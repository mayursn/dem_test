DROP PROCEDURE IF EXISTS `sp_emploee_INSERT_byPK`;
DELIMITER //
CREATE PROCEDURE sp_emploee_INSERT_byPK (IN p_first_name VARCHAR(10), IN p_last_name VARCHAR(10), IN p_salary DECIMAL(10,2), IN p_city VARCHAR(20), OUT p_id INT(11))
BEGIN 
  INSERT INTO employee (first_name, last_name, salary, city) VALUES (p_first_name, p_last_name, p_salary, p_city); 

  set p_id = (SELECT LAST_INSERT_ID());  
END //

DROP PROCEDURE IF EXISTS `sp_clientinsert`;
DELIMITER //
CREATE PROCEDURE sp_clientinsert (IN p_client_name VARCHAR(255), IN p_status ENUM('0','1'), IN p_is_deleted ENUM('0','1'), IN p_email VARCHAR(255), IN p_profile_pic VARCHAR(255), OUT client_id INT(11))
BEGIN 
  INSERT INTO client (client_name, status, is_deleted, email,profile_pic) VALUES (p_client_name, p_status, p_is_deleted, p_email,p_profile_pic); 
  set client_id = (SELECT LAST_INSERT_ID());  
END //


# Client Stored procedure
DROP PROCEDURE IF EXISTS `clientCRUD`;

DELIMITER //
CREATE PROCEDURE `clientCRUD`(
      pAction VARCHAR(10)
      ,pid INT
      ,pfname VARCHAR(255)
      ,plname VARCHAR(255)
      ,psalutationtype VARCHAR(255)
      ,pphone VARCHAR(255)
      ,pcompany VARCHAR(255)
      ,pmobile VARCHAR(255)
      ,pdesignation VARCHAR(255)
      ,pfax VARCHAR(255)
      ,pstatus ENUM('0','1')
      ,pis_deleted ENUM('0','1')
      ,pemail VARCHAR(255)
	  ,pprofile VARCHAR(255)
	  , OUT pclient_id INT

)
BEGIN
        IF pAction = "SELECT" THEN
        SELECT *
        FROM client;
     END IF;
 
        IF pAction = "INSERT" THEN
     INSERT INTO client (client_fname,client_lname,client_salutationtype,client_phone,client_company,client_mobile,client_designation,client_fax, status, is_deleted, client_email,profile_pic) 
     VALUES (pfname,plname,psalutationtype,pphone,pcompany,pmobile,pdesignation,pfax, pstatus, pis_deleted, pemail,pprofile); 
  set pclient_id = (SELECT LAST_INSERT_ID()); 
    END IF;
 
        IF pAction = "UPDATE" THEN
        UPDATE client
        SET client_fname = pfname,
        client_lname = plname,
        client_salutationtype = psalutationtype,
        client_phone = pphone,
        client_company = pcompany,
        client_mobile = pmobile,
        client_designation = pdesignation,
        client_fax = pfax,
         status = pstatus,is_deleted=pis_deleted,client_email=pemail,profile_pic=pprofile
        WHERE client_id = pid;
    END IF;
     
        IF pAction = "DELETE" THEN
        DELETE FROM client
        WHERE client_id = pid;
    END IF;
END //

#Final insert Lead SP 6-3-2017

DELIMITER $$
CREATE PROCEDURE lead_insertproc (
  IN plead_fname VARCHAR(255),
  IN plead_lname varchar(255),
  IN plead_status ENUM('0','1'),
  IN plead_salutationtype varchar(10),
  IN plead_phone varchar(20),
  IN plead_company varchar(255),
  IN plead_mobile varchar(20),
  IN plead_designation varchar(255),
  IN plead_fax varchar(20),
  IN plead_source varchar(255),
  IN plead_email varchar(255),
  IN plead_industry varchar(255),
  IN plead_website varchar(255),
  IN plead_anrevenue varchar(255),
  IN pleads_status varchar(255),
  IN plead_emp_no varchar(255),
  IN plead_rating varchar(255),
  IN plead_second_email varchar(255),
  IN plead_assigned_to varchar(255),
  IN plead_optout varchar(10),
  IN plead_street text,
  IN plead_pobox varchar(255),
  IN plead_postal_code varchar(10),
  IN plead_city varchar(255),
  IN plead_country varchar(255),
  IN plead_state varchar(255),
  IN plead_description text )

BEGIN
DECLARE clienid INT(11);

IF EXISTS (SELECT client_id FROM client WHERE client_email=plead_email) THEN
SET clienid = (SELECT client_id FROM client WHERE client_email=plead_email);
  ELSE 
  insert into client (client_fname,client_lname,client_salutationtype,client_phone,client_company,client_mobile,client_designation,client_fax,client_email,profile_pic)  VALUES
 (plead_fname,plead_lname,plead_salutationtype,plead_phone,plead_company,plead_mobile,plead_designation,plead_fax,plead_email,'user.png'); 
set clienid = (select last_insert_id()); 
  END IF;
INSERT INTO lead_mgmt (lead_fname,
lead_lname,
lead_status,
lead_salutationtype,
lead_phone,
lead_company,
lead_mobile,
lead_designation,
lead_fax,
lead_source,
lead_email,
lead_industry,
lead_website,
lead_anrevenue,
leads_status,
lead_emp_no,
lead_rating,
lead_second_email,
lead_assigned_to,
lead_optout,
lead_street,
lead_pobox,
lead_postal_code,
lead_city,
lead_country,
lead_state,
lead_description)
VALUES (plead_fname,
plead_lname,
plead_status,
plead_salutationtype,
 plead_phone,
 plead_company,
 plead_mobile,
 plead_designation,
 plead_fax,
 plead_source,
 plead_email,
 plead_industry,
 plead_website,
 plead_anrevenue,
 pleads_status,
 plead_emp_no,
 plead_rating,
 plead_second_email,
 plead_assigned_to,
 plead_optout,
 plead_street,
 plead_pobox,
 plead_postal_code,
 plead_city, 
 plead_country,
 plead_state,
 plead_description);
END $$



# try new one UPDATE lead sp

DELIMITER $$

CREATE PROCEDURE lead_updateproc ( 
  IN plead_fname VARCHAR(255),
  IN plead_lname varchar(255),
  IN plead_status ENUM('0','1'),
  IN plead_salutationtype varchar(10),
  IN plead_phone varchar(20),
  IN plead_company varchar(255),
  IN plead_mobile varchar(20),
  IN plead_designation varchar(255),
  IN plead_fax varchar(20),
  IN plead_source varchar(255),
  IN plead_email varchar(255),
  IN plead_industry varchar(255),
  IN plead_website varchar(255),
  IN plead_anrevenue varchar(255),
  IN pleads_status varchar(255),
  IN plead_emp_no varchar(255),
  IN plead_rating varchar(255),
  IN plead_second_email varchar(255),
  IN plead_assigned_to varchar(255),
  IN plead_optout varchar(10),
  IN plead_street text,
  IN plead_pobox varchar(255),
  IN plead_postal_code varchar(10),
  IN plead_city varchar(255),
  IN plead_country varchar(255),
  IN plead_state varchar(255),
  IN plead_description text,IN pid INT(11) )

BEGIN

DECLARE clienid INT(11);

IF EXISTS (SELECT client_id FROM client WHERE client_email=plead_email) THEN
SET clienid = (SELECT client_id FROM client WHERE client_email=plead_email);
  ELSE 
  insert into client (client_fname,client_lname,client_salutationtype,client_phone,client_company,client_mobile,client_designation,client_fax,client_email,profile_pic)  VALUES
 (plead_fname,plead_lname,plead_salutationtype,plead_phone,plead_company,plead_mobile,plead_designation,plead_fax,plead_email,'user.png'); 
set clienid = (select last_insert_id()); 
  END IF;

UPDATE lead_mgmt SET lead_fname = plead_fname,
lead_lname = plead_lname,
lead_status = plead_status,
lead_salutationtype = plead_salutationtype,
lead_phone = plead_phone,
lead_company = plead_company,
lead_mobile = plead_mobile,
lead_designation = plead_designation,
lead_fax = plead_fax,
lead_source = plead_source,
lead_email = plead_email, 
lead_industry = plead_industry,
lead_website = plead_website,
lead_anrevenue = plead_anrevenue,
leads_status = pleads_status,
lead_emp_no = plead_emp_no,
lead_rating = plead_rating,
lead_second_email = plead_second_email,
lead_assigned_to = plead_assigned_to,
lead_optout = plead_optout,
lead_street = plead_street,
lead_pobox = plead_pobox, 
lead_postal_code = plead_postal_code,
lead_city = plead_city,
lead_country = plead_country,
lead_state = plead_state,
lead_description = plead_description
WHERE lead_id = pid;
END $$
# try end


DELETE lead_mgmt, comment FROM lead_mgmt INNER JOIN comment
WHERE lead_mgmt.lead_id='3' AND comment.lead_id='3';


# Delete Lead And lead comments 
DROP PROCEDURE IF EXISTS `sp_leadandcomment_DELETE_byPK` 
DELIMITER $$

CREATE PROCEDURE sp_leadandcomment_DELETE_byPK
     (
        IN  p_lead_id  INT(11) 
     )
BEGIN 

    DELETE FROM lead_mgmt
    WHERE  lead_id = p_lead_id ; 
    DELETE FROM comment
    WHERE  lead_id = p_lead_id ; 

END $$
