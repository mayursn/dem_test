/**
** Counselor form Validation
** All primary and required validation for new counselor
** Used Jquery Rules validation
** 
*/

$(document).ready(function () {



    $.validator.setDefaults({ ignore: ":hidden:not(.chosen-select)" });
jQuery.validator.addMethod("primaryPhone", function (value, element) {
            return this.optional(element) || /^[0-9-+]+$/.test(value);
        }, 'Enter valid primary phone');
jQuery.validator.addMethod("faxNo", function (value, element) {
            return this.optional(element) || /^\+?[0-9]{6,}$/.test(value);
        }, 'Enter valid fax No');

      jQuery.validator.addMethod("emailAddress", function (value, element) {
            return this.optional(element) || /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/.test(value);
        }, 'Enter Valid email');

      jQuery.validator.addMethod("zipcode", function(value, element) {
  return this.optional(element) || /^\d{6}(?:-\d{4})?$/.test(value);
}, "provide a valid postal code.");

        /**
        Lead form Validation
        **/
        $("#form_client").validate({
            rules: {
                salutationtype:{required:true},
                client_fname:{required:true, minlength:3, maxlength:25},
                client_lname:{required:true,minlength:3, maxlength:25},
                client_phone:{required:true,
                		primaryPhone:true,
                          maxlength:15,
                          minlength:10},
                client_company:{required:true, maxlength:50},
                client_mobile:{primaryPhone:true,
                          maxlength:15,
                          minlength:10},
                client_designation:{required:true, maxlength:50},
                client_fax:{required:true,
                	faxNo:true, maxlength:20},                
                client_email:{required:true,emailAddress:true}
            },
            messages: {
                salutationtype:{required:"Select salutation type"},
                client_fname:{required:"Enter First Name"},                             
                client_lname:{required:"Enter Last Name"},
                client_phone:{required:"Enter Primary Phone",
            					primaryPhone:"Enter valid primary phone",
                             	maxlength:"Enter only 15 numbers",
                             	minlength:"Enter at least 10 numbers."},
                client_company:{required:"Enter Company Name"},
                client_mobile:{primaryPhone:"Enter valid mobile phone",
                             	maxlength:"Enter only 15 numbers",
                             	minlength:"Enter at least 10 numbers."},
                client_designation:{required:"Enter Designation"},
                client_fax:{required:"Enter fax number",
            		faxNo:"Enter Valid Fax No"},
                client_email:{required:"Enter email",emailAddress:"Enter valid email"}
                
            }
        });


          
        
    });