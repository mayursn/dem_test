$(document).ready(function(){
/**
* autofillup the lead (Client) details if client already exists
* Call Client function for lead data
* @param response mixed array
*/
	$( "#input-email" ).change(function() {
		var email = $( "#input-email" ).val();
		
		      var data = 'email='+ email;
  		$.ajax({
  			type:"POST",
  			url:base_url+"lead/getLeadData/",
  			data:{email:email},
  			success:function(response){
  				//alert(response);
          if(response!="Data not found")
          {
            
            var leadData = jQuery.parseJSON(response);    
            //console.log(leadData[0].client_fname);
            $("#input-fname").val(leadData[0].client_fname);
            $("#input-lname").val(leadData[0].client_lname);
            $("#salutationtype").val(leadData[0].client_salutationtype).trigger("chosen:updated");            
            $("#input-phone").val(leadData[0].client_phone);
            $("#input-company").val(leadData[0].client_company);
            $("#input-mobile").val(leadData[0].client_mobile);
            $("#input-designation").val(leadData[0].client_designation);
            $("#input-fax").val(leadData[0].client_fax);
          }else{

          }
        

        //alert(leadData);

  			}

  		})


	});

});