/**
** Counselor form Validation
** All primary and required validation for new counselor
** Used Jquery Rules validation
** 
*/

$(document).ready(function () {



    $.validator.setDefaults({ ignore: ":hidden:not(.chosen-select)" });
jQuery.validator.addMethod("primaryPhone", function (value, element) {
            return this.optional(element) || /^[0-9-+]+$/.test(value);
        }, 'Enter valid primary phone');
jQuery.validator.addMethod("faxNo", function (value, element) {
            return this.optional(element) || /^\+?[0-9]{6,}$/.test(value);
        }, 'Enter valid fax No');

      jQuery.validator.addMethod("emailAddress", function (value, element) {
            return this.optional(element) || /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/.test(value);
        }, 'Enter Valid email');

      jQuery.validator.addMethod("zipcode", function(value, element) {
  return this.optional(element) || /^\d{6}(?:-\d{4})?$/.test(value);
}, "provide a valid postal code.");

        /**
        Lead form Validation
        **/
        $("#form_counselor").validate({
            rules: {
               
                fname:{required:true, minlength:3, maxlength:25},
                lname:{required:true,minlength:3, maxlength:25},
                phone:{required:true,
                		primaryPhone:true,
                          maxlength:15,
                          minlength:10},
                company:{required:true, maxlength:50},
                mobile:{primaryPhone:true,
                          maxlength:15,
                          minlength:10},
                designation:{required:true, maxlength:50},
                fax:{required:true,
                	faxNo:true, maxlength:20},
                lead_source:{required:true},
                email:{required:true,emailAddress:true},
                industry:{required:true},
                website:{required:true,url: true},
                revenue:{required:true},                
                lead_status:{required:true},
                noemployee:{required:true},
                rating:{required:true},
                second_email:{emailAddress:true},
                assigned:{required:true},
                emailoptout:{required:true},
                street:{required:true, maxlength:255},
                pobox:{required:true,maxlength:50},
                postal_code:{required:true,zipcode:true,maxlength:10},
                city:{required:true,maxlength:50},
                country:{required:true,maxlength:50},
                state:{required:true,maxlength:50},
                description:{required:true}
            },
            messages: {
               
                fname:{required:"Enter First Name"},                             
                lname:{required:"Enter Last Name"},
                phone:{required:"Enter Primary Phone",
            					primaryPhone:"Enter valid primary phone",
                             	maxlength:"Enter only 15 numbers",
                             	minlength:"Enter at least 10 numbers."},
                company:{required:"Enter Company Name"},
                mobile:{primaryPhone:"Enter valid mobile phone",
                             	maxlength:"Enter only 15 numbers",
                             	minlength:"Enter at least 10 numbers."},
                designation:{required:"Enter Designation"},
                fax:{required:"Enter fax number",
            		faxNo:"Enter Valid Fax No"},
                lead_source:{required:"Select Lead Source"},
                email:{required:"Enter email",emailAddress:"Enter valid email"},
                industry:{required:"Select Industry"},
                website:{required:"Enter Website",
                url:"Enter Valid Website address"},
                revenue:{required:"Enter Annual Revenue"},
                lead_status:{required:"Select Lead Status"},
                noemployee:{required:"Enter Employee no"},
                rating:{required:"Select rating"},
                second_email:{emailAddress:"Enter valid email"},
                assigned:{required:"Assign at least one"},
                emailoptout:{required:"Select Email opt out"},
                street:{required:"Enter Street"},
                pobox:{required:"Enter PO Box"},
                postal_code:{required:"Enter Postal code",zipcode:"provide valid postal code"},
                city:{required:"Enter City Name"},
                country:{required:"Enter Country name"},
                state:{required:"Enter State name"},
                description:{required:"Enter description"}                
                
            }
        });

         $("#form_lead_status").validate({
            rules: {
               
                status_name:{required:true, minlength:3, maxlength:255},
            },
            messages: {
               
                status_name:{required:"Enter Status Name"},                
                
            }
        });

          $("#form_lead_source").validate({
            rules: {
               
                source_name:{required:true, minlength:3, maxlength:255},
            },
            messages: {
               
                source_name:{required:"Enter Source Name"},                
                
            }
        });
          $("#form_lead_industry").validate({
            rules: {
               
                industry_name:{required:true, minlength:3, maxlength:255},
            },
            messages: {
               
                industry_name:{required:"Enter Industry Name"},                
                
            }
        });

          $("#form_lead_rating").validate({
            rules: {
               
                rating_name:{required:true, minlength:3, maxlength:255},
            },
            messages: {
               
                rating_name:{required:"Enter Rating Name"},                
                
            }
        });

            $("#form_thread").validate({
            rules: {
               
                user:{required:true},
                comment:{required:true}

            },
            messages: {
               
                user:{required:"Select User Type"},
                comment:{required:"Enter Comment"}
                
            }
        });
          
        
    });