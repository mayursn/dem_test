<?php
class Lead_status_model extends MY_Model {   
 	protected $primary_key = 'status_id';      
 	
	function __construct(){            
	  	parent::__construct();
		$this->user_id =isset($this->session->get_userdata()['user_details'][0]->id)?$this->session->get_userdata()['user_details'][0]->users_id:'1';
	}

	
}