<?php
class Lead_source_model extends MY_Model {  
protected $primary_key = 'source_id';      
	function __construct(){            
	  	parent::__construct();
		$this->user_id =isset($this->session->get_userdata()['user_details'][0]->id)?$this->session->get_userdata()['user_details'][0]->users_id:'1';
	}

}