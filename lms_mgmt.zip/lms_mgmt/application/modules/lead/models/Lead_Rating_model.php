<?php
class Lead_Rating_model extends MY_Model { 
  protected $primary_key = 'rating_id';      
	function __construct(){            
	  	parent::__construct();
		$this->user_id =isset($this->session->get_userdata()['user_details'][0]->id)?$this->session->get_userdata()['user_details'][0]->users_id:'1';
	}
}