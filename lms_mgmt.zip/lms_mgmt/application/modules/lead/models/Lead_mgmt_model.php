<?php
class Lead_mgmt_model extends MY_Model {  
	protected $primary_key = 'lead_id';      // protected primary key
	function __construct(){            
	  	parent::__construct();
		$this->user_id =isset($this->session->get_userdata()['user_details'][0]->id)?$this->session->get_userdata()['user_details'][0]->users_id:'1';
	}
	
}