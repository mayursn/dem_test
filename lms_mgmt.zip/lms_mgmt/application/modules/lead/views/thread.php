<link href="<?php echo base_url(); ?>assets/css/timeline.css" rel="stylesheet" type="text/css"  >
<div class="content-wrapper">
   <!-- Content Header (Page header) -->
   <!-- Main content -->
   <section class="content">
      <?php if($this->session->flashdata("messagePr")){?>
      <div class="alert alert-info">      
         <?php echo $this->session->flashdata("messagePr")?>
      </div>
      <?php } ?>
      <div class="row">
         <div class="col-xs-12">
            <div class="box box-success">
               <div class="box-header with-border">
                  <h3 class="box-title">Comment Thread</h3>
               </div>
               <!-- /.box-header -->
               <div class="box-body">
                  <form class="form-horizontal" method='POST' action="<?php echo base_url(); ?>lead/createComment" id="form_thread">
                     <div class="row">
                        <div class="col-md-12">
                           <div class="panel panel-white">
                              <div class="panel-body">
                                 <div class="form-group hidden">
                                    <label for="input-user" class="col-sm-4 ">Reply Comment</label>
                                    <?php $lead_comment =  getCommentByLeadId($lead_id); // get comment by lead id for parent id   ?>                                       
                                    <div class="col-sm-3" >
                                       <select class="form-control"   name="thread_id" id="thread_id" >
                                          <option value="">None</option>
                                          <?php foreach ( $lead_comment as $leadRow) { ?>
                                          <option value="<?php echo $leadRow->thread_id; ?>"><?php echo "#".$leadRow->thread_id; ?></option>
                                          <?php } ?>
                                       </select>
                                    </div>
                                 </div>
                                 <div class="form-group">
                                    <label for="input-user" class="col-sm-4 ">Select User Type</label>
                                    <div class="col-sm-3">
                                       <select class="form-control select2 chosen-select"   name="user" id="user_type" >
                                          <option value="">None</option>
                                          <option value="From SN">From SN</option>
                                          <option value="From Client">From Client</option>
                                       </select>
                                    </div>
                                 </div>
                                 <div class="form-group">
                                    <label for="input-user" class="col-sm-4 ">Comment</label>
                                    <div class="col-sm-8">
                                       <textarea  name="comment" rows="5" cols="60" ></textarea>
                                    </div>
                                 </div>
                                 <div class="form-group">
                                    <div class="col-sm-8">
                                       <input type="hidden" name="lead_id" value="<?php echo $lead_id; ?>">
                                    </div>
                                    <input class="btn btn-success" type="submit" value='Submit' name='submit_add_thread'/>                                  
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <!-- Row -->
                  </form>
                  <?php if(count($comments) )
                     { ?>
                  <div class="page-header">
                     <h1 id="timeline">Timeline</h1>
                  </div>
                  <ul class="timeline">
                     <?php 
                        foreach (@$comments as $rows) {
                           if($rows->created_by=="From SN"){
                              $user = getDataByid('users',$rows->created_id,'users_id');
                              $name = $user->name;
                           }
                           if($rows->created_by=="From Client"){
                              $user = getDataByid('client',$rows->created_id,'client_id');
                              $name = $user->client_fname.' '.$user->client_lname;
                           }
                        ?>
                     <li class="<?php if($rows->created_by!="From Client"){  echo "timeline-inverted"; }?>" id="<?php echo $rows->thread_id; ?>">
                        <!--<div class="timeline-badge"><i class="glyphicon glyphicon-check"></i></div> -->
                        <div class="timeline-badge"><?php echo date('M d',strtotime($rows->created_date)); ?></div>
                        <div class="timeline-panel">
                           <div class="timeline-heading">
                              <h4 class="timeline-title"><?php echo $name; ?>
                                 <?php if($rows->parent_id > 0){ ?>
                                 <a href="#<?php  if($rows->parent_id > 0){ echo $rows->parent_id; }else{ echo ''; } ?>">#<?php echo $rows->parent_id; ?></a>
                                 <?php } ?>
                                 <span class="comment-text"><?php echo $rows->thread_id; ?> </span>
                              </h4>                              
                              <p><small class="text-muted"><i class="glyphicon glyphicon-time"></i> <?php echo date('M d, Y',strtotime($rows->created_date)); ?></small></p>
                           </div>
                           <div class="timeline-body">
                              <p><?php echo $rows->comment_text; ?></p>
                              <?php if($rows->created_by=="From Client"){
                                    $reply_text = "From SN";
                                 }else{
                                    $reply_text = "From Client";
                                    } ?>
                              <p><a class="reply-text" href="#form_thread" onclick="setReplyContent('<?php echo $rows->thread_id; ?>','<?php echo $reply_text; ?>');" >Reply</a></p>
                           </div>
                        </div>
                     </li>
                     <?php } ?>
                  </ul>
                  <?php }else{ ?>
                  <div class="page-header">
                     <h5 id="timeline"> No Conversation </h5>
                  </div>
                  <?php } ?>
                  <!-- Timeline Container -->
               </div>
            </div>
         </div>
      </div>
   </section>
</div>

