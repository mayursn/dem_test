

<div class="content-wrapper">
   <!-- Content Header (Page header) -->
   <!-- Main content -->
   <section class="content">
      <?php if($this->session->flashdata("messagePr")){?>
      <div class="alert alert-info">      
         <?php echo $this->session->flashdata("messagePr")?>
      </div>
      <?php } ?>
      <div class="page-inner">
         <div class="page-title">
            <h3>Add New Lead</h3>
         </div>
         <div id="main-wrapper">
            <form class="form-horizontal" method='POST' action="<?php echo base_url(); ?>lead/addlead" id="form_counselor" >
               <div class="row">
                  <div class="col-md-12">
                     <div class="panel panel-white">
                        <div class="panel-heading clearfix">
                           <h4 class="panel-title">New Lead Information</h4>
                        </div>
                        <div class="panel-body">
                        <div class="row form-group">
                           <div class="col-md-6">
                              <label for="input-fname" class="col-sm-3">First Name</label>
                              <div class="col-sm-3">
                                 <select class="form-control select2 chosen-select"   name="salutationtype" id="salutationtype" >
                                    <option value="">None</option>
                                    <?php $sel = ("Mr." == set_value('salutationtype')) ? 'selected="selected"' : ''; ?>
                                    <option value="Mr." <?php echo $sel; ?>>Mr.</option>
<?php $sel = ("Ms." == set_value('salutationtype')) ? 'selected="selected"' : ''; ?>
                                    <option value="Ms."  <?php echo $sel; ?>>Ms.</option>
                                    <?php $sel = ("Mrs." == set_value('salutationtype')) ? 'selected="selected"' : ''; ?>
                                    <option value="Mrs."  <?php echo $sel; ?>>Mrs.</option>
                                    <?php $sel = ("Dr." == set_value('salutationtype')) ? 'selected="selected"' : ''; ?>
                                    <option value="Dr."  <?php echo $sel; ?>>Dr.</option>
                                    <?php $sel = ("Prof." == set_value('salutationtype')) ? 'selected="selected"' : ''; ?>
                                    <option value="Prof."  <?php echo $sel; ?>>Prof.</option>
                                 </select>
                              </div> <!-- -->
                              <div class="col-sm-6">
                                 <input type="text"  class="form-control" name='fname' id="input-fname" value="<?php echo set_value('fname'); ?>" />                                            
                              </div>
                           </div>
                           <div class="col-md-6">
                              <label for="input-lname" class="col-sm-4">Last Name</label>
                              <div class="col-sm-8">
                                 <input type="text" class="form-control" id="input-lname" name='lname' value="<?php echo set_value('lname'); ?>">
                              </div>
                           </div>
                        </div>
                        <div class="row form-group">
                           <div class="col-md-6">
                              <label for="input-phone" class="col-sm-4 ">Primary Phone</label>
                              <div class="col-sm-8">
                                 <input type="text" minlength="10" maxlength="15" class="form-control" id="input-phone" name='phone'  value="<?php echo set_value('phone'); ?>">
                              </div>
                           </div>
                            <div class="col-md-6">
                              <label for="input-company" class="col-sm-4 ">Company</label>
                              <div class="col-sm-8">
                                 <input type="text" class="form-control" id="input-company" name='company'  value="<?php echo set_value('company'); ?>">
                              </div>
                           </div>
                           </div>
                           <div class="row form-group">
                           <div class="col-md-6">
                              <label for="input-mobile" class="col-sm-4 ">Mobile Phone</label>
                              <div class="col-sm-8">
                                 <input type="text" class="form-control" id="input-mobile" name='mobile'   value="<?php echo set_value('mobile'); ?>">
                              </div>
                           </div>
                            <div class="col-md-6">
                              <label for="input-designation" class="col-sm-4 ">Designation</label>
                              <div class="col-sm-8">
                                 <input type="text" class="form-control" id="input-designation" name='designation'  value="<?php echo set_value('designation'); ?>">
                              </div>
                           </div>
                           </div>
                           <div class="row form-group">
                           <div class="col-md-6">
                              <label for="input-fax" class="col-sm-4">Fax
                              </label>
                              <div class="col-sm-8">
                                 <input type="text" class="form-control" id="input-fax" name='fax'  value="<?php echo set_value('fax'); ?>">
                              </div>
                           </div>

                            <div class="col-md-6">
                              <label for="input-lead_source" class="col-sm-4 ">Lead Source</label>
                              <div class="col-sm-8">
                                 <select name="lead_source" class="form-control chosen-select"  id="input-lead_source">
                                    <option value="">Select an Option</option>
                                    <?php $leadSource = getLeadSourceList(); 
                                       foreach ($leadSource as $sourceRow) {?>
                                        <?php $sel = ($sourceRow->source_id == set_value('lead_source')) ? 'selected="selected"' : ''; ?>
                                    <option value="<?php echo $sourceRow->source_id; ?>" <?php echo $sel; ?>><?php echo $sourceRow->source_name; ?></option>
                                    <?php } ?>
                                 </select>
                                 <div class="box-tools">
                                    <button data-toggle="modal" class="btn-sm  btn btn-success modalButtonLeadSource" type="button"><i class="glyphicon glyphicon-plus"></i></button>       
                                 </div>
                              </div>
                              
                           </div>
                           </div>
                           <div class="row form-group">
                           <div class="col-md-6">
                              <label for="input-email" class="col-sm-4 ">Primary Email</label>
                              <div class="col-sm-8">
                                 <input type="text" class="form-control" id="input-email" name='email' value="<?php echo set_value('email'); ?>">
                              </div>
                           </div>
                           <div class="col-md-6">
                              <label for="input-industry" class="col-sm-4 ">Industry</label>
                              <div class="col-sm-8">
                                 <select name="industry" class="form-control chosen-select"  id="input-industry">
                                    <option value="">Select an Option</option>
                                    <?php $leadIndustry = getLeadIndustryList(); 
                                       foreach ($leadIndustry as $industryRow) {?>
                                       <?php $sel = ($industryRow->ind_id == set_value('industry')) ? 'selected="selected"' : ''; ?>
                                    <option value="<?php echo $industryRow->ind_id; ?>" <?php echo $sel; ?>><?php echo $industryRow->industry_name; ?></option>
                                    <?php } ?>
                                 </select>
                                 <div class="box-tools">
                                    <button data-toggle="modal" class="btn-sm  btn btn-success modalButtonIndustry" type="button"><i class="glyphicon glyphicon-plus"></i></button>
                                    <div id="IndustryInput"></div>
                                 </div>
                              </div>
                           </div>
                           </div>
                           <div class="row form-group">
                           <div class="col-md-6">
                              <label for="input-website" class="col-sm-4 ">Website</label>
                              <div class="col-sm-8">
                                 <input type="text" name="website" class="form-control" id="input-website" value="<?php echo set_value('website'); ?>">
                              </div>
                           </div>
                           
                           </div>
                          <div class="row form-group">
                           <div class="col-md-6">
                              <label for="input-leadstatus" class="col-sm-4 ">Lead Status</label>
                              <div class="col-sm-8">
                                 <select class="form-control chosen-select"   name="lead_status" id="input-leadstatus" >
                                    <option value="">Select an Option</option>
                                    <?php $statusList = getStatusList(); 
                                       foreach ($statusList as $row) { ?>
                                         <?php $sel = ($row->status_id == set_value('lead_status')) ? 'selected="selected"' : ''; ?>
                                    <option value="<?php echo $row->status_id; ?>" <?php echo $sel; ?>><?php echo $row->status_name; ?></option>
                                    <?php } ?>
                                 </select>
                                 <div class="box-tools">
                                    <button data-toggle="modal" class="btn-sm  btn btn-success modalButtonLeadStatus" type="button"><i class="glyphicon glyphicon-plus"></i></button>                                   
                                 </div>
                              </div>
                           </div>
                            
                           </div>

                            <div class="row form-group">
                           <div class="col-md-6" >
                              <label for="input-rating" class="col-sm-4 ">Rating</label>
                              <div class="col-sm-8">
                                 <select class="form-control chosen-select"   name="rating" id="input-rating" >
                                    <option value="">Select an Option</option>
                                    <?php $ratingList = getLeadRatingList(); 
                                       foreach ($ratingList as $ratingRow) {?>
                                        <?php $sel = ($ratingRow->rating_id == set_value('rating')) ? 'selected="selected"' : ''; ?>
                                    <option value="<?php echo $ratingRow->rating_id; ?>" <?php echo $sel; ?>><?php echo $ratingRow->rating_name; ?></option>
                                    <?php } ?>
                                 </select>
                                 <div class="box-tools">
                                    <button data-toggle="modal" class="btn-sm  btn btn-success modalButtonLeadRating" type="button"><i class="glyphicon glyphicon-plus"></i></button>                                   
                                 </div>
                              </div>
                              </div>
                              
                              </div>
                           <div class="row form-group">
                           <div class="col-md-6">
                              <label for="input-assigned" class="col-sm-4 ">Assigned To</label>
                              <div class="col-sm-8">
                                 <select class="form-control chosen-select"   name="assigned" id="input-assigned" >
                                 <option value="">Select an Option</option>

                                    <optgroup label="Users">
                                       <?php $users = getAllDataByTable('users','*','user_id,name,user_type'); 
                                       foreach ($users as $ukey => $uvalue) {
                                           $sel = ($uvalue->users_id == set_value('assigned')) ? 'selected="selected"' : ''; 
                                          if($uvalue->user_type!="admin")
                                          {
                                       ?>
                                       <option value="<?php echo $uvalue->users_id; ?>" <?php echo $sel; ?>><?php echo $uvalue->name; ?></option>

                                       <?php 
                                          }
                                       } ?>
                                    </optgroup>                                  
                                 </select>
                              </div>
                           </div>
                           <div class="col-md-6">
                              <label for="input-emailoptout" class="col-sm-4 ">Email Opt Out</label>
                              <div class="col-sm-8">
                                 <input type="checkbox"name="emailoptout" value="1" <?php if(set_value('emailoptout')=="1"){ echo "checked='checked'"; } ?> id="input-emailoptout">
                              </div>
                           </div>
                           </div>

                        </div>
                     </div>
                  
                  <!-- Second part  -->
                 
                  <div class="col-md-12">
                     <div class="panel panel-white">
                        <div class="panel-heading clearfix">
                           <h4 class="panel-title">Address Details</h4>
                        </div>
                        <div class="panel-body">
                           <div class="col-md-12">
                           <div class="row form-group">
                              <div class="col-md-6">
                                 <label for="input-street" class="col-sm-4 ">Street</label>
                                 <div class="col-sm-8">
                                    <textarea  class="form-control" id="input-street" name='street'> <?php echo set_value('street'); ?></textarea>
                                 </div>
                              </div>
                              <div class="col-md-6">
                                 <label for="input-pobox" class="col-sm-4 ">PO Box</label>
                                 <div class="col-sm-8">
                                    <input type="text"  class="form-control" id="input-pobox" name='pobox' value="<?php echo set_value('pobox'); ?>">
                                 </div>
                              </div>
                              </div>
                              <div class="row form-group">
                              <div class="col-md-6">
                                 <label for="input-postal_code" class="col-sm-4 ">  Postal Code</label>
                                 <div class="col-sm-8">
                                    <input type="text"   class="form-control" id="input-postal_code" name='postal_code' value="<?php echo set_value('postal_code'); ?>" />
                                 </div>
                              </div>
                              <div class="col-md-6">
                                 <label for="input-city" class="col-sm-4 ">  City</label>
                                 <div class="col-sm-8">
                                    <input type="text"   class="form-control" id="input-city" name='city' value="<?php echo set_value('city'); ?>" />
                                 </div>
                              </div>
                              </div>
                             <div class="row form-group">
                              <div class="col-md-6">
                                 <label for="input-country" class="col-sm-4 ">  Country</label>
                                 <div class="col-sm-8">
                                    <input type="text"   class="form-control" id="input-country" name='country' value="<?php echo set_value('country'); ?>" />
                                 </div>
                              </div>
                              <div class="col-md-6">
                                 <label for="input-state" class="col-sm-4 ">  State</label>
                                 <div class="col-sm-8">
                                    <input type="text"   class="form-control" id="input-state" name='state' value="<?php echo set_value('state'); ?>" />
                                 </div>
                              </div>
                              </div>
                           </div>
                        </div>
                        <!-- panel body -->
                     </div>
                  </div>                 
                  <div class="col-md-12">
                     <div class="panel panel-white">
                        <div class="panel-heading clearfix">
                           <h4 class="panel-title">Description Details</h4>
                        </div>
                        <div class="panel-body">
                           <div class="col-md-12">
                              <div class="form-group">
                                 <label for="input-description" class="col-sm-4 ">Description</label>
                                 <div class="col-sm-10">
                                    <textarea class="form-control" id="input-description" name='description'><?php echo set_value('description'); ?></textarea>
                                 </div>
                              </div>
                              <input class="btn btn-success" type="submit" value='Submit' name='submit_add_counselor'/>
                              <input class="btn btn-success" type="reset" value='Reset' name='Reset_button'/>
                           </div>
                        </div>
                        <!-- panel body -->
                     </div>
                  </div>
                  <!-- col md 12 -->
               </div>
               <!-- Row -->
            </form>
         </div>
         <!-- Main Wrapper -->
      </div>
   </section>
</div>



<script type="text/javascript">
/*   Industry dropdown replace */
    function responseIndustry()
    {
          $('#input-industry').find('option').remove().end();
            $('#input-industry').append('<option value>Select</option>');
            $.ajax({
                url: "<?php echo base_url(); ?>lead/Industry/getIndustryList",
                type: 'GET',
                success: function (content) {
                    var industry = jQuery.parseJSON(content);
                    console.log(industry);
                    $.each(industry, function (key, value) {
                        $('#input-industry').append('<option value=' + value.ind_id + '>' + value.industry_name + '</option>').trigger("chosen:updated");
                      
                    });
                }
            });
     
    }
    /*   Industry dropdown replace end */

    /*   Lead Status dropdown replace */
    function responseStatus()
    {
        $('#input-leadstatus').find('option').remove().end();
            $('#input-leadstatus').append('<option value>Select</option>');
            $.ajax({
                url: "<?php echo base_url(); ?>lead/LeadStatus/getStatusList",
                type: 'GET',
                success: function (content) {
                    var statusdata = jQuery.parseJSON(content);
                    console.log(statusdata);
                    $.each(statusdata, function (key, value) {
                        $('#input-leadstatus').append('<option value=' + value.status_id + '>' + value.status_name + '</option>').trigger("chosen:updated");
                      
                    });
                }
            });
    }
    /*   Lead Status dropdown end */
    /*   Lead Rating dropdown replace */
    function responseRating()
    {
        $('#input-rating').find('option').remove().end();
            $('#input-rating').append('<option value>Select</option>');
            $.ajax({
                url: "<?php echo base_url(); ?>lead/LeadRating/getRatingList",
                type: 'GET',
                success: function (content) {
                    var ratingdata = jQuery.parseJSON(content);
                    console.log(ratingdata);
                    $.each(ratingdata, function (key, value) {
                        $('#input-rating').append('<option value=' + value.rating_id + '>' + value.rating_name + '</option>').trigger("chosen:updated");
                      
                    });
                }
            });
    }
    /*   Lead Rating dropdown end */
     /*   Lead Source dropdown replace */
    function responseSource()
    {
        $('#input-lead_source').find('option').remove().end();
            $('#input-lead_source').append('<option value>Select</option>');
            $.ajax({
                url: "<?php echo base_url(); ?>lead/LeadSource/getSourceList",
                type: 'GET',
                success: function (content) {
                    var sourcedata = jQuery.parseJSON(content);
                    console.log(sourcedata);
                    $.each(sourcedata, function (key, value) {
                        $('#input-lead_source').append('<option value=' + value.source_id + '>' + value.source_name + '</option>').trigger("chosen:updated");
                      
                    });
                }
            });
    }
    /*   Lead Source dropdown end */
    

    
</script>

<!-- Modal Crud Start-->
<!-- Industry modal start-->
<div class="modal fade" id="nameModal_industry" tabindex="-1" role="dialog" aria-hidden="true" style="display: none;">
<div class="modal-dialog">
   <div class="box box-primary popup" >
      <div class="box-header with-border formsize">
         <h3 class="box-title">Industry Form</h3>
         <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
      </div>
      <!-- /.box-header -->
      <div class="modal-body" style="padding: 0px 0px 0px 0px;">
         <form role="form bor-rad" enctype="multipart/form-data" onsubmit="return industryvalid();"  method="post" id="IndustryPopup">
            <div class="box-body">
               <div class="row">
                  <div class="col-md-6">
                     <div class="form-group">
                        <label for="">Name</label>
                        <input type="text" name="industry_name" id="industry_name" value="<?php echo isset($userData->name)?$userData->name:'';?>" class="form-control" placeholder="Name">
                        <span id="industry_name-error"></span>
                     </div>
                  </div>
               </div>
               <div class="box-footer sub-btn-wdt">
                  <button type="submit" name="submit" id="IndustryAdd" value="add" class="btn btn-success wdt-bg">Add</button>
               </div>

         
         </div>
         </form>        
      </div>
   </div>

         <script type="text/javascript">
         
            $(function() {

            //twitter bootstrap script
            $("button#IndustryAdd").click(function(){
               var industry_name = $("#industry_name").val();
            if(industry_name=="")
            {
               $("#industry_name-error").html('Enter Name');
               $("#industry_name-error").css({'color':'#f00'});
               return false;
            }
            else{

               $("#industry_name-error").html();
               $("#industry_name-error").css({'color':'#FFF'});
               
            }
            $.ajax({
            type: "POST",
            url: "<?php echo base_url(); ?>lead/Industry/add_edit",
            data: $('form#IndustryPopup').serialize(),
            success: function(response){
               
               $("#industry_name").val("");
             responseIndustry();
                   
            $("#nameModal_industry").modal('hide'); 
            },
            error: function(){
            alert("failure");
            }
            });
            
            return false;
            });
            
            });
            
            
         </script> 
</div>
</div>

<!-- End Industry modal-->


<!-- Lead Status modal start-->
<!-- Modal Crud Start-->
<div class="modal fade" id="nameModal_status" tabindex="-1" role="dialog" aria-hidden="true" style="display: none;">
<div class="modal-dialog">
   <div class="box box-primary popup" >
      <div class="box-header with-border formsize">
         <h3 class="box-title">Lead Status Form</h3>
         <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
      </div>
      <!-- /.box-header -->
      <div class="modal-body" style="padding: 0px 0px 0px 0px;">
         <form role="form bor-rad" enctype="multipart/form-data"  method="post" id="StatusPopup">
            <div class="box-body">
               <div class="row">
                  <div class="col-md-6">
                     <div class="form-group">
                        <label for="">Status Name</label>
                        <input type="text" name="status_name" value="" id="status_name" class="form-control" placeholder="Name">
                        <span id="status_name-error"></span>
                     </div>
                  </div>
               </div>
               <div class="box-footer sub-btn-wdt">
                  <button type="submit" name="submit" id="StatusAdd" value="add" class="btn btn-success wdt-bg">Add</button>
               </div>

         
         </div>
         </form>        
      </div>
   </div>

         <script type="text/javascript">
            $(function() {
            //twitter bootstrap script
            $("button#StatusAdd").click(function(){
               var status_name = $("#status_name").val();
            if(status_name=="")
            {
               $("#status_name-error").html('Enter Name');
               $("#status_name-error").css({'color':'#f00'});
               return false;
            }
            else{
               
               $("#status_name-error").html();
               $("#status_name-error").css({'color':'#FFF'});
               
            }
            $.ajax({
            type: "POST",
            url: "<?php echo base_url(); ?>lead/LeadStatus/add_edit",
            data: $('form#StatusPopup').serialize(),
            success: function(response){
               $("#status_name").val("");
             responseStatus();
                   
            $("#nameModal_status").modal('hide'); 
            },
            error: function(){
            alert("failure");
            }
            });
            
            return false;
            });
            
            });
            
            
         </script> 
</div>
</div><!--End Modal Crud --> 
<!-- End Lead Status modal-->
<!--End Modal Crud -->



<!-- Lead Rating modal start-->
<!-- Modal Crud Start-->
<div class="modal fade" id="nameModal_rating" tabindex="-1" role="dialog" aria-hidden="true" style="display: none;">
<div class="modal-dialog">
   <div class="box box-primary popup" >
      <div class="box-header with-border formsize">
         <h3 class="box-title">Lead Rating Form</h3>
         <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
      </div>
      <!-- /.box-header -->
      <div class="modal-body" style="padding: 0px 0px 0px 0px;">
         <form role="form bor-rad" enctype="multipart/form-data"  method="post" id="RatingPopup">
            <div class="box-body">
               <div class="row">
                  <div class="col-md-6">
                     <div class="form-group">
                        <label for="">Rating Name</label>
                        <input type="text" name="rating_name" id="rating_name" value="" class="form-control" placeholder="Name">
                        <span id="rating_name-error"></span>
                     </div>
                  </div>
               </div>
               <div class="box-footer sub-btn-wdt">
                  <button type="submit" name="submit" id="RatingAdd" value="add" class="btn btn-success wdt-bg">Add</button>
               </div>

         
         </div>
         </form>        
      </div>
   </div>

         <script type="text/javascript">
            $(function() {
            //twitter bootstrap script
            $("button#RatingAdd").click(function(){
                var rating_name = $("#rating_name").val();
            if(rating_name=="")
            {
               $("#rating_name-error").html('Enter Name');
               $("#rating_name-error").css({'color':'#f00'});
               return false;
            }
            else{
               
               $("#rating_name-error").html();
               $("#rating_name-error").css({'color':'#FFF'});
               
            }
            $.ajax({
            type: "POST",
            url: "<?php echo base_url(); ?>lead/LeadRating/add_edit",
            data: $('form#RatingPopup').serialize(),
            success: function(response){
               $("#rating_name").val("");
             responseRating();
                    
            $("#nameModal_rating").modal('hide'); 
            },
            error: function(){
            alert("failure");
            }
            });
            
            return false;
            });
            
            });
            
            
         </script> 
</div>
</div><!--End Modal Crud --> 
<!-- End Lead Rating modal-->
<!--End Modal Crud -->



<!-- Lead Rating modal start-->
<!-- Modal Crud Start-->
<div class="modal fade" id="nameModal_source" tabindex="-1" role="dialog" aria-hidden="true" style="display: none;">
<div class="modal-dialog">
   <div class="box box-primary popup" >
      <div class="box-header with-border formsize">
         <h3 class="box-title">Lead Source Form</h3>
         <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
      </div>
      <!-- /.box-header -->
      <div class="modal-body" style="padding: 0px 0px 0px 0px;">
         <form role="form bor-rad" enctype="multipart/form-data"  method="post" id="SourcePopup">
            <div class="box-body">
               <div class="row">
                  <div class="col-md-6">
                     <div class="form-group">
                        <label for="">Source Name</label>
                        <input type="text" name="source_name" id="source_name" value="" class="form-control" placeholder="Name">
                        <span id="source_name-error"></span>
                     </div>
                  </div>
               </div>
               <div class="box-footer sub-btn-wdt">
                  <button type="submit" name="submit" id="SourceAdd" value="add" class="btn btn-success wdt-bg">Add</button>
               </div>

         
         </div>
         </form>        
      </div>
   </div>

         <script type="text/javascript">
            $(function() {
            //twitter bootstrap script
            $("button#SourceAdd").click(function(){
                var source_name = $("#source_name").val();
            if(source_name=="")
            {
               $("#source_name-error").html('Enter Name');
               $("#source_name-error").css({'color':'#f00'});
               return false;
            }
            else{
               
               $("#source_name-error").html();
               $("#source_name-error").css({'color':'#FFF'});
               
            }
            $.ajax({
            type: "POST",
            url: "<?php echo base_url(); ?>lead/LeadSource/add_edit",
            data: $('form#SourcePopup').serialize(),
            success: function(response){
               $("#source_name").val("");
             responseSource();
                    
            $("#nameModal_source").modal('hide'); 
            },
            error: function(){
            alert("failure");
            }
            });
            
            return false;
            });
            
            });
            
            
         </script> 
</div>
</div><!--End Modal Crud --> 
<!-- End Lead Rating modal-->
<!--End Modal Crud -->
<script type="text/javascript">
    var base_url = "<?php echo base_url(); ?>";
   
</script>
<script type="text/javascript" src="<?php echo base_url('assets/js/lead.js'); ?>"></script>
