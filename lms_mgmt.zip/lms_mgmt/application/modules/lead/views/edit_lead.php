

<div class="content-wrapper">
   <!-- Content Header (Page header) -->
   <!-- Main content -->
   <section class="content">
      <?php if($this->session->flashdata("messagePr")){?>
      <div class="alert alert-info">      
         <?php echo $this->session->flashdata("messagePr")?>
      </div>
      <?php } ?>
      <div class="page-inner">
         <div class="page-title">
            <h3>Edit Lead Details</h3>
         </div>
         <div id="main-wrapper">
            <form class="form-horizontal" method='POST' action="<?php echo base_url(); ?>lead/updateLead/<?php echo $leadData->lead_id; ?>" id="form_counselor">
               <div class="row">
                  <div class="col-md-12">
                     <div class="panel panel-white">
                        <div class="panel-heading clearfix">
                           <h4 class="panel-title">Lead Information</h4>
                        </div>
                        <div class="panel-body">
                           <div class="row form-group">
                              <div class="col-md-6">
                                 <label for="input-fname" class="col-sm-3 ">First Name</label>
                                 <div class="col-sm-3">
                                    <select class="form-control select2 chosen-select"   name="salutationtype" >
                                       <option value="">None</option>
                                       <option value="Mr."  <?php echo $sel = ($leadData->lead_salutationtype == "Mr.") ? 'selected="selected"' : ''; ?>>Mr.</option>
                                       <option value="Ms." <?php  echo $sel = ($leadData->lead_salutationtype == "Ms.") ? 'selected="selected"' : ''; ?>>Ms.</option>
                                       <option value="Mrs." <?php echo  $sel = ($leadData->lead_salutationtype == "Mrs.") ? 'selected="selected"' : ''; ?>>Mrs.</option>
                                       <option value="Dr." <?php  echo $sel = ($leadData->lead_salutationtype == "Dr.") ? 'selected="selected"' : ''; ?>>Dr.</option>
                                       <option value="Prof." <?php  echo $sel = ($leadData->lead_salutationtype == "Prof.") ? 'selected="selected"' : ''; ?>>Prof.</option>
                                    </select>
                                 </div>
                                 <div class="col-sm-6">
                                    <input type="text" class="form-control" name='fname' id="input-fname" value="<?php echo $leadData->lead_fname; ?>" />
                                 </div>
                              </div>
                              <div class="col-md-6">
                                 <label for="input-lname" class="col-sm-4 ">Last Name</label>
                                 <div class="col-sm-8">
                                    <input type="text" class="form-control" id="input-lname" name='lname' value="<?php echo $leadData->lead_lname; ?>">
                                 </div>
                              </div>
                           </div>
                           <div class="row form-group">
                              <div class="col-md-6">
                                 <label for="input-phone" class="col-sm-4 ">Primary Phone</label>
                                 <div class="col-sm-8">
                                    <input type="text" minlength="10" maxlength="15" class="form-control" value="<?php echo $leadData->lead_phone; ?>" id="input-phone" name='phone'>
                                 </div>
                              </div>
                              <div class="col-md-6">
                                 <label for="input-company" class="col-sm-4 ">Company</label>
                                 <div class="col-sm-8">
                                    <input type="text" class="form-control" id="input-company" name='company' value="<?php echo $leadData->lead_company; ?>">
                                 </div>
                              </div>
                           </div>
                           <div class="row form-group">
                              <div class="col-md-6">
                                 <label for="input-mobile" class="col-sm-4 ">Mobile Phone</label>
                                 <div class="col-sm-8">
                                    <input type="text" class="form-control" id="input-mobile" name='mobile'  value="<?php echo $leadData->lead_mobile; ?>" >
                                 </div>
                              </div>
                              <div class="col-md-6">
                                 <label for="input-designation" class="col-sm-4 ">Designation</label>
                                 <div class="col-sm-8">
                                    <input type="text" class="form-control" id="input-designation" name='designation'  value="<?php echo $leadData->lead_designation; ?>">
                                 </div>
                              </div>
                           </div>
                           <div class="row form-group">
                              <div class="col-md-6">
                                 <label for="input-fax" class="col-sm-4">Fax</label>
                                 <div class="col-sm-8">
                                    <input type="text" class="form-control" id="input-fax" name='fax' value="<?php echo $leadData->lead_fax; ?>">
                                 </div>
                              </div>
                              <div class="col-md-6">
                                 <label for="input-lead_source" class="col-sm-4 ">Lead Source</label>
                                 <div class="col-sm-8">
                                    <select name="lead_source" class="form-control chosen-select"  id="input-lead_source">
                                       <?php $leadSource = getLeadSourceList(); 
                                          foreach ($leadSource as $sourceRow) {?>
                                       <option value="<?php echo $sourceRow->source_id; ?>" <?php  echo $sel = ($leadData->lead_source == $sourceRow->source_id) ? 'selected="selected"' : ''; ?>><?php echo $sourceRow->source_name; ?></option>
                                       <?php } ?>
                                    </select>
                                 </div>
                              </div>
                           </div>
                           <div class="row form-group">
                              <div class="col-md-6">
                                 <label for="input-email" class="col-sm-4 ">Primary Email</label>
                                 <div class="col-sm-8">
                                    <input type="text" class="form-control" id="input-email" name='email' value="<?php echo $leadData->lead_email; ?>">
                                 </div>
                              </div>
                              <div class="col-md-6">
                                 <label for="input-industry" class="col-sm-4 ">Industry</label>
                                 <div class="col-sm-8">
                                    <select name="industry" class="form-control chosen-select"  id="input-industry">
                                       <option value="">Select an Option</option>
                                       <?php $leadIndustry = getLeadIndustryList(); 
                                          foreach ($leadIndustry as $industryRow) {?>
                                       <option value="<?php echo $industryRow->ind_id; ?>" <?php  echo $sel = ($leadData->lead_industry == $industryRow->ind_id) ? 'selected="selected"' : ''; ?>><?php echo $industryRow->industry_name; ?></option>
                                       <?php } ?>
                                    </select>
                                 </div>
                              </div>
                           </div>
                           <div class="row form-group">
                              <div class="col-md-6">
                                 <label for="input-website" class="col-sm-4 ">Website</label>
                                 <div class="col-sm-8">
                                    <input type="text" name="website" class="form-control" id="input-website" value="<?php echo $leadData->lead_website; ?>">
                                 </div>
                              </div>
                              <div class="col-md-6">
                                 <label for="input-revenue" class="col-sm-4 ">Annual Revenue $</label>
                                 <div class="col-sm-8">
                                    <input type="text" class="form-control" id="input-revenue" name='revenue' value="<?php echo $leadData->lead_anrevenue; ?>">
                                 </div>
                              </div>
                           </div>
                           <div class="row form-group">
                              <div class="col-md-6">
                                 <label for="input-leadstatus" class="col-sm-4 ">Lead Status</label>
                                 <div class="col-sm-8">
                                    <select class="form-control chosen-select"   name="lead_status" id="input-leadstatus" >
                                       <option value="">Select an Option</option>
                                       <?php $statusList = getStatusList(); 
                                          foreach ($statusList as $row) { ?>
                                       <option value="<?php echo $row->status_id; ?>" <?php  echo $sel = ($leadData->leads_status == $row->status_id) ? 'selected="selected"' : ''; ?>><?php echo $row->status_name; ?></option>
                                       <?php } ?>
                                    </select>
                                 </div>
                              </div>
                              <div class="col-md-6">
                                 <label for="input-noemployee" class="col-sm-4 ">Number of Employees</label>
                                 <div class="col-sm-8">
                                    <input type="text" class="form-control" id="input-noemployee" name='noemployee' value="<?php echo $leadData->lead_emp_no; ?>">
                                 </div>
                              </div>
                           </div>
                           <div class="row form-group">
                              <div class="col-md-6">
                                 <label for="input-rating" class="col-sm-4 ">Rating</label>
                                 <div class="col-sm-8">
                                    <select class="form-control chosen-select"   name="rating" id="input-rating" >
                                       <option value="">Select an Option</option>
                                       <?php $ratingList = getLeadRatingList(); 
                                          foreach ($ratingList as $ratingRow) {?>
                                       <option value="<?php echo $ratingRow->rating_id; ?>" <?php  echo $sel = ($leadData->lead_rating == $ratingRow->rating_id) ? 'selected="selected"' : ''; ?>><?php echo $ratingRow->rating_name; ?></option>
                                       <?php } ?>
                                    </select>
                                 </div>
                              </div>
                              <div class="col-md-6">
                                 <label for="input-semail" class="col-sm-4 ">Secondary Email</label>
                                 <div class="col-sm-8">
                                    <input type="text" class="form-control" id="input-semail" name='second_email' value="<?php echo $leadData->lead_second_email; ?>">
                                 </div>
                              </div>
                           </div>
                           <div class="row form-group">
                              <div class="col-md-6">
                                 <label for="input-assigned" class="col-sm-4 ">Assigned To</label>
                                 <div class="col-sm-8">
                                    <select class="form-control chosen-select"   name="assigned" id="input-assigned" >
                                       <optgroup label="Users">
                                        <?php $users = getAllDataByTable('users','*','user_id,name,user_type'); 
                                       foreach ($users as $ukey => $uvalue) {
                                          if($uvalue->user_type!="admin")
                                          {
                                       ?>
                                       <option value="<?php echo $uvalue->users_id; ?>"
 <?php  echo $sel = ($leadData->lead_assigned_to == $uvalue->users_id) ? 'selected="selected"' : ''; ?>
                                       ><?php echo $uvalue->name; ?></option>

                                       <?php 
                                          }
                                       } ?>
                                         
                                       </optgroup>
                                     <!--  <optgroup label="Groups">
                                          <option data-recordaccess="true" data-picklistvalue="Marketing Group" value="3" <?php  echo $sel = ($leadData->lead_assigned_to == "3") ? 'selected="selected"' : ''; ?>>Marketing Group</option>
                                          <option data-recordaccess="true" data-picklistvalue="Support Group" value="4"  <?php  echo $sel = ($leadData->lead_assigned_to == "4") ? 'selected="selected"' : ''; ?>>Support Group</option>
                                          <option data-recordaccess="true" data-picklistvalue="Team Selling" value="2" <?php  echo $sel = ($leadData->lead_assigned_to == "2") ? 'selected="selected"' : ''; ?>>Team Selling</option>
                                       </optgroup>-->
                                    </select>
                                 </div>
                              </div>
                              <div class="col-md-6">
                                 <label for="input-emailoptout" class="col-sm-4 ">Email Opt Out</label>
                                 <div class="col-sm-8">                
                                    <input type="checkbox"name="emailoptout" id="input-emailoptout" value="1" <?php  echo $sel = ($leadData->lead_optout == "1") ? 'checked="checked"' : ''; ?> >
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <!-- Second part  -->
                  <div class="col-md-12">
                     <div class="panel panel-white">
                        <div class="panel-heading clearfix">
                           <h4 class="panel-title">Address Details</h4>
                        </div>
                        <div class="panel-body">
                           <div class="col-md-12">
                              <div class="row form-group">
                                 <div class="col-md-6">
                                    <label for="input-street" class="col-sm-4 ">Street</label>
                                    <div class="col-sm-8">
                                       <textarea  class="form-control" id="input-street" name='street'><?php echo $leadData->lead_street; ?></textarea>
                                    </div>
                                 </div>
                                 <div class="col-md-6">
                                    <label for="input-pobox" class="col-sm-4 ">PO Box</label>
                                    <div class="col-sm-8">
                                       <input type="text"  class="form-control" id="input-pobox" name='pobox' value="<?php echo $leadData->lead_pobox; ?>">
                                    </div>
                                 </div>
                              </div>
                              <div class="row form-group">
                                 <div class="col-md-6">
                                    <label for="input-postal_code" class="col-sm-4 ">  Postal Code</label>
                                    <div class="col-sm-8">
                                       <input type="text"   class="form-control" id="input-postal_code" name='postal_code' value="<?php echo $leadData->lead_postal_code; ?>" />
                                    </div>
                                 </div>
                                 <div class="col-md-6">
                                    <label for="input-city" class="col-sm-4 ">  City</label>
                                    <div class="col-sm-8">
                                       <input type="text"   class="form-control" id="input-city" name='city' value="<?php echo $leadData->lead_city; ?>" />
                                    </div>
                                 </div>
                              </div>
                              <div class="row form-group">
                                 <div class="col-md-6">
                                    <label for="input-country" class="col-sm-4 ">  Country</label>
                                    <div class="col-sm-8">
                                       <input type="text"   class="form-control" id="input-country" name='country' value="<?php echo $leadData->lead_country; ?>"  />
                                    </div>
                                 </div>
                                 <div class="col-md-6">
                                    <label for="input-state" class="col-sm-4 ">  State</label>
                                    <div class="col-sm-8">
                                       <input type="text"   class="form-control" id="input-state" name='state' value="<?php echo $leadData->lead_state; ?>"  />
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <!-- panel body -->
                     </div>
                  </div>
                  <!-- col md 6 -->
                  <div class="col-md-12">
                     <div class="panel panel-white">
                        <div class="panel-heading clearfix">
                           <h4 class="panel-title">Description Details</h4>
                        </div>
                        <div class="panel-body">
                           <div class="col-md-12">
                              <div class="form-group">
                                 <label for="input-description" class="col-sm-4 ">Description</label>
                                 <div class="col-sm-10">
                                    <textarea class="form-control" id="input-description" name='description'><?php echo $leadData->lead_description; ?></textarea>
                                 </div>
                              </div>
                              <input class="btn btn-success" type="submit" value='Submit' name='submit_add_counselor'/>
                              <input class="btn btn-success" type="reset" value='Reset' name='Reset_button'/>
                           </div>
                        </div>
                        <!-- panel body -->
                     </div>
                  </div>
                  <!-- col md 12 -->
               </div>
               <!-- Row -->
            </form>
         </div>
         <!-- Main Wrapper -->
      </div>
   </section>
</div>
<script type="text/javascript">
   /*   Industry dropdown replace */
       function responseIndustry()
       {
             $('#input-industry').find('option').remove().end();
               $('#input-industry').append('<option value>Select</option>');
               $.ajax({
                   url: "<?php echo base_url(); ?>lead/Industry/getIndustryList",
                   type: 'GET',
                   success: function (content) {
                       var industry = jQuery.parseJSON(content);
                       console.log(industry);
                       $.each(industry, function (key, value) {
                           $('#input-industry').append('<option value=' + value.ind_id + '>' + value.industry_name + '</option>').trigger("chosen:updated");
                         
                       });
                   }
               });
        
       }
       /*   Industry dropdown replace end */
   
       /*   Lead Status dropdown replace */
       function responseStatus()
       {
           $('#input-leadstatus').find('option').remove().end();
               $('#input-leadstatus').append('<option value>Select</option>');
               $.ajax({
                   url: "<?php echo base_url(); ?>lead/LeadStatus/getStatusList",
                   type: 'GET',
                   success: function (content) {
                       var statusdata = jQuery.parseJSON(content);
                       console.log(statusdata);
                       $.each(statusdata, function (key, value) {
                           $('#input-leadstatus').append('<option value=' + value.status_id + '>' + value.status_name + '</option>').trigger("chosen:updated");
                         
                       });
                   }
               });
       }
       /*   Lead Status dropdown end */
       /*   Lead Rating dropdown replace */
       function responseRating()
       {
           $('#input-rating').find('option').remove().end();
               $('#input-rating').append('<option value>Select</option>');
               $.ajax({
                   url: "<?php echo base_url(); ?>lead/LeadRating/getRatingList",
                   type: 'GET',
                   success: function (content) {
                       var ratingdata = jQuery.parseJSON(content);
                       console.log(ratingdata);
                       $.each(ratingdata, function (key, value) {
                           $('#input-rating').append('<option value=' + value.rating_id + '>' + value.rating_name + '</option>').trigger("chosen:updated");
                         
                       });
                   }
               });
       }
       /*   Lead Rating dropdown end */
   
       
</script>
<!-- Modal Crud Start-->
<!-- Industry modal start-->
<div class="modal fade" id="nameModal_industry" tabindex="-1" role="dialog" aria-hidden="true" style="display: none;">
   <div class="modal-dialog">
      <div class="box box-primary popup" >
         <div class="box-header with-border formsize">
            <h3 class="box-title">Industry Form</h3>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
         </div>
         <!-- /.box-header -->
         <div class="modal-body" style="padding: 0px 0px 0px 0px;">
            <form role="form bor-rad" enctype="multipart/form-data"  method="post" id="IndustryPopup">
               <div class="box-body">
                  <div class="row">
                     <div class="col-md-6">
                        <div class="form-group">
                           <label for="">Name</label>
                           <input type="text" name="industry_name" id="industry_name" value="<?php echo isset($userData->name)?$userData->name:'';?>" class="form-control" placeholder="Name">
                        </div>
                     </div>
                  </div>
                  <div class="box-footer sub-btn-wdt">
                     <button type="submit" name="submit" id="IndustryAdd" value="add" class="btn btn-success wdt-bg">Add</button>
                  </div>
               </div>
            </form>
         </div>
      </div>
      <script type="text/javascript">
         $(function() {
         //twitter bootstrap script
         $("button#IndustryAdd").click(function(){
         $.ajax({
         type: "POST",
         url: "<?php echo base_url(); ?>lead/Industry/add_edit",
         data: $('form#IndustryPopup').serialize(),
         success: function(response){
            
            $("#industry_name").val("");
          responseIndustry();
                
         $("#nameModal_industry").modal('hide'); 
         },
         error: function(){
         alert("failure");
         }
         });
         
         return false;
         });
         
         });
         
         
      </script> 
   </div>
</div>
<!-- End Industry modal-->
<!-- Lead Status modal start-->
<!-- Modal Crud Start-->
<div class="modal fade" id="nameModal_status" tabindex="-1" role="dialog" aria-hidden="true" style="display: none;">
   <div class="modal-dialog">
      <div class="box box-primary popup" >
         <div class="box-header with-border formsize">
            <h3 class="box-title">Lead Status Form</h3>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
         </div>
         <!-- /.box-header -->
         <div class="modal-body" style="padding: 0px 0px 0px 0px;">
            <form role="form bor-rad" enctype="multipart/form-data"  method="post" id="StatusPopup">
               <div class="box-body">
                  <div class="row">
                     <div class="col-md-6">
                        <div class="form-group">
                           <label for="">Status Name</label>
                           <input type="text" name="status_name" value="" id="status_name" class="form-control" placeholder="Name">
                        </div>
                     </div>
                  </div>
                  <div class="box-footer sub-btn-wdt">
                     <button type="submit" name="submit" id="StatusAdd" value="add" class="btn btn-success wdt-bg">Add</button>
                  </div>
               </div>
            </form>
         </div>
      </div>
      <script type="text/javascript">
         $(function() {
         //twitter bootstrap script
         $("button#StatusAdd").click(function(){
         $.ajax({
         type: "POST",
         url: "<?php echo base_url(); ?>lead/LeadStatus/add_edit",
         data: $('form#StatusPopup').serialize(),
         success: function(response){
            $("#status_name").val("");
          responseStatus();
                
         $("#nameModal_status").modal('hide'); 
         },
         error: function(){
         alert("failure");
         }
         });
         
         return false;
         });
         
         });
         
         
      </script> 
   </div>
</div>
<!--End Modal Crud --> 
<!-- End Lead Status modal-->
<!--End Modal Crud -->
<!-- Lead Rating modal start-->
<!-- Modal Crud Start-->
<div class="modal fade" id="nameModal_rating" tabindex="-1" role="dialog" aria-hidden="true" style="display: none;">
   <div class="modal-dialog">
      <div class="box box-primary popup" >
         <div class="box-header with-border formsize">
            <h3 class="box-title">Lead Rating Form</h3>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
         </div>
         <!-- /.box-header -->
         <div class="modal-body" style="padding: 0px 0px 0px 0px;">
            <form role="form bor-rad" enctype="multipart/form-data"  method="post" id="RatingPopup">
               <div class="box-body">
                  <div class="row">
                     <div class="col-md-6">
                        <div class="form-group">
                           <label for="">Rating Name</label>
                           <input type="text" name="rating_name" id="rating_name" value="" class="form-control" placeholder="Name">
                        </div>
                     </div>
                  </div>
                  <div class="box-footer sub-btn-wdt">
                     <button type="submit" name="submit" id="RatingAdd" value="add" class="btn btn-success wdt-bg">Add</button>
                  </div>
               </div>
            </form>
         </div>
      </div>
      <script type="text/javascript">
         $(function() {
         //twitter bootstrap script
         $("button#RatingAdd").click(function(){
         $.ajax({
         type: "POST",
         url: "<?php echo base_url(); ?>lead/LeadRating/add_edit",
         data: $('form#RatingPopup').serialize(),
         success: function(response){
            $("#rating_name").val("");
          responseRating();
                 
         $("#nameModal_rating").modal('hide'); 
         },
         error: function(){
         alert("failure");
         }
         });
         
         return false;
         });
         
         });
         
         
      </script> 
   </div>
</div>
<!--End Modal Crud --> 
<!-- End Lead Rating modal-->
<!--End Modal Crud -->

