<?php defined("BASEPATH") OR exit("No direct script access allowed");

class LeadSource extends CI_Controller {

  function __construct() {
    parent::__construct();
     //Checking user is login or not 
      is_login();
    $this->load->model('Lead_source_model');
  }

  /**
     * This function is used to load page view
     * @return Void
     */
  public function index(){   
	  $this->load->view("include/header");
    $this->load->view("source/index");
    $this->load->view("include/footer");
  }

  /**
  * this function is load add source view
  * return void
  */
  public function Create()
  {
    $this->load->view("include/header");
    $this->load->view("source/create");
    $this->load->view("include/footer");
  }

  /**
  ** Create Lead data function 
  ** add all form data into database
  **/
  public function createSource()
  {
    

    $data = array("source_name"=>$_POST['source_name']);
      $this->Lead_source_model->insert($data);
      $this->session->set_flashdata('messagePr', 'Your lead source added Successfully..');
      redirect(base_url('lead/LeadSource'));
  }

  
    /**
     * This function is used to create datatable in lead  source management list page
     * @return Void
     */
    public function dataTable (){
        is_login();
      $table = 'lead_source';
      $primaryKey = 'source_id';
      $columns = array(
           array( 'db' => 'source_id', 'dt' => 0 ),           
           array( 'db' => 'source_name', 'dt' => 1 ),
           array( 'db' => 'source_id', 'dt' => 2 )
          
    );

        $sql_details = array(
      'user' => $this->db->username,
      'pass' => $this->db->password,
      'db'   => $this->db->database,
      'host' => $this->db->hostname
    );
   // $where = array("user_type != 'admin'");
    $output_arr = SSP::complex( $_GET, $sql_details, $table, $primaryKey, $columns);
    foreach ($output_arr['data'] as $key => $value) {
      $id = $output_arr['data'][$key][count($output_arr['data'][$key])  - 1];
      $output_arr['data'][$key][count($output_arr['data'][$key])  - 1] = '';
      if(CheckPermission($table, "all_update")){
      $output_arr['data'][$key][count($output_arr['data'][$key])  - 1] .= '<a id="btnEditRow"  href="'.base_url().'lead/LeadSource/editsource/'.$id.'" data-src="'.$id.'"  data-src="'.$id.'" title="Edit"><i class="fa fa-pencil" data-id=""></i></a>';
      }else if(CheckPermission($table, "own_update") && (CheckPermission($table, "all_update")!=true)){
        $user_id =getRowByTableColomId($table,$id,'source_id');
        
      $output_arr['data'][$key][count($output_arr['data'][$key])  - 1] .= '<a id="btnEditRow"  href="'.base_url().'lead/LeadSource/editsource/'.$id.'"  data-src="'.$id.'" title="Edit"><i class="fa fa-pencil" data-id=""></i></a>';
        
      }
      
      if(CheckPermission($table, "all_delete")){
      $output_arr['data'][$key][count($output_arr['data'][$key])  - 1] .= '<a style="cursor:pointer;" data-toggle="modal" class="mClass" onclick="setId('.$id.', \'lead/LeadSource\')" data-target="#cnfrm_delete" title="delete"><i class="fa fa-trash-o" ></i></a>';}
      else if(CheckPermission($table, "own_delete") && (CheckPermission($table, "all_delete")!=true)){
        $user_id =getRowByTableColomId($table,$id,'source_id');
        
      $output_arr['data'][$key][count($output_arr['data'][$key])  - 1] .= '<a style="cursor:pointer;" data-toggle="modal" class="mClass" onclick="setId('.$id.', \'lead/LeadSource\')" data-target="#cnfrm_delete" title="delete"><i class="fa fa-trash-o" ></i></a>';
        
      }
            $output_arr['data'][$key][0] = '<input type="checkbox" name="selData" value="'.$output_arr['data'][$key][0].'">';
    }
    echo json_encode($output_arr);
    }

     /**
     * This function is used to delete Lead source
     * @return Void
     */
    public function delete($id){
        is_login(); 
        $ids = explode('-', $id);
        foreach ($ids as $id) {
            $this->Lead_source_model->delete($id); 
        }
       redirect(base_url().'lead/LeadSource', 'refresh');
    }


    /**
    * This function is load edit source view
    * return @void
    */
    public function editsource($id='')
    {
        is_login();
        $source_id = $id;
        $data['sourceData'] = $this->Lead_source_model->get($source_id);
         $this->load->view("include/header");
         $this->load->view("source/editsource",$data);
         $this->load->view("include/footer");
    }

    /**
    * This function is update source data
    * @param int $id     
    */
    public function updateSource($id='')
    {
       $data = array("source_name"=>$_POST['source_name']);

      $this->Lead_source_model->update($id,$data);
      $this->session->set_flashdata('messagePr', 'Your Lead Source updated Successfully..');
      redirect(base_url('lead/LeadSource'));
    }

      /**
      * this function called through ajax for add source
      */
      function add_edit(){      
      if(!empty($_POST['source_name']))
      {
        $data = array("source_name"=>strip_tags($_POST['source_name']));
        $source_id = $this->Lead_source_model->insert($data);
        $res = $this->Lead_source_model->get($source_id);
        $arrayName = array('source_id' =>$res->source_id , 'source_name' =>$res->source_name );
        echo json_encode($arrayName);
      }
        
    }

   /**
    * return source list
    */
    function getSourceList()
    {
      $source_list = $this->Lead_source_model->get_all();
      echo json_encode($source_list);
    }

}
?>