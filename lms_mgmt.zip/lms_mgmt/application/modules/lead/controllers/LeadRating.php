<?php defined("BASEPATH") OR exit("No direct script access allowed");

class LeadRating extends CI_Controller {

  function __construct() {

    parent::__construct();
     //Checking user is login or not 
      is_login();
    $this->load->model('Lead_Rating_model');
  }

  /**
     * This function is used to load page view
     * @return Void
     */
  public function index(){   
	  $this->load->view("include/header");
    $this->load->view("rating/index");
    $this->load->view("include/footer");
  }

  public function Create()
  {
    $this->load->view("include/header");
    $this->load->view("rating/create");
    $this->load->view("include/footer");
  }

  /**
  ** Create Rating function 
  ** add all form data into database
  **/
  public function createRating()
  {
    

    $data = array("rating_name"=>$_POST['rating_name']);
      $this->Lead_Rating_model->insert($data);
      $this->session->set_flashdata('messagePr', 'Your Rating added Successfully..');
      redirect(base_url('lead/LeadRating'));
  }

  
    /**
     * This function is used to create datatable in  rating management list page
     * @return Void
     */
    public function dataTable (){
        is_login();
      $table = 'lead_rating';
      $primaryKey = 'rating_id';
      $columns = array(
           array( 'db' => 'rating_id', 'dt' => 0 ),           
           array( 'db' => 'rating_name', 'dt' => 1 ),
           array( 'db' => 'rating_id', 'dt' => 2 )
          
    );

        $sql_details = array(
      'user' => $this->db->username,
      'pass' => $this->db->password,
      'db'   => $this->db->database,
      'host' => $this->db->hostname
    );
   // $where = array("user_type != 'admin'");
    $output_arr = SSP::complex( $_GET, $sql_details, $table, $primaryKey, $columns);
    foreach ($output_arr['data'] as $key => $value) {
      $id = $output_arr['data'][$key][count($output_arr['data'][$key])  - 1];
      $output_arr['data'][$key][count($output_arr['data'][$key])  - 1] = '';
      if(CheckPermission($table, "all_update")){
      $output_arr['data'][$key][count($output_arr['data'][$key])  - 1] .= '<a id="btnEditRow"  href="'.base_url().'lead/LeadRating/editRating/'.$id.'" data-src="'.$id.'"  data-src="'.$id.'" title="Edit"><i class="fa fa-pencil" data-id=""></i></a>';
      }else if(CheckPermission($table, "own_update") && (CheckPermission($table, "all_update")!=true)){
        $user_id =getRowByTableColomId($table,$id,'rating_id');
        
      $output_arr['data'][$key][count($output_arr['data'][$key])  - 1] .= '<a id="btnEditRow"  href="'.base_url().'lead/LeadRating/editRating/'.$id.'"  data-src="'.$id.'" title="Edit"><i class="fa fa-pencil" data-id=""></i></a>';
        
      }
      
      if(CheckPermission($table, "all_delete")){
      $output_arr['data'][$key][count($output_arr['data'][$key])  - 1] .= '<a style="cursor:pointer;" data-toggle="modal" class="mClass" onclick="setId('.$id.', \'lead/LeadRating\')" data-target="#cnfrm_delete" title="delete"><i class="fa fa-trash-o" ></i></a>';}
      else if(CheckPermission($table, "own_delete") && (CheckPermission($table, "all_delete")!=true)){
        $user_id =getRowByTableColomId($table,$id,'rating_id');
        
      $output_arr['data'][$key][count($output_arr['data'][$key])  - 1] .= '<a style="cursor:pointer;" data-toggle="modal" class="mClass" onclick="setId('.$id.', \'lead/LeadRating\')" data-target="#cnfrm_delete" title="delete"><i class="fa fa-trash-o" ></i></a>';
        
      }
            $output_arr['data'][$key][0] = '<input type="checkbox" name="selData" value="'.$output_arr['data'][$key][0].'">';
    }
    echo json_encode($output_arr);
    }

     /**
     * This function is used to delete Rating
     * @return Void
     */
    public function delete($id){
        is_login(); 
        $ids = explode('-', $id);
        foreach ($ids as $id) {
            $this->Lead_Rating_model->delete($id); 
        }
       redirect(base_url().'lead/LeadRating', 'refresh');
    }


    /**
    * load edit rating view
    */
    public function editRating($id='')
    {
        is_login();
        $ind_id = $id;
        $data['ratingData'] = $this->Lead_Rating_model->get($ind_id);
         $this->load->view("include/header");
         $this->load->view("rating/editrating",$data);
         $this->load->view("include/footer");
    }


    /**
    * Update Rating data
    */
    public function updateRating($rating_id='')
    {
        $data = array("rating_name"=>$_POST['rating_name']);

      $this->Lead_Rating_model->update($rating_id,$data);
      
      $this->session->set_flashdata('messagePr', 'Your Rating data updated Successfully..');
      redirect(base_url('lead/LeadRating'));
    }

     function add_edit(){      
      if(!empty($_POST['rating_name']))
      {
        $data = array("rating_name"=>strip_tags($_POST['rating_name']));
        $status_id = $this->Lead_Rating_model->insert($data);
        $res = $this->Lead_Rating_model->get($status_id);
        $arrayName = array('rating_id' =>$res->rating_id , 'rating_name' =>$res->rating_name );
        echo json_encode($arrayName);
      }
        
    }

   /**
    * return rating list
    */
    function getRatingList()
    {
      $rating_list = $this->Lead_Rating_model->get_all();
      echo json_encode($rating_list);
    }
}
?>