<?php defined("BASEPATH") OR exit("No direct script access allowed");

class Industry extends CI_Controller {

  function __construct() {
    parent::__construct();
     //Checking user is login or not 
      is_login();
    $this->load->model('Industry_model');
  }

  /**
     * This function is used to load page view
     * @return Void
     */
  public function index(){   
	  $this->load->view("include/header");
    $this->load->view("industry/index");
    $this->load->view("include/footer");
  }

  public function Create()
  {
    $this->load->view("include/header");
    $this->load->view("industry/create");
    $this->load->view("include/footer");
  }

  /**
  ** Create industry function 
  ** add all form data into database
  **/
  public function createIndustry()
  {
    

    $data = array("industry_name"=>$_POST['industry_name']);
      $this->Industry_model->insert($data);
      $this->session->set_flashdata('messagePr', 'Your Industry added Successfully..');
      redirect(base_url('lead/Industry'));
  }

  
    /**
     * This function is used to create datatable in  Industry management list page
     * @return Void
     */
    public function dataTable (){
        is_login();
      $table = 'industry';
      $primaryKey = 'ind_id';
      $columns = array(
           array( 'db' => 'ind_id', 'dt' => 0 ),           
           array( 'db' => 'industry_name', 'dt' => 1 ),
           array( 'db' => 'ind_id', 'dt' => 2 )
          
    );

        $sql_details = array(
      'user' => $this->db->username,
      'pass' => $this->db->password,
      'db'   => $this->db->database,
      'host' => $this->db->hostname
    );
   // $where = array("user_type != 'admin'");
    $output_arr = SSP::complex( $_GET, $sql_details, $table, $primaryKey, $columns);
    foreach ($output_arr['data'] as $key => $value) {
      $id = $output_arr['data'][$key][count($output_arr['data'][$key])  - 1];
      $output_arr['data'][$key][count($output_arr['data'][$key])  - 1] = '';
      if(CheckPermission($table, "all_update")){
      $output_arr['data'][$key][count($output_arr['data'][$key])  - 1] .= '<a id="btnEditRow"  href="'.base_url().'lead/Industry/editindustry/'.$id.'" data-src="'.$id.'"  data-src="'.$id.'" title="Edit"><i class="fa fa-pencil" data-id=""></i></a>';
      }else if(CheckPermission($table, "own_update") && (CheckPermission($table, "all_update")!=true)){
        $user_id =getRowByTableColomId($table,$id,'ind_id');
        
      $output_arr['data'][$key][count($output_arr['data'][$key])  - 1] .= '<a id="btnEditRow"  href="'.base_url().'lead/Industry/editindustry/'.$id.'"  data-src="'.$id.'" title="Edit"><i class="fa fa-pencil" data-id=""></i></a>';
        
      }
      
      if(CheckPermission($table, "all_delete")){
      $output_arr['data'][$key][count($output_arr['data'][$key])  - 1] .= '<a style="cursor:pointer;" data-toggle="modal" class="mClass" onclick="setId('.$id.', \'lead/Industry\')" data-target="#cnfrm_delete" title="delete"><i class="fa fa-trash-o" ></i></a>';}
      else if(CheckPermission($table, "own_delete") && (CheckPermission($table, "all_delete")!=true)){
        $user_id =getRowByTableColomId($table,$id,'ind_id');
        
      $output_arr['data'][$key][count($output_arr['data'][$key])  - 1] .= '<a style="cursor:pointer;" data-toggle="modal" class="mClass" onclick="setId('.$id.', \'lead/Industry\')" data-target="#cnfrm_delete" title="delete"><i class="fa fa-trash-o" ></i></a>';
        
      }
            $output_arr['data'][$key][0] = '<input type="checkbox" name="selData" value="'.$output_arr['data'][$key][0].'">';
    }
    echo json_encode($output_arr);
    }

     /**
     * This function is used to delete Industry
     * @return Void
     */
    public function delete($id){
        is_login(); 
        $ids = explode('-', $id);
        foreach ($ids as $id) {
            $this->Industry_model->delete($id); 
        }
       redirect(base_url().'lead/Industry', 'refresh');
    }



    public function editindustry($id='')
    {
        is_login();
        $ind_id = $id;
        $data['IndustryData'] = $this->Industry_model->get($ind_id);
         $this->load->view("include/header");
         $this->load->view("industry/editindustry",$data);
         $this->load->view("include/footer");
    }

    public function updateIndustry($id='')
    {
        $data = array("industry_name"=>$_POST['industry_name']);

      $this->Industry_model->update($id,$data);
      $this->session->set_flashdata('messagePr', 'Your Industry data updated Successfully..');
      redirect(base_url('lead/Industry'));
    }

     /**
     * This function is used to show popup of industry to add and update
     * @return Void
     */
    public function get_modal() {
        is_login();
        if($this->input->post('id')){
            $data['userData'] = getDataByid('industry',$this->input->post('id'),'ind_id'); 
            echo $this->load->view('lead/industry/add_edit_modal', $data, true);
        } else {
            echo $this->load->view('lead/industry/add_edit_modal', '', true);
        }
        exit;
    }

    function add_edit(){      
        $data = array("industry_name"=>strip_tags($_POST['industry_name']));
        $ind_id = $this->Industry_model->insert($data);
        $res = $this->Industry_model->get($ind_id);
        $arrayName = array('ind_id' =>$res->ind_id , 'industry_name' =>$res->industry_name );
        echo json_encode($arrayName);

        
    }

    function getIndustryList()
    {
      $industry_list = $this->Industry_model->get_all();
      echo json_encode($industry_list);
    }

}
?>