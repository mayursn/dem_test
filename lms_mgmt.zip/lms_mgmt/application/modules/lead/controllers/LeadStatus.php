<?php defined("BASEPATH") OR exit("No direct script access allowed");

class LeadStatus extends CI_Controller {

  function __construct() {
    parent::__construct();
     //Checking user is login or not 
      is_login();
    $this->load->model('Lead_status_model');
  }

  /**
     * This function is used to load page view
     * @return Void
     */
  public function index(){   
	$this->load->view("include/header");
    $this->load->view("status/index");
    $this->load->view("include/footer");
  }

  public function Create()
  {
    $this->load->view("include/header");
    $this->load->view("status/create");
    $this->load->view("include/footer");
  }

  /**
  ** Create Lead data function 
  ** add all form data into database
  **/
  public function createStatus()
  {
    

    $data = array("status_name"=>$_POST['status_name']);
      $this->Lead_status_model->insert($data);
      $this->session->set_flashdata('messagePr', 'Your lead status added Successfully..');
      redirect(base_url('lead/LeadStatus'));
  }

  
    /**
     * This function is used to create datatable in lead management list page
     * @return Void
     */
    public function dataTable (){
        is_login();
      $table = 'lead_status';
      $primaryKey = 'status_id';
      $columns = array(
           array( 'db' => 'status_id', 'dt' => 0 ),           
           array( 'db' => 'status_name', 'dt' => 1 ),
           array( 'db' => 'status_id', 'dt' => 2 )
          
    );

        $sql_details = array(
      'user' => $this->db->username,
      'pass' => $this->db->password,
      'db'   => $this->db->database,
      'host' => $this->db->hostname
    );
   // $where = array("user_type != 'admin'");
    $output_arr = SSP::complex( $_GET, $sql_details, $table, $primaryKey, $columns);
    foreach ($output_arr['data'] as $key => $value) {
      $id = $output_arr['data'][$key][count($output_arr['data'][$key])  - 1];
      $output_arr['data'][$key][count($output_arr['data'][$key])  - 1] = '';
      if(CheckPermission($table, "all_update")){
      $output_arr['data'][$key][count($output_arr['data'][$key])  - 1] .= '<a id="btnEditRow"  href="'.base_url().'lead/LeadStatus/editstatus/'.$id.'" data-src="'.$id.'"  data-src="'.$id.'" title="Edit"><i class="fa fa-pencil" data-id=""></i></a>';
      }else if(CheckPermission($table, "own_update") && (CheckPermission($table, "all_update")!=true)){
        $user_id =getRowByTableColomId($table,$id,'status_id');
        
      $output_arr['data'][$key][count($output_arr['data'][$key])  - 1] .= '<a id="btnEditRow"  href="'.base_url().'lead/LeadStatus/editstatus/'.$id.'"  data-src="'.$id.'" title="Edit"><i class="fa fa-pencil" data-id=""></i></a>';
        
      }
      
      if(CheckPermission($table, "all_delete")){
      $output_arr['data'][$key][count($output_arr['data'][$key])  - 1] .= '<a style="cursor:pointer;" data-toggle="modal" class="mClass" onclick="setId('.$id.', \'lead/LeadStatus\')" data-target="#cnfrm_delete" title="delete"><i class="fa fa-trash-o" ></i></a>';}
      else if(CheckPermission($table, "own_delete") && (CheckPermission($table, "all_delete")!=true)){
        $user_id =getRowByTableColomId($table,$id,'status_id');
        
      $output_arr['data'][$key][count($output_arr['data'][$key])  - 1] .= '<a style="cursor:pointer;" data-toggle="modal" class="mClass" onclick="setId('.$id.', \'lead/LeadStatus\')" data-target="#cnfrm_delete" title="delete"><i class="fa fa-trash-o" ></i></a>';
        
      }
            $output_arr['data'][$key][0] = '<input type="checkbox" name="selData" value="'.$output_arr['data'][$key][0].'">';
    }
    echo json_encode($output_arr);
    }

     /**
     * This function is used to delete users
     * @return Void
     */
    public function delete($id){
        is_login(); 
        $ids = explode('-', $id);
        foreach ($ids as $id) {
            $this->Lead_status_model->delete($id); 
        }
       redirect(base_url().'lead/LeadStatus', 'refresh');
    }



    public function editstatus($id='')
    {
        is_login();
        $status_id = $id;
        $data['statusData'] = $this->Lead_status_model->get($status_id);
         $this->load->view("include/header");
         $this->load->view("status/editstatus",$data);
         $this->load->view("include/footer");
    }

    public function updateStatus($id='')
    {
        $data = array("status_name"=>$_POST['status_name']);

      $this->Lead_status_model->update($id,$data);
      $this->session->set_flashdata('messagePr', 'Your lead status updated Successfully..');
      redirect(base_url('lead/LeadStatus'));
    }

      /**
     * This function is used to show popup of industry to add and update
     * @return Void
     */
    public function get_modal() {
        is_login();
        if($this->input->post('id')){
            $data['userData'] = getDataByid('lead_status',$this->input->post('id'),'status_id'); 
            echo $this->load->view('lead/status/add_edit_modal', $data, true);
        } else {
            echo $this->load->view('lead/status/add_edit_modal', '', true);
        }
        exit;
    }


    /**
    * insert record from lead form modal 
    */
    function add_edit(){      
        $data = array("status_name"=>strip_tags($_POST['status_name']));
        $status_id = $this->Lead_status_model->insert($data);
        $res = $this->Lead_status_model->get($status_id);
        $arrayName = array('status_id' =>$res->status_id , 'status_name' =>$res->status_name );
        echo json_encode($arrayName);

        
    }

    /**
    * return status list
    */
    function getStatusList()
    {
      $status_list = $this->Lead_status_model->get_all();
      echo json_encode($status_list);
    }

}
?>