<?php defined("BASEPATH") OR exit("No direct script access allowed");

class Lead extends CI_Controller {

  function __construct() {
    parent::__construct();
     //Checking user is login or not 
      is_login();
    $this->load->model('Lead_mgmt_model');
  }

  /**
     * This function is used to load page view
     * @return Void
     */
  public function index(){   
	$this->load->view("include/header");
    $this->load->view("index");
    $this->load->view("include/footer");
  }

  public function addlead()
  {
    if($_POST){
      $this->form_validation->set_rules('fname', 'first name', 'required|alpha');
     $this->form_validation->set_rules('lname', 'last name', 'required|alpha');     
     $this->form_validation->set_rules('phone', 'Phone', 'required');
     $this->form_validation->set_rules('company', 'Company', 'required');
     $this->form_validation->set_rules('mobile', 'Mobile', 'required');
     $this->form_validation->set_rules('designation', 'designation', 'required');
     $this->form_validation->set_rules('fax', 'Fax', 'required');
     $this->form_validation->set_rules('lead_source', 'Lead Source', 'required');
     $this->form_validation->set_rules('email', 'email', 'required|valid_email|is_unique[lead_mgmt.lead_email]');
     $this->form_validation->set_rules('industry', 'industry', 'required');
     $this->form_validation->set_rules('website', 'website', 'required|valid_url');
     $this->form_validation->set_rules('revenue', 'revenue', 'required');
     $this->form_validation->set_rules('noemployee', 'No of employee', 'required');
     $this->form_validation->set_rules('rating', 'rating', 'required');     
     $this->form_validation->set_rules('second_email', 'second email', 'valid_email|is_unique[lead_mgmt.lead_second_email]');
     $this->form_validation->set_rules('assigned', 'assigned to', 'required');
     $this->form_validation->set_rules('emailoptout', 'email optout', 'required');
     $this->form_validation->set_rules('street', 'street', 'required');
     $this->form_validation->set_rules('pobox', 'PO BOX', 'required|alpha_numeric_spaces');
     $this->form_validation->set_rules('postal_code', 'postal code', 'required|numeric');
     $this->form_validation->set_rules('city', 'city', 'required|alpha');
     $this->form_validation->set_rules('country', 'country', 'required|alpha');
     $this->form_validation->set_rules('state', 'state', 'required|alpha');
     $this->form_validation->set_rules('description', 'description', 'required');
     

     if ($this->form_validation->run() == FALSE) {
      $this->session->set_flashdata('messagePr', validation_errors());
      
            //redirect(base_url('lead/addlead'));
     }else{
       // Create Lead USing Stored Procedure
       $a_procedure = "CALL  lead_insertproc (
                                            '".$this->input->post('fname')."',
                                            '".$this->input->post('lname')."',
                                            '1',
                                            '".$this->input->post('salutationtype')."',
                                            '".$this->input->post('phone')."',
                                            '".$this->input->post('company')."',
                                            '".$this->input->post('mobile')."',
                                            '".$this->input->post('designation')."',
                                            '".$this->input->post('fax')."',
                                            '".$this->input->post('lead_source')."',
                                            '".$this->input->post('email')."',
                                            '".$this->input->post('industry')."',
                                            '".$this->input->post('website')."',
                                            '".$this->input->post('revenue')."',
                                            '".$this->input->post('lead_status')."',
                                            '".$this->input->post('noemployee')."',
                                            '".$this->input->post('rating')."',
                                            '".$this->input->post('second_email')."',
                                            '".$this->input->post('assigned')."',
                                            '".$this->input->post('emailoptout')."',
                                            '".$this->input->post('street')."',
                                            '".$this->input->post('pobox')."',
                                            '".$this->input->post('postal_code')."',
                                            '".$this->input->post('city')."',
                                            '".$this->input->post('country')."',
                                            '".$this->input->post('state')."',
                                            '".$this->input->post('description')."')";

            $this->db->trans_start();
            $success = $this->db->query($a_procedure);            
            $this->db->trans_complete();
      $this->session->set_flashdata('messagePr', 'Your lead added Successfully..');
       redirect(base_url('lead'));
      }
    }
    $this->load->view("include/header");
    $this->load->view("add_lead");
    $this->load->view("include/footer");
  }

  /**
  ** Create Lead data function 
  ** add all form data into database
  **/
  public function createLead()
  {

     
  }

  
    /**
     * This function is used to create datatable in lead management list page
     * @return Void
     */
    public function dataTable (){
        is_login();
      $table = 'lead_mgmt';
      $primaryKey = 'lead_id';
      $columns = array(
           array( 'db' => 'lead_id', 'dt' => 0 ),           
          array( 'db' => 'lead_fname', 'dt' => 1 ),
          array( 'db' => 'lead_lname', 'dt' => 2 ),
          array( 'db' => 'lead_email', 'dt' => 3 ),
          array( 'db' => 'lead_id', 'dt' => 4 ));

        $sql_details = array(
      'user' => $this->db->username,
      'pass' => $this->db->password,
      'db'   => $this->db->database,
      'host' => $this->db->hostname
    );
   // $where = array("user_type != 'admin'");
    $output_arr = SSP::complex( $_GET, $sql_details, $table, $primaryKey, $columns);

    foreach ($output_arr['data'] as $key => $value) {
      $id = $output_arr['data'][$key][count($output_arr['data'][$key])  - 1];

      $output_arr['data'][$key][count($output_arr['data'][$key])  - 1] = '';


      if(CheckPermission($table, "all_update")){
        
      $output_arr['data'][$key][count($output_arr['data'][$key])  - 1] .= '<a id="btnEditRow"  href="'.base_url().'lead/editlead/'.$id.'" data-src="'.$id.'"  data-src="'.$id.'" title="Edit" ><i class="fa fa-pencil" data-id=""></i></a>';

      }else if(CheckPermission($table, "own_update") && (CheckPermission($table, "all_update")!=true)){
        $user_id =getRowByTableColomId($table,$id,'lead_id');
        
      $output_arr['data'][$key][count($output_arr['data'][$key])  - 1] .= '<a id="btnEditRow"  href="'.base_url().'lead/editlead/'.$id.'" class="btn-action"  data-src="'.$id.'" title="Edit"><i class="fa fa-pencil" data-id=""></i></a>';
        
      }
      
      if(CheckPermission($table, "all_delete")){
      $output_arr['data'][$key][count($output_arr['data'][$key])  - 1] .= '<a style="cursor:pointer;" data-toggle="modal" class="mClass btn-action" onclick="setId('.$id.', \'lead\')" data-target="#cnfrm_delete" title="delete"><i class="fa fa-trash-o" ></i></a>';
    }
      else if(CheckPermission($table, "own_delete") && (CheckPermission($table, "all_delete")!=true))
      {
        $user_id =getRowByTableColomId($table,$id,'lead_id');
        
      $output_arr['data'][$key][count($output_arr['data'][$key])  - 1] .= '<a style="cursor:pointer;" data-toggle="modal" class="mClass btn-action" onclick="setId('.$id.', \'lead\')" data-target="#cnfrm_delete" title="delete"><i class="fa fa-trash-o" ></i></a>';
        
      }
       $output_arr['data'][$key][count($output_arr['data'][$key])  - 1] .= '<a id="btnViewThread"  href="'.base_url().'lead/viewthread/'.$id.'" data-src="'.$id.'"  data-src="'.$id.'" title="Edit" class="btn btn-succesBorns">View Thread</a>';
     

            $output_arr['data'][$key][0] = '<input type="checkbox" name="selData" value="'.$output_arr['data'][$key][0].'">';
    }
 
    echo json_encode($output_arr);
    }

     /**
     * This function is used to delete users
     * @return Void
     */
    public function delete($id){
        is_login(); 
        $ids = explode('-', $id);
        foreach ($ids as $id) {
          $a_procedure = "CALL  sp_leadandcomment_DELETE_byPK (
                                            '".$id."')";
          $this->db->trans_start();
          $success = $this->db->query($a_procedure);            
          $this->db->trans_complete();           
        }
       redirect(base_url().'lead/', 'refresh');
    }


    /**
    * Load edit lead view 
    */
    public function editlead($id='')
    {
        is_login();
        $lead_id = $id;
        $data['leadData'] = $this->Lead_mgmt_model->get($lead_id);
         $this->load->view("include/header");
         $this->load->view("edit_lead",$data);
         $this->load->view("include/footer");
    }
    /**
    * update lead data 
    * @param int $id 
    */
    public function updateLead($id='')
    {


 $this->form_validation->set_rules('fname', 'first name', 'required|alpha');
     $this->form_validation->set_rules('lname', 'last name', 'required|alpha');     
     $this->form_validation->set_rules('phone', 'Phone', 'required');
     $this->form_validation->set_rules('company', 'Company', 'required');
     $this->form_validation->set_rules('mobile', 'Mobile', 'required');
     $this->form_validation->set_rules('designation', 'designation', 'required');
     $this->form_validation->set_rules('fax', 'Fax', 'required');
     $this->form_validation->set_rules('lead_source', 'Lead Source', 'required');
     $this->form_validation->set_rules('email', 'email', 'required|valid_email');
     $this->form_validation->set_rules('industry', 'industry', 'required');
     $this->form_validation->set_rules('website', 'website', 'required|valid_url');
     $this->form_validation->set_rules('revenue', 'revenue', 'required');
     $this->form_validation->set_rules('noemployee', 'No of employee', 'required');
     $this->form_validation->set_rules('rating', 'rating', 'required');     
     $this->form_validation->set_rules('second_email', 'second email', 'valid_email');
     $this->form_validation->set_rules('assigned', 'assigned to', 'required');
     $this->form_validation->set_rules('emailoptout', 'email optout', 'required');
     $this->form_validation->set_rules('street', 'street', 'required');
     $this->form_validation->set_rules('pobox', 'PO BOX', 'required|alpha_numeric_spaces');
     $this->form_validation->set_rules('postal_code', 'postal code', 'required|numeric');
     $this->form_validation->set_rules('city', 'city', 'required|alpha');
     $this->form_validation->set_rules('country', 'country', 'required|alpha');
     $this->form_validation->set_rules('state', 'state', 'required|alpha');
     $this->form_validation->set_rules('description', 'description', 'required');
     

     if ($this->form_validation->run() == FALSE) {
      $this->session->set_flashdata('messagePr', validation_errors());
            redirect(base_url('lead/editlead/'.$id));
     }else{
     

        $a_procedure = "CALL  lead_updateproc (
                                            '".$this->input->post('fname')."',
                                            '".$this->input->post('lname')."',
                                            '1',
                                            '".$this->input->post('salutationtype')."',
                                            '".$this->input->post('phone')."',
                                            '".$this->input->post('company')."',
                                            '".$this->input->post('mobile')."',
                                            '".$this->input->post('designation')."',
                                            '".$this->input->post('fax')."',
                                            '".$this->input->post('lead_source')."',
                                            '".$this->input->post('email')."',
                                            '".$this->input->post('industry')."',
                                            '".$this->input->post('website')."',
                                            '".$this->input->post('revenue')."',
                                            '".$this->input->post('lead_status')."',
                                            '".$this->input->post('noemployee')."',
                                            '".$this->input->post('rating')."',
                                            '".$this->input->post('second_email')."',
                                            '".$this->input->post('assigned')."',
                                            '".$this->input->post('emailoptout')."',
                                            '".$this->input->post('street')."',
                                            '".$this->input->post('pobox')."',
                                            '".$this->input->post('postal_code')."',
                                            '".$this->input->post('city')."',
                                            '".$this->input->post('country')."',
                                            '".$this->input->post('state')."',
                                            '".$this->input->post('description')."','".$id."')";

            $this->db->trans_start();
            $success = $this->db->query($a_procedure);
            
            $this->db->trans_complete();
      $this->session->set_flashdata('messagePr', 'Your lead updated Successfully..');
      }
      redirect(base_url('lead'));
    }

    /**
    * Load view Comment thread
    */
    function viewthread($id= ''){
        $this->load->model('comment/Comment_model');

        $data['comments']  = $this->Comment_model->get_comments_by_lead($id);  
        $data['lead_id']  = $id;
         $this->load->view("include/header");
         $this->load->view("thread",$data);
         $this->load->view("include/footer");
    }

     /**
    * Load view Comment thread
    */
    function viewthreaddemo($id= ''){
        $this->load->model('comment/Comment_model');
        $data['comments']  = $this->Comment_model->get_comments_by_lead($id);        
         $this->load->view("include/header");
         $this->load->view("role",$data);
         $this->load->view("include/footer");
    }

    /**
    * get lead data for autofill form
    * 
    **/
    function getLeadData(){
      $this->load->model('client/Client_model');
      if($_POST['email']!=""){
       $result = $this->Client_model->get_many_by(array("client_email"=>$_POST['email']));       
       if($result)
       {
       echo json_encode($result);
       }
       else{
        echo "Data not found";
       }
      }
    }

    /**
    * Create Comment by sales 
    * Add comment by admin or sales team 
    * 
    **/
    function createComment(){
      $this->load->model('comment/Comment_model');
      $lead_id = $_POST['lead_id'];
      $user = getleadAssignUser($lead_id);
      $client = getClientDetail($user->lead_email);
      $ip_address = get_client_ip();
      $data['comment_text'] = $_POST['comment'];
      $data['lead_id'] = $_POST['lead_id'];
      $data['parent_id'] = $_POST['thread_id'];
      $thread_id = getThreadId($lead_id);      
      $data['thread_id'] = ($thread_id+1);
      $data['ip_address'] = $ip_address;
      if($_POST['user']=="From SN"){       
          $data['created_by'] = 'From SN';
          $data['created_id'] = $user->users_id;
      }
      if($_POST['user']=="From Client"){
          $data['created_by']="From Client";
          $data['created_id'] = $client->client_id;
      }

      $this->Comment_model->insert($data);
      //echo $this->db->last_query();die;
      $this->session->set_flashdata('messagePr',"Comment Added Successfully.");
      redirect(base_url().'lead/viewthread/'.$lead_id);
    }

    /**

    */
    function addClient(){
       
$a_procedure = "CALL  clientCRUD ('UPDATE','101','ghadiya','1','0','ghadiya@search.com','user.jpg',@pclient_id)";
    $this->db->trans_start();
    $success = $this->db->query($a_procedure);
    $success->next_result();
    $success->free_result();
    $query = $this->db->query('select @pclient_id as out_param');
    $this->db->trans_complete();
    echo $query->row()->out_param;
    }

}
?>