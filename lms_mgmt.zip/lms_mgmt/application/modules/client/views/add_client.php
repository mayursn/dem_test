<form role="form bor-rad" enctype="multipart/form-data" action="<?php echo base_url().'client/add_edit'?>" method="post" id="form_client">
  <div class="box-body">
    <div class="row">
        
        <div class="row col-md-12 form-group">
          <div class="form-group">
          <div class="col-sm-3">
            <label for="">First Name</label>
            </div>
            <div class="col-sm-3">
            <select class="form-control select2 chosen-select"   name="salutationtype" id="salutationtype" >
                                    <option value="">None</option>
                                    <option value="Mr." <?php echo (isset($clientData->client_salutationtype) && $clientData->client_salutationtype == 'Mr.')?'selected':''; ?>>Mr.</option>
                                    <option value="Ms."  <?php echo (isset($clientData->client_salutationtype) && $clientData->client_salutationtype == 'Ms.')?'selected':''; ?>>Ms.</option>
                                    <option value="Mrs."  <?php echo (isset($clientData->client_salutationtype) && $clientData->client_salutationtype == 'Mrs.')?'selected':''; ?>>Mrs.</option>
                                    <option value="Dr." <?php echo (isset($clientData->client_salutationtype) && $clientData->client_salutationtype == 'Dr.')?'selected':''; ?>>Dr.</option>
                                    <option value="Prof."  <?php echo (isset($clientData->client_salutationtype) && $clientData->client_salutationtype == 'Prof.')?'selected':''; ?>>Prof.</option>
                                 </select>
                                 </div>
                                 <div class="col-sm-6">
            <input type="text" name="client_fname" value="<?php echo isset($clientData->client_fname)?$clientData->client_fname:'';?>" class="form-control" placeholder="First Name"></div>
          </div>
        </div>
        <div class="row col-md-12 form-group">
          <div class="form-group">
          <div class="col-sm-3">
            <label for="">Last Name</label>
            </div>
            <div class="col-sm-9">
            <input type="text" name="client_lname" value="<?php echo isset($clientData->client_lname)?$clientData->client_lname:'';?>" class="form-control" placeholder="Last Name">
            </div>
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group">
            <label for="">Email</label>
            <input type="text" name="client_email" value="<?php echo isset($clientData->client_email)?$clientData->client_email:'';?>" class="form-control" placeholder="Email">
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group">
            <label for="">Phone</label>
            <input type="text" name="client_phone" value="<?php echo isset($clientData->client_phone)?$clientData->client_phone:'';?>" class="form-control" placeholder="Phone">
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group">
            <label for="">Mobile</label>
            <input type="text" name="client_mobile" value="<?php echo isset($clientData->client_mobile)?$clientData->client_mobile:'';?>" class="form-control" placeholder="Mobile">
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group">
            <label for="">Company</label>
            <input type="text" name="client_company" value="<?php echo isset($clientData->client_company)?$clientData->client_company:'';?>" class="form-control" placeholder="Company">
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group">
            <label for="">Designation</label>
            <input type="text" name="client_designation" value="<?php echo isset($clientData->client_designation)?$clientData->client_designation:'';?>" class="form-control" placeholder="Designation">
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group">
            <label for="">Fax</label>
            <input type="text" name="client_fax" value="<?php echo isset($clientData->client_fax)?$clientData->client_fax:'';?>" class="form-control" placeholder="Fax">
          </div>
        </div>


        <div class="col-md-6">
            <div class="form-group">
              <label for="status"> Status</label>
              <select name="status" id="" class="form-control">
                  <option value="active" <?php echo (isset($clientData->status) && $clientData->status == 'active')?'selected':''; ?> >Active</option>

                  <option value="deleted" <?php echo (isset($clientData->status) && $clientData->status == 'deleted')?'selected':''; ?> >Deleted</option>

              </select>
            </div>
          </div>

        
          <div class="col-md-6"> 
            <div class="form-group imsize">
              <label for="exampleInputFile">Image Upload</label>
              <div class="pic_size" id="image-holder"> 
                <?php
                //echo file_exists(FCPATH.'assets/images/'.$clientData->profile_pic);
                 if(file_exists(FCPATH.'assets/images/'.$clientData->profile_pic)){ 
                   $profile_pic = $clientData->profile_pic;
                }else{                   
                  $profile_pic = 'user.png'; 
                } ?> 
                <left> <img class="thumb-image setpropileam" src="<?php echo base_url();?>/assets/images/<?php echo isset($profile_pic)?$profile_pic:'user.png';?>" alt="User profile picture"></left>
              </div> <input type="file" name="profile_pic" id="exampleInputFile">
            </div>
          </div>                
        </div>
        <?php if(!empty($clientData->client_id)){?>
        <input type="hidden"  name="client_id" value="<?php echo isset($clientData->client_id)?$clientData->client_id:'';?>">
        <input type="hidden" name="fileOld" value="<?php echo isset($clientData->profile_pic)?$clientData->profile_pic:'';?>">
        <div class="box-footer sub-btn-wdt">
          <button type="submit" name="edit" value="edit" class="btn btn-success wdt-bg">Update</button>
        </div>
              <!-- /.box-body -->
        <?php }else{?>
        <div class="box-footer sub-btn-wdt">
          <button type="submit" name="submit" value="add" class="btn btn-success wdt-bg">Add</button>
        </div>
        <?php }?>
      </form>
      <script type="text/javascript" src="<?php echo base_url('assets/js/client.js'); ?>"></script>