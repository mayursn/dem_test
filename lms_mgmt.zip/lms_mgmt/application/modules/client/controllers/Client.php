<?php
defined('BASEPATH') OR exit('No direct script access allowed ');
class Client extends CI_Controller {

    function __construct() {

        parent::__construct(); 
        //Checking user is login or not 
        is_login();
        $this->load->model('Client_model');
        $this->user_id = isset($this->session->get_userdata()['user_details'][0]->id)?$this->session->get_userdata()['user_details'][0]->users_id:'1';
    }
    function index()
    {
        
         $this->load->view('include/header');
        $this->load->view('client_table');                
        $this->load->view('include/footer');  
    }
    public function clientTable()
    {
        $this->load->view('include/header');
        $this->load->view('client_table');                
        $this->load->view('include/footer');  
    }
    
     /**
     * This function is used to create datatable in Client list page
     * @return Void
     */
    public function dataTable (){
        is_login();
	    $table = 'client';
    	$primaryKey = 'client_id';
    	$columns = array(
                    array( 'db' => 'client_id', 'dt' => 0 ),                    
					array( 'db' => 'client_fname', 'dt' => 1 ),
                    array( 'db' => 'client_lname', 'dt' => 2 ),
					array( 'db' => 'client_email', 'dt' => 3 ),
					array( 'db' => 'client_id', 'dt' => 4 )
		);

        $sql_details = array(
			'user' => $this->db->username,
			'pass' => $this->db->password,
			'db'   => $this->db->database,
			'host' => $this->db->hostname
		);
		$output_arr = SSP::complex( $_GET, $sql_details, $table, $primaryKey, $columns);
		foreach ($output_arr['data'] as $key => $value) {
			$id = $output_arr['data'][$key][count($output_arr['data'][$key])  - 1];
			$output_arr['data'][$key][count($output_arr['data'][$key])  - 1] = '';
			if(CheckPermission($table, "all_update")){
			$output_arr['data'][$key][count($output_arr['data'][$key])  - 1] .= '<a id="btnEditRow" class="modalButtonClient mClass"  href="javascript:;" type="button" data-src="'.$id.'" title="Edit"><i class="fa fa-pencil" data-id=""></i></a>';
			}else if(CheckPermission($table, "own_update") && (CheckPermission($table, "all_update")!=true)){
				$user_id =getRowByTableColomId($table,$id,'users_id','user_id');
				if($user_id==$this->user_id){
			$output_arr['data'][$key][count($output_arr['data'][$key])  - 1] .= '<a id="btnEditRow" class="modalButtonClient mClass"  href="javascript:;" type="button" data-src="'.$id.'" title="Edit"><i class="fa fa-pencil" data-id=""></i></a>';
				}
			}
			
			if(CheckPermission($table, "all_delete")){
			$output_arr['data'][$key][count($output_arr['data'][$key])  - 1] .= '<a style="cursor:pointer;" data-toggle="modal" class="mClass" onclick="setId('.$id.', \'client\')" data-target="#cnfrm_delete" title="delete"><i class="fa fa-trash-o" ></i></a>';}
			else if(CheckPermission($table, "own_delete") && (CheckPermission($table, "all_delete")!=true)){
				$user_id =getRowByTableColomId($table,$id,'users_id','user_id');
				if($user_id==$this->user_id){
			$output_arr['data'][$key][count($output_arr['data'][$key])  - 1] .= '<a style="cursor:pointer;" data-toggle="modal" class="mClass" onclick="setId('.$id.', \'client\')" data-target="#cnfrm_delete" title="delete"><i class="fa fa-trash-o" ></i></a>';
				}
			}
            $output_arr['data'][$key][0] = '<input type="checkbox" name="selData" value="'.$output_arr['data'][$key][0].'">';
		}
		echo json_encode($output_arr);
    }
    
    /**
     * This function is used to show popup of user to add and update
     * @return Void
     */
    public function get_modal() {
        is_login();
        if($this->input->post('id')){
            $data['clientData'] = getDataByid('client',$this->input->post('id'),'client_id'); 
            echo $this->load->view('add_client', $data, true);
        } else {
            echo $this->load->view('add_client', '', true);
        }
        exit;
    }
    
    public function add_edit($id='') {
        if($this->input->post('client_id')) {
            $id = $this->input->post('client_id');
        }
         foreach($_FILES as $name => $fileInfo)
        {                         
             if(!empty($_FILES[$name]['name'])){                 
                $newname=$this->upload();                   
                $data[$name]=$newname;
                $profile_pic =$newname;
             } else {  
                if($this->input->post('fileOld')) {  
                    $newname = $this->input->post('fileOld');
                    $data[$name]=$newname;
                    $profile_pic =$newname;
                } else {
                    $data[$name]='';
                    $profile_pic ='user.png';
                } 
            } 
        }
       
        if($id!='')
        {

            $id = $this->input->post('client_id');
            $status = $this->input->post('status');
            if($status=="active"){
                $status = '1';
            }
            else{
                $status = '0';
            }
             $a_procedure = "CALL  clientCRUD ('UPDATE','".$id."',
                                            '".$this->input->post('client_fname')."',
                                            '".$this->input->post('client_lname')."',
                                            '".$this->input->post('salutationtype')."',
                                            '".$this->input->post('client_phone')."',
                                            '".$this->input->post('client_company')."',
                                            '".$this->input->post('client_mobile')."',
                                            '".$this->input->post('client_designation')."',
                                            '".$this->input->post('client_fax')."',
                                            '".$status."',
                                            '0',
                                            '".$this->input->post('client_email')."',
                                            '".$profile_pic."',@pclient_id)";

            $this->db->trans_start();
            $success = $this->db->query($a_procedure);
            $success->next_result();
            $success->free_result();
            $query = $this->db->query('select @pclient_id as out_param');
            $this->db->trans_complete();
            if($id=="")
            {
                $this->session->set_flashdata('messagePr', 'Your Client added Successfully..');
            }
            else{
             $this->session->set_flashdata('messagePr', 'Your Client updated Successfully..');   
            }
            redirect( base_url().'client/', 'refresh');
            //echo $query->row()->out_param;

        }
        else
        {       
            
            $status = $this->input->post('status');
            if($status=="active"){
                $status = '1';
            }
            else{
                $status = '0';
            }
           $a_procedure = "CALL clientCRUD ('INSERT','',
                                            '".$this->input->post('client_fname')."',
                                            '".$this->input->post('client_lname')."',
                                            '".$this->input->post('salutationtype')."',
                                            '".$this->input->post('client_phone')."',
                                            '".$this->input->post('client_company')."',
                                            '".$this->input->post('client_mobile')."',
                                            '".$this->input->post('client_designation')."',
                                            '".$this->input->post('client_fax')."',
                                            '".$status."',
                                            '0',
                                            '".$this->input->post('client_email')."',
                                            '".$profile_pic."',
                                            @pclient_id)";

            $this->db->trans_start();
            $success = $this->db->query($a_procedure);
            $success->next_result();
            $success->free_result();
            $query = $this->db->query('select @pclient_id as out_param');
            $this->db->trans_complete();
            //echo $query->row()->out_param;
           $this->session->set_flashdata();
            redirect( base_url().'client/', 'refresh');
        }
    }
    
     /**
     * This function is used to upload file
     * @return Void
     */
    function upload() {
        foreach($_FILES as $name => $fileInfo)
        {
            $filename=$_FILES[$name]['name'];
            $tmpname=$_FILES[$name]['tmp_name'];
            $exp=explode('.', $filename);
            $ext=end($exp);
            $newname=  $exp[0].'_'.time().".".$ext; 
            $config['upload_path'] = 'assets/images/';
            $config['upload_url'] =  base_url().'assets/images/';
            $config['allowed_types'] = "gif|jpg|jpeg|png|iso|dmg|zip|rar|doc|docx|xls|xlsx|ppt|pptx|csv|ods|odt|odp|pdf|rtf|sxc|sxi|txt|exe|avi|mpeg|mp3|mp4|3gp";
            $config['max_size'] = '2000000'; 
            $config['file_name'] = $newname;
            $this->load->library('upload', $config);
            move_uploaded_file($tmpname,"assets/images/".$newname);
            return $newname;
        }
    }

    /**
     * This function is used to delete users
     * @return Void
     */
    public function delete($id){
        is_login(); 
        $ids = explode('-', $id);
        foreach ($ids as $id) {
            $this->Client_model->delete($id); 
        }
       redirect(base_url().'client/', 'refresh');
    }
    
}