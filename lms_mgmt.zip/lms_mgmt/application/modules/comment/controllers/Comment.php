<?php defined("BASEPATH") OR exit("No direct script access allowed");

class Comment extends CI_Controller {

  function __construct() {
    parent::__construct();
    $this->load->model('Comment_model');
  }

  /**
     * This function is used to load page view
     * @return Void
     */
  public function index(){   
    $this->load->view("include/header");
    $this->load->view("index");
    $this->load->view("include/footer");
  }

  public function insert_comment()
  {
      $public_ip = file_get_contents('https://api.ipify.org');
        //$ip_data = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=".$ip));  

     //echo "My public IP address is: " . $ip;
      $data = array("comment_text"=>$this->input->post('comment_text'),
                    "created_date"=>date('Y-m-d'),
                    "ip_address"=>$public_ip,
                    "created_by"=>$this->session->get_userdata()['user_details'][0]->users_id                
                );      
      $this->Comment_model->insert($data);
      $wherearray=array("created_by" => $this->session->get_userdata()['user_details'][0]->users_id);
        $data['comment']= $this->Comment_model->get_many_by($wherearray);
      $this->load->view('commentlist',$data);
  }

}
?>