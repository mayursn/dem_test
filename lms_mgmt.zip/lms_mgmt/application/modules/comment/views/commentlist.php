 
 <?php 
        foreach($comment as $cm)
        {
            ?>
            <div class="col-md-12">
                <div class="panel panel-white">
                    <div class="panel-heading clearfix">
                        <i class="fa fa-user fa-4" aria-hidden="true"></i>
                        <?php echo $this->session->userdata('user_details')[0]->name; ?>
                    </div>
                    <div class="panel-body">
                          <div class="col-md-12">
                              <?php echo $cm->comment_text;?>
                          </div>
                        <div class="pull-right">
                          <span><a class="cursorPointer replyComment feedback"
                                   <i class="icon-share-alt"></i>Reply</a>&nbsp;
                                   <span>|</span>&nbsp;<a class="cursorPointer editComment feedback">Edit</a></span>
                            <span>&nbsp;<span>|</span>&nbsp;<a href="javascript:void(0);" class="cursorPointer detailViewThread">View Thread</a></span>       
                        </div>
                    </div> <!-- panel body -->
                </div>
            </div> <!-- col md 12 -->
            <hr>
        <?php
        }

        ?>