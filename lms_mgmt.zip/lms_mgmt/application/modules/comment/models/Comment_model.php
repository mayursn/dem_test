<?php
class Comment_model extends MY_Model {  
	protected $primary_key = 'comment_id';      // protected primary key
	function __construct(){            
	  	parent::__construct();
		$this->user_id =isset($this->session->get_userdata()['user_details'][0]->id)?$this->session->get_userdata()['user_details'][0]->users_id:'1';
	}

	/**
	* return mixed array
	* join users and comment table for timeline data
	* @param int $id (Lead id)
	* getting result using lead id for particular lead comments view display
	*
	**/
	public function get_comments_by_lead($id=''){
		return $this->db->select('comment.*')
		->from('comment')
		->where('lead_id',$id)
		->get()->result();


	}
	
}