<!-- page content -->
 <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper settingPage">
    <!-- Main content -->
    <section class="content">
      <!-- Default box -->
      <div class="box box-success">
        <div class="box-header with-border">
          <h3 class="box-title">About Us </h3>
        </div>
        <div class="box-body">
          <div class="row">
            <div class="col-lg-12">
              <div class="col-md-6 col-md-offset-1 aboutshift">
                <p>This project is build with <a href="http://www.searchnative.com">Searchnative India Pvt. Ltd</a>.</p>
                <p><a href="http://www.searchnative.com">Searchnative</a> is a mobile apps, software and web development company, which offers a spectrum of application development services and web solutions. The company boasts of a bunch of talented and enthusiastic professionals brimming with creative ideas. </p>

                <p>Our team is always ready to handle the most complicated task flawlessly! The robust IT infrastructure of the company has further made the things easier to render hugely affordable solutions within scheduled deadlines.</p>
                <p>URL: <a href="http://www.searchnative.com">http://www.searchnative.com</a></p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- /.box-body -->
    </div>
    <!-- /.box -->
  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->