<?php
header('Content-Type: text/html; charset=utf-8');
$conn = mysqli_connect("localhost", "dawayaor", "DaWaYa@16969", "dawayaor_testing2"); // old site database connection
$conn2 = mysqli_connect("localhost", "dawayaor", "DaWaYa@16969", "dawayaor_newtopdoctors"); // new site database connection

//latest cron changes connection Date: 10-02-2017 Magento db
$conn3 = mysqli_connect("localhost", "dawayaor", "DaWaYa@16969", "dawayaor_dawaya");

$raitng_query3 = mysqli_query($conn2, "SELECT ifnull (max(last_id),0) FROM rating_data"); // get maximum id from work rating
$row3 = mysqli_fetch_row($raitng_query3);
$last_rating_data_id = $row3[0];
$max_id = $last_rating_data_id;
//last inserted id: 41157
//
//exportMysqlToCsv('export_csv.csv');

$query = mysqli_query($conn2, "INSERT INTO doctors_rating (doctor_id,reputation,clinic,availability,approachability,technology,average_score,comment,user_id,user_ip,date_created,visibility,dstatus,reviewIcon) SELECT doctor_id,reputation,clinic,availability,approachability,technology,average_score,comment,customer_id,customer_ip,date_created,dawayaor_dawaya.mb_doctory_rating.visibility,'1','0' FROM dawayaor_dawaya.mb_doctory_rating INNER JOIN dawayaor_dawaya.mb_doctory_doctor ON dawayaor_dawaya.mb_doctory_rating.doctor_id=dawayaor_dawaya.mb_doctory_doctor.entity_id WHERE dawayaor_dawaya.mb_doctory_doctor.gender!='0' AND dawayaor_dawaya.mb_doctory_rating.id > $max_id");

$query = mysqli_query($conn2, "INSERT INTO work_rating (work_id,reputation,clinic,availability,approachability,technology,average_score,comment,user_id,user_ip,date_created,visibility,wstatus,reviewIcon) SELECT doctor_id,reputation,clinic,availability,approachability,technology,average_score,comment,'1',customer_ip,date_created,dawayaor_dawaya.mb_doctory_rating.visibility,'1','0' FROM dawayaor_dawaya.mb_doctory_rating INNER JOIN dawayaor_dawaya.mb_doctory_doctor ON dawayaor_dawaya.mb_doctory_rating.doctor_id=dawayaor_dawaya.mb_doctory_doctor.entity_id WHERE dawayaor_dawaya.mb_doctory_doctor.gender='0' AND  dawayaor_dawaya.mb_doctory_rating.id > $max_id");

$get_last_id = mysqli_query($conn3, "SELECT ifnull (max(id),0) FROM dawayaor_dawaya.mb_doctory_rating");
$last_record = mysqli_fetch_row($get_last_id);
$record = $last_record[0];

mysqli_query($conn2, "INSERT rating_data SET last_id='" . $record . "'");

//send email with csv attachment
require 'class.email-query-results-as-csv-file.php';
$emailCSV = new EmailQueryResultsAsCsv('localhost', 'dawayaor_dawaya', 'dawayaor', 'DaWaYa@16969');
$sql = "SELECT doctor_id,reputation,clinic,availability,approachability,technology,average_score,comment,'1',customer_ip,date_created,dawayaor_dawaya.mb_doctory_rating.visibility,'1','0' FROM dawayaor_dawaya.mb_doctory_rating WHERE dawayaor_dawaya.mb_doctory_rating.id > $max_id";
$emailCSV->setQuery($sql);
$emailCSV->sendEmail("info@topdoctors.me", "navil.shah@searchnative.in", "Top doctors rating raport");

