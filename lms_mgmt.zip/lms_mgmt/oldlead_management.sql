-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 07, 2017 at 01:28 PM
-- Server version: 10.1.10-MariaDB
-- PHP Version: 7.0.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lead_management`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `clientCRUD` (`pAction` VARCHAR(10), `pid` INT, `pfname` VARCHAR(255), `plname` VARCHAR(255), `psalutationtype` VARCHAR(255), `pphone` VARCHAR(255), `pcompany` VARCHAR(255), `pmobile` VARCHAR(255), `pdesignation` VARCHAR(255), `pfax` VARCHAR(255), `pstatus` ENUM('0','1'), `pis_deleted` ENUM('0','1'), `pemail` VARCHAR(255), `pprofile` VARCHAR(255), OUT `pclient_id` INT)  BEGIN
        IF pAction = "SELECT" THEN
        SELECT *
        FROM client;
     END IF;
 
        IF pAction = "INSERT" THEN
     INSERT INTO client (client_fname,client_lname,client_salutationtype,client_phone,client_company,client_mobile,client_designation,client_fax, status, is_deleted, client_email,profile_pic) 
     VALUES (pfname,plname,psalutationtype,pphone,pcompany,pmobile,pdesignation,pfax, pstatus, pis_deleted, pemail,pprofile); 
  set pclient_id = (SELECT LAST_INSERT_ID()); 
    END IF;
 
        IF pAction = "UPDATE" THEN
        UPDATE client
        SET client_fname = pfname,
        client_lname = plname,
        client_salutationtype = psalutationtype,
        client_phone = pphone,
        client_company = pcompany,
        client_mobile = pmobile,
        client_designation = pdesignation,
        client_fax = pfax,
         status = pstatus,is_deleted=pis_deleted,client_email=pemail,profile_pic=pprofile
        WHERE client_id = pid;
    END IF;
     
        IF pAction = "DELETE" THEN
        DELETE FROM client
        WHERE client_id = pid;
    END IF;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `employeeCRUD` (`pAction` VARCHAR(10), `pid` INT, `pfirst_name` VARCHAR(10), `plast_name` VARCHAR(10), `psalary` DECIMAL(10,2), `pcity` VARCHAR(20))  BEGIN
        IF pAction = "SELECT" THEN
        SELECT *
        FROM employee;
     END IF;
 
        IF pAction = "INSERT" THEN
        INSERT INTO employee(first_name, last_name,salary,city)
        VALUES (pfirst_name, plast_name,psalary,pcity);
    END IF;
 
        IF pAction = "UPDATE" THEN
        UPDATE Customers
        SET first_name = pfirst_name, last_name = plast_name,salary=psalary,city=pcity
        WHERE id = pid;
    END IF;
     
        IF pAction = "DELETE" THEN
        DELETE FROM employee
        WHERE id = pid;
    END IF;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `lead_insertproc` (IN `plead_fname` VARCHAR(255), IN `plead_lname` VARCHAR(255), IN `plead_status` ENUM('0','1'), IN `plead_salutationtype` VARCHAR(10), IN `plead_phone` VARCHAR(20), IN `plead_company` VARCHAR(255), IN `plead_mobile` VARCHAR(20), IN `plead_designation` VARCHAR(255), IN `plead_fax` VARCHAR(20), IN `plead_source` VARCHAR(255), IN `plead_email` VARCHAR(255), IN `plead_industry` VARCHAR(255), IN `plead_website` VARCHAR(255), IN `plead_anrevenue` VARCHAR(255), IN `pleads_status` VARCHAR(255), IN `plead_emp_no` VARCHAR(255), IN `plead_rating` VARCHAR(255), IN `plead_second_email` VARCHAR(255), IN `plead_assigned_to` VARCHAR(255), IN `plead_optout` VARCHAR(10), IN `plead_street` TEXT, IN `plead_pobox` VARCHAR(255), IN `plead_postal_code` VARCHAR(10), IN `plead_city` VARCHAR(255), IN `plead_country` VARCHAR(255), IN `plead_state` VARCHAR(255), IN `plead_description` TEXT)  BEGIN
DECLARE clienid INT(11);
 IF EXISTS (SELECT client_id FROM client WHERE client_email=plead_email) THEN
SET clienid = (SELECT client_id FROM client WHERE client_email=plead_email);
      ELSE 
  insert into client (client_fname,client_lname,client_salutationtype,client_phone,client_company,client_mobile,client_designation,client_fax,client_email,profile_pic)  VALUES
 (plead_fname,plead_lname,plead_salutationtype,plead_phone,plead_company,plead_mobile,plead_designation,plead_fax,plead_email,'user.png'); 
set clienid = (select last_insert_id()); 
  END IF;
INSERT INTO lead_mgmt (lead_fname,
lead_lname,
lead_status,
lead_salutationtype,
lead_phone,
lead_company,
lead_mobile,
lead_designation,
lead_fax,
lead_source,
lead_email,
lead_industry,
lead_website,
lead_anrevenue,
leads_status,
lead_emp_no,
lead_rating,
lead_second_email,
lead_assigned_to,
lead_optout,
lead_street,
lead_pobox,
lead_postal_code,
lead_city,
lead_country,
lead_state,
lead_description)
VALUES (plead_fname,
plead_lname,
plead_status,
plead_salutationtype,
 plead_phone,
 plead_company,
 plead_mobile,
 plead_designation,
 plead_fax,
 plead_source,
 plead_email,
 plead_industry,
 plead_website,
 plead_anrevenue,
 pleads_status,
 plead_emp_no,
 plead_rating,
 plead_second_email,
 plead_assigned_to,
 plead_optout,
 plead_street,
 plead_pobox,
 plead_postal_code,
 plead_city, 
 plead_country,
 plead_state,
 plead_description);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `lead_updateproc` (IN `plead_fname` VARCHAR(255), IN `plead_lname` VARCHAR(255), IN `plead_status` ENUM('0','1'), IN `plead_salutationtype` VARCHAR(10), IN `plead_phone` VARCHAR(20), IN `plead_company` VARCHAR(255), IN `plead_mobile` VARCHAR(20), IN `plead_designation` VARCHAR(255), IN `plead_fax` VARCHAR(20), IN `plead_source` VARCHAR(255), IN `plead_email` VARCHAR(255), IN `plead_industry` VARCHAR(255), IN `plead_website` VARCHAR(255), IN `plead_anrevenue` VARCHAR(255), IN `pleads_status` VARCHAR(255), IN `plead_emp_no` VARCHAR(255), IN `plead_rating` VARCHAR(255), IN `plead_second_email` VARCHAR(255), IN `plead_assigned_to` VARCHAR(255), IN `plead_optout` VARCHAR(10), IN `plead_street` TEXT, IN `plead_pobox` VARCHAR(255), IN `plead_postal_code` VARCHAR(10), IN `plead_city` VARCHAR(255), IN `plead_country` VARCHAR(255), IN `plead_state` VARCHAR(255), IN `plead_description` TEXT, IN `pid` INT(11))  BEGIN

DECLARE clienid INT(11);

IF EXISTS (SELECT client_id FROM client WHERE client_email=plead_email) THEN
SET clienid = (SELECT client_id FROM client WHERE client_email=plead_email);
  ELSE 
  insert into client (client_fname,client_lname,client_salutationtype,client_phone,client_company,client_mobile,client_designation,client_fax,client_email,profile_pic)  VALUES
 (plead_fname,plead_lname,plead_salutationtype,plead_phone,plead_company,plead_mobile,plead_designation,plead_fax,plead_email,'user.png'); 
set clienid = (select last_insert_id()); 
  END IF;

UPDATE lead_mgmt SET lead_fname = plead_fname,
lead_lname = plead_lname,
lead_status = plead_status,
lead_salutationtype = plead_salutationtype,
lead_phone = plead_phone,
lead_company = plead_company,
lead_mobile = plead_mobile,
lead_designation = plead_designation,
lead_fax = plead_fax,
lead_source = plead_source,
lead_email = plead_email, 
lead_industry = plead_industry,
lead_website = plead_website,
lead_anrevenue = plead_anrevenue,
leads_status = pleads_status,
lead_emp_no = plead_emp_no,
lead_rating = plead_rating,
lead_second_email = plead_second_email,
lead_assigned_to = plead_assigned_to,
lead_optout = plead_optout,
lead_street = plead_street,
lead_pobox = plead_pobox, 
lead_postal_code = plead_postal_code,
lead_city = plead_city,
lead_country = plead_country,
lead_state = plead_state,
lead_description = plead_description
WHERE lead_id = pid;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_clientinsert` (IN `p_client_name` VARCHAR(255), IN `p_status` ENUM('0','1'), IN `p_is_deleted` ENUM('0','1'), IN `p_email` VARCHAR(255), IN `p_profile_pic` VARCHAR(255), OUT `client_id` INT(11))  BEGIN 
  INSERT INTO client (client_name, status, is_deleted, email,profile_pic) VALUES (p_client_name, p_status, p_is_deleted, p_email,p_profile_pic); 
    set client_id = (SELECT LAST_INSERT_ID());
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_emploee_INSERT_byPK` (IN `p_first_name` VARCHAR(10), IN `p_last_name` VARCHAR(10), IN `p_salary` DECIMAL(10,2), IN `p_city` VARCHAR(20), OUT `p_id` INT(11))  BEGIN 
  INSERT INTO employee (first_name, last_name, salary, city) VALUES (p_first_name, p_last_name, p_salary, p_city); 

  set p_id = (SELECT LAST_INSERT_ID());  
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_leadandcomment_DELETE_byPK` (IN `p_lead_id` INT(11))  BEGIN 

    DELETE FROM lead_mgmt
    WHERE  lead_id = p_lead_id; 
    DELETE FROM comment
    WHERE  lead_id = p_lead_id; 

END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `client`
--

CREATE TABLE `client` (
  `client_id` int(11) NOT NULL,
  `client_fname` varchar(255) DEFAULT NULL,
  `client_lname` varchar(255) DEFAULT NULL,
  `client_salutationtype` varchar(255) DEFAULT NULL,
  `client_phone` varchar(255) DEFAULT NULL,
  `client_company` varchar(255) DEFAULT NULL,
  `client_mobile` varchar(255) DEFAULT NULL,
  `client_designation` varchar(255) DEFAULT NULL,
  `client_fax` varchar(255) DEFAULT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1',
  `is_deleted` enum('0','1') NOT NULL DEFAULT '1',
  `client_email` varchar(255) DEFAULT NULL,
  `profile_pic` varchar(255) DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `client`
--

INSERT INTO `client` (`client_id`, `client_fname`, `client_lname`, `client_salutationtype`, `client_phone`, `client_company`, `client_mobile`, `client_designation`, `client_fax`, `status`, `is_deleted`, `client_email`, `profile_pic`, `created_date`, `updated_date`) VALUES
(1, 'Michel', 'Shone', '', '+94888885566', 'Example Inc.', '69588599665', 'CEO', '4545885', '1', '1', 'shone.michel@example.com', 'user.png', '2017-03-07 09:19:45', '2017-03-07 14:49:45'),
(2, 'dfdsf', 'dfgdfg', 'Mr.', '123456868686', 'asdsad', '23432312334234', 'sadasd', '234234234', '1', '1', '1234@dsd.com', 'user.png', '2017-03-07 10:16:20', '2017-03-07 15:46:20');

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE `comment` (
  `comment_id` int(10) UNSIGNED NOT NULL,
  `thread_id` int(11) NOT NULL,
  `comment_text` text NOT NULL,
  `parent_id` int(10) UNSIGNED NOT NULL,
  `lead_id` int(11) NOT NULL,
  `ip_address` varchar(20) NOT NULL,
  `email_address` varchar(100) DEFAULT NULL,
  `web_address` varchar(255) DEFAULT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` varchar(45) NOT NULL,
  `created_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `comment`
--

INSERT INTO `comment` (`comment_id`, `thread_id`, `comment_text`, `parent_id`, `lead_id`, `ip_address`, `email_address`, `web_address`, `created_date`, `created_by`, `created_id`) VALUES
(1, 1, 'This is First Lead Comment By Searchnative India', 0, 1, '192.168.1.36', NULL, NULL, '2017-03-07 09:57:05', 'From SN', 7),
(2, 2, 'This is first Reply From Client of our  comment ', 1, 1, '192.168.1.36', NULL, NULL, '2017-03-07 09:57:26', 'From Client', 1),
(3, 1, 'This is first comment on second client ', 0, 2, '192.168.1.36', NULL, NULL, '2017-03-07 10:43:55', 'From SN', 5);

-- --------------------------------------------------------

--
-- Table structure for table `industry`
--

CREATE TABLE `industry` (
  `ind_id` int(11) NOT NULL,
  `industry_name` varchar(255) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `industry`
--

INSERT INTO `industry` (`ind_id`, `industry_name`, `created_date`, `updated_date`) VALUES
(1, 'Apparel', '2017-02-21 09:40:45', '2017-02-21 15:10:45'),
(2, 'Banking', '2017-02-21 09:40:51', '2017-02-21 15:10:51'),
(3, '', '2017-03-07 09:33:02', '2017-03-07 15:03:02'),
(4, '', '2017-03-07 09:33:50', '2017-03-07 15:03:50'),
(5, 'sadfadsad', '2017-03-07 09:37:39', '2017-03-07 15:07:39');

-- --------------------------------------------------------

--
-- Table structure for table `lead_data`
--

CREATE TABLE `lead_data` (
  `lead_date` date DEFAULT NULL,
  `lead_business_type` varchar(50) DEFAULT NULL,
  `lead_inquiry_source` varchar(100) DEFAULT NULL,
  `lead_inquiry_sub_source` varchar(255) DEFAULT NULL,
  `lead_technology` varchar(255) DEFAULT NULL,
  `lead_service` varchar(255) DEFAULT NULL,
  `lead_cots` varchar(50) DEFAULT NULL,
  `lead_ind_domain` varchar(50) DEFAULT NULL,
  `lead_mediator` enum('1','0') DEFAULT '1',
  `lead_nda` enum('1','0') DEFAULT '1',
  `lead_pricing_model` varchar(255) DEFAULT NULL,
  `lead_projected_value` varchar(10) DEFAULT NULL,
  `lead_team_size` varchar(11) DEFAULT NULL,
  `lead_project_start_date` date DEFAULT NULL,
  `lead_hours` varchar(10) DEFAULT NULL,
  `lead_conv_factor` varchar(10) DEFAULT NULL,
  `lead_denied_date` date DEFAULT NULL,
  `lead_failure_reason` text,
  `lead_failure_note` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `lead_mgmt`
--

CREATE TABLE `lead_mgmt` (
  `lead_id` int(11) NOT NULL,
  `lead_fname` varchar(255) DEFAULT NULL,
  `lead_lname` varchar(255) DEFAULT NULL,
  `lead_status` enum('1','0') DEFAULT '1',
  `lead_salutationtype` varchar(10) DEFAULT NULL,
  `lead_phone` varchar(20) DEFAULT NULL,
  `lead_company` varchar(255) DEFAULT NULL,
  `lead_mobile` varchar(20) DEFAULT NULL,
  `lead_designation` varchar(255) DEFAULT NULL,
  `lead_fax` varchar(20) DEFAULT NULL,
  `lead_source` varchar(255) DEFAULT NULL,
  `lead_email` varchar(255) DEFAULT NULL,
  `lead_industry` varchar(255) DEFAULT NULL,
  `lead_website` varchar(255) DEFAULT NULL,
  `lead_anrevenue` varchar(255) DEFAULT NULL,
  `leads_status` varchar(255) DEFAULT NULL,
  `lead_emp_no` varchar(255) DEFAULT NULL,
  `lead_rating` varchar(255) DEFAULT NULL,
  `lead_second_email` varchar(255) DEFAULT NULL,
  `lead_assigned_to` varchar(255) DEFAULT NULL,
  `lead_optout` varchar(10) DEFAULT NULL,
  `lead_street` text,
  `lead_pobox` varchar(255) DEFAULT NULL,
  `lead_postal_code` varchar(10) DEFAULT NULL,
  `lead_city` varchar(255) DEFAULT NULL,
  `lead_country` varchar(255) DEFAULT NULL,
  `lead_state` varchar(255) DEFAULT NULL,
  `lead_description` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lead_mgmt`
--

INSERT INTO `lead_mgmt` (`lead_id`, `lead_fname`, `lead_lname`, `lead_status`, `lead_salutationtype`, `lead_phone`, `lead_company`, `lead_mobile`, `lead_designation`, `lead_fax`, `lead_source`, `lead_email`, `lead_industry`, `lead_website`, `lead_anrevenue`, `leads_status`, `lead_emp_no`, `lead_rating`, `lead_second_email`, `lead_assigned_to`, `lead_optout`, `lead_street`, `lead_pobox`, `lead_postal_code`, `lead_city`, `lead_country`, `lead_state`, `lead_description`) VALUES
(1, 'Michel', 'Shone', '1', 'Mr.', '+94888885566', 'Example Inc.', '69588599665', 'CEO', '4545885', '8', 'shone.michel@example.com', '1', 'http://www.example.com', '120000', '4', '1200', '1', 'shone2@example.com', '7', '1', '#suit 1 ', '123456', '123456', 'california', 'USA', 'california', 'This client is from usa'),
(2, 'dfdsf', 'dfgdfg', '1', 'Mr.', '123456868686', 'asdsad', '23432312334234', 'sadasd', '234234234', '2', '1234@dsd.com', '1', 'http://dfdsf.com', '120000', '1', '1200', '1', 'ravi.shahi@sc.com', '5', '1', 'sadsadsad', '123456', '123456', 'asdsad', 'sadsad', 'sadsadsad', 'dfdsfds');

-- --------------------------------------------------------

--
-- Table structure for table `lead_rating`
--

CREATE TABLE `lead_rating` (
  `rating_id` int(11) NOT NULL,
  `rating_name` varchar(255) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lead_rating`
--

INSERT INTO `lead_rating` (`rating_id`, `rating_name`, `created_date`, `updated_date`) VALUES
(1, 'Acquired', '2017-02-21 10:05:35', '2017-02-21 15:35:35'),
(2, 'sdfdsf', '2017-03-07 09:40:12', '2017-03-07 15:10:12');

-- --------------------------------------------------------

--
-- Table structure for table `lead_source`
--

CREATE TABLE `lead_source` (
  `source_id` int(11) NOT NULL,
  `source_name` varchar(255) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lead_source`
--

INSERT INTO `lead_source` (`source_id`, `source_name`, `created_date`, `update_date`) VALUES
(1, 'Cold Call', '2017-02-21 09:03:32', '2017-02-21 14:33:32'),
(2, 'Existing customer', '2017-02-21 09:05:03', '2017-02-21 14:35:03'),
(3, 'Self Generated', '2017-02-21 09:05:19', '2017-02-21 14:35:19'),
(4, 'Employee', '2017-02-21 09:05:32', '2017-02-21 14:35:32'),
(5, 'partner', '2017-02-21 09:05:45', '2017-02-21 14:35:45'),
(6, 'public relations', '2017-02-21 09:05:57', '2017-02-21 14:35:57'),
(7, 'Direct Mail', '2017-02-21 09:06:17', '2017-02-21 14:36:17'),
(8, 'Conference', '2017-02-21 09:06:31', '2017-02-21 14:36:31'),
(9, 'Trade Show', '2017-02-21 09:06:44', '2017-02-21 14:36:44'),
(10, 'website', '2017-02-21 09:07:03', '2017-02-21 14:37:03'),
(11, 'Word of Mouth', '2017-02-21 09:07:10', '2017-02-21 14:37:10'),
(12, 'others', '2017-02-21 09:07:18', '2017-02-21 14:37:18'),
(13, 'rdfgdfg', '2017-03-07 09:39:53', '2017-03-07 15:09:53');

-- --------------------------------------------------------

--
-- Table structure for table `lead_status`
--

CREATE TABLE `lead_status` (
  `status_id` int(11) NOT NULL,
  `status_name` varchar(255) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lead_status`
--

INSERT INTO `lead_status` (`status_id`, `status_name`, `created_date`, `updated_date`) VALUES
(1, 'Attemplted to contacts', '2017-02-21 07:15:29', '2017-02-21 12:45:29'),
(2, 'Cold', '2017-02-21 08:30:23', '2017-02-21 14:00:23'),
(3, 'Contact in Future', '2017-02-21 08:30:32', '2017-02-21 14:00:32'),
(4, 'Contacted', '2017-02-21 08:30:45', '2017-02-21 14:00:45'),
(5, 'Hot', '2017-02-21 08:30:50', '2017-02-21 14:00:50'),
(6, 'Junk lead', '2017-02-21 08:31:10', '2017-02-21 14:01:10'),
(7, 'Lost lead', '2017-02-21 08:31:17', '2017-02-21 14:01:17'),
(8, 'Not contacted', '2017-02-21 08:31:30', '2017-02-21 14:01:30'),
(9, 'Pre Qualified', '2017-02-21 08:31:39', '2017-02-21 14:01:39'),
(10, 'Qualified', '2017-02-21 08:31:52', '2017-02-21 14:01:52'),
(11, 'Warm', '2017-02-21 08:32:01', '2017-02-21 14:02:01'),
(12, '', '2017-03-07 09:21:35', '2017-03-07 14:51:35'),
(13, '', '2017-03-07 09:28:36', '2017-03-07 14:58:36'),
(14, '', '2017-03-07 09:28:38', '2017-03-07 14:58:38'),
(15, '', '2017-03-07 09:28:41', '2017-03-07 14:58:41'),
(16, 'dfgfdg', '2017-03-07 09:40:08', '2017-03-07 15:10:08');

-- --------------------------------------------------------

--
-- Table structure for table `module`
--

CREATE TABLE `module` (
  `module_id` int(11) NOT NULL,
  `module_name` varchar(255) DEFAULT NULL,
  `module_status` enum('1','0') DEFAULT '1',
  `created_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `update_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `module`
--

INSERT INTO `module` (`module_id`, `module_name`, `module_status`, `created_date`, `update_date`) VALUES
(1, 'users', '1', '2017-03-02 09:49:49', '2017-03-02 15:19:49'),
(2, 'Leads', '1', '2017-03-02 09:49:49', '2017-03-02 15:20:07'),
(3, 'LeadStatus', '1', '2017-03-02 09:49:49', '2017-03-02 15:20:11'),
(6, 'Lead Source', '1', '2017-03-02 10:00:35', '2017-03-02 15:30:35'),
(7, 'Lead Rating', '1', '2017-03-02 10:01:03', '2017-03-02 15:31:03'),
(8, 'Industry', '1', '2017-03-02 10:02:28', '2017-03-02 15:32:28');

-- --------------------------------------------------------

--
-- Table structure for table `permission`
--

CREATE TABLE `permission` (
  `id` int(122) UNSIGNED NOT NULL,
  `user_type` varchar(250) DEFAULT NULL,
  `data` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `permission`
--

INSERT INTO `permission` (`id`, `user_type`, `data`) VALUES
(1, 'Member', '{"users":{"own_create":"1","own_read":"1","own_update":"1","own_delete":"1","all_read":"1","all_update":"1","all_delete":"1"},"Leads":{"own_create":"1","own_read":"1","own_update":"1","own_delete":"1","all_read":"1","all_update":"1","all_delete":"1"},"LeadStatus":"LeadStatus","Lead Source":"Lead_SPACE_Source","Lead Rating":{"own_create":"1","own_read":"1","own_update":"1","own_delete":"1","all_read":"1","all_update":"1","all_delete":"1"},"Industry":"Industry"}'),
(2, 'admin', '{"users":{"own_create":"1","own_read":"1","own_update":"1","own_delete":"1","all_create":"1","all_read":"1","all_update":"1","all_delete":"1"},"Leads":{"own_create":"1","own_read":"1","own_update":"1","own_delete":"1","all_create":"1","all_read":"1","all_update":"1","all_delete":"1"},"LeadStatus":{"own_create":"","own_read":"","own_update":"","own_delete":"","all_create":"","all_read":"","all_update":"","all_delete":""},"Lead Source":{"own_create":"","own_read":"","own_update":"","own_delete":"","all_create":"","all_read":"","all_update":"","all_delete":""},"Lead Rating":{"own_create":"","own_read":"","own_update":"","own_delete":"","all_create":"","all_read":"","all_update":"","all_delete":""},"Industry":{"own_create":"","own_read":"","own_update":"","own_delete":"","all_create":"","all_read":"","all_update":"","all_delete":""}}'),
(3, 'Manager', '{"users":{"own_create":"1","own_read":"1","own_update":"1","own_delete":"1","all_read":"1","all_update":"1","all_delete":"1"},"Leads":{"own_create":"1","own_read":"1","own_update":"1","own_delete":"1","all_read":"1","all_update":"1","all_delete":"1"},"LeadStatus":"LeadStatus","Lead Source":"Lead_SPACE_Source","Lead Rating":"Lead_SPACE_Rating","Industry":"Industry"}'),
(4, 'Client', '{"users":{"own_create":"1","own_read":"1","own_update":"1","own_delete":"1","all_read":"1","all_update":"1","all_delete":"1"},"Leads":{"own_create":"1","own_read":"1","own_update":"1","own_delete":"1","all_read":"1","all_update":"1","all_delete":"1"},"LeadStatus":"LeadStatus","Lead Source":"Lead_SPACE_Source","Lead Rating":"Lead_SPACE_Rating","Industry":"Industry"}'),
(5, 'Pre-Sales', '{"users":"users","Leads":{"own_create":"1","own_read":"1","own_update":"1","own_delete":"1"},"LeadStatus":"LeadStatus","Lead Source":"Lead_SPACE_Source","Lead Rating":"Lead_SPACE_Rating","Industry":"Industry"}'),
(6, 'Developer', '{"users":{"own_create":"1","own_read":"1","own_update":"1","own_delete":"1"},"Leads":"Leads","LeadStatus":"LeadStatus","Lead Source":"Lead_SPACE_Source","Lead Rating":"Lead_SPACE_Rating","Industry":"Industry"}');

-- --------------------------------------------------------

--
-- Table structure for table `setting`
--

CREATE TABLE `setting` (
  `id` int(122) UNSIGNED NOT NULL,
  `keys` varchar(255) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `setting`
--

INSERT INTO `setting` (`id`, `keys`, `value`) VALUES
(1, 'website', 'Lead Management System'),
(2, 'logo', NULL),
(3, 'favicon', NULL),
(4, 'SMTP_EMAIL', 'mayur.panchal@searchnative.in'),
(5, 'HOST', ''),
(6, 'PORT', '25'),
(7, 'SMTP_SECURE', ''),
(8, 'SMTP_PASSWORD', 'Mayur@@123'),
(9, 'mail_setting', 'simple_mail'),
(10, 'company_name', 'Searchnative India Pvt Ltd'),
(11, 'crud_list', 'users,User'),
(12, 'EMAIL', 'mayur.panchal@searchnative.in'),
(13, 'UserModules', 'yes'),
(14, 'register_allowed', '0'),
(15, 'email_invitation', '1'),
(16, 'admin_approval', '0'),
(17, 'user_type', '["Member"]');

-- --------------------------------------------------------

--
-- Table structure for table `templates`
--

CREATE TABLE `templates` (
  `id` int(121) UNSIGNED NOT NULL,
  `module` varchar(255) DEFAULT NULL,
  `code` varchar(255) DEFAULT NULL,
  `template_name` varchar(255) DEFAULT NULL,
  `html` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `templates`
--

INSERT INTO `templates` (`id`, `module`, `code`, `template_name`, `html`) VALUES
(1, 'forgot_pass', 'forgot_password', 'Forgot password', '<html xmlns="http://www.w3.org/1999/xhtml"><head>\r\n  <meta name="viewport" content="width=device-width, initial-scale=1.0">\r\n  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">\r\n  <style type="text/css" rel="stylesheet" media="all">\r\n    /* Base ------------------------------ */\r\n    *:not(br):not(tr):not(html) {\r\n      font-family: Arial, ''Helvetica Neue'', Helvetica, sans-serif;\r\n      -webkit-box-sizing: border-box;\r\n      box-sizing: border-box;\r\n    }\r\n    body {\r\n      \r\n    }\r\n    a {\r\n      color: #3869D4;\r\n    }\r\n\r\n\r\n    /* Masthead ----------------------- */\r\n    .email-masthead {\r\n      padding: 25px 0;\r\n      text-align: center;\r\n    }\r\n    .email-masthead_logo {\r\n      max-width: 400px;\r\n      border: 0;\r\n    }\r\n    .email-footer {\r\n      width: 570px;\r\n      margin: 0 auto;\r\n      padding: 0;\r\n      text-align: center;\r\n    }\r\n    .email-footer p {\r\n      color: #AEAEAE;\r\n    }\r\n  \r\n    .content-cell {\r\n      padding: 35px;\r\n    }\r\n    .align-right {\r\n      text-align: right;\r\n    }\r\n\r\n    /* Type ------------------------------ */\r\n    h1 {\r\n      margin-top: 0;\r\n      color: #2F3133;\r\n      font-size: 19px;\r\n      font-weight: bold;\r\n      text-align: left;\r\n    }\r\n    h2 {\r\n      margin-top: 0;\r\n      color: #2F3133;\r\n      font-size: 16px;\r\n      font-weight: bold;\r\n      text-align: left;\r\n    }\r\n    h3 {\r\n      margin-top: 0;\r\n      color: #2F3133;\r\n      font-size: 14px;\r\n      font-weight: bold;\r\n      text-align: left;\r\n    }\r\n    p {\r\n      margin-top: 0;\r\n      color: #74787E;\r\n      font-size: 16px;\r\n      line-height: 1.5em;\r\n      text-align: left;\r\n    }\r\n    p.sub {\r\n      font-size: 12px;\r\n    }\r\n    p.center {\r\n      text-align: center;\r\n    }\r\n\r\n    /* Buttons ------------------------------ */\r\n    .button {\r\n      display: inline-block;\r\n      width: 200px;\r\n      background-color: #3869D4;\r\n      border-radius: 3px;\r\n      color: #ffffff;\r\n      font-size: 15px;\r\n      line-height: 45px;\r\n      text-align: center;\r\n      text-decoration: none;\r\n      -webkit-text-size-adjust: none;\r\n      mso-hide: all;\r\n    }\r\n    .button--green {\r\n      background-color: #22BC66;\r\n    }\r\n    .button--red {\r\n      background-color: #dc4d2f;\r\n    }\r\n    .button--blue {\r\n      background-color: #3869D4;\r\n    }\r\n  </style>\r\n</head>\r\n<body style="width: 100% !important;\r\n      height: 100%;\r\n      margin: 0;\r\n      line-height: 1.4;\r\n      background-color: #F2F4F6;\r\n      color: #74787E;\r\n      -webkit-text-size-adjust: none;">\r\n  <table class="email-wrapper" width="100%" cellpadding="0" cellspacing="0" style="\r\n    width: 100%;\r\n    margin: 0;\r\n    padding: 0;">\r\n    <tbody><tr>\r\n      <td align="center">\r\n        <table class="email-content" width="100%" cellpadding="0" cellspacing="0" style="width: 100%;\r\n      margin: 0;\r\n      padding: 0;">\r\n          <!-- Logo -->\r\n\r\n          <tbody>\r\n          <!-- Email Body -->\r\n          <tr>\r\n            <td class="email-body" width="100%" style="width: 100%;\r\n    margin: 0;\r\n    padding: 0;\r\n    border-top: 1px solid #edeef2;\r\n    border-bottom: 1px solid #edeef2;\r\n    background-color: #edeef2;">\r\n              <table class="email-body_inner" align="center" width="570" cellpadding="0" cellspacing="0" style=" width: 570px;\r\n    margin:  14px auto;\r\n    background: #fff;\r\n    padding: 0;\r\n    border: 1px outset rgba(136, 131, 131, 0.26);\r\n    box-shadow: 0px 6px 38px rgb(0, 0, 0);\r\n       ">\r\n                <!-- Body content -->\r\n                <thead style="background: #3869d4;"><tr><th><div align="center" style="padding: 15px; color: #000;"><a href="{var_action_url}" class="email-masthead_name" style="font-size: 16px;\r\n      font-weight: bold;\r\n      color: #bbbfc3;\r\n      text-decoration: none;\r\n      text-shadow: 0 1px 0 white;">{var_sender_name}</a></div></th></tr>\r\n                </thead>\r\n                <tbody><tr>\r\n                  <td class="content-cell" style="padding: 35px;">\r\n                    <h1>Hi {var_user_name},</h1>\r\n                    <p>You recently requested to reset your password for your {var_website_name} account. Click the button below to reset it.</p>\r\n                    <!-- Action -->\r\n                    <table class="body-action" align="center" width="100%" cellpadding="0" cellspacing="0" style="\r\n      width: 100%;\r\n      margin: 30px auto;\r\n      padding: 0;\r\n      text-align: center;">\r\n                      <tbody><tr>\r\n                        <td align="center">\r\n                          <div>\r\n                            <!--[if mso]><v:roundrect xmlns:v="urn:schemas-microsoft-com:vml" xmlns:w="urn:schemas-microsoft-com:office:word" href="{{var_action_url}}" style="height:45px;v-text-anchor:middle;width:200px;" arcsize="7%" stroke="f" fill="t">\r\n                              <v:fill type="tile" color="#dc4d2f" />\r\n                              <w:anchorlock/>\r\n                              <center style="color:#ffffff;font-family:sans-serif;font-size:15px;">Reset your password</center>\r\n                            </v:roundrect><![endif]-->\r\n                            <a href="{var_varification_link}" class="button button--red" style="background-color: #dc4d2f;display: inline-block;\r\n      width: 200px;\r\n      background-color: #3869D4;\r\n      border-radius: 3px;\r\n      color: #ffffff;\r\n      font-size: 15px;\r\n      line-height: 45px;\r\n      text-align: center;\r\n      text-decoration: none;\r\n      -webkit-text-size-adjust: none;\r\n      mso-hide: all;">Reset your password</a>\r\n                          </div>\r\n                        </td>\r\n                      </tr>\r\n                    </tbody></table>\r\n                    <p>If you did not request a password reset, please ignore this email or reply to let us know.</p>\r\n                    <p>Thanks,<br>{var_sender_name} and the {var_website_name} Team</p>\r\n                   <!-- Sub copy -->\r\n                    <table class="body-sub" style="margin-top: 25px;\r\n      padding-top: 25px;\r\n      border-top: 1px solid #EDEFF2;">\r\n                      <tbody><tr>\r\n                        <td> \r\n                          <p class="sub" style="font-size:12px;">If you are having trouble clicking the password reset button, copy and paste the URL below into your web browser.</p>\r\n                          <p class="sub"  style="font-size:12px;"><a href="{var_varification_link}">{var_varification_link}</a></p>\r\n                        </td>\r\n                      </tr>\r\n                    </tbody></table>\r\n                  </td>\r\n                </tr>\r\n              </tbody></table>\r\n            </td>\r\n          </tr>\r\n        </tbody></table>\r\n      </td>\r\n    </tr>\r\n  </tbody></table>\r\n\r\n\r\n</body></html>'),
(3, 'users', 'invitation', 'Invitation', '<p>Hello <strong>{var_user_email}</strong></p>\n\n<p>Click below link to register&nbsp;<br />\n{var_inviation_link}</p>\n\n<p>Thanks&nbsp;</p>\n');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `users_id` int(121) NOT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  `var_key` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `is_deleted` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `profile_pic` varchar(255) DEFAULT NULL,
  `user_type` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`users_id`, `user_id`, `var_key`, `status`, `is_deleted`, `name`, `password`, `email`, `profile_pic`, `user_type`) VALUES
(1, '1', '$2y$10$hWAOAsVvtYBv.RMW3v4ro.DtWBNaV8dIW4IZhQEa4X7X6tEOglKvi', 'active', '0', 'admin', '$2y$10$drKXWzo4Q9wWzukIBpJQAenPw4u1f9YSi/05XQEjglRdlqgaPHzkq', 'admin@searchnative.in', 'mypic_1487652318.jpeg', 'admin'),
(5, '1', NULL, 'active', '0', 'Brijesh Dhami', '$2y$10$tougsoLCJIfYTvP.kTBE.uuJUM/DJjFyEMl5QWUo0pmR2pBIpA/xu', 'brijesh.dhami@searchnative.in', 'mypic_1488437340.jpeg', 'Developer'),
(6, '1', NULL, 'active', '0', 'Jon Doe', '$2y$10$zo2Gacpup060T/39tuG4J.PtebCS94JXgJsJ1p.sjddxZnDN0VVzS', 'sachin.prajapati@searchnative.in', '40_1488516807.jpg', 'Client'),
(7, '1', NULL, 'active', '0', 'Keyur Choksi', '$2y$10$SvR7gcX5nn9HYfbWA1AjWOjxufm4zwu7WtDigu4oVW3t5N8UyVO6q', 'k.chokshi@searchnative.in', '16_1488516918.jpg', 'Pre-Sales'),
(8, NULL, 'FPKVaHN4', NULL, NULL, NULL, NULL, 'mayur.ghadiya@searchnative.in', NULL, NULL),
(9, '1', '', 'active', '0', 'max', '$2y$10$ggsIQRXUy7Av/hRm1JZK5.IWVqJcwfB21y73HgyYQX8fdE7lDy9ca', 'mayur.panchal@searchnative.in', 'user.png', 'Developer');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`client_id`);

--
-- Indexes for table `comment`
--
ALTER TABLE `comment`
  ADD PRIMARY KEY (`comment_id`),
  ADD KEY `lead_id` (`lead_id`);

--
-- Indexes for table `industry`
--
ALTER TABLE `industry`
  ADD PRIMARY KEY (`ind_id`);

--
-- Indexes for table `lead_mgmt`
--
ALTER TABLE `lead_mgmt`
  ADD PRIMARY KEY (`lead_id`);

--
-- Indexes for table `lead_rating`
--
ALTER TABLE `lead_rating`
  ADD PRIMARY KEY (`rating_id`);

--
-- Indexes for table `lead_source`
--
ALTER TABLE `lead_source`
  ADD PRIMARY KEY (`source_id`);

--
-- Indexes for table `lead_status`
--
ALTER TABLE `lead_status`
  ADD PRIMARY KEY (`status_id`);

--
-- Indexes for table `module`
--
ALTER TABLE `module`
  ADD PRIMARY KEY (`module_id`);

--
-- Indexes for table `permission`
--
ALTER TABLE `permission`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `setting`
--
ALTER TABLE `setting`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `templates`
--
ALTER TABLE `templates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`users_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `client`
--
ALTER TABLE `client`
  MODIFY `client_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `comment`
--
ALTER TABLE `comment`
  MODIFY `comment_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `industry`
--
ALTER TABLE `industry`
  MODIFY `ind_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `lead_mgmt`
--
ALTER TABLE `lead_mgmt`
  MODIFY `lead_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `lead_rating`
--
ALTER TABLE `lead_rating`
  MODIFY `rating_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `lead_source`
--
ALTER TABLE `lead_source`
  MODIFY `source_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `lead_status`
--
ALTER TABLE `lead_status`
  MODIFY `status_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `module`
--
ALTER TABLE `module`
  MODIFY `module_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `permission`
--
ALTER TABLE `permission`
  MODIFY `id` int(122) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `setting`
--
ALTER TABLE `setting`
  MODIFY `id` int(122) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `templates`
--
ALTER TABLE `templates`
  MODIFY `id` int(121) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `users_id` int(121) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `comment`
--
ALTER TABLE `comment`
  ADD CONSTRAINT `Leadforeignkey` FOREIGN KEY (`lead_id`) REFERENCES `lead_mgmt` (`lead_id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
