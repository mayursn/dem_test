<?php defined('BASEPATH') or exit('No direct script access allowed');

// form validation configuration

$config = [
  
    /**
     * User login
     */
    'user_login' => [
        [
            'field' => 'txtemail',
            'label' => 'Email',
            'rules' => 'required|trim|max_length[254]|min_length[3]',
        ],
        [
            'field' => 'txtpassword',
            'label' => 'Password',
            'rules' => 'required|trim|min_length[6]',
        ],
    ],

    /**
     * Admin profile
     */
    'admin_profile' => [
        [
            'field' => 'txtname',
            'label' => 'Name',
            'rules' => 'required|trim|max_length[35]|regex_match[/^[a-zA-Z ]+$/]',
            'errors' => [
                'regex_match' => '%s only allowed to enter letters(a-z) and space',
            ],
        ],
        [
            'field' => 'txtemail',
            'label' => 'Email',
            'rules' => 'required|trim|max_length[254]|min_length[3]|valid_email',
        ],        
        [
            'field' => 'txtphone',
            'label' => 'Phone',
            'rules' => 'trim|regex_match[/^[+]?[0-9]{5,15}$/]',
            'errors' => [
                'regex_match' => 'The %s field is not valid',
            ],
        ],
    ],


    /**
     * Admin profile
     */
    'adminmanage_profile' => [
        [
            'field' => 'txtname',
            'label' => 'Name',
            'rules' => 'required|trim|max_length[35]|regex_match[/^[a-zA-Z ]+$/]',
            'errors' => [
                'regex_match' => '%s only allowed to enter letters(a-z) and space',
            ],
        ],
        [
            'field' => 'txtemail',
            'label' => 'Email',
            'rules' => 'required|trim|max_length[254]|min_length[3]|valid_email|is_unique[admin.admin_email]',
            'errors' => ['is_unique' => 'That email is already taken.']
        ],        
        [
            'field' => 'txtphone',
            'label' => 'Phone',
            'rules' => 'trim|regex_match[/^[+]?[0-9]{5,15}$/]',
            'errors' => [
                'regex_match' => 'The %s field is not valid',
            ],
        ],
         [
            'field' => 'newpass',
            'label' => 'Password',
            'rules' => 'trim|min_length[6]|max_length[128]',
        ],
        [
            'field' => 'confpass',
            'label' => 'Confirm password',
            'rules' => 'trim|matches[newpass]',
        ],
    ],

    
    'reports' => [
        [
            'field' => 'type',
            'label' => 'Type',
            /*'rules' => 'required|trim|max_length[35]|regex_match[/^[a-zA-Z ]+$/]',
            'errors' => [
                'regex_match' => '%s only allowed to enter letters(a-z) and space',
            ],*/
        ],
        [
            'field' => 'from_date',
            'label' => 'From Date',
            'rules' => 'required',
        ],
        [
            'field' => 'to_date',
            'label' => 'To Date',
            'rules' => 'required',
        ],
        [
            'field' => 'location',
            'label' => 'Location',
            'rules' => 'required',
        ],   
        
        [
            'field' => 'radius',
            'label' => 'Radius',
            'rules' => 'trim|regex_match[/^\d+$/]',
            'errors' => [
                'regex_match' => '%s field is not valid',
            ],
        ],
        [
            'field' => 'latitude',
            'label' => 'Latitude',
            'rules' => 'trim|required'
        ],
        [
            'field' => 'longitude',
            'label' => 'Longitude',
            'rules' => 'trim|required'
        ],
    ],
    /**
     * Admin profile
     */
    'adminmanageedit_profile' => [
        [
            'field' => 'txtname',
            'label' => 'Name',
            'rules' => 'required|trim|max_length[35]|regex_match[/^[a-zA-Z ]+$/]',
            'errors' => [
                'regex_match' => '%s only allowed to enter letters(a-z) and space',
            ],
        ],
        [
            'field' => 'txtemail',
            'label' => 'Email',
            'rules' => 'required|trim|max_length[254]|min_length[3]|valid_email',
        ],        
        [
            'field' => 'txtphone',
            'label' => 'Phone',
            'rules' => 'trim|regex_match[/^[+]?[0-9]{5,15}$/]',
            'errors' => [
                'regex_match' => 'The %s field is not valid',
            ],
        ],
    ],



    /**
     * Change password
     */
    'change_password' => [
        [
            'field' => 'newpass',
            'label' => 'Password',
            'rules' => 'required|trim|min_length[6]|max_length[128]',
        ],
        [
            'field' => 'confpass',
            'label' => 'Confirm password',
            'rules' => 'required|trim|matches[newpass]',
        ],
    ],


    /**
     * Password reset
     */
    'password_reset' => [
        [
            'field' => 'txtpassword',
            'label' => 'Password',
            'rules' => 'required|trim|min_length[6]|max_length[128]',
        ],
        [
            'field' => 'txtconfirmpassword',
            'label' => 'Confirm password',
            'rules' => 'required|trim|matches[txtpassword]',
        ],
    ],

     /**
     * Password reset
     */
    'api_password_reset' => [
        [
            'field' => 'txtpassword',
            'label' => 'Password',
            'rules' => 'required|trim|min_length[6]|max_length[128]',
        ],
        [
            'field' => 'txtconfirmpassword',
            'label' => 'Confirm password',
            'rules' => 'required|trim|matches[txtpassword]',
        ],
        [
            'field' => 'otp',
            'label' => 'OTP',
            'rules' => 'required|trim',
        ],
        [
            'field' => 'users_id',
            'label' => 'User ID',
            'rules' => 'required|trim',
        ],
    ],

    /**
     * Forgot password
     */
    'forgot_password' => [
        [
            'field' => 'txtemail',
            'label' => 'Email',
            'rules' => 'required|trim|max_length[254]|min_length[3]',
        ],
    ],

     /**
     * Forgot password
     */
    'user_forgot_password' => [
        [
            'field' => 'email',
            'label' => 'Email',
            'rules' => 'required|trim|max_length[254]|min_length[3]',
        ],
    ],


      /**
     * General settings
     */
    'general_settings' => [
        [
            'field' => 'site_name',
            'label' => 'Website name',
            'rules' => 'required|trim',
        ],       
        
        [
            'field' => 'site_email',
            'label' => 'Website email',
            'rules' => 'required|trim|valid_email|max_length[254]|min_length[3]',
        ],
        [
            'field' => 'site_phone',
            'label' => 'Phone',
            'rules' => 'required|trim|regex_match[/^[+]?[0-9]{5,15}$/]',
            'errors' => [
                'regex_match' => 'The %s field is not valid',
            ],
        ],
    ],



    /**
     * Users Create
     */
    'Create' => [
        [
            'field' => 'firstname',
            'label' => 'First name',
            'rules' => 'required|trim',
        ], 
        [
            'field' => 'lastname',
            'label' => 'Last name',
            'rules' => 'required|trim',
        ], 
        [
            'field' => 'txtname',
            'label' => 'Username',
            'rules' => 'required|trim|alpha_numeric|is_unique[users.users_name]',
        ], 
        [
            'field' => 'txtemail',
            'label' => 'email',
            'rules' => 'trim|valid_email|max_length[254]|min_length[3]|is_unique[users.users_email]',
        ],      
        [
            'field' => 'newpass',
            'label' => 'Password',
            'rules' => 'required|trim|min_length[6]',
        ],
        [
            'field' => 'confpass',
            'label' => 'Confirm password',
            'rules' => 'required|trim|matches[newpass]',
        ], 
        [
            'field' => 'txtphone',
            'label' => 'Phone',
            'rules' => 'required|trim|regex_match[/^[+]?[0-9]{5,15}$/]',
            'errors' => [
                'regex_match' => 'The %s field is not valid',
            ],
        ],
        [
            'field' => 'users_zip',
            'label' => 'Zip code',
            'rules' => 'required|trim|min_length[4]|max_length[6]|numeric',
        ],

        [
            'field' => 'users_address',
            'label' => 'Address',
            'rules' => 'required|trim',            
        ], 
        [
            'field' => 'users_latitude',
            'label' => 'Latitude',
            'rules' => 'required|trim'
        ],        
        [
            'field' => 'users_longitude',
            'label' => 'Longitude',
            'rules' => 'required|trim'
        ], 
    ],

    'cmspages/create' => [
        [
            'field' => 'txtname',
            'label' => 'Title',
            'rules' => 'required|trim',
        ], 
        [
            'field' => 'cms_content',
            'label' => 'Content',
            'rules' => 'required|trim',
        ], 
    ],

    'cmspages/edit' => [
        [
            'field' => 'txtname',
            'label' => 'Title',
            'rules' => 'required|trim',
        ], 
        [
            'field' => 'cms_content',
            'label' => 'Content',
            'rules' => 'required|trim',
        ], 
    ],
    
    'question/create' => [
        [
            'field' => 'txtname',
            'label' => 'Title',
            'rules' => 'required|trim',
        ], 
        [
            'field' => 'option1',
            'label' => 'Option 1',
            'rules' => 'required|trim',
        ], 
        [
            'field' => 'option2',
            'label' => 'Option 2',
            'rules' => 'required|trim',
        ] 
        
    ],

    
    
    //==================================================================================
    // API Validation
    //==================================================================================

     /**
     * Api user registration
     */
    'register_post' => [
        [
            'field' => 'fbtoken',
            'label' => 'Facebook Token',
            'rules' => 'required|trim|is_unique[users.fb_token]',
        ],
        [
            'field' => 'email',
            'label' => 'Email',
            'rules' => 'trim|max_length[254]|min_length[3]|is_unique[user.email]|valid_email',
        ],
        [
            'field' => 'firstname',
            'label' => 'Firstname',
            'rules' => 'required|trim',
        ],
        [
            'field' => 'lasname',
            'label' => 'Lastname',
            'rules' => 'required|trim',
        ],
    ],



    
    /**
     * Api forgot password
     */
    'forgot_password_post' => [
        [
            'field' => 'username',
            'label' => 'Username',
            'rules' => 'required|trim|max_length[254]|min_length[3]',
        ],
    ],

    /**
     * Api Set Preference
     */
    'preference/setPreferences_post' => [
        [
            'field' => 'preference_id',
            'label' => 'Preference',
            'rules' => 'required',
        ],
        [
            'field' => 'option_id',
            'label' => 'option',
            'rules' => 'required',
        ],
        [
            'field' => 'users_id',
            'label' => 'User',
            'rules' => 'required',
        ],
    ],

    

    /**
     * Change password
     */
    'change_password_post' => [
        [
            'field' => 'original_password',
            'label' => 'Original password',
            'rules' => 'required|trim',
        ],
        [
            'field' => 'password',
            'label' => 'Password',
            'rules' => 'required|trim|min_length[6]',
        ],
        [
            'field' => 'confirm_password',
            'label' => 'Confirm password',
            'rules' => 'required|trim',
        ],
        [
            'field' => 'user_id',
            'label' => 'Userid',
            'rules' => 'required|trim|is_natural_no_zero',
        ],
    ],
    



    /**
     * Api user registration
     */
    'register' => [        
        [
            'field' => 'email',
            'label' => 'Email',
            'rules' => 'required|trim|max_length[254]|min_length[3]|valid_email',
             'errors' => array(
                        'required' => 'You must provide a %s.'                        
                ),
        ],
        [
            'field' => 'firstname',
            'label' => 'Firstname',
            'rules' => 'required|trim',
        ],
        [
            'field' => 'lastname',
            'label' => 'Lastname',
            'rules' => 'required|trim',
        ],
        [
            'field' => 'password',
            'label' => 'Password',
            'rules' => 'required|trim',
        ],        
    ],


    /**
     * Api validation for email signup user edit profile
     */
    'setPreferences' => [        
        [
            'field' => 'firstname',
            'label' => 'Firstname',
            'rules' => 'required|trim',
             'errors' => array(
                        'required' => 'You must provide a %s.',                        
                ),
        ],        
        [
            'field' => 'lastname',
            'label' => 'Lastname',
            'rules' => 'required|trim',
             'errors' => array(
                        'required' => 'You must provide a %s.',                        
                ),
        ], 
        
        [
            'field' => 'dob',
            'label' => 'Date of birth',
            'rules' => 'required|trim',
             'errors' => array(
                        'required' => 'You must provide a %s.',                        
                ),
        ], 
    ],



    /**
     * Check otp validation
     */
    'checkotp' => [        
        [
            'field' => 'email',
            'label' => 'Email',
            'rules' => 'required|trim',
             'errors' => array(
                        'required' => 'You must provide a %s.',                        
                ),
        ],        
        [
            'field' => 'otp',
            'label' => 'OTP',
            'rules' => 'required|trim',
        ],        
    ],

      /**
     * Api user registration
     */
    'login' => [        
        [
            'field' => 'email',
            'label' => 'Email',
            'rules' => 'required|trim|valid_email',
             'errors' => array(
                        'required' => 'You must provide a %s.',                        
                ),
        ],        
        [
            'field' => 'password',
            'label' => 'Password',
            'rules' => 'required|trim',
        ],        
    ],



    /**
     * Api user registration
     */
    'signup' => [
        [
            'field' => 'fbtoken',
            'label' => 'Facebook Token',
            'rules' => 'required|trim',
        ],
        [
            'field' => 'email',
            'label' => 'Email',
            'rules' => 'trim|max_length[254]|min_length[3]|valid_email',
        ],
        [
            'field' => 'firstname',
            'label' => 'Firstname',
            'rules' => 'required|trim',
        ],
        [
            'field' => 'lastname',
            'label' => 'Lastname',
            'rules' => 'required|trim',
        ],
    ],



    /**
     * Api questions answers
     */
    'question_answer' => [
        [
            'field' => 'question_id',
            'label' => 'Question Id',
            'rules' => 'required|trim',
        ],
        [
            'field' => 'users_id',
            'label' => 'User Id',
            'rules' => 'required|trim',
        ],
        [
            'field' => 'answer_id',
            'label' => 'Answer Id',
            'rules' => 'required|trim',
        ]
    ],


  
];
