<?php

class User_interest_model extends MY_Model
{

    public function __construct()
    {
        $this->table = 'user_interest';
        
        $this->primary_key = 'interest_id';

    //callbacks
        $this->before_create = array('timestamps');
   
   
        parent::__construct();
    }
	

     /**
     * Create timestamps before new user created
     * @param  array $user
     * @return array
     */
    protected function timestamps($user)
    {
        $user['created_date'] =  date('Y-m-d H:i:s');

        return $user;
    }

    public function mutualInteres($users_id,$profile_user_id){

        return  $this->db->query("SELECT fb_like_id,name FROM user_interest WHERE users_id='$users_id' AND fb_like_id IN ( SELECT fb_like_id FROM user_interest WHERE users_id='$profile_user_id' )")->result();
    }

    
}
?>