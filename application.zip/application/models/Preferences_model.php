<?php

class Preferences_model extends MY_Model
{

     public function __construct()
    {
        $this->table = 'preferences';
        $this->primary_key = 'preferences_option_id';
        $this->soft_deletes = false;
        $this->before_create = array('timestamps');
        $this->order = array($this->table.'.preferences_option_id' => 'desc');

        parent::__construct();
    }
    
    //callbacks
   
     /**
     * Create timestamps before new user created
     * @param  array $user
     * @return array
     */
    protected function timestamps($user)
    {
        $user['created_date'] = $user['updated_date'] = date('Y-m-d H:i:s');

        return $user;
    }


}
?>