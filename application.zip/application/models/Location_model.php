<?php

class Location_model extends MY_Model
{


     public function __construct()
    {
        $this->table = 'location';
        $this->primary_key = 'location_id';
      
      
        parent::__construct();
    }
    

    
    

}
?>