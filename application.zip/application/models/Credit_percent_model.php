<?php
# credit model is purchasing Additional Credits table
# which is store all details of amount of credits for purchase
# 
class Credit_percent_model extends MY_Model
{

     public function __construct()
    {
        $this->table = 'credit_percent';
        $this->primary_key = 'id';         
        
        parent::__construct();
    }

    
   


}
?>