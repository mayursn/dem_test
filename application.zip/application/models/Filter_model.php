<?php
/**
* Filter model is used for filter api and card view api
* Special match, near by, match %, and last online and card view functionality is query here. 
* Special match based on preference and question,
* near by user funcationality is based on near by city country
* matching % is based on question answer and preference base
* last online means who user is online now
* card view functionality is based on preferences
* all the query have some similiar condition is looking for, age, lat long, and blocked user and dislike users 
*/

class Filter_model extends CI_Model

{
    public function __construct()
    {
        parent::__construct();
    }

  
    // two method is deprecated and not being used in filter controller so ignore it in update queries specialMatch() & specialMatchNumRows()

    /**
     * Special Match Number of rows
     * @param $where,$where_in,$userdetails
     * @return response number of rows int
     * Now not being in used
     */
    function specialMatchNumRows($where, $where_in, $userdetails)
    {
        if($userdetails->users_latitude!="" && $userdetails->users_longitude!=""){
            
        $distance = "( 3959 * acos( cos( radians($userdetails->users_latitude) ) * cos( radians( users_latitude ) ) * cos( radians( users_longitude ) - radians($userdetails->users_longitude) ) + sin( radians($userdetails->users_latitude) ) * sin( radians( users_latitude ) ) ) ) AS distance";

        $distance_where = "having distance < 50";

        }else{

            $distance = "";

            $distance_where  = "";

        }

        if($userdetails->looking_for != ""){

            $looking_for ="AND users_gender='$userdetails->looking_for'";    

            if($userdetails->looking_for =="Male & Female"){
                $looking_for = '';
            }

            

        }
        else{

            $looking_for = "";

        }
       if($userdetails->from_age!="" && $userdetails->to_age!="" && $userdetails->from_age >= 18 && $userdetails->to_age >= 18){

         $age = "AND ((users_age BETWEEN '$userdetails->from_age' AND '$userdetails->to_age') OR users_age='0')";
       

        }else{

            $age = "";

        }

       if($userdetails->saved_height!=""){

            $heights = explode("To", $userdetails->saved_height);

            $from_height = $heights[0];

            $to_height = $heights[1];
            if($from_height!="" && $to_height!=""){

            $height = " AND (users_height BETWEEN '$from_height' AND '$to_height')";
            }else{
                $height = "";
            }

        }else{

            $height = "";

        }


       

         return $this->db->query("SELECT DISTINCT(users.users_id
            ),users_fname,users_lname,IFNULL(name, '') as name,IFNULL(users_age, '') as users_age, IFNULL(about, '') as self_summery,$distance FROM users LEFT JOIN user_preference ON users.users_id=user_preference.users_id LEFT JOIN location ON location.location_id=users.users_location WHERE users_status='1' $where $looking_for $age $height $where_in ORDER BY credit_percent DESC group by users.users_id $distance_where ")->num_rows();
         

    }

    /**
     * Special Match Number of rows
     * @param $where,$where_in,$userdetails,$page,$perpage
     * @return response result array
     * Now not being in used
     */
    function specialMatch($where, $where_in, $userdetails, $page, $perPage)
    {
        if($userdetails->users_latitude!="" && $userdetails->users_longitude!=""){

        $distance = "( 3959 * acos( cos( radians($userdetails->users_latitude) ) * cos( radians( users_latitude ) ) * cos( radians( users_longitude ) - radians($userdetails->users_longitude) ) + sin( radians($userdetails->users_latitude) ) * sin( radians( users_latitude ) ) ) ) AS distance";

        $distance_where = "having distance < 50";


        }else{

            $distance = "";

            $distance_where  = "";

        }

        if($userdetails->looking_for!= "" ) {

          $looking_for ="AND users_gender='$userdetails->looking_for'";    

            if($userdetails->looking_for =="Male & Female"){
                $looking_for = '';
            }


        }
        else{

            $looking_for = "";

        }
        if($userdetails->from_age!="" && $userdetails->to_age!="" && $userdetails->from_age >= 18 && $userdetails->to_age >= 18){

         $age = "AND ((users_age BETWEEN '$userdetails->from_age' AND '$userdetails->to_age') OR users_age='0')";
       

        }else{

            $age = "";

        }

        if($userdetails->saved_height!=""){

            $heights = explode("To", $userdetails->saved_height);

            $from_height = $heights[0];

            $to_height = $heights[1];
            if($from_height!="" && $to_height!=""){

            $height = " AND (users_height BETWEEN '$from_height' AND '$to_height')";
            }else{
                $height = "";
            }

        }else{

            $height = "";

        }

        
        $page = ($page * $perPage);

        return $this->db->query("SELECT DISTINCT(users.users_id
            ),concat(users_fname,' ',users_lname) as name,IFNULL(location.name,'') as users_location,IFNULL(users_age, '') as users_age, IFNULL(about,'') as self_summery,$distance FROM users LEFT JOIN user_preference ON users.users_id=user_preference.users_id LEFT JOIN location ON location.location_id=users.users_location WHERE users_status='1' $where $looking_for $age $height $where_in ORDER BY credit_percent DESC group by users.users_id   $distance_where LIMIT $page,$perPage")->result();
    }

    /**
     * Today and yesterday register user list
     * @param $userdetails array
     * @return response number of rows
     */
    function lastJoinedUsersNumrows($userdetails, $where_in,$where_pref)
    {
        $latitude = $userdetails->users_latitude;

        $longitude = $userdetails->users_longitude;

        $from_age = $userdetails->from_age;

        $to_age = $userdetails->to_age;

        $looking_for = $userdetails->looking_for;

        $today = date('Y-m-d') . " 23:59:59";

        $yesterday = date('Y-m-d', strtotime("-1 days")) . " 00:00:00";

        $this->db->select("concat(users_fname,' ',users_lname) as name,users.users_id,IFNULL(users_age, '') as users_age,IFNULL(lc.name,'') as users_location,IFNULL(lcc.name,'') as country,( 3959 * acos( cos( radians($latitude) ) * cos( radians( users_latitude ) ) * cos( radians( users_longitude ) - radians($longitude) ) + sin( radians($latitude) ) * sin( radians( users_latitude ) ) ) ) AS distance,IFNULL(users.is_online,'0') as is_onine");

        $this->db->where("users.discovery",'1');

        $this->db->where('users_status', '1');

        $this->db->where("users.created_date BETWEEN '$yesterday' AND NOW()");

        if (!empty($where_in)) {

            $this->db->where($where_in);

        }

         if (!empty($where_pref)) {

            $this->db->where($where_pref);

        }

        if (!empty($from_age) && !empty($to_age)) {

         if($from_age >= 18 && $to_age >=18 ){
                $this->db->where("((users_age BETWEEN '$from_age' AND '$to_age') or users_age='0')");
            }

        }

        if($userdetails->saved_height!=""){

            $heights = explode("To", $userdetails->saved_height);

            $from_height = $heights[0];

            $to_height = $heights[1];
            if($from_height!="" && $to_height!=""){

            $this->db->where(" (users_height BETWEEN '$from_height' AND '$to_height')");
            }

        }

        if ($looking_for != "" && $looking_for != "Male & Female") {

            $this->db->where("users_gender", $looking_for);

        }

        $this->db->having("distance < 50");

        $this->db->join('location lc', "lc.location_id=users.users_location",'left');
        $this->db->join('user_preference up', "up.users_id=users.users_id", 'left');
        $this->db->join('location lcc', "lcc.location_id=users.country",'left');
        $this->db->order_by('credit_percent',"DESC");
        $this->db->order_by('credit_percent_update_time',"DESC");
        $this->db->group_by('users.users_id');
        return $this->db->get('users')->num_rows();
    }

    /**
     * Today and yesterday register user list
     * @param $userdetails array
     * @return response users list
     */
    function lastJoinedUsers($userdetails, $where_in,$where_pref, $page, $perPage)
    {
        $latitude = $userdetails->users_latitude;

        $longitude = $userdetails->users_longitude;

        $from_age = $userdetails->from_age;

        $to_age = $userdetails->to_age;

        $looking_for = $userdetails->looking_for;

        $page = ($page * $perPage);

        $today = date('Y-m-d') . " 23:59:59";

        $yesterday = date('Y-m-d', strtotime("-1 days")) . " 00:00:00";

        $this->db->select("concat(users_fname,' ',users_lname) as name,users.users_id,IFNULL(users_age, '') as users_age,IFNULL(lc.name,'') as users_location,IFNULL(lcc.name,'') as country,IFNULL(users.about,'') as self_summery,( 3959 * acos( cos( radians($latitude) ) * cos( radians( users_latitude ) ) * cos( radians( users_longitude ) - radians($longitude) ) + sin( radians($latitude) ) * sin( radians( users_latitude ) ) ) ) AS distance,IFNULL(users.is_online,'0') as is_onine");

        $this->db->where("users.discovery",'1');

        $this->db->where('users_status', '1');

        $this->db->where("users.created_date BETWEEN '$yesterday' AND NOW()");

        if (!empty($where_in)) {

            $this->db->where($where_in);

        }

         if (!empty($where_pref)) {

            $this->db->where($where_pref);

        }

        if (!empty($from_age) && !empty($to_age)) {

            if($from_age >= 18 && $to_age >=18 ){
                $this->db->where("((users_age BETWEEN '$from_age' AND '$to_age') or users_age='0')");
            }

        }

        if($userdetails->saved_height!=""){

            $heights = explode("To", $userdetails->saved_height);

            $from_height = $heights[0];

            $to_height = $heights[1];
            if($from_height!="" && $to_height!=""){

            $this->db->where(" (users_height BETWEEN '$from_height' AND '$to_height')");
            }

        }

        if ($looking_for != "" && $looking_for != "Male & Female") {

            $this->db->where("users_gender", $looking_for);

        }

        $this->db->having("distance < 50");

        $this->db->join('location lc', "lc.location_id=users.users_location",'left');

        $this->db->join('user_preference up', "up.users_id=users.users_id", 'left');
        $this->db->join('location lcc', "lcc.location_id=users.country",'left');
        $this->db->order_by('credit_percent',"DESC");
        $this->db->order_by('credit_percent_update_time',"DESC");
        $this->db->group_by('users.users_id');
        $this->db->limit($perPage,$page);

        return $this->db->get('users')->result();
    }

    function lastOnlineUserListNumRows($userdetails, $where_in,$where_pref)
    {
        $latitude = $userdetails->users_latitude;
        $longitude = $userdetails->users_longitude;
        $from_age = $userdetails->from_age;
        $to_age = $userdetails->to_age;
        $looking_for = $userdetails->looking_for;
        $this->db->select("concat(users_fname,' ',users_lname) as name,users.users_id,IFNULL(users_age, '') as users_age,IFNULL(lc.name,'') as users_location,IFNULL(lcc.name,'') as country,IFNULL(users.about,'') as self_summery,( 3959 * acos( cos( radians($latitude) ) * cos( radians( users_latitude ) ) * cos( radians( users_longitude ) - radians($longitude) ) + sin( radians($latitude) ) * sin( radians( users_latitude ) ) ) ) AS distance,IFNULL(users.is_online,'0') as is_onine");

        $this->db->where('users_status', '1');
        
        if (!empty($where_in)) {
            $this->db->where($where_in);
        }

        if(!empty($where_pref)){

            $this->db->where($where_pref);

        }

        if (!empty($from_age) && !empty($to_age)) {
           if($from_age >= 18 && $to_age >=18 ){
                $this->db->where("((users_age BETWEEN '$from_age' AND '$to_age') or users_age='0')");
            }
        }

         if($userdetails->saved_height!=""){

            $heights = explode("To", $userdetails->saved_height);

            $from_height = $heights[0];

            $to_height = $heights[1];
            if($from_height!="" && $to_height!=""){

            $this->db->where(" (users_height BETWEEN '$from_height' AND '$to_height')");
            }

        }

        $this->db->where("users.discovery",'1'); // user discovery

        $this->db->where("is_online", '1');

        if ($looking_for != "" && $looking_for != "Male & Female") {
            $this->db->where("users_gender", $looking_for);
        }

        $this->db->having("distance < 50");
        $this->db->join('location lc', "lc.location_id=users.users_location", 'left');
        $this->db->join('user_preference up', "up.users_id=users.users_id", 'left');
        $this->db->join('location lcc', "lcc.location_id=users.country", 'left');
        $this->db->order_by('credit_percent',"DESC");
        $this->db->order_by('credit_percent_update_time',"DESC");
        $this->db->group_by('users.users_id');
        return $this->db->get('users')->num_rows();
    }

    function lastOnlineUserList($userdetails, $where_in,$where_pref, $page, $perPage)
    {
        $page = ($page * $perPage);
       $latitude = $userdetails->users_latitude;
        $longitude = $userdetails->users_longitude;
        $from_age = $userdetails->from_age;
        $to_age = $userdetails->to_age;
        $looking_for = $userdetails->looking_for;
        $this->db->select("concat(users_fname,' ',users_lname) as name,users.users_id,IFNULL(users_age, '') as users_age,IFNULL(lc.name,'') as users_location,IFNULL(lcc.name,'') as country,IFNULL(users.about,'') as self_summery,( 3959 * acos( cos( radians($latitude) ) * cos( radians( users_latitude ) ) * cos( radians( users_longitude ) - radians($longitude) ) + sin( radians($latitude) ) * sin( radians( users_latitude ) ) ) ) AS distance,IFNULL(users.is_online,'0') as is_onine");

        $this->db->where('users_status', '1');
        
        if (!empty($where_in)) {
            $this->db->where($where_in);
        }

        if(!empty($where_pref)){

            $this->db->where($where_pref);

        }

        if (!empty($from_age) && !empty($to_age)) {
           if($from_age >= 18 && $to_age >=18 ){
                $this->db->where("((users_age BETWEEN '$from_age' AND '$to_age') or users_age='0')");
            }
        }

         if($userdetails->saved_height!=""){

            $heights = explode("To", $userdetails->saved_height);

            $from_height = $heights[0];

            $to_height = $heights[1];
            if($from_height!="" && $to_height!=""){

            $this->db->where(" (users_height BETWEEN '$from_height' AND '$to_height')");
            }

        }

        $this->db->where("users.discovery",'1'); // user discovery

        $this->db->where("is_online", '1');

        if ($looking_for != "" && $looking_for != "Male & Female") {
            $this->db->where("users_gender", $looking_for);
        }

        $this->db->having("distance < 50");
        $this->db->join('location lc', "lc.location_id=users.users_location", 'left');
        $this->db->join('user_preference up', "up.users_id=users.users_id", 'left');
        $this->db->join('location lcc', "lcc.location_id=users.country", 'left');
        $this->db->order_by('credit_percent',"DESC");
        $this->db->order_by('credit_percent_update_time',"DESC");
        $this->db->group_by('users.users_id');
        $this->db->limit($perPage,$page);
        return $this->db->get('users')->result();
    }

    function nearByNumrows($userdetails, $where_in,$where_pref)
    {
        $latitude = $userdetails->users_latitude;

        $longitude = $userdetails->users_longitude;

        if(!empty($latitude) && !empty($longitude)){

            $select = ",( 3959 * acos( cos( radians($latitude) ) * cos( radians( users_latitude ) ) * cos( radians( users_longitude ) - radians($longitude) ) + sin( radians($latitude) ) * sin( radians( users_latitude ) ) ) ) AS distance";
                $this->db->having("distance < 50");

        }
        else{
             $select = "";
        }

        $from_age = $userdetails->from_age;

        $to_age = $userdetails->to_age;

        $looking_for = $userdetails->looking_for;

        $users_location = $userdetails->users_location;

        $country = $userdetails->country;

        $this->db->select("concat(users_fname,' ',users_lname) as name,users.users_id,IFNULL(users_age, '') as users_age,IFNULL(lc.name,'') as users_location,IFNULL(lcc.name,'') as country,IFNULL(about,'') as self_summery,IFNULL(users.is_online,'0') as is_onine $select");

        $this->db->where("users.discovery",'1'); // user discovery

        $this->db->where("users_status", '1'); // if user active

        if (!empty($where_in)) {

            $this->db->where($where_in);

        }

        if (!empty($where_pref)) {

            $this->db->where($where_pref);

        }

        if($userdetails->saved_height!=""){

            $heights = explode("To", $userdetails->saved_height);

            $from_height = $heights[0];

            $to_height = $heights[1];
            if($from_height!="" && $to_height!=""){

            $this->db->where(" (users_height BETWEEN '$from_height' AND '$to_height')");
            }

        }

        if (!empty($from_age) && !empty($to_age)) {

           if($from_age >= 18 && $to_age >=18 ){
                $this->db->where("((users_age BETWEEN '$from_age' AND '$to_age') or users_age='0')");
            }

        }

        if ($looking_for != "" && $looking_for != "Male & Female") {

            $this->db->where("users_gender='$looking_for' ");

        }

        $this->db->join('location lc', "lc.location_id=users.users_location", 'left');

         $this->db->join('user_preference up', "up.users_id=users.users_id", 'left');

        $this->db->join('location lcc', "lcc.location_id=users.country", 'left');
        $this->db->order_by('credit_percent',"DESC");
        $this->db->group_by("users.users_id");

         return $this->db->get('users')->num_rows();


       
    }

    function nearBy($userdetails, $where_in,$where_pref, $page, $perPage)
    {
         $page = ($page * $perPage);
    
         $latitude = $userdetails->users_latitude;

        $longitude = $userdetails->users_longitude;

        if(!empty($latitude) && !empty($longitude)){

            $select = ",( 3959 * acos( cos( radians($latitude) ) * cos( radians( users_latitude ) ) * cos( radians( users_longitude ) - radians($longitude) ) + sin( radians($latitude) ) * sin( radians( users_latitude ) ) ) ) AS distance";
                $this->db->having("distance < 50");

        }
        else{
             $select = "";
        }

        $from_age = $userdetails->from_age;

        $to_age = $userdetails->to_age;

        $looking_for = $userdetails->looking_for;

        $users_location = $userdetails->users_location;

        $country = $userdetails->country;

        $this->db->select("concat(users_fname,' ',users_lname) as name,users.users_id,IFNULL(users_age, '') as users_age,IFNULL(lc.name,'') as users_location,IFNULL(lcc.name,'') as country,IFNULL(about,'') as self_summery,IFNULL(users.is_online,'0') as is_onine $select");

        $this->db->where("users.discovery",'1'); // user discovery

        $this->db->where("users_status", '1');

        if (!empty($where_in)) {

            $this->db->where($where_in);

        }

        if (!empty($where_pref)) {

            $this->db->where($where_pref);

        }

        if($userdetails->saved_height!=""){

            $heights = explode("To", $userdetails->saved_height);

            $from_height = $heights[0];

            $to_height = $heights[1];
            if($from_height!="" && $to_height!=""){

            $this->db->where(" (users_height BETWEEN '$from_height' AND '$to_height')");
            }

        }

        if (!empty($from_age) && !empty($to_age)) {

            if($from_age >= 18 && $to_age >=18 ){
                $this->db->where("((users_age BETWEEN '$from_age' AND '$to_age') or users_age='0')");
            }

        }

        if ($looking_for != "" && $looking_for != "Male & Female") {

            $this->db->where("users_gender='$looking_for' ");

        }


        $this->db->join('location lc', "lc.location_id=users.users_location", 'left');

         $this->db->join('user_preference up', "up.users_id=users.users_id", 'left');

        $this->db->join('location lcc', "lcc.location_id=users.country", 'left');
        $this->db->order_by('credit_percent',"DESC");
        $this->db->group_by("users.users_id");
        $this->db->limit($perPage,$page);

        return $this->db->get('users')->result();
    }


    /**
    * Card view screen query for api
    * @param $filterdata
    * @return number of rows (int)
    */
    function cardviewNumRows($filterdata, $preferences,$num_pref){

        $users_id = $filterdata["users_id"];
        $this->db->where("users.discovery",'1');
        $this->db->where("users.users_status",'1');
        /*$page = ($page * $perPage);*/
        $preferences = implode(',', $preferences);

        if($filterdata["looking_for"] != "" && $filterdata["looking_for"] != "Male & Female"){

            $looking_for = $filterdata["looking_for"];

            $this->db->where("users_gender",$looking_for);

        }

        if($filterdata['from_age']!="" && $filterdata['to_age']!=""){    

            $from_age = $filterdata['from_age'];
            $to_age = $filterdata['to_age'];
            if($from_age >= 18 && $to_age >=18 ){
                $this->db->where("((users_age BETWEEN '$from_age' AND '$to_age') or users_age='0')");
            }
        }

        if($filterdata['string']!=""){
            $string = $filterdata['string'];
            $this->db->where("users.users_id NOT IN ($string)");
        }



        $where_distance = $filterdata['where_distance'];

        if($filterdata['where_distance']!=""){

            $this->db->having("distance < 50");

        }

        $this->db->select("users.users_id,concat(users.users_fname,' ',users.users_lname) as name,IFNULL(users.users_age, '') as users_age,IFNULL(lc.name, '') as users_location, '10' as percentage $where_distance,IFNULL(users.about,'') as self_summery,IFNULL(users.is_online,'0') as is_onine");

        $this->db->from("users");

        $this->db->join('user_preference','users.users_id=user_preference.users_id','left');

        $this->db->join('location lc','lc.location_id=users.users_location','left');

        if($num_pref > 2){
        $this->db->where("preference_option_id IN ( SELECT user_preference.preference_option_id FROM users LEFT JOIN user_preference ON users.users_id=user_preference.users_id  WHERE users.users_id=$users_id AND user_preference.preference_option_id NOT IN ($preferences))");
        }

        $this->db->order_by('credit_percent',"DESC");

        $this->db->order_by('credit_percent_update_time',"DESC");
        
        //  AND user_preference.preference_option_id NOT IN ($preferences)

        $this->db->group_by("user_preference.users_id");

        return $this->db->get()->num_rows();

    }

     /**
    * Card view screen query for api
    * @param $filterdata ,$page,$perpage
    * @return response list of users
    */
    function cardviewResult($filterdata, $preferences, $page,$perPage,$num_pref){

        $users_id = $filterdata["users_id"];

        $page = ($page * $perPage);
        $preferences = implode(',', $preferences);
        $this->db->where("users.discovery",'1');
        $this->db->where("users.users_status",'1');
        if($filterdata["looking_for"]!="" && $filterdata["looking_for"] != "Male & Female"){

            $looking_for = $filterdata["looking_for"];

            $this->db->where("users_gender",$looking_for);

        }

        if($filterdata['from_age']!="" && $filterdata['to_age']!=""){

            $from_age = $filterdata['from_age'];
            $to_age = $filterdata['to_age'];
            if($from_age >= 18 && $to_age >=18 ) {
                $this->db->where("((users_age BETWEEN '$from_age' AND '$to_age') or users_age='0')");
            }

        }

        if($filterdata['string']!=""){
            $string = $filterdata['string'];
            $this->db->where("users.users_id NOT IN ($string)");
        }

        $where_distance = $filterdata['where_distance'];

        if($filterdata['where_distance']!=""){

            $this->db->having("distance < 50");

        }

        $this->db->select("users.users_id,concat(users.users_fname,' ',users.users_lname) as name,IFNULL(users.users_age, '') as users_age,IFNULL(lc.name, '') as users_location, '10' as percentage $where_distance,IFNULL(users.about,'') as self_summery,IFNULL(users.is_online,'0') as is_onine");

        $this->db->from("users");

        $this->db->join('user_preference','users.users_id=user_preference.users_id','left');
        $this->db->join('location lc','lc.location_id=users.users_location','left');
        if($num_pref > 2){

        $this->db->where("preference_option_id IN ( SELECT user_preference.preference_option_id FROM users LEFT JOIN user_preference ON users.users_id=user_preference.users_id  WHERE users.users_id=$users_id AND user_preference.preference_option_id NOT IN ($preferences))");

        }

        // AND user_preference.preference_option_id NOT IN ($preferences)
        $this->db->order_by('credit_percent',"DESC");
        $this->db->order_by('credit_percent_update_time',"DESC");
        $this->db->group_by("user_preference.users_id");
        
        $this->db->limit($perPage,$page);

        return $this->db->get()->result();

    }


    

    function matchingNumRows($filterdata,$preferences,$num_pref){

        $users_id = $filterdata["users_id"];
        $preferences = implode(',', $preferences);
        $this->db->where("users.discovery",'1');
        $this->db->where("users.users_status",'1');
        if($filterdata["looking_for"] != ""  && $filterdata["looking_for"] != "Male & Female") {

            $looking_for = $filterdata["looking_for"];
            $this->db->where("users.users_id != ",$users_id);
            $this->db->where("users.users_gender",$looking_for);

        }

        if($filterdata['from_age']!="" && $filterdata['to_age']!=""){    

            $from_age = $filterdata['from_age'];
            $to_age = $filterdata['to_age'];
            if($from_age > 18 && $to_age > 18){
            $this->db->where("((users_age BETWEEN '$from_age' AND '$to_age') or users_age='0')");
            }

        }

        if($filterdata['from_height']!="" && $filterdata['to_height']!=""){
            
            $from_height = $filterdata['from_height'];
            $to_height = $filterdata['to_height'];
            if($from_height > 0 && $to_height > 0){
            $this->db->where(" (users_height BETWEEN '$from_height' AND '$to_height')");
            }
        }


        if($filterdata['string']!=""){
            $string = $filterdata['string'];
            $this->db->where("users.users_id NOT IN ($string)");
        }


        if (!empty($filterdata['where_pref'])) {
            $where_pref = $filterdata['where_pref'];
            $this->db->where($where_pref);

        }


        $where_distance = $filterdata['where_distance'];

        if($filterdata['where_distance']!=""){

            $this->db->having("distance < 50");

        }

        $this->db->select("users.users_id,concat(users.users_fname,' ',users.users_lname) as name,IFNULL(users.users_age,'') as users_age,IFNULL(users.users_location,'') as users_location, '10' as percentage $where_distance,IFNULL(users.about,'') as self_summery,IFNULL(users.is_online,'0') as is_onine,credit_percent");

        $this->db->from("users");

        $this->db->join('user_preference','users.users_id=user_preference.users_id','left');
        if($num_pref > 2){
        $this->db->where("preference_option_id IN ( SELECT user_preference.preference_option_id FROM users LEFT JOIN user_preference ON users.users_id=user_preference.users_id  WHERE users.users_id=$users_id  AND user_preference.preference_option_id NOT IN ($preferences))");
        }
        $this->db->order_by('credit_percent',"DESC");
        $this->db->order_by('credit_percent_update_time',"DESC");
        $this->db->group_by("user_preference.users_id");

        return $this->db->get()->num_rows();
    }


    /**
    * Card view screen query for api
    * @param $filterdata ,$page,$perpage
    * @return response list of users
    */
    function matchingResult($filterdata,$preferences,$page,$perPage,$num_pref){

        $users_id = $filterdata["users_id"];
        $preferences = implode(',', $preferences);
        $page = ($page * $perPage);
        $this->db->where("users.discovery",'1');
        $this->db->where("users.users_status",'1');
        if($filterdata["looking_for"]!="" && $filterdata["looking_for"] != "Male & Female"){

            $looking_for = $filterdata["looking_for"];
            $this->db->where("users.users_id != ",$users_id);
            $this->db->where("users.users_gender",$looking_for);

        }

        if($filterdata['from_age']!="" && $filterdata['to_age']!=""){    

            $from_age = $filterdata['from_age'];
            $to_age = $filterdata['to_age'];
            if($from_age > 18 && $to_age > 18){
            $this->db->where("((users_age BETWEEN '$from_age' AND '$to_age') or users_age='0')");
            }
        }

        if($filterdata['from_height']!="" && $filterdata['to_height']!=""){
            
            $from_height = $filterdata['from_height'];
            $to_height = $filterdata['to_height'];
            if($from_height > 0 && $to_height > 0){
            $this->db->where(" (users_height BETWEEN '$from_height' AND '$to_height')");
            }
        }


        if($filterdata['string']!=""){
            $string = $filterdata['string'];
            $this->db->where("users.users_id NOT IN ($string)");
        }


        if (!empty($filterdata['where_pref'])) {
            $where_pref = $filterdata['where_pref'];
            $this->db->where($where_pref);

        }


        $where_distance = $filterdata['where_distance'];

        if($filterdata['where_distance']!=""){

            $this->db->having("distance < 50");

        }

        $this->db->select("users.users_id,concat(users.users_fname,' ',users.users_lname) as name,IFNULL(users.users_age,'') as users_age,IFNULL(users.users_location,'') as users_location, '10' as percentage $where_distance,IFNULL(users.about,'') as self_summery,IFNULL(users.is_online,'0') as is_onine,credit_percent");

        $this->db->from("users");

        $this->db->join('user_preference','users.users_id=user_preference.users_id','left');
        if($num_pref > 2){
        $this->db->where("preference_option_id IN ( SELECT user_preference.preference_option_id FROM users LEFT JOIN user_preference ON users.users_id=user_preference.users_id  WHERE users.users_id=$users_id  AND user_preference.preference_option_id NOT IN ($preferences))");
        }
        $this->db->order_by('credit_percent',"DESC");
        $this->db->order_by('credit_percent_update_time',"DESC");
        $this->db->group_by("user_preference.users_id");
        
        $this->db->limit($perPage,$page);

        return $this->db->get()->result();

    }



    /**
    * Card view screen query for api
    * @param $filterdata ,$page,$perpage
    * @return response list of users
    */
    function getMoreVisitsResult($filterdata){

         $users_id   = $filterdata["users_id"];
        $lat        = $filterdata['lat'];
        $long       = $filterdata['long'];
        

       
        $this->db->where("users.discovery",'1');
        $this->db->where("users.users_status",'1');
        if($filterdata["looking_for"]!="" && $filterdata["looking_for"] != "Male & Female"){

        $looking_for = $filterdata["looking_for"];
        $this->db->where("(users_gender = '$looking_for')");

        }  

        //$promoted_ids = $filterdata['promoted'];
        $this->db->where("users.get_more_visits","1");
             

        if($filterdata['string']!=""){

        $string = $filterdata['string'];
        $this->db->where("users.users_id NOT IN ($string)");

        }

        $this->db->select("users.users_id,( 3959 * acos( cos( radians($lat) ) * cos( radians( users_latitude ) ) * cos( radians( users_longitude ) - radians($long) ) + sin( radians($lat) ) * sin( radians( users_latitude ) ) ) ) AS distance");

        $this->db->from("users");
           
        $this->db->join('location lc','lc.location_id=users.users_location','left');

        $this->db->group_by("users.users_id");

        $this->db->having("distance < 50");        
        $this->db->order_by("view_count ASC,`move_to_top` DESC,RAND()");
        /*$this->db->order_by('move_to_top','DESC');*/
        $this->db->limit('10');
        $users = $this->db->get()->result();

        $count = count($users);

        foreach ($users as $rows) {
            $user_notin[] = $rows->users_id;
        }

        $limit = (10 - $count);


        if(count($users) < 10) {

        $users_id   = $filterdata["users_id"];
        $lat        = $filterdata['lat'];
        $long       = $filterdata['long'];
        
        
        

        $this->db->select("users.users_id,concat(users.users_fname,' ',users.users_lname) as name,IFNULL(users.users_age, '') as users_age,IFNULL(lc.name, '') as users_location, '10' as percentage,IFNULL(users.about,'') as self_summery,IFNULL(users.is_online,'0') as is_onine,( 3959 * acos( cos( radians($lat) ) * cos( radians( users_latitude ) ) * cos( radians( users_longitude ) - radians($long) ) + sin( radians($lat) ) * sin( radians( users_latitude ) ) ) ) AS distance");


        $this->db->where("users.discovery",'1');
        $this->db->where("users.users_status",'1');

        if($filterdata["looking_for"]!="" && $filterdata["looking_for"] != "Male & Female"){

            $looking_for = $filterdata["looking_for"];

        $this->db->where("(users_gender = '$looking_for')");
        }  

       // $promoted_ids = $filterdata['promoted'];
        $this->db->where("users.get_more_visits","1");

        $string = $filterdata['string'];
        if($filterdata['string']!=""){
            if(!empty($user_notin)){
                $user_notin = implode(",", $user_notin);
                $string = $filterdata['string'].",".$user_notin;        


            }else{
                $string = $filterdata['string'];
            }        
            $this->db->where("users.users_id NOT IN ($string)");
        }else{
            if(!empty($user_notin)){
                $user_notin = implode(",", $user_notin);
                $string = $user_notin;        
                    $this->db->where("users.users_id NOT IN ($string)");
            }
        }


        $this->db->from("users");        
        $this->db->join('location lc','lc.location_id=users.users_location','left');
        $this->db->limit($limit);
        $this->db->group_by("users.users_id");                
        $this->db->order_by('view_count ASC,`move_to_top` DESC,RAND()');
        

        $global_users = $this->db->get()->result();        
       
        }


        if(!empty($global_users)){
            $users = array_merge($users,$global_users);
        }

        shuffle($users);

        return $users;


    }

     function moveTotop($filterdata,$move_top_id){
        
            
        $users_id   = $filterdata["users_id"];
        $lat        = $filterdata['lat'];
        $long       = $filterdata['long'];
        
       
        $this->db->where("users.discovery",'1');

        $this->db->where("users.users_status",'1');        

        $this->db->select("users.users_id,concat(users.users_fname,' ',users.users_lname) as name,IFNULL(users.users_age, '') as users_age,IFNULL(lc.name, '') as users_location, '10' as percentage,IFNULL(users.about,'') as self_summery,IFNULL(users.is_online,'0') as is_onine,( 3959 * acos( cos( radians($lat) ) * cos( radians( users_latitude ) ) * cos( radians( users_longitude ) - radians($long) ) + sin( radians($lat) ) * sin( radians( users_latitude ) ) ) ) AS distance,users.move_to_top,users.view_count");

        $this->db->from("users");
           
        $this->db->join('location lc','lc.location_id=users.users_location','left');

        $this->db->group_by("users.users_id");        

        
        /*$this->db->order_by("IF(move_to_top='1', name, users.users_lname) ASC");*/
        //$this->db->order_by("(`move_to_top` = '1') DESC, `name` ASC");
        $this->db->order_by("move_to_top DESC, (CASE WHEN move_to_top = '1' THEN 1 ELSE 0 END),name ASC, (CASE WHEN move_to_top = '1' THEN 1 ELSE 0 END), distance asc");

        if(!empty($move_top_id)){

            $this->db->where("users_id IN ($move_top_id)");

            
        }

        $this->db->limit('10');   

        $users = $this->db->get()->result();

        return $users;
    }

}

?>