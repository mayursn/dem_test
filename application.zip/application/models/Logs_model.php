<?php

class Logs_model extends MY_Model
{

     public function __construct()
    {
        $this->table = 'logs';
        $this->primary_key = 'id';
        $this->soft_deletes = false;
        $this->before_create = array('timestamps');     
        /*$this->has_one = array(
            'user' => array(
                'foreign_model' => 'Users_model',
                'foreign_table' => 'users',
                'foreign_key' => 'users_id',
                'local_key' => 'user_id'
            )
        );*/

        $this->column_order = array('uri','message','params','ip_address','created_date');
        $this->column_search = array('uri','message','params','ip_address','created_date'); //set column field database for datatable searchable        
        $this->order = array($this->table.'.created_date' => 'desc');   
        parent::__construct();
    }
    
    //callbacks
   
     /**
     * Create timestamps before new user created
     * @param  array $user
     * @return array
     */
    protected function timestamps($user)
    {
        $user['created_date'] = $user['updated_date'] = date('Y-m-d H:i:s');

        return $user;
    }



     private function _get_datatables_query()
    {
        //$this->db->select("$this->table.*,concat(users.users_fname,' ',users.users_lname) as uname");
        $this->db->select("$this->table.*");
        $this->db->from($this->table);
        //$this->db->join("users","users.users_id=$this->table.user_id",'left');
        //$this->db->join('location_master','location_master.location_id=work_master.location_id');
        //$this->db->join('doctor_details','doctor_master_en.doctor_id=doctor_details.doctor_id','right');
        //$this->db->join('specialty_master','specialty_master.specialties_id=doctor_details.speciality_id','left');
        //$this->db->join('location_master','location_master.location_id=doctor_details.location_id','left');

        
        $this->db->where('user_id',$_POST['user_id']);
       
        

        $i = 0;

        foreach ($this->column_search as $item) // loop column
        {
            if (@$_POST['search']['value']) //if datatable send POST for search
            {

                if ($i === 0) // first loop
                {
                    $this->db->group_start(); // open bracket. query Where with OR clause better with bracket. because maybe can combine with other WHERE with AND.
                    $this->db->like($item, $_POST['search']['value']);
                } else {
                    $this->db->or_like($item, $_POST['search']['value']);
                }

                if (count($this->column_search) - 1 == $i) //last loop
                {
                    $this->db->group_end();
                }
                //close bracket
            }
            $i++;
        }

        if (isset($_POST['order'])) // here order processing
        {
            $this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        } else if (isset($this->order)) {
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    public function get_datatables()
    {
        $this->_get_datatables_query();
        if (@$_POST['length'] != -1) {
            $this->db->limit(@$_POST['length'], @$_POST['start']);
        }

        $query = $this->db->get();
        return $query->result();
    }

    public function count_filtered()
    {
        $this->_get_datatables_query();
        $query = $this->db->get();
        return $query->num_rows();
    }

    public function count_all()
    {
        $this->db->from($this->table);
        $this->db->where('user_id',$_POST['user_id']);
        return $this->db->count_all_results();
    }

    /**
    * Get user logs
    * @param $where array
    * @return response logs array
    */
    public function getUsersLogs($where){
       
        return $this->db->select('l.uri,l.method,l.params,l.ip_address,l.time,l.message,l.status,l.created_date as logged')
        ->join('users u','u.users_id=l.user_id','left')
        ->where($where)
        ->get('logs l')->result();
    }

}
?>