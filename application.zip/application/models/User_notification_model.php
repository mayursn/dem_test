<?php

class User_notification_model extends MY_Model
{


     public function __construct()
     {
        $this->table = 'user_notification';
        $this->primary_key = 'notification_id';      
        parent::__construct();
     }
    


    

}
?>