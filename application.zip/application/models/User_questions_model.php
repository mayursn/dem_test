<?php

class User_questions_model extends MY_Model
{

     public function __construct()
    {
        $this->table = 'user_questions';
        $this->primary_key = 'user_question_id';
        $this->soft_deletes = false;
        $this->before_create = array('timestamps');        

        parent::__construct();
    }
    

    //callbacks
   
     /**
     * Create timestamps before new user created
     * @param  array $user
     * @return array with include created date
     */
    protected function timestamps($data)
    {
        $data['created_date'] = date('Y-m-d H:i:s');

        return $data;
    }


     function answeredquestions($users_id,$question_id){
        $this->db->select('IFNULL(qm.question_id,0) as question_id ,qm.question_title,uq.answer_id as selected,uq.opp_user_them');            
            $this->db->join('questions_master qm',"qm.question_id=uq.question_id",'left');          
            $this->db->where('uq.users_id',$users_id);  
            $this->db->where('uq.question_id',$question_id);  
          return $this->db->get('user_questions uq')->result();
    }


}
?>