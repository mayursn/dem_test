<?php

class Cms_pages_model extends MY_Model
{

     public function __construct()
    {
        $this->table = 'cms_pages';
        $this->primary_key = 'cms_id';
        $this->soft_deletes = false;        
        $this->before_create = array('timestamps');        
        $this->before_update = array('update_timestamp');
        $this->before_get =  array('get_before');
   
        parent::__construct();
    }
      

    //callbacks
   
     /**
     * Create timestamps before new user created
     * @param  array $user
     * @return array
     */
    protected function timestamps($user)
    {
        $user['created_date'] = $user['updated_date'] = date('Y-m-d H:i:s');

        return $user;
    }

    /**
     * Update timestamp before update user details
     * @param  array $user
     * @return array
     */
    protected function update_timestamp($user)
    {
        $user['updated_date'] = date('Y-m-d H:i:s');

        return $user;
    }


    protected function get_before(){
        return $this->db->where('is_deleted','0');
    }
}
?>