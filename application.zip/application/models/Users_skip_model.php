<?php

class Users_skip_model extends MY_Model
{

     public function __construct()
    {
        $this->table = 'users_skip';
        $this->primary_key = 'skip_id';
        $this->soft_deletes = false;        
        $this->before_create = array('timestamps');     
        parent::__construct();
    }
      

    //callbacks
   
     /**
     * include created time in array to insert data
     * @param  array $user
     * @return array
     */
    protected function timestamps($user)
    {
        $user['created_date'] = $user['updated_date'] =  date('Y-m-d H:i:s');

        return $user;
    }



    /**
    * List of skipped questions by user
    * @param $users_id 
    * @return response
    */
    public function getSkippedQuestions($users_id){
        $this->db->select('us.question_id,qm.question_title');
        $this->db->join('questions_master qm','qm.question_id=us.question_id','left');
        $this->db->where('users_id',$users_id);
        return $this->db->get($this->table." us")->result();
    }

}
?>