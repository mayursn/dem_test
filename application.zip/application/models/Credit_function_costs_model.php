<?php
# credit model is purchasing Additional Credits table
# which is store all details of amount of credits for purchase
# 
class Credit_function_costs_model extends MY_Model
{

     public function __construct()
    {
        $this->table = 'credit_function_costs';
        $this->primary_key = 'id';
        //$this->soft_deletes = false;     
        //$this->before_create = array('timestamps');
        //$this->before_get = array('checkdeleted'); 
        
        parent::__construct();
    }

   

}
?>