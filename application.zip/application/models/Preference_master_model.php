<?php

class Preference_master_model extends MY_Model
{

     public function __construct()
    {
        $this->table = 'preference_master';
        $this->primary_key = 'preference_id';
        $this->soft_deletes = false;
        $this->before_create = array('timestamps');     
        $this->has_many = array(
            'preferences' => array(
                'foreign_model' => 'Preferences_model',
                'foreign_table' => 'preferences',
                'foreign_key' => 'preference_id',
                'local_key' => 'preference_id'
            )
        );
        

         

        $this->before_get =  array('get_before');
        $this->column_order = array('preference_id','preference_name','is_active','created_date');
        $this->column_search = array('preference_id','preference_name','is_active','created_date'); //set column field database for datatable searchable        
        $this->order = array($this->table.'.id' => 'desc');   
        parent::__construct();
    }

    protected function get_before(){
        return $this->db->where('is_deleted','0');
        }
    
    //callbacks
   
     /**
     * Create timestamps before new user created
     * @param  array $user
     * @return array
     */
    protected function timestamps($user)
    {
        $user['created_date'] = $user['updated_date'] = date('Y-m-d H:i:s');

        return $user;
    }



     private function _get_datatables_query()
    {
        $this->db->select("$this->table.*");
        $this->db->from($this->table);        
        
        $i = 0;

        foreach ($this->column_search as $item) // loop column
        {
            if (@$_POST['search']['value']) //if datatable send POST for search
            {

                if ($i === 0) // first loop
                {
                    $this->db->group_start(); // open bracket. query Where with OR clause better with bracket. because maybe can combine with other WHERE with AND.
                    $this->db->like($item, $_POST['search']['value']);
                } else {
                    $this->db->or_like($item, $_POST['search']['value']);
                }

                if (count($this->column_search) - 1 == $i) //last loop
                {
                    $this->db->group_end();
                }
                //close bracket
            }
            $i++;
        }

        if (isset($_POST['order'])) // here order processing
        {
            $this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        } else if (isset($this->order)) {
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    public function get_datatables()
    {
        $this->_get_datatables_query();
        if (@$_POST['length'] != -1) {
            $this->db->limit(@$_POST['length'], @$_POST['start']);
        }

        $query = $this->db->get();
        return $query->result();
    }

    public function count_filtered()
    {
        $this->_get_datatables_query();
        $query = $this->db->get();
        return $query->num_rows();
    }

    public function count_all()
    {
        $this->db->from($this->table);
        return $this->db->count_all_results();
    }

}
?>