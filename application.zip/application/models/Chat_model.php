<?php

class Chat_model extends MY_Model
{

     public function __construct()
    {
        $this->table = 'chat';
        $this->primary_key = 'chat_id';
        parent::__construct();
    }
   
}
?>