<?php

class Permission_model extends MY_Model
{

      public function __construct()
    {
        $this->table = 'permission';
        $this->primary_key = 'permission_id';
        $this->soft_deletes = false;
        $this->before_create = array('timestamps');
        $this->before_update = array('update_timestamp');    
        //$this->has_one['details'] = 'User_details_model';
        // $this->has_one['details'] = array('User_details_model','user_id','id');
        //$this->has_one['details'] = array('local_key'=>'id', 'foreign_key'=>'user_id', 'foreign_model'=>'User_details_model');
        //$this->has_many['posts'] = 'Post_model';
        $this->before_create = array('timestamps');
        parent::__construct();
    }
	

    //callbacks
    



     /**
     * Create timestamps before new permission created
     * @param  array $permission
     * @return array
     */
    protected function timestamps($permission)
    {
        $permission['created_date'] = $permission['updated_date'] = date('Y-m-d H:i:s');

        return $permission;
    }

  

    /**
     * Update timestamp before update permission details
     * @param  array $permission
     * @return array
     */
    protected function update_timestamp($permission)
    {
        $permission['updated_date'] = date('Y-m-d H:i:s');

        return $permission;
    }


    /**
    * Role permission 
    */

    function role_permission_with_module($admin_id) {
        return $this->db->select()
                ->from('permission')
                ->join("modules", "modules.module_id = permission.module_id")
                ->where([
                    "permission.admin_id" => $admin_id
                ])->get()->result();
    }


    function checkUserAdmin($id=''){
      $this->db->where('admin_id',$id);
      $admin_type = $this->db->get('admin')->row()->admin_type;

      if($admin_type=="2")
      {
        return false;
      }
      return true;

    }
    

    

}
?>