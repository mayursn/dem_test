<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Getallusers_model extends MY_Model
{
    public $primary_key = 'users_id';

    public $table = 'users';
    public $column_order = array('users_fname','users_email','created_date','users_status','users_id');
    public $column_search = array('users_fname','users_email','created_date','users_status','users_id'); //set column field database for datatable searchable
    public $order = array('users.users_id' => 'desc');

    private function _get_datatables_query()
    {
        $this->db->select('users.*');
        $this->db->from('users');
        //$this->db->join('location_master','location_master.location_id=work_master.location_id');
        //$this->db->join('doctor_details','doctor_master_en.doctor_id=doctor_details.doctor_id','right');
        //$this->db->join('specialty_master','specialty_master.specialties_id=doctor_details.speciality_id','left');
        //$this->db->join('location_master','location_master.location_id=doctor_details.location_id','left');

        

        if ($this->input->post('user_status')=="1" || $this->input->post('user_status')=="0") {
            $this->db->where('users.status', trim($this->input->post('user_status')));
        }
        if ($this->input->post('registration_from')) {
            $this->db->where('users.register_from', trim($this->input->post('registration_from')));
        }


        
        
            

        

        $i = 0;

        foreach ($this->column_search as $item) // loop column
        {
            if (@$_POST['search']['value']) //if datatable send POST for search
            {

                if ($i === 0) // first loop
                {
                    $this->db->group_start(); // open bracket. query Where with OR clause better with bracket. because maybe can combine with other WHERE with AND.
                    $this->db->like($item, $_POST['search']['value']);
                } else {
                    $this->db->or_like($item, $_POST['search']['value']);
                }

                if (count($this->column_search) - 1 == $i) //last loop
                {
                    $this->db->group_end();
                }
                //close bracket
            }
            $i++;
        }
        if (isset($_POST['search']['value'])) //if datatable send POST for search
        {   
            $this->db->or_like('users_lname',$_POST['search']['value']);
            
        }

        if (isset($_POST['search']['value']) && ($_POST['search']['value']=="premium" || $_POST['search']['value']=="Premium" || $_POST['search']['value']=="prem" || $_POST['search']['value']=="pre" || $_POST['search']['value']=="premi"  || $_POST['search']['value']=="premiu") ) //if datatable send POST for search
        {   
            $this->db->or_like('premium_status',"1");
            
        }

        if (isset($_POST['search']['value']) && ($_POST['search']['value']=="free" || $_POST['search']['value']=="fre" || $_POST['search']['value']=="Free" || $_POST['search']['value']=="Fr" ) ) //if datatable send POST for search
        {   
            $this->db->or_like('premium_status',"0");
            
        }

        if (isset($_POST['search']['value']) && is_numeric($_POST['search']['value'])) //if datatable send POST for search
        {   
            $this->db->or_like('total_credits',$_POST['search']['value']);
            $this->db->or_like('weekly_credits',$_POST['search']['value']);
            
        }


        if (isset($_POST['order'])) // here order processing
        {
            $this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        } else if (isset($this->order)) {
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    public function get_datatables()
    {
        $this->_get_datatables_query();
        if (@$_POST['length'] != -1) {
            $this->db->limit(@$_POST['length'], @$_POST['start']);
        }

        $query = $this->db->get();
        return $query->result();
    }

    public function count_filtered()
    {
        $this->_get_datatables_query();
        $query = $this->db->get();
        return $query->num_rows();
    }

    public function count_all()
    {
        $this->db->from('users');
        return $this->db->count_all_results();
    }
}
