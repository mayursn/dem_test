<?php

class Modules_model extends MY_Model
{
	public $primary_key = 'module_id';

    //callbacks
    public $before_create = array('timestamps');
    public $before_update = array('update_timestamp');    
    public $before_get = array('getbefore');

     /**
     * Create timestamps before new user created
     * @param  array $user
     * @return array
     */
    protected function timestamps($user)
    {
        $user['created_at'] = $user['updated_at'] = date('Y-m-d H:i:s');

        return $user;
    }

  

    /**
     * Update timestamp before update user details
     * @param  array $user
     * @return array
     */
    protected function update_timestamp($user)
    {
        $user['updated_at'] = date('Y-m-d H:i:s');

        return $user;
    }

    /**
    * check data before get
    * Condition apply with query while get data 
    */

    protected function getbefore(){
        $this->db->where('is_active','1');
    }


}
?>