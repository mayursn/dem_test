<?php

class Messages_model extends MY_Model
{

     public function __construct()
    {
        $this->table = 'messages';
        $this->primary_key = 'message_id';
        $this->soft_deletes = false;     
        $this->before_create = array('timestamps');
        
   
        parent::__construct();
    }
      

    //callbacks
   
     /**
     * Create timestamps before new user created
     * @param  array $user
     * @return array
     */
    protected function timestamps($user)
    {
        $user['created_date'] = date('Y-m-d H:i:s');

        return $user;
    }


       /**
    * Get all messages 
    * @param $sender_id is current user id and @receiver_id is opposite user
    * @return $response array
    */
    public function get_all_messages($chat_id,$page,$perPage){

        $page = ($page * $perPage);

        $this->db->select("concat_ws(' ',su.users_fname,su.users_lname) as sender_name,concat_ws(' ',ru.users_fname,ru.users_lname) as receiver_name,$this->table.message,$this->table.image,$this->table.sender_id,$this->table.receiver_id,$this->table.message_id,$this->table.created_date,$this->table.sender_visibility,$this->table.receiver_visibility,$this->table.message_type,$this->table.emoji_flag,$this->table.chat_id,c.chat_type");

        $this->db->where("$this->table.message_status","1");
         /*$this->db->where("((sender_id=$sender_id AND receiver_id=$receiver_id) OR (receiver_id=$sender_id AND sender_id=$receiver_id))");  */
         $this->db->join('chat as c',"$this->table.chat_id=c.chat_id");
         $this->db->where("$this->table.chat_id='$chat_id'");  
        $this->db->join('users as ru',"$this->table.receiver_id=ru.users_id",'left');
        $this->db->join('users su',"$this->table.sender_id=su.users_id",'left');
        
        
        $this->db->order_by('message_id','desc');
        $this->db->limit($perPage,$page);
        return $this->db->get($this->table)->result();
        
    }

    /**
    * Get all messages 
    * @param $sender_id is current user id and @receiver_id is opposite user
    * @return $response array
    */
    public function get_all_messagesNumRows($chat_id){
        $this->db->select("concat_ws(' ',su.users_fname,su.users_lname) as sender_name,concat_ws(' ',ru.users_fname,ru.users_lname) as receiver_name,$this->table.message,,$this->table.image,$this->table.sender_id,$this->table.receiver_id,$this->table.message_id,$this->table.created_date,$this->table.sender_visibility,$this->table.receiver_visibility,$this->table.message_type,$this->table.emoji_flag,$this->table.chat_id,c.chat_type");
        
        $this->db->where("$this->table.message_status","1");
         $this->db->where("$this->table.chat_id='$chat_id'");  
         $this->db->join('chat as c',"$this->table.chat_id=c.chat_id");
        $this->db->join('users as ru',"$this->table.receiver_id=ru.users_id",'left');
        $this->db->join('users su',"$this->table.sender_id=su.users_id",'left');
        $this->db->order_by('message_id','desc');
        return $this->db->get($this->table)->num_rows();
        
    }




     function listUsersNumRows($users_id,$condition){
        
        return $this->db->query("SELECT chat.*,u.users_id,IFNULL(concat(u.users_fname,' ',u.users_lname),'') as name,u.is_invisible FROM chat LEFT JOIN users as u ON ( CASE WHEN chat.sender_id = $users_id THEN chat.receiver_id ELSE chat.sender_id END)=u.users_id WHERE chat.random_users_id!='$users_id' AND (chat.sender_id='$users_id' OR chat.receiver_id='$users_id') $condition  order by updated_date desc")->num_rows();
        
    }

    function listUsers($users_id,$page,$perPage,$condition){
        $page = ($page * $perPage);

        return $this->db->query("SELECT chat.*,u.users_id,IFNULL(concat(u.users_fname,' ',u.users_lname),'') as name,u.is_invisible FROM chat LEFT JOIN users as u ON ( CASE WHEN chat.sender_id = $users_id THEN chat.receiver_id ELSE chat.sender_id END)=u.users_id WHERE chat.random_users_id!='$users_id' AND (chat.sender_id='$users_id' OR chat.receiver_id='$users_id') $condition order by updated_date desc LIMIT $page, $perPage")->result();
    
    }


    
    function UserDetails($usersID){

         $this->db->select("users_id,concat(users_fname,' ',users_lname) as name");
              $this->db->where('users_id',$usersID);
             return  $this->db->get('users')->row();    

    }



}
?>