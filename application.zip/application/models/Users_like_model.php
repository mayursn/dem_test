<?php

class Users_like_model extends MY_Model
{

     public function __construct()
    {
        $this->table = 'users_like';
        $this->primary_key = 'like_id';
        $this->soft_deletes = false;        
        $this->before_create = array('timestamps');
        $this->has_many = array(
            'likes' => array(
                'foreign_model' => 'Users_model',
                'foreign_table' => 'users',
                'foreign_key' => 'users_id',
                'local_key' => 'like_users_id'
            )

        );


        $this->has_many = array(
            'likesyou' => array(
                'foreign_model' => 'Users_model',
                'foreign_table' => 'users',
                'foreign_key' => 'users_id',
                'local_key' => 'users_id'
            )

        );




       
        parent::__construct();
    }
      

    //callbacks
   
     /**
     * include created time in array to insert data
     * @param  array $user
     * @return array
     */
    protected function timestamps($user)
    {
        $user['created_date'] =  date('Y-m-d H:i:s');

        return $user;
    }



    /**
    * user likes list
    * @param $users_id,$like_users_id
    * @return response
    */

    public function get_orwhere($users_id,$like_users_id){

        $where = "(users_id=$users_id AND like_users_id=$like_users_id AND like_status='1') OR (like_users_id=$users_id AND users_id=$like_users_id  AND like_status='1')";

  return $this->db->select()        
        ->where($where)
        ->get($this->table)
        ->num_rows();
    }

     public function mutualLikeListNumRows($users_id){
       return $this->db->query("SELECT `users`.`users_id`, concat(users_fname, ' ', users_lname) as name,  COALESCE(`location`.`name`, '')  as `users_location`,IFNULL(`users`.discovery,'') as discovery,IFNULL(`users`.offline_time,'') as offline_time,IFNULL(`users`.is_online,'') as is_onine FROM `users_like` LEFT JOIN `users` ON `users`.`users_id`=`users_like`.`like_users_id` LEFT JOIN `location` ON `location`.`location_id`=`users`.`users_location` where users_like.users_id='$users_id' and users_like.like_status='1' and users_like.like_users_id IN (SELECT users_id FROM users_like WHERE like_users_id='$users_id' AND like_status='1')  ORDER BY users_like.created_date DESC")->num_rows(); 
      
    }

    public function mutualLikeList($users_id,$page,$perPage){
        $page = ($page * $perPage);
      return  $this->db->query("SELECT `users`.`users_id`, concat(users_fname, ' ', users_lname) as name,  COALESCE(`location`.`name`, '')  as `users_location`,IFNULL(`users`.discovery,'') as discovery,IFNULL(`users`.offline_time,'') as offline_time,IFNULL(`users`.is_online,'') as is_onine FROM `users_like` LEFT JOIN `users` ON `users`.`users_id`=`users_like`.`like_users_id` LEFT JOIN `location` ON `location`.`location_id`=`users`.`users_location` where users_like.users_id='$users_id' and users_like.like_status='1' and users_like.like_users_id IN (SELECT users_id FROM users_like WHERE like_users_id='$users_id' AND like_status='1')  ORDER BY users_like.created_date DESC LIMIT $page,$perPage")->result();
    }

  
    /**
    * Get List Loggedin user Like other users 
    * @param $usersid
    * @return response array
    */


     function userLikeList($users_id,$page,$perPage){
         $page = ($page * $perPage);
         return $this->db->query("SELECT users.users_id,concat(users_fname,' ',users_lname) as name, COALESCE(`location`.`name`, '')  as users_location,IFNULL(`users`.is_online,'') as is_onine FROM users_like LEFT JOIN users ON users.users_id=users_like.like_users_id LEFT JOIN location ON location.location_id=users.users_location WHERE users.discovery=1 AND users_like.users_id='$users_id' AND users_like.like_status='1' AND users_like.like_users_id NOT IN ( SELECT users_id FROM users_like WHERE like_users_id='$users_id' AND like_status='1') AND users.users_id NOT IN (SELECT blocked_users_id FROM users_block WHERE users_id='$users_id' AND block_status='1')  ORDER BY users_like.updated_date DESC LIMIT $page,$perPage")->result();
       
    }


   /**
    * Get List Loggedin user Like other users 
    * @param $usersid
    * @return response array
    */


    function userLikeListNumRows($users_id){
     
        return $this->db->query("SELECT users.users_id,concat(users_fname,' ',users_lname) as name, COALESCE(`location`.`name`, '')  as users_location,IFNULL(`users`.is_online,'') as is_onine FROM users_like LEFT JOIN users ON users.users_id=users_like.like_users_id LEFT JOIN location ON location.location_id=users.users_location WHERE users.discovery=1 AND users_like.users_id='$users_id' AND users_like.like_status='1' AND users_like.like_users_id NOT IN ( SELECT users_id FROM users_like WHERE like_users_id='$users_id' AND like_status='1') AND users.users_id NOT IN (SELECT blocked_users_id FROM users_block WHERE users_id='$users_id' AND block_status='1') ORDER BY users_like.updated_date DESC")->num_rows();
    }

    /**
    * User list who liked logged in user
    * @param logged in user id
    * @return response
    */

    function userLikeYouList($users_id,$page,$perPage){
        $page = ($page * $perPage);

        
        return $this->db->select('users.users_id,concat(users_fname," ",users_lname) as name, COALESCE(`location`.`name`, "")  as users_location')
                        ->where('like_status','1')
                        ->where('users_like.like_users_id',$users_id)
                        ->join('users','users.users_id=users_like.users_id','left')
                        ->join('location','location.location_id=users.users_location','left')
                        ->limit($perPage,$page)
                        ->get($this->table)
                        ->result();
    }


     /**
    * count User list who liked logged in user
    * @param logged in user id
    * @return response
    */

    function userLikeYouListNumRows($users_id){
        return $this->db->select('users.users_id,concat(users_fname," ",users_lname) as name, COALESCE(`location`.`name`, "")  as users_location')
                        ->where('like_status','1')
                        ->where('users_like.like_users_id',$users_id)
                        ->join('users','users.users_id=users_like.users_id','left')
                        ->join('location','location.location_id=users.users_location','left')
                        ->get($this->table)
                        ->num_rows();
    }
    

    

    function updateStatus($users_id,$profile_user_id){
        $this->db->where("(sender_id=$users_id AND receiver_id=$profile_user_id) OR (receiver_id=$users_id AND sender_id=$profile_user_id)");
        $this->db->update('messages',['message_status'=>'0']);
    }



    /**
    * Delete dislike every six month 
    * @return response
    *
    */

    public function resetFilter(){
        return $this->db->query("DELETE FROM users_like WHERE created_date <= DATE_SUB(CURDATE(), INTERVAL 6 MONTH) AND like_status='0' AND users_id in (SELECT users_id FROM users WHERE users_status='1' AND is_deleted='0')");
    }


     public function getLikedStatus($users_id,$like_users_id){
            $this->db->select('like_status');
            $this->db->where('users_id',$users_id);
            $this->db->where('like_users_id',$like_users_id);
            $this->db->order_by('like_id','DESC');
    $user = $this->db->get('users_like')->row();

            $this->db->select('like_status');
            $this->db->where('users_id',$like_users_id);
            $this->db->where('like_users_id',$users_id);
            $this->db->order_by('like_id','DESC');
    $profile_user = $this->db->get('users_like')->row();

        if($user->like_status=="1" && $profile_user->like_status=="1")    {
            return ['is_mutualfriend'=>'1','is_liked'=>'1'];
        }else if($user->like_status=="1")    {
            return ['is_mutualfriend'=>'0','is_liked'=>'1'];
        }else{
            return ['is_mutualfriend'=>'0','is_liked'=>'0'];
        }

        
    }

     /**
    * Mutual user list
    * @param $users_id
    * @return $response array users_id
    * 24-05-2018    
    */
    public function mutualUserID($users_id){
        return $this->db->query("SELECT `users`.`users_id` FROM `users_like` LEFT JOIN `users` ON `users`.`users_id`=`users_like`.`like_users_id` LEFT JOIN `location` ON `location`.`location_id`=`users`.`users_location` where users_like.users_id='$users_id' and users_like.like_status='1' and users_like.like_users_id IN (SELECT users_id FROM users_like WHERE like_users_id='$users_id' AND like_status='1')  ORDER BY users_like.created_date DESC")->result();
    }

    
}
?>