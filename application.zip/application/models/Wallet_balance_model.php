<?php
# credit model is purchasing Additional Credits table
# which is store all details of amount of credits for purchase
# 
class Wallet_balance_model extends MY_Model
{

     public function __construct()
    {
        $this->table = 'wallet_balance';
        $this->primary_key = 'wallet_id';
        //$this->soft_deletes = false;     
        //$this->before_create = array('timestamps');
        //$this->before_get = array('checkdeleted'); 
        
        parent::__construct();
    }

    /**
    * Get All credits and debit data to daily Expired debit 
    * @param
    * @return response standard array
    */
    function getWalletdata(){

      return $this->db->query("SELECT wallet_expiry.users_id,users.weekly_credits,users.total_credits FROM wallet_expiry LEFT JOIN users ON users.users_id=wallet_expiry.users_id WHERE  DATE_FORMAT(expiry_date,'%Y-%m-%d') <= '".date('Y-m-d')."' AND premium_status='1'")->result();
    }


    function addUpdateWalletExpiry($data,$duration){

        $Date = date("Y-m-d H:i:s");

        $this->db->where('users_id',$data['users_id']);

        $user = $this->db->get('wallet_expiry')->row();

        if($duration==""){

                        $this->db->where(['id'=>1]);
            $duration = $this->db->get('credits_info')->row()->duration;

        }else{

            $duration = $duration;

        }
        

        if(empty($user)){
        
            $insert =   [
                            'users_id'=>$data['users_id'],
                            'purchase_id'=>$data['purchase_id'],
                            'purchased_date'=>date('Y-m-d H:i:s'),
                            'expiry_date'=>date('Y-m-d H:i:s', strtotime($Date. " + $duration days"))
                        ];

            $this->db->insert('wallet_expiry',$insert);
       
        }else{

            $update =   [
                            'users_id'=>$data['users_id'],
                            'purchase_id'=>$data['purchase_id'],
                            'purchased_date'=>date('Y-m-d H:i:s'),
                            'expiry_date'=>date('Y-m-d H:i:s', strtotime($Date. " + $duration days"))
                        ];

            $this->db->where('users_id',$user->users_id);

            $this->db->update('wallet_expiry',$update);

        }
    }
   

    function freeTrialExpired(){;
        $data = ['premium_status'=>'0'];
        $this->db->where('premium_trial_used','1');
        $this->db->where('premium_status','1');
        $this->db->where('freetrial_end_date <= ',date('Y-m-d'));
        $this->db->update('users',$data);
    }

    function updateManualSubscription($users_id){
        $data = ['expiry_date'=>date('Y-m-d H:i:s')];
        $this->db->where('users_id',$users_id);
        $this->db->where('type',$this->lang->line('manually_cancel'));
        return $this->db->update('wallet_expiry',$data);
    }

}
?>