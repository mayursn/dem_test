<?php

class Answer_option_model extends MY_Model
{

     public function __construct()
    {
        $this->table = 'answer_option';
        $this->primary_key = 'answer_id';
        $this->soft_deletes = false;
        $this->before_create = array('timestamps');     
        /*$this->has_one = array(
            'user' => array(
                'foreign_model' => 'Users_model',
                'foreign_table' => 'users',
                'foreign_key' => 'users_id',
                'local_key' => 'user_id'
            )
        );*/
        
        $this->order = array($this->table.'.answer_id' => 'desc');   
        parent::__construct();
    }
    
    //callbacks
   
     /**
     * Create timestamps before new user created
     * @param  array $user
     * @return array
     */
    protected function timestamps($user)
    {
        $user['created_date'] = $user['updated_date'] = date('Y-m-d H:i:s');

        return $user;
    }



    /**
    * Answer list of questions
    * @param $question_id
    * @return response answer list
    */
    public function answersList($question_id){
        $this->db->select('answer_id,answer_title');
                    $this->db->where('question_id',$question_id);
                    return $this->db->get('answer_option')->result();
    }


}
?>