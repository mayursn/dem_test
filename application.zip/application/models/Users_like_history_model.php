<?php

class Users_like_history_model extends MY_Model
{

     public function __construct()
    {
        $this->table = 'users_like_history';
        $this->primary_key = 'history_id';
        $this->soft_deletes = false;        
        $this->before_create = array('timestamps');
  
        parent::__construct();
    }
      

    //callbacks
   
     /**
     * include created time in array to insert data
     * @param  array $user
     * @return array
     */
    protected function timestamps($user)
    {
        $user['created_date'] =  date('Y-m-d H:i:s');

        return $user;
    }


}
?>