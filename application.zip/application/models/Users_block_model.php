<?php

class Users_block_model extends MY_Model
{

     public function __construct()
    {
        $this->table = 'users_block';
        $this->primary_key = 'block_id';
        $this->soft_deletes = false;        
        $this->before_create = array('timestamps');
        
        parent::__construct();
    }
      

    //callbacks
   
     /**
     * include created time in array to insert data
     * @param  array $user
     * @return array
     */
    protected function timestamps($user)
    {
        $user['created_date'] = $user['updated_date'] =  date('Y-m-d H:i:s');

        return $user;
    }

    /**
    * Check Block unblock status of sender and receiver
    * @param sender_id,receiver_id
    * return response int
    */
     function checkBlock($sender_id,$receiver_id){
        $this->db->where("users_id",$sender_id);
        $this->db->where("blocked_users_id",$receiver_id);         
        $res = $this->db->get("$this->table")->result();

        if($res){
            return "1";
        }


        $this->db->where("users_id",$receiver_id);
        $this->db->where("blocked_users_id",$sender_id);         
        $res2 = $this->db->get("$this->table")->result();
        if($res2){
            return "2";
        }

         
    }
    /**
    * Logged in user block list
    * @param $users_id
    * @return response array
    * Date : 29-1-2018 By Mayur Panchal    
    */
    function usersBlockList($users_id,$page,$perPage){
        $page = ($page * $perPage);
        $this->db->select('u.users_id,concat(u.users_fname," ",u.users_lname) as name');
        $this->db->where('ub.users_id',$users_id);
        $this->db->join('users u','u.users_id=ub.blocked_users_id','left');
        $this->db->limit($perPage,$page);
        return $this->db->get('users_block ub')->result();
    }

    /**
    * Logged in user block list
    * @param $users_id
    * @return response array
    * Date : 29-1-2018 By Mayur Panchal    
    */
    function usersBlockListNumRows($users_id){
        
        $this->db->select('u.users_id,concat(u.users_fname," ",u.users_lname) as name');
        $this->db->where('ub.users_id',$users_id);
        $this->db->join('users u','u.users_id=ub.blocked_users_id','left');        
        return $this->db->get('users_block ub')->num_rows();
    }


    
}
?>