<?php

class User_images_model extends MY_Model
{
	public $primary_key = 'user_image_id';

    //callbacks
    public $before_create = array('timestamps');
    public $before_update = array('update_timestamp');
    

     /**
     * Create timestamps before new user created
     * @param  array $user
     * @return array
     */
    protected function timestamps($user)
    {
        $user['created_date'] = $user['updated_date'] = date('Y-m-d H:i:s');

        return $user;
    }

  

    /**
     * Update timestamp before update user details
     * @param  array $user
     * @return array
     */
    protected function update_timestamp($user)
    {
        $user['updated_date'] = date('Y-m-d H:i:s');

        return $user;
    }


    

}
?>