<?php

class Questions_master_model extends MY_Model
{

     public function __construct()
    {
        $this->table = 'questions_master';
        $this->primary_key = 'question_id';
        $this->soft_deletes = false;
        $this->before_create = array('timestamps');        
        $this->before_update = array('update_timestamp');   
        $this->has_many = array(
            'answer_option' => array(
                'foreign_model' => 'Answer_option_model',
                'foreign_table' => 'answer_option',
                'foreign_key' => 'question_id',
                'local_key' => 'question_id'
            )

        );
        $this->column_order = array('question_title','answer_option_1','answer_option_2','answer_option_3','answer_option_4','question_id');
        $this->column_search = array('question_title','answer_option_1','answer_option_2','answer_option_3','answer_option_4','question_id'); //set column field database for datatable searchable
        $this->before_get =  array('get_before');
        $this->order = array($this->table.'.question_id' => 'desc');   
        parent::__construct();
    }
    
    protected function get_before(){
        $this->db->where('is_deleted','0');
    }

    //callbacks
   
     /**
     * Create timestamps before new user created
     * @param  array $user
     * @return array
     */
    protected function timestamps($user)
    {
        $user['created_date'] = $user['updated_date'] = date('Y-m-d H:i:s');

        return $user;
    }

    /**
     * Update timestamp before update user details
     * @param  array $user
     * @return array
     */
    protected function update_timestamp($user)
    {
        $user['updated_date'] = date('Y-m-d H:i:s');

        return $user;
    }


    public function questionCreateSP($data){
        return $this->db->query("call questionInsert('".$data['txtname']."',
                                                '".$data['option1']."',
                                                '".$data['option2']."',
                                                '".$data['option3']."',
                                                '".$data['option4']."',@p_question_id)");
        $query = $this->db->query("SELECT @p_question_id as id");
        return $query->row();
        
    }

     private function _get_datatables_query()
    {
        $this->db->select('*');
        $this->db->from($this->table);
        //$this->db->join('location_master','location_master.location_id=work_master.location_id');
        //$this->db->join('doctor_details','doctor_master_en.doctor_id=doctor_details.doctor_id','right');
        //$this->db->join('specialty_master','specialty_master.specialties_id=doctor_details.speciality_id','left');
        //$this->db->join('location_master','location_master.location_id=doctor_details.location_id','left');

        

       
        

        $i = 0;

        foreach ($this->column_search as $item) // loop column
        {
            if (@$_POST['search']['value']) //if datatable send POST for search
            {

                if ($i === 0) // first loop
                {
                    $this->db->group_start(); // open bracket. query Where with OR clause better with bracket. because maybe can combine with other WHERE with AND.
                    $this->db->like($item, $_POST['search']['value']);
                } else {
                    $this->db->or_like($item, $_POST['search']['value']);
                }

                if (count($this->column_search) - 1 == $i) //last loop
                {
                    $this->db->group_end();
                }
                //close bracket
            }
            $i++;
        }

        if (isset($_POST['order'])) // here order processing
        {
            $this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        } else if (isset($this->order)) {
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    public function get_datatables()
    {
        $this->_get_datatables_query();
        if (@$_POST['length'] != -1) {
            $this->db->limit(@$_POST['length'], @$_POST['start']);
        }

        $query = $this->db->get();
        return $query->result();
    }

    public function count_filtered()
    {
        $this->_get_datatables_query();
        $query = $this->db->get();
        return $query->num_rows();
    }

    public function count_all()
    {
        $this->db->from('questions_master');
        return $this->db->count_all_results();
    }

}
?>