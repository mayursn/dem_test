<?php

class Profile_visit_model extends MY_Model
{

    public function __construct()
    {
        $this->table = 'profile_visit';
        
        $this->primary_key = 'visit_id';

    //callbacks
        $this->before_create = array('timestamps');
   
   
        parent::__construct();
    }
    

     /**
     * Create timestamps before new user created
     * @param  array $user
     * @return array
     */
    protected function timestamps($user)
    {
        $user['created_date'] =  date('Y-m-d H:i:s');

        return $user;
    }

    
}
?>