<?php

class User_interested_model extends MY_Model
{

     public function __construct()
    {
        $this->table = 'user_interested';
        $this->primary_key = 'interested_id';
        $this->soft_deletes = false;
        $this->before_create = array('timestamps');        

        parent::__construct();
    }
    

    //callbacks
   
     /**
     * Create timestamps before new user created
     * @param  array $user
     * @return array with include created date
     */
    protected function timestamps($data)
    {
        $data['created_date'] = $data['updated_date'] = date('Y-m-d H:i:s');

        return $data;
    }


    /**
    * User Interested or not entry
    * @param $users_id,$interested int
    * @return response
    */
    public function get_interest($users_id,$interested){
        return $this->db->select()
        ->where(['users_id'=>$users_id,'interest_user_id'=>$interested])
        ->or_where(array('interest_user_id'=>$users_id,'users_id'=>$interested))
        ->get($this->table)
        ->row();
                                            
                                            
        
    }



}
?>