<?php

class Orientation_master_model extends MY_Model
{

     public function __construct()
    {
        $this->table = 'orientation_master';
        $this->primary_key = 'orientation_id';
        $this->soft_deletes = false;
        $this->before_create = array('timestamps');     
        /*$this->has_one = array(
            'user' => array(
                'foreign_model' => 'Users_model',
                'foreign_table' => 'users',
                'foreign_key' => 'users_id',
                'local_key' => 'user_id'
            )
        );*/
        
        $this->order = array($this->table.'.orientation_id' => 'desc');   
        parent::__construct();
    }
    
    //callbacks
   
     /**
     * Create timestamps before new user created
     * @param  array $user
     * @return array
     */
    protected function timestamps($user)
    {
        $user['created_date'] = $user['updated_date'] = date('Y-m-d H:i:s');

        return $user;
    }


}
?>