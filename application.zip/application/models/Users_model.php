<?php

class Users_model extends MY_Model
{

    public function __construct()
    {
        $this->table = 'users';
        
        $this->primary_key = 'users_id';

    //callbacks
        $this->before_create = array('timestamps');
        $this->before_update = array('update_timestamp');
        $this->before_get = array('getbefore');

        //relationships
        $this->has_many = array(
            'logs' => array(
                'foreign_model' => 'Logs_model',
                'foreign_table' => 'logs',
                'foreign_key' => 'user_id',
                'local_key' => 'users_id'
            )

        );

        //relationships       
         $this->has_many = array(
            'userpref' => array(
                'foreign_model' => 'User_preference_model',
                'foreign_table' => 'user_preference',
                'foreign_key' => 'users_id',
                'local_key' => 'users_id'
            )

        );

       
   
   
        parent::__construct();
    }
	

     /**
     * Create timestamps before new user created
     * @param  array $user
     * @return array
     */
    protected function timestamps($user)
    {
        $user['created_date'] = $user['updated_date'] = date('Y-m-d H:i:s');

        return $user;
    }

  

    /**
     * Update timestamp before update user details
     * @param  array $user
     * @return array
     */
    protected function update_timestamp($user)
    {
        $user['updated_date'] = date('Y-m-d H:i:s');

        return $user;
    }

    /**
    * Check Before get Data
    * check conditions before get user data
    * 
    */
    protected function getbefore(){
        $this->db->where('is_deleted','0');
    }


    public function getLoggedinUser($id){
        $this->db->select('u.users_fname,u.users_lname,u.users_email,u.users_gender,u.users_location');
        $this->db->where('u.users_id',$id);
        $this->db->join('user_images ui','ui.users_id=u.users_id','left');
        return $this->db->get('users u')->row();
    }

    /**
    * Check User already register or not
    * @param $fbtoken is facebook token
    * @return row as array 
    */
    public function getFBTokenSP($fbtoken){
        
         $query = $this->db->query("call getUserByFBToken('".$fbtoken."')");
        return $query->row();
    }



    /**
    * SP for insert users
    * @param $data array
    * @return $query user id
    */
    public function insertUser($data){
     $success =  $this->db->query("call usersInsert('".$data['firstname']."','".$data['lastname']."','".$data['email']."','".$data['mobile_no']."','".$data['fbtoken']."', @pusers_id)");
            $this->db->trans_start();
            $success->next_result();
            $success->free_result();
            $query = $this->db->query('select @pusers_id as out_param');
            $this->db->trans_complete();
            return $query;

        
    }


    /**
    * get user detail by FBToken
    * @return row
    */
    public function getUserFieldByFBToken($fbtoken){

        $this->db->where('fb_token',$fbtoken);
        return $this->db->get($this->table)->row();
    }



    /**    
    *  Get User Profile 
    *  @param $profile_user_id int
    *  @return result mixed array
    *   join tables user preference and user images
    */
    public function get_profile($profile_user_id,$lat,$long){
        $this->db->select("u.users_id,concat(u.users_fname,' ',u.users_lname) as name,IFNULL(u.users_age,'') as users_age,IFNULL(u.users_dob,'') as users_dob,IFNULL(u.users_gender,'') as gender,IFNULL(u.about,'') as self_summery,IFNULL(u.looking_for,'') as looking_for,IFNULL(u.from_age,'') as from_age,IFNULL(u.to_age,'') as to_age, COALESCE(l.name, '') as users_location,IFNULL(u.fb_token,'') as fb_token,
            3956 * 2 * ASIN(SQRT( POWER(SIN(($lat - users_latitude) * pi()/180 / 2), 2) + COS($lat * pi()/180) * COS(users_latitude * pi()/180) *
            POWER(SIN(($long - users_longitude) * pi()/180 / 2), 2) )) as
            distance,IFNULL(u.discovery,'') as discovery,IFNULL(u.offline_time,'') as offline_time,IFNULL(u.is_online,'') as is_onine, IFNULL(u.get_more_visits,'0') as is_promoted");
        $this->db->join('location l','l.location_id=u.users_location','left');
        
        $this->db->where('u.users_id',$profile_user_id);
        return $this->db->get("$this->table u")->row();

        /*$this->db->join('user_preference up','u.users_id=up.users_id','left');
        $this->db->join('preference_master pm','pm.preference_id=up.preference_id','left');
        $this->db->join('preferences p','p.preferences_option_id=up.preference_option_id','left');        */
    }



  /**
  * get User Details
  * @param $users_id int
  * @return mixed array
  * join user preference and images table
  */
  public function getusersDetails($users_id){
    


   $this->db->select('u.users_id,u.users_fname,u.users_lname,u.users_email,u.users_status,u.users_gender,u.users_gender,u.users_location,u.country,u.users_latitude,u.users_longitude,u.users_dob,u.users_age,u.user_ip,u.fb_token,u.device_token,u.created_date,u.updated_date,pm.preference_id,pm.preference_name,p.preferences_option_id,p.option_title,ul.name as users_location,ulc.name as country,u.users_height,u.from_age,u.to_age,u.looking_for,u.premium_status,u.freetrial_start_date,u.freetrial_end_date,u.premium_trial_used,u.weekly_credits,u.total_credits');
    $this->db->join('user_preference up','up.users_id=u.users_id','left');
    $this->db->join('preferences p','p.preference_id=up.preference_id','left');
    $this->db->join('preference_master pm','pm.preference_id=up.preference_id','left');
    $this->db->join('location ul','ul.location_id=u.users_location','left');
    $this->db->join('location ulc','ulc.location_id=u.country','left');
    $this->db->where('u.users_id',$users_id);
    return $this->db->get("$this->table u")->row();
  }


  /**
  * Get Preferences of user
  * @param $id int 
  * @return response mixed array
  */
  public function get_Preference($id){
        return $this->db->select('pm.preference_name,p.option_title,p.*')
        ->join('preference_master pm','pm.preference_id=up.preference_id','left')
        ->join('preferences p','p.preferences_option_id=up.preference_option_id','left')
        ->where('up.users_id',$id)
        ->get('user_preference up')->result();
  }


  /**
  * Last Week Registered user
  * @param 
  * @return result array
  */
  public function getLastWeekUsers(){
    
    return $this->db->select('users_id')                    
                    ->get($this->table)
                    ->num_rows();
  }

/**
  * Online USers
  * @param 
  * @return result array
  */
  public function onlineUser(){
    
    return $this->db->select('users_id')
                    ->where('is_online','1')
                    ->where('users_status!=','2')
                    ->where('users_id NOT IN (SELECT blocked_users_id FROM users_block)')
                    ->get($this->table)
                    ->num_rows();

  }


  /**
  * This week registered user count
  * @param
  * @return response int (number of rows)
  *
  */
  public function thisWeek(){
    return $this->db->select('users_id')
                    ->where("created_date > DATE_SUB(NOW(), INTERVAL 1 WEEK)")
                    ->get($this->table)->num_rows();
  }

  /**
  *
  *
  */

  public function lastweekDays(){
    return $this->db->select('count(users_id) as days')
                    ->where("DATE(created_date ) > DATE_SUB( CURDATE( ) , INTERVAL 1 MONTH )")
                    ->group_by("DAYOFMONTH(DATE(created_date))")
                    ->get($this->table)
                    ->result();
      

  }


  /**
  * Yester day registered user total count for admin dashboard
  * @param
  * @return response int count total users
  */

  public function yesterdayUsers(){
    return $this->db->select()
                    ->where("created_date BETWEEN date_sub(curdate(),interval 1 day) AND date_sub(curdate(),interval 0 day)")
                    ->get($this->table)
                    ->num_rows();
  }


  /**
  * This week registered user total count for admin dashboard
  * @param
  * @return response int count total users
  */

  public function thiweekUsers(){
    return $this->db->select()
                    ->where("created_date BETWEEN DATE_SUB( CURDATE( ) ,INTERVAL (dayofweek(CURDATE())-2) DAY ) AND CURDATE( )")
                    ->get($this->table)
                    ->num_rows();
  }


  /**
  * Last Month registered user total count for admin dashboard
  * @param
  * @return response int count total users
  */

  public function lastmonthUsers(){
    return $this->db->select()
                    ->where("month(created_date) = month(date_add(now(),interval -1 month))")
                    ->get($this->table)
                    ->num_rows();
  }

  /**
  * This year registered user total count for admin dashboard
  * @param
  * @return response int count total users
  */

  public function thisyearUsers(){
    return $this->db->select()
                    ->where("year(created_date) = year(date_add(now(),interval 0 year))")
                    ->get($this->table)
                    ->num_rows();
  }

  

/*
  public function userPerecentage($users_id,$profile_user_id){
    return $this->db->query("SELECT ROUND(SUM(matching) * 100 / SUM(totalpref),0) as totalmatchpercent  FROM (SELECT (SELECT count(preference_option_id)  FROM user_preference WHERE users_id=$profile_user_id) as opp_user_prf, (SELECT count(preference_option_id)  FROM user_preference WHERE preference_option_id in (SELECT preference_option_id FROM user_preference WHERE users_id=$profile_user_id) AND users_id=$users_id ) as matching, (SELECT count(preference_option_id) FROM user_preference WHERE preference_option_id in (SELECT preference_option_id FROM user_preference WHERE users_id='4') AND users_id=$users_id ) * 100 / count(*) as totalpercent,count(*) as totalpref FROM user_preference WHERE users_id=$users_id
      UNION ALL
      (SELECT (SELECT count(answer_id)  FROM user_questions WHERE users_id=$profile_user_id) as opp_user_prf, (SELECT count(answer_id)  FROM user_questions WHERE answer_id in (SELECT answer_id FROM user_questions WHERE users_id=$profile_user_id) AND users_id=$users_id ) as matching, (SELECT count(answer_id) FROM user_questions WHERE answer_id in (SELECT answer_id FROM user_questions WHERE users_id=$profile_user_id) AND users_id=$users_id ) * 100 / count(*) as totalpercent,count(*) as totalpref  FROM user_questions WHERE users_id=$users_id)) t1 WHERE matching IS NOT NULL ")->row()->totalmatchpercent;
  }
*/
    
 /**
  * Get matching percentage
  * @param $users_id $profile_user_id int(11)
  * @return response userPerecentage
  */
  public function userPerecentage($users_id,$profile_user_id){
      return $this->db->query("SELECT ROUND(AVG(totalpercent),0) as totalmatchpercent FROM (SELECT (SELECT count(preference_option_id) FROM user_preference WHERE preference_option_id in (SELECT preference_option_id FROM user_preference WHERE users_id=$profile_user_id) AND users_id=$users_id) * 100 / count(*) as totalpercent FROM user_preference WHERE users_id=$users_id UNION ALL SELECT (SELECT count(*) FROM user_questions uq LEFT JOIN user_questions suq ON suq.question_id=uq.question_id WHERE uq.users_id=$users_id AND suq.users_id=$profile_user_id AND FIND_IN_SET(suq.answer_id,uq.opp_user_them)) * 100 / count(*) as totalpercent FROM user_questions WHERE users_id=$users_id  ) t1

")->row()->totalmatchpercent;
  }


  
  /**
  * Get matching percentage only preference
  * @param $users_id $profile_user_id int(11)
  * @return response userPerecentage
  */
  public function userPreferencePerecentage($users_id,$profile_user_id){
      return $this->db->query("SELECT (SELECT count(preference_option_id) FROM user_preference WHERE preference_option_id in (SELECT preference_option_id FROM user_preference WHERE users_id='$users_id') AND users_id='$profile_user_id' ) * 100 / count(*) as totalpercent FROM user_preference WHERE users_id='$profile_user_id'")->row()->totalpercent;
  }

  
  public function userProfileget($users_id){
     $this->db->select('users_id,IFNULL(users_fname,"") as users_fname,IFNULL(users_lname,"") as users_lname,IFNULL(users_gender,"") as users_gender,IFNULL(users_dob,"") as users_dob,IFNULL(users_location,"") as users_location,IFNULL(country,"") as country,IFNULL(about,"") as self_summery,is_invisible,IFNULL(get_more_visits,"0") as is_promoted');
            $this->db->where(['users_id'=>$users_id]);
        return $this->db->get('users')->row();
  }


  function getUSerNoticeData($users_id){
    $this->db->select('users_id,IFNULL(users_fname,"") as users_fname,IFNULL(users_lname,"") as users_lname,IFNULL(ul.name,"") as users_location,is_invisible');
    $this->db->where('users_id',$users_id);    
    $this->db->join('location ul','ul.location_id=users.users_location','left');
    return $this->db->get('users')->row();
  }

  function getPrimaryImg($users_id){
    $this->db->select('user_img');
    $this->db->where(['users_id'=>$users_id,'image_index'=>1]);
    return  $this->db->get('user_images')->row();
  }



  /**
  * Get Random users 
  * @param $id, $where
  * 24-05-2018  
  */
  function getRandomUsers($id,$where){
    
             $this->db->select('*');
             if(count($where) > 0){
                $this->db->where($where);
              }
             $this->db->where("users_id NOT IN ($id)");
             $this->db->order_by("RAND()");
             $this->db->limit('20');
             $this->db->where('users_status','1');
       $result = $this->db->get('users')->result();

       if(count($result) < 20){
             $this->db->select('*');             
             $this->db->where("users_id NOT IN ($id)");
             $this->db->order_by("RAND()");
             $this->db->where('users_status','1');
             $this->db->limit('20');
       $result = $this->db->get('users')->result();
       }
       return $result;
       
  } 

    
}
?>