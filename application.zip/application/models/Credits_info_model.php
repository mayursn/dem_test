<?php
# credit model is purchasing Additional Credits table
# which is store all details of amount of credits for purchase
# 
class Credits_info_model extends MY_Model
{

     public function __construct()
    {
        $this->table = 'credits_info';
        $this->primary_key = 'id';
        $this->soft_deletes = false;     
        $this->before_create = array('timestamps');
        $this->before_get = array('checkdeleted','checkdaily'); 
        
        parent::__construct();
    }
      

    //callbacks
   
     /** 
     * Create timestamps before new user created
     * @param  array $user
     * @return array
     */
    protected function timestamps($user)
    {
        $user['created_date'] = date('Y-m-d H:i:s');

        return $user;
    }

    /* checked deleted info not showing in list */
    protected function checkdeleted(){
        return $this->db->where('status!=','2');
    }

    /* check daily subscription details not showing*/
    protected function checkdaily(){
        return $this->db->where('status!=','3');
    }

   


}
?>