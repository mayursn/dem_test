<?php

class User_preference_model extends MY_Model
{


     public function __construct()
    {
        $this->table = 'user_preference';
        $this->primary_key = 'user_preference_id';
        $this->soft_deletes = false;
      
        $this->before_create = array('timestamps');
        $this->before_update = array('update_timestamp');
        parent::__construct();
    }
	
     /**
     * Create timestamps before new user created
     * @param  array $user
     * @return array
     */
    protected function timestamps($user)
    {
        $user['created_date'] = $user['updated_date'] = date('Y-m-d H:i:s');

        return $user;
    }

  

    /**
     * Update timestamp before update user details
     * @param  array $user
     * @return array
     */
    protected function update_timestamp($user)
    {
        $user['updated_date'] = date('Y-m-d H:i:s');

        return $user;
    }


    public function insertUsingSP($data){
       return $this->db->query("call usersPreferenceSet('".$data['orientation']."',
                                                '".$data['distance']."',
                                                '".$data['age_range']."',
                                                '".$data['work_business']."',
                                                '".$data['education']."',
                                                '".$data['marital_status']."',
                                                '".$data['interest']."',
                                                '".$data['ethnicity']."',
                                                '".$data['languages']."',
                                                '".$data['smoking']."',
                                                '".$data['drinking']."',
                                                '".$data['religion']."',
                                                '".$data['kids']."',
                                                '".$data['looking_forward']."',
                                                '".$data['relationship_type']."
                                                ',
                                                '".$data['users_id']."
                                                ')");
    }
    public function updateUsingSP($data){
       return $this->db->query("call updatePreferenceUsingSP('".$data['orientation']."',
                                                '".$data['distance']."',
                                                '".$data['age_range']."',
                                                '".$data['work_business']."',
                                                '".$data['education']."',
                                                '".$data['marital_status']."',
                                                '".$data['interest']."',
                                                '".$data['ethnicity']."',
                                                '".$data['languages']."',
                                                '".$data['smoking']."',
                                                '".$data['drinking']."',
                                                '".$data['religion']."',
                                                '".$data['kids']."',
                                                '".$data['looking_forward']."',
                                                '".$data['relationship_type']."
                                                ',
                                                '".$data['users_id']."
                                                ')");
    }

    

    public function checkPreference($user_id){
            $this->db->where('users_id',$user_id);
        return $this->db->get($this->table)->row();
        /*return $this->db->query("call checkPreference('".$user_id."')")->row();*/
    }

    /**
    * Update preference of user
    * @param $data preferences and $user_preference_id is primary key
    * @return void
    */
    public function update_data($data,$user_preference_id){

        $this->db->where('user_preference_id',$user_preference_id);
              return $this->db->update('user_preference',$data);
              

    }


    /**
    * Get User preference
    * @param $profile_user_id
    * @return response array
    */
    public function getPreferences($profile_user_id){
    return $this->db->select('pm.preference_name,p.option_title')
            ->join('preference_master pm','pm.preference_id=up.preference_id','left')
            ->join('preferences p','p.preferences_option_id=up.preference_option_id','left')
            ->where('up.users_id',$profile_user_id)
            ->get("$this->table up")
            ->result();
    }


    
    /**
    * Get Orientation and gender
    * @param $users_id
    * @return response array
    */

    public function orientation($users_id){
        return $this->db->select("p.option_title, pm.preference_name")
        ->join('user_preference up','pm.preference_id=up.preference_id','left')
        ->join('preferences p ','p.preferences_option_id=up.preference_option_id','left')
        ->where("pm.preference_id IN ('1','2')")
        ->where('up.users_id',$users_id)
        ->get('preference_master pm')
        ->result();

    }
    

}
?>