<?php

class Settings_model extends MY_Model
{
    // primary key

    public $primary_key = 'settings_id';
    public $before_create = array('timestamps');
    public $before_update = array('update_timestamp');
    public $table = 'settings';
    /**
     * Set timestamps before creating db config
     * @param  array $settings
     * @return array
     */
    protected function timestamps($settings)
    {
        $settings['created_date'] = $settings['updated_date'] = date('Y-m-d H:i:s');

        return $settings;
    }

    /**
     * Set update timestamp before updating db config
     * @param  array $settings
     * @return array
     */
    protected function update_timestamp($settings)
    {
        $settings['updated_date'] = date('Y-m-d H:i:s');

        return $settings;
    }

    /**
     * Save or update db config
     * @param  array $data
     */
    public function save_config($data)
    {
        foreach ($data as $key => $value) {
            $is_config_avail = $this->db->get("settings",[
                'site_key' => $key,
            ]);


            if (count($is_config_avail)) {
                //update config data
                
                $this->db->update('settings',
                    [
                        'site_value' => $value,
                    ],
                    [
                        'site_key' => $key,
                    ]
                ); 

            } else {
                $this->insert('settings',[
                    'site_key' => $key,
                    'site_value' => $value,
                ]);
            }

        }

    }
}
