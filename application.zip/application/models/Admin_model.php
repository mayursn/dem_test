<?php
class Admin_model extends MY_Model {       

	  // primary key
	//public $table = 'admin';
    
    

    //callbacks
    

    public function __construct()
    {
        $this->table = 'admin';
        $this->primary_key = 'admin_id';
        $this->soft_deletes = false;
        //$this->has_one['details'] = 'User_details_model';
        // $this->has_one['details'] = array('User_details_model','user_id','id');
        //$this->has_one['details'] = array('local_key'=>'id', 'foreign_key'=>'user_id', 'foreign_model'=>'User_details_model');
        //$this->has_many['posts'] = 'Post_model';
        $this->before_create = array('timestamps');
        //$this->before_get = array('getbefore');

        
        parent::__construct();
    }
  // /  public $before_update = array('update_timestamp');
    

    // Protected, non-modifiable attributes
    

    // user belongs to user type (many to one relationship)
    

    // Support for soft deletes and this model's 'deleted' key
    

    /**
     * Create timestamps before new user created
     * @param  array $user
     * @return array
     */
    protected function timestamps($data)
    {

        $data['created_date'] = date('Y-m-d H:i:s');
        $data['updated_date'] = date('Y-m-d H:i:s');

        return $data;
    }

    
    /**
     * Update timestamp before update user details
     * @param  array $user
     * @return array
     */
   /* protected function update_timestamp($data)
    {
        $data['updated_date'] = date('Y-m-d H:i:s');

        return $data;
    }
*/

     /**
     * Login with email and password
     * @param  string $email
     * @param  string $password
     * @return object
     */
    public function login($email, $password)
    {
        $this->db->group_start();
        $this->db->where('admin_email', $email);                
        $this->db->group_end();
        $this->db->where([
            'admin_password' => $password,
        ]);

        $user = $this->db->get('admin')->row();

        /*if ($user) {
            $user = $this->Admin_model->with_deleted()->get($user->admin_id);
        }*/

        return $user;
    }


    public function insert_data($data){
         $data['created_date'] = date('Y-m-d H:i:s');
        $data['updated_date'] = date('Y-m-d H:i:s');

        $this->db->insert('admin',$data);
        return $this->db->insert_id();
    }

    /**
    * Update profile
    * @param int $id logged in user id
    * @param array $data
    * @return int
    */
    public function update_data($id,$data){
         $data['updated_date'] = date('Y-m-d H:i:s');
    	$this->db->where('admin_id',$id);
    	return $this->db->update('admin',$data);
    }


    /**
     * Change password for user
     * @param  int $user_id  Loggedin user id
     * @param  string $password
     * @return int
     */
    public function change_password($user_id, $password)
    {
        $this->db->where('admin_id',$user_id);
        $id = $this->db->update('admin', array('admin_password' => $password));

        return $id;
    }


    /**
     * get data for forgot email
     * @param $email is email id of admin user
     * @return array
     */
    public function get_by_email($email=''){
        $this->db->where('admin_email',$email);
        return $this->db->get('admin')->row();

    }

    /**
     * Generate token for forgot password
     * @param $email is email id of admin user
     * @return array
     */
    public function update_token($email,$token){
        $data['generated_date'] = date('Y-m-d H:i:s');
        $data['password_token'] = $token;
        $this->db->where('admin_email',$email);
        $this->db->update("admin",$data);
    }


    public function ListAdmin($where= ''){

        $this->db->where($where);

        return $this->db->get('admin')->result();
    }

    public function totalAdmin(){
        return $this->db->select('admin_id')
        ->where('is_deleted','0')
        ->where('admin_type','1')
        ->get($this->table)
        ->num_rows();
    }


}