<?php
class MY_Controller extends CI_Controller
{

    public function __construct() {

        parent::__construct(); 
        $this->load->model('Settings_model');
        //$this->data['page'] = '';
        $this->data['site_detail'] = $this->site_details();
        if($this->is_logged_in()){
            $this->login_user_role_permission();  
            if(!count($this->data['permission'])) {

                echo '<h3>You don\'t have permission to access any module. Please contact admin</h3>';
                exit;
            }
        }
        
        $this->data['parentPage'] = "";
        $this->data['bgcolor'] = "bg-gray";

    }


    /**
    * Check user exists or not
    * @param $id user id
    * @return bool
    */
    public function checkuserId($id)
    {
        $this->load->model("Users_model");
        $result = $this->Users_model->get(['users_id' => $id]);
        if ($result) {
            return TRUE;
        }
        else {
            return FALSE;
        }
    }


     /**
     * Template
     * @param string $page_name
     * @param mixed $data
     */
    function __template($page_name, $data) {
        $this->load->view('admin/header',$data);
        $this->load->view($page_name,$data);
        $this->load->view('admin/footer',$data);
    }

    /**
     * Check whether user loggedin or not
     * @return boolean
     */
    public function is_logged_in()
    {
        $is_logged_in = $this->session->userdata('is_logged_in');
        if ($is_logged_in) {
            return true;
        }

        return false;
    }



    /**
     * user information logs
     * @return boolean
     */
    /*public function _trackUser($authorized = FALSE,$message='',$status='')
    {
        return $this->rest->db->insert(config_item('rest_logs_table'), array(
            'uri' => $this->uri->uri_string(),
            'method' => $this->request->method,
            'params' => serialize($this->_args),
            'api_key' => isset($this->rest->key) ? $this->rest->key : '',
            'ip_address' => $this->input->ip_address(),
            'time' => function_exists('now') ? now() : time(),
            'authorized' => $authorized,
            'message'=>$message,
            'status'=>$status
        ));

    }
*/

    /**
     * Site details
     * @return object Web site config details
     */
    public function site_details()
    {
        $config = array();
        $result = $this->Settings_model->get_all();

        foreach ($result as $row) {
            $config[$row->site_key] = $row->site_value;
        }

        return (object) $config;
    }


    /**
     * Generate one way hash by using sha512
     * @param  string $str
     * @return string
     */
    public function _hash($str)
    {
        return hash('sha512', $str . config_item('encryption_key'));
    }


     /**
     * Add dynamic js in footer
     * @param array $js
     */
    public function add_js($js = array())
    {
        $this->data['script'] =$js;
        /*foreach ($js as $row) {
            array_push($this->data['scripts'], $row);
        }*/
    }

    /**
     * Add dynamic css
     * @param array $css
     */
    public function add_css($css = array())
    {
        $this->data['css'] = $css;
        /*foreach ($css as $row) {
            array_push($this->data['css'], $row);
        }*/
    }


    public function modulelist(){
        $this->load->model('List/Modules_model');
        return  $this->Modules_model->get_all();
    }


    /**
     * Get the login user permission
     */
    function login_user_role_permission() {
        $this->load->model('List/Permission_model');
        

        $user_role_module = $this->Permission_model
                ->role_permission_with_module($this->session->userdata('admin_id'));
             

        foreach($user_role_module as $row) {
            $module = $row->module_name;
            $this->data['permission'][$module] = array();
            $user_permission  = array('perm_create' => $row->perm_create,'perm_read' => $row->perm_read,
            'perm_update' => $row->perm_update,
            'perm_delete' => $row->perm_delete );
            array_push($this->data['permission'][$module], $user_permission);

        }
       
    }


    function _checkAllPermission($moduleName){
        return checkAllPermission($moduleName);

    }


}
 ?>