<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
$lang['user_inactive'] = 'User Inactive';
$lang['user_blocked'] = 'User Blocked';
$lang['user_signin_success_message'] = 'User Successfully sign in.';
$lang['user_deleted'] = 'User Deleted.';
$lang['invalid_token'] = 'Invalid token';
$lang['more_messages'] = "Get more messages";
$lang['move_top'] = "Move to the top";
$lang['more_matches'] = "To get more matches";
$lang['more_visits'] = "To get more visits";
$lang['emojis'] = "Emoji's";
$lang['direct_message'] = "Send messages to the people not connected to you";
$lang['daily_credits'] = "Daily Credit";
$lang['daily_expired'] = "Daily Expired";
$lang['free_premium_trial'] = "14 Days free premium trial";
$lang['cancel_subscription'] = "Cancel Subscription";
$lang['manually_cancel'] = "Manually cancel subscription";

?>