<?php
defined('BASEPATH') OR exit('No direct script access allowed ');
class Admin extends MY_Controller {

    function __construct() {
        parent::__construct(); 
        $this->load->model('Admin_model');
        $this->load->model('Users_model');
        ini_set('post_max_size','0');
        if(!$this->is_logged_in()){
          redirect(base_url()."snackadmin/login");
        }
    }


     /**
      * This function is update profile
      * @return Void
      */
    public function index() {
            if($_POST){
                $is_valid_data = true;

                    if ($this->form_validation->run('admin_profile') == false) {
                            set_error_notification(validation_errors());
                        } else {

                        if ($_FILES['photo']['name'] != '') {
                                $config = array(
                                    'upload_path' => './uploads/admin',
                                    'allowed_types' => 'jpg|gif|png|bmp|jpeg',
                                    'max_size' => '2048',
                                    'multi' => 'all',
                                );
                                $this->load->library('upload', $config);
                                if (!$this->upload->do_upload('photo')) {
                                    set_error_notification($this->upload->display_errors());
                                    $is_valid_data = false;
                                } else {
                                    $upload_data = $this->upload->data();
                                }
                            }



                            if ($is_valid_data) { 
                                 $id = $this->input->post('id',true);

                                $profile = $this->Admin_model->update_data($id, [
                                    'admin_name' => $this->input->post('txtname', true),
                                    'admin_email' => $this->input->post('txtemail', true),
                                    'admin_mobile' => $this->input->post('txtphone', true)
                                ]);

                                 $this->session->set_userdata('name', $this->input->post('txtname', true));
                                 $this->session->set_userdata('email', $this->input->post('txtemail', true));
                                 

                                if ($_FILES['photo']['name'] != '') {

                                    $this->Admin_model->update_data($id, [
                                        'admin_photo' => $upload_data['file_name'],
                                    ]);

                                    //set session
                                    $this->session->set_userdata('photo', $upload_data['file_name']);
                                }
                               
                                set_success_notification("Data updated successfully");


                            }
                            
                        }

        }
        redirect(base_url().'snackadmin/editprofile', 'refresh');
    }

    

    /**
    Edit profile view after login
    */
    public function editprofile(){

        $this->add_css(["plugins/node-waves/waves.css",
                              "plugins/animate-css/animate.css",
                              "plugins/sweetalert/sweetalert.css",
                              "css/style.css",
                             ]);
        $this->add_js(["plugins/bootstrap-select/js/bootstrap-select.js",
                              "plugins/jquery-slimscroll/jquery.slimscroll.js",
                              'plugins/jquery-validation/jquery.validate.js',
                              "plugins/node-waves/waves.js",
                              "js/admin.js",
                              "js/demo.js",
                              'js/form_validate.js',
                             ]);
                             


      $admin_id = $this->session->userdata('admin_id');
      $this->data['profile'] = $this->Admin_model->get( array('admin_id' =>  $admin_id));
      $this->data['page'] = "dashboard";
      $this->__template('admin/editprofile', $this->data);                
    }
   


    /* General settings */ 
    /**/ 

    public function settings(){
        $this->data['moduleName'] = 'settings';
        if($_POST){
             if ($this->input->post('setting_type', true) == 'general') {
                //general settings validation
                if ($this->form_validation->run('general_settings') == false) {
                    set_error_notification(validation_errors());
                } else {
                    $this->_store_settings($_POST, $_FILES);
                }
            }
        }


        $this->add_css(["plugins/node-waves/waves.css",
                              "plugins/animate-css/animate.css",
                              "plugins/sweetalert/sweetalert.css",
                              "css/style.css",
                             ]);
        $this->add_js(["plugins/bootstrap-select/js/bootstrap-select.js",
                              "plugins/jquery-slimscroll/jquery.slimscroll.js",
                              'plugins/jquery-validation/jquery.validate.js',
                              "plugins/node-waves/waves.js",
                              "js/admin.js",
                              "js/demo.js",
                              'js/form_validate.js',
                             ]);
                             
        $this->load->model('Settings_model');    
        $this->load->model('Siteconfig');    
        
        $this->data['page'] = 'settings';   
        $this->data['profile'] = $this->data['site_detail'];
        $this->data['smtp'] = $this->Siteconfig->get_all()->result();
        
        $this->__template('admin/settings', $this->data);    

        }


    /**
    * SMTP email settings 
    *
    *
    */ 
    

    public function smtpSettings(){      
        
     /*   $config['protocol'] = "smtp";
        $config['smtp_host'] = "ssl://smtp.gmail.com";
        $config['smtp_port'] = "465";
        $config['smtp_user'] = "mayur.panchal@searchnative.in";
        $config['smtp_pass'] = "Mayur@@123";
        $config['charset'] = "utf-8";
        $config['mailtype'] = "html";
        $config['newline'] = "\r\n";
*/

      $this->load->model('Siteconfig');    
        $this->data['moduleName'] = 'settings';
        if($_POST){          
              $this->Siteconfig->update_config($_POST);
              set_success_notification("SMTP setting updated successfully");
              redirect(base_url().'snackadmin/settings');
        }
      }

        
    


      
    /**
    Dashboard view after login
    */
    public function dashboard(){
       
      $this->data['page'] = "dashboard";

      $this->add_js([
            'plugins/bootstrap-select/js/bootstrap-select.js',
            'plugins/jquery-slimscroll/jquery.slimscroll.js',
            'plugins/node-waves/waves.js',
            'plugins/jquery-countto/jquery.countTo.js',
            'plugins/raphael/raphael.min.js',
            'plugins/morrisjs/morris.js',
            'plugins/flot-charts/jquery.flot.js',
            'plugins/flot-charts/jquery.flot.resize.js',
            'plugins/flot-charts/jquery.flot.pie.js',
            'plugins/flot-charts/jquery.flot.categories.js',
            'plugins/flot-charts/jquery.flot.time.js',
            'plugins/jquery-sparkline/jquery.sparkline.js',            
            'plugins/chartjs/Chart.bundle.js',
            'js/admin.js',
            'js/pages/index.js',
            'js/demo.js',
        ]);
       $this->add_css([
            'plugins/bootstrap/css/bootstrap.css',
            'plugins/node-waves/waves.css',
            'plugins/animate-css/animate.css',
            'plugins/morrisjs/morris.css',
            'css/style.css',
            'css/themes/all-themes.css'
        ]);      
       $this->load->model('Users_reported_model');
       $this->data['weeklyUsers'] = $this->Users_model->getLastWeekUsers();
       $this->data['onlineuser'] = $this->Users_model->onlineUser();
       $this->data['lastweekusers'] = $this->Users_model->thisWeek();
       //$this->data['lastweekdays'] = $this->Users_model->lastweekDays();
       $this->data['yesterdays'] = $this->Users_model->yesterdayUsers();
       $this->data['thisweek'] = $this->Users_model->thiweekUsers();
       $this->data['thismonth'] = $this->Users_model->lastmonthUsers();
       $this->data['thisyear'] = $this->Users_model->thisyearUsers();
       $this->data['allusers'] = $this->Users_model->count_rows();
       
       
       $this->data['subadmin'] = $this->Admin_model->totalAdmin();
       $this->data['subadminList'] = $this->Admin_model->fields('admin_name,admin_email,admin_photo,created_date')->get_all(['admin_type'=>'1','is_deleted'=>'0','admin_status'=>'1']);
       
       

       $this->data['reporteduser']= $this->Users_reported_model->count_rows();

    
       $this->__template('admin/dashboard', $this->data); 
                    
    }


     /**
     * Store settings
     * @param  array $post
     * @param  array $files
     */
    public function _store_settings($post, $files = array())
    {
        $upload_data = array();
        $is_valid_data = true;
        if (count($files)) {
            if ($files['site_logo']['name'] != '') {
                $config = array(
                    'upload_path' => './uploads/admin/logo/',
                    'allowed_types' => 'jpg|gif|png|bmp|jpeg',
                    'max_size' => '2048',
                    'multi' => 'all',
                );
                $this->load->library('upload', $config);
                if (!$this->upload->do_upload('site_logo')) {
                    set_error_notification($this->upload->display_errors());
                    $is_valid_data = false;
                } else {
                    $upload_data = $this->upload->data();
                    $post['site_logo'] = $upload_data['file_name'];
                }
            }
        }
        if ($is_valid_data) {
            $this->Settings_model->save_config($post);
            set_success_notification("Settings is successfully updated.");
        }
        redirect(base_url().'snackadmin/settings');
    }


    public function changepassword(){
        
        if($_POST)
        {
        if ($this->form_validation->run('change_password') == false) {
                            $this->session->set_flashdata("password_error", "1");
                            set_error_notification(validation_errors());
                        } else {
                            //update password
                            $id = $this->input->post('id');
                            $password = $this->_hash($this->input->post('newpass', true));
                            $is_updated = $this->Admin_model->change_password($id, $password);

                            if ($is_updated) {
                                set_success_notification("Passoword is successfully updated.");
                            } else {
                                set_error_notification("Error occurred while updating password.");
                            }

                           
                        }

                    }
                     redirect(base_url('snackadmin/dashboard'), 'refresh');
    }


    public function adminList(){

      $this->data['moduleName'] = "Subadmin";
      $this->data['moduleName2'] = "permission";
      if(!$this->_checkAllPermission("Subadmin") && !$this->_checkAllPermission("permission")){
        redirect(base_url().'snackadmin/dashboard');
      }

      $this->add_js([
            'plugins/bootstrap-select/js/bootstrap-select.js',
            'plugins/jquery-slimscroll/jquery.slimscroll.js',
            'plugins/bootstrap-notify/bootstrap-notify.js',
            'plugins/node-waves/waves.js',
            'plugins/sweetalert/sweetalert.min.js',            
            'js/admin.js',
            'js/pages/ui/dialogs.js',
            'plugins/jquery-datatable/jquery.dataTables.js',            
            'plugins/jquery-datatable/skin/bootstrap/js/dataTables.bootstrap.js',
            'js/pages/tables/jquery-datatable.js',
            'js/demo.js',
        ]);
       $this->add_css([            
            'plugins/node-waves/waves.css',
            'plugins/animate-css/animate.css',
            'plugins/sweetalert/sweetalert.css',
            'plugins/jquery-datatable/skin/bootstrap/css/dataTables.bootstrap.css',
            'css/style.css'

        ]);      

         $this->data['page'] = 'adminList';
         $this->data['adminList'] = $this->Admin_model->ListAdmin(array('is_deleted'=>'0','admin_type'=>'1'));
        $this->__template('admin/adminlist', $this->data);                
    }



    /**
    * manage admin data
    * @param $action is create or edit
    * @param id is optional
    * 
    */
    public function manageadmin($action='',$id=''){
        
        if($_POST){
          
        $is_valid_data = true;
        
                    if ($this->form_validation->run('adminmanageedit_profile') == false) {
                            set_error_notification(validation_errors());

                        } else {
                        if ($_FILES['photo']['name'] != '') {
                                $config = array(
                                    'upload_path' => './uploads/admin',
                                    'allowed_types' => 'jpg|gif|png|bmp|jpeg',
                                    'max_size' => '0',
                                    'multi' => 'all',
                                );
                                $this->load->library('upload', $config);
                                if (!$this->upload->do_upload('photo')) {
                                  
                                    set_error_notification($this->upload->display_errors());
                                    $is_valid_data = false;
                                } else {
                                    $upload_data = $this->upload->data();
                                }
                            }

                            if ($is_valid_data) { 

                                  $status = 0;

                                  if (isset($_POST['admin_status'])) {
                                    $status = "1";

                                  }
                                  // Edit admin details
                                    if($_POST['action']=="Edit Admin"){
                                    
                                        $id = $this->input->post('id',true);
                                         $info = [
                                    'admin_name' => $this->input->post('txtname', true),
                                    'admin_email' => $this->input->post('txtemail', true),
                                    'admin_mobile' => $this->input->post('txtphone', true),
                                    'admin_status' => $status
                                     ];                
                                     $this->Admin_model->update_data($id, $info);
                                 }

                                if ($_FILES['photo']['name'] != '') {
                                  
                                     $this->db->update('admin',[
                                        'admin_photo' => $upload_data['file_name'],
                                    ],['admin_id'=>$id]);
                                }
                               
                                set_success_notification("Data updated successfully");
                                
                          redirect(base_url().'snackadmin/admin/adminList');

                            }
                         
                        }
               
            }
        




        $this->data['page'] = 'dashboard'; 
        
        if($action=="edit" || isset($_POST['action'])=="Edit Admin"){
            
             $this->data['title'] = "Edit Admin";
             $this->data['profile'] = $this->Admin_model->get(array('admin_id'=>$id));
        }

          $this->add_css(["plugins/node-waves/waves.css",
                              "plugins/animate-css/animate.css",
                              "plugins/sweetalert/sweetalert.css",
                              '/plugins/bootstrap-select/css/bootstrap-select.css',
                              "css/style.css",
                             ]);
        $this->add_js(["plugins/bootstrap-select/js/bootstrap-select.js",
                              "plugins/jquery-slimscroll/jquery.slimscroll.js",
                              'plugins/jquery-validation/jquery.validate.js',
                              "plugins/node-waves/waves.js",
                              "js/admin.js",
                              "js/demo.js",
                              'js/form_validate.js',
                             ]);
              

        $this->__template('admin/manageadmin', $this->data);                
    }

    
    function delete($id=''){
        $data['is_deleted'] = '1'; 

        $this->Admin_model->update_data($id,$data);
        
        set_success_notification("Admin Removed successfully");
        redirect(base_url().'snackadmin/adminList');
    }


    function permission($id=''){


      if($this->session->userdata('admin_type')=="1"){
          $allow = $this->Permission_model->checkUserAdmin($id);          
          if(!$allow){
            set_error_notification("You don't have permission to access this module!");
            redirect('adminList');
          }
      }

      $this->data['moduleName'] = "permission";

      if(!$this->_checkAllPermission("permission")){
        redirect(base_url().'snackadmin/dashboard');
      }

      $this->load->model('List/Permission_model');

      $this->data['modulelist'] = $this->modulelist();
       $this->data['user_permission'] = $this->Permission_model->get_all(array(
            'admin_id'   => $id
        ));
        if($_POST){
          $modules = $this->data['modulelist'];
           foreach ($modules as $module) {                
                  $permission = $this->check_permission($module->module_id);     
                  $this->check_and_update_role_permission($_POST['admin_id'], $module->module_id, $permission);
            }

            set_success_notification("Permission set successfully");
            redirect(base_url().'snackadmin/admin/permission/'.$id);

        }

        $this->add_css(["plugins/node-waves/waves.css",
                              "plugins/animate-css/animate.css",
                              "plugins/sweetalert/sweetalert.css",
                              '/plugins/bootstrap-select/css/bootstrap-select.css',
                              "css/style.css",
                             ]);
        $this->add_js(["plugins/bootstrap-select/js/bootstrap-select.js",
                              "plugins/jquery-slimscroll/jquery.slimscroll.js",
                              'plugins/jquery-validation/jquery.validate.js',
                              "plugins/node-waves/waves.js",
                              "js/admin.js",
                              "js/demo.js",
                              'js/form_validate.js',
                              'js/permission-js.js',
                             ]);
        $this->data['page'] = 'adminList';             
        $this->data['title'] = "Permission";       
        
        $this->data['id'] = $id;
        $this->__template('admin/permission', $this->data);                

    }


   function getValue($key) {
    if (!isset($_POST[$key])) {
        return false;
    }
    return $_POST[$key];
    }

    public function check_permission($module_id){
       $permission = [];

        //create permission check
        if($this->getValue("admin_type")=="2"){
          echo "exit why here?";exit;
        }
        if (isset($_POST['create_' . $module_id]) || $this->getValue("admin_type")=="2") {       
        
            $permission['perm_create'] = '1';
        } else {
            $permission['perm_create'] = '0';
        }

        //read permission check
        if (isset($_POST['read_' . $module_id]) || $this->getValue("admin_type")=="2") {
            $permission['perm_read'] = '1';
        } else {
            $permission['perm_read'] = '0';
        }

        //update permission check
        if (isset($_POST['update_' . $module_id]) || $this->getValue("admin_type")=="2") {
            $permission['perm_update'] =  '1';
        } else {
            $permission['perm_update'] = '0';
        }

        //Delete permission check
        if (isset($_POST['delete_' . $module_id]) || $this->getValue("admin_type")=="2") {
            $permission['perm_delete'] = '1';
        } else {
            $permission['perm_delete'] = '0';
        }

        return $permission;
    }


    /**
     * Check and update user role permission
     * @param string $role_id
     * @param string $module_id
     * @param string $permission
     */
    function check_and_update_role_permission($admin_id, $module_id, $permission) {
        $this->load->model('List/Permission_model');

        $user_permission = $this->Permission_model->get(array(
            'admin_id' => $admin_id,
            'module_id' => $module_id
        ));
       
        //update
        if ($user_permission) {
            //update permission
            $where = array(
                'admin_id' => $admin_id,
                'module_id' => $module_id
            );
            
            $data = $permission;
            
            $this->Permission_model->where($where)->update($data);

        } else {

            //insert
          $permission['admin_id'] = $admin_id;
          $permission['module_id'] = $module_id;        
          $this->Permission_model->insert($permission);
        }
    }



    public function create($action='',$id=''){
        $this->data['moduleName'] = "Subadmin";
        if($_POST){

             $is_valid_data = true;
        
                    if ($this->form_validation->run('adminmanage_profile') == false) {
                            set_error_notification(validation_errors());

                        } else {
                           if ($_FILES['photo']['name'] != '') {
                                $config = array(
                                    'upload_path' => './uploads/admin',
                                    'allowed_types' => 'gif|png|bmp|jpeg|jpg',
                                    'max_size' => '0',
                                    'multi' => 'all',
                                );
                                $this->load->library('upload', $config);
                                if (!$this->upload->do_upload('photo')) {
                                  
                                    set_error_notification($this->upload->display_errors());
                                    $is_valid_data = false;
                                } else {
                                    $upload_data = $this->upload->data();
                                }
                            } // image upload


                            if ($is_valid_data) { 

                                $pass = $this->_hash($this->input->post('newpass', true));

                                // create admin details
                                   $status = 0;

                                  if (isset($_POST['admin_status'])) {
                                    $status = "1";

                                  }

                                     $info = [
                                    'admin_name' => $this->input->post('txtname', true),
                                    'admin_email' => $this->input->post('txtemail', true),
                                    'admin_mobile' => $this->input->post('txtphone', true),
                                    'admin_password'=> $pass,
                                    'admin_status' => $status
                                     ];

                                    $id = $this->Admin_model->insert_data($info);
                                    
                                    $this->data['modulelist'] = $this->modulelist();

                                      $modules = $this->data['modulelist'];
                                       foreach ($modules as $module) {                
                                              $permission = $this->check_permission($module->module_id);     
                                              $this->check_and_update_role_permission($id, $module->module_id, $permission);
                                        }

                                    if ($_FILES['photo']['name'] != '') {
                                  
                                     $this->db->update('admin',[
                                        'admin_photo' => $upload_data['file_name'],
                                    ],['admin_id'=>$id]);
                                    }
                                    set_success_notification('Admin added successfully');
                                  redirect(base_url().'snackadmin/adminList');
                                 
                                }



                        }

        }
          
        $this->data['page'] = 'dashboard'; 
        $this->data['title'] = "Create Admin";

        
          $this->add_css(["plugins/node-waves/waves.css",
                              "plugins/animate-css/animate.css",
                              "plugins/sweetalert/sweetalert.css",
                              '/plugins/bootstrap-select/css/bootstrap-select.css',
                              "css/style.css",
                             ]);
        $this->add_js(["plugins/bootstrap-select/js/bootstrap-select.js",
                              "plugins/jquery-slimscroll/jquery.slimscroll.js",
                              'plugins/jquery-validation/jquery.validate.js',
                              "plugins/node-waves/waves.js",
                              "js/admin.js",
                              "js/demo.js",
                              'js/form_validate.js',
                             ]);
              

        $this->__template('admin/createadmin', $this->data); 


    }




}