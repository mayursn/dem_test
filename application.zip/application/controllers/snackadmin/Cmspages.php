<?php
defined('BASEPATH') OR exit('No direct script access allowed ');
class cmspages extends MY_Controller {

    function __construct() {
        parent::__construct(); 
        $this->load->model('Cms_pages_model');
        $this->data['moduleName'] = "CMS";
               
    }


    public function index(){
        
 if(!$this->is_logged_in()){
          redirect(base_url()."snackadmin/login");
        }

        $this->data['page'] = "cmspages";
        $this->data['page_title'] = "CMS pages";
        $this->add_js([
            'plugins/bootstrap-select/js/bootstrap-select.js',
            'plugins/jquery-slimscroll/jquery.slimscroll.js',
            'plugins/bootstrap-notify/bootstrap-notify.js',
            'plugins/node-waves/waves.js',
            'plugins/sweetalert/sweetalert.min.js',            
            'js/admin.js',
            'js/pages/ui/dialogs.js',
            'plugins/jquery-datatable/jquery.dataTables.js',            
            'plugins/jquery-datatable/skin/bootstrap/js/dataTables.bootstrap.js',
            'js/pages/tables/jquery-datatable.js',
            'js/demo.js',
        ]);
       $this->add_css([            
            'plugins/node-waves/waves.css',
            'plugins/animate-css/animate.css',
            'plugins/sweetalert/sweetalert.css',
            'plugins/jquery-datatable/skin/bootstrap/css/dataTables.bootstrap.css',
            'css/style.css'

        ]);      

        $this->data['cmspage'] = $this->Cms_pages_model->get_all();
        $this->__template('cmspages/cmspages',$this->data);        
    }

   public function create(){
 if(!$this->is_logged_in()){
          redirect(base_url()."snackadmin/login");
        }

        if($_POST){
            $is_valid_data = true;
            if ($this->form_validation->run('cmspages/create') == false) {
                            set_error_notification(validation_errors());
                       //     redirect(base_url().'users/create');
            }else{


                    if ($_FILES['cms_img']['name'] != '') {
                                $config = array(
                                    'upload_path' => './uploads/cms',
                                    'allowed_types' => 'jpg|gif|png|bmp|jpeg',
                                    'max_size' => '0',
                                    'multi' => 'all',
                                );
                                $this->load->library('upload', $config);
                                if (!$this->upload->do_upload('cms_img')) {
                                    set_error_notification($this->upload->display_errors());
                                    $is_valid_data = false;
                                } else {
                                    $upload_data = $this->upload->data();
                                }
                            }

                            if ($is_valid_data) {
                              $admin_id = $this->session->userdata('admin_id');
                                $info = 
                                ['cms_title'=>$this->input->post('txtname'),
                                'cms_content'=>$this->input->post('cms_content'),
                                  'cms_status'=>$this->input->post('status'),
                                'cms_date'=>$this->input->post('cms_date'),
                                'admin_id'=>$admin_id];

                                $id =  $this->Cms_pages_model->insert($info);

                                if($id){
                                     $perfile = $upload_data['full_path'];
                                    chmod($perfile ,0777);
                                        $data['cms_img'] = $upload_data['file_name'];
                                    $this->Cms_pages_model->update($data,$id);
                                    set_success_notification("Page created successfully");
                                    redirect(base_url().'snackadmin/cmsPages');
                                }

                            }
            }
            
        }

        $this->cssScript();
        
        $this->data['page'] = "cmspages";
        $this->data['page_title'] = "Create Page";      
         
        $this->__template('cmspages/create', $this->data);                

   }



   public function edit($id=''){
 if(!$this->is_logged_in()){
          redirect(base_url()."snackadmin/login");
        }

        if($_POST){
            $is_valid_data = true;
            if ($this->form_validation->run('cmspages/edit') == false) {
                            set_error_notification(validation_errors());
                       //     redirect(base_url().'users/create');
            }else{


                    if ($_FILES['cms_img']['name'] != '') {
                                $config = array(
                                    'upload_path' => './uploads/cms',
                                    'allowed_types' => 'jpg|gif|png|bmp|jpeg',
                                    'max_size' => '0',
                                    'multi' => 'all',
                                );
                                $this->load->library('upload', $config);
                                if (!$this->upload->do_upload('cms_img')) {
                                    set_error_notification($this->upload->display_errors());
                                    $is_valid_data = false;
                                } else {
                                    $upload_data = $this->upload->data();
                                }
                            }

                            if ($is_valid_data) {
                              $admin_id = $this->session->userdata('admin_id');
                                $info = 
                                  ['cms_title'=>$this->input->post('txtname'),
                                  'cms_content'=>$this->input->post('cms_content'),
                                  'cms_status'=>$this->input->post('status'),
                                  'cms_date'=>$this->input->post('cms_date'),'admin_id'=>$admin_id];

                                $res =  $this->Cms_pages_model->update($info,$id);

                                if($res){
                                    if ($_FILES['cms_img']['name'] != '') {
                                     $perfile = $upload_data['full_path'];
                                    chmod($perfile ,0777);
                                        $data['cms_img'] = $upload_data['file_name'];
                                    $this->Cms_pages_model->update($data,$id);
                                    }
                                    set_success_notification("Page updated successfully");
                                    redirect(base_url().'snackadmin/cmsPages');
                                }

                            }
            }
            
        }

        $this->cssScript();
        
        $this->data['page'] = "cmspages";
        $this->data['page_title'] = "Create Page";      
        $this->data['cms'] = $this->Cms_pages_model->get($id);
       
        $this->__template('cmspages/edit', $this->data);                

   }

   public function delete($id){
     if(!$this->is_logged_in()){
          redirect(base_url()."snackadmin/login");
        }

        $update = array("is_deleted"=>'1');

        //$where = array("cms_id",$id);
        $res = $this->Cms_pages_model->update($update,$id);
        
        if($res){
             set_success_notification("Page deleted successfully");
                    redirect(base_url().'snackadmin/cmsPages');
        }
        else{
              set_error_notification("Error while delete page! Try again");
                 redirect(base_url().'snackadmin/cmsPages');   
        }
   }

    /**/
    public function cssScript(){
        $this->add_css(["plugins/node-waves/waves.css",
                              "plugins/animate-css/animate.css",
                              "plugins/sweetalert/sweetalert.css",
                              'plugins/waitme/waitMe.css',
                              '/plugins/bootstrap-select/css/bootstrap-select.css',
                              'plugins/bootstrap-material-datetimepicker/css/bootstrap-material-datetimepicker.css',
                              "css/style.css",
                             ]);
        $this->add_js(["plugins/bootstrap-select/js/bootstrap-select.js",
                              "plugins/jquery-slimscroll/jquery.slimscroll.js",                              
                              'plugins/momentjs/moment.js',
                              'plugins/bootstrap-material-datetimepicker/js/bootstrap-material-datetimepicker.js',
                              'plugins/jquery-validation/jquery.validate.js',
                              "plugins/node-waves/waves.js",
                              "js/admin.js",
                              "js/demo.js",
                              'js/form_validate.js',
                              'plugins/autosize/autosize.js',
                              'plugins/ckeditor/ckeditor.js',
                              
                              'js/pages/forms/basic-form-elements.js'
                             ]);
    }

    function subscription(){
      $this->db->where('cms_id','5');
      $subscription = $this->db->get('cms_pages')->row();

      echo "<h1 style='text-align:center;'>".$subscription->cms_title."</h1>";      
      echo "<div style='margin:20px;'>".$subscription->cms_content."</div>";
    }
    function privacy_policy(){
      $this->db->where('cms_id','2');
      $privacy_policy = $this->db->get('cms_pages')->row();

      echo "<h1 style='text-align:center;'>".$privacy_policy->cms_title."</h1>";      
      echo "<div style='margin:20px;'>".$privacy_policy->cms_content."</div>";
    }

    function terms_condition(){
      $this->db->where('cms_id','3');
      $privacy_policy = $this->db->get('cms_pages')->row();

      echo "<h1 style='text-align:center;'>".$privacy_policy->cms_title."</h1>";      
      echo "<div style='margin:20px;'>".$privacy_policy->cms_content."</div>"; 
    }




    /**/
}