<?php
defined('BASEPATH') OR exit('No direct script access allowed ');
class Reports extends MY_Controller {

    function __construct() {
        parent::__construct(); 
        $this->load->model('Users_model');

        

        if(!$this->is_logged_in()){
          redirect(base_url()."snackadmin/login");
        }
    }


    public function index(){

        $this->data['moduleName'] = "Reports";
        $this->data['page'] = "reportsList";
        $this->data['page_title'] = "Reports List";
       $this->cssJs();
       $this->data['parentPage'] = "reportsList";
       $this->data['users'] = $this->Users_model->get_all();
       $this->__template('admin/reports/reportsList',$this->data);        
    }

    function cssJs(){
        $this->add_js([
        'plugins/jquery/jquery.min.js',

        'plugins/bootstrap/js/bootstrap.js',            
            'plugins/jquery-slimscroll/jquery.slimscroll.js',
            'plugins/bootstrap-notify/bootstrap-notify.js',
            'plugins/node-waves/waves.js',
            'plugins/sweetalert/sweetalert.min.js',            
            'js/admin.js',
            'js/locationpicker.jquery.min.js',
            'js/pages/ui/dialogs.js',            
            'plugins/momentjs/moment.js',
            'plugins/bootstrap-material-datetimepicker/js/bootstrap-material-datetimepicker.js',
            'plugins/nouislider/nouislider.js',      
            'plugins/jquery-validation/jquery.validate.js',
            'js/reports.js',
            'js/demo.js',
        ]);
       $this->add_css([            
            'plugins/node-waves/waves.css',
            'plugins/animate-css/animate.css',
            'plugins/sweetalert/sweetalert.css',            
            'plugins/bootstrap-material-datetimepicker/css/bootstrap-material-datetimepicker.css',
            'plugins/nouislider/nouislider.min.css',
            'css/style.css'            
        ]);      
    }

   
    function generate(){
        /*echo "<pre>";
        print_r($_POST);
        echo "</pre>";*/


        $type = $_POST['type'];
        $radius = $_POST['radius'];        
        $lat = $_POST['latitude'];
        $long = $_POST['longitude'];
        $age_range = $_POST['age_range'];
        $age_range = explode("To", $age_range);
        $from_age = round($age_range[0]);
        $to_age = round($age_range[1]);        
        $start_date = date('Y-m-d',strtotime($_POST['from_date']));
        $end_date = date('Y-m-d',strtotime($_POST['to_date']));
        $start_date = $start_date." 00:00:00";
        $end_date = $end_date." 23:59:59";

         if ($this->form_validation->run('reports') == false) {
                set_error_notification(validation_errors());
                $this->data['moduleName'] = "Reports";
                $this->data['page'] = "reportsList";
                $this->data['page_title'] = "Reports List";
                $this->cssJs();
                $this->data['parentPage'] = "reportsList";
                $this->data['users'] = $this->Users_model->get_all();
                $this->__template('admin/reports/reportsList',$this->data);  

        } else {


        if($type=="In-app Purchase made"){

                $result = $this->db->query("SELECT users.users_id as ID,users_fname AS FirstName,users_lname as LastName,users.users_age as Age,( 6373000 * acos( cos( radians($lat) ) * cos( radians( users_latitude ) ) * cos( radians( users_longitude ) - radians($long) ) + sin( radians($lat) ) * sin( radians( users_latitude ) ) ) ) AS DistanceINMEETERS,wallet_balance.purchase_amount as Amount,wallet_balance.purchase_credits as Credits,wallet_balance.purchased_date as PurchasedDate FROM users left join wallet_balance ON users.users_id = wallet_balance.users_id WHERE (wallet_balance.purchased_date >= '$start_date'AND wallet_balance.purchased_date <= '$end_date') AND (users_age >= '$from_age' AND users_age <= '$to_age') AND wallet_balance.purchase_id = '1' having DistanceINMEETERS <= $radius")->result_array();
        }else{

                $result = $this->db->query("SELECT users.users_id as ID,users_fname AS FirstName,users_lname as LastName,users.users_age as Age,( 6373000 * acos( cos( radians($lat) ) * cos( radians( users_latitude ) ) * cos( radians( users_longitude ) - radians($long) ) + sin( radians($lat) ) * sin( radians( users_latitude ) ) ) ) AS DistanceINMEETERS,wallet_balance.purchase_amount as Amount,wallet_balance.purchase_credits as Credits,wallet_balance.purchased_date as PurchasedDate FROM users left join wallet_balance ON users.users_id = wallet_balance.users_id WHERE (wallet_balance.purchased_date >= '$start_date'AND wallet_balance.purchased_date <= '$end_date') AND (users_age >= '$from_age' AND users_age <= '$to_age') AND wallet_balance.purchase_id != '1' AND  wallet_balance.purchase_id != '' having DistanceINMEETERS <= $radius")->result_array();
        }
        if(empty($result)){
            $result[0]['ID'] = '';
            $result[0]['FirstName'] = '';
            $result[0]['LastName'] = '';
            $result[0]['Age'] = '';
            $result[0]['Distance'] = '';
            $result[0]['Amount'] = '';
            $result[0]['Credits'] = '';
            $result[0]['PurchasedDate'] = '';
        }
       
         // file name for download
        $type = str_replace(" ", "-",$type);
        $fileName = "Snack_".$type."_report" . date('Ymd') . ".xls";
        
        // headers for download
        header("Content-Disposition: attachment; filename=\"$fileName\"");
        header("Content-Type: application/vnd.ms-excel");
        
        $flag = false;
        foreach($result as $row) {
            if(!$flag) {
                // display column names as first row
                echo implode("\t", array_keys($row)) . "\n";
                $flag = true;
            }
            // filter data
            array_walk($row, array($this, 'filterData'));
            echo implode("\t", array_values($row)) . "\n";

        }
    }


    }

    function filterData(&$str)
    {
        $str = preg_replace("/\t/", "\\t", $str);
        $str = preg_replace("/\r?\n/", "\\n", $str);
        if(strstr($str, '"')) $str = '"' . str_replace('"', '""', $str) . '"';
    }



    /**
    * Check user exists or not
    * @param $id user id
    * @return bool
    */
    public function checkuserId($id)
    {
        $result = $this->Users_model->get(['users_id' => $id]);
        if ($result) {
            return TRUE;
        }
        else {
            return FALSE;
        }
    }

    /**/
}

