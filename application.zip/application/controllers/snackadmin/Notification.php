<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Notification extends MY_Controller {

	/**
	 * Constructor
	 */
	function __construct() {
		parent::__construct();
		$this->load->model('Users_model');
		$this->load->model('User_notification_model');
		
		//$this->load->helper('pushnotification_helper');
		if(!$this->is_logged_in()){
          redirect(base_url()."snackadmin/login");
        }
	}

	/**
	 * Index
	 */
	function index() {
		$this->load->model('Location_model');

		 $this->add_js([
            'plugins/bootstrap-select/js/bootstrap-select.js',
            'plugins/jquery-slimscroll/jquery.slimscroll.js',
            'plugins/bootstrap-notify/bootstrap-notify.js',
            'plugins/node-waves/waves.js',
            'plugins/sweetalert/sweetalert.min.js',            
            'js/admin.js',            
            'js/pages/ui/dialogs.js',
            'plugins/jquery-datatable/jquery.dataTables.js',            
            'plugins/jquery-datatable/skin/bootstrap/js/dataTables.bootstrap.js',
            'js/pages/tables/jquery-datatable.js', 
             'plugins/jquery-validation/jquery.validate.js',   		
             'plugins/jquery-steps/jquery.steps.js',
             'js/pages/forms/form-validation.js',
            'js/demo.js',
            'js/notification.js',
        ]);

       $this->add_css([            
            'plugins/node-waves/waves.css',
            'plugins/animate-css/animate.css',
            'plugins/sweetalert/sweetalert.css',
            'plugins/bootstrap-select/css/bootstrap-select.css',
            'plugins/jquery-datatable/skin/bootstrap/css/dataTables.bootstrap.css',
            'css/style.css'

        ]);  

           	

       	$this->data['moduleName'] = 'notification';       
		$this->data['title'] = "Notification";
		$this->data['page'] = 'notification';		
		$this->__template('admin/notifications', $this->data);
	}



	

	
	/**
	 *  Send notification
	 */
	function sendnotification() {
		if ($_POST) {

			$androidTokens = [];
			$iosTokens = [];
			
			$messages  = $this->input->post('notification');

			if($_POST['send_type']=="All"){
				$users_ids = [];
				$androidTokens = $this->getallTokensAndroid($users_ids);
				

				$iosTokens 	   = $this->getallTokensIos($users_ids);


			}else{
				if($_POST['country']=="All" || $_POST['city']=="All"){

				$country = $_POST['country'];

				$androidTokens = $this->getCountryWiseAndroid($country);

				$iosTokens 	   = $this->getCountryWiseIos($country);				

				
				}else{

					$country = $_POST['country'];

					$city = $_POST['city'];

					$user_type = $this->input->post('user_type');

					if($user_type=="All"){

					$androidTokens = $this->getCityWiseAndroid($country,$city);

					$iosTokens 	   = $this->getCityWiseIos($country,$city);

					}else{

					$users_ids = $this->input->post('users');

					if(!empty($users_ids)){

						$androidTokens = $this->getallTokensAndroid($users_ids);
						
						$iosTokens 	   = $this->getallTokensIos($users_ids);	

					}

					}

				}
			}
			

			


			  
			$title = "";
			//	$token = $this->db
			$currenttime = date("Y-m-d H:i:s");

			$message = array();

			
			if(count($androidTokens) > 0){
				
				$rowsofvalue = [];
				foreach ($androidTokens as $rows) {
					$rowsofvalue[] = $rows->device_token;
				}

				
				
					$this->User_notification_model->insert(['users_id'=>$rows->users_id]);

					$count = $this->User_notification_model->fields('notification_id')->get_all(['users_id'=>$rows->users_id]);
					$badge = count($count);
					$msg['body'] = array('message' 	=> $messages ,'badge' => $badge);
				$this->sendPushNotificationAndroid($rowsofvalue, $msg, $title);
			}

			
			if(count($iosTokens) > 0){
				foreach ($iosTokens as $rows) {		
				
					$messagebody = json_decode($messagebody);
					$this->User_notification_model->insert(['users_id'=>$rows->users_id]);

					$count = $this->User_notification_model->fields('notification_id')->get_all(['users_id'=>$rows->users_id]);
					$badge = count($count);
					$this->sendPushNotificationIos($rows->device_token, $messages, $title,$badge);			
				}	
				
			}		
			
			set_success_notification("Notification sent successfully");
			redirect(base_url() . 'snackadmin/notification/');

		}
	}

	

	function getCityWiseAndroid($country,$city){
		
				$this->db->where(['users_status'=>'1',"device_token !="=>"",'device_type'=>'android','country'=>$country,'users_location'=>$city]);					
		return 	$android_users = $this->Users_model->fields('users_id,device_token')
										->get_all();
	}

	function getCityWiseIos($country,$city){
		
				$this->db->where(['users_status'=>'1',"device_token !="=>"",'device_type'=>'IOS','country'=>$country,'users_location'=>$city]);					
		return 	$android_users = $this->Users_model->fields('users_id,device_token')
										->get_all();
	}


	function getCountryWiseAndroid($country){
		
				$this->db->where(['users_status'=>'1',"device_token !="=>"",'device_type'=>'android','country'=>$country]);					
		return 	$android_users = $this->Users_model->fields('users_id,device_token')
										->get_all();
	}

	function getCountryWiseIos($country){
		
				$this->db->where(['users_status'=>'1',"device_token !="=>"",'device_type'=>'IOS','country'=>$country]);					
		return 	$android_users = $this->Users_model->fields('users_id,device_token')
										->get_all();
	}



	/**
	 * Push notifcation send code in iphone
	 *
	 * @param      string  $token  The token
	 *
	 * @return     string  ( json )
	 */
	function sendPushNotificationIos($token, $message = NULL, $title = NULL,$badge=1) {
		//$ci = &get_instance(); // CI instance
		$passphrase = '';
		$messagealert = '';
		if (empty($message)) {
			$messagealert = "Notification.";
		} else {
			$messagealert = $message;
		}
		$ctx = stream_context_create();

		//echo FCPATH . 'zatuna_dev.pem';exit;
		
		stream_context_set_option($ctx, 'ssl', 'local_cert', 'apns.pem');
		stream_context_set_option($ctx, 'ssl', 'passphrase', $passphrase);

		// LIVE :- gateway.push.apple.com:2195
		// Staging :- gateway.sandbox.push.apple.com:2195

		$fp = stream_socket_client(
			'ssl://gateway.sandbox.push.apple.com:2195', $error, $errstr, 30, STREAM_CLIENT_CONNECT | STREAM_CLIENT_PERSISTENT, $ctx);
		if (!$fp) {
			exit("Failed to connect: $err $errstr" . PHP_EOL);
		}
		//$body['body'] =
		$body['aps'] = array(
			'alert' => array(
				'title' => $title,
				'body' => $messagealert,
			),
			'sound' => 'default',
		    'badge'=>($badge != (null) ? $badge + 1 : 1)
		);
		//$body['image'] = base_url() . 'uploads/notifications' . $messages[0]->media;
		$payload = json_encode($body);
		$msg = chr(0) . pack('n', 32) . pack('H*', $token) . pack('n', strlen($payload)) . $payload;
		$result = fwrite($fp, $msg, strlen($msg));
		

		if (!$result) {
			return 0;
		} else {
			return 1;
		}
		fclose($fp);
	}


	/**
	 * Push notifcation send code in iphone
	 *
	 * @param      string  $token  The token
	 *
	 * @return     string  ( json )
	 */
	function sendPushNotificationAndroid($registration_ids, $message = NULL, $title = NULL)
	{


		$fields = array(
			'registration_ids' => $registration_ids,
			'data'=> $message,
			);

			$headers = array(
			'Authorization: key='.FIREBASE_API_KEY, // FIREBASE_API_KEY_FOR_ANDROID_NOTIFICATION
			'Content-Type: application/json'
			);
			// Open connection
			$ch = curl_init();
			// Set the url, number of POST vars, POST data
			curl_setopt( $ch,CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send' );
			curl_setopt( $ch,CURLOPT_POST, true );
			curl_setopt( $ch,CURLOPT_HTTPHEADER, $headers );
			curl_setopt( $ch,CURLOPT_RETURNTRANSFER, true );
			// Disabling SSL Certificate support temporarly
			curl_setopt( $ch,CURLOPT_SSL_VERIFYPEER, false );
			curl_setopt( $ch,CURLOPT_POSTFIELDS, json_encode( $fields ) );
			// Execute post
			$result = curl_exec($ch );
			if($result === false){
			die('Curl failed:' .curl_errno($ch));
			}
			// Close connection
			curl_close( $ch );
			return $result;


		
	}



	

	/**
	 * Get list of tokens
	 */
	function getallTokensAndroid($users=[]) {

				if(!empty($users)){
					$users = implode(",", $users);
					$this->db->where("users_id IN ($users)");
				}

				$this->db->where(['users_status'=>'1',"device_token !="=>"",'device_type'=>'android']);	
				
		return 	$android_users = $this->Users_model->fields('users_id,device_token')
										->get_all();
		

		
		//return $this->db->get('devicetokens');

	}
	function getallTokensIos($users=[]) {

				if(!empty($users)){
					$users = implode(",", $users);
					$this->db->where("users_id IN ($users)");
				}
					
				$this->db->where(['users_status'=>'1',"device_token !="=>"",'device_type'=>'IOS']);
				
		return 	$ios_users = $this->Users_model->fields('users_id,device_token')
										->get_all();
	}
	
	

	/*Difference between time*/
	function dateDiff($start, $end) {
		$start_ts = strtotime($start);
		$end_ts = strtotime($end);
		$diff = $end_ts - $start_ts;
		return round($diff / 86400);
	}
	/**
	 *  Check current date is less than previous date
	 */
	function checkDate($inputdate, $existdate) {
		$idate = strtotime($inputdate);
		$exdate = strtotime($existdate);

		//echo $idate . '==' . $exdate;exit;

		if ($exdate < $idate) {
			return 1;
		} else {
			return 0;
		}
	}


	public function sample(){
	//	$this->load->model('Users_model');
		$this->db->select('device_type,device_token');
		 $this->db->where(['users_status'=>'1',"is_signout"=>'0',"device_token !="=>"","users_id"=>'65']);
		 $user = $this->db->get('users')->row();
		
        /*            $user = $this->Users_model->fields('device_type,device_token')->get(['users_status'=>'1',"is_signout"=>'0',"device_token !="=>"","users_id"=>'67']);*/
                    var_dump($user);
                    $device_token = $user->device_token;
                    $device_type = $user->device_type;                    
                    $text = "Someone message you";
                    $text = json_encode($text);
                    //$text = json_decode($text);
                    $title = "";
		  sendPushNotificationIos($device_token, $text, $title);
		  
		$message = "This is testing";
		$message = json_encode($message);
		$title = "";
		$token = 'EBBA1349C82884F421F58A226C82143DEB8750927CE3067C829CE530C689832B';
		$passphrase = '';
		$messagealert = '';
		if (empty($message)) {
			$messagealert = "Notification.";
		} else {
			$messagealert = $message;
		}
		$ctx = stream_context_create();

		//echo FCPATH . 'zatuna_dev.pem';exit;
		
		stream_context_set_option($ctx, 'ssl', 'local_cert', 'apns.pem');
		stream_context_set_option($ctx, 'ssl', 'passphrase', $passphrase);

		// LIVE :- gateway.push.apple.com:2195
		// Staging :- gateway.sandbox.push.apple.com:2195

		$fp = stream_socket_client(
			'ssl://gateway.sandbox.push.apple.com:2195', $error, $errstr, 30, STREAM_CLIENT_CONNECT | STREAM_CLIENT_PERSISTENT, $ctx);
		if (!$fp) {
			exit("Failed to connect: $err $errstr" . PHP_EOL);
		}
		//$body['body'] =
		$body['aps'] = array(
			'alert' => array(
				'title' => $title,
				'body' => $messagealert,
			),
			'sound' => 'default',
		);
		//$body['image'] = base_url() . 'uploads/notifications' . $messages[0]->media;
		$payload = json_encode($body);
		$msg = chr(0) . pack('n', 32) . pack('H*', $token) . pack('n', strlen($payload)) . $payload;
		$result = fwrite($fp, $msg, strlen($msg));

		
		fclose($fp);
		var_dump($msg);
		
	}

	function getCountries(){
		$this->load->model('Location_model');
		$country = $this->Location_model->fields('location_id,name')->where(['location_type'=>'0'])->get_all();   
		if(!empty($country)){
			echo json_encode($country);
		}else{
			echo "";
		}
	}

	function getCity(){
		$country = $_POST['country'];
		if($country!=""){
			$this->db->where('users_location!=',"");			
			$users = $this->Users_model->fields('users_location')->get_all();
			$location = [];
			if(!empty($users)){
				foreach ($users as $rows) {
					$location[] = $rows->users_location;
				}
			}

			$this->load->model('Location_model');
			if(!empty($location)){
				$this->db->where_in('location_id',$location);
			}
			$this->db->distinct('name');
			$this->db->order_by('name','asc');			
			$cities = $this->Location_model->fields('location_id,name')->where(['parent_id'=>$country,'location_type'=>'2'])->get_all();


			echo json_encode($cities);
		}else{
			echo "";
		}
	}

	public function getusers(){
		 $city = $_POST['cities'];
		 $country = $_POST['country'];
		
		$this->load->model('Users_model');

		$users = $this->Users_model->fields('users_id,users_fname,users_lname')->where(['users_location'=>$city,'country'=>$country])->get_all();

		if(!empty($users)){
			echo json_encode($users);
		}else{
			echo "";
		}
	}

}
