<?php
defined('BASEPATH') OR exit('No direct script access allowed ');
class Credits extends MY_Controller {

    function __construct() {
        parent::__construct();         
        $this->load->model('Credits_info_model');
        $this->data['moduleName'] = "credits";
        if(!$this->is_logged_in()){
          redirect(base_url()."snackadmin/login");
        }
        
    }

    #listing function
    public function index(){
        

        $this->data['page'] = "credits";
        $this->data['page_title'] = "Purchasing Additional Credits";
        $this->add_js([
            'plugins/bootstrap-select/js/bootstrap-select.js',
            'plugins/jquery-slimscroll/jquery.slimscroll.js',
            'plugins/bootstrap-notify/bootstrap-notify.js',
            'plugins/node-waves/waves.js',
            'plugins/sweetalert/sweetalert.min.js',            
            'js/admin.js',
            'js/pages/ui/dialogs.js',
            'plugins/jquery-datatable/jquery.dataTables.js',            
            'plugins/jquery-datatable/skin/bootstrap/js/dataTables.bootstrap.js',
            'js/pages/tables/jquery-datatable.js',
            'js/demo.js',
        ]);
        $this->add_css([            
            'plugins/node-waves/waves.css',
            'plugins/animate-css/animate.css',
            'plugins/sweetalert/sweetalert.css',
            'plugins/jquery-datatable/skin/bootstrap/css/dataTables.bootstrap.css',
            'css/style.css'

        ]);      

        $this->data['credits'] = $this->Credits_info_model->get_all();
        
        $this->__template('credits/index',$this->data);        
    }

    #insert function for credits
   public function create(){
       if($_POST){
        $status = 0;       
        if(isset($_POST['status'])){
            $status = 1;
        }
        $id = $this->Credits_info_model->insert([
                                                    'credits'=>$_POST['credits'],
                                                    'amount'=>$_POST['amount'],
                                                    'status'=>$status,
                                                    'currency'=>'Ksh'
                                                ]);   

    
      
      

      set_success_notification("Information added successfully");
                                    redirect(base_url().'snackadmin/credits');
       }
        $this->cssScript();
        $this->data['page'] = "credits";
        $this->data['page_title'] = "Create Credits info";      
        $this->__template('credits/create', $this->data);                

   }

   #edit credits functionality
  
   public function edit($id=''){

       

        $this->cssScript();
        
        $this->data['page'] = "credits";
        $this->data['page_title'] = "Edit Credits Info";      
        $this->data['credits'] = $this->Credits_info_model->fields('id,amount,credits,status')->get(['id'=>$id]);        
       
        $this->__template('credits/edit', $this->data);                

   }

   #update credits information
   public function update($id=''){
        if($_POST){

            $status = 0;       

            if(isset($_POST['status'])){
                $status = 1;
            }
            $this->Credits_info_model->update([
                                                    'credits'=>$_POST['credits'],
                                                    'amount'=>$_POST['amount'],
                                                    'status'=>$status,
                                                    'currency'=>'Ksh'
                                                ],$id);   
            
            set_success_notification("Information updated successfully");
        }

        
                 redirect(base_url().'snackadmin/credits');

    }
   public function delete($id){
        $update = array("status"=>'2');
        $result = $this->Credits_info_model->get($id);
        $res = $this->Credits_info_model->update($update,$id);

        if($res){

            set_success_notification("Credits info deleted successfully");

        } 
        else{

            set_error_notification("Error while delete! Try again.");

        }

        redirect(base_url().'snackadmin/credits');
   }





    /**
    * Css And Js script added as per required
    *
    */
    public function cssScript(){
        $this->add_css(["plugins/node-waves/waves.css",
                              "plugins/animate-css/animate.css",
                              "plugins/sweetalert/sweetalert.css",
                               'plugins/jquery-datatable/skin/bootstrap/css/dataTables.bootstrap.css',
                              "css/style.css",
                             ]);
        $this->add_js(['plugins/bootstrap-select/js/bootstrap-select.js',
                      'plugins/jquery-slimscroll/jquery.slimscroll.js',
                      'plugins/bootstrap-notify/bootstrap-notify.js',
                      'plugins/jquery-validation/jquery.validate.js',
                      'plugins/node-waves/waves.js',
                      'plugins/sweetalert/sweetalert.min.js',            
                      'js/admin.js',
                      'js/pages/ui/dialogs.js',
                      'plugins/jquery-datatable/jquery.dataTables.js',
                      'plugins/jquery-datatable/skin/bootstrap/js/dataTables.bootstrap.js',
                      'js/pages/tables/jquery-datatable.js',
                      'js/demo.js',
                      'js/form_validate.js']);

    }


    


    /**/
}