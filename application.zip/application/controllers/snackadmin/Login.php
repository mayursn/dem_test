<?php
defined('BASEPATH') OR exit('No direct script access allowed ');
class Login extends MY_Controller {

    function __construct() {
        parent::__construct(); 
        $this->load->model('Admin_model');
        
        
    }


     /**
      * This function is redirect to Login Page
      * @return Void
      */
    public function index() {
        if ($this->is_logged_in()) {
            redirect(base_url().'snackadmin/dashboard');
        }
      $this->process_login();
    }

    /* Login Process*/
    public function process_login(){
        if ($this->is_logged_in()) {
            redirect(base_url().'snackadmin/dashboard');
        }

        
        if ($_POST) {
            
            //validation
            if ($this->form_validation->run('user_login') == false) {
                set_error_notification(validation_errors());
            } else {
                $email = $this->input->post('txtemail', true);
                $password = $this->_hash($this->input->post('txtpassword', true));

                $user = $this->Admin_model->get(['admin_email'=>$email,'admin_password'=>$password]);
                

                if ($user) {
                    //check for status
                    
                    if ($user->admin_status=='0') {
                        //temporary inactive
                        set_error_notification($_POST['txtemail'] . " email is temporary deactived by the Admin.");
                        redirect(base_url('snackadmin/login'), 'refresh');
                    }
                    if ($user->is_deleted == 1) {
                        //temporary inactive
                        set_error_notification($_POST['txtemail'] . " email is temporary suspended by the Admin.");
                        redirect(base_url('snackadmin/login'), 'refresh');
                    }
                   
                        // store data in session
                        $this->session->set_userdata([
                            'admin_id' => $user->admin_id,
                            'email' => $user->admin_email,
                            'name' => $user->admin_name,                            
                            'is_logged_in' => true,
                            'photo' => $user->admin_photo,
                            'admin_type'=>$user->admin_type
                        ]);
                        // check for user type                       

                            redirect(base_url('snackadmin/dashboard'), 'refresh');
                        
                    
                } else {
                    // Invalid username or password
                    set_error_notification('Invalid username or password.');
                    redirect(base_url('snackadmin/login'), 'refresh');
                }
            }
        }
        $this->data['page'] = "Login";
        $this->load->view('login', $this->data);
        


        /*$data[] = '';

        $this->load->view('login', $data);                
*/


    }


    public function forgot_password(){
         $this->data['title'] = 'Reset Password';
        if ($_POST) {
            //validation
            if ($this->form_validation->run('forgot_password') == false) {
                set_error_notification(validation_errors());
            } else {
                //load password reset model
                $this->load->model('Admin_model');

                //get the user detail by entered email address
                $email = $this->input->post('txtemail', true);

                $user = $this->Admin_model->get_by_email($email);

                //check user is found
                if ($user) {
                    //check for status
                    if ($user->admin_status == 0) {
                        //email or username is temporary deactivated
                        set_error_notification('<i>' . $_POST["txtemail"] . '</i> email address is temporary deactived by the Admin.');
                        redirect(base_url("snackadmin/login/forgot_password"), 'refresh');
                    }
                    //check for soft delete
                    if ($user->is_deleted == 1) {
                        //email or username is temporary suspended
                        set_error_notification('<i>' . $_POST["txtemail"] . '</i> email address is temporary suspended by the Admin.');
                        redirect(base_url("snackadmin/login/forgot_password"), 'refresh');
                    } else {
                        //generate token for reset password
                        $this->load->helper('string');

                        $token = random_string('alnum', 32);
                        $this->Admin_model->update_token($user->admin_email,$token);
                        //send email to entered email address
                        $this->data['name'] = $user->admin_name;
                        $this->data['reset_password_url'] = base_url("snackadmin/login/reset-password/" . $token);
                        $message = $this->load->view('reset_password_email_template', $this->data, true);

                        $config = emailconfig();
                        $this->load->library('email',$config);       
                        $this->email->set_newline("\r\n");
                 
                        $this->email->from('no-reply@snackdating.com', websitedata('site_name'));
                        $this->email->to($user->admin_email);
                        $this->email->subject('Reset Password');
                        $this->email->message($message);

                        try {
                            if ($this->email->send()) {

                                set_success_notification('Please check your mail box to reset your password.');
                            }
                            else{
                                set_error_notification('Error while send mail! Please try again or try after sometime');
                                redirect('login', 'refresh');
                            }

                        } catch (Exception $e) {
                            set_error_notification('Error while send mail! Please try again or try after sometime');

                            
                        }
                        
                        redirect(base_url("snackadmin/login"), 'refresh');
                    }
                } else {
                    //email is not registered with the system
                    set_error_notification('<i>' . $_POST["txtemail"] . '</i> username or email address is not registered with the system.');
                }
                redirect(base_url("snackadmin/login/forgot_password"), 'refresh');
            }
        }
        
        
        $this->data['page'] = "Forgot Password";
        $this->load->view('forgot_password', $this->data);
        clear_notification();
    }


    /**
     * Reset user password based on requested
     * @param  string $token
     */
    public function reset_password($token = '')
    {
        $this->load->model('Admin_model');
        if ($_POST) {
            //validation
            if ($this->form_validation->run('password_reset') == false) {
                set_error_notification(validation_errors());
            } else {
                if ($token === $this->input->post('_token', true)) {
                    //get and compare password
                    $new_password = $this->input->post('txtpassword', true);
                    $confirm_password = $this->input->post('txtconfirmpassword', true);

                    if ($new_password === $confirm_password) {
                        $password_reset = $this->Admin_model->get([
                            'password_token' => $this->input->post('_token', true),
                        ]);

                        //update new password
                        $this->db->where('admin_email', $password_reset->admin_email);
                        $user = $this->db->update('admin', [
                            'admin_password' => $this->_hash($new_password),
                            'password_token' => ''
                        ]);

                        if ($user) {
                            //disable token
                           

                            set_success_notification('Your password has been reset successfully!');
                            redirect(base_url("snackadmin/login"), 'refresh');
                        } else {
                            set_error_notification('Server error! Please try again later.');
                            redirect(base_url("snackadmin/login/reset-password/" . $token), 'refresh');
                        }
                    } else {
                        set_error_notification('A password mismatch has been detected.');
                        redirect(base_url("snackadmin/login/reset-password/" . $token), 'refresh');
                    }
                }
            }
        }
        if ($token) {
            $reset_request = $this->Admin_model->get([
                'password_token' => $token,
            ]);

            if ($reset_request) {
                $this->data['token'] = $token;
                $this->data['title'] = 'Reset Password';
                $this->load->view('reset_password', $this->data);
            } else {
                show_404();
            }
        } else {
            show_404();
        }
    }


    /**
     * Logout from user account
     */
    public function Logout()
    {
        $this->session->sess_destroy();
        redirect(base_url('snackadmin/login'), 'refresh');
    }


    


}