<?php
defined('BASEPATH') OR exit('No direct script access allowed ');
class Users extends MY_Controller {

    function __construct() {
        parent::__construct(); 
        $this->load->model('Users_model');
        if(!$this->is_logged_in()){
          redirect(base_url()."snackadmin/login");
        }
    }


    public function index(){

        $this->data['moduleName'] = "users";
        $this->data['page'] = "usersList";
        $this->data['page_title'] = "Users List";
       $this->add_js([
            'plugins/bootstrap-select/js/bootstrap-select.js',
            'plugins/jquery-slimscroll/jquery.slimscroll.js',
            'plugins/bootstrap-notify/bootstrap-notify.js',
            'plugins/node-waves/waves.js',
            'plugins/sweetalert/sweetalert.min.js',            
            'js/admin.js',
            'js/pages/ui/dialogs.js',
            'plugins/jquery-datatable/jquery.dataTables.js',            
            'plugins/jquery-datatable/skin/bootstrap/js/dataTables.bootstrap.js',
            'js/pages/tables/jquery-datatable.js',
            'js/demo.js',
        ]);
       $this->add_css([            
            'plugins/node-waves/waves.css',
            'plugins/animate-css/animate.css',
            'plugins/sweetalert/sweetalert.css',
            'plugins/jquery-datatable/skin/bootstrap/css/dataTables.bootstrap.css',
            'css/style.css'

        ]);      
       $this->data['parentPage'] = "usersLists";
       $this->data['users'] = $this->Users_model->get_all();
       $this->__template('users/usersList',$this->data);        
    }

   public function create(){

        if($_POST){
            $upload_data = array();
             $is_valid_data = true;
            if ($this->form_validation->run('Create') == false) {
                            set_error_notification(validation_errors());
                       //     redirect(base_url().'snackadmin/users/create');
            }else{

                   if ($_FILES['photo']['name'] != '') {
                                $config = array(
                                    'upload_path' => './uploads/users',
                                    'allowed_types' => 'jpg|gif|png|bmp|jpeg',
                                    'max_size' => '2048',
                                    'multi' => 'all',
                                );
                                $this->load->library('upload', $config);
                                if (!$this->upload->do_upload('photo')) {
                                    set_error_notification($this->upload->display_errors());
                                    $is_valid_data = false;
                                } else {
                                    $upload_data = $this->upload->data();
                                }
                            }

                            if ($is_valid_data) {

                                $status = 0;
                                if(isset($_POST['user_status']))
                                {
                                    $status = 1;
                                }

                                 $password = $this->_hash($this->input->post('newpass', true));

                                $id = $this->Users_model->insert(
                                                    array('users_name' =>  $this->input->post('txtname', true), 
                                                        'users_fname'=> $this->input->post('firstname', true),
                                                        'users_lname'=> $this->input->post('lastname', true),
                                                        'users_mobile'=> $this->input->post('txtphone', true),
                                                        'users_email'=> $this->input->post('txtemail', true),
                                                        'users_password'=> $password,
                                                        'users_status'=> $status,                                                        
                                                        'users_address'=> $this->input->post('users_address', true),
                                                        'users_zip'=> $this->input->post('users_zip', true),
                                                        'users_latitude'=> $this->input->post('users_latitude', true),
                                                        'users_longitude'=> $this->input->post('users_longitude', true),
                                                        'users_dob'=> $this->input->post('users_dob', true)
                                                        )
                                                    );

                                if ($_FILES['photo']['name'] != '') {
                                    $file  = $upload_data['file_name'];
                                    $this->Users_model->update(array(
                                        'users_image' => $file), array('users_id'=> $id)); 
                                
                                }

                                if ($id) {
                                set_success_notification("User created successfully");

                                redirect(base_url('users'), 'refresh');
                            } else {
                                set_error_notification("Error occurred while creating user.");
                            }

                            redirect(base_url().'snackadmin/users', 'refresh');

                            }


            }
        }

        $this->cssScript();
        
        $this->data['page'] = "usersList";
        $this->data['page_title'] = "Create User";      
        $this->data['parentPage'] = "usersLists"; 
        $this->__template('users/create', $this->data);                

   }


   /**
   * Get Users List by ajax
   * @return json array
   */
    public function ajax_list(){
        $this->load->model('List/Getallusers_model');
               
        $list = $this->Getallusers_model->get_datatables();
    
        $data = array();
      
        foreach ($list as $users) {
            //$no++;

              $users_id = $users->users_id;
            $user = $this->Users_model->fields('premium_status,freetrial_start_date,freetrial_end_date,premium_trial_used,weekly_credits,total_credits')->where(['users_id'=>$users_id])->get();
        

        $premium_status = $user->premium_status;    
            if($premium_status=='1'){
            $freetrial_start_date = date('Y-m-d',strtotime($user->freetrial_start_date));        
            $freetrial_end_date = date('Y-m-d',strtotime($user->freetrial_end_date));        
            $date = date('Y-m-d');
            $is_trial = '0';
                if (($date >= $freetrial_start_date) && ($date <= $freetrial_end_date)){
                    $is_trial = '1';
                }
            }else{
                $is_trial = '0';
            }

            if($user->premium_trial_used==""){
                $is_trial_used = "0";
            }else{
                $is_trial_used = $user->premium_trial_used;
            }

            $credits = ($user->total_credits + $user->weekly_credits);   
            if($is_trial=='1' && $premium_status=="1"){
                $membership = "Free Trial";
            }elseif($is_trial=='0' && $premium_status=="1"){
                $membership = "Premium";
            }else{
                $membership = "Free";
            }


            //($users->users_status=='0') ?  : "";
            if($users->users_status=='0'){
                $class = "label-warning";
                $titlename = "Inactive";
            }
            if($users->users_status=='1'){
                $class = "label-success";
                $titlename = "Active";
            }
            if($users->users_status=='2'){
                $class = "label-danger";
                $titlename = "Blocked";
            }
            $status = "<span class='label $class'>$titlename</span>";

            /*$user_status = ($users->users_status=='1') ? '<span class="label label-success">Active</span>' : "";
            $user_status = ($users->users_status=='2') ? '<span class="label label-danger">Blocked</span>' : "";*/

            $row = array();            
           
            $row[] = substr($users->users_fname.' '.$users->users_lname,0,19);            
            $row[] = $users->users_email;
            $row[] = $membership;
            $row[] = $credits;  
            $row[] = $users->created_date;
            $row[] = $status;
            

            $userView = base_url()."snackadmin/users/views/".$users->users_id;
              $activityview = base_url()."snackadmin/users/activityview/".$users->users_id;
          
           
            $row[] = '<a href="'.$userView.'" class="btn btn-primary waves-effect">View Details</a>  <a href="'.$activityview.'" class="btn btn-primary waves-effect">View Activity</a>';

           

            $data[] = $row;
        }

        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->Getallusers_model->count_all(),
            "recordsFiltered" => $this->Getallusers_model->count_filtered(),
            "data" => $data,
        );
        //output to json format
        echo json_encode($output);
    }


    /**/
    public function cssScript(){
        $this->add_css(["plugins/node-waves/waves.css",
                              "plugins/animate-css/animate.css",
                              "plugins/sweetalert/sweetalert.css",
                              'plugins/waitme/waitMe.css',
                              '/plugins/bootstrap-select/css/bootstrap-select.css',
                              'plugins/bootstrap-material-datetimepicker/css/bootstrap-material-datetimepicker.css',
                              "css/style.css",
                             ]);
        $this->add_js(["plugins/bootstrap-select/js/bootstrap-select.js",
                              "plugins/jquery-slimscroll/jquery.slimscroll.js",                              
                              'plugins/momentjs/moment.js',
                              'plugins/bootstrap-material-datetimepicker/js/bootstrap-material-datetimepicker.js',
                              'plugins/jquery-validation/jquery.validate.js',
                              "plugins/node-waves/waves.js",
                              "js/admin.js",
                              "js/demo.js",
                              'js/form_validate.js',
                              'plugins/autosize/autosize.js',
                              'js/pages/forms/basic-form-elements.js'
                             ]);
    }


    function listCssJs(){
         $this->add_js([
            'plugins/bootstrap-select/js/bootstrap-select.js',
            'plugins/jquery-slimscroll/jquery.slimscroll.js',
            'plugins/bootstrap-notify/bootstrap-notify.js',
            'plugins/node-waves/waves.js',
            'plugins/sweetalert/sweetalert.min.js',            
            'js/admin.js',
            'js/pages/ui/dialogs.js',
            'plugins/jquery-datatable/jquery.dataTables.js',            
            'plugins/jquery-datatable/skin/bootstrap/js/dataTables.bootstrap.js',
            'js/pages/tables/jquery-datatable.js',
            'js/demo.js',
        ]);
       $this->add_css([            
            'plugins/node-waves/waves.css',
            'plugins/animate-css/animate.css',
            'plugins/sweetalert/sweetalert.css',
            'plugins/jquery-datatable/skin/bootstrap/css/dataTables.bootstrap.css',
            'css/style.css'

        ]); 
    }


    function check(){
        
        echo $permission = check_methods_modules("settings","perm_update");
        echo checkAllPermission("settings");


    }


    public function reported(){
          $this->listCssJs();
        $this->data['moduleName'] = "users";
        $this->data['parentPage'] = "usersLists";
        $this->data['page'] = "usersReported";
        $this->data['page_title'] = "Reported User";         
        $this->__template('users/reported',$this->data);    
    }


    public function views($id=''){
        $this->load->model('User_images_model');

        
        if(!$this->checkuserId($id))
        {
            redirect();
        }
        

        $this->listCssJs();
        $this->data['bgcolor'] = "bg-white";
        $user = $this->Users_model->getusersDetails($id);
        $details = $this->Users_model->get_Preference($id);
        /*echo "<prE>";
        print_r($details);
        exit;*/
        $this->data['parentPage'] = "usersLists";
        $this->data['moduleName'] = "users";
        $this->data['page'] = "usersList";
        $this->data['page_title'] = "User Details";
        $this->data['user'] = $user;
        $this->data['images'] = $this->User_images_model->fields('user_img')->get_all(['users_id'=>$id]);
        $this->data['preferences'] = $details;
        $this->__template('users/user_details',$this->data);   
    }

    


    function activity(){

        $this->listCssJs();
        $this->data['parentPage'] = "usersLists";
        $this->data['moduleName'] = "users";
        $this->data['page'] = "Logs";
        $this->data['page_title'] = "User Activity";         
        $this->__template('users/activity_list',$this->data);    
    }



    /**
    * User Activity List 
    * @param    
    * @return json array
    */

    function activity_ajax_list(){
        $this->load->model('Logs_model');
        $list = $this->Logs_model->get_datatables();
    
        $data = array();
      
        foreach ($list as $users) {
            //$no++;
            
            $row = array();            
            $serial = '';
           $serialize = unserialize($users->params);
                foreach ($serialize as $key => $value){
                            $serial .='<p>'.$key .' : ' .$value."</p>";
                };
            
            $row[] = base_url().$users->uri;            
            $row[] = $users->message;
            $row[] = $serial;            
            $row[] = $users->ip_address;
            $row[] = $users->created_date;

            $userView = base_url()."snackadmin/users/activityview/".$users->id;
          
           /* $row[] = '<a href="'.$userView.'" class="btn btn-primary waves-effect">View Details</a>';*/

            $data[] = $row;
        }

        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->Logs_model->count_all(),
            "recordsFiltered" => $this->Logs_model->count_filtered(),
            "data" => $data,
        );
        //output to json format
        echo json_encode($output);

    }

    /**
    * Reported user List 
    * @param    
    * @return json array
    */
    public function reported_ajax_list(){
          $this->load->model('Users_reported_model');
        $list = $this->Users_reported_model->get_datatables();
    
        $data = array();
      
        foreach ($list as $users) {
            //$no++;
            
            $row = array();            
            
            $row[] = $users->uname;            
            $row[] = $users->runame;
            $row[] = $users->created_date;

            $data[] = $row;
        }

        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->Users_reported_model->count_all(),
            "recordsFiltered" => $this->Users_reported_model->count_filtered(),
            "data" => $data,
        );
        //output to json format
        echo json_encode($output);

    }

    public function activityview($id=''){
        $this->load->model('Logs_model');
        $user = $this->Users_model->get(['users_id'=>$id]);
        $logs = $this->Logs_model->getUsersLogs(['users_id'=>$id]);
       
        
        $this->data['bgcolor'] = "bg-white";
        $this->listCssJs();
        $this->data['parentPage'] = "usersLists";
        $this->data['moduleName'] = "users";
        $this->data['page'] = "usersList";
        $this->data['page_title'] = "User Activity";
        $this->data['user'] = $user;        
        $this->data['logs'] = $logs;   
        $this->data['users_id'] = $id;    
        $this->__template('users/user_activity',$this->data); 

        


    }



    /**
    * Change user status (admin can block and unblock user)
    * @param $action block unblock, $id int
    * redirect on views
    */
    function changestatus($action,$id=''){
         if($action!="" && $id!=""){   
        if($action=="block"){
            $this->Users_model->update(['users_status'=>'2'],$id);
            set_error_notification("User blocked successfully");
        }
        if($action=="unblock"){
            $this->Users_model->update(['users_status'=>'1'],$id);
            set_success_notification("User Unblock successfully");            
        }

        redirect(base_url().'snackadmin/users/views/'.$id);
        }
        else{
         redirect(base_url().'snackadmin/users');   
        }



    }

    public function hasmany(){
        $details = $this->Users_model->with_userpref('fields:preference_id,preference_option_id')->with_prefmaster('fields:preference_name')->with_preferences('fields:option_title')->get(['users_id'=>$id]);

    }


    /**
    * Check user exists or not
    * @param $id user id
    * @return bool
    */
    public function checkuserId($id)
    {
        $result = $this->Users_model->get(['users_id' => $id]);
        if ($result) {
            return TRUE;
        }
        else {
            return FALSE;
        }
    }

    /**/
}

