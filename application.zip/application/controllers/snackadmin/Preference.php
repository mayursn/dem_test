<?php
defined('BASEPATH') OR exit('No direct script access allowed ');
class Preference extends MY_Controller {

    function __construct() {
        parent::__construct(); 
        $this->load->model('Preference_master_model');        
        $this->load->model('Preferences_model');
        $this->data['moduleName'] = "Preference";
        if(!$this->is_logged_in()){
          redirect(base_url()."snackadmin/login");
        }
        
    }


    public function index(){
        

        $this->data['page'] = "preference";
        $this->data['page_title'] = "Preference";
        $this->add_js([
            'plugins/bootstrap-select/js/bootstrap-select.js',
            'plugins/jquery-slimscroll/jquery.slimscroll.js',
            'plugins/bootstrap-notify/bootstrap-notify.js',
            'plugins/node-waves/waves.js',
            'plugins/sweetalert/sweetalert.min.js',            
            'js/admin.js',
            'js/pages/ui/dialogs.js',
            'plugins/jquery-datatable/jquery.dataTables.js',            
            'plugins/jquery-datatable/skin/bootstrap/js/dataTables.bootstrap.js',
            'js/pages/tables/jquery-datatable.js',
            'js/demo.js',
        ]);
       	$this->add_css([            
            'plugins/node-waves/waves.css',
            'plugins/animate-css/animate.css',
            'plugins/sweetalert/sweetalert.css',
            'plugins/jquery-datatable/skin/bootstrap/css/dataTables.bootstrap.css',
            'css/style.css'

        ]);      

        $this->data['preferences'] = $this->Preference_master_model->get_all();
        
        $this->__template('preference/index',$this->data);        
    }

   public function create(){
       if($_POST){
       	$id = $this->Preference_master_model->insert(['preference_name'=>$_POST['txtname']]);   

    
      
      $options = $_POST['options'];
      foreach ($options as $row) {
      $optionsOfPreferences = ['preference_id'=>$id,'option_title'=>$row];
      		$this->Preferences_model->insert($optionsOfPreferences);
      }

      set_success_notification("preference added successfully");
                                    redirect(base_url().'snackadmin/preference');
       }
        $this->cssScript();
        $this->data['page'] = "preference";
        $this->data['page_title'] = "Create Preference";      
        $this->__template('preference/create', $this->data);                

   }


   public function create_data(){


     $pref = $this->Preference_master_model->get(['preference_name'=>$_POST['txtname']]);
        if($pref){
          set_error_notification('This preference already exists!');
          redirect(base_url('preference'));
        }



    $id = $this->Preference_master_model->insert(['preference_name'=>$_POST['txtname']]);   

    
      
      $options = $_POST['options'];
      foreach ($options as $row) {
      $optionsOfPreferences = ['preference_id'=>$id,'option_title'=>$row];
      		$this->Preferences_model->insert($optionsOfPreferences);
      }

      set_success_notification("preference added successfully");
                                    redirect(base_url().'snackadmin/preference');

    
   }






   public function edit($id=''){

       

        $this->cssScript();
        
        $this->data['page'] = "preference";
        $this->data['page_title'] = "Edit Preference";      
        $this->data['preference'] = $this->Preference_master_model->fields('preference_id,preference_name')->get(['preference_id'=>$id]);
        $this->data['preferenceOptions'] = $this->Preferences_model->fields('preferences_option_id,preference_id,option_title')->get_all(['preference_id'=>$id]);
       
        $this->__template('preference/edit', $this->data);                

   }
   public function update($id=''){
	    if($_POST){
	        $this->Preference_master_model->update(['preference_name'=>$_POST['txtname']],$id);   
	        

	        
	    		$existingOption = $_POST['opt'];	
			    foreach($existingOption as $key => $value){
			    	
			    	$options_array = explode("options_",$key);
			    	$option_id = $options_array[1];
			    	//echo $value;
			    	$options_update = ['option_title'=>$value];
			    	$this->Preferences_model->update($options_update,$option_id);
			    	//exit;

				}
	      
		      $options = $_POST['options'];
		      if($options)
		      {
			      foreach ($options as $row) {
			      $optionsOfPreferences = ['preference_id'=>$id,'option_title'=>$row];
			      		$this->Preferences_model->insert($optionsOfPreferences);
			      }
		            
		      }
	    }

	    set_success_notification("Preference updated successfully");
                 redirect(base_url().'snackadmin/preference');

    }
   public function delete($id){
        $update = array("is_deleted"=>'1');
        $result = $this->Preference_master_model->get($id);
        

        if($result->is_static=='0') // is_static 0 means deletable
        {        
          $res = $this->Preference_master_model->update($update,$id);
          if($res){
             set_success_notification("Preference deleted successfully");
          } 
          else{
            set_error_notification("Error while delete! Try again.");
          }

        }        
        else{
              set_error_notification("You can't Delete this option!");
        }

        redirect(base_url().'snackadmin/preference');
   }

   /**
   * Delete preference options 
   * @param id int
   * return void
   */
   public function deleteOptions($id){        
         $res = $this->Preferences_model->delete(['preferences_option_id'=>$id]);
         return $res;
        
   }




    /**
    * Css And Js script added as per required
    *
    */
    public function cssScript(){
        $this->add_css(["plugins/node-waves/waves.css",
                              "plugins/animate-css/animate.css",
                              "plugins/sweetalert/sweetalert.css",
                               'plugins/jquery-datatable/skin/bootstrap/css/dataTables.bootstrap.css',
                              "css/style.css",
                             ]);
        $this->add_js(['plugins/bootstrap-select/js/bootstrap-select.js',
                      'plugins/jquery-slimscroll/jquery.slimscroll.js',
                      'plugins/bootstrap-notify/bootstrap-notify.js',
                      'plugins/jquery-validation/jquery.validate.js',
                      'plugins/node-waves/waves.js',
                      'plugins/sweetalert/sweetalert.min.js',            
                      'js/admin.js',
                      'js/pages/ui/dialogs.js',
                      'plugins/jquery-datatable/jquery.dataTables.js',
                      'plugins/jquery-datatable/skin/bootstrap/js/dataTables.bootstrap.js',
                      'js/pages/tables/jquery-datatable.js',
                      'js/demo.js',
                      'js/form_validate.js']);

    }




    /**/
}