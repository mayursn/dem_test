<?php
defined('BASEPATH') OR exit('No direct script access allowed ');
class Questions extends MY_Controller {

    function __construct() {
        parent::__construct(); 
        $this->load->model('Questions_master_model');
        $this->load->model('Answer_option_model');
        $this->data['moduleName'] = "questions";
        if(!$this->is_logged_in()){
          redirect(base_url()."snackadmin/login");
        }
        
    }


    public function index(){

        $this->data['page'] = "questions";
        $this->data['page_title'] = "Questions";
        $this->add_js([
            'plugins/bootstrap-select/js/bootstrap-select.js',
            'plugins/jquery-slimscroll/jquery.slimscroll.js',
            'plugins/bootstrap-notify/bootstrap-notify.js',
            'plugins/node-waves/waves.js',
            'plugins/sweetalert/sweetalert.min.js',            
            'js/admin.js',
            'js/pages/ui/dialogs.js',
            'plugins/jquery-datatable/jquery.dataTables.js',            
            'plugins/jquery-datatable/skin/bootstrap/js/dataTables.bootstrap.js',
            'js/pages/tables/jquery-datatable.js',
            'js/demo.js',
        ]);
       $this->add_css([            
            'plugins/node-waves/waves.css',
            'plugins/animate-css/animate.css',
            'plugins/sweetalert/sweetalert.css',
            'plugins/jquery-datatable/skin/bootstrap/css/dataTables.bootstrap.css',
            'css/style.css'

        ]);      
        $this->data['questions'] = $this->Questions_master_model->get_all();

        $this->__template('questions/question_list',$this->data);        
    }

   public function create(){
        $this->cssScript();        
        $this->data['page'] = "questions";
        $this->data['page_title'] = "Create Questions";               
        $this->__template('questions/create', $this->data);  
   }


   public function create_data(){
    if($_POST)
    {

      $que = $this->Questions_master_model->get(['question_title'=>$_POST['txtname']]);
      if($que){
          set_error_notification('This question already exists!');
          redirect(base_url('preference/create'));
        }
        
    $id = $this->Questions_master_model->insert(['question_title'=>$_POST['txtname']]);
    $answers = $_POST['options'];

    foreach ($answers as $ans) {
        $this->Answer_option_model->insert(['question_id'=>$id,'answer_title'=>$ans]);
    }

     set_success_notification("Question added successfully");
     
    }
    redirect(base_url().'snackadmin/questions');
   }



   public function edit($id=''){

        if($_POST){
          
          
                    

                            
                          
          $info = ['question_title'=>$this->input->post('txtname')];
                                $res =  $this->Questions_master_model->update($info,$id);


          $existingOption = $_POST['opt'];  
          foreach($existingOption as $key => $value){
            
            $options_array = explode("options_",$key);
            $option_id = $options_array[1];
            //echo $value;
            $options_update = ['answer_title'=>$value];
            $this->Answer_option_model->update($options_update,$option_id);
            //exit;

        }
        
          $options = $_POST['options'];
          if($options)
          {
            foreach ($options as $row) {
            $optionsOfPreferences = ['question_id'=>$id,'answer_title'=>$row];
                $this->Answer_option_model->insert($optionsOfPreferences);
            }
                
          }

         set_success_notification("Question updated successfully");
                                    redirect(base_url().'snackadmin/questions');
                            
            
        }

        $this->cssScript();
        
        $this->data['page'] = "questions";
        $this->data['page_title'] = "Edit Question";      
        $this->data['question'] = $this->Questions_master_model->get(['question_id'=>$id]);
         $this->data['answerOptions'] = $this->Answer_option_model->get_all(['question_id'=>$id]);
       
        $this->__template('questions/edit', $this->data);                

   }

   public function delete($id){
        $update = array("is_deleted"=>'1');

        //$where = array("cms_id",$id);
        $res = $this->Questions_master_model->update($update,$id);
        
        if($res){
             set_success_notification("Question deleted successfully");
                 redirect(base_url().'snackadmin/questions');
        }
        else{
              set_error_notification("Error while delete Question! Try again");
                 redirect(base_url().'snackadmin/questions');   
        }
   }

    /**/
    public function cssScript(){
        $this->add_css(["plugins/node-waves/waves.css",
                              "plugins/animate-css/animate.css",
                              "plugins/sweetalert/sweetalert.css",
                               'plugins/jquery-datatable/skin/bootstrap/css/dataTables.bootstrap.css',
                              "css/style.css",
                             ]);
        $this->add_js([
           'plugins/bootstrap-select/js/bootstrap-select.js',
                      'plugins/jquery-slimscroll/jquery.slimscroll.js',
                      'plugins/bootstrap-notify/bootstrap-notify.js',
                      'plugins/jquery-validation/jquery.validate.js',
                      'plugins/node-waves/waves.js',
                      'plugins/sweetalert/sweetalert.min.js',            
                      'js/admin.js',
                      'js/pages/ui/dialogs.js',
                      'plugins/jquery-datatable/jquery.dataTables.js',
                      'plugins/jquery-datatable/skin/bootstrap/js/dataTables.bootstrap.js',
                      'js/pages/tables/jquery-datatable.js',
                      'js/demo.js',
                      'js/form_validate.js'
                             ]);

    }


    


     /**
   * Delete preference options 
   * @param id int
   * return void
   */
   public function deleteOptions($id){        
         $res = $this->Answer_option_model->delete(['answer_id'=>$id]);
         return $res;
        
   }



    /**/
}