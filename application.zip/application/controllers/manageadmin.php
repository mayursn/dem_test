<section class="content">
        <div class="container-fluid">
            <div class="block-header">
                <h2> </h2>
            </div>
            <!-- Vertical Layout -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                     <?php echo print_notification(); ?>
                        <div class="header">
                         <ul class="nav nav-tabs tab-nav-right" role="tablist">
                                <li role="presentation" class="active"><a href="#home" data-toggle="tab"> Edit Profile</a></li>
                                <li role="presentation"><a href="#changepassword" data-toggle="tab">Change password</a></li>
                                
                            </ul>

                          
                           
                            <!-- <ul class="header-dropdown m-r--5">
                                <li class="dropdown">
                                    <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                                        <i class="material-icons">more_vert</i>
                                    </a>
                                    <ul class="dropdown-menu pull-right">
                                        <li><a href="javascript:void(0);" class=" waves-effect waves-block">Action</a></li>
                                        <li><a href="javascript:void(0);" class=" waves-effect waves-block">Another action</a></li>
                                        <li><a href="javascript:void(0);" class=" waves-effect waves-block">Something else here</a></li>
                                    </ul>
                                </li>
                            </ul> -->
                        </div>
                        <div class="body">
                          <div class="tab-content">
                                <div role="tabpanel" class="tab-pane fade in active" id="home">
                            <form action="<?php echo base_url(); ?>admin/index" method="post" enctype="multipart/form-data" id="adminprofile">
                            <input type="hidden" name="id" value="<?php if(isset($profile)){ echo $profile->admin_id; } ?>">
                            
                            <label for="email_address">Name </label>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" name="txtname" id="admin_name" class="form-control" value="<?php if(isset($profile)){ echo $profile->admin_name; } ?>" placeholder="Name">
                                    </div>
                                </div>
                                <label for="email_address">Email Address</label>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" id="email_address" name="txtemail" class="form-control" value="<?php if(isset($profile)){  echo $profile->admin_email; } ?>" placeholder="Enter your email address">
                                    </div>
                                </div>
                                <label for="phone">Phone</label>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" id="phone" name="txtphone" class="form-control" value="<?php if(isset($profile)){  echo $profile->admin_mobile; } ?>" placeholder="Enter your phone number">
                                    </div>
                                </div>
                                <label for="photo">Photo </label>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="file" name="photo" id="photo" class="form-control" >
                                        <?php if(isset($profile)){  if($profile->admin_photo!=""){ ?>
                                        <div class="image">
                                        <img src="<?php echo base_url(); ?>uploads/admin/<?php echo $profile->admin_photo; ?>" height="48" width="48">
                                        </div>

                                        <?php } }?>
                                    </div>
                                </div>
                                	
                                <!-- <label for="password">Password</label>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="password" id="password" class="form-control" placeholder="Enter your password">
                                    </div>
                                </div> -->
                                
                                <br>
                                <button type="submit" class="btn btn-primary m-t-15 waves-effect">Save</button>
                            </form>
                            </div>
                        
                        </div> <!-- vbv >
                    </div>
                </div>
            </div>           
           
        </div>
    </section>
    <script type="text/javascript">
    	
    </script>
