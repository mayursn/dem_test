<?php

defined('BASEPATH') OR exit('No direct script access allowed ');

require APPPATH . '/libraries/REST_Controller.php';

class Credits extends REST_Controller{

    /**
    * Construct function 
    * loading Credits info model and users model
    * loading language file
    * basic set of credits of debit you can find in lang file    
    * 1) To get more messages = more_messages
    * 2) Move_to_the_top = move_top
    * 3) To get more matches = more_matches
    * 4) To get more visits = more_visits
    * 5) Emoji's = emojis 
    * 6) Send messages to the people not connected to you = direct_message         
    */
    /**
    * At the End of the file Dailydebits_get functions which is cron job functions so don't delete it
    below is path of cron job
    /usr/local/bin/php -f /home/pr01004/public_html/index.php api/credits dailyDebits
    */

    function __construct() {
        parent::__construct(); 
        $this->load->model('credits_info_model');
        $this->load->model('wallet_balance_model');
        $this->load->model('Users_model');
        $this->load->model('Credit_percent_model');        
        $this->lang->load('message', 'english');
        $this->load->model('Credit_function_costs_model');

    }

    /**
    *  get purchasing addition credits information data for user
    * @param users_id
    * @return response data in json array
    */
    function getCreditsdata_get(){
       
        $users_id = $this->get('users_id');

        if(!$this->checkuserId($users_id)){

            _trackUser(TRUE, "User not found", TRUE, $users_id); // log

            $this->response(['status' => FALSE,'message' => 'User not found',
                'userstatus' => FALSE ], REST_Controller::HTTP_OK); // response
        }

    
        $data = $this->credits_info_model->fields('id,credits,currency,amount,ios_identifier,android_identifier,duration')->where(['status'=>'1'])->get_all();

        $rowdata = [];

        foreach ($data as $key => $rows) {

            $currency_amount = $rows->amount;   

            $duration = $rows->duration;

            if($rows->duration==""){

                $duration = "";

            }

            $rowdata[$key] =    [
                                    'id'                =>$rows->id,
                                    'credits'           =>$rows->credits,
                                    'amount'            =>$currency_amount,
                                    'ios_identifier'    =>$rows->ios_identifier,
                                    'android_identifier'=>$rows->android_identifier,
                                    'duration'          =>$duration
                                ];
        }

       

        if(empty($rowdata)){

            $this->response(array(
                'status' => FALSE,
                'message' => 'No data found' ) , REST_Controller::HTTP_OK);
        
        }else{

            _trackUser(TRUE, 'Purchasing Additional Credits List', TRUE, $users_id); // user logs

            $this->response(array(
                'status' => TRUE,
                'message' => 'Purchasing Additional Credits List',
                'data' => $rowdata ) , REST_Controller::HTTP_OK);

        }
      
    }


    /**
    * Add weekly credits
    * @param $users_id, $amount, $credits, $purchased_id = 1
    * @return response json array
    */
    function addDailyCredits_post(){

        $users_id           = $this->post('users_id');
        $subscription_type  = $this->post('subscription_type'); // free_trial OR premium
        $purchase_id        = 1;        
        $purchase_amount    = isset($_POST['amount']) ? $_POST['amount'] : '70';
        $purchase_credits   = isset($_POST['credits']) ? $_POST['credits'] : '70';
        $duration           = isset($_POST['duration']) ? $_POST['duration'] : '7';
        $device_type        = isset($_POST['device_type']) ? $_POST['device_type'] : 'IOS'; // Android/IOS

        if(!$this->checkuserId($users_id)){

            _trackUser(TRUE, "User not found", TRUE, $users_id); // log

            $this->response([
                                'status'        => FALSE,
                                'message'       => 'User not found',
                                'userstatus'    => FALSE ], 
                                REST_Controller::HTTP_OK); // response
        }

        $user = $this->Users_model->get($users_id);

        // when user use 14 days free trial
        if($subscription_type=="free_trial"){

            if($user->premium_trial_used=='1'){

                 $this->response(array(
                    'status' => FALSE,
                    'message' =>"You have already used free trial" ) , 
                    REST_Controller::HTTP_OK);

            }

            $date  = date('Y-m-d');

            $data = [
                        'premium_status'            =>'1',
                        'premium_trial_used'        =>'1',                        
                        'freetrial_start_date'        =>date('Y-m-d'),
                        'freetrial_end_date'          =>date('Y-m-d', strtotime($date. " + 14 days")),
                        'premium_trial_device_type' =>$device_type
                    ];

            $this->Users_model->update($data,$users_id);

            _trackUser(TRUE, $this->lang->line('free_premium_trial'), TRUE, $users_id); // user logs
        
            $this->response(array(
                    'status' => TRUE,
                    'message' =>"Thank you for being our premium trial user, now you will not see any kind of advertising in app" ) , 
                    REST_Controller::HTTP_OK);

        }

        $total_credits = $user->total_credits;

        $total_credits = ($total_credits + $purchase_credits); // for wallet table       
        $weekly_credits = $purchase_credits;

        $Date = date("Y-m-d H:i:s");

        //'expired_date'=>date('Y-m-d H:i:s', strtotime($Date. ' + 7 days'))
        $data = [   
                    'users_id'          =>$users_id,
                    'purchase_id'       =>$purchase_id,
                    'purchase_amount'   =>$purchase_amount,
                    'purchase_credits'  =>$purchase_credits,
                    'total_credits'     =>$total_credits,
                    'type'              =>'credit',   
                    'credit_type'       =>'weekly',               
                    'purchased_date'    =>date('Y-m-d H:i:s')
                ];

        // added data into wallet balance to track the credits and it uses
        $res = $this->wallet_balance_model->insert($data);

        $this->wallet_balance_model->addUpdateWalletExpiry($data,$duration);

        if($total_credits > 0){

            $user_data = [
                            'premium_status'                    =>'1',
                            'weekly_credits'                    => $weekly_credits,
                            'premium_subscription_device_type'  => $device_type
                         ];

            // updating purchased credits 
            $updated = $this->Users_model->update($user_data,$users_id);

            if($updated){

                _trackUser(TRUE, $this->lang->line('daily_credits'), TRUE, $users_id); // user logs
        
                $this->response(array(
                    'status' => TRUE,
                    'message' =>"Thank you for being our premium user, now you will not see any kind of advertisement in app." ) , 
                    REST_Controller::HTTP_OK);

            }else{

                $this->response(array(
                    'status' => FALSE,
                    'message' => "Error while updating credits") , 
                    REST_Controller::HTTP_OK);

            }

        }else{
                $this->response(array(
                    'status' => FALSE,
                    'message' => "Error while updating credits" ) , 
                    REST_Controller::HTTP_OK);
        }

    }

    /**
    * Purchase additional credits
    * @param $users_id,$purchase_id,$purchase_amount,$purchase_credits
    * @return response json array
    */
    function purchaseCredits_post(){

        $users_id           = $this->post('users_id');
        $purchase_id        = $this->post('purchase_id');
        $purchase_amount    = $this->post('amount');
        $purchase_credits   = $this->post('credits');

        if(!$this->checkuserId($users_id)){

            _trackUser(TRUE, "User not found", TRUE, $users_id); // log

            $this->response(['status' => FALSE,'message' => 'User not found',
                'userstatus' => FALSE ], REST_Controller::HTTP_OK); // response
        }

        $user = $this->Users_model->get($users_id);

        if($user->premium_status=='0'){

            $this->response(['status' => FALSE,'message' => 'Please subscribe premium membership',
                'userstatus' => FALSE ], REST_Controller::HTTP_OK); // response   

        }

        $total_credits = $user->total_credits + $user->weekly_credits;

        $total_credits = ($total_credits + $purchase_credits);

                  $this->db->order_by('wallet_id','DESC');        
        $wallet = $this->wallet_balance_model->where(['users_id'=>$users_id])->get();

        $additional_credits = ($wallet->total_credits + $purchase_credits);
        
        $data = [   
                    'users_id'          =>$users_id,
                    'purchase_id'       =>$purchase_id,
                    'purchase_amount'   =>$purchase_amount,
                    'purchase_credits'  =>$purchase_credits,
                    'total_credits'     =>$additional_credits,
                    'type'              =>'credit',
                    'credit_type'       =>'additional',
                    'purchased_date'    =>date('Y-m-d H:i:s')

                ];

        // added data into wallet balance to track the credits and it uses
        $res = $this->wallet_balance_model->insert($data);

        if($total_credits > 0){

            $total_credits = $user->total_credits + $purchase_credits;

            $user_data = [
                            'total_credits' => $total_credits
                         ];

            // updating purchased credits 
            $updated = $this->Users_model->update($user_data,$users_id);

            if($updated){

                _trackUser(TRUE, $this->lang->line('more_messages'), TRUE, $users_id); // user logs
        
                $this->response(array(
                    'status' => TRUE,
                    'message' =>"Thank you for purchasing credits" ) , REST_Controller::HTTP_OK);

            }else{

                $this->response(array(
                    'status' => FALSE,
                    'message' => "Error while updating credits") , REST_Controller::HTTP_OK);

            }

        }else{
                $this->response(array(
                    'status' => FALSE,
                    'message' => "Error while updating credits" ) , REST_Controller::HTTP_OK);
        }
    }



    /**
    * User spend their credits to the get more messages
    * @param user_id, credits
    * @return response json array 
    */
    function getMoreMessage_post(){        
     
        $users_id = $this->post('users_id');
        $credits = $this->post('credits');
        $spend_type = "more_messages";

        if(!$this->checkuserId($users_id)){

            _trackUser(TRUE, "User not found", TRUE, $users_id); // log

            $this->response(['status' => FALSE,'message' => 'User not found',
                'userstatus' => FALSE ], REST_Controller::HTTP_OK); // response
        }

        $user = $this->Users_model->fields('weekly_credits,total_credits,credit_percent')->get($users_id);

        $total_credits = $user->total_credits + $user->weekly_credits;

        $credit_percent = $user->credit_percent;

        if($total_credits >= $credits){

        $total_credits = ($total_credits - $credits); // total credits for wallet balance table

        $percent = $this->Credit_percent_model->where(['type'=>'more_messages'])->get();

        $percent = $percent->percent;

        if($credit_percent <= 100){

            $percent = ($credit_percent + $percent);

            // if percent is greater than 100
            if($percent > 100){

                $percent = 100;
            }

        }else{
            // if percent is greater than 100
            $percent = $credit_percent;

        }

        /* start Weekly credits and total credits calculation */
                  $this->db->order_by('wallet_id','DESC');
        $wallet = $this->wallet_balance_model->where(['users_id'=>$users_id])->get();

            
        $wallet_data = creditCalculations($user,$wallet,$credits);
        
        $weekly_credits = $wallet_data['weekly_credits'];

        $total_credits = $wallet_data['total_credits'];

        $wallet_balance_total = $wallet_data['wallet_balance_total'];

        /* end Weekly credits and total credits calculation */

        $user_data =    [
                            'weekly_credits'=>$weekly_credits,
                            'total_credits' => $total_credits,
                            'credit_percent'=>$percent,
                            'credit_percent_update_time'=>date('Y-m-d H:i:s')
                        ];

        // updating purchased credits                         
        $updated = $this->Users_model->update($user_data,$users_id);
        
         $data = [   
                    'users_id' =>$users_id,
                    'debit_value'=>$credits,
                    'use_for'=>$this->lang->line('more_messages'),                    
                    'debit_date'=>date('Y-m-d H:i:s'), 
                    'type'=>'debit',                   
                    'total_credits'=>$wallet_balance_total
                ];

        // added data into wallet balance to track the credits and it uses

        $res = $this->wallet_balance_model->insert($data);

        $this->sendMessages($users_id);

            _trackUser(TRUE, $this->lang->line('more_messages'), TRUE, $users_id); // user logs
        
            $this->response(array(
                'status' => TRUE,
                'message' =>"Thank you for spending $credits credits"                     
            ) , REST_Controller::HTTP_OK);
        
        }else{

             $this->response(array(
                'status' => FALSE,
                'message' => "You don't have enough credits."
            ) , REST_Controller::HTTP_OK);
        }

    }


    /**
    * Send random messages to other users when user use credit for get more messages
    * @param $users_id
    * @return $response    
    */

    function sendMessages($users_id){
        $this->load->model('Users_block_model');
        $this->load->model('Users_like_model');
        $this->load->model('Chat_model');

        // user details

        $user = $this->Users_model->get($users_id);

        if($user->looking_for!=""){

            $where['looking_for'] = $user->looking_for;

            if($user->looking_for =="Male & Female" || $user->looking_for =="Other" )
            {
                $where['looking_for'] = "";                
            }

        }

       
        

        $blocked = $this->Users_block_model->fields('blocked_users_id')->get_all(['users_id'=>$users_id]); 

        $blocked_id[] = $users_id;

        if(!empty($blocked)){

            foreach ($blocked as $rows) {

                $blocked_id[] = $rows->blocked_users_id;

            }
        
        }

        $users = $this->Users_like_model->mutualUserID($users_id);

        if(!empty($users)) {

            foreach ($users as $rows) {

                $blocked_id[] = $rows->users_id;

            }
           
        }

        $id = implode(",", $blocked_id);

        $randomusers = $this->Users_model->getRandomUsers($id,$where);
        if(!empty($randomusers)){
            foreach ($randomusers as $rows) {
            
            $this->load->model('Messages_model');
            $sender_name = $user->users_fname." ".$user->users_lname;
            $message = $sender_name." wants to chat with you";

            $receiver_id  = $rows->users_id;
            $sender_id =$users_id;

            /*$this->db->insert('chat',['sender_id'=>$sender_id,'receiver_id'=>$receiver_id,'message'=>$message,'created_date'=>date('Y-m-d H:i:s'),'updated_date'=>date('Y-m-d H:i:s'),'chat_type'=>'0','sender_visibility'=>'0','receiver_visibility'=>'0','random_status'=>'1','random_users_id'=>$sender_id]);
            $chat_id = $this->db->insert_id();*/

            $chat = $this->Chat_model->where(['sender_id'=>$sender_id,'receiver_id'=>$receiver_id])->get();
            if(empty($chat)){
                
                $chat_id = $this->Chat_model->insert(['sender_id'=>$sender_id,'receiver_id'=>$receiver_id,'message'=>$message,'created_date'=>date('Y-m-d H:i:s'),'updated_date'=>date('Y-m-d H:i:s'),'chat_type'=>'1','sender_visibility'=>'1','receiver_visibility'=>'1','random_status'=>'1','random_users_id'=>$sender_id]);
                
            }else{
                $chat_id = $chat->chat_id;
                $this->db->where(['chat_id'=>$chat_id]);
                $this->Chat_model->update([
                                            'sender_id'=>$sender_id,
                                            'receiver_id'=>$receiver_id,
                                            'message'=>$message,
                                            'created_date'=>date('Y-m-d H:i:s'),
                                            'updated_date'=>date('Y-m-d H:i:s'),
                                            'chat_type'=>'1',
                                            'sender_visibility'=>'1',
                                            'receiver_visibility'=>'1',
                                            'random_status'=>'1',
                                            'random_users_id'=>$sender_id]);

                
            }

            $messages = $this->Messages_model->insert(
                
                ['sender_id'=>$sender_id,
                'receiver_id'=>$receiver_id,
                'message'=>$message,                
                'emoji_flag'=>"0", 
                "random_message"=>'1',
                'chat_id'=>$chat_id,
                'sender_visibility'=>'1',
                'receiver_visibility'=>'1',
                'message_type'=>"direct_message"]);

            }

            // send push notification

            if(!empty($rows->device_token) && $rows->users_status=="1"){

                    $device_token = $rows->device_token;                    
                    $device_type = $rows->device_type;  

                    $text = ucfirst($sender_name." wants to chat with you");
                   
                    //$text = json_decode($text);
                    $title = "";
                    $type = "0";

                    $userMsg = $this->Messages_model->get(['message_id'=>$messages]);
                    $userMsg->users_id = $users_id;
                    $userMsg->name = $sender_name;
                    $userMsg->sender_visibility = '1';
                    $userMsg->receiver_visibility = '1';
                    $userMsg->chat_id =$chat_id;                    
                    $userMsg->chat_receiver_id =$receiver_id;
                    $userMsg->chat_sender_id =$sender_id;
                    $userMsgData = userNotificationData($userMsg);

                    $badge = badgeCount($receiver_id);
                    if($device_type=="IOS"){
                    
                        sendPushNotificationIos($device_token, $text, $title,$sender_id,$type,$userMsgData,$badge);

                    }
                    if($device_type=="Android"){
                        $notification_data = ['users_id'=>$receiver_id];
                        $this->db->insert('user_notification',$notification_data);
                            $msg['body'] = ['body'=> $text, 
                                            'badge' => $badge,
                                            'type'=>$type,
                                            'users_id'=>$sender_id
                                            ];
                            $msg['msgdata'] = $userMsgData;

                        sendPushNotificationAndroid($device_token, $msg);

                    }
                }
        }


    }


    /**
    * Move to the top credit functionality
    * @param $users_id, $credits
    * @return response json array
    */
    function movetoTop_post(){

        $users_id = $this->post('users_id');

        $credits = $this->post('credits');

        $spend_type = "move_top";

        if(!$this->checkuserId($users_id)){

            _trackUser(TRUE, "User not found", TRUE, $users_id); // log

            $this->response(['status' => FALSE,'message' => 'User not found',
                'userstatus' => FALSE ], REST_Controller::HTTP_OK); // response
        }

        $user = $this->Users_model->fields('weekly_credits,total_credits,credit_percent')->get($users_id);

        $total_credits = $user->total_credits + $user->weekly_credits;

        $credit_percent = $user->credit_percent;

        if($total_credits >= $credits){

        /*$total_credits = ($total_credits - $credits);*/

        $percent = $this->Credit_percent_model->where(['type'=>'move_top'])->get();

        $percent = $percent->percent;

        if($credit_percent <= 100){

            $percent = ($credit_percent + $percent);

            // if percent is greater than 100
            if($percent > 100){

                $percent = 100;
            }

        }else{

            // if percent is greater than 100
            $percent = $credit_percent;

        }
                 
       /* start Weekly credits and total credits calculation */
         $this->db->order_by('wallet_id','DESC');
        $wallet = $this->wallet_balance_model->where(['users_id'=>$users_id])->get();

            
        $wallet_data = creditCalculations($user,$wallet,$credits);
        
        $weekly_credits = $wallet_data['weekly_credits'];
        $total_credits = $wallet_data['total_credits'];
        $wallet_balance_total = $wallet_data['wallet_balance_total'];

        /* end Weekly credits and total credits calculation */
        $date = date('Y-m-d');
        $user_data =    [
                            'weekly_credits'=>$weekly_credits,
                            'total_credits' => $total_credits,
                            'credit_percent'=>$percent,
                             'move_to_top'=>'1', 
                            'move_top_expired_date'=>date('Y-m-d H:i:s',strtotime($date." +7 days")),   
                            'credit_percent_update_time'=>date('Y-m-d H:i:s')
                        ];

        // updating purchased credits 
        $updated = $this->Users_model->update($user_data,$users_id);


         $data = [   
                    'users_id' =>$users_id,
                    'debit_value'=>$credits,
                    'use_for'=>$this->lang->line('move_top'),                    
                    'debit_date'=>date('Y-m-d H:i:s'),     
                    'type'=>'debit',               
                    'total_credits'=>$wallet_balance_total
                ];

        // added data into wallet balance to track the credits and it uses

        $res = $this->wallet_balance_model->insert($data);



            _trackUser(TRUE, $this->lang->line('move_top'), TRUE, $users_id); // user logs
        
            $this->response(array(
                'status' => TRUE,
                'message' =>"Thank you for spending $credits credits"                     
            ) , REST_Controller::HTTP_OK);
        


        }else{
             $this->response(array(
                'status' => FALSE,
                'message' => "You don't have enough credits."
            ) , REST_Controller::HTTP_OK);
        }


    }

    /**
    * Get more matches credit functionality
    * @param $users_id, $credits
    * @return response json array
    */
    function moreMatches_post(){

        $users_id = $this->post('users_id');

        $credits = $this->post('credits');

        $spend_type = "more_matches";

        if(!$this->checkuserId($users_id)){

            _trackUser(TRUE, "User not found", TRUE, $users_id); // log

            $this->response(['status' => FALSE,'message' => 'User not found',
                'userstatus' => FALSE ], REST_Controller::HTTP_OK); // response
        }

        $user = $this->Users_model->fields('weekly_credits,total_credits,credit_percent')->get($users_id);

        $total_credits = $user->total_credits + $user->weekly_credits;

        $credit_percent = $user->credit_percent;

        if($total_credits >= $credits){

        $total_credits = ($total_credits - $credits);

        $percent = $this->Credit_percent_model->where(['type'=>'more_matches'])->get();

        $percent = $percent->percent;

        if($credit_percent <= 100){

            $percent = ($credit_percent + $percent);

            // if percent is greater than 100
            if($percent > 100){

                $percent = 100;
            }

        }else{

            // if percent is greater than 100
            $percent = $credit_percent;

        }


                 
        /* start Weekly credits and total credits calculation */
         $this->db->order_by('wallet_id','DESC');
        $wallet = $this->wallet_balance_model->where(['users_id'=>$users_id])->get();

            
        $wallet_data = creditCalculations($user,$wallet,$credits);
        
        $weekly_credits = $wallet_data['weekly_credits'];
        $total_credits = $wallet_data['total_credits'];
        $wallet_balance_total = $wallet_data['wallet_balance_total'];

        /* end Weekly credits and total credits calculation */
        $date= date('Y-m-d H:i:s');
        $user_data =    [
                            'weekly_credits'=>$weekly_credits,
                            'total_credits' => $total_credits,
                            'credit_percent'=>$percent,
                            'more_matches_status'=>'1',
                            'matches_expired_date'=>date('Y-m-d H:i:s',strtotime($date." +7 days")),
                            'credit_percent_update_time'=>date('Y-m-d H:i:s')
                        ];

        // updating purchased credits                         
        $updated = $this->Users_model->update($user_data,$users_id);

        $data = [   
                    'users_id' =>$users_id,
                    'debit_value'=>$credits,
                    'use_for'=>$this->lang->line('more_matches'),                    
                    'debit_date'=>date('Y-m-d H:i:s'),     
                    'type'=>'debit',               
                    'total_credits'=>$wallet_balance_total
                ];

        // added data into wallet balance to track the credits and it uses

        $res = $this->wallet_balance_model->insert($data);

            _trackUser(TRUE, $this->lang->line('more_matches'), TRUE, $users_id); // user logs
        
            $this->response(array(
                'status' => TRUE,
                'message' =>"Thank you for spending $credits credits"                     
            ) , REST_Controller::HTTP_OK);
        


        }else{

             $this->response(array(
                'status' => FALSE,
                'message' => "You don't have enough credits."
            ) , REST_Controller::HTTP_OK);

        }


    }

    /**
    * Get more visits credit functionality
    * @param $users_id, $credits
    * @return response json array
    */
    function moreVisits_post(){

        $users_id = $this->post('users_id');

        $credits = $this->post('credits');

        $spend_type = "more_visits";

        if(!$this->checkuserId($users_id)){

            _trackUser(TRUE, "User not found", TRUE, $users_id); // log

            $this->response(['status' => FALSE,'message' => 'User not found',
                'userstatus' => FALSE ], REST_Controller::HTTP_OK); // response
        }

        $user = $this->Users_model->fields('weekly_credits,total_credits,credit_percent')->get($users_id);

        $total_credits = ($user->total_credits + $user->weekly_credits);

        $credit_percent = $user->credit_percent;

        if($total_credits >= $credits){

        $total_credits = ($total_credits - $credits);

        $percent = $this->Credit_percent_model->where(['type'=>'more_visits'])->get();

        $percent = $percent->percent;

        if($credit_percent <= 100){

            $percent = ($credit_percent + $percent);

            // if percent is greater than 100 
            if($percent > 100){

                $percent = 100;
            }

        }else{

            // if percent is greater than 100
            $percent = $credit_percent;

        }

          /* start Weekly credits and total credits calculation */
         $this->db->order_by('wallet_id','DESC');
        $wallet = $this->wallet_balance_model->where(['users_id'=>$users_id])->get();

        // wallet calculation function
        $wallet_data = creditCalculations($user,$wallet,$credits);
        
        $weekly_credits = $wallet_data['weekly_credits'];
        $total_credits = $wallet_data['total_credits'];
        $wallet_balance_total = $wallet_data['wallet_balance_total'];
        

        /* end Weekly credits and total credits calculation */
        $date = date('Y-m-d');
        $user_data =    [
                            'weekly_credits'=>$weekly_credits,
                            'total_credits' => $total_credits,
                            'credit_percent'=>$percent,
                             'get_more_visits'=>'1',
                            'visits_expired_date'=>date('Y-m-d H:i:s',strtotime($date." +7 days")),
                            'credit_percent_update_time'=>date('Y-m-d H:i:s')
                        ];

        // updating purchased credits 
        $updated = $this->Users_model->update($user_data,$users_id);


        $data = [   
                    'users_id' =>$users_id,
                    'debit_value'=>$credits,
                    'use_for'=>$this->lang->line('more_visits'),                    
                    'debit_date'=>date('Y-m-d H:i:s'),     
                    'type'=>'debit',               
                    'total_credits'=>$wallet_balance_total
                ];

        // added data into wallet balance to track the credits and it uses

        $res = $this->wallet_balance_model->insert($data);

        $id  = $this->db->insert('promoted_users',
                                            ['promoted_users_id'=>$users_id,
                                            'created_date'=>date('Y-m-d H:i:s'),   
                                            'expiration_date'=>date('Y-m-d', strtotime($date. " + 14 days")),
                                            'promote_date'=>date('Y-m-d'),
                                            'promote_status'=>'0'
                                            ]);

            _trackUser(TRUE, $this->lang->line('more_visits'), TRUE, $users_id); // user logs
        
            $this->response(array(
                'status' => TRUE,
                'message' =>"Thank you for spending $credits credits"                     
            ) , REST_Controller::HTTP_OK);
        
        }else{

             $this->response(array(
                'status' => FALSE,
                'message' => "You don't have enough credits."
            ) , REST_Controller::HTTP_OK);
             
        }


    }

    /** 
    * Get credits functions and costs
    * @param 
    * @return response json array
    */
    function getCreditcostsData_get(){

        $users_id = $this->get('users_id');

        if(!$this->checkuserId($users_id)){

            _trackUser(TRUE, "User not found", TRUE, $users_id); // log

            $this->response(['status' => FALSE,'message' => 'User not found',
                'userstatus' => FALSE ], REST_Controller::HTTP_OK); // response
        }

        $user = $this->Users_model->fields('move_to_top,more_matches_status,get_more_visits')->where(['users_id'=>$users_id])->get();

      
        $credits_data = $this->Credit_function_costs_model->fields('id,title,credits,description')->get_all();

        $credits = [];

        foreach ($credits_data as $key => $value) {
                $title = $value->title;
                if($value->title==""){
                    $title = $value->title = "";
                }

                $credits_value = $value->credits;
                if($value->credits==""){
                    $credits_value = $value->credits = "";
                }
                
                $description = $value->description;                    
                if($value->description==""){
                    $description = $value->description = "";
                }
                $is_in_use = '0';
                
                if($title=="Move to the top"){
                    
                    if($user->move_to_top=="1"){
                        $is_in_use = "1";
                    }else{
                        $is_in_use = "0";
                    }
                }

                if($title=="To get more matches"){
                    if($user->more_matches_status=="1"){
                        $is_in_use = "1";
                    }else{
                        $is_in_use = "0";
                    }
                } 
                if($title=="To get more visits"){
                    if($user->get_more_visits=="1"){
                        $is_in_use = "1";
                    }else{
                        $is_in_use = "0";
                    }
                }  

                $credits[] = ['id'=>$value->id,
                                'title'=>$title,
                                'credits'=>$credits_value,
                                'description'=>$description,
                                'is_in_use'=>$is_in_use
                            ];
        }

        if($credits){

            $this->response(array(
                    'status' => TRUE,
                    'credits'=>$credits,
                    'message' =>"Credits functions costs"                     
            ) , REST_Controller::HTTP_OK);

        }else{

             $this->response(array(
                'status' => FALSE,
                'message' => "Something went wrong."
            ) , REST_Controller::HTTP_OK);

        }


    }


    /**
    * User cancel subscription 
    * @param $users_id
    * @return response json array
    */
    function cancelSubscription_post(){

        $users_id = $this->post('users_id');
        
        if(!$this->checkuserId($users_id)){
            _trackUser(TRUE, "User not found", TRUE, $users_id); // log

            $this->response(['status' => FALSE,'message' => 'User not found',
                'userstatus' => FALSE ], REST_Controller::HTTP_OK); // response
        }

        $user = $this->Users_model->fields('weekly_credits,premium_status,premium_trial_used')->get($users_id);
        $weekly_credits = $user->weekly_credits;
        if($user->premium_status=='1'){

            if($user->premium_trial_used=="0"){

                $user_data  =   [  
                                    'premium_status'=>'0',
                                    'weekly_credits' => '0'
                                ];
            }else{
                $user_data  =   [  
                                    'premium_status'=>'0',
                                    'weekly_credits' => '0',
                                    'premium_trial_used'=>'1',
                                    'freetrial_end_date'=>date('Y-m-d')
                                ];
            }

            // updating purchased credits 
            $updated    = $this->Users_model->update($user_data,$users_id);
            

                        $this->db->order_by('wallet_id','DESC');
            $wallet = $this->wallet_balance_model->where(['users_id'=>$users_id])->get();
            if($wallet){

                if($wallet->total_credits > $weekly_credits){
                    $total_credits = ($wallet->total_credits - $weekly_credits);
                }else{
                    $total_credits = ($weekly_credits - $wallet->total_credits);
                }

                

                    $data = [   
                                'users_id' =>$users_id,
                                'debit_value'=>$weekly_credits,
                                'use_for'=>$this->lang->line('cancel_subscription'),                    
                                'debit_date'=>date('Y-m-d H:i:s'), 
                                'type'=>'debit',                   
                                'total_credits'=>$total_credits
                            ];

                // added data into wallet balance to track the credits and it uses

                    $res = $this->wallet_balance_model->insert($data);

                


            }


            if($updated){
                 $this->response(array(
                        'status' => TRUE,
                        'message' => "Subscription cancel successfully" ) , REST_Controller::HTTP_OK);
            }else{
                 $this->response(array(
                        'status' => FALSE,
                        'message' => "Error while cancel subscription" ) , REST_Controller::HTTP_OK);
            }
        }else{
                 $this->response(array(
                        'status' => TRUE,
                        'message' => "you are not subscribed user" ) , REST_Controller::HTTP_OK);
        }


    }


     /**
    * Check user is premium or not
    * @param $users_id 
    * @return response json array
    *
    */
    function checkuserCredits_get(){

        $users_id = $this->get('users_id');

        $user = $this->Users_model->get($users_id);

        if($user){

        $premium_status = $user->premium_status;    
        if($premium_status=='1'){
        $freetrial_start_date = date('Y-m-d',strtotime($user->freetrial_start_date));        
        $freetrial_end_date = date('Y-m-d',strtotime($user->freetrial_end_date));        
        $date = date('Y-m-d');
        $is_trial = '0';
        if (($date > $freetrial_start_date) && ($date < $freetrial_end_date)){
            $is_trial = '1';
        }
    }else{
        $is_trial = '0';
    }

    if($user->premium_trial_used==""){
        $is_trial_used = "0";
    }else{
        $is_trial_used = $user->premium_trial_used;
    }

        $credits = ($user->total_credits + $user->weekly_credits);        

         $this->response(array(
                    'status' => TRUE,
                    'is_trial'=>$is_trial,
                    'premium_status'=>$premium_status,
                    'is_trial_used'=>$is_trial_used,
                    'credits'=>$credits) , REST_Controller::HTTP_OK);
        }else{
             $this->response(array(
                    'status' => FALSE,                    
                    'message' => "User not found" ) , REST_Controller::HTTP_OK);
        }
    }


    /**
    * Check user exists or not
    * @param $id user id
    * @return bool
    */
    public function checkuserId($id){
        $result = $this->Users_model->get(['users_id' => $id,
                                            'users_status'=>'1'
                                            ]);
        if ($result) {
            return TRUE;
        }
        else {
            return FALSE;
        }
    }


    

    /**     
    * CRON JOB functions for every day run at midnight for expiring a subscription
    * @param kai kam lagtu nathi
    * @return response in json array
    */
    function dailyDebits_get(){
        error_reporting(E_ALL);
        ini_set('display_errors',1);
        // get all user info to expired 7 day credits
       $res = [];
        $wallet_user = $this->wallet_balance_model->getWalletdata();

        $this->wallet_balance_model->freeTrialExpired();

        /* visit more profile expired data update */
        $date  = date('Y-m-d');
      
        $this->db->where(["visits_expired_date < "=>$date,'get_more_visits'=>'1']);
        $promoted_users =  $this->Users_model->get_all();
        if(!empty($promoted_users)){
            foreach (@$promoted_users as $rows) {
                $promoted_users_id = $rows->promoted_users_id;
                $this->db->where(['promoted_users_id'=>$promoted_users_id]);
                $this->db->delete('promoted_users');            
            }
        }
       
       $data = ['get_more_visits'=>'0','visits_expired_date'=>''];

         $this->db->where(["visits_expired_date < "=>$date,'get_more_visits'=>'1']);
        $update =  $this->Users_model->update($data);

        /* visit more profile update end */

        // more matches expired 
        $data = ['more_matches_status'=>'0','matches_expired_date'=>''];
        $date  = date('Y-m-d');
        $this->db->where(["matches_expired_date < "=>$date,'more_matches_status'=>'1']);
        $update =  $this->Users_model->update($data);

        // move to the top expired 
        $data = ['move_to_top'=>'0','move_top_expired_date'=>''];        
        $date  = date('Y-m-d');
        $this->db->where(["move_top_expired_date < "=>$date,'move_to_top'=>'1']);
        $update =  $this->Users_model->update($data);
               

        if(!empty($wallet_user)){
        foreach (@$wallet_user as $rows) {

            $weekly_credits = $rows->weekly_credits;

            $users_id = $rows->users_id;

            $user_data  =   [  
                                'premium_status'=>'0',
                                'weekly_credits' => '0'                       
                            ];

            // updating purchased credits 
            $updated    = $this->Users_model->update($user_data,$users_id);

            $this->db->order_by('wallet_id','DESC');
            $wallet = $this->wallet_balance_model->where(['users_id'=>$users_id])->get();

            if($wallet->total_credits > $weekly_credits){
                $total_credits = ($wallet->total_credits - $weekly_credits); 
            }else{
                $total_credits = ($weekly_credits - $wallet->total_credits); 
            }
            $data       =   [   
                                'users_id' =>$users_id,
                                'debit_value'=>$weekly_credits,
                                'use_for'=>$this->lang->line('daily_expired'),                    
                                'debit_date'=>date('Y-m-d H:i:s'), 
                                'type'=>'debit',                   
                                'total_credits'=>$total_credits
                            ];

        // added data into wallet balance to track the credits and it uses
            @$res[] = $this->wallet_balance_model->insert($data);
            $data = json_encode($data);
            $myfile = fopen("cronjob.txt", "w") or die("Unable to open file!");
            $txt = $data;
            fwrite($myfile, $txt);
            fclose($myfile);
          
        }
        }else{
            $file = fopen("test.txt","w");
            fwrite($file,"Hello World. Testing!");
            fclose($file);
        }

        /*if(@$res){
             $this->response(array(
                    'status' => TRUE,
                    'message' => "Credits expired successfully" ) , REST_Controller::HTTP_OK);
        }*/
        /*var_dump(@$res);
            exit;*/

    }
    
   
    
}