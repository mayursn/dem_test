<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . '/libraries/REST_Controller.php';

class Preference extends REST_Controller

{
    
    /**
     * Constructor
     *
     *  @return void
     */
    public function __construct(){
        parent::__construct();
        $this->load->model('Users_model');        
        $this->load->model('Preference_master_model');        
        $this->load->model('Preferences_model');   
        $this->load->model('Location_model');   
        
        $this->load->model('User_preference_model');        
        $this->lang->load('message', 'english');

    }


   public function setPreferences_post() {

        $preferences = $this->post('preferences');
        $users_id = $this->post('users_id');
        $preferencesList = json_decode($preferences);
        $height = $this->post('height');
        $from_age = $this->post('from_age');
        $to_age = $this->post('to_age');
        $latitude = $this->post('latitude');        
        $longitude = $this->post('longitude');
        $self_summery = $this->post('self_summery');
        $city = $this->post('city');
        $country = $this->post('country');

        $city_id = "";
        $country_id = "";
        



        if(!$this->checkuserId($users_id)){
                    
          $this->response(['status' => FALSE,'message' => 'User not found'], REST_Controller::HTTP_OK); // response
        }


        $userInfo = $this->Users_model->get($users_id);
        if($userInfo->is_social=='0'){
            if ($this->form_validation->run('setPreferences') == false) {

                $error = strip_tags(validation_errors());
                     $this->response(['status' => FALSE,'message' => $error], REST_Controller::HTTP_OK); // response


            }
        }
        

        $data =  "";
        $prefupdate = [];

         if(isset($_POST['mobile']) && $_POST['mobile']!="" && $_POST['country_code']!=""){
            $mobile = $_POST['mobile'];
            $get_user = $this->Users_model->where(['users_mobile'=>$mobile,'users_id != '=>$users_id])->get();
           
            if($get_user){
                $error = $mobile." this mobile number is already exists!";
                 $this->response(['status' => FALSE,'message' =>$error], REST_Controller::HTTP_OK); // response
            }else{
                $prefupdate['users_mobile'] = $mobile;
                $prefupdate['country_code'] = $_POST['country_code'];
            }
        }else{
            $error = "Enter Mobile Number";
            $this->response(['status' => FALSE,'message' =>$error], REST_Controller::HTTP_OK); // response
        }


        if($preferencesList) {
            /*echo "<pre>";
            print_r($preferencesList);
            exit;*/
            foreach ($preferencesList as $key => $value) {
                
                if($value->preferences_option_id > 0 || $value->preferences_option_id!="") {
                    $preference_id = $value->preference_id;

                    $preferences_option_id = $value->preferences_option_id;                   

                    $checkPreferenceOption = $this->checkPreferenceOption($preferences_option_id);
                    
                    if($checkPreferenceOption){
                    
                    $checkpreference = $this->checkPreferences($preference_id,$users_id);
                   

                        if($checkpreference){
                            $user_preference_id = $checkpreference->user_preference_id;

                            

                            $data = $this->User_preference_model->update([
                                                            'preference_id' => $preference_id,
                                                            'preference_option_id'=>$preferences_option_id
                                                         ],$user_preference_id);
                        }
                        else{

                            $data = $this->User_preference_model->insert([
                                                            'preference_id' => $preference_id,
                                                            'preference_option_id'=>$preferences_option_id,
                                                            'users_id'=>$users_id
                                                         ]);

                        } // end else check preferences 

                        
                    }   // end check preference option exists or not

                       if($preference_id==1) {
                                
                                $prefupdate['users_gender'] = $this->getPreferenceOption($preferences_option_id);
                                
                                
                            }
                            if($preference_id==2) {
                                $prefupdate['looking_for'] = $this->getPreferenceOption($preferences_option_id);
                            }
                } // end check preference option value 0 or not empty

            } // end foreach



            // update looking for option if gender or orientation changed
//            $list = $this->User_preference_model->orientation($users_id);
//            
//            $gender = $list[0]->option_title;
//            $orientation = $list[1]->option_title;            
//            $title = orientationgender($orientation,$gender);


            if($height!=""){
                $prefupdate['users_height'] = $height;
            }

            if($from_age!="" && $to_age!=""){
                $prefupdate['from_age'] = $from_age;
                $prefupdate['to_age'] = $to_age;
            }

            if($latitude!="" && $longitude){
                $prefupdate['users_latitude'] = $latitude;
                $prefupdate['users_longitude'] = $longitude;
            }

            if($self_summery){
                
                $prefupdate['about'] = $self_summery;
            }

            if($city!=""){
            $this->db->where("name",$city);
            $city_id = $this->Location_model->get()->location_id;
                if(!empty($city_id)){
                    $prefupdate['users_location'] =$city_id;
                }
             }

             if($country!=""){
                $this->db->where("name",$country);
                $country_id = $this->Location_model->get()->location_id;
                if(!empty($country_id)){
                    $prefupdate['country'] =$country_id;
                }
            
             }
            /*$firstname = $this->post('firstname');
            $lastname = $this->post('lastname');
            $birthdate = $this->post('birthdate');*/
            if(isset($_POST['firstname']) && isset($_POST['lastname'])){
                $prefupdate['users_fname'] =$_POST['firstname'];
                $prefupdate['users_lname'] =$_POST['lastname'];
            }
            if(isset($_POST['dob'])){
                $prefupdate['users_dob'] = $_POST['dob'];
                $prefupdate['users_age'] = $this->age($_POST['dob']);
            }

            
            if(!empty($prefupdate))
            {
                $this->Users_model->update($prefupdate,$users_id);
            }
            
        }

        if($data){
                    $this->response(array(
                            'status' => TRUE,
                            'message' => 'Preference set successfully'
                        ) , REST_Controller::HTTP_OK);
        }
        else{
                    $this->response(array(
                            'status' => FALSE,
                            'message' => 'Problem while set preferences!'
                        ) , REST_Controller::HTTP_OK);   
        }
      
    }


    function checkPreferences($preference_id,$users_id){
       return $this->User_preference_model->get([
                                                'preference_id' => $preference_id,
                                                'users_id'=>$users_id
                                             ]);
    }


     /**
    * Age Calculation using date of birth
    * @param $birthdate 
    * @return age int
    */
    public function age($birthdate){
        if($birthdate){
            $from = new DateTime($birthdate);
            $to   = new DateTime('today');
            return $from->diff($to)->y;
        }
    }


    public function preferenceList_get(){
        $users_id = $this->get('users_id');
        if($this->get('users_id')){
        $preference_master = $this->Preference_master_model
            ->fields('preference_id,preference_name')
            ->with_preferences('fields:preferences_option_id,option_title')
            ->get_all();

        $user = $this->Users_model->fields('users_fname,users_lname,users_dob,users_height,from_age,to_age,users_latitude,users_longitude,about as self_summery,users_mobile,country_code')->get(['users_id'=>$users_id]);    

        if($user->users_mobile!=""){

            $users_mobile = $user->users_mobile;

        }else{

            $users_mobile = "";

        }
        if($user->country_code!=""){

            $country_code = $user->country_code;            

        }else{

            $country_code = "";

        }

        if($user->users_height!=""){

            $height = $user->users_height;

        }else{

            $height = "0";

        }
        if($user->self_summery!=""){

            $self_summery = $user->self_summery;

        }else{

            $self_summery = "";

        }
        if($user->users_latitude!=""){

            $latitude = $user->users_latitude;

        }else{

            $latitude = "";
            
        }
        if($user->users_longitude!=""){
            $longitude = $user->users_longitude;
        }else{
            $longitude = "";
        }
        if($user->to_age!=""){
            $to_age = $user->to_age;
        }else{
            $to_age = "0";
        }
        if($user->from_age!=""){
            $from_age = $user->from_age;
        }else{
            $from_age = "0";
        }

         if($user->users_fname!=""){
            $users_fname = $user->users_fname;
        }else{
            $users_fname = "";
        }
        if($user->users_lname!=""){
            $users_lname = $user->users_lname;
        }else{
            $users_lname = "";
        }

        if($user->users_dob!=""){
            $users_dob = $user->users_dob;
        }else{
            $users_dob = "";
        }
         
        

            foreach ($preference_master as $rows) {
                            $pref = $this->User_preference_model->get([
                                                    'users_id'=>$users_id,
                                                    'preference_id'=>$rows->preference_id
                                                    ]);

                        if($pref){
                            $rows->selected = $pref->preference_option_id;
                        }
                        else{
                            $rows->selected = 0;
                        }

                        if($rows->selected==""){
                            $rows->selected = 0;   
                        }
             }
        
        // $preference_master['height'] = $height;
            
             //$arr = array_map('utf8_encode', $arr);
             //echo json_encode($arr);             
       $this->response(array(
                    'status' => TRUE,
                    'message' => 'Preference List',
                    'allpref' => $preference_master,
                    'height'=>$height,
                    'from_age'=>$from_age,
                    'to_age'=>$to_age,
                    'latitude'=>$latitude,                   
                    'longitude'=>$longitude,
                    'users_fname'=>$users_fname,
                    'users_lname'=>$users_lname,
                    'users_dob'=>$users_dob,
                    'self_summery'=>$self_summery,
                    'country_code'=>$country_code,
                    'users_mobile'=>$users_mobile
                ) , REST_Controller::HTTP_OK);
        }else{
         $this->response(array(
                    'status' => FALSE,
                    'message' => 'Something went wrong!'
                ) , REST_Controller::HTTP_OK);   
        }
    }


    /**
    * Check user exists or not
    * @param $id user id
    * @return bool
    */
    public function checkuserId($id)
    {
        $result = $this->Users_model->get(['users_id' => $id,
                                            'users_status'=>'1'
                                            ]);
        if ($result) {
            return TRUE;
        }
        else {
            return FALSE;
        }
    }


    /**
    * Check user exists or not
    * @param $id user id
    * @return bool
    */
    public function checkPreferenceOption($id)
    {
        $result = $this->Preferences_model->get(['preferences_option_id' => $id]);
        if ($result) {
            return TRUE;
        }
        return FALSE;
    }
    
    /**
    * Check user exists or not
    * @param $id user id
    * @return bool
    */
    public function getPreferenceOption($id)
    {
        $result = $this->Preferences_model->get($id);
        if ($result) {
            return $result->option_title;
        }
        
        return null;
    }




}