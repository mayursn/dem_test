<?php
defined('BASEPATH') OR exit('No direct script access allowed ');

/**
* Filter option parameter Controller 
* Get all the preferences with their option for filter api
* Path Controllers/api
* filename FilterOption.php
*/


require APPPATH . '/libraries/REST_Controller.php';

class FilterOption extends REST_Controller{

    function __construct() {

        parent::__construct(); 

        $this->load->model('Users_model');
        $this->load->model('Preference_master_model');
        $this->load->model('Preferences_model');
        $this->load->model('User_preference_model');
        $this->load->model('Filter_preference_model');
        

    }


    /**
    * Looks filter option parameter 
    * @return response
    */
    function looks_get(){

        $users_id = $this->get("users_id");
        if(!$this->checkuserId($users_id)){
            $this->response(array(
                'status' => FALSE,
                'message' => 'User not found'
            ) , REST_Controller::HTTP_OK);
        }


        $users = $this->Users_model->fields("saved_height")->get($users_id);

        $saved_height = $users->saved_height;

        if(!empty($saved_height)){

        $height = explode("To", $saved_height);

            $from_height    = $height[0];
            $to_height      = $height[1];

        }else{

            $from_height    = "";
            $to_height      = "";

        }


        $this->db->where('preference_id','3');        
        $preference_master = $this->Preference_master_model
            ->fields('preference_id,preference_name')
            ->with_preferences('fields:preferences_option_id,option_title')
            ->get_all();

        $preferences = $this->Filter_preference_model->get(['users_id'=>$users_id,"preference_id"=>'3']);

            if(!empty($preferences->saved_option)){

                $preferences->saved_option = explode(",", $preferences->saved_option);

            }
            else{

                $preferences->saved_option = "";
            }

        foreach ($preference_master as $key => $value) {

            
                foreach ($value->preferences as $key => $values) {
                           
                    $preferences_option_id = $values->preferences_option_id;

                    if($preferences->saved_option!=""){

                        if(in_array($preferences_option_id, $preferences->saved_option)){

                            $value->preferences[$key]->selected = "1";

                        }else{

                            $value->preferences[$key]->selected = "0";                        
                        }        
                                  
                    }else{

                             $value->preferences[$key]->selected = "0";
                    }

                }
        }
      
        
        $this->response(array(
                'status' => TRUE,
                'message' => 'Looks preferences',                
                'body_type'=>$preference_master,
                "from_height"=>$from_height,
                "to_height"=>$to_height
            ) , REST_Controller::HTTP_OK);

    }


    /**
    * Looks filter option parameter preferences 
    * @return response
    *
    */
    function background_get(){

        $users_id = $this->get("users_id");

        if(!$this->checkuserId($users_id)){
            $this->response(array(
                'status' => FALSE,
                'message' => 'User not found'
            ) , REST_Controller::HTTP_OK);
        }

        $this->db->where('preference_id','4');
        $ethnicity = $this->Preference_master_model
            ->fields('preference_id,preference_name')
            ->with_preferences('fields:preferences_option_id,option_title')
            ->get_all();

        $preferences = $this->Filter_preference_model->get(['users_id'=>$users_id,"preference_id"=>'4']);
            if(!empty($preferences->saved_option)){
                $preferences->saved_option = explode(",", $preferences->saved_option);
            }
            else{
                $preferences->saved_option = "";
            }

        foreach ($ethnicity as $key => $value) {

            
                foreach ($value->preferences as $key => $values) {
                           
                    $preferences_option_id = $values->preferences_option_id;
                    if($preferences->saved_option!=""){

                        if(in_array($preferences_option_id, $preferences->saved_option)){

                            $value->preferences[$key]->selected = "1";

                        }else{

                            $value->preferences[$key]->selected = "0";                        
                        }            

                    }else{

                             $value->preferences[$key]->selected = "0";
                    }

                }
        }    



        $this->db->where('preference_id','5');
        $religion = $preference_master = $this->Preference_master_model
            ->fields('preference_id,preference_name')
            ->with_preferences('fields:preferences_option_id,option_title')
            ->get_all();


        $preferences = $this->Filter_preference_model->get(['users_id'=>$users_id,"preference_id"=>'5']);
            if(!empty($preferences->saved_option)){
                $preferences->saved_option = explode(",", $preferences->saved_option);
            }
            else{
                $preferences->saved_option = "";
            }

            foreach ($religion as $key => $value) {

                
                    foreach ($value->preferences as $key => $values) {
                               
                        $preferences_option_id = $values->preferences_option_id;
                        if($preferences->saved_option!=""){
                            if(in_array($preferences_option_id, $preferences->saved_option)){
                                $value->preferences[$key]->selected = "1";

                            }else{
                                $value->preferences[$key]->selected = "0";                        
                            }                  
                        }else{

                                 $value->preferences[$key]->selected = "0";
                        }

                    }
            }    



         $this->db->where('preference_id','10');
        $languages = $this->Preference_master_model
            ->fields('preference_id,preference_name')
            ->with_preferences('fields:preferences_option_id,option_title')
            ->get_all();


             $preferences = $this->Filter_preference_model->get(['users_id'=>$users_id,"preference_id"=>10]);
            if(!empty($preferences->saved_option)){
                $preferences->saved_option = explode(",", $preferences->saved_option);
            }
            else{
                $preferences->saved_option = "";
            }

            foreach ($languages as $key => $value) {

                
                    foreach ($value->preferences as $key => $values) {
                               
                        $preferences_option_id = $values->preferences_option_id;
                        if($preferences->saved_option!=""){
                            if(in_array($preferences_option_id, $preferences->saved_option)){
                                $value->preferences[$key]->selected = "1";

                            }else{
                                $value->preferences[$key]->selected = "0";                        
                            }                  
                        }else{

                                 $value->preferences[$key]->selected = "0";
                        }

                    }
            } 
            

        $this->response(array(
                'status' => TRUE,
                'message' => 'Background preferences',
                'ethnicity'=>$ethnicity,
                'religion'=>$religion,
                'languages'=>$languages
            ) , REST_Controller::HTTP_OK);

    }


    /**
    * Avaibility preferences options
    * @return reponse
    * 
    */
    function availability_get(){

        $users_id = $this->get("users_id");
        if(!$this->checkuserId($users_id)){
            $this->response(array(
                'status' => FALSE,
                'message' => 'User not found'
            ) , REST_Controller::HTTP_OK);
        }

        $this->db->where('preference_id','6');
        $status = $preference_master = $this->Preference_master_model
            ->fields('preference_id,preference_name')
            ->with_preferences('fields:preferences_option_id,option_title')
            ->get_all();

              $preferences = $this->Filter_preference_model->get(['users_id'=>$users_id,"preference_id"=>'6']);
            if(!empty($preferences->saved_option)){
                $preferences->saved_option = explode(",", $preferences->saved_option);
            }
            else{
                $preferences->saved_option = "";
            }

            foreach ($status as $key => $value) {

                
                    foreach ($value->preferences as $key => $values) {
                               
                        $preferences_option_id = $values->preferences_option_id;
                        if($preferences->saved_option!=""){
                            if(in_array($preferences_option_id, $preferences->saved_option)){
                                $value->preferences[$key]->selected = "1";

                            }else{
                                $value->preferences[$key]->selected = "0";                        
                            }                  
                        }else{

                                 $value->preferences[$key]->selected = "0";
                        }

                    }
            } 

            $this->response(array(
                'status' => TRUE,
                'message' => 'Availability preferences',
                'preference'=>$status
            ) , REST_Controller::HTTP_OK);

    }


    /**
    * Vices preferences options
    * @return reponse
    * 
    */
    function vices_get(){

        $users_id = $this->get("users_id");
        if(!$this->checkuserId($users_id)){
            $this->response(array(
                'status' => FALSE,
                'message' => 'User not found'
            ) , REST_Controller::HTTP_OK);
        }

        $this->db->where('preference_id','7');
        $drinking = $preference_master = $this->Preference_master_model
            ->fields('preference_id,preference_name')
            ->with_preferences('fields:preferences_option_id,option_title')
            ->get_all();


          $preferences = $this->Filter_preference_model->get(['users_id'=>$users_id,"preference_id"=>'7']);
            if(!empty($preferences->saved_option)){
                $preferences->saved_option = explode(",", $preferences->saved_option);
            }
            else{
                $preferences->saved_option = "";
            }

            foreach ($drinking as $key => $value) {

                
                    foreach ($value->preferences as $key => $values) {
                               
                        $preferences_option_id = $values->preferences_option_id;
                        if($preferences->saved_option!=""){
                            if(in_array($preferences_option_id, $preferences->saved_option)){
                                $value->preferences[$key]->selected = "1";

                            }else{
                                $value->preferences[$key]->selected = "0";                        
                            }                  
                        }else{

                                 $value->preferences[$key]->selected = "0";
                        }

                    }
            } 


        


            $this->db->where('preference_id','8');
            $drugs = $preference_master = $this->Preference_master_model
            ->fields('preference_id,preference_name')
            ->with_preferences('fields:preferences_option_id,option_title')
            ->get_all();


              $preferences = $this->Filter_preference_model->get(['users_id'=>$users_id,"preference_id"=>'8']);
            if(!empty($preferences->saved_option)){
                $preferences->saved_option = explode(",", $preferences->saved_option);
            }
            else{
                $preferences->saved_option = "";
            }

        foreach ($drugs as $key => $value) {

            
                foreach ($value->preferences as $key => $values) {
                           
                    $preferences_option_id = $values->preferences_option_id;
                    if($preferences->saved_option!=""){
                        if(in_array($preferences_option_id, $preferences->saved_option)){
                            $value->preferences[$key]->selected = "1";

                        }else{
                            $value->preferences[$key]->selected = "0";                        
                        }                  
                    }else{

                             $value->preferences[$key]->selected = "0";
                    }

                }
        } 



            $this->db->where('preference_id','9');
        $smoking = $preference_master = $this->Preference_master_model
            ->fields('preference_id,preference_name')
            ->with_preferences('fields:preferences_option_id,option_title')
            ->get_all();

        $preferences = $this->Filter_preference_model->get(['users_id'=>$users_id,"preference_id"=>'9']);

            if(!empty($preferences->saved_option)){
                $preferences->saved_option = explode(",", $preferences->saved_option);
            }
            else{
                $preferences->saved_option = "";
            }

        foreach ($smoking as $key => $value) {

            
                foreach ($value->preferences as $key => $values) {
                           
                    $preferences_option_id = $values->preferences_option_id;
                    if($preferences->saved_option!=""){
                        if(in_array($preferences_option_id, $preferences->saved_option)){
                            $value->preferences[$key]->selected = "1";

                        }else{
                            $value->preferences[$key]->selected = "0";                        
                        }                  
                    }else{

                             $value->preferences[$key]->selected = "0";
                    }

                }
        } 

            $this->response(array(
                'status' => TRUE,
                'message' => 'Vices preferences',
                'drinking'=>$drinking,
                'drugs'=>$drugs,
                'smoking'=>$smoking
            ) , REST_Controller::HTTP_OK);

    }



    /**
    * Check user exists or not
    * @param $id user id
    * @return bool
    */
    public function checkuserId($id){
        $result = $this->Users_model->get(['users_id' => $id,
                                            'users_status'=>'1'
                                            ]);
        if ($result) {
            return TRUE;
        }
        else {
            return FALSE;
        }
    }


    /**
    * Apply filter option save api All the preferences set
    * @param parameter preference_id, Option_id
    * @return response selected preferences
    */

    public function applyFilter_post(){

        $from_height        = $this->post('from_height'); 

        $to_height          = $this->post('to_height');

        $users_id           = $this->post('users_id'); // loggedin user id (app)

        $preferences        = $this->post('preferences'); // json encoded object

        $preferences = json_decode($preferences);

        if($from_height!="" && $to_height!=""){

            $height = $from_height."To".$to_height;

            $this->Users_model->update(["saved_height"=>$height],$users_id);

        }
          
        if(!empty($preferences))  {

            foreach ($preferences as $value) {

                $preference_id = $value->preference_id;

                $userpref = $this->Filter_preference_model->get(['users_id'=>$users_id,'preference_id'=>$preference_id]);

                $pref = $value->preferences;


                $option = [];

                if(!empty($pref)){

                    foreach ($pref as $key => $values) {

                        $option[] = $values->preferences_option_id;
            
                    }
                   
                    if(!empty($option)){

                    $options = implode(",", $option);
 
                    }else{

                        $options = "";

                    }

                    if(!empty($options)){
                        if($userpref){

                            $filter_id = $userpref->filter_id;
//                            if($preference_id == 10) {
//                                echo $options;
//echo $filter_id; die;
//                            }
                            $this->Filter_preference_model->update(['preference_id'=>$preference_id,"saved_option"=>$options],$filter_id);

                        }else{
                            
                            $this->Filter_preference_model->insert(['users_id'=>$users_id,'preference_id'=>$preference_id,"saved_option"=>$options]);
                        }

                    }

                }else{
                         if($userpref){

                         $filter_id = $userpref->filter_id;

                            $this->Filter_preference_model->update(['preference_id'=>$preference_id,"saved_option"=>""],$filter_id);

                        }else{

                             $this->Filter_preference_model->insert(['users_id'=>$users_id,'preference_id'=>$preference_id,"saved_option"=>""]);

                        }
                }

           }

        }

        //$this->reset($users_id);

        _trackUser(TRUE, 'User reset filter option', TRUE, $users_id); // user logs

        $this->response(array(
                'status' => TRUE,
                'message' => 'User reset filter option'
            ) , REST_Controller::HTTP_OK);
       
    }


     /**
     * Reset Dislike user
     * @param users_id
     * @return response
     */
    public function reset($users_id)
    {
        $this->load->model('Users_like_model');        
        $this->db->where('users_id', $users_id);
        $this->db->where('like_status', '0');
        $response = $this->Users_like_model->delete();

    }

    /**
    * More & Advanced preferences options
    * @return reponse
    * 
    */
    function more_get(){
        $users_id = $this->get("users_id");

        $ignore = ["1","2","3","4","5","6","7","8","9","10"];
        $this->db->where_not_in("preference_id",$ignore);
        $more = $preference_master = $this->Preference_master_model
            ->fields('preference_id,preference_name')
            ->with_preferences('fields:preferences_option_id,option_title')
            ->get_all();

         
 
          foreach ($more as $key => $value) {
                            $preference_id = $value->preference_id;
                            $this->db->where("preference_id",$preference_id);
                            $this->db->where('users_id',$users_id);
                    $preferences = $this->Filter_preference_model->get();
                    if(!empty($preferences->saved_option)){
                        $preferences->saved_option = explode(",", $preferences->saved_option);
                    }
                    else{
                        $preferences->saved_option = "";
                    }
                    foreach ($value->preferences as $key => $values) {
                               
                        $preferences_option_id = $values->preferences_option_id;
                        if($preferences->saved_option!=""){
                            if(in_array($preferences_option_id, $preferences->saved_option)){
                                $value->preferences[$key]->selected = "1";

                            }else{
                                $value->preferences[$key]->selected = "0";                        
                            }                  
                        }else{

                                 $value->preferences[$key]->selected = "0";
                        }

                    }
            }
            
        $this->response(array(
                'status' => TRUE,
                'message' => 'More preferences',
                'more'=>$more
            ) , REST_Controller::HTTP_OK);


    }

   /* function more_get(){
        $users_id = $this->get("users_id");
        $ignore = ["1","2","3","4","5","6","7","8","9","10"];
        $this->db->where_not_in("preference_id",$ignore);
       $more = $preference_master = $this->Preference_master_model
            ->fields('preference_id,preference_name')
            ->with_preferences('fields:preferences_option_id,option_title')
            ->get_all();


            $preferences = $this->Filter_preference_model->get(['users_id'=>$users_id,"preference_id"=>'9']);
        
            if(!empty($preferences->saved_option)){
                $preferences->saved_option = explode(",", $preferences->saved_option);
            }
            else{
                $preferences->saved_option = "";
            }

        foreach ($more as $key => $value) {

            
                foreach ($value->preferences as $key => $values) {
                           
                    $preferences_option_id = $values->preferences_option_id;
                    if($preferences->saved_option!=""){
                        if(in_array($preferences_option_id, $preferences->saved_option)){
                            $value->preferences[$key]->selected = "1";

                        }else{
                            $value->preferences[$key]->selected = "0";                        
                        }                  
                    }else{

                             $value->preferences[$key]->selected = "0";
                    }

                }
        } 


        $this->response(array(
                'status' => TRUE,
                'message' => 'More preferences',
                'more'=>$more
            ) , REST_Controller::HTTP_OK);


    }*/


    



}