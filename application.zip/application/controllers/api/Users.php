<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . '/libraries/REST_Controller.php';

class Users extends REST_Controller

{
    
    /**
     * Constructor
     *
     *  @return void
     */

    /**
    * At the end of file resetDislikeUser function which cron job function
    * below is cron job path
    * /usr/local/bin/php -f /home/pr01004/public_html/index.php api/users resetDislikeUser   Edit
    */
    public function __construct(){

        parent::__construct();        
        $this->load->model('Users_model');                
        $this->load->model('User_images_model'); 
        $this->load->model('User_interest_model');    
        $this->load->model("Location_model");     
        $this->load->model('User_preference_model');
        $this->load->model('Preferences_model');
        $this->lang->load('message', 'english');

    }



    /**
    * Signup with email
    * 
    */

    public function register_post(){

        if ($this->form_validation->run('register') == true) {

            $email = $_POST['email'];

            $userInfo = $this->Users_model->get(['users_email'=>$email]);
            if($userInfo){

                if($userInfo->is_social==1){
                    $errors = "Seems you have used Facebook for login. Please try login using facebook account";
                    $this->response(['status' => FALSE, 'message' => $errors,'is_registered'=>'0'], REST_Controller::HTTP_OK); // OK
                }

                if ($userInfo->users_status=='0') {
                        //temporary inactive
                        $error = $_POST['email'] . " email is temporary deactived by the Admin.";
                          $this->response(['status' => FALSE, 'message' => $error,'is_login'=>'0'], REST_Controller::HTTP_OK); // OK
                    }
                if ($userInfo->is_deleted == 1) {
                        //temporary inactive
                        $error = $_POST['email'] . " email is temporary suspended by the Admin.";
                          $this->response(['status' => FALSE, 'message' => $error,'is_login'=>'0'], REST_Controller::HTTP_OK); // OK
                }

                $errors = $_POST['email']." email is already exists";
                   $this->response(['status' => FALSE, 'message' => $errors,'is_registered'=>'0'], REST_Controller::HTTP_OK); // OK
            }

            $password = $this->_hash($_POST['password']);
            $firstname = $_POST['firstname'];
            $lastname = $_POST['lastname'];
            $device_type = $_POST['device_type'];
            $device_token = $_POST['device_token'];
            $latitude = $_POST['latitude'];
            $longitude = $_POST['longitude'];            
            $city = $this->post('city');
            $country = $this->post('country');
            $city_id = "";
            $country_id = "";

            $data =  ['users_email'=>$email,
                      'users_fname'=>$firstname,
                      'users_lname'=>$lastname,
                      'users_password'=>$password,
                      'users_status'=>'1',
                      'is_social'=>'0',
                      'users_latitude'=>$latitude,
                      'users_longitude'=>$longitude,
                      'device_token'=>$device_token,
                      'device_type'=>$device_type
                      ];
              if($city!=""){
            $this->db->where("name",$city);
            $city_id = $this->Location_model->get()->location_id;
                if(!empty($city_id)){
                    $data['users_location'] =$city_id;
                }
             }

             if($country!=""){
                $this->db->where("name",$country);
                $country_id = $this->Location_model->get()->location_id;
                if(!empty($country_id)){
                    $data['country'] =$country_id;
                }
            
             }

             // premium trial 14 days information 
            /*$premium_trial_date = date('Y-m-d');
            $trial_end_date = date('Y-m-d',strtotime($premium_trial_date. ' + 14 days'));*/
            //$data['subscribe_type'] = '0'; # 0:free user 1:premium user
            $data['premium_status'] = '0'; # 0:free 1: premium subscribed
            /*$data['premium_start_date'] = $premium_trial_date;
            $data['premium_end_date'] = $trial_end_date;*/
            // end

           $user_id = $this->Users_model->insert($data);
           $subject = "Snack Dating app";
           $message = "Hello ".$firstname." ".$lastname."<br>";
           $message .= "Thank you for register with Snack Dating app";
            $this->sendmail($email,$subject,$message);
            $user = $this->Users_model->fields('users_fname,users_lname,users_dob,users_gender,is_social')->get($user_id);
            $infoCompleted = checkComplited($user);
            _trackUser(TRUE, 'User successfully registered.', TRUE, $user_id);
            $this->response(['status' => TRUE,  'message' => 'User successfully registered.','is_registered'=>'0','users_id' => $user_id,'infocompleted'=>$infoCompleted], REST_Controller::HTTP_OK); // OK (200) Reponse code
             // user logs
            
        }else{            


            $errors = validation_errors();
            $errors = strip_tags($errors);
            $this->response(['status' => FALSE, 'message' => $errors,'is_registered'=>'0'], REST_Controller::HTTP_OK); // OK
           // user logs
        }

    }

    /**
    * Login in with email & password
    * @param $email, $password
    *
    */
    public function login_post(){

         if ($_POST) {
            
            //validation
            if ($this->form_validation->run('login') == false) {
                $errors = validation_errors();
                $errors = strip_tags($errors);
                $this->response(['status' => FALSE, 'message' => $errors,'is_login'=>'0'], REST_Controller::HTTP_OK); // OK

            } else {

                $email = $this->input->post('email', true);
                $password = $this->_hash($this->input->post('password', true));

                $user = $this->Users_model->get(['users_email'=>$email,'users_password'=>$password]);
                

                if ($user) {
                    $users_id = $user->users_id;
                    //check for status
                    
                    if ($user->users_status=='2') {
                        //temporary inactive
                        $error = $_POST['email'] . " email is temporary deactived by the Admin.";
                          $this->response(['status' => FALSE, 'message' => $error,'is_login'=>'0'], REST_Controller::HTTP_OK); // OK
                    }
                    if ($user->is_deleted == 1) {
                        //temporary inactive
                        $error = $_POST['email'] . " email is temporary suspended by the Admin.";
                          $this->response(['status' => FALSE, 'message' => $error,'is_login'=>'0'], REST_Controller::HTTP_OK); // OK
                    }

                    $this->Users_model->update(['is_online'=>'1','users_status'=>'1','is_signout'=>'0'],$users_id);
                    
                    $incomplited = checkComplited($user);
                    $discovery = 0;
                    if($user->discovery==1){
                        $discovery = 1;
                    }
                   $this->response(['status' => TRUE, 'message' => 'User logged in successfully','users_id'=>$users_id,'infocompleted'=>$incomplited,'discovery'=>$discovery], REST_Controller::HTTP_OK); // OK
                    
                } else {
                    // Invalid username or password
                     $error = "Invalid Email or password";
                    $this->response(['status' => FALSE, 'message' => $error,'is_login'=>'0'], REST_Controller::HTTP_OK); // OK
                }
            }
        }
    }


    


    /**
    * Get user listing based on match
    * @return response array
    */

    public function list_get()
    {
      
        if (count($_GET)) {
            $is_avail = $this->Users_model->get_all();
            $is_avail = $this->db->get('logs')->result();
            $id = $this->input->get('id');
            if ($is_avail) {
                  _trackUser(TRUE, 'User List view!', TRUE, $id); // user logs
                $this->response(array(
                    'status' => TRUE,
                    'message' => 'User Found!',
                    'users' => $is_avail,
                ) , REST_Controller::HTTP_OK);
              
            }
        }
        // $this->_log_request(TRUE);
    }


    /**
    * User Signup Process using facebook token
    * @return $this->response api response success or failed
    */

    public function signup_post()
    {
        
        $fbtoken = $_POST['fbtoken'];
        
        $email = trim($this->post('email'));

        $user = $this->Users_model->get(['users_email'=>$email,'is_social'=>'0']);
        if($user){

          $this->response(['status' => FALSE, 'message' => 'Seems you have already used this Email. Please try login using Email & password','is_registered'=>'0'], REST_Controller::HTTP_OK); // OK
        }
           // user logs
        
        if ($this->form_validation->run('signup') == false) {
          $this->response(['status' => FALSE, 'message' => validation_errors(),'is_registered'=>'0'], REST_Controller::HTTP_OK); // OK
           // user logs
        }

        $check_avail = $this->Users_model->get(['fb_token'=>$fbtoken]);
        
        $city  =$_POST["city"];
        $country  =$_POST["country"];
        $country_id= "";
        $city_id = "";
        $this->db->where("name",$city);
        $cities = $this->Location_model->get();
        
        $this->db->where("name",$country);
        $country = $this->Location_model->get();

         if($_POST["country"]!=""){
       
        if(empty($country) && $_POST["country"]!=""){

            $country_id = $this->Location_model->insert([
                                            "name"=>$_POST["country"],
                                            "location_type"=>'0',
                                            "parent_id"=>'0',
                                            'is_visible'=>'0']); 

        }else{

            $country_id = $country->location_id;
        }
        }else{
            $country_id = "";   
        }

          if($_POST["city"]!=""){

        if(empty($cities) && $_POST["city"]!=""){

            $city_id = $this->Location_model->insert([
                                            "name"=>$_POST["city"],
                                            "location_type"=>'2',
                                            "parent_id"=>$country_id,
                                            'is_visible'=>'0']);

        }else{
            $city_id = $cities->location_id;
        }

         }else{

            $city_id = "";

        }
        if($_POST['dob']!="" && $_POST['dob']!="0000-00-00"){
            $age = $this->age($_POST['dob']);
        }else{
            $age = 0;
        } 
        // Check facebook token exists or not
        $user_ip = $this->input->ip_address();
        if (empty($check_avail)) {
            $file = $_FILES['profile']['name'];
            
            /*$premium_trial_date = date('Y-m-d');
            $trial_end_date = date('Y-m-d',strtotime($premium_trial_date. ' + 14 days'));*/
            

            $data = $this->Users_model->insert([
                                        'users_fname'=>$_POST['firstname'],
                                        'users_lname'=>$_POST['lastname'],  
                                        'users_email'=>$_POST['email'],
                                        'users_gender'=>$_POST['gender'],
                                        'users_location'=>$city_id,
                                        'users_latitude'=>$_POST['latitude'],
                                        'users_longitude'=>$_POST['longitude'],
                                        'users_dob'=>$_POST['dob'],
                                        'users_age'=>$age,
                                        'country'=>$country_id,
                                        'fb_token'=>$_POST['fbtoken'],
                                        'user_ip'=>$user_ip,
                                        'looking_for'=>$_POST['looking_for'],
                                        'device_token'=>$_POST['device_token'],
                                        'about'=>$_POST['self_summery'],
                                        'device_type'=>$_POST['device_type'],
                                        'is_online'=>'1',
                                        'is_signout'=>'0',
                                        'premium_status'=>'0',
                                        /*'premium_start_date'=>$premium_trial_date,
                                        'premium_end_date'=>$trial_end_date*/
                                        ]); // user insert
            if ($file != "") {
                
                $ext = explode(".", $file);
                $imgext = strtolower(end($ext));
                $image = date('dmYhis') . '.' . $imgext;
                $config['upload_path'] = './uploads/users/';
                $config['allowed_types'] = 'gif|jpg|png|jpeg';
                $config['max_size'] = 0;
                $config['file_name'] = $image;
                
                $this->load->library('upload', $config);
                if (!$this->upload->do_upload('profile')) {
                     _trackUser(TRUE, $this->upload->display_errors() , TRUE, $data); // user logs
                    $this->response(['status' => FALSE, 'message' => $this->upload->display_errors() , 'users_id' => $check_avail->users_id], REST_Controller::HTTP_OK); // OK (200) Reponse code
                   
                }
                else {
                    $dataimage = array(
                        'upload_data' => $this->upload->data()
                    );
                }
            }
            else{
                $image = '';
            }
           
              

            if($data && $image!=""){
                $this->User_images_model->insert(['users_id'=>$data,'user_img'=>$image,'is_primary'=>'1','image_index' => '1','user_ip'=>$user_ip]);
            }

            $interest = json_decode($_POST['interest']);
            $this->load->model('User_interest_model');

            foreach ($interest as $rows) {

                 $this->User_interest_model->insert(['users_id'=>$data,'fb_like_id'=>$rows->id,'name'=>$rows->name]);
                
                
            }
            if(!empty($_POST['gender'])){
            $gender = genderpreference($_POST['gender']);

            $this->User_preference_model->insert(['users_id'=>$data,'preference_id'=>'1','preference_option_id'=>$gender]);
            
            $preference_data = $this->Preferences_model->get(['option_title'=> $_POST['looking_for'], 'preference_id' => 2]);
            $this->User_preference_model->insert(['users_id'=>$data,'preference_id'=>'2','preference_option_id'=> $preference_data->preferences_option_id]);  
            }

              $user = $this->Users_model->fields('users_id,users_fname,users_lname,users_dob,users_gender,is_social')->get($data);

            $infoCompleted = checkComplited($user);

            _trackUser(TRUE, 'User successfully registered with facebook.', TRUE, $data);
            $this->response(['status' => TRUE,  'message' => 'User successfully registered with facebook.','is_registered'=>'0','users_id' => $data,'infocompleted'=>$infoCompleted], REST_Controller::HTTP_OK); // OK (200) Reponse code
             // user logs
        }
        else {
                $data = $this->Users_model->update([
                                        'users_location'=>$city_id,
                                        'users_latitude'=>$_POST['latitude'],
                                        'users_longitude'=>$_POST['longitude'],
                                        'country'=>$country_id,
                                        'user_ip'=>$user_ip,
                                        'device_token'=>$_POST['device_token'],
                                        'device_type'=>$_POST['device_type'],
                                        'is_online'=>'1',
                                        'is_signout'=>'0'
                                        ],['fb_token'=>$fbtoken]); // user insert


            $interest = json_decode($_POST['interest']);
            if(!empty($_POST['interest'])){
            $this->load->model('User_interest_model');

                foreach ($interest as $rowss) {  
                           
                    $get = $this->User_interest_model->get(['users_id'=>$data,'fb_like_id'=>$rowss->id,'name'=>$rowss->name]);

                    if(!$get){
                        $this->User_interest_model->insert(['users_id'=>$data,'fb_like_id'=>$rowss->id,'name'=>$rowss->name]);
                    }
                }
            }
            $users_id = $check_avail->users_id;
             $user = $this->Users_model->fields('users_id,users_fname,users_lname,users_dob,users_gender,is_social')->get($users_id);
            $infoCompleted = checkComplited($user);
            _trackUser(TRUE, 'User already registered.', TRUE, $check_avail->users_id);
            $this->response(['status' => TRUE, 'message' => 'User already registered','is_registered'=>'1', 'users_id' => $check_avail->users_id,'infocompleted'=>$infoCompleted], REST_Controller::HTTP_OK); // OK (200) Reponse code
           // user logs
        }
    }

    function signin_post()
    {
        $fbtoken = trim($this->post('fbtoken'));
        $result = $this->Users_model->getUserFieldByFBToken($fbtoken);
        if ($result) {        
            $id = $result->users_id;            
            if($result->is_deleted==1){
               _trackUser(TRUE, 'this account is temporary suspended by the Admin.', FALSE, $id);
                $this->response([ 'status' => FALSE, 'message' => $this->lang->line('user_deleted'),'user' => $result], REST_Controller::HTTP_OK); 
            }

            if($result->users_status==0){
                $this->Users_model->update(['is_online'=>'1','users_status'=>'1','is_signout'=>'0'],$id);
                _trackUser(TRUE, 'Reenable account.', FALSE, $id);                
                $this->response(['status' => FALSE, 'message' => 'Reenable your account','user' => $result, ], REST_Controller::HTTP_OK);    
            }


             if($result->users_status==2){
                _trackUser(TRUE, 'this account is temporary deactived by the Admin', FALSE, $id);                
                $this->response(['status' => FALSE, 'message' => "This account temporary deactived by the Admin",'user' => $result,], REST_Controller::HTTP_OK);    
            }
                    
             $this->Users_model->update(['is_online'=>'1','users_status'=>'1','is_signout'=>'0'],$id);

                _trackUser(TRUE, 'User successfully signed in.', TRUE, $id);
                $result->users_mobile = '';
                $result->users_password = '';
                $result->marital_status = '';
                $result->users_name= '';
                $incomplited = checkComplited($result);
                $this->response(['user' => $result, 'status' => TRUE, 'message' => $this->lang->line('user_signin_success_message'),'infocompleted'=>$incomplited], REST_Controller::HTTP_OK);
        }
        else {
            //_trackUser(TRUE, 'Invalid token.', TRUE, '');
            $this->response(['status' => FALSE, 'message' => $this->lang->line('invalid_token')], REST_Controller::HTTP_OK); // OK (200) Reponse code
        }
    }

    /**
    * Profile pic upload of user
    * @return response to app
    * 
    */
    function profilePic_post()
    {
           
        $user_id = trim($this->post('users_id'));
        $index = trim($this->post('index'));
        
        $valid = $this->checkuserId($user_id);
        
        if ($valid) {
           $is_valid_data = true;
           $errors = "";
            if ($_FILES['profile']['name'] != '') 
            {
                 $tmpFilePath = $_FILES['profile']['tmp_name'];

              $file = explode(".",$_FILES['profile']['name']);
              $ext = strtolower(end($file));
                $image = date('dmYhis').'.'.$ext;

                                $config = array(
                                    'upload_path' => './uploads/users',
                                    'allowed_types' => 'gif|png|bmp|jpeg|jpg',
                                    'file_name' =>$image,
                                    'max_size'=>'0'

                                );
                                $this->load->library('upload', $config);

                                if (!$this->upload->do_upload('profile')) {

                                    $errors = $this->upload->display_errors();
                                    $is_valid_data = false;

                                } else {
                                    if($index=="1"){
                                        $primary = '1';
                                    }
                                    else{
                                        $primary = '0';   
                                    }
                                    $upload_data = $this->upload->data();
                                      $profilepic = $this->User_images_model->insert([
                                                    'users_id' => $user_id,
                                                    'user_img' => $image,
                                                    'is_primary' => $primary,
                                                    'image_index'=>$index,
                                                    'user_ip' => $this->input->ip_address()

                                                     ]);

                                      $profile = $this->User_images_model->fields('user_img')->get(['user_image_id'=>$profilepic]);
                                      
                                      $user_img = $profile->user_img;
                                      $path = base_url()."uploads/users/".$user_img;

                                }

                if($is_valid_data==true){

                    _trackUser(TRUE, 'Profile uploaded successfully', TRUE, $user_id);
                    $this->response(['status' => TRUE, 'message' => "Image uploaded successfully", 'users_id' => $user_id,"image"=>$path], REST_Controller::HTTP_OK);
                    
                }else{

                    _trackUser(TRUE, 'Invalid file', TRUE, $user_id);
                    $this->response(['status' => FALSE, 'message' => $errors, 'users_id' => $user_id], REST_Controller::HTTP_OK);
                }
            }
            else{

            $this->response(['status' => FALSE, 'message' => "Please upload image", 'users_id' => $user_id], REST_Controller::HTTP_OK);

            }
        
        }
        else {

             _trackUser(TRUE, 'Invalid User.', TRUE, $user_id);
            $this->response(['status' => FALSE, 'message' => "Invalid user", 'users_id' => $user_id], REST_Controller::HTTP_OK);
           
        }
    }

    function set_upload_options(){
         //upload an image options
    
    }

    


    public function getAllProfilepic_post(){

        $users_id = $this->post('users_id');
        $this->db->order_by('image_index','ASC');
         $userdata = $this->User_images_model->fields([
                                                'user_image_id',
                                                'user_img',
                                                'is_primary',
                                                'image_index'])
                                            ->get_all([
                                                    "users_id" => $users_id
                                                    ]);

        foreach($userdata as $key => $value) {
            $userdata[$key]->user_img = base_url() . 'uploads/users/' . $userdata[$key]->user_img;
        }

         _trackUser(TRUE, 'User get profile picture list.', TRUE, $result->users_id);

                    $this->response([ 'status' => TRUE, 'message' => 'Picture list','profilepic' => $userdata], REST_Controller::HTTP_OK);
    }


   
   

    /**
    * Change user online status user is online
    * using post method 
    * @param users_id int    
    * @return response array
    */
    function is_online_post(){

            $data = ['is_online'=>'1'];

            $users_id = $this->post('users_id');
            $this->db->where('users_id',$users_id);
            $this->Users_model->update($data);

            $this->ClearNotification($users_id);

            _trackUser(TRUE, "user is online", TRUE, $users_id); // update status
             $this->response(array(
                    'status' => TRUE,
                    'message' => 'you are online now.'
                    ) , REST_Controller::HTTP_OK);
    }


    function ClearNotification($users_id){
        $this->load->model('User_notification_model');
        return $this->User_notification_model->delete(['users_id'=>$users_id]);

    }

    /**
    * Change user online status user is offline
    * using post method 
    * @param users_id int    
    * @return response array
    */
    function is_offline_post(){

            $data = [
                        'is_online'=>'0',
                        'offline_time'=>date('Y-m-d H:i:s')
                    ];
            $users_id = $this->post('users_id');
            $this->db->where('users_id',$users_id);
            $this->Users_model->update($data,$users_id); // update status

            _trackUser(TRUE, "user is offline", TRUE, $users_id);
            $this->response(array(
                                    'status' => TRUE,
                                    'message' => 'you are offline.'
                                    ) , REST_Controller::HTTP_OK
                            );
    }


     /**
    * Remove app user image 
    * @param $image_id,$users_id
    * @return response 
    */
    function removeImage_post(){

        $user_image_id = $this->post('user_image_id');
        $users_id = $this->post('users_id');
        if($this->checkuserId($users_id))
        {
            $images = $this->User_images_model->get(['user_image_id'=>$user_image_id]);
            $img = $this->User_images_model->delete($user_image_id);

        if($images){

            $path = FCPATH.'uploads/users/';
            $path2 = FCPATH.'uploads/users/'.$images->user_img;
            chmod($path,0777);
            chmod($path2,0777);
            $imagename = $images->user_img;
            unlink($path2);

            $indexing = json_decode($_POST['indexing']);
            
        
                if(!empty($indexing))
                {
                    $i=1;
                    foreach ($indexing as $rows) {
                        $index = $rows->index;
                        $image_id = $rows->image_id;
                        if($i==1)
                        {
                            $primary = "1";
                        }
                        else{
                            $primary = "0";   
                        }
                        $this->User_images_model->update(['image_index'=>$index,'is_primary'=>$primary],$image_id);
                    }    
                }
            


       

            _trackUser(TRUE, "Image Removed", TRUE, $users_id);
            $this->response(array('status' => TRUE,
                                  'message' => 'Image Removed'), REST_Controller::HTTP_OK);
        }
        else{
            _trackUser(TRUE, "error while removing image", FALSE, $users_id);
            $this->response(array('status' => FALSE,
                                  'message' => 'Error while removing image'), REST_Controller::HTTP_OK);   

        }
        }else{
            _trackUser(TRUE, "User not found", FALSE, $users_id);
            $this->response(array('status' => FALSE,
                                  'message' => 'User not found'), REST_Controller::HTTP_OK);   

        }

    }


    /**
    * Update User profile
    * @param $_POSTS
    * @return response mixed array
    */
    public function updateProfile_post(){

        // date of birth format Y-m-d

        $users_id = $this->post('users_id');
        if($_POST['birthdate']!="" && isset($_POST['birthdate'])){
            $age = $this->age($_POST['birthdate']);
            $update["users_age"] = $age;
            $update["users_dob"] =$_POST['birthdate'];
        }


        

        $update = [
                "users_fname"=>$_POST['firstname'],
                "users_lname"=>$_POST['lastname'],                
                "users_email"=>$_POST['email'],
                "users_gender"=>$_POST['gender'],
                "users_location"=>$_POST['location'],                
                "users_latitude"=>$_POST['latitude'],
                "users_longitude"=>$_POST['longitude'],                
                "user_ip"=>$_POST['user_ip'],
                "device_token"=>$_POST['device_token'],
                "country"=>$_POST['country'],
                'from_age'=>$_POST['from_age'],
                'to_age'=>$_POST['to_age'],
                'about'=>$_POST['about']
                ];
         
        

        $update_data =  $this->Users_model->update($update,$users_id);

        $this->Users_model->fields('users_id,users_fname,users_lname,users_email,users_gender,users_location,users_zip,users_latitude,users_longitude,users_dob')->get(['users_id'=>$users_id]);

        _trackUser(TRUE, "Profile updated by user", TRUE, $users_id);
        $this->response(['status' => TRUE,
                         'message' => 'profile updated successfully'
                        ], REST_Controller::HTTP_OK);
        
    }





    /**
    * Age Calculation using date of birth
    * @param $birthdate 
    * @return age int
    */
    public function age($birthdate){
        if($birthdate){
            $from = new DateTime($birthdate);
            $to   = new DateTime('today');
            return $from->diff($to)->y;
        }
    }


    /**
    * Get User Profile details preferences and images
    * @return response array
    *
    */
    public function getUserProfile_post(){

        $profile_user_id = $this->post('profile_user_id');
        $users_id = $this->post('users_id');
        $this->load->model('Users_like_model');
        
        $this->load->model('Chat_model');
        if($this->checkuserId($users_id) && $this->checkuserId($profile_user_id))
        {

        $usersData = $this->Users_model->fields("users_latitude,users_longitude")->get(['users_id'=>$users_id]);

        $latitude = $usersData->users_latitude;
        $longitude = $usersData->users_longitude;
        
        //$users->preferences = []; // user preferences
        $users->images = []; // user images array

        $users = $this->Users_model->get_profile($profile_user_id,$latitude,
                                                $longitude);

        $this->db->where("(sender_id='$users_id' AND receiver_id='$profile_user_id') AND (sender_visibility='1')");
        $this->db->or_where("(sender_id='$profile_user_id' AND receiver_id='$users_id') AND (sender_visibility='1')");        
        $chat = $this->Chat_model->get();

        $chat_id = '';
        if(!empty($chat)){
            $chat_id = $chat->chat_id;
        }

        $this->db->where("(sender_id='$users_id' AND receiver_id='$profile_user_id') AND (sender_visibility='0')");
        $receiver = $this->Chat_model->get();
        $invisible_chat_id = '';
        if(!empty($receiver)){
            $invisible_chat_id = $receiver->chat_id;
        }

        $users->chat_id = $chat_id;
        $users->invisible_chat_id = $invisible_chat_id;

       /* $preferences = $this->User_preference_model->getPreferences(
                                                    $profile_user_id);*/
                     $this->db->order_by('is_primary','DESC');
        $userdata = $this->User_images_model->fields(['user_image_id','user_img','is_primary','image_index'])->get_all(["users_id" => $profile_user_id]);

        foreach($userdata as $key => $value) {

                $userdata[$key]->user_img = base_url() . 'uploads/users/' . $userdata[$key]->user_img;

        }

        if($users->self_summery==""){

            $users->self_summery = "";

        }


        /*$likes = $this->User_interest_model->fields('fb_like_id,name')->get_all(['users_id'=>$profile_user_id]);*/
        $likes = $this->User_interest_model->mutualInteres($users_id,$profile_user_id);


        if(empty($likes)){
            $users->interest = [];

        }else{

            $users->interest = $likes;

        }

        // check user like and mutual like status
        $res = $this->Users_like_model->getLikedStatus($users_id,$profile_user_id);

        $users->is_mutualfriend = $res['is_mutualfriend'];
        $users->is_liked = $res['is_liked'];
        

        //$users->preferences = $preferences;
                    
        $users->images = $userdata;
        
        if(empty($users->images))    {

         $users->images =   [];

        }
        
        $users->percentage = $this->Users_model->userPerecentage($users_id,$profile_user_id);

        if($users->percentage==""){
            $users->percentage = "";

        }
        if($users->offline_time!=""){
            $offline_time = strtotime($users->offline_time);
            $users->offline_time = time_ago($offline_time);
        }
   
   
       _trackUser(TRUE, "User Profile", TRUE, $users_id); // log

        $this->response(['status' => TRUE,'message' => 'seen user profile','user'=>$users], REST_Controller::HTTP_OK); // response
        }else{
            _trackUser(TRUE, "User not found", TRUE, $users_id); // log

        $this->response(['status' => FALSE,'message' => 'User not found'], REST_Controller::HTTP_OK); // response
        }
    }

    /**
    * Set user interest one to other  (Like)
    * @param interested_user id 
    * @return reponse
    */
    public function setInterest_post(){

        $this->load->model('User_interested_model');        

        $users_id = $this->post('users_id');
        $profile_user_id  = $this->post('profile_user_id');
        $interest_status = $this->post('interest_status');

        $get = $this->User_interested_model->get([
                                            'users_id'=>$users_id,
                                            'interest_user_id'=>$profile_user_id
                                            ]);

        if(!$get){

        $this->User_interested_model->insert([
                                            'users_id'=>$users_id,
                                            'interest_user_id'=>$profile_user_id,
                                            'interest_status'=>$interest_status
                                            ]);

            _trackUser(TRUE, "set interest", TRUE, $users_id); // 

            $this->response(array('status' => TRUE,'message' => 'set interest'), REST_Controller::HTTP_OK);

        }else{

            _trackUser(TRUE, "User already interested", TRUE, $users_id);
            $this->response(array('status' => TRUE,'message' => 'User already interested'), REST_Controller::HTTP_OK);            
        }
        //$this->
    }

    /**
    * Second user accept interest
    * @param profile_user_id and users id (users id)
    * @return response
    */
    public function interested_post(){

        $users_id = $this->post('users_id');
        $interested  = $this->post('profile_user_id');

        $this->load->model('User_interested_model');        

        $this->User_interested_model->update(['interest_status'=>'2'],
                                            ['users_id'=>$interested,
                                            'interest_user_id'=>$users_id
                                            ]);

        _trackUser(TRUE, "Both interested", TRUE, $users_id);

        $this->response(array('status' => TRUE,'message' => 'Both interested'), REST_Controller::HTTP_OK);

    }

    /**
    * Check user exists or not
    * @param $id user id
    * @return bool
    */
    public function checkuserId($id){
        $result = $this->Users_model->get(['users_id' => $id,
                                            'users_status'=>'1'
                                            ]);
        if ($result) {
            return TRUE;
        }
        else {
            return FALSE;
        }
    }



     /**
    * User Profile Like
    * @param users_id (current profile id ) and profile_user_id (opposite user
     profile id)
    * @return response 
    */

    public function usersLikes_post(){

        $this->load->model('Users_like_model');
        $this->load->model('Users_like_history_model');

        $users_id = $this->post('users_id');
        $profile_user_id = $this->post('profile_user_id');
        $title = "";
        $userlike = $this->Users_like_model->get(
                                            [   'users_id'=>$users_id,
                                                'like_users_id'=>$profile_user_id
                                            ]);
        $userMsgData = $this->userNotificationData($users_id);

        $profile_user = $this->Users_model->fields('users_fname,users_lname')->where(['users_id'=>$profile_user_id])->get();

        $profile_user_name = $profile_user->users_fname." ".$profile_user->users_lname;

        if(empty($userlike)){

              $insert  = $this->Users_like_model->insert([
                                                'users_id'=>$users_id,
                                                'like_users_id'=>$profile_user_id,
                                                'like_status'=>'1']);
              $checkmutual = $this->Users_like_model->get(['users_id'=>$profile_user_id,'like_users_id'=>$users_id,'like_status'=>'1']);

              $this->db->where(["users_id"=>$users_id]);
              $user2 = $this->Users_model->fields('users_fname,users_lname')->get();
              $uname2 = $user2->users_fname.' '.$user2->users_lname;

              if(!empty($checkmutual)){

                        $this->db->where(['users_status'=>'1',"users_id"=>$profile_user_id]);

                        $user = $this->Users_model->fields('users_fname,users_lname,device_type,device_token,is_signout')->get();
                    
                        $uname = $user->users_fname.' '.$user->users_lname;

                        if(!empty($user->device_token)){
                            $device_token = $user->device_token;
                            $device_type = $user->device_type;                    
                            $message = "You and $uname2 are now mutual friend";
                            $badge = $this->badgeCount($profile_user_id);
                            $sender_id='';
                            $type = '2';
                            if($device_type=="IOS"){
                                

                                sendPushNotificationIos($device_token, $message, $title,$sender_id,$type,$userMsgData,$badge);

                            }
                            if($device_type=="Android"){
                                   $msg['body'] =  ['body'=> $message, 
                                        'badge' => $badge,
                                        'type'=>$type,
                                        'users_id'=>$sender_id];
                                   $msg['msgdata'] = $userMsgData;
                              sendPushNotificationAndroid($device_token, $msg);
                            }
                        }


                        $this->Users_like_history_model->insert([
                                                'like_id'=>$insert,
                                                'users_id'=>$users_id,
                                                'like_users_id'=>$profile_user_id,
                                                'like_status'=>'1',
                                                'like_status_text'=>'mutual like']);              

                        _trackUser(TRUE, "You and $profile_user_name are now mutual friend", TRUE, $users_id);
                        $this->response(array('status' => TRUE,'message' => "You and $uname are now mutual friend",'like_type'=>'mutual'), REST_Controller::HTTP_OK);   
                }

                        // user like history 
                        $this->Users_like_history_model->insert([
                                                        'like_id'=>$insert,
                                                        'users_id'=>$users_id,
                                                        'like_users_id'=>$profile_user_id,
                                                        'like_status'=>'1',
                                                        'like_status_text'=>'user like']);


                $this->db->where(['users_status'=>'1',"is_signout"=>'0',"device_token !="=>"","users_id"=>$profile_user_id]);
                    $user = $this->Users_model->fields('users_fname,users_lname,device_type,device_token')->get();
                    if(!empty($user)){
                    $device_token = $user->device_token;
                    $device_type = $user->device_type;                    
                    $message = "Someone like you";
                   
                    $badge = $this->badgeCount($profile_user_id);
                    $sender_id='';
                    $type = '1';
                    if($device_type=="IOS"){
                        sendPushNotificationIos($device_token, $message, $title,$sender_id,$type,$userMsgData,$badge);

                    }
                    if($device_type=="Android"){
                              $msg['body'] = ['body'=> $message, 
                                        'badge' => $badge,
                                        'type'=>$type,
                                        'users_id'=>$sender_id];
                              $msg['msgdata']=$userMsgData;
                        sendPushNotificationAndroid($device_token, $msg);
                    }
                }

            
            $msg_response = "You liked ".$profile_user_name;
            _trackUser(TRUE, $msg_response, TRUE, $users_id);
            $this->response(array('status' => TRUE,'message' => $msg_response,'like_type'=>'like'), REST_Controller::HTTP_OK);   

        }else{

             $this->Users_like_model->update(['like_status'=>'1'],$userlike->like_id);



              $checkmutual = $this->Users_like_model->get(['users_id'=>$profile_user_id,'like_users_id'=>$users_id,'like_status'=>'1']);

              $this->db->where(["users_id"=>$users_id]);
              $user2 = $this->Users_model->fields('users_fname,users_lname')->get();
              $uname2 = $user2->users_fname.' '.$user2->users_lname;

              if(!empty($checkmutual)){

                        $this->db->where(['users_status'=>'1',"users_id"=>$profile_user_id]);
                        $user = $this->Users_model->fields('users_fname,users_lname,device_type,device_token,is_signout')->get();

                        $uname = $user->users_fname.' '.$user->users_lname;
                        if(!empty($user->device_token)){
                            $device_token = $user->device_token;
                            $device_type = $user->device_type;                    
                            $message = "You and $uname2 are now mutual friend";
                            $sender_id='';
                            $type = '2';
                            $badge = $this->badgeCount($profile_user_id);
                            if($user->is_signout=='0'){

                                if($device_type=="IOS"){
                                    sendPushNotificationIos($device_token, $message, $title,$sender_id,$type,$userMsgData,$badge);
                                }

                                if($device_type=="Android"){     
                                      $msg['body'] = ['body'=> $message, 
                                        'badge' => $badge,
                                        'type'=>$type,
                                        'users_id'=>$sender_id];
                                        $msg['msgdata']=$userMsgData;
                                    sendPushNotificationAndroid($device_token, $msg);
                                }
                            }
                        }


                        $this->Users_like_history_model->insert([
                                                'like_id'=>$userlike->like_id,
                                                'users_id'=>$users_id,
                                                'like_users_id'=>$profile_user_id,
                                                'like_status'=>'1',
                                                'like_status_text'=>'mutual like']);
                       

                        _trackUser(TRUE, "You and $profile_user_name are now mutual friend", TRUE, $users_id);
                        $this->response(array('status' => TRUE,'message' => "You and $uname are now mutual friend",'like_type'=>'mutual'), REST_Controller::HTTP_OK);   
                }

                $this->Users_like_history_model->insert([
                                                'like_id'=>$userlike->like_id,
                                                'users_id'=>$users_id,
                                                'like_users_id'=>$profile_user_id,
                                                'like_status'=>'1',
                                                'like_status_text'=>'user like']);
                       

                $this->db->where(['users_status'=>'1',"is_signout"=>'0',"device_token !="=>"","users_id"=>$profile_user_id]);

                    $user = $this->Users_model->fields('users_fname,users_lname,device_type,device_token')->get();
                    if(!empty($user )){
                    $device_token = $user->device_token;
                    $device_type = $user->device_type;  
                    
                    $badge = $this->badgeCount($profile_user_id);
                    $message = "Someone like you";
                    $sender_id='';
                    $type = '1';
                    if($device_type=="IOS"){
                        sendPushNotificationIos($device_token, $message, $title,$sender_id,$type,$userMsgData,$badge);

                    }
                    if($device_type=="Android"){
                              $msg['body']=  ['body'=> $message, 
                                        'badge' => $badge,
                                        'type'=>$type,
                                        'users_id'=>$sender_id];
                                        $msg['msgdata']=$userMsgData;
                        sendPushNotificationAndroid($device_token, $msg);
                    }
                }

             $msg_response = "You liked ".$profile_user_name;
            _trackUser(TRUE, $msg_response, TRUE, $users_id);
            $this->response(array('status' => TRUE,'message' => $msg_response,'like_type'=>'like'), REST_Controller::HTTP_OK);    


        }

    }

    function userNotificationData($users_id){
        $nimage = $this->Users_model->getPrimaryImg($users_id);
        $noticeuser = $this->Users_model->getUSerNoticeData($users_id);
        if(!empty($nimage->user_img)){
            $unimage = base_url().'uploads/users/'.$nimage->user_img;
        }else{
            $unimage = "";
        }

        $usersLocation = $noticeuser->users_location;
        $uname2 = $noticeuser->users_fname." ".$noticeuser->users_lname;
        return $userMsgData = ['users_id'=>$users_id,"name"=>$uname2,'users_location'=>$usersLocation,'users_img'=>$unimage];
    }

    function badgeCount($users_id){
        $this->load->model('User_notification_model');
        $this->User_notification_model->insert(['users_id'=>$users_id]);

                    $count = $this->User_notification_model->fields('notification_id')->get_all(['users_id'=>$users_id]);
                    return $badge = count($count);
    }

    /**
    * Accept like 
    * @param $users_id (current profile id), $profile_user_id (opposite user    
      profile id)
    * @return response
    */
    public function disLike_post(){

        $users_id = $this->post('users_id');
        $profile_user_id = $this->post('profile_user_id');
        $this->load->model('Users_like_model');
         $this->load->model('Users_like_history_model');

        $result  = $this->Users_like_model->get(['users_id'=>$users_id,'like_users_id'=>$profile_user_id]);

        if(!$result){

            $insert = $this->Users_like_model->insert([
                                                'users_id'=>$users_id,
                                                'like_users_id'=>$profile_user_id,
                                                'like_status'=>'0']);

             $this->Users_like_history_model->insert([
                                                        'like_id'=>$insert,
                                                        'users_id'=>$users_id,
                                                        'like_users_id'=>$profile_user_id,
                                                        'like_status'=>'0',
                                                        'like_status_text'=>'user dislike']);

             _trackUser(TRUE, "Dislike successfully.", TRUE, $users_id);
                $this->response(array('status' => TRUE,'message' => 'Dislike successfully'), REST_Controller::HTTP_OK);

        }else{

            $this->Users_like_model->update([
                                                'users_id'=>$users_id,
                                                'like_users_id'=>$profile_user_id,
                                                'like_status'=>'0'],$result->like_id);
            
            $this->Users_like_history_model->insert([
                                                        'like_id'=>$result->like_id,
                                                        'users_id'=>$users_id,
                                                        'like_users_id'=>$profile_user_id,
                                                        'like_status'=>'0',
                                                        'like_status_text'=>'user dislike']);

            $this->Users_like_model->updateStatus($users_id,$profile_user_id);

            _trackUser(TRUE, "Dislike successfully.", TRUE, $users_id);

            $this->response(array('status' => TRUE,'message' => 'Dislike successfully'), REST_Controller::HTTP_OK);
        }


    }



  
    /**
    * Set basic filter 
    * @param $users_id,looking_for,from_age,to_age
    * @return response
    */
    public function basicPreference_post(){
        $users_id = $this->post('users_id');
        $looking_for = $this->post('looking_for');
        $from_age = $this->post('from_age');
        $to_age = $this->post('to_age');

        $update = $this->Users_model->update([
                            'looking_for'=>$looking_for,
                            'from_age'=>$from_age,
                            'to_age'=>$to_age                            
                            ],$users_id);

        if($update){

            _trackUser(TRUE, "set basic preference", TRUE, $users_id);
            $this->response(array('status' => TRUE,'message' => 'update successfully'), REST_Controller::HTTP_OK);

        }
        else{

            _trackUser(TRUE, "Error set basic preference", TRUE, $users_id);
            $this->response(array('status' => TRUE,'message' => 'Error set basic preference'), REST_Controller::HTTP_OK);

        }

    }


    /**
    * user block other users
    * @param $users_id (current user id), $profile_user_id (other user id)
    * @return 
    */
    public function blockUser_post(){
        $this->load->model('Users_block_model');
        $users_id = $this->post('users_id');
        $block_reason = $this->post('block_reason');
        
        $profile_user_id = $this->post('profile_user_id');
        if(empty($block_reason)){
            $block_reason = "";
        }
        $result = $this->Users_block_model->get(['users_id'=>$users_id,'blocked_users_id'=>$profile_user_id]);
        if(!$result){

            $res = $this->Users_block_model->insert(['users_id'=>$users_id,
                                                    'blocked_users_id'=>$profile_user_id,
                                                    'block_reason'=>$block_reason,
                                                    'block_status'=>'1']);

            if($res){
                            $this->db->where(['users_id'=>$profile_user_id]);
                $profile = $this->Users_model->fields('users_fname,users_lname')->get();
                $name = $profile->users_fname." ".$profile->users_lname;
                $msg = $name. " blocked successfully";
                _trackUser(TRUE, "User blocked", TRUE, $users_id);
                $this->response(array('status' => TRUE,'message' => $msg), REST_Controller::HTTP_OK);
            }
        }
        else{
                _trackUser(TRUE, "User already blocked", TRUE, $users_id);
                $this->response(array('status' => TRUE,'message' => 'User already blocked'), REST_Controller::HTTP_OK);
        }

    } 



    /**
    * user Unblock other users
    * @param $users_id (current user id), $profile_user_id (other user id)
    * @return 
    */
    public function unblockUser_post(){
        $this->load->model('Users_block_model');
        $users_id = $this->post('users_id');
        $profile_user_id = $this->post('profile_user_id');

        $result = $this->Users_block_model->get(['users_id'=>$users_id,'blocked_users_id'=>$profile_user_id]);
        if($result){
            $block_id = $result->block_id;
            $res = $this->Users_block_model->delete($block_id);

            if($res){
                _trackUser(TRUE, "User Unblocked", TRUE, $users_id);
                $this->response(array('status' => TRUE,'message' => 'User Unblocked'), REST_Controller::HTTP_OK);
            }
        }
        else{
                _trackUser(TRUE, "User already unblocked", TRUE, $users_id);
                $this->response(array('status' => TRUE,'message' => 'User already unblocked'), REST_Controller::HTTP_OK);
        }

    }       


     /**
    * user report other users
    * @param $users_id (current user id), $profile_user_id (other user id)
    * @return reponse
    */
    public function reportUser_post(){

        $this->load->model('Users_reported_model');
        $users_id = $this->post('users_id');
        $profile_user_id = $this->post('profile_user_id');

        $result = $this->Users_reported_model->get(['users_id'=>$users_id,'reported_users_id'=>$profile_user_id]);

        if(!$result){

            $res = $this->Users_reported_model->insert(['users_id'=>$users_id,
                                                    'reported_users_id'=>$profile_user_id]);
            if($res){

                _trackUser(TRUE, "User reported", TRUE, $users_id);
                $this->response(array('status' => TRUE,'message' => 'User reported successfully'), REST_Controller::HTTP_OK);
            }
        }
        else{
                _trackUser(TRUE, "User already reported", TRUE, $users_id);
                $this->response(array('status' => TRUE,'message' => 'User already reported'), REST_Controller::HTTP_OK);
        }

    }    






    /**
    * Deactive user account api
    * @param users_id
    * @return response
    */
    public function deactiveAccount_post(){

        $users_id = $this->post('users_id');
        $users_id = $this->post('users_id');
        $response = $this->Users_model->update(['users_status'=>'0','is_online'=>'0','is_signout'=>'1'],$users_id);
        if($response){
              _trackUser(TRUE, "Account is deactivated", TRUE, $users_id);
            $this->response(array('status' => TRUE,'message' => 'Your account is deactivated'), REST_Controller::HTTP_OK);
        }

    }


    /**
    * Reset Dislike user
    * @param users_id
    * @return response
    */
    public function filterReset_post(){
        $this->load->model('Users_like_model');
        $users_id = $this->post('users_id');
        $this->db->where('users_id',$users_id);
        $this->db->where('like_status','0');
        $response = $this->Users_like_model->delete();
          _trackUser(TRUE, "Filter reset successfully", TRUE, $users_id);
          $this->response(array('status' => TRUE,'message' => 'Filter reset successfully'), REST_Controller::HTTP_OK);

    }


    /**
    * user profile 
    * @param $users_id
    * @return response json array
    */
    public function userProfile_post(){
        $this->load->model('Location_model');
        $users_id = $this->post('users_id');

        if($this->checkuserId($users_id))
        {

       
            
        $users = $this->Users_model->userProfileget($users_id);
        if(!empty($users->users_location)){
          $location = $this->Location_model->get(['location_id'=>$users->users_location]);
        

        $users->users_location = $location->name;
        }   

        if(!empty($users->country)){
        $country = $this->Location_model->get(['location_id'=>$users->country]);
             $users->country = $country->name;
        }
       
        $users->images = []; // user images array

        if($users->is_invisible==""){
            $users->is_invisible = 1;
        }
        

        $this->db->order_by('image_index','asc');
        $userdata = $this->User_images_model
                        ->fields(['user_image_id','user_img','is_primary','image_index'])
                        ->get_all(["users_id" => $users_id]);

        foreach(@$userdata as $key => $value) {
                if(!empty($userdata[$key]->user_img))
                {
                    $userdata[$key]->user_img = base_url() . 'uploads/users/' . $userdata[$key]->user_img;
                }else{
                    $userdata[$key]->user_img = [];
                }
           }

        $users->images = $userdata;
        
        if(empty($users->images))    {
         $users->images =   [];
        }
        _trackUser(TRUE, "User Profile", TRUE, $users_id); // log

        $this->response(['status' => TRUE,'message' => 'User Profile','profile'=>$users], REST_Controller::HTTP_OK); // response
        }else{
            _trackUser(TRUE, "User not found", TRUE, $users_id); // log

        $this->response(['status' => FALSE,'message' => 'User not found',
                'userstatus' => FALSE ], REST_Controller::HTTP_OK); // response
        }
    }


   

    /**
    * Swipe images update
    * @param imageid and index
    * @return reponse
    */
    public function swipImages_post(){

        $indexing = json_decode($_POST['indexing']);

        $users_id = $this->post('users_id');

        $valid = $this->checkuserId($users_id);

        
        if($valid){

            $i=1;

            foreach ($indexing as $rows) {

                $index = $rows->index;

                $image_id = $rows->image_id;

                if($i=='1'){

                    $primary = '1';    

                }else{

                    $primary = '0';    

                }

                $this->User_images_model->update(['image_index'=>$index,'is_primary'=>$primary],$image_id);
                $i++;
            }    
            $this->response(['status' => TRUE,'message' => 'Images rearrange successfully'], REST_Controller::HTTP_OK); // response
        }
        else{

            $this->response(['status' => FALSE,'message' => 'User not found'], REST_Controller::HTTP_OK); // response
        }
        
    }


    /**
    * Signout from application remove devicetoken and devicetype
    * @param $users_id
    * @return response
    */
    public function signout_get(){
        
        $users_id = $this->get('users_id');

        $update = $this->Users_model->update(["is_online"=>'0',"is_signout"=>'1','offline_time'=>$offline_time],$users_id);

        if($update){

             _trackUser(TRUE, "Signout", TRUE, $users_id); // log

            $this->response(['status' => TRUE,'message' => 'Signout successfully'], REST_Controller::HTTP_OK); // response

        }else{

             _trackUser(TRUE, "Error while sign out", TRUE, $users_id); // log

            $this->response(['status' => TRUE,'message' => 'Error while sign out'], REST_Controller::HTTP_OK); // response
        }
    }


    
    /**
    * Update device token 
    * @param device_token, device_type, users_id
    * @return response
    */
    public function updateToken_post(){


        $device_token = $this->post('device_token');
        $device_type = $this->post('device_type');
        $users_id = $this->post('users_id');
        $valid = $this->checkuserId($users_id);

        
        if($valid){
        
            if($device_token!="" && $device_type!="")
            {
            $this->Users_model->update(['device_type'=>$device_type,'device_token'=>$device_token],$users_id);
             _trackUser(TRUE, "Device token updated", TRUE, $users_id); // log
            

            $this->response(['status' => TRUE,'message' => 'Device token updated'], REST_Controller::HTTP_OK); // response
            }
            else{
                  $this->response(['status' => FALSE,'message' => 'device token and device type is mandatory'], REST_Controller::HTTP_OK); // response
            }
        }
        else{

            $this->response(['status' => FALSE,'message' => 'User not found'], REST_Controller::HTTP_OK); // response
        }

    }

    /**
     * Generate one way hash by using sha512
     * @param  string $str
     * @return string
     */
    public function _hash($str)
    {
        return hash('sha512', $str . config_item('encryption_key'));
    }


    /**
    * Send mail function
    *
    *
    */
    function sendmail($email,$subject,$message){
        $config = emailconfig();
                        $this->load->library('email',$config);       
                        $this->email->set_newline("\r\n");
                 
                        $this->email->from('no-reply@snackdating.com', websitedata('site_name'));
                        $this->email->to($email);
                        $this->email->subject($subject);
                        $this->email->message($message);

                        try {
                            if ($this->email->send()) {
                                return true;
                            }
                            else{
                                return false;
                            }

                        } catch (Exception $e) {
                                return false;                            
                        }
    }

    /**
    * Generate otp function
    * Generate random 6 length number & check is already exists or not
    * @return number
    */
    function generateopt(){
         $otp = rand(100, 999) . rand(100, 999);

        if($otp){
            $opt_user = $this->Users_model->get(['otp_number'=>$otp]);
            if($opt_user){                
                $otp = $this->generateopt();                    
            }
        }
        return $otp;
    }


    /**
    * Forgot password
    * 
    */
    public function forgot_password_post(){


        //$otp = rand(100, 999) . rand(100, 999);
       
         $this->data['title'] = 'Reset Password';

        if ($_POST) {
            //validation
            if ($this->form_validation->run('user_forgot_password') == false) {
                $error = strip_tags(validation_errors());
                 $this->response(['status' => FALSE,'message' => $error], REST_Controller::HTTP_OK); // response
                //set_error_notification();
            } else {
                //load password reset model
                
                //get the user detail by entered email address
                $email = $this->input->post('email', true);

                 $otp = $this->generateopt();

                if($otp){
                    $opt_user = $this->Users_model->get(['users_email'=>$email]);
                    if($opt_user->otp_number!=""){
                        $otp_created_at  = $opt_user->otp_created_at;
                        $timediff = timeDiff($otp_created_at,date("Y-m-d H:i:s"));
                        if($timediff < 1800){
                              $otp =  $opt_user->otp_number;
                        }
                    }
                }


                $user = $this->Users_model->get(['users_email'=>$email]);

                //check user is found
                if ($user) {
                    //check for status
                    if ($user->users_status == 0) {
                        //email or username is temporary deactivated
                         $error = $_POST["email"] . '</i> email is temporary deactived by the Admin.';
                          $this->response(['status' => FALSE,'message' => $error], REST_Controller::HTTP_OK); // response
                        
                    }
                    //check for soft delete
                    if ($user->is_deleted == 1) {
                        //email or username is temporary suspended
                        $error = $_POST["email"] . '</i> email is temporary suspended by the Admin.';
                        $this->response(['status' => FALSE,'message' => $error], REST_Controller::HTTP_OK); // response
                        
                    } else {

                        if($user->is_social=="1"){
                            /*$error = $_POST["email"] . '</i> email is registered with facebook login you cant .';*/
                            $error = "Seems you have used Facebook for login. Please try login using facebook account";
                            $this->response(['status' => FALSE,'message' => $error], REST_Controller::HTTP_OK); // response
                        }


                        //generate token for reset password
                        $this->load->helper('string');

                        $token = random_string('alnum', 32);
                       // $this->Users_model->update_token($user->admin_email,$token);
                        //send email to entered email address
                        $name = $user->users_fname." ".$user->users_lname;
                        
                        $message = "Hello ".$name."<br>";
                        $message .='We got a request to reset your password'."<br>";
                        $message .= $otp." is your otp for reset your password.";

                        $config = emailconfig();
                        $this->load->library('email',$config);       
                        $this->email->set_newline("\r\n");
                 
                        $this->email->from('no-reply@snackdating.com', websitedata('site_name'));
                        $this->email->to($user->users_email);
                        $this->email->subject('Reset Password - Snack Dating');
                        $this->email->message($message);

                        try {
                            if ($this->email->send()) {
                                $users_id = $user->users_id;
                                $date = date('Y-m-d H:i:s');
                                $this->Users_model->update(['otp_number'=>$otp,'otp_created_at'=>$date],$users_id);
                                $message = 'OTP is sent on your mail id.';
                                $this->response(['status' => TRUE,'message' => $message], REST_Controller::HTTP_OK); // response
                            }
                            else{
                                $message = 'Error while send mail! Please try again or try after sometime';
                                $this->response(['status' => FALSE,'message' => $message], REST_Controller::HTTP_OK); // response
                                
                                
                            }

                        } catch (Exception $e) {

                              $message = 'Error while send mail! Please try again or try after sometime';
                                $this->response(['status' => FALSE,'message' => $message], REST_Controller::HTTP_OK); // response

                            
                        }
                         $message = 'Error while send mail! Please try again or try after sometime';
                                $this->response(['status' => FALSE,'message' => $message], REST_Controller::HTTP_OK); // response

                    }
                } else {
                    
                    $message = 'Email address is not registered with the system';
                    $this->response(['status' => FALSE,'message' => $message], REST_Controller::HTTP_OK); // response
                }
            }
        }
        
    }

    public function checkotp_post(){

        $otp = $_POST['otp'];
        $email= $_POST['email'];

         if ($this->form_validation->run('checkotp') == true) {
            
            
        $user = $this->Users_model->get(['otp_number'=>$otp,'users_email'=>$email]);
       
            if($user){

                 $otp_created_at = $user->otp_created_at;

                $timediff = timeDiff($otp_created_at,date("Y-m-d H:i:s"));
                if($timediff > 1800){
                      $error = "Your OTP is expired";
                      $this->response(['status' => FALSE,'message' => $error], REST_Controller::HTTP_OK); // response
                }



                        $users_id = $user->users_id;
                        $otp_number = $user->otp_number;
                        $message = 'OTP match successfully';
                        $this->response(['status' => TRUE,'message' => $message,'users_id'=>$users_id,'otp'=>$otp_number], REST_Controller::HTTP_OK); // response
            }else{
                        $message = 'OTP is not matching, Please try again';
                        $this->response(['status' => FALSE,'message' => $message,'users_id'=>$users_id], REST_Controller::HTTP_OK); // response
            }
        }else{
                 $error = strip_tags(validation_errors());
                 $this->response(['status' => FALSE,'message' => $error], REST_Controller::HTTP_OK); // response
                //set_error_notification();
        }


    }



/**
     * Reset user password based on requested
     * @param  string $token
     */
    public function reset_password_post()
    {
      /*  echo "<pre>";
        print_r($_POST);
        exit;*/
        
        if ($_POST) {
            //validation
            if ($this->form_validation->run('api_password_reset') == false) {

                $error = strip_tags(validation_errors());
                  
                $this->response(['status' =>FALSE,'message' => $error], REST_Controller::HTTP_OK); // response
            } else {
                if ($this->input->post('users_id', true)) {
                    $users_id = $this->input->post('users_id', true);
                    //get and compare password
                    $new_password = $this->input->post('txtpassword', true);

                    $confirm_password = $this->input->post('txtconfirmpassword', true);

                    $otp = $this->input->post('otp', true);

                    if ($new_password === $confirm_password) {

                        $password_reset = $this->Users_model->get(['users_id'=>$users_id,'otp_number'=>$otp]);
                        if($password_reset){
                        //update new password
                        $this->db->where('users_email', $password_reset->users_email);
                        $this->db->where('otp_number', $otp);
                        $user = $this->db->update('users', [
                            'users_password' => $this->_hash($new_password),
                            'otp_number' => ''
                        ]);
                     

                        if ($user) {
                            //disable token                            
                            $message = 'Your password has been reset successfully!';
                            $this->response(['status' => TRUE,'message' => $message], REST_Controller::HTTP_OK); // response
                        } else {
                            
                            $message = 'Server error! Please try again later.';
                            $this->response(['status' => FALSE,'message' => $message], REST_Controller::HTTP_OK); // response
                        }

                        }else{
                            $message = 'OTP is expired or wrong OTP.';
                            $this->response(['status' => FALSE,'message' => $message], REST_Controller::HTTP_OK); // response
                        }

                    } else {
                        $message = 'A password mismatch has been detected.';
                            $this->response(['status' => FALSE,'message' => $message], REST_Controller::HTTP_OK); // response
                    }
                }
            }
        }
       
    }

    /**
    * Blocked users list by logged in user
    * @param $users_id
    * @return response array
    * 29-1-2018 by mayur panchal
    */
    function usersBlockList_get(){
        $this->load->Model('Users_block_model');
        $users_id = $this->get('users_id');
         $page = $this->get('page');

        if ($page == "" || $page < 1) {

            $page = "0";

        }

        $perPage = "10";
        
        $total_rows = $this->Users_block_model->usersBlockListNumRows($users_id);
        $users = $this->Users_block_model->usersBlockList($users_id,$page,$perPage);
        foreach ($users as $key => $value) {
             $profile_user_id = $value->users_id;

                $profile = $this->User_images_model->get(['users_id' => $profile_user_id, 'is_primary' => '1']);

                if (!empty($profile->user_img)) {

                    $users[$key]->users_img = base_url() . 'uploads/users/' . $profile->user_img;

                }
                else {

                    $users[$key]->users_img = "";

                }
        }

         if(empty($users)){

        $this->response(array(
            'status' => FALSE,
            'message' => 'No data found'
        ) , REST_Controller::HTTP_OK);
        
        }else{
        

        _trackUser(TRUE, 'Blocked users list', TRUE, $users_id); // user logs
        
        $this->response(array(
            'status' => TRUE,
            'message' => 'Blocked users list',
            'users' => $users,
            'total_rows'=>$total_rows
        ) , REST_Controller::HTTP_OK);

        }


    }

    /**
    * User Discovery Settings (if user discovery is off then user not displaying in list)
    * @param $users_id,$discovery
    * @return response boolean
    * Date : 31-1-2018 by mayur panchal
    */
    function discoverySetting_post(){
        $users_id = $this->post('users_id');
        $discovery = $this->post('discovery');

        $valid = $this->checkuserId($users_id);
        
        if (!$valid) {
        
        $this->response(array(
            'status' => FALSE,
            'message' => 'Invalid user'
        ) , REST_Controller::HTTP_OK);
        
        }

        if($discovery!=""){

            $data = ['discovery'=>$discovery];
            $msg = "Discovery on by user";
            if($discovery==0){
                $msg =  "Discovery off by user";
            }
            $this->Users_model->update($data,$users_id);

            _trackUser(TRUE,$msg, TRUE, $users_id);

            $this->response([
                                'status' => TRUE,
                                'message' => $msg
                        ], REST_Controller::HTTP_OK);
        }else{
            
             $message = 'Invalid Details';
             $this->response([
                                'status' => FALSE,
                                'message' => $message
                        ], REST_Controller::HTTP_OK); // response
        }

    }

   

    /**
    * user name invisible if user is purchased premium package
    * @param $users_id,is_invisible
    * @return response json array
    * Date 25-04-2018
    * Developer : mayur panchal
    */
     function invisible_post(){
        $users_id =  $this->post('users_id');    
        $valid = $this->checkuserId($users_id);
        
        if (!$valid) {
        
        $this->response(array(
            'status' => FALSE,
            'message' => 'Invalid user'
        ) , REST_Controller::HTTP_OK);
        
        }
        $user = $this->Users_model->get($users_id);

        if($user->premium_status==1){

            $status = $this->post('is_invisible'); # 0 OR 1

            $user = $this->Users_model->update(['is_invisible'=>$status],$users_id);

            if($user){

                if($status=="1"){
                    $msg = "Status change as visible";
                }elseif($status=="0"){
                    $msg = "Status change as invisible";
                }

                _trackUser(TRUE, $msg, TRUE, $users_id); // user logs
            
                $this->response(array(
                    'status' => TRUE,
                    'message' =>$msg                       
                ) , REST_Controller::HTTP_OK);
            
            }else{

            
                $this->response(array(
                    'status' => FALSE,
                    'message' => 'Error while change status'
                ) , REST_Controller::HTTP_OK);

            }
        }else{
             $this->response(array(
                    'status' => FALSE,
                    'message' => "You can't be invisible without purchase premium membership",
                ) , REST_Controller::HTTP_OK);
        }
    }

    /**
    * Verify mobile number is valid for update or not
    * if same user want to update it allow but another user try with already exists mobile number in someone's account it will throw error in response
    * @return return json array
    * @param users_id and mobile
    */
    function verifyMobile_post(){
        $users_id =  $this->post('users_id');    
        $valid = $this->checkuserId($users_id);
        
        if (!$valid) {
        
        $this->response(array(
            'status' => FALSE,
            'message' => 'Invalid user'
        ) , REST_Controller::HTTP_OK);
        
        }
        
        if($_POST['mobile']){

            $mobile = $_POST['mobile'];
            $get_user = $this->Users_model->where(['users_mobile'=>$mobile,'users_id != '=>$users_id])->get();
           
            if($get_user){
                $error = $mobile." this mobile number is already exists!";
                $this->response(['status' => FALSE,'message' =>$error], REST_Controller::HTTP_OK); // response
            }else{
                $success = "Mobile number is valid for update";
                $this->response(['status' => TRUE,'message' =>$success], REST_Controller::HTTP_OK); // response
            }
           
        }else{
             $this->response(array(
                    'status' => FALSE,
                    'message' => "You can't be invisible without purchase premium membership",
                ) , REST_Controller::HTTP_OK);
        }
    }


    
    /**
    * Delete disliked users from like table  
    * This function called through cron job
    * users disliked record delete every 6 month 
    */
    public function resetDislikeUser_get(){
      $this->load->model('Users_like_model');
      $reset = $this->Users_like_model->resetFilter();
      if($reset){
        echo "Dislike data reset successfully";
      }
    }
    


}