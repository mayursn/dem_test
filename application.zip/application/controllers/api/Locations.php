<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . '/libraries/REST_Controller.php';

class Locations extends REST_Controller

{
    
    /**
     * Constructor
     *
     *  @return void
     */
    public function __construct(){
        parent::__construct();       
        $this->load->model('Users_model');    
        $this->load->helper("users_helper");    
        $this->lang->load('message', 'english');

    }

    /**
    * Update Location when user add new location
    * @param $users_id,$latitude,$longitude
    * @return response
    *
    */

    function updateLocation_post(){
        $latitude = $this->post('latitude');
        $longitude = $this->post('longitude');
        $users_id = $this->post('users_id');
        $checkuser = $this->checkuserId($users_id);
        if($checkuser){
            if($latitude!="" && $longitude!=""){
                $this->Users_model->update(['users_latitude'=>$latitude,'users_longitude'=>$longitude],$users_id);
                _trackUser(TRUE, "Location updated successfully", TRUE, $users_id);

            $this->response(array('status' => TRUE,'message' => 'Location updated successfully'), REST_Controller::HTTP_OK);
            }else{


            $this->response(array('status' => FALSE,'message' => 'Latitude Or Longitude not found'), REST_Controller::HTTP_OK);
            }


            
        }else{
            _trackUser(TRUE, "User not found", TRUE, $users_id);

            $this->response(array('status' => FALSE,'message' => 'User not found'), REST_Controller::HTTP_OK);
        }
    }



    /**
    * Check user exists or not
    * @param $id user id
    * @return bool
    */
    public function checkuserId($id)
    {
        $result = $this->Users_model->get(['users_id' => $id,
                                            'users_status'=>'1'
                                            ]);
        if ($result) {
            return TRUE;
        }
        else {
            return FALSE;
        }
    }





}