<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . '/libraries/REST_Controller.php';

class Questions extends REST_Controller

{
    
    /**
     * Constructor
     *
     *  @return void
     */
    public function __construct(){
        parent::__construct();
        $this->load->model('Questions_master_model'); 
        $this->load->model('Answer_option_model'); 
        $this->load->model('Users_model'); 
              
        $this->load->model('User_questions_model');     
        $this->lang->load('message', 'english');
    }


    /**
    * Get user listing based on match
    * @return response array
    */

    public function questionsList_get(){
           $users_id  = $this->get('users_id');
            
            
            $this->db->where("questions_master.question_id NOT IN (SELECT question_id FROM user_questions WHERE users_id=$users_id)");
            $this->db->join("users_skip","users_skip.question_id=questions_master.question_id AND users_skip.users_id ='$users_id'",'left');
            $this->db->order_by("users_skip.created_date",'asc');            
            $questions = $this->Questions_master_model->fields('question_id,question_title')->get_all();
           
            if ($questions) {

                _trackUser(TRUE, 'Questions List!', TRUE, $users_id); // user logs
                $this->response(array(
                    'status' => TRUE,
                    'message' => 'Questions list',
                    'questions' => $questions
                ) , REST_Controller::HTTP_OK);
              
            }
            else{

                _trackUser(TRUE, 'No more question found', TRUE, $users_id); // user logs
                $this->response(array(
                    'status' => TRUE,
                    'message' => 'No more question found!'
                ) , REST_Controller::HTTP_OK);

            }

    }




    /**
    * Add answer of question
    * @param $question_id, $users_id, $answer
    * @return response mixed array
    */
    public function answers_post(){

        $this->load->model('User_questions_model');

        $question_id = $this->post('question_id');
        $users_id = $this->post('users_id');
        $answer = $this->post('answer_id');
        $opp_user_them = $this->post('opp_user_them');
        $valid = $this->checkuserId($users_id);

        if(!$valid){
                $this->response(['status' => FALSE, 'message' => "User not found"], REST_Controller::HTTP_OK); // OK
        }
        $get_question = $this->Questions_master_model->get(['question_id'=>$question_id]);
        if(!$get_question){
            $this->response(['status' => FALSE, 'message' => "This question is not found"], REST_Controller::HTTP_OK); // OK
           // user logs
        }

        $get_answer = $this->Answer_option_model->get(['answer_id'=>$answer]);
        if(!$get_answer){
            $this->response(['status' => FALSE, 'message' => "This answer is not found"], REST_Controller::HTTP_OK); // OK
           // user logs
        }

        /*        
        $importance = $this->post('importance');
        $details = $this->post('details');
        $answer_publicly = $this->post('answer_publicly');
        */
        if ($this->form_validation->run('question_answer') == false) {
          $this->response(['status' => FALSE, 'message' => validation_errors()], REST_Controller::HTTP_OK); // OK
           // user logs
        }

        $question = $this->User_questions_model->get(["users_id"=>$users_id,
            "question_id"=>$question_id]);

        $this->foreignkey_issue(); // set MYSQL 

        if($question){
                $saved = $this->User_questions_model->update([
                    "users_id"=>$users_id,
                    "question_id"=>$question_id,
                    "answer_id"=>$answer,
                    "opp_user_them"=>$opp_user_them

                ],$question->user_question_id);
        }else{
                $saved = $this->User_questions_model->insert([
                    "users_id"=>$users_id,
                    "question_id"=>$question_id,
                    "answer_id"=>$answer,
                    "opp_user_them"=>$opp_user_them
                    ]);
        }
        $this->foreignkey_solved();

        if($saved){
            _trackUser(TRUE, 'Answer saved', TRUE, $users_id); // user logs
            $this->response(array(
                        'status' => TRUE,
                        'message' => 'Answer saved'
            ) , REST_Controller::HTTP_OK);
        }else{
            _trackUser(TRUE, 'Error while save answer', TRUE, $users_id); // user logs
            $this->response(array(
                        'status' => TRUE,
                        'message' => 'Error while save answer'
            ) , REST_Controller::HTTP_OK);
        }

    }


    /**
    * Foreign key issue
    */
    function foreignkey_issue(){
            $this->db->query("SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT");
            $this->db->query("SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS");
            $this->db->query("SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION");
            $this->db->query("SET NAMES utf8");
            $this->db->query("SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0");
            $this->db->query("SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0");
            $this->db->query("SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO'");
            $this->db->query("SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0");

    }

    /**
    * Foreign key issue
    */
    function foreignkey_solved(){
            $this->db->query("SET SQL_MODE=@OLD_SQL_MODE");
            $this->db->query("SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS");
            $this->db->query("SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS");
            $this->db->query("SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT");
            $this->db->query("SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS");
            $this->db->query("SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION");
            $this->db->query("SET SQL_NOTES=@OLD_SQL_NOTES"); 
    }



    /**
    * Clear answer of question from the list
    * @param $question_id,$users_id
    * @return response 
    */
    function clearQuestion_post(){
        $question_id = $this->post('question_id');
        $users_id = $this->post('users_id');
        $user_question = $this->User_questions_model->get(['users_id'=>$users_id,'question_id'=>$question_id]);

        $user_question_id = $user_question->user_question_id;

        if($user_question_id){

            $this->User_questions_model->delete($user_question_id);

            _trackUser(TRUE, 'Answer clear successfully', TRUE, $users_id); // user logs
            $this->response(array(
                        'status' => TRUE,
                        'message' => 'Answer clear successfully'
            ) , REST_Controller::HTTP_OK);

        }else{

            _trackUser(TRUE, 'Error while clear answer', TRUE, $users_id); // user logs

            $this->response(array(
                        'status' => TRUE,
                        'message' => 'Error while clear answer'
            ) , REST_Controller::HTTP_OK);

        }

    }



    
    /**
    * Skip question api
    * @param $users_id, $question_id
    * @return response
    */


    function skip_get(){
        $this->load->model('Users_skip_model');
        $question_id = $this->get('question_id');
        $users_id = $this->get('users_id');
        $question = $this->Users_skip_model->get([
                                                'users_id'=>$users_id,
                                                'question_id'=>$question_id
                                                ]);
        if($question_id!="" && $users_id!=""){
            if($question){
                $skip_id = $question->skip_id;
                $date = date('Y-m-d H:i:s');
                 $skip = $this->Users_skip_model->update([
                                                'created_date'=>$date,
                                                ],$skip_id);
            }
            else{
                
                $skip = $this->Users_skip_model->insert([
                                                'users_id'=>$users_id,
                                                'question_id'=>$question_id
                                                ]);
            }

            if($skip){
                _trackUser(TRUE, 'Question Skipped', TRUE, $users_id); // user logs
            $this->response(array(
                        'status' => TRUE,
                        'message' => 'Question Skipped'
            ) , REST_Controller::HTTP_OK);

            }else{
                 _trackUser(TRUE, 'Error while skip question', TRUE, $users_id); // user logs

            $this->response(array(
                        'status' => FALSE,
                        'message' => 'Error while skip question'
            ) , REST_Controller::HTTP_OK);
            }
        }
        else{
              _trackUser(TRUE, 'Error while skip question', TRUE, $users_id); // user logs

            $this->response(array(
                        'status' => FALSE,
                        'message' => 'Error while skip question'
            ) , REST_Controller::HTTP_OK);
        }

    }


    /**
    * Answered List with question
    * @param $users_id
    * @return response
    */


    function answeredList_get(){
                $users_id = $this->get('users_id');
  $page = $this->get('page');
            if ($page == "" || $page < 1) {
                $page = "0";
            }

            $perPage = "10";
             $page = ($page * $perPage);
            $this->db->select('qm.question_id,qm.question_title,uq.answer_id as selected,uq.opp_user_them');
            $this->db->where('uq.users_id',$users_id);
            $this->db->join('questions_master qm',"qm.question_id=uq.question_id",'left');
            $total_rows = $this->db->get('user_questions uq')->num_rows();


            $this->db->select('IFNULL(qm.question_id,0) as question_id,IFNULL(qm.question_title,0) as question_title,IFNULL(uq.answer_id,0) as selected,IFNULL(uq.opp_user_them,0) as opp_user_them');
            $this->db->where('uq.users_id',$users_id);
            $this->db->join('questions_master qm',"qm.question_id=uq.question_id",'left');
            $this->db->limit($perPage,$page);
            $questions = $this->db->get('user_questions uq')->result();

              foreach ($questions as $key => $value) {
                    $this->db->select('answer_id,answer_title');
                    $this->db->where('question_id',$value->question_id);
                    $answer = $this->db->get('answer_option')->result();
                    $questions[$key]->answer_option = $answer;
                    $answer_option = $questions[$key]->answer_option;
                            foreach ($answer_option as $keys => $values) {

                                $them = $value->opp_user_them;

                                if(!empty($them)){

                                    $them = explode(",", $them);

                                    if(in_array($values->answer_id, $them)){

                                        $answer_option[$keys]->opp_user_them = 1;    
                                    }
                                    else{

                                        $answer_option[$keys]->opp_user_them = 0;       
                                    }

                                }else{

                                    $answer_option[$key]->opp_user_them = 0;       
                                }
                                
                            }


            }


            

            if ($questions) {

                _trackUser(TRUE, 'Questions List!', TRUE, $users_id); // user logs
                $this->response(array(
                    'status' => TRUE,
                    'message' => 'Questions list',
                    'questions' => $questions,
                    'total_rows' =>$total_rows
                ) , REST_Controller::HTTP_OK);
              
            }
            else{

                _trackUser(TRUE, 'Answered question not found', TRUE, $users_id); // user logs
                $this->response(array(
                    'status' => FALSE,
                    'message' => 'Answered question not found!'
                ) , REST_Controller::HTTP_OK);

            }
    }




    /**
    * Answer View api
    * @param $users_id, $question_id
    * @return response array
    */
    function answerView_get(){
        $users_id = $this->get('users_id');    
        $question_id = $this->get('question_id');

        $this->db->select('qm.question_id,qm.question_title');
        $this->db->where('qm.question_id',$question_id);        
        $questions = $this->db->get('questions_master qm')->result();

        foreach ($questions as $key => $value) {
               $this->db->select('answer_id,answer_title');
                    $this->db->where('question_id',$value->question_id);
                    $answer = $this->db->get('answer_option')->result();
                    $questions[$key]->opp_user_them = 0;
                    $questions[$key]->answer_option = $answer;
                    
        }

        if ($questions) {

                _trackUser(TRUE, 'Questions List!', TRUE, $users_id); // user logs
                $this->response(array(
                    'status' => TRUE,
                    'message' => 'Questions list',
                    'questions' => $questions
                ) , REST_Controller::HTTP_OK);
              
        }else{

                _trackUser(TRUE, 'No more question found', TRUE, $users_id); // user logs
                $this->response(array(
                    'status' => FALSE,
                    'message' => 'No more question found!'
                ) , REST_Controller::HTTP_OK);

        }


    }



     /**
    * Answered questions details page api
    * @param $users_id, $question_id 
    * @return response question details
    */


    function answered_get(){
        
        $this->load->model('User_questions_model');
        $this->load->model('Users_model');

        $question_id = $this->get('question_id');
        $users_id = $this->get('users_id');
        $valid = $this->checkuserId($users_id);

        if(!$valid){
                $this->response(['status' => FALSE, 'message' => "User not found"], REST_Controller::HTTP_OK); // OK
        }

        $get_question = $this->Questions_master_model->get(['question_id'=>$question_id]);

        if(!$get_question){
            $this->response(['status' => FALSE, 'message' => "This question is not found"], REST_Controller::HTTP_OK); // OK
           // user logs
        }

        $questions = $this->User_questions_model->answeredquestions($users_id,$question_id);


        foreach ($questions as $key => $value) {
                    $this->db->select('answer_id,answer_title');
                    $this->db->where('question_id',$value->question_id);
                    $answer = $this->db->get('answer_option')->result();
                    $questions[$key]->answer_option = $answer;
                    $answer_option = $questions[$key]->answer_option;
                            foreach ($answer_option as $keys => $values) {

                                $them = $value->opp_user_them;

                                if(!empty($them)){

                                    $them = explode(",", $them);

                                    if(in_array($values->answer_id, $them)){

                                        $answer_option[$keys]->opp_user_them = 1;    
                                    }
                                    else{

                                        $answer_option[$keys]->opp_user_them = 0;       
                                    }

                                }else{

                                    $answer_option[$key]->opp_user_them = 0;       
                                }
                                
                            }


            }



       

        if($questions){
            _trackUser(TRUE, 'Answered question', TRUE, $users_id); // user logs
            $this->response(array(
                        'status' => TRUE,
                        'message' => 'Answered question',
                        'questions'=>$questions

            ) , REST_Controller::HTTP_OK);
        }else{
            _trackUser(TRUE, 'Error while get Answered question', TRUE, $users_id); // user logs
            $this->response(array(
                        'status' => TRUE,
                        'message' => 'Error while get Answered question'
            ) , REST_Controller::HTTP_OK);
        }
    }



    



    /**
    * Check user exists or not
    * @param $id user id
    * @return bool
    */
    public function checkuserId($id)
    {
        $result = $this->Users_model->get(['users_id' => $id,
                                            'users_status'=>'1'
                                            ]);
        if ($result) {
            return TRUE;
        }
        else {
            return FALSE;
        }
    }

    /*
    Question search
    SELECT *,uq.opp_user_them FROM users u LEFT JOIN user_questions uq ON u.users_id=uq.users_id WHERE answer_id IN ('1','2') 
    */


    /**
    SET FOREIGN_KEY_CHECKS=0;
    TRUNCATE TABLE user_preference;
    SET FOREIGN_KEY_CHECKS=1;
    **/
}