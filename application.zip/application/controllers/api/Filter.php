<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require APPPATH . '/libraries/REST_Controller.php';

class Filter extends REST_Controller

{
    /**
     * Constructor
     *
     *  @return void
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Users_model');
        $this->load->model('User_images_model');
        $this->load->model('Users_like_model');
        $this->load->model('Users_block_model');
        $this->load->model('User_questions_model');
        $this->load->model('Preference_master_model');
        $this->load->model('Preferences_model');
        $this->load->model('User_preference_model');
        $this->load->model('Filter_preference_model');
        $this->load->model('Location_model');
        
        $this->load->helper("users_helper");

        $this->load->model('Filter_model');
        $this->lang->load('message', 'english');
    }

    /**
     * Special match functionality based on the preferences
     *
     *
     *
     */
     function specialMatch_get()
    {
        

      
        $this->load->model('User_interest_model');

        $users_id = $this->get('users_id');

        $page = $this->get('page');

        if ($page == "" || $page < 1) {

            $page = "0";

        }

        $perPage = "10";

        if(!$this->checkuserId($users_id)) {   

            $this->response(array(
                'status' => FALSE,
                'message' => 'Invalid user'
            ) , REST_Controller::HTTP_OK);  

        }


        $user = $this->Users_model->fields('users_fname,users_lname,users_gender,looking_for,from_age,to_age,is_online,users_latitude,users_longitude,is_social,users_dob')->get(['users_id' => $users_id]);
        
        $interested = $this->Users_like_model->fields('like_users_id')->get_all(['users_id' => $users_id]);

        $blocked = $this->Users_block_model->fields('blocked_users_id')->get_all(['block_status' => '1','users_id' => $users_id]);
        $filterdata = [];
        $string = [];
        $string[] = $users_id;
        if ($blocked) {

            foreach($blocked as $value) {

                $string[] = $value->blocked_users_id;

            }

        }

        if ($interested) {

            foreach($interested as $value) {

                $string[] = $value->like_users_id;

            }

        }

        if ($string != "") {

            $string = implode(",", $string);

            $string = $string . ',' . $users_id;

            $filterdata['string'] = $string;
            
        }else{

            $filterdata['string'] = $users_id;
        }

        

        $lat = $user->users_latitude;

        $long = $user->users_longitude;

        $filterdata["users_id"] = $users_id;

        if ($lat != "" && $long != "") {

            $where_distance = " ,( 3959 * acos( cos( radians($lat) ) * cos( radians( users_latitude ) ) * cos( radians( users_longitude ) - radians($long) ) + sin( radians($lat) ) * sin( radians( users_latitude ) ) ) ) AS distance ";

            $filterdata['where_distance'] = $where_distance;
             
        }
        else {

            $where_distance = "";

        }

        $from_age = $user->from_age;

        $to_age = $user->to_age;

        if ($from_age != "" && $to_age != "") {

            $filterdata['from_age'] = $from_age;

            $filterdata['to_age'] = $to_age;

        }
        else{

            $filterdata['from_age'] = "";

            $filterdata['to_age'] = "";
        }

        if ($user->looking_for != "" && $user->looking_for != 'Male & Female') {

            $looking_for = $user->looking_for;

            $filterdata['looking_for'] = $looking_for;   

        }
            
        $this->db->where_in('preference_id', [1,2]);
        $preferencesObj = $this->Preferences_model->get_all();
        $preferences = [];
        foreach ($preferencesObj as $preference) {
            $preferences[] = $preference->preferences_option_id;
        }
        
         $this->db->where('users_id',$users_id);
        $num_pref = $this->db->get('user_preference')->num_rows();


        $total_rows = $this->Filter_model->cardviewNumRows($filterdata, $preferences, $num_pref);

        $users = $this->Filter_model->cardviewResult( $filterdata,$preferences, $page,$perPage, $num_pref);

        $users_data = '';

        if(!empty($users)){

            foreach($users as $key => $value) {
                
                $profile_user_id = $value->users_id;

                $percentage = $this->Users_model->userPerecentage($users_id, $profile_user_id);
                $likes = $this->User_interest_model->mutualInteres($users_id,$profile_user_id);

               /* $likes = $this->User_interest_model->fields('fb_like_id,name')->get_all(['users_id' => $profile_user_id]);*/

                if (empty($likes)) {

                    $users[$key]->interest = [];

                }
                else {

                    $users[$key]->interest = $likes;

                }

                $users[$key]->percentage = $percentage;

                if ($users[$key]->percentage == "") {

                    $users[$key]->percentage = "0";

                }

              
                $profile_user_id = $value->users_id;

                $profile = $this->User_images_model->get(['users_id' => $profile_user_id, 'is_primary' => '1']);

                if (!empty($profile->user_img)) {

                    $users[$key]->users_img = base_url() . 'uploads/users/' . $profile->user_img;

                }
                else {

                    $users[$key]->users_img = "";

                }

                
            }
            
        }else{

            $users = [];

            $total_rows = 0;

        }

        $infoCompleted = checkComplited($user);

        if(empty($users)){

        $this->response(array(
            'status' => FALSE,
            'message' => 'No data found',
            'infocompleted'=>$infoCompleted
        ) , REST_Controller::HTTP_OK);

        }else{

        _trackUser(TRUE, 'Special Match', TRUE, $users_id); // user logs
        $this->response(array(
            'status' => TRUE,
            'message' => 'Special Match',
            'users' => $users,
            'total_rows'=>$total_rows,
            'infocompleted'=>$infoCompleted
        ) , REST_Controller::HTTP_OK);

        }

    }


    /**
     * Reset Dislike user
     * @param users_id
     * @return response
     */
    public function reset_post()
    {
        $this->load->model('Users_like_model');
        $users_id = $this->post('users_id');
        $this->db->where('users_id', $users_id);
        $this->db->where('like_status', '0');
        $response = $this->Users_like_model->delete();
        _trackUser(TRUE, "Filter reset successfully", TRUE, $users_id);
        $this->response(array(
            'status' => TRUE,
            'message' => 'Filter reset successfully'
        ) , REST_Controller::HTTP_OK);
    }

    /**
     * Last Online user list
     * @param $users_id,$page
     * @return response
     */
    public function lastOnline_get()
    {
        $users_id = $this->get('users_id');
        $page = $this->get('page');
        $perPage = "10";
        if(!$this->checkuserId($users_id)) {   

            $this->response(array(
                'status' => FALSE,
                'message' => 'User not found',
                'userstatus' => FALSE ,
            ) , REST_Controller::HTTP_OK);  

        }
        $userdetails = $this->Users_model->fields("users_fname,users_lname,users_location,country,from_age,to_age,users_latitude,users_longitude,looking_for,saved_height,users_id,users_gender,is_social,users_dob")->get(["users_id" => $users_id]);
        $interested = $this->Users_like_model->fields('like_users_id')->get_all([ 'users_id' => $users_id]);
        $blocked = $this->Users_block_model->fields('blocked_users_id')->get_all(['block_status' => '1', 'users_id' => $users_id]);
        $string = [];
        $string[] = $users_id;
        if ($blocked) {
            foreach($blocked as $value) {
                $string[] = $value->blocked_users_id;
            }
        }

        if ($interested) {
            foreach($interested as $value) {
                $string[] = $value->like_users_id;
            }
        }

        if ($string != "") {
            $string = implode(",", $string);
            $where_in = " users.users_id NOT IN ($string) ";
        }
        else {
            $where_in = "";
        }

        $filterOption = $this->Filter_preference_model->fields('preference_id,saved_option')->get_all(['users_id'=>$users_id,"saved_option !="=>""]);


           $where_pref = "";
        if(!empty($filterOption)){
             $i = 0;
             $where_pref = " (";
            foreach ($filterOption as $rows) {
                $pref_opt = $rows->saved_option;
                $pref_opt = explode(",", $pref_opt);

                foreach ($pref_opt as $key => $value) {
                       if ($i == 0) {

                    $where_pref.= " preference_option_id=$value";

                }
                else {

                    $where_pref.= " OR preference_option_id=$value";

                }
                 
                $i++; 

                }
                
                # code...
            }
            $where_pref .= " ) ";
           
        }


         


        $total_rows = $this->Filter_model->lastOnlineUserListNumRows($userdetails, $where_in,$where_pref);

        $users = $this->Filter_model->lastOnlineUserList($userdetails, $where_in,$where_pref, $page, $perPage);
        foreach($users as $key => $value) {
            $profile_user_id = $value->users_id;
            $percentage = $this->Users_model->userPerecentage($users_id, $profile_user_id);
            $users[$key]->percentage = $percentage;
            if ($users[$key]->percentage == "") {
                $users[$key]->percentage = "0";
            }

            $profile = $this->User_images_model->get(['users_id' => $profile_user_id, 'is_primary' => '1']);
           if (!empty($profile->user_img)) {
                $users[$key]->users_img = base_url() . 'uploads/users/' . $profile->user_img;
            }
            else {
                $users[$key]->users_img = "";
            }
        }

        $infoCompleted = checkComplited($userdetails);

        if (empty($users)) {
            $this->response(array(
                'status' => FALSE,
                'message' => 'No data found',
                'infocompleted'=>$infoCompleted
            ) , REST_Controller::HTTP_OK);
        }
        else {
            _trackUser(TRUE, "User visit last joined user list", TRUE, $users_id);
            $this->response(array(
                'status' => TRUE,
                'message' => 'last online user list',
                'users' => $users,
                'total_rows' => $total_rows,
                'infocompleted'=>$infoCompleted
            ) , REST_Controller::HTTP_OK);
        }

        // echo $this->db->last_query();

    }

    /**
     * Get users who are in the same area as loggedin user Area, City, Country
     * @param $users_id
     * @return response array
     */
    public function nearby_get()
    {
        $users_id = $this->get('users_id');
        $page = $this->get('page');
        $perPage = "10";

        /**
        * Check user is exists or not
        */
        if(!$this->checkuserId($users_id)) {   

            $this->response(array(
                'status' => FALSE,
                'message' => 'User not found',
                'userstatus' => FALSE ,
            ) , REST_Controller::HTTP_OK);  

        }

        $userdetails = $this->Users_model->fields("users_fname,users_lname,users_location,country,from_age,to_age,users_latitude,users_longitude,looking_for,saved_height,users_id,users_gender,is_social,users_dob")->get(["users_id" => $users_id]);

        // Blocked and Dislike users

        $interested = $this->Users_like_model->fields('like_users_id')->get_all([ 'users_id' => $users_id]);
        $blocked = $this->Users_block_model->fields('blocked_users_id')->get_all(['block_status' => '1', 'users_id' => $users_id]);
        $string = [];
        $string[] = $users_id;
        if ($blocked) {
            foreach($blocked as $value) {
                $string[] = $value->blocked_users_id;
            }
        }

        if ($interested) {
            foreach($interested as $value) {
                $string[] = $value->like_users_id;
            }
        }

        if ($string != "") {
            $string = implode(",", $string);
            $string = $string . ',' . $users_id;
            $where_in = " users.users_id NOT IN ($string) ";
        }
        else {
            $where_in = "";
        }

         $filterOption = $this->Filter_preference_model->fields('preference_id,saved_option')->get_all(['users_id'=>$users_id,"saved_option !="=>""]);


           $where_pref = "";
        if(!empty($filterOption)){
             $i = 0;
             $where_pref = " (";
            foreach ($filterOption as $rows) {
                $pref_opt = $rows->saved_option;
                $pref_opt = explode(",", $pref_opt);

                foreach ($pref_opt as $key => $value) {
                       if ($i == 0) {

                    $where_pref.= " preference_option_id=$value";

                }
                else {

                    $where_pref.= " OR preference_option_id=$value";

                }
                 
                $i++; 

                }
                
                # code...
            }
            $where_pref .= " ) ";
           
        }



        $total_rows = $this->Filter_model->nearByNumrows($userdetails, $where_in,$where_pref);

        $users = $this->Filter_model->nearBy($userdetails, $where_in,$where_pref, $page, $perPage);
        foreach($users as $key => $value) {
            $profile_user_id = $value->users_id;
            $percentage = $this->Users_model->userPerecentage($users_id, $profile_user_id);
            $users[$key]->percentage = $percentage;
            if ($users[$key]->percentage == "") {
                $users[$key]->percentage = "0";
            }

            $profile = $this->User_images_model->get(['users_id' => $profile_user_id, 'is_primary' => '1']);
            if (!empty($profile->user_img)) {
                $users[$key]->users_img = base_url() . 'uploads/users/' . $profile->user_img;
            }
            else {
                $users[$key]->users_img = "";
            }
        }

        $infoCompleted = checkComplited($userdetails);


        if (empty($users)) {
            $this->response(array(
                'status' => FALSE,
                'message' => 'No data found',
                'infocompleted'=>$infoCompleted
            ) , REST_Controller::HTTP_OK);
        }
        else {
            _trackUser(TRUE, "User visit near by user list", TRUE, $users_id);
            $this->response(array(
                'status' => TRUE,
                'message' => 'Near by user list',
                'users' => $users,
                'total_rows' => $total_rows,
                'infocompleted'=>$infoCompleted
            ) , REST_Controller::HTTP_OK);
        }
    }

    /**
     * User list that were lastly Joined
     * @param $users_id
     * @return response array
     */
    public function lastJoined_get()
    {
        $users_id = $this->get('users_id');
        $page = $this->get('page');
        $perPage = "10";

        if(!$this->checkuserId($users_id)) {   

            $this->response(array(
                'status' => FALSE,
                'message' => 'User not found',
                'userstatus' => FALSE ,
            ) , REST_Controller::HTTP_OK);  

        }

        $userdetails = $this->Users_model->fields("users_fname,users_lname,users_location,country,from_age,to_age,users_latitude,users_longitude,looking_for,saved_height,users_gender,is_social,users_dob")->get(["users_id" => $users_id]);

        // Blocked and Dislike users

        $interested = $this->Users_like_model->fields('like_users_id')->get_all([ 'users_id' => $users_id]);
        $blocked = $this->Users_block_model->fields('blocked_users_id')->get_all(['block_status' => '1', 'users_id' => $users_id]);
        $string = [];
        $string[] = $users_id;
        if ($blocked) {
            foreach($blocked as $value) {
                $string[] = $value->blocked_users_id;
            }
        }

        if ($interested) {
            foreach($interested as $value) {
                $string[] = $value->like_users_id;
            }
        }

        if ($string != "") {
            $string = implode(",", $string);
            $string = $string . ',' . $users_id;
            $where_in = " users.users_id NOT IN ($string) ";
        }
        else {
            $where_in = "";
        }

        //

        $filterOption = $this->Filter_preference_model->fields('preference_id,saved_option')->get_all(['users_id'=>$users_id,"saved_option !="=>""]);


           $where_pref = "";
        if(!empty($filterOption)){
             $i = 0;
             $where_pref = " (";
            foreach ($filterOption as $rows) {
                $pref_opt = $rows->saved_option;
                $pref_opt = explode(",", $pref_opt);

                foreach ($pref_opt as $key => $value) {
                       if ($i == 0) {

                    $where_pref.= " preference_option_id=$value";

                }
                else {

                    $where_pref.= " OR preference_option_id=$value";

                }
                 
                $i++; 

                }
                
                # code...
            }
            $where_pref .= " ) ";
           
        }


        //

        $total_rows = $this->Filter_model->lastJoinedUsersNumrows($userdetails, $where_in,$where_pref);

        $users = $this->Filter_model->lastJoinedUsers($userdetails, $where_in,$where_pref, $page, $perPage);

        foreach($users as $key => $value) {
            $profile_user_id = $value->users_id;
            $percentage = $this->Users_model->userPerecentage($users_id, $profile_user_id);
            $users[$key]->percentage = $percentage;
            if ($users[$key]->percentage == "") {
                $users[$key]->percentage = "0";
            }            

            $profile = $this->User_images_model->get(['users_id' => $profile_user_id, 'is_primary' => '1']);
           if (!empty($profile->user_img)) {
                $users[$key]->users_img = base_url() . 'uploads/users/' . $profile->user_img;
            }
            else {
                $users[$key]->users_img = "";
            }
        }

        $infoCompleted = checkComplited($userdetails);

        if (empty($users)) {
            $this->response(array(
                'status' => FALSE,
                'message' => 'No data found',
                'infocompleted'=>$infoCompleted
            ) , REST_Controller::HTTP_OK);
        }
        else {
            _trackUser(TRUE, "User visit last joined user list", TRUE, $users_id);
            $this->response(array(
                'status' => TRUE,
                'message' => 'last joined user list',
                'users' => $users,
                'total_rows' => $total_rows,
                'infocompleted'=>$infoCompleted
            ) , REST_Controller::HTTP_OK);
        }

       
    }



     /**
    * Card view users list api
    * method get
    * @param $users_id,$page
    * @return response users list
    */
    function cardView_get(){
       
        $this->load->model('User_interest_model');

        $filterdata = [];
        $users_id = $this->get('users_id');

        $page = $this->get('page');

        if ($page == "" || $page < 1) {

            $page = "0";

        }

        $perPage = "10";

        if(!$this->checkuserId($users_id)) {   

            $this->response(array(
                'status' => FALSE,
                'message' => 'User not found',
                'userstatus' => FALSE ,
            ) , REST_Controller::HTTP_OK);  

        }

        // delete a matches which is disliked by users
        $matches  = $this->Users_model->fields('users_id')->where(['more_matches_status'=>'1'])->get_all();

        foreach ($matches as $rows) {
            $like_users_id = $rows->users_id;
            $more_matches_id[] = $rows->users_id;
            $this->db->where(['users_id'=>$users_id,'like_users_id'=>$like_users_id,'like_status'=>'0']);
            $this->Users_like_model->delete();
        }


        $user = $this->Users_model->fields('users_gender,looking_for,from_age,to_age,is_online,users_latitude,users_longitude,users_fname,users_lname,users_dob,is_social,users_dob')->get(['users_id' => $users_id]);
        
        $interested = $this->Users_like_model->fields('like_users_id')->get_all(['users_id' => $users_id]);

        $blocked = $this->Users_block_model->fields('blocked_users_id')->get_all(['block_status' => '1','users_id' => $users_id]);
        
        $string = [];
        $string[] = $users_id;
        if ($blocked) {

            foreach($blocked as $value) {

                $string[] = $value->blocked_users_id;

            }

        }

        if ($interested) {

            foreach($interested as $value) {

                $string[] = $value->like_users_id;

            }

        }

        if ($string != "") {

            $string = implode(",", $string);

            $string = $string . ',' . $users_id;

            $filterdata['string'] = $string;
            
        }else{

            $filterdata['string'] = $users_id;
        }

        

        $lat = $user->users_latitude;

        $long = $user->users_longitude;

        $filterdata["users_id"] = $users_id;

        if ($lat != "" && $long != "") {

            $where_distance = " ,( 3959 * acos( cos( radians($lat) ) * cos( radians( users_latitude ) ) * cos( radians( users_longitude ) - radians($long) ) + sin( radians($lat) ) * sin( radians( users_latitude ) ) ) ) AS distance ";

            $filterdata['where_distance'] = $where_distance;
             
        }
        else {

            $where_distance = "";

        }

        $from_age = $user->from_age;

        $to_age = $user->to_age;

        if ($from_age != "" && $to_age != "") {

            $filterdata['from_age'] = $from_age;

            $filterdata['to_age'] = $to_age;

        }
        else{

            $filterdata['from_age'] = "";

            $filterdata['to_age'] = "";
        }

        if ($user->looking_for != "" && $user->looking_for != 'Male & Female') {

            $looking_for = $user->looking_for;

            $filterdata['looking_for'] = $looking_for;   

        }
            
        $this->db->where_in('preference_id', [1,2]);
        $preferencesObj = $this->Preferences_model->get_all();
        $preferences = [];
        foreach ($preferencesObj as $preference) {
            $preferences[] = $preference->preferences_option_id;
        }
         $this->db->where('users_id',$users_id);
        $num_pref = $this->db->get('user_preference')->num_rows();

        $total_rows = $this->Filter_model->cardviewNumRows($filterdata, $preferences,$num_pref);

        $users = $this->Filter_model->cardviewResult( $filterdata,$preferences, $page,$perPage,$num_pref);

        $users_data = '';

        if(!empty($users)){

            foreach($users as $key => $value) {
                
                $profile_user_id = $value->users_id;

                $percentage = $this->Users_model->userPerecentage($users_id, $profile_user_id);

               /* $likes = $this->User_interest_model->fields('fb_like_id,name')->get_all(['users_id' => $profile_user_id]);*/
               $likes = $this->User_interest_model->mutualInteres($users_id,$profile_user_id);

                if (empty($likes)) {

                    $users[$key]->interest = [];

                }
                else {

                    $users[$key]->interest = $likes;

                }

                $users[$key]->percentage = $percentage;

                if ($users[$key]->percentage == "") {

                    $users[$key]->percentage = "0";

                }

              
                $profile_user_id = $value->users_id;

                $profile = $this->User_images_model->get(['users_id' => $profile_user_id, 'is_primary' => '1']);

                if (!empty($profile->user_img)) {

                    $users[$key]->users_img = base_url() . 'uploads/users/' . $profile->user_img;

                }
                else {

                    $users[$key]->users_img = "";

                }

                
            }
            
        }else{

            $users = [];

            $total_rows = 0;

        }

        $users = shuffle_assoc($users);
       
        $infoCompleted = checkComplited($user);

        if(empty($users)){

        $this->response(array(
            'status' => FALSE,
            'message' => 'No data found',
            'infocompleted'=>$infoCompleted
        ) , REST_Controller::HTTP_OK);

        }else{

        _trackUser(TRUE, 'Card View', TRUE, $users_id); // user logs
        $this->response(array(
            'status' => TRUE,
            'message' => 'Card View',
            'users' => $users,
            'total_rows'=>$total_rows,
            'infocompleted'=>$infoCompleted
        ) , REST_Controller::HTTP_OK);

        }

    }


    /**
    * 
    * 
    *
    */
    function matching_get(){

      
        

        $this->load->model('User_interest_model');

        $filterdata = [];
        $users_id = $this->get('users_id');

        $page = $this->get('page');

        if ($page == "" || $page < 1) {

            $page = "0";

        }

        $perPage = "10";

        if(!$this->checkuserId($users_id)) {

            $this->response(array(
                'status' => FALSE,
                'message' => 'Invalid user'
            ) , REST_Controller::HTTP_OK);

        }


        $user = $this->Users_model->fields('users_gender,looking_for,from_age,to_age,is_online,users_latitude,users_longitude,saved_height,users_fname,users_lname,users_dob,is_social')->get(['users_id' => $users_id]);

        $interested = $this->Users_like_model->fields('like_users_id')->get_all(['users_id' => $users_id]);

        $blocked = $this->Users_block_model->fields('blocked_users_id')->get_all(['block_status' => '1','users_id' => $users_id]);

        $string = [];
        $string[] = $users_id;
        if ($blocked) {

            foreach($blocked as $value) {

                $string[] = $value->blocked_users_id;

            }

        }

        if ($interested) {

            foreach($interested as $value) {

                $string[] = $value->like_users_id;

            }

        }

        if ($string != "") {

            $string = implode(",", $string);

            $filterdata['string'] = $string;
            
        }else{

            $filterdata['string'] = "";
        }

        

        $lat = $user->users_latitude;

        $long = $user->users_longitude;

        $filterdata["users_id"] = $users_id;

        if ($lat != "" && $long != "") {

            $where_distance = " ,( 3959 * acos( cos( radians($lat) ) * cos( radians( users_latitude ) ) * cos( radians( users_longitude ) - radians($long) ) + sin( radians($lat) ) * sin( radians( users_latitude ) ) ) ) AS distance ";

            $filterdata['where_distance'] = $where_distance;
             
        }
        else {

            $where_distance = "";

        }

        $from_age = $user->from_age;

        $to_age = $user->to_age;

        if ($from_age != "" && $to_age != "") {

            $filterdata['from_age'] = $from_age;

            $filterdata['to_age'] = $to_age;

        }
        else{

            $filterdata['from_age'] = "";

            $filterdata['to_age'] = "";
        }

        if ($user->looking_for != "" && $user->looking_for != "Male & Female") {

            $looking_for = $user->looking_for;

            $filterdata['looking_for'] = $looking_for;   

        }
         $filterOption = $this->Filter_preference_model->fields('preference_id,saved_option')->get_all(['users_id'=>$users_id,"saved_option !="=>""]);


           $filterdata['where_pref'] = "";
        if(!empty($filterOption)){
            $where_pref = "";
             $i = 0;
             $where_pref = " (";
            foreach ($filterOption as $rows) {
                $pref_opt = $rows->saved_option;
                $pref_opt = explode(",", $pref_opt);

                foreach ($pref_opt as $key => $value) {
                       if ($i == 0) {

                    $where_pref.= " preference_option_id=$value";

                }
                else {

                    $where_pref.= " OR preference_option_id=$value";

                }
                 
                $i++; 

                }
                
                # code...
            }
            $where_pref .= " ) ";

            $filterdata["where_pref"] = $where_pref;
           
        }

        if($user->saved_height!=""){

            $heights = explode("To", $user->saved_height);

            $filterdata["from_height"] = $heights[0];

            $filterdata["to_height"] = $heights[1];
            
        }else{
            $filterdata["from_height"] = "";

            $filterdata["to_height"] = "";

        }


        $this->db->where('users_id',$users_id);
        $num_pref = $this->db->get('user_preference')->num_rows();
         $this->db->where_in('preference_id', [1,2]);
        $preferencesObj = $this->Preferences_model->get_all();
        $preferences = [];
        foreach ($preferencesObj as $preference) {
            $preferences[] = $preference->preferences_option_id;
        }
            
        $total_rows = $this->Filter_model->matchingNumRows( $filterdata,$preferences,$num_pref);

        $users = $this->Filter_model->matchingResult( $filterdata,$preferences,$page,$perPage,$num_pref);

        $users_data = '';

        if(!empty($users)){

            foreach($users as $key => $value) {

                $location = $value->users_location; // location city id

                $loc_array = $this->Location_model->get(['location_id' => $location]);

                  if(!empty($loc_array)){
                $users[$key]->users_location = $loc_array->name; // location name
                }else{
                    $users[$key]->users_location = "";
                }

                $profile_user_id = $value->users_id;

                $percentage = $this->Users_model->userPerecentage($users_id, $profile_user_id);

                $likes = $this->User_interest_model->fields('fb_like_id,name')->get_all(['users_id' => $profile_user_id]);

                if (empty($likes)) {

                    $users[$key]->interest = [];

                }
                else {

                    $users[$key]->interest = $likes;

                }

                $users[$key]->percentage = $percentage;

                if ($users[$key]->percentage == "") {

                    $users[$key]->percentage = "0";

                }

                $profile_user_id = $value->users_id;

                $profile = $this->User_images_model->get(['users_id' => $profile_user_id, 'is_primary' => '1']);

                if (!empty($profile->user_img)) {

                    $users[$key]->users_img = base_url() . 'uploads/users/' . $profile->user_img;

                }
                else {

                    $users[$key]->users_img = "";

                }

                if ($users[$key]->self_summery == "") {

                    $users[$key]->self_summery = "";

                }
            }

        }else{

            $users = [];

            $total_rows = 0;

        }

     
        $infoCompleted = checkComplited($user);

        if(empty($users)){

        $this->response(array(
            'status' => FALSE,
            'message' => 'No data found',
            'infocompleted'=>$infoCompleted
        ) , REST_Controller::HTTP_OK);
        
        }else{

        $users = $this->multid_sort($users, 'percentage');

        _trackUser(TRUE, 'Match % users list', TRUE, $users_id); // user logs
        
        $this->response(array(
            'status' => TRUE,
            'message' => 'Match % users list',
            'users' => $users,
            'total_rows'=>$total_rows,
            'infocompleted'=>$infoCompleted
        ) , REST_Controller::HTTP_OK);

        }
    }


    /**
    * Check user exists or not
    * @param $id user id
    * @return bool
    */
    public function checkuserId($id){
        $result = $this->Users_model->get(['users_id' => $id,
                                            'users_status'=>'1'
                                            ]);
        if ($result) {
            return TRUE;
        }
        else {
            return FALSE;
        }
    }



     /**
    * Card view users list api
    * method get
    * @param $users_id,$page
    * @return response users list
    */
    function getMorevisits_get(){
       
        $this->load->model('User_interest_model');

        $filterdata = [];

        $users_id = $this->get('users_id');

        

        if(!$this->checkuserId($users_id)) {   

            $this->response(array(
                'status' => FALSE,
                'message' => 'User not found',
                'userstatus' => FALSE ,
            ) , REST_Controller::HTTP_OK);  

        }


        /*$this->db->select('promoted_users_id');
        $promoted_users = $this->db->get('promoted_users')->result();

        if(!empty($promoted_users)){

        
        if ($promoted_users) {

            foreach($promoted_users as $value) {

                $promoted[] = $value->promoted_users_id;

            }

        }
        
            $filterdata['promoted'] = implode(",", $promoted);
            
        }else{

             $this->response(array(
                'status' => FALSE,
                'message' => 'Data not found',
                'userstatus' => FALSE ,
            ) , REST_Controller::HTTP_OK);  
        }
*/


        $user = $this->Users_model->fields('users_gender,looking_for,from_age,to_age,is_online,users_latitude,users_longitude,users_fname,users_lname,users_dob,is_social,users_dob')->get(['users_id' => $users_id]);
        
        $interested = $this->Users_like_model->fields('like_users_id')->get_all(['users_id' => $users_id]);

        $blocked = $this->Users_block_model->fields('blocked_users_id')->get_all(['block_status' => '1','users_id' => $users_id]);
        
        $string = [];
        $string[] = $users_id;
        if ($blocked) {

            foreach($blocked as $value) {

                $string[] = $value->blocked_users_id;

            }

        }

        if ($interested) {

            foreach($interested as $value) {

                $string[] = $value->like_users_id;

            }

        }

        if ($string != "") {

            $string = implode(",", $string);

            $string = $string . ',' . $users_id;

            $filterdata['string'] = $string;
            
        }else{

            $filterdata['string'] = $users_id;
        }

        

        $filterdata["users_id"] = $users_id;

        $filterdata['looking_for'] = "";

        if ($user->looking_for != "" && $user->looking_for != 'Male & Female') {

            $looking_for = $user->looking_for;

            $filterdata['looking_for'] = $looking_for;   

        }

        if($user->users_latitude!="" && $user->users_longitude!=""){
            $filterdata['lat'] = $user->users_latitude;   
            $filterdata['long'] = $user->users_longitude;   
        }
            
        
       
       /* $users = $this->Filter_model->getMoreVisitsResult( $filterdata);*/

        $users = $this->Filter_model->getMoreVisitsResult( $filterdata);
        if(count($users) > 0){
        $move_top_id = [];
        foreach ($users as $rows) {

            $move_top_id[] = $rows->users_id;

        }

        if(!empty($move_top_id)){
            $move_top_id = implode(",", $move_top_id);        
        }

        $users = $this->Filter_model->moveTotop($filterdata,$move_top_id);
       
        }

       /* foreach ($users as $rows) {
            $this->db->insert();
        }*/

        $users_data = '';

        if(!empty($users)){

            foreach($users as $key => $value) {
                
                $profile_user_id = $value->users_id;

                $percentage = $this->Users_model->userPerecentage($users_id, $profile_user_id);

               /* $likes = $this->User_interest_model->fields('fb_like_id,name')->get_all(['users_id' => $profile_user_id]);*/
               $likes = $this->User_interest_model->mutualInteres($users_id,$profile_user_id);

                if (empty($likes)) {

                    $users[$key]->interest = [];

                }
                else {

                    $users[$key]->interest = $likes;

                }

                $users[$key]->percentage = $percentage;

                if ($users[$key]->percentage == "") {

                    $users[$key]->percentage = "0";

                }

              
                $profile_user_id = $value->users_id;

                $profile = $this->User_images_model->get(['users_id' => $profile_user_id, 'is_primary' => '1']);

                if (!empty($profile->user_img)) {

                    $users[$key]->users_img = base_url() . 'uploads/users/' . $profile->user_img;

                }
                else {

                    $users[$key]->users_img = "";

                }

                $view_count = ($value->view_count+1);
                $count_users_id = $value->users_id;
                $this->db->where(['users_id'=>$count_users_id]);
                $this->Users_model->update(['view_count'=>$view_count]);

                
            }
            
        }else{

            $users = [];

            $total_rows = 0;

        }
       
        if(empty($users)){

        $this->response(array(
            'status' => FALSE,
            'message' => 'No data found'            
        ) , REST_Controller::HTTP_OK);

        }else{

        _trackUser(TRUE, 'Get more visits', TRUE, $users_id); // user logs
        $this->response(array(
            'status' => TRUE,
            'message' => 'Get more visits',
            'users' => $users,            
        ) , REST_Controller::HTTP_OK);

        }

    }


    
    /**
    * Sorting array index wise
    * @param $arr as array, and $index as key
    * @return sorted array
    */
    function multid_sort($arr, $index) {
        $b = array();
        $c = array();
        foreach ($arr as $key => $value) {
            $b[$key] = $value->$index;
        }

        arsort($b);

        foreach ($b as $key => $value) {
            $c[] = $arr[$key];
        }

        return $c;
    }



    
}