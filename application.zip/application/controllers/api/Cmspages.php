<?php

defined('BASEPATH') OR exit('No direct script access allowed ');

require APPPATH . '/libraries/REST_Controller.php';

class cmspages extends REST_Controller{

    function __construct() {
        parent::__construct(); 
        $this->load->model('Cms_pages_model');
        $this->load->model('Users_model');
    }



    /**
    * Feedback from app
    * @param $subject,$description
    * @return response boolean
    */
    public function feedBack_post(){
    	$users_id  = $this->post('users_id');

          $valid = $this->checkuserId($users_id);
        if($valid){


    	$subject = $this->post('subject');

    	$userdata = $this->Users_model->get($users_id);


    	$description = "Name : ".$userdata->users_fname. ' ' .$userdata->users_lname."<br>";
		$description .=	"Email : ".$userdata->users_email."<br>";

        $description .= "Subject : ".$subject."<br>";
        
    	$description .= $this->post('description');

    	$feedback_email = websitedata('feedback_email');

    	$config = emailconfig();
        $this->load->library('email',$config);       
        $this->email->set_newline("\r\n");
        $this->email->from('no-reply@snackdating.com', websitedata('site_name'));
        $this->email->to($feedback_email);
        $this->email->subject('Feedback');
        $this->email->message($description);

        try {
                if ($this->email->send()) {

                    _trackUser(TRUE, 'Sent Feedback', TRUE, $users_id); // user logs
    				$this->response(array(
    				                    'status' => TRUE,
    				                    'message' => 'Thank you for your valuable feedback'
    				                ) , REST_Controller::HTTP_OK);
                }
                else{
                    
                    _trackUser(TRUE, 'error while send feedback', TRUE, $users_id); // user logs
    				$this->response(array(
    				                    'status' => FALSE,
    				                    'message' => 'error while send feedback'
    				                ) , REST_Controller::HTTP_OK);
                }

            } catch (Exception $e) {

                    _trackUser(TRUE, 'error while send feedback', TRUE, $users_id); // user logs
                    $this->response(array(
				                    'status' => FALSE,
				                    'message' => 'error while send feedback'
				    ) , REST_Controller::HTTP_OK);
       		}

         }else{
                  $this->response(array(
                                    'status' => FALSE,
                                    'message' => 'User not found'
                    ) , REST_Controller::HTTP_OK);
        }


    }




    /**
    * CMS pages list title and id
    * @param $users_id 
    * @return response id and title of pages in object
    */
    function pagesList_post(){
        $users_id = $this->post('users_id');
        $this->db->where('cms_status','1');
        $cms =    $this->Cms_pages_model->fields('cms_id,cms_title')->get_all();

        if($cms){

                    $this->response(array(
                                    'status' => TRUE,
                                    'message' => 'Pages list',
                                    'pages'=>$cms,
                                ) , REST_Controller::HTTP_OK);
        }
        else{
                    $this->response(array(
                                    'status' => TRUE,
                                    'message' => 'No record found'
                                ) , REST_Controller::HTTP_OK);   
        }


    }



    /**
    * Single page data
    * @param $page_id and $users_id
    * @return response page data
    */
    function pageDetails_post(){
        $page_id = $this->post('page_id');
         $page = $this->Cms_pages_model->fields('cms_id,cms_title,cms_content')->get(['cms_id'=>$page_id]);

         $title = $page->cms_title;

        if($page){

                  _trackUser(TRUE, "User visit ".$title." page details", TRUE, $users_id); // user logs

                    $this->response(array(
                                    'status' => TRUE,
                                    'message' => 'Pages list',
                                    'page'=>$page,
                                ) , REST_Controller::HTTP_OK);

        }
        else{
                    $this->response(array(
                                    'status' => TRUE,
                                    'message' => 'No record found'
                                ) , REST_Controller::HTTP_OK);   
        }

    }




    /**
    * Check user exists or not
    * @param $id user id
    * @return bool
    */
    public function checkuserId($id){
        $result = $this->Users_model->get(['users_id' => $id,
                                            'users_status'=>'1'
                                            ]);
        if ($result) {
            return TRUE;
        }
        else {
            return FALSE;
        }
    }


}