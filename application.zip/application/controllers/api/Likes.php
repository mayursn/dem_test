<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . '/libraries/REST_Controller.php';

class Likes extends REST_Controller

{
    
    /**
     * Constructor
     *
     *  @return void
     */
    public function __construct(){
        parent::__construct();    

        $this->load->model('Users_like_model');
        $this->load->model('User_images_model');
        $this->load->model('Users_model');
        $this->load->model('Location_model');


    }


    /**
    * Get List Loggedin user Like other users 
    * @param users_id
    * @return response json array
    */
    public function youLike_get(){
        $users_id = $this->get('users_id');
        $page = $this->get('page');
        $perPage = "10";

        $total_rows = $this->Users_like_model->userLikeListNumRows($users_id);

        $usersLike = $this->Users_like_model->userLikeList($users_id,$page,$perPage);

        foreach ($usersLike as $key => $value) {
            $profile_user_id = $value->users_id;
                $profile = $this->User_images_model->get(['users_id' => $profile_user_id, 'is_primary' => '1']);

                if ($profile->user_img != "") {

                    $usersLike[$key]->users_img = base_url() . 'uploads/users/' . $profile->user_img;

                }
                else {

                    $usersLike[$key]->users_img = "";

                }


        }

            if(count($usersLike)){

                _trackUser(TRUE, "user seen like list", TRUE, $users_id);

                $this->response(array('status' => TRUE,'message' => 'your like list',"likes"=>$usersLike,"total_rows"=>$total_rows), REST_Controller::HTTP_OK);

            }
            else{

                _trackUser(TRUE, "user like list", TRUE, $users_id);

                $this->response(array('status' => FALSE,'message' => 'No data found'), REST_Controller::HTTP_OK);   

            }         
    }


    /**
    * Get user list who likes loggedin user
    * @param user_id
    * @return response
    */
    public function userLikeYou_get(){

        $users_id = $this->get('users_id');
        $page = $this->get('page');
        $perPage = '10';
        $total_rows = $this->Users_like_model->userLikeYouListNumRows($users_id);
        $users = $this->Users_like_model->userLikeYouList($users_id,$page,$perPage);
          foreach ($users as $key => $value) {
            $profile_user_id = $value->users_id;
                $profile = $this->User_images_model->get(['users_id' => $profile_user_id, 'is_primary' => '1']);

                if ($profile->user_img != "") {

                    $users[$key]->users_img = base_url() . 'uploads/users/' . $profile->user_img;

                }
                else {

                    $users[$key]->users_img = "";

                }
        }
        if(count($users)){
                _trackUser(TRUE, "User check like list", TRUE, $users_id);
                $this->response(array('status' => TRUE,'message' => 'User list who likes you',"likes"=>$users,"total_rows"=>$total_rows), REST_Controller::HTTP_OK);
            }
            else{
                _trackUser(TRUE, "User check like list", TRUE, $users_id);
               $this->response(array('status' => FALSE,'message' => 'No data found'), REST_Controller::HTTP_OK);  
            }  
    }



     /**
    * Get mutual like user list
    * @param users_id
    * @return response
    */
    public function mutualLikes_get(){
        $users_id = $this->get('users_id');
        $page = $this->get('page');
        $perPage = 10;
        
        $total_rows = $this->Users_like_model->mutualLikeListNumRows($users_id);
        $users = $this->Users_like_model->mutualLikeList($users_id,$page,$perPage);
        /*echo "<pre>";
        print_r($users);
        echo "</pre>";
        exit;*/

         foreach ($users as $key => $value) {
            $profile_user_id = $value->users_id;

                $profile = $this->User_images_model->get(['users_id' => $profile_user_id, 'is_primary' => '1']);

                if ($profile->user_img != "") {

                    $users[$key]->users_img = base_url() . 'uploads/users/' . $profile->user_img;

                }
                else {

                    $users[$key]->users_img = "";

                }

                if($users[$key]->offline_time!=""){                    
                    $offline_time = strtotime($users[$key]->offline_time);
                    $users[$key]->offline_time = time_ago($offline_time);
                }

        }
      
        if(count($users)){
                _trackUser(TRUE, "Mutual like list", TRUE, $users_id);
                $this->response(array('status' => TRUE,'message' => 'Mutual like list',"likes"=>$users,"total_rows"=>$total_rows), REST_Controller::HTTP_OK);
            }
            else{
                _trackUser(TRUE, "Mutual like list no data found", TRUE, $users_id);
                $this->response(array('status' => FALSE,'message' => 'No data found'), REST_Controller::HTTP_OK);  
            }  
    }


    /**
    * User Like List
    * @param $users_id
    * @return response user list
    */
    function mutualLikesList($users_id){
                
        $details1= $this->Users_like_model->userLike($users_id);

        $details = $this->Users_like_model->OtherUserLike($users_id);
                
        $list = array_merge($details1,$details);
                
        return $list;
            
    }














}