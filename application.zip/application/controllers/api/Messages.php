<?php
defined('BASEPATH') OR exit('No direct script access allowed ');

require APPPATH . '/libraries/REST_Controller.php';

class Messages extends REST_Controller{

    /**
    * Construct function 
    * loaded messages model and users model
    * 
    */

    function __construct() {
        parent::__construct(); 

        $this->load->model('Messages_model');
        $this->load->model('Users_model');
        $this->load->model('Chat_model');
        
        $this->lang->load('message', 'english');
    }


     /**
    *  Send message user to user
    *  Message send if both user like each other
    * @param sender_id and receiver id is users id int
    * @param message varchar
    * @return response array
    */
    function send_post(){

        $this->load->model('Users_block_model');

        $this->load->model('Users_like_model'); // user like model

        $this->load->model('wallet_balance_model'); // init model

        $this->load->model('Credit_function_costs_model');

        $sender_id = $this->post('sender_id');       

        $receiver_id = $this->post('receiver_id'); 

        if(!$this->checkuserId($sender_id)){

            $this->response(
                            array(
                                'status' => FALSE,
                                'message' => "User not found"
                            ) , 
                REST_Controller::HTTP_OK);
        }
        if(!$this->checkuserId($receiver_id)){

            $this->response(
                            array(
                                'status' => FALSE,
                                'message' => "User not found"
                            ) , 
                REST_Controller::HTTP_OK);
        }   

        $blockstatus = $this->Users_block_model->checkBlock($sender_id,$receiver_id);

        if($blockstatus=="1"){

            _trackUser(TRUE, "You blocked this user", TRUE, $sender_id);

            $this->response(array(
                                'status' => FALSE,
                                'message' => 'You blocked this user'
                    ) , REST_Controller::HTTP_OK);  

        }

        if($blockstatus=="2"){

            _trackUser(TRUE, "This user blocked you", TRUE, $sender_id);

            $this->response(array(
                                'status' => FALSE,
                                'message' => 'This user blocked you'
                    ) , REST_Controller::HTTP_OK);  

        }



        $message = $this->post('message');        
        
        //$msg_type = $this->post('msg_type');

        $emoji_flag = $this->post('emoji_flag');

        $res = $this->Users_like_model->getLikedStatus($sender_id,$receiver_id);
       
        $is_mutualfriend = $res['is_mutualfriend'];
        
        if($is_mutualfriend=="1"){

            $msg_type = "mutual";            

        }else{
           
            $msg_type = "direct_message";
        }
       

        if(!isset($emoji_flag)){

            $emoji = "";

            $emoji_flag = '0';
        }

        $user = $this->Users_model->fields('weekly_credits,total_credits,is_invisible')->get($sender_id);

        $this->db->order_by('wallet_id','DESC');
        $wallet = $this->wallet_balance_model->where(['users_id'=>$sender_id])->get();

        if(isset($emoji_flag) && $emoji_flag=="1"){

            $total_credits = $user->total_credits + $user->weekly_credits;

            $costs = $this->Credit_function_costs_model->where(['short_type'=>'emojis'])->get()->credits;
            
            if($total_credits < $costs ){

                $this->response(
                            array(
                                'status' => FALSE,
                                'message' => "You don't have enough credits to send emojis."
                            ) , 
                REST_Controller::HTTP_OK);

            }else{
                
               
                    
                $wallet_data = creditCalculations($user,$wallet,$costs);
                
                $weekly_credits = $wallet_data['weekly_credits'];

                $total_credits = $wallet_data['total_credits'];

                $wallet_balance_total = $wallet_data['wallet_balance_total'];

                /*$total_credits = ($total_credits - $costs);*/

                $user_data  =   [
                                    'weekly_credits'=>$weekly_credits,
                                    'total_credits' => $total_credits
                                ];

                // updating purchased credits 
                $updated = $this->Users_model->update($user_data,$sender_id);

                

                    $data   =   [   
                                    'users_id' =>$sender_id,
                                    'debit_value'=>$costs,
                                    'use_for'=>$this->lang->line('emojis'),                    
                                    'debit_date'=>date('Y-m-d H:i:s'), 
                                    'type'=>'debit',                   
                                    'total_credits'=>$wallet_balance_total
                                ];

                // added data into wallet balance to track the credits and it uses

                $res = $this->wallet_balance_model->insert($data);

            }

        }
       
        if($msg_type=="mutual") : 

        

        $res = $this->Users_like_model->get_orwhere($sender_id,$receiver_id);

        if(!$res){

            _trackUser(TRUE, "No match found with this user", TRUE, $sender_id);

            $this->response(array(
                            'status' => FALSE,
                            'message' => 'No match found with this user'
                    ) , REST_Controller::HTTP_OK);  
        }

        endif; // mutual end if

        // send direct msg credit check

        if($msg_type=="direct_message") :

            $total_credits = ($user->total_credits + $user->weekly_credits);
        

            $credits = $costs = $this->Credit_function_costs_model->where(['short_type'=>'direct_message'])->get()->credits;            

            if($total_credits < $credits){

                $this->response(
                            array(
                                'status' => FALSE,
                                'message' => "You don't have enough credits to send direct message."
                            ) , 
                REST_Controller::HTTP_OK);

            }

        endif;

        $file = @$_FILES['image']['name'];       
            
        if ($file != "") {
                
                $ext = explode(".", $file);

                $imgext = strtolower(end($ext));

                $image = date('dmYhis') . '.' . $imgext;

                $config['upload_path'] = './uploads/messages/';

                $config['allowed_types'] = 'gif|jpg|png|jpeg';

                $config['max_size'] = 0;

                $config['file_name'] = $image;
                
                $this->load->library('upload', $config);
                if (!$this->upload->do_upload('image')) {

                     _trackUser(TRUE, $this->upload->display_errors() , TRUE, $sender_id); // user logs
                    $this->response(['status' => FALSE, 'message' => $this->upload->display_errors() , 'users_id' => $sender_id], REST_Controller::HTTP_OK); // OK (200) Reponse code
                   
                }
                else {

                    $dataimage = array(
                        'upload_data' => $this->upload->data()
                    );
                }
            }
            else{

                $image = '';
        }

        $receiver = $this->Users_model->get($receiver_id);

        $receiver_visibility = $receiver->is_invisible;

        $sender_visibility = $user->is_invisible;
        $start_sender_id = $sender_id;
        $chat_id = $this->post('chat_id');

        if($chat_id!=""){

            $chat = $this->Chat_model->where(['chat_id'=>$chat_id])->get();

            $msg_sender_visibility =$chat->sender_visibility;
            $start_sender_id = $chat->sender_id;
             $start_receiver_id = $chat->receiver_id;
            $msg_receiver_visibility = $chat->receiver_visibility;

            $this->db->where(['chat_id'=>$chat_id]);
            $this->Chat_model->update([
                                        'message'=>$message,
                                        'updated_date'=>date('Y-m-d H:i:s'),
                                        'random_status'=>'0',
                                        'random_users_id'=>'0',
                                        'sender_visibility'=>$msg_sender_visibility,
                                        'receiver_visibility'=>$msg_receiver_visibility
                            ]);


        }else{


            $chat = $this->Chat_model->where(['sender_id'=>$sender_id,'receiver_id'=>$receiver_id,'sender_visibility'=>$sender_visibility,'receiver_visibility'=>$receiver_visibility])->get();

            if(!empty($chat)){

                $msg_sender_visibility =$chat->sender_visibility;  
                $start_sender_id = $chat->sender_id; 
                $start_receiver_id = $chat->receiver_id;         
                $msg_receiver_visibility = $chat->receiver_visibility;
                $chat_id = $chat->chat_id;
                $this->db->where(['chat_id',$chat_id]);
                $this->Chat_model->update([
                                        'message'=>$message,
                                        'updated_date'=>date('Y-m-d H:i:s'),
                                        'random_status'=>'0',
                                        'random_users_id'=>'0',
                                        'sender_visibility'=>$msg_sender_visibility,
                                        'receiver_visibility'=>$msg_receiver_visibility
                            ]);

            }else{

                $this->Chat_model->insert([
                                        'sender_id'=>$sender_id,
                                        'receiver_id'=>$receiver_id,
                                        'message'=>$message,
                                        'created_date'=>date('Y-m-d H:i:s'),
                                        'updated_date'=>date('Y-m-d H:i:s'),
                                        'sender_visibility'=>$sender_visibility,
                                        'receiver_visibility'=>'1'
                                        ]);

                $chat_id = $this->db->insert_id();

                $msg_sender_visibility =$sender_visibility;
                $start_sender_id = $sender_id;
                $start_receiver_id = $receiver_id;
                $msg_receiver_visibility = '1';

                }
           
        }


        $messages = $this->Messages_model->insert(
            ['sender_id'=>$sender_id,
            'receiver_id'=>$receiver_id,
            'message'=>$message,
            'image'=>$image,
            'emoji_flag'=>$emoji_flag,
            'sender_visibility'=>$msg_sender_visibility,
            'receiver_visibility'=>$msg_receiver_visibility,
            'message_type'=>$msg_type,
            'chat_id'=>$chat_id]);

        $message_id = $messages;
        
        $userMsgData = [];

        if($messages){

            // if msg type = direct_message

            if($msg_type=="direct_message") : 

                $spend_type = "direct_message";
            
                $wallet_data = creditCalculations($user,$wallet,$credits);
                
                $weekly_credits = $wallet_data['weekly_credits']; // weekly subscribed credits

                $total_credits = $wallet_data['total_credits']; // additional credits

                $wallet_balance_total = $wallet_data['wallet_balance_total']; // wallet balance result of combine additional and free credits

                /*$total_credits = ($total_credits - $costs);*/

                $user_data  =   [
                                    'weekly_credits'=>$weekly_credits,
                                    'total_credits' => $total_credits
                                ];                

                // updating purchased credits 
                $updated = $this->Users_model->update($user_data,$sender_id);

                $this->load->model('wallet_balance_model');

                    $data   =   [   
                                    'users_id' =>$sender_id,
                                    'debit_value'=>$credits,
                                    'use_for'=>$this->lang->line('direct_message'),                    
                                    'debit_date'=>date('Y-m-d H:i:s'), 
                                    'type'=>'debit',                   
                                    'total_credits'=>$wallet_balance_total
                                ];

                // added data into wallet balance to track the credits and it uses

                $res = $this->wallet_balance_model->insert($data);

            endif; // endif direct msg


            $sender_user = $this->Users_model->fields('users_fname,users_lname')->get(['users_id'=>$sender_id]);


            $sender_name = $sender_user->users_fname.' '.$sender_user->users_lname;

                    $this->db->where(['users_status'=>'1',"is_signout"=>'0',"device_token !="=>"","users_id"=>$receiver_id]);
            $user = $this->Users_model->fields('users_id,users_status,device_type,device_token')->get();

            if(!empty($user->device_token) && $user->users_status=="1"){

                    $device_token = $user->device_token;                    
                    $device_type = $user->device_type;  
                    if($sender_visibility=="1"){

                        $text = ucfirst($sender_name." message you");

                    }else
                    {
                        $sender_name = "Snack User";
                        $text = "Someone message you";
                    }
                   
                    //$text = json_decode($text);
                    $title = "";
                    $type = "0";

                    $userMsg = $this->Messages_model->get(['message_id'=>$message_id]);
                    $userMsg->users_id = $user->users_id;
                    $userMsg->name = $sender_name;
                    $userMsg->sender_visibility = $msg_sender_visibility;
                    $userMsg->receiver_visibility = $msg_receiver_visibility;
                    $userMsg->chat_id =$chat_id;                    
                    $userMsg->chat_receiver_id =$start_receiver_id;
                    $userMsg->chat_sender_id =$start_sender_id;
                    $userMsgData = userNotificationData($userMsg);
                   

                    $badge = badgeCount($receiver_id);
                    if($device_type=="IOS"){
                    
                        sendPushNotificationIos($device_token, $text, $title,$sender_id,$type,$userMsgData,$badge);

                    }
                    if($device_type=="Android"){
                        $notification_data = ['users_id'=>$receiver_id];
                        $this->db->insert('user_notification',$notification_data);
                            $msg['body'] = ['body'=> $text, 
                                        'badge' => $badge,
                                        'type'=>$type,
                                        'users_id'=>$sender_id];
                            $msg['msgdata'] = $userMsgData;

                        sendPushNotificationAndroid($device_token, $msg);

                    }
                }
        }

        if(!empty($image)){
            $image = base_url().'/uploads/messages/'.$image;
        }
             _trackUser(TRUE, "Message Sent", TRUE, $sender_id);
             $this->response(array(
                    
                    'status' => TRUE,
                    'message' => 'message sent',
                    'messages' => $message,
                    'image'=>$image,
                    'emoji_flag'=>$emoji_flag,
                    'msg_type'=>$msg_type,
                    'message_id'=>$message_id,
                    'chat_id'=>$chat_id
                    ) , REST_Controller::HTTP_OK);  

    }

    
    function temporary_get(){
        $sender_id = $this->get('sender_id');
        $this->db->where('sender_id',$sender_id);
        $this->db->or_where('receiver_id',$sender_id);
        $chat = $this->db->get('chat')->result();
         $this->response(array(
                    'status' => TRUE,
                    'message' => 'list of messages',
                    'messages' => $chat                    
                    ) , REST_Controller::HTTP_OK);  
    }


    

    /**
    * Get conversation between two user api
    * @param $sender_id,$receiver_id is $users id int
    * @return response conversation array
    */

    function listMessages_get(){

        $chat_id = $this->get('chat_id');

        $users_id = $this->get('users_id');
        $sender_id = $this->get('sender_id');

        $receiver_id = $this->get('receiver_id');

        $page  = $this->get('page');

        $perPage = "20";

        $total_rows = $this->Messages_model->get_all_messagesNumRows($chat_id);

        $messages = $this->Messages_model->get_all_messages($chat_id,$page,$perPage);

        $this->load->model('Users_like_model');
        
        $chat = $this->Chat_model->where(['chat_id'=>$chat_id])->get();

        if(!empty($messages)){

            foreach ($messages as $key => $value) {

                $receiver_id = $receiver_id;
                $sender_id = $sender_id;

                $res = $this->Users_like_model->getLikedStatus($sender_id,$receiver_id);               

                if($res['is_mutualfriend']){

                    $messages[$key]->is_mutualfriend = $res['is_mutualfriend'];

                }else{

                    $messages[$key]->is_mutualfriend =  '0';

                }


                            
            $image = $value->image;

            if(!empty($image)){

                $messages[$key]->image = base_url().'uploads/messages/'.$image;

            }else{

                $messages[$key]->image = "";
            }

            $messages[$key]->sender_name = $value->sender_name;

            if($chat->sender_visibility=="0" && $chat->sender_id!=$users_id){
                if($value->sender_id!=$users_id){

                     $messages[$key]->sender_name = "Snack User";
                }

                if($value->receiver_id==$users_id){
                     $messages[$key]->sender_name = "Snack User";   
                }else{
                        $messages[$key]->receiver_name = "Snack User";   
                }
            }


            /*if($value->sender_id!=$users_id){ // if user is not sender of this chat for showing anonymous as snack user

                if($value->sender_visibility=="0"){

                    $messages[$key]->sender_name = "Snack User";    
                }

            }elseif($value->receiver_id!=$users_id){ // if user is not sender of this chat for showing anonymous as snack user

                if($chat->sender_visibility=="0"){

                    $messages[$key]->receiver_name = "Snack User";    
                }

            }*/
            

        }

            _trackUser(TRUE, "Conversation", TRUE, $sender_id);
            $this->response(array(
                    'status' => TRUE,
                    'message' => 'list of messages',
                    'messages' => $messages,
                    'total_rows'=>$total_rows
                    ) , REST_Controller::HTTP_OK);  
         }
         else{


            $this->response(array(
                    'status' => FALSE,
                    'message' => 'No data found',
                    ) , REST_Controller::HTTP_OK);  

         }
        
        
    }



    /**
    * List of users last messages
    * @param $users_id, $page
    * @return response
    */

    function listMessageUser_post(){

        $this->load->model('User_images_model');

        $this->load->model('Users_block_model');

        $users_id = $this->post('users_id'); 

        $page = $this->post('page'); 

        $perPage = "10";          

        $blocked = $this->Users_block_model->fields('blocked_users_id')->get_all(['users_id'=>$users_id]); 

        $blocked_id = [];

        if(!empty($blocked))      {

            foreach ($blocked as $rows) {

                $blocked_id[] = $rows->blocked_users_id;

            }

            $id = implode(",", $blocked_id);

            $condition = " AND (sender_id NOT IN ($id) AND receiver_id NOT IN ($id))";

        }else{

            $condition = '';

        }
        
       $total_rows = $this->Messages_model->listUsersNumRows($users_id,$condition);

       $users = $this->Messages_model->listUsers($users_id,$page,$perPage,$condition);

       // var_dump($users);exit;
       // echo $this->db->last_query();die;
       $this->load->model('Users_like_model');

       if(!empty($users)){

        foreach ($users as $key => $value) {
            $sender_id = $value->sender_id;
            $receiver_id = $value->receiver_id;
            $chat_id = $value->chat_id;
            $res = $this->Users_like_model->getLikedStatus($sender_id,$receiver_id);

                if($res['is_mutualfriend']){

                    $users[$key]->is_mutualfriend = $res['is_mutualfriend'];

                }else{

                    $users[$key]->is_mutualfriend =  '0';

                }

            $otherUser = $value->users_id;

            $users[$key]->name = $value->name;
             $images = $this->User_images_model->get(['users_id'=>$otherUser,'is_primary'=>'1']);
              $users_image = $images->user_img;

            if(!empty($users_image)){

                $users[$key]->users_image = base_url().'uploads/users/'.$users_image;

            }else{

                $users[$key]->users_image = "";

            }

            if($value->sender_visibility=="0" || $value->receiver_visibility=="0"){

                if($value->sender_visibility=="0" && $value->sender_id!=$users_id){
                    $users[$key]->name = "Snack User";    
                    $users[$key]->users_image = "";            
                }
                else if($value->receiver_visibility=="0" && $value->receiver_id!=$users_id){
                    $users[$key]->name = "Snack User";    
                    $users[$key]->users_image = "";               
                }

            }

                        $this->db->order_by('message_id','DESC');
                        $this->db->limit(1);
            $msgs =     $this->Messages_model->fields('sender_id,receiver_id,message,image,message_type,emoji_flag')->where(['chat_id'=>$chat_id])->get();

            if(!empty($msgs->image)){
                $msgs->image = base_url().'uploads/messages/'.$msgs->image;
            }else{
                $msgs->image = "";
            }
            $users[$key]->sender_id = $msgs->sender_id;
            $users[$key]->receiver_id = $msgs->receiver_id;
            $users[$key]->message = $msgs->message;
            $users[$key]->image = $msgs->image;
            $users[$key]->message_type = $msgs->message_type;
            $users[$key]->emoji_flag = $msgs->emoji_flag;

            $users[$key]->duration =  ""; 
            if($value->updated_date!=""){

                $updated_time = $value->updated_date;
                // time difference 30-05-2018
                $elapsed = time_elapsed_string($updated_time);                       
                $users[$key]->duration =  $elapsed; 
                
             }
            
            $users[$key]->users_id = $otherUser;

            unset($users[$key]->otherUser);
            unset($users[$key]->chat_type);
            unset($users[$key]->is_invisible);
            unset($users[$key]->random_status);
            unset($users[$key]->random_users_id);
            


        }
        

        _trackUser(TRUE, "Conversation", TRUE, $sender_id);
            $this->response(array(
                    'status' => TRUE,
                    'message' => 'list of messages',
                    'messages' => $users,
                    'total_rows'=>$total_rows
                    ) , REST_Controller::HTTP_OK);  
        }
        else{
            
             $this->response(array(
                    'status' => FALSE,
                    'message' => 'No data found',
                    ) , REST_Controller::HTTP_OK);  
        }
        
    }

    /**
    * Check user exists or not
    * @param $id user id
    * @return bool
    */
    public function checkuserId($id){
        $result = $this->Users_model->get(['users_id' => $id,
                                            'users_status'=>'1'
                                            ]);
        if ($result) {
            return TRUE;
        }
        else {
            return FALSE;
        }
    }


   


}