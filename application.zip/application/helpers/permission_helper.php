<?php 
/**
*@if(CheckPermission('crm', 'read'))
**/
 function CheckPermission($moduleName="", $method=""){
	 $CI = get_instance();
    $permission = ($CI->session->userdata('admin_type'))?$CI->session->userdata('admin_type'):'';
    if(isset($permission) && $permission != "" ) 
	{
		
        if($permission == '2' || $permission == 'Super Admin') 
		{
          return true;
        } 
		else 
		{	
			$admin_id = $CI->session->userdata('admin_id');
			$getPermission = array();
			$getPermission = json_decode(getRowByTableColomId('permission',$admin_id,'admin_id','*'));
			
			
			if (isset($getPermission->$moduleName)) 
			{	
			 
			  if(isset($moduleName) && isset($method) && $moduleName != "" && $method != "" )
			  {		
			  		
			  	   $method_arr = explode(',',$method);
			  	   foreach($method_arr as $method_item){ 
				   if(isset($getPermission->$moduleName->$method_item))
				   {  
						return $getPermission->$moduleName->$method_item;
					}
				   
				} 
				//return 0;
              } 
			  else
			  {
                return 0;
              }
			}
			else{return 0;}
       }
    } 
	else 
	{
      return 0;
    }
  }


  function getAllDataByTable($tableName='',$columnValue='*',$colume='')
	{  
		$CI = get_instance();
		$CI->db->select($columnValue);
		$CI->db->from($tableName);
		$query = $CI->db->get();
		if($query->num_rows() > 0) {
		   $catlog_data = $query->result();
			return $catlog_data;
		}else {return false;}
	}


	function getRowByTableColomId($tableName='',$id='',$colom='id',$whichColom='')
	{  
		if($colom == 'id' && $tableName != 'users') {
			$colom = $tableName.'_id';
		}
		$CI = get_instance();
		$CI->db->select('*');
		$CI->db->from($tableName);
		$CI->db->where($colom , $id);
		$query = $CI->db->get();
		$result = $query->row();
			if(!empty($result))
			{	
				if(!empty($whichColom)){
				 $result = $result->$whichColom;
				 return $result;
				}
				else
				{
					return $result;
				}
			}
			else
			{
				return false;
			}
	
	}



function checkAllPermission($moduleName){
	$CI = &get_instance();

	if($CI->session->userdata('admin_type')=='2')
	{
		return TRUE;	
	}
	else{
		$methods = check_single_permission($moduleName);

		if($methods->perm_create=="1" || $methods->perm_read=="1" || $methods->perm_update=="1" || $methods->perm_delete=="1"){
			
			return TRUE;

		}
		return FALSE;
	}
}




function check_methods_modules($modulename,$method){
	$methods = check_single_permission($modulename);

	if("perm_create"==$method)
	{
		if($methods->perm_create=='1')
		{
			return TRUE;
		}
		else{
			return FALSE;
		}
	}
	elseif ("perm_read"==$method) {
		if($methods->perm_read=='1')
		{
			return TRUE;
		}
		else{
			return FALSE;
		}
	}
	elseif ("perm_update"==$method) {
		if($methods->perm_update=='1')
		{
			return TRUE;
		}
		else{
			return FALSE;
		}
	}
	elseif ("perm_delete"==$method) {
		if($methods->perm_delete=='1')
		{
			return TRUE;
		}
		else{
			return FALSE;
		}
	}

}

function check_single_permission($modulename){
	return get_modules($modulename);

}


function get_modules($modulename){
	
	$CI = &get_instance();
	$admin_id = $CI->session->userdata('admin_id');
	$CI->db->select("p.perm_create,p.perm_read,p.perm_update,p.perm_delete");
	$CI->db->where('m.module_name',$modulename);
	$CI->db->where('p.admin_id',$admin_id);
	$CI->db->join('modules m','m.module_id=p.module_id');
	return $CI->db->get('permission p')->row();
}

function check_custom_permission(){
	$CI = &get_instance();
	$admin_id = $CI->session->userdata('admin_id');
	$user_role_module = $CI->db->select()
                ->from('permission')
                ->join("modules", "modules.module_id = permission.module_id")
                ->where([
                    "permission.admin_id" => $admin_id
                ])->get()->result();

		$CI->data['permission'] = '';
        foreach($user_role_module as $row) {
            $module = $row->module_name;
            $CI->data['permission'][$module] = array();
            $user_permission  = array('perm_create' => $row->perm_create,'perm_read' => $row->perm_read,
            'perm_update' => $row->perm_update,
            'perm_delete' => $row->perm_delete );
            $CI->data['permission'][$module] = $user_permission;
           //array_push($CI->data['permission'][$module], $user_permission);

        }



        

        return $CI->data['permission'];
        
       

}