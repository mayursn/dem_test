<?php 
if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

/**
 * CodeIgniter Notification Helpers
 *
 * @package        CodeIgniter
 * @subpackage    Helpers
 * @category    Helpers
 * @author        Andri Setiawan
 * @link        https://github.com/shevtiawan
 */
// ------------------------------------------------------------------------
if (!function_exists('set_error_notification')) {
    function set_error_notification($message = "")
    {
        $CI = &get_instance();
        $CI->session->set_flashdata('notification', true);
        $CI->session->set_flashdata('error-notification', $message);
    }
}
if (!function_exists('set_warning_notification')) {
    function set_warning_notification($message = "")
    {
        $CI = &get_instance();
        $CI->session->set_flashdata('notification', true);
        $CI->session->set_flashdata('warning-notification', $message);
    }
}
if (!function_exists('set_success_notification')) {
    function set_success_notification($message = "")
    {
        $CI = &get_instance();
        $CI->session->set_flashdata('notification', true);
        $CI->session->set_flashdata('success-notification', $message);
    }
}
if (!function_exists('clear_notification')) {
    function clear_notification()
    {
        $CI = &get_instance();
        $CI->session->set_flashdata('notification', false);
    }
}
if (!function_exists('print_notification')) {
    function print_notification()
    {
        $CI = &get_instance();
        $hasil = '';
        if ($CI->session->flashdata('notification')) {
            if ($CI->session->flashdata('error-notification')) {
                $hasil .= '<div class="alert bg-pink alert-dismissable">';
                $hasil .= '<button class="close" data-dismiss="alert" aria-label="close" title="close">&times;</button>';
                $hasil .= $CI->session->flashdata('error-notification');
            }
            ;
            if ($CI->session->flashdata('warning-notification')) {
                $hasil .= '<div class="alert bg-orange alert-dismissable">';
                $hasil .= '<button class="close" data-dismiss="alert" aria-label="close" title="close">&times;</button>';
                $hasil .= $CI->session->flashdata('warning-notification');
            }
            ;
            if ($CI->session->flashdata('success-notification')) {
                $hasil .= '<div class="alert bg-green alert-dismissable">';
                $hasil .= '<button class="close" data-dismiss="alert" aria-label="close" title="close">&times;</button>';
                $hasil .= $CI->session->flashdata('success-notification');
            }
            ;

            $hasil = $hasil . '</div>';
        }
        return $hasil;
    }
}
if (!function_exists('print_red_notification')) {
    function print_red_notification()
    {
        $CI = &get_instance();
        $hasil = '';
        if ($CI->session->flashdata('error-notification')) {
            $hasil = '<div id="notification"><div class="error-notification">' . $CI->session->flashdata('error-notification') . '</div></div>';
        }
        return $hasil;
    }
}
if (!function_exists('print_blue_notification')) {
    function print_blue_notification()
    {
        $CI = &get_instance();
        $hasil = '';
        if ($CI->session->flashdata('blue-notification')) {
            $hasil = '<div id="notification"><div class="blue-notification">' . $CI->session->flashdata('blue-notification') . '</div></div>';
        }
        return $hasil;
    }
}
if (!function_exists('print_success_notification')) {
    function print_success_notification()
    {
        $CI = &get_instance();
        $hasil = '';
        if ($CI->session->flashdata('success-notification')) {
            $hasil = '<div id="notification"><div class="success-notification">' . $CI->session->flashdata('success-notification') . '</div></div>';
        }
        return $hasil;
    }
}


 
    function _trackUser($authorized = FALSE,$message='',$status='',$user_id = '')
    {
        $CI = &get_instance();
        return $CI->db->insert('logs', array(
            'uri' => $CI->uri->uri_string(),
            'method' => strtolower($_SERVER['REQUEST_METHOD']),
            'params' => serialize(($_POST) ? $_POST : $_GET),            
            'ip_address' => $CI->input->ip_address(),
            'time' => function_exists('now') ? now() : time(),
            'authorized' => $authorized,
            'message'=>$message,
            'status'=>$status,
            'user_id'=>$user_id
        ));


        //echo $CI->db->last_query();

    }



    
    
    /**
     * Push notifcation send code in iphone
     *
     * @param      string  $token  The token
     *
     * @return     string  ( json )
     */
    function sendPushNotificationIos($token, $message = "", $title = "",$sender_id = "",$type = "",$userMsgData = [],$badge=1) {
        //$ci = &get_instance(); // CI instance

        
        $passphrase = '';
        $messagealert = '';

        if (empty($message)) {

            $messagealert = "Snack app notitfication.";

        } else {

            $messagealert = $message;

        }

        $ctx = stream_context_create();

        
        stream_context_set_option($ctx, 'ssl', 'local_cert', 'apns.pem');

        stream_context_set_option($ctx, 'ssl', 'passphrase', $passphrase);

        // LIVE :- gateway.push.apple.com:2195
        // Staging :- gateway.sandbox.push.apple.com:2195

        $fp = stream_socket_client(
            'ssl://gateway.sandbox.push.apple.com:2195', $error, $errstr, 30, STREAM_CLIENT_CONNECT | STREAM_CLIENT_PERSISTENT, $ctx);

        if (!$fp) {

            exit("Failed to connect: $err $errstr" . PHP_EOL);

        }
        //$body['body'] =
        $body['aps'] = array(

            'alert' => array(

                'title' => $title,

                'body' => $messagealert,

            ),

            'sound' => 'default',
            'badge'=>($badge != (null) ? $badge : 1)
        );

        
        $body['type'] = $type;
        $body['users_id'] = $sender_id;
            
        $body['msgdata'] = $userMsgData;
        $payload = json_encode($body);

        $msg = chr(0) . pack('n', 32) . pack('H*', $token) . pack('n', strlen($payload)) . $payload;

        $result = fwrite($fp, $msg, strlen($msg));

        if (!$result) {

            return 0;

        } else {

            return 1;

        }

        fclose($fp);
    }



    /**
     * Push notifcation send code in iphone
     *
     * @param      string  $token  The token
     *
     * @return     string  ( json )
     */
    function sendPushNotificationAndroid($registration_ids, $message )
    {


            $fields = array(
            'registration_ids' => [$registration_ids],
            'data'=> $message,

            );
          
            $headers = array(
            'Authorization: key='.FIREBASE_API_KEY, // FIREBASE_API_KEY_FOR_ANDROID_NOTIFICATION
            'Content-Type: application/json'
            );
            // Open connection
            $ch = curl_init();
            // Set the url, number of POST vars, POST data
            curl_setopt( $ch,CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send' );
            curl_setopt( $ch,CURLOPT_POST, true );
            curl_setopt( $ch,CURLOPT_HTTPHEADER, $headers );
            curl_setopt( $ch,CURLOPT_RETURNTRANSFER, true );
            // Disabling SSL Certificate support temporarly
            curl_setopt( $ch,CURLOPT_SSL_VERIFYPEER, false );
            curl_setopt( $ch,CURLOPT_POSTFIELDS, json_encode( $fields ) );
            // Execute post
            $result = curl_exec($ch );
            if($result === false){
            die('Curl failed:' .curl_errno($ch));
            }
            // Close connection
            curl_close( $ch );
            return $result;


        
    }






?>