<?php 
if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

/**
 * CodeIgniter Users Helpers
 *
 * @package        CodeIgniter
 * @subpackage    Helpers
 * @category    Helpers
 * @author        Searchnative
 * @link        https://searchnative.com
 */
// ------------------------------------------------------------------------
if (!function_exists('genderlookingfor')) {
    function genderlookingfor($gender)
    {
        switch ($gender) {
		    case "Male":
		        return "Female";
		        break;

		    case "Female":
		        return "Male";
		        break;

		    case "Gay":
		        return "Gay";
		    break;
		    case "Lesbian":
		        return "Lesbian";
		    break;
                    case "Other":
		        return "Male & Female";
		    break;
		}
        
    }
}



if (!function_exists('genderpreference')) {
    function genderpreference($gender)
    {
        switch ($gender) {
		    case "Male":
		        return "1";
		        break;

		    case "Female":
		        return "2";
		        break;
                    case "Other":
		        return "66";
		        break;
		}
        
    }
}
/**
* Get Looking for option using orientation and gender
* @param $orientation, $gender
* @return reponse text
*/

if (!function_exists('orientationgender')) {
    function orientationgender($orientation,$gender)
    {
     	
		switch ([$orientation, $gender]) {
		    case ["Straight", 'Men']:
		        return 'Women';
		    break;

		    case ['Straight', 'Women'];
		        return 'Men';
		    break;
		    case ['Gay / Lesbian', 'Men'];
		        return 'Men';
		    break;
		    case ['Gay / Lesbian', 'Women'];
		        return 'Women';
		    break;
		}   
    }
}



/**
* Multidimensional array sorting 
* @param $arr is mult.dime. array $index is the key of value which consider desc oreder 
* @return response array with desc order
*/

if (!function_exists('multid_sort')) {
	   function multid_sort($arr, $index) {
	    $b = array();
	    $c = array();
	    foreach ($arr as $key => $value) {
	        $b[$key] = $value->$index;
	    }

	    arsort($b);

	    foreach ($b as $key => $value) {
	        $c[] = $arr[$key];
	    }

	    return $c;
	}
}

if (!function_exists('checkComplited')) {

function checkComplited($user){
            if($user->is_social==0){
                if($user->users_fname!="" && $user->users_lname!="" &&  $user->users_dob!="" && $user->users_dob!="0000-00-00" && $user->users_gender!=""){
                    return true;    
                }                
            }else{
                if($user->is_social==1 && $user->users_dob!="" && $user->users_dob!="0000-00-00" && $user->users_gender!=""  && $user->users_mobile!=""){
                    return true;
                }
                
            }
            return false;
    }

}



if (!function_exists('timeDiff')) {
	function timeDiff($firstTime,$lastTime)
	{

		// convert to unix timestamps
		$firstTime=strtotime($firstTime);
		$lastTime=strtotime($lastTime);

		// perform subtraction to get the difference (in seconds) between times
		$timeDiff=$lastTime-$firstTime;

		// return the difference
		return $timeDiff;
	}
}


if(!function_exists('time_ago'))  	{

    function time_ago( $time )
    {
        $out    = ''; // what we will print out
        $now    = time(); // current time
        $diff   = $now - $time; // difference between the current and the provided dates

        if( $diff < 60 ) // it happened now
            return TIMEBEFORE_NOW;

        elseif( $diff < 3600 ) // it happened X minutes ago
            return str_replace( '{num}', ( $out = round( $diff / 60 ) ), $out == 1 ? TIMEBEFORE_MINUTE : TIMEBEFORE_MINUTES );

        elseif( $diff < 3600 * 24 ) // it happened X hours ago
            return str_replace( '{num}', ( $out = round( $diff / 3600 ) ), $out == 1 ? TIMEBEFORE_HOUR : TIMEBEFORE_HOURS );

        elseif( $diff < 3600 * 24 * 2 ) // it happened yesterday
            return TIMEBEFORE_YESTERDAY;

        else // falling back on a usual date format as it happened later than yesterday
            return strftime( date( 'Y', $time ) == date( 'Y' ) ? TIMEBEFORE_FORMAT : TIMEBEFORE_FORMAT_YEAR, $time );
    }
}

/**
* common function Credit calculations for costs and functions
* @param $user array,$wallet array, $credits as int
* @return response in array object
*/
if(!function_exists('creditCalculations')){
    function creditCalculations($user,$wallet,$credits){

        $weekly_credits = $user->weekly_credits;

        if($user->weekly_credits > 0){

            if($user->weekly_credits >= $credits){ // if week credits more than 50 calculation will be finish in this condition

                $weekly_credits = ($user->weekly_credits - $credits);

                $total_credits = $user->total_credits;                              

            }else{ // if weekly credits less than 50 then it will substract from weekly credits than it will be substract from additional credits
                
                $left_credits = ($credits - $weekly_credits);
                // $left_credits is carry to substract from additional credits
                $weekly_credits = '0';

                if($left_credits > 0){

                    $total_credits = ($user->total_credits - $left_credits);

                }   

            }

        }else{

            $weekly_credits = '0';

            $total_credits = ($user->total_credits - $credits);
        }

        $wallet_balance_total =  $wallet->total_credits - $credits;
        $data=['weekly_credits'=>$weekly_credits,'total_credits'=>$total_credits,'wallet_balance_total'=>$wallet_balance_total];
        return $data;

    }
}


// 24-05-2018
if(!function_exists('userNotificationData')){
function userNotificationData($userMsg){

       $CI = get_instance();
        $sender_id = $userMsg->sender_id;

        $image = $userMsg->image;

        $message = $userMsg->message;

        $message_type = $userMsg->message_type;

        $emoji_flag = $userMsg->emoji_flag;

        $created_date = $userMsg->created_date;

        $message_id = $userMsg->message_id;

        $chat_receiver_id = $userMsg->chat_receiver_id;
        $chat_sender_id = $userMsg->chat_sender_id;
        


        $sender_visibility = "0";
        if(!empty($userMsg->sender_visibility)){
            $sender_visibility = $userMsg->sender_visibility;
        }
        $receiver_visibility = "0";
        if(!empty($userMsg->receiver_visibility)){
            $receiver_visibility = $userMsg->receiver_visibility;
        }
        $chat_id = "";
        if($userMsg->chat_id!=""){
         $chat_id = $userMsg->chat_id;
        }


       

        if($emoji_flag=="1"){

            $emoji_flag = "1";

        }else{

            $emoji_flag = "0";

        }

        if(!empty($image)){

            $unimage = base_url().'uploads/messages/'.$image;

        }else{

            $unimage = "";

        }

        if(empty($message)){

            $message = "";

        }

        $nimage = $CI->Users_model->getPrimaryImg($sender_id);

        $noticeuser = $CI->Users_model->getUSerNoticeData($sender_id);

        if(!empty($nimage->user_img)){        

            $userimg = base_url().'uploads/users/'.$nimage->user_img;

        }else{

            $userimg = "";

        }

        
        if($noticeuser->is_invisible=="0"){

            $uname2    = "Snack User";
             $userimg  = "";
        }else{

            $uname2 = $noticeuser->users_fname." ".$noticeuser->users_lname;
        }
        
        return $userMsgData = ['users_id'=>$sender_id,
                                'name'=>$uname2,
                                'users_img'=>$userimg,
                                'message_id'=>$message_id,
                                "message"=>$message,
                                'image'=>$unimage,
                                'emoji_flag'=>$emoji_flag,
                                'chat_sender_id'=>$chat_sender_id,
                                'chat_receiver_id'=>$chat_receiver_id,
                                'chat_id'=>$chat_id,
                                'message_type'=>$message_type,
                                'created_date'=>$created_date,
                                'sender_visibility'=>$sender_visibility,
                                'receiver_visibility'=>$receiver_visibility];
    }
}

// 24-05-2018

if(!function_exists('badgeCount')){
function badgeCount($users_id){
    $CI = get_instance();
        $CI->load->model('User_notification_model');

        $CI->User_notification_model->insert(['users_id'=>$users_id]);

        $count = $CI->User_notification_model->fields('notification_id')->get_all([
                                                            'users_id'=>$users_id
                                                            ]
                                                        );
        return $badge = count($count);
    }
}


// 24-05-2018
if(!function_exists('shuffle_assoc')){
function shuffle_assoc($list) { 
  if (!is_array($list)) return $list; 

  $keys = array_keys($list); 
  shuffle($keys); 
  $random = array(); 
  foreach ($keys as $key) { 
    $random[] = $list[$key]; 
  }
  return $random; 
} 
}

/**
* Date time difference in seconds/minutes/days/weeks/months/year
* @param $datetime
* @return response string
* 30-05-2018
*/
if(!function_exists('time_elapsed_string')){
function time_elapsed_string($datetime, $full = false) {
    $now = new DateTime;
    $ago = new DateTime($datetime);
    $diff = $now->diff($ago);

    $diff->w = floor($diff->d / 7);
    $diff->d -= $diff->w * 7;

    $string = array(
        'y' => 'year',
        'm' => 'month',
        'w' => 'week',
        'd' => 'day',
        'h' => 'hr',
        'i' => 'min',
        's' => 'sec',
    );
    foreach ($string as $k => &$v) {
        if ($diff->$k) {
            $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
        } else {
            unset($string[$k]);
        }
    }

    if (!$full) $string = array_slice($string, 0, 1);
    return $string ? implode(', ', $string) . ' ' : ' now';
}    
}