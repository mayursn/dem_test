<?php defined('BASEPATH') or exit('No direct script access allowed');



/**
 * Select or active navigation
 */
if (!function_exists('nav_select')) {
    function nav_select($key, $value)
    {
        if ($key == $value) {
            return 'class="active"';
        }

        return '';
    }
}

if (!function_exists('sub_nav_select')) {
    function sub_nav_select($value, $key = array())
    {
        if (in_array($value, $key)) {
            return 'class="active"';
        }

        return '';
    }
}


if (!function_exists('status_active')) {
    function status_active($value)
    {
        $status = '';
        if($value=="1")
        {
            $status = "Active";
        }
        else{
            $status = "Inactive";
        }

        return $status;
    }
}


if (!function_exists('emailconfig')) {
   function emailconfig(){
        $CI = &get_instance();
                        $config = [];
                        $CI->load->model('Siteconfig');
                        $siteconfig = $CI->Siteconfig->get_all()->result();
                        foreach($siteconfig as $key => $val){
                            $config[$val->key] = $val->value;
                        }
                        $config['charset'] = "utf-8";
                        $config['mailtype'] = "html";
                        $config['newline'] = "\r\n";
                        return $config;

    }
}


if (!function_exists('websitedata')) {
   function websitedata($key){
        $CI = &get_instance();
        $CI->db->where('site_key',$key);
        return $CI->db->get('settings')->row()->site_value;               

    }
}




