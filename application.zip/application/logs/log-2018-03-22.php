<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-03-22 13:03:38 --> Config Class Initialized
INFO - 2018-03-22 13:03:38 --> Hooks Class Initialized
DEBUG - 2018-03-22 13:03:38 --> UTF-8 Support Enabled
INFO - 2018-03-22 13:03:38 --> Utf8 Class Initialized
INFO - 2018-03-22 13:03:38 --> URI Class Initialized
INFO - 2018-03-22 13:03:38 --> Router Class Initialized
INFO - 2018-03-22 13:03:38 --> Output Class Initialized
INFO - 2018-03-22 13:03:38 --> Security Class Initialized
DEBUG - 2018-03-22 13:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 13:03:38 --> Input Class Initialized
INFO - 2018-03-22 13:03:38 --> Language Class Initialized
INFO - 2018-03-22 13:03:38 --> Language Class Initialized
INFO - 2018-03-22 13:03:38 --> Config Class Initialized
INFO - 2018-03-22 13:03:38 --> Loader Class Initialized
INFO - 2018-03-22 18:33:38 --> Helper loaded: url_helper
INFO - 2018-03-22 18:33:38 --> Helper loaded: notification_helper
INFO - 2018-03-22 18:33:38 --> Helper loaded: settings_helper
INFO - 2018-03-22 18:33:38 --> Helper loaded: permission_helper
INFO - 2018-03-22 18:33:38 --> Helper loaded: users_helper
INFO - 2018-03-22 18:33:38 --> Database Driver Class Initialized
DEBUG - 2018-03-22 18:33:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 18:33:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 18:33:39 --> Helper loaded: form_helper
INFO - 2018-03-22 18:33:39 --> Form Validation Class Initialized
INFO - 2018-03-22 18:33:39 --> Controller Class Initialized
INFO - 2018-03-22 18:33:39 --> Model Class Initialized
INFO - 2018-03-22 18:33:39 --> Helper loaded: inflector_helper
DEBUG - 2018-03-22 18:33:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-22 18:33:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-22 18:33:39 --> Model Class Initialized
INFO - 2018-03-22 18:33:39 --> Model Class Initialized
INFO - 2018-03-22 18:33:39 --> Model Class Initialized
INFO - 2018-03-22 18:33:39 --> Model Class Initialized
INFO - 2018-03-22 18:33:39 --> Model Class Initialized
INFO - 2018-03-22 18:33:39 --> Model Class Initialized
INFO - 2018-03-22 18:33:39 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-22 18:33:39 --> Model Class Initialized
INFO - 2018-03-22 18:33:39 --> Final output sent to browser
DEBUG - 2018-03-22 18:33:39 --> Total execution time: 0.5014
INFO - 2018-03-22 13:03:39 --> Config Class Initialized
INFO - 2018-03-22 13:03:39 --> Hooks Class Initialized
DEBUG - 2018-03-22 13:03:40 --> UTF-8 Support Enabled
INFO - 2018-03-22 13:03:40 --> Utf8 Class Initialized
INFO - 2018-03-22 13:03:40 --> Config Class Initialized
INFO - 2018-03-22 13:03:40 --> Hooks Class Initialized
INFO - 2018-03-22 13:03:40 --> URI Class Initialized
DEBUG - 2018-03-22 13:03:40 --> UTF-8 Support Enabled
INFO - 2018-03-22 13:03:40 --> Utf8 Class Initialized
INFO - 2018-03-22 13:03:40 --> Router Class Initialized
INFO - 2018-03-22 13:03:40 --> URI Class Initialized
INFO - 2018-03-22 13:03:40 --> Output Class Initialized
INFO - 2018-03-22 13:03:40 --> Router Class Initialized
INFO - 2018-03-22 13:03:40 --> Security Class Initialized
INFO - 2018-03-22 13:03:40 --> Output Class Initialized
INFO - 2018-03-22 13:03:40 --> Security Class Initialized
DEBUG - 2018-03-22 13:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 13:03:40 --> Input Class Initialized
DEBUG - 2018-03-22 13:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 13:03:40 --> Input Class Initialized
INFO - 2018-03-22 13:03:40 --> Language Class Initialized
INFO - 2018-03-22 13:03:40 --> Language Class Initialized
INFO - 2018-03-22 13:03:41 --> Language Class Initialized
INFO - 2018-03-22 13:03:41 --> Config Class Initialized
INFO - 2018-03-22 13:03:41 --> Loader Class Initialized
INFO - 2018-03-22 18:33:41 --> Helper loaded: url_helper
INFO - 2018-03-22 18:33:41 --> Helper loaded: notification_helper
INFO - 2018-03-22 18:33:41 --> Helper loaded: settings_helper
INFO - 2018-03-22 18:33:41 --> Helper loaded: permission_helper
INFO - 2018-03-22 18:33:41 --> Helper loaded: users_helper
INFO - 2018-03-22 13:03:41 --> Language Class Initialized
INFO - 2018-03-22 13:03:41 --> Config Class Initialized
INFO - 2018-03-22 13:03:41 --> Loader Class Initialized
INFO - 2018-03-22 18:33:42 --> Helper loaded: url_helper
INFO - 2018-03-22 18:33:42 --> Helper loaded: notification_helper
INFO - 2018-03-22 18:33:42 --> Helper loaded: settings_helper
INFO - 2018-03-22 18:33:42 --> Helper loaded: permission_helper
INFO - 2018-03-22 18:33:42 --> Helper loaded: users_helper
INFO - 2018-03-22 18:33:42 --> Database Driver Class Initialized
DEBUG - 2018-03-22 18:33:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 18:33:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 18:33:42 --> Helper loaded: form_helper
INFO - 2018-03-22 18:33:42 --> Form Validation Class Initialized
INFO - 2018-03-22 18:33:42 --> Controller Class Initialized
INFO - 2018-03-22 18:33:42 --> Model Class Initialized
INFO - 2018-03-22 18:33:42 --> Helper loaded: inflector_helper
DEBUG - 2018-03-22 18:33:42 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-22 18:33:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-22 18:33:42 --> Model Class Initialized
INFO - 2018-03-22 18:33:42 --> Model Class Initialized
INFO - 2018-03-22 18:33:42 --> Model Class Initialized
INFO - 2018-03-22 18:33:42 --> Model Class Initialized
INFO - 2018-03-22 18:33:42 --> Model Class Initialized
INFO - 2018-03-22 18:33:42 --> Model Class Initialized
INFO - 2018-03-22 18:33:42 --> Model Class Initialized
INFO - 2018-03-22 18:33:42 --> Model Class Initialized
INFO - 2018-03-22 18:33:42 --> Model Class Initialized
INFO - 2018-03-22 18:33:42 --> Model Class Initialized
INFO - 2018-03-22 18:33:42 --> Model Class Initialized
INFO - 2018-03-22 18:33:42 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-22 18:33:42 --> Model Class Initialized
INFO - 2018-03-22 18:33:42 --> Final output sent to browser
DEBUG - 2018-03-22 18:33:42 --> Total execution time: 2.8868
INFO - 2018-03-22 18:33:43 --> Database Driver Class Initialized
DEBUG - 2018-03-22 18:33:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 18:33:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 18:33:43 --> Helper loaded: form_helper
INFO - 2018-03-22 18:33:43 --> Form Validation Class Initialized
INFO - 2018-03-22 18:33:43 --> Controller Class Initialized
INFO - 2018-03-22 18:33:43 --> Model Class Initialized
INFO - 2018-03-22 18:33:43 --> Helper loaded: inflector_helper
DEBUG - 2018-03-22 18:33:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-22 18:33:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-22 18:33:43 --> Model Class Initialized
INFO - 2018-03-22 18:33:43 --> Model Class Initialized
INFO - 2018-03-22 18:33:43 --> Model Class Initialized
INFO - 2018-03-22 18:33:43 --> Model Class Initialized
INFO - 2018-03-22 18:33:43 --> Model Class Initialized
INFO - 2018-03-22 18:33:43 --> Model Class Initialized
INFO - 2018-03-22 18:33:43 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-22 18:33:43 --> Final output sent to browser
DEBUG - 2018-03-22 18:33:43 --> Total execution time: 3.6347
INFO - 2018-03-22 13:03:46 --> Config Class Initialized
INFO - 2018-03-22 13:03:46 --> Hooks Class Initialized
DEBUG - 2018-03-22 13:03:46 --> UTF-8 Support Enabled
INFO - 2018-03-22 13:03:46 --> Utf8 Class Initialized
INFO - 2018-03-22 13:03:46 --> URI Class Initialized
INFO - 2018-03-22 13:03:46 --> Router Class Initialized
INFO - 2018-03-22 13:03:46 --> Output Class Initialized
INFO - 2018-03-22 13:03:46 --> Security Class Initialized
DEBUG - 2018-03-22 13:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 13:03:46 --> Input Class Initialized
INFO - 2018-03-22 13:03:46 --> Language Class Initialized
INFO - 2018-03-22 13:03:46 --> Language Class Initialized
INFO - 2018-03-22 13:03:46 --> Config Class Initialized
INFO - 2018-03-22 13:03:46 --> Loader Class Initialized
INFO - 2018-03-22 18:33:46 --> Helper loaded: url_helper
INFO - 2018-03-22 18:33:46 --> Helper loaded: notification_helper
INFO - 2018-03-22 18:33:46 --> Helper loaded: settings_helper
INFO - 2018-03-22 18:33:46 --> Helper loaded: permission_helper
INFO - 2018-03-22 18:33:46 --> Helper loaded: users_helper
INFO - 2018-03-22 18:33:46 --> Database Driver Class Initialized
DEBUG - 2018-03-22 18:33:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 18:33:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 18:33:46 --> Helper loaded: form_helper
INFO - 2018-03-22 18:33:46 --> Form Validation Class Initialized
INFO - 2018-03-22 18:33:46 --> Controller Class Initialized
INFO - 2018-03-22 18:33:46 --> Model Class Initialized
INFO - 2018-03-22 18:33:46 --> Helper loaded: inflector_helper
DEBUG - 2018-03-22 18:33:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-22 18:33:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-22 18:33:46 --> Model Class Initialized
INFO - 2018-03-22 18:33:46 --> Model Class Initialized
INFO - 2018-03-22 18:33:46 --> Model Class Initialized
INFO - 2018-03-22 18:33:46 --> Model Class Initialized
INFO - 2018-03-22 18:33:46 --> Model Class Initialized
INFO - 2018-03-22 18:33:46 --> Model Class Initialized
INFO - 2018-03-22 18:33:46 --> Model Class Initialized
INFO - 2018-03-22 18:33:46 --> Model Class Initialized
INFO - 2018-03-22 18:33:46 --> Model Class Initialized
INFO - 2018-03-22 18:33:46 --> Model Class Initialized
INFO - 2018-03-22 18:33:46 --> Model Class Initialized
INFO - 2018-03-22 18:33:46 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-22 18:33:46 --> Model Class Initialized
INFO - 2018-03-22 18:33:46 --> Final output sent to browser
DEBUG - 2018-03-22 18:33:46 --> Total execution time: 0.1170
INFO - 2018-03-22 13:03:49 --> Config Class Initialized
INFO - 2018-03-22 13:03:49 --> Hooks Class Initialized
DEBUG - 2018-03-22 13:03:49 --> UTF-8 Support Enabled
INFO - 2018-03-22 13:03:49 --> Utf8 Class Initialized
INFO - 2018-03-22 13:03:49 --> URI Class Initialized
INFO - 2018-03-22 13:03:49 --> Router Class Initialized
INFO - 2018-03-22 13:03:49 --> Output Class Initialized
INFO - 2018-03-22 13:03:49 --> Security Class Initialized
DEBUG - 2018-03-22 13:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 13:03:49 --> Input Class Initialized
INFO - 2018-03-22 13:03:49 --> Language Class Initialized
INFO - 2018-03-22 13:03:49 --> Language Class Initialized
INFO - 2018-03-22 13:03:49 --> Config Class Initialized
INFO - 2018-03-22 13:03:49 --> Loader Class Initialized
INFO - 2018-03-22 18:33:49 --> Helper loaded: url_helper
INFO - 2018-03-22 18:33:49 --> Helper loaded: notification_helper
INFO - 2018-03-22 18:33:49 --> Helper loaded: settings_helper
INFO - 2018-03-22 18:33:49 --> Helper loaded: permission_helper
INFO - 2018-03-22 18:33:49 --> Helper loaded: users_helper
INFO - 2018-03-22 18:33:49 --> Database Driver Class Initialized
DEBUG - 2018-03-22 18:33:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 18:33:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 18:33:49 --> Helper loaded: form_helper
INFO - 2018-03-22 18:33:49 --> Form Validation Class Initialized
INFO - 2018-03-22 18:33:49 --> Controller Class Initialized
INFO - 2018-03-22 18:33:49 --> Model Class Initialized
INFO - 2018-03-22 18:33:49 --> Helper loaded: inflector_helper
DEBUG - 2018-03-22 18:33:49 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-22 18:33:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-22 18:33:49 --> Model Class Initialized
INFO - 2018-03-22 18:33:49 --> Model Class Initialized
INFO - 2018-03-22 18:33:49 --> Model Class Initialized
INFO - 2018-03-22 18:33:49 --> Model Class Initialized
INFO - 2018-03-22 18:33:49 --> Final output sent to browser
DEBUG - 2018-03-22 18:33:49 --> Total execution time: 0.3369
INFO - 2018-03-22 13:03:51 --> Config Class Initialized
INFO - 2018-03-22 13:03:51 --> Hooks Class Initialized
DEBUG - 2018-03-22 13:03:51 --> UTF-8 Support Enabled
INFO - 2018-03-22 13:03:51 --> Utf8 Class Initialized
INFO - 2018-03-22 13:03:51 --> URI Class Initialized
INFO - 2018-03-22 13:03:51 --> Router Class Initialized
INFO - 2018-03-22 13:03:51 --> Output Class Initialized
INFO - 2018-03-22 13:03:51 --> Security Class Initialized
DEBUG - 2018-03-22 13:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 13:03:51 --> Input Class Initialized
INFO - 2018-03-22 13:03:51 --> Language Class Initialized
INFO - 2018-03-22 13:03:51 --> Language Class Initialized
INFO - 2018-03-22 13:03:51 --> Config Class Initialized
INFO - 2018-03-22 13:03:51 --> Loader Class Initialized
INFO - 2018-03-22 18:33:51 --> Helper loaded: url_helper
INFO - 2018-03-22 18:33:51 --> Helper loaded: notification_helper
INFO - 2018-03-22 18:33:51 --> Helper loaded: settings_helper
INFO - 2018-03-22 18:33:51 --> Helper loaded: permission_helper
INFO - 2018-03-22 18:33:51 --> Helper loaded: users_helper
INFO - 2018-03-22 18:33:51 --> Database Driver Class Initialized
DEBUG - 2018-03-22 18:33:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 18:33:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 18:33:51 --> Helper loaded: form_helper
INFO - 2018-03-22 18:33:51 --> Form Validation Class Initialized
INFO - 2018-03-22 18:33:51 --> Controller Class Initialized
INFO - 2018-03-22 18:33:51 --> Model Class Initialized
INFO - 2018-03-22 18:33:51 --> Helper loaded: inflector_helper
DEBUG - 2018-03-22 18:33:51 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-22 18:33:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-22 18:33:51 --> Model Class Initialized
INFO - 2018-03-22 18:33:51 --> Model Class Initialized
INFO - 2018-03-22 18:33:51 --> Model Class Initialized
INFO - 2018-03-22 18:33:51 --> Model Class Initialized
INFO - 2018-03-22 18:33:51 --> Final output sent to browser
DEBUG - 2018-03-22 18:33:51 --> Total execution time: 0.8968
INFO - 2018-03-22 13:03:52 --> Config Class Initialized
INFO - 2018-03-22 13:03:52 --> Hooks Class Initialized
DEBUG - 2018-03-22 13:03:52 --> UTF-8 Support Enabled
INFO - 2018-03-22 13:03:52 --> Utf8 Class Initialized
INFO - 2018-03-22 13:03:52 --> URI Class Initialized
INFO - 2018-03-22 13:03:52 --> Router Class Initialized
INFO - 2018-03-22 13:03:52 --> Output Class Initialized
INFO - 2018-03-22 13:03:52 --> Security Class Initialized
DEBUG - 2018-03-22 13:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 13:03:53 --> Input Class Initialized
INFO - 2018-03-22 13:03:53 --> Language Class Initialized
INFO - 2018-03-22 13:03:53 --> Config Class Initialized
INFO - 2018-03-22 13:03:53 --> Hooks Class Initialized
DEBUG - 2018-03-22 13:03:53 --> UTF-8 Support Enabled
INFO - 2018-03-22 13:03:53 --> Utf8 Class Initialized
INFO - 2018-03-22 13:03:53 --> URI Class Initialized
INFO - 2018-03-22 13:03:53 --> Router Class Initialized
INFO - 2018-03-22 13:03:53 --> Output Class Initialized
INFO - 2018-03-22 13:03:53 --> Security Class Initialized
DEBUG - 2018-03-22 13:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 13:03:53 --> Input Class Initialized
INFO - 2018-03-22 13:03:53 --> Language Class Initialized
INFO - 2018-03-22 13:03:53 --> Language Class Initialized
INFO - 2018-03-22 13:03:53 --> Config Class Initialized
INFO - 2018-03-22 13:03:53 --> Loader Class Initialized
INFO - 2018-03-22 18:33:53 --> Helper loaded: url_helper
INFO - 2018-03-22 18:33:53 --> Helper loaded: notification_helper
INFO - 2018-03-22 18:33:53 --> Helper loaded: settings_helper
INFO - 2018-03-22 18:33:53 --> Helper loaded: permission_helper
INFO - 2018-03-22 18:33:53 --> Helper loaded: users_helper
INFO - 2018-03-22 18:33:53 --> Database Driver Class Initialized
DEBUG - 2018-03-22 18:33:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 18:33:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 18:33:53 --> Helper loaded: form_helper
INFO - 2018-03-22 18:33:53 --> Form Validation Class Initialized
INFO - 2018-03-22 18:33:53 --> Controller Class Initialized
INFO - 2018-03-22 18:33:53 --> Model Class Initialized
INFO - 2018-03-22 18:33:53 --> Helper loaded: inflector_helper
DEBUG - 2018-03-22 18:33:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-22 18:33:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-22 18:33:53 --> Model Class Initialized
INFO - 2018-03-22 18:33:53 --> Model Class Initialized
INFO - 2018-03-22 18:33:53 --> Model Class Initialized
INFO - 2018-03-22 18:33:53 --> Model Class Initialized
INFO - 2018-03-22 18:33:53 --> Model Class Initialized
INFO - 2018-03-22 18:33:53 --> Model Class Initialized
INFO - 2018-03-22 18:33:53 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-22 18:33:53 --> Final output sent to browser
DEBUG - 2018-03-22 18:33:53 --> Total execution time: 0.1179
INFO - 2018-03-22 13:03:54 --> Language Class Initialized
INFO - 2018-03-22 13:03:54 --> Config Class Initialized
INFO - 2018-03-22 13:03:54 --> Loader Class Initialized
INFO - 2018-03-22 18:33:54 --> Helper loaded: url_helper
INFO - 2018-03-22 18:33:54 --> Helper loaded: notification_helper
INFO - 2018-03-22 18:33:54 --> Helper loaded: settings_helper
INFO - 2018-03-22 18:33:54 --> Helper loaded: permission_helper
INFO - 2018-03-22 18:33:54 --> Helper loaded: users_helper
INFO - 2018-03-22 18:33:54 --> Database Driver Class Initialized
DEBUG - 2018-03-22 18:33:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 18:33:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 18:33:54 --> Helper loaded: form_helper
INFO - 2018-03-22 18:33:54 --> Form Validation Class Initialized
INFO - 2018-03-22 18:33:54 --> Controller Class Initialized
INFO - 2018-03-22 18:33:54 --> Model Class Initialized
INFO - 2018-03-22 18:33:54 --> Helper loaded: inflector_helper
DEBUG - 2018-03-22 18:33:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-22 18:33:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-22 18:33:54 --> Model Class Initialized
INFO - 2018-03-22 18:33:54 --> Model Class Initialized
INFO - 2018-03-22 18:33:54 --> Model Class Initialized
INFO - 2018-03-22 18:33:54 --> Model Class Initialized
INFO - 2018-03-22 18:33:54 --> Model Class Initialized
INFO - 2018-03-22 18:33:54 --> Model Class Initialized
INFO - 2018-03-22 18:33:54 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-22 18:33:54 --> Final output sent to browser
DEBUG - 2018-03-22 18:33:54 --> Total execution time: 2.6840
INFO - 2018-03-22 13:53:18 --> Config Class Initialized
INFO - 2018-03-22 13:53:18 --> Hooks Class Initialized
DEBUG - 2018-03-22 13:53:18 --> UTF-8 Support Enabled
INFO - 2018-03-22 13:53:18 --> Utf8 Class Initialized
INFO - 2018-03-22 13:53:18 --> URI Class Initialized
INFO - 2018-03-22 13:53:18 --> Router Class Initialized
INFO - 2018-03-22 13:53:18 --> Output Class Initialized
INFO - 2018-03-22 13:53:18 --> Security Class Initialized
DEBUG - 2018-03-22 13:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 13:53:18 --> Input Class Initialized
INFO - 2018-03-22 13:53:18 --> Language Class Initialized
INFO - 2018-03-22 13:53:18 --> Language Class Initialized
INFO - 2018-03-22 13:53:18 --> Config Class Initialized
INFO - 2018-03-22 13:53:18 --> Loader Class Initialized
INFO - 2018-03-22 19:23:19 --> Helper loaded: url_helper
INFO - 2018-03-22 19:23:19 --> Helper loaded: notification_helper
INFO - 2018-03-22 19:23:19 --> Helper loaded: settings_helper
INFO - 2018-03-22 19:23:19 --> Helper loaded: permission_helper
INFO - 2018-03-22 19:23:19 --> Helper loaded: users_helper
INFO - 2018-03-22 13:53:19 --> Config Class Initialized
INFO - 2018-03-22 13:53:19 --> Hooks Class Initialized
DEBUG - 2018-03-22 13:53:19 --> UTF-8 Support Enabled
INFO - 2018-03-22 13:53:19 --> Utf8 Class Initialized
INFO - 2018-03-22 13:53:19 --> URI Class Initialized
INFO - 2018-03-22 13:53:19 --> Router Class Initialized
INFO - 2018-03-22 19:23:19 --> Database Driver Class Initialized
DEBUG - 2018-03-22 19:23:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 19:23:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 13:53:19 --> Output Class Initialized
INFO - 2018-03-22 13:53:19 --> Security Class Initialized
DEBUG - 2018-03-22 13:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 13:53:19 --> Input Class Initialized
INFO - 2018-03-22 13:53:19 --> Language Class Initialized
INFO - 2018-03-22 19:23:19 --> Helper loaded: form_helper
INFO - 2018-03-22 19:23:19 --> Form Validation Class Initialized
INFO - 2018-03-22 19:23:19 --> Controller Class Initialized
INFO - 2018-03-22 19:23:19 --> Model Class Initialized
INFO - 2018-03-22 19:23:19 --> Helper loaded: inflector_helper
INFO - 2018-03-22 13:53:19 --> Language Class Initialized
INFO - 2018-03-22 13:53:19 --> Config Class Initialized
INFO - 2018-03-22 13:53:19 --> Loader Class Initialized
DEBUG - 2018-03-22 19:23:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-22 19:23:19 --> Helper loaded: url_helper
INFO - 2018-03-22 19:23:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-22 19:23:19 --> Helper loaded: notification_helper
INFO - 2018-03-22 19:23:19 --> Helper loaded: settings_helper
INFO - 2018-03-22 19:23:19 --> Model Class Initialized
INFO - 2018-03-22 19:23:19 --> Model Class Initialized
INFO - 2018-03-22 19:23:19 --> Model Class Initialized
INFO - 2018-03-22 19:23:19 --> Model Class Initialized
INFO - 2018-03-22 19:23:19 --> Helper loaded: permission_helper
INFO - 2018-03-22 19:23:19 --> Helper loaded: users_helper
INFO - 2018-03-22 19:23:19 --> Model Class Initialized
INFO - 2018-03-22 19:23:19 --> Model Class Initialized
INFO - 2018-03-22 19:23:19 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-22 19:23:19 --> Final output sent to browser
DEBUG - 2018-03-22 19:23:19 --> Total execution time: 0.4137
INFO - 2018-03-22 19:23:19 --> Database Driver Class Initialized
DEBUG - 2018-03-22 19:23:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 19:23:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 19:23:19 --> Helper loaded: form_helper
INFO - 2018-03-22 19:23:19 --> Form Validation Class Initialized
INFO - 2018-03-22 19:23:19 --> Controller Class Initialized
INFO - 2018-03-22 19:23:19 --> Model Class Initialized
INFO - 2018-03-22 19:23:19 --> Helper loaded: inflector_helper
DEBUG - 2018-03-22 19:23:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-22 19:23:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-22 19:23:19 --> Model Class Initialized
INFO - 2018-03-22 19:23:19 --> Model Class Initialized
INFO - 2018-03-22 19:23:19 --> Model Class Initialized
INFO - 2018-03-22 19:23:19 --> Model Class Initialized
INFO - 2018-03-22 19:23:19 --> Model Class Initialized
INFO - 2018-03-22 19:23:19 --> Model Class Initialized
INFO - 2018-03-22 19:23:19 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-22 19:23:19 --> Model Class Initialized
INFO - 2018-03-22 19:23:19 --> Final output sent to browser
DEBUG - 2018-03-22 19:23:19 --> Total execution time: 0.2759
INFO - 2018-03-22 13:53:20 --> Config Class Initialized
INFO - 2018-03-22 13:53:20 --> Hooks Class Initialized
DEBUG - 2018-03-22 13:53:20 --> UTF-8 Support Enabled
INFO - 2018-03-22 13:53:20 --> Utf8 Class Initialized
INFO - 2018-03-22 13:53:20 --> URI Class Initialized
INFO - 2018-03-22 13:53:20 --> Router Class Initialized
INFO - 2018-03-22 13:53:20 --> Output Class Initialized
INFO - 2018-03-22 13:53:20 --> Security Class Initialized
DEBUG - 2018-03-22 13:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 13:53:20 --> Input Class Initialized
INFO - 2018-03-22 13:53:20 --> Language Class Initialized
INFO - 2018-03-22 13:53:20 --> Language Class Initialized
INFO - 2018-03-22 13:53:20 --> Config Class Initialized
INFO - 2018-03-22 13:53:20 --> Loader Class Initialized
INFO - 2018-03-22 19:23:20 --> Helper loaded: url_helper
INFO - 2018-03-22 19:23:20 --> Helper loaded: notification_helper
INFO - 2018-03-22 19:23:20 --> Helper loaded: settings_helper
INFO - 2018-03-22 19:23:20 --> Helper loaded: permission_helper
INFO - 2018-03-22 19:23:20 --> Helper loaded: users_helper
INFO - 2018-03-22 13:53:20 --> Config Class Initialized
INFO - 2018-03-22 13:53:20 --> Hooks Class Initialized
DEBUG - 2018-03-22 13:53:20 --> UTF-8 Support Enabled
INFO - 2018-03-22 13:53:20 --> Utf8 Class Initialized
INFO - 2018-03-22 19:23:20 --> Database Driver Class Initialized
INFO - 2018-03-22 13:53:20 --> URI Class Initialized
DEBUG - 2018-03-22 19:23:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 19:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 19:23:20 --> Helper loaded: form_helper
INFO - 2018-03-22 19:23:20 --> Form Validation Class Initialized
INFO - 2018-03-22 19:23:20 --> Controller Class Initialized
INFO - 2018-03-22 13:53:20 --> Router Class Initialized
INFO - 2018-03-22 13:53:20 --> Output Class Initialized
INFO - 2018-03-22 13:53:20 --> Security Class Initialized
INFO - 2018-03-22 19:23:20 --> Model Class Initialized
DEBUG - 2018-03-22 13:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 13:53:20 --> Input Class Initialized
INFO - 2018-03-22 19:23:20 --> Helper loaded: inflector_helper
INFO - 2018-03-22 13:53:20 --> Language Class Initialized
DEBUG - 2018-03-22 19:23:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-22 19:23:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-22 19:23:20 --> Model Class Initialized
INFO - 2018-03-22 19:23:20 --> Model Class Initialized
INFO - 2018-03-22 19:23:20 --> Model Class Initialized
INFO - 2018-03-22 19:23:20 --> Model Class Initialized
INFO - 2018-03-22 19:23:20 --> Model Class Initialized
INFO - 2018-03-22 19:23:20 --> Model Class Initialized
INFO - 2018-03-22 19:23:20 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-22 19:23:20 --> Final output sent to browser
DEBUG - 2018-03-22 19:23:20 --> Total execution time: 0.2577
INFO - 2018-03-22 13:53:20 --> Language Class Initialized
INFO - 2018-03-22 13:53:20 --> Config Class Initialized
INFO - 2018-03-22 13:53:20 --> Loader Class Initialized
INFO - 2018-03-22 19:23:20 --> Helper loaded: url_helper
INFO - 2018-03-22 19:23:20 --> Helper loaded: notification_helper
INFO - 2018-03-22 19:23:20 --> Helper loaded: settings_helper
INFO - 2018-03-22 19:23:20 --> Helper loaded: permission_helper
INFO - 2018-03-22 19:23:20 --> Helper loaded: users_helper
INFO - 2018-03-22 19:23:20 --> Database Driver Class Initialized
DEBUG - 2018-03-22 19:23:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 19:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 19:23:21 --> Helper loaded: form_helper
INFO - 2018-03-22 19:23:21 --> Form Validation Class Initialized
INFO - 2018-03-22 19:23:21 --> Controller Class Initialized
INFO - 2018-03-22 19:23:21 --> Model Class Initialized
INFO - 2018-03-22 19:23:21 --> Helper loaded: inflector_helper
DEBUG - 2018-03-22 19:23:21 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-22 19:23:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-22 19:23:21 --> Model Class Initialized
INFO - 2018-03-22 19:23:21 --> Model Class Initialized
INFO - 2018-03-22 19:23:21 --> Model Class Initialized
INFO - 2018-03-22 19:23:21 --> Model Class Initialized
INFO - 2018-03-22 19:23:21 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-22 19:23:21 --> Final output sent to browser
DEBUG - 2018-03-22 19:23:21 --> Total execution time: 0.4661
INFO - 2018-03-22 13:53:27 --> Config Class Initialized
INFO - 2018-03-22 13:53:27 --> Hooks Class Initialized
DEBUG - 2018-03-22 13:53:27 --> UTF-8 Support Enabled
INFO - 2018-03-22 13:53:27 --> Utf8 Class Initialized
INFO - 2018-03-22 13:53:27 --> URI Class Initialized
INFO - 2018-03-22 13:53:27 --> Router Class Initialized
INFO - 2018-03-22 13:53:27 --> Output Class Initialized
INFO - 2018-03-22 13:53:27 --> Security Class Initialized
DEBUG - 2018-03-22 13:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 13:53:27 --> Input Class Initialized
INFO - 2018-03-22 13:53:27 --> Language Class Initialized
INFO - 2018-03-22 13:53:28 --> Language Class Initialized
INFO - 2018-03-22 13:53:28 --> Config Class Initialized
INFO - 2018-03-22 13:53:28 --> Loader Class Initialized
INFO - 2018-03-22 19:23:28 --> Helper loaded: url_helper
INFO - 2018-03-22 19:23:28 --> Helper loaded: notification_helper
INFO - 2018-03-22 19:23:28 --> Helper loaded: settings_helper
INFO - 2018-03-22 19:23:28 --> Helper loaded: permission_helper
INFO - 2018-03-22 19:23:28 --> Helper loaded: users_helper
INFO - 2018-03-22 19:23:29 --> Database Driver Class Initialized
DEBUG - 2018-03-22 19:23:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 19:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 19:23:29 --> Helper loaded: form_helper
INFO - 2018-03-22 19:23:29 --> Form Validation Class Initialized
INFO - 2018-03-22 19:23:29 --> Controller Class Initialized
INFO - 2018-03-22 19:23:29 --> Model Class Initialized
INFO - 2018-03-22 19:23:29 --> Helper loaded: inflector_helper
DEBUG - 2018-03-22 19:23:29 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-22 19:23:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-22 19:23:29 --> Model Class Initialized
INFO - 2018-03-22 19:23:29 --> Model Class Initialized
INFO - 2018-03-22 19:23:29 --> Model Class Initialized
INFO - 2018-03-22 19:23:29 --> Model Class Initialized
INFO - 2018-03-22 19:23:29 --> Model Class Initialized
INFO - 2018-03-22 19:23:29 --> Model Class Initialized
INFO - 2018-03-22 19:23:29 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-22 19:23:29 --> Final output sent to browser
DEBUG - 2018-03-22 19:23:29 --> Total execution time: 2.1108
INFO - 2018-03-22 14:09:05 --> Config Class Initialized
INFO - 2018-03-22 14:09:05 --> Hooks Class Initialized
DEBUG - 2018-03-22 14:09:05 --> UTF-8 Support Enabled
INFO - 2018-03-22 14:09:05 --> Utf8 Class Initialized
INFO - 2018-03-22 14:09:05 --> URI Class Initialized
INFO - 2018-03-22 14:09:05 --> Router Class Initialized
INFO - 2018-03-22 14:09:05 --> Output Class Initialized
INFO - 2018-03-22 14:09:05 --> Security Class Initialized
DEBUG - 2018-03-22 14:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 14:09:05 --> Input Class Initialized
INFO - 2018-03-22 14:09:05 --> Language Class Initialized
INFO - 2018-03-22 14:09:05 --> Language Class Initialized
INFO - 2018-03-22 14:09:05 --> Config Class Initialized
INFO - 2018-03-22 14:09:05 --> Loader Class Initialized
INFO - 2018-03-22 19:39:05 --> Helper loaded: url_helper
INFO - 2018-03-22 19:39:05 --> Helper loaded: notification_helper
INFO - 2018-03-22 19:39:05 --> Helper loaded: settings_helper
INFO - 2018-03-22 19:39:05 --> Helper loaded: permission_helper
INFO - 2018-03-22 19:39:05 --> Helper loaded: users_helper
INFO - 2018-03-22 19:39:05 --> Database Driver Class Initialized
DEBUG - 2018-03-22 19:39:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 19:39:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 19:39:06 --> Helper loaded: form_helper
INFO - 2018-03-22 19:39:06 --> Form Validation Class Initialized
INFO - 2018-03-22 19:39:06 --> Controller Class Initialized
INFO - 2018-03-22 19:39:06 --> Model Class Initialized
INFO - 2018-03-22 19:39:06 --> Helper loaded: inflector_helper
DEBUG - 2018-03-22 19:39:06 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-22 19:39:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-22 19:39:06 --> Model Class Initialized
INFO - 2018-03-22 19:39:06 --> Model Class Initialized
INFO - 2018-03-22 19:39:06 --> Model Class Initialized
INFO - 2018-03-22 19:39:06 --> Model Class Initialized
INFO - 2018-03-22 19:39:06 --> Model Class Initialized
INFO - 2018-03-22 19:39:06 --> Model Class Initialized
INFO - 2018-03-22 19:39:06 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-22 19:39:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-22 19:39:06 --> Model Class Initialized
INFO - 2018-03-22 19:39:06 --> Email Class Initialized
INFO - 2018-03-22 19:39:11 --> Language file loaded: language/english/email_lang.php
INFO - 2018-03-22 19:39:13 --> Final output sent to browser
DEBUG - 2018-03-22 19:39:13 --> Total execution time: 8.0482
INFO - 2018-03-22 14:09:14 --> Config Class Initialized
INFO - 2018-03-22 14:09:14 --> Hooks Class Initialized
DEBUG - 2018-03-22 14:09:14 --> UTF-8 Support Enabled
INFO - 2018-03-22 14:09:14 --> Utf8 Class Initialized
INFO - 2018-03-22 14:09:14 --> URI Class Initialized
INFO - 2018-03-22 14:09:14 --> Router Class Initialized
INFO - 2018-03-22 14:09:14 --> Output Class Initialized
INFO - 2018-03-22 14:09:14 --> Security Class Initialized
DEBUG - 2018-03-22 14:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 14:09:14 --> Input Class Initialized
INFO - 2018-03-22 14:09:14 --> Language Class Initialized
INFO - 2018-03-22 14:09:14 --> Language Class Initialized
INFO - 2018-03-22 14:09:14 --> Config Class Initialized
INFO - 2018-03-22 14:09:14 --> Loader Class Initialized
INFO - 2018-03-22 19:39:14 --> Helper loaded: url_helper
INFO - 2018-03-22 19:39:14 --> Helper loaded: notification_helper
INFO - 2018-03-22 19:39:14 --> Helper loaded: settings_helper
INFO - 2018-03-22 19:39:14 --> Helper loaded: permission_helper
INFO - 2018-03-22 19:39:14 --> Helper loaded: users_helper
INFO - 2018-03-22 19:39:14 --> Database Driver Class Initialized
DEBUG - 2018-03-22 19:39:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 19:39:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 19:39:14 --> Helper loaded: form_helper
INFO - 2018-03-22 19:39:14 --> Form Validation Class Initialized
INFO - 2018-03-22 19:39:14 --> Controller Class Initialized
INFO - 2018-03-22 19:39:14 --> Model Class Initialized
INFO - 2018-03-22 19:39:14 --> Helper loaded: inflector_helper
DEBUG - 2018-03-22 19:39:14 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-22 19:39:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-22 19:39:14 --> Model Class Initialized
INFO - 2018-03-22 19:39:14 --> Model Class Initialized
INFO - 2018-03-22 19:39:14 --> Model Class Initialized
INFO - 2018-03-22 19:39:14 --> Model Class Initialized
INFO - 2018-03-22 19:39:14 --> Model Class Initialized
INFO - 2018-03-22 19:39:14 --> Model Class Initialized
INFO - 2018-03-22 19:39:14 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-22 19:39:14 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-03-22 19:39:14 --> Final output sent to browser
DEBUG - 2018-03-22 19:39:14 --> Total execution time: 0.1292
INFO - 2018-03-22 14:09:15 --> Config Class Initialized
INFO - 2018-03-22 14:09:15 --> Hooks Class Initialized
DEBUG - 2018-03-22 14:09:15 --> UTF-8 Support Enabled
INFO - 2018-03-22 14:09:15 --> Utf8 Class Initialized
INFO - 2018-03-22 14:09:15 --> URI Class Initialized
INFO - 2018-03-22 14:09:15 --> Router Class Initialized
INFO - 2018-03-22 14:09:15 --> Output Class Initialized
INFO - 2018-03-22 14:09:15 --> Security Class Initialized
DEBUG - 2018-03-22 14:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 14:09:15 --> Input Class Initialized
INFO - 2018-03-22 14:09:15 --> Language Class Initialized
INFO - 2018-03-22 14:09:15 --> Language Class Initialized
INFO - 2018-03-22 14:09:15 --> Config Class Initialized
INFO - 2018-03-22 14:09:15 --> Loader Class Initialized
INFO - 2018-03-22 19:39:16 --> Helper loaded: url_helper
INFO - 2018-03-22 19:39:16 --> Helper loaded: notification_helper
INFO - 2018-03-22 19:39:16 --> Helper loaded: settings_helper
INFO - 2018-03-22 19:39:16 --> Helper loaded: permission_helper
INFO - 2018-03-22 19:39:16 --> Helper loaded: users_helper
INFO - 2018-03-22 19:39:17 --> Database Driver Class Initialized
DEBUG - 2018-03-22 19:39:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 19:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 19:39:17 --> Helper loaded: form_helper
INFO - 2018-03-22 19:39:17 --> Form Validation Class Initialized
INFO - 2018-03-22 19:39:17 --> Controller Class Initialized
INFO - 2018-03-22 19:39:17 --> Model Class Initialized
INFO - 2018-03-22 19:39:17 --> Helper loaded: inflector_helper
DEBUG - 2018-03-22 19:39:17 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-22 19:39:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-22 19:39:17 --> Model Class Initialized
INFO - 2018-03-22 19:39:17 --> Model Class Initialized
INFO - 2018-03-22 19:39:17 --> Model Class Initialized
INFO - 2018-03-22 19:39:17 --> Model Class Initialized
INFO - 2018-03-22 19:39:17 --> Model Class Initialized
INFO - 2018-03-22 19:39:17 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-22 19:39:17 --> Model Class Initialized
INFO - 2018-03-22 19:39:17 --> Final output sent to browser
DEBUG - 2018-03-22 19:39:17 --> Total execution time: 2.5825
INFO - 2018-03-22 14:09:20 --> Config Class Initialized
INFO - 2018-03-22 14:09:20 --> Hooks Class Initialized
DEBUG - 2018-03-22 14:09:20 --> UTF-8 Support Enabled
INFO - 2018-03-22 14:09:20 --> Utf8 Class Initialized
INFO - 2018-03-22 14:09:20 --> URI Class Initialized
INFO - 2018-03-22 14:09:20 --> Router Class Initialized
INFO - 2018-03-22 14:09:20 --> Output Class Initialized
INFO - 2018-03-22 14:09:20 --> Security Class Initialized
DEBUG - 2018-03-22 14:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 14:09:21 --> Input Class Initialized
INFO - 2018-03-22 14:09:21 --> Language Class Initialized
INFO - 2018-03-22 14:09:22 --> Language Class Initialized
INFO - 2018-03-22 14:09:22 --> Config Class Initialized
INFO - 2018-03-22 14:09:22 --> Loader Class Initialized
INFO - 2018-03-22 19:39:22 --> Helper loaded: url_helper
INFO - 2018-03-22 19:39:22 --> Helper loaded: notification_helper
INFO - 2018-03-22 19:39:22 --> Helper loaded: settings_helper
INFO - 2018-03-22 19:39:22 --> Helper loaded: permission_helper
INFO - 2018-03-22 19:39:22 --> Helper loaded: users_helper
INFO - 2018-03-22 19:39:23 --> Database Driver Class Initialized
DEBUG - 2018-03-22 19:39:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 19:39:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 19:39:23 --> Helper loaded: form_helper
INFO - 2018-03-22 19:39:23 --> Form Validation Class Initialized
INFO - 2018-03-22 19:39:23 --> Controller Class Initialized
INFO - 2018-03-22 19:39:23 --> Model Class Initialized
INFO - 2018-03-22 19:39:23 --> Helper loaded: inflector_helper
DEBUG - 2018-03-22 19:39:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-22 19:39:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-22 19:39:23 --> Model Class Initialized
INFO - 2018-03-22 19:39:23 --> Model Class Initialized
INFO - 2018-03-22 19:39:23 --> Model Class Initialized
INFO - 2018-03-22 19:39:23 --> Model Class Initialized
INFO - 2018-03-22 19:39:23 --> Model Class Initialized
INFO - 2018-03-22 19:39:23 --> Model Class Initialized
INFO - 2018-03-22 19:39:23 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-22 19:39:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-03-22 19:39:23 --> Final output sent to browser
DEBUG - 2018-03-22 19:39:23 --> Total execution time: 3.4709
INFO - 2018-03-22 14:14:26 --> Config Class Initialized
INFO - 2018-03-22 14:14:26 --> Hooks Class Initialized
DEBUG - 2018-03-22 14:14:26 --> UTF-8 Support Enabled
INFO - 2018-03-22 14:14:26 --> Utf8 Class Initialized
INFO - 2018-03-22 14:14:26 --> URI Class Initialized
INFO - 2018-03-22 14:14:26 --> Router Class Initialized
INFO - 2018-03-22 14:14:26 --> Output Class Initialized
INFO - 2018-03-22 14:14:26 --> Security Class Initialized
DEBUG - 2018-03-22 14:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 14:14:26 --> Input Class Initialized
INFO - 2018-03-22 14:14:27 --> Language Class Initialized
INFO - 2018-03-22 14:14:27 --> Language Class Initialized
INFO - 2018-03-22 14:14:27 --> Config Class Initialized
INFO - 2018-03-22 14:14:27 --> Loader Class Initialized
INFO - 2018-03-22 19:44:27 --> Helper loaded: url_helper
INFO - 2018-03-22 19:44:27 --> Helper loaded: notification_helper
INFO - 2018-03-22 19:44:27 --> Helper loaded: settings_helper
INFO - 2018-03-22 19:44:27 --> Helper loaded: permission_helper
INFO - 2018-03-22 19:44:27 --> Helper loaded: users_helper
INFO - 2018-03-22 19:44:28 --> Database Driver Class Initialized
DEBUG - 2018-03-22 19:44:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 19:44:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 19:44:28 --> Helper loaded: form_helper
INFO - 2018-03-22 19:44:28 --> Form Validation Class Initialized
INFO - 2018-03-22 19:44:28 --> Controller Class Initialized
INFO - 2018-03-22 19:44:28 --> Model Class Initialized
INFO - 2018-03-22 19:44:28 --> Helper loaded: inflector_helper
DEBUG - 2018-03-22 19:44:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-22 19:44:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-22 19:44:28 --> Model Class Initialized
INFO - 2018-03-22 19:44:28 --> Model Class Initialized
INFO - 2018-03-22 19:44:28 --> Model Class Initialized
INFO - 2018-03-22 19:44:28 --> Model Class Initialized
INFO - 2018-03-22 19:44:28 --> Model Class Initialized
INFO - 2018-03-22 19:44:28 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-22 19:44:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-22 19:44:28 --> Final output sent to browser
DEBUG - 2018-03-22 19:44:28 --> Total execution time: 2.5140
INFO - 2018-03-22 14:14:30 --> Config Class Initialized
INFO - 2018-03-22 14:14:30 --> Hooks Class Initialized
DEBUG - 2018-03-22 14:14:30 --> UTF-8 Support Enabled
INFO - 2018-03-22 14:14:30 --> Utf8 Class Initialized
INFO - 2018-03-22 14:14:30 --> URI Class Initialized
INFO - 2018-03-22 14:14:30 --> Router Class Initialized
INFO - 2018-03-22 14:14:30 --> Output Class Initialized
INFO - 2018-03-22 14:14:30 --> Security Class Initialized
DEBUG - 2018-03-22 14:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 14:14:30 --> Input Class Initialized
INFO - 2018-03-22 14:14:30 --> Language Class Initialized
INFO - 2018-03-22 14:14:30 --> Language Class Initialized
INFO - 2018-03-22 14:14:30 --> Config Class Initialized
INFO - 2018-03-22 14:14:30 --> Loader Class Initialized
INFO - 2018-03-22 19:44:30 --> Helper loaded: url_helper
INFO - 2018-03-22 19:44:30 --> Helper loaded: notification_helper
INFO - 2018-03-22 19:44:30 --> Helper loaded: settings_helper
INFO - 2018-03-22 19:44:30 --> Helper loaded: permission_helper
INFO - 2018-03-22 19:44:30 --> Helper loaded: users_helper
INFO - 2018-03-22 19:44:30 --> Database Driver Class Initialized
DEBUG - 2018-03-22 19:44:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 19:44:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 19:44:30 --> Helper loaded: form_helper
INFO - 2018-03-22 19:44:30 --> Form Validation Class Initialized
INFO - 2018-03-22 19:44:30 --> Controller Class Initialized
INFO - 2018-03-22 19:44:30 --> Model Class Initialized
INFO - 2018-03-22 19:44:30 --> Helper loaded: inflector_helper
DEBUG - 2018-03-22 19:44:30 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-22 19:44:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-22 19:44:30 --> Model Class Initialized
INFO - 2018-03-22 19:44:30 --> Model Class Initialized
INFO - 2018-03-22 19:44:30 --> Model Class Initialized
INFO - 2018-03-22 19:44:30 --> Model Class Initialized
INFO - 2018-03-22 19:44:30 --> Model Class Initialized
INFO - 2018-03-22 19:44:30 --> Model Class Initialized
INFO - 2018-03-22 19:44:30 --> Model Class Initialized
INFO - 2018-03-22 19:44:30 --> Model Class Initialized
INFO - 2018-03-22 19:44:30 --> Model Class Initialized
INFO - 2018-03-22 19:44:30 --> Model Class Initialized
INFO - 2018-03-22 19:44:30 --> Model Class Initialized
INFO - 2018-03-22 19:44:30 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-22 19:44:30 --> Model Class Initialized
INFO - 2018-03-22 19:44:30 --> Final output sent to browser
DEBUG - 2018-03-22 19:44:30 --> Total execution time: 0.0917
INFO - 2018-03-22 14:19:37 --> Config Class Initialized
INFO - 2018-03-22 14:19:37 --> Hooks Class Initialized
DEBUG - 2018-03-22 14:19:37 --> UTF-8 Support Enabled
INFO - 2018-03-22 14:19:37 --> Utf8 Class Initialized
INFO - 2018-03-22 14:19:37 --> URI Class Initialized
INFO - 2018-03-22 14:19:37 --> Router Class Initialized
INFO - 2018-03-22 14:19:37 --> Output Class Initialized
INFO - 2018-03-22 14:19:37 --> Security Class Initialized
DEBUG - 2018-03-22 14:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 14:19:37 --> Input Class Initialized
INFO - 2018-03-22 14:19:37 --> Language Class Initialized
INFO - 2018-03-22 14:19:37 --> Language Class Initialized
INFO - 2018-03-22 14:19:37 --> Config Class Initialized
INFO - 2018-03-22 14:19:37 --> Loader Class Initialized
INFO - 2018-03-22 19:49:37 --> Helper loaded: url_helper
INFO - 2018-03-22 19:49:37 --> Helper loaded: notification_helper
INFO - 2018-03-22 19:49:37 --> Helper loaded: settings_helper
INFO - 2018-03-22 19:49:37 --> Helper loaded: permission_helper
INFO - 2018-03-22 19:49:37 --> Helper loaded: users_helper
INFO - 2018-03-22 19:49:37 --> Database Driver Class Initialized
DEBUG - 2018-03-22 19:49:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 19:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 19:49:37 --> Helper loaded: form_helper
INFO - 2018-03-22 19:49:37 --> Form Validation Class Initialized
INFO - 2018-03-22 19:49:37 --> Controller Class Initialized
INFO - 2018-03-22 19:49:37 --> Model Class Initialized
INFO - 2018-03-22 19:49:37 --> Helper loaded: inflector_helper
DEBUG - 2018-03-22 19:49:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-22 19:49:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-22 19:49:37 --> Model Class Initialized
INFO - 2018-03-22 19:49:37 --> Model Class Initialized
INFO - 2018-03-22 19:49:37 --> Model Class Initialized
INFO - 2018-03-22 19:49:37 --> Model Class Initialized
INFO - 2018-03-22 19:49:37 --> Model Class Initialized
INFO - 2018-03-22 19:49:37 --> Model Class Initialized
INFO - 2018-03-22 19:49:37 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-22 19:49:37 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-22 19:49:37 --> Final output sent to browser
DEBUG - 2018-03-22 19:49:37 --> Total execution time: 0.2114
INFO - 2018-03-22 14:24:49 --> Config Class Initialized
INFO - 2018-03-22 14:24:49 --> Hooks Class Initialized
DEBUG - 2018-03-22 14:24:49 --> UTF-8 Support Enabled
INFO - 2018-03-22 14:24:49 --> Utf8 Class Initialized
INFO - 2018-03-22 14:24:49 --> URI Class Initialized
INFO - 2018-03-22 14:24:49 --> Router Class Initialized
INFO - 2018-03-22 14:24:49 --> Output Class Initialized
INFO - 2018-03-22 14:24:49 --> Security Class Initialized
DEBUG - 2018-03-22 14:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 14:24:49 --> Input Class Initialized
INFO - 2018-03-22 14:24:49 --> Language Class Initialized
INFO - 2018-03-22 14:24:49 --> Language Class Initialized
INFO - 2018-03-22 14:24:49 --> Config Class Initialized
INFO - 2018-03-22 14:24:49 --> Loader Class Initialized
INFO - 2018-03-22 19:54:49 --> Helper loaded: url_helper
INFO - 2018-03-22 19:54:49 --> Helper loaded: notification_helper
INFO - 2018-03-22 19:54:49 --> Helper loaded: settings_helper
INFO - 2018-03-22 19:54:49 --> Helper loaded: permission_helper
INFO - 2018-03-22 19:54:49 --> Helper loaded: users_helper
INFO - 2018-03-22 19:54:49 --> Database Driver Class Initialized
DEBUG - 2018-03-22 19:54:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 19:54:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 19:54:49 --> Helper loaded: form_helper
INFO - 2018-03-22 19:54:49 --> Form Validation Class Initialized
INFO - 2018-03-22 19:54:49 --> Controller Class Initialized
INFO - 2018-03-22 19:54:49 --> Model Class Initialized
INFO - 2018-03-22 19:54:49 --> Helper loaded: inflector_helper
DEBUG - 2018-03-22 19:54:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-22 14:24:50 --> Config Class Initialized
INFO - 2018-03-22 19:54:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-22 14:24:50 --> Hooks Class Initialized
INFO - 2018-03-22 19:54:50 --> Model Class Initialized
INFO - 2018-03-22 19:54:50 --> Model Class Initialized
INFO - 2018-03-22 19:54:50 --> Model Class Initialized
INFO - 2018-03-22 19:54:50 --> Model Class Initialized
INFO - 2018-03-22 19:54:50 --> Model Class Initialized
INFO - 2018-03-22 19:54:50 --> Model Class Initialized
DEBUG - 2018-03-22 14:24:50 --> UTF-8 Support Enabled
INFO - 2018-03-22 14:24:50 --> Utf8 Class Initialized
INFO - 2018-03-22 19:54:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-22 19:54:50 --> Model Class Initialized
INFO - 2018-03-22 14:24:50 --> URI Class Initialized
INFO - 2018-03-22 19:54:50 --> Model Class Initialized
INFO - 2018-03-22 14:24:50 --> Router Class Initialized
INFO - 2018-03-22 19:54:50 --> Model Class Initialized
INFO - 2018-03-22 14:24:50 --> Output Class Initialized
INFO - 2018-03-22 14:24:50 --> Security Class Initialized
DEBUG - 2018-03-22 14:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 14:24:50 --> Input Class Initialized
INFO - 2018-03-22 14:24:50 --> Language Class Initialized
INFO - 2018-03-22 14:24:50 --> Language Class Initialized
INFO - 2018-03-22 14:24:50 --> Config Class Initialized
INFO - 2018-03-22 14:24:50 --> Loader Class Initialized
INFO - 2018-03-22 19:54:50 --> Helper loaded: url_helper
INFO - 2018-03-22 19:54:50 --> Helper loaded: notification_helper
INFO - 2018-03-22 19:54:50 --> Helper loaded: settings_helper
INFO - 2018-03-22 19:54:50 --> Helper loaded: permission_helper
INFO - 2018-03-22 19:54:50 --> Helper loaded: users_helper
INFO - 2018-03-22 19:54:50 --> Database Driver Class Initialized
DEBUG - 2018-03-22 19:54:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 19:54:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 19:54:50 --> Helper loaded: form_helper
INFO - 2018-03-22 19:54:50 --> Form Validation Class Initialized
INFO - 2018-03-22 19:54:50 --> Controller Class Initialized
INFO - 2018-03-22 19:54:50 --> Model Class Initialized
INFO - 2018-03-22 19:54:50 --> Helper loaded: inflector_helper
DEBUG - 2018-03-22 19:54:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-22 19:54:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-22 19:54:50 --> Model Class Initialized
INFO - 2018-03-22 19:54:50 --> Model Class Initialized
INFO - 2018-03-22 19:54:50 --> Model Class Initialized
INFO - 2018-03-22 19:54:50 --> Model Class Initialized
INFO - 2018-03-22 19:54:50 --> Model Class Initialized
INFO - 2018-03-22 19:54:50 --> Model Class Initialized
INFO - 2018-03-22 19:54:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-22 19:54:50 --> Model Class Initialized
INFO - 2018-03-22 19:54:50 --> Model Class Initialized
INFO - 2018-03-22 19:54:50 --> Final output sent to browser
DEBUG - 2018-03-22 19:54:50 --> Total execution time: 0.3885
INFO - 2018-03-22 14:24:50 --> Config Class Initialized
INFO - 2018-03-22 14:24:50 --> Hooks Class Initialized
DEBUG - 2018-03-22 14:24:50 --> UTF-8 Support Enabled
INFO - 2018-03-22 14:24:50 --> Utf8 Class Initialized
INFO - 2018-03-22 14:24:50 --> URI Class Initialized
INFO - 2018-03-22 14:24:50 --> Router Class Initialized
INFO - 2018-03-22 14:24:50 --> Output Class Initialized
INFO - 2018-03-22 14:24:50 --> Security Class Initialized
DEBUG - 2018-03-22 14:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 14:24:50 --> Input Class Initialized
INFO - 2018-03-22 14:24:50 --> Language Class Initialized
INFO - 2018-03-22 14:24:50 --> Language Class Initialized
INFO - 2018-03-22 14:24:50 --> Config Class Initialized
INFO - 2018-03-22 14:24:50 --> Loader Class Initialized
INFO - 2018-03-22 19:54:51 --> Helper loaded: url_helper
INFO - 2018-03-22 19:54:51 --> Helper loaded: notification_helper
INFO - 2018-03-22 19:54:51 --> Helper loaded: settings_helper
INFO - 2018-03-22 19:54:51 --> Helper loaded: permission_helper
INFO - 2018-03-22 19:54:51 --> Helper loaded: users_helper
INFO - 2018-03-22 19:54:51 --> Final output sent to browser
DEBUG - 2018-03-22 19:54:51 --> Total execution time: 1.8914
INFO - 2018-03-22 19:54:51 --> Database Driver Class Initialized
DEBUG - 2018-03-22 19:54:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 19:54:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 19:54:51 --> Helper loaded: form_helper
INFO - 2018-03-22 19:54:51 --> Form Validation Class Initialized
INFO - 2018-03-22 19:54:51 --> Controller Class Initialized
INFO - 2018-03-22 19:54:51 --> Model Class Initialized
INFO - 2018-03-22 19:54:51 --> Helper loaded: inflector_helper
DEBUG - 2018-03-22 19:54:51 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-22 19:54:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-22 19:54:51 --> Model Class Initialized
INFO - 2018-03-22 19:54:51 --> Model Class Initialized
INFO - 2018-03-22 19:54:51 --> Model Class Initialized
INFO - 2018-03-22 19:54:51 --> Model Class Initialized
INFO - 2018-03-22 19:54:51 --> Model Class Initialized
INFO - 2018-03-22 19:54:51 --> Model Class Initialized
INFO - 2018-03-22 19:54:51 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-22 19:54:51 --> Model Class Initialized
INFO - 2018-03-22 19:54:51 --> Model Class Initialized
INFO - 2018-03-22 19:54:51 --> Model Class Initialized
INFO - 2018-03-22 19:54:53 --> Final output sent to browser
DEBUG - 2018-03-22 19:54:53 --> Total execution time: 3.5711
INFO - 2018-03-22 14:26:50 --> Config Class Initialized
INFO - 2018-03-22 14:26:50 --> Hooks Class Initialized
DEBUG - 2018-03-22 14:26:50 --> UTF-8 Support Enabled
INFO - 2018-03-22 14:26:50 --> Utf8 Class Initialized
INFO - 2018-03-22 14:26:50 --> URI Class Initialized
INFO - 2018-03-22 14:26:50 --> Router Class Initialized
INFO - 2018-03-22 14:26:51 --> Output Class Initialized
INFO - 2018-03-22 14:26:51 --> Security Class Initialized
DEBUG - 2018-03-22 14:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 14:26:51 --> Input Class Initialized
INFO - 2018-03-22 14:26:51 --> Language Class Initialized
INFO - 2018-03-22 14:26:52 --> Language Class Initialized
INFO - 2018-03-22 14:26:52 --> Config Class Initialized
INFO - 2018-03-22 14:26:52 --> Loader Class Initialized
INFO - 2018-03-22 19:56:53 --> Helper loaded: url_helper
INFO - 2018-03-22 19:56:53 --> Helper loaded: notification_helper
INFO - 2018-03-22 19:56:53 --> Helper loaded: settings_helper
INFO - 2018-03-22 19:56:53 --> Helper loaded: permission_helper
INFO - 2018-03-22 19:56:53 --> Helper loaded: users_helper
INFO - 2018-03-22 19:56:53 --> Database Driver Class Initialized
DEBUG - 2018-03-22 19:56:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 19:56:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 19:56:54 --> Helper loaded: form_helper
INFO - 2018-03-22 19:56:54 --> Form Validation Class Initialized
INFO - 2018-03-22 19:56:54 --> Controller Class Initialized
INFO - 2018-03-22 19:56:54 --> Model Class Initialized
INFO - 2018-03-22 19:56:54 --> Helper loaded: inflector_helper
DEBUG - 2018-03-22 19:56:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-22 19:56:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-22 19:56:55 --> Model Class Initialized
INFO - 2018-03-22 19:56:55 --> Model Class Initialized
INFO - 2018-03-22 19:56:55 --> Model Class Initialized
INFO - 2018-03-22 19:56:55 --> Model Class Initialized
INFO - 2018-03-22 19:56:55 --> Model Class Initialized
INFO - 2018-03-22 19:56:55 --> Model Class Initialized
INFO - 2018-03-22 19:56:55 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-22 19:56:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-03-22 19:56:55 --> Final output sent to browser
DEBUG - 2018-03-22 19:56:55 --> Total execution time: 5.6518
INFO - 2018-03-22 14:26:57 --> Config Class Initialized
INFO - 2018-03-22 14:26:57 --> Hooks Class Initialized
DEBUG - 2018-03-22 14:26:57 --> UTF-8 Support Enabled
INFO - 2018-03-22 14:26:57 --> Utf8 Class Initialized
INFO - 2018-03-22 14:26:57 --> URI Class Initialized
INFO - 2018-03-22 14:26:57 --> Router Class Initialized
INFO - 2018-03-22 14:26:57 --> Output Class Initialized
INFO - 2018-03-22 14:26:57 --> Security Class Initialized
DEBUG - 2018-03-22 14:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 14:26:57 --> Input Class Initialized
INFO - 2018-03-22 14:26:57 --> Language Class Initialized
INFO - 2018-03-22 14:26:57 --> Language Class Initialized
INFO - 2018-03-22 14:26:57 --> Config Class Initialized
INFO - 2018-03-22 14:26:57 --> Loader Class Initialized
INFO - 2018-03-22 19:56:57 --> Helper loaded: url_helper
INFO - 2018-03-22 19:56:57 --> Helper loaded: notification_helper
INFO - 2018-03-22 19:56:57 --> Helper loaded: settings_helper
INFO - 2018-03-22 19:56:57 --> Helper loaded: permission_helper
INFO - 2018-03-22 19:56:57 --> Helper loaded: users_helper
INFO - 2018-03-22 19:56:58 --> Database Driver Class Initialized
DEBUG - 2018-03-22 19:56:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 19:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 19:56:58 --> Helper loaded: form_helper
INFO - 2018-03-22 19:56:58 --> Form Validation Class Initialized
INFO - 2018-03-22 19:56:58 --> Controller Class Initialized
INFO - 2018-03-22 19:56:58 --> Model Class Initialized
INFO - 2018-03-22 19:56:58 --> Helper loaded: inflector_helper
DEBUG - 2018-03-22 19:56:58 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-22 19:56:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-22 19:56:58 --> Model Class Initialized
INFO - 2018-03-22 19:56:58 --> Model Class Initialized
INFO - 2018-03-22 19:56:58 --> Model Class Initialized
INFO - 2018-03-22 19:56:58 --> Model Class Initialized
INFO - 2018-03-22 19:56:58 --> Model Class Initialized
INFO - 2018-03-22 19:56:58 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-22 19:56:58 --> Model Class Initialized
INFO - 2018-03-22 19:56:58 --> Final output sent to browser
DEBUG - 2018-03-22 19:56:58 --> Total execution time: 0.4274
INFO - 2018-03-22 14:26:59 --> Config Class Initialized
INFO - 2018-03-22 14:26:59 --> Hooks Class Initialized
DEBUG - 2018-03-22 14:26:59 --> UTF-8 Support Enabled
INFO - 2018-03-22 14:26:59 --> Utf8 Class Initialized
INFO - 2018-03-22 14:26:59 --> URI Class Initialized
INFO - 2018-03-22 14:26:59 --> Router Class Initialized
INFO - 2018-03-22 14:26:59 --> Output Class Initialized
INFO - 2018-03-22 14:26:59 --> Security Class Initialized
DEBUG - 2018-03-22 14:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 14:26:59 --> Input Class Initialized
INFO - 2018-03-22 14:26:59 --> Language Class Initialized
INFO - 2018-03-22 14:26:59 --> Language Class Initialized
INFO - 2018-03-22 14:26:59 --> Config Class Initialized
INFO - 2018-03-22 14:26:59 --> Loader Class Initialized
INFO - 2018-03-22 19:56:59 --> Helper loaded: url_helper
INFO - 2018-03-22 19:56:59 --> Helper loaded: notification_helper
INFO - 2018-03-22 19:56:59 --> Helper loaded: settings_helper
INFO - 2018-03-22 19:56:59 --> Helper loaded: permission_helper
INFO - 2018-03-22 19:56:59 --> Helper loaded: users_helper
INFO - 2018-03-22 19:56:59 --> Database Driver Class Initialized
DEBUG - 2018-03-22 19:56:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 19:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 19:56:59 --> Helper loaded: form_helper
INFO - 2018-03-22 19:56:59 --> Form Validation Class Initialized
INFO - 2018-03-22 19:56:59 --> Controller Class Initialized
INFO - 2018-03-22 19:56:59 --> Model Class Initialized
INFO - 2018-03-22 19:56:59 --> Helper loaded: inflector_helper
DEBUG - 2018-03-22 19:56:59 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-22 19:56:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-22 19:56:59 --> Model Class Initialized
INFO - 2018-03-22 19:56:59 --> Model Class Initialized
INFO - 2018-03-22 19:56:59 --> Model Class Initialized
INFO - 2018-03-22 19:56:59 --> Model Class Initialized
INFO - 2018-03-22 19:56:59 --> Model Class Initialized
INFO - 2018-03-22 19:56:59 --> Model Class Initialized
INFO - 2018-03-22 19:56:59 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-22 19:56:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-03-22 19:56:59 --> Final output sent to browser
DEBUG - 2018-03-22 19:56:59 --> Total execution time: 0.1075
INFO - 2018-03-22 14:30:04 --> Config Class Initialized
INFO - 2018-03-22 14:30:04 --> Hooks Class Initialized
DEBUG - 2018-03-22 14:30:04 --> UTF-8 Support Enabled
INFO - 2018-03-22 14:30:04 --> Utf8 Class Initialized
INFO - 2018-03-22 14:30:05 --> URI Class Initialized
INFO - 2018-03-22 14:30:05 --> Router Class Initialized
INFO - 2018-03-22 14:30:05 --> Output Class Initialized
INFO - 2018-03-22 14:30:05 --> Security Class Initialized
DEBUG - 2018-03-22 14:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 14:30:05 --> Input Class Initialized
INFO - 2018-03-22 14:30:05 --> Language Class Initialized
INFO - 2018-03-22 14:30:06 --> Language Class Initialized
INFO - 2018-03-22 14:30:06 --> Config Class Initialized
INFO - 2018-03-22 14:30:06 --> Loader Class Initialized
INFO - 2018-03-22 20:00:06 --> Helper loaded: url_helper
INFO - 2018-03-22 20:00:06 --> Helper loaded: notification_helper
INFO - 2018-03-22 20:00:06 --> Helper loaded: settings_helper
INFO - 2018-03-22 20:00:06 --> Helper loaded: permission_helper
INFO - 2018-03-22 20:00:06 --> Helper loaded: users_helper
INFO - 2018-03-22 20:00:07 --> Database Driver Class Initialized
DEBUG - 2018-03-22 20:00:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 20:00:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 20:00:07 --> Helper loaded: form_helper
INFO - 2018-03-22 20:00:07 --> Form Validation Class Initialized
INFO - 2018-03-22 20:00:07 --> Controller Class Initialized
INFO - 2018-03-22 20:00:08 --> Model Class Initialized
INFO - 2018-03-22 20:00:08 --> Helper loaded: inflector_helper
DEBUG - 2018-03-22 20:00:08 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-22 20:00:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-22 20:00:08 --> Model Class Initialized
INFO - 2018-03-22 20:00:08 --> Model Class Initialized
INFO - 2018-03-22 20:00:08 --> Model Class Initialized
INFO - 2018-03-22 20:00:08 --> Model Class Initialized
INFO - 2018-03-22 20:00:08 --> Model Class Initialized
INFO - 2018-03-22 20:00:08 --> Model Class Initialized
INFO - 2018-03-22 20:00:08 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-22 20:00:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-03-22 20:00:08 --> Final output sent to browser
DEBUG - 2018-03-22 20:00:08 --> Total execution time: 3.9790
INFO - 2018-03-22 14:30:09 --> Config Class Initialized
INFO - 2018-03-22 14:30:09 --> Hooks Class Initialized
DEBUG - 2018-03-22 14:30:09 --> UTF-8 Support Enabled
INFO - 2018-03-22 14:30:09 --> Utf8 Class Initialized
INFO - 2018-03-22 14:30:09 --> URI Class Initialized
INFO - 2018-03-22 14:30:09 --> Router Class Initialized
INFO - 2018-03-22 14:30:09 --> Output Class Initialized
INFO - 2018-03-22 14:30:09 --> Security Class Initialized
DEBUG - 2018-03-22 14:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 14:30:09 --> Input Class Initialized
INFO - 2018-03-22 14:30:09 --> Language Class Initialized
INFO - 2018-03-22 14:30:09 --> Language Class Initialized
INFO - 2018-03-22 14:30:09 --> Config Class Initialized
INFO - 2018-03-22 14:30:09 --> Loader Class Initialized
INFO - 2018-03-22 20:00:09 --> Helper loaded: url_helper
INFO - 2018-03-22 20:00:09 --> Helper loaded: notification_helper
INFO - 2018-03-22 20:00:09 --> Helper loaded: settings_helper
INFO - 2018-03-22 20:00:09 --> Helper loaded: permission_helper
INFO - 2018-03-22 20:00:09 --> Helper loaded: users_helper
INFO - 2018-03-22 20:00:09 --> Database Driver Class Initialized
DEBUG - 2018-03-22 20:00:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 20:00:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 20:00:09 --> Helper loaded: form_helper
INFO - 2018-03-22 20:00:09 --> Form Validation Class Initialized
INFO - 2018-03-22 20:00:09 --> Controller Class Initialized
INFO - 2018-03-22 20:00:09 --> Model Class Initialized
INFO - 2018-03-22 20:00:09 --> Helper loaded: inflector_helper
DEBUG - 2018-03-22 20:00:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-22 20:00:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-22 20:00:09 --> Model Class Initialized
INFO - 2018-03-22 20:00:09 --> Model Class Initialized
INFO - 2018-03-22 20:00:09 --> Model Class Initialized
INFO - 2018-03-22 20:00:09 --> Model Class Initialized
INFO - 2018-03-22 20:00:09 --> Model Class Initialized
INFO - 2018-03-22 20:00:09 --> Model Class Initialized
INFO - 2018-03-22 20:00:09 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-22 20:00:09 --> Final output sent to browser
DEBUG - 2018-03-22 20:00:09 --> Total execution time: 0.2628
INFO - 2018-03-22 14:30:11 --> Config Class Initialized
INFO - 2018-03-22 14:30:11 --> Hooks Class Initialized
DEBUG - 2018-03-22 14:30:11 --> UTF-8 Support Enabled
INFO - 2018-03-22 14:30:11 --> Utf8 Class Initialized
INFO - 2018-03-22 14:30:11 --> URI Class Initialized
INFO - 2018-03-22 14:30:11 --> Router Class Initialized
INFO - 2018-03-22 14:30:11 --> Output Class Initialized
INFO - 2018-03-22 14:30:11 --> Security Class Initialized
DEBUG - 2018-03-22 14:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 14:30:11 --> Input Class Initialized
INFO - 2018-03-22 14:30:11 --> Language Class Initialized
INFO - 2018-03-22 14:30:11 --> Language Class Initialized
INFO - 2018-03-22 14:30:11 --> Config Class Initialized
INFO - 2018-03-22 14:30:11 --> Loader Class Initialized
INFO - 2018-03-22 20:00:11 --> Helper loaded: url_helper
INFO - 2018-03-22 20:00:11 --> Helper loaded: notification_helper
INFO - 2018-03-22 20:00:11 --> Helper loaded: settings_helper
INFO - 2018-03-22 20:00:11 --> Helper loaded: permission_helper
INFO - 2018-03-22 20:00:11 --> Helper loaded: users_helper
INFO - 2018-03-22 20:00:11 --> Database Driver Class Initialized
DEBUG - 2018-03-22 20:00:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 20:00:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 20:00:11 --> Helper loaded: form_helper
INFO - 2018-03-22 20:00:11 --> Form Validation Class Initialized
INFO - 2018-03-22 20:00:11 --> Controller Class Initialized
INFO - 2018-03-22 20:00:11 --> Model Class Initialized
INFO - 2018-03-22 20:00:11 --> Helper loaded: inflector_helper
DEBUG - 2018-03-22 20:00:11 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-22 20:00:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-22 20:00:11 --> Model Class Initialized
INFO - 2018-03-22 20:00:11 --> Model Class Initialized
INFO - 2018-03-22 20:00:11 --> Model Class Initialized
INFO - 2018-03-22 20:00:11 --> Model Class Initialized
INFO - 2018-03-22 20:00:11 --> Model Class Initialized
INFO - 2018-03-22 20:00:11 --> Model Class Initialized
INFO - 2018-03-22 20:00:11 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-22 20:00:11 --> Model Class Initialized
INFO - 2018-03-22 20:00:11 --> Final output sent to browser
DEBUG - 2018-03-22 20:00:11 --> Total execution time: 0.1150
INFO - 2018-03-22 14:30:12 --> Config Class Initialized
INFO - 2018-03-22 14:30:12 --> Hooks Class Initialized
DEBUG - 2018-03-22 14:30:12 --> UTF-8 Support Enabled
INFO - 2018-03-22 14:30:12 --> Utf8 Class Initialized
INFO - 2018-03-22 14:30:12 --> URI Class Initialized
INFO - 2018-03-22 14:30:12 --> Router Class Initialized
INFO - 2018-03-22 14:30:12 --> Output Class Initialized
INFO - 2018-03-22 14:30:12 --> Security Class Initialized
DEBUG - 2018-03-22 14:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 14:30:12 --> Input Class Initialized
INFO - 2018-03-22 14:30:12 --> Language Class Initialized
INFO - 2018-03-22 14:30:12 --> Language Class Initialized
INFO - 2018-03-22 14:30:12 --> Config Class Initialized
INFO - 2018-03-22 14:30:12 --> Loader Class Initialized
INFO - 2018-03-22 20:00:12 --> Helper loaded: url_helper
INFO - 2018-03-22 20:00:12 --> Helper loaded: notification_helper
INFO - 2018-03-22 20:00:12 --> Helper loaded: settings_helper
INFO - 2018-03-22 20:00:12 --> Helper loaded: permission_helper
INFO - 2018-03-22 20:00:12 --> Helper loaded: users_helper
INFO - 2018-03-22 20:00:12 --> Database Driver Class Initialized
DEBUG - 2018-03-22 20:00:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 20:00:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 20:00:12 --> Helper loaded: form_helper
INFO - 2018-03-22 20:00:12 --> Form Validation Class Initialized
INFO - 2018-03-22 20:00:12 --> Controller Class Initialized
INFO - 2018-03-22 20:00:12 --> Model Class Initialized
INFO - 2018-03-22 20:00:12 --> Helper loaded: inflector_helper
DEBUG - 2018-03-22 20:00:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-22 20:00:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-22 20:00:12 --> Model Class Initialized
INFO - 2018-03-22 20:00:12 --> Model Class Initialized
INFO - 2018-03-22 20:00:12 --> Model Class Initialized
INFO - 2018-03-22 20:00:12 --> Model Class Initialized
INFO - 2018-03-22 20:00:12 --> Model Class Initialized
INFO - 2018-03-22 20:00:12 --> Model Class Initialized
INFO - 2018-03-22 20:00:12 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-22 20:00:12 --> Final output sent to browser
DEBUG - 2018-03-22 20:00:12 --> Total execution time: 0.1412
INFO - 2018-03-22 14:30:13 --> Config Class Initialized
INFO - 2018-03-22 14:30:13 --> Hooks Class Initialized
DEBUG - 2018-03-22 14:30:13 --> UTF-8 Support Enabled
INFO - 2018-03-22 14:30:13 --> Utf8 Class Initialized
INFO - 2018-03-22 14:30:13 --> URI Class Initialized
INFO - 2018-03-22 14:30:13 --> Router Class Initialized
INFO - 2018-03-22 14:30:13 --> Output Class Initialized
INFO - 2018-03-22 14:30:13 --> Security Class Initialized
DEBUG - 2018-03-22 14:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 14:30:13 --> Input Class Initialized
INFO - 2018-03-22 14:30:13 --> Language Class Initialized
INFO - 2018-03-22 14:30:13 --> Language Class Initialized
INFO - 2018-03-22 14:30:13 --> Config Class Initialized
INFO - 2018-03-22 14:30:13 --> Loader Class Initialized
INFO - 2018-03-22 20:00:13 --> Helper loaded: url_helper
INFO - 2018-03-22 20:00:13 --> Helper loaded: notification_helper
INFO - 2018-03-22 20:00:13 --> Helper loaded: settings_helper
INFO - 2018-03-22 20:00:13 --> Helper loaded: permission_helper
INFO - 2018-03-22 20:00:13 --> Helper loaded: users_helper
INFO - 2018-03-22 20:00:13 --> Database Driver Class Initialized
DEBUG - 2018-03-22 20:00:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 20:00:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 20:00:13 --> Helper loaded: form_helper
INFO - 2018-03-22 20:00:13 --> Form Validation Class Initialized
INFO - 2018-03-22 20:00:13 --> Controller Class Initialized
INFO - 2018-03-22 20:00:13 --> Model Class Initialized
INFO - 2018-03-22 20:00:13 --> Helper loaded: inflector_helper
DEBUG - 2018-03-22 20:00:13 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-22 20:00:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-22 20:00:13 --> Model Class Initialized
INFO - 2018-03-22 20:00:13 --> Model Class Initialized
INFO - 2018-03-22 20:00:13 --> Model Class Initialized
INFO - 2018-03-22 20:00:13 --> Model Class Initialized
INFO - 2018-03-22 20:00:13 --> Model Class Initialized
INFO - 2018-03-22 20:00:13 --> Model Class Initialized
INFO - 2018-03-22 20:00:13 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-22 20:00:13 --> Model Class Initialized
INFO - 2018-03-22 20:00:13 --> Final output sent to browser
DEBUG - 2018-03-22 20:00:13 --> Total execution time: 0.2290
INFO - 2018-03-22 14:30:13 --> Config Class Initialized
INFO - 2018-03-22 14:30:13 --> Hooks Class Initialized
DEBUG - 2018-03-22 14:30:13 --> UTF-8 Support Enabled
INFO - 2018-03-22 14:30:13 --> Utf8 Class Initialized
INFO - 2018-03-22 14:30:13 --> URI Class Initialized
INFO - 2018-03-22 14:30:13 --> Router Class Initialized
INFO - 2018-03-22 14:30:13 --> Output Class Initialized
INFO - 2018-03-22 14:30:14 --> Config Class Initialized
INFO - 2018-03-22 14:30:14 --> Hooks Class Initialized
INFO - 2018-03-22 14:30:14 --> Security Class Initialized
DEBUG - 2018-03-22 14:30:14 --> UTF-8 Support Enabled
INFO - 2018-03-22 14:30:14 --> Utf8 Class Initialized
INFO - 2018-03-22 14:30:14 --> URI Class Initialized
DEBUG - 2018-03-22 14:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 14:30:14 --> Input Class Initialized
INFO - 2018-03-22 14:30:14 --> Language Class Initialized
INFO - 2018-03-22 14:30:14 --> Router Class Initialized
INFO - 2018-03-22 14:30:14 --> Output Class Initialized
INFO - 2018-03-22 14:30:14 --> Security Class Initialized
DEBUG - 2018-03-22 14:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 14:30:14 --> Input Class Initialized
INFO - 2018-03-22 14:30:14 --> Language Class Initialized
INFO - 2018-03-22 14:30:15 --> Language Class Initialized
INFO - 2018-03-22 14:30:15 --> Config Class Initialized
INFO - 2018-03-22 14:30:15 --> Loader Class Initialized
INFO - 2018-03-22 20:00:15 --> Helper loaded: url_helper
INFO - 2018-03-22 20:00:15 --> Helper loaded: notification_helper
INFO - 2018-03-22 20:00:15 --> Helper loaded: settings_helper
INFO - 2018-03-22 20:00:15 --> Helper loaded: permission_helper
INFO - 2018-03-22 20:00:15 --> Helper loaded: users_helper
INFO - 2018-03-22 14:30:15 --> Language Class Initialized
INFO - 2018-03-22 14:30:15 --> Config Class Initialized
INFO - 2018-03-22 14:30:15 --> Loader Class Initialized
INFO - 2018-03-22 20:00:15 --> Helper loaded: url_helper
INFO - 2018-03-22 20:00:15 --> Helper loaded: notification_helper
INFO - 2018-03-22 20:00:15 --> Helper loaded: settings_helper
INFO - 2018-03-22 20:00:15 --> Helper loaded: permission_helper
INFO - 2018-03-22 20:00:15 --> Helper loaded: users_helper
INFO - 2018-03-22 20:00:15 --> Database Driver Class Initialized
DEBUG - 2018-03-22 20:00:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 20:00:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 20:00:16 --> Helper loaded: form_helper
INFO - 2018-03-22 20:00:16 --> Form Validation Class Initialized
INFO - 2018-03-22 20:00:16 --> Controller Class Initialized
INFO - 2018-03-22 20:00:16 --> Database Driver Class Initialized
DEBUG - 2018-03-22 20:00:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 20:00:16 --> Model Class Initialized
INFO - 2018-03-22 20:00:16 --> Helper loaded: inflector_helper
DEBUG - 2018-03-22 20:00:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-22 20:00:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-22 20:00:16 --> Model Class Initialized
INFO - 2018-03-22 20:00:16 --> Model Class Initialized
INFO - 2018-03-22 20:00:16 --> Model Class Initialized
INFO - 2018-03-22 20:00:16 --> Model Class Initialized
INFO - 2018-03-22 20:00:16 --> Model Class Initialized
INFO - 2018-03-22 20:00:16 --> Model Class Initialized
INFO - 2018-03-22 20:00:16 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-22 20:00:16 --> Final output sent to browser
DEBUG - 2018-03-22 20:00:16 --> Total execution time: 2.7862
INFO - 2018-03-22 20:00:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 20:00:16 --> Helper loaded: form_helper
INFO - 2018-03-22 20:00:16 --> Form Validation Class Initialized
INFO - 2018-03-22 20:00:16 --> Controller Class Initialized
INFO - 2018-03-22 20:00:16 --> Model Class Initialized
INFO - 2018-03-22 20:00:16 --> Helper loaded: inflector_helper
DEBUG - 2018-03-22 20:00:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-22 20:00:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-22 20:00:16 --> Model Class Initialized
INFO - 2018-03-22 20:00:16 --> Model Class Initialized
INFO - 2018-03-22 20:00:16 --> Model Class Initialized
INFO - 2018-03-22 20:00:16 --> Model Class Initialized
INFO - 2018-03-22 20:00:16 --> Model Class Initialized
INFO - 2018-03-22 20:00:16 --> Model Class Initialized
INFO - 2018-03-22 20:00:16 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-22 20:00:16 --> Final output sent to browser
DEBUG - 2018-03-22 20:00:16 --> Total execution time: 2.7153
INFO - 2018-03-22 14:33:20 --> Config Class Initialized
INFO - 2018-03-22 14:33:20 --> Hooks Class Initialized
DEBUG - 2018-03-22 14:33:20 --> UTF-8 Support Enabled
INFO - 2018-03-22 14:33:20 --> Utf8 Class Initialized
INFO - 2018-03-22 14:33:20 --> URI Class Initialized
INFO - 2018-03-22 14:33:20 --> Router Class Initialized
INFO - 2018-03-22 14:33:20 --> Output Class Initialized
INFO - 2018-03-22 14:33:20 --> Security Class Initialized
DEBUG - 2018-03-22 14:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 14:33:20 --> Input Class Initialized
INFO - 2018-03-22 14:33:20 --> Language Class Initialized
INFO - 2018-03-22 14:33:20 --> Language Class Initialized
INFO - 2018-03-22 14:33:20 --> Config Class Initialized
INFO - 2018-03-22 14:33:20 --> Loader Class Initialized
INFO - 2018-03-22 20:03:20 --> Helper loaded: url_helper
INFO - 2018-03-22 20:03:20 --> Helper loaded: notification_helper
INFO - 2018-03-22 20:03:20 --> Helper loaded: settings_helper
INFO - 2018-03-22 20:03:20 --> Helper loaded: permission_helper
INFO - 2018-03-22 20:03:20 --> Helper loaded: users_helper
INFO - 2018-03-22 20:03:20 --> Database Driver Class Initialized
DEBUG - 2018-03-22 20:03:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 20:03:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 20:03:20 --> Helper loaded: form_helper
INFO - 2018-03-22 20:03:20 --> Form Validation Class Initialized
INFO - 2018-03-22 20:03:20 --> Controller Class Initialized
INFO - 2018-03-22 20:03:20 --> Model Class Initialized
INFO - 2018-03-22 20:03:20 --> Helper loaded: inflector_helper
DEBUG - 2018-03-22 20:03:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-22 20:03:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-22 20:03:20 --> Model Class Initialized
INFO - 2018-03-22 20:03:20 --> Model Class Initialized
INFO - 2018-03-22 20:03:20 --> Model Class Initialized
INFO - 2018-03-22 20:03:20 --> Model Class Initialized
INFO - 2018-03-22 20:03:20 --> Model Class Initialized
INFO - 2018-03-22 20:03:20 --> Model Class Initialized
INFO - 2018-03-22 20:03:20 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-22 20:03:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-03-22 20:03:20 --> Final output sent to browser
DEBUG - 2018-03-22 20:03:20 --> Total execution time: 0.2493
INFO - 2018-03-22 14:33:21 --> Config Class Initialized
INFO - 2018-03-22 14:33:21 --> Hooks Class Initialized
DEBUG - 2018-03-22 14:33:21 --> UTF-8 Support Enabled
INFO - 2018-03-22 14:33:21 --> Utf8 Class Initialized
INFO - 2018-03-22 14:33:21 --> URI Class Initialized
INFO - 2018-03-22 14:33:21 --> Router Class Initialized
INFO - 2018-03-22 14:33:21 --> Output Class Initialized
INFO - 2018-03-22 14:33:21 --> Security Class Initialized
DEBUG - 2018-03-22 14:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 14:33:21 --> Input Class Initialized
INFO - 2018-03-22 14:33:21 --> Language Class Initialized
INFO - 2018-03-22 14:33:21 --> Language Class Initialized
INFO - 2018-03-22 14:33:21 --> Config Class Initialized
INFO - 2018-03-22 14:33:21 --> Loader Class Initialized
INFO - 2018-03-22 20:03:21 --> Helper loaded: url_helper
INFO - 2018-03-22 20:03:21 --> Helper loaded: notification_helper
INFO - 2018-03-22 20:03:21 --> Helper loaded: settings_helper
INFO - 2018-03-22 20:03:21 --> Helper loaded: permission_helper
INFO - 2018-03-22 20:03:21 --> Helper loaded: users_helper
INFO - 2018-03-22 20:03:21 --> Database Driver Class Initialized
DEBUG - 2018-03-22 20:03:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 20:03:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 20:03:21 --> Helper loaded: form_helper
INFO - 2018-03-22 20:03:21 --> Form Validation Class Initialized
INFO - 2018-03-22 20:03:21 --> Controller Class Initialized
INFO - 2018-03-22 20:03:21 --> Model Class Initialized
INFO - 2018-03-22 20:03:21 --> Helper loaded: inflector_helper
DEBUG - 2018-03-22 20:03:21 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-22 20:03:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-22 20:03:21 --> Model Class Initialized
INFO - 2018-03-22 20:03:21 --> Model Class Initialized
INFO - 2018-03-22 20:03:21 --> Model Class Initialized
INFO - 2018-03-22 20:03:21 --> Model Class Initialized
INFO - 2018-03-22 20:03:21 --> Model Class Initialized
INFO - 2018-03-22 20:03:21 --> Model Class Initialized
INFO - 2018-03-22 20:03:21 --> Model Class Initialized
INFO - 2018-03-22 20:03:21 --> Model Class Initialized
INFO - 2018-03-22 20:03:21 --> Model Class Initialized
INFO - 2018-03-22 20:03:21 --> Model Class Initialized
INFO - 2018-03-22 20:03:21 --> Model Class Initialized
INFO - 2018-03-22 20:03:21 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-22 20:03:21 --> Model Class Initialized
INFO - 2018-03-22 20:03:21 --> Final output sent to browser
DEBUG - 2018-03-22 20:03:21 --> Total execution time: 0.2246
INFO - 2018-03-22 14:35:11 --> Config Class Initialized
INFO - 2018-03-22 14:35:11 --> Hooks Class Initialized
DEBUG - 2018-03-22 14:35:11 --> UTF-8 Support Enabled
INFO - 2018-03-22 14:35:11 --> Utf8 Class Initialized
INFO - 2018-03-22 14:35:11 --> URI Class Initialized
INFO - 2018-03-22 14:35:11 --> Router Class Initialized
INFO - 2018-03-22 14:35:11 --> Output Class Initialized
INFO - 2018-03-22 14:35:11 --> Security Class Initialized
DEBUG - 2018-03-22 14:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 14:35:11 --> Input Class Initialized
INFO - 2018-03-22 14:35:11 --> Language Class Initialized
INFO - 2018-03-22 14:35:11 --> Language Class Initialized
INFO - 2018-03-22 14:35:11 --> Config Class Initialized
INFO - 2018-03-22 14:35:11 --> Loader Class Initialized
INFO - 2018-03-22 20:05:11 --> Helper loaded: url_helper
INFO - 2018-03-22 20:05:11 --> Helper loaded: notification_helper
INFO - 2018-03-22 20:05:11 --> Helper loaded: settings_helper
INFO - 2018-03-22 20:05:11 --> Helper loaded: permission_helper
INFO - 2018-03-22 20:05:11 --> Helper loaded: users_helper
INFO - 2018-03-22 20:05:11 --> Database Driver Class Initialized
DEBUG - 2018-03-22 20:05:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 20:05:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 20:05:11 --> Helper loaded: form_helper
INFO - 2018-03-22 20:05:11 --> Form Validation Class Initialized
INFO - 2018-03-22 20:05:11 --> Controller Class Initialized
INFO - 2018-03-22 20:05:11 --> Model Class Initialized
INFO - 2018-03-22 20:05:11 --> Helper loaded: inflector_helper
DEBUG - 2018-03-22 20:05:11 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-22 20:05:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-22 20:05:11 --> Model Class Initialized
INFO - 2018-03-22 20:05:11 --> Model Class Initialized
INFO - 2018-03-22 20:05:11 --> Model Class Initialized
INFO - 2018-03-22 20:05:11 --> Model Class Initialized
INFO - 2018-03-22 20:05:11 --> Model Class Initialized
INFO - 2018-03-22 20:05:11 --> Model Class Initialized
ERROR - 2018-03-22 20:05:11 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/FilterOption.php 79
INFO - 2018-03-22 20:05:11 --> Final output sent to browser
DEBUG - 2018-03-22 20:05:11 --> Total execution time: 0.1601
INFO - 2018-03-22 14:35:12 --> Config Class Initialized
INFO - 2018-03-22 14:35:12 --> Hooks Class Initialized
DEBUG - 2018-03-22 14:35:12 --> UTF-8 Support Enabled
INFO - 2018-03-22 14:35:12 --> Utf8 Class Initialized
INFO - 2018-03-22 14:35:12 --> URI Class Initialized
INFO - 2018-03-22 14:35:12 --> Router Class Initialized
INFO - 2018-03-22 14:35:12 --> Output Class Initialized
INFO - 2018-03-22 14:35:12 --> Security Class Initialized
DEBUG - 2018-03-22 14:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 14:35:12 --> Input Class Initialized
INFO - 2018-03-22 14:35:12 --> Language Class Initialized
INFO - 2018-03-22 14:35:12 --> Language Class Initialized
INFO - 2018-03-22 14:35:12 --> Config Class Initialized
INFO - 2018-03-22 14:35:12 --> Loader Class Initialized
INFO - 2018-03-22 20:05:12 --> Helper loaded: url_helper
INFO - 2018-03-22 20:05:12 --> Helper loaded: notification_helper
INFO - 2018-03-22 20:05:12 --> Helper loaded: settings_helper
INFO - 2018-03-22 20:05:12 --> Helper loaded: permission_helper
INFO - 2018-03-22 20:05:12 --> Helper loaded: users_helper
INFO - 2018-03-22 20:05:12 --> Database Driver Class Initialized
DEBUG - 2018-03-22 20:05:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 20:05:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 20:05:12 --> Helper loaded: form_helper
INFO - 2018-03-22 20:05:12 --> Form Validation Class Initialized
INFO - 2018-03-22 20:05:12 --> Controller Class Initialized
INFO - 2018-03-22 20:05:12 --> Model Class Initialized
INFO - 2018-03-22 20:05:12 --> Helper loaded: inflector_helper
DEBUG - 2018-03-22 20:05:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-22 20:05:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-22 20:05:12 --> Model Class Initialized
INFO - 2018-03-22 20:05:12 --> Model Class Initialized
INFO - 2018-03-22 20:05:12 --> Model Class Initialized
INFO - 2018-03-22 20:05:12 --> Model Class Initialized
INFO - 2018-03-22 20:05:12 --> Model Class Initialized
INFO - 2018-03-22 20:05:12 --> Model Class Initialized
ERROR - 2018-03-22 20:05:12 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/FilterOption.php 349
ERROR - 2018-03-22 20:05:12 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/FilterOption.php 389
ERROR - 2018-03-22 20:05:12 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/FilterOption.php 427
INFO - 2018-03-22 20:05:12 --> Final output sent to browser
DEBUG - 2018-03-22 20:05:12 --> Total execution time: 0.1030
INFO - 2018-03-22 14:35:12 --> Config Class Initialized
INFO - 2018-03-22 14:35:12 --> Hooks Class Initialized
DEBUG - 2018-03-22 14:35:12 --> UTF-8 Support Enabled
INFO - 2018-03-22 14:35:12 --> Utf8 Class Initialized
INFO - 2018-03-22 14:35:12 --> URI Class Initialized
INFO - 2018-03-22 14:35:12 --> Router Class Initialized
INFO - 2018-03-22 14:35:12 --> Output Class Initialized
INFO - 2018-03-22 14:35:12 --> Security Class Initialized
DEBUG - 2018-03-22 14:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 14:35:12 --> Input Class Initialized
INFO - 2018-03-22 14:35:12 --> Language Class Initialized
INFO - 2018-03-22 14:35:13 --> Config Class Initialized
INFO - 2018-03-22 14:35:13 --> Hooks Class Initialized
INFO - 2018-03-22 14:35:13 --> Language Class Initialized
INFO - 2018-03-22 14:35:13 --> Config Class Initialized
INFO - 2018-03-22 14:35:13 --> Loader Class Initialized
DEBUG - 2018-03-22 14:35:13 --> UTF-8 Support Enabled
INFO - 2018-03-22 14:35:13 --> Utf8 Class Initialized
INFO - 2018-03-22 20:05:13 --> Helper loaded: url_helper
INFO - 2018-03-22 20:05:13 --> Helper loaded: notification_helper
INFO - 2018-03-22 20:05:13 --> Helper loaded: settings_helper
INFO - 2018-03-22 14:35:13 --> URI Class Initialized
INFO - 2018-03-22 20:05:13 --> Helper loaded: permission_helper
INFO - 2018-03-22 20:05:13 --> Helper loaded: users_helper
INFO - 2018-03-22 14:35:13 --> Router Class Initialized
INFO - 2018-03-22 14:35:13 --> Config Class Initialized
INFO - 2018-03-22 14:35:13 --> Hooks Class Initialized
INFO - 2018-03-22 14:35:14 --> Output Class Initialized
DEBUG - 2018-03-22 14:35:14 --> UTF-8 Support Enabled
INFO - 2018-03-22 14:35:14 --> Utf8 Class Initialized
INFO - 2018-03-22 14:35:14 --> Security Class Initialized
DEBUG - 2018-03-22 14:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 14:35:14 --> Input Class Initialized
INFO - 2018-03-22 14:35:14 --> URI Class Initialized
INFO - 2018-03-22 14:35:14 --> Language Class Initialized
INFO - 2018-03-22 14:35:14 --> Router Class Initialized
INFO - 2018-03-22 14:35:14 --> Output Class Initialized
INFO - 2018-03-22 14:35:14 --> Security Class Initialized
DEBUG - 2018-03-22 14:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 14:35:14 --> Input Class Initialized
INFO - 2018-03-22 14:35:14 --> Language Class Initialized
INFO - 2018-03-22 14:35:14 --> Language Class Initialized
INFO - 2018-03-22 14:35:14 --> Config Class Initialized
INFO - 2018-03-22 14:35:14 --> Loader Class Initialized
INFO - 2018-03-22 20:05:14 --> Helper loaded: url_helper
INFO - 2018-03-22 20:05:14 --> Helper loaded: notification_helper
INFO - 2018-03-22 20:05:14 --> Helper loaded: settings_helper
INFO - 2018-03-22 20:05:14 --> Helper loaded: permission_helper
INFO - 2018-03-22 20:05:14 --> Helper loaded: users_helper
INFO - 2018-03-22 20:05:14 --> Database Driver Class Initialized
DEBUG - 2018-03-22 20:05:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 20:05:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 20:05:14 --> Helper loaded: form_helper
INFO - 2018-03-22 20:05:14 --> Form Validation Class Initialized
INFO - 2018-03-22 20:05:14 --> Controller Class Initialized
INFO - 2018-03-22 20:05:14 --> Model Class Initialized
INFO - 2018-03-22 20:05:14 --> Helper loaded: inflector_helper
DEBUG - 2018-03-22 20:05:14 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-22 20:05:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-22 20:05:14 --> Model Class Initialized
INFO - 2018-03-22 20:05:14 --> Model Class Initialized
INFO - 2018-03-22 20:05:14 --> Model Class Initialized
INFO - 2018-03-22 20:05:14 --> Model Class Initialized
INFO - 2018-03-22 20:05:14 --> Model Class Initialized
INFO - 2018-03-22 20:05:14 --> Model Class Initialized
ERROR - 2018-03-22 20:05:14 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/FilterOption.php 625
ERROR - 2018-03-22 20:05:14 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/FilterOption.php 625
INFO - 2018-03-22 20:05:14 --> Final output sent to browser
DEBUG - 2018-03-22 20:05:14 --> Total execution time: 1.2597
INFO - 2018-03-22 14:35:14 --> Language Class Initialized
INFO - 2018-03-22 14:35:14 --> Config Class Initialized
INFO - 2018-03-22 14:35:14 --> Loader Class Initialized
INFO - 2018-03-22 20:05:14 --> Database Driver Class Initialized
DEBUG - 2018-03-22 20:05:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 20:05:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 20:05:14 --> Helper loaded: url_helper
INFO - 2018-03-22 20:05:14 --> Helper loaded: form_helper
INFO - 2018-03-22 20:05:14 --> Form Validation Class Initialized
INFO - 2018-03-22 20:05:14 --> Controller Class Initialized
INFO - 2018-03-22 20:05:14 --> Model Class Initialized
INFO - 2018-03-22 20:05:14 --> Helper loaded: inflector_helper
INFO - 2018-03-22 20:05:14 --> Helper loaded: notification_helper
DEBUG - 2018-03-22 20:05:14 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-22 20:05:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-22 20:05:14 --> Model Class Initialized
INFO - 2018-03-22 20:05:14 --> Model Class Initialized
INFO - 2018-03-22 20:05:14 --> Model Class Initialized
INFO - 2018-03-22 20:05:14 --> Helper loaded: settings_helper
INFO - 2018-03-22 20:05:14 --> Model Class Initialized
INFO - 2018-03-22 20:05:14 --> Model Class Initialized
INFO - 2018-03-22 20:05:14 --> Model Class Initialized
ERROR - 2018-03-22 20:05:14 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/FilterOption.php 289
INFO - 2018-03-22 20:05:14 --> Final output sent to browser
DEBUG - 2018-03-22 20:05:14 --> Total execution time: 2.0234
INFO - 2018-03-22 20:05:14 --> Helper loaded: permission_helper
INFO - 2018-03-22 20:05:14 --> Helper loaded: users_helper
INFO - 2018-03-22 20:05:15 --> Database Driver Class Initialized
DEBUG - 2018-03-22 20:05:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 20:05:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 20:05:15 --> Helper loaded: form_helper
INFO - 2018-03-22 20:05:15 --> Form Validation Class Initialized
INFO - 2018-03-22 20:05:15 --> Controller Class Initialized
INFO - 2018-03-22 20:05:15 --> Model Class Initialized
INFO - 2018-03-22 20:05:15 --> Helper loaded: inflector_helper
DEBUG - 2018-03-22 20:05:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-22 20:05:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-22 20:05:15 --> Model Class Initialized
INFO - 2018-03-22 20:05:15 --> Model Class Initialized
INFO - 2018-03-22 20:05:15 --> Model Class Initialized
INFO - 2018-03-22 20:05:15 --> Model Class Initialized
INFO - 2018-03-22 20:05:15 --> Model Class Initialized
INFO - 2018-03-22 20:05:15 --> Model Class Initialized
ERROR - 2018-03-22 20:05:15 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/FilterOption.php 147
ERROR - 2018-03-22 20:05:15 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/FilterOption.php 189
ERROR - 2018-03-22 20:05:15 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/FilterOption.php 227
INFO - 2018-03-22 20:05:15 --> Final output sent to browser
DEBUG - 2018-03-22 20:05:15 --> Total execution time: 1.5224
INFO - 2018-03-22 14:38:17 --> Config Class Initialized
INFO - 2018-03-22 14:38:17 --> Hooks Class Initialized
DEBUG - 2018-03-22 14:38:17 --> UTF-8 Support Enabled
INFO - 2018-03-22 14:38:17 --> Utf8 Class Initialized
INFO - 2018-03-22 14:38:17 --> URI Class Initialized
INFO - 2018-03-22 14:38:17 --> Router Class Initialized
INFO - 2018-03-22 14:38:17 --> Output Class Initialized
INFO - 2018-03-22 14:38:17 --> Security Class Initialized
DEBUG - 2018-03-22 14:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 14:38:17 --> Input Class Initialized
INFO - 2018-03-22 14:38:17 --> Language Class Initialized
INFO - 2018-03-22 14:38:17 --> Language Class Initialized
INFO - 2018-03-22 14:38:17 --> Config Class Initialized
INFO - 2018-03-22 14:38:17 --> Loader Class Initialized
INFO - 2018-03-22 20:08:17 --> Helper loaded: url_helper
INFO - 2018-03-22 20:08:17 --> Helper loaded: notification_helper
INFO - 2018-03-22 20:08:17 --> Helper loaded: settings_helper
INFO - 2018-03-22 20:08:17 --> Helper loaded: permission_helper
INFO - 2018-03-22 20:08:17 --> Helper loaded: users_helper
INFO - 2018-03-22 20:08:17 --> Database Driver Class Initialized
DEBUG - 2018-03-22 20:08:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 20:08:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 20:08:17 --> Helper loaded: form_helper
INFO - 2018-03-22 20:08:17 --> Form Validation Class Initialized
INFO - 2018-03-22 20:08:17 --> Controller Class Initialized
INFO - 2018-03-22 20:08:17 --> Model Class Initialized
INFO - 2018-03-22 20:08:17 --> Helper loaded: inflector_helper
DEBUG - 2018-03-22 20:08:17 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-22 20:08:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-22 20:08:17 --> Model Class Initialized
INFO - 2018-03-22 20:08:17 --> Model Class Initialized
INFO - 2018-03-22 20:08:17 --> Model Class Initialized
INFO - 2018-03-22 20:08:17 --> Model Class Initialized
INFO - 2018-03-22 20:08:17 --> Model Class Initialized
INFO - 2018-03-22 20:08:17 --> Model Class Initialized
INFO - 2018-03-22 20:08:17 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-22 20:08:17 --> Final output sent to browser
DEBUG - 2018-03-22 20:08:17 --> Total execution time: 0.1213
INFO - 2018-03-22 14:38:18 --> Config Class Initialized
INFO - 2018-03-22 14:38:18 --> Hooks Class Initialized
DEBUG - 2018-03-22 14:38:18 --> UTF-8 Support Enabled
INFO - 2018-03-22 14:38:18 --> Utf8 Class Initialized
INFO - 2018-03-22 14:38:18 --> URI Class Initialized
INFO - 2018-03-22 14:38:18 --> Router Class Initialized
INFO - 2018-03-22 14:38:18 --> Output Class Initialized
INFO - 2018-03-22 14:38:18 --> Security Class Initialized
DEBUG - 2018-03-22 14:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-22 14:38:18 --> Input Class Initialized
INFO - 2018-03-22 14:38:18 --> Language Class Initialized
INFO - 2018-03-22 14:38:19 --> Language Class Initialized
INFO - 2018-03-22 14:38:19 --> Config Class Initialized
INFO - 2018-03-22 14:38:19 --> Loader Class Initialized
INFO - 2018-03-22 20:08:19 --> Helper loaded: url_helper
INFO - 2018-03-22 20:08:19 --> Helper loaded: notification_helper
INFO - 2018-03-22 20:08:19 --> Helper loaded: settings_helper
INFO - 2018-03-22 20:08:19 --> Helper loaded: permission_helper
INFO - 2018-03-22 20:08:20 --> Helper loaded: users_helper
INFO - 2018-03-22 20:08:20 --> Database Driver Class Initialized
DEBUG - 2018-03-22 20:08:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-22 20:08:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-22 20:08:21 --> Helper loaded: form_helper
INFO - 2018-03-22 20:08:21 --> Form Validation Class Initialized
INFO - 2018-03-22 20:08:21 --> Controller Class Initialized
INFO - 2018-03-22 20:08:21 --> Model Class Initialized
INFO - 2018-03-22 20:08:21 --> Helper loaded: inflector_helper
DEBUG - 2018-03-22 20:08:21 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-22 20:08:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-22 20:08:21 --> Model Class Initialized
INFO - 2018-03-22 20:08:21 --> Model Class Initialized
INFO - 2018-03-22 20:08:21 --> Model Class Initialized
INFO - 2018-03-22 20:08:21 --> Model Class Initialized
INFO - 2018-03-22 20:08:21 --> Model Class Initialized
INFO - 2018-03-22 20:08:21 --> Model Class Initialized
INFO - 2018-03-22 20:08:21 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-22 20:08:21 --> Final output sent to browser
DEBUG - 2018-03-22 20:08:21 --> Total execution time: 3.7510
