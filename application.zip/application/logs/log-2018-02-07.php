<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-02-07 04:50:04 --> Config Class Initialized
INFO - 2018-02-07 04:50:04 --> Hooks Class Initialized
DEBUG - 2018-02-07 04:50:04 --> UTF-8 Support Enabled
INFO - 2018-02-07 04:50:04 --> Utf8 Class Initialized
INFO - 2018-02-07 04:50:04 --> URI Class Initialized
INFO - 2018-02-07 04:50:04 --> Router Class Initialized
INFO - 2018-02-07 04:50:04 --> Output Class Initialized
INFO - 2018-02-07 04:50:04 --> Security Class Initialized
DEBUG - 2018-02-07 04:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 04:50:04 --> Input Class Initialized
INFO - 2018-02-07 04:50:04 --> Language Class Initialized
INFO - 2018-02-07 04:50:04 --> Language Class Initialized
INFO - 2018-02-07 04:50:04 --> Config Class Initialized
INFO - 2018-02-07 04:50:04 --> Loader Class Initialized
INFO - 2018-02-07 10:20:04 --> Helper loaded: url_helper
INFO - 2018-02-07 10:20:04 --> Helper loaded: notification_helper
INFO - 2018-02-07 10:20:04 --> Helper loaded: settings_helper
INFO - 2018-02-07 10:20:04 --> Helper loaded: permission_helper
INFO - 2018-02-07 10:20:04 --> Helper loaded: users_helper
INFO - 2018-02-07 10:20:04 --> Database Driver Class Initialized
DEBUG - 2018-02-07 10:20:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:20:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 10:20:04 --> Helper loaded: form_helper
INFO - 2018-02-07 10:20:04 --> Form Validation Class Initialized
INFO - 2018-02-07 10:20:04 --> Controller Class Initialized
INFO - 2018-02-07 10:20:04 --> Model Class Initialized
INFO - 2018-02-07 10:20:04 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 10:20:04 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 10:20:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 10:20:04 --> Model Class Initialized
INFO - 2018-02-07 10:20:04 --> Model Class Initialized
INFO - 2018-02-07 10:20:04 --> Model Class Initialized
INFO - 2018-02-07 10:20:04 --> Model Class Initialized
INFO - 2018-02-07 10:20:04 --> Model Class Initialized
INFO - 2018-02-07 10:20:04 --> Model Class Initialized
INFO - 2018-02-07 10:20:04 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 10:20:04 --> Final output sent to browser
DEBUG - 2018-02-07 10:20:04 --> Total execution time: 0.1211
INFO - 2018-02-07 04:50:05 --> Config Class Initialized
INFO - 2018-02-07 04:50:05 --> Hooks Class Initialized
DEBUG - 2018-02-07 04:50:05 --> UTF-8 Support Enabled
INFO - 2018-02-07 04:50:05 --> Utf8 Class Initialized
INFO - 2018-02-07 04:50:05 --> URI Class Initialized
INFO - 2018-02-07 04:50:05 --> Router Class Initialized
INFO - 2018-02-07 04:50:05 --> Output Class Initialized
INFO - 2018-02-07 04:50:05 --> Security Class Initialized
DEBUG - 2018-02-07 04:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 04:50:05 --> Input Class Initialized
INFO - 2018-02-07 04:50:05 --> Language Class Initialized
INFO - 2018-02-07 04:50:05 --> Language Class Initialized
INFO - 2018-02-07 04:50:05 --> Config Class Initialized
INFO - 2018-02-07 04:50:05 --> Loader Class Initialized
INFO - 2018-02-07 10:20:05 --> Helper loaded: url_helper
INFO - 2018-02-07 10:20:05 --> Helper loaded: notification_helper
INFO - 2018-02-07 10:20:05 --> Helper loaded: settings_helper
INFO - 2018-02-07 10:20:05 --> Helper loaded: permission_helper
INFO - 2018-02-07 10:20:05 --> Helper loaded: users_helper
INFO - 2018-02-07 10:20:05 --> Database Driver Class Initialized
DEBUG - 2018-02-07 10:20:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:20:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 10:20:05 --> Helper loaded: form_helper
INFO - 2018-02-07 10:20:05 --> Form Validation Class Initialized
INFO - 2018-02-07 10:20:05 --> Controller Class Initialized
INFO - 2018-02-07 10:20:05 --> Model Class Initialized
INFO - 2018-02-07 10:20:05 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 10:20:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 10:20:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 10:20:05 --> Model Class Initialized
INFO - 2018-02-07 10:20:05 --> Model Class Initialized
INFO - 2018-02-07 10:20:05 --> Model Class Initialized
INFO - 2018-02-07 10:20:05 --> Model Class Initialized
INFO - 2018-02-07 10:20:05 --> Model Class Initialized
INFO - 2018-02-07 10:20:05 --> Model Class Initialized
INFO - 2018-02-07 10:20:05 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 10:20:05 --> Final output sent to browser
DEBUG - 2018-02-07 10:20:05 --> Total execution time: 0.1218
INFO - 2018-02-07 04:50:05 --> Config Class Initialized
INFO - 2018-02-07 04:50:05 --> Hooks Class Initialized
DEBUG - 2018-02-07 04:50:05 --> UTF-8 Support Enabled
INFO - 2018-02-07 04:50:05 --> Utf8 Class Initialized
INFO - 2018-02-07 04:50:05 --> URI Class Initialized
INFO - 2018-02-07 04:50:05 --> Router Class Initialized
INFO - 2018-02-07 04:50:05 --> Output Class Initialized
INFO - 2018-02-07 04:50:05 --> Security Class Initialized
DEBUG - 2018-02-07 04:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 04:50:05 --> Input Class Initialized
INFO - 2018-02-07 04:50:05 --> Language Class Initialized
INFO - 2018-02-07 04:50:05 --> Language Class Initialized
INFO - 2018-02-07 04:50:05 --> Config Class Initialized
INFO - 2018-02-07 04:50:05 --> Loader Class Initialized
INFO - 2018-02-07 10:20:05 --> Helper loaded: url_helper
INFO - 2018-02-07 10:20:05 --> Helper loaded: notification_helper
INFO - 2018-02-07 10:20:05 --> Helper loaded: settings_helper
INFO - 2018-02-07 04:50:05 --> Config Class Initialized
INFO - 2018-02-07 04:50:05 --> Hooks Class Initialized
INFO - 2018-02-07 10:20:05 --> Helper loaded: permission_helper
INFO - 2018-02-07 10:20:05 --> Helper loaded: users_helper
DEBUG - 2018-02-07 04:50:05 --> UTF-8 Support Enabled
INFO - 2018-02-07 04:50:05 --> Utf8 Class Initialized
INFO - 2018-02-07 04:50:05 --> URI Class Initialized
INFO - 2018-02-07 04:50:05 --> Router Class Initialized
INFO - 2018-02-07 04:50:05 --> Output Class Initialized
INFO - 2018-02-07 10:20:05 --> Database Driver Class Initialized
INFO - 2018-02-07 04:50:05 --> Security Class Initialized
DEBUG - 2018-02-07 04:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 04:50:05 --> Input Class Initialized
INFO - 2018-02-07 04:50:05 --> Config Class Initialized
INFO - 2018-02-07 04:50:05 --> Hooks Class Initialized
INFO - 2018-02-07 04:50:05 --> Language Class Initialized
DEBUG - 2018-02-07 10:20:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:20:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-07 04:50:05 --> UTF-8 Support Enabled
INFO - 2018-02-07 04:50:05 --> Utf8 Class Initialized
INFO - 2018-02-07 04:50:05 --> URI Class Initialized
INFO - 2018-02-07 04:50:05 --> Router Class Initialized
INFO - 2018-02-07 10:20:05 --> Helper loaded: form_helper
INFO - 2018-02-07 10:20:05 --> Form Validation Class Initialized
INFO - 2018-02-07 10:20:05 --> Controller Class Initialized
INFO - 2018-02-07 04:50:05 --> Output Class Initialized
INFO - 2018-02-07 04:50:05 --> Security Class Initialized
DEBUG - 2018-02-07 04:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 04:50:05 --> Input Class Initialized
INFO - 2018-02-07 04:50:05 --> Language Class Initialized
INFO - 2018-02-07 04:50:05 --> Config Class Initialized
INFO - 2018-02-07 04:50:05 --> Loader Class Initialized
INFO - 2018-02-07 04:50:05 --> Language Class Initialized
INFO - 2018-02-07 10:20:05 --> Model Class Initialized
INFO - 2018-02-07 10:20:05 --> Helper loaded: url_helper
INFO - 2018-02-07 10:20:05 --> Helper loaded: inflector_helper
INFO - 2018-02-07 10:20:05 --> Helper loaded: notification_helper
INFO - 2018-02-07 10:20:05 --> Helper loaded: settings_helper
INFO - 2018-02-07 10:20:05 --> Helper loaded: permission_helper
INFO - 2018-02-07 10:20:05 --> Helper loaded: users_helper
DEBUG - 2018-02-07 10:20:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 10:20:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 10:20:05 --> Model Class Initialized
INFO - 2018-02-07 10:20:05 --> Model Class Initialized
INFO - 2018-02-07 10:20:05 --> Model Class Initialized
INFO - 2018-02-07 10:20:05 --> Model Class Initialized
INFO - 2018-02-07 10:20:05 --> Model Class Initialized
INFO - 2018-02-07 10:20:05 --> Model Class Initialized
INFO - 2018-02-07 10:20:05 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 10:20:05 --> Model Class Initialized
INFO - 2018-02-07 10:20:05 --> Final output sent to browser
DEBUG - 2018-02-07 10:20:05 --> Total execution time: 0.1164
INFO - 2018-02-07 04:50:05 --> Config Class Initialized
INFO - 2018-02-07 04:50:05 --> Hooks Class Initialized
INFO - 2018-02-07 10:20:05 --> Database Driver Class Initialized
INFO - 2018-02-07 04:50:05 --> Language Class Initialized
INFO - 2018-02-07 04:50:05 --> Config Class Initialized
INFO - 2018-02-07 04:50:05 --> Loader Class Initialized
DEBUG - 2018-02-07 04:50:05 --> UTF-8 Support Enabled
INFO - 2018-02-07 04:50:05 --> Utf8 Class Initialized
INFO - 2018-02-07 10:20:05 --> Helper loaded: url_helper
INFO - 2018-02-07 10:20:05 --> Helper loaded: notification_helper
INFO - 2018-02-07 04:50:05 --> URI Class Initialized
INFO - 2018-02-07 10:20:05 --> Helper loaded: settings_helper
INFO - 2018-02-07 10:20:05 --> Helper loaded: permission_helper
DEBUG - 2018-02-07 10:20:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:20:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 10:20:05 --> Helper loaded: users_helper
INFO - 2018-02-07 04:50:05 --> Router Class Initialized
INFO - 2018-02-07 04:50:05 --> Output Class Initialized
INFO - 2018-02-07 04:50:05 --> Security Class Initialized
INFO - 2018-02-07 10:20:05 --> Helper loaded: form_helper
INFO - 2018-02-07 10:20:05 --> Form Validation Class Initialized
INFO - 2018-02-07 10:20:05 --> Controller Class Initialized
DEBUG - 2018-02-07 04:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 04:50:05 --> Input Class Initialized
INFO - 2018-02-07 04:50:05 --> Language Class Initialized
INFO - 2018-02-07 10:20:05 --> Database Driver Class Initialized
INFO - 2018-02-07 10:20:05 --> Model Class Initialized
INFO - 2018-02-07 10:20:05 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 10:20:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:20:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-07 10:20:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 10:20:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 10:20:05 --> Model Class Initialized
INFO - 2018-02-07 10:20:05 --> Model Class Initialized
INFO - 2018-02-07 10:20:05 --> Model Class Initialized
INFO - 2018-02-07 10:20:05 --> Model Class Initialized
INFO - 2018-02-07 10:20:05 --> Model Class Initialized
INFO - 2018-02-07 04:50:06 --> Language Class Initialized
INFO - 2018-02-07 04:50:06 --> Config Class Initialized
INFO - 2018-02-07 04:50:06 --> Loader Class Initialized
INFO - 2018-02-07 10:20:06 --> Model Class Initialized
INFO - 2018-02-07 10:20:06 --> Model Class Initialized
INFO - 2018-02-07 10:20:06 --> Helper loaded: form_helper
INFO - 2018-02-07 10:20:06 --> Form Validation Class Initialized
INFO - 2018-02-07 10:20:06 --> Controller Class Initialized
INFO - 2018-02-07 10:20:06 --> Model Class Initialized
INFO - 2018-02-07 10:20:06 --> Model Class Initialized
INFO - 2018-02-07 10:20:06 --> Model Class Initialized
INFO - 2018-02-07 10:20:06 --> Helper loaded: url_helper
INFO - 2018-02-07 10:20:06 --> Helper loaded: notification_helper
INFO - 2018-02-07 10:20:06 --> Helper loaded: settings_helper
INFO - 2018-02-07 10:20:06 --> Model Class Initialized
INFO - 2018-02-07 10:20:06 --> Helper loaded: permission_helper
INFO - 2018-02-07 10:20:06 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 10:20:06 --> Model Class Initialized
INFO - 2018-02-07 10:20:06 --> Helper loaded: users_helper
INFO - 2018-02-07 10:20:06 --> Model Class Initialized
INFO - 2018-02-07 10:20:06 --> Helper loaded: inflector_helper
INFO - 2018-02-07 10:20:06 --> Final output sent to browser
DEBUG - 2018-02-07 10:20:06 --> Total execution time: 0.1261
DEBUG - 2018-02-07 10:20:06 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 10:20:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 10:20:06 --> Model Class Initialized
INFO - 2018-02-07 10:20:06 --> Model Class Initialized
INFO - 2018-02-07 10:20:06 --> Model Class Initialized
INFO - 2018-02-07 10:20:06 --> Model Class Initialized
INFO - 2018-02-07 10:20:06 --> Database Driver Class Initialized
INFO - 2018-02-07 10:20:06 --> Model Class Initialized
INFO - 2018-02-07 10:20:06 --> Model Class Initialized
INFO - 2018-02-07 10:20:06 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 10:20:06 --> Model Class Initialized
INFO - 2018-02-07 10:20:06 --> Final output sent to browser
DEBUG - 2018-02-07 10:20:06 --> Total execution time: 0.1163
DEBUG - 2018-02-07 10:20:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 10:20:06 --> Helper loaded: form_helper
INFO - 2018-02-07 10:20:06 --> Form Validation Class Initialized
INFO - 2018-02-07 10:20:06 --> Controller Class Initialized
INFO - 2018-02-07 10:20:06 --> Model Class Initialized
INFO - 2018-02-07 10:20:06 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 10:20:06 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 10:20:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 10:20:06 --> Model Class Initialized
INFO - 2018-02-07 10:20:06 --> Model Class Initialized
INFO - 2018-02-07 10:20:06 --> Model Class Initialized
INFO - 2018-02-07 10:20:06 --> Model Class Initialized
INFO - 2018-02-07 10:20:06 --> Model Class Initialized
INFO - 2018-02-07 10:20:06 --> Model Class Initialized
INFO - 2018-02-07 10:20:06 --> Model Class Initialized
INFO - 2018-02-07 10:20:06 --> Model Class Initialized
INFO - 2018-02-07 10:20:06 --> Model Class Initialized
INFO - 2018-02-07 10:20:06 --> Model Class Initialized
INFO - 2018-02-07 10:20:06 --> Model Class Initialized
INFO - 2018-02-07 10:20:06 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 10:20:06 --> Model Class Initialized
INFO - 2018-02-07 10:20:06 --> Final output sent to browser
DEBUG - 2018-02-07 10:20:06 --> Total execution time: 0.1185
INFO - 2018-02-07 04:50:07 --> Config Class Initialized
INFO - 2018-02-07 04:50:07 --> Hooks Class Initialized
DEBUG - 2018-02-07 04:50:07 --> UTF-8 Support Enabled
INFO - 2018-02-07 04:50:07 --> Utf8 Class Initialized
INFO - 2018-02-07 04:50:07 --> URI Class Initialized
INFO - 2018-02-07 04:50:07 --> Router Class Initialized
INFO - 2018-02-07 04:50:07 --> Output Class Initialized
INFO - 2018-02-07 04:50:07 --> Security Class Initialized
DEBUG - 2018-02-07 04:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 04:50:07 --> Input Class Initialized
INFO - 2018-02-07 04:50:07 --> Language Class Initialized
INFO - 2018-02-07 04:50:07 --> Config Class Initialized
INFO - 2018-02-07 04:50:07 --> Hooks Class Initialized
INFO - 2018-02-07 04:50:07 --> Config Class Initialized
INFO - 2018-02-07 04:50:07 --> Hooks Class Initialized
DEBUG - 2018-02-07 04:50:07 --> UTF-8 Support Enabled
INFO - 2018-02-07 04:50:07 --> Utf8 Class Initialized
INFO - 2018-02-07 04:50:07 --> URI Class Initialized
DEBUG - 2018-02-07 04:50:07 --> UTF-8 Support Enabled
INFO - 2018-02-07 04:50:07 --> Utf8 Class Initialized
INFO - 2018-02-07 04:50:07 --> URI Class Initialized
INFO - 2018-02-07 04:50:07 --> Router Class Initialized
INFO - 2018-02-07 04:50:07 --> Router Class Initialized
INFO - 2018-02-07 04:50:07 --> Output Class Initialized
INFO - 2018-02-07 04:50:07 --> Security Class Initialized
INFO - 2018-02-07 04:50:07 --> Output Class Initialized
DEBUG - 2018-02-07 04:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 04:50:07 --> Input Class Initialized
INFO - 2018-02-07 04:50:07 --> Security Class Initialized
INFO - 2018-02-07 04:50:07 --> Language Class Initialized
INFO - 2018-02-07 04:50:07 --> Language Class Initialized
INFO - 2018-02-07 04:50:07 --> Config Class Initialized
INFO - 2018-02-07 04:50:07 --> Loader Class Initialized
DEBUG - 2018-02-07 04:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 04:50:07 --> Input Class Initialized
INFO - 2018-02-07 10:20:07 --> Helper loaded: url_helper
INFO - 2018-02-07 04:50:07 --> Language Class Initialized
INFO - 2018-02-07 10:20:07 --> Helper loaded: notification_helper
INFO - 2018-02-07 10:20:07 --> Helper loaded: settings_helper
INFO - 2018-02-07 10:20:07 --> Helper loaded: permission_helper
INFO - 2018-02-07 10:20:07 --> Helper loaded: users_helper
INFO - 2018-02-07 04:50:07 --> Language Class Initialized
INFO - 2018-02-07 04:50:07 --> Config Class Initialized
INFO - 2018-02-07 04:50:07 --> Loader Class Initialized
INFO - 2018-02-07 04:50:07 --> Language Class Initialized
INFO - 2018-02-07 04:50:07 --> Config Class Initialized
INFO - 2018-02-07 04:50:07 --> Loader Class Initialized
INFO - 2018-02-07 10:20:07 --> Database Driver Class Initialized
INFO - 2018-02-07 10:20:07 --> Helper loaded: url_helper
INFO - 2018-02-07 10:20:07 --> Helper loaded: url_helper
INFO - 2018-02-07 10:20:07 --> Helper loaded: notification_helper
INFO - 2018-02-07 10:20:07 --> Helper loaded: settings_helper
INFO - 2018-02-07 10:20:07 --> Helper loaded: notification_helper
INFO - 2018-02-07 10:20:07 --> Helper loaded: settings_helper
INFO - 2018-02-07 10:20:07 --> Helper loaded: permission_helper
INFO - 2018-02-07 10:20:07 --> Helper loaded: permission_helper
INFO - 2018-02-07 10:20:07 --> Helper loaded: users_helper
INFO - 2018-02-07 10:20:07 --> Helper loaded: users_helper
DEBUG - 2018-02-07 10:20:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 10:20:07 --> Helper loaded: form_helper
INFO - 2018-02-07 10:20:07 --> Form Validation Class Initialized
INFO - 2018-02-07 10:20:07 --> Controller Class Initialized
INFO - 2018-02-07 10:20:07 --> Database Driver Class Initialized
INFO - 2018-02-07 10:20:07 --> Database Driver Class Initialized
DEBUG - 2018-02-07 10:20:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 10:20:07 --> Model Class Initialized
DEBUG - 2018-02-07 10:20:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:20:07 --> Helper loaded: inflector_helper
INFO - 2018-02-07 10:20:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-07 10:20:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 10:20:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 10:20:07 --> Helper loaded: form_helper
INFO - 2018-02-07 10:20:07 --> Form Validation Class Initialized
INFO - 2018-02-07 10:20:07 --> Controller Class Initialized
INFO - 2018-02-07 10:20:07 --> Model Class Initialized
INFO - 2018-02-07 10:20:07 --> Model Class Initialized
INFO - 2018-02-07 10:20:07 --> Model Class Initialized
INFO - 2018-02-07 10:20:07 --> Model Class Initialized
INFO - 2018-02-07 10:20:07 --> Helper loaded: form_helper
INFO - 2018-02-07 10:20:07 --> Form Validation Class Initialized
INFO - 2018-02-07 10:20:07 --> Controller Class Initialized
INFO - 2018-02-07 10:20:07 --> Model Class Initialized
INFO - 2018-02-07 10:20:07 --> Model Class Initialized
INFO - 2018-02-07 10:20:07 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 10:20:07 --> Final output sent to browser
DEBUG - 2018-02-07 10:20:07 --> Total execution time: 0.1121
INFO - 2018-02-07 10:20:07 --> Model Class Initialized
INFO - 2018-02-07 10:20:07 --> Helper loaded: inflector_helper
INFO - 2018-02-07 10:20:07 --> Model Class Initialized
INFO - 2018-02-07 10:20:07 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 10:20:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 10:20:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 10:20:07 --> Model Class Initialized
DEBUG - 2018-02-07 10:20:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 10:20:07 --> Model Class Initialized
INFO - 2018-02-07 10:20:07 --> Model Class Initialized
INFO - 2018-02-07 10:20:07 --> Model Class Initialized
INFO - 2018-02-07 10:20:07 --> Model Class Initialized
INFO - 2018-02-07 10:20:07 --> Model Class Initialized
INFO - 2018-02-07 10:20:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 10:20:07 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 10:20:07 --> Model Class Initialized
INFO - 2018-02-07 10:20:07 --> Model Class Initialized
INFO - 2018-02-07 10:20:07 --> Model Class Initialized
INFO - 2018-02-07 10:20:07 --> Model Class Initialized
INFO - 2018-02-07 10:20:07 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 10:20:07 --> Final output sent to browser
DEBUG - 2018-02-07 10:20:07 --> Total execution time: 0.1072
INFO - 2018-02-07 10:20:07 --> Final output sent to browser
DEBUG - 2018-02-07 10:20:07 --> Total execution time: 0.1087
INFO - 2018-02-07 04:50:09 --> Config Class Initialized
INFO - 2018-02-07 04:50:09 --> Hooks Class Initialized
DEBUG - 2018-02-07 04:50:09 --> UTF-8 Support Enabled
INFO - 2018-02-07 04:50:09 --> Utf8 Class Initialized
INFO - 2018-02-07 04:50:09 --> URI Class Initialized
INFO - 2018-02-07 04:50:09 --> Router Class Initialized
INFO - 2018-02-07 04:50:09 --> Output Class Initialized
INFO - 2018-02-07 04:50:09 --> Security Class Initialized
DEBUG - 2018-02-07 04:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 04:50:09 --> Input Class Initialized
INFO - 2018-02-07 04:50:09 --> Language Class Initialized
INFO - 2018-02-07 04:50:09 --> Language Class Initialized
INFO - 2018-02-07 04:50:09 --> Config Class Initialized
INFO - 2018-02-07 04:50:09 --> Loader Class Initialized
INFO - 2018-02-07 10:20:09 --> Helper loaded: url_helper
INFO - 2018-02-07 10:20:09 --> Helper loaded: notification_helper
INFO - 2018-02-07 10:20:09 --> Helper loaded: settings_helper
INFO - 2018-02-07 10:20:09 --> Helper loaded: permission_helper
INFO - 2018-02-07 10:20:09 --> Helper loaded: users_helper
INFO - 2018-02-07 10:20:09 --> Database Driver Class Initialized
DEBUG - 2018-02-07 10:20:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 10:20:09 --> Helper loaded: form_helper
INFO - 2018-02-07 10:20:09 --> Form Validation Class Initialized
INFO - 2018-02-07 10:20:09 --> Controller Class Initialized
INFO - 2018-02-07 10:20:09 --> Model Class Initialized
INFO - 2018-02-07 10:20:09 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 10:20:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 10:20:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 10:20:09 --> Model Class Initialized
INFO - 2018-02-07 10:20:09 --> Model Class Initialized
INFO - 2018-02-07 10:20:09 --> Final output sent to browser
DEBUG - 2018-02-07 10:20:09 --> Total execution time: 0.1063
INFO - 2018-02-07 04:50:18 --> Config Class Initialized
INFO - 2018-02-07 04:50:18 --> Hooks Class Initialized
DEBUG - 2018-02-07 04:50:18 --> UTF-8 Support Enabled
INFO - 2018-02-07 04:50:18 --> Utf8 Class Initialized
INFO - 2018-02-07 04:50:18 --> URI Class Initialized
INFO - 2018-02-07 04:50:18 --> Router Class Initialized
INFO - 2018-02-07 04:50:18 --> Output Class Initialized
INFO - 2018-02-07 04:50:18 --> Security Class Initialized
DEBUG - 2018-02-07 04:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 04:50:18 --> Input Class Initialized
INFO - 2018-02-07 04:50:18 --> Language Class Initialized
INFO - 2018-02-07 04:50:18 --> Language Class Initialized
INFO - 2018-02-07 04:50:18 --> Config Class Initialized
INFO - 2018-02-07 04:50:18 --> Loader Class Initialized
INFO - 2018-02-07 10:20:18 --> Helper loaded: url_helper
INFO - 2018-02-07 10:20:18 --> Helper loaded: notification_helper
INFO - 2018-02-07 10:20:18 --> Helper loaded: settings_helper
INFO - 2018-02-07 10:20:18 --> Helper loaded: permission_helper
INFO - 2018-02-07 10:20:18 --> Helper loaded: users_helper
INFO - 2018-02-07 10:20:18 --> Database Driver Class Initialized
DEBUG - 2018-02-07 10:20:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:20:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 10:20:18 --> Helper loaded: form_helper
INFO - 2018-02-07 10:20:18 --> Form Validation Class Initialized
INFO - 2018-02-07 10:20:18 --> Controller Class Initialized
INFO - 2018-02-07 10:20:18 --> Model Class Initialized
INFO - 2018-02-07 10:20:18 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 10:20:18 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 04:50:18 --> Config Class Initialized
INFO - 2018-02-07 04:50:18 --> Hooks Class Initialized
INFO - 2018-02-07 10:20:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 10:20:18 --> Model Class Initialized
INFO - 2018-02-07 10:20:18 --> Model Class Initialized
DEBUG - 2018-02-07 04:50:18 --> UTF-8 Support Enabled
INFO - 2018-02-07 04:50:18 --> Utf8 Class Initialized
INFO - 2018-02-07 10:20:18 --> Model Class Initialized
INFO - 2018-02-07 10:20:18 --> Model Class Initialized
INFO - 2018-02-07 10:20:18 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 04:50:18 --> URI Class Initialized
INFO - 2018-02-07 10:20:18 --> Final output sent to browser
DEBUG - 2018-02-07 10:20:18 --> Total execution time: 0.1065
INFO - 2018-02-07 04:50:18 --> Router Class Initialized
INFO - 2018-02-07 04:50:18 --> Output Class Initialized
INFO - 2018-02-07 04:50:18 --> Security Class Initialized
DEBUG - 2018-02-07 04:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 04:50:18 --> Input Class Initialized
INFO - 2018-02-07 04:50:18 --> Language Class Initialized
INFO - 2018-02-07 04:50:18 --> Language Class Initialized
INFO - 2018-02-07 04:50:18 --> Config Class Initialized
INFO - 2018-02-07 04:50:18 --> Loader Class Initialized
INFO - 2018-02-07 10:20:18 --> Helper loaded: url_helper
INFO - 2018-02-07 10:20:18 --> Helper loaded: notification_helper
INFO - 2018-02-07 10:20:18 --> Helper loaded: settings_helper
INFO - 2018-02-07 10:20:18 --> Helper loaded: permission_helper
INFO - 2018-02-07 10:20:18 --> Helper loaded: users_helper
INFO - 2018-02-07 04:50:18 --> Config Class Initialized
INFO - 2018-02-07 04:50:18 --> Hooks Class Initialized
DEBUG - 2018-02-07 04:50:18 --> UTF-8 Support Enabled
INFO - 2018-02-07 04:50:18 --> Utf8 Class Initialized
INFO - 2018-02-07 04:50:18 --> URI Class Initialized
INFO - 2018-02-07 04:50:18 --> Router Class Initialized
INFO - 2018-02-07 04:50:18 --> Output Class Initialized
INFO - 2018-02-07 04:50:18 --> Security Class Initialized
INFO - 2018-02-07 10:20:18 --> Database Driver Class Initialized
DEBUG - 2018-02-07 04:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 04:50:18 --> Input Class Initialized
INFO - 2018-02-07 04:50:18 --> Language Class Initialized
DEBUG - 2018-02-07 10:20:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:20:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 10:20:18 --> Helper loaded: form_helper
INFO - 2018-02-07 10:20:18 --> Form Validation Class Initialized
INFO - 2018-02-07 10:20:18 --> Controller Class Initialized
INFO - 2018-02-07 04:50:18 --> Language Class Initialized
INFO - 2018-02-07 04:50:18 --> Config Class Initialized
INFO - 2018-02-07 04:50:18 --> Loader Class Initialized
INFO - 2018-02-07 10:20:18 --> Helper loaded: url_helper
INFO - 2018-02-07 10:20:18 --> Helper loaded: notification_helper
INFO - 2018-02-07 10:20:18 --> Helper loaded: settings_helper
INFO - 2018-02-07 10:20:18 --> Helper loaded: permission_helper
INFO - 2018-02-07 10:20:18 --> Helper loaded: users_helper
INFO - 2018-02-07 10:20:18 --> Model Class Initialized
INFO - 2018-02-07 10:20:18 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 10:20:18 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 10:20:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 10:20:18 --> Model Class Initialized
INFO - 2018-02-07 10:20:18 --> Model Class Initialized
INFO - 2018-02-07 10:20:18 --> Model Class Initialized
INFO - 2018-02-07 10:20:18 --> Model Class Initialized
INFO - 2018-02-07 10:20:18 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 10:20:18 --> Database Driver Class Initialized
INFO - 2018-02-07 10:20:18 --> Final output sent to browser
DEBUG - 2018-02-07 10:20:18 --> Total execution time: 0.1119
DEBUG - 2018-02-07 10:20:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:20:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 10:20:18 --> Helper loaded: form_helper
INFO - 2018-02-07 10:20:18 --> Form Validation Class Initialized
INFO - 2018-02-07 10:20:18 --> Controller Class Initialized
INFO - 2018-02-07 04:50:18 --> Config Class Initialized
INFO - 2018-02-07 04:50:18 --> Hooks Class Initialized
DEBUG - 2018-02-07 04:50:18 --> UTF-8 Support Enabled
INFO - 2018-02-07 04:50:18 --> Utf8 Class Initialized
INFO - 2018-02-07 10:20:18 --> Model Class Initialized
INFO - 2018-02-07 10:20:18 --> Helper loaded: inflector_helper
INFO - 2018-02-07 04:50:18 --> URI Class Initialized
DEBUG - 2018-02-07 10:20:18 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 04:50:18 --> Router Class Initialized
INFO - 2018-02-07 10:20:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 10:20:18 --> Model Class Initialized
INFO - 2018-02-07 10:20:18 --> Model Class Initialized
INFO - 2018-02-07 10:20:18 --> Model Class Initialized
INFO - 2018-02-07 10:20:18 --> Model Class Initialized
INFO - 2018-02-07 10:20:18 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 04:50:18 --> Output Class Initialized
INFO - 2018-02-07 10:20:18 --> Final output sent to browser
DEBUG - 2018-02-07 10:20:18 --> Total execution time: 0.0984
INFO - 2018-02-07 04:50:18 --> Security Class Initialized
DEBUG - 2018-02-07 04:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 04:50:18 --> Input Class Initialized
INFO - 2018-02-07 04:50:18 --> Language Class Initialized
INFO - 2018-02-07 04:50:18 --> Language Class Initialized
INFO - 2018-02-07 04:50:18 --> Config Class Initialized
INFO - 2018-02-07 04:50:18 --> Loader Class Initialized
INFO - 2018-02-07 10:20:18 --> Helper loaded: url_helper
INFO - 2018-02-07 10:20:18 --> Helper loaded: notification_helper
INFO - 2018-02-07 10:20:18 --> Helper loaded: settings_helper
INFO - 2018-02-07 10:20:18 --> Helper loaded: permission_helper
INFO - 2018-02-07 10:20:18 --> Helper loaded: users_helper
INFO - 2018-02-07 10:20:18 --> Database Driver Class Initialized
DEBUG - 2018-02-07 10:20:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:20:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 10:20:18 --> Helper loaded: form_helper
INFO - 2018-02-07 10:20:18 --> Form Validation Class Initialized
INFO - 2018-02-07 10:20:18 --> Controller Class Initialized
INFO - 2018-02-07 10:20:18 --> Model Class Initialized
INFO - 2018-02-07 10:20:18 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 10:20:18 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 10:20:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 10:20:18 --> Model Class Initialized
INFO - 2018-02-07 10:20:18 --> Model Class Initialized
INFO - 2018-02-07 10:20:18 --> Model Class Initialized
INFO - 2018-02-07 10:20:18 --> Model Class Initialized
INFO - 2018-02-07 10:20:18 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 10:20:18 --> Final output sent to browser
DEBUG - 2018-02-07 10:20:18 --> Total execution time: 0.1133
INFO - 2018-02-07 04:50:21 --> Config Class Initialized
INFO - 2018-02-07 04:50:21 --> Hooks Class Initialized
DEBUG - 2018-02-07 04:50:21 --> UTF-8 Support Enabled
INFO - 2018-02-07 04:50:21 --> Utf8 Class Initialized
INFO - 2018-02-07 04:50:21 --> URI Class Initialized
INFO - 2018-02-07 04:50:21 --> Router Class Initialized
INFO - 2018-02-07 04:50:21 --> Output Class Initialized
INFO - 2018-02-07 04:50:21 --> Security Class Initialized
DEBUG - 2018-02-07 04:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 04:50:21 --> Input Class Initialized
INFO - 2018-02-07 04:50:21 --> Language Class Initialized
INFO - 2018-02-07 04:50:21 --> Language Class Initialized
INFO - 2018-02-07 04:50:21 --> Config Class Initialized
INFO - 2018-02-07 04:50:21 --> Loader Class Initialized
INFO - 2018-02-07 10:20:21 --> Helper loaded: url_helper
INFO - 2018-02-07 10:20:21 --> Helper loaded: notification_helper
INFO - 2018-02-07 10:20:21 --> Helper loaded: settings_helper
INFO - 2018-02-07 10:20:21 --> Helper loaded: permission_helper
INFO - 2018-02-07 10:20:21 --> Helper loaded: users_helper
INFO - 2018-02-07 10:20:21 --> Database Driver Class Initialized
DEBUG - 2018-02-07 10:20:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:20:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 10:20:21 --> Helper loaded: form_helper
INFO - 2018-02-07 10:20:21 --> Form Validation Class Initialized
INFO - 2018-02-07 10:20:21 --> Controller Class Initialized
INFO - 2018-02-07 10:20:21 --> Model Class Initialized
INFO - 2018-02-07 10:20:21 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 10:20:21 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 10:20:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 10:20:21 --> Model Class Initialized
INFO - 2018-02-07 10:20:21 --> Model Class Initialized
INFO - 2018-02-07 10:20:21 --> Model Class Initialized
INFO - 2018-02-07 10:20:21 --> Model Class Initialized
INFO - 2018-02-07 10:20:21 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 10:20:21 --> Final output sent to browser
DEBUG - 2018-02-07 10:20:21 --> Total execution time: 0.1015
INFO - 2018-02-07 04:50:22 --> Config Class Initialized
INFO - 2018-02-07 04:50:22 --> Hooks Class Initialized
DEBUG - 2018-02-07 04:50:22 --> UTF-8 Support Enabled
INFO - 2018-02-07 04:50:22 --> Utf8 Class Initialized
INFO - 2018-02-07 04:50:22 --> URI Class Initialized
INFO - 2018-02-07 04:50:22 --> Router Class Initialized
INFO - 2018-02-07 04:50:22 --> Output Class Initialized
INFO - 2018-02-07 04:50:22 --> Security Class Initialized
DEBUG - 2018-02-07 04:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 04:50:22 --> Input Class Initialized
INFO - 2018-02-07 04:50:22 --> Language Class Initialized
INFO - 2018-02-07 04:50:22 --> Language Class Initialized
INFO - 2018-02-07 04:50:22 --> Config Class Initialized
INFO - 2018-02-07 04:50:22 --> Loader Class Initialized
INFO - 2018-02-07 10:20:22 --> Helper loaded: url_helper
INFO - 2018-02-07 10:20:22 --> Helper loaded: notification_helper
INFO - 2018-02-07 10:20:22 --> Helper loaded: settings_helper
INFO - 2018-02-07 10:20:22 --> Helper loaded: permission_helper
INFO - 2018-02-07 10:20:22 --> Helper loaded: users_helper
INFO - 2018-02-07 10:20:22 --> Database Driver Class Initialized
DEBUG - 2018-02-07 10:20:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 10:20:22 --> Helper loaded: form_helper
INFO - 2018-02-07 10:20:22 --> Form Validation Class Initialized
INFO - 2018-02-07 10:20:22 --> Controller Class Initialized
INFO - 2018-02-07 10:20:22 --> Model Class Initialized
INFO - 2018-02-07 10:20:22 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 10:20:22 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 10:20:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 10:20:22 --> Model Class Initialized
INFO - 2018-02-07 10:20:22 --> Model Class Initialized
INFO - 2018-02-07 10:20:22 --> Model Class Initialized
INFO - 2018-02-07 10:20:22 --> Model Class Initialized
INFO - 2018-02-07 10:20:22 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 10:20:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-07 10:20:22 --> Final output sent to browser
DEBUG - 2018-02-07 10:20:22 --> Total execution time: 0.1073
INFO - 2018-02-07 04:50:23 --> Config Class Initialized
INFO - 2018-02-07 04:50:23 --> Hooks Class Initialized
DEBUG - 2018-02-07 04:50:23 --> UTF-8 Support Enabled
INFO - 2018-02-07 04:50:23 --> Utf8 Class Initialized
INFO - 2018-02-07 04:50:23 --> URI Class Initialized
INFO - 2018-02-07 04:50:23 --> Router Class Initialized
INFO - 2018-02-07 04:50:23 --> Output Class Initialized
INFO - 2018-02-07 04:50:23 --> Security Class Initialized
DEBUG - 2018-02-07 04:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 04:50:23 --> Input Class Initialized
INFO - 2018-02-07 04:50:23 --> Language Class Initialized
INFO - 2018-02-07 04:50:23 --> Language Class Initialized
INFO - 2018-02-07 04:50:23 --> Config Class Initialized
INFO - 2018-02-07 04:50:23 --> Loader Class Initialized
INFO - 2018-02-07 10:20:23 --> Helper loaded: url_helper
INFO - 2018-02-07 10:20:23 --> Helper loaded: notification_helper
INFO - 2018-02-07 10:20:23 --> Helper loaded: settings_helper
INFO - 2018-02-07 10:20:23 --> Helper loaded: permission_helper
INFO - 2018-02-07 10:20:23 --> Helper loaded: users_helper
INFO - 2018-02-07 10:20:23 --> Database Driver Class Initialized
DEBUG - 2018-02-07 10:20:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:20:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 10:20:23 --> Helper loaded: form_helper
INFO - 2018-02-07 10:20:23 --> Form Validation Class Initialized
INFO - 2018-02-07 10:20:23 --> Controller Class Initialized
INFO - 2018-02-07 10:20:23 --> Model Class Initialized
INFO - 2018-02-07 10:20:23 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 10:20:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 10:20:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 10:20:23 --> Model Class Initialized
INFO - 2018-02-07 10:20:23 --> Model Class Initialized
INFO - 2018-02-07 10:20:23 --> Model Class Initialized
INFO - 2018-02-07 10:20:23 --> Model Class Initialized
INFO - 2018-02-07 10:20:23 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 10:20:23 --> Final output sent to browser
DEBUG - 2018-02-07 10:20:23 --> Total execution time: 0.0986
INFO - 2018-02-07 04:50:24 --> Config Class Initialized
INFO - 2018-02-07 04:50:24 --> Hooks Class Initialized
DEBUG - 2018-02-07 04:50:24 --> UTF-8 Support Enabled
INFO - 2018-02-07 04:50:24 --> Utf8 Class Initialized
INFO - 2018-02-07 04:50:24 --> URI Class Initialized
INFO - 2018-02-07 04:50:24 --> Router Class Initialized
INFO - 2018-02-07 04:50:24 --> Output Class Initialized
INFO - 2018-02-07 04:50:24 --> Security Class Initialized
DEBUG - 2018-02-07 04:50:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 04:50:24 --> Input Class Initialized
INFO - 2018-02-07 04:50:24 --> Language Class Initialized
INFO - 2018-02-07 04:50:24 --> Language Class Initialized
INFO - 2018-02-07 04:50:24 --> Config Class Initialized
INFO - 2018-02-07 04:50:24 --> Loader Class Initialized
INFO - 2018-02-07 10:20:24 --> Helper loaded: url_helper
INFO - 2018-02-07 10:20:24 --> Helper loaded: notification_helper
INFO - 2018-02-07 10:20:24 --> Helper loaded: settings_helper
INFO - 2018-02-07 10:20:24 --> Helper loaded: permission_helper
INFO - 2018-02-07 10:20:24 --> Helper loaded: users_helper
INFO - 2018-02-07 10:20:24 --> Database Driver Class Initialized
DEBUG - 2018-02-07 10:20:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 10:20:24 --> Helper loaded: form_helper
INFO - 2018-02-07 10:20:24 --> Form Validation Class Initialized
INFO - 2018-02-07 10:20:24 --> Controller Class Initialized
INFO - 2018-02-07 10:20:24 --> Model Class Initialized
INFO - 2018-02-07 10:20:24 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 10:20:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 10:20:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 10:20:24 --> Model Class Initialized
INFO - 2018-02-07 10:20:24 --> Model Class Initialized
INFO - 2018-02-07 10:20:24 --> Model Class Initialized
INFO - 2018-02-07 10:20:24 --> Model Class Initialized
INFO - 2018-02-07 10:20:24 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 10:20:24 --> Final output sent to browser
DEBUG - 2018-02-07 10:20:24 --> Total execution time: 0.1162
INFO - 2018-02-07 04:50:26 --> Config Class Initialized
INFO - 2018-02-07 04:50:26 --> Hooks Class Initialized
DEBUG - 2018-02-07 04:50:26 --> UTF-8 Support Enabled
INFO - 2018-02-07 04:50:26 --> Utf8 Class Initialized
INFO - 2018-02-07 04:50:26 --> URI Class Initialized
INFO - 2018-02-07 04:50:26 --> Router Class Initialized
INFO - 2018-02-07 04:50:26 --> Output Class Initialized
INFO - 2018-02-07 04:50:26 --> Security Class Initialized
DEBUG - 2018-02-07 04:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 04:50:26 --> Input Class Initialized
INFO - 2018-02-07 04:50:26 --> Language Class Initialized
INFO - 2018-02-07 04:50:26 --> Language Class Initialized
INFO - 2018-02-07 04:50:26 --> Config Class Initialized
INFO - 2018-02-07 04:50:26 --> Loader Class Initialized
INFO - 2018-02-07 10:20:26 --> Helper loaded: url_helper
INFO - 2018-02-07 10:20:26 --> Helper loaded: notification_helper
INFO - 2018-02-07 10:20:26 --> Helper loaded: settings_helper
INFO - 2018-02-07 10:20:26 --> Helper loaded: permission_helper
INFO - 2018-02-07 10:20:26 --> Helper loaded: users_helper
INFO - 2018-02-07 10:20:26 --> Database Driver Class Initialized
DEBUG - 2018-02-07 10:20:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:20:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 10:20:26 --> Helper loaded: form_helper
INFO - 2018-02-07 10:20:26 --> Form Validation Class Initialized
INFO - 2018-02-07 10:20:26 --> Controller Class Initialized
INFO - 2018-02-07 10:20:26 --> Model Class Initialized
INFO - 2018-02-07 10:20:26 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 10:20:26 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 10:20:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 10:20:26 --> Model Class Initialized
INFO - 2018-02-07 10:20:26 --> Model Class Initialized
INFO - 2018-02-07 10:20:26 --> Model Class Initialized
INFO - 2018-02-07 10:20:26 --> Model Class Initialized
INFO - 2018-02-07 10:20:26 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 10:20:26 --> Final output sent to browser
DEBUG - 2018-02-07 10:20:26 --> Total execution time: 0.1040
INFO - 2018-02-07 04:50:26 --> Config Class Initialized
INFO - 2018-02-07 04:50:26 --> Hooks Class Initialized
DEBUG - 2018-02-07 04:50:26 --> UTF-8 Support Enabled
INFO - 2018-02-07 04:50:26 --> Utf8 Class Initialized
INFO - 2018-02-07 04:50:26 --> URI Class Initialized
INFO - 2018-02-07 04:50:26 --> Router Class Initialized
INFO - 2018-02-07 04:50:26 --> Output Class Initialized
INFO - 2018-02-07 04:50:26 --> Security Class Initialized
DEBUG - 2018-02-07 04:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 04:50:26 --> Input Class Initialized
INFO - 2018-02-07 04:50:26 --> Language Class Initialized
INFO - 2018-02-07 04:50:26 --> Language Class Initialized
INFO - 2018-02-07 04:50:26 --> Config Class Initialized
INFO - 2018-02-07 04:50:26 --> Loader Class Initialized
INFO - 2018-02-07 10:20:26 --> Helper loaded: url_helper
INFO - 2018-02-07 10:20:26 --> Helper loaded: notification_helper
INFO - 2018-02-07 10:20:26 --> Helper loaded: settings_helper
INFO - 2018-02-07 10:20:26 --> Helper loaded: permission_helper
INFO - 2018-02-07 10:20:26 --> Helper loaded: users_helper
INFO - 2018-02-07 10:20:27 --> Database Driver Class Initialized
DEBUG - 2018-02-07 10:20:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:20:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 10:20:27 --> Helper loaded: form_helper
INFO - 2018-02-07 10:20:27 --> Form Validation Class Initialized
INFO - 2018-02-07 10:20:27 --> Controller Class Initialized
INFO - 2018-02-07 10:20:27 --> Model Class Initialized
INFO - 2018-02-07 10:20:27 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 10:20:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 10:20:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 10:20:27 --> Model Class Initialized
INFO - 2018-02-07 10:20:27 --> Model Class Initialized
INFO - 2018-02-07 10:20:27 --> Model Class Initialized
INFO - 2018-02-07 10:20:27 --> Model Class Initialized
INFO - 2018-02-07 10:20:27 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 10:20:27 --> Final output sent to browser
DEBUG - 2018-02-07 10:20:27 --> Total execution time: 0.0753
INFO - 2018-02-07 04:50:29 --> Config Class Initialized
INFO - 2018-02-07 04:50:29 --> Hooks Class Initialized
DEBUG - 2018-02-07 04:50:29 --> UTF-8 Support Enabled
INFO - 2018-02-07 04:50:29 --> Utf8 Class Initialized
INFO - 2018-02-07 04:50:29 --> URI Class Initialized
INFO - 2018-02-07 04:50:29 --> Router Class Initialized
INFO - 2018-02-07 04:50:29 --> Output Class Initialized
INFO - 2018-02-07 04:50:30 --> Security Class Initialized
DEBUG - 2018-02-07 04:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 04:50:30 --> Input Class Initialized
INFO - 2018-02-07 04:50:30 --> Language Class Initialized
INFO - 2018-02-07 04:50:30 --> Language Class Initialized
INFO - 2018-02-07 04:50:30 --> Config Class Initialized
INFO - 2018-02-07 04:50:30 --> Loader Class Initialized
INFO - 2018-02-07 10:20:30 --> Helper loaded: url_helper
INFO - 2018-02-07 10:20:30 --> Helper loaded: notification_helper
INFO - 2018-02-07 10:20:30 --> Helper loaded: settings_helper
INFO - 2018-02-07 10:20:30 --> Helper loaded: permission_helper
INFO - 2018-02-07 10:20:30 --> Helper loaded: users_helper
INFO - 2018-02-07 10:20:30 --> Database Driver Class Initialized
DEBUG - 2018-02-07 10:20:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:20:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 10:20:30 --> Helper loaded: form_helper
INFO - 2018-02-07 10:20:30 --> Form Validation Class Initialized
INFO - 2018-02-07 10:20:30 --> Controller Class Initialized
INFO - 2018-02-07 10:20:30 --> Model Class Initialized
INFO - 2018-02-07 10:20:30 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 10:20:30 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 10:20:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 10:20:30 --> Model Class Initialized
INFO - 2018-02-07 10:20:30 --> Model Class Initialized
INFO - 2018-02-07 10:20:30 --> Model Class Initialized
INFO - 2018-02-07 10:20:30 --> Model Class Initialized
INFO - 2018-02-07 10:20:30 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 10:20:30 --> Final output sent to browser
DEBUG - 2018-02-07 10:20:30 --> Total execution time: 0.0951
INFO - 2018-02-07 04:50:30 --> Config Class Initialized
INFO - 2018-02-07 04:50:30 --> Hooks Class Initialized
DEBUG - 2018-02-07 04:50:30 --> UTF-8 Support Enabled
INFO - 2018-02-07 04:50:30 --> Utf8 Class Initialized
INFO - 2018-02-07 04:50:30 --> URI Class Initialized
INFO - 2018-02-07 04:50:31 --> Router Class Initialized
INFO - 2018-02-07 04:50:31 --> Output Class Initialized
INFO - 2018-02-07 04:50:31 --> Security Class Initialized
DEBUG - 2018-02-07 04:50:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 04:50:31 --> Input Class Initialized
INFO - 2018-02-07 04:50:31 --> Language Class Initialized
INFO - 2018-02-07 04:50:31 --> Language Class Initialized
INFO - 2018-02-07 04:50:31 --> Config Class Initialized
INFO - 2018-02-07 04:50:31 --> Loader Class Initialized
INFO - 2018-02-07 10:20:31 --> Helper loaded: url_helper
INFO - 2018-02-07 10:20:31 --> Helper loaded: notification_helper
INFO - 2018-02-07 10:20:31 --> Helper loaded: settings_helper
INFO - 2018-02-07 10:20:31 --> Helper loaded: permission_helper
INFO - 2018-02-07 10:20:31 --> Helper loaded: users_helper
INFO - 2018-02-07 10:20:31 --> Database Driver Class Initialized
DEBUG - 2018-02-07 10:20:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:20:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 10:20:31 --> Helper loaded: form_helper
INFO - 2018-02-07 10:20:31 --> Form Validation Class Initialized
INFO - 2018-02-07 10:20:31 --> Controller Class Initialized
INFO - 2018-02-07 10:20:31 --> Model Class Initialized
INFO - 2018-02-07 10:20:31 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 10:20:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 10:20:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 10:20:31 --> Model Class Initialized
INFO - 2018-02-07 10:20:31 --> Model Class Initialized
INFO - 2018-02-07 10:20:31 --> Model Class Initialized
INFO - 2018-02-07 10:20:31 --> Model Class Initialized
INFO - 2018-02-07 10:20:31 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 10:20:31 --> Model Class Initialized
INFO - 2018-02-07 10:20:31 --> Final output sent to browser
DEBUG - 2018-02-07 10:20:31 --> Total execution time: 0.1141
INFO - 2018-02-07 04:50:31 --> Config Class Initialized
INFO - 2018-02-07 04:50:31 --> Hooks Class Initialized
DEBUG - 2018-02-07 04:50:31 --> UTF-8 Support Enabled
INFO - 2018-02-07 04:50:31 --> Utf8 Class Initialized
INFO - 2018-02-07 04:50:31 --> URI Class Initialized
INFO - 2018-02-07 04:50:31 --> Router Class Initialized
INFO - 2018-02-07 04:50:31 --> Output Class Initialized
INFO - 2018-02-07 04:50:31 --> Security Class Initialized
DEBUG - 2018-02-07 04:50:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 04:50:31 --> Input Class Initialized
INFO - 2018-02-07 04:50:31 --> Language Class Initialized
INFO - 2018-02-07 04:50:31 --> Language Class Initialized
INFO - 2018-02-07 04:50:31 --> Config Class Initialized
INFO - 2018-02-07 04:50:31 --> Loader Class Initialized
INFO - 2018-02-07 10:20:31 --> Helper loaded: url_helper
INFO - 2018-02-07 10:20:31 --> Helper loaded: notification_helper
INFO - 2018-02-07 10:20:31 --> Helper loaded: settings_helper
INFO - 2018-02-07 10:20:31 --> Helper loaded: permission_helper
INFO - 2018-02-07 10:20:31 --> Helper loaded: users_helper
INFO - 2018-02-07 10:20:31 --> Database Driver Class Initialized
DEBUG - 2018-02-07 10:20:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:20:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 10:20:31 --> Helper loaded: form_helper
INFO - 2018-02-07 10:20:31 --> Form Validation Class Initialized
INFO - 2018-02-07 10:20:31 --> Controller Class Initialized
INFO - 2018-02-07 10:20:31 --> Model Class Initialized
INFO - 2018-02-07 10:20:31 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 10:20:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 10:20:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 10:20:31 --> Model Class Initialized
INFO - 2018-02-07 10:20:31 --> Model Class Initialized
INFO - 2018-02-07 10:20:31 --> Model Class Initialized
INFO - 2018-02-07 10:20:31 --> Model Class Initialized
INFO - 2018-02-07 10:20:31 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 10:20:31 --> Final output sent to browser
DEBUG - 2018-02-07 10:20:31 --> Total execution time: 0.1074
INFO - 2018-02-07 04:50:32 --> Config Class Initialized
INFO - 2018-02-07 04:50:32 --> Hooks Class Initialized
DEBUG - 2018-02-07 04:50:32 --> UTF-8 Support Enabled
INFO - 2018-02-07 04:50:32 --> Utf8 Class Initialized
INFO - 2018-02-07 04:50:32 --> URI Class Initialized
INFO - 2018-02-07 04:50:32 --> Router Class Initialized
INFO - 2018-02-07 04:50:32 --> Output Class Initialized
INFO - 2018-02-07 04:50:32 --> Security Class Initialized
DEBUG - 2018-02-07 04:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 04:50:32 --> Input Class Initialized
INFO - 2018-02-07 04:50:32 --> Language Class Initialized
INFO - 2018-02-07 04:50:32 --> Language Class Initialized
INFO - 2018-02-07 04:50:32 --> Config Class Initialized
INFO - 2018-02-07 04:50:32 --> Loader Class Initialized
INFO - 2018-02-07 10:20:32 --> Helper loaded: url_helper
INFO - 2018-02-07 10:20:32 --> Helper loaded: notification_helper
INFO - 2018-02-07 10:20:32 --> Helper loaded: settings_helper
INFO - 2018-02-07 10:20:32 --> Helper loaded: permission_helper
INFO - 2018-02-07 10:20:32 --> Helper loaded: users_helper
INFO - 2018-02-07 10:20:32 --> Database Driver Class Initialized
DEBUG - 2018-02-07 10:20:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 10:20:32 --> Helper loaded: form_helper
INFO - 2018-02-07 10:20:32 --> Form Validation Class Initialized
INFO - 2018-02-07 10:20:32 --> Controller Class Initialized
INFO - 2018-02-07 10:20:32 --> Model Class Initialized
INFO - 2018-02-07 10:20:32 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 10:20:32 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 10:20:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 10:20:32 --> Model Class Initialized
INFO - 2018-02-07 10:20:32 --> Model Class Initialized
INFO - 2018-02-07 10:20:32 --> Model Class Initialized
INFO - 2018-02-07 10:20:32 --> Model Class Initialized
INFO - 2018-02-07 10:20:32 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 10:20:32 --> Final output sent to browser
DEBUG - 2018-02-07 10:20:32 --> Total execution time: 0.0764
INFO - 2018-02-07 04:50:33 --> Config Class Initialized
INFO - 2018-02-07 04:50:33 --> Hooks Class Initialized
DEBUG - 2018-02-07 04:50:33 --> UTF-8 Support Enabled
INFO - 2018-02-07 04:50:33 --> Utf8 Class Initialized
INFO - 2018-02-07 04:50:33 --> URI Class Initialized
INFO - 2018-02-07 04:50:33 --> Router Class Initialized
INFO - 2018-02-07 04:50:33 --> Output Class Initialized
INFO - 2018-02-07 04:50:33 --> Security Class Initialized
DEBUG - 2018-02-07 04:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 04:50:33 --> Input Class Initialized
INFO - 2018-02-07 04:50:33 --> Language Class Initialized
INFO - 2018-02-07 04:50:33 --> Language Class Initialized
INFO - 2018-02-07 04:50:33 --> Config Class Initialized
INFO - 2018-02-07 04:50:33 --> Loader Class Initialized
INFO - 2018-02-07 10:20:33 --> Helper loaded: url_helper
INFO - 2018-02-07 10:20:33 --> Helper loaded: notification_helper
INFO - 2018-02-07 10:20:33 --> Helper loaded: settings_helper
INFO - 2018-02-07 10:20:33 --> Helper loaded: permission_helper
INFO - 2018-02-07 10:20:33 --> Helper loaded: users_helper
INFO - 2018-02-07 10:20:33 --> Database Driver Class Initialized
DEBUG - 2018-02-07 10:20:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 10:20:33 --> Helper loaded: form_helper
INFO - 2018-02-07 10:20:33 --> Form Validation Class Initialized
INFO - 2018-02-07 10:20:33 --> Controller Class Initialized
INFO - 2018-02-07 10:20:33 --> Model Class Initialized
INFO - 2018-02-07 10:20:33 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 10:20:33 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 10:20:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 10:20:33 --> Model Class Initialized
INFO - 2018-02-07 10:20:33 --> Model Class Initialized
INFO - 2018-02-07 10:20:33 --> Model Class Initialized
INFO - 2018-02-07 10:20:33 --> Model Class Initialized
INFO - 2018-02-07 10:20:33 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 10:20:33 --> Final output sent to browser
DEBUG - 2018-02-07 10:20:33 --> Total execution time: 0.1063
INFO - 2018-02-07 04:50:33 --> Config Class Initialized
INFO - 2018-02-07 04:50:33 --> Hooks Class Initialized
DEBUG - 2018-02-07 04:50:34 --> UTF-8 Support Enabled
INFO - 2018-02-07 04:50:34 --> Utf8 Class Initialized
INFO - 2018-02-07 04:50:34 --> URI Class Initialized
INFO - 2018-02-07 04:50:34 --> Router Class Initialized
INFO - 2018-02-07 04:50:34 --> Output Class Initialized
INFO - 2018-02-07 04:50:34 --> Security Class Initialized
DEBUG - 2018-02-07 04:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 04:50:34 --> Input Class Initialized
INFO - 2018-02-07 04:50:34 --> Language Class Initialized
INFO - 2018-02-07 04:50:34 --> Language Class Initialized
INFO - 2018-02-07 04:50:34 --> Config Class Initialized
INFO - 2018-02-07 04:50:34 --> Loader Class Initialized
INFO - 2018-02-07 10:20:34 --> Helper loaded: url_helper
INFO - 2018-02-07 10:20:34 --> Helper loaded: notification_helper
INFO - 2018-02-07 10:20:34 --> Helper loaded: settings_helper
INFO - 2018-02-07 10:20:34 --> Helper loaded: permission_helper
INFO - 2018-02-07 10:20:34 --> Helper loaded: users_helper
INFO - 2018-02-07 10:20:34 --> Database Driver Class Initialized
DEBUG - 2018-02-07 10:20:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:20:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 10:20:34 --> Helper loaded: form_helper
INFO - 2018-02-07 10:20:34 --> Form Validation Class Initialized
INFO - 2018-02-07 10:20:34 --> Controller Class Initialized
INFO - 2018-02-07 10:20:34 --> Model Class Initialized
INFO - 2018-02-07 10:20:34 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 10:20:34 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 10:20:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 10:20:34 --> Model Class Initialized
INFO - 2018-02-07 10:20:34 --> Model Class Initialized
INFO - 2018-02-07 10:20:34 --> Model Class Initialized
INFO - 2018-02-07 10:20:34 --> Model Class Initialized
INFO - 2018-02-07 10:20:34 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 10:20:34 --> Final output sent to browser
DEBUG - 2018-02-07 10:20:34 --> Total execution time: 0.0962
INFO - 2018-02-07 04:50:35 --> Config Class Initialized
INFO - 2018-02-07 04:50:35 --> Hooks Class Initialized
DEBUG - 2018-02-07 04:50:35 --> UTF-8 Support Enabled
INFO - 2018-02-07 04:50:35 --> Utf8 Class Initialized
INFO - 2018-02-07 04:50:35 --> URI Class Initialized
INFO - 2018-02-07 04:50:35 --> Router Class Initialized
INFO - 2018-02-07 04:50:35 --> Output Class Initialized
INFO - 2018-02-07 04:50:35 --> Security Class Initialized
DEBUG - 2018-02-07 04:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 04:50:35 --> Input Class Initialized
INFO - 2018-02-07 04:50:35 --> Language Class Initialized
INFO - 2018-02-07 04:50:35 --> Language Class Initialized
INFO - 2018-02-07 04:50:35 --> Config Class Initialized
INFO - 2018-02-07 04:50:35 --> Loader Class Initialized
INFO - 2018-02-07 10:20:35 --> Helper loaded: url_helper
INFO - 2018-02-07 10:20:35 --> Helper loaded: notification_helper
INFO - 2018-02-07 10:20:35 --> Helper loaded: settings_helper
INFO - 2018-02-07 10:20:35 --> Helper loaded: permission_helper
INFO - 2018-02-07 10:20:35 --> Helper loaded: users_helper
INFO - 2018-02-07 10:20:35 --> Database Driver Class Initialized
DEBUG - 2018-02-07 10:20:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:20:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 10:20:35 --> Helper loaded: form_helper
INFO - 2018-02-07 10:20:35 --> Form Validation Class Initialized
INFO - 2018-02-07 10:20:35 --> Controller Class Initialized
INFO - 2018-02-07 10:20:35 --> Model Class Initialized
INFO - 2018-02-07 10:20:35 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 10:20:35 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 10:20:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 10:20:35 --> Model Class Initialized
INFO - 2018-02-07 10:20:35 --> Model Class Initialized
INFO - 2018-02-07 10:20:35 --> Model Class Initialized
INFO - 2018-02-07 10:20:35 --> Model Class Initialized
INFO - 2018-02-07 10:20:35 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 10:20:35 --> Final output sent to browser
DEBUG - 2018-02-07 10:20:35 --> Total execution time: 0.1044
INFO - 2018-02-07 04:50:36 --> Config Class Initialized
INFO - 2018-02-07 04:50:36 --> Hooks Class Initialized
DEBUG - 2018-02-07 04:50:36 --> UTF-8 Support Enabled
INFO - 2018-02-07 04:50:36 --> Utf8 Class Initialized
INFO - 2018-02-07 04:50:36 --> URI Class Initialized
INFO - 2018-02-07 04:50:36 --> Router Class Initialized
INFO - 2018-02-07 04:50:36 --> Output Class Initialized
INFO - 2018-02-07 04:50:36 --> Security Class Initialized
DEBUG - 2018-02-07 04:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 04:50:37 --> Input Class Initialized
INFO - 2018-02-07 04:50:37 --> Language Class Initialized
INFO - 2018-02-07 04:50:37 --> Config Class Initialized
INFO - 2018-02-07 04:50:37 --> Hooks Class Initialized
DEBUG - 2018-02-07 04:50:37 --> UTF-8 Support Enabled
INFO - 2018-02-07 04:50:37 --> Utf8 Class Initialized
INFO - 2018-02-07 04:50:37 --> URI Class Initialized
INFO - 2018-02-07 04:50:37 --> Language Class Initialized
INFO - 2018-02-07 04:50:37 --> Config Class Initialized
INFO - 2018-02-07 04:50:37 --> Loader Class Initialized
INFO - 2018-02-07 10:20:37 --> Helper loaded: url_helper
INFO - 2018-02-07 04:50:37 --> Router Class Initialized
INFO - 2018-02-07 10:20:37 --> Helper loaded: notification_helper
INFO - 2018-02-07 04:50:37 --> Config Class Initialized
INFO - 2018-02-07 04:50:37 --> Hooks Class Initialized
INFO - 2018-02-07 10:20:37 --> Helper loaded: settings_helper
INFO - 2018-02-07 10:20:37 --> Helper loaded: permission_helper
INFO - 2018-02-07 10:20:37 --> Helper loaded: users_helper
INFO - 2018-02-07 04:50:37 --> Output Class Initialized
DEBUG - 2018-02-07 04:50:37 --> UTF-8 Support Enabled
INFO - 2018-02-07 04:50:37 --> Utf8 Class Initialized
INFO - 2018-02-07 04:50:37 --> Security Class Initialized
INFO - 2018-02-07 04:50:37 --> URI Class Initialized
DEBUG - 2018-02-07 04:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 04:50:37 --> Input Class Initialized
INFO - 2018-02-07 04:50:37 --> Language Class Initialized
INFO - 2018-02-07 04:50:37 --> Router Class Initialized
INFO - 2018-02-07 04:50:37 --> Output Class Initialized
INFO - 2018-02-07 04:50:37 --> Security Class Initialized
DEBUG - 2018-02-07 04:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 04:50:37 --> Input Class Initialized
INFO - 2018-02-07 10:20:37 --> Database Driver Class Initialized
INFO - 2018-02-07 04:50:37 --> Language Class Initialized
DEBUG - 2018-02-07 10:20:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 04:50:37 --> Language Class Initialized
INFO - 2018-02-07 04:50:37 --> Config Class Initialized
INFO - 2018-02-07 04:50:37 --> Loader Class Initialized
INFO - 2018-02-07 10:20:37 --> Helper loaded: url_helper
INFO - 2018-02-07 10:20:37 --> Helper loaded: notification_helper
INFO - 2018-02-07 04:50:37 --> Language Class Initialized
INFO - 2018-02-07 04:50:37 --> Config Class Initialized
INFO - 2018-02-07 04:50:37 --> Loader Class Initialized
INFO - 2018-02-07 10:20:37 --> Helper loaded: settings_helper
INFO - 2018-02-07 10:20:37 --> Helper loaded: permission_helper
INFO - 2018-02-07 10:20:37 --> Helper loaded: users_helper
INFO - 2018-02-07 10:20:37 --> Helper loaded: url_helper
INFO - 2018-02-07 10:20:37 --> Helper loaded: form_helper
INFO - 2018-02-07 10:20:37 --> Form Validation Class Initialized
INFO - 2018-02-07 10:20:37 --> Controller Class Initialized
INFO - 2018-02-07 10:20:37 --> Helper loaded: notification_helper
INFO - 2018-02-07 10:20:37 --> Helper loaded: settings_helper
INFO - 2018-02-07 10:20:37 --> Helper loaded: permission_helper
INFO - 2018-02-07 10:20:37 --> Helper loaded: users_helper
INFO - 2018-02-07 10:20:37 --> Model Class Initialized
INFO - 2018-02-07 10:20:37 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 10:20:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 10:20:37 --> Database Driver Class Initialized
INFO - 2018-02-07 10:20:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 10:20:37 --> Database Driver Class Initialized
INFO - 2018-02-07 10:20:37 --> Model Class Initialized
INFO - 2018-02-07 10:20:37 --> Model Class Initialized
INFO - 2018-02-07 10:20:37 --> Model Class Initialized
INFO - 2018-02-07 10:20:37 --> Model Class Initialized
INFO - 2018-02-07 10:20:37 --> Model Class Initialized
INFO - 2018-02-07 10:20:37 --> Model Class Initialized
INFO - 2018-02-07 10:20:37 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-02-07 10:20:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 10:20:37 --> Final output sent to browser
DEBUG - 2018-02-07 10:20:37 --> Total execution time: 0.1193
DEBUG - 2018-02-07 10:20:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 10:20:37 --> Helper loaded: form_helper
INFO - 2018-02-07 10:20:37 --> Form Validation Class Initialized
INFO - 2018-02-07 10:20:37 --> Controller Class Initialized
INFO - 2018-02-07 10:20:37 --> Helper loaded: form_helper
INFO - 2018-02-07 10:20:37 --> Form Validation Class Initialized
INFO - 2018-02-07 10:20:37 --> Controller Class Initialized
INFO - 2018-02-07 10:20:37 --> Model Class Initialized
INFO - 2018-02-07 10:20:37 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 10:20:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 10:20:37 --> Model Class Initialized
INFO - 2018-02-07 10:20:37 --> Helper loaded: inflector_helper
INFO - 2018-02-07 10:20:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 10:20:37 --> Model Class Initialized
INFO - 2018-02-07 10:20:37 --> Model Class Initialized
INFO - 2018-02-07 10:20:37 --> Model Class Initialized
INFO - 2018-02-07 10:20:37 --> Model Class Initialized
DEBUG - 2018-02-07 10:20:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 10:20:37 --> Model Class Initialized
INFO - 2018-02-07 10:20:37 --> Model Class Initialized
INFO - 2018-02-07 10:20:37 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 10:20:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 10:20:37 --> Model Class Initialized
INFO - 2018-02-07 10:20:37 --> Model Class Initialized
INFO - 2018-02-07 10:20:37 --> Model Class Initialized
INFO - 2018-02-07 10:20:37 --> Model Class Initialized
INFO - 2018-02-07 10:20:37 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 10:20:37 --> Final output sent to browser
DEBUG - 2018-02-07 10:20:37 --> Total execution time: 0.1069
INFO - 2018-02-07 10:20:37 --> Final output sent to browser
DEBUG - 2018-02-07 10:20:37 --> Total execution time: 0.1008
INFO - 2018-02-07 04:50:38 --> Config Class Initialized
INFO - 2018-02-07 04:50:38 --> Hooks Class Initialized
DEBUG - 2018-02-07 04:50:38 --> UTF-8 Support Enabled
INFO - 2018-02-07 04:50:38 --> Utf8 Class Initialized
INFO - 2018-02-07 04:50:38 --> URI Class Initialized
INFO - 2018-02-07 04:50:38 --> Router Class Initialized
INFO - 2018-02-07 04:50:38 --> Output Class Initialized
INFO - 2018-02-07 04:50:38 --> Security Class Initialized
DEBUG - 2018-02-07 04:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 04:50:38 --> Input Class Initialized
INFO - 2018-02-07 04:50:38 --> Language Class Initialized
INFO - 2018-02-07 04:50:38 --> Language Class Initialized
INFO - 2018-02-07 04:50:38 --> Config Class Initialized
INFO - 2018-02-07 04:50:38 --> Loader Class Initialized
INFO - 2018-02-07 04:50:38 --> Config Class Initialized
INFO - 2018-02-07 10:20:38 --> Helper loaded: url_helper
INFO - 2018-02-07 04:50:38 --> Hooks Class Initialized
INFO - 2018-02-07 10:20:38 --> Helper loaded: notification_helper
INFO - 2018-02-07 10:20:38 --> Helper loaded: settings_helper
INFO - 2018-02-07 10:20:38 --> Helper loaded: permission_helper
INFO - 2018-02-07 10:20:38 --> Helper loaded: users_helper
DEBUG - 2018-02-07 04:50:38 --> UTF-8 Support Enabled
INFO - 2018-02-07 04:50:38 --> Utf8 Class Initialized
INFO - 2018-02-07 04:50:38 --> URI Class Initialized
INFO - 2018-02-07 04:50:38 --> Router Class Initialized
INFO - 2018-02-07 04:50:38 --> Output Class Initialized
INFO - 2018-02-07 04:50:38 --> Security Class Initialized
INFO - 2018-02-07 10:20:38 --> Database Driver Class Initialized
DEBUG - 2018-02-07 04:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 04:50:38 --> Input Class Initialized
INFO - 2018-02-07 04:50:38 --> Language Class Initialized
DEBUG - 2018-02-07 10:20:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 10:20:38 --> Helper loaded: form_helper
INFO - 2018-02-07 10:20:38 --> Form Validation Class Initialized
INFO - 2018-02-07 10:20:38 --> Controller Class Initialized
INFO - 2018-02-07 04:50:38 --> Language Class Initialized
INFO - 2018-02-07 04:50:38 --> Config Class Initialized
INFO - 2018-02-07 04:50:38 --> Loader Class Initialized
INFO - 2018-02-07 10:20:38 --> Model Class Initialized
INFO - 2018-02-07 10:20:38 --> Helper loaded: inflector_helper
INFO - 2018-02-07 10:20:38 --> Helper loaded: url_helper
INFO - 2018-02-07 10:20:38 --> Helper loaded: notification_helper
INFO - 2018-02-07 10:20:38 --> Helper loaded: settings_helper
DEBUG - 2018-02-07 10:20:38 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 10:20:38 --> Helper loaded: permission_helper
INFO - 2018-02-07 10:20:38 --> Helper loaded: users_helper
INFO - 2018-02-07 10:20:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 10:20:38 --> Model Class Initialized
INFO - 2018-02-07 10:20:38 --> Model Class Initialized
INFO - 2018-02-07 10:20:38 --> Model Class Initialized
INFO - 2018-02-07 10:20:38 --> Model Class Initialized
INFO - 2018-02-07 10:20:38 --> Model Class Initialized
INFO - 2018-02-07 10:20:38 --> Model Class Initialized
INFO - 2018-02-07 10:20:38 --> Model Class Initialized
INFO - 2018-02-07 10:20:38 --> Model Class Initialized
INFO - 2018-02-07 10:20:38 --> Model Class Initialized
INFO - 2018-02-07 10:20:38 --> Model Class Initialized
INFO - 2018-02-07 10:20:38 --> Model Class Initialized
INFO - 2018-02-07 10:20:38 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 10:20:38 --> Model Class Initialized
INFO - 2018-02-07 10:20:38 --> Database Driver Class Initialized
INFO - 2018-02-07 10:20:38 --> Final output sent to browser
DEBUG - 2018-02-07 10:20:38 --> Total execution time: 0.1218
DEBUG - 2018-02-07 10:20:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 10:20:39 --> Helper loaded: form_helper
INFO - 2018-02-07 10:20:39 --> Form Validation Class Initialized
INFO - 2018-02-07 10:20:39 --> Controller Class Initialized
INFO - 2018-02-07 10:20:39 --> Model Class Initialized
INFO - 2018-02-07 10:20:39 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 10:20:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 10:20:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 10:20:39 --> Model Class Initialized
INFO - 2018-02-07 10:20:39 --> Model Class Initialized
INFO - 2018-02-07 10:20:39 --> Model Class Initialized
INFO - 2018-02-07 10:20:39 --> Model Class Initialized
INFO - 2018-02-07 10:20:39 --> Model Class Initialized
INFO - 2018-02-07 10:20:39 --> Model Class Initialized
INFO - 2018-02-07 10:20:39 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 10:20:39 --> Model Class Initialized
INFO - 2018-02-07 10:20:39 --> Final output sent to browser
DEBUG - 2018-02-07 10:20:39 --> Total execution time: 0.1183
INFO - 2018-02-07 04:50:40 --> Config Class Initialized
INFO - 2018-02-07 04:50:40 --> Hooks Class Initialized
DEBUG - 2018-02-07 04:50:40 --> UTF-8 Support Enabled
INFO - 2018-02-07 04:50:40 --> Utf8 Class Initialized
INFO - 2018-02-07 04:50:40 --> URI Class Initialized
INFO - 2018-02-07 04:50:40 --> Config Class Initialized
INFO - 2018-02-07 04:50:40 --> Hooks Class Initialized
INFO - 2018-02-07 04:50:40 --> Router Class Initialized
DEBUG - 2018-02-07 04:50:40 --> UTF-8 Support Enabled
INFO - 2018-02-07 04:50:40 --> Utf8 Class Initialized
INFO - 2018-02-07 04:50:40 --> Output Class Initialized
INFO - 2018-02-07 04:50:40 --> URI Class Initialized
INFO - 2018-02-07 04:50:40 --> Security Class Initialized
INFO - 2018-02-07 04:50:40 --> Router Class Initialized
DEBUG - 2018-02-07 04:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 04:50:40 --> Input Class Initialized
INFO - 2018-02-07 04:50:40 --> Language Class Initialized
INFO - 2018-02-07 04:50:40 --> Config Class Initialized
INFO - 2018-02-07 04:50:40 --> Hooks Class Initialized
INFO - 2018-02-07 04:50:40 --> Output Class Initialized
DEBUG - 2018-02-07 04:50:40 --> UTF-8 Support Enabled
INFO - 2018-02-07 04:50:40 --> Utf8 Class Initialized
INFO - 2018-02-07 04:50:40 --> Security Class Initialized
INFO - 2018-02-07 04:50:40 --> URI Class Initialized
DEBUG - 2018-02-07 04:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 04:50:40 --> Input Class Initialized
INFO - 2018-02-07 04:50:40 --> Language Class Initialized
INFO - 2018-02-07 04:50:40 --> Router Class Initialized
INFO - 2018-02-07 04:50:40 --> Output Class Initialized
INFO - 2018-02-07 04:50:40 --> Security Class Initialized
DEBUG - 2018-02-07 04:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 04:50:40 --> Input Class Initialized
INFO - 2018-02-07 04:50:40 --> Language Class Initialized
INFO - 2018-02-07 04:50:40 --> Config Class Initialized
INFO - 2018-02-07 04:50:40 --> Loader Class Initialized
INFO - 2018-02-07 04:50:40 --> Language Class Initialized
INFO - 2018-02-07 10:20:40 --> Helper loaded: url_helper
INFO - 2018-02-07 10:20:40 --> Helper loaded: notification_helper
INFO - 2018-02-07 10:20:40 --> Helper loaded: settings_helper
INFO - 2018-02-07 10:20:40 --> Helper loaded: permission_helper
INFO - 2018-02-07 10:20:40 --> Helper loaded: users_helper
INFO - 2018-02-07 04:50:40 --> Language Class Initialized
INFO - 2018-02-07 04:50:40 --> Config Class Initialized
INFO - 2018-02-07 04:50:40 --> Loader Class Initialized
INFO - 2018-02-07 10:20:40 --> Helper loaded: url_helper
INFO - 2018-02-07 10:20:40 --> Helper loaded: notification_helper
INFO - 2018-02-07 10:20:40 --> Helper loaded: settings_helper
INFO - 2018-02-07 10:20:40 --> Helper loaded: permission_helper
INFO - 2018-02-07 10:20:40 --> Helper loaded: users_helper
INFO - 2018-02-07 04:50:40 --> Language Class Initialized
INFO - 2018-02-07 04:50:40 --> Config Class Initialized
INFO - 2018-02-07 04:50:40 --> Loader Class Initialized
INFO - 2018-02-07 10:20:40 --> Helper loaded: url_helper
INFO - 2018-02-07 10:20:40 --> Helper loaded: notification_helper
INFO - 2018-02-07 10:20:40 --> Helper loaded: settings_helper
INFO - 2018-02-07 10:20:40 --> Database Driver Class Initialized
INFO - 2018-02-07 10:20:40 --> Helper loaded: permission_helper
INFO - 2018-02-07 10:20:40 --> Helper loaded: users_helper
DEBUG - 2018-02-07 10:20:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 10:20:40 --> Database Driver Class Initialized
INFO - 2018-02-07 10:20:40 --> Helper loaded: form_helper
INFO - 2018-02-07 10:20:40 --> Form Validation Class Initialized
INFO - 2018-02-07 10:20:40 --> Controller Class Initialized
DEBUG - 2018-02-07 10:20:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 10:20:40 --> Database Driver Class Initialized
DEBUG - 2018-02-07 10:20:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 10:20:40 --> Model Class Initialized
INFO - 2018-02-07 10:20:40 --> Helper loaded: inflector_helper
INFO - 2018-02-07 10:20:40 --> Helper loaded: form_helper
INFO - 2018-02-07 10:20:40 --> Form Validation Class Initialized
INFO - 2018-02-07 10:20:40 --> Controller Class Initialized
DEBUG - 2018-02-07 10:20:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 10:20:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 10:20:40 --> Model Class Initialized
INFO - 2018-02-07 10:20:40 --> Model Class Initialized
INFO - 2018-02-07 10:20:40 --> Model Class Initialized
INFO - 2018-02-07 10:20:40 --> Model Class Initialized
INFO - 2018-02-07 10:20:40 --> Helper loaded: form_helper
INFO - 2018-02-07 10:20:40 --> Form Validation Class Initialized
INFO - 2018-02-07 10:20:40 --> Controller Class Initialized
INFO - 2018-02-07 10:20:40 --> Model Class Initialized
INFO - 2018-02-07 10:20:40 --> Model Class Initialized
INFO - 2018-02-07 10:20:40 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 10:20:40 --> Model Class Initialized
INFO - 2018-02-07 10:20:40 --> Final output sent to browser
DEBUG - 2018-02-07 10:20:40 --> Total execution time: 0.1066
INFO - 2018-02-07 10:20:40 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 10:20:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 10:20:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 10:20:40 --> Model Class Initialized
INFO - 2018-02-07 10:20:40 --> Helper loaded: inflector_helper
INFO - 2018-02-07 10:20:40 --> Model Class Initialized
INFO - 2018-02-07 10:20:40 --> Model Class Initialized
INFO - 2018-02-07 10:20:40 --> Model Class Initialized
INFO - 2018-02-07 10:20:40 --> Model Class Initialized
INFO - 2018-02-07 10:20:40 --> Model Class Initialized
INFO - 2018-02-07 10:20:40 --> Model Class Initialized
INFO - 2018-02-07 10:20:40 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-02-07 10:20:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 10:20:40 --> Final output sent to browser
DEBUG - 2018-02-07 10:20:40 --> Total execution time: 0.1128
INFO - 2018-02-07 10:20:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 10:20:40 --> Model Class Initialized
INFO - 2018-02-07 10:20:40 --> Model Class Initialized
INFO - 2018-02-07 10:20:40 --> Model Class Initialized
INFO - 2018-02-07 10:20:40 --> Model Class Initialized
INFO - 2018-02-07 10:20:40 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 10:20:40 --> Final output sent to browser
DEBUG - 2018-02-07 10:20:40 --> Total execution time: 0.1069
INFO - 2018-02-07 04:50:41 --> Config Class Initialized
INFO - 2018-02-07 04:50:41 --> Hooks Class Initialized
DEBUG - 2018-02-07 04:50:41 --> UTF-8 Support Enabled
INFO - 2018-02-07 04:50:41 --> Utf8 Class Initialized
INFO - 2018-02-07 04:50:41 --> URI Class Initialized
INFO - 2018-02-07 04:50:41 --> Router Class Initialized
INFO - 2018-02-07 04:50:41 --> Output Class Initialized
INFO - 2018-02-07 04:50:41 --> Security Class Initialized
DEBUG - 2018-02-07 04:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 04:50:41 --> Input Class Initialized
INFO - 2018-02-07 04:50:41 --> Language Class Initialized
INFO - 2018-02-07 04:50:41 --> Language Class Initialized
INFO - 2018-02-07 04:50:41 --> Config Class Initialized
INFO - 2018-02-07 04:50:41 --> Loader Class Initialized
INFO - 2018-02-07 10:20:41 --> Helper loaded: url_helper
INFO - 2018-02-07 10:20:41 --> Helper loaded: notification_helper
INFO - 2018-02-07 10:20:41 --> Helper loaded: settings_helper
INFO - 2018-02-07 10:20:41 --> Helper loaded: permission_helper
INFO - 2018-02-07 10:20:41 --> Helper loaded: users_helper
INFO - 2018-02-07 10:20:41 --> Database Driver Class Initialized
DEBUG - 2018-02-07 10:20:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:20:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 10:20:41 --> Helper loaded: form_helper
INFO - 2018-02-07 10:20:41 --> Form Validation Class Initialized
INFO - 2018-02-07 10:20:41 --> Controller Class Initialized
INFO - 2018-02-07 10:20:41 --> Model Class Initialized
INFO - 2018-02-07 10:20:41 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 10:20:41 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 10:20:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 10:20:41 --> Model Class Initialized
INFO - 2018-02-07 10:20:41 --> Model Class Initialized
INFO - 2018-02-07 10:20:41 --> Final output sent to browser
DEBUG - 2018-02-07 10:20:41 --> Total execution time: 0.0983
INFO - 2018-02-07 04:50:44 --> Config Class Initialized
INFO - 2018-02-07 04:50:44 --> Hooks Class Initialized
DEBUG - 2018-02-07 04:50:44 --> UTF-8 Support Enabled
INFO - 2018-02-07 04:50:44 --> Utf8 Class Initialized
INFO - 2018-02-07 04:50:44 --> URI Class Initialized
INFO - 2018-02-07 04:50:44 --> Router Class Initialized
INFO - 2018-02-07 04:50:44 --> Output Class Initialized
INFO - 2018-02-07 04:50:44 --> Security Class Initialized
DEBUG - 2018-02-07 04:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 04:50:44 --> Input Class Initialized
INFO - 2018-02-07 04:50:44 --> Language Class Initialized
INFO - 2018-02-07 04:50:44 --> Language Class Initialized
INFO - 2018-02-07 04:50:44 --> Config Class Initialized
INFO - 2018-02-07 04:50:44 --> Loader Class Initialized
INFO - 2018-02-07 10:20:44 --> Helper loaded: url_helper
INFO - 2018-02-07 10:20:44 --> Helper loaded: notification_helper
INFO - 2018-02-07 10:20:44 --> Helper loaded: settings_helper
INFO - 2018-02-07 10:20:44 --> Helper loaded: permission_helper
INFO - 2018-02-07 10:20:44 --> Helper loaded: users_helper
INFO - 2018-02-07 10:20:44 --> Database Driver Class Initialized
DEBUG - 2018-02-07 10:20:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:20:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 10:20:44 --> Helper loaded: form_helper
INFO - 2018-02-07 10:20:44 --> Form Validation Class Initialized
INFO - 2018-02-07 10:20:44 --> Controller Class Initialized
INFO - 2018-02-07 10:20:44 --> Model Class Initialized
INFO - 2018-02-07 10:20:44 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 10:20:44 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 10:20:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 10:20:44 --> Model Class Initialized
INFO - 2018-02-07 10:20:44 --> Model Class Initialized
INFO - 2018-02-07 10:20:44 --> Model Class Initialized
INFO - 2018-02-07 10:20:44 --> Model Class Initialized
INFO - 2018-02-07 10:20:44 --> Model Class Initialized
INFO - 2018-02-07 10:20:44 --> Model Class Initialized
INFO - 2018-02-07 10:20:44 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 10:20:44 --> Final output sent to browser
DEBUG - 2018-02-07 10:20:44 --> Total execution time: 0.1058
INFO - 2018-02-07 04:50:45 --> Config Class Initialized
INFO - 2018-02-07 04:50:45 --> Hooks Class Initialized
DEBUG - 2018-02-07 04:50:45 --> UTF-8 Support Enabled
INFO - 2018-02-07 04:50:45 --> Utf8 Class Initialized
INFO - 2018-02-07 04:50:45 --> URI Class Initialized
INFO - 2018-02-07 04:50:45 --> Router Class Initialized
INFO - 2018-02-07 04:50:45 --> Output Class Initialized
INFO - 2018-02-07 04:50:45 --> Security Class Initialized
DEBUG - 2018-02-07 04:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 04:50:45 --> Input Class Initialized
INFO - 2018-02-07 04:50:45 --> Language Class Initialized
INFO - 2018-02-07 04:50:45 --> Language Class Initialized
INFO - 2018-02-07 04:50:45 --> Config Class Initialized
INFO - 2018-02-07 04:50:45 --> Loader Class Initialized
INFO - 2018-02-07 10:20:45 --> Helper loaded: url_helper
INFO - 2018-02-07 10:20:45 --> Helper loaded: notification_helper
INFO - 2018-02-07 10:20:45 --> Helper loaded: settings_helper
INFO - 2018-02-07 10:20:45 --> Helper loaded: permission_helper
INFO - 2018-02-07 10:20:45 --> Helper loaded: users_helper
INFO - 2018-02-07 10:20:45 --> Database Driver Class Initialized
DEBUG - 2018-02-07 10:20:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 10:20:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 10:20:45 --> Helper loaded: form_helper
INFO - 2018-02-07 10:20:45 --> Form Validation Class Initialized
INFO - 2018-02-07 10:20:45 --> Controller Class Initialized
INFO - 2018-02-07 10:20:45 --> Model Class Initialized
INFO - 2018-02-07 10:20:45 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 10:20:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 10:20:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 10:20:45 --> Model Class Initialized
INFO - 2018-02-07 10:20:45 --> Model Class Initialized
INFO - 2018-02-07 10:20:45 --> Model Class Initialized
INFO - 2018-02-07 10:20:45 --> Model Class Initialized
INFO - 2018-02-07 10:20:45 --> Model Class Initialized
INFO - 2018-02-07 10:20:45 --> Model Class Initialized
INFO - 2018-02-07 10:20:45 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 10:20:45 --> Final output sent to browser
DEBUG - 2018-02-07 10:20:45 --> Total execution time: 0.1122
INFO - 2018-02-07 06:31:42 --> Config Class Initialized
INFO - 2018-02-07 06:31:42 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:31:42 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:31:42 --> Utf8 Class Initialized
INFO - 2018-02-07 06:31:42 --> URI Class Initialized
INFO - 2018-02-07 06:31:42 --> Router Class Initialized
INFO - 2018-02-07 06:31:42 --> Output Class Initialized
INFO - 2018-02-07 06:31:42 --> Security Class Initialized
DEBUG - 2018-02-07 06:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:31:42 --> Input Class Initialized
INFO - 2018-02-07 06:31:42 --> Language Class Initialized
INFO - 2018-02-07 06:31:42 --> Language Class Initialized
INFO - 2018-02-07 06:31:42 --> Config Class Initialized
INFO - 2018-02-07 06:31:42 --> Loader Class Initialized
INFO - 2018-02-07 12:01:42 --> Helper loaded: url_helper
INFO - 2018-02-07 12:01:42 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:01:42 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:01:42 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:01:42 --> Helper loaded: users_helper
INFO - 2018-02-07 12:01:42 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:01:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:01:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:01:42 --> Helper loaded: form_helper
INFO - 2018-02-07 12:01:42 --> Form Validation Class Initialized
INFO - 2018-02-07 12:01:42 --> Controller Class Initialized
INFO - 2018-02-07 12:01:42 --> Model Class Initialized
INFO - 2018-02-07 12:01:42 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:01:42 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:01:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:01:42 --> Model Class Initialized
INFO - 2018-02-07 12:01:42 --> Model Class Initialized
INFO - 2018-02-07 12:01:42 --> Model Class Initialized
INFO - 2018-02-07 12:01:42 --> Model Class Initialized
INFO - 2018-02-07 12:01:42 --> Model Class Initialized
INFO - 2018-02-07 12:01:42 --> Model Class Initialized
INFO - 2018-02-07 12:01:42 --> Model Class Initialized
INFO - 2018-02-07 12:01:42 --> Model Class Initialized
INFO - 2018-02-07 12:01:42 --> Model Class Initialized
INFO - 2018-02-07 12:01:42 --> Model Class Initialized
INFO - 2018-02-07 12:01:42 --> Model Class Initialized
INFO - 2018-02-07 12:01:42 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:01:42 --> Model Class Initialized
INFO - 2018-02-07 12:01:42 --> Final output sent to browser
DEBUG - 2018-02-07 12:01:42 --> Total execution time: 0.1249
INFO - 2018-02-07 06:31:42 --> Config Class Initialized
INFO - 2018-02-07 06:31:42 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:31:42 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:31:42 --> Utf8 Class Initialized
INFO - 2018-02-07 06:31:42 --> URI Class Initialized
INFO - 2018-02-07 06:31:42 --> Router Class Initialized
INFO - 2018-02-07 06:31:42 --> Output Class Initialized
INFO - 2018-02-07 06:31:42 --> Security Class Initialized
DEBUG - 2018-02-07 06:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:31:42 --> Input Class Initialized
INFO - 2018-02-07 06:31:42 --> Language Class Initialized
INFO - 2018-02-07 06:31:43 --> Language Class Initialized
INFO - 2018-02-07 06:31:43 --> Config Class Initialized
INFO - 2018-02-07 06:31:43 --> Loader Class Initialized
INFO - 2018-02-07 12:01:43 --> Helper loaded: url_helper
INFO - 2018-02-07 12:01:43 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:01:43 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:01:43 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:01:43 --> Helper loaded: users_helper
INFO - 2018-02-07 12:01:43 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:01:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:01:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:01:43 --> Helper loaded: form_helper
INFO - 2018-02-07 12:01:43 --> Form Validation Class Initialized
INFO - 2018-02-07 12:01:43 --> Controller Class Initialized
INFO - 2018-02-07 12:01:43 --> Model Class Initialized
INFO - 2018-02-07 12:01:43 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:01:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:01:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:01:43 --> Model Class Initialized
INFO - 2018-02-07 12:01:43 --> Model Class Initialized
INFO - 2018-02-07 12:01:43 --> Model Class Initialized
INFO - 2018-02-07 12:01:43 --> Model Class Initialized
INFO - 2018-02-07 12:01:43 --> Model Class Initialized
INFO - 2018-02-07 12:01:43 --> Model Class Initialized
INFO - 2018-02-07 12:01:43 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:01:43 --> Model Class Initialized
INFO - 2018-02-07 12:01:43 --> Final output sent to browser
DEBUG - 2018-02-07 12:01:43 --> Total execution time: 0.1063
INFO - 2018-02-07 06:31:57 --> Config Class Initialized
INFO - 2018-02-07 06:31:57 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:31:57 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:31:57 --> Utf8 Class Initialized
INFO - 2018-02-07 06:31:57 --> URI Class Initialized
INFO - 2018-02-07 06:31:57 --> Router Class Initialized
INFO - 2018-02-07 06:31:57 --> Output Class Initialized
INFO - 2018-02-07 06:31:57 --> Security Class Initialized
DEBUG - 2018-02-07 06:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:31:57 --> Input Class Initialized
INFO - 2018-02-07 06:31:57 --> Language Class Initialized
INFO - 2018-02-07 06:31:57 --> Language Class Initialized
INFO - 2018-02-07 06:31:57 --> Config Class Initialized
INFO - 2018-02-07 06:31:57 --> Loader Class Initialized
INFO - 2018-02-07 12:01:57 --> Helper loaded: url_helper
INFO - 2018-02-07 12:01:57 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:01:57 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:01:57 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:01:57 --> Helper loaded: users_helper
INFO - 2018-02-07 12:01:57 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:01:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:01:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:01:57 --> Helper loaded: form_helper
INFO - 2018-02-07 12:01:57 --> Form Validation Class Initialized
INFO - 2018-02-07 12:01:57 --> Controller Class Initialized
INFO - 2018-02-07 12:01:57 --> Model Class Initialized
INFO - 2018-02-07 12:01:57 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:01:57 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:01:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:01:57 --> Model Class Initialized
INFO - 2018-02-07 12:01:57 --> Model Class Initialized
INFO - 2018-02-07 12:01:57 --> Model Class Initialized
INFO - 2018-02-07 12:01:57 --> Model Class Initialized
INFO - 2018-02-07 12:01:57 --> Model Class Initialized
INFO - 2018-02-07 12:01:57 --> Model Class Initialized
INFO - 2018-02-07 12:01:57 --> Model Class Initialized
INFO - 2018-02-07 12:01:57 --> Model Class Initialized
INFO - 2018-02-07 12:01:57 --> Model Class Initialized
INFO - 2018-02-07 12:01:57 --> Model Class Initialized
INFO - 2018-02-07 12:01:57 --> Model Class Initialized
INFO - 2018-02-07 12:01:57 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:01:57 --> Model Class Initialized
INFO - 2018-02-07 12:01:57 --> Final output sent to browser
DEBUG - 2018-02-07 12:01:57 --> Total execution time: 0.1405
INFO - 2018-02-07 06:50:16 --> Config Class Initialized
INFO - 2018-02-07 06:50:16 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:50:16 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:50:16 --> Utf8 Class Initialized
INFO - 2018-02-07 06:50:16 --> URI Class Initialized
INFO - 2018-02-07 06:50:16 --> Router Class Initialized
INFO - 2018-02-07 06:50:16 --> Output Class Initialized
INFO - 2018-02-07 06:50:16 --> Security Class Initialized
DEBUG - 2018-02-07 06:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:50:16 --> Input Class Initialized
INFO - 2018-02-07 06:50:16 --> Language Class Initialized
INFO - 2018-02-07 06:50:16 --> Language Class Initialized
INFO - 2018-02-07 06:50:16 --> Config Class Initialized
INFO - 2018-02-07 06:50:16 --> Loader Class Initialized
INFO - 2018-02-07 12:20:16 --> Helper loaded: url_helper
INFO - 2018-02-07 12:20:16 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:20:16 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:20:16 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:20:16 --> Helper loaded: users_helper
INFO - 2018-02-07 12:20:16 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:20:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:20:16 --> Helper loaded: form_helper
INFO - 2018-02-07 12:20:16 --> Form Validation Class Initialized
INFO - 2018-02-07 12:20:16 --> Controller Class Initialized
INFO - 2018-02-07 12:20:16 --> Model Class Initialized
INFO - 2018-02-07 12:20:16 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:20:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:20:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:20:16 --> Model Class Initialized
INFO - 2018-02-07 12:20:16 --> Model Class Initialized
INFO - 2018-02-07 12:20:16 --> Model Class Initialized
INFO - 2018-02-07 12:20:16 --> Model Class Initialized
INFO - 2018-02-07 12:20:16 --> Model Class Initialized
INFO - 2018-02-07 12:20:16 --> Model Class Initialized
INFO - 2018-02-07 12:20:16 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:20:16 --> Final output sent to browser
DEBUG - 2018-02-07 12:20:16 --> Total execution time: 0.0886
INFO - 2018-02-07 06:50:17 --> Config Class Initialized
INFO - 2018-02-07 06:50:17 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:50:17 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:50:17 --> Utf8 Class Initialized
INFO - 2018-02-07 06:50:17 --> URI Class Initialized
INFO - 2018-02-07 06:50:17 --> Router Class Initialized
INFO - 2018-02-07 06:50:17 --> Output Class Initialized
INFO - 2018-02-07 06:50:17 --> Security Class Initialized
DEBUG - 2018-02-07 06:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:50:17 --> Input Class Initialized
INFO - 2018-02-07 06:50:17 --> Language Class Initialized
INFO - 2018-02-07 06:50:17 --> Language Class Initialized
INFO - 2018-02-07 06:50:17 --> Config Class Initialized
INFO - 2018-02-07 06:50:17 --> Loader Class Initialized
INFO - 2018-02-07 12:20:17 --> Helper loaded: url_helper
INFO - 2018-02-07 12:20:17 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:20:17 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:20:17 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:20:17 --> Helper loaded: users_helper
INFO - 2018-02-07 12:20:17 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:20:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:20:17 --> Helper loaded: form_helper
INFO - 2018-02-07 12:20:17 --> Form Validation Class Initialized
INFO - 2018-02-07 12:20:17 --> Controller Class Initialized
INFO - 2018-02-07 12:20:17 --> Model Class Initialized
INFO - 2018-02-07 12:20:17 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:20:17 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:20:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:20:17 --> Model Class Initialized
INFO - 2018-02-07 12:20:17 --> Model Class Initialized
INFO - 2018-02-07 12:20:17 --> Model Class Initialized
INFO - 2018-02-07 12:20:17 --> Model Class Initialized
INFO - 2018-02-07 12:20:17 --> Model Class Initialized
INFO - 2018-02-07 12:20:17 --> Model Class Initialized
INFO - 2018-02-07 12:20:17 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:20:17 --> Final output sent to browser
DEBUG - 2018-02-07 12:20:17 --> Total execution time: 0.1205
INFO - 2018-02-07 06:50:17 --> Config Class Initialized
INFO - 2018-02-07 06:50:17 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:50:17 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:50:17 --> Utf8 Class Initialized
INFO - 2018-02-07 06:50:17 --> URI Class Initialized
INFO - 2018-02-07 06:50:17 --> Router Class Initialized
INFO - 2018-02-07 06:50:17 --> Config Class Initialized
INFO - 2018-02-07 06:50:17 --> Hooks Class Initialized
INFO - 2018-02-07 06:50:17 --> Output Class Initialized
DEBUG - 2018-02-07 06:50:17 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:50:17 --> Utf8 Class Initialized
INFO - 2018-02-07 06:50:17 --> Security Class Initialized
INFO - 2018-02-07 06:50:17 --> URI Class Initialized
DEBUG - 2018-02-07 06:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:50:17 --> Input Class Initialized
INFO - 2018-02-07 06:50:17 --> Language Class Initialized
INFO - 2018-02-07 06:50:17 --> Router Class Initialized
INFO - 2018-02-07 06:50:17 --> Output Class Initialized
INFO - 2018-02-07 06:50:17 --> Security Class Initialized
DEBUG - 2018-02-07 06:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:50:17 --> Input Class Initialized
INFO - 2018-02-07 06:50:17 --> Language Class Initialized
INFO - 2018-02-07 06:50:17 --> Language Class Initialized
INFO - 2018-02-07 06:50:17 --> Config Class Initialized
INFO - 2018-02-07 06:50:17 --> Loader Class Initialized
INFO - 2018-02-07 12:20:17 --> Helper loaded: url_helper
INFO - 2018-02-07 12:20:17 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:20:17 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:20:17 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:20:17 --> Helper loaded: users_helper
INFO - 2018-02-07 06:50:17 --> Config Class Initialized
INFO - 2018-02-07 06:50:17 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:50:17 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:50:17 --> Utf8 Class Initialized
INFO - 2018-02-07 06:50:17 --> Language Class Initialized
INFO - 2018-02-07 06:50:17 --> Config Class Initialized
INFO - 2018-02-07 06:50:17 --> Loader Class Initialized
INFO - 2018-02-07 06:50:17 --> URI Class Initialized
INFO - 2018-02-07 12:20:17 --> Helper loaded: url_helper
INFO - 2018-02-07 12:20:17 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:20:17 --> Helper loaded: settings_helper
INFO - 2018-02-07 06:50:17 --> Router Class Initialized
INFO - 2018-02-07 12:20:17 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:20:17 --> Helper loaded: users_helper
INFO - 2018-02-07 12:20:17 --> Database Driver Class Initialized
INFO - 2018-02-07 06:50:17 --> Output Class Initialized
INFO - 2018-02-07 06:50:17 --> Security Class Initialized
DEBUG - 2018-02-07 12:20:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:20:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-07 06:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:50:17 --> Input Class Initialized
INFO - 2018-02-07 06:50:17 --> Language Class Initialized
INFO - 2018-02-07 12:20:17 --> Database Driver Class Initialized
INFO - 2018-02-07 12:20:17 --> Helper loaded: form_helper
INFO - 2018-02-07 12:20:17 --> Form Validation Class Initialized
INFO - 2018-02-07 12:20:17 --> Controller Class Initialized
DEBUG - 2018-02-07 12:20:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:20:17 --> Model Class Initialized
INFO - 2018-02-07 12:20:17 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:20:17 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:20:17 --> Helper loaded: form_helper
INFO - 2018-02-07 06:50:17 --> Language Class Initialized
INFO - 2018-02-07 12:20:17 --> Form Validation Class Initialized
INFO - 2018-02-07 06:50:17 --> Config Class Initialized
INFO - 2018-02-07 12:20:17 --> Controller Class Initialized
INFO - 2018-02-07 06:50:17 --> Loader Class Initialized
INFO - 2018-02-07 12:20:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:20:17 --> Model Class Initialized
INFO - 2018-02-07 12:20:17 --> Helper loaded: url_helper
INFO - 2018-02-07 12:20:17 --> Model Class Initialized
INFO - 2018-02-07 12:20:17 --> Model Class Initialized
INFO - 2018-02-07 12:20:17 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:20:17 --> Model Class Initialized
INFO - 2018-02-07 12:20:17 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:20:17 --> Model Class Initialized
INFO - 2018-02-07 12:20:17 --> Model Class Initialized
INFO - 2018-02-07 12:20:17 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:20:17 --> Model Class Initialized
INFO - 2018-02-07 12:20:17 --> Model Class Initialized
INFO - 2018-02-07 12:20:17 --> Helper loaded: users_helper
INFO - 2018-02-07 12:20:17 --> Model Class Initialized
INFO - 2018-02-07 12:20:17 --> Model Class Initialized
INFO - 2018-02-07 12:20:17 --> Model Class Initialized
INFO - 2018-02-07 12:20:17 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:20:17 --> Model Class Initialized
INFO - 2018-02-07 12:20:17 --> Model Class Initialized
INFO - 2018-02-07 12:20:17 --> Helper loaded: inflector_helper
INFO - 2018-02-07 06:50:17 --> Config Class Initialized
INFO - 2018-02-07 06:50:17 --> Hooks Class Initialized
DEBUG - 2018-02-07 12:20:17 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-02-07 06:50:17 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:50:17 --> Utf8 Class Initialized
INFO - 2018-02-07 12:20:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 06:50:17 --> URI Class Initialized
INFO - 2018-02-07 12:20:17 --> Model Class Initialized
INFO - 2018-02-07 12:20:17 --> Model Class Initialized
INFO - 2018-02-07 12:20:17 --> Model Class Initialized
INFO - 2018-02-07 12:20:17 --> Final output sent to browser
DEBUG - 2018-02-07 12:20:17 --> Total execution time: 0.1205
INFO - 2018-02-07 12:20:17 --> Model Class Initialized
INFO - 2018-02-07 12:20:17 --> Model Class Initialized
INFO - 2018-02-07 06:50:17 --> Router Class Initialized
INFO - 2018-02-07 12:20:17 --> Database Driver Class Initialized
INFO - 2018-02-07 12:20:17 --> Model Class Initialized
INFO - 2018-02-07 12:20:17 --> Model Class Initialized
INFO - 2018-02-07 12:20:17 --> Model Class Initialized
INFO - 2018-02-07 12:20:17 --> Model Class Initialized
INFO - 2018-02-07 12:20:17 --> Model Class Initialized
INFO - 2018-02-07 06:50:17 --> Output Class Initialized
INFO - 2018-02-07 12:20:17 --> Model Class Initialized
INFO - 2018-02-07 12:20:17 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:20:17 --> Model Class Initialized
INFO - 2018-02-07 06:50:17 --> Security Class Initialized
DEBUG - 2018-02-07 06:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:50:17 --> Input Class Initialized
INFO - 2018-02-07 06:50:17 --> Language Class Initialized
DEBUG - 2018-02-07 12:20:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:20:17 --> Final output sent to browser
DEBUG - 2018-02-07 12:20:17 --> Total execution time: 0.1268
INFO - 2018-02-07 12:20:17 --> Helper loaded: form_helper
INFO - 2018-02-07 12:20:17 --> Form Validation Class Initialized
INFO - 2018-02-07 12:20:17 --> Controller Class Initialized
INFO - 2018-02-07 06:50:17 --> Language Class Initialized
INFO - 2018-02-07 06:50:17 --> Config Class Initialized
INFO - 2018-02-07 06:50:17 --> Loader Class Initialized
INFO - 2018-02-07 12:20:17 --> Model Class Initialized
INFO - 2018-02-07 12:20:17 --> Helper loaded: url_helper
INFO - 2018-02-07 12:20:17 --> Helper loaded: inflector_helper
INFO - 2018-02-07 12:20:17 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:20:17 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:20:17 --> Helper loaded: permission_helper
DEBUG - 2018-02-07 12:20:17 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:20:17 --> Helper loaded: users_helper
INFO - 2018-02-07 12:20:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:20:18 --> Model Class Initialized
INFO - 2018-02-07 12:20:18 --> Model Class Initialized
INFO - 2018-02-07 12:20:18 --> Model Class Initialized
INFO - 2018-02-07 12:20:18 --> Model Class Initialized
INFO - 2018-02-07 12:20:18 --> Model Class Initialized
INFO - 2018-02-07 12:20:18 --> Model Class Initialized
INFO - 2018-02-07 12:20:18 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:20:18 --> Model Class Initialized
INFO - 2018-02-07 12:20:18 --> Final output sent to browser
DEBUG - 2018-02-07 12:20:18 --> Total execution time: 0.1260
INFO - 2018-02-07 12:20:18 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:20:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:20:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:20:18 --> Helper loaded: form_helper
INFO - 2018-02-07 12:20:18 --> Form Validation Class Initialized
INFO - 2018-02-07 12:20:18 --> Controller Class Initialized
INFO - 2018-02-07 12:20:18 --> Model Class Initialized
INFO - 2018-02-07 12:20:18 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:20:18 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:20:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:20:18 --> Model Class Initialized
INFO - 2018-02-07 12:20:18 --> Model Class Initialized
INFO - 2018-02-07 12:20:18 --> Model Class Initialized
INFO - 2018-02-07 12:20:18 --> Model Class Initialized
INFO - 2018-02-07 12:20:18 --> Model Class Initialized
INFO - 2018-02-07 12:20:18 --> Model Class Initialized
INFO - 2018-02-07 12:20:18 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:20:18 --> Model Class Initialized
INFO - 2018-02-07 12:20:18 --> Final output sent to browser
DEBUG - 2018-02-07 12:20:18 --> Total execution time: 0.1139
INFO - 2018-02-07 06:50:20 --> Config Class Initialized
INFO - 2018-02-07 06:50:20 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:50:20 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:50:20 --> Utf8 Class Initialized
INFO - 2018-02-07 06:50:20 --> URI Class Initialized
INFO - 2018-02-07 06:50:20 --> Router Class Initialized
INFO - 2018-02-07 06:50:20 --> Config Class Initialized
INFO - 2018-02-07 06:50:20 --> Hooks Class Initialized
INFO - 2018-02-07 06:50:20 --> Output Class Initialized
DEBUG - 2018-02-07 06:50:20 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:50:20 --> Utf8 Class Initialized
INFO - 2018-02-07 06:50:20 --> Security Class Initialized
INFO - 2018-02-07 06:50:20 --> URI Class Initialized
DEBUG - 2018-02-07 06:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:50:20 --> Input Class Initialized
INFO - 2018-02-07 06:50:20 --> Language Class Initialized
INFO - 2018-02-07 06:50:20 --> Router Class Initialized
INFO - 2018-02-07 06:50:20 --> Output Class Initialized
INFO - 2018-02-07 06:50:20 --> Security Class Initialized
DEBUG - 2018-02-07 06:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:50:20 --> Input Class Initialized
INFO - 2018-02-07 06:50:20 --> Language Class Initialized
INFO - 2018-02-07 06:50:20 --> Language Class Initialized
INFO - 2018-02-07 06:50:20 --> Config Class Initialized
INFO - 2018-02-07 06:50:20 --> Loader Class Initialized
INFO - 2018-02-07 12:20:20 --> Helper loaded: url_helper
INFO - 2018-02-07 12:20:20 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:20:20 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:20:20 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:20:20 --> Helper loaded: users_helper
INFO - 2018-02-07 06:50:20 --> Language Class Initialized
INFO - 2018-02-07 06:50:20 --> Config Class Initialized
INFO - 2018-02-07 06:50:20 --> Loader Class Initialized
INFO - 2018-02-07 12:20:20 --> Helper loaded: url_helper
INFO - 2018-02-07 12:20:20 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:20:20 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:20:20 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:20:20 --> Helper loaded: users_helper
INFO - 2018-02-07 12:20:20 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:20:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:20:20 --> Database Driver Class Initialized
INFO - 2018-02-07 12:20:20 --> Helper loaded: form_helper
INFO - 2018-02-07 12:20:20 --> Form Validation Class Initialized
INFO - 2018-02-07 12:20:20 --> Controller Class Initialized
DEBUG - 2018-02-07 12:20:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:20:20 --> Helper loaded: form_helper
INFO - 2018-02-07 12:20:20 --> Form Validation Class Initialized
INFO - 2018-02-07 12:20:20 --> Controller Class Initialized
INFO - 2018-02-07 12:20:20 --> Model Class Initialized
INFO - 2018-02-07 12:20:20 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:20:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:20:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:20:20 --> Model Class Initialized
INFO - 2018-02-07 12:20:20 --> Model Class Initialized
INFO - 2018-02-07 12:20:20 --> Model Class Initialized
INFO - 2018-02-07 12:20:20 --> Model Class Initialized
INFO - 2018-02-07 12:20:20 --> Model Class Initialized
INFO - 2018-02-07 12:20:20 --> Model Class Initialized
INFO - 2018-02-07 12:20:20 --> Helper loaded: inflector_helper
INFO - 2018-02-07 12:20:20 --> Model Class Initialized
INFO - 2018-02-07 12:20:20 --> Model Class Initialized
INFO - 2018-02-07 12:20:20 --> Model Class Initialized
INFO - 2018-02-07 12:20:20 --> Model Class Initialized
INFO - 2018-02-07 12:20:20 --> Model Class Initialized
DEBUG - 2018-02-07 12:20:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:20:20 --> Model Class Initialized
INFO - 2018-02-07 12:20:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:20:20 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:20:20 --> Model Class Initialized
INFO - 2018-02-07 12:20:20 --> Model Class Initialized
INFO - 2018-02-07 12:20:20 --> Model Class Initialized
INFO - 2018-02-07 12:20:20 --> Model Class Initialized
INFO - 2018-02-07 12:20:20 --> Model Class Initialized
INFO - 2018-02-07 12:20:20 --> Model Class Initialized
INFO - 2018-02-07 12:20:20 --> Model Class Initialized
INFO - 2018-02-07 12:20:20 --> Model Class Initialized
INFO - 2018-02-07 12:20:20 --> Model Class Initialized
INFO - 2018-02-07 12:20:20 --> Model Class Initialized
INFO - 2018-02-07 12:20:20 --> Model Class Initialized
INFO - 2018-02-07 12:20:20 --> Model Class Initialized
INFO - 2018-02-07 12:20:20 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:20:20 --> Final output sent to browser
DEBUG - 2018-02-07 12:20:20 --> Total execution time: 0.1165
INFO - 2018-02-07 12:20:20 --> Final output sent to browser
DEBUG - 2018-02-07 12:20:20 --> Total execution time: 0.1112
INFO - 2018-02-07 06:50:24 --> Config Class Initialized
INFO - 2018-02-07 06:50:24 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:50:24 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:50:24 --> Utf8 Class Initialized
INFO - 2018-02-07 06:50:24 --> URI Class Initialized
INFO - 2018-02-07 06:50:24 --> Router Class Initialized
INFO - 2018-02-07 06:50:24 --> Output Class Initialized
INFO - 2018-02-07 06:50:24 --> Security Class Initialized
DEBUG - 2018-02-07 06:50:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:50:24 --> Input Class Initialized
INFO - 2018-02-07 06:50:24 --> Language Class Initialized
INFO - 2018-02-07 06:50:24 --> Language Class Initialized
INFO - 2018-02-07 06:50:24 --> Config Class Initialized
INFO - 2018-02-07 06:50:24 --> Loader Class Initialized
INFO - 2018-02-07 12:20:24 --> Helper loaded: url_helper
INFO - 2018-02-07 12:20:24 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:20:24 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:20:24 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:20:24 --> Helper loaded: users_helper
INFO - 2018-02-07 12:20:24 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:20:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:20:24 --> Helper loaded: form_helper
INFO - 2018-02-07 12:20:24 --> Form Validation Class Initialized
INFO - 2018-02-07 12:20:24 --> Controller Class Initialized
INFO - 2018-02-07 12:20:24 --> Model Class Initialized
INFO - 2018-02-07 12:20:24 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:20:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:20:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:20:24 --> Model Class Initialized
INFO - 2018-02-07 12:20:24 --> Model Class Initialized
INFO - 2018-02-07 12:20:24 --> Model Class Initialized
INFO - 2018-02-07 12:20:24 --> Model Class Initialized
INFO - 2018-02-07 12:20:24 --> Model Class Initialized
INFO - 2018-02-07 12:20:24 --> Model Class Initialized
INFO - 2018-02-07 12:20:24 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-02-07 12:20:24 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 771
ERROR - 2018-02-07 12:20:24 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 781
INFO - 2018-02-07 12:20:24 --> Final output sent to browser
DEBUG - 2018-02-07 12:20:24 --> Total execution time: 0.1078
INFO - 2018-02-07 06:50:25 --> Config Class Initialized
INFO - 2018-02-07 06:50:25 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:50:25 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:50:25 --> Utf8 Class Initialized
INFO - 2018-02-07 06:50:25 --> URI Class Initialized
INFO - 2018-02-07 06:50:25 --> Router Class Initialized
INFO - 2018-02-07 06:50:25 --> Output Class Initialized
INFO - 2018-02-07 06:50:25 --> Security Class Initialized
DEBUG - 2018-02-07 06:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:50:25 --> Input Class Initialized
INFO - 2018-02-07 06:50:25 --> Language Class Initialized
INFO - 2018-02-07 06:50:25 --> Language Class Initialized
INFO - 2018-02-07 06:50:25 --> Config Class Initialized
INFO - 2018-02-07 06:50:25 --> Loader Class Initialized
INFO - 2018-02-07 12:20:25 --> Helper loaded: url_helper
INFO - 2018-02-07 12:20:25 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:20:25 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:20:25 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:20:25 --> Helper loaded: users_helper
INFO - 2018-02-07 12:20:25 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:20:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:20:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:20:25 --> Helper loaded: form_helper
INFO - 2018-02-07 12:20:25 --> Form Validation Class Initialized
INFO - 2018-02-07 12:20:25 --> Controller Class Initialized
INFO - 2018-02-07 12:20:25 --> Model Class Initialized
INFO - 2018-02-07 12:20:25 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:20:25 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:20:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:20:25 --> Model Class Initialized
INFO - 2018-02-07 12:20:25 --> Model Class Initialized
INFO - 2018-02-07 12:20:25 --> Model Class Initialized
INFO - 2018-02-07 12:20:25 --> Model Class Initialized
INFO - 2018-02-07 12:20:25 --> Model Class Initialized
INFO - 2018-02-07 12:20:25 --> Model Class Initialized
INFO - 2018-02-07 12:20:25 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:20:25 --> Model Class Initialized
INFO - 2018-02-07 12:20:25 --> Model Class Initialized
INFO - 2018-02-07 12:20:25 --> Final output sent to browser
DEBUG - 2018-02-07 12:20:25 --> Total execution time: 0.1270
INFO - 2018-02-07 06:50:26 --> Config Class Initialized
INFO - 2018-02-07 06:50:26 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:50:26 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:50:26 --> Utf8 Class Initialized
INFO - 2018-02-07 06:50:26 --> URI Class Initialized
INFO - 2018-02-07 06:50:26 --> Router Class Initialized
INFO - 2018-02-07 06:50:26 --> Output Class Initialized
INFO - 2018-02-07 06:50:26 --> Security Class Initialized
DEBUG - 2018-02-07 06:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:50:26 --> Input Class Initialized
INFO - 2018-02-07 06:50:26 --> Language Class Initialized
INFO - 2018-02-07 06:50:26 --> Language Class Initialized
INFO - 2018-02-07 06:50:26 --> Config Class Initialized
INFO - 2018-02-07 06:50:26 --> Loader Class Initialized
INFO - 2018-02-07 12:20:26 --> Helper loaded: url_helper
INFO - 2018-02-07 12:20:26 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:20:26 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:20:26 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:20:26 --> Helper loaded: users_helper
INFO - 2018-02-07 12:20:26 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:20:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:20:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:20:26 --> Helper loaded: form_helper
INFO - 2018-02-07 12:20:26 --> Form Validation Class Initialized
INFO - 2018-02-07 12:20:26 --> Controller Class Initialized
INFO - 2018-02-07 12:20:26 --> Model Class Initialized
INFO - 2018-02-07 12:20:26 --> Helper loaded: inflector_helper
INFO - 2018-02-07 06:50:26 --> Config Class Initialized
INFO - 2018-02-07 06:50:26 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:50:26 --> UTF-8 Support Enabled
DEBUG - 2018-02-07 12:20:26 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 06:50:26 --> Utf8 Class Initialized
INFO - 2018-02-07 12:20:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 06:50:26 --> URI Class Initialized
INFO - 2018-02-07 12:20:26 --> Model Class Initialized
INFO - 2018-02-07 12:20:26 --> Model Class Initialized
INFO - 2018-02-07 12:20:26 --> Model Class Initialized
INFO - 2018-02-07 12:20:26 --> Model Class Initialized
INFO - 2018-02-07 12:20:26 --> Model Class Initialized
INFO - 2018-02-07 06:50:26 --> Router Class Initialized
INFO - 2018-02-07 12:20:26 --> Model Class Initialized
INFO - 2018-02-07 12:20:26 --> Model Class Initialized
INFO - 2018-02-07 12:20:26 --> Model Class Initialized
INFO - 2018-02-07 12:20:26 --> Model Class Initialized
INFO - 2018-02-07 12:20:26 --> Model Class Initialized
INFO - 2018-02-07 06:50:26 --> Output Class Initialized
INFO - 2018-02-07 12:20:26 --> Model Class Initialized
INFO - 2018-02-07 12:20:26 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:20:26 --> Model Class Initialized
INFO - 2018-02-07 06:50:26 --> Security Class Initialized
DEBUG - 2018-02-07 06:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:50:26 --> Input Class Initialized
INFO - 2018-02-07 06:50:26 --> Language Class Initialized
INFO - 2018-02-07 12:20:26 --> Final output sent to browser
DEBUG - 2018-02-07 12:20:26 --> Total execution time: 0.1252
INFO - 2018-02-07 06:50:26 --> Language Class Initialized
INFO - 2018-02-07 06:50:26 --> Config Class Initialized
INFO - 2018-02-07 06:50:26 --> Loader Class Initialized
INFO - 2018-02-07 12:20:26 --> Helper loaded: url_helper
INFO - 2018-02-07 12:20:26 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:20:26 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:20:26 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:20:26 --> Helper loaded: users_helper
INFO - 2018-02-07 12:20:26 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:20:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:20:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:20:26 --> Helper loaded: form_helper
INFO - 2018-02-07 12:20:26 --> Form Validation Class Initialized
INFO - 2018-02-07 12:20:26 --> Controller Class Initialized
INFO - 2018-02-07 12:20:26 --> Model Class Initialized
INFO - 2018-02-07 12:20:26 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:20:26 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:20:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:20:26 --> Model Class Initialized
INFO - 2018-02-07 12:20:26 --> Model Class Initialized
INFO - 2018-02-07 12:20:26 --> Model Class Initialized
INFO - 2018-02-07 12:20:26 --> Model Class Initialized
INFO - 2018-02-07 12:20:26 --> Model Class Initialized
INFO - 2018-02-07 12:20:26 --> Model Class Initialized
INFO - 2018-02-07 12:20:26 --> Model Class Initialized
INFO - 2018-02-07 12:20:26 --> Model Class Initialized
INFO - 2018-02-07 12:20:26 --> Model Class Initialized
INFO - 2018-02-07 12:20:26 --> Model Class Initialized
INFO - 2018-02-07 12:20:26 --> Model Class Initialized
INFO - 2018-02-07 12:20:26 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:20:26 --> Final output sent to browser
DEBUG - 2018-02-07 12:20:26 --> Total execution time: 0.1203
INFO - 2018-02-07 06:50:28 --> Config Class Initialized
INFO - 2018-02-07 06:50:28 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:50:28 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:50:28 --> Utf8 Class Initialized
INFO - 2018-02-07 06:50:28 --> URI Class Initialized
INFO - 2018-02-07 06:50:28 --> Router Class Initialized
INFO - 2018-02-07 06:50:28 --> Output Class Initialized
INFO - 2018-02-07 06:50:28 --> Security Class Initialized
DEBUG - 2018-02-07 06:50:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:50:28 --> Input Class Initialized
INFO - 2018-02-07 06:50:28 --> Language Class Initialized
INFO - 2018-02-07 06:50:28 --> Language Class Initialized
INFO - 2018-02-07 06:50:28 --> Config Class Initialized
INFO - 2018-02-07 06:50:28 --> Loader Class Initialized
INFO - 2018-02-07 12:20:28 --> Helper loaded: url_helper
INFO - 2018-02-07 12:20:28 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:20:28 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:20:28 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:20:28 --> Helper loaded: users_helper
INFO - 2018-02-07 12:20:28 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:20:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:20:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:20:28 --> Helper loaded: form_helper
INFO - 2018-02-07 12:20:28 --> Form Validation Class Initialized
INFO - 2018-02-07 12:20:28 --> Controller Class Initialized
INFO - 2018-02-07 12:20:28 --> Model Class Initialized
INFO - 2018-02-07 12:20:28 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:20:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:20:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:20:28 --> Model Class Initialized
INFO - 2018-02-07 12:20:28 --> Model Class Initialized
INFO - 2018-02-07 12:20:28 --> Model Class Initialized
INFO - 2018-02-07 12:20:28 --> Model Class Initialized
INFO - 2018-02-07 12:20:28 --> Final output sent to browser
DEBUG - 2018-02-07 12:20:28 --> Total execution time: 0.0851
INFO - 2018-02-07 06:50:28 --> Config Class Initialized
INFO - 2018-02-07 06:50:28 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:50:28 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:50:28 --> Utf8 Class Initialized
INFO - 2018-02-07 06:50:28 --> URI Class Initialized
INFO - 2018-02-07 06:50:28 --> Router Class Initialized
INFO - 2018-02-07 06:50:28 --> Output Class Initialized
INFO - 2018-02-07 06:50:28 --> Security Class Initialized
DEBUG - 2018-02-07 06:50:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:50:28 --> Input Class Initialized
INFO - 2018-02-07 06:50:28 --> Language Class Initialized
INFO - 2018-02-07 06:50:28 --> Language Class Initialized
INFO - 2018-02-07 06:50:28 --> Config Class Initialized
INFO - 2018-02-07 06:50:28 --> Loader Class Initialized
INFO - 2018-02-07 12:20:28 --> Helper loaded: url_helper
INFO - 2018-02-07 12:20:28 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:20:28 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:20:28 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:20:28 --> Helper loaded: users_helper
INFO - 2018-02-07 12:20:28 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:20:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:20:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:20:28 --> Helper loaded: form_helper
INFO - 2018-02-07 12:20:28 --> Form Validation Class Initialized
INFO - 2018-02-07 12:20:28 --> Controller Class Initialized
INFO - 2018-02-07 12:20:28 --> Model Class Initialized
INFO - 2018-02-07 12:20:28 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:20:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:20:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:20:28 --> Model Class Initialized
INFO - 2018-02-07 12:20:28 --> Model Class Initialized
INFO - 2018-02-07 12:20:28 --> Model Class Initialized
INFO - 2018-02-07 12:20:28 --> Model Class Initialized
INFO - 2018-02-07 12:20:28 --> Final output sent to browser
DEBUG - 2018-02-07 12:20:28 --> Total execution time: 0.0969
INFO - 2018-02-07 06:50:34 --> Config Class Initialized
INFO - 2018-02-07 06:50:34 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:50:34 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:50:34 --> Utf8 Class Initialized
INFO - 2018-02-07 06:50:34 --> URI Class Initialized
INFO - 2018-02-07 06:50:34 --> Router Class Initialized
INFO - 2018-02-07 06:50:34 --> Output Class Initialized
INFO - 2018-02-07 06:50:34 --> Security Class Initialized
DEBUG - 2018-02-07 06:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:50:34 --> Input Class Initialized
INFO - 2018-02-07 06:50:34 --> Language Class Initialized
INFO - 2018-02-07 06:50:34 --> Language Class Initialized
INFO - 2018-02-07 06:50:34 --> Config Class Initialized
INFO - 2018-02-07 06:50:34 --> Loader Class Initialized
INFO - 2018-02-07 12:20:34 --> Helper loaded: url_helper
INFO - 2018-02-07 12:20:34 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:20:34 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:20:34 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:20:34 --> Helper loaded: users_helper
INFO - 2018-02-07 12:20:34 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:20:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:20:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:20:34 --> Helper loaded: form_helper
INFO - 2018-02-07 12:20:34 --> Form Validation Class Initialized
INFO - 2018-02-07 12:20:34 --> Controller Class Initialized
INFO - 2018-02-07 12:20:34 --> Model Class Initialized
INFO - 2018-02-07 12:20:34 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:20:34 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:20:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:20:34 --> Model Class Initialized
INFO - 2018-02-07 12:20:34 --> Model Class Initialized
INFO - 2018-02-07 12:20:34 --> Model Class Initialized
INFO - 2018-02-07 12:20:34 --> Model Class Initialized
INFO - 2018-02-07 12:20:34 --> Model Class Initialized
INFO - 2018-02-07 12:20:34 --> Model Class Initialized
INFO - 2018-02-07 12:20:34 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-02-07 12:20:34 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 771
INFO - 2018-02-07 12:20:34 --> Final output sent to browser
DEBUG - 2018-02-07 12:20:34 --> Total execution time: 0.0963
INFO - 2018-02-07 06:50:37 --> Config Class Initialized
INFO - 2018-02-07 06:50:37 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:50:37 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:50:37 --> Utf8 Class Initialized
INFO - 2018-02-07 06:50:37 --> URI Class Initialized
INFO - 2018-02-07 06:50:37 --> Router Class Initialized
INFO - 2018-02-07 06:50:37 --> Output Class Initialized
INFO - 2018-02-07 06:50:37 --> Security Class Initialized
DEBUG - 2018-02-07 06:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:50:37 --> Input Class Initialized
INFO - 2018-02-07 06:50:37 --> Language Class Initialized
INFO - 2018-02-07 06:50:37 --> Language Class Initialized
INFO - 2018-02-07 06:50:37 --> Config Class Initialized
INFO - 2018-02-07 06:50:37 --> Loader Class Initialized
INFO - 2018-02-07 12:20:37 --> Helper loaded: url_helper
INFO - 2018-02-07 12:20:37 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:20:37 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:20:37 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:20:37 --> Helper loaded: users_helper
INFO - 2018-02-07 12:20:37 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:20:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:20:37 --> Helper loaded: form_helper
INFO - 2018-02-07 12:20:37 --> Form Validation Class Initialized
INFO - 2018-02-07 12:20:37 --> Controller Class Initialized
INFO - 2018-02-07 12:20:37 --> Model Class Initialized
INFO - 2018-02-07 12:20:37 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:20:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:20:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:20:37 --> Model Class Initialized
INFO - 2018-02-07 12:20:37 --> Model Class Initialized
INFO - 2018-02-07 12:20:37 --> Model Class Initialized
INFO - 2018-02-07 12:20:37 --> Model Class Initialized
INFO - 2018-02-07 12:20:37 --> Final output sent to browser
DEBUG - 2018-02-07 12:20:37 --> Total execution time: 0.0823
INFO - 2018-02-07 06:50:37 --> Config Class Initialized
INFO - 2018-02-07 06:50:37 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:50:37 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:50:37 --> Utf8 Class Initialized
INFO - 2018-02-07 06:50:37 --> URI Class Initialized
INFO - 2018-02-07 06:50:37 --> Router Class Initialized
INFO - 2018-02-07 06:50:37 --> Output Class Initialized
INFO - 2018-02-07 06:50:37 --> Security Class Initialized
DEBUG - 2018-02-07 06:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:50:37 --> Input Class Initialized
INFO - 2018-02-07 06:50:37 --> Language Class Initialized
INFO - 2018-02-07 06:50:37 --> Language Class Initialized
INFO - 2018-02-07 06:50:37 --> Config Class Initialized
INFO - 2018-02-07 06:50:37 --> Loader Class Initialized
INFO - 2018-02-07 12:20:37 --> Helper loaded: url_helper
INFO - 2018-02-07 12:20:37 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:20:37 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:20:37 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:20:37 --> Helper loaded: users_helper
INFO - 2018-02-07 12:20:37 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:20:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:20:37 --> Helper loaded: form_helper
INFO - 2018-02-07 12:20:37 --> Form Validation Class Initialized
INFO - 2018-02-07 12:20:37 --> Controller Class Initialized
INFO - 2018-02-07 12:20:37 --> Model Class Initialized
INFO - 2018-02-07 12:20:37 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:20:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:20:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:20:37 --> Model Class Initialized
INFO - 2018-02-07 12:20:37 --> Model Class Initialized
INFO - 2018-02-07 12:20:37 --> Model Class Initialized
INFO - 2018-02-07 12:20:37 --> Model Class Initialized
INFO - 2018-02-07 12:20:37 --> Final output sent to browser
DEBUG - 2018-02-07 12:20:37 --> Total execution time: 0.1203
INFO - 2018-02-07 06:50:40 --> Config Class Initialized
INFO - 2018-02-07 06:50:40 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:50:40 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:50:40 --> Utf8 Class Initialized
INFO - 2018-02-07 06:50:40 --> URI Class Initialized
INFO - 2018-02-07 06:50:40 --> Router Class Initialized
INFO - 2018-02-07 06:50:40 --> Output Class Initialized
INFO - 2018-02-07 06:50:40 --> Security Class Initialized
DEBUG - 2018-02-07 06:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:50:40 --> Input Class Initialized
INFO - 2018-02-07 06:50:40 --> Language Class Initialized
INFO - 2018-02-07 06:50:40 --> Language Class Initialized
INFO - 2018-02-07 06:50:40 --> Config Class Initialized
INFO - 2018-02-07 06:50:40 --> Loader Class Initialized
INFO - 2018-02-07 12:20:40 --> Helper loaded: url_helper
INFO - 2018-02-07 12:20:40 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:20:40 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:20:40 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:20:40 --> Helper loaded: users_helper
INFO - 2018-02-07 12:20:40 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:20:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:20:40 --> Helper loaded: form_helper
INFO - 2018-02-07 12:20:40 --> Form Validation Class Initialized
INFO - 2018-02-07 12:20:40 --> Controller Class Initialized
INFO - 2018-02-07 12:20:40 --> Model Class Initialized
INFO - 2018-02-07 12:20:40 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:20:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:20:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:20:40 --> Model Class Initialized
INFO - 2018-02-07 12:20:40 --> Model Class Initialized
INFO - 2018-02-07 12:20:40 --> Model Class Initialized
INFO - 2018-02-07 12:20:40 --> Model Class Initialized
INFO - 2018-02-07 12:20:40 --> Model Class Initialized
INFO - 2018-02-07 12:20:40 --> Model Class Initialized
INFO - 2018-02-07 12:20:40 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-02-07 12:20:40 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 771
INFO - 2018-02-07 12:20:40 --> Final output sent to browser
DEBUG - 2018-02-07 12:20:40 --> Total execution time: 0.1255
INFO - 2018-02-07 06:50:43 --> Config Class Initialized
INFO - 2018-02-07 06:50:43 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:50:43 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:50:43 --> Utf8 Class Initialized
INFO - 2018-02-07 06:50:43 --> URI Class Initialized
INFO - 2018-02-07 06:50:43 --> Router Class Initialized
INFO - 2018-02-07 06:50:43 --> Output Class Initialized
INFO - 2018-02-07 06:50:43 --> Security Class Initialized
DEBUG - 2018-02-07 06:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:50:43 --> Input Class Initialized
INFO - 2018-02-07 06:50:43 --> Language Class Initialized
INFO - 2018-02-07 06:50:43 --> Language Class Initialized
INFO - 2018-02-07 06:50:43 --> Config Class Initialized
INFO - 2018-02-07 06:50:43 --> Loader Class Initialized
INFO - 2018-02-07 12:20:43 --> Helper loaded: url_helper
INFO - 2018-02-07 12:20:43 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:20:43 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:20:43 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:20:43 --> Helper loaded: users_helper
INFO - 2018-02-07 12:20:43 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:20:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:20:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:20:43 --> Helper loaded: form_helper
INFO - 2018-02-07 12:20:43 --> Form Validation Class Initialized
INFO - 2018-02-07 12:20:43 --> Controller Class Initialized
INFO - 2018-02-07 12:20:43 --> Model Class Initialized
INFO - 2018-02-07 12:20:43 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:20:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:20:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:20:43 --> Model Class Initialized
INFO - 2018-02-07 12:20:43 --> Model Class Initialized
INFO - 2018-02-07 12:20:43 --> Model Class Initialized
INFO - 2018-02-07 12:20:43 --> Model Class Initialized
INFO - 2018-02-07 12:20:43 --> Final output sent to browser
DEBUG - 2018-02-07 12:20:43 --> Total execution time: 0.1086
INFO - 2018-02-07 06:50:43 --> Config Class Initialized
INFO - 2018-02-07 06:50:43 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:50:43 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:50:43 --> Utf8 Class Initialized
INFO - 2018-02-07 06:50:43 --> URI Class Initialized
INFO - 2018-02-07 06:50:43 --> Router Class Initialized
INFO - 2018-02-07 06:50:43 --> Output Class Initialized
INFO - 2018-02-07 06:50:43 --> Security Class Initialized
DEBUG - 2018-02-07 06:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:50:43 --> Input Class Initialized
INFO - 2018-02-07 06:50:43 --> Language Class Initialized
INFO - 2018-02-07 06:50:43 --> Language Class Initialized
INFO - 2018-02-07 06:50:43 --> Config Class Initialized
INFO - 2018-02-07 06:50:43 --> Loader Class Initialized
INFO - 2018-02-07 12:20:43 --> Helper loaded: url_helper
INFO - 2018-02-07 12:20:43 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:20:43 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:20:43 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:20:43 --> Helper loaded: users_helper
INFO - 2018-02-07 12:20:43 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:20:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:20:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:20:43 --> Helper loaded: form_helper
INFO - 2018-02-07 12:20:43 --> Form Validation Class Initialized
INFO - 2018-02-07 12:20:43 --> Controller Class Initialized
INFO - 2018-02-07 12:20:43 --> Model Class Initialized
INFO - 2018-02-07 12:20:43 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:20:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:20:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:20:43 --> Model Class Initialized
INFO - 2018-02-07 12:20:43 --> Model Class Initialized
INFO - 2018-02-07 12:20:43 --> Model Class Initialized
INFO - 2018-02-07 12:20:43 --> Model Class Initialized
INFO - 2018-02-07 12:20:43 --> Final output sent to browser
DEBUG - 2018-02-07 12:20:43 --> Total execution time: 0.1160
INFO - 2018-02-07 06:50:46 --> Config Class Initialized
INFO - 2018-02-07 06:50:46 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:50:46 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:50:46 --> Utf8 Class Initialized
INFO - 2018-02-07 06:50:46 --> Config Class Initialized
INFO - 2018-02-07 06:50:46 --> Hooks Class Initialized
INFO - 2018-02-07 06:50:46 --> URI Class Initialized
DEBUG - 2018-02-07 06:50:46 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:50:46 --> Utf8 Class Initialized
INFO - 2018-02-07 06:50:46 --> Router Class Initialized
INFO - 2018-02-07 06:50:46 --> URI Class Initialized
INFO - 2018-02-07 06:50:46 --> Output Class Initialized
INFO - 2018-02-07 06:50:46 --> Router Class Initialized
INFO - 2018-02-07 06:50:46 --> Security Class Initialized
DEBUG - 2018-02-07 06:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:50:46 --> Input Class Initialized
INFO - 2018-02-07 06:50:46 --> Output Class Initialized
INFO - 2018-02-07 06:50:46 --> Language Class Initialized
INFO - 2018-02-07 06:50:46 --> Security Class Initialized
DEBUG - 2018-02-07 06:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:50:46 --> Input Class Initialized
INFO - 2018-02-07 06:50:46 --> Language Class Initialized
INFO - 2018-02-07 06:50:46 --> Language Class Initialized
INFO - 2018-02-07 06:50:46 --> Config Class Initialized
INFO - 2018-02-07 06:50:46 --> Loader Class Initialized
INFO - 2018-02-07 12:20:46 --> Helper loaded: url_helper
INFO - 2018-02-07 12:20:46 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:20:46 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:20:46 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:20:46 --> Helper loaded: users_helper
INFO - 2018-02-07 06:50:46 --> Language Class Initialized
INFO - 2018-02-07 06:50:46 --> Config Class Initialized
INFO - 2018-02-07 06:50:46 --> Loader Class Initialized
INFO - 2018-02-07 12:20:46 --> Helper loaded: url_helper
INFO - 2018-02-07 12:20:46 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:20:46 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:20:46 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:20:46 --> Helper loaded: users_helper
INFO - 2018-02-07 12:20:46 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:20:46 --> Helper loaded: form_helper
INFO - 2018-02-07 12:20:46 --> Form Validation Class Initialized
INFO - 2018-02-07 12:20:46 --> Controller Class Initialized
INFO - 2018-02-07 12:20:46 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:20:46 --> Model Class Initialized
INFO - 2018-02-07 12:20:46 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:20:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:20:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:20:46 --> Model Class Initialized
INFO - 2018-02-07 12:20:46 --> Model Class Initialized
INFO - 2018-02-07 12:20:46 --> Model Class Initialized
INFO - 2018-02-07 12:20:46 --> Model Class Initialized
INFO - 2018-02-07 12:20:46 --> Model Class Initialized
INFO - 2018-02-07 12:20:46 --> Model Class Initialized
INFO - 2018-02-07 12:20:46 --> Model Class Initialized
INFO - 2018-02-07 12:20:46 --> Model Class Initialized
INFO - 2018-02-07 12:20:46 --> Model Class Initialized
INFO - 2018-02-07 12:20:46 --> Helper loaded: form_helper
INFO - 2018-02-07 12:20:46 --> Form Validation Class Initialized
INFO - 2018-02-07 12:20:46 --> Model Class Initialized
INFO - 2018-02-07 12:20:46 --> Controller Class Initialized
INFO - 2018-02-07 12:20:46 --> Model Class Initialized
INFO - 2018-02-07 12:20:46 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:20:46 --> Model Class Initialized
INFO - 2018-02-07 12:20:46 --> Model Class Initialized
INFO - 2018-02-07 12:20:46 --> Helper loaded: inflector_helper
INFO - 2018-02-07 12:20:46 --> Final output sent to browser
DEBUG - 2018-02-07 12:20:46 --> Total execution time: 0.1168
DEBUG - 2018-02-07 12:20:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:20:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:20:46 --> Model Class Initialized
INFO - 2018-02-07 12:20:46 --> Model Class Initialized
INFO - 2018-02-07 12:20:46 --> Model Class Initialized
INFO - 2018-02-07 12:20:46 --> Model Class Initialized
INFO - 2018-02-07 12:20:46 --> Model Class Initialized
INFO - 2018-02-07 12:20:46 --> Model Class Initialized
INFO - 2018-02-07 12:20:46 --> Model Class Initialized
INFO - 2018-02-07 12:20:46 --> Model Class Initialized
INFO - 2018-02-07 12:20:46 --> Model Class Initialized
INFO - 2018-02-07 12:20:46 --> Model Class Initialized
INFO - 2018-02-07 12:20:46 --> Model Class Initialized
INFO - 2018-02-07 12:20:46 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:20:46 --> Final output sent to browser
DEBUG - 2018-02-07 12:20:46 --> Total execution time: 0.1356
INFO - 2018-02-07 06:50:47 --> Config Class Initialized
INFO - 2018-02-07 06:50:47 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:50:47 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:50:47 --> Utf8 Class Initialized
INFO - 2018-02-07 06:50:47 --> URI Class Initialized
INFO - 2018-02-07 06:50:47 --> Router Class Initialized
INFO - 2018-02-07 06:50:47 --> Output Class Initialized
INFO - 2018-02-07 06:50:47 --> Security Class Initialized
DEBUG - 2018-02-07 06:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:50:47 --> Input Class Initialized
INFO - 2018-02-07 06:50:47 --> Language Class Initialized
INFO - 2018-02-07 06:50:47 --> Language Class Initialized
INFO - 2018-02-07 06:50:47 --> Config Class Initialized
INFO - 2018-02-07 06:50:47 --> Loader Class Initialized
INFO - 2018-02-07 12:20:47 --> Helper loaded: url_helper
INFO - 2018-02-07 12:20:47 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:20:47 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:20:47 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:20:47 --> Helper loaded: users_helper
INFO - 2018-02-07 12:20:47 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:20:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:20:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:20:47 --> Helper loaded: form_helper
INFO - 2018-02-07 12:20:47 --> Form Validation Class Initialized
INFO - 2018-02-07 12:20:47 --> Controller Class Initialized
INFO - 2018-02-07 12:20:48 --> Model Class Initialized
INFO - 2018-02-07 12:20:48 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:20:48 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:20:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:20:48 --> Model Class Initialized
INFO - 2018-02-07 12:20:48 --> Model Class Initialized
INFO - 2018-02-07 12:20:48 --> Model Class Initialized
INFO - 2018-02-07 12:20:48 --> Model Class Initialized
INFO - 2018-02-07 12:20:48 --> Model Class Initialized
INFO - 2018-02-07 12:20:48 --> Model Class Initialized
INFO - 2018-02-07 12:20:48 --> Model Class Initialized
INFO - 2018-02-07 12:20:48 --> Model Class Initialized
INFO - 2018-02-07 12:20:48 --> Model Class Initialized
INFO - 2018-02-07 12:20:48 --> Model Class Initialized
INFO - 2018-02-07 12:20:48 --> Model Class Initialized
INFO - 2018-02-07 12:20:48 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:20:48 --> Final output sent to browser
DEBUG - 2018-02-07 12:20:48 --> Total execution time: 0.1397
INFO - 2018-02-07 06:50:49 --> Config Class Initialized
INFO - 2018-02-07 06:50:49 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:50:49 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:50:49 --> Utf8 Class Initialized
INFO - 2018-02-07 06:50:49 --> URI Class Initialized
INFO - 2018-02-07 06:50:49 --> Router Class Initialized
INFO - 2018-02-07 06:50:49 --> Output Class Initialized
INFO - 2018-02-07 06:50:49 --> Security Class Initialized
DEBUG - 2018-02-07 06:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:50:49 --> Input Class Initialized
INFO - 2018-02-07 06:50:49 --> Language Class Initialized
INFO - 2018-02-07 06:50:49 --> Language Class Initialized
INFO - 2018-02-07 06:50:49 --> Config Class Initialized
INFO - 2018-02-07 06:50:49 --> Loader Class Initialized
INFO - 2018-02-07 12:20:49 --> Helper loaded: url_helper
INFO - 2018-02-07 12:20:49 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:20:49 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:20:49 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:20:49 --> Helper loaded: users_helper
INFO - 2018-02-07 12:20:49 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:20:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:20:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:20:49 --> Helper loaded: form_helper
INFO - 2018-02-07 12:20:49 --> Form Validation Class Initialized
INFO - 2018-02-07 12:20:49 --> Controller Class Initialized
INFO - 2018-02-07 12:20:49 --> Model Class Initialized
INFO - 2018-02-07 12:20:49 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:20:49 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:20:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:20:49 --> Model Class Initialized
INFO - 2018-02-07 12:20:49 --> Model Class Initialized
INFO - 2018-02-07 12:20:49 --> Model Class Initialized
INFO - 2018-02-07 12:20:49 --> Model Class Initialized
INFO - 2018-02-07 12:20:49 --> Model Class Initialized
INFO - 2018-02-07 12:20:49 --> Model Class Initialized
INFO - 2018-02-07 12:20:49 --> Model Class Initialized
INFO - 2018-02-07 12:20:49 --> Model Class Initialized
INFO - 2018-02-07 12:20:49 --> Model Class Initialized
INFO - 2018-02-07 12:20:49 --> Model Class Initialized
INFO - 2018-02-07 12:20:49 --> Model Class Initialized
INFO - 2018-02-07 12:20:49 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:20:49 --> Model Class Initialized
INFO - 2018-02-07 12:20:49 --> Final output sent to browser
DEBUG - 2018-02-07 12:20:49 --> Total execution time: 0.1326
INFO - 2018-02-07 06:50:50 --> Config Class Initialized
INFO - 2018-02-07 06:50:50 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:50:50 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:50:50 --> Utf8 Class Initialized
INFO - 2018-02-07 06:50:50 --> URI Class Initialized
INFO - 2018-02-07 06:50:50 --> Router Class Initialized
INFO - 2018-02-07 06:50:50 --> Output Class Initialized
INFO - 2018-02-07 06:50:50 --> Security Class Initialized
DEBUG - 2018-02-07 06:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:50:50 --> Input Class Initialized
INFO - 2018-02-07 06:50:50 --> Language Class Initialized
INFO - 2018-02-07 06:50:50 --> Language Class Initialized
INFO - 2018-02-07 06:50:50 --> Config Class Initialized
INFO - 2018-02-07 06:50:50 --> Loader Class Initialized
INFO - 2018-02-07 12:20:50 --> Helper loaded: url_helper
INFO - 2018-02-07 12:20:50 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:20:50 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:20:50 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:20:50 --> Helper loaded: users_helper
INFO - 2018-02-07 12:20:50 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:20:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:20:50 --> Helper loaded: form_helper
INFO - 2018-02-07 12:20:50 --> Form Validation Class Initialized
INFO - 2018-02-07 12:20:50 --> Controller Class Initialized
INFO - 2018-02-07 12:20:50 --> Model Class Initialized
INFO - 2018-02-07 12:20:50 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:20:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:20:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:20:50 --> Model Class Initialized
INFO - 2018-02-07 12:20:50 --> Model Class Initialized
INFO - 2018-02-07 12:20:50 --> Model Class Initialized
INFO - 2018-02-07 12:20:50 --> Model Class Initialized
INFO - 2018-02-07 12:20:50 --> Model Class Initialized
INFO - 2018-02-07 12:20:50 --> Model Class Initialized
INFO - 2018-02-07 12:20:50 --> Model Class Initialized
INFO - 2018-02-07 12:20:50 --> Model Class Initialized
INFO - 2018-02-07 12:20:50 --> Model Class Initialized
INFO - 2018-02-07 12:20:50 --> Model Class Initialized
INFO - 2018-02-07 12:20:50 --> Model Class Initialized
INFO - 2018-02-07 12:20:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:20:50 --> Final output sent to browser
DEBUG - 2018-02-07 12:20:50 --> Total execution time: 0.1322
INFO - 2018-02-07 06:50:53 --> Config Class Initialized
INFO - 2018-02-07 06:50:53 --> Hooks Class Initialized
INFO - 2018-02-07 06:50:53 --> Config Class Initialized
INFO - 2018-02-07 06:50:53 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:50:53 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:50:53 --> Utf8 Class Initialized
DEBUG - 2018-02-07 06:50:53 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:50:53 --> Utf8 Class Initialized
INFO - 2018-02-07 06:50:53 --> URI Class Initialized
INFO - 2018-02-07 06:50:53 --> URI Class Initialized
INFO - 2018-02-07 06:50:53 --> Router Class Initialized
INFO - 2018-02-07 06:50:53 --> Router Class Initialized
INFO - 2018-02-07 06:50:53 --> Output Class Initialized
INFO - 2018-02-07 06:50:53 --> Output Class Initialized
INFO - 2018-02-07 06:50:53 --> Security Class Initialized
INFO - 2018-02-07 06:50:53 --> Security Class Initialized
DEBUG - 2018-02-07 06:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:50:53 --> Input Class Initialized
INFO - 2018-02-07 06:50:53 --> Language Class Initialized
DEBUG - 2018-02-07 06:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:50:53 --> Input Class Initialized
INFO - 2018-02-07 06:50:53 --> Language Class Initialized
INFO - 2018-02-07 06:50:53 --> Language Class Initialized
INFO - 2018-02-07 06:50:53 --> Config Class Initialized
INFO - 2018-02-07 06:50:53 --> Loader Class Initialized
INFO - 2018-02-07 12:20:53 --> Helper loaded: url_helper
INFO - 2018-02-07 12:20:53 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:20:53 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:20:53 --> Helper loaded: permission_helper
INFO - 2018-02-07 06:50:53 --> Language Class Initialized
INFO - 2018-02-07 06:50:53 --> Config Class Initialized
INFO - 2018-02-07 06:50:53 --> Loader Class Initialized
INFO - 2018-02-07 12:20:53 --> Helper loaded: users_helper
INFO - 2018-02-07 12:20:53 --> Helper loaded: url_helper
INFO - 2018-02-07 12:20:53 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:20:53 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:20:53 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:20:53 --> Helper loaded: users_helper
INFO - 2018-02-07 12:20:53 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:20:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:20:53 --> Database Driver Class Initialized
INFO - 2018-02-07 12:20:53 --> Helper loaded: form_helper
INFO - 2018-02-07 12:20:53 --> Form Validation Class Initialized
INFO - 2018-02-07 12:20:53 --> Controller Class Initialized
DEBUG - 2018-02-07 12:20:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:20:53 --> Model Class Initialized
INFO - 2018-02-07 12:20:53 --> Helper loaded: inflector_helper
INFO - 2018-02-07 12:20:53 --> Helper loaded: form_helper
INFO - 2018-02-07 12:20:53 --> Form Validation Class Initialized
INFO - 2018-02-07 12:20:53 --> Controller Class Initialized
DEBUG - 2018-02-07 12:20:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:20:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:20:53 --> Model Class Initialized
INFO - 2018-02-07 12:20:53 --> Model Class Initialized
INFO - 2018-02-07 12:20:53 --> Model Class Initialized
INFO - 2018-02-07 12:20:53 --> Model Class Initialized
INFO - 2018-02-07 12:20:53 --> Model Class Initialized
INFO - 2018-02-07 12:20:53 --> Model Class Initialized
INFO - 2018-02-07 12:20:53 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:20:53 --> Final output sent to browser
DEBUG - 2018-02-07 12:20:53 --> Total execution time: 0.1048
INFO - 2018-02-07 12:20:53 --> Model Class Initialized
INFO - 2018-02-07 12:20:53 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:20:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:20:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:20:53 --> Model Class Initialized
INFO - 2018-02-07 12:20:53 --> Model Class Initialized
INFO - 2018-02-07 12:20:53 --> Model Class Initialized
INFO - 2018-02-07 12:20:53 --> Model Class Initialized
INFO - 2018-02-07 12:20:53 --> Model Class Initialized
INFO - 2018-02-07 12:20:53 --> Model Class Initialized
INFO - 2018-02-07 12:20:53 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:20:53 --> Final output sent to browser
DEBUG - 2018-02-07 12:20:53 --> Total execution time: 0.1221
INFO - 2018-02-07 06:50:54 --> Config Class Initialized
INFO - 2018-02-07 06:50:54 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:50:54 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:50:54 --> Utf8 Class Initialized
INFO - 2018-02-07 06:50:54 --> URI Class Initialized
INFO - 2018-02-07 06:50:54 --> Router Class Initialized
INFO - 2018-02-07 06:50:54 --> Output Class Initialized
INFO - 2018-02-07 06:50:54 --> Security Class Initialized
DEBUG - 2018-02-07 06:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:50:54 --> Input Class Initialized
INFO - 2018-02-07 06:50:54 --> Language Class Initialized
INFO - 2018-02-07 06:50:54 --> Language Class Initialized
INFO - 2018-02-07 06:50:54 --> Config Class Initialized
INFO - 2018-02-07 06:50:54 --> Loader Class Initialized
INFO - 2018-02-07 12:20:54 --> Helper loaded: url_helper
INFO - 2018-02-07 12:20:54 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:20:54 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:20:54 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:20:54 --> Helper loaded: users_helper
INFO - 2018-02-07 12:20:54 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:20:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:20:54 --> Helper loaded: form_helper
INFO - 2018-02-07 12:20:54 --> Form Validation Class Initialized
INFO - 2018-02-07 12:20:54 --> Controller Class Initialized
INFO - 2018-02-07 12:20:54 --> Model Class Initialized
INFO - 2018-02-07 12:20:54 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:20:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:20:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:20:54 --> Model Class Initialized
INFO - 2018-02-07 12:20:54 --> Model Class Initialized
INFO - 2018-02-07 12:20:54 --> Model Class Initialized
INFO - 2018-02-07 12:20:54 --> Model Class Initialized
INFO - 2018-02-07 12:20:54 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:20:54 --> Final output sent to browser
DEBUG - 2018-02-07 12:20:54 --> Total execution time: 0.0882
INFO - 2018-02-07 06:50:55 --> Config Class Initialized
INFO - 2018-02-07 06:50:55 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:50:55 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:50:55 --> Utf8 Class Initialized
INFO - 2018-02-07 06:50:55 --> URI Class Initialized
INFO - 2018-02-07 06:50:55 --> Router Class Initialized
INFO - 2018-02-07 06:50:55 --> Output Class Initialized
INFO - 2018-02-07 06:50:55 --> Security Class Initialized
DEBUG - 2018-02-07 06:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:50:55 --> Input Class Initialized
INFO - 2018-02-07 06:50:55 --> Language Class Initialized
INFO - 2018-02-07 06:50:55 --> Config Class Initialized
INFO - 2018-02-07 06:50:55 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:50:55 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:50:55 --> Utf8 Class Initialized
INFO - 2018-02-07 06:50:55 --> URI Class Initialized
INFO - 2018-02-07 06:50:55 --> Language Class Initialized
INFO - 2018-02-07 06:50:55 --> Config Class Initialized
INFO - 2018-02-07 06:50:55 --> Loader Class Initialized
INFO - 2018-02-07 06:50:55 --> Router Class Initialized
INFO - 2018-02-07 12:20:55 --> Helper loaded: url_helper
INFO - 2018-02-07 12:20:55 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:20:55 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:20:55 --> Helper loaded: permission_helper
INFO - 2018-02-07 06:50:55 --> Output Class Initialized
INFO - 2018-02-07 12:20:55 --> Helper loaded: users_helper
INFO - 2018-02-07 06:50:55 --> Security Class Initialized
DEBUG - 2018-02-07 06:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:50:55 --> Input Class Initialized
INFO - 2018-02-07 06:50:55 --> Language Class Initialized
INFO - 2018-02-07 12:20:55 --> Database Driver Class Initialized
INFO - 2018-02-07 06:50:55 --> Config Class Initialized
INFO - 2018-02-07 06:50:55 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:50:55 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:50:55 --> Utf8 Class Initialized
INFO - 2018-02-07 06:50:55 --> URI Class Initialized
DEBUG - 2018-02-07 12:20:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:20:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 06:50:55 --> Router Class Initialized
INFO - 2018-02-07 06:50:55 --> Language Class Initialized
INFO - 2018-02-07 06:50:55 --> Config Class Initialized
INFO - 2018-02-07 06:50:55 --> Loader Class Initialized
INFO - 2018-02-07 06:50:55 --> Output Class Initialized
INFO - 2018-02-07 12:20:55 --> Helper loaded: url_helper
INFO - 2018-02-07 06:50:55 --> Security Class Initialized
INFO - 2018-02-07 12:20:55 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:20:55 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:20:55 --> Helper loaded: form_helper
INFO - 2018-02-07 12:20:55 --> Form Validation Class Initialized
INFO - 2018-02-07 12:20:55 --> Controller Class Initialized
DEBUG - 2018-02-07 06:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:50:55 --> Input Class Initialized
INFO - 2018-02-07 12:20:55 --> Helper loaded: permission_helper
INFO - 2018-02-07 06:50:55 --> Language Class Initialized
INFO - 2018-02-07 12:20:55 --> Helper loaded: users_helper
INFO - 2018-02-07 12:20:55 --> Model Class Initialized
INFO - 2018-02-07 12:20:55 --> Helper loaded: inflector_helper
INFO - 2018-02-07 06:50:55 --> Language Class Initialized
INFO - 2018-02-07 06:50:55 --> Config Class Initialized
INFO - 2018-02-07 06:50:55 --> Loader Class Initialized
DEBUG - 2018-02-07 12:20:55 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:20:55 --> Helper loaded: url_helper
INFO - 2018-02-07 12:20:55 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:20:55 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:20:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:20:55 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:20:55 --> Helper loaded: users_helper
INFO - 2018-02-07 12:20:55 --> Model Class Initialized
INFO - 2018-02-07 12:20:55 --> Model Class Initialized
INFO - 2018-02-07 12:20:55 --> Database Driver Class Initialized
INFO - 2018-02-07 12:20:55 --> Model Class Initialized
INFO - 2018-02-07 12:20:55 --> Model Class Initialized
INFO - 2018-02-07 12:20:55 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-02-07 12:20:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:20:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:20:55 --> Final output sent to browser
DEBUG - 2018-02-07 12:20:55 --> Total execution time: 0.1067
INFO - 2018-02-07 12:20:55 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:20:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:20:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:20:55 --> Helper loaded: form_helper
INFO - 2018-02-07 12:20:55 --> Form Validation Class Initialized
INFO - 2018-02-07 12:20:55 --> Controller Class Initialized
INFO - 2018-02-07 12:20:55 --> Helper loaded: form_helper
INFO - 2018-02-07 12:20:55 --> Form Validation Class Initialized
INFO - 2018-02-07 12:20:55 --> Controller Class Initialized
INFO - 2018-02-07 12:20:55 --> Model Class Initialized
INFO - 2018-02-07 12:20:55 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:20:55 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:20:55 --> Model Class Initialized
INFO - 2018-02-07 12:20:55 --> Helper loaded: inflector_helper
INFO - 2018-02-07 12:20:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:20:55 --> Model Class Initialized
INFO - 2018-02-07 12:20:55 --> Model Class Initialized
DEBUG - 2018-02-07 12:20:55 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:20:55 --> Model Class Initialized
INFO - 2018-02-07 12:20:55 --> Model Class Initialized
INFO - 2018-02-07 12:20:55 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:20:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:20:55 --> Model Class Initialized
INFO - 2018-02-07 12:20:55 --> Model Class Initialized
INFO - 2018-02-07 12:20:55 --> Model Class Initialized
INFO - 2018-02-07 12:20:55 --> Model Class Initialized
INFO - 2018-02-07 12:20:55 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:20:55 --> Final output sent to browser
DEBUG - 2018-02-07 12:20:55 --> Total execution time: 0.1101
INFO - 2018-02-07 12:20:55 --> Final output sent to browser
DEBUG - 2018-02-07 12:20:55 --> Total execution time: 0.0811
INFO - 2018-02-07 06:50:55 --> Config Class Initialized
INFO - 2018-02-07 06:50:55 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:50:55 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:50:55 --> Utf8 Class Initialized
INFO - 2018-02-07 06:50:55 --> URI Class Initialized
INFO - 2018-02-07 06:50:55 --> Router Class Initialized
INFO - 2018-02-07 06:50:55 --> Output Class Initialized
INFO - 2018-02-07 06:50:55 --> Security Class Initialized
DEBUG - 2018-02-07 06:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:50:55 --> Input Class Initialized
INFO - 2018-02-07 06:50:55 --> Language Class Initialized
INFO - 2018-02-07 06:50:56 --> Language Class Initialized
INFO - 2018-02-07 06:50:56 --> Config Class Initialized
INFO - 2018-02-07 06:50:56 --> Loader Class Initialized
INFO - 2018-02-07 12:20:56 --> Helper loaded: url_helper
INFO - 2018-02-07 12:20:56 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:20:56 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:20:56 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:20:56 --> Helper loaded: users_helper
INFO - 2018-02-07 12:20:56 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:20:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:20:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:20:56 --> Helper loaded: form_helper
INFO - 2018-02-07 12:20:56 --> Form Validation Class Initialized
INFO - 2018-02-07 12:20:56 --> Controller Class Initialized
INFO - 2018-02-07 12:20:56 --> Model Class Initialized
INFO - 2018-02-07 12:20:56 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:20:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:20:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:20:56 --> Model Class Initialized
INFO - 2018-02-07 12:20:56 --> Model Class Initialized
INFO - 2018-02-07 12:20:56 --> Model Class Initialized
INFO - 2018-02-07 12:20:56 --> Model Class Initialized
INFO - 2018-02-07 12:20:56 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:20:56 --> Final output sent to browser
DEBUG - 2018-02-07 12:20:56 --> Total execution time: 0.0935
INFO - 2018-02-07 06:51:00 --> Config Class Initialized
INFO - 2018-02-07 06:51:00 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:51:00 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:51:00 --> Utf8 Class Initialized
INFO - 2018-02-07 06:51:00 --> URI Class Initialized
INFO - 2018-02-07 06:51:00 --> Router Class Initialized
INFO - 2018-02-07 06:51:00 --> Output Class Initialized
INFO - 2018-02-07 06:51:00 --> Security Class Initialized
DEBUG - 2018-02-07 06:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:51:00 --> Input Class Initialized
INFO - 2018-02-07 06:51:00 --> Language Class Initialized
INFO - 2018-02-07 06:51:00 --> Language Class Initialized
INFO - 2018-02-07 06:51:00 --> Config Class Initialized
INFO - 2018-02-07 06:51:00 --> Loader Class Initialized
INFO - 2018-02-07 12:21:00 --> Helper loaded: url_helper
INFO - 2018-02-07 12:21:00 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:21:00 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:21:00 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:21:00 --> Helper loaded: users_helper
INFO - 2018-02-07 12:21:00 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:21:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:21:00 --> Helper loaded: form_helper
INFO - 2018-02-07 12:21:00 --> Form Validation Class Initialized
INFO - 2018-02-07 12:21:00 --> Controller Class Initialized
INFO - 2018-02-07 12:21:00 --> Model Class Initialized
INFO - 2018-02-07 12:21:00 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:21:00 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:21:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:21:00 --> Model Class Initialized
INFO - 2018-02-07 12:21:00 --> Model Class Initialized
INFO - 2018-02-07 12:21:00 --> Model Class Initialized
INFO - 2018-02-07 12:21:00 --> Model Class Initialized
INFO - 2018-02-07 12:21:00 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:21:00 --> Final output sent to browser
DEBUG - 2018-02-07 12:21:00 --> Total execution time: 0.0744
INFO - 2018-02-07 06:51:02 --> Config Class Initialized
INFO - 2018-02-07 06:51:02 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:51:02 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:51:02 --> Utf8 Class Initialized
INFO - 2018-02-07 06:51:02 --> URI Class Initialized
INFO - 2018-02-07 06:51:02 --> Router Class Initialized
INFO - 2018-02-07 06:51:02 --> Output Class Initialized
INFO - 2018-02-07 06:51:02 --> Security Class Initialized
DEBUG - 2018-02-07 06:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:51:02 --> Input Class Initialized
INFO - 2018-02-07 06:51:02 --> Language Class Initialized
INFO - 2018-02-07 06:51:02 --> Language Class Initialized
INFO - 2018-02-07 06:51:02 --> Config Class Initialized
INFO - 2018-02-07 06:51:02 --> Loader Class Initialized
INFO - 2018-02-07 12:21:02 --> Helper loaded: url_helper
INFO - 2018-02-07 12:21:02 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:21:02 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:21:02 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:21:02 --> Helper loaded: users_helper
INFO - 2018-02-07 12:21:02 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:21:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:21:02 --> Helper loaded: form_helper
INFO - 2018-02-07 12:21:02 --> Form Validation Class Initialized
INFO - 2018-02-07 12:21:02 --> Controller Class Initialized
INFO - 2018-02-07 12:21:02 --> Model Class Initialized
INFO - 2018-02-07 12:21:02 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:21:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:21:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:21:02 --> Model Class Initialized
INFO - 2018-02-07 12:21:02 --> Model Class Initialized
INFO - 2018-02-07 12:21:02 --> Model Class Initialized
INFO - 2018-02-07 12:21:02 --> Model Class Initialized
INFO - 2018-02-07 12:21:02 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:21:02 --> Final output sent to browser
DEBUG - 2018-02-07 12:21:02 --> Total execution time: 0.0970
INFO - 2018-02-07 06:51:04 --> Config Class Initialized
INFO - 2018-02-07 06:51:04 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:51:04 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:51:04 --> Utf8 Class Initialized
INFO - 2018-02-07 06:51:04 --> URI Class Initialized
INFO - 2018-02-07 06:51:04 --> Router Class Initialized
INFO - 2018-02-07 06:51:04 --> Output Class Initialized
INFO - 2018-02-07 06:51:04 --> Security Class Initialized
DEBUG - 2018-02-07 06:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:51:04 --> Input Class Initialized
INFO - 2018-02-07 06:51:04 --> Language Class Initialized
INFO - 2018-02-07 06:51:04 --> Language Class Initialized
INFO - 2018-02-07 06:51:04 --> Config Class Initialized
INFO - 2018-02-07 06:51:04 --> Loader Class Initialized
INFO - 2018-02-07 12:21:04 --> Helper loaded: url_helper
INFO - 2018-02-07 12:21:04 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:21:04 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:21:04 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:21:04 --> Helper loaded: users_helper
INFO - 2018-02-07 06:51:04 --> Config Class Initialized
INFO - 2018-02-07 06:51:04 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:51:04 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:51:04 --> Utf8 Class Initialized
INFO - 2018-02-07 06:51:04 --> URI Class Initialized
INFO - 2018-02-07 06:51:04 --> Router Class Initialized
INFO - 2018-02-07 06:51:04 --> Output Class Initialized
INFO - 2018-02-07 06:51:04 --> Security Class Initialized
DEBUG - 2018-02-07 06:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:51:04 --> Input Class Initialized
INFO - 2018-02-07 12:21:04 --> Database Driver Class Initialized
INFO - 2018-02-07 06:51:04 --> Language Class Initialized
DEBUG - 2018-02-07 12:21:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:21:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 06:51:04 --> Language Class Initialized
INFO - 2018-02-07 06:51:04 --> Config Class Initialized
INFO - 2018-02-07 06:51:04 --> Loader Class Initialized
INFO - 2018-02-07 12:21:04 --> Helper loaded: url_helper
INFO - 2018-02-07 12:21:04 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:21:04 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:21:04 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:21:04 --> Helper loaded: form_helper
INFO - 2018-02-07 12:21:04 --> Form Validation Class Initialized
INFO - 2018-02-07 12:21:04 --> Controller Class Initialized
INFO - 2018-02-07 12:21:04 --> Helper loaded: users_helper
INFO - 2018-02-07 12:21:04 --> Model Class Initialized
INFO - 2018-02-07 12:21:04 --> Database Driver Class Initialized
INFO - 2018-02-07 12:21:04 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:21:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:21:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-07 12:21:04 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:21:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:21:04 --> Model Class Initialized
INFO - 2018-02-07 12:21:04 --> Model Class Initialized
INFO - 2018-02-07 12:21:04 --> Model Class Initialized
INFO - 2018-02-07 12:21:04 --> Model Class Initialized
INFO - 2018-02-07 12:21:04 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:21:04 --> Helper loaded: form_helper
INFO - 2018-02-07 12:21:04 --> Form Validation Class Initialized
INFO - 2018-02-07 12:21:04 --> Controller Class Initialized
INFO - 2018-02-07 12:21:04 --> Final output sent to browser
DEBUG - 2018-02-07 12:21:04 --> Total execution time: 0.1144
INFO - 2018-02-07 12:21:04 --> Model Class Initialized
INFO - 2018-02-07 12:21:04 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:21:04 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:21:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:21:04 --> Model Class Initialized
INFO - 2018-02-07 12:21:04 --> Model Class Initialized
INFO - 2018-02-07 12:21:04 --> Model Class Initialized
INFO - 2018-02-07 12:21:04 --> Model Class Initialized
INFO - 2018-02-07 12:21:04 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:21:04 --> Final output sent to browser
DEBUG - 2018-02-07 12:21:04 --> Total execution time: 0.0803
INFO - 2018-02-07 06:51:07 --> Config Class Initialized
INFO - 2018-02-07 06:51:07 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:51:07 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:51:07 --> Utf8 Class Initialized
INFO - 2018-02-07 06:51:07 --> URI Class Initialized
INFO - 2018-02-07 06:51:07 --> Router Class Initialized
INFO - 2018-02-07 06:51:07 --> Output Class Initialized
INFO - 2018-02-07 06:51:07 --> Security Class Initialized
DEBUG - 2018-02-07 06:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:51:07 --> Input Class Initialized
INFO - 2018-02-07 06:51:07 --> Language Class Initialized
INFO - 2018-02-07 06:51:07 --> Language Class Initialized
INFO - 2018-02-07 06:51:07 --> Config Class Initialized
INFO - 2018-02-07 06:51:07 --> Loader Class Initialized
INFO - 2018-02-07 12:21:07 --> Helper loaded: url_helper
INFO - 2018-02-07 12:21:07 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:21:07 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:21:07 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:21:07 --> Helper loaded: users_helper
INFO - 2018-02-07 12:21:07 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:21:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:21:07 --> Helper loaded: form_helper
INFO - 2018-02-07 12:21:07 --> Form Validation Class Initialized
INFO - 2018-02-07 12:21:07 --> Controller Class Initialized
INFO - 2018-02-07 12:21:07 --> Model Class Initialized
INFO - 2018-02-07 12:21:07 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:21:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:21:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:21:07 --> Model Class Initialized
INFO - 2018-02-07 12:21:07 --> Model Class Initialized
INFO - 2018-02-07 12:21:07 --> Model Class Initialized
INFO - 2018-02-07 12:21:07 --> Model Class Initialized
INFO - 2018-02-07 12:21:07 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:21:07 --> Final output sent to browser
DEBUG - 2018-02-07 12:21:07 --> Total execution time: 0.1069
INFO - 2018-02-07 06:51:10 --> Config Class Initialized
INFO - 2018-02-07 06:51:10 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:51:10 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:51:10 --> Utf8 Class Initialized
INFO - 2018-02-07 06:51:10 --> URI Class Initialized
INFO - 2018-02-07 06:51:10 --> Router Class Initialized
INFO - 2018-02-07 06:51:10 --> Output Class Initialized
INFO - 2018-02-07 06:51:10 --> Security Class Initialized
DEBUG - 2018-02-07 06:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:51:10 --> Input Class Initialized
INFO - 2018-02-07 06:51:10 --> Language Class Initialized
INFO - 2018-02-07 06:51:10 --> Language Class Initialized
INFO - 2018-02-07 06:51:10 --> Config Class Initialized
INFO - 2018-02-07 06:51:10 --> Loader Class Initialized
INFO - 2018-02-07 12:21:10 --> Helper loaded: url_helper
INFO - 2018-02-07 12:21:10 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:21:10 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:21:10 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:21:10 --> Helper loaded: users_helper
INFO - 2018-02-07 12:21:10 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:21:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:21:10 --> Helper loaded: form_helper
INFO - 2018-02-07 12:21:10 --> Form Validation Class Initialized
INFO - 2018-02-07 12:21:10 --> Controller Class Initialized
INFO - 2018-02-07 12:21:10 --> Model Class Initialized
INFO - 2018-02-07 12:21:10 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:21:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:21:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:21:10 --> Model Class Initialized
INFO - 2018-02-07 12:21:10 --> Model Class Initialized
INFO - 2018-02-07 12:21:10 --> Model Class Initialized
INFO - 2018-02-07 12:21:10 --> Model Class Initialized
INFO - 2018-02-07 12:21:10 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:21:10 --> Final output sent to browser
DEBUG - 2018-02-07 12:21:10 --> Total execution time: 0.0761
INFO - 2018-02-07 06:51:13 --> Config Class Initialized
INFO - 2018-02-07 06:51:13 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:51:13 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:51:13 --> Utf8 Class Initialized
INFO - 2018-02-07 06:51:13 --> URI Class Initialized
INFO - 2018-02-07 06:51:13 --> Router Class Initialized
INFO - 2018-02-07 06:51:13 --> Output Class Initialized
INFO - 2018-02-07 06:51:13 --> Security Class Initialized
DEBUG - 2018-02-07 06:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:51:13 --> Input Class Initialized
INFO - 2018-02-07 06:51:13 --> Language Class Initialized
INFO - 2018-02-07 06:51:13 --> Language Class Initialized
INFO - 2018-02-07 06:51:13 --> Config Class Initialized
INFO - 2018-02-07 06:51:13 --> Loader Class Initialized
INFO - 2018-02-07 12:21:13 --> Helper loaded: url_helper
INFO - 2018-02-07 12:21:13 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:21:13 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:21:13 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:21:13 --> Helper loaded: users_helper
INFO - 2018-02-07 12:21:13 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:21:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:21:13 --> Helper loaded: form_helper
INFO - 2018-02-07 12:21:13 --> Form Validation Class Initialized
INFO - 2018-02-07 12:21:13 --> Controller Class Initialized
INFO - 2018-02-07 12:21:13 --> Model Class Initialized
INFO - 2018-02-07 12:21:13 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:21:13 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:21:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:21:13 --> Model Class Initialized
INFO - 2018-02-07 12:21:13 --> Model Class Initialized
INFO - 2018-02-07 12:21:13 --> Model Class Initialized
INFO - 2018-02-07 12:21:13 --> Model Class Initialized
INFO - 2018-02-07 12:21:13 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:21:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-07 12:21:13 --> Final output sent to browser
DEBUG - 2018-02-07 12:21:13 --> Total execution time: 0.1189
INFO - 2018-02-07 06:51:14 --> Config Class Initialized
INFO - 2018-02-07 06:51:14 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:51:14 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:51:14 --> Utf8 Class Initialized
INFO - 2018-02-07 06:51:14 --> URI Class Initialized
INFO - 2018-02-07 06:51:14 --> Router Class Initialized
INFO - 2018-02-07 06:51:14 --> Output Class Initialized
INFO - 2018-02-07 06:51:14 --> Security Class Initialized
DEBUG - 2018-02-07 06:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:51:14 --> Input Class Initialized
INFO - 2018-02-07 06:51:14 --> Language Class Initialized
INFO - 2018-02-07 06:51:14 --> Language Class Initialized
INFO - 2018-02-07 06:51:14 --> Config Class Initialized
INFO - 2018-02-07 06:51:14 --> Loader Class Initialized
INFO - 2018-02-07 12:21:14 --> Helper loaded: url_helper
INFO - 2018-02-07 12:21:14 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:21:14 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:21:14 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:21:14 --> Helper loaded: users_helper
INFO - 2018-02-07 12:21:14 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:21:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:21:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:21:14 --> Helper loaded: form_helper
INFO - 2018-02-07 12:21:14 --> Form Validation Class Initialized
INFO - 2018-02-07 12:21:14 --> Controller Class Initialized
INFO - 2018-02-07 12:21:14 --> Model Class Initialized
INFO - 2018-02-07 12:21:14 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:21:14 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:21:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:21:14 --> Model Class Initialized
INFO - 2018-02-07 12:21:14 --> Model Class Initialized
INFO - 2018-02-07 12:21:14 --> Model Class Initialized
INFO - 2018-02-07 12:21:14 --> Model Class Initialized
INFO - 2018-02-07 12:21:14 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:21:14 --> Final output sent to browser
DEBUG - 2018-02-07 12:21:14 --> Total execution time: 0.1201
INFO - 2018-02-07 06:51:14 --> Config Class Initialized
INFO - 2018-02-07 06:51:14 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:51:14 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:51:14 --> Utf8 Class Initialized
INFO - 2018-02-07 06:51:14 --> URI Class Initialized
INFO - 2018-02-07 06:51:14 --> Router Class Initialized
INFO - 2018-02-07 06:51:14 --> Output Class Initialized
INFO - 2018-02-07 06:51:14 --> Security Class Initialized
DEBUG - 2018-02-07 06:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:51:14 --> Input Class Initialized
INFO - 2018-02-07 06:51:14 --> Language Class Initialized
INFO - 2018-02-07 06:51:14 --> Language Class Initialized
INFO - 2018-02-07 06:51:14 --> Config Class Initialized
INFO - 2018-02-07 06:51:14 --> Loader Class Initialized
INFO - 2018-02-07 12:21:14 --> Helper loaded: url_helper
INFO - 2018-02-07 12:21:14 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:21:14 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:21:14 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:21:14 --> Helper loaded: users_helper
INFO - 2018-02-07 12:21:14 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:21:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:21:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:21:14 --> Helper loaded: form_helper
INFO - 2018-02-07 12:21:14 --> Form Validation Class Initialized
INFO - 2018-02-07 12:21:14 --> Controller Class Initialized
INFO - 2018-02-07 12:21:14 --> Model Class Initialized
INFO - 2018-02-07 12:21:14 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:21:14 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:21:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:21:14 --> Model Class Initialized
INFO - 2018-02-07 12:21:14 --> Model Class Initialized
INFO - 2018-02-07 12:21:14 --> Model Class Initialized
INFO - 2018-02-07 12:21:14 --> Model Class Initialized
INFO - 2018-02-07 12:21:14 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:21:14 --> Final output sent to browser
DEBUG - 2018-02-07 12:21:14 --> Total execution time: 0.0757
INFO - 2018-02-07 06:51:16 --> Config Class Initialized
INFO - 2018-02-07 06:51:16 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:51:16 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:51:16 --> Utf8 Class Initialized
INFO - 2018-02-07 06:51:16 --> URI Class Initialized
INFO - 2018-02-07 06:51:16 --> Router Class Initialized
INFO - 2018-02-07 06:51:16 --> Config Class Initialized
INFO - 2018-02-07 06:51:16 --> Hooks Class Initialized
INFO - 2018-02-07 06:51:16 --> Output Class Initialized
DEBUG - 2018-02-07 06:51:16 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:51:16 --> Utf8 Class Initialized
INFO - 2018-02-07 06:51:16 --> Security Class Initialized
INFO - 2018-02-07 06:51:16 --> URI Class Initialized
DEBUG - 2018-02-07 06:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:51:16 --> Input Class Initialized
INFO - 2018-02-07 06:51:16 --> Router Class Initialized
INFO - 2018-02-07 06:51:16 --> Language Class Initialized
INFO - 2018-02-07 06:51:16 --> Output Class Initialized
INFO - 2018-02-07 06:51:16 --> Security Class Initialized
DEBUG - 2018-02-07 06:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:51:16 --> Input Class Initialized
INFO - 2018-02-07 06:51:16 --> Language Class Initialized
INFO - 2018-02-07 06:51:16 --> Language Class Initialized
INFO - 2018-02-07 06:51:16 --> Config Class Initialized
INFO - 2018-02-07 06:51:16 --> Loader Class Initialized
INFO - 2018-02-07 12:21:16 --> Helper loaded: url_helper
INFO - 2018-02-07 12:21:16 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:21:16 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:21:16 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:21:16 --> Helper loaded: users_helper
INFO - 2018-02-07 06:51:16 --> Language Class Initialized
INFO - 2018-02-07 06:51:16 --> Config Class Initialized
INFO - 2018-02-07 06:51:16 --> Loader Class Initialized
INFO - 2018-02-07 12:21:16 --> Helper loaded: url_helper
INFO - 2018-02-07 12:21:16 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:21:16 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:21:16 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:21:16 --> Helper loaded: users_helper
INFO - 2018-02-07 12:21:16 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:21:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:21:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:21:16 --> Database Driver Class Initialized
INFO - 2018-02-07 12:21:16 --> Helper loaded: form_helper
INFO - 2018-02-07 12:21:16 --> Form Validation Class Initialized
INFO - 2018-02-07 12:21:16 --> Controller Class Initialized
DEBUG - 2018-02-07 12:21:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:21:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:21:16 --> Model Class Initialized
INFO - 2018-02-07 12:21:16 --> Helper loaded: inflector_helper
INFO - 2018-02-07 12:21:16 --> Helper loaded: form_helper
INFO - 2018-02-07 12:21:16 --> Form Validation Class Initialized
INFO - 2018-02-07 12:21:16 --> Controller Class Initialized
DEBUG - 2018-02-07 12:21:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:21:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:21:16 --> Model Class Initialized
INFO - 2018-02-07 12:21:16 --> Model Class Initialized
INFO - 2018-02-07 12:21:16 --> Model Class Initialized
INFO - 2018-02-07 12:21:16 --> Model Class Initialized
INFO - 2018-02-07 12:21:16 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:21:16 --> Model Class Initialized
INFO - 2018-02-07 12:21:16 --> Helper loaded: inflector_helper
INFO - 2018-02-07 12:21:16 --> Final output sent to browser
DEBUG - 2018-02-07 12:21:16 --> Total execution time: 0.1125
DEBUG - 2018-02-07 12:21:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:21:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:21:16 --> Model Class Initialized
INFO - 2018-02-07 12:21:16 --> Model Class Initialized
INFO - 2018-02-07 12:21:16 --> Model Class Initialized
INFO - 2018-02-07 12:21:16 --> Model Class Initialized
INFO - 2018-02-07 12:21:16 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:21:16 --> Final output sent to browser
DEBUG - 2018-02-07 12:21:16 --> Total execution time: 0.1130
INFO - 2018-02-07 06:51:20 --> Config Class Initialized
INFO - 2018-02-07 06:51:20 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:51:20 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:51:20 --> Utf8 Class Initialized
INFO - 2018-02-07 06:51:20 --> URI Class Initialized
INFO - 2018-02-07 06:51:20 --> Router Class Initialized
INFO - 2018-02-07 06:51:20 --> Output Class Initialized
INFO - 2018-02-07 06:51:20 --> Security Class Initialized
DEBUG - 2018-02-07 06:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:51:20 --> Input Class Initialized
INFO - 2018-02-07 06:51:20 --> Language Class Initialized
INFO - 2018-02-07 06:51:20 --> Language Class Initialized
INFO - 2018-02-07 06:51:20 --> Config Class Initialized
INFO - 2018-02-07 06:51:20 --> Loader Class Initialized
INFO - 2018-02-07 12:21:20 --> Helper loaded: url_helper
INFO - 2018-02-07 12:21:20 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:21:20 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:21:20 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:21:20 --> Helper loaded: users_helper
INFO - 2018-02-07 12:21:20 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:21:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:21:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:21:20 --> Helper loaded: form_helper
INFO - 2018-02-07 12:21:20 --> Form Validation Class Initialized
INFO - 2018-02-07 12:21:20 --> Controller Class Initialized
INFO - 2018-02-07 12:21:20 --> Model Class Initialized
INFO - 2018-02-07 12:21:20 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:21:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:21:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:21:20 --> Model Class Initialized
INFO - 2018-02-07 12:21:20 --> Model Class Initialized
INFO - 2018-02-07 12:21:20 --> Model Class Initialized
INFO - 2018-02-07 12:21:20 --> Model Class Initialized
INFO - 2018-02-07 12:21:20 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:21:20 --> Final output sent to browser
DEBUG - 2018-02-07 12:21:20 --> Total execution time: 0.1055
INFO - 2018-02-07 06:51:21 --> Config Class Initialized
INFO - 2018-02-07 06:51:21 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:51:21 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:51:21 --> Utf8 Class Initialized
INFO - 2018-02-07 06:51:21 --> URI Class Initialized
INFO - 2018-02-07 06:51:21 --> Router Class Initialized
INFO - 2018-02-07 06:51:21 --> Output Class Initialized
INFO - 2018-02-07 06:51:21 --> Security Class Initialized
DEBUG - 2018-02-07 06:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:51:21 --> Input Class Initialized
INFO - 2018-02-07 06:51:21 --> Language Class Initialized
INFO - 2018-02-07 06:51:21 --> Language Class Initialized
INFO - 2018-02-07 06:51:21 --> Config Class Initialized
INFO - 2018-02-07 06:51:21 --> Loader Class Initialized
INFO - 2018-02-07 12:21:21 --> Helper loaded: url_helper
INFO - 2018-02-07 12:21:21 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:21:21 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:21:21 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:21:21 --> Helper loaded: users_helper
INFO - 2018-02-07 12:21:21 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:21:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:21:21 --> Helper loaded: form_helper
INFO - 2018-02-07 12:21:21 --> Form Validation Class Initialized
INFO - 2018-02-07 12:21:21 --> Controller Class Initialized
INFO - 2018-02-07 12:21:21 --> Model Class Initialized
INFO - 2018-02-07 12:21:21 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:21:21 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:21:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:21:21 --> Model Class Initialized
INFO - 2018-02-07 12:21:21 --> Model Class Initialized
INFO - 2018-02-07 12:21:21 --> Model Class Initialized
INFO - 2018-02-07 12:21:21 --> Model Class Initialized
INFO - 2018-02-07 12:21:21 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:21:21 --> Final output sent to browser
DEBUG - 2018-02-07 12:21:21 --> Total execution time: 0.0972
INFO - 2018-02-07 06:51:22 --> Config Class Initialized
INFO - 2018-02-07 06:51:22 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:51:22 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:51:22 --> Utf8 Class Initialized
INFO - 2018-02-07 06:51:22 --> URI Class Initialized
INFO - 2018-02-07 06:51:22 --> Router Class Initialized
INFO - 2018-02-07 06:51:22 --> Output Class Initialized
INFO - 2018-02-07 06:51:22 --> Security Class Initialized
DEBUG - 2018-02-07 06:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:51:22 --> Input Class Initialized
INFO - 2018-02-07 06:51:22 --> Language Class Initialized
INFO - 2018-02-07 06:51:22 --> Language Class Initialized
INFO - 2018-02-07 06:51:22 --> Config Class Initialized
INFO - 2018-02-07 06:51:22 --> Loader Class Initialized
INFO - 2018-02-07 12:21:22 --> Helper loaded: url_helper
INFO - 2018-02-07 12:21:22 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:21:22 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:21:22 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:21:22 --> Helper loaded: users_helper
INFO - 2018-02-07 12:21:22 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:21:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:21:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:21:22 --> Helper loaded: form_helper
INFO - 2018-02-07 12:21:22 --> Form Validation Class Initialized
INFO - 2018-02-07 12:21:22 --> Controller Class Initialized
INFO - 2018-02-07 12:21:22 --> Model Class Initialized
INFO - 2018-02-07 12:21:22 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:21:22 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:21:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:21:22 --> Model Class Initialized
INFO - 2018-02-07 12:21:22 --> Model Class Initialized
INFO - 2018-02-07 12:21:22 --> Model Class Initialized
INFO - 2018-02-07 12:21:22 --> Model Class Initialized
INFO - 2018-02-07 12:21:22 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:21:22 --> Final output sent to browser
DEBUG - 2018-02-07 12:21:22 --> Total execution time: 0.0860
INFO - 2018-02-07 06:51:23 --> Config Class Initialized
INFO - 2018-02-07 06:51:23 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:51:23 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:51:23 --> Utf8 Class Initialized
INFO - 2018-02-07 06:51:23 --> URI Class Initialized
INFO - 2018-02-07 06:51:23 --> Router Class Initialized
INFO - 2018-02-07 06:51:23 --> Output Class Initialized
INFO - 2018-02-07 06:51:23 --> Security Class Initialized
DEBUG - 2018-02-07 06:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:51:23 --> Input Class Initialized
INFO - 2018-02-07 06:51:23 --> Language Class Initialized
INFO - 2018-02-07 06:51:23 --> Language Class Initialized
INFO - 2018-02-07 06:51:23 --> Config Class Initialized
INFO - 2018-02-07 06:51:23 --> Loader Class Initialized
INFO - 2018-02-07 06:51:23 --> Config Class Initialized
INFO - 2018-02-07 06:51:23 --> Hooks Class Initialized
INFO - 2018-02-07 12:21:23 --> Helper loaded: url_helper
INFO - 2018-02-07 12:21:23 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:21:23 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:21:23 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:21:23 --> Helper loaded: users_helper
DEBUG - 2018-02-07 06:51:23 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:51:23 --> Utf8 Class Initialized
INFO - 2018-02-07 06:51:23 --> URI Class Initialized
INFO - 2018-02-07 06:51:23 --> Router Class Initialized
INFO - 2018-02-07 06:51:23 --> Output Class Initialized
INFO - 2018-02-07 06:51:23 --> Security Class Initialized
INFO - 2018-02-07 12:21:23 --> Database Driver Class Initialized
DEBUG - 2018-02-07 06:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:51:23 --> Input Class Initialized
INFO - 2018-02-07 06:51:23 --> Language Class Initialized
DEBUG - 2018-02-07 12:21:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:21:23 --> Helper loaded: form_helper
INFO - 2018-02-07 12:21:23 --> Form Validation Class Initialized
INFO - 2018-02-07 12:21:23 --> Controller Class Initialized
INFO - 2018-02-07 06:51:23 --> Language Class Initialized
INFO - 2018-02-07 06:51:23 --> Config Class Initialized
INFO - 2018-02-07 06:51:23 --> Loader Class Initialized
INFO - 2018-02-07 12:21:23 --> Helper loaded: url_helper
INFO - 2018-02-07 12:21:23 --> Model Class Initialized
INFO - 2018-02-07 12:21:23 --> Helper loaded: inflector_helper
INFO - 2018-02-07 12:21:23 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:21:23 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:21:23 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:21:23 --> Helper loaded: users_helper
DEBUG - 2018-02-07 12:21:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:21:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:21:23 --> Model Class Initialized
INFO - 2018-02-07 12:21:23 --> Model Class Initialized
INFO - 2018-02-07 12:21:23 --> Model Class Initialized
INFO - 2018-02-07 12:21:23 --> Model Class Initialized
INFO - 2018-02-07 12:21:23 --> Model Class Initialized
INFO - 2018-02-07 12:21:23 --> Model Class Initialized
INFO - 2018-02-07 12:21:23 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:21:23 --> Final output sent to browser
DEBUG - 2018-02-07 12:21:23 --> Total execution time: 0.1172
INFO - 2018-02-07 12:21:23 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:21:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:21:23 --> Helper loaded: form_helper
INFO - 2018-02-07 12:21:23 --> Form Validation Class Initialized
INFO - 2018-02-07 12:21:23 --> Controller Class Initialized
INFO - 2018-02-07 12:21:23 --> Model Class Initialized
INFO - 2018-02-07 12:21:23 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:21:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:21:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:21:23 --> Model Class Initialized
INFO - 2018-02-07 12:21:23 --> Model Class Initialized
INFO - 2018-02-07 12:21:23 --> Model Class Initialized
INFO - 2018-02-07 12:21:23 --> Model Class Initialized
INFO - 2018-02-07 12:21:23 --> Model Class Initialized
INFO - 2018-02-07 12:21:23 --> Model Class Initialized
INFO - 2018-02-07 12:21:23 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:21:23 --> Final output sent to browser
DEBUG - 2018-02-07 12:21:23 --> Total execution time: 0.1175
INFO - 2018-02-07 06:51:24 --> Config Class Initialized
INFO - 2018-02-07 06:51:24 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:51:24 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:51:24 --> Utf8 Class Initialized
INFO - 2018-02-07 06:51:24 --> URI Class Initialized
INFO - 2018-02-07 06:51:24 --> Router Class Initialized
INFO - 2018-02-07 06:51:24 --> Output Class Initialized
INFO - 2018-02-07 06:51:24 --> Security Class Initialized
DEBUG - 2018-02-07 06:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:51:24 --> Input Class Initialized
INFO - 2018-02-07 06:51:24 --> Language Class Initialized
INFO - 2018-02-07 06:51:24 --> Language Class Initialized
INFO - 2018-02-07 06:51:24 --> Config Class Initialized
INFO - 2018-02-07 06:51:24 --> Loader Class Initialized
INFO - 2018-02-07 12:21:24 --> Helper loaded: url_helper
INFO - 2018-02-07 12:21:24 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:21:24 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:21:24 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:21:24 --> Helper loaded: users_helper
INFO - 2018-02-07 12:21:24 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:21:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:21:24 --> Helper loaded: form_helper
INFO - 2018-02-07 12:21:24 --> Form Validation Class Initialized
INFO - 2018-02-07 12:21:24 --> Controller Class Initialized
INFO - 2018-02-07 12:21:24 --> Model Class Initialized
INFO - 2018-02-07 12:21:24 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:21:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:21:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:21:24 --> Model Class Initialized
INFO - 2018-02-07 12:21:24 --> Model Class Initialized
INFO - 2018-02-07 12:21:24 --> Model Class Initialized
INFO - 2018-02-07 12:21:24 --> Model Class Initialized
INFO - 2018-02-07 12:21:24 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:21:24 --> Final output sent to browser
DEBUG - 2018-02-07 12:21:24 --> Total execution time: 0.0779
INFO - 2018-02-07 06:51:27 --> Config Class Initialized
INFO - 2018-02-07 06:51:27 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:51:27 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:51:27 --> Utf8 Class Initialized
INFO - 2018-02-07 06:51:27 --> URI Class Initialized
INFO - 2018-02-07 06:51:27 --> Router Class Initialized
INFO - 2018-02-07 06:51:27 --> Output Class Initialized
INFO - 2018-02-07 06:51:27 --> Security Class Initialized
DEBUG - 2018-02-07 06:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:51:27 --> Input Class Initialized
INFO - 2018-02-07 06:51:27 --> Language Class Initialized
INFO - 2018-02-07 06:51:27 --> Config Class Initialized
INFO - 2018-02-07 06:51:27 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:51:27 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:51:27 --> Utf8 Class Initialized
INFO - 2018-02-07 06:51:27 --> URI Class Initialized
INFO - 2018-02-07 06:51:27 --> Router Class Initialized
INFO - 2018-02-07 06:51:27 --> Output Class Initialized
INFO - 2018-02-07 06:51:27 --> Language Class Initialized
INFO - 2018-02-07 06:51:27 --> Config Class Initialized
INFO - 2018-02-07 06:51:27 --> Loader Class Initialized
INFO - 2018-02-07 06:51:27 --> Security Class Initialized
DEBUG - 2018-02-07 06:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:51:27 --> Input Class Initialized
INFO - 2018-02-07 12:21:27 --> Helper loaded: url_helper
INFO - 2018-02-07 06:51:27 --> Language Class Initialized
INFO - 2018-02-07 12:21:27 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:21:27 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:21:27 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:21:27 --> Helper loaded: users_helper
INFO - 2018-02-07 06:51:27 --> Language Class Initialized
INFO - 2018-02-07 06:51:27 --> Config Class Initialized
INFO - 2018-02-07 06:51:27 --> Loader Class Initialized
INFO - 2018-02-07 06:51:27 --> Config Class Initialized
INFO - 2018-02-07 12:21:27 --> Helper loaded: url_helper
INFO - 2018-02-07 06:51:27 --> Hooks Class Initialized
INFO - 2018-02-07 12:21:27 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:21:27 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:21:27 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:21:27 --> Helper loaded: users_helper
DEBUG - 2018-02-07 06:51:27 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:51:27 --> Utf8 Class Initialized
INFO - 2018-02-07 12:21:27 --> Database Driver Class Initialized
INFO - 2018-02-07 06:51:27 --> URI Class Initialized
INFO - 2018-02-07 06:51:27 --> Router Class Initialized
DEBUG - 2018-02-07 12:21:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:21:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 06:51:27 --> Output Class Initialized
INFO - 2018-02-07 12:21:27 --> Database Driver Class Initialized
INFO - 2018-02-07 06:51:27 --> Security Class Initialized
DEBUG - 2018-02-07 12:21:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:21:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-07 06:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:51:27 --> Input Class Initialized
INFO - 2018-02-07 06:51:27 --> Language Class Initialized
INFO - 2018-02-07 12:21:27 --> Helper loaded: form_helper
INFO - 2018-02-07 12:21:27 --> Form Validation Class Initialized
INFO - 2018-02-07 12:21:27 --> Controller Class Initialized
INFO - 2018-02-07 12:21:27 --> Helper loaded: form_helper
INFO - 2018-02-07 12:21:27 --> Form Validation Class Initialized
INFO - 2018-02-07 12:21:27 --> Controller Class Initialized
INFO - 2018-02-07 12:21:27 --> Model Class Initialized
INFO - 2018-02-07 12:21:27 --> Model Class Initialized
INFO - 2018-02-07 12:21:27 --> Helper loaded: inflector_helper
INFO - 2018-02-07 12:21:27 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:21:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-02-07 12:21:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:21:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:21:27 --> Model Class Initialized
INFO - 2018-02-07 06:51:27 --> Language Class Initialized
INFO - 2018-02-07 06:51:27 --> Config Class Initialized
INFO - 2018-02-07 06:51:27 --> Loader Class Initialized
INFO - 2018-02-07 12:21:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:21:27 --> Model Class Initialized
INFO - 2018-02-07 12:21:27 --> Model Class Initialized
INFO - 2018-02-07 12:21:27 --> Model Class Initialized
INFO - 2018-02-07 12:21:27 --> Model Class Initialized
INFO - 2018-02-07 12:21:27 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:21:27 --> Model Class Initialized
INFO - 2018-02-07 12:21:27 --> Helper loaded: url_helper
INFO - 2018-02-07 12:21:27 --> Model Class Initialized
INFO - 2018-02-07 12:21:27 --> Model Class Initialized
INFO - 2018-02-07 12:21:27 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:21:27 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:21:27 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:21:27 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:21:27 --> Final output sent to browser
DEBUG - 2018-02-07 12:21:27 --> Total execution time: 0.0743
INFO - 2018-02-07 12:21:27 --> Final output sent to browser
DEBUG - 2018-02-07 12:21:27 --> Total execution time: 0.1014
INFO - 2018-02-07 12:21:27 --> Helper loaded: users_helper
INFO - 2018-02-07 12:21:27 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:21:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:21:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:21:27 --> Helper loaded: form_helper
INFO - 2018-02-07 12:21:27 --> Form Validation Class Initialized
INFO - 2018-02-07 12:21:27 --> Controller Class Initialized
INFO - 2018-02-07 12:21:27 --> Model Class Initialized
INFO - 2018-02-07 12:21:27 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:21:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:21:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:21:27 --> Model Class Initialized
INFO - 2018-02-07 12:21:27 --> Model Class Initialized
INFO - 2018-02-07 12:21:27 --> Model Class Initialized
INFO - 2018-02-07 12:21:27 --> Model Class Initialized
INFO - 2018-02-07 12:21:27 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:21:27 --> Final output sent to browser
DEBUG - 2018-02-07 12:21:27 --> Total execution time: 0.1103
INFO - 2018-02-07 06:51:29 --> Config Class Initialized
INFO - 2018-02-07 06:51:29 --> Hooks Class Initialized
INFO - 2018-02-07 06:51:29 --> Config Class Initialized
INFO - 2018-02-07 06:51:29 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:51:29 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:51:29 --> Utf8 Class Initialized
DEBUG - 2018-02-07 06:51:29 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:51:29 --> Utf8 Class Initialized
INFO - 2018-02-07 06:51:29 --> URI Class Initialized
INFO - 2018-02-07 06:51:29 --> URI Class Initialized
INFO - 2018-02-07 06:51:29 --> Router Class Initialized
INFO - 2018-02-07 06:51:29 --> Router Class Initialized
INFO - 2018-02-07 06:51:29 --> Output Class Initialized
INFO - 2018-02-07 06:51:29 --> Security Class Initialized
INFO - 2018-02-07 06:51:29 --> Output Class Initialized
DEBUG - 2018-02-07 06:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:51:29 --> Input Class Initialized
INFO - 2018-02-07 06:51:29 --> Language Class Initialized
INFO - 2018-02-07 06:51:29 --> Security Class Initialized
DEBUG - 2018-02-07 06:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:51:29 --> Input Class Initialized
INFO - 2018-02-07 06:51:29 --> Language Class Initialized
INFO - 2018-02-07 06:51:29 --> Language Class Initialized
INFO - 2018-02-07 06:51:29 --> Config Class Initialized
INFO - 2018-02-07 06:51:29 --> Loader Class Initialized
INFO - 2018-02-07 12:21:29 --> Helper loaded: url_helper
INFO - 2018-02-07 12:21:29 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:21:29 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:21:29 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:21:29 --> Helper loaded: users_helper
INFO - 2018-02-07 06:51:29 --> Language Class Initialized
INFO - 2018-02-07 06:51:29 --> Config Class Initialized
INFO - 2018-02-07 06:51:29 --> Loader Class Initialized
INFO - 2018-02-07 12:21:29 --> Helper loaded: url_helper
INFO - 2018-02-07 12:21:29 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:21:29 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:21:29 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:21:29 --> Helper loaded: users_helper
INFO - 2018-02-07 12:21:29 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:21:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:21:29 --> Database Driver Class Initialized
INFO - 2018-02-07 12:21:29 --> Helper loaded: form_helper
INFO - 2018-02-07 12:21:29 --> Form Validation Class Initialized
INFO - 2018-02-07 12:21:29 --> Controller Class Initialized
DEBUG - 2018-02-07 12:21:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:21:29 --> Model Class Initialized
INFO - 2018-02-07 12:21:29 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:21:29 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:21:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:21:29 --> Model Class Initialized
INFO - 2018-02-07 12:21:29 --> Model Class Initialized
INFO - 2018-02-07 12:21:29 --> Helper loaded: form_helper
INFO - 2018-02-07 12:21:29 --> Form Validation Class Initialized
INFO - 2018-02-07 12:21:29 --> Controller Class Initialized
INFO - 2018-02-07 12:21:29 --> Model Class Initialized
INFO - 2018-02-07 12:21:29 --> Model Class Initialized
INFO - 2018-02-07 12:21:29 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:21:29 --> Final output sent to browser
DEBUG - 2018-02-07 12:21:29 --> Total execution time: 0.0957
INFO - 2018-02-07 12:21:29 --> Model Class Initialized
INFO - 2018-02-07 12:21:29 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:21:29 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:21:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:21:29 --> Model Class Initialized
INFO - 2018-02-07 12:21:29 --> Model Class Initialized
INFO - 2018-02-07 12:21:29 --> Model Class Initialized
INFO - 2018-02-07 12:21:29 --> Model Class Initialized
INFO - 2018-02-07 12:21:29 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:21:29 --> Final output sent to browser
DEBUG - 2018-02-07 12:21:29 --> Total execution time: 0.1181
INFO - 2018-02-07 06:51:30 --> Config Class Initialized
INFO - 2018-02-07 06:51:30 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:51:30 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:51:30 --> Utf8 Class Initialized
INFO - 2018-02-07 06:51:30 --> URI Class Initialized
INFO - 2018-02-07 06:51:30 --> Router Class Initialized
INFO - 2018-02-07 06:51:30 --> Output Class Initialized
INFO - 2018-02-07 06:51:30 --> Security Class Initialized
DEBUG - 2018-02-07 06:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:51:30 --> Input Class Initialized
INFO - 2018-02-07 06:51:30 --> Language Class Initialized
INFO - 2018-02-07 06:51:30 --> Language Class Initialized
INFO - 2018-02-07 06:51:30 --> Config Class Initialized
INFO - 2018-02-07 06:51:30 --> Loader Class Initialized
INFO - 2018-02-07 12:21:30 --> Helper loaded: url_helper
INFO - 2018-02-07 12:21:30 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:21:30 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:21:30 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:21:30 --> Helper loaded: users_helper
INFO - 2018-02-07 12:21:30 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:21:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:21:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:21:30 --> Helper loaded: form_helper
INFO - 2018-02-07 12:21:30 --> Form Validation Class Initialized
INFO - 2018-02-07 12:21:30 --> Controller Class Initialized
INFO - 2018-02-07 12:21:30 --> Model Class Initialized
INFO - 2018-02-07 12:21:30 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:21:30 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:21:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:21:30 --> Model Class Initialized
INFO - 2018-02-07 12:21:30 --> Model Class Initialized
INFO - 2018-02-07 12:21:30 --> Model Class Initialized
INFO - 2018-02-07 12:21:30 --> Model Class Initialized
INFO - 2018-02-07 12:21:30 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:21:30 --> Final output sent to browser
DEBUG - 2018-02-07 12:21:30 --> Total execution time: 0.0801
INFO - 2018-02-07 06:51:32 --> Config Class Initialized
INFO - 2018-02-07 06:51:32 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:51:32 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:51:32 --> Utf8 Class Initialized
INFO - 2018-02-07 06:51:32 --> URI Class Initialized
INFO - 2018-02-07 06:51:32 --> Router Class Initialized
INFO - 2018-02-07 06:51:32 --> Output Class Initialized
INFO - 2018-02-07 06:51:32 --> Security Class Initialized
DEBUG - 2018-02-07 06:51:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:51:32 --> Input Class Initialized
INFO - 2018-02-07 06:51:32 --> Language Class Initialized
INFO - 2018-02-07 06:51:32 --> Language Class Initialized
INFO - 2018-02-07 06:51:32 --> Config Class Initialized
INFO - 2018-02-07 06:51:32 --> Loader Class Initialized
INFO - 2018-02-07 12:21:32 --> Helper loaded: url_helper
INFO - 2018-02-07 12:21:32 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:21:32 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:21:32 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:21:32 --> Helper loaded: users_helper
INFO - 2018-02-07 12:21:32 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:21:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:21:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:21:32 --> Helper loaded: form_helper
INFO - 2018-02-07 12:21:32 --> Form Validation Class Initialized
INFO - 2018-02-07 12:21:32 --> Controller Class Initialized
INFO - 2018-02-07 12:21:32 --> Model Class Initialized
INFO - 2018-02-07 12:21:32 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:21:32 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:21:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:21:32 --> Model Class Initialized
INFO - 2018-02-07 12:21:32 --> Model Class Initialized
INFO - 2018-02-07 12:21:32 --> Model Class Initialized
INFO - 2018-02-07 12:21:32 --> Model Class Initialized
INFO - 2018-02-07 12:21:32 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:21:32 --> Final output sent to browser
DEBUG - 2018-02-07 12:21:32 --> Total execution time: 0.1141
INFO - 2018-02-07 06:51:35 --> Config Class Initialized
INFO - 2018-02-07 06:51:35 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:51:35 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:51:35 --> Utf8 Class Initialized
INFO - 2018-02-07 06:51:35 --> URI Class Initialized
INFO - 2018-02-07 06:51:35 --> Router Class Initialized
INFO - 2018-02-07 06:51:35 --> Output Class Initialized
INFO - 2018-02-07 06:51:35 --> Security Class Initialized
DEBUG - 2018-02-07 06:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:51:35 --> Input Class Initialized
INFO - 2018-02-07 06:51:35 --> Language Class Initialized
INFO - 2018-02-07 06:51:35 --> Language Class Initialized
INFO - 2018-02-07 06:51:35 --> Config Class Initialized
INFO - 2018-02-07 06:51:35 --> Loader Class Initialized
INFO - 2018-02-07 12:21:35 --> Helper loaded: url_helper
INFO - 2018-02-07 12:21:35 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:21:35 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:21:35 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:21:35 --> Helper loaded: users_helper
INFO - 2018-02-07 12:21:35 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:21:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:21:35 --> Helper loaded: form_helper
INFO - 2018-02-07 12:21:35 --> Form Validation Class Initialized
INFO - 2018-02-07 12:21:35 --> Controller Class Initialized
INFO - 2018-02-07 12:21:35 --> Model Class Initialized
INFO - 2018-02-07 12:21:35 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:21:35 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:21:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:21:35 --> Model Class Initialized
INFO - 2018-02-07 12:21:35 --> Model Class Initialized
INFO - 2018-02-07 12:21:35 --> Model Class Initialized
INFO - 2018-02-07 12:21:35 --> Model Class Initialized
INFO - 2018-02-07 12:21:35 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:21:35 --> Final output sent to browser
DEBUG - 2018-02-07 12:21:35 --> Total execution time: 0.1549
INFO - 2018-02-07 06:51:37 --> Config Class Initialized
INFO - 2018-02-07 06:51:37 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:51:37 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:51:37 --> Utf8 Class Initialized
INFO - 2018-02-07 06:51:37 --> URI Class Initialized
INFO - 2018-02-07 06:51:37 --> Router Class Initialized
INFO - 2018-02-07 06:51:37 --> Output Class Initialized
INFO - 2018-02-07 06:51:37 --> Security Class Initialized
DEBUG - 2018-02-07 06:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:51:37 --> Input Class Initialized
INFO - 2018-02-07 06:51:37 --> Language Class Initialized
INFO - 2018-02-07 06:51:37 --> Language Class Initialized
INFO - 2018-02-07 06:51:37 --> Config Class Initialized
INFO - 2018-02-07 06:51:37 --> Loader Class Initialized
INFO - 2018-02-07 12:21:37 --> Helper loaded: url_helper
INFO - 2018-02-07 12:21:37 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:21:37 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:21:37 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:21:37 --> Helper loaded: users_helper
INFO - 2018-02-07 12:21:37 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:21:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:21:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:21:37 --> Helper loaded: form_helper
INFO - 2018-02-07 12:21:37 --> Form Validation Class Initialized
INFO - 2018-02-07 12:21:37 --> Controller Class Initialized
INFO - 2018-02-07 12:21:37 --> Model Class Initialized
INFO - 2018-02-07 12:21:37 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:21:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:21:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:21:37 --> Model Class Initialized
INFO - 2018-02-07 12:21:37 --> Model Class Initialized
INFO - 2018-02-07 12:21:37 --> Model Class Initialized
INFO - 2018-02-07 12:21:37 --> Model Class Initialized
INFO - 2018-02-07 12:21:37 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:21:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-07 12:21:37 --> Final output sent to browser
DEBUG - 2018-02-07 12:21:37 --> Total execution time: 0.1131
INFO - 2018-02-07 06:51:38 --> Config Class Initialized
INFO - 2018-02-07 06:51:38 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:51:38 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:51:38 --> Utf8 Class Initialized
INFO - 2018-02-07 06:51:38 --> URI Class Initialized
INFO - 2018-02-07 06:51:38 --> Router Class Initialized
INFO - 2018-02-07 06:51:38 --> Output Class Initialized
INFO - 2018-02-07 06:51:38 --> Security Class Initialized
DEBUG - 2018-02-07 06:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:51:38 --> Input Class Initialized
INFO - 2018-02-07 06:51:38 --> Language Class Initialized
INFO - 2018-02-07 06:51:38 --> Language Class Initialized
INFO - 2018-02-07 06:51:38 --> Config Class Initialized
INFO - 2018-02-07 06:51:38 --> Loader Class Initialized
INFO - 2018-02-07 12:21:38 --> Helper loaded: url_helper
INFO - 2018-02-07 12:21:38 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:21:38 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:21:38 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:21:38 --> Helper loaded: users_helper
INFO - 2018-02-07 12:21:38 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:21:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:21:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:21:38 --> Helper loaded: form_helper
INFO - 2018-02-07 12:21:38 --> Form Validation Class Initialized
INFO - 2018-02-07 12:21:38 --> Controller Class Initialized
INFO - 2018-02-07 12:21:38 --> Model Class Initialized
INFO - 2018-02-07 12:21:38 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:21:38 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:21:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:21:38 --> Model Class Initialized
INFO - 2018-02-07 12:21:38 --> Model Class Initialized
INFO - 2018-02-07 12:21:38 --> Model Class Initialized
INFO - 2018-02-07 12:21:38 --> Model Class Initialized
INFO - 2018-02-07 12:21:38 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:21:38 --> Final output sent to browser
DEBUG - 2018-02-07 12:21:38 --> Total execution time: 0.1058
INFO - 2018-02-07 06:51:38 --> Config Class Initialized
INFO - 2018-02-07 06:51:38 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:51:38 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:51:38 --> Utf8 Class Initialized
INFO - 2018-02-07 06:51:38 --> URI Class Initialized
INFO - 2018-02-07 06:51:38 --> Router Class Initialized
INFO - 2018-02-07 06:51:38 --> Output Class Initialized
INFO - 2018-02-07 06:51:38 --> Security Class Initialized
DEBUG - 2018-02-07 06:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:51:38 --> Input Class Initialized
INFO - 2018-02-07 06:51:38 --> Language Class Initialized
INFO - 2018-02-07 06:51:38 --> Language Class Initialized
INFO - 2018-02-07 06:51:38 --> Config Class Initialized
INFO - 2018-02-07 06:51:38 --> Loader Class Initialized
INFO - 2018-02-07 12:21:38 --> Helper loaded: url_helper
INFO - 2018-02-07 12:21:38 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:21:38 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:21:38 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:21:38 --> Helper loaded: users_helper
INFO - 2018-02-07 12:21:38 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:21:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:21:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:21:38 --> Helper loaded: form_helper
INFO - 2018-02-07 12:21:38 --> Form Validation Class Initialized
INFO - 2018-02-07 12:21:38 --> Controller Class Initialized
INFO - 2018-02-07 12:21:38 --> Model Class Initialized
INFO - 2018-02-07 12:21:39 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:21:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:21:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:21:39 --> Model Class Initialized
INFO - 2018-02-07 12:21:39 --> Model Class Initialized
INFO - 2018-02-07 12:21:39 --> Model Class Initialized
INFO - 2018-02-07 12:21:39 --> Model Class Initialized
INFO - 2018-02-07 12:21:39 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:21:39 --> Final output sent to browser
DEBUG - 2018-02-07 12:21:39 --> Total execution time: 0.1164
INFO - 2018-02-07 06:51:40 --> Config Class Initialized
INFO - 2018-02-07 06:51:40 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:51:40 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:51:40 --> Utf8 Class Initialized
INFO - 2018-02-07 06:51:40 --> URI Class Initialized
INFO - 2018-02-07 06:51:40 --> Router Class Initialized
INFO - 2018-02-07 06:51:40 --> Output Class Initialized
INFO - 2018-02-07 06:51:40 --> Security Class Initialized
INFO - 2018-02-07 06:51:40 --> Config Class Initialized
INFO - 2018-02-07 06:51:40 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:51:40 --> Input Class Initialized
INFO - 2018-02-07 06:51:40 --> Language Class Initialized
DEBUG - 2018-02-07 06:51:40 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:51:40 --> Utf8 Class Initialized
INFO - 2018-02-07 06:51:40 --> URI Class Initialized
INFO - 2018-02-07 06:51:40 --> Router Class Initialized
INFO - 2018-02-07 06:51:40 --> Output Class Initialized
INFO - 2018-02-07 06:51:40 --> Security Class Initialized
INFO - 2018-02-07 06:51:40 --> Language Class Initialized
INFO - 2018-02-07 06:51:40 --> Config Class Initialized
INFO - 2018-02-07 06:51:40 --> Loader Class Initialized
DEBUG - 2018-02-07 06:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:51:40 --> Input Class Initialized
INFO - 2018-02-07 06:51:40 --> Language Class Initialized
INFO - 2018-02-07 12:21:40 --> Helper loaded: url_helper
INFO - 2018-02-07 12:21:40 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:21:40 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:21:40 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:21:40 --> Helper loaded: users_helper
INFO - 2018-02-07 06:51:40 --> Language Class Initialized
INFO - 2018-02-07 06:51:40 --> Config Class Initialized
INFO - 2018-02-07 06:51:40 --> Loader Class Initialized
INFO - 2018-02-07 12:21:40 --> Helper loaded: url_helper
INFO - 2018-02-07 12:21:40 --> Database Driver Class Initialized
INFO - 2018-02-07 12:21:40 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:21:40 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:21:40 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:21:40 --> Helper loaded: users_helper
DEBUG - 2018-02-07 12:21:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:21:40 --> Helper loaded: form_helper
INFO - 2018-02-07 12:21:40 --> Form Validation Class Initialized
INFO - 2018-02-07 12:21:40 --> Controller Class Initialized
INFO - 2018-02-07 12:21:40 --> Database Driver Class Initialized
INFO - 2018-02-07 12:21:40 --> Model Class Initialized
DEBUG - 2018-02-07 12:21:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:21:40 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:21:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:21:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:21:40 --> Model Class Initialized
INFO - 2018-02-07 12:21:40 --> Helper loaded: form_helper
INFO - 2018-02-07 12:21:40 --> Form Validation Class Initialized
INFO - 2018-02-07 12:21:40 --> Model Class Initialized
INFO - 2018-02-07 12:21:40 --> Controller Class Initialized
INFO - 2018-02-07 12:21:40 --> Model Class Initialized
INFO - 2018-02-07 12:21:40 --> Model Class Initialized
INFO - 2018-02-07 12:21:40 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:21:40 --> Final output sent to browser
DEBUG - 2018-02-07 12:21:40 --> Total execution time: 0.0990
INFO - 2018-02-07 12:21:40 --> Model Class Initialized
INFO - 2018-02-07 12:21:40 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:21:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:21:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:21:40 --> Model Class Initialized
INFO - 2018-02-07 12:21:40 --> Model Class Initialized
INFO - 2018-02-07 12:21:40 --> Model Class Initialized
INFO - 2018-02-07 12:21:40 --> Model Class Initialized
INFO - 2018-02-07 12:21:40 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:21:40 --> Final output sent to browser
DEBUG - 2018-02-07 12:21:40 --> Total execution time: 0.1001
INFO - 2018-02-07 06:51:44 --> Config Class Initialized
INFO - 2018-02-07 06:51:44 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:51:44 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:51:44 --> Utf8 Class Initialized
INFO - 2018-02-07 06:51:44 --> URI Class Initialized
INFO - 2018-02-07 06:51:44 --> Router Class Initialized
INFO - 2018-02-07 06:51:44 --> Output Class Initialized
INFO - 2018-02-07 06:51:44 --> Security Class Initialized
DEBUG - 2018-02-07 06:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:51:44 --> Input Class Initialized
INFO - 2018-02-07 06:51:44 --> Language Class Initialized
INFO - 2018-02-07 06:51:44 --> Language Class Initialized
INFO - 2018-02-07 06:51:44 --> Config Class Initialized
INFO - 2018-02-07 06:51:44 --> Loader Class Initialized
INFO - 2018-02-07 12:21:44 --> Helper loaded: url_helper
INFO - 2018-02-07 12:21:44 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:21:44 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:21:44 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:21:44 --> Helper loaded: users_helper
INFO - 2018-02-07 12:21:44 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:21:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:21:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:21:44 --> Helper loaded: form_helper
INFO - 2018-02-07 12:21:44 --> Form Validation Class Initialized
INFO - 2018-02-07 12:21:44 --> Controller Class Initialized
INFO - 2018-02-07 12:21:44 --> Model Class Initialized
INFO - 2018-02-07 12:21:44 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:21:44 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:21:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:21:44 --> Model Class Initialized
INFO - 2018-02-07 12:21:44 --> Model Class Initialized
INFO - 2018-02-07 12:21:44 --> Model Class Initialized
INFO - 2018-02-07 12:21:44 --> Model Class Initialized
INFO - 2018-02-07 12:21:44 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:21:44 --> Final output sent to browser
DEBUG - 2018-02-07 12:21:44 --> Total execution time: 0.1113
INFO - 2018-02-07 06:51:45 --> Config Class Initialized
INFO - 2018-02-07 06:51:45 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:51:45 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:51:45 --> Utf8 Class Initialized
INFO - 2018-02-07 06:51:45 --> URI Class Initialized
INFO - 2018-02-07 06:51:45 --> Router Class Initialized
INFO - 2018-02-07 06:51:45 --> Output Class Initialized
INFO - 2018-02-07 06:51:45 --> Security Class Initialized
DEBUG - 2018-02-07 06:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:51:45 --> Input Class Initialized
INFO - 2018-02-07 06:51:45 --> Language Class Initialized
INFO - 2018-02-07 06:51:45 --> Config Class Initialized
INFO - 2018-02-07 06:51:45 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:51:45 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:51:45 --> Utf8 Class Initialized
INFO - 2018-02-07 06:51:45 --> URI Class Initialized
INFO - 2018-02-07 06:51:45 --> Language Class Initialized
INFO - 2018-02-07 06:51:45 --> Config Class Initialized
INFO - 2018-02-07 06:51:45 --> Loader Class Initialized
INFO - 2018-02-07 06:51:45 --> Router Class Initialized
INFO - 2018-02-07 12:21:45 --> Helper loaded: url_helper
INFO - 2018-02-07 12:21:45 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:21:45 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:21:45 --> Helper loaded: permission_helper
INFO - 2018-02-07 06:51:45 --> Output Class Initialized
INFO - 2018-02-07 12:21:45 --> Helper loaded: users_helper
INFO - 2018-02-07 06:51:45 --> Security Class Initialized
DEBUG - 2018-02-07 06:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:51:45 --> Input Class Initialized
INFO - 2018-02-07 06:51:45 --> Language Class Initialized
INFO - 2018-02-07 12:21:45 --> Database Driver Class Initialized
INFO - 2018-02-07 06:51:45 --> Language Class Initialized
INFO - 2018-02-07 06:51:45 --> Config Class Initialized
INFO - 2018-02-07 06:51:45 --> Loader Class Initialized
DEBUG - 2018-02-07 12:21:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:21:45 --> Helper loaded: url_helper
INFO - 2018-02-07 12:21:45 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:21:45 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:21:45 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:21:45 --> Helper loaded: users_helper
INFO - 2018-02-07 12:21:45 --> Helper loaded: form_helper
INFO - 2018-02-07 12:21:45 --> Form Validation Class Initialized
INFO - 2018-02-07 12:21:45 --> Controller Class Initialized
INFO - 2018-02-07 12:21:45 --> Model Class Initialized
INFO - 2018-02-07 12:21:45 --> Helper loaded: inflector_helper
INFO - 2018-02-07 12:21:45 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:21:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:21:45 --> Language file loaded: language/english/rest_controller_lang.php
DEBUG - 2018-02-07 12:21:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:21:45 --> Model Class Initialized
INFO - 2018-02-07 12:21:45 --> Model Class Initialized
INFO - 2018-02-07 12:21:45 --> Model Class Initialized
INFO - 2018-02-07 12:21:45 --> Model Class Initialized
INFO - 2018-02-07 12:21:45 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:21:45 --> Helper loaded: form_helper
INFO - 2018-02-07 12:21:45 --> Form Validation Class Initialized
INFO - 2018-02-07 12:21:45 --> Final output sent to browser
INFO - 2018-02-07 12:21:45 --> Controller Class Initialized
DEBUG - 2018-02-07 12:21:45 --> Total execution time: 0.1113
INFO - 2018-02-07 12:21:45 --> Model Class Initialized
INFO - 2018-02-07 12:21:45 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:21:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:21:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:21:45 --> Model Class Initialized
INFO - 2018-02-07 12:21:45 --> Model Class Initialized
INFO - 2018-02-07 12:21:45 --> Model Class Initialized
INFO - 2018-02-07 12:21:45 --> Model Class Initialized
INFO - 2018-02-07 12:21:45 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:21:45 --> Final output sent to browser
DEBUG - 2018-02-07 12:21:45 --> Total execution time: 0.1065
INFO - 2018-02-07 06:51:46 --> Config Class Initialized
INFO - 2018-02-07 06:51:46 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:51:46 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:51:46 --> Utf8 Class Initialized
INFO - 2018-02-07 06:51:46 --> URI Class Initialized
INFO - 2018-02-07 06:51:46 --> Router Class Initialized
INFO - 2018-02-07 06:51:46 --> Output Class Initialized
INFO - 2018-02-07 06:51:46 --> Security Class Initialized
DEBUG - 2018-02-07 06:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:51:46 --> Input Class Initialized
INFO - 2018-02-07 06:51:46 --> Config Class Initialized
INFO - 2018-02-07 06:51:46 --> Hooks Class Initialized
INFO - 2018-02-07 06:51:46 --> Language Class Initialized
DEBUG - 2018-02-07 06:51:46 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:51:46 --> Utf8 Class Initialized
INFO - 2018-02-07 06:51:46 --> URI Class Initialized
INFO - 2018-02-07 06:51:46 --> Router Class Initialized
INFO - 2018-02-07 06:51:46 --> Output Class Initialized
INFO - 2018-02-07 06:51:46 --> Security Class Initialized
DEBUG - 2018-02-07 06:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:51:46 --> Input Class Initialized
INFO - 2018-02-07 06:51:46 --> Language Class Initialized
INFO - 2018-02-07 06:51:46 --> Language Class Initialized
INFO - 2018-02-07 06:51:46 --> Config Class Initialized
INFO - 2018-02-07 06:51:46 --> Loader Class Initialized
INFO - 2018-02-07 12:21:46 --> Helper loaded: url_helper
INFO - 2018-02-07 12:21:46 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:21:46 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:21:46 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:21:46 --> Helper loaded: users_helper
INFO - 2018-02-07 06:51:46 --> Language Class Initialized
INFO - 2018-02-07 06:51:46 --> Config Class Initialized
INFO - 2018-02-07 06:51:46 --> Loader Class Initialized
INFO - 2018-02-07 12:21:46 --> Helper loaded: url_helper
INFO - 2018-02-07 12:21:46 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:21:46 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:21:46 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:21:46 --> Helper loaded: users_helper
INFO - 2018-02-07 12:21:46 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:21:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:21:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:21:46 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:21:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:21:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:21:46 --> Helper loaded: form_helper
INFO - 2018-02-07 12:21:46 --> Form Validation Class Initialized
INFO - 2018-02-07 12:21:46 --> Controller Class Initialized
INFO - 2018-02-07 12:21:46 --> Helper loaded: form_helper
INFO - 2018-02-07 12:21:46 --> Form Validation Class Initialized
INFO - 2018-02-07 12:21:46 --> Controller Class Initialized
INFO - 2018-02-07 12:21:46 --> Model Class Initialized
INFO - 2018-02-07 12:21:46 --> Helper loaded: inflector_helper
INFO - 2018-02-07 12:21:46 --> Model Class Initialized
INFO - 2018-02-07 12:21:46 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:21:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-02-07 12:21:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:21:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:21:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:21:46 --> Model Class Initialized
INFO - 2018-02-07 12:21:46 --> Model Class Initialized
INFO - 2018-02-07 12:21:46 --> Model Class Initialized
INFO - 2018-02-07 12:21:46 --> Model Class Initialized
INFO - 2018-02-07 12:21:46 --> Model Class Initialized
INFO - 2018-02-07 12:21:46 --> Model Class Initialized
INFO - 2018-02-07 12:21:46 --> Model Class Initialized
INFO - 2018-02-07 12:21:46 --> Model Class Initialized
INFO - 2018-02-07 12:21:46 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:21:46 --> Model Class Initialized
INFO - 2018-02-07 12:21:46 --> Model Class Initialized
INFO - 2018-02-07 12:21:46 --> Model Class Initialized
INFO - 2018-02-07 12:21:46 --> Model Class Initialized
INFO - 2018-02-07 12:21:46 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:21:46 --> Final output sent to browser
INFO - 2018-02-07 12:21:46 --> Final output sent to browser
DEBUG - 2018-02-07 12:21:46 --> Total execution time: 0.1232
DEBUG - 2018-02-07 12:21:46 --> Total execution time: 0.0998
INFO - 2018-02-07 06:51:47 --> Config Class Initialized
INFO - 2018-02-07 06:51:47 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:51:47 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:51:47 --> Utf8 Class Initialized
INFO - 2018-02-07 06:51:47 --> URI Class Initialized
INFO - 2018-02-07 06:51:47 --> Router Class Initialized
INFO - 2018-02-07 06:51:47 --> Output Class Initialized
INFO - 2018-02-07 06:51:47 --> Security Class Initialized
DEBUG - 2018-02-07 06:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:51:47 --> Input Class Initialized
INFO - 2018-02-07 06:51:47 --> Language Class Initialized
INFO - 2018-02-07 06:51:47 --> Language Class Initialized
INFO - 2018-02-07 06:51:47 --> Config Class Initialized
INFO - 2018-02-07 06:51:47 --> Loader Class Initialized
INFO - 2018-02-07 12:21:47 --> Helper loaded: url_helper
INFO - 2018-02-07 12:21:47 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:21:47 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:21:47 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:21:47 --> Helper loaded: users_helper
INFO - 2018-02-07 12:21:47 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:21:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:21:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:21:47 --> Helper loaded: form_helper
INFO - 2018-02-07 12:21:47 --> Form Validation Class Initialized
INFO - 2018-02-07 12:21:47 --> Controller Class Initialized
INFO - 2018-02-07 12:21:47 --> Model Class Initialized
INFO - 2018-02-07 12:21:47 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:21:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:21:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:21:47 --> Model Class Initialized
INFO - 2018-02-07 12:21:47 --> Model Class Initialized
INFO - 2018-02-07 12:21:47 --> Model Class Initialized
INFO - 2018-02-07 12:21:47 --> Model Class Initialized
INFO - 2018-02-07 12:21:47 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:21:47 --> Final output sent to browser
DEBUG - 2018-02-07 12:21:47 --> Total execution time: 0.1155
INFO - 2018-02-07 06:51:49 --> Config Class Initialized
INFO - 2018-02-07 06:51:49 --> Hooks Class Initialized
INFO - 2018-02-07 06:51:49 --> Config Class Initialized
INFO - 2018-02-07 06:51:49 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:51:49 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:51:49 --> Utf8 Class Initialized
DEBUG - 2018-02-07 06:51:49 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:51:49 --> Utf8 Class Initialized
INFO - 2018-02-07 06:51:49 --> URI Class Initialized
INFO - 2018-02-07 06:51:49 --> URI Class Initialized
INFO - 2018-02-07 06:51:49 --> Router Class Initialized
INFO - 2018-02-07 06:51:49 --> Router Class Initialized
INFO - 2018-02-07 06:51:49 --> Output Class Initialized
INFO - 2018-02-07 06:51:49 --> Output Class Initialized
INFO - 2018-02-07 06:51:49 --> Security Class Initialized
INFO - 2018-02-07 06:51:49 --> Security Class Initialized
DEBUG - 2018-02-07 06:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:51:49 --> Input Class Initialized
DEBUG - 2018-02-07 06:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:51:49 --> Input Class Initialized
INFO - 2018-02-07 06:51:49 --> Language Class Initialized
INFO - 2018-02-07 06:51:49 --> Language Class Initialized
INFO - 2018-02-07 06:51:49 --> Language Class Initialized
INFO - 2018-02-07 06:51:49 --> Config Class Initialized
INFO - 2018-02-07 06:51:49 --> Loader Class Initialized
INFO - 2018-02-07 06:51:49 --> Language Class Initialized
INFO - 2018-02-07 06:51:49 --> Config Class Initialized
INFO - 2018-02-07 06:51:49 --> Loader Class Initialized
INFO - 2018-02-07 12:21:49 --> Helper loaded: url_helper
INFO - 2018-02-07 12:21:49 --> Helper loaded: url_helper
INFO - 2018-02-07 12:21:49 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:21:49 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:21:49 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:21:49 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:21:49 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:21:49 --> Helper loaded: users_helper
INFO - 2018-02-07 12:21:49 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:21:49 --> Helper loaded: users_helper
INFO - 2018-02-07 12:21:49 --> Database Driver Class Initialized
INFO - 2018-02-07 12:21:49 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:21:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:21:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-07 12:21:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:21:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:21:49 --> Helper loaded: form_helper
INFO - 2018-02-07 12:21:49 --> Form Validation Class Initialized
INFO - 2018-02-07 12:21:49 --> Controller Class Initialized
INFO - 2018-02-07 12:21:49 --> Helper loaded: form_helper
INFO - 2018-02-07 12:21:49 --> Form Validation Class Initialized
INFO - 2018-02-07 12:21:49 --> Controller Class Initialized
INFO - 2018-02-07 12:21:49 --> Model Class Initialized
INFO - 2018-02-07 12:21:49 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:21:49 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:21:49 --> Model Class Initialized
INFO - 2018-02-07 12:21:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:21:49 --> Helper loaded: inflector_helper
INFO - 2018-02-07 12:21:49 --> Model Class Initialized
INFO - 2018-02-07 12:21:49 --> Model Class Initialized
INFO - 2018-02-07 12:21:49 --> Model Class Initialized
INFO - 2018-02-07 12:21:49 --> Model Class Initialized
INFO - 2018-02-07 12:21:49 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-02-07 12:21:49 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:21:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:21:49 --> Model Class Initialized
INFO - 2018-02-07 12:21:49 --> Model Class Initialized
INFO - 2018-02-07 12:21:49 --> Final output sent to browser
DEBUG - 2018-02-07 12:21:49 --> Total execution time: 0.1067
INFO - 2018-02-07 12:21:49 --> Model Class Initialized
INFO - 2018-02-07 12:21:49 --> Model Class Initialized
INFO - 2018-02-07 12:21:49 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:21:49 --> Final output sent to browser
DEBUG - 2018-02-07 12:21:49 --> Total execution time: 0.1128
INFO - 2018-02-07 06:51:49 --> Config Class Initialized
INFO - 2018-02-07 06:51:49 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:51:49 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:51:49 --> Utf8 Class Initialized
INFO - 2018-02-07 06:51:49 --> URI Class Initialized
INFO - 2018-02-07 06:51:49 --> Router Class Initialized
INFO - 2018-02-07 06:51:49 --> Output Class Initialized
INFO - 2018-02-07 06:51:49 --> Security Class Initialized
DEBUG - 2018-02-07 06:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:51:49 --> Input Class Initialized
INFO - 2018-02-07 06:51:49 --> Language Class Initialized
INFO - 2018-02-07 06:51:49 --> Language Class Initialized
INFO - 2018-02-07 06:51:49 --> Config Class Initialized
INFO - 2018-02-07 06:51:49 --> Loader Class Initialized
INFO - 2018-02-07 12:21:49 --> Helper loaded: url_helper
INFO - 2018-02-07 12:21:49 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:21:49 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:21:49 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:21:49 --> Helper loaded: users_helper
INFO - 2018-02-07 12:21:49 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:21:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:21:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:21:49 --> Helper loaded: form_helper
INFO - 2018-02-07 12:21:49 --> Form Validation Class Initialized
INFO - 2018-02-07 12:21:49 --> Controller Class Initialized
INFO - 2018-02-07 12:21:49 --> Model Class Initialized
INFO - 2018-02-07 12:21:49 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:21:49 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:21:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:21:49 --> Model Class Initialized
INFO - 2018-02-07 12:21:49 --> Model Class Initialized
INFO - 2018-02-07 12:21:49 --> Model Class Initialized
INFO - 2018-02-07 12:21:49 --> Model Class Initialized
INFO - 2018-02-07 12:21:49 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:21:49 --> Final output sent to browser
DEBUG - 2018-02-07 12:21:49 --> Total execution time: 0.1156
INFO - 2018-02-07 06:51:49 --> Config Class Initialized
INFO - 2018-02-07 06:51:49 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:51:49 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:51:49 --> Utf8 Class Initialized
INFO - 2018-02-07 06:51:49 --> URI Class Initialized
INFO - 2018-02-07 06:51:49 --> Router Class Initialized
INFO - 2018-02-07 06:51:49 --> Output Class Initialized
INFO - 2018-02-07 06:51:49 --> Security Class Initialized
DEBUG - 2018-02-07 06:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:51:49 --> Input Class Initialized
INFO - 2018-02-07 06:51:49 --> Language Class Initialized
INFO - 2018-02-07 06:51:49 --> Language Class Initialized
INFO - 2018-02-07 06:51:49 --> Config Class Initialized
INFO - 2018-02-07 06:51:49 --> Loader Class Initialized
INFO - 2018-02-07 12:21:49 --> Helper loaded: url_helper
INFO - 2018-02-07 12:21:49 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:21:49 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:21:49 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:21:49 --> Helper loaded: users_helper
INFO - 2018-02-07 12:21:49 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:21:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:21:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:21:49 --> Helper loaded: form_helper
INFO - 2018-02-07 12:21:49 --> Form Validation Class Initialized
INFO - 2018-02-07 12:21:49 --> Controller Class Initialized
INFO - 2018-02-07 12:21:49 --> Model Class Initialized
INFO - 2018-02-07 12:21:49 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:21:49 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:21:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:21:49 --> Model Class Initialized
INFO - 2018-02-07 12:21:49 --> Model Class Initialized
INFO - 2018-02-07 12:21:49 --> Model Class Initialized
INFO - 2018-02-07 12:21:49 --> Model Class Initialized
INFO - 2018-02-07 12:21:49 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:21:49 --> Final output sent to browser
DEBUG - 2018-02-07 12:21:49 --> Total execution time: 0.1056
INFO - 2018-02-07 06:51:52 --> Config Class Initialized
INFO - 2018-02-07 06:51:52 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:51:52 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:51:52 --> Utf8 Class Initialized
INFO - 2018-02-07 06:51:52 --> URI Class Initialized
INFO - 2018-02-07 06:51:52 --> Router Class Initialized
INFO - 2018-02-07 06:51:52 --> Output Class Initialized
INFO - 2018-02-07 06:51:52 --> Security Class Initialized
DEBUG - 2018-02-07 06:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:51:52 --> Input Class Initialized
INFO - 2018-02-07 06:51:52 --> Language Class Initialized
INFO - 2018-02-07 06:51:52 --> Language Class Initialized
INFO - 2018-02-07 06:51:52 --> Config Class Initialized
INFO - 2018-02-07 06:51:52 --> Loader Class Initialized
INFO - 2018-02-07 12:21:52 --> Helper loaded: url_helper
INFO - 2018-02-07 12:21:52 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:21:52 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:21:52 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:21:52 --> Helper loaded: users_helper
INFO - 2018-02-07 12:21:52 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:21:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:21:52 --> Helper loaded: form_helper
INFO - 2018-02-07 12:21:52 --> Form Validation Class Initialized
INFO - 2018-02-07 12:21:52 --> Controller Class Initialized
INFO - 2018-02-07 12:21:52 --> Model Class Initialized
INFO - 2018-02-07 12:21:52 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:21:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:21:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:21:52 --> Model Class Initialized
INFO - 2018-02-07 12:21:52 --> Model Class Initialized
INFO - 2018-02-07 12:21:52 --> Model Class Initialized
INFO - 2018-02-07 12:21:52 --> Model Class Initialized
INFO - 2018-02-07 12:21:52 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:21:52 --> Final output sent to browser
DEBUG - 2018-02-07 12:21:52 --> Total execution time: 0.1138
INFO - 2018-02-07 06:51:53 --> Config Class Initialized
INFO - 2018-02-07 06:51:53 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:51:53 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:51:53 --> Utf8 Class Initialized
INFO - 2018-02-07 06:51:53 --> URI Class Initialized
INFO - 2018-02-07 06:51:53 --> Router Class Initialized
INFO - 2018-02-07 06:51:53 --> Output Class Initialized
INFO - 2018-02-07 06:51:53 --> Security Class Initialized
INFO - 2018-02-07 06:51:53 --> Config Class Initialized
INFO - 2018-02-07 06:51:53 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:51:53 --> Input Class Initialized
INFO - 2018-02-07 06:51:53 --> Language Class Initialized
DEBUG - 2018-02-07 06:51:53 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:51:53 --> Utf8 Class Initialized
INFO - 2018-02-07 06:51:53 --> URI Class Initialized
INFO - 2018-02-07 06:51:53 --> Router Class Initialized
INFO - 2018-02-07 06:51:53 --> Language Class Initialized
INFO - 2018-02-07 06:51:53 --> Config Class Initialized
INFO - 2018-02-07 06:51:53 --> Loader Class Initialized
INFO - 2018-02-07 06:51:53 --> Output Class Initialized
INFO - 2018-02-07 12:21:53 --> Helper loaded: url_helper
INFO - 2018-02-07 12:21:53 --> Helper loaded: notification_helper
INFO - 2018-02-07 06:51:53 --> Security Class Initialized
INFO - 2018-02-07 12:21:53 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:21:53 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:21:53 --> Helper loaded: users_helper
DEBUG - 2018-02-07 06:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:51:53 --> Input Class Initialized
INFO - 2018-02-07 06:51:53 --> Language Class Initialized
INFO - 2018-02-07 12:21:53 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:21:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:21:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 06:51:53 --> Language Class Initialized
INFO - 2018-02-07 06:51:53 --> Config Class Initialized
INFO - 2018-02-07 06:51:53 --> Loader Class Initialized
INFO - 2018-02-07 12:21:53 --> Helper loaded: url_helper
INFO - 2018-02-07 12:21:53 --> Helper loaded: form_helper
INFO - 2018-02-07 12:21:53 --> Form Validation Class Initialized
INFO - 2018-02-07 12:21:53 --> Controller Class Initialized
INFO - 2018-02-07 12:21:53 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:21:53 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:21:53 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:21:53 --> Helper loaded: users_helper
INFO - 2018-02-07 12:21:53 --> Model Class Initialized
INFO - 2018-02-07 12:21:53 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:21:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:21:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:21:53 --> Model Class Initialized
INFO - 2018-02-07 12:21:53 --> Model Class Initialized
INFO - 2018-02-07 12:21:53 --> Model Class Initialized
INFO - 2018-02-07 12:21:53 --> Model Class Initialized
INFO - 2018-02-07 12:21:53 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:21:53 --> Final output sent to browser
DEBUG - 2018-02-07 12:21:53 --> Total execution time: 0.0833
INFO - 2018-02-07 12:21:53 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:21:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:21:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:21:53 --> Helper loaded: form_helper
INFO - 2018-02-07 12:21:53 --> Form Validation Class Initialized
INFO - 2018-02-07 12:21:53 --> Controller Class Initialized
INFO - 2018-02-07 12:21:53 --> Model Class Initialized
INFO - 2018-02-07 12:21:53 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:21:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:21:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:21:54 --> Model Class Initialized
INFO - 2018-02-07 12:21:54 --> Model Class Initialized
INFO - 2018-02-07 12:21:54 --> Model Class Initialized
INFO - 2018-02-07 12:21:54 --> Model Class Initialized
INFO - 2018-02-07 12:21:54 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:21:54 --> Final output sent to browser
DEBUG - 2018-02-07 12:21:54 --> Total execution time: 0.1140
INFO - 2018-02-07 06:51:55 --> Config Class Initialized
INFO - 2018-02-07 06:51:55 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:51:55 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:51:55 --> Utf8 Class Initialized
INFO - 2018-02-07 06:51:55 --> URI Class Initialized
INFO - 2018-02-07 06:51:55 --> Router Class Initialized
INFO - 2018-02-07 06:51:55 --> Output Class Initialized
INFO - 2018-02-07 06:51:55 --> Security Class Initialized
DEBUG - 2018-02-07 06:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:51:55 --> Input Class Initialized
INFO - 2018-02-07 06:51:55 --> Language Class Initialized
INFO - 2018-02-07 06:51:55 --> Language Class Initialized
INFO - 2018-02-07 06:51:55 --> Config Class Initialized
INFO - 2018-02-07 06:51:55 --> Loader Class Initialized
INFO - 2018-02-07 12:21:55 --> Helper loaded: url_helper
INFO - 2018-02-07 12:21:55 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:21:55 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:21:55 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:21:55 --> Helper loaded: users_helper
INFO - 2018-02-07 12:21:55 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:21:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:21:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:21:55 --> Helper loaded: form_helper
INFO - 2018-02-07 12:21:55 --> Form Validation Class Initialized
INFO - 2018-02-07 12:21:55 --> Controller Class Initialized
INFO - 2018-02-07 12:21:55 --> Model Class Initialized
INFO - 2018-02-07 12:21:55 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:21:55 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:21:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:21:55 --> Model Class Initialized
INFO - 2018-02-07 12:21:55 --> Model Class Initialized
INFO - 2018-02-07 12:21:55 --> Model Class Initialized
INFO - 2018-02-07 12:21:55 --> Model Class Initialized
INFO - 2018-02-07 12:21:55 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:21:55 --> Final output sent to browser
DEBUG - 2018-02-07 12:21:55 --> Total execution time: 0.1055
INFO - 2018-02-07 06:51:57 --> Config Class Initialized
INFO - 2018-02-07 06:51:57 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:51:57 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:51:57 --> Utf8 Class Initialized
INFO - 2018-02-07 06:51:57 --> URI Class Initialized
INFO - 2018-02-07 06:51:57 --> Router Class Initialized
INFO - 2018-02-07 06:51:57 --> Output Class Initialized
INFO - 2018-02-07 06:51:57 --> Security Class Initialized
DEBUG - 2018-02-07 06:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:51:57 --> Input Class Initialized
INFO - 2018-02-07 06:51:57 --> Language Class Initialized
INFO - 2018-02-07 06:51:57 --> Config Class Initialized
INFO - 2018-02-07 06:51:57 --> Hooks Class Initialized
INFO - 2018-02-07 06:51:57 --> Language Class Initialized
INFO - 2018-02-07 06:51:57 --> Config Class Initialized
INFO - 2018-02-07 06:51:57 --> Loader Class Initialized
INFO - 2018-02-07 12:21:57 --> Helper loaded: url_helper
DEBUG - 2018-02-07 06:51:57 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:51:57 --> Utf8 Class Initialized
INFO - 2018-02-07 12:21:57 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:21:57 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:21:57 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:21:57 --> Helper loaded: users_helper
INFO - 2018-02-07 06:51:57 --> URI Class Initialized
INFO - 2018-02-07 06:51:57 --> Router Class Initialized
INFO - 2018-02-07 06:51:57 --> Output Class Initialized
INFO - 2018-02-07 06:51:57 --> Security Class Initialized
INFO - 2018-02-07 12:21:57 --> Database Driver Class Initialized
DEBUG - 2018-02-07 06:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:51:57 --> Input Class Initialized
INFO - 2018-02-07 06:51:57 --> Language Class Initialized
DEBUG - 2018-02-07 12:21:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:21:57 --> Helper loaded: form_helper
INFO - 2018-02-07 12:21:57 --> Form Validation Class Initialized
INFO - 2018-02-07 12:21:57 --> Controller Class Initialized
INFO - 2018-02-07 06:51:57 --> Language Class Initialized
INFO - 2018-02-07 06:51:57 --> Config Class Initialized
INFO - 2018-02-07 06:51:57 --> Loader Class Initialized
INFO - 2018-02-07 12:21:57 --> Helper loaded: url_helper
INFO - 2018-02-07 12:21:57 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:21:57 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:21:57 --> Model Class Initialized
INFO - 2018-02-07 12:21:57 --> Helper loaded: inflector_helper
INFO - 2018-02-07 12:21:57 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:21:57 --> Helper loaded: users_helper
DEBUG - 2018-02-07 12:21:57 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:21:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:21:57 --> Model Class Initialized
INFO - 2018-02-07 12:21:57 --> Model Class Initialized
INFO - 2018-02-07 12:21:57 --> Model Class Initialized
INFO - 2018-02-07 12:21:57 --> Model Class Initialized
INFO - 2018-02-07 12:21:57 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:21:57 --> Final output sent to browser
DEBUG - 2018-02-07 12:21:57 --> Total execution time: 0.0953
INFO - 2018-02-07 12:21:57 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:21:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:21:57 --> Helper loaded: form_helper
INFO - 2018-02-07 12:21:57 --> Form Validation Class Initialized
INFO - 2018-02-07 12:21:57 --> Controller Class Initialized
INFO - 2018-02-07 12:21:57 --> Model Class Initialized
INFO - 2018-02-07 12:21:57 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:21:57 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:21:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:21:57 --> Model Class Initialized
INFO - 2018-02-07 12:21:57 --> Model Class Initialized
INFO - 2018-02-07 12:21:57 --> Model Class Initialized
INFO - 2018-02-07 12:21:57 --> Model Class Initialized
INFO - 2018-02-07 12:21:57 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:21:57 --> Final output sent to browser
DEBUG - 2018-02-07 12:21:57 --> Total execution time: 0.1087
INFO - 2018-02-07 06:51:58 --> Config Class Initialized
INFO - 2018-02-07 06:51:58 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:51:58 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:51:58 --> Utf8 Class Initialized
INFO - 2018-02-07 06:51:58 --> URI Class Initialized
INFO - 2018-02-07 06:51:58 --> Router Class Initialized
INFO - 2018-02-07 06:51:58 --> Output Class Initialized
INFO - 2018-02-07 06:51:58 --> Security Class Initialized
DEBUG - 2018-02-07 06:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:51:58 --> Input Class Initialized
INFO - 2018-02-07 06:51:58 --> Language Class Initialized
INFO - 2018-02-07 06:51:58 --> Language Class Initialized
INFO - 2018-02-07 06:51:58 --> Config Class Initialized
INFO - 2018-02-07 06:51:58 --> Loader Class Initialized
INFO - 2018-02-07 12:21:58 --> Helper loaded: url_helper
INFO - 2018-02-07 12:21:58 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:21:58 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:21:58 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:21:58 --> Helper loaded: users_helper
INFO - 2018-02-07 12:21:58 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:21:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:21:58 --> Helper loaded: form_helper
INFO - 2018-02-07 12:21:58 --> Form Validation Class Initialized
INFO - 2018-02-07 12:21:58 --> Controller Class Initialized
INFO - 2018-02-07 12:21:59 --> Model Class Initialized
INFO - 2018-02-07 12:21:59 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:21:59 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:21:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:21:59 --> Model Class Initialized
INFO - 2018-02-07 12:21:59 --> Model Class Initialized
INFO - 2018-02-07 12:21:59 --> Model Class Initialized
INFO - 2018-02-07 12:21:59 --> Model Class Initialized
INFO - 2018-02-07 12:21:59 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:21:59 --> Final output sent to browser
DEBUG - 2018-02-07 12:21:59 --> Total execution time: 0.1023
INFO - 2018-02-07 06:52:10 --> Config Class Initialized
INFO - 2018-02-07 06:52:10 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:52:10 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:52:10 --> Utf8 Class Initialized
INFO - 2018-02-07 06:52:10 --> URI Class Initialized
INFO - 2018-02-07 06:52:10 --> Router Class Initialized
INFO - 2018-02-07 06:52:10 --> Output Class Initialized
INFO - 2018-02-07 06:52:10 --> Security Class Initialized
DEBUG - 2018-02-07 06:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:52:10 --> Input Class Initialized
INFO - 2018-02-07 06:52:10 --> Language Class Initialized
INFO - 2018-02-07 06:52:10 --> Language Class Initialized
INFO - 2018-02-07 06:52:10 --> Config Class Initialized
INFO - 2018-02-07 06:52:10 --> Loader Class Initialized
INFO - 2018-02-07 12:22:10 --> Helper loaded: url_helper
INFO - 2018-02-07 12:22:10 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:22:10 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:22:10 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:22:10 --> Helper loaded: users_helper
INFO - 2018-02-07 12:22:10 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:22:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:22:10 --> Helper loaded: form_helper
INFO - 2018-02-07 12:22:10 --> Form Validation Class Initialized
INFO - 2018-02-07 12:22:10 --> Controller Class Initialized
INFO - 2018-02-07 12:22:10 --> Model Class Initialized
INFO - 2018-02-07 12:22:10 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:22:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:22:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:22:10 --> Model Class Initialized
INFO - 2018-02-07 12:22:10 --> Model Class Initialized
INFO - 2018-02-07 12:22:10 --> Model Class Initialized
INFO - 2018-02-07 12:22:10 --> Model Class Initialized
INFO - 2018-02-07 12:22:10 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:22:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-07 12:22:10 --> Final output sent to browser
DEBUG - 2018-02-07 12:22:10 --> Total execution time: 0.1098
INFO - 2018-02-07 06:52:10 --> Config Class Initialized
INFO - 2018-02-07 06:52:10 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:52:10 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:52:10 --> Utf8 Class Initialized
INFO - 2018-02-07 06:52:10 --> URI Class Initialized
INFO - 2018-02-07 06:52:10 --> Router Class Initialized
INFO - 2018-02-07 06:52:10 --> Output Class Initialized
INFO - 2018-02-07 06:52:10 --> Security Class Initialized
DEBUG - 2018-02-07 06:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:52:10 --> Input Class Initialized
INFO - 2018-02-07 06:52:10 --> Language Class Initialized
INFO - 2018-02-07 06:52:10 --> Language Class Initialized
INFO - 2018-02-07 06:52:10 --> Config Class Initialized
INFO - 2018-02-07 06:52:10 --> Loader Class Initialized
INFO - 2018-02-07 12:22:10 --> Helper loaded: url_helper
INFO - 2018-02-07 12:22:10 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:22:10 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:22:10 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:22:10 --> Helper loaded: users_helper
INFO - 2018-02-07 12:22:10 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:22:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:22:10 --> Helper loaded: form_helper
INFO - 2018-02-07 12:22:10 --> Form Validation Class Initialized
INFO - 2018-02-07 12:22:10 --> Controller Class Initialized
INFO - 2018-02-07 12:22:10 --> Model Class Initialized
INFO - 2018-02-07 12:22:10 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:22:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:22:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:22:10 --> Model Class Initialized
INFO - 2018-02-07 12:22:10 --> Model Class Initialized
INFO - 2018-02-07 12:22:10 --> Model Class Initialized
INFO - 2018-02-07 12:22:10 --> Model Class Initialized
INFO - 2018-02-07 12:22:10 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:22:10 --> Final output sent to browser
DEBUG - 2018-02-07 12:22:10 --> Total execution time: 0.1148
INFO - 2018-02-07 06:52:11 --> Config Class Initialized
INFO - 2018-02-07 06:52:11 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:52:11 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:52:11 --> Utf8 Class Initialized
INFO - 2018-02-07 06:52:11 --> URI Class Initialized
INFO - 2018-02-07 06:52:11 --> Router Class Initialized
INFO - 2018-02-07 06:52:11 --> Output Class Initialized
INFO - 2018-02-07 06:52:11 --> Security Class Initialized
DEBUG - 2018-02-07 06:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:52:11 --> Input Class Initialized
INFO - 2018-02-07 06:52:11 --> Language Class Initialized
INFO - 2018-02-07 06:52:11 --> Language Class Initialized
INFO - 2018-02-07 06:52:11 --> Config Class Initialized
INFO - 2018-02-07 06:52:11 --> Loader Class Initialized
INFO - 2018-02-07 12:22:11 --> Helper loaded: url_helper
INFO - 2018-02-07 12:22:11 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:22:11 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:22:11 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:22:11 --> Helper loaded: users_helper
INFO - 2018-02-07 12:22:11 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:22:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:22:11 --> Helper loaded: form_helper
INFO - 2018-02-07 12:22:11 --> Form Validation Class Initialized
INFO - 2018-02-07 12:22:11 --> Controller Class Initialized
INFO - 2018-02-07 12:22:11 --> Model Class Initialized
INFO - 2018-02-07 12:22:11 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:22:11 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:22:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:22:11 --> Model Class Initialized
INFO - 2018-02-07 12:22:11 --> Model Class Initialized
INFO - 2018-02-07 12:22:11 --> Model Class Initialized
INFO - 2018-02-07 12:22:11 --> Model Class Initialized
INFO - 2018-02-07 12:22:11 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:22:11 --> Final output sent to browser
DEBUG - 2018-02-07 12:22:11 --> Total execution time: 0.0801
INFO - 2018-02-07 06:52:13 --> Config Class Initialized
INFO - 2018-02-07 06:52:13 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:52:13 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:52:13 --> Utf8 Class Initialized
INFO - 2018-02-07 06:52:13 --> URI Class Initialized
INFO - 2018-02-07 06:52:13 --> Router Class Initialized
INFO - 2018-02-07 06:52:13 --> Output Class Initialized
INFO - 2018-02-07 06:52:13 --> Security Class Initialized
DEBUG - 2018-02-07 06:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:52:13 --> Input Class Initialized
INFO - 2018-02-07 06:52:13 --> Language Class Initialized
INFO - 2018-02-07 06:52:13 --> Language Class Initialized
INFO - 2018-02-07 06:52:13 --> Config Class Initialized
INFO - 2018-02-07 06:52:13 --> Loader Class Initialized
INFO - 2018-02-07 12:22:13 --> Helper loaded: url_helper
INFO - 2018-02-07 12:22:13 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:22:13 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:22:13 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:22:13 --> Helper loaded: users_helper
INFO - 2018-02-07 12:22:13 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:22:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:22:13 --> Helper loaded: form_helper
INFO - 2018-02-07 12:22:13 --> Form Validation Class Initialized
INFO - 2018-02-07 12:22:13 --> Controller Class Initialized
INFO - 2018-02-07 12:22:13 --> Model Class Initialized
INFO - 2018-02-07 12:22:13 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:22:13 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:22:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:22:13 --> Model Class Initialized
INFO - 2018-02-07 12:22:13 --> Model Class Initialized
INFO - 2018-02-07 12:22:13 --> Model Class Initialized
INFO - 2018-02-07 12:22:13 --> Model Class Initialized
INFO - 2018-02-07 12:22:13 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:22:13 --> Final output sent to browser
DEBUG - 2018-02-07 12:22:13 --> Total execution time: 0.1123
INFO - 2018-02-07 06:52:13 --> Config Class Initialized
INFO - 2018-02-07 06:52:13 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:52:13 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:52:13 --> Utf8 Class Initialized
INFO - 2018-02-07 06:52:13 --> URI Class Initialized
INFO - 2018-02-07 06:52:13 --> Router Class Initialized
INFO - 2018-02-07 06:52:13 --> Output Class Initialized
INFO - 2018-02-07 06:52:13 --> Security Class Initialized
DEBUG - 2018-02-07 06:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:52:13 --> Input Class Initialized
INFO - 2018-02-07 06:52:13 --> Language Class Initialized
INFO - 2018-02-07 06:52:13 --> Language Class Initialized
INFO - 2018-02-07 06:52:13 --> Config Class Initialized
INFO - 2018-02-07 06:52:13 --> Loader Class Initialized
INFO - 2018-02-07 12:22:13 --> Helper loaded: url_helper
INFO - 2018-02-07 12:22:13 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:22:13 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:22:13 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:22:13 --> Helper loaded: users_helper
INFO - 2018-02-07 12:22:14 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:22:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:22:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:22:14 --> Helper loaded: form_helper
INFO - 2018-02-07 12:22:14 --> Form Validation Class Initialized
INFO - 2018-02-07 12:22:14 --> Controller Class Initialized
INFO - 2018-02-07 12:22:14 --> Model Class Initialized
INFO - 2018-02-07 12:22:14 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:22:14 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:22:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:22:14 --> Model Class Initialized
INFO - 2018-02-07 12:22:14 --> Model Class Initialized
INFO - 2018-02-07 12:22:14 --> Model Class Initialized
INFO - 2018-02-07 12:22:14 --> Model Class Initialized
INFO - 2018-02-07 12:22:14 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:22:14 --> Final output sent to browser
DEBUG - 2018-02-07 12:22:14 --> Total execution time: 0.1012
INFO - 2018-02-07 06:52:15 --> Config Class Initialized
INFO - 2018-02-07 06:52:15 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:52:15 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:52:15 --> Utf8 Class Initialized
INFO - 2018-02-07 06:52:15 --> URI Class Initialized
INFO - 2018-02-07 06:52:15 --> Router Class Initialized
INFO - 2018-02-07 06:52:15 --> Output Class Initialized
INFO - 2018-02-07 06:52:15 --> Security Class Initialized
DEBUG - 2018-02-07 06:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:52:15 --> Input Class Initialized
INFO - 2018-02-07 06:52:15 --> Language Class Initialized
INFO - 2018-02-07 06:52:15 --> Language Class Initialized
INFO - 2018-02-07 06:52:15 --> Config Class Initialized
INFO - 2018-02-07 06:52:15 --> Loader Class Initialized
INFO - 2018-02-07 12:22:15 --> Helper loaded: url_helper
INFO - 2018-02-07 12:22:15 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:22:15 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:22:15 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:22:15 --> Helper loaded: users_helper
INFO - 2018-02-07 06:52:15 --> Config Class Initialized
INFO - 2018-02-07 06:52:15 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:52:15 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:52:15 --> Utf8 Class Initialized
INFO - 2018-02-07 06:52:15 --> URI Class Initialized
INFO - 2018-02-07 12:22:15 --> Database Driver Class Initialized
INFO - 2018-02-07 06:52:15 --> Router Class Initialized
DEBUG - 2018-02-07 12:22:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 06:52:15 --> Output Class Initialized
INFO - 2018-02-07 06:52:15 --> Security Class Initialized
INFO - 2018-02-07 12:22:15 --> Helper loaded: form_helper
INFO - 2018-02-07 12:22:15 --> Form Validation Class Initialized
INFO - 2018-02-07 12:22:15 --> Controller Class Initialized
DEBUG - 2018-02-07 06:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:52:15 --> Input Class Initialized
INFO - 2018-02-07 06:52:15 --> Language Class Initialized
INFO - 2018-02-07 12:22:16 --> Model Class Initialized
INFO - 2018-02-07 12:22:16 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:22:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:22:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:22:16 --> Model Class Initialized
INFO - 2018-02-07 12:22:16 --> Model Class Initialized
INFO - 2018-02-07 12:22:16 --> Model Class Initialized
INFO - 2018-02-07 12:22:16 --> Model Class Initialized
INFO - 2018-02-07 12:22:16 --> Model Class Initialized
INFO - 2018-02-07 12:22:16 --> Model Class Initialized
INFO - 2018-02-07 12:22:16 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:22:16 --> Final output sent to browser
DEBUG - 2018-02-07 12:22:16 --> Total execution time: 0.0837
INFO - 2018-02-07 06:52:16 --> Language Class Initialized
INFO - 2018-02-07 06:52:16 --> Config Class Initialized
INFO - 2018-02-07 06:52:16 --> Loader Class Initialized
INFO - 2018-02-07 12:22:16 --> Helper loaded: url_helper
INFO - 2018-02-07 12:22:16 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:22:16 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:22:16 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:22:16 --> Helper loaded: users_helper
INFO - 2018-02-07 12:22:16 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:22:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:22:16 --> Helper loaded: form_helper
INFO - 2018-02-07 12:22:16 --> Form Validation Class Initialized
INFO - 2018-02-07 12:22:16 --> Controller Class Initialized
INFO - 2018-02-07 12:22:16 --> Model Class Initialized
INFO - 2018-02-07 12:22:16 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:22:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:22:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:22:16 --> Model Class Initialized
INFO - 2018-02-07 12:22:16 --> Model Class Initialized
INFO - 2018-02-07 12:22:16 --> Model Class Initialized
INFO - 2018-02-07 12:22:16 --> Model Class Initialized
INFO - 2018-02-07 12:22:16 --> Model Class Initialized
INFO - 2018-02-07 12:22:16 --> Model Class Initialized
INFO - 2018-02-07 12:22:16 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:22:16 --> Final output sent to browser
DEBUG - 2018-02-07 12:22:16 --> Total execution time: 0.1189
INFO - 2018-02-07 06:52:16 --> Config Class Initialized
INFO - 2018-02-07 06:52:16 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:52:16 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:52:16 --> Utf8 Class Initialized
INFO - 2018-02-07 06:52:16 --> URI Class Initialized
INFO - 2018-02-07 06:52:16 --> Router Class Initialized
INFO - 2018-02-07 06:52:16 --> Output Class Initialized
INFO - 2018-02-07 06:52:16 --> Security Class Initialized
DEBUG - 2018-02-07 06:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:52:16 --> Input Class Initialized
INFO - 2018-02-07 06:52:16 --> Language Class Initialized
INFO - 2018-02-07 06:52:16 --> Language Class Initialized
INFO - 2018-02-07 06:52:16 --> Config Class Initialized
INFO - 2018-02-07 06:52:16 --> Loader Class Initialized
INFO - 2018-02-07 12:22:16 --> Helper loaded: url_helper
INFO - 2018-02-07 12:22:16 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:22:16 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:22:16 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:22:16 --> Helper loaded: users_helper
INFO - 2018-02-07 12:22:16 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:22:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:22:16 --> Helper loaded: form_helper
INFO - 2018-02-07 12:22:16 --> Form Validation Class Initialized
INFO - 2018-02-07 12:22:16 --> Controller Class Initialized
INFO - 2018-02-07 12:22:16 --> Model Class Initialized
INFO - 2018-02-07 12:22:16 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:22:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:22:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:22:16 --> Model Class Initialized
INFO - 2018-02-07 12:22:16 --> Model Class Initialized
INFO - 2018-02-07 12:22:16 --> Model Class Initialized
INFO - 2018-02-07 12:22:16 --> Model Class Initialized
INFO - 2018-02-07 12:22:16 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:22:16 --> Final output sent to browser
DEBUG - 2018-02-07 12:22:16 --> Total execution time: 0.0951
INFO - 2018-02-07 06:52:18 --> Config Class Initialized
INFO - 2018-02-07 06:52:18 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:52:18 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:52:18 --> Utf8 Class Initialized
INFO - 2018-02-07 06:52:18 --> Config Class Initialized
INFO - 2018-02-07 06:52:18 --> Hooks Class Initialized
INFO - 2018-02-07 06:52:18 --> URI Class Initialized
DEBUG - 2018-02-07 06:52:18 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:52:18 --> Utf8 Class Initialized
INFO - 2018-02-07 06:52:18 --> Router Class Initialized
INFO - 2018-02-07 06:52:18 --> URI Class Initialized
INFO - 2018-02-07 06:52:18 --> Output Class Initialized
INFO - 2018-02-07 06:52:18 --> Router Class Initialized
INFO - 2018-02-07 06:52:18 --> Security Class Initialized
INFO - 2018-02-07 06:52:18 --> Output Class Initialized
DEBUG - 2018-02-07 06:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:52:18 --> Input Class Initialized
INFO - 2018-02-07 06:52:18 --> Language Class Initialized
INFO - 2018-02-07 06:52:18 --> Security Class Initialized
DEBUG - 2018-02-07 06:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:52:18 --> Input Class Initialized
INFO - 2018-02-07 06:52:18 --> Language Class Initialized
INFO - 2018-02-07 06:52:18 --> Language Class Initialized
INFO - 2018-02-07 06:52:18 --> Config Class Initialized
INFO - 2018-02-07 06:52:18 --> Loader Class Initialized
INFO - 2018-02-07 12:22:18 --> Helper loaded: url_helper
INFO - 2018-02-07 12:22:18 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:22:18 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:22:18 --> Helper loaded: permission_helper
INFO - 2018-02-07 06:52:18 --> Language Class Initialized
INFO - 2018-02-07 06:52:18 --> Config Class Initialized
INFO - 2018-02-07 06:52:18 --> Loader Class Initialized
INFO - 2018-02-07 12:22:18 --> Helper loaded: users_helper
INFO - 2018-02-07 12:22:18 --> Helper loaded: url_helper
INFO - 2018-02-07 12:22:18 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:22:18 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:22:18 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:22:18 --> Helper loaded: users_helper
INFO - 2018-02-07 12:22:18 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:22:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 06:52:18 --> Config Class Initialized
INFO - 2018-02-07 06:52:18 --> Hooks Class Initialized
INFO - 2018-02-07 12:22:18 --> Database Driver Class Initialized
DEBUG - 2018-02-07 06:52:18 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:52:18 --> Utf8 Class Initialized
INFO - 2018-02-07 06:52:18 --> URI Class Initialized
DEBUG - 2018-02-07 12:22:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:22:18 --> Helper loaded: form_helper
INFO - 2018-02-07 12:22:18 --> Form Validation Class Initialized
INFO - 2018-02-07 12:22:18 --> Controller Class Initialized
INFO - 2018-02-07 06:52:18 --> Router Class Initialized
INFO - 2018-02-07 06:52:18 --> Output Class Initialized
INFO - 2018-02-07 12:22:18 --> Helper loaded: form_helper
INFO - 2018-02-07 12:22:18 --> Form Validation Class Initialized
INFO - 2018-02-07 12:22:18 --> Controller Class Initialized
INFO - 2018-02-07 06:52:18 --> Security Class Initialized
INFO - 2018-02-07 12:22:18 --> Model Class Initialized
INFO - 2018-02-07 12:22:18 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 06:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:52:18 --> Input Class Initialized
INFO - 2018-02-07 06:52:18 --> Language Class Initialized
DEBUG - 2018-02-07 12:22:18 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:22:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:22:18 --> Model Class Initialized
INFO - 2018-02-07 12:22:18 --> Model Class Initialized
INFO - 2018-02-07 12:22:18 --> Model Class Initialized
INFO - 2018-02-07 12:22:18 --> Helper loaded: inflector_helper
INFO - 2018-02-07 12:22:18 --> Model Class Initialized
INFO - 2018-02-07 12:22:18 --> Model Class Initialized
INFO - 2018-02-07 12:22:18 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-02-07 12:22:18 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:22:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:22:18 --> Model Class Initialized
INFO - 2018-02-07 12:22:18 --> Model Class Initialized
INFO - 2018-02-07 12:22:18 --> Final output sent to browser
DEBUG - 2018-02-07 12:22:18 --> Total execution time: 0.1068
INFO - 2018-02-07 06:52:18 --> Language Class Initialized
INFO - 2018-02-07 06:52:18 --> Config Class Initialized
INFO - 2018-02-07 06:52:18 --> Loader Class Initialized
INFO - 2018-02-07 12:22:18 --> Model Class Initialized
INFO - 2018-02-07 12:22:18 --> Model Class Initialized
INFO - 2018-02-07 12:22:18 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:22:18 --> Helper loaded: url_helper
INFO - 2018-02-07 12:22:18 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:22:18 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:22:18 --> Final output sent to browser
DEBUG - 2018-02-07 12:22:18 --> Total execution time: 0.1062
INFO - 2018-02-07 12:22:18 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:22:18 --> Helper loaded: users_helper
INFO - 2018-02-07 12:22:18 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:22:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:22:18 --> Helper loaded: form_helper
INFO - 2018-02-07 12:22:18 --> Form Validation Class Initialized
INFO - 2018-02-07 12:22:18 --> Controller Class Initialized
INFO - 2018-02-07 12:22:18 --> Model Class Initialized
INFO - 2018-02-07 12:22:18 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:22:18 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:22:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:22:18 --> Model Class Initialized
INFO - 2018-02-07 12:22:18 --> Model Class Initialized
INFO - 2018-02-07 12:22:18 --> Model Class Initialized
INFO - 2018-02-07 12:22:18 --> Model Class Initialized
INFO - 2018-02-07 12:22:18 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:22:18 --> Final output sent to browser
DEBUG - 2018-02-07 12:22:18 --> Total execution time: 0.1007
INFO - 2018-02-07 06:52:18 --> Config Class Initialized
INFO - 2018-02-07 06:52:18 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:52:18 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:52:18 --> Utf8 Class Initialized
INFO - 2018-02-07 06:52:18 --> URI Class Initialized
INFO - 2018-02-07 06:52:18 --> Router Class Initialized
INFO - 2018-02-07 06:52:18 --> Output Class Initialized
INFO - 2018-02-07 06:52:18 --> Security Class Initialized
DEBUG - 2018-02-07 06:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:52:18 --> Input Class Initialized
INFO - 2018-02-07 06:52:18 --> Language Class Initialized
INFO - 2018-02-07 06:52:18 --> Language Class Initialized
INFO - 2018-02-07 06:52:18 --> Config Class Initialized
INFO - 2018-02-07 06:52:18 --> Loader Class Initialized
INFO - 2018-02-07 12:22:18 --> Helper loaded: url_helper
INFO - 2018-02-07 12:22:18 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:22:18 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:22:18 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:22:18 --> Helper loaded: users_helper
INFO - 2018-02-07 12:22:18 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:22:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:22:18 --> Helper loaded: form_helper
INFO - 2018-02-07 12:22:18 --> Form Validation Class Initialized
INFO - 2018-02-07 12:22:18 --> Controller Class Initialized
INFO - 2018-02-07 12:22:18 --> Model Class Initialized
INFO - 2018-02-07 12:22:18 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:22:18 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:22:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:22:18 --> Model Class Initialized
INFO - 2018-02-07 12:22:18 --> Model Class Initialized
INFO - 2018-02-07 12:22:18 --> Model Class Initialized
INFO - 2018-02-07 12:22:18 --> Model Class Initialized
INFO - 2018-02-07 12:22:18 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:22:18 --> Final output sent to browser
DEBUG - 2018-02-07 12:22:18 --> Total execution time: 0.0815
INFO - 2018-02-07 06:52:20 --> Config Class Initialized
INFO - 2018-02-07 06:52:20 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:52:20 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:52:20 --> Utf8 Class Initialized
INFO - 2018-02-07 06:52:20 --> URI Class Initialized
INFO - 2018-02-07 06:52:20 --> Router Class Initialized
INFO - 2018-02-07 06:52:20 --> Output Class Initialized
INFO - 2018-02-07 06:52:20 --> Security Class Initialized
DEBUG - 2018-02-07 06:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:52:20 --> Input Class Initialized
INFO - 2018-02-07 06:52:20 --> Language Class Initialized
INFO - 2018-02-07 06:52:20 --> Language Class Initialized
INFO - 2018-02-07 06:52:20 --> Config Class Initialized
INFO - 2018-02-07 06:52:20 --> Loader Class Initialized
INFO - 2018-02-07 12:22:20 --> Helper loaded: url_helper
INFO - 2018-02-07 12:22:20 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:22:20 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:22:20 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:22:20 --> Helper loaded: users_helper
INFO - 2018-02-07 12:22:20 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:22:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:22:20 --> Helper loaded: form_helper
INFO - 2018-02-07 12:22:20 --> Form Validation Class Initialized
INFO - 2018-02-07 12:22:20 --> Controller Class Initialized
INFO - 2018-02-07 12:22:20 --> Model Class Initialized
INFO - 2018-02-07 12:22:20 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:22:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:22:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:22:20 --> Model Class Initialized
INFO - 2018-02-07 12:22:20 --> Model Class Initialized
INFO - 2018-02-07 12:22:20 --> Model Class Initialized
INFO - 2018-02-07 12:22:20 --> Model Class Initialized
INFO - 2018-02-07 12:22:20 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:22:20 --> Final output sent to browser
DEBUG - 2018-02-07 12:22:20 --> Total execution time: 0.1145
INFO - 2018-02-07 06:52:21 --> Config Class Initialized
INFO - 2018-02-07 06:52:21 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:52:21 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:52:21 --> Utf8 Class Initialized
INFO - 2018-02-07 06:52:21 --> URI Class Initialized
INFO - 2018-02-07 06:52:21 --> Router Class Initialized
INFO - 2018-02-07 06:52:21 --> Output Class Initialized
INFO - 2018-02-07 06:52:21 --> Security Class Initialized
DEBUG - 2018-02-07 06:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:52:21 --> Input Class Initialized
INFO - 2018-02-07 06:52:21 --> Language Class Initialized
INFO - 2018-02-07 06:52:21 --> Language Class Initialized
INFO - 2018-02-07 06:52:21 --> Config Class Initialized
INFO - 2018-02-07 06:52:21 --> Loader Class Initialized
INFO - 2018-02-07 12:22:21 --> Helper loaded: url_helper
INFO - 2018-02-07 06:52:21 --> Config Class Initialized
INFO - 2018-02-07 06:52:21 --> Hooks Class Initialized
INFO - 2018-02-07 12:22:21 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:22:21 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:22:21 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:22:21 --> Helper loaded: users_helper
DEBUG - 2018-02-07 06:52:21 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:52:21 --> Utf8 Class Initialized
INFO - 2018-02-07 06:52:21 --> URI Class Initialized
INFO - 2018-02-07 06:52:21 --> Router Class Initialized
INFO - 2018-02-07 06:52:21 --> Output Class Initialized
INFO - 2018-02-07 12:22:21 --> Database Driver Class Initialized
INFO - 2018-02-07 06:52:21 --> Security Class Initialized
DEBUG - 2018-02-07 12:22:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-07 06:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:52:21 --> Input Class Initialized
INFO - 2018-02-07 12:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 06:52:21 --> Language Class Initialized
INFO - 2018-02-07 12:22:21 --> Helper loaded: form_helper
INFO - 2018-02-07 12:22:21 --> Form Validation Class Initialized
INFO - 2018-02-07 12:22:21 --> Controller Class Initialized
INFO - 2018-02-07 12:22:21 --> Model Class Initialized
INFO - 2018-02-07 12:22:21 --> Helper loaded: inflector_helper
INFO - 2018-02-07 06:52:21 --> Language Class Initialized
INFO - 2018-02-07 06:52:21 --> Config Class Initialized
INFO - 2018-02-07 06:52:21 --> Loader Class Initialized
DEBUG - 2018-02-07 12:22:21 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:22:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:22:21 --> Model Class Initialized
INFO - 2018-02-07 12:22:21 --> Helper loaded: url_helper
INFO - 2018-02-07 12:22:21 --> Model Class Initialized
INFO - 2018-02-07 12:22:21 --> Model Class Initialized
INFO - 2018-02-07 12:22:21 --> Model Class Initialized
INFO - 2018-02-07 12:22:21 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:22:21 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:22:21 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:22:21 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:22:21 --> Helper loaded: users_helper
INFO - 2018-02-07 12:22:21 --> Final output sent to browser
DEBUG - 2018-02-07 12:22:21 --> Total execution time: 0.0853
INFO - 2018-02-07 12:22:21 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:22:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:22:21 --> Helper loaded: form_helper
INFO - 2018-02-07 12:22:21 --> Form Validation Class Initialized
INFO - 2018-02-07 12:22:21 --> Controller Class Initialized
INFO - 2018-02-07 12:22:21 --> Model Class Initialized
INFO - 2018-02-07 12:22:21 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:22:21 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:22:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:22:21 --> Model Class Initialized
INFO - 2018-02-07 12:22:21 --> Model Class Initialized
INFO - 2018-02-07 12:22:21 --> Model Class Initialized
INFO - 2018-02-07 12:22:21 --> Model Class Initialized
INFO - 2018-02-07 12:22:21 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:22:21 --> Final output sent to browser
DEBUG - 2018-02-07 12:22:21 --> Total execution time: 0.1109
INFO - 2018-02-07 06:52:22 --> Config Class Initialized
INFO - 2018-02-07 06:52:22 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:52:22 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:52:22 --> Utf8 Class Initialized
INFO - 2018-02-07 06:52:22 --> URI Class Initialized
INFO - 2018-02-07 06:52:22 --> Router Class Initialized
INFO - 2018-02-07 06:52:22 --> Output Class Initialized
INFO - 2018-02-07 06:52:22 --> Security Class Initialized
DEBUG - 2018-02-07 06:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:52:22 --> Input Class Initialized
INFO - 2018-02-07 06:52:22 --> Language Class Initialized
INFO - 2018-02-07 06:52:22 --> Language Class Initialized
INFO - 2018-02-07 06:52:22 --> Config Class Initialized
INFO - 2018-02-07 06:52:22 --> Loader Class Initialized
INFO - 2018-02-07 12:22:22 --> Helper loaded: url_helper
INFO - 2018-02-07 12:22:22 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:22:22 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:22:22 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:22:22 --> Helper loaded: users_helper
INFO - 2018-02-07 12:22:22 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:22:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:22:22 --> Helper loaded: form_helper
INFO - 2018-02-07 12:22:22 --> Form Validation Class Initialized
INFO - 2018-02-07 12:22:22 --> Controller Class Initialized
INFO - 2018-02-07 12:22:22 --> Model Class Initialized
INFO - 2018-02-07 12:22:22 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:22:22 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:22:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:22:22 --> Model Class Initialized
INFO - 2018-02-07 12:22:22 --> Model Class Initialized
INFO - 2018-02-07 12:22:22 --> Model Class Initialized
INFO - 2018-02-07 12:22:22 --> Model Class Initialized
INFO - 2018-02-07 12:22:22 --> Model Class Initialized
INFO - 2018-02-07 12:22:22 --> Model Class Initialized
INFO - 2018-02-07 12:22:22 --> Model Class Initialized
INFO - 2018-02-07 12:22:22 --> Model Class Initialized
INFO - 2018-02-07 12:22:22 --> Model Class Initialized
INFO - 2018-02-07 12:22:22 --> Model Class Initialized
INFO - 2018-02-07 12:22:22 --> Model Class Initialized
INFO - 2018-02-07 12:22:22 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:22:22 --> Model Class Initialized
INFO - 2018-02-07 12:22:22 --> Final output sent to browser
DEBUG - 2018-02-07 12:22:22 --> Total execution time: 0.1408
INFO - 2018-02-07 06:52:23 --> Config Class Initialized
INFO - 2018-02-07 06:52:23 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:52:23 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:52:23 --> Utf8 Class Initialized
INFO - 2018-02-07 06:52:23 --> URI Class Initialized
INFO - 2018-02-07 06:52:23 --> Router Class Initialized
INFO - 2018-02-07 06:52:23 --> Output Class Initialized
INFO - 2018-02-07 06:52:23 --> Security Class Initialized
DEBUG - 2018-02-07 06:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:52:23 --> Input Class Initialized
INFO - 2018-02-07 06:52:23 --> Language Class Initialized
INFO - 2018-02-07 06:52:23 --> Language Class Initialized
INFO - 2018-02-07 06:52:23 --> Config Class Initialized
INFO - 2018-02-07 06:52:23 --> Loader Class Initialized
INFO - 2018-02-07 12:22:23 --> Helper loaded: url_helper
INFO - 2018-02-07 12:22:23 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:22:23 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:22:23 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:22:23 --> Helper loaded: users_helper
INFO - 2018-02-07 12:22:23 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:22:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:22:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:22:23 --> Helper loaded: form_helper
INFO - 2018-02-07 12:22:23 --> Form Validation Class Initialized
INFO - 2018-02-07 12:22:23 --> Controller Class Initialized
INFO - 2018-02-07 12:22:23 --> Model Class Initialized
INFO - 2018-02-07 12:22:23 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:22:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:22:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:22:23 --> Model Class Initialized
INFO - 2018-02-07 12:22:23 --> Model Class Initialized
INFO - 2018-02-07 12:22:23 --> Model Class Initialized
INFO - 2018-02-07 12:22:23 --> Model Class Initialized
INFO - 2018-02-07 12:22:23 --> Model Class Initialized
INFO - 2018-02-07 12:22:23 --> Model Class Initialized
INFO - 2018-02-07 12:22:23 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:22:23 --> Model Class Initialized
INFO - 2018-02-07 12:22:23 --> Final output sent to browser
DEBUG - 2018-02-07 12:22:23 --> Total execution time: 0.1214
INFO - 2018-02-07 06:52:24 --> Config Class Initialized
INFO - 2018-02-07 06:52:24 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:52:24 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:52:24 --> Utf8 Class Initialized
INFO - 2018-02-07 06:52:24 --> URI Class Initialized
INFO - 2018-02-07 06:52:24 --> Router Class Initialized
INFO - 2018-02-07 06:52:24 --> Output Class Initialized
INFO - 2018-02-07 06:52:24 --> Security Class Initialized
DEBUG - 2018-02-07 06:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:52:24 --> Input Class Initialized
INFO - 2018-02-07 06:52:24 --> Language Class Initialized
INFO - 2018-02-07 06:52:24 --> Language Class Initialized
INFO - 2018-02-07 06:52:24 --> Config Class Initialized
INFO - 2018-02-07 06:52:24 --> Loader Class Initialized
INFO - 2018-02-07 12:22:24 --> Helper loaded: url_helper
INFO - 2018-02-07 12:22:24 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:22:24 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:22:24 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:22:24 --> Helper loaded: users_helper
INFO - 2018-02-07 06:52:24 --> Config Class Initialized
INFO - 2018-02-07 06:52:24 --> Hooks Class Initialized
INFO - 2018-02-07 06:52:24 --> Config Class Initialized
INFO - 2018-02-07 06:52:24 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:52:24 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:52:24 --> Utf8 Class Initialized
DEBUG - 2018-02-07 06:52:24 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:52:24 --> Utf8 Class Initialized
INFO - 2018-02-07 06:52:24 --> URI Class Initialized
INFO - 2018-02-07 12:22:24 --> Database Driver Class Initialized
INFO - 2018-02-07 06:52:24 --> URI Class Initialized
INFO - 2018-02-07 06:52:24 --> Router Class Initialized
INFO - 2018-02-07 06:52:24 --> Router Class Initialized
DEBUG - 2018-02-07 12:22:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 06:52:24 --> Output Class Initialized
INFO - 2018-02-07 12:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 06:52:24 --> Output Class Initialized
INFO - 2018-02-07 06:52:24 --> Security Class Initialized
INFO - 2018-02-07 06:52:24 --> Security Class Initialized
DEBUG - 2018-02-07 06:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:52:24 --> Input Class Initialized
INFO - 2018-02-07 06:52:24 --> Language Class Initialized
DEBUG - 2018-02-07 06:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:52:24 --> Input Class Initialized
INFO - 2018-02-07 12:22:24 --> Helper loaded: form_helper
INFO - 2018-02-07 12:22:24 --> Form Validation Class Initialized
INFO - 2018-02-07 12:22:24 --> Controller Class Initialized
INFO - 2018-02-07 06:52:24 --> Language Class Initialized
INFO - 2018-02-07 12:22:24 --> Model Class Initialized
INFO - 2018-02-07 12:22:24 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:22:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 06:52:24 --> Language Class Initialized
INFO - 2018-02-07 06:52:24 --> Config Class Initialized
INFO - 2018-02-07 06:52:24 --> Loader Class Initialized
INFO - 2018-02-07 12:22:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 06:52:24 --> Language Class Initialized
INFO - 2018-02-07 06:52:24 --> Config Class Initialized
INFO - 2018-02-07 12:22:24 --> Model Class Initialized
INFO - 2018-02-07 06:52:24 --> Loader Class Initialized
INFO - 2018-02-07 12:22:24 --> Model Class Initialized
INFO - 2018-02-07 12:22:24 --> Helper loaded: url_helper
INFO - 2018-02-07 12:22:24 --> Model Class Initialized
INFO - 2018-02-07 12:22:24 --> Model Class Initialized
INFO - 2018-02-07 12:22:24 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:22:24 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:22:24 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:22:24 --> Helper loaded: url_helper
INFO - 2018-02-07 12:22:24 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:22:24 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:22:24 --> Helper loaded: users_helper
INFO - 2018-02-07 12:22:24 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:22:24 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:22:24 --> Helper loaded: users_helper
INFO - 2018-02-07 12:22:24 --> Final output sent to browser
DEBUG - 2018-02-07 12:22:24 --> Total execution time: 0.0852
INFO - 2018-02-07 12:22:24 --> Database Driver Class Initialized
INFO - 2018-02-07 12:22:24 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:22:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-07 12:22:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:22:24 --> Helper loaded: form_helper
INFO - 2018-02-07 12:22:24 --> Form Validation Class Initialized
INFO - 2018-02-07 12:22:24 --> Controller Class Initialized
INFO - 2018-02-07 12:22:24 --> Helper loaded: form_helper
INFO - 2018-02-07 12:22:24 --> Form Validation Class Initialized
INFO - 2018-02-07 12:22:24 --> Controller Class Initialized
INFO - 2018-02-07 12:22:24 --> Model Class Initialized
INFO - 2018-02-07 12:22:24 --> Model Class Initialized
INFO - 2018-02-07 12:22:24 --> Helper loaded: inflector_helper
INFO - 2018-02-07 12:22:24 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:22:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-02-07 12:22:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:22:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:22:24 --> Model Class Initialized
INFO - 2018-02-07 12:22:24 --> Model Class Initialized
INFO - 2018-02-07 12:22:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:22:24 --> Model Class Initialized
INFO - 2018-02-07 12:22:24 --> Model Class Initialized
INFO - 2018-02-07 12:22:24 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:22:24 --> Model Class Initialized
INFO - 2018-02-07 12:22:24 --> Model Class Initialized
INFO - 2018-02-07 12:22:24 --> Model Class Initialized
INFO - 2018-02-07 12:22:24 --> Model Class Initialized
INFO - 2018-02-07 12:22:24 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:22:24 --> Final output sent to browser
DEBUG - 2018-02-07 12:22:24 --> Total execution time: 0.1116
INFO - 2018-02-07 12:22:24 --> Final output sent to browser
DEBUG - 2018-02-07 12:22:24 --> Total execution time: 0.1139
INFO - 2018-02-07 06:52:25 --> Config Class Initialized
INFO - 2018-02-07 06:52:25 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:52:25 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:52:25 --> Utf8 Class Initialized
INFO - 2018-02-07 06:52:25 --> URI Class Initialized
INFO - 2018-02-07 06:52:25 --> Router Class Initialized
INFO - 2018-02-07 06:52:25 --> Output Class Initialized
INFO - 2018-02-07 06:52:25 --> Security Class Initialized
DEBUG - 2018-02-07 06:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:52:25 --> Input Class Initialized
INFO - 2018-02-07 06:52:25 --> Language Class Initialized
INFO - 2018-02-07 06:52:25 --> Language Class Initialized
INFO - 2018-02-07 06:52:25 --> Config Class Initialized
INFO - 2018-02-07 06:52:25 --> Loader Class Initialized
INFO - 2018-02-07 12:22:25 --> Helper loaded: url_helper
INFO - 2018-02-07 12:22:25 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:22:25 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:22:25 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:22:25 --> Helper loaded: users_helper
INFO - 2018-02-07 12:22:25 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:22:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:22:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:22:25 --> Helper loaded: form_helper
INFO - 2018-02-07 12:22:25 --> Form Validation Class Initialized
INFO - 2018-02-07 12:22:25 --> Controller Class Initialized
INFO - 2018-02-07 12:22:25 --> Model Class Initialized
INFO - 2018-02-07 12:22:25 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:22:25 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:22:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:22:25 --> Model Class Initialized
INFO - 2018-02-07 12:22:25 --> Model Class Initialized
INFO - 2018-02-07 12:22:25 --> Model Class Initialized
INFO - 2018-02-07 12:22:25 --> Model Class Initialized
INFO - 2018-02-07 12:22:25 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:22:25 --> Final output sent to browser
DEBUG - 2018-02-07 12:22:25 --> Total execution time: 0.1009
INFO - 2018-02-07 06:52:27 --> Config Class Initialized
INFO - 2018-02-07 06:52:27 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:52:27 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:52:27 --> Utf8 Class Initialized
INFO - 2018-02-07 06:52:27 --> URI Class Initialized
INFO - 2018-02-07 06:52:27 --> Router Class Initialized
INFO - 2018-02-07 06:52:27 --> Output Class Initialized
INFO - 2018-02-07 06:52:27 --> Security Class Initialized
DEBUG - 2018-02-07 06:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:52:27 --> Input Class Initialized
INFO - 2018-02-07 06:52:27 --> Language Class Initialized
INFO - 2018-02-07 06:52:27 --> Language Class Initialized
INFO - 2018-02-07 06:52:27 --> Config Class Initialized
INFO - 2018-02-07 06:52:27 --> Loader Class Initialized
INFO - 2018-02-07 12:22:27 --> Helper loaded: url_helper
INFO - 2018-02-07 12:22:27 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:22:27 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:22:27 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:22:27 --> Helper loaded: users_helper
INFO - 2018-02-07 12:22:28 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:22:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:22:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:22:28 --> Helper loaded: form_helper
INFO - 2018-02-07 12:22:28 --> Form Validation Class Initialized
INFO - 2018-02-07 12:22:28 --> Controller Class Initialized
INFO - 2018-02-07 12:22:28 --> Model Class Initialized
INFO - 2018-02-07 12:22:28 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:22:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:22:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:22:28 --> Model Class Initialized
INFO - 2018-02-07 12:22:28 --> Model Class Initialized
INFO - 2018-02-07 12:22:28 --> Model Class Initialized
INFO - 2018-02-07 12:22:28 --> Model Class Initialized
INFO - 2018-02-07 12:22:28 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:22:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-07 12:22:28 --> Final output sent to browser
DEBUG - 2018-02-07 12:22:28 --> Total execution time: 0.0934
INFO - 2018-02-07 06:52:28 --> Config Class Initialized
INFO - 2018-02-07 06:52:28 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:52:28 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:52:28 --> Utf8 Class Initialized
INFO - 2018-02-07 06:52:28 --> URI Class Initialized
INFO - 2018-02-07 06:52:28 --> Router Class Initialized
INFO - 2018-02-07 06:52:28 --> Output Class Initialized
INFO - 2018-02-07 06:52:28 --> Security Class Initialized
DEBUG - 2018-02-07 06:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:52:28 --> Input Class Initialized
INFO - 2018-02-07 06:52:28 --> Language Class Initialized
INFO - 2018-02-07 06:52:28 --> Language Class Initialized
INFO - 2018-02-07 06:52:28 --> Config Class Initialized
INFO - 2018-02-07 06:52:28 --> Loader Class Initialized
INFO - 2018-02-07 12:22:28 --> Helper loaded: url_helper
INFO - 2018-02-07 12:22:28 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:22:28 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:22:28 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:22:28 --> Helper loaded: users_helper
INFO - 2018-02-07 12:22:28 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:22:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:22:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:22:28 --> Helper loaded: form_helper
INFO - 2018-02-07 12:22:28 --> Form Validation Class Initialized
INFO - 2018-02-07 12:22:28 --> Controller Class Initialized
INFO - 2018-02-07 12:22:28 --> Model Class Initialized
INFO - 2018-02-07 12:22:28 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:22:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:22:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:22:28 --> Model Class Initialized
INFO - 2018-02-07 12:22:28 --> Model Class Initialized
INFO - 2018-02-07 12:22:28 --> Model Class Initialized
INFO - 2018-02-07 12:22:28 --> Model Class Initialized
INFO - 2018-02-07 12:22:28 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:22:28 --> Final output sent to browser
DEBUG - 2018-02-07 12:22:28 --> Total execution time: 0.1051
INFO - 2018-02-07 06:52:28 --> Config Class Initialized
INFO - 2018-02-07 06:52:28 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:52:28 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:52:28 --> Utf8 Class Initialized
INFO - 2018-02-07 06:52:28 --> URI Class Initialized
INFO - 2018-02-07 06:52:28 --> Router Class Initialized
INFO - 2018-02-07 06:52:28 --> Output Class Initialized
INFO - 2018-02-07 06:52:28 --> Security Class Initialized
DEBUG - 2018-02-07 06:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:52:28 --> Input Class Initialized
INFO - 2018-02-07 06:52:28 --> Language Class Initialized
INFO - 2018-02-07 06:52:28 --> Language Class Initialized
INFO - 2018-02-07 06:52:28 --> Config Class Initialized
INFO - 2018-02-07 06:52:28 --> Loader Class Initialized
INFO - 2018-02-07 12:22:29 --> Helper loaded: url_helper
INFO - 2018-02-07 12:22:29 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:22:29 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:22:29 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:22:29 --> Helper loaded: users_helper
INFO - 2018-02-07 12:22:29 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:22:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:22:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:22:29 --> Helper loaded: form_helper
INFO - 2018-02-07 12:22:29 --> Form Validation Class Initialized
INFO - 2018-02-07 12:22:29 --> Controller Class Initialized
INFO - 2018-02-07 12:22:29 --> Model Class Initialized
INFO - 2018-02-07 12:22:29 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:22:29 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:22:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:22:29 --> Model Class Initialized
INFO - 2018-02-07 12:22:29 --> Model Class Initialized
INFO - 2018-02-07 12:22:29 --> Model Class Initialized
INFO - 2018-02-07 12:22:29 --> Model Class Initialized
INFO - 2018-02-07 12:22:29 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:22:29 --> Final output sent to browser
DEBUG - 2018-02-07 12:22:29 --> Total execution time: 0.1061
INFO - 2018-02-07 06:52:30 --> Config Class Initialized
INFO - 2018-02-07 06:52:30 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:52:30 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:52:30 --> Utf8 Class Initialized
INFO - 2018-02-07 06:52:30 --> URI Class Initialized
INFO - 2018-02-07 06:52:30 --> Router Class Initialized
INFO - 2018-02-07 06:52:30 --> Output Class Initialized
INFO - 2018-02-07 06:52:30 --> Security Class Initialized
DEBUG - 2018-02-07 06:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:52:30 --> Input Class Initialized
INFO - 2018-02-07 06:52:30 --> Language Class Initialized
INFO - 2018-02-07 06:52:30 --> Language Class Initialized
INFO - 2018-02-07 06:52:30 --> Config Class Initialized
INFO - 2018-02-07 06:52:30 --> Loader Class Initialized
INFO - 2018-02-07 12:22:30 --> Helper loaded: url_helper
INFO - 2018-02-07 12:22:30 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:22:30 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:22:30 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:22:30 --> Helper loaded: users_helper
INFO - 2018-02-07 12:22:30 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:22:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:22:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:22:30 --> Helper loaded: form_helper
INFO - 2018-02-07 12:22:30 --> Form Validation Class Initialized
INFO - 2018-02-07 12:22:30 --> Controller Class Initialized
INFO - 2018-02-07 12:22:30 --> Model Class Initialized
INFO - 2018-02-07 12:22:30 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:22:30 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:22:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:22:30 --> Model Class Initialized
INFO - 2018-02-07 12:22:30 --> Model Class Initialized
INFO - 2018-02-07 12:22:30 --> Model Class Initialized
INFO - 2018-02-07 12:22:30 --> Model Class Initialized
INFO - 2018-02-07 12:22:30 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:22:30 --> Final output sent to browser
DEBUG - 2018-02-07 12:22:30 --> Total execution time: 0.1063
INFO - 2018-02-07 06:52:31 --> Config Class Initialized
INFO - 2018-02-07 06:52:31 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:52:31 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:52:31 --> Utf8 Class Initialized
INFO - 2018-02-07 06:52:31 --> URI Class Initialized
INFO - 2018-02-07 06:52:31 --> Router Class Initialized
INFO - 2018-02-07 06:52:31 --> Output Class Initialized
INFO - 2018-02-07 06:52:31 --> Security Class Initialized
DEBUG - 2018-02-07 06:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:52:31 --> Input Class Initialized
INFO - 2018-02-07 06:52:31 --> Language Class Initialized
INFO - 2018-02-07 06:52:31 --> Language Class Initialized
INFO - 2018-02-07 06:52:31 --> Config Class Initialized
INFO - 2018-02-07 06:52:31 --> Loader Class Initialized
INFO - 2018-02-07 12:22:31 --> Helper loaded: url_helper
INFO - 2018-02-07 12:22:31 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:22:31 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:22:31 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:22:31 --> Helper loaded: users_helper
INFO - 2018-02-07 12:22:31 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:22:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:22:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:22:31 --> Helper loaded: form_helper
INFO - 2018-02-07 12:22:31 --> Form Validation Class Initialized
INFO - 2018-02-07 12:22:31 --> Controller Class Initialized
INFO - 2018-02-07 12:22:31 --> Model Class Initialized
INFO - 2018-02-07 12:22:31 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:22:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:22:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:22:31 --> Model Class Initialized
INFO - 2018-02-07 12:22:31 --> Model Class Initialized
INFO - 2018-02-07 12:22:31 --> Model Class Initialized
INFO - 2018-02-07 12:22:31 --> Model Class Initialized
INFO - 2018-02-07 12:22:31 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:22:31 --> Final output sent to browser
DEBUG - 2018-02-07 12:22:31 --> Total execution time: 0.1095
INFO - 2018-02-07 06:52:32 --> Config Class Initialized
INFO - 2018-02-07 06:52:32 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:52:32 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:52:32 --> Utf8 Class Initialized
INFO - 2018-02-07 06:52:32 --> URI Class Initialized
INFO - 2018-02-07 06:52:32 --> Router Class Initialized
INFO - 2018-02-07 06:52:32 --> Output Class Initialized
INFO - 2018-02-07 06:52:32 --> Security Class Initialized
DEBUG - 2018-02-07 06:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:52:32 --> Input Class Initialized
INFO - 2018-02-07 06:52:33 --> Language Class Initialized
INFO - 2018-02-07 06:52:33 --> Language Class Initialized
INFO - 2018-02-07 06:52:33 --> Config Class Initialized
INFO - 2018-02-07 06:52:33 --> Loader Class Initialized
INFO - 2018-02-07 12:22:33 --> Helper loaded: url_helper
INFO - 2018-02-07 12:22:33 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:22:33 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:22:33 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:22:33 --> Helper loaded: users_helper
INFO - 2018-02-07 12:22:33 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:22:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:22:33 --> Helper loaded: form_helper
INFO - 2018-02-07 12:22:33 --> Form Validation Class Initialized
INFO - 2018-02-07 12:22:33 --> Controller Class Initialized
INFO - 2018-02-07 12:22:33 --> Model Class Initialized
INFO - 2018-02-07 12:22:33 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:22:33 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:22:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:22:33 --> Model Class Initialized
INFO - 2018-02-07 12:22:33 --> Model Class Initialized
INFO - 2018-02-07 12:22:33 --> Model Class Initialized
INFO - 2018-02-07 12:22:33 --> Model Class Initialized
INFO - 2018-02-07 12:22:33 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:22:33 --> Final output sent to browser
DEBUG - 2018-02-07 12:22:33 --> Total execution time: 0.0919
INFO - 2018-02-07 06:52:35 --> Config Class Initialized
INFO - 2018-02-07 06:52:35 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:52:35 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:52:35 --> Utf8 Class Initialized
INFO - 2018-02-07 06:52:35 --> URI Class Initialized
INFO - 2018-02-07 06:52:35 --> Router Class Initialized
INFO - 2018-02-07 06:52:35 --> Output Class Initialized
INFO - 2018-02-07 06:52:35 --> Security Class Initialized
DEBUG - 2018-02-07 06:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:52:35 --> Input Class Initialized
INFO - 2018-02-07 06:52:35 --> Language Class Initialized
INFO - 2018-02-07 06:52:35 --> Language Class Initialized
INFO - 2018-02-07 06:52:35 --> Config Class Initialized
INFO - 2018-02-07 06:52:35 --> Loader Class Initialized
INFO - 2018-02-07 12:22:35 --> Helper loaded: url_helper
INFO - 2018-02-07 12:22:35 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:22:35 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:22:35 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:22:35 --> Helper loaded: users_helper
INFO - 2018-02-07 12:22:35 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:22:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:22:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:22:35 --> Helper loaded: form_helper
INFO - 2018-02-07 12:22:35 --> Form Validation Class Initialized
INFO - 2018-02-07 12:22:35 --> Controller Class Initialized
INFO - 2018-02-07 12:22:35 --> Model Class Initialized
INFO - 2018-02-07 12:22:35 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:22:35 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:22:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:22:35 --> Model Class Initialized
INFO - 2018-02-07 12:22:35 --> Model Class Initialized
INFO - 2018-02-07 12:22:35 --> Model Class Initialized
INFO - 2018-02-07 12:22:35 --> Model Class Initialized
INFO - 2018-02-07 12:22:35 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:22:35 --> Final output sent to browser
DEBUG - 2018-02-07 12:22:35 --> Total execution time: 0.1174
INFO - 2018-02-07 06:52:35 --> Config Class Initialized
INFO - 2018-02-07 06:52:35 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:52:35 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:52:35 --> Utf8 Class Initialized
INFO - 2018-02-07 06:52:35 --> URI Class Initialized
INFO - 2018-02-07 06:52:35 --> Router Class Initialized
INFO - 2018-02-07 06:52:35 --> Output Class Initialized
INFO - 2018-02-07 06:52:35 --> Security Class Initialized
DEBUG - 2018-02-07 06:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:52:35 --> Input Class Initialized
INFO - 2018-02-07 06:52:35 --> Language Class Initialized
INFO - 2018-02-07 06:52:35 --> Language Class Initialized
INFO - 2018-02-07 06:52:35 --> Config Class Initialized
INFO - 2018-02-07 06:52:35 --> Loader Class Initialized
INFO - 2018-02-07 12:22:35 --> Helper loaded: url_helper
INFO - 2018-02-07 12:22:36 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:22:36 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:22:36 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:22:36 --> Helper loaded: users_helper
INFO - 2018-02-07 12:22:36 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:22:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:22:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:22:36 --> Helper loaded: form_helper
INFO - 2018-02-07 12:22:36 --> Form Validation Class Initialized
INFO - 2018-02-07 12:22:36 --> Controller Class Initialized
INFO - 2018-02-07 12:22:36 --> Model Class Initialized
INFO - 2018-02-07 12:22:36 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:22:36 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:22:36 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:22:36 --> Model Class Initialized
INFO - 2018-02-07 12:22:36 --> Model Class Initialized
INFO - 2018-02-07 12:22:36 --> Model Class Initialized
INFO - 2018-02-07 12:22:36 --> Model Class Initialized
INFO - 2018-02-07 12:22:36 --> Model Class Initialized
INFO - 2018-02-07 12:22:36 --> Model Class Initialized
INFO - 2018-02-07 12:22:36 --> Model Class Initialized
INFO - 2018-02-07 12:22:36 --> Model Class Initialized
INFO - 2018-02-07 12:22:36 --> Model Class Initialized
INFO - 2018-02-07 12:22:36 --> Model Class Initialized
INFO - 2018-02-07 12:22:36 --> Model Class Initialized
INFO - 2018-02-07 12:22:36 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:22:36 --> Model Class Initialized
INFO - 2018-02-07 12:22:36 --> Final output sent to browser
DEBUG - 2018-02-07 12:22:36 --> Total execution time: 0.1250
INFO - 2018-02-07 06:52:38 --> Config Class Initialized
INFO - 2018-02-07 06:52:38 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:52:38 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:52:38 --> Utf8 Class Initialized
INFO - 2018-02-07 06:52:38 --> URI Class Initialized
INFO - 2018-02-07 06:52:38 --> Router Class Initialized
INFO - 2018-02-07 06:52:38 --> Output Class Initialized
INFO - 2018-02-07 06:52:38 --> Security Class Initialized
DEBUG - 2018-02-07 06:52:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:52:38 --> Input Class Initialized
INFO - 2018-02-07 06:52:38 --> Language Class Initialized
INFO - 2018-02-07 06:52:38 --> Language Class Initialized
INFO - 2018-02-07 06:52:38 --> Config Class Initialized
INFO - 2018-02-07 06:52:38 --> Loader Class Initialized
INFO - 2018-02-07 12:22:38 --> Helper loaded: url_helper
INFO - 2018-02-07 12:22:38 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:22:38 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:22:38 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:22:38 --> Helper loaded: users_helper
INFO - 2018-02-07 12:22:38 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:22:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:22:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:22:38 --> Helper loaded: form_helper
INFO - 2018-02-07 12:22:38 --> Form Validation Class Initialized
INFO - 2018-02-07 12:22:38 --> Controller Class Initialized
INFO - 2018-02-07 12:22:38 --> Model Class Initialized
INFO - 2018-02-07 12:22:38 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:22:38 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:22:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:22:38 --> Model Class Initialized
INFO - 2018-02-07 12:22:38 --> Model Class Initialized
INFO - 2018-02-07 12:22:38 --> Model Class Initialized
INFO - 2018-02-07 12:22:38 --> Model Class Initialized
INFO - 2018-02-07 12:22:38 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:22:38 --> Final output sent to browser
DEBUG - 2018-02-07 12:22:38 --> Total execution time: 0.0793
INFO - 2018-02-07 06:52:40 --> Config Class Initialized
INFO - 2018-02-07 06:52:40 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:52:40 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:52:40 --> Utf8 Class Initialized
INFO - 2018-02-07 06:52:40 --> URI Class Initialized
INFO - 2018-02-07 06:52:40 --> Router Class Initialized
INFO - 2018-02-07 06:52:40 --> Output Class Initialized
INFO - 2018-02-07 06:52:40 --> Security Class Initialized
DEBUG - 2018-02-07 06:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:52:40 --> Input Class Initialized
INFO - 2018-02-07 06:52:40 --> Language Class Initialized
INFO - 2018-02-07 06:52:40 --> Language Class Initialized
INFO - 2018-02-07 06:52:40 --> Config Class Initialized
INFO - 2018-02-07 06:52:40 --> Loader Class Initialized
INFO - 2018-02-07 12:22:40 --> Helper loaded: url_helper
INFO - 2018-02-07 12:22:40 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:22:40 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:22:40 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:22:40 --> Helper loaded: users_helper
INFO - 2018-02-07 12:22:40 --> Database Driver Class Initialized
INFO - 2018-02-07 06:52:40 --> Config Class Initialized
INFO - 2018-02-07 06:52:40 --> Hooks Class Initialized
DEBUG - 2018-02-07 12:22:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:22:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-07 06:52:40 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:52:40 --> Utf8 Class Initialized
INFO - 2018-02-07 06:52:40 --> URI Class Initialized
INFO - 2018-02-07 06:52:40 --> Router Class Initialized
INFO - 2018-02-07 12:22:40 --> Helper loaded: form_helper
INFO - 2018-02-07 12:22:40 --> Form Validation Class Initialized
INFO - 2018-02-07 12:22:40 --> Controller Class Initialized
INFO - 2018-02-07 06:52:40 --> Output Class Initialized
INFO - 2018-02-07 06:52:40 --> Security Class Initialized
DEBUG - 2018-02-07 06:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:52:40 --> Input Class Initialized
INFO - 2018-02-07 06:52:40 --> Language Class Initialized
INFO - 2018-02-07 12:22:40 --> Model Class Initialized
INFO - 2018-02-07 12:22:40 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:22:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:22:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:22:40 --> Model Class Initialized
INFO - 2018-02-07 12:22:40 --> Model Class Initialized
INFO - 2018-02-07 12:22:40 --> Model Class Initialized
INFO - 2018-02-07 12:22:40 --> Model Class Initialized
INFO - 2018-02-07 12:22:40 --> Model Class Initialized
INFO - 2018-02-07 12:22:40 --> Model Class Initialized
INFO - 2018-02-07 12:22:40 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:22:40 --> Final output sent to browser
DEBUG - 2018-02-07 12:22:40 --> Total execution time: 0.1183
INFO - 2018-02-07 06:52:40 --> Language Class Initialized
INFO - 2018-02-07 06:52:40 --> Config Class Initialized
INFO - 2018-02-07 06:52:40 --> Loader Class Initialized
INFO - 2018-02-07 12:22:40 --> Helper loaded: url_helper
INFO - 2018-02-07 12:22:40 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:22:40 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:22:40 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:22:40 --> Helper loaded: users_helper
INFO - 2018-02-07 12:22:40 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:22:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:22:40 --> Helper loaded: form_helper
INFO - 2018-02-07 12:22:40 --> Form Validation Class Initialized
INFO - 2018-02-07 12:22:40 --> Controller Class Initialized
INFO - 2018-02-07 12:22:40 --> Model Class Initialized
INFO - 2018-02-07 12:22:40 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:22:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:22:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:22:40 --> Model Class Initialized
INFO - 2018-02-07 12:22:40 --> Model Class Initialized
INFO - 2018-02-07 12:22:40 --> Model Class Initialized
INFO - 2018-02-07 12:22:40 --> Model Class Initialized
INFO - 2018-02-07 12:22:40 --> Model Class Initialized
INFO - 2018-02-07 12:22:40 --> Model Class Initialized
INFO - 2018-02-07 12:22:40 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:22:40 --> Final output sent to browser
DEBUG - 2018-02-07 12:22:40 --> Total execution time: 0.1199
INFO - 2018-02-07 06:52:40 --> Config Class Initialized
INFO - 2018-02-07 06:52:40 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:52:40 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:52:40 --> Utf8 Class Initialized
INFO - 2018-02-07 06:52:40 --> URI Class Initialized
INFO - 2018-02-07 06:52:40 --> Router Class Initialized
INFO - 2018-02-07 06:52:40 --> Output Class Initialized
INFO - 2018-02-07 06:52:40 --> Security Class Initialized
DEBUG - 2018-02-07 06:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:52:40 --> Input Class Initialized
INFO - 2018-02-07 06:52:40 --> Language Class Initialized
INFO - 2018-02-07 06:52:40 --> Language Class Initialized
INFO - 2018-02-07 06:52:40 --> Config Class Initialized
INFO - 2018-02-07 06:52:40 --> Loader Class Initialized
INFO - 2018-02-07 12:22:40 --> Helper loaded: url_helper
INFO - 2018-02-07 12:22:40 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:22:40 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:22:40 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:22:40 --> Helper loaded: users_helper
INFO - 2018-02-07 12:22:40 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:22:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:22:40 --> Helper loaded: form_helper
INFO - 2018-02-07 12:22:40 --> Form Validation Class Initialized
INFO - 2018-02-07 12:22:40 --> Controller Class Initialized
INFO - 2018-02-07 12:22:40 --> Model Class Initialized
INFO - 2018-02-07 12:22:40 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:22:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:22:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:22:40 --> Model Class Initialized
INFO - 2018-02-07 12:22:40 --> Model Class Initialized
INFO - 2018-02-07 12:22:40 --> Model Class Initialized
INFO - 2018-02-07 12:22:40 --> Model Class Initialized
INFO - 2018-02-07 12:22:40 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:22:40 --> Final output sent to browser
DEBUG - 2018-02-07 12:22:40 --> Total execution time: 0.1144
INFO - 2018-02-07 06:53:02 --> Config Class Initialized
INFO - 2018-02-07 06:53:02 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:53:02 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:53:02 --> Utf8 Class Initialized
INFO - 2018-02-07 06:53:02 --> URI Class Initialized
INFO - 2018-02-07 06:53:02 --> Router Class Initialized
INFO - 2018-02-07 06:53:02 --> Output Class Initialized
INFO - 2018-02-07 06:53:02 --> Security Class Initialized
DEBUG - 2018-02-07 06:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:53:02 --> Input Class Initialized
INFO - 2018-02-07 06:53:02 --> Language Class Initialized
INFO - 2018-02-07 06:53:02 --> Language Class Initialized
INFO - 2018-02-07 06:53:02 --> Config Class Initialized
INFO - 2018-02-07 06:53:02 --> Loader Class Initialized
INFO - 2018-02-07 12:23:02 --> Helper loaded: url_helper
INFO - 2018-02-07 12:23:02 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:23:02 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:23:02 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:23:02 --> Helper loaded: users_helper
INFO - 2018-02-07 12:23:02 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:23:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:23:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:23:02 --> Helper loaded: form_helper
INFO - 2018-02-07 12:23:02 --> Form Validation Class Initialized
INFO - 2018-02-07 12:23:02 --> Controller Class Initialized
INFO - 2018-02-07 12:23:02 --> Model Class Initialized
INFO - 2018-02-07 12:23:02 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:23:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:23:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:23:02 --> Model Class Initialized
INFO - 2018-02-07 12:23:02 --> Model Class Initialized
INFO - 2018-02-07 12:23:02 --> Model Class Initialized
INFO - 2018-02-07 12:23:02 --> Model Class Initialized
INFO - 2018-02-07 12:23:02 --> Model Class Initialized
INFO - 2018-02-07 12:23:02 --> Model Class Initialized
INFO - 2018-02-07 12:23:02 --> Model Class Initialized
INFO - 2018-02-07 12:23:02 --> Model Class Initialized
INFO - 2018-02-07 12:23:02 --> Model Class Initialized
INFO - 2018-02-07 12:23:02 --> Model Class Initialized
INFO - 2018-02-07 12:23:02 --> Model Class Initialized
INFO - 2018-02-07 12:23:02 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:23:02 --> Model Class Initialized
INFO - 2018-02-07 12:23:02 --> Final output sent to browser
DEBUG - 2018-02-07 12:23:02 --> Total execution time: 0.1328
INFO - 2018-02-07 06:53:26 --> Config Class Initialized
INFO - 2018-02-07 06:53:26 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:53:26 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:53:26 --> Utf8 Class Initialized
INFO - 2018-02-07 06:53:26 --> URI Class Initialized
INFO - 2018-02-07 06:53:26 --> Router Class Initialized
INFO - 2018-02-07 06:53:26 --> Output Class Initialized
INFO - 2018-02-07 06:53:26 --> Security Class Initialized
DEBUG - 2018-02-07 06:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:53:26 --> Input Class Initialized
INFO - 2018-02-07 06:53:26 --> Language Class Initialized
INFO - 2018-02-07 06:53:26 --> Language Class Initialized
INFO - 2018-02-07 06:53:26 --> Config Class Initialized
INFO - 2018-02-07 06:53:26 --> Loader Class Initialized
INFO - 2018-02-07 12:23:26 --> Helper loaded: url_helper
INFO - 2018-02-07 12:23:26 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:23:26 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:23:26 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:23:26 --> Helper loaded: users_helper
INFO - 2018-02-07 12:23:26 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:23:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:23:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:23:26 --> Helper loaded: form_helper
INFO - 2018-02-07 12:23:26 --> Form Validation Class Initialized
INFO - 2018-02-07 12:23:26 --> Controller Class Initialized
INFO - 2018-02-07 12:23:26 --> Model Class Initialized
INFO - 2018-02-07 12:23:26 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:23:26 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:23:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:23:26 --> Model Class Initialized
INFO - 2018-02-07 12:23:26 --> Model Class Initialized
INFO - 2018-02-07 12:23:26 --> Model Class Initialized
INFO - 2018-02-07 12:23:26 --> Model Class Initialized
INFO - 2018-02-07 12:23:26 --> Model Class Initialized
INFO - 2018-02-07 12:23:26 --> Model Class Initialized
INFO - 2018-02-07 12:23:26 --> Model Class Initialized
INFO - 2018-02-07 12:23:26 --> Model Class Initialized
INFO - 2018-02-07 12:23:26 --> Model Class Initialized
INFO - 2018-02-07 12:23:26 --> Model Class Initialized
INFO - 2018-02-07 12:23:26 --> Model Class Initialized
INFO - 2018-02-07 12:23:26 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:23:26 --> Final output sent to browser
DEBUG - 2018-02-07 12:23:26 --> Total execution time: 0.1124
INFO - 2018-02-07 06:53:28 --> Config Class Initialized
INFO - 2018-02-07 06:53:28 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:53:28 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:53:28 --> Utf8 Class Initialized
INFO - 2018-02-07 06:53:28 --> URI Class Initialized
INFO - 2018-02-07 06:53:28 --> Router Class Initialized
INFO - 2018-02-07 06:53:28 --> Output Class Initialized
INFO - 2018-02-07 06:53:28 --> Security Class Initialized
DEBUG - 2018-02-07 06:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:53:28 --> Input Class Initialized
INFO - 2018-02-07 06:53:28 --> Language Class Initialized
INFO - 2018-02-07 06:53:28 --> Language Class Initialized
INFO - 2018-02-07 06:53:28 --> Config Class Initialized
INFO - 2018-02-07 06:53:28 --> Loader Class Initialized
INFO - 2018-02-07 12:23:28 --> Helper loaded: url_helper
INFO - 2018-02-07 12:23:28 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:23:28 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:23:28 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:23:28 --> Helper loaded: users_helper
INFO - 2018-02-07 12:23:28 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:23:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:23:28 --> Helper loaded: form_helper
INFO - 2018-02-07 12:23:28 --> Form Validation Class Initialized
INFO - 2018-02-07 12:23:28 --> Controller Class Initialized
INFO - 2018-02-07 12:23:28 --> Model Class Initialized
INFO - 2018-02-07 12:23:28 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:23:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:23:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:23:28 --> Model Class Initialized
INFO - 2018-02-07 12:23:28 --> Model Class Initialized
INFO - 2018-02-07 12:23:28 --> Model Class Initialized
INFO - 2018-02-07 12:23:28 --> Model Class Initialized
INFO - 2018-02-07 12:23:28 --> Model Class Initialized
INFO - 2018-02-07 12:23:28 --> Model Class Initialized
INFO - 2018-02-07 12:23:28 --> Model Class Initialized
INFO - 2018-02-07 12:23:28 --> Model Class Initialized
INFO - 2018-02-07 12:23:28 --> Model Class Initialized
INFO - 2018-02-07 12:23:28 --> Model Class Initialized
INFO - 2018-02-07 12:23:28 --> Model Class Initialized
INFO - 2018-02-07 12:23:28 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:23:28 --> Final output sent to browser
DEBUG - 2018-02-07 12:23:28 --> Total execution time: 0.0977
INFO - 2018-02-07 06:53:35 --> Config Class Initialized
INFO - 2018-02-07 06:53:35 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:53:35 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:53:35 --> Utf8 Class Initialized
INFO - 2018-02-07 06:53:35 --> URI Class Initialized
INFO - 2018-02-07 06:53:35 --> Router Class Initialized
INFO - 2018-02-07 06:53:35 --> Output Class Initialized
INFO - 2018-02-07 06:53:35 --> Security Class Initialized
DEBUG - 2018-02-07 06:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:53:35 --> Input Class Initialized
INFO - 2018-02-07 06:53:35 --> Language Class Initialized
INFO - 2018-02-07 06:53:35 --> Language Class Initialized
INFO - 2018-02-07 06:53:35 --> Config Class Initialized
INFO - 2018-02-07 06:53:35 --> Loader Class Initialized
INFO - 2018-02-07 12:23:35 --> Helper loaded: url_helper
INFO - 2018-02-07 12:23:35 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:23:35 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:23:35 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:23:35 --> Helper loaded: users_helper
INFO - 2018-02-07 12:23:35 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:23:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:23:35 --> Helper loaded: form_helper
INFO - 2018-02-07 12:23:35 --> Form Validation Class Initialized
INFO - 2018-02-07 12:23:35 --> Controller Class Initialized
INFO - 2018-02-07 12:23:35 --> Model Class Initialized
INFO - 2018-02-07 12:23:35 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:23:35 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:23:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:23:35 --> Model Class Initialized
INFO - 2018-02-07 12:23:35 --> Model Class Initialized
INFO - 2018-02-07 12:23:35 --> Model Class Initialized
INFO - 2018-02-07 12:23:35 --> Model Class Initialized
INFO - 2018-02-07 12:23:35 --> Model Class Initialized
INFO - 2018-02-07 12:23:35 --> Model Class Initialized
INFO - 2018-02-07 12:23:35 --> Model Class Initialized
INFO - 2018-02-07 12:23:35 --> Model Class Initialized
INFO - 2018-02-07 12:23:35 --> Model Class Initialized
INFO - 2018-02-07 12:23:35 --> Model Class Initialized
INFO - 2018-02-07 12:23:35 --> Model Class Initialized
INFO - 2018-02-07 12:23:35 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:23:35 --> Final output sent to browser
DEBUG - 2018-02-07 12:23:35 --> Total execution time: 0.1140
INFO - 2018-02-07 06:53:37 --> Config Class Initialized
INFO - 2018-02-07 06:53:37 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:53:37 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:53:37 --> Utf8 Class Initialized
INFO - 2018-02-07 06:53:37 --> URI Class Initialized
INFO - 2018-02-07 06:53:37 --> Router Class Initialized
INFO - 2018-02-07 06:53:37 --> Output Class Initialized
INFO - 2018-02-07 06:53:37 --> Security Class Initialized
DEBUG - 2018-02-07 06:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:53:37 --> Input Class Initialized
INFO - 2018-02-07 06:53:37 --> Language Class Initialized
INFO - 2018-02-07 06:53:37 --> Language Class Initialized
INFO - 2018-02-07 06:53:37 --> Config Class Initialized
INFO - 2018-02-07 06:53:37 --> Loader Class Initialized
INFO - 2018-02-07 12:23:37 --> Helper loaded: url_helper
INFO - 2018-02-07 12:23:37 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:23:37 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:23:37 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:23:37 --> Helper loaded: users_helper
INFO - 2018-02-07 12:23:37 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:23:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:23:37 --> Helper loaded: form_helper
INFO - 2018-02-07 12:23:37 --> Form Validation Class Initialized
INFO - 2018-02-07 12:23:37 --> Controller Class Initialized
INFO - 2018-02-07 12:23:37 --> Model Class Initialized
INFO - 2018-02-07 12:23:37 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:23:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:23:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:23:37 --> Model Class Initialized
INFO - 2018-02-07 12:23:37 --> Model Class Initialized
INFO - 2018-02-07 12:23:37 --> Model Class Initialized
INFO - 2018-02-07 12:23:37 --> Model Class Initialized
INFO - 2018-02-07 12:23:37 --> Model Class Initialized
INFO - 2018-02-07 12:23:37 --> Model Class Initialized
INFO - 2018-02-07 12:23:37 --> Model Class Initialized
INFO - 2018-02-07 12:23:37 --> Model Class Initialized
INFO - 2018-02-07 12:23:37 --> Model Class Initialized
INFO - 2018-02-07 12:23:37 --> Model Class Initialized
INFO - 2018-02-07 12:23:37 --> Model Class Initialized
INFO - 2018-02-07 12:23:37 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:23:37 --> Final output sent to browser
DEBUG - 2018-02-07 12:23:37 --> Total execution time: 0.1232
INFO - 2018-02-07 06:55:28 --> Config Class Initialized
INFO - 2018-02-07 06:55:28 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:55:28 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:55:28 --> Utf8 Class Initialized
INFO - 2018-02-07 06:55:28 --> URI Class Initialized
INFO - 2018-02-07 06:55:28 --> Router Class Initialized
INFO - 2018-02-07 06:55:28 --> Output Class Initialized
INFO - 2018-02-07 06:55:28 --> Security Class Initialized
DEBUG - 2018-02-07 06:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:55:28 --> Input Class Initialized
INFO - 2018-02-07 06:55:28 --> Language Class Initialized
INFO - 2018-02-07 06:55:28 --> Language Class Initialized
INFO - 2018-02-07 06:55:28 --> Config Class Initialized
INFO - 2018-02-07 06:55:28 --> Loader Class Initialized
INFO - 2018-02-07 12:25:28 --> Helper loaded: url_helper
INFO - 2018-02-07 12:25:28 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:25:28 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:25:28 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:25:28 --> Helper loaded: users_helper
INFO - 2018-02-07 12:25:28 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:25:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:25:28 --> Helper loaded: form_helper
INFO - 2018-02-07 12:25:28 --> Form Validation Class Initialized
INFO - 2018-02-07 12:25:28 --> Controller Class Initialized
INFO - 2018-02-07 12:25:28 --> Model Class Initialized
INFO - 2018-02-07 12:25:28 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:25:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:25:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:25:28 --> Model Class Initialized
INFO - 2018-02-07 12:25:28 --> Model Class Initialized
INFO - 2018-02-07 12:25:28 --> Model Class Initialized
INFO - 2018-02-07 12:25:28 --> Model Class Initialized
INFO - 2018-02-07 12:25:28 --> Model Class Initialized
INFO - 2018-02-07 12:25:28 --> Model Class Initialized
INFO - 2018-02-07 12:25:28 --> Model Class Initialized
INFO - 2018-02-07 12:25:28 --> Model Class Initialized
INFO - 2018-02-07 12:25:28 --> Model Class Initialized
INFO - 2018-02-07 12:25:28 --> Model Class Initialized
INFO - 2018-02-07 12:25:28 --> Model Class Initialized
INFO - 2018-02-07 12:25:28 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:25:28 --> Final output sent to browser
DEBUG - 2018-02-07 12:25:28 --> Total execution time: 0.1304
INFO - 2018-02-07 06:58:53 --> Config Class Initialized
INFO - 2018-02-07 06:58:53 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:58:53 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:58:53 --> Utf8 Class Initialized
INFO - 2018-02-07 06:58:53 --> URI Class Initialized
INFO - 2018-02-07 06:58:53 --> Router Class Initialized
INFO - 2018-02-07 06:58:53 --> Output Class Initialized
INFO - 2018-02-07 06:58:53 --> Security Class Initialized
DEBUG - 2018-02-07 06:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:58:53 --> Input Class Initialized
INFO - 2018-02-07 06:58:53 --> Language Class Initialized
INFO - 2018-02-07 06:58:53 --> Language Class Initialized
INFO - 2018-02-07 06:58:53 --> Config Class Initialized
INFO - 2018-02-07 06:58:53 --> Loader Class Initialized
INFO - 2018-02-07 12:28:53 --> Helper loaded: url_helper
INFO - 2018-02-07 12:28:53 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:28:53 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:28:53 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:28:53 --> Helper loaded: users_helper
INFO - 2018-02-07 12:28:53 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:28:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:28:53 --> Helper loaded: form_helper
INFO - 2018-02-07 12:28:53 --> Form Validation Class Initialized
INFO - 2018-02-07 12:28:53 --> Controller Class Initialized
INFO - 2018-02-07 12:28:53 --> Model Class Initialized
INFO - 2018-02-07 12:28:53 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:28:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:28:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:28:53 --> Model Class Initialized
INFO - 2018-02-07 12:28:53 --> Model Class Initialized
INFO - 2018-02-07 12:28:53 --> Model Class Initialized
INFO - 2018-02-07 12:28:53 --> Model Class Initialized
INFO - 2018-02-07 12:28:53 --> Model Class Initialized
INFO - 2018-02-07 12:28:53 --> Model Class Initialized
INFO - 2018-02-07 12:28:53 --> Model Class Initialized
INFO - 2018-02-07 12:28:53 --> Model Class Initialized
INFO - 2018-02-07 12:28:53 --> Model Class Initialized
INFO - 2018-02-07 12:28:53 --> Model Class Initialized
INFO - 2018-02-07 12:28:53 --> Model Class Initialized
INFO - 2018-02-07 12:28:53 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:28:53 --> Model Class Initialized
INFO - 2018-02-07 12:28:53 --> Final output sent to browser
DEBUG - 2018-02-07 12:28:53 --> Total execution time: 0.1368
INFO - 2018-02-07 06:58:54 --> Config Class Initialized
INFO - 2018-02-07 06:58:54 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:58:54 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:58:54 --> Utf8 Class Initialized
INFO - 2018-02-07 06:58:54 --> URI Class Initialized
INFO - 2018-02-07 06:58:54 --> Router Class Initialized
INFO - 2018-02-07 06:58:54 --> Output Class Initialized
INFO - 2018-02-07 06:58:54 --> Security Class Initialized
DEBUG - 2018-02-07 06:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:58:54 --> Input Class Initialized
INFO - 2018-02-07 06:58:54 --> Language Class Initialized
INFO - 2018-02-07 06:58:54 --> Language Class Initialized
INFO - 2018-02-07 06:58:54 --> Config Class Initialized
INFO - 2018-02-07 06:58:54 --> Loader Class Initialized
INFO - 2018-02-07 12:28:54 --> Helper loaded: url_helper
INFO - 2018-02-07 12:28:54 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:28:54 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:28:54 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:28:54 --> Helper loaded: users_helper
INFO - 2018-02-07 12:28:54 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:28:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:28:54 --> Helper loaded: form_helper
INFO - 2018-02-07 12:28:54 --> Form Validation Class Initialized
INFO - 2018-02-07 12:28:54 --> Controller Class Initialized
INFO - 2018-02-07 12:28:54 --> Model Class Initialized
INFO - 2018-02-07 12:28:54 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:28:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:28:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:28:54 --> Model Class Initialized
INFO - 2018-02-07 12:28:54 --> Model Class Initialized
INFO - 2018-02-07 12:28:54 --> Model Class Initialized
INFO - 2018-02-07 12:28:54 --> Model Class Initialized
INFO - 2018-02-07 12:28:54 --> Model Class Initialized
INFO - 2018-02-07 12:28:54 --> Model Class Initialized
INFO - 2018-02-07 12:28:54 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:28:54 --> Model Class Initialized
INFO - 2018-02-07 12:28:54 --> Final output sent to browser
DEBUG - 2018-02-07 12:28:54 --> Total execution time: 0.1172
INFO - 2018-02-07 06:59:05 --> Config Class Initialized
INFO - 2018-02-07 06:59:05 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:59:05 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:59:05 --> Utf8 Class Initialized
INFO - 2018-02-07 06:59:05 --> URI Class Initialized
INFO - 2018-02-07 06:59:05 --> Router Class Initialized
INFO - 2018-02-07 06:59:05 --> Output Class Initialized
INFO - 2018-02-07 06:59:05 --> Security Class Initialized
DEBUG - 2018-02-07 06:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:59:05 --> Input Class Initialized
INFO - 2018-02-07 06:59:05 --> Language Class Initialized
INFO - 2018-02-07 06:59:05 --> Language Class Initialized
INFO - 2018-02-07 06:59:05 --> Config Class Initialized
INFO - 2018-02-07 06:59:05 --> Loader Class Initialized
INFO - 2018-02-07 12:29:05 --> Helper loaded: url_helper
INFO - 2018-02-07 12:29:05 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:29:05 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:29:05 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:29:05 --> Helper loaded: users_helper
INFO - 2018-02-07 12:29:05 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:29:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:29:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:29:05 --> Helper loaded: form_helper
INFO - 2018-02-07 12:29:05 --> Form Validation Class Initialized
INFO - 2018-02-07 12:29:05 --> Controller Class Initialized
INFO - 2018-02-07 12:29:05 --> Model Class Initialized
INFO - 2018-02-07 12:29:05 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:29:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:29:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:29:05 --> Model Class Initialized
INFO - 2018-02-07 12:29:05 --> Model Class Initialized
INFO - 2018-02-07 12:29:05 --> Model Class Initialized
INFO - 2018-02-07 12:29:05 --> Model Class Initialized
INFO - 2018-02-07 12:29:05 --> Model Class Initialized
INFO - 2018-02-07 12:29:05 --> Model Class Initialized
INFO - 2018-02-07 12:29:05 --> Model Class Initialized
INFO - 2018-02-07 12:29:05 --> Model Class Initialized
INFO - 2018-02-07 12:29:05 --> Model Class Initialized
INFO - 2018-02-07 12:29:05 --> Model Class Initialized
INFO - 2018-02-07 12:29:05 --> Model Class Initialized
INFO - 2018-02-07 12:29:05 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 12:29:05 --> Model Class Initialized
INFO - 2018-02-07 12:29:05 --> Final output sent to browser
DEBUG - 2018-02-07 12:29:05 --> Total execution time: 0.0960
INFO - 2018-02-07 06:59:30 --> Config Class Initialized
INFO - 2018-02-07 06:59:30 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:59:30 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:59:30 --> Utf8 Class Initialized
INFO - 2018-02-07 06:59:30 --> URI Class Initialized
INFO - 2018-02-07 06:59:30 --> Router Class Initialized
INFO - 2018-02-07 06:59:30 --> Output Class Initialized
INFO - 2018-02-07 06:59:30 --> Security Class Initialized
DEBUG - 2018-02-07 06:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:59:30 --> Input Class Initialized
INFO - 2018-02-07 06:59:30 --> Language Class Initialized
INFO - 2018-02-07 06:59:30 --> Language Class Initialized
INFO - 2018-02-07 06:59:30 --> Config Class Initialized
INFO - 2018-02-07 06:59:30 --> Loader Class Initialized
INFO - 2018-02-07 12:29:30 --> Helper loaded: url_helper
INFO - 2018-02-07 12:29:30 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:29:30 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:29:30 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:29:30 --> Helper loaded: users_helper
INFO - 2018-02-07 12:29:30 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:29:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:29:30 --> Helper loaded: form_helper
INFO - 2018-02-07 12:29:30 --> Form Validation Class Initialized
INFO - 2018-02-07 12:29:30 --> Controller Class Initialized
INFO - 2018-02-07 12:29:30 --> Model Class Initialized
INFO - 2018-02-07 12:29:30 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:29:30 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:29:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:29:30 --> Model Class Initialized
INFO - 2018-02-07 12:29:30 --> Model Class Initialized
INFO - 2018-02-07 12:29:30 --> Model Class Initialized
INFO - 2018-02-07 12:29:30 --> Model Class Initialized
INFO - 2018-02-07 12:29:30 --> Model Class Initialized
INFO - 2018-02-07 12:29:30 --> Model Class Initialized
INFO - 2018-02-07 12:29:30 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-02-07 12:29:30 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 771
ERROR - 2018-02-07 12:29:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 781
INFO - 2018-02-07 12:29:30 --> Final output sent to browser
DEBUG - 2018-02-07 12:29:30 --> Total execution time: 0.1197
INFO - 2018-02-07 06:59:47 --> Config Class Initialized
INFO - 2018-02-07 06:59:47 --> Hooks Class Initialized
DEBUG - 2018-02-07 06:59:47 --> UTF-8 Support Enabled
INFO - 2018-02-07 06:59:47 --> Utf8 Class Initialized
INFO - 2018-02-07 06:59:47 --> URI Class Initialized
INFO - 2018-02-07 06:59:47 --> Router Class Initialized
INFO - 2018-02-07 06:59:47 --> Output Class Initialized
INFO - 2018-02-07 06:59:47 --> Security Class Initialized
DEBUG - 2018-02-07 06:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 06:59:47 --> Input Class Initialized
INFO - 2018-02-07 06:59:47 --> Language Class Initialized
INFO - 2018-02-07 06:59:47 --> Language Class Initialized
INFO - 2018-02-07 06:59:47 --> Config Class Initialized
INFO - 2018-02-07 06:59:47 --> Loader Class Initialized
INFO - 2018-02-07 12:29:47 --> Helper loaded: url_helper
INFO - 2018-02-07 12:29:47 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:29:47 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:29:47 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:29:47 --> Helper loaded: users_helper
INFO - 2018-02-07 12:29:47 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:29:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:29:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:29:47 --> Helper loaded: form_helper
INFO - 2018-02-07 12:29:47 --> Form Validation Class Initialized
INFO - 2018-02-07 12:29:47 --> Controller Class Initialized
INFO - 2018-02-07 12:29:47 --> Model Class Initialized
INFO - 2018-02-07 12:29:47 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:29:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:29:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:29:47 --> Model Class Initialized
INFO - 2018-02-07 12:29:47 --> Model Class Initialized
INFO - 2018-02-07 12:29:47 --> Model Class Initialized
INFO - 2018-02-07 12:29:47 --> Model Class Initialized
INFO - 2018-02-07 12:29:47 --> Model Class Initialized
INFO - 2018-02-07 12:29:47 --> Model Class Initialized
INFO - 2018-02-07 12:29:47 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-02-07 12:29:47 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 771
INFO - 2018-02-07 12:29:47 --> Final output sent to browser
DEBUG - 2018-02-07 12:29:47 --> Total execution time: 0.0777
INFO - 2018-02-07 07:01:13 --> Config Class Initialized
INFO - 2018-02-07 07:01:13 --> Hooks Class Initialized
DEBUG - 2018-02-07 07:01:13 --> UTF-8 Support Enabled
INFO - 2018-02-07 07:01:13 --> Utf8 Class Initialized
INFO - 2018-02-07 07:01:13 --> URI Class Initialized
INFO - 2018-02-07 07:01:13 --> Router Class Initialized
INFO - 2018-02-07 07:01:13 --> Output Class Initialized
INFO - 2018-02-07 07:01:13 --> Security Class Initialized
DEBUG - 2018-02-07 07:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 07:01:13 --> Input Class Initialized
INFO - 2018-02-07 07:01:13 --> Language Class Initialized
INFO - 2018-02-07 07:01:13 --> Language Class Initialized
INFO - 2018-02-07 07:01:13 --> Config Class Initialized
INFO - 2018-02-07 07:01:13 --> Loader Class Initialized
INFO - 2018-02-07 12:31:13 --> Helper loaded: url_helper
INFO - 2018-02-07 12:31:13 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:31:13 --> Helper loaded: settings_helper
INFO - 2018-02-07 12:31:13 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:31:13 --> Helper loaded: users_helper
INFO - 2018-02-07 12:31:13 --> Database Driver Class Initialized
DEBUG - 2018-02-07 12:31:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 12:31:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:31:13 --> Helper loaded: form_helper
INFO - 2018-02-07 12:31:13 --> Form Validation Class Initialized
INFO - 2018-02-07 12:31:13 --> Controller Class Initialized
INFO - 2018-02-07 12:31:13 --> Model Class Initialized
INFO - 2018-02-07 12:31:13 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 12:31:13 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 12:31:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 12:31:13 --> Model Class Initialized
INFO - 2018-02-07 12:31:13 --> Model Class Initialized
INFO - 2018-02-07 12:31:13 --> Model Class Initialized
INFO - 2018-02-07 12:31:13 --> Model Class Initialized
INFO - 2018-02-07 12:31:13 --> Model Class Initialized
INFO - 2018-02-07 12:31:13 --> Model Class Initialized
INFO - 2018-02-07 12:31:13 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-02-07 12:31:13 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 771
ERROR - 2018-02-07 12:31:13 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 781
INFO - 2018-02-07 12:31:13 --> Final output sent to browser
DEBUG - 2018-02-07 12:31:13 --> Total execution time: 0.1009
INFO - 2018-02-07 07:30:25 --> Config Class Initialized
INFO - 2018-02-07 07:30:25 --> Hooks Class Initialized
DEBUG - 2018-02-07 07:30:25 --> UTF-8 Support Enabled
INFO - 2018-02-07 07:30:25 --> Utf8 Class Initialized
INFO - 2018-02-07 07:30:25 --> URI Class Initialized
INFO - 2018-02-07 07:30:25 --> Router Class Initialized
INFO - 2018-02-07 07:30:25 --> Output Class Initialized
INFO - 2018-02-07 07:30:25 --> Security Class Initialized
DEBUG - 2018-02-07 07:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 07:30:25 --> Input Class Initialized
INFO - 2018-02-07 07:30:25 --> Language Class Initialized
INFO - 2018-02-07 07:30:25 --> Language Class Initialized
INFO - 2018-02-07 07:30:25 --> Config Class Initialized
INFO - 2018-02-07 07:30:25 --> Loader Class Initialized
INFO - 2018-02-07 13:00:25 --> Helper loaded: url_helper
INFO - 2018-02-07 13:00:25 --> Helper loaded: notification_helper
INFO - 2018-02-07 13:00:25 --> Helper loaded: settings_helper
INFO - 2018-02-07 13:00:25 --> Helper loaded: permission_helper
INFO - 2018-02-07 13:00:25 --> Helper loaded: users_helper
INFO - 2018-02-07 13:00:25 --> Database Driver Class Initialized
DEBUG - 2018-02-07 13:00:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 13:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 13:00:25 --> Helper loaded: form_helper
INFO - 2018-02-07 13:00:25 --> Form Validation Class Initialized
INFO - 2018-02-07 13:00:25 --> Controller Class Initialized
INFO - 2018-02-07 13:00:25 --> Model Class Initialized
INFO - 2018-02-07 13:00:25 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 13:00:25 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 13:00:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 13:00:25 --> Model Class Initialized
INFO - 2018-02-07 13:00:25 --> Model Class Initialized
INFO - 2018-02-07 13:00:25 --> Model Class Initialized
INFO - 2018-02-07 13:00:25 --> Model Class Initialized
INFO - 2018-02-07 13:00:25 --> Model Class Initialized
INFO - 2018-02-07 13:00:25 --> Model Class Initialized
INFO - 2018-02-07 13:00:25 --> Model Class Initialized
INFO - 2018-02-07 13:00:25 --> Model Class Initialized
INFO - 2018-02-07 13:00:25 --> Model Class Initialized
INFO - 2018-02-07 13:00:25 --> Model Class Initialized
INFO - 2018-02-07 13:00:25 --> Model Class Initialized
INFO - 2018-02-07 13:00:25 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 13:00:25 --> Model Class Initialized
INFO - 2018-02-07 13:00:25 --> Final output sent to browser
DEBUG - 2018-02-07 13:00:25 --> Total execution time: 0.1335
INFO - 2018-02-07 07:30:25 --> Config Class Initialized
INFO - 2018-02-07 07:30:25 --> Hooks Class Initialized
DEBUG - 2018-02-07 07:30:25 --> UTF-8 Support Enabled
INFO - 2018-02-07 07:30:25 --> Utf8 Class Initialized
INFO - 2018-02-07 07:30:25 --> URI Class Initialized
INFO - 2018-02-07 07:30:25 --> Router Class Initialized
INFO - 2018-02-07 07:30:25 --> Output Class Initialized
INFO - 2018-02-07 07:30:25 --> Security Class Initialized
DEBUG - 2018-02-07 07:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 07:30:25 --> Input Class Initialized
INFO - 2018-02-07 07:30:25 --> Language Class Initialized
INFO - 2018-02-07 07:30:25 --> Language Class Initialized
INFO - 2018-02-07 07:30:25 --> Config Class Initialized
INFO - 2018-02-07 07:30:25 --> Loader Class Initialized
INFO - 2018-02-07 13:00:25 --> Helper loaded: url_helper
INFO - 2018-02-07 13:00:25 --> Helper loaded: notification_helper
INFO - 2018-02-07 13:00:25 --> Helper loaded: settings_helper
INFO - 2018-02-07 13:00:25 --> Helper loaded: permission_helper
INFO - 2018-02-07 13:00:25 --> Helper loaded: users_helper
INFO - 2018-02-07 13:00:25 --> Database Driver Class Initialized
DEBUG - 2018-02-07 13:00:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 13:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 13:00:25 --> Helper loaded: form_helper
INFO - 2018-02-07 13:00:25 --> Form Validation Class Initialized
INFO - 2018-02-07 13:00:25 --> Controller Class Initialized
INFO - 2018-02-07 13:00:25 --> Model Class Initialized
INFO - 2018-02-07 13:00:25 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 13:00:25 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 13:00:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 13:00:25 --> Model Class Initialized
INFO - 2018-02-07 13:00:25 --> Model Class Initialized
INFO - 2018-02-07 13:00:25 --> Model Class Initialized
INFO - 2018-02-07 13:00:25 --> Model Class Initialized
INFO - 2018-02-07 13:00:25 --> Model Class Initialized
INFO - 2018-02-07 13:00:25 --> Model Class Initialized
INFO - 2018-02-07 13:00:25 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 13:00:25 --> Model Class Initialized
INFO - 2018-02-07 13:00:25 --> Final output sent to browser
DEBUG - 2018-02-07 13:00:25 --> Total execution time: 0.1188
INFO - 2018-02-07 07:31:00 --> Config Class Initialized
INFO - 2018-02-07 07:31:00 --> Hooks Class Initialized
DEBUG - 2018-02-07 07:31:00 --> UTF-8 Support Enabled
INFO - 2018-02-07 07:31:00 --> Utf8 Class Initialized
INFO - 2018-02-07 07:31:00 --> URI Class Initialized
INFO - 2018-02-07 07:31:00 --> Router Class Initialized
INFO - 2018-02-07 07:31:00 --> Output Class Initialized
INFO - 2018-02-07 07:31:00 --> Security Class Initialized
DEBUG - 2018-02-07 07:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 07:31:00 --> Input Class Initialized
INFO - 2018-02-07 07:31:00 --> Language Class Initialized
INFO - 2018-02-07 07:31:00 --> Language Class Initialized
INFO - 2018-02-07 07:31:00 --> Config Class Initialized
INFO - 2018-02-07 07:31:00 --> Loader Class Initialized
INFO - 2018-02-07 13:01:00 --> Helper loaded: url_helper
INFO - 2018-02-07 13:01:00 --> Helper loaded: notification_helper
INFO - 2018-02-07 13:01:00 --> Helper loaded: settings_helper
INFO - 2018-02-07 13:01:00 --> Helper loaded: permission_helper
INFO - 2018-02-07 13:01:00 --> Helper loaded: users_helper
INFO - 2018-02-07 13:01:00 --> Database Driver Class Initialized
DEBUG - 2018-02-07 13:01:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 13:01:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 13:01:00 --> Helper loaded: form_helper
INFO - 2018-02-07 13:01:00 --> Form Validation Class Initialized
INFO - 2018-02-07 13:01:00 --> Controller Class Initialized
INFO - 2018-02-07 13:01:00 --> Model Class Initialized
INFO - 2018-02-07 13:01:00 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 13:01:00 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 13:01:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 13:01:00 --> Model Class Initialized
INFO - 2018-02-07 13:01:00 --> Model Class Initialized
INFO - 2018-02-07 13:01:00 --> Model Class Initialized
INFO - 2018-02-07 13:01:00 --> Model Class Initialized
INFO - 2018-02-07 13:01:00 --> Model Class Initialized
INFO - 2018-02-07 13:01:00 --> Model Class Initialized
INFO - 2018-02-07 13:01:00 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 13:01:00 --> Model Class Initialized
INFO - 2018-02-07 13:01:00 --> Model Class Initialized
INFO - 2018-02-07 13:01:00 --> Model Class Initialized
INFO - 2018-02-07 13:01:00 --> Final output sent to browser
DEBUG - 2018-02-07 13:01:00 --> Total execution time: 0.2468
INFO - 2018-02-07 07:33:17 --> Config Class Initialized
INFO - 2018-02-07 07:33:17 --> Hooks Class Initialized
DEBUG - 2018-02-07 07:33:17 --> UTF-8 Support Enabled
INFO - 2018-02-07 07:33:17 --> Utf8 Class Initialized
INFO - 2018-02-07 07:33:17 --> URI Class Initialized
INFO - 2018-02-07 07:33:17 --> Router Class Initialized
INFO - 2018-02-07 07:33:17 --> Config Class Initialized
INFO - 2018-02-07 07:33:17 --> Hooks Class Initialized
INFO - 2018-02-07 07:33:17 --> Output Class Initialized
DEBUG - 2018-02-07 07:33:17 --> UTF-8 Support Enabled
INFO - 2018-02-07 07:33:17 --> Utf8 Class Initialized
INFO - 2018-02-07 07:33:17 --> Security Class Initialized
INFO - 2018-02-07 07:33:17 --> URI Class Initialized
DEBUG - 2018-02-07 07:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 07:33:17 --> Input Class Initialized
INFO - 2018-02-07 07:33:17 --> Language Class Initialized
INFO - 2018-02-07 07:33:17 --> Router Class Initialized
INFO - 2018-02-07 07:33:17 --> Output Class Initialized
INFO - 2018-02-07 07:33:17 --> Security Class Initialized
DEBUG - 2018-02-07 07:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 07:33:17 --> Input Class Initialized
INFO - 2018-02-07 07:33:17 --> Language Class Initialized
INFO - 2018-02-07 07:33:17 --> Language Class Initialized
INFO - 2018-02-07 07:33:17 --> Config Class Initialized
INFO - 2018-02-07 07:33:17 --> Loader Class Initialized
INFO - 2018-02-07 13:03:17 --> Helper loaded: url_helper
INFO - 2018-02-07 13:03:17 --> Helper loaded: notification_helper
INFO - 2018-02-07 13:03:17 --> Helper loaded: settings_helper
INFO - 2018-02-07 13:03:17 --> Helper loaded: permission_helper
INFO - 2018-02-07 13:03:17 --> Helper loaded: users_helper
INFO - 2018-02-07 07:33:17 --> Language Class Initialized
INFO - 2018-02-07 07:33:17 --> Config Class Initialized
INFO - 2018-02-07 07:33:17 --> Loader Class Initialized
INFO - 2018-02-07 13:03:17 --> Helper loaded: url_helper
INFO - 2018-02-07 13:03:17 --> Helper loaded: notification_helper
INFO - 2018-02-07 13:03:17 --> Helper loaded: settings_helper
INFO - 2018-02-07 13:03:17 --> Helper loaded: permission_helper
INFO - 2018-02-07 13:03:17 --> Helper loaded: users_helper
INFO - 2018-02-07 13:03:17 --> Database Driver Class Initialized
DEBUG - 2018-02-07 13:03:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 13:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 13:03:17 --> Database Driver Class Initialized
INFO - 2018-02-07 13:03:17 --> Helper loaded: form_helper
INFO - 2018-02-07 13:03:17 --> Form Validation Class Initialized
INFO - 2018-02-07 13:03:17 --> Controller Class Initialized
DEBUG - 2018-02-07 13:03:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 13:03:17 --> Model Class Initialized
INFO - 2018-02-07 13:03:17 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 13:03:17 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 13:03:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 13:03:17 --> Model Class Initialized
INFO - 2018-02-07 13:03:17 --> Model Class Initialized
INFO - 2018-02-07 13:03:17 --> Model Class Initialized
INFO - 2018-02-07 13:03:17 --> Model Class Initialized
INFO - 2018-02-07 13:03:17 --> Model Class Initialized
INFO - 2018-02-07 13:03:17 --> Model Class Initialized
INFO - 2018-02-07 13:03:17 --> Model Class Initialized
INFO - 2018-02-07 13:03:17 --> Model Class Initialized
INFO - 2018-02-07 13:03:17 --> Model Class Initialized
INFO - 2018-02-07 13:03:17 --> Model Class Initialized
INFO - 2018-02-07 13:03:17 --> Model Class Initialized
INFO - 2018-02-07 13:03:17 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 13:03:17 --> Model Class Initialized
INFO - 2018-02-07 13:03:17 --> Final output sent to browser
DEBUG - 2018-02-07 13:03:17 --> Total execution time: 0.1329
INFO - 2018-02-07 13:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 13:03:17 --> Helper loaded: form_helper
INFO - 2018-02-07 13:03:17 --> Form Validation Class Initialized
INFO - 2018-02-07 13:03:17 --> Controller Class Initialized
INFO - 2018-02-07 13:03:17 --> Model Class Initialized
INFO - 2018-02-07 13:03:17 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 13:03:17 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 13:03:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 13:03:17 --> Model Class Initialized
INFO - 2018-02-07 13:03:17 --> Model Class Initialized
INFO - 2018-02-07 13:03:17 --> Model Class Initialized
INFO - 2018-02-07 13:03:17 --> Model Class Initialized
INFO - 2018-02-07 13:03:17 --> Model Class Initialized
INFO - 2018-02-07 13:03:17 --> Model Class Initialized
INFO - 2018-02-07 13:03:17 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 13:03:17 --> Model Class Initialized
INFO - 2018-02-07 13:03:17 --> Final output sent to browser
DEBUG - 2018-02-07 13:03:17 --> Total execution time: 0.1576
INFO - 2018-02-07 08:11:59 --> Config Class Initialized
INFO - 2018-02-07 08:11:59 --> Hooks Class Initialized
DEBUG - 2018-02-07 08:11:59 --> UTF-8 Support Enabled
INFO - 2018-02-07 08:11:59 --> Utf8 Class Initialized
INFO - 2018-02-07 08:11:59 --> URI Class Initialized
INFO - 2018-02-07 08:11:59 --> Router Class Initialized
INFO - 2018-02-07 08:11:59 --> Output Class Initialized
INFO - 2018-02-07 08:11:59 --> Security Class Initialized
DEBUG - 2018-02-07 08:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 08:11:59 --> Input Class Initialized
INFO - 2018-02-07 08:11:59 --> Language Class Initialized
INFO - 2018-02-07 08:11:59 --> Language Class Initialized
INFO - 2018-02-07 08:11:59 --> Config Class Initialized
INFO - 2018-02-07 08:11:59 --> Loader Class Initialized
INFO - 2018-02-07 13:41:59 --> Helper loaded: url_helper
INFO - 2018-02-07 13:41:59 --> Helper loaded: notification_helper
INFO - 2018-02-07 13:41:59 --> Helper loaded: settings_helper
INFO - 2018-02-07 13:41:59 --> Helper loaded: permission_helper
INFO - 2018-02-07 13:41:59 --> Helper loaded: users_helper
INFO - 2018-02-07 13:41:59 --> Database Driver Class Initialized
DEBUG - 2018-02-07 13:41:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 13:41:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 13:41:59 --> Helper loaded: form_helper
INFO - 2018-02-07 13:41:59 --> Form Validation Class Initialized
INFO - 2018-02-07 13:41:59 --> Controller Class Initialized
INFO - 2018-02-07 13:41:59 --> Model Class Initialized
INFO - 2018-02-07 13:41:59 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 13:41:59 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 13:41:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 13:41:59 --> Model Class Initialized
INFO - 2018-02-07 13:41:59 --> Model Class Initialized
INFO - 2018-02-07 13:41:59 --> Model Class Initialized
INFO - 2018-02-07 13:41:59 --> Model Class Initialized
INFO - 2018-02-07 13:41:59 --> Model Class Initialized
INFO - 2018-02-07 13:41:59 --> Model Class Initialized
INFO - 2018-02-07 13:41:59 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 13:41:59 --> Final output sent to browser
DEBUG - 2018-02-07 13:41:59 --> Total execution time: 0.0865
INFO - 2018-02-07 08:12:00 --> Config Class Initialized
INFO - 2018-02-07 08:12:00 --> Hooks Class Initialized
DEBUG - 2018-02-07 08:12:00 --> UTF-8 Support Enabled
INFO - 2018-02-07 08:12:00 --> Utf8 Class Initialized
INFO - 2018-02-07 08:12:00 --> URI Class Initialized
INFO - 2018-02-07 08:12:00 --> Router Class Initialized
INFO - 2018-02-07 08:12:00 --> Output Class Initialized
INFO - 2018-02-07 08:12:00 --> Security Class Initialized
DEBUG - 2018-02-07 08:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 08:12:00 --> Input Class Initialized
INFO - 2018-02-07 08:12:00 --> Language Class Initialized
INFO - 2018-02-07 08:12:00 --> Language Class Initialized
INFO - 2018-02-07 08:12:00 --> Config Class Initialized
INFO - 2018-02-07 08:12:00 --> Loader Class Initialized
INFO - 2018-02-07 13:42:00 --> Helper loaded: url_helper
INFO - 2018-02-07 13:42:00 --> Helper loaded: notification_helper
INFO - 2018-02-07 13:42:00 --> Helper loaded: settings_helper
INFO - 2018-02-07 13:42:00 --> Helper loaded: permission_helper
INFO - 2018-02-07 13:42:00 --> Helper loaded: users_helper
INFO - 2018-02-07 13:42:00 --> Database Driver Class Initialized
DEBUG - 2018-02-07 13:42:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 13:42:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 13:42:00 --> Helper loaded: form_helper
INFO - 2018-02-07 13:42:00 --> Form Validation Class Initialized
INFO - 2018-02-07 13:42:00 --> Controller Class Initialized
INFO - 2018-02-07 13:42:00 --> Model Class Initialized
INFO - 2018-02-07 13:42:00 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 13:42:00 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 13:42:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 13:42:00 --> Model Class Initialized
INFO - 2018-02-07 13:42:00 --> Model Class Initialized
INFO - 2018-02-07 13:42:00 --> Model Class Initialized
INFO - 2018-02-07 13:42:00 --> Model Class Initialized
INFO - 2018-02-07 13:42:00 --> Model Class Initialized
INFO - 2018-02-07 13:42:00 --> Model Class Initialized
INFO - 2018-02-07 13:42:00 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 13:42:00 --> Final output sent to browser
DEBUG - 2018-02-07 13:42:00 --> Total execution time: 0.1199
INFO - 2018-02-07 08:12:00 --> Config Class Initialized
INFO - 2018-02-07 08:12:00 --> Hooks Class Initialized
DEBUG - 2018-02-07 08:12:00 --> UTF-8 Support Enabled
INFO - 2018-02-07 08:12:00 --> Utf8 Class Initialized
INFO - 2018-02-07 08:12:00 --> URI Class Initialized
INFO - 2018-02-07 08:12:00 --> Router Class Initialized
INFO - 2018-02-07 08:12:00 --> Output Class Initialized
INFO - 2018-02-07 08:12:00 --> Security Class Initialized
DEBUG - 2018-02-07 08:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 08:12:00 --> Input Class Initialized
INFO - 2018-02-07 08:12:00 --> Language Class Initialized
INFO - 2018-02-07 08:12:00 --> Language Class Initialized
INFO - 2018-02-07 08:12:00 --> Config Class Initialized
INFO - 2018-02-07 08:12:00 --> Loader Class Initialized
INFO - 2018-02-07 13:42:00 --> Helper loaded: url_helper
INFO - 2018-02-07 13:42:00 --> Helper loaded: notification_helper
INFO - 2018-02-07 13:42:00 --> Helper loaded: settings_helper
INFO - 2018-02-07 13:42:00 --> Helper loaded: permission_helper
INFO - 2018-02-07 13:42:00 --> Helper loaded: users_helper
INFO - 2018-02-07 13:42:00 --> Database Driver Class Initialized
DEBUG - 2018-02-07 13:42:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 13:42:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 13:42:00 --> Helper loaded: form_helper
INFO - 2018-02-07 13:42:00 --> Form Validation Class Initialized
INFO - 2018-02-07 13:42:00 --> Controller Class Initialized
INFO - 2018-02-07 13:42:00 --> Model Class Initialized
INFO - 2018-02-07 13:42:00 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 13:42:00 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 13:42:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 13:42:00 --> Model Class Initialized
INFO - 2018-02-07 13:42:00 --> Model Class Initialized
INFO - 2018-02-07 13:42:00 --> Model Class Initialized
INFO - 2018-02-07 13:42:00 --> Model Class Initialized
INFO - 2018-02-07 13:42:00 --> Model Class Initialized
INFO - 2018-02-07 13:42:00 --> Model Class Initialized
INFO - 2018-02-07 13:42:00 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 13:42:00 --> Model Class Initialized
INFO - 2018-02-07 13:42:00 --> Final output sent to browser
DEBUG - 2018-02-07 13:42:00 --> Total execution time: 0.0884
INFO - 2018-02-07 08:12:00 --> Config Class Initialized
INFO - 2018-02-07 08:12:00 --> Hooks Class Initialized
DEBUG - 2018-02-07 08:12:00 --> UTF-8 Support Enabled
INFO - 2018-02-07 08:12:00 --> Utf8 Class Initialized
INFO - 2018-02-07 08:12:00 --> URI Class Initialized
INFO - 2018-02-07 08:12:00 --> Router Class Initialized
INFO - 2018-02-07 08:12:00 --> Output Class Initialized
INFO - 2018-02-07 08:12:00 --> Security Class Initialized
DEBUG - 2018-02-07 08:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 08:12:00 --> Input Class Initialized
INFO - 2018-02-07 08:12:00 --> Language Class Initialized
INFO - 2018-02-07 08:12:00 --> Language Class Initialized
INFO - 2018-02-07 08:12:00 --> Config Class Initialized
INFO - 2018-02-07 08:12:00 --> Loader Class Initialized
INFO - 2018-02-07 13:42:00 --> Helper loaded: url_helper
INFO - 2018-02-07 13:42:00 --> Helper loaded: notification_helper
INFO - 2018-02-07 13:42:00 --> Helper loaded: settings_helper
INFO - 2018-02-07 13:42:00 --> Helper loaded: permission_helper
INFO - 2018-02-07 13:42:00 --> Helper loaded: users_helper
INFO - 2018-02-07 13:42:00 --> Database Driver Class Initialized
DEBUG - 2018-02-07 13:42:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 13:42:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 08:12:00 --> Config Class Initialized
INFO - 2018-02-07 08:12:00 --> Hooks Class Initialized
DEBUG - 2018-02-07 08:12:00 --> UTF-8 Support Enabled
INFO - 2018-02-07 08:12:00 --> Utf8 Class Initialized
INFO - 2018-02-07 13:42:00 --> Helper loaded: form_helper
INFO - 2018-02-07 13:42:00 --> Form Validation Class Initialized
INFO - 2018-02-07 13:42:00 --> Controller Class Initialized
INFO - 2018-02-07 08:12:00 --> URI Class Initialized
INFO - 2018-02-07 08:12:00 --> Router Class Initialized
INFO - 2018-02-07 08:12:00 --> Output Class Initialized
INFO - 2018-02-07 13:42:00 --> Model Class Initialized
INFO - 2018-02-07 13:42:00 --> Helper loaded: inflector_helper
INFO - 2018-02-07 08:12:00 --> Security Class Initialized
DEBUG - 2018-02-07 13:42:00 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-02-07 08:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 08:12:00 --> Input Class Initialized
INFO - 2018-02-07 13:42:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 08:12:00 --> Language Class Initialized
INFO - 2018-02-07 13:42:00 --> Model Class Initialized
INFO - 2018-02-07 13:42:00 --> Model Class Initialized
INFO - 2018-02-07 13:42:00 --> Model Class Initialized
INFO - 2018-02-07 13:42:00 --> Model Class Initialized
INFO - 2018-02-07 13:42:00 --> Model Class Initialized
INFO - 2018-02-07 13:42:00 --> Model Class Initialized
INFO - 2018-02-07 13:42:00 --> Model Class Initialized
INFO - 2018-02-07 13:42:00 --> Model Class Initialized
INFO - 2018-02-07 13:42:00 --> Model Class Initialized
INFO - 2018-02-07 13:42:00 --> Model Class Initialized
INFO - 2018-02-07 13:42:00 --> Model Class Initialized
INFO - 2018-02-07 13:42:00 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 13:42:00 --> Model Class Initialized
INFO - 2018-02-07 13:42:00 --> Final output sent to browser
DEBUG - 2018-02-07 13:42:00 --> Total execution time: 0.1190
INFO - 2018-02-07 08:12:00 --> Language Class Initialized
INFO - 2018-02-07 08:12:00 --> Config Class Initialized
INFO - 2018-02-07 08:12:00 --> Loader Class Initialized
INFO - 2018-02-07 13:42:00 --> Helper loaded: url_helper
INFO - 2018-02-07 13:42:00 --> Helper loaded: notification_helper
INFO - 2018-02-07 13:42:00 --> Helper loaded: settings_helper
INFO - 2018-02-07 13:42:00 --> Helper loaded: permission_helper
INFO - 2018-02-07 13:42:00 --> Helper loaded: users_helper
INFO - 2018-02-07 13:42:00 --> Database Driver Class Initialized
DEBUG - 2018-02-07 13:42:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 13:42:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 13:42:00 --> Helper loaded: form_helper
INFO - 2018-02-07 13:42:00 --> Form Validation Class Initialized
INFO - 2018-02-07 13:42:00 --> Controller Class Initialized
INFO - 2018-02-07 13:42:00 --> Model Class Initialized
INFO - 2018-02-07 13:42:00 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 13:42:00 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 13:42:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 13:42:00 --> Model Class Initialized
INFO - 2018-02-07 13:42:00 --> Model Class Initialized
INFO - 2018-02-07 13:42:00 --> Model Class Initialized
INFO - 2018-02-07 13:42:00 --> Model Class Initialized
INFO - 2018-02-07 13:42:00 --> Model Class Initialized
INFO - 2018-02-07 13:42:00 --> Model Class Initialized
INFO - 2018-02-07 13:42:00 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 13:42:00 --> Model Class Initialized
INFO - 2018-02-07 13:42:00 --> Final output sent to browser
DEBUG - 2018-02-07 13:42:00 --> Total execution time: 0.1168
INFO - 2018-02-07 08:12:01 --> Config Class Initialized
INFO - 2018-02-07 08:12:01 --> Hooks Class Initialized
DEBUG - 2018-02-07 08:12:01 --> UTF-8 Support Enabled
INFO - 2018-02-07 08:12:01 --> Utf8 Class Initialized
INFO - 2018-02-07 08:12:01 --> URI Class Initialized
INFO - 2018-02-07 08:12:01 --> Router Class Initialized
INFO - 2018-02-07 08:12:01 --> Output Class Initialized
INFO - 2018-02-07 08:12:01 --> Security Class Initialized
DEBUG - 2018-02-07 08:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 08:12:01 --> Input Class Initialized
INFO - 2018-02-07 08:12:01 --> Language Class Initialized
INFO - 2018-02-07 08:12:01 --> Language Class Initialized
INFO - 2018-02-07 08:12:01 --> Config Class Initialized
INFO - 2018-02-07 08:12:01 --> Loader Class Initialized
INFO - 2018-02-07 13:42:01 --> Helper loaded: url_helper
INFO - 2018-02-07 13:42:01 --> Helper loaded: notification_helper
INFO - 2018-02-07 13:42:01 --> Helper loaded: settings_helper
INFO - 2018-02-07 13:42:01 --> Helper loaded: permission_helper
INFO - 2018-02-07 13:42:01 --> Helper loaded: users_helper
INFO - 2018-02-07 13:42:01 --> Database Driver Class Initialized
DEBUG - 2018-02-07 13:42:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 13:42:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 13:42:01 --> Helper loaded: form_helper
INFO - 2018-02-07 13:42:01 --> Form Validation Class Initialized
INFO - 2018-02-07 13:42:01 --> Controller Class Initialized
INFO - 2018-02-07 13:42:01 --> Model Class Initialized
INFO - 2018-02-07 13:42:01 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 13:42:01 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 13:42:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 13:42:01 --> Model Class Initialized
INFO - 2018-02-07 13:42:01 --> Model Class Initialized
INFO - 2018-02-07 13:42:01 --> Model Class Initialized
INFO - 2018-02-07 13:42:01 --> Model Class Initialized
INFO - 2018-02-07 13:42:01 --> Model Class Initialized
INFO - 2018-02-07 13:42:01 --> Model Class Initialized
INFO - 2018-02-07 13:42:01 --> Model Class Initialized
INFO - 2018-02-07 13:42:01 --> Model Class Initialized
INFO - 2018-02-07 13:42:01 --> Model Class Initialized
INFO - 2018-02-07 13:42:01 --> Model Class Initialized
INFO - 2018-02-07 13:42:01 --> Model Class Initialized
INFO - 2018-02-07 13:42:01 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 13:42:01 --> Model Class Initialized
INFO - 2018-02-07 13:42:01 --> Final output sent to browser
DEBUG - 2018-02-07 13:42:01 --> Total execution time: 0.1195
INFO - 2018-02-07 08:24:39 --> Config Class Initialized
INFO - 2018-02-07 08:24:39 --> Hooks Class Initialized
DEBUG - 2018-02-07 08:24:39 --> UTF-8 Support Enabled
INFO - 2018-02-07 08:24:39 --> Utf8 Class Initialized
INFO - 2018-02-07 08:24:39 --> URI Class Initialized
INFO - 2018-02-07 08:24:39 --> Router Class Initialized
INFO - 2018-02-07 08:24:39 --> Output Class Initialized
INFO - 2018-02-07 08:24:39 --> Security Class Initialized
DEBUG - 2018-02-07 08:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 08:24:39 --> Input Class Initialized
INFO - 2018-02-07 08:24:39 --> Language Class Initialized
INFO - 2018-02-07 08:24:39 --> Language Class Initialized
INFO - 2018-02-07 08:24:39 --> Config Class Initialized
INFO - 2018-02-07 08:24:39 --> Loader Class Initialized
INFO - 2018-02-07 13:54:39 --> Helper loaded: url_helper
INFO - 2018-02-07 13:54:39 --> Helper loaded: notification_helper
INFO - 2018-02-07 13:54:39 --> Helper loaded: settings_helper
INFO - 2018-02-07 13:54:39 --> Helper loaded: permission_helper
INFO - 2018-02-07 13:54:39 --> Helper loaded: users_helper
INFO - 2018-02-07 13:54:39 --> Database Driver Class Initialized
DEBUG - 2018-02-07 13:54:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 13:54:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 13:54:39 --> Helper loaded: form_helper
INFO - 2018-02-07 13:54:39 --> Form Validation Class Initialized
INFO - 2018-02-07 13:54:39 --> Controller Class Initialized
INFO - 2018-02-07 13:54:39 --> Model Class Initialized
INFO - 2018-02-07 13:54:39 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 13:54:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 13:54:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 13:54:39 --> Model Class Initialized
INFO - 2018-02-07 13:54:39 --> Model Class Initialized
INFO - 2018-02-07 13:54:39 --> Model Class Initialized
INFO - 2018-02-07 13:54:39 --> Model Class Initialized
INFO - 2018-02-07 13:54:39 --> Model Class Initialized
INFO - 2018-02-07 13:54:39 --> Model Class Initialized
INFO - 2018-02-07 13:54:39 --> Model Class Initialized
INFO - 2018-02-07 13:54:39 --> Model Class Initialized
INFO - 2018-02-07 13:54:39 --> Model Class Initialized
INFO - 2018-02-07 13:54:39 --> Model Class Initialized
INFO - 2018-02-07 13:54:39 --> Model Class Initialized
INFO - 2018-02-07 13:54:39 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 13:54:39 --> Model Class Initialized
INFO - 2018-02-07 13:54:39 --> Final output sent to browser
DEBUG - 2018-02-07 13:54:39 --> Total execution time: 0.1161
INFO - 2018-02-07 08:24:39 --> Config Class Initialized
INFO - 2018-02-07 08:24:39 --> Hooks Class Initialized
DEBUG - 2018-02-07 08:24:39 --> UTF-8 Support Enabled
INFO - 2018-02-07 08:24:39 --> Utf8 Class Initialized
INFO - 2018-02-07 08:24:39 --> URI Class Initialized
INFO - 2018-02-07 08:24:39 --> Router Class Initialized
INFO - 2018-02-07 08:24:39 --> Output Class Initialized
INFO - 2018-02-07 08:24:39 --> Security Class Initialized
DEBUG - 2018-02-07 08:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 08:24:39 --> Input Class Initialized
INFO - 2018-02-07 08:24:39 --> Language Class Initialized
INFO - 2018-02-07 08:24:39 --> Language Class Initialized
INFO - 2018-02-07 08:24:39 --> Config Class Initialized
INFO - 2018-02-07 08:24:39 --> Loader Class Initialized
INFO - 2018-02-07 13:54:40 --> Helper loaded: url_helper
INFO - 2018-02-07 13:54:40 --> Helper loaded: notification_helper
INFO - 2018-02-07 13:54:40 --> Helper loaded: settings_helper
INFO - 2018-02-07 13:54:40 --> Helper loaded: permission_helper
INFO - 2018-02-07 13:54:40 --> Helper loaded: users_helper
INFO - 2018-02-07 13:54:40 --> Database Driver Class Initialized
DEBUG - 2018-02-07 13:54:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 13:54:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 13:54:40 --> Helper loaded: form_helper
INFO - 2018-02-07 13:54:40 --> Form Validation Class Initialized
INFO - 2018-02-07 13:54:40 --> Controller Class Initialized
INFO - 2018-02-07 13:54:40 --> Model Class Initialized
INFO - 2018-02-07 13:54:40 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 13:54:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 13:54:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 13:54:40 --> Model Class Initialized
INFO - 2018-02-07 13:54:40 --> Model Class Initialized
INFO - 2018-02-07 13:54:40 --> Model Class Initialized
INFO - 2018-02-07 13:54:40 --> Model Class Initialized
INFO - 2018-02-07 13:54:40 --> Model Class Initialized
INFO - 2018-02-07 13:54:40 --> Model Class Initialized
INFO - 2018-02-07 13:54:40 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 13:54:40 --> Model Class Initialized
INFO - 2018-02-07 13:54:40 --> Final output sent to browser
DEBUG - 2018-02-07 13:54:40 --> Total execution time: 0.1184
INFO - 2018-02-07 08:24:55 --> Config Class Initialized
INFO - 2018-02-07 08:24:55 --> Hooks Class Initialized
DEBUG - 2018-02-07 08:24:55 --> UTF-8 Support Enabled
INFO - 2018-02-07 08:24:55 --> Utf8 Class Initialized
INFO - 2018-02-07 08:24:55 --> URI Class Initialized
INFO - 2018-02-07 08:24:55 --> Router Class Initialized
INFO - 2018-02-07 08:24:55 --> Output Class Initialized
INFO - 2018-02-07 08:24:55 --> Security Class Initialized
DEBUG - 2018-02-07 08:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 08:24:55 --> Input Class Initialized
INFO - 2018-02-07 08:24:55 --> Language Class Initialized
INFO - 2018-02-07 08:24:55 --> Language Class Initialized
INFO - 2018-02-07 08:24:55 --> Config Class Initialized
INFO - 2018-02-07 08:24:55 --> Loader Class Initialized
INFO - 2018-02-07 13:54:55 --> Helper loaded: url_helper
INFO - 2018-02-07 13:54:55 --> Helper loaded: notification_helper
INFO - 2018-02-07 13:54:55 --> Helper loaded: settings_helper
INFO - 2018-02-07 13:54:55 --> Helper loaded: permission_helper
INFO - 2018-02-07 13:54:55 --> Helper loaded: users_helper
INFO - 2018-02-07 13:54:55 --> Database Driver Class Initialized
DEBUG - 2018-02-07 13:54:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 13:54:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 13:54:55 --> Helper loaded: form_helper
INFO - 2018-02-07 13:54:55 --> Form Validation Class Initialized
INFO - 2018-02-07 13:54:55 --> Controller Class Initialized
INFO - 2018-02-07 13:54:55 --> Model Class Initialized
INFO - 2018-02-07 13:54:55 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 13:54:55 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 13:54:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 13:54:55 --> Model Class Initialized
INFO - 2018-02-07 13:54:55 --> Model Class Initialized
INFO - 2018-02-07 13:54:55 --> Model Class Initialized
INFO - 2018-02-07 13:54:55 --> Model Class Initialized
INFO - 2018-02-07 13:54:55 --> Model Class Initialized
INFO - 2018-02-07 13:54:55 --> Model Class Initialized
INFO - 2018-02-07 13:54:55 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-02-07 13:54:55 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 771
INFO - 2018-02-07 13:54:55 --> Final output sent to browser
DEBUG - 2018-02-07 13:54:55 --> Total execution time: 0.1158
INFO - 2018-02-07 08:27:33 --> Config Class Initialized
INFO - 2018-02-07 08:27:33 --> Hooks Class Initialized
DEBUG - 2018-02-07 08:27:33 --> UTF-8 Support Enabled
INFO - 2018-02-07 08:27:33 --> Utf8 Class Initialized
INFO - 2018-02-07 08:27:33 --> URI Class Initialized
INFO - 2018-02-07 08:27:33 --> Router Class Initialized
INFO - 2018-02-07 08:27:33 --> Output Class Initialized
INFO - 2018-02-07 08:27:33 --> Security Class Initialized
DEBUG - 2018-02-07 08:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 08:27:33 --> Input Class Initialized
INFO - 2018-02-07 08:27:33 --> Language Class Initialized
INFO - 2018-02-07 08:27:33 --> Language Class Initialized
INFO - 2018-02-07 08:27:33 --> Config Class Initialized
INFO - 2018-02-07 08:27:33 --> Loader Class Initialized
INFO - 2018-02-07 13:57:33 --> Helper loaded: url_helper
INFO - 2018-02-07 13:57:33 --> Helper loaded: notification_helper
INFO - 2018-02-07 13:57:33 --> Helper loaded: settings_helper
INFO - 2018-02-07 13:57:33 --> Helper loaded: permission_helper
INFO - 2018-02-07 13:57:33 --> Helper loaded: users_helper
INFO - 2018-02-07 13:57:34 --> Database Driver Class Initialized
DEBUG - 2018-02-07 13:57:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 13:57:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 13:57:34 --> Helper loaded: form_helper
INFO - 2018-02-07 13:57:34 --> Form Validation Class Initialized
INFO - 2018-02-07 13:57:34 --> Controller Class Initialized
INFO - 2018-02-07 13:57:34 --> Model Class Initialized
INFO - 2018-02-07 13:57:34 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 13:57:34 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 13:57:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 13:57:34 --> Model Class Initialized
INFO - 2018-02-07 13:57:34 --> Model Class Initialized
INFO - 2018-02-07 13:57:34 --> Model Class Initialized
INFO - 2018-02-07 13:57:34 --> Model Class Initialized
INFO - 2018-02-07 13:57:34 --> Model Class Initialized
INFO - 2018-02-07 13:57:34 --> Model Class Initialized
INFO - 2018-02-07 13:57:34 --> Model Class Initialized
INFO - 2018-02-07 13:57:34 --> Model Class Initialized
INFO - 2018-02-07 13:57:34 --> Model Class Initialized
INFO - 2018-02-07 13:57:34 --> Model Class Initialized
INFO - 2018-02-07 13:57:34 --> Model Class Initialized
INFO - 2018-02-07 13:57:34 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 13:57:34 --> Model Class Initialized
INFO - 2018-02-07 13:57:34 --> Final output sent to browser
DEBUG - 2018-02-07 13:57:34 --> Total execution time: 0.1257
INFO - 2018-02-07 08:27:34 --> Config Class Initialized
INFO - 2018-02-07 08:27:34 --> Hooks Class Initialized
DEBUG - 2018-02-07 08:27:34 --> UTF-8 Support Enabled
INFO - 2018-02-07 08:27:34 --> Utf8 Class Initialized
INFO - 2018-02-07 08:27:34 --> URI Class Initialized
INFO - 2018-02-07 08:27:34 --> Router Class Initialized
INFO - 2018-02-07 08:27:34 --> Output Class Initialized
INFO - 2018-02-07 08:27:34 --> Security Class Initialized
DEBUG - 2018-02-07 08:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 08:27:34 --> Input Class Initialized
INFO - 2018-02-07 08:27:34 --> Language Class Initialized
INFO - 2018-02-07 08:27:34 --> Language Class Initialized
INFO - 2018-02-07 08:27:34 --> Config Class Initialized
INFO - 2018-02-07 08:27:34 --> Loader Class Initialized
INFO - 2018-02-07 13:57:34 --> Helper loaded: url_helper
INFO - 2018-02-07 13:57:34 --> Helper loaded: notification_helper
INFO - 2018-02-07 13:57:34 --> Helper loaded: settings_helper
INFO - 2018-02-07 13:57:34 --> Helper loaded: permission_helper
INFO - 2018-02-07 13:57:34 --> Helper loaded: users_helper
INFO - 2018-02-07 13:57:34 --> Database Driver Class Initialized
DEBUG - 2018-02-07 13:57:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 13:57:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 13:57:34 --> Helper loaded: form_helper
INFO - 2018-02-07 13:57:34 --> Form Validation Class Initialized
INFO - 2018-02-07 13:57:34 --> Controller Class Initialized
INFO - 2018-02-07 13:57:34 --> Model Class Initialized
INFO - 2018-02-07 13:57:34 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 13:57:34 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 13:57:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 13:57:34 --> Model Class Initialized
INFO - 2018-02-07 13:57:34 --> Model Class Initialized
INFO - 2018-02-07 13:57:34 --> Model Class Initialized
INFO - 2018-02-07 13:57:34 --> Model Class Initialized
INFO - 2018-02-07 13:57:34 --> Model Class Initialized
INFO - 2018-02-07 13:57:34 --> Model Class Initialized
INFO - 2018-02-07 13:57:34 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 13:57:34 --> Model Class Initialized
INFO - 2018-02-07 13:57:34 --> Final output sent to browser
DEBUG - 2018-02-07 13:57:34 --> Total execution time: 0.0933
INFO - 2018-02-07 08:27:41 --> Config Class Initialized
INFO - 2018-02-07 08:27:41 --> Hooks Class Initialized
DEBUG - 2018-02-07 08:27:41 --> UTF-8 Support Enabled
INFO - 2018-02-07 08:27:41 --> Utf8 Class Initialized
INFO - 2018-02-07 08:27:41 --> URI Class Initialized
INFO - 2018-02-07 08:27:41 --> Router Class Initialized
INFO - 2018-02-07 08:27:41 --> Output Class Initialized
INFO - 2018-02-07 08:27:41 --> Security Class Initialized
DEBUG - 2018-02-07 08:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 08:27:41 --> Input Class Initialized
INFO - 2018-02-07 08:27:41 --> Language Class Initialized
INFO - 2018-02-07 08:27:41 --> Language Class Initialized
INFO - 2018-02-07 08:27:41 --> Config Class Initialized
INFO - 2018-02-07 08:27:41 --> Loader Class Initialized
INFO - 2018-02-07 13:57:41 --> Helper loaded: url_helper
INFO - 2018-02-07 13:57:41 --> Helper loaded: notification_helper
INFO - 2018-02-07 13:57:41 --> Helper loaded: settings_helper
INFO - 2018-02-07 13:57:41 --> Helper loaded: permission_helper
INFO - 2018-02-07 13:57:41 --> Helper loaded: users_helper
INFO - 2018-02-07 13:57:41 --> Database Driver Class Initialized
DEBUG - 2018-02-07 13:57:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 13:57:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 13:57:41 --> Helper loaded: form_helper
INFO - 2018-02-07 13:57:41 --> Form Validation Class Initialized
INFO - 2018-02-07 13:57:41 --> Controller Class Initialized
INFO - 2018-02-07 13:57:41 --> Model Class Initialized
INFO - 2018-02-07 13:57:41 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 13:57:41 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 13:57:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 13:57:41 --> Model Class Initialized
INFO - 2018-02-07 13:57:41 --> Model Class Initialized
INFO - 2018-02-07 13:57:41 --> Model Class Initialized
INFO - 2018-02-07 13:57:41 --> Model Class Initialized
INFO - 2018-02-07 13:57:41 --> Model Class Initialized
INFO - 2018-02-07 13:57:41 --> Model Class Initialized
INFO - 2018-02-07 13:57:41 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-02-07 13:57:41 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 771
INFO - 2018-02-07 13:57:41 --> Final output sent to browser
DEBUG - 2018-02-07 13:57:41 --> Total execution time: 0.1069
INFO - 2018-02-07 08:27:51 --> Config Class Initialized
INFO - 2018-02-07 08:27:51 --> Hooks Class Initialized
DEBUG - 2018-02-07 08:27:51 --> UTF-8 Support Enabled
INFO - 2018-02-07 08:27:51 --> Utf8 Class Initialized
INFO - 2018-02-07 08:27:51 --> URI Class Initialized
INFO - 2018-02-07 08:27:51 --> Router Class Initialized
INFO - 2018-02-07 08:27:51 --> Output Class Initialized
INFO - 2018-02-07 08:27:51 --> Security Class Initialized
DEBUG - 2018-02-07 08:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 08:27:51 --> Input Class Initialized
INFO - 2018-02-07 08:27:51 --> Language Class Initialized
INFO - 2018-02-07 08:27:51 --> Language Class Initialized
INFO - 2018-02-07 08:27:51 --> Config Class Initialized
INFO - 2018-02-07 08:27:51 --> Loader Class Initialized
INFO - 2018-02-07 13:57:51 --> Helper loaded: url_helper
INFO - 2018-02-07 13:57:51 --> Helper loaded: notification_helper
INFO - 2018-02-07 13:57:51 --> Helper loaded: settings_helper
INFO - 2018-02-07 13:57:51 --> Helper loaded: permission_helper
INFO - 2018-02-07 13:57:51 --> Helper loaded: users_helper
INFO - 2018-02-07 13:57:51 --> Database Driver Class Initialized
DEBUG - 2018-02-07 13:57:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 13:57:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 13:57:51 --> Helper loaded: form_helper
INFO - 2018-02-07 13:57:51 --> Form Validation Class Initialized
INFO - 2018-02-07 13:57:51 --> Controller Class Initialized
INFO - 2018-02-07 13:57:51 --> Model Class Initialized
INFO - 2018-02-07 13:57:51 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 13:57:51 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 13:57:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 13:57:51 --> Model Class Initialized
INFO - 2018-02-07 13:57:51 --> Model Class Initialized
INFO - 2018-02-07 13:57:51 --> Model Class Initialized
INFO - 2018-02-07 13:57:51 --> Model Class Initialized
INFO - 2018-02-07 13:57:51 --> Model Class Initialized
INFO - 2018-02-07 13:57:51 --> Model Class Initialized
INFO - 2018-02-07 13:57:51 --> Model Class Initialized
INFO - 2018-02-07 13:57:51 --> Model Class Initialized
INFO - 2018-02-07 13:57:51 --> Model Class Initialized
INFO - 2018-02-07 13:57:51 --> Model Class Initialized
INFO - 2018-02-07 13:57:51 --> Model Class Initialized
INFO - 2018-02-07 13:57:51 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 13:57:51 --> Model Class Initialized
INFO - 2018-02-07 13:57:51 --> Final output sent to browser
DEBUG - 2018-02-07 13:57:51 --> Total execution time: 0.0888
INFO - 2018-02-07 08:27:54 --> Config Class Initialized
INFO - 2018-02-07 08:27:54 --> Hooks Class Initialized
DEBUG - 2018-02-07 08:27:54 --> UTF-8 Support Enabled
INFO - 2018-02-07 08:27:54 --> Utf8 Class Initialized
INFO - 2018-02-07 08:27:54 --> URI Class Initialized
INFO - 2018-02-07 08:27:54 --> Router Class Initialized
INFO - 2018-02-07 08:27:54 --> Output Class Initialized
INFO - 2018-02-07 08:27:54 --> Security Class Initialized
DEBUG - 2018-02-07 08:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 08:27:54 --> Input Class Initialized
INFO - 2018-02-07 08:27:54 --> Language Class Initialized
INFO - 2018-02-07 08:27:54 --> Language Class Initialized
INFO - 2018-02-07 08:27:54 --> Config Class Initialized
INFO - 2018-02-07 08:27:54 --> Loader Class Initialized
INFO - 2018-02-07 13:57:54 --> Helper loaded: url_helper
INFO - 2018-02-07 13:57:54 --> Helper loaded: notification_helper
INFO - 2018-02-07 13:57:54 --> Helper loaded: settings_helper
INFO - 2018-02-07 13:57:54 --> Helper loaded: permission_helper
INFO - 2018-02-07 13:57:54 --> Helper loaded: users_helper
INFO - 2018-02-07 13:57:54 --> Database Driver Class Initialized
DEBUG - 2018-02-07 13:57:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 13:57:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 13:57:54 --> Helper loaded: form_helper
INFO - 2018-02-07 13:57:54 --> Form Validation Class Initialized
INFO - 2018-02-07 13:57:54 --> Controller Class Initialized
INFO - 2018-02-07 13:57:54 --> Model Class Initialized
INFO - 2018-02-07 13:57:54 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 13:57:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 13:57:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 13:57:54 --> Model Class Initialized
INFO - 2018-02-07 13:57:54 --> Model Class Initialized
INFO - 2018-02-07 13:57:54 --> Model Class Initialized
INFO - 2018-02-07 13:57:54 --> Model Class Initialized
INFO - 2018-02-07 13:57:54 --> Model Class Initialized
INFO - 2018-02-07 13:57:54 --> Model Class Initialized
INFO - 2018-02-07 13:57:54 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-02-07 13:57:54 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 771
ERROR - 2018-02-07 13:57:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 781
INFO - 2018-02-07 13:57:54 --> Final output sent to browser
DEBUG - 2018-02-07 13:57:54 --> Total execution time: 0.1204
INFO - 2018-02-07 08:28:14 --> Config Class Initialized
INFO - 2018-02-07 08:28:14 --> Hooks Class Initialized
DEBUG - 2018-02-07 08:28:14 --> UTF-8 Support Enabled
INFO - 2018-02-07 08:28:14 --> Utf8 Class Initialized
INFO - 2018-02-07 08:28:14 --> URI Class Initialized
INFO - 2018-02-07 08:28:14 --> Router Class Initialized
INFO - 2018-02-07 08:28:14 --> Output Class Initialized
INFO - 2018-02-07 08:28:14 --> Security Class Initialized
DEBUG - 2018-02-07 08:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 08:28:14 --> Input Class Initialized
INFO - 2018-02-07 08:28:14 --> Language Class Initialized
INFO - 2018-02-07 08:28:14 --> Language Class Initialized
INFO - 2018-02-07 08:28:14 --> Config Class Initialized
INFO - 2018-02-07 08:28:14 --> Loader Class Initialized
INFO - 2018-02-07 13:58:14 --> Helper loaded: url_helper
INFO - 2018-02-07 13:58:14 --> Helper loaded: notification_helper
INFO - 2018-02-07 13:58:14 --> Helper loaded: settings_helper
INFO - 2018-02-07 13:58:14 --> Helper loaded: permission_helper
INFO - 2018-02-07 13:58:14 --> Helper loaded: users_helper
INFO - 2018-02-07 13:58:14 --> Database Driver Class Initialized
DEBUG - 2018-02-07 13:58:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 13:58:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 13:58:14 --> Helper loaded: form_helper
INFO - 2018-02-07 13:58:14 --> Form Validation Class Initialized
INFO - 2018-02-07 13:58:14 --> Controller Class Initialized
INFO - 2018-02-07 13:58:14 --> Model Class Initialized
INFO - 2018-02-07 13:58:14 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 13:58:14 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 13:58:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 13:58:14 --> Model Class Initialized
INFO - 2018-02-07 13:58:14 --> Model Class Initialized
INFO - 2018-02-07 13:58:14 --> Model Class Initialized
INFO - 2018-02-07 13:58:14 --> Model Class Initialized
INFO - 2018-02-07 13:58:14 --> Model Class Initialized
INFO - 2018-02-07 13:58:14 --> Model Class Initialized
INFO - 2018-02-07 13:58:14 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-02-07 13:58:14 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 771
INFO - 2018-02-07 13:58:14 --> Final output sent to browser
DEBUG - 2018-02-07 13:58:14 --> Total execution time: 0.1001
INFO - 2018-02-07 08:28:40 --> Config Class Initialized
INFO - 2018-02-07 08:28:40 --> Hooks Class Initialized
DEBUG - 2018-02-07 08:28:40 --> UTF-8 Support Enabled
INFO - 2018-02-07 08:28:40 --> Utf8 Class Initialized
INFO - 2018-02-07 08:28:40 --> URI Class Initialized
INFO - 2018-02-07 08:28:40 --> Router Class Initialized
INFO - 2018-02-07 08:28:40 --> Output Class Initialized
INFO - 2018-02-07 08:28:40 --> Security Class Initialized
DEBUG - 2018-02-07 08:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 08:28:40 --> Input Class Initialized
INFO - 2018-02-07 08:28:40 --> Language Class Initialized
INFO - 2018-02-07 08:28:40 --> Language Class Initialized
INFO - 2018-02-07 08:28:40 --> Config Class Initialized
INFO - 2018-02-07 08:28:40 --> Loader Class Initialized
INFO - 2018-02-07 13:58:40 --> Helper loaded: url_helper
INFO - 2018-02-07 13:58:40 --> Helper loaded: notification_helper
INFO - 2018-02-07 13:58:40 --> Helper loaded: settings_helper
INFO - 2018-02-07 13:58:40 --> Helper loaded: permission_helper
INFO - 2018-02-07 13:58:40 --> Helper loaded: users_helper
INFO - 2018-02-07 13:58:40 --> Database Driver Class Initialized
DEBUG - 2018-02-07 13:58:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 13:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 13:58:41 --> Helper loaded: form_helper
INFO - 2018-02-07 13:58:41 --> Form Validation Class Initialized
INFO - 2018-02-07 13:58:41 --> Controller Class Initialized
INFO - 2018-02-07 13:58:41 --> Model Class Initialized
INFO - 2018-02-07 13:58:41 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 13:58:41 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 13:58:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 13:58:41 --> Model Class Initialized
INFO - 2018-02-07 13:58:41 --> Model Class Initialized
INFO - 2018-02-07 13:58:41 --> Model Class Initialized
INFO - 2018-02-07 13:58:41 --> Model Class Initialized
INFO - 2018-02-07 13:58:41 --> Model Class Initialized
INFO - 2018-02-07 13:58:41 --> Model Class Initialized
INFO - 2018-02-07 13:58:41 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-02-07 13:58:41 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 771
ERROR - 2018-02-07 13:58:41 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 781
INFO - 2018-02-07 13:58:41 --> Final output sent to browser
DEBUG - 2018-02-07 13:58:41 --> Total execution time: 0.1232
INFO - 2018-02-07 08:31:55 --> Config Class Initialized
INFO - 2018-02-07 08:31:55 --> Hooks Class Initialized
DEBUG - 2018-02-07 08:31:55 --> UTF-8 Support Enabled
INFO - 2018-02-07 08:31:55 --> Utf8 Class Initialized
INFO - 2018-02-07 08:31:55 --> URI Class Initialized
INFO - 2018-02-07 08:31:55 --> Router Class Initialized
INFO - 2018-02-07 08:31:55 --> Output Class Initialized
INFO - 2018-02-07 08:31:55 --> Security Class Initialized
DEBUG - 2018-02-07 08:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 08:31:55 --> Input Class Initialized
INFO - 2018-02-07 08:31:55 --> Language Class Initialized
INFO - 2018-02-07 08:31:55 --> Language Class Initialized
INFO - 2018-02-07 08:31:55 --> Config Class Initialized
INFO - 2018-02-07 08:31:55 --> Loader Class Initialized
INFO - 2018-02-07 14:01:55 --> Helper loaded: url_helper
INFO - 2018-02-07 14:01:55 --> Helper loaded: notification_helper
INFO - 2018-02-07 14:01:55 --> Helper loaded: settings_helper
INFO - 2018-02-07 14:01:55 --> Helper loaded: permission_helper
INFO - 2018-02-07 14:01:55 --> Helper loaded: users_helper
INFO - 2018-02-07 14:01:55 --> Database Driver Class Initialized
DEBUG - 2018-02-07 14:01:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 14:01:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 14:01:55 --> Helper loaded: form_helper
INFO - 2018-02-07 14:01:55 --> Form Validation Class Initialized
INFO - 2018-02-07 14:01:55 --> Controller Class Initialized
INFO - 2018-02-07 14:01:55 --> Model Class Initialized
INFO - 2018-02-07 14:01:55 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 14:01:55 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 14:01:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 14:01:55 --> Model Class Initialized
INFO - 2018-02-07 14:01:55 --> Model Class Initialized
INFO - 2018-02-07 14:01:55 --> Model Class Initialized
INFO - 2018-02-07 14:01:55 --> Model Class Initialized
INFO - 2018-02-07 14:01:55 --> Model Class Initialized
INFO - 2018-02-07 14:01:55 --> Model Class Initialized
INFO - 2018-02-07 14:01:55 --> Model Class Initialized
INFO - 2018-02-07 14:01:55 --> Model Class Initialized
INFO - 2018-02-07 14:01:55 --> Model Class Initialized
INFO - 2018-02-07 14:01:55 --> Model Class Initialized
INFO - 2018-02-07 14:01:55 --> Model Class Initialized
INFO - 2018-02-07 14:01:55 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 14:01:55 --> Model Class Initialized
INFO - 2018-02-07 14:01:55 --> Final output sent to browser
DEBUG - 2018-02-07 14:01:55 --> Total execution time: 0.1337
INFO - 2018-02-07 08:31:57 --> Config Class Initialized
INFO - 2018-02-07 08:31:57 --> Hooks Class Initialized
DEBUG - 2018-02-07 08:31:57 --> UTF-8 Support Enabled
INFO - 2018-02-07 08:31:57 --> Utf8 Class Initialized
INFO - 2018-02-07 08:31:57 --> URI Class Initialized
INFO - 2018-02-07 08:31:57 --> Router Class Initialized
INFO - 2018-02-07 08:31:57 --> Output Class Initialized
INFO - 2018-02-07 08:31:57 --> Security Class Initialized
DEBUG - 2018-02-07 08:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 08:31:57 --> Input Class Initialized
INFO - 2018-02-07 08:31:57 --> Language Class Initialized
INFO - 2018-02-07 08:31:57 --> Language Class Initialized
INFO - 2018-02-07 08:31:57 --> Config Class Initialized
INFO - 2018-02-07 08:31:57 --> Loader Class Initialized
INFO - 2018-02-07 14:01:57 --> Helper loaded: url_helper
INFO - 2018-02-07 14:01:57 --> Helper loaded: notification_helper
INFO - 2018-02-07 14:01:57 --> Helper loaded: settings_helper
INFO - 2018-02-07 14:01:57 --> Helper loaded: permission_helper
INFO - 2018-02-07 14:01:57 --> Helper loaded: users_helper
INFO - 2018-02-07 14:01:57 --> Database Driver Class Initialized
DEBUG - 2018-02-07 14:01:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 14:01:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 14:01:57 --> Helper loaded: form_helper
INFO - 2018-02-07 14:01:57 --> Form Validation Class Initialized
INFO - 2018-02-07 14:01:57 --> Controller Class Initialized
INFO - 2018-02-07 14:01:57 --> Model Class Initialized
INFO - 2018-02-07 14:01:57 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 14:01:57 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 14:01:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 14:01:57 --> Model Class Initialized
INFO - 2018-02-07 14:01:57 --> Model Class Initialized
INFO - 2018-02-07 14:01:57 --> Model Class Initialized
INFO - 2018-02-07 14:01:57 --> Model Class Initialized
INFO - 2018-02-07 14:01:57 --> Model Class Initialized
INFO - 2018-02-07 14:01:57 --> Model Class Initialized
INFO - 2018-02-07 14:01:57 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 14:01:57 --> Model Class Initialized
INFO - 2018-02-07 14:01:57 --> Final output sent to browser
DEBUG - 2018-02-07 14:01:57 --> Total execution time: 0.2364
INFO - 2018-02-07 08:32:03 --> Config Class Initialized
INFO - 2018-02-07 08:32:03 --> Hooks Class Initialized
DEBUG - 2018-02-07 08:32:03 --> UTF-8 Support Enabled
INFO - 2018-02-07 08:32:03 --> Utf8 Class Initialized
INFO - 2018-02-07 08:32:03 --> URI Class Initialized
INFO - 2018-02-07 08:32:03 --> Router Class Initialized
INFO - 2018-02-07 08:32:03 --> Output Class Initialized
INFO - 2018-02-07 08:32:03 --> Security Class Initialized
DEBUG - 2018-02-07 08:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 08:32:03 --> Input Class Initialized
INFO - 2018-02-07 08:32:03 --> Language Class Initialized
INFO - 2018-02-07 08:32:03 --> Language Class Initialized
INFO - 2018-02-07 08:32:03 --> Config Class Initialized
INFO - 2018-02-07 08:32:03 --> Loader Class Initialized
INFO - 2018-02-07 14:02:03 --> Helper loaded: url_helper
INFO - 2018-02-07 14:02:03 --> Helper loaded: notification_helper
INFO - 2018-02-07 14:02:03 --> Helper loaded: settings_helper
INFO - 2018-02-07 14:02:03 --> Helper loaded: permission_helper
INFO - 2018-02-07 14:02:03 --> Helper loaded: users_helper
INFO - 2018-02-07 14:02:03 --> Database Driver Class Initialized
DEBUG - 2018-02-07 14:02:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 14:02:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 14:02:03 --> Helper loaded: form_helper
INFO - 2018-02-07 14:02:03 --> Form Validation Class Initialized
INFO - 2018-02-07 14:02:03 --> Controller Class Initialized
INFO - 2018-02-07 14:02:03 --> Model Class Initialized
INFO - 2018-02-07 14:02:03 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 14:02:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 14:02:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 14:02:03 --> Model Class Initialized
INFO - 2018-02-07 14:02:03 --> Model Class Initialized
INFO - 2018-02-07 14:02:03 --> Model Class Initialized
INFO - 2018-02-07 14:02:03 --> Model Class Initialized
INFO - 2018-02-07 14:02:03 --> Model Class Initialized
INFO - 2018-02-07 14:02:03 --> Model Class Initialized
INFO - 2018-02-07 14:02:03 --> Model Class Initialized
INFO - 2018-02-07 14:02:03 --> Model Class Initialized
INFO - 2018-02-07 14:02:03 --> Model Class Initialized
INFO - 2018-02-07 14:02:03 --> Model Class Initialized
INFO - 2018-02-07 14:02:03 --> Model Class Initialized
INFO - 2018-02-07 14:02:03 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 14:02:03 --> Model Class Initialized
INFO - 2018-02-07 14:02:03 --> Final output sent to browser
DEBUG - 2018-02-07 14:02:03 --> Total execution time: 0.1351
INFO - 2018-02-07 08:32:09 --> Config Class Initialized
INFO - 2018-02-07 08:32:09 --> Hooks Class Initialized
DEBUG - 2018-02-07 08:32:09 --> UTF-8 Support Enabled
INFO - 2018-02-07 08:32:09 --> Utf8 Class Initialized
INFO - 2018-02-07 08:32:09 --> URI Class Initialized
INFO - 2018-02-07 08:32:09 --> Router Class Initialized
INFO - 2018-02-07 08:32:09 --> Output Class Initialized
INFO - 2018-02-07 08:32:09 --> Security Class Initialized
DEBUG - 2018-02-07 08:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 08:32:09 --> Input Class Initialized
INFO - 2018-02-07 08:32:09 --> Language Class Initialized
INFO - 2018-02-07 08:32:09 --> Language Class Initialized
INFO - 2018-02-07 08:32:09 --> Config Class Initialized
INFO - 2018-02-07 08:32:09 --> Loader Class Initialized
INFO - 2018-02-07 14:02:09 --> Helper loaded: url_helper
INFO - 2018-02-07 14:02:09 --> Helper loaded: notification_helper
INFO - 2018-02-07 14:02:09 --> Helper loaded: settings_helper
INFO - 2018-02-07 14:02:09 --> Helper loaded: permission_helper
INFO - 2018-02-07 14:02:09 --> Helper loaded: users_helper
INFO - 2018-02-07 14:02:09 --> Database Driver Class Initialized
DEBUG - 2018-02-07 14:02:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 14:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 14:02:09 --> Helper loaded: form_helper
INFO - 2018-02-07 14:02:09 --> Form Validation Class Initialized
INFO - 2018-02-07 14:02:09 --> Controller Class Initialized
INFO - 2018-02-07 14:02:09 --> Model Class Initialized
INFO - 2018-02-07 14:02:09 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 14:02:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 14:02:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 14:02:09 --> Model Class Initialized
INFO - 2018-02-07 14:02:09 --> Model Class Initialized
INFO - 2018-02-07 14:02:09 --> Model Class Initialized
INFO - 2018-02-07 14:02:09 --> Model Class Initialized
INFO - 2018-02-07 14:02:09 --> Model Class Initialized
INFO - 2018-02-07 14:02:09 --> Model Class Initialized
INFO - 2018-02-07 14:02:09 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-02-07 14:02:09 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 771
ERROR - 2018-02-07 14:02:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 781
INFO - 2018-02-07 14:02:09 --> Final output sent to browser
DEBUG - 2018-02-07 14:02:09 --> Total execution time: 0.1217
INFO - 2018-02-07 08:42:45 --> Config Class Initialized
INFO - 2018-02-07 08:42:45 --> Hooks Class Initialized
DEBUG - 2018-02-07 08:42:45 --> UTF-8 Support Enabled
INFO - 2018-02-07 08:42:45 --> Utf8 Class Initialized
INFO - 2018-02-07 08:42:45 --> URI Class Initialized
INFO - 2018-02-07 08:42:45 --> Router Class Initialized
INFO - 2018-02-07 08:42:45 --> Output Class Initialized
INFO - 2018-02-07 08:42:45 --> Security Class Initialized
DEBUG - 2018-02-07 08:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 08:42:46 --> Input Class Initialized
INFO - 2018-02-07 08:42:46 --> Language Class Initialized
INFO - 2018-02-07 08:42:46 --> Language Class Initialized
INFO - 2018-02-07 08:42:46 --> Config Class Initialized
INFO - 2018-02-07 08:42:46 --> Loader Class Initialized
INFO - 2018-02-07 14:12:46 --> Helper loaded: url_helper
INFO - 2018-02-07 14:12:46 --> Helper loaded: notification_helper
INFO - 2018-02-07 14:12:46 --> Helper loaded: settings_helper
INFO - 2018-02-07 14:12:46 --> Helper loaded: permission_helper
INFO - 2018-02-07 14:12:46 --> Helper loaded: users_helper
INFO - 2018-02-07 14:12:46 --> Database Driver Class Initialized
DEBUG - 2018-02-07 14:12:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 14:12:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 14:12:46 --> Helper loaded: form_helper
INFO - 2018-02-07 14:12:46 --> Form Validation Class Initialized
INFO - 2018-02-07 14:12:46 --> Controller Class Initialized
INFO - 2018-02-07 14:12:46 --> Model Class Initialized
INFO - 2018-02-07 14:12:46 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 14:12:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 14:12:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 14:12:46 --> Model Class Initialized
INFO - 2018-02-07 14:12:46 --> Model Class Initialized
INFO - 2018-02-07 14:12:46 --> Model Class Initialized
INFO - 2018-02-07 14:12:46 --> Model Class Initialized
INFO - 2018-02-07 14:12:46 --> Model Class Initialized
INFO - 2018-02-07 14:12:46 --> Model Class Initialized
INFO - 2018-02-07 14:12:46 --> Model Class Initialized
INFO - 2018-02-07 14:12:46 --> Model Class Initialized
INFO - 2018-02-07 14:12:46 --> Model Class Initialized
INFO - 2018-02-07 14:12:46 --> Model Class Initialized
INFO - 2018-02-07 14:12:46 --> Model Class Initialized
INFO - 2018-02-07 14:12:46 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 14:12:46 --> Model Class Initialized
INFO - 2018-02-07 14:12:46 --> Final output sent to browser
DEBUG - 2018-02-07 14:12:46 --> Total execution time: 0.0973
INFO - 2018-02-07 08:42:46 --> Config Class Initialized
INFO - 2018-02-07 08:42:46 --> Hooks Class Initialized
DEBUG - 2018-02-07 08:42:46 --> UTF-8 Support Enabled
INFO - 2018-02-07 08:42:46 --> Utf8 Class Initialized
INFO - 2018-02-07 08:42:46 --> URI Class Initialized
INFO - 2018-02-07 08:42:46 --> Router Class Initialized
INFO - 2018-02-07 08:42:46 --> Output Class Initialized
INFO - 2018-02-07 08:42:46 --> Security Class Initialized
DEBUG - 2018-02-07 08:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 08:42:46 --> Input Class Initialized
INFO - 2018-02-07 08:42:46 --> Language Class Initialized
INFO - 2018-02-07 08:42:46 --> Language Class Initialized
INFO - 2018-02-07 08:42:46 --> Config Class Initialized
INFO - 2018-02-07 08:42:46 --> Loader Class Initialized
INFO - 2018-02-07 14:12:46 --> Helper loaded: url_helper
INFO - 2018-02-07 14:12:46 --> Helper loaded: notification_helper
INFO - 2018-02-07 14:12:46 --> Helper loaded: settings_helper
INFO - 2018-02-07 14:12:46 --> Helper loaded: permission_helper
INFO - 2018-02-07 14:12:46 --> Helper loaded: users_helper
INFO - 2018-02-07 14:12:46 --> Database Driver Class Initialized
DEBUG - 2018-02-07 14:12:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 14:12:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 14:12:46 --> Helper loaded: form_helper
INFO - 2018-02-07 14:12:46 --> Form Validation Class Initialized
INFO - 2018-02-07 14:12:46 --> Controller Class Initialized
INFO - 2018-02-07 14:12:46 --> Model Class Initialized
INFO - 2018-02-07 14:12:46 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 14:12:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 14:12:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 14:12:46 --> Model Class Initialized
INFO - 2018-02-07 14:12:46 --> Model Class Initialized
INFO - 2018-02-07 14:12:46 --> Model Class Initialized
INFO - 2018-02-07 14:12:46 --> Model Class Initialized
INFO - 2018-02-07 14:12:46 --> Model Class Initialized
INFO - 2018-02-07 14:12:46 --> Model Class Initialized
INFO - 2018-02-07 14:12:46 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 14:12:46 --> Model Class Initialized
INFO - 2018-02-07 14:12:46 --> Final output sent to browser
DEBUG - 2018-02-07 14:12:46 --> Total execution time: 0.1268
INFO - 2018-02-07 08:43:10 --> Config Class Initialized
INFO - 2018-02-07 08:43:10 --> Hooks Class Initialized
INFO - 2018-02-07 08:43:10 --> Config Class Initialized
INFO - 2018-02-07 08:43:10 --> Hooks Class Initialized
DEBUG - 2018-02-07 08:43:10 --> UTF-8 Support Enabled
INFO - 2018-02-07 08:43:10 --> Utf8 Class Initialized
INFO - 2018-02-07 08:43:10 --> URI Class Initialized
DEBUG - 2018-02-07 08:43:10 --> UTF-8 Support Enabled
INFO - 2018-02-07 08:43:10 --> Utf8 Class Initialized
INFO - 2018-02-07 08:43:10 --> URI Class Initialized
INFO - 2018-02-07 08:43:10 --> Router Class Initialized
INFO - 2018-02-07 08:43:10 --> Router Class Initialized
INFO - 2018-02-07 08:43:10 --> Output Class Initialized
INFO - 2018-02-07 08:43:10 --> Security Class Initialized
INFO - 2018-02-07 08:43:10 --> Output Class Initialized
DEBUG - 2018-02-07 08:43:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 08:43:10 --> Input Class Initialized
INFO - 2018-02-07 08:43:10 --> Security Class Initialized
INFO - 2018-02-07 08:43:10 --> Language Class Initialized
DEBUG - 2018-02-07 08:43:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 08:43:10 --> Input Class Initialized
INFO - 2018-02-07 08:43:10 --> Language Class Initialized
INFO - 2018-02-07 08:43:10 --> Language Class Initialized
INFO - 2018-02-07 08:43:10 --> Config Class Initialized
INFO - 2018-02-07 08:43:10 --> Loader Class Initialized
INFO - 2018-02-07 08:43:10 --> Language Class Initialized
INFO - 2018-02-07 08:43:10 --> Config Class Initialized
INFO - 2018-02-07 08:43:10 --> Loader Class Initialized
INFO - 2018-02-07 14:13:10 --> Helper loaded: url_helper
INFO - 2018-02-07 14:13:10 --> Helper loaded: notification_helper
INFO - 2018-02-07 14:13:10 --> Helper loaded: url_helper
INFO - 2018-02-07 14:13:10 --> Helper loaded: settings_helper
INFO - 2018-02-07 14:13:10 --> Helper loaded: permission_helper
INFO - 2018-02-07 14:13:10 --> Helper loaded: notification_helper
INFO - 2018-02-07 14:13:10 --> Helper loaded: users_helper
INFO - 2018-02-07 14:13:10 --> Helper loaded: settings_helper
INFO - 2018-02-07 14:13:10 --> Helper loaded: permission_helper
INFO - 2018-02-07 14:13:10 --> Helper loaded: users_helper
INFO - 2018-02-07 14:13:10 --> Database Driver Class Initialized
INFO - 2018-02-07 14:13:10 --> Database Driver Class Initialized
DEBUG - 2018-02-07 14:13:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 14:13:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-07 14:13:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 14:13:10 --> Helper loaded: form_helper
INFO - 2018-02-07 14:13:10 --> Form Validation Class Initialized
INFO - 2018-02-07 14:13:10 --> Controller Class Initialized
INFO - 2018-02-07 14:13:10 --> Model Class Initialized
INFO - 2018-02-07 14:13:10 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 14:13:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 14:13:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 14:13:10 --> Model Class Initialized
INFO - 2018-02-07 14:13:10 --> Model Class Initialized
INFO - 2018-02-07 14:13:10 --> Model Class Initialized
INFO - 2018-02-07 14:13:10 --> Model Class Initialized
INFO - 2018-02-07 14:13:10 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 14:13:10 --> Final output sent to browser
DEBUG - 2018-02-07 14:13:10 --> Total execution time: 0.1113
INFO - 2018-02-07 14:13:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 14:13:10 --> Helper loaded: form_helper
INFO - 2018-02-07 14:13:10 --> Form Validation Class Initialized
INFO - 2018-02-07 14:13:10 --> Controller Class Initialized
INFO - 2018-02-07 14:13:10 --> Model Class Initialized
INFO - 2018-02-07 14:13:10 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 14:13:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 14:13:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 14:13:11 --> Model Class Initialized
INFO - 2018-02-07 14:13:11 --> Model Class Initialized
INFO - 2018-02-07 14:13:11 --> Model Class Initialized
INFO - 2018-02-07 14:13:11 --> Model Class Initialized
INFO - 2018-02-07 14:13:11 --> Model Class Initialized
INFO - 2018-02-07 14:13:11 --> Model Class Initialized
INFO - 2018-02-07 14:13:11 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 14:13:11 --> Final output sent to browser
DEBUG - 2018-02-07 14:13:11 --> Total execution time: 0.1518
INFO - 2018-02-07 08:46:54 --> Config Class Initialized
INFO - 2018-02-07 08:46:54 --> Hooks Class Initialized
DEBUG - 2018-02-07 08:46:54 --> UTF-8 Support Enabled
INFO - 2018-02-07 08:46:54 --> Utf8 Class Initialized
INFO - 2018-02-07 08:46:54 --> URI Class Initialized
INFO - 2018-02-07 08:46:54 --> Router Class Initialized
INFO - 2018-02-07 08:46:54 --> Output Class Initialized
INFO - 2018-02-07 08:46:54 --> Security Class Initialized
DEBUG - 2018-02-07 08:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 08:46:54 --> Input Class Initialized
INFO - 2018-02-07 08:46:54 --> Language Class Initialized
INFO - 2018-02-07 08:46:54 --> Language Class Initialized
INFO - 2018-02-07 08:46:54 --> Config Class Initialized
INFO - 2018-02-07 08:46:54 --> Loader Class Initialized
INFO - 2018-02-07 14:16:54 --> Helper loaded: url_helper
INFO - 2018-02-07 14:16:54 --> Helper loaded: notification_helper
INFO - 2018-02-07 14:16:54 --> Helper loaded: settings_helper
INFO - 2018-02-07 14:16:54 --> Helper loaded: permission_helper
INFO - 2018-02-07 14:16:54 --> Helper loaded: users_helper
INFO - 2018-02-07 14:16:54 --> Database Driver Class Initialized
DEBUG - 2018-02-07 14:16:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 14:16:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 14:16:54 --> Helper loaded: form_helper
INFO - 2018-02-07 14:16:54 --> Form Validation Class Initialized
INFO - 2018-02-07 14:16:54 --> Controller Class Initialized
INFO - 2018-02-07 14:16:54 --> Model Class Initialized
INFO - 2018-02-07 14:16:54 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 14:16:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 14:16:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 14:16:54 --> Model Class Initialized
INFO - 2018-02-07 14:16:54 --> Model Class Initialized
INFO - 2018-02-07 14:16:54 --> Model Class Initialized
INFO - 2018-02-07 14:16:54 --> Model Class Initialized
INFO - 2018-02-07 14:16:54 --> Model Class Initialized
INFO - 2018-02-07 14:16:54 --> Model Class Initialized
INFO - 2018-02-07 14:16:54 --> Model Class Initialized
INFO - 2018-02-07 14:16:54 --> Model Class Initialized
INFO - 2018-02-07 14:16:54 --> Model Class Initialized
INFO - 2018-02-07 14:16:54 --> Model Class Initialized
INFO - 2018-02-07 14:16:54 --> Model Class Initialized
INFO - 2018-02-07 14:16:54 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 14:16:54 --> Model Class Initialized
INFO - 2018-02-07 14:16:54 --> Final output sent to browser
DEBUG - 2018-02-07 14:16:54 --> Total execution time: 0.1228
INFO - 2018-02-07 08:46:55 --> Config Class Initialized
INFO - 2018-02-07 08:46:55 --> Hooks Class Initialized
DEBUG - 2018-02-07 08:46:55 --> UTF-8 Support Enabled
INFO - 2018-02-07 08:46:55 --> Utf8 Class Initialized
INFO - 2018-02-07 08:46:55 --> URI Class Initialized
INFO - 2018-02-07 08:46:55 --> Router Class Initialized
INFO - 2018-02-07 08:46:55 --> Output Class Initialized
INFO - 2018-02-07 08:46:55 --> Security Class Initialized
DEBUG - 2018-02-07 08:46:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 08:46:55 --> Input Class Initialized
INFO - 2018-02-07 08:46:55 --> Language Class Initialized
INFO - 2018-02-07 08:46:55 --> Language Class Initialized
INFO - 2018-02-07 08:46:55 --> Config Class Initialized
INFO - 2018-02-07 08:46:55 --> Loader Class Initialized
INFO - 2018-02-07 14:16:55 --> Helper loaded: url_helper
INFO - 2018-02-07 14:16:55 --> Helper loaded: notification_helper
INFO - 2018-02-07 14:16:55 --> Helper loaded: settings_helper
INFO - 2018-02-07 14:16:55 --> Helper loaded: permission_helper
INFO - 2018-02-07 14:16:55 --> Helper loaded: users_helper
INFO - 2018-02-07 14:16:55 --> Database Driver Class Initialized
DEBUG - 2018-02-07 14:16:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 14:16:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 14:16:55 --> Helper loaded: form_helper
INFO - 2018-02-07 14:16:55 --> Form Validation Class Initialized
INFO - 2018-02-07 14:16:55 --> Controller Class Initialized
INFO - 2018-02-07 14:16:55 --> Model Class Initialized
INFO - 2018-02-07 14:16:55 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 14:16:55 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 14:16:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 14:16:55 --> Model Class Initialized
INFO - 2018-02-07 14:16:55 --> Model Class Initialized
INFO - 2018-02-07 14:16:55 --> Model Class Initialized
INFO - 2018-02-07 14:16:55 --> Model Class Initialized
INFO - 2018-02-07 14:16:55 --> Model Class Initialized
INFO - 2018-02-07 14:16:55 --> Model Class Initialized
INFO - 2018-02-07 14:16:55 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 14:16:55 --> Model Class Initialized
INFO - 2018-02-07 14:16:55 --> Final output sent to browser
DEBUG - 2018-02-07 14:16:55 --> Total execution time: 0.1219
INFO - 2018-02-07 08:47:10 --> Config Class Initialized
INFO - 2018-02-07 08:47:10 --> Hooks Class Initialized
DEBUG - 2018-02-07 08:47:10 --> UTF-8 Support Enabled
INFO - 2018-02-07 08:47:10 --> Utf8 Class Initialized
INFO - 2018-02-07 08:47:10 --> URI Class Initialized
INFO - 2018-02-07 08:47:10 --> Router Class Initialized
INFO - 2018-02-07 08:47:10 --> Output Class Initialized
INFO - 2018-02-07 08:47:10 --> Security Class Initialized
DEBUG - 2018-02-07 08:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 08:47:10 --> Input Class Initialized
INFO - 2018-02-07 08:47:10 --> Language Class Initialized
INFO - 2018-02-07 08:47:10 --> Language Class Initialized
INFO - 2018-02-07 08:47:10 --> Config Class Initialized
INFO - 2018-02-07 08:47:10 --> Loader Class Initialized
INFO - 2018-02-07 14:17:10 --> Helper loaded: url_helper
INFO - 2018-02-07 14:17:10 --> Helper loaded: notification_helper
INFO - 2018-02-07 14:17:10 --> Helper loaded: settings_helper
INFO - 2018-02-07 14:17:10 --> Helper loaded: permission_helper
INFO - 2018-02-07 14:17:10 --> Helper loaded: users_helper
INFO - 2018-02-07 14:17:10 --> Database Driver Class Initialized
DEBUG - 2018-02-07 14:17:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 14:17:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 14:17:10 --> Helper loaded: form_helper
INFO - 2018-02-07 14:17:10 --> Form Validation Class Initialized
INFO - 2018-02-07 14:17:10 --> Controller Class Initialized
INFO - 2018-02-07 14:17:10 --> Model Class Initialized
INFO - 2018-02-07 14:17:10 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 14:17:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 14:17:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 14:17:10 --> Model Class Initialized
INFO - 2018-02-07 14:17:10 --> Model Class Initialized
INFO - 2018-02-07 14:17:10 --> Model Class Initialized
INFO - 2018-02-07 14:17:10 --> Model Class Initialized
INFO - 2018-02-07 14:17:10 --> Model Class Initialized
INFO - 2018-02-07 14:17:10 --> Model Class Initialized
INFO - 2018-02-07 14:17:10 --> Model Class Initialized
INFO - 2018-02-07 14:17:10 --> Model Class Initialized
INFO - 2018-02-07 14:17:10 --> Model Class Initialized
INFO - 2018-02-07 14:17:10 --> Model Class Initialized
INFO - 2018-02-07 14:17:10 --> Model Class Initialized
INFO - 2018-02-07 14:17:10 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 14:17:10 --> Model Class Initialized
INFO - 2018-02-07 14:17:10 --> Final output sent to browser
DEBUG - 2018-02-07 14:17:10 --> Total execution time: 0.0965
INFO - 2018-02-07 08:47:17 --> Config Class Initialized
INFO - 2018-02-07 08:47:17 --> Hooks Class Initialized
DEBUG - 2018-02-07 08:47:17 --> UTF-8 Support Enabled
INFO - 2018-02-07 08:47:17 --> Utf8 Class Initialized
INFO - 2018-02-07 08:47:17 --> URI Class Initialized
INFO - 2018-02-07 08:47:17 --> Router Class Initialized
INFO - 2018-02-07 08:47:17 --> Output Class Initialized
INFO - 2018-02-07 08:47:17 --> Security Class Initialized
DEBUG - 2018-02-07 08:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 08:47:17 --> Input Class Initialized
INFO - 2018-02-07 08:47:17 --> Language Class Initialized
INFO - 2018-02-07 08:47:17 --> Language Class Initialized
INFO - 2018-02-07 08:47:17 --> Config Class Initialized
INFO - 2018-02-07 08:47:17 --> Loader Class Initialized
INFO - 2018-02-07 08:47:17 --> Config Class Initialized
INFO - 2018-02-07 08:47:17 --> Hooks Class Initialized
INFO - 2018-02-07 14:17:17 --> Helper loaded: url_helper
INFO - 2018-02-07 14:17:17 --> Helper loaded: notification_helper
INFO - 2018-02-07 14:17:17 --> Helper loaded: settings_helper
INFO - 2018-02-07 14:17:17 --> Helper loaded: permission_helper
DEBUG - 2018-02-07 08:47:17 --> UTF-8 Support Enabled
INFO - 2018-02-07 08:47:17 --> Utf8 Class Initialized
INFO - 2018-02-07 14:17:17 --> Helper loaded: users_helper
INFO - 2018-02-07 08:47:17 --> URI Class Initialized
INFO - 2018-02-07 08:47:17 --> Router Class Initialized
INFO - 2018-02-07 08:47:17 --> Output Class Initialized
INFO - 2018-02-07 08:47:17 --> Security Class Initialized
INFO - 2018-02-07 14:17:17 --> Database Driver Class Initialized
DEBUG - 2018-02-07 08:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 08:47:17 --> Input Class Initialized
INFO - 2018-02-07 08:47:17 --> Language Class Initialized
DEBUG - 2018-02-07 14:17:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 14:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 14:17:17 --> Helper loaded: form_helper
INFO - 2018-02-07 14:17:17 --> Form Validation Class Initialized
INFO - 2018-02-07 14:17:17 --> Controller Class Initialized
INFO - 2018-02-07 14:17:17 --> Model Class Initialized
INFO - 2018-02-07 08:47:17 --> Language Class Initialized
INFO - 2018-02-07 08:47:17 --> Config Class Initialized
INFO - 2018-02-07 08:47:17 --> Loader Class Initialized
INFO - 2018-02-07 14:17:17 --> Helper loaded: inflector_helper
INFO - 2018-02-07 14:17:17 --> Helper loaded: url_helper
INFO - 2018-02-07 14:17:17 --> Helper loaded: notification_helper
DEBUG - 2018-02-07 14:17:17 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 14:17:17 --> Helper loaded: settings_helper
INFO - 2018-02-07 14:17:17 --> Helper loaded: permission_helper
INFO - 2018-02-07 14:17:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 14:17:17 --> Helper loaded: users_helper
INFO - 2018-02-07 14:17:17 --> Model Class Initialized
INFO - 2018-02-07 14:17:17 --> Model Class Initialized
INFO - 2018-02-07 14:17:17 --> Model Class Initialized
INFO - 2018-02-07 14:17:17 --> Model Class Initialized
INFO - 2018-02-07 14:17:17 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 14:17:17 --> Final output sent to browser
DEBUG - 2018-02-07 14:17:17 --> Total execution time: 0.1020
INFO - 2018-02-07 14:17:17 --> Database Driver Class Initialized
DEBUG - 2018-02-07 14:17:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 14:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 14:17:17 --> Helper loaded: form_helper
INFO - 2018-02-07 14:17:17 --> Form Validation Class Initialized
INFO - 2018-02-07 14:17:17 --> Controller Class Initialized
INFO - 2018-02-07 14:17:17 --> Model Class Initialized
INFO - 2018-02-07 14:17:17 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 14:17:17 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 14:17:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 14:17:17 --> Model Class Initialized
INFO - 2018-02-07 14:17:17 --> Model Class Initialized
INFO - 2018-02-07 14:17:17 --> Model Class Initialized
INFO - 2018-02-07 14:17:17 --> Model Class Initialized
INFO - 2018-02-07 14:17:17 --> Model Class Initialized
INFO - 2018-02-07 14:17:17 --> Model Class Initialized
INFO - 2018-02-07 14:17:17 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 14:17:17 --> Final output sent to browser
DEBUG - 2018-02-07 14:17:17 --> Total execution time: 0.1174
INFO - 2018-02-07 08:48:00 --> Config Class Initialized
INFO - 2018-02-07 08:48:00 --> Hooks Class Initialized
DEBUG - 2018-02-07 08:48:00 --> UTF-8 Support Enabled
INFO - 2018-02-07 08:48:00 --> Utf8 Class Initialized
INFO - 2018-02-07 08:48:00 --> URI Class Initialized
INFO - 2018-02-07 08:48:00 --> Router Class Initialized
INFO - 2018-02-07 08:48:00 --> Output Class Initialized
INFO - 2018-02-07 08:48:00 --> Security Class Initialized
DEBUG - 2018-02-07 08:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 08:48:00 --> Input Class Initialized
INFO - 2018-02-07 08:48:00 --> Language Class Initialized
INFO - 2018-02-07 08:48:00 --> Language Class Initialized
INFO - 2018-02-07 08:48:00 --> Config Class Initialized
INFO - 2018-02-07 08:48:00 --> Loader Class Initialized
INFO - 2018-02-07 14:18:00 --> Helper loaded: url_helper
INFO - 2018-02-07 14:18:00 --> Helper loaded: notification_helper
INFO - 2018-02-07 14:18:00 --> Helper loaded: settings_helper
INFO - 2018-02-07 14:18:00 --> Helper loaded: permission_helper
INFO - 2018-02-07 14:18:00 --> Helper loaded: users_helper
INFO - 2018-02-07 14:18:00 --> Database Driver Class Initialized
DEBUG - 2018-02-07 14:18:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 14:18:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 14:18:00 --> Helper loaded: form_helper
INFO - 2018-02-07 14:18:00 --> Form Validation Class Initialized
INFO - 2018-02-07 14:18:00 --> Controller Class Initialized
INFO - 2018-02-07 14:18:00 --> Model Class Initialized
INFO - 2018-02-07 14:18:00 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 14:18:00 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 14:18:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 14:18:00 --> Model Class Initialized
INFO - 2018-02-07 14:18:00 --> Model Class Initialized
INFO - 2018-02-07 14:18:00 --> Model Class Initialized
INFO - 2018-02-07 14:18:00 --> Model Class Initialized
INFO - 2018-02-07 14:18:00 --> Model Class Initialized
INFO - 2018-02-07 14:18:00 --> Model Class Initialized
INFO - 2018-02-07 14:18:00 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 14:18:00 --> Final output sent to browser
DEBUG - 2018-02-07 14:18:00 --> Total execution time: 0.0835
INFO - 2018-02-07 09:02:00 --> Config Class Initialized
INFO - 2018-02-07 09:02:00 --> Hooks Class Initialized
DEBUG - 2018-02-07 09:02:00 --> UTF-8 Support Enabled
INFO - 2018-02-07 09:02:00 --> Utf8 Class Initialized
INFO - 2018-02-07 09:02:00 --> URI Class Initialized
INFO - 2018-02-07 09:02:00 --> Router Class Initialized
INFO - 2018-02-07 09:02:00 --> Output Class Initialized
INFO - 2018-02-07 09:02:00 --> Security Class Initialized
DEBUG - 2018-02-07 09:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 09:02:00 --> Input Class Initialized
INFO - 2018-02-07 09:02:00 --> Language Class Initialized
INFO - 2018-02-07 09:02:00 --> Language Class Initialized
INFO - 2018-02-07 09:02:00 --> Config Class Initialized
INFO - 2018-02-07 09:02:00 --> Loader Class Initialized
INFO - 2018-02-07 14:32:00 --> Helper loaded: url_helper
INFO - 2018-02-07 14:32:00 --> Helper loaded: notification_helper
INFO - 2018-02-07 14:32:00 --> Helper loaded: settings_helper
INFO - 2018-02-07 14:32:00 --> Helper loaded: permission_helper
INFO - 2018-02-07 14:32:00 --> Helper loaded: users_helper
INFO - 2018-02-07 14:32:00 --> Database Driver Class Initialized
DEBUG - 2018-02-07 14:32:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 14:32:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 14:32:00 --> Helper loaded: form_helper
INFO - 2018-02-07 14:32:00 --> Form Validation Class Initialized
INFO - 2018-02-07 14:32:00 --> Controller Class Initialized
INFO - 2018-02-07 14:32:00 --> Model Class Initialized
INFO - 2018-02-07 14:32:00 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 14:32:00 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 14:32:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 14:32:00 --> Model Class Initialized
INFO - 2018-02-07 14:32:00 --> Model Class Initialized
INFO - 2018-02-07 14:32:00 --> Model Class Initialized
INFO - 2018-02-07 14:32:00 --> Model Class Initialized
INFO - 2018-02-07 14:32:00 --> Model Class Initialized
INFO - 2018-02-07 14:32:00 --> Model Class Initialized
INFO - 2018-02-07 14:32:00 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 14:32:00 --> Model Class Initialized
INFO - 2018-02-07 14:32:00 --> Final output sent to browser
DEBUG - 2018-02-07 14:32:00 --> Total execution time: 0.1108
INFO - 2018-02-07 09:02:01 --> Config Class Initialized
INFO - 2018-02-07 09:02:01 --> Hooks Class Initialized
DEBUG - 2018-02-07 09:02:01 --> UTF-8 Support Enabled
INFO - 2018-02-07 09:02:01 --> Utf8 Class Initialized
INFO - 2018-02-07 09:02:01 --> URI Class Initialized
INFO - 2018-02-07 09:02:01 --> Router Class Initialized
INFO - 2018-02-07 09:02:01 --> Output Class Initialized
INFO - 2018-02-07 09:02:01 --> Security Class Initialized
DEBUG - 2018-02-07 09:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 09:02:01 --> Input Class Initialized
INFO - 2018-02-07 09:02:01 --> Language Class Initialized
INFO - 2018-02-07 09:02:01 --> Language Class Initialized
INFO - 2018-02-07 09:02:01 --> Config Class Initialized
INFO - 2018-02-07 09:02:01 --> Loader Class Initialized
INFO - 2018-02-07 14:32:01 --> Helper loaded: url_helper
INFO - 2018-02-07 14:32:01 --> Helper loaded: notification_helper
INFO - 2018-02-07 14:32:01 --> Helper loaded: settings_helper
INFO - 2018-02-07 14:32:01 --> Helper loaded: permission_helper
INFO - 2018-02-07 14:32:01 --> Helper loaded: users_helper
INFO - 2018-02-07 14:32:01 --> Database Driver Class Initialized
DEBUG - 2018-02-07 14:32:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 14:32:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 14:32:01 --> Helper loaded: form_helper
INFO - 2018-02-07 14:32:01 --> Form Validation Class Initialized
INFO - 2018-02-07 14:32:01 --> Controller Class Initialized
DEBUG - 2018-02-07 14:32:01 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-02-07 14:32:01 --> Final output sent to browser
DEBUG - 2018-02-07 14:32:01 --> Total execution time: 0.2839
INFO - 2018-02-07 09:25:46 --> Config Class Initialized
INFO - 2018-02-07 09:25:46 --> Hooks Class Initialized
DEBUG - 2018-02-07 09:25:46 --> UTF-8 Support Enabled
INFO - 2018-02-07 09:25:46 --> Utf8 Class Initialized
INFO - 2018-02-07 09:25:46 --> URI Class Initialized
INFO - 2018-02-07 09:25:46 --> Router Class Initialized
INFO - 2018-02-07 09:25:46 --> Output Class Initialized
INFO - 2018-02-07 09:25:46 --> Security Class Initialized
DEBUG - 2018-02-07 09:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 09:25:46 --> Input Class Initialized
INFO - 2018-02-07 09:25:46 --> Language Class Initialized
INFO - 2018-02-07 09:25:46 --> Language Class Initialized
INFO - 2018-02-07 09:25:46 --> Config Class Initialized
INFO - 2018-02-07 09:25:46 --> Loader Class Initialized
INFO - 2018-02-07 14:55:46 --> Helper loaded: url_helper
INFO - 2018-02-07 14:55:46 --> Helper loaded: notification_helper
INFO - 2018-02-07 14:55:46 --> Helper loaded: settings_helper
INFO - 2018-02-07 14:55:46 --> Helper loaded: permission_helper
INFO - 2018-02-07 14:55:46 --> Helper loaded: users_helper
INFO - 2018-02-07 14:55:46 --> Database Driver Class Initialized
DEBUG - 2018-02-07 14:55:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 14:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 14:55:46 --> Helper loaded: form_helper
INFO - 2018-02-07 14:55:46 --> Form Validation Class Initialized
INFO - 2018-02-07 14:55:46 --> Controller Class Initialized
INFO - 2018-02-07 14:55:46 --> Model Class Initialized
INFO - 2018-02-07 14:55:46 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 14:55:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 14:55:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 14:55:46 --> Model Class Initialized
INFO - 2018-02-07 14:55:46 --> Model Class Initialized
INFO - 2018-02-07 14:55:46 --> Model Class Initialized
INFO - 2018-02-07 14:55:46 --> Model Class Initialized
INFO - 2018-02-07 14:55:46 --> Model Class Initialized
INFO - 2018-02-07 14:55:46 --> Model Class Initialized
INFO - 2018-02-07 14:55:46 --> Model Class Initialized
INFO - 2018-02-07 14:55:46 --> Model Class Initialized
INFO - 2018-02-07 14:55:46 --> Model Class Initialized
INFO - 2018-02-07 14:55:46 --> Model Class Initialized
INFO - 2018-02-07 14:55:46 --> Model Class Initialized
INFO - 2018-02-07 14:55:46 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 14:55:46 --> Model Class Initialized
INFO - 2018-02-07 14:55:46 --> Final output sent to browser
DEBUG - 2018-02-07 14:55:46 --> Total execution time: 0.1397
INFO - 2018-02-07 09:25:47 --> Config Class Initialized
INFO - 2018-02-07 09:25:47 --> Hooks Class Initialized
DEBUG - 2018-02-07 09:25:47 --> UTF-8 Support Enabled
INFO - 2018-02-07 09:25:47 --> Utf8 Class Initialized
INFO - 2018-02-07 09:25:47 --> URI Class Initialized
INFO - 2018-02-07 09:25:47 --> Router Class Initialized
INFO - 2018-02-07 09:25:47 --> Output Class Initialized
INFO - 2018-02-07 09:25:47 --> Security Class Initialized
DEBUG - 2018-02-07 09:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 09:25:47 --> Input Class Initialized
INFO - 2018-02-07 09:25:47 --> Language Class Initialized
INFO - 2018-02-07 09:25:47 --> Language Class Initialized
INFO - 2018-02-07 09:25:47 --> Config Class Initialized
INFO - 2018-02-07 09:25:47 --> Loader Class Initialized
INFO - 2018-02-07 14:55:47 --> Helper loaded: url_helper
INFO - 2018-02-07 14:55:47 --> Helper loaded: notification_helper
INFO - 2018-02-07 14:55:47 --> Helper loaded: settings_helper
INFO - 2018-02-07 14:55:47 --> Helper loaded: permission_helper
INFO - 2018-02-07 14:55:47 --> Helper loaded: users_helper
INFO - 2018-02-07 14:55:48 --> Database Driver Class Initialized
DEBUG - 2018-02-07 14:55:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 14:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 14:55:48 --> Helper loaded: form_helper
INFO - 2018-02-07 14:55:48 --> Form Validation Class Initialized
INFO - 2018-02-07 14:55:48 --> Controller Class Initialized
INFO - 2018-02-07 14:55:48 --> Model Class Initialized
INFO - 2018-02-07 14:55:48 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 14:55:48 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 14:55:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 14:55:48 --> Model Class Initialized
INFO - 2018-02-07 14:55:48 --> Model Class Initialized
INFO - 2018-02-07 14:55:48 --> Model Class Initialized
INFO - 2018-02-07 14:55:48 --> Model Class Initialized
INFO - 2018-02-07 14:55:48 --> Model Class Initialized
INFO - 2018-02-07 14:55:48 --> Model Class Initialized
INFO - 2018-02-07 14:55:48 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 14:55:48 --> Model Class Initialized
INFO - 2018-02-07 14:55:48 --> Final output sent to browser
DEBUG - 2018-02-07 14:55:48 --> Total execution time: 0.1096
INFO - 2018-02-07 09:34:23 --> Config Class Initialized
INFO - 2018-02-07 09:34:23 --> Hooks Class Initialized
DEBUG - 2018-02-07 09:34:23 --> UTF-8 Support Enabled
INFO - 2018-02-07 09:34:23 --> Utf8 Class Initialized
INFO - 2018-02-07 09:34:23 --> URI Class Initialized
INFO - 2018-02-07 09:34:23 --> Router Class Initialized
INFO - 2018-02-07 09:34:23 --> Output Class Initialized
INFO - 2018-02-07 09:34:23 --> Security Class Initialized
DEBUG - 2018-02-07 09:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 09:34:23 --> Input Class Initialized
INFO - 2018-02-07 09:34:23 --> Language Class Initialized
INFO - 2018-02-07 09:34:23 --> Language Class Initialized
INFO - 2018-02-07 09:34:23 --> Config Class Initialized
INFO - 2018-02-07 09:34:23 --> Loader Class Initialized
INFO - 2018-02-07 15:04:23 --> Helper loaded: url_helper
INFO - 2018-02-07 15:04:23 --> Helper loaded: notification_helper
INFO - 2018-02-07 15:04:23 --> Helper loaded: settings_helper
INFO - 2018-02-07 15:04:23 --> Helper loaded: permission_helper
INFO - 2018-02-07 15:04:23 --> Helper loaded: users_helper
INFO - 2018-02-07 15:04:23 --> Database Driver Class Initialized
DEBUG - 2018-02-07 15:04:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:04:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:04:23 --> Helper loaded: form_helper
INFO - 2018-02-07 15:04:23 --> Form Validation Class Initialized
INFO - 2018-02-07 15:04:23 --> Controller Class Initialized
INFO - 2018-02-07 15:04:23 --> Model Class Initialized
INFO - 2018-02-07 15:04:23 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 15:04:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 15:04:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:04:23 --> Model Class Initialized
INFO - 2018-02-07 15:04:23 --> Model Class Initialized
INFO - 2018-02-07 15:04:23 --> Model Class Initialized
INFO - 2018-02-07 15:04:23 --> Model Class Initialized
INFO - 2018-02-07 15:04:23 --> Model Class Initialized
INFO - 2018-02-07 15:04:23 --> Model Class Initialized
INFO - 2018-02-07 15:04:23 --> Model Class Initialized
INFO - 2018-02-07 15:04:23 --> Model Class Initialized
INFO - 2018-02-07 15:04:23 --> Model Class Initialized
INFO - 2018-02-07 15:04:23 --> Model Class Initialized
INFO - 2018-02-07 15:04:23 --> Model Class Initialized
INFO - 2018-02-07 15:04:23 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 15:04:23 --> Model Class Initialized
INFO - 2018-02-07 15:04:23 --> Final output sent to browser
DEBUG - 2018-02-07 15:04:23 --> Total execution time: 0.2041
INFO - 2018-02-07 09:34:23 --> Config Class Initialized
INFO - 2018-02-07 09:34:23 --> Hooks Class Initialized
DEBUG - 2018-02-07 09:34:23 --> UTF-8 Support Enabled
INFO - 2018-02-07 09:34:23 --> Utf8 Class Initialized
INFO - 2018-02-07 09:34:23 --> URI Class Initialized
INFO - 2018-02-07 09:34:23 --> Router Class Initialized
INFO - 2018-02-07 09:34:23 --> Output Class Initialized
INFO - 2018-02-07 09:34:23 --> Security Class Initialized
DEBUG - 2018-02-07 09:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 09:34:23 --> Input Class Initialized
INFO - 2018-02-07 09:34:23 --> Language Class Initialized
INFO - 2018-02-07 09:34:23 --> Language Class Initialized
INFO - 2018-02-07 09:34:23 --> Config Class Initialized
INFO - 2018-02-07 09:34:23 --> Loader Class Initialized
INFO - 2018-02-07 15:04:23 --> Helper loaded: url_helper
INFO - 2018-02-07 15:04:23 --> Helper loaded: notification_helper
INFO - 2018-02-07 15:04:23 --> Helper loaded: settings_helper
INFO - 2018-02-07 15:04:23 --> Helper loaded: permission_helper
INFO - 2018-02-07 15:04:23 --> Helper loaded: users_helper
INFO - 2018-02-07 15:04:23 --> Database Driver Class Initialized
DEBUG - 2018-02-07 15:04:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:04:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:04:23 --> Helper loaded: form_helper
INFO - 2018-02-07 15:04:23 --> Form Validation Class Initialized
INFO - 2018-02-07 15:04:23 --> Controller Class Initialized
INFO - 2018-02-07 15:04:23 --> Model Class Initialized
INFO - 2018-02-07 15:04:23 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 15:04:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 15:04:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:04:23 --> Model Class Initialized
INFO - 2018-02-07 15:04:23 --> Model Class Initialized
INFO - 2018-02-07 15:04:23 --> Model Class Initialized
INFO - 2018-02-07 15:04:23 --> Model Class Initialized
INFO - 2018-02-07 15:04:23 --> Model Class Initialized
INFO - 2018-02-07 15:04:23 --> Model Class Initialized
INFO - 2018-02-07 15:04:23 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 15:04:23 --> Model Class Initialized
INFO - 2018-02-07 15:04:23 --> Final output sent to browser
DEBUG - 2018-02-07 15:04:23 --> Total execution time: 0.0815
INFO - 2018-02-07 09:34:43 --> Config Class Initialized
INFO - 2018-02-07 09:34:43 --> Hooks Class Initialized
DEBUG - 2018-02-07 09:34:43 --> UTF-8 Support Enabled
INFO - 2018-02-07 09:34:43 --> Utf8 Class Initialized
INFO - 2018-02-07 09:34:43 --> URI Class Initialized
INFO - 2018-02-07 09:34:43 --> Router Class Initialized
INFO - 2018-02-07 09:34:43 --> Output Class Initialized
INFO - 2018-02-07 09:34:43 --> Security Class Initialized
DEBUG - 2018-02-07 09:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 09:34:43 --> Input Class Initialized
INFO - 2018-02-07 09:34:43 --> Language Class Initialized
INFO - 2018-02-07 09:34:43 --> Config Class Initialized
INFO - 2018-02-07 09:34:43 --> Hooks Class Initialized
DEBUG - 2018-02-07 09:34:43 --> UTF-8 Support Enabled
INFO - 2018-02-07 09:34:43 --> Utf8 Class Initialized
INFO - 2018-02-07 09:34:43 --> URI Class Initialized
INFO - 2018-02-07 09:34:43 --> Router Class Initialized
INFO - 2018-02-07 09:34:43 --> Output Class Initialized
INFO - 2018-02-07 09:34:43 --> Security Class Initialized
INFO - 2018-02-07 09:34:43 --> Language Class Initialized
INFO - 2018-02-07 09:34:43 --> Config Class Initialized
INFO - 2018-02-07 09:34:43 --> Loader Class Initialized
DEBUG - 2018-02-07 09:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 09:34:43 --> Input Class Initialized
INFO - 2018-02-07 09:34:43 --> Language Class Initialized
INFO - 2018-02-07 15:04:43 --> Helper loaded: url_helper
INFO - 2018-02-07 15:04:43 --> Helper loaded: notification_helper
INFO - 2018-02-07 15:04:43 --> Helper loaded: settings_helper
INFO - 2018-02-07 15:04:43 --> Helper loaded: permission_helper
INFO - 2018-02-07 15:04:43 --> Helper loaded: users_helper
INFO - 2018-02-07 15:04:43 --> Database Driver Class Initialized
INFO - 2018-02-07 09:34:43 --> Language Class Initialized
INFO - 2018-02-07 09:34:43 --> Config Class Initialized
INFO - 2018-02-07 09:34:43 --> Loader Class Initialized
INFO - 2018-02-07 15:04:43 --> Helper loaded: url_helper
DEBUG - 2018-02-07 15:04:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:04:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:04:43 --> Helper loaded: notification_helper
INFO - 2018-02-07 15:04:43 --> Helper loaded: settings_helper
INFO - 2018-02-07 15:04:43 --> Helper loaded: permission_helper
INFO - 2018-02-07 15:04:43 --> Helper loaded: users_helper
INFO - 2018-02-07 15:04:43 --> Helper loaded: form_helper
INFO - 2018-02-07 15:04:43 --> Form Validation Class Initialized
INFO - 2018-02-07 15:04:43 --> Controller Class Initialized
INFO - 2018-02-07 15:04:43 --> Database Driver Class Initialized
INFO - 2018-02-07 15:04:43 --> Model Class Initialized
INFO - 2018-02-07 15:04:43 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 15:04:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-07 15:04:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 15:04:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:04:43 --> Model Class Initialized
INFO - 2018-02-07 15:04:43 --> Model Class Initialized
INFO - 2018-02-07 15:04:43 --> Model Class Initialized
INFO - 2018-02-07 15:04:43 --> Model Class Initialized
INFO - 2018-02-07 15:04:43 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 15:04:43 --> Final output sent to browser
DEBUG - 2018-02-07 15:04:43 --> Total execution time: 0.1145
INFO - 2018-02-07 15:04:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:04:43 --> Helper loaded: form_helper
INFO - 2018-02-07 15:04:43 --> Form Validation Class Initialized
INFO - 2018-02-07 15:04:43 --> Controller Class Initialized
INFO - 2018-02-07 15:04:43 --> Model Class Initialized
INFO - 2018-02-07 15:04:43 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 15:04:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 15:04:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:04:43 --> Model Class Initialized
INFO - 2018-02-07 15:04:43 --> Model Class Initialized
INFO - 2018-02-07 15:04:43 --> Model Class Initialized
INFO - 2018-02-07 15:04:43 --> Model Class Initialized
INFO - 2018-02-07 15:04:43 --> Model Class Initialized
INFO - 2018-02-07 15:04:43 --> Model Class Initialized
INFO - 2018-02-07 15:04:43 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 15:04:43 --> Final output sent to browser
DEBUG - 2018-02-07 15:04:43 --> Total execution time: 0.1277
INFO - 2018-02-07 09:34:49 --> Config Class Initialized
INFO - 2018-02-07 09:34:49 --> Hooks Class Initialized
DEBUG - 2018-02-07 09:34:49 --> UTF-8 Support Enabled
INFO - 2018-02-07 09:34:49 --> Utf8 Class Initialized
INFO - 2018-02-07 09:34:49 --> URI Class Initialized
INFO - 2018-02-07 09:34:49 --> Router Class Initialized
INFO - 2018-02-07 09:34:49 --> Output Class Initialized
INFO - 2018-02-07 09:34:49 --> Security Class Initialized
DEBUG - 2018-02-07 09:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 09:34:49 --> Input Class Initialized
INFO - 2018-02-07 09:34:49 --> Language Class Initialized
INFO - 2018-02-07 09:34:49 --> Language Class Initialized
INFO - 2018-02-07 09:34:49 --> Config Class Initialized
INFO - 2018-02-07 09:34:49 --> Loader Class Initialized
INFO - 2018-02-07 15:04:49 --> Helper loaded: url_helper
INFO - 2018-02-07 15:04:49 --> Helper loaded: notification_helper
INFO - 2018-02-07 15:04:49 --> Helper loaded: settings_helper
INFO - 2018-02-07 15:04:49 --> Helper loaded: permission_helper
INFO - 2018-02-07 15:04:49 --> Helper loaded: users_helper
INFO - 2018-02-07 15:04:49 --> Database Driver Class Initialized
DEBUG - 2018-02-07 15:04:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:04:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:04:49 --> Helper loaded: form_helper
INFO - 2018-02-07 15:04:49 --> Form Validation Class Initialized
INFO - 2018-02-07 15:04:49 --> Controller Class Initialized
INFO - 2018-02-07 15:04:49 --> Model Class Initialized
INFO - 2018-02-07 15:04:49 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 15:04:49 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 15:04:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:04:49 --> Model Class Initialized
INFO - 2018-02-07 15:04:49 --> Model Class Initialized
INFO - 2018-02-07 15:04:49 --> Model Class Initialized
INFO - 2018-02-07 15:04:49 --> Model Class Initialized
INFO - 2018-02-07 15:04:49 --> Model Class Initialized
INFO - 2018-02-07 15:04:49 --> Model Class Initialized
INFO - 2018-02-07 15:04:49 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 15:04:49 --> Model Class Initialized
INFO - 2018-02-07 15:04:49 --> Final output sent to browser
DEBUG - 2018-02-07 15:04:49 --> Total execution time: 0.1142
INFO - 2018-02-07 09:42:01 --> Config Class Initialized
INFO - 2018-02-07 09:42:01 --> Hooks Class Initialized
DEBUG - 2018-02-07 09:42:01 --> UTF-8 Support Enabled
INFO - 2018-02-07 09:42:01 --> Utf8 Class Initialized
INFO - 2018-02-07 09:42:01 --> URI Class Initialized
INFO - 2018-02-07 09:42:01 --> Router Class Initialized
INFO - 2018-02-07 09:42:01 --> Output Class Initialized
INFO - 2018-02-07 09:42:02 --> Security Class Initialized
DEBUG - 2018-02-07 09:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 09:42:02 --> Input Class Initialized
INFO - 2018-02-07 09:42:02 --> Language Class Initialized
INFO - 2018-02-07 09:42:02 --> Language Class Initialized
INFO - 2018-02-07 09:42:02 --> Config Class Initialized
INFO - 2018-02-07 09:42:02 --> Loader Class Initialized
INFO - 2018-02-07 15:12:02 --> Helper loaded: url_helper
INFO - 2018-02-07 15:12:02 --> Helper loaded: notification_helper
INFO - 2018-02-07 15:12:02 --> Helper loaded: settings_helper
INFO - 2018-02-07 15:12:02 --> Helper loaded: permission_helper
INFO - 2018-02-07 15:12:02 --> Helper loaded: users_helper
INFO - 2018-02-07 15:12:02 --> Database Driver Class Initialized
DEBUG - 2018-02-07 15:12:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:12:02 --> Helper loaded: form_helper
INFO - 2018-02-07 15:12:02 --> Form Validation Class Initialized
INFO - 2018-02-07 15:12:02 --> Controller Class Initialized
INFO - 2018-02-07 15:12:02 --> Model Class Initialized
INFO - 2018-02-07 15:12:02 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 15:12:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 15:12:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:12:02 --> Model Class Initialized
INFO - 2018-02-07 15:12:02 --> Model Class Initialized
INFO - 2018-02-07 15:12:02 --> Model Class Initialized
INFO - 2018-02-07 15:12:02 --> Model Class Initialized
INFO - 2018-02-07 15:12:02 --> Model Class Initialized
INFO - 2018-02-07 15:12:02 --> Model Class Initialized
INFO - 2018-02-07 15:12:02 --> Model Class Initialized
INFO - 2018-02-07 15:12:02 --> Model Class Initialized
INFO - 2018-02-07 15:12:02 --> Model Class Initialized
INFO - 2018-02-07 15:12:02 --> Model Class Initialized
INFO - 2018-02-07 15:12:02 --> Model Class Initialized
INFO - 2018-02-07 15:12:02 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 15:12:02 --> Model Class Initialized
INFO - 2018-02-07 15:12:02 --> Final output sent to browser
DEBUG - 2018-02-07 15:12:02 --> Total execution time: 0.1325
INFO - 2018-02-07 09:42:02 --> Config Class Initialized
INFO - 2018-02-07 09:42:02 --> Hooks Class Initialized
DEBUG - 2018-02-07 09:42:02 --> UTF-8 Support Enabled
INFO - 2018-02-07 09:42:02 --> Utf8 Class Initialized
INFO - 2018-02-07 09:42:02 --> URI Class Initialized
INFO - 2018-02-07 09:42:02 --> Router Class Initialized
INFO - 2018-02-07 09:42:02 --> Output Class Initialized
INFO - 2018-02-07 09:42:02 --> Security Class Initialized
DEBUG - 2018-02-07 09:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 09:42:02 --> Input Class Initialized
INFO - 2018-02-07 09:42:02 --> Language Class Initialized
INFO - 2018-02-07 09:42:02 --> Language Class Initialized
INFO - 2018-02-07 09:42:02 --> Config Class Initialized
INFO - 2018-02-07 09:42:02 --> Loader Class Initialized
INFO - 2018-02-07 15:12:02 --> Helper loaded: url_helper
INFO - 2018-02-07 15:12:02 --> Helper loaded: notification_helper
INFO - 2018-02-07 15:12:02 --> Helper loaded: settings_helper
INFO - 2018-02-07 15:12:02 --> Helper loaded: permission_helper
INFO - 2018-02-07 15:12:02 --> Helper loaded: users_helper
INFO - 2018-02-07 15:12:02 --> Database Driver Class Initialized
DEBUG - 2018-02-07 15:12:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:12:02 --> Helper loaded: form_helper
INFO - 2018-02-07 15:12:02 --> Form Validation Class Initialized
INFO - 2018-02-07 15:12:02 --> Controller Class Initialized
INFO - 2018-02-07 15:12:02 --> Model Class Initialized
INFO - 2018-02-07 15:12:02 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 15:12:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 15:12:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:12:02 --> Model Class Initialized
INFO - 2018-02-07 15:12:02 --> Model Class Initialized
INFO - 2018-02-07 15:12:02 --> Model Class Initialized
INFO - 2018-02-07 15:12:02 --> Model Class Initialized
INFO - 2018-02-07 15:12:02 --> Model Class Initialized
INFO - 2018-02-07 15:12:02 --> Model Class Initialized
INFO - 2018-02-07 15:12:02 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 15:12:02 --> Model Class Initialized
INFO - 2018-02-07 15:12:02 --> Final output sent to browser
DEBUG - 2018-02-07 15:12:02 --> Total execution time: 0.1153
INFO - 2018-02-07 09:42:24 --> Config Class Initialized
INFO - 2018-02-07 09:42:24 --> Hooks Class Initialized
DEBUG - 2018-02-07 09:42:24 --> UTF-8 Support Enabled
INFO - 2018-02-07 09:42:24 --> Utf8 Class Initialized
INFO - 2018-02-07 09:42:24 --> URI Class Initialized
INFO - 2018-02-07 09:42:24 --> Router Class Initialized
INFO - 2018-02-07 09:42:24 --> Output Class Initialized
INFO - 2018-02-07 09:42:24 --> Security Class Initialized
DEBUG - 2018-02-07 09:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 09:42:24 --> Input Class Initialized
INFO - 2018-02-07 09:42:24 --> Language Class Initialized
INFO - 2018-02-07 09:42:24 --> Language Class Initialized
INFO - 2018-02-07 09:42:24 --> Config Class Initialized
INFO - 2018-02-07 09:42:24 --> Loader Class Initialized
INFO - 2018-02-07 15:12:24 --> Helper loaded: url_helper
INFO - 2018-02-07 15:12:24 --> Helper loaded: notification_helper
INFO - 2018-02-07 15:12:24 --> Helper loaded: settings_helper
INFO - 2018-02-07 15:12:24 --> Helper loaded: permission_helper
INFO - 2018-02-07 15:12:24 --> Helper loaded: users_helper
INFO - 2018-02-07 15:12:24 --> Database Driver Class Initialized
DEBUG - 2018-02-07 15:12:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:12:24 --> Helper loaded: form_helper
INFO - 2018-02-07 15:12:24 --> Form Validation Class Initialized
INFO - 2018-02-07 15:12:24 --> Controller Class Initialized
INFO - 2018-02-07 15:12:24 --> Model Class Initialized
INFO - 2018-02-07 15:12:24 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 15:12:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 15:12:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:12:24 --> Model Class Initialized
INFO - 2018-02-07 15:12:24 --> Model Class Initialized
INFO - 2018-02-07 15:12:24 --> Model Class Initialized
INFO - 2018-02-07 15:12:24 --> Model Class Initialized
INFO - 2018-02-07 15:12:24 --> Model Class Initialized
INFO - 2018-02-07 15:12:24 --> Model Class Initialized
INFO - 2018-02-07 15:12:24 --> Model Class Initialized
INFO - 2018-02-07 15:12:24 --> Model Class Initialized
INFO - 2018-02-07 15:12:24 --> Model Class Initialized
INFO - 2018-02-07 15:12:24 --> Model Class Initialized
INFO - 2018-02-07 15:12:24 --> Model Class Initialized
INFO - 2018-02-07 15:12:24 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 15:12:24 --> Model Class Initialized
INFO - 2018-02-07 15:12:24 --> Final output sent to browser
DEBUG - 2018-02-07 15:12:24 --> Total execution time: 0.1195
INFO - 2018-02-07 09:42:26 --> Config Class Initialized
INFO - 2018-02-07 09:42:26 --> Hooks Class Initialized
DEBUG - 2018-02-07 09:42:26 --> UTF-8 Support Enabled
INFO - 2018-02-07 09:42:26 --> Utf8 Class Initialized
INFO - 2018-02-07 09:42:26 --> URI Class Initialized
INFO - 2018-02-07 09:42:26 --> Router Class Initialized
INFO - 2018-02-07 09:42:26 --> Output Class Initialized
INFO - 2018-02-07 09:42:26 --> Security Class Initialized
DEBUG - 2018-02-07 09:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 09:42:26 --> Input Class Initialized
INFO - 2018-02-07 09:42:26 --> Language Class Initialized
INFO - 2018-02-07 09:42:26 --> Language Class Initialized
INFO - 2018-02-07 09:42:26 --> Config Class Initialized
INFO - 2018-02-07 09:42:26 --> Loader Class Initialized
INFO - 2018-02-07 15:12:26 --> Helper loaded: url_helper
INFO - 2018-02-07 15:12:26 --> Helper loaded: notification_helper
INFO - 2018-02-07 15:12:26 --> Helper loaded: settings_helper
INFO - 2018-02-07 15:12:26 --> Helper loaded: permission_helper
INFO - 2018-02-07 15:12:26 --> Helper loaded: users_helper
INFO - 2018-02-07 15:12:26 --> Database Driver Class Initialized
DEBUG - 2018-02-07 15:12:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:12:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:12:26 --> Helper loaded: form_helper
INFO - 2018-02-07 15:12:26 --> Form Validation Class Initialized
INFO - 2018-02-07 15:12:26 --> Controller Class Initialized
INFO - 2018-02-07 15:12:26 --> Model Class Initialized
INFO - 2018-02-07 15:12:26 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 15:12:26 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 15:12:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:12:26 --> Model Class Initialized
INFO - 2018-02-07 15:12:26 --> Model Class Initialized
INFO - 2018-02-07 15:12:26 --> Model Class Initialized
INFO - 2018-02-07 15:12:26 --> Model Class Initialized
INFO - 2018-02-07 15:12:26 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 15:12:26 --> Final output sent to browser
DEBUG - 2018-02-07 15:12:26 --> Total execution time: 0.1083
INFO - 2018-02-07 09:42:26 --> Config Class Initialized
INFO - 2018-02-07 09:42:26 --> Hooks Class Initialized
DEBUG - 2018-02-07 09:42:26 --> UTF-8 Support Enabled
INFO - 2018-02-07 09:42:26 --> Utf8 Class Initialized
INFO - 2018-02-07 09:42:26 --> URI Class Initialized
INFO - 2018-02-07 09:42:26 --> Router Class Initialized
INFO - 2018-02-07 09:42:26 --> Output Class Initialized
INFO - 2018-02-07 09:42:26 --> Security Class Initialized
DEBUG - 2018-02-07 09:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 09:42:26 --> Input Class Initialized
INFO - 2018-02-07 09:42:26 --> Language Class Initialized
INFO - 2018-02-07 09:42:26 --> Language Class Initialized
INFO - 2018-02-07 09:42:26 --> Config Class Initialized
INFO - 2018-02-07 09:42:26 --> Loader Class Initialized
INFO - 2018-02-07 15:12:26 --> Helper loaded: url_helper
INFO - 2018-02-07 15:12:26 --> Helper loaded: notification_helper
INFO - 2018-02-07 15:12:26 --> Helper loaded: settings_helper
INFO - 2018-02-07 15:12:26 --> Helper loaded: permission_helper
INFO - 2018-02-07 15:12:26 --> Helper loaded: users_helper
INFO - 2018-02-07 15:12:26 --> Database Driver Class Initialized
DEBUG - 2018-02-07 15:12:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:12:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:12:26 --> Helper loaded: form_helper
INFO - 2018-02-07 15:12:26 --> Form Validation Class Initialized
INFO - 2018-02-07 15:12:26 --> Controller Class Initialized
INFO - 2018-02-07 15:12:26 --> Model Class Initialized
INFO - 2018-02-07 15:12:26 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 15:12:26 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 15:12:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:12:26 --> Model Class Initialized
INFO - 2018-02-07 15:12:26 --> Model Class Initialized
INFO - 2018-02-07 15:12:26 --> Model Class Initialized
INFO - 2018-02-07 15:12:26 --> Model Class Initialized
INFO - 2018-02-07 15:12:26 --> Model Class Initialized
INFO - 2018-02-07 15:12:26 --> Model Class Initialized
INFO - 2018-02-07 15:12:26 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 15:12:26 --> Final output sent to browser
DEBUG - 2018-02-07 15:12:26 --> Total execution time: 0.1260
INFO - 2018-02-07 09:42:29 --> Config Class Initialized
INFO - 2018-02-07 09:42:29 --> Hooks Class Initialized
DEBUG - 2018-02-07 09:42:29 --> UTF-8 Support Enabled
INFO - 2018-02-07 09:42:29 --> Utf8 Class Initialized
INFO - 2018-02-07 09:42:29 --> URI Class Initialized
INFO - 2018-02-07 09:42:29 --> Router Class Initialized
INFO - 2018-02-07 09:42:29 --> Output Class Initialized
INFO - 2018-02-07 09:42:29 --> Security Class Initialized
DEBUG - 2018-02-07 09:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 09:42:29 --> Input Class Initialized
INFO - 2018-02-07 09:42:29 --> Language Class Initialized
INFO - 2018-02-07 09:42:29 --> Language Class Initialized
INFO - 2018-02-07 09:42:29 --> Config Class Initialized
INFO - 2018-02-07 09:42:29 --> Loader Class Initialized
INFO - 2018-02-07 15:12:29 --> Helper loaded: url_helper
INFO - 2018-02-07 15:12:29 --> Helper loaded: notification_helper
INFO - 2018-02-07 15:12:29 --> Helper loaded: settings_helper
INFO - 2018-02-07 15:12:29 --> Helper loaded: permission_helper
INFO - 2018-02-07 15:12:29 --> Helper loaded: users_helper
INFO - 2018-02-07 15:12:29 --> Database Driver Class Initialized
DEBUG - 2018-02-07 15:12:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:12:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:12:29 --> Helper loaded: form_helper
INFO - 2018-02-07 15:12:29 --> Form Validation Class Initialized
INFO - 2018-02-07 15:12:29 --> Controller Class Initialized
INFO - 2018-02-07 15:12:29 --> Model Class Initialized
INFO - 2018-02-07 15:12:29 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 15:12:29 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 15:12:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:12:29 --> Model Class Initialized
INFO - 2018-02-07 15:12:29 --> Model Class Initialized
INFO - 2018-02-07 15:12:29 --> Model Class Initialized
INFO - 2018-02-07 15:12:29 --> Model Class Initialized
INFO - 2018-02-07 15:12:29 --> Model Class Initialized
INFO - 2018-02-07 15:12:29 --> Model Class Initialized
INFO - 2018-02-07 15:12:29 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 15:12:29 --> Model Class Initialized
INFO - 2018-02-07 15:12:29 --> Final output sent to browser
DEBUG - 2018-02-07 15:12:29 --> Total execution time: 0.0827
INFO - 2018-02-07 09:51:45 --> Config Class Initialized
INFO - 2018-02-07 09:51:45 --> Hooks Class Initialized
DEBUG - 2018-02-07 09:51:45 --> UTF-8 Support Enabled
INFO - 2018-02-07 09:51:45 --> Utf8 Class Initialized
INFO - 2018-02-07 09:51:45 --> URI Class Initialized
INFO - 2018-02-07 09:51:45 --> Router Class Initialized
INFO - 2018-02-07 09:51:45 --> Output Class Initialized
INFO - 2018-02-07 09:51:45 --> Security Class Initialized
DEBUG - 2018-02-07 09:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 09:51:45 --> Input Class Initialized
INFO - 2018-02-07 09:51:45 --> Language Class Initialized
INFO - 2018-02-07 09:51:45 --> Language Class Initialized
INFO - 2018-02-07 09:51:45 --> Config Class Initialized
INFO - 2018-02-07 09:51:45 --> Loader Class Initialized
INFO - 2018-02-07 15:21:45 --> Helper loaded: url_helper
INFO - 2018-02-07 15:21:45 --> Helper loaded: notification_helper
INFO - 2018-02-07 15:21:45 --> Helper loaded: settings_helper
INFO - 2018-02-07 15:21:45 --> Helper loaded: permission_helper
INFO - 2018-02-07 15:21:45 --> Helper loaded: users_helper
INFO - 2018-02-07 15:21:45 --> Database Driver Class Initialized
DEBUG - 2018-02-07 15:21:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:21:45 --> Helper loaded: form_helper
INFO - 2018-02-07 15:21:45 --> Form Validation Class Initialized
INFO - 2018-02-07 15:21:45 --> Controller Class Initialized
INFO - 2018-02-07 15:21:45 --> Model Class Initialized
INFO - 2018-02-07 15:21:45 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 15:21:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 15:21:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:21:45 --> Model Class Initialized
INFO - 2018-02-07 15:21:45 --> Model Class Initialized
INFO - 2018-02-07 15:21:45 --> Model Class Initialized
INFO - 2018-02-07 15:21:45 --> Model Class Initialized
INFO - 2018-02-07 15:21:45 --> Model Class Initialized
INFO - 2018-02-07 15:21:45 --> Model Class Initialized
INFO - 2018-02-07 15:21:45 --> Model Class Initialized
INFO - 2018-02-07 15:21:45 --> Model Class Initialized
INFO - 2018-02-07 15:21:45 --> Model Class Initialized
INFO - 2018-02-07 15:21:45 --> Model Class Initialized
INFO - 2018-02-07 15:21:45 --> Model Class Initialized
INFO - 2018-02-07 15:21:45 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 15:21:45 --> Model Class Initialized
INFO - 2018-02-07 15:21:45 --> Final output sent to browser
DEBUG - 2018-02-07 15:21:45 --> Total execution time: 0.1224
INFO - 2018-02-07 09:51:45 --> Config Class Initialized
INFO - 2018-02-07 09:51:45 --> Hooks Class Initialized
DEBUG - 2018-02-07 09:51:45 --> UTF-8 Support Enabled
INFO - 2018-02-07 09:51:45 --> Utf8 Class Initialized
INFO - 2018-02-07 09:51:45 --> URI Class Initialized
INFO - 2018-02-07 09:51:45 --> Router Class Initialized
INFO - 2018-02-07 09:51:45 --> Output Class Initialized
INFO - 2018-02-07 09:51:45 --> Security Class Initialized
DEBUG - 2018-02-07 09:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 09:51:45 --> Input Class Initialized
INFO - 2018-02-07 09:51:45 --> Language Class Initialized
INFO - 2018-02-07 09:51:45 --> Language Class Initialized
INFO - 2018-02-07 09:51:45 --> Config Class Initialized
INFO - 2018-02-07 09:51:45 --> Loader Class Initialized
INFO - 2018-02-07 15:21:45 --> Helper loaded: url_helper
INFO - 2018-02-07 15:21:45 --> Helper loaded: notification_helper
INFO - 2018-02-07 15:21:45 --> Helper loaded: settings_helper
INFO - 2018-02-07 15:21:45 --> Helper loaded: permission_helper
INFO - 2018-02-07 15:21:45 --> Helper loaded: users_helper
INFO - 2018-02-07 15:21:45 --> Database Driver Class Initialized
DEBUG - 2018-02-07 15:21:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:21:45 --> Helper loaded: form_helper
INFO - 2018-02-07 15:21:45 --> Form Validation Class Initialized
INFO - 2018-02-07 15:21:45 --> Controller Class Initialized
INFO - 2018-02-07 15:21:45 --> Model Class Initialized
INFO - 2018-02-07 15:21:45 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 15:21:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 15:21:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:21:45 --> Model Class Initialized
INFO - 2018-02-07 15:21:45 --> Model Class Initialized
INFO - 2018-02-07 15:21:45 --> Model Class Initialized
INFO - 2018-02-07 15:21:45 --> Model Class Initialized
INFO - 2018-02-07 15:21:45 --> Model Class Initialized
INFO - 2018-02-07 15:21:45 --> Model Class Initialized
INFO - 2018-02-07 15:21:45 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 15:21:45 --> Model Class Initialized
INFO - 2018-02-07 15:21:45 --> Final output sent to browser
DEBUG - 2018-02-07 15:21:45 --> Total execution time: 0.1221
INFO - 2018-02-07 09:52:02 --> Config Class Initialized
INFO - 2018-02-07 09:52:02 --> Hooks Class Initialized
DEBUG - 2018-02-07 09:52:02 --> UTF-8 Support Enabled
INFO - 2018-02-07 09:52:02 --> Utf8 Class Initialized
INFO - 2018-02-07 09:52:02 --> URI Class Initialized
INFO - 2018-02-07 09:52:02 --> Router Class Initialized
INFO - 2018-02-07 09:52:02 --> Output Class Initialized
INFO - 2018-02-07 09:52:02 --> Security Class Initialized
DEBUG - 2018-02-07 09:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 09:52:02 --> Input Class Initialized
INFO - 2018-02-07 09:52:02 --> Language Class Initialized
INFO - 2018-02-07 09:52:02 --> Language Class Initialized
INFO - 2018-02-07 09:52:02 --> Config Class Initialized
INFO - 2018-02-07 09:52:02 --> Loader Class Initialized
INFO - 2018-02-07 15:22:02 --> Helper loaded: url_helper
INFO - 2018-02-07 15:22:02 --> Helper loaded: notification_helper
INFO - 2018-02-07 15:22:02 --> Helper loaded: settings_helper
INFO - 2018-02-07 15:22:02 --> Helper loaded: permission_helper
INFO - 2018-02-07 15:22:02 --> Helper loaded: users_helper
INFO - 2018-02-07 15:22:02 --> Database Driver Class Initialized
DEBUG - 2018-02-07 15:22:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:22:02 --> Helper loaded: form_helper
INFO - 2018-02-07 15:22:02 --> Form Validation Class Initialized
INFO - 2018-02-07 15:22:02 --> Controller Class Initialized
INFO - 2018-02-07 15:22:02 --> Model Class Initialized
INFO - 2018-02-07 15:22:02 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 15:22:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 15:22:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:22:02 --> Model Class Initialized
INFO - 2018-02-07 15:22:02 --> Model Class Initialized
INFO - 2018-02-07 15:22:02 --> Model Class Initialized
INFO - 2018-02-07 15:22:02 --> Model Class Initialized
INFO - 2018-02-07 15:22:02 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 15:22:02 --> Final output sent to browser
DEBUG - 2018-02-07 15:22:02 --> Total execution time: 0.1115
INFO - 2018-02-07 09:52:02 --> Config Class Initialized
INFO - 2018-02-07 09:52:02 --> Hooks Class Initialized
DEBUG - 2018-02-07 09:52:02 --> UTF-8 Support Enabled
INFO - 2018-02-07 09:52:02 --> Utf8 Class Initialized
INFO - 2018-02-07 09:52:02 --> URI Class Initialized
INFO - 2018-02-07 09:52:02 --> Router Class Initialized
INFO - 2018-02-07 09:52:02 --> Output Class Initialized
INFO - 2018-02-07 09:52:02 --> Security Class Initialized
DEBUG - 2018-02-07 09:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 09:52:02 --> Input Class Initialized
INFO - 2018-02-07 09:52:02 --> Language Class Initialized
INFO - 2018-02-07 09:52:02 --> Language Class Initialized
INFO - 2018-02-07 09:52:02 --> Config Class Initialized
INFO - 2018-02-07 09:52:02 --> Loader Class Initialized
INFO - 2018-02-07 15:22:02 --> Helper loaded: url_helper
INFO - 2018-02-07 15:22:02 --> Helper loaded: notification_helper
INFO - 2018-02-07 15:22:02 --> Helper loaded: settings_helper
INFO - 2018-02-07 15:22:02 --> Helper loaded: permission_helper
INFO - 2018-02-07 15:22:02 --> Helper loaded: users_helper
INFO - 2018-02-07 15:22:02 --> Database Driver Class Initialized
DEBUG - 2018-02-07 15:22:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:22:02 --> Helper loaded: form_helper
INFO - 2018-02-07 15:22:02 --> Form Validation Class Initialized
INFO - 2018-02-07 15:22:02 --> Controller Class Initialized
INFO - 2018-02-07 15:22:02 --> Model Class Initialized
INFO - 2018-02-07 15:22:02 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 15:22:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 15:22:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:22:02 --> Model Class Initialized
INFO - 2018-02-07 15:22:02 --> Model Class Initialized
INFO - 2018-02-07 15:22:02 --> Model Class Initialized
INFO - 2018-02-07 15:22:02 --> Model Class Initialized
INFO - 2018-02-07 15:22:02 --> Model Class Initialized
INFO - 2018-02-07 15:22:02 --> Model Class Initialized
INFO - 2018-02-07 15:22:02 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 15:22:02 --> Final output sent to browser
DEBUG - 2018-02-07 15:22:02 --> Total execution time: 0.1161
INFO - 2018-02-07 09:52:07 --> Config Class Initialized
INFO - 2018-02-07 09:52:07 --> Hooks Class Initialized
DEBUG - 2018-02-07 09:52:07 --> UTF-8 Support Enabled
INFO - 2018-02-07 09:52:07 --> Utf8 Class Initialized
INFO - 2018-02-07 09:52:07 --> URI Class Initialized
INFO - 2018-02-07 09:52:07 --> Router Class Initialized
INFO - 2018-02-07 09:52:07 --> Output Class Initialized
INFO - 2018-02-07 09:52:07 --> Security Class Initialized
DEBUG - 2018-02-07 09:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 09:52:07 --> Input Class Initialized
INFO - 2018-02-07 09:52:07 --> Language Class Initialized
INFO - 2018-02-07 09:52:07 --> Language Class Initialized
INFO - 2018-02-07 09:52:07 --> Config Class Initialized
INFO - 2018-02-07 09:52:07 --> Loader Class Initialized
INFO - 2018-02-07 15:22:07 --> Helper loaded: url_helper
INFO - 2018-02-07 15:22:07 --> Helper loaded: notification_helper
INFO - 2018-02-07 15:22:07 --> Helper loaded: settings_helper
INFO - 2018-02-07 15:22:07 --> Helper loaded: permission_helper
INFO - 2018-02-07 15:22:07 --> Helper loaded: users_helper
INFO - 2018-02-07 15:22:07 --> Database Driver Class Initialized
DEBUG - 2018-02-07 15:22:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:22:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:22:07 --> Helper loaded: form_helper
INFO - 2018-02-07 15:22:07 --> Form Validation Class Initialized
INFO - 2018-02-07 15:22:07 --> Controller Class Initialized
INFO - 2018-02-07 15:22:07 --> Model Class Initialized
INFO - 2018-02-07 15:22:07 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 15:22:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 15:22:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:22:07 --> Model Class Initialized
INFO - 2018-02-07 15:22:07 --> Model Class Initialized
INFO - 2018-02-07 15:22:07 --> Model Class Initialized
INFO - 2018-02-07 15:22:07 --> Model Class Initialized
INFO - 2018-02-07 15:22:07 --> Model Class Initialized
INFO - 2018-02-07 15:22:07 --> Model Class Initialized
INFO - 2018-02-07 15:22:07 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 15:22:07 --> Model Class Initialized
INFO - 2018-02-07 15:22:07 --> Final output sent to browser
DEBUG - 2018-02-07 15:22:07 --> Total execution time: 0.1288
INFO - 2018-02-07 10:02:38 --> Config Class Initialized
INFO - 2018-02-07 10:02:38 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:02:38 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:02:38 --> Utf8 Class Initialized
INFO - 2018-02-07 10:02:38 --> URI Class Initialized
INFO - 2018-02-07 10:02:38 --> Router Class Initialized
INFO - 2018-02-07 10:02:38 --> Output Class Initialized
INFO - 2018-02-07 10:02:38 --> Security Class Initialized
DEBUG - 2018-02-07 10:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:02:38 --> Input Class Initialized
INFO - 2018-02-07 10:02:38 --> Language Class Initialized
INFO - 2018-02-07 10:02:38 --> Language Class Initialized
INFO - 2018-02-07 10:02:38 --> Config Class Initialized
INFO - 2018-02-07 10:02:38 --> Loader Class Initialized
INFO - 2018-02-07 15:32:38 --> Helper loaded: url_helper
INFO - 2018-02-07 15:32:38 --> Helper loaded: notification_helper
INFO - 2018-02-07 15:32:38 --> Helper loaded: settings_helper
INFO - 2018-02-07 15:32:38 --> Helper loaded: permission_helper
INFO - 2018-02-07 15:32:38 --> Helper loaded: users_helper
INFO - 2018-02-07 15:32:38 --> Database Driver Class Initialized
DEBUG - 2018-02-07 15:32:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:32:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:32:38 --> Helper loaded: form_helper
INFO - 2018-02-07 15:32:38 --> Form Validation Class Initialized
INFO - 2018-02-07 15:32:38 --> Controller Class Initialized
INFO - 2018-02-07 15:32:38 --> Model Class Initialized
INFO - 2018-02-07 15:32:38 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 15:32:38 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 15:32:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:32:38 --> Model Class Initialized
INFO - 2018-02-07 15:32:38 --> Model Class Initialized
INFO - 2018-02-07 15:32:38 --> Model Class Initialized
INFO - 2018-02-07 15:32:38 --> Model Class Initialized
INFO - 2018-02-07 15:32:38 --> Model Class Initialized
INFO - 2018-02-07 15:32:38 --> Model Class Initialized
INFO - 2018-02-07 15:32:38 --> Model Class Initialized
INFO - 2018-02-07 15:32:38 --> Model Class Initialized
INFO - 2018-02-07 15:32:38 --> Model Class Initialized
INFO - 2018-02-07 15:32:38 --> Model Class Initialized
INFO - 2018-02-07 15:32:38 --> Model Class Initialized
INFO - 2018-02-07 15:32:38 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 15:32:38 --> Model Class Initialized
INFO - 2018-02-07 15:32:38 --> Final output sent to browser
DEBUG - 2018-02-07 15:32:38 --> Total execution time: 0.1371
INFO - 2018-02-07 10:02:38 --> Config Class Initialized
INFO - 2018-02-07 10:02:38 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:02:38 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:02:38 --> Utf8 Class Initialized
INFO - 2018-02-07 10:02:38 --> URI Class Initialized
INFO - 2018-02-07 10:02:38 --> Router Class Initialized
INFO - 2018-02-07 10:02:38 --> Output Class Initialized
INFO - 2018-02-07 10:02:38 --> Security Class Initialized
DEBUG - 2018-02-07 10:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:02:38 --> Input Class Initialized
INFO - 2018-02-07 10:02:38 --> Language Class Initialized
INFO - 2018-02-07 10:02:38 --> Language Class Initialized
INFO - 2018-02-07 10:02:38 --> Config Class Initialized
INFO - 2018-02-07 10:02:38 --> Loader Class Initialized
INFO - 2018-02-07 15:32:38 --> Helper loaded: url_helper
INFO - 2018-02-07 15:32:38 --> Helper loaded: notification_helper
INFO - 2018-02-07 15:32:38 --> Helper loaded: settings_helper
INFO - 2018-02-07 15:32:38 --> Helper loaded: permission_helper
INFO - 2018-02-07 15:32:38 --> Helper loaded: users_helper
INFO - 2018-02-07 15:32:38 --> Database Driver Class Initialized
DEBUG - 2018-02-07 15:32:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:32:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:32:38 --> Helper loaded: form_helper
INFO - 2018-02-07 15:32:38 --> Form Validation Class Initialized
INFO - 2018-02-07 15:32:38 --> Controller Class Initialized
INFO - 2018-02-07 15:32:38 --> Model Class Initialized
INFO - 2018-02-07 15:32:38 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 15:32:38 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 15:32:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:32:38 --> Model Class Initialized
INFO - 2018-02-07 15:32:38 --> Model Class Initialized
INFO - 2018-02-07 15:32:38 --> Model Class Initialized
INFO - 2018-02-07 15:32:38 --> Model Class Initialized
INFO - 2018-02-07 15:32:38 --> Model Class Initialized
INFO - 2018-02-07 15:32:38 --> Model Class Initialized
INFO - 2018-02-07 15:32:38 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 15:32:38 --> Model Class Initialized
INFO - 2018-02-07 15:32:38 --> Final output sent to browser
DEBUG - 2018-02-07 15:32:38 --> Total execution time: 0.1123
INFO - 2018-02-07 10:02:48 --> Config Class Initialized
INFO - 2018-02-07 10:02:48 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:02:48 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:02:48 --> Utf8 Class Initialized
INFO - 2018-02-07 10:02:48 --> URI Class Initialized
INFO - 2018-02-07 10:02:48 --> Router Class Initialized
INFO - 2018-02-07 10:02:48 --> Output Class Initialized
INFO - 2018-02-07 10:02:48 --> Security Class Initialized
DEBUG - 2018-02-07 10:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:02:48 --> Input Class Initialized
INFO - 2018-02-07 10:02:48 --> Language Class Initialized
INFO - 2018-02-07 10:02:48 --> Config Class Initialized
INFO - 2018-02-07 10:02:48 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:02:48 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:02:48 --> Utf8 Class Initialized
INFO - 2018-02-07 10:02:48 --> URI Class Initialized
INFO - 2018-02-07 10:02:48 --> Language Class Initialized
INFO - 2018-02-07 10:02:48 --> Config Class Initialized
INFO - 2018-02-07 10:02:48 --> Loader Class Initialized
INFO - 2018-02-07 15:32:48 --> Helper loaded: url_helper
INFO - 2018-02-07 15:32:48 --> Helper loaded: notification_helper
INFO - 2018-02-07 15:32:48 --> Helper loaded: settings_helper
INFO - 2018-02-07 10:02:48 --> Router Class Initialized
INFO - 2018-02-07 15:32:48 --> Helper loaded: permission_helper
INFO - 2018-02-07 15:32:48 --> Helper loaded: users_helper
INFO - 2018-02-07 10:02:48 --> Output Class Initialized
INFO - 2018-02-07 10:02:48 --> Security Class Initialized
DEBUG - 2018-02-07 10:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:02:48 --> Input Class Initialized
INFO - 2018-02-07 10:02:48 --> Language Class Initialized
INFO - 2018-02-07 15:32:48 --> Database Driver Class Initialized
DEBUG - 2018-02-07 15:32:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:32:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:32:48 --> Helper loaded: form_helper
INFO - 2018-02-07 15:32:48 --> Form Validation Class Initialized
INFO - 2018-02-07 15:32:48 --> Controller Class Initialized
INFO - 2018-02-07 10:02:48 --> Language Class Initialized
INFO - 2018-02-07 10:02:48 --> Config Class Initialized
INFO - 2018-02-07 10:02:48 --> Loader Class Initialized
INFO - 2018-02-07 15:32:48 --> Model Class Initialized
INFO - 2018-02-07 15:32:48 --> Helper loaded: inflector_helper
INFO - 2018-02-07 15:32:48 --> Helper loaded: url_helper
INFO - 2018-02-07 15:32:48 --> Helper loaded: notification_helper
INFO - 2018-02-07 15:32:48 --> Helper loaded: settings_helper
DEBUG - 2018-02-07 15:32:48 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 15:32:48 --> Helper loaded: permission_helper
INFO - 2018-02-07 15:32:48 --> Helper loaded: users_helper
INFO - 2018-02-07 15:32:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:32:48 --> Model Class Initialized
INFO - 2018-02-07 15:32:48 --> Model Class Initialized
INFO - 2018-02-07 15:32:48 --> Model Class Initialized
INFO - 2018-02-07 15:32:48 --> Model Class Initialized
INFO - 2018-02-07 15:32:48 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 15:32:48 --> Final output sent to browser
DEBUG - 2018-02-07 15:32:48 --> Total execution time: 0.0838
INFO - 2018-02-07 15:32:48 --> Database Driver Class Initialized
DEBUG - 2018-02-07 15:32:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:32:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:32:48 --> Helper loaded: form_helper
INFO - 2018-02-07 15:32:48 --> Form Validation Class Initialized
INFO - 2018-02-07 15:32:48 --> Controller Class Initialized
INFO - 2018-02-07 15:32:48 --> Model Class Initialized
INFO - 2018-02-07 15:32:48 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 15:32:48 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 15:32:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:32:48 --> Model Class Initialized
INFO - 2018-02-07 15:32:48 --> Model Class Initialized
INFO - 2018-02-07 15:32:48 --> Model Class Initialized
INFO - 2018-02-07 15:32:48 --> Model Class Initialized
INFO - 2018-02-07 15:32:48 --> Model Class Initialized
INFO - 2018-02-07 15:32:48 --> Model Class Initialized
INFO - 2018-02-07 15:32:48 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 15:32:48 --> Final output sent to browser
DEBUG - 2018-02-07 15:32:48 --> Total execution time: 0.1103
INFO - 2018-02-07 10:02:49 --> Config Class Initialized
INFO - 2018-02-07 10:02:49 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:02:49 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:02:49 --> Utf8 Class Initialized
INFO - 2018-02-07 10:02:49 --> URI Class Initialized
INFO - 2018-02-07 10:02:49 --> Router Class Initialized
INFO - 2018-02-07 10:02:49 --> Output Class Initialized
INFO - 2018-02-07 10:02:49 --> Security Class Initialized
DEBUG - 2018-02-07 10:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:02:49 --> Input Class Initialized
INFO - 2018-02-07 10:02:49 --> Language Class Initialized
INFO - 2018-02-07 10:02:49 --> Language Class Initialized
INFO - 2018-02-07 10:02:49 --> Config Class Initialized
INFO - 2018-02-07 10:02:49 --> Loader Class Initialized
INFO - 2018-02-07 15:32:49 --> Helper loaded: url_helper
INFO - 2018-02-07 15:32:49 --> Helper loaded: notification_helper
INFO - 2018-02-07 15:32:49 --> Helper loaded: settings_helper
INFO - 2018-02-07 15:32:49 --> Helper loaded: permission_helper
INFO - 2018-02-07 15:32:49 --> Helper loaded: users_helper
INFO - 2018-02-07 15:32:49 --> Database Driver Class Initialized
DEBUG - 2018-02-07 15:32:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:32:49 --> Helper loaded: form_helper
INFO - 2018-02-07 15:32:49 --> Form Validation Class Initialized
INFO - 2018-02-07 15:32:49 --> Controller Class Initialized
INFO - 2018-02-07 15:32:49 --> Model Class Initialized
INFO - 2018-02-07 15:32:49 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 15:32:49 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 15:32:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:32:49 --> Model Class Initialized
INFO - 2018-02-07 15:32:49 --> Model Class Initialized
INFO - 2018-02-07 15:32:49 --> Model Class Initialized
INFO - 2018-02-07 15:32:49 --> Model Class Initialized
INFO - 2018-02-07 15:32:49 --> Model Class Initialized
INFO - 2018-02-07 15:32:49 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 15:32:49 --> Model Class Initialized
INFO - 2018-02-07 15:32:49 --> Final output sent to browser
DEBUG - 2018-02-07 15:32:49 --> Total execution time: 0.1081
INFO - 2018-02-07 10:02:50 --> Config Class Initialized
INFO - 2018-02-07 10:02:50 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:02:50 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:02:50 --> Utf8 Class Initialized
INFO - 2018-02-07 10:02:50 --> URI Class Initialized
INFO - 2018-02-07 10:02:50 --> Router Class Initialized
INFO - 2018-02-07 10:02:50 --> Output Class Initialized
INFO - 2018-02-07 10:02:50 --> Security Class Initialized
DEBUG - 2018-02-07 10:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:02:50 --> Input Class Initialized
INFO - 2018-02-07 10:02:50 --> Language Class Initialized
INFO - 2018-02-07 10:02:50 --> Language Class Initialized
INFO - 2018-02-07 10:02:50 --> Config Class Initialized
INFO - 2018-02-07 10:02:50 --> Loader Class Initialized
INFO - 2018-02-07 15:32:50 --> Helper loaded: url_helper
INFO - 2018-02-07 15:32:50 --> Helper loaded: notification_helper
INFO - 2018-02-07 15:32:50 --> Helper loaded: settings_helper
INFO - 2018-02-07 15:32:50 --> Helper loaded: permission_helper
INFO - 2018-02-07 15:32:50 --> Helper loaded: users_helper
INFO - 2018-02-07 15:32:50 --> Database Driver Class Initialized
DEBUG - 2018-02-07 15:32:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:32:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:32:50 --> Helper loaded: form_helper
INFO - 2018-02-07 15:32:50 --> Form Validation Class Initialized
INFO - 2018-02-07 15:32:50 --> Controller Class Initialized
INFO - 2018-02-07 15:32:50 --> Model Class Initialized
INFO - 2018-02-07 15:32:50 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 15:32:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 15:32:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:32:50 --> Model Class Initialized
INFO - 2018-02-07 15:32:50 --> Model Class Initialized
INFO - 2018-02-07 15:32:50 --> Model Class Initialized
INFO - 2018-02-07 15:32:50 --> Model Class Initialized
INFO - 2018-02-07 15:32:50 --> Model Class Initialized
INFO - 2018-02-07 15:32:50 --> Model Class Initialized
INFO - 2018-02-07 15:32:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 15:32:50 --> Final output sent to browser
DEBUG - 2018-02-07 15:32:50 --> Total execution time: 0.1206
INFO - 2018-02-07 10:02:52 --> Config Class Initialized
INFO - 2018-02-07 10:02:52 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:02:52 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:02:52 --> Utf8 Class Initialized
INFO - 2018-02-07 10:02:52 --> URI Class Initialized
INFO - 2018-02-07 10:02:52 --> Router Class Initialized
INFO - 2018-02-07 10:02:52 --> Output Class Initialized
INFO - 2018-02-07 10:02:52 --> Security Class Initialized
DEBUG - 2018-02-07 10:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:02:52 --> Input Class Initialized
INFO - 2018-02-07 10:02:52 --> Language Class Initialized
INFO - 2018-02-07 10:02:52 --> Language Class Initialized
INFO - 2018-02-07 10:02:52 --> Config Class Initialized
INFO - 2018-02-07 10:02:52 --> Loader Class Initialized
INFO - 2018-02-07 15:32:52 --> Helper loaded: url_helper
INFO - 2018-02-07 15:32:52 --> Helper loaded: notification_helper
INFO - 2018-02-07 15:32:52 --> Helper loaded: settings_helper
INFO - 2018-02-07 15:32:52 --> Helper loaded: permission_helper
INFO - 2018-02-07 15:32:52 --> Helper loaded: users_helper
INFO - 2018-02-07 15:32:52 --> Database Driver Class Initialized
DEBUG - 2018-02-07 15:32:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:32:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:32:52 --> Helper loaded: form_helper
INFO - 2018-02-07 15:32:52 --> Form Validation Class Initialized
INFO - 2018-02-07 15:32:52 --> Controller Class Initialized
INFO - 2018-02-07 15:32:52 --> Model Class Initialized
INFO - 2018-02-07 15:32:52 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 15:32:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 15:32:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:32:52 --> Model Class Initialized
INFO - 2018-02-07 15:32:52 --> Model Class Initialized
INFO - 2018-02-07 15:32:52 --> Model Class Initialized
INFO - 2018-02-07 15:32:52 --> Model Class Initialized
INFO - 2018-02-07 15:32:52 --> Model Class Initialized
INFO - 2018-02-07 15:32:52 --> Model Class Initialized
INFO - 2018-02-07 15:32:52 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 15:32:52 --> Final output sent to browser
DEBUG - 2018-02-07 15:32:52 --> Total execution time: 0.1205
INFO - 2018-02-07 10:02:54 --> Config Class Initialized
INFO - 2018-02-07 10:02:54 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:02:54 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:02:54 --> Utf8 Class Initialized
INFO - 2018-02-07 10:02:54 --> URI Class Initialized
INFO - 2018-02-07 10:02:54 --> Router Class Initialized
INFO - 2018-02-07 10:02:54 --> Output Class Initialized
INFO - 2018-02-07 10:02:54 --> Security Class Initialized
DEBUG - 2018-02-07 10:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:02:54 --> Input Class Initialized
INFO - 2018-02-07 10:02:54 --> Language Class Initialized
INFO - 2018-02-07 10:02:54 --> Language Class Initialized
INFO - 2018-02-07 10:02:54 --> Config Class Initialized
INFO - 2018-02-07 10:02:54 --> Loader Class Initialized
INFO - 2018-02-07 15:32:54 --> Helper loaded: url_helper
INFO - 2018-02-07 15:32:54 --> Helper loaded: notification_helper
INFO - 2018-02-07 15:32:54 --> Helper loaded: settings_helper
INFO - 2018-02-07 15:32:54 --> Helper loaded: permission_helper
INFO - 2018-02-07 15:32:54 --> Helper loaded: users_helper
INFO - 2018-02-07 15:32:54 --> Database Driver Class Initialized
DEBUG - 2018-02-07 15:32:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:32:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:32:54 --> Helper loaded: form_helper
INFO - 2018-02-07 15:32:54 --> Form Validation Class Initialized
INFO - 2018-02-07 15:32:54 --> Controller Class Initialized
INFO - 2018-02-07 15:32:54 --> Model Class Initialized
INFO - 2018-02-07 15:32:54 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 15:32:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 15:32:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:32:54 --> Model Class Initialized
INFO - 2018-02-07 15:32:54 --> Model Class Initialized
INFO - 2018-02-07 15:32:54 --> Model Class Initialized
INFO - 2018-02-07 15:32:54 --> Model Class Initialized
INFO - 2018-02-07 15:32:54 --> Model Class Initialized
INFO - 2018-02-07 15:32:54 --> Model Class Initialized
INFO - 2018-02-07 15:32:54 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 15:32:54 --> Model Class Initialized
INFO - 2018-02-07 15:32:54 --> Final output sent to browser
DEBUG - 2018-02-07 15:32:54 --> Total execution time: 0.1120
INFO - 2018-02-07 10:03:02 --> Config Class Initialized
INFO - 2018-02-07 10:03:02 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:03:02 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:03:02 --> Utf8 Class Initialized
INFO - 2018-02-07 10:03:02 --> URI Class Initialized
INFO - 2018-02-07 10:03:02 --> Router Class Initialized
INFO - 2018-02-07 10:03:02 --> Output Class Initialized
INFO - 2018-02-07 10:03:02 --> Security Class Initialized
DEBUG - 2018-02-07 10:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:03:02 --> Input Class Initialized
INFO - 2018-02-07 10:03:02 --> Language Class Initialized
INFO - 2018-02-07 10:03:02 --> Language Class Initialized
INFO - 2018-02-07 10:03:02 --> Config Class Initialized
INFO - 2018-02-07 10:03:02 --> Loader Class Initialized
INFO - 2018-02-07 15:33:02 --> Helper loaded: url_helper
INFO - 2018-02-07 15:33:02 --> Helper loaded: notification_helper
INFO - 2018-02-07 15:33:02 --> Helper loaded: settings_helper
INFO - 2018-02-07 15:33:02 --> Helper loaded: permission_helper
INFO - 2018-02-07 15:33:02 --> Helper loaded: users_helper
INFO - 2018-02-07 15:33:02 --> Database Driver Class Initialized
DEBUG - 2018-02-07 15:33:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:33:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:33:02 --> Helper loaded: form_helper
INFO - 2018-02-07 15:33:02 --> Form Validation Class Initialized
INFO - 2018-02-07 15:33:02 --> Controller Class Initialized
INFO - 2018-02-07 15:33:02 --> Model Class Initialized
INFO - 2018-02-07 15:33:02 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 15:33:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 15:33:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:33:02 --> Model Class Initialized
INFO - 2018-02-07 15:33:02 --> Model Class Initialized
INFO - 2018-02-07 15:33:02 --> Model Class Initialized
INFO - 2018-02-07 15:33:02 --> Model Class Initialized
INFO - 2018-02-07 15:33:02 --> Model Class Initialized
INFO - 2018-02-07 15:33:02 --> Model Class Initialized
INFO - 2018-02-07 15:33:02 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 15:33:02 --> Model Class Initialized
INFO - 2018-02-07 15:33:02 --> Final output sent to browser
DEBUG - 2018-02-07 15:33:02 --> Total execution time: 0.1127
INFO - 2018-02-07 10:03:06 --> Config Class Initialized
INFO - 2018-02-07 10:03:06 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:03:06 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:03:06 --> Utf8 Class Initialized
INFO - 2018-02-07 10:03:06 --> URI Class Initialized
INFO - 2018-02-07 10:03:06 --> Router Class Initialized
INFO - 2018-02-07 10:03:06 --> Output Class Initialized
INFO - 2018-02-07 10:03:06 --> Security Class Initialized
DEBUG - 2018-02-07 10:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:03:06 --> Input Class Initialized
INFO - 2018-02-07 10:03:06 --> Language Class Initialized
INFO - 2018-02-07 10:03:06 --> Language Class Initialized
INFO - 2018-02-07 10:03:06 --> Config Class Initialized
INFO - 2018-02-07 10:03:06 --> Loader Class Initialized
INFO - 2018-02-07 15:33:06 --> Helper loaded: url_helper
INFO - 2018-02-07 15:33:06 --> Helper loaded: notification_helper
INFO - 2018-02-07 15:33:06 --> Helper loaded: settings_helper
INFO - 2018-02-07 15:33:06 --> Helper loaded: permission_helper
INFO - 2018-02-07 15:33:06 --> Helper loaded: users_helper
INFO - 2018-02-07 15:33:06 --> Database Driver Class Initialized
DEBUG - 2018-02-07 15:33:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:33:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:33:06 --> Helper loaded: form_helper
INFO - 2018-02-07 15:33:06 --> Form Validation Class Initialized
INFO - 2018-02-07 15:33:06 --> Controller Class Initialized
INFO - 2018-02-07 15:33:06 --> Model Class Initialized
INFO - 2018-02-07 15:33:06 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 15:33:06 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 15:33:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:33:06 --> Model Class Initialized
INFO - 2018-02-07 15:33:06 --> Model Class Initialized
INFO - 2018-02-07 15:33:06 --> Model Class Initialized
INFO - 2018-02-07 15:33:06 --> Model Class Initialized
INFO - 2018-02-07 15:33:06 --> Model Class Initialized
INFO - 2018-02-07 15:33:06 --> Model Class Initialized
INFO - 2018-02-07 15:33:06 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 15:33:06 --> Final output sent to browser
DEBUG - 2018-02-07 15:33:06 --> Total execution time: 0.1228
INFO - 2018-02-07 10:03:07 --> Config Class Initialized
INFO - 2018-02-07 10:03:07 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:03:07 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:03:07 --> Utf8 Class Initialized
INFO - 2018-02-07 10:03:07 --> URI Class Initialized
INFO - 2018-02-07 10:03:07 --> Router Class Initialized
INFO - 2018-02-07 10:03:07 --> Output Class Initialized
INFO - 2018-02-07 10:03:07 --> Security Class Initialized
DEBUG - 2018-02-07 10:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:03:07 --> Input Class Initialized
INFO - 2018-02-07 10:03:07 --> Language Class Initialized
INFO - 2018-02-07 10:03:07 --> Language Class Initialized
INFO - 2018-02-07 10:03:07 --> Config Class Initialized
INFO - 2018-02-07 10:03:07 --> Loader Class Initialized
INFO - 2018-02-07 15:33:07 --> Helper loaded: url_helper
INFO - 2018-02-07 15:33:07 --> Helper loaded: notification_helper
INFO - 2018-02-07 15:33:07 --> Helper loaded: settings_helper
INFO - 2018-02-07 15:33:07 --> Helper loaded: permission_helper
INFO - 2018-02-07 15:33:07 --> Helper loaded: users_helper
INFO - 2018-02-07 15:33:07 --> Database Driver Class Initialized
DEBUG - 2018-02-07 15:33:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:33:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:33:07 --> Helper loaded: form_helper
INFO - 2018-02-07 15:33:07 --> Form Validation Class Initialized
INFO - 2018-02-07 15:33:07 --> Controller Class Initialized
INFO - 2018-02-07 15:33:07 --> Model Class Initialized
INFO - 2018-02-07 15:33:07 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 15:33:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 15:33:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:33:07 --> Model Class Initialized
INFO - 2018-02-07 15:33:07 --> Model Class Initialized
INFO - 2018-02-07 15:33:07 --> Model Class Initialized
INFO - 2018-02-07 15:33:07 --> Model Class Initialized
INFO - 2018-02-07 15:33:07 --> Model Class Initialized
INFO - 2018-02-07 15:33:07 --> Model Class Initialized
INFO - 2018-02-07 15:33:07 --> Model Class Initialized
INFO - 2018-02-07 15:33:07 --> Model Class Initialized
INFO - 2018-02-07 15:33:07 --> Model Class Initialized
INFO - 2018-02-07 15:33:07 --> Model Class Initialized
INFO - 2018-02-07 15:33:07 --> Model Class Initialized
INFO - 2018-02-07 15:33:07 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 15:33:07 --> Model Class Initialized
INFO - 2018-02-07 15:33:07 --> Final output sent to browser
DEBUG - 2018-02-07 15:33:07 --> Total execution time: 0.1480
INFO - 2018-02-07 10:03:13 --> Config Class Initialized
INFO - 2018-02-07 10:03:13 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:03:13 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:03:13 --> Utf8 Class Initialized
INFO - 2018-02-07 10:03:13 --> URI Class Initialized
INFO - 2018-02-07 10:03:13 --> Router Class Initialized
INFO - 2018-02-07 10:03:13 --> Output Class Initialized
INFO - 2018-02-07 10:03:13 --> Security Class Initialized
DEBUG - 2018-02-07 10:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:03:13 --> Input Class Initialized
INFO - 2018-02-07 10:03:13 --> Language Class Initialized
INFO - 2018-02-07 10:03:13 --> Language Class Initialized
INFO - 2018-02-07 10:03:13 --> Config Class Initialized
INFO - 2018-02-07 10:03:13 --> Loader Class Initialized
INFO - 2018-02-07 15:33:13 --> Helper loaded: url_helper
INFO - 2018-02-07 15:33:13 --> Helper loaded: notification_helper
INFO - 2018-02-07 15:33:13 --> Helper loaded: settings_helper
INFO - 2018-02-07 15:33:13 --> Helper loaded: permission_helper
INFO - 2018-02-07 15:33:13 --> Helper loaded: users_helper
INFO - 2018-02-07 15:33:13 --> Database Driver Class Initialized
DEBUG - 2018-02-07 15:33:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:33:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:33:13 --> Helper loaded: form_helper
INFO - 2018-02-07 15:33:13 --> Form Validation Class Initialized
INFO - 2018-02-07 15:33:13 --> Controller Class Initialized
INFO - 2018-02-07 15:33:13 --> Model Class Initialized
INFO - 2018-02-07 15:33:13 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 15:33:13 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 15:33:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:33:13 --> Model Class Initialized
INFO - 2018-02-07 15:33:13 --> Model Class Initialized
INFO - 2018-02-07 15:33:13 --> Model Class Initialized
INFO - 2018-02-07 15:33:13 --> Model Class Initialized
INFO - 2018-02-07 15:33:13 --> Model Class Initialized
INFO - 2018-02-07 15:33:13 --> Model Class Initialized
INFO - 2018-02-07 15:33:13 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-02-07 15:33:13 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 771
INFO - 2018-02-07 15:33:13 --> Final output sent to browser
DEBUG - 2018-02-07 15:33:13 --> Total execution time: 0.1206
INFO - 2018-02-07 10:04:24 --> Config Class Initialized
INFO - 2018-02-07 10:04:24 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:04:24 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:04:24 --> Utf8 Class Initialized
INFO - 2018-02-07 10:04:24 --> URI Class Initialized
INFO - 2018-02-07 10:04:24 --> Router Class Initialized
INFO - 2018-02-07 10:04:24 --> Output Class Initialized
INFO - 2018-02-07 10:04:24 --> Security Class Initialized
DEBUG - 2018-02-07 10:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:04:24 --> Input Class Initialized
INFO - 2018-02-07 10:04:24 --> Language Class Initialized
INFO - 2018-02-07 10:04:24 --> Language Class Initialized
INFO - 2018-02-07 10:04:24 --> Config Class Initialized
INFO - 2018-02-07 10:04:24 --> Loader Class Initialized
INFO - 2018-02-07 15:34:24 --> Helper loaded: url_helper
INFO - 2018-02-07 15:34:24 --> Helper loaded: notification_helper
INFO - 2018-02-07 15:34:24 --> Helper loaded: settings_helper
INFO - 2018-02-07 15:34:24 --> Helper loaded: permission_helper
INFO - 2018-02-07 15:34:24 --> Helper loaded: users_helper
INFO - 2018-02-07 15:34:24 --> Database Driver Class Initialized
DEBUG - 2018-02-07 15:34:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:34:24 --> Helper loaded: form_helper
INFO - 2018-02-07 15:34:24 --> Form Validation Class Initialized
INFO - 2018-02-07 15:34:24 --> Controller Class Initialized
INFO - 2018-02-07 15:34:24 --> Model Class Initialized
INFO - 2018-02-07 15:34:24 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 15:34:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 15:34:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:34:24 --> Model Class Initialized
INFO - 2018-02-07 15:34:24 --> Model Class Initialized
INFO - 2018-02-07 15:34:24 --> Model Class Initialized
INFO - 2018-02-07 15:34:24 --> Model Class Initialized
INFO - 2018-02-07 15:34:24 --> Model Class Initialized
INFO - 2018-02-07 15:34:24 --> Model Class Initialized
INFO - 2018-02-07 15:34:24 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 15:34:24 --> Model Class Initialized
INFO - 2018-02-07 15:34:24 --> Final output sent to browser
DEBUG - 2018-02-07 15:34:24 --> Total execution time: 0.1143
INFO - 2018-02-07 10:05:15 --> Config Class Initialized
INFO - 2018-02-07 10:05:15 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:05:15 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:05:15 --> Utf8 Class Initialized
INFO - 2018-02-07 10:05:15 --> URI Class Initialized
INFO - 2018-02-07 10:05:15 --> Router Class Initialized
INFO - 2018-02-07 10:05:15 --> Output Class Initialized
INFO - 2018-02-07 10:05:15 --> Security Class Initialized
DEBUG - 2018-02-07 10:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:05:15 --> Input Class Initialized
INFO - 2018-02-07 10:05:15 --> Language Class Initialized
INFO - 2018-02-07 10:05:15 --> Language Class Initialized
INFO - 2018-02-07 10:05:15 --> Config Class Initialized
INFO - 2018-02-07 10:05:15 --> Loader Class Initialized
INFO - 2018-02-07 15:35:15 --> Helper loaded: url_helper
INFO - 2018-02-07 15:35:15 --> Helper loaded: notification_helper
INFO - 2018-02-07 15:35:15 --> Helper loaded: settings_helper
INFO - 2018-02-07 15:35:15 --> Helper loaded: permission_helper
INFO - 2018-02-07 15:35:15 --> Helper loaded: users_helper
INFO - 2018-02-07 15:35:15 --> Database Driver Class Initialized
DEBUG - 2018-02-07 15:35:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:35:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:35:15 --> Helper loaded: form_helper
INFO - 2018-02-07 15:35:15 --> Form Validation Class Initialized
INFO - 2018-02-07 15:35:15 --> Controller Class Initialized
INFO - 2018-02-07 15:35:15 --> Model Class Initialized
INFO - 2018-02-07 15:35:15 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 15:35:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 15:35:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:35:15 --> Model Class Initialized
INFO - 2018-02-07 15:35:15 --> Model Class Initialized
INFO - 2018-02-07 15:35:15 --> Model Class Initialized
INFO - 2018-02-07 15:35:15 --> Model Class Initialized
INFO - 2018-02-07 15:35:15 --> Model Class Initialized
INFO - 2018-02-07 15:35:15 --> Model Class Initialized
INFO - 2018-02-07 15:35:15 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 15:35:15 --> Final output sent to browser
DEBUG - 2018-02-07 15:35:15 --> Total execution time: 0.1160
INFO - 2018-02-07 10:05:18 --> Config Class Initialized
INFO - 2018-02-07 10:05:18 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:05:18 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:05:18 --> Utf8 Class Initialized
INFO - 2018-02-07 10:05:18 --> URI Class Initialized
INFO - 2018-02-07 10:05:18 --> Router Class Initialized
INFO - 2018-02-07 10:05:18 --> Output Class Initialized
INFO - 2018-02-07 10:05:18 --> Security Class Initialized
DEBUG - 2018-02-07 10:05:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:05:18 --> Input Class Initialized
INFO - 2018-02-07 10:05:18 --> Language Class Initialized
INFO - 2018-02-07 10:05:18 --> Language Class Initialized
INFO - 2018-02-07 10:05:18 --> Config Class Initialized
INFO - 2018-02-07 10:05:18 --> Loader Class Initialized
INFO - 2018-02-07 15:35:18 --> Helper loaded: url_helper
INFO - 2018-02-07 15:35:18 --> Helper loaded: notification_helper
INFO - 2018-02-07 15:35:18 --> Helper loaded: settings_helper
INFO - 2018-02-07 15:35:18 --> Helper loaded: permission_helper
INFO - 2018-02-07 15:35:18 --> Helper loaded: users_helper
INFO - 2018-02-07 15:35:18 --> Database Driver Class Initialized
DEBUG - 2018-02-07 15:35:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:35:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:35:18 --> Helper loaded: form_helper
INFO - 2018-02-07 15:35:18 --> Form Validation Class Initialized
INFO - 2018-02-07 15:35:18 --> Controller Class Initialized
INFO - 2018-02-07 15:35:18 --> Model Class Initialized
INFO - 2018-02-07 15:35:18 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 15:35:18 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 15:35:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:35:18 --> Model Class Initialized
INFO - 2018-02-07 15:35:18 --> Model Class Initialized
INFO - 2018-02-07 15:35:18 --> Model Class Initialized
INFO - 2018-02-07 15:35:18 --> Model Class Initialized
INFO - 2018-02-07 15:35:18 --> Model Class Initialized
INFO - 2018-02-07 15:35:18 --> Model Class Initialized
INFO - 2018-02-07 15:35:18 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 15:35:18 --> Model Class Initialized
INFO - 2018-02-07 15:35:18 --> Final output sent to browser
DEBUG - 2018-02-07 15:35:18 --> Total execution time: 0.1218
INFO - 2018-02-07 10:05:50 --> Config Class Initialized
INFO - 2018-02-07 10:05:50 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:05:50 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:05:50 --> Utf8 Class Initialized
INFO - 2018-02-07 10:05:50 --> URI Class Initialized
INFO - 2018-02-07 10:05:50 --> Router Class Initialized
INFO - 2018-02-07 10:05:50 --> Output Class Initialized
INFO - 2018-02-07 10:05:50 --> Security Class Initialized
DEBUG - 2018-02-07 10:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:05:50 --> Input Class Initialized
INFO - 2018-02-07 10:05:50 --> Language Class Initialized
INFO - 2018-02-07 10:05:50 --> Language Class Initialized
INFO - 2018-02-07 10:05:50 --> Config Class Initialized
INFO - 2018-02-07 10:05:50 --> Loader Class Initialized
INFO - 2018-02-07 15:35:50 --> Helper loaded: url_helper
INFO - 2018-02-07 15:35:50 --> Helper loaded: notification_helper
INFO - 2018-02-07 15:35:50 --> Helper loaded: settings_helper
INFO - 2018-02-07 15:35:50 --> Helper loaded: permission_helper
INFO - 2018-02-07 15:35:50 --> Helper loaded: users_helper
INFO - 2018-02-07 15:35:50 --> Database Driver Class Initialized
DEBUG - 2018-02-07 15:35:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:35:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:35:50 --> Helper loaded: form_helper
INFO - 2018-02-07 15:35:50 --> Form Validation Class Initialized
INFO - 2018-02-07 15:35:50 --> Controller Class Initialized
INFO - 2018-02-07 15:35:50 --> Model Class Initialized
INFO - 2018-02-07 15:35:50 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 15:35:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 15:35:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:35:50 --> Model Class Initialized
INFO - 2018-02-07 15:35:50 --> Model Class Initialized
INFO - 2018-02-07 15:35:50 --> Model Class Initialized
INFO - 2018-02-07 15:35:50 --> Model Class Initialized
INFO - 2018-02-07 15:35:50 --> Model Class Initialized
INFO - 2018-02-07 15:35:50 --> Model Class Initialized
INFO - 2018-02-07 15:35:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 15:35:50 --> Final output sent to browser
DEBUG - 2018-02-07 15:35:50 --> Total execution time: 0.1215
INFO - 2018-02-07 10:06:01 --> Config Class Initialized
INFO - 2018-02-07 10:06:01 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:06:01 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:06:01 --> Utf8 Class Initialized
INFO - 2018-02-07 10:06:01 --> URI Class Initialized
INFO - 2018-02-07 10:06:01 --> Router Class Initialized
INFO - 2018-02-07 10:06:01 --> Output Class Initialized
INFO - 2018-02-07 10:06:01 --> Security Class Initialized
DEBUG - 2018-02-07 10:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:06:01 --> Input Class Initialized
INFO - 2018-02-07 10:06:01 --> Language Class Initialized
INFO - 2018-02-07 10:06:01 --> Language Class Initialized
INFO - 2018-02-07 10:06:01 --> Config Class Initialized
INFO - 2018-02-07 10:06:01 --> Loader Class Initialized
INFO - 2018-02-07 15:36:01 --> Helper loaded: url_helper
INFO - 2018-02-07 15:36:01 --> Helper loaded: notification_helper
INFO - 2018-02-07 15:36:01 --> Helper loaded: settings_helper
INFO - 2018-02-07 15:36:01 --> Helper loaded: permission_helper
INFO - 2018-02-07 15:36:01 --> Helper loaded: users_helper
INFO - 2018-02-07 15:36:02 --> Database Driver Class Initialized
DEBUG - 2018-02-07 15:36:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:36:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:36:02 --> Helper loaded: form_helper
INFO - 2018-02-07 15:36:02 --> Form Validation Class Initialized
INFO - 2018-02-07 15:36:02 --> Controller Class Initialized
INFO - 2018-02-07 15:36:02 --> Model Class Initialized
INFO - 2018-02-07 15:36:02 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 15:36:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 15:36:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:36:02 --> Model Class Initialized
INFO - 2018-02-07 15:36:02 --> Model Class Initialized
INFO - 2018-02-07 15:36:02 --> Model Class Initialized
INFO - 2018-02-07 15:36:02 --> Model Class Initialized
INFO - 2018-02-07 15:36:02 --> Model Class Initialized
INFO - 2018-02-07 15:36:02 --> Model Class Initialized
INFO - 2018-02-07 15:36:02 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-02-07 15:36:02 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 771
INFO - 2018-02-07 15:36:02 --> Final output sent to browser
DEBUG - 2018-02-07 15:36:02 --> Total execution time: 0.1148
INFO - 2018-02-07 10:06:19 --> Config Class Initialized
INFO - 2018-02-07 10:06:19 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:06:19 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:06:19 --> Utf8 Class Initialized
INFO - 2018-02-07 10:06:19 --> URI Class Initialized
INFO - 2018-02-07 10:06:19 --> Router Class Initialized
INFO - 2018-02-07 10:06:19 --> Output Class Initialized
INFO - 2018-02-07 10:06:19 --> Security Class Initialized
DEBUG - 2018-02-07 10:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:06:19 --> Input Class Initialized
INFO - 2018-02-07 10:06:19 --> Language Class Initialized
INFO - 2018-02-07 10:06:19 --> Language Class Initialized
INFO - 2018-02-07 10:06:19 --> Config Class Initialized
INFO - 2018-02-07 10:06:19 --> Loader Class Initialized
INFO - 2018-02-07 15:36:19 --> Helper loaded: url_helper
INFO - 2018-02-07 15:36:19 --> Helper loaded: notification_helper
INFO - 2018-02-07 15:36:19 --> Helper loaded: settings_helper
INFO - 2018-02-07 15:36:19 --> Helper loaded: permission_helper
INFO - 2018-02-07 15:36:19 --> Helper loaded: users_helper
INFO - 2018-02-07 15:36:19 --> Database Driver Class Initialized
DEBUG - 2018-02-07 15:36:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:36:19 --> Helper loaded: form_helper
INFO - 2018-02-07 15:36:19 --> Form Validation Class Initialized
INFO - 2018-02-07 15:36:19 --> Controller Class Initialized
INFO - 2018-02-07 15:36:19 --> Model Class Initialized
INFO - 2018-02-07 15:36:19 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 15:36:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 15:36:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:36:19 --> Model Class Initialized
INFO - 2018-02-07 15:36:19 --> Model Class Initialized
INFO - 2018-02-07 15:36:19 --> Model Class Initialized
INFO - 2018-02-07 15:36:19 --> Model Class Initialized
INFO - 2018-02-07 15:36:19 --> Model Class Initialized
INFO - 2018-02-07 15:36:19 --> Model Class Initialized
INFO - 2018-02-07 15:36:19 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-02-07 15:36:19 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 771
INFO - 2018-02-07 15:36:19 --> Final output sent to browser
DEBUG - 2018-02-07 15:36:19 --> Total execution time: 0.1211
INFO - 2018-02-07 10:06:32 --> Config Class Initialized
INFO - 2018-02-07 10:06:32 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:06:32 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:06:32 --> Utf8 Class Initialized
INFO - 2018-02-07 10:06:32 --> URI Class Initialized
INFO - 2018-02-07 10:06:32 --> Router Class Initialized
INFO - 2018-02-07 10:06:32 --> Output Class Initialized
INFO - 2018-02-07 10:06:32 --> Security Class Initialized
DEBUG - 2018-02-07 10:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:06:32 --> Input Class Initialized
INFO - 2018-02-07 10:06:32 --> Language Class Initialized
INFO - 2018-02-07 10:06:32 --> Language Class Initialized
INFO - 2018-02-07 10:06:32 --> Config Class Initialized
INFO - 2018-02-07 10:06:32 --> Loader Class Initialized
INFO - 2018-02-07 15:36:32 --> Helper loaded: url_helper
INFO - 2018-02-07 15:36:32 --> Helper loaded: notification_helper
INFO - 2018-02-07 15:36:32 --> Helper loaded: settings_helper
INFO - 2018-02-07 15:36:32 --> Helper loaded: permission_helper
INFO - 2018-02-07 15:36:32 --> Helper loaded: users_helper
INFO - 2018-02-07 15:36:32 --> Database Driver Class Initialized
DEBUG - 2018-02-07 15:36:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:36:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:36:32 --> Helper loaded: form_helper
INFO - 2018-02-07 15:36:32 --> Form Validation Class Initialized
INFO - 2018-02-07 15:36:32 --> Controller Class Initialized
INFO - 2018-02-07 15:36:32 --> Model Class Initialized
INFO - 2018-02-07 15:36:32 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 15:36:32 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 15:36:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:36:32 --> Model Class Initialized
INFO - 2018-02-07 15:36:32 --> Model Class Initialized
INFO - 2018-02-07 15:36:32 --> Model Class Initialized
INFO - 2018-02-07 15:36:32 --> Model Class Initialized
INFO - 2018-02-07 15:36:32 --> Model Class Initialized
INFO - 2018-02-07 15:36:32 --> Model Class Initialized
INFO - 2018-02-07 15:36:32 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 15:36:32 --> Model Class Initialized
INFO - 2018-02-07 15:36:32 --> Final output sent to browser
DEBUG - 2018-02-07 15:36:32 --> Total execution time: 0.1179
INFO - 2018-02-07 10:07:25 --> Config Class Initialized
INFO - 2018-02-07 10:07:25 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:07:25 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:07:25 --> Utf8 Class Initialized
INFO - 2018-02-07 10:07:25 --> URI Class Initialized
INFO - 2018-02-07 10:07:25 --> Router Class Initialized
INFO - 2018-02-07 10:07:25 --> Output Class Initialized
INFO - 2018-02-07 10:07:25 --> Security Class Initialized
DEBUG - 2018-02-07 10:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:07:25 --> Input Class Initialized
INFO - 2018-02-07 10:07:25 --> Language Class Initialized
INFO - 2018-02-07 10:07:25 --> Language Class Initialized
INFO - 2018-02-07 10:07:25 --> Config Class Initialized
INFO - 2018-02-07 10:07:25 --> Loader Class Initialized
INFO - 2018-02-07 15:37:25 --> Helper loaded: url_helper
INFO - 2018-02-07 15:37:25 --> Helper loaded: notification_helper
INFO - 2018-02-07 15:37:25 --> Helper loaded: settings_helper
INFO - 2018-02-07 15:37:25 --> Helper loaded: permission_helper
INFO - 2018-02-07 15:37:25 --> Helper loaded: users_helper
INFO - 2018-02-07 15:37:25 --> Database Driver Class Initialized
DEBUG - 2018-02-07 15:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:37:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:37:25 --> Helper loaded: form_helper
INFO - 2018-02-07 15:37:25 --> Form Validation Class Initialized
INFO - 2018-02-07 15:37:25 --> Controller Class Initialized
INFO - 2018-02-07 15:37:25 --> Model Class Initialized
INFO - 2018-02-07 15:37:25 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 15:37:25 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 15:37:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:37:25 --> Model Class Initialized
INFO - 2018-02-07 15:37:25 --> Model Class Initialized
INFO - 2018-02-07 15:37:25 --> Model Class Initialized
INFO - 2018-02-07 15:37:25 --> Model Class Initialized
INFO - 2018-02-07 15:37:25 --> Model Class Initialized
INFO - 2018-02-07 15:37:25 --> Model Class Initialized
INFO - 2018-02-07 15:37:25 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 15:37:25 --> Final output sent to browser
DEBUG - 2018-02-07 15:37:25 --> Total execution time: 0.1188
INFO - 2018-02-07 10:07:27 --> Config Class Initialized
INFO - 2018-02-07 10:07:27 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:07:27 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:07:27 --> Utf8 Class Initialized
INFO - 2018-02-07 10:07:27 --> URI Class Initialized
INFO - 2018-02-07 10:07:27 --> Router Class Initialized
INFO - 2018-02-07 10:07:27 --> Output Class Initialized
INFO - 2018-02-07 10:07:27 --> Security Class Initialized
DEBUG - 2018-02-07 10:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:07:27 --> Input Class Initialized
INFO - 2018-02-07 10:07:27 --> Language Class Initialized
INFO - 2018-02-07 10:07:27 --> Language Class Initialized
INFO - 2018-02-07 10:07:27 --> Config Class Initialized
INFO - 2018-02-07 10:07:27 --> Loader Class Initialized
INFO - 2018-02-07 15:37:27 --> Helper loaded: url_helper
INFO - 2018-02-07 15:37:27 --> Helper loaded: notification_helper
INFO - 2018-02-07 15:37:27 --> Helper loaded: settings_helper
INFO - 2018-02-07 15:37:27 --> Helper loaded: permission_helper
INFO - 2018-02-07 15:37:27 --> Helper loaded: users_helper
INFO - 2018-02-07 15:37:27 --> Database Driver Class Initialized
DEBUG - 2018-02-07 15:37:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:37:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:37:27 --> Helper loaded: form_helper
INFO - 2018-02-07 15:37:27 --> Form Validation Class Initialized
INFO - 2018-02-07 15:37:27 --> Controller Class Initialized
INFO - 2018-02-07 15:37:27 --> Model Class Initialized
INFO - 2018-02-07 15:37:27 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 15:37:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 15:37:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:37:27 --> Model Class Initialized
INFO - 2018-02-07 15:37:27 --> Model Class Initialized
INFO - 2018-02-07 15:37:27 --> Model Class Initialized
INFO - 2018-02-07 15:37:27 --> Model Class Initialized
INFO - 2018-02-07 15:37:27 --> Model Class Initialized
INFO - 2018-02-07 15:37:27 --> Model Class Initialized
INFO - 2018-02-07 15:37:27 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 15:37:27 --> Model Class Initialized
INFO - 2018-02-07 15:37:27 --> Final output sent to browser
DEBUG - 2018-02-07 15:37:27 --> Total execution time: 0.1091
INFO - 2018-02-07 10:14:14 --> Config Class Initialized
INFO - 2018-02-07 10:14:14 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:14:14 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:14:14 --> Utf8 Class Initialized
INFO - 2018-02-07 10:14:14 --> URI Class Initialized
INFO - 2018-02-07 10:14:14 --> Router Class Initialized
INFO - 2018-02-07 10:14:14 --> Output Class Initialized
INFO - 2018-02-07 10:14:14 --> Security Class Initialized
DEBUG - 2018-02-07 10:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:14:14 --> Input Class Initialized
INFO - 2018-02-07 10:14:14 --> Language Class Initialized
INFO - 2018-02-07 10:14:14 --> Language Class Initialized
INFO - 2018-02-07 10:14:14 --> Config Class Initialized
INFO - 2018-02-07 10:14:14 --> Loader Class Initialized
INFO - 2018-02-07 15:44:14 --> Helper loaded: url_helper
INFO - 2018-02-07 15:44:14 --> Helper loaded: notification_helper
INFO - 2018-02-07 15:44:14 --> Helper loaded: settings_helper
INFO - 2018-02-07 15:44:14 --> Helper loaded: permission_helper
INFO - 2018-02-07 15:44:14 --> Helper loaded: users_helper
INFO - 2018-02-07 15:44:14 --> Database Driver Class Initialized
DEBUG - 2018-02-07 15:44:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:44:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:44:14 --> Helper loaded: form_helper
INFO - 2018-02-07 15:44:14 --> Form Validation Class Initialized
INFO - 2018-02-07 15:44:14 --> Controller Class Initialized
INFO - 2018-02-07 15:44:14 --> Model Class Initialized
INFO - 2018-02-07 15:44:14 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 15:44:14 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 15:44:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:44:14 --> Model Class Initialized
INFO - 2018-02-07 15:44:14 --> Model Class Initialized
INFO - 2018-02-07 15:44:14 --> Model Class Initialized
INFO - 2018-02-07 15:44:14 --> Model Class Initialized
INFO - 2018-02-07 15:44:14 --> Model Class Initialized
INFO - 2018-02-07 15:44:14 --> Model Class Initialized
INFO - 2018-02-07 15:44:14 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 15:44:14 --> Final output sent to browser
DEBUG - 2018-02-07 15:44:14 --> Total execution time: 0.1192
INFO - 2018-02-07 10:14:31 --> Config Class Initialized
INFO - 2018-02-07 10:14:31 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:14:31 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:14:31 --> Utf8 Class Initialized
INFO - 2018-02-07 10:14:31 --> URI Class Initialized
INFO - 2018-02-07 10:14:31 --> Router Class Initialized
INFO - 2018-02-07 10:14:31 --> Output Class Initialized
INFO - 2018-02-07 10:14:31 --> Security Class Initialized
DEBUG - 2018-02-07 10:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:14:31 --> Input Class Initialized
INFO - 2018-02-07 10:14:31 --> Language Class Initialized
INFO - 2018-02-07 10:14:31 --> Language Class Initialized
INFO - 2018-02-07 10:14:31 --> Config Class Initialized
INFO - 2018-02-07 10:14:31 --> Loader Class Initialized
INFO - 2018-02-07 15:44:31 --> Helper loaded: url_helper
INFO - 2018-02-07 15:44:31 --> Helper loaded: notification_helper
INFO - 2018-02-07 15:44:31 --> Helper loaded: settings_helper
INFO - 2018-02-07 15:44:31 --> Helper loaded: permission_helper
INFO - 2018-02-07 15:44:31 --> Helper loaded: users_helper
INFO - 2018-02-07 15:44:31 --> Database Driver Class Initialized
DEBUG - 2018-02-07 15:44:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:44:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:44:31 --> Helper loaded: form_helper
INFO - 2018-02-07 15:44:31 --> Form Validation Class Initialized
INFO - 2018-02-07 15:44:31 --> Controller Class Initialized
INFO - 2018-02-07 15:44:31 --> Model Class Initialized
INFO - 2018-02-07 15:44:31 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 15:44:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 15:44:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:44:31 --> Model Class Initialized
INFO - 2018-02-07 15:44:31 --> Model Class Initialized
INFO - 2018-02-07 15:44:31 --> Model Class Initialized
INFO - 2018-02-07 15:44:31 --> Model Class Initialized
INFO - 2018-02-07 15:44:31 --> Model Class Initialized
INFO - 2018-02-07 15:44:31 --> Model Class Initialized
INFO - 2018-02-07 15:44:31 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 15:44:31 --> Model Class Initialized
INFO - 2018-02-07 15:44:32 --> Final output sent to browser
DEBUG - 2018-02-07 15:44:32 --> Total execution time: 0.1109
INFO - 2018-02-07 10:14:32 --> Config Class Initialized
INFO - 2018-02-07 10:14:32 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:14:32 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:14:32 --> Utf8 Class Initialized
INFO - 2018-02-07 10:14:32 --> URI Class Initialized
INFO - 2018-02-07 10:14:32 --> Router Class Initialized
INFO - 2018-02-07 10:14:32 --> Output Class Initialized
INFO - 2018-02-07 10:14:32 --> Security Class Initialized
DEBUG - 2018-02-07 10:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:14:32 --> Input Class Initialized
INFO - 2018-02-07 10:14:32 --> Language Class Initialized
INFO - 2018-02-07 10:14:32 --> Language Class Initialized
INFO - 2018-02-07 10:14:32 --> Config Class Initialized
INFO - 2018-02-07 10:14:32 --> Loader Class Initialized
INFO - 2018-02-07 15:44:32 --> Helper loaded: url_helper
INFO - 2018-02-07 15:44:32 --> Helper loaded: notification_helper
INFO - 2018-02-07 15:44:32 --> Helper loaded: settings_helper
INFO - 2018-02-07 15:44:32 --> Helper loaded: permission_helper
INFO - 2018-02-07 15:44:32 --> Helper loaded: users_helper
INFO - 2018-02-07 15:44:32 --> Database Driver Class Initialized
DEBUG - 2018-02-07 15:44:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:44:32 --> Helper loaded: form_helper
INFO - 2018-02-07 15:44:32 --> Form Validation Class Initialized
INFO - 2018-02-07 15:44:32 --> Controller Class Initialized
DEBUG - 2018-02-07 15:44:32 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-02-07 15:44:32 --> Final output sent to browser
DEBUG - 2018-02-07 15:44:32 --> Total execution time: 0.0962
INFO - 2018-02-07 10:21:41 --> Config Class Initialized
INFO - 2018-02-07 10:21:41 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:21:41 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:21:41 --> Utf8 Class Initialized
INFO - 2018-02-07 10:21:41 --> URI Class Initialized
INFO - 2018-02-07 10:21:41 --> Router Class Initialized
INFO - 2018-02-07 10:21:41 --> Output Class Initialized
INFO - 2018-02-07 10:21:41 --> Security Class Initialized
DEBUG - 2018-02-07 10:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:21:41 --> Input Class Initialized
INFO - 2018-02-07 10:21:41 --> Language Class Initialized
INFO - 2018-02-07 10:21:41 --> Language Class Initialized
INFO - 2018-02-07 10:21:41 --> Config Class Initialized
INFO - 2018-02-07 10:21:41 --> Loader Class Initialized
INFO - 2018-02-07 15:51:41 --> Helper loaded: url_helper
INFO - 2018-02-07 15:51:41 --> Helper loaded: notification_helper
INFO - 2018-02-07 15:51:41 --> Helper loaded: settings_helper
INFO - 2018-02-07 15:51:41 --> Helper loaded: permission_helper
INFO - 2018-02-07 15:51:41 --> Helper loaded: users_helper
INFO - 2018-02-07 15:51:41 --> Database Driver Class Initialized
DEBUG - 2018-02-07 15:51:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:51:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:51:41 --> Helper loaded: form_helper
INFO - 2018-02-07 15:51:41 --> Form Validation Class Initialized
INFO - 2018-02-07 15:51:41 --> Controller Class Initialized
INFO - 2018-02-07 15:51:41 --> Model Class Initialized
INFO - 2018-02-07 15:51:41 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 15:51:41 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 15:51:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:51:41 --> Model Class Initialized
INFO - 2018-02-07 15:51:41 --> Model Class Initialized
INFO - 2018-02-07 15:51:41 --> Model Class Initialized
INFO - 2018-02-07 15:51:41 --> Model Class Initialized
INFO - 2018-02-07 15:51:41 --> Model Class Initialized
INFO - 2018-02-07 15:51:41 --> Model Class Initialized
INFO - 2018-02-07 15:51:41 --> Model Class Initialized
INFO - 2018-02-07 15:51:41 --> Model Class Initialized
INFO - 2018-02-07 15:51:41 --> Model Class Initialized
INFO - 2018-02-07 15:51:41 --> Model Class Initialized
INFO - 2018-02-07 15:51:41 --> Model Class Initialized
INFO - 2018-02-07 15:51:41 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 15:51:41 --> Model Class Initialized
INFO - 2018-02-07 15:51:41 --> Final output sent to browser
DEBUG - 2018-02-07 15:51:41 --> Total execution time: 0.1491
INFO - 2018-02-07 10:21:41 --> Config Class Initialized
INFO - 2018-02-07 10:21:41 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:21:41 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:21:41 --> Utf8 Class Initialized
INFO - 2018-02-07 10:21:41 --> URI Class Initialized
INFO - 2018-02-07 10:21:41 --> Router Class Initialized
INFO - 2018-02-07 10:21:41 --> Output Class Initialized
INFO - 2018-02-07 10:21:41 --> Security Class Initialized
DEBUG - 2018-02-07 10:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:21:41 --> Input Class Initialized
INFO - 2018-02-07 10:21:41 --> Language Class Initialized
INFO - 2018-02-07 10:21:41 --> Language Class Initialized
INFO - 2018-02-07 10:21:41 --> Config Class Initialized
INFO - 2018-02-07 10:21:41 --> Loader Class Initialized
INFO - 2018-02-07 15:51:41 --> Helper loaded: url_helper
INFO - 2018-02-07 15:51:41 --> Helper loaded: notification_helper
INFO - 2018-02-07 15:51:41 --> Helper loaded: settings_helper
INFO - 2018-02-07 15:51:41 --> Helper loaded: permission_helper
INFO - 2018-02-07 15:51:41 --> Helper loaded: users_helper
INFO - 2018-02-07 15:51:41 --> Database Driver Class Initialized
DEBUG - 2018-02-07 15:51:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:51:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:51:41 --> Helper loaded: form_helper
INFO - 2018-02-07 15:51:41 --> Form Validation Class Initialized
INFO - 2018-02-07 15:51:41 --> Controller Class Initialized
INFO - 2018-02-07 15:51:41 --> Model Class Initialized
INFO - 2018-02-07 15:51:41 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 15:51:41 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 15:51:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:51:41 --> Model Class Initialized
INFO - 2018-02-07 15:51:41 --> Model Class Initialized
INFO - 2018-02-07 15:51:41 --> Model Class Initialized
INFO - 2018-02-07 15:51:41 --> Model Class Initialized
INFO - 2018-02-07 15:51:41 --> Model Class Initialized
INFO - 2018-02-07 15:51:41 --> Model Class Initialized
INFO - 2018-02-07 15:51:41 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 15:51:41 --> Model Class Initialized
INFO - 2018-02-07 15:51:41 --> Final output sent to browser
DEBUG - 2018-02-07 15:51:41 --> Total execution time: 0.0880
INFO - 2018-02-07 10:21:56 --> Config Class Initialized
INFO - 2018-02-07 10:21:56 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:21:56 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:21:56 --> Utf8 Class Initialized
INFO - 2018-02-07 10:21:56 --> URI Class Initialized
INFO - 2018-02-07 10:21:56 --> Router Class Initialized
INFO - 2018-02-07 10:21:56 --> Output Class Initialized
INFO - 2018-02-07 10:21:56 --> Security Class Initialized
DEBUG - 2018-02-07 10:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:21:56 --> Input Class Initialized
INFO - 2018-02-07 10:21:56 --> Language Class Initialized
INFO - 2018-02-07 10:21:56 --> Language Class Initialized
INFO - 2018-02-07 10:21:56 --> Config Class Initialized
INFO - 2018-02-07 10:21:56 --> Loader Class Initialized
INFO - 2018-02-07 15:51:56 --> Helper loaded: url_helper
INFO - 2018-02-07 15:51:56 --> Helper loaded: notification_helper
INFO - 2018-02-07 15:51:56 --> Helper loaded: settings_helper
INFO - 2018-02-07 15:51:56 --> Helper loaded: permission_helper
INFO - 2018-02-07 15:51:56 --> Helper loaded: users_helper
INFO - 2018-02-07 15:51:56 --> Database Driver Class Initialized
DEBUG - 2018-02-07 15:51:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:51:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:51:56 --> Helper loaded: form_helper
INFO - 2018-02-07 15:51:56 --> Form Validation Class Initialized
INFO - 2018-02-07 15:51:56 --> Controller Class Initialized
INFO - 2018-02-07 15:51:56 --> Model Class Initialized
INFO - 2018-02-07 15:51:56 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 15:51:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 15:51:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:51:56 --> Model Class Initialized
INFO - 2018-02-07 15:51:56 --> Model Class Initialized
INFO - 2018-02-07 15:51:56 --> Model Class Initialized
INFO - 2018-02-07 15:51:56 --> Model Class Initialized
INFO - 2018-02-07 15:51:56 --> Model Class Initialized
INFO - 2018-02-07 15:51:56 --> Model Class Initialized
INFO - 2018-02-07 15:51:56 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 15:51:56 --> Final output sent to browser
DEBUG - 2018-02-07 15:51:56 --> Total execution time: 0.1085
INFO - 2018-02-07 10:21:57 --> Config Class Initialized
INFO - 2018-02-07 10:21:57 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:21:57 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:21:57 --> Utf8 Class Initialized
INFO - 2018-02-07 10:21:57 --> URI Class Initialized
INFO - 2018-02-07 10:21:57 --> Router Class Initialized
INFO - 2018-02-07 10:21:57 --> Output Class Initialized
INFO - 2018-02-07 10:21:57 --> Security Class Initialized
DEBUG - 2018-02-07 10:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:21:57 --> Input Class Initialized
INFO - 2018-02-07 10:21:57 --> Language Class Initialized
INFO - 2018-02-07 10:21:57 --> Language Class Initialized
INFO - 2018-02-07 10:21:57 --> Config Class Initialized
INFO - 2018-02-07 10:21:57 --> Loader Class Initialized
INFO - 2018-02-07 15:51:57 --> Helper loaded: url_helper
INFO - 2018-02-07 15:51:57 --> Helper loaded: notification_helper
INFO - 2018-02-07 15:51:57 --> Helper loaded: settings_helper
INFO - 2018-02-07 15:51:57 --> Helper loaded: permission_helper
INFO - 2018-02-07 15:51:57 --> Helper loaded: users_helper
INFO - 2018-02-07 15:51:57 --> Database Driver Class Initialized
DEBUG - 2018-02-07 15:51:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:51:57 --> Helper loaded: form_helper
INFO - 2018-02-07 15:51:57 --> Form Validation Class Initialized
INFO - 2018-02-07 15:51:57 --> Controller Class Initialized
INFO - 2018-02-07 15:51:57 --> Model Class Initialized
INFO - 2018-02-07 15:51:57 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 15:51:57 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 15:51:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:51:57 --> Model Class Initialized
INFO - 2018-02-07 15:51:57 --> Model Class Initialized
INFO - 2018-02-07 15:51:57 --> Model Class Initialized
INFO - 2018-02-07 15:51:57 --> Model Class Initialized
INFO - 2018-02-07 15:51:57 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 15:51:57 --> Final output sent to browser
DEBUG - 2018-02-07 15:51:57 --> Total execution time: 0.1166
INFO - 2018-02-07 10:22:02 --> Config Class Initialized
INFO - 2018-02-07 10:22:02 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:22:02 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:22:02 --> Utf8 Class Initialized
INFO - 2018-02-07 10:22:02 --> URI Class Initialized
INFO - 2018-02-07 10:22:02 --> Router Class Initialized
INFO - 2018-02-07 10:22:02 --> Output Class Initialized
INFO - 2018-02-07 10:22:02 --> Security Class Initialized
DEBUG - 2018-02-07 10:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:22:02 --> Input Class Initialized
INFO - 2018-02-07 10:22:02 --> Language Class Initialized
INFO - 2018-02-07 10:22:02 --> Language Class Initialized
INFO - 2018-02-07 10:22:02 --> Config Class Initialized
INFO - 2018-02-07 10:22:02 --> Loader Class Initialized
INFO - 2018-02-07 15:52:02 --> Helper loaded: url_helper
INFO - 2018-02-07 15:52:02 --> Helper loaded: notification_helper
INFO - 2018-02-07 15:52:02 --> Helper loaded: settings_helper
INFO - 2018-02-07 15:52:02 --> Helper loaded: permission_helper
INFO - 2018-02-07 15:52:02 --> Helper loaded: users_helper
INFO - 2018-02-07 15:52:02 --> Database Driver Class Initialized
DEBUG - 2018-02-07 15:52:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:52:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:52:02 --> Helper loaded: form_helper
INFO - 2018-02-07 15:52:02 --> Form Validation Class Initialized
INFO - 2018-02-07 15:52:02 --> Controller Class Initialized
INFO - 2018-02-07 15:52:02 --> Model Class Initialized
INFO - 2018-02-07 15:52:02 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 15:52:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 15:52:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:52:02 --> Model Class Initialized
INFO - 2018-02-07 15:52:02 --> Model Class Initialized
INFO - 2018-02-07 15:52:02 --> Model Class Initialized
INFO - 2018-02-07 15:52:02 --> Model Class Initialized
INFO - 2018-02-07 15:52:02 --> Model Class Initialized
INFO - 2018-02-07 15:52:02 --> Model Class Initialized
INFO - 2018-02-07 15:52:02 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 15:52:02 --> Model Class Initialized
INFO - 2018-02-07 15:52:02 --> Final output sent to browser
DEBUG - 2018-02-07 15:52:02 --> Total execution time: 0.1173
INFO - 2018-02-07 10:26:13 --> Config Class Initialized
INFO - 2018-02-07 10:26:13 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:26:13 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:26:13 --> Utf8 Class Initialized
INFO - 2018-02-07 10:26:13 --> URI Class Initialized
INFO - 2018-02-07 10:26:13 --> Router Class Initialized
INFO - 2018-02-07 10:26:13 --> Output Class Initialized
INFO - 2018-02-07 10:26:13 --> Security Class Initialized
DEBUG - 2018-02-07 10:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:26:13 --> Input Class Initialized
INFO - 2018-02-07 10:26:13 --> Language Class Initialized
INFO - 2018-02-07 10:26:13 --> Language Class Initialized
INFO - 2018-02-07 10:26:13 --> Config Class Initialized
INFO - 2018-02-07 10:26:13 --> Loader Class Initialized
INFO - 2018-02-07 15:56:13 --> Helper loaded: url_helper
INFO - 2018-02-07 15:56:13 --> Helper loaded: notification_helper
INFO - 2018-02-07 15:56:13 --> Helper loaded: settings_helper
INFO - 2018-02-07 15:56:13 --> Helper loaded: permission_helper
INFO - 2018-02-07 15:56:13 --> Helper loaded: users_helper
INFO - 2018-02-07 15:56:13 --> Database Driver Class Initialized
DEBUG - 2018-02-07 15:56:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:56:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:56:13 --> Helper loaded: form_helper
INFO - 2018-02-07 15:56:13 --> Form Validation Class Initialized
INFO - 2018-02-07 15:56:13 --> Controller Class Initialized
INFO - 2018-02-07 15:56:13 --> Model Class Initialized
INFO - 2018-02-07 15:56:13 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 15:56:13 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 15:56:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:56:13 --> Model Class Initialized
INFO - 2018-02-07 15:56:13 --> Model Class Initialized
INFO - 2018-02-07 15:56:13 --> Model Class Initialized
INFO - 2018-02-07 15:56:13 --> Model Class Initialized
INFO - 2018-02-07 15:56:13 --> Model Class Initialized
INFO - 2018-02-07 15:56:13 --> Model Class Initialized
INFO - 2018-02-07 15:56:13 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 15:56:13 --> Model Class Initialized
INFO - 2018-02-07 15:56:13 --> Final output sent to browser
DEBUG - 2018-02-07 15:56:13 --> Total execution time: 0.1161
INFO - 2018-02-07 10:27:02 --> Config Class Initialized
INFO - 2018-02-07 10:27:02 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:27:02 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:27:02 --> Utf8 Class Initialized
INFO - 2018-02-07 10:27:02 --> URI Class Initialized
INFO - 2018-02-07 10:27:02 --> Router Class Initialized
INFO - 2018-02-07 10:27:02 --> Output Class Initialized
INFO - 2018-02-07 10:27:02 --> Security Class Initialized
DEBUG - 2018-02-07 10:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:27:02 --> Input Class Initialized
INFO - 2018-02-07 10:27:02 --> Language Class Initialized
INFO - 2018-02-07 10:27:02 --> Language Class Initialized
INFO - 2018-02-07 10:27:02 --> Config Class Initialized
INFO - 2018-02-07 10:27:02 --> Loader Class Initialized
INFO - 2018-02-07 15:57:02 --> Helper loaded: url_helper
INFO - 2018-02-07 15:57:02 --> Helper loaded: notification_helper
INFO - 2018-02-07 15:57:02 --> Helper loaded: settings_helper
INFO - 2018-02-07 15:57:02 --> Helper loaded: permission_helper
INFO - 2018-02-07 15:57:02 --> Helper loaded: users_helper
INFO - 2018-02-07 15:57:02 --> Database Driver Class Initialized
DEBUG - 2018-02-07 15:57:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 15:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 15:57:02 --> Helper loaded: form_helper
INFO - 2018-02-07 15:57:02 --> Form Validation Class Initialized
INFO - 2018-02-07 15:57:02 --> Controller Class Initialized
INFO - 2018-02-07 15:57:02 --> Model Class Initialized
INFO - 2018-02-07 15:57:02 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 15:57:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 15:57:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 15:57:02 --> Model Class Initialized
INFO - 2018-02-07 15:57:02 --> Model Class Initialized
INFO - 2018-02-07 15:57:02 --> Model Class Initialized
INFO - 2018-02-07 15:57:02 --> Model Class Initialized
INFO - 2018-02-07 15:57:02 --> Model Class Initialized
INFO - 2018-02-07 15:57:02 --> Model Class Initialized
INFO - 2018-02-07 15:57:02 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 15:57:02 --> Model Class Initialized
INFO - 2018-02-07 15:57:02 --> Final output sent to browser
DEBUG - 2018-02-07 15:57:02 --> Total execution time: 0.1223
INFO - 2018-02-07 10:36:23 --> Config Class Initialized
INFO - 2018-02-07 10:36:23 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:36:23 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:36:23 --> Utf8 Class Initialized
INFO - 2018-02-07 10:36:23 --> URI Class Initialized
INFO - 2018-02-07 10:36:23 --> Router Class Initialized
INFO - 2018-02-07 10:36:23 --> Output Class Initialized
INFO - 2018-02-07 10:36:23 --> Security Class Initialized
DEBUG - 2018-02-07 10:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:36:23 --> Input Class Initialized
INFO - 2018-02-07 10:36:23 --> Language Class Initialized
INFO - 2018-02-07 10:36:23 --> Language Class Initialized
INFO - 2018-02-07 10:36:23 --> Config Class Initialized
INFO - 2018-02-07 10:36:23 --> Loader Class Initialized
INFO - 2018-02-07 16:06:23 --> Helper loaded: url_helper
INFO - 2018-02-07 16:06:23 --> Helper loaded: notification_helper
INFO - 2018-02-07 16:06:23 --> Helper loaded: settings_helper
INFO - 2018-02-07 16:06:23 --> Helper loaded: permission_helper
INFO - 2018-02-07 16:06:23 --> Helper loaded: users_helper
INFO - 2018-02-07 16:06:23 --> Database Driver Class Initialized
DEBUG - 2018-02-07 16:06:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 16:06:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 16:06:23 --> Helper loaded: form_helper
INFO - 2018-02-07 16:06:23 --> Form Validation Class Initialized
INFO - 2018-02-07 16:06:23 --> Controller Class Initialized
INFO - 2018-02-07 16:06:23 --> Model Class Initialized
INFO - 2018-02-07 16:06:23 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 16:06:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 16:06:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 16:06:23 --> Model Class Initialized
INFO - 2018-02-07 16:06:23 --> Model Class Initialized
INFO - 2018-02-07 16:06:23 --> Model Class Initialized
INFO - 2018-02-07 16:06:23 --> Model Class Initialized
INFO - 2018-02-07 16:06:23 --> Model Class Initialized
INFO - 2018-02-07 16:06:23 --> Model Class Initialized
INFO - 2018-02-07 16:06:23 --> Model Class Initialized
INFO - 2018-02-07 16:06:23 --> Model Class Initialized
INFO - 2018-02-07 16:06:23 --> Model Class Initialized
INFO - 2018-02-07 16:06:23 --> Model Class Initialized
INFO - 2018-02-07 16:06:23 --> Model Class Initialized
INFO - 2018-02-07 16:06:23 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 16:06:23 --> Model Class Initialized
INFO - 2018-02-07 16:06:23 --> Final output sent to browser
DEBUG - 2018-02-07 16:06:23 --> Total execution time: 0.1246
INFO - 2018-02-07 10:36:27 --> Config Class Initialized
INFO - 2018-02-07 10:36:27 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:36:27 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:36:27 --> Utf8 Class Initialized
INFO - 2018-02-07 10:36:27 --> URI Class Initialized
INFO - 2018-02-07 10:36:27 --> Router Class Initialized
INFO - 2018-02-07 10:36:27 --> Output Class Initialized
INFO - 2018-02-07 10:36:27 --> Security Class Initialized
DEBUG - 2018-02-07 10:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:36:27 --> Input Class Initialized
INFO - 2018-02-07 10:36:27 --> Language Class Initialized
INFO - 2018-02-07 10:36:27 --> Language Class Initialized
INFO - 2018-02-07 10:36:27 --> Config Class Initialized
INFO - 2018-02-07 10:36:27 --> Loader Class Initialized
INFO - 2018-02-07 16:06:27 --> Helper loaded: url_helper
INFO - 2018-02-07 16:06:27 --> Helper loaded: notification_helper
INFO - 2018-02-07 16:06:27 --> Helper loaded: settings_helper
INFO - 2018-02-07 16:06:27 --> Helper loaded: permission_helper
INFO - 2018-02-07 16:06:27 --> Helper loaded: users_helper
INFO - 2018-02-07 16:06:27 --> Database Driver Class Initialized
DEBUG - 2018-02-07 16:06:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 16:06:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 16:06:27 --> Helper loaded: form_helper
INFO - 2018-02-07 16:06:27 --> Form Validation Class Initialized
INFO - 2018-02-07 16:06:27 --> Controller Class Initialized
INFO - 2018-02-07 16:06:27 --> Model Class Initialized
INFO - 2018-02-07 16:06:27 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 16:06:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 16:06:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 16:06:27 --> Model Class Initialized
INFO - 2018-02-07 16:06:27 --> Model Class Initialized
INFO - 2018-02-07 16:06:27 --> Model Class Initialized
INFO - 2018-02-07 16:06:27 --> Model Class Initialized
INFO - 2018-02-07 16:06:27 --> Model Class Initialized
INFO - 2018-02-07 16:06:27 --> Model Class Initialized
INFO - 2018-02-07 16:06:27 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 16:06:27 --> Model Class Initialized
INFO - 2018-02-07 16:06:27 --> Final output sent to browser
DEBUG - 2018-02-07 16:06:27 --> Total execution time: 0.1016
INFO - 2018-02-07 10:38:45 --> Config Class Initialized
INFO - 2018-02-07 10:38:45 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:38:45 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:38:45 --> Utf8 Class Initialized
INFO - 2018-02-07 10:38:45 --> URI Class Initialized
INFO - 2018-02-07 10:38:45 --> Router Class Initialized
INFO - 2018-02-07 10:38:45 --> Output Class Initialized
INFO - 2018-02-07 10:38:45 --> Security Class Initialized
DEBUG - 2018-02-07 10:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:38:45 --> Input Class Initialized
INFO - 2018-02-07 10:38:45 --> Language Class Initialized
INFO - 2018-02-07 10:38:45 --> Language Class Initialized
INFO - 2018-02-07 10:38:45 --> Config Class Initialized
INFO - 2018-02-07 10:38:45 --> Loader Class Initialized
INFO - 2018-02-07 16:08:45 --> Helper loaded: url_helper
INFO - 2018-02-07 16:08:45 --> Helper loaded: notification_helper
INFO - 2018-02-07 16:08:45 --> Helper loaded: settings_helper
INFO - 2018-02-07 16:08:45 --> Helper loaded: permission_helper
INFO - 2018-02-07 16:08:45 --> Helper loaded: users_helper
INFO - 2018-02-07 10:38:45 --> Config Class Initialized
INFO - 2018-02-07 10:38:45 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:38:45 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:38:45 --> Utf8 Class Initialized
INFO - 2018-02-07 10:38:45 --> URI Class Initialized
INFO - 2018-02-07 10:38:45 --> Router Class Initialized
INFO - 2018-02-07 10:38:45 --> Output Class Initialized
INFO - 2018-02-07 16:08:45 --> Database Driver Class Initialized
INFO - 2018-02-07 10:38:45 --> Security Class Initialized
DEBUG - 2018-02-07 10:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:38:45 --> Input Class Initialized
INFO - 2018-02-07 10:38:45 --> Language Class Initialized
DEBUG - 2018-02-07 16:08:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 16:08:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 16:08:45 --> Helper loaded: form_helper
INFO - 2018-02-07 16:08:45 --> Form Validation Class Initialized
INFO - 2018-02-07 16:08:45 --> Controller Class Initialized
INFO - 2018-02-07 16:08:45 --> Model Class Initialized
INFO - 2018-02-07 16:08:45 --> Helper loaded: inflector_helper
INFO - 2018-02-07 10:38:45 --> Language Class Initialized
INFO - 2018-02-07 10:38:45 --> Config Class Initialized
INFO - 2018-02-07 10:38:45 --> Loader Class Initialized
DEBUG - 2018-02-07 16:08:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 16:08:45 --> Helper loaded: url_helper
INFO - 2018-02-07 16:08:45 --> Helper loaded: notification_helper
INFO - 2018-02-07 16:08:45 --> Helper loaded: settings_helper
INFO - 2018-02-07 16:08:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 16:08:45 --> Helper loaded: permission_helper
INFO - 2018-02-07 16:08:45 --> Model Class Initialized
INFO - 2018-02-07 16:08:45 --> Model Class Initialized
INFO - 2018-02-07 16:08:45 --> Helper loaded: users_helper
INFO - 2018-02-07 16:08:45 --> Model Class Initialized
INFO - 2018-02-07 16:08:45 --> Model Class Initialized
INFO - 2018-02-07 16:08:45 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 16:08:45 --> Final output sent to browser
DEBUG - 2018-02-07 16:08:45 --> Total execution time: 0.1021
INFO - 2018-02-07 16:08:45 --> Database Driver Class Initialized
DEBUG - 2018-02-07 16:08:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 16:08:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 16:08:45 --> Helper loaded: form_helper
INFO - 2018-02-07 16:08:45 --> Form Validation Class Initialized
INFO - 2018-02-07 16:08:45 --> Controller Class Initialized
INFO - 2018-02-07 16:08:45 --> Model Class Initialized
INFO - 2018-02-07 16:08:45 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 16:08:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 16:08:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 16:08:45 --> Model Class Initialized
INFO - 2018-02-07 16:08:45 --> Model Class Initialized
INFO - 2018-02-07 16:08:45 --> Model Class Initialized
INFO - 2018-02-07 16:08:45 --> Model Class Initialized
INFO - 2018-02-07 16:08:45 --> Model Class Initialized
INFO - 2018-02-07 16:08:45 --> Model Class Initialized
INFO - 2018-02-07 16:08:45 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 16:08:45 --> Final output sent to browser
DEBUG - 2018-02-07 16:08:45 --> Total execution time: 0.1182
INFO - 2018-02-07 10:38:48 --> Config Class Initialized
INFO - 2018-02-07 10:38:48 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:38:48 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:38:48 --> Utf8 Class Initialized
INFO - 2018-02-07 10:38:48 --> URI Class Initialized
INFO - 2018-02-07 10:38:48 --> Router Class Initialized
INFO - 2018-02-07 10:38:48 --> Output Class Initialized
INFO - 2018-02-07 10:38:48 --> Security Class Initialized
DEBUG - 2018-02-07 10:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:38:48 --> Input Class Initialized
INFO - 2018-02-07 10:38:48 --> Language Class Initialized
INFO - 2018-02-07 10:38:48 --> Language Class Initialized
INFO - 2018-02-07 10:38:48 --> Config Class Initialized
INFO - 2018-02-07 10:38:48 --> Loader Class Initialized
INFO - 2018-02-07 16:08:48 --> Helper loaded: url_helper
INFO - 2018-02-07 16:08:48 --> Helper loaded: notification_helper
INFO - 2018-02-07 16:08:48 --> Helper loaded: settings_helper
INFO - 2018-02-07 16:08:48 --> Helper loaded: permission_helper
INFO - 2018-02-07 16:08:48 --> Helper loaded: users_helper
INFO - 2018-02-07 16:08:49 --> Database Driver Class Initialized
DEBUG - 2018-02-07 16:08:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 16:08:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 16:08:49 --> Helper loaded: form_helper
INFO - 2018-02-07 16:08:49 --> Form Validation Class Initialized
INFO - 2018-02-07 16:08:49 --> Controller Class Initialized
INFO - 2018-02-07 16:08:49 --> Model Class Initialized
INFO - 2018-02-07 16:08:49 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 16:08:49 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 16:08:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 16:08:49 --> Model Class Initialized
INFO - 2018-02-07 16:08:49 --> Model Class Initialized
INFO - 2018-02-07 16:08:49 --> Model Class Initialized
INFO - 2018-02-07 16:08:49 --> Model Class Initialized
INFO - 2018-02-07 16:08:49 --> Model Class Initialized
INFO - 2018-02-07 16:08:49 --> Model Class Initialized
INFO - 2018-02-07 16:08:49 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 16:08:49 --> Model Class Initialized
INFO - 2018-02-07 16:08:49 --> Final output sent to browser
DEBUG - 2018-02-07 16:08:49 --> Total execution time: 0.1241
INFO - 2018-02-07 10:39:04 --> Config Class Initialized
INFO - 2018-02-07 10:39:04 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:39:04 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:39:04 --> Utf8 Class Initialized
INFO - 2018-02-07 10:39:04 --> URI Class Initialized
INFO - 2018-02-07 10:39:04 --> Router Class Initialized
INFO - 2018-02-07 10:39:04 --> Output Class Initialized
INFO - 2018-02-07 10:39:04 --> Security Class Initialized
DEBUG - 2018-02-07 10:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:39:04 --> Input Class Initialized
INFO - 2018-02-07 10:39:04 --> Language Class Initialized
INFO - 2018-02-07 10:39:04 --> Language Class Initialized
INFO - 2018-02-07 10:39:04 --> Config Class Initialized
INFO - 2018-02-07 10:39:04 --> Loader Class Initialized
INFO - 2018-02-07 16:09:04 --> Helper loaded: url_helper
INFO - 2018-02-07 16:09:04 --> Helper loaded: notification_helper
INFO - 2018-02-07 16:09:04 --> Helper loaded: settings_helper
INFO - 2018-02-07 16:09:04 --> Helper loaded: permission_helper
INFO - 2018-02-07 16:09:04 --> Helper loaded: users_helper
INFO - 2018-02-07 16:09:04 --> Database Driver Class Initialized
DEBUG - 2018-02-07 16:09:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 16:09:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 16:09:04 --> Helper loaded: form_helper
INFO - 2018-02-07 16:09:04 --> Form Validation Class Initialized
INFO - 2018-02-07 16:09:04 --> Controller Class Initialized
INFO - 2018-02-07 16:09:04 --> Model Class Initialized
INFO - 2018-02-07 16:09:04 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 16:09:04 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 16:09:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 16:09:04 --> Model Class Initialized
INFO - 2018-02-07 16:09:04 --> Model Class Initialized
INFO - 2018-02-07 16:09:04 --> Model Class Initialized
INFO - 2018-02-07 16:09:04 --> Model Class Initialized
INFO - 2018-02-07 16:09:04 --> Model Class Initialized
INFO - 2018-02-07 16:09:04 --> Model Class Initialized
INFO - 2018-02-07 16:09:04 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 16:09:04 --> Model Class Initialized
INFO - 2018-02-07 16:09:04 --> Final output sent to browser
DEBUG - 2018-02-07 16:09:04 --> Total execution time: 0.1260
INFO - 2018-02-07 10:40:31 --> Config Class Initialized
INFO - 2018-02-07 10:40:31 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:40:31 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:40:31 --> Utf8 Class Initialized
INFO - 2018-02-07 10:40:31 --> URI Class Initialized
INFO - 2018-02-07 10:40:31 --> Router Class Initialized
INFO - 2018-02-07 10:40:31 --> Output Class Initialized
INFO - 2018-02-07 10:40:31 --> Security Class Initialized
DEBUG - 2018-02-07 10:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:40:31 --> Input Class Initialized
INFO - 2018-02-07 10:40:31 --> Language Class Initialized
INFO - 2018-02-07 10:40:31 --> Language Class Initialized
INFO - 2018-02-07 10:40:31 --> Config Class Initialized
INFO - 2018-02-07 10:40:31 --> Loader Class Initialized
INFO - 2018-02-07 16:10:31 --> Helper loaded: url_helper
INFO - 2018-02-07 16:10:31 --> Helper loaded: notification_helper
INFO - 2018-02-07 16:10:31 --> Helper loaded: settings_helper
INFO - 2018-02-07 16:10:31 --> Helper loaded: permission_helper
INFO - 2018-02-07 16:10:31 --> Helper loaded: users_helper
INFO - 2018-02-07 16:10:31 --> Database Driver Class Initialized
DEBUG - 2018-02-07 16:10:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 16:10:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 16:10:31 --> Helper loaded: form_helper
INFO - 2018-02-07 16:10:31 --> Form Validation Class Initialized
INFO - 2018-02-07 16:10:31 --> Controller Class Initialized
INFO - 2018-02-07 16:10:31 --> Model Class Initialized
INFO - 2018-02-07 16:10:31 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 16:10:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 16:10:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 16:10:31 --> Model Class Initialized
INFO - 2018-02-07 16:10:31 --> Model Class Initialized
INFO - 2018-02-07 16:10:31 --> Model Class Initialized
INFO - 2018-02-07 16:10:31 --> Model Class Initialized
INFO - 2018-02-07 16:10:31 --> Model Class Initialized
INFO - 2018-02-07 16:10:31 --> Model Class Initialized
INFO - 2018-02-07 16:10:31 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 16:10:31 --> Model Class Initialized
INFO - 2018-02-07 16:10:31 --> Final output sent to browser
DEBUG - 2018-02-07 16:10:31 --> Total execution time: 0.1010
INFO - 2018-02-07 10:41:20 --> Config Class Initialized
INFO - 2018-02-07 10:41:20 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:41:20 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:41:20 --> Utf8 Class Initialized
INFO - 2018-02-07 10:41:20 --> URI Class Initialized
INFO - 2018-02-07 10:41:20 --> Router Class Initialized
INFO - 2018-02-07 10:41:20 --> Output Class Initialized
INFO - 2018-02-07 10:41:20 --> Security Class Initialized
DEBUG - 2018-02-07 10:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:41:20 --> Input Class Initialized
INFO - 2018-02-07 10:41:20 --> Language Class Initialized
INFO - 2018-02-07 10:41:20 --> Language Class Initialized
INFO - 2018-02-07 10:41:20 --> Config Class Initialized
INFO - 2018-02-07 10:41:20 --> Loader Class Initialized
INFO - 2018-02-07 16:11:20 --> Helper loaded: url_helper
INFO - 2018-02-07 16:11:20 --> Helper loaded: notification_helper
INFO - 2018-02-07 16:11:20 --> Helper loaded: settings_helper
INFO - 2018-02-07 16:11:20 --> Helper loaded: permission_helper
INFO - 2018-02-07 16:11:20 --> Helper loaded: users_helper
INFO - 2018-02-07 16:11:20 --> Database Driver Class Initialized
DEBUG - 2018-02-07 16:11:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 16:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 16:11:20 --> Helper loaded: form_helper
INFO - 2018-02-07 16:11:20 --> Form Validation Class Initialized
INFO - 2018-02-07 16:11:20 --> Controller Class Initialized
INFO - 2018-02-07 16:11:20 --> Model Class Initialized
INFO - 2018-02-07 16:11:20 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 16:11:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 16:11:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 16:11:20 --> Model Class Initialized
INFO - 2018-02-07 16:11:20 --> Model Class Initialized
INFO - 2018-02-07 16:11:20 --> Model Class Initialized
INFO - 2018-02-07 16:11:20 --> Model Class Initialized
INFO - 2018-02-07 16:11:20 --> Model Class Initialized
INFO - 2018-02-07 16:11:20 --> Model Class Initialized
INFO - 2018-02-07 16:11:20 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 16:11:20 --> Model Class Initialized
INFO - 2018-02-07 16:11:20 --> Final output sent to browser
DEBUG - 2018-02-07 16:11:20 --> Total execution time: 0.1196
INFO - 2018-02-07 10:46:19 --> Config Class Initialized
INFO - 2018-02-07 10:46:19 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:46:19 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:46:19 --> Utf8 Class Initialized
INFO - 2018-02-07 10:46:19 --> URI Class Initialized
INFO - 2018-02-07 10:46:19 --> Router Class Initialized
INFO - 2018-02-07 10:46:19 --> Output Class Initialized
INFO - 2018-02-07 10:46:19 --> Security Class Initialized
DEBUG - 2018-02-07 10:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:46:19 --> Input Class Initialized
INFO - 2018-02-07 10:46:19 --> Language Class Initialized
INFO - 2018-02-07 10:46:19 --> Language Class Initialized
INFO - 2018-02-07 10:46:19 --> Config Class Initialized
INFO - 2018-02-07 10:46:19 --> Loader Class Initialized
INFO - 2018-02-07 16:16:19 --> Helper loaded: url_helper
INFO - 2018-02-07 16:16:19 --> Helper loaded: notification_helper
INFO - 2018-02-07 16:16:19 --> Helper loaded: settings_helper
INFO - 2018-02-07 16:16:19 --> Helper loaded: permission_helper
INFO - 2018-02-07 16:16:19 --> Helper loaded: users_helper
INFO - 2018-02-07 16:16:19 --> Database Driver Class Initialized
DEBUG - 2018-02-07 16:16:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 16:16:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 16:16:19 --> Helper loaded: form_helper
INFO - 2018-02-07 16:16:19 --> Form Validation Class Initialized
INFO - 2018-02-07 16:16:19 --> Controller Class Initialized
INFO - 2018-02-07 16:16:19 --> Model Class Initialized
INFO - 2018-02-07 16:16:19 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 16:16:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 16:16:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 16:16:19 --> Model Class Initialized
INFO - 2018-02-07 16:16:19 --> Model Class Initialized
INFO - 2018-02-07 16:16:19 --> Model Class Initialized
INFO - 2018-02-07 16:16:19 --> Model Class Initialized
INFO - 2018-02-07 16:16:19 --> Model Class Initialized
INFO - 2018-02-07 16:16:19 --> Model Class Initialized
INFO - 2018-02-07 16:16:19 --> Model Class Initialized
INFO - 2018-02-07 16:16:19 --> Model Class Initialized
INFO - 2018-02-07 16:16:19 --> Model Class Initialized
INFO - 2018-02-07 16:16:19 --> Model Class Initialized
INFO - 2018-02-07 16:16:19 --> Model Class Initialized
INFO - 2018-02-07 16:16:19 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 16:16:19 --> Model Class Initialized
INFO - 2018-02-07 16:16:19 --> Final output sent to browser
DEBUG - 2018-02-07 16:16:19 --> Total execution time: 0.0996
INFO - 2018-02-07 10:46:20 --> Config Class Initialized
INFO - 2018-02-07 10:46:20 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:46:20 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:46:20 --> Utf8 Class Initialized
INFO - 2018-02-07 10:46:20 --> URI Class Initialized
INFO - 2018-02-07 10:46:20 --> Router Class Initialized
INFO - 2018-02-07 10:46:20 --> Output Class Initialized
INFO - 2018-02-07 10:46:20 --> Security Class Initialized
DEBUG - 2018-02-07 10:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:46:20 --> Input Class Initialized
INFO - 2018-02-07 10:46:20 --> Language Class Initialized
INFO - 2018-02-07 10:46:20 --> Language Class Initialized
INFO - 2018-02-07 10:46:20 --> Config Class Initialized
INFO - 2018-02-07 10:46:20 --> Loader Class Initialized
INFO - 2018-02-07 16:16:20 --> Helper loaded: url_helper
INFO - 2018-02-07 16:16:20 --> Helper loaded: notification_helper
INFO - 2018-02-07 16:16:20 --> Helper loaded: settings_helper
INFO - 2018-02-07 16:16:20 --> Helper loaded: permission_helper
INFO - 2018-02-07 16:16:20 --> Helper loaded: users_helper
INFO - 2018-02-07 16:16:20 --> Database Driver Class Initialized
DEBUG - 2018-02-07 16:16:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 16:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 16:16:20 --> Helper loaded: form_helper
INFO - 2018-02-07 16:16:20 --> Form Validation Class Initialized
INFO - 2018-02-07 16:16:20 --> Controller Class Initialized
INFO - 2018-02-07 16:16:20 --> Model Class Initialized
INFO - 2018-02-07 16:16:20 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 16:16:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 16:16:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 16:16:20 --> Model Class Initialized
INFO - 2018-02-07 16:16:20 --> Model Class Initialized
INFO - 2018-02-07 16:16:20 --> Model Class Initialized
INFO - 2018-02-07 16:16:20 --> Model Class Initialized
INFO - 2018-02-07 16:16:20 --> Model Class Initialized
INFO - 2018-02-07 16:16:20 --> Model Class Initialized
INFO - 2018-02-07 16:16:20 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 16:16:20 --> Model Class Initialized
INFO - 2018-02-07 16:16:20 --> Final output sent to browser
DEBUG - 2018-02-07 16:16:20 --> Total execution time: 0.1231
INFO - 2018-02-07 10:46:44 --> Config Class Initialized
INFO - 2018-02-07 10:46:44 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:46:44 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:46:44 --> Utf8 Class Initialized
INFO - 2018-02-07 10:46:44 --> URI Class Initialized
INFO - 2018-02-07 10:46:44 --> Router Class Initialized
INFO - 2018-02-07 10:46:44 --> Output Class Initialized
INFO - 2018-02-07 10:46:44 --> Security Class Initialized
DEBUG - 2018-02-07 10:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:46:44 --> Input Class Initialized
INFO - 2018-02-07 10:46:44 --> Language Class Initialized
INFO - 2018-02-07 10:46:44 --> Config Class Initialized
INFO - 2018-02-07 10:46:44 --> Hooks Class Initialized
INFO - 2018-02-07 10:46:44 --> Language Class Initialized
DEBUG - 2018-02-07 10:46:44 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:46:44 --> Config Class Initialized
INFO - 2018-02-07 10:46:44 --> Utf8 Class Initialized
INFO - 2018-02-07 10:46:44 --> Loader Class Initialized
INFO - 2018-02-07 16:16:44 --> Helper loaded: url_helper
INFO - 2018-02-07 10:46:44 --> URI Class Initialized
INFO - 2018-02-07 16:16:44 --> Helper loaded: notification_helper
INFO - 2018-02-07 16:16:44 --> Helper loaded: settings_helper
INFO - 2018-02-07 16:16:44 --> Helper loaded: permission_helper
INFO - 2018-02-07 16:16:44 --> Helper loaded: users_helper
INFO - 2018-02-07 10:46:44 --> Router Class Initialized
INFO - 2018-02-07 10:46:44 --> Output Class Initialized
INFO - 2018-02-07 10:46:44 --> Security Class Initialized
DEBUG - 2018-02-07 10:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:46:44 --> Input Class Initialized
INFO - 2018-02-07 10:46:44 --> Language Class Initialized
INFO - 2018-02-07 16:16:44 --> Database Driver Class Initialized
DEBUG - 2018-02-07 16:16:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 16:16:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 10:46:44 --> Language Class Initialized
INFO - 2018-02-07 10:46:44 --> Config Class Initialized
INFO - 2018-02-07 10:46:44 --> Loader Class Initialized
INFO - 2018-02-07 16:16:44 --> Helper loaded: form_helper
INFO - 2018-02-07 16:16:44 --> Form Validation Class Initialized
INFO - 2018-02-07 16:16:44 --> Controller Class Initialized
INFO - 2018-02-07 16:16:44 --> Helper loaded: url_helper
INFO - 2018-02-07 16:16:44 --> Helper loaded: notification_helper
INFO - 2018-02-07 16:16:44 --> Helper loaded: settings_helper
INFO - 2018-02-07 16:16:44 --> Helper loaded: permission_helper
INFO - 2018-02-07 16:16:44 --> Helper loaded: users_helper
INFO - 2018-02-07 16:16:44 --> Model Class Initialized
INFO - 2018-02-07 16:16:44 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 16:16:44 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 16:16:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 16:16:44 --> Model Class Initialized
INFO - 2018-02-07 16:16:44 --> Model Class Initialized
INFO - 2018-02-07 16:16:44 --> Model Class Initialized
INFO - 2018-02-07 16:16:44 --> Model Class Initialized
INFO - 2018-02-07 16:16:44 --> Model Class Initialized
INFO - 2018-02-07 16:16:44 --> Model Class Initialized
INFO - 2018-02-07 16:16:44 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 16:16:44 --> Database Driver Class Initialized
INFO - 2018-02-07 16:16:44 --> Final output sent to browser
DEBUG - 2018-02-07 16:16:44 --> Total execution time: 0.0828
DEBUG - 2018-02-07 16:16:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 16:16:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 16:16:44 --> Helper loaded: form_helper
INFO - 2018-02-07 16:16:44 --> Form Validation Class Initialized
INFO - 2018-02-07 16:16:44 --> Controller Class Initialized
INFO - 2018-02-07 16:16:44 --> Model Class Initialized
INFO - 2018-02-07 16:16:44 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 16:16:44 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 16:16:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 16:16:44 --> Model Class Initialized
INFO - 2018-02-07 16:16:44 --> Model Class Initialized
INFO - 2018-02-07 16:16:44 --> Model Class Initialized
INFO - 2018-02-07 16:16:44 --> Model Class Initialized
INFO - 2018-02-07 16:16:44 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 16:16:44 --> Final output sent to browser
DEBUG - 2018-02-07 16:16:44 --> Total execution time: 0.0804
INFO - 2018-02-07 10:46:48 --> Config Class Initialized
INFO - 2018-02-07 10:46:48 --> Hooks Class Initialized
DEBUG - 2018-02-07 10:46:48 --> UTF-8 Support Enabled
INFO - 2018-02-07 10:46:48 --> Utf8 Class Initialized
INFO - 2018-02-07 10:46:48 --> URI Class Initialized
INFO - 2018-02-07 10:46:48 --> Router Class Initialized
INFO - 2018-02-07 10:46:48 --> Output Class Initialized
INFO - 2018-02-07 10:46:48 --> Security Class Initialized
DEBUG - 2018-02-07 10:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 10:46:48 --> Input Class Initialized
INFO - 2018-02-07 10:46:48 --> Language Class Initialized
INFO - 2018-02-07 10:46:48 --> Language Class Initialized
INFO - 2018-02-07 10:46:48 --> Config Class Initialized
INFO - 2018-02-07 10:46:48 --> Loader Class Initialized
INFO - 2018-02-07 16:16:48 --> Helper loaded: url_helper
INFO - 2018-02-07 16:16:48 --> Helper loaded: notification_helper
INFO - 2018-02-07 16:16:48 --> Helper loaded: settings_helper
INFO - 2018-02-07 16:16:48 --> Helper loaded: permission_helper
INFO - 2018-02-07 16:16:48 --> Helper loaded: users_helper
INFO - 2018-02-07 16:16:48 --> Database Driver Class Initialized
DEBUG - 2018-02-07 16:16:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 16:16:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 16:16:48 --> Helper loaded: form_helper
INFO - 2018-02-07 16:16:48 --> Form Validation Class Initialized
INFO - 2018-02-07 16:16:48 --> Controller Class Initialized
INFO - 2018-02-07 16:16:48 --> Model Class Initialized
INFO - 2018-02-07 16:16:48 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 16:16:48 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 16:16:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 16:16:48 --> Model Class Initialized
INFO - 2018-02-07 16:16:48 --> Model Class Initialized
INFO - 2018-02-07 16:16:48 --> Model Class Initialized
INFO - 2018-02-07 16:16:48 --> Model Class Initialized
INFO - 2018-02-07 16:16:48 --> Model Class Initialized
INFO - 2018-02-07 16:16:48 --> Model Class Initialized
INFO - 2018-02-07 16:16:48 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 16:16:48 --> Model Class Initialized
INFO - 2018-02-07 16:16:48 --> Final output sent to browser
DEBUG - 2018-02-07 16:16:48 --> Total execution time: 0.1144
INFO - 2018-02-07 11:08:58 --> Config Class Initialized
INFO - 2018-02-07 11:08:58 --> Hooks Class Initialized
DEBUG - 2018-02-07 11:08:58 --> UTF-8 Support Enabled
INFO - 2018-02-07 11:08:58 --> Utf8 Class Initialized
INFO - 2018-02-07 11:08:58 --> URI Class Initialized
INFO - 2018-02-07 11:08:58 --> Router Class Initialized
INFO - 2018-02-07 11:08:58 --> Output Class Initialized
INFO - 2018-02-07 11:08:58 --> Security Class Initialized
DEBUG - 2018-02-07 11:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 11:08:58 --> Input Class Initialized
INFO - 2018-02-07 11:08:58 --> Language Class Initialized
INFO - 2018-02-07 11:08:58 --> Language Class Initialized
INFO - 2018-02-07 11:08:58 --> Config Class Initialized
INFO - 2018-02-07 11:08:58 --> Loader Class Initialized
INFO - 2018-02-07 16:38:58 --> Helper loaded: url_helper
INFO - 2018-02-07 16:38:58 --> Helper loaded: notification_helper
INFO - 2018-02-07 16:38:58 --> Helper loaded: settings_helper
INFO - 2018-02-07 16:38:58 --> Helper loaded: permission_helper
INFO - 2018-02-07 16:38:58 --> Helper loaded: users_helper
INFO - 2018-02-07 16:38:58 --> Database Driver Class Initialized
DEBUG - 2018-02-07 16:38:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 16:38:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 16:38:58 --> Helper loaded: form_helper
INFO - 2018-02-07 16:38:58 --> Form Validation Class Initialized
INFO - 2018-02-07 16:38:58 --> Controller Class Initialized
INFO - 2018-02-07 16:38:58 --> Model Class Initialized
INFO - 2018-02-07 16:38:58 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 16:38:58 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 16:38:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 16:38:58 --> Model Class Initialized
INFO - 2018-02-07 16:38:58 --> Model Class Initialized
INFO - 2018-02-07 16:38:58 --> Model Class Initialized
INFO - 2018-02-07 16:38:58 --> Model Class Initialized
INFO - 2018-02-07 16:38:58 --> Model Class Initialized
INFO - 2018-02-07 16:38:58 --> Model Class Initialized
INFO - 2018-02-07 16:38:58 --> Model Class Initialized
INFO - 2018-02-07 16:38:58 --> Model Class Initialized
INFO - 2018-02-07 16:38:58 --> Model Class Initialized
INFO - 2018-02-07 16:38:58 --> Model Class Initialized
INFO - 2018-02-07 16:38:58 --> Model Class Initialized
INFO - 2018-02-07 16:38:58 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 16:38:58 --> Model Class Initialized
INFO - 2018-02-07 16:38:58 --> Final output sent to browser
DEBUG - 2018-02-07 16:38:58 --> Total execution time: 0.0980
INFO - 2018-02-07 11:08:59 --> Config Class Initialized
INFO - 2018-02-07 11:08:59 --> Hooks Class Initialized
DEBUG - 2018-02-07 11:08:59 --> UTF-8 Support Enabled
INFO - 2018-02-07 11:08:59 --> Utf8 Class Initialized
INFO - 2018-02-07 11:08:59 --> URI Class Initialized
INFO - 2018-02-07 11:08:59 --> Router Class Initialized
INFO - 2018-02-07 11:08:59 --> Output Class Initialized
INFO - 2018-02-07 11:08:59 --> Security Class Initialized
DEBUG - 2018-02-07 11:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 11:08:59 --> Input Class Initialized
INFO - 2018-02-07 11:08:59 --> Language Class Initialized
INFO - 2018-02-07 11:08:59 --> Language Class Initialized
INFO - 2018-02-07 11:08:59 --> Config Class Initialized
INFO - 2018-02-07 11:08:59 --> Loader Class Initialized
INFO - 2018-02-07 16:38:59 --> Helper loaded: url_helper
INFO - 2018-02-07 16:38:59 --> Helper loaded: notification_helper
INFO - 2018-02-07 16:38:59 --> Helper loaded: settings_helper
INFO - 2018-02-07 16:38:59 --> Helper loaded: permission_helper
INFO - 2018-02-07 16:38:59 --> Helper loaded: users_helper
INFO - 2018-02-07 16:38:59 --> Database Driver Class Initialized
DEBUG - 2018-02-07 16:38:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 16:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 16:38:59 --> Helper loaded: form_helper
INFO - 2018-02-07 16:38:59 --> Form Validation Class Initialized
INFO - 2018-02-07 16:38:59 --> Controller Class Initialized
INFO - 2018-02-07 16:38:59 --> Model Class Initialized
INFO - 2018-02-07 16:38:59 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 16:38:59 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 16:38:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 16:38:59 --> Model Class Initialized
INFO - 2018-02-07 16:38:59 --> Model Class Initialized
INFO - 2018-02-07 16:38:59 --> Model Class Initialized
INFO - 2018-02-07 16:38:59 --> Model Class Initialized
INFO - 2018-02-07 16:38:59 --> Model Class Initialized
INFO - 2018-02-07 16:38:59 --> Model Class Initialized
INFO - 2018-02-07 16:38:59 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 16:38:59 --> Model Class Initialized
INFO - 2018-02-07 16:38:59 --> Final output sent to browser
DEBUG - 2018-02-07 16:38:59 --> Total execution time: 0.1215
INFO - 2018-02-07 11:09:11 --> Config Class Initialized
INFO - 2018-02-07 11:09:11 --> Hooks Class Initialized
DEBUG - 2018-02-07 11:09:11 --> UTF-8 Support Enabled
INFO - 2018-02-07 11:09:11 --> Utf8 Class Initialized
INFO - 2018-02-07 11:09:11 --> URI Class Initialized
INFO - 2018-02-07 11:09:11 --> Router Class Initialized
INFO - 2018-02-07 11:09:11 --> Output Class Initialized
INFO - 2018-02-07 11:09:11 --> Security Class Initialized
DEBUG - 2018-02-07 11:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 11:09:11 --> Input Class Initialized
INFO - 2018-02-07 11:09:11 --> Language Class Initialized
INFO - 2018-02-07 11:09:11 --> Language Class Initialized
INFO - 2018-02-07 11:09:11 --> Config Class Initialized
INFO - 2018-02-07 11:09:11 --> Loader Class Initialized
INFO - 2018-02-07 16:39:11 --> Helper loaded: url_helper
INFO - 2018-02-07 16:39:11 --> Helper loaded: notification_helper
INFO - 2018-02-07 16:39:11 --> Helper loaded: settings_helper
INFO - 2018-02-07 16:39:11 --> Helper loaded: permission_helper
INFO - 2018-02-07 16:39:11 --> Helper loaded: users_helper
INFO - 2018-02-07 16:39:11 --> Database Driver Class Initialized
DEBUG - 2018-02-07 16:39:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 16:39:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 16:39:11 --> Helper loaded: form_helper
INFO - 2018-02-07 16:39:11 --> Form Validation Class Initialized
INFO - 2018-02-07 16:39:11 --> Controller Class Initialized
INFO - 2018-02-07 16:39:11 --> Model Class Initialized
INFO - 2018-02-07 16:39:11 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 16:39:11 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 16:39:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 16:39:11 --> Model Class Initialized
INFO - 2018-02-07 16:39:11 --> Model Class Initialized
INFO - 2018-02-07 16:39:11 --> Model Class Initialized
INFO - 2018-02-07 16:39:11 --> Model Class Initialized
INFO - 2018-02-07 16:39:11 --> Model Class Initialized
INFO - 2018-02-07 16:39:11 --> Model Class Initialized
INFO - 2018-02-07 16:39:11 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 16:39:11 --> Final output sent to browser
DEBUG - 2018-02-07 16:39:11 --> Total execution time: 0.1124
INFO - 2018-02-07 11:09:11 --> Config Class Initialized
INFO - 2018-02-07 11:09:11 --> Hooks Class Initialized
DEBUG - 2018-02-07 11:09:11 --> UTF-8 Support Enabled
INFO - 2018-02-07 11:09:11 --> Utf8 Class Initialized
INFO - 2018-02-07 11:09:11 --> URI Class Initialized
INFO - 2018-02-07 11:09:11 --> Router Class Initialized
INFO - 2018-02-07 11:09:11 --> Output Class Initialized
INFO - 2018-02-07 11:09:11 --> Security Class Initialized
DEBUG - 2018-02-07 11:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 11:09:11 --> Input Class Initialized
INFO - 2018-02-07 11:09:11 --> Language Class Initialized
INFO - 2018-02-07 11:09:11 --> Language Class Initialized
INFO - 2018-02-07 11:09:11 --> Config Class Initialized
INFO - 2018-02-07 11:09:11 --> Loader Class Initialized
INFO - 2018-02-07 16:39:11 --> Helper loaded: url_helper
INFO - 2018-02-07 16:39:11 --> Helper loaded: notification_helper
INFO - 2018-02-07 16:39:11 --> Helper loaded: settings_helper
INFO - 2018-02-07 16:39:11 --> Helper loaded: permission_helper
INFO - 2018-02-07 16:39:11 --> Helper loaded: users_helper
INFO - 2018-02-07 16:39:11 --> Database Driver Class Initialized
DEBUG - 2018-02-07 16:39:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 16:39:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 16:39:11 --> Helper loaded: form_helper
INFO - 2018-02-07 16:39:11 --> Form Validation Class Initialized
INFO - 2018-02-07 16:39:11 --> Controller Class Initialized
INFO - 2018-02-07 16:39:11 --> Model Class Initialized
INFO - 2018-02-07 16:39:11 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 16:39:11 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 16:39:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 16:39:11 --> Model Class Initialized
INFO - 2018-02-07 16:39:11 --> Model Class Initialized
INFO - 2018-02-07 16:39:11 --> Model Class Initialized
INFO - 2018-02-07 16:39:11 --> Model Class Initialized
INFO - 2018-02-07 16:39:11 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 16:39:11 --> Final output sent to browser
DEBUG - 2018-02-07 16:39:11 --> Total execution time: 0.1126
INFO - 2018-02-07 11:09:23 --> Config Class Initialized
INFO - 2018-02-07 11:09:23 --> Hooks Class Initialized
DEBUG - 2018-02-07 11:09:23 --> UTF-8 Support Enabled
INFO - 2018-02-07 11:09:23 --> Utf8 Class Initialized
INFO - 2018-02-07 11:09:23 --> URI Class Initialized
INFO - 2018-02-07 11:09:23 --> Router Class Initialized
INFO - 2018-02-07 11:09:23 --> Output Class Initialized
INFO - 2018-02-07 11:09:23 --> Security Class Initialized
DEBUG - 2018-02-07 11:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 11:09:23 --> Input Class Initialized
INFO - 2018-02-07 11:09:23 --> Language Class Initialized
INFO - 2018-02-07 11:09:23 --> Language Class Initialized
INFO - 2018-02-07 11:09:23 --> Config Class Initialized
INFO - 2018-02-07 11:09:23 --> Loader Class Initialized
INFO - 2018-02-07 16:39:23 --> Helper loaded: url_helper
INFO - 2018-02-07 16:39:23 --> Helper loaded: notification_helper
INFO - 2018-02-07 16:39:23 --> Helper loaded: settings_helper
INFO - 2018-02-07 16:39:23 --> Helper loaded: permission_helper
INFO - 2018-02-07 16:39:23 --> Helper loaded: users_helper
INFO - 2018-02-07 16:39:23 --> Database Driver Class Initialized
DEBUG - 2018-02-07 16:39:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 16:39:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 16:39:24 --> Helper loaded: form_helper
INFO - 2018-02-07 16:39:24 --> Form Validation Class Initialized
INFO - 2018-02-07 16:39:24 --> Controller Class Initialized
INFO - 2018-02-07 16:39:24 --> Model Class Initialized
INFO - 2018-02-07 16:39:24 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 16:39:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 16:39:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 16:39:24 --> Model Class Initialized
INFO - 2018-02-07 16:39:24 --> Model Class Initialized
INFO - 2018-02-07 16:39:24 --> Model Class Initialized
INFO - 2018-02-07 16:39:24 --> Model Class Initialized
INFO - 2018-02-07 16:39:24 --> Model Class Initialized
INFO - 2018-02-07 16:39:24 --> Model Class Initialized
INFO - 2018-02-07 16:39:24 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 16:39:24 --> Model Class Initialized
INFO - 2018-02-07 16:39:24 --> Final output sent to browser
DEBUG - 2018-02-07 16:39:24 --> Total execution time: 0.1192
INFO - 2018-02-07 11:23:54 --> Config Class Initialized
INFO - 2018-02-07 11:23:54 --> Hooks Class Initialized
DEBUG - 2018-02-07 11:23:54 --> UTF-8 Support Enabled
INFO - 2018-02-07 11:23:54 --> Utf8 Class Initialized
INFO - 2018-02-07 11:23:54 --> URI Class Initialized
INFO - 2018-02-07 11:23:55 --> Router Class Initialized
INFO - 2018-02-07 11:23:55 --> Output Class Initialized
INFO - 2018-02-07 11:23:55 --> Security Class Initialized
DEBUG - 2018-02-07 11:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 11:23:55 --> Input Class Initialized
INFO - 2018-02-07 11:23:55 --> Language Class Initialized
INFO - 2018-02-07 11:23:55 --> Language Class Initialized
INFO - 2018-02-07 11:23:55 --> Config Class Initialized
INFO - 2018-02-07 11:23:55 --> Loader Class Initialized
INFO - 2018-02-07 16:53:55 --> Helper loaded: url_helper
INFO - 2018-02-07 16:53:55 --> Helper loaded: notification_helper
INFO - 2018-02-07 16:53:55 --> Helper loaded: settings_helper
INFO - 2018-02-07 16:53:55 --> Helper loaded: permission_helper
INFO - 2018-02-07 16:53:55 --> Helper loaded: users_helper
INFO - 2018-02-07 16:53:55 --> Database Driver Class Initialized
DEBUG - 2018-02-07 16:53:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 16:53:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 16:53:55 --> Helper loaded: form_helper
INFO - 2018-02-07 16:53:55 --> Form Validation Class Initialized
INFO - 2018-02-07 16:53:55 --> Controller Class Initialized
INFO - 2018-02-07 16:53:55 --> Model Class Initialized
INFO - 2018-02-07 16:53:55 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 16:53:55 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 16:53:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 16:53:55 --> Model Class Initialized
INFO - 2018-02-07 16:53:55 --> Model Class Initialized
INFO - 2018-02-07 16:53:55 --> Model Class Initialized
INFO - 2018-02-07 16:53:55 --> Model Class Initialized
INFO - 2018-02-07 16:53:55 --> Model Class Initialized
INFO - 2018-02-07 16:53:55 --> Model Class Initialized
INFO - 2018-02-07 16:53:55 --> Model Class Initialized
INFO - 2018-02-07 16:53:55 --> Model Class Initialized
INFO - 2018-02-07 16:53:55 --> Model Class Initialized
INFO - 2018-02-07 16:53:55 --> Model Class Initialized
INFO - 2018-02-07 16:53:55 --> Model Class Initialized
INFO - 2018-02-07 16:53:55 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 16:53:55 --> Model Class Initialized
INFO - 2018-02-07 16:53:55 --> Final output sent to browser
DEBUG - 2018-02-07 16:53:55 --> Total execution time: 0.1555
INFO - 2018-02-07 11:23:55 --> Config Class Initialized
INFO - 2018-02-07 11:23:55 --> Hooks Class Initialized
DEBUG - 2018-02-07 11:23:55 --> UTF-8 Support Enabled
INFO - 2018-02-07 11:23:55 --> Utf8 Class Initialized
INFO - 2018-02-07 11:23:55 --> URI Class Initialized
INFO - 2018-02-07 11:23:55 --> Router Class Initialized
INFO - 2018-02-07 11:23:55 --> Output Class Initialized
INFO - 2018-02-07 11:23:55 --> Security Class Initialized
DEBUG - 2018-02-07 11:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 11:23:55 --> Input Class Initialized
INFO - 2018-02-07 11:23:55 --> Language Class Initialized
INFO - 2018-02-07 11:23:55 --> Language Class Initialized
INFO - 2018-02-07 11:23:55 --> Config Class Initialized
INFO - 2018-02-07 11:23:55 --> Loader Class Initialized
INFO - 2018-02-07 16:53:55 --> Helper loaded: url_helper
INFO - 2018-02-07 16:53:55 --> Helper loaded: notification_helper
INFO - 2018-02-07 16:53:55 --> Helper loaded: settings_helper
INFO - 2018-02-07 16:53:55 --> Helper loaded: permission_helper
INFO - 2018-02-07 16:53:55 --> Helper loaded: users_helper
INFO - 2018-02-07 16:53:55 --> Database Driver Class Initialized
DEBUG - 2018-02-07 16:53:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 16:53:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 16:53:55 --> Helper loaded: form_helper
INFO - 2018-02-07 16:53:55 --> Form Validation Class Initialized
INFO - 2018-02-07 16:53:55 --> Controller Class Initialized
INFO - 2018-02-07 16:53:55 --> Model Class Initialized
INFO - 2018-02-07 16:53:55 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 16:53:55 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 16:53:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 16:53:55 --> Model Class Initialized
INFO - 2018-02-07 16:53:55 --> Model Class Initialized
INFO - 2018-02-07 16:53:55 --> Model Class Initialized
INFO - 2018-02-07 16:53:55 --> Model Class Initialized
INFO - 2018-02-07 16:53:55 --> Model Class Initialized
INFO - 2018-02-07 16:53:55 --> Model Class Initialized
INFO - 2018-02-07 16:53:55 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 16:53:55 --> Model Class Initialized
INFO - 2018-02-07 16:53:55 --> Final output sent to browser
DEBUG - 2018-02-07 16:53:55 --> Total execution time: 0.1258
INFO - 2018-02-07 11:24:24 --> Config Class Initialized
INFO - 2018-02-07 11:24:24 --> Hooks Class Initialized
DEBUG - 2018-02-07 11:24:24 --> UTF-8 Support Enabled
INFO - 2018-02-07 11:24:24 --> Utf8 Class Initialized
INFO - 2018-02-07 11:24:24 --> URI Class Initialized
INFO - 2018-02-07 11:24:24 --> Router Class Initialized
INFO - 2018-02-07 11:24:24 --> Output Class Initialized
INFO - 2018-02-07 11:24:24 --> Security Class Initialized
DEBUG - 2018-02-07 11:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 11:24:24 --> Input Class Initialized
INFO - 2018-02-07 11:24:24 --> Language Class Initialized
INFO - 2018-02-07 11:24:24 --> Language Class Initialized
INFO - 2018-02-07 11:24:24 --> Config Class Initialized
INFO - 2018-02-07 11:24:24 --> Loader Class Initialized
INFO - 2018-02-07 16:54:24 --> Helper loaded: url_helper
INFO - 2018-02-07 16:54:24 --> Helper loaded: notification_helper
INFO - 2018-02-07 16:54:24 --> Helper loaded: settings_helper
INFO - 2018-02-07 11:24:24 --> Config Class Initialized
INFO - 2018-02-07 11:24:24 --> Hooks Class Initialized
INFO - 2018-02-07 16:54:24 --> Helper loaded: permission_helper
INFO - 2018-02-07 16:54:24 --> Helper loaded: users_helper
DEBUG - 2018-02-07 11:24:24 --> UTF-8 Support Enabled
INFO - 2018-02-07 11:24:24 --> Utf8 Class Initialized
INFO - 2018-02-07 11:24:24 --> URI Class Initialized
INFO - 2018-02-07 11:24:24 --> Router Class Initialized
INFO - 2018-02-07 16:54:24 --> Database Driver Class Initialized
INFO - 2018-02-07 11:24:24 --> Output Class Initialized
INFO - 2018-02-07 11:24:24 --> Security Class Initialized
DEBUG - 2018-02-07 16:54:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 16:54:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-07 11:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 11:24:24 --> Input Class Initialized
INFO - 2018-02-07 11:24:24 --> Language Class Initialized
INFO - 2018-02-07 16:54:24 --> Helper loaded: form_helper
INFO - 2018-02-07 16:54:24 --> Form Validation Class Initialized
INFO - 2018-02-07 16:54:24 --> Controller Class Initialized
INFO - 2018-02-07 16:54:24 --> Model Class Initialized
INFO - 2018-02-07 16:54:24 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 16:54:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 16:54:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 16:54:24 --> Model Class Initialized
INFO - 2018-02-07 16:54:24 --> Model Class Initialized
INFO - 2018-02-07 16:54:24 --> Model Class Initialized
INFO - 2018-02-07 16:54:24 --> Model Class Initialized
INFO - 2018-02-07 16:54:24 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 16:54:24 --> Final output sent to browser
DEBUG - 2018-02-07 16:54:24 --> Total execution time: 0.1003
INFO - 2018-02-07 11:24:24 --> Language Class Initialized
INFO - 2018-02-07 11:24:24 --> Config Class Initialized
INFO - 2018-02-07 11:24:24 --> Loader Class Initialized
INFO - 2018-02-07 16:54:24 --> Helper loaded: url_helper
INFO - 2018-02-07 16:54:24 --> Helper loaded: notification_helper
INFO - 2018-02-07 16:54:24 --> Helper loaded: settings_helper
INFO - 2018-02-07 16:54:24 --> Helper loaded: permission_helper
INFO - 2018-02-07 16:54:24 --> Helper loaded: users_helper
INFO - 2018-02-07 16:54:24 --> Database Driver Class Initialized
DEBUG - 2018-02-07 16:54:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 16:54:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 16:54:24 --> Helper loaded: form_helper
INFO - 2018-02-07 16:54:24 --> Form Validation Class Initialized
INFO - 2018-02-07 16:54:24 --> Controller Class Initialized
INFO - 2018-02-07 16:54:24 --> Model Class Initialized
INFO - 2018-02-07 16:54:24 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 16:54:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 16:54:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 16:54:24 --> Model Class Initialized
INFO - 2018-02-07 16:54:24 --> Model Class Initialized
INFO - 2018-02-07 16:54:24 --> Model Class Initialized
INFO - 2018-02-07 16:54:24 --> Model Class Initialized
INFO - 2018-02-07 16:54:24 --> Model Class Initialized
INFO - 2018-02-07 16:54:24 --> Model Class Initialized
INFO - 2018-02-07 16:54:24 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 16:54:24 --> Final output sent to browser
DEBUG - 2018-02-07 16:54:24 --> Total execution time: 0.1496
INFO - 2018-02-07 11:24:35 --> Config Class Initialized
INFO - 2018-02-07 11:24:35 --> Hooks Class Initialized
DEBUG - 2018-02-07 11:24:35 --> UTF-8 Support Enabled
INFO - 2018-02-07 11:24:35 --> Utf8 Class Initialized
INFO - 2018-02-07 11:24:35 --> URI Class Initialized
INFO - 2018-02-07 11:24:35 --> Router Class Initialized
INFO - 2018-02-07 11:24:35 --> Output Class Initialized
INFO - 2018-02-07 11:24:35 --> Security Class Initialized
DEBUG - 2018-02-07 11:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 11:24:35 --> Input Class Initialized
INFO - 2018-02-07 11:24:35 --> Language Class Initialized
INFO - 2018-02-07 11:24:35 --> Language Class Initialized
INFO - 2018-02-07 11:24:35 --> Config Class Initialized
INFO - 2018-02-07 11:24:35 --> Loader Class Initialized
INFO - 2018-02-07 16:54:35 --> Helper loaded: url_helper
INFO - 2018-02-07 16:54:35 --> Helper loaded: notification_helper
INFO - 2018-02-07 16:54:35 --> Helper loaded: settings_helper
INFO - 2018-02-07 16:54:35 --> Helper loaded: permission_helper
INFO - 2018-02-07 16:54:35 --> Helper loaded: users_helper
INFO - 2018-02-07 16:54:35 --> Database Driver Class Initialized
DEBUG - 2018-02-07 16:54:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 16:54:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 16:54:35 --> Helper loaded: form_helper
INFO - 2018-02-07 16:54:35 --> Form Validation Class Initialized
INFO - 2018-02-07 16:54:35 --> Controller Class Initialized
INFO - 2018-02-07 16:54:35 --> Model Class Initialized
INFO - 2018-02-07 16:54:35 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 16:54:35 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 16:54:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 16:54:35 --> Model Class Initialized
INFO - 2018-02-07 16:54:35 --> Model Class Initialized
INFO - 2018-02-07 16:54:35 --> Model Class Initialized
INFO - 2018-02-07 16:54:35 --> Model Class Initialized
INFO - 2018-02-07 16:54:35 --> Model Class Initialized
INFO - 2018-02-07 16:54:35 --> Model Class Initialized
INFO - 2018-02-07 16:54:35 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 16:54:35 --> Model Class Initialized
INFO - 2018-02-07 16:54:35 --> Final output sent to browser
DEBUG - 2018-02-07 16:54:35 --> Total execution time: 0.0956
INFO - 2018-02-07 11:33:58 --> Config Class Initialized
INFO - 2018-02-07 11:33:58 --> Hooks Class Initialized
DEBUG - 2018-02-07 11:33:58 --> UTF-8 Support Enabled
INFO - 2018-02-07 11:33:58 --> Utf8 Class Initialized
INFO - 2018-02-07 11:33:58 --> URI Class Initialized
INFO - 2018-02-07 11:33:58 --> Router Class Initialized
INFO - 2018-02-07 11:33:58 --> Output Class Initialized
INFO - 2018-02-07 11:33:58 --> Security Class Initialized
DEBUG - 2018-02-07 11:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 11:33:58 --> Input Class Initialized
INFO - 2018-02-07 11:33:58 --> Language Class Initialized
INFO - 2018-02-07 11:33:58 --> Language Class Initialized
INFO - 2018-02-07 11:33:58 --> Config Class Initialized
INFO - 2018-02-07 11:33:58 --> Loader Class Initialized
INFO - 2018-02-07 17:03:58 --> Helper loaded: url_helper
INFO - 2018-02-07 17:03:58 --> Helper loaded: notification_helper
INFO - 2018-02-07 17:03:58 --> Helper loaded: settings_helper
INFO - 2018-02-07 17:03:58 --> Helper loaded: permission_helper
INFO - 2018-02-07 17:03:58 --> Helper loaded: users_helper
INFO - 2018-02-07 17:03:58 --> Database Driver Class Initialized
DEBUG - 2018-02-07 17:03:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 17:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 17:03:58 --> Helper loaded: form_helper
INFO - 2018-02-07 17:03:58 --> Form Validation Class Initialized
INFO - 2018-02-07 17:03:58 --> Controller Class Initialized
INFO - 2018-02-07 17:03:58 --> Model Class Initialized
INFO - 2018-02-07 17:03:58 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 17:03:58 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 17:03:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 17:03:58 --> Model Class Initialized
INFO - 2018-02-07 17:03:58 --> Model Class Initialized
INFO - 2018-02-07 17:03:58 --> Model Class Initialized
INFO - 2018-02-07 17:03:58 --> Model Class Initialized
INFO - 2018-02-07 17:03:58 --> Model Class Initialized
INFO - 2018-02-07 17:03:58 --> Model Class Initialized
INFO - 2018-02-07 17:03:58 --> Model Class Initialized
INFO - 2018-02-07 17:03:58 --> Model Class Initialized
INFO - 2018-02-07 17:03:58 --> Model Class Initialized
INFO - 2018-02-07 17:03:58 --> Model Class Initialized
INFO - 2018-02-07 17:03:58 --> Model Class Initialized
INFO - 2018-02-07 17:03:58 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 17:03:58 --> Model Class Initialized
INFO - 2018-02-07 17:03:58 --> Final output sent to browser
DEBUG - 2018-02-07 17:03:58 --> Total execution time: 0.1255
INFO - 2018-02-07 11:34:02 --> Config Class Initialized
INFO - 2018-02-07 11:34:02 --> Hooks Class Initialized
DEBUG - 2018-02-07 11:34:02 --> UTF-8 Support Enabled
INFO - 2018-02-07 11:34:02 --> Utf8 Class Initialized
INFO - 2018-02-07 11:34:02 --> URI Class Initialized
INFO - 2018-02-07 11:34:02 --> Router Class Initialized
INFO - 2018-02-07 11:34:02 --> Output Class Initialized
INFO - 2018-02-07 11:34:02 --> Security Class Initialized
DEBUG - 2018-02-07 11:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 11:34:02 --> Input Class Initialized
INFO - 2018-02-07 11:34:02 --> Language Class Initialized
INFO - 2018-02-07 11:34:02 --> Language Class Initialized
INFO - 2018-02-07 11:34:02 --> Config Class Initialized
INFO - 2018-02-07 11:34:02 --> Loader Class Initialized
INFO - 2018-02-07 17:04:02 --> Helper loaded: url_helper
INFO - 2018-02-07 17:04:02 --> Helper loaded: notification_helper
INFO - 2018-02-07 17:04:02 --> Helper loaded: settings_helper
INFO - 2018-02-07 17:04:02 --> Helper loaded: permission_helper
INFO - 2018-02-07 17:04:02 --> Helper loaded: users_helper
INFO - 2018-02-07 17:04:02 --> Database Driver Class Initialized
DEBUG - 2018-02-07 17:04:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 17:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 17:04:02 --> Helper loaded: form_helper
INFO - 2018-02-07 17:04:02 --> Form Validation Class Initialized
INFO - 2018-02-07 17:04:02 --> Controller Class Initialized
INFO - 2018-02-07 17:04:02 --> Model Class Initialized
INFO - 2018-02-07 17:04:02 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 17:04:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 17:04:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 17:04:02 --> Model Class Initialized
INFO - 2018-02-07 17:04:02 --> Model Class Initialized
INFO - 2018-02-07 17:04:02 --> Model Class Initialized
INFO - 2018-02-07 17:04:02 --> Model Class Initialized
INFO - 2018-02-07 17:04:02 --> Model Class Initialized
INFO - 2018-02-07 17:04:02 --> Model Class Initialized
INFO - 2018-02-07 17:04:02 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 17:04:02 --> Model Class Initialized
INFO - 2018-02-07 17:04:02 --> Final output sent to browser
DEBUG - 2018-02-07 17:04:02 --> Total execution time: 0.1127
INFO - 2018-02-07 11:34:05 --> Config Class Initialized
INFO - 2018-02-07 11:34:05 --> Hooks Class Initialized
DEBUG - 2018-02-07 11:34:05 --> UTF-8 Support Enabled
INFO - 2018-02-07 11:34:05 --> Utf8 Class Initialized
INFO - 2018-02-07 11:34:05 --> URI Class Initialized
INFO - 2018-02-07 11:34:05 --> Router Class Initialized
INFO - 2018-02-07 11:34:05 --> Output Class Initialized
INFO - 2018-02-07 11:34:05 --> Security Class Initialized
DEBUG - 2018-02-07 11:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 11:34:05 --> Input Class Initialized
INFO - 2018-02-07 11:34:05 --> Language Class Initialized
INFO - 2018-02-07 11:34:05 --> Language Class Initialized
INFO - 2018-02-07 11:34:05 --> Config Class Initialized
INFO - 2018-02-07 11:34:05 --> Loader Class Initialized
INFO - 2018-02-07 17:04:05 --> Helper loaded: url_helper
INFO - 2018-02-07 17:04:05 --> Helper loaded: notification_helper
INFO - 2018-02-07 17:04:05 --> Helper loaded: settings_helper
INFO - 2018-02-07 17:04:05 --> Helper loaded: permission_helper
INFO - 2018-02-07 17:04:05 --> Helper loaded: users_helper
INFO - 2018-02-07 17:04:05 --> Database Driver Class Initialized
DEBUG - 2018-02-07 17:04:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 17:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 17:04:05 --> Helper loaded: form_helper
INFO - 2018-02-07 17:04:05 --> Form Validation Class Initialized
INFO - 2018-02-07 17:04:05 --> Controller Class Initialized
INFO - 2018-02-07 17:04:05 --> Model Class Initialized
INFO - 2018-02-07 17:04:05 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 17:04:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 17:04:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 17:04:05 --> Model Class Initialized
INFO - 2018-02-07 17:04:05 --> Model Class Initialized
INFO - 2018-02-07 17:04:05 --> Model Class Initialized
INFO - 2018-02-07 17:04:05 --> Model Class Initialized
INFO - 2018-02-07 17:04:05 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 17:04:05 --> Final output sent to browser
DEBUG - 2018-02-07 17:04:05 --> Total execution time: 0.1121
INFO - 2018-02-07 11:34:05 --> Config Class Initialized
INFO - 2018-02-07 11:34:05 --> Hooks Class Initialized
DEBUG - 2018-02-07 11:34:05 --> UTF-8 Support Enabled
INFO - 2018-02-07 11:34:05 --> Utf8 Class Initialized
INFO - 2018-02-07 11:34:05 --> URI Class Initialized
INFO - 2018-02-07 11:34:05 --> Router Class Initialized
INFO - 2018-02-07 11:34:05 --> Output Class Initialized
INFO - 2018-02-07 11:34:05 --> Security Class Initialized
DEBUG - 2018-02-07 11:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 11:34:05 --> Input Class Initialized
INFO - 2018-02-07 11:34:05 --> Language Class Initialized
INFO - 2018-02-07 11:34:05 --> Language Class Initialized
INFO - 2018-02-07 11:34:05 --> Config Class Initialized
INFO - 2018-02-07 11:34:05 --> Loader Class Initialized
INFO - 2018-02-07 17:04:05 --> Helper loaded: url_helper
INFO - 2018-02-07 17:04:05 --> Helper loaded: notification_helper
INFO - 2018-02-07 17:04:05 --> Helper loaded: settings_helper
INFO - 2018-02-07 17:04:05 --> Helper loaded: permission_helper
INFO - 2018-02-07 17:04:05 --> Helper loaded: users_helper
INFO - 2018-02-07 17:04:05 --> Database Driver Class Initialized
DEBUG - 2018-02-07 17:04:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 17:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 17:04:05 --> Helper loaded: form_helper
INFO - 2018-02-07 17:04:05 --> Form Validation Class Initialized
INFO - 2018-02-07 17:04:05 --> Controller Class Initialized
INFO - 2018-02-07 17:04:05 --> Model Class Initialized
INFO - 2018-02-07 17:04:05 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 17:04:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 17:04:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 17:04:05 --> Model Class Initialized
INFO - 2018-02-07 17:04:05 --> Model Class Initialized
INFO - 2018-02-07 17:04:05 --> Model Class Initialized
INFO - 2018-02-07 17:04:05 --> Model Class Initialized
INFO - 2018-02-07 17:04:05 --> Model Class Initialized
INFO - 2018-02-07 17:04:05 --> Model Class Initialized
INFO - 2018-02-07 17:04:05 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 17:04:05 --> Final output sent to browser
DEBUG - 2018-02-07 17:04:05 --> Total execution time: 0.0865
INFO - 2018-02-07 11:34:11 --> Config Class Initialized
INFO - 2018-02-07 11:34:11 --> Hooks Class Initialized
DEBUG - 2018-02-07 11:34:11 --> UTF-8 Support Enabled
INFO - 2018-02-07 11:34:11 --> Utf8 Class Initialized
INFO - 2018-02-07 11:34:11 --> URI Class Initialized
INFO - 2018-02-07 11:34:11 --> Router Class Initialized
INFO - 2018-02-07 11:34:11 --> Output Class Initialized
INFO - 2018-02-07 11:34:11 --> Security Class Initialized
DEBUG - 2018-02-07 11:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 11:34:11 --> Input Class Initialized
INFO - 2018-02-07 11:34:11 --> Language Class Initialized
INFO - 2018-02-07 11:34:11 --> Language Class Initialized
INFO - 2018-02-07 11:34:11 --> Config Class Initialized
INFO - 2018-02-07 11:34:11 --> Loader Class Initialized
INFO - 2018-02-07 17:04:11 --> Helper loaded: url_helper
INFO - 2018-02-07 17:04:11 --> Helper loaded: notification_helper
INFO - 2018-02-07 17:04:11 --> Helper loaded: settings_helper
INFO - 2018-02-07 17:04:11 --> Helper loaded: permission_helper
INFO - 2018-02-07 17:04:11 --> Helper loaded: users_helper
INFO - 2018-02-07 17:04:11 --> Database Driver Class Initialized
DEBUG - 2018-02-07 17:04:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 17:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 17:04:11 --> Helper loaded: form_helper
INFO - 2018-02-07 17:04:11 --> Form Validation Class Initialized
INFO - 2018-02-07 17:04:11 --> Controller Class Initialized
INFO - 2018-02-07 17:04:11 --> Model Class Initialized
INFO - 2018-02-07 17:04:11 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 17:04:11 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 17:04:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 17:04:11 --> Model Class Initialized
INFO - 2018-02-07 17:04:11 --> Model Class Initialized
INFO - 2018-02-07 17:04:11 --> Model Class Initialized
INFO - 2018-02-07 17:04:11 --> Model Class Initialized
INFO - 2018-02-07 17:04:11 --> Model Class Initialized
INFO - 2018-02-07 17:04:11 --> Model Class Initialized
INFO - 2018-02-07 17:04:11 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 17:04:11 --> Model Class Initialized
INFO - 2018-02-07 17:04:11 --> Final output sent to browser
DEBUG - 2018-02-07 17:04:11 --> Total execution time: 0.1048
INFO - 2018-02-07 11:50:20 --> Config Class Initialized
INFO - 2018-02-07 11:50:20 --> Hooks Class Initialized
DEBUG - 2018-02-07 11:50:20 --> UTF-8 Support Enabled
INFO - 2018-02-07 11:50:20 --> Utf8 Class Initialized
INFO - 2018-02-07 11:50:20 --> URI Class Initialized
INFO - 2018-02-07 11:50:20 --> Router Class Initialized
INFO - 2018-02-07 11:50:20 --> Output Class Initialized
INFO - 2018-02-07 11:50:20 --> Security Class Initialized
DEBUG - 2018-02-07 11:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 11:50:20 --> Input Class Initialized
INFO - 2018-02-07 11:50:20 --> Language Class Initialized
INFO - 2018-02-07 11:50:20 --> Language Class Initialized
INFO - 2018-02-07 11:50:20 --> Config Class Initialized
INFO - 2018-02-07 11:50:20 --> Loader Class Initialized
INFO - 2018-02-07 17:20:20 --> Helper loaded: url_helper
INFO - 2018-02-07 17:20:20 --> Helper loaded: notification_helper
INFO - 2018-02-07 17:20:20 --> Helper loaded: settings_helper
INFO - 2018-02-07 17:20:20 --> Helper loaded: permission_helper
INFO - 2018-02-07 17:20:20 --> Helper loaded: users_helper
INFO - 2018-02-07 17:20:20 --> Database Driver Class Initialized
DEBUG - 2018-02-07 17:20:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 17:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 17:20:20 --> Helper loaded: form_helper
INFO - 2018-02-07 17:20:20 --> Form Validation Class Initialized
INFO - 2018-02-07 17:20:20 --> Controller Class Initialized
INFO - 2018-02-07 17:20:20 --> Model Class Initialized
INFO - 2018-02-07 17:20:20 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 17:20:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 17:20:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 17:20:20 --> Model Class Initialized
INFO - 2018-02-07 17:20:20 --> Model Class Initialized
INFO - 2018-02-07 17:20:20 --> Model Class Initialized
INFO - 2018-02-07 17:20:20 --> Model Class Initialized
INFO - 2018-02-07 17:20:20 --> Model Class Initialized
INFO - 2018-02-07 17:20:20 --> Model Class Initialized
INFO - 2018-02-07 17:20:20 --> Model Class Initialized
INFO - 2018-02-07 17:20:20 --> Model Class Initialized
INFO - 2018-02-07 17:20:20 --> Model Class Initialized
INFO - 2018-02-07 17:20:20 --> Model Class Initialized
INFO - 2018-02-07 17:20:20 --> Model Class Initialized
INFO - 2018-02-07 17:20:20 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 17:20:20 --> Model Class Initialized
INFO - 2018-02-07 17:20:20 --> Final output sent to browser
DEBUG - 2018-02-07 17:20:20 --> Total execution time: 0.1332
INFO - 2018-02-07 11:50:20 --> Config Class Initialized
INFO - 2018-02-07 11:50:20 --> Hooks Class Initialized
DEBUG - 2018-02-07 11:50:20 --> UTF-8 Support Enabled
INFO - 2018-02-07 11:50:20 --> Utf8 Class Initialized
INFO - 2018-02-07 11:50:20 --> URI Class Initialized
INFO - 2018-02-07 11:50:20 --> Router Class Initialized
INFO - 2018-02-07 11:50:20 --> Output Class Initialized
INFO - 2018-02-07 11:50:20 --> Security Class Initialized
DEBUG - 2018-02-07 11:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 11:50:20 --> Input Class Initialized
INFO - 2018-02-07 11:50:20 --> Language Class Initialized
INFO - 2018-02-07 11:50:20 --> Language Class Initialized
INFO - 2018-02-07 11:50:20 --> Config Class Initialized
INFO - 2018-02-07 11:50:20 --> Loader Class Initialized
INFO - 2018-02-07 17:20:20 --> Helper loaded: url_helper
INFO - 2018-02-07 17:20:20 --> Helper loaded: notification_helper
INFO - 2018-02-07 17:20:20 --> Helper loaded: settings_helper
INFO - 2018-02-07 17:20:20 --> Helper loaded: permission_helper
INFO - 2018-02-07 17:20:20 --> Helper loaded: users_helper
INFO - 2018-02-07 17:20:20 --> Database Driver Class Initialized
DEBUG - 2018-02-07 17:20:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 17:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 17:20:20 --> Helper loaded: form_helper
INFO - 2018-02-07 17:20:20 --> Form Validation Class Initialized
INFO - 2018-02-07 17:20:20 --> Controller Class Initialized
INFO - 2018-02-07 17:20:20 --> Model Class Initialized
INFO - 2018-02-07 17:20:20 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 17:20:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 17:20:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 17:20:20 --> Model Class Initialized
INFO - 2018-02-07 17:20:20 --> Model Class Initialized
INFO - 2018-02-07 17:20:20 --> Model Class Initialized
INFO - 2018-02-07 17:20:20 --> Model Class Initialized
INFO - 2018-02-07 17:20:20 --> Model Class Initialized
INFO - 2018-02-07 17:20:20 --> Model Class Initialized
INFO - 2018-02-07 17:20:20 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 17:20:20 --> Model Class Initialized
INFO - 2018-02-07 17:20:20 --> Final output sent to browser
DEBUG - 2018-02-07 17:20:20 --> Total execution time: 0.1316
INFO - 2018-02-07 11:50:22 --> Config Class Initialized
INFO - 2018-02-07 11:50:22 --> Hooks Class Initialized
DEBUG - 2018-02-07 11:50:22 --> UTF-8 Support Enabled
INFO - 2018-02-07 11:50:22 --> Utf8 Class Initialized
INFO - 2018-02-07 11:50:22 --> URI Class Initialized
INFO - 2018-02-07 11:50:22 --> Router Class Initialized
INFO - 2018-02-07 11:50:22 --> Config Class Initialized
INFO - 2018-02-07 11:50:22 --> Hooks Class Initialized
INFO - 2018-02-07 11:50:22 --> Output Class Initialized
DEBUG - 2018-02-07 11:50:22 --> UTF-8 Support Enabled
INFO - 2018-02-07 11:50:22 --> Utf8 Class Initialized
INFO - 2018-02-07 11:50:22 --> Security Class Initialized
INFO - 2018-02-07 11:50:22 --> URI Class Initialized
DEBUG - 2018-02-07 11:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 11:50:22 --> Input Class Initialized
INFO - 2018-02-07 11:50:22 --> Language Class Initialized
INFO - 2018-02-07 11:50:22 --> Router Class Initialized
INFO - 2018-02-07 11:50:22 --> Output Class Initialized
INFO - 2018-02-07 11:50:22 --> Security Class Initialized
DEBUG - 2018-02-07 11:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 11:50:22 --> Input Class Initialized
INFO - 2018-02-07 11:50:22 --> Language Class Initialized
INFO - 2018-02-07 11:50:22 --> Language Class Initialized
INFO - 2018-02-07 11:50:22 --> Config Class Initialized
INFO - 2018-02-07 11:50:22 --> Loader Class Initialized
INFO - 2018-02-07 17:20:22 --> Helper loaded: url_helper
INFO - 2018-02-07 17:20:22 --> Helper loaded: notification_helper
INFO - 2018-02-07 17:20:22 --> Helper loaded: settings_helper
INFO - 2018-02-07 17:20:22 --> Helper loaded: permission_helper
INFO - 2018-02-07 17:20:22 --> Helper loaded: users_helper
INFO - 2018-02-07 11:50:22 --> Language Class Initialized
INFO - 2018-02-07 11:50:22 --> Config Class Initialized
INFO - 2018-02-07 11:50:22 --> Loader Class Initialized
INFO - 2018-02-07 17:20:22 --> Helper loaded: url_helper
INFO - 2018-02-07 17:20:22 --> Helper loaded: notification_helper
INFO - 2018-02-07 17:20:22 --> Helper loaded: settings_helper
INFO - 2018-02-07 17:20:22 --> Helper loaded: permission_helper
INFO - 2018-02-07 17:20:22 --> Helper loaded: users_helper
INFO - 2018-02-07 17:20:22 --> Database Driver Class Initialized
DEBUG - 2018-02-07 17:20:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 17:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 17:20:22 --> Helper loaded: form_helper
INFO - 2018-02-07 17:20:22 --> Form Validation Class Initialized
INFO - 2018-02-07 17:20:22 --> Controller Class Initialized
INFO - 2018-02-07 17:20:22 --> Database Driver Class Initialized
DEBUG - 2018-02-07 17:20:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 17:20:22 --> Model Class Initialized
INFO - 2018-02-07 17:20:22 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 17:20:22 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 17:20:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 17:20:22 --> Model Class Initialized
INFO - 2018-02-07 17:20:22 --> Model Class Initialized
INFO - 2018-02-07 17:20:22 --> Model Class Initialized
INFO - 2018-02-07 17:20:22 --> Model Class Initialized
INFO - 2018-02-07 17:20:22 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 17:20:22 --> Final output sent to browser
DEBUG - 2018-02-07 17:20:22 --> Total execution time: 0.1106
INFO - 2018-02-07 17:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 17:20:22 --> Helper loaded: form_helper
INFO - 2018-02-07 17:20:22 --> Form Validation Class Initialized
INFO - 2018-02-07 17:20:22 --> Controller Class Initialized
INFO - 2018-02-07 17:20:22 --> Model Class Initialized
INFO - 2018-02-07 17:20:22 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 17:20:22 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 17:20:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 17:20:22 --> Model Class Initialized
INFO - 2018-02-07 17:20:22 --> Model Class Initialized
INFO - 2018-02-07 17:20:22 --> Model Class Initialized
INFO - 2018-02-07 17:20:22 --> Model Class Initialized
INFO - 2018-02-07 17:20:22 --> Model Class Initialized
INFO - 2018-02-07 17:20:22 --> Model Class Initialized
INFO - 2018-02-07 17:20:22 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 17:20:22 --> Final output sent to browser
DEBUG - 2018-02-07 17:20:22 --> Total execution time: 0.1461
INFO - 2018-02-07 11:50:25 --> Config Class Initialized
INFO - 2018-02-07 11:50:25 --> Hooks Class Initialized
DEBUG - 2018-02-07 11:50:25 --> UTF-8 Support Enabled
INFO - 2018-02-07 11:50:25 --> Utf8 Class Initialized
INFO - 2018-02-07 11:50:25 --> URI Class Initialized
INFO - 2018-02-07 11:50:25 --> Router Class Initialized
INFO - 2018-02-07 11:50:25 --> Output Class Initialized
INFO - 2018-02-07 11:50:25 --> Security Class Initialized
DEBUG - 2018-02-07 11:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 11:50:25 --> Input Class Initialized
INFO - 2018-02-07 11:50:25 --> Language Class Initialized
INFO - 2018-02-07 11:50:25 --> Language Class Initialized
INFO - 2018-02-07 11:50:25 --> Config Class Initialized
INFO - 2018-02-07 11:50:25 --> Loader Class Initialized
INFO - 2018-02-07 17:20:25 --> Helper loaded: url_helper
INFO - 2018-02-07 17:20:25 --> Helper loaded: notification_helper
INFO - 2018-02-07 17:20:25 --> Helper loaded: settings_helper
INFO - 2018-02-07 17:20:25 --> Helper loaded: permission_helper
INFO - 2018-02-07 17:20:25 --> Helper loaded: users_helper
INFO - 2018-02-07 17:20:25 --> Database Driver Class Initialized
DEBUG - 2018-02-07 17:20:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 17:20:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 17:20:25 --> Helper loaded: form_helper
INFO - 2018-02-07 17:20:25 --> Form Validation Class Initialized
INFO - 2018-02-07 17:20:25 --> Controller Class Initialized
INFO - 2018-02-07 17:20:25 --> Model Class Initialized
INFO - 2018-02-07 17:20:25 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 17:20:25 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 17:20:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 17:20:25 --> Model Class Initialized
INFO - 2018-02-07 17:20:25 --> Model Class Initialized
INFO - 2018-02-07 17:20:25 --> Model Class Initialized
INFO - 2018-02-07 17:20:25 --> Model Class Initialized
INFO - 2018-02-07 17:20:25 --> Model Class Initialized
INFO - 2018-02-07 17:20:25 --> Model Class Initialized
INFO - 2018-02-07 17:20:25 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 17:20:25 --> Model Class Initialized
INFO - 2018-02-07 17:20:25 --> Final output sent to browser
DEBUG - 2018-02-07 17:20:25 --> Total execution time: 0.1247
INFO - 2018-02-07 11:52:19 --> Config Class Initialized
INFO - 2018-02-07 11:52:19 --> Hooks Class Initialized
DEBUG - 2018-02-07 11:52:19 --> UTF-8 Support Enabled
INFO - 2018-02-07 11:52:19 --> Utf8 Class Initialized
INFO - 2018-02-07 11:52:19 --> URI Class Initialized
INFO - 2018-02-07 11:52:19 --> Router Class Initialized
INFO - 2018-02-07 11:52:19 --> Output Class Initialized
INFO - 2018-02-07 11:52:19 --> Security Class Initialized
DEBUG - 2018-02-07 11:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 11:52:19 --> Input Class Initialized
INFO - 2018-02-07 11:52:19 --> Language Class Initialized
INFO - 2018-02-07 11:52:19 --> Language Class Initialized
INFO - 2018-02-07 11:52:19 --> Config Class Initialized
INFO - 2018-02-07 11:52:19 --> Loader Class Initialized
INFO - 2018-02-07 17:22:19 --> Helper loaded: url_helper
INFO - 2018-02-07 17:22:19 --> Helper loaded: notification_helper
INFO - 2018-02-07 17:22:19 --> Helper loaded: settings_helper
INFO - 2018-02-07 17:22:19 --> Helper loaded: permission_helper
INFO - 2018-02-07 17:22:19 --> Helper loaded: users_helper
INFO - 2018-02-07 17:22:19 --> Database Driver Class Initialized
DEBUG - 2018-02-07 17:22:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 17:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 17:22:19 --> Helper loaded: form_helper
INFO - 2018-02-07 17:22:19 --> Form Validation Class Initialized
INFO - 2018-02-07 17:22:19 --> Controller Class Initialized
INFO - 2018-02-07 17:22:19 --> Model Class Initialized
INFO - 2018-02-07 17:22:19 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 17:22:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 17:22:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 17:22:19 --> Model Class Initialized
INFO - 2018-02-07 17:22:19 --> Model Class Initialized
INFO - 2018-02-07 17:22:19 --> Model Class Initialized
INFO - 2018-02-07 17:22:19 --> Model Class Initialized
INFO - 2018-02-07 17:22:19 --> Model Class Initialized
INFO - 2018-02-07 17:22:19 --> Model Class Initialized
INFO - 2018-02-07 17:22:19 --> Model Class Initialized
INFO - 2018-02-07 17:22:19 --> Model Class Initialized
INFO - 2018-02-07 17:22:19 --> Model Class Initialized
INFO - 2018-02-07 17:22:19 --> Model Class Initialized
INFO - 2018-02-07 17:22:19 --> Model Class Initialized
INFO - 2018-02-07 17:22:19 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 17:22:19 --> Model Class Initialized
INFO - 2018-02-07 17:22:19 --> Final output sent to browser
DEBUG - 2018-02-07 17:22:19 --> Total execution time: 0.1290
INFO - 2018-02-07 11:52:20 --> Config Class Initialized
INFO - 2018-02-07 11:52:20 --> Hooks Class Initialized
DEBUG - 2018-02-07 11:52:20 --> UTF-8 Support Enabled
INFO - 2018-02-07 11:52:20 --> Utf8 Class Initialized
INFO - 2018-02-07 11:52:20 --> URI Class Initialized
INFO - 2018-02-07 11:52:20 --> Router Class Initialized
INFO - 2018-02-07 11:52:20 --> Output Class Initialized
INFO - 2018-02-07 11:52:20 --> Security Class Initialized
DEBUG - 2018-02-07 11:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 11:52:20 --> Input Class Initialized
INFO - 2018-02-07 11:52:20 --> Language Class Initialized
INFO - 2018-02-07 11:52:20 --> Language Class Initialized
INFO - 2018-02-07 11:52:20 --> Config Class Initialized
INFO - 2018-02-07 11:52:20 --> Loader Class Initialized
INFO - 2018-02-07 17:22:20 --> Helper loaded: url_helper
INFO - 2018-02-07 17:22:20 --> Helper loaded: notification_helper
INFO - 2018-02-07 17:22:20 --> Helper loaded: settings_helper
INFO - 2018-02-07 17:22:20 --> Helper loaded: permission_helper
INFO - 2018-02-07 17:22:20 --> Helper loaded: users_helper
INFO - 2018-02-07 17:22:20 --> Database Driver Class Initialized
DEBUG - 2018-02-07 17:22:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 17:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 17:22:20 --> Helper loaded: form_helper
INFO - 2018-02-07 17:22:20 --> Form Validation Class Initialized
INFO - 2018-02-07 17:22:20 --> Controller Class Initialized
INFO - 2018-02-07 17:22:20 --> Model Class Initialized
INFO - 2018-02-07 17:22:20 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 17:22:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 17:22:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 17:22:20 --> Model Class Initialized
INFO - 2018-02-07 17:22:20 --> Model Class Initialized
INFO - 2018-02-07 17:22:20 --> Model Class Initialized
INFO - 2018-02-07 17:22:20 --> Model Class Initialized
INFO - 2018-02-07 17:22:20 --> Model Class Initialized
INFO - 2018-02-07 17:22:20 --> Model Class Initialized
INFO - 2018-02-07 17:22:20 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 17:22:20 --> Model Class Initialized
INFO - 2018-02-07 17:22:20 --> Final output sent to browser
DEBUG - 2018-02-07 17:22:20 --> Total execution time: 0.1109
INFO - 2018-02-07 11:52:23 --> Config Class Initialized
INFO - 2018-02-07 11:52:23 --> Hooks Class Initialized
DEBUG - 2018-02-07 11:52:23 --> UTF-8 Support Enabled
INFO - 2018-02-07 11:52:23 --> Utf8 Class Initialized
INFO - 2018-02-07 11:52:23 --> URI Class Initialized
INFO - 2018-02-07 11:52:23 --> Router Class Initialized
INFO - 2018-02-07 11:52:23 --> Output Class Initialized
INFO - 2018-02-07 11:52:23 --> Security Class Initialized
DEBUG - 2018-02-07 11:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 11:52:23 --> Input Class Initialized
INFO - 2018-02-07 11:52:23 --> Language Class Initialized
INFO - 2018-02-07 11:52:23 --> Language Class Initialized
INFO - 2018-02-07 11:52:23 --> Config Class Initialized
INFO - 2018-02-07 11:52:23 --> Loader Class Initialized
INFO - 2018-02-07 17:22:23 --> Helper loaded: url_helper
INFO - 2018-02-07 17:22:23 --> Helper loaded: notification_helper
INFO - 2018-02-07 17:22:23 --> Helper loaded: settings_helper
INFO - 2018-02-07 17:22:23 --> Helper loaded: permission_helper
INFO - 2018-02-07 17:22:23 --> Helper loaded: users_helper
INFO - 2018-02-07 17:22:23 --> Database Driver Class Initialized
DEBUG - 2018-02-07 17:22:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 17:22:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 17:22:23 --> Helper loaded: form_helper
INFO - 2018-02-07 17:22:23 --> Form Validation Class Initialized
INFO - 2018-02-07 17:22:23 --> Controller Class Initialized
INFO - 2018-02-07 17:22:23 --> Model Class Initialized
INFO - 2018-02-07 17:22:23 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 17:22:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 17:22:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 17:22:23 --> Model Class Initialized
INFO - 2018-02-07 17:22:23 --> Model Class Initialized
INFO - 2018-02-07 17:22:23 --> Model Class Initialized
INFO - 2018-02-07 17:22:23 --> Model Class Initialized
INFO - 2018-02-07 17:22:23 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 17:22:23 --> Final output sent to browser
DEBUG - 2018-02-07 17:22:23 --> Total execution time: 0.0787
INFO - 2018-02-07 11:52:23 --> Config Class Initialized
INFO - 2018-02-07 11:52:23 --> Hooks Class Initialized
DEBUG - 2018-02-07 11:52:23 --> UTF-8 Support Enabled
INFO - 2018-02-07 11:52:23 --> Utf8 Class Initialized
INFO - 2018-02-07 11:52:23 --> URI Class Initialized
INFO - 2018-02-07 11:52:23 --> Router Class Initialized
INFO - 2018-02-07 11:52:23 --> Output Class Initialized
INFO - 2018-02-07 11:52:23 --> Security Class Initialized
DEBUG - 2018-02-07 11:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 11:52:23 --> Input Class Initialized
INFO - 2018-02-07 11:52:23 --> Language Class Initialized
INFO - 2018-02-07 11:52:23 --> Language Class Initialized
INFO - 2018-02-07 11:52:23 --> Config Class Initialized
INFO - 2018-02-07 11:52:23 --> Loader Class Initialized
INFO - 2018-02-07 17:22:23 --> Helper loaded: url_helper
INFO - 2018-02-07 17:22:23 --> Helper loaded: notification_helper
INFO - 2018-02-07 17:22:23 --> Helper loaded: settings_helper
INFO - 2018-02-07 17:22:23 --> Helper loaded: permission_helper
INFO - 2018-02-07 17:22:23 --> Helper loaded: users_helper
INFO - 2018-02-07 17:22:23 --> Database Driver Class Initialized
DEBUG - 2018-02-07 17:22:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 17:22:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 17:22:23 --> Helper loaded: form_helper
INFO - 2018-02-07 17:22:23 --> Form Validation Class Initialized
INFO - 2018-02-07 17:22:23 --> Controller Class Initialized
INFO - 2018-02-07 17:22:23 --> Model Class Initialized
INFO - 2018-02-07 17:22:23 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 17:22:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 17:22:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 17:22:23 --> Model Class Initialized
INFO - 2018-02-07 17:22:23 --> Model Class Initialized
INFO - 2018-02-07 17:22:23 --> Model Class Initialized
INFO - 2018-02-07 17:22:23 --> Model Class Initialized
INFO - 2018-02-07 17:22:23 --> Model Class Initialized
INFO - 2018-02-07 17:22:23 --> Model Class Initialized
INFO - 2018-02-07 17:22:23 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 17:22:23 --> Final output sent to browser
DEBUG - 2018-02-07 17:22:23 --> Total execution time: 0.1100
INFO - 2018-02-07 11:52:26 --> Config Class Initialized
INFO - 2018-02-07 11:52:26 --> Hooks Class Initialized
DEBUG - 2018-02-07 11:52:26 --> UTF-8 Support Enabled
INFO - 2018-02-07 11:52:26 --> Utf8 Class Initialized
INFO - 2018-02-07 11:52:26 --> URI Class Initialized
INFO - 2018-02-07 11:52:26 --> Router Class Initialized
INFO - 2018-02-07 11:52:26 --> Output Class Initialized
INFO - 2018-02-07 11:52:26 --> Security Class Initialized
DEBUG - 2018-02-07 11:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 11:52:26 --> Input Class Initialized
INFO - 2018-02-07 11:52:26 --> Language Class Initialized
INFO - 2018-02-07 11:52:26 --> Language Class Initialized
INFO - 2018-02-07 11:52:26 --> Config Class Initialized
INFO - 2018-02-07 11:52:26 --> Loader Class Initialized
INFO - 2018-02-07 17:22:26 --> Helper loaded: url_helper
INFO - 2018-02-07 17:22:26 --> Helper loaded: notification_helper
INFO - 2018-02-07 17:22:26 --> Helper loaded: settings_helper
INFO - 2018-02-07 17:22:26 --> Helper loaded: permission_helper
INFO - 2018-02-07 17:22:26 --> Helper loaded: users_helper
INFO - 2018-02-07 17:22:26 --> Database Driver Class Initialized
DEBUG - 2018-02-07 17:22:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 17:22:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 17:22:26 --> Helper loaded: form_helper
INFO - 2018-02-07 17:22:26 --> Form Validation Class Initialized
INFO - 2018-02-07 17:22:26 --> Controller Class Initialized
INFO - 2018-02-07 17:22:26 --> Model Class Initialized
INFO - 2018-02-07 17:22:26 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 17:22:26 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 17:22:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 17:22:26 --> Model Class Initialized
INFO - 2018-02-07 17:22:26 --> Model Class Initialized
INFO - 2018-02-07 17:22:26 --> Model Class Initialized
INFO - 2018-02-07 17:22:26 --> Model Class Initialized
INFO - 2018-02-07 17:22:26 --> Model Class Initialized
INFO - 2018-02-07 17:22:26 --> Model Class Initialized
INFO - 2018-02-07 17:22:26 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 17:22:26 --> Model Class Initialized
INFO - 2018-02-07 17:22:26 --> Final output sent to browser
DEBUG - 2018-02-07 17:22:26 --> Total execution time: 0.1202
INFO - 2018-02-07 11:54:37 --> Config Class Initialized
INFO - 2018-02-07 11:54:37 --> Hooks Class Initialized
DEBUG - 2018-02-07 11:54:37 --> UTF-8 Support Enabled
INFO - 2018-02-07 11:54:37 --> Utf8 Class Initialized
INFO - 2018-02-07 11:54:37 --> URI Class Initialized
INFO - 2018-02-07 11:54:37 --> Router Class Initialized
INFO - 2018-02-07 11:54:37 --> Output Class Initialized
INFO - 2018-02-07 11:54:37 --> Security Class Initialized
DEBUG - 2018-02-07 11:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 11:54:37 --> Input Class Initialized
INFO - 2018-02-07 11:54:37 --> Language Class Initialized
INFO - 2018-02-07 11:54:37 --> Language Class Initialized
INFO - 2018-02-07 11:54:37 --> Config Class Initialized
INFO - 2018-02-07 11:54:37 --> Loader Class Initialized
INFO - 2018-02-07 17:24:37 --> Helper loaded: url_helper
INFO - 2018-02-07 17:24:37 --> Helper loaded: notification_helper
INFO - 2018-02-07 17:24:37 --> Helper loaded: settings_helper
INFO - 2018-02-07 17:24:37 --> Helper loaded: permission_helper
INFO - 2018-02-07 17:24:37 --> Helper loaded: users_helper
INFO - 2018-02-07 17:24:37 --> Database Driver Class Initialized
DEBUG - 2018-02-07 17:24:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 17:24:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 17:24:37 --> Helper loaded: form_helper
INFO - 2018-02-07 17:24:37 --> Form Validation Class Initialized
INFO - 2018-02-07 17:24:37 --> Controller Class Initialized
INFO - 2018-02-07 17:24:37 --> Model Class Initialized
INFO - 2018-02-07 17:24:37 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 17:24:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 17:24:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 17:24:37 --> Model Class Initialized
INFO - 2018-02-07 17:24:37 --> Model Class Initialized
INFO - 2018-02-07 17:24:37 --> Model Class Initialized
INFO - 2018-02-07 17:24:37 --> Model Class Initialized
INFO - 2018-02-07 17:24:37 --> Model Class Initialized
INFO - 2018-02-07 17:24:37 --> Model Class Initialized
INFO - 2018-02-07 17:24:37 --> Model Class Initialized
INFO - 2018-02-07 17:24:37 --> Model Class Initialized
INFO - 2018-02-07 17:24:37 --> Model Class Initialized
INFO - 2018-02-07 17:24:37 --> Model Class Initialized
INFO - 2018-02-07 17:24:37 --> Model Class Initialized
INFO - 2018-02-07 17:24:37 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 17:24:37 --> Model Class Initialized
INFO - 2018-02-07 17:24:37 --> Final output sent to browser
DEBUG - 2018-02-07 17:24:37 --> Total execution time: 0.2511
INFO - 2018-02-07 11:54:37 --> Config Class Initialized
INFO - 2018-02-07 11:54:37 --> Hooks Class Initialized
DEBUG - 2018-02-07 11:54:37 --> UTF-8 Support Enabled
INFO - 2018-02-07 11:54:37 --> Utf8 Class Initialized
INFO - 2018-02-07 11:54:37 --> URI Class Initialized
INFO - 2018-02-07 11:54:37 --> Router Class Initialized
INFO - 2018-02-07 11:54:37 --> Output Class Initialized
INFO - 2018-02-07 11:54:37 --> Security Class Initialized
DEBUG - 2018-02-07 11:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 11:54:37 --> Input Class Initialized
INFO - 2018-02-07 11:54:37 --> Language Class Initialized
INFO - 2018-02-07 11:54:37 --> Language Class Initialized
INFO - 2018-02-07 11:54:37 --> Config Class Initialized
INFO - 2018-02-07 11:54:37 --> Loader Class Initialized
INFO - 2018-02-07 17:24:37 --> Helper loaded: url_helper
INFO - 2018-02-07 17:24:37 --> Helper loaded: notification_helper
INFO - 2018-02-07 17:24:37 --> Helper loaded: settings_helper
INFO - 2018-02-07 17:24:37 --> Helper loaded: permission_helper
INFO - 2018-02-07 17:24:37 --> Helper loaded: users_helper
INFO - 2018-02-07 17:24:37 --> Database Driver Class Initialized
DEBUG - 2018-02-07 17:24:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 17:24:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 17:24:37 --> Helper loaded: form_helper
INFO - 2018-02-07 17:24:37 --> Form Validation Class Initialized
INFO - 2018-02-07 17:24:37 --> Controller Class Initialized
INFO - 2018-02-07 17:24:37 --> Model Class Initialized
INFO - 2018-02-07 17:24:37 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 17:24:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 17:24:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 17:24:37 --> Model Class Initialized
INFO - 2018-02-07 17:24:37 --> Model Class Initialized
INFO - 2018-02-07 17:24:37 --> Model Class Initialized
INFO - 2018-02-07 17:24:37 --> Model Class Initialized
INFO - 2018-02-07 17:24:37 --> Model Class Initialized
INFO - 2018-02-07 17:24:37 --> Model Class Initialized
INFO - 2018-02-07 17:24:37 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 17:24:37 --> Model Class Initialized
INFO - 2018-02-07 17:24:37 --> Final output sent to browser
DEBUG - 2018-02-07 17:24:37 --> Total execution time: 0.1144
INFO - 2018-02-07 11:54:41 --> Config Class Initialized
INFO - 2018-02-07 11:54:41 --> Hooks Class Initialized
DEBUG - 2018-02-07 11:54:41 --> UTF-8 Support Enabled
INFO - 2018-02-07 11:54:41 --> Utf8 Class Initialized
INFO - 2018-02-07 11:54:41 --> URI Class Initialized
INFO - 2018-02-07 11:54:41 --> Config Class Initialized
INFO - 2018-02-07 11:54:41 --> Hooks Class Initialized
INFO - 2018-02-07 11:54:41 --> Router Class Initialized
DEBUG - 2018-02-07 11:54:41 --> UTF-8 Support Enabled
INFO - 2018-02-07 11:54:41 --> Utf8 Class Initialized
INFO - 2018-02-07 11:54:41 --> Output Class Initialized
INFO - 2018-02-07 11:54:41 --> URI Class Initialized
INFO - 2018-02-07 11:54:41 --> Security Class Initialized
DEBUG - 2018-02-07 11:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 11:54:41 --> Input Class Initialized
INFO - 2018-02-07 11:54:41 --> Language Class Initialized
INFO - 2018-02-07 11:54:41 --> Router Class Initialized
INFO - 2018-02-07 11:54:41 --> Output Class Initialized
INFO - 2018-02-07 11:54:41 --> Language Class Initialized
INFO - 2018-02-07 11:54:41 --> Config Class Initialized
INFO - 2018-02-07 11:54:41 --> Loader Class Initialized
INFO - 2018-02-07 17:24:41 --> Helper loaded: url_helper
INFO - 2018-02-07 17:24:41 --> Helper loaded: notification_helper
INFO - 2018-02-07 17:24:41 --> Helper loaded: settings_helper
INFO - 2018-02-07 11:54:41 --> Security Class Initialized
INFO - 2018-02-07 17:24:41 --> Helper loaded: permission_helper
INFO - 2018-02-07 17:24:41 --> Helper loaded: users_helper
DEBUG - 2018-02-07 11:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 11:54:41 --> Input Class Initialized
INFO - 2018-02-07 11:54:41 --> Language Class Initialized
INFO - 2018-02-07 17:24:41 --> Database Driver Class Initialized
DEBUG - 2018-02-07 17:24:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 17:24:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 17:24:41 --> Helper loaded: form_helper
INFO - 2018-02-07 17:24:41 --> Form Validation Class Initialized
INFO - 2018-02-07 17:24:41 --> Controller Class Initialized
INFO - 2018-02-07 17:24:41 --> Model Class Initialized
INFO - 2018-02-07 17:24:41 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 17:24:41 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 17:24:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 17:24:41 --> Model Class Initialized
INFO - 2018-02-07 17:24:41 --> Model Class Initialized
INFO - 2018-02-07 17:24:41 --> Model Class Initialized
INFO - 2018-02-07 17:24:41 --> Model Class Initialized
INFO - 2018-02-07 17:24:41 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 17:24:41 --> Final output sent to browser
DEBUG - 2018-02-07 17:24:41 --> Total execution time: 0.0741
INFO - 2018-02-07 11:54:41 --> Language Class Initialized
INFO - 2018-02-07 11:54:41 --> Config Class Initialized
INFO - 2018-02-07 11:54:41 --> Loader Class Initialized
INFO - 2018-02-07 17:24:41 --> Helper loaded: url_helper
INFO - 2018-02-07 17:24:41 --> Helper loaded: notification_helper
INFO - 2018-02-07 17:24:41 --> Helper loaded: settings_helper
INFO - 2018-02-07 17:24:41 --> Helper loaded: permission_helper
INFO - 2018-02-07 17:24:41 --> Helper loaded: users_helper
INFO - 2018-02-07 17:24:41 --> Database Driver Class Initialized
DEBUG - 2018-02-07 17:24:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 17:24:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 17:24:41 --> Helper loaded: form_helper
INFO - 2018-02-07 17:24:41 --> Form Validation Class Initialized
INFO - 2018-02-07 17:24:41 --> Controller Class Initialized
INFO - 2018-02-07 17:24:41 --> Model Class Initialized
INFO - 2018-02-07 17:24:41 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 17:24:41 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 17:24:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 17:24:41 --> Model Class Initialized
INFO - 2018-02-07 17:24:41 --> Model Class Initialized
INFO - 2018-02-07 17:24:41 --> Model Class Initialized
INFO - 2018-02-07 17:24:41 --> Model Class Initialized
INFO - 2018-02-07 17:24:41 --> Model Class Initialized
INFO - 2018-02-07 17:24:41 --> Model Class Initialized
INFO - 2018-02-07 17:24:41 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 17:24:41 --> Final output sent to browser
DEBUG - 2018-02-07 17:24:41 --> Total execution time: 0.1568
INFO - 2018-02-07 11:54:44 --> Config Class Initialized
INFO - 2018-02-07 11:54:44 --> Hooks Class Initialized
DEBUG - 2018-02-07 11:54:44 --> UTF-8 Support Enabled
INFO - 2018-02-07 11:54:44 --> Utf8 Class Initialized
INFO - 2018-02-07 11:54:44 --> URI Class Initialized
INFO - 2018-02-07 11:54:44 --> Router Class Initialized
INFO - 2018-02-07 11:54:44 --> Output Class Initialized
INFO - 2018-02-07 11:54:44 --> Security Class Initialized
DEBUG - 2018-02-07 11:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 11:54:44 --> Input Class Initialized
INFO - 2018-02-07 11:54:44 --> Language Class Initialized
INFO - 2018-02-07 11:54:44 --> Language Class Initialized
INFO - 2018-02-07 11:54:44 --> Config Class Initialized
INFO - 2018-02-07 11:54:44 --> Loader Class Initialized
INFO - 2018-02-07 17:24:44 --> Helper loaded: url_helper
INFO - 2018-02-07 17:24:44 --> Helper loaded: notification_helper
INFO - 2018-02-07 17:24:44 --> Helper loaded: settings_helper
INFO - 2018-02-07 17:24:44 --> Helper loaded: permission_helper
INFO - 2018-02-07 17:24:44 --> Helper loaded: users_helper
INFO - 2018-02-07 17:24:44 --> Database Driver Class Initialized
DEBUG - 2018-02-07 17:24:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 17:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 17:24:44 --> Helper loaded: form_helper
INFO - 2018-02-07 17:24:44 --> Form Validation Class Initialized
INFO - 2018-02-07 17:24:44 --> Controller Class Initialized
INFO - 2018-02-07 17:24:44 --> Model Class Initialized
INFO - 2018-02-07 17:24:44 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 17:24:44 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 17:24:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 17:24:44 --> Model Class Initialized
INFO - 2018-02-07 17:24:44 --> Model Class Initialized
INFO - 2018-02-07 17:24:44 --> Model Class Initialized
INFO - 2018-02-07 17:24:44 --> Model Class Initialized
INFO - 2018-02-07 17:24:44 --> Model Class Initialized
INFO - 2018-02-07 17:24:44 --> Model Class Initialized
INFO - 2018-02-07 17:24:44 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 17:24:44 --> Model Class Initialized
INFO - 2018-02-07 17:24:44 --> Final output sent to browser
DEBUG - 2018-02-07 17:24:45 --> Total execution time: 0.1211
INFO - 2018-02-07 11:58:58 --> Config Class Initialized
INFO - 2018-02-07 11:58:58 --> Hooks Class Initialized
DEBUG - 2018-02-07 11:58:58 --> UTF-8 Support Enabled
INFO - 2018-02-07 11:58:58 --> Utf8 Class Initialized
INFO - 2018-02-07 11:58:58 --> URI Class Initialized
INFO - 2018-02-07 11:58:58 --> Router Class Initialized
INFO - 2018-02-07 11:58:58 --> Output Class Initialized
INFO - 2018-02-07 11:58:58 --> Security Class Initialized
DEBUG - 2018-02-07 11:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 11:58:58 --> Input Class Initialized
INFO - 2018-02-07 11:58:58 --> Language Class Initialized
INFO - 2018-02-07 11:58:58 --> Language Class Initialized
INFO - 2018-02-07 11:58:58 --> Config Class Initialized
INFO - 2018-02-07 11:58:58 --> Loader Class Initialized
INFO - 2018-02-07 17:28:58 --> Helper loaded: url_helper
INFO - 2018-02-07 17:28:58 --> Helper loaded: notification_helper
INFO - 2018-02-07 17:28:58 --> Helper loaded: settings_helper
INFO - 2018-02-07 17:28:58 --> Helper loaded: permission_helper
INFO - 2018-02-07 17:28:58 --> Helper loaded: users_helper
INFO - 2018-02-07 17:28:58 --> Database Driver Class Initialized
DEBUG - 2018-02-07 17:28:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 17:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 17:28:58 --> Helper loaded: form_helper
INFO - 2018-02-07 17:28:58 --> Form Validation Class Initialized
INFO - 2018-02-07 17:28:58 --> Controller Class Initialized
INFO - 2018-02-07 17:28:58 --> Model Class Initialized
INFO - 2018-02-07 17:28:58 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 17:28:58 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 17:28:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 17:28:58 --> Model Class Initialized
INFO - 2018-02-07 17:28:58 --> Model Class Initialized
INFO - 2018-02-07 17:28:58 --> Model Class Initialized
INFO - 2018-02-07 17:28:58 --> Model Class Initialized
INFO - 2018-02-07 17:28:58 --> Model Class Initialized
INFO - 2018-02-07 17:28:58 --> Model Class Initialized
INFO - 2018-02-07 17:28:58 --> Model Class Initialized
INFO - 2018-02-07 17:28:58 --> Model Class Initialized
INFO - 2018-02-07 17:28:58 --> Model Class Initialized
INFO - 2018-02-07 17:28:58 --> Model Class Initialized
INFO - 2018-02-07 17:28:58 --> Model Class Initialized
INFO - 2018-02-07 17:28:58 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 17:28:58 --> Model Class Initialized
INFO - 2018-02-07 17:28:58 --> Final output sent to browser
DEBUG - 2018-02-07 17:28:58 --> Total execution time: 0.1170
INFO - 2018-02-07 11:58:58 --> Config Class Initialized
INFO - 2018-02-07 11:58:58 --> Hooks Class Initialized
DEBUG - 2018-02-07 11:58:58 --> UTF-8 Support Enabled
INFO - 2018-02-07 11:58:58 --> Utf8 Class Initialized
INFO - 2018-02-07 11:58:58 --> URI Class Initialized
INFO - 2018-02-07 11:58:58 --> Router Class Initialized
INFO - 2018-02-07 11:58:58 --> Output Class Initialized
INFO - 2018-02-07 11:58:58 --> Security Class Initialized
DEBUG - 2018-02-07 11:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 11:58:58 --> Input Class Initialized
INFO - 2018-02-07 11:58:58 --> Language Class Initialized
INFO - 2018-02-07 11:58:58 --> Language Class Initialized
INFO - 2018-02-07 11:58:58 --> Config Class Initialized
INFO - 2018-02-07 11:58:58 --> Loader Class Initialized
INFO - 2018-02-07 17:28:58 --> Helper loaded: url_helper
INFO - 2018-02-07 17:28:58 --> Helper loaded: notification_helper
INFO - 2018-02-07 17:28:58 --> Helper loaded: settings_helper
INFO - 2018-02-07 17:28:58 --> Helper loaded: permission_helper
INFO - 2018-02-07 17:28:58 --> Helper loaded: users_helper
INFO - 2018-02-07 17:28:58 --> Database Driver Class Initialized
DEBUG - 2018-02-07 17:28:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 17:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 17:28:58 --> Helper loaded: form_helper
INFO - 2018-02-07 17:28:58 --> Form Validation Class Initialized
INFO - 2018-02-07 17:28:58 --> Controller Class Initialized
INFO - 2018-02-07 17:28:58 --> Model Class Initialized
INFO - 2018-02-07 17:28:58 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 17:28:58 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 17:28:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 17:28:58 --> Model Class Initialized
INFO - 2018-02-07 17:28:58 --> Model Class Initialized
INFO - 2018-02-07 17:28:58 --> Model Class Initialized
INFO - 2018-02-07 17:28:58 --> Model Class Initialized
INFO - 2018-02-07 17:28:58 --> Model Class Initialized
INFO - 2018-02-07 17:28:58 --> Model Class Initialized
INFO - 2018-02-07 17:28:58 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 17:28:58 --> Model Class Initialized
INFO - 2018-02-07 17:28:58 --> Final output sent to browser
DEBUG - 2018-02-07 17:28:58 --> Total execution time: 0.0744
INFO - 2018-02-07 11:59:02 --> Config Class Initialized
INFO - 2018-02-07 11:59:02 --> Hooks Class Initialized
INFO - 2018-02-07 11:59:02 --> Config Class Initialized
INFO - 2018-02-07 11:59:02 --> Hooks Class Initialized
DEBUG - 2018-02-07 11:59:02 --> UTF-8 Support Enabled
INFO - 2018-02-07 11:59:02 --> Utf8 Class Initialized
DEBUG - 2018-02-07 11:59:02 --> UTF-8 Support Enabled
INFO - 2018-02-07 11:59:02 --> Utf8 Class Initialized
INFO - 2018-02-07 11:59:02 --> URI Class Initialized
INFO - 2018-02-07 11:59:02 --> URI Class Initialized
INFO - 2018-02-07 11:59:02 --> Router Class Initialized
INFO - 2018-02-07 11:59:02 --> Router Class Initialized
INFO - 2018-02-07 11:59:02 --> Output Class Initialized
INFO - 2018-02-07 11:59:02 --> Output Class Initialized
INFO - 2018-02-07 11:59:02 --> Security Class Initialized
INFO - 2018-02-07 11:59:02 --> Security Class Initialized
DEBUG - 2018-02-07 11:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 11:59:02 --> Input Class Initialized
INFO - 2018-02-07 11:59:02 --> Language Class Initialized
DEBUG - 2018-02-07 11:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 11:59:02 --> Input Class Initialized
INFO - 2018-02-07 11:59:02 --> Language Class Initialized
INFO - 2018-02-07 11:59:02 --> Language Class Initialized
INFO - 2018-02-07 11:59:02 --> Config Class Initialized
INFO - 2018-02-07 11:59:02 --> Loader Class Initialized
INFO - 2018-02-07 11:59:02 --> Language Class Initialized
INFO - 2018-02-07 11:59:02 --> Config Class Initialized
INFO - 2018-02-07 11:59:02 --> Loader Class Initialized
INFO - 2018-02-07 17:29:02 --> Helper loaded: url_helper
INFO - 2018-02-07 17:29:02 --> Helper loaded: notification_helper
INFO - 2018-02-07 17:29:02 --> Helper loaded: settings_helper
INFO - 2018-02-07 17:29:02 --> Helper loaded: url_helper
INFO - 2018-02-07 17:29:02 --> Helper loaded: permission_helper
INFO - 2018-02-07 17:29:02 --> Helper loaded: users_helper
INFO - 2018-02-07 17:29:02 --> Helper loaded: notification_helper
INFO - 2018-02-07 17:29:02 --> Helper loaded: settings_helper
INFO - 2018-02-07 17:29:02 --> Helper loaded: permission_helper
INFO - 2018-02-07 17:29:02 --> Helper loaded: users_helper
INFO - 2018-02-07 17:29:02 --> Database Driver Class Initialized
INFO - 2018-02-07 17:29:02 --> Database Driver Class Initialized
DEBUG - 2018-02-07 17:29:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 17:29:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-07 17:29:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 17:29:02 --> Helper loaded: form_helper
INFO - 2018-02-07 17:29:02 --> Form Validation Class Initialized
INFO - 2018-02-07 17:29:02 --> Controller Class Initialized
INFO - 2018-02-07 17:29:02 --> Model Class Initialized
INFO - 2018-02-07 17:29:02 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 17:29:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 17:29:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 17:29:02 --> Model Class Initialized
INFO - 2018-02-07 17:29:02 --> Model Class Initialized
INFO - 2018-02-07 17:29:02 --> Model Class Initialized
INFO - 2018-02-07 17:29:02 --> Model Class Initialized
INFO - 2018-02-07 17:29:02 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 17:29:02 --> Final output sent to browser
DEBUG - 2018-02-07 17:29:02 --> Total execution time: 0.1113
INFO - 2018-02-07 17:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 17:29:02 --> Helper loaded: form_helper
INFO - 2018-02-07 17:29:02 --> Form Validation Class Initialized
INFO - 2018-02-07 17:29:02 --> Controller Class Initialized
INFO - 2018-02-07 17:29:02 --> Model Class Initialized
INFO - 2018-02-07 17:29:02 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 17:29:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 17:29:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 17:29:02 --> Model Class Initialized
INFO - 2018-02-07 17:29:02 --> Model Class Initialized
INFO - 2018-02-07 17:29:02 --> Model Class Initialized
INFO - 2018-02-07 17:29:02 --> Model Class Initialized
INFO - 2018-02-07 17:29:02 --> Model Class Initialized
INFO - 2018-02-07 17:29:02 --> Model Class Initialized
INFO - 2018-02-07 17:29:02 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 17:29:02 --> Final output sent to browser
DEBUG - 2018-02-07 17:29:02 --> Total execution time: 0.1459
INFO - 2018-02-07 11:59:05 --> Config Class Initialized
INFO - 2018-02-07 11:59:05 --> Hooks Class Initialized
DEBUG - 2018-02-07 11:59:05 --> UTF-8 Support Enabled
INFO - 2018-02-07 11:59:05 --> Utf8 Class Initialized
INFO - 2018-02-07 11:59:05 --> URI Class Initialized
INFO - 2018-02-07 11:59:05 --> Router Class Initialized
INFO - 2018-02-07 11:59:05 --> Output Class Initialized
INFO - 2018-02-07 11:59:05 --> Security Class Initialized
DEBUG - 2018-02-07 11:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 11:59:05 --> Input Class Initialized
INFO - 2018-02-07 11:59:05 --> Language Class Initialized
INFO - 2018-02-07 11:59:05 --> Language Class Initialized
INFO - 2018-02-07 11:59:05 --> Config Class Initialized
INFO - 2018-02-07 11:59:05 --> Loader Class Initialized
INFO - 2018-02-07 17:29:05 --> Helper loaded: url_helper
INFO - 2018-02-07 17:29:05 --> Helper loaded: notification_helper
INFO - 2018-02-07 17:29:05 --> Helper loaded: settings_helper
INFO - 2018-02-07 17:29:05 --> Helper loaded: permission_helper
INFO - 2018-02-07 17:29:05 --> Helper loaded: users_helper
INFO - 2018-02-07 17:29:05 --> Database Driver Class Initialized
DEBUG - 2018-02-07 17:29:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 17:29:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 17:29:05 --> Helper loaded: form_helper
INFO - 2018-02-07 17:29:05 --> Form Validation Class Initialized
INFO - 2018-02-07 17:29:05 --> Controller Class Initialized
INFO - 2018-02-07 17:29:05 --> Model Class Initialized
INFO - 2018-02-07 17:29:05 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 17:29:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 17:29:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 17:29:05 --> Model Class Initialized
INFO - 2018-02-07 17:29:05 --> Model Class Initialized
INFO - 2018-02-07 17:29:05 --> Model Class Initialized
INFO - 2018-02-07 17:29:05 --> Model Class Initialized
INFO - 2018-02-07 17:29:05 --> Model Class Initialized
INFO - 2018-02-07 17:29:05 --> Model Class Initialized
INFO - 2018-02-07 17:29:05 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 17:29:05 --> Model Class Initialized
INFO - 2018-02-07 17:29:05 --> Final output sent to browser
DEBUG - 2018-02-07 17:29:05 --> Total execution time: 0.0934
INFO - 2018-02-07 12:06:50 --> Config Class Initialized
INFO - 2018-02-07 12:06:50 --> Hooks Class Initialized
DEBUG - 2018-02-07 12:06:50 --> UTF-8 Support Enabled
INFO - 2018-02-07 12:06:50 --> Utf8 Class Initialized
INFO - 2018-02-07 12:06:50 --> URI Class Initialized
INFO - 2018-02-07 12:06:50 --> Router Class Initialized
INFO - 2018-02-07 12:06:50 --> Output Class Initialized
INFO - 2018-02-07 12:06:50 --> Security Class Initialized
DEBUG - 2018-02-07 12:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 12:06:50 --> Input Class Initialized
INFO - 2018-02-07 12:06:50 --> Language Class Initialized
INFO - 2018-02-07 12:06:50 --> Language Class Initialized
INFO - 2018-02-07 12:06:50 --> Config Class Initialized
INFO - 2018-02-07 12:06:50 --> Loader Class Initialized
INFO - 2018-02-07 17:36:50 --> Helper loaded: url_helper
INFO - 2018-02-07 17:36:50 --> Helper loaded: notification_helper
INFO - 2018-02-07 17:36:50 --> Helper loaded: settings_helper
INFO - 2018-02-07 17:36:50 --> Helper loaded: permission_helper
INFO - 2018-02-07 17:36:50 --> Helper loaded: users_helper
INFO - 2018-02-07 17:36:50 --> Database Driver Class Initialized
DEBUG - 2018-02-07 17:36:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 17:36:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 17:36:50 --> Helper loaded: form_helper
INFO - 2018-02-07 17:36:50 --> Form Validation Class Initialized
INFO - 2018-02-07 17:36:50 --> Controller Class Initialized
INFO - 2018-02-07 17:36:50 --> Model Class Initialized
INFO - 2018-02-07 17:36:50 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 17:36:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 17:36:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 17:36:50 --> Model Class Initialized
INFO - 2018-02-07 17:36:50 --> Model Class Initialized
INFO - 2018-02-07 17:36:50 --> Model Class Initialized
INFO - 2018-02-07 17:36:50 --> Model Class Initialized
INFO - 2018-02-07 17:36:50 --> Model Class Initialized
INFO - 2018-02-07 17:36:50 --> Model Class Initialized
INFO - 2018-02-07 17:36:50 --> Model Class Initialized
INFO - 2018-02-07 17:36:50 --> Model Class Initialized
INFO - 2018-02-07 17:36:50 --> Model Class Initialized
INFO - 2018-02-07 17:36:50 --> Model Class Initialized
INFO - 2018-02-07 17:36:50 --> Model Class Initialized
INFO - 2018-02-07 17:36:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 17:36:50 --> Model Class Initialized
INFO - 2018-02-07 17:36:50 --> Final output sent to browser
DEBUG - 2018-02-07 17:36:50 --> Total execution time: 0.1295
INFO - 2018-02-07 12:06:51 --> Config Class Initialized
INFO - 2018-02-07 12:06:51 --> Hooks Class Initialized
DEBUG - 2018-02-07 12:06:51 --> UTF-8 Support Enabled
INFO - 2018-02-07 12:06:51 --> Utf8 Class Initialized
INFO - 2018-02-07 12:06:51 --> URI Class Initialized
INFO - 2018-02-07 12:06:51 --> Router Class Initialized
INFO - 2018-02-07 12:06:51 --> Output Class Initialized
INFO - 2018-02-07 12:06:51 --> Security Class Initialized
DEBUG - 2018-02-07 12:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 12:06:51 --> Input Class Initialized
INFO - 2018-02-07 12:06:51 --> Language Class Initialized
INFO - 2018-02-07 12:06:51 --> Language Class Initialized
INFO - 2018-02-07 12:06:51 --> Config Class Initialized
INFO - 2018-02-07 12:06:51 --> Loader Class Initialized
INFO - 2018-02-07 17:36:51 --> Helper loaded: url_helper
INFO - 2018-02-07 17:36:51 --> Helper loaded: notification_helper
INFO - 2018-02-07 17:36:51 --> Helper loaded: settings_helper
INFO - 2018-02-07 17:36:51 --> Helper loaded: permission_helper
INFO - 2018-02-07 17:36:51 --> Helper loaded: users_helper
INFO - 2018-02-07 17:36:51 --> Database Driver Class Initialized
DEBUG - 2018-02-07 17:36:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 17:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 17:36:51 --> Helper loaded: form_helper
INFO - 2018-02-07 17:36:51 --> Form Validation Class Initialized
INFO - 2018-02-07 17:36:51 --> Controller Class Initialized
INFO - 2018-02-07 17:36:51 --> Model Class Initialized
INFO - 2018-02-07 17:36:51 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 17:36:51 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 17:36:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 17:36:51 --> Model Class Initialized
INFO - 2018-02-07 17:36:51 --> Model Class Initialized
INFO - 2018-02-07 17:36:51 --> Model Class Initialized
INFO - 2018-02-07 17:36:51 --> Model Class Initialized
INFO - 2018-02-07 17:36:51 --> Model Class Initialized
INFO - 2018-02-07 17:36:51 --> Model Class Initialized
INFO - 2018-02-07 17:36:51 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 17:36:51 --> Model Class Initialized
INFO - 2018-02-07 17:36:51 --> Final output sent to browser
DEBUG - 2018-02-07 17:36:51 --> Total execution time: 0.1180
INFO - 2018-02-07 12:07:04 --> Config Class Initialized
INFO - 2018-02-07 12:07:04 --> Hooks Class Initialized
DEBUG - 2018-02-07 12:07:04 --> UTF-8 Support Enabled
INFO - 2018-02-07 12:07:04 --> Utf8 Class Initialized
INFO - 2018-02-07 12:07:04 --> URI Class Initialized
INFO - 2018-02-07 12:07:04 --> Router Class Initialized
INFO - 2018-02-07 12:07:04 --> Output Class Initialized
INFO - 2018-02-07 12:07:04 --> Security Class Initialized
DEBUG - 2018-02-07 12:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 12:07:04 --> Input Class Initialized
INFO - 2018-02-07 12:07:04 --> Language Class Initialized
INFO - 2018-02-07 12:07:04 --> Config Class Initialized
INFO - 2018-02-07 12:07:04 --> Hooks Class Initialized
DEBUG - 2018-02-07 12:07:04 --> UTF-8 Support Enabled
INFO - 2018-02-07 12:07:04 --> Utf8 Class Initialized
INFO - 2018-02-07 12:07:04 --> URI Class Initialized
INFO - 2018-02-07 12:07:04 --> Router Class Initialized
INFO - 2018-02-07 12:07:04 --> Language Class Initialized
INFO - 2018-02-07 12:07:04 --> Config Class Initialized
INFO - 2018-02-07 12:07:04 --> Loader Class Initialized
INFO - 2018-02-07 17:37:04 --> Helper loaded: url_helper
INFO - 2018-02-07 12:07:04 --> Output Class Initialized
INFO - 2018-02-07 17:37:04 --> Helper loaded: notification_helper
INFO - 2018-02-07 17:37:04 --> Helper loaded: settings_helper
INFO - 2018-02-07 17:37:04 --> Helper loaded: permission_helper
INFO - 2018-02-07 12:07:04 --> Security Class Initialized
INFO - 2018-02-07 17:37:04 --> Helper loaded: users_helper
DEBUG - 2018-02-07 12:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 12:07:04 --> Input Class Initialized
INFO - 2018-02-07 12:07:04 --> Language Class Initialized
INFO - 2018-02-07 17:37:04 --> Database Driver Class Initialized
DEBUG - 2018-02-07 17:37:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 17:37:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 12:07:04 --> Language Class Initialized
INFO - 2018-02-07 12:07:04 --> Config Class Initialized
INFO - 2018-02-07 12:07:04 --> Loader Class Initialized
INFO - 2018-02-07 17:37:04 --> Helper loaded: url_helper
INFO - 2018-02-07 17:37:04 --> Helper loaded: notification_helper
INFO - 2018-02-07 17:37:04 --> Helper loaded: settings_helper
INFO - 2018-02-07 17:37:04 --> Helper loaded: form_helper
INFO - 2018-02-07 17:37:04 --> Helper loaded: permission_helper
INFO - 2018-02-07 17:37:04 --> Form Validation Class Initialized
INFO - 2018-02-07 17:37:04 --> Controller Class Initialized
INFO - 2018-02-07 17:37:04 --> Helper loaded: users_helper
INFO - 2018-02-07 17:37:04 --> Model Class Initialized
INFO - 2018-02-07 17:37:04 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 17:37:04 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 17:37:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 17:37:04 --> Database Driver Class Initialized
INFO - 2018-02-07 17:37:04 --> Model Class Initialized
INFO - 2018-02-07 17:37:04 --> Model Class Initialized
INFO - 2018-02-07 17:37:04 --> Model Class Initialized
INFO - 2018-02-07 17:37:04 --> Model Class Initialized
INFO - 2018-02-07 17:37:04 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 17:37:04 --> Final output sent to browser
DEBUG - 2018-02-07 17:37:04 --> Total execution time: 0.1556
DEBUG - 2018-02-07 17:37:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 17:37:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 17:37:04 --> Helper loaded: form_helper
INFO - 2018-02-07 17:37:04 --> Form Validation Class Initialized
INFO - 2018-02-07 17:37:04 --> Controller Class Initialized
INFO - 2018-02-07 17:37:04 --> Model Class Initialized
INFO - 2018-02-07 17:37:04 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 17:37:04 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 17:37:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 17:37:04 --> Model Class Initialized
INFO - 2018-02-07 17:37:04 --> Model Class Initialized
INFO - 2018-02-07 17:37:04 --> Model Class Initialized
INFO - 2018-02-07 17:37:04 --> Model Class Initialized
INFO - 2018-02-07 17:37:04 --> Model Class Initialized
INFO - 2018-02-07 17:37:04 --> Model Class Initialized
INFO - 2018-02-07 17:37:04 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 17:37:04 --> Final output sent to browser
DEBUG - 2018-02-07 17:37:04 --> Total execution time: 0.1387
INFO - 2018-02-07 12:07:09 --> Config Class Initialized
INFO - 2018-02-07 12:07:09 --> Hooks Class Initialized
DEBUG - 2018-02-07 12:07:09 --> UTF-8 Support Enabled
INFO - 2018-02-07 12:07:09 --> Utf8 Class Initialized
INFO - 2018-02-07 12:07:09 --> URI Class Initialized
INFO - 2018-02-07 12:07:09 --> Router Class Initialized
INFO - 2018-02-07 12:07:09 --> Output Class Initialized
INFO - 2018-02-07 12:07:09 --> Security Class Initialized
DEBUG - 2018-02-07 12:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 12:07:09 --> Input Class Initialized
INFO - 2018-02-07 12:07:09 --> Language Class Initialized
INFO - 2018-02-07 12:07:09 --> Language Class Initialized
INFO - 2018-02-07 12:07:09 --> Config Class Initialized
INFO - 2018-02-07 12:07:09 --> Loader Class Initialized
INFO - 2018-02-07 17:37:09 --> Helper loaded: url_helper
INFO - 2018-02-07 17:37:09 --> Helper loaded: notification_helper
INFO - 2018-02-07 17:37:09 --> Helper loaded: settings_helper
INFO - 2018-02-07 17:37:09 --> Helper loaded: permission_helper
INFO - 2018-02-07 17:37:09 --> Helper loaded: users_helper
INFO - 2018-02-07 17:37:09 --> Database Driver Class Initialized
DEBUG - 2018-02-07 17:37:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 17:37:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 17:37:09 --> Helper loaded: form_helper
INFO - 2018-02-07 17:37:09 --> Form Validation Class Initialized
INFO - 2018-02-07 17:37:09 --> Controller Class Initialized
INFO - 2018-02-07 17:37:09 --> Model Class Initialized
INFO - 2018-02-07 17:37:09 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 17:37:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 17:37:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 17:37:09 --> Model Class Initialized
INFO - 2018-02-07 17:37:09 --> Model Class Initialized
INFO - 2018-02-07 17:37:09 --> Model Class Initialized
INFO - 2018-02-07 17:37:09 --> Model Class Initialized
INFO - 2018-02-07 17:37:09 --> Model Class Initialized
INFO - 2018-02-07 17:37:09 --> Model Class Initialized
INFO - 2018-02-07 17:37:09 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 17:37:09 --> Model Class Initialized
INFO - 2018-02-07 17:37:09 --> Final output sent to browser
DEBUG - 2018-02-07 17:37:09 --> Total execution time: 0.0915
INFO - 2018-02-07 12:14:50 --> Config Class Initialized
INFO - 2018-02-07 12:14:50 --> Hooks Class Initialized
DEBUG - 2018-02-07 12:14:50 --> UTF-8 Support Enabled
INFO - 2018-02-07 12:14:50 --> Utf8 Class Initialized
INFO - 2018-02-07 12:14:50 --> URI Class Initialized
INFO - 2018-02-07 12:14:50 --> Router Class Initialized
INFO - 2018-02-07 12:14:50 --> Output Class Initialized
INFO - 2018-02-07 12:14:50 --> Security Class Initialized
DEBUG - 2018-02-07 12:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 12:14:50 --> Input Class Initialized
INFO - 2018-02-07 12:14:50 --> Language Class Initialized
INFO - 2018-02-07 12:14:50 --> Language Class Initialized
INFO - 2018-02-07 12:14:50 --> Config Class Initialized
INFO - 2018-02-07 12:14:50 --> Loader Class Initialized
INFO - 2018-02-07 17:44:50 --> Helper loaded: url_helper
INFO - 2018-02-07 17:44:50 --> Helper loaded: notification_helper
INFO - 2018-02-07 17:44:50 --> Helper loaded: settings_helper
INFO - 2018-02-07 17:44:50 --> Helper loaded: permission_helper
INFO - 2018-02-07 17:44:50 --> Helper loaded: users_helper
INFO - 2018-02-07 17:44:50 --> Database Driver Class Initialized
DEBUG - 2018-02-07 17:44:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 17:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 17:44:50 --> Helper loaded: form_helper
INFO - 2018-02-07 17:44:50 --> Form Validation Class Initialized
INFO - 2018-02-07 17:44:50 --> Controller Class Initialized
INFO - 2018-02-07 17:44:50 --> Model Class Initialized
INFO - 2018-02-07 17:44:50 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 17:44:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 17:44:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 17:44:50 --> Model Class Initialized
INFO - 2018-02-07 17:44:50 --> Model Class Initialized
INFO - 2018-02-07 17:44:50 --> Model Class Initialized
INFO - 2018-02-07 17:44:50 --> Model Class Initialized
INFO - 2018-02-07 17:44:50 --> Model Class Initialized
INFO - 2018-02-07 17:44:50 --> Model Class Initialized
INFO - 2018-02-07 17:44:50 --> Model Class Initialized
INFO - 2018-02-07 17:44:50 --> Model Class Initialized
INFO - 2018-02-07 17:44:50 --> Model Class Initialized
INFO - 2018-02-07 17:44:50 --> Model Class Initialized
INFO - 2018-02-07 17:44:50 --> Model Class Initialized
INFO - 2018-02-07 17:44:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 17:44:50 --> Model Class Initialized
INFO - 2018-02-07 17:44:50 --> Final output sent to browser
DEBUG - 2018-02-07 17:44:50 --> Total execution time: 0.1358
INFO - 2018-02-07 12:14:51 --> Config Class Initialized
INFO - 2018-02-07 12:14:51 --> Hooks Class Initialized
DEBUG - 2018-02-07 12:14:51 --> UTF-8 Support Enabled
INFO - 2018-02-07 12:14:51 --> Utf8 Class Initialized
INFO - 2018-02-07 12:14:51 --> URI Class Initialized
INFO - 2018-02-07 12:14:51 --> Router Class Initialized
INFO - 2018-02-07 12:14:51 --> Output Class Initialized
INFO - 2018-02-07 12:14:51 --> Security Class Initialized
DEBUG - 2018-02-07 12:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 12:14:51 --> Input Class Initialized
INFO - 2018-02-07 12:14:51 --> Language Class Initialized
INFO - 2018-02-07 12:14:51 --> Language Class Initialized
INFO - 2018-02-07 12:14:51 --> Config Class Initialized
INFO - 2018-02-07 12:14:51 --> Loader Class Initialized
INFO - 2018-02-07 17:44:51 --> Helper loaded: url_helper
INFO - 2018-02-07 17:44:51 --> Helper loaded: notification_helper
INFO - 2018-02-07 17:44:51 --> Helper loaded: settings_helper
INFO - 2018-02-07 17:44:51 --> Helper loaded: permission_helper
INFO - 2018-02-07 17:44:51 --> Helper loaded: users_helper
INFO - 2018-02-07 17:44:51 --> Database Driver Class Initialized
DEBUG - 2018-02-07 17:44:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 17:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 17:44:51 --> Helper loaded: form_helper
INFO - 2018-02-07 17:44:51 --> Form Validation Class Initialized
INFO - 2018-02-07 17:44:51 --> Controller Class Initialized
INFO - 2018-02-07 17:44:51 --> Model Class Initialized
INFO - 2018-02-07 17:44:51 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 17:44:51 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 17:44:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 17:44:51 --> Model Class Initialized
INFO - 2018-02-07 17:44:51 --> Model Class Initialized
INFO - 2018-02-07 17:44:51 --> Model Class Initialized
INFO - 2018-02-07 17:44:51 --> Model Class Initialized
INFO - 2018-02-07 17:44:51 --> Model Class Initialized
INFO - 2018-02-07 17:44:51 --> Model Class Initialized
INFO - 2018-02-07 17:44:51 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 17:44:51 --> Model Class Initialized
INFO - 2018-02-07 17:44:51 --> Final output sent to browser
DEBUG - 2018-02-07 17:44:51 --> Total execution time: 0.1164
INFO - 2018-02-07 12:14:53 --> Config Class Initialized
INFO - 2018-02-07 12:14:53 --> Hooks Class Initialized
DEBUG - 2018-02-07 12:14:53 --> UTF-8 Support Enabled
INFO - 2018-02-07 12:14:53 --> Utf8 Class Initialized
INFO - 2018-02-07 12:14:53 --> URI Class Initialized
INFO - 2018-02-07 12:14:53 --> Router Class Initialized
INFO - 2018-02-07 12:14:53 --> Output Class Initialized
INFO - 2018-02-07 12:14:53 --> Security Class Initialized
DEBUG - 2018-02-07 12:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 12:14:53 --> Input Class Initialized
INFO - 2018-02-07 12:14:53 --> Language Class Initialized
INFO - 2018-02-07 12:14:53 --> Config Class Initialized
INFO - 2018-02-07 12:14:53 --> Hooks Class Initialized
DEBUG - 2018-02-07 12:14:53 --> UTF-8 Support Enabled
INFO - 2018-02-07 12:14:53 --> Utf8 Class Initialized
INFO - 2018-02-07 12:14:53 --> URI Class Initialized
INFO - 2018-02-07 12:14:53 --> Language Class Initialized
INFO - 2018-02-07 12:14:53 --> Config Class Initialized
INFO - 2018-02-07 12:14:53 --> Loader Class Initialized
INFO - 2018-02-07 17:44:53 --> Helper loaded: url_helper
INFO - 2018-02-07 17:44:53 --> Helper loaded: notification_helper
INFO - 2018-02-07 12:14:53 --> Router Class Initialized
INFO - 2018-02-07 17:44:53 --> Helper loaded: settings_helper
INFO - 2018-02-07 17:44:53 --> Helper loaded: permission_helper
INFO - 2018-02-07 17:44:53 --> Helper loaded: users_helper
INFO - 2018-02-07 12:14:53 --> Output Class Initialized
INFO - 2018-02-07 12:14:53 --> Security Class Initialized
DEBUG - 2018-02-07 12:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 12:14:53 --> Input Class Initialized
INFO - 2018-02-07 12:14:53 --> Language Class Initialized
INFO - 2018-02-07 17:44:53 --> Database Driver Class Initialized
DEBUG - 2018-02-07 17:44:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 17:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 17:44:53 --> Helper loaded: form_helper
INFO - 2018-02-07 17:44:53 --> Form Validation Class Initialized
INFO - 2018-02-07 17:44:53 --> Controller Class Initialized
INFO - 2018-02-07 12:14:53 --> Language Class Initialized
INFO - 2018-02-07 12:14:53 --> Config Class Initialized
INFO - 2018-02-07 12:14:53 --> Loader Class Initialized
INFO - 2018-02-07 17:44:53 --> Helper loaded: url_helper
INFO - 2018-02-07 17:44:53 --> Helper loaded: notification_helper
INFO - 2018-02-07 17:44:53 --> Model Class Initialized
INFO - 2018-02-07 17:44:53 --> Helper loaded: settings_helper
INFO - 2018-02-07 17:44:53 --> Helper loaded: inflector_helper
INFO - 2018-02-07 17:44:53 --> Helper loaded: permission_helper
INFO - 2018-02-07 17:44:53 --> Helper loaded: users_helper
DEBUG - 2018-02-07 17:44:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 17:44:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 17:44:53 --> Model Class Initialized
INFO - 2018-02-07 17:44:53 --> Model Class Initialized
INFO - 2018-02-07 17:44:53 --> Model Class Initialized
INFO - 2018-02-07 17:44:53 --> Model Class Initialized
INFO - 2018-02-07 17:44:53 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 17:44:53 --> Final output sent to browser
DEBUG - 2018-02-07 17:44:53 --> Total execution time: 0.0989
INFO - 2018-02-07 17:44:53 --> Database Driver Class Initialized
DEBUG - 2018-02-07 17:44:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 17:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 17:44:53 --> Helper loaded: form_helper
INFO - 2018-02-07 17:44:53 --> Form Validation Class Initialized
INFO - 2018-02-07 17:44:53 --> Controller Class Initialized
INFO - 2018-02-07 17:44:53 --> Model Class Initialized
INFO - 2018-02-07 17:44:53 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 17:44:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 17:44:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 17:44:53 --> Model Class Initialized
INFO - 2018-02-07 17:44:53 --> Model Class Initialized
INFO - 2018-02-07 17:44:53 --> Model Class Initialized
INFO - 2018-02-07 17:44:53 --> Model Class Initialized
INFO - 2018-02-07 17:44:53 --> Model Class Initialized
INFO - 2018-02-07 17:44:53 --> Model Class Initialized
INFO - 2018-02-07 17:44:53 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 17:44:53 --> Final output sent to browser
DEBUG - 2018-02-07 17:44:53 --> Total execution time: 0.1180
INFO - 2018-02-07 12:14:57 --> Config Class Initialized
INFO - 2018-02-07 12:14:57 --> Hooks Class Initialized
DEBUG - 2018-02-07 12:14:57 --> UTF-8 Support Enabled
INFO - 2018-02-07 12:14:57 --> Utf8 Class Initialized
INFO - 2018-02-07 12:14:57 --> URI Class Initialized
INFO - 2018-02-07 12:14:57 --> Router Class Initialized
INFO - 2018-02-07 12:14:57 --> Output Class Initialized
INFO - 2018-02-07 12:14:57 --> Security Class Initialized
DEBUG - 2018-02-07 12:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 12:14:57 --> Input Class Initialized
INFO - 2018-02-07 12:14:57 --> Language Class Initialized
INFO - 2018-02-07 12:14:57 --> Language Class Initialized
INFO - 2018-02-07 12:14:57 --> Config Class Initialized
INFO - 2018-02-07 12:14:57 --> Loader Class Initialized
INFO - 2018-02-07 17:44:57 --> Helper loaded: url_helper
INFO - 2018-02-07 17:44:57 --> Helper loaded: notification_helper
INFO - 2018-02-07 17:44:57 --> Helper loaded: settings_helper
INFO - 2018-02-07 17:44:57 --> Helper loaded: permission_helper
INFO - 2018-02-07 17:44:57 --> Helper loaded: users_helper
INFO - 2018-02-07 17:44:57 --> Database Driver Class Initialized
DEBUG - 2018-02-07 17:44:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 17:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 17:44:57 --> Helper loaded: form_helper
INFO - 2018-02-07 17:44:57 --> Form Validation Class Initialized
INFO - 2018-02-07 17:44:57 --> Controller Class Initialized
INFO - 2018-02-07 17:44:57 --> Model Class Initialized
INFO - 2018-02-07 17:44:57 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 17:44:57 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 17:44:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 17:44:57 --> Model Class Initialized
INFO - 2018-02-07 17:44:57 --> Model Class Initialized
INFO - 2018-02-07 17:44:57 --> Model Class Initialized
INFO - 2018-02-07 17:44:57 --> Model Class Initialized
INFO - 2018-02-07 17:44:57 --> Model Class Initialized
INFO - 2018-02-07 17:44:57 --> Model Class Initialized
INFO - 2018-02-07 17:44:57 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 17:44:57 --> Model Class Initialized
INFO - 2018-02-07 17:44:57 --> Final output sent to browser
DEBUG - 2018-02-07 17:44:57 --> Total execution time: 0.1174
INFO - 2018-02-07 12:33:46 --> Config Class Initialized
INFO - 2018-02-07 12:33:46 --> Hooks Class Initialized
DEBUG - 2018-02-07 12:33:46 --> UTF-8 Support Enabled
INFO - 2018-02-07 12:33:46 --> Utf8 Class Initialized
INFO - 2018-02-07 12:33:46 --> URI Class Initialized
INFO - 2018-02-07 12:33:46 --> Router Class Initialized
INFO - 2018-02-07 12:33:46 --> Output Class Initialized
INFO - 2018-02-07 12:33:46 --> Security Class Initialized
DEBUG - 2018-02-07 12:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 12:33:46 --> Input Class Initialized
INFO - 2018-02-07 12:33:46 --> Language Class Initialized
INFO - 2018-02-07 12:33:46 --> Language Class Initialized
INFO - 2018-02-07 12:33:46 --> Config Class Initialized
INFO - 2018-02-07 12:33:46 --> Loader Class Initialized
INFO - 2018-02-07 18:03:46 --> Helper loaded: url_helper
INFO - 2018-02-07 18:03:46 --> Helper loaded: notification_helper
INFO - 2018-02-07 18:03:46 --> Helper loaded: settings_helper
INFO - 2018-02-07 18:03:46 --> Helper loaded: permission_helper
INFO - 2018-02-07 18:03:46 --> Helper loaded: users_helper
INFO - 2018-02-07 18:03:46 --> Database Driver Class Initialized
DEBUG - 2018-02-07 18:03:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 18:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 18:03:46 --> Helper loaded: form_helper
INFO - 2018-02-07 18:03:46 --> Form Validation Class Initialized
INFO - 2018-02-07 18:03:46 --> Controller Class Initialized
INFO - 2018-02-07 18:03:46 --> Model Class Initialized
INFO - 2018-02-07 18:03:46 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 18:03:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 18:03:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 18:03:46 --> Model Class Initialized
INFO - 2018-02-07 18:03:46 --> Model Class Initialized
INFO - 2018-02-07 18:03:46 --> Model Class Initialized
INFO - 2018-02-07 18:03:46 --> Model Class Initialized
INFO - 2018-02-07 18:03:46 --> Model Class Initialized
INFO - 2018-02-07 18:03:46 --> Model Class Initialized
INFO - 2018-02-07 18:03:46 --> Model Class Initialized
INFO - 2018-02-07 18:03:46 --> Model Class Initialized
INFO - 2018-02-07 18:03:46 --> Model Class Initialized
INFO - 2018-02-07 18:03:46 --> Model Class Initialized
INFO - 2018-02-07 18:03:46 --> Model Class Initialized
INFO - 2018-02-07 18:03:46 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 18:03:46 --> Model Class Initialized
INFO - 2018-02-07 18:03:46 --> Final output sent to browser
DEBUG - 2018-02-07 18:03:46 --> Total execution time: 0.1569
INFO - 2018-02-07 12:33:46 --> Config Class Initialized
INFO - 2018-02-07 12:33:46 --> Hooks Class Initialized
DEBUG - 2018-02-07 12:33:46 --> UTF-8 Support Enabled
INFO - 2018-02-07 12:33:46 --> Utf8 Class Initialized
INFO - 2018-02-07 12:33:46 --> URI Class Initialized
INFO - 2018-02-07 12:33:46 --> Router Class Initialized
INFO - 2018-02-07 12:33:46 --> Output Class Initialized
INFO - 2018-02-07 12:33:46 --> Security Class Initialized
DEBUG - 2018-02-07 12:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 12:33:46 --> Input Class Initialized
INFO - 2018-02-07 12:33:46 --> Language Class Initialized
INFO - 2018-02-07 12:33:46 --> Language Class Initialized
INFO - 2018-02-07 12:33:46 --> Config Class Initialized
INFO - 2018-02-07 12:33:46 --> Loader Class Initialized
INFO - 2018-02-07 18:03:46 --> Helper loaded: url_helper
INFO - 2018-02-07 18:03:46 --> Helper loaded: notification_helper
INFO - 2018-02-07 18:03:46 --> Helper loaded: settings_helper
INFO - 2018-02-07 18:03:46 --> Helper loaded: permission_helper
INFO - 2018-02-07 18:03:46 --> Helper loaded: users_helper
INFO - 2018-02-07 18:03:46 --> Database Driver Class Initialized
DEBUG - 2018-02-07 18:03:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 18:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 18:03:46 --> Helper loaded: form_helper
INFO - 2018-02-07 18:03:46 --> Form Validation Class Initialized
INFO - 2018-02-07 18:03:46 --> Controller Class Initialized
INFO - 2018-02-07 18:03:46 --> Model Class Initialized
INFO - 2018-02-07 18:03:46 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 18:03:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 18:03:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 18:03:46 --> Model Class Initialized
INFO - 2018-02-07 18:03:46 --> Model Class Initialized
INFO - 2018-02-07 18:03:46 --> Model Class Initialized
INFO - 2018-02-07 18:03:46 --> Model Class Initialized
INFO - 2018-02-07 18:03:46 --> Model Class Initialized
INFO - 2018-02-07 18:03:46 --> Model Class Initialized
INFO - 2018-02-07 18:03:46 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 18:03:46 --> Model Class Initialized
INFO - 2018-02-07 18:03:46 --> Final output sent to browser
DEBUG - 2018-02-07 18:03:46 --> Total execution time: 0.1143
INFO - 2018-02-07 12:34:15 --> Config Class Initialized
INFO - 2018-02-07 12:34:15 --> Hooks Class Initialized
DEBUG - 2018-02-07 12:34:15 --> UTF-8 Support Enabled
INFO - 2018-02-07 12:34:15 --> Utf8 Class Initialized
INFO - 2018-02-07 12:34:15 --> URI Class Initialized
INFO - 2018-02-07 12:34:15 --> Router Class Initialized
INFO - 2018-02-07 12:34:15 --> Output Class Initialized
INFO - 2018-02-07 12:34:15 --> Security Class Initialized
DEBUG - 2018-02-07 12:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 12:34:15 --> Input Class Initialized
INFO - 2018-02-07 12:34:15 --> Language Class Initialized
INFO - 2018-02-07 12:34:15 --> Language Class Initialized
INFO - 2018-02-07 12:34:15 --> Config Class Initialized
INFO - 2018-02-07 12:34:15 --> Loader Class Initialized
INFO - 2018-02-07 18:04:15 --> Helper loaded: url_helper
INFO - 2018-02-07 18:04:15 --> Helper loaded: notification_helper
INFO - 2018-02-07 18:04:15 --> Helper loaded: settings_helper
INFO - 2018-02-07 18:04:15 --> Helper loaded: permission_helper
INFO - 2018-02-07 18:04:15 --> Helper loaded: users_helper
INFO - 2018-02-07 18:04:15 --> Database Driver Class Initialized
DEBUG - 2018-02-07 18:04:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 18:04:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 18:04:15 --> Helper loaded: form_helper
INFO - 2018-02-07 18:04:15 --> Form Validation Class Initialized
INFO - 2018-02-07 18:04:15 --> Controller Class Initialized
INFO - 2018-02-07 18:04:15 --> Model Class Initialized
INFO - 2018-02-07 18:04:15 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 18:04:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 18:04:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 18:04:15 --> Model Class Initialized
INFO - 2018-02-07 18:04:15 --> Model Class Initialized
INFO - 2018-02-07 18:04:15 --> Model Class Initialized
INFO - 2018-02-07 18:04:15 --> Model Class Initialized
INFO - 2018-02-07 18:04:15 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 18:04:15 --> Final output sent to browser
DEBUG - 2018-02-07 18:04:15 --> Total execution time: 0.1066
INFO - 2018-02-07 12:34:15 --> Config Class Initialized
INFO - 2018-02-07 12:34:15 --> Hooks Class Initialized
DEBUG - 2018-02-07 12:34:15 --> UTF-8 Support Enabled
INFO - 2018-02-07 12:34:15 --> Utf8 Class Initialized
INFO - 2018-02-07 12:34:15 --> URI Class Initialized
INFO - 2018-02-07 12:34:15 --> Router Class Initialized
INFO - 2018-02-07 12:34:15 --> Output Class Initialized
INFO - 2018-02-07 12:34:15 --> Security Class Initialized
DEBUG - 2018-02-07 12:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 12:34:15 --> Input Class Initialized
INFO - 2018-02-07 12:34:15 --> Language Class Initialized
INFO - 2018-02-07 12:34:15 --> Language Class Initialized
INFO - 2018-02-07 12:34:15 --> Config Class Initialized
INFO - 2018-02-07 12:34:15 --> Loader Class Initialized
INFO - 2018-02-07 18:04:15 --> Helper loaded: url_helper
INFO - 2018-02-07 18:04:15 --> Helper loaded: notification_helper
INFO - 2018-02-07 18:04:15 --> Helper loaded: settings_helper
INFO - 2018-02-07 18:04:15 --> Helper loaded: permission_helper
INFO - 2018-02-07 18:04:15 --> Helper loaded: users_helper
INFO - 2018-02-07 18:04:15 --> Database Driver Class Initialized
DEBUG - 2018-02-07 18:04:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 18:04:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 18:04:15 --> Helper loaded: form_helper
INFO - 2018-02-07 18:04:15 --> Form Validation Class Initialized
INFO - 2018-02-07 18:04:15 --> Controller Class Initialized
INFO - 2018-02-07 18:04:15 --> Model Class Initialized
INFO - 2018-02-07 18:04:15 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 18:04:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 18:04:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 18:04:15 --> Model Class Initialized
INFO - 2018-02-07 18:04:15 --> Model Class Initialized
INFO - 2018-02-07 18:04:15 --> Model Class Initialized
INFO - 2018-02-07 18:04:15 --> Model Class Initialized
INFO - 2018-02-07 18:04:15 --> Model Class Initialized
INFO - 2018-02-07 18:04:15 --> Model Class Initialized
INFO - 2018-02-07 18:04:15 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 18:04:15 --> Final output sent to browser
DEBUG - 2018-02-07 18:04:15 --> Total execution time: 0.1199
INFO - 2018-02-07 12:34:19 --> Config Class Initialized
INFO - 2018-02-07 12:34:19 --> Hooks Class Initialized
DEBUG - 2018-02-07 12:34:19 --> UTF-8 Support Enabled
INFO - 2018-02-07 12:34:19 --> Utf8 Class Initialized
INFO - 2018-02-07 12:34:19 --> URI Class Initialized
INFO - 2018-02-07 12:34:19 --> Router Class Initialized
INFO - 2018-02-07 12:34:19 --> Output Class Initialized
INFO - 2018-02-07 12:34:19 --> Security Class Initialized
DEBUG - 2018-02-07 12:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 12:34:19 --> Input Class Initialized
INFO - 2018-02-07 12:34:19 --> Language Class Initialized
INFO - 2018-02-07 12:34:19 --> Language Class Initialized
INFO - 2018-02-07 12:34:19 --> Config Class Initialized
INFO - 2018-02-07 12:34:19 --> Loader Class Initialized
INFO - 2018-02-07 18:04:19 --> Helper loaded: url_helper
INFO - 2018-02-07 18:04:19 --> Helper loaded: notification_helper
INFO - 2018-02-07 18:04:19 --> Helper loaded: settings_helper
INFO - 2018-02-07 18:04:19 --> Helper loaded: permission_helper
INFO - 2018-02-07 18:04:19 --> Helper loaded: users_helper
INFO - 2018-02-07 18:04:19 --> Database Driver Class Initialized
DEBUG - 2018-02-07 18:04:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 18:04:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 18:04:19 --> Helper loaded: form_helper
INFO - 2018-02-07 18:04:19 --> Form Validation Class Initialized
INFO - 2018-02-07 18:04:19 --> Controller Class Initialized
INFO - 2018-02-07 18:04:19 --> Model Class Initialized
INFO - 2018-02-07 18:04:19 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 18:04:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 18:04:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 18:04:19 --> Model Class Initialized
INFO - 2018-02-07 18:04:19 --> Model Class Initialized
INFO - 2018-02-07 18:04:19 --> Model Class Initialized
INFO - 2018-02-07 18:04:19 --> Model Class Initialized
INFO - 2018-02-07 18:04:19 --> Model Class Initialized
INFO - 2018-02-07 18:04:19 --> Model Class Initialized
INFO - 2018-02-07 18:04:19 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 18:04:19 --> Model Class Initialized
INFO - 2018-02-07 18:04:19 --> Final output sent to browser
DEBUG - 2018-02-07 18:04:19 --> Total execution time: 0.1198
INFO - 2018-02-07 12:34:30 --> Config Class Initialized
INFO - 2018-02-07 12:34:30 --> Hooks Class Initialized
DEBUG - 2018-02-07 12:34:30 --> UTF-8 Support Enabled
INFO - 2018-02-07 12:34:30 --> Utf8 Class Initialized
INFO - 2018-02-07 12:34:30 --> URI Class Initialized
INFO - 2018-02-07 12:34:30 --> Router Class Initialized
INFO - 2018-02-07 12:34:30 --> Output Class Initialized
INFO - 2018-02-07 12:34:30 --> Security Class Initialized
DEBUG - 2018-02-07 12:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 12:34:30 --> Input Class Initialized
INFO - 2018-02-07 12:34:30 --> Language Class Initialized
INFO - 2018-02-07 12:34:30 --> Language Class Initialized
INFO - 2018-02-07 12:34:30 --> Config Class Initialized
INFO - 2018-02-07 12:34:30 --> Loader Class Initialized
INFO - 2018-02-07 18:04:30 --> Helper loaded: url_helper
INFO - 2018-02-07 18:04:30 --> Helper loaded: notification_helper
INFO - 2018-02-07 18:04:30 --> Helper loaded: settings_helper
INFO - 2018-02-07 18:04:30 --> Helper loaded: permission_helper
INFO - 2018-02-07 18:04:30 --> Helper loaded: users_helper
INFO - 2018-02-07 18:04:30 --> Database Driver Class Initialized
DEBUG - 2018-02-07 18:04:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 18:04:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 18:04:30 --> Helper loaded: form_helper
INFO - 2018-02-07 18:04:30 --> Form Validation Class Initialized
INFO - 2018-02-07 18:04:30 --> Controller Class Initialized
INFO - 2018-02-07 18:04:30 --> Model Class Initialized
INFO - 2018-02-07 18:04:30 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 18:04:30 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 18:04:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 18:04:30 --> Model Class Initialized
INFO - 2018-02-07 18:04:30 --> Model Class Initialized
INFO - 2018-02-07 18:04:30 --> Model Class Initialized
INFO - 2018-02-07 18:04:30 --> Model Class Initialized
INFO - 2018-02-07 18:04:30 --> Model Class Initialized
INFO - 2018-02-07 18:04:30 --> Model Class Initialized
INFO - 2018-02-07 18:04:30 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 18:04:30 --> Model Class Initialized
INFO - 2018-02-07 18:04:30 --> Final output sent to browser
DEBUG - 2018-02-07 18:04:30 --> Total execution time: 0.0975
INFO - 2018-02-07 13:48:54 --> Config Class Initialized
INFO - 2018-02-07 13:48:54 --> Hooks Class Initialized
DEBUG - 2018-02-07 13:48:54 --> UTF-8 Support Enabled
INFO - 2018-02-07 13:48:54 --> Utf8 Class Initialized
INFO - 2018-02-07 13:48:54 --> URI Class Initialized
INFO - 2018-02-07 13:48:54 --> Router Class Initialized
INFO - 2018-02-07 13:48:54 --> Output Class Initialized
INFO - 2018-02-07 13:48:54 --> Security Class Initialized
DEBUG - 2018-02-07 13:48:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 13:48:54 --> Input Class Initialized
INFO - 2018-02-07 13:48:54 --> Language Class Initialized
INFO - 2018-02-07 13:48:54 --> Language Class Initialized
INFO - 2018-02-07 13:48:54 --> Config Class Initialized
INFO - 2018-02-07 13:48:54 --> Loader Class Initialized
INFO - 2018-02-07 19:18:54 --> Helper loaded: url_helper
INFO - 2018-02-07 19:18:54 --> Helper loaded: notification_helper
INFO - 2018-02-07 19:18:54 --> Helper loaded: settings_helper
INFO - 2018-02-07 19:18:54 --> Helper loaded: permission_helper
INFO - 2018-02-07 19:18:54 --> Helper loaded: users_helper
INFO - 2018-02-07 19:18:54 --> Database Driver Class Initialized
DEBUG - 2018-02-07 19:18:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 19:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 19:18:54 --> Helper loaded: form_helper
INFO - 2018-02-07 19:18:54 --> Form Validation Class Initialized
INFO - 2018-02-07 19:18:54 --> Controller Class Initialized
INFO - 2018-02-07 19:18:54 --> Model Class Initialized
INFO - 2018-02-07 19:18:54 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 19:18:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 19:18:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 19:18:54 --> Model Class Initialized
INFO - 2018-02-07 19:18:54 --> Model Class Initialized
INFO - 2018-02-07 19:18:54 --> Model Class Initialized
INFO - 2018-02-07 19:18:54 --> Model Class Initialized
INFO - 2018-02-07 19:18:54 --> Model Class Initialized
INFO - 2018-02-07 19:18:54 --> Model Class Initialized
INFO - 2018-02-07 19:18:54 --> Model Class Initialized
INFO - 2018-02-07 19:18:54 --> Model Class Initialized
INFO - 2018-02-07 19:18:54 --> Model Class Initialized
INFO - 2018-02-07 19:18:54 --> Model Class Initialized
INFO - 2018-02-07 19:18:54 --> Model Class Initialized
INFO - 2018-02-07 19:18:54 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 19:18:54 --> Model Class Initialized
INFO - 2018-02-07 19:18:54 --> Final output sent to browser
DEBUG - 2018-02-07 19:18:54 --> Total execution time: 0.1264
INFO - 2018-02-07 13:48:55 --> Config Class Initialized
INFO - 2018-02-07 13:48:55 --> Hooks Class Initialized
DEBUG - 2018-02-07 13:48:55 --> UTF-8 Support Enabled
INFO - 2018-02-07 13:48:55 --> Utf8 Class Initialized
INFO - 2018-02-07 13:48:55 --> URI Class Initialized
INFO - 2018-02-07 13:48:55 --> Router Class Initialized
INFO - 2018-02-07 13:48:55 --> Output Class Initialized
INFO - 2018-02-07 13:48:55 --> Security Class Initialized
DEBUG - 2018-02-07 13:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 13:48:55 --> Input Class Initialized
INFO - 2018-02-07 13:48:55 --> Language Class Initialized
INFO - 2018-02-07 13:48:55 --> Language Class Initialized
INFO - 2018-02-07 13:48:55 --> Config Class Initialized
INFO - 2018-02-07 13:48:55 --> Loader Class Initialized
INFO - 2018-02-07 19:18:55 --> Helper loaded: url_helper
INFO - 2018-02-07 19:18:55 --> Helper loaded: notification_helper
INFO - 2018-02-07 19:18:55 --> Helper loaded: settings_helper
INFO - 2018-02-07 19:18:55 --> Helper loaded: permission_helper
INFO - 2018-02-07 19:18:55 --> Helper loaded: users_helper
INFO - 2018-02-07 19:18:55 --> Database Driver Class Initialized
DEBUG - 2018-02-07 19:18:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 19:18:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 19:18:55 --> Helper loaded: form_helper
INFO - 2018-02-07 19:18:55 --> Form Validation Class Initialized
INFO - 2018-02-07 19:18:55 --> Controller Class Initialized
INFO - 2018-02-07 19:18:55 --> Model Class Initialized
INFO - 2018-02-07 19:18:55 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 19:18:55 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 19:18:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 19:18:55 --> Model Class Initialized
INFO - 2018-02-07 19:18:55 --> Model Class Initialized
INFO - 2018-02-07 19:18:55 --> Model Class Initialized
INFO - 2018-02-07 19:18:55 --> Model Class Initialized
INFO - 2018-02-07 19:18:55 --> Model Class Initialized
INFO - 2018-02-07 19:18:55 --> Model Class Initialized
INFO - 2018-02-07 19:18:55 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 19:18:55 --> Model Class Initialized
INFO - 2018-02-07 19:18:56 --> Final output sent to browser
DEBUG - 2018-02-07 19:18:56 --> Total execution time: 0.1078
INFO - 2018-02-07 13:49:09 --> Config Class Initialized
INFO - 2018-02-07 13:49:09 --> Hooks Class Initialized
DEBUG - 2018-02-07 13:49:09 --> UTF-8 Support Enabled
INFO - 2018-02-07 13:49:09 --> Utf8 Class Initialized
INFO - 2018-02-07 13:49:09 --> URI Class Initialized
INFO - 2018-02-07 13:49:09 --> Router Class Initialized
INFO - 2018-02-07 13:49:09 --> Output Class Initialized
INFO - 2018-02-07 13:49:09 --> Security Class Initialized
DEBUG - 2018-02-07 13:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 13:49:09 --> Input Class Initialized
INFO - 2018-02-07 13:49:09 --> Language Class Initialized
INFO - 2018-02-07 13:49:09 --> Config Class Initialized
INFO - 2018-02-07 13:49:09 --> Hooks Class Initialized
INFO - 2018-02-07 13:49:09 --> Language Class Initialized
INFO - 2018-02-07 13:49:09 --> Config Class Initialized
INFO - 2018-02-07 13:49:09 --> Loader Class Initialized
DEBUG - 2018-02-07 13:49:09 --> UTF-8 Support Enabled
INFO - 2018-02-07 13:49:09 --> Utf8 Class Initialized
INFO - 2018-02-07 19:19:09 --> Helper loaded: url_helper
INFO - 2018-02-07 19:19:09 --> Helper loaded: notification_helper
INFO - 2018-02-07 13:49:09 --> URI Class Initialized
INFO - 2018-02-07 19:19:09 --> Helper loaded: settings_helper
INFO - 2018-02-07 19:19:09 --> Helper loaded: permission_helper
INFO - 2018-02-07 19:19:09 --> Helper loaded: users_helper
INFO - 2018-02-07 13:49:09 --> Router Class Initialized
INFO - 2018-02-07 13:49:09 --> Output Class Initialized
INFO - 2018-02-07 13:49:09 --> Security Class Initialized
DEBUG - 2018-02-07 13:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 13:49:09 --> Input Class Initialized
INFO - 2018-02-07 13:49:09 --> Language Class Initialized
INFO - 2018-02-07 19:19:09 --> Database Driver Class Initialized
DEBUG - 2018-02-07 19:19:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 19:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 19:19:09 --> Helper loaded: form_helper
INFO - 2018-02-07 19:19:09 --> Form Validation Class Initialized
INFO - 2018-02-07 19:19:09 --> Controller Class Initialized
INFO - 2018-02-07 13:49:09 --> Language Class Initialized
INFO - 2018-02-07 13:49:09 --> Config Class Initialized
INFO - 2018-02-07 13:49:09 --> Loader Class Initialized
INFO - 2018-02-07 19:19:09 --> Helper loaded: url_helper
INFO - 2018-02-07 19:19:09 --> Helper loaded: notification_helper
INFO - 2018-02-07 19:19:09 --> Helper loaded: settings_helper
INFO - 2018-02-07 19:19:09 --> Helper loaded: permission_helper
INFO - 2018-02-07 19:19:09 --> Helper loaded: users_helper
INFO - 2018-02-07 19:19:09 --> Model Class Initialized
INFO - 2018-02-07 19:19:09 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 19:19:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 19:19:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 19:19:09 --> Model Class Initialized
INFO - 2018-02-07 19:19:09 --> Model Class Initialized
INFO - 2018-02-07 19:19:09 --> Model Class Initialized
INFO - 2018-02-07 19:19:09 --> Model Class Initialized
INFO - 2018-02-07 19:19:09 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 19:19:09 --> Final output sent to browser
DEBUG - 2018-02-07 19:19:09 --> Total execution time: 0.1079
INFO - 2018-02-07 19:19:09 --> Database Driver Class Initialized
DEBUG - 2018-02-07 19:19:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 19:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 19:19:09 --> Helper loaded: form_helper
INFO - 2018-02-07 19:19:09 --> Form Validation Class Initialized
INFO - 2018-02-07 19:19:09 --> Controller Class Initialized
INFO - 2018-02-07 19:19:09 --> Model Class Initialized
INFO - 2018-02-07 19:19:09 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 19:19:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 19:19:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 19:19:09 --> Model Class Initialized
INFO - 2018-02-07 19:19:09 --> Model Class Initialized
INFO - 2018-02-07 19:19:09 --> Model Class Initialized
INFO - 2018-02-07 19:19:09 --> Model Class Initialized
INFO - 2018-02-07 19:19:09 --> Model Class Initialized
INFO - 2018-02-07 19:19:09 --> Model Class Initialized
INFO - 2018-02-07 19:19:09 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 19:19:09 --> Final output sent to browser
DEBUG - 2018-02-07 19:19:09 --> Total execution time: 0.1151
INFO - 2018-02-07 13:50:57 --> Config Class Initialized
INFO - 2018-02-07 13:50:57 --> Hooks Class Initialized
DEBUG - 2018-02-07 13:50:57 --> UTF-8 Support Enabled
INFO - 2018-02-07 13:50:57 --> Utf8 Class Initialized
INFO - 2018-02-07 13:50:57 --> URI Class Initialized
INFO - 2018-02-07 13:50:57 --> Router Class Initialized
INFO - 2018-02-07 13:50:57 --> Output Class Initialized
INFO - 2018-02-07 13:50:57 --> Security Class Initialized
DEBUG - 2018-02-07 13:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 13:50:57 --> Input Class Initialized
INFO - 2018-02-07 13:50:57 --> Language Class Initialized
INFO - 2018-02-07 13:50:57 --> Language Class Initialized
INFO - 2018-02-07 13:50:57 --> Config Class Initialized
INFO - 2018-02-07 13:50:57 --> Loader Class Initialized
INFO - 2018-02-07 19:20:57 --> Helper loaded: url_helper
INFO - 2018-02-07 19:20:57 --> Helper loaded: notification_helper
INFO - 2018-02-07 19:20:57 --> Helper loaded: settings_helper
INFO - 2018-02-07 19:20:57 --> Helper loaded: permission_helper
INFO - 2018-02-07 19:20:57 --> Helper loaded: users_helper
INFO - 2018-02-07 19:20:57 --> Database Driver Class Initialized
DEBUG - 2018-02-07 19:20:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 19:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 19:20:57 --> Helper loaded: form_helper
INFO - 2018-02-07 19:20:57 --> Form Validation Class Initialized
INFO - 2018-02-07 19:20:57 --> Controller Class Initialized
INFO - 2018-02-07 19:20:57 --> Model Class Initialized
INFO - 2018-02-07 19:20:57 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 19:20:57 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 19:20:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 19:20:57 --> Model Class Initialized
INFO - 2018-02-07 19:20:57 --> Model Class Initialized
INFO - 2018-02-07 19:20:57 --> Model Class Initialized
INFO - 2018-02-07 19:20:57 --> Model Class Initialized
INFO - 2018-02-07 19:20:57 --> Model Class Initialized
INFO - 2018-02-07 19:20:57 --> Model Class Initialized
INFO - 2018-02-07 19:20:57 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 19:20:57 --> Model Class Initialized
INFO - 2018-02-07 19:20:57 --> Final output sent to browser
DEBUG - 2018-02-07 19:20:57 --> Total execution time: 0.1161
INFO - 2018-02-07 13:51:10 --> Config Class Initialized
INFO - 2018-02-07 13:51:10 --> Hooks Class Initialized
DEBUG - 2018-02-07 13:51:10 --> UTF-8 Support Enabled
INFO - 2018-02-07 13:51:10 --> Utf8 Class Initialized
INFO - 2018-02-07 13:51:10 --> URI Class Initialized
INFO - 2018-02-07 13:51:10 --> Router Class Initialized
INFO - 2018-02-07 13:51:10 --> Output Class Initialized
INFO - 2018-02-07 13:51:10 --> Security Class Initialized
DEBUG - 2018-02-07 13:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 13:51:10 --> Input Class Initialized
INFO - 2018-02-07 13:51:10 --> Language Class Initialized
INFO - 2018-02-07 13:51:10 --> Language Class Initialized
INFO - 2018-02-07 13:51:10 --> Config Class Initialized
INFO - 2018-02-07 13:51:10 --> Loader Class Initialized
INFO - 2018-02-07 19:21:10 --> Helper loaded: url_helper
INFO - 2018-02-07 19:21:10 --> Helper loaded: notification_helper
INFO - 2018-02-07 19:21:10 --> Helper loaded: settings_helper
INFO - 2018-02-07 19:21:10 --> Helper loaded: permission_helper
INFO - 2018-02-07 19:21:10 --> Helper loaded: users_helper
INFO - 2018-02-07 19:21:10 --> Database Driver Class Initialized
DEBUG - 2018-02-07 19:21:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 19:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 19:21:10 --> Helper loaded: form_helper
INFO - 2018-02-07 19:21:10 --> Form Validation Class Initialized
INFO - 2018-02-07 19:21:10 --> Controller Class Initialized
INFO - 2018-02-07 19:21:10 --> Model Class Initialized
INFO - 2018-02-07 19:21:10 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 19:21:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 19:21:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 19:21:10 --> Model Class Initialized
INFO - 2018-02-07 19:21:10 --> Model Class Initialized
INFO - 2018-02-07 19:21:10 --> Model Class Initialized
INFO - 2018-02-07 19:21:10 --> Model Class Initialized
INFO - 2018-02-07 19:21:10 --> Model Class Initialized
INFO - 2018-02-07 19:21:10 --> Model Class Initialized
INFO - 2018-02-07 19:21:10 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 19:21:10 --> Model Class Initialized
INFO - 2018-02-07 19:21:10 --> Final output sent to browser
DEBUG - 2018-02-07 19:21:10 --> Total execution time: 0.1143
INFO - 2018-02-07 13:56:16 --> Config Class Initialized
INFO - 2018-02-07 13:56:16 --> Hooks Class Initialized
DEBUG - 2018-02-07 13:56:16 --> UTF-8 Support Enabled
INFO - 2018-02-07 13:56:16 --> Utf8 Class Initialized
INFO - 2018-02-07 13:56:16 --> URI Class Initialized
INFO - 2018-02-07 13:56:16 --> Router Class Initialized
INFO - 2018-02-07 13:56:16 --> Output Class Initialized
INFO - 2018-02-07 13:56:16 --> Security Class Initialized
DEBUG - 2018-02-07 13:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 13:56:16 --> Input Class Initialized
INFO - 2018-02-07 13:56:16 --> Language Class Initialized
INFO - 2018-02-07 13:56:16 --> Language Class Initialized
INFO - 2018-02-07 13:56:16 --> Config Class Initialized
INFO - 2018-02-07 13:56:16 --> Loader Class Initialized
INFO - 2018-02-07 19:26:16 --> Helper loaded: url_helper
INFO - 2018-02-07 19:26:16 --> Helper loaded: notification_helper
INFO - 2018-02-07 19:26:16 --> Helper loaded: settings_helper
INFO - 2018-02-07 19:26:16 --> Helper loaded: permission_helper
INFO - 2018-02-07 19:26:16 --> Helper loaded: users_helper
INFO - 2018-02-07 19:26:16 --> Database Driver Class Initialized
DEBUG - 2018-02-07 19:26:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 19:26:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 19:26:16 --> Helper loaded: form_helper
INFO - 2018-02-07 19:26:16 --> Form Validation Class Initialized
INFO - 2018-02-07 19:26:16 --> Controller Class Initialized
INFO - 2018-02-07 19:26:16 --> Model Class Initialized
INFO - 2018-02-07 19:26:16 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 19:26:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 19:26:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 19:26:16 --> Model Class Initialized
INFO - 2018-02-07 19:26:16 --> Model Class Initialized
INFO - 2018-02-07 19:26:16 --> Model Class Initialized
INFO - 2018-02-07 19:26:16 --> Model Class Initialized
INFO - 2018-02-07 19:26:16 --> Model Class Initialized
INFO - 2018-02-07 19:26:16 --> Model Class Initialized
INFO - 2018-02-07 19:26:16 --> Model Class Initialized
INFO - 2018-02-07 19:26:16 --> Model Class Initialized
INFO - 2018-02-07 19:26:16 --> Model Class Initialized
INFO - 2018-02-07 19:26:16 --> Model Class Initialized
INFO - 2018-02-07 19:26:16 --> Model Class Initialized
INFO - 2018-02-07 19:26:16 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 19:26:16 --> Model Class Initialized
INFO - 2018-02-07 19:26:16 --> Final output sent to browser
DEBUG - 2018-02-07 19:26:16 --> Total execution time: 0.1359
INFO - 2018-02-07 13:56:17 --> Config Class Initialized
INFO - 2018-02-07 13:56:17 --> Hooks Class Initialized
DEBUG - 2018-02-07 13:56:17 --> UTF-8 Support Enabled
INFO - 2018-02-07 13:56:17 --> Utf8 Class Initialized
INFO - 2018-02-07 13:56:17 --> URI Class Initialized
INFO - 2018-02-07 13:56:17 --> Router Class Initialized
INFO - 2018-02-07 13:56:17 --> Output Class Initialized
INFO - 2018-02-07 13:56:17 --> Security Class Initialized
DEBUG - 2018-02-07 13:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 13:56:17 --> Input Class Initialized
INFO - 2018-02-07 13:56:17 --> Language Class Initialized
INFO - 2018-02-07 13:56:17 --> Language Class Initialized
INFO - 2018-02-07 13:56:17 --> Config Class Initialized
INFO - 2018-02-07 13:56:17 --> Loader Class Initialized
INFO - 2018-02-07 19:26:17 --> Helper loaded: url_helper
INFO - 2018-02-07 19:26:17 --> Helper loaded: notification_helper
INFO - 2018-02-07 19:26:17 --> Helper loaded: settings_helper
INFO - 2018-02-07 19:26:17 --> Helper loaded: permission_helper
INFO - 2018-02-07 19:26:17 --> Helper loaded: users_helper
INFO - 2018-02-07 19:26:17 --> Database Driver Class Initialized
DEBUG - 2018-02-07 19:26:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 19:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 19:26:17 --> Helper loaded: form_helper
INFO - 2018-02-07 19:26:17 --> Form Validation Class Initialized
INFO - 2018-02-07 19:26:17 --> Controller Class Initialized
INFO - 2018-02-07 19:26:17 --> Model Class Initialized
INFO - 2018-02-07 19:26:17 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 19:26:17 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 19:26:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 19:26:17 --> Model Class Initialized
INFO - 2018-02-07 19:26:17 --> Model Class Initialized
INFO - 2018-02-07 19:26:17 --> Model Class Initialized
INFO - 2018-02-07 19:26:17 --> Model Class Initialized
INFO - 2018-02-07 19:26:17 --> Model Class Initialized
INFO - 2018-02-07 19:26:17 --> Model Class Initialized
INFO - 2018-02-07 19:26:17 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 19:26:17 --> Model Class Initialized
INFO - 2018-02-07 19:26:17 --> Final output sent to browser
DEBUG - 2018-02-07 19:26:17 --> Total execution time: 0.1188
INFO - 2018-02-07 13:56:21 --> Config Class Initialized
INFO - 2018-02-07 13:56:21 --> Hooks Class Initialized
DEBUG - 2018-02-07 13:56:21 --> UTF-8 Support Enabled
INFO - 2018-02-07 13:56:21 --> Utf8 Class Initialized
INFO - 2018-02-07 13:56:21 --> URI Class Initialized
INFO - 2018-02-07 13:56:21 --> Router Class Initialized
INFO - 2018-02-07 13:56:21 --> Output Class Initialized
INFO - 2018-02-07 13:56:21 --> Security Class Initialized
DEBUG - 2018-02-07 13:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 13:56:21 --> Input Class Initialized
INFO - 2018-02-07 13:56:21 --> Language Class Initialized
INFO - 2018-02-07 13:56:21 --> Language Class Initialized
INFO - 2018-02-07 13:56:21 --> Config Class Initialized
INFO - 2018-02-07 13:56:21 --> Loader Class Initialized
INFO - 2018-02-07 19:26:21 --> Helper loaded: url_helper
INFO - 2018-02-07 19:26:21 --> Helper loaded: notification_helper
INFO - 2018-02-07 19:26:21 --> Helper loaded: settings_helper
INFO - 2018-02-07 19:26:21 --> Helper loaded: permission_helper
INFO - 2018-02-07 19:26:21 --> Helper loaded: users_helper
INFO - 2018-02-07 19:26:21 --> Database Driver Class Initialized
DEBUG - 2018-02-07 19:26:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 19:26:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 19:26:21 --> Helper loaded: form_helper
INFO - 2018-02-07 19:26:21 --> Form Validation Class Initialized
INFO - 2018-02-07 19:26:21 --> Controller Class Initialized
INFO - 2018-02-07 19:26:21 --> Model Class Initialized
INFO - 2018-02-07 19:26:21 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 19:26:21 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 19:26:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 19:26:21 --> Model Class Initialized
INFO - 2018-02-07 19:26:21 --> Model Class Initialized
INFO - 2018-02-07 19:26:21 --> Model Class Initialized
INFO - 2018-02-07 19:26:21 --> Model Class Initialized
INFO - 2018-02-07 19:26:21 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 19:26:21 --> Final output sent to browser
DEBUG - 2018-02-07 19:26:21 --> Total execution time: 0.1053
INFO - 2018-02-07 13:56:21 --> Config Class Initialized
INFO - 2018-02-07 13:56:21 --> Hooks Class Initialized
DEBUG - 2018-02-07 13:56:21 --> UTF-8 Support Enabled
INFO - 2018-02-07 13:56:21 --> Utf8 Class Initialized
INFO - 2018-02-07 13:56:21 --> URI Class Initialized
INFO - 2018-02-07 13:56:21 --> Router Class Initialized
INFO - 2018-02-07 13:56:21 --> Output Class Initialized
INFO - 2018-02-07 13:56:21 --> Security Class Initialized
DEBUG - 2018-02-07 13:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 13:56:21 --> Input Class Initialized
INFO - 2018-02-07 13:56:21 --> Language Class Initialized
INFO - 2018-02-07 13:56:21 --> Language Class Initialized
INFO - 2018-02-07 13:56:21 --> Config Class Initialized
INFO - 2018-02-07 13:56:21 --> Loader Class Initialized
INFO - 2018-02-07 19:26:21 --> Helper loaded: url_helper
INFO - 2018-02-07 19:26:21 --> Helper loaded: notification_helper
INFO - 2018-02-07 19:26:21 --> Helper loaded: settings_helper
INFO - 2018-02-07 19:26:21 --> Helper loaded: permission_helper
INFO - 2018-02-07 19:26:21 --> Helper loaded: users_helper
INFO - 2018-02-07 19:26:21 --> Database Driver Class Initialized
DEBUG - 2018-02-07 19:26:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 19:26:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 19:26:21 --> Helper loaded: form_helper
INFO - 2018-02-07 19:26:21 --> Form Validation Class Initialized
INFO - 2018-02-07 19:26:21 --> Controller Class Initialized
INFO - 2018-02-07 19:26:21 --> Model Class Initialized
INFO - 2018-02-07 19:26:21 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 19:26:21 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 19:26:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 19:26:21 --> Model Class Initialized
INFO - 2018-02-07 19:26:21 --> Model Class Initialized
INFO - 2018-02-07 19:26:21 --> Model Class Initialized
INFO - 2018-02-07 19:26:21 --> Model Class Initialized
INFO - 2018-02-07 19:26:21 --> Model Class Initialized
INFO - 2018-02-07 19:26:21 --> Model Class Initialized
INFO - 2018-02-07 19:26:21 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 19:26:21 --> Final output sent to browser
DEBUG - 2018-02-07 19:26:21 --> Total execution time: 0.0980
INFO - 2018-02-07 13:56:41 --> Config Class Initialized
INFO - 2018-02-07 13:56:41 --> Hooks Class Initialized
DEBUG - 2018-02-07 13:56:41 --> UTF-8 Support Enabled
INFO - 2018-02-07 13:56:41 --> Utf8 Class Initialized
INFO - 2018-02-07 13:56:41 --> URI Class Initialized
INFO - 2018-02-07 13:56:41 --> Router Class Initialized
INFO - 2018-02-07 13:56:41 --> Output Class Initialized
INFO - 2018-02-07 13:56:41 --> Security Class Initialized
DEBUG - 2018-02-07 13:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 13:56:41 --> Input Class Initialized
INFO - 2018-02-07 13:56:41 --> Language Class Initialized
INFO - 2018-02-07 13:56:41 --> Language Class Initialized
INFO - 2018-02-07 13:56:41 --> Config Class Initialized
INFO - 2018-02-07 13:56:41 --> Loader Class Initialized
INFO - 2018-02-07 19:26:41 --> Helper loaded: url_helper
INFO - 2018-02-07 19:26:41 --> Helper loaded: notification_helper
INFO - 2018-02-07 19:26:41 --> Helper loaded: settings_helper
INFO - 2018-02-07 19:26:41 --> Helper loaded: permission_helper
INFO - 2018-02-07 19:26:41 --> Helper loaded: users_helper
INFO - 2018-02-07 19:26:41 --> Database Driver Class Initialized
DEBUG - 2018-02-07 19:26:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 19:26:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 19:26:41 --> Helper loaded: form_helper
INFO - 2018-02-07 19:26:41 --> Form Validation Class Initialized
INFO - 2018-02-07 19:26:41 --> Controller Class Initialized
INFO - 2018-02-07 19:26:41 --> Model Class Initialized
INFO - 2018-02-07 19:26:41 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 19:26:41 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 19:26:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 19:26:41 --> Model Class Initialized
INFO - 2018-02-07 19:26:41 --> Model Class Initialized
INFO - 2018-02-07 19:26:41 --> Model Class Initialized
INFO - 2018-02-07 19:26:41 --> Model Class Initialized
INFO - 2018-02-07 19:26:41 --> Model Class Initialized
INFO - 2018-02-07 19:26:41 --> Model Class Initialized
INFO - 2018-02-07 19:26:41 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 19:26:41 --> Model Class Initialized
INFO - 2018-02-07 19:26:41 --> Final output sent to browser
DEBUG - 2018-02-07 19:26:41 --> Total execution time: 0.1166
INFO - 2018-02-07 13:56:43 --> Config Class Initialized
INFO - 2018-02-07 13:56:43 --> Hooks Class Initialized
DEBUG - 2018-02-07 13:56:43 --> UTF-8 Support Enabled
INFO - 2018-02-07 13:56:43 --> Utf8 Class Initialized
INFO - 2018-02-07 13:56:43 --> URI Class Initialized
INFO - 2018-02-07 13:56:43 --> Router Class Initialized
INFO - 2018-02-07 13:56:43 --> Output Class Initialized
INFO - 2018-02-07 13:56:43 --> Security Class Initialized
DEBUG - 2018-02-07 13:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 13:56:43 --> Input Class Initialized
INFO - 2018-02-07 13:56:43 --> Language Class Initialized
INFO - 2018-02-07 13:56:43 --> Language Class Initialized
INFO - 2018-02-07 13:56:43 --> Config Class Initialized
INFO - 2018-02-07 13:56:43 --> Loader Class Initialized
INFO - 2018-02-07 19:26:43 --> Helper loaded: url_helper
INFO - 2018-02-07 19:26:43 --> Helper loaded: notification_helper
INFO - 2018-02-07 19:26:43 --> Helper loaded: settings_helper
INFO - 2018-02-07 19:26:43 --> Helper loaded: permission_helper
INFO - 2018-02-07 19:26:43 --> Helper loaded: users_helper
INFO - 2018-02-07 19:26:43 --> Database Driver Class Initialized
DEBUG - 2018-02-07 19:26:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 19:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 19:26:43 --> Helper loaded: form_helper
INFO - 2018-02-07 19:26:43 --> Form Validation Class Initialized
INFO - 2018-02-07 19:26:43 --> Controller Class Initialized
INFO - 2018-02-07 19:26:43 --> Model Class Initialized
INFO - 2018-02-07 19:26:43 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 19:26:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 19:26:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 19:26:43 --> Model Class Initialized
INFO - 2018-02-07 19:26:43 --> Model Class Initialized
INFO - 2018-02-07 19:26:43 --> Model Class Initialized
INFO - 2018-02-07 19:26:43 --> Model Class Initialized
INFO - 2018-02-07 19:26:43 --> Model Class Initialized
INFO - 2018-02-07 19:26:43 --> Model Class Initialized
INFO - 2018-02-07 19:26:43 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 19:26:43 --> Model Class Initialized
INFO - 2018-02-07 19:26:43 --> Final output sent to browser
DEBUG - 2018-02-07 19:26:43 --> Total execution time: 0.0991
INFO - 2018-02-07 13:59:26 --> Config Class Initialized
INFO - 2018-02-07 13:59:26 --> Hooks Class Initialized
DEBUG - 2018-02-07 13:59:26 --> UTF-8 Support Enabled
INFO - 2018-02-07 13:59:26 --> Utf8 Class Initialized
INFO - 2018-02-07 13:59:26 --> URI Class Initialized
INFO - 2018-02-07 13:59:26 --> Router Class Initialized
INFO - 2018-02-07 13:59:26 --> Output Class Initialized
INFO - 2018-02-07 13:59:26 --> Security Class Initialized
DEBUG - 2018-02-07 13:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 13:59:26 --> Input Class Initialized
INFO - 2018-02-07 13:59:26 --> Language Class Initialized
INFO - 2018-02-07 13:59:26 --> Language Class Initialized
INFO - 2018-02-07 13:59:26 --> Config Class Initialized
INFO - 2018-02-07 13:59:26 --> Loader Class Initialized
INFO - 2018-02-07 19:29:26 --> Helper loaded: url_helper
INFO - 2018-02-07 19:29:26 --> Helper loaded: notification_helper
INFO - 2018-02-07 19:29:26 --> Helper loaded: settings_helper
INFO - 2018-02-07 19:29:26 --> Helper loaded: permission_helper
INFO - 2018-02-07 19:29:26 --> Helper loaded: users_helper
INFO - 2018-02-07 19:29:26 --> Database Driver Class Initialized
DEBUG - 2018-02-07 19:29:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 19:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 19:29:26 --> Helper loaded: form_helper
INFO - 2018-02-07 19:29:26 --> Form Validation Class Initialized
INFO - 2018-02-07 19:29:26 --> Controller Class Initialized
INFO - 2018-02-07 19:29:26 --> Model Class Initialized
INFO - 2018-02-07 19:29:26 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 19:29:26 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 19:29:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 19:29:26 --> Model Class Initialized
INFO - 2018-02-07 19:29:26 --> Model Class Initialized
INFO - 2018-02-07 19:29:26 --> Model Class Initialized
INFO - 2018-02-07 19:29:26 --> Model Class Initialized
INFO - 2018-02-07 19:29:26 --> Model Class Initialized
INFO - 2018-02-07 19:29:26 --> Model Class Initialized
INFO - 2018-02-07 19:29:26 --> Model Class Initialized
INFO - 2018-02-07 19:29:26 --> Model Class Initialized
INFO - 2018-02-07 19:29:26 --> Model Class Initialized
INFO - 2018-02-07 19:29:26 --> Model Class Initialized
INFO - 2018-02-07 19:29:26 --> Model Class Initialized
INFO - 2018-02-07 19:29:26 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 19:29:26 --> Model Class Initialized
INFO - 2018-02-07 19:29:27 --> Final output sent to browser
DEBUG - 2018-02-07 19:29:27 --> Total execution time: 0.1864
INFO - 2018-02-07 13:59:27 --> Config Class Initialized
INFO - 2018-02-07 13:59:27 --> Hooks Class Initialized
DEBUG - 2018-02-07 13:59:27 --> UTF-8 Support Enabled
INFO - 2018-02-07 13:59:27 --> Utf8 Class Initialized
INFO - 2018-02-07 13:59:27 --> URI Class Initialized
INFO - 2018-02-07 13:59:27 --> Router Class Initialized
INFO - 2018-02-07 13:59:27 --> Output Class Initialized
INFO - 2018-02-07 13:59:27 --> Security Class Initialized
DEBUG - 2018-02-07 13:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 13:59:27 --> Input Class Initialized
INFO - 2018-02-07 13:59:27 --> Language Class Initialized
INFO - 2018-02-07 13:59:27 --> Language Class Initialized
INFO - 2018-02-07 13:59:27 --> Config Class Initialized
INFO - 2018-02-07 13:59:27 --> Loader Class Initialized
INFO - 2018-02-07 19:29:27 --> Helper loaded: url_helper
INFO - 2018-02-07 19:29:27 --> Helper loaded: notification_helper
INFO - 2018-02-07 19:29:27 --> Helper loaded: settings_helper
INFO - 2018-02-07 19:29:27 --> Helper loaded: permission_helper
INFO - 2018-02-07 19:29:27 --> Helper loaded: users_helper
INFO - 2018-02-07 19:29:27 --> Database Driver Class Initialized
DEBUG - 2018-02-07 19:29:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 19:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 19:29:27 --> Helper loaded: form_helper
INFO - 2018-02-07 19:29:27 --> Form Validation Class Initialized
INFO - 2018-02-07 19:29:27 --> Controller Class Initialized
INFO - 2018-02-07 19:29:27 --> Model Class Initialized
INFO - 2018-02-07 19:29:27 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 19:29:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 19:29:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 19:29:27 --> Model Class Initialized
INFO - 2018-02-07 19:29:27 --> Model Class Initialized
INFO - 2018-02-07 19:29:27 --> Model Class Initialized
INFO - 2018-02-07 19:29:27 --> Model Class Initialized
INFO - 2018-02-07 19:29:27 --> Model Class Initialized
INFO - 2018-02-07 19:29:27 --> Model Class Initialized
INFO - 2018-02-07 19:29:27 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 19:29:27 --> Model Class Initialized
INFO - 2018-02-07 19:29:27 --> Final output sent to browser
DEBUG - 2018-02-07 19:29:27 --> Total execution time: 0.1058
INFO - 2018-02-07 13:59:34 --> Config Class Initialized
INFO - 2018-02-07 13:59:34 --> Hooks Class Initialized
DEBUG - 2018-02-07 13:59:34 --> UTF-8 Support Enabled
INFO - 2018-02-07 13:59:34 --> Utf8 Class Initialized
INFO - 2018-02-07 13:59:34 --> Config Class Initialized
INFO - 2018-02-07 13:59:34 --> Hooks Class Initialized
INFO - 2018-02-07 13:59:34 --> URI Class Initialized
DEBUG - 2018-02-07 13:59:34 --> UTF-8 Support Enabled
INFO - 2018-02-07 13:59:34 --> Utf8 Class Initialized
INFO - 2018-02-07 13:59:34 --> Router Class Initialized
INFO - 2018-02-07 13:59:34 --> URI Class Initialized
INFO - 2018-02-07 13:59:34 --> Output Class Initialized
INFO - 2018-02-07 13:59:34 --> Router Class Initialized
INFO - 2018-02-07 13:59:34 --> Security Class Initialized
INFO - 2018-02-07 13:59:34 --> Output Class Initialized
DEBUG - 2018-02-07 13:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 13:59:34 --> Input Class Initialized
INFO - 2018-02-07 13:59:34 --> Language Class Initialized
INFO - 2018-02-07 13:59:34 --> Security Class Initialized
DEBUG - 2018-02-07 13:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 13:59:34 --> Input Class Initialized
INFO - 2018-02-07 13:59:34 --> Language Class Initialized
INFO - 2018-02-07 13:59:34 --> Language Class Initialized
INFO - 2018-02-07 13:59:34 --> Config Class Initialized
INFO - 2018-02-07 13:59:34 --> Loader Class Initialized
INFO - 2018-02-07 19:29:34 --> Helper loaded: url_helper
INFO - 2018-02-07 19:29:34 --> Helper loaded: notification_helper
INFO - 2018-02-07 19:29:34 --> Helper loaded: settings_helper
INFO - 2018-02-07 19:29:34 --> Helper loaded: permission_helper
INFO - 2018-02-07 19:29:34 --> Helper loaded: users_helper
INFO - 2018-02-07 13:59:34 --> Language Class Initialized
INFO - 2018-02-07 13:59:34 --> Config Class Initialized
INFO - 2018-02-07 13:59:34 --> Loader Class Initialized
INFO - 2018-02-07 19:29:34 --> Helper loaded: url_helper
INFO - 2018-02-07 19:29:34 --> Helper loaded: notification_helper
INFO - 2018-02-07 19:29:34 --> Helper loaded: settings_helper
INFO - 2018-02-07 19:29:34 --> Helper loaded: permission_helper
INFO - 2018-02-07 19:29:34 --> Helper loaded: users_helper
INFO - 2018-02-07 19:29:34 --> Database Driver Class Initialized
DEBUG - 2018-02-07 19:29:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 19:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 19:29:34 --> Database Driver Class Initialized
DEBUG - 2018-02-07 19:29:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 19:29:34 --> Helper loaded: form_helper
INFO - 2018-02-07 19:29:34 --> Form Validation Class Initialized
INFO - 2018-02-07 19:29:34 --> Controller Class Initialized
INFO - 2018-02-07 19:29:34 --> Model Class Initialized
INFO - 2018-02-07 19:29:34 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 19:29:34 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 19:29:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 19:29:34 --> Model Class Initialized
INFO - 2018-02-07 19:29:34 --> Model Class Initialized
INFO - 2018-02-07 19:29:34 --> Model Class Initialized
INFO - 2018-02-07 19:29:34 --> Model Class Initialized
INFO - 2018-02-07 19:29:34 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 19:29:34 --> Final output sent to browser
DEBUG - 2018-02-07 19:29:34 --> Total execution time: 0.1039
INFO - 2018-02-07 19:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 19:29:34 --> Helper loaded: form_helper
INFO - 2018-02-07 19:29:34 --> Form Validation Class Initialized
INFO - 2018-02-07 19:29:34 --> Controller Class Initialized
INFO - 2018-02-07 19:29:34 --> Model Class Initialized
INFO - 2018-02-07 19:29:34 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 19:29:34 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 19:29:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 19:29:34 --> Model Class Initialized
INFO - 2018-02-07 19:29:34 --> Model Class Initialized
INFO - 2018-02-07 19:29:34 --> Model Class Initialized
INFO - 2018-02-07 19:29:34 --> Model Class Initialized
INFO - 2018-02-07 19:29:34 --> Model Class Initialized
INFO - 2018-02-07 19:29:34 --> Model Class Initialized
INFO - 2018-02-07 19:29:34 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 19:29:34 --> Final output sent to browser
DEBUG - 2018-02-07 19:29:34 --> Total execution time: 0.1305
INFO - 2018-02-07 13:59:39 --> Config Class Initialized
INFO - 2018-02-07 13:59:39 --> Hooks Class Initialized
DEBUG - 2018-02-07 13:59:39 --> UTF-8 Support Enabled
INFO - 2018-02-07 13:59:39 --> Utf8 Class Initialized
INFO - 2018-02-07 13:59:39 --> URI Class Initialized
INFO - 2018-02-07 13:59:39 --> Router Class Initialized
INFO - 2018-02-07 13:59:39 --> Output Class Initialized
INFO - 2018-02-07 13:59:39 --> Security Class Initialized
DEBUG - 2018-02-07 13:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 13:59:39 --> Input Class Initialized
INFO - 2018-02-07 13:59:39 --> Language Class Initialized
INFO - 2018-02-07 13:59:39 --> Language Class Initialized
INFO - 2018-02-07 13:59:39 --> Config Class Initialized
INFO - 2018-02-07 13:59:39 --> Loader Class Initialized
INFO - 2018-02-07 19:29:39 --> Helper loaded: url_helper
INFO - 2018-02-07 19:29:39 --> Helper loaded: notification_helper
INFO - 2018-02-07 19:29:39 --> Helper loaded: settings_helper
INFO - 2018-02-07 19:29:39 --> Helper loaded: permission_helper
INFO - 2018-02-07 19:29:39 --> Helper loaded: users_helper
INFO - 2018-02-07 19:29:39 --> Database Driver Class Initialized
DEBUG - 2018-02-07 19:29:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 19:29:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 19:29:39 --> Helper loaded: form_helper
INFO - 2018-02-07 19:29:39 --> Form Validation Class Initialized
INFO - 2018-02-07 19:29:39 --> Controller Class Initialized
INFO - 2018-02-07 19:29:39 --> Model Class Initialized
INFO - 2018-02-07 19:29:39 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 19:29:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 19:29:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 19:29:39 --> Model Class Initialized
INFO - 2018-02-07 19:29:39 --> Model Class Initialized
INFO - 2018-02-07 19:29:39 --> Model Class Initialized
INFO - 2018-02-07 19:29:39 --> Model Class Initialized
INFO - 2018-02-07 19:29:39 --> Model Class Initialized
INFO - 2018-02-07 19:29:39 --> Model Class Initialized
INFO - 2018-02-07 19:29:39 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 19:29:39 --> Model Class Initialized
INFO - 2018-02-07 19:29:39 --> Final output sent to browser
DEBUG - 2018-02-07 19:29:39 --> Total execution time: 0.0845
INFO - 2018-02-07 13:59:41 --> Config Class Initialized
INFO - 2018-02-07 13:59:41 --> Hooks Class Initialized
DEBUG - 2018-02-07 13:59:41 --> UTF-8 Support Enabled
INFO - 2018-02-07 13:59:41 --> Utf8 Class Initialized
INFO - 2018-02-07 13:59:41 --> URI Class Initialized
INFO - 2018-02-07 13:59:41 --> Router Class Initialized
INFO - 2018-02-07 13:59:41 --> Output Class Initialized
INFO - 2018-02-07 13:59:41 --> Security Class Initialized
DEBUG - 2018-02-07 13:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 13:59:42 --> Input Class Initialized
INFO - 2018-02-07 13:59:42 --> Language Class Initialized
INFO - 2018-02-07 13:59:42 --> Language Class Initialized
INFO - 2018-02-07 13:59:42 --> Config Class Initialized
INFO - 2018-02-07 13:59:42 --> Loader Class Initialized
INFO - 2018-02-07 19:29:42 --> Helper loaded: url_helper
INFO - 2018-02-07 19:29:42 --> Helper loaded: notification_helper
INFO - 2018-02-07 19:29:42 --> Helper loaded: settings_helper
INFO - 2018-02-07 19:29:42 --> Helper loaded: permission_helper
INFO - 2018-02-07 19:29:42 --> Helper loaded: users_helper
INFO - 2018-02-07 19:29:42 --> Database Driver Class Initialized
DEBUG - 2018-02-07 19:29:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 19:29:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 19:29:42 --> Helper loaded: form_helper
INFO - 2018-02-07 19:29:42 --> Form Validation Class Initialized
INFO - 2018-02-07 19:29:42 --> Controller Class Initialized
INFO - 2018-02-07 19:29:42 --> Model Class Initialized
INFO - 2018-02-07 19:29:42 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 19:29:42 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 19:29:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 19:29:42 --> Model Class Initialized
INFO - 2018-02-07 19:29:42 --> Model Class Initialized
INFO - 2018-02-07 19:29:42 --> Model Class Initialized
INFO - 2018-02-07 19:29:42 --> Model Class Initialized
INFO - 2018-02-07 19:29:42 --> Model Class Initialized
INFO - 2018-02-07 19:29:42 --> Model Class Initialized
INFO - 2018-02-07 19:29:42 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 19:29:42 --> Model Class Initialized
INFO - 2018-02-07 19:29:42 --> Final output sent to browser
DEBUG - 2018-02-07 19:29:42 --> Total execution time: 0.1094
INFO - 2018-02-07 14:05:27 --> Config Class Initialized
INFO - 2018-02-07 14:05:27 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:05:27 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:05:27 --> Utf8 Class Initialized
INFO - 2018-02-07 14:05:27 --> URI Class Initialized
INFO - 2018-02-07 14:05:27 --> Router Class Initialized
INFO - 2018-02-07 14:05:27 --> Output Class Initialized
INFO - 2018-02-07 14:05:27 --> Security Class Initialized
DEBUG - 2018-02-07 14:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:05:27 --> Input Class Initialized
INFO - 2018-02-07 14:05:27 --> Language Class Initialized
INFO - 2018-02-07 14:05:27 --> Language Class Initialized
INFO - 2018-02-07 14:05:27 --> Config Class Initialized
INFO - 2018-02-07 14:05:27 --> Loader Class Initialized
INFO - 2018-02-07 19:35:27 --> Helper loaded: url_helper
INFO - 2018-02-07 19:35:27 --> Helper loaded: notification_helper
INFO - 2018-02-07 19:35:27 --> Helper loaded: settings_helper
INFO - 2018-02-07 19:35:27 --> Helper loaded: permission_helper
INFO - 2018-02-07 19:35:27 --> Helper loaded: users_helper
INFO - 2018-02-07 19:35:27 --> Database Driver Class Initialized
DEBUG - 2018-02-07 19:35:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 19:35:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 19:35:27 --> Helper loaded: form_helper
INFO - 2018-02-07 19:35:27 --> Form Validation Class Initialized
INFO - 2018-02-07 19:35:27 --> Controller Class Initialized
INFO - 2018-02-07 19:35:27 --> Model Class Initialized
INFO - 2018-02-07 19:35:27 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 19:35:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 19:35:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 19:35:27 --> Model Class Initialized
INFO - 2018-02-07 19:35:27 --> Model Class Initialized
INFO - 2018-02-07 19:35:27 --> Model Class Initialized
INFO - 2018-02-07 19:35:27 --> Model Class Initialized
INFO - 2018-02-07 19:35:27 --> Model Class Initialized
INFO - 2018-02-07 19:35:27 --> Model Class Initialized
INFO - 2018-02-07 19:35:27 --> Model Class Initialized
INFO - 2018-02-07 19:35:27 --> Model Class Initialized
INFO - 2018-02-07 19:35:27 --> Model Class Initialized
INFO - 2018-02-07 19:35:27 --> Model Class Initialized
INFO - 2018-02-07 19:35:27 --> Model Class Initialized
INFO - 2018-02-07 19:35:27 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 19:35:27 --> Model Class Initialized
INFO - 2018-02-07 19:35:27 --> Final output sent to browser
DEBUG - 2018-02-07 19:35:27 --> Total execution time: 0.0932
INFO - 2018-02-07 14:05:28 --> Config Class Initialized
INFO - 2018-02-07 14:05:28 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:05:28 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:05:28 --> Utf8 Class Initialized
INFO - 2018-02-07 14:05:28 --> URI Class Initialized
INFO - 2018-02-07 14:05:28 --> Router Class Initialized
INFO - 2018-02-07 14:05:28 --> Output Class Initialized
INFO - 2018-02-07 14:05:28 --> Security Class Initialized
DEBUG - 2018-02-07 14:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:05:28 --> Input Class Initialized
INFO - 2018-02-07 14:05:28 --> Language Class Initialized
INFO - 2018-02-07 14:05:28 --> Language Class Initialized
INFO - 2018-02-07 14:05:28 --> Config Class Initialized
INFO - 2018-02-07 14:05:28 --> Loader Class Initialized
INFO - 2018-02-07 19:35:28 --> Helper loaded: url_helper
INFO - 2018-02-07 19:35:28 --> Helper loaded: notification_helper
INFO - 2018-02-07 19:35:28 --> Helper loaded: settings_helper
INFO - 2018-02-07 19:35:28 --> Helper loaded: permission_helper
INFO - 2018-02-07 19:35:28 --> Helper loaded: users_helper
INFO - 2018-02-07 19:35:28 --> Database Driver Class Initialized
DEBUG - 2018-02-07 19:35:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 19:35:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 19:35:28 --> Helper loaded: form_helper
INFO - 2018-02-07 19:35:28 --> Form Validation Class Initialized
INFO - 2018-02-07 19:35:28 --> Controller Class Initialized
INFO - 2018-02-07 19:35:28 --> Model Class Initialized
INFO - 2018-02-07 19:35:28 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 19:35:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 19:35:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 19:35:28 --> Model Class Initialized
INFO - 2018-02-07 19:35:28 --> Model Class Initialized
INFO - 2018-02-07 19:35:28 --> Model Class Initialized
INFO - 2018-02-07 19:35:28 --> Model Class Initialized
INFO - 2018-02-07 19:35:28 --> Model Class Initialized
INFO - 2018-02-07 19:35:28 --> Model Class Initialized
INFO - 2018-02-07 19:35:28 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 19:35:28 --> Model Class Initialized
INFO - 2018-02-07 19:35:28 --> Final output sent to browser
DEBUG - 2018-02-07 19:35:28 --> Total execution time: 0.0772
INFO - 2018-02-07 14:05:40 --> Config Class Initialized
INFO - 2018-02-07 14:05:40 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:05:40 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:05:40 --> Utf8 Class Initialized
INFO - 2018-02-07 14:05:40 --> URI Class Initialized
INFO - 2018-02-07 14:05:40 --> Router Class Initialized
INFO - 2018-02-07 14:05:40 --> Output Class Initialized
INFO - 2018-02-07 14:05:40 --> Security Class Initialized
DEBUG - 2018-02-07 14:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:05:40 --> Input Class Initialized
INFO - 2018-02-07 14:05:40 --> Language Class Initialized
INFO - 2018-02-07 14:05:40 --> Language Class Initialized
INFO - 2018-02-07 14:05:40 --> Config Class Initialized
INFO - 2018-02-07 14:05:40 --> Loader Class Initialized
INFO - 2018-02-07 19:35:40 --> Helper loaded: url_helper
INFO - 2018-02-07 19:35:40 --> Helper loaded: notification_helper
INFO - 2018-02-07 19:35:40 --> Helper loaded: settings_helper
INFO - 2018-02-07 19:35:40 --> Helper loaded: permission_helper
INFO - 2018-02-07 19:35:40 --> Helper loaded: users_helper
INFO - 2018-02-07 19:35:40 --> Database Driver Class Initialized
DEBUG - 2018-02-07 19:35:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 19:35:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 19:35:40 --> Helper loaded: form_helper
INFO - 2018-02-07 19:35:40 --> Form Validation Class Initialized
INFO - 2018-02-07 19:35:40 --> Controller Class Initialized
INFO - 2018-02-07 19:35:40 --> Model Class Initialized
INFO - 2018-02-07 19:35:40 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 19:35:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 19:35:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 19:35:40 --> Model Class Initialized
INFO - 2018-02-07 19:35:40 --> Model Class Initialized
INFO - 2018-02-07 19:35:40 --> Model Class Initialized
INFO - 2018-02-07 19:35:40 --> Model Class Initialized
INFO - 2018-02-07 19:35:40 --> Model Class Initialized
INFO - 2018-02-07 19:35:40 --> Model Class Initialized
INFO - 2018-02-07 19:35:40 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 19:35:40 --> Final output sent to browser
DEBUG - 2018-02-07 19:35:40 --> Total execution time: 0.1130
INFO - 2018-02-07 14:05:40 --> Config Class Initialized
INFO - 2018-02-07 14:05:40 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:05:40 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:05:40 --> Utf8 Class Initialized
INFO - 2018-02-07 14:05:40 --> URI Class Initialized
INFO - 2018-02-07 14:05:40 --> Router Class Initialized
INFO - 2018-02-07 14:05:40 --> Output Class Initialized
INFO - 2018-02-07 14:05:40 --> Security Class Initialized
DEBUG - 2018-02-07 14:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:05:40 --> Input Class Initialized
INFO - 2018-02-07 14:05:40 --> Language Class Initialized
INFO - 2018-02-07 14:05:40 --> Language Class Initialized
INFO - 2018-02-07 14:05:40 --> Config Class Initialized
INFO - 2018-02-07 14:05:40 --> Loader Class Initialized
INFO - 2018-02-07 19:35:40 --> Helper loaded: url_helper
INFO - 2018-02-07 19:35:40 --> Helper loaded: notification_helper
INFO - 2018-02-07 19:35:40 --> Helper loaded: settings_helper
INFO - 2018-02-07 19:35:40 --> Helper loaded: permission_helper
INFO - 2018-02-07 19:35:40 --> Helper loaded: users_helper
INFO - 2018-02-07 19:35:40 --> Database Driver Class Initialized
DEBUG - 2018-02-07 19:35:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 19:35:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 19:35:40 --> Helper loaded: form_helper
INFO - 2018-02-07 19:35:40 --> Form Validation Class Initialized
INFO - 2018-02-07 19:35:40 --> Controller Class Initialized
INFO - 2018-02-07 19:35:40 --> Model Class Initialized
INFO - 2018-02-07 19:35:40 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 19:35:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 19:35:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 19:35:40 --> Model Class Initialized
INFO - 2018-02-07 19:35:40 --> Model Class Initialized
INFO - 2018-02-07 19:35:40 --> Model Class Initialized
INFO - 2018-02-07 19:35:40 --> Model Class Initialized
INFO - 2018-02-07 19:35:40 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 19:35:40 --> Final output sent to browser
DEBUG - 2018-02-07 19:35:40 --> Total execution time: 0.1056
INFO - 2018-02-07 14:05:44 --> Config Class Initialized
INFO - 2018-02-07 14:05:44 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:05:44 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:05:44 --> Utf8 Class Initialized
INFO - 2018-02-07 14:05:44 --> URI Class Initialized
INFO - 2018-02-07 14:05:44 --> Router Class Initialized
INFO - 2018-02-07 14:05:44 --> Output Class Initialized
INFO - 2018-02-07 14:05:44 --> Security Class Initialized
DEBUG - 2018-02-07 14:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:05:44 --> Input Class Initialized
INFO - 2018-02-07 14:05:44 --> Language Class Initialized
INFO - 2018-02-07 14:05:44 --> Language Class Initialized
INFO - 2018-02-07 14:05:44 --> Config Class Initialized
INFO - 2018-02-07 14:05:44 --> Loader Class Initialized
INFO - 2018-02-07 19:35:44 --> Helper loaded: url_helper
INFO - 2018-02-07 19:35:44 --> Helper loaded: notification_helper
INFO - 2018-02-07 19:35:44 --> Helper loaded: settings_helper
INFO - 2018-02-07 19:35:44 --> Helper loaded: permission_helper
INFO - 2018-02-07 19:35:44 --> Helper loaded: users_helper
INFO - 2018-02-07 19:35:44 --> Database Driver Class Initialized
DEBUG - 2018-02-07 19:35:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 19:35:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 19:35:44 --> Helper loaded: form_helper
INFO - 2018-02-07 19:35:44 --> Form Validation Class Initialized
INFO - 2018-02-07 19:35:44 --> Controller Class Initialized
INFO - 2018-02-07 19:35:44 --> Model Class Initialized
INFO - 2018-02-07 19:35:44 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 19:35:44 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 19:35:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 19:35:44 --> Model Class Initialized
INFO - 2018-02-07 19:35:44 --> Model Class Initialized
INFO - 2018-02-07 19:35:44 --> Model Class Initialized
INFO - 2018-02-07 19:35:44 --> Model Class Initialized
INFO - 2018-02-07 19:35:44 --> Model Class Initialized
INFO - 2018-02-07 19:35:44 --> Model Class Initialized
INFO - 2018-02-07 19:35:44 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 19:35:44 --> Model Class Initialized
INFO - 2018-02-07 19:35:44 --> Final output sent to browser
DEBUG - 2018-02-07 19:35:44 --> Total execution time: 0.1173
INFO - 2018-02-07 14:05:47 --> Config Class Initialized
INFO - 2018-02-07 14:05:47 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:05:47 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:05:47 --> Utf8 Class Initialized
INFO - 2018-02-07 14:05:47 --> URI Class Initialized
INFO - 2018-02-07 14:05:47 --> Router Class Initialized
INFO - 2018-02-07 14:05:47 --> Output Class Initialized
INFO - 2018-02-07 14:05:47 --> Security Class Initialized
DEBUG - 2018-02-07 14:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:05:47 --> Input Class Initialized
INFO - 2018-02-07 14:05:47 --> Language Class Initialized
INFO - 2018-02-07 14:05:47 --> Language Class Initialized
INFO - 2018-02-07 14:05:47 --> Config Class Initialized
INFO - 2018-02-07 14:05:47 --> Loader Class Initialized
INFO - 2018-02-07 19:35:47 --> Helper loaded: url_helper
INFO - 2018-02-07 19:35:47 --> Helper loaded: notification_helper
INFO - 2018-02-07 19:35:47 --> Helper loaded: settings_helper
INFO - 2018-02-07 19:35:47 --> Helper loaded: permission_helper
INFO - 2018-02-07 19:35:47 --> Helper loaded: users_helper
INFO - 2018-02-07 19:35:47 --> Database Driver Class Initialized
DEBUG - 2018-02-07 19:35:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 19:35:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 19:35:47 --> Helper loaded: form_helper
INFO - 2018-02-07 19:35:47 --> Form Validation Class Initialized
INFO - 2018-02-07 19:35:47 --> Controller Class Initialized
INFO - 2018-02-07 19:35:47 --> Model Class Initialized
INFO - 2018-02-07 19:35:47 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 19:35:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 19:35:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 19:35:47 --> Model Class Initialized
INFO - 2018-02-07 19:35:47 --> Model Class Initialized
INFO - 2018-02-07 19:35:47 --> Model Class Initialized
INFO - 2018-02-07 19:35:47 --> Model Class Initialized
INFO - 2018-02-07 19:35:47 --> Model Class Initialized
INFO - 2018-02-07 19:35:47 --> Model Class Initialized
INFO - 2018-02-07 19:35:47 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 19:35:47 --> Model Class Initialized
INFO - 2018-02-07 19:35:47 --> Final output sent to browser
DEBUG - 2018-02-07 19:35:47 --> Total execution time: 0.1456
INFO - 2018-02-07 14:07:27 --> Config Class Initialized
INFO - 2018-02-07 14:07:27 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:07:27 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:07:27 --> Utf8 Class Initialized
INFO - 2018-02-07 14:07:27 --> URI Class Initialized
INFO - 2018-02-07 14:07:27 --> Router Class Initialized
INFO - 2018-02-07 14:07:27 --> Output Class Initialized
INFO - 2018-02-07 14:07:27 --> Security Class Initialized
DEBUG - 2018-02-07 14:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:07:27 --> Input Class Initialized
INFO - 2018-02-07 14:07:27 --> Language Class Initialized
INFO - 2018-02-07 14:07:27 --> Language Class Initialized
INFO - 2018-02-07 14:07:27 --> Config Class Initialized
INFO - 2018-02-07 14:07:27 --> Loader Class Initialized
INFO - 2018-02-07 19:37:27 --> Helper loaded: url_helper
INFO - 2018-02-07 19:37:27 --> Helper loaded: notification_helper
INFO - 2018-02-07 19:37:27 --> Helper loaded: settings_helper
INFO - 2018-02-07 19:37:27 --> Helper loaded: permission_helper
INFO - 2018-02-07 19:37:27 --> Helper loaded: users_helper
INFO - 2018-02-07 19:37:27 --> Database Driver Class Initialized
DEBUG - 2018-02-07 19:37:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 19:37:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 19:37:27 --> Helper loaded: form_helper
INFO - 2018-02-07 19:37:27 --> Form Validation Class Initialized
INFO - 2018-02-07 19:37:27 --> Controller Class Initialized
INFO - 2018-02-07 19:37:27 --> Model Class Initialized
INFO - 2018-02-07 19:37:27 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 19:37:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 19:37:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 19:37:27 --> Model Class Initialized
INFO - 2018-02-07 19:37:27 --> Model Class Initialized
INFO - 2018-02-07 19:37:27 --> Model Class Initialized
INFO - 2018-02-07 19:37:27 --> Model Class Initialized
INFO - 2018-02-07 19:37:27 --> Model Class Initialized
INFO - 2018-02-07 19:37:27 --> Model Class Initialized
INFO - 2018-02-07 19:37:27 --> Model Class Initialized
INFO - 2018-02-07 19:37:27 --> Model Class Initialized
INFO - 2018-02-07 19:37:27 --> Model Class Initialized
INFO - 2018-02-07 19:37:27 --> Model Class Initialized
INFO - 2018-02-07 19:37:27 --> Model Class Initialized
INFO - 2018-02-07 19:37:27 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 19:37:27 --> Model Class Initialized
INFO - 2018-02-07 19:37:27 --> Final output sent to browser
DEBUG - 2018-02-07 19:37:27 --> Total execution time: 0.1229
INFO - 2018-02-07 14:07:28 --> Config Class Initialized
INFO - 2018-02-07 14:07:28 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:07:28 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:07:28 --> Utf8 Class Initialized
INFO - 2018-02-07 14:07:28 --> URI Class Initialized
INFO - 2018-02-07 14:07:28 --> Router Class Initialized
INFO - 2018-02-07 14:07:28 --> Output Class Initialized
INFO - 2018-02-07 14:07:28 --> Security Class Initialized
DEBUG - 2018-02-07 14:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:07:28 --> Input Class Initialized
INFO - 2018-02-07 14:07:28 --> Language Class Initialized
INFO - 2018-02-07 14:07:28 --> Language Class Initialized
INFO - 2018-02-07 14:07:28 --> Config Class Initialized
INFO - 2018-02-07 14:07:28 --> Loader Class Initialized
INFO - 2018-02-07 19:37:28 --> Helper loaded: url_helper
INFO - 2018-02-07 19:37:28 --> Helper loaded: notification_helper
INFO - 2018-02-07 19:37:28 --> Helper loaded: settings_helper
INFO - 2018-02-07 19:37:28 --> Helper loaded: permission_helper
INFO - 2018-02-07 19:37:28 --> Helper loaded: users_helper
INFO - 2018-02-07 19:37:28 --> Database Driver Class Initialized
DEBUG - 2018-02-07 19:37:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 19:37:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 19:37:28 --> Helper loaded: form_helper
INFO - 2018-02-07 19:37:28 --> Form Validation Class Initialized
INFO - 2018-02-07 19:37:28 --> Controller Class Initialized
INFO - 2018-02-07 19:37:28 --> Model Class Initialized
INFO - 2018-02-07 19:37:28 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 19:37:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 19:37:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 19:37:28 --> Model Class Initialized
INFO - 2018-02-07 19:37:28 --> Model Class Initialized
INFO - 2018-02-07 19:37:28 --> Model Class Initialized
INFO - 2018-02-07 19:37:28 --> Model Class Initialized
INFO - 2018-02-07 19:37:28 --> Model Class Initialized
INFO - 2018-02-07 19:37:28 --> Model Class Initialized
INFO - 2018-02-07 19:37:28 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 19:37:28 --> Model Class Initialized
INFO - 2018-02-07 19:37:28 --> Final output sent to browser
DEBUG - 2018-02-07 19:37:28 --> Total execution time: 0.0977
INFO - 2018-02-07 14:07:35 --> Config Class Initialized
INFO - 2018-02-07 14:07:35 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:07:35 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:07:35 --> Utf8 Class Initialized
INFO - 2018-02-07 14:07:35 --> URI Class Initialized
INFO - 2018-02-07 14:07:35 --> Router Class Initialized
INFO - 2018-02-07 14:07:35 --> Output Class Initialized
INFO - 2018-02-07 14:07:35 --> Config Class Initialized
INFO - 2018-02-07 14:07:35 --> Hooks Class Initialized
INFO - 2018-02-07 14:07:35 --> Security Class Initialized
DEBUG - 2018-02-07 14:07:35 --> UTF-8 Support Enabled
DEBUG - 2018-02-07 14:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:07:35 --> Utf8 Class Initialized
INFO - 2018-02-07 14:07:35 --> Input Class Initialized
INFO - 2018-02-07 14:07:35 --> Language Class Initialized
INFO - 2018-02-07 14:07:35 --> URI Class Initialized
INFO - 2018-02-07 14:07:35 --> Router Class Initialized
INFO - 2018-02-07 14:07:35 --> Output Class Initialized
INFO - 2018-02-07 14:07:35 --> Security Class Initialized
DEBUG - 2018-02-07 14:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:07:35 --> Input Class Initialized
INFO - 2018-02-07 14:07:35 --> Language Class Initialized
INFO - 2018-02-07 14:07:35 --> Language Class Initialized
INFO - 2018-02-07 14:07:35 --> Config Class Initialized
INFO - 2018-02-07 14:07:35 --> Loader Class Initialized
INFO - 2018-02-07 19:37:35 --> Helper loaded: url_helper
INFO - 2018-02-07 19:37:35 --> Helper loaded: notification_helper
INFO - 2018-02-07 19:37:35 --> Helper loaded: settings_helper
INFO - 2018-02-07 19:37:35 --> Helper loaded: permission_helper
INFO - 2018-02-07 19:37:35 --> Helper loaded: users_helper
INFO - 2018-02-07 14:07:35 --> Language Class Initialized
INFO - 2018-02-07 14:07:35 --> Config Class Initialized
INFO - 2018-02-07 14:07:35 --> Loader Class Initialized
INFO - 2018-02-07 19:37:35 --> Helper loaded: url_helper
INFO - 2018-02-07 19:37:35 --> Helper loaded: notification_helper
INFO - 2018-02-07 19:37:35 --> Helper loaded: settings_helper
INFO - 2018-02-07 19:37:35 --> Helper loaded: permission_helper
INFO - 2018-02-07 19:37:35 --> Helper loaded: users_helper
INFO - 2018-02-07 19:37:35 --> Database Driver Class Initialized
DEBUG - 2018-02-07 19:37:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 19:37:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 19:37:35 --> Helper loaded: form_helper
INFO - 2018-02-07 19:37:35 --> Form Validation Class Initialized
INFO - 2018-02-07 19:37:35 --> Controller Class Initialized
INFO - 2018-02-07 19:37:35 --> Database Driver Class Initialized
DEBUG - 2018-02-07 19:37:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 19:37:35 --> Model Class Initialized
INFO - 2018-02-07 19:37:35 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 19:37:35 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 19:37:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 19:37:35 --> Model Class Initialized
INFO - 2018-02-07 19:37:35 --> Model Class Initialized
INFO - 2018-02-07 19:37:35 --> Model Class Initialized
INFO - 2018-02-07 19:37:35 --> Model Class Initialized
INFO - 2018-02-07 19:37:35 --> Model Class Initialized
INFO - 2018-02-07 19:37:35 --> Model Class Initialized
INFO - 2018-02-07 19:37:35 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 19:37:35 --> Final output sent to browser
DEBUG - 2018-02-07 19:37:35 --> Total execution time: 0.1066
INFO - 2018-02-07 19:37:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 19:37:35 --> Helper loaded: form_helper
INFO - 2018-02-07 19:37:35 --> Form Validation Class Initialized
INFO - 2018-02-07 19:37:35 --> Controller Class Initialized
INFO - 2018-02-07 19:37:35 --> Model Class Initialized
INFO - 2018-02-07 19:37:35 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 19:37:35 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 19:37:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 19:37:35 --> Model Class Initialized
INFO - 2018-02-07 19:37:35 --> Model Class Initialized
INFO - 2018-02-07 19:37:35 --> Model Class Initialized
INFO - 2018-02-07 19:37:35 --> Model Class Initialized
INFO - 2018-02-07 19:37:35 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 19:37:35 --> Final output sent to browser
DEBUG - 2018-02-07 19:37:35 --> Total execution time: 0.1269
INFO - 2018-02-07 14:07:40 --> Config Class Initialized
INFO - 2018-02-07 14:07:40 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:07:40 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:07:40 --> Utf8 Class Initialized
INFO - 2018-02-07 14:07:40 --> URI Class Initialized
INFO - 2018-02-07 14:07:40 --> Router Class Initialized
INFO - 2018-02-07 14:07:40 --> Output Class Initialized
INFO - 2018-02-07 14:07:40 --> Security Class Initialized
DEBUG - 2018-02-07 14:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:07:40 --> Input Class Initialized
INFO - 2018-02-07 14:07:40 --> Language Class Initialized
INFO - 2018-02-07 14:07:40 --> Language Class Initialized
INFO - 2018-02-07 14:07:40 --> Config Class Initialized
INFO - 2018-02-07 14:07:40 --> Loader Class Initialized
INFO - 2018-02-07 19:37:40 --> Helper loaded: url_helper
INFO - 2018-02-07 19:37:40 --> Helper loaded: notification_helper
INFO - 2018-02-07 19:37:40 --> Helper loaded: settings_helper
INFO - 2018-02-07 19:37:40 --> Helper loaded: permission_helper
INFO - 2018-02-07 19:37:40 --> Helper loaded: users_helper
INFO - 2018-02-07 19:37:40 --> Database Driver Class Initialized
DEBUG - 2018-02-07 19:37:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 19:37:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 19:37:40 --> Helper loaded: form_helper
INFO - 2018-02-07 19:37:40 --> Form Validation Class Initialized
INFO - 2018-02-07 19:37:40 --> Controller Class Initialized
INFO - 2018-02-07 19:37:40 --> Model Class Initialized
INFO - 2018-02-07 19:37:40 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 19:37:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 19:37:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 19:37:40 --> Model Class Initialized
INFO - 2018-02-07 19:37:40 --> Model Class Initialized
INFO - 2018-02-07 19:37:40 --> Model Class Initialized
INFO - 2018-02-07 19:37:40 --> Model Class Initialized
INFO - 2018-02-07 19:37:40 --> Model Class Initialized
INFO - 2018-02-07 19:37:40 --> Model Class Initialized
INFO - 2018-02-07 19:37:40 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 19:37:40 --> Model Class Initialized
INFO - 2018-02-07 19:37:40 --> Final output sent to browser
DEBUG - 2018-02-07 19:37:40 --> Total execution time: 0.1149
INFO - 2018-02-07 14:07:57 --> Config Class Initialized
INFO - 2018-02-07 14:07:57 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:07:57 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:07:57 --> Utf8 Class Initialized
INFO - 2018-02-07 14:07:57 --> URI Class Initialized
INFO - 2018-02-07 14:07:57 --> Router Class Initialized
INFO - 2018-02-07 14:07:57 --> Output Class Initialized
INFO - 2018-02-07 14:07:57 --> Security Class Initialized
DEBUG - 2018-02-07 14:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:07:57 --> Input Class Initialized
INFO - 2018-02-07 14:07:57 --> Language Class Initialized
INFO - 2018-02-07 14:07:57 --> Language Class Initialized
INFO - 2018-02-07 14:07:57 --> Config Class Initialized
INFO - 2018-02-07 14:07:57 --> Loader Class Initialized
INFO - 2018-02-07 19:37:57 --> Helper loaded: url_helper
INFO - 2018-02-07 19:37:57 --> Helper loaded: notification_helper
INFO - 2018-02-07 19:37:57 --> Helper loaded: settings_helper
INFO - 2018-02-07 19:37:57 --> Helper loaded: permission_helper
INFO - 2018-02-07 19:37:57 --> Helper loaded: users_helper
INFO - 2018-02-07 19:37:57 --> Database Driver Class Initialized
DEBUG - 2018-02-07 19:37:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 19:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 19:37:57 --> Helper loaded: form_helper
INFO - 2018-02-07 19:37:57 --> Form Validation Class Initialized
INFO - 2018-02-07 19:37:57 --> Controller Class Initialized
INFO - 2018-02-07 19:37:57 --> Model Class Initialized
INFO - 2018-02-07 19:37:57 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 19:37:57 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 19:37:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 19:37:57 --> Model Class Initialized
INFO - 2018-02-07 19:37:57 --> Model Class Initialized
INFO - 2018-02-07 19:37:57 --> Model Class Initialized
INFO - 2018-02-07 19:37:57 --> Model Class Initialized
INFO - 2018-02-07 19:37:57 --> Model Class Initialized
INFO - 2018-02-07 19:37:57 --> Model Class Initialized
INFO - 2018-02-07 19:37:57 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 19:37:57 --> Model Class Initialized
INFO - 2018-02-07 19:37:57 --> Final output sent to browser
DEBUG - 2018-02-07 19:37:57 --> Total execution time: 0.1187
INFO - 2018-02-07 14:09:45 --> Config Class Initialized
INFO - 2018-02-07 14:09:45 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:09:45 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:09:45 --> Utf8 Class Initialized
INFO - 2018-02-07 14:09:45 --> URI Class Initialized
INFO - 2018-02-07 14:09:45 --> Router Class Initialized
INFO - 2018-02-07 14:09:45 --> Output Class Initialized
INFO - 2018-02-07 14:09:45 --> Security Class Initialized
DEBUG - 2018-02-07 14:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:09:45 --> Input Class Initialized
INFO - 2018-02-07 14:09:45 --> Language Class Initialized
INFO - 2018-02-07 14:09:45 --> Language Class Initialized
INFO - 2018-02-07 14:09:45 --> Config Class Initialized
INFO - 2018-02-07 14:09:45 --> Loader Class Initialized
INFO - 2018-02-07 19:39:45 --> Helper loaded: url_helper
INFO - 2018-02-07 19:39:45 --> Helper loaded: notification_helper
INFO - 2018-02-07 19:39:45 --> Helper loaded: settings_helper
INFO - 2018-02-07 19:39:45 --> Helper loaded: permission_helper
INFO - 2018-02-07 19:39:45 --> Helper loaded: users_helper
INFO - 2018-02-07 19:39:45 --> Database Driver Class Initialized
DEBUG - 2018-02-07 19:39:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 19:39:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 19:39:45 --> Helper loaded: form_helper
INFO - 2018-02-07 19:39:45 --> Form Validation Class Initialized
INFO - 2018-02-07 19:39:45 --> Controller Class Initialized
INFO - 2018-02-07 19:39:45 --> Model Class Initialized
INFO - 2018-02-07 19:39:45 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 19:39:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 19:39:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 19:39:45 --> Model Class Initialized
INFO - 2018-02-07 19:39:45 --> Model Class Initialized
INFO - 2018-02-07 19:39:45 --> Model Class Initialized
INFO - 2018-02-07 19:39:45 --> Model Class Initialized
INFO - 2018-02-07 19:39:45 --> Model Class Initialized
INFO - 2018-02-07 19:39:45 --> Model Class Initialized
INFO - 2018-02-07 19:39:45 --> Model Class Initialized
INFO - 2018-02-07 19:39:45 --> Model Class Initialized
INFO - 2018-02-07 19:39:45 --> Model Class Initialized
INFO - 2018-02-07 19:39:45 --> Model Class Initialized
INFO - 2018-02-07 19:39:45 --> Model Class Initialized
INFO - 2018-02-07 19:39:45 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 19:39:45 --> Model Class Initialized
INFO - 2018-02-07 19:39:45 --> Final output sent to browser
DEBUG - 2018-02-07 19:39:45 --> Total execution time: 0.1139
INFO - 2018-02-07 14:09:49 --> Config Class Initialized
INFO - 2018-02-07 14:09:49 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:09:49 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:09:49 --> Utf8 Class Initialized
INFO - 2018-02-07 14:09:49 --> URI Class Initialized
INFO - 2018-02-07 14:09:49 --> Router Class Initialized
INFO - 2018-02-07 14:09:49 --> Output Class Initialized
INFO - 2018-02-07 14:09:49 --> Security Class Initialized
DEBUG - 2018-02-07 14:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:09:49 --> Input Class Initialized
INFO - 2018-02-07 14:09:49 --> Language Class Initialized
INFO - 2018-02-07 14:09:49 --> Language Class Initialized
INFO - 2018-02-07 14:09:49 --> Config Class Initialized
INFO - 2018-02-07 14:09:49 --> Loader Class Initialized
INFO - 2018-02-07 19:39:49 --> Helper loaded: url_helper
INFO - 2018-02-07 19:39:49 --> Helper loaded: notification_helper
INFO - 2018-02-07 19:39:49 --> Helper loaded: settings_helper
INFO - 2018-02-07 19:39:49 --> Helper loaded: permission_helper
INFO - 2018-02-07 19:39:49 --> Helper loaded: users_helper
INFO - 2018-02-07 19:39:49 --> Database Driver Class Initialized
DEBUG - 2018-02-07 19:39:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 19:39:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 19:39:49 --> Helper loaded: form_helper
INFO - 2018-02-07 19:39:49 --> Form Validation Class Initialized
INFO - 2018-02-07 19:39:49 --> Controller Class Initialized
INFO - 2018-02-07 19:39:49 --> Model Class Initialized
INFO - 2018-02-07 19:39:49 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 19:39:49 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 19:39:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 19:39:49 --> Model Class Initialized
INFO - 2018-02-07 19:39:49 --> Model Class Initialized
INFO - 2018-02-07 19:39:49 --> Model Class Initialized
INFO - 2018-02-07 19:39:49 --> Model Class Initialized
INFO - 2018-02-07 19:39:49 --> Model Class Initialized
INFO - 2018-02-07 19:39:49 --> Model Class Initialized
INFO - 2018-02-07 19:39:49 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 19:39:49 --> Model Class Initialized
INFO - 2018-02-07 19:39:49 --> Final output sent to browser
DEBUG - 2018-02-07 19:39:49 --> Total execution time: 0.1230
INFO - 2018-02-07 14:09:49 --> Config Class Initialized
INFO - 2018-02-07 14:09:49 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:09:49 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:09:49 --> Utf8 Class Initialized
INFO - 2018-02-07 14:09:49 --> URI Class Initialized
INFO - 2018-02-07 14:09:49 --> Router Class Initialized
INFO - 2018-02-07 14:09:49 --> Output Class Initialized
INFO - 2018-02-07 14:09:49 --> Security Class Initialized
DEBUG - 2018-02-07 14:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:09:49 --> Input Class Initialized
INFO - 2018-02-07 14:09:49 --> Language Class Initialized
INFO - 2018-02-07 14:09:49 --> Language Class Initialized
INFO - 2018-02-07 14:09:49 --> Config Class Initialized
INFO - 2018-02-07 14:09:49 --> Loader Class Initialized
INFO - 2018-02-07 19:39:49 --> Helper loaded: url_helper
INFO - 2018-02-07 19:39:49 --> Helper loaded: notification_helper
INFO - 2018-02-07 19:39:49 --> Helper loaded: settings_helper
INFO - 2018-02-07 19:39:49 --> Helper loaded: permission_helper
INFO - 2018-02-07 19:39:49 --> Helper loaded: users_helper
INFO - 2018-02-07 19:39:50 --> Database Driver Class Initialized
DEBUG - 2018-02-07 19:39:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 19:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 19:39:50 --> Helper loaded: form_helper
INFO - 2018-02-07 19:39:50 --> Form Validation Class Initialized
INFO - 2018-02-07 19:39:50 --> Controller Class Initialized
INFO - 2018-02-07 19:39:50 --> Model Class Initialized
INFO - 2018-02-07 19:39:50 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 19:39:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 19:39:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 19:39:50 --> Model Class Initialized
INFO - 2018-02-07 19:39:50 --> Model Class Initialized
INFO - 2018-02-07 19:39:50 --> Model Class Initialized
INFO - 2018-02-07 19:39:50 --> Model Class Initialized
INFO - 2018-02-07 19:39:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 19:39:50 --> Final output sent to browser
DEBUG - 2018-02-07 19:39:50 --> Total execution time: 0.1057
INFO - 2018-02-07 14:09:50 --> Config Class Initialized
INFO - 2018-02-07 14:09:50 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:09:50 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:09:50 --> Utf8 Class Initialized
INFO - 2018-02-07 14:09:50 --> URI Class Initialized
INFO - 2018-02-07 14:09:50 --> Router Class Initialized
INFO - 2018-02-07 14:09:50 --> Output Class Initialized
INFO - 2018-02-07 14:09:50 --> Security Class Initialized
DEBUG - 2018-02-07 14:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:09:50 --> Input Class Initialized
INFO - 2018-02-07 14:09:50 --> Language Class Initialized
INFO - 2018-02-07 14:09:50 --> Language Class Initialized
INFO - 2018-02-07 14:09:50 --> Config Class Initialized
INFO - 2018-02-07 14:09:50 --> Loader Class Initialized
INFO - 2018-02-07 19:39:50 --> Helper loaded: url_helper
INFO - 2018-02-07 19:39:50 --> Helper loaded: notification_helper
INFO - 2018-02-07 19:39:50 --> Helper loaded: settings_helper
INFO - 2018-02-07 19:39:50 --> Helper loaded: permission_helper
INFO - 2018-02-07 19:39:50 --> Helper loaded: users_helper
INFO - 2018-02-07 19:39:50 --> Database Driver Class Initialized
DEBUG - 2018-02-07 19:39:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 19:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 19:39:50 --> Helper loaded: form_helper
INFO - 2018-02-07 19:39:50 --> Form Validation Class Initialized
INFO - 2018-02-07 19:39:50 --> Controller Class Initialized
INFO - 2018-02-07 19:39:50 --> Model Class Initialized
INFO - 2018-02-07 19:39:50 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 19:39:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 19:39:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 19:39:50 --> Model Class Initialized
INFO - 2018-02-07 19:39:50 --> Model Class Initialized
INFO - 2018-02-07 19:39:50 --> Model Class Initialized
INFO - 2018-02-07 19:39:50 --> Model Class Initialized
INFO - 2018-02-07 19:39:50 --> Model Class Initialized
INFO - 2018-02-07 19:39:50 --> Model Class Initialized
INFO - 2018-02-07 19:39:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 19:39:50 --> Final output sent to browser
DEBUG - 2018-02-07 19:39:50 --> Total execution time: 0.1119
INFO - 2018-02-07 14:09:56 --> Config Class Initialized
INFO - 2018-02-07 14:09:56 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:09:56 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:09:56 --> Utf8 Class Initialized
INFO - 2018-02-07 14:09:56 --> URI Class Initialized
INFO - 2018-02-07 14:09:56 --> Router Class Initialized
INFO - 2018-02-07 14:09:56 --> Output Class Initialized
INFO - 2018-02-07 14:09:56 --> Security Class Initialized
DEBUG - 2018-02-07 14:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:09:56 --> Input Class Initialized
INFO - 2018-02-07 14:09:56 --> Language Class Initialized
INFO - 2018-02-07 14:09:56 --> Language Class Initialized
INFO - 2018-02-07 14:09:56 --> Config Class Initialized
INFO - 2018-02-07 14:09:56 --> Loader Class Initialized
INFO - 2018-02-07 19:39:56 --> Helper loaded: url_helper
INFO - 2018-02-07 19:39:56 --> Helper loaded: notification_helper
INFO - 2018-02-07 19:39:56 --> Helper loaded: settings_helper
INFO - 2018-02-07 19:39:56 --> Helper loaded: permission_helper
INFO - 2018-02-07 19:39:56 --> Helper loaded: users_helper
INFO - 2018-02-07 19:39:56 --> Database Driver Class Initialized
DEBUG - 2018-02-07 19:39:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 19:39:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 19:39:56 --> Helper loaded: form_helper
INFO - 2018-02-07 19:39:56 --> Form Validation Class Initialized
INFO - 2018-02-07 19:39:56 --> Controller Class Initialized
INFO - 2018-02-07 19:39:56 --> Model Class Initialized
INFO - 2018-02-07 19:39:56 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 19:39:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 19:39:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 19:39:56 --> Model Class Initialized
INFO - 2018-02-07 19:39:56 --> Model Class Initialized
INFO - 2018-02-07 19:39:56 --> Model Class Initialized
INFO - 2018-02-07 19:39:56 --> Model Class Initialized
INFO - 2018-02-07 19:39:56 --> Model Class Initialized
INFO - 2018-02-07 19:39:56 --> Model Class Initialized
INFO - 2018-02-07 19:39:56 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 19:39:56 --> Model Class Initialized
INFO - 2018-02-07 19:39:56 --> Final output sent to browser
DEBUG - 2018-02-07 19:39:56 --> Total execution time: 0.1187
INFO - 2018-02-07 14:09:59 --> Config Class Initialized
INFO - 2018-02-07 14:09:59 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:09:59 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:09:59 --> Utf8 Class Initialized
INFO - 2018-02-07 14:09:59 --> URI Class Initialized
INFO - 2018-02-07 14:09:59 --> Router Class Initialized
INFO - 2018-02-07 14:09:59 --> Output Class Initialized
INFO - 2018-02-07 14:09:59 --> Security Class Initialized
DEBUG - 2018-02-07 14:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:09:59 --> Input Class Initialized
INFO - 2018-02-07 14:09:59 --> Language Class Initialized
INFO - 2018-02-07 14:09:59 --> Language Class Initialized
INFO - 2018-02-07 14:09:59 --> Config Class Initialized
INFO - 2018-02-07 14:09:59 --> Loader Class Initialized
INFO - 2018-02-07 19:39:59 --> Helper loaded: url_helper
INFO - 2018-02-07 19:39:59 --> Helper loaded: notification_helper
INFO - 2018-02-07 19:39:59 --> Helper loaded: settings_helper
INFO - 2018-02-07 19:39:59 --> Helper loaded: permission_helper
INFO - 2018-02-07 19:39:59 --> Helper loaded: users_helper
INFO - 2018-02-07 19:39:59 --> Database Driver Class Initialized
DEBUG - 2018-02-07 19:39:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 19:39:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 19:39:59 --> Helper loaded: form_helper
INFO - 2018-02-07 19:39:59 --> Form Validation Class Initialized
INFO - 2018-02-07 19:39:59 --> Controller Class Initialized
INFO - 2018-02-07 19:39:59 --> Model Class Initialized
INFO - 2018-02-07 19:39:59 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 19:39:59 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 19:39:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 19:39:59 --> Model Class Initialized
INFO - 2018-02-07 19:39:59 --> Model Class Initialized
INFO - 2018-02-07 19:39:59 --> Model Class Initialized
INFO - 2018-02-07 19:39:59 --> Model Class Initialized
INFO - 2018-02-07 19:39:59 --> Model Class Initialized
INFO - 2018-02-07 19:39:59 --> Model Class Initialized
INFO - 2018-02-07 19:39:59 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 19:39:59 --> Model Class Initialized
INFO - 2018-02-07 19:39:59 --> Final output sent to browser
DEBUG - 2018-02-07 19:39:59 --> Total execution time: 0.1224
INFO - 2018-02-07 14:15:19 --> Config Class Initialized
INFO - 2018-02-07 14:15:19 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:15:19 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:15:19 --> Utf8 Class Initialized
INFO - 2018-02-07 14:15:19 --> URI Class Initialized
INFO - 2018-02-07 14:15:19 --> Router Class Initialized
INFO - 2018-02-07 14:15:19 --> Output Class Initialized
INFO - 2018-02-07 14:15:19 --> Security Class Initialized
DEBUG - 2018-02-07 14:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:15:19 --> Input Class Initialized
INFO - 2018-02-07 14:15:19 --> Language Class Initialized
INFO - 2018-02-07 14:15:19 --> Language Class Initialized
INFO - 2018-02-07 14:15:19 --> Config Class Initialized
INFO - 2018-02-07 14:15:19 --> Loader Class Initialized
INFO - 2018-02-07 19:45:19 --> Helper loaded: url_helper
INFO - 2018-02-07 19:45:19 --> Helper loaded: notification_helper
INFO - 2018-02-07 19:45:19 --> Helper loaded: settings_helper
INFO - 2018-02-07 19:45:19 --> Helper loaded: permission_helper
INFO - 2018-02-07 19:45:19 --> Helper loaded: users_helper
INFO - 2018-02-07 19:45:19 --> Database Driver Class Initialized
DEBUG - 2018-02-07 19:45:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 19:45:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 19:45:19 --> Helper loaded: form_helper
INFO - 2018-02-07 19:45:19 --> Form Validation Class Initialized
INFO - 2018-02-07 19:45:19 --> Controller Class Initialized
INFO - 2018-02-07 19:45:19 --> Model Class Initialized
INFO - 2018-02-07 19:45:19 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 19:45:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 19:45:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 19:45:19 --> Model Class Initialized
INFO - 2018-02-07 19:45:19 --> Model Class Initialized
INFO - 2018-02-07 19:45:19 --> Model Class Initialized
INFO - 2018-02-07 19:45:19 --> Model Class Initialized
INFO - 2018-02-07 19:45:19 --> Model Class Initialized
INFO - 2018-02-07 19:45:19 --> Model Class Initialized
INFO - 2018-02-07 19:45:19 --> Model Class Initialized
INFO - 2018-02-07 19:45:19 --> Model Class Initialized
INFO - 2018-02-07 19:45:19 --> Model Class Initialized
INFO - 2018-02-07 19:45:19 --> Model Class Initialized
INFO - 2018-02-07 19:45:19 --> Model Class Initialized
INFO - 2018-02-07 19:45:19 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 19:45:19 --> Model Class Initialized
INFO - 2018-02-07 19:45:19 --> Final output sent to browser
DEBUG - 2018-02-07 19:45:19 --> Total execution time: 0.1202
INFO - 2018-02-07 14:15:19 --> Config Class Initialized
INFO - 2018-02-07 14:15:19 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:15:19 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:15:19 --> Utf8 Class Initialized
INFO - 2018-02-07 14:15:19 --> URI Class Initialized
INFO - 2018-02-07 14:15:19 --> Router Class Initialized
INFO - 2018-02-07 14:15:19 --> Output Class Initialized
INFO - 2018-02-07 14:15:19 --> Security Class Initialized
DEBUG - 2018-02-07 14:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:15:19 --> Input Class Initialized
INFO - 2018-02-07 14:15:19 --> Language Class Initialized
INFO - 2018-02-07 14:15:20 --> Language Class Initialized
INFO - 2018-02-07 14:15:20 --> Config Class Initialized
INFO - 2018-02-07 14:15:20 --> Loader Class Initialized
INFO - 2018-02-07 19:45:20 --> Helper loaded: url_helper
INFO - 2018-02-07 19:45:20 --> Helper loaded: notification_helper
INFO - 2018-02-07 19:45:20 --> Helper loaded: settings_helper
INFO - 2018-02-07 19:45:20 --> Helper loaded: permission_helper
INFO - 2018-02-07 19:45:20 --> Helper loaded: users_helper
INFO - 2018-02-07 19:45:20 --> Database Driver Class Initialized
DEBUG - 2018-02-07 19:45:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 19:45:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 19:45:20 --> Helper loaded: form_helper
INFO - 2018-02-07 19:45:20 --> Form Validation Class Initialized
INFO - 2018-02-07 19:45:20 --> Controller Class Initialized
INFO - 2018-02-07 19:45:20 --> Model Class Initialized
INFO - 2018-02-07 19:45:20 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 19:45:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 19:45:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 19:45:20 --> Model Class Initialized
INFO - 2018-02-07 19:45:20 --> Model Class Initialized
INFO - 2018-02-07 19:45:20 --> Model Class Initialized
INFO - 2018-02-07 19:45:20 --> Model Class Initialized
INFO - 2018-02-07 19:45:20 --> Model Class Initialized
INFO - 2018-02-07 19:45:20 --> Model Class Initialized
INFO - 2018-02-07 19:45:20 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 19:45:20 --> Model Class Initialized
INFO - 2018-02-07 19:45:20 --> Final output sent to browser
DEBUG - 2018-02-07 19:45:20 --> Total execution time: 0.1096
INFO - 2018-02-07 14:15:25 --> Config Class Initialized
INFO - 2018-02-07 14:15:25 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:15:25 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:15:25 --> Utf8 Class Initialized
INFO - 2018-02-07 14:15:25 --> URI Class Initialized
INFO - 2018-02-07 14:15:25 --> Router Class Initialized
INFO - 2018-02-07 14:15:25 --> Output Class Initialized
INFO - 2018-02-07 14:15:25 --> Security Class Initialized
DEBUG - 2018-02-07 14:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:15:25 --> Input Class Initialized
INFO - 2018-02-07 14:15:25 --> Language Class Initialized
INFO - 2018-02-07 14:15:25 --> Language Class Initialized
INFO - 2018-02-07 14:15:25 --> Config Class Initialized
INFO - 2018-02-07 14:15:25 --> Loader Class Initialized
INFO - 2018-02-07 19:45:25 --> Helper loaded: url_helper
INFO - 2018-02-07 19:45:25 --> Helper loaded: notification_helper
INFO - 2018-02-07 19:45:25 --> Helper loaded: settings_helper
INFO - 2018-02-07 19:45:25 --> Helper loaded: permission_helper
INFO - 2018-02-07 19:45:25 --> Helper loaded: users_helper
INFO - 2018-02-07 14:15:25 --> Config Class Initialized
INFO - 2018-02-07 14:15:25 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:15:25 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:15:25 --> Utf8 Class Initialized
INFO - 2018-02-07 14:15:25 --> URI Class Initialized
INFO - 2018-02-07 14:15:25 --> Router Class Initialized
INFO - 2018-02-07 19:45:25 --> Database Driver Class Initialized
INFO - 2018-02-07 14:15:25 --> Output Class Initialized
INFO - 2018-02-07 14:15:25 --> Security Class Initialized
DEBUG - 2018-02-07 19:45:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 19:45:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-07 14:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:15:25 --> Input Class Initialized
INFO - 2018-02-07 14:15:25 --> Language Class Initialized
INFO - 2018-02-07 19:45:25 --> Helper loaded: form_helper
INFO - 2018-02-07 19:45:25 --> Form Validation Class Initialized
INFO - 2018-02-07 19:45:25 --> Controller Class Initialized
INFO - 2018-02-07 19:45:26 --> Model Class Initialized
INFO - 2018-02-07 19:45:26 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 19:45:26 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 14:15:26 --> Language Class Initialized
INFO - 2018-02-07 14:15:26 --> Config Class Initialized
INFO - 2018-02-07 14:15:26 --> Loader Class Initialized
INFO - 2018-02-07 19:45:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 19:45:26 --> Helper loaded: url_helper
INFO - 2018-02-07 19:45:26 --> Model Class Initialized
INFO - 2018-02-07 19:45:26 --> Model Class Initialized
INFO - 2018-02-07 19:45:26 --> Helper loaded: notification_helper
INFO - 2018-02-07 19:45:26 --> Model Class Initialized
INFO - 2018-02-07 19:45:26 --> Helper loaded: settings_helper
INFO - 2018-02-07 19:45:26 --> Model Class Initialized
INFO - 2018-02-07 19:45:26 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 19:45:26 --> Helper loaded: permission_helper
INFO - 2018-02-07 19:45:26 --> Helper loaded: users_helper
INFO - 2018-02-07 19:45:26 --> Final output sent to browser
DEBUG - 2018-02-07 19:45:26 --> Total execution time: 0.1096
INFO - 2018-02-07 19:45:26 --> Database Driver Class Initialized
DEBUG - 2018-02-07 19:45:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 19:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 19:45:26 --> Helper loaded: form_helper
INFO - 2018-02-07 19:45:26 --> Form Validation Class Initialized
INFO - 2018-02-07 19:45:26 --> Controller Class Initialized
INFO - 2018-02-07 19:45:26 --> Model Class Initialized
INFO - 2018-02-07 19:45:26 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 19:45:26 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 19:45:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 19:45:26 --> Model Class Initialized
INFO - 2018-02-07 19:45:26 --> Model Class Initialized
INFO - 2018-02-07 19:45:26 --> Model Class Initialized
INFO - 2018-02-07 19:45:26 --> Model Class Initialized
INFO - 2018-02-07 19:45:26 --> Model Class Initialized
INFO - 2018-02-07 19:45:26 --> Model Class Initialized
INFO - 2018-02-07 19:45:26 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 19:45:26 --> Final output sent to browser
DEBUG - 2018-02-07 19:45:26 --> Total execution time: 0.1111
INFO - 2018-02-07 14:15:29 --> Config Class Initialized
INFO - 2018-02-07 14:15:29 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:15:29 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:15:29 --> Utf8 Class Initialized
INFO - 2018-02-07 14:15:29 --> URI Class Initialized
INFO - 2018-02-07 14:15:29 --> Router Class Initialized
INFO - 2018-02-07 14:15:29 --> Output Class Initialized
INFO - 2018-02-07 14:15:29 --> Security Class Initialized
DEBUG - 2018-02-07 14:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:15:29 --> Input Class Initialized
INFO - 2018-02-07 14:15:29 --> Language Class Initialized
INFO - 2018-02-07 14:15:29 --> Language Class Initialized
INFO - 2018-02-07 14:15:29 --> Config Class Initialized
INFO - 2018-02-07 14:15:29 --> Loader Class Initialized
INFO - 2018-02-07 19:45:29 --> Helper loaded: url_helper
INFO - 2018-02-07 19:45:29 --> Helper loaded: notification_helper
INFO - 2018-02-07 19:45:29 --> Helper loaded: settings_helper
INFO - 2018-02-07 19:45:29 --> Helper loaded: permission_helper
INFO - 2018-02-07 19:45:29 --> Helper loaded: users_helper
INFO - 2018-02-07 19:45:29 --> Database Driver Class Initialized
DEBUG - 2018-02-07 19:45:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 19:45:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 19:45:29 --> Helper loaded: form_helper
INFO - 2018-02-07 19:45:29 --> Form Validation Class Initialized
INFO - 2018-02-07 19:45:29 --> Controller Class Initialized
INFO - 2018-02-07 19:45:29 --> Model Class Initialized
INFO - 2018-02-07 19:45:29 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 19:45:29 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 19:45:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 19:45:29 --> Model Class Initialized
INFO - 2018-02-07 19:45:29 --> Model Class Initialized
INFO - 2018-02-07 19:45:29 --> Model Class Initialized
INFO - 2018-02-07 19:45:29 --> Model Class Initialized
INFO - 2018-02-07 19:45:29 --> Model Class Initialized
INFO - 2018-02-07 19:45:29 --> Model Class Initialized
INFO - 2018-02-07 19:45:29 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 19:45:29 --> Model Class Initialized
INFO - 2018-02-07 19:45:29 --> Final output sent to browser
DEBUG - 2018-02-07 19:45:29 --> Total execution time: 0.1085
INFO - 2018-02-07 14:15:31 --> Config Class Initialized
INFO - 2018-02-07 14:15:31 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:15:31 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:15:31 --> Utf8 Class Initialized
INFO - 2018-02-07 14:15:31 --> URI Class Initialized
INFO - 2018-02-07 14:15:31 --> Router Class Initialized
INFO - 2018-02-07 14:15:31 --> Output Class Initialized
INFO - 2018-02-07 14:15:31 --> Security Class Initialized
DEBUG - 2018-02-07 14:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:15:31 --> Input Class Initialized
INFO - 2018-02-07 14:15:31 --> Language Class Initialized
INFO - 2018-02-07 14:15:31 --> Language Class Initialized
INFO - 2018-02-07 14:15:31 --> Config Class Initialized
INFO - 2018-02-07 14:15:31 --> Loader Class Initialized
INFO - 2018-02-07 19:45:31 --> Helper loaded: url_helper
INFO - 2018-02-07 19:45:31 --> Helper loaded: notification_helper
INFO - 2018-02-07 19:45:31 --> Helper loaded: settings_helper
INFO - 2018-02-07 19:45:31 --> Helper loaded: permission_helper
INFO - 2018-02-07 19:45:31 --> Helper loaded: users_helper
INFO - 2018-02-07 19:45:31 --> Database Driver Class Initialized
DEBUG - 2018-02-07 19:45:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 19:45:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 19:45:31 --> Helper loaded: form_helper
INFO - 2018-02-07 19:45:31 --> Form Validation Class Initialized
INFO - 2018-02-07 19:45:31 --> Controller Class Initialized
INFO - 2018-02-07 19:45:31 --> Model Class Initialized
INFO - 2018-02-07 19:45:31 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 19:45:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 19:45:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 19:45:31 --> Model Class Initialized
INFO - 2018-02-07 19:45:31 --> Model Class Initialized
INFO - 2018-02-07 19:45:31 --> Model Class Initialized
INFO - 2018-02-07 19:45:31 --> Model Class Initialized
INFO - 2018-02-07 19:45:31 --> Model Class Initialized
INFO - 2018-02-07 19:45:31 --> Model Class Initialized
INFO - 2018-02-07 19:45:31 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 19:45:31 --> Model Class Initialized
INFO - 2018-02-07 19:45:31 --> Final output sent to browser
DEBUG - 2018-02-07 19:45:31 --> Total execution time: 0.1122
INFO - 2018-02-07 14:15:39 --> Config Class Initialized
INFO - 2018-02-07 14:15:39 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:15:39 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:15:39 --> Utf8 Class Initialized
INFO - 2018-02-07 14:15:39 --> URI Class Initialized
INFO - 2018-02-07 14:15:39 --> Router Class Initialized
INFO - 2018-02-07 14:15:39 --> Output Class Initialized
INFO - 2018-02-07 14:15:39 --> Security Class Initialized
DEBUG - 2018-02-07 14:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:15:39 --> Input Class Initialized
INFO - 2018-02-07 14:15:39 --> Language Class Initialized
INFO - 2018-02-07 14:15:39 --> Language Class Initialized
INFO - 2018-02-07 14:15:39 --> Config Class Initialized
INFO - 2018-02-07 14:15:39 --> Loader Class Initialized
INFO - 2018-02-07 19:45:39 --> Helper loaded: url_helper
INFO - 2018-02-07 19:45:39 --> Helper loaded: notification_helper
INFO - 2018-02-07 19:45:39 --> Helper loaded: settings_helper
INFO - 2018-02-07 19:45:39 --> Helper loaded: permission_helper
INFO - 2018-02-07 19:45:39 --> Helper loaded: users_helper
INFO - 2018-02-07 19:45:39 --> Database Driver Class Initialized
DEBUG - 2018-02-07 19:45:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 19:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 19:45:39 --> Helper loaded: form_helper
INFO - 2018-02-07 19:45:39 --> Form Validation Class Initialized
INFO - 2018-02-07 19:45:39 --> Controller Class Initialized
INFO - 2018-02-07 19:45:39 --> Model Class Initialized
INFO - 2018-02-07 19:45:39 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 19:45:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 19:45:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 19:45:39 --> Model Class Initialized
INFO - 2018-02-07 19:45:39 --> Model Class Initialized
INFO - 2018-02-07 19:45:39 --> Model Class Initialized
INFO - 2018-02-07 19:45:39 --> Model Class Initialized
INFO - 2018-02-07 19:45:39 --> Model Class Initialized
INFO - 2018-02-07 19:45:39 --> Model Class Initialized
INFO - 2018-02-07 19:45:39 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 19:45:39 --> Model Class Initialized
INFO - 2018-02-07 19:45:39 --> Final output sent to browser
DEBUG - 2018-02-07 19:45:39 --> Total execution time: 0.1107
INFO - 2018-02-07 14:15:45 --> Config Class Initialized
INFO - 2018-02-07 14:15:45 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:15:45 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:15:45 --> Utf8 Class Initialized
INFO - 2018-02-07 14:15:45 --> URI Class Initialized
INFO - 2018-02-07 14:15:45 --> Router Class Initialized
INFO - 2018-02-07 14:15:45 --> Output Class Initialized
INFO - 2018-02-07 14:15:45 --> Security Class Initialized
DEBUG - 2018-02-07 14:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:15:45 --> Input Class Initialized
INFO - 2018-02-07 14:15:45 --> Language Class Initialized
INFO - 2018-02-07 14:15:45 --> Language Class Initialized
INFO - 2018-02-07 14:15:45 --> Config Class Initialized
INFO - 2018-02-07 14:15:45 --> Loader Class Initialized
INFO - 2018-02-07 19:45:45 --> Helper loaded: url_helper
INFO - 2018-02-07 19:45:45 --> Helper loaded: notification_helper
INFO - 2018-02-07 19:45:45 --> Helper loaded: settings_helper
INFO - 2018-02-07 19:45:45 --> Helper loaded: permission_helper
INFO - 2018-02-07 19:45:45 --> Helper loaded: users_helper
INFO - 2018-02-07 19:45:45 --> Database Driver Class Initialized
DEBUG - 2018-02-07 19:45:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 19:45:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 19:45:45 --> Helper loaded: form_helper
INFO - 2018-02-07 19:45:45 --> Form Validation Class Initialized
INFO - 2018-02-07 19:45:45 --> Controller Class Initialized
INFO - 2018-02-07 19:45:45 --> Model Class Initialized
INFO - 2018-02-07 19:45:45 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 19:45:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 19:45:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 19:45:45 --> Model Class Initialized
INFO - 2018-02-07 19:45:45 --> Model Class Initialized
INFO - 2018-02-07 19:45:45 --> Model Class Initialized
INFO - 2018-02-07 19:45:45 --> Model Class Initialized
INFO - 2018-02-07 19:45:45 --> Model Class Initialized
INFO - 2018-02-07 19:45:45 --> Model Class Initialized
INFO - 2018-02-07 19:45:45 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 19:45:45 --> Model Class Initialized
INFO - 2018-02-07 19:45:45 --> Final output sent to browser
DEBUG - 2018-02-07 19:45:45 --> Total execution time: 0.1064
INFO - 2018-02-07 14:29:13 --> Config Class Initialized
INFO - 2018-02-07 14:29:13 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:29:13 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:29:13 --> Utf8 Class Initialized
INFO - 2018-02-07 14:29:13 --> URI Class Initialized
INFO - 2018-02-07 14:29:13 --> Router Class Initialized
INFO - 2018-02-07 14:29:13 --> Output Class Initialized
INFO - 2018-02-07 14:29:13 --> Security Class Initialized
DEBUG - 2018-02-07 14:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:29:13 --> Input Class Initialized
INFO - 2018-02-07 14:29:13 --> Language Class Initialized
INFO - 2018-02-07 14:29:13 --> Language Class Initialized
INFO - 2018-02-07 14:29:13 --> Config Class Initialized
INFO - 2018-02-07 14:29:13 --> Loader Class Initialized
INFO - 2018-02-07 19:59:13 --> Helper loaded: url_helper
INFO - 2018-02-07 19:59:13 --> Helper loaded: notification_helper
INFO - 2018-02-07 19:59:13 --> Helper loaded: settings_helper
INFO - 2018-02-07 19:59:13 --> Helper loaded: permission_helper
INFO - 2018-02-07 19:59:13 --> Helper loaded: users_helper
INFO - 2018-02-07 19:59:13 --> Database Driver Class Initialized
DEBUG - 2018-02-07 19:59:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 19:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 19:59:13 --> Helper loaded: form_helper
INFO - 2018-02-07 19:59:13 --> Form Validation Class Initialized
INFO - 2018-02-07 19:59:13 --> Controller Class Initialized
INFO - 2018-02-07 19:59:13 --> Model Class Initialized
INFO - 2018-02-07 19:59:13 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 19:59:13 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 19:59:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 19:59:13 --> Model Class Initialized
INFO - 2018-02-07 19:59:13 --> Model Class Initialized
INFO - 2018-02-07 19:59:13 --> Model Class Initialized
INFO - 2018-02-07 19:59:13 --> Model Class Initialized
INFO - 2018-02-07 19:59:13 --> Model Class Initialized
INFO - 2018-02-07 19:59:13 --> Model Class Initialized
INFO - 2018-02-07 19:59:13 --> Model Class Initialized
INFO - 2018-02-07 19:59:13 --> Model Class Initialized
INFO - 2018-02-07 19:59:13 --> Model Class Initialized
INFO - 2018-02-07 19:59:13 --> Model Class Initialized
INFO - 2018-02-07 19:59:13 --> Model Class Initialized
INFO - 2018-02-07 19:59:13 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 19:59:13 --> Model Class Initialized
INFO - 2018-02-07 19:59:13 --> Final output sent to browser
DEBUG - 2018-02-07 19:59:13 --> Total execution time: 0.1243
INFO - 2018-02-07 14:29:13 --> Config Class Initialized
INFO - 2018-02-07 14:29:13 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:29:13 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:29:13 --> Utf8 Class Initialized
INFO - 2018-02-07 14:29:13 --> URI Class Initialized
INFO - 2018-02-07 14:29:13 --> Router Class Initialized
INFO - 2018-02-07 14:29:13 --> Output Class Initialized
INFO - 2018-02-07 14:29:13 --> Security Class Initialized
DEBUG - 2018-02-07 14:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:29:13 --> Input Class Initialized
INFO - 2018-02-07 14:29:13 --> Language Class Initialized
INFO - 2018-02-07 14:29:13 --> Language Class Initialized
INFO - 2018-02-07 14:29:13 --> Config Class Initialized
INFO - 2018-02-07 14:29:13 --> Loader Class Initialized
INFO - 2018-02-07 19:59:13 --> Helper loaded: url_helper
INFO - 2018-02-07 19:59:13 --> Helper loaded: notification_helper
INFO - 2018-02-07 19:59:13 --> Helper loaded: settings_helper
INFO - 2018-02-07 19:59:13 --> Helper loaded: permission_helper
INFO - 2018-02-07 19:59:13 --> Helper loaded: users_helper
INFO - 2018-02-07 19:59:13 --> Database Driver Class Initialized
DEBUG - 2018-02-07 19:59:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 19:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 19:59:13 --> Helper loaded: form_helper
INFO - 2018-02-07 19:59:13 --> Form Validation Class Initialized
INFO - 2018-02-07 19:59:13 --> Controller Class Initialized
INFO - 2018-02-07 19:59:13 --> Model Class Initialized
INFO - 2018-02-07 19:59:13 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 19:59:13 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 19:59:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 19:59:13 --> Model Class Initialized
INFO - 2018-02-07 19:59:13 --> Model Class Initialized
INFO - 2018-02-07 19:59:13 --> Model Class Initialized
INFO - 2018-02-07 19:59:13 --> Model Class Initialized
INFO - 2018-02-07 19:59:13 --> Model Class Initialized
INFO - 2018-02-07 19:59:13 --> Model Class Initialized
INFO - 2018-02-07 19:59:13 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 19:59:13 --> Model Class Initialized
INFO - 2018-02-07 19:59:13 --> Final output sent to browser
DEBUG - 2018-02-07 19:59:13 --> Total execution time: 0.1062
INFO - 2018-02-07 14:29:16 --> Config Class Initialized
INFO - 2018-02-07 14:29:16 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:29:16 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:29:16 --> Utf8 Class Initialized
INFO - 2018-02-07 14:29:16 --> URI Class Initialized
INFO - 2018-02-07 14:29:16 --> Router Class Initialized
INFO - 2018-02-07 14:29:16 --> Output Class Initialized
INFO - 2018-02-07 14:29:16 --> Security Class Initialized
DEBUG - 2018-02-07 14:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:29:16 --> Input Class Initialized
INFO - 2018-02-07 14:29:16 --> Language Class Initialized
INFO - 2018-02-07 14:29:16 --> Config Class Initialized
INFO - 2018-02-07 14:29:16 --> Hooks Class Initialized
INFO - 2018-02-07 14:29:16 --> Language Class Initialized
INFO - 2018-02-07 14:29:16 --> Config Class Initialized
INFO - 2018-02-07 14:29:16 --> Loader Class Initialized
INFO - 2018-02-07 19:59:16 --> Helper loaded: url_helper
DEBUG - 2018-02-07 14:29:16 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:29:16 --> Utf8 Class Initialized
INFO - 2018-02-07 19:59:16 --> Helper loaded: notification_helper
INFO - 2018-02-07 19:59:16 --> Helper loaded: settings_helper
INFO - 2018-02-07 19:59:16 --> Helper loaded: permission_helper
INFO - 2018-02-07 14:29:16 --> URI Class Initialized
INFO - 2018-02-07 19:59:16 --> Helper loaded: users_helper
INFO - 2018-02-07 14:29:16 --> Router Class Initialized
INFO - 2018-02-07 14:29:16 --> Output Class Initialized
INFO - 2018-02-07 14:29:16 --> Security Class Initialized
INFO - 2018-02-07 19:59:16 --> Database Driver Class Initialized
DEBUG - 2018-02-07 14:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:29:16 --> Input Class Initialized
INFO - 2018-02-07 14:29:16 --> Language Class Initialized
DEBUG - 2018-02-07 19:59:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 19:59:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 19:59:16 --> Helper loaded: form_helper
INFO - 2018-02-07 19:59:16 --> Form Validation Class Initialized
INFO - 2018-02-07 19:59:16 --> Controller Class Initialized
INFO - 2018-02-07 19:59:16 --> Model Class Initialized
INFO - 2018-02-07 19:59:16 --> Helper loaded: inflector_helper
INFO - 2018-02-07 14:29:16 --> Language Class Initialized
INFO - 2018-02-07 14:29:16 --> Config Class Initialized
INFO - 2018-02-07 14:29:16 --> Loader Class Initialized
DEBUG - 2018-02-07 19:59:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 19:59:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 19:59:16 --> Helper loaded: url_helper
INFO - 2018-02-07 19:59:16 --> Model Class Initialized
INFO - 2018-02-07 19:59:16 --> Model Class Initialized
INFO - 2018-02-07 19:59:16 --> Helper loaded: notification_helper
INFO - 2018-02-07 19:59:16 --> Model Class Initialized
INFO - 2018-02-07 19:59:16 --> Model Class Initialized
INFO - 2018-02-07 19:59:16 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 19:59:16 --> Helper loaded: settings_helper
INFO - 2018-02-07 19:59:16 --> Helper loaded: permission_helper
INFO - 2018-02-07 19:59:16 --> Helper loaded: users_helper
INFO - 2018-02-07 19:59:16 --> Final output sent to browser
DEBUG - 2018-02-07 19:59:16 --> Total execution time: 0.0957
INFO - 2018-02-07 19:59:16 --> Database Driver Class Initialized
DEBUG - 2018-02-07 19:59:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 19:59:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 19:59:16 --> Helper loaded: form_helper
INFO - 2018-02-07 19:59:16 --> Form Validation Class Initialized
INFO - 2018-02-07 19:59:16 --> Controller Class Initialized
INFO - 2018-02-07 19:59:16 --> Model Class Initialized
INFO - 2018-02-07 19:59:16 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 19:59:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 19:59:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 19:59:16 --> Model Class Initialized
INFO - 2018-02-07 19:59:16 --> Model Class Initialized
INFO - 2018-02-07 19:59:16 --> Model Class Initialized
INFO - 2018-02-07 19:59:16 --> Model Class Initialized
INFO - 2018-02-07 19:59:16 --> Model Class Initialized
INFO - 2018-02-07 19:59:16 --> Model Class Initialized
INFO - 2018-02-07 19:59:16 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 19:59:16 --> Final output sent to browser
DEBUG - 2018-02-07 19:59:16 --> Total execution time: 0.1164
INFO - 2018-02-07 14:29:19 --> Config Class Initialized
INFO - 2018-02-07 14:29:19 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:29:19 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:29:19 --> Utf8 Class Initialized
INFO - 2018-02-07 14:29:19 --> URI Class Initialized
INFO - 2018-02-07 14:29:19 --> Router Class Initialized
INFO - 2018-02-07 14:29:19 --> Output Class Initialized
INFO - 2018-02-07 14:29:19 --> Security Class Initialized
DEBUG - 2018-02-07 14:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:29:19 --> Input Class Initialized
INFO - 2018-02-07 14:29:19 --> Language Class Initialized
INFO - 2018-02-07 14:29:19 --> Language Class Initialized
INFO - 2018-02-07 14:29:19 --> Config Class Initialized
INFO - 2018-02-07 14:29:19 --> Loader Class Initialized
INFO - 2018-02-07 19:59:19 --> Helper loaded: url_helper
INFO - 2018-02-07 19:59:19 --> Helper loaded: notification_helper
INFO - 2018-02-07 19:59:19 --> Helper loaded: settings_helper
INFO - 2018-02-07 19:59:19 --> Helper loaded: permission_helper
INFO - 2018-02-07 19:59:19 --> Helper loaded: users_helper
INFO - 2018-02-07 19:59:19 --> Database Driver Class Initialized
DEBUG - 2018-02-07 19:59:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 19:59:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 19:59:19 --> Helper loaded: form_helper
INFO - 2018-02-07 19:59:19 --> Form Validation Class Initialized
INFO - 2018-02-07 19:59:19 --> Controller Class Initialized
INFO - 2018-02-07 19:59:19 --> Model Class Initialized
INFO - 2018-02-07 19:59:19 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 19:59:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 19:59:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 19:59:19 --> Model Class Initialized
INFO - 2018-02-07 19:59:19 --> Model Class Initialized
INFO - 2018-02-07 19:59:19 --> Model Class Initialized
INFO - 2018-02-07 19:59:19 --> Model Class Initialized
INFO - 2018-02-07 19:59:19 --> Model Class Initialized
INFO - 2018-02-07 19:59:19 --> Model Class Initialized
INFO - 2018-02-07 19:59:19 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 19:59:19 --> Model Class Initialized
INFO - 2018-02-07 19:59:19 --> Final output sent to browser
DEBUG - 2018-02-07 19:59:19 --> Total execution time: 0.1136
INFO - 2018-02-07 14:32:05 --> Config Class Initialized
INFO - 2018-02-07 14:32:05 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:32:05 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:32:05 --> Utf8 Class Initialized
INFO - 2018-02-07 14:32:05 --> URI Class Initialized
INFO - 2018-02-07 14:32:05 --> Router Class Initialized
INFO - 2018-02-07 14:32:05 --> Output Class Initialized
INFO - 2018-02-07 14:32:05 --> Security Class Initialized
DEBUG - 2018-02-07 14:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:32:05 --> Input Class Initialized
INFO - 2018-02-07 14:32:05 --> Language Class Initialized
INFO - 2018-02-07 14:32:05 --> Language Class Initialized
INFO - 2018-02-07 14:32:05 --> Config Class Initialized
INFO - 2018-02-07 14:32:05 --> Loader Class Initialized
INFO - 2018-02-07 20:02:05 --> Helper loaded: url_helper
INFO - 2018-02-07 20:02:05 --> Helper loaded: notification_helper
INFO - 2018-02-07 20:02:05 --> Helper loaded: settings_helper
INFO - 2018-02-07 20:02:05 --> Helper loaded: permission_helper
INFO - 2018-02-07 20:02:05 --> Helper loaded: users_helper
INFO - 2018-02-07 20:02:05 --> Database Driver Class Initialized
DEBUG - 2018-02-07 20:02:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 20:02:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 20:02:05 --> Helper loaded: form_helper
INFO - 2018-02-07 20:02:05 --> Form Validation Class Initialized
INFO - 2018-02-07 20:02:05 --> Controller Class Initialized
INFO - 2018-02-07 20:02:06 --> Model Class Initialized
INFO - 2018-02-07 20:02:06 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 20:02:06 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 20:02:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 20:02:06 --> Model Class Initialized
INFO - 2018-02-07 20:02:06 --> Model Class Initialized
INFO - 2018-02-07 20:02:06 --> Model Class Initialized
INFO - 2018-02-07 20:02:06 --> Model Class Initialized
INFO - 2018-02-07 20:02:06 --> Model Class Initialized
INFO - 2018-02-07 20:02:06 --> Model Class Initialized
INFO - 2018-02-07 20:02:06 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 20:02:06 --> Model Class Initialized
INFO - 2018-02-07 20:02:06 --> Final output sent to browser
DEBUG - 2018-02-07 20:02:06 --> Total execution time: 0.1122
INFO - 2018-02-07 14:32:06 --> Config Class Initialized
INFO - 2018-02-07 14:32:06 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:32:06 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:32:06 --> Utf8 Class Initialized
INFO - 2018-02-07 14:32:06 --> URI Class Initialized
INFO - 2018-02-07 14:32:06 --> Router Class Initialized
INFO - 2018-02-07 14:32:06 --> Output Class Initialized
INFO - 2018-02-07 14:32:06 --> Security Class Initialized
DEBUG - 2018-02-07 14:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:32:06 --> Input Class Initialized
INFO - 2018-02-07 14:32:06 --> Language Class Initialized
INFO - 2018-02-07 14:32:06 --> Language Class Initialized
INFO - 2018-02-07 14:32:06 --> Config Class Initialized
INFO - 2018-02-07 14:32:06 --> Loader Class Initialized
INFO - 2018-02-07 20:02:06 --> Helper loaded: url_helper
INFO - 2018-02-07 20:02:06 --> Helper loaded: notification_helper
INFO - 2018-02-07 20:02:06 --> Helper loaded: settings_helper
INFO - 2018-02-07 20:02:06 --> Helper loaded: permission_helper
INFO - 2018-02-07 20:02:06 --> Helper loaded: users_helper
INFO - 2018-02-07 20:02:06 --> Database Driver Class Initialized
DEBUG - 2018-02-07 20:02:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 20:02:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 20:02:06 --> Helper loaded: form_helper
INFO - 2018-02-07 20:02:06 --> Form Validation Class Initialized
INFO - 2018-02-07 20:02:06 --> Controller Class Initialized
INFO - 2018-02-07 20:02:06 --> Model Class Initialized
INFO - 2018-02-07 20:02:06 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 20:02:06 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 20:02:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 20:02:06 --> Model Class Initialized
INFO - 2018-02-07 20:02:06 --> Model Class Initialized
INFO - 2018-02-07 20:02:06 --> Model Class Initialized
INFO - 2018-02-07 20:02:06 --> Model Class Initialized
INFO - 2018-02-07 20:02:06 --> Model Class Initialized
INFO - 2018-02-07 20:02:06 --> Model Class Initialized
INFO - 2018-02-07 20:02:06 --> Model Class Initialized
INFO - 2018-02-07 20:02:06 --> Model Class Initialized
INFO - 2018-02-07 20:02:06 --> Model Class Initialized
INFO - 2018-02-07 20:02:06 --> Model Class Initialized
INFO - 2018-02-07 20:02:06 --> Model Class Initialized
INFO - 2018-02-07 20:02:06 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 20:02:06 --> Model Class Initialized
INFO - 2018-02-07 20:02:06 --> Final output sent to browser
DEBUG - 2018-02-07 20:02:06 --> Total execution time: 0.1370
INFO - 2018-02-07 14:32:08 --> Config Class Initialized
INFO - 2018-02-07 14:32:08 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:32:08 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:32:08 --> Utf8 Class Initialized
INFO - 2018-02-07 14:32:08 --> URI Class Initialized
INFO - 2018-02-07 14:32:08 --> Router Class Initialized
INFO - 2018-02-07 14:32:08 --> Output Class Initialized
INFO - 2018-02-07 14:32:08 --> Security Class Initialized
DEBUG - 2018-02-07 14:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:32:08 --> Input Class Initialized
INFO - 2018-02-07 14:32:08 --> Language Class Initialized
INFO - 2018-02-07 14:32:08 --> Language Class Initialized
INFO - 2018-02-07 14:32:08 --> Config Class Initialized
INFO - 2018-02-07 14:32:08 --> Loader Class Initialized
INFO - 2018-02-07 20:02:08 --> Helper loaded: url_helper
INFO - 2018-02-07 20:02:08 --> Helper loaded: notification_helper
INFO - 2018-02-07 20:02:08 --> Helper loaded: settings_helper
INFO - 2018-02-07 20:02:08 --> Helper loaded: permission_helper
INFO - 2018-02-07 20:02:08 --> Helper loaded: users_helper
INFO - 2018-02-07 20:02:08 --> Database Driver Class Initialized
DEBUG - 2018-02-07 20:02:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 20:02:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 20:02:08 --> Helper loaded: form_helper
INFO - 2018-02-07 20:02:08 --> Form Validation Class Initialized
INFO - 2018-02-07 20:02:08 --> Controller Class Initialized
INFO - 2018-02-07 20:02:08 --> Model Class Initialized
INFO - 2018-02-07 20:02:08 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 20:02:08 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 20:02:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 20:02:08 --> Model Class Initialized
INFO - 2018-02-07 20:02:08 --> Model Class Initialized
INFO - 2018-02-07 20:02:08 --> Model Class Initialized
INFO - 2018-02-07 20:02:08 --> Model Class Initialized
INFO - 2018-02-07 20:02:08 --> Model Class Initialized
INFO - 2018-02-07 20:02:08 --> Model Class Initialized
INFO - 2018-02-07 20:02:08 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 20:02:08 --> Final output sent to browser
DEBUG - 2018-02-07 20:02:08 --> Total execution time: 0.1045
INFO - 2018-02-07 14:32:08 --> Config Class Initialized
INFO - 2018-02-07 14:32:08 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:32:08 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:32:08 --> Utf8 Class Initialized
INFO - 2018-02-07 14:32:08 --> URI Class Initialized
INFO - 2018-02-07 14:32:08 --> Router Class Initialized
INFO - 2018-02-07 14:32:08 --> Output Class Initialized
INFO - 2018-02-07 14:32:08 --> Security Class Initialized
DEBUG - 2018-02-07 14:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:32:08 --> Input Class Initialized
INFO - 2018-02-07 14:32:08 --> Language Class Initialized
INFO - 2018-02-07 14:32:08 --> Language Class Initialized
INFO - 2018-02-07 14:32:08 --> Config Class Initialized
INFO - 2018-02-07 14:32:08 --> Loader Class Initialized
INFO - 2018-02-07 20:02:08 --> Helper loaded: url_helper
INFO - 2018-02-07 20:02:08 --> Helper loaded: notification_helper
INFO - 2018-02-07 20:02:08 --> Helper loaded: settings_helper
INFO - 2018-02-07 20:02:08 --> Helper loaded: permission_helper
INFO - 2018-02-07 20:02:08 --> Helper loaded: users_helper
INFO - 2018-02-07 20:02:08 --> Database Driver Class Initialized
DEBUG - 2018-02-07 20:02:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 20:02:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 20:02:08 --> Helper loaded: form_helper
INFO - 2018-02-07 20:02:08 --> Form Validation Class Initialized
INFO - 2018-02-07 20:02:08 --> Controller Class Initialized
INFO - 2018-02-07 20:02:08 --> Model Class Initialized
INFO - 2018-02-07 20:02:08 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 20:02:08 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 20:02:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 20:02:08 --> Model Class Initialized
INFO - 2018-02-07 20:02:08 --> Model Class Initialized
INFO - 2018-02-07 20:02:08 --> Model Class Initialized
INFO - 2018-02-07 20:02:08 --> Model Class Initialized
INFO - 2018-02-07 20:02:08 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 20:02:08 --> Final output sent to browser
DEBUG - 2018-02-07 20:02:08 --> Total execution time: 0.0830
INFO - 2018-02-07 14:32:10 --> Config Class Initialized
INFO - 2018-02-07 14:32:10 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:32:10 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:32:10 --> Utf8 Class Initialized
INFO - 2018-02-07 14:32:10 --> URI Class Initialized
INFO - 2018-02-07 14:32:10 --> Router Class Initialized
INFO - 2018-02-07 14:32:10 --> Output Class Initialized
INFO - 2018-02-07 14:32:10 --> Security Class Initialized
DEBUG - 2018-02-07 14:32:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:32:10 --> Input Class Initialized
INFO - 2018-02-07 14:32:10 --> Language Class Initialized
INFO - 2018-02-07 14:32:10 --> Language Class Initialized
INFO - 2018-02-07 14:32:10 --> Config Class Initialized
INFO - 2018-02-07 14:32:10 --> Loader Class Initialized
INFO - 2018-02-07 20:02:10 --> Helper loaded: url_helper
INFO - 2018-02-07 20:02:10 --> Helper loaded: notification_helper
INFO - 2018-02-07 20:02:10 --> Helper loaded: settings_helper
INFO - 2018-02-07 20:02:10 --> Helper loaded: permission_helper
INFO - 2018-02-07 20:02:10 --> Helper loaded: users_helper
INFO - 2018-02-07 20:02:10 --> Database Driver Class Initialized
DEBUG - 2018-02-07 20:02:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 20:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 20:02:10 --> Helper loaded: form_helper
INFO - 2018-02-07 20:02:10 --> Form Validation Class Initialized
INFO - 2018-02-07 20:02:10 --> Controller Class Initialized
INFO - 2018-02-07 20:02:10 --> Model Class Initialized
INFO - 2018-02-07 20:02:10 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 20:02:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 20:02:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 20:02:10 --> Model Class Initialized
INFO - 2018-02-07 20:02:10 --> Model Class Initialized
INFO - 2018-02-07 20:02:10 --> Model Class Initialized
INFO - 2018-02-07 20:02:10 --> Model Class Initialized
INFO - 2018-02-07 20:02:10 --> Model Class Initialized
INFO - 2018-02-07 20:02:10 --> Model Class Initialized
INFO - 2018-02-07 20:02:10 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 20:02:10 --> Model Class Initialized
INFO - 2018-02-07 20:02:10 --> Final output sent to browser
DEBUG - 2018-02-07 20:02:10 --> Total execution time: 0.0888
INFO - 2018-02-07 14:32:13 --> Config Class Initialized
INFO - 2018-02-07 14:32:13 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:32:13 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:32:13 --> Utf8 Class Initialized
INFO - 2018-02-07 14:32:13 --> URI Class Initialized
INFO - 2018-02-07 14:32:13 --> Router Class Initialized
INFO - 2018-02-07 14:32:13 --> Output Class Initialized
INFO - 2018-02-07 14:32:13 --> Security Class Initialized
DEBUG - 2018-02-07 14:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:32:13 --> Input Class Initialized
INFO - 2018-02-07 14:32:13 --> Language Class Initialized
INFO - 2018-02-07 14:32:13 --> Language Class Initialized
INFO - 2018-02-07 14:32:13 --> Config Class Initialized
INFO - 2018-02-07 14:32:13 --> Loader Class Initialized
INFO - 2018-02-07 20:02:13 --> Helper loaded: url_helper
INFO - 2018-02-07 20:02:13 --> Helper loaded: notification_helper
INFO - 2018-02-07 20:02:13 --> Helper loaded: settings_helper
INFO - 2018-02-07 20:02:13 --> Helper loaded: permission_helper
INFO - 2018-02-07 20:02:13 --> Helper loaded: users_helper
INFO - 2018-02-07 20:02:13 --> Database Driver Class Initialized
DEBUG - 2018-02-07 20:02:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 20:02:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 20:02:13 --> Helper loaded: form_helper
INFO - 2018-02-07 20:02:13 --> Form Validation Class Initialized
INFO - 2018-02-07 20:02:13 --> Controller Class Initialized
INFO - 2018-02-07 20:02:13 --> Model Class Initialized
INFO - 2018-02-07 20:02:13 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 20:02:13 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 20:02:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 20:02:13 --> Model Class Initialized
INFO - 2018-02-07 20:02:13 --> Model Class Initialized
INFO - 2018-02-07 20:02:13 --> Model Class Initialized
INFO - 2018-02-07 20:02:13 --> Model Class Initialized
INFO - 2018-02-07 20:02:13 --> Model Class Initialized
INFO - 2018-02-07 20:02:13 --> Model Class Initialized
INFO - 2018-02-07 20:02:13 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 20:02:13 --> Model Class Initialized
INFO - 2018-02-07 20:02:13 --> Final output sent to browser
DEBUG - 2018-02-07 20:02:13 --> Total execution time: 0.1561
INFO - 2018-02-07 14:32:44 --> Config Class Initialized
INFO - 2018-02-07 14:32:44 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:32:44 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:32:44 --> Utf8 Class Initialized
INFO - 2018-02-07 14:32:44 --> URI Class Initialized
INFO - 2018-02-07 14:32:44 --> Router Class Initialized
INFO - 2018-02-07 14:32:44 --> Output Class Initialized
INFO - 2018-02-07 14:32:44 --> Security Class Initialized
DEBUG - 2018-02-07 14:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:32:44 --> Input Class Initialized
INFO - 2018-02-07 14:32:44 --> Language Class Initialized
INFO - 2018-02-07 14:32:44 --> Language Class Initialized
INFO - 2018-02-07 14:32:44 --> Config Class Initialized
INFO - 2018-02-07 14:32:44 --> Loader Class Initialized
INFO - 2018-02-07 20:02:44 --> Helper loaded: url_helper
INFO - 2018-02-07 20:02:44 --> Helper loaded: notification_helper
INFO - 2018-02-07 20:02:44 --> Helper loaded: settings_helper
INFO - 2018-02-07 20:02:44 --> Helper loaded: permission_helper
INFO - 2018-02-07 20:02:44 --> Helper loaded: users_helper
INFO - 2018-02-07 20:02:44 --> Database Driver Class Initialized
DEBUG - 2018-02-07 20:02:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 20:02:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 20:02:44 --> Helper loaded: form_helper
INFO - 2018-02-07 20:02:44 --> Form Validation Class Initialized
INFO - 2018-02-07 20:02:44 --> Controller Class Initialized
INFO - 2018-02-07 20:02:44 --> Model Class Initialized
INFO - 2018-02-07 20:02:44 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 20:02:44 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 20:02:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 20:02:44 --> Model Class Initialized
INFO - 2018-02-07 20:02:44 --> Model Class Initialized
INFO - 2018-02-07 20:02:44 --> Model Class Initialized
INFO - 2018-02-07 20:02:44 --> Model Class Initialized
INFO - 2018-02-07 20:02:44 --> Model Class Initialized
INFO - 2018-02-07 20:02:44 --> Model Class Initialized
INFO - 2018-02-07 20:02:44 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 20:02:44 --> Model Class Initialized
INFO - 2018-02-07 20:02:44 --> Final output sent to browser
DEBUG - 2018-02-07 20:02:44 --> Total execution time: 0.1211
INFO - 2018-02-07 14:36:44 --> Config Class Initialized
INFO - 2018-02-07 14:36:44 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:36:44 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:36:44 --> Utf8 Class Initialized
INFO - 2018-02-07 14:36:44 --> Config Class Initialized
INFO - 2018-02-07 14:36:44 --> Hooks Class Initialized
INFO - 2018-02-07 14:36:44 --> URI Class Initialized
DEBUG - 2018-02-07 14:36:44 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:36:44 --> Utf8 Class Initialized
INFO - 2018-02-07 14:36:44 --> URI Class Initialized
INFO - 2018-02-07 14:36:44 --> Router Class Initialized
INFO - 2018-02-07 14:36:44 --> Output Class Initialized
INFO - 2018-02-07 14:36:44 --> Router Class Initialized
INFO - 2018-02-07 14:36:44 --> Security Class Initialized
INFO - 2018-02-07 14:36:44 --> Output Class Initialized
DEBUG - 2018-02-07 14:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:36:44 --> Input Class Initialized
INFO - 2018-02-07 14:36:44 --> Security Class Initialized
INFO - 2018-02-07 14:36:44 --> Language Class Initialized
DEBUG - 2018-02-07 14:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:36:44 --> Input Class Initialized
INFO - 2018-02-07 14:36:44 --> Language Class Initialized
INFO - 2018-02-07 14:36:44 --> Language Class Initialized
INFO - 2018-02-07 14:36:44 --> Config Class Initialized
INFO - 2018-02-07 14:36:44 --> Loader Class Initialized
INFO - 2018-02-07 20:06:44 --> Helper loaded: url_helper
INFO - 2018-02-07 20:06:44 --> Helper loaded: notification_helper
INFO - 2018-02-07 20:06:44 --> Helper loaded: settings_helper
INFO - 2018-02-07 14:36:44 --> Language Class Initialized
INFO - 2018-02-07 14:36:44 --> Config Class Initialized
INFO - 2018-02-07 14:36:44 --> Loader Class Initialized
INFO - 2018-02-07 20:06:44 --> Helper loaded: permission_helper
INFO - 2018-02-07 20:06:44 --> Helper loaded: users_helper
INFO - 2018-02-07 20:06:44 --> Helper loaded: url_helper
INFO - 2018-02-07 20:06:44 --> Helper loaded: notification_helper
INFO - 2018-02-07 20:06:44 --> Helper loaded: settings_helper
INFO - 2018-02-07 20:06:44 --> Helper loaded: permission_helper
INFO - 2018-02-07 20:06:44 --> Helper loaded: users_helper
INFO - 2018-02-07 20:06:44 --> Database Driver Class Initialized
INFO - 2018-02-07 20:06:44 --> Database Driver Class Initialized
DEBUG - 2018-02-07 20:06:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 20:06:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-07 20:06:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 20:06:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 20:06:44 --> Helper loaded: form_helper
INFO - 2018-02-07 20:06:44 --> Form Validation Class Initialized
INFO - 2018-02-07 20:06:44 --> Controller Class Initialized
INFO - 2018-02-07 20:06:44 --> Helper loaded: form_helper
INFO - 2018-02-07 20:06:44 --> Form Validation Class Initialized
INFO - 2018-02-07 20:06:44 --> Controller Class Initialized
INFO - 2018-02-07 20:06:44 --> Model Class Initialized
INFO - 2018-02-07 20:06:44 --> Model Class Initialized
INFO - 2018-02-07 20:06:44 --> Helper loaded: inflector_helper
INFO - 2018-02-07 20:06:44 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 20:06:44 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-02-07 20:06:44 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 20:06:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 20:06:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 20:06:44 --> Model Class Initialized
INFO - 2018-02-07 20:06:44 --> Model Class Initialized
INFO - 2018-02-07 20:06:44 --> Model Class Initialized
INFO - 2018-02-07 20:06:44 --> Model Class Initialized
INFO - 2018-02-07 20:06:44 --> Model Class Initialized
INFO - 2018-02-07 20:06:44 --> Model Class Initialized
INFO - 2018-02-07 20:06:44 --> Model Class Initialized
INFO - 2018-02-07 20:06:44 --> Model Class Initialized
INFO - 2018-02-07 20:06:44 --> Model Class Initialized
INFO - 2018-02-07 20:06:44 --> Model Class Initialized
INFO - 2018-02-07 20:06:44 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 20:06:44 --> Model Class Initialized
INFO - 2018-02-07 20:06:44 --> Model Class Initialized
INFO - 2018-02-07 20:06:44 --> Model Class Initialized
INFO - 2018-02-07 20:06:44 --> Model Class Initialized
INFO - 2018-02-07 20:06:44 --> Model Class Initialized
INFO - 2018-02-07 20:06:44 --> Model Class Initialized
INFO - 2018-02-07 20:06:44 --> Model Class Initialized
INFO - 2018-02-07 20:06:44 --> Final output sent to browser
DEBUG - 2018-02-07 20:06:44 --> Total execution time: 0.1132
INFO - 2018-02-07 20:06:44 --> Model Class Initialized
INFO - 2018-02-07 20:06:44 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 20:06:44 --> Model Class Initialized
INFO - 2018-02-07 20:06:44 --> Final output sent to browser
DEBUG - 2018-02-07 20:06:44 --> Total execution time: 0.1365
INFO - 2018-02-07 14:36:47 --> Config Class Initialized
INFO - 2018-02-07 14:36:47 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:36:47 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:36:47 --> Utf8 Class Initialized
INFO - 2018-02-07 14:36:47 --> URI Class Initialized
INFO - 2018-02-07 14:36:47 --> Config Class Initialized
INFO - 2018-02-07 14:36:47 --> Hooks Class Initialized
INFO - 2018-02-07 14:36:47 --> Router Class Initialized
DEBUG - 2018-02-07 14:36:47 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:36:47 --> Utf8 Class Initialized
INFO - 2018-02-07 14:36:47 --> URI Class Initialized
INFO - 2018-02-07 14:36:47 --> Output Class Initialized
INFO - 2018-02-07 14:36:47 --> Security Class Initialized
INFO - 2018-02-07 14:36:47 --> Router Class Initialized
DEBUG - 2018-02-07 14:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:36:47 --> Input Class Initialized
INFO - 2018-02-07 14:36:47 --> Output Class Initialized
INFO - 2018-02-07 14:36:47 --> Language Class Initialized
INFO - 2018-02-07 14:36:47 --> Security Class Initialized
DEBUG - 2018-02-07 14:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:36:47 --> Input Class Initialized
INFO - 2018-02-07 14:36:47 --> Language Class Initialized
INFO - 2018-02-07 14:36:47 --> Language Class Initialized
INFO - 2018-02-07 14:36:47 --> Config Class Initialized
INFO - 2018-02-07 14:36:47 --> Loader Class Initialized
INFO - 2018-02-07 20:06:47 --> Helper loaded: url_helper
INFO - 2018-02-07 20:06:47 --> Helper loaded: notification_helper
INFO - 2018-02-07 20:06:47 --> Helper loaded: settings_helper
INFO - 2018-02-07 20:06:47 --> Helper loaded: permission_helper
INFO - 2018-02-07 20:06:47 --> Helper loaded: users_helper
INFO - 2018-02-07 14:36:47 --> Language Class Initialized
INFO - 2018-02-07 14:36:47 --> Config Class Initialized
INFO - 2018-02-07 14:36:47 --> Loader Class Initialized
INFO - 2018-02-07 20:06:47 --> Helper loaded: url_helper
INFO - 2018-02-07 20:06:47 --> Helper loaded: notification_helper
INFO - 2018-02-07 20:06:47 --> Helper loaded: settings_helper
INFO - 2018-02-07 20:06:47 --> Helper loaded: permission_helper
INFO - 2018-02-07 20:06:47 --> Helper loaded: users_helper
INFO - 2018-02-07 20:06:47 --> Database Driver Class Initialized
DEBUG - 2018-02-07 20:06:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 20:06:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 20:06:47 --> Database Driver Class Initialized
INFO - 2018-02-07 20:06:47 --> Helper loaded: form_helper
INFO - 2018-02-07 20:06:47 --> Form Validation Class Initialized
INFO - 2018-02-07 20:06:47 --> Controller Class Initialized
DEBUG - 2018-02-07 20:06:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 20:06:47 --> Model Class Initialized
INFO - 2018-02-07 20:06:47 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 20:06:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 20:06:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 20:06:47 --> Model Class Initialized
INFO - 2018-02-07 20:06:47 --> Model Class Initialized
INFO - 2018-02-07 20:06:47 --> Model Class Initialized
INFO - 2018-02-07 20:06:47 --> Model Class Initialized
INFO - 2018-02-07 20:06:47 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 20:06:47 --> Final output sent to browser
DEBUG - 2018-02-07 20:06:47 --> Total execution time: 0.1007
INFO - 2018-02-07 20:06:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 20:06:47 --> Helper loaded: form_helper
INFO - 2018-02-07 20:06:47 --> Form Validation Class Initialized
INFO - 2018-02-07 20:06:47 --> Controller Class Initialized
INFO - 2018-02-07 20:06:47 --> Model Class Initialized
INFO - 2018-02-07 20:06:47 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 20:06:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 20:06:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 20:06:47 --> Model Class Initialized
INFO - 2018-02-07 20:06:47 --> Model Class Initialized
INFO - 2018-02-07 20:06:47 --> Model Class Initialized
INFO - 2018-02-07 20:06:47 --> Model Class Initialized
INFO - 2018-02-07 20:06:47 --> Model Class Initialized
INFO - 2018-02-07 20:06:47 --> Model Class Initialized
INFO - 2018-02-07 20:06:47 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 20:06:47 --> Final output sent to browser
DEBUG - 2018-02-07 20:06:47 --> Total execution time: 0.1280
INFO - 2018-02-07 14:36:50 --> Config Class Initialized
INFO - 2018-02-07 14:36:50 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:36:50 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:36:50 --> Utf8 Class Initialized
INFO - 2018-02-07 14:36:50 --> URI Class Initialized
INFO - 2018-02-07 14:36:50 --> Router Class Initialized
INFO - 2018-02-07 14:36:50 --> Output Class Initialized
INFO - 2018-02-07 14:36:50 --> Security Class Initialized
DEBUG - 2018-02-07 14:36:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:36:50 --> Input Class Initialized
INFO - 2018-02-07 14:36:50 --> Language Class Initialized
INFO - 2018-02-07 14:36:50 --> Language Class Initialized
INFO - 2018-02-07 14:36:50 --> Config Class Initialized
INFO - 2018-02-07 14:36:50 --> Loader Class Initialized
INFO - 2018-02-07 20:06:50 --> Helper loaded: url_helper
INFO - 2018-02-07 20:06:50 --> Helper loaded: notification_helper
INFO - 2018-02-07 20:06:50 --> Helper loaded: settings_helper
INFO - 2018-02-07 20:06:50 --> Helper loaded: permission_helper
INFO - 2018-02-07 20:06:50 --> Helper loaded: users_helper
INFO - 2018-02-07 20:06:50 --> Database Driver Class Initialized
DEBUG - 2018-02-07 20:06:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 20:06:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 20:06:50 --> Helper loaded: form_helper
INFO - 2018-02-07 20:06:50 --> Form Validation Class Initialized
INFO - 2018-02-07 20:06:50 --> Controller Class Initialized
INFO - 2018-02-07 20:06:50 --> Model Class Initialized
INFO - 2018-02-07 20:06:50 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 20:06:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 20:06:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 20:06:50 --> Model Class Initialized
INFO - 2018-02-07 20:06:50 --> Model Class Initialized
INFO - 2018-02-07 20:06:50 --> Model Class Initialized
INFO - 2018-02-07 20:06:50 --> Model Class Initialized
INFO - 2018-02-07 20:06:50 --> Model Class Initialized
INFO - 2018-02-07 20:06:50 --> Model Class Initialized
INFO - 2018-02-07 20:06:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 20:06:50 --> Model Class Initialized
INFO - 2018-02-07 20:06:50 --> Final output sent to browser
DEBUG - 2018-02-07 20:06:50 --> Total execution time: 0.1164
INFO - 2018-02-07 14:36:56 --> Config Class Initialized
INFO - 2018-02-07 14:36:56 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:36:56 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:36:56 --> Utf8 Class Initialized
INFO - 2018-02-07 14:36:56 --> URI Class Initialized
INFO - 2018-02-07 14:36:56 --> Router Class Initialized
INFO - 2018-02-07 14:36:56 --> Output Class Initialized
INFO - 2018-02-07 14:36:56 --> Security Class Initialized
DEBUG - 2018-02-07 14:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:36:56 --> Input Class Initialized
INFO - 2018-02-07 14:36:56 --> Language Class Initialized
INFO - 2018-02-07 14:36:56 --> Language Class Initialized
INFO - 2018-02-07 14:36:56 --> Config Class Initialized
INFO - 2018-02-07 14:36:56 --> Loader Class Initialized
INFO - 2018-02-07 20:06:56 --> Helper loaded: url_helper
INFO - 2018-02-07 20:06:56 --> Helper loaded: notification_helper
INFO - 2018-02-07 20:06:56 --> Helper loaded: settings_helper
INFO - 2018-02-07 20:06:56 --> Helper loaded: permission_helper
INFO - 2018-02-07 20:06:56 --> Helper loaded: users_helper
INFO - 2018-02-07 20:06:56 --> Database Driver Class Initialized
DEBUG - 2018-02-07 20:06:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 20:06:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 20:06:56 --> Helper loaded: form_helper
INFO - 2018-02-07 20:06:56 --> Form Validation Class Initialized
INFO - 2018-02-07 20:06:56 --> Controller Class Initialized
INFO - 2018-02-07 20:06:56 --> Model Class Initialized
INFO - 2018-02-07 20:06:56 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 20:06:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 20:06:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 20:06:56 --> Model Class Initialized
INFO - 2018-02-07 20:06:56 --> Model Class Initialized
INFO - 2018-02-07 20:06:56 --> Model Class Initialized
INFO - 2018-02-07 20:06:56 --> Model Class Initialized
INFO - 2018-02-07 20:06:56 --> Model Class Initialized
INFO - 2018-02-07 20:06:56 --> Model Class Initialized
INFO - 2018-02-07 20:06:56 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 20:06:56 --> Model Class Initialized
INFO - 2018-02-07 20:06:56 --> Final output sent to browser
DEBUG - 2018-02-07 20:06:56 --> Total execution time: 0.1196
INFO - 2018-02-07 14:38:38 --> Config Class Initialized
INFO - 2018-02-07 14:38:38 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:38:38 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:38:38 --> Utf8 Class Initialized
INFO - 2018-02-07 14:38:38 --> URI Class Initialized
INFO - 2018-02-07 14:38:38 --> Router Class Initialized
INFO - 2018-02-07 14:38:38 --> Output Class Initialized
INFO - 2018-02-07 14:38:38 --> Security Class Initialized
DEBUG - 2018-02-07 14:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:38:38 --> Input Class Initialized
INFO - 2018-02-07 14:38:38 --> Language Class Initialized
INFO - 2018-02-07 14:38:38 --> Language Class Initialized
INFO - 2018-02-07 14:38:38 --> Config Class Initialized
INFO - 2018-02-07 14:38:38 --> Loader Class Initialized
INFO - 2018-02-07 20:08:38 --> Helper loaded: url_helper
INFO - 2018-02-07 20:08:38 --> Helper loaded: notification_helper
INFO - 2018-02-07 20:08:38 --> Helper loaded: settings_helper
INFO - 2018-02-07 20:08:38 --> Helper loaded: permission_helper
INFO - 2018-02-07 20:08:38 --> Helper loaded: users_helper
INFO - 2018-02-07 20:08:38 --> Database Driver Class Initialized
DEBUG - 2018-02-07 20:08:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 20:08:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 20:08:38 --> Helper loaded: form_helper
INFO - 2018-02-07 20:08:38 --> Form Validation Class Initialized
INFO - 2018-02-07 20:08:38 --> Controller Class Initialized
INFO - 2018-02-07 20:08:38 --> Model Class Initialized
INFO - 2018-02-07 20:08:38 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 20:08:38 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 20:08:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 20:08:38 --> Model Class Initialized
INFO - 2018-02-07 20:08:38 --> Model Class Initialized
INFO - 2018-02-07 20:08:38 --> Model Class Initialized
INFO - 2018-02-07 20:08:38 --> Model Class Initialized
INFO - 2018-02-07 20:08:38 --> Model Class Initialized
INFO - 2018-02-07 20:08:38 --> Model Class Initialized
INFO - 2018-02-07 20:08:38 --> Model Class Initialized
INFO - 2018-02-07 20:08:38 --> Model Class Initialized
INFO - 2018-02-07 20:08:38 --> Model Class Initialized
INFO - 2018-02-07 20:08:38 --> Model Class Initialized
INFO - 2018-02-07 20:08:38 --> Model Class Initialized
INFO - 2018-02-07 20:08:38 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 20:08:38 --> Model Class Initialized
INFO - 2018-02-07 20:08:38 --> Final output sent to browser
DEBUG - 2018-02-07 20:08:38 --> Total execution time: 0.1187
INFO - 2018-02-07 14:38:38 --> Config Class Initialized
INFO - 2018-02-07 14:38:38 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:38:38 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:38:38 --> Utf8 Class Initialized
INFO - 2018-02-07 14:38:38 --> URI Class Initialized
INFO - 2018-02-07 14:38:38 --> Router Class Initialized
INFO - 2018-02-07 14:38:38 --> Output Class Initialized
INFO - 2018-02-07 14:38:38 --> Security Class Initialized
DEBUG - 2018-02-07 14:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:38:38 --> Input Class Initialized
INFO - 2018-02-07 14:38:38 --> Language Class Initialized
INFO - 2018-02-07 14:38:38 --> Language Class Initialized
INFO - 2018-02-07 14:38:38 --> Config Class Initialized
INFO - 2018-02-07 14:38:38 --> Loader Class Initialized
INFO - 2018-02-07 20:08:38 --> Helper loaded: url_helper
INFO - 2018-02-07 20:08:38 --> Helper loaded: notification_helper
INFO - 2018-02-07 20:08:38 --> Helper loaded: settings_helper
INFO - 2018-02-07 20:08:38 --> Helper loaded: permission_helper
INFO - 2018-02-07 20:08:38 --> Helper loaded: users_helper
INFO - 2018-02-07 20:08:38 --> Database Driver Class Initialized
DEBUG - 2018-02-07 20:08:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 20:08:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 20:08:38 --> Helper loaded: form_helper
INFO - 2018-02-07 20:08:38 --> Form Validation Class Initialized
INFO - 2018-02-07 20:08:38 --> Controller Class Initialized
INFO - 2018-02-07 20:08:38 --> Model Class Initialized
INFO - 2018-02-07 20:08:38 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 20:08:38 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 20:08:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 20:08:38 --> Model Class Initialized
INFO - 2018-02-07 20:08:38 --> Model Class Initialized
INFO - 2018-02-07 20:08:38 --> Model Class Initialized
INFO - 2018-02-07 20:08:38 --> Model Class Initialized
INFO - 2018-02-07 20:08:38 --> Model Class Initialized
INFO - 2018-02-07 20:08:38 --> Model Class Initialized
INFO - 2018-02-07 20:08:38 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 20:08:38 --> Model Class Initialized
INFO - 2018-02-07 20:08:38 --> Final output sent to browser
DEBUG - 2018-02-07 20:08:38 --> Total execution time: 0.1161
INFO - 2018-02-07 14:38:41 --> Config Class Initialized
INFO - 2018-02-07 14:38:41 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:38:41 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:38:41 --> Utf8 Class Initialized
INFO - 2018-02-07 14:38:41 --> URI Class Initialized
INFO - 2018-02-07 14:38:41 --> Router Class Initialized
INFO - 2018-02-07 14:38:41 --> Output Class Initialized
INFO - 2018-02-07 14:38:41 --> Config Class Initialized
INFO - 2018-02-07 14:38:41 --> Hooks Class Initialized
INFO - 2018-02-07 14:38:41 --> Security Class Initialized
DEBUG - 2018-02-07 14:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:38:41 --> Input Class Initialized
INFO - 2018-02-07 14:38:41 --> Language Class Initialized
DEBUG - 2018-02-07 14:38:41 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:38:41 --> Utf8 Class Initialized
INFO - 2018-02-07 14:38:41 --> URI Class Initialized
INFO - 2018-02-07 14:38:41 --> Router Class Initialized
INFO - 2018-02-07 14:38:41 --> Output Class Initialized
INFO - 2018-02-07 14:38:41 --> Language Class Initialized
INFO - 2018-02-07 14:38:41 --> Config Class Initialized
INFO - 2018-02-07 14:38:41 --> Loader Class Initialized
INFO - 2018-02-07 14:38:41 --> Security Class Initialized
INFO - 2018-02-07 20:08:41 --> Helper loaded: url_helper
INFO - 2018-02-07 20:08:41 --> Helper loaded: notification_helper
INFO - 2018-02-07 20:08:41 --> Helper loaded: settings_helper
DEBUG - 2018-02-07 14:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:38:41 --> Input Class Initialized
INFO - 2018-02-07 20:08:41 --> Helper loaded: permission_helper
INFO - 2018-02-07 20:08:41 --> Helper loaded: users_helper
INFO - 2018-02-07 14:38:41 --> Language Class Initialized
INFO - 2018-02-07 20:08:41 --> Database Driver Class Initialized
DEBUG - 2018-02-07 20:08:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 20:08:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 14:38:41 --> Language Class Initialized
INFO - 2018-02-07 14:38:41 --> Config Class Initialized
INFO - 2018-02-07 14:38:41 --> Loader Class Initialized
INFO - 2018-02-07 20:08:41 --> Helper loaded: form_helper
INFO - 2018-02-07 20:08:41 --> Form Validation Class Initialized
INFO - 2018-02-07 20:08:41 --> Controller Class Initialized
INFO - 2018-02-07 20:08:41 --> Helper loaded: url_helper
INFO - 2018-02-07 20:08:41 --> Helper loaded: notification_helper
INFO - 2018-02-07 20:08:41 --> Helper loaded: settings_helper
INFO - 2018-02-07 20:08:41 --> Helper loaded: permission_helper
INFO - 2018-02-07 20:08:41 --> Helper loaded: users_helper
INFO - 2018-02-07 20:08:41 --> Model Class Initialized
INFO - 2018-02-07 20:08:41 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 20:08:41 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 20:08:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 20:08:41 --> Model Class Initialized
INFO - 2018-02-07 20:08:41 --> Model Class Initialized
INFO - 2018-02-07 20:08:41 --> Model Class Initialized
INFO - 2018-02-07 20:08:41 --> Model Class Initialized
INFO - 2018-02-07 20:08:41 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 20:08:41 --> Final output sent to browser
DEBUG - 2018-02-07 20:08:41 --> Total execution time: 0.0810
INFO - 2018-02-07 20:08:41 --> Database Driver Class Initialized
DEBUG - 2018-02-07 20:08:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 20:08:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 20:08:41 --> Helper loaded: form_helper
INFO - 2018-02-07 20:08:41 --> Form Validation Class Initialized
INFO - 2018-02-07 20:08:41 --> Controller Class Initialized
INFO - 2018-02-07 20:08:41 --> Model Class Initialized
INFO - 2018-02-07 20:08:41 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 20:08:41 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 20:08:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 20:08:41 --> Model Class Initialized
INFO - 2018-02-07 20:08:41 --> Model Class Initialized
INFO - 2018-02-07 20:08:41 --> Model Class Initialized
INFO - 2018-02-07 20:08:41 --> Model Class Initialized
INFO - 2018-02-07 20:08:41 --> Model Class Initialized
INFO - 2018-02-07 20:08:41 --> Model Class Initialized
INFO - 2018-02-07 20:08:41 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 20:08:41 --> Final output sent to browser
DEBUG - 2018-02-07 20:08:41 --> Total execution time: 0.1095
INFO - 2018-02-07 14:38:44 --> Config Class Initialized
INFO - 2018-02-07 14:38:44 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:38:44 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:38:44 --> Utf8 Class Initialized
INFO - 2018-02-07 14:38:44 --> URI Class Initialized
INFO - 2018-02-07 14:38:44 --> Router Class Initialized
INFO - 2018-02-07 14:38:44 --> Output Class Initialized
INFO - 2018-02-07 14:38:44 --> Security Class Initialized
DEBUG - 2018-02-07 14:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:38:44 --> Input Class Initialized
INFO - 2018-02-07 14:38:44 --> Language Class Initialized
INFO - 2018-02-07 14:38:45 --> Language Class Initialized
INFO - 2018-02-07 14:38:45 --> Config Class Initialized
INFO - 2018-02-07 14:38:45 --> Loader Class Initialized
INFO - 2018-02-07 20:08:45 --> Helper loaded: url_helper
INFO - 2018-02-07 20:08:45 --> Helper loaded: notification_helper
INFO - 2018-02-07 20:08:45 --> Helper loaded: settings_helper
INFO - 2018-02-07 20:08:45 --> Helper loaded: permission_helper
INFO - 2018-02-07 20:08:45 --> Helper loaded: users_helper
INFO - 2018-02-07 20:08:45 --> Database Driver Class Initialized
DEBUG - 2018-02-07 20:08:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 20:08:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 20:08:45 --> Helper loaded: form_helper
INFO - 2018-02-07 20:08:45 --> Form Validation Class Initialized
INFO - 2018-02-07 20:08:45 --> Controller Class Initialized
INFO - 2018-02-07 20:08:45 --> Model Class Initialized
INFO - 2018-02-07 20:08:45 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 20:08:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 20:08:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 20:08:45 --> Model Class Initialized
INFO - 2018-02-07 20:08:45 --> Model Class Initialized
INFO - 2018-02-07 20:08:45 --> Model Class Initialized
INFO - 2018-02-07 20:08:45 --> Model Class Initialized
INFO - 2018-02-07 20:08:45 --> Model Class Initialized
INFO - 2018-02-07 20:08:45 --> Model Class Initialized
INFO - 2018-02-07 20:08:45 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 20:08:45 --> Model Class Initialized
INFO - 2018-02-07 20:08:45 --> Final output sent to browser
DEBUG - 2018-02-07 20:08:45 --> Total execution time: 0.1087
INFO - 2018-02-07 14:45:08 --> Config Class Initialized
INFO - 2018-02-07 14:45:08 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:45:08 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:45:08 --> Utf8 Class Initialized
INFO - 2018-02-07 14:45:08 --> URI Class Initialized
INFO - 2018-02-07 14:45:08 --> Router Class Initialized
INFO - 2018-02-07 14:45:08 --> Output Class Initialized
INFO - 2018-02-07 14:45:08 --> Security Class Initialized
DEBUG - 2018-02-07 14:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:45:08 --> Input Class Initialized
INFO - 2018-02-07 14:45:08 --> Language Class Initialized
INFO - 2018-02-07 14:45:08 --> Language Class Initialized
INFO - 2018-02-07 14:45:08 --> Config Class Initialized
INFO - 2018-02-07 14:45:08 --> Loader Class Initialized
INFO - 2018-02-07 20:15:08 --> Helper loaded: url_helper
INFO - 2018-02-07 20:15:08 --> Helper loaded: notification_helper
INFO - 2018-02-07 20:15:08 --> Helper loaded: settings_helper
INFO - 2018-02-07 20:15:08 --> Helper loaded: permission_helper
INFO - 2018-02-07 20:15:08 --> Helper loaded: users_helper
INFO - 2018-02-07 20:15:08 --> Database Driver Class Initialized
DEBUG - 2018-02-07 20:15:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 20:15:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 20:15:08 --> Helper loaded: form_helper
INFO - 2018-02-07 20:15:08 --> Form Validation Class Initialized
INFO - 2018-02-07 20:15:08 --> Controller Class Initialized
INFO - 2018-02-07 20:15:08 --> Model Class Initialized
INFO - 2018-02-07 20:15:08 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 20:15:08 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 20:15:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 20:15:08 --> Model Class Initialized
INFO - 2018-02-07 20:15:08 --> Model Class Initialized
INFO - 2018-02-07 20:15:08 --> Model Class Initialized
INFO - 2018-02-07 20:15:08 --> Model Class Initialized
INFO - 2018-02-07 20:15:08 --> Model Class Initialized
INFO - 2018-02-07 20:15:08 --> Model Class Initialized
INFO - 2018-02-07 20:15:08 --> Model Class Initialized
INFO - 2018-02-07 20:15:08 --> Model Class Initialized
INFO - 2018-02-07 20:15:08 --> Model Class Initialized
INFO - 2018-02-07 20:15:08 --> Model Class Initialized
INFO - 2018-02-07 20:15:08 --> Model Class Initialized
INFO - 2018-02-07 20:15:08 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 20:15:08 --> Model Class Initialized
INFO - 2018-02-07 20:15:08 --> Final output sent to browser
DEBUG - 2018-02-07 20:15:08 --> Total execution time: 0.1287
INFO - 2018-02-07 14:45:08 --> Config Class Initialized
INFO - 2018-02-07 14:45:08 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:45:08 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:45:08 --> Utf8 Class Initialized
INFO - 2018-02-07 14:45:08 --> URI Class Initialized
INFO - 2018-02-07 14:45:08 --> Router Class Initialized
INFO - 2018-02-07 14:45:08 --> Output Class Initialized
INFO - 2018-02-07 14:45:08 --> Security Class Initialized
DEBUG - 2018-02-07 14:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:45:08 --> Input Class Initialized
INFO - 2018-02-07 14:45:08 --> Language Class Initialized
INFO - 2018-02-07 14:45:08 --> Language Class Initialized
INFO - 2018-02-07 14:45:08 --> Config Class Initialized
INFO - 2018-02-07 14:45:08 --> Loader Class Initialized
INFO - 2018-02-07 20:15:08 --> Helper loaded: url_helper
INFO - 2018-02-07 20:15:08 --> Helper loaded: notification_helper
INFO - 2018-02-07 20:15:08 --> Helper loaded: settings_helper
INFO - 2018-02-07 20:15:08 --> Helper loaded: permission_helper
INFO - 2018-02-07 20:15:08 --> Helper loaded: users_helper
INFO - 2018-02-07 20:15:08 --> Database Driver Class Initialized
DEBUG - 2018-02-07 20:15:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 20:15:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 20:15:08 --> Helper loaded: form_helper
INFO - 2018-02-07 20:15:08 --> Form Validation Class Initialized
INFO - 2018-02-07 20:15:08 --> Controller Class Initialized
INFO - 2018-02-07 20:15:08 --> Model Class Initialized
INFO - 2018-02-07 20:15:08 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 20:15:08 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 20:15:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 20:15:08 --> Model Class Initialized
INFO - 2018-02-07 20:15:08 --> Model Class Initialized
INFO - 2018-02-07 20:15:08 --> Model Class Initialized
INFO - 2018-02-07 20:15:08 --> Model Class Initialized
INFO - 2018-02-07 20:15:08 --> Model Class Initialized
INFO - 2018-02-07 20:15:08 --> Model Class Initialized
INFO - 2018-02-07 20:15:08 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 20:15:08 --> Model Class Initialized
INFO - 2018-02-07 20:15:08 --> Final output sent to browser
DEBUG - 2018-02-07 20:15:08 --> Total execution time: 0.1079
INFO - 2018-02-07 14:45:12 --> Config Class Initialized
INFO - 2018-02-07 14:45:12 --> Hooks Class Initialized
INFO - 2018-02-07 14:45:12 --> Config Class Initialized
INFO - 2018-02-07 14:45:12 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:45:12 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:45:12 --> Utf8 Class Initialized
INFO - 2018-02-07 14:45:12 --> URI Class Initialized
DEBUG - 2018-02-07 14:45:12 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:45:12 --> Utf8 Class Initialized
INFO - 2018-02-07 14:45:12 --> URI Class Initialized
INFO - 2018-02-07 14:45:12 --> Router Class Initialized
INFO - 2018-02-07 14:45:12 --> Router Class Initialized
INFO - 2018-02-07 14:45:12 --> Output Class Initialized
INFO - 2018-02-07 14:45:12 --> Security Class Initialized
INFO - 2018-02-07 14:45:12 --> Output Class Initialized
DEBUG - 2018-02-07 14:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:45:12 --> Input Class Initialized
INFO - 2018-02-07 14:45:12 --> Security Class Initialized
INFO - 2018-02-07 14:45:12 --> Language Class Initialized
DEBUG - 2018-02-07 14:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:45:12 --> Input Class Initialized
INFO - 2018-02-07 14:45:12 --> Language Class Initialized
INFO - 2018-02-07 14:45:12 --> Language Class Initialized
INFO - 2018-02-07 14:45:12 --> Config Class Initialized
INFO - 2018-02-07 14:45:12 --> Loader Class Initialized
INFO - 2018-02-07 20:15:12 --> Helper loaded: url_helper
INFO - 2018-02-07 14:45:12 --> Language Class Initialized
INFO - 2018-02-07 14:45:12 --> Config Class Initialized
INFO - 2018-02-07 14:45:12 --> Loader Class Initialized
INFO - 2018-02-07 20:15:12 --> Helper loaded: notification_helper
INFO - 2018-02-07 20:15:12 --> Helper loaded: settings_helper
INFO - 2018-02-07 20:15:12 --> Helper loaded: permission_helper
INFO - 2018-02-07 20:15:12 --> Helper loaded: url_helper
INFO - 2018-02-07 20:15:12 --> Helper loaded: users_helper
INFO - 2018-02-07 20:15:12 --> Helper loaded: notification_helper
INFO - 2018-02-07 20:15:12 --> Helper loaded: settings_helper
INFO - 2018-02-07 20:15:12 --> Helper loaded: permission_helper
INFO - 2018-02-07 20:15:12 --> Helper loaded: users_helper
INFO - 2018-02-07 20:15:12 --> Database Driver Class Initialized
INFO - 2018-02-07 20:15:12 --> Database Driver Class Initialized
DEBUG - 2018-02-07 20:15:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 20:15:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-07 20:15:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 20:15:12 --> Helper loaded: form_helper
INFO - 2018-02-07 20:15:12 --> Form Validation Class Initialized
INFO - 2018-02-07 20:15:12 --> Controller Class Initialized
INFO - 2018-02-07 20:15:12 --> Model Class Initialized
INFO - 2018-02-07 20:15:12 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 20:15:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 20:15:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 20:15:12 --> Model Class Initialized
INFO - 2018-02-07 20:15:12 --> Model Class Initialized
INFO - 2018-02-07 20:15:12 --> Model Class Initialized
INFO - 2018-02-07 20:15:12 --> Model Class Initialized
INFO - 2018-02-07 20:15:12 --> Model Class Initialized
INFO - 2018-02-07 20:15:12 --> Model Class Initialized
INFO - 2018-02-07 20:15:12 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 20:15:12 --> Final output sent to browser
DEBUG - 2018-02-07 20:15:12 --> Total execution time: 0.1029
INFO - 2018-02-07 20:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 20:15:12 --> Helper loaded: form_helper
INFO - 2018-02-07 20:15:12 --> Form Validation Class Initialized
INFO - 2018-02-07 20:15:12 --> Controller Class Initialized
INFO - 2018-02-07 20:15:12 --> Model Class Initialized
INFO - 2018-02-07 20:15:12 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 20:15:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 20:15:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 20:15:12 --> Model Class Initialized
INFO - 2018-02-07 20:15:12 --> Model Class Initialized
INFO - 2018-02-07 20:15:12 --> Model Class Initialized
INFO - 2018-02-07 20:15:12 --> Model Class Initialized
INFO - 2018-02-07 20:15:12 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 20:15:12 --> Final output sent to browser
DEBUG - 2018-02-07 20:15:12 --> Total execution time: 0.1260
INFO - 2018-02-07 14:45:14 --> Config Class Initialized
INFO - 2018-02-07 14:45:14 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:45:14 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:45:14 --> Utf8 Class Initialized
INFO - 2018-02-07 14:45:14 --> URI Class Initialized
INFO - 2018-02-07 14:45:14 --> Router Class Initialized
INFO - 2018-02-07 14:45:14 --> Output Class Initialized
INFO - 2018-02-07 14:45:14 --> Security Class Initialized
DEBUG - 2018-02-07 14:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:45:14 --> Input Class Initialized
INFO - 2018-02-07 14:45:14 --> Language Class Initialized
INFO - 2018-02-07 14:45:14 --> Language Class Initialized
INFO - 2018-02-07 14:45:14 --> Config Class Initialized
INFO - 2018-02-07 14:45:14 --> Loader Class Initialized
INFO - 2018-02-07 20:15:14 --> Helper loaded: url_helper
INFO - 2018-02-07 20:15:14 --> Helper loaded: notification_helper
INFO - 2018-02-07 20:15:14 --> Helper loaded: settings_helper
INFO - 2018-02-07 20:15:14 --> Helper loaded: permission_helper
INFO - 2018-02-07 20:15:14 --> Helper loaded: users_helper
INFO - 2018-02-07 20:15:14 --> Database Driver Class Initialized
DEBUG - 2018-02-07 20:15:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 20:15:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 20:15:15 --> Helper loaded: form_helper
INFO - 2018-02-07 20:15:15 --> Form Validation Class Initialized
INFO - 2018-02-07 20:15:15 --> Controller Class Initialized
INFO - 2018-02-07 20:15:15 --> Model Class Initialized
INFO - 2018-02-07 20:15:15 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 20:15:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 20:15:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 20:15:15 --> Model Class Initialized
INFO - 2018-02-07 20:15:15 --> Model Class Initialized
INFO - 2018-02-07 20:15:15 --> Model Class Initialized
INFO - 2018-02-07 20:15:15 --> Model Class Initialized
INFO - 2018-02-07 20:15:15 --> Model Class Initialized
INFO - 2018-02-07 20:15:15 --> Model Class Initialized
INFO - 2018-02-07 20:15:15 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 20:15:15 --> Model Class Initialized
INFO - 2018-02-07 20:15:15 --> Final output sent to browser
DEBUG - 2018-02-07 20:15:15 --> Total execution time: 0.1222
INFO - 2018-02-07 14:48:37 --> Config Class Initialized
INFO - 2018-02-07 14:48:37 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:48:37 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:48:37 --> Utf8 Class Initialized
INFO - 2018-02-07 14:48:37 --> URI Class Initialized
INFO - 2018-02-07 14:48:37 --> Router Class Initialized
INFO - 2018-02-07 14:48:37 --> Output Class Initialized
INFO - 2018-02-07 14:48:37 --> Security Class Initialized
DEBUG - 2018-02-07 14:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:48:37 --> Input Class Initialized
INFO - 2018-02-07 14:48:37 --> Language Class Initialized
INFO - 2018-02-07 14:48:37 --> Language Class Initialized
INFO - 2018-02-07 14:48:37 --> Config Class Initialized
INFO - 2018-02-07 14:48:37 --> Loader Class Initialized
INFO - 2018-02-07 20:18:37 --> Helper loaded: url_helper
INFO - 2018-02-07 20:18:37 --> Helper loaded: notification_helper
INFO - 2018-02-07 20:18:37 --> Helper loaded: settings_helper
INFO - 2018-02-07 20:18:37 --> Helper loaded: permission_helper
INFO - 2018-02-07 20:18:37 --> Helper loaded: users_helper
INFO - 2018-02-07 20:18:37 --> Database Driver Class Initialized
DEBUG - 2018-02-07 20:18:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 20:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 20:18:37 --> Helper loaded: form_helper
INFO - 2018-02-07 20:18:37 --> Form Validation Class Initialized
INFO - 2018-02-07 20:18:37 --> Controller Class Initialized
INFO - 2018-02-07 20:18:37 --> Model Class Initialized
INFO - 2018-02-07 20:18:37 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 20:18:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 20:18:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 20:18:37 --> Model Class Initialized
INFO - 2018-02-07 20:18:37 --> Model Class Initialized
INFO - 2018-02-07 20:18:37 --> Model Class Initialized
INFO - 2018-02-07 20:18:37 --> Model Class Initialized
INFO - 2018-02-07 20:18:37 --> Model Class Initialized
INFO - 2018-02-07 20:18:37 --> Model Class Initialized
INFO - 2018-02-07 20:18:37 --> Model Class Initialized
INFO - 2018-02-07 20:18:37 --> Model Class Initialized
INFO - 2018-02-07 20:18:37 --> Model Class Initialized
INFO - 2018-02-07 20:18:37 --> Model Class Initialized
INFO - 2018-02-07 20:18:37 --> Model Class Initialized
INFO - 2018-02-07 20:18:37 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 20:18:37 --> Model Class Initialized
INFO - 2018-02-07 20:18:37 --> Final output sent to browser
DEBUG - 2018-02-07 20:18:37 --> Total execution time: 0.1103
INFO - 2018-02-07 14:48:38 --> Config Class Initialized
INFO - 2018-02-07 14:48:38 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:48:38 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:48:38 --> Utf8 Class Initialized
INFO - 2018-02-07 14:48:38 --> URI Class Initialized
INFO - 2018-02-07 14:48:38 --> Router Class Initialized
INFO - 2018-02-07 14:48:38 --> Output Class Initialized
INFO - 2018-02-07 14:48:38 --> Security Class Initialized
DEBUG - 2018-02-07 14:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:48:38 --> Input Class Initialized
INFO - 2018-02-07 14:48:38 --> Language Class Initialized
INFO - 2018-02-07 14:48:38 --> Language Class Initialized
INFO - 2018-02-07 14:48:38 --> Config Class Initialized
INFO - 2018-02-07 14:48:38 --> Loader Class Initialized
INFO - 2018-02-07 20:18:38 --> Helper loaded: url_helper
INFO - 2018-02-07 20:18:38 --> Helper loaded: notification_helper
INFO - 2018-02-07 20:18:38 --> Helper loaded: settings_helper
INFO - 2018-02-07 20:18:38 --> Helper loaded: permission_helper
INFO - 2018-02-07 20:18:38 --> Helper loaded: users_helper
INFO - 2018-02-07 20:18:38 --> Database Driver Class Initialized
DEBUG - 2018-02-07 20:18:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 20:18:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 20:18:38 --> Helper loaded: form_helper
INFO - 2018-02-07 20:18:38 --> Form Validation Class Initialized
INFO - 2018-02-07 20:18:38 --> Controller Class Initialized
INFO - 2018-02-07 20:18:38 --> Model Class Initialized
INFO - 2018-02-07 20:18:38 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 20:18:38 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 20:18:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 20:18:38 --> Model Class Initialized
INFO - 2018-02-07 20:18:38 --> Model Class Initialized
INFO - 2018-02-07 20:18:38 --> Model Class Initialized
INFO - 2018-02-07 20:18:38 --> Model Class Initialized
INFO - 2018-02-07 20:18:38 --> Model Class Initialized
INFO - 2018-02-07 20:18:38 --> Model Class Initialized
INFO - 2018-02-07 20:18:38 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 20:18:38 --> Model Class Initialized
INFO - 2018-02-07 20:18:38 --> Final output sent to browser
DEBUG - 2018-02-07 20:18:38 --> Total execution time: 0.1208
INFO - 2018-02-07 14:48:40 --> Config Class Initialized
INFO - 2018-02-07 14:48:40 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:48:40 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:48:40 --> Utf8 Class Initialized
INFO - 2018-02-07 14:48:40 --> URI Class Initialized
INFO - 2018-02-07 14:48:40 --> Config Class Initialized
INFO - 2018-02-07 14:48:40 --> Hooks Class Initialized
INFO - 2018-02-07 14:48:40 --> Router Class Initialized
DEBUG - 2018-02-07 14:48:40 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:48:40 --> Utf8 Class Initialized
INFO - 2018-02-07 14:48:40 --> Output Class Initialized
INFO - 2018-02-07 14:48:40 --> URI Class Initialized
INFO - 2018-02-07 14:48:40 --> Security Class Initialized
DEBUG - 2018-02-07 14:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:48:40 --> Input Class Initialized
INFO - 2018-02-07 14:48:40 --> Router Class Initialized
INFO - 2018-02-07 14:48:40 --> Language Class Initialized
INFO - 2018-02-07 14:48:40 --> Output Class Initialized
INFO - 2018-02-07 14:48:40 --> Security Class Initialized
DEBUG - 2018-02-07 14:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:48:40 --> Input Class Initialized
INFO - 2018-02-07 14:48:40 --> Language Class Initialized
INFO - 2018-02-07 14:48:40 --> Language Class Initialized
INFO - 2018-02-07 14:48:40 --> Config Class Initialized
INFO - 2018-02-07 14:48:40 --> Loader Class Initialized
INFO - 2018-02-07 20:18:40 --> Helper loaded: url_helper
INFO - 2018-02-07 20:18:40 --> Helper loaded: notification_helper
INFO - 2018-02-07 20:18:40 --> Helper loaded: settings_helper
INFO - 2018-02-07 20:18:40 --> Helper loaded: permission_helper
INFO - 2018-02-07 20:18:40 --> Helper loaded: users_helper
INFO - 2018-02-07 14:48:40 --> Language Class Initialized
INFO - 2018-02-07 14:48:40 --> Config Class Initialized
INFO - 2018-02-07 14:48:40 --> Loader Class Initialized
INFO - 2018-02-07 20:18:40 --> Helper loaded: url_helper
INFO - 2018-02-07 20:18:40 --> Helper loaded: notification_helper
INFO - 2018-02-07 20:18:40 --> Helper loaded: settings_helper
INFO - 2018-02-07 20:18:40 --> Helper loaded: permission_helper
INFO - 2018-02-07 20:18:40 --> Helper loaded: users_helper
INFO - 2018-02-07 20:18:40 --> Database Driver Class Initialized
DEBUG - 2018-02-07 20:18:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 20:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 20:18:40 --> Database Driver Class Initialized
INFO - 2018-02-07 20:18:40 --> Helper loaded: form_helper
INFO - 2018-02-07 20:18:40 --> Form Validation Class Initialized
INFO - 2018-02-07 20:18:40 --> Controller Class Initialized
DEBUG - 2018-02-07 20:18:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 20:18:40 --> Model Class Initialized
INFO - 2018-02-07 20:18:40 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 20:18:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 20:18:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 20:18:40 --> Model Class Initialized
INFO - 2018-02-07 20:18:40 --> Model Class Initialized
INFO - 2018-02-07 20:18:40 --> Model Class Initialized
INFO - 2018-02-07 20:18:40 --> Model Class Initialized
INFO - 2018-02-07 20:18:40 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 20:18:40 --> Final output sent to browser
DEBUG - 2018-02-07 20:18:40 --> Total execution time: 0.1082
INFO - 2018-02-07 20:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 20:18:40 --> Helper loaded: form_helper
INFO - 2018-02-07 20:18:40 --> Form Validation Class Initialized
INFO - 2018-02-07 20:18:40 --> Controller Class Initialized
INFO - 2018-02-07 20:18:40 --> Model Class Initialized
INFO - 2018-02-07 20:18:40 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 20:18:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 20:18:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 20:18:40 --> Model Class Initialized
INFO - 2018-02-07 20:18:40 --> Model Class Initialized
INFO - 2018-02-07 20:18:40 --> Model Class Initialized
INFO - 2018-02-07 20:18:40 --> Model Class Initialized
INFO - 2018-02-07 20:18:40 --> Model Class Initialized
INFO - 2018-02-07 20:18:40 --> Model Class Initialized
INFO - 2018-02-07 20:18:40 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 20:18:40 --> Final output sent to browser
DEBUG - 2018-02-07 20:18:40 --> Total execution time: 0.1371
INFO - 2018-02-07 14:48:43 --> Config Class Initialized
INFO - 2018-02-07 14:48:43 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:48:43 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:48:43 --> Utf8 Class Initialized
INFO - 2018-02-07 14:48:43 --> URI Class Initialized
INFO - 2018-02-07 14:48:43 --> Router Class Initialized
INFO - 2018-02-07 14:48:43 --> Output Class Initialized
INFO - 2018-02-07 14:48:43 --> Security Class Initialized
DEBUG - 2018-02-07 14:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:48:43 --> Input Class Initialized
INFO - 2018-02-07 14:48:43 --> Language Class Initialized
INFO - 2018-02-07 14:48:43 --> Language Class Initialized
INFO - 2018-02-07 14:48:43 --> Config Class Initialized
INFO - 2018-02-07 14:48:43 --> Loader Class Initialized
INFO - 2018-02-07 20:18:43 --> Helper loaded: url_helper
INFO - 2018-02-07 20:18:43 --> Helper loaded: notification_helper
INFO - 2018-02-07 20:18:43 --> Helper loaded: settings_helper
INFO - 2018-02-07 20:18:43 --> Helper loaded: permission_helper
INFO - 2018-02-07 20:18:43 --> Helper loaded: users_helper
INFO - 2018-02-07 20:18:43 --> Database Driver Class Initialized
DEBUG - 2018-02-07 20:18:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 20:18:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 20:18:43 --> Helper loaded: form_helper
INFO - 2018-02-07 20:18:43 --> Form Validation Class Initialized
INFO - 2018-02-07 20:18:43 --> Controller Class Initialized
INFO - 2018-02-07 20:18:43 --> Model Class Initialized
INFO - 2018-02-07 20:18:43 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 20:18:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 20:18:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 20:18:43 --> Model Class Initialized
INFO - 2018-02-07 20:18:43 --> Model Class Initialized
INFO - 2018-02-07 20:18:43 --> Model Class Initialized
INFO - 2018-02-07 20:18:43 --> Model Class Initialized
INFO - 2018-02-07 20:18:43 --> Model Class Initialized
INFO - 2018-02-07 20:18:43 --> Model Class Initialized
INFO - 2018-02-07 20:18:43 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 20:18:43 --> Model Class Initialized
INFO - 2018-02-07 20:18:43 --> Final output sent to browser
DEBUG - 2018-02-07 20:18:43 --> Total execution time: 0.1009
INFO - 2018-02-07 14:51:06 --> Config Class Initialized
INFO - 2018-02-07 14:51:06 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:51:06 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:51:06 --> Utf8 Class Initialized
INFO - 2018-02-07 14:51:06 --> URI Class Initialized
INFO - 2018-02-07 14:51:06 --> Router Class Initialized
INFO - 2018-02-07 14:51:06 --> Output Class Initialized
INFO - 2018-02-07 14:51:06 --> Security Class Initialized
DEBUG - 2018-02-07 14:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:51:06 --> Input Class Initialized
INFO - 2018-02-07 14:51:06 --> Language Class Initialized
INFO - 2018-02-07 14:51:06 --> Language Class Initialized
INFO - 2018-02-07 14:51:06 --> Config Class Initialized
INFO - 2018-02-07 14:51:06 --> Loader Class Initialized
INFO - 2018-02-07 20:21:06 --> Helper loaded: url_helper
INFO - 2018-02-07 20:21:06 --> Helper loaded: notification_helper
INFO - 2018-02-07 20:21:06 --> Helper loaded: settings_helper
INFO - 2018-02-07 20:21:06 --> Helper loaded: permission_helper
INFO - 2018-02-07 20:21:06 --> Helper loaded: users_helper
INFO - 2018-02-07 20:21:06 --> Database Driver Class Initialized
DEBUG - 2018-02-07 20:21:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 20:21:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 20:21:06 --> Helper loaded: form_helper
INFO - 2018-02-07 20:21:06 --> Form Validation Class Initialized
INFO - 2018-02-07 20:21:06 --> Controller Class Initialized
INFO - 2018-02-07 20:21:06 --> Model Class Initialized
INFO - 2018-02-07 20:21:06 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 20:21:06 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 20:21:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 20:21:06 --> Model Class Initialized
INFO - 2018-02-07 20:21:06 --> Model Class Initialized
INFO - 2018-02-07 20:21:06 --> Model Class Initialized
INFO - 2018-02-07 20:21:06 --> Model Class Initialized
INFO - 2018-02-07 20:21:06 --> Model Class Initialized
INFO - 2018-02-07 20:21:06 --> Model Class Initialized
INFO - 2018-02-07 20:21:06 --> Model Class Initialized
INFO - 2018-02-07 20:21:06 --> Model Class Initialized
INFO - 2018-02-07 20:21:06 --> Model Class Initialized
INFO - 2018-02-07 20:21:06 --> Model Class Initialized
INFO - 2018-02-07 20:21:06 --> Model Class Initialized
INFO - 2018-02-07 20:21:06 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 20:21:06 --> Model Class Initialized
INFO - 2018-02-07 20:21:06 --> Final output sent to browser
DEBUG - 2018-02-07 20:21:06 --> Total execution time: 0.1212
INFO - 2018-02-07 14:51:06 --> Config Class Initialized
INFO - 2018-02-07 14:51:06 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:51:06 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:51:06 --> Utf8 Class Initialized
INFO - 2018-02-07 14:51:06 --> URI Class Initialized
INFO - 2018-02-07 14:51:06 --> Router Class Initialized
INFO - 2018-02-07 14:51:06 --> Output Class Initialized
INFO - 2018-02-07 14:51:06 --> Security Class Initialized
DEBUG - 2018-02-07 14:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:51:06 --> Input Class Initialized
INFO - 2018-02-07 14:51:06 --> Language Class Initialized
INFO - 2018-02-07 14:51:06 --> Language Class Initialized
INFO - 2018-02-07 14:51:06 --> Config Class Initialized
INFO - 2018-02-07 14:51:06 --> Loader Class Initialized
INFO - 2018-02-07 20:21:06 --> Helper loaded: url_helper
INFO - 2018-02-07 20:21:06 --> Helper loaded: notification_helper
INFO - 2018-02-07 20:21:06 --> Helper loaded: settings_helper
INFO - 2018-02-07 20:21:06 --> Helper loaded: permission_helper
INFO - 2018-02-07 20:21:06 --> Helper loaded: users_helper
INFO - 2018-02-07 20:21:06 --> Database Driver Class Initialized
DEBUG - 2018-02-07 20:21:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 20:21:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 20:21:06 --> Helper loaded: form_helper
INFO - 2018-02-07 20:21:06 --> Form Validation Class Initialized
INFO - 2018-02-07 20:21:06 --> Controller Class Initialized
INFO - 2018-02-07 20:21:06 --> Model Class Initialized
INFO - 2018-02-07 20:21:06 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 20:21:06 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 20:21:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 20:21:06 --> Model Class Initialized
INFO - 2018-02-07 20:21:06 --> Model Class Initialized
INFO - 2018-02-07 20:21:06 --> Model Class Initialized
INFO - 2018-02-07 20:21:06 --> Model Class Initialized
INFO - 2018-02-07 20:21:06 --> Model Class Initialized
INFO - 2018-02-07 20:21:06 --> Model Class Initialized
INFO - 2018-02-07 20:21:06 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 20:21:06 --> Model Class Initialized
INFO - 2018-02-07 20:21:06 --> Final output sent to browser
DEBUG - 2018-02-07 20:21:06 --> Total execution time: 0.0928
INFO - 2018-02-07 14:51:08 --> Config Class Initialized
INFO - 2018-02-07 14:51:08 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:51:08 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:51:08 --> Utf8 Class Initialized
INFO - 2018-02-07 14:51:08 --> URI Class Initialized
INFO - 2018-02-07 14:51:08 --> Router Class Initialized
INFO - 2018-02-07 14:51:08 --> Output Class Initialized
INFO - 2018-02-07 14:51:08 --> Security Class Initialized
INFO - 2018-02-07 14:51:08 --> Config Class Initialized
INFO - 2018-02-07 14:51:08 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:51:08 --> Input Class Initialized
INFO - 2018-02-07 14:51:08 --> Language Class Initialized
DEBUG - 2018-02-07 14:51:08 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:51:08 --> Utf8 Class Initialized
INFO - 2018-02-07 14:51:08 --> URI Class Initialized
INFO - 2018-02-07 14:51:08 --> Router Class Initialized
INFO - 2018-02-07 14:51:08 --> Output Class Initialized
INFO - 2018-02-07 14:51:08 --> Language Class Initialized
INFO - 2018-02-07 14:51:08 --> Config Class Initialized
INFO - 2018-02-07 14:51:08 --> Loader Class Initialized
INFO - 2018-02-07 14:51:08 --> Security Class Initialized
INFO - 2018-02-07 20:21:08 --> Helper loaded: url_helper
DEBUG - 2018-02-07 14:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:51:08 --> Input Class Initialized
INFO - 2018-02-07 20:21:08 --> Helper loaded: notification_helper
INFO - 2018-02-07 20:21:08 --> Helper loaded: settings_helper
INFO - 2018-02-07 14:51:08 --> Language Class Initialized
INFO - 2018-02-07 20:21:08 --> Helper loaded: permission_helper
INFO - 2018-02-07 20:21:08 --> Helper loaded: users_helper
INFO - 2018-02-07 20:21:08 --> Database Driver Class Initialized
DEBUG - 2018-02-07 20:21:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 20:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 14:51:08 --> Language Class Initialized
INFO - 2018-02-07 14:51:08 --> Config Class Initialized
INFO - 2018-02-07 14:51:08 --> Loader Class Initialized
INFO - 2018-02-07 20:21:08 --> Helper loaded: url_helper
INFO - 2018-02-07 20:21:08 --> Helper loaded: notification_helper
INFO - 2018-02-07 20:21:08 --> Helper loaded: settings_helper
INFO - 2018-02-07 20:21:08 --> Helper loaded: permission_helper
INFO - 2018-02-07 20:21:08 --> Helper loaded: users_helper
INFO - 2018-02-07 20:21:08 --> Helper loaded: form_helper
INFO - 2018-02-07 20:21:08 --> Form Validation Class Initialized
INFO - 2018-02-07 20:21:08 --> Controller Class Initialized
INFO - 2018-02-07 20:21:08 --> Model Class Initialized
INFO - 2018-02-07 20:21:08 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 20:21:08 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 20:21:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 20:21:08 --> Model Class Initialized
INFO - 2018-02-07 20:21:08 --> Model Class Initialized
INFO - 2018-02-07 20:21:08 --> Database Driver Class Initialized
INFO - 2018-02-07 20:21:08 --> Model Class Initialized
INFO - 2018-02-07 20:21:08 --> Model Class Initialized
INFO - 2018-02-07 20:21:08 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 20:21:08 --> Final output sent to browser
DEBUG - 2018-02-07 20:21:08 --> Total execution time: 0.0919
DEBUG - 2018-02-07 20:21:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 20:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 20:21:08 --> Helper loaded: form_helper
INFO - 2018-02-07 20:21:08 --> Form Validation Class Initialized
INFO - 2018-02-07 20:21:08 --> Controller Class Initialized
INFO - 2018-02-07 20:21:08 --> Model Class Initialized
INFO - 2018-02-07 20:21:08 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 20:21:08 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 20:21:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 20:21:08 --> Model Class Initialized
INFO - 2018-02-07 20:21:08 --> Model Class Initialized
INFO - 2018-02-07 20:21:08 --> Model Class Initialized
INFO - 2018-02-07 20:21:08 --> Model Class Initialized
INFO - 2018-02-07 20:21:08 --> Model Class Initialized
INFO - 2018-02-07 20:21:08 --> Model Class Initialized
INFO - 2018-02-07 20:21:08 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 20:21:08 --> Final output sent to browser
DEBUG - 2018-02-07 20:21:08 --> Total execution time: 0.1161
INFO - 2018-02-07 14:51:10 --> Config Class Initialized
INFO - 2018-02-07 14:51:10 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:51:10 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:51:10 --> Utf8 Class Initialized
INFO - 2018-02-07 14:51:10 --> URI Class Initialized
INFO - 2018-02-07 14:51:10 --> Router Class Initialized
INFO - 2018-02-07 14:51:10 --> Output Class Initialized
INFO - 2018-02-07 14:51:10 --> Security Class Initialized
DEBUG - 2018-02-07 14:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:51:10 --> Input Class Initialized
INFO - 2018-02-07 14:51:10 --> Language Class Initialized
INFO - 2018-02-07 14:51:10 --> Language Class Initialized
INFO - 2018-02-07 14:51:10 --> Config Class Initialized
INFO - 2018-02-07 14:51:10 --> Loader Class Initialized
INFO - 2018-02-07 20:21:10 --> Helper loaded: url_helper
INFO - 2018-02-07 20:21:10 --> Helper loaded: notification_helper
INFO - 2018-02-07 20:21:10 --> Helper loaded: settings_helper
INFO - 2018-02-07 20:21:10 --> Helper loaded: permission_helper
INFO - 2018-02-07 20:21:10 --> Helper loaded: users_helper
INFO - 2018-02-07 20:21:10 --> Database Driver Class Initialized
DEBUG - 2018-02-07 20:21:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 20:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 20:21:10 --> Helper loaded: form_helper
INFO - 2018-02-07 20:21:10 --> Form Validation Class Initialized
INFO - 2018-02-07 20:21:10 --> Controller Class Initialized
INFO - 2018-02-07 20:21:10 --> Model Class Initialized
INFO - 2018-02-07 20:21:10 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 20:21:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 20:21:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 20:21:10 --> Model Class Initialized
INFO - 2018-02-07 20:21:10 --> Model Class Initialized
INFO - 2018-02-07 20:21:10 --> Model Class Initialized
INFO - 2018-02-07 20:21:10 --> Model Class Initialized
INFO - 2018-02-07 20:21:10 --> Model Class Initialized
INFO - 2018-02-07 20:21:10 --> Model Class Initialized
INFO - 2018-02-07 20:21:10 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 20:21:10 --> Model Class Initialized
INFO - 2018-02-07 20:21:10 --> Final output sent to browser
DEBUG - 2018-02-07 20:21:10 --> Total execution time: 0.1319
INFO - 2018-02-07 14:51:15 --> Config Class Initialized
INFO - 2018-02-07 14:51:15 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:51:15 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:51:15 --> Utf8 Class Initialized
INFO - 2018-02-07 14:51:15 --> URI Class Initialized
INFO - 2018-02-07 14:51:15 --> Router Class Initialized
INFO - 2018-02-07 14:51:15 --> Output Class Initialized
INFO - 2018-02-07 14:51:15 --> Security Class Initialized
DEBUG - 2018-02-07 14:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:51:15 --> Input Class Initialized
INFO - 2018-02-07 14:51:15 --> Language Class Initialized
INFO - 2018-02-07 14:51:15 --> Language Class Initialized
INFO - 2018-02-07 14:51:15 --> Config Class Initialized
INFO - 2018-02-07 14:51:15 --> Loader Class Initialized
INFO - 2018-02-07 20:21:15 --> Helper loaded: url_helper
INFO - 2018-02-07 20:21:15 --> Helper loaded: notification_helper
INFO - 2018-02-07 20:21:15 --> Helper loaded: settings_helper
INFO - 2018-02-07 20:21:15 --> Helper loaded: permission_helper
INFO - 2018-02-07 20:21:15 --> Helper loaded: users_helper
INFO - 2018-02-07 20:21:15 --> Database Driver Class Initialized
DEBUG - 2018-02-07 20:21:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 20:21:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 20:21:15 --> Helper loaded: form_helper
INFO - 2018-02-07 20:21:15 --> Form Validation Class Initialized
INFO - 2018-02-07 20:21:15 --> Controller Class Initialized
INFO - 2018-02-07 20:21:15 --> Model Class Initialized
INFO - 2018-02-07 20:21:15 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 20:21:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 20:21:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 20:21:15 --> Model Class Initialized
INFO - 2018-02-07 20:21:15 --> Model Class Initialized
INFO - 2018-02-07 20:21:15 --> Model Class Initialized
INFO - 2018-02-07 20:21:15 --> Model Class Initialized
INFO - 2018-02-07 20:21:15 --> Model Class Initialized
INFO - 2018-02-07 20:21:15 --> Model Class Initialized
INFO - 2018-02-07 20:21:15 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 20:21:15 --> Model Class Initialized
INFO - 2018-02-07 20:21:15 --> Final output sent to browser
DEBUG - 2018-02-07 20:21:15 --> Total execution time: 0.1107
INFO - 2018-02-07 14:51:25 --> Config Class Initialized
INFO - 2018-02-07 14:51:25 --> Hooks Class Initialized
DEBUG - 2018-02-07 14:51:25 --> UTF-8 Support Enabled
INFO - 2018-02-07 14:51:25 --> Utf8 Class Initialized
INFO - 2018-02-07 14:51:25 --> URI Class Initialized
INFO - 2018-02-07 14:51:25 --> Router Class Initialized
INFO - 2018-02-07 14:51:25 --> Output Class Initialized
INFO - 2018-02-07 14:51:25 --> Security Class Initialized
DEBUG - 2018-02-07 14:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-07 14:51:25 --> Input Class Initialized
INFO - 2018-02-07 14:51:25 --> Language Class Initialized
INFO - 2018-02-07 14:51:25 --> Language Class Initialized
INFO - 2018-02-07 14:51:25 --> Config Class Initialized
INFO - 2018-02-07 14:51:25 --> Loader Class Initialized
INFO - 2018-02-07 20:21:25 --> Helper loaded: url_helper
INFO - 2018-02-07 20:21:25 --> Helper loaded: notification_helper
INFO - 2018-02-07 20:21:25 --> Helper loaded: settings_helper
INFO - 2018-02-07 20:21:25 --> Helper loaded: permission_helper
INFO - 2018-02-07 20:21:25 --> Helper loaded: users_helper
INFO - 2018-02-07 20:21:25 --> Database Driver Class Initialized
DEBUG - 2018-02-07 20:21:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-07 20:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-07 20:21:25 --> Helper loaded: form_helper
INFO - 2018-02-07 20:21:25 --> Form Validation Class Initialized
INFO - 2018-02-07 20:21:25 --> Controller Class Initialized
INFO - 2018-02-07 20:21:25 --> Model Class Initialized
INFO - 2018-02-07 20:21:25 --> Helper loaded: inflector_helper
DEBUG - 2018-02-07 20:21:25 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-07 20:21:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-07 20:21:25 --> Model Class Initialized
INFO - 2018-02-07 20:21:25 --> Model Class Initialized
INFO - 2018-02-07 20:21:25 --> Model Class Initialized
INFO - 2018-02-07 20:21:25 --> Model Class Initialized
INFO - 2018-02-07 20:21:25 --> Model Class Initialized
INFO - 2018-02-07 20:21:25 --> Model Class Initialized
INFO - 2018-02-07 20:21:25 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-07 20:21:25 --> Model Class Initialized
INFO - 2018-02-07 20:21:25 --> Final output sent to browser
DEBUG - 2018-02-07 20:21:25 --> Total execution time: 0.1894
