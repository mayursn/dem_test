<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-01-30 05:37:45 --> Config Class Initialized
INFO - 2018-01-30 05:37:45 --> Hooks Class Initialized
DEBUG - 2018-01-30 05:37:45 --> UTF-8 Support Enabled
INFO - 2018-01-30 05:37:45 --> Utf8 Class Initialized
INFO - 2018-01-30 05:37:45 --> URI Class Initialized
INFO - 2018-01-30 05:37:45 --> Router Class Initialized
INFO - 2018-01-30 05:37:45 --> Output Class Initialized
INFO - 2018-01-30 05:37:45 --> Security Class Initialized
DEBUG - 2018-01-30 05:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-30 05:37:45 --> Input Class Initialized
INFO - 2018-01-30 05:37:45 --> Language Class Initialized
INFO - 2018-01-30 05:37:45 --> Language Class Initialized
INFO - 2018-01-30 05:37:45 --> Config Class Initialized
INFO - 2018-01-30 05:37:45 --> Loader Class Initialized
INFO - 2018-01-30 11:07:45 --> Helper loaded: url_helper
INFO - 2018-01-30 11:07:45 --> Helper loaded: notification_helper
INFO - 2018-01-30 11:07:45 --> Helper loaded: settings_helper
INFO - 2018-01-30 11:07:45 --> Helper loaded: permission_helper
INFO - 2018-01-30 11:07:45 --> Helper loaded: users_helper
INFO - 2018-01-30 11:07:45 --> Database Driver Class Initialized
DEBUG - 2018-01-30 11:07:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-30 11:07:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-30 11:07:45 --> Helper loaded: form_helper
INFO - 2018-01-30 11:07:45 --> Form Validation Class Initialized
INFO - 2018-01-30 11:07:45 --> Controller Class Initialized
DEBUG - 2018-01-30 11:07:45 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-01-30 11:07:45 --> Final output sent to browser
DEBUG - 2018-01-30 11:07:45 --> Total execution time: 0.1986
INFO - 2018-01-30 13:40:32 --> Config Class Initialized
INFO - 2018-01-30 13:40:32 --> Hooks Class Initialized
DEBUG - 2018-01-30 13:40:32 --> UTF-8 Support Enabled
INFO - 2018-01-30 13:40:32 --> Utf8 Class Initialized
INFO - 2018-01-30 13:40:32 --> URI Class Initialized
DEBUG - 2018-01-30 13:40:32 --> No URI present. Default controller set.
INFO - 2018-01-30 13:40:32 --> Router Class Initialized
INFO - 2018-01-30 13:40:32 --> Output Class Initialized
INFO - 2018-01-30 13:40:32 --> Security Class Initialized
DEBUG - 2018-01-30 13:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-30 13:40:32 --> Input Class Initialized
INFO - 2018-01-30 13:40:32 --> Language Class Initialized
INFO - 2018-01-30 13:40:32 --> Language Class Initialized
INFO - 2018-01-30 13:40:32 --> Config Class Initialized
INFO - 2018-01-30 13:40:32 --> Loader Class Initialized
INFO - 2018-01-30 19:10:32 --> Helper loaded: url_helper
INFO - 2018-01-30 19:10:33 --> Helper loaded: notification_helper
INFO - 2018-01-30 19:10:33 --> Helper loaded: settings_helper
INFO - 2018-01-30 19:10:33 --> Helper loaded: permission_helper
INFO - 2018-01-30 19:10:33 --> Helper loaded: users_helper
INFO - 2018-01-30 19:10:33 --> Database Driver Class Initialized
DEBUG - 2018-01-30 19:10:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-30 19:10:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-30 19:10:33 --> Helper loaded: form_helper
INFO - 2018-01-30 19:10:33 --> Form Validation Class Initialized
INFO - 2018-01-30 19:10:33 --> Controller Class Initialized
INFO - 2018-01-30 19:10:33 --> Model Class Initialized
INFO - 2018-01-30 19:10:33 --> Helper loaded: inflector_helper
INFO - 2018-01-30 19:10:33 --> Model Class Initialized
DEBUG - 2018-01-30 19:10:33 --> File loaded: /home/pr01004/public_html/application/views/login.php
INFO - 2018-01-30 19:10:33 --> Final output sent to browser
DEBUG - 2018-01-30 19:10:33 --> Total execution time: 0.5163
INFO - 2018-01-30 13:40:38 --> Config Class Initialized
INFO - 2018-01-30 13:40:38 --> Hooks Class Initialized
DEBUG - 2018-01-30 13:40:38 --> UTF-8 Support Enabled
INFO - 2018-01-30 13:40:38 --> Utf8 Class Initialized
INFO - 2018-01-30 13:40:38 --> URI Class Initialized
INFO - 2018-01-30 13:40:38 --> Router Class Initialized
INFO - 2018-01-30 13:40:38 --> Output Class Initialized
INFO - 2018-01-30 13:40:38 --> Security Class Initialized
DEBUG - 2018-01-30 13:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-30 13:40:38 --> Input Class Initialized
INFO - 2018-01-30 13:40:38 --> Language Class Initialized
INFO - 2018-01-30 13:40:38 --> Language Class Initialized
INFO - 2018-01-30 13:40:38 --> Config Class Initialized
INFO - 2018-01-30 13:40:38 --> Loader Class Initialized
INFO - 2018-01-30 19:10:38 --> Helper loaded: url_helper
INFO - 2018-01-30 19:10:38 --> Helper loaded: notification_helper
INFO - 2018-01-30 19:10:38 --> Helper loaded: settings_helper
INFO - 2018-01-30 19:10:38 --> Helper loaded: permission_helper
INFO - 2018-01-30 19:10:38 --> Helper loaded: users_helper
INFO - 2018-01-30 19:10:38 --> Database Driver Class Initialized
DEBUG - 2018-01-30 19:10:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-30 19:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-30 19:10:38 --> Helper loaded: form_helper
INFO - 2018-01-30 19:10:38 --> Form Validation Class Initialized
INFO - 2018-01-30 19:10:38 --> Controller Class Initialized
INFO - 2018-01-30 19:10:38 --> Model Class Initialized
INFO - 2018-01-30 19:10:38 --> Helper loaded: inflector_helper
INFO - 2018-01-30 19:10:38 --> Model Class Initialized
INFO - 2018-01-30 19:10:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-01-30 13:40:38 --> Config Class Initialized
INFO - 2018-01-30 13:40:38 --> Hooks Class Initialized
DEBUG - 2018-01-30 13:40:38 --> UTF-8 Support Enabled
INFO - 2018-01-30 13:40:38 --> Utf8 Class Initialized
INFO - 2018-01-30 13:40:38 --> URI Class Initialized
INFO - 2018-01-30 13:40:38 --> Router Class Initialized
INFO - 2018-01-30 13:40:38 --> Output Class Initialized
INFO - 2018-01-30 13:40:38 --> Security Class Initialized
DEBUG - 2018-01-30 13:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-30 13:40:38 --> Input Class Initialized
INFO - 2018-01-30 13:40:38 --> Language Class Initialized
INFO - 2018-01-30 13:40:38 --> Config Class Initialized
INFO - 2018-01-30 13:40:38 --> Hooks Class Initialized
DEBUG - 2018-01-30 13:40:38 --> UTF-8 Support Enabled
INFO - 2018-01-30 13:40:38 --> Utf8 Class Initialized
INFO - 2018-01-30 13:40:38 --> URI Class Initialized
INFO - 2018-01-30 13:40:38 --> Router Class Initialized
INFO - 2018-01-30 13:40:38 --> Output Class Initialized
INFO - 2018-01-30 13:40:38 --> Security Class Initialized
DEBUG - 2018-01-30 13:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-30 13:40:38 --> Input Class Initialized
INFO - 2018-01-30 13:40:38 --> Language Class Initialized
INFO - 2018-01-30 13:40:38 --> Language Class Initialized
INFO - 2018-01-30 13:40:38 --> Config Class Initialized
INFO - 2018-01-30 13:40:38 --> Loader Class Initialized
INFO - 2018-01-30 19:10:39 --> Helper loaded: url_helper
INFO - 2018-01-30 19:10:39 --> Helper loaded: notification_helper
INFO - 2018-01-30 19:10:39 --> Helper loaded: settings_helper
INFO - 2018-01-30 19:10:39 --> Helper loaded: permission_helper
INFO - 2018-01-30 19:10:39 --> Helper loaded: users_helper
INFO - 2018-01-30 13:40:39 --> Language Class Initialized
INFO - 2018-01-30 13:40:39 --> Config Class Initialized
INFO - 2018-01-30 13:40:39 --> Loader Class Initialized
INFO - 2018-01-30 19:10:39 --> Helper loaded: url_helper
INFO - 2018-01-30 19:10:39 --> Helper loaded: notification_helper
INFO - 2018-01-30 19:10:39 --> Database Driver Class Initialized
INFO - 2018-01-30 19:10:39 --> Helper loaded: settings_helper
INFO - 2018-01-30 19:10:39 --> Helper loaded: permission_helper
DEBUG - 2018-01-30 19:10:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-30 19:10:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-30 19:10:39 --> Helper loaded: users_helper
INFO - 2018-01-30 19:10:39 --> Helper loaded: form_helper
INFO - 2018-01-30 19:10:39 --> Form Validation Class Initialized
INFO - 2018-01-30 19:10:39 --> Controller Class Initialized
DEBUG - 2018-01-30 19:10:39 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-01-30 19:10:39 --> Final output sent to browser
DEBUG - 2018-01-30 19:10:39 --> Total execution time: 0.3057
INFO - 2018-01-30 19:10:39 --> Database Driver Class Initialized
DEBUG - 2018-01-30 19:10:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-30 19:10:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-30 19:10:39 --> Helper loaded: form_helper
INFO - 2018-01-30 19:10:39 --> Form Validation Class Initialized
INFO - 2018-01-30 19:10:39 --> Controller Class Initialized
INFO - 2018-01-30 19:10:39 --> Model Class Initialized
INFO - 2018-01-30 19:10:39 --> Helper loaded: inflector_helper
INFO - 2018-01-30 19:10:39 --> Model Class Initialized
INFO - 2018-01-30 19:10:39 --> Model Class Initialized
INFO - 2018-01-30 19:10:39 --> Model Class Initialized
INFO - 2018-01-30 19:10:39 --> Model Class Initialized
INFO - 2018-01-30 19:10:39 --> Model Class Initialized
DEBUG - 2018-01-30 19:10:39 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-01-30 19:10:39 --> File loaded: /home/pr01004/public_html/application/views/admin/dashboard.php
DEBUG - 2018-01-30 19:10:39 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-01-30 19:10:39 --> Final output sent to browser
DEBUG - 2018-01-30 19:10:39 --> Total execution time: 0.4367
INFO - 2018-01-30 13:40:45 --> Config Class Initialized
INFO - 2018-01-30 13:40:45 --> Hooks Class Initialized
DEBUG - 2018-01-30 13:40:45 --> UTF-8 Support Enabled
INFO - 2018-01-30 13:40:45 --> Utf8 Class Initialized
INFO - 2018-01-30 13:40:45 --> URI Class Initialized
INFO - 2018-01-30 13:40:45 --> Router Class Initialized
INFO - 2018-01-30 13:40:45 --> Output Class Initialized
INFO - 2018-01-30 13:40:45 --> Security Class Initialized
DEBUG - 2018-01-30 13:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-30 13:40:45 --> Input Class Initialized
INFO - 2018-01-30 13:40:45 --> Language Class Initialized
INFO - 2018-01-30 13:40:45 --> Language Class Initialized
INFO - 2018-01-30 13:40:45 --> Config Class Initialized
INFO - 2018-01-30 13:40:45 --> Loader Class Initialized
INFO - 2018-01-30 19:10:45 --> Helper loaded: url_helper
INFO - 2018-01-30 19:10:45 --> Helper loaded: notification_helper
INFO - 2018-01-30 19:10:45 --> Helper loaded: settings_helper
INFO - 2018-01-30 19:10:45 --> Helper loaded: permission_helper
INFO - 2018-01-30 19:10:45 --> Helper loaded: users_helper
INFO - 2018-01-30 19:10:45 --> Database Driver Class Initialized
DEBUG - 2018-01-30 19:10:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-30 19:10:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-30 19:10:45 --> Helper loaded: form_helper
INFO - 2018-01-30 19:10:45 --> Form Validation Class Initialized
INFO - 2018-01-30 19:10:45 --> Controller Class Initialized
INFO - 2018-01-30 19:10:45 --> Model Class Initialized
INFO - 2018-01-30 19:10:45 --> Helper loaded: inflector_helper
INFO - 2018-01-30 19:10:45 --> Model Class Initialized
INFO - 2018-01-30 19:10:45 --> Model Class Initialized
DEBUG - 2018-01-30 19:10:45 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-01-30 19:10:45 --> File loaded: /home/pr01004/public_html/application/views/cmspages/cmspages.php
DEBUG - 2018-01-30 19:10:45 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-01-30 19:10:45 --> Final output sent to browser
DEBUG - 2018-01-30 19:10:45 --> Total execution time: 0.1312
INFO - 2018-01-30 13:40:48 --> Config Class Initialized
INFO - 2018-01-30 13:40:48 --> Hooks Class Initialized
DEBUG - 2018-01-30 13:40:48 --> UTF-8 Support Enabled
INFO - 2018-01-30 13:40:48 --> Utf8 Class Initialized
INFO - 2018-01-30 13:40:48 --> URI Class Initialized
INFO - 2018-01-30 13:40:48 --> Router Class Initialized
INFO - 2018-01-30 13:40:48 --> Output Class Initialized
INFO - 2018-01-30 13:40:48 --> Security Class Initialized
DEBUG - 2018-01-30 13:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-30 13:40:48 --> Input Class Initialized
INFO - 2018-01-30 13:40:48 --> Language Class Initialized
INFO - 2018-01-30 13:40:48 --> Language Class Initialized
INFO - 2018-01-30 13:40:48 --> Config Class Initialized
INFO - 2018-01-30 13:40:48 --> Loader Class Initialized
INFO - 2018-01-30 19:10:48 --> Helper loaded: url_helper
INFO - 2018-01-30 19:10:48 --> Helper loaded: notification_helper
INFO - 2018-01-30 19:10:48 --> Helper loaded: settings_helper
INFO - 2018-01-30 19:10:48 --> Helper loaded: permission_helper
INFO - 2018-01-30 19:10:48 --> Helper loaded: users_helper
INFO - 2018-01-30 19:10:48 --> Database Driver Class Initialized
DEBUG - 2018-01-30 19:10:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-30 19:10:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-30 19:10:48 --> Helper loaded: form_helper
INFO - 2018-01-30 19:10:48 --> Form Validation Class Initialized
INFO - 2018-01-30 19:10:48 --> Controller Class Initialized
INFO - 2018-01-30 19:10:48 --> Model Class Initialized
INFO - 2018-01-30 19:10:48 --> Helper loaded: inflector_helper
INFO - 2018-01-30 19:10:48 --> Model Class Initialized
INFO - 2018-01-30 19:10:48 --> Model Class Initialized
DEBUG - 2018-01-30 19:10:48 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-01-30 19:10:48 --> File loaded: /home/pr01004/public_html/application/views/cmspages/edit.php
DEBUG - 2018-01-30 19:10:48 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-01-30 19:10:48 --> Final output sent to browser
DEBUG - 2018-01-30 19:10:48 --> Total execution time: 0.1088
INFO - 2018-01-30 13:40:57 --> Config Class Initialized
INFO - 2018-01-30 13:40:57 --> Hooks Class Initialized
DEBUG - 2018-01-30 13:40:57 --> UTF-8 Support Enabled
INFO - 2018-01-30 13:40:57 --> Utf8 Class Initialized
INFO - 2018-01-30 13:40:57 --> URI Class Initialized
INFO - 2018-01-30 13:40:57 --> Router Class Initialized
INFO - 2018-01-30 13:40:57 --> Output Class Initialized
INFO - 2018-01-30 13:40:57 --> Security Class Initialized
DEBUG - 2018-01-30 13:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-30 13:40:57 --> Input Class Initialized
INFO - 2018-01-30 13:40:57 --> Language Class Initialized
INFO - 2018-01-30 13:40:57 --> Language Class Initialized
INFO - 2018-01-30 13:40:57 --> Config Class Initialized
INFO - 2018-01-30 13:40:57 --> Loader Class Initialized
INFO - 2018-01-30 19:10:57 --> Helper loaded: url_helper
INFO - 2018-01-30 19:10:57 --> Helper loaded: notification_helper
INFO - 2018-01-30 19:10:57 --> Helper loaded: settings_helper
INFO - 2018-01-30 19:10:57 --> Helper loaded: permission_helper
INFO - 2018-01-30 19:10:57 --> Helper loaded: users_helper
INFO - 2018-01-30 19:10:57 --> Database Driver Class Initialized
DEBUG - 2018-01-30 19:10:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-30 19:10:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-30 19:10:57 --> Helper loaded: form_helper
INFO - 2018-01-30 19:10:57 --> Form Validation Class Initialized
INFO - 2018-01-30 19:10:57 --> Controller Class Initialized
INFO - 2018-01-30 19:10:57 --> Model Class Initialized
INFO - 2018-01-30 19:10:57 --> Helper loaded: inflector_helper
INFO - 2018-01-30 19:10:57 --> Model Class Initialized
INFO - 2018-01-30 19:10:57 --> Model Class Initialized
INFO - 2018-01-30 19:10:57 --> Model Class Initialized
DEBUG - 2018-01-30 19:10:57 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-01-30 19:10:57 --> File loaded: /home/pr01004/public_html/application/views/preference/index.php
DEBUG - 2018-01-30 19:10:57 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-01-30 19:10:57 --> Final output sent to browser
DEBUG - 2018-01-30 19:10:57 --> Total execution time: 0.1503
INFO - 2018-01-30 13:40:59 --> Config Class Initialized
INFO - 2018-01-30 13:40:59 --> Hooks Class Initialized
DEBUG - 2018-01-30 13:40:59 --> UTF-8 Support Enabled
INFO - 2018-01-30 13:40:59 --> Utf8 Class Initialized
INFO - 2018-01-30 13:40:59 --> URI Class Initialized
INFO - 2018-01-30 13:40:59 --> Router Class Initialized
INFO - 2018-01-30 13:40:59 --> Output Class Initialized
INFO - 2018-01-30 13:40:59 --> Security Class Initialized
DEBUG - 2018-01-30 13:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-30 13:40:59 --> Input Class Initialized
INFO - 2018-01-30 13:40:59 --> Language Class Initialized
INFO - 2018-01-30 13:40:59 --> Language Class Initialized
INFO - 2018-01-30 13:40:59 --> Config Class Initialized
INFO - 2018-01-30 13:40:59 --> Loader Class Initialized
INFO - 2018-01-30 19:10:59 --> Helper loaded: url_helper
INFO - 2018-01-30 19:10:59 --> Helper loaded: notification_helper
INFO - 2018-01-30 19:10:59 --> Helper loaded: settings_helper
INFO - 2018-01-30 19:10:59 --> Helper loaded: permission_helper
INFO - 2018-01-30 19:10:59 --> Helper loaded: users_helper
INFO - 2018-01-30 19:10:59 --> Database Driver Class Initialized
DEBUG - 2018-01-30 19:10:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-30 19:10:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-30 19:10:59 --> Helper loaded: form_helper
INFO - 2018-01-30 19:10:59 --> Form Validation Class Initialized
INFO - 2018-01-30 19:10:59 --> Controller Class Initialized
INFO - 2018-01-30 19:10:59 --> Model Class Initialized
INFO - 2018-01-30 19:10:59 --> Helper loaded: inflector_helper
INFO - 2018-01-30 19:10:59 --> Model Class Initialized
INFO - 2018-01-30 19:10:59 --> Model Class Initialized
INFO - 2018-01-30 19:10:59 --> Model Class Initialized
DEBUG - 2018-01-30 19:10:59 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-01-30 19:10:59 --> File loaded: /home/pr01004/public_html/application/views/preference/create.php
DEBUG - 2018-01-30 19:10:59 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-01-30 19:10:59 --> Final output sent to browser
DEBUG - 2018-01-30 19:10:59 --> Total execution time: 0.1145
INFO - 2018-01-30 13:41:14 --> Config Class Initialized
INFO - 2018-01-30 13:41:14 --> Hooks Class Initialized
DEBUG - 2018-01-30 13:41:14 --> UTF-8 Support Enabled
INFO - 2018-01-30 13:41:14 --> Utf8 Class Initialized
INFO - 2018-01-30 13:41:14 --> URI Class Initialized
INFO - 2018-01-30 13:41:14 --> Router Class Initialized
INFO - 2018-01-30 13:41:14 --> Output Class Initialized
INFO - 2018-01-30 13:41:14 --> Security Class Initialized
DEBUG - 2018-01-30 13:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-30 13:41:14 --> Input Class Initialized
INFO - 2018-01-30 13:41:14 --> Language Class Initialized
INFO - 2018-01-30 13:41:14 --> Language Class Initialized
INFO - 2018-01-30 13:41:14 --> Config Class Initialized
INFO - 2018-01-30 13:41:14 --> Loader Class Initialized
INFO - 2018-01-30 19:11:14 --> Helper loaded: url_helper
INFO - 2018-01-30 19:11:14 --> Helper loaded: notification_helper
INFO - 2018-01-30 19:11:14 --> Helper loaded: settings_helper
INFO - 2018-01-30 19:11:14 --> Helper loaded: permission_helper
INFO - 2018-01-30 19:11:14 --> Helper loaded: users_helper
INFO - 2018-01-30 19:11:14 --> Database Driver Class Initialized
DEBUG - 2018-01-30 19:11:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-30 19:11:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-30 19:11:14 --> Helper loaded: form_helper
INFO - 2018-01-30 19:11:14 --> Form Validation Class Initialized
INFO - 2018-01-30 19:11:14 --> Controller Class Initialized
INFO - 2018-01-30 19:11:14 --> Model Class Initialized
INFO - 2018-01-30 19:11:14 --> Helper loaded: inflector_helper
INFO - 2018-01-30 19:11:14 --> Model Class Initialized
INFO - 2018-01-30 19:11:14 --> Model Class Initialized
INFO - 2018-01-30 19:11:14 --> Model Class Initialized
DEBUG - 2018-01-30 19:11:14 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-01-30 19:11:14 --> File loaded: /home/pr01004/public_html/application/views/admin/notifications.php
DEBUG - 2018-01-30 19:11:14 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-01-30 19:11:14 --> Final output sent to browser
DEBUG - 2018-01-30 19:11:14 --> Total execution time: 0.1257
INFO - 2018-01-30 13:41:22 --> Config Class Initialized
INFO - 2018-01-30 13:41:22 --> Hooks Class Initialized
DEBUG - 2018-01-30 13:41:22 --> UTF-8 Support Enabled
INFO - 2018-01-30 13:41:22 --> Utf8 Class Initialized
INFO - 2018-01-30 13:41:22 --> URI Class Initialized
INFO - 2018-01-30 13:41:22 --> Router Class Initialized
INFO - 2018-01-30 13:41:22 --> Output Class Initialized
INFO - 2018-01-30 13:41:22 --> Security Class Initialized
DEBUG - 2018-01-30 13:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-30 13:41:22 --> Input Class Initialized
INFO - 2018-01-30 13:41:22 --> Language Class Initialized
INFO - 2018-01-30 13:41:22 --> Language Class Initialized
INFO - 2018-01-30 13:41:22 --> Config Class Initialized
INFO - 2018-01-30 13:41:22 --> Loader Class Initialized
INFO - 2018-01-30 19:11:22 --> Helper loaded: url_helper
INFO - 2018-01-30 19:11:22 --> Helper loaded: notification_helper
INFO - 2018-01-30 19:11:22 --> Helper loaded: settings_helper
INFO - 2018-01-30 19:11:22 --> Helper loaded: permission_helper
INFO - 2018-01-30 19:11:22 --> Helper loaded: users_helper
INFO - 2018-01-30 19:11:22 --> Database Driver Class Initialized
DEBUG - 2018-01-30 19:11:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-30 19:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-30 19:11:22 --> Helper loaded: form_helper
INFO - 2018-01-30 19:11:22 --> Form Validation Class Initialized
INFO - 2018-01-30 19:11:22 --> Controller Class Initialized
INFO - 2018-01-30 19:11:22 --> Model Class Initialized
INFO - 2018-01-30 19:11:22 --> Helper loaded: inflector_helper
INFO - 2018-01-30 19:11:22 --> Model Class Initialized
INFO - 2018-01-30 19:11:22 --> Model Class Initialized
INFO - 2018-01-30 19:11:22 --> Model Class Initialized
ERROR - 2018-01-30 19:11:22 --> Severity: error --> Exception: [] operator not supported for strings /home/pr01004/public_html/application/controllers/Notification.php 82
INFO - 2018-01-30 13:43:07 --> Config Class Initialized
INFO - 2018-01-30 13:43:07 --> Hooks Class Initialized
DEBUG - 2018-01-30 13:43:07 --> UTF-8 Support Enabled
INFO - 2018-01-30 13:43:07 --> Utf8 Class Initialized
INFO - 2018-01-30 13:43:07 --> URI Class Initialized
INFO - 2018-01-30 13:43:07 --> Router Class Initialized
INFO - 2018-01-30 13:43:07 --> Output Class Initialized
INFO - 2018-01-30 13:43:07 --> Security Class Initialized
DEBUG - 2018-01-30 13:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-30 13:43:07 --> Input Class Initialized
INFO - 2018-01-30 13:43:07 --> Language Class Initialized
INFO - 2018-01-30 13:43:07 --> Language Class Initialized
INFO - 2018-01-30 13:43:07 --> Config Class Initialized
INFO - 2018-01-30 13:43:07 --> Loader Class Initialized
INFO - 2018-01-30 19:13:07 --> Helper loaded: url_helper
INFO - 2018-01-30 19:13:07 --> Helper loaded: notification_helper
INFO - 2018-01-30 19:13:07 --> Helper loaded: settings_helper
INFO - 2018-01-30 19:13:07 --> Helper loaded: permission_helper
INFO - 2018-01-30 19:13:07 --> Helper loaded: users_helper
INFO - 2018-01-30 19:13:07 --> Database Driver Class Initialized
DEBUG - 2018-01-30 19:13:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-30 19:13:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-30 19:13:07 --> Helper loaded: form_helper
INFO - 2018-01-30 19:13:07 --> Form Validation Class Initialized
INFO - 2018-01-30 19:13:07 --> Controller Class Initialized
INFO - 2018-01-30 19:13:07 --> Model Class Initialized
INFO - 2018-01-30 19:13:07 --> Helper loaded: inflector_helper
INFO - 2018-01-30 19:13:07 --> Model Class Initialized
INFO - 2018-01-30 19:13:07 --> Model Class Initialized
INFO - 2018-01-30 19:13:07 --> Model Class Initialized
INFO - 2018-01-30 19:13:07 --> Final output sent to browser
DEBUG - 2018-01-30 19:13:07 --> Total execution time: 0.0955
INFO - 2018-01-30 13:43:08 --> Config Class Initialized
INFO - 2018-01-30 13:43:08 --> Hooks Class Initialized
DEBUG - 2018-01-30 13:43:08 --> UTF-8 Support Enabled
INFO - 2018-01-30 13:43:08 --> Utf8 Class Initialized
INFO - 2018-01-30 13:43:08 --> URI Class Initialized
INFO - 2018-01-30 13:43:08 --> Router Class Initialized
INFO - 2018-01-30 13:43:08 --> Output Class Initialized
INFO - 2018-01-30 13:43:08 --> Security Class Initialized
DEBUG - 2018-01-30 13:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-30 13:43:08 --> Input Class Initialized
INFO - 2018-01-30 13:43:08 --> Language Class Initialized
INFO - 2018-01-30 13:43:08 --> Language Class Initialized
INFO - 2018-01-30 13:43:08 --> Config Class Initialized
INFO - 2018-01-30 13:43:08 --> Loader Class Initialized
INFO - 2018-01-30 19:13:08 --> Helper loaded: url_helper
INFO - 2018-01-30 19:13:08 --> Helper loaded: notification_helper
INFO - 2018-01-30 19:13:08 --> Helper loaded: settings_helper
INFO - 2018-01-30 19:13:08 --> Helper loaded: permission_helper
INFO - 2018-01-30 19:13:08 --> Helper loaded: users_helper
INFO - 2018-01-30 19:13:08 --> Database Driver Class Initialized
DEBUG - 2018-01-30 19:13:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-30 19:13:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-30 19:13:08 --> Helper loaded: form_helper
INFO - 2018-01-30 19:13:08 --> Form Validation Class Initialized
INFO - 2018-01-30 19:13:08 --> Controller Class Initialized
DEBUG - 2018-01-30 19:13:08 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-01-30 19:13:08 --> Final output sent to browser
DEBUG - 2018-01-30 19:13:08 --> Total execution time: 0.0702
INFO - 2018-01-30 13:43:44 --> Config Class Initialized
INFO - 2018-01-30 13:43:44 --> Hooks Class Initialized
DEBUG - 2018-01-30 13:43:44 --> UTF-8 Support Enabled
INFO - 2018-01-30 13:43:44 --> Utf8 Class Initialized
INFO - 2018-01-30 13:43:44 --> URI Class Initialized
INFO - 2018-01-30 13:43:44 --> Router Class Initialized
INFO - 2018-01-30 13:43:44 --> Output Class Initialized
INFO - 2018-01-30 13:43:44 --> Security Class Initialized
DEBUG - 2018-01-30 13:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-30 13:43:44 --> Input Class Initialized
INFO - 2018-01-30 13:43:44 --> Language Class Initialized
INFO - 2018-01-30 13:43:44 --> Language Class Initialized
INFO - 2018-01-30 13:43:44 --> Config Class Initialized
INFO - 2018-01-30 13:43:44 --> Loader Class Initialized
INFO - 2018-01-30 19:13:44 --> Helper loaded: url_helper
INFO - 2018-01-30 19:13:44 --> Helper loaded: notification_helper
INFO - 2018-01-30 19:13:44 --> Helper loaded: settings_helper
INFO - 2018-01-30 19:13:44 --> Helper loaded: permission_helper
INFO - 2018-01-30 19:13:44 --> Helper loaded: users_helper
INFO - 2018-01-30 19:13:44 --> Database Driver Class Initialized
DEBUG - 2018-01-30 19:13:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-30 19:13:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-30 19:13:44 --> Helper loaded: form_helper
INFO - 2018-01-30 19:13:44 --> Form Validation Class Initialized
INFO - 2018-01-30 19:13:44 --> Controller Class Initialized
INFO - 2018-01-30 19:13:44 --> Model Class Initialized
INFO - 2018-01-30 19:13:44 --> Helper loaded: inflector_helper
INFO - 2018-01-30 19:13:44 --> Model Class Initialized
INFO - 2018-01-30 19:13:44 --> Model Class Initialized
INFO - 2018-01-30 19:13:44 --> Model Class Initialized
INFO - 2018-01-30 19:13:44 --> Final output sent to browser
DEBUG - 2018-01-30 19:13:44 --> Total execution time: 0.0897
INFO - 2018-01-30 13:44:57 --> Config Class Initialized
INFO - 2018-01-30 13:44:57 --> Hooks Class Initialized
DEBUG - 2018-01-30 13:44:57 --> UTF-8 Support Enabled
INFO - 2018-01-30 13:44:57 --> Utf8 Class Initialized
INFO - 2018-01-30 13:44:57 --> URI Class Initialized
INFO - 2018-01-30 13:44:57 --> Router Class Initialized
INFO - 2018-01-30 13:44:57 --> Output Class Initialized
INFO - 2018-01-30 13:44:57 --> Security Class Initialized
DEBUG - 2018-01-30 13:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-30 13:44:57 --> Input Class Initialized
INFO - 2018-01-30 13:44:57 --> Language Class Initialized
INFO - 2018-01-30 13:44:57 --> Language Class Initialized
INFO - 2018-01-30 13:44:57 --> Config Class Initialized
INFO - 2018-01-30 13:44:57 --> Loader Class Initialized
INFO - 2018-01-30 19:14:57 --> Helper loaded: url_helper
INFO - 2018-01-30 19:14:57 --> Helper loaded: notification_helper
INFO - 2018-01-30 19:14:57 --> Helper loaded: settings_helper
INFO - 2018-01-30 19:14:57 --> Helper loaded: permission_helper
INFO - 2018-01-30 19:14:57 --> Helper loaded: users_helper
INFO - 2018-01-30 19:14:57 --> Database Driver Class Initialized
DEBUG - 2018-01-30 19:14:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-30 19:14:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-30 19:14:57 --> Helper loaded: form_helper
INFO - 2018-01-30 19:14:57 --> Form Validation Class Initialized
INFO - 2018-01-30 19:14:57 --> Controller Class Initialized
INFO - 2018-01-30 19:14:57 --> Model Class Initialized
INFO - 2018-01-30 19:14:57 --> Helper loaded: inflector_helper
INFO - 2018-01-30 19:14:57 --> Model Class Initialized
INFO - 2018-01-30 19:14:57 --> Model Class Initialized
INFO - 2018-01-30 19:14:57 --> Model Class Initialized
INFO - 2018-01-30 19:14:57 --> Final output sent to browser
DEBUG - 2018-01-30 19:14:57 --> Total execution time: 0.0629
INFO - 2018-01-30 13:44:58 --> Config Class Initialized
INFO - 2018-01-30 13:44:58 --> Hooks Class Initialized
DEBUG - 2018-01-30 13:44:58 --> UTF-8 Support Enabled
INFO - 2018-01-30 13:44:58 --> Utf8 Class Initialized
INFO - 2018-01-30 13:44:58 --> URI Class Initialized
INFO - 2018-01-30 13:44:58 --> Router Class Initialized
INFO - 2018-01-30 13:44:58 --> Output Class Initialized
INFO - 2018-01-30 13:44:58 --> Security Class Initialized
DEBUG - 2018-01-30 13:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-30 13:44:58 --> Input Class Initialized
INFO - 2018-01-30 13:44:58 --> Language Class Initialized
INFO - 2018-01-30 13:44:58 --> Language Class Initialized
INFO - 2018-01-30 13:44:58 --> Config Class Initialized
INFO - 2018-01-30 13:44:58 --> Loader Class Initialized
INFO - 2018-01-30 19:14:58 --> Helper loaded: url_helper
INFO - 2018-01-30 19:14:58 --> Helper loaded: notification_helper
INFO - 2018-01-30 19:14:58 --> Helper loaded: settings_helper
INFO - 2018-01-30 19:14:58 --> Helper loaded: permission_helper
INFO - 2018-01-30 19:14:58 --> Helper loaded: users_helper
INFO - 2018-01-30 19:14:58 --> Database Driver Class Initialized
DEBUG - 2018-01-30 19:14:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-30 19:14:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-30 19:14:58 --> Helper loaded: form_helper
INFO - 2018-01-30 19:14:58 --> Form Validation Class Initialized
INFO - 2018-01-30 19:14:58 --> Controller Class Initialized
DEBUG - 2018-01-30 19:14:58 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-01-30 19:14:58 --> Final output sent to browser
DEBUG - 2018-01-30 19:14:58 --> Total execution time: 0.0739
INFO - 2018-01-30 13:45:00 --> Config Class Initialized
INFO - 2018-01-30 13:45:00 --> Hooks Class Initialized
DEBUG - 2018-01-30 13:45:00 --> UTF-8 Support Enabled
INFO - 2018-01-30 13:45:00 --> Utf8 Class Initialized
INFO - 2018-01-30 13:45:00 --> URI Class Initialized
DEBUG - 2018-01-30 13:45:00 --> No URI present. Default controller set.
INFO - 2018-01-30 13:45:00 --> Router Class Initialized
INFO - 2018-01-30 13:45:00 --> Output Class Initialized
INFO - 2018-01-30 13:45:00 --> Security Class Initialized
DEBUG - 2018-01-30 13:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-30 13:45:00 --> Input Class Initialized
INFO - 2018-01-30 13:45:00 --> Language Class Initialized
INFO - 2018-01-30 13:45:00 --> Language Class Initialized
INFO - 2018-01-30 13:45:00 --> Config Class Initialized
INFO - 2018-01-30 13:45:00 --> Loader Class Initialized
INFO - 2018-01-30 19:15:00 --> Helper loaded: url_helper
INFO - 2018-01-30 19:15:00 --> Helper loaded: notification_helper
INFO - 2018-01-30 19:15:00 --> Helper loaded: settings_helper
INFO - 2018-01-30 19:15:00 --> Helper loaded: permission_helper
INFO - 2018-01-30 19:15:00 --> Helper loaded: users_helper
INFO - 2018-01-30 19:15:00 --> Database Driver Class Initialized
DEBUG - 2018-01-30 19:15:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-30 19:15:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-30 19:15:00 --> Helper loaded: form_helper
INFO - 2018-01-30 19:15:00 --> Form Validation Class Initialized
INFO - 2018-01-30 19:15:00 --> Controller Class Initialized
INFO - 2018-01-30 19:15:01 --> Model Class Initialized
INFO - 2018-01-30 19:15:01 --> Helper loaded: inflector_helper
INFO - 2018-01-30 19:15:01 --> Model Class Initialized
INFO - 2018-01-30 19:15:01 --> Model Class Initialized
INFO - 2018-01-30 13:45:01 --> Config Class Initialized
INFO - 2018-01-30 13:45:01 --> Hooks Class Initialized
DEBUG - 2018-01-30 13:45:01 --> UTF-8 Support Enabled
INFO - 2018-01-30 13:45:01 --> Utf8 Class Initialized
INFO - 2018-01-30 13:45:01 --> URI Class Initialized
INFO - 2018-01-30 13:45:01 --> Router Class Initialized
INFO - 2018-01-30 13:45:01 --> Output Class Initialized
INFO - 2018-01-30 13:45:01 --> Security Class Initialized
DEBUG - 2018-01-30 13:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-30 13:45:01 --> Input Class Initialized
INFO - 2018-01-30 13:45:01 --> Language Class Initialized
INFO - 2018-01-30 13:45:01 --> Language Class Initialized
INFO - 2018-01-30 13:45:01 --> Config Class Initialized
INFO - 2018-01-30 13:45:01 --> Loader Class Initialized
INFO - 2018-01-30 19:15:01 --> Helper loaded: url_helper
INFO - 2018-01-30 19:15:01 --> Helper loaded: notification_helper
INFO - 2018-01-30 19:15:01 --> Helper loaded: settings_helper
INFO - 2018-01-30 19:15:01 --> Helper loaded: permission_helper
INFO - 2018-01-30 19:15:01 --> Helper loaded: users_helper
INFO - 2018-01-30 19:15:01 --> Database Driver Class Initialized
DEBUG - 2018-01-30 19:15:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-30 19:15:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-30 19:15:01 --> Helper loaded: form_helper
INFO - 2018-01-30 19:15:01 --> Form Validation Class Initialized
INFO - 2018-01-30 19:15:01 --> Controller Class Initialized
INFO - 2018-01-30 19:15:01 --> Model Class Initialized
INFO - 2018-01-30 19:15:01 --> Helper loaded: inflector_helper
INFO - 2018-01-30 19:15:01 --> Model Class Initialized
INFO - 2018-01-30 19:15:01 --> Model Class Initialized
INFO - 2018-01-30 19:15:01 --> Model Class Initialized
INFO - 2018-01-30 19:15:01 --> Model Class Initialized
INFO - 2018-01-30 19:15:01 --> Model Class Initialized
DEBUG - 2018-01-30 19:15:01 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-01-30 19:15:01 --> File loaded: /home/pr01004/public_html/application/views/admin/dashboard.php
DEBUG - 2018-01-30 19:15:01 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-01-30 19:15:01 --> Final output sent to browser
DEBUG - 2018-01-30 19:15:01 --> Total execution time: 0.1319
INFO - 2018-01-30 13:45:09 --> Config Class Initialized
INFO - 2018-01-30 13:45:09 --> Hooks Class Initialized
DEBUG - 2018-01-30 13:45:09 --> UTF-8 Support Enabled
INFO - 2018-01-30 13:45:09 --> Utf8 Class Initialized
INFO - 2018-01-30 13:45:09 --> URI Class Initialized
INFO - 2018-01-30 13:45:09 --> Router Class Initialized
INFO - 2018-01-30 13:45:09 --> Output Class Initialized
INFO - 2018-01-30 13:45:09 --> Security Class Initialized
DEBUG - 2018-01-30 13:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-30 13:45:09 --> Input Class Initialized
INFO - 2018-01-30 13:45:09 --> Language Class Initialized
INFO - 2018-01-30 13:45:09 --> Language Class Initialized
INFO - 2018-01-30 13:45:09 --> Config Class Initialized
INFO - 2018-01-30 13:45:09 --> Loader Class Initialized
INFO - 2018-01-30 19:15:09 --> Helper loaded: url_helper
INFO - 2018-01-30 19:15:09 --> Helper loaded: notification_helper
INFO - 2018-01-30 19:15:09 --> Helper loaded: settings_helper
INFO - 2018-01-30 19:15:09 --> Helper loaded: permission_helper
INFO - 2018-01-30 19:15:09 --> Helper loaded: users_helper
INFO - 2018-01-30 19:15:10 --> Database Driver Class Initialized
DEBUG - 2018-01-30 19:15:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-30 19:15:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-30 19:15:10 --> Helper loaded: form_helper
INFO - 2018-01-30 19:15:10 --> Form Validation Class Initialized
INFO - 2018-01-30 19:15:10 --> Controller Class Initialized
INFO - 2018-01-30 19:15:10 --> Model Class Initialized
INFO - 2018-01-30 19:15:10 --> Helper loaded: inflector_helper
INFO - 2018-01-30 19:15:10 --> Model Class Initialized
INFO - 2018-01-30 19:15:10 --> Model Class Initialized
INFO - 2018-01-30 19:15:10 --> Model Class Initialized
DEBUG - 2018-01-30 19:15:10 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-01-30 19:15:10 --> File loaded: /home/pr01004/public_html/application/views/admin/notifications.php
DEBUG - 2018-01-30 19:15:10 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-01-30 19:15:10 --> Final output sent to browser
DEBUG - 2018-01-30 19:15:10 --> Total execution time: 0.1026
INFO - 2018-01-30 13:45:19 --> Config Class Initialized
INFO - 2018-01-30 13:45:19 --> Hooks Class Initialized
DEBUG - 2018-01-30 13:45:19 --> UTF-8 Support Enabled
INFO - 2018-01-30 13:45:19 --> Utf8 Class Initialized
INFO - 2018-01-30 13:45:19 --> URI Class Initialized
INFO - 2018-01-30 13:45:19 --> Router Class Initialized
INFO - 2018-01-30 13:45:19 --> Output Class Initialized
INFO - 2018-01-30 13:45:19 --> Security Class Initialized
DEBUG - 2018-01-30 13:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-30 13:45:19 --> Input Class Initialized
INFO - 2018-01-30 13:45:19 --> Language Class Initialized
INFO - 2018-01-30 13:45:19 --> Language Class Initialized
INFO - 2018-01-30 13:45:19 --> Config Class Initialized
INFO - 2018-01-30 13:45:19 --> Loader Class Initialized
INFO - 2018-01-30 19:15:19 --> Helper loaded: url_helper
INFO - 2018-01-30 19:15:19 --> Helper loaded: notification_helper
INFO - 2018-01-30 19:15:19 --> Helper loaded: settings_helper
INFO - 2018-01-30 19:15:19 --> Helper loaded: permission_helper
INFO - 2018-01-30 19:15:19 --> Helper loaded: users_helper
INFO - 2018-01-30 19:15:20 --> Database Driver Class Initialized
DEBUG - 2018-01-30 19:15:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-30 19:15:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-30 19:15:20 --> Helper loaded: form_helper
INFO - 2018-01-30 19:15:20 --> Form Validation Class Initialized
INFO - 2018-01-30 19:15:20 --> Controller Class Initialized
INFO - 2018-01-30 19:15:20 --> Model Class Initialized
INFO - 2018-01-30 19:15:20 --> Helper loaded: inflector_helper
INFO - 2018-01-30 19:15:20 --> Model Class Initialized
INFO - 2018-01-30 19:15:20 --> Model Class Initialized
INFO - 2018-01-30 19:15:20 --> Model Class Initialized
ERROR - 2018-01-30 19:15:20 --> Severity: error --> Exception: [] operator not supported for strings /home/pr01004/public_html/application/controllers/Notification.php 82
INFO - 2018-01-30 13:46:08 --> Config Class Initialized
INFO - 2018-01-30 13:46:08 --> Hooks Class Initialized
DEBUG - 2018-01-30 13:46:08 --> UTF-8 Support Enabled
INFO - 2018-01-30 13:46:08 --> Utf8 Class Initialized
INFO - 2018-01-30 13:46:08 --> URI Class Initialized
INFO - 2018-01-30 13:46:08 --> Router Class Initialized
INFO - 2018-01-30 13:46:08 --> Output Class Initialized
INFO - 2018-01-30 13:46:08 --> Security Class Initialized
DEBUG - 2018-01-30 13:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-30 13:46:08 --> Input Class Initialized
INFO - 2018-01-30 13:46:08 --> Language Class Initialized
INFO - 2018-01-30 13:46:08 --> Language Class Initialized
INFO - 2018-01-30 13:46:08 --> Config Class Initialized
INFO - 2018-01-30 13:46:08 --> Loader Class Initialized
INFO - 2018-01-30 19:16:08 --> Helper loaded: url_helper
INFO - 2018-01-30 19:16:08 --> Helper loaded: notification_helper
INFO - 2018-01-30 19:16:08 --> Helper loaded: settings_helper
INFO - 2018-01-30 19:16:08 --> Helper loaded: permission_helper
INFO - 2018-01-30 19:16:08 --> Helper loaded: users_helper
INFO - 2018-01-30 19:16:08 --> Database Driver Class Initialized
DEBUG - 2018-01-30 19:16:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-30 19:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-30 19:16:08 --> Helper loaded: form_helper
INFO - 2018-01-30 19:16:08 --> Form Validation Class Initialized
INFO - 2018-01-30 19:16:08 --> Controller Class Initialized
INFO - 2018-01-30 19:16:08 --> Model Class Initialized
INFO - 2018-01-30 19:16:08 --> Helper loaded: inflector_helper
INFO - 2018-01-30 19:16:08 --> Model Class Initialized
INFO - 2018-01-30 19:16:08 --> Model Class Initialized
INFO - 2018-01-30 19:16:08 --> Model Class Initialized
ERROR - 2018-01-30 19:16:10 --> Severity: Notice --> Undefined variable: messagebody /home/pr01004/public_html/application/controllers/Notification.php 99
ERROR - 2018-01-30 19:16:11 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:11 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:11 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:11 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:11 --> Severity: Warning --> pack(): Type H: illegal hex digit k /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:11 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:11 --> Severity: Warning --> pack(): Type H: illegal hex digit j /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:11 --> Severity: Warning --> pack(): Type H: illegal hex digit l /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:11 --> Severity: Warning --> pack(): Type H: illegal hex digit k /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:11 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:11 --> Severity: Warning --> pack(): Type H: illegal hex digit l /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:11 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:11 --> Severity: Warning --> pack(): Type H: illegal hex digit k /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:11 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:11 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:11 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:11 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:11 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:11 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:11 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:11 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:11 --> Severity: Warning --> pack(): Type H: illegal hex digit k /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:11 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:11 --> Severity: Warning --> pack(): Type H: illegal hex digit j /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:11 --> Severity: Warning --> pack(): Type H: illegal hex digit l /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:11 --> Severity: Warning --> pack(): Type H: illegal hex digit k /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:11 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:11 --> Severity: Warning --> pack(): Type H: illegal hex digit l /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:11 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:11 --> Severity: Warning --> pack(): Type H: illegal hex digit k /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:11 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:11 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:11 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:11 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:11 --> Severity: Warning --> pack(): Type H: illegal hex digit s /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:11 --> Severity: Warning --> pack(): Type H: illegal hex digit s /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:11 --> Severity: Warning --> pack(): Type H: illegal hex digit s /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:11 --> Severity: Warning --> pack(): Type H: illegal hex digit s /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:11 --> Severity: Warning --> pack(): Type H: illegal hex digit s /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:11 --> Severity: Warning --> pack(): Type H: illegal hex digit s /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/pr01004/public_html/system/core/Exceptions.php:271) /home/pr01004/public_html/system/helpers/url_helper.php 564
INFO - 2018-01-30 13:46:12 --> Config Class Initialized
INFO - 2018-01-30 13:46:12 --> Hooks Class Initialized
DEBUG - 2018-01-30 13:46:12 --> UTF-8 Support Enabled
INFO - 2018-01-30 13:46:12 --> Utf8 Class Initialized
INFO - 2018-01-30 13:46:12 --> URI Class Initialized
INFO - 2018-01-30 13:46:12 --> Router Class Initialized
INFO - 2018-01-30 13:46:12 --> Output Class Initialized
INFO - 2018-01-30 13:46:12 --> Security Class Initialized
DEBUG - 2018-01-30 13:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-30 13:46:12 --> Input Class Initialized
INFO - 2018-01-30 13:46:12 --> Language Class Initialized
INFO - 2018-01-30 13:46:12 --> Language Class Initialized
INFO - 2018-01-30 13:46:12 --> Config Class Initialized
INFO - 2018-01-30 13:46:12 --> Loader Class Initialized
INFO - 2018-01-30 19:16:12 --> Helper loaded: url_helper
INFO - 2018-01-30 19:16:12 --> Helper loaded: notification_helper
INFO - 2018-01-30 19:16:12 --> Helper loaded: settings_helper
INFO - 2018-01-30 19:16:12 --> Helper loaded: permission_helper
INFO - 2018-01-30 19:16:12 --> Helper loaded: users_helper
INFO - 2018-01-30 19:16:12 --> Database Driver Class Initialized
DEBUG - 2018-01-30 19:16:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-30 19:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-30 19:16:12 --> Helper loaded: form_helper
INFO - 2018-01-30 19:16:12 --> Form Validation Class Initialized
INFO - 2018-01-30 19:16:12 --> Controller Class Initialized
DEBUG - 2018-01-30 19:16:12 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-01-30 19:16:12 --> Final output sent to browser
DEBUG - 2018-01-30 19:16:12 --> Total execution time: 0.0747
INFO - 2018-01-30 13:46:32 --> Config Class Initialized
INFO - 2018-01-30 13:46:32 --> Hooks Class Initialized
DEBUG - 2018-01-30 13:46:32 --> UTF-8 Support Enabled
INFO - 2018-01-30 13:46:32 --> Utf8 Class Initialized
INFO - 2018-01-30 13:46:32 --> URI Class Initialized
INFO - 2018-01-30 13:46:32 --> Router Class Initialized
INFO - 2018-01-30 13:46:32 --> Output Class Initialized
INFO - 2018-01-30 13:46:32 --> Security Class Initialized
DEBUG - 2018-01-30 13:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-30 13:46:33 --> Input Class Initialized
INFO - 2018-01-30 13:46:33 --> Language Class Initialized
INFO - 2018-01-30 13:46:33 --> Language Class Initialized
INFO - 2018-01-30 13:46:33 --> Config Class Initialized
INFO - 2018-01-30 13:46:33 --> Loader Class Initialized
INFO - 2018-01-30 19:16:33 --> Helper loaded: url_helper
INFO - 2018-01-30 19:16:33 --> Helper loaded: notification_helper
INFO - 2018-01-30 19:16:33 --> Helper loaded: settings_helper
INFO - 2018-01-30 19:16:33 --> Helper loaded: permission_helper
INFO - 2018-01-30 19:16:33 --> Helper loaded: users_helper
INFO - 2018-01-30 19:16:33 --> Database Driver Class Initialized
DEBUG - 2018-01-30 19:16:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-30 19:16:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-30 19:16:33 --> Helper loaded: form_helper
INFO - 2018-01-30 19:16:33 --> Form Validation Class Initialized
INFO - 2018-01-30 19:16:33 --> Controller Class Initialized
INFO - 2018-01-30 19:16:33 --> Model Class Initialized
INFO - 2018-01-30 19:16:33 --> Helper loaded: inflector_helper
INFO - 2018-01-30 19:16:33 --> Model Class Initialized
INFO - 2018-01-30 19:16:33 --> Model Class Initialized
INFO - 2018-01-30 19:16:33 --> Model Class Initialized
ERROR - 2018-01-30 19:16:36 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:36 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:36 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:36 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:36 --> Severity: Warning --> pack(): Type H: illegal hex digit k /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:36 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:36 --> Severity: Warning --> pack(): Type H: illegal hex digit j /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:36 --> Severity: Warning --> pack(): Type H: illegal hex digit l /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:36 --> Severity: Warning --> pack(): Type H: illegal hex digit k /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:36 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:36 --> Severity: Warning --> pack(): Type H: illegal hex digit l /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:36 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:36 --> Severity: Warning --> pack(): Type H: illegal hex digit k /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:36 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:36 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:36 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:36 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:36 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:36 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:36 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:36 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:36 --> Severity: Warning --> pack(): Type H: illegal hex digit k /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:36 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:36 --> Severity: Warning --> pack(): Type H: illegal hex digit j /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:36 --> Severity: Warning --> pack(): Type H: illegal hex digit l /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:36 --> Severity: Warning --> pack(): Type H: illegal hex digit k /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:36 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:36 --> Severity: Warning --> pack(): Type H: illegal hex digit l /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:36 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:36 --> Severity: Warning --> pack(): Type H: illegal hex digit k /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:36 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:36 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:36 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:36 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:36 --> Severity: Warning --> pack(): Type H: illegal hex digit s /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:36 --> Severity: Warning --> pack(): Type H: illegal hex digit s /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:36 --> Severity: Warning --> pack(): Type H: illegal hex digit s /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:36 --> Severity: Warning --> pack(): Type H: illegal hex digit s /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:36 --> Severity: Warning --> pack(): Type H: illegal hex digit s /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-01-30 19:16:36 --> Severity: Warning --> pack(): Type H: illegal hex digit s /home/pr01004/public_html/application/controllers/Notification.php 156
INFO - 2018-01-30 13:46:37 --> Config Class Initialized
INFO - 2018-01-30 13:46:37 --> Hooks Class Initialized
DEBUG - 2018-01-30 13:46:37 --> UTF-8 Support Enabled
INFO - 2018-01-30 13:46:37 --> Utf8 Class Initialized
INFO - 2018-01-30 13:46:37 --> URI Class Initialized
INFO - 2018-01-30 13:46:37 --> Router Class Initialized
INFO - 2018-01-30 13:46:37 --> Output Class Initialized
INFO - 2018-01-30 13:46:37 --> Security Class Initialized
DEBUG - 2018-01-30 13:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-30 13:46:37 --> Input Class Initialized
INFO - 2018-01-30 13:46:37 --> Language Class Initialized
INFO - 2018-01-30 13:46:37 --> Language Class Initialized
INFO - 2018-01-30 13:46:37 --> Config Class Initialized
INFO - 2018-01-30 13:46:37 --> Loader Class Initialized
INFO - 2018-01-30 19:16:37 --> Helper loaded: url_helper
INFO - 2018-01-30 19:16:37 --> Helper loaded: notification_helper
INFO - 2018-01-30 19:16:37 --> Helper loaded: settings_helper
INFO - 2018-01-30 19:16:37 --> Helper loaded: permission_helper
INFO - 2018-01-30 19:16:37 --> Helper loaded: users_helper
INFO - 2018-01-30 19:16:37 --> Database Driver Class Initialized
DEBUG - 2018-01-30 19:16:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-30 19:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-30 19:16:37 --> Helper loaded: form_helper
INFO - 2018-01-30 19:16:37 --> Form Validation Class Initialized
INFO - 2018-01-30 19:16:37 --> Controller Class Initialized
INFO - 2018-01-30 19:16:37 --> Model Class Initialized
INFO - 2018-01-30 19:16:37 --> Helper loaded: inflector_helper
INFO - 2018-01-30 19:16:37 --> Model Class Initialized
INFO - 2018-01-30 19:16:37 --> Model Class Initialized
INFO - 2018-01-30 19:16:37 --> Model Class Initialized
DEBUG - 2018-01-30 19:16:37 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-01-30 19:16:37 --> File loaded: /home/pr01004/public_html/application/views/admin/notifications.php
DEBUG - 2018-01-30 19:16:37 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-01-30 19:16:37 --> Final output sent to browser
DEBUG - 2018-01-30 19:16:37 --> Total execution time: 0.1125
INFO - 2018-01-30 14:00:46 --> Config Class Initialized
INFO - 2018-01-30 14:00:46 --> Hooks Class Initialized
DEBUG - 2018-01-30 14:00:46 --> UTF-8 Support Enabled
INFO - 2018-01-30 14:00:46 --> Utf8 Class Initialized
INFO - 2018-01-30 14:00:46 --> URI Class Initialized
INFO - 2018-01-30 14:00:46 --> Config Class Initialized
INFO - 2018-01-30 14:00:46 --> Config Class Initialized
INFO - 2018-01-30 14:00:46 --> Hooks Class Initialized
INFO - 2018-01-30 14:00:46 --> Hooks Class Initialized
INFO - 2018-01-30 14:00:46 --> Router Class Initialized
DEBUG - 2018-01-30 14:00:46 --> UTF-8 Support Enabled
INFO - 2018-01-30 14:00:46 --> Utf8 Class Initialized
DEBUG - 2018-01-30 14:00:46 --> UTF-8 Support Enabled
INFO - 2018-01-30 14:00:46 --> Utf8 Class Initialized
INFO - 2018-01-30 14:00:46 --> Output Class Initialized
INFO - 2018-01-30 14:00:46 --> URI Class Initialized
INFO - 2018-01-30 14:00:46 --> URI Class Initialized
INFO - 2018-01-30 14:00:46 --> Security Class Initialized
INFO - 2018-01-30 14:00:46 --> Router Class Initialized
DEBUG - 2018-01-30 14:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-30 14:00:46 --> Router Class Initialized
INFO - 2018-01-30 14:00:46 --> Input Class Initialized
INFO - 2018-01-30 14:00:46 --> Language Class Initialized
INFO - 2018-01-30 14:00:46 --> Output Class Initialized
INFO - 2018-01-30 14:00:46 --> Output Class Initialized
INFO - 2018-01-30 14:00:46 --> Security Class Initialized
INFO - 2018-01-30 14:00:46 --> Security Class Initialized
DEBUG - 2018-01-30 14:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-30 14:00:46 --> Input Class Initialized
INFO - 2018-01-30 14:00:46 --> Language Class Initialized
DEBUG - 2018-01-30 14:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-30 14:00:46 --> Input Class Initialized
INFO - 2018-01-30 14:00:46 --> Language Class Initialized
INFO - 2018-01-30 14:00:46 --> Language Class Initialized
INFO - 2018-01-30 14:00:46 --> Config Class Initialized
INFO - 2018-01-30 14:00:46 --> Loader Class Initialized
INFO - 2018-01-30 14:00:46 --> Language Class Initialized
INFO - 2018-01-30 14:00:46 --> Config Class Initialized
INFO - 2018-01-30 14:00:46 --> Loader Class Initialized
INFO - 2018-01-30 19:30:46 --> Helper loaded: url_helper
INFO - 2018-01-30 19:30:46 --> Helper loaded: notification_helper
INFO - 2018-01-30 19:30:46 --> Helper loaded: url_helper
INFO - 2018-01-30 19:30:46 --> Helper loaded: settings_helper
INFO - 2018-01-30 19:30:46 --> Helper loaded: permission_helper
INFO - 2018-01-30 19:30:46 --> Helper loaded: notification_helper
INFO - 2018-01-30 19:30:46 --> Helper loaded: settings_helper
INFO - 2018-01-30 19:30:46 --> Helper loaded: users_helper
INFO - 2018-01-30 19:30:46 --> Helper loaded: permission_helper
INFO - 2018-01-30 19:30:46 --> Helper loaded: users_helper
INFO - 2018-01-30 14:00:46 --> Language Class Initialized
INFO - 2018-01-30 14:00:46 --> Config Class Initialized
INFO - 2018-01-30 14:00:46 --> Loader Class Initialized
INFO - 2018-01-30 19:30:46 --> Helper loaded: url_helper
INFO - 2018-01-30 19:30:46 --> Helper loaded: notification_helper
INFO - 2018-01-30 19:30:46 --> Helper loaded: settings_helper
INFO - 2018-01-30 19:30:46 --> Helper loaded: permission_helper
INFO - 2018-01-30 19:30:46 --> Helper loaded: users_helper
INFO - 2018-01-30 19:30:46 --> Database Driver Class Initialized
INFO - 2018-01-30 19:30:46 --> Database Driver Class Initialized
DEBUG - 2018-01-30 19:30:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-30 14:00:46 --> Config Class Initialized
INFO - 2018-01-30 14:00:46 --> Hooks Class Initialized
DEBUG - 2018-01-30 19:30:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-30 19:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-30 19:30:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-01-30 14:00:46 --> UTF-8 Support Enabled
INFO - 2018-01-30 14:00:46 --> Utf8 Class Initialized
INFO - 2018-01-30 14:00:46 --> URI Class Initialized
INFO - 2018-01-30 19:30:46 --> Helper loaded: form_helper
INFO - 2018-01-30 19:30:46 --> Form Validation Class Initialized
INFO - 2018-01-30 19:30:46 --> Controller Class Initialized
INFO - 2018-01-30 19:30:46 --> Helper loaded: form_helper
INFO - 2018-01-30 19:30:46 --> Form Validation Class Initialized
INFO - 2018-01-30 19:30:46 --> Controller Class Initialized
INFO - 2018-01-30 19:30:46 --> Database Driver Class Initialized
INFO - 2018-01-30 14:00:46 --> Router Class Initialized
INFO - 2018-01-30 14:00:46 --> Output Class Initialized
DEBUG - 2018-01-30 19:30:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-30 19:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-30 14:00:46 --> Security Class Initialized
INFO - 2018-01-30 19:30:46 --> Model Class Initialized
INFO - 2018-01-30 19:30:46 --> Helper loaded: inflector_helper
INFO - 2018-01-30 19:30:46 --> Model Class Initialized
DEBUG - 2018-01-30 14:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-30 14:00:46 --> Input Class Initialized
INFO - 2018-01-30 19:30:46 --> Helper loaded: inflector_helper
INFO - 2018-01-30 14:00:46 --> Language Class Initialized
INFO - 2018-01-30 14:00:46 --> Config Class Initialized
INFO - 2018-01-30 14:00:46 --> Hooks Class Initialized
DEBUG - 2018-01-30 19:30:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-01-30 19:30:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-30 19:30:46 --> Helper loaded: form_helper
INFO - 2018-01-30 19:30:46 --> Form Validation Class Initialized
INFO - 2018-01-30 19:30:46 --> Controller Class Initialized
DEBUG - 2018-01-30 14:00:46 --> UTF-8 Support Enabled
INFO - 2018-01-30 14:00:46 --> Utf8 Class Initialized
INFO - 2018-01-30 14:00:46 --> URI Class Initialized
INFO - 2018-01-30 14:00:46 --> Router Class Initialized
INFO - 2018-01-30 19:30:46 --> Model Class Initialized
INFO - 2018-01-30 19:30:46 --> Helper loaded: inflector_helper
INFO - 2018-01-30 14:00:46 --> Output Class Initialized
INFO - 2018-01-30 14:00:46 --> Security Class Initialized
DEBUG - 2018-01-30 19:30:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-30 14:00:46 --> Language Class Initialized
INFO - 2018-01-30 14:00:46 --> Config Class Initialized
INFO - 2018-01-30 14:00:46 --> Loader Class Initialized
DEBUG - 2018-01-30 14:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-30 14:00:46 --> Input Class Initialized
INFO - 2018-01-30 14:00:46 --> Language Class Initialized
INFO - 2018-01-30 19:30:46 --> Helper loaded: url_helper
INFO - 2018-01-30 19:30:46 --> Helper loaded: notification_helper
INFO - 2018-01-30 19:30:46 --> Helper loaded: settings_helper
INFO - 2018-01-30 19:30:46 --> Helper loaded: permission_helper
INFO - 2018-01-30 19:30:46 --> Helper loaded: users_helper
INFO - 2018-01-30 19:30:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-30 19:30:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-30 19:30:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-30 19:30:46 --> Model Class Initialized
INFO - 2018-01-30 19:30:46 --> Model Class Initialized
INFO - 2018-01-30 19:30:46 --> Model Class Initialized
INFO - 2018-01-30 19:30:46 --> Database Driver Class Initialized
INFO - 2018-01-30 19:30:46 --> Model Class Initialized
INFO - 2018-01-30 19:30:46 --> Model Class Initialized
INFO - 2018-01-30 19:30:46 --> Model Class Initialized
DEBUG - 2018-01-30 19:30:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-30 19:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-30 19:30:46 --> Model Class Initialized
INFO - 2018-01-30 19:30:46 --> Model Class Initialized
INFO - 2018-01-30 19:30:46 --> Model Class Initialized
INFO - 2018-01-30 14:00:46 --> Language Class Initialized
INFO - 2018-01-30 14:00:46 --> Config Class Initialized
INFO - 2018-01-30 14:00:46 --> Loader Class Initialized
INFO - 2018-01-30 19:30:46 --> Helper loaded: form_helper
INFO - 2018-01-30 19:30:46 --> Form Validation Class Initialized
INFO - 2018-01-30 19:30:46 --> Controller Class Initialized
INFO - 2018-01-30 19:30:46 --> Model Class Initialized
INFO - 2018-01-30 19:30:46 --> Helper loaded: url_helper
INFO - 2018-01-30 19:30:46 --> Model Class Initialized
INFO - 2018-01-30 19:30:46 --> Model Class Initialized
INFO - 2018-01-30 19:30:46 --> Helper loaded: notification_helper
INFO - 2018-01-30 19:30:46 --> Language file loaded: language/english/message_lang.php
INFO - 2018-01-30 19:30:46 --> Helper loaded: settings_helper
INFO - 2018-01-30 19:30:46 --> Helper loaded: permission_helper
INFO - 2018-01-30 19:30:46 --> Helper loaded: users_helper
INFO - 2018-01-30 19:30:46 --> Model Class Initialized
INFO - 2018-01-30 19:30:46 --> Final output sent to browser
DEBUG - 2018-01-30 19:30:46 --> Total execution time: 0.1491
INFO - 2018-01-30 19:30:46 --> Helper loaded: inflector_helper
INFO - 2018-01-30 19:30:46 --> Model Class Initialized
INFO - 2018-01-30 19:30:46 --> Model Class Initialized
INFO - 2018-01-30 19:30:46 --> Model Class Initialized
INFO - 2018-01-30 19:30:46 --> Model Class Initialized
DEBUG - 2018-01-30 19:30:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-30 19:30:46 --> Model Class Initialized
INFO - 2018-01-30 19:30:46 --> Model Class Initialized
INFO - 2018-01-30 19:30:46 --> Model Class Initialized
INFO - 2018-01-30 19:30:46 --> Model Class Initialized
INFO - 2018-01-30 19:30:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-30 19:30:46 --> Model Class Initialized
INFO - 2018-01-30 19:30:46 --> Model Class Initialized
INFO - 2018-01-30 19:30:46 --> Model Class Initialized
INFO - 2018-01-30 19:30:46 --> Model Class Initialized
INFO - 2018-01-30 19:30:46 --> Model Class Initialized
INFO - 2018-01-30 19:30:46 --> Model Class Initialized
INFO - 2018-01-30 19:30:46 --> Model Class Initialized
INFO - 2018-01-30 19:30:46 --> Model Class Initialized
INFO - 2018-01-30 19:30:46 --> Model Class Initialized
INFO - 2018-01-30 19:30:46 --> Model Class Initialized
INFO - 2018-01-30 19:30:46 --> Model Class Initialized
INFO - 2018-01-30 19:30:46 --> Model Class Initialized
INFO - 2018-01-30 19:30:46 --> Language file loaded: language/english/message_lang.php
INFO - 2018-01-30 19:30:46 --> Model Class Initialized
INFO - 2018-01-30 19:30:46 --> Final output sent to browser
DEBUG - 2018-01-30 19:30:46 --> Total execution time: 0.0955
INFO - 2018-01-30 19:30:46 --> Database Driver Class Initialized
INFO - 2018-01-30 19:30:46 --> Model Class Initialized
INFO - 2018-01-30 19:30:46 --> Language file loaded: language/english/message_lang.php
INFO - 2018-01-30 19:30:46 --> Model Class Initialized
INFO - 2018-01-30 19:30:46 --> Model Class Initialized
INFO - 2018-01-30 19:30:46 --> Language file loaded: language/english/message_lang.php
INFO - 2018-01-30 19:30:46 --> Model Class Initialized
DEBUG - 2018-01-30 19:30:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-30 19:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-30 19:30:46 --> Helper loaded: form_helper
INFO - 2018-01-30 19:30:46 --> Form Validation Class Initialized
INFO - 2018-01-30 19:30:46 --> Controller Class Initialized
INFO - 2018-01-30 19:30:46 --> Model Class Initialized
INFO - 2018-01-30 19:30:46 --> Helper loaded: inflector_helper
DEBUG - 2018-01-30 19:30:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-30 19:30:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-30 19:30:46 --> Model Class Initialized
INFO - 2018-01-30 19:30:46 --> Model Class Initialized
INFO - 2018-01-30 19:30:46 --> Model Class Initialized
INFO - 2018-01-30 19:30:46 --> Model Class Initialized
INFO - 2018-01-30 19:30:46 --> Model Class Initialized
INFO - 2018-01-30 19:30:46 --> Model Class Initialized
INFO - 2018-01-30 19:30:46 --> Language file loaded: language/english/message_lang.php
INFO - 2018-01-30 19:30:46 --> Model Class Initialized
INFO - 2018-01-30 19:30:46 --> Final output sent to browser
DEBUG - 2018-01-30 19:30:46 --> Total execution time: 0.1193
INFO - 2018-01-30 19:30:46 --> Final output sent to browser
DEBUG - 2018-01-30 19:30:46 --> Total execution time: 0.2185
INFO - 2018-01-30 19:30:46 --> Final output sent to browser
DEBUG - 2018-01-30 19:30:46 --> Total execution time: 0.2140
INFO - 2018-01-30 14:00:49 --> Config Class Initialized
INFO - 2018-01-30 14:00:49 --> Hooks Class Initialized
DEBUG - 2018-01-30 14:00:49 --> UTF-8 Support Enabled
INFO - 2018-01-30 14:00:49 --> Utf8 Class Initialized
INFO - 2018-01-30 14:00:49 --> URI Class Initialized
INFO - 2018-01-30 14:00:49 --> Router Class Initialized
INFO - 2018-01-30 14:00:49 --> Output Class Initialized
INFO - 2018-01-30 14:00:49 --> Security Class Initialized
DEBUG - 2018-01-30 14:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-30 14:00:49 --> Input Class Initialized
INFO - 2018-01-30 14:00:49 --> Language Class Initialized
INFO - 2018-01-30 14:00:49 --> Config Class Initialized
INFO - 2018-01-30 14:00:49 --> Hooks Class Initialized
INFO - 2018-01-30 14:00:49 --> Language Class Initialized
INFO - 2018-01-30 14:00:49 --> Config Class Initialized
INFO - 2018-01-30 14:00:49 --> Loader Class Initialized
DEBUG - 2018-01-30 14:00:49 --> UTF-8 Support Enabled
INFO - 2018-01-30 14:00:49 --> Utf8 Class Initialized
INFO - 2018-01-30 19:30:49 --> Helper loaded: url_helper
INFO - 2018-01-30 19:30:49 --> Helper loaded: notification_helper
INFO - 2018-01-30 19:30:49 --> Helper loaded: settings_helper
INFO - 2018-01-30 19:30:49 --> Helper loaded: permission_helper
INFO - 2018-01-30 14:00:49 --> URI Class Initialized
INFO - 2018-01-30 19:30:49 --> Helper loaded: users_helper
INFO - 2018-01-30 14:00:49 --> Router Class Initialized
INFO - 2018-01-30 14:00:49 --> Output Class Initialized
INFO - 2018-01-30 19:30:49 --> Database Driver Class Initialized
INFO - 2018-01-30 14:00:49 --> Security Class Initialized
DEBUG - 2018-01-30 14:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-30 14:00:49 --> Input Class Initialized
DEBUG - 2018-01-30 19:30:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-30 19:30:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-30 14:00:49 --> Language Class Initialized
INFO - 2018-01-30 19:30:49 --> Helper loaded: form_helper
INFO - 2018-01-30 19:30:49 --> Form Validation Class Initialized
INFO - 2018-01-30 19:30:49 --> Controller Class Initialized
INFO - 2018-01-30 19:30:49 --> Model Class Initialized
INFO - 2018-01-30 14:00:49 --> Language Class Initialized
INFO - 2018-01-30 19:30:49 --> Helper loaded: inflector_helper
INFO - 2018-01-30 14:00:49 --> Config Class Initialized
INFO - 2018-01-30 14:00:49 --> Loader Class Initialized
INFO - 2018-01-30 19:30:49 --> Helper loaded: url_helper
DEBUG - 2018-01-30 19:30:49 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-30 19:30:49 --> Helper loaded: notification_helper
INFO - 2018-01-30 19:30:49 --> Helper loaded: settings_helper
INFO - 2018-01-30 19:30:49 --> Helper loaded: permission_helper
INFO - 2018-01-30 19:30:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-30 19:30:49 --> Helper loaded: users_helper
INFO - 2018-01-30 19:30:49 --> Model Class Initialized
INFO - 2018-01-30 19:30:49 --> Model Class Initialized
INFO - 2018-01-30 19:30:49 --> Model Class Initialized
INFO - 2018-01-30 19:30:49 --> Model Class Initialized
INFO - 2018-01-30 19:30:49 --> Model Class Initialized
INFO - 2018-01-30 19:30:49 --> Model Class Initialized
INFO - 2018-01-30 19:30:49 --> Model Class Initialized
INFO - 2018-01-30 19:30:49 --> Model Class Initialized
INFO - 2018-01-30 19:30:49 --> Model Class Initialized
INFO - 2018-01-30 19:30:49 --> Model Class Initialized
INFO - 2018-01-30 19:30:49 --> Model Class Initialized
INFO - 2018-01-30 19:30:49 --> Language file loaded: language/english/message_lang.php
INFO - 2018-01-30 19:30:49 --> Model Class Initialized
INFO - 2018-01-30 19:30:49 --> Database Driver Class Initialized
INFO - 2018-01-30 19:30:49 --> Final output sent to browser
DEBUG - 2018-01-30 19:30:49 --> Total execution time: 0.1165
DEBUG - 2018-01-30 19:30:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-30 19:30:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-30 19:30:49 --> Helper loaded: form_helper
INFO - 2018-01-30 19:30:49 --> Form Validation Class Initialized
INFO - 2018-01-30 19:30:49 --> Controller Class Initialized
INFO - 2018-01-30 19:30:49 --> Model Class Initialized
INFO - 2018-01-30 19:30:49 --> Helper loaded: inflector_helper
DEBUG - 2018-01-30 19:30:49 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-30 19:30:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-30 19:30:49 --> Model Class Initialized
INFO - 2018-01-30 19:30:49 --> Model Class Initialized
INFO - 2018-01-30 19:30:49 --> Model Class Initialized
INFO - 2018-01-30 19:30:49 --> Model Class Initialized
INFO - 2018-01-30 19:30:49 --> Model Class Initialized
INFO - 2018-01-30 19:30:49 --> Model Class Initialized
INFO - 2018-01-30 19:30:49 --> Model Class Initialized
INFO - 2018-01-30 19:30:49 --> Model Class Initialized
INFO - 2018-01-30 19:30:49 --> Model Class Initialized
INFO - 2018-01-30 19:30:49 --> Model Class Initialized
INFO - 2018-01-30 19:30:49 --> Model Class Initialized
INFO - 2018-01-30 19:30:49 --> Language file loaded: language/english/message_lang.php
INFO - 2018-01-30 19:30:49 --> Final output sent to browser
DEBUG - 2018-01-30 19:30:49 --> Total execution time: 0.1291
INFO - 2018-01-30 14:00:50 --> Config Class Initialized
INFO - 2018-01-30 14:00:50 --> Hooks Class Initialized
DEBUG - 2018-01-30 14:00:50 --> UTF-8 Support Enabled
INFO - 2018-01-30 14:00:50 --> Utf8 Class Initialized
INFO - 2018-01-30 14:00:50 --> URI Class Initialized
INFO - 2018-01-30 14:00:50 --> Router Class Initialized
INFO - 2018-01-30 14:00:50 --> Output Class Initialized
INFO - 2018-01-30 14:00:50 --> Security Class Initialized
INFO - 2018-01-30 14:00:50 --> Config Class Initialized
INFO - 2018-01-30 14:00:50 --> Hooks Class Initialized
DEBUG - 2018-01-30 14:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-30 14:00:50 --> Input Class Initialized
DEBUG - 2018-01-30 14:00:50 --> UTF-8 Support Enabled
INFO - 2018-01-30 14:00:50 --> Utf8 Class Initialized
INFO - 2018-01-30 14:00:50 --> Language Class Initialized
INFO - 2018-01-30 14:00:50 --> URI Class Initialized
INFO - 2018-01-30 14:00:50 --> Router Class Initialized
INFO - 2018-01-30 14:00:50 --> Output Class Initialized
INFO - 2018-01-30 14:00:50 --> Security Class Initialized
DEBUG - 2018-01-30 14:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-30 14:00:50 --> Input Class Initialized
INFO - 2018-01-30 14:00:50 --> Language Class Initialized
INFO - 2018-01-30 14:00:50 --> Language Class Initialized
INFO - 2018-01-30 14:00:50 --> Config Class Initialized
INFO - 2018-01-30 14:00:50 --> Loader Class Initialized
INFO - 2018-01-30 19:30:50 --> Helper loaded: url_helper
INFO - 2018-01-30 19:30:50 --> Helper loaded: notification_helper
INFO - 2018-01-30 19:30:50 --> Helper loaded: settings_helper
INFO - 2018-01-30 19:30:50 --> Helper loaded: permission_helper
INFO - 2018-01-30 19:30:50 --> Helper loaded: users_helper
INFO - 2018-01-30 14:00:50 --> Language Class Initialized
INFO - 2018-01-30 14:00:50 --> Config Class Initialized
INFO - 2018-01-30 14:00:50 --> Loader Class Initialized
INFO - 2018-01-30 19:30:50 --> Helper loaded: url_helper
INFO - 2018-01-30 19:30:50 --> Helper loaded: notification_helper
INFO - 2018-01-30 19:30:50 --> Helper loaded: settings_helper
INFO - 2018-01-30 19:30:50 --> Helper loaded: permission_helper
INFO - 2018-01-30 19:30:50 --> Helper loaded: users_helper
INFO - 2018-01-30 19:30:50 --> Database Driver Class Initialized
DEBUG - 2018-01-30 19:30:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-30 14:00:50 --> Config Class Initialized
INFO - 2018-01-30 14:00:50 --> Hooks Class Initialized
INFO - 2018-01-30 19:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-30 19:30:50 --> Database Driver Class Initialized
DEBUG - 2018-01-30 14:00:50 --> UTF-8 Support Enabled
INFO - 2018-01-30 14:00:50 --> Utf8 Class Initialized
INFO - 2018-01-30 14:00:50 --> URI Class Initialized
DEBUG - 2018-01-30 19:30:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-30 19:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-30 19:30:50 --> Helper loaded: form_helper
INFO - 2018-01-30 19:30:50 --> Form Validation Class Initialized
INFO - 2018-01-30 19:30:50 --> Controller Class Initialized
INFO - 2018-01-30 14:00:50 --> Router Class Initialized
INFO - 2018-01-30 14:00:50 --> Output Class Initialized
INFO - 2018-01-30 19:30:50 --> Helper loaded: form_helper
INFO - 2018-01-30 19:30:50 --> Form Validation Class Initialized
INFO - 2018-01-30 19:30:50 --> Controller Class Initialized
INFO - 2018-01-30 14:00:50 --> Security Class Initialized
DEBUG - 2018-01-30 14:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-30 14:00:50 --> Input Class Initialized
INFO - 2018-01-30 14:00:50 --> Language Class Initialized
INFO - 2018-01-30 19:30:50 --> Model Class Initialized
INFO - 2018-01-30 19:30:50 --> Helper loaded: inflector_helper
INFO - 2018-01-30 19:30:50 --> Model Class Initialized
INFO - 2018-01-30 19:30:50 --> Helper loaded: inflector_helper
DEBUG - 2018-01-30 19:30:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-30 19:30:50 --> Language file loaded: language/english/rest_controller_lang.php
DEBUG - 2018-01-30 19:30:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-30 19:30:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-30 19:30:50 --> Model Class Initialized
INFO - 2018-01-30 19:30:50 --> Model Class Initialized
INFO - 2018-01-30 19:30:50 --> Model Class Initialized
INFO - 2018-01-30 19:30:50 --> Model Class Initialized
INFO - 2018-01-30 19:30:50 --> Model Class Initialized
INFO - 2018-01-30 19:30:50 --> Model Class Initialized
INFO - 2018-01-30 19:30:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-01-30 19:30:50 --> Model Class Initialized
INFO - 2018-01-30 19:30:50 --> Model Class Initialized
INFO - 2018-01-30 19:30:50 --> Final output sent to browser
DEBUG - 2018-01-30 19:30:50 --> Total execution time: 0.1029
INFO - 2018-01-30 19:30:50 --> Model Class Initialized
INFO - 2018-01-30 19:30:50 --> Model Class Initialized
INFO - 2018-01-30 19:30:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-01-30 14:00:50 --> Language Class Initialized
INFO - 2018-01-30 14:00:50 --> Config Class Initialized
INFO - 2018-01-30 14:00:50 --> Loader Class Initialized
INFO - 2018-01-30 19:30:50 --> Helper loaded: url_helper
INFO - 2018-01-30 19:30:50 --> Final output sent to browser
DEBUG - 2018-01-30 19:30:50 --> Total execution time: 0.1307
INFO - 2018-01-30 19:30:50 --> Helper loaded: notification_helper
INFO - 2018-01-30 19:30:50 --> Helper loaded: settings_helper
INFO - 2018-01-30 19:30:50 --> Helper loaded: permission_helper
INFO - 2018-01-30 19:30:50 --> Helper loaded: users_helper
INFO - 2018-01-30 19:30:50 --> Database Driver Class Initialized
DEBUG - 2018-01-30 19:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-30 19:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-30 19:30:51 --> Helper loaded: form_helper
INFO - 2018-01-30 19:30:51 --> Form Validation Class Initialized
INFO - 2018-01-30 19:30:51 --> Controller Class Initialized
INFO - 2018-01-30 19:30:51 --> Model Class Initialized
INFO - 2018-01-30 19:30:51 --> Helper loaded: inflector_helper
DEBUG - 2018-01-30 19:30:51 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-30 19:30:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-30 19:30:51 --> Model Class Initialized
INFO - 2018-01-30 19:30:51 --> Model Class Initialized
INFO - 2018-01-30 19:30:51 --> Model Class Initialized
INFO - 2018-01-30 19:30:51 --> Model Class Initialized
INFO - 2018-01-30 19:30:51 --> Model Class Initialized
INFO - 2018-01-30 19:30:51 --> Model Class Initialized
INFO - 2018-01-30 19:30:51 --> Language file loaded: language/english/message_lang.php
INFO - 2018-01-30 19:30:51 --> Final output sent to browser
DEBUG - 2018-01-30 19:30:51 --> Total execution time: 0.1110
INFO - 2018-01-30 14:00:52 --> Config Class Initialized
INFO - 2018-01-30 14:00:52 --> Hooks Class Initialized
DEBUG - 2018-01-30 14:00:52 --> UTF-8 Support Enabled
INFO - 2018-01-30 14:00:52 --> Utf8 Class Initialized
INFO - 2018-01-30 14:00:52 --> URI Class Initialized
INFO - 2018-01-30 14:00:52 --> Router Class Initialized
INFO - 2018-01-30 14:00:52 --> Output Class Initialized
INFO - 2018-01-30 14:00:52 --> Security Class Initialized
DEBUG - 2018-01-30 14:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-30 14:00:52 --> Input Class Initialized
INFO - 2018-01-30 14:00:52 --> Language Class Initialized
INFO - 2018-01-30 14:00:52 --> Language Class Initialized
INFO - 2018-01-30 14:00:52 --> Config Class Initialized
INFO - 2018-01-30 14:00:52 --> Loader Class Initialized
INFO - 2018-01-30 19:30:52 --> Helper loaded: url_helper
INFO - 2018-01-30 19:30:52 --> Helper loaded: notification_helper
INFO - 2018-01-30 19:30:52 --> Helper loaded: settings_helper
INFO - 2018-01-30 19:30:52 --> Helper loaded: permission_helper
INFO - 2018-01-30 19:30:52 --> Helper loaded: users_helper
INFO - 2018-01-30 19:30:52 --> Database Driver Class Initialized
DEBUG - 2018-01-30 19:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-30 19:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-30 19:30:52 --> Helper loaded: form_helper
INFO - 2018-01-30 19:30:52 --> Form Validation Class Initialized
INFO - 2018-01-30 19:30:52 --> Controller Class Initialized
INFO - 2018-01-30 19:30:52 --> Model Class Initialized
INFO - 2018-01-30 19:30:52 --> Helper loaded: inflector_helper
DEBUG - 2018-01-30 19:30:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-30 19:30:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-30 19:30:52 --> Model Class Initialized
INFO - 2018-01-30 19:30:52 --> Model Class Initialized
INFO - 2018-01-30 19:30:52 --> Model Class Initialized
INFO - 2018-01-30 19:30:52 --> Model Class Initialized
INFO - 2018-01-30 19:30:52 --> Model Class Initialized
INFO - 2018-01-30 19:30:52 --> Model Class Initialized
INFO - 2018-01-30 19:30:52 --> Language file loaded: language/english/message_lang.php
INFO - 2018-01-30 19:30:52 --> Final output sent to browser
DEBUG - 2018-01-30 19:30:52 --> Total execution time: 0.1163
