<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-04-13 07:13:24 --> Config Class Initialized
INFO - 2018-04-13 07:13:24 --> Hooks Class Initialized
DEBUG - 2018-04-13 07:13:24 --> UTF-8 Support Enabled
INFO - 2018-04-13 07:13:24 --> Utf8 Class Initialized
INFO - 2018-04-13 07:13:24 --> URI Class Initialized
INFO - 2018-04-13 07:13:24 --> Router Class Initialized
INFO - 2018-04-13 07:13:24 --> Output Class Initialized
INFO - 2018-04-13 07:13:24 --> Security Class Initialized
DEBUG - 2018-04-13 07:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 07:13:24 --> Input Class Initialized
INFO - 2018-04-13 07:13:24 --> Language Class Initialized
INFO - 2018-04-13 07:13:24 --> Language Class Initialized
INFO - 2018-04-13 07:13:24 --> Config Class Initialized
INFO - 2018-04-13 07:13:24 --> Loader Class Initialized
INFO - 2018-04-13 12:43:24 --> Helper loaded: url_helper
INFO - 2018-04-13 12:43:24 --> Helper loaded: notification_helper
INFO - 2018-04-13 12:43:24 --> Helper loaded: settings_helper
INFO - 2018-04-13 12:43:24 --> Helper loaded: permission_helper
INFO - 2018-04-13 12:43:24 --> Helper loaded: users_helper
INFO - 2018-04-13 12:43:24 --> Database Driver Class Initialized
DEBUG - 2018-04-13 12:43:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 12:43:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 12:43:24 --> Helper loaded: form_helper
INFO - 2018-04-13 12:43:24 --> Form Validation Class Initialized
INFO - 2018-04-13 12:43:24 --> Controller Class Initialized
DEBUG - 2018-04-13 12:43:24 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-04-13 12:43:24 --> Final output sent to browser
DEBUG - 2018-04-13 12:43:24 --> Total execution time: 0.0922
INFO - 2018-04-13 08:23:48 --> Config Class Initialized
INFO - 2018-04-13 08:23:48 --> Hooks Class Initialized
INFO - 2018-04-13 08:23:48 --> Config Class Initialized
INFO - 2018-04-13 08:23:48 --> Hooks Class Initialized
DEBUG - 2018-04-13 08:23:48 --> UTF-8 Support Enabled
INFO - 2018-04-13 08:23:48 --> Utf8 Class Initialized
DEBUG - 2018-04-13 08:23:48 --> UTF-8 Support Enabled
INFO - 2018-04-13 08:23:48 --> Utf8 Class Initialized
INFO - 2018-04-13 08:23:48 --> URI Class Initialized
INFO - 2018-04-13 08:23:48 --> URI Class Initialized
INFO - 2018-04-13 08:23:48 --> Config Class Initialized
INFO - 2018-04-13 08:23:48 --> Hooks Class Initialized
INFO - 2018-04-13 08:23:48 --> Router Class Initialized
INFO - 2018-04-13 08:23:48 --> Router Class Initialized
INFO - 2018-04-13 08:23:48 --> Config Class Initialized
INFO - 2018-04-13 08:23:48 --> Hooks Class Initialized
INFO - 2018-04-13 08:23:48 --> Output Class Initialized
INFO - 2018-04-13 08:23:48 --> Output Class Initialized
DEBUG - 2018-04-13 08:23:48 --> UTF-8 Support Enabled
INFO - 2018-04-13 08:23:48 --> Utf8 Class Initialized
DEBUG - 2018-04-13 08:23:48 --> UTF-8 Support Enabled
INFO - 2018-04-13 08:23:48 --> Security Class Initialized
INFO - 2018-04-13 08:23:48 --> Utf8 Class Initialized
INFO - 2018-04-13 08:23:48 --> Security Class Initialized
INFO - 2018-04-13 08:23:48 --> URI Class Initialized
INFO - 2018-04-13 08:23:48 --> URI Class Initialized
DEBUG - 2018-04-13 08:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 08:23:48 --> Input Class Initialized
DEBUG - 2018-04-13 08:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 08:23:48 --> Input Class Initialized
INFO - 2018-04-13 08:23:48 --> Language Class Initialized
INFO - 2018-04-13 08:23:48 --> Language Class Initialized
INFO - 2018-04-13 08:23:48 --> Router Class Initialized
INFO - 2018-04-13 08:23:48 --> Router Class Initialized
INFO - 2018-04-13 08:23:48 --> Output Class Initialized
INFO - 2018-04-13 08:23:48 --> Output Class Initialized
INFO - 2018-04-13 08:23:48 --> Security Class Initialized
INFO - 2018-04-13 08:23:48 --> Security Class Initialized
DEBUG - 2018-04-13 08:23:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-13 08:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 08:23:48 --> Input Class Initialized
INFO - 2018-04-13 08:23:48 --> Input Class Initialized
INFO - 2018-04-13 08:23:48 --> Language Class Initialized
INFO - 2018-04-13 08:23:48 --> Language Class Initialized
INFO - 2018-04-13 08:23:49 --> Language Class Initialized
INFO - 2018-04-13 08:23:49 --> Config Class Initialized
INFO - 2018-04-13 08:23:49 --> Loader Class Initialized
INFO - 2018-04-13 13:53:49 --> Helper loaded: url_helper
INFO - 2018-04-13 08:23:49 --> Language Class Initialized
INFO - 2018-04-13 08:23:49 --> Config Class Initialized
INFO - 2018-04-13 08:23:49 --> Loader Class Initialized
INFO - 2018-04-13 13:53:49 --> Helper loaded: notification_helper
INFO - 2018-04-13 13:53:49 --> Helper loaded: settings_helper
INFO - 2018-04-13 13:53:49 --> Helper loaded: permission_helper
INFO - 2018-04-13 13:53:49 --> Helper loaded: url_helper
INFO - 2018-04-13 13:53:49 --> Helper loaded: users_helper
INFO - 2018-04-13 13:53:49 --> Helper loaded: notification_helper
INFO - 2018-04-13 13:53:49 --> Helper loaded: settings_helper
INFO - 2018-04-13 08:23:49 --> Config Class Initialized
INFO - 2018-04-13 08:23:49 --> Hooks Class Initialized
INFO - 2018-04-13 13:53:49 --> Helper loaded: permission_helper
INFO - 2018-04-13 13:53:49 --> Helper loaded: users_helper
DEBUG - 2018-04-13 08:23:49 --> UTF-8 Support Enabled
INFO - 2018-04-13 08:23:49 --> Utf8 Class Initialized
INFO - 2018-04-13 08:23:49 --> Language Class Initialized
INFO - 2018-04-13 08:23:49 --> Config Class Initialized
INFO - 2018-04-13 08:23:49 --> Loader Class Initialized
INFO - 2018-04-13 08:23:49 --> URI Class Initialized
INFO - 2018-04-13 13:53:49 --> Helper loaded: url_helper
INFO - 2018-04-13 13:53:49 --> Helper loaded: notification_helper
INFO - 2018-04-13 13:53:49 --> Helper loaded: settings_helper
INFO - 2018-04-13 13:53:49 --> Helper loaded: permission_helper
INFO - 2018-04-13 08:23:49 --> Router Class Initialized
INFO - 2018-04-13 13:53:49 --> Helper loaded: users_helper
INFO - 2018-04-13 08:23:49 --> Language Class Initialized
INFO - 2018-04-13 08:23:49 --> Config Class Initialized
INFO - 2018-04-13 08:23:49 --> Loader Class Initialized
INFO - 2018-04-13 13:53:49 --> Database Driver Class Initialized
INFO - 2018-04-13 08:23:49 --> Output Class Initialized
INFO - 2018-04-13 13:53:49 --> Helper loaded: url_helper
INFO - 2018-04-13 13:53:49 --> Database Driver Class Initialized
INFO - 2018-04-13 13:53:49 --> Helper loaded: notification_helper
INFO - 2018-04-13 13:53:49 --> Helper loaded: settings_helper
INFO - 2018-04-13 13:53:49 --> Helper loaded: permission_helper
INFO - 2018-04-13 08:23:49 --> Security Class Initialized
DEBUG - 2018-04-13 13:53:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 13:53:49 --> Helper loaded: users_helper
INFO - 2018-04-13 13:53:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-04-13 13:53:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 13:53:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-04-13 08:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 08:23:49 --> Input Class Initialized
INFO - 2018-04-13 08:23:49 --> Language Class Initialized
INFO - 2018-04-13 13:53:49 --> Database Driver Class Initialized
INFO - 2018-04-13 13:53:49 --> Helper loaded: form_helper
INFO - 2018-04-13 13:53:49 --> Form Validation Class Initialized
INFO - 2018-04-13 13:53:49 --> Controller Class Initialized
INFO - 2018-04-13 13:53:49 --> Helper loaded: form_helper
INFO - 2018-04-13 13:53:49 --> Form Validation Class Initialized
INFO - 2018-04-13 13:53:49 --> Controller Class Initialized
DEBUG - 2018-04-13 13:53:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 13:53:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 13:53:49 --> Database Driver Class Initialized
INFO - 2018-04-13 13:53:49 --> Model Class Initialized
INFO - 2018-04-13 13:53:49 --> Helper loaded: inflector_helper
INFO - 2018-04-13 13:53:49 --> Model Class Initialized
INFO - 2018-04-13 13:53:49 --> Helper loaded: inflector_helper
INFO - 2018-04-13 13:53:49 --> Helper loaded: form_helper
INFO - 2018-04-13 13:53:49 --> Form Validation Class Initialized
INFO - 2018-04-13 13:53:49 --> Controller Class Initialized
DEBUG - 2018-04-13 13:53:49 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-04-13 13:53:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-04-13 13:53:49 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 13:53:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 13:53:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 13:53:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 13:53:49 --> Model Class Initialized
INFO - 2018-04-13 13:53:49 --> Model Class Initialized
INFO - 2018-04-13 13:53:49 --> Model Class Initialized
INFO - 2018-04-13 13:53:49 --> Model Class Initialized
INFO - 2018-04-13 13:53:49 --> Model Class Initialized
INFO - 2018-04-13 13:53:49 --> Model Class Initialized
INFO - 2018-04-13 13:53:49 --> Model Class Initialized
INFO - 2018-04-13 13:53:49 --> Model Class Initialized
INFO - 2018-04-13 13:53:49 --> Model Class Initialized
INFO - 2018-04-13 13:53:49 --> Model Class Initialized
INFO - 2018-04-13 13:53:49 --> Model Class Initialized
INFO - 2018-04-13 13:53:49 --> Model Class Initialized
INFO - 2018-04-13 13:53:49 --> Model Class Initialized
INFO - 2018-04-13 13:53:49 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-13 13:53:49 --> Model Class Initialized
INFO - 2018-04-13 13:53:49 --> Model Class Initialized
INFO - 2018-04-13 13:53:49 --> Model Class Initialized
INFO - 2018-04-13 08:23:49 --> Language Class Initialized
INFO - 2018-04-13 08:23:49 --> Config Class Initialized
INFO - 2018-04-13 08:23:49 --> Loader Class Initialized
INFO - 2018-04-13 13:53:49 --> Model Class Initialized
INFO - 2018-04-13 13:53:49 --> Helper loaded: inflector_helper
INFO - 2018-04-13 13:53:49 --> Model Class Initialized
INFO - 2018-04-13 13:53:49 --> Model Class Initialized
INFO - 2018-04-13 13:53:49 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-13 13:53:49 --> Helper loaded: url_helper
INFO - 2018-04-13 13:53:49 --> Model Class Initialized
INFO - 2018-04-13 13:53:49 --> Final output sent to browser
INFO - 2018-04-13 13:53:49 --> Helper loaded: form_helper
DEBUG - 2018-04-13 13:53:49 --> Total execution time: 0.1021
INFO - 2018-04-13 13:53:49 --> Form Validation Class Initialized
INFO - 2018-04-13 13:53:49 --> Controller Class Initialized
INFO - 2018-04-13 13:53:49 --> Helper loaded: notification_helper
DEBUG - 2018-04-13 13:53:49 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 13:53:49 --> Helper loaded: settings_helper
INFO - 2018-04-13 13:53:49 --> Helper loaded: permission_helper
INFO - 2018-04-13 13:53:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 13:53:49 --> Helper loaded: users_helper
INFO - 2018-04-13 13:53:49 --> Model Class Initialized
INFO - 2018-04-13 13:53:49 --> Model Class Initialized
INFO - 2018-04-13 13:53:49 --> Model Class Initialized
INFO - 2018-04-13 13:53:49 --> Model Class Initialized
INFO - 2018-04-13 13:53:49 --> Model Class Initialized
INFO - 2018-04-13 13:53:49 --> Model Class Initialized
INFO - 2018-04-13 13:53:49 --> Model Class Initialized
INFO - 2018-04-13 13:53:49 --> Model Class Initialized
INFO - 2018-04-13 13:53:49 --> Model Class Initialized
INFO - 2018-04-13 13:53:49 --> Model Class Initialized
INFO - 2018-04-13 13:53:49 --> Model Class Initialized
INFO - 2018-04-13 13:53:49 --> Model Class Initialized
INFO - 2018-04-13 13:53:49 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-13 13:53:49 --> Helper loaded: inflector_helper
INFO - 2018-04-13 13:53:49 --> Final output sent to browser
DEBUG - 2018-04-13 13:53:49 --> Total execution time: 0.1164
INFO - 2018-04-13 13:53:49 --> Model Class Initialized
DEBUG - 2018-04-13 13:53:49 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 13:53:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 13:53:49 --> Model Class Initialized
INFO - 2018-04-13 13:53:49 --> Model Class Initialized
INFO - 2018-04-13 13:53:49 --> Model Class Initialized
INFO - 2018-04-13 13:53:49 --> Model Class Initialized
INFO - 2018-04-13 13:53:49 --> Model Class Initialized
INFO - 2018-04-13 13:53:49 --> Model Class Initialized
INFO - 2018-04-13 13:53:49 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-13 13:53:49 --> Database Driver Class Initialized
INFO - 2018-04-13 13:53:49 --> Final output sent to browser
DEBUG - 2018-04-13 13:53:49 --> Total execution time: 0.1161
INFO - 2018-04-13 13:53:49 --> Final output sent to browser
DEBUG - 2018-04-13 13:53:49 --> Total execution time: 0.1224
DEBUG - 2018-04-13 13:53:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 13:53:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 13:53:49 --> Helper loaded: form_helper
INFO - 2018-04-13 13:53:49 --> Form Validation Class Initialized
INFO - 2018-04-13 13:53:49 --> Controller Class Initialized
INFO - 2018-04-13 13:53:49 --> Model Class Initialized
INFO - 2018-04-13 13:53:49 --> Helper loaded: inflector_helper
DEBUG - 2018-04-13 13:53:49 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 13:53:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 13:53:49 --> Model Class Initialized
INFO - 2018-04-13 13:53:49 --> Model Class Initialized
INFO - 2018-04-13 13:53:49 --> Model Class Initialized
INFO - 2018-04-13 13:53:49 --> Model Class Initialized
INFO - 2018-04-13 13:53:49 --> Model Class Initialized
INFO - 2018-04-13 13:53:49 --> Model Class Initialized
INFO - 2018-04-13 13:53:49 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-13 13:53:49 --> Model Class Initialized
INFO - 2018-04-13 13:53:49 --> Final output sent to browser
DEBUG - 2018-04-13 13:53:49 --> Total execution time: 0.1286
INFO - 2018-04-13 08:23:52 --> Config Class Initialized
INFO - 2018-04-13 08:23:52 --> Hooks Class Initialized
DEBUG - 2018-04-13 08:23:52 --> UTF-8 Support Enabled
INFO - 2018-04-13 08:23:52 --> Utf8 Class Initialized
INFO - 2018-04-13 08:23:52 --> URI Class Initialized
INFO - 2018-04-13 08:23:52 --> Router Class Initialized
INFO - 2018-04-13 08:23:52 --> Output Class Initialized
INFO - 2018-04-13 08:23:52 --> Security Class Initialized
DEBUG - 2018-04-13 08:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 08:23:52 --> Input Class Initialized
INFO - 2018-04-13 08:23:52 --> Language Class Initialized
INFO - 2018-04-13 08:23:52 --> Language Class Initialized
INFO - 2018-04-13 08:23:52 --> Config Class Initialized
INFO - 2018-04-13 08:23:52 --> Loader Class Initialized
INFO - 2018-04-13 13:53:52 --> Helper loaded: url_helper
INFO - 2018-04-13 13:53:52 --> Helper loaded: notification_helper
INFO - 2018-04-13 13:53:52 --> Helper loaded: settings_helper
INFO - 2018-04-13 13:53:52 --> Helper loaded: permission_helper
INFO - 2018-04-13 13:53:52 --> Helper loaded: users_helper
INFO - 2018-04-13 13:53:52 --> Database Driver Class Initialized
DEBUG - 2018-04-13 13:53:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 13:53:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 13:53:52 --> Helper loaded: form_helper
INFO - 2018-04-13 13:53:52 --> Form Validation Class Initialized
INFO - 2018-04-13 13:53:52 --> Controller Class Initialized
INFO - 2018-04-13 13:53:52 --> Model Class Initialized
INFO - 2018-04-13 13:53:52 --> Helper loaded: inflector_helper
DEBUG - 2018-04-13 13:53:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 13:53:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 13:53:52 --> Model Class Initialized
INFO - 2018-04-13 13:53:52 --> Model Class Initialized
INFO - 2018-04-13 13:53:52 --> Model Class Initialized
INFO - 2018-04-13 13:53:52 --> Model Class Initialized
INFO - 2018-04-13 13:53:52 --> Model Class Initialized
INFO - 2018-04-13 13:53:52 --> Model Class Initialized
INFO - 2018-04-13 13:53:52 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-04-13 13:53:52 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-04-13 13:53:52 --> Final output sent to browser
DEBUG - 2018-04-13 13:53:52 --> Total execution time: 0.1151
INFO - 2018-04-13 08:23:53 --> Config Class Initialized
INFO - 2018-04-13 08:23:53 --> Hooks Class Initialized
DEBUG - 2018-04-13 08:23:53 --> UTF-8 Support Enabled
INFO - 2018-04-13 08:23:53 --> Utf8 Class Initialized
INFO - 2018-04-13 08:23:53 --> URI Class Initialized
INFO - 2018-04-13 08:23:53 --> Router Class Initialized
INFO - 2018-04-13 08:23:53 --> Output Class Initialized
INFO - 2018-04-13 08:23:53 --> Security Class Initialized
DEBUG - 2018-04-13 08:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 08:23:54 --> Input Class Initialized
INFO - 2018-04-13 08:23:54 --> Config Class Initialized
INFO - 2018-04-13 08:23:54 --> Hooks Class Initialized
INFO - 2018-04-13 08:23:54 --> Language Class Initialized
DEBUG - 2018-04-13 08:23:54 --> UTF-8 Support Enabled
INFO - 2018-04-13 08:23:54 --> Utf8 Class Initialized
INFO - 2018-04-13 08:23:54 --> URI Class Initialized
INFO - 2018-04-13 08:23:54 --> Router Class Initialized
INFO - 2018-04-13 08:23:54 --> Output Class Initialized
INFO - 2018-04-13 08:23:54 --> Security Class Initialized
DEBUG - 2018-04-13 08:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 08:23:54 --> Input Class Initialized
INFO - 2018-04-13 08:23:54 --> Language Class Initialized
INFO - 2018-04-13 08:23:54 --> Language Class Initialized
INFO - 2018-04-13 08:23:54 --> Config Class Initialized
INFO - 2018-04-13 08:23:54 --> Loader Class Initialized
INFO - 2018-04-13 13:53:54 --> Helper loaded: url_helper
INFO - 2018-04-13 13:53:54 --> Helper loaded: notification_helper
INFO - 2018-04-13 13:53:54 --> Helper loaded: settings_helper
INFO - 2018-04-13 13:53:54 --> Helper loaded: permission_helper
INFO - 2018-04-13 13:53:54 --> Helper loaded: users_helper
INFO - 2018-04-13 08:23:54 --> Language Class Initialized
INFO - 2018-04-13 08:23:54 --> Config Class Initialized
INFO - 2018-04-13 08:23:54 --> Loader Class Initialized
INFO - 2018-04-13 13:53:54 --> Helper loaded: url_helper
INFO - 2018-04-13 13:53:54 --> Database Driver Class Initialized
INFO - 2018-04-13 13:53:54 --> Helper loaded: notification_helper
INFO - 2018-04-13 13:53:54 --> Helper loaded: settings_helper
INFO - 2018-04-13 13:53:54 --> Helper loaded: permission_helper
INFO - 2018-04-13 13:53:54 --> Helper loaded: users_helper
DEBUG - 2018-04-13 13:53:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 13:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 13:53:54 --> Helper loaded: form_helper
INFO - 2018-04-13 13:53:54 --> Form Validation Class Initialized
INFO - 2018-04-13 13:53:54 --> Controller Class Initialized
INFO - 2018-04-13 13:53:54 --> Database Driver Class Initialized
DEBUG - 2018-04-13 13:53:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 13:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 13:53:54 --> Model Class Initialized
INFO - 2018-04-13 13:53:54 --> Helper loaded: inflector_helper
DEBUG - 2018-04-13 13:53:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 13:53:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 13:53:54 --> Helper loaded: form_helper
INFO - 2018-04-13 13:53:54 --> Form Validation Class Initialized
INFO - 2018-04-13 13:53:54 --> Controller Class Initialized
INFO - 2018-04-13 13:53:54 --> Model Class Initialized
INFO - 2018-04-13 13:53:54 --> Model Class Initialized
INFO - 2018-04-13 13:53:54 --> Model Class Initialized
INFO - 2018-04-13 13:53:54 --> Model Class Initialized
INFO - 2018-04-13 13:53:54 --> Model Class Initialized
INFO - 2018-04-13 13:53:54 --> Model Class Initialized
INFO - 2018-04-13 13:53:54 --> Model Class Initialized
INFO - 2018-04-13 13:53:54 --> Model Class Initialized
INFO - 2018-04-13 13:53:54 --> Model Class Initialized
INFO - 2018-04-13 13:53:54 --> Model Class Initialized
INFO - 2018-04-13 13:53:54 --> Model Class Initialized
INFO - 2018-04-13 13:53:54 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-13 13:53:54 --> Model Class Initialized
INFO - 2018-04-13 13:53:54 --> Model Class Initialized
INFO - 2018-04-13 13:53:54 --> Helper loaded: inflector_helper
DEBUG - 2018-04-13 13:53:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 13:53:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 13:53:54 --> Model Class Initialized
INFO - 2018-04-13 13:53:54 --> Model Class Initialized
INFO - 2018-04-13 13:53:54 --> Model Class Initialized
INFO - 2018-04-13 13:53:54 --> Model Class Initialized
INFO - 2018-04-13 13:53:54 --> Model Class Initialized
INFO - 2018-04-13 13:53:54 --> Model Class Initialized
INFO - 2018-04-13 13:53:54 --> Final output sent to browser
DEBUG - 2018-04-13 13:53:54 --> Total execution time: 0.1385
INFO - 2018-04-13 13:53:54 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-13 13:53:54 --> Model Class Initialized
INFO - 2018-04-13 13:53:54 --> Final output sent to browser
DEBUG - 2018-04-13 13:53:54 --> Total execution time: 0.1063
INFO - 2018-04-13 08:23:55 --> Config Class Initialized
INFO - 2018-04-13 08:23:55 --> Hooks Class Initialized
DEBUG - 2018-04-13 08:23:55 --> UTF-8 Support Enabled
INFO - 2018-04-13 08:23:55 --> Utf8 Class Initialized
INFO - 2018-04-13 08:23:55 --> URI Class Initialized
INFO - 2018-04-13 08:23:55 --> Router Class Initialized
INFO - 2018-04-13 08:23:55 --> Output Class Initialized
INFO - 2018-04-13 08:23:55 --> Security Class Initialized
DEBUG - 2018-04-13 08:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 08:23:55 --> Input Class Initialized
INFO - 2018-04-13 08:23:55 --> Language Class Initialized
INFO - 2018-04-13 08:23:55 --> Language Class Initialized
INFO - 2018-04-13 08:23:55 --> Config Class Initialized
INFO - 2018-04-13 08:23:55 --> Loader Class Initialized
INFO - 2018-04-13 13:53:55 --> Helper loaded: url_helper
INFO - 2018-04-13 13:53:55 --> Helper loaded: notification_helper
INFO - 2018-04-13 13:53:55 --> Helper loaded: settings_helper
INFO - 2018-04-13 13:53:55 --> Helper loaded: permission_helper
INFO - 2018-04-13 13:53:55 --> Helper loaded: users_helper
INFO - 2018-04-13 13:53:55 --> Database Driver Class Initialized
DEBUG - 2018-04-13 13:53:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 13:53:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 13:53:55 --> Helper loaded: form_helper
INFO - 2018-04-13 13:53:55 --> Form Validation Class Initialized
INFO - 2018-04-13 13:53:55 --> Controller Class Initialized
INFO - 2018-04-13 13:53:55 --> Model Class Initialized
INFO - 2018-04-13 13:53:55 --> Helper loaded: inflector_helper
DEBUG - 2018-04-13 13:53:55 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 13:53:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 13:53:55 --> Model Class Initialized
INFO - 2018-04-13 13:53:55 --> Model Class Initialized
INFO - 2018-04-13 13:53:55 --> Model Class Initialized
INFO - 2018-04-13 13:53:55 --> Model Class Initialized
INFO - 2018-04-13 13:53:55 --> Final output sent to browser
DEBUG - 2018-04-13 13:53:55 --> Total execution time: 0.0997
INFO - 2018-04-13 08:23:56 --> Config Class Initialized
INFO - 2018-04-13 08:23:56 --> Hooks Class Initialized
DEBUG - 2018-04-13 08:23:56 --> UTF-8 Support Enabled
INFO - 2018-04-13 08:23:56 --> Utf8 Class Initialized
INFO - 2018-04-13 08:23:56 --> URI Class Initialized
INFO - 2018-04-13 08:23:56 --> Config Class Initialized
INFO - 2018-04-13 08:23:56 --> Hooks Class Initialized
INFO - 2018-04-13 08:23:56 --> Router Class Initialized
INFO - 2018-04-13 08:23:56 --> Output Class Initialized
DEBUG - 2018-04-13 08:23:56 --> UTF-8 Support Enabled
INFO - 2018-04-13 08:23:56 --> Utf8 Class Initialized
INFO - 2018-04-13 08:23:56 --> URI Class Initialized
INFO - 2018-04-13 08:23:56 --> Security Class Initialized
DEBUG - 2018-04-13 08:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 08:23:56 --> Input Class Initialized
INFO - 2018-04-13 08:23:56 --> Language Class Initialized
INFO - 2018-04-13 08:23:56 --> Router Class Initialized
INFO - 2018-04-13 08:23:56 --> Output Class Initialized
INFO - 2018-04-13 08:23:56 --> Security Class Initialized
DEBUG - 2018-04-13 08:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 08:23:56 --> Input Class Initialized
INFO - 2018-04-13 08:23:56 --> Language Class Initialized
INFO - 2018-04-13 08:23:56 --> Language Class Initialized
INFO - 2018-04-13 08:23:56 --> Config Class Initialized
INFO - 2018-04-13 08:23:56 --> Loader Class Initialized
INFO - 2018-04-13 13:53:56 --> Helper loaded: url_helper
INFO - 2018-04-13 13:53:56 --> Helper loaded: notification_helper
INFO - 2018-04-13 13:53:56 --> Helper loaded: settings_helper
INFO - 2018-04-13 13:53:56 --> Helper loaded: permission_helper
INFO - 2018-04-13 13:53:56 --> Helper loaded: users_helper
INFO - 2018-04-13 08:23:56 --> Language Class Initialized
INFO - 2018-04-13 08:23:56 --> Config Class Initialized
INFO - 2018-04-13 08:23:56 --> Loader Class Initialized
INFO - 2018-04-13 13:53:56 --> Helper loaded: url_helper
INFO - 2018-04-13 13:53:56 --> Helper loaded: notification_helper
INFO - 2018-04-13 13:53:56 --> Helper loaded: settings_helper
INFO - 2018-04-13 13:53:56 --> Helper loaded: permission_helper
INFO - 2018-04-13 13:53:56 --> Helper loaded: users_helper
INFO - 2018-04-13 13:53:56 --> Database Driver Class Initialized
DEBUG - 2018-04-13 13:53:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 13:53:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 13:53:56 --> Database Driver Class Initialized
INFO - 2018-04-13 13:53:56 --> Helper loaded: form_helper
DEBUG - 2018-04-13 13:53:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 13:53:56 --> Form Validation Class Initialized
INFO - 2018-04-13 13:53:56 --> Controller Class Initialized
INFO - 2018-04-13 13:53:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 13:53:56 --> Helper loaded: form_helper
INFO - 2018-04-13 13:53:56 --> Form Validation Class Initialized
INFO - 2018-04-13 13:53:56 --> Controller Class Initialized
INFO - 2018-04-13 13:53:56 --> Model Class Initialized
INFO - 2018-04-13 13:53:56 --> Helper loaded: inflector_helper
DEBUG - 2018-04-13 13:53:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 08:23:56 --> Config Class Initialized
INFO - 2018-04-13 08:23:56 --> Hooks Class Initialized
INFO - 2018-04-13 13:53:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 13:53:56 --> Model Class Initialized
INFO - 2018-04-13 13:53:56 --> Model Class Initialized
INFO - 2018-04-13 13:53:56 --> Model Class Initialized
INFO - 2018-04-13 13:53:56 --> Model Class Initialized
INFO - 2018-04-13 13:53:56 --> Model Class Initialized
INFO - 2018-04-13 13:53:56 --> Model Class Initialized
INFO - 2018-04-13 13:53:56 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-04-13 08:23:56 --> UTF-8 Support Enabled
INFO - 2018-04-13 08:23:56 --> Utf8 Class Initialized
INFO - 2018-04-13 13:53:56 --> Model Class Initialized
INFO - 2018-04-13 13:53:56 --> Helper loaded: inflector_helper
ERROR - 2018-04-13 13:53:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-04-13 08:23:56 --> URI Class Initialized
INFO - 2018-04-13 13:53:56 --> Final output sent to browser
DEBUG - 2018-04-13 13:53:56 --> Total execution time: 0.1015
DEBUG - 2018-04-13 13:53:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 13:53:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 13:53:56 --> Model Class Initialized
INFO - 2018-04-13 13:53:56 --> Model Class Initialized
INFO - 2018-04-13 08:23:56 --> Router Class Initialized
INFO - 2018-04-13 13:53:56 --> Model Class Initialized
INFO - 2018-04-13 13:53:56 --> Model Class Initialized
INFO - 2018-04-13 13:53:56 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-13 08:23:56 --> Output Class Initialized
INFO - 2018-04-13 13:53:56 --> Final output sent to browser
DEBUG - 2018-04-13 13:53:56 --> Total execution time: 0.1032
INFO - 2018-04-13 08:23:56 --> Security Class Initialized
DEBUG - 2018-04-13 08:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 08:23:56 --> Input Class Initialized
INFO - 2018-04-13 08:23:56 --> Language Class Initialized
INFO - 2018-04-13 08:23:56 --> Language Class Initialized
INFO - 2018-04-13 08:23:56 --> Config Class Initialized
INFO - 2018-04-13 08:23:56 --> Loader Class Initialized
INFO - 2018-04-13 13:53:56 --> Helper loaded: url_helper
INFO - 2018-04-13 13:53:56 --> Helper loaded: notification_helper
INFO - 2018-04-13 13:53:56 --> Helper loaded: settings_helper
INFO - 2018-04-13 13:53:56 --> Helper loaded: permission_helper
INFO - 2018-04-13 13:53:56 --> Helper loaded: users_helper
INFO - 2018-04-13 13:53:56 --> Database Driver Class Initialized
DEBUG - 2018-04-13 13:53:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 13:53:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 13:53:56 --> Helper loaded: form_helper
INFO - 2018-04-13 13:53:56 --> Form Validation Class Initialized
INFO - 2018-04-13 13:53:56 --> Controller Class Initialized
INFO - 2018-04-13 13:53:56 --> Model Class Initialized
INFO - 2018-04-13 13:53:56 --> Helper loaded: inflector_helper
DEBUG - 2018-04-13 13:53:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 13:53:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 13:53:56 --> Model Class Initialized
INFO - 2018-04-13 13:53:56 --> Model Class Initialized
INFO - 2018-04-13 13:53:56 --> Model Class Initialized
INFO - 2018-04-13 13:53:56 --> Model Class Initialized
INFO - 2018-04-13 13:53:56 --> Model Class Initialized
INFO - 2018-04-13 13:53:56 --> Model Class Initialized
INFO - 2018-04-13 13:53:56 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-04-13 13:53:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-04-13 13:53:56 --> Final output sent to browser
DEBUG - 2018-04-13 13:53:56 --> Total execution time: 0.1136
INFO - 2018-04-13 08:24:01 --> Config Class Initialized
INFO - 2018-04-13 08:24:01 --> Hooks Class Initialized
DEBUG - 2018-04-13 08:24:01 --> UTF-8 Support Enabled
INFO - 2018-04-13 08:24:01 --> Utf8 Class Initialized
INFO - 2018-04-13 08:24:01 --> URI Class Initialized
INFO - 2018-04-13 08:24:01 --> Router Class Initialized
INFO - 2018-04-13 08:24:01 --> Output Class Initialized
INFO - 2018-04-13 08:24:01 --> Security Class Initialized
DEBUG - 2018-04-13 08:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 08:24:01 --> Input Class Initialized
INFO - 2018-04-13 08:24:01 --> Language Class Initialized
INFO - 2018-04-13 08:24:01 --> Config Class Initialized
INFO - 2018-04-13 08:24:01 --> Hooks Class Initialized
DEBUG - 2018-04-13 08:24:01 --> UTF-8 Support Enabled
INFO - 2018-04-13 08:24:01 --> Utf8 Class Initialized
INFO - 2018-04-13 08:24:01 --> URI Class Initialized
INFO - 2018-04-13 08:24:01 --> Router Class Initialized
INFO - 2018-04-13 08:24:01 --> Language Class Initialized
INFO - 2018-04-13 08:24:01 --> Config Class Initialized
INFO - 2018-04-13 08:24:01 --> Loader Class Initialized
INFO - 2018-04-13 08:24:01 --> Output Class Initialized
INFO - 2018-04-13 13:54:01 --> Helper loaded: url_helper
INFO - 2018-04-13 13:54:01 --> Helper loaded: notification_helper
INFO - 2018-04-13 13:54:01 --> Helper loaded: settings_helper
INFO - 2018-04-13 08:24:01 --> Security Class Initialized
INFO - 2018-04-13 13:54:01 --> Helper loaded: permission_helper
INFO - 2018-04-13 13:54:01 --> Helper loaded: users_helper
DEBUG - 2018-04-13 08:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 08:24:01 --> Input Class Initialized
INFO - 2018-04-13 08:24:01 --> Language Class Initialized
INFO - 2018-04-13 13:54:01 --> Database Driver Class Initialized
DEBUG - 2018-04-13 13:54:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 13:54:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 08:24:01 --> Language Class Initialized
INFO - 2018-04-13 08:24:01 --> Config Class Initialized
INFO - 2018-04-13 08:24:01 --> Loader Class Initialized
INFO - 2018-04-13 13:54:01 --> Helper loaded: form_helper
INFO - 2018-04-13 13:54:01 --> Form Validation Class Initialized
INFO - 2018-04-13 13:54:01 --> Controller Class Initialized
INFO - 2018-04-13 13:54:01 --> Helper loaded: url_helper
INFO - 2018-04-13 13:54:01 --> Helper loaded: notification_helper
INFO - 2018-04-13 13:54:01 --> Helper loaded: settings_helper
INFO - 2018-04-13 13:54:01 --> Helper loaded: permission_helper
INFO - 2018-04-13 13:54:01 --> Helper loaded: users_helper
INFO - 2018-04-13 13:54:01 --> Model Class Initialized
INFO - 2018-04-13 13:54:01 --> Helper loaded: inflector_helper
DEBUG - 2018-04-13 13:54:01 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 13:54:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 13:54:01 --> Model Class Initialized
INFO - 2018-04-13 13:54:01 --> Model Class Initialized
INFO - 2018-04-13 13:54:01 --> Model Class Initialized
INFO - 2018-04-13 13:54:01 --> Model Class Initialized
INFO - 2018-04-13 13:54:01 --> Model Class Initialized
INFO - 2018-04-13 13:54:01 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-13 13:54:01 --> Model Class Initialized
INFO - 2018-04-13 13:54:01 --> Database Driver Class Initialized
INFO - 2018-04-13 13:54:01 --> Final output sent to browser
DEBUG - 2018-04-13 13:54:01 --> Total execution time: 0.1074
DEBUG - 2018-04-13 13:54:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 13:54:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 13:54:01 --> Helper loaded: form_helper
INFO - 2018-04-13 13:54:01 --> Form Validation Class Initialized
INFO - 2018-04-13 13:54:01 --> Controller Class Initialized
INFO - 2018-04-13 13:54:01 --> Model Class Initialized
INFO - 2018-04-13 13:54:01 --> Helper loaded: inflector_helper
DEBUG - 2018-04-13 13:54:01 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 13:54:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 13:54:01 --> Model Class Initialized
INFO - 2018-04-13 13:54:01 --> Model Class Initialized
INFO - 2018-04-13 13:54:01 --> Model Class Initialized
INFO - 2018-04-13 13:54:01 --> Model Class Initialized
INFO - 2018-04-13 13:54:01 --> Model Class Initialized
INFO - 2018-04-13 13:54:01 --> Model Class Initialized
INFO - 2018-04-13 13:54:01 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-04-13 13:54:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-04-13 13:54:01 --> Final output sent to browser
DEBUG - 2018-04-13 13:54:01 --> Total execution time: 0.1236
INFO - 2018-04-13 08:25:16 --> Config Class Initialized
INFO - 2018-04-13 08:25:16 --> Hooks Class Initialized
DEBUG - 2018-04-13 08:25:16 --> UTF-8 Support Enabled
INFO - 2018-04-13 08:25:16 --> Utf8 Class Initialized
INFO - 2018-04-13 08:25:16 --> Config Class Initialized
INFO - 2018-04-13 08:25:16 --> Hooks Class Initialized
INFO - 2018-04-13 08:25:16 --> URI Class Initialized
DEBUG - 2018-04-13 08:25:16 --> UTF-8 Support Enabled
INFO - 2018-04-13 08:25:16 --> Utf8 Class Initialized
INFO - 2018-04-13 08:25:16 --> URI Class Initialized
INFO - 2018-04-13 08:25:16 --> Router Class Initialized
INFO - 2018-04-13 08:25:16 --> Router Class Initialized
INFO - 2018-04-13 08:25:16 --> Output Class Initialized
INFO - 2018-04-13 08:25:16 --> Output Class Initialized
INFO - 2018-04-13 08:25:16 --> Security Class Initialized
INFO - 2018-04-13 08:25:16 --> Security Class Initialized
DEBUG - 2018-04-13 08:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 08:25:16 --> Input Class Initialized
INFO - 2018-04-13 08:25:16 --> Language Class Initialized
DEBUG - 2018-04-13 08:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 08:25:16 --> Input Class Initialized
INFO - 2018-04-13 08:25:16 --> Language Class Initialized
INFO - 2018-04-13 08:25:16 --> Language Class Initialized
INFO - 2018-04-13 08:25:16 --> Config Class Initialized
INFO - 2018-04-13 08:25:16 --> Loader Class Initialized
INFO - 2018-04-13 13:55:16 --> Helper loaded: url_helper
INFO - 2018-04-13 13:55:16 --> Helper loaded: notification_helper
INFO - 2018-04-13 13:55:16 --> Helper loaded: settings_helper
INFO - 2018-04-13 13:55:16 --> Helper loaded: permission_helper
INFO - 2018-04-13 08:25:16 --> Language Class Initialized
INFO - 2018-04-13 08:25:16 --> Config Class Initialized
INFO - 2018-04-13 08:25:16 --> Loader Class Initialized
INFO - 2018-04-13 13:55:16 --> Helper loaded: users_helper
INFO - 2018-04-13 13:55:16 --> Helper loaded: url_helper
INFO - 2018-04-13 13:55:16 --> Helper loaded: notification_helper
INFO - 2018-04-13 13:55:16 --> Helper loaded: settings_helper
INFO - 2018-04-13 13:55:16 --> Helper loaded: permission_helper
INFO - 2018-04-13 13:55:16 --> Helper loaded: users_helper
INFO - 2018-04-13 13:55:16 --> Database Driver Class Initialized
INFO - 2018-04-13 13:55:16 --> Database Driver Class Initialized
INFO - 2018-04-13 08:25:16 --> Config Class Initialized
INFO - 2018-04-13 08:25:16 --> Hooks Class Initialized
DEBUG - 2018-04-13 13:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 13:55:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-04-13 08:25:16 --> UTF-8 Support Enabled
INFO - 2018-04-13 08:25:16 --> Utf8 Class Initialized
DEBUG - 2018-04-13 13:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 08:25:16 --> URI Class Initialized
INFO - 2018-04-13 13:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 13:55:16 --> Helper loaded: form_helper
INFO - 2018-04-13 08:25:16 --> Router Class Initialized
INFO - 2018-04-13 13:55:16 --> Form Validation Class Initialized
INFO - 2018-04-13 13:55:16 --> Controller Class Initialized
INFO - 2018-04-13 08:25:16 --> Output Class Initialized
INFO - 2018-04-13 13:55:16 --> Helper loaded: form_helper
INFO - 2018-04-13 13:55:16 --> Form Validation Class Initialized
INFO - 2018-04-13 13:55:16 --> Controller Class Initialized
INFO - 2018-04-13 08:25:16 --> Security Class Initialized
INFO - 2018-04-13 13:55:16 --> Model Class Initialized
DEBUG - 2018-04-13 08:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 08:25:16 --> Input Class Initialized
INFO - 2018-04-13 13:55:16 --> Helper loaded: inflector_helper
INFO - 2018-04-13 08:25:16 --> Language Class Initialized
DEBUG - 2018-04-13 13:55:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 13:55:16 --> Model Class Initialized
INFO - 2018-04-13 13:55:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 13:55:16 --> Helper loaded: inflector_helper
INFO - 2018-04-13 13:55:16 --> Model Class Initialized
INFO - 2018-04-13 13:55:16 --> Model Class Initialized
INFO - 2018-04-13 13:55:16 --> Model Class Initialized
INFO - 2018-04-13 13:55:16 --> Model Class Initialized
INFO - 2018-04-13 13:55:16 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-04-13 13:55:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 13:55:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 13:55:16 --> Final output sent to browser
DEBUG - 2018-04-13 13:55:16 --> Total execution time: 0.1052
INFO - 2018-04-13 13:55:16 --> Model Class Initialized
INFO - 2018-04-13 13:55:16 --> Model Class Initialized
INFO - 2018-04-13 13:55:16 --> Model Class Initialized
INFO - 2018-04-13 13:55:16 --> Model Class Initialized
INFO - 2018-04-13 13:55:16 --> Model Class Initialized
INFO - 2018-04-13 13:55:16 --> Model Class Initialized
INFO - 2018-04-13 13:55:16 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-04-13 13:55:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-04-13 13:55:16 --> Final output sent to browser
DEBUG - 2018-04-13 13:55:16 --> Total execution time: 0.1082
INFO - 2018-04-13 08:25:16 --> Language Class Initialized
INFO - 2018-04-13 08:25:16 --> Config Class Initialized
INFO - 2018-04-13 08:25:16 --> Loader Class Initialized
INFO - 2018-04-13 13:55:16 --> Helper loaded: url_helper
INFO - 2018-04-13 13:55:16 --> Helper loaded: notification_helper
INFO - 2018-04-13 13:55:16 --> Helper loaded: settings_helper
INFO - 2018-04-13 13:55:16 --> Helper loaded: permission_helper
INFO - 2018-04-13 13:55:16 --> Helper loaded: users_helper
INFO - 2018-04-13 13:55:16 --> Database Driver Class Initialized
DEBUG - 2018-04-13 13:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 13:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 13:55:16 --> Helper loaded: form_helper
INFO - 2018-04-13 13:55:16 --> Form Validation Class Initialized
INFO - 2018-04-13 13:55:16 --> Controller Class Initialized
INFO - 2018-04-13 13:55:16 --> Model Class Initialized
INFO - 2018-04-13 13:55:16 --> Helper loaded: inflector_helper
DEBUG - 2018-04-13 13:55:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 13:55:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 13:55:16 --> Model Class Initialized
INFO - 2018-04-13 13:55:16 --> Model Class Initialized
INFO - 2018-04-13 13:55:16 --> Model Class Initialized
INFO - 2018-04-13 13:55:16 --> Model Class Initialized
INFO - 2018-04-13 13:55:16 --> Model Class Initialized
INFO - 2018-04-13 13:55:16 --> Model Class Initialized
INFO - 2018-04-13 13:55:16 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-04-13 13:55:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-04-13 13:55:17 --> Final output sent to browser
DEBUG - 2018-04-13 13:55:17 --> Total execution time: 0.1157
INFO - 2018-04-13 08:25:19 --> Config Class Initialized
INFO - 2018-04-13 08:25:19 --> Hooks Class Initialized
DEBUG - 2018-04-13 08:25:19 --> UTF-8 Support Enabled
INFO - 2018-04-13 08:25:19 --> Utf8 Class Initialized
INFO - 2018-04-13 08:25:19 --> URI Class Initialized
INFO - 2018-04-13 08:25:19 --> Config Class Initialized
INFO - 2018-04-13 08:25:19 --> Hooks Class Initialized
DEBUG - 2018-04-13 08:25:19 --> UTF-8 Support Enabled
INFO - 2018-04-13 08:25:19 --> Utf8 Class Initialized
INFO - 2018-04-13 08:25:19 --> Router Class Initialized
INFO - 2018-04-13 08:25:19 --> URI Class Initialized
INFO - 2018-04-13 08:25:19 --> Output Class Initialized
INFO - 2018-04-13 08:25:19 --> Router Class Initialized
INFO - 2018-04-13 08:25:19 --> Security Class Initialized
INFO - 2018-04-13 08:25:19 --> Output Class Initialized
DEBUG - 2018-04-13 08:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 08:25:19 --> Input Class Initialized
INFO - 2018-04-13 08:25:19 --> Language Class Initialized
INFO - 2018-04-13 08:25:19 --> Security Class Initialized
DEBUG - 2018-04-13 08:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 08:25:19 --> Input Class Initialized
INFO - 2018-04-13 08:25:19 --> Language Class Initialized
INFO - 2018-04-13 08:25:19 --> Language Class Initialized
INFO - 2018-04-13 08:25:19 --> Config Class Initialized
INFO - 2018-04-13 08:25:19 --> Loader Class Initialized
INFO - 2018-04-13 13:55:19 --> Helper loaded: url_helper
INFO - 2018-04-13 13:55:19 --> Helper loaded: notification_helper
INFO - 2018-04-13 13:55:19 --> Helper loaded: settings_helper
INFO - 2018-04-13 13:55:19 --> Helper loaded: permission_helper
INFO - 2018-04-13 13:55:19 --> Helper loaded: users_helper
INFO - 2018-04-13 08:25:19 --> Language Class Initialized
INFO - 2018-04-13 08:25:19 --> Config Class Initialized
INFO - 2018-04-13 08:25:19 --> Loader Class Initialized
INFO - 2018-04-13 13:55:19 --> Helper loaded: url_helper
INFO - 2018-04-13 13:55:19 --> Helper loaded: notification_helper
INFO - 2018-04-13 13:55:19 --> Helper loaded: settings_helper
INFO - 2018-04-13 13:55:19 --> Helper loaded: permission_helper
INFO - 2018-04-13 13:55:19 --> Helper loaded: users_helper
INFO - 2018-04-13 13:55:19 --> Database Driver Class Initialized
DEBUG - 2018-04-13 13:55:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 13:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 13:55:19 --> Database Driver Class Initialized
INFO - 2018-04-13 13:55:19 --> Helper loaded: form_helper
INFO - 2018-04-13 13:55:19 --> Form Validation Class Initialized
INFO - 2018-04-13 13:55:19 --> Controller Class Initialized
DEBUG - 2018-04-13 13:55:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 13:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 13:55:19 --> Helper loaded: form_helper
INFO - 2018-04-13 13:55:19 --> Form Validation Class Initialized
INFO - 2018-04-13 13:55:19 --> Controller Class Initialized
INFO - 2018-04-13 13:55:19 --> Model Class Initialized
INFO - 2018-04-13 13:55:19 --> Helper loaded: inflector_helper
DEBUG - 2018-04-13 13:55:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 13:55:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 13:55:19 --> Model Class Initialized
INFO - 2018-04-13 13:55:19 --> Model Class Initialized
INFO - 2018-04-13 13:55:19 --> Model Class Initialized
INFO - 2018-04-13 13:55:19 --> Model Class Initialized
INFO - 2018-04-13 13:55:19 --> Model Class Initialized
INFO - 2018-04-13 13:55:19 --> Model Class Initialized
INFO - 2018-04-13 13:55:19 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-13 13:55:19 --> Helper loaded: inflector_helper
INFO - 2018-04-13 13:55:19 --> Model Class Initialized
DEBUG - 2018-04-13 13:55:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 13:55:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 13:55:19 --> Model Class Initialized
INFO - 2018-04-13 13:55:19 --> Model Class Initialized
INFO - 2018-04-13 13:55:19 --> Final output sent to browser
DEBUG - 2018-04-13 13:55:19 --> Total execution time: 0.1170
INFO - 2018-04-13 13:55:19 --> Model Class Initialized
INFO - 2018-04-13 13:55:19 --> Model Class Initialized
INFO - 2018-04-13 13:55:19 --> Model Class Initialized
INFO - 2018-04-13 13:55:19 --> Model Class Initialized
INFO - 2018-04-13 13:55:19 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-04-13 13:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-04-13 13:55:19 --> Final output sent to browser
DEBUG - 2018-04-13 13:55:19 --> Total execution time: 0.1114
INFO - 2018-04-13 08:25:20 --> Config Class Initialized
INFO - 2018-04-13 08:25:20 --> Hooks Class Initialized
DEBUG - 2018-04-13 08:25:20 --> UTF-8 Support Enabled
INFO - 2018-04-13 08:25:20 --> Utf8 Class Initialized
INFO - 2018-04-13 08:25:20 --> URI Class Initialized
INFO - 2018-04-13 08:25:20 --> Router Class Initialized
INFO - 2018-04-13 08:25:20 --> Output Class Initialized
INFO - 2018-04-13 08:25:20 --> Security Class Initialized
DEBUG - 2018-04-13 08:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 08:25:20 --> Input Class Initialized
INFO - 2018-04-13 08:25:20 --> Language Class Initialized
INFO - 2018-04-13 08:25:20 --> Config Class Initialized
INFO - 2018-04-13 08:25:20 --> Hooks Class Initialized
DEBUG - 2018-04-13 08:25:20 --> UTF-8 Support Enabled
INFO - 2018-04-13 08:25:20 --> Utf8 Class Initialized
INFO - 2018-04-13 08:25:20 --> URI Class Initialized
INFO - 2018-04-13 08:25:20 --> Router Class Initialized
INFO - 2018-04-13 08:25:20 --> Language Class Initialized
INFO - 2018-04-13 08:25:20 --> Config Class Initialized
INFO - 2018-04-13 08:25:20 --> Loader Class Initialized
INFO - 2018-04-13 08:25:20 --> Output Class Initialized
INFO - 2018-04-13 13:55:20 --> Helper loaded: url_helper
INFO - 2018-04-13 13:55:20 --> Helper loaded: notification_helper
INFO - 2018-04-13 08:25:20 --> Security Class Initialized
INFO - 2018-04-13 13:55:20 --> Helper loaded: settings_helper
INFO - 2018-04-13 13:55:20 --> Helper loaded: permission_helper
INFO - 2018-04-13 13:55:20 --> Helper loaded: users_helper
INFO - 2018-04-13 08:25:20 --> Config Class Initialized
INFO - 2018-04-13 08:25:20 --> Hooks Class Initialized
DEBUG - 2018-04-13 08:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 08:25:20 --> Input Class Initialized
INFO - 2018-04-13 08:25:20 --> Language Class Initialized
DEBUG - 2018-04-13 08:25:20 --> UTF-8 Support Enabled
INFO - 2018-04-13 08:25:20 --> Utf8 Class Initialized
INFO - 2018-04-13 08:25:20 --> URI Class Initialized
INFO - 2018-04-13 08:25:20 --> Router Class Initialized
INFO - 2018-04-13 08:25:20 --> Output Class Initialized
INFO - 2018-04-13 13:55:20 --> Database Driver Class Initialized
INFO - 2018-04-13 08:25:20 --> Security Class Initialized
DEBUG - 2018-04-13 08:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 08:25:20 --> Input Class Initialized
INFO - 2018-04-13 08:25:20 --> Language Class Initialized
DEBUG - 2018-04-13 13:55:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 13:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 08:25:20 --> Language Class Initialized
INFO - 2018-04-13 08:25:20 --> Config Class Initialized
INFO - 2018-04-13 08:25:20 --> Loader Class Initialized
INFO - 2018-04-13 13:55:20 --> Helper loaded: url_helper
INFO - 2018-04-13 13:55:20 --> Helper loaded: notification_helper
INFO - 2018-04-13 13:55:20 --> Helper loaded: settings_helper
INFO - 2018-04-13 13:55:20 --> Helper loaded: permission_helper
INFO - 2018-04-13 13:55:20 --> Helper loaded: users_helper
INFO - 2018-04-13 13:55:20 --> Helper loaded: form_helper
INFO - 2018-04-13 13:55:20 --> Form Validation Class Initialized
INFO - 2018-04-13 13:55:20 --> Controller Class Initialized
INFO - 2018-04-13 08:25:20 --> Language Class Initialized
INFO - 2018-04-13 08:25:20 --> Config Class Initialized
INFO - 2018-04-13 08:25:20 --> Loader Class Initialized
INFO - 2018-04-13 13:55:20 --> Model Class Initialized
INFO - 2018-04-13 13:55:20 --> Helper loaded: inflector_helper
INFO - 2018-04-13 13:55:20 --> Helper loaded: url_helper
INFO - 2018-04-13 13:55:20 --> Helper loaded: notification_helper
INFO - 2018-04-13 13:55:20 --> Helper loaded: settings_helper
INFO - 2018-04-13 13:55:20 --> Database Driver Class Initialized
DEBUG - 2018-04-13 13:55:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 13:55:20 --> Helper loaded: permission_helper
INFO - 2018-04-13 13:55:20 --> Helper loaded: users_helper
INFO - 2018-04-13 13:55:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 13:55:20 --> Model Class Initialized
INFO - 2018-04-13 13:55:20 --> Model Class Initialized
INFO - 2018-04-13 13:55:20 --> Model Class Initialized
INFO - 2018-04-13 13:55:20 --> Model Class Initialized
INFO - 2018-04-13 13:55:20 --> Model Class Initialized
DEBUG - 2018-04-13 13:55:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 13:55:20 --> Model Class Initialized
INFO - 2018-04-13 13:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 13:55:20 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-04-13 13:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-04-13 13:55:20 --> Final output sent to browser
DEBUG - 2018-04-13 13:55:20 --> Total execution time: 0.0982
INFO - 2018-04-13 13:55:20 --> Helper loaded: form_helper
INFO - 2018-04-13 13:55:20 --> Form Validation Class Initialized
INFO - 2018-04-13 13:55:20 --> Database Driver Class Initialized
INFO - 2018-04-13 13:55:20 --> Controller Class Initialized
DEBUG - 2018-04-13 13:55:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 13:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 13:55:20 --> Model Class Initialized
INFO - 2018-04-13 13:55:20 --> Helper loaded: inflector_helper
INFO - 2018-04-13 13:55:20 --> Helper loaded: form_helper
INFO - 2018-04-13 13:55:20 --> Form Validation Class Initialized
INFO - 2018-04-13 13:55:20 --> Controller Class Initialized
DEBUG - 2018-04-13 13:55:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 13:55:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 13:55:20 --> Model Class Initialized
INFO - 2018-04-13 13:55:20 --> Model Class Initialized
INFO - 2018-04-13 13:55:20 --> Model Class Initialized
INFO - 2018-04-13 13:55:20 --> Model Class Initialized
INFO - 2018-04-13 13:55:20 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-13 13:55:20 --> Model Class Initialized
INFO - 2018-04-13 13:55:20 --> Helper loaded: inflector_helper
INFO - 2018-04-13 13:55:20 --> Final output sent to browser
DEBUG - 2018-04-13 13:55:20 --> Total execution time: 0.1135
DEBUG - 2018-04-13 13:55:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 13:55:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 13:55:20 --> Model Class Initialized
INFO - 2018-04-13 13:55:20 --> Model Class Initialized
INFO - 2018-04-13 13:55:20 --> Model Class Initialized
INFO - 2018-04-13 13:55:20 --> Model Class Initialized
INFO - 2018-04-13 13:55:20 --> Model Class Initialized
INFO - 2018-04-13 13:55:20 --> Model Class Initialized
INFO - 2018-04-13 13:55:20 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-04-13 13:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-04-13 13:55:20 --> Final output sent to browser
DEBUG - 2018-04-13 13:55:20 --> Total execution time: 0.1014
INFO - 2018-04-13 08:25:25 --> Config Class Initialized
INFO - 2018-04-13 08:25:25 --> Hooks Class Initialized
INFO - 2018-04-13 08:25:25 --> Config Class Initialized
INFO - 2018-04-13 08:25:25 --> Hooks Class Initialized
DEBUG - 2018-04-13 08:25:25 --> UTF-8 Support Enabled
INFO - 2018-04-13 08:25:25 --> Utf8 Class Initialized
INFO - 2018-04-13 08:25:25 --> URI Class Initialized
DEBUG - 2018-04-13 08:25:25 --> UTF-8 Support Enabled
INFO - 2018-04-13 08:25:25 --> Utf8 Class Initialized
INFO - 2018-04-13 08:25:25 --> URI Class Initialized
INFO - 2018-04-13 08:25:25 --> Router Class Initialized
INFO - 2018-04-13 08:25:25 --> Router Class Initialized
INFO - 2018-04-13 08:25:25 --> Output Class Initialized
INFO - 2018-04-13 08:25:25 --> Output Class Initialized
INFO - 2018-04-13 08:25:25 --> Security Class Initialized
INFO - 2018-04-13 08:25:25 --> Security Class Initialized
DEBUG - 2018-04-13 08:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 08:25:25 --> Input Class Initialized
DEBUG - 2018-04-13 08:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 08:25:25 --> Input Class Initialized
INFO - 2018-04-13 08:25:25 --> Language Class Initialized
INFO - 2018-04-13 08:25:25 --> Language Class Initialized
INFO - 2018-04-13 08:25:25 --> Language Class Initialized
INFO - 2018-04-13 08:25:25 --> Config Class Initialized
INFO - 2018-04-13 08:25:25 --> Loader Class Initialized
INFO - 2018-04-13 08:25:25 --> Language Class Initialized
INFO - 2018-04-13 08:25:25 --> Config Class Initialized
INFO - 2018-04-13 08:25:25 --> Loader Class Initialized
INFO - 2018-04-13 13:55:25 --> Helper loaded: url_helper
INFO - 2018-04-13 13:55:25 --> Helper loaded: url_helper
INFO - 2018-04-13 13:55:25 --> Helper loaded: notification_helper
INFO - 2018-04-13 13:55:25 --> Helper loaded: settings_helper
INFO - 2018-04-13 13:55:25 --> Helper loaded: notification_helper
INFO - 2018-04-13 13:55:25 --> Helper loaded: settings_helper
INFO - 2018-04-13 13:55:25 --> Helper loaded: permission_helper
INFO - 2018-04-13 13:55:25 --> Helper loaded: permission_helper
INFO - 2018-04-13 13:55:25 --> Helper loaded: users_helper
INFO - 2018-04-13 13:55:25 --> Helper loaded: users_helper
INFO - 2018-04-13 13:55:25 --> Database Driver Class Initialized
INFO - 2018-04-13 13:55:25 --> Database Driver Class Initialized
DEBUG - 2018-04-13 13:55:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 13:55:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-04-13 13:55:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 13:55:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 13:55:25 --> Helper loaded: form_helper
INFO - 2018-04-13 13:55:25 --> Form Validation Class Initialized
INFO - 2018-04-13 13:55:25 --> Controller Class Initialized
INFO - 2018-04-13 13:55:25 --> Helper loaded: form_helper
INFO - 2018-04-13 13:55:25 --> Form Validation Class Initialized
INFO - 2018-04-13 13:55:25 --> Controller Class Initialized
INFO - 2018-04-13 13:55:25 --> Model Class Initialized
INFO - 2018-04-13 13:55:25 --> Helper loaded: inflector_helper
DEBUG - 2018-04-13 13:55:25 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 13:55:25 --> Model Class Initialized
INFO - 2018-04-13 13:55:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 13:55:25 --> Helper loaded: inflector_helper
INFO - 2018-04-13 13:55:25 --> Model Class Initialized
INFO - 2018-04-13 13:55:25 --> Model Class Initialized
INFO - 2018-04-13 13:55:25 --> Model Class Initialized
INFO - 2018-04-13 13:55:25 --> Model Class Initialized
INFO - 2018-04-13 13:55:25 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-04-13 13:55:25 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 13:55:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 13:55:25 --> Model Class Initialized
INFO - 2018-04-13 13:55:25 --> Model Class Initialized
INFO - 2018-04-13 13:55:25 --> Model Class Initialized
INFO - 2018-04-13 13:55:25 --> Model Class Initialized
INFO - 2018-04-13 13:55:25 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-13 13:55:25 --> Final output sent to browser
INFO - 2018-04-13 13:55:25 --> Final output sent to browser
DEBUG - 2018-04-13 13:55:25 --> Total execution time: 0.1120
DEBUG - 2018-04-13 13:55:25 --> Total execution time: 0.1158
INFO - 2018-04-13 08:25:25 --> Config Class Initialized
INFO - 2018-04-13 08:25:25 --> Hooks Class Initialized
DEBUG - 2018-04-13 08:25:25 --> UTF-8 Support Enabled
INFO - 2018-04-13 08:25:25 --> Utf8 Class Initialized
INFO - 2018-04-13 08:25:25 --> URI Class Initialized
INFO - 2018-04-13 08:25:25 --> Router Class Initialized
INFO - 2018-04-13 08:25:25 --> Output Class Initialized
INFO - 2018-04-13 08:25:25 --> Security Class Initialized
DEBUG - 2018-04-13 08:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 08:25:25 --> Input Class Initialized
INFO - 2018-04-13 08:25:25 --> Language Class Initialized
INFO - 2018-04-13 08:25:25 --> Language Class Initialized
INFO - 2018-04-13 08:25:25 --> Config Class Initialized
INFO - 2018-04-13 08:25:25 --> Loader Class Initialized
INFO - 2018-04-13 13:55:25 --> Helper loaded: url_helper
INFO - 2018-04-13 13:55:25 --> Helper loaded: notification_helper
INFO - 2018-04-13 13:55:25 --> Helper loaded: settings_helper
INFO - 2018-04-13 13:55:25 --> Helper loaded: permission_helper
INFO - 2018-04-13 13:55:25 --> Helper loaded: users_helper
INFO - 2018-04-13 13:55:25 --> Database Driver Class Initialized
DEBUG - 2018-04-13 13:55:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 13:55:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 13:55:25 --> Helper loaded: form_helper
INFO - 2018-04-13 13:55:25 --> Form Validation Class Initialized
INFO - 2018-04-13 13:55:25 --> Controller Class Initialized
INFO - 2018-04-13 13:55:25 --> Model Class Initialized
INFO - 2018-04-13 13:55:25 --> Helper loaded: inflector_helper
DEBUG - 2018-04-13 13:55:25 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 13:55:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 13:55:25 --> Model Class Initialized
INFO - 2018-04-13 13:55:25 --> Model Class Initialized
INFO - 2018-04-13 13:55:25 --> Model Class Initialized
INFO - 2018-04-13 13:55:25 --> Model Class Initialized
INFO - 2018-04-13 13:55:25 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-13 13:55:25 --> Final output sent to browser
DEBUG - 2018-04-13 13:55:25 --> Total execution time: 0.1101
INFO - 2018-04-13 08:25:25 --> Config Class Initialized
INFO - 2018-04-13 08:25:25 --> Hooks Class Initialized
DEBUG - 2018-04-13 08:25:25 --> UTF-8 Support Enabled
INFO - 2018-04-13 08:25:25 --> Utf8 Class Initialized
INFO - 2018-04-13 08:25:25 --> URI Class Initialized
INFO - 2018-04-13 08:25:25 --> Router Class Initialized
INFO - 2018-04-13 08:25:25 --> Output Class Initialized
INFO - 2018-04-13 08:25:25 --> Security Class Initialized
DEBUG - 2018-04-13 08:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 08:25:25 --> Input Class Initialized
INFO - 2018-04-13 08:25:25 --> Language Class Initialized
INFO - 2018-04-13 08:25:25 --> Language Class Initialized
INFO - 2018-04-13 08:25:25 --> Config Class Initialized
INFO - 2018-04-13 08:25:25 --> Loader Class Initialized
INFO - 2018-04-13 13:55:25 --> Helper loaded: url_helper
INFO - 2018-04-13 13:55:25 --> Helper loaded: notification_helper
INFO - 2018-04-13 13:55:25 --> Helper loaded: settings_helper
INFO - 2018-04-13 13:55:25 --> Helper loaded: permission_helper
INFO - 2018-04-13 13:55:25 --> Helper loaded: users_helper
INFO - 2018-04-13 13:55:25 --> Database Driver Class Initialized
DEBUG - 2018-04-13 13:55:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 13:55:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 13:55:25 --> Helper loaded: form_helper
INFO - 2018-04-13 13:55:25 --> Form Validation Class Initialized
INFO - 2018-04-13 13:55:25 --> Controller Class Initialized
INFO - 2018-04-13 13:55:25 --> Model Class Initialized
INFO - 2018-04-13 13:55:25 --> Helper loaded: inflector_helper
DEBUG - 2018-04-13 13:55:25 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 13:55:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 13:55:25 --> Model Class Initialized
INFO - 2018-04-13 13:55:25 --> Model Class Initialized
INFO - 2018-04-13 13:55:25 --> Model Class Initialized
INFO - 2018-04-13 13:55:25 --> Model Class Initialized
INFO - 2018-04-13 13:55:25 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-13 13:55:25 --> Final output sent to browser
DEBUG - 2018-04-13 13:55:25 --> Total execution time: 0.0979
INFO - 2018-04-13 08:25:26 --> Config Class Initialized
INFO - 2018-04-13 08:25:26 --> Hooks Class Initialized
DEBUG - 2018-04-13 08:25:26 --> UTF-8 Support Enabled
INFO - 2018-04-13 08:25:26 --> Utf8 Class Initialized
INFO - 2018-04-13 08:25:26 --> URI Class Initialized
INFO - 2018-04-13 08:25:26 --> Config Class Initialized
INFO - 2018-04-13 08:25:26 --> Hooks Class Initialized
INFO - 2018-04-13 08:25:26 --> Router Class Initialized
DEBUG - 2018-04-13 08:25:26 --> UTF-8 Support Enabled
INFO - 2018-04-13 08:25:26 --> Utf8 Class Initialized
INFO - 2018-04-13 08:25:26 --> URI Class Initialized
INFO - 2018-04-13 08:25:26 --> Output Class Initialized
INFO - 2018-04-13 08:25:26 --> Router Class Initialized
INFO - 2018-04-13 08:25:26 --> Output Class Initialized
INFO - 2018-04-13 08:25:26 --> Security Class Initialized
INFO - 2018-04-13 08:25:26 --> Security Class Initialized
DEBUG - 2018-04-13 08:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 08:25:26 --> Input Class Initialized
INFO - 2018-04-13 08:25:26 --> Language Class Initialized
DEBUG - 2018-04-13 08:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 08:25:26 --> Input Class Initialized
INFO - 2018-04-13 08:25:26 --> Language Class Initialized
INFO - 2018-04-13 08:25:26 --> Language Class Initialized
INFO - 2018-04-13 08:25:26 --> Config Class Initialized
INFO - 2018-04-13 08:25:26 --> Loader Class Initialized
INFO - 2018-04-13 13:55:26 --> Helper loaded: url_helper
INFO - 2018-04-13 13:55:26 --> Helper loaded: notification_helper
INFO - 2018-04-13 13:55:26 --> Helper loaded: settings_helper
INFO - 2018-04-13 13:55:26 --> Helper loaded: permission_helper
INFO - 2018-04-13 13:55:26 --> Helper loaded: users_helper
INFO - 2018-04-13 08:25:26 --> Config Class Initialized
INFO - 2018-04-13 08:25:26 --> Hooks Class Initialized
DEBUG - 2018-04-13 08:25:26 --> UTF-8 Support Enabled
INFO - 2018-04-13 08:25:26 --> Utf8 Class Initialized
INFO - 2018-04-13 08:25:26 --> Language Class Initialized
INFO - 2018-04-13 08:25:26 --> Config Class Initialized
INFO - 2018-04-13 08:25:26 --> Loader Class Initialized
INFO - 2018-04-13 08:25:26 --> URI Class Initialized
INFO - 2018-04-13 13:55:26 --> Helper loaded: url_helper
INFO - 2018-04-13 13:55:26 --> Database Driver Class Initialized
INFO - 2018-04-13 13:55:26 --> Helper loaded: notification_helper
INFO - 2018-04-13 08:25:26 --> Router Class Initialized
INFO - 2018-04-13 13:55:26 --> Helper loaded: settings_helper
INFO - 2018-04-13 13:55:26 --> Helper loaded: permission_helper
INFO - 2018-04-13 13:55:26 --> Helper loaded: users_helper
DEBUG - 2018-04-13 13:55:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 13:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 08:25:26 --> Output Class Initialized
INFO - 2018-04-13 08:25:26 --> Security Class Initialized
DEBUG - 2018-04-13 08:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 08:25:26 --> Input Class Initialized
INFO - 2018-04-13 08:25:26 --> Language Class Initialized
INFO - 2018-04-13 13:55:26 --> Helper loaded: form_helper
INFO - 2018-04-13 13:55:26 --> Form Validation Class Initialized
INFO - 2018-04-13 13:55:26 --> Controller Class Initialized
INFO - 2018-04-13 13:55:26 --> Database Driver Class Initialized
DEBUG - 2018-04-13 13:55:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 13:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 13:55:26 --> Model Class Initialized
INFO - 2018-04-13 13:55:26 --> Helper loaded: inflector_helper
INFO - 2018-04-13 08:25:26 --> Language Class Initialized
INFO - 2018-04-13 08:25:26 --> Config Class Initialized
INFO - 2018-04-13 08:25:26 --> Loader Class Initialized
DEBUG - 2018-04-13 13:55:26 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 13:55:26 --> Helper loaded: url_helper
INFO - 2018-04-13 13:55:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 13:55:27 --> Helper loaded: form_helper
INFO - 2018-04-13 13:55:27 --> Form Validation Class Initialized
INFO - 2018-04-13 13:55:27 --> Controller Class Initialized
INFO - 2018-04-13 13:55:27 --> Helper loaded: notification_helper
INFO - 2018-04-13 13:55:27 --> Helper loaded: settings_helper
INFO - 2018-04-13 13:55:27 --> Model Class Initialized
INFO - 2018-04-13 13:55:27 --> Model Class Initialized
INFO - 2018-04-13 13:55:27 --> Helper loaded: permission_helper
INFO - 2018-04-13 13:55:27 --> Model Class Initialized
INFO - 2018-04-13 13:55:27 --> Model Class Initialized
INFO - 2018-04-13 13:55:27 --> Helper loaded: users_helper
INFO - 2018-04-13 13:55:27 --> Model Class Initialized
INFO - 2018-04-13 13:55:27 --> Model Class Initialized
INFO - 2018-04-13 13:55:27 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-04-13 13:55:27 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-04-13 13:55:27 --> Final output sent to browser
DEBUG - 2018-04-13 13:55:27 --> Total execution time: 0.1150
INFO - 2018-04-13 13:55:27 --> Model Class Initialized
INFO - 2018-04-13 13:55:27 --> Helper loaded: inflector_helper
DEBUG - 2018-04-13 13:55:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 13:55:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 13:55:27 --> Database Driver Class Initialized
INFO - 2018-04-13 13:55:27 --> Model Class Initialized
INFO - 2018-04-13 13:55:27 --> Model Class Initialized
INFO - 2018-04-13 13:55:27 --> Model Class Initialized
INFO - 2018-04-13 13:55:27 --> Model Class Initialized
INFO - 2018-04-13 13:55:27 --> Model Class Initialized
INFO - 2018-04-13 13:55:27 --> Model Class Initialized
INFO - 2018-04-13 13:55:27 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-04-13 13:55:27 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
DEBUG - 2018-04-13 13:55:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 13:55:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 13:55:27 --> Final output sent to browser
DEBUG - 2018-04-13 13:55:27 --> Total execution time: 0.1442
INFO - 2018-04-13 13:55:27 --> Helper loaded: form_helper
INFO - 2018-04-13 13:55:27 --> Form Validation Class Initialized
INFO - 2018-04-13 13:55:27 --> Controller Class Initialized
INFO - 2018-04-13 13:55:27 --> Model Class Initialized
INFO - 2018-04-13 13:55:27 --> Helper loaded: inflector_helper
DEBUG - 2018-04-13 13:55:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 13:55:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 13:55:27 --> Model Class Initialized
INFO - 2018-04-13 13:55:27 --> Model Class Initialized
INFO - 2018-04-13 13:55:27 --> Model Class Initialized
INFO - 2018-04-13 13:55:27 --> Model Class Initialized
INFO - 2018-04-13 13:55:27 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-13 13:55:27 --> Final output sent to browser
DEBUG - 2018-04-13 13:55:27 --> Total execution time: 0.1066
INFO - 2018-04-13 08:25:28 --> Config Class Initialized
INFO - 2018-04-13 08:25:28 --> Hooks Class Initialized
DEBUG - 2018-04-13 08:25:28 --> UTF-8 Support Enabled
INFO - 2018-04-13 08:25:28 --> Utf8 Class Initialized
INFO - 2018-04-13 08:25:28 --> URI Class Initialized
INFO - 2018-04-13 08:25:28 --> Router Class Initialized
INFO - 2018-04-13 08:25:28 --> Output Class Initialized
INFO - 2018-04-13 08:25:28 --> Security Class Initialized
DEBUG - 2018-04-13 08:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 08:25:28 --> Input Class Initialized
INFO - 2018-04-13 08:25:28 --> Language Class Initialized
INFO - 2018-04-13 08:25:28 --> Language Class Initialized
INFO - 2018-04-13 08:25:28 --> Config Class Initialized
INFO - 2018-04-13 08:25:28 --> Loader Class Initialized
INFO - 2018-04-13 13:55:28 --> Helper loaded: url_helper
INFO - 2018-04-13 13:55:28 --> Helper loaded: notification_helper
INFO - 2018-04-13 13:55:28 --> Helper loaded: settings_helper
INFO - 2018-04-13 13:55:28 --> Helper loaded: permission_helper
INFO - 2018-04-13 13:55:28 --> Helper loaded: users_helper
INFO - 2018-04-13 13:55:28 --> Database Driver Class Initialized
DEBUG - 2018-04-13 13:55:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 13:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 13:55:28 --> Helper loaded: form_helper
INFO - 2018-04-13 13:55:28 --> Form Validation Class Initialized
INFO - 2018-04-13 13:55:28 --> Controller Class Initialized
INFO - 2018-04-13 13:55:28 --> Model Class Initialized
INFO - 2018-04-13 13:55:28 --> Helper loaded: inflector_helper
DEBUG - 2018-04-13 13:55:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 13:55:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 13:55:28 --> Model Class Initialized
INFO - 2018-04-13 13:55:28 --> Model Class Initialized
INFO - 2018-04-13 13:55:28 --> Final output sent to browser
DEBUG - 2018-04-13 13:55:28 --> Total execution time: 0.0964
INFO - 2018-04-13 08:25:31 --> Config Class Initialized
INFO - 2018-04-13 08:25:31 --> Hooks Class Initialized
DEBUG - 2018-04-13 08:25:31 --> UTF-8 Support Enabled
INFO - 2018-04-13 08:25:31 --> Utf8 Class Initialized
INFO - 2018-04-13 08:25:31 --> URI Class Initialized
INFO - 2018-04-13 08:25:31 --> Config Class Initialized
INFO - 2018-04-13 08:25:31 --> Hooks Class Initialized
INFO - 2018-04-13 08:25:31 --> Router Class Initialized
DEBUG - 2018-04-13 08:25:31 --> UTF-8 Support Enabled
INFO - 2018-04-13 08:25:31 --> Utf8 Class Initialized
INFO - 2018-04-13 08:25:31 --> Output Class Initialized
INFO - 2018-04-13 08:25:31 --> Security Class Initialized
INFO - 2018-04-13 08:25:31 --> URI Class Initialized
DEBUG - 2018-04-13 08:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 08:25:31 --> Input Class Initialized
INFO - 2018-04-13 08:25:31 --> Language Class Initialized
INFO - 2018-04-13 08:25:31 --> Router Class Initialized
INFO - 2018-04-13 08:25:31 --> Output Class Initialized
INFO - 2018-04-13 08:25:31 --> Security Class Initialized
DEBUG - 2018-04-13 08:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 08:25:31 --> Input Class Initialized
INFO - 2018-04-13 08:25:31 --> Language Class Initialized
INFO - 2018-04-13 08:25:31 --> Language Class Initialized
INFO - 2018-04-13 08:25:31 --> Config Class Initialized
INFO - 2018-04-13 08:25:31 --> Loader Class Initialized
INFO - 2018-04-13 13:55:31 --> Helper loaded: url_helper
INFO - 2018-04-13 13:55:31 --> Helper loaded: notification_helper
INFO - 2018-04-13 13:55:31 --> Helper loaded: settings_helper
INFO - 2018-04-13 13:55:31 --> Helper loaded: permission_helper
INFO - 2018-04-13 13:55:31 --> Helper loaded: users_helper
INFO - 2018-04-13 13:55:31 --> Database Driver Class Initialized
INFO - 2018-04-13 08:25:31 --> Language Class Initialized
INFO - 2018-04-13 08:25:31 --> Config Class Initialized
INFO - 2018-04-13 08:25:31 --> Loader Class Initialized
INFO - 2018-04-13 13:55:31 --> Helper loaded: url_helper
DEBUG - 2018-04-13 13:55:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 13:55:31 --> Helper loaded: notification_helper
INFO - 2018-04-13 13:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 13:55:31 --> Helper loaded: settings_helper
INFO - 2018-04-13 13:55:31 --> Helper loaded: permission_helper
INFO - 2018-04-13 13:55:31 --> Helper loaded: users_helper
INFO - 2018-04-13 13:55:31 --> Helper loaded: form_helper
INFO - 2018-04-13 13:55:31 --> Form Validation Class Initialized
INFO - 2018-04-13 13:55:31 --> Controller Class Initialized
INFO - 2018-04-13 13:55:31 --> Database Driver Class Initialized
INFO - 2018-04-13 13:55:31 --> Model Class Initialized
INFO - 2018-04-13 13:55:31 --> Helper loaded: inflector_helper
DEBUG - 2018-04-13 13:55:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-04-13 13:55:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 13:55:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 13:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 13:55:31 --> Model Class Initialized
INFO - 2018-04-13 13:55:31 --> Model Class Initialized
INFO - 2018-04-13 13:55:31 --> Model Class Initialized
INFO - 2018-04-13 13:55:31 --> Model Class Initialized
INFO - 2018-04-13 13:55:31 --> Model Class Initialized
INFO - 2018-04-13 13:55:31 --> Model Class Initialized
INFO - 2018-04-13 13:55:31 --> Model Class Initialized
INFO - 2018-04-13 13:55:31 --> Model Class Initialized
INFO - 2018-04-13 13:55:31 --> Model Class Initialized
INFO - 2018-04-13 13:55:31 --> Model Class Initialized
INFO - 2018-04-13 13:55:31 --> Model Class Initialized
INFO - 2018-04-13 13:55:31 --> Helper loaded: form_helper
INFO - 2018-04-13 13:55:31 --> Form Validation Class Initialized
INFO - 2018-04-13 13:55:31 --> Controller Class Initialized
INFO - 2018-04-13 13:55:31 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-13 13:55:31 --> Model Class Initialized
INFO - 2018-04-13 13:55:31 --> Model Class Initialized
INFO - 2018-04-13 13:55:31 --> Helper loaded: inflector_helper
INFO - 2018-04-13 13:55:31 --> Final output sent to browser
DEBUG - 2018-04-13 13:55:31 --> Total execution time: 0.1191
DEBUG - 2018-04-13 13:55:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 13:55:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 13:55:31 --> Model Class Initialized
INFO - 2018-04-13 13:55:31 --> Model Class Initialized
INFO - 2018-04-13 13:55:31 --> Model Class Initialized
INFO - 2018-04-13 13:55:31 --> Model Class Initialized
INFO - 2018-04-13 13:55:31 --> Model Class Initialized
INFO - 2018-04-13 13:55:31 --> Model Class Initialized
INFO - 2018-04-13 13:55:31 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-13 13:55:31 --> Model Class Initialized
INFO - 2018-04-13 13:55:31 --> Final output sent to browser
DEBUG - 2018-04-13 13:55:31 --> Total execution time: 0.1281
INFO - 2018-04-13 08:25:32 --> Config Class Initialized
INFO - 2018-04-13 08:25:32 --> Hooks Class Initialized
DEBUG - 2018-04-13 08:25:32 --> UTF-8 Support Enabled
INFO - 2018-04-13 08:25:32 --> Utf8 Class Initialized
INFO - 2018-04-13 08:25:32 --> URI Class Initialized
INFO - 2018-04-13 08:25:32 --> Config Class Initialized
INFO - 2018-04-13 08:25:32 --> Hooks Class Initialized
INFO - 2018-04-13 08:25:32 --> Router Class Initialized
DEBUG - 2018-04-13 08:25:32 --> UTF-8 Support Enabled
INFO - 2018-04-13 08:25:32 --> Utf8 Class Initialized
INFO - 2018-04-13 08:25:32 --> URI Class Initialized
INFO - 2018-04-13 08:25:32 --> Output Class Initialized
INFO - 2018-04-13 08:25:32 --> Router Class Initialized
INFO - 2018-04-13 08:25:32 --> Output Class Initialized
INFO - 2018-04-13 08:25:32 --> Security Class Initialized
INFO - 2018-04-13 08:25:32 --> Security Class Initialized
DEBUG - 2018-04-13 08:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 08:25:32 --> Input Class Initialized
INFO - 2018-04-13 08:25:32 --> Language Class Initialized
DEBUG - 2018-04-13 08:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 08:25:32 --> Input Class Initialized
INFO - 2018-04-13 08:25:32 --> Language Class Initialized
INFO - 2018-04-13 08:25:32 --> Language Class Initialized
INFO - 2018-04-13 08:25:32 --> Config Class Initialized
INFO - 2018-04-13 08:25:32 --> Loader Class Initialized
INFO - 2018-04-13 13:55:32 --> Helper loaded: url_helper
INFO - 2018-04-13 13:55:32 --> Helper loaded: notification_helper
INFO - 2018-04-13 13:55:32 --> Helper loaded: settings_helper
INFO - 2018-04-13 13:55:32 --> Helper loaded: permission_helper
INFO - 2018-04-13 13:55:32 --> Helper loaded: users_helper
INFO - 2018-04-13 08:25:32 --> Language Class Initialized
INFO - 2018-04-13 08:25:32 --> Config Class Initialized
INFO - 2018-04-13 08:25:32 --> Loader Class Initialized
INFO - 2018-04-13 13:55:32 --> Helper loaded: url_helper
INFO - 2018-04-13 13:55:32 --> Helper loaded: notification_helper
INFO - 2018-04-13 13:55:32 --> Helper loaded: settings_helper
INFO - 2018-04-13 13:55:32 --> Helper loaded: permission_helper
INFO - 2018-04-13 13:55:32 --> Helper loaded: users_helper
INFO - 2018-04-13 13:55:32 --> Database Driver Class Initialized
DEBUG - 2018-04-13 13:55:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 13:55:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 13:55:32 --> Database Driver Class Initialized
INFO - 2018-04-13 13:55:32 --> Helper loaded: form_helper
INFO - 2018-04-13 13:55:32 --> Form Validation Class Initialized
DEBUG - 2018-04-13 13:55:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 13:55:32 --> Controller Class Initialized
INFO - 2018-04-13 13:55:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 13:55:32 --> Helper loaded: form_helper
INFO - 2018-04-13 13:55:32 --> Form Validation Class Initialized
INFO - 2018-04-13 13:55:32 --> Controller Class Initialized
INFO - 2018-04-13 13:55:32 --> Model Class Initialized
INFO - 2018-04-13 13:55:32 --> Helper loaded: inflector_helper
INFO - 2018-04-13 13:55:32 --> Model Class Initialized
INFO - 2018-04-13 13:55:32 --> Helper loaded: inflector_helper
DEBUG - 2018-04-13 13:55:32 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 13:55:32 --> Language file loaded: language/english/rest_controller_lang.php
DEBUG - 2018-04-13 13:55:32 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 13:55:32 --> Model Class Initialized
INFO - 2018-04-13 13:55:32 --> Model Class Initialized
INFO - 2018-04-13 13:55:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 13:55:32 --> Model Class Initialized
INFO - 2018-04-13 13:55:32 --> Model Class Initialized
INFO - 2018-04-13 13:55:32 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-13 13:55:32 --> Model Class Initialized
INFO - 2018-04-13 13:55:32 --> Model Class Initialized
INFO - 2018-04-13 13:55:32 --> Model Class Initialized
INFO - 2018-04-13 13:55:32 --> Model Class Initialized
INFO - 2018-04-13 13:55:32 --> Model Class Initialized
INFO - 2018-04-13 13:55:32 --> Model Class Initialized
INFO - 2018-04-13 13:55:32 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-13 13:55:32 --> Final output sent to browser
DEBUG - 2018-04-13 13:55:32 --> Total execution time: 0.1315
ERROR - 2018-04-13 13:55:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-04-13 13:55:32 --> Final output sent to browser
DEBUG - 2018-04-13 13:55:32 --> Total execution time: 0.1046
INFO - 2018-04-13 08:25:33 --> Config Class Initialized
INFO - 2018-04-13 08:25:33 --> Hooks Class Initialized
DEBUG - 2018-04-13 08:25:33 --> UTF-8 Support Enabled
INFO - 2018-04-13 08:25:33 --> Utf8 Class Initialized
INFO - 2018-04-13 08:25:33 --> URI Class Initialized
INFO - 2018-04-13 08:25:33 --> Router Class Initialized
INFO - 2018-04-13 08:25:33 --> Output Class Initialized
INFO - 2018-04-13 08:25:33 --> Security Class Initialized
DEBUG - 2018-04-13 08:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 08:25:33 --> Input Class Initialized
INFO - 2018-04-13 08:25:33 --> Language Class Initialized
INFO - 2018-04-13 08:25:33 --> Language Class Initialized
INFO - 2018-04-13 08:25:33 --> Config Class Initialized
INFO - 2018-04-13 08:25:33 --> Loader Class Initialized
INFO - 2018-04-13 13:55:33 --> Helper loaded: url_helper
INFO - 2018-04-13 13:55:33 --> Helper loaded: notification_helper
INFO - 2018-04-13 13:55:33 --> Helper loaded: settings_helper
INFO - 2018-04-13 13:55:33 --> Helper loaded: permission_helper
INFO - 2018-04-13 13:55:33 --> Helper loaded: users_helper
INFO - 2018-04-13 13:55:33 --> Database Driver Class Initialized
DEBUG - 2018-04-13 13:55:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 13:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 13:55:33 --> Helper loaded: form_helper
INFO - 2018-04-13 13:55:33 --> Form Validation Class Initialized
INFO - 2018-04-13 13:55:33 --> Controller Class Initialized
INFO - 2018-04-13 13:55:33 --> Model Class Initialized
INFO - 2018-04-13 13:55:33 --> Helper loaded: inflector_helper
DEBUG - 2018-04-13 13:55:33 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 13:55:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 13:55:33 --> Model Class Initialized
INFO - 2018-04-13 13:55:33 --> Model Class Initialized
INFO - 2018-04-13 13:55:33 --> Model Class Initialized
INFO - 2018-04-13 13:55:33 --> Model Class Initialized
INFO - 2018-04-13 13:55:33 --> Model Class Initialized
INFO - 2018-04-13 13:55:33 --> Model Class Initialized
INFO - 2018-04-13 13:55:33 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-04-13 13:55:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-04-13 13:55:33 --> Final output sent to browser
DEBUG - 2018-04-13 13:55:33 --> Total execution time: 0.1006
INFO - 2018-04-13 08:31:16 --> Config Class Initialized
INFO - 2018-04-13 08:31:16 --> Hooks Class Initialized
DEBUG - 2018-04-13 08:31:16 --> UTF-8 Support Enabled
INFO - 2018-04-13 08:31:16 --> Utf8 Class Initialized
INFO - 2018-04-13 08:31:16 --> URI Class Initialized
INFO - 2018-04-13 08:31:16 --> Router Class Initialized
INFO - 2018-04-13 08:31:16 --> Output Class Initialized
INFO - 2018-04-13 08:31:16 --> Security Class Initialized
DEBUG - 2018-04-13 08:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 08:31:16 --> Input Class Initialized
INFO - 2018-04-13 08:31:16 --> Language Class Initialized
INFO - 2018-04-13 08:31:16 --> Language Class Initialized
INFO - 2018-04-13 08:31:16 --> Config Class Initialized
INFO - 2018-04-13 08:31:16 --> Loader Class Initialized
INFO - 2018-04-13 14:01:16 --> Helper loaded: url_helper
INFO - 2018-04-13 14:01:16 --> Helper loaded: notification_helper
INFO - 2018-04-13 14:01:16 --> Helper loaded: settings_helper
INFO - 2018-04-13 14:01:16 --> Helper loaded: permission_helper
INFO - 2018-04-13 14:01:16 --> Helper loaded: users_helper
INFO - 2018-04-13 14:01:16 --> Database Driver Class Initialized
DEBUG - 2018-04-13 14:01:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 14:01:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 14:01:16 --> Helper loaded: form_helper
INFO - 2018-04-13 14:01:16 --> Form Validation Class Initialized
INFO - 2018-04-13 14:01:16 --> Controller Class Initialized
INFO - 2018-04-13 08:31:16 --> Config Class Initialized
INFO - 2018-04-13 08:31:16 --> Hooks Class Initialized
INFO - 2018-04-13 14:01:16 --> Model Class Initialized
INFO - 2018-04-13 14:01:16 --> Helper loaded: inflector_helper
DEBUG - 2018-04-13 08:31:16 --> UTF-8 Support Enabled
INFO - 2018-04-13 08:31:16 --> Utf8 Class Initialized
DEBUG - 2018-04-13 14:01:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 08:31:16 --> URI Class Initialized
INFO - 2018-04-13 08:31:16 --> Config Class Initialized
INFO - 2018-04-13 08:31:16 --> Hooks Class Initialized
INFO - 2018-04-13 14:01:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 14:01:16 --> Model Class Initialized
INFO - 2018-04-13 08:31:16 --> Router Class Initialized
DEBUG - 2018-04-13 08:31:16 --> UTF-8 Support Enabled
INFO - 2018-04-13 08:31:16 --> Utf8 Class Initialized
INFO - 2018-04-13 14:01:16 --> Model Class Initialized
INFO - 2018-04-13 14:01:16 --> Model Class Initialized
INFO - 2018-04-13 14:01:16 --> Model Class Initialized
INFO - 2018-04-13 14:01:16 --> Model Class Initialized
INFO - 2018-04-13 14:01:16 --> Model Class Initialized
INFO - 2018-04-13 14:01:16 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-13 08:31:16 --> URI Class Initialized
INFO - 2018-04-13 08:31:16 --> Output Class Initialized
INFO - 2018-04-13 08:31:16 --> Security Class Initialized
INFO - 2018-04-13 14:01:16 --> Final output sent to browser
DEBUG - 2018-04-13 14:01:16 --> Total execution time: 0.1137
INFO - 2018-04-13 08:31:16 --> Router Class Initialized
INFO - 2018-04-13 08:31:16 --> Config Class Initialized
INFO - 2018-04-13 08:31:16 --> Hooks Class Initialized
DEBUG - 2018-04-13 08:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 08:31:16 --> Input Class Initialized
INFO - 2018-04-13 08:31:16 --> Output Class Initialized
INFO - 2018-04-13 08:31:16 --> Language Class Initialized
INFO - 2018-04-13 08:31:16 --> Security Class Initialized
DEBUG - 2018-04-13 08:31:16 --> UTF-8 Support Enabled
INFO - 2018-04-13 08:31:16 --> Utf8 Class Initialized
INFO - 2018-04-13 08:31:16 --> URI Class Initialized
DEBUG - 2018-04-13 08:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 08:31:16 --> Input Class Initialized
INFO - 2018-04-13 08:31:16 --> Language Class Initialized
INFO - 2018-04-13 08:31:16 --> Router Class Initialized
INFO - 2018-04-13 08:31:16 --> Output Class Initialized
INFO - 2018-04-13 08:31:16 --> Security Class Initialized
DEBUG - 2018-04-13 08:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 08:31:16 --> Input Class Initialized
INFO - 2018-04-13 08:31:16 --> Language Class Initialized
INFO - 2018-04-13 08:31:16 --> Config Class Initialized
INFO - 2018-04-13 08:31:16 --> Loader Class Initialized
INFO - 2018-04-13 08:31:16 --> Language Class Initialized
INFO - 2018-04-13 14:01:16 --> Helper loaded: url_helper
INFO - 2018-04-13 14:01:16 --> Helper loaded: notification_helper
INFO - 2018-04-13 14:01:16 --> Helper loaded: settings_helper
INFO - 2018-04-13 14:01:16 --> Helper loaded: permission_helper
INFO - 2018-04-13 14:01:16 --> Helper loaded: users_helper
INFO - 2018-04-13 08:31:16 --> Language Class Initialized
INFO - 2018-04-13 08:31:16 --> Config Class Initialized
INFO - 2018-04-13 08:31:16 --> Loader Class Initialized
INFO - 2018-04-13 14:01:16 --> Helper loaded: url_helper
INFO - 2018-04-13 14:01:16 --> Helper loaded: notification_helper
INFO - 2018-04-13 14:01:16 --> Helper loaded: settings_helper
INFO - 2018-04-13 14:01:16 --> Helper loaded: permission_helper
INFO - 2018-04-13 14:01:16 --> Helper loaded: users_helper
INFO - 2018-04-13 08:31:16 --> Language Class Initialized
INFO - 2018-04-13 08:31:16 --> Config Class Initialized
INFO - 2018-04-13 08:31:16 --> Loader Class Initialized
INFO - 2018-04-13 14:01:16 --> Database Driver Class Initialized
INFO - 2018-04-13 14:01:16 --> Helper loaded: url_helper
INFO - 2018-04-13 14:01:16 --> Helper loaded: notification_helper
INFO - 2018-04-13 14:01:16 --> Helper loaded: settings_helper
INFO - 2018-04-13 14:01:16 --> Helper loaded: permission_helper
INFO - 2018-04-13 14:01:16 --> Helper loaded: users_helper
DEBUG - 2018-04-13 14:01:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 14:01:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 14:01:16 --> Database Driver Class Initialized
DEBUG - 2018-04-13 14:01:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 14:01:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 14:01:16 --> Helper loaded: form_helper
INFO - 2018-04-13 14:01:16 --> Form Validation Class Initialized
INFO - 2018-04-13 14:01:16 --> Controller Class Initialized
INFO - 2018-04-13 14:01:16 --> Database Driver Class Initialized
INFO - 2018-04-13 14:01:16 --> Helper loaded: form_helper
INFO - 2018-04-13 14:01:16 --> Form Validation Class Initialized
INFO - 2018-04-13 14:01:16 --> Controller Class Initialized
INFO - 2018-04-13 14:01:16 --> Model Class Initialized
INFO - 2018-04-13 14:01:16 --> Helper loaded: inflector_helper
DEBUG - 2018-04-13 14:01:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 14:01:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-04-13 14:01:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 14:01:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 14:01:16 --> Model Class Initialized
INFO - 2018-04-13 14:01:16 --> Model Class Initialized
INFO - 2018-04-13 14:01:16 --> Model Class Initialized
INFO - 2018-04-13 14:01:16 --> Model Class Initialized
INFO - 2018-04-13 14:01:16 --> Helper loaded: inflector_helper
INFO - 2018-04-13 14:01:16 --> Model Class Initialized
INFO - 2018-04-13 14:01:16 --> Model Class Initialized
INFO - 2018-04-13 14:01:16 --> Model Class Initialized
INFO - 2018-04-13 14:01:16 --> Model Class Initialized
INFO - 2018-04-13 14:01:16 --> Model Class Initialized
INFO - 2018-04-13 14:01:16 --> Model Class Initialized
INFO - 2018-04-13 14:01:16 --> Model Class Initialized
DEBUG - 2018-04-13 14:01:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 14:01:16 --> Helper loaded: form_helper
INFO - 2018-04-13 14:01:16 --> Form Validation Class Initialized
INFO - 2018-04-13 14:01:16 --> Controller Class Initialized
INFO - 2018-04-13 14:01:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 14:01:16 --> Model Class Initialized
INFO - 2018-04-13 14:01:16 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-13 14:01:16 --> Model Class Initialized
INFO - 2018-04-13 14:01:16 --> Model Class Initialized
INFO - 2018-04-13 14:01:16 --> Model Class Initialized
INFO - 2018-04-13 14:01:16 --> Model Class Initialized
INFO - 2018-04-13 14:01:16 --> Model Class Initialized
INFO - 2018-04-13 14:01:16 --> Model Class Initialized
INFO - 2018-04-13 14:01:16 --> Model Class Initialized
INFO - 2018-04-13 14:01:16 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-13 14:01:16 --> Model Class Initialized
INFO - 2018-04-13 14:01:16 --> Model Class Initialized
INFO - 2018-04-13 14:01:16 --> Final output sent to browser
DEBUG - 2018-04-13 14:01:16 --> Total execution time: 0.1199
INFO - 2018-04-13 14:01:16 --> Helper loaded: inflector_helper
DEBUG - 2018-04-13 14:01:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 14:01:16 --> Final output sent to browser
DEBUG - 2018-04-13 14:01:16 --> Total execution time: 0.1315
INFO - 2018-04-13 14:01:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 14:01:16 --> Model Class Initialized
INFO - 2018-04-13 14:01:16 --> Model Class Initialized
INFO - 2018-04-13 14:01:16 --> Model Class Initialized
INFO - 2018-04-13 14:01:16 --> Model Class Initialized
INFO - 2018-04-13 14:01:16 --> Model Class Initialized
INFO - 2018-04-13 14:01:16 --> Model Class Initialized
INFO - 2018-04-13 14:01:16 --> Model Class Initialized
INFO - 2018-04-13 14:01:16 --> Model Class Initialized
INFO - 2018-04-13 14:01:16 --> Model Class Initialized
INFO - 2018-04-13 14:01:16 --> Model Class Initialized
INFO - 2018-04-13 14:01:16 --> Model Class Initialized
INFO - 2018-04-13 14:01:16 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-13 14:01:16 --> Model Class Initialized
INFO - 2018-04-13 14:01:17 --> Final output sent to browser
DEBUG - 2018-04-13 14:01:17 --> Total execution time: 0.1292
INFO - 2018-04-13 08:31:17 --> Config Class Initialized
INFO - 2018-04-13 08:31:17 --> Hooks Class Initialized
DEBUG - 2018-04-13 08:31:17 --> UTF-8 Support Enabled
INFO - 2018-04-13 08:31:17 --> Utf8 Class Initialized
INFO - 2018-04-13 08:31:17 --> URI Class Initialized
INFO - 2018-04-13 08:31:17 --> Router Class Initialized
INFO - 2018-04-13 08:31:17 --> Output Class Initialized
INFO - 2018-04-13 08:31:17 --> Security Class Initialized
DEBUG - 2018-04-13 08:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 08:31:17 --> Input Class Initialized
INFO - 2018-04-13 08:31:17 --> Language Class Initialized
INFO - 2018-04-13 08:31:17 --> Language Class Initialized
INFO - 2018-04-13 08:31:17 --> Config Class Initialized
INFO - 2018-04-13 08:31:17 --> Loader Class Initialized
INFO - 2018-04-13 14:01:17 --> Helper loaded: url_helper
INFO - 2018-04-13 14:01:17 --> Helper loaded: notification_helper
INFO - 2018-04-13 14:01:17 --> Helper loaded: settings_helper
INFO - 2018-04-13 14:01:17 --> Helper loaded: permission_helper
INFO - 2018-04-13 14:01:17 --> Helper loaded: users_helper
INFO - 2018-04-13 14:01:17 --> Database Driver Class Initialized
DEBUG - 2018-04-13 14:01:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 14:01:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 14:01:17 --> Helper loaded: form_helper
INFO - 2018-04-13 14:01:17 --> Form Validation Class Initialized
INFO - 2018-04-13 14:01:17 --> Controller Class Initialized
INFO - 2018-04-13 14:01:17 --> Model Class Initialized
INFO - 2018-04-13 14:01:17 --> Helper loaded: inflector_helper
DEBUG - 2018-04-13 14:01:17 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 14:01:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 14:01:17 --> Model Class Initialized
INFO - 2018-04-13 14:01:17 --> Model Class Initialized
INFO - 2018-04-13 14:01:17 --> Model Class Initialized
INFO - 2018-04-13 14:01:17 --> Model Class Initialized
INFO - 2018-04-13 14:01:17 --> Model Class Initialized
INFO - 2018-04-13 14:01:17 --> Model Class Initialized
INFO - 2018-04-13 14:01:17 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-13 14:01:17 --> Model Class Initialized
INFO - 2018-04-13 14:01:17 --> Final output sent to browser
DEBUG - 2018-04-13 14:01:17 --> Total execution time: 0.1026
INFO - 2018-04-13 08:31:19 --> Config Class Initialized
INFO - 2018-04-13 08:31:19 --> Hooks Class Initialized
DEBUG - 2018-04-13 08:31:19 --> UTF-8 Support Enabled
INFO - 2018-04-13 08:31:19 --> Utf8 Class Initialized
INFO - 2018-04-13 08:31:19 --> URI Class Initialized
INFO - 2018-04-13 08:31:19 --> Router Class Initialized
INFO - 2018-04-13 08:31:19 --> Output Class Initialized
INFO - 2018-04-13 08:31:19 --> Security Class Initialized
DEBUG - 2018-04-13 08:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 08:31:19 --> Input Class Initialized
INFO - 2018-04-13 08:31:19 --> Language Class Initialized
INFO - 2018-04-13 08:31:19 --> Language Class Initialized
INFO - 2018-04-13 08:31:19 --> Config Class Initialized
INFO - 2018-04-13 08:31:19 --> Loader Class Initialized
INFO - 2018-04-13 14:01:19 --> Helper loaded: url_helper
INFO - 2018-04-13 08:31:19 --> Config Class Initialized
INFO - 2018-04-13 08:31:19 --> Hooks Class Initialized
INFO - 2018-04-13 14:01:19 --> Helper loaded: notification_helper
INFO - 2018-04-13 14:01:19 --> Helper loaded: settings_helper
INFO - 2018-04-13 14:01:19 --> Helper loaded: permission_helper
INFO - 2018-04-13 14:01:19 --> Helper loaded: users_helper
INFO - 2018-04-13 08:31:19 --> Config Class Initialized
INFO - 2018-04-13 08:31:19 --> Hooks Class Initialized
DEBUG - 2018-04-13 08:31:19 --> UTF-8 Support Enabled
INFO - 2018-04-13 08:31:19 --> Utf8 Class Initialized
INFO - 2018-04-13 08:31:19 --> URI Class Initialized
DEBUG - 2018-04-13 08:31:19 --> UTF-8 Support Enabled
INFO - 2018-04-13 08:31:19 --> Utf8 Class Initialized
INFO - 2018-04-13 08:31:19 --> URI Class Initialized
INFO - 2018-04-13 08:31:19 --> Router Class Initialized
INFO - 2018-04-13 08:31:19 --> Router Class Initialized
INFO - 2018-04-13 08:31:19 --> Output Class Initialized
INFO - 2018-04-13 14:01:19 --> Database Driver Class Initialized
INFO - 2018-04-13 08:31:19 --> Output Class Initialized
INFO - 2018-04-13 08:31:19 --> Security Class Initialized
DEBUG - 2018-04-13 14:01:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 14:01:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 08:31:19 --> Security Class Initialized
DEBUG - 2018-04-13 08:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 08:31:19 --> Input Class Initialized
INFO - 2018-04-13 08:31:19 --> Language Class Initialized
DEBUG - 2018-04-13 08:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 08:31:19 --> Input Class Initialized
INFO - 2018-04-13 08:31:19 --> Language Class Initialized
INFO - 2018-04-13 14:01:19 --> Helper loaded: form_helper
INFO - 2018-04-13 14:01:19 --> Form Validation Class Initialized
INFO - 2018-04-13 14:01:19 --> Controller Class Initialized
INFO - 2018-04-13 14:01:19 --> Model Class Initialized
INFO - 2018-04-13 14:01:19 --> Helper loaded: inflector_helper
DEBUG - 2018-04-13 14:01:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 14:01:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 14:01:19 --> Model Class Initialized
INFO - 2018-04-13 14:01:19 --> Model Class Initialized
INFO - 2018-04-13 14:01:19 --> Model Class Initialized
INFO - 2018-04-13 14:01:19 --> Model Class Initialized
INFO - 2018-04-13 14:01:19 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-13 14:01:19 --> Final output sent to browser
DEBUG - 2018-04-13 14:01:19 --> Total execution time: 0.0739
INFO - 2018-04-13 08:31:19 --> Language Class Initialized
INFO - 2018-04-13 08:31:19 --> Config Class Initialized
INFO - 2018-04-13 08:31:19 --> Loader Class Initialized
INFO - 2018-04-13 08:31:19 --> Language Class Initialized
INFO - 2018-04-13 08:31:19 --> Config Class Initialized
INFO - 2018-04-13 08:31:19 --> Loader Class Initialized
INFO - 2018-04-13 14:01:19 --> Helper loaded: url_helper
INFO - 2018-04-13 14:01:19 --> Helper loaded: url_helper
INFO - 2018-04-13 14:01:19 --> Helper loaded: notification_helper
INFO - 2018-04-13 14:01:19 --> Helper loaded: notification_helper
INFO - 2018-04-13 14:01:19 --> Helper loaded: settings_helper
INFO - 2018-04-13 14:01:19 --> Helper loaded: settings_helper
INFO - 2018-04-13 14:01:19 --> Helper loaded: permission_helper
INFO - 2018-04-13 14:01:19 --> Helper loaded: permission_helper
INFO - 2018-04-13 14:01:19 --> Helper loaded: users_helper
INFO - 2018-04-13 14:01:19 --> Helper loaded: users_helper
INFO - 2018-04-13 14:01:19 --> Database Driver Class Initialized
INFO - 2018-04-13 14:01:19 --> Database Driver Class Initialized
DEBUG - 2018-04-13 14:01:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 14:01:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-04-13 14:01:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 14:01:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 14:01:19 --> Helper loaded: form_helper
INFO - 2018-04-13 14:01:19 --> Form Validation Class Initialized
INFO - 2018-04-13 14:01:19 --> Controller Class Initialized
INFO - 2018-04-13 14:01:19 --> Helper loaded: form_helper
INFO - 2018-04-13 14:01:19 --> Form Validation Class Initialized
INFO - 2018-04-13 14:01:19 --> Controller Class Initialized
INFO - 2018-04-13 14:01:19 --> Model Class Initialized
INFO - 2018-04-13 14:01:19 --> Helper loaded: inflector_helper
INFO - 2018-04-13 14:01:19 --> Model Class Initialized
DEBUG - 2018-04-13 14:01:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 14:01:19 --> Helper loaded: inflector_helper
INFO - 2018-04-13 14:01:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 14:01:19 --> Model Class Initialized
INFO - 2018-04-13 14:01:19 --> Model Class Initialized
DEBUG - 2018-04-13 14:01:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 14:01:19 --> Model Class Initialized
INFO - 2018-04-13 14:01:19 --> Model Class Initialized
INFO - 2018-04-13 14:01:19 --> Model Class Initialized
INFO - 2018-04-13 14:01:19 --> Model Class Initialized
INFO - 2018-04-13 14:01:19 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-13 14:01:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 14:01:19 --> Model Class Initialized
INFO - 2018-04-13 14:01:19 --> Model Class Initialized
INFO - 2018-04-13 14:01:19 --> Model Class Initialized
INFO - 2018-04-13 14:01:19 --> Model Class Initialized
INFO - 2018-04-13 14:01:19 --> Model Class Initialized
INFO - 2018-04-13 14:01:19 --> Model Class Initialized
INFO - 2018-04-13 14:01:19 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-04-13 14:01:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-04-13 14:01:19 --> Final output sent to browser
DEBUG - 2018-04-13 14:01:19 --> Total execution time: 0.1016
ERROR - 2018-04-13 14:01:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-04-13 14:01:19 --> Final output sent to browser
DEBUG - 2018-04-13 14:01:19 --> Total execution time: 0.1066
INFO - 2018-04-13 08:31:20 --> Config Class Initialized
INFO - 2018-04-13 08:31:20 --> Hooks Class Initialized
DEBUG - 2018-04-13 08:31:20 --> UTF-8 Support Enabled
INFO - 2018-04-13 08:31:20 --> Utf8 Class Initialized
INFO - 2018-04-13 08:31:20 --> URI Class Initialized
INFO - 2018-04-13 08:31:20 --> Router Class Initialized
INFO - 2018-04-13 08:31:20 --> Output Class Initialized
INFO - 2018-04-13 08:31:20 --> Security Class Initialized
DEBUG - 2018-04-13 08:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 08:31:20 --> Input Class Initialized
INFO - 2018-04-13 08:31:20 --> Language Class Initialized
INFO - 2018-04-13 08:31:20 --> Language Class Initialized
INFO - 2018-04-13 08:31:20 --> Config Class Initialized
INFO - 2018-04-13 08:31:20 --> Loader Class Initialized
INFO - 2018-04-13 14:01:20 --> Helper loaded: url_helper
INFO - 2018-04-13 14:01:20 --> Helper loaded: notification_helper
INFO - 2018-04-13 14:01:20 --> Helper loaded: settings_helper
INFO - 2018-04-13 14:01:20 --> Helper loaded: permission_helper
INFO - 2018-04-13 14:01:20 --> Helper loaded: users_helper
INFO - 2018-04-13 14:01:20 --> Database Driver Class Initialized
DEBUG - 2018-04-13 14:01:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 14:01:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 14:01:20 --> Helper loaded: form_helper
INFO - 2018-04-13 14:01:20 --> Form Validation Class Initialized
INFO - 2018-04-13 14:01:20 --> Controller Class Initialized
INFO - 2018-04-13 14:01:20 --> Model Class Initialized
INFO - 2018-04-13 14:01:20 --> Helper loaded: inflector_helper
DEBUG - 2018-04-13 14:01:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 14:01:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 14:01:20 --> Model Class Initialized
INFO - 2018-04-13 14:01:20 --> Model Class Initialized
INFO - 2018-04-13 14:01:20 --> Model Class Initialized
INFO - 2018-04-13 14:01:20 --> Model Class Initialized
INFO - 2018-04-13 14:01:20 --> Model Class Initialized
INFO - 2018-04-13 14:01:20 --> Model Class Initialized
INFO - 2018-04-13 14:01:20 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-04-13 14:01:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-04-13 14:01:20 --> Final output sent to browser
DEBUG - 2018-04-13 14:01:20 --> Total execution time: 0.0774
INFO - 2018-04-13 08:31:20 --> Config Class Initialized
INFO - 2018-04-13 08:31:20 --> Hooks Class Initialized
DEBUG - 2018-04-13 08:31:20 --> UTF-8 Support Enabled
INFO - 2018-04-13 08:31:20 --> Utf8 Class Initialized
INFO - 2018-04-13 08:31:20 --> URI Class Initialized
INFO - 2018-04-13 08:31:20 --> Router Class Initialized
INFO - 2018-04-13 08:31:20 --> Output Class Initialized
INFO - 2018-04-13 08:31:20 --> Security Class Initialized
DEBUG - 2018-04-13 08:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 08:31:20 --> Input Class Initialized
INFO - 2018-04-13 08:31:20 --> Language Class Initialized
INFO - 2018-04-13 08:31:20 --> Language Class Initialized
INFO - 2018-04-13 08:31:20 --> Config Class Initialized
INFO - 2018-04-13 08:31:20 --> Loader Class Initialized
INFO - 2018-04-13 14:01:20 --> Helper loaded: url_helper
INFO - 2018-04-13 14:01:20 --> Helper loaded: notification_helper
INFO - 2018-04-13 14:01:20 --> Helper loaded: settings_helper
INFO - 2018-04-13 14:01:20 --> Helper loaded: permission_helper
INFO - 2018-04-13 14:01:20 --> Helper loaded: users_helper
INFO - 2018-04-13 14:01:20 --> Database Driver Class Initialized
DEBUG - 2018-04-13 14:01:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 14:01:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 14:01:20 --> Helper loaded: form_helper
INFO - 2018-04-13 14:01:20 --> Form Validation Class Initialized
INFO - 2018-04-13 14:01:20 --> Controller Class Initialized
INFO - 2018-04-13 14:01:20 --> Model Class Initialized
INFO - 2018-04-13 14:01:20 --> Helper loaded: inflector_helper
DEBUG - 2018-04-13 14:01:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 14:01:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 14:01:20 --> Model Class Initialized
INFO - 2018-04-13 14:01:20 --> Model Class Initialized
INFO - 2018-04-13 14:01:20 --> Model Class Initialized
INFO - 2018-04-13 14:01:20 --> Model Class Initialized
INFO - 2018-04-13 14:01:20 --> Model Class Initialized
INFO - 2018-04-13 14:01:20 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-13 14:01:20 --> Model Class Initialized
INFO - 2018-04-13 14:01:20 --> Final output sent to browser
DEBUG - 2018-04-13 14:01:20 --> Total execution time: 0.0940
INFO - 2018-04-13 08:32:04 --> Config Class Initialized
INFO - 2018-04-13 08:32:04 --> Hooks Class Initialized
DEBUG - 2018-04-13 08:32:04 --> UTF-8 Support Enabled
INFO - 2018-04-13 08:32:04 --> Utf8 Class Initialized
INFO - 2018-04-13 08:32:04 --> URI Class Initialized
INFO - 2018-04-13 08:32:04 --> Router Class Initialized
INFO - 2018-04-13 08:32:04 --> Output Class Initialized
INFO - 2018-04-13 08:32:04 --> Security Class Initialized
DEBUG - 2018-04-13 08:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 08:32:04 --> Input Class Initialized
INFO - 2018-04-13 08:32:04 --> Language Class Initialized
INFO - 2018-04-13 08:32:04 --> Language Class Initialized
INFO - 2018-04-13 08:32:04 --> Config Class Initialized
INFO - 2018-04-13 08:32:04 --> Loader Class Initialized
INFO - 2018-04-13 14:02:04 --> Helper loaded: url_helper
INFO - 2018-04-13 14:02:04 --> Helper loaded: notification_helper
INFO - 2018-04-13 14:02:04 --> Helper loaded: settings_helper
INFO - 2018-04-13 14:02:04 --> Helper loaded: permission_helper
INFO - 2018-04-13 14:02:04 --> Helper loaded: users_helper
INFO - 2018-04-13 14:02:04 --> Database Driver Class Initialized
DEBUG - 2018-04-13 14:02:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 14:02:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 14:02:04 --> Helper loaded: form_helper
INFO - 2018-04-13 14:02:04 --> Form Validation Class Initialized
INFO - 2018-04-13 14:02:04 --> Controller Class Initialized
INFO - 2018-04-13 14:02:04 --> Model Class Initialized
INFO - 2018-04-13 14:02:04 --> Helper loaded: inflector_helper
DEBUG - 2018-04-13 14:02:04 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 14:02:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 14:02:04 --> Model Class Initialized
INFO - 2018-04-13 14:02:04 --> Model Class Initialized
INFO - 2018-04-13 14:02:04 --> Model Class Initialized
INFO - 2018-04-13 14:02:04 --> Model Class Initialized
INFO - 2018-04-13 14:02:04 --> Model Class Initialized
INFO - 2018-04-13 14:02:04 --> Model Class Initialized
INFO - 2018-04-13 14:02:04 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-04-13 14:02:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-04-13 08:32:04 --> Config Class Initialized
INFO - 2018-04-13 08:32:04 --> Hooks Class Initialized
INFO - 2018-04-13 14:02:04 --> Final output sent to browser
DEBUG - 2018-04-13 14:02:04 --> Total execution time: 0.1097
DEBUG - 2018-04-13 08:32:04 --> UTF-8 Support Enabled
INFO - 2018-04-13 08:32:04 --> Utf8 Class Initialized
INFO - 2018-04-13 08:32:04 --> URI Class Initialized
INFO - 2018-04-13 08:32:04 --> Router Class Initialized
INFO - 2018-04-13 08:32:04 --> Output Class Initialized
INFO - 2018-04-13 08:32:04 --> Security Class Initialized
DEBUG - 2018-04-13 08:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 08:32:04 --> Input Class Initialized
INFO - 2018-04-13 08:32:04 --> Language Class Initialized
INFO - 2018-04-13 08:32:04 --> Language Class Initialized
INFO - 2018-04-13 08:32:04 --> Config Class Initialized
INFO - 2018-04-13 08:32:04 --> Loader Class Initialized
INFO - 2018-04-13 14:02:04 --> Helper loaded: url_helper
INFO - 2018-04-13 14:02:04 --> Helper loaded: notification_helper
INFO - 2018-04-13 14:02:04 --> Helper loaded: settings_helper
INFO - 2018-04-13 14:02:04 --> Helper loaded: permission_helper
INFO - 2018-04-13 14:02:04 --> Helper loaded: users_helper
INFO - 2018-04-13 14:02:04 --> Database Driver Class Initialized
DEBUG - 2018-04-13 14:02:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 14:02:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 14:02:04 --> Helper loaded: form_helper
INFO - 2018-04-13 14:02:04 --> Form Validation Class Initialized
INFO - 2018-04-13 14:02:04 --> Controller Class Initialized
INFO - 2018-04-13 14:02:04 --> Model Class Initialized
INFO - 2018-04-13 14:02:04 --> Helper loaded: inflector_helper
DEBUG - 2018-04-13 14:02:04 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 14:02:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 14:02:04 --> Model Class Initialized
INFO - 2018-04-13 14:02:04 --> Model Class Initialized
INFO - 2018-04-13 14:02:04 --> Model Class Initialized
INFO - 2018-04-13 14:02:04 --> Model Class Initialized
INFO - 2018-04-13 14:02:04 --> Model Class Initialized
INFO - 2018-04-13 14:02:04 --> Model Class Initialized
INFO - 2018-04-13 14:02:04 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-04-13 14:02:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-04-13 14:02:04 --> Final output sent to browser
DEBUG - 2018-04-13 14:02:04 --> Total execution time: 0.1174
INFO - 2018-04-13 08:32:04 --> Config Class Initialized
INFO - 2018-04-13 08:32:04 --> Hooks Class Initialized
DEBUG - 2018-04-13 08:32:04 --> UTF-8 Support Enabled
INFO - 2018-04-13 08:32:04 --> Utf8 Class Initialized
INFO - 2018-04-13 08:32:04 --> URI Class Initialized
INFO - 2018-04-13 08:32:04 --> Router Class Initialized
INFO - 2018-04-13 08:32:04 --> Output Class Initialized
INFO - 2018-04-13 08:32:04 --> Security Class Initialized
DEBUG - 2018-04-13 08:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 08:32:04 --> Input Class Initialized
INFO - 2018-04-13 08:32:04 --> Language Class Initialized
INFO - 2018-04-13 08:32:04 --> Language Class Initialized
INFO - 2018-04-13 08:32:04 --> Config Class Initialized
INFO - 2018-04-13 08:32:04 --> Loader Class Initialized
INFO - 2018-04-13 14:02:04 --> Helper loaded: url_helper
INFO - 2018-04-13 14:02:04 --> Helper loaded: notification_helper
INFO - 2018-04-13 14:02:04 --> Helper loaded: settings_helper
INFO - 2018-04-13 14:02:05 --> Helper loaded: permission_helper
INFO - 2018-04-13 14:02:05 --> Helper loaded: users_helper
INFO - 2018-04-13 14:02:05 --> Database Driver Class Initialized
DEBUG - 2018-04-13 14:02:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 14:02:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 14:02:05 --> Helper loaded: form_helper
INFO - 2018-04-13 14:02:05 --> Form Validation Class Initialized
INFO - 2018-04-13 14:02:05 --> Controller Class Initialized
INFO - 2018-04-13 14:02:05 --> Model Class Initialized
INFO - 2018-04-13 14:02:05 --> Helper loaded: inflector_helper
DEBUG - 2018-04-13 14:02:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 14:02:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 14:02:05 --> Model Class Initialized
INFO - 2018-04-13 14:02:05 --> Model Class Initialized
INFO - 2018-04-13 14:02:05 --> Model Class Initialized
INFO - 2018-04-13 14:02:05 --> Model Class Initialized
INFO - 2018-04-13 14:02:05 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-13 14:02:05 --> Final output sent to browser
DEBUG - 2018-04-13 14:02:05 --> Total execution time: 0.0945
INFO - 2018-04-13 08:32:06 --> Config Class Initialized
INFO - 2018-04-13 08:32:06 --> Hooks Class Initialized
DEBUG - 2018-04-13 08:32:06 --> UTF-8 Support Enabled
INFO - 2018-04-13 08:32:06 --> Utf8 Class Initialized
INFO - 2018-04-13 08:32:06 --> URI Class Initialized
INFO - 2018-04-13 08:32:06 --> Router Class Initialized
INFO - 2018-04-13 08:32:06 --> Output Class Initialized
INFO - 2018-04-13 08:32:06 --> Security Class Initialized
DEBUG - 2018-04-13 08:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 08:32:06 --> Input Class Initialized
INFO - 2018-04-13 08:32:06 --> Language Class Initialized
INFO - 2018-04-13 08:32:06 --> Language Class Initialized
INFO - 2018-04-13 08:32:06 --> Config Class Initialized
INFO - 2018-04-13 08:32:06 --> Loader Class Initialized
INFO - 2018-04-13 14:02:06 --> Helper loaded: url_helper
INFO - 2018-04-13 14:02:06 --> Helper loaded: notification_helper
INFO - 2018-04-13 14:02:06 --> Helper loaded: settings_helper
INFO - 2018-04-13 14:02:06 --> Helper loaded: permission_helper
INFO - 2018-04-13 14:02:06 --> Helper loaded: users_helper
INFO - 2018-04-13 14:02:06 --> Database Driver Class Initialized
DEBUG - 2018-04-13 14:02:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 14:02:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 14:02:06 --> Helper loaded: form_helper
INFO - 2018-04-13 14:02:06 --> Form Validation Class Initialized
INFO - 2018-04-13 14:02:06 --> Controller Class Initialized
INFO - 2018-04-13 14:02:06 --> Model Class Initialized
INFO - 2018-04-13 14:02:06 --> Helper loaded: inflector_helper
DEBUG - 2018-04-13 14:02:06 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 14:02:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 14:02:06 --> Model Class Initialized
INFO - 2018-04-13 14:02:06 --> Model Class Initialized
INFO - 2018-04-13 14:02:06 --> Final output sent to browser
DEBUG - 2018-04-13 14:02:06 --> Total execution time: 0.1028
INFO - 2018-04-13 08:32:18 --> Config Class Initialized
INFO - 2018-04-13 08:32:18 --> Hooks Class Initialized
DEBUG - 2018-04-13 08:32:18 --> UTF-8 Support Enabled
INFO - 2018-04-13 08:32:18 --> Utf8 Class Initialized
INFO - 2018-04-13 08:32:18 --> URI Class Initialized
INFO - 2018-04-13 08:32:18 --> Router Class Initialized
INFO - 2018-04-13 08:32:18 --> Output Class Initialized
INFO - 2018-04-13 08:32:18 --> Security Class Initialized
DEBUG - 2018-04-13 08:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 08:32:18 --> Input Class Initialized
INFO - 2018-04-13 08:32:18 --> Language Class Initialized
INFO - 2018-04-13 08:32:18 --> Language Class Initialized
INFO - 2018-04-13 08:32:18 --> Config Class Initialized
INFO - 2018-04-13 08:32:18 --> Loader Class Initialized
INFO - 2018-04-13 14:02:18 --> Helper loaded: url_helper
INFO - 2018-04-13 14:02:18 --> Helper loaded: notification_helper
INFO - 2018-04-13 14:02:18 --> Helper loaded: settings_helper
INFO - 2018-04-13 14:02:18 --> Helper loaded: permission_helper
INFO - 2018-04-13 14:02:18 --> Helper loaded: users_helper
INFO - 2018-04-13 14:02:18 --> Database Driver Class Initialized
DEBUG - 2018-04-13 14:02:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 14:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 14:02:18 --> Helper loaded: form_helper
INFO - 2018-04-13 14:02:18 --> Form Validation Class Initialized
INFO - 2018-04-13 14:02:18 --> Controller Class Initialized
INFO - 2018-04-13 14:02:18 --> Model Class Initialized
INFO - 2018-04-13 14:02:18 --> Helper loaded: inflector_helper
DEBUG - 2018-04-13 14:02:18 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 14:02:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 14:02:18 --> Model Class Initialized
INFO - 2018-04-13 14:02:18 --> Model Class Initialized
INFO - 2018-04-13 14:02:18 --> Final output sent to browser
DEBUG - 2018-04-13 14:02:18 --> Total execution time: 0.0715
INFO - 2018-04-13 11:17:58 --> Config Class Initialized
INFO - 2018-04-13 11:17:58 --> Hooks Class Initialized
DEBUG - 2018-04-13 11:17:58 --> UTF-8 Support Enabled
INFO - 2018-04-13 11:17:58 --> Utf8 Class Initialized
INFO - 2018-04-13 11:17:58 --> URI Class Initialized
DEBUG - 2018-04-13 11:17:58 --> No URI present. Default controller set.
INFO - 2018-04-13 11:17:58 --> Router Class Initialized
INFO - 2018-04-13 11:17:58 --> Output Class Initialized
INFO - 2018-04-13 11:17:58 --> Security Class Initialized
DEBUG - 2018-04-13 11:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 11:17:58 --> Input Class Initialized
INFO - 2018-04-13 11:17:58 --> Language Class Initialized
INFO - 2018-04-13 11:17:58 --> Language Class Initialized
INFO - 2018-04-13 11:17:58 --> Config Class Initialized
INFO - 2018-04-13 11:17:58 --> Loader Class Initialized
INFO - 2018-04-13 16:47:58 --> Helper loaded: url_helper
INFO - 2018-04-13 16:47:58 --> Helper loaded: notification_helper
INFO - 2018-04-13 16:47:58 --> Helper loaded: settings_helper
INFO - 2018-04-13 16:47:58 --> Helper loaded: permission_helper
INFO - 2018-04-13 16:47:58 --> Helper loaded: users_helper
INFO - 2018-04-13 16:47:58 --> Database Driver Class Initialized
DEBUG - 2018-04-13 16:47:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 16:47:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 16:47:58 --> Helper loaded: form_helper
INFO - 2018-04-13 16:47:58 --> Form Validation Class Initialized
INFO - 2018-04-13 16:47:58 --> Controller Class Initialized
INFO - 2018-04-13 16:47:58 --> Model Class Initialized
INFO - 2018-04-13 16:47:58 --> Helper loaded: inflector_helper
INFO - 2018-04-13 16:47:58 --> Model Class Initialized
DEBUG - 2018-04-13 16:47:58 --> File loaded: /home/pr01004/public_html/application/views/login.php
INFO - 2018-04-13 16:47:58 --> Final output sent to browser
DEBUG - 2018-04-13 16:47:58 --> Total execution time: 0.0833
INFO - 2018-04-13 12:25:28 --> Config Class Initialized
INFO - 2018-04-13 12:25:28 --> Hooks Class Initialized
DEBUG - 2018-04-13 12:25:28 --> UTF-8 Support Enabled
INFO - 2018-04-13 12:25:28 --> Utf8 Class Initialized
INFO - 2018-04-13 12:25:28 --> URI Class Initialized
INFO - 2018-04-13 12:25:28 --> Router Class Initialized
INFO - 2018-04-13 12:25:28 --> Output Class Initialized
INFO - 2018-04-13 12:25:28 --> Security Class Initialized
DEBUG - 2018-04-13 12:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 12:25:28 --> Input Class Initialized
INFO - 2018-04-13 12:25:28 --> Language Class Initialized
INFO - 2018-04-13 12:25:28 --> Config Class Initialized
INFO - 2018-04-13 12:25:28 --> Hooks Class Initialized
DEBUG - 2018-04-13 12:25:28 --> UTF-8 Support Enabled
INFO - 2018-04-13 12:25:28 --> Utf8 Class Initialized
INFO - 2018-04-13 12:25:28 --> Language Class Initialized
INFO - 2018-04-13 12:25:28 --> Config Class Initialized
INFO - 2018-04-13 12:25:28 --> Loader Class Initialized
INFO - 2018-04-13 12:25:28 --> URI Class Initialized
INFO - 2018-04-13 17:55:28 --> Helper loaded: url_helper
INFO - 2018-04-13 17:55:28 --> Helper loaded: notification_helper
INFO - 2018-04-13 17:55:28 --> Helper loaded: settings_helper
INFO - 2018-04-13 12:25:28 --> Router Class Initialized
INFO - 2018-04-13 17:55:28 --> Helper loaded: permission_helper
INFO - 2018-04-13 17:55:28 --> Helper loaded: users_helper
INFO - 2018-04-13 12:25:28 --> Output Class Initialized
INFO - 2018-04-13 12:25:28 --> Security Class Initialized
DEBUG - 2018-04-13 12:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 12:25:28 --> Input Class Initialized
INFO - 2018-04-13 12:25:28 --> Language Class Initialized
INFO - 2018-04-13 17:55:28 --> Database Driver Class Initialized
DEBUG - 2018-04-13 17:55:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 17:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 12:25:28 --> Config Class Initialized
INFO - 2018-04-13 12:25:28 --> Hooks Class Initialized
INFO - 2018-04-13 12:25:28 --> Language Class Initialized
INFO - 2018-04-13 12:25:28 --> Config Class Initialized
INFO - 2018-04-13 12:25:28 --> Loader Class Initialized
INFO - 2018-04-13 17:55:28 --> Helper loaded: form_helper
INFO - 2018-04-13 17:55:28 --> Form Validation Class Initialized
INFO - 2018-04-13 17:55:28 --> Controller Class Initialized
DEBUG - 2018-04-13 12:25:28 --> UTF-8 Support Enabled
INFO - 2018-04-13 12:25:28 --> Utf8 Class Initialized
INFO - 2018-04-13 17:55:28 --> Helper loaded: url_helper
INFO - 2018-04-13 17:55:28 --> Helper loaded: notification_helper
INFO - 2018-04-13 17:55:28 --> Helper loaded: settings_helper
INFO - 2018-04-13 12:25:28 --> URI Class Initialized
INFO - 2018-04-13 17:55:28 --> Helper loaded: permission_helper
INFO - 2018-04-13 17:55:28 --> Helper loaded: users_helper
INFO - 2018-04-13 17:55:28 --> Model Class Initialized
INFO - 2018-04-13 17:55:28 --> Helper loaded: inflector_helper
INFO - 2018-04-13 12:25:28 --> Router Class Initialized
DEBUG - 2018-04-13 17:55:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 17:55:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 17:55:28 --> Model Class Initialized
INFO - 2018-04-13 17:55:28 --> Model Class Initialized
INFO - 2018-04-13 17:55:28 --> Model Class Initialized
INFO - 2018-04-13 17:55:28 --> Model Class Initialized
INFO - 2018-04-13 17:55:28 --> Model Class Initialized
INFO - 2018-04-13 17:55:28 --> Model Class Initialized
INFO - 2018-04-13 17:55:28 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-13 12:25:28 --> Output Class Initialized
INFO - 2018-04-13 17:55:28 --> Final output sent to browser
DEBUG - 2018-04-13 17:55:28 --> Total execution time: 0.1310
INFO - 2018-04-13 12:25:28 --> Security Class Initialized
DEBUG - 2018-04-13 12:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 12:25:28 --> Input Class Initialized
INFO - 2018-04-13 12:25:28 --> Language Class Initialized
INFO - 2018-04-13 17:55:28 --> Database Driver Class Initialized
INFO - 2018-04-13 12:25:28 --> Config Class Initialized
INFO - 2018-04-13 12:25:28 --> Hooks Class Initialized
DEBUG - 2018-04-13 17:55:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 17:55:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-04-13 12:25:28 --> UTF-8 Support Enabled
INFO - 2018-04-13 12:25:28 --> Utf8 Class Initialized
INFO - 2018-04-13 12:25:28 --> URI Class Initialized
INFO - 2018-04-13 17:55:28 --> Helper loaded: form_helper
INFO - 2018-04-13 17:55:28 --> Form Validation Class Initialized
INFO - 2018-04-13 17:55:28 --> Controller Class Initialized
INFO - 2018-04-13 12:25:28 --> Router Class Initialized
INFO - 2018-04-13 12:25:28 --> Output Class Initialized
INFO - 2018-04-13 12:25:28 --> Language Class Initialized
INFO - 2018-04-13 12:25:28 --> Config Class Initialized
INFO - 2018-04-13 12:25:28 --> Loader Class Initialized
INFO - 2018-04-13 17:55:28 --> Helper loaded: url_helper
INFO - 2018-04-13 12:25:28 --> Security Class Initialized
INFO - 2018-04-13 17:55:28 --> Model Class Initialized
INFO - 2018-04-13 17:55:28 --> Helper loaded: notification_helper
INFO - 2018-04-13 17:55:28 --> Helper loaded: inflector_helper
INFO - 2018-04-13 17:55:28 --> Helper loaded: settings_helper
INFO - 2018-04-13 17:55:28 --> Helper loaded: permission_helper
DEBUG - 2018-04-13 12:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 12:25:28 --> Input Class Initialized
INFO - 2018-04-13 17:55:28 --> Helper loaded: users_helper
INFO - 2018-04-13 12:25:28 --> Language Class Initialized
DEBUG - 2018-04-13 17:55:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 17:55:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 17:55:28 --> Model Class Initialized
INFO - 2018-04-13 17:55:28 --> Model Class Initialized
INFO - 2018-04-13 17:55:28 --> Model Class Initialized
INFO - 2018-04-13 17:55:28 --> Model Class Initialized
INFO - 2018-04-13 17:55:28 --> Model Class Initialized
INFO - 2018-04-13 17:55:28 --> Model Class Initialized
INFO - 2018-04-13 17:55:28 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-13 17:55:28 --> Model Class Initialized
INFO - 2018-04-13 17:55:28 --> Final output sent to browser
DEBUG - 2018-04-13 17:55:28 --> Total execution time: 0.1997
INFO - 2018-04-13 17:55:28 --> Database Driver Class Initialized
INFO - 2018-04-13 12:25:28 --> Language Class Initialized
INFO - 2018-04-13 12:25:28 --> Config Class Initialized
INFO - 2018-04-13 12:25:28 --> Loader Class Initialized
DEBUG - 2018-04-13 17:55:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 17:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 17:55:28 --> Helper loaded: url_helper
INFO - 2018-04-13 17:55:28 --> Helper loaded: notification_helper
INFO - 2018-04-13 17:55:28 --> Helper loaded: settings_helper
INFO - 2018-04-13 17:55:28 --> Helper loaded: permission_helper
INFO - 2018-04-13 17:55:28 --> Helper loaded: users_helper
INFO - 2018-04-13 17:55:28 --> Helper loaded: form_helper
INFO - 2018-04-13 17:55:28 --> Form Validation Class Initialized
INFO - 2018-04-13 17:55:28 --> Controller Class Initialized
INFO - 2018-04-13 17:55:28 --> Model Class Initialized
INFO - 2018-04-13 17:55:28 --> Helper loaded: inflector_helper
INFO - 2018-04-13 17:55:28 --> Database Driver Class Initialized
DEBUG - 2018-04-13 17:55:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 17:55:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 17:55:28 --> Model Class Initialized
INFO - 2018-04-13 17:55:28 --> Model Class Initialized
INFO - 2018-04-13 17:55:28 --> Model Class Initialized
INFO - 2018-04-13 17:55:28 --> Model Class Initialized
INFO - 2018-04-13 17:55:28 --> Model Class Initialized
INFO - 2018-04-13 17:55:28 --> Model Class Initialized
INFO - 2018-04-13 17:55:28 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-04-13 17:55:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 17:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 17:55:28 --> Model Class Initialized
INFO - 2018-04-13 17:55:28 --> Final output sent to browser
DEBUG - 2018-04-13 17:55:28 --> Total execution time: 0.2694
INFO - 2018-04-13 17:55:28 --> Helper loaded: form_helper
INFO - 2018-04-13 17:55:28 --> Form Validation Class Initialized
INFO - 2018-04-13 17:55:28 --> Controller Class Initialized
INFO - 2018-04-13 12:25:28 --> Config Class Initialized
INFO - 2018-04-13 12:25:28 --> Hooks Class Initialized
DEBUG - 2018-04-13 12:25:28 --> UTF-8 Support Enabled
INFO - 2018-04-13 12:25:28 --> Utf8 Class Initialized
INFO - 2018-04-13 12:25:28 --> URI Class Initialized
INFO - 2018-04-13 12:25:28 --> Router Class Initialized
INFO - 2018-04-13 17:55:28 --> Model Class Initialized
INFO - 2018-04-13 17:55:28 --> Helper loaded: inflector_helper
INFO - 2018-04-13 12:25:28 --> Output Class Initialized
INFO - 2018-04-13 12:25:28 --> Security Class Initialized
DEBUG - 2018-04-13 17:55:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 17:55:28 --> Language file loaded: language/english/rest_controller_lang.php
DEBUG - 2018-04-13 12:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 12:25:28 --> Input Class Initialized
INFO - 2018-04-13 17:55:28 --> Model Class Initialized
INFO - 2018-04-13 17:55:28 --> Model Class Initialized
INFO - 2018-04-13 12:25:28 --> Language Class Initialized
INFO - 2018-04-13 17:55:28 --> Model Class Initialized
INFO - 2018-04-13 17:55:28 --> Model Class Initialized
INFO - 2018-04-13 17:55:28 --> Model Class Initialized
INFO - 2018-04-13 17:55:28 --> Model Class Initialized
INFO - 2018-04-13 17:55:28 --> Model Class Initialized
INFO - 2018-04-13 17:55:28 --> Model Class Initialized
INFO - 2018-04-13 17:55:28 --> Model Class Initialized
INFO - 2018-04-13 17:55:28 --> Model Class Initialized
INFO - 2018-04-13 17:55:28 --> Model Class Initialized
INFO - 2018-04-13 17:55:28 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-13 17:55:28 --> Model Class Initialized
INFO - 2018-04-13 12:25:28 --> Language Class Initialized
INFO - 2018-04-13 12:25:28 --> Config Class Initialized
INFO - 2018-04-13 12:25:28 --> Loader Class Initialized
INFO - 2018-04-13 17:55:28 --> Helper loaded: url_helper
INFO - 2018-04-13 17:55:28 --> Helper loaded: notification_helper
INFO - 2018-04-13 17:55:28 --> Helper loaded: settings_helper
INFO - 2018-04-13 17:55:28 --> Helper loaded: permission_helper
INFO - 2018-04-13 17:55:28 --> Helper loaded: users_helper
INFO - 2018-04-13 17:55:28 --> Final output sent to browser
DEBUG - 2018-04-13 17:55:28 --> Total execution time: 0.3346
INFO - 2018-04-13 17:55:28 --> Database Driver Class Initialized
DEBUG - 2018-04-13 17:55:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 17:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 17:55:28 --> Helper loaded: form_helper
INFO - 2018-04-13 17:55:28 --> Form Validation Class Initialized
INFO - 2018-04-13 17:55:28 --> Controller Class Initialized
INFO - 2018-04-13 17:55:28 --> Model Class Initialized
INFO - 2018-04-13 17:55:28 --> Helper loaded: inflector_helper
DEBUG - 2018-04-13 17:55:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 17:55:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 17:55:28 --> Model Class Initialized
INFO - 2018-04-13 17:55:28 --> Model Class Initialized
INFO - 2018-04-13 17:55:28 --> Model Class Initialized
INFO - 2018-04-13 17:55:28 --> Model Class Initialized
INFO - 2018-04-13 17:55:28 --> Model Class Initialized
INFO - 2018-04-13 17:55:28 --> Model Class Initialized
INFO - 2018-04-13 17:55:28 --> Model Class Initialized
INFO - 2018-04-13 17:55:28 --> Model Class Initialized
INFO - 2018-04-13 17:55:28 --> Model Class Initialized
INFO - 2018-04-13 17:55:28 --> Model Class Initialized
INFO - 2018-04-13 17:55:28 --> Model Class Initialized
INFO - 2018-04-13 17:55:28 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-13 17:55:28 --> Model Class Initialized
INFO - 2018-04-13 17:55:28 --> Final output sent to browser
DEBUG - 2018-04-13 17:55:28 --> Total execution time: 0.1828
INFO - 2018-04-13 12:25:30 --> Config Class Initialized
INFO - 2018-04-13 12:25:30 --> Hooks Class Initialized
DEBUG - 2018-04-13 12:25:30 --> UTF-8 Support Enabled
INFO - 2018-04-13 12:25:30 --> Utf8 Class Initialized
INFO - 2018-04-13 12:25:30 --> URI Class Initialized
INFO - 2018-04-13 12:25:30 --> Router Class Initialized
INFO - 2018-04-13 12:25:30 --> Output Class Initialized
INFO - 2018-04-13 12:25:30 --> Security Class Initialized
DEBUG - 2018-04-13 12:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 12:25:30 --> Input Class Initialized
INFO - 2018-04-13 12:25:30 --> Language Class Initialized
INFO - 2018-04-13 12:25:30 --> Language Class Initialized
INFO - 2018-04-13 12:25:30 --> Config Class Initialized
INFO - 2018-04-13 12:25:30 --> Loader Class Initialized
INFO - 2018-04-13 17:55:30 --> Helper loaded: url_helper
INFO - 2018-04-13 17:55:30 --> Helper loaded: notification_helper
INFO - 2018-04-13 17:55:30 --> Helper loaded: settings_helper
INFO - 2018-04-13 17:55:30 --> Helper loaded: permission_helper
INFO - 2018-04-13 17:55:30 --> Helper loaded: users_helper
INFO - 2018-04-13 17:55:30 --> Database Driver Class Initialized
INFO - 2018-04-13 12:25:30 --> Config Class Initialized
INFO - 2018-04-13 12:25:30 --> Hooks Class Initialized
DEBUG - 2018-04-13 17:55:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 17:55:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-04-13 12:25:30 --> UTF-8 Support Enabled
INFO - 2018-04-13 12:25:30 --> Utf8 Class Initialized
INFO - 2018-04-13 17:55:30 --> Helper loaded: form_helper
INFO - 2018-04-13 17:55:30 --> Form Validation Class Initialized
INFO - 2018-04-13 17:55:30 --> Controller Class Initialized
INFO - 2018-04-13 12:25:30 --> URI Class Initialized
INFO - 2018-04-13 17:55:30 --> Model Class Initialized
INFO - 2018-04-13 12:25:30 --> Router Class Initialized
INFO - 2018-04-13 17:55:30 --> Helper loaded: inflector_helper
DEBUG - 2018-04-13 17:55:30 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 12:25:30 --> Output Class Initialized
INFO - 2018-04-13 17:55:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 17:55:30 --> Model Class Initialized
INFO - 2018-04-13 17:55:30 --> Model Class Initialized
INFO - 2018-04-13 17:55:30 --> Model Class Initialized
INFO - 2018-04-13 17:55:30 --> Model Class Initialized
INFO - 2018-04-13 17:55:30 --> Model Class Initialized
INFO - 2018-04-13 17:55:30 --> Model Class Initialized
INFO - 2018-04-13 17:55:30 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-04-13 17:55:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-04-13 17:55:30 --> Final output sent to browser
DEBUG - 2018-04-13 17:55:30 --> Total execution time: 0.1173
INFO - 2018-04-13 12:25:30 --> Security Class Initialized
DEBUG - 2018-04-13 12:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 12:25:30 --> Input Class Initialized
INFO - 2018-04-13 12:25:30 --> Language Class Initialized
INFO - 2018-04-13 12:25:30 --> Language Class Initialized
INFO - 2018-04-13 12:25:30 --> Config Class Initialized
INFO - 2018-04-13 12:25:30 --> Loader Class Initialized
INFO - 2018-04-13 17:55:30 --> Helper loaded: url_helper
INFO - 2018-04-13 17:55:30 --> Helper loaded: notification_helper
INFO - 2018-04-13 17:55:30 --> Helper loaded: settings_helper
INFO - 2018-04-13 17:55:30 --> Helper loaded: permission_helper
INFO - 2018-04-13 17:55:30 --> Helper loaded: users_helper
INFO - 2018-04-13 12:25:30 --> Config Class Initialized
INFO - 2018-04-13 12:25:30 --> Hooks Class Initialized
INFO - 2018-04-13 17:55:30 --> Database Driver Class Initialized
DEBUG - 2018-04-13 12:25:30 --> UTF-8 Support Enabled
INFO - 2018-04-13 12:25:30 --> Utf8 Class Initialized
INFO - 2018-04-13 12:25:30 --> URI Class Initialized
INFO - 2018-04-13 12:25:30 --> Router Class Initialized
DEBUG - 2018-04-13 17:55:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 17:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 12:25:30 --> Output Class Initialized
INFO - 2018-04-13 12:25:30 --> Security Class Initialized
DEBUG - 2018-04-13 12:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 12:25:30 --> Input Class Initialized
INFO - 2018-04-13 12:25:30 --> Language Class Initialized
INFO - 2018-04-13 17:55:30 --> Helper loaded: form_helper
INFO - 2018-04-13 17:55:30 --> Form Validation Class Initialized
INFO - 2018-04-13 17:55:30 --> Controller Class Initialized
INFO - 2018-04-13 12:25:30 --> Language Class Initialized
INFO - 2018-04-13 12:25:30 --> Config Class Initialized
INFO - 2018-04-13 12:25:30 --> Loader Class Initialized
INFO - 2018-04-13 17:55:30 --> Helper loaded: url_helper
INFO - 2018-04-13 17:55:30 --> Helper loaded: notification_helper
INFO - 2018-04-13 17:55:30 --> Helper loaded: settings_helper
INFO - 2018-04-13 17:55:30 --> Helper loaded: permission_helper
INFO - 2018-04-13 17:55:30 --> Helper loaded: users_helper
INFO - 2018-04-13 17:55:30 --> Model Class Initialized
INFO - 2018-04-13 17:55:30 --> Helper loaded: inflector_helper
DEBUG - 2018-04-13 17:55:30 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 17:55:30 --> Database Driver Class Initialized
DEBUG - 2018-04-13 17:55:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 17:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 17:55:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 17:55:30 --> Model Class Initialized
INFO - 2018-04-13 17:55:30 --> Model Class Initialized
INFO - 2018-04-13 17:55:30 --> Model Class Initialized
INFO - 2018-04-13 17:55:30 --> Model Class Initialized
INFO - 2018-04-13 17:55:30 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-13 17:55:30 --> Helper loaded: form_helper
INFO - 2018-04-13 17:55:30 --> Form Validation Class Initialized
INFO - 2018-04-13 17:55:30 --> Controller Class Initialized
INFO - 2018-04-13 17:55:30 --> Final output sent to browser
DEBUG - 2018-04-13 17:55:30 --> Total execution time: 0.2220
INFO - 2018-04-13 17:55:30 --> Model Class Initialized
INFO - 2018-04-13 17:55:30 --> Helper loaded: inflector_helper
DEBUG - 2018-04-13 17:55:30 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 17:55:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 17:55:30 --> Model Class Initialized
INFO - 2018-04-13 17:55:30 --> Model Class Initialized
INFO - 2018-04-13 17:55:30 --> Model Class Initialized
INFO - 2018-04-13 17:55:30 --> Model Class Initialized
INFO - 2018-04-13 17:55:30 --> Model Class Initialized
INFO - 2018-04-13 17:55:30 --> Model Class Initialized
INFO - 2018-04-13 17:55:30 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-04-13 17:55:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-04-13 17:55:30 --> Final output sent to browser
DEBUG - 2018-04-13 17:55:30 --> Total execution time: 0.1116
INFO - 2018-04-13 12:25:31 --> Config Class Initialized
INFO - 2018-04-13 12:25:31 --> Hooks Class Initialized
DEBUG - 2018-04-13 12:25:31 --> UTF-8 Support Enabled
INFO - 2018-04-13 12:25:31 --> Utf8 Class Initialized
INFO - 2018-04-13 12:25:31 --> URI Class Initialized
INFO - 2018-04-13 12:25:31 --> Router Class Initialized
INFO - 2018-04-13 12:25:31 --> Output Class Initialized
INFO - 2018-04-13 12:25:31 --> Security Class Initialized
DEBUG - 2018-04-13 12:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 12:25:31 --> Input Class Initialized
INFO - 2018-04-13 12:25:31 --> Language Class Initialized
INFO - 2018-04-13 12:25:31 --> Language Class Initialized
INFO - 2018-04-13 12:25:31 --> Config Class Initialized
INFO - 2018-04-13 12:25:31 --> Loader Class Initialized
INFO - 2018-04-13 17:55:31 --> Helper loaded: url_helper
INFO - 2018-04-13 17:55:31 --> Helper loaded: notification_helper
INFO - 2018-04-13 17:55:31 --> Helper loaded: settings_helper
INFO - 2018-04-13 17:55:31 --> Helper loaded: permission_helper
INFO - 2018-04-13 17:55:31 --> Helper loaded: users_helper
INFO - 2018-04-13 17:55:32 --> Database Driver Class Initialized
DEBUG - 2018-04-13 17:55:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 17:55:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 17:55:32 --> Helper loaded: form_helper
INFO - 2018-04-13 17:55:32 --> Form Validation Class Initialized
INFO - 2018-04-13 17:55:32 --> Controller Class Initialized
INFO - 2018-04-13 12:25:32 --> Config Class Initialized
INFO - 2018-04-13 12:25:32 --> Hooks Class Initialized
DEBUG - 2018-04-13 12:25:32 --> UTF-8 Support Enabled
INFO - 2018-04-13 12:25:32 --> Utf8 Class Initialized
INFO - 2018-04-13 17:55:32 --> Model Class Initialized
INFO - 2018-04-13 12:25:32 --> URI Class Initialized
INFO - 2018-04-13 17:55:32 --> Helper loaded: inflector_helper
DEBUG - 2018-04-13 17:55:32 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 12:25:32 --> Router Class Initialized
INFO - 2018-04-13 17:55:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 17:55:32 --> Model Class Initialized
INFO - 2018-04-13 17:55:32 --> Model Class Initialized
INFO - 2018-04-13 17:55:32 --> Model Class Initialized
INFO - 2018-04-13 17:55:32 --> Model Class Initialized
INFO - 2018-04-13 17:55:32 --> Model Class Initialized
INFO - 2018-04-13 17:55:32 --> Model Class Initialized
INFO - 2018-04-13 12:25:32 --> Output Class Initialized
INFO - 2018-04-13 17:55:32 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-04-13 17:55:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-04-13 12:25:32 --> Security Class Initialized
INFO - 2018-04-13 17:55:32 --> Final output sent to browser
DEBUG - 2018-04-13 17:55:32 --> Total execution time: 0.1870
DEBUG - 2018-04-13 12:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 12:25:32 --> Input Class Initialized
INFO - 2018-04-13 12:25:32 --> Language Class Initialized
INFO - 2018-04-13 12:25:32 --> Language Class Initialized
INFO - 2018-04-13 12:25:32 --> Config Class Initialized
INFO - 2018-04-13 12:25:32 --> Loader Class Initialized
INFO - 2018-04-13 17:55:32 --> Helper loaded: url_helper
INFO - 2018-04-13 17:55:32 --> Helper loaded: notification_helper
INFO - 2018-04-13 17:55:32 --> Helper loaded: settings_helper
INFO - 2018-04-13 17:55:32 --> Helper loaded: permission_helper
INFO - 2018-04-13 17:55:32 --> Helper loaded: users_helper
INFO - 2018-04-13 17:55:32 --> Database Driver Class Initialized
DEBUG - 2018-04-13 17:55:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 17:55:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 17:55:32 --> Helper loaded: form_helper
INFO - 2018-04-13 17:55:32 --> Form Validation Class Initialized
INFO - 2018-04-13 17:55:32 --> Controller Class Initialized
INFO - 2018-04-13 17:55:32 --> Model Class Initialized
INFO - 2018-04-13 17:55:32 --> Helper loaded: inflector_helper
DEBUG - 2018-04-13 17:55:32 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 17:55:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 17:55:32 --> Model Class Initialized
INFO - 2018-04-13 17:55:32 --> Model Class Initialized
INFO - 2018-04-13 17:55:32 --> Model Class Initialized
INFO - 2018-04-13 17:55:32 --> Model Class Initialized
INFO - 2018-04-13 17:55:32 --> Model Class Initialized
INFO - 2018-04-13 17:55:32 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-13 17:55:32 --> Model Class Initialized
INFO - 2018-04-13 17:55:32 --> Final output sent to browser
DEBUG - 2018-04-13 17:55:32 --> Total execution time: 0.2103
INFO - 2018-04-13 12:35:40 --> Config Class Initialized
INFO - 2018-04-13 12:35:40 --> Hooks Class Initialized
DEBUG - 2018-04-13 12:35:40 --> UTF-8 Support Enabled
INFO - 2018-04-13 12:35:40 --> Utf8 Class Initialized
INFO - 2018-04-13 12:35:40 --> Config Class Initialized
INFO - 2018-04-13 12:35:40 --> Hooks Class Initialized
INFO - 2018-04-13 12:35:40 --> URI Class Initialized
DEBUG - 2018-04-13 12:35:40 --> UTF-8 Support Enabled
INFO - 2018-04-13 12:35:40 --> Utf8 Class Initialized
INFO - 2018-04-13 12:35:40 --> Router Class Initialized
INFO - 2018-04-13 12:35:40 --> URI Class Initialized
INFO - 2018-04-13 12:35:40 --> Output Class Initialized
INFO - 2018-04-13 12:35:40 --> Router Class Initialized
INFO - 2018-04-13 12:35:40 --> Security Class Initialized
INFO - 2018-04-13 12:35:40 --> Output Class Initialized
DEBUG - 2018-04-13 12:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 12:35:40 --> Input Class Initialized
INFO - 2018-04-13 12:35:40 --> Language Class Initialized
INFO - 2018-04-13 12:35:40 --> Security Class Initialized
DEBUG - 2018-04-13 12:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 12:35:40 --> Input Class Initialized
INFO - 2018-04-13 12:35:40 --> Language Class Initialized
INFO - 2018-04-13 12:35:40 --> Language Class Initialized
INFO - 2018-04-13 12:35:40 --> Config Class Initialized
INFO - 2018-04-13 12:35:40 --> Language Class Initialized
INFO - 2018-04-13 12:35:40 --> Loader Class Initialized
INFO - 2018-04-13 12:35:40 --> Config Class Initialized
INFO - 2018-04-13 12:35:40 --> Loader Class Initialized
INFO - 2018-04-13 18:05:40 --> Helper loaded: url_helper
INFO - 2018-04-13 18:05:40 --> Helper loaded: url_helper
INFO - 2018-04-13 18:05:40 --> Helper loaded: notification_helper
INFO - 2018-04-13 18:05:40 --> Helper loaded: notification_helper
INFO - 2018-04-13 18:05:40 --> Helper loaded: settings_helper
INFO - 2018-04-13 18:05:40 --> Helper loaded: settings_helper
INFO - 2018-04-13 18:05:40 --> Helper loaded: permission_helper
INFO - 2018-04-13 18:05:40 --> Helper loaded: permission_helper
INFO - 2018-04-13 18:05:40 --> Helper loaded: users_helper
INFO - 2018-04-13 18:05:40 --> Helper loaded: users_helper
INFO - 2018-04-13 18:05:40 --> Database Driver Class Initialized
INFO - 2018-04-13 18:05:40 --> Database Driver Class Initialized
DEBUG - 2018-04-13 18:05:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 18:05:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-04-13 18:05:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 18:05:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 18:05:40 --> Helper loaded: form_helper
INFO - 2018-04-13 18:05:40 --> Form Validation Class Initialized
INFO - 2018-04-13 18:05:40 --> Controller Class Initialized
INFO - 2018-04-13 18:05:40 --> Model Class Initialized
INFO - 2018-04-13 18:05:40 --> Helper loaded: inflector_helper
INFO - 2018-04-13 12:35:40 --> Config Class Initialized
INFO - 2018-04-13 12:35:40 --> Hooks Class Initialized
INFO - 2018-04-13 18:05:40 --> Helper loaded: form_helper
INFO - 2018-04-13 18:05:40 --> Form Validation Class Initialized
INFO - 2018-04-13 18:05:40 --> Controller Class Initialized
DEBUG - 2018-04-13 18:05:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-04-13 12:35:40 --> UTF-8 Support Enabled
INFO - 2018-04-13 12:35:40 --> Utf8 Class Initialized
INFO - 2018-04-13 18:05:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 12:35:40 --> URI Class Initialized
INFO - 2018-04-13 18:05:40 --> Model Class Initialized
INFO - 2018-04-13 18:05:40 --> Model Class Initialized
INFO - 2018-04-13 18:05:40 --> Model Class Initialized
INFO - 2018-04-13 18:05:40 --> Model Class Initialized
INFO - 2018-04-13 18:05:40 --> Model Class Initialized
INFO - 2018-04-13 18:05:40 --> Model Class Initialized
INFO - 2018-04-13 18:05:40 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-13 12:35:40 --> Router Class Initialized
ERROR - 2018-04-13 18:05:40 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-04-13 18:05:40 --> Final output sent to browser
DEBUG - 2018-04-13 18:05:40 --> Total execution time: 0.1099
INFO - 2018-04-13 12:35:40 --> Output Class Initialized
INFO - 2018-04-13 12:35:40 --> Security Class Initialized
DEBUG - 2018-04-13 12:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 12:35:40 --> Input Class Initialized
INFO - 2018-04-13 12:35:40 --> Language Class Initialized
INFO - 2018-04-13 18:05:40 --> Model Class Initialized
INFO - 2018-04-13 18:05:40 --> Helper loaded: inflector_helper
DEBUG - 2018-04-13 18:05:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 18:05:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 12:35:40 --> Language Class Initialized
INFO - 2018-04-13 12:35:40 --> Config Class Initialized
INFO - 2018-04-13 12:35:40 --> Loader Class Initialized
INFO - 2018-04-13 18:05:40 --> Model Class Initialized
INFO - 2018-04-13 18:05:40 --> Model Class Initialized
INFO - 2018-04-13 18:05:40 --> Helper loaded: url_helper
INFO - 2018-04-13 18:05:40 --> Helper loaded: notification_helper
INFO - 2018-04-13 18:05:40 --> Helper loaded: settings_helper
INFO - 2018-04-13 18:05:40 --> Model Class Initialized
INFO - 2018-04-13 18:05:40 --> Model Class Initialized
INFO - 2018-04-13 18:05:40 --> Helper loaded: permission_helper
INFO - 2018-04-13 18:05:40 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-13 18:05:40 --> Helper loaded: users_helper
INFO - 2018-04-13 18:05:40 --> Final output sent to browser
DEBUG - 2018-04-13 18:05:40 --> Total execution time: 0.1401
INFO - 2018-04-13 18:05:40 --> Database Driver Class Initialized
DEBUG - 2018-04-13 18:05:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 18:05:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 18:05:40 --> Helper loaded: form_helper
INFO - 2018-04-13 18:05:40 --> Form Validation Class Initialized
INFO - 2018-04-13 18:05:40 --> Controller Class Initialized
INFO - 2018-04-13 18:05:40 --> Model Class Initialized
INFO - 2018-04-13 18:05:40 --> Helper loaded: inflector_helper
DEBUG - 2018-04-13 18:05:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 18:05:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 18:05:40 --> Model Class Initialized
INFO - 2018-04-13 18:05:40 --> Model Class Initialized
INFO - 2018-04-13 18:05:40 --> Model Class Initialized
INFO - 2018-04-13 18:05:40 --> Model Class Initialized
INFO - 2018-04-13 18:05:40 --> Model Class Initialized
INFO - 2018-04-13 18:05:40 --> Model Class Initialized
INFO - 2018-04-13 18:05:40 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-04-13 18:05:40 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-04-13 18:05:40 --> Final output sent to browser
DEBUG - 2018-04-13 18:05:40 --> Total execution time: 0.1080
INFO - 2018-04-13 12:35:41 --> Config Class Initialized
INFO - 2018-04-13 12:35:41 --> Hooks Class Initialized
DEBUG - 2018-04-13 12:35:41 --> UTF-8 Support Enabled
INFO - 2018-04-13 12:35:41 --> Utf8 Class Initialized
INFO - 2018-04-13 12:35:41 --> URI Class Initialized
INFO - 2018-04-13 12:35:41 --> Router Class Initialized
INFO - 2018-04-13 12:35:41 --> Output Class Initialized
INFO - 2018-04-13 12:35:41 --> Security Class Initialized
INFO - 2018-04-13 12:35:41 --> Config Class Initialized
INFO - 2018-04-13 12:35:41 --> Hooks Class Initialized
DEBUG - 2018-04-13 12:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 12:35:41 --> Input Class Initialized
DEBUG - 2018-04-13 12:35:41 --> UTF-8 Support Enabled
INFO - 2018-04-13 12:35:41 --> Utf8 Class Initialized
INFO - 2018-04-13 12:35:41 --> Language Class Initialized
INFO - 2018-04-13 12:35:41 --> URI Class Initialized
INFO - 2018-04-13 12:35:41 --> Router Class Initialized
INFO - 2018-04-13 12:35:41 --> Output Class Initialized
INFO - 2018-04-13 12:35:41 --> Security Class Initialized
INFO - 2018-04-13 12:35:41 --> Language Class Initialized
INFO - 2018-04-13 12:35:41 --> Config Class Initialized
INFO - 2018-04-13 12:35:41 --> Loader Class Initialized
DEBUG - 2018-04-13 12:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 12:35:41 --> Input Class Initialized
INFO - 2018-04-13 12:35:41 --> Language Class Initialized
INFO - 2018-04-13 18:05:41 --> Helper loaded: url_helper
INFO - 2018-04-13 18:05:41 --> Helper loaded: notification_helper
INFO - 2018-04-13 18:05:41 --> Helper loaded: settings_helper
INFO - 2018-04-13 18:05:41 --> Helper loaded: permission_helper
INFO - 2018-04-13 18:05:41 --> Helper loaded: users_helper
INFO - 2018-04-13 18:05:41 --> Database Driver Class Initialized
INFO - 2018-04-13 12:35:41 --> Language Class Initialized
INFO - 2018-04-13 12:35:41 --> Config Class Initialized
INFO - 2018-04-13 12:35:41 --> Loader Class Initialized
DEBUG - 2018-04-13 18:05:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 18:05:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 18:05:41 --> Helper loaded: url_helper
INFO - 2018-04-13 18:05:41 --> Helper loaded: notification_helper
INFO - 2018-04-13 18:05:41 --> Helper loaded: settings_helper
INFO - 2018-04-13 18:05:41 --> Helper loaded: permission_helper
INFO - 2018-04-13 18:05:41 --> Helper loaded: users_helper
INFO - 2018-04-13 18:05:41 --> Helper loaded: form_helper
INFO - 2018-04-13 18:05:41 --> Form Validation Class Initialized
INFO - 2018-04-13 18:05:41 --> Controller Class Initialized
INFO - 2018-04-13 18:05:41 --> Model Class Initialized
INFO - 2018-04-13 18:05:41 --> Helper loaded: inflector_helper
INFO - 2018-04-13 18:05:41 --> Database Driver Class Initialized
DEBUG - 2018-04-13 18:05:41 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 18:05:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 18:05:41 --> Model Class Initialized
INFO - 2018-04-13 18:05:41 --> Model Class Initialized
INFO - 2018-04-13 18:05:41 --> Model Class Initialized
INFO - 2018-04-13 18:05:41 --> Model Class Initialized
INFO - 2018-04-13 18:05:41 --> Model Class Initialized
DEBUG - 2018-04-13 18:05:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 18:05:41 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-13 18:05:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 18:05:41 --> Model Class Initialized
INFO - 2018-04-13 18:05:41 --> Final output sent to browser
DEBUG - 2018-04-13 18:05:41 --> Total execution time: 0.1044
INFO - 2018-04-13 18:05:41 --> Helper loaded: form_helper
INFO - 2018-04-13 18:05:41 --> Form Validation Class Initialized
INFO - 2018-04-13 18:05:41 --> Controller Class Initialized
INFO - 2018-04-13 18:05:41 --> Model Class Initialized
INFO - 2018-04-13 18:05:41 --> Helper loaded: inflector_helper
DEBUG - 2018-04-13 18:05:41 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 18:05:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 18:05:41 --> Model Class Initialized
INFO - 2018-04-13 18:05:41 --> Model Class Initialized
INFO - 2018-04-13 18:05:41 --> Model Class Initialized
INFO - 2018-04-13 18:05:41 --> Model Class Initialized
INFO - 2018-04-13 18:05:41 --> Model Class Initialized
INFO - 2018-04-13 18:05:41 --> Model Class Initialized
INFO - 2018-04-13 18:05:41 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-04-13 18:05:41 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-04-13 18:05:41 --> Final output sent to browser
DEBUG - 2018-04-13 18:05:41 --> Total execution time: 0.1157
INFO - 2018-04-13 12:40:30 --> Config Class Initialized
INFO - 2018-04-13 12:40:30 --> Hooks Class Initialized
INFO - 2018-04-13 12:40:30 --> Config Class Initialized
INFO - 2018-04-13 12:40:30 --> Hooks Class Initialized
DEBUG - 2018-04-13 12:40:30 --> UTF-8 Support Enabled
INFO - 2018-04-13 12:40:30 --> Utf8 Class Initialized
DEBUG - 2018-04-13 12:40:30 --> UTF-8 Support Enabled
INFO - 2018-04-13 12:40:30 --> Utf8 Class Initialized
INFO - 2018-04-13 12:40:30 --> URI Class Initialized
INFO - 2018-04-13 12:40:30 --> URI Class Initialized
INFO - 2018-04-13 12:40:30 --> Router Class Initialized
INFO - 2018-04-13 12:40:30 --> Router Class Initialized
INFO - 2018-04-13 12:40:30 --> Output Class Initialized
INFO - 2018-04-13 12:40:30 --> Output Class Initialized
INFO - 2018-04-13 12:40:30 --> Security Class Initialized
INFO - 2018-04-13 12:40:30 --> Config Class Initialized
INFO - 2018-04-13 12:40:30 --> Hooks Class Initialized
INFO - 2018-04-13 12:40:30 --> Config Class Initialized
INFO - 2018-04-13 12:40:30 --> Hooks Class Initialized
DEBUG - 2018-04-13 12:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 12:40:30 --> Input Class Initialized
INFO - 2018-04-13 12:40:30 --> Security Class Initialized
DEBUG - 2018-04-13 12:40:30 --> UTF-8 Support Enabled
INFO - 2018-04-13 12:40:30 --> Utf8 Class Initialized
DEBUG - 2018-04-13 12:40:30 --> UTF-8 Support Enabled
INFO - 2018-04-13 12:40:30 --> Utf8 Class Initialized
INFO - 2018-04-13 12:40:30 --> Language Class Initialized
DEBUG - 2018-04-13 12:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 12:40:30 --> Input Class Initialized
INFO - 2018-04-13 12:40:30 --> URI Class Initialized
INFO - 2018-04-13 12:40:30 --> URI Class Initialized
INFO - 2018-04-13 12:40:30 --> Language Class Initialized
INFO - 2018-04-13 12:40:30 --> Router Class Initialized
INFO - 2018-04-13 12:40:30 --> Router Class Initialized
INFO - 2018-04-13 12:40:30 --> Config Class Initialized
INFO - 2018-04-13 12:40:30 --> Hooks Class Initialized
INFO - 2018-04-13 12:40:30 --> Output Class Initialized
INFO - 2018-04-13 12:40:30 --> Output Class Initialized
INFO - 2018-04-13 12:40:30 --> Security Class Initialized
DEBUG - 2018-04-13 12:40:30 --> UTF-8 Support Enabled
INFO - 2018-04-13 12:40:30 --> Utf8 Class Initialized
INFO - 2018-04-13 12:40:30 --> URI Class Initialized
DEBUG - 2018-04-13 12:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 12:40:30 --> Security Class Initialized
INFO - 2018-04-13 12:40:30 --> Input Class Initialized
INFO - 2018-04-13 12:40:30 --> Language Class Initialized
DEBUG - 2018-04-13 12:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 12:40:30 --> Input Class Initialized
INFO - 2018-04-13 12:40:30 --> Router Class Initialized
INFO - 2018-04-13 12:40:30 --> Language Class Initialized
INFO - 2018-04-13 12:40:30 --> Output Class Initialized
INFO - 2018-04-13 12:40:30 --> Security Class Initialized
DEBUG - 2018-04-13 12:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 12:40:30 --> Input Class Initialized
INFO - 2018-04-13 12:40:30 --> Language Class Initialized
INFO - 2018-04-13 12:40:30 --> Config Class Initialized
INFO - 2018-04-13 12:40:30 --> Loader Class Initialized
INFO - 2018-04-13 12:40:30 --> Language Class Initialized
INFO - 2018-04-13 12:40:30 --> Language Class Initialized
INFO - 2018-04-13 12:40:30 --> Config Class Initialized
INFO - 2018-04-13 12:40:30 --> Loader Class Initialized
INFO - 2018-04-13 18:10:30 --> Helper loaded: url_helper
INFO - 2018-04-13 18:10:30 --> Helper loaded: url_helper
INFO - 2018-04-13 18:10:30 --> Helper loaded: notification_helper
INFO - 2018-04-13 18:10:30 --> Helper loaded: notification_helper
INFO - 2018-04-13 18:10:30 --> Helper loaded: settings_helper
INFO - 2018-04-13 18:10:30 --> Helper loaded: permission_helper
INFO - 2018-04-13 18:10:30 --> Helper loaded: users_helper
INFO - 2018-04-13 18:10:30 --> Helper loaded: settings_helper
INFO - 2018-04-13 18:10:30 --> Helper loaded: permission_helper
INFO - 2018-04-13 12:40:31 --> Language Class Initialized
INFO - 2018-04-13 18:10:31 --> Helper loaded: users_helper
INFO - 2018-04-13 12:40:31 --> Config Class Initialized
INFO - 2018-04-13 12:40:31 --> Loader Class Initialized
INFO - 2018-04-13 18:10:31 --> Helper loaded: url_helper
INFO - 2018-04-13 18:10:31 --> Helper loaded: notification_helper
INFO - 2018-04-13 18:10:31 --> Helper loaded: settings_helper
INFO - 2018-04-13 18:10:31 --> Helper loaded: permission_helper
INFO - 2018-04-13 18:10:31 --> Helper loaded: users_helper
INFO - 2018-04-13 12:40:31 --> Language Class Initialized
INFO - 2018-04-13 12:40:31 --> Config Class Initialized
INFO - 2018-04-13 12:40:31 --> Loader Class Initialized
INFO - 2018-04-13 18:10:31 --> Database Driver Class Initialized
INFO - 2018-04-13 18:10:31 --> Database Driver Class Initialized
INFO - 2018-04-13 18:10:31 --> Helper loaded: url_helper
INFO - 2018-04-13 18:10:31 --> Helper loaded: notification_helper
INFO - 2018-04-13 18:10:31 --> Helper loaded: settings_helper
INFO - 2018-04-13 12:40:31 --> Language Class Initialized
INFO - 2018-04-13 12:40:31 --> Config Class Initialized
INFO - 2018-04-13 12:40:31 --> Loader Class Initialized
INFO - 2018-04-13 18:10:31 --> Helper loaded: permission_helper
DEBUG - 2018-04-13 18:10:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 18:10:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 18:10:31 --> Helper loaded: users_helper
DEBUG - 2018-04-13 18:10:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 18:10:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 18:10:31 --> Helper loaded: url_helper
INFO - 2018-04-13 18:10:31 --> Database Driver Class Initialized
INFO - 2018-04-13 18:10:31 --> Helper loaded: notification_helper
INFO - 2018-04-13 18:10:31 --> Helper loaded: settings_helper
INFO - 2018-04-13 18:10:31 --> Helper loaded: permission_helper
INFO - 2018-04-13 18:10:31 --> Helper loaded: form_helper
INFO - 2018-04-13 18:10:31 --> Form Validation Class Initialized
INFO - 2018-04-13 18:10:31 --> Controller Class Initialized
INFO - 2018-04-13 18:10:31 --> Helper loaded: users_helper
INFO - 2018-04-13 18:10:31 --> Helper loaded: form_helper
DEBUG - 2018-04-13 18:10:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 18:10:31 --> Form Validation Class Initialized
INFO - 2018-04-13 18:10:31 --> Controller Class Initialized
INFO - 2018-04-13 18:10:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 18:10:31 --> Database Driver Class Initialized
INFO - 2018-04-13 18:10:31 --> Model Class Initialized
INFO - 2018-04-13 18:10:31 --> Helper loaded: form_helper
INFO - 2018-04-13 18:10:31 --> Form Validation Class Initialized
INFO - 2018-04-13 18:10:31 --> Controller Class Initialized
INFO - 2018-04-13 18:10:31 --> Helper loaded: inflector_helper
INFO - 2018-04-13 18:10:31 --> Model Class Initialized
INFO - 2018-04-13 18:10:31 --> Helper loaded: inflector_helper
DEBUG - 2018-04-13 18:10:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 18:10:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-04-13 18:10:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-04-13 18:10:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 18:10:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 18:10:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 18:10:31 --> Model Class Initialized
INFO - 2018-04-13 18:10:31 --> Model Class Initialized
INFO - 2018-04-13 18:10:31 --> Model Class Initialized
INFO - 2018-04-13 18:10:31 --> Model Class Initialized
INFO - 2018-04-13 18:10:31 --> Model Class Initialized
INFO - 2018-04-13 18:10:31 --> Model Class Initialized
INFO - 2018-04-13 18:10:31 --> Model Class Initialized
INFO - 2018-04-13 18:10:31 --> Model Class Initialized
INFO - 2018-04-13 18:10:31 --> Model Class Initialized
INFO - 2018-04-13 18:10:31 --> Model Class Initialized
INFO - 2018-04-13 18:10:31 --> Model Class Initialized
INFO - 2018-04-13 18:10:31 --> Model Class Initialized
INFO - 2018-04-13 18:10:31 --> Model Class Initialized
INFO - 2018-04-13 18:10:31 --> Helper loaded: form_helper
INFO - 2018-04-13 18:10:31 --> Form Validation Class Initialized
INFO - 2018-04-13 18:10:31 --> Model Class Initialized
INFO - 2018-04-13 18:10:31 --> Controller Class Initialized
INFO - 2018-04-13 18:10:31 --> Helper loaded: inflector_helper
INFO - 2018-04-13 18:10:31 --> Model Class Initialized
INFO - 2018-04-13 18:10:31 --> Model Class Initialized
INFO - 2018-04-13 18:10:31 --> Model Class Initialized
INFO - 2018-04-13 18:10:31 --> Model Class Initialized
INFO - 2018-04-13 18:10:31 --> Model Class Initialized
INFO - 2018-04-13 18:10:31 --> Model Class Initialized
INFO - 2018-04-13 18:10:31 --> Model Class Initialized
DEBUG - 2018-04-13 18:10:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 18:10:31 --> Model Class Initialized
INFO - 2018-04-13 18:10:31 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-13 18:10:31 --> Model Class Initialized
INFO - 2018-04-13 18:10:31 --> Model Class Initialized
INFO - 2018-04-13 18:10:31 --> Database Driver Class Initialized
INFO - 2018-04-13 18:10:31 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-13 18:10:31 --> Model Class Initialized
INFO - 2018-04-13 18:10:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 18:10:31 --> Model Class Initialized
INFO - 2018-04-13 18:10:31 --> Model Class Initialized
INFO - 2018-04-13 18:10:31 --> Model Class Initialized
INFO - 2018-04-13 18:10:31 --> Model Class Initialized
INFO - 2018-04-13 18:10:31 --> Model Class Initialized
INFO - 2018-04-13 18:10:31 --> Model Class Initialized
INFO - 2018-04-13 18:10:31 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-13 18:10:31 --> Model Class Initialized
INFO - 2018-04-13 18:10:31 --> Helper loaded: inflector_helper
INFO - 2018-04-13 18:10:31 --> Final output sent to browser
DEBUG - 2018-04-13 18:10:31 --> Total execution time: 0.1127
DEBUG - 2018-04-13 18:10:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-04-13 18:10:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 18:10:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 18:10:31 --> Final output sent to browser
DEBUG - 2018-04-13 18:10:31 --> Total execution time: 0.1562
INFO - 2018-04-13 18:10:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 18:10:31 --> Model Class Initialized
INFO - 2018-04-13 18:10:31 --> Model Class Initialized
INFO - 2018-04-13 18:10:31 --> Model Class Initialized
INFO - 2018-04-13 18:10:31 --> Model Class Initialized
INFO - 2018-04-13 18:10:31 --> Model Class Initialized
INFO - 2018-04-13 18:10:31 --> Model Class Initialized
INFO - 2018-04-13 18:10:31 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-13 18:10:31 --> Model Class Initialized
INFO - 2018-04-13 18:10:31 --> Final output sent to browser
DEBUG - 2018-04-13 18:10:31 --> Total execution time: 0.1102
INFO - 2018-04-13 18:10:31 --> Helper loaded: form_helper
INFO - 2018-04-13 18:10:31 --> Form Validation Class Initialized
INFO - 2018-04-13 18:10:31 --> Controller Class Initialized
INFO - 2018-04-13 18:10:31 --> Final output sent to browser
DEBUG - 2018-04-13 18:10:31 --> Total execution time: 0.1706
INFO - 2018-04-13 18:10:31 --> Model Class Initialized
INFO - 2018-04-13 18:10:31 --> Helper loaded: inflector_helper
DEBUG - 2018-04-13 18:10:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 18:10:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 18:10:31 --> Model Class Initialized
INFO - 2018-04-13 18:10:31 --> Model Class Initialized
INFO - 2018-04-13 18:10:31 --> Model Class Initialized
INFO - 2018-04-13 18:10:31 --> Model Class Initialized
INFO - 2018-04-13 18:10:31 --> Model Class Initialized
INFO - 2018-04-13 18:10:31 --> Model Class Initialized
INFO - 2018-04-13 18:10:31 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-13 18:10:31 --> Model Class Initialized
INFO - 2018-04-13 18:10:31 --> Final output sent to browser
DEBUG - 2018-04-13 18:10:31 --> Total execution time: 0.1529
INFO - 2018-04-13 12:40:32 --> Config Class Initialized
INFO - 2018-04-13 12:40:32 --> Hooks Class Initialized
DEBUG - 2018-04-13 12:40:32 --> UTF-8 Support Enabled
INFO - 2018-04-13 12:40:32 --> Utf8 Class Initialized
INFO - 2018-04-13 12:40:32 --> URI Class Initialized
INFO - 2018-04-13 12:40:32 --> Router Class Initialized
INFO - 2018-04-13 12:40:32 --> Config Class Initialized
INFO - 2018-04-13 12:40:32 --> Hooks Class Initialized
INFO - 2018-04-13 12:40:32 --> Config Class Initialized
INFO - 2018-04-13 12:40:32 --> Hooks Class Initialized
INFO - 2018-04-13 12:40:32 --> Output Class Initialized
INFO - 2018-04-13 12:40:32 --> Security Class Initialized
DEBUG - 2018-04-13 12:40:32 --> UTF-8 Support Enabled
DEBUG - 2018-04-13 12:40:32 --> UTF-8 Support Enabled
INFO - 2018-04-13 12:40:32 --> Utf8 Class Initialized
INFO - 2018-04-13 12:40:32 --> Utf8 Class Initialized
DEBUG - 2018-04-13 12:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 12:40:32 --> Input Class Initialized
INFO - 2018-04-13 12:40:32 --> Language Class Initialized
INFO - 2018-04-13 12:40:32 --> URI Class Initialized
INFO - 2018-04-13 12:40:32 --> URI Class Initialized
INFO - 2018-04-13 12:40:32 --> Router Class Initialized
INFO - 2018-04-13 12:40:32 --> Router Class Initialized
INFO - 2018-04-13 12:40:32 --> Output Class Initialized
INFO - 2018-04-13 12:40:32 --> Output Class Initialized
INFO - 2018-04-13 12:40:32 --> Language Class Initialized
INFO - 2018-04-13 12:40:32 --> Config Class Initialized
INFO - 2018-04-13 12:40:32 --> Loader Class Initialized
INFO - 2018-04-13 12:40:32 --> Security Class Initialized
INFO - 2018-04-13 12:40:32 --> Security Class Initialized
INFO - 2018-04-13 18:10:32 --> Helper loaded: url_helper
INFO - 2018-04-13 18:10:32 --> Helper loaded: notification_helper
INFO - 2018-04-13 18:10:32 --> Helper loaded: settings_helper
INFO - 2018-04-13 18:10:32 --> Helper loaded: permission_helper
DEBUG - 2018-04-13 12:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 12:40:32 --> Input Class Initialized
DEBUG - 2018-04-13 12:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 12:40:32 --> Input Class Initialized
INFO - 2018-04-13 18:10:32 --> Helper loaded: users_helper
INFO - 2018-04-13 12:40:32 --> Language Class Initialized
INFO - 2018-04-13 12:40:32 --> Language Class Initialized
INFO - 2018-04-13 18:10:32 --> Database Driver Class Initialized
DEBUG - 2018-04-13 18:10:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 18:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 12:40:32 --> Language Class Initialized
INFO - 2018-04-13 12:40:32 --> Config Class Initialized
INFO - 2018-04-13 12:40:32 --> Loader Class Initialized
INFO - 2018-04-13 12:40:32 --> Language Class Initialized
INFO - 2018-04-13 12:40:32 --> Config Class Initialized
INFO - 2018-04-13 12:40:32 --> Loader Class Initialized
INFO - 2018-04-13 18:10:32 --> Helper loaded: url_helper
INFO - 2018-04-13 18:10:32 --> Helper loaded: url_helper
INFO - 2018-04-13 18:10:32 --> Helper loaded: notification_helper
INFO - 2018-04-13 18:10:32 --> Helper loaded: notification_helper
INFO - 2018-04-13 18:10:32 --> Helper loaded: settings_helper
INFO - 2018-04-13 18:10:32 --> Helper loaded: settings_helper
INFO - 2018-04-13 18:10:32 --> Helper loaded: permission_helper
INFO - 2018-04-13 18:10:32 --> Helper loaded: permission_helper
INFO - 2018-04-13 18:10:32 --> Helper loaded: users_helper
INFO - 2018-04-13 18:10:32 --> Helper loaded: users_helper
INFO - 2018-04-13 18:10:32 --> Helper loaded: form_helper
INFO - 2018-04-13 18:10:32 --> Form Validation Class Initialized
INFO - 2018-04-13 18:10:32 --> Controller Class Initialized
INFO - 2018-04-13 18:10:32 --> Database Driver Class Initialized
INFO - 2018-04-13 18:10:32 --> Model Class Initialized
INFO - 2018-04-13 18:10:32 --> Helper loaded: inflector_helper
DEBUG - 2018-04-13 18:10:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 18:10:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-04-13 18:10:32 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 18:10:32 --> Database Driver Class Initialized
INFO - 2018-04-13 18:10:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 18:10:32 --> Model Class Initialized
INFO - 2018-04-13 18:10:32 --> Model Class Initialized
INFO - 2018-04-13 18:10:32 --> Helper loaded: form_helper
INFO - 2018-04-13 18:10:32 --> Form Validation Class Initialized
INFO - 2018-04-13 18:10:32 --> Controller Class Initialized
INFO - 2018-04-13 18:10:32 --> Model Class Initialized
INFO - 2018-04-13 18:10:32 --> Model Class Initialized
INFO - 2018-04-13 18:10:32 --> Model Class Initialized
INFO - 2018-04-13 18:10:32 --> Model Class Initialized
INFO - 2018-04-13 18:10:32 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-04-13 18:10:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 18:10:32 --> Session: Class initialized using 'files' driver.
ERROR - 2018-04-13 18:10:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-04-13 18:10:32 --> Final output sent to browser
DEBUG - 2018-04-13 18:10:32 --> Total execution time: 0.1230
INFO - 2018-04-13 18:10:32 --> Model Class Initialized
INFO - 2018-04-13 18:10:32 --> Helper loaded: inflector_helper
INFO - 2018-04-13 18:10:32 --> Helper loaded: form_helper
INFO - 2018-04-13 18:10:32 --> Form Validation Class Initialized
INFO - 2018-04-13 18:10:32 --> Controller Class Initialized
DEBUG - 2018-04-13 18:10:32 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 18:10:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 18:10:32 --> Model Class Initialized
INFO - 2018-04-13 18:10:32 --> Model Class Initialized
INFO - 2018-04-13 18:10:32 --> Model Class Initialized
INFO - 2018-04-13 18:10:32 --> Model Class Initialized
INFO - 2018-04-13 18:10:32 --> Model Class Initialized
INFO - 2018-04-13 18:10:32 --> Model Class Initialized
INFO - 2018-04-13 18:10:32 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-13 18:10:32 --> Model Class Initialized
INFO - 2018-04-13 18:10:32 --> Helper loaded: inflector_helper
ERROR - 2018-04-13 18:10:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-04-13 18:10:32 --> Final output sent to browser
DEBUG - 2018-04-13 18:10:32 --> Total execution time: 0.1317
DEBUG - 2018-04-13 18:10:32 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 18:10:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 18:10:32 --> Model Class Initialized
INFO - 2018-04-13 18:10:32 --> Model Class Initialized
INFO - 2018-04-13 18:10:32 --> Model Class Initialized
INFO - 2018-04-13 18:10:32 --> Model Class Initialized
INFO - 2018-04-13 18:10:32 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-13 18:10:32 --> Final output sent to browser
DEBUG - 2018-04-13 18:10:32 --> Total execution time: 0.1460
INFO - 2018-04-13 12:40:39 --> Config Class Initialized
INFO - 2018-04-13 12:40:39 --> Hooks Class Initialized
DEBUG - 2018-04-13 12:40:39 --> UTF-8 Support Enabled
INFO - 2018-04-13 12:40:39 --> Utf8 Class Initialized
INFO - 2018-04-13 12:40:39 --> URI Class Initialized
INFO - 2018-04-13 12:40:39 --> Router Class Initialized
INFO - 2018-04-13 12:40:39 --> Output Class Initialized
INFO - 2018-04-13 12:40:39 --> Security Class Initialized
DEBUG - 2018-04-13 12:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 12:40:39 --> Input Class Initialized
INFO - 2018-04-13 12:40:39 --> Language Class Initialized
INFO - 2018-04-13 12:40:39 --> Language Class Initialized
INFO - 2018-04-13 12:40:39 --> Config Class Initialized
INFO - 2018-04-13 12:40:39 --> Loader Class Initialized
INFO - 2018-04-13 18:10:39 --> Helper loaded: url_helper
INFO - 2018-04-13 18:10:39 --> Helper loaded: notification_helper
INFO - 2018-04-13 18:10:39 --> Helper loaded: settings_helper
INFO - 2018-04-13 18:10:39 --> Helper loaded: permission_helper
INFO - 2018-04-13 18:10:39 --> Helper loaded: users_helper
INFO - 2018-04-13 18:10:39 --> Database Driver Class Initialized
DEBUG - 2018-04-13 18:10:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 18:10:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 18:10:39 --> Helper loaded: form_helper
INFO - 2018-04-13 18:10:39 --> Form Validation Class Initialized
INFO - 2018-04-13 18:10:39 --> Controller Class Initialized
INFO - 2018-04-13 18:10:39 --> Model Class Initialized
INFO - 2018-04-13 18:10:39 --> Helper loaded: inflector_helper
DEBUG - 2018-04-13 18:10:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 18:10:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 18:10:39 --> Model Class Initialized
INFO - 2018-04-13 18:10:39 --> Model Class Initialized
INFO - 2018-04-13 18:10:39 --> Model Class Initialized
INFO - 2018-04-13 18:10:39 --> Model Class Initialized
INFO - 2018-04-13 18:10:39 --> Model Class Initialized
INFO - 2018-04-13 18:10:39 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-13 18:10:39 --> Model Class Initialized
INFO - 2018-04-13 18:10:39 --> Final output sent to browser
DEBUG - 2018-04-13 18:10:39 --> Total execution time: 0.1129
INFO - 2018-04-13 12:40:39 --> Config Class Initialized
INFO - 2018-04-13 12:40:39 --> Hooks Class Initialized
DEBUG - 2018-04-13 12:40:39 --> UTF-8 Support Enabled
INFO - 2018-04-13 12:40:39 --> Utf8 Class Initialized
INFO - 2018-04-13 12:40:39 --> URI Class Initialized
INFO - 2018-04-13 12:40:39 --> Router Class Initialized
INFO - 2018-04-13 12:40:39 --> Output Class Initialized
INFO - 2018-04-13 12:40:39 --> Security Class Initialized
DEBUG - 2018-04-13 12:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 12:40:39 --> Input Class Initialized
INFO - 2018-04-13 12:40:39 --> Language Class Initialized
INFO - 2018-04-13 12:40:39 --> Language Class Initialized
INFO - 2018-04-13 12:40:39 --> Config Class Initialized
INFO - 2018-04-13 12:40:39 --> Loader Class Initialized
INFO - 2018-04-13 18:10:39 --> Helper loaded: url_helper
INFO - 2018-04-13 18:10:39 --> Helper loaded: notification_helper
INFO - 2018-04-13 18:10:39 --> Helper loaded: settings_helper
INFO - 2018-04-13 18:10:39 --> Helper loaded: permission_helper
INFO - 2018-04-13 18:10:39 --> Helper loaded: users_helper
INFO - 2018-04-13 18:10:39 --> Database Driver Class Initialized
DEBUG - 2018-04-13 18:10:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 18:10:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 18:10:39 --> Helper loaded: form_helper
INFO - 2018-04-13 18:10:39 --> Form Validation Class Initialized
INFO - 2018-04-13 18:10:39 --> Controller Class Initialized
INFO - 2018-04-13 18:10:39 --> Model Class Initialized
INFO - 2018-04-13 18:10:39 --> Helper loaded: inflector_helper
DEBUG - 2018-04-13 18:10:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 18:10:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 18:10:39 --> Model Class Initialized
INFO - 2018-04-13 18:10:39 --> Model Class Initialized
INFO - 2018-04-13 18:10:39 --> Model Class Initialized
INFO - 2018-04-13 18:10:39 --> Model Class Initialized
INFO - 2018-04-13 18:10:39 --> Model Class Initialized
INFO - 2018-04-13 18:10:39 --> Model Class Initialized
INFO - 2018-04-13 18:10:39 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-04-13 18:10:39 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-04-13 18:10:39 --> Final output sent to browser
DEBUG - 2018-04-13 18:10:39 --> Total execution time: 0.1175
INFO - 2018-04-13 12:40:51 --> Config Class Initialized
INFO - 2018-04-13 12:40:51 --> Hooks Class Initialized
DEBUG - 2018-04-13 12:40:51 --> UTF-8 Support Enabled
INFO - 2018-04-13 12:40:51 --> Utf8 Class Initialized
INFO - 2018-04-13 12:40:51 --> URI Class Initialized
INFO - 2018-04-13 12:40:51 --> Router Class Initialized
INFO - 2018-04-13 12:40:51 --> Output Class Initialized
INFO - 2018-04-13 12:40:51 --> Security Class Initialized
DEBUG - 2018-04-13 12:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 12:40:51 --> Input Class Initialized
INFO - 2018-04-13 12:40:51 --> Language Class Initialized
INFO - 2018-04-13 12:40:51 --> Language Class Initialized
INFO - 2018-04-13 12:40:51 --> Config Class Initialized
INFO - 2018-04-13 12:40:51 --> Loader Class Initialized
INFO - 2018-04-13 18:10:51 --> Helper loaded: url_helper
INFO - 2018-04-13 18:10:51 --> Helper loaded: notification_helper
INFO - 2018-04-13 18:10:51 --> Helper loaded: settings_helper
INFO - 2018-04-13 18:10:51 --> Helper loaded: permission_helper
INFO - 2018-04-13 18:10:51 --> Helper loaded: users_helper
INFO - 2018-04-13 18:10:51 --> Database Driver Class Initialized
DEBUG - 2018-04-13 18:10:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 18:10:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 18:10:51 --> Helper loaded: form_helper
INFO - 2018-04-13 18:10:51 --> Form Validation Class Initialized
INFO - 2018-04-13 18:10:51 --> Controller Class Initialized
INFO - 2018-04-13 18:10:51 --> Model Class Initialized
INFO - 2018-04-13 18:10:51 --> Helper loaded: inflector_helper
DEBUG - 2018-04-13 18:10:51 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 18:10:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 18:10:51 --> Model Class Initialized
INFO - 2018-04-13 18:10:51 --> Model Class Initialized
INFO - 2018-04-13 18:10:51 --> Model Class Initialized
INFO - 2018-04-13 18:10:51 --> Model Class Initialized
INFO - 2018-04-13 18:10:51 --> Model Class Initialized
INFO - 2018-04-13 18:10:51 --> Model Class Initialized
INFO - 2018-04-13 18:10:51 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-13 18:10:51 --> Final output sent to browser
DEBUG - 2018-04-13 18:10:51 --> Total execution time: 0.1036
INFO - 2018-04-13 12:41:01 --> Config Class Initialized
INFO - 2018-04-13 12:41:01 --> Hooks Class Initialized
DEBUG - 2018-04-13 12:41:01 --> UTF-8 Support Enabled
INFO - 2018-04-13 12:41:01 --> Utf8 Class Initialized
INFO - 2018-04-13 12:41:01 --> URI Class Initialized
INFO - 2018-04-13 12:41:01 --> Router Class Initialized
INFO - 2018-04-13 12:41:01 --> Output Class Initialized
INFO - 2018-04-13 12:41:01 --> Security Class Initialized
DEBUG - 2018-04-13 12:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 12:41:01 --> Input Class Initialized
INFO - 2018-04-13 12:41:01 --> Language Class Initialized
INFO - 2018-04-13 12:41:01 --> Language Class Initialized
INFO - 2018-04-13 12:41:01 --> Config Class Initialized
INFO - 2018-04-13 12:41:01 --> Loader Class Initialized
INFO - 2018-04-13 18:11:01 --> Helper loaded: url_helper
INFO - 2018-04-13 18:11:01 --> Helper loaded: notification_helper
INFO - 2018-04-13 18:11:01 --> Helper loaded: settings_helper
INFO - 2018-04-13 18:11:01 --> Helper loaded: permission_helper
INFO - 2018-04-13 18:11:01 --> Helper loaded: users_helper
INFO - 2018-04-13 18:11:01 --> Database Driver Class Initialized
DEBUG - 2018-04-13 18:11:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 18:11:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 18:11:01 --> Helper loaded: form_helper
INFO - 2018-04-13 18:11:01 --> Form Validation Class Initialized
INFO - 2018-04-13 18:11:01 --> Controller Class Initialized
INFO - 2018-04-13 18:11:01 --> Model Class Initialized
INFO - 2018-04-13 18:11:01 --> Helper loaded: inflector_helper
DEBUG - 2018-04-13 18:11:01 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 18:11:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 18:11:01 --> Model Class Initialized
INFO - 2018-04-13 18:11:01 --> Model Class Initialized
INFO - 2018-04-13 18:11:01 --> Model Class Initialized
INFO - 2018-04-13 18:11:01 --> Model Class Initialized
INFO - 2018-04-13 18:11:01 --> Model Class Initialized
INFO - 2018-04-13 18:11:01 --> Model Class Initialized
INFO - 2018-04-13 18:11:01 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-13 18:11:01 --> Final output sent to browser
DEBUG - 2018-04-13 18:11:01 --> Total execution time: 0.1582
INFO - 2018-04-13 12:42:33 --> Config Class Initialized
INFO - 2018-04-13 12:42:33 --> Hooks Class Initialized
DEBUG - 2018-04-13 12:42:33 --> UTF-8 Support Enabled
INFO - 2018-04-13 12:42:33 --> Utf8 Class Initialized
INFO - 2018-04-13 12:42:33 --> URI Class Initialized
INFO - 2018-04-13 12:42:33 --> Router Class Initialized
INFO - 2018-04-13 12:42:33 --> Config Class Initialized
INFO - 2018-04-13 12:42:33 --> Hooks Class Initialized
INFO - 2018-04-13 12:42:33 --> Output Class Initialized
DEBUG - 2018-04-13 12:42:33 --> UTF-8 Support Enabled
INFO - 2018-04-13 12:42:33 --> Utf8 Class Initialized
INFO - 2018-04-13 12:42:33 --> URI Class Initialized
INFO - 2018-04-13 12:42:33 --> Security Class Initialized
DEBUG - 2018-04-13 12:42:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 12:42:33 --> Input Class Initialized
INFO - 2018-04-13 12:42:33 --> Router Class Initialized
INFO - 2018-04-13 12:42:33 --> Language Class Initialized
INFO - 2018-04-13 12:42:33 --> Output Class Initialized
INFO - 2018-04-13 12:42:33 --> Security Class Initialized
DEBUG - 2018-04-13 12:42:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 12:42:33 --> Input Class Initialized
INFO - 2018-04-13 12:42:33 --> Language Class Initialized
INFO - 2018-04-13 12:42:33 --> Language Class Initialized
INFO - 2018-04-13 12:42:33 --> Config Class Initialized
INFO - 2018-04-13 12:42:33 --> Loader Class Initialized
INFO - 2018-04-13 18:12:33 --> Helper loaded: url_helper
INFO - 2018-04-13 18:12:33 --> Helper loaded: notification_helper
INFO - 2018-04-13 18:12:33 --> Helper loaded: settings_helper
INFO - 2018-04-13 18:12:33 --> Helper loaded: permission_helper
INFO - 2018-04-13 18:12:33 --> Helper loaded: users_helper
INFO - 2018-04-13 12:42:33 --> Language Class Initialized
INFO - 2018-04-13 12:42:33 --> Config Class Initialized
INFO - 2018-04-13 12:42:33 --> Loader Class Initialized
INFO - 2018-04-13 18:12:33 --> Helper loaded: url_helper
INFO - 2018-04-13 12:42:33 --> Config Class Initialized
INFO - 2018-04-13 12:42:33 --> Hooks Class Initialized
INFO - 2018-04-13 18:12:33 --> Helper loaded: notification_helper
INFO - 2018-04-13 18:12:33 --> Helper loaded: settings_helper
INFO - 2018-04-13 12:42:33 --> Config Class Initialized
INFO - 2018-04-13 12:42:33 --> Hooks Class Initialized
INFO - 2018-04-13 18:12:33 --> Helper loaded: permission_helper
INFO - 2018-04-13 18:12:33 --> Helper loaded: users_helper
DEBUG - 2018-04-13 12:42:33 --> UTF-8 Support Enabled
INFO - 2018-04-13 12:42:33 --> Utf8 Class Initialized
INFO - 2018-04-13 18:12:33 --> Database Driver Class Initialized
DEBUG - 2018-04-13 12:42:33 --> UTF-8 Support Enabled
INFO - 2018-04-13 12:42:33 --> Utf8 Class Initialized
INFO - 2018-04-13 12:42:33 --> URI Class Initialized
INFO - 2018-04-13 12:42:33 --> URI Class Initialized
INFO - 2018-04-13 12:42:33 --> Router Class Initialized
DEBUG - 2018-04-13 18:12:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 18:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 12:42:33 --> Router Class Initialized
INFO - 2018-04-13 12:42:33 --> Output Class Initialized
INFO - 2018-04-13 12:42:33 --> Security Class Initialized
INFO - 2018-04-13 12:42:33 --> Output Class Initialized
INFO - 2018-04-13 18:12:33 --> Database Driver Class Initialized
DEBUG - 2018-04-13 12:42:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 12:42:33 --> Input Class Initialized
INFO - 2018-04-13 12:42:33 --> Language Class Initialized
INFO - 2018-04-13 12:42:33 --> Security Class Initialized
INFO - 2018-04-13 18:12:33 --> Helper loaded: form_helper
INFO - 2018-04-13 18:12:33 --> Form Validation Class Initialized
INFO - 2018-04-13 18:12:33 --> Controller Class Initialized
DEBUG - 2018-04-13 12:42:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 12:42:33 --> Input Class Initialized
INFO - 2018-04-13 12:42:33 --> Language Class Initialized
DEBUG - 2018-04-13 18:12:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 18:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 18:12:33 --> Model Class Initialized
INFO - 2018-04-13 18:12:33 --> Helper loaded: inflector_helper
INFO - 2018-04-13 18:12:33 --> Helper loaded: form_helper
INFO - 2018-04-13 18:12:33 --> Form Validation Class Initialized
INFO - 2018-04-13 18:12:33 --> Controller Class Initialized
DEBUG - 2018-04-13 18:12:33 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 18:12:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 18:12:33 --> Model Class Initialized
INFO - 2018-04-13 18:12:33 --> Model Class Initialized
INFO - 2018-04-13 18:12:33 --> Model Class Initialized
INFO - 2018-04-13 18:12:33 --> Model Class Initialized
INFO - 2018-04-13 12:42:33 --> Language Class Initialized
INFO - 2018-04-13 12:42:33 --> Config Class Initialized
INFO - 2018-04-13 12:42:33 --> Loader Class Initialized
INFO - 2018-04-13 18:12:33 --> Model Class Initialized
INFO - 2018-04-13 18:12:33 --> Model Class Initialized
INFO - 2018-04-13 18:12:33 --> Model Class Initialized
INFO - 2018-04-13 18:12:33 --> Model Class Initialized
INFO - 2018-04-13 18:12:33 --> Model Class Initialized
INFO - 2018-04-13 18:12:33 --> Model Class Initialized
INFO - 2018-04-13 18:12:33 --> Helper loaded: inflector_helper
INFO - 2018-04-13 18:12:33 --> Model Class Initialized
INFO - 2018-04-13 18:12:33 --> Helper loaded: url_helper
INFO - 2018-04-13 18:12:33 --> Helper loaded: notification_helper
INFO - 2018-04-13 18:12:33 --> Helper loaded: settings_helper
INFO - 2018-04-13 18:12:33 --> Helper loaded: permission_helper
DEBUG - 2018-04-13 18:12:33 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 18:12:33 --> Model Class Initialized
INFO - 2018-04-13 18:12:33 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-13 18:12:33 --> Helper loaded: users_helper
INFO - 2018-04-13 18:12:33 --> Model Class Initialized
INFO - 2018-04-13 18:12:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 12:42:33 --> Language Class Initialized
INFO - 2018-04-13 12:42:33 --> Config Class Initialized
INFO - 2018-04-13 12:42:33 --> Loader Class Initialized
INFO - 2018-04-13 18:12:33 --> Model Class Initialized
INFO - 2018-04-13 18:12:33 --> Model Class Initialized
INFO - 2018-04-13 18:12:33 --> Model Class Initialized
INFO - 2018-04-13 18:12:33 --> Model Class Initialized
INFO - 2018-04-13 18:12:33 --> Model Class Initialized
INFO - 2018-04-13 18:12:33 --> Model Class Initialized
INFO - 2018-04-13 18:12:33 --> Helper loaded: url_helper
INFO - 2018-04-13 18:12:33 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-13 18:12:33 --> Helper loaded: notification_helper
INFO - 2018-04-13 18:12:33 --> Helper loaded: settings_helper
INFO - 2018-04-13 18:12:33 --> Helper loaded: permission_helper
INFO - 2018-04-13 18:12:33 --> Helper loaded: users_helper
INFO - 2018-04-13 18:12:33 --> Final output sent to browser
DEBUG - 2018-04-13 18:12:33 --> Total execution time: 0.1147
INFO - 2018-04-13 18:12:33 --> Final output sent to browser
DEBUG - 2018-04-13 18:12:33 --> Total execution time: 0.1277
INFO - 2018-04-13 18:12:33 --> Database Driver Class Initialized
DEBUG - 2018-04-13 18:12:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 18:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 18:12:33 --> Database Driver Class Initialized
INFO - 2018-04-13 18:12:33 --> Helper loaded: form_helper
INFO - 2018-04-13 18:12:33 --> Form Validation Class Initialized
INFO - 2018-04-13 18:12:33 --> Controller Class Initialized
DEBUG - 2018-04-13 18:12:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 18:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 18:12:33 --> Model Class Initialized
INFO - 2018-04-13 18:12:33 --> Helper loaded: inflector_helper
INFO - 2018-04-13 18:12:33 --> Helper loaded: form_helper
INFO - 2018-04-13 18:12:33 --> Form Validation Class Initialized
INFO - 2018-04-13 18:12:33 --> Controller Class Initialized
DEBUG - 2018-04-13 18:12:33 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 18:12:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 18:12:33 --> Model Class Initialized
INFO - 2018-04-13 18:12:33 --> Model Class Initialized
INFO - 2018-04-13 18:12:33 --> Model Class Initialized
INFO - 2018-04-13 18:12:33 --> Model Class Initialized
INFO - 2018-04-13 18:12:33 --> Model Class Initialized
INFO - 2018-04-13 18:12:33 --> Model Class Initialized
INFO - 2018-04-13 18:12:33 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-13 18:12:33 --> Model Class Initialized
INFO - 2018-04-13 18:12:33 --> Helper loaded: inflector_helper
INFO - 2018-04-13 12:42:33 --> Config Class Initialized
INFO - 2018-04-13 12:42:33 --> Hooks Class Initialized
INFO - 2018-04-13 18:12:33 --> Model Class Initialized
INFO - 2018-04-13 18:12:33 --> Final output sent to browser
DEBUG - 2018-04-13 18:12:33 --> Total execution time: 0.1143
DEBUG - 2018-04-13 18:12:33 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-04-13 12:42:33 --> UTF-8 Support Enabled
INFO - 2018-04-13 12:42:33 --> Utf8 Class Initialized
INFO - 2018-04-13 18:12:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 12:42:33 --> URI Class Initialized
INFO - 2018-04-13 18:12:33 --> Model Class Initialized
INFO - 2018-04-13 18:12:33 --> Model Class Initialized
INFO - 2018-04-13 18:12:33 --> Model Class Initialized
INFO - 2018-04-13 18:12:33 --> Model Class Initialized
INFO - 2018-04-13 18:12:33 --> Model Class Initialized
INFO - 2018-04-13 18:12:33 --> Model Class Initialized
INFO - 2018-04-13 18:12:33 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-13 12:42:33 --> Router Class Initialized
INFO - 2018-04-13 18:12:33 --> Model Class Initialized
INFO - 2018-04-13 12:42:33 --> Output Class Initialized
INFO - 2018-04-13 18:12:33 --> Final output sent to browser
DEBUG - 2018-04-13 18:12:33 --> Total execution time: 0.1254
INFO - 2018-04-13 12:42:33 --> Security Class Initialized
DEBUG - 2018-04-13 12:42:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 12:42:33 --> Input Class Initialized
INFO - 2018-04-13 12:42:33 --> Language Class Initialized
INFO - 2018-04-13 12:42:33 --> Language Class Initialized
INFO - 2018-04-13 12:42:33 --> Config Class Initialized
INFO - 2018-04-13 12:42:33 --> Loader Class Initialized
INFO - 2018-04-13 18:12:33 --> Helper loaded: url_helper
INFO - 2018-04-13 18:12:33 --> Helper loaded: notification_helper
INFO - 2018-04-13 18:12:33 --> Helper loaded: settings_helper
INFO - 2018-04-13 18:12:33 --> Helper loaded: permission_helper
INFO - 2018-04-13 18:12:33 --> Helper loaded: users_helper
INFO - 2018-04-13 18:12:33 --> Database Driver Class Initialized
DEBUG - 2018-04-13 18:12:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 18:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 18:12:33 --> Helper loaded: form_helper
INFO - 2018-04-13 18:12:33 --> Form Validation Class Initialized
INFO - 2018-04-13 18:12:33 --> Controller Class Initialized
INFO - 2018-04-13 18:12:33 --> Model Class Initialized
INFO - 2018-04-13 18:12:33 --> Helper loaded: inflector_helper
DEBUG - 2018-04-13 18:12:33 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 18:12:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 18:12:33 --> Model Class Initialized
INFO - 2018-04-13 18:12:33 --> Model Class Initialized
INFO - 2018-04-13 18:12:33 --> Model Class Initialized
INFO - 2018-04-13 18:12:33 --> Model Class Initialized
INFO - 2018-04-13 18:12:33 --> Model Class Initialized
INFO - 2018-04-13 18:12:33 --> Model Class Initialized
INFO - 2018-04-13 18:12:33 --> Model Class Initialized
INFO - 2018-04-13 18:12:33 --> Model Class Initialized
INFO - 2018-04-13 18:12:33 --> Model Class Initialized
INFO - 2018-04-13 18:12:33 --> Model Class Initialized
INFO - 2018-04-13 18:12:33 --> Model Class Initialized
INFO - 2018-04-13 18:12:33 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-13 18:12:33 --> Model Class Initialized
INFO - 2018-04-13 18:12:33 --> Final output sent to browser
DEBUG - 2018-04-13 18:12:33 --> Total execution time: 0.1170
INFO - 2018-04-13 12:43:11 --> Config Class Initialized
INFO - 2018-04-13 12:43:11 --> Hooks Class Initialized
DEBUG - 2018-04-13 12:43:11 --> UTF-8 Support Enabled
INFO - 2018-04-13 12:43:11 --> Utf8 Class Initialized
INFO - 2018-04-13 12:43:11 --> URI Class Initialized
INFO - 2018-04-13 12:43:11 --> Router Class Initialized
INFO - 2018-04-13 12:43:11 --> Output Class Initialized
INFO - 2018-04-13 12:43:11 --> Security Class Initialized
DEBUG - 2018-04-13 12:43:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 12:43:11 --> Input Class Initialized
INFO - 2018-04-13 12:43:11 --> Language Class Initialized
INFO - 2018-04-13 12:43:11 --> Language Class Initialized
INFO - 2018-04-13 12:43:11 --> Config Class Initialized
INFO - 2018-04-13 12:43:11 --> Loader Class Initialized
INFO - 2018-04-13 18:13:11 --> Helper loaded: url_helper
INFO - 2018-04-13 18:13:11 --> Helper loaded: notification_helper
INFO - 2018-04-13 18:13:11 --> Helper loaded: settings_helper
INFO - 2018-04-13 18:13:11 --> Helper loaded: permission_helper
INFO - 2018-04-13 18:13:11 --> Helper loaded: users_helper
INFO - 2018-04-13 18:13:11 --> Database Driver Class Initialized
DEBUG - 2018-04-13 18:13:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 18:13:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 12:43:11 --> Config Class Initialized
INFO - 2018-04-13 12:43:11 --> Hooks Class Initialized
INFO - 2018-04-13 18:13:11 --> Helper loaded: form_helper
INFO - 2018-04-13 18:13:11 --> Form Validation Class Initialized
INFO - 2018-04-13 18:13:11 --> Controller Class Initialized
DEBUG - 2018-04-13 12:43:11 --> UTF-8 Support Enabled
INFO - 2018-04-13 12:43:11 --> Utf8 Class Initialized
INFO - 2018-04-13 12:43:11 --> URI Class Initialized
INFO - 2018-04-13 18:13:11 --> Model Class Initialized
INFO - 2018-04-13 18:13:11 --> Helper loaded: inflector_helper
INFO - 2018-04-13 12:43:11 --> Router Class Initialized
DEBUG - 2018-04-13 18:13:11 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 18:13:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 18:13:11 --> Model Class Initialized
INFO - 2018-04-13 18:13:11 --> Model Class Initialized
INFO - 2018-04-13 18:13:11 --> Model Class Initialized
INFO - 2018-04-13 18:13:11 --> Model Class Initialized
INFO - 2018-04-13 18:13:11 --> Model Class Initialized
INFO - 2018-04-13 18:13:11 --> Model Class Initialized
INFO - 2018-04-13 18:13:11 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-13 12:43:11 --> Output Class Initialized
ERROR - 2018-04-13 18:13:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-04-13 18:13:11 --> Final output sent to browser
DEBUG - 2018-04-13 18:13:11 --> Total execution time: 0.1106
INFO - 2018-04-13 12:43:11 --> Security Class Initialized
DEBUG - 2018-04-13 12:43:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 12:43:11 --> Input Class Initialized
INFO - 2018-04-13 12:43:11 --> Language Class Initialized
INFO - 2018-04-13 12:43:11 --> Language Class Initialized
INFO - 2018-04-13 12:43:11 --> Config Class Initialized
INFO - 2018-04-13 12:43:11 --> Loader Class Initialized
INFO - 2018-04-13 18:13:11 --> Helper loaded: url_helper
INFO - 2018-04-13 18:13:11 --> Helper loaded: notification_helper
INFO - 2018-04-13 18:13:11 --> Helper loaded: settings_helper
INFO - 2018-04-13 18:13:11 --> Helper loaded: permission_helper
INFO - 2018-04-13 18:13:11 --> Helper loaded: users_helper
INFO - 2018-04-13 18:13:11 --> Database Driver Class Initialized
DEBUG - 2018-04-13 18:13:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 18:13:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 18:13:11 --> Helper loaded: form_helper
INFO - 2018-04-13 18:13:11 --> Form Validation Class Initialized
INFO - 2018-04-13 18:13:11 --> Controller Class Initialized
INFO - 2018-04-13 18:13:11 --> Model Class Initialized
INFO - 2018-04-13 18:13:11 --> Helper loaded: inflector_helper
DEBUG - 2018-04-13 18:13:11 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 18:13:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 18:13:11 --> Model Class Initialized
INFO - 2018-04-13 18:13:11 --> Model Class Initialized
INFO - 2018-04-13 18:13:11 --> Model Class Initialized
INFO - 2018-04-13 18:13:11 --> Model Class Initialized
INFO - 2018-04-13 18:13:11 --> Model Class Initialized
INFO - 2018-04-13 18:13:11 --> Model Class Initialized
INFO - 2018-04-13 18:13:11 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-04-13 18:13:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-04-13 18:13:11 --> Final output sent to browser
DEBUG - 2018-04-13 18:13:11 --> Total execution time: 0.1914
INFO - 2018-04-13 12:43:11 --> Config Class Initialized
INFO - 2018-04-13 12:43:11 --> Hooks Class Initialized
DEBUG - 2018-04-13 12:43:11 --> UTF-8 Support Enabled
INFO - 2018-04-13 12:43:11 --> Utf8 Class Initialized
INFO - 2018-04-13 12:43:11 --> URI Class Initialized
INFO - 2018-04-13 12:43:11 --> Router Class Initialized
INFO - 2018-04-13 12:43:11 --> Output Class Initialized
INFO - 2018-04-13 12:43:11 --> Security Class Initialized
DEBUG - 2018-04-13 12:43:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 12:43:11 --> Input Class Initialized
INFO - 2018-04-13 12:43:11 --> Language Class Initialized
INFO - 2018-04-13 12:43:11 --> Language Class Initialized
INFO - 2018-04-13 12:43:11 --> Config Class Initialized
INFO - 2018-04-13 12:43:11 --> Loader Class Initialized
INFO - 2018-04-13 18:13:11 --> Helper loaded: url_helper
INFO - 2018-04-13 18:13:11 --> Helper loaded: notification_helper
INFO - 2018-04-13 18:13:11 --> Helper loaded: settings_helper
INFO - 2018-04-13 18:13:11 --> Helper loaded: permission_helper
INFO - 2018-04-13 18:13:11 --> Helper loaded: users_helper
INFO - 2018-04-13 18:13:11 --> Database Driver Class Initialized
DEBUG - 2018-04-13 18:13:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 18:13:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 18:13:11 --> Helper loaded: form_helper
INFO - 2018-04-13 18:13:11 --> Form Validation Class Initialized
INFO - 2018-04-13 18:13:11 --> Controller Class Initialized
INFO - 2018-04-13 18:13:12 --> Model Class Initialized
INFO - 2018-04-13 18:13:12 --> Helper loaded: inflector_helper
DEBUG - 2018-04-13 18:13:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 18:13:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 18:13:12 --> Model Class Initialized
INFO - 2018-04-13 18:13:12 --> Model Class Initialized
INFO - 2018-04-13 18:13:12 --> Model Class Initialized
INFO - 2018-04-13 18:13:12 --> Model Class Initialized
INFO - 2018-04-13 18:13:12 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-13 18:13:12 --> Final output sent to browser
DEBUG - 2018-04-13 18:13:12 --> Total execution time: 0.0960
INFO - 2018-04-13 12:43:12 --> Config Class Initialized
INFO - 2018-04-13 12:43:12 --> Hooks Class Initialized
DEBUG - 2018-04-13 12:43:12 --> UTF-8 Support Enabled
INFO - 2018-04-13 12:43:12 --> Utf8 Class Initialized
INFO - 2018-04-13 12:43:12 --> URI Class Initialized
INFO - 2018-04-13 12:43:12 --> Router Class Initialized
INFO - 2018-04-13 12:43:12 --> Output Class Initialized
INFO - 2018-04-13 12:43:12 --> Security Class Initialized
DEBUG - 2018-04-13 12:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 12:43:12 --> Input Class Initialized
INFO - 2018-04-13 12:43:12 --> Language Class Initialized
INFO - 2018-04-13 12:43:12 --> Language Class Initialized
INFO - 2018-04-13 12:43:12 --> Config Class Initialized
INFO - 2018-04-13 12:43:12 --> Loader Class Initialized
INFO - 2018-04-13 18:13:12 --> Helper loaded: url_helper
INFO - 2018-04-13 18:13:12 --> Helper loaded: notification_helper
INFO - 2018-04-13 18:13:12 --> Helper loaded: settings_helper
INFO - 2018-04-13 12:43:12 --> Config Class Initialized
INFO - 2018-04-13 12:43:12 --> Hooks Class Initialized
INFO - 2018-04-13 18:13:12 --> Helper loaded: permission_helper
INFO - 2018-04-13 18:13:12 --> Helper loaded: users_helper
DEBUG - 2018-04-13 12:43:12 --> UTF-8 Support Enabled
INFO - 2018-04-13 12:43:12 --> Utf8 Class Initialized
INFO - 2018-04-13 12:43:12 --> URI Class Initialized
INFO - 2018-04-13 12:43:12 --> Router Class Initialized
INFO - 2018-04-13 12:43:12 --> Output Class Initialized
INFO - 2018-04-13 12:43:12 --> Security Class Initialized
INFO - 2018-04-13 18:13:12 --> Database Driver Class Initialized
DEBUG - 2018-04-13 12:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 12:43:12 --> Input Class Initialized
INFO - 2018-04-13 12:43:12 --> Language Class Initialized
DEBUG - 2018-04-13 18:13:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 18:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 18:13:12 --> Helper loaded: form_helper
INFO - 2018-04-13 18:13:12 --> Form Validation Class Initialized
INFO - 2018-04-13 18:13:12 --> Controller Class Initialized
INFO - 2018-04-13 18:13:12 --> Model Class Initialized
INFO - 2018-04-13 18:13:12 --> Helper loaded: inflector_helper
INFO - 2018-04-13 12:43:12 --> Language Class Initialized
INFO - 2018-04-13 12:43:12 --> Config Class Initialized
INFO - 2018-04-13 12:43:12 --> Loader Class Initialized
DEBUG - 2018-04-13 18:13:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 18:13:12 --> Helper loaded: url_helper
INFO - 2018-04-13 18:13:12 --> Helper loaded: notification_helper
INFO - 2018-04-13 18:13:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 18:13:12 --> Helper loaded: settings_helper
INFO - 2018-04-13 18:13:12 --> Helper loaded: permission_helper
INFO - 2018-04-13 18:13:12 --> Model Class Initialized
INFO - 2018-04-13 18:13:12 --> Model Class Initialized
INFO - 2018-04-13 18:13:12 --> Helper loaded: users_helper
INFO - 2018-04-13 18:13:12 --> Model Class Initialized
INFO - 2018-04-13 18:13:12 --> Model Class Initialized
INFO - 2018-04-13 18:13:12 --> Model Class Initialized
INFO - 2018-04-13 18:13:12 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-13 18:13:12 --> Model Class Initialized
INFO - 2018-04-13 18:13:12 --> Final output sent to browser
DEBUG - 2018-04-13 18:13:12 --> Total execution time: 0.1260
INFO - 2018-04-13 18:13:12 --> Database Driver Class Initialized
DEBUG - 2018-04-13 18:13:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 18:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 18:13:12 --> Helper loaded: form_helper
INFO - 2018-04-13 18:13:12 --> Form Validation Class Initialized
INFO - 2018-04-13 18:13:12 --> Controller Class Initialized
INFO - 2018-04-13 18:13:12 --> Model Class Initialized
INFO - 2018-04-13 18:13:12 --> Helper loaded: inflector_helper
DEBUG - 2018-04-13 18:13:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 18:13:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 18:13:12 --> Model Class Initialized
INFO - 2018-04-13 18:13:12 --> Model Class Initialized
INFO - 2018-04-13 18:13:12 --> Model Class Initialized
INFO - 2018-04-13 18:13:12 --> Model Class Initialized
INFO - 2018-04-13 18:13:12 --> Model Class Initialized
INFO - 2018-04-13 18:13:12 --> Model Class Initialized
INFO - 2018-04-13 18:13:12 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-04-13 18:13:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-04-13 18:13:12 --> Final output sent to browser
DEBUG - 2018-04-13 18:13:12 --> Total execution time: 0.1131
INFO - 2018-04-13 13:22:49 --> Config Class Initialized
INFO - 2018-04-13 13:22:49 --> Hooks Class Initialized
DEBUG - 2018-04-13 13:22:49 --> UTF-8 Support Enabled
INFO - 2018-04-13 13:22:49 --> Utf8 Class Initialized
INFO - 2018-04-13 13:22:49 --> URI Class Initialized
INFO - 2018-04-13 13:22:49 --> Router Class Initialized
INFO - 2018-04-13 13:22:49 --> Output Class Initialized
INFO - 2018-04-13 13:22:49 --> Security Class Initialized
DEBUG - 2018-04-13 13:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 13:22:49 --> Input Class Initialized
INFO - 2018-04-13 13:22:49 --> Language Class Initialized
INFO - 2018-04-13 13:22:49 --> Config Class Initialized
INFO - 2018-04-13 13:22:49 --> Hooks Class Initialized
DEBUG - 2018-04-13 13:22:49 --> UTF-8 Support Enabled
INFO - 2018-04-13 13:22:49 --> Utf8 Class Initialized
INFO - 2018-04-13 13:22:49 --> URI Class Initialized
INFO - 2018-04-13 13:22:49 --> Language Class Initialized
INFO - 2018-04-13 13:22:49 --> Config Class Initialized
INFO - 2018-04-13 13:22:49 --> Loader Class Initialized
INFO - 2018-04-13 18:52:49 --> Helper loaded: url_helper
INFO - 2018-04-13 13:22:49 --> Router Class Initialized
INFO - 2018-04-13 18:52:49 --> Helper loaded: notification_helper
INFO - 2018-04-13 18:52:49 --> Helper loaded: settings_helper
INFO - 2018-04-13 18:52:49 --> Helper loaded: permission_helper
INFO - 2018-04-13 18:52:49 --> Helper loaded: users_helper
INFO - 2018-04-13 13:22:49 --> Output Class Initialized
INFO - 2018-04-13 13:22:49 --> Security Class Initialized
DEBUG - 2018-04-13 13:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 13:22:49 --> Input Class Initialized
INFO - 2018-04-13 13:22:49 --> Language Class Initialized
INFO - 2018-04-13 18:52:49 --> Database Driver Class Initialized
DEBUG - 2018-04-13 18:52:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 18:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 13:22:49 --> Language Class Initialized
INFO - 2018-04-13 13:22:49 --> Config Class Initialized
INFO - 2018-04-13 13:22:49 --> Loader Class Initialized
INFO - 2018-04-13 18:52:49 --> Helper loaded: url_helper
INFO - 2018-04-13 18:52:49 --> Helper loaded: form_helper
INFO - 2018-04-13 18:52:49 --> Form Validation Class Initialized
INFO - 2018-04-13 18:52:49 --> Controller Class Initialized
INFO - 2018-04-13 18:52:49 --> Helper loaded: notification_helper
INFO - 2018-04-13 18:52:49 --> Helper loaded: settings_helper
INFO - 2018-04-13 18:52:49 --> Helper loaded: permission_helper
INFO - 2018-04-13 18:52:49 --> Helper loaded: users_helper
INFO - 2018-04-13 18:52:49 --> Model Class Initialized
INFO - 2018-04-13 18:52:49 --> Helper loaded: inflector_helper
DEBUG - 2018-04-13 18:52:49 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 18:52:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 18:52:49 --> Model Class Initialized
INFO - 2018-04-13 18:52:49 --> Model Class Initialized
INFO - 2018-04-13 18:52:49 --> Model Class Initialized
INFO - 2018-04-13 18:52:49 --> Model Class Initialized
INFO - 2018-04-13 18:52:49 --> Database Driver Class Initialized
INFO - 2018-04-13 18:52:49 --> Model Class Initialized
INFO - 2018-04-13 18:52:49 --> Model Class Initialized
INFO - 2018-04-13 18:52:49 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-13 18:52:49 --> Final output sent to browser
DEBUG - 2018-04-13 18:52:49 --> Total execution time: 0.1161
DEBUG - 2018-04-13 18:52:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 18:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 18:52:49 --> Helper loaded: form_helper
INFO - 2018-04-13 18:52:49 --> Form Validation Class Initialized
INFO - 2018-04-13 18:52:49 --> Controller Class Initialized
INFO - 2018-04-13 18:52:49 --> Model Class Initialized
INFO - 2018-04-13 18:52:49 --> Helper loaded: inflector_helper
DEBUG - 2018-04-13 18:52:49 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 18:52:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 18:52:49 --> Model Class Initialized
INFO - 2018-04-13 18:52:49 --> Model Class Initialized
INFO - 2018-04-13 18:52:49 --> Model Class Initialized
INFO - 2018-04-13 18:52:49 --> Model Class Initialized
INFO - 2018-04-13 18:52:49 --> Model Class Initialized
INFO - 2018-04-13 18:52:49 --> Model Class Initialized
INFO - 2018-04-13 18:52:49 --> Model Class Initialized
INFO - 2018-04-13 18:52:49 --> Model Class Initialized
INFO - 2018-04-13 18:52:49 --> Model Class Initialized
INFO - 2018-04-13 18:52:49 --> Model Class Initialized
INFO - 2018-04-13 18:52:49 --> Model Class Initialized
INFO - 2018-04-13 18:52:49 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-13 18:52:49 --> Model Class Initialized
INFO - 2018-04-13 18:52:49 --> Final output sent to browser
DEBUG - 2018-04-13 18:52:49 --> Total execution time: 0.1287
INFO - 2018-04-13 13:22:49 --> Config Class Initialized
INFO - 2018-04-13 13:22:49 --> Hooks Class Initialized
DEBUG - 2018-04-13 13:22:49 --> UTF-8 Support Enabled
INFO - 2018-04-13 13:22:49 --> Utf8 Class Initialized
INFO - 2018-04-13 13:22:49 --> URI Class Initialized
INFO - 2018-04-13 13:22:49 --> Router Class Initialized
INFO - 2018-04-13 13:22:49 --> Output Class Initialized
INFO - 2018-04-13 13:22:49 --> Security Class Initialized
DEBUG - 2018-04-13 13:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 13:22:49 --> Input Class Initialized
INFO - 2018-04-13 13:22:49 --> Language Class Initialized
INFO - 2018-04-13 13:22:50 --> Language Class Initialized
INFO - 2018-04-13 13:22:50 --> Config Class Initialized
INFO - 2018-04-13 13:22:50 --> Loader Class Initialized
INFO - 2018-04-13 18:52:50 --> Helper loaded: url_helper
INFO - 2018-04-13 18:52:50 --> Helper loaded: notification_helper
INFO - 2018-04-13 18:52:50 --> Helper loaded: settings_helper
INFO - 2018-04-13 18:52:50 --> Helper loaded: permission_helper
INFO - 2018-04-13 18:52:50 --> Helper loaded: users_helper
INFO - 2018-04-13 18:52:50 --> Database Driver Class Initialized
INFO - 2018-04-13 13:22:50 --> Config Class Initialized
INFO - 2018-04-13 13:22:50 --> Hooks Class Initialized
DEBUG - 2018-04-13 13:22:50 --> UTF-8 Support Enabled
INFO - 2018-04-13 13:22:50 --> Utf8 Class Initialized
DEBUG - 2018-04-13 18:52:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 18:52:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 13:22:50 --> URI Class Initialized
INFO - 2018-04-13 13:22:50 --> Router Class Initialized
INFO - 2018-04-13 13:22:50 --> Output Class Initialized
INFO - 2018-04-13 18:52:50 --> Helper loaded: form_helper
INFO - 2018-04-13 18:52:50 --> Form Validation Class Initialized
INFO - 2018-04-13 18:52:50 --> Controller Class Initialized
INFO - 2018-04-13 13:22:50 --> Security Class Initialized
DEBUG - 2018-04-13 13:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 13:22:50 --> Input Class Initialized
INFO - 2018-04-13 13:22:50 --> Language Class Initialized
INFO - 2018-04-13 18:52:50 --> Model Class Initialized
INFO - 2018-04-13 18:52:50 --> Helper loaded: inflector_helper
DEBUG - 2018-04-13 18:52:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 18:52:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 18:52:50 --> Model Class Initialized
INFO - 2018-04-13 18:52:50 --> Model Class Initialized
INFO - 2018-04-13 18:52:50 --> Model Class Initialized
INFO - 2018-04-13 18:52:50 --> Model Class Initialized
INFO - 2018-04-13 18:52:50 --> Model Class Initialized
INFO - 2018-04-13 18:52:50 --> Model Class Initialized
INFO - 2018-04-13 18:52:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-13 18:52:50 --> Model Class Initialized
INFO - 2018-04-13 18:52:50 --> Final output sent to browser
DEBUG - 2018-04-13 18:52:50 --> Total execution time: 0.1098
INFO - 2018-04-13 13:22:50 --> Language Class Initialized
INFO - 2018-04-13 13:22:50 --> Config Class Initialized
INFO - 2018-04-13 13:22:50 --> Loader Class Initialized
INFO - 2018-04-13 18:52:50 --> Helper loaded: url_helper
INFO - 2018-04-13 18:52:50 --> Helper loaded: notification_helper
INFO - 2018-04-13 18:52:50 --> Helper loaded: settings_helper
INFO - 2018-04-13 18:52:50 --> Helper loaded: permission_helper
INFO - 2018-04-13 18:52:50 --> Helper loaded: users_helper
INFO - 2018-04-13 18:52:50 --> Database Driver Class Initialized
DEBUG - 2018-04-13 18:52:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 18:52:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 18:52:50 --> Helper loaded: form_helper
INFO - 2018-04-13 18:52:50 --> Form Validation Class Initialized
INFO - 2018-04-13 18:52:50 --> Controller Class Initialized
INFO - 2018-04-13 18:52:50 --> Model Class Initialized
INFO - 2018-04-13 18:52:50 --> Helper loaded: inflector_helper
DEBUG - 2018-04-13 18:52:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 18:52:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 18:52:50 --> Model Class Initialized
INFO - 2018-04-13 18:52:50 --> Model Class Initialized
INFO - 2018-04-13 18:52:50 --> Model Class Initialized
INFO - 2018-04-13 18:52:50 --> Model Class Initialized
INFO - 2018-04-13 18:52:50 --> Model Class Initialized
INFO - 2018-04-13 18:52:50 --> Model Class Initialized
INFO - 2018-04-13 18:52:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-13 18:52:50 --> Model Class Initialized
INFO - 2018-04-13 18:52:50 --> Final output sent to browser
DEBUG - 2018-04-13 18:52:50 --> Total execution time: 0.1066
INFO - 2018-04-13 13:22:50 --> Config Class Initialized
INFO - 2018-04-13 13:22:50 --> Hooks Class Initialized
DEBUG - 2018-04-13 13:22:50 --> UTF-8 Support Enabled
INFO - 2018-04-13 13:22:50 --> Utf8 Class Initialized
INFO - 2018-04-13 13:22:50 --> URI Class Initialized
INFO - 2018-04-13 13:22:50 --> Router Class Initialized
INFO - 2018-04-13 13:22:50 --> Output Class Initialized
INFO - 2018-04-13 13:22:50 --> Security Class Initialized
DEBUG - 2018-04-13 13:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 13:22:50 --> Input Class Initialized
INFO - 2018-04-13 13:22:50 --> Language Class Initialized
INFO - 2018-04-13 13:22:50 --> Language Class Initialized
INFO - 2018-04-13 13:22:50 --> Config Class Initialized
INFO - 2018-04-13 13:22:50 --> Loader Class Initialized
INFO - 2018-04-13 18:52:50 --> Helper loaded: url_helper
INFO - 2018-04-13 18:52:50 --> Helper loaded: notification_helper
INFO - 2018-04-13 18:52:50 --> Helper loaded: settings_helper
INFO - 2018-04-13 18:52:50 --> Helper loaded: permission_helper
INFO - 2018-04-13 18:52:50 --> Helper loaded: users_helper
INFO - 2018-04-13 18:52:50 --> Database Driver Class Initialized
DEBUG - 2018-04-13 18:52:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 18:52:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 18:52:50 --> Helper loaded: form_helper
INFO - 2018-04-13 18:52:50 --> Form Validation Class Initialized
INFO - 2018-04-13 18:52:50 --> Controller Class Initialized
INFO - 2018-04-13 18:52:50 --> Model Class Initialized
INFO - 2018-04-13 18:52:50 --> Helper loaded: inflector_helper
DEBUG - 2018-04-13 18:52:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 18:52:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 18:52:50 --> Model Class Initialized
INFO - 2018-04-13 18:52:50 --> Model Class Initialized
INFO - 2018-04-13 18:52:50 --> Model Class Initialized
INFO - 2018-04-13 18:52:50 --> Model Class Initialized
INFO - 2018-04-13 18:52:50 --> Model Class Initialized
INFO - 2018-04-13 18:52:50 --> Model Class Initialized
INFO - 2018-04-13 18:52:50 --> Model Class Initialized
INFO - 2018-04-13 18:52:50 --> Model Class Initialized
INFO - 2018-04-13 18:52:50 --> Model Class Initialized
INFO - 2018-04-13 18:52:50 --> Model Class Initialized
INFO - 2018-04-13 18:52:50 --> Model Class Initialized
INFO - 2018-04-13 18:52:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-13 18:52:50 --> Model Class Initialized
INFO - 2018-04-13 18:52:50 --> Final output sent to browser
DEBUG - 2018-04-13 18:52:50 --> Total execution time: 0.1205
INFO - 2018-04-13 13:22:50 --> Config Class Initialized
INFO - 2018-04-13 13:22:50 --> Hooks Class Initialized
DEBUG - 2018-04-13 13:22:50 --> UTF-8 Support Enabled
INFO - 2018-04-13 13:22:50 --> Utf8 Class Initialized
INFO - 2018-04-13 13:22:50 --> URI Class Initialized
INFO - 2018-04-13 13:22:50 --> Router Class Initialized
INFO - 2018-04-13 13:22:50 --> Output Class Initialized
INFO - 2018-04-13 13:22:50 --> Security Class Initialized
DEBUG - 2018-04-13 13:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 13:22:50 --> Input Class Initialized
INFO - 2018-04-13 13:22:50 --> Language Class Initialized
INFO - 2018-04-13 13:22:51 --> Language Class Initialized
INFO - 2018-04-13 13:22:51 --> Config Class Initialized
INFO - 2018-04-13 13:22:51 --> Loader Class Initialized
INFO - 2018-04-13 18:52:51 --> Helper loaded: url_helper
INFO - 2018-04-13 18:52:51 --> Helper loaded: notification_helper
INFO - 2018-04-13 18:52:51 --> Helper loaded: settings_helper
INFO - 2018-04-13 18:52:51 --> Helper loaded: permission_helper
INFO - 2018-04-13 18:52:51 --> Helper loaded: users_helper
INFO - 2018-04-13 18:52:51 --> Database Driver Class Initialized
DEBUG - 2018-04-13 18:52:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 18:52:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 18:52:51 --> Helper loaded: form_helper
INFO - 2018-04-13 18:52:51 --> Form Validation Class Initialized
INFO - 2018-04-13 18:52:51 --> Controller Class Initialized
INFO - 2018-04-13 18:52:51 --> Model Class Initialized
INFO - 2018-04-13 18:52:51 --> Helper loaded: inflector_helper
DEBUG - 2018-04-13 18:52:51 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 18:52:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 18:52:51 --> Model Class Initialized
INFO - 2018-04-13 18:52:51 --> Model Class Initialized
INFO - 2018-04-13 18:52:51 --> Model Class Initialized
INFO - 2018-04-13 18:52:51 --> Model Class Initialized
INFO - 2018-04-13 18:52:51 --> Final output sent to browser
DEBUG - 2018-04-13 18:52:51 --> Total execution time: 0.1087
INFO - 2018-04-13 13:22:54 --> Config Class Initialized
INFO - 2018-04-13 13:22:54 --> Hooks Class Initialized
DEBUG - 2018-04-13 13:22:54 --> UTF-8 Support Enabled
INFO - 2018-04-13 13:22:54 --> Utf8 Class Initialized
INFO - 2018-04-13 13:22:54 --> URI Class Initialized
INFO - 2018-04-13 13:22:54 --> Router Class Initialized
INFO - 2018-04-13 13:22:54 --> Output Class Initialized
INFO - 2018-04-13 13:22:54 --> Security Class Initialized
DEBUG - 2018-04-13 13:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 13:22:54 --> Input Class Initialized
INFO - 2018-04-13 13:22:54 --> Language Class Initialized
INFO - 2018-04-13 13:22:54 --> Language Class Initialized
INFO - 2018-04-13 13:22:54 --> Config Class Initialized
INFO - 2018-04-13 13:22:54 --> Loader Class Initialized
INFO - 2018-04-13 18:52:54 --> Helper loaded: url_helper
INFO - 2018-04-13 18:52:54 --> Helper loaded: notification_helper
INFO - 2018-04-13 18:52:54 --> Helper loaded: settings_helper
INFO - 2018-04-13 18:52:54 --> Helper loaded: permission_helper
INFO - 2018-04-13 18:52:54 --> Helper loaded: users_helper
INFO - 2018-04-13 13:22:54 --> Config Class Initialized
INFO - 2018-04-13 13:22:54 --> Hooks Class Initialized
INFO - 2018-04-13 18:52:54 --> Database Driver Class Initialized
DEBUG - 2018-04-13 13:22:54 --> UTF-8 Support Enabled
INFO - 2018-04-13 13:22:54 --> Utf8 Class Initialized
INFO - 2018-04-13 13:22:54 --> URI Class Initialized
DEBUG - 2018-04-13 18:52:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 18:52:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 13:22:54 --> Router Class Initialized
INFO - 2018-04-13 13:22:54 --> Output Class Initialized
INFO - 2018-04-13 18:52:54 --> Helper loaded: form_helper
INFO - 2018-04-13 18:52:54 --> Form Validation Class Initialized
INFO - 2018-04-13 18:52:54 --> Controller Class Initialized
INFO - 2018-04-13 13:22:54 --> Security Class Initialized
DEBUG - 2018-04-13 13:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 13:22:54 --> Input Class Initialized
INFO - 2018-04-13 13:22:54 --> Language Class Initialized
INFO - 2018-04-13 18:52:54 --> Model Class Initialized
INFO - 2018-04-13 18:52:54 --> Helper loaded: inflector_helper
DEBUG - 2018-04-13 18:52:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 18:52:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 18:52:54 --> Model Class Initialized
INFO - 2018-04-13 18:52:54 --> Model Class Initialized
INFO - 2018-04-13 18:52:54 --> Model Class Initialized
INFO - 2018-04-13 18:52:54 --> Model Class Initialized
INFO - 2018-04-13 18:52:54 --> Model Class Initialized
INFO - 2018-04-13 18:52:54 --> Model Class Initialized
INFO - 2018-04-13 18:52:54 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-13 18:52:54 --> Model Class Initialized
INFO - 2018-04-13 13:22:54 --> Language Class Initialized
INFO - 2018-04-13 13:22:54 --> Config Class Initialized
INFO - 2018-04-13 13:22:54 --> Loader Class Initialized
INFO - 2018-04-13 18:52:54 --> Final output sent to browser
DEBUG - 2018-04-13 18:52:54 --> Total execution time: 0.1092
INFO - 2018-04-13 18:52:54 --> Helper loaded: url_helper
INFO - 2018-04-13 18:52:54 --> Helper loaded: notification_helper
INFO - 2018-04-13 18:52:54 --> Helper loaded: settings_helper
INFO - 2018-04-13 18:52:54 --> Helper loaded: permission_helper
INFO - 2018-04-13 18:52:54 --> Helper loaded: users_helper
INFO - 2018-04-13 18:52:54 --> Database Driver Class Initialized
DEBUG - 2018-04-13 18:52:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 18:52:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 18:52:54 --> Helper loaded: form_helper
INFO - 2018-04-13 18:52:54 --> Form Validation Class Initialized
INFO - 2018-04-13 18:52:54 --> Controller Class Initialized
INFO - 2018-04-13 18:52:54 --> Model Class Initialized
INFO - 2018-04-13 18:52:54 --> Helper loaded: inflector_helper
DEBUG - 2018-04-13 18:52:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 18:52:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 18:52:54 --> Model Class Initialized
INFO - 2018-04-13 18:52:54 --> Model Class Initialized
INFO - 2018-04-13 18:52:54 --> Model Class Initialized
INFO - 2018-04-13 18:52:54 --> Model Class Initialized
INFO - 2018-04-13 18:52:54 --> Model Class Initialized
INFO - 2018-04-13 18:52:54 --> Model Class Initialized
INFO - 2018-04-13 18:52:54 --> Model Class Initialized
INFO - 2018-04-13 18:52:54 --> Model Class Initialized
INFO - 2018-04-13 18:52:54 --> Model Class Initialized
INFO - 2018-04-13 18:52:54 --> Model Class Initialized
INFO - 2018-04-13 18:52:54 --> Model Class Initialized
INFO - 2018-04-13 18:52:54 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-13 18:52:54 --> Model Class Initialized
INFO - 2018-04-13 18:52:54 --> Final output sent to browser
DEBUG - 2018-04-13 18:52:54 --> Total execution time: 0.1191
INFO - 2018-04-13 13:22:55 --> Config Class Initialized
INFO - 2018-04-13 13:22:55 --> Hooks Class Initialized
DEBUG - 2018-04-13 13:22:55 --> UTF-8 Support Enabled
INFO - 2018-04-13 13:22:55 --> Utf8 Class Initialized
INFO - 2018-04-13 13:22:55 --> URI Class Initialized
INFO - 2018-04-13 13:22:55 --> Router Class Initialized
INFO - 2018-04-13 13:22:55 --> Output Class Initialized
INFO - 2018-04-13 13:22:55 --> Security Class Initialized
DEBUG - 2018-04-13 13:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 13:22:55 --> Input Class Initialized
INFO - 2018-04-13 13:22:55 --> Language Class Initialized
INFO - 2018-04-13 13:22:56 --> Language Class Initialized
INFO - 2018-04-13 13:22:56 --> Config Class Initialized
INFO - 2018-04-13 13:22:56 --> Loader Class Initialized
INFO - 2018-04-13 18:52:56 --> Helper loaded: url_helper
INFO - 2018-04-13 18:52:56 --> Helper loaded: notification_helper
INFO - 2018-04-13 18:52:56 --> Helper loaded: settings_helper
INFO - 2018-04-13 18:52:56 --> Helper loaded: permission_helper
INFO - 2018-04-13 18:52:56 --> Helper loaded: users_helper
INFO - 2018-04-13 18:52:56 --> Database Driver Class Initialized
DEBUG - 2018-04-13 18:52:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 18:52:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 18:52:56 --> Helper loaded: form_helper
INFO - 2018-04-13 18:52:56 --> Form Validation Class Initialized
INFO - 2018-04-13 18:52:56 --> Controller Class Initialized
INFO - 2018-04-13 18:52:56 --> Model Class Initialized
INFO - 2018-04-13 18:52:56 --> Helper loaded: inflector_helper
DEBUG - 2018-04-13 18:52:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 18:52:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 18:52:56 --> Model Class Initialized
INFO - 2018-04-13 18:52:56 --> Model Class Initialized
INFO - 2018-04-13 18:52:56 --> Model Class Initialized
INFO - 2018-04-13 18:52:56 --> Model Class Initialized
INFO - 2018-04-13 18:52:56 --> Model Class Initialized
INFO - 2018-04-13 18:52:56 --> Model Class Initialized
INFO - 2018-04-13 18:52:56 --> Model Class Initialized
INFO - 2018-04-13 18:52:56 --> Model Class Initialized
INFO - 2018-04-13 18:52:56 --> Model Class Initialized
INFO - 2018-04-13 18:52:56 --> Model Class Initialized
INFO - 2018-04-13 18:52:56 --> Model Class Initialized
INFO - 2018-04-13 18:52:56 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-13 18:52:56 --> Model Class Initialized
INFO - 2018-04-13 18:52:56 --> Final output sent to browser
DEBUG - 2018-04-13 18:52:56 --> Total execution time: 0.1125
INFO - 2018-04-13 13:22:56 --> Config Class Initialized
INFO - 2018-04-13 13:22:56 --> Hooks Class Initialized
DEBUG - 2018-04-13 13:22:56 --> UTF-8 Support Enabled
INFO - 2018-04-13 13:22:56 --> Utf8 Class Initialized
INFO - 2018-04-13 13:22:56 --> URI Class Initialized
INFO - 2018-04-13 13:22:56 --> Router Class Initialized
INFO - 2018-04-13 13:22:56 --> Output Class Initialized
INFO - 2018-04-13 13:22:56 --> Security Class Initialized
DEBUG - 2018-04-13 13:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 13:22:56 --> Input Class Initialized
INFO - 2018-04-13 13:22:56 --> Language Class Initialized
INFO - 2018-04-13 13:22:56 --> Language Class Initialized
INFO - 2018-04-13 13:22:56 --> Config Class Initialized
INFO - 2018-04-13 13:22:56 --> Loader Class Initialized
INFO - 2018-04-13 18:52:56 --> Helper loaded: url_helper
INFO - 2018-04-13 18:52:56 --> Helper loaded: notification_helper
INFO - 2018-04-13 18:52:56 --> Helper loaded: settings_helper
INFO - 2018-04-13 18:52:56 --> Helper loaded: permission_helper
INFO - 2018-04-13 18:52:56 --> Helper loaded: users_helper
INFO - 2018-04-13 18:52:56 --> Database Driver Class Initialized
DEBUG - 2018-04-13 18:52:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 18:52:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 18:52:56 --> Helper loaded: form_helper
INFO - 2018-04-13 18:52:56 --> Form Validation Class Initialized
INFO - 2018-04-13 18:52:56 --> Controller Class Initialized
INFO - 2018-04-13 18:52:56 --> Model Class Initialized
INFO - 2018-04-13 18:52:56 --> Helper loaded: inflector_helper
DEBUG - 2018-04-13 18:52:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 18:52:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 18:52:56 --> Model Class Initialized
INFO - 2018-04-13 18:52:56 --> Model Class Initialized
INFO - 2018-04-13 18:52:56 --> Model Class Initialized
INFO - 2018-04-13 18:52:56 --> Model Class Initialized
INFO - 2018-04-13 18:52:56 --> Model Class Initialized
INFO - 2018-04-13 18:52:56 --> Model Class Initialized
INFO - 2018-04-13 18:52:56 --> Model Class Initialized
INFO - 2018-04-13 18:52:56 --> Model Class Initialized
INFO - 2018-04-13 18:52:56 --> Model Class Initialized
INFO - 2018-04-13 18:52:56 --> Model Class Initialized
INFO - 2018-04-13 18:52:56 --> Model Class Initialized
INFO - 2018-04-13 18:52:56 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-13 18:52:56 --> Final output sent to browser
DEBUG - 2018-04-13 18:52:56 --> Total execution time: 0.1345
INFO - 2018-04-13 13:22:59 --> Config Class Initialized
INFO - 2018-04-13 13:22:59 --> Hooks Class Initialized
DEBUG - 2018-04-13 13:22:59 --> UTF-8 Support Enabled
INFO - 2018-04-13 13:22:59 --> Utf8 Class Initialized
INFO - 2018-04-13 13:22:59 --> URI Class Initialized
INFO - 2018-04-13 13:22:59 --> Router Class Initialized
INFO - 2018-04-13 13:22:59 --> Output Class Initialized
INFO - 2018-04-13 13:22:59 --> Security Class Initialized
DEBUG - 2018-04-13 13:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 13:22:59 --> Input Class Initialized
INFO - 2018-04-13 13:22:59 --> Language Class Initialized
INFO - 2018-04-13 13:22:59 --> Language Class Initialized
INFO - 2018-04-13 13:22:59 --> Config Class Initialized
INFO - 2018-04-13 13:22:59 --> Loader Class Initialized
INFO - 2018-04-13 18:52:59 --> Helper loaded: url_helper
INFO - 2018-04-13 18:52:59 --> Helper loaded: notification_helper
INFO - 2018-04-13 18:52:59 --> Helper loaded: settings_helper
INFO - 2018-04-13 18:52:59 --> Helper loaded: permission_helper
INFO - 2018-04-13 18:52:59 --> Helper loaded: users_helper
INFO - 2018-04-13 18:52:59 --> Database Driver Class Initialized
DEBUG - 2018-04-13 18:52:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 18:52:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 18:52:59 --> Helper loaded: form_helper
INFO - 2018-04-13 18:52:59 --> Form Validation Class Initialized
INFO - 2018-04-13 18:52:59 --> Controller Class Initialized
INFO - 2018-04-13 18:52:59 --> Model Class Initialized
INFO - 2018-04-13 18:52:59 --> Helper loaded: inflector_helper
DEBUG - 2018-04-13 18:52:59 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 18:52:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 18:52:59 --> Model Class Initialized
INFO - 2018-04-13 18:52:59 --> Model Class Initialized
INFO - 2018-04-13 18:52:59 --> Model Class Initialized
INFO - 2018-04-13 18:52:59 --> Model Class Initialized
INFO - 2018-04-13 18:52:59 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-13 18:52:59 --> Final output sent to browser
DEBUG - 2018-04-13 18:52:59 --> Total execution time: 0.1021
INFO - 2018-04-13 13:23:00 --> Config Class Initialized
INFO - 2018-04-13 13:23:00 --> Hooks Class Initialized
DEBUG - 2018-04-13 13:23:00 --> UTF-8 Support Enabled
INFO - 2018-04-13 13:23:00 --> Utf8 Class Initialized
INFO - 2018-04-13 13:23:00 --> URI Class Initialized
INFO - 2018-04-13 13:23:00 --> Router Class Initialized
INFO - 2018-04-13 13:23:00 --> Output Class Initialized
INFO - 2018-04-13 13:23:00 --> Security Class Initialized
DEBUG - 2018-04-13 13:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 13:23:00 --> Input Class Initialized
INFO - 2018-04-13 13:23:00 --> Language Class Initialized
INFO - 2018-04-13 13:23:00 --> Language Class Initialized
INFO - 2018-04-13 13:23:00 --> Config Class Initialized
INFO - 2018-04-13 13:23:00 --> Loader Class Initialized
INFO - 2018-04-13 18:53:00 --> Helper loaded: url_helper
INFO - 2018-04-13 18:53:00 --> Helper loaded: notification_helper
INFO - 2018-04-13 18:53:00 --> Helper loaded: settings_helper
INFO - 2018-04-13 18:53:00 --> Helper loaded: permission_helper
INFO - 2018-04-13 18:53:00 --> Helper loaded: users_helper
INFO - 2018-04-13 18:53:00 --> Database Driver Class Initialized
DEBUG - 2018-04-13 18:53:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 18:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 18:53:00 --> Helper loaded: form_helper
INFO - 2018-04-13 18:53:00 --> Form Validation Class Initialized
INFO - 2018-04-13 18:53:00 --> Controller Class Initialized
INFO - 2018-04-13 18:53:00 --> Model Class Initialized
INFO - 2018-04-13 18:53:00 --> Helper loaded: inflector_helper
DEBUG - 2018-04-13 18:53:00 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 18:53:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 18:53:00 --> Model Class Initialized
INFO - 2018-04-13 18:53:00 --> Model Class Initialized
INFO - 2018-04-13 18:53:00 --> Model Class Initialized
INFO - 2018-04-13 18:53:00 --> Model Class Initialized
INFO - 2018-04-13 18:53:00 --> Model Class Initialized
INFO - 2018-04-13 18:53:00 --> Model Class Initialized
INFO - 2018-04-13 18:53:00 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-04-13 18:53:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-04-13 18:53:00 --> Final output sent to browser
DEBUG - 2018-04-13 18:53:00 --> Total execution time: 0.1092
INFO - 2018-04-13 13:23:00 --> Config Class Initialized
INFO - 2018-04-13 13:23:00 --> Hooks Class Initialized
DEBUG - 2018-04-13 13:23:00 --> UTF-8 Support Enabled
INFO - 2018-04-13 13:23:00 --> Utf8 Class Initialized
INFO - 2018-04-13 13:23:00 --> URI Class Initialized
INFO - 2018-04-13 13:23:00 --> Router Class Initialized
INFO - 2018-04-13 13:23:00 --> Output Class Initialized
INFO - 2018-04-13 13:23:00 --> Security Class Initialized
DEBUG - 2018-04-13 13:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 13:23:00 --> Input Class Initialized
INFO - 2018-04-13 13:23:00 --> Language Class Initialized
INFO - 2018-04-13 13:23:00 --> Language Class Initialized
INFO - 2018-04-13 13:23:00 --> Config Class Initialized
INFO - 2018-04-13 13:23:00 --> Loader Class Initialized
INFO - 2018-04-13 18:53:00 --> Helper loaded: url_helper
INFO - 2018-04-13 18:53:00 --> Helper loaded: notification_helper
INFO - 2018-04-13 18:53:00 --> Helper loaded: settings_helper
INFO - 2018-04-13 18:53:00 --> Helper loaded: permission_helper
INFO - 2018-04-13 18:53:00 --> Helper loaded: users_helper
INFO - 2018-04-13 18:53:00 --> Database Driver Class Initialized
DEBUG - 2018-04-13 18:53:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 18:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 18:53:00 --> Helper loaded: form_helper
INFO - 2018-04-13 18:53:00 --> Form Validation Class Initialized
INFO - 2018-04-13 18:53:00 --> Controller Class Initialized
INFO - 2018-04-13 18:53:00 --> Model Class Initialized
INFO - 2018-04-13 18:53:00 --> Helper loaded: inflector_helper
DEBUG - 2018-04-13 18:53:00 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-13 18:53:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-13 18:53:00 --> Model Class Initialized
INFO - 2018-04-13 18:53:00 --> Model Class Initialized
INFO - 2018-04-13 18:53:00 --> Model Class Initialized
INFO - 2018-04-13 18:53:00 --> Model Class Initialized
INFO - 2018-04-13 18:53:00 --> Model Class Initialized
INFO - 2018-04-13 18:53:00 --> Model Class Initialized
INFO - 2018-04-13 18:53:00 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-04-13 18:53:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-04-13 18:53:00 --> Final output sent to browser
DEBUG - 2018-04-13 18:53:00 --> Total execution time: 0.1081
