<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-03-06 17:52:53 --> Config Class Initialized
INFO - 2018-03-06 17:52:53 --> Hooks Class Initialized
INFO - 2018-03-06 17:52:53 --> Config Class Initialized
INFO - 2018-03-06 17:52:53 --> Hooks Class Initialized
DEBUG - 2018-03-06 17:52:53 --> UTF-8 Support Enabled
INFO - 2018-03-06 17:52:53 --> Utf8 Class Initialized
INFO - 2018-03-06 17:52:53 --> URI Class Initialized
DEBUG - 2018-03-06 17:52:53 --> UTF-8 Support Enabled
INFO - 2018-03-06 17:52:53 --> Utf8 Class Initialized
INFO - 2018-03-06 17:52:53 --> URI Class Initialized
INFO - 2018-03-06 17:52:53 --> Router Class Initialized
INFO - 2018-03-06 17:52:53 --> Router Class Initialized
INFO - 2018-03-06 17:52:53 --> Output Class Initialized
INFO - 2018-03-06 17:52:53 --> Output Class Initialized
INFO - 2018-03-06 17:52:53 --> Security Class Initialized
INFO - 2018-03-06 17:52:53 --> Security Class Initialized
DEBUG - 2018-03-06 17:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 17:52:53 --> Input Class Initialized
INFO - 2018-03-06 17:52:53 --> Language Class Initialized
DEBUG - 2018-03-06 17:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 17:52:53 --> Input Class Initialized
INFO - 2018-03-06 17:52:53 --> Language Class Initialized
INFO - 2018-03-06 17:52:53 --> Language Class Initialized
INFO - 2018-03-06 17:52:53 --> Config Class Initialized
INFO - 2018-03-06 17:52:53 --> Loader Class Initialized
INFO - 2018-03-06 23:22:53 --> Helper loaded: url_helper
INFO - 2018-03-06 17:52:53 --> Language Class Initialized
INFO - 2018-03-06 17:52:53 --> Config Class Initialized
INFO - 2018-03-06 17:52:53 --> Loader Class Initialized
INFO - 2018-03-06 23:22:53 --> Helper loaded: notification_helper
INFO - 2018-03-06 23:22:53 --> Helper loaded: settings_helper
INFO - 2018-03-06 23:22:53 --> Helper loaded: url_helper
INFO - 2018-03-06 23:22:53 --> Helper loaded: permission_helper
INFO - 2018-03-06 23:22:53 --> Helper loaded: users_helper
INFO - 2018-03-06 17:52:53 --> Config Class Initialized
INFO - 2018-03-06 17:52:53 --> Hooks Class Initialized
INFO - 2018-03-06 23:22:53 --> Helper loaded: notification_helper
INFO - 2018-03-06 23:22:53 --> Helper loaded: settings_helper
INFO - 2018-03-06 23:22:53 --> Helper loaded: permission_helper
INFO - 2018-03-06 23:22:53 --> Helper loaded: users_helper
DEBUG - 2018-03-06 17:52:53 --> UTF-8 Support Enabled
INFO - 2018-03-06 17:52:53 --> Utf8 Class Initialized
INFO - 2018-03-06 17:52:53 --> URI Class Initialized
INFO - 2018-03-06 23:22:53 --> Database Driver Class Initialized
INFO - 2018-03-06 17:52:53 --> Router Class Initialized
INFO - 2018-03-06 17:52:53 --> Output Class Initialized
INFO - 2018-03-06 17:52:53 --> Security Class Initialized
DEBUG - 2018-03-06 17:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 17:52:53 --> Input Class Initialized
INFO - 2018-03-06 17:52:53 --> Language Class Initialized
DEBUG - 2018-03-06 23:22:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 23:22:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 23:22:53 --> Helper loaded: form_helper
INFO - 2018-03-06 23:22:53 --> Form Validation Class Initialized
INFO - 2018-03-06 23:22:53 --> Controller Class Initialized
INFO - 2018-03-06 23:22:53 --> Model Class Initialized
INFO - 2018-03-06 23:22:53 --> Helper loaded: inflector_helper
DEBUG - 2018-03-06 23:22:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-06 23:22:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-06 23:22:53 --> Model Class Initialized
INFO - 2018-03-06 23:22:53 --> Model Class Initialized
INFO - 2018-03-06 23:22:53 --> Model Class Initialized
INFO - 2018-03-06 23:22:53 --> Model Class Initialized
INFO - 2018-03-06 23:22:53 --> Model Class Initialized
INFO - 2018-03-06 23:22:53 --> Model Class Initialized
INFO - 2018-03-06 23:22:53 --> Model Class Initialized
INFO - 2018-03-06 23:22:53 --> Model Class Initialized
INFO - 2018-03-06 23:22:53 --> Model Class Initialized
INFO - 2018-03-06 23:22:53 --> Model Class Initialized
INFO - 2018-03-06 23:22:53 --> Model Class Initialized
INFO - 2018-03-06 23:22:53 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-06 23:22:53 --> Model Class Initialized
INFO - 2018-03-06 23:22:53 --> Database Driver Class Initialized
DEBUG - 2018-03-06 23:22:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 23:22:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 23:22:53 --> Helper loaded: form_helper
INFO - 2018-03-06 23:22:53 --> Form Validation Class Initialized
INFO - 2018-03-06 23:22:53 --> Controller Class Initialized
INFO - 2018-03-06 23:22:53 --> Model Class Initialized
INFO - 2018-03-06 23:22:53 --> Helper loaded: inflector_helper
DEBUG - 2018-03-06 23:22:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-06 23:22:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-06 23:22:53 --> Model Class Initialized
INFO - 2018-03-06 23:22:53 --> Model Class Initialized
INFO - 2018-03-06 23:22:53 --> Model Class Initialized
INFO - 2018-03-06 23:22:53 --> Model Class Initialized
INFO - 2018-03-06 23:22:53 --> Model Class Initialized
INFO - 2018-03-06 23:22:53 --> Model Class Initialized
INFO - 2018-03-06 23:22:53 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-06 23:22:53 --> Model Class Initialized
INFO - 2018-03-06 23:22:53 --> Final output sent to browser
DEBUG - 2018-03-06 23:22:53 --> Total execution time: 0.3627
INFO - 2018-03-06 17:52:53 --> Language Class Initialized
INFO - 2018-03-06 17:52:53 --> Config Class Initialized
INFO - 2018-03-06 17:52:53 --> Loader Class Initialized
INFO - 2018-03-06 23:22:53 --> Helper loaded: url_helper
INFO - 2018-03-06 23:22:53 --> Helper loaded: notification_helper
INFO - 2018-03-06 23:22:53 --> Helper loaded: settings_helper
INFO - 2018-03-06 23:22:53 --> Final output sent to browser
DEBUG - 2018-03-06 23:22:53 --> Total execution time: 0.5056
INFO - 2018-03-06 23:22:53 --> Helper loaded: permission_helper
INFO - 2018-03-06 23:22:53 --> Helper loaded: users_helper
INFO - 2018-03-06 23:22:53 --> Database Driver Class Initialized
DEBUG - 2018-03-06 23:22:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 23:22:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 23:22:53 --> Helper loaded: form_helper
INFO - 2018-03-06 23:22:53 --> Form Validation Class Initialized
INFO - 2018-03-06 23:22:53 --> Controller Class Initialized
INFO - 2018-03-06 23:22:53 --> Model Class Initialized
INFO - 2018-03-06 23:22:53 --> Helper loaded: inflector_helper
DEBUG - 2018-03-06 23:22:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-06 23:22:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-06 23:22:53 --> Model Class Initialized
INFO - 2018-03-06 23:22:53 --> Model Class Initialized
INFO - 2018-03-06 23:22:53 --> Model Class Initialized
INFO - 2018-03-06 23:22:53 --> Model Class Initialized
INFO - 2018-03-06 23:22:53 --> Model Class Initialized
INFO - 2018-03-06 23:22:53 --> Model Class Initialized
INFO - 2018-03-06 23:22:53 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-06 23:22:53 --> Model Class Initialized
INFO - 2018-03-06 23:22:53 --> Final output sent to browser
DEBUG - 2018-03-06 23:22:53 --> Total execution time: 0.6650
INFO - 2018-03-06 17:52:55 --> Config Class Initialized
INFO - 2018-03-06 17:52:55 --> Hooks Class Initialized
DEBUG - 2018-03-06 17:52:55 --> UTF-8 Support Enabled
INFO - 2018-03-06 17:52:55 --> Utf8 Class Initialized
INFO - 2018-03-06 17:52:55 --> URI Class Initialized
INFO - 2018-03-06 17:52:55 --> Router Class Initialized
INFO - 2018-03-06 17:52:55 --> Output Class Initialized
INFO - 2018-03-06 17:52:55 --> Security Class Initialized
DEBUG - 2018-03-06 17:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 17:52:55 --> Input Class Initialized
INFO - 2018-03-06 17:52:55 --> Language Class Initialized
INFO - 2018-03-06 17:52:55 --> Language Class Initialized
INFO - 2018-03-06 17:52:55 --> Config Class Initialized
INFO - 2018-03-06 17:52:55 --> Loader Class Initialized
INFO - 2018-03-06 23:22:55 --> Helper loaded: url_helper
INFO - 2018-03-06 23:22:55 --> Helper loaded: notification_helper
INFO - 2018-03-06 23:22:55 --> Helper loaded: settings_helper
INFO - 2018-03-06 23:22:55 --> Helper loaded: permission_helper
INFO - 2018-03-06 23:22:55 --> Helper loaded: users_helper
INFO - 2018-03-06 23:22:55 --> Database Driver Class Initialized
DEBUG - 2018-03-06 23:22:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 23:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 23:22:55 --> Helper loaded: form_helper
INFO - 2018-03-06 23:22:55 --> Form Validation Class Initialized
INFO - 2018-03-06 23:22:55 --> Controller Class Initialized
INFO - 2018-03-06 23:22:55 --> Model Class Initialized
INFO - 2018-03-06 23:22:55 --> Helper loaded: inflector_helper
DEBUG - 2018-03-06 23:22:55 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-06 23:22:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-06 23:22:55 --> Model Class Initialized
INFO - 2018-03-06 23:22:55 --> Model Class Initialized
INFO - 2018-03-06 23:22:55 --> Model Class Initialized
INFO - 2018-03-06 23:22:55 --> Model Class Initialized
INFO - 2018-03-06 23:22:55 --> Model Class Initialized
INFO - 2018-03-06 23:22:55 --> Model Class Initialized
INFO - 2018-03-06 23:22:55 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-06 23:22:55 --> Final output sent to browser
DEBUG - 2018-03-06 23:22:55 --> Total execution time: 0.1107
INFO - 2018-03-06 17:52:55 --> Config Class Initialized
INFO - 2018-03-06 17:52:55 --> Hooks Class Initialized
DEBUG - 2018-03-06 17:52:55 --> UTF-8 Support Enabled
INFO - 2018-03-06 17:52:55 --> Utf8 Class Initialized
INFO - 2018-03-06 17:52:55 --> URI Class Initialized
INFO - 2018-03-06 17:52:55 --> Router Class Initialized
INFO - 2018-03-06 17:52:55 --> Output Class Initialized
INFO - 2018-03-06 17:52:55 --> Security Class Initialized
DEBUG - 2018-03-06 17:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 17:52:55 --> Input Class Initialized
INFO - 2018-03-06 17:52:55 --> Language Class Initialized
INFO - 2018-03-06 17:52:55 --> Language Class Initialized
INFO - 2018-03-06 17:52:55 --> Config Class Initialized
INFO - 2018-03-06 17:52:55 --> Loader Class Initialized
INFO - 2018-03-06 23:22:55 --> Helper loaded: url_helper
INFO - 2018-03-06 23:22:55 --> Helper loaded: notification_helper
INFO - 2018-03-06 23:22:55 --> Helper loaded: settings_helper
INFO - 2018-03-06 23:22:55 --> Helper loaded: permission_helper
INFO - 2018-03-06 23:22:55 --> Helper loaded: users_helper
INFO - 2018-03-06 23:22:55 --> Database Driver Class Initialized
DEBUG - 2018-03-06 23:22:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 23:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 23:22:55 --> Helper loaded: form_helper
INFO - 2018-03-06 23:22:55 --> Form Validation Class Initialized
INFO - 2018-03-06 23:22:55 --> Controller Class Initialized
INFO - 2018-03-06 23:22:55 --> Model Class Initialized
INFO - 2018-03-06 23:22:55 --> Helper loaded: inflector_helper
DEBUG - 2018-03-06 23:22:55 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-06 23:22:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-06 23:22:55 --> Model Class Initialized
INFO - 2018-03-06 23:22:55 --> Model Class Initialized
INFO - 2018-03-06 23:22:55 --> Model Class Initialized
INFO - 2018-03-06 23:22:55 --> Model Class Initialized
INFO - 2018-03-06 23:22:55 --> Model Class Initialized
INFO - 2018-03-06 23:22:55 --> Model Class Initialized
INFO - 2018-03-06 23:22:55 --> Model Class Initialized
INFO - 2018-03-06 23:22:55 --> Model Class Initialized
INFO - 2018-03-06 23:22:55 --> Model Class Initialized
INFO - 2018-03-06 23:22:55 --> Model Class Initialized
INFO - 2018-03-06 23:22:55 --> Model Class Initialized
INFO - 2018-03-06 23:22:55 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-06 23:22:55 --> Model Class Initialized
INFO - 2018-03-06 23:22:55 --> Final output sent to browser
DEBUG - 2018-03-06 23:22:55 --> Total execution time: 0.1430
INFO - 2018-03-06 17:52:58 --> Config Class Initialized
INFO - 2018-03-06 17:52:58 --> Hooks Class Initialized
DEBUG - 2018-03-06 17:52:58 --> UTF-8 Support Enabled
INFO - 2018-03-06 17:52:58 --> Utf8 Class Initialized
INFO - 2018-03-06 17:52:58 --> URI Class Initialized
INFO - 2018-03-06 17:52:58 --> Router Class Initialized
INFO - 2018-03-06 17:52:58 --> Output Class Initialized
INFO - 2018-03-06 17:52:58 --> Security Class Initialized
DEBUG - 2018-03-06 17:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 17:52:58 --> Input Class Initialized
INFO - 2018-03-06 17:52:58 --> Language Class Initialized
INFO - 2018-03-06 17:52:58 --> Language Class Initialized
INFO - 2018-03-06 17:52:58 --> Config Class Initialized
INFO - 2018-03-06 17:52:58 --> Loader Class Initialized
INFO - 2018-03-06 23:22:58 --> Helper loaded: url_helper
INFO - 2018-03-06 23:22:58 --> Helper loaded: notification_helper
INFO - 2018-03-06 23:22:58 --> Helper loaded: settings_helper
INFO - 2018-03-06 23:22:58 --> Helper loaded: permission_helper
INFO - 2018-03-06 23:22:58 --> Helper loaded: users_helper
INFO - 2018-03-06 23:22:58 --> Database Driver Class Initialized
DEBUG - 2018-03-06 23:22:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 23:22:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 23:22:58 --> Helper loaded: form_helper
INFO - 2018-03-06 23:22:58 --> Form Validation Class Initialized
INFO - 2018-03-06 23:22:58 --> Controller Class Initialized
INFO - 2018-03-06 23:22:58 --> Model Class Initialized
INFO - 2018-03-06 23:22:58 --> Helper loaded: inflector_helper
DEBUG - 2018-03-06 23:22:58 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-06 23:22:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-06 23:22:58 --> Model Class Initialized
INFO - 2018-03-06 23:22:58 --> Model Class Initialized
INFO - 2018-03-06 23:22:58 --> Model Class Initialized
INFO - 2018-03-06 23:22:58 --> Model Class Initialized
INFO - 2018-03-06 23:22:58 --> Model Class Initialized
INFO - 2018-03-06 23:22:58 --> Model Class Initialized
INFO - 2018-03-06 23:22:58 --> Model Class Initialized
INFO - 2018-03-06 23:22:58 --> Model Class Initialized
INFO - 2018-03-06 23:22:58 --> Model Class Initialized
INFO - 2018-03-06 23:22:58 --> Model Class Initialized
INFO - 2018-03-06 23:22:58 --> Model Class Initialized
INFO - 2018-03-06 23:22:58 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-06 23:22:58 --> Model Class Initialized
INFO - 2018-03-06 23:22:58 --> Final output sent to browser
DEBUG - 2018-03-06 23:22:58 --> Total execution time: 0.1520
INFO - 2018-03-06 17:52:58 --> Config Class Initialized
INFO - 2018-03-06 17:52:58 --> Hooks Class Initialized
DEBUG - 2018-03-06 17:52:58 --> UTF-8 Support Enabled
INFO - 2018-03-06 17:52:58 --> Utf8 Class Initialized
INFO - 2018-03-06 17:52:58 --> URI Class Initialized
INFO - 2018-03-06 17:52:58 --> Router Class Initialized
INFO - 2018-03-06 17:52:58 --> Output Class Initialized
INFO - 2018-03-06 17:52:58 --> Security Class Initialized
DEBUG - 2018-03-06 17:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 17:52:58 --> Input Class Initialized
INFO - 2018-03-06 17:52:58 --> Language Class Initialized
INFO - 2018-03-06 17:52:58 --> Language Class Initialized
INFO - 2018-03-06 17:52:58 --> Config Class Initialized
INFO - 2018-03-06 17:52:58 --> Loader Class Initialized
INFO - 2018-03-06 23:22:58 --> Helper loaded: url_helper
INFO - 2018-03-06 23:22:58 --> Helper loaded: notification_helper
INFO - 2018-03-06 23:22:58 --> Helper loaded: settings_helper
INFO - 2018-03-06 23:22:58 --> Helper loaded: permission_helper
INFO - 2018-03-06 23:22:58 --> Helper loaded: users_helper
INFO - 2018-03-06 23:22:58 --> Database Driver Class Initialized
DEBUG - 2018-03-06 23:22:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 23:22:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 23:22:58 --> Helper loaded: form_helper
INFO - 2018-03-06 23:22:58 --> Form Validation Class Initialized
INFO - 2018-03-06 23:22:58 --> Controller Class Initialized
INFO - 2018-03-06 23:22:58 --> Model Class Initialized
INFO - 2018-03-06 23:22:58 --> Helper loaded: inflector_helper
DEBUG - 2018-03-06 23:22:58 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-06 23:22:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-06 23:22:58 --> Model Class Initialized
INFO - 2018-03-06 23:22:58 --> Model Class Initialized
INFO - 2018-03-06 23:22:58 --> Model Class Initialized
INFO - 2018-03-06 23:22:58 --> Model Class Initialized
INFO - 2018-03-06 23:22:58 --> Model Class Initialized
INFO - 2018-03-06 23:22:58 --> Model Class Initialized
INFO - 2018-03-06 23:22:58 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-06 23:22:58 --> Model Class Initialized
INFO - 2018-03-06 23:22:58 --> Final output sent to browser
DEBUG - 2018-03-06 23:22:58 --> Total execution time: 0.0873
INFO - 2018-03-06 17:52:59 --> Config Class Initialized
INFO - 2018-03-06 17:52:59 --> Hooks Class Initialized
DEBUG - 2018-03-06 17:52:59 --> UTF-8 Support Enabled
INFO - 2018-03-06 17:52:59 --> Utf8 Class Initialized
INFO - 2018-03-06 17:52:59 --> URI Class Initialized
INFO - 2018-03-06 17:52:59 --> Router Class Initialized
INFO - 2018-03-06 17:52:59 --> Output Class Initialized
INFO - 2018-03-06 17:52:59 --> Security Class Initialized
DEBUG - 2018-03-06 17:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 17:52:59 --> Input Class Initialized
INFO - 2018-03-06 17:52:59 --> Language Class Initialized
INFO - 2018-03-06 17:53:00 --> Language Class Initialized
INFO - 2018-03-06 17:53:00 --> Config Class Initialized
INFO - 2018-03-06 17:53:00 --> Loader Class Initialized
INFO - 2018-03-06 23:23:00 --> Helper loaded: url_helper
INFO - 2018-03-06 23:23:00 --> Helper loaded: notification_helper
INFO - 2018-03-06 23:23:00 --> Helper loaded: settings_helper
INFO - 2018-03-06 23:23:00 --> Helper loaded: permission_helper
INFO - 2018-03-06 23:23:00 --> Helper loaded: users_helper
INFO - 2018-03-06 23:23:00 --> Database Driver Class Initialized
DEBUG - 2018-03-06 23:23:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 23:23:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 23:23:01 --> Helper loaded: form_helper
INFO - 2018-03-06 23:23:01 --> Form Validation Class Initialized
INFO - 2018-03-06 23:23:01 --> Controller Class Initialized
INFO - 2018-03-06 23:23:01 --> Model Class Initialized
INFO - 2018-03-06 23:23:01 --> Helper loaded: inflector_helper
DEBUG - 2018-03-06 23:23:01 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-06 23:23:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-06 23:23:01 --> Model Class Initialized
INFO - 2018-03-06 23:23:01 --> Model Class Initialized
INFO - 2018-03-06 23:23:01 --> Model Class Initialized
INFO - 2018-03-06 23:23:01 --> Model Class Initialized
INFO - 2018-03-06 23:23:01 --> Model Class Initialized
INFO - 2018-03-06 23:23:01 --> Model Class Initialized
INFO - 2018-03-06 23:23:01 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-06 23:23:01 --> Model Class Initialized
INFO - 2018-03-06 23:23:01 --> Final output sent to browser
DEBUG - 2018-03-06 23:23:01 --> Total execution time: 2.6241
INFO - 2018-03-06 17:53:02 --> Config Class Initialized
INFO - 2018-03-06 17:53:02 --> Hooks Class Initialized
DEBUG - 2018-03-06 17:53:02 --> UTF-8 Support Enabled
INFO - 2018-03-06 17:53:02 --> Utf8 Class Initialized
INFO - 2018-03-06 17:53:02 --> URI Class Initialized
INFO - 2018-03-06 17:53:02 --> Router Class Initialized
INFO - 2018-03-06 17:53:02 --> Output Class Initialized
INFO - 2018-03-06 17:53:02 --> Security Class Initialized
DEBUG - 2018-03-06 17:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 17:53:02 --> Input Class Initialized
INFO - 2018-03-06 17:53:02 --> Config Class Initialized
INFO - 2018-03-06 17:53:02 --> Hooks Class Initialized
INFO - 2018-03-06 17:53:02 --> Language Class Initialized
DEBUG - 2018-03-06 17:53:02 --> UTF-8 Support Enabled
INFO - 2018-03-06 17:53:02 --> Utf8 Class Initialized
INFO - 2018-03-06 17:53:02 --> URI Class Initialized
INFO - 2018-03-06 17:53:02 --> Router Class Initialized
INFO - 2018-03-06 17:53:02 --> Output Class Initialized
INFO - 2018-03-06 17:53:02 --> Security Class Initialized
DEBUG - 2018-03-06 17:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 17:53:02 --> Input Class Initialized
INFO - 2018-03-06 17:53:02 --> Language Class Initialized
INFO - 2018-03-06 17:53:02 --> Language Class Initialized
INFO - 2018-03-06 17:53:02 --> Config Class Initialized
INFO - 2018-03-06 17:53:02 --> Loader Class Initialized
INFO - 2018-03-06 23:23:02 --> Helper loaded: url_helper
INFO - 2018-03-06 23:23:02 --> Helper loaded: notification_helper
INFO - 2018-03-06 23:23:02 --> Helper loaded: settings_helper
INFO - 2018-03-06 23:23:02 --> Helper loaded: permission_helper
INFO - 2018-03-06 23:23:02 --> Helper loaded: users_helper
INFO - 2018-03-06 17:53:02 --> Language Class Initialized
INFO - 2018-03-06 17:53:02 --> Config Class Initialized
INFO - 2018-03-06 17:53:02 --> Loader Class Initialized
INFO - 2018-03-06 23:23:02 --> Helper loaded: url_helper
INFO - 2018-03-06 23:23:02 --> Helper loaded: notification_helper
INFO - 2018-03-06 23:23:02 --> Helper loaded: settings_helper
INFO - 2018-03-06 23:23:02 --> Helper loaded: permission_helper
INFO - 2018-03-06 23:23:02 --> Helper loaded: users_helper
INFO - 2018-03-06 23:23:02 --> Database Driver Class Initialized
DEBUG - 2018-03-06 23:23:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 23:23:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 23:23:03 --> Helper loaded: form_helper
INFO - 2018-03-06 23:23:03 --> Form Validation Class Initialized
INFO - 2018-03-06 23:23:03 --> Controller Class Initialized
INFO - 2018-03-06 23:23:03 --> Model Class Initialized
INFO - 2018-03-06 23:23:03 --> Helper loaded: inflector_helper
DEBUG - 2018-03-06 23:23:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-06 23:23:03 --> Database Driver Class Initialized
INFO - 2018-03-06 23:23:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-06 23:23:03 --> Model Class Initialized
INFO - 2018-03-06 23:23:03 --> Model Class Initialized
INFO - 2018-03-06 23:23:03 --> Model Class Initialized
INFO - 2018-03-06 23:23:03 --> Model Class Initialized
INFO - 2018-03-06 23:23:03 --> Model Class Initialized
DEBUG - 2018-03-06 23:23:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 23:23:03 --> Model Class Initialized
INFO - 2018-03-06 23:23:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 23:23:03 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-06 23:23:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-03-06 23:23:03 --> Final output sent to browser
DEBUG - 2018-03-06 23:23:03 --> Total execution time: 0.5238
INFO - 2018-03-06 23:23:03 --> Helper loaded: form_helper
INFO - 2018-03-06 23:23:03 --> Form Validation Class Initialized
INFO - 2018-03-06 23:23:03 --> Controller Class Initialized
INFO - 2018-03-06 23:23:03 --> Model Class Initialized
INFO - 2018-03-06 23:23:03 --> Helper loaded: inflector_helper
DEBUG - 2018-03-06 23:23:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-06 23:23:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-06 23:23:03 --> Model Class Initialized
INFO - 2018-03-06 23:23:03 --> Model Class Initialized
INFO - 2018-03-06 23:23:03 --> Model Class Initialized
INFO - 2018-03-06 23:23:03 --> Model Class Initialized
INFO - 2018-03-06 23:23:03 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-06 23:23:03 --> Final output sent to browser
DEBUG - 2018-03-06 23:23:03 --> Total execution time: 0.5099
INFO - 2018-03-06 17:53:03 --> Config Class Initialized
INFO - 2018-03-06 17:53:03 --> Hooks Class Initialized
DEBUG - 2018-03-06 17:53:03 --> UTF-8 Support Enabled
INFO - 2018-03-06 17:53:03 --> Utf8 Class Initialized
INFO - 2018-03-06 17:53:03 --> URI Class Initialized
INFO - 2018-03-06 17:53:04 --> Router Class Initialized
INFO - 2018-03-06 17:53:04 --> Output Class Initialized
INFO - 2018-03-06 17:53:04 --> Security Class Initialized
DEBUG - 2018-03-06 17:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 17:53:04 --> Input Class Initialized
INFO - 2018-03-06 17:53:04 --> Language Class Initialized
INFO - 2018-03-06 17:53:05 --> Language Class Initialized
INFO - 2018-03-06 17:53:05 --> Config Class Initialized
INFO - 2018-03-06 17:53:05 --> Loader Class Initialized
INFO - 2018-03-06 23:23:05 --> Helper loaded: url_helper
INFO - 2018-03-06 23:23:05 --> Helper loaded: notification_helper
INFO - 2018-03-06 23:23:05 --> Helper loaded: settings_helper
INFO - 2018-03-06 23:23:05 --> Helper loaded: permission_helper
INFO - 2018-03-06 23:23:05 --> Helper loaded: users_helper
INFO - 2018-03-06 17:53:06 --> Config Class Initialized
INFO - 2018-03-06 17:53:06 --> Hooks Class Initialized
INFO - 2018-03-06 23:23:06 --> Database Driver Class Initialized
DEBUG - 2018-03-06 17:53:06 --> UTF-8 Support Enabled
INFO - 2018-03-06 17:53:06 --> Utf8 Class Initialized
INFO - 2018-03-06 17:53:06 --> URI Class Initialized
DEBUG - 2018-03-06 23:23:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 23:23:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 17:53:06 --> Router Class Initialized
INFO - 2018-03-06 17:53:06 --> Output Class Initialized
INFO - 2018-03-06 23:23:06 --> Helper loaded: form_helper
INFO - 2018-03-06 23:23:06 --> Form Validation Class Initialized
INFO - 2018-03-06 23:23:06 --> Controller Class Initialized
INFO - 2018-03-06 17:53:06 --> Security Class Initialized
DEBUG - 2018-03-06 17:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 17:53:06 --> Input Class Initialized
INFO - 2018-03-06 17:53:06 --> Language Class Initialized
INFO - 2018-03-06 23:23:07 --> Model Class Initialized
INFO - 2018-03-06 23:23:07 --> Helper loaded: inflector_helper
DEBUG - 2018-03-06 23:23:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-06 23:23:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-06 17:53:07 --> Config Class Initialized
INFO - 2018-03-06 17:53:07 --> Hooks Class Initialized
DEBUG - 2018-03-06 17:53:07 --> UTF-8 Support Enabled
INFO - 2018-03-06 17:53:07 --> Utf8 Class Initialized
INFO - 2018-03-06 17:53:07 --> URI Class Initialized
INFO - 2018-03-06 17:53:07 --> Router Class Initialized
INFO - 2018-03-06 17:53:07 --> Output Class Initialized
INFO - 2018-03-06 17:53:07 --> Security Class Initialized
DEBUG - 2018-03-06 17:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 17:53:07 --> Input Class Initialized
INFO - 2018-03-06 17:53:07 --> Language Class Initialized
INFO - 2018-03-06 17:53:07 --> Language Class Initialized
INFO - 2018-03-06 17:53:07 --> Config Class Initialized
INFO - 2018-03-06 17:53:07 --> Loader Class Initialized
INFO - 2018-03-06 23:23:07 --> Helper loaded: url_helper
INFO - 2018-03-06 23:23:07 --> Helper loaded: notification_helper
INFO - 2018-03-06 23:23:07 --> Helper loaded: settings_helper
INFO - 2018-03-06 23:23:07 --> Helper loaded: permission_helper
INFO - 2018-03-06 23:23:07 --> Helper loaded: users_helper
INFO - 2018-03-06 23:23:07 --> Model Class Initialized
INFO - 2018-03-06 23:23:07 --> Model Class Initialized
INFO - 2018-03-06 23:23:07 --> Database Driver Class Initialized
DEBUG - 2018-03-06 23:23:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 23:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 23:23:07 --> Helper loaded: form_helper
INFO - 2018-03-06 23:23:07 --> Form Validation Class Initialized
INFO - 2018-03-06 23:23:07 --> Controller Class Initialized
INFO - 2018-03-06 23:23:07 --> Model Class Initialized
INFO - 2018-03-06 23:23:07 --> Helper loaded: inflector_helper
DEBUG - 2018-03-06 23:23:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-06 23:23:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-06 23:23:07 --> Model Class Initialized
INFO - 2018-03-06 23:23:07 --> Model Class Initialized
INFO - 2018-03-06 23:23:07 --> Model Class Initialized
INFO - 2018-03-06 23:23:07 --> Model Class Initialized
INFO - 2018-03-06 23:23:07 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-06 23:23:07 --> Final output sent to browser
DEBUG - 2018-03-06 23:23:07 --> Total execution time: 0.0965
INFO - 2018-03-06 23:23:07 --> Model Class Initialized
INFO - 2018-03-06 23:23:07 --> Model Class Initialized
INFO - 2018-03-06 23:23:07 --> Model Class Initialized
INFO - 2018-03-06 23:23:07 --> Model Class Initialized
INFO - 2018-03-06 23:23:07 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-06 23:23:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-03-06 23:23:07 --> Final output sent to browser
DEBUG - 2018-03-06 23:23:07 --> Total execution time: 4.0935
INFO - 2018-03-06 17:53:07 --> Language Class Initialized
INFO - 2018-03-06 17:53:07 --> Config Class Initialized
INFO - 2018-03-06 17:53:07 --> Loader Class Initialized
INFO - 2018-03-06 17:53:07 --> Config Class Initialized
INFO - 2018-03-06 17:53:07 --> Hooks Class Initialized
DEBUG - 2018-03-06 17:53:07 --> UTF-8 Support Enabled
INFO - 2018-03-06 17:53:07 --> Utf8 Class Initialized
INFO - 2018-03-06 17:53:07 --> URI Class Initialized
INFO - 2018-03-06 17:53:07 --> Router Class Initialized
INFO - 2018-03-06 17:53:07 --> Output Class Initialized
INFO - 2018-03-06 17:53:07 --> Security Class Initialized
DEBUG - 2018-03-06 17:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-06 17:53:07 --> Input Class Initialized
INFO - 2018-03-06 17:53:07 --> Language Class Initialized
INFO - 2018-03-06 17:53:07 --> Language Class Initialized
INFO - 2018-03-06 17:53:07 --> Config Class Initialized
INFO - 2018-03-06 17:53:07 --> Loader Class Initialized
INFO - 2018-03-06 23:23:07 --> Helper loaded: url_helper
INFO - 2018-03-06 23:23:07 --> Helper loaded: notification_helper
INFO - 2018-03-06 23:23:07 --> Helper loaded: settings_helper
INFO - 2018-03-06 23:23:07 --> Helper loaded: permission_helper
INFO - 2018-03-06 23:23:07 --> Helper loaded: users_helper
INFO - 2018-03-06 23:23:07 --> Database Driver Class Initialized
INFO - 2018-03-06 23:23:07 --> Helper loaded: url_helper
DEBUG - 2018-03-06 23:23:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 23:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 23:23:07 --> Helper loaded: form_helper
INFO - 2018-03-06 23:23:07 --> Form Validation Class Initialized
INFO - 2018-03-06 23:23:07 --> Controller Class Initialized
INFO - 2018-03-06 23:23:07 --> Model Class Initialized
INFO - 2018-03-06 23:23:07 --> Helper loaded: inflector_helper
DEBUG - 2018-03-06 23:23:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-06 23:23:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-06 23:23:07 --> Model Class Initialized
INFO - 2018-03-06 23:23:07 --> Model Class Initialized
INFO - 2018-03-06 23:23:07 --> Model Class Initialized
INFO - 2018-03-06 23:23:07 --> Model Class Initialized
INFO - 2018-03-06 23:23:07 --> Model Class Initialized
INFO - 2018-03-06 23:23:07 --> Model Class Initialized
INFO - 2018-03-06 23:23:07 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-06 23:23:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-03-06 23:23:07 --> Final output sent to browser
DEBUG - 2018-03-06 23:23:07 --> Total execution time: 0.0985
INFO - 2018-03-06 23:23:07 --> Helper loaded: notification_helper
INFO - 2018-03-06 23:23:07 --> Helper loaded: settings_helper
INFO - 2018-03-06 23:23:07 --> Helper loaded: permission_helper
INFO - 2018-03-06 23:23:07 --> Helper loaded: users_helper
INFO - 2018-03-06 23:23:08 --> Database Driver Class Initialized
DEBUG - 2018-03-06 23:23:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-06 23:23:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-06 23:23:08 --> Helper loaded: form_helper
INFO - 2018-03-06 23:23:08 --> Form Validation Class Initialized
INFO - 2018-03-06 23:23:08 --> Controller Class Initialized
INFO - 2018-03-06 23:23:08 --> Model Class Initialized
INFO - 2018-03-06 23:23:08 --> Helper loaded: inflector_helper
DEBUG - 2018-03-06 23:23:08 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-06 23:23:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-06 23:23:08 --> Model Class Initialized
INFO - 2018-03-06 23:23:08 --> Model Class Initialized
INFO - 2018-03-06 23:23:08 --> Model Class Initialized
INFO - 2018-03-06 23:23:08 --> Model Class Initialized
INFO - 2018-03-06 23:23:08 --> Model Class Initialized
INFO - 2018-03-06 23:23:08 --> Model Class Initialized
INFO - 2018-03-06 23:23:08 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-06 23:23:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-03-06 23:23:08 --> Final output sent to browser
DEBUG - 2018-03-06 23:23:08 --> Total execution time: 2.2976
