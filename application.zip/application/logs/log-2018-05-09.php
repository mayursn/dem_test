<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-05-09 05:43:01 --> Config Class Initialized
INFO - 2018-05-09 05:43:01 --> Hooks Class Initialized
DEBUG - 2018-05-09 05:43:01 --> UTF-8 Support Enabled
INFO - 2018-05-09 05:43:01 --> Utf8 Class Initialized
INFO - 2018-05-09 05:43:01 --> URI Class Initialized
INFO - 2018-05-09 05:43:01 --> Router Class Initialized
INFO - 2018-05-09 05:43:01 --> Config Class Initialized
INFO - 2018-05-09 05:43:01 --> Hooks Class Initialized
INFO - 2018-05-09 05:43:01 --> Output Class Initialized
DEBUG - 2018-05-09 05:43:01 --> UTF-8 Support Enabled
INFO - 2018-05-09 05:43:01 --> Utf8 Class Initialized
INFO - 2018-05-09 05:43:01 --> Security Class Initialized
INFO - 2018-05-09 05:43:01 --> URI Class Initialized
INFO - 2018-05-09 05:43:01 --> Config Class Initialized
INFO - 2018-05-09 05:43:01 --> Hooks Class Initialized
DEBUG - 2018-05-09 05:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 05:43:01 --> Input Class Initialized
INFO - 2018-05-09 05:43:01 --> Router Class Initialized
INFO - 2018-05-09 05:43:01 --> Language Class Initialized
DEBUG - 2018-05-09 05:43:01 --> UTF-8 Support Enabled
INFO - 2018-05-09 05:43:01 --> Utf8 Class Initialized
INFO - 2018-05-09 05:43:01 --> Output Class Initialized
INFO - 2018-05-09 05:43:01 --> URI Class Initialized
INFO - 2018-05-09 05:43:01 --> Security Class Initialized
DEBUG - 2018-05-09 05:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 05:43:01 --> Input Class Initialized
INFO - 2018-05-09 05:43:01 --> Language Class Initialized
INFO - 2018-05-09 05:43:01 --> Router Class Initialized
INFO - 2018-05-09 05:43:01 --> Output Class Initialized
INFO - 2018-05-09 05:43:01 --> Security Class Initialized
INFO - 2018-05-09 05:43:01 --> Language Class Initialized
INFO - 2018-05-09 05:43:01 --> Config Class Initialized
INFO - 2018-05-09 05:43:01 --> Loader Class Initialized
INFO - 2018-05-09 11:13:01 --> Helper loaded: url_helper
INFO - 2018-05-09 11:13:01 --> Helper loaded: notification_helper
INFO - 2018-05-09 11:13:01 --> Helper loaded: settings_helper
INFO - 2018-05-09 11:13:01 --> Helper loaded: permission_helper
DEBUG - 2018-05-09 05:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 05:43:01 --> Input Class Initialized
INFO - 2018-05-09 11:13:01 --> Helper loaded: users_helper
INFO - 2018-05-09 05:43:01 --> Language Class Initialized
INFO - 2018-05-09 05:43:01 --> Config Class Initialized
INFO - 2018-05-09 05:43:01 --> Loader Class Initialized
INFO - 2018-05-09 05:43:01 --> Language Class Initialized
INFO - 2018-05-09 11:13:01 --> Helper loaded: url_helper
INFO - 2018-05-09 11:13:01 --> Helper loaded: notification_helper
INFO - 2018-05-09 11:13:01 --> Helper loaded: settings_helper
INFO - 2018-05-09 11:13:01 --> Helper loaded: permission_helper
INFO - 2018-05-09 11:13:01 --> Helper loaded: users_helper
INFO - 2018-05-09 05:43:01 --> Config Class Initialized
INFO - 2018-05-09 05:43:01 --> Hooks Class Initialized
INFO - 2018-05-09 11:13:01 --> Database Driver Class Initialized
INFO - 2018-05-09 11:13:01 --> Database Driver Class Initialized
DEBUG - 2018-05-09 11:13:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-05-09 05:43:01 --> UTF-8 Support Enabled
INFO - 2018-05-09 05:43:01 --> Utf8 Class Initialized
INFO - 2018-05-09 11:13:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-05-09 11:13:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 11:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 05:43:01 --> URI Class Initialized
INFO - 2018-05-09 05:43:01 --> Language Class Initialized
INFO - 2018-05-09 05:43:01 --> Config Class Initialized
INFO - 2018-05-09 05:43:01 --> Loader Class Initialized
INFO - 2018-05-09 11:13:01 --> Helper loaded: form_helper
INFO - 2018-05-09 11:13:01 --> Form Validation Class Initialized
INFO - 2018-05-09 11:13:01 --> Controller Class Initialized
INFO - 2018-05-09 11:13:01 --> Helper loaded: url_helper
INFO - 2018-05-09 11:13:01 --> Helper loaded: notification_helper
INFO - 2018-05-09 11:13:01 --> Helper loaded: settings_helper
INFO - 2018-05-09 11:13:01 --> Helper loaded: form_helper
INFO - 2018-05-09 11:13:01 --> Form Validation Class Initialized
INFO - 2018-05-09 11:13:01 --> Controller Class Initialized
INFO - 2018-05-09 11:13:01 --> Helper loaded: permission_helper
INFO - 2018-05-09 11:13:01 --> Helper loaded: users_helper
INFO - 2018-05-09 05:43:01 --> Router Class Initialized
INFO - 2018-05-09 11:13:01 --> Model Class Initialized
INFO - 2018-05-09 11:13:01 --> Helper loaded: inflector_helper
INFO - 2018-05-09 11:13:01 --> Model Class Initialized
INFO - 2018-05-09 11:13:01 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 11:13:01 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-05-09 11:13:01 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 11:13:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 11:13:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 11:13:01 --> Model Class Initialized
INFO - 2018-05-09 11:13:01 --> Model Class Initialized
INFO - 2018-05-09 11:13:01 --> Model Class Initialized
INFO - 2018-05-09 11:13:01 --> Model Class Initialized
INFO - 2018-05-09 11:13:01 --> Model Class Initialized
INFO - 2018-05-09 11:13:01 --> Model Class Initialized
INFO - 2018-05-09 11:13:01 --> Model Class Initialized
INFO - 2018-05-09 11:13:01 --> Model Class Initialized
INFO - 2018-05-09 11:13:01 --> Model Class Initialized
INFO - 2018-05-09 11:13:01 --> Model Class Initialized
INFO - 2018-05-09 11:13:01 --> Model Class Initialized
INFO - 2018-05-09 05:43:01 --> Output Class Initialized
INFO - 2018-05-09 11:13:01 --> Model Class Initialized
INFO - 2018-05-09 11:13:01 --> Model Class Initialized
INFO - 2018-05-09 11:13:01 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 11:13:01 --> Model Class Initialized
INFO - 2018-05-09 11:13:01 --> Model Class Initialized
INFO - 2018-05-09 11:13:01 --> Model Class Initialized
INFO - 2018-05-09 11:13:01 --> Model Class Initialized
INFO - 2018-05-09 11:13:01 --> Model Class Initialized
INFO - 2018-05-09 11:13:01 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 11:13:01 --> Model Class Initialized
INFO - 2018-05-09 11:13:01 --> Final output sent to browser
DEBUG - 2018-05-09 11:13:01 --> Total execution time: 0.1130
INFO - 2018-05-09 11:13:01 --> Database Driver Class Initialized
INFO - 2018-05-09 05:43:01 --> Security Class Initialized
INFO - 2018-05-09 05:43:01 --> Config Class Initialized
INFO - 2018-05-09 05:43:01 --> Hooks Class Initialized
DEBUG - 2018-05-09 11:13:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 11:13:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-05-09 05:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 05:43:01 --> Input Class Initialized
DEBUG - 2018-05-09 05:43:01 --> UTF-8 Support Enabled
INFO - 2018-05-09 05:43:01 --> Utf8 Class Initialized
INFO - 2018-05-09 05:43:01 --> Language Class Initialized
INFO - 2018-05-09 11:13:01 --> Final output sent to browser
DEBUG - 2018-05-09 11:13:01 --> Total execution time: 0.1211
INFO - 2018-05-09 05:43:01 --> URI Class Initialized
INFO - 2018-05-09 11:13:01 --> Helper loaded: form_helper
INFO - 2018-05-09 11:13:01 --> Form Validation Class Initialized
INFO - 2018-05-09 11:13:01 --> Controller Class Initialized
INFO - 2018-05-09 05:43:01 --> Router Class Initialized
INFO - 2018-05-09 11:13:01 --> Model Class Initialized
INFO - 2018-05-09 11:13:01 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 11:13:01 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 05:43:01 --> Output Class Initialized
INFO - 2018-05-09 11:13:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 11:13:01 --> Model Class Initialized
INFO - 2018-05-09 05:43:01 --> Security Class Initialized
INFO - 2018-05-09 11:13:01 --> Model Class Initialized
INFO - 2018-05-09 11:13:01 --> Model Class Initialized
INFO - 2018-05-09 11:13:01 --> Model Class Initialized
INFO - 2018-05-09 11:13:01 --> Model Class Initialized
INFO - 2018-05-09 11:13:01 --> Model Class Initialized
INFO - 2018-05-09 11:13:01 --> Model Class Initialized
INFO - 2018-05-09 11:13:01 --> Model Class Initialized
INFO - 2018-05-09 11:13:01 --> Model Class Initialized
DEBUG - 2018-05-09 05:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 05:43:01 --> Input Class Initialized
INFO - 2018-05-09 11:13:01 --> Model Class Initialized
INFO - 2018-05-09 05:43:01 --> Language Class Initialized
INFO - 2018-05-09 11:13:01 --> Model Class Initialized
INFO - 2018-05-09 11:13:01 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 11:13:01 --> Model Class Initialized
INFO - 2018-05-09 05:43:01 --> Language Class Initialized
INFO - 2018-05-09 05:43:01 --> Config Class Initialized
INFO - 2018-05-09 05:43:01 --> Loader Class Initialized
INFO - 2018-05-09 11:13:01 --> Helper loaded: url_helper
INFO - 2018-05-09 11:13:01 --> Helper loaded: notification_helper
INFO - 2018-05-09 11:13:01 --> Helper loaded: settings_helper
INFO - 2018-05-09 11:13:01 --> Helper loaded: permission_helper
INFO - 2018-05-09 11:13:01 --> Helper loaded: users_helper
INFO - 2018-05-09 11:13:01 --> Database Driver Class Initialized
INFO - 2018-05-09 05:43:01 --> Language Class Initialized
INFO - 2018-05-09 05:43:01 --> Config Class Initialized
INFO - 2018-05-09 05:43:01 --> Loader Class Initialized
INFO - 2018-05-09 11:13:01 --> Helper loaded: url_helper
INFO - 2018-05-09 11:13:01 --> Helper loaded: notification_helper
INFO - 2018-05-09 11:13:01 --> Helper loaded: settings_helper
DEBUG - 2018-05-09 11:13:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 11:13:01 --> Helper loaded: permission_helper
INFO - 2018-05-09 11:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 11:13:01 --> Helper loaded: users_helper
INFO - 2018-05-09 11:13:01 --> Helper loaded: form_helper
INFO - 2018-05-09 11:13:01 --> Form Validation Class Initialized
INFO - 2018-05-09 11:13:01 --> Controller Class Initialized
INFO - 2018-05-09 11:13:01 --> Final output sent to browser
DEBUG - 2018-05-09 11:13:01 --> Total execution time: 0.2109
INFO - 2018-05-09 11:13:01 --> Database Driver Class Initialized
INFO - 2018-05-09 11:13:01 --> Model Class Initialized
INFO - 2018-05-09 11:13:01 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 11:13:01 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 11:13:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 11:13:01 --> Model Class Initialized
INFO - 2018-05-09 11:13:01 --> Model Class Initialized
INFO - 2018-05-09 11:13:01 --> Model Class Initialized
INFO - 2018-05-09 11:13:01 --> Model Class Initialized
INFO - 2018-05-09 11:13:01 --> Model Class Initialized
INFO - 2018-05-09 11:13:01 --> Model Class Initialized
INFO - 2018-05-09 11:13:01 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-05-09 11:13:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 11:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 11:13:01 --> Final output sent to browser
DEBUG - 2018-05-09 11:13:01 --> Total execution time: 0.2029
INFO - 2018-05-09 11:13:01 --> Helper loaded: form_helper
INFO - 2018-05-09 11:13:01 --> Form Validation Class Initialized
INFO - 2018-05-09 11:13:01 --> Controller Class Initialized
INFO - 2018-05-09 11:13:01 --> Model Class Initialized
INFO - 2018-05-09 11:13:01 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 11:13:01 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 11:13:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 11:13:01 --> Model Class Initialized
INFO - 2018-05-09 11:13:01 --> Model Class Initialized
INFO - 2018-05-09 11:13:01 --> Model Class Initialized
INFO - 2018-05-09 11:13:01 --> Model Class Initialized
INFO - 2018-05-09 11:13:01 --> Model Class Initialized
INFO - 2018-05-09 11:13:01 --> Model Class Initialized
INFO - 2018-05-09 11:13:01 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 11:13:01 --> Model Class Initialized
INFO - 2018-05-09 11:13:01 --> Final output sent to browser
DEBUG - 2018-05-09 11:13:01 --> Total execution time: 0.1827
INFO - 2018-05-09 05:43:12 --> Config Class Initialized
INFO - 2018-05-09 05:43:12 --> Hooks Class Initialized
INFO - 2018-05-09 05:43:12 --> Config Class Initialized
INFO - 2018-05-09 05:43:12 --> Hooks Class Initialized
INFO - 2018-05-09 05:43:12 --> Config Class Initialized
INFO - 2018-05-09 05:43:12 --> Hooks Class Initialized
DEBUG - 2018-05-09 05:43:12 --> UTF-8 Support Enabled
INFO - 2018-05-09 05:43:12 --> Utf8 Class Initialized
INFO - 2018-05-09 05:43:12 --> Config Class Initialized
INFO - 2018-05-09 05:43:12 --> Hooks Class Initialized
DEBUG - 2018-05-09 05:43:12 --> UTF-8 Support Enabled
INFO - 2018-05-09 05:43:12 --> Utf8 Class Initialized
DEBUG - 2018-05-09 05:43:12 --> UTF-8 Support Enabled
INFO - 2018-05-09 05:43:12 --> Utf8 Class Initialized
INFO - 2018-05-09 05:43:12 --> URI Class Initialized
INFO - 2018-05-09 05:43:12 --> URI Class Initialized
INFO - 2018-05-09 05:43:12 --> URI Class Initialized
DEBUG - 2018-05-09 05:43:12 --> UTF-8 Support Enabled
INFO - 2018-05-09 05:43:12 --> Utf8 Class Initialized
INFO - 2018-05-09 05:43:12 --> Router Class Initialized
INFO - 2018-05-09 05:43:12 --> Router Class Initialized
INFO - 2018-05-09 05:43:12 --> URI Class Initialized
INFO - 2018-05-09 05:43:12 --> Router Class Initialized
INFO - 2018-05-09 05:43:12 --> Config Class Initialized
INFO - 2018-05-09 05:43:12 --> Hooks Class Initialized
INFO - 2018-05-09 05:43:12 --> Output Class Initialized
INFO - 2018-05-09 05:43:12 --> Output Class Initialized
INFO - 2018-05-09 05:43:12 --> Security Class Initialized
INFO - 2018-05-09 05:43:12 --> Output Class Initialized
INFO - 2018-05-09 05:43:12 --> Security Class Initialized
INFO - 2018-05-09 05:43:12 --> Router Class Initialized
DEBUG - 2018-05-09 05:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 05:43:12 --> Input Class Initialized
DEBUG - 2018-05-09 05:43:12 --> UTF-8 Support Enabled
INFO - 2018-05-09 05:43:12 --> Utf8 Class Initialized
INFO - 2018-05-09 05:43:12 --> Output Class Initialized
INFO - 2018-05-09 05:43:12 --> Language Class Initialized
INFO - 2018-05-09 05:43:12 --> Security Class Initialized
DEBUG - 2018-05-09 05:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 05:43:12 --> URI Class Initialized
INFO - 2018-05-09 05:43:12 --> Input Class Initialized
INFO - 2018-05-09 05:43:12 --> Security Class Initialized
DEBUG - 2018-05-09 05:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 05:43:12 --> Input Class Initialized
INFO - 2018-05-09 05:43:12 --> Language Class Initialized
INFO - 2018-05-09 05:43:12 --> Language Class Initialized
DEBUG - 2018-05-09 05:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 05:43:12 --> Input Class Initialized
INFO - 2018-05-09 05:43:12 --> Language Class Initialized
INFO - 2018-05-09 05:43:12 --> Router Class Initialized
INFO - 2018-05-09 05:43:12 --> Output Class Initialized
INFO - 2018-05-09 05:43:12 --> Security Class Initialized
DEBUG - 2018-05-09 05:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 05:43:12 --> Input Class Initialized
INFO - 2018-05-09 05:43:12 --> Language Class Initialized
INFO - 2018-05-09 05:43:12 --> Config Class Initialized
INFO - 2018-05-09 05:43:12 --> Loader Class Initialized
INFO - 2018-05-09 05:43:12 --> Language Class Initialized
INFO - 2018-05-09 05:43:12 --> Language Class Initialized
INFO - 2018-05-09 05:43:12 --> Config Class Initialized
INFO - 2018-05-09 05:43:12 --> Loader Class Initialized
INFO - 2018-05-09 11:13:12 --> Helper loaded: url_helper
INFO - 2018-05-09 11:13:12 --> Helper loaded: notification_helper
INFO - 2018-05-09 11:13:12 --> Helper loaded: settings_helper
INFO - 2018-05-09 11:13:12 --> Helper loaded: url_helper
INFO - 2018-05-09 11:13:12 --> Helper loaded: permission_helper
INFO - 2018-05-09 11:13:12 --> Helper loaded: users_helper
INFO - 2018-05-09 11:13:12 --> Helper loaded: notification_helper
INFO - 2018-05-09 11:13:12 --> Helper loaded: settings_helper
INFO - 2018-05-09 11:13:12 --> Helper loaded: permission_helper
INFO - 2018-05-09 11:13:12 --> Helper loaded: users_helper
INFO - 2018-05-09 05:43:12 --> Language Class Initialized
INFO - 2018-05-09 05:43:12 --> Config Class Initialized
INFO - 2018-05-09 05:43:12 --> Loader Class Initialized
INFO - 2018-05-09 11:13:12 --> Helper loaded: url_helper
INFO - 2018-05-09 11:13:12 --> Helper loaded: notification_helper
INFO - 2018-05-09 11:13:12 --> Helper loaded: settings_helper
INFO - 2018-05-09 11:13:12 --> Helper loaded: permission_helper
INFO - 2018-05-09 11:13:12 --> Helper loaded: users_helper
INFO - 2018-05-09 11:13:12 --> Database Driver Class Initialized
DEBUG - 2018-05-09 11:13:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 11:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 05:43:12 --> Language Class Initialized
INFO - 2018-05-09 05:43:12 --> Config Class Initialized
INFO - 2018-05-09 05:43:12 --> Loader Class Initialized
INFO - 2018-05-09 11:13:12 --> Database Driver Class Initialized
INFO - 2018-05-09 11:13:12 --> Helper loaded: url_helper
INFO - 2018-05-09 11:13:12 --> Helper loaded: form_helper
INFO - 2018-05-09 11:13:12 --> Form Validation Class Initialized
INFO - 2018-05-09 11:13:12 --> Controller Class Initialized
INFO - 2018-05-09 11:13:12 --> Helper loaded: notification_helper
DEBUG - 2018-05-09 11:13:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 11:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 11:13:12 --> Helper loaded: settings_helper
INFO - 2018-05-09 11:13:12 --> Database Driver Class Initialized
INFO - 2018-05-09 11:13:12 --> Helper loaded: permission_helper
INFO - 2018-05-09 11:13:12 --> Helper loaded: users_helper
INFO - 2018-05-09 11:13:12 --> Model Class Initialized
INFO - 2018-05-09 11:13:12 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 11:13:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-05-09 11:13:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 11:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 05:43:12 --> Language Class Initialized
INFO - 2018-05-09 05:43:12 --> Config Class Initialized
INFO - 2018-05-09 05:43:12 --> Loader Class Initialized
INFO - 2018-05-09 11:13:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 11:13:12 --> Model Class Initialized
INFO - 2018-05-09 11:13:12 --> Model Class Initialized
INFO - 2018-05-09 11:13:12 --> Model Class Initialized
INFO - 2018-05-09 11:13:12 --> Model Class Initialized
INFO - 2018-05-09 11:13:12 --> Model Class Initialized
INFO - 2018-05-09 11:13:12 --> Model Class Initialized
INFO - 2018-05-09 11:13:12 --> Model Class Initialized
INFO - 2018-05-09 11:13:12 --> Helper loaded: form_helper
INFO - 2018-05-09 11:13:12 --> Form Validation Class Initialized
INFO - 2018-05-09 11:13:12 --> Controller Class Initialized
INFO - 2018-05-09 11:13:12 --> Model Class Initialized
INFO - 2018-05-09 11:13:12 --> Model Class Initialized
INFO - 2018-05-09 11:13:12 --> Model Class Initialized
INFO - 2018-05-09 11:13:12 --> Helper loaded: url_helper
INFO - 2018-05-09 11:13:12 --> Model Class Initialized
INFO - 2018-05-09 11:13:12 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 11:13:12 --> Model Class Initialized
INFO - 2018-05-09 11:13:12 --> Helper loaded: notification_helper
INFO - 2018-05-09 11:13:12 --> Helper loaded: settings_helper
INFO - 2018-05-09 11:13:12 --> Helper loaded: form_helper
INFO - 2018-05-09 11:13:12 --> Form Validation Class Initialized
INFO - 2018-05-09 11:13:12 --> Controller Class Initialized
INFO - 2018-05-09 11:13:12 --> Helper loaded: permission_helper
INFO - 2018-05-09 11:13:12 --> Helper loaded: users_helper
INFO - 2018-05-09 11:13:12 --> Model Class Initialized
INFO - 2018-05-09 11:13:12 --> Helper loaded: inflector_helper
INFO - 2018-05-09 11:13:12 --> Model Class Initialized
INFO - 2018-05-09 11:13:12 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 11:13:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-05-09 11:13:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 11:13:12 --> Database Driver Class Initialized
INFO - 2018-05-09 11:13:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 11:13:12 --> Model Class Initialized
INFO - 2018-05-09 11:13:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 11:13:12 --> Model Class Initialized
INFO - 2018-05-09 11:13:12 --> Model Class Initialized
INFO - 2018-05-09 11:13:12 --> Model Class Initialized
INFO - 2018-05-09 11:13:12 --> Model Class Initialized
INFO - 2018-05-09 11:13:12 --> Final output sent to browser
DEBUG - 2018-05-09 11:13:12 --> Total execution time: 0.1800
INFO - 2018-05-09 11:13:12 --> Model Class Initialized
INFO - 2018-05-09 11:13:12 --> Model Class Initialized
INFO - 2018-05-09 11:13:12 --> Model Class Initialized
INFO - 2018-05-09 11:13:12 --> Model Class Initialized
INFO - 2018-05-09 11:13:12 --> Model Class Initialized
INFO - 2018-05-09 11:13:12 --> Model Class Initialized
INFO - 2018-05-09 11:13:12 --> Model Class Initialized
INFO - 2018-05-09 11:13:12 --> Model Class Initialized
INFO - 2018-05-09 11:13:12 --> Model Class Initialized
INFO - 2018-05-09 11:13:12 --> Model Class Initialized
INFO - 2018-05-09 11:13:12 --> Model Class Initialized
INFO - 2018-05-09 11:13:12 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-05-09 11:13:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 11:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 11:13:12 --> Final output sent to browser
DEBUG - 2018-05-09 11:13:12 --> Total execution time: 0.1978
INFO - 2018-05-09 11:13:12 --> Model Class Initialized
INFO - 2018-05-09 11:13:12 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 11:13:12 --> Model Class Initialized
INFO - 2018-05-09 11:13:12 --> Database Driver Class Initialized
INFO - 2018-05-09 11:13:12 --> Helper loaded: form_helper
INFO - 2018-05-09 11:13:12 --> Form Validation Class Initialized
INFO - 2018-05-09 11:13:12 --> Controller Class Initialized
DEBUG - 2018-05-09 11:13:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 11:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 11:13:12 --> Helper loaded: form_helper
INFO - 2018-05-09 11:13:12 --> Form Validation Class Initialized
INFO - 2018-05-09 11:13:12 --> Controller Class Initialized
INFO - 2018-05-09 11:13:12 --> Model Class Initialized
INFO - 2018-05-09 11:13:12 --> Helper loaded: inflector_helper
INFO - 2018-05-09 11:13:12 --> Model Class Initialized
DEBUG - 2018-05-09 11:13:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 11:13:12 --> Final output sent to browser
DEBUG - 2018-05-09 11:13:12 --> Total execution time: 0.2473
INFO - 2018-05-09 11:13:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 11:13:12 --> Helper loaded: inflector_helper
INFO - 2018-05-09 11:13:12 --> Model Class Initialized
INFO - 2018-05-09 11:13:12 --> Model Class Initialized
INFO - 2018-05-09 11:13:12 --> Model Class Initialized
DEBUG - 2018-05-09 11:13:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 11:13:12 --> Model Class Initialized
INFO - 2018-05-09 11:13:12 --> Model Class Initialized
INFO - 2018-05-09 11:13:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 11:13:12 --> Model Class Initialized
INFO - 2018-05-09 11:13:12 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 11:13:12 --> Model Class Initialized
INFO - 2018-05-09 11:13:12 --> Model Class Initialized
INFO - 2018-05-09 11:13:12 --> Model Class Initialized
INFO - 2018-05-09 11:13:12 --> Model Class Initialized
INFO - 2018-05-09 11:13:12 --> Model Class Initialized
INFO - 2018-05-09 11:13:12 --> Model Class Initialized
INFO - 2018-05-09 11:13:12 --> Model Class Initialized
INFO - 2018-05-09 11:13:12 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 11:13:12 --> Final output sent to browser
DEBUG - 2018-05-09 11:13:12 --> Total execution time: 0.2629
INFO - 2018-05-09 11:13:12 --> Model Class Initialized
INFO - 2018-05-09 11:13:12 --> Final output sent to browser
DEBUG - 2018-05-09 11:13:12 --> Total execution time: 0.2555
INFO - 2018-05-09 05:43:31 --> Config Class Initialized
INFO - 2018-05-09 05:43:31 --> Hooks Class Initialized
DEBUG - 2018-05-09 05:43:31 --> UTF-8 Support Enabled
INFO - 2018-05-09 05:43:31 --> Utf8 Class Initialized
INFO - 2018-05-09 05:43:31 --> URI Class Initialized
INFO - 2018-05-09 05:43:31 --> Router Class Initialized
INFO - 2018-05-09 05:43:31 --> Output Class Initialized
INFO - 2018-05-09 05:43:31 --> Security Class Initialized
DEBUG - 2018-05-09 05:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 05:43:31 --> Input Class Initialized
INFO - 2018-05-09 05:43:31 --> Language Class Initialized
INFO - 2018-05-09 05:43:31 --> Language Class Initialized
INFO - 2018-05-09 05:43:31 --> Config Class Initialized
INFO - 2018-05-09 05:43:31 --> Loader Class Initialized
INFO - 2018-05-09 11:13:31 --> Helper loaded: url_helper
INFO - 2018-05-09 11:13:31 --> Helper loaded: notification_helper
INFO - 2018-05-09 11:13:31 --> Helper loaded: settings_helper
INFO - 2018-05-09 11:13:31 --> Helper loaded: permission_helper
INFO - 2018-05-09 11:13:31 --> Helper loaded: users_helper
INFO - 2018-05-09 11:13:31 --> Database Driver Class Initialized
DEBUG - 2018-05-09 11:13:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 11:13:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 11:13:31 --> Helper loaded: form_helper
INFO - 2018-05-09 11:13:31 --> Form Validation Class Initialized
INFO - 2018-05-09 11:13:31 --> Controller Class Initialized
INFO - 2018-05-09 11:13:31 --> Model Class Initialized
INFO - 2018-05-09 11:13:31 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 11:13:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 11:13:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 11:13:31 --> Model Class Initialized
INFO - 2018-05-09 11:13:31 --> Model Class Initialized
INFO - 2018-05-09 11:13:31 --> Model Class Initialized
INFO - 2018-05-09 11:13:31 --> Model Class Initialized
INFO - 2018-05-09 11:13:31 --> Model Class Initialized
INFO - 2018-05-09 11:13:31 --> Model Class Initialized
INFO - 2018-05-09 11:13:31 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-05-09 11:13:31 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 800
INFO - 2018-05-09 11:13:31 --> Final output sent to browser
DEBUG - 2018-05-09 11:13:31 --> Total execution time: 0.1195
INFO - 2018-05-09 05:43:32 --> Config Class Initialized
INFO - 2018-05-09 05:43:32 --> Hooks Class Initialized
DEBUG - 2018-05-09 05:43:32 --> UTF-8 Support Enabled
INFO - 2018-05-09 05:43:32 --> Utf8 Class Initialized
INFO - 2018-05-09 05:43:32 --> URI Class Initialized
INFO - 2018-05-09 05:43:32 --> Router Class Initialized
INFO - 2018-05-09 05:43:33 --> Output Class Initialized
INFO - 2018-05-09 05:43:33 --> Security Class Initialized
DEBUG - 2018-05-09 05:43:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 05:43:33 --> Input Class Initialized
INFO - 2018-05-09 05:43:33 --> Language Class Initialized
INFO - 2018-05-09 05:43:33 --> Language Class Initialized
INFO - 2018-05-09 05:43:33 --> Config Class Initialized
INFO - 2018-05-09 05:43:33 --> Loader Class Initialized
INFO - 2018-05-09 11:13:33 --> Helper loaded: url_helper
INFO - 2018-05-09 11:13:33 --> Helper loaded: notification_helper
INFO - 2018-05-09 11:13:33 --> Helper loaded: settings_helper
INFO - 2018-05-09 11:13:33 --> Helper loaded: permission_helper
INFO - 2018-05-09 11:13:33 --> Helper loaded: users_helper
INFO - 2018-05-09 11:13:33 --> Database Driver Class Initialized
DEBUG - 2018-05-09 11:13:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 11:13:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 11:13:33 --> Helper loaded: form_helper
INFO - 2018-05-09 11:13:33 --> Form Validation Class Initialized
INFO - 2018-05-09 11:13:33 --> Controller Class Initialized
INFO - 2018-05-09 11:13:33 --> Model Class Initialized
INFO - 2018-05-09 11:13:33 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 11:13:33 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 11:13:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 11:13:33 --> Model Class Initialized
INFO - 2018-05-09 11:13:33 --> Model Class Initialized
INFO - 2018-05-09 11:13:33 --> Model Class Initialized
INFO - 2018-05-09 11:13:33 --> Model Class Initialized
INFO - 2018-05-09 11:13:33 --> Model Class Initialized
INFO - 2018-05-09 11:13:33 --> Model Class Initialized
INFO - 2018-05-09 11:13:33 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 11:13:33 --> Model Class Initialized
INFO - 2018-05-09 11:13:33 --> Final output sent to browser
DEBUG - 2018-05-09 11:13:33 --> Total execution time: 0.1393
INFO - 2018-05-09 05:43:33 --> Config Class Initialized
INFO - 2018-05-09 05:43:33 --> Hooks Class Initialized
DEBUG - 2018-05-09 05:43:33 --> UTF-8 Support Enabled
INFO - 2018-05-09 05:43:33 --> Utf8 Class Initialized
INFO - 2018-05-09 05:43:33 --> URI Class Initialized
INFO - 2018-05-09 05:43:33 --> Router Class Initialized
INFO - 2018-05-09 05:43:33 --> Output Class Initialized
INFO - 2018-05-09 05:43:33 --> Security Class Initialized
DEBUG - 2018-05-09 05:43:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 05:43:33 --> Input Class Initialized
INFO - 2018-05-09 05:43:33 --> Language Class Initialized
INFO - 2018-05-09 05:43:33 --> Language Class Initialized
INFO - 2018-05-09 05:43:33 --> Config Class Initialized
INFO - 2018-05-09 05:43:33 --> Loader Class Initialized
INFO - 2018-05-09 11:13:33 --> Helper loaded: url_helper
INFO - 2018-05-09 11:13:33 --> Helper loaded: notification_helper
INFO - 2018-05-09 11:13:33 --> Helper loaded: settings_helper
INFO - 2018-05-09 11:13:33 --> Helper loaded: permission_helper
INFO - 2018-05-09 11:13:33 --> Helper loaded: users_helper
INFO - 2018-05-09 11:13:33 --> Database Driver Class Initialized
DEBUG - 2018-05-09 11:13:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 11:13:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 11:13:33 --> Helper loaded: form_helper
INFO - 2018-05-09 11:13:33 --> Form Validation Class Initialized
INFO - 2018-05-09 11:13:33 --> Controller Class Initialized
INFO - 2018-05-09 11:13:33 --> Model Class Initialized
INFO - 2018-05-09 11:13:33 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 11:13:33 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 11:13:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 11:13:33 --> Model Class Initialized
INFO - 2018-05-09 11:13:33 --> Model Class Initialized
INFO - 2018-05-09 11:13:33 --> Model Class Initialized
INFO - 2018-05-09 11:13:33 --> Model Class Initialized
INFO - 2018-05-09 11:13:33 --> Model Class Initialized
INFO - 2018-05-09 11:13:33 --> Model Class Initialized
INFO - 2018-05-09 11:13:33 --> Model Class Initialized
INFO - 2018-05-09 11:13:33 --> Model Class Initialized
INFO - 2018-05-09 11:13:33 --> Model Class Initialized
INFO - 2018-05-09 11:13:33 --> Model Class Initialized
INFO - 2018-05-09 11:13:33 --> Model Class Initialized
INFO - 2018-05-09 11:13:33 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 11:13:33 --> Model Class Initialized
INFO - 2018-05-09 11:13:33 --> Final output sent to browser
DEBUG - 2018-05-09 11:13:33 --> Total execution time: 0.1352
INFO - 2018-05-09 05:43:35 --> Config Class Initialized
INFO - 2018-05-09 05:43:35 --> Hooks Class Initialized
DEBUG - 2018-05-09 05:43:35 --> UTF-8 Support Enabled
INFO - 2018-05-09 05:43:35 --> Utf8 Class Initialized
INFO - 2018-05-09 05:43:35 --> URI Class Initialized
INFO - 2018-05-09 05:43:35 --> Router Class Initialized
INFO - 2018-05-09 05:43:35 --> Output Class Initialized
INFO - 2018-05-09 05:43:35 --> Security Class Initialized
DEBUG - 2018-05-09 05:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 05:43:35 --> Input Class Initialized
INFO - 2018-05-09 05:43:35 --> Language Class Initialized
INFO - 2018-05-09 05:43:35 --> Language Class Initialized
INFO - 2018-05-09 05:43:35 --> Config Class Initialized
INFO - 2018-05-09 05:43:35 --> Loader Class Initialized
INFO - 2018-05-09 11:13:35 --> Helper loaded: url_helper
INFO - 2018-05-09 11:13:35 --> Helper loaded: notification_helper
INFO - 2018-05-09 11:13:35 --> Helper loaded: settings_helper
INFO - 2018-05-09 11:13:35 --> Helper loaded: permission_helper
INFO - 2018-05-09 11:13:35 --> Helper loaded: users_helper
INFO - 2018-05-09 11:13:35 --> Database Driver Class Initialized
DEBUG - 2018-05-09 11:13:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 11:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 11:13:35 --> Helper loaded: form_helper
INFO - 2018-05-09 11:13:35 --> Form Validation Class Initialized
INFO - 2018-05-09 11:13:35 --> Controller Class Initialized
INFO - 2018-05-09 11:13:35 --> Model Class Initialized
INFO - 2018-05-09 11:13:35 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 11:13:35 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 11:13:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 11:13:35 --> Model Class Initialized
INFO - 2018-05-09 11:13:35 --> Model Class Initialized
INFO - 2018-05-09 11:13:35 --> Model Class Initialized
INFO - 2018-05-09 11:13:35 --> Model Class Initialized
INFO - 2018-05-09 11:13:35 --> Model Class Initialized
INFO - 2018-05-09 11:13:35 --> Model Class Initialized
INFO - 2018-05-09 11:13:35 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-05-09 11:13:35 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 800
INFO - 2018-05-09 11:13:35 --> Final output sent to browser
DEBUG - 2018-05-09 11:13:35 --> Total execution time: 0.2555
INFO - 2018-05-09 05:43:38 --> Config Class Initialized
INFO - 2018-05-09 05:43:38 --> Hooks Class Initialized
DEBUG - 2018-05-09 05:43:38 --> UTF-8 Support Enabled
INFO - 2018-05-09 05:43:38 --> Utf8 Class Initialized
INFO - 2018-05-09 05:43:38 --> URI Class Initialized
INFO - 2018-05-09 05:43:38 --> Config Class Initialized
INFO - 2018-05-09 05:43:38 --> Hooks Class Initialized
INFO - 2018-05-09 05:43:38 --> Router Class Initialized
DEBUG - 2018-05-09 05:43:38 --> UTF-8 Support Enabled
INFO - 2018-05-09 05:43:38 --> Utf8 Class Initialized
INFO - 2018-05-09 05:43:38 --> Output Class Initialized
INFO - 2018-05-09 05:43:38 --> URI Class Initialized
INFO - 2018-05-09 05:43:38 --> Security Class Initialized
DEBUG - 2018-05-09 05:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 05:43:38 --> Input Class Initialized
INFO - 2018-05-09 05:43:38 --> Language Class Initialized
INFO - 2018-05-09 05:43:38 --> Router Class Initialized
INFO - 2018-05-09 05:43:38 --> Output Class Initialized
INFO - 2018-05-09 05:43:38 --> Security Class Initialized
DEBUG - 2018-05-09 05:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 05:43:38 --> Input Class Initialized
INFO - 2018-05-09 05:43:38 --> Language Class Initialized
INFO - 2018-05-09 05:43:38 --> Language Class Initialized
INFO - 2018-05-09 05:43:38 --> Config Class Initialized
INFO - 2018-05-09 05:43:38 --> Loader Class Initialized
INFO - 2018-05-09 11:13:38 --> Helper loaded: url_helper
INFO - 2018-05-09 11:13:38 --> Helper loaded: notification_helper
INFO - 2018-05-09 11:13:38 --> Helper loaded: settings_helper
INFO - 2018-05-09 11:13:38 --> Helper loaded: permission_helper
INFO - 2018-05-09 11:13:38 --> Helper loaded: users_helper
INFO - 2018-05-09 11:13:38 --> Database Driver Class Initialized
INFO - 2018-05-09 05:43:38 --> Language Class Initialized
INFO - 2018-05-09 05:43:38 --> Config Class Initialized
INFO - 2018-05-09 05:43:38 --> Loader Class Initialized
INFO - 2018-05-09 11:13:38 --> Helper loaded: url_helper
DEBUG - 2018-05-09 11:13:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 11:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 11:13:38 --> Helper loaded: notification_helper
INFO - 2018-05-09 11:13:38 --> Helper loaded: settings_helper
INFO - 2018-05-09 11:13:38 --> Helper loaded: permission_helper
INFO - 2018-05-09 11:13:38 --> Helper loaded: users_helper
INFO - 2018-05-09 11:13:38 --> Helper loaded: form_helper
INFO - 2018-05-09 11:13:38 --> Form Validation Class Initialized
INFO - 2018-05-09 11:13:38 --> Controller Class Initialized
INFO - 2018-05-09 11:13:38 --> Database Driver Class Initialized
INFO - 2018-05-09 11:13:38 --> Model Class Initialized
INFO - 2018-05-09 11:13:38 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 11:13:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-05-09 11:13:38 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 11:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 11:13:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 11:13:38 --> Model Class Initialized
INFO - 2018-05-09 11:13:38 --> Model Class Initialized
INFO - 2018-05-09 11:13:38 --> Model Class Initialized
INFO - 2018-05-09 11:13:38 --> Model Class Initialized
INFO - 2018-05-09 11:13:38 --> Model Class Initialized
INFO - 2018-05-09 11:13:38 --> Model Class Initialized
INFO - 2018-05-09 11:13:38 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 11:13:38 --> Helper loaded: form_helper
INFO - 2018-05-09 11:13:38 --> Form Validation Class Initialized
INFO - 2018-05-09 11:13:38 --> Controller Class Initialized
INFO - 2018-05-09 11:13:38 --> Model Class Initialized
INFO - 2018-05-09 11:13:38 --> Final output sent to browser
DEBUG - 2018-05-09 11:13:38 --> Total execution time: 0.1095
INFO - 2018-05-09 11:13:38 --> Model Class Initialized
INFO - 2018-05-09 11:13:38 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 11:13:38 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 11:13:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 11:13:38 --> Model Class Initialized
INFO - 2018-05-09 11:13:38 --> Model Class Initialized
INFO - 2018-05-09 11:13:38 --> Model Class Initialized
INFO - 2018-05-09 11:13:38 --> Model Class Initialized
INFO - 2018-05-09 11:13:38 --> Model Class Initialized
INFO - 2018-05-09 11:13:38 --> Model Class Initialized
INFO - 2018-05-09 11:13:38 --> Model Class Initialized
INFO - 2018-05-09 11:13:38 --> Model Class Initialized
INFO - 2018-05-09 11:13:38 --> Model Class Initialized
INFO - 2018-05-09 11:13:38 --> Model Class Initialized
INFO - 2018-05-09 11:13:38 --> Model Class Initialized
INFO - 2018-05-09 11:13:38 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 11:13:38 --> Model Class Initialized
INFO - 2018-05-09 11:13:38 --> Final output sent to browser
DEBUG - 2018-05-09 11:13:38 --> Total execution time: 0.1577
INFO - 2018-05-09 05:43:39 --> Config Class Initialized
INFO - 2018-05-09 05:43:39 --> Hooks Class Initialized
DEBUG - 2018-05-09 05:43:39 --> UTF-8 Support Enabled
INFO - 2018-05-09 05:43:39 --> Utf8 Class Initialized
INFO - 2018-05-09 05:43:39 --> URI Class Initialized
INFO - 2018-05-09 05:43:39 --> Router Class Initialized
INFO - 2018-05-09 05:43:39 --> Output Class Initialized
INFO - 2018-05-09 05:43:39 --> Security Class Initialized
DEBUG - 2018-05-09 05:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 05:43:39 --> Input Class Initialized
INFO - 2018-05-09 05:43:39 --> Language Class Initialized
INFO - 2018-05-09 05:43:39 --> Language Class Initialized
INFO - 2018-05-09 05:43:39 --> Config Class Initialized
INFO - 2018-05-09 05:43:39 --> Loader Class Initialized
INFO - 2018-05-09 11:13:39 --> Helper loaded: url_helper
INFO - 2018-05-09 11:13:39 --> Helper loaded: notification_helper
INFO - 2018-05-09 11:13:39 --> Helper loaded: settings_helper
INFO - 2018-05-09 11:13:39 --> Helper loaded: permission_helper
INFO - 2018-05-09 11:13:39 --> Helper loaded: users_helper
INFO - 2018-05-09 05:43:39 --> Config Class Initialized
INFO - 2018-05-09 05:43:39 --> Hooks Class Initialized
DEBUG - 2018-05-09 05:43:39 --> UTF-8 Support Enabled
INFO - 2018-05-09 05:43:39 --> Utf8 Class Initialized
INFO - 2018-05-09 05:43:39 --> URI Class Initialized
INFO - 2018-05-09 11:13:39 --> Database Driver Class Initialized
INFO - 2018-05-09 05:43:39 --> Router Class Initialized
DEBUG - 2018-05-09 11:13:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 11:13:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 05:43:39 --> Output Class Initialized
INFO - 2018-05-09 05:43:39 --> Security Class Initialized
DEBUG - 2018-05-09 05:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 05:43:39 --> Input Class Initialized
INFO - 2018-05-09 05:43:39 --> Language Class Initialized
INFO - 2018-05-09 11:13:39 --> Helper loaded: form_helper
INFO - 2018-05-09 11:13:39 --> Form Validation Class Initialized
INFO - 2018-05-09 11:13:39 --> Controller Class Initialized
INFO - 2018-05-09 11:13:39 --> Model Class Initialized
INFO - 2018-05-09 11:13:39 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 11:13:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 11:13:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 11:13:39 --> Model Class Initialized
INFO - 2018-05-09 11:13:39 --> Model Class Initialized
INFO - 2018-05-09 11:13:39 --> Model Class Initialized
INFO - 2018-05-09 11:13:39 --> Model Class Initialized
INFO - 2018-05-09 11:13:39 --> Model Class Initialized
INFO - 2018-05-09 11:13:39 --> Model Class Initialized
INFO - 2018-05-09 11:13:39 --> Model Class Initialized
INFO - 2018-05-09 11:13:39 --> Model Class Initialized
INFO - 2018-05-09 11:13:39 --> Model Class Initialized
INFO - 2018-05-09 11:13:39 --> Model Class Initialized
INFO - 2018-05-09 05:43:39 --> Language Class Initialized
INFO - 2018-05-09 05:43:39 --> Config Class Initialized
INFO - 2018-05-09 05:43:39 --> Loader Class Initialized
INFO - 2018-05-09 11:13:39 --> Model Class Initialized
INFO - 2018-05-09 11:13:39 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 11:13:39 --> Helper loaded: url_helper
INFO - 2018-05-09 11:13:39 --> Model Class Initialized
INFO - 2018-05-09 11:13:39 --> Helper loaded: notification_helper
INFO - 2018-05-09 11:13:39 --> Helper loaded: settings_helper
INFO - 2018-05-09 11:13:39 --> Helper loaded: permission_helper
INFO - 2018-05-09 11:13:39 --> Helper loaded: users_helper
INFO - 2018-05-09 11:13:39 --> Database Driver Class Initialized
INFO - 2018-05-09 11:13:39 --> Final output sent to browser
DEBUG - 2018-05-09 11:13:39 --> Total execution time: 0.1722
DEBUG - 2018-05-09 11:13:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 11:13:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 11:13:39 --> Helper loaded: form_helper
INFO - 2018-05-09 11:13:39 --> Form Validation Class Initialized
INFO - 2018-05-09 11:13:39 --> Controller Class Initialized
INFO - 2018-05-09 11:13:40 --> Model Class Initialized
INFO - 2018-05-09 11:13:40 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 11:13:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 11:13:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 11:13:40 --> Model Class Initialized
INFO - 2018-05-09 11:13:40 --> Model Class Initialized
INFO - 2018-05-09 11:13:40 --> Model Class Initialized
INFO - 2018-05-09 11:13:40 --> Model Class Initialized
INFO - 2018-05-09 11:13:40 --> Model Class Initialized
INFO - 2018-05-09 11:13:40 --> Model Class Initialized
INFO - 2018-05-09 11:13:40 --> Model Class Initialized
INFO - 2018-05-09 11:13:40 --> Model Class Initialized
INFO - 2018-05-09 11:13:40 --> Model Class Initialized
INFO - 2018-05-09 11:13:40 --> Model Class Initialized
INFO - 2018-05-09 11:13:40 --> Model Class Initialized
INFO - 2018-05-09 11:13:40 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 11:13:40 --> Final output sent to browser
DEBUG - 2018-05-09 11:13:40 --> Total execution time: 0.1476
INFO - 2018-05-09 05:43:41 --> Config Class Initialized
INFO - 2018-05-09 05:43:41 --> Hooks Class Initialized
DEBUG - 2018-05-09 05:43:41 --> UTF-8 Support Enabled
INFO - 2018-05-09 05:43:41 --> Utf8 Class Initialized
INFO - 2018-05-09 05:43:41 --> URI Class Initialized
INFO - 2018-05-09 05:43:41 --> Router Class Initialized
INFO - 2018-05-09 05:43:41 --> Output Class Initialized
INFO - 2018-05-09 05:43:41 --> Security Class Initialized
DEBUG - 2018-05-09 05:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 05:43:41 --> Input Class Initialized
INFO - 2018-05-09 05:43:41 --> Language Class Initialized
INFO - 2018-05-09 05:43:41 --> Language Class Initialized
INFO - 2018-05-09 05:43:41 --> Config Class Initialized
INFO - 2018-05-09 05:43:41 --> Loader Class Initialized
INFO - 2018-05-09 11:13:41 --> Helper loaded: url_helper
INFO - 2018-05-09 11:13:41 --> Helper loaded: notification_helper
INFO - 2018-05-09 11:13:41 --> Helper loaded: settings_helper
INFO - 2018-05-09 11:13:41 --> Helper loaded: permission_helper
INFO - 2018-05-09 11:13:41 --> Helper loaded: users_helper
INFO - 2018-05-09 11:13:41 --> Database Driver Class Initialized
DEBUG - 2018-05-09 11:13:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 11:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 11:13:41 --> Helper loaded: form_helper
INFO - 2018-05-09 11:13:41 --> Form Validation Class Initialized
INFO - 2018-05-09 11:13:41 --> Controller Class Initialized
INFO - 2018-05-09 11:13:41 --> Model Class Initialized
INFO - 2018-05-09 11:13:41 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 11:13:41 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 11:13:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 11:13:41 --> Model Class Initialized
INFO - 2018-05-09 11:13:41 --> Model Class Initialized
INFO - 2018-05-09 11:13:41 --> Model Class Initialized
INFO - 2018-05-09 11:13:41 --> Model Class Initialized
INFO - 2018-05-09 11:13:41 --> Model Class Initialized
INFO - 2018-05-09 11:13:41 --> Model Class Initialized
INFO - 2018-05-09 11:13:41 --> Model Class Initialized
INFO - 2018-05-09 11:13:41 --> Model Class Initialized
INFO - 2018-05-09 11:13:41 --> Model Class Initialized
INFO - 2018-05-09 11:13:41 --> Model Class Initialized
INFO - 2018-05-09 11:13:41 --> Model Class Initialized
INFO - 2018-05-09 11:13:41 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 11:13:41 --> Final output sent to browser
DEBUG - 2018-05-09 11:13:41 --> Total execution time: 0.1295
INFO - 2018-05-09 05:43:42 --> Config Class Initialized
INFO - 2018-05-09 05:43:42 --> Hooks Class Initialized
DEBUG - 2018-05-09 05:43:42 --> UTF-8 Support Enabled
INFO - 2018-05-09 05:43:42 --> Utf8 Class Initialized
INFO - 2018-05-09 05:43:42 --> URI Class Initialized
INFO - 2018-05-09 05:43:42 --> Router Class Initialized
INFO - 2018-05-09 05:43:42 --> Output Class Initialized
INFO - 2018-05-09 05:43:42 --> Security Class Initialized
DEBUG - 2018-05-09 05:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 05:43:42 --> Input Class Initialized
INFO - 2018-05-09 05:43:42 --> Language Class Initialized
INFO - 2018-05-09 05:43:42 --> Language Class Initialized
INFO - 2018-05-09 05:43:42 --> Config Class Initialized
INFO - 2018-05-09 05:43:42 --> Loader Class Initialized
INFO - 2018-05-09 11:13:42 --> Helper loaded: url_helper
INFO - 2018-05-09 11:13:42 --> Helper loaded: notification_helper
INFO - 2018-05-09 11:13:42 --> Helper loaded: settings_helper
INFO - 2018-05-09 11:13:42 --> Helper loaded: permission_helper
INFO - 2018-05-09 11:13:42 --> Helper loaded: users_helper
INFO - 2018-05-09 11:13:42 --> Database Driver Class Initialized
DEBUG - 2018-05-09 11:13:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 11:13:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 11:13:42 --> Helper loaded: form_helper
INFO - 2018-05-09 11:13:42 --> Form Validation Class Initialized
INFO - 2018-05-09 11:13:42 --> Controller Class Initialized
INFO - 2018-05-09 11:13:42 --> Model Class Initialized
INFO - 2018-05-09 11:13:42 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 11:13:42 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 11:13:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 11:13:42 --> Model Class Initialized
INFO - 2018-05-09 11:13:42 --> Model Class Initialized
INFO - 2018-05-09 11:13:42 --> Model Class Initialized
INFO - 2018-05-09 11:13:42 --> Model Class Initialized
INFO - 2018-05-09 11:13:42 --> Model Class Initialized
INFO - 2018-05-09 11:13:42 --> Model Class Initialized
INFO - 2018-05-09 11:13:42 --> Model Class Initialized
INFO - 2018-05-09 11:13:42 --> Model Class Initialized
INFO - 2018-05-09 11:13:42 --> Model Class Initialized
INFO - 2018-05-09 11:13:42 --> Model Class Initialized
INFO - 2018-05-09 11:13:42 --> Model Class Initialized
INFO - 2018-05-09 11:13:42 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 11:13:42 --> Model Class Initialized
INFO - 2018-05-09 11:13:42 --> Final output sent to browser
DEBUG - 2018-05-09 11:13:42 --> Total execution time: 0.1963
INFO - 2018-05-09 05:43:43 --> Config Class Initialized
INFO - 2018-05-09 05:43:43 --> Hooks Class Initialized
DEBUG - 2018-05-09 05:43:43 --> UTF-8 Support Enabled
INFO - 2018-05-09 05:43:43 --> Utf8 Class Initialized
INFO - 2018-05-09 05:43:43 --> URI Class Initialized
INFO - 2018-05-09 05:43:43 --> Router Class Initialized
INFO - 2018-05-09 05:43:43 --> Output Class Initialized
INFO - 2018-05-09 05:43:43 --> Security Class Initialized
DEBUG - 2018-05-09 05:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 05:43:43 --> Input Class Initialized
INFO - 2018-05-09 05:43:43 --> Language Class Initialized
INFO - 2018-05-09 05:43:43 --> Language Class Initialized
INFO - 2018-05-09 05:43:43 --> Config Class Initialized
INFO - 2018-05-09 05:43:43 --> Loader Class Initialized
INFO - 2018-05-09 11:13:43 --> Helper loaded: url_helper
INFO - 2018-05-09 11:13:43 --> Helper loaded: notification_helper
INFO - 2018-05-09 11:13:43 --> Helper loaded: settings_helper
INFO - 2018-05-09 11:13:43 --> Helper loaded: permission_helper
INFO - 2018-05-09 11:13:43 --> Helper loaded: users_helper
INFO - 2018-05-09 11:13:43 --> Database Driver Class Initialized
DEBUG - 2018-05-09 11:13:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 11:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 11:13:43 --> Helper loaded: form_helper
INFO - 2018-05-09 11:13:43 --> Form Validation Class Initialized
INFO - 2018-05-09 11:13:43 --> Controller Class Initialized
INFO - 2018-05-09 11:13:44 --> Model Class Initialized
INFO - 2018-05-09 11:13:44 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 11:13:44 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 11:13:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 11:13:44 --> Model Class Initialized
INFO - 2018-05-09 11:13:44 --> Model Class Initialized
INFO - 2018-05-09 11:13:44 --> Model Class Initialized
INFO - 2018-05-09 11:13:44 --> Model Class Initialized
INFO - 2018-05-09 11:13:44 --> Model Class Initialized
INFO - 2018-05-09 11:13:44 --> Model Class Initialized
INFO - 2018-05-09 11:13:44 --> Model Class Initialized
INFO - 2018-05-09 11:13:44 --> Model Class Initialized
INFO - 2018-05-09 11:13:44 --> Model Class Initialized
INFO - 2018-05-09 11:13:44 --> Model Class Initialized
INFO - 2018-05-09 11:13:44 --> Model Class Initialized
INFO - 2018-05-09 11:13:44 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 11:13:44 --> Final output sent to browser
DEBUG - 2018-05-09 11:13:44 --> Total execution time: 0.1365
INFO - 2018-05-09 05:43:47 --> Config Class Initialized
INFO - 2018-05-09 05:43:47 --> Hooks Class Initialized
DEBUG - 2018-05-09 05:43:47 --> UTF-8 Support Enabled
INFO - 2018-05-09 05:43:47 --> Utf8 Class Initialized
INFO - 2018-05-09 05:43:47 --> URI Class Initialized
INFO - 2018-05-09 05:43:47 --> Router Class Initialized
INFO - 2018-05-09 05:43:47 --> Output Class Initialized
INFO - 2018-05-09 05:43:47 --> Security Class Initialized
DEBUG - 2018-05-09 05:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 05:43:47 --> Input Class Initialized
INFO - 2018-05-09 05:43:47 --> Language Class Initialized
INFO - 2018-05-09 05:43:47 --> Language Class Initialized
INFO - 2018-05-09 05:43:47 --> Config Class Initialized
INFO - 2018-05-09 05:43:47 --> Loader Class Initialized
INFO - 2018-05-09 11:13:47 --> Helper loaded: url_helper
INFO - 2018-05-09 11:13:47 --> Helper loaded: notification_helper
INFO - 2018-05-09 11:13:47 --> Helper loaded: settings_helper
INFO - 2018-05-09 11:13:47 --> Helper loaded: permission_helper
INFO - 2018-05-09 11:13:47 --> Helper loaded: users_helper
INFO - 2018-05-09 11:13:47 --> Database Driver Class Initialized
DEBUG - 2018-05-09 11:13:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 11:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 11:13:47 --> Helper loaded: form_helper
INFO - 2018-05-09 11:13:47 --> Form Validation Class Initialized
INFO - 2018-05-09 11:13:47 --> Controller Class Initialized
INFO - 2018-05-09 11:13:47 --> Model Class Initialized
INFO - 2018-05-09 11:13:47 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 11:13:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 11:13:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 11:13:47 --> Model Class Initialized
INFO - 2018-05-09 11:13:47 --> Model Class Initialized
INFO - 2018-05-09 11:13:47 --> Model Class Initialized
INFO - 2018-05-09 11:13:47 --> Model Class Initialized
INFO - 2018-05-09 11:13:47 --> Model Class Initialized
INFO - 2018-05-09 11:13:47 --> Model Class Initialized
INFO - 2018-05-09 11:13:47 --> Model Class Initialized
INFO - 2018-05-09 11:13:47 --> Model Class Initialized
INFO - 2018-05-09 11:13:47 --> Model Class Initialized
INFO - 2018-05-09 11:13:47 --> Model Class Initialized
INFO - 2018-05-09 11:13:47 --> Model Class Initialized
INFO - 2018-05-09 11:13:47 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 11:13:47 --> Final output sent to browser
DEBUG - 2018-05-09 11:13:47 --> Total execution time: 0.1910
INFO - 2018-05-09 05:43:48 --> Config Class Initialized
INFO - 2018-05-09 05:43:48 --> Hooks Class Initialized
DEBUG - 2018-05-09 05:43:48 --> UTF-8 Support Enabled
INFO - 2018-05-09 05:43:48 --> Utf8 Class Initialized
INFO - 2018-05-09 05:43:48 --> URI Class Initialized
INFO - 2018-05-09 05:43:48 --> Router Class Initialized
INFO - 2018-05-09 05:43:48 --> Output Class Initialized
INFO - 2018-05-09 05:43:48 --> Security Class Initialized
DEBUG - 2018-05-09 05:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 05:43:48 --> Input Class Initialized
INFO - 2018-05-09 05:43:48 --> Language Class Initialized
INFO - 2018-05-09 05:43:48 --> Language Class Initialized
INFO - 2018-05-09 05:43:48 --> Config Class Initialized
INFO - 2018-05-09 05:43:48 --> Loader Class Initialized
INFO - 2018-05-09 11:13:48 --> Helper loaded: url_helper
INFO - 2018-05-09 11:13:48 --> Helper loaded: notification_helper
INFO - 2018-05-09 11:13:48 --> Helper loaded: settings_helper
INFO - 2018-05-09 11:13:48 --> Helper loaded: permission_helper
INFO - 2018-05-09 11:13:48 --> Helper loaded: users_helper
INFO - 2018-05-09 11:13:48 --> Database Driver Class Initialized
DEBUG - 2018-05-09 11:13:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 11:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 11:13:48 --> Helper loaded: form_helper
INFO - 2018-05-09 11:13:48 --> Form Validation Class Initialized
INFO - 2018-05-09 11:13:48 --> Controller Class Initialized
INFO - 2018-05-09 11:13:48 --> Model Class Initialized
INFO - 2018-05-09 11:13:48 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 11:13:48 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 11:13:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 11:13:48 --> Model Class Initialized
INFO - 2018-05-09 11:13:48 --> Model Class Initialized
INFO - 2018-05-09 11:13:48 --> Model Class Initialized
INFO - 2018-05-09 11:13:48 --> Model Class Initialized
INFO - 2018-05-09 11:13:48 --> Model Class Initialized
INFO - 2018-05-09 11:13:48 --> Model Class Initialized
INFO - 2018-05-09 11:13:48 --> Model Class Initialized
INFO - 2018-05-09 11:13:48 --> Model Class Initialized
INFO - 2018-05-09 11:13:48 --> Model Class Initialized
INFO - 2018-05-09 11:13:48 --> Model Class Initialized
INFO - 2018-05-09 11:13:48 --> Model Class Initialized
INFO - 2018-05-09 11:13:48 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 11:13:48 --> Final output sent to browser
DEBUG - 2018-05-09 11:13:48 --> Total execution time: 0.1353
INFO - 2018-05-09 05:43:54 --> Config Class Initialized
INFO - 2018-05-09 05:43:54 --> Hooks Class Initialized
DEBUG - 2018-05-09 05:43:54 --> UTF-8 Support Enabled
INFO - 2018-05-09 05:43:54 --> Utf8 Class Initialized
INFO - 2018-05-09 05:43:54 --> URI Class Initialized
INFO - 2018-05-09 05:43:54 --> Router Class Initialized
INFO - 2018-05-09 05:43:54 --> Output Class Initialized
INFO - 2018-05-09 05:43:54 --> Security Class Initialized
DEBUG - 2018-05-09 05:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 05:43:54 --> Input Class Initialized
INFO - 2018-05-09 05:43:54 --> Language Class Initialized
INFO - 2018-05-09 05:43:54 --> Language Class Initialized
INFO - 2018-05-09 05:43:54 --> Config Class Initialized
INFO - 2018-05-09 05:43:54 --> Loader Class Initialized
INFO - 2018-05-09 11:13:54 --> Helper loaded: url_helper
INFO - 2018-05-09 11:13:54 --> Helper loaded: notification_helper
INFO - 2018-05-09 11:13:54 --> Helper loaded: settings_helper
INFO - 2018-05-09 11:13:54 --> Helper loaded: permission_helper
INFO - 2018-05-09 11:13:54 --> Helper loaded: users_helper
INFO - 2018-05-09 11:13:54 --> Database Driver Class Initialized
DEBUG - 2018-05-09 11:13:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 11:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 11:13:54 --> Helper loaded: form_helper
INFO - 2018-05-09 11:13:54 --> Form Validation Class Initialized
INFO - 2018-05-09 11:13:54 --> Controller Class Initialized
INFO - 2018-05-09 11:13:54 --> Model Class Initialized
INFO - 2018-05-09 11:13:54 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 11:13:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 11:13:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 11:13:54 --> Model Class Initialized
INFO - 2018-05-09 11:13:54 --> Model Class Initialized
INFO - 2018-05-09 11:13:54 --> Model Class Initialized
INFO - 2018-05-09 11:13:54 --> Model Class Initialized
INFO - 2018-05-09 11:13:54 --> Model Class Initialized
INFO - 2018-05-09 11:13:54 --> Model Class Initialized
INFO - 2018-05-09 11:13:54 --> Model Class Initialized
INFO - 2018-05-09 11:13:54 --> Model Class Initialized
INFO - 2018-05-09 11:13:54 --> Model Class Initialized
INFO - 2018-05-09 11:13:54 --> Model Class Initialized
INFO - 2018-05-09 11:13:54 --> Model Class Initialized
INFO - 2018-05-09 11:13:54 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 11:13:54 --> Model Class Initialized
INFO - 2018-05-09 11:13:54 --> Final output sent to browser
DEBUG - 2018-05-09 11:13:54 --> Total execution time: 0.1592
INFO - 2018-05-09 05:44:01 --> Config Class Initialized
INFO - 2018-05-09 05:44:01 --> Hooks Class Initialized
DEBUG - 2018-05-09 05:44:01 --> UTF-8 Support Enabled
INFO - 2018-05-09 05:44:01 --> Utf8 Class Initialized
INFO - 2018-05-09 05:44:01 --> URI Class Initialized
INFO - 2018-05-09 05:44:01 --> Router Class Initialized
INFO - 2018-05-09 05:44:01 --> Output Class Initialized
INFO - 2018-05-09 05:44:01 --> Security Class Initialized
DEBUG - 2018-05-09 05:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 05:44:01 --> Input Class Initialized
INFO - 2018-05-09 05:44:01 --> Language Class Initialized
INFO - 2018-05-09 05:44:01 --> Language Class Initialized
INFO - 2018-05-09 05:44:01 --> Config Class Initialized
INFO - 2018-05-09 05:44:01 --> Loader Class Initialized
INFO - 2018-05-09 11:14:01 --> Helper loaded: url_helper
INFO - 2018-05-09 11:14:01 --> Helper loaded: notification_helper
INFO - 2018-05-09 11:14:01 --> Helper loaded: settings_helper
INFO - 2018-05-09 11:14:01 --> Helper loaded: permission_helper
INFO - 2018-05-09 11:14:01 --> Helper loaded: users_helper
INFO - 2018-05-09 11:14:01 --> Database Driver Class Initialized
DEBUG - 2018-05-09 11:14:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 11:14:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 11:14:02 --> Helper loaded: form_helper
INFO - 2018-05-09 11:14:02 --> Form Validation Class Initialized
INFO - 2018-05-09 11:14:02 --> Controller Class Initialized
INFO - 2018-05-09 11:14:02 --> Model Class Initialized
INFO - 2018-05-09 11:14:02 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 11:14:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 11:14:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 11:14:02 --> Model Class Initialized
INFO - 2018-05-09 11:14:02 --> Model Class Initialized
INFO - 2018-05-09 11:14:02 --> Model Class Initialized
INFO - 2018-05-09 11:14:02 --> Model Class Initialized
INFO - 2018-05-09 11:14:02 --> Final output sent to browser
DEBUG - 2018-05-09 11:14:02 --> Total execution time: 0.1107
INFO - 2018-05-09 05:44:03 --> Config Class Initialized
INFO - 2018-05-09 05:44:03 --> Hooks Class Initialized
DEBUG - 2018-05-09 05:44:03 --> UTF-8 Support Enabled
INFO - 2018-05-09 05:44:03 --> Utf8 Class Initialized
INFO - 2018-05-09 05:44:03 --> URI Class Initialized
INFO - 2018-05-09 05:44:03 --> Router Class Initialized
INFO - 2018-05-09 05:44:03 --> Output Class Initialized
INFO - 2018-05-09 05:44:03 --> Security Class Initialized
DEBUG - 2018-05-09 05:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 05:44:03 --> Input Class Initialized
INFO - 2018-05-09 05:44:03 --> Language Class Initialized
INFO - 2018-05-09 05:44:03 --> Language Class Initialized
INFO - 2018-05-09 05:44:03 --> Config Class Initialized
INFO - 2018-05-09 05:44:03 --> Loader Class Initialized
INFO - 2018-05-09 11:14:03 --> Helper loaded: url_helper
INFO - 2018-05-09 11:14:03 --> Helper loaded: notification_helper
INFO - 2018-05-09 11:14:03 --> Helper loaded: settings_helper
INFO - 2018-05-09 11:14:03 --> Helper loaded: permission_helper
INFO - 2018-05-09 11:14:03 --> Helper loaded: users_helper
INFO - 2018-05-09 11:14:03 --> Database Driver Class Initialized
DEBUG - 2018-05-09 11:14:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 11:14:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 11:14:03 --> Helper loaded: form_helper
INFO - 2018-05-09 11:14:03 --> Form Validation Class Initialized
INFO - 2018-05-09 11:14:03 --> Controller Class Initialized
INFO - 2018-05-09 05:44:03 --> Config Class Initialized
INFO - 2018-05-09 05:44:03 --> Hooks Class Initialized
DEBUG - 2018-05-09 05:44:03 --> UTF-8 Support Enabled
INFO - 2018-05-09 05:44:03 --> Utf8 Class Initialized
INFO - 2018-05-09 05:44:03 --> URI Class Initialized
INFO - 2018-05-09 11:14:03 --> Model Class Initialized
INFO - 2018-05-09 11:14:03 --> Helper loaded: inflector_helper
INFO - 2018-05-09 05:44:03 --> Router Class Initialized
DEBUG - 2018-05-09 11:14:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 11:14:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 11:14:03 --> Model Class Initialized
INFO - 2018-05-09 05:44:03 --> Output Class Initialized
INFO - 2018-05-09 11:14:03 --> Model Class Initialized
INFO - 2018-05-09 11:14:03 --> Model Class Initialized
INFO - 2018-05-09 11:14:03 --> Model Class Initialized
INFO - 2018-05-09 05:44:03 --> Security Class Initialized
INFO - 2018-05-09 11:14:03 --> Final output sent to browser
DEBUG - 2018-05-09 11:14:03 --> Total execution time: 0.1038
DEBUG - 2018-05-09 05:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 05:44:03 --> Input Class Initialized
INFO - 2018-05-09 05:44:03 --> Language Class Initialized
INFO - 2018-05-09 05:44:03 --> Language Class Initialized
INFO - 2018-05-09 05:44:03 --> Config Class Initialized
INFO - 2018-05-09 05:44:03 --> Loader Class Initialized
INFO - 2018-05-09 11:14:03 --> Helper loaded: url_helper
INFO - 2018-05-09 11:14:03 --> Helper loaded: notification_helper
INFO - 2018-05-09 11:14:03 --> Helper loaded: settings_helper
INFO - 2018-05-09 11:14:03 --> Helper loaded: permission_helper
INFO - 2018-05-09 11:14:03 --> Helper loaded: users_helper
INFO - 2018-05-09 11:14:03 --> Database Driver Class Initialized
DEBUG - 2018-05-09 11:14:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 11:14:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 11:14:03 --> Helper loaded: form_helper
INFO - 2018-05-09 11:14:03 --> Form Validation Class Initialized
INFO - 2018-05-09 11:14:03 --> Controller Class Initialized
INFO - 2018-05-09 11:14:03 --> Model Class Initialized
INFO - 2018-05-09 11:14:03 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 11:14:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 11:14:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 11:14:03 --> Model Class Initialized
INFO - 2018-05-09 11:14:03 --> Model Class Initialized
INFO - 2018-05-09 11:14:03 --> Model Class Initialized
INFO - 2018-05-09 11:14:03 --> Model Class Initialized
INFO - 2018-05-09 11:14:03 --> Final output sent to browser
DEBUG - 2018-05-09 11:14:03 --> Total execution time: 0.1043
INFO - 2018-05-09 05:44:04 --> Config Class Initialized
INFO - 2018-05-09 05:44:04 --> Hooks Class Initialized
INFO - 2018-05-09 05:44:04 --> Config Class Initialized
INFO - 2018-05-09 05:44:04 --> Hooks Class Initialized
DEBUG - 2018-05-09 05:44:04 --> UTF-8 Support Enabled
INFO - 2018-05-09 05:44:04 --> Utf8 Class Initialized
INFO - 2018-05-09 05:44:04 --> URI Class Initialized
DEBUG - 2018-05-09 05:44:04 --> UTF-8 Support Enabled
INFO - 2018-05-09 05:44:04 --> Utf8 Class Initialized
INFO - 2018-05-09 05:44:04 --> URI Class Initialized
INFO - 2018-05-09 05:44:04 --> Router Class Initialized
INFO - 2018-05-09 05:44:04 --> Router Class Initialized
INFO - 2018-05-09 05:44:04 --> Output Class Initialized
INFO - 2018-05-09 05:44:04 --> Security Class Initialized
INFO - 2018-05-09 05:44:04 --> Output Class Initialized
DEBUG - 2018-05-09 05:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 05:44:04 --> Input Class Initialized
INFO - 2018-05-09 05:44:04 --> Security Class Initialized
INFO - 2018-05-09 05:44:04 --> Language Class Initialized
DEBUG - 2018-05-09 05:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 05:44:04 --> Input Class Initialized
INFO - 2018-05-09 05:44:04 --> Language Class Initialized
INFO - 2018-05-09 05:44:04 --> Language Class Initialized
INFO - 2018-05-09 05:44:04 --> Config Class Initialized
INFO - 2018-05-09 05:44:04 --> Loader Class Initialized
INFO - 2018-05-09 11:14:04 --> Helper loaded: url_helper
INFO - 2018-05-09 05:44:04 --> Language Class Initialized
INFO - 2018-05-09 05:44:04 --> Config Class Initialized
INFO - 2018-05-09 05:44:04 --> Loader Class Initialized
INFO - 2018-05-09 11:14:04 --> Helper loaded: notification_helper
INFO - 2018-05-09 11:14:04 --> Helper loaded: settings_helper
INFO - 2018-05-09 11:14:04 --> Helper loaded: permission_helper
INFO - 2018-05-09 11:14:04 --> Helper loaded: users_helper
INFO - 2018-05-09 11:14:04 --> Helper loaded: url_helper
INFO - 2018-05-09 11:14:04 --> Helper loaded: notification_helper
INFO - 2018-05-09 11:14:04 --> Helper loaded: settings_helper
INFO - 2018-05-09 11:14:04 --> Helper loaded: permission_helper
INFO - 2018-05-09 11:14:04 --> Helper loaded: users_helper
INFO - 2018-05-09 11:14:04 --> Database Driver Class Initialized
INFO - 2018-05-09 11:14:04 --> Database Driver Class Initialized
DEBUG - 2018-05-09 11:14:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 11:14:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-05-09 11:14:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 11:14:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 11:14:04 --> Helper loaded: form_helper
INFO - 2018-05-09 11:14:04 --> Form Validation Class Initialized
INFO - 2018-05-09 11:14:04 --> Controller Class Initialized
INFO - 2018-05-09 11:14:04 --> Helper loaded: form_helper
INFO - 2018-05-09 11:14:04 --> Form Validation Class Initialized
INFO - 2018-05-09 11:14:04 --> Controller Class Initialized
INFO - 2018-05-09 11:14:04 --> Model Class Initialized
INFO - 2018-05-09 11:14:04 --> Helper loaded: inflector_helper
INFO - 2018-05-09 11:14:04 --> Model Class Initialized
DEBUG - 2018-05-09 11:14:04 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 11:14:04 --> Helper loaded: inflector_helper
INFO - 2018-05-09 11:14:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 11:14:04 --> Model Class Initialized
INFO - 2018-05-09 11:14:04 --> Model Class Initialized
DEBUG - 2018-05-09 11:14:04 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 11:14:04 --> Model Class Initialized
INFO - 2018-05-09 11:14:04 --> Model Class Initialized
INFO - 2018-05-09 11:14:04 --> Model Class Initialized
INFO - 2018-05-09 11:14:04 --> Model Class Initialized
INFO - 2018-05-09 11:14:04 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 11:14:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 11:14:04 --> Model Class Initialized
INFO - 2018-05-09 11:14:04 --> Model Class Initialized
INFO - 2018-05-09 11:14:04 --> Model Class Initialized
INFO - 2018-05-09 11:14:04 --> Model Class Initialized
INFO - 2018-05-09 11:14:04 --> Final output sent to browser
DEBUG - 2018-05-09 11:14:04 --> Total execution time: 0.1061
INFO - 2018-05-09 11:14:04 --> Model Class Initialized
INFO - 2018-05-09 11:14:04 --> Model Class Initialized
INFO - 2018-05-09 11:14:04 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 11:14:04 --> Final output sent to browser
DEBUG - 2018-05-09 11:14:04 --> Total execution time: 0.1102
INFO - 2018-05-09 05:44:05 --> Config Class Initialized
INFO - 2018-05-09 05:44:05 --> Hooks Class Initialized
DEBUG - 2018-05-09 05:44:05 --> UTF-8 Support Enabled
INFO - 2018-05-09 05:44:05 --> Utf8 Class Initialized
INFO - 2018-05-09 05:44:05 --> URI Class Initialized
INFO - 2018-05-09 05:44:05 --> Router Class Initialized
INFO - 2018-05-09 05:44:05 --> Output Class Initialized
INFO - 2018-05-09 05:44:05 --> Security Class Initialized
DEBUG - 2018-05-09 05:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 05:44:05 --> Input Class Initialized
INFO - 2018-05-09 05:44:05 --> Language Class Initialized
INFO - 2018-05-09 05:44:05 --> Language Class Initialized
INFO - 2018-05-09 05:44:05 --> Config Class Initialized
INFO - 2018-05-09 05:44:05 --> Loader Class Initialized
INFO - 2018-05-09 11:14:05 --> Helper loaded: url_helper
INFO - 2018-05-09 11:14:05 --> Helper loaded: notification_helper
INFO - 2018-05-09 11:14:05 --> Helper loaded: settings_helper
INFO - 2018-05-09 11:14:05 --> Helper loaded: permission_helper
INFO - 2018-05-09 11:14:05 --> Helper loaded: users_helper
INFO - 2018-05-09 11:14:05 --> Database Driver Class Initialized
DEBUG - 2018-05-09 11:14:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 11:14:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 11:14:05 --> Helper loaded: form_helper
INFO - 2018-05-09 11:14:05 --> Form Validation Class Initialized
INFO - 2018-05-09 11:14:05 --> Controller Class Initialized
INFO - 2018-05-09 11:14:05 --> Model Class Initialized
INFO - 2018-05-09 11:14:05 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 11:14:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 11:14:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 11:14:05 --> Model Class Initialized
INFO - 2018-05-09 11:14:05 --> Model Class Initialized
INFO - 2018-05-09 11:14:05 --> Model Class Initialized
INFO - 2018-05-09 11:14:05 --> Model Class Initialized
INFO - 2018-05-09 11:14:05 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 11:14:05 --> Final output sent to browser
DEBUG - 2018-05-09 11:14:05 --> Total execution time: 0.1198
INFO - 2018-05-09 05:44:12 --> Config Class Initialized
INFO - 2018-05-09 05:44:12 --> Hooks Class Initialized
DEBUG - 2018-05-09 05:44:12 --> UTF-8 Support Enabled
INFO - 2018-05-09 05:44:12 --> Utf8 Class Initialized
INFO - 2018-05-09 05:44:12 --> URI Class Initialized
INFO - 2018-05-09 05:44:12 --> Router Class Initialized
INFO - 2018-05-09 05:44:12 --> Output Class Initialized
INFO - 2018-05-09 05:44:12 --> Security Class Initialized
DEBUG - 2018-05-09 05:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 05:44:12 --> Input Class Initialized
INFO - 2018-05-09 05:44:12 --> Language Class Initialized
INFO - 2018-05-09 05:44:12 --> Language Class Initialized
INFO - 2018-05-09 05:44:12 --> Config Class Initialized
INFO - 2018-05-09 05:44:12 --> Loader Class Initialized
INFO - 2018-05-09 11:14:12 --> Helper loaded: url_helper
INFO - 2018-05-09 11:14:12 --> Helper loaded: notification_helper
INFO - 2018-05-09 11:14:12 --> Helper loaded: settings_helper
INFO - 2018-05-09 11:14:12 --> Helper loaded: permission_helper
INFO - 2018-05-09 11:14:12 --> Helper loaded: users_helper
INFO - 2018-05-09 11:14:12 --> Database Driver Class Initialized
DEBUG - 2018-05-09 11:14:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 11:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 11:14:12 --> Helper loaded: form_helper
INFO - 2018-05-09 11:14:12 --> Form Validation Class Initialized
INFO - 2018-05-09 11:14:12 --> Controller Class Initialized
INFO - 2018-05-09 11:14:12 --> Model Class Initialized
INFO - 2018-05-09 11:14:12 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 11:14:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 11:14:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 11:14:12 --> Model Class Initialized
INFO - 2018-05-09 11:14:12 --> Model Class Initialized
INFO - 2018-05-09 11:14:12 --> Model Class Initialized
INFO - 2018-05-09 11:14:12 --> Model Class Initialized
INFO - 2018-05-09 11:14:12 --> Model Class Initialized
INFO - 2018-05-09 11:14:12 --> Model Class Initialized
INFO - 2018-05-09 11:14:12 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 11:14:12 --> Final output sent to browser
DEBUG - 2018-05-09 11:14:12 --> Total execution time: 0.1243
INFO - 2018-05-09 05:48:45 --> Config Class Initialized
INFO - 2018-05-09 05:48:45 --> Hooks Class Initialized
INFO - 2018-05-09 05:48:45 --> Config Class Initialized
INFO - 2018-05-09 05:48:45 --> Hooks Class Initialized
INFO - 2018-05-09 05:48:45 --> Config Class Initialized
INFO - 2018-05-09 05:48:45 --> Hooks Class Initialized
DEBUG - 2018-05-09 05:48:45 --> UTF-8 Support Enabled
INFO - 2018-05-09 05:48:45 --> Utf8 Class Initialized
DEBUG - 2018-05-09 05:48:45 --> UTF-8 Support Enabled
INFO - 2018-05-09 05:48:45 --> Utf8 Class Initialized
INFO - 2018-05-09 05:48:45 --> URI Class Initialized
INFO - 2018-05-09 05:48:45 --> URI Class Initialized
DEBUG - 2018-05-09 05:48:45 --> UTF-8 Support Enabled
INFO - 2018-05-09 05:48:45 --> Utf8 Class Initialized
INFO - 2018-05-09 05:48:45 --> Router Class Initialized
INFO - 2018-05-09 05:48:45 --> Router Class Initialized
INFO - 2018-05-09 05:48:45 --> URI Class Initialized
INFO - 2018-05-09 05:48:45 --> Output Class Initialized
INFO - 2018-05-09 05:48:45 --> Output Class Initialized
INFO - 2018-05-09 05:48:45 --> Security Class Initialized
INFO - 2018-05-09 05:48:45 --> Security Class Initialized
DEBUG - 2018-05-09 05:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 05:48:45 --> Input Class Initialized
INFO - 2018-05-09 05:48:45 --> Router Class Initialized
DEBUG - 2018-05-09 05:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 05:48:45 --> Input Class Initialized
INFO - 2018-05-09 05:48:45 --> Language Class Initialized
INFO - 2018-05-09 05:48:45 --> Language Class Initialized
INFO - 2018-05-09 05:48:45 --> Output Class Initialized
INFO - 2018-05-09 05:48:45 --> Security Class Initialized
DEBUG - 2018-05-09 05:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 05:48:45 --> Input Class Initialized
INFO - 2018-05-09 05:48:45 --> Language Class Initialized
INFO - 2018-05-09 05:48:45 --> Language Class Initialized
INFO - 2018-05-09 05:48:45 --> Config Class Initialized
INFO - 2018-05-09 05:48:45 --> Loader Class Initialized
INFO - 2018-05-09 11:18:45 --> Helper loaded: url_helper
INFO - 2018-05-09 05:48:45 --> Language Class Initialized
INFO - 2018-05-09 05:48:45 --> Config Class Initialized
INFO - 2018-05-09 05:48:45 --> Loader Class Initialized
INFO - 2018-05-09 11:18:45 --> Helper loaded: notification_helper
INFO - 2018-05-09 11:18:45 --> Helper loaded: settings_helper
INFO - 2018-05-09 11:18:45 --> Helper loaded: permission_helper
INFO - 2018-05-09 11:18:45 --> Helper loaded: users_helper
INFO - 2018-05-09 11:18:45 --> Helper loaded: url_helper
INFO - 2018-05-09 11:18:45 --> Helper loaded: notification_helper
INFO - 2018-05-09 11:18:45 --> Helper loaded: settings_helper
INFO - 2018-05-09 11:18:45 --> Helper loaded: permission_helper
INFO - 2018-05-09 11:18:45 --> Helper loaded: users_helper
INFO - 2018-05-09 11:18:45 --> Database Driver Class Initialized
INFO - 2018-05-09 11:18:45 --> Database Driver Class Initialized
INFO - 2018-05-09 05:48:45 --> Language Class Initialized
INFO - 2018-05-09 05:48:45 --> Config Class Initialized
INFO - 2018-05-09 05:48:45 --> Loader Class Initialized
INFO - 2018-05-09 11:18:45 --> Helper loaded: url_helper
DEBUG - 2018-05-09 11:18:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 11:18:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 11:18:45 --> Helper loaded: notification_helper
DEBUG - 2018-05-09 11:18:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 11:18:45 --> Helper loaded: settings_helper
INFO - 2018-05-09 11:18:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 11:18:45 --> Helper loaded: permission_helper
INFO - 2018-05-09 11:18:45 --> Helper loaded: users_helper
INFO - 2018-05-09 11:18:45 --> Helper loaded: form_helper
INFO - 2018-05-09 11:18:45 --> Form Validation Class Initialized
INFO - 2018-05-09 11:18:45 --> Controller Class Initialized
INFO - 2018-05-09 11:18:45 --> Helper loaded: form_helper
INFO - 2018-05-09 11:18:45 --> Form Validation Class Initialized
INFO - 2018-05-09 11:18:45 --> Controller Class Initialized
INFO - 2018-05-09 11:18:45 --> Model Class Initialized
INFO - 2018-05-09 11:18:45 --> Model Class Initialized
INFO - 2018-05-09 11:18:45 --> Helper loaded: inflector_helper
INFO - 2018-05-09 11:18:45 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 11:18:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-05-09 11:18:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 11:18:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 11:18:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 11:18:45 --> Model Class Initialized
INFO - 2018-05-09 11:18:45 --> Model Class Initialized
INFO - 2018-05-09 11:18:45 --> Model Class Initialized
INFO - 2018-05-09 11:18:45 --> Model Class Initialized
INFO - 2018-05-09 11:18:45 --> Model Class Initialized
INFO - 2018-05-09 11:18:45 --> Model Class Initialized
INFO - 2018-05-09 11:18:45 --> Model Class Initialized
INFO - 2018-05-09 11:18:45 --> Model Class Initialized
INFO - 2018-05-09 11:18:45 --> Model Class Initialized
INFO - 2018-05-09 11:18:45 --> Model Class Initialized
INFO - 2018-05-09 11:18:45 --> Model Class Initialized
INFO - 2018-05-09 11:18:45 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 11:18:45 --> Model Class Initialized
INFO - 2018-05-09 11:18:45 --> Model Class Initialized
INFO - 2018-05-09 11:18:45 --> Model Class Initialized
INFO - 2018-05-09 11:18:45 --> Model Class Initialized
INFO - 2018-05-09 11:18:45 --> Model Class Initialized
INFO - 2018-05-09 11:18:45 --> Database Driver Class Initialized
INFO - 2018-05-09 11:18:45 --> Model Class Initialized
INFO - 2018-05-09 11:18:45 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 11:18:45 --> Model Class Initialized
INFO - 2018-05-09 11:18:45 --> Final output sent to browser
DEBUG - 2018-05-09 11:18:45 --> Total execution time: 0.1140
INFO - 2018-05-09 11:18:45 --> Final output sent to browser
DEBUG - 2018-05-09 11:18:45 --> Total execution time: 0.1388
DEBUG - 2018-05-09 11:18:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 11:18:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 11:18:45 --> Helper loaded: form_helper
INFO - 2018-05-09 11:18:45 --> Form Validation Class Initialized
INFO - 2018-05-09 11:18:45 --> Controller Class Initialized
INFO - 2018-05-09 11:18:45 --> Model Class Initialized
INFO - 2018-05-09 11:18:45 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 11:18:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 11:18:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 11:18:45 --> Model Class Initialized
INFO - 2018-05-09 11:18:45 --> Model Class Initialized
INFO - 2018-05-09 11:18:45 --> Model Class Initialized
INFO - 2018-05-09 11:18:45 --> Model Class Initialized
INFO - 2018-05-09 11:18:45 --> Model Class Initialized
INFO - 2018-05-09 11:18:45 --> Model Class Initialized
INFO - 2018-05-09 11:18:45 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 11:18:45 --> Model Class Initialized
INFO - 2018-05-09 11:18:45 --> Final output sent to browser
DEBUG - 2018-05-09 11:18:45 --> Total execution time: 0.1553
INFO - 2018-05-09 05:48:46 --> Config Class Initialized
INFO - 2018-05-09 05:48:46 --> Hooks Class Initialized
DEBUG - 2018-05-09 05:48:46 --> UTF-8 Support Enabled
INFO - 2018-05-09 05:48:46 --> Utf8 Class Initialized
INFO - 2018-05-09 05:48:46 --> Config Class Initialized
INFO - 2018-05-09 05:48:46 --> Hooks Class Initialized
INFO - 2018-05-09 05:48:46 --> URI Class Initialized
DEBUG - 2018-05-09 05:48:46 --> UTF-8 Support Enabled
INFO - 2018-05-09 05:48:46 --> Utf8 Class Initialized
INFO - 2018-05-09 05:48:46 --> URI Class Initialized
INFO - 2018-05-09 05:48:46 --> Router Class Initialized
INFO - 2018-05-09 05:48:46 --> Output Class Initialized
INFO - 2018-05-09 05:48:46 --> Router Class Initialized
INFO - 2018-05-09 05:48:46 --> Security Class Initialized
INFO - 2018-05-09 05:48:46 --> Output Class Initialized
DEBUG - 2018-05-09 05:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 05:48:46 --> Input Class Initialized
INFO - 2018-05-09 05:48:46 --> Language Class Initialized
INFO - 2018-05-09 05:48:46 --> Security Class Initialized
DEBUG - 2018-05-09 05:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 05:48:46 --> Input Class Initialized
INFO - 2018-05-09 05:48:46 --> Language Class Initialized
INFO - 2018-05-09 05:48:46 --> Language Class Initialized
INFO - 2018-05-09 05:48:46 --> Config Class Initialized
INFO - 2018-05-09 05:48:46 --> Loader Class Initialized
INFO - 2018-05-09 11:18:46 --> Helper loaded: url_helper
INFO - 2018-05-09 11:18:46 --> Helper loaded: notification_helper
INFO - 2018-05-09 11:18:46 --> Helper loaded: settings_helper
INFO - 2018-05-09 11:18:46 --> Helper loaded: permission_helper
INFO - 2018-05-09 11:18:46 --> Helper loaded: users_helper
INFO - 2018-05-09 05:48:46 --> Language Class Initialized
INFO - 2018-05-09 05:48:46 --> Config Class Initialized
INFO - 2018-05-09 05:48:46 --> Loader Class Initialized
INFO - 2018-05-09 11:18:46 --> Helper loaded: url_helper
INFO - 2018-05-09 11:18:46 --> Helper loaded: notification_helper
INFO - 2018-05-09 11:18:46 --> Helper loaded: settings_helper
INFO - 2018-05-09 11:18:46 --> Helper loaded: permission_helper
INFO - 2018-05-09 11:18:46 --> Helper loaded: users_helper
INFO - 2018-05-09 11:18:46 --> Database Driver Class Initialized
DEBUG - 2018-05-09 11:18:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 11:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 11:18:46 --> Database Driver Class Initialized
INFO - 2018-05-09 11:18:46 --> Helper loaded: form_helper
INFO - 2018-05-09 11:18:46 --> Form Validation Class Initialized
INFO - 2018-05-09 11:18:46 --> Controller Class Initialized
DEBUG - 2018-05-09 11:18:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 11:18:46 --> Model Class Initialized
INFO - 2018-05-09 11:18:46 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 11:18:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 11:18:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 11:18:46 --> Model Class Initialized
INFO - 2018-05-09 11:18:46 --> Model Class Initialized
INFO - 2018-05-09 11:18:46 --> Model Class Initialized
INFO - 2018-05-09 11:18:46 --> Model Class Initialized
INFO - 2018-05-09 11:18:46 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 11:18:46 --> Final output sent to browser
DEBUG - 2018-05-09 11:18:46 --> Total execution time: 0.0994
INFO - 2018-05-09 11:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 11:18:46 --> Helper loaded: form_helper
INFO - 2018-05-09 11:18:46 --> Form Validation Class Initialized
INFO - 2018-05-09 11:18:46 --> Controller Class Initialized
INFO - 2018-05-09 11:18:46 --> Model Class Initialized
INFO - 2018-05-09 11:18:46 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 11:18:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 11:18:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 11:18:46 --> Model Class Initialized
INFO - 2018-05-09 11:18:46 --> Model Class Initialized
INFO - 2018-05-09 11:18:46 --> Model Class Initialized
INFO - 2018-05-09 11:18:46 --> Model Class Initialized
INFO - 2018-05-09 11:18:46 --> Model Class Initialized
INFO - 2018-05-09 11:18:46 --> Model Class Initialized
INFO - 2018-05-09 11:18:46 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 11:18:46 --> Final output sent to browser
DEBUG - 2018-05-09 11:18:46 --> Total execution time: 0.1393
INFO - 2018-05-09 05:56:28 --> Config Class Initialized
INFO - 2018-05-09 05:56:28 --> Hooks Class Initialized
DEBUG - 2018-05-09 05:56:28 --> UTF-8 Support Enabled
INFO - 2018-05-09 05:56:28 --> Utf8 Class Initialized
INFO - 2018-05-09 05:56:28 --> URI Class Initialized
INFO - 2018-05-09 05:56:28 --> Router Class Initialized
INFO - 2018-05-09 05:56:28 --> Output Class Initialized
INFO - 2018-05-09 05:56:28 --> Security Class Initialized
DEBUG - 2018-05-09 05:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 05:56:29 --> Input Class Initialized
INFO - 2018-05-09 05:56:29 --> Language Class Initialized
INFO - 2018-05-09 05:56:29 --> Language Class Initialized
INFO - 2018-05-09 05:56:29 --> Config Class Initialized
INFO - 2018-05-09 05:56:29 --> Loader Class Initialized
INFO - 2018-05-09 11:26:29 --> Helper loaded: url_helper
INFO - 2018-05-09 11:26:29 --> Helper loaded: notification_helper
INFO - 2018-05-09 11:26:29 --> Helper loaded: settings_helper
INFO - 2018-05-09 11:26:29 --> Helper loaded: permission_helper
INFO - 2018-05-09 11:26:29 --> Helper loaded: users_helper
INFO - 2018-05-09 11:26:29 --> Database Driver Class Initialized
DEBUG - 2018-05-09 11:26:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 11:26:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 11:26:29 --> Helper loaded: form_helper
INFO - 2018-05-09 11:26:29 --> Form Validation Class Initialized
INFO - 2018-05-09 11:26:29 --> Controller Class Initialized
INFO - 2018-05-09 11:26:29 --> Model Class Initialized
INFO - 2018-05-09 11:26:29 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 11:26:29 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 11:26:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 11:26:29 --> Model Class Initialized
INFO - 2018-05-09 11:26:29 --> Model Class Initialized
INFO - 2018-05-09 11:26:29 --> Model Class Initialized
INFO - 2018-05-09 11:26:29 --> Model Class Initialized
INFO - 2018-05-09 11:26:29 --> Model Class Initialized
INFO - 2018-05-09 11:26:29 --> Model Class Initialized
INFO - 2018-05-09 11:26:29 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 11:26:29 --> Final output sent to browser
DEBUG - 2018-05-09 11:26:29 --> Total execution time: 0.1150
INFO - 2018-05-09 05:56:32 --> Config Class Initialized
INFO - 2018-05-09 05:56:32 --> Hooks Class Initialized
DEBUG - 2018-05-09 05:56:32 --> UTF-8 Support Enabled
INFO - 2018-05-09 05:56:32 --> Utf8 Class Initialized
INFO - 2018-05-09 05:56:32 --> URI Class Initialized
INFO - 2018-05-09 05:56:32 --> Router Class Initialized
INFO - 2018-05-09 05:56:32 --> Output Class Initialized
INFO - 2018-05-09 05:56:32 --> Security Class Initialized
DEBUG - 2018-05-09 05:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 05:56:32 --> Input Class Initialized
INFO - 2018-05-09 05:56:32 --> Language Class Initialized
INFO - 2018-05-09 05:56:32 --> Language Class Initialized
INFO - 2018-05-09 05:56:32 --> Config Class Initialized
INFO - 2018-05-09 05:56:32 --> Loader Class Initialized
INFO - 2018-05-09 11:26:32 --> Helper loaded: url_helper
INFO - 2018-05-09 11:26:32 --> Helper loaded: notification_helper
INFO - 2018-05-09 11:26:32 --> Helper loaded: settings_helper
INFO - 2018-05-09 11:26:32 --> Helper loaded: permission_helper
INFO - 2018-05-09 11:26:32 --> Helper loaded: users_helper
INFO - 2018-05-09 11:26:32 --> Database Driver Class Initialized
DEBUG - 2018-05-09 11:26:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 11:26:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 11:26:32 --> Helper loaded: form_helper
INFO - 2018-05-09 11:26:32 --> Form Validation Class Initialized
INFO - 2018-05-09 11:26:32 --> Controller Class Initialized
INFO - 2018-05-09 11:26:32 --> Model Class Initialized
INFO - 2018-05-09 11:26:32 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 11:26:32 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 11:26:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 11:26:32 --> Model Class Initialized
INFO - 2018-05-09 11:26:32 --> Model Class Initialized
INFO - 2018-05-09 11:26:32 --> Model Class Initialized
INFO - 2018-05-09 11:26:32 --> Model Class Initialized
INFO - 2018-05-09 11:26:32 --> Model Class Initialized
INFO - 2018-05-09 11:26:32 --> Model Class Initialized
INFO - 2018-05-09 11:26:32 --> Model Class Initialized
INFO - 2018-05-09 11:26:32 --> Model Class Initialized
INFO - 2018-05-09 11:26:32 --> Model Class Initialized
INFO - 2018-05-09 11:26:32 --> Model Class Initialized
INFO - 2018-05-09 11:26:32 --> Model Class Initialized
INFO - 2018-05-09 11:26:32 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 11:26:32 --> Model Class Initialized
INFO - 2018-05-09 11:26:32 --> Final output sent to browser
DEBUG - 2018-05-09 11:26:32 --> Total execution time: 0.1117
INFO - 2018-05-09 05:56:34 --> Config Class Initialized
INFO - 2018-05-09 05:56:34 --> Hooks Class Initialized
DEBUG - 2018-05-09 05:56:34 --> UTF-8 Support Enabled
INFO - 2018-05-09 05:56:34 --> Utf8 Class Initialized
INFO - 2018-05-09 05:56:34 --> URI Class Initialized
INFO - 2018-05-09 05:56:34 --> Router Class Initialized
INFO - 2018-05-09 05:56:34 --> Output Class Initialized
INFO - 2018-05-09 05:56:34 --> Security Class Initialized
DEBUG - 2018-05-09 05:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 05:56:34 --> Input Class Initialized
INFO - 2018-05-09 05:56:34 --> Language Class Initialized
INFO - 2018-05-09 05:56:34 --> Language Class Initialized
INFO - 2018-05-09 05:56:34 --> Config Class Initialized
INFO - 2018-05-09 05:56:34 --> Loader Class Initialized
INFO - 2018-05-09 11:26:34 --> Helper loaded: url_helper
INFO - 2018-05-09 11:26:34 --> Helper loaded: notification_helper
INFO - 2018-05-09 11:26:34 --> Helper loaded: settings_helper
INFO - 2018-05-09 11:26:34 --> Helper loaded: permission_helper
INFO - 2018-05-09 11:26:34 --> Helper loaded: users_helper
INFO - 2018-05-09 11:26:34 --> Database Driver Class Initialized
DEBUG - 2018-05-09 11:26:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 11:26:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 11:26:34 --> Helper loaded: form_helper
INFO - 2018-05-09 11:26:34 --> Form Validation Class Initialized
INFO - 2018-05-09 11:26:34 --> Controller Class Initialized
INFO - 2018-05-09 11:26:34 --> Model Class Initialized
INFO - 2018-05-09 11:26:34 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 11:26:34 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 11:26:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 11:26:34 --> Model Class Initialized
INFO - 2018-05-09 11:26:34 --> Model Class Initialized
INFO - 2018-05-09 11:26:34 --> Model Class Initialized
INFO - 2018-05-09 11:26:34 --> Model Class Initialized
INFO - 2018-05-09 11:26:34 --> Final output sent to browser
DEBUG - 2018-05-09 11:26:34 --> Total execution time: 0.1012
INFO - 2018-05-09 05:56:37 --> Config Class Initialized
INFO - 2018-05-09 05:56:37 --> Hooks Class Initialized
DEBUG - 2018-05-09 05:56:37 --> UTF-8 Support Enabled
INFO - 2018-05-09 05:56:37 --> Utf8 Class Initialized
INFO - 2018-05-09 05:56:37 --> URI Class Initialized
INFO - 2018-05-09 05:56:37 --> Router Class Initialized
INFO - 2018-05-09 05:56:37 --> Output Class Initialized
INFO - 2018-05-09 05:56:37 --> Security Class Initialized
DEBUG - 2018-05-09 05:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 05:56:37 --> Input Class Initialized
INFO - 2018-05-09 05:56:37 --> Language Class Initialized
INFO - 2018-05-09 05:56:37 --> Language Class Initialized
INFO - 2018-05-09 05:56:37 --> Config Class Initialized
INFO - 2018-05-09 05:56:37 --> Loader Class Initialized
INFO - 2018-05-09 11:26:37 --> Helper loaded: url_helper
INFO - 2018-05-09 11:26:37 --> Helper loaded: notification_helper
INFO - 2018-05-09 11:26:37 --> Helper loaded: settings_helper
INFO - 2018-05-09 11:26:37 --> Helper loaded: permission_helper
INFO - 2018-05-09 11:26:37 --> Helper loaded: users_helper
INFO - 2018-05-09 11:26:37 --> Database Driver Class Initialized
DEBUG - 2018-05-09 11:26:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 11:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 11:26:37 --> Helper loaded: form_helper
INFO - 2018-05-09 11:26:37 --> Form Validation Class Initialized
INFO - 2018-05-09 11:26:37 --> Controller Class Initialized
INFO - 2018-05-09 11:26:37 --> Model Class Initialized
INFO - 2018-05-09 11:26:37 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 11:26:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 11:26:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 11:26:37 --> Model Class Initialized
INFO - 2018-05-09 11:26:37 --> Model Class Initialized
INFO - 2018-05-09 11:26:37 --> Model Class Initialized
INFO - 2018-05-09 11:26:37 --> Model Class Initialized
INFO - 2018-05-09 11:26:37 --> Model Class Initialized
INFO - 2018-05-09 11:26:37 --> Model Class Initialized
INFO - 2018-05-09 11:26:37 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-05-09 11:26:37 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 800
INFO - 2018-05-09 11:26:37 --> Final output sent to browser
DEBUG - 2018-05-09 11:26:37 --> Total execution time: 0.1091
INFO - 2018-05-09 05:57:02 --> Config Class Initialized
INFO - 2018-05-09 05:57:02 --> Hooks Class Initialized
DEBUG - 2018-05-09 05:57:02 --> UTF-8 Support Enabled
INFO - 2018-05-09 05:57:02 --> Utf8 Class Initialized
INFO - 2018-05-09 05:57:02 --> URI Class Initialized
INFO - 2018-05-09 05:57:02 --> Router Class Initialized
INFO - 2018-05-09 05:57:02 --> Output Class Initialized
INFO - 2018-05-09 05:57:02 --> Security Class Initialized
DEBUG - 2018-05-09 05:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 05:57:02 --> Input Class Initialized
INFO - 2018-05-09 05:57:02 --> Language Class Initialized
INFO - 2018-05-09 05:57:02 --> Language Class Initialized
INFO - 2018-05-09 05:57:02 --> Config Class Initialized
INFO - 2018-05-09 05:57:02 --> Loader Class Initialized
INFO - 2018-05-09 11:27:02 --> Helper loaded: url_helper
INFO - 2018-05-09 11:27:02 --> Helper loaded: notification_helper
INFO - 2018-05-09 11:27:02 --> Helper loaded: settings_helper
INFO - 2018-05-09 11:27:02 --> Helper loaded: permission_helper
INFO - 2018-05-09 11:27:02 --> Helper loaded: users_helper
INFO - 2018-05-09 11:27:02 --> Database Driver Class Initialized
DEBUG - 2018-05-09 11:27:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 11:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 11:27:02 --> Helper loaded: form_helper
INFO - 2018-05-09 11:27:02 --> Form Validation Class Initialized
INFO - 2018-05-09 11:27:02 --> Controller Class Initialized
INFO - 2018-05-09 11:27:02 --> Model Class Initialized
INFO - 2018-05-09 11:27:02 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 11:27:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 11:27:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 11:27:02 --> Model Class Initialized
INFO - 2018-05-09 11:27:02 --> Model Class Initialized
INFO - 2018-05-09 11:27:02 --> Model Class Initialized
INFO - 2018-05-09 11:27:02 --> Model Class Initialized
INFO - 2018-05-09 11:27:02 --> Model Class Initialized
INFO - 2018-05-09 11:27:02 --> Model Class Initialized
INFO - 2018-05-09 11:27:02 --> Model Class Initialized
INFO - 2018-05-09 11:27:02 --> Model Class Initialized
INFO - 2018-05-09 11:27:02 --> Model Class Initialized
INFO - 2018-05-09 11:27:02 --> Model Class Initialized
INFO - 2018-05-09 11:27:02 --> Model Class Initialized
INFO - 2018-05-09 11:27:02 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 11:27:02 --> Model Class Initialized
INFO - 2018-05-09 11:27:02 --> Final output sent to browser
DEBUG - 2018-05-09 11:27:02 --> Total execution time: 0.1431
INFO - 2018-05-09 05:57:03 --> Config Class Initialized
INFO - 2018-05-09 05:57:03 --> Hooks Class Initialized
DEBUG - 2018-05-09 05:57:03 --> UTF-8 Support Enabled
INFO - 2018-05-09 05:57:03 --> Utf8 Class Initialized
INFO - 2018-05-09 05:57:03 --> URI Class Initialized
INFO - 2018-05-09 05:57:03 --> Router Class Initialized
INFO - 2018-05-09 05:57:03 --> Output Class Initialized
INFO - 2018-05-09 05:57:03 --> Security Class Initialized
DEBUG - 2018-05-09 05:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 05:57:03 --> Input Class Initialized
INFO - 2018-05-09 05:57:03 --> Language Class Initialized
INFO - 2018-05-09 05:57:03 --> Language Class Initialized
INFO - 2018-05-09 05:57:03 --> Config Class Initialized
INFO - 2018-05-09 05:57:03 --> Loader Class Initialized
INFO - 2018-05-09 11:27:03 --> Helper loaded: url_helper
INFO - 2018-05-09 11:27:03 --> Helper loaded: notification_helper
INFO - 2018-05-09 11:27:03 --> Helper loaded: settings_helper
INFO - 2018-05-09 11:27:03 --> Helper loaded: permission_helper
INFO - 2018-05-09 11:27:03 --> Helper loaded: users_helper
INFO - 2018-05-09 11:27:03 --> Database Driver Class Initialized
DEBUG - 2018-05-09 11:27:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 11:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 11:27:03 --> Helper loaded: form_helper
INFO - 2018-05-09 11:27:03 --> Form Validation Class Initialized
INFO - 2018-05-09 11:27:03 --> Controller Class Initialized
INFO - 2018-05-09 11:27:03 --> Model Class Initialized
INFO - 2018-05-09 11:27:03 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 11:27:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 11:27:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 11:27:03 --> Model Class Initialized
INFO - 2018-05-09 11:27:03 --> Model Class Initialized
INFO - 2018-05-09 11:27:03 --> Model Class Initialized
INFO - 2018-05-09 11:27:03 --> Model Class Initialized
INFO - 2018-05-09 11:27:03 --> Model Class Initialized
INFO - 2018-05-09 11:27:03 --> Model Class Initialized
INFO - 2018-05-09 11:27:03 --> Model Class Initialized
INFO - 2018-05-09 11:27:03 --> Model Class Initialized
INFO - 2018-05-09 11:27:03 --> Model Class Initialized
INFO - 2018-05-09 11:27:03 --> Model Class Initialized
INFO - 2018-05-09 11:27:03 --> Model Class Initialized
INFO - 2018-05-09 11:27:03 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 11:27:03 --> Model Class Initialized
INFO - 2018-05-09 11:27:03 --> Final output sent to browser
DEBUG - 2018-05-09 11:27:03 --> Total execution time: 0.1166
INFO - 2018-05-09 05:57:06 --> Config Class Initialized
INFO - 2018-05-09 05:57:06 --> Hooks Class Initialized
DEBUG - 2018-05-09 05:57:06 --> UTF-8 Support Enabled
INFO - 2018-05-09 05:57:06 --> Utf8 Class Initialized
INFO - 2018-05-09 05:57:06 --> URI Class Initialized
INFO - 2018-05-09 05:57:06 --> Router Class Initialized
INFO - 2018-05-09 05:57:06 --> Output Class Initialized
INFO - 2018-05-09 05:57:06 --> Security Class Initialized
DEBUG - 2018-05-09 05:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 05:57:06 --> Input Class Initialized
INFO - 2018-05-09 05:57:06 --> Language Class Initialized
INFO - 2018-05-09 05:57:06 --> Language Class Initialized
INFO - 2018-05-09 05:57:06 --> Config Class Initialized
INFO - 2018-05-09 05:57:06 --> Loader Class Initialized
INFO - 2018-05-09 11:27:06 --> Helper loaded: url_helper
INFO - 2018-05-09 11:27:06 --> Helper loaded: notification_helper
INFO - 2018-05-09 11:27:06 --> Helper loaded: settings_helper
INFO - 2018-05-09 11:27:06 --> Helper loaded: permission_helper
INFO - 2018-05-09 11:27:06 --> Helper loaded: users_helper
INFO - 2018-05-09 11:27:06 --> Database Driver Class Initialized
DEBUG - 2018-05-09 11:27:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 11:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 11:27:06 --> Helper loaded: form_helper
INFO - 2018-05-09 11:27:06 --> Form Validation Class Initialized
INFO - 2018-05-09 11:27:06 --> Controller Class Initialized
INFO - 2018-05-09 11:27:06 --> Model Class Initialized
INFO - 2018-05-09 11:27:06 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 11:27:06 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 11:27:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 11:27:06 --> Model Class Initialized
INFO - 2018-05-09 11:27:06 --> Model Class Initialized
INFO - 2018-05-09 11:27:06 --> Model Class Initialized
INFO - 2018-05-09 11:27:06 --> Model Class Initialized
INFO - 2018-05-09 11:27:06 --> Model Class Initialized
INFO - 2018-05-09 11:27:06 --> Model Class Initialized
INFO - 2018-05-09 11:27:06 --> Model Class Initialized
INFO - 2018-05-09 11:27:06 --> Model Class Initialized
INFO - 2018-05-09 11:27:06 --> Model Class Initialized
INFO - 2018-05-09 11:27:06 --> Model Class Initialized
INFO - 2018-05-09 11:27:06 --> Model Class Initialized
INFO - 2018-05-09 11:27:06 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 11:27:06 --> Model Class Initialized
INFO - 2018-05-09 11:27:06 --> Final output sent to browser
DEBUG - 2018-05-09 11:27:06 --> Total execution time: 0.1124
INFO - 2018-05-09 05:57:07 --> Config Class Initialized
INFO - 2018-05-09 05:57:07 --> Hooks Class Initialized
DEBUG - 2018-05-09 05:57:07 --> UTF-8 Support Enabled
INFO - 2018-05-09 05:57:07 --> Utf8 Class Initialized
INFO - 2018-05-09 05:57:07 --> URI Class Initialized
INFO - 2018-05-09 05:57:07 --> Router Class Initialized
INFO - 2018-05-09 05:57:07 --> Output Class Initialized
INFO - 2018-05-09 05:57:07 --> Security Class Initialized
DEBUG - 2018-05-09 05:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 05:57:07 --> Input Class Initialized
INFO - 2018-05-09 05:57:07 --> Language Class Initialized
INFO - 2018-05-09 05:57:07 --> Language Class Initialized
INFO - 2018-05-09 05:57:07 --> Config Class Initialized
INFO - 2018-05-09 05:57:07 --> Loader Class Initialized
INFO - 2018-05-09 11:27:07 --> Helper loaded: url_helper
INFO - 2018-05-09 11:27:07 --> Helper loaded: notification_helper
INFO - 2018-05-09 11:27:07 --> Helper loaded: settings_helper
INFO - 2018-05-09 11:27:07 --> Helper loaded: permission_helper
INFO - 2018-05-09 11:27:07 --> Helper loaded: users_helper
INFO - 2018-05-09 11:27:07 --> Database Driver Class Initialized
DEBUG - 2018-05-09 11:27:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 11:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 11:27:07 --> Helper loaded: form_helper
INFO - 2018-05-09 11:27:07 --> Form Validation Class Initialized
INFO - 2018-05-09 11:27:07 --> Controller Class Initialized
INFO - 2018-05-09 11:27:07 --> Model Class Initialized
INFO - 2018-05-09 11:27:07 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 11:27:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 11:27:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 11:27:07 --> Model Class Initialized
INFO - 2018-05-09 11:27:07 --> Model Class Initialized
INFO - 2018-05-09 11:27:07 --> Model Class Initialized
INFO - 2018-05-09 11:27:07 --> Model Class Initialized
INFO - 2018-05-09 11:27:07 --> Model Class Initialized
INFO - 2018-05-09 11:27:07 --> Model Class Initialized
INFO - 2018-05-09 11:27:07 --> Model Class Initialized
INFO - 2018-05-09 11:27:07 --> Model Class Initialized
INFO - 2018-05-09 11:27:07 --> Model Class Initialized
INFO - 2018-05-09 11:27:07 --> Model Class Initialized
INFO - 2018-05-09 11:27:07 --> Model Class Initialized
INFO - 2018-05-09 11:27:07 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 11:27:07 --> Final output sent to browser
DEBUG - 2018-05-09 11:27:07 --> Total execution time: 0.1121
INFO - 2018-05-09 05:57:08 --> Config Class Initialized
INFO - 2018-05-09 05:57:08 --> Hooks Class Initialized
DEBUG - 2018-05-09 05:57:08 --> UTF-8 Support Enabled
INFO - 2018-05-09 05:57:08 --> Utf8 Class Initialized
INFO - 2018-05-09 05:57:08 --> URI Class Initialized
INFO - 2018-05-09 05:57:08 --> Router Class Initialized
INFO - 2018-05-09 05:57:08 --> Output Class Initialized
INFO - 2018-05-09 05:57:08 --> Security Class Initialized
DEBUG - 2018-05-09 05:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 05:57:08 --> Input Class Initialized
INFO - 2018-05-09 05:57:08 --> Language Class Initialized
INFO - 2018-05-09 05:57:08 --> Language Class Initialized
INFO - 2018-05-09 05:57:08 --> Config Class Initialized
INFO - 2018-05-09 05:57:08 --> Loader Class Initialized
INFO - 2018-05-09 11:27:08 --> Helper loaded: url_helper
INFO - 2018-05-09 11:27:08 --> Helper loaded: notification_helper
INFO - 2018-05-09 11:27:08 --> Helper loaded: settings_helper
INFO - 2018-05-09 11:27:08 --> Helper loaded: permission_helper
INFO - 2018-05-09 11:27:08 --> Helper loaded: users_helper
INFO - 2018-05-09 11:27:08 --> Database Driver Class Initialized
DEBUG - 2018-05-09 11:27:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 11:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 11:27:08 --> Helper loaded: form_helper
INFO - 2018-05-09 11:27:08 --> Form Validation Class Initialized
INFO - 2018-05-09 11:27:08 --> Controller Class Initialized
INFO - 2018-05-09 11:27:09 --> Model Class Initialized
INFO - 2018-05-09 11:27:09 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 11:27:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 11:27:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 11:27:09 --> Model Class Initialized
INFO - 2018-05-09 11:27:09 --> Model Class Initialized
INFO - 2018-05-09 11:27:09 --> Model Class Initialized
INFO - 2018-05-09 11:27:09 --> Model Class Initialized
INFO - 2018-05-09 11:27:09 --> Model Class Initialized
INFO - 2018-05-09 11:27:09 --> Model Class Initialized
INFO - 2018-05-09 11:27:09 --> Model Class Initialized
INFO - 2018-05-09 11:27:09 --> Model Class Initialized
INFO - 2018-05-09 11:27:09 --> Model Class Initialized
INFO - 2018-05-09 11:27:09 --> Model Class Initialized
INFO - 2018-05-09 11:27:09 --> Model Class Initialized
INFO - 2018-05-09 11:27:09 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 11:27:09 --> Model Class Initialized
INFO - 2018-05-09 11:27:09 --> Final output sent to browser
DEBUG - 2018-05-09 11:27:09 --> Total execution time: 0.1374
INFO - 2018-05-09 05:57:14 --> Config Class Initialized
INFO - 2018-05-09 05:57:14 --> Hooks Class Initialized
DEBUG - 2018-05-09 05:57:14 --> UTF-8 Support Enabled
INFO - 2018-05-09 05:57:14 --> Utf8 Class Initialized
INFO - 2018-05-09 05:57:14 --> URI Class Initialized
INFO - 2018-05-09 05:57:14 --> Router Class Initialized
INFO - 2018-05-09 05:57:14 --> Output Class Initialized
INFO - 2018-05-09 05:57:14 --> Security Class Initialized
DEBUG - 2018-05-09 05:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 05:57:14 --> Input Class Initialized
INFO - 2018-05-09 05:57:14 --> Language Class Initialized
INFO - 2018-05-09 05:57:14 --> Language Class Initialized
INFO - 2018-05-09 05:57:14 --> Config Class Initialized
INFO - 2018-05-09 05:57:14 --> Loader Class Initialized
INFO - 2018-05-09 11:27:14 --> Helper loaded: url_helper
INFO - 2018-05-09 11:27:14 --> Helper loaded: notification_helper
INFO - 2018-05-09 11:27:14 --> Helper loaded: settings_helper
INFO - 2018-05-09 11:27:14 --> Helper loaded: permission_helper
INFO - 2018-05-09 11:27:14 --> Helper loaded: users_helper
INFO - 2018-05-09 11:27:14 --> Database Driver Class Initialized
DEBUG - 2018-05-09 11:27:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 11:27:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 11:27:14 --> Helper loaded: form_helper
INFO - 2018-05-09 11:27:14 --> Form Validation Class Initialized
INFO - 2018-05-09 11:27:14 --> Controller Class Initialized
INFO - 2018-05-09 11:27:14 --> Model Class Initialized
INFO - 2018-05-09 11:27:14 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 11:27:14 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 11:27:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 11:27:14 --> Model Class Initialized
INFO - 2018-05-09 11:27:14 --> Model Class Initialized
INFO - 2018-05-09 11:27:14 --> Model Class Initialized
INFO - 2018-05-09 11:27:14 --> Model Class Initialized
INFO - 2018-05-09 11:27:14 --> Model Class Initialized
INFO - 2018-05-09 11:27:14 --> Model Class Initialized
INFO - 2018-05-09 11:27:14 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-05-09 11:27:14 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 800
ERROR - 2018-05-09 11:27:14 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 810
INFO - 2018-05-09 11:27:14 --> Final output sent to browser
DEBUG - 2018-05-09 11:27:14 --> Total execution time: 0.0994
INFO - 2018-05-09 05:57:34 --> Config Class Initialized
INFO - 2018-05-09 05:57:34 --> Hooks Class Initialized
DEBUG - 2018-05-09 05:57:34 --> UTF-8 Support Enabled
INFO - 2018-05-09 05:57:34 --> Utf8 Class Initialized
INFO - 2018-05-09 05:57:34 --> URI Class Initialized
INFO - 2018-05-09 05:57:34 --> Router Class Initialized
INFO - 2018-05-09 05:57:34 --> Output Class Initialized
INFO - 2018-05-09 05:57:34 --> Security Class Initialized
DEBUG - 2018-05-09 05:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 05:57:34 --> Input Class Initialized
INFO - 2018-05-09 05:57:34 --> Language Class Initialized
INFO - 2018-05-09 05:57:34 --> Language Class Initialized
INFO - 2018-05-09 05:57:34 --> Config Class Initialized
INFO - 2018-05-09 05:57:34 --> Loader Class Initialized
INFO - 2018-05-09 11:27:34 --> Helper loaded: url_helper
INFO - 2018-05-09 11:27:34 --> Helper loaded: notification_helper
INFO - 2018-05-09 11:27:34 --> Helper loaded: settings_helper
INFO - 2018-05-09 11:27:34 --> Helper loaded: permission_helper
INFO - 2018-05-09 11:27:34 --> Helper loaded: users_helper
INFO - 2018-05-09 11:27:34 --> Database Driver Class Initialized
DEBUG - 2018-05-09 11:27:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 11:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 11:27:34 --> Helper loaded: form_helper
INFO - 2018-05-09 11:27:34 --> Form Validation Class Initialized
INFO - 2018-05-09 11:27:34 --> Controller Class Initialized
INFO - 2018-05-09 11:27:34 --> Model Class Initialized
INFO - 2018-05-09 11:27:34 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 11:27:34 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 11:27:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 11:27:34 --> Model Class Initialized
INFO - 2018-05-09 11:27:34 --> Model Class Initialized
INFO - 2018-05-09 11:27:34 --> Model Class Initialized
INFO - 2018-05-09 11:27:34 --> Model Class Initialized
INFO - 2018-05-09 11:27:34 --> Model Class Initialized
INFO - 2018-05-09 11:27:34 --> Model Class Initialized
INFO - 2018-05-09 11:27:34 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 11:27:34 --> Final output sent to browser
DEBUG - 2018-05-09 11:27:34 --> Total execution time: 0.1346
INFO - 2018-05-09 05:57:41 --> Config Class Initialized
INFO - 2018-05-09 05:57:41 --> Hooks Class Initialized
DEBUG - 2018-05-09 05:57:41 --> UTF-8 Support Enabled
INFO - 2018-05-09 05:57:41 --> Utf8 Class Initialized
INFO - 2018-05-09 05:57:41 --> URI Class Initialized
INFO - 2018-05-09 05:57:41 --> Router Class Initialized
INFO - 2018-05-09 05:57:41 --> Output Class Initialized
INFO - 2018-05-09 05:57:41 --> Security Class Initialized
DEBUG - 2018-05-09 05:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 05:57:41 --> Input Class Initialized
INFO - 2018-05-09 05:57:41 --> Language Class Initialized
INFO - 2018-05-09 05:57:41 --> Config Class Initialized
INFO - 2018-05-09 05:57:41 --> Hooks Class Initialized
DEBUG - 2018-05-09 05:57:41 --> UTF-8 Support Enabled
INFO - 2018-05-09 05:57:41 --> Utf8 Class Initialized
INFO - 2018-05-09 05:57:41 --> URI Class Initialized
INFO - 2018-05-09 05:57:41 --> Router Class Initialized
INFO - 2018-05-09 05:57:41 --> Output Class Initialized
INFO - 2018-05-09 05:57:41 --> Language Class Initialized
INFO - 2018-05-09 05:57:41 --> Config Class Initialized
INFO - 2018-05-09 05:57:41 --> Loader Class Initialized
INFO - 2018-05-09 05:57:41 --> Security Class Initialized
INFO - 2018-05-09 11:27:41 --> Helper loaded: url_helper
INFO - 2018-05-09 11:27:41 --> Helper loaded: notification_helper
INFO - 2018-05-09 11:27:41 --> Helper loaded: settings_helper
INFO - 2018-05-09 11:27:41 --> Helper loaded: permission_helper
DEBUG - 2018-05-09 05:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 05:57:41 --> Input Class Initialized
INFO - 2018-05-09 11:27:41 --> Helper loaded: users_helper
INFO - 2018-05-09 05:57:41 --> Language Class Initialized
INFO - 2018-05-09 11:27:41 --> Database Driver Class Initialized
DEBUG - 2018-05-09 11:27:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 11:27:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 05:57:41 --> Language Class Initialized
INFO - 2018-05-09 05:57:41 --> Config Class Initialized
INFO - 2018-05-09 05:57:41 --> Loader Class Initialized
INFO - 2018-05-09 11:27:41 --> Helper loaded: url_helper
INFO - 2018-05-09 11:27:41 --> Helper loaded: notification_helper
INFO - 2018-05-09 11:27:41 --> Helper loaded: settings_helper
INFO - 2018-05-09 11:27:41 --> Helper loaded: permission_helper
INFO - 2018-05-09 11:27:41 --> Helper loaded: users_helper
INFO - 2018-05-09 11:27:41 --> Helper loaded: form_helper
INFO - 2018-05-09 11:27:41 --> Form Validation Class Initialized
INFO - 2018-05-09 11:27:41 --> Controller Class Initialized
INFO - 2018-05-09 11:27:41 --> Model Class Initialized
INFO - 2018-05-09 11:27:41 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 11:27:41 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 11:27:41 --> Database Driver Class Initialized
INFO - 2018-05-09 11:27:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 11:27:41 --> Model Class Initialized
INFO - 2018-05-09 11:27:41 --> Model Class Initialized
INFO - 2018-05-09 11:27:41 --> Model Class Initialized
INFO - 2018-05-09 11:27:41 --> Model Class Initialized
INFO - 2018-05-09 11:27:41 --> Model Class Initialized
INFO - 2018-05-09 11:27:41 --> Model Class Initialized
INFO - 2018-05-09 11:27:41 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-05-09 11:27:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 11:27:41 --> Model Class Initialized
INFO - 2018-05-09 11:27:41 --> Final output sent to browser
DEBUG - 2018-05-09 11:27:41 --> Total execution time: 0.1163
INFO - 2018-05-09 11:27:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 11:27:41 --> Helper loaded: form_helper
INFO - 2018-05-09 11:27:41 --> Form Validation Class Initialized
INFO - 2018-05-09 11:27:41 --> Controller Class Initialized
INFO - 2018-05-09 11:27:41 --> Model Class Initialized
INFO - 2018-05-09 11:27:41 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 11:27:41 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 11:27:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 11:27:41 --> Model Class Initialized
INFO - 2018-05-09 11:27:41 --> Model Class Initialized
INFO - 2018-05-09 11:27:41 --> Model Class Initialized
INFO - 2018-05-09 11:27:41 --> Model Class Initialized
INFO - 2018-05-09 11:27:41 --> Model Class Initialized
INFO - 2018-05-09 11:27:41 --> Model Class Initialized
INFO - 2018-05-09 11:27:41 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 11:27:41 --> Final output sent to browser
DEBUG - 2018-05-09 11:27:41 --> Total execution time: 0.1430
INFO - 2018-05-09 05:57:42 --> Config Class Initialized
INFO - 2018-05-09 05:57:42 --> Hooks Class Initialized
DEBUG - 2018-05-09 05:57:42 --> UTF-8 Support Enabled
INFO - 2018-05-09 05:57:42 --> Utf8 Class Initialized
INFO - 2018-05-09 05:57:42 --> URI Class Initialized
INFO - 2018-05-09 05:57:42 --> Router Class Initialized
INFO - 2018-05-09 05:57:42 --> Output Class Initialized
INFO - 2018-05-09 05:57:42 --> Security Class Initialized
DEBUG - 2018-05-09 05:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 05:57:42 --> Input Class Initialized
INFO - 2018-05-09 05:57:42 --> Language Class Initialized
INFO - 2018-05-09 05:57:42 --> Language Class Initialized
INFO - 2018-05-09 05:57:42 --> Config Class Initialized
INFO - 2018-05-09 05:57:42 --> Loader Class Initialized
INFO - 2018-05-09 11:27:42 --> Helper loaded: url_helper
INFO - 2018-05-09 11:27:42 --> Helper loaded: notification_helper
INFO - 2018-05-09 11:27:42 --> Helper loaded: settings_helper
INFO - 2018-05-09 11:27:42 --> Helper loaded: permission_helper
INFO - 2018-05-09 11:27:42 --> Helper loaded: users_helper
INFO - 2018-05-09 11:27:42 --> Database Driver Class Initialized
DEBUG - 2018-05-09 11:27:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 11:27:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 11:27:42 --> Helper loaded: form_helper
INFO - 2018-05-09 11:27:42 --> Form Validation Class Initialized
INFO - 2018-05-09 11:27:42 --> Controller Class Initialized
INFO - 2018-05-09 11:27:42 --> Model Class Initialized
INFO - 2018-05-09 11:27:42 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 11:27:42 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 11:27:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 11:27:42 --> Model Class Initialized
INFO - 2018-05-09 11:27:42 --> Model Class Initialized
INFO - 2018-05-09 11:27:42 --> Model Class Initialized
INFO - 2018-05-09 11:27:42 --> Model Class Initialized
INFO - 2018-05-09 11:27:42 --> Model Class Initialized
INFO - 2018-05-09 11:27:42 --> Model Class Initialized
INFO - 2018-05-09 11:27:42 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 11:27:42 --> Final output sent to browser
DEBUG - 2018-05-09 11:27:42 --> Total execution time: 0.1102
INFO - 2018-05-09 05:57:43 --> Config Class Initialized
INFO - 2018-05-09 05:57:43 --> Hooks Class Initialized
DEBUG - 2018-05-09 05:57:43 --> UTF-8 Support Enabled
INFO - 2018-05-09 05:57:43 --> Utf8 Class Initialized
INFO - 2018-05-09 05:57:43 --> URI Class Initialized
INFO - 2018-05-09 05:57:43 --> Router Class Initialized
INFO - 2018-05-09 05:57:43 --> Output Class Initialized
INFO - 2018-05-09 05:57:43 --> Security Class Initialized
DEBUG - 2018-05-09 05:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 05:57:43 --> Input Class Initialized
INFO - 2018-05-09 05:57:43 --> Language Class Initialized
INFO - 2018-05-09 05:57:43 --> Language Class Initialized
INFO - 2018-05-09 05:57:43 --> Config Class Initialized
INFO - 2018-05-09 05:57:43 --> Loader Class Initialized
INFO - 2018-05-09 11:27:43 --> Helper loaded: url_helper
INFO - 2018-05-09 11:27:43 --> Helper loaded: notification_helper
INFO - 2018-05-09 11:27:43 --> Helper loaded: settings_helper
INFO - 2018-05-09 11:27:43 --> Helper loaded: permission_helper
INFO - 2018-05-09 11:27:43 --> Helper loaded: users_helper
INFO - 2018-05-09 05:57:43 --> Config Class Initialized
INFO - 2018-05-09 05:57:43 --> Hooks Class Initialized
DEBUG - 2018-05-09 05:57:43 --> UTF-8 Support Enabled
INFO - 2018-05-09 05:57:43 --> Utf8 Class Initialized
INFO - 2018-05-09 05:57:43 --> URI Class Initialized
INFO - 2018-05-09 11:27:43 --> Database Driver Class Initialized
INFO - 2018-05-09 05:57:43 --> Router Class Initialized
DEBUG - 2018-05-09 11:27:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 11:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 05:57:43 --> Output Class Initialized
INFO - 2018-05-09 05:57:43 --> Security Class Initialized
INFO - 2018-05-09 11:27:43 --> Helper loaded: form_helper
INFO - 2018-05-09 11:27:43 --> Form Validation Class Initialized
INFO - 2018-05-09 11:27:43 --> Controller Class Initialized
DEBUG - 2018-05-09 05:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 05:57:43 --> Input Class Initialized
INFO - 2018-05-09 05:57:43 --> Language Class Initialized
INFO - 2018-05-09 11:27:43 --> Model Class Initialized
INFO - 2018-05-09 11:27:43 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 11:27:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 11:27:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 11:27:43 --> Model Class Initialized
INFO - 2018-05-09 11:27:43 --> Model Class Initialized
INFO - 2018-05-09 11:27:43 --> Model Class Initialized
INFO - 2018-05-09 11:27:43 --> Model Class Initialized
INFO - 2018-05-09 11:27:43 --> Model Class Initialized
INFO - 2018-05-09 11:27:43 --> Model Class Initialized
INFO - 2018-05-09 11:27:43 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 11:27:43 --> Model Class Initialized
INFO - 2018-05-09 11:27:43 --> Final output sent to browser
DEBUG - 2018-05-09 11:27:43 --> Total execution time: 0.1085
INFO - 2018-05-09 05:57:43 --> Language Class Initialized
INFO - 2018-05-09 05:57:43 --> Config Class Initialized
INFO - 2018-05-09 05:57:43 --> Loader Class Initialized
INFO - 2018-05-09 11:27:43 --> Helper loaded: url_helper
INFO - 2018-05-09 11:27:43 --> Helper loaded: notification_helper
INFO - 2018-05-09 11:27:43 --> Helper loaded: settings_helper
INFO - 2018-05-09 11:27:43 --> Helper loaded: permission_helper
INFO - 2018-05-09 11:27:43 --> Helper loaded: users_helper
INFO - 2018-05-09 11:27:43 --> Database Driver Class Initialized
DEBUG - 2018-05-09 11:27:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 11:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 11:27:43 --> Helper loaded: form_helper
INFO - 2018-05-09 11:27:43 --> Form Validation Class Initialized
INFO - 2018-05-09 11:27:43 --> Controller Class Initialized
INFO - 2018-05-09 11:27:43 --> Model Class Initialized
INFO - 2018-05-09 11:27:43 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 11:27:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 11:27:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 11:27:43 --> Model Class Initialized
INFO - 2018-05-09 11:27:43 --> Model Class Initialized
INFO - 2018-05-09 11:27:43 --> Model Class Initialized
INFO - 2018-05-09 11:27:43 --> Model Class Initialized
INFO - 2018-05-09 11:27:43 --> Model Class Initialized
INFO - 2018-05-09 11:27:43 --> Model Class Initialized
INFO - 2018-05-09 11:27:43 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 11:27:43 --> Final output sent to browser
DEBUG - 2018-05-09 11:27:43 --> Total execution time: 0.1475
INFO - 2018-05-09 05:57:46 --> Config Class Initialized
INFO - 2018-05-09 05:57:46 --> Hooks Class Initialized
DEBUG - 2018-05-09 05:57:46 --> UTF-8 Support Enabled
INFO - 2018-05-09 05:57:46 --> Utf8 Class Initialized
INFO - 2018-05-09 05:57:46 --> URI Class Initialized
INFO - 2018-05-09 05:57:46 --> Router Class Initialized
INFO - 2018-05-09 05:57:46 --> Output Class Initialized
INFO - 2018-05-09 05:57:46 --> Security Class Initialized
DEBUG - 2018-05-09 05:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 05:57:46 --> Input Class Initialized
INFO - 2018-05-09 05:57:46 --> Language Class Initialized
INFO - 2018-05-09 05:57:46 --> Language Class Initialized
INFO - 2018-05-09 05:57:46 --> Config Class Initialized
INFO - 2018-05-09 05:57:46 --> Loader Class Initialized
INFO - 2018-05-09 11:27:46 --> Helper loaded: url_helper
INFO - 2018-05-09 11:27:46 --> Helper loaded: notification_helper
INFO - 2018-05-09 11:27:46 --> Helper loaded: settings_helper
INFO - 2018-05-09 11:27:46 --> Helper loaded: permission_helper
INFO - 2018-05-09 11:27:46 --> Helper loaded: users_helper
INFO - 2018-05-09 11:27:46 --> Database Driver Class Initialized
DEBUG - 2018-05-09 11:27:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 11:27:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 11:27:46 --> Helper loaded: form_helper
INFO - 2018-05-09 11:27:46 --> Form Validation Class Initialized
INFO - 2018-05-09 11:27:46 --> Controller Class Initialized
INFO - 2018-05-09 11:27:46 --> Model Class Initialized
INFO - 2018-05-09 11:27:46 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 11:27:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 11:27:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 11:27:46 --> Model Class Initialized
INFO - 2018-05-09 11:27:46 --> Model Class Initialized
INFO - 2018-05-09 11:27:46 --> Model Class Initialized
INFO - 2018-05-09 11:27:46 --> Model Class Initialized
INFO - 2018-05-09 11:27:46 --> Model Class Initialized
INFO - 2018-05-09 11:27:46 --> Model Class Initialized
INFO - 2018-05-09 11:27:46 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-05-09 11:27:46 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 800
ERROR - 2018-05-09 11:27:46 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 810
INFO - 2018-05-09 11:27:46 --> Final output sent to browser
DEBUG - 2018-05-09 11:27:46 --> Total execution time: 0.1149
INFO - 2018-05-09 05:59:00 --> Config Class Initialized
INFO - 2018-05-09 05:59:00 --> Hooks Class Initialized
DEBUG - 2018-05-09 05:59:00 --> UTF-8 Support Enabled
INFO - 2018-05-09 05:59:00 --> Utf8 Class Initialized
INFO - 2018-05-09 05:59:00 --> URI Class Initialized
INFO - 2018-05-09 05:59:00 --> Router Class Initialized
INFO - 2018-05-09 05:59:00 --> Output Class Initialized
INFO - 2018-05-09 05:59:00 --> Security Class Initialized
DEBUG - 2018-05-09 05:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 05:59:00 --> Input Class Initialized
INFO - 2018-05-09 05:59:00 --> Language Class Initialized
INFO - 2018-05-09 05:59:00 --> Language Class Initialized
INFO - 2018-05-09 05:59:00 --> Config Class Initialized
INFO - 2018-05-09 05:59:00 --> Loader Class Initialized
INFO - 2018-05-09 11:29:00 --> Helper loaded: url_helper
INFO - 2018-05-09 11:29:00 --> Helper loaded: notification_helper
INFO - 2018-05-09 11:29:00 --> Helper loaded: settings_helper
INFO - 2018-05-09 11:29:00 --> Helper loaded: permission_helper
INFO - 2018-05-09 11:29:00 --> Helper loaded: users_helper
INFO - 2018-05-09 11:29:00 --> Database Driver Class Initialized
DEBUG - 2018-05-09 11:29:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 11:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 11:29:00 --> Helper loaded: form_helper
INFO - 2018-05-09 11:29:00 --> Form Validation Class Initialized
INFO - 2018-05-09 11:29:00 --> Controller Class Initialized
INFO - 2018-05-09 11:29:00 --> Model Class Initialized
INFO - 2018-05-09 11:29:00 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 11:29:00 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 11:29:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 11:29:00 --> Model Class Initialized
INFO - 2018-05-09 11:29:00 --> Model Class Initialized
INFO - 2018-05-09 11:29:00 --> Model Class Initialized
INFO - 2018-05-09 11:29:00 --> Model Class Initialized
INFO - 2018-05-09 11:29:00 --> Model Class Initialized
INFO - 2018-05-09 11:29:00 --> Model Class Initialized
INFO - 2018-05-09 11:29:00 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 11:29:00 --> Final output sent to browser
DEBUG - 2018-05-09 11:29:00 --> Total execution time: 0.1175
INFO - 2018-05-09 06:33:12 --> Config Class Initialized
INFO - 2018-05-09 06:33:12 --> Hooks Class Initialized
DEBUG - 2018-05-09 06:33:12 --> UTF-8 Support Enabled
INFO - 2018-05-09 06:33:12 --> Utf8 Class Initialized
INFO - 2018-05-09 06:33:12 --> URI Class Initialized
INFO - 2018-05-09 06:33:12 --> Router Class Initialized
INFO - 2018-05-09 06:33:12 --> Output Class Initialized
INFO - 2018-05-09 06:33:12 --> Security Class Initialized
DEBUG - 2018-05-09 06:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 06:33:12 --> Input Class Initialized
INFO - 2018-05-09 06:33:12 --> Language Class Initialized
INFO - 2018-05-09 06:33:12 --> Language Class Initialized
INFO - 2018-05-09 06:33:12 --> Config Class Initialized
INFO - 2018-05-09 06:33:12 --> Loader Class Initialized
INFO - 2018-05-09 12:03:12 --> Helper loaded: url_helper
INFO - 2018-05-09 12:03:12 --> Helper loaded: notification_helper
INFO - 2018-05-09 12:03:12 --> Helper loaded: settings_helper
INFO - 2018-05-09 12:03:12 --> Helper loaded: permission_helper
INFO - 2018-05-09 12:03:12 --> Helper loaded: users_helper
INFO - 2018-05-09 12:03:12 --> Database Driver Class Initialized
DEBUG - 2018-05-09 12:03:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 12:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 12:03:12 --> Helper loaded: form_helper
INFO - 2018-05-09 12:03:12 --> Form Validation Class Initialized
INFO - 2018-05-09 12:03:12 --> Controller Class Initialized
INFO - 2018-05-09 12:03:12 --> Model Class Initialized
INFO - 2018-05-09 12:03:12 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 12:03:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 12:03:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 12:03:12 --> Model Class Initialized
INFO - 2018-05-09 12:03:12 --> Model Class Initialized
INFO - 2018-05-09 12:03:12 --> Model Class Initialized
INFO - 2018-05-09 12:03:12 --> Model Class Initialized
INFO - 2018-05-09 12:03:12 --> Model Class Initialized
INFO - 2018-05-09 12:03:12 --> Model Class Initialized
INFO - 2018-05-09 12:03:12 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 12:03:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-05-09 12:03:12 --> Final output sent to browser
DEBUG - 2018-05-09 12:03:12 --> Total execution time: 0.1147
INFO - 2018-05-09 06:33:14 --> Config Class Initialized
INFO - 2018-05-09 06:33:14 --> Hooks Class Initialized
DEBUG - 2018-05-09 06:33:14 --> UTF-8 Support Enabled
INFO - 2018-05-09 06:33:14 --> Utf8 Class Initialized
INFO - 2018-05-09 06:33:14 --> URI Class Initialized
INFO - 2018-05-09 06:33:14 --> Router Class Initialized
INFO - 2018-05-09 06:33:14 --> Output Class Initialized
INFO - 2018-05-09 06:33:14 --> Security Class Initialized
DEBUG - 2018-05-09 06:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 06:33:14 --> Input Class Initialized
INFO - 2018-05-09 06:33:14 --> Language Class Initialized
INFO - 2018-05-09 06:33:14 --> Language Class Initialized
INFO - 2018-05-09 06:33:14 --> Config Class Initialized
INFO - 2018-05-09 06:33:14 --> Loader Class Initialized
INFO - 2018-05-09 12:03:14 --> Helper loaded: url_helper
INFO - 2018-05-09 12:03:14 --> Helper loaded: notification_helper
INFO - 2018-05-09 12:03:14 --> Helper loaded: settings_helper
INFO - 2018-05-09 12:03:14 --> Helper loaded: permission_helper
INFO - 2018-05-09 12:03:14 --> Helper loaded: users_helper
INFO - 2018-05-09 12:03:14 --> Database Driver Class Initialized
DEBUG - 2018-05-09 12:03:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 12:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 12:03:14 --> Helper loaded: form_helper
INFO - 2018-05-09 12:03:14 --> Form Validation Class Initialized
INFO - 2018-05-09 12:03:14 --> Controller Class Initialized
INFO - 2018-05-09 12:03:14 --> Model Class Initialized
INFO - 2018-05-09 12:03:14 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 12:03:14 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 12:03:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 12:03:14 --> Model Class Initialized
INFO - 2018-05-09 12:03:14 --> Model Class Initialized
INFO - 2018-05-09 12:03:14 --> Model Class Initialized
INFO - 2018-05-09 12:03:14 --> Model Class Initialized
INFO - 2018-05-09 12:03:14 --> Model Class Initialized
INFO - 2018-05-09 12:03:14 --> Model Class Initialized
INFO - 2018-05-09 12:03:14 --> Model Class Initialized
INFO - 2018-05-09 12:03:14 --> Model Class Initialized
INFO - 2018-05-09 12:03:14 --> Model Class Initialized
INFO - 2018-05-09 12:03:14 --> Model Class Initialized
INFO - 2018-05-09 12:03:14 --> Model Class Initialized
INFO - 2018-05-09 12:03:14 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 12:03:14 --> Model Class Initialized
INFO - 2018-05-09 12:03:14 --> Final output sent to browser
DEBUG - 2018-05-09 12:03:14 --> Total execution time: 0.1146
INFO - 2018-05-09 06:44:02 --> Config Class Initialized
INFO - 2018-05-09 06:44:02 --> Hooks Class Initialized
DEBUG - 2018-05-09 06:44:02 --> UTF-8 Support Enabled
INFO - 2018-05-09 06:44:02 --> Utf8 Class Initialized
INFO - 2018-05-09 06:44:02 --> URI Class Initialized
INFO - 2018-05-09 06:44:02 --> Config Class Initialized
INFO - 2018-05-09 06:44:02 --> Hooks Class Initialized
INFO - 2018-05-09 06:44:02 --> Router Class Initialized
INFO - 2018-05-09 06:44:02 --> Output Class Initialized
DEBUG - 2018-05-09 06:44:02 --> UTF-8 Support Enabled
INFO - 2018-05-09 06:44:02 --> Utf8 Class Initialized
INFO - 2018-05-09 06:44:02 --> Security Class Initialized
INFO - 2018-05-09 06:44:02 --> URI Class Initialized
DEBUG - 2018-05-09 06:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 06:44:02 --> Input Class Initialized
INFO - 2018-05-09 06:44:02 --> Language Class Initialized
INFO - 2018-05-09 06:44:02 --> Router Class Initialized
INFO - 2018-05-09 06:44:02 --> Output Class Initialized
INFO - 2018-05-09 06:44:02 --> Security Class Initialized
DEBUG - 2018-05-09 06:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 06:44:02 --> Input Class Initialized
INFO - 2018-05-09 06:44:02 --> Language Class Initialized
INFO - 2018-05-09 06:44:02 --> Language Class Initialized
INFO - 2018-05-09 06:44:02 --> Config Class Initialized
INFO - 2018-05-09 06:44:02 --> Loader Class Initialized
INFO - 2018-05-09 12:14:02 --> Helper loaded: url_helper
INFO - 2018-05-09 12:14:02 --> Helper loaded: notification_helper
INFO - 2018-05-09 12:14:02 --> Helper loaded: settings_helper
INFO - 2018-05-09 12:14:02 --> Helper loaded: permission_helper
INFO - 2018-05-09 12:14:02 --> Helper loaded: users_helper
INFO - 2018-05-09 12:14:02 --> Database Driver Class Initialized
DEBUG - 2018-05-09 12:14:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 12:14:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 06:44:02 --> Language Class Initialized
INFO - 2018-05-09 06:44:02 --> Config Class Initialized
INFO - 2018-05-09 06:44:02 --> Loader Class Initialized
INFO - 2018-05-09 12:14:02 --> Helper loaded: form_helper
INFO - 2018-05-09 12:14:02 --> Form Validation Class Initialized
INFO - 2018-05-09 12:14:02 --> Controller Class Initialized
INFO - 2018-05-09 12:14:02 --> Helper loaded: url_helper
INFO - 2018-05-09 12:14:02 --> Helper loaded: notification_helper
INFO - 2018-05-09 12:14:02 --> Helper loaded: settings_helper
INFO - 2018-05-09 12:14:02 --> Helper loaded: permission_helper
INFO - 2018-05-09 12:14:02 --> Helper loaded: users_helper
INFO - 2018-05-09 12:14:02 --> Model Class Initialized
INFO - 2018-05-09 12:14:02 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 12:14:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 12:14:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 12:14:02 --> Model Class Initialized
INFO - 2018-05-09 12:14:02 --> Model Class Initialized
INFO - 2018-05-09 12:14:02 --> Model Class Initialized
INFO - 2018-05-09 12:14:02 --> Model Class Initialized
INFO - 2018-05-09 12:14:02 --> Model Class Initialized
INFO - 2018-05-09 12:14:02 --> Model Class Initialized
INFO - 2018-05-09 12:14:02 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 12:14:02 --> Final output sent to browser
DEBUG - 2018-05-09 12:14:02 --> Total execution time: 0.1211
INFO - 2018-05-09 12:14:02 --> Database Driver Class Initialized
DEBUG - 2018-05-09 12:14:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 12:14:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 12:14:02 --> Helper loaded: form_helper
INFO - 2018-05-09 12:14:02 --> Form Validation Class Initialized
INFO - 2018-05-09 12:14:02 --> Controller Class Initialized
INFO - 2018-05-09 12:14:02 --> Model Class Initialized
INFO - 2018-05-09 12:14:02 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 12:14:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 12:14:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 12:14:02 --> Model Class Initialized
INFO - 2018-05-09 12:14:02 --> Model Class Initialized
INFO - 2018-05-09 12:14:02 --> Model Class Initialized
INFO - 2018-05-09 12:14:02 --> Model Class Initialized
INFO - 2018-05-09 12:14:02 --> Model Class Initialized
INFO - 2018-05-09 12:14:02 --> Model Class Initialized
INFO - 2018-05-09 12:14:02 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 12:14:02 --> Model Class Initialized
INFO - 2018-05-09 12:14:02 --> Final output sent to browser
DEBUG - 2018-05-09 12:14:02 --> Total execution time: 0.2126
INFO - 2018-05-09 06:44:06 --> Config Class Initialized
INFO - 2018-05-09 06:44:06 --> Hooks Class Initialized
DEBUG - 2018-05-09 06:44:06 --> UTF-8 Support Enabled
INFO - 2018-05-09 06:44:06 --> Utf8 Class Initialized
INFO - 2018-05-09 06:44:06 --> URI Class Initialized
INFO - 2018-05-09 06:44:06 --> Router Class Initialized
INFO - 2018-05-09 06:44:06 --> Output Class Initialized
INFO - 2018-05-09 06:44:06 --> Security Class Initialized
DEBUG - 2018-05-09 06:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 06:44:06 --> Input Class Initialized
INFO - 2018-05-09 06:44:06 --> Language Class Initialized
INFO - 2018-05-09 06:44:06 --> Language Class Initialized
INFO - 2018-05-09 06:44:06 --> Config Class Initialized
INFO - 2018-05-09 06:44:06 --> Loader Class Initialized
INFO - 2018-05-09 12:14:06 --> Helper loaded: url_helper
INFO - 2018-05-09 12:14:06 --> Helper loaded: notification_helper
INFO - 2018-05-09 12:14:06 --> Helper loaded: settings_helper
INFO - 2018-05-09 12:14:06 --> Helper loaded: permission_helper
INFO - 2018-05-09 12:14:06 --> Helper loaded: users_helper
INFO - 2018-05-09 12:14:06 --> Database Driver Class Initialized
DEBUG - 2018-05-09 12:14:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 12:14:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 12:14:06 --> Helper loaded: form_helper
INFO - 2018-05-09 12:14:06 --> Form Validation Class Initialized
INFO - 2018-05-09 12:14:06 --> Controller Class Initialized
INFO - 2018-05-09 12:14:06 --> Model Class Initialized
INFO - 2018-05-09 12:14:06 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 12:14:06 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 12:14:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 12:14:06 --> Model Class Initialized
INFO - 2018-05-09 12:14:06 --> Model Class Initialized
INFO - 2018-05-09 12:14:06 --> Model Class Initialized
INFO - 2018-05-09 12:14:06 --> Model Class Initialized
INFO - 2018-05-09 12:14:06 --> Model Class Initialized
INFO - 2018-05-09 12:14:06 --> Model Class Initialized
INFO - 2018-05-09 12:14:06 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 12:14:06 --> Final output sent to browser
DEBUG - 2018-05-09 12:14:06 --> Total execution time: 0.1286
INFO - 2018-05-09 06:44:06 --> Config Class Initialized
INFO - 2018-05-09 06:44:06 --> Hooks Class Initialized
DEBUG - 2018-05-09 06:44:06 --> UTF-8 Support Enabled
INFO - 2018-05-09 06:44:06 --> Utf8 Class Initialized
INFO - 2018-05-09 06:44:06 --> URI Class Initialized
INFO - 2018-05-09 06:44:06 --> Router Class Initialized
INFO - 2018-05-09 06:44:06 --> Output Class Initialized
INFO - 2018-05-09 06:44:06 --> Security Class Initialized
DEBUG - 2018-05-09 06:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 06:44:06 --> Input Class Initialized
INFO - 2018-05-09 06:44:06 --> Language Class Initialized
INFO - 2018-05-09 06:44:06 --> Language Class Initialized
INFO - 2018-05-09 06:44:06 --> Config Class Initialized
INFO - 2018-05-09 06:44:06 --> Loader Class Initialized
INFO - 2018-05-09 12:14:06 --> Helper loaded: url_helper
INFO - 2018-05-09 12:14:06 --> Helper loaded: notification_helper
INFO - 2018-05-09 12:14:06 --> Helper loaded: settings_helper
INFO - 2018-05-09 12:14:06 --> Helper loaded: permission_helper
INFO - 2018-05-09 12:14:06 --> Helper loaded: users_helper
INFO - 2018-05-09 12:14:06 --> Database Driver Class Initialized
DEBUG - 2018-05-09 12:14:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 12:14:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 12:14:06 --> Helper loaded: form_helper
INFO - 2018-05-09 12:14:06 --> Form Validation Class Initialized
INFO - 2018-05-09 12:14:06 --> Controller Class Initialized
INFO - 2018-05-09 12:14:06 --> Model Class Initialized
INFO - 2018-05-09 12:14:06 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 12:14:06 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 12:14:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 12:14:06 --> Model Class Initialized
INFO - 2018-05-09 12:14:06 --> Model Class Initialized
INFO - 2018-05-09 12:14:06 --> Model Class Initialized
INFO - 2018-05-09 12:14:06 --> Model Class Initialized
INFO - 2018-05-09 12:14:06 --> Model Class Initialized
INFO - 2018-05-09 12:14:06 --> Model Class Initialized
INFO - 2018-05-09 12:14:06 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 12:14:06 --> Final output sent to browser
DEBUG - 2018-05-09 12:14:06 --> Total execution time: 0.1115
INFO - 2018-05-09 06:51:13 --> Config Class Initialized
INFO - 2018-05-09 06:51:13 --> Hooks Class Initialized
DEBUG - 2018-05-09 06:51:13 --> UTF-8 Support Enabled
INFO - 2018-05-09 06:51:13 --> Utf8 Class Initialized
INFO - 2018-05-09 06:51:13 --> URI Class Initialized
INFO - 2018-05-09 06:51:13 --> Router Class Initialized
INFO - 2018-05-09 06:51:13 --> Output Class Initialized
INFO - 2018-05-09 06:51:13 --> Security Class Initialized
DEBUG - 2018-05-09 06:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 06:51:13 --> Input Class Initialized
INFO - 2018-05-09 06:51:13 --> Language Class Initialized
INFO - 2018-05-09 06:51:13 --> Language Class Initialized
INFO - 2018-05-09 06:51:13 --> Config Class Initialized
INFO - 2018-05-09 06:51:13 --> Loader Class Initialized
INFO - 2018-05-09 12:21:13 --> Helper loaded: url_helper
INFO - 2018-05-09 12:21:13 --> Helper loaded: notification_helper
INFO - 2018-05-09 12:21:13 --> Helper loaded: settings_helper
INFO - 2018-05-09 12:21:13 --> Helper loaded: permission_helper
INFO - 2018-05-09 12:21:13 --> Helper loaded: users_helper
INFO - 2018-05-09 12:21:13 --> Database Driver Class Initialized
DEBUG - 2018-05-09 12:21:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 12:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 12:21:13 --> Helper loaded: form_helper
INFO - 2018-05-09 12:21:13 --> Form Validation Class Initialized
INFO - 2018-05-09 12:21:13 --> Controller Class Initialized
INFO - 2018-05-09 12:21:13 --> Model Class Initialized
INFO - 2018-05-09 12:21:13 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 12:21:13 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 12:21:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 12:21:13 --> Model Class Initialized
INFO - 2018-05-09 12:21:13 --> Model Class Initialized
INFO - 2018-05-09 12:21:13 --> Model Class Initialized
INFO - 2018-05-09 12:21:13 --> Model Class Initialized
INFO - 2018-05-09 12:21:13 --> Model Class Initialized
INFO - 2018-05-09 12:21:13 --> Model Class Initialized
INFO - 2018-05-09 12:21:13 --> Model Class Initialized
INFO - 2018-05-09 12:21:13 --> Model Class Initialized
INFO - 2018-05-09 12:21:13 --> Model Class Initialized
INFO - 2018-05-09 12:21:13 --> Model Class Initialized
INFO - 2018-05-09 12:21:13 --> Model Class Initialized
INFO - 2018-05-09 12:21:13 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 12:21:13 --> Model Class Initialized
INFO - 2018-05-09 12:21:13 --> Final output sent to browser
DEBUG - 2018-05-09 12:21:13 --> Total execution time: 0.1319
INFO - 2018-05-09 06:51:13 --> Config Class Initialized
INFO - 2018-05-09 06:51:13 --> Hooks Class Initialized
DEBUG - 2018-05-09 06:51:13 --> UTF-8 Support Enabled
INFO - 2018-05-09 06:51:13 --> Utf8 Class Initialized
INFO - 2018-05-09 06:51:13 --> URI Class Initialized
INFO - 2018-05-09 06:51:13 --> Router Class Initialized
INFO - 2018-05-09 06:51:13 --> Output Class Initialized
INFO - 2018-05-09 06:51:13 --> Security Class Initialized
DEBUG - 2018-05-09 06:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 06:51:13 --> Input Class Initialized
INFO - 2018-05-09 06:51:13 --> Language Class Initialized
INFO - 2018-05-09 06:51:13 --> Language Class Initialized
INFO - 2018-05-09 06:51:13 --> Config Class Initialized
INFO - 2018-05-09 06:51:13 --> Loader Class Initialized
INFO - 2018-05-09 12:21:13 --> Helper loaded: url_helper
INFO - 2018-05-09 12:21:13 --> Helper loaded: notification_helper
INFO - 2018-05-09 12:21:13 --> Helper loaded: settings_helper
INFO - 2018-05-09 12:21:13 --> Helper loaded: permission_helper
INFO - 2018-05-09 12:21:13 --> Helper loaded: users_helper
INFO - 2018-05-09 12:21:13 --> Database Driver Class Initialized
DEBUG - 2018-05-09 12:21:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 12:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 12:21:13 --> Helper loaded: form_helper
INFO - 2018-05-09 12:21:13 --> Form Validation Class Initialized
INFO - 2018-05-09 12:21:13 --> Controller Class Initialized
INFO - 2018-05-09 12:21:13 --> Model Class Initialized
INFO - 2018-05-09 12:21:13 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 12:21:13 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 12:21:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 12:21:13 --> Model Class Initialized
INFO - 2018-05-09 12:21:13 --> Model Class Initialized
INFO - 2018-05-09 12:21:13 --> Model Class Initialized
INFO - 2018-05-09 12:21:13 --> Model Class Initialized
INFO - 2018-05-09 12:21:13 --> Model Class Initialized
INFO - 2018-05-09 12:21:13 --> Model Class Initialized
INFO - 2018-05-09 12:21:13 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 12:21:13 --> Model Class Initialized
INFO - 2018-05-09 12:21:13 --> Final output sent to browser
DEBUG - 2018-05-09 12:21:13 --> Total execution time: 0.1281
INFO - 2018-05-09 06:51:20 --> Config Class Initialized
INFO - 2018-05-09 06:51:20 --> Hooks Class Initialized
DEBUG - 2018-05-09 06:51:20 --> UTF-8 Support Enabled
INFO - 2018-05-09 06:51:20 --> Utf8 Class Initialized
INFO - 2018-05-09 06:51:20 --> URI Class Initialized
INFO - 2018-05-09 06:51:20 --> Router Class Initialized
INFO - 2018-05-09 06:51:20 --> Output Class Initialized
INFO - 2018-05-09 06:51:20 --> Security Class Initialized
DEBUG - 2018-05-09 06:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 06:51:20 --> Input Class Initialized
INFO - 2018-05-09 06:51:20 --> Language Class Initialized
INFO - 2018-05-09 06:51:20 --> Config Class Initialized
INFO - 2018-05-09 06:51:20 --> Hooks Class Initialized
DEBUG - 2018-05-09 06:51:20 --> UTF-8 Support Enabled
INFO - 2018-05-09 06:51:20 --> Utf8 Class Initialized
INFO - 2018-05-09 06:51:20 --> URI Class Initialized
INFO - 2018-05-09 06:51:20 --> Language Class Initialized
INFO - 2018-05-09 06:51:20 --> Config Class Initialized
INFO - 2018-05-09 06:51:20 --> Loader Class Initialized
INFO - 2018-05-09 12:21:20 --> Helper loaded: url_helper
INFO - 2018-05-09 06:51:20 --> Router Class Initialized
INFO - 2018-05-09 12:21:20 --> Helper loaded: notification_helper
INFO - 2018-05-09 12:21:20 --> Helper loaded: settings_helper
INFO - 2018-05-09 12:21:20 --> Helper loaded: permission_helper
INFO - 2018-05-09 12:21:20 --> Helper loaded: users_helper
INFO - 2018-05-09 06:51:20 --> Output Class Initialized
INFO - 2018-05-09 06:51:20 --> Security Class Initialized
DEBUG - 2018-05-09 06:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 06:51:20 --> Input Class Initialized
INFO - 2018-05-09 06:51:20 --> Language Class Initialized
INFO - 2018-05-09 12:21:20 --> Database Driver Class Initialized
DEBUG - 2018-05-09 12:21:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 12:21:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 12:21:20 --> Helper loaded: form_helper
INFO - 2018-05-09 12:21:20 --> Form Validation Class Initialized
INFO - 2018-05-09 12:21:20 --> Controller Class Initialized
INFO - 2018-05-09 06:51:20 --> Language Class Initialized
INFO - 2018-05-09 06:51:20 --> Config Class Initialized
INFO - 2018-05-09 06:51:20 --> Loader Class Initialized
INFO - 2018-05-09 12:21:20 --> Helper loaded: url_helper
INFO - 2018-05-09 12:21:20 --> Helper loaded: notification_helper
INFO - 2018-05-09 12:21:20 --> Helper loaded: settings_helper
INFO - 2018-05-09 12:21:20 --> Helper loaded: permission_helper
INFO - 2018-05-09 12:21:20 --> Model Class Initialized
INFO - 2018-05-09 12:21:20 --> Helper loaded: users_helper
INFO - 2018-05-09 12:21:20 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 12:21:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 12:21:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 12:21:20 --> Model Class Initialized
INFO - 2018-05-09 12:21:20 --> Model Class Initialized
INFO - 2018-05-09 12:21:20 --> Model Class Initialized
INFO - 2018-05-09 12:21:20 --> Model Class Initialized
INFO - 2018-05-09 12:21:20 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 12:21:20 --> Database Driver Class Initialized
INFO - 2018-05-09 12:21:20 --> Final output sent to browser
DEBUG - 2018-05-09 12:21:20 --> Total execution time: 0.0959
DEBUG - 2018-05-09 12:21:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 12:21:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 12:21:20 --> Helper loaded: form_helper
INFO - 2018-05-09 12:21:20 --> Form Validation Class Initialized
INFO - 2018-05-09 12:21:20 --> Controller Class Initialized
INFO - 2018-05-09 12:21:20 --> Model Class Initialized
INFO - 2018-05-09 12:21:20 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 12:21:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 12:21:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 12:21:20 --> Model Class Initialized
INFO - 2018-05-09 12:21:20 --> Model Class Initialized
INFO - 2018-05-09 12:21:20 --> Model Class Initialized
INFO - 2018-05-09 12:21:20 --> Model Class Initialized
INFO - 2018-05-09 12:21:20 --> Model Class Initialized
INFO - 2018-05-09 12:21:20 --> Model Class Initialized
INFO - 2018-05-09 12:21:20 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 12:21:20 --> Final output sent to browser
DEBUG - 2018-05-09 12:21:20 --> Total execution time: 0.1109
INFO - 2018-05-09 06:51:30 --> Config Class Initialized
INFO - 2018-05-09 06:51:30 --> Hooks Class Initialized
DEBUG - 2018-05-09 06:51:30 --> UTF-8 Support Enabled
INFO - 2018-05-09 06:51:30 --> Utf8 Class Initialized
INFO - 2018-05-09 06:51:30 --> URI Class Initialized
INFO - 2018-05-09 06:51:30 --> Router Class Initialized
INFO - 2018-05-09 06:51:30 --> Output Class Initialized
INFO - 2018-05-09 06:51:30 --> Security Class Initialized
DEBUG - 2018-05-09 06:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 06:51:30 --> Input Class Initialized
INFO - 2018-05-09 06:51:30 --> Language Class Initialized
INFO - 2018-05-09 06:51:30 --> Language Class Initialized
INFO - 2018-05-09 06:51:30 --> Config Class Initialized
INFO - 2018-05-09 06:51:30 --> Loader Class Initialized
INFO - 2018-05-09 12:21:30 --> Helper loaded: url_helper
INFO - 2018-05-09 12:21:30 --> Helper loaded: notification_helper
INFO - 2018-05-09 12:21:30 --> Helper loaded: settings_helper
INFO - 2018-05-09 12:21:30 --> Helper loaded: permission_helper
INFO - 2018-05-09 12:21:30 --> Helper loaded: users_helper
INFO - 2018-05-09 12:21:30 --> Database Driver Class Initialized
DEBUG - 2018-05-09 12:21:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 12:21:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 12:21:30 --> Helper loaded: form_helper
INFO - 2018-05-09 12:21:30 --> Form Validation Class Initialized
INFO - 2018-05-09 12:21:30 --> Controller Class Initialized
DEBUG - 2018-05-09 12:21:30 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-05-09 12:21:30 --> Final output sent to browser
DEBUG - 2018-05-09 12:21:30 --> Total execution time: 0.0983
INFO - 2018-05-09 06:51:34 --> Config Class Initialized
INFO - 2018-05-09 06:51:34 --> Hooks Class Initialized
DEBUG - 2018-05-09 06:51:34 --> UTF-8 Support Enabled
INFO - 2018-05-09 06:51:34 --> Utf8 Class Initialized
INFO - 2018-05-09 06:51:34 --> URI Class Initialized
INFO - 2018-05-09 06:51:34 --> Router Class Initialized
INFO - 2018-05-09 06:51:34 --> Output Class Initialized
INFO - 2018-05-09 06:51:34 --> Security Class Initialized
DEBUG - 2018-05-09 06:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 06:51:34 --> Input Class Initialized
INFO - 2018-05-09 06:51:34 --> Language Class Initialized
INFO - 2018-05-09 06:51:34 --> Language Class Initialized
INFO - 2018-05-09 06:51:34 --> Config Class Initialized
INFO - 2018-05-09 06:51:34 --> Loader Class Initialized
INFO - 2018-05-09 12:21:34 --> Helper loaded: url_helper
INFO - 2018-05-09 12:21:34 --> Helper loaded: notification_helper
INFO - 2018-05-09 12:21:34 --> Helper loaded: settings_helper
INFO - 2018-05-09 12:21:34 --> Helper loaded: permission_helper
INFO - 2018-05-09 12:21:34 --> Helper loaded: users_helper
INFO - 2018-05-09 12:21:34 --> Database Driver Class Initialized
DEBUG - 2018-05-09 12:21:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 12:21:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 12:21:34 --> Helper loaded: form_helper
INFO - 2018-05-09 12:21:34 --> Form Validation Class Initialized
INFO - 2018-05-09 12:21:34 --> Controller Class Initialized
DEBUG - 2018-05-09 12:21:34 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-05-09 12:21:34 --> Final output sent to browser
DEBUG - 2018-05-09 12:21:34 --> Total execution time: 0.0690
INFO - 2018-05-09 06:56:39 --> Config Class Initialized
INFO - 2018-05-09 06:56:39 --> Hooks Class Initialized
DEBUG - 2018-05-09 06:56:39 --> UTF-8 Support Enabled
INFO - 2018-05-09 06:56:39 --> Utf8 Class Initialized
INFO - 2018-05-09 06:56:39 --> URI Class Initialized
INFO - 2018-05-09 06:56:39 --> Router Class Initialized
INFO - 2018-05-09 06:56:39 --> Output Class Initialized
INFO - 2018-05-09 06:56:39 --> Security Class Initialized
DEBUG - 2018-05-09 06:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 06:56:39 --> Input Class Initialized
INFO - 2018-05-09 06:56:39 --> Language Class Initialized
INFO - 2018-05-09 06:56:39 --> Language Class Initialized
INFO - 2018-05-09 06:56:39 --> Config Class Initialized
INFO - 2018-05-09 06:56:39 --> Loader Class Initialized
INFO - 2018-05-09 12:26:39 --> Helper loaded: url_helper
INFO - 2018-05-09 12:26:39 --> Helper loaded: notification_helper
INFO - 2018-05-09 12:26:39 --> Helper loaded: settings_helper
INFO - 2018-05-09 12:26:39 --> Helper loaded: permission_helper
INFO - 2018-05-09 12:26:39 --> Helper loaded: users_helper
INFO - 2018-05-09 12:26:39 --> Database Driver Class Initialized
DEBUG - 2018-05-09 12:26:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 12:26:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 12:26:39 --> Helper loaded: form_helper
INFO - 2018-05-09 12:26:39 --> Form Validation Class Initialized
INFO - 2018-05-09 12:26:39 --> Controller Class Initialized
INFO - 2018-05-09 12:26:39 --> Model Class Initialized
INFO - 2018-05-09 12:26:39 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 12:26:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 12:26:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 12:26:39 --> Model Class Initialized
INFO - 2018-05-09 12:26:39 --> Model Class Initialized
INFO - 2018-05-09 12:26:39 --> Model Class Initialized
INFO - 2018-05-09 12:26:39 --> Model Class Initialized
INFO - 2018-05-09 12:26:39 --> Model Class Initialized
INFO - 2018-05-09 12:26:39 --> Model Class Initialized
INFO - 2018-05-09 12:26:39 --> Model Class Initialized
INFO - 2018-05-09 12:26:39 --> Model Class Initialized
INFO - 2018-05-09 12:26:39 --> Model Class Initialized
INFO - 2018-05-09 12:26:39 --> Model Class Initialized
INFO - 2018-05-09 06:56:39 --> Config Class Initialized
INFO - 2018-05-09 06:56:39 --> Hooks Class Initialized
INFO - 2018-05-09 12:26:39 --> Model Class Initialized
INFO - 2018-05-09 12:26:39 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 12:26:39 --> Model Class Initialized
DEBUG - 2018-05-09 06:56:39 --> UTF-8 Support Enabled
INFO - 2018-05-09 06:56:39 --> Utf8 Class Initialized
INFO - 2018-05-09 06:56:39 --> URI Class Initialized
INFO - 2018-05-09 06:56:39 --> Router Class Initialized
INFO - 2018-05-09 06:56:39 --> Output Class Initialized
INFO - 2018-05-09 06:56:39 --> Security Class Initialized
INFO - 2018-05-09 12:26:39 --> Final output sent to browser
DEBUG - 2018-05-09 12:26:39 --> Total execution time: 0.1445
DEBUG - 2018-05-09 06:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 06:56:39 --> Input Class Initialized
INFO - 2018-05-09 06:56:39 --> Language Class Initialized
INFO - 2018-05-09 06:56:39 --> Language Class Initialized
INFO - 2018-05-09 06:56:39 --> Config Class Initialized
INFO - 2018-05-09 06:56:39 --> Loader Class Initialized
INFO - 2018-05-09 12:26:39 --> Helper loaded: url_helper
INFO - 2018-05-09 12:26:39 --> Helper loaded: notification_helper
INFO - 2018-05-09 12:26:39 --> Helper loaded: settings_helper
INFO - 2018-05-09 12:26:39 --> Helper loaded: permission_helper
INFO - 2018-05-09 12:26:39 --> Helper loaded: users_helper
INFO - 2018-05-09 12:26:39 --> Database Driver Class Initialized
DEBUG - 2018-05-09 12:26:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 12:26:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 12:26:39 --> Helper loaded: form_helper
INFO - 2018-05-09 12:26:39 --> Form Validation Class Initialized
INFO - 2018-05-09 12:26:39 --> Controller Class Initialized
INFO - 2018-05-09 12:26:39 --> Model Class Initialized
INFO - 2018-05-09 12:26:39 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 12:26:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 12:26:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 12:26:39 --> Model Class Initialized
INFO - 2018-05-09 12:26:39 --> Model Class Initialized
INFO - 2018-05-09 12:26:39 --> Model Class Initialized
INFO - 2018-05-09 12:26:39 --> Model Class Initialized
INFO - 2018-05-09 12:26:39 --> Model Class Initialized
INFO - 2018-05-09 12:26:39 --> Model Class Initialized
INFO - 2018-05-09 12:26:39 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 12:26:39 --> Model Class Initialized
INFO - 2018-05-09 12:26:39 --> Final output sent to browser
DEBUG - 2018-05-09 12:26:39 --> Total execution time: 0.1080
INFO - 2018-05-09 06:56:44 --> Config Class Initialized
INFO - 2018-05-09 06:56:44 --> Config Class Initialized
INFO - 2018-05-09 06:56:44 --> Hooks Class Initialized
INFO - 2018-05-09 06:56:44 --> Hooks Class Initialized
DEBUG - 2018-05-09 06:56:44 --> UTF-8 Support Enabled
INFO - 2018-05-09 06:56:44 --> Utf8 Class Initialized
DEBUG - 2018-05-09 06:56:44 --> UTF-8 Support Enabled
INFO - 2018-05-09 06:56:44 --> Utf8 Class Initialized
INFO - 2018-05-09 06:56:44 --> URI Class Initialized
INFO - 2018-05-09 06:56:44 --> URI Class Initialized
INFO - 2018-05-09 06:56:44 --> Router Class Initialized
INFO - 2018-05-09 06:56:44 --> Router Class Initialized
INFO - 2018-05-09 06:56:44 --> Output Class Initialized
INFO - 2018-05-09 06:56:44 --> Output Class Initialized
INFO - 2018-05-09 06:56:44 --> Security Class Initialized
INFO - 2018-05-09 06:56:44 --> Security Class Initialized
DEBUG - 2018-05-09 06:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 06:56:44 --> Input Class Initialized
DEBUG - 2018-05-09 06:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 06:56:44 --> Input Class Initialized
INFO - 2018-05-09 06:56:44 --> Language Class Initialized
INFO - 2018-05-09 06:56:44 --> Language Class Initialized
INFO - 2018-05-09 06:56:44 --> Language Class Initialized
INFO - 2018-05-09 06:56:44 --> Config Class Initialized
INFO - 2018-05-09 06:56:44 --> Loader Class Initialized
INFO - 2018-05-09 12:26:44 --> Helper loaded: url_helper
INFO - 2018-05-09 12:26:44 --> Helper loaded: notification_helper
INFO - 2018-05-09 12:26:44 --> Helper loaded: settings_helper
INFO - 2018-05-09 12:26:44 --> Helper loaded: permission_helper
INFO - 2018-05-09 12:26:44 --> Helper loaded: users_helper
INFO - 2018-05-09 06:56:44 --> Language Class Initialized
INFO - 2018-05-09 06:56:44 --> Config Class Initialized
INFO - 2018-05-09 06:56:44 --> Loader Class Initialized
INFO - 2018-05-09 12:26:44 --> Helper loaded: url_helper
INFO - 2018-05-09 12:26:44 --> Helper loaded: notification_helper
INFO - 2018-05-09 12:26:44 --> Helper loaded: settings_helper
INFO - 2018-05-09 12:26:44 --> Helper loaded: permission_helper
INFO - 2018-05-09 12:26:44 --> Helper loaded: users_helper
INFO - 2018-05-09 12:26:44 --> Database Driver Class Initialized
DEBUG - 2018-05-09 12:26:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 12:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 12:26:44 --> Database Driver Class Initialized
INFO - 2018-05-09 12:26:44 --> Helper loaded: form_helper
INFO - 2018-05-09 12:26:44 --> Form Validation Class Initialized
INFO - 2018-05-09 12:26:44 --> Controller Class Initialized
DEBUG - 2018-05-09 12:26:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 12:26:44 --> Model Class Initialized
INFO - 2018-05-09 12:26:44 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 12:26:44 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 12:26:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 12:26:44 --> Model Class Initialized
INFO - 2018-05-09 12:26:44 --> Model Class Initialized
INFO - 2018-05-09 12:26:44 --> Model Class Initialized
INFO - 2018-05-09 12:26:44 --> Model Class Initialized
INFO - 2018-05-09 12:26:44 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 12:26:44 --> Final output sent to browser
DEBUG - 2018-05-09 12:26:44 --> Total execution time: 0.1315
INFO - 2018-05-09 12:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 12:26:44 --> Helper loaded: form_helper
INFO - 2018-05-09 12:26:44 --> Form Validation Class Initialized
INFO - 2018-05-09 12:26:44 --> Controller Class Initialized
INFO - 2018-05-09 12:26:44 --> Model Class Initialized
INFO - 2018-05-09 12:26:44 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 12:26:44 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 12:26:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 12:26:44 --> Model Class Initialized
INFO - 2018-05-09 12:26:44 --> Model Class Initialized
INFO - 2018-05-09 12:26:44 --> Model Class Initialized
INFO - 2018-05-09 12:26:44 --> Model Class Initialized
INFO - 2018-05-09 12:26:44 --> Model Class Initialized
INFO - 2018-05-09 12:26:44 --> Model Class Initialized
INFO - 2018-05-09 12:26:44 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 12:26:44 --> Final output sent to browser
DEBUG - 2018-05-09 12:26:44 --> Total execution time: 0.1586
INFO - 2018-05-09 06:56:48 --> Config Class Initialized
INFO - 2018-05-09 06:56:48 --> Hooks Class Initialized
DEBUG - 2018-05-09 06:56:48 --> UTF-8 Support Enabled
INFO - 2018-05-09 06:56:48 --> Utf8 Class Initialized
INFO - 2018-05-09 06:56:48 --> URI Class Initialized
INFO - 2018-05-09 06:56:48 --> Router Class Initialized
INFO - 2018-05-09 06:56:48 --> Output Class Initialized
INFO - 2018-05-09 06:56:48 --> Security Class Initialized
DEBUG - 2018-05-09 06:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 06:56:48 --> Input Class Initialized
INFO - 2018-05-09 06:56:48 --> Language Class Initialized
INFO - 2018-05-09 06:56:48 --> Language Class Initialized
INFO - 2018-05-09 06:56:48 --> Config Class Initialized
INFO - 2018-05-09 06:56:48 --> Loader Class Initialized
INFO - 2018-05-09 12:26:48 --> Helper loaded: url_helper
INFO - 2018-05-09 12:26:48 --> Helper loaded: notification_helper
INFO - 2018-05-09 12:26:48 --> Helper loaded: settings_helper
INFO - 2018-05-09 12:26:48 --> Helper loaded: permission_helper
INFO - 2018-05-09 12:26:48 --> Helper loaded: users_helper
INFO - 2018-05-09 12:26:48 --> Database Driver Class Initialized
DEBUG - 2018-05-09 12:26:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 12:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 12:26:48 --> Helper loaded: form_helper
INFO - 2018-05-09 12:26:48 --> Form Validation Class Initialized
INFO - 2018-05-09 12:26:48 --> Controller Class Initialized
INFO - 2018-05-09 12:26:48 --> Model Class Initialized
INFO - 2018-05-09 12:26:48 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 12:26:48 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 12:26:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 12:26:48 --> Model Class Initialized
INFO - 2018-05-09 12:26:48 --> Model Class Initialized
INFO - 2018-05-09 12:26:48 --> Final output sent to browser
DEBUG - 2018-05-09 12:26:48 --> Total execution time: 0.1157
INFO - 2018-05-09 07:23:30 --> Config Class Initialized
INFO - 2018-05-09 07:23:30 --> Hooks Class Initialized
DEBUG - 2018-05-09 07:23:30 --> UTF-8 Support Enabled
INFO - 2018-05-09 07:23:30 --> Utf8 Class Initialized
INFO - 2018-05-09 07:23:30 --> URI Class Initialized
INFO - 2018-05-09 07:23:30 --> Router Class Initialized
INFO - 2018-05-09 07:23:30 --> Output Class Initialized
INFO - 2018-05-09 07:23:30 --> Security Class Initialized
DEBUG - 2018-05-09 07:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 07:23:30 --> Input Class Initialized
INFO - 2018-05-09 07:23:30 --> Language Class Initialized
INFO - 2018-05-09 07:23:30 --> Language Class Initialized
INFO - 2018-05-09 07:23:30 --> Config Class Initialized
INFO - 2018-05-09 07:23:30 --> Loader Class Initialized
INFO - 2018-05-09 12:53:30 --> Helper loaded: url_helper
INFO - 2018-05-09 12:53:30 --> Helper loaded: notification_helper
INFO - 2018-05-09 12:53:30 --> Helper loaded: settings_helper
INFO - 2018-05-09 12:53:30 --> Helper loaded: permission_helper
INFO - 2018-05-09 12:53:30 --> Helper loaded: users_helper
INFO - 2018-05-09 12:53:30 --> Database Driver Class Initialized
INFO - 2018-05-09 07:23:30 --> Config Class Initialized
INFO - 2018-05-09 07:23:30 --> Hooks Class Initialized
DEBUG - 2018-05-09 12:53:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 12:53:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-05-09 07:23:30 --> UTF-8 Support Enabled
INFO - 2018-05-09 07:23:30 --> Utf8 Class Initialized
INFO - 2018-05-09 07:23:30 --> URI Class Initialized
INFO - 2018-05-09 12:53:30 --> Helper loaded: form_helper
INFO - 2018-05-09 12:53:30 --> Form Validation Class Initialized
INFO - 2018-05-09 12:53:30 --> Controller Class Initialized
INFO - 2018-05-09 07:23:30 --> Router Class Initialized
INFO - 2018-05-09 07:23:30 --> Output Class Initialized
INFO - 2018-05-09 07:23:30 --> Security Class Initialized
INFO - 2018-05-09 12:53:30 --> Model Class Initialized
DEBUG - 2018-05-09 07:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 12:53:30 --> Helper loaded: inflector_helper
INFO - 2018-05-09 07:23:30 --> Input Class Initialized
INFO - 2018-05-09 07:23:30 --> Language Class Initialized
DEBUG - 2018-05-09 12:53:30 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 12:53:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 12:53:30 --> Model Class Initialized
INFO - 2018-05-09 12:53:30 --> Model Class Initialized
INFO - 2018-05-09 12:53:30 --> Model Class Initialized
INFO - 2018-05-09 12:53:30 --> Model Class Initialized
INFO - 2018-05-09 12:53:30 --> Model Class Initialized
INFO - 2018-05-09 12:53:30 --> Model Class Initialized
INFO - 2018-05-09 12:53:30 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 12:53:30 --> Model Class Initialized
INFO - 2018-05-09 12:53:30 --> Final output sent to browser
DEBUG - 2018-05-09 12:53:30 --> Total execution time: 0.1130
INFO - 2018-05-09 07:23:30 --> Language Class Initialized
INFO - 2018-05-09 07:23:30 --> Config Class Initialized
INFO - 2018-05-09 07:23:30 --> Loader Class Initialized
INFO - 2018-05-09 12:53:30 --> Helper loaded: url_helper
INFO - 2018-05-09 12:53:30 --> Helper loaded: notification_helper
INFO - 2018-05-09 12:53:30 --> Helper loaded: settings_helper
INFO - 2018-05-09 12:53:30 --> Helper loaded: permission_helper
INFO - 2018-05-09 12:53:30 --> Helper loaded: users_helper
INFO - 2018-05-09 12:53:30 --> Database Driver Class Initialized
DEBUG - 2018-05-09 12:53:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 12:53:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 12:53:30 --> Helper loaded: form_helper
INFO - 2018-05-09 12:53:30 --> Form Validation Class Initialized
INFO - 2018-05-09 12:53:30 --> Controller Class Initialized
INFO - 2018-05-09 12:53:30 --> Model Class Initialized
INFO - 2018-05-09 12:53:30 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 12:53:30 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 12:53:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 12:53:30 --> Model Class Initialized
INFO - 2018-05-09 12:53:30 --> Model Class Initialized
INFO - 2018-05-09 12:53:30 --> Model Class Initialized
INFO - 2018-05-09 12:53:30 --> Model Class Initialized
INFO - 2018-05-09 12:53:30 --> Model Class Initialized
INFO - 2018-05-09 12:53:30 --> Model Class Initialized
INFO - 2018-05-09 12:53:30 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 12:53:30 --> Final output sent to browser
DEBUG - 2018-05-09 12:53:30 --> Total execution time: 0.1259
INFO - 2018-05-09 07:23:32 --> Config Class Initialized
INFO - 2018-05-09 07:23:32 --> Hooks Class Initialized
DEBUG - 2018-05-09 07:23:32 --> UTF-8 Support Enabled
INFO - 2018-05-09 07:23:32 --> Utf8 Class Initialized
INFO - 2018-05-09 07:23:32 --> URI Class Initialized
INFO - 2018-05-09 07:23:32 --> Router Class Initialized
INFO - 2018-05-09 07:23:32 --> Output Class Initialized
INFO - 2018-05-09 07:23:32 --> Security Class Initialized
DEBUG - 2018-05-09 07:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 07:23:32 --> Input Class Initialized
INFO - 2018-05-09 07:23:32 --> Language Class Initialized
INFO - 2018-05-09 07:23:32 --> Language Class Initialized
INFO - 2018-05-09 07:23:32 --> Config Class Initialized
INFO - 2018-05-09 07:23:32 --> Loader Class Initialized
INFO - 2018-05-09 12:53:32 --> Helper loaded: url_helper
INFO - 2018-05-09 12:53:32 --> Helper loaded: notification_helper
INFO - 2018-05-09 12:53:32 --> Helper loaded: settings_helper
INFO - 2018-05-09 12:53:32 --> Helper loaded: permission_helper
INFO - 2018-05-09 12:53:32 --> Helper loaded: users_helper
INFO - 2018-05-09 12:53:32 --> Database Driver Class Initialized
DEBUG - 2018-05-09 12:53:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 12:53:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 12:53:32 --> Helper loaded: form_helper
INFO - 2018-05-09 12:53:32 --> Form Validation Class Initialized
INFO - 2018-05-09 12:53:32 --> Controller Class Initialized
INFO - 2018-05-09 12:53:32 --> Model Class Initialized
INFO - 2018-05-09 12:53:32 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 12:53:32 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 12:53:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 12:53:32 --> Model Class Initialized
INFO - 2018-05-09 12:53:32 --> Model Class Initialized
INFO - 2018-05-09 12:53:32 --> Model Class Initialized
INFO - 2018-05-09 12:53:32 --> Model Class Initialized
INFO - 2018-05-09 12:53:32 --> Final output sent to browser
DEBUG - 2018-05-09 12:53:32 --> Total execution time: 0.1035
INFO - 2018-05-09 07:23:40 --> Config Class Initialized
INFO - 2018-05-09 07:23:40 --> Hooks Class Initialized
DEBUG - 2018-05-09 07:23:40 --> UTF-8 Support Enabled
INFO - 2018-05-09 07:23:40 --> Utf8 Class Initialized
INFO - 2018-05-09 07:23:40 --> URI Class Initialized
INFO - 2018-05-09 07:23:40 --> Router Class Initialized
INFO - 2018-05-09 07:23:40 --> Output Class Initialized
INFO - 2018-05-09 07:23:40 --> Security Class Initialized
DEBUG - 2018-05-09 07:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 07:23:40 --> Input Class Initialized
INFO - 2018-05-09 07:23:40 --> Language Class Initialized
INFO - 2018-05-09 07:23:40 --> Language Class Initialized
INFO - 2018-05-09 07:23:40 --> Config Class Initialized
INFO - 2018-05-09 07:23:40 --> Loader Class Initialized
INFO - 2018-05-09 12:53:40 --> Helper loaded: url_helper
INFO - 2018-05-09 12:53:40 --> Helper loaded: notification_helper
INFO - 2018-05-09 12:53:40 --> Helper loaded: settings_helper
INFO - 2018-05-09 12:53:40 --> Helper loaded: permission_helper
INFO - 2018-05-09 12:53:40 --> Helper loaded: users_helper
INFO - 2018-05-09 12:53:40 --> Database Driver Class Initialized
DEBUG - 2018-05-09 12:53:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 12:53:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 12:53:40 --> Helper loaded: form_helper
INFO - 2018-05-09 12:53:40 --> Form Validation Class Initialized
INFO - 2018-05-09 12:53:40 --> Controller Class Initialized
INFO - 2018-05-09 12:53:40 --> Model Class Initialized
INFO - 2018-05-09 12:53:40 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 12:53:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 12:53:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 12:53:40 --> Model Class Initialized
INFO - 2018-05-09 12:53:40 --> Model Class Initialized
INFO - 2018-05-09 12:53:40 --> Model Class Initialized
INFO - 2018-05-09 12:53:40 --> Model Class Initialized
INFO - 2018-05-09 12:53:40 --> Model Class Initialized
INFO - 2018-05-09 12:53:40 --> Model Class Initialized
INFO - 2018-05-09 12:53:40 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-05-09 12:53:40 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 800
ERROR - 2018-05-09 12:53:40 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 810
INFO - 2018-05-09 12:53:40 --> Final output sent to browser
DEBUG - 2018-05-09 12:53:40 --> Total execution time: 0.1318
INFO - 2018-05-09 07:26:29 --> Config Class Initialized
INFO - 2018-05-09 07:26:29 --> Hooks Class Initialized
DEBUG - 2018-05-09 07:26:29 --> UTF-8 Support Enabled
INFO - 2018-05-09 07:26:29 --> Utf8 Class Initialized
INFO - 2018-05-09 07:26:29 --> URI Class Initialized
INFO - 2018-05-09 07:26:29 --> Router Class Initialized
INFO - 2018-05-09 07:26:29 --> Output Class Initialized
INFO - 2018-05-09 07:26:29 --> Security Class Initialized
DEBUG - 2018-05-09 07:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 07:26:29 --> Input Class Initialized
INFO - 2018-05-09 07:26:29 --> Language Class Initialized
INFO - 2018-05-09 07:26:29 --> Language Class Initialized
INFO - 2018-05-09 07:26:29 --> Config Class Initialized
INFO - 2018-05-09 07:26:29 --> Loader Class Initialized
INFO - 2018-05-09 12:56:29 --> Helper loaded: url_helper
INFO - 2018-05-09 12:56:29 --> Helper loaded: notification_helper
INFO - 2018-05-09 12:56:29 --> Helper loaded: settings_helper
INFO - 2018-05-09 12:56:29 --> Helper loaded: permission_helper
INFO - 2018-05-09 12:56:29 --> Helper loaded: users_helper
INFO - 2018-05-09 12:56:29 --> Database Driver Class Initialized
DEBUG - 2018-05-09 12:56:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 12:56:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 12:56:29 --> Helper loaded: form_helper
INFO - 2018-05-09 12:56:29 --> Form Validation Class Initialized
INFO - 2018-05-09 12:56:29 --> Controller Class Initialized
INFO - 2018-05-09 12:56:29 --> Model Class Initialized
INFO - 2018-05-09 12:56:29 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 12:56:29 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 12:56:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 12:56:29 --> Model Class Initialized
INFO - 2018-05-09 12:56:29 --> Model Class Initialized
INFO - 2018-05-09 12:56:29 --> Model Class Initialized
INFO - 2018-05-09 12:56:29 --> Model Class Initialized
INFO - 2018-05-09 12:56:29 --> Model Class Initialized
INFO - 2018-05-09 12:56:29 --> Model Class Initialized
INFO - 2018-05-09 12:56:29 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 12:56:29 --> Final output sent to browser
DEBUG - 2018-05-09 12:56:29 --> Total execution time: 0.1223
INFO - 2018-05-09 07:26:30 --> Config Class Initialized
INFO - 2018-05-09 07:26:30 --> Hooks Class Initialized
DEBUG - 2018-05-09 07:26:30 --> UTF-8 Support Enabled
INFO - 2018-05-09 07:26:30 --> Utf8 Class Initialized
INFO - 2018-05-09 07:26:30 --> URI Class Initialized
INFO - 2018-05-09 07:26:30 --> Router Class Initialized
INFO - 2018-05-09 07:26:30 --> Output Class Initialized
INFO - 2018-05-09 07:26:30 --> Security Class Initialized
DEBUG - 2018-05-09 07:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 07:26:30 --> Input Class Initialized
INFO - 2018-05-09 07:26:30 --> Language Class Initialized
INFO - 2018-05-09 07:26:30 --> Language Class Initialized
INFO - 2018-05-09 07:26:30 --> Config Class Initialized
INFO - 2018-05-09 07:26:30 --> Loader Class Initialized
INFO - 2018-05-09 12:56:30 --> Helper loaded: url_helper
INFO - 2018-05-09 12:56:30 --> Helper loaded: notification_helper
INFO - 2018-05-09 12:56:30 --> Helper loaded: settings_helper
INFO - 2018-05-09 12:56:30 --> Helper loaded: permission_helper
INFO - 2018-05-09 12:56:30 --> Helper loaded: users_helper
INFO - 2018-05-09 12:56:30 --> Database Driver Class Initialized
DEBUG - 2018-05-09 12:56:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 12:56:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 12:56:30 --> Helper loaded: form_helper
INFO - 2018-05-09 12:56:30 --> Form Validation Class Initialized
INFO - 2018-05-09 12:56:30 --> Controller Class Initialized
INFO - 2018-05-09 12:56:30 --> Model Class Initialized
INFO - 2018-05-09 12:56:30 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 12:56:30 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 12:56:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 12:56:30 --> Model Class Initialized
INFO - 2018-05-09 12:56:30 --> Model Class Initialized
INFO - 2018-05-09 12:56:30 --> Model Class Initialized
INFO - 2018-05-09 12:56:30 --> Model Class Initialized
INFO - 2018-05-09 12:56:30 --> Model Class Initialized
INFO - 2018-05-09 12:56:30 --> Model Class Initialized
INFO - 2018-05-09 12:56:30 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 12:56:30 --> Final output sent to browser
DEBUG - 2018-05-09 12:56:30 --> Total execution time: 0.1100
INFO - 2018-05-09 07:26:43 --> Config Class Initialized
INFO - 2018-05-09 07:26:43 --> Hooks Class Initialized
DEBUG - 2018-05-09 07:26:43 --> UTF-8 Support Enabled
INFO - 2018-05-09 07:26:43 --> Utf8 Class Initialized
INFO - 2018-05-09 07:26:43 --> URI Class Initialized
INFO - 2018-05-09 07:26:43 --> Router Class Initialized
INFO - 2018-05-09 07:26:43 --> Output Class Initialized
INFO - 2018-05-09 07:26:43 --> Security Class Initialized
DEBUG - 2018-05-09 07:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 07:26:43 --> Input Class Initialized
INFO - 2018-05-09 07:26:43 --> Language Class Initialized
INFO - 2018-05-09 07:26:43 --> Config Class Initialized
INFO - 2018-05-09 07:26:43 --> Hooks Class Initialized
DEBUG - 2018-05-09 07:26:43 --> UTF-8 Support Enabled
INFO - 2018-05-09 07:26:43 --> Utf8 Class Initialized
INFO - 2018-05-09 07:26:43 --> URI Class Initialized
INFO - 2018-05-09 07:26:43 --> Router Class Initialized
INFO - 2018-05-09 07:26:43 --> Language Class Initialized
INFO - 2018-05-09 07:26:43 --> Config Class Initialized
INFO - 2018-05-09 07:26:43 --> Loader Class Initialized
INFO - 2018-05-09 12:56:43 --> Helper loaded: url_helper
INFO - 2018-05-09 07:26:43 --> Output Class Initialized
INFO - 2018-05-09 12:56:43 --> Helper loaded: notification_helper
INFO - 2018-05-09 12:56:43 --> Helper loaded: settings_helper
INFO - 2018-05-09 12:56:43 --> Helper loaded: permission_helper
INFO - 2018-05-09 12:56:43 --> Helper loaded: users_helper
INFO - 2018-05-09 07:26:43 --> Security Class Initialized
DEBUG - 2018-05-09 07:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 07:26:43 --> Input Class Initialized
INFO - 2018-05-09 07:26:43 --> Language Class Initialized
INFO - 2018-05-09 12:56:43 --> Database Driver Class Initialized
DEBUG - 2018-05-09 12:56:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 12:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 12:56:43 --> Helper loaded: form_helper
INFO - 2018-05-09 12:56:43 --> Form Validation Class Initialized
INFO - 2018-05-09 12:56:43 --> Controller Class Initialized
INFO - 2018-05-09 07:26:43 --> Language Class Initialized
INFO - 2018-05-09 07:26:43 --> Config Class Initialized
INFO - 2018-05-09 07:26:43 --> Loader Class Initialized
INFO - 2018-05-09 12:56:43 --> Model Class Initialized
INFO - 2018-05-09 12:56:43 --> Helper loaded: inflector_helper
INFO - 2018-05-09 12:56:43 --> Helper loaded: url_helper
DEBUG - 2018-05-09 12:56:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 12:56:43 --> Helper loaded: notification_helper
INFO - 2018-05-09 12:56:43 --> Helper loaded: settings_helper
INFO - 2018-05-09 12:56:43 --> Helper loaded: permission_helper
INFO - 2018-05-09 12:56:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 12:56:43 --> Helper loaded: users_helper
INFO - 2018-05-09 12:56:43 --> Model Class Initialized
INFO - 2018-05-09 12:56:43 --> Model Class Initialized
INFO - 2018-05-09 12:56:43 --> Model Class Initialized
INFO - 2018-05-09 12:56:43 --> Model Class Initialized
INFO - 2018-05-09 12:56:43 --> Model Class Initialized
INFO - 2018-05-09 12:56:43 --> Model Class Initialized
INFO - 2018-05-09 12:56:43 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 12:56:43 --> Model Class Initialized
INFO - 2018-05-09 12:56:43 --> Final output sent to browser
DEBUG - 2018-05-09 12:56:43 --> Total execution time: 0.1128
INFO - 2018-05-09 12:56:43 --> Database Driver Class Initialized
DEBUG - 2018-05-09 12:56:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 12:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 12:56:43 --> Helper loaded: form_helper
INFO - 2018-05-09 12:56:43 --> Form Validation Class Initialized
INFO - 2018-05-09 12:56:43 --> Controller Class Initialized
INFO - 2018-05-09 12:56:43 --> Model Class Initialized
INFO - 2018-05-09 12:56:43 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 12:56:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 12:56:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 12:56:43 --> Model Class Initialized
INFO - 2018-05-09 12:56:43 --> Model Class Initialized
INFO - 2018-05-09 12:56:43 --> Model Class Initialized
INFO - 2018-05-09 12:56:43 --> Model Class Initialized
INFO - 2018-05-09 12:56:43 --> Model Class Initialized
INFO - 2018-05-09 12:56:43 --> Model Class Initialized
INFO - 2018-05-09 12:56:43 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 12:56:43 --> Final output sent to browser
DEBUG - 2018-05-09 12:56:43 --> Total execution time: 0.1577
INFO - 2018-05-09 07:26:45 --> Config Class Initialized
INFO - 2018-05-09 07:26:45 --> Hooks Class Initialized
DEBUG - 2018-05-09 07:26:45 --> UTF-8 Support Enabled
INFO - 2018-05-09 07:26:45 --> Utf8 Class Initialized
INFO - 2018-05-09 07:26:45 --> URI Class Initialized
INFO - 2018-05-09 07:26:45 --> Router Class Initialized
INFO - 2018-05-09 07:26:45 --> Output Class Initialized
INFO - 2018-05-09 07:26:45 --> Security Class Initialized
DEBUG - 2018-05-09 07:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 07:26:45 --> Input Class Initialized
INFO - 2018-05-09 07:26:45 --> Language Class Initialized
INFO - 2018-05-09 07:26:45 --> Language Class Initialized
INFO - 2018-05-09 07:26:45 --> Config Class Initialized
INFO - 2018-05-09 07:26:45 --> Loader Class Initialized
INFO - 2018-05-09 12:56:45 --> Helper loaded: url_helper
INFO - 2018-05-09 12:56:45 --> Helper loaded: notification_helper
INFO - 2018-05-09 12:56:45 --> Helper loaded: settings_helper
INFO - 2018-05-09 12:56:45 --> Helper loaded: permission_helper
INFO - 2018-05-09 12:56:45 --> Helper loaded: users_helper
INFO - 2018-05-09 12:56:45 --> Database Driver Class Initialized
DEBUG - 2018-05-09 12:56:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 12:56:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 12:56:45 --> Helper loaded: form_helper
INFO - 2018-05-09 12:56:45 --> Form Validation Class Initialized
INFO - 2018-05-09 12:56:45 --> Controller Class Initialized
INFO - 2018-05-09 12:56:45 --> Model Class Initialized
INFO - 2018-05-09 12:56:45 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 12:56:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 12:56:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 12:56:45 --> Model Class Initialized
INFO - 2018-05-09 12:56:45 --> Model Class Initialized
INFO - 2018-05-09 12:56:45 --> Model Class Initialized
INFO - 2018-05-09 12:56:45 --> Model Class Initialized
INFO - 2018-05-09 12:56:45 --> Model Class Initialized
INFO - 2018-05-09 12:56:45 --> Model Class Initialized
INFO - 2018-05-09 12:56:45 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 12:56:45 --> Final output sent to browser
DEBUG - 2018-05-09 12:56:45 --> Total execution time: 0.1157
INFO - 2018-05-09 07:26:47 --> Config Class Initialized
INFO - 2018-05-09 07:26:47 --> Hooks Class Initialized
DEBUG - 2018-05-09 07:26:47 --> UTF-8 Support Enabled
INFO - 2018-05-09 07:26:47 --> Utf8 Class Initialized
INFO - 2018-05-09 07:26:47 --> URI Class Initialized
INFO - 2018-05-09 07:26:47 --> Router Class Initialized
INFO - 2018-05-09 07:26:47 --> Output Class Initialized
INFO - 2018-05-09 07:26:47 --> Security Class Initialized
DEBUG - 2018-05-09 07:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 07:26:47 --> Input Class Initialized
INFO - 2018-05-09 07:26:47 --> Language Class Initialized
INFO - 2018-05-09 07:26:47 --> Language Class Initialized
INFO - 2018-05-09 07:26:47 --> Config Class Initialized
INFO - 2018-05-09 07:26:47 --> Loader Class Initialized
INFO - 2018-05-09 12:56:47 --> Helper loaded: url_helper
INFO - 2018-05-09 12:56:47 --> Helper loaded: notification_helper
INFO - 2018-05-09 12:56:47 --> Helper loaded: settings_helper
INFO - 2018-05-09 12:56:47 --> Helper loaded: permission_helper
INFO - 2018-05-09 12:56:47 --> Helper loaded: users_helper
INFO - 2018-05-09 12:56:47 --> Database Driver Class Initialized
DEBUG - 2018-05-09 12:56:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 12:56:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 12:56:47 --> Helper loaded: form_helper
INFO - 2018-05-09 12:56:47 --> Form Validation Class Initialized
INFO - 2018-05-09 12:56:47 --> Controller Class Initialized
INFO - 2018-05-09 12:56:47 --> Model Class Initialized
INFO - 2018-05-09 12:56:47 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 12:56:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 12:56:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 12:56:47 --> Model Class Initialized
INFO - 2018-05-09 12:56:47 --> Model Class Initialized
INFO - 2018-05-09 12:56:47 --> Model Class Initialized
INFO - 2018-05-09 12:56:47 --> Model Class Initialized
INFO - 2018-05-09 12:56:47 --> Model Class Initialized
INFO - 2018-05-09 12:56:47 --> Model Class Initialized
INFO - 2018-05-09 12:56:47 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 12:56:47 --> Final output sent to browser
DEBUG - 2018-05-09 12:56:47 --> Total execution time: 0.2405
INFO - 2018-05-09 07:28:43 --> Config Class Initialized
INFO - 2018-05-09 07:28:43 --> Hooks Class Initialized
DEBUG - 2018-05-09 07:28:43 --> UTF-8 Support Enabled
INFO - 2018-05-09 07:28:43 --> Utf8 Class Initialized
INFO - 2018-05-09 07:28:43 --> URI Class Initialized
INFO - 2018-05-09 07:28:43 --> Router Class Initialized
INFO - 2018-05-09 07:28:43 --> Output Class Initialized
INFO - 2018-05-09 07:28:43 --> Security Class Initialized
DEBUG - 2018-05-09 07:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 07:28:43 --> Input Class Initialized
INFO - 2018-05-09 07:28:43 --> Language Class Initialized
INFO - 2018-05-09 07:28:43 --> Language Class Initialized
INFO - 2018-05-09 07:28:43 --> Config Class Initialized
INFO - 2018-05-09 07:28:43 --> Loader Class Initialized
INFO - 2018-05-09 12:58:43 --> Helper loaded: url_helper
INFO - 2018-05-09 12:58:43 --> Helper loaded: notification_helper
INFO - 2018-05-09 12:58:43 --> Helper loaded: settings_helper
INFO - 2018-05-09 12:58:43 --> Helper loaded: permission_helper
INFO - 2018-05-09 12:58:43 --> Helper loaded: users_helper
INFO - 2018-05-09 12:58:43 --> Database Driver Class Initialized
DEBUG - 2018-05-09 12:58:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 12:58:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 07:28:43 --> Config Class Initialized
INFO - 2018-05-09 07:28:43 --> Hooks Class Initialized
INFO - 2018-05-09 12:58:43 --> Helper loaded: form_helper
INFO - 2018-05-09 12:58:43 --> Form Validation Class Initialized
INFO - 2018-05-09 12:58:43 --> Controller Class Initialized
DEBUG - 2018-05-09 07:28:43 --> UTF-8 Support Enabled
INFO - 2018-05-09 07:28:43 --> Utf8 Class Initialized
INFO - 2018-05-09 07:28:43 --> URI Class Initialized
INFO - 2018-05-09 07:28:43 --> Router Class Initialized
INFO - 2018-05-09 12:58:43 --> Model Class Initialized
INFO - 2018-05-09 12:58:43 --> Helper loaded: inflector_helper
INFO - 2018-05-09 07:28:43 --> Output Class Initialized
DEBUG - 2018-05-09 12:58:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 07:28:43 --> Security Class Initialized
INFO - 2018-05-09 12:58:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 12:58:43 --> Model Class Initialized
INFO - 2018-05-09 12:58:43 --> Model Class Initialized
DEBUG - 2018-05-09 07:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 07:28:43 --> Input Class Initialized
INFO - 2018-05-09 12:58:43 --> Model Class Initialized
INFO - 2018-05-09 12:58:43 --> Model Class Initialized
INFO - 2018-05-09 07:28:43 --> Language Class Initialized
INFO - 2018-05-09 12:58:43 --> Model Class Initialized
INFO - 2018-05-09 12:58:43 --> Model Class Initialized
INFO - 2018-05-09 12:58:43 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 12:58:43 --> Model Class Initialized
INFO - 2018-05-09 12:58:43 --> Final output sent to browser
DEBUG - 2018-05-09 12:58:43 --> Total execution time: 0.1109
INFO - 2018-05-09 07:28:44 --> Language Class Initialized
INFO - 2018-05-09 07:28:44 --> Config Class Initialized
INFO - 2018-05-09 07:28:44 --> Loader Class Initialized
INFO - 2018-05-09 12:58:44 --> Helper loaded: url_helper
INFO - 2018-05-09 12:58:44 --> Helper loaded: notification_helper
INFO - 2018-05-09 12:58:44 --> Helper loaded: settings_helper
INFO - 2018-05-09 12:58:44 --> Helper loaded: permission_helper
INFO - 2018-05-09 12:58:44 --> Helper loaded: users_helper
INFO - 2018-05-09 12:58:44 --> Database Driver Class Initialized
DEBUG - 2018-05-09 12:58:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 12:58:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 12:58:44 --> Helper loaded: form_helper
INFO - 2018-05-09 12:58:44 --> Form Validation Class Initialized
INFO - 2018-05-09 12:58:44 --> Controller Class Initialized
INFO - 2018-05-09 12:58:44 --> Model Class Initialized
INFO - 2018-05-09 12:58:44 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 12:58:44 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 12:58:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 12:58:44 --> Model Class Initialized
INFO - 2018-05-09 12:58:44 --> Model Class Initialized
INFO - 2018-05-09 12:58:44 --> Model Class Initialized
INFO - 2018-05-09 12:58:44 --> Model Class Initialized
INFO - 2018-05-09 12:58:44 --> Model Class Initialized
INFO - 2018-05-09 12:58:44 --> Model Class Initialized
INFO - 2018-05-09 12:58:44 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 12:58:44 --> Final output sent to browser
DEBUG - 2018-05-09 12:58:44 --> Total execution time: 0.1219
INFO - 2018-05-09 07:28:44 --> Config Class Initialized
INFO - 2018-05-09 07:28:44 --> Hooks Class Initialized
DEBUG - 2018-05-09 07:28:44 --> UTF-8 Support Enabled
INFO - 2018-05-09 07:28:44 --> Utf8 Class Initialized
INFO - 2018-05-09 07:28:44 --> URI Class Initialized
INFO - 2018-05-09 07:28:44 --> Router Class Initialized
INFO - 2018-05-09 07:28:44 --> Output Class Initialized
INFO - 2018-05-09 07:28:44 --> Security Class Initialized
DEBUG - 2018-05-09 07:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 07:28:44 --> Input Class Initialized
INFO - 2018-05-09 07:28:44 --> Language Class Initialized
INFO - 2018-05-09 07:28:44 --> Config Class Initialized
INFO - 2018-05-09 07:28:44 --> Hooks Class Initialized
DEBUG - 2018-05-09 07:28:44 --> UTF-8 Support Enabled
INFO - 2018-05-09 07:28:44 --> Utf8 Class Initialized
INFO - 2018-05-09 07:28:44 --> URI Class Initialized
INFO - 2018-05-09 07:28:44 --> Language Class Initialized
INFO - 2018-05-09 07:28:44 --> Config Class Initialized
INFO - 2018-05-09 07:28:44 --> Loader Class Initialized
INFO - 2018-05-09 07:28:44 --> Router Class Initialized
INFO - 2018-05-09 12:58:44 --> Helper loaded: url_helper
INFO - 2018-05-09 12:58:44 --> Helper loaded: notification_helper
INFO - 2018-05-09 07:28:44 --> Output Class Initialized
INFO - 2018-05-09 12:58:44 --> Helper loaded: settings_helper
INFO - 2018-05-09 12:58:44 --> Helper loaded: permission_helper
INFO - 2018-05-09 07:28:44 --> Security Class Initialized
INFO - 2018-05-09 12:58:44 --> Helper loaded: users_helper
DEBUG - 2018-05-09 07:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 07:28:44 --> Input Class Initialized
INFO - 2018-05-09 07:28:44 --> Language Class Initialized
INFO - 2018-05-09 12:58:44 --> Database Driver Class Initialized
INFO - 2018-05-09 07:28:44 --> Language Class Initialized
INFO - 2018-05-09 07:28:44 --> Config Class Initialized
INFO - 2018-05-09 07:28:44 --> Loader Class Initialized
INFO - 2018-05-09 12:58:44 --> Helper loaded: url_helper
INFO - 2018-05-09 12:58:44 --> Helper loaded: notification_helper
INFO - 2018-05-09 12:58:44 --> Helper loaded: settings_helper
DEBUG - 2018-05-09 12:58:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 12:58:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 12:58:44 --> Helper loaded: permission_helper
INFO - 2018-05-09 12:58:44 --> Helper loaded: users_helper
INFO - 2018-05-09 12:58:44 --> Helper loaded: form_helper
INFO - 2018-05-09 12:58:44 --> Form Validation Class Initialized
INFO - 2018-05-09 12:58:44 --> Controller Class Initialized
INFO - 2018-05-09 12:58:44 --> Database Driver Class Initialized
DEBUG - 2018-05-09 12:58:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 12:58:44 --> Model Class Initialized
INFO - 2018-05-09 12:58:44 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 12:58:44 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 12:58:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 12:58:44 --> Model Class Initialized
INFO - 2018-05-09 12:58:44 --> Model Class Initialized
INFO - 2018-05-09 12:58:44 --> Model Class Initialized
INFO - 2018-05-09 12:58:44 --> Model Class Initialized
INFO - 2018-05-09 12:58:44 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 12:58:44 --> Final output sent to browser
DEBUG - 2018-05-09 12:58:44 --> Total execution time: 0.1278
INFO - 2018-05-09 12:58:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 12:58:44 --> Helper loaded: form_helper
INFO - 2018-05-09 12:58:44 --> Form Validation Class Initialized
INFO - 2018-05-09 12:58:44 --> Controller Class Initialized
INFO - 2018-05-09 12:58:44 --> Model Class Initialized
INFO - 2018-05-09 12:58:44 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 12:58:44 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 12:58:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 12:58:44 --> Model Class Initialized
INFO - 2018-05-09 12:58:44 --> Model Class Initialized
INFO - 2018-05-09 12:58:44 --> Model Class Initialized
INFO - 2018-05-09 12:58:44 --> Model Class Initialized
INFO - 2018-05-09 12:58:44 --> Model Class Initialized
INFO - 2018-05-09 12:58:44 --> Model Class Initialized
INFO - 2018-05-09 12:58:44 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 12:58:44 --> Final output sent to browser
DEBUG - 2018-05-09 12:58:44 --> Total execution time: 0.1343
INFO - 2018-05-09 07:28:48 --> Config Class Initialized
INFO - 2018-05-09 07:28:48 --> Hooks Class Initialized
DEBUG - 2018-05-09 07:28:48 --> UTF-8 Support Enabled
INFO - 2018-05-09 07:28:48 --> Utf8 Class Initialized
INFO - 2018-05-09 07:28:48 --> URI Class Initialized
INFO - 2018-05-09 07:28:48 --> Router Class Initialized
INFO - 2018-05-09 07:28:48 --> Output Class Initialized
INFO - 2018-05-09 07:28:48 --> Security Class Initialized
DEBUG - 2018-05-09 07:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 07:28:48 --> Input Class Initialized
INFO - 2018-05-09 07:28:48 --> Language Class Initialized
INFO - 2018-05-09 07:28:48 --> Language Class Initialized
INFO - 2018-05-09 07:28:48 --> Config Class Initialized
INFO - 2018-05-09 07:28:48 --> Loader Class Initialized
INFO - 2018-05-09 12:58:48 --> Helper loaded: url_helper
INFO - 2018-05-09 12:58:48 --> Helper loaded: notification_helper
INFO - 2018-05-09 12:58:48 --> Helper loaded: settings_helper
INFO - 2018-05-09 12:58:48 --> Helper loaded: permission_helper
INFO - 2018-05-09 12:58:48 --> Helper loaded: users_helper
INFO - 2018-05-09 12:58:48 --> Database Driver Class Initialized
DEBUG - 2018-05-09 12:58:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 12:58:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 12:58:48 --> Helper loaded: form_helper
INFO - 2018-05-09 12:58:48 --> Form Validation Class Initialized
INFO - 2018-05-09 12:58:48 --> Controller Class Initialized
INFO - 2018-05-09 12:58:48 --> Model Class Initialized
INFO - 2018-05-09 12:58:48 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 12:58:48 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 12:58:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 12:58:48 --> Model Class Initialized
INFO - 2018-05-09 12:58:48 --> Model Class Initialized
INFO - 2018-05-09 12:58:48 --> Model Class Initialized
INFO - 2018-05-09 12:58:48 --> Model Class Initialized
INFO - 2018-05-09 12:58:48 --> Model Class Initialized
INFO - 2018-05-09 12:58:48 --> Model Class Initialized
INFO - 2018-05-09 12:58:48 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 12:58:48 --> Final output sent to browser
DEBUG - 2018-05-09 12:58:48 --> Total execution time: 0.1089
INFO - 2018-05-09 07:28:51 --> Config Class Initialized
INFO - 2018-05-09 07:28:51 --> Hooks Class Initialized
DEBUG - 2018-05-09 07:28:51 --> UTF-8 Support Enabled
INFO - 2018-05-09 07:28:51 --> Utf8 Class Initialized
INFO - 2018-05-09 07:28:51 --> URI Class Initialized
INFO - 2018-05-09 07:28:51 --> Router Class Initialized
INFO - 2018-05-09 07:28:51 --> Output Class Initialized
INFO - 2018-05-09 07:28:51 --> Security Class Initialized
DEBUG - 2018-05-09 07:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 07:28:51 --> Input Class Initialized
INFO - 2018-05-09 07:28:51 --> Language Class Initialized
INFO - 2018-05-09 07:28:51 --> Language Class Initialized
INFO - 2018-05-09 07:28:51 --> Config Class Initialized
INFO - 2018-05-09 07:28:51 --> Loader Class Initialized
INFO - 2018-05-09 12:58:51 --> Helper loaded: url_helper
INFO - 2018-05-09 12:58:51 --> Helper loaded: notification_helper
INFO - 2018-05-09 12:58:51 --> Helper loaded: settings_helper
INFO - 2018-05-09 12:58:51 --> Helper loaded: permission_helper
INFO - 2018-05-09 12:58:51 --> Helper loaded: users_helper
INFO - 2018-05-09 12:58:51 --> Database Driver Class Initialized
DEBUG - 2018-05-09 12:58:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 12:58:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 12:58:51 --> Helper loaded: form_helper
INFO - 2018-05-09 12:58:51 --> Form Validation Class Initialized
INFO - 2018-05-09 12:58:51 --> Controller Class Initialized
INFO - 2018-05-09 12:58:51 --> Model Class Initialized
INFO - 2018-05-09 12:58:51 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 12:58:51 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 12:58:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 12:58:51 --> Model Class Initialized
INFO - 2018-05-09 12:58:51 --> Model Class Initialized
INFO - 2018-05-09 12:58:51 --> Model Class Initialized
INFO - 2018-05-09 12:58:51 --> Model Class Initialized
INFO - 2018-05-09 12:58:51 --> Model Class Initialized
INFO - 2018-05-09 12:58:51 --> Model Class Initialized
INFO - 2018-05-09 12:58:51 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 12:58:51 --> Final output sent to browser
DEBUG - 2018-05-09 12:58:51 --> Total execution time: 0.1342
INFO - 2018-05-09 07:30:37 --> Config Class Initialized
INFO - 2018-05-09 07:30:37 --> Hooks Class Initialized
DEBUG - 2018-05-09 07:30:37 --> UTF-8 Support Enabled
INFO - 2018-05-09 07:30:37 --> Utf8 Class Initialized
INFO - 2018-05-09 07:30:37 --> URI Class Initialized
INFO - 2018-05-09 07:30:37 --> Router Class Initialized
INFO - 2018-05-09 07:30:37 --> Output Class Initialized
INFO - 2018-05-09 07:30:37 --> Security Class Initialized
INFO - 2018-05-09 07:30:37 --> Config Class Initialized
INFO - 2018-05-09 07:30:37 --> Hooks Class Initialized
DEBUG - 2018-05-09 07:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 07:30:37 --> Input Class Initialized
INFO - 2018-05-09 07:30:37 --> Language Class Initialized
DEBUG - 2018-05-09 07:30:37 --> UTF-8 Support Enabled
INFO - 2018-05-09 07:30:37 --> Utf8 Class Initialized
INFO - 2018-05-09 07:30:37 --> URI Class Initialized
INFO - 2018-05-09 07:30:37 --> Router Class Initialized
INFO - 2018-05-09 07:30:37 --> Output Class Initialized
INFO - 2018-05-09 07:30:37 --> Security Class Initialized
DEBUG - 2018-05-09 07:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 07:30:37 --> Input Class Initialized
INFO - 2018-05-09 07:30:37 --> Language Class Initialized
INFO - 2018-05-09 07:30:37 --> Language Class Initialized
INFO - 2018-05-09 07:30:37 --> Config Class Initialized
INFO - 2018-05-09 07:30:37 --> Loader Class Initialized
INFO - 2018-05-09 13:00:37 --> Helper loaded: url_helper
INFO - 2018-05-09 13:00:37 --> Helper loaded: notification_helper
INFO - 2018-05-09 13:00:37 --> Helper loaded: settings_helper
INFO - 2018-05-09 13:00:37 --> Helper loaded: permission_helper
INFO - 2018-05-09 13:00:37 --> Helper loaded: users_helper
INFO - 2018-05-09 07:30:37 --> Language Class Initialized
INFO - 2018-05-09 07:30:37 --> Config Class Initialized
INFO - 2018-05-09 07:30:37 --> Loader Class Initialized
INFO - 2018-05-09 13:00:37 --> Helper loaded: url_helper
INFO - 2018-05-09 13:00:37 --> Helper loaded: notification_helper
INFO - 2018-05-09 13:00:37 --> Helper loaded: settings_helper
INFO - 2018-05-09 13:00:37 --> Database Driver Class Initialized
INFO - 2018-05-09 13:00:37 --> Helper loaded: permission_helper
INFO - 2018-05-09 13:00:37 --> Helper loaded: users_helper
DEBUG - 2018-05-09 13:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 13:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 13:00:37 --> Helper loaded: form_helper
INFO - 2018-05-09 13:00:37 --> Form Validation Class Initialized
INFO - 2018-05-09 13:00:37 --> Controller Class Initialized
INFO - 2018-05-09 13:00:37 --> Database Driver Class Initialized
DEBUG - 2018-05-09 13:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 13:00:37 --> Model Class Initialized
INFO - 2018-05-09 13:00:37 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 13:00:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 13:00:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 13:00:37 --> Model Class Initialized
INFO - 2018-05-09 13:00:37 --> Model Class Initialized
INFO - 2018-05-09 13:00:37 --> Model Class Initialized
INFO - 2018-05-09 13:00:37 --> Model Class Initialized
INFO - 2018-05-09 13:00:37 --> Model Class Initialized
INFO - 2018-05-09 13:00:37 --> Model Class Initialized
INFO - 2018-05-09 13:00:37 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 13:00:37 --> Model Class Initialized
INFO - 2018-05-09 13:00:37 --> Final output sent to browser
DEBUG - 2018-05-09 13:00:37 --> Total execution time: 0.1068
INFO - 2018-05-09 13:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 13:00:37 --> Helper loaded: form_helper
INFO - 2018-05-09 13:00:37 --> Form Validation Class Initialized
INFO - 2018-05-09 13:00:37 --> Controller Class Initialized
INFO - 2018-05-09 13:00:37 --> Model Class Initialized
INFO - 2018-05-09 13:00:37 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 13:00:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 13:00:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 13:00:37 --> Model Class Initialized
INFO - 2018-05-09 13:00:37 --> Model Class Initialized
INFO - 2018-05-09 13:00:37 --> Model Class Initialized
INFO - 2018-05-09 13:00:37 --> Model Class Initialized
INFO - 2018-05-09 13:00:37 --> Model Class Initialized
INFO - 2018-05-09 13:00:37 --> Model Class Initialized
INFO - 2018-05-09 13:00:37 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 13:00:37 --> Final output sent to browser
DEBUG - 2018-05-09 13:00:37 --> Total execution time: 0.1331
INFO - 2018-05-09 07:30:39 --> Config Class Initialized
INFO - 2018-05-09 07:30:39 --> Hooks Class Initialized
DEBUG - 2018-05-09 07:30:39 --> UTF-8 Support Enabled
INFO - 2018-05-09 07:30:39 --> Utf8 Class Initialized
INFO - 2018-05-09 07:30:39 --> URI Class Initialized
INFO - 2018-05-09 07:30:39 --> Router Class Initialized
INFO - 2018-05-09 07:30:39 --> Output Class Initialized
INFO - 2018-05-09 07:30:39 --> Security Class Initialized
DEBUG - 2018-05-09 07:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 07:30:39 --> Input Class Initialized
INFO - 2018-05-09 07:30:39 --> Language Class Initialized
INFO - 2018-05-09 07:30:39 --> Language Class Initialized
INFO - 2018-05-09 07:30:39 --> Config Class Initialized
INFO - 2018-05-09 07:30:39 --> Loader Class Initialized
INFO - 2018-05-09 13:00:39 --> Helper loaded: url_helper
INFO - 2018-05-09 13:00:39 --> Helper loaded: notification_helper
INFO - 2018-05-09 13:00:39 --> Helper loaded: settings_helper
INFO - 2018-05-09 13:00:39 --> Helper loaded: permission_helper
INFO - 2018-05-09 13:00:39 --> Helper loaded: users_helper
INFO - 2018-05-09 13:00:39 --> Database Driver Class Initialized
DEBUG - 2018-05-09 13:00:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 13:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 13:00:39 --> Helper loaded: form_helper
INFO - 2018-05-09 13:00:39 --> Form Validation Class Initialized
INFO - 2018-05-09 13:00:39 --> Controller Class Initialized
INFO - 2018-05-09 13:00:39 --> Model Class Initialized
INFO - 2018-05-09 13:00:39 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 13:00:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 13:00:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 13:00:39 --> Model Class Initialized
INFO - 2018-05-09 13:00:39 --> Model Class Initialized
INFO - 2018-05-09 13:00:39 --> Model Class Initialized
INFO - 2018-05-09 13:00:39 --> Model Class Initialized
INFO - 2018-05-09 13:00:39 --> Model Class Initialized
INFO - 2018-05-09 13:00:39 --> Model Class Initialized
INFO - 2018-05-09 13:00:39 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-05-09 13:00:39 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 800
ERROR - 2018-05-09 13:00:39 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 810
INFO - 2018-05-09 13:00:39 --> Final output sent to browser
DEBUG - 2018-05-09 13:00:39 --> Total execution time: 0.1292
INFO - 2018-05-09 07:30:47 --> Config Class Initialized
INFO - 2018-05-09 07:30:47 --> Hooks Class Initialized
DEBUG - 2018-05-09 07:30:47 --> UTF-8 Support Enabled
INFO - 2018-05-09 07:30:47 --> Utf8 Class Initialized
INFO - 2018-05-09 07:30:47 --> URI Class Initialized
INFO - 2018-05-09 07:30:47 --> Router Class Initialized
INFO - 2018-05-09 07:30:47 --> Output Class Initialized
INFO - 2018-05-09 07:30:47 --> Security Class Initialized
DEBUG - 2018-05-09 07:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 07:30:47 --> Input Class Initialized
INFO - 2018-05-09 07:30:47 --> Language Class Initialized
INFO - 2018-05-09 07:30:47 --> Language Class Initialized
INFO - 2018-05-09 07:30:47 --> Config Class Initialized
INFO - 2018-05-09 07:30:47 --> Loader Class Initialized
INFO - 2018-05-09 13:00:47 --> Helper loaded: url_helper
INFO - 2018-05-09 13:00:47 --> Helper loaded: notification_helper
INFO - 2018-05-09 13:00:47 --> Helper loaded: settings_helper
INFO - 2018-05-09 13:00:47 --> Helper loaded: permission_helper
INFO - 2018-05-09 13:00:47 --> Helper loaded: users_helper
INFO - 2018-05-09 13:00:47 --> Database Driver Class Initialized
DEBUG - 2018-05-09 13:00:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 13:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 13:00:47 --> Helper loaded: form_helper
INFO - 2018-05-09 13:00:47 --> Form Validation Class Initialized
INFO - 2018-05-09 13:00:47 --> Controller Class Initialized
INFO - 2018-05-09 13:00:47 --> Model Class Initialized
INFO - 2018-05-09 13:00:47 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 13:00:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 13:00:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 13:00:47 --> Model Class Initialized
INFO - 2018-05-09 13:00:47 --> Model Class Initialized
INFO - 2018-05-09 13:00:47 --> Model Class Initialized
INFO - 2018-05-09 13:00:47 --> Model Class Initialized
INFO - 2018-05-09 13:00:47 --> Final output sent to browser
DEBUG - 2018-05-09 13:00:47 --> Total execution time: 0.1011
INFO - 2018-05-09 07:31:05 --> Config Class Initialized
INFO - 2018-05-09 07:31:05 --> Hooks Class Initialized
DEBUG - 2018-05-09 07:31:05 --> UTF-8 Support Enabled
INFO - 2018-05-09 07:31:05 --> Utf8 Class Initialized
INFO - 2018-05-09 07:31:05 --> URI Class Initialized
INFO - 2018-05-09 07:31:05 --> Router Class Initialized
INFO - 2018-05-09 07:31:05 --> Output Class Initialized
INFO - 2018-05-09 07:31:05 --> Security Class Initialized
DEBUG - 2018-05-09 07:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 07:31:05 --> Input Class Initialized
INFO - 2018-05-09 07:31:05 --> Language Class Initialized
INFO - 2018-05-09 07:31:05 --> Language Class Initialized
INFO - 2018-05-09 07:31:05 --> Config Class Initialized
INFO - 2018-05-09 07:31:05 --> Loader Class Initialized
INFO - 2018-05-09 13:01:05 --> Helper loaded: url_helper
INFO - 2018-05-09 13:01:05 --> Helper loaded: notification_helper
INFO - 2018-05-09 13:01:05 --> Helper loaded: settings_helper
INFO - 2018-05-09 13:01:05 --> Helper loaded: permission_helper
INFO - 2018-05-09 13:01:05 --> Helper loaded: users_helper
INFO - 2018-05-09 13:01:05 --> Database Driver Class Initialized
DEBUG - 2018-05-09 13:01:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 13:01:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 13:01:05 --> Helper loaded: form_helper
INFO - 2018-05-09 13:01:05 --> Form Validation Class Initialized
INFO - 2018-05-09 13:01:05 --> Controller Class Initialized
INFO - 2018-05-09 13:01:05 --> Model Class Initialized
INFO - 2018-05-09 13:01:05 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 13:01:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 13:01:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 13:01:05 --> Model Class Initialized
INFO - 2018-05-09 13:01:05 --> Model Class Initialized
INFO - 2018-05-09 13:01:05 --> Model Class Initialized
INFO - 2018-05-09 13:01:05 --> Model Class Initialized
INFO - 2018-05-09 13:01:05 --> Model Class Initialized
INFO - 2018-05-09 13:01:05 --> Model Class Initialized
INFO - 2018-05-09 13:01:05 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-05-09 13:01:05 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 800
ERROR - 2018-05-09 13:01:05 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 810
INFO - 2018-05-09 13:01:05 --> Final output sent to browser
DEBUG - 2018-05-09 13:01:05 --> Total execution time: 0.1493
INFO - 2018-05-09 07:31:12 --> Config Class Initialized
INFO - 2018-05-09 07:31:12 --> Hooks Class Initialized
DEBUG - 2018-05-09 07:31:12 --> UTF-8 Support Enabled
INFO - 2018-05-09 07:31:12 --> Utf8 Class Initialized
INFO - 2018-05-09 07:31:12 --> URI Class Initialized
INFO - 2018-05-09 07:31:12 --> Router Class Initialized
INFO - 2018-05-09 07:31:12 --> Output Class Initialized
INFO - 2018-05-09 07:31:12 --> Security Class Initialized
DEBUG - 2018-05-09 07:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 07:31:12 --> Input Class Initialized
INFO - 2018-05-09 07:31:12 --> Language Class Initialized
INFO - 2018-05-09 07:31:12 --> Language Class Initialized
INFO - 2018-05-09 07:31:12 --> Config Class Initialized
INFO - 2018-05-09 07:31:12 --> Loader Class Initialized
INFO - 2018-05-09 13:01:12 --> Helper loaded: url_helper
INFO - 2018-05-09 13:01:12 --> Helper loaded: notification_helper
INFO - 2018-05-09 13:01:12 --> Helper loaded: settings_helper
INFO - 2018-05-09 13:01:12 --> Helper loaded: permission_helper
INFO - 2018-05-09 13:01:12 --> Helper loaded: users_helper
INFO - 2018-05-09 13:01:12 --> Database Driver Class Initialized
DEBUG - 2018-05-09 13:01:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 13:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 13:01:12 --> Helper loaded: form_helper
INFO - 2018-05-09 13:01:12 --> Form Validation Class Initialized
INFO - 2018-05-09 13:01:12 --> Controller Class Initialized
INFO - 2018-05-09 13:01:12 --> Model Class Initialized
INFO - 2018-05-09 13:01:12 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 13:01:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 13:01:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 13:01:12 --> Model Class Initialized
INFO - 2018-05-09 13:01:12 --> Model Class Initialized
INFO - 2018-05-09 13:01:13 --> Model Class Initialized
INFO - 2018-05-09 13:01:13 --> Model Class Initialized
INFO - 2018-05-09 13:01:13 --> Final output sent to browser
DEBUG - 2018-05-09 13:01:13 --> Total execution time: 0.0984
INFO - 2018-05-09 07:31:32 --> Config Class Initialized
INFO - 2018-05-09 07:31:32 --> Hooks Class Initialized
DEBUG - 2018-05-09 07:31:32 --> UTF-8 Support Enabled
INFO - 2018-05-09 07:31:32 --> Utf8 Class Initialized
INFO - 2018-05-09 07:31:32 --> URI Class Initialized
INFO - 2018-05-09 07:31:32 --> Router Class Initialized
INFO - 2018-05-09 07:31:32 --> Output Class Initialized
INFO - 2018-05-09 07:31:32 --> Security Class Initialized
DEBUG - 2018-05-09 07:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 07:31:32 --> Input Class Initialized
INFO - 2018-05-09 07:31:32 --> Language Class Initialized
INFO - 2018-05-09 07:31:32 --> Language Class Initialized
INFO - 2018-05-09 07:31:32 --> Config Class Initialized
INFO - 2018-05-09 07:31:32 --> Loader Class Initialized
INFO - 2018-05-09 13:01:32 --> Helper loaded: url_helper
INFO - 2018-05-09 13:01:32 --> Helper loaded: notification_helper
INFO - 2018-05-09 13:01:32 --> Helper loaded: settings_helper
INFO - 2018-05-09 13:01:32 --> Helper loaded: permission_helper
INFO - 2018-05-09 13:01:32 --> Helper loaded: users_helper
INFO - 2018-05-09 13:01:32 --> Database Driver Class Initialized
DEBUG - 2018-05-09 13:01:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 13:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 13:01:32 --> Helper loaded: form_helper
INFO - 2018-05-09 13:01:32 --> Form Validation Class Initialized
INFO - 2018-05-09 13:01:32 --> Controller Class Initialized
INFO - 2018-05-09 13:01:32 --> Model Class Initialized
INFO - 2018-05-09 13:01:32 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 13:01:32 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 13:01:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 13:01:32 --> Model Class Initialized
INFO - 2018-05-09 13:01:32 --> Model Class Initialized
INFO - 2018-05-09 13:01:32 --> Model Class Initialized
INFO - 2018-05-09 13:01:32 --> Model Class Initialized
INFO - 2018-05-09 13:01:32 --> Final output sent to browser
DEBUG - 2018-05-09 13:01:32 --> Total execution time: 0.0980
INFO - 2018-05-09 08:18:05 --> Config Class Initialized
INFO - 2018-05-09 08:18:05 --> Hooks Class Initialized
DEBUG - 2018-05-09 08:18:05 --> UTF-8 Support Enabled
INFO - 2018-05-09 08:18:05 --> Utf8 Class Initialized
INFO - 2018-05-09 08:18:05 --> URI Class Initialized
INFO - 2018-05-09 08:18:05 --> Router Class Initialized
INFO - 2018-05-09 08:18:05 --> Output Class Initialized
INFO - 2018-05-09 08:18:05 --> Security Class Initialized
DEBUG - 2018-05-09 08:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 08:18:05 --> Input Class Initialized
INFO - 2018-05-09 08:18:05 --> Language Class Initialized
INFO - 2018-05-09 08:18:05 --> Language Class Initialized
INFO - 2018-05-09 08:18:05 --> Config Class Initialized
INFO - 2018-05-09 08:18:05 --> Loader Class Initialized
INFO - 2018-05-09 13:48:05 --> Helper loaded: url_helper
INFO - 2018-05-09 13:48:05 --> Helper loaded: notification_helper
INFO - 2018-05-09 13:48:05 --> Helper loaded: settings_helper
INFO - 2018-05-09 13:48:05 --> Helper loaded: permission_helper
INFO - 2018-05-09 13:48:05 --> Helper loaded: users_helper
INFO - 2018-05-09 13:48:05 --> Database Driver Class Initialized
DEBUG - 2018-05-09 13:48:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 13:48:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 13:48:06 --> Helper loaded: form_helper
INFO - 2018-05-09 13:48:06 --> Form Validation Class Initialized
INFO - 2018-05-09 13:48:06 --> Controller Class Initialized
INFO - 2018-05-09 13:48:06 --> Model Class Initialized
INFO - 2018-05-09 13:48:06 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 13:48:06 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 13:48:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 13:48:06 --> Model Class Initialized
INFO - 2018-05-09 13:48:06 --> Model Class Initialized
INFO - 2018-05-09 13:48:06 --> Model Class Initialized
INFO - 2018-05-09 13:48:06 --> Model Class Initialized
INFO - 2018-05-09 13:48:06 --> Final output sent to browser
DEBUG - 2018-05-09 13:48:06 --> Total execution time: 0.1239
INFO - 2018-05-09 08:18:10 --> Config Class Initialized
INFO - 2018-05-09 08:18:10 --> Hooks Class Initialized
DEBUG - 2018-05-09 08:18:10 --> UTF-8 Support Enabled
INFO - 2018-05-09 08:18:10 --> Utf8 Class Initialized
INFO - 2018-05-09 08:18:10 --> URI Class Initialized
INFO - 2018-05-09 08:18:10 --> Router Class Initialized
INFO - 2018-05-09 08:18:10 --> Output Class Initialized
INFO - 2018-05-09 08:18:10 --> Security Class Initialized
DEBUG - 2018-05-09 08:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 08:18:10 --> Input Class Initialized
INFO - 2018-05-09 08:18:10 --> Language Class Initialized
INFO - 2018-05-09 08:18:10 --> Language Class Initialized
INFO - 2018-05-09 08:18:10 --> Config Class Initialized
INFO - 2018-05-09 08:18:10 --> Loader Class Initialized
INFO - 2018-05-09 13:48:10 --> Helper loaded: url_helper
INFO - 2018-05-09 13:48:10 --> Helper loaded: notification_helper
INFO - 2018-05-09 13:48:10 --> Helper loaded: settings_helper
INFO - 2018-05-09 13:48:10 --> Helper loaded: permission_helper
INFO - 2018-05-09 13:48:10 --> Helper loaded: users_helper
INFO - 2018-05-09 13:48:10 --> Database Driver Class Initialized
DEBUG - 2018-05-09 13:48:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 13:48:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 13:48:10 --> Helper loaded: form_helper
INFO - 2018-05-09 13:48:10 --> Form Validation Class Initialized
INFO - 2018-05-09 13:48:10 --> Controller Class Initialized
INFO - 2018-05-09 13:48:10 --> Model Class Initialized
INFO - 2018-05-09 13:48:10 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 13:48:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 13:48:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 13:48:10 --> Model Class Initialized
INFO - 2018-05-09 13:48:10 --> Model Class Initialized
INFO - 2018-05-09 13:48:10 --> Model Class Initialized
INFO - 2018-05-09 13:48:10 --> Model Class Initialized
INFO - 2018-05-09 13:48:10 --> Model Class Initialized
INFO - 2018-05-09 13:48:10 --> Model Class Initialized
INFO - 2018-05-09 13:48:10 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 13:48:10 --> Final output sent to browser
DEBUG - 2018-05-09 13:48:10 --> Total execution time: 0.1392
INFO - 2018-05-09 08:18:11 --> Config Class Initialized
INFO - 2018-05-09 08:18:11 --> Hooks Class Initialized
DEBUG - 2018-05-09 08:18:11 --> UTF-8 Support Enabled
INFO - 2018-05-09 08:18:11 --> Utf8 Class Initialized
INFO - 2018-05-09 08:18:11 --> URI Class Initialized
INFO - 2018-05-09 08:18:11 --> Router Class Initialized
INFO - 2018-05-09 08:18:11 --> Output Class Initialized
INFO - 2018-05-09 08:18:11 --> Security Class Initialized
DEBUG - 2018-05-09 08:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 08:18:11 --> Input Class Initialized
INFO - 2018-05-09 08:18:11 --> Language Class Initialized
INFO - 2018-05-09 08:18:11 --> Language Class Initialized
INFO - 2018-05-09 08:18:11 --> Config Class Initialized
INFO - 2018-05-09 08:18:11 --> Loader Class Initialized
INFO - 2018-05-09 13:48:11 --> Helper loaded: url_helper
INFO - 2018-05-09 13:48:11 --> Helper loaded: notification_helper
INFO - 2018-05-09 13:48:11 --> Helper loaded: settings_helper
INFO - 2018-05-09 13:48:11 --> Helper loaded: permission_helper
INFO - 2018-05-09 13:48:11 --> Helper loaded: users_helper
INFO - 2018-05-09 13:48:11 --> Database Driver Class Initialized
DEBUG - 2018-05-09 13:48:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 13:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 13:48:11 --> Helper loaded: form_helper
INFO - 2018-05-09 13:48:11 --> Form Validation Class Initialized
INFO - 2018-05-09 13:48:11 --> Controller Class Initialized
INFO - 2018-05-09 13:48:11 --> Model Class Initialized
INFO - 2018-05-09 13:48:11 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 13:48:11 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 13:48:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 13:48:11 --> Model Class Initialized
INFO - 2018-05-09 13:48:11 --> Model Class Initialized
INFO - 2018-05-09 13:48:11 --> Model Class Initialized
INFO - 2018-05-09 13:48:11 --> Model Class Initialized
INFO - 2018-05-09 13:48:11 --> Model Class Initialized
INFO - 2018-05-09 13:48:11 --> Model Class Initialized
INFO - 2018-05-09 13:48:11 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 13:48:11 --> Final output sent to browser
DEBUG - 2018-05-09 13:48:11 --> Total execution time: 0.1331
INFO - 2018-05-09 08:18:25 --> Config Class Initialized
INFO - 2018-05-09 08:18:25 --> Hooks Class Initialized
INFO - 2018-05-09 08:18:25 --> Config Class Initialized
DEBUG - 2018-05-09 08:18:25 --> UTF-8 Support Enabled
INFO - 2018-05-09 08:18:25 --> Utf8 Class Initialized
INFO - 2018-05-09 08:18:25 --> Hooks Class Initialized
INFO - 2018-05-09 08:18:25 --> URI Class Initialized
DEBUG - 2018-05-09 08:18:25 --> UTF-8 Support Enabled
INFO - 2018-05-09 08:18:25 --> Utf8 Class Initialized
INFO - 2018-05-09 08:18:25 --> Router Class Initialized
INFO - 2018-05-09 08:18:25 --> URI Class Initialized
INFO - 2018-05-09 08:18:26 --> Output Class Initialized
INFO - 2018-05-09 08:18:26 --> Security Class Initialized
INFO - 2018-05-09 08:18:26 --> Router Class Initialized
DEBUG - 2018-05-09 08:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 08:18:26 --> Input Class Initialized
INFO - 2018-05-09 08:18:26 --> Language Class Initialized
INFO - 2018-05-09 08:18:26 --> Output Class Initialized
INFO - 2018-05-09 08:18:26 --> Security Class Initialized
DEBUG - 2018-05-09 08:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 08:18:26 --> Input Class Initialized
INFO - 2018-05-09 08:18:26 --> Language Class Initialized
INFO - 2018-05-09 08:18:26 --> Language Class Initialized
INFO - 2018-05-09 08:18:26 --> Config Class Initialized
INFO - 2018-05-09 08:18:26 --> Loader Class Initialized
INFO - 2018-05-09 13:48:26 --> Helper loaded: url_helper
INFO - 2018-05-09 13:48:26 --> Helper loaded: notification_helper
INFO - 2018-05-09 13:48:26 --> Helper loaded: settings_helper
INFO - 2018-05-09 13:48:26 --> Helper loaded: permission_helper
INFO - 2018-05-09 13:48:26 --> Helper loaded: users_helper
INFO - 2018-05-09 08:18:26 --> Language Class Initialized
INFO - 2018-05-09 08:18:26 --> Config Class Initialized
INFO - 2018-05-09 08:18:26 --> Loader Class Initialized
INFO - 2018-05-09 13:48:26 --> Helper loaded: url_helper
INFO - 2018-05-09 13:48:26 --> Helper loaded: notification_helper
INFO - 2018-05-09 13:48:26 --> Helper loaded: settings_helper
INFO - 2018-05-09 13:48:26 --> Helper loaded: permission_helper
INFO - 2018-05-09 13:48:26 --> Helper loaded: users_helper
INFO - 2018-05-09 13:48:26 --> Database Driver Class Initialized
DEBUG - 2018-05-09 13:48:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 13:48:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 13:48:26 --> Database Driver Class Initialized
INFO - 2018-05-09 13:48:26 --> Helper loaded: form_helper
INFO - 2018-05-09 13:48:26 --> Form Validation Class Initialized
INFO - 2018-05-09 13:48:26 --> Controller Class Initialized
DEBUG - 2018-05-09 13:48:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 13:48:26 --> Model Class Initialized
INFO - 2018-05-09 13:48:26 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 13:48:26 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 13:48:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 13:48:26 --> Model Class Initialized
INFO - 2018-05-09 13:48:26 --> Model Class Initialized
INFO - 2018-05-09 13:48:26 --> Model Class Initialized
INFO - 2018-05-09 13:48:26 --> Model Class Initialized
INFO - 2018-05-09 13:48:26 --> Model Class Initialized
INFO - 2018-05-09 13:48:26 --> Model Class Initialized
INFO - 2018-05-09 13:48:26 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 13:48:26 --> Model Class Initialized
INFO - 2018-05-09 13:48:26 --> Final output sent to browser
DEBUG - 2018-05-09 13:48:26 --> Total execution time: 0.1150
INFO - 2018-05-09 13:48:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 13:48:26 --> Helper loaded: form_helper
INFO - 2018-05-09 13:48:26 --> Form Validation Class Initialized
INFO - 2018-05-09 13:48:26 --> Controller Class Initialized
INFO - 2018-05-09 13:48:26 --> Model Class Initialized
INFO - 2018-05-09 13:48:26 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 13:48:26 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 13:48:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 13:48:26 --> Model Class Initialized
INFO - 2018-05-09 13:48:26 --> Model Class Initialized
INFO - 2018-05-09 13:48:26 --> Model Class Initialized
INFO - 2018-05-09 13:48:26 --> Model Class Initialized
INFO - 2018-05-09 13:48:26 --> Model Class Initialized
INFO - 2018-05-09 13:48:26 --> Model Class Initialized
INFO - 2018-05-09 13:48:26 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 13:48:26 --> Final output sent to browser
DEBUG - 2018-05-09 13:48:26 --> Total execution time: 0.1459
INFO - 2018-05-09 08:18:28 --> Config Class Initialized
INFO - 2018-05-09 08:18:28 --> Hooks Class Initialized
DEBUG - 2018-05-09 08:18:28 --> UTF-8 Support Enabled
INFO - 2018-05-09 08:18:28 --> Utf8 Class Initialized
INFO - 2018-05-09 08:18:28 --> URI Class Initialized
INFO - 2018-05-09 08:18:28 --> Router Class Initialized
INFO - 2018-05-09 08:18:28 --> Output Class Initialized
INFO - 2018-05-09 08:18:28 --> Security Class Initialized
DEBUG - 2018-05-09 08:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 08:18:28 --> Input Class Initialized
INFO - 2018-05-09 08:18:28 --> Language Class Initialized
INFO - 2018-05-09 08:18:28 --> Language Class Initialized
INFO - 2018-05-09 08:18:28 --> Config Class Initialized
INFO - 2018-05-09 08:18:28 --> Loader Class Initialized
INFO - 2018-05-09 13:48:28 --> Helper loaded: url_helper
INFO - 2018-05-09 13:48:28 --> Helper loaded: notification_helper
INFO - 2018-05-09 13:48:28 --> Helper loaded: settings_helper
INFO - 2018-05-09 13:48:28 --> Helper loaded: permission_helper
INFO - 2018-05-09 13:48:28 --> Helper loaded: users_helper
INFO - 2018-05-09 13:48:28 --> Database Driver Class Initialized
DEBUG - 2018-05-09 13:48:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 13:48:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 13:48:28 --> Helper loaded: form_helper
INFO - 2018-05-09 13:48:28 --> Form Validation Class Initialized
INFO - 2018-05-09 13:48:28 --> Controller Class Initialized
INFO - 2018-05-09 13:48:28 --> Model Class Initialized
INFO - 2018-05-09 13:48:28 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 13:48:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 13:48:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 13:48:28 --> Model Class Initialized
INFO - 2018-05-09 13:48:28 --> Model Class Initialized
INFO - 2018-05-09 13:48:28 --> Model Class Initialized
INFO - 2018-05-09 13:48:28 --> Model Class Initialized
INFO - 2018-05-09 13:48:28 --> Final output sent to browser
DEBUG - 2018-05-09 13:48:28 --> Total execution time: 0.1265
INFO - 2018-05-09 08:18:29 --> Config Class Initialized
INFO - 2018-05-09 08:18:29 --> Hooks Class Initialized
DEBUG - 2018-05-09 08:18:29 --> UTF-8 Support Enabled
INFO - 2018-05-09 08:18:29 --> Utf8 Class Initialized
INFO - 2018-05-09 08:18:29 --> URI Class Initialized
INFO - 2018-05-09 08:18:29 --> Router Class Initialized
INFO - 2018-05-09 08:18:29 --> Output Class Initialized
INFO - 2018-05-09 08:18:29 --> Security Class Initialized
DEBUG - 2018-05-09 08:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 08:18:29 --> Input Class Initialized
INFO - 2018-05-09 08:18:29 --> Language Class Initialized
INFO - 2018-05-09 08:18:29 --> Language Class Initialized
INFO - 2018-05-09 08:18:29 --> Config Class Initialized
INFO - 2018-05-09 08:18:29 --> Loader Class Initialized
INFO - 2018-05-09 13:48:29 --> Helper loaded: url_helper
INFO - 2018-05-09 13:48:29 --> Helper loaded: notification_helper
INFO - 2018-05-09 13:48:29 --> Helper loaded: settings_helper
INFO - 2018-05-09 13:48:29 --> Helper loaded: permission_helper
INFO - 2018-05-09 13:48:29 --> Helper loaded: users_helper
INFO - 2018-05-09 13:48:29 --> Database Driver Class Initialized
DEBUG - 2018-05-09 13:48:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 13:48:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 13:48:29 --> Helper loaded: form_helper
INFO - 2018-05-09 13:48:29 --> Form Validation Class Initialized
INFO - 2018-05-09 13:48:29 --> Controller Class Initialized
INFO - 2018-05-09 13:48:29 --> Model Class Initialized
INFO - 2018-05-09 13:48:29 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 13:48:29 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 13:48:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 13:48:29 --> Model Class Initialized
INFO - 2018-05-09 13:48:29 --> Model Class Initialized
INFO - 2018-05-09 13:48:29 --> Model Class Initialized
INFO - 2018-05-09 13:48:29 --> Model Class Initialized
INFO - 2018-05-09 13:48:29 --> Final output sent to browser
DEBUG - 2018-05-09 13:48:29 --> Total execution time: 0.1139
INFO - 2018-05-09 08:21:07 --> Config Class Initialized
INFO - 2018-05-09 08:21:07 --> Hooks Class Initialized
DEBUG - 2018-05-09 08:21:07 --> UTF-8 Support Enabled
INFO - 2018-05-09 08:21:07 --> Utf8 Class Initialized
INFO - 2018-05-09 08:21:07 --> URI Class Initialized
INFO - 2018-05-09 08:21:07 --> Router Class Initialized
INFO - 2018-05-09 08:21:07 --> Output Class Initialized
INFO - 2018-05-09 08:21:07 --> Security Class Initialized
DEBUG - 2018-05-09 08:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 08:21:07 --> Input Class Initialized
INFO - 2018-05-09 08:21:07 --> Language Class Initialized
INFO - 2018-05-09 08:21:07 --> Language Class Initialized
INFO - 2018-05-09 08:21:07 --> Config Class Initialized
INFO - 2018-05-09 08:21:07 --> Loader Class Initialized
INFO - 2018-05-09 13:51:07 --> Helper loaded: url_helper
INFO - 2018-05-09 13:51:07 --> Helper loaded: notification_helper
INFO - 2018-05-09 13:51:07 --> Helper loaded: settings_helper
INFO - 2018-05-09 13:51:07 --> Helper loaded: permission_helper
INFO - 2018-05-09 13:51:07 --> Helper loaded: users_helper
INFO - 2018-05-09 13:51:07 --> Database Driver Class Initialized
DEBUG - 2018-05-09 13:51:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 13:51:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 13:51:07 --> Helper loaded: form_helper
INFO - 2018-05-09 13:51:07 --> Form Validation Class Initialized
INFO - 2018-05-09 13:51:07 --> Controller Class Initialized
INFO - 2018-05-09 13:51:07 --> Model Class Initialized
INFO - 2018-05-09 13:51:07 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 13:51:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 13:51:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 13:51:07 --> Model Class Initialized
INFO - 2018-05-09 13:51:07 --> Model Class Initialized
INFO - 2018-05-09 13:51:07 --> Model Class Initialized
INFO - 2018-05-09 13:51:07 --> Model Class Initialized
INFO - 2018-05-09 13:51:07 --> Final output sent to browser
DEBUG - 2018-05-09 13:51:07 --> Total execution time: 0.1020
INFO - 2018-05-09 08:21:08 --> Config Class Initialized
INFO - 2018-05-09 08:21:08 --> Hooks Class Initialized
DEBUG - 2018-05-09 08:21:08 --> UTF-8 Support Enabled
INFO - 2018-05-09 08:21:08 --> Utf8 Class Initialized
INFO - 2018-05-09 08:21:08 --> URI Class Initialized
INFO - 2018-05-09 08:21:08 --> Router Class Initialized
INFO - 2018-05-09 08:21:08 --> Output Class Initialized
INFO - 2018-05-09 08:21:08 --> Security Class Initialized
DEBUG - 2018-05-09 08:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 08:21:08 --> Input Class Initialized
INFO - 2018-05-09 08:21:08 --> Language Class Initialized
INFO - 2018-05-09 08:21:08 --> Language Class Initialized
INFO - 2018-05-09 08:21:08 --> Config Class Initialized
INFO - 2018-05-09 08:21:08 --> Loader Class Initialized
INFO - 2018-05-09 13:51:08 --> Helper loaded: url_helper
INFO - 2018-05-09 13:51:08 --> Helper loaded: notification_helper
INFO - 2018-05-09 13:51:08 --> Helper loaded: settings_helper
INFO - 2018-05-09 13:51:08 --> Helper loaded: permission_helper
INFO - 2018-05-09 13:51:08 --> Helper loaded: users_helper
INFO - 2018-05-09 13:51:08 --> Database Driver Class Initialized
DEBUG - 2018-05-09 13:51:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 13:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 13:51:08 --> Helper loaded: form_helper
INFO - 2018-05-09 13:51:08 --> Form Validation Class Initialized
INFO - 2018-05-09 13:51:08 --> Controller Class Initialized
INFO - 2018-05-09 13:51:08 --> Model Class Initialized
INFO - 2018-05-09 13:51:08 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 13:51:08 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 13:51:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 13:51:08 --> Model Class Initialized
INFO - 2018-05-09 13:51:08 --> Model Class Initialized
INFO - 2018-05-09 13:51:08 --> Model Class Initialized
INFO - 2018-05-09 13:51:08 --> Model Class Initialized
INFO - 2018-05-09 13:51:08 --> Model Class Initialized
INFO - 2018-05-09 13:51:08 --> Model Class Initialized
INFO - 2018-05-09 13:51:08 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 13:51:08 --> Final output sent to browser
DEBUG - 2018-05-09 13:51:08 --> Total execution time: 0.1346
INFO - 2018-05-09 08:21:09 --> Config Class Initialized
INFO - 2018-05-09 08:21:09 --> Hooks Class Initialized
DEBUG - 2018-05-09 08:21:09 --> UTF-8 Support Enabled
INFO - 2018-05-09 08:21:09 --> Utf8 Class Initialized
INFO - 2018-05-09 08:21:09 --> URI Class Initialized
INFO - 2018-05-09 08:21:09 --> Router Class Initialized
INFO - 2018-05-09 08:21:09 --> Output Class Initialized
INFO - 2018-05-09 08:21:09 --> Security Class Initialized
DEBUG - 2018-05-09 08:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 08:21:09 --> Input Class Initialized
INFO - 2018-05-09 08:21:09 --> Language Class Initialized
INFO - 2018-05-09 08:21:09 --> Language Class Initialized
INFO - 2018-05-09 08:21:09 --> Config Class Initialized
INFO - 2018-05-09 08:21:09 --> Loader Class Initialized
INFO - 2018-05-09 13:51:09 --> Helper loaded: url_helper
INFO - 2018-05-09 13:51:09 --> Helper loaded: notification_helper
INFO - 2018-05-09 13:51:09 --> Helper loaded: settings_helper
INFO - 2018-05-09 13:51:09 --> Helper loaded: permission_helper
INFO - 2018-05-09 13:51:09 --> Helper loaded: users_helper
INFO - 2018-05-09 13:51:09 --> Database Driver Class Initialized
DEBUG - 2018-05-09 13:51:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 13:51:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 13:51:09 --> Helper loaded: form_helper
INFO - 2018-05-09 13:51:09 --> Form Validation Class Initialized
INFO - 2018-05-09 13:51:09 --> Controller Class Initialized
INFO - 2018-05-09 13:51:09 --> Model Class Initialized
INFO - 2018-05-09 13:51:09 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 13:51:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 13:51:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 13:51:09 --> Model Class Initialized
INFO - 2018-05-09 13:51:09 --> Model Class Initialized
INFO - 2018-05-09 13:51:09 --> Model Class Initialized
INFO - 2018-05-09 13:51:09 --> Model Class Initialized
INFO - 2018-05-09 13:51:09 --> Model Class Initialized
INFO - 2018-05-09 13:51:09 --> Model Class Initialized
INFO - 2018-05-09 13:51:09 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 08:22:49 --> Config Class Initialized
INFO - 2018-05-09 08:22:49 --> Hooks Class Initialized
DEBUG - 2018-05-09 08:22:49 --> UTF-8 Support Enabled
INFO - 2018-05-09 08:22:49 --> Utf8 Class Initialized
INFO - 2018-05-09 08:22:49 --> URI Class Initialized
INFO - 2018-05-09 08:22:49 --> Router Class Initialized
INFO - 2018-05-09 08:22:49 --> Output Class Initialized
INFO - 2018-05-09 08:22:49 --> Security Class Initialized
DEBUG - 2018-05-09 08:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 08:22:49 --> Input Class Initialized
INFO - 2018-05-09 08:22:49 --> Language Class Initialized
INFO - 2018-05-09 08:22:49 --> Language Class Initialized
INFO - 2018-05-09 08:22:49 --> Config Class Initialized
INFO - 2018-05-09 08:22:49 --> Loader Class Initialized
INFO - 2018-05-09 08:22:49 --> Config Class Initialized
INFO - 2018-05-09 08:22:49 --> Hooks Class Initialized
INFO - 2018-05-09 13:52:49 --> Helper loaded: url_helper
INFO - 2018-05-09 13:52:49 --> Helper loaded: notification_helper
INFO - 2018-05-09 13:52:49 --> Helper loaded: settings_helper
INFO - 2018-05-09 13:52:49 --> Helper loaded: permission_helper
INFO - 2018-05-09 13:52:49 --> Helper loaded: users_helper
DEBUG - 2018-05-09 08:22:49 --> UTF-8 Support Enabled
INFO - 2018-05-09 08:22:49 --> Utf8 Class Initialized
INFO - 2018-05-09 08:22:49 --> URI Class Initialized
INFO - 2018-05-09 08:22:49 --> Router Class Initialized
INFO - 2018-05-09 08:22:49 --> Output Class Initialized
INFO - 2018-05-09 08:22:49 --> Security Class Initialized
INFO - 2018-05-09 13:52:49 --> Database Driver Class Initialized
DEBUG - 2018-05-09 08:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 08:22:49 --> Input Class Initialized
INFO - 2018-05-09 08:22:49 --> Language Class Initialized
DEBUG - 2018-05-09 13:52:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 13:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 13:52:49 --> Helper loaded: form_helper
INFO - 2018-05-09 13:52:49 --> Form Validation Class Initialized
INFO - 2018-05-09 13:52:49 --> Controller Class Initialized
INFO - 2018-05-09 13:52:49 --> Model Class Initialized
INFO - 2018-05-09 13:52:49 --> Helper loaded: inflector_helper
INFO - 2018-05-09 08:22:49 --> Language Class Initialized
INFO - 2018-05-09 08:22:49 --> Config Class Initialized
INFO - 2018-05-09 08:22:49 --> Loader Class Initialized
INFO - 2018-05-09 13:52:49 --> Helper loaded: url_helper
DEBUG - 2018-05-09 13:52:49 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 13:52:49 --> Helper loaded: notification_helper
INFO - 2018-05-09 13:52:49 --> Helper loaded: settings_helper
INFO - 2018-05-09 13:52:49 --> Helper loaded: permission_helper
INFO - 2018-05-09 13:52:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 13:52:49 --> Helper loaded: users_helper
INFO - 2018-05-09 13:52:49 --> Model Class Initialized
INFO - 2018-05-09 13:52:49 --> Model Class Initialized
INFO - 2018-05-09 13:52:49 --> Model Class Initialized
INFO - 2018-05-09 13:52:49 --> Model Class Initialized
INFO - 2018-05-09 13:52:49 --> Model Class Initialized
INFO - 2018-05-09 13:52:49 --> Model Class Initialized
INFO - 2018-05-09 13:52:49 --> Model Class Initialized
INFO - 2018-05-09 13:52:49 --> Model Class Initialized
INFO - 2018-05-09 13:52:49 --> Model Class Initialized
INFO - 2018-05-09 13:52:49 --> Model Class Initialized
INFO - 2018-05-09 13:52:49 --> Model Class Initialized
INFO - 2018-05-09 13:52:49 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 13:52:49 --> Model Class Initialized
INFO - 2018-05-09 13:52:49 --> Database Driver Class Initialized
INFO - 2018-05-09 13:52:49 --> Final output sent to browser
DEBUG - 2018-05-09 13:52:49 --> Total execution time: 0.1168
DEBUG - 2018-05-09 13:52:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 13:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 13:52:49 --> Helper loaded: form_helper
INFO - 2018-05-09 13:52:49 --> Form Validation Class Initialized
INFO - 2018-05-09 13:52:49 --> Controller Class Initialized
INFO - 2018-05-09 13:52:49 --> Model Class Initialized
INFO - 2018-05-09 13:52:49 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 13:52:49 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 13:52:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 13:52:49 --> Model Class Initialized
INFO - 2018-05-09 13:52:49 --> Model Class Initialized
INFO - 2018-05-09 13:52:49 --> Model Class Initialized
INFO - 2018-05-09 13:52:49 --> Model Class Initialized
INFO - 2018-05-09 13:52:49 --> Model Class Initialized
INFO - 2018-05-09 13:52:49 --> Model Class Initialized
INFO - 2018-05-09 13:52:49 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 13:52:49 --> Model Class Initialized
INFO - 2018-05-09 13:52:49 --> Final output sent to browser
DEBUG - 2018-05-09 13:52:49 --> Total execution time: 0.1149
INFO - 2018-05-09 08:22:49 --> Config Class Initialized
INFO - 2018-05-09 08:22:49 --> Hooks Class Initialized
DEBUG - 2018-05-09 08:22:49 --> UTF-8 Support Enabled
INFO - 2018-05-09 08:22:49 --> Utf8 Class Initialized
INFO - 2018-05-09 08:22:49 --> URI Class Initialized
INFO - 2018-05-09 08:22:49 --> Router Class Initialized
INFO - 2018-05-09 08:22:49 --> Output Class Initialized
INFO - 2018-05-09 08:22:49 --> Security Class Initialized
DEBUG - 2018-05-09 08:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 08:22:49 --> Input Class Initialized
INFO - 2018-05-09 08:22:49 --> Language Class Initialized
INFO - 2018-05-09 08:22:49 --> Language Class Initialized
INFO - 2018-05-09 08:22:49 --> Config Class Initialized
INFO - 2018-05-09 08:22:49 --> Loader Class Initialized
INFO - 2018-05-09 13:52:49 --> Helper loaded: url_helper
INFO - 2018-05-09 13:52:49 --> Helper loaded: notification_helper
INFO - 2018-05-09 13:52:49 --> Helper loaded: settings_helper
INFO - 2018-05-09 13:52:49 --> Helper loaded: permission_helper
INFO - 2018-05-09 13:52:49 --> Helper loaded: users_helper
INFO - 2018-05-09 13:52:49 --> Database Driver Class Initialized
DEBUG - 2018-05-09 13:52:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 13:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 13:52:49 --> Helper loaded: form_helper
INFO - 2018-05-09 13:52:49 --> Form Validation Class Initialized
INFO - 2018-05-09 13:52:49 --> Controller Class Initialized
INFO - 2018-05-09 13:52:49 --> Model Class Initialized
INFO - 2018-05-09 13:52:49 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 13:52:49 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 13:52:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 13:52:49 --> Model Class Initialized
INFO - 2018-05-09 13:52:49 --> Model Class Initialized
INFO - 2018-05-09 13:52:49 --> Model Class Initialized
INFO - 2018-05-09 13:52:49 --> Model Class Initialized
INFO - 2018-05-09 13:52:49 --> Model Class Initialized
INFO - 2018-05-09 13:52:49 --> Model Class Initialized
INFO - 2018-05-09 13:52:49 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 13:52:49 --> Final output sent to browser
DEBUG - 2018-05-09 13:52:49 --> Total execution time: 0.1134
INFO - 2018-05-09 08:22:49 --> Config Class Initialized
INFO - 2018-05-09 08:22:49 --> Hooks Class Initialized
DEBUG - 2018-05-09 08:22:49 --> UTF-8 Support Enabled
INFO - 2018-05-09 08:22:49 --> Utf8 Class Initialized
INFO - 2018-05-09 08:22:49 --> URI Class Initialized
INFO - 2018-05-09 08:22:49 --> Router Class Initialized
INFO - 2018-05-09 08:22:49 --> Output Class Initialized
INFO - 2018-05-09 08:22:49 --> Security Class Initialized
INFO - 2018-05-09 08:22:50 --> Config Class Initialized
INFO - 2018-05-09 08:22:50 --> Hooks Class Initialized
DEBUG - 2018-05-09 08:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 08:22:50 --> Input Class Initialized
INFO - 2018-05-09 08:22:50 --> Language Class Initialized
DEBUG - 2018-05-09 08:22:50 --> UTF-8 Support Enabled
INFO - 2018-05-09 08:22:50 --> Utf8 Class Initialized
INFO - 2018-05-09 08:22:50 --> URI Class Initialized
INFO - 2018-05-09 08:22:50 --> Router Class Initialized
INFO - 2018-05-09 08:22:50 --> Language Class Initialized
INFO - 2018-05-09 08:22:50 --> Config Class Initialized
INFO - 2018-05-09 08:22:50 --> Loader Class Initialized
INFO - 2018-05-09 08:22:50 --> Output Class Initialized
INFO - 2018-05-09 13:52:50 --> Helper loaded: url_helper
INFO - 2018-05-09 13:52:50 --> Helper loaded: notification_helper
INFO - 2018-05-09 13:52:50 --> Helper loaded: settings_helper
INFO - 2018-05-09 08:22:50 --> Security Class Initialized
INFO - 2018-05-09 13:52:50 --> Helper loaded: permission_helper
INFO - 2018-05-09 13:52:50 --> Helper loaded: users_helper
DEBUG - 2018-05-09 08:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 08:22:50 --> Input Class Initialized
INFO - 2018-05-09 08:22:50 --> Language Class Initialized
INFO - 2018-05-09 13:52:50 --> Database Driver Class Initialized
DEBUG - 2018-05-09 13:52:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 13:52:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 08:22:50 --> Language Class Initialized
INFO - 2018-05-09 08:22:50 --> Config Class Initialized
INFO - 2018-05-09 08:22:50 --> Loader Class Initialized
INFO - 2018-05-09 13:52:50 --> Helper loaded: form_helper
INFO - 2018-05-09 13:52:50 --> Form Validation Class Initialized
INFO - 2018-05-09 13:52:50 --> Controller Class Initialized
INFO - 2018-05-09 13:52:50 --> Helper loaded: url_helper
INFO - 2018-05-09 13:52:50 --> Helper loaded: notification_helper
INFO - 2018-05-09 13:52:50 --> Helper loaded: settings_helper
INFO - 2018-05-09 13:52:50 --> Helper loaded: permission_helper
INFO - 2018-05-09 13:52:50 --> Helper loaded: users_helper
INFO - 2018-05-09 13:52:50 --> Model Class Initialized
INFO - 2018-05-09 13:52:50 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 13:52:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 13:52:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 13:52:50 --> Model Class Initialized
INFO - 2018-05-09 13:52:50 --> Model Class Initialized
INFO - 2018-05-09 13:52:50 --> Model Class Initialized
INFO - 2018-05-09 13:52:50 --> Model Class Initialized
INFO - 2018-05-09 13:52:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 13:52:50 --> Final output sent to browser
DEBUG - 2018-05-09 13:52:50 --> Total execution time: 0.1018
INFO - 2018-05-09 13:52:50 --> Database Driver Class Initialized
DEBUG - 2018-05-09 13:52:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 13:52:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 13:52:50 --> Helper loaded: form_helper
INFO - 2018-05-09 13:52:50 --> Form Validation Class Initialized
INFO - 2018-05-09 13:52:50 --> Controller Class Initialized
INFO - 2018-05-09 13:52:50 --> Model Class Initialized
INFO - 2018-05-09 13:52:50 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 13:52:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 13:52:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 13:52:50 --> Model Class Initialized
INFO - 2018-05-09 13:52:50 --> Model Class Initialized
INFO - 2018-05-09 13:52:50 --> Model Class Initialized
INFO - 2018-05-09 13:52:50 --> Model Class Initialized
INFO - 2018-05-09 13:52:50 --> Model Class Initialized
INFO - 2018-05-09 13:52:50 --> Model Class Initialized
INFO - 2018-05-09 13:52:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 13:52:50 --> Final output sent to browser
DEBUG - 2018-05-09 13:52:50 --> Total execution time: 0.1366
INFO - 2018-05-09 08:25:01 --> Config Class Initialized
INFO - 2018-05-09 08:25:01 --> Hooks Class Initialized
DEBUG - 2018-05-09 08:25:01 --> UTF-8 Support Enabled
INFO - 2018-05-09 08:25:01 --> Utf8 Class Initialized
INFO - 2018-05-09 08:25:01 --> URI Class Initialized
INFO - 2018-05-09 08:25:01 --> Router Class Initialized
INFO - 2018-05-09 08:25:01 --> Output Class Initialized
INFO - 2018-05-09 08:25:01 --> Security Class Initialized
DEBUG - 2018-05-09 08:25:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 08:25:01 --> Input Class Initialized
INFO - 2018-05-09 08:25:01 --> Language Class Initialized
INFO - 2018-05-09 08:25:01 --> Language Class Initialized
INFO - 2018-05-09 08:25:01 --> Config Class Initialized
INFO - 2018-05-09 08:25:01 --> Loader Class Initialized
INFO - 2018-05-09 13:55:01 --> Helper loaded: url_helper
INFO - 2018-05-09 13:55:01 --> Helper loaded: notification_helper
INFO - 2018-05-09 13:55:01 --> Helper loaded: settings_helper
INFO - 2018-05-09 13:55:01 --> Helper loaded: permission_helper
INFO - 2018-05-09 13:55:01 --> Helper loaded: users_helper
INFO - 2018-05-09 13:55:01 --> Database Driver Class Initialized
DEBUG - 2018-05-09 13:55:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 13:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 13:55:01 --> Helper loaded: form_helper
INFO - 2018-05-09 13:55:01 --> Form Validation Class Initialized
INFO - 2018-05-09 13:55:01 --> Controller Class Initialized
INFO - 2018-05-09 13:55:02 --> Model Class Initialized
INFO - 2018-05-09 13:55:02 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 13:55:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 13:55:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 13:55:02 --> Model Class Initialized
INFO - 2018-05-09 13:55:02 --> Model Class Initialized
INFO - 2018-05-09 13:55:02 --> Model Class Initialized
INFO - 2018-05-09 13:55:02 --> Model Class Initialized
INFO - 2018-05-09 13:55:02 --> Final output sent to browser
DEBUG - 2018-05-09 13:55:02 --> Total execution time: 0.1286
INFO - 2018-05-09 08:25:04 --> Config Class Initialized
INFO - 2018-05-09 08:25:04 --> Hooks Class Initialized
DEBUG - 2018-05-09 08:25:04 --> UTF-8 Support Enabled
INFO - 2018-05-09 08:25:04 --> Utf8 Class Initialized
INFO - 2018-05-09 08:25:04 --> URI Class Initialized
INFO - 2018-05-09 08:25:04 --> Router Class Initialized
INFO - 2018-05-09 08:25:04 --> Output Class Initialized
INFO - 2018-05-09 08:25:04 --> Security Class Initialized
DEBUG - 2018-05-09 08:25:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 08:25:04 --> Input Class Initialized
INFO - 2018-05-09 08:25:04 --> Language Class Initialized
INFO - 2018-05-09 08:25:04 --> Language Class Initialized
INFO - 2018-05-09 08:25:04 --> Config Class Initialized
INFO - 2018-05-09 08:25:04 --> Loader Class Initialized
INFO - 2018-05-09 13:55:04 --> Helper loaded: url_helper
INFO - 2018-05-09 13:55:04 --> Helper loaded: notification_helper
INFO - 2018-05-09 13:55:04 --> Helper loaded: settings_helper
INFO - 2018-05-09 13:55:04 --> Helper loaded: permission_helper
INFO - 2018-05-09 13:55:04 --> Helper loaded: users_helper
INFO - 2018-05-09 13:55:04 --> Database Driver Class Initialized
DEBUG - 2018-05-09 13:55:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 13:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 13:55:04 --> Helper loaded: form_helper
INFO - 2018-05-09 13:55:04 --> Form Validation Class Initialized
INFO - 2018-05-09 13:55:04 --> Controller Class Initialized
INFO - 2018-05-09 13:55:04 --> Model Class Initialized
INFO - 2018-05-09 13:55:04 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 13:55:04 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 13:55:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 13:55:04 --> Model Class Initialized
INFO - 2018-05-09 13:55:04 --> Model Class Initialized
INFO - 2018-05-09 13:55:04 --> Model Class Initialized
INFO - 2018-05-09 13:55:04 --> Model Class Initialized
INFO - 2018-05-09 13:55:04 --> Final output sent to browser
DEBUG - 2018-05-09 13:55:04 --> Total execution time: 0.1018
INFO - 2018-05-09 08:26:37 --> Config Class Initialized
INFO - 2018-05-09 08:26:37 --> Hooks Class Initialized
DEBUG - 2018-05-09 08:26:37 --> UTF-8 Support Enabled
INFO - 2018-05-09 08:26:37 --> Utf8 Class Initialized
INFO - 2018-05-09 08:26:37 --> URI Class Initialized
INFO - 2018-05-09 08:26:37 --> Router Class Initialized
INFO - 2018-05-09 08:26:37 --> Output Class Initialized
INFO - 2018-05-09 08:26:37 --> Security Class Initialized
DEBUG - 2018-05-09 08:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 08:26:37 --> Input Class Initialized
INFO - 2018-05-09 08:26:37 --> Language Class Initialized
INFO - 2018-05-09 08:26:37 --> Language Class Initialized
INFO - 2018-05-09 08:26:37 --> Config Class Initialized
INFO - 2018-05-09 08:26:37 --> Loader Class Initialized
INFO - 2018-05-09 13:56:37 --> Helper loaded: url_helper
INFO - 2018-05-09 13:56:37 --> Helper loaded: notification_helper
INFO - 2018-05-09 13:56:37 --> Helper loaded: settings_helper
INFO - 2018-05-09 13:56:37 --> Helper loaded: permission_helper
INFO - 2018-05-09 13:56:37 --> Helper loaded: users_helper
INFO - 2018-05-09 13:56:37 --> Database Driver Class Initialized
DEBUG - 2018-05-09 13:56:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 13:56:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 13:56:37 --> Helper loaded: form_helper
INFO - 2018-05-09 13:56:37 --> Form Validation Class Initialized
INFO - 2018-05-09 13:56:37 --> Controller Class Initialized
INFO - 2018-05-09 13:56:37 --> Model Class Initialized
INFO - 2018-05-09 13:56:37 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 13:56:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 13:56:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 13:56:37 --> Model Class Initialized
INFO - 2018-05-09 13:56:37 --> Model Class Initialized
INFO - 2018-05-09 13:56:37 --> Model Class Initialized
INFO - 2018-05-09 13:56:37 --> Model Class Initialized
INFO - 2018-05-09 13:56:37 --> Model Class Initialized
INFO - 2018-05-09 13:56:37 --> Model Class Initialized
INFO - 2018-05-09 13:56:37 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-05-09 13:56:37 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 800
ERROR - 2018-05-09 13:56:37 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 810
INFO - 2018-05-09 13:56:37 --> Final output sent to browser
DEBUG - 2018-05-09 13:56:37 --> Total execution time: 0.1364
INFO - 2018-05-09 08:26:58 --> Config Class Initialized
INFO - 2018-05-09 08:26:58 --> Hooks Class Initialized
DEBUG - 2018-05-09 08:26:58 --> UTF-8 Support Enabled
INFO - 2018-05-09 08:26:58 --> Utf8 Class Initialized
INFO - 2018-05-09 08:26:58 --> URI Class Initialized
INFO - 2018-05-09 08:26:58 --> Router Class Initialized
INFO - 2018-05-09 08:26:58 --> Output Class Initialized
INFO - 2018-05-09 08:26:58 --> Security Class Initialized
DEBUG - 2018-05-09 08:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 08:26:58 --> Input Class Initialized
INFO - 2018-05-09 08:26:58 --> Language Class Initialized
INFO - 2018-05-09 08:26:58 --> Language Class Initialized
INFO - 2018-05-09 08:26:58 --> Config Class Initialized
INFO - 2018-05-09 08:26:58 --> Loader Class Initialized
INFO - 2018-05-09 13:56:58 --> Helper loaded: url_helper
INFO - 2018-05-09 13:56:58 --> Helper loaded: notification_helper
INFO - 2018-05-09 13:56:58 --> Helper loaded: settings_helper
INFO - 2018-05-09 13:56:58 --> Helper loaded: permission_helper
INFO - 2018-05-09 13:56:58 --> Helper loaded: users_helper
INFO - 2018-05-09 13:56:58 --> Database Driver Class Initialized
DEBUG - 2018-05-09 13:56:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 13:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 13:56:58 --> Helper loaded: form_helper
INFO - 2018-05-09 13:56:58 --> Form Validation Class Initialized
INFO - 2018-05-09 13:56:58 --> Controller Class Initialized
INFO - 2018-05-09 13:56:58 --> Model Class Initialized
INFO - 2018-05-09 13:56:58 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 13:56:58 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 13:56:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 13:56:58 --> Model Class Initialized
INFO - 2018-05-09 13:56:58 --> Model Class Initialized
INFO - 2018-05-09 13:56:58 --> Model Class Initialized
INFO - 2018-05-09 13:56:58 --> Model Class Initialized
INFO - 2018-05-09 13:56:58 --> Model Class Initialized
INFO - 2018-05-09 13:56:58 --> Model Class Initialized
INFO - 2018-05-09 13:56:58 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-05-09 13:56:58 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 800
ERROR - 2018-05-09 13:56:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 810
INFO - 2018-05-09 13:56:58 --> Final output sent to browser
DEBUG - 2018-05-09 13:56:58 --> Total execution time: 0.1393
INFO - 2018-05-09 08:28:58 --> Config Class Initialized
INFO - 2018-05-09 08:28:58 --> Hooks Class Initialized
DEBUG - 2018-05-09 08:28:58 --> UTF-8 Support Enabled
INFO - 2018-05-09 08:28:58 --> Utf8 Class Initialized
INFO - 2018-05-09 08:28:58 --> URI Class Initialized
INFO - 2018-05-09 08:28:58 --> Router Class Initialized
INFO - 2018-05-09 08:28:58 --> Output Class Initialized
INFO - 2018-05-09 08:28:58 --> Security Class Initialized
DEBUG - 2018-05-09 08:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 08:28:58 --> Input Class Initialized
INFO - 2018-05-09 08:28:58 --> Language Class Initialized
INFO - 2018-05-09 08:28:58 --> Language Class Initialized
INFO - 2018-05-09 08:28:58 --> Config Class Initialized
INFO - 2018-05-09 08:28:58 --> Loader Class Initialized
INFO - 2018-05-09 13:58:58 --> Helper loaded: url_helper
INFO - 2018-05-09 13:58:58 --> Helper loaded: notification_helper
INFO - 2018-05-09 13:58:58 --> Helper loaded: settings_helper
INFO - 2018-05-09 13:58:58 --> Helper loaded: permission_helper
INFO - 2018-05-09 13:58:58 --> Helper loaded: users_helper
INFO - 2018-05-09 13:58:58 --> Database Driver Class Initialized
DEBUG - 2018-05-09 13:58:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 13:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 13:58:58 --> Helper loaded: form_helper
INFO - 2018-05-09 13:58:58 --> Form Validation Class Initialized
INFO - 2018-05-09 13:58:58 --> Controller Class Initialized
INFO - 2018-05-09 13:58:58 --> Model Class Initialized
INFO - 2018-05-09 13:58:58 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 13:58:58 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 13:58:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 13:58:58 --> Model Class Initialized
INFO - 2018-05-09 13:58:58 --> Model Class Initialized
INFO - 2018-05-09 13:58:58 --> Model Class Initialized
INFO - 2018-05-09 13:58:58 --> Model Class Initialized
INFO - 2018-05-09 13:58:58 --> Model Class Initialized
INFO - 2018-05-09 13:58:58 --> Model Class Initialized
INFO - 2018-05-09 13:58:58 --> Model Class Initialized
INFO - 2018-05-09 13:58:58 --> Model Class Initialized
INFO - 2018-05-09 13:58:58 --> Model Class Initialized
INFO - 2018-05-09 13:58:58 --> Model Class Initialized
INFO - 2018-05-09 13:58:58 --> Model Class Initialized
INFO - 2018-05-09 13:58:58 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 13:58:58 --> Model Class Initialized
INFO - 2018-05-09 13:58:58 --> Final output sent to browser
DEBUG - 2018-05-09 13:58:58 --> Total execution time: 0.1264
INFO - 2018-05-09 08:29:07 --> Config Class Initialized
INFO - 2018-05-09 08:29:07 --> Hooks Class Initialized
DEBUG - 2018-05-09 08:29:07 --> UTF-8 Support Enabled
INFO - 2018-05-09 08:29:07 --> Utf8 Class Initialized
INFO - 2018-05-09 08:29:07 --> URI Class Initialized
INFO - 2018-05-09 08:29:07 --> Router Class Initialized
INFO - 2018-05-09 08:29:07 --> Output Class Initialized
INFO - 2018-05-09 08:29:07 --> Security Class Initialized
DEBUG - 2018-05-09 08:29:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 08:29:07 --> Input Class Initialized
INFO - 2018-05-09 08:29:07 --> Language Class Initialized
INFO - 2018-05-09 08:29:07 --> Language Class Initialized
INFO - 2018-05-09 08:29:07 --> Config Class Initialized
INFO - 2018-05-09 08:29:07 --> Loader Class Initialized
INFO - 2018-05-09 13:59:07 --> Helper loaded: url_helper
INFO - 2018-05-09 13:59:07 --> Helper loaded: notification_helper
INFO - 2018-05-09 13:59:07 --> Helper loaded: settings_helper
INFO - 2018-05-09 13:59:07 --> Helper loaded: permission_helper
INFO - 2018-05-09 13:59:07 --> Helper loaded: users_helper
INFO - 2018-05-09 13:59:07 --> Database Driver Class Initialized
DEBUG - 2018-05-09 13:59:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 13:59:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 13:59:07 --> Helper loaded: form_helper
INFO - 2018-05-09 13:59:07 --> Form Validation Class Initialized
INFO - 2018-05-09 13:59:07 --> Controller Class Initialized
INFO - 2018-05-09 13:59:07 --> Model Class Initialized
INFO - 2018-05-09 13:59:07 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 13:59:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 13:59:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 13:59:07 --> Model Class Initialized
INFO - 2018-05-09 13:59:07 --> Model Class Initialized
INFO - 2018-05-09 13:59:07 --> Model Class Initialized
INFO - 2018-05-09 13:59:07 --> Model Class Initialized
INFO - 2018-05-09 13:59:07 --> Final output sent to browser
DEBUG - 2018-05-09 13:59:07 --> Total execution time: 0.1053
INFO - 2018-05-09 08:29:08 --> Config Class Initialized
INFO - 2018-05-09 08:29:08 --> Hooks Class Initialized
DEBUG - 2018-05-09 08:29:08 --> UTF-8 Support Enabled
INFO - 2018-05-09 08:29:08 --> Utf8 Class Initialized
INFO - 2018-05-09 08:29:08 --> URI Class Initialized
INFO - 2018-05-09 08:29:08 --> Router Class Initialized
INFO - 2018-05-09 08:29:08 --> Output Class Initialized
INFO - 2018-05-09 08:29:08 --> Security Class Initialized
DEBUG - 2018-05-09 08:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 08:29:08 --> Input Class Initialized
INFO - 2018-05-09 08:29:08 --> Language Class Initialized
INFO - 2018-05-09 08:29:08 --> Language Class Initialized
INFO - 2018-05-09 08:29:08 --> Config Class Initialized
INFO - 2018-05-09 08:29:08 --> Loader Class Initialized
INFO - 2018-05-09 13:59:08 --> Helper loaded: url_helper
INFO - 2018-05-09 13:59:08 --> Helper loaded: notification_helper
INFO - 2018-05-09 13:59:08 --> Helper loaded: settings_helper
INFO - 2018-05-09 13:59:08 --> Helper loaded: permission_helper
INFO - 2018-05-09 13:59:08 --> Helper loaded: users_helper
INFO - 2018-05-09 13:59:08 --> Database Driver Class Initialized
DEBUG - 2018-05-09 13:59:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 13:59:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 13:59:08 --> Helper loaded: form_helper
INFO - 2018-05-09 13:59:08 --> Form Validation Class Initialized
INFO - 2018-05-09 13:59:08 --> Controller Class Initialized
INFO - 2018-05-09 13:59:09 --> Model Class Initialized
INFO - 2018-05-09 13:59:09 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 13:59:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 13:59:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 13:59:09 --> Model Class Initialized
INFO - 2018-05-09 13:59:09 --> Model Class Initialized
INFO - 2018-05-09 13:59:09 --> Model Class Initialized
INFO - 2018-05-09 13:59:09 --> Model Class Initialized
INFO - 2018-05-09 13:59:09 --> Model Class Initialized
INFO - 2018-05-09 13:59:09 --> Model Class Initialized
INFO - 2018-05-09 13:59:09 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-05-09 13:59:09 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 800
ERROR - 2018-05-09 13:59:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 810
INFO - 2018-05-09 13:59:09 --> Final output sent to browser
DEBUG - 2018-05-09 13:59:09 --> Total execution time: 0.1390
INFO - 2018-05-09 08:29:45 --> Config Class Initialized
INFO - 2018-05-09 08:29:45 --> Hooks Class Initialized
DEBUG - 2018-05-09 08:29:45 --> UTF-8 Support Enabled
INFO - 2018-05-09 08:29:45 --> Utf8 Class Initialized
INFO - 2018-05-09 08:29:45 --> URI Class Initialized
INFO - 2018-05-09 08:29:45 --> Router Class Initialized
INFO - 2018-05-09 08:29:45 --> Output Class Initialized
INFO - 2018-05-09 08:29:45 --> Security Class Initialized
DEBUG - 2018-05-09 08:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 08:29:45 --> Input Class Initialized
INFO - 2018-05-09 08:29:45 --> Language Class Initialized
INFO - 2018-05-09 08:29:45 --> Language Class Initialized
INFO - 2018-05-09 08:29:45 --> Config Class Initialized
INFO - 2018-05-09 08:29:45 --> Loader Class Initialized
INFO - 2018-05-09 13:59:45 --> Helper loaded: url_helper
INFO - 2018-05-09 13:59:45 --> Helper loaded: notification_helper
INFO - 2018-05-09 13:59:45 --> Helper loaded: settings_helper
INFO - 2018-05-09 13:59:45 --> Helper loaded: permission_helper
INFO - 2018-05-09 13:59:45 --> Helper loaded: users_helper
INFO - 2018-05-09 13:59:45 --> Database Driver Class Initialized
DEBUG - 2018-05-09 13:59:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 13:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 13:59:45 --> Helper loaded: form_helper
INFO - 2018-05-09 13:59:45 --> Form Validation Class Initialized
INFO - 2018-05-09 13:59:45 --> Controller Class Initialized
INFO - 2018-05-09 13:59:45 --> Model Class Initialized
INFO - 2018-05-09 13:59:45 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 13:59:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 13:59:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 13:59:45 --> Model Class Initialized
INFO - 2018-05-09 13:59:45 --> Model Class Initialized
INFO - 2018-05-09 13:59:45 --> Model Class Initialized
INFO - 2018-05-09 13:59:45 --> Model Class Initialized
INFO - 2018-05-09 13:59:45 --> Model Class Initialized
INFO - 2018-05-09 13:59:45 --> Model Class Initialized
INFO - 2018-05-09 13:59:45 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-05-09 13:59:45 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 800
ERROR - 2018-05-09 13:59:45 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 810
INFO - 2018-05-09 13:59:45 --> Final output sent to browser
DEBUG - 2018-05-09 13:59:45 --> Total execution time: 0.1090
INFO - 2018-05-09 08:54:39 --> Config Class Initialized
INFO - 2018-05-09 08:54:39 --> Hooks Class Initialized
DEBUG - 2018-05-09 08:54:39 --> UTF-8 Support Enabled
INFO - 2018-05-09 08:54:39 --> Utf8 Class Initialized
INFO - 2018-05-09 08:54:39 --> URI Class Initialized
INFO - 2018-05-09 08:54:39 --> Router Class Initialized
INFO - 2018-05-09 08:54:39 --> Output Class Initialized
INFO - 2018-05-09 08:54:39 --> Security Class Initialized
DEBUG - 2018-05-09 08:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 08:54:39 --> Input Class Initialized
INFO - 2018-05-09 08:54:39 --> Language Class Initialized
INFO - 2018-05-09 08:54:39 --> Language Class Initialized
INFO - 2018-05-09 08:54:39 --> Config Class Initialized
INFO - 2018-05-09 08:54:39 --> Loader Class Initialized
INFO - 2018-05-09 14:24:39 --> Helper loaded: url_helper
INFO - 2018-05-09 14:24:39 --> Helper loaded: notification_helper
INFO - 2018-05-09 14:24:39 --> Helper loaded: settings_helper
INFO - 2018-05-09 14:24:39 --> Helper loaded: permission_helper
INFO - 2018-05-09 14:24:39 --> Helper loaded: users_helper
INFO - 2018-05-09 14:24:39 --> Database Driver Class Initialized
DEBUG - 2018-05-09 14:24:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 14:24:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 14:24:39 --> Helper loaded: form_helper
INFO - 2018-05-09 14:24:39 --> Form Validation Class Initialized
INFO - 2018-05-09 14:24:39 --> Controller Class Initialized
INFO - 2018-05-09 14:24:39 --> Model Class Initialized
INFO - 2018-05-09 14:24:39 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 14:24:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 14:24:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 14:24:39 --> Model Class Initialized
INFO - 2018-05-09 14:24:39 --> Model Class Initialized
INFO - 2018-05-09 14:24:39 --> Model Class Initialized
INFO - 2018-05-09 14:24:39 --> Model Class Initialized
INFO - 2018-05-09 14:24:39 --> Model Class Initialized
INFO - 2018-05-09 14:24:39 --> Model Class Initialized
INFO - 2018-05-09 14:24:39 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 14:24:39 --> Final output sent to browser
DEBUG - 2018-05-09 14:24:39 --> Total execution time: 0.1078
INFO - 2018-05-09 12:16:31 --> Config Class Initialized
INFO - 2018-05-09 12:16:31 --> Hooks Class Initialized
DEBUG - 2018-05-09 12:16:31 --> UTF-8 Support Enabled
INFO - 2018-05-09 12:16:31 --> Utf8 Class Initialized
INFO - 2018-05-09 12:16:31 --> URI Class Initialized
INFO - 2018-05-09 12:16:31 --> Router Class Initialized
INFO - 2018-05-09 12:16:31 --> Output Class Initialized
INFO - 2018-05-09 12:16:31 --> Security Class Initialized
DEBUG - 2018-05-09 12:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 12:16:31 --> Input Class Initialized
INFO - 2018-05-09 12:16:31 --> Language Class Initialized
INFO - 2018-05-09 12:16:31 --> Config Class Initialized
INFO - 2018-05-09 12:16:31 --> Hooks Class Initialized
DEBUG - 2018-05-09 12:16:31 --> UTF-8 Support Enabled
INFO - 2018-05-09 12:16:31 --> Utf8 Class Initialized
INFO - 2018-05-09 12:16:31 --> URI Class Initialized
INFO - 2018-05-09 12:16:31 --> Config Class Initialized
INFO - 2018-05-09 12:16:31 --> Hooks Class Initialized
DEBUG - 2018-05-09 12:16:31 --> UTF-8 Support Enabled
INFO - 2018-05-09 12:16:31 --> Utf8 Class Initialized
INFO - 2018-05-09 12:16:31 --> Router Class Initialized
INFO - 2018-05-09 12:16:31 --> Language Class Initialized
INFO - 2018-05-09 12:16:31 --> Config Class Initialized
INFO - 2018-05-09 12:16:31 --> Loader Class Initialized
INFO - 2018-05-09 17:46:31 --> Helper loaded: url_helper
INFO - 2018-05-09 12:16:31 --> URI Class Initialized
INFO - 2018-05-09 17:46:31 --> Helper loaded: notification_helper
INFO - 2018-05-09 17:46:31 --> Helper loaded: settings_helper
INFO - 2018-05-09 17:46:31 --> Helper loaded: permission_helper
INFO - 2018-05-09 12:16:31 --> Output Class Initialized
INFO - 2018-05-09 17:46:31 --> Helper loaded: users_helper
INFO - 2018-05-09 12:16:31 --> Security Class Initialized
INFO - 2018-05-09 12:16:31 --> Router Class Initialized
INFO - 2018-05-09 12:16:31 --> Output Class Initialized
DEBUG - 2018-05-09 12:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 12:16:31 --> Input Class Initialized
INFO - 2018-05-09 12:16:31 --> Language Class Initialized
INFO - 2018-05-09 12:16:31 --> Security Class Initialized
DEBUG - 2018-05-09 12:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 12:16:31 --> Input Class Initialized
INFO - 2018-05-09 12:16:31 --> Language Class Initialized
INFO - 2018-05-09 17:46:31 --> Database Driver Class Initialized
DEBUG - 2018-05-09 17:46:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 17:46:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 17:46:31 --> Helper loaded: form_helper
INFO - 2018-05-09 17:46:31 --> Form Validation Class Initialized
INFO - 2018-05-09 17:46:31 --> Controller Class Initialized
INFO - 2018-05-09 12:16:31 --> Language Class Initialized
INFO - 2018-05-09 12:16:31 --> Config Class Initialized
INFO - 2018-05-09 12:16:31 --> Loader Class Initialized
INFO - 2018-05-09 17:46:31 --> Helper loaded: url_helper
INFO - 2018-05-09 17:46:31 --> Helper loaded: notification_helper
INFO - 2018-05-09 17:46:31 --> Model Class Initialized
INFO - 2018-05-09 17:46:31 --> Helper loaded: settings_helper
INFO - 2018-05-09 17:46:31 --> Helper loaded: inflector_helper
INFO - 2018-05-09 17:46:31 --> Helper loaded: permission_helper
INFO - 2018-05-09 17:46:31 --> Helper loaded: users_helper
INFO - 2018-05-09 12:16:31 --> Language Class Initialized
INFO - 2018-05-09 12:16:31 --> Config Class Initialized
INFO - 2018-05-09 12:16:31 --> Loader Class Initialized
DEBUG - 2018-05-09 17:46:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 17:46:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 17:46:31 --> Model Class Initialized
INFO - 2018-05-09 17:46:31 --> Model Class Initialized
INFO - 2018-05-09 17:46:31 --> Helper loaded: url_helper
INFO - 2018-05-09 17:46:31 --> Model Class Initialized
INFO - 2018-05-09 17:46:31 --> Model Class Initialized
INFO - 2018-05-09 17:46:31 --> Helper loaded: notification_helper
INFO - 2018-05-09 17:46:31 --> Model Class Initialized
INFO - 2018-05-09 17:46:31 --> Helper loaded: settings_helper
INFO - 2018-05-09 17:46:31 --> Model Class Initialized
INFO - 2018-05-09 17:46:31 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 17:46:31 --> Helper loaded: permission_helper
INFO - 2018-05-09 17:46:31 --> Helper loaded: users_helper
INFO - 2018-05-09 17:46:31 --> Final output sent to browser
DEBUG - 2018-05-09 17:46:31 --> Total execution time: 0.1063
INFO - 2018-05-09 17:46:31 --> Database Driver Class Initialized
DEBUG - 2018-05-09 17:46:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 17:46:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 17:46:31 --> Database Driver Class Initialized
INFO - 2018-05-09 17:46:31 --> Helper loaded: form_helper
INFO - 2018-05-09 17:46:31 --> Form Validation Class Initialized
INFO - 2018-05-09 17:46:31 --> Controller Class Initialized
DEBUG - 2018-05-09 17:46:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 17:46:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 17:46:31 --> Model Class Initialized
INFO - 2018-05-09 17:46:31 --> Helper loaded: inflector_helper
INFO - 2018-05-09 17:46:31 --> Helper loaded: form_helper
INFO - 2018-05-09 17:46:31 --> Form Validation Class Initialized
INFO - 2018-05-09 17:46:31 --> Controller Class Initialized
DEBUG - 2018-05-09 17:46:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 17:46:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 17:46:31 --> Model Class Initialized
INFO - 2018-05-09 17:46:31 --> Model Class Initialized
INFO - 2018-05-09 17:46:31 --> Model Class Initialized
INFO - 2018-05-09 17:46:31 --> Model Class Initialized
INFO - 2018-05-09 17:46:31 --> Model Class Initialized
INFO - 2018-05-09 17:46:31 --> Model Class Initialized
INFO - 2018-05-09 17:46:31 --> Model Class Initialized
INFO - 2018-05-09 17:46:31 --> Model Class Initialized
INFO - 2018-05-09 17:46:31 --> Model Class Initialized
INFO - 2018-05-09 17:46:31 --> Model Class Initialized
INFO - 2018-05-09 17:46:31 --> Model Class Initialized
INFO - 2018-05-09 17:46:31 --> Helper loaded: inflector_helper
INFO - 2018-05-09 17:46:31 --> Model Class Initialized
INFO - 2018-05-09 17:46:31 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-05-09 17:46:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 17:46:31 --> Model Class Initialized
INFO - 2018-05-09 17:46:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 17:46:31 --> Model Class Initialized
INFO - 2018-05-09 17:46:31 --> Model Class Initialized
INFO - 2018-05-09 17:46:31 --> Model Class Initialized
INFO - 2018-05-09 17:46:31 --> Model Class Initialized
INFO - 2018-05-09 17:46:31 --> Model Class Initialized
INFO - 2018-05-09 17:46:31 --> Model Class Initialized
INFO - 2018-05-09 17:46:31 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 17:46:31 --> Model Class Initialized
INFO - 2018-05-09 17:46:31 --> Final output sent to browser
DEBUG - 2018-05-09 17:46:31 --> Total execution time: 0.1448
INFO - 2018-05-09 17:46:31 --> Final output sent to browser
DEBUG - 2018-05-09 17:46:31 --> Total execution time: 0.1324
INFO - 2018-05-09 12:16:34 --> Config Class Initialized
INFO - 2018-05-09 12:16:34 --> Hooks Class Initialized
DEBUG - 2018-05-09 12:16:34 --> UTF-8 Support Enabled
INFO - 2018-05-09 12:16:34 --> Utf8 Class Initialized
INFO - 2018-05-09 12:16:34 --> URI Class Initialized
INFO - 2018-05-09 12:16:34 --> Router Class Initialized
INFO - 2018-05-09 12:16:34 --> Output Class Initialized
INFO - 2018-05-09 12:16:34 --> Security Class Initialized
DEBUG - 2018-05-09 12:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 12:16:34 --> Input Class Initialized
INFO - 2018-05-09 12:16:34 --> Language Class Initialized
INFO - 2018-05-09 12:16:34 --> Config Class Initialized
INFO - 2018-05-09 12:16:34 --> Hooks Class Initialized
DEBUG - 2018-05-09 12:16:34 --> UTF-8 Support Enabled
INFO - 2018-05-09 12:16:34 --> Utf8 Class Initialized
INFO - 2018-05-09 12:16:34 --> URI Class Initialized
INFO - 2018-05-09 12:16:34 --> Language Class Initialized
INFO - 2018-05-09 12:16:34 --> Config Class Initialized
INFO - 2018-05-09 12:16:34 --> Loader Class Initialized
INFO - 2018-05-09 17:46:34 --> Helper loaded: url_helper
INFO - 2018-05-09 12:16:34 --> Router Class Initialized
INFO - 2018-05-09 17:46:34 --> Helper loaded: notification_helper
INFO - 2018-05-09 17:46:34 --> Helper loaded: settings_helper
INFO - 2018-05-09 17:46:34 --> Helper loaded: permission_helper
INFO - 2018-05-09 17:46:34 --> Helper loaded: users_helper
INFO - 2018-05-09 12:16:34 --> Output Class Initialized
INFO - 2018-05-09 12:16:34 --> Security Class Initialized
INFO - 2018-05-09 17:46:34 --> Database Driver Class Initialized
DEBUG - 2018-05-09 12:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 12:16:34 --> Input Class Initialized
INFO - 2018-05-09 12:16:34 --> Language Class Initialized
DEBUG - 2018-05-09 17:46:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 17:46:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 17:46:34 --> Helper loaded: form_helper
INFO - 2018-05-09 17:46:34 --> Form Validation Class Initialized
INFO - 2018-05-09 17:46:34 --> Controller Class Initialized
INFO - 2018-05-09 17:46:34 --> Model Class Initialized
INFO - 2018-05-09 17:46:34 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 17:46:34 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 12:16:34 --> Language Class Initialized
INFO - 2018-05-09 12:16:34 --> Config Class Initialized
INFO - 2018-05-09 12:16:34 --> Loader Class Initialized
INFO - 2018-05-09 17:46:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 17:46:34 --> Model Class Initialized
INFO - 2018-05-09 17:46:34 --> Helper loaded: url_helper
INFO - 2018-05-09 17:46:34 --> Model Class Initialized
INFO - 2018-05-09 17:46:34 --> Model Class Initialized
INFO - 2018-05-09 17:46:34 --> Helper loaded: notification_helper
INFO - 2018-05-09 17:46:34 --> Model Class Initialized
INFO - 2018-05-09 17:46:34 --> Helper loaded: settings_helper
INFO - 2018-05-09 17:46:34 --> Model Class Initialized
INFO - 2018-05-09 17:46:34 --> Model Class Initialized
INFO - 2018-05-09 17:46:34 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 17:46:34 --> Helper loaded: permission_helper
INFO - 2018-05-09 17:46:34 --> Helper loaded: users_helper
INFO - 2018-05-09 17:46:34 --> Final output sent to browser
DEBUG - 2018-05-09 17:46:34 --> Total execution time: 0.1158
INFO - 2018-05-09 17:46:34 --> Database Driver Class Initialized
DEBUG - 2018-05-09 17:46:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 17:46:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 17:46:34 --> Helper loaded: form_helper
INFO - 2018-05-09 17:46:34 --> Form Validation Class Initialized
INFO - 2018-05-09 17:46:34 --> Controller Class Initialized
INFO - 2018-05-09 17:46:34 --> Model Class Initialized
INFO - 2018-05-09 17:46:34 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 17:46:34 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 17:46:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 17:46:34 --> Model Class Initialized
INFO - 2018-05-09 17:46:34 --> Model Class Initialized
INFO - 2018-05-09 17:46:34 --> Model Class Initialized
INFO - 2018-05-09 17:46:34 --> Model Class Initialized
INFO - 2018-05-09 17:46:34 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 17:46:34 --> Final output sent to browser
DEBUG - 2018-05-09 17:46:34 --> Total execution time: 0.1989
INFO - 2018-05-09 12:17:02 --> Config Class Initialized
INFO - 2018-05-09 12:17:02 --> Hooks Class Initialized
DEBUG - 2018-05-09 12:17:02 --> UTF-8 Support Enabled
INFO - 2018-05-09 12:17:02 --> Utf8 Class Initialized
INFO - 2018-05-09 12:17:02 --> URI Class Initialized
INFO - 2018-05-09 12:17:02 --> Router Class Initialized
INFO - 2018-05-09 12:17:02 --> Output Class Initialized
INFO - 2018-05-09 12:17:02 --> Security Class Initialized
DEBUG - 2018-05-09 12:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 12:17:02 --> Input Class Initialized
INFO - 2018-05-09 12:17:02 --> Language Class Initialized
INFO - 2018-05-09 12:17:02 --> Language Class Initialized
INFO - 2018-05-09 12:17:02 --> Config Class Initialized
INFO - 2018-05-09 12:17:02 --> Loader Class Initialized
INFO - 2018-05-09 17:47:02 --> Helper loaded: url_helper
INFO - 2018-05-09 17:47:02 --> Helper loaded: notification_helper
INFO - 2018-05-09 17:47:02 --> Helper loaded: settings_helper
INFO - 2018-05-09 17:47:02 --> Helper loaded: permission_helper
INFO - 2018-05-09 17:47:02 --> Helper loaded: users_helper
INFO - 2018-05-09 17:47:02 --> Database Driver Class Initialized
DEBUG - 2018-05-09 17:47:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 17:47:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 17:47:02 --> Helper loaded: form_helper
INFO - 2018-05-09 17:47:02 --> Form Validation Class Initialized
INFO - 2018-05-09 17:47:02 --> Controller Class Initialized
INFO - 2018-05-09 17:47:02 --> Model Class Initialized
INFO - 2018-05-09 17:47:02 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 17:47:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 17:47:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 17:47:02 --> Model Class Initialized
INFO - 2018-05-09 17:47:02 --> Model Class Initialized
INFO - 2018-05-09 17:47:02 --> Model Class Initialized
INFO - 2018-05-09 17:47:02 --> Model Class Initialized
INFO - 2018-05-09 17:47:02 --> Model Class Initialized
INFO - 2018-05-09 17:47:02 --> Model Class Initialized
INFO - 2018-05-09 17:47:02 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 17:47:02 --> Final output sent to browser
DEBUG - 2018-05-09 17:47:02 --> Total execution time: 0.1229
INFO - 2018-05-09 12:17:03 --> Config Class Initialized
INFO - 2018-05-09 12:17:03 --> Hooks Class Initialized
DEBUG - 2018-05-09 12:17:03 --> UTF-8 Support Enabled
INFO - 2018-05-09 12:17:03 --> Utf8 Class Initialized
INFO - 2018-05-09 12:17:03 --> URI Class Initialized
INFO - 2018-05-09 12:17:03 --> Router Class Initialized
INFO - 2018-05-09 12:17:03 --> Output Class Initialized
INFO - 2018-05-09 12:17:03 --> Security Class Initialized
DEBUG - 2018-05-09 12:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 12:17:03 --> Input Class Initialized
INFO - 2018-05-09 12:17:03 --> Language Class Initialized
INFO - 2018-05-09 12:17:03 --> Language Class Initialized
INFO - 2018-05-09 12:17:03 --> Config Class Initialized
INFO - 2018-05-09 12:17:03 --> Loader Class Initialized
INFO - 2018-05-09 17:47:03 --> Helper loaded: url_helper
INFO - 2018-05-09 17:47:03 --> Helper loaded: notification_helper
INFO - 2018-05-09 17:47:03 --> Helper loaded: settings_helper
INFO - 2018-05-09 17:47:03 --> Helper loaded: permission_helper
INFO - 2018-05-09 17:47:03 --> Helper loaded: users_helper
INFO - 2018-05-09 17:47:03 --> Database Driver Class Initialized
DEBUG - 2018-05-09 17:47:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 17:47:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 17:47:03 --> Helper loaded: form_helper
INFO - 2018-05-09 17:47:03 --> Form Validation Class Initialized
INFO - 2018-05-09 17:47:03 --> Controller Class Initialized
INFO - 2018-05-09 17:47:03 --> Model Class Initialized
INFO - 2018-05-09 17:47:03 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 17:47:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 17:47:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 17:47:03 --> Model Class Initialized
INFO - 2018-05-09 17:47:03 --> Model Class Initialized
INFO - 2018-05-09 17:47:03 --> Model Class Initialized
INFO - 2018-05-09 17:47:03 --> Model Class Initialized
INFO - 2018-05-09 17:47:03 --> Final output sent to browser
DEBUG - 2018-05-09 17:47:03 --> Total execution time: 0.1028
INFO - 2018-05-09 12:17:04 --> Config Class Initialized
INFO - 2018-05-09 12:17:04 --> Hooks Class Initialized
DEBUG - 2018-05-09 12:17:04 --> UTF-8 Support Enabled
INFO - 2018-05-09 12:17:04 --> Utf8 Class Initialized
INFO - 2018-05-09 12:17:04 --> URI Class Initialized
INFO - 2018-05-09 12:17:04 --> Router Class Initialized
INFO - 2018-05-09 12:17:04 --> Output Class Initialized
INFO - 2018-05-09 12:17:05 --> Security Class Initialized
DEBUG - 2018-05-09 12:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 12:17:05 --> Input Class Initialized
INFO - 2018-05-09 12:17:05 --> Language Class Initialized
INFO - 2018-05-09 12:17:05 --> Language Class Initialized
INFO - 2018-05-09 12:17:05 --> Config Class Initialized
INFO - 2018-05-09 12:17:05 --> Loader Class Initialized
INFO - 2018-05-09 17:47:05 --> Helper loaded: url_helper
INFO - 2018-05-09 17:47:05 --> Helper loaded: notification_helper
INFO - 2018-05-09 17:47:05 --> Helper loaded: settings_helper
INFO - 2018-05-09 17:47:05 --> Helper loaded: permission_helper
INFO - 2018-05-09 17:47:05 --> Helper loaded: users_helper
INFO - 2018-05-09 17:47:05 --> Database Driver Class Initialized
DEBUG - 2018-05-09 17:47:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 17:47:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 17:47:05 --> Helper loaded: form_helper
INFO - 2018-05-09 17:47:05 --> Form Validation Class Initialized
INFO - 2018-05-09 17:47:05 --> Controller Class Initialized
INFO - 2018-05-09 17:47:05 --> Model Class Initialized
INFO - 2018-05-09 17:47:05 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 17:47:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 17:47:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 17:47:05 --> Model Class Initialized
INFO - 2018-05-09 17:47:05 --> Model Class Initialized
INFO - 2018-05-09 17:47:05 --> Model Class Initialized
INFO - 2018-05-09 17:47:05 --> Model Class Initialized
INFO - 2018-05-09 17:47:05 --> Model Class Initialized
INFO - 2018-05-09 17:47:05 --> Model Class Initialized
INFO - 2018-05-09 17:47:05 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-05-09 17:47:05 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 800
ERROR - 2018-05-09 17:47:05 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 810
INFO - 2018-05-09 17:47:05 --> Final output sent to browser
DEBUG - 2018-05-09 17:47:05 --> Total execution time: 0.1408
INFO - 2018-05-09 12:17:27 --> Config Class Initialized
INFO - 2018-05-09 12:17:27 --> Hooks Class Initialized
DEBUG - 2018-05-09 12:17:27 --> UTF-8 Support Enabled
INFO - 2018-05-09 12:17:27 --> Utf8 Class Initialized
INFO - 2018-05-09 12:17:27 --> URI Class Initialized
INFO - 2018-05-09 12:17:27 --> Router Class Initialized
INFO - 2018-05-09 12:17:27 --> Output Class Initialized
INFO - 2018-05-09 12:17:27 --> Security Class Initialized
DEBUG - 2018-05-09 12:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 12:17:27 --> Input Class Initialized
INFO - 2018-05-09 12:17:27 --> Language Class Initialized
INFO - 2018-05-09 12:17:27 --> Language Class Initialized
INFO - 2018-05-09 12:17:27 --> Config Class Initialized
INFO - 2018-05-09 12:17:27 --> Loader Class Initialized
INFO - 2018-05-09 17:47:27 --> Helper loaded: url_helper
INFO - 2018-05-09 17:47:27 --> Helper loaded: notification_helper
INFO - 2018-05-09 17:47:27 --> Helper loaded: settings_helper
INFO - 2018-05-09 17:47:27 --> Helper loaded: permission_helper
INFO - 2018-05-09 17:47:27 --> Helper loaded: users_helper
INFO - 2018-05-09 17:47:27 --> Database Driver Class Initialized
DEBUG - 2018-05-09 17:47:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 17:47:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 17:47:27 --> Helper loaded: form_helper
INFO - 2018-05-09 17:47:27 --> Form Validation Class Initialized
INFO - 2018-05-09 17:47:27 --> Controller Class Initialized
INFO - 2018-05-09 17:47:27 --> Model Class Initialized
INFO - 2018-05-09 17:47:27 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 17:47:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 17:47:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 17:47:27 --> Model Class Initialized
INFO - 2018-05-09 17:47:27 --> Model Class Initialized
INFO - 2018-05-09 17:47:27 --> Model Class Initialized
INFO - 2018-05-09 17:47:27 --> Model Class Initialized
INFO - 2018-05-09 17:47:27 --> Model Class Initialized
INFO - 2018-05-09 17:47:27 --> Model Class Initialized
INFO - 2018-05-09 17:47:27 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 17:47:27 --> Final output sent to browser
DEBUG - 2018-05-09 17:47:27 --> Total execution time: 0.1300
INFO - 2018-05-09 12:17:27 --> Config Class Initialized
INFO - 2018-05-09 12:17:27 --> Hooks Class Initialized
DEBUG - 2018-05-09 12:17:27 --> UTF-8 Support Enabled
INFO - 2018-05-09 12:17:27 --> Utf8 Class Initialized
INFO - 2018-05-09 12:17:27 --> URI Class Initialized
INFO - 2018-05-09 12:17:27 --> Router Class Initialized
INFO - 2018-05-09 12:17:27 --> Output Class Initialized
INFO - 2018-05-09 12:17:27 --> Security Class Initialized
DEBUG - 2018-05-09 12:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 12:17:27 --> Input Class Initialized
INFO - 2018-05-09 12:17:27 --> Language Class Initialized
INFO - 2018-05-09 12:17:27 --> Language Class Initialized
INFO - 2018-05-09 12:17:27 --> Config Class Initialized
INFO - 2018-05-09 12:17:27 --> Loader Class Initialized
INFO - 2018-05-09 17:47:27 --> Helper loaded: url_helper
INFO - 2018-05-09 17:47:27 --> Helper loaded: notification_helper
INFO - 2018-05-09 17:47:27 --> Helper loaded: settings_helper
INFO - 2018-05-09 17:47:27 --> Helper loaded: permission_helper
INFO - 2018-05-09 17:47:27 --> Helper loaded: users_helper
INFO - 2018-05-09 17:47:27 --> Database Driver Class Initialized
DEBUG - 2018-05-09 17:47:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 17:47:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 17:47:27 --> Helper loaded: form_helper
INFO - 2018-05-09 17:47:27 --> Form Validation Class Initialized
INFO - 2018-05-09 17:47:27 --> Controller Class Initialized
INFO - 2018-05-09 17:47:27 --> Model Class Initialized
INFO - 2018-05-09 17:47:27 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 17:47:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 17:47:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 17:47:27 --> Model Class Initialized
INFO - 2018-05-09 17:47:27 --> Model Class Initialized
INFO - 2018-05-09 17:47:27 --> Model Class Initialized
INFO - 2018-05-09 17:47:27 --> Model Class Initialized
INFO - 2018-05-09 17:47:27 --> Model Class Initialized
INFO - 2018-05-09 17:47:27 --> Model Class Initialized
INFO - 2018-05-09 17:47:27 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 17:47:27 --> Final output sent to browser
DEBUG - 2018-05-09 17:47:27 --> Total execution time: 0.1144
INFO - 2018-05-09 13:06:34 --> Config Class Initialized
INFO - 2018-05-09 13:06:34 --> Hooks Class Initialized
DEBUG - 2018-05-09 13:06:34 --> UTF-8 Support Enabled
INFO - 2018-05-09 13:06:34 --> Utf8 Class Initialized
INFO - 2018-05-09 13:06:34 --> URI Class Initialized
INFO - 2018-05-09 13:06:34 --> Router Class Initialized
INFO - 2018-05-09 13:06:34 --> Output Class Initialized
INFO - 2018-05-09 13:06:34 --> Security Class Initialized
DEBUG - 2018-05-09 13:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 13:06:34 --> Input Class Initialized
INFO - 2018-05-09 13:06:34 --> Language Class Initialized
INFO - 2018-05-09 13:06:34 --> Language Class Initialized
INFO - 2018-05-09 13:06:34 --> Config Class Initialized
INFO - 2018-05-09 13:06:34 --> Loader Class Initialized
INFO - 2018-05-09 18:36:34 --> Helper loaded: url_helper
INFO - 2018-05-09 18:36:34 --> Helper loaded: notification_helper
INFO - 2018-05-09 18:36:34 --> Helper loaded: settings_helper
INFO - 2018-05-09 18:36:34 --> Helper loaded: permission_helper
INFO - 2018-05-09 18:36:34 --> Helper loaded: users_helper
INFO - 2018-05-09 18:36:34 --> Database Driver Class Initialized
DEBUG - 2018-05-09 18:36:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 18:36:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 18:36:34 --> Helper loaded: form_helper
INFO - 2018-05-09 18:36:34 --> Form Validation Class Initialized
INFO - 2018-05-09 18:36:34 --> Controller Class Initialized
INFO - 2018-05-09 18:36:34 --> Model Class Initialized
INFO - 2018-05-09 18:36:34 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 18:36:34 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 18:36:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 18:36:34 --> Model Class Initialized
INFO - 2018-05-09 18:36:34 --> Model Class Initialized
INFO - 2018-05-09 18:36:34 --> Model Class Initialized
INFO - 2018-05-09 18:36:34 --> Model Class Initialized
INFO - 2018-05-09 18:36:34 --> Model Class Initialized
INFO - 2018-05-09 18:36:34 --> Model Class Initialized
INFO - 2018-05-09 18:36:34 --> Model Class Initialized
INFO - 2018-05-09 18:36:34 --> Model Class Initialized
INFO - 2018-05-09 18:36:34 --> Model Class Initialized
INFO - 2018-05-09 18:36:34 --> Model Class Initialized
INFO - 2018-05-09 18:36:34 --> Model Class Initialized
INFO - 2018-05-09 18:36:34 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 18:36:34 --> Model Class Initialized
INFO - 2018-05-09 18:36:34 --> Final output sent to browser
DEBUG - 2018-05-09 18:36:34 --> Total execution time: 0.1405
INFO - 2018-05-09 13:06:35 --> Config Class Initialized
INFO - 2018-05-09 13:06:35 --> Hooks Class Initialized
DEBUG - 2018-05-09 13:06:35 --> UTF-8 Support Enabled
INFO - 2018-05-09 13:06:35 --> Utf8 Class Initialized
INFO - 2018-05-09 13:06:35 --> URI Class Initialized
INFO - 2018-05-09 13:06:35 --> Router Class Initialized
INFO - 2018-05-09 13:06:35 --> Output Class Initialized
INFO - 2018-05-09 13:06:35 --> Security Class Initialized
DEBUG - 2018-05-09 13:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 13:06:35 --> Input Class Initialized
INFO - 2018-05-09 13:06:35 --> Language Class Initialized
INFO - 2018-05-09 13:06:35 --> Language Class Initialized
INFO - 2018-05-09 13:06:35 --> Config Class Initialized
INFO - 2018-05-09 13:06:35 --> Loader Class Initialized
INFO - 2018-05-09 18:36:35 --> Helper loaded: url_helper
INFO - 2018-05-09 18:36:35 --> Helper loaded: notification_helper
INFO - 2018-05-09 18:36:35 --> Helper loaded: settings_helper
INFO - 2018-05-09 18:36:35 --> Helper loaded: permission_helper
INFO - 2018-05-09 18:36:35 --> Helper loaded: users_helper
INFO - 2018-05-09 18:36:35 --> Database Driver Class Initialized
DEBUG - 2018-05-09 18:36:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 18:36:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 18:36:35 --> Helper loaded: form_helper
INFO - 2018-05-09 18:36:35 --> Form Validation Class Initialized
INFO - 2018-05-09 18:36:35 --> Controller Class Initialized
INFO - 2018-05-09 18:36:35 --> Model Class Initialized
INFO - 2018-05-09 18:36:35 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 18:36:35 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 18:36:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 18:36:35 --> Model Class Initialized
INFO - 2018-05-09 18:36:35 --> Model Class Initialized
INFO - 2018-05-09 18:36:35 --> Model Class Initialized
INFO - 2018-05-09 18:36:35 --> Model Class Initialized
INFO - 2018-05-09 18:36:35 --> Model Class Initialized
INFO - 2018-05-09 18:36:35 --> Model Class Initialized
INFO - 2018-05-09 18:36:35 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 18:36:35 --> Model Class Initialized
INFO - 2018-05-09 18:36:35 --> Final output sent to browser
DEBUG - 2018-05-09 18:36:35 --> Total execution time: 0.1149
INFO - 2018-05-09 13:06:39 --> Config Class Initialized
INFO - 2018-05-09 13:06:39 --> Hooks Class Initialized
DEBUG - 2018-05-09 13:06:39 --> UTF-8 Support Enabled
INFO - 2018-05-09 13:06:39 --> Utf8 Class Initialized
INFO - 2018-05-09 13:06:39 --> URI Class Initialized
INFO - 2018-05-09 13:06:39 --> Router Class Initialized
INFO - 2018-05-09 13:06:39 --> Output Class Initialized
INFO - 2018-05-09 13:06:39 --> Security Class Initialized
DEBUG - 2018-05-09 13:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 13:06:39 --> Input Class Initialized
INFO - 2018-05-09 13:06:39 --> Language Class Initialized
INFO - 2018-05-09 13:06:39 --> Config Class Initialized
INFO - 2018-05-09 13:06:39 --> Hooks Class Initialized
DEBUG - 2018-05-09 13:06:39 --> UTF-8 Support Enabled
INFO - 2018-05-09 13:06:39 --> Utf8 Class Initialized
INFO - 2018-05-09 13:06:39 --> Language Class Initialized
INFO - 2018-05-09 13:06:39 --> Config Class Initialized
INFO - 2018-05-09 13:06:39 --> Loader Class Initialized
INFO - 2018-05-09 13:06:39 --> URI Class Initialized
INFO - 2018-05-09 18:36:39 --> Helper loaded: url_helper
INFO - 2018-05-09 18:36:39 --> Helper loaded: notification_helper
INFO - 2018-05-09 18:36:39 --> Helper loaded: settings_helper
INFO - 2018-05-09 18:36:39 --> Helper loaded: permission_helper
INFO - 2018-05-09 13:06:39 --> Router Class Initialized
INFO - 2018-05-09 18:36:39 --> Helper loaded: users_helper
INFO - 2018-05-09 13:06:39 --> Output Class Initialized
INFO - 2018-05-09 13:06:39 --> Security Class Initialized
DEBUG - 2018-05-09 13:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 13:06:39 --> Input Class Initialized
INFO - 2018-05-09 13:06:39 --> Language Class Initialized
INFO - 2018-05-09 18:36:39 --> Database Driver Class Initialized
DEBUG - 2018-05-09 18:36:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 18:36:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 18:36:39 --> Helper loaded: form_helper
INFO - 2018-05-09 18:36:39 --> Form Validation Class Initialized
INFO - 2018-05-09 18:36:39 --> Controller Class Initialized
INFO - 2018-05-09 13:06:39 --> Language Class Initialized
INFO - 2018-05-09 13:06:39 --> Config Class Initialized
INFO - 2018-05-09 13:06:39 --> Loader Class Initialized
INFO - 2018-05-09 18:36:39 --> Model Class Initialized
INFO - 2018-05-09 18:36:39 --> Helper loaded: inflector_helper
INFO - 2018-05-09 18:36:39 --> Helper loaded: url_helper
INFO - 2018-05-09 18:36:39 --> Helper loaded: notification_helper
INFO - 2018-05-09 18:36:39 --> Helper loaded: settings_helper
DEBUG - 2018-05-09 18:36:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 18:36:39 --> Helper loaded: permission_helper
INFO - 2018-05-09 18:36:39 --> Helper loaded: users_helper
INFO - 2018-05-09 18:36:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 18:36:39 --> Model Class Initialized
INFO - 2018-05-09 18:36:39 --> Model Class Initialized
INFO - 2018-05-09 18:36:39 --> Model Class Initialized
INFO - 2018-05-09 18:36:39 --> Model Class Initialized
INFO - 2018-05-09 18:36:39 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 18:36:39 --> Final output sent to browser
DEBUG - 2018-05-09 18:36:39 --> Total execution time: 0.1005
INFO - 2018-05-09 18:36:39 --> Database Driver Class Initialized
DEBUG - 2018-05-09 18:36:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 18:36:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 18:36:39 --> Helper loaded: form_helper
INFO - 2018-05-09 18:36:39 --> Form Validation Class Initialized
INFO - 2018-05-09 18:36:39 --> Controller Class Initialized
INFO - 2018-05-09 18:36:39 --> Model Class Initialized
INFO - 2018-05-09 18:36:39 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 18:36:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 18:36:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 18:36:39 --> Model Class Initialized
INFO - 2018-05-09 18:36:39 --> Model Class Initialized
INFO - 2018-05-09 18:36:39 --> Model Class Initialized
INFO - 2018-05-09 18:36:39 --> Model Class Initialized
INFO - 2018-05-09 18:36:39 --> Model Class Initialized
INFO - 2018-05-09 18:36:39 --> Model Class Initialized
INFO - 2018-05-09 18:36:39 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 18:36:39 --> Final output sent to browser
DEBUG - 2018-05-09 18:36:39 --> Total execution time: 0.1245
INFO - 2018-05-09 13:11:14 --> Config Class Initialized
INFO - 2018-05-09 13:11:14 --> Hooks Class Initialized
DEBUG - 2018-05-09 13:11:14 --> UTF-8 Support Enabled
INFO - 2018-05-09 13:11:14 --> Utf8 Class Initialized
INFO - 2018-05-09 13:11:14 --> URI Class Initialized
INFO - 2018-05-09 13:11:14 --> Router Class Initialized
INFO - 2018-05-09 13:11:14 --> Output Class Initialized
INFO - 2018-05-09 13:11:14 --> Security Class Initialized
DEBUG - 2018-05-09 13:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 13:11:14 --> Input Class Initialized
INFO - 2018-05-09 13:11:14 --> Language Class Initialized
INFO - 2018-05-09 13:11:14 --> Language Class Initialized
INFO - 2018-05-09 13:11:14 --> Config Class Initialized
INFO - 2018-05-09 13:11:14 --> Loader Class Initialized
INFO - 2018-05-09 18:41:14 --> Helper loaded: url_helper
INFO - 2018-05-09 18:41:14 --> Helper loaded: notification_helper
INFO - 2018-05-09 18:41:14 --> Helper loaded: settings_helper
INFO - 2018-05-09 18:41:14 --> Helper loaded: permission_helper
INFO - 2018-05-09 18:41:14 --> Helper loaded: users_helper
INFO - 2018-05-09 18:41:14 --> Database Driver Class Initialized
DEBUG - 2018-05-09 18:41:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 18:41:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 18:41:15 --> Helper loaded: form_helper
INFO - 2018-05-09 18:41:15 --> Form Validation Class Initialized
INFO - 2018-05-09 18:41:15 --> Controller Class Initialized
INFO - 2018-05-09 18:41:15 --> Model Class Initialized
INFO - 2018-05-09 18:41:15 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 18:41:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 18:41:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 18:41:15 --> Model Class Initialized
INFO - 2018-05-09 18:41:15 --> Model Class Initialized
INFO - 2018-05-09 18:41:15 --> Model Class Initialized
INFO - 2018-05-09 18:41:15 --> Model Class Initialized
INFO - 2018-05-09 18:41:15 --> Model Class Initialized
INFO - 2018-05-09 18:41:15 --> Model Class Initialized
INFO - 2018-05-09 18:41:15 --> Model Class Initialized
INFO - 2018-05-09 18:41:15 --> Model Class Initialized
INFO - 2018-05-09 18:41:15 --> Model Class Initialized
INFO - 2018-05-09 18:41:15 --> Model Class Initialized
INFO - 2018-05-09 18:41:15 --> Model Class Initialized
INFO - 2018-05-09 18:41:15 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 18:41:15 --> Model Class Initialized
INFO - 2018-05-09 18:41:15 --> Final output sent to browser
DEBUG - 2018-05-09 18:41:15 --> Total execution time: 0.1257
INFO - 2018-05-09 13:11:15 --> Config Class Initialized
INFO - 2018-05-09 13:11:15 --> Hooks Class Initialized
DEBUG - 2018-05-09 13:11:15 --> UTF-8 Support Enabled
INFO - 2018-05-09 13:11:15 --> Utf8 Class Initialized
INFO - 2018-05-09 13:11:15 --> URI Class Initialized
INFO - 2018-05-09 13:11:15 --> Router Class Initialized
INFO - 2018-05-09 13:11:15 --> Output Class Initialized
INFO - 2018-05-09 13:11:15 --> Security Class Initialized
DEBUG - 2018-05-09 13:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 13:11:15 --> Input Class Initialized
INFO - 2018-05-09 13:11:15 --> Language Class Initialized
INFO - 2018-05-09 13:11:15 --> Language Class Initialized
INFO - 2018-05-09 13:11:15 --> Config Class Initialized
INFO - 2018-05-09 13:11:15 --> Loader Class Initialized
INFO - 2018-05-09 18:41:15 --> Helper loaded: url_helper
INFO - 2018-05-09 18:41:15 --> Helper loaded: notification_helper
INFO - 2018-05-09 18:41:15 --> Helper loaded: settings_helper
INFO - 2018-05-09 18:41:15 --> Helper loaded: permission_helper
INFO - 2018-05-09 18:41:15 --> Helper loaded: users_helper
INFO - 2018-05-09 18:41:15 --> Database Driver Class Initialized
DEBUG - 2018-05-09 18:41:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 18:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 18:41:15 --> Helper loaded: form_helper
INFO - 2018-05-09 18:41:15 --> Form Validation Class Initialized
INFO - 2018-05-09 18:41:15 --> Controller Class Initialized
INFO - 2018-05-09 18:41:15 --> Model Class Initialized
INFO - 2018-05-09 18:41:15 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 18:41:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 18:41:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 18:41:15 --> Model Class Initialized
INFO - 2018-05-09 18:41:15 --> Model Class Initialized
INFO - 2018-05-09 18:41:15 --> Model Class Initialized
INFO - 2018-05-09 18:41:15 --> Model Class Initialized
INFO - 2018-05-09 18:41:15 --> Model Class Initialized
INFO - 2018-05-09 18:41:15 --> Model Class Initialized
INFO - 2018-05-09 18:41:15 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 18:41:15 --> Model Class Initialized
INFO - 2018-05-09 18:41:15 --> Final output sent to browser
DEBUG - 2018-05-09 18:41:15 --> Total execution time: 0.1915
INFO - 2018-05-09 13:11:18 --> Config Class Initialized
INFO - 2018-05-09 13:11:18 --> Hooks Class Initialized
DEBUG - 2018-05-09 13:11:18 --> UTF-8 Support Enabled
INFO - 2018-05-09 13:11:18 --> Utf8 Class Initialized
INFO - 2018-05-09 13:11:18 --> URI Class Initialized
INFO - 2018-05-09 13:11:18 --> Router Class Initialized
INFO - 2018-05-09 13:11:18 --> Output Class Initialized
INFO - 2018-05-09 13:11:18 --> Security Class Initialized
DEBUG - 2018-05-09 13:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 13:11:18 --> Input Class Initialized
INFO - 2018-05-09 13:11:18 --> Language Class Initialized
INFO - 2018-05-09 13:11:18 --> Language Class Initialized
INFO - 2018-05-09 13:11:18 --> Config Class Initialized
INFO - 2018-05-09 13:11:18 --> Loader Class Initialized
INFO - 2018-05-09 18:41:18 --> Helper loaded: url_helper
INFO - 2018-05-09 18:41:18 --> Helper loaded: notification_helper
INFO - 2018-05-09 18:41:18 --> Helper loaded: settings_helper
INFO - 2018-05-09 18:41:18 --> Helper loaded: permission_helper
INFO - 2018-05-09 18:41:18 --> Helper loaded: users_helper
INFO - 2018-05-09 13:11:18 --> Config Class Initialized
INFO - 2018-05-09 13:11:18 --> Hooks Class Initialized
DEBUG - 2018-05-09 13:11:18 --> UTF-8 Support Enabled
INFO - 2018-05-09 13:11:18 --> Utf8 Class Initialized
INFO - 2018-05-09 13:11:18 --> URI Class Initialized
INFO - 2018-05-09 18:41:18 --> Database Driver Class Initialized
INFO - 2018-05-09 13:11:18 --> Router Class Initialized
DEBUG - 2018-05-09 18:41:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 18:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 13:11:18 --> Output Class Initialized
INFO - 2018-05-09 18:41:18 --> Helper loaded: form_helper
INFO - 2018-05-09 18:41:18 --> Form Validation Class Initialized
INFO - 2018-05-09 18:41:18 --> Controller Class Initialized
INFO - 2018-05-09 13:11:18 --> Security Class Initialized
DEBUG - 2018-05-09 13:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 13:11:18 --> Input Class Initialized
INFO - 2018-05-09 13:11:18 --> Language Class Initialized
INFO - 2018-05-09 18:41:18 --> Model Class Initialized
INFO - 2018-05-09 18:41:18 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 18:41:18 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 18:41:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 18:41:18 --> Model Class Initialized
INFO - 2018-05-09 18:41:18 --> Model Class Initialized
INFO - 2018-05-09 18:41:18 --> Model Class Initialized
INFO - 2018-05-09 18:41:18 --> Model Class Initialized
INFO - 2018-05-09 18:41:18 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 18:41:18 --> Final output sent to browser
DEBUG - 2018-05-09 18:41:18 --> Total execution time: 0.0773
INFO - 2018-05-09 13:11:18 --> Language Class Initialized
INFO - 2018-05-09 13:11:18 --> Config Class Initialized
INFO - 2018-05-09 13:11:18 --> Loader Class Initialized
INFO - 2018-05-09 18:41:18 --> Helper loaded: url_helper
INFO - 2018-05-09 18:41:18 --> Helper loaded: notification_helper
INFO - 2018-05-09 18:41:18 --> Helper loaded: settings_helper
INFO - 2018-05-09 18:41:18 --> Helper loaded: permission_helper
INFO - 2018-05-09 18:41:18 --> Helper loaded: users_helper
INFO - 2018-05-09 18:41:18 --> Database Driver Class Initialized
DEBUG - 2018-05-09 18:41:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 18:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 18:41:18 --> Helper loaded: form_helper
INFO - 2018-05-09 18:41:18 --> Form Validation Class Initialized
INFO - 2018-05-09 18:41:18 --> Controller Class Initialized
INFO - 2018-05-09 18:41:18 --> Model Class Initialized
INFO - 2018-05-09 18:41:18 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 18:41:18 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 18:41:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 18:41:18 --> Model Class Initialized
INFO - 2018-05-09 18:41:18 --> Model Class Initialized
INFO - 2018-05-09 18:41:18 --> Model Class Initialized
INFO - 2018-05-09 18:41:18 --> Model Class Initialized
INFO - 2018-05-09 18:41:18 --> Model Class Initialized
INFO - 2018-05-09 18:41:18 --> Model Class Initialized
INFO - 2018-05-09 18:41:18 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 18:41:18 --> Final output sent to browser
DEBUG - 2018-05-09 18:41:18 --> Total execution time: 0.1259
INFO - 2018-05-09 13:15:07 --> Config Class Initialized
INFO - 2018-05-09 13:15:07 --> Hooks Class Initialized
DEBUG - 2018-05-09 13:15:07 --> UTF-8 Support Enabled
INFO - 2018-05-09 13:15:07 --> Utf8 Class Initialized
INFO - 2018-05-09 13:15:07 --> URI Class Initialized
INFO - 2018-05-09 13:15:07 --> Router Class Initialized
INFO - 2018-05-09 13:15:07 --> Output Class Initialized
INFO - 2018-05-09 13:15:07 --> Security Class Initialized
DEBUG - 2018-05-09 13:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 13:15:07 --> Input Class Initialized
INFO - 2018-05-09 13:15:07 --> Language Class Initialized
INFO - 2018-05-09 13:15:07 --> Language Class Initialized
INFO - 2018-05-09 13:15:07 --> Config Class Initialized
INFO - 2018-05-09 13:15:07 --> Loader Class Initialized
INFO - 2018-05-09 18:45:07 --> Helper loaded: url_helper
INFO - 2018-05-09 18:45:07 --> Helper loaded: notification_helper
INFO - 2018-05-09 18:45:07 --> Helper loaded: settings_helper
INFO - 2018-05-09 18:45:07 --> Helper loaded: permission_helper
INFO - 2018-05-09 18:45:07 --> Helper loaded: users_helper
INFO - 2018-05-09 18:45:07 --> Database Driver Class Initialized
DEBUG - 2018-05-09 18:45:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 18:45:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 18:45:07 --> Helper loaded: form_helper
INFO - 2018-05-09 18:45:07 --> Form Validation Class Initialized
INFO - 2018-05-09 18:45:07 --> Controller Class Initialized
INFO - 2018-05-09 18:45:07 --> Model Class Initialized
INFO - 2018-05-09 18:45:07 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 18:45:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 18:45:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 18:45:07 --> Model Class Initialized
INFO - 2018-05-09 18:45:07 --> Model Class Initialized
INFO - 2018-05-09 18:45:07 --> Model Class Initialized
INFO - 2018-05-09 18:45:07 --> Model Class Initialized
INFO - 2018-05-09 18:45:07 --> Model Class Initialized
INFO - 2018-05-09 18:45:07 --> Model Class Initialized
INFO - 2018-05-09 18:45:07 --> Model Class Initialized
INFO - 2018-05-09 18:45:07 --> Model Class Initialized
INFO - 2018-05-09 18:45:07 --> Model Class Initialized
INFO - 2018-05-09 18:45:07 --> Model Class Initialized
INFO - 2018-05-09 18:45:07 --> Model Class Initialized
INFO - 2018-05-09 18:45:07 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 18:45:07 --> Model Class Initialized
INFO - 2018-05-09 18:45:07 --> Final output sent to browser
DEBUG - 2018-05-09 18:45:07 --> Total execution time: 0.1465
INFO - 2018-05-09 13:15:08 --> Config Class Initialized
INFO - 2018-05-09 13:15:08 --> Hooks Class Initialized
DEBUG - 2018-05-09 13:15:08 --> UTF-8 Support Enabled
INFO - 2018-05-09 13:15:08 --> Utf8 Class Initialized
INFO - 2018-05-09 13:15:08 --> URI Class Initialized
INFO - 2018-05-09 13:15:08 --> Router Class Initialized
INFO - 2018-05-09 13:15:08 --> Output Class Initialized
INFO - 2018-05-09 13:15:08 --> Security Class Initialized
DEBUG - 2018-05-09 13:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 13:15:08 --> Input Class Initialized
INFO - 2018-05-09 13:15:08 --> Language Class Initialized
INFO - 2018-05-09 13:15:08 --> Language Class Initialized
INFO - 2018-05-09 13:15:08 --> Config Class Initialized
INFO - 2018-05-09 13:15:08 --> Loader Class Initialized
INFO - 2018-05-09 18:45:08 --> Helper loaded: url_helper
INFO - 2018-05-09 18:45:08 --> Helper loaded: notification_helper
INFO - 2018-05-09 18:45:08 --> Helper loaded: settings_helper
INFO - 2018-05-09 18:45:08 --> Helper loaded: permission_helper
INFO - 2018-05-09 18:45:08 --> Helper loaded: users_helper
INFO - 2018-05-09 18:45:08 --> Database Driver Class Initialized
DEBUG - 2018-05-09 18:45:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 18:45:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 18:45:08 --> Helper loaded: form_helper
INFO - 2018-05-09 18:45:08 --> Form Validation Class Initialized
INFO - 2018-05-09 18:45:08 --> Controller Class Initialized
INFO - 2018-05-09 18:45:08 --> Model Class Initialized
INFO - 2018-05-09 18:45:08 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 18:45:08 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 18:45:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 18:45:08 --> Model Class Initialized
INFO - 2018-05-09 18:45:08 --> Model Class Initialized
INFO - 2018-05-09 18:45:08 --> Model Class Initialized
INFO - 2018-05-09 18:45:08 --> Model Class Initialized
INFO - 2018-05-09 18:45:08 --> Model Class Initialized
INFO - 2018-05-09 18:45:08 --> Model Class Initialized
INFO - 2018-05-09 18:45:08 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 18:45:08 --> Model Class Initialized
INFO - 2018-05-09 18:45:08 --> Final output sent to browser
DEBUG - 2018-05-09 18:45:08 --> Total execution time: 0.1239
INFO - 2018-05-09 13:15:11 --> Config Class Initialized
INFO - 2018-05-09 13:15:11 --> Hooks Class Initialized
DEBUG - 2018-05-09 13:15:11 --> UTF-8 Support Enabled
INFO - 2018-05-09 13:15:11 --> Utf8 Class Initialized
INFO - 2018-05-09 13:15:11 --> URI Class Initialized
INFO - 2018-05-09 13:15:11 --> Config Class Initialized
INFO - 2018-05-09 13:15:11 --> Hooks Class Initialized
INFO - 2018-05-09 13:15:11 --> Router Class Initialized
DEBUG - 2018-05-09 13:15:11 --> UTF-8 Support Enabled
INFO - 2018-05-09 13:15:11 --> Utf8 Class Initialized
INFO - 2018-05-09 13:15:11 --> Output Class Initialized
INFO - 2018-05-09 13:15:11 --> URI Class Initialized
INFO - 2018-05-09 13:15:11 --> Security Class Initialized
DEBUG - 2018-05-09 13:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 13:15:11 --> Input Class Initialized
INFO - 2018-05-09 13:15:11 --> Router Class Initialized
INFO - 2018-05-09 13:15:11 --> Language Class Initialized
INFO - 2018-05-09 13:15:11 --> Output Class Initialized
INFO - 2018-05-09 13:15:11 --> Security Class Initialized
DEBUG - 2018-05-09 13:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 13:15:11 --> Input Class Initialized
INFO - 2018-05-09 13:15:11 --> Language Class Initialized
INFO - 2018-05-09 13:15:11 --> Language Class Initialized
INFO - 2018-05-09 13:15:11 --> Config Class Initialized
INFO - 2018-05-09 13:15:11 --> Loader Class Initialized
INFO - 2018-05-09 18:45:11 --> Helper loaded: url_helper
INFO - 2018-05-09 18:45:11 --> Helper loaded: notification_helper
INFO - 2018-05-09 18:45:11 --> Helper loaded: settings_helper
INFO - 2018-05-09 18:45:11 --> Helper loaded: permission_helper
INFO - 2018-05-09 18:45:11 --> Helper loaded: users_helper
INFO - 2018-05-09 13:15:11 --> Language Class Initialized
INFO - 2018-05-09 13:15:11 --> Config Class Initialized
INFO - 2018-05-09 13:15:11 --> Loader Class Initialized
INFO - 2018-05-09 18:45:11 --> Helper loaded: url_helper
INFO - 2018-05-09 18:45:11 --> Helper loaded: notification_helper
INFO - 2018-05-09 18:45:11 --> Helper loaded: settings_helper
INFO - 2018-05-09 18:45:11 --> Helper loaded: permission_helper
INFO - 2018-05-09 18:45:11 --> Helper loaded: users_helper
INFO - 2018-05-09 18:45:11 --> Database Driver Class Initialized
DEBUG - 2018-05-09 18:45:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 18:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 18:45:11 --> Database Driver Class Initialized
DEBUG - 2018-05-09 18:45:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 18:45:11 --> Helper loaded: form_helper
INFO - 2018-05-09 18:45:11 --> Form Validation Class Initialized
INFO - 2018-05-09 18:45:11 --> Controller Class Initialized
INFO - 2018-05-09 18:45:11 --> Model Class Initialized
INFO - 2018-05-09 18:45:11 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 18:45:11 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 18:45:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 18:45:11 --> Model Class Initialized
INFO - 2018-05-09 18:45:11 --> Model Class Initialized
INFO - 2018-05-09 18:45:11 --> Model Class Initialized
INFO - 2018-05-09 18:45:11 --> Model Class Initialized
INFO - 2018-05-09 18:45:11 --> Model Class Initialized
INFO - 2018-05-09 18:45:11 --> Model Class Initialized
INFO - 2018-05-09 18:45:11 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 18:45:11 --> Final output sent to browser
DEBUG - 2018-05-09 18:45:11 --> Total execution time: 0.1170
INFO - 2018-05-09 18:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 18:45:11 --> Helper loaded: form_helper
INFO - 2018-05-09 18:45:11 --> Form Validation Class Initialized
INFO - 2018-05-09 18:45:11 --> Controller Class Initialized
INFO - 2018-05-09 18:45:11 --> Model Class Initialized
INFO - 2018-05-09 18:45:11 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 18:45:11 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 18:45:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 18:45:11 --> Model Class Initialized
INFO - 2018-05-09 18:45:11 --> Model Class Initialized
INFO - 2018-05-09 18:45:11 --> Model Class Initialized
INFO - 2018-05-09 18:45:11 --> Model Class Initialized
INFO - 2018-05-09 18:45:11 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 18:45:11 --> Final output sent to browser
DEBUG - 2018-05-09 18:45:11 --> Total execution time: 0.1475
INFO - 2018-05-09 13:32:18 --> Config Class Initialized
INFO - 2018-05-09 13:32:18 --> Hooks Class Initialized
DEBUG - 2018-05-09 13:32:18 --> UTF-8 Support Enabled
INFO - 2018-05-09 13:32:18 --> Utf8 Class Initialized
INFO - 2018-05-09 13:32:18 --> URI Class Initialized
INFO - 2018-05-09 13:32:18 --> Router Class Initialized
INFO - 2018-05-09 13:32:18 --> Output Class Initialized
INFO - 2018-05-09 13:32:18 --> Security Class Initialized
DEBUG - 2018-05-09 13:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 13:32:18 --> Input Class Initialized
INFO - 2018-05-09 13:32:18 --> Language Class Initialized
INFO - 2018-05-09 13:32:18 --> Language Class Initialized
INFO - 2018-05-09 13:32:18 --> Config Class Initialized
INFO - 2018-05-09 13:32:18 --> Loader Class Initialized
INFO - 2018-05-09 19:02:18 --> Helper loaded: url_helper
INFO - 2018-05-09 19:02:18 --> Helper loaded: notification_helper
INFO - 2018-05-09 19:02:18 --> Helper loaded: settings_helper
INFO - 2018-05-09 19:02:18 --> Helper loaded: permission_helper
INFO - 2018-05-09 19:02:18 --> Helper loaded: users_helper
INFO - 2018-05-09 19:02:18 --> Database Driver Class Initialized
DEBUG - 2018-05-09 19:02:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 19:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 19:02:18 --> Helper loaded: form_helper
INFO - 2018-05-09 19:02:18 --> Form Validation Class Initialized
INFO - 2018-05-09 19:02:18 --> Controller Class Initialized
DEBUG - 2018-05-09 19:02:18 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-05-09 19:02:18 --> Final output sent to browser
DEBUG - 2018-05-09 19:02:18 --> Total execution time: 0.1310
INFO - 2018-05-09 13:32:25 --> Config Class Initialized
INFO - 2018-05-09 13:32:25 --> Hooks Class Initialized
DEBUG - 2018-05-09 13:32:25 --> UTF-8 Support Enabled
INFO - 2018-05-09 13:32:25 --> Utf8 Class Initialized
INFO - 2018-05-09 13:32:25 --> URI Class Initialized
INFO - 2018-05-09 13:32:25 --> Router Class Initialized
INFO - 2018-05-09 13:32:25 --> Output Class Initialized
INFO - 2018-05-09 13:32:25 --> Security Class Initialized
DEBUG - 2018-05-09 13:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 13:32:25 --> Input Class Initialized
INFO - 2018-05-09 13:32:25 --> Language Class Initialized
INFO - 2018-05-09 13:32:25 --> Language Class Initialized
INFO - 2018-05-09 13:32:25 --> Config Class Initialized
INFO - 2018-05-09 13:32:25 --> Loader Class Initialized
INFO - 2018-05-09 19:02:25 --> Helper loaded: url_helper
INFO - 2018-05-09 19:02:25 --> Helper loaded: notification_helper
INFO - 2018-05-09 19:02:25 --> Helper loaded: settings_helper
INFO - 2018-05-09 19:02:25 --> Helper loaded: permission_helper
INFO - 2018-05-09 19:02:25 --> Helper loaded: users_helper
INFO - 2018-05-09 19:02:25 --> Database Driver Class Initialized
DEBUG - 2018-05-09 19:02:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 19:02:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 19:02:25 --> Helper loaded: form_helper
INFO - 2018-05-09 19:02:25 --> Form Validation Class Initialized
INFO - 2018-05-09 19:02:25 --> Controller Class Initialized
INFO - 2018-05-09 19:02:25 --> Model Class Initialized
INFO - 2018-05-09 19:02:25 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 19:02:25 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 19:02:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 19:02:25 --> Model Class Initialized
INFO - 2018-05-09 19:02:25 --> Model Class Initialized
INFO - 2018-05-09 19:02:25 --> Model Class Initialized
INFO - 2018-05-09 19:02:25 --> Model Class Initialized
INFO - 2018-05-09 19:02:25 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 19:02:25 --> Model Class Initialized
INFO - 2018-05-09 19:02:25 --> Final output sent to browser
DEBUG - 2018-05-09 19:02:25 --> Total execution time: 0.1083
INFO - 2018-05-09 13:33:47 --> Config Class Initialized
INFO - 2018-05-09 13:33:47 --> Hooks Class Initialized
DEBUG - 2018-05-09 13:33:47 --> UTF-8 Support Enabled
INFO - 2018-05-09 13:33:47 --> Utf8 Class Initialized
INFO - 2018-05-09 13:33:47 --> URI Class Initialized
INFO - 2018-05-09 13:33:47 --> Router Class Initialized
INFO - 2018-05-09 13:33:47 --> Output Class Initialized
INFO - 2018-05-09 13:33:47 --> Security Class Initialized
DEBUG - 2018-05-09 13:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 13:33:47 --> Input Class Initialized
INFO - 2018-05-09 13:33:47 --> Language Class Initialized
INFO - 2018-05-09 13:33:47 --> Language Class Initialized
INFO - 2018-05-09 13:33:47 --> Config Class Initialized
INFO - 2018-05-09 13:33:47 --> Loader Class Initialized
INFO - 2018-05-09 19:03:47 --> Helper loaded: url_helper
INFO - 2018-05-09 19:03:47 --> Helper loaded: notification_helper
INFO - 2018-05-09 19:03:47 --> Helper loaded: settings_helper
INFO - 2018-05-09 19:03:47 --> Helper loaded: permission_helper
INFO - 2018-05-09 19:03:47 --> Helper loaded: users_helper
INFO - 2018-05-09 19:03:47 --> Database Driver Class Initialized
DEBUG - 2018-05-09 19:03:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 19:03:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 19:03:47 --> Helper loaded: form_helper
INFO - 2018-05-09 19:03:47 --> Form Validation Class Initialized
INFO - 2018-05-09 19:03:47 --> Controller Class Initialized
INFO - 2018-05-09 19:03:47 --> Model Class Initialized
INFO - 2018-05-09 19:03:47 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 19:03:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 19:03:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 19:03:47 --> Model Class Initialized
INFO - 2018-05-09 19:03:47 --> Model Class Initialized
INFO - 2018-05-09 19:03:47 --> Model Class Initialized
INFO - 2018-05-09 19:03:47 --> Model Class Initialized
INFO - 2018-05-09 19:03:47 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 19:03:47 --> Model Class Initialized
INFO - 2018-05-09 19:03:47 --> Final output sent to browser
DEBUG - 2018-05-09 19:03:47 --> Total execution time: 0.1054
INFO - 2018-05-09 13:34:32 --> Config Class Initialized
INFO - 2018-05-09 13:34:32 --> Hooks Class Initialized
DEBUG - 2018-05-09 13:34:32 --> UTF-8 Support Enabled
INFO - 2018-05-09 13:34:32 --> Utf8 Class Initialized
INFO - 2018-05-09 13:34:32 --> URI Class Initialized
INFO - 2018-05-09 13:34:32 --> Router Class Initialized
INFO - 2018-05-09 13:34:32 --> Output Class Initialized
INFO - 2018-05-09 13:34:32 --> Security Class Initialized
DEBUG - 2018-05-09 13:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 13:34:32 --> Input Class Initialized
INFO - 2018-05-09 13:34:32 --> Language Class Initialized
INFO - 2018-05-09 13:34:32 --> Language Class Initialized
INFO - 2018-05-09 13:34:32 --> Config Class Initialized
INFO - 2018-05-09 13:34:32 --> Loader Class Initialized
INFO - 2018-05-09 19:04:32 --> Helper loaded: url_helper
INFO - 2018-05-09 19:04:32 --> Helper loaded: notification_helper
INFO - 2018-05-09 19:04:32 --> Helper loaded: settings_helper
INFO - 2018-05-09 19:04:32 --> Helper loaded: permission_helper
INFO - 2018-05-09 19:04:32 --> Helper loaded: users_helper
INFO - 2018-05-09 19:04:32 --> Database Driver Class Initialized
DEBUG - 2018-05-09 19:04:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 19:04:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 19:04:32 --> Helper loaded: form_helper
INFO - 2018-05-09 19:04:32 --> Form Validation Class Initialized
INFO - 2018-05-09 19:04:32 --> Controller Class Initialized
INFO - 2018-05-09 19:04:32 --> Model Class Initialized
INFO - 2018-05-09 19:04:32 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 19:04:32 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 19:04:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 19:04:32 --> Model Class Initialized
INFO - 2018-05-09 19:04:32 --> Model Class Initialized
INFO - 2018-05-09 19:04:32 --> Model Class Initialized
INFO - 2018-05-09 19:04:32 --> Model Class Initialized
INFO - 2018-05-09 19:04:32 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 19:04:32 --> Model Class Initialized
INFO - 2018-05-09 19:04:32 --> Final output sent to browser
DEBUG - 2018-05-09 19:04:32 --> Total execution time: 0.0993
INFO - 2018-05-09 13:34:53 --> Config Class Initialized
INFO - 2018-05-09 13:34:53 --> Hooks Class Initialized
DEBUG - 2018-05-09 13:34:53 --> UTF-8 Support Enabled
INFO - 2018-05-09 13:34:53 --> Utf8 Class Initialized
INFO - 2018-05-09 13:34:53 --> URI Class Initialized
INFO - 2018-05-09 13:34:53 --> Router Class Initialized
INFO - 2018-05-09 13:34:53 --> Output Class Initialized
INFO - 2018-05-09 13:34:53 --> Security Class Initialized
DEBUG - 2018-05-09 13:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 13:34:53 --> Input Class Initialized
INFO - 2018-05-09 13:34:53 --> Language Class Initialized
INFO - 2018-05-09 13:34:53 --> Language Class Initialized
INFO - 2018-05-09 13:34:53 --> Config Class Initialized
INFO - 2018-05-09 13:34:53 --> Loader Class Initialized
INFO - 2018-05-09 19:04:53 --> Helper loaded: url_helper
INFO - 2018-05-09 19:04:53 --> Helper loaded: notification_helper
INFO - 2018-05-09 19:04:53 --> Helper loaded: settings_helper
INFO - 2018-05-09 19:04:53 --> Helper loaded: permission_helper
INFO - 2018-05-09 19:04:53 --> Helper loaded: users_helper
INFO - 2018-05-09 19:04:53 --> Database Driver Class Initialized
DEBUG - 2018-05-09 19:04:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 19:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 19:04:53 --> Helper loaded: form_helper
INFO - 2018-05-09 19:04:53 --> Form Validation Class Initialized
INFO - 2018-05-09 19:04:53 --> Controller Class Initialized
DEBUG - 2018-05-09 19:04:53 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-05-09 19:04:53 --> Final output sent to browser
DEBUG - 2018-05-09 19:04:53 --> Total execution time: 0.0728
INFO - 2018-05-09 14:03:55 --> Config Class Initialized
INFO - 2018-05-09 14:03:55 --> Hooks Class Initialized
DEBUG - 2018-05-09 14:03:55 --> UTF-8 Support Enabled
INFO - 2018-05-09 14:03:55 --> Utf8 Class Initialized
INFO - 2018-05-09 14:03:55 --> URI Class Initialized
DEBUG - 2018-05-09 14:03:55 --> No URI present. Default controller set.
INFO - 2018-05-09 14:03:55 --> Router Class Initialized
INFO - 2018-05-09 14:03:55 --> Output Class Initialized
INFO - 2018-05-09 14:03:55 --> Security Class Initialized
DEBUG - 2018-05-09 14:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 14:03:55 --> Input Class Initialized
INFO - 2018-05-09 14:03:55 --> Language Class Initialized
INFO - 2018-05-09 14:03:55 --> Language Class Initialized
INFO - 2018-05-09 14:03:55 --> Config Class Initialized
INFO - 2018-05-09 14:03:55 --> Loader Class Initialized
INFO - 2018-05-09 19:33:55 --> Helper loaded: url_helper
INFO - 2018-05-09 19:33:55 --> Helper loaded: notification_helper
INFO - 2018-05-09 19:33:55 --> Helper loaded: settings_helper
INFO - 2018-05-09 19:33:55 --> Helper loaded: permission_helper
INFO - 2018-05-09 19:33:55 --> Helper loaded: users_helper
INFO - 2018-05-09 19:33:55 --> Database Driver Class Initialized
DEBUG - 2018-05-09 19:33:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 19:33:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 19:33:55 --> Helper loaded: form_helper
INFO - 2018-05-09 19:33:55 --> Form Validation Class Initialized
INFO - 2018-05-09 19:33:55 --> Controller Class Initialized
INFO - 2018-05-09 19:33:55 --> Model Class Initialized
INFO - 2018-05-09 19:33:55 --> Helper loaded: inflector_helper
INFO - 2018-05-09 19:33:55 --> Model Class Initialized
DEBUG - 2018-05-09 19:33:55 --> File loaded: /home/pr01004/public_html/application/views/login.php
INFO - 2018-05-09 19:33:55 --> Final output sent to browser
DEBUG - 2018-05-09 19:33:55 --> Total execution time: 0.1468
INFO - 2018-05-09 14:04:07 --> Config Class Initialized
INFO - 2018-05-09 14:04:07 --> Hooks Class Initialized
DEBUG - 2018-05-09 14:04:07 --> UTF-8 Support Enabled
INFO - 2018-05-09 14:04:07 --> Utf8 Class Initialized
INFO - 2018-05-09 14:04:07 --> URI Class Initialized
INFO - 2018-05-09 14:04:07 --> Router Class Initialized
INFO - 2018-05-09 14:04:07 --> Output Class Initialized
INFO - 2018-05-09 14:04:07 --> Security Class Initialized
DEBUG - 2018-05-09 14:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 14:04:07 --> Input Class Initialized
INFO - 2018-05-09 14:04:07 --> Language Class Initialized
INFO - 2018-05-09 14:04:07 --> Language Class Initialized
INFO - 2018-05-09 14:04:07 --> Config Class Initialized
INFO - 2018-05-09 14:04:07 --> Loader Class Initialized
INFO - 2018-05-09 19:34:07 --> Helper loaded: url_helper
INFO - 2018-05-09 19:34:07 --> Helper loaded: notification_helper
INFO - 2018-05-09 19:34:07 --> Helper loaded: settings_helper
INFO - 2018-05-09 19:34:07 --> Helper loaded: permission_helper
INFO - 2018-05-09 19:34:07 --> Helper loaded: users_helper
INFO - 2018-05-09 19:34:07 --> Database Driver Class Initialized
DEBUG - 2018-05-09 19:34:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 19:34:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 19:34:07 --> Helper loaded: form_helper
INFO - 2018-05-09 19:34:07 --> Form Validation Class Initialized
INFO - 2018-05-09 19:34:07 --> Controller Class Initialized
INFO - 2018-05-09 19:34:07 --> Model Class Initialized
INFO - 2018-05-09 19:34:07 --> Helper loaded: inflector_helper
INFO - 2018-05-09 19:34:07 --> Model Class Initialized
INFO - 2018-05-09 19:34:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-05-09 14:04:07 --> Config Class Initialized
INFO - 2018-05-09 14:04:07 --> Hooks Class Initialized
DEBUG - 2018-05-09 14:04:07 --> UTF-8 Support Enabled
INFO - 2018-05-09 14:04:07 --> Utf8 Class Initialized
INFO - 2018-05-09 14:04:07 --> URI Class Initialized
INFO - 2018-05-09 14:04:07 --> Router Class Initialized
INFO - 2018-05-09 14:04:07 --> Output Class Initialized
INFO - 2018-05-09 14:04:07 --> Security Class Initialized
DEBUG - 2018-05-09 14:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 14:04:07 --> Input Class Initialized
INFO - 2018-05-09 14:04:07 --> Language Class Initialized
INFO - 2018-05-09 14:04:07 --> Language Class Initialized
INFO - 2018-05-09 14:04:07 --> Config Class Initialized
INFO - 2018-05-09 14:04:07 --> Loader Class Initialized
INFO - 2018-05-09 19:34:07 --> Helper loaded: url_helper
INFO - 2018-05-09 19:34:07 --> Helper loaded: notification_helper
INFO - 2018-05-09 19:34:07 --> Helper loaded: settings_helper
INFO - 2018-05-09 19:34:07 --> Helper loaded: permission_helper
INFO - 2018-05-09 19:34:07 --> Helper loaded: users_helper
INFO - 2018-05-09 19:34:07 --> Database Driver Class Initialized
DEBUG - 2018-05-09 19:34:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 19:34:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 19:34:07 --> Helper loaded: form_helper
INFO - 2018-05-09 19:34:07 --> Form Validation Class Initialized
INFO - 2018-05-09 19:34:07 --> Controller Class Initialized
DEBUG - 2018-05-09 19:34:07 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-05-09 19:34:07 --> Final output sent to browser
DEBUG - 2018-05-09 19:34:07 --> Total execution time: 0.0712
INFO - 2018-05-09 14:04:08 --> Config Class Initialized
INFO - 2018-05-09 14:04:08 --> Hooks Class Initialized
DEBUG - 2018-05-09 14:04:08 --> UTF-8 Support Enabled
INFO - 2018-05-09 14:04:08 --> Utf8 Class Initialized
INFO - 2018-05-09 14:04:08 --> URI Class Initialized
INFO - 2018-05-09 14:04:08 --> Router Class Initialized
INFO - 2018-05-09 14:04:08 --> Output Class Initialized
INFO - 2018-05-09 14:04:08 --> Security Class Initialized
DEBUG - 2018-05-09 14:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 14:04:08 --> Input Class Initialized
INFO - 2018-05-09 14:04:08 --> Language Class Initialized
INFO - 2018-05-09 14:04:08 --> Language Class Initialized
INFO - 2018-05-09 14:04:08 --> Config Class Initialized
INFO - 2018-05-09 14:04:08 --> Loader Class Initialized
INFO - 2018-05-09 19:34:08 --> Helper loaded: url_helper
INFO - 2018-05-09 19:34:08 --> Helper loaded: notification_helper
INFO - 2018-05-09 19:34:08 --> Helper loaded: settings_helper
INFO - 2018-05-09 19:34:08 --> Helper loaded: permission_helper
INFO - 2018-05-09 19:34:08 --> Helper loaded: users_helper
INFO - 2018-05-09 19:34:08 --> Database Driver Class Initialized
DEBUG - 2018-05-09 19:34:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 19:34:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 19:34:08 --> Helper loaded: form_helper
INFO - 2018-05-09 19:34:08 --> Form Validation Class Initialized
INFO - 2018-05-09 19:34:08 --> Controller Class Initialized
INFO - 2018-05-09 19:34:08 --> Model Class Initialized
INFO - 2018-05-09 19:34:08 --> Helper loaded: inflector_helper
INFO - 2018-05-09 19:34:08 --> Model Class Initialized
INFO - 2018-05-09 19:34:08 --> Model Class Initialized
INFO - 2018-05-09 19:34:08 --> Model Class Initialized
INFO - 2018-05-09 19:34:08 --> Model Class Initialized
INFO - 2018-05-09 19:34:08 --> Model Class Initialized
DEBUG - 2018-05-09 19:34:08 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-05-09 19:34:08 --> File loaded: /home/pr01004/public_html/application/views/admin/dashboard.php
DEBUG - 2018-05-09 19:34:08 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-05-09 19:34:08 --> Final output sent to browser
DEBUG - 2018-05-09 19:34:08 --> Total execution time: 0.1899
INFO - 2018-05-09 14:04:20 --> Config Class Initialized
INFO - 2018-05-09 14:04:20 --> Hooks Class Initialized
DEBUG - 2018-05-09 14:04:20 --> UTF-8 Support Enabled
INFO - 2018-05-09 14:04:20 --> Utf8 Class Initialized
INFO - 2018-05-09 14:04:20 --> URI Class Initialized
INFO - 2018-05-09 14:04:20 --> Router Class Initialized
INFO - 2018-05-09 14:04:20 --> Output Class Initialized
INFO - 2018-05-09 14:04:20 --> Security Class Initialized
DEBUG - 2018-05-09 14:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 14:04:20 --> Input Class Initialized
INFO - 2018-05-09 14:04:20 --> Language Class Initialized
INFO - 2018-05-09 14:04:20 --> Language Class Initialized
INFO - 2018-05-09 14:04:20 --> Config Class Initialized
INFO - 2018-05-09 14:04:20 --> Loader Class Initialized
INFO - 2018-05-09 19:34:20 --> Helper loaded: url_helper
INFO - 2018-05-09 19:34:20 --> Helper loaded: notification_helper
INFO - 2018-05-09 19:34:20 --> Helper loaded: settings_helper
INFO - 2018-05-09 19:34:20 --> Helper loaded: permission_helper
INFO - 2018-05-09 19:34:20 --> Helper loaded: users_helper
INFO - 2018-05-09 19:34:20 --> Database Driver Class Initialized
DEBUG - 2018-05-09 19:34:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 19:34:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 19:34:20 --> Helper loaded: form_helper
INFO - 2018-05-09 19:34:20 --> Form Validation Class Initialized
INFO - 2018-05-09 19:34:20 --> Controller Class Initialized
INFO - 2018-05-09 19:34:20 --> Model Class Initialized
INFO - 2018-05-09 19:34:20 --> Helper loaded: inflector_helper
INFO - 2018-05-09 19:34:20 --> Model Class Initialized
INFO - 2018-05-09 19:34:20 --> Model Class Initialized
DEBUG - 2018-05-09 19:34:20 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-05-09 19:34:20 --> File loaded: /home/pr01004/public_html/application/views/credits/index.php
DEBUG - 2018-05-09 19:34:20 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-05-09 19:34:20 --> Final output sent to browser
DEBUG - 2018-05-09 19:34:20 --> Total execution time: 0.1474
INFO - 2018-05-09 14:32:50 --> Config Class Initialized
INFO - 2018-05-09 14:32:50 --> Hooks Class Initialized
DEBUG - 2018-05-09 14:32:50 --> UTF-8 Support Enabled
INFO - 2018-05-09 14:32:50 --> Utf8 Class Initialized
INFO - 2018-05-09 14:32:50 --> URI Class Initialized
INFO - 2018-05-09 14:32:50 --> Router Class Initialized
INFO - 2018-05-09 14:32:50 --> Output Class Initialized
INFO - 2018-05-09 14:32:50 --> Security Class Initialized
DEBUG - 2018-05-09 14:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 14:32:50 --> Input Class Initialized
INFO - 2018-05-09 14:32:50 --> Language Class Initialized
INFO - 2018-05-09 14:32:50 --> Language Class Initialized
INFO - 2018-05-09 14:32:50 --> Config Class Initialized
INFO - 2018-05-09 14:32:50 --> Loader Class Initialized
INFO - 2018-05-09 20:02:50 --> Helper loaded: url_helper
INFO - 2018-05-09 20:02:50 --> Helper loaded: notification_helper
INFO - 2018-05-09 20:02:50 --> Helper loaded: settings_helper
INFO - 2018-05-09 20:02:50 --> Helper loaded: permission_helper
INFO - 2018-05-09 20:02:50 --> Helper loaded: users_helper
INFO - 2018-05-09 20:02:50 --> Database Driver Class Initialized
DEBUG - 2018-05-09 20:02:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 20:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 20:02:50 --> Helper loaded: form_helper
INFO - 2018-05-09 20:02:50 --> Form Validation Class Initialized
INFO - 2018-05-09 20:02:50 --> Controller Class Initialized
INFO - 2018-05-09 20:02:50 --> Model Class Initialized
INFO - 2018-05-09 20:02:50 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 20:02:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 20:02:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 20:02:50 --> Model Class Initialized
INFO - 2018-05-09 20:02:50 --> Model Class Initialized
INFO - 2018-05-09 20:02:50 --> Model Class Initialized
INFO - 2018-05-09 20:02:50 --> Model Class Initialized
INFO - 2018-05-09 20:02:50 --> Model Class Initialized
INFO - 2018-05-09 20:02:50 --> Model Class Initialized
INFO - 2018-05-09 20:02:50 --> Model Class Initialized
INFO - 2018-05-09 20:02:50 --> Model Class Initialized
INFO - 2018-05-09 20:02:50 --> Model Class Initialized
INFO - 2018-05-09 20:02:50 --> Model Class Initialized
INFO - 2018-05-09 20:02:50 --> Model Class Initialized
INFO - 2018-05-09 20:02:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 20:02:50 --> Model Class Initialized
INFO - 2018-05-09 20:02:50 --> Final output sent to browser
DEBUG - 2018-05-09 20:02:50 --> Total execution time: 0.1290
INFO - 2018-05-09 14:32:52 --> Config Class Initialized
INFO - 2018-05-09 14:32:52 --> Hooks Class Initialized
DEBUG - 2018-05-09 14:32:52 --> UTF-8 Support Enabled
INFO - 2018-05-09 14:32:52 --> Utf8 Class Initialized
INFO - 2018-05-09 14:32:52 --> URI Class Initialized
INFO - 2018-05-09 14:32:52 --> Router Class Initialized
INFO - 2018-05-09 14:32:52 --> Output Class Initialized
INFO - 2018-05-09 14:32:52 --> Security Class Initialized
DEBUG - 2018-05-09 14:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 14:32:52 --> Input Class Initialized
INFO - 2018-05-09 14:32:52 --> Language Class Initialized
INFO - 2018-05-09 14:32:53 --> Language Class Initialized
INFO - 2018-05-09 14:32:53 --> Config Class Initialized
INFO - 2018-05-09 14:32:53 --> Loader Class Initialized
INFO - 2018-05-09 20:02:53 --> Helper loaded: url_helper
INFO - 2018-05-09 20:02:53 --> Helper loaded: notification_helper
INFO - 2018-05-09 20:02:53 --> Helper loaded: settings_helper
INFO - 2018-05-09 20:02:53 --> Helper loaded: permission_helper
INFO - 2018-05-09 20:02:53 --> Helper loaded: users_helper
INFO - 2018-05-09 20:02:53 --> Database Driver Class Initialized
DEBUG - 2018-05-09 20:02:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 20:02:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 20:02:53 --> Helper loaded: form_helper
INFO - 2018-05-09 20:02:53 --> Form Validation Class Initialized
INFO - 2018-05-09 20:02:53 --> Controller Class Initialized
INFO - 2018-05-09 20:02:53 --> Model Class Initialized
INFO - 2018-05-09 20:02:53 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 20:02:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 20:02:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 20:02:53 --> Model Class Initialized
INFO - 2018-05-09 20:02:53 --> Model Class Initialized
INFO - 2018-05-09 20:02:53 --> Model Class Initialized
INFO - 2018-05-09 20:02:53 --> Model Class Initialized
INFO - 2018-05-09 20:02:53 --> Model Class Initialized
INFO - 2018-05-09 20:02:53 --> Model Class Initialized
INFO - 2018-05-09 20:02:53 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 20:02:53 --> Model Class Initialized
INFO - 2018-05-09 20:02:53 --> Final output sent to browser
DEBUG - 2018-05-09 20:02:53 --> Total execution time: 0.1149
INFO - 2018-05-09 14:33:00 --> Config Class Initialized
INFO - 2018-05-09 14:33:00 --> Hooks Class Initialized
DEBUG - 2018-05-09 14:33:00 --> UTF-8 Support Enabled
INFO - 2018-05-09 14:33:00 --> Utf8 Class Initialized
INFO - 2018-05-09 14:33:00 --> URI Class Initialized
INFO - 2018-05-09 14:33:00 --> Router Class Initialized
INFO - 2018-05-09 14:33:00 --> Output Class Initialized
INFO - 2018-05-09 14:33:00 --> Security Class Initialized
DEBUG - 2018-05-09 14:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 14:33:00 --> Input Class Initialized
INFO - 2018-05-09 14:33:00 --> Language Class Initialized
INFO - 2018-05-09 14:33:00 --> Config Class Initialized
INFO - 2018-05-09 14:33:00 --> Hooks Class Initialized
DEBUG - 2018-05-09 14:33:00 --> UTF-8 Support Enabled
INFO - 2018-05-09 14:33:00 --> Utf8 Class Initialized
INFO - 2018-05-09 14:33:00 --> URI Class Initialized
INFO - 2018-05-09 14:33:00 --> Language Class Initialized
INFO - 2018-05-09 14:33:00 --> Config Class Initialized
INFO - 2018-05-09 14:33:00 --> Loader Class Initialized
INFO - 2018-05-09 20:03:00 --> Helper loaded: url_helper
INFO - 2018-05-09 20:03:00 --> Helper loaded: notification_helper
INFO - 2018-05-09 20:03:00 --> Helper loaded: settings_helper
INFO - 2018-05-09 14:33:00 --> Router Class Initialized
INFO - 2018-05-09 20:03:00 --> Helper loaded: permission_helper
INFO - 2018-05-09 20:03:00 --> Helper loaded: users_helper
INFO - 2018-05-09 14:33:00 --> Output Class Initialized
INFO - 2018-05-09 14:33:00 --> Security Class Initialized
DEBUG - 2018-05-09 14:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 14:33:00 --> Input Class Initialized
INFO - 2018-05-09 14:33:00 --> Language Class Initialized
INFO - 2018-05-09 20:03:00 --> Database Driver Class Initialized
DEBUG - 2018-05-09 20:03:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 20:03:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 20:03:00 --> Helper loaded: form_helper
INFO - 2018-05-09 20:03:00 --> Form Validation Class Initialized
INFO - 2018-05-09 20:03:00 --> Controller Class Initialized
INFO - 2018-05-09 14:33:00 --> Language Class Initialized
INFO - 2018-05-09 14:33:00 --> Config Class Initialized
INFO - 2018-05-09 14:33:00 --> Loader Class Initialized
INFO - 2018-05-09 20:03:00 --> Helper loaded: url_helper
INFO - 2018-05-09 20:03:00 --> Helper loaded: notification_helper
INFO - 2018-05-09 20:03:00 --> Helper loaded: settings_helper
INFO - 2018-05-09 20:03:00 --> Helper loaded: permission_helper
INFO - 2018-05-09 20:03:00 --> Helper loaded: users_helper
INFO - 2018-05-09 20:03:00 --> Model Class Initialized
INFO - 2018-05-09 20:03:00 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 20:03:00 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 20:03:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 20:03:00 --> Model Class Initialized
INFO - 2018-05-09 20:03:00 --> Model Class Initialized
INFO - 2018-05-09 20:03:00 --> Model Class Initialized
INFO - 2018-05-09 20:03:00 --> Model Class Initialized
INFO - 2018-05-09 20:03:00 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 20:03:00 --> Final output sent to browser
DEBUG - 2018-05-09 20:03:00 --> Total execution time: 0.0978
INFO - 2018-05-09 20:03:00 --> Database Driver Class Initialized
DEBUG - 2018-05-09 20:03:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 20:03:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 20:03:00 --> Helper loaded: form_helper
INFO - 2018-05-09 20:03:00 --> Form Validation Class Initialized
INFO - 2018-05-09 20:03:00 --> Controller Class Initialized
INFO - 2018-05-09 20:03:00 --> Model Class Initialized
INFO - 2018-05-09 20:03:00 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 20:03:00 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 20:03:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 20:03:00 --> Model Class Initialized
INFO - 2018-05-09 20:03:00 --> Model Class Initialized
INFO - 2018-05-09 20:03:00 --> Model Class Initialized
INFO - 2018-05-09 20:03:00 --> Model Class Initialized
INFO - 2018-05-09 20:03:00 --> Model Class Initialized
INFO - 2018-05-09 20:03:00 --> Model Class Initialized
INFO - 2018-05-09 20:03:00 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 20:03:00 --> Final output sent to browser
DEBUG - 2018-05-09 20:03:00 --> Total execution time: 0.1179
INFO - 2018-05-09 14:33:09 --> Config Class Initialized
INFO - 2018-05-09 14:33:09 --> Hooks Class Initialized
DEBUG - 2018-05-09 14:33:09 --> UTF-8 Support Enabled
INFO - 2018-05-09 14:33:09 --> Utf8 Class Initialized
INFO - 2018-05-09 14:33:09 --> URI Class Initialized
INFO - 2018-05-09 14:33:09 --> Router Class Initialized
INFO - 2018-05-09 14:33:09 --> Output Class Initialized
INFO - 2018-05-09 14:33:09 --> Security Class Initialized
DEBUG - 2018-05-09 14:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 14:33:09 --> Input Class Initialized
INFO - 2018-05-09 14:33:09 --> Language Class Initialized
INFO - 2018-05-09 14:33:09 --> Language Class Initialized
INFO - 2018-05-09 14:33:09 --> Config Class Initialized
INFO - 2018-05-09 14:33:09 --> Loader Class Initialized
INFO - 2018-05-09 20:03:09 --> Helper loaded: url_helper
INFO - 2018-05-09 20:03:09 --> Helper loaded: notification_helper
INFO - 2018-05-09 20:03:09 --> Helper loaded: settings_helper
INFO - 2018-05-09 20:03:09 --> Helper loaded: permission_helper
INFO - 2018-05-09 20:03:09 --> Helper loaded: users_helper
INFO - 2018-05-09 20:03:09 --> Database Driver Class Initialized
DEBUG - 2018-05-09 20:03:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 20:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 20:03:09 --> Helper loaded: form_helper
INFO - 2018-05-09 20:03:09 --> Form Validation Class Initialized
INFO - 2018-05-09 20:03:09 --> Controller Class Initialized
INFO - 2018-05-09 20:03:09 --> Model Class Initialized
INFO - 2018-05-09 20:03:09 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 20:03:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 20:03:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 20:03:09 --> Model Class Initialized
INFO - 2018-05-09 20:03:09 --> Model Class Initialized
INFO - 2018-05-09 20:03:09 --> Model Class Initialized
INFO - 2018-05-09 20:03:09 --> Model Class Initialized
INFO - 2018-05-09 20:03:09 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 20:03:09 --> Model Class Initialized
INFO - 2018-05-09 20:03:09 --> Final output sent to browser
DEBUG - 2018-05-09 20:03:09 --> Total execution time: 0.0959
INFO - 2018-05-09 14:34:06 --> Config Class Initialized
INFO - 2018-05-09 14:34:06 --> Hooks Class Initialized
DEBUG - 2018-05-09 14:34:06 --> UTF-8 Support Enabled
INFO - 2018-05-09 14:34:06 --> Utf8 Class Initialized
INFO - 2018-05-09 14:34:06 --> URI Class Initialized
INFO - 2018-05-09 14:34:06 --> Router Class Initialized
INFO - 2018-05-09 14:34:06 --> Output Class Initialized
INFO - 2018-05-09 14:34:06 --> Security Class Initialized
DEBUG - 2018-05-09 14:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 14:34:06 --> Input Class Initialized
INFO - 2018-05-09 14:34:06 --> Language Class Initialized
INFO - 2018-05-09 14:34:06 --> Language Class Initialized
INFO - 2018-05-09 14:34:06 --> Config Class Initialized
INFO - 2018-05-09 14:34:06 --> Loader Class Initialized
INFO - 2018-05-09 20:04:06 --> Helper loaded: url_helper
INFO - 2018-05-09 20:04:06 --> Helper loaded: notification_helper
INFO - 2018-05-09 20:04:06 --> Helper loaded: settings_helper
INFO - 2018-05-09 20:04:06 --> Helper loaded: permission_helper
INFO - 2018-05-09 20:04:06 --> Helper loaded: users_helper
INFO - 2018-05-09 20:04:06 --> Database Driver Class Initialized
DEBUG - 2018-05-09 20:04:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 20:04:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 20:04:06 --> Helper loaded: form_helper
INFO - 2018-05-09 20:04:06 --> Form Validation Class Initialized
INFO - 2018-05-09 20:04:06 --> Controller Class Initialized
INFO - 2018-05-09 20:04:06 --> Model Class Initialized
INFO - 2018-05-09 20:04:06 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 20:04:06 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 20:04:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 20:04:06 --> Model Class Initialized
INFO - 2018-05-09 20:04:06 --> Model Class Initialized
INFO - 2018-05-09 20:04:06 --> Model Class Initialized
INFO - 2018-05-09 20:04:06 --> Model Class Initialized
INFO - 2018-05-09 20:04:06 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 20:04:06 --> Model Class Initialized
INFO - 2018-05-09 20:04:06 --> Final output sent to browser
DEBUG - 2018-05-09 20:04:06 --> Total execution time: 0.0962
INFO - 2018-05-09 14:34:09 --> Config Class Initialized
INFO - 2018-05-09 14:34:09 --> Hooks Class Initialized
DEBUG - 2018-05-09 14:34:09 --> UTF-8 Support Enabled
INFO - 2018-05-09 14:34:09 --> Utf8 Class Initialized
INFO - 2018-05-09 14:34:09 --> URI Class Initialized
INFO - 2018-05-09 14:34:09 --> Router Class Initialized
INFO - 2018-05-09 14:34:09 --> Output Class Initialized
INFO - 2018-05-09 14:34:09 --> Security Class Initialized
DEBUG - 2018-05-09 14:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 14:34:09 --> Input Class Initialized
INFO - 2018-05-09 14:34:09 --> Language Class Initialized
INFO - 2018-05-09 14:34:10 --> Language Class Initialized
INFO - 2018-05-09 14:34:10 --> Config Class Initialized
INFO - 2018-05-09 14:34:10 --> Loader Class Initialized
INFO - 2018-05-09 20:04:10 --> Helper loaded: url_helper
INFO - 2018-05-09 20:04:10 --> Helper loaded: notification_helper
INFO - 2018-05-09 20:04:10 --> Helper loaded: settings_helper
INFO - 2018-05-09 20:04:10 --> Helper loaded: permission_helper
INFO - 2018-05-09 20:04:10 --> Helper loaded: users_helper
INFO - 2018-05-09 20:04:10 --> Database Driver Class Initialized
DEBUG - 2018-05-09 20:04:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 20:04:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 20:04:10 --> Helper loaded: form_helper
INFO - 2018-05-09 20:04:10 --> Form Validation Class Initialized
INFO - 2018-05-09 20:04:10 --> Controller Class Initialized
INFO - 2018-05-09 20:04:10 --> Model Class Initialized
INFO - 2018-05-09 20:04:10 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 20:04:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 20:04:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 20:04:10 --> Model Class Initialized
INFO - 2018-05-09 20:04:10 --> Model Class Initialized
INFO - 2018-05-09 20:04:10 --> Model Class Initialized
INFO - 2018-05-09 20:04:10 --> Model Class Initialized
INFO - 2018-05-09 20:04:10 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 20:04:10 --> Model Class Initialized
INFO - 2018-05-09 20:04:10 --> Final output sent to browser
DEBUG - 2018-05-09 20:04:10 --> Total execution time: 0.1411
INFO - 2018-05-09 14:38:25 --> Config Class Initialized
INFO - 2018-05-09 14:38:25 --> Hooks Class Initialized
DEBUG - 2018-05-09 14:38:25 --> UTF-8 Support Enabled
INFO - 2018-05-09 14:38:25 --> Utf8 Class Initialized
INFO - 2018-05-09 14:38:25 --> URI Class Initialized
INFO - 2018-05-09 14:38:25 --> Router Class Initialized
INFO - 2018-05-09 14:38:25 --> Output Class Initialized
INFO - 2018-05-09 14:38:25 --> Security Class Initialized
DEBUG - 2018-05-09 14:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 14:38:25 --> Input Class Initialized
INFO - 2018-05-09 14:38:25 --> Language Class Initialized
INFO - 2018-05-09 14:38:26 --> Language Class Initialized
INFO - 2018-05-09 14:38:26 --> Config Class Initialized
INFO - 2018-05-09 14:38:26 --> Loader Class Initialized
INFO - 2018-05-09 20:08:26 --> Helper loaded: url_helper
INFO - 2018-05-09 20:08:26 --> Helper loaded: notification_helper
INFO - 2018-05-09 20:08:26 --> Helper loaded: settings_helper
INFO - 2018-05-09 20:08:26 --> Helper loaded: permission_helper
INFO - 2018-05-09 20:08:26 --> Helper loaded: users_helper
INFO - 2018-05-09 20:08:26 --> Database Driver Class Initialized
DEBUG - 2018-05-09 20:08:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 20:08:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 20:08:26 --> Helper loaded: form_helper
INFO - 2018-05-09 20:08:26 --> Form Validation Class Initialized
INFO - 2018-05-09 20:08:26 --> Controller Class Initialized
INFO - 2018-05-09 20:08:26 --> Model Class Initialized
INFO - 2018-05-09 20:08:26 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 20:08:26 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 20:08:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 20:08:26 --> Model Class Initialized
INFO - 2018-05-09 20:08:26 --> Model Class Initialized
INFO - 2018-05-09 20:08:26 --> Model Class Initialized
INFO - 2018-05-09 20:08:26 --> Model Class Initialized
INFO - 2018-05-09 20:08:26 --> Model Class Initialized
INFO - 2018-05-09 20:08:26 --> Model Class Initialized
INFO - 2018-05-09 20:08:26 --> Model Class Initialized
INFO - 2018-05-09 20:08:26 --> Model Class Initialized
INFO - 2018-05-09 20:08:26 --> Model Class Initialized
INFO - 2018-05-09 20:08:26 --> Model Class Initialized
INFO - 2018-05-09 20:08:26 --> Model Class Initialized
INFO - 2018-05-09 20:08:26 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 20:08:26 --> Model Class Initialized
INFO - 2018-05-09 20:08:26 --> Final output sent to browser
DEBUG - 2018-05-09 20:08:26 --> Total execution time: 0.1346
INFO - 2018-05-09 14:38:26 --> Config Class Initialized
INFO - 2018-05-09 14:38:26 --> Hooks Class Initialized
DEBUG - 2018-05-09 14:38:26 --> UTF-8 Support Enabled
INFO - 2018-05-09 14:38:26 --> Utf8 Class Initialized
INFO - 2018-05-09 14:38:26 --> URI Class Initialized
INFO - 2018-05-09 14:38:26 --> Router Class Initialized
INFO - 2018-05-09 14:38:26 --> Output Class Initialized
INFO - 2018-05-09 14:38:26 --> Security Class Initialized
DEBUG - 2018-05-09 14:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 14:38:26 --> Input Class Initialized
INFO - 2018-05-09 14:38:26 --> Language Class Initialized
INFO - 2018-05-09 14:38:26 --> Language Class Initialized
INFO - 2018-05-09 14:38:26 --> Config Class Initialized
INFO - 2018-05-09 14:38:26 --> Loader Class Initialized
INFO - 2018-05-09 20:08:26 --> Helper loaded: url_helper
INFO - 2018-05-09 20:08:26 --> Helper loaded: notification_helper
INFO - 2018-05-09 20:08:26 --> Helper loaded: settings_helper
INFO - 2018-05-09 20:08:26 --> Helper loaded: permission_helper
INFO - 2018-05-09 20:08:26 --> Helper loaded: users_helper
INFO - 2018-05-09 20:08:26 --> Database Driver Class Initialized
DEBUG - 2018-05-09 20:08:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 20:08:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 20:08:26 --> Helper loaded: form_helper
INFO - 2018-05-09 20:08:26 --> Form Validation Class Initialized
INFO - 2018-05-09 20:08:26 --> Controller Class Initialized
INFO - 2018-05-09 20:08:26 --> Model Class Initialized
INFO - 2018-05-09 20:08:26 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 20:08:26 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 20:08:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 20:08:26 --> Model Class Initialized
INFO - 2018-05-09 20:08:26 --> Model Class Initialized
INFO - 2018-05-09 20:08:26 --> Model Class Initialized
INFO - 2018-05-09 20:08:26 --> Model Class Initialized
INFO - 2018-05-09 20:08:26 --> Model Class Initialized
INFO - 2018-05-09 20:08:26 --> Model Class Initialized
INFO - 2018-05-09 20:08:26 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 20:08:26 --> Model Class Initialized
INFO - 2018-05-09 20:08:26 --> Final output sent to browser
DEBUG - 2018-05-09 20:08:26 --> Total execution time: 0.1143
INFO - 2018-05-09 14:38:28 --> Config Class Initialized
INFO - 2018-05-09 14:38:28 --> Hooks Class Initialized
DEBUG - 2018-05-09 14:38:28 --> UTF-8 Support Enabled
INFO - 2018-05-09 14:38:28 --> Utf8 Class Initialized
INFO - 2018-05-09 14:38:28 --> URI Class Initialized
INFO - 2018-05-09 14:38:28 --> Router Class Initialized
INFO - 2018-05-09 14:38:28 --> Output Class Initialized
INFO - 2018-05-09 14:38:28 --> Security Class Initialized
DEBUG - 2018-05-09 14:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 14:38:28 --> Input Class Initialized
INFO - 2018-05-09 14:38:28 --> Language Class Initialized
INFO - 2018-05-09 14:38:28 --> Language Class Initialized
INFO - 2018-05-09 14:38:28 --> Config Class Initialized
INFO - 2018-05-09 14:38:28 --> Loader Class Initialized
INFO - 2018-05-09 20:08:28 --> Helper loaded: url_helper
INFO - 2018-05-09 20:08:28 --> Helper loaded: notification_helper
INFO - 2018-05-09 20:08:28 --> Helper loaded: settings_helper
INFO - 2018-05-09 20:08:28 --> Helper loaded: permission_helper
INFO - 2018-05-09 20:08:28 --> Helper loaded: users_helper
INFO - 2018-05-09 20:08:28 --> Database Driver Class Initialized
DEBUG - 2018-05-09 20:08:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 20:08:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 20:08:28 --> Helper loaded: form_helper
INFO - 2018-05-09 20:08:28 --> Form Validation Class Initialized
INFO - 2018-05-09 20:08:28 --> Controller Class Initialized
INFO - 2018-05-09 20:08:28 --> Model Class Initialized
INFO - 2018-05-09 20:08:28 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 20:08:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 20:08:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 20:08:28 --> Model Class Initialized
INFO - 2018-05-09 20:08:28 --> Model Class Initialized
INFO - 2018-05-09 20:08:28 --> Model Class Initialized
INFO - 2018-05-09 20:08:28 --> Model Class Initialized
INFO - 2018-05-09 20:08:28 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 20:08:28 --> Final output sent to browser
DEBUG - 2018-05-09 20:08:28 --> Total execution time: 0.1255
INFO - 2018-05-09 14:38:28 --> Config Class Initialized
INFO - 2018-05-09 14:38:28 --> Hooks Class Initialized
DEBUG - 2018-05-09 14:38:28 --> UTF-8 Support Enabled
INFO - 2018-05-09 14:38:28 --> Utf8 Class Initialized
INFO - 2018-05-09 14:38:28 --> URI Class Initialized
INFO - 2018-05-09 14:38:28 --> Router Class Initialized
INFO - 2018-05-09 14:38:28 --> Output Class Initialized
INFO - 2018-05-09 14:38:28 --> Security Class Initialized
DEBUG - 2018-05-09 14:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 14:38:28 --> Input Class Initialized
INFO - 2018-05-09 14:38:28 --> Language Class Initialized
INFO - 2018-05-09 14:38:28 --> Language Class Initialized
INFO - 2018-05-09 14:38:28 --> Config Class Initialized
INFO - 2018-05-09 14:38:28 --> Loader Class Initialized
INFO - 2018-05-09 20:08:28 --> Helper loaded: url_helper
INFO - 2018-05-09 20:08:28 --> Helper loaded: notification_helper
INFO - 2018-05-09 20:08:28 --> Helper loaded: settings_helper
INFO - 2018-05-09 20:08:28 --> Helper loaded: permission_helper
INFO - 2018-05-09 20:08:28 --> Helper loaded: users_helper
INFO - 2018-05-09 20:08:28 --> Database Driver Class Initialized
DEBUG - 2018-05-09 20:08:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 20:08:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 20:08:28 --> Helper loaded: form_helper
INFO - 2018-05-09 20:08:28 --> Form Validation Class Initialized
INFO - 2018-05-09 20:08:28 --> Controller Class Initialized
INFO - 2018-05-09 20:08:28 --> Model Class Initialized
INFO - 2018-05-09 20:08:28 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 20:08:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 20:08:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 20:08:28 --> Model Class Initialized
INFO - 2018-05-09 20:08:28 --> Model Class Initialized
INFO - 2018-05-09 20:08:28 --> Model Class Initialized
INFO - 2018-05-09 20:08:28 --> Model Class Initialized
INFO - 2018-05-09 20:08:28 --> Model Class Initialized
INFO - 2018-05-09 20:08:28 --> Model Class Initialized
INFO - 2018-05-09 20:08:28 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 20:08:28 --> Final output sent to browser
DEBUG - 2018-05-09 20:08:28 --> Total execution time: 0.0974
INFO - 2018-05-09 14:38:32 --> Config Class Initialized
INFO - 2018-05-09 14:38:32 --> Hooks Class Initialized
DEBUG - 2018-05-09 14:38:32 --> UTF-8 Support Enabled
INFO - 2018-05-09 14:38:32 --> Utf8 Class Initialized
INFO - 2018-05-09 14:38:32 --> URI Class Initialized
INFO - 2018-05-09 14:38:32 --> Router Class Initialized
INFO - 2018-05-09 14:38:32 --> Output Class Initialized
INFO - 2018-05-09 14:38:32 --> Security Class Initialized
DEBUG - 2018-05-09 14:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 14:38:32 --> Input Class Initialized
INFO - 2018-05-09 14:38:32 --> Language Class Initialized
INFO - 2018-05-09 14:38:32 --> Language Class Initialized
INFO - 2018-05-09 14:38:32 --> Config Class Initialized
INFO - 2018-05-09 14:38:32 --> Loader Class Initialized
INFO - 2018-05-09 20:08:32 --> Helper loaded: url_helper
INFO - 2018-05-09 20:08:32 --> Helper loaded: notification_helper
INFO - 2018-05-09 20:08:32 --> Helper loaded: settings_helper
INFO - 2018-05-09 20:08:32 --> Helper loaded: permission_helper
INFO - 2018-05-09 20:08:32 --> Helper loaded: users_helper
INFO - 2018-05-09 20:08:32 --> Database Driver Class Initialized
DEBUG - 2018-05-09 20:08:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 20:08:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 20:08:32 --> Helper loaded: form_helper
INFO - 2018-05-09 20:08:32 --> Form Validation Class Initialized
INFO - 2018-05-09 20:08:32 --> Controller Class Initialized
INFO - 2018-05-09 20:08:32 --> Model Class Initialized
INFO - 2018-05-09 20:08:32 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 20:08:32 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 20:08:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 20:08:32 --> Model Class Initialized
INFO - 2018-05-09 20:08:32 --> Model Class Initialized
INFO - 2018-05-09 20:08:32 --> Model Class Initialized
INFO - 2018-05-09 20:08:32 --> Model Class Initialized
INFO - 2018-05-09 20:08:32 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 20:08:32 --> Model Class Initialized
INFO - 2018-05-09 20:08:32 --> Final output sent to browser
DEBUG - 2018-05-09 20:08:32 --> Total execution time: 0.0988
INFO - 2018-05-09 14:40:59 --> Config Class Initialized
INFO - 2018-05-09 14:40:59 --> Hooks Class Initialized
DEBUG - 2018-05-09 14:40:59 --> UTF-8 Support Enabled
INFO - 2018-05-09 14:40:59 --> Utf8 Class Initialized
INFO - 2018-05-09 14:40:59 --> URI Class Initialized
INFO - 2018-05-09 14:40:59 --> Router Class Initialized
INFO - 2018-05-09 14:40:59 --> Output Class Initialized
INFO - 2018-05-09 14:40:59 --> Security Class Initialized
DEBUG - 2018-05-09 14:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 14:40:59 --> Input Class Initialized
INFO - 2018-05-09 14:40:59 --> Language Class Initialized
INFO - 2018-05-09 14:40:59 --> Language Class Initialized
INFO - 2018-05-09 14:40:59 --> Config Class Initialized
INFO - 2018-05-09 14:40:59 --> Loader Class Initialized
INFO - 2018-05-09 20:10:59 --> Helper loaded: url_helper
INFO - 2018-05-09 20:10:59 --> Helper loaded: notification_helper
INFO - 2018-05-09 20:10:59 --> Helper loaded: settings_helper
INFO - 2018-05-09 20:10:59 --> Helper loaded: permission_helper
INFO - 2018-05-09 20:10:59 --> Helper loaded: users_helper
INFO - 2018-05-09 20:10:59 --> Database Driver Class Initialized
DEBUG - 2018-05-09 20:10:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 20:10:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 20:10:59 --> Helper loaded: form_helper
INFO - 2018-05-09 20:10:59 --> Form Validation Class Initialized
INFO - 2018-05-09 20:10:59 --> Controller Class Initialized
INFO - 2018-05-09 20:10:59 --> Model Class Initialized
INFO - 2018-05-09 20:10:59 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 20:10:59 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 20:10:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 20:10:59 --> Model Class Initialized
INFO - 2018-05-09 20:10:59 --> Model Class Initialized
INFO - 2018-05-09 20:10:59 --> Model Class Initialized
INFO - 2018-05-09 20:10:59 --> Model Class Initialized
INFO - 2018-05-09 20:10:59 --> Model Class Initialized
INFO - 2018-05-09 20:10:59 --> Model Class Initialized
INFO - 2018-05-09 20:10:59 --> Model Class Initialized
INFO - 2018-05-09 20:10:59 --> Model Class Initialized
INFO - 2018-05-09 20:10:59 --> Model Class Initialized
INFO - 2018-05-09 20:10:59 --> Model Class Initialized
INFO - 2018-05-09 20:10:59 --> Model Class Initialized
INFO - 2018-05-09 20:10:59 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 20:10:59 --> Model Class Initialized
INFO - 2018-05-09 20:10:59 --> Final output sent to browser
DEBUG - 2018-05-09 20:10:59 --> Total execution time: 0.1245
INFO - 2018-05-09 14:41:00 --> Config Class Initialized
INFO - 2018-05-09 14:41:00 --> Hooks Class Initialized
DEBUG - 2018-05-09 14:41:00 --> UTF-8 Support Enabled
INFO - 2018-05-09 14:41:00 --> Utf8 Class Initialized
INFO - 2018-05-09 14:41:00 --> URI Class Initialized
INFO - 2018-05-09 14:41:00 --> Router Class Initialized
INFO - 2018-05-09 14:41:00 --> Output Class Initialized
INFO - 2018-05-09 14:41:00 --> Security Class Initialized
DEBUG - 2018-05-09 14:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 14:41:00 --> Input Class Initialized
INFO - 2018-05-09 14:41:00 --> Language Class Initialized
INFO - 2018-05-09 14:41:00 --> Language Class Initialized
INFO - 2018-05-09 14:41:00 --> Config Class Initialized
INFO - 2018-05-09 14:41:00 --> Loader Class Initialized
INFO - 2018-05-09 20:11:00 --> Helper loaded: url_helper
INFO - 2018-05-09 20:11:00 --> Helper loaded: notification_helper
INFO - 2018-05-09 20:11:00 --> Helper loaded: settings_helper
INFO - 2018-05-09 20:11:00 --> Helper loaded: permission_helper
INFO - 2018-05-09 20:11:00 --> Helper loaded: users_helper
INFO - 2018-05-09 20:11:00 --> Database Driver Class Initialized
DEBUG - 2018-05-09 20:11:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 20:11:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 20:11:00 --> Helper loaded: form_helper
INFO - 2018-05-09 20:11:00 --> Form Validation Class Initialized
INFO - 2018-05-09 20:11:00 --> Controller Class Initialized
INFO - 2018-05-09 20:11:00 --> Model Class Initialized
INFO - 2018-05-09 20:11:00 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 20:11:00 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 20:11:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 20:11:00 --> Model Class Initialized
INFO - 2018-05-09 20:11:00 --> Model Class Initialized
INFO - 2018-05-09 20:11:00 --> Model Class Initialized
INFO - 2018-05-09 20:11:00 --> Model Class Initialized
INFO - 2018-05-09 20:11:00 --> Model Class Initialized
INFO - 2018-05-09 20:11:00 --> Model Class Initialized
INFO - 2018-05-09 20:11:00 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 20:11:00 --> Model Class Initialized
INFO - 2018-05-09 20:11:00 --> Final output sent to browser
DEBUG - 2018-05-09 20:11:00 --> Total execution time: 0.1225
INFO - 2018-05-09 14:41:01 --> Config Class Initialized
INFO - 2018-05-09 14:41:01 --> Hooks Class Initialized
DEBUG - 2018-05-09 14:41:01 --> UTF-8 Support Enabled
INFO - 2018-05-09 14:41:01 --> Utf8 Class Initialized
INFO - 2018-05-09 14:41:01 --> URI Class Initialized
INFO - 2018-05-09 14:41:01 --> Router Class Initialized
INFO - 2018-05-09 14:41:01 --> Config Class Initialized
INFO - 2018-05-09 14:41:01 --> Hooks Class Initialized
INFO - 2018-05-09 14:41:01 --> Output Class Initialized
DEBUG - 2018-05-09 14:41:01 --> UTF-8 Support Enabled
INFO - 2018-05-09 14:41:01 --> Utf8 Class Initialized
INFO - 2018-05-09 14:41:01 --> Security Class Initialized
INFO - 2018-05-09 14:41:01 --> URI Class Initialized
DEBUG - 2018-05-09 14:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 14:41:01 --> Input Class Initialized
INFO - 2018-05-09 14:41:01 --> Language Class Initialized
INFO - 2018-05-09 14:41:01 --> Router Class Initialized
INFO - 2018-05-09 14:41:01 --> Output Class Initialized
INFO - 2018-05-09 14:41:01 --> Security Class Initialized
DEBUG - 2018-05-09 14:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 14:41:01 --> Input Class Initialized
INFO - 2018-05-09 14:41:01 --> Language Class Initialized
INFO - 2018-05-09 14:41:01 --> Language Class Initialized
INFO - 2018-05-09 14:41:01 --> Config Class Initialized
INFO - 2018-05-09 14:41:01 --> Loader Class Initialized
INFO - 2018-05-09 20:11:01 --> Helper loaded: url_helper
INFO - 2018-05-09 20:11:01 --> Helper loaded: notification_helper
INFO - 2018-05-09 20:11:01 --> Helper loaded: settings_helper
INFO - 2018-05-09 20:11:01 --> Helper loaded: permission_helper
INFO - 2018-05-09 20:11:01 --> Helper loaded: users_helper
INFO - 2018-05-09 14:41:01 --> Language Class Initialized
INFO - 2018-05-09 14:41:01 --> Config Class Initialized
INFO - 2018-05-09 14:41:01 --> Loader Class Initialized
INFO - 2018-05-09 20:11:01 --> Helper loaded: url_helper
INFO - 2018-05-09 20:11:01 --> Helper loaded: notification_helper
INFO - 2018-05-09 20:11:01 --> Helper loaded: settings_helper
INFO - 2018-05-09 20:11:01 --> Database Driver Class Initialized
INFO - 2018-05-09 20:11:01 --> Helper loaded: permission_helper
INFO - 2018-05-09 20:11:01 --> Helper loaded: users_helper
DEBUG - 2018-05-09 20:11:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 20:11:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 20:11:01 --> Helper loaded: form_helper
INFO - 2018-05-09 20:11:01 --> Form Validation Class Initialized
INFO - 2018-05-09 20:11:01 --> Controller Class Initialized
INFO - 2018-05-09 20:11:01 --> Database Driver Class Initialized
INFO - 2018-05-09 20:11:01 --> Model Class Initialized
INFO - 2018-05-09 20:11:01 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 20:11:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-05-09 20:11:01 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 20:11:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 20:11:01 --> Model Class Initialized
INFO - 2018-05-09 20:11:01 --> Model Class Initialized
INFO - 2018-05-09 20:11:01 --> Model Class Initialized
INFO - 2018-05-09 20:11:01 --> Model Class Initialized
INFO - 2018-05-09 20:11:01 --> Model Class Initialized
INFO - 2018-05-09 20:11:01 --> Model Class Initialized
INFO - 2018-05-09 20:11:01 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 20:11:01 --> Final output sent to browser
DEBUG - 2018-05-09 20:11:01 --> Total execution time: 0.1062
INFO - 2018-05-09 20:11:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 20:11:01 --> Helper loaded: form_helper
INFO - 2018-05-09 20:11:01 --> Form Validation Class Initialized
INFO - 2018-05-09 20:11:01 --> Controller Class Initialized
INFO - 2018-05-09 20:11:01 --> Model Class Initialized
INFO - 2018-05-09 20:11:01 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 20:11:01 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 20:11:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 20:11:01 --> Model Class Initialized
INFO - 2018-05-09 20:11:01 --> Model Class Initialized
INFO - 2018-05-09 20:11:01 --> Model Class Initialized
INFO - 2018-05-09 20:11:01 --> Model Class Initialized
INFO - 2018-05-09 20:11:01 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 20:11:01 --> Final output sent to browser
DEBUG - 2018-05-09 20:11:01 --> Total execution time: 0.1633
INFO - 2018-05-09 14:41:04 --> Config Class Initialized
INFO - 2018-05-09 14:41:04 --> Hooks Class Initialized
DEBUG - 2018-05-09 14:41:04 --> UTF-8 Support Enabled
INFO - 2018-05-09 14:41:04 --> Utf8 Class Initialized
INFO - 2018-05-09 14:41:04 --> URI Class Initialized
INFO - 2018-05-09 14:41:04 --> Router Class Initialized
INFO - 2018-05-09 14:41:04 --> Output Class Initialized
INFO - 2018-05-09 14:41:04 --> Security Class Initialized
DEBUG - 2018-05-09 14:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 14:41:04 --> Input Class Initialized
INFO - 2018-05-09 14:41:04 --> Language Class Initialized
INFO - 2018-05-09 14:41:04 --> Language Class Initialized
INFO - 2018-05-09 14:41:04 --> Config Class Initialized
INFO - 2018-05-09 14:41:04 --> Loader Class Initialized
INFO - 2018-05-09 20:11:04 --> Helper loaded: url_helper
INFO - 2018-05-09 20:11:04 --> Helper loaded: notification_helper
INFO - 2018-05-09 20:11:04 --> Helper loaded: settings_helper
INFO - 2018-05-09 20:11:04 --> Helper loaded: permission_helper
INFO - 2018-05-09 20:11:04 --> Helper loaded: users_helper
INFO - 2018-05-09 20:11:04 --> Database Driver Class Initialized
DEBUG - 2018-05-09 20:11:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 20:11:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 20:11:04 --> Helper loaded: form_helper
INFO - 2018-05-09 20:11:04 --> Form Validation Class Initialized
INFO - 2018-05-09 20:11:04 --> Controller Class Initialized
INFO - 2018-05-09 20:11:04 --> Model Class Initialized
INFO - 2018-05-09 20:11:04 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 20:11:04 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 20:11:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 20:11:04 --> Model Class Initialized
INFO - 2018-05-09 20:11:04 --> Model Class Initialized
INFO - 2018-05-09 20:11:04 --> Model Class Initialized
INFO - 2018-05-09 20:11:04 --> Model Class Initialized
INFO - 2018-05-09 20:11:04 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 20:11:04 --> Model Class Initialized
INFO - 2018-05-09 20:11:04 --> Final output sent to browser
DEBUG - 2018-05-09 20:11:04 --> Total execution time: 0.1047
INFO - 2018-05-09 14:41:53 --> Config Class Initialized
INFO - 2018-05-09 14:41:53 --> Hooks Class Initialized
DEBUG - 2018-05-09 14:41:53 --> UTF-8 Support Enabled
INFO - 2018-05-09 14:41:53 --> Utf8 Class Initialized
INFO - 2018-05-09 14:41:53 --> URI Class Initialized
INFO - 2018-05-09 14:41:53 --> Router Class Initialized
INFO - 2018-05-09 14:41:53 --> Output Class Initialized
INFO - 2018-05-09 14:41:53 --> Security Class Initialized
DEBUG - 2018-05-09 14:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 14:41:53 --> Input Class Initialized
INFO - 2018-05-09 14:41:53 --> Language Class Initialized
INFO - 2018-05-09 14:41:53 --> Language Class Initialized
INFO - 2018-05-09 14:41:53 --> Config Class Initialized
INFO - 2018-05-09 14:41:53 --> Loader Class Initialized
INFO - 2018-05-09 20:11:53 --> Helper loaded: url_helper
INFO - 2018-05-09 20:11:53 --> Helper loaded: notification_helper
INFO - 2018-05-09 20:11:53 --> Helper loaded: settings_helper
INFO - 2018-05-09 20:11:53 --> Helper loaded: permission_helper
INFO - 2018-05-09 20:11:53 --> Helper loaded: users_helper
INFO - 2018-05-09 20:11:53 --> Database Driver Class Initialized
DEBUG - 2018-05-09 20:11:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 20:11:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 20:11:53 --> Helper loaded: form_helper
INFO - 2018-05-09 20:11:53 --> Form Validation Class Initialized
INFO - 2018-05-09 20:11:53 --> Controller Class Initialized
INFO - 2018-05-09 20:11:54 --> Model Class Initialized
INFO - 2018-05-09 20:11:54 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 20:11:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 20:11:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 20:11:54 --> Model Class Initialized
INFO - 2018-05-09 20:11:54 --> Model Class Initialized
INFO - 2018-05-09 20:11:54 --> Model Class Initialized
INFO - 2018-05-09 20:11:54 --> Model Class Initialized
INFO - 2018-05-09 20:11:54 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 20:11:54 --> Model Class Initialized
INFO - 2018-05-09 20:11:54 --> Final output sent to browser
DEBUG - 2018-05-09 20:11:54 --> Total execution time: 0.1376
INFO - 2018-05-09 14:42:06 --> Config Class Initialized
INFO - 2018-05-09 14:42:06 --> Hooks Class Initialized
DEBUG - 2018-05-09 14:42:06 --> UTF-8 Support Enabled
INFO - 2018-05-09 14:42:06 --> Utf8 Class Initialized
INFO - 2018-05-09 14:42:06 --> URI Class Initialized
INFO - 2018-05-09 14:42:06 --> Router Class Initialized
INFO - 2018-05-09 14:42:06 --> Output Class Initialized
INFO - 2018-05-09 14:42:06 --> Security Class Initialized
DEBUG - 2018-05-09 14:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 14:42:06 --> Input Class Initialized
INFO - 2018-05-09 14:42:06 --> Language Class Initialized
INFO - 2018-05-09 14:42:06 --> Language Class Initialized
INFO - 2018-05-09 14:42:06 --> Config Class Initialized
INFO - 2018-05-09 14:42:06 --> Loader Class Initialized
INFO - 2018-05-09 20:12:06 --> Helper loaded: url_helper
INFO - 2018-05-09 20:12:06 --> Helper loaded: notification_helper
INFO - 2018-05-09 20:12:06 --> Helper loaded: settings_helper
INFO - 2018-05-09 20:12:06 --> Helper loaded: permission_helper
INFO - 2018-05-09 20:12:06 --> Helper loaded: users_helper
INFO - 2018-05-09 20:12:06 --> Database Driver Class Initialized
DEBUG - 2018-05-09 20:12:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 20:12:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 20:12:06 --> Helper loaded: form_helper
INFO - 2018-05-09 20:12:06 --> Form Validation Class Initialized
INFO - 2018-05-09 20:12:06 --> Controller Class Initialized
INFO - 2018-05-09 20:12:06 --> Model Class Initialized
INFO - 2018-05-09 20:12:06 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 20:12:06 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 20:12:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 20:12:06 --> Model Class Initialized
INFO - 2018-05-09 20:12:06 --> Model Class Initialized
INFO - 2018-05-09 20:12:06 --> Model Class Initialized
INFO - 2018-05-09 20:12:06 --> Model Class Initialized
INFO - 2018-05-09 20:12:06 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 20:12:06 --> Model Class Initialized
INFO - 2018-05-09 20:12:06 --> Final output sent to browser
DEBUG - 2018-05-09 20:12:06 --> Total execution time: 0.0970
INFO - 2018-05-09 14:42:11 --> Config Class Initialized
INFO - 2018-05-09 14:42:11 --> Hooks Class Initialized
DEBUG - 2018-05-09 14:42:11 --> UTF-8 Support Enabled
INFO - 2018-05-09 14:42:11 --> Utf8 Class Initialized
INFO - 2018-05-09 14:42:11 --> URI Class Initialized
INFO - 2018-05-09 14:42:11 --> Router Class Initialized
INFO - 2018-05-09 14:42:11 --> Output Class Initialized
INFO - 2018-05-09 14:42:11 --> Security Class Initialized
DEBUG - 2018-05-09 14:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 14:42:11 --> Input Class Initialized
INFO - 2018-05-09 14:42:11 --> Language Class Initialized
INFO - 2018-05-09 14:42:11 --> Language Class Initialized
INFO - 2018-05-09 14:42:11 --> Config Class Initialized
INFO - 2018-05-09 14:42:11 --> Loader Class Initialized
INFO - 2018-05-09 20:12:11 --> Helper loaded: url_helper
INFO - 2018-05-09 20:12:11 --> Helper loaded: notification_helper
INFO - 2018-05-09 20:12:11 --> Helper loaded: settings_helper
INFO - 2018-05-09 20:12:11 --> Helper loaded: permission_helper
INFO - 2018-05-09 20:12:11 --> Helper loaded: users_helper
INFO - 2018-05-09 20:12:11 --> Database Driver Class Initialized
DEBUG - 2018-05-09 20:12:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 20:12:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 20:12:11 --> Helper loaded: form_helper
INFO - 2018-05-09 20:12:11 --> Form Validation Class Initialized
INFO - 2018-05-09 20:12:11 --> Controller Class Initialized
INFO - 2018-05-09 20:12:11 --> Model Class Initialized
INFO - 2018-05-09 20:12:11 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 20:12:11 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 20:12:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 20:12:11 --> Model Class Initialized
INFO - 2018-05-09 20:12:11 --> Model Class Initialized
INFO - 2018-05-09 20:12:11 --> Model Class Initialized
INFO - 2018-05-09 20:12:11 --> Model Class Initialized
INFO - 2018-05-09 20:12:11 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 20:12:11 --> Model Class Initialized
INFO - 2018-05-09 20:12:11 --> Final output sent to browser
DEBUG - 2018-05-09 20:12:11 --> Total execution time: 0.1089
INFO - 2018-05-09 14:42:14 --> Config Class Initialized
INFO - 2018-05-09 14:42:14 --> Hooks Class Initialized
DEBUG - 2018-05-09 14:42:14 --> UTF-8 Support Enabled
INFO - 2018-05-09 14:42:14 --> Utf8 Class Initialized
INFO - 2018-05-09 14:42:14 --> URI Class Initialized
INFO - 2018-05-09 14:42:14 --> Router Class Initialized
INFO - 2018-05-09 14:42:14 --> Output Class Initialized
INFO - 2018-05-09 14:42:14 --> Security Class Initialized
DEBUG - 2018-05-09 14:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 14:42:14 --> Input Class Initialized
INFO - 2018-05-09 14:42:14 --> Language Class Initialized
INFO - 2018-05-09 14:42:14 --> Language Class Initialized
INFO - 2018-05-09 14:42:14 --> Config Class Initialized
INFO - 2018-05-09 14:42:14 --> Loader Class Initialized
INFO - 2018-05-09 20:12:14 --> Helper loaded: url_helper
INFO - 2018-05-09 20:12:14 --> Helper loaded: notification_helper
INFO - 2018-05-09 20:12:14 --> Helper loaded: settings_helper
INFO - 2018-05-09 20:12:14 --> Helper loaded: permission_helper
INFO - 2018-05-09 20:12:14 --> Helper loaded: users_helper
INFO - 2018-05-09 20:12:14 --> Database Driver Class Initialized
DEBUG - 2018-05-09 20:12:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 20:12:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 20:12:14 --> Helper loaded: form_helper
INFO - 2018-05-09 20:12:14 --> Form Validation Class Initialized
INFO - 2018-05-09 20:12:14 --> Controller Class Initialized
INFO - 2018-05-09 20:12:14 --> Model Class Initialized
INFO - 2018-05-09 20:12:14 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 20:12:14 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 20:12:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 20:12:14 --> Model Class Initialized
INFO - 2018-05-09 20:12:14 --> Model Class Initialized
INFO - 2018-05-09 20:12:14 --> Model Class Initialized
INFO - 2018-05-09 20:12:14 --> Model Class Initialized
INFO - 2018-05-09 20:12:14 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 20:12:14 --> Model Class Initialized
INFO - 2018-05-09 20:12:14 --> Final output sent to browser
DEBUG - 2018-05-09 20:12:14 --> Total execution time: 0.1199
INFO - 2018-05-09 14:42:17 --> Config Class Initialized
INFO - 2018-05-09 14:42:17 --> Hooks Class Initialized
DEBUG - 2018-05-09 14:42:17 --> UTF-8 Support Enabled
INFO - 2018-05-09 14:42:17 --> Utf8 Class Initialized
INFO - 2018-05-09 14:42:17 --> URI Class Initialized
INFO - 2018-05-09 14:42:17 --> Router Class Initialized
INFO - 2018-05-09 14:42:17 --> Output Class Initialized
INFO - 2018-05-09 14:42:17 --> Security Class Initialized
DEBUG - 2018-05-09 14:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 14:42:17 --> Input Class Initialized
INFO - 2018-05-09 14:42:17 --> Language Class Initialized
INFO - 2018-05-09 14:42:17 --> Language Class Initialized
INFO - 2018-05-09 14:42:17 --> Config Class Initialized
INFO - 2018-05-09 14:42:17 --> Loader Class Initialized
INFO - 2018-05-09 20:12:17 --> Helper loaded: url_helper
INFO - 2018-05-09 20:12:17 --> Helper loaded: notification_helper
INFO - 2018-05-09 20:12:17 --> Helper loaded: settings_helper
INFO - 2018-05-09 20:12:17 --> Helper loaded: permission_helper
INFO - 2018-05-09 20:12:17 --> Helper loaded: users_helper
INFO - 2018-05-09 20:12:17 --> Database Driver Class Initialized
DEBUG - 2018-05-09 20:12:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 20:12:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 20:12:17 --> Helper loaded: form_helper
INFO - 2018-05-09 20:12:17 --> Form Validation Class Initialized
INFO - 2018-05-09 20:12:17 --> Controller Class Initialized
INFO - 2018-05-09 20:12:17 --> Model Class Initialized
INFO - 2018-05-09 20:12:17 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 20:12:17 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 20:12:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 20:12:17 --> Model Class Initialized
INFO - 2018-05-09 20:12:17 --> Model Class Initialized
INFO - 2018-05-09 20:12:17 --> Model Class Initialized
INFO - 2018-05-09 20:12:17 --> Model Class Initialized
INFO - 2018-05-09 20:12:17 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 20:12:17 --> Model Class Initialized
INFO - 2018-05-09 20:12:17 --> Final output sent to browser
DEBUG - 2018-05-09 20:12:17 --> Total execution time: 0.1084
INFO - 2018-05-09 14:42:21 --> Config Class Initialized
INFO - 2018-05-09 14:42:21 --> Hooks Class Initialized
DEBUG - 2018-05-09 14:42:21 --> UTF-8 Support Enabled
INFO - 2018-05-09 14:42:21 --> Utf8 Class Initialized
INFO - 2018-05-09 14:42:21 --> URI Class Initialized
INFO - 2018-05-09 14:42:21 --> Router Class Initialized
INFO - 2018-05-09 14:42:21 --> Output Class Initialized
INFO - 2018-05-09 14:42:21 --> Security Class Initialized
DEBUG - 2018-05-09 14:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 14:42:21 --> Input Class Initialized
INFO - 2018-05-09 14:42:21 --> Language Class Initialized
INFO - 2018-05-09 14:42:21 --> Language Class Initialized
INFO - 2018-05-09 14:42:21 --> Config Class Initialized
INFO - 2018-05-09 14:42:21 --> Loader Class Initialized
INFO - 2018-05-09 20:12:21 --> Helper loaded: url_helper
INFO - 2018-05-09 20:12:21 --> Helper loaded: notification_helper
INFO - 2018-05-09 20:12:21 --> Helper loaded: settings_helper
INFO - 2018-05-09 20:12:21 --> Helper loaded: permission_helper
INFO - 2018-05-09 20:12:21 --> Helper loaded: users_helper
INFO - 2018-05-09 20:12:21 --> Database Driver Class Initialized
DEBUG - 2018-05-09 20:12:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 20:12:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 20:12:21 --> Helper loaded: form_helper
INFO - 2018-05-09 20:12:21 --> Form Validation Class Initialized
INFO - 2018-05-09 20:12:21 --> Controller Class Initialized
INFO - 2018-05-09 20:12:21 --> Model Class Initialized
INFO - 2018-05-09 20:12:21 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 20:12:21 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 20:12:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 20:12:21 --> Model Class Initialized
INFO - 2018-05-09 20:12:21 --> Model Class Initialized
INFO - 2018-05-09 20:12:21 --> Model Class Initialized
INFO - 2018-05-09 20:12:21 --> Model Class Initialized
INFO - 2018-05-09 20:12:21 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 20:12:21 --> Model Class Initialized
INFO - 2018-05-09 20:12:21 --> Final output sent to browser
DEBUG - 2018-05-09 20:12:21 --> Total execution time: 0.1020
INFO - 2018-05-09 14:42:24 --> Config Class Initialized
INFO - 2018-05-09 14:42:24 --> Hooks Class Initialized
DEBUG - 2018-05-09 14:42:24 --> UTF-8 Support Enabled
INFO - 2018-05-09 14:42:24 --> Utf8 Class Initialized
INFO - 2018-05-09 14:42:24 --> URI Class Initialized
INFO - 2018-05-09 14:42:24 --> Router Class Initialized
INFO - 2018-05-09 14:42:24 --> Output Class Initialized
INFO - 2018-05-09 14:42:24 --> Security Class Initialized
DEBUG - 2018-05-09 14:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 14:42:24 --> Input Class Initialized
INFO - 2018-05-09 14:42:24 --> Language Class Initialized
INFO - 2018-05-09 14:42:24 --> Language Class Initialized
INFO - 2018-05-09 14:42:24 --> Config Class Initialized
INFO - 2018-05-09 14:42:24 --> Loader Class Initialized
INFO - 2018-05-09 20:12:24 --> Helper loaded: url_helper
INFO - 2018-05-09 20:12:24 --> Helper loaded: notification_helper
INFO - 2018-05-09 20:12:24 --> Helper loaded: settings_helper
INFO - 2018-05-09 20:12:24 --> Helper loaded: permission_helper
INFO - 2018-05-09 20:12:24 --> Helper loaded: users_helper
INFO - 2018-05-09 20:12:24 --> Database Driver Class Initialized
DEBUG - 2018-05-09 20:12:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 20:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 20:12:24 --> Helper loaded: form_helper
INFO - 2018-05-09 20:12:24 --> Form Validation Class Initialized
INFO - 2018-05-09 20:12:24 --> Controller Class Initialized
INFO - 2018-05-09 20:12:24 --> Model Class Initialized
INFO - 2018-05-09 20:12:24 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 20:12:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 20:12:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 20:12:24 --> Model Class Initialized
INFO - 2018-05-09 20:12:24 --> Model Class Initialized
INFO - 2018-05-09 20:12:24 --> Model Class Initialized
INFO - 2018-05-09 20:12:24 --> Model Class Initialized
INFO - 2018-05-09 20:12:24 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 20:12:24 --> Model Class Initialized
INFO - 2018-05-09 20:12:24 --> Final output sent to browser
DEBUG - 2018-05-09 20:12:24 --> Total execution time: 0.0986
INFO - 2018-05-09 14:42:29 --> Config Class Initialized
INFO - 2018-05-09 14:42:29 --> Hooks Class Initialized
DEBUG - 2018-05-09 14:42:29 --> UTF-8 Support Enabled
INFO - 2018-05-09 14:42:29 --> Utf8 Class Initialized
INFO - 2018-05-09 14:42:29 --> URI Class Initialized
INFO - 2018-05-09 14:42:29 --> Router Class Initialized
INFO - 2018-05-09 14:42:29 --> Output Class Initialized
INFO - 2018-05-09 14:42:29 --> Security Class Initialized
DEBUG - 2018-05-09 14:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 14:42:29 --> Input Class Initialized
INFO - 2018-05-09 14:42:29 --> Language Class Initialized
INFO - 2018-05-09 14:42:29 --> Language Class Initialized
INFO - 2018-05-09 14:42:29 --> Config Class Initialized
INFO - 2018-05-09 14:42:29 --> Loader Class Initialized
INFO - 2018-05-09 20:12:29 --> Helper loaded: url_helper
INFO - 2018-05-09 20:12:29 --> Helper loaded: notification_helper
INFO - 2018-05-09 20:12:29 --> Helper loaded: settings_helper
INFO - 2018-05-09 20:12:29 --> Helper loaded: permission_helper
INFO - 2018-05-09 20:12:29 --> Helper loaded: users_helper
INFO - 2018-05-09 20:12:29 --> Database Driver Class Initialized
DEBUG - 2018-05-09 20:12:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 20:12:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 20:12:29 --> Helper loaded: form_helper
INFO - 2018-05-09 20:12:29 --> Form Validation Class Initialized
INFO - 2018-05-09 20:12:29 --> Controller Class Initialized
INFO - 2018-05-09 20:12:29 --> Model Class Initialized
INFO - 2018-05-09 20:12:29 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 20:12:29 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 20:12:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 20:12:29 --> Model Class Initialized
INFO - 2018-05-09 20:12:29 --> Model Class Initialized
INFO - 2018-05-09 20:12:29 --> Model Class Initialized
INFO - 2018-05-09 20:12:29 --> Model Class Initialized
INFO - 2018-05-09 20:12:29 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 20:12:29 --> Model Class Initialized
INFO - 2018-05-09 20:12:29 --> Final output sent to browser
DEBUG - 2018-05-09 20:12:29 --> Total execution time: 0.1281
INFO - 2018-05-09 14:43:28 --> Config Class Initialized
INFO - 2018-05-09 14:43:28 --> Hooks Class Initialized
DEBUG - 2018-05-09 14:43:28 --> UTF-8 Support Enabled
INFO - 2018-05-09 14:43:28 --> Utf8 Class Initialized
INFO - 2018-05-09 14:43:28 --> URI Class Initialized
INFO - 2018-05-09 14:43:28 --> Router Class Initialized
INFO - 2018-05-09 14:43:28 --> Output Class Initialized
INFO - 2018-05-09 14:43:28 --> Security Class Initialized
DEBUG - 2018-05-09 14:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 14:43:28 --> Input Class Initialized
INFO - 2018-05-09 14:43:28 --> Language Class Initialized
INFO - 2018-05-09 14:43:28 --> Language Class Initialized
INFO - 2018-05-09 14:43:28 --> Config Class Initialized
INFO - 2018-05-09 14:43:28 --> Loader Class Initialized
INFO - 2018-05-09 20:13:28 --> Helper loaded: url_helper
INFO - 2018-05-09 20:13:28 --> Helper loaded: notification_helper
INFO - 2018-05-09 20:13:28 --> Helper loaded: settings_helper
INFO - 2018-05-09 20:13:28 --> Helper loaded: permission_helper
INFO - 2018-05-09 20:13:28 --> Helper loaded: users_helper
INFO - 2018-05-09 20:13:28 --> Database Driver Class Initialized
DEBUG - 2018-05-09 20:13:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 20:13:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 20:13:28 --> Helper loaded: form_helper
INFO - 2018-05-09 20:13:28 --> Form Validation Class Initialized
INFO - 2018-05-09 20:13:28 --> Controller Class Initialized
INFO - 2018-05-09 20:13:28 --> Model Class Initialized
INFO - 2018-05-09 20:13:28 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 20:13:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 20:13:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 20:13:28 --> Model Class Initialized
INFO - 2018-05-09 20:13:28 --> Model Class Initialized
INFO - 2018-05-09 20:13:28 --> Model Class Initialized
INFO - 2018-05-09 20:13:28 --> Model Class Initialized
INFO - 2018-05-09 20:13:28 --> Model Class Initialized
INFO - 2018-05-09 20:13:28 --> Model Class Initialized
INFO - 2018-05-09 20:13:28 --> Model Class Initialized
INFO - 2018-05-09 20:13:28 --> Model Class Initialized
INFO - 2018-05-09 20:13:28 --> Model Class Initialized
INFO - 2018-05-09 20:13:28 --> Model Class Initialized
INFO - 2018-05-09 20:13:28 --> Model Class Initialized
INFO - 2018-05-09 20:13:28 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 20:13:28 --> Model Class Initialized
INFO - 2018-05-09 20:13:28 --> Final output sent to browser
DEBUG - 2018-05-09 20:13:28 --> Total execution time: 0.1220
INFO - 2018-05-09 14:43:29 --> Config Class Initialized
INFO - 2018-05-09 14:43:29 --> Hooks Class Initialized
DEBUG - 2018-05-09 14:43:29 --> UTF-8 Support Enabled
INFO - 2018-05-09 14:43:29 --> Utf8 Class Initialized
INFO - 2018-05-09 14:43:29 --> URI Class Initialized
INFO - 2018-05-09 14:43:29 --> Router Class Initialized
INFO - 2018-05-09 14:43:29 --> Output Class Initialized
INFO - 2018-05-09 14:43:29 --> Security Class Initialized
DEBUG - 2018-05-09 14:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 14:43:29 --> Input Class Initialized
INFO - 2018-05-09 14:43:29 --> Language Class Initialized
INFO - 2018-05-09 14:43:29 --> Language Class Initialized
INFO - 2018-05-09 14:43:29 --> Config Class Initialized
INFO - 2018-05-09 14:43:29 --> Loader Class Initialized
INFO - 2018-05-09 20:13:29 --> Helper loaded: url_helper
INFO - 2018-05-09 20:13:29 --> Helper loaded: notification_helper
INFO - 2018-05-09 20:13:29 --> Helper loaded: settings_helper
INFO - 2018-05-09 20:13:29 --> Helper loaded: permission_helper
INFO - 2018-05-09 20:13:29 --> Helper loaded: users_helper
INFO - 2018-05-09 20:13:29 --> Database Driver Class Initialized
DEBUG - 2018-05-09 20:13:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 20:13:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 20:13:29 --> Helper loaded: form_helper
INFO - 2018-05-09 20:13:29 --> Form Validation Class Initialized
INFO - 2018-05-09 20:13:29 --> Controller Class Initialized
INFO - 2018-05-09 20:13:29 --> Model Class Initialized
INFO - 2018-05-09 20:13:29 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 20:13:29 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 20:13:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 20:13:29 --> Model Class Initialized
INFO - 2018-05-09 20:13:29 --> Model Class Initialized
INFO - 2018-05-09 20:13:29 --> Model Class Initialized
INFO - 2018-05-09 20:13:29 --> Model Class Initialized
INFO - 2018-05-09 20:13:29 --> Model Class Initialized
INFO - 2018-05-09 20:13:29 --> Model Class Initialized
INFO - 2018-05-09 20:13:29 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 20:13:29 --> Model Class Initialized
INFO - 2018-05-09 20:13:29 --> Final output sent to browser
DEBUG - 2018-05-09 20:13:29 --> Total execution time: 0.1229
INFO - 2018-05-09 14:43:31 --> Config Class Initialized
INFO - 2018-05-09 14:43:31 --> Hooks Class Initialized
DEBUG - 2018-05-09 14:43:31 --> UTF-8 Support Enabled
INFO - 2018-05-09 14:43:31 --> Utf8 Class Initialized
INFO - 2018-05-09 14:43:31 --> Config Class Initialized
INFO - 2018-05-09 14:43:31 --> Hooks Class Initialized
INFO - 2018-05-09 14:43:31 --> URI Class Initialized
DEBUG - 2018-05-09 14:43:31 --> UTF-8 Support Enabled
INFO - 2018-05-09 14:43:31 --> Utf8 Class Initialized
INFO - 2018-05-09 14:43:31 --> Router Class Initialized
INFO - 2018-05-09 14:43:31 --> URI Class Initialized
INFO - 2018-05-09 14:43:31 --> Output Class Initialized
INFO - 2018-05-09 14:43:31 --> Router Class Initialized
INFO - 2018-05-09 14:43:31 --> Security Class Initialized
INFO - 2018-05-09 14:43:31 --> Output Class Initialized
DEBUG - 2018-05-09 14:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 14:43:31 --> Input Class Initialized
INFO - 2018-05-09 14:43:31 --> Language Class Initialized
INFO - 2018-05-09 14:43:31 --> Security Class Initialized
DEBUG - 2018-05-09 14:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 14:43:31 --> Input Class Initialized
INFO - 2018-05-09 14:43:31 --> Language Class Initialized
INFO - 2018-05-09 14:43:31 --> Language Class Initialized
INFO - 2018-05-09 14:43:31 --> Config Class Initialized
INFO - 2018-05-09 14:43:31 --> Loader Class Initialized
INFO - 2018-05-09 20:13:31 --> Helper loaded: url_helper
INFO - 2018-05-09 20:13:31 --> Helper loaded: notification_helper
INFO - 2018-05-09 20:13:31 --> Helper loaded: settings_helper
INFO - 2018-05-09 20:13:31 --> Helper loaded: permission_helper
INFO - 2018-05-09 20:13:31 --> Helper loaded: users_helper
INFO - 2018-05-09 14:43:31 --> Language Class Initialized
INFO - 2018-05-09 14:43:31 --> Config Class Initialized
INFO - 2018-05-09 14:43:31 --> Loader Class Initialized
INFO - 2018-05-09 20:13:31 --> Helper loaded: url_helper
INFO - 2018-05-09 20:13:31 --> Helper loaded: notification_helper
INFO - 2018-05-09 20:13:31 --> Helper loaded: settings_helper
INFO - 2018-05-09 20:13:31 --> Helper loaded: permission_helper
INFO - 2018-05-09 20:13:31 --> Helper loaded: users_helper
INFO - 2018-05-09 20:13:31 --> Database Driver Class Initialized
DEBUG - 2018-05-09 20:13:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 20:13:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 20:13:31 --> Database Driver Class Initialized
INFO - 2018-05-09 20:13:31 --> Helper loaded: form_helper
INFO - 2018-05-09 20:13:31 --> Form Validation Class Initialized
INFO - 2018-05-09 20:13:31 --> Controller Class Initialized
DEBUG - 2018-05-09 20:13:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 20:13:31 --> Model Class Initialized
INFO - 2018-05-09 20:13:31 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 20:13:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 20:13:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 20:13:31 --> Model Class Initialized
INFO - 2018-05-09 20:13:31 --> Model Class Initialized
INFO - 2018-05-09 20:13:31 --> Model Class Initialized
INFO - 2018-05-09 20:13:31 --> Model Class Initialized
INFO - 2018-05-09 20:13:31 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 20:13:31 --> Final output sent to browser
DEBUG - 2018-05-09 20:13:31 --> Total execution time: 0.0989
INFO - 2018-05-09 20:13:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 20:13:31 --> Helper loaded: form_helper
INFO - 2018-05-09 20:13:31 --> Form Validation Class Initialized
INFO - 2018-05-09 20:13:31 --> Controller Class Initialized
INFO - 2018-05-09 20:13:32 --> Model Class Initialized
INFO - 2018-05-09 20:13:32 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 20:13:32 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 20:13:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 20:13:32 --> Model Class Initialized
INFO - 2018-05-09 20:13:32 --> Model Class Initialized
INFO - 2018-05-09 20:13:32 --> Model Class Initialized
INFO - 2018-05-09 20:13:32 --> Model Class Initialized
INFO - 2018-05-09 20:13:32 --> Model Class Initialized
INFO - 2018-05-09 20:13:32 --> Model Class Initialized
INFO - 2018-05-09 20:13:32 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 20:13:32 --> Final output sent to browser
DEBUG - 2018-05-09 20:13:32 --> Total execution time: 0.1285
INFO - 2018-05-09 14:44:05 --> Config Class Initialized
INFO - 2018-05-09 14:44:05 --> Hooks Class Initialized
DEBUG - 2018-05-09 14:44:05 --> UTF-8 Support Enabled
INFO - 2018-05-09 14:44:05 --> Utf8 Class Initialized
INFO - 2018-05-09 14:44:05 --> URI Class Initialized
INFO - 2018-05-09 14:44:05 --> Router Class Initialized
INFO - 2018-05-09 14:44:05 --> Output Class Initialized
INFO - 2018-05-09 14:44:05 --> Security Class Initialized
DEBUG - 2018-05-09 14:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 14:44:05 --> Input Class Initialized
INFO - 2018-05-09 14:44:05 --> Language Class Initialized
INFO - 2018-05-09 14:44:05 --> Language Class Initialized
INFO - 2018-05-09 14:44:05 --> Config Class Initialized
INFO - 2018-05-09 14:44:05 --> Loader Class Initialized
INFO - 2018-05-09 20:14:06 --> Helper loaded: url_helper
INFO - 2018-05-09 20:14:06 --> Helper loaded: notification_helper
INFO - 2018-05-09 20:14:06 --> Helper loaded: settings_helper
INFO - 2018-05-09 20:14:06 --> Helper loaded: permission_helper
INFO - 2018-05-09 20:14:06 --> Helper loaded: users_helper
INFO - 2018-05-09 20:14:06 --> Database Driver Class Initialized
DEBUG - 2018-05-09 20:14:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 20:14:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 20:14:06 --> Helper loaded: form_helper
INFO - 2018-05-09 20:14:06 --> Form Validation Class Initialized
INFO - 2018-05-09 20:14:06 --> Controller Class Initialized
INFO - 2018-05-09 20:14:06 --> Model Class Initialized
INFO - 2018-05-09 20:14:06 --> Helper loaded: inflector_helper
DEBUG - 2018-05-09 20:14:06 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-09 20:14:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-09 20:14:06 --> Model Class Initialized
INFO - 2018-05-09 20:14:06 --> Model Class Initialized
INFO - 2018-05-09 20:14:06 --> Model Class Initialized
INFO - 2018-05-09 20:14:06 --> Model Class Initialized
INFO - 2018-05-09 20:14:06 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-09 20:14:06 --> Model Class Initialized
INFO - 2018-05-09 20:14:06 --> Final output sent to browser
DEBUG - 2018-05-09 20:14:06 --> Total execution time: 0.1046
