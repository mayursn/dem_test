<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-05-10 05:02:37 --> Config Class Initialized
INFO - 2018-05-10 05:02:37 --> Hooks Class Initialized
DEBUG - 2018-05-10 05:02:37 --> UTF-8 Support Enabled
INFO - 2018-05-10 05:02:37 --> Utf8 Class Initialized
INFO - 2018-05-10 05:02:37 --> URI Class Initialized
INFO - 2018-05-10 05:02:37 --> Router Class Initialized
INFO - 2018-05-10 05:02:37 --> Output Class Initialized
INFO - 2018-05-10 05:02:37 --> Security Class Initialized
DEBUG - 2018-05-10 05:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 05:02:37 --> Input Class Initialized
INFO - 2018-05-10 05:02:37 --> Language Class Initialized
INFO - 2018-05-10 05:02:37 --> Language Class Initialized
INFO - 2018-05-10 05:02:37 --> Config Class Initialized
INFO - 2018-05-10 05:02:37 --> Loader Class Initialized
INFO - 2018-05-10 10:32:37 --> Helper loaded: url_helper
INFO - 2018-05-10 10:32:37 --> Helper loaded: notification_helper
INFO - 2018-05-10 10:32:37 --> Helper loaded: settings_helper
INFO - 2018-05-10 10:32:37 --> Helper loaded: permission_helper
INFO - 2018-05-10 10:32:37 --> Helper loaded: users_helper
INFO - 2018-05-10 10:32:37 --> Database Driver Class Initialized
DEBUG - 2018-05-10 10:32:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 10:32:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 10:32:37 --> Helper loaded: form_helper
INFO - 2018-05-10 10:32:37 --> Form Validation Class Initialized
INFO - 2018-05-10 10:32:37 --> Controller Class Initialized
INFO - 2018-05-10 10:32:37 --> Model Class Initialized
INFO - 2018-05-10 10:32:37 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 10:32:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 10:32:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 10:32:37 --> Model Class Initialized
INFO - 2018-05-10 10:32:37 --> Model Class Initialized
INFO - 2018-05-10 10:32:37 --> Model Class Initialized
INFO - 2018-05-10 10:32:37 --> Model Class Initialized
INFO - 2018-05-10 10:32:37 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 10:32:37 --> Model Class Initialized
INFO - 2018-05-10 10:32:37 --> Final output sent to browser
DEBUG - 2018-05-10 10:32:37 --> Total execution time: 0.1841
INFO - 2018-05-10 06:02:56 --> Config Class Initialized
INFO - 2018-05-10 06:02:56 --> Hooks Class Initialized
DEBUG - 2018-05-10 06:02:56 --> UTF-8 Support Enabled
INFO - 2018-05-10 06:02:56 --> Utf8 Class Initialized
INFO - 2018-05-10 06:02:56 --> URI Class Initialized
INFO - 2018-05-10 06:02:56 --> Router Class Initialized
INFO - 2018-05-10 06:02:56 --> Output Class Initialized
INFO - 2018-05-10 06:02:56 --> Security Class Initialized
DEBUG - 2018-05-10 06:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 06:02:56 --> Input Class Initialized
INFO - 2018-05-10 06:02:56 --> Language Class Initialized
INFO - 2018-05-10 06:02:56 --> Language Class Initialized
INFO - 2018-05-10 06:02:56 --> Config Class Initialized
INFO - 2018-05-10 06:02:56 --> Loader Class Initialized
INFO - 2018-05-10 11:32:56 --> Helper loaded: url_helper
INFO - 2018-05-10 11:32:56 --> Helper loaded: notification_helper
INFO - 2018-05-10 11:32:56 --> Helper loaded: settings_helper
INFO - 2018-05-10 11:32:56 --> Helper loaded: permission_helper
INFO - 2018-05-10 11:32:56 --> Helper loaded: users_helper
INFO - 2018-05-10 11:32:56 --> Database Driver Class Initialized
DEBUG - 2018-05-10 11:32:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 11:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 11:32:56 --> Helper loaded: form_helper
INFO - 2018-05-10 11:32:56 --> Form Validation Class Initialized
INFO - 2018-05-10 11:32:56 --> Controller Class Initialized
INFO - 2018-05-10 11:32:56 --> Model Class Initialized
INFO - 2018-05-10 11:32:56 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 11:32:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 11:32:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 11:32:56 --> Model Class Initialized
INFO - 2018-05-10 11:32:56 --> Model Class Initialized
INFO - 2018-05-10 11:32:56 --> Model Class Initialized
INFO - 2018-05-10 11:32:56 --> Model Class Initialized
INFO - 2018-05-10 11:32:56 --> Model Class Initialized
INFO - 2018-05-10 11:32:56 --> Model Class Initialized
INFO - 2018-05-10 11:32:56 --> Model Class Initialized
INFO - 2018-05-10 11:32:56 --> Model Class Initialized
INFO - 2018-05-10 11:32:56 --> Model Class Initialized
INFO - 2018-05-10 11:32:56 --> Model Class Initialized
INFO - 2018-05-10 11:32:56 --> Model Class Initialized
INFO - 2018-05-10 11:32:56 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 11:32:56 --> Model Class Initialized
INFO - 2018-05-10 11:32:56 --> Final output sent to browser
DEBUG - 2018-05-10 11:32:56 --> Total execution time: 0.1131
INFO - 2018-05-10 06:02:59 --> Config Class Initialized
INFO - 2018-05-10 06:02:59 --> Hooks Class Initialized
DEBUG - 2018-05-10 06:02:59 --> UTF-8 Support Enabled
INFO - 2018-05-10 06:02:59 --> Utf8 Class Initialized
INFO - 2018-05-10 06:02:59 --> URI Class Initialized
INFO - 2018-05-10 06:02:59 --> Router Class Initialized
INFO - 2018-05-10 06:02:59 --> Output Class Initialized
INFO - 2018-05-10 06:02:59 --> Security Class Initialized
DEBUG - 2018-05-10 06:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 06:02:59 --> Input Class Initialized
INFO - 2018-05-10 06:02:59 --> Language Class Initialized
INFO - 2018-05-10 06:03:00 --> Language Class Initialized
INFO - 2018-05-10 06:03:00 --> Config Class Initialized
INFO - 2018-05-10 06:03:00 --> Loader Class Initialized
INFO - 2018-05-10 11:33:00 --> Helper loaded: url_helper
INFO - 2018-05-10 11:33:00 --> Helper loaded: notification_helper
INFO - 2018-05-10 11:33:00 --> Helper loaded: settings_helper
INFO - 2018-05-10 11:33:00 --> Helper loaded: permission_helper
INFO - 2018-05-10 11:33:00 --> Helper loaded: users_helper
INFO - 2018-05-10 11:33:00 --> Database Driver Class Initialized
DEBUG - 2018-05-10 11:33:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 11:33:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 11:33:00 --> Helper loaded: form_helper
INFO - 2018-05-10 11:33:00 --> Form Validation Class Initialized
INFO - 2018-05-10 11:33:00 --> Controller Class Initialized
INFO - 2018-05-10 11:33:00 --> Model Class Initialized
INFO - 2018-05-10 11:33:00 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 11:33:00 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 11:33:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 11:33:00 --> Model Class Initialized
INFO - 2018-05-10 11:33:00 --> Model Class Initialized
INFO - 2018-05-10 11:33:00 --> Model Class Initialized
INFO - 2018-05-10 11:33:00 --> Model Class Initialized
INFO - 2018-05-10 11:33:00 --> Model Class Initialized
INFO - 2018-05-10 11:33:00 --> Model Class Initialized
INFO - 2018-05-10 11:33:00 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 11:33:00 --> Model Class Initialized
INFO - 2018-05-10 11:33:00 --> Final output sent to browser
DEBUG - 2018-05-10 11:33:00 --> Total execution time: 0.1077
INFO - 2018-05-10 06:03:14 --> Config Class Initialized
INFO - 2018-05-10 06:03:14 --> Hooks Class Initialized
DEBUG - 2018-05-10 06:03:14 --> UTF-8 Support Enabled
INFO - 2018-05-10 06:03:14 --> Utf8 Class Initialized
INFO - 2018-05-10 06:03:14 --> URI Class Initialized
INFO - 2018-05-10 06:03:14 --> Router Class Initialized
INFO - 2018-05-10 06:03:14 --> Output Class Initialized
INFO - 2018-05-10 06:03:14 --> Security Class Initialized
DEBUG - 2018-05-10 06:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 06:03:14 --> Input Class Initialized
INFO - 2018-05-10 06:03:14 --> Language Class Initialized
INFO - 2018-05-10 06:03:14 --> Language Class Initialized
INFO - 2018-05-10 06:03:14 --> Config Class Initialized
INFO - 2018-05-10 06:03:14 --> Loader Class Initialized
INFO - 2018-05-10 11:33:14 --> Helper loaded: url_helper
INFO - 2018-05-10 11:33:14 --> Helper loaded: notification_helper
INFO - 2018-05-10 11:33:14 --> Helper loaded: settings_helper
INFO - 2018-05-10 11:33:14 --> Helper loaded: permission_helper
INFO - 2018-05-10 11:33:14 --> Helper loaded: users_helper
INFO - 2018-05-10 11:33:14 --> Database Driver Class Initialized
INFO - 2018-05-10 06:03:14 --> Config Class Initialized
INFO - 2018-05-10 06:03:14 --> Hooks Class Initialized
DEBUG - 2018-05-10 11:33:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 11:33:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-05-10 06:03:14 --> UTF-8 Support Enabled
INFO - 2018-05-10 06:03:14 --> Utf8 Class Initialized
INFO - 2018-05-10 06:03:14 --> URI Class Initialized
INFO - 2018-05-10 06:03:14 --> Router Class Initialized
INFO - 2018-05-10 11:33:14 --> Helper loaded: form_helper
INFO - 2018-05-10 11:33:14 --> Form Validation Class Initialized
INFO - 2018-05-10 11:33:14 --> Controller Class Initialized
INFO - 2018-05-10 06:03:14 --> Output Class Initialized
INFO - 2018-05-10 06:03:14 --> Security Class Initialized
INFO - 2018-05-10 11:33:14 --> Model Class Initialized
INFO - 2018-05-10 11:33:14 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 06:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 06:03:14 --> Input Class Initialized
INFO - 2018-05-10 06:03:14 --> Language Class Initialized
DEBUG - 2018-05-10 11:33:14 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 11:33:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 11:33:14 --> Model Class Initialized
INFO - 2018-05-10 11:33:14 --> Model Class Initialized
INFO - 2018-05-10 11:33:14 --> Model Class Initialized
INFO - 2018-05-10 11:33:14 --> Model Class Initialized
INFO - 2018-05-10 11:33:14 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 11:33:14 --> Final output sent to browser
DEBUG - 2018-05-10 11:33:14 --> Total execution time: 0.0987
INFO - 2018-05-10 06:03:14 --> Language Class Initialized
INFO - 2018-05-10 06:03:14 --> Config Class Initialized
INFO - 2018-05-10 06:03:14 --> Loader Class Initialized
INFO - 2018-05-10 11:33:14 --> Helper loaded: url_helper
INFO - 2018-05-10 11:33:14 --> Helper loaded: notification_helper
INFO - 2018-05-10 11:33:14 --> Helper loaded: settings_helper
INFO - 2018-05-10 11:33:14 --> Helper loaded: permission_helper
INFO - 2018-05-10 11:33:14 --> Helper loaded: users_helper
INFO - 2018-05-10 11:33:15 --> Database Driver Class Initialized
DEBUG - 2018-05-10 11:33:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 11:33:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 11:33:15 --> Helper loaded: form_helper
INFO - 2018-05-10 11:33:15 --> Form Validation Class Initialized
INFO - 2018-05-10 11:33:15 --> Controller Class Initialized
INFO - 2018-05-10 11:33:15 --> Model Class Initialized
INFO - 2018-05-10 11:33:15 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 11:33:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 11:33:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 11:33:15 --> Model Class Initialized
INFO - 2018-05-10 11:33:15 --> Model Class Initialized
INFO - 2018-05-10 11:33:15 --> Model Class Initialized
INFO - 2018-05-10 11:33:15 --> Model Class Initialized
INFO - 2018-05-10 11:33:15 --> Model Class Initialized
INFO - 2018-05-10 11:33:15 --> Model Class Initialized
INFO - 2018-05-10 11:33:15 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 11:33:15 --> Final output sent to browser
DEBUG - 2018-05-10 11:33:15 --> Total execution time: 0.1338
INFO - 2018-05-10 06:03:19 --> Config Class Initialized
INFO - 2018-05-10 06:03:19 --> Hooks Class Initialized
DEBUG - 2018-05-10 06:03:19 --> UTF-8 Support Enabled
INFO - 2018-05-10 06:03:19 --> Utf8 Class Initialized
INFO - 2018-05-10 06:03:19 --> URI Class Initialized
INFO - 2018-05-10 06:03:19 --> Router Class Initialized
INFO - 2018-05-10 06:03:19 --> Output Class Initialized
INFO - 2018-05-10 06:03:19 --> Security Class Initialized
DEBUG - 2018-05-10 06:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 06:03:19 --> Input Class Initialized
INFO - 2018-05-10 06:03:19 --> Language Class Initialized
INFO - 2018-05-10 06:03:19 --> Language Class Initialized
INFO - 2018-05-10 06:03:19 --> Config Class Initialized
INFO - 2018-05-10 06:03:19 --> Loader Class Initialized
INFO - 2018-05-10 11:33:19 --> Helper loaded: url_helper
INFO - 2018-05-10 11:33:19 --> Helper loaded: notification_helper
INFO - 2018-05-10 11:33:19 --> Helper loaded: settings_helper
INFO - 2018-05-10 11:33:19 --> Helper loaded: permission_helper
INFO - 2018-05-10 11:33:19 --> Helper loaded: users_helper
INFO - 2018-05-10 11:33:19 --> Database Driver Class Initialized
DEBUG - 2018-05-10 11:33:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 11:33:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 11:33:19 --> Helper loaded: form_helper
INFO - 2018-05-10 11:33:19 --> Form Validation Class Initialized
INFO - 2018-05-10 11:33:19 --> Controller Class Initialized
INFO - 2018-05-10 11:33:19 --> Model Class Initialized
INFO - 2018-05-10 11:33:19 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 11:33:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 11:33:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 11:33:19 --> Model Class Initialized
INFO - 2018-05-10 11:33:19 --> Model Class Initialized
INFO - 2018-05-10 11:33:19 --> Model Class Initialized
INFO - 2018-05-10 11:33:19 --> Model Class Initialized
INFO - 2018-05-10 11:33:19 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 11:33:19 --> Model Class Initialized
INFO - 2018-05-10 11:33:19 --> Final output sent to browser
DEBUG - 2018-05-10 11:33:19 --> Total execution time: 0.1375
INFO - 2018-05-10 06:08:41 --> Config Class Initialized
INFO - 2018-05-10 06:08:41 --> Hooks Class Initialized
DEBUG - 2018-05-10 06:08:41 --> UTF-8 Support Enabled
INFO - 2018-05-10 06:08:41 --> Utf8 Class Initialized
INFO - 2018-05-10 06:08:41 --> URI Class Initialized
INFO - 2018-05-10 06:08:41 --> Router Class Initialized
INFO - 2018-05-10 06:08:41 --> Output Class Initialized
INFO - 2018-05-10 06:08:41 --> Security Class Initialized
DEBUG - 2018-05-10 06:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 06:08:41 --> Input Class Initialized
INFO - 2018-05-10 06:08:41 --> Language Class Initialized
INFO - 2018-05-10 06:08:41 --> Language Class Initialized
INFO - 2018-05-10 06:08:41 --> Config Class Initialized
INFO - 2018-05-10 06:08:41 --> Loader Class Initialized
INFO - 2018-05-10 11:38:41 --> Helper loaded: url_helper
INFO - 2018-05-10 11:38:41 --> Helper loaded: notification_helper
INFO - 2018-05-10 11:38:41 --> Helper loaded: settings_helper
INFO - 2018-05-10 11:38:41 --> Helper loaded: permission_helper
INFO - 2018-05-10 11:38:41 --> Helper loaded: users_helper
INFO - 2018-05-10 11:38:41 --> Database Driver Class Initialized
DEBUG - 2018-05-10 11:38:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 11:38:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 11:38:41 --> Helper loaded: form_helper
INFO - 2018-05-10 11:38:41 --> Form Validation Class Initialized
INFO - 2018-05-10 11:38:41 --> Controller Class Initialized
INFO - 2018-05-10 11:38:41 --> Model Class Initialized
INFO - 2018-05-10 11:38:41 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 11:38:41 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 11:38:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 11:38:41 --> Model Class Initialized
INFO - 2018-05-10 11:38:41 --> Model Class Initialized
INFO - 2018-05-10 11:38:41 --> Model Class Initialized
INFO - 2018-05-10 11:38:41 --> Model Class Initialized
INFO - 2018-05-10 11:38:41 --> Model Class Initialized
INFO - 2018-05-10 11:38:41 --> Model Class Initialized
INFO - 2018-05-10 11:38:41 --> Model Class Initialized
INFO - 2018-05-10 11:38:41 --> Model Class Initialized
INFO - 2018-05-10 11:38:41 --> Model Class Initialized
INFO - 2018-05-10 11:38:41 --> Model Class Initialized
INFO - 2018-05-10 11:38:41 --> Model Class Initialized
INFO - 2018-05-10 11:38:41 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 11:38:41 --> Model Class Initialized
INFO - 2018-05-10 11:38:41 --> Final output sent to browser
DEBUG - 2018-05-10 11:38:41 --> Total execution time: 0.1544
INFO - 2018-05-10 06:08:43 --> Config Class Initialized
INFO - 2018-05-10 06:08:43 --> Hooks Class Initialized
DEBUG - 2018-05-10 06:08:43 --> UTF-8 Support Enabled
INFO - 2018-05-10 06:08:43 --> Utf8 Class Initialized
INFO - 2018-05-10 06:08:43 --> URI Class Initialized
INFO - 2018-05-10 06:08:43 --> Router Class Initialized
INFO - 2018-05-10 06:08:43 --> Output Class Initialized
INFO - 2018-05-10 06:08:43 --> Security Class Initialized
DEBUG - 2018-05-10 06:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 06:08:43 --> Input Class Initialized
INFO - 2018-05-10 06:08:43 --> Language Class Initialized
INFO - 2018-05-10 06:08:43 --> Language Class Initialized
INFO - 2018-05-10 06:08:43 --> Config Class Initialized
INFO - 2018-05-10 06:08:43 --> Loader Class Initialized
INFO - 2018-05-10 11:38:43 --> Helper loaded: url_helper
INFO - 2018-05-10 11:38:43 --> Helper loaded: notification_helper
INFO - 2018-05-10 11:38:43 --> Helper loaded: settings_helper
INFO - 2018-05-10 11:38:43 --> Helper loaded: permission_helper
INFO - 2018-05-10 11:38:43 --> Helper loaded: users_helper
INFO - 2018-05-10 11:38:43 --> Database Driver Class Initialized
DEBUG - 2018-05-10 11:38:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 11:38:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 11:38:43 --> Helper loaded: form_helper
INFO - 2018-05-10 11:38:43 --> Form Validation Class Initialized
INFO - 2018-05-10 11:38:43 --> Controller Class Initialized
INFO - 2018-05-10 11:38:43 --> Model Class Initialized
INFO - 2018-05-10 11:38:43 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 11:38:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 11:38:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 11:38:43 --> Model Class Initialized
INFO - 2018-05-10 11:38:43 --> Model Class Initialized
INFO - 2018-05-10 11:38:43 --> Model Class Initialized
INFO - 2018-05-10 11:38:43 --> Model Class Initialized
INFO - 2018-05-10 11:38:43 --> Model Class Initialized
INFO - 2018-05-10 11:38:43 --> Model Class Initialized
INFO - 2018-05-10 11:38:43 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 11:38:43 --> Model Class Initialized
INFO - 2018-05-10 11:38:43 --> Final output sent to browser
DEBUG - 2018-05-10 11:38:43 --> Total execution time: 0.1365
INFO - 2018-05-10 06:09:12 --> Config Class Initialized
INFO - 2018-05-10 06:09:12 --> Hooks Class Initialized
DEBUG - 2018-05-10 06:09:12 --> UTF-8 Support Enabled
INFO - 2018-05-10 06:09:12 --> Utf8 Class Initialized
INFO - 2018-05-10 06:09:12 --> URI Class Initialized
INFO - 2018-05-10 06:09:12 --> Config Class Initialized
INFO - 2018-05-10 06:09:12 --> Hooks Class Initialized
DEBUG - 2018-05-10 06:09:12 --> UTF-8 Support Enabled
INFO - 2018-05-10 06:09:12 --> Utf8 Class Initialized
DEBUG - 2018-05-10 06:09:12 --> No URI present. Default controller set.
INFO - 2018-05-10 06:09:12 --> Router Class Initialized
INFO - 2018-05-10 06:09:12 --> URI Class Initialized
INFO - 2018-05-10 06:09:12 --> Output Class Initialized
INFO - 2018-05-10 06:09:12 --> Security Class Initialized
INFO - 2018-05-10 06:09:12 --> Router Class Initialized
DEBUG - 2018-05-10 06:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 06:09:12 --> Input Class Initialized
INFO - 2018-05-10 06:09:12 --> Language Class Initialized
INFO - 2018-05-10 06:09:12 --> Output Class Initialized
INFO - 2018-05-10 06:09:12 --> Security Class Initialized
DEBUG - 2018-05-10 06:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 06:09:12 --> Input Class Initialized
INFO - 2018-05-10 06:09:12 --> Language Class Initialized
INFO - 2018-05-10 06:09:12 --> Language Class Initialized
INFO - 2018-05-10 06:09:12 --> Config Class Initialized
INFO - 2018-05-10 06:09:12 --> Loader Class Initialized
INFO - 2018-05-10 11:39:12 --> Helper loaded: url_helper
INFO - 2018-05-10 11:39:12 --> Helper loaded: notification_helper
INFO - 2018-05-10 11:39:12 --> Helper loaded: settings_helper
INFO - 2018-05-10 11:39:12 --> Helper loaded: permission_helper
INFO - 2018-05-10 11:39:12 --> Helper loaded: users_helper
INFO - 2018-05-10 06:09:12 --> Config Class Initialized
INFO - 2018-05-10 06:09:12 --> Hooks Class Initialized
DEBUG - 2018-05-10 06:09:12 --> UTF-8 Support Enabled
INFO - 2018-05-10 06:09:12 --> Utf8 Class Initialized
INFO - 2018-05-10 06:09:12 --> URI Class Initialized
INFO - 2018-05-10 06:09:12 --> Language Class Initialized
INFO - 2018-05-10 06:09:12 --> Config Class Initialized
INFO - 2018-05-10 06:09:12 --> Loader Class Initialized
INFO - 2018-05-10 11:39:12 --> Helper loaded: url_helper
INFO - 2018-05-10 06:09:12 --> Router Class Initialized
INFO - 2018-05-10 11:39:12 --> Helper loaded: notification_helper
INFO - 2018-05-10 11:39:12 --> Helper loaded: settings_helper
INFO - 2018-05-10 11:39:12 --> Helper loaded: permission_helper
INFO - 2018-05-10 11:39:12 --> Helper loaded: users_helper
INFO - 2018-05-10 06:09:12 --> Output Class Initialized
INFO - 2018-05-10 06:09:12 --> Security Class Initialized
INFO - 2018-05-10 11:39:12 --> Database Driver Class Initialized
DEBUG - 2018-05-10 06:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 06:09:12 --> Input Class Initialized
INFO - 2018-05-10 06:09:12 --> Language Class Initialized
DEBUG - 2018-05-10 11:39:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 11:39:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 11:39:12 --> Database Driver Class Initialized
INFO - 2018-05-10 11:39:12 --> Helper loaded: form_helper
INFO - 2018-05-10 11:39:12 --> Form Validation Class Initialized
INFO - 2018-05-10 11:39:12 --> Controller Class Initialized
DEBUG - 2018-05-10 11:39:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 11:39:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 06:09:12 --> Language Class Initialized
INFO - 2018-05-10 06:09:12 --> Config Class Initialized
INFO - 2018-05-10 06:09:12 --> Loader Class Initialized
INFO - 2018-05-10 11:39:12 --> Model Class Initialized
INFO - 2018-05-10 11:39:12 --> Helper loaded: inflector_helper
INFO - 2018-05-10 11:39:12 --> Helper loaded: url_helper
INFO - 2018-05-10 11:39:12 --> Helper loaded: notification_helper
INFO - 2018-05-10 11:39:12 --> Helper loaded: form_helper
INFO - 2018-05-10 11:39:12 --> Form Validation Class Initialized
INFO - 2018-05-10 11:39:12 --> Controller Class Initialized
INFO - 2018-05-10 11:39:12 --> Helper loaded: settings_helper
INFO - 2018-05-10 11:39:12 --> Model Class Initialized
INFO - 2018-05-10 11:39:12 --> Helper loaded: permission_helper
DEBUG - 2018-05-10 11:39:12 --> File loaded: /home/pr01004/public_html/application/views/login.php
INFO - 2018-05-10 11:39:12 --> Final output sent to browser
DEBUG - 2018-05-10 11:39:12 --> Total execution time: 0.0924
INFO - 2018-05-10 11:39:12 --> Helper loaded: users_helper
INFO - 2018-05-10 11:39:12 --> Model Class Initialized
INFO - 2018-05-10 11:39:12 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 11:39:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 11:39:12 --> Database Driver Class Initialized
INFO - 2018-05-10 11:39:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 11:39:12 --> Model Class Initialized
INFO - 2018-05-10 11:39:12 --> Model Class Initialized
INFO - 2018-05-10 11:39:12 --> Model Class Initialized
INFO - 2018-05-10 11:39:12 --> Model Class Initialized
INFO - 2018-05-10 11:39:12 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-05-10 11:39:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 11:39:12 --> Final output sent to browser
DEBUG - 2018-05-10 11:39:12 --> Total execution time: 0.1049
INFO - 2018-05-10 11:39:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 11:39:12 --> Helper loaded: form_helper
INFO - 2018-05-10 11:39:12 --> Form Validation Class Initialized
INFO - 2018-05-10 11:39:12 --> Controller Class Initialized
INFO - 2018-05-10 11:39:12 --> Model Class Initialized
INFO - 2018-05-10 11:39:12 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 11:39:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 11:39:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 11:39:12 --> Model Class Initialized
INFO - 2018-05-10 11:39:12 --> Model Class Initialized
INFO - 2018-05-10 11:39:12 --> Model Class Initialized
INFO - 2018-05-10 11:39:12 --> Model Class Initialized
INFO - 2018-05-10 11:39:12 --> Model Class Initialized
INFO - 2018-05-10 11:39:12 --> Model Class Initialized
INFO - 2018-05-10 11:39:12 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 11:39:12 --> Final output sent to browser
DEBUG - 2018-05-10 11:39:12 --> Total execution time: 0.1052
INFO - 2018-05-10 06:09:20 --> Config Class Initialized
INFO - 2018-05-10 06:09:20 --> Hooks Class Initialized
DEBUG - 2018-05-10 06:09:20 --> UTF-8 Support Enabled
INFO - 2018-05-10 06:09:20 --> Utf8 Class Initialized
INFO - 2018-05-10 06:09:20 --> URI Class Initialized
INFO - 2018-05-10 06:09:20 --> Router Class Initialized
INFO - 2018-05-10 06:09:20 --> Output Class Initialized
INFO - 2018-05-10 06:09:20 --> Security Class Initialized
DEBUG - 2018-05-10 06:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 06:09:20 --> Input Class Initialized
INFO - 2018-05-10 06:09:20 --> Language Class Initialized
INFO - 2018-05-10 06:09:20 --> Language Class Initialized
INFO - 2018-05-10 06:09:20 --> Config Class Initialized
INFO - 2018-05-10 06:09:20 --> Loader Class Initialized
INFO - 2018-05-10 11:39:20 --> Helper loaded: url_helper
INFO - 2018-05-10 11:39:20 --> Helper loaded: notification_helper
INFO - 2018-05-10 11:39:20 --> Helper loaded: settings_helper
INFO - 2018-05-10 11:39:20 --> Helper loaded: permission_helper
INFO - 2018-05-10 11:39:20 --> Helper loaded: users_helper
INFO - 2018-05-10 11:39:20 --> Database Driver Class Initialized
DEBUG - 2018-05-10 11:39:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 11:39:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 11:39:20 --> Helper loaded: form_helper
INFO - 2018-05-10 11:39:20 --> Form Validation Class Initialized
INFO - 2018-05-10 11:39:20 --> Controller Class Initialized
INFO - 2018-05-10 11:39:20 --> Model Class Initialized
INFO - 2018-05-10 11:39:20 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 11:39:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 11:39:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 11:39:21 --> Model Class Initialized
INFO - 2018-05-10 11:39:21 --> Model Class Initialized
INFO - 2018-05-10 11:39:21 --> Model Class Initialized
INFO - 2018-05-10 11:39:21 --> Model Class Initialized
INFO - 2018-05-10 11:39:21 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 11:39:21 --> Model Class Initialized
INFO - 2018-05-10 11:39:21 --> Final output sent to browser
DEBUG - 2018-05-10 11:39:21 --> Total execution time: 0.1761
INFO - 2018-05-10 06:12:08 --> Config Class Initialized
INFO - 2018-05-10 06:12:08 --> Hooks Class Initialized
DEBUG - 2018-05-10 06:12:08 --> UTF-8 Support Enabled
INFO - 2018-05-10 06:12:08 --> Utf8 Class Initialized
INFO - 2018-05-10 06:12:08 --> URI Class Initialized
INFO - 2018-05-10 06:12:08 --> Router Class Initialized
INFO - 2018-05-10 06:12:08 --> Output Class Initialized
INFO - 2018-05-10 06:12:08 --> Security Class Initialized
DEBUG - 2018-05-10 06:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 06:12:08 --> Input Class Initialized
INFO - 2018-05-10 06:12:08 --> Language Class Initialized
INFO - 2018-05-10 06:12:08 --> Language Class Initialized
INFO - 2018-05-10 06:12:08 --> Config Class Initialized
INFO - 2018-05-10 06:12:08 --> Loader Class Initialized
INFO - 2018-05-10 11:42:08 --> Helper loaded: url_helper
INFO - 2018-05-10 11:42:08 --> Helper loaded: notification_helper
INFO - 2018-05-10 11:42:08 --> Helper loaded: settings_helper
INFO - 2018-05-10 11:42:08 --> Helper loaded: permission_helper
INFO - 2018-05-10 11:42:08 --> Helper loaded: users_helper
INFO - 2018-05-10 11:42:08 --> Database Driver Class Initialized
DEBUG - 2018-05-10 11:42:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 11:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 11:42:08 --> Helper loaded: form_helper
INFO - 2018-05-10 11:42:08 --> Form Validation Class Initialized
INFO - 2018-05-10 11:42:08 --> Controller Class Initialized
INFO - 2018-05-10 11:42:08 --> Model Class Initialized
INFO - 2018-05-10 11:42:08 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 11:42:08 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 11:42:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 11:42:08 --> Model Class Initialized
INFO - 2018-05-10 11:42:08 --> Model Class Initialized
INFO - 2018-05-10 11:42:08 --> Model Class Initialized
INFO - 2018-05-10 11:42:08 --> Model Class Initialized
INFO - 2018-05-10 11:42:08 --> Model Class Initialized
INFO - 2018-05-10 11:42:08 --> Model Class Initialized
INFO - 2018-05-10 11:42:08 --> Model Class Initialized
INFO - 2018-05-10 11:42:08 --> Model Class Initialized
INFO - 2018-05-10 11:42:08 --> Model Class Initialized
INFO - 2018-05-10 11:42:08 --> Model Class Initialized
INFO - 2018-05-10 11:42:08 --> Model Class Initialized
INFO - 2018-05-10 11:42:08 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 11:42:08 --> Model Class Initialized
INFO - 2018-05-10 11:42:08 --> Final output sent to browser
DEBUG - 2018-05-10 11:42:08 --> Total execution time: 0.1172
INFO - 2018-05-10 06:12:08 --> Config Class Initialized
INFO - 2018-05-10 06:12:08 --> Hooks Class Initialized
DEBUG - 2018-05-10 06:12:08 --> UTF-8 Support Enabled
INFO - 2018-05-10 06:12:08 --> Utf8 Class Initialized
INFO - 2018-05-10 06:12:08 --> URI Class Initialized
INFO - 2018-05-10 06:12:08 --> Router Class Initialized
INFO - 2018-05-10 06:12:08 --> Output Class Initialized
INFO - 2018-05-10 06:12:08 --> Security Class Initialized
DEBUG - 2018-05-10 06:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 06:12:08 --> Input Class Initialized
INFO - 2018-05-10 06:12:08 --> Language Class Initialized
INFO - 2018-05-10 06:12:08 --> Language Class Initialized
INFO - 2018-05-10 06:12:08 --> Config Class Initialized
INFO - 2018-05-10 06:12:08 --> Loader Class Initialized
INFO - 2018-05-10 11:42:08 --> Helper loaded: url_helper
INFO - 2018-05-10 11:42:08 --> Helper loaded: notification_helper
INFO - 2018-05-10 11:42:08 --> Helper loaded: settings_helper
INFO - 2018-05-10 11:42:08 --> Helper loaded: permission_helper
INFO - 2018-05-10 11:42:08 --> Helper loaded: users_helper
INFO - 2018-05-10 11:42:08 --> Database Driver Class Initialized
DEBUG - 2018-05-10 11:42:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 11:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 11:42:08 --> Helper loaded: form_helper
INFO - 2018-05-10 11:42:08 --> Form Validation Class Initialized
INFO - 2018-05-10 11:42:08 --> Controller Class Initialized
INFO - 2018-05-10 11:42:08 --> Model Class Initialized
INFO - 2018-05-10 11:42:08 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 11:42:08 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 11:42:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 11:42:08 --> Model Class Initialized
INFO - 2018-05-10 11:42:08 --> Model Class Initialized
INFO - 2018-05-10 11:42:08 --> Model Class Initialized
INFO - 2018-05-10 11:42:08 --> Model Class Initialized
INFO - 2018-05-10 11:42:08 --> Model Class Initialized
INFO - 2018-05-10 11:42:08 --> Model Class Initialized
INFO - 2018-05-10 11:42:08 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 11:42:08 --> Model Class Initialized
INFO - 2018-05-10 11:42:08 --> Final output sent to browser
DEBUG - 2018-05-10 11:42:08 --> Total execution time: 0.1283
INFO - 2018-05-10 06:12:09 --> Config Class Initialized
INFO - 2018-05-10 06:12:09 --> Hooks Class Initialized
INFO - 2018-05-10 06:12:09 --> Config Class Initialized
DEBUG - 2018-05-10 06:12:09 --> UTF-8 Support Enabled
INFO - 2018-05-10 06:12:09 --> Hooks Class Initialized
INFO - 2018-05-10 06:12:09 --> Utf8 Class Initialized
INFO - 2018-05-10 06:12:10 --> URI Class Initialized
INFO - 2018-05-10 06:12:10 --> Router Class Initialized
DEBUG - 2018-05-10 06:12:10 --> UTF-8 Support Enabled
INFO - 2018-05-10 06:12:10 --> Utf8 Class Initialized
INFO - 2018-05-10 06:12:10 --> Output Class Initialized
INFO - 2018-05-10 06:12:10 --> URI Class Initialized
INFO - 2018-05-10 06:12:10 --> Security Class Initialized
INFO - 2018-05-10 06:12:10 --> Router Class Initialized
DEBUG - 2018-05-10 06:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 06:12:10 --> Input Class Initialized
INFO - 2018-05-10 06:12:10 --> Language Class Initialized
INFO - 2018-05-10 06:12:10 --> Output Class Initialized
INFO - 2018-05-10 06:12:10 --> Security Class Initialized
DEBUG - 2018-05-10 06:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 06:12:10 --> Input Class Initialized
INFO - 2018-05-10 06:12:10 --> Language Class Initialized
INFO - 2018-05-10 06:12:10 --> Language Class Initialized
INFO - 2018-05-10 06:12:10 --> Config Class Initialized
INFO - 2018-05-10 06:12:10 --> Loader Class Initialized
INFO - 2018-05-10 11:42:10 --> Helper loaded: url_helper
INFO - 2018-05-10 11:42:10 --> Helper loaded: notification_helper
INFO - 2018-05-10 11:42:10 --> Helper loaded: settings_helper
INFO - 2018-05-10 11:42:10 --> Helper loaded: permission_helper
INFO - 2018-05-10 11:42:10 --> Helper loaded: users_helper
INFO - 2018-05-10 06:12:10 --> Language Class Initialized
INFO - 2018-05-10 06:12:10 --> Config Class Initialized
INFO - 2018-05-10 06:12:10 --> Loader Class Initialized
INFO - 2018-05-10 11:42:10 --> Database Driver Class Initialized
INFO - 2018-05-10 11:42:10 --> Helper loaded: url_helper
INFO - 2018-05-10 11:42:10 --> Helper loaded: notification_helper
INFO - 2018-05-10 11:42:10 --> Helper loaded: settings_helper
INFO - 2018-05-10 11:42:10 --> Helper loaded: permission_helper
INFO - 2018-05-10 11:42:10 --> Helper loaded: users_helper
DEBUG - 2018-05-10 11:42:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 11:42:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 11:42:10 --> Helper loaded: form_helper
INFO - 2018-05-10 11:42:10 --> Form Validation Class Initialized
INFO - 2018-05-10 11:42:10 --> Controller Class Initialized
INFO - 2018-05-10 11:42:10 --> Database Driver Class Initialized
INFO - 2018-05-10 11:42:10 --> Model Class Initialized
INFO - 2018-05-10 11:42:10 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 11:42:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-05-10 11:42:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 11:42:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 11:42:10 --> Model Class Initialized
INFO - 2018-05-10 11:42:10 --> Model Class Initialized
INFO - 2018-05-10 11:42:10 --> Model Class Initialized
INFO - 2018-05-10 11:42:10 --> Model Class Initialized
INFO - 2018-05-10 11:42:10 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 11:42:10 --> Final output sent to browser
DEBUG - 2018-05-10 11:42:10 --> Total execution time: 0.0943
INFO - 2018-05-10 11:42:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 11:42:10 --> Helper loaded: form_helper
INFO - 2018-05-10 11:42:10 --> Form Validation Class Initialized
INFO - 2018-05-10 11:42:10 --> Controller Class Initialized
INFO - 2018-05-10 11:42:10 --> Model Class Initialized
INFO - 2018-05-10 11:42:10 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 11:42:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 11:42:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 11:42:10 --> Model Class Initialized
INFO - 2018-05-10 11:42:10 --> Model Class Initialized
INFO - 2018-05-10 11:42:10 --> Model Class Initialized
INFO - 2018-05-10 11:42:10 --> Model Class Initialized
INFO - 2018-05-10 11:42:10 --> Model Class Initialized
INFO - 2018-05-10 11:42:10 --> Model Class Initialized
INFO - 2018-05-10 11:42:10 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 11:42:10 --> Final output sent to browser
DEBUG - 2018-05-10 11:42:10 --> Total execution time: 0.1296
INFO - 2018-05-10 06:12:16 --> Config Class Initialized
INFO - 2018-05-10 06:12:16 --> Hooks Class Initialized
DEBUG - 2018-05-10 06:12:16 --> UTF-8 Support Enabled
INFO - 2018-05-10 06:12:16 --> Utf8 Class Initialized
INFO - 2018-05-10 06:12:16 --> URI Class Initialized
INFO - 2018-05-10 06:12:16 --> Router Class Initialized
INFO - 2018-05-10 06:12:16 --> Output Class Initialized
INFO - 2018-05-10 06:12:16 --> Security Class Initialized
DEBUG - 2018-05-10 06:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 06:12:16 --> Input Class Initialized
INFO - 2018-05-10 06:12:16 --> Language Class Initialized
INFO - 2018-05-10 06:12:16 --> Language Class Initialized
INFO - 2018-05-10 06:12:16 --> Config Class Initialized
INFO - 2018-05-10 06:12:16 --> Loader Class Initialized
INFO - 2018-05-10 11:42:16 --> Helper loaded: url_helper
INFO - 2018-05-10 11:42:16 --> Helper loaded: notification_helper
INFO - 2018-05-10 11:42:16 --> Helper loaded: settings_helper
INFO - 2018-05-10 11:42:16 --> Helper loaded: permission_helper
INFO - 2018-05-10 11:42:16 --> Helper loaded: users_helper
INFO - 2018-05-10 11:42:16 --> Database Driver Class Initialized
DEBUG - 2018-05-10 11:42:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 11:42:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 11:42:16 --> Helper loaded: form_helper
INFO - 2018-05-10 11:42:16 --> Form Validation Class Initialized
INFO - 2018-05-10 11:42:16 --> Controller Class Initialized
INFO - 2018-05-10 11:42:16 --> Model Class Initialized
INFO - 2018-05-10 11:42:16 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 11:42:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 11:42:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 11:42:16 --> Model Class Initialized
INFO - 2018-05-10 11:42:16 --> Model Class Initialized
INFO - 2018-05-10 11:42:16 --> Model Class Initialized
INFO - 2018-05-10 11:42:16 --> Model Class Initialized
INFO - 2018-05-10 11:42:16 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 11:42:16 --> Model Class Initialized
INFO - 2018-05-10 11:42:16 --> Final output sent to browser
DEBUG - 2018-05-10 11:42:16 --> Total execution time: 0.0975
INFO - 2018-05-10 06:14:51 --> Config Class Initialized
INFO - 2018-05-10 06:14:51 --> Hooks Class Initialized
DEBUG - 2018-05-10 06:14:51 --> UTF-8 Support Enabled
INFO - 2018-05-10 06:14:51 --> Utf8 Class Initialized
INFO - 2018-05-10 06:14:51 --> URI Class Initialized
INFO - 2018-05-10 06:14:51 --> Router Class Initialized
INFO - 2018-05-10 06:14:51 --> Output Class Initialized
INFO - 2018-05-10 06:14:51 --> Security Class Initialized
DEBUG - 2018-05-10 06:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 06:14:51 --> Input Class Initialized
INFO - 2018-05-10 06:14:51 --> Language Class Initialized
INFO - 2018-05-10 06:14:51 --> Language Class Initialized
INFO - 2018-05-10 06:14:51 --> Config Class Initialized
INFO - 2018-05-10 06:14:51 --> Loader Class Initialized
INFO - 2018-05-10 11:44:51 --> Helper loaded: url_helper
INFO - 2018-05-10 11:44:51 --> Helper loaded: notification_helper
INFO - 2018-05-10 11:44:51 --> Helper loaded: settings_helper
INFO - 2018-05-10 11:44:51 --> Helper loaded: permission_helper
INFO - 2018-05-10 11:44:51 --> Helper loaded: users_helper
INFO - 2018-05-10 11:44:51 --> Database Driver Class Initialized
DEBUG - 2018-05-10 11:44:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 11:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 11:44:51 --> Helper loaded: form_helper
INFO - 2018-05-10 11:44:51 --> Form Validation Class Initialized
INFO - 2018-05-10 11:44:51 --> Controller Class Initialized
INFO - 2018-05-10 11:44:51 --> Model Class Initialized
INFO - 2018-05-10 11:44:51 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 11:44:51 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 11:44:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 11:44:51 --> Model Class Initialized
INFO - 2018-05-10 11:44:51 --> Model Class Initialized
INFO - 2018-05-10 11:44:51 --> Model Class Initialized
INFO - 2018-05-10 11:44:51 --> Model Class Initialized
INFO - 2018-05-10 11:44:51 --> Model Class Initialized
INFO - 2018-05-10 11:44:51 --> Model Class Initialized
INFO - 2018-05-10 11:44:51 --> Model Class Initialized
INFO - 2018-05-10 11:44:51 --> Model Class Initialized
INFO - 2018-05-10 11:44:51 --> Model Class Initialized
INFO - 2018-05-10 11:44:51 --> Model Class Initialized
INFO - 2018-05-10 11:44:51 --> Model Class Initialized
INFO - 2018-05-10 11:44:51 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 11:44:51 --> Model Class Initialized
INFO - 2018-05-10 11:44:51 --> Final output sent to browser
DEBUG - 2018-05-10 11:44:51 --> Total execution time: 0.1333
INFO - 2018-05-10 06:14:51 --> Config Class Initialized
INFO - 2018-05-10 06:14:51 --> Hooks Class Initialized
DEBUG - 2018-05-10 06:14:51 --> UTF-8 Support Enabled
INFO - 2018-05-10 06:14:51 --> Utf8 Class Initialized
INFO - 2018-05-10 06:14:51 --> URI Class Initialized
INFO - 2018-05-10 06:14:51 --> Router Class Initialized
INFO - 2018-05-10 06:14:51 --> Output Class Initialized
INFO - 2018-05-10 06:14:51 --> Security Class Initialized
DEBUG - 2018-05-10 06:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 06:14:51 --> Input Class Initialized
INFO - 2018-05-10 06:14:51 --> Language Class Initialized
INFO - 2018-05-10 06:14:51 --> Language Class Initialized
INFO - 2018-05-10 06:14:51 --> Config Class Initialized
INFO - 2018-05-10 06:14:51 --> Loader Class Initialized
INFO - 2018-05-10 11:44:51 --> Helper loaded: url_helper
INFO - 2018-05-10 11:44:51 --> Helper loaded: notification_helper
INFO - 2018-05-10 11:44:51 --> Helper loaded: settings_helper
INFO - 2018-05-10 11:44:51 --> Helper loaded: permission_helper
INFO - 2018-05-10 11:44:51 --> Helper loaded: users_helper
INFO - 2018-05-10 11:44:51 --> Database Driver Class Initialized
DEBUG - 2018-05-10 11:44:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 11:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 11:44:51 --> Helper loaded: form_helper
INFO - 2018-05-10 11:44:51 --> Form Validation Class Initialized
INFO - 2018-05-10 11:44:51 --> Controller Class Initialized
INFO - 2018-05-10 11:44:51 --> Model Class Initialized
INFO - 2018-05-10 11:44:51 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 11:44:51 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 11:44:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 11:44:51 --> Model Class Initialized
INFO - 2018-05-10 11:44:51 --> Model Class Initialized
INFO - 2018-05-10 11:44:51 --> Model Class Initialized
INFO - 2018-05-10 11:44:51 --> Model Class Initialized
INFO - 2018-05-10 11:44:51 --> Model Class Initialized
INFO - 2018-05-10 11:44:51 --> Model Class Initialized
INFO - 2018-05-10 11:44:51 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 11:44:51 --> Model Class Initialized
INFO - 2018-05-10 11:44:51 --> Final output sent to browser
DEBUG - 2018-05-10 11:44:51 --> Total execution time: 0.1092
INFO - 2018-05-10 06:14:52 --> Config Class Initialized
INFO - 2018-05-10 06:14:52 --> Hooks Class Initialized
DEBUG - 2018-05-10 06:14:52 --> UTF-8 Support Enabled
INFO - 2018-05-10 06:14:52 --> Utf8 Class Initialized
INFO - 2018-05-10 06:14:52 --> URI Class Initialized
INFO - 2018-05-10 06:14:52 --> Router Class Initialized
INFO - 2018-05-10 06:14:52 --> Output Class Initialized
INFO - 2018-05-10 06:14:52 --> Config Class Initialized
INFO - 2018-05-10 06:14:52 --> Hooks Class Initialized
INFO - 2018-05-10 06:14:52 --> Security Class Initialized
DEBUG - 2018-05-10 06:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 06:14:52 --> Input Class Initialized
DEBUG - 2018-05-10 06:14:52 --> UTF-8 Support Enabled
INFO - 2018-05-10 06:14:52 --> Utf8 Class Initialized
INFO - 2018-05-10 06:14:52 --> URI Class Initialized
INFO - 2018-05-10 06:14:52 --> Language Class Initialized
INFO - 2018-05-10 06:14:52 --> Router Class Initialized
INFO - 2018-05-10 06:14:52 --> Output Class Initialized
INFO - 2018-05-10 06:14:52 --> Security Class Initialized
DEBUG - 2018-05-10 06:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 06:14:52 --> Input Class Initialized
INFO - 2018-05-10 06:14:52 --> Language Class Initialized
INFO - 2018-05-10 06:14:52 --> Language Class Initialized
INFO - 2018-05-10 06:14:52 --> Config Class Initialized
INFO - 2018-05-10 06:14:52 --> Loader Class Initialized
INFO - 2018-05-10 11:44:52 --> Helper loaded: url_helper
INFO - 2018-05-10 11:44:52 --> Helper loaded: notification_helper
INFO - 2018-05-10 11:44:52 --> Helper loaded: settings_helper
INFO - 2018-05-10 11:44:52 --> Helper loaded: permission_helper
INFO - 2018-05-10 11:44:52 --> Helper loaded: users_helper
INFO - 2018-05-10 06:14:52 --> Language Class Initialized
INFO - 2018-05-10 06:14:52 --> Config Class Initialized
INFO - 2018-05-10 06:14:52 --> Loader Class Initialized
INFO - 2018-05-10 11:44:52 --> Helper loaded: url_helper
INFO - 2018-05-10 11:44:52 --> Helper loaded: notification_helper
INFO - 2018-05-10 11:44:52 --> Helper loaded: settings_helper
INFO - 2018-05-10 11:44:52 --> Helper loaded: permission_helper
INFO - 2018-05-10 11:44:52 --> Helper loaded: users_helper
INFO - 2018-05-10 11:44:52 --> Database Driver Class Initialized
DEBUG - 2018-05-10 11:44:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 11:44:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 11:44:52 --> Database Driver Class Initialized
INFO - 2018-05-10 11:44:52 --> Helper loaded: form_helper
INFO - 2018-05-10 11:44:52 --> Form Validation Class Initialized
INFO - 2018-05-10 11:44:52 --> Controller Class Initialized
DEBUG - 2018-05-10 11:44:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 11:44:52 --> Model Class Initialized
INFO - 2018-05-10 11:44:52 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 11:44:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 11:44:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 11:44:52 --> Model Class Initialized
INFO - 2018-05-10 11:44:52 --> Model Class Initialized
INFO - 2018-05-10 11:44:52 --> Model Class Initialized
INFO - 2018-05-10 11:44:52 --> Model Class Initialized
INFO - 2018-05-10 11:44:52 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 11:44:52 --> Final output sent to browser
DEBUG - 2018-05-10 11:44:52 --> Total execution time: 0.1469
INFO - 2018-05-10 11:44:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 11:44:52 --> Helper loaded: form_helper
INFO - 2018-05-10 11:44:52 --> Form Validation Class Initialized
INFO - 2018-05-10 11:44:52 --> Controller Class Initialized
INFO - 2018-05-10 11:44:52 --> Model Class Initialized
INFO - 2018-05-10 11:44:52 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 11:44:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 11:44:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 11:44:53 --> Model Class Initialized
INFO - 2018-05-10 11:44:53 --> Model Class Initialized
INFO - 2018-05-10 11:44:53 --> Model Class Initialized
INFO - 2018-05-10 11:44:53 --> Model Class Initialized
INFO - 2018-05-10 11:44:53 --> Model Class Initialized
INFO - 2018-05-10 11:44:53 --> Model Class Initialized
INFO - 2018-05-10 11:44:53 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 11:44:53 --> Final output sent to browser
DEBUG - 2018-05-10 11:44:53 --> Total execution time: 0.1821
INFO - 2018-05-10 06:14:56 --> Config Class Initialized
INFO - 2018-05-10 06:14:56 --> Hooks Class Initialized
DEBUG - 2018-05-10 06:14:56 --> UTF-8 Support Enabled
INFO - 2018-05-10 06:14:56 --> Utf8 Class Initialized
INFO - 2018-05-10 06:14:56 --> URI Class Initialized
INFO - 2018-05-10 06:14:56 --> Router Class Initialized
INFO - 2018-05-10 06:14:56 --> Output Class Initialized
INFO - 2018-05-10 06:14:56 --> Security Class Initialized
DEBUG - 2018-05-10 06:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 06:14:56 --> Input Class Initialized
INFO - 2018-05-10 06:14:56 --> Language Class Initialized
INFO - 2018-05-10 06:14:56 --> Language Class Initialized
INFO - 2018-05-10 06:14:56 --> Config Class Initialized
INFO - 2018-05-10 06:14:56 --> Loader Class Initialized
INFO - 2018-05-10 11:44:56 --> Helper loaded: url_helper
INFO - 2018-05-10 11:44:56 --> Helper loaded: notification_helper
INFO - 2018-05-10 11:44:56 --> Helper loaded: settings_helper
INFO - 2018-05-10 11:44:56 --> Helper loaded: permission_helper
INFO - 2018-05-10 11:44:56 --> Helper loaded: users_helper
INFO - 2018-05-10 11:44:56 --> Database Driver Class Initialized
DEBUG - 2018-05-10 11:44:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 11:44:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 11:44:56 --> Helper loaded: form_helper
INFO - 2018-05-10 11:44:56 --> Form Validation Class Initialized
INFO - 2018-05-10 11:44:56 --> Controller Class Initialized
INFO - 2018-05-10 11:44:56 --> Model Class Initialized
INFO - 2018-05-10 11:44:56 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 11:44:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 11:44:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 11:44:56 --> Model Class Initialized
INFO - 2018-05-10 11:44:56 --> Model Class Initialized
INFO - 2018-05-10 11:44:56 --> Model Class Initialized
INFO - 2018-05-10 11:44:56 --> Model Class Initialized
INFO - 2018-05-10 11:44:56 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 11:44:56 --> Model Class Initialized
INFO - 2018-05-10 11:44:56 --> Final output sent to browser
DEBUG - 2018-05-10 11:44:56 --> Total execution time: 0.1076
INFO - 2018-05-10 06:24:02 --> Config Class Initialized
INFO - 2018-05-10 06:24:02 --> Hooks Class Initialized
DEBUG - 2018-05-10 06:24:02 --> UTF-8 Support Enabled
INFO - 2018-05-10 06:24:02 --> Utf8 Class Initialized
INFO - 2018-05-10 06:24:02 --> URI Class Initialized
INFO - 2018-05-10 06:24:02 --> Router Class Initialized
INFO - 2018-05-10 06:24:02 --> Output Class Initialized
INFO - 2018-05-10 06:24:02 --> Security Class Initialized
INFO - 2018-05-10 06:24:02 --> Config Class Initialized
INFO - 2018-05-10 06:24:02 --> Hooks Class Initialized
DEBUG - 2018-05-10 06:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 06:24:02 --> Input Class Initialized
INFO - 2018-05-10 06:24:02 --> Language Class Initialized
DEBUG - 2018-05-10 06:24:02 --> UTF-8 Support Enabled
INFO - 2018-05-10 06:24:02 --> Utf8 Class Initialized
INFO - 2018-05-10 06:24:02 --> URI Class Initialized
INFO - 2018-05-10 06:24:02 --> Router Class Initialized
INFO - 2018-05-10 06:24:02 --> Language Class Initialized
INFO - 2018-05-10 06:24:02 --> Config Class Initialized
INFO - 2018-05-10 06:24:02 --> Output Class Initialized
INFO - 2018-05-10 06:24:02 --> Loader Class Initialized
INFO - 2018-05-10 11:54:02 --> Helper loaded: url_helper
INFO - 2018-05-10 06:24:02 --> Security Class Initialized
INFO - 2018-05-10 11:54:02 --> Helper loaded: notification_helper
INFO - 2018-05-10 11:54:02 --> Helper loaded: settings_helper
INFO - 2018-05-10 11:54:02 --> Helper loaded: permission_helper
DEBUG - 2018-05-10 06:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 11:54:02 --> Helper loaded: users_helper
INFO - 2018-05-10 06:24:02 --> Input Class Initialized
INFO - 2018-05-10 06:24:02 --> Language Class Initialized
INFO - 2018-05-10 11:54:02 --> Database Driver Class Initialized
DEBUG - 2018-05-10 11:54:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 11:54:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 06:24:02 --> Language Class Initialized
INFO - 2018-05-10 06:24:02 --> Config Class Initialized
INFO - 2018-05-10 06:24:02 --> Loader Class Initialized
INFO - 2018-05-10 11:54:02 --> Helper loaded: form_helper
INFO - 2018-05-10 11:54:02 --> Form Validation Class Initialized
INFO - 2018-05-10 11:54:02 --> Controller Class Initialized
INFO - 2018-05-10 11:54:03 --> Helper loaded: url_helper
INFO - 2018-05-10 11:54:03 --> Helper loaded: notification_helper
INFO - 2018-05-10 11:54:03 --> Helper loaded: settings_helper
INFO - 2018-05-10 11:54:03 --> Helper loaded: permission_helper
INFO - 2018-05-10 11:54:03 --> Helper loaded: users_helper
INFO - 2018-05-10 11:54:03 --> Model Class Initialized
INFO - 2018-05-10 11:54:03 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 11:54:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 11:54:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 11:54:03 --> Model Class Initialized
INFO - 2018-05-10 11:54:03 --> Model Class Initialized
INFO - 2018-05-10 11:54:03 --> Model Class Initialized
INFO - 2018-05-10 11:54:03 --> Model Class Initialized
INFO - 2018-05-10 11:54:03 --> Model Class Initialized
INFO - 2018-05-10 11:54:03 --> Model Class Initialized
INFO - 2018-05-10 11:54:03 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 11:54:03 --> Model Class Initialized
INFO - 2018-05-10 11:54:03 --> Final output sent to browser
DEBUG - 2018-05-10 11:54:03 --> Total execution time: 0.1121
INFO - 2018-05-10 11:54:03 --> Database Driver Class Initialized
DEBUG - 2018-05-10 11:54:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 11:54:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 11:54:03 --> Helper loaded: form_helper
INFO - 2018-05-10 11:54:03 --> Form Validation Class Initialized
INFO - 2018-05-10 11:54:03 --> Controller Class Initialized
INFO - 2018-05-10 11:54:03 --> Model Class Initialized
INFO - 2018-05-10 11:54:03 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 11:54:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 11:54:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 11:54:03 --> Model Class Initialized
INFO - 2018-05-10 11:54:03 --> Model Class Initialized
INFO - 2018-05-10 11:54:03 --> Model Class Initialized
INFO - 2018-05-10 11:54:03 --> Model Class Initialized
INFO - 2018-05-10 11:54:03 --> Model Class Initialized
INFO - 2018-05-10 11:54:03 --> Model Class Initialized
INFO - 2018-05-10 11:54:03 --> Model Class Initialized
INFO - 2018-05-10 11:54:03 --> Model Class Initialized
INFO - 2018-05-10 11:54:03 --> Model Class Initialized
INFO - 2018-05-10 11:54:03 --> Model Class Initialized
INFO - 2018-05-10 11:54:03 --> Model Class Initialized
INFO - 2018-05-10 11:54:03 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 11:54:03 --> Model Class Initialized
INFO - 2018-05-10 11:54:03 --> Final output sent to browser
DEBUG - 2018-05-10 11:54:03 --> Total execution time: 0.1640
INFO - 2018-05-10 06:24:05 --> Config Class Initialized
INFO - 2018-05-10 06:24:05 --> Hooks Class Initialized
DEBUG - 2018-05-10 06:24:05 --> UTF-8 Support Enabled
INFO - 2018-05-10 06:24:05 --> Utf8 Class Initialized
INFO - 2018-05-10 06:24:05 --> URI Class Initialized
INFO - 2018-05-10 06:24:05 --> Router Class Initialized
INFO - 2018-05-10 06:24:05 --> Output Class Initialized
INFO - 2018-05-10 06:24:05 --> Security Class Initialized
DEBUG - 2018-05-10 06:24:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 06:24:05 --> Input Class Initialized
INFO - 2018-05-10 06:24:05 --> Language Class Initialized
INFO - 2018-05-10 06:24:05 --> Config Class Initialized
INFO - 2018-05-10 06:24:05 --> Hooks Class Initialized
DEBUG - 2018-05-10 06:24:05 --> UTF-8 Support Enabled
INFO - 2018-05-10 06:24:05 --> Utf8 Class Initialized
INFO - 2018-05-10 06:24:05 --> URI Class Initialized
INFO - 2018-05-10 06:24:05 --> Language Class Initialized
INFO - 2018-05-10 06:24:05 --> Config Class Initialized
INFO - 2018-05-10 06:24:05 --> Loader Class Initialized
INFO - 2018-05-10 06:24:05 --> Router Class Initialized
INFO - 2018-05-10 11:54:05 --> Helper loaded: url_helper
INFO - 2018-05-10 11:54:05 --> Helper loaded: notification_helper
INFO - 2018-05-10 11:54:05 --> Helper loaded: settings_helper
INFO - 2018-05-10 11:54:05 --> Helper loaded: permission_helper
INFO - 2018-05-10 11:54:05 --> Helper loaded: users_helper
INFO - 2018-05-10 06:24:05 --> Output Class Initialized
INFO - 2018-05-10 06:24:05 --> Security Class Initialized
DEBUG - 2018-05-10 06:24:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 06:24:05 --> Input Class Initialized
INFO - 2018-05-10 06:24:05 --> Language Class Initialized
INFO - 2018-05-10 11:54:05 --> Database Driver Class Initialized
DEBUG - 2018-05-10 11:54:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 11:54:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 11:54:05 --> Helper loaded: form_helper
INFO - 2018-05-10 11:54:05 --> Form Validation Class Initialized
INFO - 2018-05-10 11:54:05 --> Controller Class Initialized
INFO - 2018-05-10 11:54:05 --> Model Class Initialized
INFO - 2018-05-10 11:54:05 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 11:54:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 06:24:05 --> Language Class Initialized
INFO - 2018-05-10 06:24:05 --> Config Class Initialized
INFO - 2018-05-10 06:24:05 --> Loader Class Initialized
INFO - 2018-05-10 11:54:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 11:54:05 --> Model Class Initialized
INFO - 2018-05-10 11:54:05 --> Model Class Initialized
INFO - 2018-05-10 11:54:05 --> Model Class Initialized
INFO - 2018-05-10 11:54:05 --> Model Class Initialized
INFO - 2018-05-10 11:54:05 --> Model Class Initialized
INFO - 2018-05-10 11:54:05 --> Model Class Initialized
INFO - 2018-05-10 11:54:05 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 11:54:05 --> Helper loaded: url_helper
INFO - 2018-05-10 11:54:05 --> Helper loaded: notification_helper
INFO - 2018-05-10 11:54:05 --> Helper loaded: settings_helper
INFO - 2018-05-10 11:54:05 --> Final output sent to browser
DEBUG - 2018-05-10 11:54:05 --> Total execution time: 0.1021
INFO - 2018-05-10 11:54:05 --> Helper loaded: permission_helper
INFO - 2018-05-10 11:54:05 --> Helper loaded: users_helper
INFO - 2018-05-10 11:54:05 --> Database Driver Class Initialized
DEBUG - 2018-05-10 11:54:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 11:54:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 11:54:05 --> Helper loaded: form_helper
INFO - 2018-05-10 11:54:05 --> Form Validation Class Initialized
INFO - 2018-05-10 11:54:05 --> Controller Class Initialized
INFO - 2018-05-10 11:54:05 --> Model Class Initialized
INFO - 2018-05-10 11:54:05 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 11:54:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 11:54:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 11:54:05 --> Model Class Initialized
INFO - 2018-05-10 11:54:05 --> Model Class Initialized
INFO - 2018-05-10 11:54:05 --> Model Class Initialized
INFO - 2018-05-10 11:54:05 --> Model Class Initialized
INFO - 2018-05-10 11:54:05 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 11:54:05 --> Final output sent to browser
DEBUG - 2018-05-10 11:54:05 --> Total execution time: 0.1413
INFO - 2018-05-10 06:24:08 --> Config Class Initialized
INFO - 2018-05-10 06:24:08 --> Hooks Class Initialized
DEBUG - 2018-05-10 06:24:08 --> UTF-8 Support Enabled
INFO - 2018-05-10 06:24:08 --> Utf8 Class Initialized
INFO - 2018-05-10 06:24:08 --> URI Class Initialized
INFO - 2018-05-10 06:24:08 --> Router Class Initialized
INFO - 2018-05-10 06:24:08 --> Output Class Initialized
INFO - 2018-05-10 06:24:08 --> Security Class Initialized
DEBUG - 2018-05-10 06:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 06:24:08 --> Input Class Initialized
INFO - 2018-05-10 06:24:08 --> Language Class Initialized
INFO - 2018-05-10 06:24:08 --> Language Class Initialized
INFO - 2018-05-10 06:24:08 --> Config Class Initialized
INFO - 2018-05-10 06:24:08 --> Loader Class Initialized
INFO - 2018-05-10 11:54:08 --> Helper loaded: url_helper
INFO - 2018-05-10 11:54:08 --> Helper loaded: notification_helper
INFO - 2018-05-10 11:54:08 --> Helper loaded: settings_helper
INFO - 2018-05-10 11:54:08 --> Helper loaded: permission_helper
INFO - 2018-05-10 11:54:08 --> Helper loaded: users_helper
INFO - 2018-05-10 11:54:08 --> Database Driver Class Initialized
DEBUG - 2018-05-10 11:54:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 11:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 11:54:08 --> Helper loaded: form_helper
INFO - 2018-05-10 11:54:08 --> Form Validation Class Initialized
INFO - 2018-05-10 11:54:08 --> Controller Class Initialized
INFO - 2018-05-10 11:54:08 --> Model Class Initialized
INFO - 2018-05-10 11:54:08 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 11:54:08 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 11:54:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 11:54:08 --> Model Class Initialized
INFO - 2018-05-10 11:54:08 --> Model Class Initialized
INFO - 2018-05-10 11:54:08 --> Model Class Initialized
INFO - 2018-05-10 11:54:08 --> Model Class Initialized
INFO - 2018-05-10 11:54:08 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 11:54:08 --> Model Class Initialized
INFO - 2018-05-10 11:54:08 --> Final output sent to browser
DEBUG - 2018-05-10 11:54:08 --> Total execution time: 0.1183
INFO - 2018-05-10 06:32:38 --> Config Class Initialized
INFO - 2018-05-10 06:32:38 --> Hooks Class Initialized
DEBUG - 2018-05-10 06:32:38 --> UTF-8 Support Enabled
INFO - 2018-05-10 06:32:38 --> Utf8 Class Initialized
INFO - 2018-05-10 06:32:38 --> URI Class Initialized
INFO - 2018-05-10 06:32:38 --> Router Class Initialized
INFO - 2018-05-10 06:32:38 --> Output Class Initialized
INFO - 2018-05-10 06:32:38 --> Security Class Initialized
DEBUG - 2018-05-10 06:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 06:32:38 --> Input Class Initialized
INFO - 2018-05-10 06:32:38 --> Language Class Initialized
INFO - 2018-05-10 06:32:38 --> Config Class Initialized
INFO - 2018-05-10 06:32:38 --> Hooks Class Initialized
DEBUG - 2018-05-10 06:32:38 --> UTF-8 Support Enabled
INFO - 2018-05-10 06:32:38 --> Utf8 Class Initialized
INFO - 2018-05-10 06:32:38 --> URI Class Initialized
INFO - 2018-05-10 06:32:38 --> Router Class Initialized
INFO - 2018-05-10 06:32:38 --> Language Class Initialized
INFO - 2018-05-10 06:32:38 --> Config Class Initialized
INFO - 2018-05-10 06:32:38 --> Loader Class Initialized
INFO - 2018-05-10 06:32:38 --> Output Class Initialized
INFO - 2018-05-10 12:02:38 --> Helper loaded: url_helper
INFO - 2018-05-10 12:02:38 --> Helper loaded: notification_helper
INFO - 2018-05-10 06:32:38 --> Security Class Initialized
INFO - 2018-05-10 12:02:38 --> Helper loaded: settings_helper
INFO - 2018-05-10 12:02:39 --> Helper loaded: permission_helper
INFO - 2018-05-10 12:02:39 --> Helper loaded: users_helper
DEBUG - 2018-05-10 06:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 06:32:39 --> Input Class Initialized
INFO - 2018-05-10 06:32:39 --> Language Class Initialized
INFO - 2018-05-10 12:02:39 --> Database Driver Class Initialized
INFO - 2018-05-10 06:32:39 --> Language Class Initialized
INFO - 2018-05-10 06:32:39 --> Config Class Initialized
INFO - 2018-05-10 06:32:39 --> Loader Class Initialized
INFO - 2018-05-10 12:02:39 --> Helper loaded: url_helper
INFO - 2018-05-10 12:02:39 --> Helper loaded: notification_helper
INFO - 2018-05-10 12:02:39 --> Helper loaded: settings_helper
DEBUG - 2018-05-10 12:02:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 12:02:39 --> Helper loaded: permission_helper
INFO - 2018-05-10 12:02:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 12:02:39 --> Helper loaded: users_helper
INFO - 2018-05-10 12:02:39 --> Helper loaded: form_helper
INFO - 2018-05-10 12:02:39 --> Form Validation Class Initialized
INFO - 2018-05-10 12:02:39 --> Controller Class Initialized
INFO - 2018-05-10 12:02:39 --> Database Driver Class Initialized
INFO - 2018-05-10 12:02:39 --> Model Class Initialized
INFO - 2018-05-10 12:02:39 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 12:02:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 12:02:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-05-10 12:02:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 12:02:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 12:02:39 --> Model Class Initialized
INFO - 2018-05-10 12:02:39 --> Model Class Initialized
INFO - 2018-05-10 12:02:39 --> Model Class Initialized
INFO - 2018-05-10 12:02:39 --> Model Class Initialized
INFO - 2018-05-10 12:02:39 --> Model Class Initialized
INFO - 2018-05-10 12:02:39 --> Model Class Initialized
INFO - 2018-05-10 12:02:39 --> Model Class Initialized
INFO - 2018-05-10 12:02:39 --> Helper loaded: form_helper
INFO - 2018-05-10 12:02:39 --> Form Validation Class Initialized
INFO - 2018-05-10 12:02:39 --> Controller Class Initialized
INFO - 2018-05-10 12:02:39 --> Model Class Initialized
INFO - 2018-05-10 12:02:39 --> Model Class Initialized
INFO - 2018-05-10 12:02:39 --> Model Class Initialized
INFO - 2018-05-10 12:02:39 --> Model Class Initialized
INFO - 2018-05-10 12:02:39 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 12:02:39 --> Model Class Initialized
INFO - 2018-05-10 12:02:39 --> Model Class Initialized
INFO - 2018-05-10 12:02:39 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 12:02:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 12:02:39 --> Final output sent to browser
DEBUG - 2018-05-10 12:02:39 --> Total execution time: 0.1539
INFO - 2018-05-10 12:02:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 12:02:39 --> Model Class Initialized
INFO - 2018-05-10 12:02:39 --> Model Class Initialized
INFO - 2018-05-10 12:02:39 --> Model Class Initialized
INFO - 2018-05-10 12:02:39 --> Model Class Initialized
INFO - 2018-05-10 12:02:39 --> Model Class Initialized
INFO - 2018-05-10 12:02:39 --> Model Class Initialized
INFO - 2018-05-10 12:02:39 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 12:02:39 --> Model Class Initialized
INFO - 2018-05-10 12:02:39 --> Final output sent to browser
DEBUG - 2018-05-10 12:02:39 --> Total execution time: 0.1193
INFO - 2018-05-10 06:32:42 --> Config Class Initialized
INFO - 2018-05-10 06:32:42 --> Hooks Class Initialized
DEBUG - 2018-05-10 06:32:42 --> UTF-8 Support Enabled
INFO - 2018-05-10 06:32:42 --> Utf8 Class Initialized
INFO - 2018-05-10 06:32:42 --> URI Class Initialized
INFO - 2018-05-10 06:32:42 --> Router Class Initialized
INFO - 2018-05-10 06:32:42 --> Output Class Initialized
INFO - 2018-05-10 06:32:42 --> Security Class Initialized
INFO - 2018-05-10 06:32:42 --> Config Class Initialized
INFO - 2018-05-10 06:32:42 --> Hooks Class Initialized
DEBUG - 2018-05-10 06:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 06:32:42 --> Input Class Initialized
INFO - 2018-05-10 06:32:42 --> Language Class Initialized
DEBUG - 2018-05-10 06:32:42 --> UTF-8 Support Enabled
INFO - 2018-05-10 06:32:42 --> Utf8 Class Initialized
INFO - 2018-05-10 06:32:42 --> URI Class Initialized
INFO - 2018-05-10 06:32:42 --> Router Class Initialized
INFO - 2018-05-10 06:32:42 --> Output Class Initialized
INFO - 2018-05-10 06:32:42 --> Security Class Initialized
INFO - 2018-05-10 06:32:42 --> Language Class Initialized
INFO - 2018-05-10 06:32:42 --> Config Class Initialized
INFO - 2018-05-10 06:32:42 --> Loader Class Initialized
INFO - 2018-05-10 12:02:42 --> Helper loaded: url_helper
DEBUG - 2018-05-10 06:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 06:32:42 --> Input Class Initialized
INFO - 2018-05-10 12:02:42 --> Helper loaded: notification_helper
INFO - 2018-05-10 12:02:42 --> Helper loaded: settings_helper
INFO - 2018-05-10 12:02:42 --> Helper loaded: permission_helper
INFO - 2018-05-10 06:32:42 --> Language Class Initialized
INFO - 2018-05-10 12:02:42 --> Helper loaded: users_helper
INFO - 2018-05-10 12:02:42 --> Database Driver Class Initialized
INFO - 2018-05-10 06:32:42 --> Language Class Initialized
INFO - 2018-05-10 06:32:42 --> Config Class Initialized
INFO - 2018-05-10 06:32:42 --> Loader Class Initialized
DEBUG - 2018-05-10 12:02:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 12:02:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 12:02:42 --> Helper loaded: url_helper
INFO - 2018-05-10 12:02:42 --> Helper loaded: notification_helper
INFO - 2018-05-10 12:02:42 --> Helper loaded: settings_helper
INFO - 2018-05-10 12:02:42 --> Helper loaded: permission_helper
INFO - 2018-05-10 12:02:42 --> Helper loaded: users_helper
INFO - 2018-05-10 12:02:42 --> Helper loaded: form_helper
INFO - 2018-05-10 12:02:42 --> Form Validation Class Initialized
INFO - 2018-05-10 12:02:42 --> Controller Class Initialized
INFO - 2018-05-10 12:02:42 --> Database Driver Class Initialized
INFO - 2018-05-10 12:02:42 --> Model Class Initialized
INFO - 2018-05-10 12:02:42 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 12:02:42 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-05-10 12:02:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 12:02:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 12:02:42 --> Model Class Initialized
INFO - 2018-05-10 12:02:42 --> Model Class Initialized
INFO - 2018-05-10 12:02:42 --> Model Class Initialized
INFO - 2018-05-10 12:02:42 --> Model Class Initialized
INFO - 2018-05-10 12:02:42 --> Model Class Initialized
INFO - 2018-05-10 12:02:42 --> Model Class Initialized
INFO - 2018-05-10 12:02:42 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 12:02:42 --> Final output sent to browser
DEBUG - 2018-05-10 12:02:42 --> Total execution time: 0.1339
INFO - 2018-05-10 12:02:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 12:02:42 --> Helper loaded: form_helper
INFO - 2018-05-10 12:02:42 --> Form Validation Class Initialized
INFO - 2018-05-10 12:02:42 --> Controller Class Initialized
INFO - 2018-05-10 12:02:42 --> Model Class Initialized
INFO - 2018-05-10 12:02:42 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 12:02:42 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 12:02:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 12:02:42 --> Model Class Initialized
INFO - 2018-05-10 12:02:42 --> Model Class Initialized
INFO - 2018-05-10 12:02:42 --> Model Class Initialized
INFO - 2018-05-10 12:02:42 --> Model Class Initialized
INFO - 2018-05-10 12:02:42 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 12:02:42 --> Final output sent to browser
DEBUG - 2018-05-10 12:02:42 --> Total execution time: 0.1622
INFO - 2018-05-10 06:32:47 --> Config Class Initialized
INFO - 2018-05-10 06:32:47 --> Hooks Class Initialized
DEBUG - 2018-05-10 06:32:47 --> UTF-8 Support Enabled
INFO - 2018-05-10 06:32:47 --> Utf8 Class Initialized
INFO - 2018-05-10 06:32:47 --> URI Class Initialized
INFO - 2018-05-10 06:32:47 --> Router Class Initialized
INFO - 2018-05-10 06:32:47 --> Output Class Initialized
INFO - 2018-05-10 06:32:47 --> Security Class Initialized
DEBUG - 2018-05-10 06:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 06:32:47 --> Input Class Initialized
INFO - 2018-05-10 06:32:47 --> Language Class Initialized
INFO - 2018-05-10 06:32:47 --> Language Class Initialized
INFO - 2018-05-10 06:32:47 --> Config Class Initialized
INFO - 2018-05-10 06:32:47 --> Loader Class Initialized
INFO - 2018-05-10 12:02:47 --> Helper loaded: url_helper
INFO - 2018-05-10 12:02:47 --> Helper loaded: notification_helper
INFO - 2018-05-10 12:02:47 --> Helper loaded: settings_helper
INFO - 2018-05-10 12:02:47 --> Helper loaded: permission_helper
INFO - 2018-05-10 12:02:47 --> Helper loaded: users_helper
INFO - 2018-05-10 12:02:47 --> Database Driver Class Initialized
DEBUG - 2018-05-10 12:02:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 12:02:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 12:02:47 --> Helper loaded: form_helper
INFO - 2018-05-10 12:02:47 --> Form Validation Class Initialized
INFO - 2018-05-10 12:02:47 --> Controller Class Initialized
INFO - 2018-05-10 12:02:47 --> Model Class Initialized
INFO - 2018-05-10 12:02:47 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 12:02:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 12:02:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 12:02:47 --> Model Class Initialized
INFO - 2018-05-10 12:02:47 --> Model Class Initialized
INFO - 2018-05-10 12:02:47 --> Model Class Initialized
INFO - 2018-05-10 12:02:47 --> Model Class Initialized
INFO - 2018-05-10 12:02:47 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 12:02:47 --> Model Class Initialized
INFO - 2018-05-10 12:02:47 --> Final output sent to browser
DEBUG - 2018-05-10 12:02:47 --> Total execution time: 0.1462
INFO - 2018-05-10 06:38:33 --> Config Class Initialized
INFO - 2018-05-10 06:38:33 --> Hooks Class Initialized
INFO - 2018-05-10 06:38:33 --> Config Class Initialized
INFO - 2018-05-10 06:38:33 --> Hooks Class Initialized
DEBUG - 2018-05-10 06:38:33 --> UTF-8 Support Enabled
INFO - 2018-05-10 06:38:33 --> Utf8 Class Initialized
DEBUG - 2018-05-10 06:38:33 --> UTF-8 Support Enabled
INFO - 2018-05-10 06:38:33 --> Utf8 Class Initialized
INFO - 2018-05-10 06:38:33 --> URI Class Initialized
INFO - 2018-05-10 06:38:33 --> URI Class Initialized
INFO - 2018-05-10 06:38:33 --> Router Class Initialized
INFO - 2018-05-10 06:38:33 --> Router Class Initialized
INFO - 2018-05-10 06:38:33 --> Output Class Initialized
INFO - 2018-05-10 06:38:33 --> Output Class Initialized
INFO - 2018-05-10 06:38:33 --> Security Class Initialized
INFO - 2018-05-10 06:38:33 --> Security Class Initialized
DEBUG - 2018-05-10 06:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 06:38:33 --> Input Class Initialized
DEBUG - 2018-05-10 06:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 06:38:33 --> Input Class Initialized
INFO - 2018-05-10 06:38:33 --> Language Class Initialized
INFO - 2018-05-10 06:38:33 --> Language Class Initialized
INFO - 2018-05-10 06:38:33 --> Language Class Initialized
INFO - 2018-05-10 06:38:33 --> Config Class Initialized
INFO - 2018-05-10 06:38:33 --> Loader Class Initialized
INFO - 2018-05-10 12:08:33 --> Helper loaded: url_helper
INFO - 2018-05-10 06:38:33 --> Language Class Initialized
INFO - 2018-05-10 06:38:33 --> Config Class Initialized
INFO - 2018-05-10 06:38:33 --> Loader Class Initialized
INFO - 2018-05-10 12:08:33 --> Helper loaded: notification_helper
INFO - 2018-05-10 12:08:33 --> Helper loaded: settings_helper
INFO - 2018-05-10 12:08:33 --> Helper loaded: permission_helper
INFO - 2018-05-10 12:08:33 --> Helper loaded: url_helper
INFO - 2018-05-10 12:08:33 --> Helper loaded: users_helper
INFO - 2018-05-10 12:08:33 --> Helper loaded: notification_helper
INFO - 2018-05-10 12:08:33 --> Helper loaded: settings_helper
INFO - 2018-05-10 12:08:33 --> Helper loaded: permission_helper
INFO - 2018-05-10 12:08:33 --> Helper loaded: users_helper
INFO - 2018-05-10 12:08:33 --> Database Driver Class Initialized
INFO - 2018-05-10 12:08:33 --> Database Driver Class Initialized
DEBUG - 2018-05-10 12:08:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 12:08:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-05-10 12:08:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 12:08:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 12:08:33 --> Helper loaded: form_helper
INFO - 2018-05-10 12:08:33 --> Form Validation Class Initialized
INFO - 2018-05-10 12:08:33 --> Controller Class Initialized
INFO - 2018-05-10 12:08:33 --> Model Class Initialized
INFO - 2018-05-10 12:08:33 --> Helper loaded: inflector_helper
INFO - 2018-05-10 12:08:33 --> Helper loaded: form_helper
INFO - 2018-05-10 12:08:33 --> Form Validation Class Initialized
INFO - 2018-05-10 12:08:33 --> Controller Class Initialized
DEBUG - 2018-05-10 12:08:33 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 12:08:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 12:08:33 --> Model Class Initialized
INFO - 2018-05-10 12:08:33 --> Model Class Initialized
INFO - 2018-05-10 12:08:33 --> Model Class Initialized
INFO - 2018-05-10 12:08:33 --> Model Class Initialized
INFO - 2018-05-10 12:08:33 --> Model Class Initialized
INFO - 2018-05-10 12:08:33 --> Model Class Initialized
INFO - 2018-05-10 12:08:33 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 12:08:33 --> Model Class Initialized
INFO - 2018-05-10 12:08:33 --> Final output sent to browser
DEBUG - 2018-05-10 12:08:33 --> Total execution time: 0.1806
INFO - 2018-05-10 12:08:33 --> Model Class Initialized
INFO - 2018-05-10 12:08:33 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 12:08:33 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 12:08:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 12:08:33 --> Model Class Initialized
INFO - 2018-05-10 12:08:33 --> Model Class Initialized
INFO - 2018-05-10 12:08:33 --> Model Class Initialized
INFO - 2018-05-10 12:08:33 --> Model Class Initialized
INFO - 2018-05-10 12:08:33 --> Model Class Initialized
INFO - 2018-05-10 12:08:33 --> Model Class Initialized
INFO - 2018-05-10 12:08:33 --> Model Class Initialized
INFO - 2018-05-10 12:08:33 --> Model Class Initialized
INFO - 2018-05-10 12:08:33 --> Model Class Initialized
INFO - 2018-05-10 12:08:33 --> Model Class Initialized
INFO - 2018-05-10 12:08:33 --> Model Class Initialized
INFO - 2018-05-10 12:08:33 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 12:08:33 --> Model Class Initialized
INFO - 2018-05-10 12:08:33 --> Final output sent to browser
DEBUG - 2018-05-10 12:08:33 --> Total execution time: 0.2111
INFO - 2018-05-10 06:39:08 --> Config Class Initialized
INFO - 2018-05-10 06:39:08 --> Hooks Class Initialized
DEBUG - 2018-05-10 06:39:08 --> UTF-8 Support Enabled
INFO - 2018-05-10 06:39:08 --> Utf8 Class Initialized
INFO - 2018-05-10 06:39:08 --> URI Class Initialized
INFO - 2018-05-10 06:39:08 --> Router Class Initialized
INFO - 2018-05-10 06:39:08 --> Config Class Initialized
INFO - 2018-05-10 06:39:08 --> Hooks Class Initialized
INFO - 2018-05-10 06:39:08 --> Output Class Initialized
INFO - 2018-05-10 06:39:08 --> Security Class Initialized
DEBUG - 2018-05-10 06:39:08 --> UTF-8 Support Enabled
INFO - 2018-05-10 06:39:08 --> Utf8 Class Initialized
INFO - 2018-05-10 06:39:08 --> URI Class Initialized
DEBUG - 2018-05-10 06:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 06:39:08 --> Input Class Initialized
INFO - 2018-05-10 06:39:08 --> Language Class Initialized
INFO - 2018-05-10 06:39:08 --> Router Class Initialized
INFO - 2018-05-10 06:39:09 --> Output Class Initialized
INFO - 2018-05-10 06:39:09 --> Security Class Initialized
DEBUG - 2018-05-10 06:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 06:39:09 --> Input Class Initialized
INFO - 2018-05-10 06:39:09 --> Language Class Initialized
INFO - 2018-05-10 06:39:09 --> Language Class Initialized
INFO - 2018-05-10 06:39:09 --> Config Class Initialized
INFO - 2018-05-10 06:39:09 --> Loader Class Initialized
INFO - 2018-05-10 12:09:09 --> Helper loaded: url_helper
INFO - 2018-05-10 12:09:09 --> Helper loaded: notification_helper
INFO - 2018-05-10 12:09:09 --> Helper loaded: settings_helper
INFO - 2018-05-10 12:09:09 --> Helper loaded: permission_helper
INFO - 2018-05-10 12:09:09 --> Helper loaded: users_helper
INFO - 2018-05-10 12:09:09 --> Database Driver Class Initialized
INFO - 2018-05-10 06:39:09 --> Language Class Initialized
INFO - 2018-05-10 06:39:09 --> Config Class Initialized
INFO - 2018-05-10 06:39:09 --> Loader Class Initialized
INFO - 2018-05-10 12:09:09 --> Helper loaded: url_helper
INFO - 2018-05-10 12:09:09 --> Helper loaded: notification_helper
INFO - 2018-05-10 12:09:09 --> Helper loaded: settings_helper
INFO - 2018-05-10 12:09:09 --> Helper loaded: permission_helper
INFO - 2018-05-10 12:09:09 --> Helper loaded: users_helper
DEBUG - 2018-05-10 12:09:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 12:09:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 12:09:09 --> Database Driver Class Initialized
DEBUG - 2018-05-10 12:09:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 12:09:09 --> Helper loaded: form_helper
INFO - 2018-05-10 12:09:09 --> Form Validation Class Initialized
INFO - 2018-05-10 12:09:09 --> Controller Class Initialized
INFO - 2018-05-10 12:09:09 --> Model Class Initialized
INFO - 2018-05-10 12:09:09 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 12:09:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 12:09:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 12:09:09 --> Model Class Initialized
INFO - 2018-05-10 12:09:09 --> Model Class Initialized
INFO - 2018-05-10 12:09:09 --> Model Class Initialized
INFO - 2018-05-10 12:09:09 --> Model Class Initialized
INFO - 2018-05-10 12:09:09 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 12:09:09 --> Final output sent to browser
DEBUG - 2018-05-10 12:09:09 --> Total execution time: 0.1718
INFO - 2018-05-10 12:09:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 12:09:09 --> Helper loaded: form_helper
INFO - 2018-05-10 12:09:09 --> Form Validation Class Initialized
INFO - 2018-05-10 12:09:09 --> Controller Class Initialized
INFO - 2018-05-10 12:09:09 --> Model Class Initialized
INFO - 2018-05-10 12:09:09 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 12:09:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 12:09:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 12:09:09 --> Model Class Initialized
INFO - 2018-05-10 12:09:09 --> Model Class Initialized
INFO - 2018-05-10 12:09:09 --> Model Class Initialized
INFO - 2018-05-10 12:09:09 --> Model Class Initialized
INFO - 2018-05-10 12:09:09 --> Model Class Initialized
INFO - 2018-05-10 12:09:09 --> Model Class Initialized
INFO - 2018-05-10 12:09:09 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 12:09:09 --> Final output sent to browser
DEBUG - 2018-05-10 12:09:09 --> Total execution time: 0.2086
INFO - 2018-05-10 06:39:12 --> Config Class Initialized
INFO - 2018-05-10 06:39:12 --> Hooks Class Initialized
DEBUG - 2018-05-10 06:39:12 --> UTF-8 Support Enabled
INFO - 2018-05-10 06:39:12 --> Utf8 Class Initialized
INFO - 2018-05-10 06:39:12 --> URI Class Initialized
INFO - 2018-05-10 06:39:12 --> Router Class Initialized
INFO - 2018-05-10 06:39:12 --> Output Class Initialized
INFO - 2018-05-10 06:39:12 --> Security Class Initialized
DEBUG - 2018-05-10 06:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 06:39:12 --> Input Class Initialized
INFO - 2018-05-10 06:39:12 --> Language Class Initialized
INFO - 2018-05-10 06:39:12 --> Language Class Initialized
INFO - 2018-05-10 06:39:12 --> Config Class Initialized
INFO - 2018-05-10 06:39:12 --> Loader Class Initialized
INFO - 2018-05-10 12:09:12 --> Helper loaded: url_helper
INFO - 2018-05-10 12:09:12 --> Helper loaded: notification_helper
INFO - 2018-05-10 12:09:12 --> Helper loaded: settings_helper
INFO - 2018-05-10 12:09:12 --> Helper loaded: permission_helper
INFO - 2018-05-10 12:09:12 --> Helper loaded: users_helper
INFO - 2018-05-10 12:09:12 --> Database Driver Class Initialized
DEBUG - 2018-05-10 12:09:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 12:09:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 12:09:12 --> Helper loaded: form_helper
INFO - 2018-05-10 12:09:12 --> Form Validation Class Initialized
INFO - 2018-05-10 12:09:12 --> Controller Class Initialized
INFO - 2018-05-10 12:09:12 --> Model Class Initialized
INFO - 2018-05-10 12:09:12 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 12:09:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 12:09:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 12:09:12 --> Model Class Initialized
INFO - 2018-05-10 12:09:12 --> Model Class Initialized
INFO - 2018-05-10 12:09:12 --> Model Class Initialized
INFO - 2018-05-10 12:09:12 --> Model Class Initialized
INFO - 2018-05-10 12:09:12 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 12:09:12 --> Model Class Initialized
INFO - 2018-05-10 12:09:12 --> Final output sent to browser
DEBUG - 2018-05-10 12:09:12 --> Total execution time: 0.1101
INFO - 2018-05-10 06:41:57 --> Config Class Initialized
INFO - 2018-05-10 06:41:57 --> Hooks Class Initialized
DEBUG - 2018-05-10 06:41:57 --> UTF-8 Support Enabled
INFO - 2018-05-10 06:41:57 --> Utf8 Class Initialized
INFO - 2018-05-10 06:41:57 --> URI Class Initialized
INFO - 2018-05-10 06:41:57 --> Router Class Initialized
INFO - 2018-05-10 06:41:57 --> Output Class Initialized
INFO - 2018-05-10 06:41:57 --> Security Class Initialized
DEBUG - 2018-05-10 06:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 06:41:57 --> Input Class Initialized
INFO - 2018-05-10 06:41:57 --> Language Class Initialized
INFO - 2018-05-10 06:41:57 --> Language Class Initialized
INFO - 2018-05-10 06:41:57 --> Config Class Initialized
INFO - 2018-05-10 06:41:57 --> Loader Class Initialized
INFO - 2018-05-10 12:11:57 --> Helper loaded: url_helper
INFO - 2018-05-10 12:11:57 --> Helper loaded: notification_helper
INFO - 2018-05-10 12:11:57 --> Helper loaded: settings_helper
INFO - 2018-05-10 12:11:57 --> Helper loaded: permission_helper
INFO - 2018-05-10 12:11:57 --> Helper loaded: users_helper
INFO - 2018-05-10 12:11:57 --> Database Driver Class Initialized
DEBUG - 2018-05-10 12:11:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 12:11:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 12:11:57 --> Helper loaded: form_helper
INFO - 2018-05-10 12:11:57 --> Form Validation Class Initialized
INFO - 2018-05-10 12:11:57 --> Controller Class Initialized
INFO - 2018-05-10 12:11:57 --> Model Class Initialized
INFO - 2018-05-10 12:11:57 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 12:11:57 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 12:11:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 12:11:57 --> Model Class Initialized
INFO - 2018-05-10 12:11:57 --> Model Class Initialized
INFO - 2018-05-10 12:11:57 --> Model Class Initialized
INFO - 2018-05-10 12:11:57 --> Model Class Initialized
INFO - 2018-05-10 12:11:57 --> Model Class Initialized
INFO - 2018-05-10 12:11:57 --> Model Class Initialized
INFO - 2018-05-10 12:11:57 --> Model Class Initialized
INFO - 2018-05-10 12:11:57 --> Model Class Initialized
INFO - 2018-05-10 12:11:57 --> Model Class Initialized
INFO - 2018-05-10 12:11:57 --> Model Class Initialized
INFO - 2018-05-10 12:11:57 --> Model Class Initialized
INFO - 2018-05-10 12:11:57 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 12:11:57 --> Model Class Initialized
INFO - 2018-05-10 12:11:57 --> Final output sent to browser
DEBUG - 2018-05-10 12:11:57 --> Total execution time: 0.1216
INFO - 2018-05-10 06:41:57 --> Config Class Initialized
INFO - 2018-05-10 06:41:57 --> Hooks Class Initialized
DEBUG - 2018-05-10 06:41:57 --> UTF-8 Support Enabled
INFO - 2018-05-10 06:41:57 --> Utf8 Class Initialized
INFO - 2018-05-10 06:41:57 --> URI Class Initialized
INFO - 2018-05-10 06:41:57 --> Router Class Initialized
INFO - 2018-05-10 06:41:57 --> Output Class Initialized
INFO - 2018-05-10 06:41:57 --> Security Class Initialized
DEBUG - 2018-05-10 06:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 06:41:57 --> Input Class Initialized
INFO - 2018-05-10 06:41:57 --> Language Class Initialized
INFO - 2018-05-10 06:41:57 --> Language Class Initialized
INFO - 2018-05-10 06:41:57 --> Config Class Initialized
INFO - 2018-05-10 06:41:57 --> Loader Class Initialized
INFO - 2018-05-10 12:11:57 --> Helper loaded: url_helper
INFO - 2018-05-10 12:11:57 --> Helper loaded: notification_helper
INFO - 2018-05-10 12:11:57 --> Helper loaded: settings_helper
INFO - 2018-05-10 12:11:57 --> Helper loaded: permission_helper
INFO - 2018-05-10 12:11:57 --> Helper loaded: users_helper
INFO - 2018-05-10 12:11:57 --> Database Driver Class Initialized
DEBUG - 2018-05-10 12:11:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 12:11:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 12:11:57 --> Helper loaded: form_helper
INFO - 2018-05-10 12:11:57 --> Form Validation Class Initialized
INFO - 2018-05-10 12:11:57 --> Controller Class Initialized
INFO - 2018-05-10 12:11:57 --> Model Class Initialized
INFO - 2018-05-10 12:11:57 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 12:11:57 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 12:11:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 12:11:57 --> Model Class Initialized
INFO - 2018-05-10 12:11:57 --> Model Class Initialized
INFO - 2018-05-10 12:11:57 --> Model Class Initialized
INFO - 2018-05-10 12:11:57 --> Model Class Initialized
INFO - 2018-05-10 12:11:57 --> Model Class Initialized
INFO - 2018-05-10 12:11:57 --> Model Class Initialized
INFO - 2018-05-10 12:11:57 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 12:11:57 --> Model Class Initialized
INFO - 2018-05-10 12:11:57 --> Final output sent to browser
DEBUG - 2018-05-10 12:11:57 --> Total execution time: 0.1453
INFO - 2018-05-10 06:42:13 --> Config Class Initialized
INFO - 2018-05-10 06:42:13 --> Hooks Class Initialized
DEBUG - 2018-05-10 06:42:13 --> UTF-8 Support Enabled
INFO - 2018-05-10 06:42:13 --> Utf8 Class Initialized
INFO - 2018-05-10 06:42:13 --> URI Class Initialized
INFO - 2018-05-10 06:42:13 --> Router Class Initialized
INFO - 2018-05-10 06:42:13 --> Output Class Initialized
INFO - 2018-05-10 06:42:13 --> Security Class Initialized
DEBUG - 2018-05-10 06:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 06:42:13 --> Input Class Initialized
INFO - 2018-05-10 06:42:13 --> Language Class Initialized
INFO - 2018-05-10 06:42:13 --> Config Class Initialized
INFO - 2018-05-10 06:42:13 --> Hooks Class Initialized
DEBUG - 2018-05-10 06:42:13 --> UTF-8 Support Enabled
INFO - 2018-05-10 06:42:13 --> Utf8 Class Initialized
INFO - 2018-05-10 06:42:13 --> URI Class Initialized
INFO - 2018-05-10 06:42:13 --> Router Class Initialized
INFO - 2018-05-10 06:42:13 --> Output Class Initialized
INFO - 2018-05-10 06:42:13 --> Security Class Initialized
INFO - 2018-05-10 06:42:13 --> Language Class Initialized
INFO - 2018-05-10 06:42:13 --> Config Class Initialized
INFO - 2018-05-10 06:42:13 --> Loader Class Initialized
DEBUG - 2018-05-10 06:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 06:42:13 --> Input Class Initialized
INFO - 2018-05-10 12:12:13 --> Helper loaded: url_helper
INFO - 2018-05-10 06:42:13 --> Language Class Initialized
INFO - 2018-05-10 12:12:13 --> Helper loaded: notification_helper
INFO - 2018-05-10 12:12:13 --> Helper loaded: settings_helper
INFO - 2018-05-10 12:12:13 --> Helper loaded: permission_helper
INFO - 2018-05-10 12:12:13 --> Helper loaded: users_helper
INFO - 2018-05-10 12:12:13 --> Database Driver Class Initialized
INFO - 2018-05-10 06:42:13 --> Language Class Initialized
INFO - 2018-05-10 06:42:13 --> Config Class Initialized
INFO - 2018-05-10 06:42:13 --> Loader Class Initialized
INFO - 2018-05-10 12:12:13 --> Helper loaded: url_helper
INFO - 2018-05-10 12:12:13 --> Helper loaded: notification_helper
INFO - 2018-05-10 12:12:13 --> Helper loaded: settings_helper
DEBUG - 2018-05-10 12:12:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 12:12:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 12:12:13 --> Helper loaded: permission_helper
INFO - 2018-05-10 12:12:13 --> Helper loaded: users_helper
INFO - 2018-05-10 12:12:13 --> Helper loaded: form_helper
INFO - 2018-05-10 12:12:13 --> Form Validation Class Initialized
INFO - 2018-05-10 12:12:13 --> Controller Class Initialized
INFO - 2018-05-10 12:12:13 --> Model Class Initialized
INFO - 2018-05-10 12:12:13 --> Helper loaded: inflector_helper
INFO - 2018-05-10 12:12:13 --> Database Driver Class Initialized
DEBUG - 2018-05-10 12:12:13 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 12:12:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 12:12:13 --> Model Class Initialized
INFO - 2018-05-10 12:12:13 --> Model Class Initialized
DEBUG - 2018-05-10 12:12:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 12:12:13 --> Model Class Initialized
INFO - 2018-05-10 12:12:13 --> Model Class Initialized
INFO - 2018-05-10 12:12:13 --> Model Class Initialized
INFO - 2018-05-10 12:12:13 --> Model Class Initialized
INFO - 2018-05-10 12:12:13 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 12:12:13 --> Final output sent to browser
DEBUG - 2018-05-10 12:12:13 --> Total execution time: 0.1177
INFO - 2018-05-10 12:12:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 12:12:13 --> Helper loaded: form_helper
INFO - 2018-05-10 12:12:13 --> Form Validation Class Initialized
INFO - 2018-05-10 12:12:13 --> Controller Class Initialized
INFO - 2018-05-10 12:12:13 --> Model Class Initialized
INFO - 2018-05-10 12:12:13 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 12:12:13 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 12:12:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 12:12:13 --> Model Class Initialized
INFO - 2018-05-10 12:12:13 --> Model Class Initialized
INFO - 2018-05-10 12:12:13 --> Model Class Initialized
INFO - 2018-05-10 12:12:13 --> Model Class Initialized
INFO - 2018-05-10 12:12:13 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 12:12:13 --> Final output sent to browser
DEBUG - 2018-05-10 12:12:13 --> Total execution time: 0.1398
INFO - 2018-05-10 06:42:16 --> Config Class Initialized
INFO - 2018-05-10 06:42:16 --> Hooks Class Initialized
DEBUG - 2018-05-10 06:42:16 --> UTF-8 Support Enabled
INFO - 2018-05-10 06:42:16 --> Utf8 Class Initialized
INFO - 2018-05-10 06:42:16 --> URI Class Initialized
INFO - 2018-05-10 06:42:16 --> Router Class Initialized
INFO - 2018-05-10 06:42:16 --> Output Class Initialized
INFO - 2018-05-10 06:42:16 --> Security Class Initialized
DEBUG - 2018-05-10 06:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 06:42:16 --> Input Class Initialized
INFO - 2018-05-10 06:42:16 --> Language Class Initialized
INFO - 2018-05-10 06:42:16 --> Language Class Initialized
INFO - 2018-05-10 06:42:16 --> Config Class Initialized
INFO - 2018-05-10 06:42:16 --> Loader Class Initialized
INFO - 2018-05-10 12:12:16 --> Helper loaded: url_helper
INFO - 2018-05-10 12:12:16 --> Helper loaded: notification_helper
INFO - 2018-05-10 12:12:16 --> Helper loaded: settings_helper
INFO - 2018-05-10 12:12:16 --> Helper loaded: permission_helper
INFO - 2018-05-10 12:12:16 --> Helper loaded: users_helper
INFO - 2018-05-10 12:12:16 --> Database Driver Class Initialized
DEBUG - 2018-05-10 12:12:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 12:12:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 12:12:16 --> Helper loaded: form_helper
INFO - 2018-05-10 12:12:16 --> Form Validation Class Initialized
INFO - 2018-05-10 12:12:16 --> Controller Class Initialized
INFO - 2018-05-10 12:12:16 --> Model Class Initialized
INFO - 2018-05-10 12:12:16 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 12:12:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 12:12:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 12:12:16 --> Model Class Initialized
INFO - 2018-05-10 12:12:16 --> Model Class Initialized
INFO - 2018-05-10 12:12:16 --> Model Class Initialized
INFO - 2018-05-10 12:12:16 --> Model Class Initialized
INFO - 2018-05-10 12:12:16 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 12:12:16 --> Model Class Initialized
INFO - 2018-05-10 12:12:16 --> Final output sent to browser
DEBUG - 2018-05-10 12:12:16 --> Total execution time: 0.1580
INFO - 2018-05-10 06:44:03 --> Config Class Initialized
INFO - 2018-05-10 06:44:03 --> Hooks Class Initialized
DEBUG - 2018-05-10 06:44:03 --> UTF-8 Support Enabled
INFO - 2018-05-10 06:44:03 --> Utf8 Class Initialized
INFO - 2018-05-10 06:44:03 --> URI Class Initialized
INFO - 2018-05-10 06:44:03 --> Router Class Initialized
INFO - 2018-05-10 06:44:03 --> Output Class Initialized
INFO - 2018-05-10 06:44:03 --> Security Class Initialized
DEBUG - 2018-05-10 06:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 06:44:03 --> Input Class Initialized
INFO - 2018-05-10 06:44:03 --> Language Class Initialized
INFO - 2018-05-10 06:44:03 --> Language Class Initialized
INFO - 2018-05-10 06:44:03 --> Config Class Initialized
INFO - 2018-05-10 06:44:03 --> Loader Class Initialized
INFO - 2018-05-10 12:14:03 --> Helper loaded: url_helper
INFO - 2018-05-10 12:14:03 --> Helper loaded: notification_helper
INFO - 2018-05-10 12:14:03 --> Helper loaded: settings_helper
INFO - 2018-05-10 12:14:03 --> Helper loaded: permission_helper
INFO - 2018-05-10 12:14:03 --> Helper loaded: users_helper
INFO - 2018-05-10 12:14:03 --> Database Driver Class Initialized
DEBUG - 2018-05-10 12:14:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 12:14:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 12:14:03 --> Helper loaded: form_helper
INFO - 2018-05-10 12:14:03 --> Form Validation Class Initialized
INFO - 2018-05-10 12:14:03 --> Controller Class Initialized
INFO - 2018-05-10 12:14:03 --> Model Class Initialized
INFO - 2018-05-10 12:14:03 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 12:14:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 12:14:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 12:14:03 --> Model Class Initialized
INFO - 2018-05-10 12:14:03 --> Model Class Initialized
INFO - 2018-05-10 12:14:03 --> Model Class Initialized
INFO - 2018-05-10 12:14:03 --> Model Class Initialized
INFO - 2018-05-10 12:14:03 --> Model Class Initialized
INFO - 2018-05-10 12:14:03 --> Model Class Initialized
INFO - 2018-05-10 12:14:03 --> Model Class Initialized
INFO - 2018-05-10 12:14:03 --> Model Class Initialized
INFO - 2018-05-10 12:14:03 --> Model Class Initialized
INFO - 2018-05-10 12:14:03 --> Model Class Initialized
INFO - 2018-05-10 12:14:03 --> Model Class Initialized
INFO - 2018-05-10 12:14:03 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 12:14:03 --> Model Class Initialized
INFO - 2018-05-10 12:14:03 --> Final output sent to browser
DEBUG - 2018-05-10 12:14:03 --> Total execution time: 0.1316
INFO - 2018-05-10 06:44:03 --> Config Class Initialized
INFO - 2018-05-10 06:44:03 --> Hooks Class Initialized
DEBUG - 2018-05-10 06:44:03 --> UTF-8 Support Enabled
INFO - 2018-05-10 06:44:03 --> Utf8 Class Initialized
INFO - 2018-05-10 06:44:03 --> URI Class Initialized
INFO - 2018-05-10 06:44:03 --> Router Class Initialized
INFO - 2018-05-10 06:44:03 --> Output Class Initialized
INFO - 2018-05-10 06:44:03 --> Security Class Initialized
DEBUG - 2018-05-10 06:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 06:44:03 --> Input Class Initialized
INFO - 2018-05-10 06:44:03 --> Language Class Initialized
INFO - 2018-05-10 06:44:03 --> Language Class Initialized
INFO - 2018-05-10 06:44:03 --> Config Class Initialized
INFO - 2018-05-10 06:44:03 --> Loader Class Initialized
INFO - 2018-05-10 12:14:03 --> Helper loaded: url_helper
INFO - 2018-05-10 12:14:03 --> Helper loaded: notification_helper
INFO - 2018-05-10 12:14:03 --> Helper loaded: settings_helper
INFO - 2018-05-10 12:14:03 --> Helper loaded: permission_helper
INFO - 2018-05-10 12:14:03 --> Helper loaded: users_helper
INFO - 2018-05-10 12:14:03 --> Database Driver Class Initialized
DEBUG - 2018-05-10 12:14:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 12:14:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 12:14:03 --> Helper loaded: form_helper
INFO - 2018-05-10 12:14:03 --> Form Validation Class Initialized
INFO - 2018-05-10 12:14:03 --> Controller Class Initialized
INFO - 2018-05-10 12:14:03 --> Model Class Initialized
INFO - 2018-05-10 12:14:03 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 12:14:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 12:14:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 12:14:03 --> Model Class Initialized
INFO - 2018-05-10 12:14:03 --> Model Class Initialized
INFO - 2018-05-10 12:14:03 --> Model Class Initialized
INFO - 2018-05-10 12:14:03 --> Model Class Initialized
INFO - 2018-05-10 12:14:03 --> Model Class Initialized
INFO - 2018-05-10 12:14:03 --> Model Class Initialized
INFO - 2018-05-10 12:14:03 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 12:14:03 --> Model Class Initialized
INFO - 2018-05-10 12:14:03 --> Final output sent to browser
DEBUG - 2018-05-10 12:14:03 --> Total execution time: 0.1183
INFO - 2018-05-10 06:44:05 --> Config Class Initialized
INFO - 2018-05-10 06:44:05 --> Hooks Class Initialized
DEBUG - 2018-05-10 06:44:05 --> UTF-8 Support Enabled
INFO - 2018-05-10 06:44:05 --> Config Class Initialized
INFO - 2018-05-10 06:44:05 --> Utf8 Class Initialized
INFO - 2018-05-10 06:44:05 --> Hooks Class Initialized
INFO - 2018-05-10 06:44:05 --> URI Class Initialized
DEBUG - 2018-05-10 06:44:05 --> UTF-8 Support Enabled
INFO - 2018-05-10 06:44:05 --> Utf8 Class Initialized
INFO - 2018-05-10 06:44:05 --> URI Class Initialized
INFO - 2018-05-10 06:44:05 --> Router Class Initialized
INFO - 2018-05-10 06:44:05 --> Router Class Initialized
INFO - 2018-05-10 06:44:05 --> Output Class Initialized
INFO - 2018-05-10 06:44:05 --> Output Class Initialized
INFO - 2018-05-10 06:44:05 --> Security Class Initialized
INFO - 2018-05-10 06:44:05 --> Security Class Initialized
DEBUG - 2018-05-10 06:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 06:44:05 --> Input Class Initialized
INFO - 2018-05-10 06:44:05 --> Language Class Initialized
DEBUG - 2018-05-10 06:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 06:44:05 --> Input Class Initialized
INFO - 2018-05-10 06:44:05 --> Language Class Initialized
INFO - 2018-05-10 06:44:05 --> Language Class Initialized
INFO - 2018-05-10 06:44:05 --> Config Class Initialized
INFO - 2018-05-10 06:44:05 --> Loader Class Initialized
INFO - 2018-05-10 12:14:05 --> Helper loaded: url_helper
INFO - 2018-05-10 12:14:05 --> Helper loaded: notification_helper
INFO - 2018-05-10 12:14:05 --> Helper loaded: settings_helper
INFO - 2018-05-10 12:14:05 --> Helper loaded: permission_helper
INFO - 2018-05-10 06:44:05 --> Language Class Initialized
INFO - 2018-05-10 06:44:05 --> Config Class Initialized
INFO - 2018-05-10 06:44:05 --> Loader Class Initialized
INFO - 2018-05-10 12:14:05 --> Helper loaded: users_helper
INFO - 2018-05-10 12:14:05 --> Helper loaded: url_helper
INFO - 2018-05-10 12:14:05 --> Helper loaded: notification_helper
INFO - 2018-05-10 12:14:05 --> Helper loaded: settings_helper
INFO - 2018-05-10 12:14:05 --> Helper loaded: permission_helper
INFO - 2018-05-10 12:14:05 --> Helper loaded: users_helper
INFO - 2018-05-10 12:14:05 --> Database Driver Class Initialized
INFO - 2018-05-10 12:14:05 --> Database Driver Class Initialized
DEBUG - 2018-05-10 12:14:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 12:14:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-05-10 12:14:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 12:14:05 --> Helper loaded: form_helper
INFO - 2018-05-10 12:14:05 --> Form Validation Class Initialized
INFO - 2018-05-10 12:14:05 --> Controller Class Initialized
INFO - 2018-05-10 12:14:05 --> Model Class Initialized
INFO - 2018-05-10 12:14:05 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 12:14:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 12:14:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 12:14:05 --> Model Class Initialized
INFO - 2018-05-10 12:14:05 --> Model Class Initialized
INFO - 2018-05-10 12:14:05 --> Model Class Initialized
INFO - 2018-05-10 12:14:05 --> Model Class Initialized
INFO - 2018-05-10 12:14:05 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 12:14:05 --> Final output sent to browser
DEBUG - 2018-05-10 12:14:05 --> Total execution time: 0.1000
INFO - 2018-05-10 12:14:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 12:14:05 --> Helper loaded: form_helper
INFO - 2018-05-10 12:14:05 --> Form Validation Class Initialized
INFO - 2018-05-10 12:14:05 --> Controller Class Initialized
INFO - 2018-05-10 12:14:05 --> Model Class Initialized
INFO - 2018-05-10 12:14:05 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 12:14:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 12:14:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 12:14:05 --> Model Class Initialized
INFO - 2018-05-10 12:14:05 --> Model Class Initialized
INFO - 2018-05-10 12:14:05 --> Model Class Initialized
INFO - 2018-05-10 12:14:05 --> Model Class Initialized
INFO - 2018-05-10 12:14:05 --> Model Class Initialized
INFO - 2018-05-10 12:14:05 --> Model Class Initialized
INFO - 2018-05-10 12:14:05 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 12:14:05 --> Final output sent to browser
DEBUG - 2018-05-10 12:14:05 --> Total execution time: 0.1234
INFO - 2018-05-10 06:44:07 --> Config Class Initialized
INFO - 2018-05-10 06:44:07 --> Hooks Class Initialized
DEBUG - 2018-05-10 06:44:07 --> UTF-8 Support Enabled
INFO - 2018-05-10 06:44:07 --> Utf8 Class Initialized
INFO - 2018-05-10 06:44:07 --> URI Class Initialized
INFO - 2018-05-10 06:44:07 --> Router Class Initialized
INFO - 2018-05-10 06:44:07 --> Output Class Initialized
INFO - 2018-05-10 06:44:07 --> Security Class Initialized
DEBUG - 2018-05-10 06:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 06:44:07 --> Input Class Initialized
INFO - 2018-05-10 06:44:07 --> Language Class Initialized
INFO - 2018-05-10 06:44:07 --> Language Class Initialized
INFO - 2018-05-10 06:44:07 --> Config Class Initialized
INFO - 2018-05-10 06:44:07 --> Loader Class Initialized
INFO - 2018-05-10 12:14:07 --> Helper loaded: url_helper
INFO - 2018-05-10 12:14:07 --> Helper loaded: notification_helper
INFO - 2018-05-10 12:14:07 --> Helper loaded: settings_helper
INFO - 2018-05-10 12:14:07 --> Helper loaded: permission_helper
INFO - 2018-05-10 12:14:07 --> Helper loaded: users_helper
INFO - 2018-05-10 12:14:07 --> Database Driver Class Initialized
DEBUG - 2018-05-10 12:14:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 12:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 12:14:07 --> Helper loaded: form_helper
INFO - 2018-05-10 12:14:07 --> Form Validation Class Initialized
INFO - 2018-05-10 12:14:07 --> Controller Class Initialized
INFO - 2018-05-10 12:14:07 --> Model Class Initialized
INFO - 2018-05-10 12:14:07 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 12:14:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 12:14:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 12:14:07 --> Model Class Initialized
INFO - 2018-05-10 12:14:07 --> Model Class Initialized
INFO - 2018-05-10 12:14:07 --> Model Class Initialized
INFO - 2018-05-10 12:14:07 --> Model Class Initialized
INFO - 2018-05-10 12:14:07 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 12:14:07 --> Model Class Initialized
INFO - 2018-05-10 12:14:07 --> Final output sent to browser
DEBUG - 2018-05-10 12:14:07 --> Total execution time: 0.0893
INFO - 2018-05-10 06:44:14 --> Config Class Initialized
INFO - 2018-05-10 06:44:14 --> Hooks Class Initialized
DEBUG - 2018-05-10 06:44:14 --> UTF-8 Support Enabled
INFO - 2018-05-10 06:44:14 --> Utf8 Class Initialized
INFO - 2018-05-10 06:44:14 --> URI Class Initialized
INFO - 2018-05-10 06:44:14 --> Router Class Initialized
INFO - 2018-05-10 06:44:14 --> Output Class Initialized
INFO - 2018-05-10 06:44:14 --> Security Class Initialized
DEBUG - 2018-05-10 06:44:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 06:44:14 --> Input Class Initialized
INFO - 2018-05-10 06:44:14 --> Language Class Initialized
INFO - 2018-05-10 06:44:14 --> Language Class Initialized
INFO - 2018-05-10 06:44:14 --> Config Class Initialized
INFO - 2018-05-10 06:44:14 --> Loader Class Initialized
INFO - 2018-05-10 12:14:14 --> Helper loaded: url_helper
INFO - 2018-05-10 12:14:14 --> Helper loaded: notification_helper
INFO - 2018-05-10 12:14:14 --> Helper loaded: settings_helper
INFO - 2018-05-10 12:14:14 --> Helper loaded: permission_helper
INFO - 2018-05-10 12:14:14 --> Helper loaded: users_helper
INFO - 2018-05-10 12:14:14 --> Database Driver Class Initialized
DEBUG - 2018-05-10 12:14:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 12:14:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 12:14:14 --> Helper loaded: form_helper
INFO - 2018-05-10 12:14:14 --> Form Validation Class Initialized
INFO - 2018-05-10 12:14:14 --> Controller Class Initialized
INFO - 2018-05-10 12:14:14 --> Model Class Initialized
INFO - 2018-05-10 12:14:14 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 12:14:14 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 12:14:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 12:14:14 --> Model Class Initialized
INFO - 2018-05-10 12:14:14 --> Model Class Initialized
INFO - 2018-05-10 12:14:14 --> Model Class Initialized
INFO - 2018-05-10 12:14:14 --> Model Class Initialized
INFO - 2018-05-10 12:14:14 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 12:14:14 --> Model Class Initialized
INFO - 2018-05-10 12:14:14 --> Final output sent to browser
DEBUG - 2018-05-10 12:14:14 --> Total execution time: 0.0976
INFO - 2018-05-10 06:44:39 --> Config Class Initialized
INFO - 2018-05-10 06:44:39 --> Hooks Class Initialized
DEBUG - 2018-05-10 06:44:39 --> UTF-8 Support Enabled
INFO - 2018-05-10 06:44:39 --> Utf8 Class Initialized
INFO - 2018-05-10 06:44:39 --> URI Class Initialized
INFO - 2018-05-10 06:44:39 --> Router Class Initialized
INFO - 2018-05-10 06:44:39 --> Output Class Initialized
INFO - 2018-05-10 06:44:39 --> Security Class Initialized
DEBUG - 2018-05-10 06:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 06:44:39 --> Input Class Initialized
INFO - 2018-05-10 06:44:39 --> Language Class Initialized
INFO - 2018-05-10 06:44:39 --> Language Class Initialized
INFO - 2018-05-10 06:44:39 --> Config Class Initialized
INFO - 2018-05-10 06:44:39 --> Loader Class Initialized
INFO - 2018-05-10 12:14:39 --> Helper loaded: url_helper
INFO - 2018-05-10 12:14:39 --> Helper loaded: notification_helper
INFO - 2018-05-10 12:14:39 --> Helper loaded: settings_helper
INFO - 2018-05-10 12:14:39 --> Helper loaded: permission_helper
INFO - 2018-05-10 12:14:39 --> Helper loaded: users_helper
INFO - 2018-05-10 12:14:39 --> Database Driver Class Initialized
DEBUG - 2018-05-10 12:14:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 12:14:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 12:14:39 --> Helper loaded: form_helper
INFO - 2018-05-10 12:14:39 --> Form Validation Class Initialized
INFO - 2018-05-10 12:14:39 --> Controller Class Initialized
INFO - 2018-05-10 12:14:39 --> Model Class Initialized
INFO - 2018-05-10 12:14:39 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 12:14:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 12:14:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 12:14:39 --> Model Class Initialized
INFO - 2018-05-10 12:14:39 --> Model Class Initialized
INFO - 2018-05-10 12:14:39 --> Model Class Initialized
INFO - 2018-05-10 12:14:39 --> Model Class Initialized
INFO - 2018-05-10 12:14:39 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 12:14:39 --> Model Class Initialized
INFO - 2018-05-10 12:14:39 --> Final output sent to browser
DEBUG - 2018-05-10 12:14:39 --> Total execution time: 0.1016
INFO - 2018-05-10 07:15:50 --> Config Class Initialized
INFO - 2018-05-10 07:15:50 --> Hooks Class Initialized
DEBUG - 2018-05-10 07:15:50 --> UTF-8 Support Enabled
INFO - 2018-05-10 07:15:50 --> Utf8 Class Initialized
INFO - 2018-05-10 07:15:50 --> URI Class Initialized
INFO - 2018-05-10 07:15:50 --> Router Class Initialized
INFO - 2018-05-10 07:15:50 --> Output Class Initialized
INFO - 2018-05-10 07:15:50 --> Security Class Initialized
DEBUG - 2018-05-10 07:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 07:15:50 --> Input Class Initialized
INFO - 2018-05-10 07:15:50 --> Language Class Initialized
INFO - 2018-05-10 07:15:50 --> Language Class Initialized
INFO - 2018-05-10 07:15:50 --> Config Class Initialized
INFO - 2018-05-10 07:15:50 --> Loader Class Initialized
INFO - 2018-05-10 12:45:50 --> Helper loaded: url_helper
INFO - 2018-05-10 12:45:50 --> Helper loaded: notification_helper
INFO - 2018-05-10 12:45:50 --> Helper loaded: settings_helper
INFO - 2018-05-10 12:45:50 --> Helper loaded: permission_helper
INFO - 2018-05-10 12:45:50 --> Helper loaded: users_helper
INFO - 2018-05-10 12:45:50 --> Database Driver Class Initialized
DEBUG - 2018-05-10 12:45:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 12:45:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 12:45:50 --> Helper loaded: form_helper
INFO - 2018-05-10 12:45:50 --> Form Validation Class Initialized
INFO - 2018-05-10 12:45:50 --> Controller Class Initialized
INFO - 2018-05-10 12:45:50 --> Model Class Initialized
INFO - 2018-05-10 12:45:50 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 12:45:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 12:45:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 12:45:50 --> Model Class Initialized
INFO - 2018-05-10 12:45:50 --> Model Class Initialized
INFO - 2018-05-10 12:45:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 12:45:50 --> Model Class Initialized
INFO - 2018-05-10 12:45:50 --> Model Class Initialized
INFO - 2018-05-10 12:45:50 --> Final output sent to browser
DEBUG - 2018-05-10 12:45:50 --> Total execution time: 0.1197
INFO - 2018-05-10 08:30:19 --> Config Class Initialized
INFO - 2018-05-10 08:30:19 --> Hooks Class Initialized
DEBUG - 2018-05-10 08:30:19 --> UTF-8 Support Enabled
INFO - 2018-05-10 08:30:19 --> Utf8 Class Initialized
INFO - 2018-05-10 08:30:19 --> URI Class Initialized
INFO - 2018-05-10 08:30:19 --> Router Class Initialized
INFO - 2018-05-10 08:30:19 --> Output Class Initialized
INFO - 2018-05-10 08:30:19 --> Security Class Initialized
DEBUG - 2018-05-10 08:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 08:30:19 --> Input Class Initialized
INFO - 2018-05-10 08:30:19 --> Language Class Initialized
INFO - 2018-05-10 08:30:19 --> Language Class Initialized
INFO - 2018-05-10 08:30:19 --> Config Class Initialized
INFO - 2018-05-10 08:30:19 --> Loader Class Initialized
INFO - 2018-05-10 14:00:19 --> Helper loaded: url_helper
INFO - 2018-05-10 14:00:19 --> Helper loaded: notification_helper
INFO - 2018-05-10 14:00:19 --> Helper loaded: settings_helper
INFO - 2018-05-10 14:00:19 --> Helper loaded: permission_helper
INFO - 2018-05-10 14:00:19 --> Helper loaded: users_helper
INFO - 2018-05-10 14:00:19 --> Database Driver Class Initialized
DEBUG - 2018-05-10 14:00:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 14:00:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 14:00:19 --> Helper loaded: form_helper
INFO - 2018-05-10 14:00:19 --> Form Validation Class Initialized
INFO - 2018-05-10 14:00:19 --> Controller Class Initialized
INFO - 2018-05-10 14:00:19 --> Model Class Initialized
INFO - 2018-05-10 14:00:19 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 14:00:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 14:00:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 14:00:19 --> Model Class Initialized
INFO - 2018-05-10 14:00:19 --> Model Class Initialized
INFO - 2018-05-10 14:00:19 --> Model Class Initialized
INFO - 2018-05-10 14:00:19 --> Model Class Initialized
INFO - 2018-05-10 14:00:19 --> Model Class Initialized
INFO - 2018-05-10 14:00:19 --> Model Class Initialized
INFO - 2018-05-10 14:00:19 --> Model Class Initialized
INFO - 2018-05-10 14:00:19 --> Model Class Initialized
INFO - 2018-05-10 14:00:19 --> Model Class Initialized
INFO - 2018-05-10 14:00:19 --> Model Class Initialized
INFO - 2018-05-10 14:00:19 --> Model Class Initialized
INFO - 2018-05-10 14:00:19 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 14:00:19 --> Model Class Initialized
INFO - 2018-05-10 14:00:19 --> Final output sent to browser
DEBUG - 2018-05-10 14:00:19 --> Total execution time: 0.1306
INFO - 2018-05-10 08:30:21 --> Config Class Initialized
INFO - 2018-05-10 08:30:21 --> Hooks Class Initialized
DEBUG - 2018-05-10 08:30:21 --> UTF-8 Support Enabled
INFO - 2018-05-10 08:30:21 --> Utf8 Class Initialized
INFO - 2018-05-10 08:30:21 --> URI Class Initialized
INFO - 2018-05-10 08:30:21 --> Router Class Initialized
INFO - 2018-05-10 08:30:21 --> Output Class Initialized
INFO - 2018-05-10 08:30:21 --> Security Class Initialized
DEBUG - 2018-05-10 08:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 08:30:21 --> Input Class Initialized
INFO - 2018-05-10 08:30:21 --> Language Class Initialized
INFO - 2018-05-10 08:30:21 --> Language Class Initialized
INFO - 2018-05-10 08:30:21 --> Config Class Initialized
INFO - 2018-05-10 08:30:21 --> Loader Class Initialized
INFO - 2018-05-10 14:00:21 --> Helper loaded: url_helper
INFO - 2018-05-10 14:00:21 --> Helper loaded: notification_helper
INFO - 2018-05-10 14:00:21 --> Helper loaded: settings_helper
INFO - 2018-05-10 14:00:21 --> Helper loaded: permission_helper
INFO - 2018-05-10 14:00:21 --> Helper loaded: users_helper
INFO - 2018-05-10 14:00:21 --> Database Driver Class Initialized
DEBUG - 2018-05-10 14:00:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 14:00:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 14:00:21 --> Helper loaded: form_helper
INFO - 2018-05-10 14:00:21 --> Form Validation Class Initialized
INFO - 2018-05-10 14:00:21 --> Controller Class Initialized
INFO - 2018-05-10 14:00:21 --> Model Class Initialized
INFO - 2018-05-10 14:00:21 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 14:00:21 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 14:00:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 14:00:21 --> Model Class Initialized
INFO - 2018-05-10 14:00:21 --> Model Class Initialized
INFO - 2018-05-10 14:00:21 --> Model Class Initialized
INFO - 2018-05-10 14:00:21 --> Model Class Initialized
INFO - 2018-05-10 14:00:21 --> Model Class Initialized
INFO - 2018-05-10 14:00:21 --> Model Class Initialized
INFO - 2018-05-10 14:00:21 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 14:00:21 --> Model Class Initialized
INFO - 2018-05-10 14:00:21 --> Final output sent to browser
DEBUG - 2018-05-10 14:00:21 --> Total execution time: 0.1185
INFO - 2018-05-10 08:30:30 --> Config Class Initialized
INFO - 2018-05-10 08:30:30 --> Hooks Class Initialized
DEBUG - 2018-05-10 08:30:30 --> UTF-8 Support Enabled
INFO - 2018-05-10 08:30:30 --> Utf8 Class Initialized
INFO - 2018-05-10 08:30:30 --> URI Class Initialized
INFO - 2018-05-10 08:30:30 --> Router Class Initialized
INFO - 2018-05-10 08:30:30 --> Output Class Initialized
INFO - 2018-05-10 08:30:30 --> Security Class Initialized
DEBUG - 2018-05-10 08:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 08:30:30 --> Input Class Initialized
INFO - 2018-05-10 08:30:30 --> Language Class Initialized
INFO - 2018-05-10 08:30:30 --> Config Class Initialized
INFO - 2018-05-10 08:30:30 --> Hooks Class Initialized
DEBUG - 2018-05-10 08:30:30 --> UTF-8 Support Enabled
INFO - 2018-05-10 08:30:30 --> Utf8 Class Initialized
INFO - 2018-05-10 08:30:30 --> Language Class Initialized
INFO - 2018-05-10 08:30:30 --> Config Class Initialized
INFO - 2018-05-10 08:30:30 --> URI Class Initialized
INFO - 2018-05-10 08:30:30 --> Loader Class Initialized
INFO - 2018-05-10 14:00:30 --> Helper loaded: url_helper
INFO - 2018-05-10 14:00:30 --> Helper loaded: notification_helper
INFO - 2018-05-10 08:30:30 --> Router Class Initialized
INFO - 2018-05-10 14:00:30 --> Helper loaded: settings_helper
INFO - 2018-05-10 14:00:30 --> Helper loaded: permission_helper
INFO - 2018-05-10 14:00:30 --> Helper loaded: users_helper
INFO - 2018-05-10 08:30:30 --> Output Class Initialized
INFO - 2018-05-10 08:30:30 --> Security Class Initialized
DEBUG - 2018-05-10 08:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 08:30:30 --> Input Class Initialized
INFO - 2018-05-10 08:30:30 --> Language Class Initialized
INFO - 2018-05-10 14:00:30 --> Database Driver Class Initialized
DEBUG - 2018-05-10 14:00:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 14:00:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 08:30:30 --> Language Class Initialized
INFO - 2018-05-10 08:30:30 --> Config Class Initialized
INFO - 2018-05-10 08:30:30 --> Loader Class Initialized
INFO - 2018-05-10 14:00:30 --> Helper loaded: url_helper
INFO - 2018-05-10 14:00:30 --> Helper loaded: form_helper
INFO - 2018-05-10 14:00:30 --> Form Validation Class Initialized
INFO - 2018-05-10 14:00:30 --> Controller Class Initialized
INFO - 2018-05-10 14:00:30 --> Helper loaded: notification_helper
INFO - 2018-05-10 14:00:30 --> Helper loaded: settings_helper
INFO - 2018-05-10 14:00:30 --> Helper loaded: permission_helper
INFO - 2018-05-10 14:00:30 --> Helper loaded: users_helper
INFO - 2018-05-10 14:00:30 --> Model Class Initialized
INFO - 2018-05-10 14:00:30 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 14:00:30 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 14:00:30 --> Database Driver Class Initialized
INFO - 2018-05-10 14:00:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 14:00:30 --> Model Class Initialized
INFO - 2018-05-10 14:00:30 --> Model Class Initialized
INFO - 2018-05-10 14:00:30 --> Model Class Initialized
INFO - 2018-05-10 14:00:30 --> Model Class Initialized
INFO - 2018-05-10 14:00:30 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-05-10 14:00:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 14:00:30 --> Final output sent to browser
DEBUG - 2018-05-10 14:00:30 --> Total execution time: 0.1797
INFO - 2018-05-10 14:00:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 14:00:30 --> Helper loaded: form_helper
INFO - 2018-05-10 14:00:30 --> Form Validation Class Initialized
INFO - 2018-05-10 14:00:30 --> Controller Class Initialized
INFO - 2018-05-10 14:00:30 --> Model Class Initialized
INFO - 2018-05-10 14:00:30 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 14:00:30 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 14:00:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 14:00:30 --> Model Class Initialized
INFO - 2018-05-10 14:00:30 --> Model Class Initialized
INFO - 2018-05-10 14:00:30 --> Model Class Initialized
INFO - 2018-05-10 14:00:30 --> Model Class Initialized
INFO - 2018-05-10 14:00:30 --> Model Class Initialized
INFO - 2018-05-10 14:00:30 --> Model Class Initialized
INFO - 2018-05-10 14:00:30 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 14:00:30 --> Final output sent to browser
DEBUG - 2018-05-10 14:00:30 --> Total execution time: 0.1875
INFO - 2018-05-10 08:34:51 --> Config Class Initialized
INFO - 2018-05-10 08:34:51 --> Hooks Class Initialized
DEBUG - 2018-05-10 08:34:51 --> UTF-8 Support Enabled
INFO - 2018-05-10 08:34:51 --> Utf8 Class Initialized
INFO - 2018-05-10 08:34:51 --> URI Class Initialized
INFO - 2018-05-10 08:34:51 --> Router Class Initialized
INFO - 2018-05-10 08:34:51 --> Output Class Initialized
INFO - 2018-05-10 08:34:51 --> Security Class Initialized
DEBUG - 2018-05-10 08:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 08:34:51 --> Input Class Initialized
INFO - 2018-05-10 08:34:51 --> Language Class Initialized
INFO - 2018-05-10 08:34:52 --> Language Class Initialized
INFO - 2018-05-10 08:34:52 --> Config Class Initialized
INFO - 2018-05-10 08:34:52 --> Loader Class Initialized
INFO - 2018-05-10 14:04:52 --> Helper loaded: url_helper
INFO - 2018-05-10 14:04:52 --> Helper loaded: notification_helper
INFO - 2018-05-10 14:04:52 --> Helper loaded: settings_helper
INFO - 2018-05-10 14:04:52 --> Helper loaded: permission_helper
INFO - 2018-05-10 14:04:52 --> Helper loaded: users_helper
INFO - 2018-05-10 14:04:52 --> Database Driver Class Initialized
DEBUG - 2018-05-10 14:04:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 14:04:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 14:04:52 --> Helper loaded: form_helper
INFO - 2018-05-10 14:04:52 --> Form Validation Class Initialized
INFO - 2018-05-10 14:04:52 --> Controller Class Initialized
INFO - 2018-05-10 14:04:52 --> Model Class Initialized
INFO - 2018-05-10 14:04:52 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 14:04:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 14:04:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 14:04:52 --> Model Class Initialized
INFO - 2018-05-10 14:04:52 --> Model Class Initialized
INFO - 2018-05-10 14:04:52 --> Model Class Initialized
INFO - 2018-05-10 14:04:52 --> Model Class Initialized
INFO - 2018-05-10 14:04:52 --> Model Class Initialized
INFO - 2018-05-10 14:04:52 --> Model Class Initialized
INFO - 2018-05-10 14:04:52 --> Model Class Initialized
INFO - 2018-05-10 14:04:52 --> Model Class Initialized
INFO - 2018-05-10 14:04:52 --> Model Class Initialized
INFO - 2018-05-10 14:04:52 --> Model Class Initialized
INFO - 2018-05-10 14:04:52 --> Model Class Initialized
INFO - 2018-05-10 14:04:52 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 14:04:52 --> Model Class Initialized
INFO - 2018-05-10 14:04:52 --> Final output sent to browser
DEBUG - 2018-05-10 14:04:52 --> Total execution time: 0.1130
INFO - 2018-05-10 08:34:52 --> Config Class Initialized
INFO - 2018-05-10 08:34:52 --> Hooks Class Initialized
DEBUG - 2018-05-10 08:34:52 --> UTF-8 Support Enabled
INFO - 2018-05-10 08:34:52 --> Utf8 Class Initialized
INFO - 2018-05-10 08:34:52 --> URI Class Initialized
INFO - 2018-05-10 08:34:52 --> Router Class Initialized
INFO - 2018-05-10 08:34:52 --> Output Class Initialized
INFO - 2018-05-10 08:34:52 --> Security Class Initialized
DEBUG - 2018-05-10 08:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 08:34:52 --> Input Class Initialized
INFO - 2018-05-10 08:34:52 --> Language Class Initialized
INFO - 2018-05-10 08:34:52 --> Language Class Initialized
INFO - 2018-05-10 08:34:52 --> Config Class Initialized
INFO - 2018-05-10 08:34:52 --> Loader Class Initialized
INFO - 2018-05-10 14:04:52 --> Helper loaded: url_helper
INFO - 2018-05-10 14:04:52 --> Helper loaded: notification_helper
INFO - 2018-05-10 14:04:52 --> Helper loaded: settings_helper
INFO - 2018-05-10 14:04:52 --> Helper loaded: permission_helper
INFO - 2018-05-10 14:04:52 --> Helper loaded: users_helper
INFO - 2018-05-10 14:04:52 --> Database Driver Class Initialized
DEBUG - 2018-05-10 14:04:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 14:04:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 14:04:52 --> Helper loaded: form_helper
INFO - 2018-05-10 14:04:52 --> Form Validation Class Initialized
INFO - 2018-05-10 14:04:52 --> Controller Class Initialized
INFO - 2018-05-10 14:04:52 --> Model Class Initialized
INFO - 2018-05-10 14:04:52 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 14:04:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 14:04:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 14:04:52 --> Model Class Initialized
INFO - 2018-05-10 14:04:52 --> Model Class Initialized
INFO - 2018-05-10 14:04:52 --> Model Class Initialized
INFO - 2018-05-10 14:04:52 --> Model Class Initialized
INFO - 2018-05-10 14:04:52 --> Model Class Initialized
INFO - 2018-05-10 14:04:52 --> Model Class Initialized
INFO - 2018-05-10 14:04:52 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 14:04:52 --> Model Class Initialized
INFO - 2018-05-10 14:04:52 --> Final output sent to browser
DEBUG - 2018-05-10 14:04:52 --> Total execution time: 0.1147
INFO - 2018-05-10 08:35:00 --> Config Class Initialized
INFO - 2018-05-10 08:35:00 --> Hooks Class Initialized
DEBUG - 2018-05-10 08:35:00 --> UTF-8 Support Enabled
INFO - 2018-05-10 08:35:00 --> Utf8 Class Initialized
INFO - 2018-05-10 08:35:00 --> URI Class Initialized
INFO - 2018-05-10 08:35:00 --> Config Class Initialized
INFO - 2018-05-10 08:35:00 --> Hooks Class Initialized
INFO - 2018-05-10 08:35:00 --> Router Class Initialized
DEBUG - 2018-05-10 08:35:00 --> UTF-8 Support Enabled
INFO - 2018-05-10 08:35:00 --> Utf8 Class Initialized
INFO - 2018-05-10 08:35:00 --> Output Class Initialized
INFO - 2018-05-10 08:35:00 --> URI Class Initialized
INFO - 2018-05-10 08:35:00 --> Security Class Initialized
DEBUG - 2018-05-10 08:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 08:35:00 --> Input Class Initialized
INFO - 2018-05-10 08:35:00 --> Router Class Initialized
INFO - 2018-05-10 08:35:00 --> Language Class Initialized
INFO - 2018-05-10 08:35:00 --> Output Class Initialized
INFO - 2018-05-10 08:35:00 --> Security Class Initialized
DEBUG - 2018-05-10 08:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 08:35:00 --> Input Class Initialized
INFO - 2018-05-10 08:35:00 --> Language Class Initialized
INFO - 2018-05-10 08:35:00 --> Language Class Initialized
INFO - 2018-05-10 08:35:00 --> Config Class Initialized
INFO - 2018-05-10 08:35:00 --> Loader Class Initialized
INFO - 2018-05-10 14:05:00 --> Helper loaded: url_helper
INFO - 2018-05-10 14:05:00 --> Helper loaded: notification_helper
INFO - 2018-05-10 14:05:00 --> Helper loaded: settings_helper
INFO - 2018-05-10 14:05:00 --> Helper loaded: permission_helper
INFO - 2018-05-10 14:05:00 --> Helper loaded: users_helper
INFO - 2018-05-10 14:05:00 --> Database Driver Class Initialized
INFO - 2018-05-10 08:35:00 --> Language Class Initialized
INFO - 2018-05-10 08:35:00 --> Config Class Initialized
INFO - 2018-05-10 08:35:00 --> Loader Class Initialized
INFO - 2018-05-10 14:05:00 --> Helper loaded: url_helper
INFO - 2018-05-10 14:05:00 --> Helper loaded: notification_helper
INFO - 2018-05-10 14:05:00 --> Helper loaded: settings_helper
INFO - 2018-05-10 14:05:00 --> Helper loaded: permission_helper
INFO - 2018-05-10 14:05:00 --> Helper loaded: users_helper
DEBUG - 2018-05-10 14:05:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 14:05:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 14:05:00 --> Helper loaded: form_helper
INFO - 2018-05-10 14:05:00 --> Form Validation Class Initialized
INFO - 2018-05-10 14:05:00 --> Controller Class Initialized
INFO - 2018-05-10 14:05:00 --> Database Driver Class Initialized
DEBUG - 2018-05-10 14:05:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 14:05:00 --> Model Class Initialized
INFO - 2018-05-10 14:05:00 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 14:05:00 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 14:05:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 14:05:00 --> Model Class Initialized
INFO - 2018-05-10 14:05:00 --> Model Class Initialized
INFO - 2018-05-10 14:05:00 --> Model Class Initialized
INFO - 2018-05-10 14:05:00 --> Model Class Initialized
INFO - 2018-05-10 14:05:00 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 14:05:00 --> Final output sent to browser
DEBUG - 2018-05-10 14:05:00 --> Total execution time: 0.1165
INFO - 2018-05-10 14:05:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 14:05:00 --> Helper loaded: form_helper
INFO - 2018-05-10 14:05:00 --> Form Validation Class Initialized
INFO - 2018-05-10 14:05:00 --> Controller Class Initialized
INFO - 2018-05-10 14:05:00 --> Model Class Initialized
INFO - 2018-05-10 14:05:00 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 14:05:00 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 14:05:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 14:05:00 --> Model Class Initialized
INFO - 2018-05-10 14:05:00 --> Model Class Initialized
INFO - 2018-05-10 14:05:00 --> Model Class Initialized
INFO - 2018-05-10 14:05:00 --> Model Class Initialized
INFO - 2018-05-10 14:05:00 --> Model Class Initialized
INFO - 2018-05-10 14:05:00 --> Model Class Initialized
INFO - 2018-05-10 14:05:00 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 14:05:00 --> Final output sent to browser
DEBUG - 2018-05-10 14:05:00 --> Total execution time: 0.1417
INFO - 2018-05-10 08:37:30 --> Config Class Initialized
INFO - 2018-05-10 08:37:30 --> Hooks Class Initialized
DEBUG - 2018-05-10 08:37:30 --> UTF-8 Support Enabled
INFO - 2018-05-10 08:37:30 --> Utf8 Class Initialized
INFO - 2018-05-10 08:37:30 --> URI Class Initialized
INFO - 2018-05-10 08:37:30 --> Router Class Initialized
INFO - 2018-05-10 08:37:30 --> Output Class Initialized
INFO - 2018-05-10 08:37:30 --> Security Class Initialized
DEBUG - 2018-05-10 08:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 08:37:30 --> Input Class Initialized
INFO - 2018-05-10 08:37:30 --> Language Class Initialized
INFO - 2018-05-10 08:37:30 --> Language Class Initialized
INFO - 2018-05-10 08:37:30 --> Config Class Initialized
INFO - 2018-05-10 08:37:30 --> Loader Class Initialized
INFO - 2018-05-10 14:07:30 --> Helper loaded: url_helper
INFO - 2018-05-10 14:07:30 --> Helper loaded: notification_helper
INFO - 2018-05-10 14:07:30 --> Helper loaded: settings_helper
INFO - 2018-05-10 14:07:30 --> Helper loaded: permission_helper
INFO - 2018-05-10 14:07:30 --> Helper loaded: users_helper
INFO - 2018-05-10 14:07:30 --> Database Driver Class Initialized
DEBUG - 2018-05-10 14:07:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 14:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 14:07:30 --> Helper loaded: form_helper
INFO - 2018-05-10 14:07:30 --> Form Validation Class Initialized
INFO - 2018-05-10 14:07:30 --> Controller Class Initialized
INFO - 2018-05-10 14:07:31 --> Model Class Initialized
INFO - 2018-05-10 14:07:31 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 14:07:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 14:07:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 14:07:31 --> Model Class Initialized
INFO - 2018-05-10 14:07:31 --> Model Class Initialized
INFO - 2018-05-10 14:07:31 --> Model Class Initialized
INFO - 2018-05-10 14:07:31 --> Model Class Initialized
INFO - 2018-05-10 14:07:31 --> Model Class Initialized
INFO - 2018-05-10 14:07:31 --> Model Class Initialized
INFO - 2018-05-10 14:07:31 --> Model Class Initialized
INFO - 2018-05-10 14:07:31 --> Model Class Initialized
INFO - 2018-05-10 14:07:31 --> Model Class Initialized
INFO - 2018-05-10 14:07:31 --> Model Class Initialized
INFO - 2018-05-10 14:07:31 --> Model Class Initialized
INFO - 2018-05-10 14:07:31 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 14:07:31 --> Model Class Initialized
INFO - 2018-05-10 14:07:31 --> Final output sent to browser
DEBUG - 2018-05-10 14:07:31 --> Total execution time: 0.1242
INFO - 2018-05-10 08:37:31 --> Config Class Initialized
INFO - 2018-05-10 08:37:31 --> Hooks Class Initialized
DEBUG - 2018-05-10 08:37:31 --> UTF-8 Support Enabled
INFO - 2018-05-10 08:37:31 --> Utf8 Class Initialized
INFO - 2018-05-10 08:37:31 --> URI Class Initialized
INFO - 2018-05-10 08:37:31 --> Router Class Initialized
INFO - 2018-05-10 08:37:31 --> Output Class Initialized
INFO - 2018-05-10 08:37:31 --> Security Class Initialized
DEBUG - 2018-05-10 08:37:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 08:37:31 --> Input Class Initialized
INFO - 2018-05-10 08:37:31 --> Language Class Initialized
INFO - 2018-05-10 08:37:31 --> Language Class Initialized
INFO - 2018-05-10 08:37:31 --> Config Class Initialized
INFO - 2018-05-10 08:37:31 --> Loader Class Initialized
INFO - 2018-05-10 14:07:31 --> Helper loaded: url_helper
INFO - 2018-05-10 14:07:31 --> Helper loaded: notification_helper
INFO - 2018-05-10 14:07:31 --> Helper loaded: settings_helper
INFO - 2018-05-10 14:07:31 --> Helper loaded: permission_helper
INFO - 2018-05-10 14:07:31 --> Helper loaded: users_helper
INFO - 2018-05-10 14:07:31 --> Database Driver Class Initialized
DEBUG - 2018-05-10 14:07:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 14:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 14:07:31 --> Helper loaded: form_helper
INFO - 2018-05-10 14:07:31 --> Form Validation Class Initialized
INFO - 2018-05-10 14:07:31 --> Controller Class Initialized
INFO - 2018-05-10 14:07:31 --> Model Class Initialized
INFO - 2018-05-10 14:07:31 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 14:07:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 14:07:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 14:07:31 --> Model Class Initialized
INFO - 2018-05-10 14:07:31 --> Model Class Initialized
INFO - 2018-05-10 14:07:31 --> Model Class Initialized
INFO - 2018-05-10 14:07:31 --> Model Class Initialized
INFO - 2018-05-10 14:07:31 --> Model Class Initialized
INFO - 2018-05-10 14:07:31 --> Model Class Initialized
INFO - 2018-05-10 14:07:31 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 14:07:31 --> Model Class Initialized
INFO - 2018-05-10 14:07:31 --> Final output sent to browser
DEBUG - 2018-05-10 14:07:31 --> Total execution time: 0.1108
INFO - 2018-05-10 08:37:35 --> Config Class Initialized
INFO - 2018-05-10 08:37:35 --> Hooks Class Initialized
DEBUG - 2018-05-10 08:37:35 --> UTF-8 Support Enabled
INFO - 2018-05-10 08:37:35 --> Utf8 Class Initialized
INFO - 2018-05-10 08:37:35 --> URI Class Initialized
INFO - 2018-05-10 08:37:35 --> Router Class Initialized
INFO - 2018-05-10 08:37:35 --> Output Class Initialized
INFO - 2018-05-10 08:37:35 --> Security Class Initialized
DEBUG - 2018-05-10 08:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 08:37:35 --> Input Class Initialized
INFO - 2018-05-10 08:37:35 --> Language Class Initialized
INFO - 2018-05-10 08:37:35 --> Language Class Initialized
INFO - 2018-05-10 08:37:35 --> Config Class Initialized
INFO - 2018-05-10 08:37:35 --> Loader Class Initialized
INFO - 2018-05-10 14:07:35 --> Helper loaded: url_helper
INFO - 2018-05-10 14:07:35 --> Helper loaded: notification_helper
INFO - 2018-05-10 14:07:35 --> Helper loaded: settings_helper
INFO - 2018-05-10 14:07:35 --> Helper loaded: permission_helper
INFO - 2018-05-10 08:37:35 --> Config Class Initialized
INFO - 2018-05-10 08:37:35 --> Hooks Class Initialized
INFO - 2018-05-10 14:07:35 --> Helper loaded: users_helper
DEBUG - 2018-05-10 08:37:35 --> UTF-8 Support Enabled
INFO - 2018-05-10 08:37:35 --> Utf8 Class Initialized
INFO - 2018-05-10 08:37:35 --> URI Class Initialized
INFO - 2018-05-10 08:37:35 --> Router Class Initialized
INFO - 2018-05-10 08:37:35 --> Output Class Initialized
INFO - 2018-05-10 14:07:35 --> Database Driver Class Initialized
INFO - 2018-05-10 08:37:35 --> Security Class Initialized
DEBUG - 2018-05-10 14:07:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 14:07:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-05-10 08:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 08:37:35 --> Input Class Initialized
INFO - 2018-05-10 08:37:35 --> Language Class Initialized
INFO - 2018-05-10 14:07:35 --> Helper loaded: form_helper
INFO - 2018-05-10 14:07:35 --> Form Validation Class Initialized
INFO - 2018-05-10 14:07:35 --> Controller Class Initialized
INFO - 2018-05-10 14:07:35 --> Model Class Initialized
INFO - 2018-05-10 14:07:35 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 14:07:35 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 14:07:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 14:07:35 --> Model Class Initialized
INFO - 2018-05-10 14:07:35 --> Model Class Initialized
INFO - 2018-05-10 14:07:35 --> Model Class Initialized
INFO - 2018-05-10 14:07:35 --> Model Class Initialized
INFO - 2018-05-10 14:07:35 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 14:07:35 --> Final output sent to browser
DEBUG - 2018-05-10 14:07:35 --> Total execution time: 0.1008
INFO - 2018-05-10 08:37:35 --> Language Class Initialized
INFO - 2018-05-10 08:37:35 --> Config Class Initialized
INFO - 2018-05-10 08:37:35 --> Loader Class Initialized
INFO - 2018-05-10 14:07:35 --> Helper loaded: url_helper
INFO - 2018-05-10 14:07:35 --> Helper loaded: notification_helper
INFO - 2018-05-10 14:07:35 --> Helper loaded: settings_helper
INFO - 2018-05-10 14:07:35 --> Helper loaded: permission_helper
INFO - 2018-05-10 14:07:35 --> Helper loaded: users_helper
INFO - 2018-05-10 14:07:35 --> Database Driver Class Initialized
DEBUG - 2018-05-10 14:07:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 14:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 14:07:35 --> Helper loaded: form_helper
INFO - 2018-05-10 14:07:35 --> Form Validation Class Initialized
INFO - 2018-05-10 14:07:35 --> Controller Class Initialized
INFO - 2018-05-10 14:07:35 --> Model Class Initialized
INFO - 2018-05-10 14:07:35 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 14:07:35 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 14:07:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 14:07:35 --> Model Class Initialized
INFO - 2018-05-10 14:07:35 --> Model Class Initialized
INFO - 2018-05-10 14:07:35 --> Model Class Initialized
INFO - 2018-05-10 14:07:35 --> Model Class Initialized
INFO - 2018-05-10 14:07:35 --> Model Class Initialized
INFO - 2018-05-10 14:07:35 --> Model Class Initialized
INFO - 2018-05-10 14:07:35 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 14:07:35 --> Final output sent to browser
DEBUG - 2018-05-10 14:07:35 --> Total execution time: 0.1800
INFO - 2018-05-10 08:49:25 --> Config Class Initialized
INFO - 2018-05-10 08:49:25 --> Hooks Class Initialized
DEBUG - 2018-05-10 08:49:25 --> UTF-8 Support Enabled
INFO - 2018-05-10 08:49:25 --> Utf8 Class Initialized
INFO - 2018-05-10 08:49:25 --> URI Class Initialized
INFO - 2018-05-10 08:49:25 --> Router Class Initialized
INFO - 2018-05-10 08:49:25 --> Output Class Initialized
INFO - 2018-05-10 08:49:25 --> Security Class Initialized
DEBUG - 2018-05-10 08:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 08:49:25 --> Input Class Initialized
INFO - 2018-05-10 08:49:25 --> Language Class Initialized
INFO - 2018-05-10 08:49:25 --> Language Class Initialized
INFO - 2018-05-10 08:49:25 --> Config Class Initialized
INFO - 2018-05-10 08:49:25 --> Loader Class Initialized
INFO - 2018-05-10 14:19:25 --> Helper loaded: url_helper
INFO - 2018-05-10 14:19:25 --> Helper loaded: notification_helper
INFO - 2018-05-10 14:19:25 --> Helper loaded: settings_helper
INFO - 2018-05-10 14:19:25 --> Helper loaded: permission_helper
INFO - 2018-05-10 14:19:25 --> Helper loaded: users_helper
INFO - 2018-05-10 14:19:25 --> Database Driver Class Initialized
DEBUG - 2018-05-10 14:19:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 14:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 14:19:25 --> Helper loaded: form_helper
INFO - 2018-05-10 14:19:25 --> Form Validation Class Initialized
INFO - 2018-05-10 14:19:25 --> Controller Class Initialized
INFO - 2018-05-10 14:19:25 --> Model Class Initialized
INFO - 2018-05-10 14:19:25 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 14:19:25 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 14:19:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 14:19:25 --> Model Class Initialized
INFO - 2018-05-10 14:19:25 --> Model Class Initialized
INFO - 2018-05-10 14:19:25 --> Model Class Initialized
INFO - 2018-05-10 14:19:25 --> Model Class Initialized
INFO - 2018-05-10 14:19:25 --> Model Class Initialized
INFO - 2018-05-10 14:19:25 --> Model Class Initialized
INFO - 2018-05-10 14:19:25 --> Model Class Initialized
INFO - 2018-05-10 14:19:25 --> Model Class Initialized
INFO - 2018-05-10 14:19:25 --> Model Class Initialized
INFO - 2018-05-10 14:19:25 --> Model Class Initialized
INFO - 2018-05-10 14:19:25 --> Model Class Initialized
INFO - 2018-05-10 14:19:25 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 14:19:25 --> Model Class Initialized
INFO - 2018-05-10 14:19:25 --> Final output sent to browser
DEBUG - 2018-05-10 14:19:25 --> Total execution time: 0.1235
INFO - 2018-05-10 08:49:26 --> Config Class Initialized
INFO - 2018-05-10 08:49:26 --> Hooks Class Initialized
DEBUG - 2018-05-10 08:49:26 --> UTF-8 Support Enabled
INFO - 2018-05-10 08:49:26 --> Utf8 Class Initialized
INFO - 2018-05-10 08:49:26 --> URI Class Initialized
INFO - 2018-05-10 08:49:26 --> Router Class Initialized
INFO - 2018-05-10 08:49:26 --> Output Class Initialized
INFO - 2018-05-10 08:49:26 --> Security Class Initialized
DEBUG - 2018-05-10 08:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 08:49:26 --> Input Class Initialized
INFO - 2018-05-10 08:49:26 --> Language Class Initialized
INFO - 2018-05-10 08:49:26 --> Language Class Initialized
INFO - 2018-05-10 08:49:26 --> Config Class Initialized
INFO - 2018-05-10 08:49:26 --> Loader Class Initialized
INFO - 2018-05-10 14:19:26 --> Helper loaded: url_helper
INFO - 2018-05-10 14:19:26 --> Helper loaded: notification_helper
INFO - 2018-05-10 14:19:26 --> Helper loaded: settings_helper
INFO - 2018-05-10 14:19:26 --> Helper loaded: permission_helper
INFO - 2018-05-10 14:19:26 --> Helper loaded: users_helper
INFO - 2018-05-10 14:19:26 --> Database Driver Class Initialized
DEBUG - 2018-05-10 14:19:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 14:19:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 14:19:26 --> Helper loaded: form_helper
INFO - 2018-05-10 14:19:26 --> Form Validation Class Initialized
INFO - 2018-05-10 14:19:26 --> Controller Class Initialized
INFO - 2018-05-10 14:19:26 --> Model Class Initialized
INFO - 2018-05-10 14:19:26 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 14:19:26 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 14:19:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 14:19:26 --> Model Class Initialized
INFO - 2018-05-10 14:19:26 --> Model Class Initialized
INFO - 2018-05-10 14:19:26 --> Model Class Initialized
INFO - 2018-05-10 14:19:26 --> Model Class Initialized
INFO - 2018-05-10 14:19:26 --> Model Class Initialized
INFO - 2018-05-10 14:19:26 --> Model Class Initialized
INFO - 2018-05-10 14:19:26 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 14:19:26 --> Model Class Initialized
INFO - 2018-05-10 14:19:26 --> Final output sent to browser
DEBUG - 2018-05-10 14:19:26 --> Total execution time: 0.1173
INFO - 2018-05-10 08:51:08 --> Config Class Initialized
INFO - 2018-05-10 08:51:08 --> Hooks Class Initialized
INFO - 2018-05-10 08:51:08 --> Config Class Initialized
INFO - 2018-05-10 08:51:08 --> Hooks Class Initialized
DEBUG - 2018-05-10 08:51:08 --> UTF-8 Support Enabled
INFO - 2018-05-10 08:51:08 --> Utf8 Class Initialized
DEBUG - 2018-05-10 08:51:08 --> UTF-8 Support Enabled
INFO - 2018-05-10 08:51:08 --> Utf8 Class Initialized
INFO - 2018-05-10 08:51:08 --> URI Class Initialized
INFO - 2018-05-10 08:51:08 --> URI Class Initialized
INFO - 2018-05-10 08:51:08 --> Router Class Initialized
INFO - 2018-05-10 08:51:08 --> Router Class Initialized
INFO - 2018-05-10 08:51:08 --> Output Class Initialized
INFO - 2018-05-10 08:51:08 --> Security Class Initialized
DEBUG - 2018-05-10 08:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 08:51:08 --> Input Class Initialized
INFO - 2018-05-10 08:51:08 --> Output Class Initialized
INFO - 2018-05-10 08:51:08 --> Language Class Initialized
INFO - 2018-05-10 08:51:08 --> Security Class Initialized
DEBUG - 2018-05-10 08:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 08:51:08 --> Input Class Initialized
INFO - 2018-05-10 08:51:08 --> Language Class Initialized
INFO - 2018-05-10 08:51:08 --> Language Class Initialized
INFO - 2018-05-10 08:51:08 --> Config Class Initialized
INFO - 2018-05-10 08:51:08 --> Loader Class Initialized
INFO - 2018-05-10 08:51:08 --> Language Class Initialized
INFO - 2018-05-10 08:51:08 --> Config Class Initialized
INFO - 2018-05-10 08:51:08 --> Loader Class Initialized
INFO - 2018-05-10 14:21:08 --> Helper loaded: url_helper
INFO - 2018-05-10 14:21:08 --> Helper loaded: url_helper
INFO - 2018-05-10 14:21:08 --> Helper loaded: notification_helper
INFO - 2018-05-10 14:21:08 --> Helper loaded: notification_helper
INFO - 2018-05-10 14:21:08 --> Helper loaded: settings_helper
INFO - 2018-05-10 14:21:08 --> Helper loaded: settings_helper
INFO - 2018-05-10 14:21:08 --> Helper loaded: permission_helper
INFO - 2018-05-10 14:21:08 --> Helper loaded: permission_helper
INFO - 2018-05-10 14:21:08 --> Helper loaded: users_helper
INFO - 2018-05-10 14:21:08 --> Helper loaded: users_helper
INFO - 2018-05-10 14:21:08 --> Database Driver Class Initialized
INFO - 2018-05-10 14:21:08 --> Database Driver Class Initialized
DEBUG - 2018-05-10 14:21:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 14:21:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-05-10 14:21:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 14:21:08 --> Helper loaded: form_helper
INFO - 2018-05-10 14:21:08 --> Form Validation Class Initialized
INFO - 2018-05-10 14:21:08 --> Controller Class Initialized
INFO - 2018-05-10 14:21:08 --> Model Class Initialized
INFO - 2018-05-10 14:21:08 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 14:21:08 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 14:21:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 14:21:08 --> Model Class Initialized
INFO - 2018-05-10 14:21:08 --> Model Class Initialized
INFO - 2018-05-10 14:21:08 --> Model Class Initialized
INFO - 2018-05-10 14:21:08 --> Model Class Initialized
INFO - 2018-05-10 14:21:08 --> Model Class Initialized
INFO - 2018-05-10 14:21:08 --> Model Class Initialized
INFO - 2018-05-10 14:21:08 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 14:21:08 --> Final output sent to browser
DEBUG - 2018-05-10 14:21:08 --> Total execution time: 0.0975
INFO - 2018-05-10 14:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 14:21:08 --> Helper loaded: form_helper
INFO - 2018-05-10 14:21:08 --> Form Validation Class Initialized
INFO - 2018-05-10 14:21:08 --> Controller Class Initialized
INFO - 2018-05-10 14:21:08 --> Model Class Initialized
INFO - 2018-05-10 14:21:08 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 14:21:08 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 14:21:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 14:21:08 --> Model Class Initialized
INFO - 2018-05-10 14:21:08 --> Model Class Initialized
INFO - 2018-05-10 14:21:08 --> Model Class Initialized
INFO - 2018-05-10 14:21:08 --> Model Class Initialized
INFO - 2018-05-10 14:21:08 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 14:21:08 --> Final output sent to browser
DEBUG - 2018-05-10 14:21:08 --> Total execution time: 0.1231
INFO - 2018-05-10 08:53:12 --> Config Class Initialized
INFO - 2018-05-10 08:53:12 --> Hooks Class Initialized
DEBUG - 2018-05-10 08:53:12 --> UTF-8 Support Enabled
INFO - 2018-05-10 08:53:12 --> Utf8 Class Initialized
INFO - 2018-05-10 08:53:12 --> URI Class Initialized
INFO - 2018-05-10 08:53:12 --> Router Class Initialized
INFO - 2018-05-10 08:53:12 --> Output Class Initialized
INFO - 2018-05-10 08:53:12 --> Security Class Initialized
DEBUG - 2018-05-10 08:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 08:53:12 --> Input Class Initialized
INFO - 2018-05-10 08:53:12 --> Language Class Initialized
INFO - 2018-05-10 08:53:12 --> Language Class Initialized
INFO - 2018-05-10 08:53:12 --> Config Class Initialized
INFO - 2018-05-10 08:53:12 --> Loader Class Initialized
INFO - 2018-05-10 14:23:12 --> Helper loaded: url_helper
INFO - 2018-05-10 14:23:12 --> Helper loaded: notification_helper
INFO - 2018-05-10 14:23:12 --> Helper loaded: settings_helper
INFO - 2018-05-10 14:23:12 --> Helper loaded: permission_helper
INFO - 2018-05-10 14:23:12 --> Helper loaded: users_helper
INFO - 2018-05-10 14:23:12 --> Database Driver Class Initialized
DEBUG - 2018-05-10 14:23:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 14:23:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 14:23:12 --> Helper loaded: form_helper
INFO - 2018-05-10 14:23:12 --> Form Validation Class Initialized
INFO - 2018-05-10 14:23:12 --> Controller Class Initialized
INFO - 2018-05-10 14:23:12 --> Model Class Initialized
INFO - 2018-05-10 14:23:12 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 14:23:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 14:23:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 14:23:12 --> Model Class Initialized
INFO - 2018-05-10 14:23:12 --> Model Class Initialized
INFO - 2018-05-10 14:23:12 --> Model Class Initialized
INFO - 2018-05-10 14:23:12 --> Model Class Initialized
INFO - 2018-05-10 14:23:12 --> Model Class Initialized
INFO - 2018-05-10 14:23:12 --> Model Class Initialized
INFO - 2018-05-10 14:23:12 --> Model Class Initialized
INFO - 2018-05-10 14:23:12 --> Model Class Initialized
INFO - 2018-05-10 14:23:12 --> Model Class Initialized
INFO - 2018-05-10 14:23:12 --> Model Class Initialized
INFO - 2018-05-10 14:23:12 --> Model Class Initialized
INFO - 2018-05-10 14:23:12 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 14:23:12 --> Model Class Initialized
INFO - 2018-05-10 14:23:12 --> Final output sent to browser
DEBUG - 2018-05-10 14:23:12 --> Total execution time: 0.1219
INFO - 2018-05-10 08:53:12 --> Config Class Initialized
INFO - 2018-05-10 08:53:12 --> Hooks Class Initialized
DEBUG - 2018-05-10 08:53:12 --> UTF-8 Support Enabled
INFO - 2018-05-10 08:53:12 --> Utf8 Class Initialized
INFO - 2018-05-10 08:53:12 --> URI Class Initialized
INFO - 2018-05-10 08:53:12 --> Router Class Initialized
INFO - 2018-05-10 08:53:12 --> Output Class Initialized
INFO - 2018-05-10 08:53:12 --> Security Class Initialized
DEBUG - 2018-05-10 08:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 08:53:12 --> Input Class Initialized
INFO - 2018-05-10 08:53:12 --> Language Class Initialized
INFO - 2018-05-10 08:53:12 --> Language Class Initialized
INFO - 2018-05-10 08:53:12 --> Config Class Initialized
INFO - 2018-05-10 08:53:12 --> Loader Class Initialized
INFO - 2018-05-10 14:23:13 --> Helper loaded: url_helper
INFO - 2018-05-10 14:23:13 --> Helper loaded: notification_helper
INFO - 2018-05-10 14:23:13 --> Helper loaded: settings_helper
INFO - 2018-05-10 14:23:13 --> Helper loaded: permission_helper
INFO - 2018-05-10 14:23:13 --> Helper loaded: users_helper
INFO - 2018-05-10 14:23:13 --> Database Driver Class Initialized
DEBUG - 2018-05-10 14:23:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 14:23:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 14:23:13 --> Helper loaded: form_helper
INFO - 2018-05-10 14:23:13 --> Form Validation Class Initialized
INFO - 2018-05-10 14:23:13 --> Controller Class Initialized
INFO - 2018-05-10 14:23:13 --> Model Class Initialized
INFO - 2018-05-10 14:23:13 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 14:23:13 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 14:23:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 14:23:13 --> Model Class Initialized
INFO - 2018-05-10 14:23:13 --> Model Class Initialized
INFO - 2018-05-10 14:23:13 --> Model Class Initialized
INFO - 2018-05-10 14:23:13 --> Model Class Initialized
INFO - 2018-05-10 14:23:13 --> Model Class Initialized
INFO - 2018-05-10 14:23:13 --> Model Class Initialized
INFO - 2018-05-10 14:23:13 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 14:23:13 --> Model Class Initialized
INFO - 2018-05-10 14:23:13 --> Final output sent to browser
DEBUG - 2018-05-10 14:23:13 --> Total execution time: 0.1082
INFO - 2018-05-10 08:53:16 --> Config Class Initialized
INFO - 2018-05-10 08:53:16 --> Hooks Class Initialized
DEBUG - 2018-05-10 08:53:16 --> UTF-8 Support Enabled
INFO - 2018-05-10 08:53:16 --> Utf8 Class Initialized
INFO - 2018-05-10 08:53:16 --> URI Class Initialized
INFO - 2018-05-10 08:53:16 --> Router Class Initialized
INFO - 2018-05-10 08:53:16 --> Output Class Initialized
INFO - 2018-05-10 08:53:16 --> Security Class Initialized
DEBUG - 2018-05-10 08:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 08:53:16 --> Input Class Initialized
INFO - 2018-05-10 08:53:16 --> Language Class Initialized
INFO - 2018-05-10 08:53:16 --> Config Class Initialized
INFO - 2018-05-10 08:53:16 --> Hooks Class Initialized
DEBUG - 2018-05-10 08:53:16 --> UTF-8 Support Enabled
INFO - 2018-05-10 08:53:16 --> Utf8 Class Initialized
INFO - 2018-05-10 08:53:16 --> URI Class Initialized
INFO - 2018-05-10 08:53:16 --> Language Class Initialized
INFO - 2018-05-10 08:53:16 --> Config Class Initialized
INFO - 2018-05-10 08:53:16 --> Loader Class Initialized
INFO - 2018-05-10 14:23:16 --> Helper loaded: url_helper
INFO - 2018-05-10 14:23:16 --> Helper loaded: notification_helper
INFO - 2018-05-10 14:23:16 --> Helper loaded: settings_helper
INFO - 2018-05-10 08:53:16 --> Router Class Initialized
INFO - 2018-05-10 14:23:16 --> Helper loaded: permission_helper
INFO - 2018-05-10 14:23:16 --> Helper loaded: users_helper
INFO - 2018-05-10 08:53:16 --> Output Class Initialized
INFO - 2018-05-10 08:53:16 --> Security Class Initialized
DEBUG - 2018-05-10 08:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 08:53:16 --> Input Class Initialized
INFO - 2018-05-10 08:53:16 --> Language Class Initialized
INFO - 2018-05-10 14:23:16 --> Database Driver Class Initialized
DEBUG - 2018-05-10 14:23:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 14:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 08:53:16 --> Language Class Initialized
INFO - 2018-05-10 08:53:16 --> Config Class Initialized
INFO - 2018-05-10 08:53:16 --> Loader Class Initialized
INFO - 2018-05-10 14:23:16 --> Helper loaded: url_helper
INFO - 2018-05-10 14:23:16 --> Helper loaded: notification_helper
INFO - 2018-05-10 14:23:16 --> Helper loaded: settings_helper
INFO - 2018-05-10 14:23:16 --> Helper loaded: permission_helper
INFO - 2018-05-10 14:23:16 --> Helper loaded: users_helper
INFO - 2018-05-10 14:23:16 --> Helper loaded: form_helper
INFO - 2018-05-10 14:23:16 --> Form Validation Class Initialized
INFO - 2018-05-10 14:23:16 --> Controller Class Initialized
INFO - 2018-05-10 14:23:16 --> Database Driver Class Initialized
DEBUG - 2018-05-10 14:23:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 14:23:16 --> Model Class Initialized
INFO - 2018-05-10 14:23:16 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 14:23:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 14:23:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 14:23:16 --> Model Class Initialized
INFO - 2018-05-10 14:23:16 --> Model Class Initialized
INFO - 2018-05-10 14:23:16 --> Model Class Initialized
INFO - 2018-05-10 14:23:16 --> Model Class Initialized
INFO - 2018-05-10 14:23:16 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 14:23:16 --> Final output sent to browser
DEBUG - 2018-05-10 14:23:16 --> Total execution time: 0.1708
INFO - 2018-05-10 14:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 14:23:16 --> Helper loaded: form_helper
INFO - 2018-05-10 14:23:16 --> Form Validation Class Initialized
INFO - 2018-05-10 14:23:16 --> Controller Class Initialized
INFO - 2018-05-10 14:23:16 --> Model Class Initialized
INFO - 2018-05-10 14:23:16 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 14:23:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 14:23:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 14:23:16 --> Model Class Initialized
INFO - 2018-05-10 14:23:16 --> Model Class Initialized
INFO - 2018-05-10 14:23:16 --> Model Class Initialized
INFO - 2018-05-10 14:23:16 --> Model Class Initialized
INFO - 2018-05-10 14:23:16 --> Model Class Initialized
INFO - 2018-05-10 14:23:16 --> Model Class Initialized
INFO - 2018-05-10 14:23:16 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 14:23:16 --> Final output sent to browser
DEBUG - 2018-05-10 14:23:16 --> Total execution time: 0.1839
INFO - 2018-05-10 09:48:01 --> Config Class Initialized
INFO - 2018-05-10 09:48:01 --> Hooks Class Initialized
DEBUG - 2018-05-10 09:48:01 --> UTF-8 Support Enabled
INFO - 2018-05-10 09:48:01 --> Utf8 Class Initialized
INFO - 2018-05-10 09:48:01 --> URI Class Initialized
INFO - 2018-05-10 09:48:01 --> Router Class Initialized
INFO - 2018-05-10 09:48:01 --> Output Class Initialized
INFO - 2018-05-10 09:48:01 --> Security Class Initialized
DEBUG - 2018-05-10 09:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 09:48:01 --> Input Class Initialized
INFO - 2018-05-10 09:48:01 --> Language Class Initialized
INFO - 2018-05-10 09:48:01 --> Language Class Initialized
INFO - 2018-05-10 09:48:01 --> Config Class Initialized
INFO - 2018-05-10 09:48:01 --> Loader Class Initialized
INFO - 2018-05-10 15:18:01 --> Helper loaded: url_helper
INFO - 2018-05-10 15:18:01 --> Helper loaded: notification_helper
INFO - 2018-05-10 15:18:01 --> Helper loaded: settings_helper
INFO - 2018-05-10 15:18:01 --> Helper loaded: permission_helper
INFO - 2018-05-10 15:18:01 --> Helper loaded: users_helper
INFO - 2018-05-10 15:18:01 --> Database Driver Class Initialized
DEBUG - 2018-05-10 15:18:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 15:18:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 15:18:01 --> Helper loaded: form_helper
INFO - 2018-05-10 15:18:01 --> Form Validation Class Initialized
INFO - 2018-05-10 15:18:01 --> Controller Class Initialized
INFO - 2018-05-10 15:18:01 --> Model Class Initialized
INFO - 2018-05-10 15:18:01 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 15:18:01 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 15:18:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 15:18:01 --> Model Class Initialized
INFO - 2018-05-10 15:18:01 --> Model Class Initialized
INFO - 2018-05-10 15:18:01 --> Model Class Initialized
INFO - 2018-05-10 15:18:01 --> Model Class Initialized
INFO - 2018-05-10 15:18:01 --> Model Class Initialized
INFO - 2018-05-10 15:18:01 --> Model Class Initialized
INFO - 2018-05-10 15:18:01 --> Model Class Initialized
INFO - 2018-05-10 15:18:01 --> Model Class Initialized
INFO - 2018-05-10 15:18:01 --> Model Class Initialized
INFO - 2018-05-10 15:18:01 --> Model Class Initialized
INFO - 2018-05-10 15:18:01 --> Model Class Initialized
INFO - 2018-05-10 15:18:01 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 15:18:01 --> Model Class Initialized
INFO - 2018-05-10 15:18:01 --> Final output sent to browser
DEBUG - 2018-05-10 15:18:01 --> Total execution time: 0.1289
INFO - 2018-05-10 09:48:02 --> Config Class Initialized
INFO - 2018-05-10 09:48:02 --> Hooks Class Initialized
DEBUG - 2018-05-10 09:48:02 --> UTF-8 Support Enabled
INFO - 2018-05-10 09:48:02 --> Utf8 Class Initialized
INFO - 2018-05-10 09:48:02 --> URI Class Initialized
INFO - 2018-05-10 09:48:02 --> Router Class Initialized
INFO - 2018-05-10 09:48:02 --> Output Class Initialized
INFO - 2018-05-10 09:48:02 --> Security Class Initialized
DEBUG - 2018-05-10 09:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 09:48:02 --> Input Class Initialized
INFO - 2018-05-10 09:48:02 --> Language Class Initialized
INFO - 2018-05-10 09:48:02 --> Language Class Initialized
INFO - 2018-05-10 09:48:02 --> Config Class Initialized
INFO - 2018-05-10 09:48:02 --> Loader Class Initialized
INFO - 2018-05-10 15:18:02 --> Helper loaded: url_helper
INFO - 2018-05-10 15:18:02 --> Helper loaded: notification_helper
INFO - 2018-05-10 15:18:02 --> Helper loaded: settings_helper
INFO - 2018-05-10 15:18:02 --> Helper loaded: permission_helper
INFO - 2018-05-10 15:18:02 --> Helper loaded: users_helper
INFO - 2018-05-10 15:18:02 --> Database Driver Class Initialized
DEBUG - 2018-05-10 15:18:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 15:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 15:18:02 --> Helper loaded: form_helper
INFO - 2018-05-10 15:18:02 --> Form Validation Class Initialized
INFO - 2018-05-10 15:18:02 --> Controller Class Initialized
INFO - 2018-05-10 15:18:02 --> Model Class Initialized
INFO - 2018-05-10 15:18:02 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 15:18:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 15:18:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 15:18:02 --> Model Class Initialized
INFO - 2018-05-10 15:18:02 --> Model Class Initialized
INFO - 2018-05-10 15:18:02 --> Model Class Initialized
INFO - 2018-05-10 15:18:02 --> Model Class Initialized
INFO - 2018-05-10 15:18:02 --> Model Class Initialized
INFO - 2018-05-10 15:18:02 --> Model Class Initialized
INFO - 2018-05-10 15:18:02 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 15:18:02 --> Model Class Initialized
INFO - 2018-05-10 15:18:02 --> Final output sent to browser
DEBUG - 2018-05-10 15:18:02 --> Total execution time: 0.1423
INFO - 2018-05-10 09:48:07 --> Config Class Initialized
INFO - 2018-05-10 09:48:07 --> Hooks Class Initialized
DEBUG - 2018-05-10 09:48:07 --> UTF-8 Support Enabled
INFO - 2018-05-10 09:48:07 --> Utf8 Class Initialized
INFO - 2018-05-10 09:48:07 --> URI Class Initialized
INFO - 2018-05-10 09:48:07 --> Router Class Initialized
INFO - 2018-05-10 09:48:07 --> Output Class Initialized
INFO - 2018-05-10 09:48:07 --> Security Class Initialized
DEBUG - 2018-05-10 09:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 09:48:07 --> Input Class Initialized
INFO - 2018-05-10 09:48:07 --> Language Class Initialized
INFO - 2018-05-10 09:48:07 --> Language Class Initialized
INFO - 2018-05-10 09:48:07 --> Config Class Initialized
INFO - 2018-05-10 09:48:07 --> Loader Class Initialized
INFO - 2018-05-10 15:18:07 --> Helper loaded: url_helper
INFO - 2018-05-10 15:18:07 --> Helper loaded: notification_helper
INFO - 2018-05-10 15:18:07 --> Helper loaded: settings_helper
INFO - 2018-05-10 15:18:07 --> Helper loaded: permission_helper
INFO - 2018-05-10 15:18:07 --> Helper loaded: users_helper
INFO - 2018-05-10 15:18:07 --> Database Driver Class Initialized
DEBUG - 2018-05-10 15:18:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 15:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 15:18:07 --> Helper loaded: form_helper
INFO - 2018-05-10 15:18:07 --> Form Validation Class Initialized
INFO - 2018-05-10 15:18:07 --> Controller Class Initialized
INFO - 2018-05-10 15:18:07 --> Model Class Initialized
INFO - 2018-05-10 15:18:07 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 15:18:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 15:18:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 15:18:07 --> Model Class Initialized
INFO - 2018-05-10 15:18:07 --> Model Class Initialized
INFO - 2018-05-10 15:18:07 --> Model Class Initialized
INFO - 2018-05-10 15:18:07 --> Model Class Initialized
INFO - 2018-05-10 15:18:07 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 15:18:07 --> Final output sent to browser
DEBUG - 2018-05-10 15:18:07 --> Total execution time: 0.1015
INFO - 2018-05-10 09:48:07 --> Config Class Initialized
INFO - 2018-05-10 09:48:07 --> Hooks Class Initialized
DEBUG - 2018-05-10 09:48:07 --> UTF-8 Support Enabled
INFO - 2018-05-10 09:48:07 --> Utf8 Class Initialized
INFO - 2018-05-10 09:48:07 --> URI Class Initialized
INFO - 2018-05-10 09:48:07 --> Router Class Initialized
INFO - 2018-05-10 09:48:07 --> Output Class Initialized
INFO - 2018-05-10 09:48:07 --> Security Class Initialized
DEBUG - 2018-05-10 09:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 09:48:07 --> Input Class Initialized
INFO - 2018-05-10 09:48:07 --> Language Class Initialized
INFO - 2018-05-10 09:48:07 --> Language Class Initialized
INFO - 2018-05-10 09:48:07 --> Config Class Initialized
INFO - 2018-05-10 09:48:07 --> Loader Class Initialized
INFO - 2018-05-10 15:18:07 --> Helper loaded: url_helper
INFO - 2018-05-10 15:18:07 --> Helper loaded: notification_helper
INFO - 2018-05-10 15:18:07 --> Helper loaded: settings_helper
INFO - 2018-05-10 15:18:07 --> Helper loaded: permission_helper
INFO - 2018-05-10 15:18:07 --> Helper loaded: users_helper
INFO - 2018-05-10 15:18:07 --> Database Driver Class Initialized
DEBUG - 2018-05-10 15:18:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 15:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 15:18:07 --> Helper loaded: form_helper
INFO - 2018-05-10 15:18:07 --> Form Validation Class Initialized
INFO - 2018-05-10 15:18:07 --> Controller Class Initialized
INFO - 2018-05-10 15:18:07 --> Model Class Initialized
INFO - 2018-05-10 15:18:07 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 15:18:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 15:18:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 15:18:07 --> Model Class Initialized
INFO - 2018-05-10 15:18:07 --> Model Class Initialized
INFO - 2018-05-10 15:18:07 --> Model Class Initialized
INFO - 2018-05-10 15:18:07 --> Model Class Initialized
INFO - 2018-05-10 15:18:07 --> Model Class Initialized
INFO - 2018-05-10 15:18:07 --> Model Class Initialized
INFO - 2018-05-10 15:18:07 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 15:18:07 --> Final output sent to browser
DEBUG - 2018-05-10 15:18:07 --> Total execution time: 0.1241
INFO - 2018-05-10 09:48:15 --> Config Class Initialized
INFO - 2018-05-10 09:48:15 --> Hooks Class Initialized
DEBUG - 2018-05-10 09:48:15 --> UTF-8 Support Enabled
INFO - 2018-05-10 09:48:15 --> Utf8 Class Initialized
INFO - 2018-05-10 09:48:15 --> URI Class Initialized
INFO - 2018-05-10 09:48:15 --> Router Class Initialized
INFO - 2018-05-10 09:48:15 --> Output Class Initialized
INFO - 2018-05-10 09:48:15 --> Security Class Initialized
DEBUG - 2018-05-10 09:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 09:48:15 --> Input Class Initialized
INFO - 2018-05-10 09:48:15 --> Language Class Initialized
INFO - 2018-05-10 09:48:15 --> Language Class Initialized
INFO - 2018-05-10 09:48:15 --> Config Class Initialized
INFO - 2018-05-10 09:48:15 --> Loader Class Initialized
INFO - 2018-05-10 15:18:15 --> Helper loaded: url_helper
INFO - 2018-05-10 15:18:15 --> Helper loaded: notification_helper
INFO - 2018-05-10 15:18:15 --> Helper loaded: settings_helper
INFO - 2018-05-10 15:18:15 --> Helper loaded: permission_helper
INFO - 2018-05-10 15:18:15 --> Helper loaded: users_helper
INFO - 2018-05-10 15:18:15 --> Database Driver Class Initialized
DEBUG - 2018-05-10 15:18:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 15:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 15:18:15 --> Helper loaded: form_helper
INFO - 2018-05-10 15:18:15 --> Form Validation Class Initialized
INFO - 2018-05-10 15:18:15 --> Controller Class Initialized
INFO - 2018-05-10 15:18:15 --> Model Class Initialized
INFO - 2018-05-10 15:18:15 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 15:18:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 15:18:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 15:18:15 --> Model Class Initialized
INFO - 2018-05-10 15:18:15 --> Model Class Initialized
INFO - 2018-05-10 15:18:15 --> Model Class Initialized
INFO - 2018-05-10 15:18:15 --> Model Class Initialized
INFO - 2018-05-10 15:18:15 --> Model Class Initialized
INFO - 2018-05-10 15:18:15 --> Model Class Initialized
INFO - 2018-05-10 15:18:15 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 15:18:15 --> Final output sent to browser
DEBUG - 2018-05-10 15:18:15 --> Total execution time: 0.0752
INFO - 2018-05-10 09:51:39 --> Config Class Initialized
INFO - 2018-05-10 09:51:39 --> Hooks Class Initialized
DEBUG - 2018-05-10 09:51:39 --> UTF-8 Support Enabled
INFO - 2018-05-10 09:51:39 --> Utf8 Class Initialized
INFO - 2018-05-10 09:51:39 --> URI Class Initialized
INFO - 2018-05-10 09:51:39 --> Router Class Initialized
INFO - 2018-05-10 09:51:39 --> Output Class Initialized
INFO - 2018-05-10 09:51:39 --> Security Class Initialized
DEBUG - 2018-05-10 09:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 09:51:39 --> Input Class Initialized
INFO - 2018-05-10 09:51:39 --> Language Class Initialized
INFO - 2018-05-10 09:51:39 --> Language Class Initialized
INFO - 2018-05-10 09:51:39 --> Config Class Initialized
INFO - 2018-05-10 09:51:39 --> Loader Class Initialized
INFO - 2018-05-10 15:21:39 --> Helper loaded: url_helper
INFO - 2018-05-10 15:21:39 --> Helper loaded: notification_helper
INFO - 2018-05-10 15:21:39 --> Helper loaded: settings_helper
INFO - 2018-05-10 15:21:39 --> Helper loaded: permission_helper
INFO - 2018-05-10 15:21:39 --> Helper loaded: users_helper
INFO - 2018-05-10 15:21:39 --> Database Driver Class Initialized
DEBUG - 2018-05-10 15:21:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 15:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 15:21:39 --> Helper loaded: form_helper
INFO - 2018-05-10 15:21:39 --> Form Validation Class Initialized
INFO - 2018-05-10 15:21:39 --> Controller Class Initialized
INFO - 2018-05-10 15:21:39 --> Model Class Initialized
INFO - 2018-05-10 15:21:39 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 15:21:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 15:21:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 15:21:39 --> Model Class Initialized
INFO - 2018-05-10 15:21:39 --> Model Class Initialized
INFO - 2018-05-10 15:21:39 --> Model Class Initialized
INFO - 2018-05-10 15:21:39 --> Model Class Initialized
INFO - 2018-05-10 15:21:39 --> Model Class Initialized
INFO - 2018-05-10 15:21:39 --> Model Class Initialized
INFO - 2018-05-10 15:21:39 --> Model Class Initialized
INFO - 2018-05-10 15:21:39 --> Model Class Initialized
INFO - 2018-05-10 15:21:39 --> Model Class Initialized
INFO - 2018-05-10 15:21:39 --> Model Class Initialized
INFO - 2018-05-10 15:21:39 --> Model Class Initialized
INFO - 2018-05-10 15:21:39 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 15:21:39 --> Final output sent to browser
DEBUG - 2018-05-10 15:21:39 --> Total execution time: 0.1476
INFO - 2018-05-10 09:51:40 --> Config Class Initialized
INFO - 2018-05-10 09:51:40 --> Hooks Class Initialized
DEBUG - 2018-05-10 09:51:40 --> UTF-8 Support Enabled
INFO - 2018-05-10 09:51:40 --> Utf8 Class Initialized
INFO - 2018-05-10 09:51:40 --> URI Class Initialized
INFO - 2018-05-10 09:51:40 --> Router Class Initialized
INFO - 2018-05-10 09:51:40 --> Output Class Initialized
INFO - 2018-05-10 09:51:40 --> Security Class Initialized
DEBUG - 2018-05-10 09:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 09:51:40 --> Input Class Initialized
INFO - 2018-05-10 09:51:40 --> Language Class Initialized
INFO - 2018-05-10 09:51:40 --> Language Class Initialized
INFO - 2018-05-10 09:51:40 --> Config Class Initialized
INFO - 2018-05-10 09:51:40 --> Loader Class Initialized
INFO - 2018-05-10 15:21:40 --> Helper loaded: url_helper
INFO - 2018-05-10 15:21:40 --> Helper loaded: notification_helper
INFO - 2018-05-10 15:21:40 --> Helper loaded: settings_helper
INFO - 2018-05-10 15:21:40 --> Helper loaded: permission_helper
INFO - 2018-05-10 15:21:40 --> Helper loaded: users_helper
INFO - 2018-05-10 15:21:40 --> Database Driver Class Initialized
DEBUG - 2018-05-10 15:21:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 15:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 15:21:40 --> Helper loaded: form_helper
INFO - 2018-05-10 15:21:40 --> Form Validation Class Initialized
INFO - 2018-05-10 15:21:40 --> Controller Class Initialized
DEBUG - 2018-05-10 15:21:40 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-05-10 15:21:40 --> Final output sent to browser
DEBUG - 2018-05-10 15:21:40 --> Total execution time: 0.0715
INFO - 2018-05-10 09:53:39 --> Config Class Initialized
INFO - 2018-05-10 09:53:39 --> Hooks Class Initialized
DEBUG - 2018-05-10 09:53:39 --> UTF-8 Support Enabled
INFO - 2018-05-10 09:53:39 --> Utf8 Class Initialized
INFO - 2018-05-10 09:53:39 --> URI Class Initialized
INFO - 2018-05-10 09:53:39 --> Router Class Initialized
INFO - 2018-05-10 09:53:39 --> Output Class Initialized
INFO - 2018-05-10 09:53:39 --> Security Class Initialized
DEBUG - 2018-05-10 09:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 09:53:39 --> Input Class Initialized
INFO - 2018-05-10 09:53:39 --> Language Class Initialized
INFO - 2018-05-10 09:53:39 --> Language Class Initialized
INFO - 2018-05-10 09:53:39 --> Config Class Initialized
INFO - 2018-05-10 09:53:39 --> Loader Class Initialized
INFO - 2018-05-10 15:23:39 --> Helper loaded: url_helper
INFO - 2018-05-10 15:23:39 --> Helper loaded: notification_helper
INFO - 2018-05-10 15:23:39 --> Helper loaded: settings_helper
INFO - 2018-05-10 15:23:39 --> Helper loaded: permission_helper
INFO - 2018-05-10 15:23:39 --> Helper loaded: users_helper
INFO - 2018-05-10 15:23:39 --> Database Driver Class Initialized
DEBUG - 2018-05-10 15:23:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 15:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 15:23:39 --> Helper loaded: form_helper
INFO - 2018-05-10 15:23:39 --> Form Validation Class Initialized
INFO - 2018-05-10 15:23:39 --> Controller Class Initialized
INFO - 2018-05-10 15:23:39 --> Model Class Initialized
INFO - 2018-05-10 15:23:39 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 15:23:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 15:23:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 15:23:39 --> Model Class Initialized
INFO - 2018-05-10 15:23:39 --> Model Class Initialized
INFO - 2018-05-10 15:23:39 --> Model Class Initialized
INFO - 2018-05-10 15:23:39 --> Model Class Initialized
INFO - 2018-05-10 15:23:39 --> Model Class Initialized
INFO - 2018-05-10 15:23:39 --> Model Class Initialized
INFO - 2018-05-10 15:23:39 --> Model Class Initialized
INFO - 2018-05-10 15:23:39 --> Model Class Initialized
INFO - 2018-05-10 15:23:39 --> Model Class Initialized
INFO - 2018-05-10 15:23:39 --> Model Class Initialized
INFO - 2018-05-10 15:23:39 --> Model Class Initialized
INFO - 2018-05-10 15:23:39 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 15:23:39 --> Model Class Initialized
INFO - 2018-05-10 15:23:39 --> Final output sent to browser
DEBUG - 2018-05-10 15:23:39 --> Total execution time: 0.1666
INFO - 2018-05-10 09:53:39 --> Config Class Initialized
INFO - 2018-05-10 09:53:39 --> Hooks Class Initialized
DEBUG - 2018-05-10 09:53:39 --> UTF-8 Support Enabled
INFO - 2018-05-10 09:53:39 --> Utf8 Class Initialized
INFO - 2018-05-10 09:53:39 --> URI Class Initialized
INFO - 2018-05-10 09:53:39 --> Router Class Initialized
INFO - 2018-05-10 09:53:39 --> Output Class Initialized
INFO - 2018-05-10 09:53:39 --> Security Class Initialized
DEBUG - 2018-05-10 09:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 09:53:39 --> Input Class Initialized
INFO - 2018-05-10 09:53:39 --> Language Class Initialized
INFO - 2018-05-10 09:53:39 --> Language Class Initialized
INFO - 2018-05-10 09:53:39 --> Config Class Initialized
INFO - 2018-05-10 09:53:39 --> Loader Class Initialized
INFO - 2018-05-10 15:23:39 --> Helper loaded: url_helper
INFO - 2018-05-10 15:23:39 --> Helper loaded: notification_helper
INFO - 2018-05-10 15:23:39 --> Helper loaded: settings_helper
INFO - 2018-05-10 15:23:39 --> Helper loaded: permission_helper
INFO - 2018-05-10 15:23:39 --> Helper loaded: users_helper
INFO - 2018-05-10 15:23:39 --> Database Driver Class Initialized
DEBUG - 2018-05-10 15:23:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 15:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 15:23:39 --> Helper loaded: form_helper
INFO - 2018-05-10 15:23:39 --> Form Validation Class Initialized
INFO - 2018-05-10 15:23:39 --> Controller Class Initialized
INFO - 2018-05-10 15:23:39 --> Model Class Initialized
INFO - 2018-05-10 15:23:39 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 15:23:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 15:23:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 15:23:39 --> Model Class Initialized
INFO - 2018-05-10 15:23:39 --> Model Class Initialized
INFO - 2018-05-10 15:23:39 --> Model Class Initialized
INFO - 2018-05-10 15:23:39 --> Model Class Initialized
INFO - 2018-05-10 15:23:39 --> Model Class Initialized
INFO - 2018-05-10 15:23:39 --> Model Class Initialized
INFO - 2018-05-10 15:23:39 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 15:23:39 --> Model Class Initialized
INFO - 2018-05-10 15:23:39 --> Final output sent to browser
DEBUG - 2018-05-10 15:23:39 --> Total execution time: 0.1068
INFO - 2018-05-10 09:53:57 --> Config Class Initialized
INFO - 2018-05-10 09:53:57 --> Hooks Class Initialized
INFO - 2018-05-10 09:53:57 --> Config Class Initialized
INFO - 2018-05-10 09:53:57 --> Hooks Class Initialized
DEBUG - 2018-05-10 09:53:57 --> UTF-8 Support Enabled
INFO - 2018-05-10 09:53:57 --> Utf8 Class Initialized
INFO - 2018-05-10 09:53:57 --> URI Class Initialized
DEBUG - 2018-05-10 09:53:57 --> UTF-8 Support Enabled
INFO - 2018-05-10 09:53:57 --> Utf8 Class Initialized
INFO - 2018-05-10 09:53:57 --> Router Class Initialized
INFO - 2018-05-10 09:53:57 --> URI Class Initialized
INFO - 2018-05-10 09:53:57 --> Router Class Initialized
INFO - 2018-05-10 09:53:57 --> Output Class Initialized
INFO - 2018-05-10 09:53:57 --> Security Class Initialized
INFO - 2018-05-10 09:53:57 --> Output Class Initialized
DEBUG - 2018-05-10 09:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 09:53:57 --> Input Class Initialized
INFO - 2018-05-10 09:53:57 --> Language Class Initialized
INFO - 2018-05-10 09:53:57 --> Security Class Initialized
DEBUG - 2018-05-10 09:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 09:53:57 --> Input Class Initialized
INFO - 2018-05-10 09:53:57 --> Language Class Initialized
INFO - 2018-05-10 09:53:57 --> Language Class Initialized
INFO - 2018-05-10 09:53:57 --> Config Class Initialized
INFO - 2018-05-10 09:53:57 --> Loader Class Initialized
INFO - 2018-05-10 09:53:57 --> Language Class Initialized
INFO - 2018-05-10 09:53:57 --> Config Class Initialized
INFO - 2018-05-10 09:53:57 --> Loader Class Initialized
INFO - 2018-05-10 15:23:57 --> Helper loaded: url_helper
INFO - 2018-05-10 15:23:57 --> Helper loaded: url_helper
INFO - 2018-05-10 15:23:57 --> Helper loaded: notification_helper
INFO - 2018-05-10 15:23:57 --> Helper loaded: settings_helper
INFO - 2018-05-10 15:23:57 --> Helper loaded: permission_helper
INFO - 2018-05-10 15:23:57 --> Helper loaded: notification_helper
INFO - 2018-05-10 15:23:57 --> Helper loaded: settings_helper
INFO - 2018-05-10 15:23:57 --> Helper loaded: permission_helper
INFO - 2018-05-10 15:23:57 --> Helper loaded: users_helper
INFO - 2018-05-10 15:23:57 --> Helper loaded: users_helper
INFO - 2018-05-10 15:23:57 --> Database Driver Class Initialized
DEBUG - 2018-05-10 15:23:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 15:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 15:23:57 --> Helper loaded: form_helper
INFO - 2018-05-10 15:23:57 --> Database Driver Class Initialized
INFO - 2018-05-10 15:23:57 --> Form Validation Class Initialized
INFO - 2018-05-10 15:23:57 --> Controller Class Initialized
DEBUG - 2018-05-10 15:23:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 15:23:57 --> Model Class Initialized
INFO - 2018-05-10 15:23:57 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 15:23:57 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 15:23:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 15:23:57 --> Model Class Initialized
INFO - 2018-05-10 15:23:57 --> Model Class Initialized
INFO - 2018-05-10 15:23:57 --> Model Class Initialized
INFO - 2018-05-10 15:23:57 --> Model Class Initialized
INFO - 2018-05-10 15:23:57 --> Model Class Initialized
INFO - 2018-05-10 15:23:57 --> Model Class Initialized
INFO - 2018-05-10 15:23:57 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 15:23:57 --> Final output sent to browser
DEBUG - 2018-05-10 15:23:57 --> Total execution time: 0.1795
INFO - 2018-05-10 15:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 15:23:57 --> Helper loaded: form_helper
INFO - 2018-05-10 15:23:57 --> Form Validation Class Initialized
INFO - 2018-05-10 15:23:57 --> Controller Class Initialized
INFO - 2018-05-10 15:23:57 --> Model Class Initialized
INFO - 2018-05-10 15:23:57 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 15:23:57 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 15:23:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 15:23:57 --> Model Class Initialized
INFO - 2018-05-10 15:23:57 --> Model Class Initialized
INFO - 2018-05-10 15:23:57 --> Model Class Initialized
INFO - 2018-05-10 15:23:57 --> Model Class Initialized
INFO - 2018-05-10 15:23:57 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 15:23:57 --> Final output sent to browser
DEBUG - 2018-05-10 15:23:57 --> Total execution time: 0.2114
INFO - 2018-05-10 09:54:20 --> Config Class Initialized
INFO - 2018-05-10 09:54:20 --> Hooks Class Initialized
DEBUG - 2018-05-10 09:54:20 --> UTF-8 Support Enabled
INFO - 2018-05-10 09:54:20 --> Utf8 Class Initialized
INFO - 2018-05-10 09:54:20 --> URI Class Initialized
INFO - 2018-05-10 09:54:20 --> Router Class Initialized
INFO - 2018-05-10 09:54:20 --> Output Class Initialized
INFO - 2018-05-10 09:54:20 --> Security Class Initialized
DEBUG - 2018-05-10 09:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 09:54:20 --> Input Class Initialized
INFO - 2018-05-10 09:54:20 --> Language Class Initialized
INFO - 2018-05-10 09:54:20 --> Language Class Initialized
INFO - 2018-05-10 09:54:20 --> Config Class Initialized
INFO - 2018-05-10 09:54:20 --> Loader Class Initialized
INFO - 2018-05-10 15:24:20 --> Helper loaded: url_helper
INFO - 2018-05-10 15:24:20 --> Helper loaded: notification_helper
INFO - 2018-05-10 15:24:20 --> Helper loaded: settings_helper
INFO - 2018-05-10 15:24:20 --> Helper loaded: permission_helper
INFO - 2018-05-10 15:24:20 --> Helper loaded: users_helper
INFO - 2018-05-10 15:24:20 --> Database Driver Class Initialized
DEBUG - 2018-05-10 15:24:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 15:24:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 15:24:20 --> Helper loaded: form_helper
INFO - 2018-05-10 15:24:20 --> Form Validation Class Initialized
INFO - 2018-05-10 15:24:20 --> Controller Class Initialized
INFO - 2018-05-10 15:24:20 --> Model Class Initialized
INFO - 2018-05-10 15:24:20 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 15:24:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 15:24:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 15:24:20 --> Model Class Initialized
INFO - 2018-05-10 15:24:20 --> Model Class Initialized
INFO - 2018-05-10 15:24:20 --> Model Class Initialized
INFO - 2018-05-10 15:24:20 --> Model Class Initialized
INFO - 2018-05-10 15:24:20 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 15:24:20 --> Model Class Initialized
INFO - 2018-05-10 15:24:20 --> Final output sent to browser
DEBUG - 2018-05-10 15:24:20 --> Total execution time: 0.1033
INFO - 2018-05-10 09:54:23 --> Config Class Initialized
INFO - 2018-05-10 09:54:23 --> Hooks Class Initialized
DEBUG - 2018-05-10 09:54:23 --> UTF-8 Support Enabled
INFO - 2018-05-10 09:54:23 --> Utf8 Class Initialized
INFO - 2018-05-10 09:54:23 --> URI Class Initialized
INFO - 2018-05-10 09:54:23 --> Router Class Initialized
INFO - 2018-05-10 09:54:23 --> Output Class Initialized
INFO - 2018-05-10 09:54:23 --> Security Class Initialized
DEBUG - 2018-05-10 09:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 09:54:23 --> Input Class Initialized
INFO - 2018-05-10 09:54:23 --> Language Class Initialized
INFO - 2018-05-10 09:54:23 --> Language Class Initialized
INFO - 2018-05-10 09:54:23 --> Config Class Initialized
INFO - 2018-05-10 09:54:23 --> Loader Class Initialized
INFO - 2018-05-10 15:24:23 --> Helper loaded: url_helper
INFO - 2018-05-10 15:24:23 --> Helper loaded: notification_helper
INFO - 2018-05-10 15:24:23 --> Helper loaded: settings_helper
INFO - 2018-05-10 15:24:23 --> Helper loaded: permission_helper
INFO - 2018-05-10 15:24:23 --> Helper loaded: users_helper
INFO - 2018-05-10 15:24:23 --> Database Driver Class Initialized
DEBUG - 2018-05-10 15:24:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 15:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 15:24:23 --> Helper loaded: form_helper
INFO - 2018-05-10 15:24:23 --> Form Validation Class Initialized
INFO - 2018-05-10 15:24:23 --> Controller Class Initialized
INFO - 2018-05-10 15:24:23 --> Model Class Initialized
INFO - 2018-05-10 15:24:23 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 15:24:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 15:24:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 15:24:23 --> Model Class Initialized
INFO - 2018-05-10 15:24:23 --> Model Class Initialized
INFO - 2018-05-10 15:24:23 --> Model Class Initialized
INFO - 2018-05-10 15:24:23 --> Model Class Initialized
INFO - 2018-05-10 15:24:23 --> Model Class Initialized
INFO - 2018-05-10 15:24:23 --> Model Class Initialized
INFO - 2018-05-10 15:24:23 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 15:24:23 --> Final output sent to browser
DEBUG - 2018-05-10 15:24:23 --> Total execution time: 0.1149
INFO - 2018-05-10 09:58:03 --> Config Class Initialized
INFO - 2018-05-10 09:58:03 --> Hooks Class Initialized
DEBUG - 2018-05-10 09:58:03 --> UTF-8 Support Enabled
INFO - 2018-05-10 09:58:03 --> Utf8 Class Initialized
INFO - 2018-05-10 09:58:03 --> URI Class Initialized
INFO - 2018-05-10 09:58:03 --> Router Class Initialized
INFO - 2018-05-10 09:58:03 --> Output Class Initialized
INFO - 2018-05-10 09:58:03 --> Security Class Initialized
DEBUG - 2018-05-10 09:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 09:58:03 --> Input Class Initialized
INFO - 2018-05-10 09:58:03 --> Language Class Initialized
INFO - 2018-05-10 09:58:03 --> Language Class Initialized
INFO - 2018-05-10 09:58:03 --> Config Class Initialized
INFO - 2018-05-10 09:58:03 --> Loader Class Initialized
INFO - 2018-05-10 15:28:03 --> Helper loaded: url_helper
INFO - 2018-05-10 15:28:03 --> Helper loaded: notification_helper
INFO - 2018-05-10 15:28:03 --> Helper loaded: settings_helper
INFO - 2018-05-10 15:28:03 --> Helper loaded: permission_helper
INFO - 2018-05-10 15:28:03 --> Helper loaded: users_helper
INFO - 2018-05-10 15:28:03 --> Database Driver Class Initialized
DEBUG - 2018-05-10 15:28:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 15:28:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 15:28:03 --> Helper loaded: form_helper
INFO - 2018-05-10 15:28:03 --> Form Validation Class Initialized
INFO - 2018-05-10 15:28:03 --> Controller Class Initialized
INFO - 2018-05-10 15:28:03 --> Model Class Initialized
INFO - 2018-05-10 15:28:03 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 15:28:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 15:28:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 15:28:03 --> Model Class Initialized
INFO - 2018-05-10 15:28:03 --> Model Class Initialized
INFO - 2018-05-10 15:28:03 --> Model Class Initialized
INFO - 2018-05-10 15:28:03 --> Model Class Initialized
INFO - 2018-05-10 15:28:03 --> Model Class Initialized
INFO - 2018-05-10 15:28:03 --> Model Class Initialized
INFO - 2018-05-10 15:28:03 --> Model Class Initialized
INFO - 2018-05-10 15:28:03 --> Model Class Initialized
INFO - 2018-05-10 15:28:03 --> Model Class Initialized
INFO - 2018-05-10 15:28:03 --> Model Class Initialized
INFO - 2018-05-10 15:28:03 --> Model Class Initialized
INFO - 2018-05-10 15:28:03 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 15:28:03 --> Model Class Initialized
INFO - 2018-05-10 15:28:03 --> Final output sent to browser
DEBUG - 2018-05-10 15:28:03 --> Total execution time: 0.1203
INFO - 2018-05-10 09:58:04 --> Config Class Initialized
INFO - 2018-05-10 09:58:04 --> Hooks Class Initialized
DEBUG - 2018-05-10 09:58:04 --> UTF-8 Support Enabled
INFO - 2018-05-10 09:58:04 --> Utf8 Class Initialized
INFO - 2018-05-10 09:58:04 --> URI Class Initialized
INFO - 2018-05-10 09:58:04 --> Router Class Initialized
INFO - 2018-05-10 09:58:04 --> Output Class Initialized
INFO - 2018-05-10 09:58:04 --> Security Class Initialized
DEBUG - 2018-05-10 09:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 09:58:04 --> Input Class Initialized
INFO - 2018-05-10 09:58:04 --> Language Class Initialized
INFO - 2018-05-10 09:58:04 --> Language Class Initialized
INFO - 2018-05-10 09:58:04 --> Config Class Initialized
INFO - 2018-05-10 09:58:04 --> Loader Class Initialized
INFO - 2018-05-10 15:28:04 --> Helper loaded: url_helper
INFO - 2018-05-10 15:28:04 --> Helper loaded: notification_helper
INFO - 2018-05-10 15:28:04 --> Helper loaded: settings_helper
INFO - 2018-05-10 15:28:04 --> Helper loaded: permission_helper
INFO - 2018-05-10 15:28:04 --> Helper loaded: users_helper
INFO - 2018-05-10 15:28:04 --> Database Driver Class Initialized
DEBUG - 2018-05-10 15:28:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 15:28:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 15:28:04 --> Helper loaded: form_helper
INFO - 2018-05-10 15:28:04 --> Form Validation Class Initialized
INFO - 2018-05-10 15:28:04 --> Controller Class Initialized
INFO - 2018-05-10 15:28:04 --> Model Class Initialized
INFO - 2018-05-10 15:28:04 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 15:28:04 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 15:28:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 15:28:04 --> Model Class Initialized
INFO - 2018-05-10 15:28:04 --> Model Class Initialized
INFO - 2018-05-10 15:28:04 --> Model Class Initialized
INFO - 2018-05-10 15:28:04 --> Model Class Initialized
INFO - 2018-05-10 15:28:04 --> Model Class Initialized
INFO - 2018-05-10 15:28:04 --> Model Class Initialized
INFO - 2018-05-10 15:28:04 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 15:28:04 --> Model Class Initialized
INFO - 2018-05-10 15:28:04 --> Final output sent to browser
DEBUG - 2018-05-10 15:28:04 --> Total execution time: 0.1683
INFO - 2018-05-10 09:58:05 --> Config Class Initialized
INFO - 2018-05-10 09:58:05 --> Hooks Class Initialized
DEBUG - 2018-05-10 09:58:05 --> UTF-8 Support Enabled
INFO - 2018-05-10 09:58:05 --> Utf8 Class Initialized
INFO - 2018-05-10 09:58:05 --> URI Class Initialized
INFO - 2018-05-10 09:58:05 --> Config Class Initialized
INFO - 2018-05-10 09:58:05 --> Hooks Class Initialized
INFO - 2018-05-10 09:58:05 --> Router Class Initialized
DEBUG - 2018-05-10 09:58:05 --> UTF-8 Support Enabled
INFO - 2018-05-10 09:58:05 --> Utf8 Class Initialized
INFO - 2018-05-10 09:58:05 --> Output Class Initialized
INFO - 2018-05-10 09:58:05 --> URI Class Initialized
INFO - 2018-05-10 09:58:05 --> Security Class Initialized
DEBUG - 2018-05-10 09:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 09:58:05 --> Input Class Initialized
INFO - 2018-05-10 09:58:05 --> Router Class Initialized
INFO - 2018-05-10 09:58:05 --> Language Class Initialized
INFO - 2018-05-10 09:58:05 --> Output Class Initialized
INFO - 2018-05-10 09:58:05 --> Security Class Initialized
DEBUG - 2018-05-10 09:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 09:58:05 --> Input Class Initialized
INFO - 2018-05-10 09:58:05 --> Language Class Initialized
INFO - 2018-05-10 09:58:05 --> Language Class Initialized
INFO - 2018-05-10 09:58:05 --> Config Class Initialized
INFO - 2018-05-10 09:58:05 --> Loader Class Initialized
INFO - 2018-05-10 15:28:05 --> Helper loaded: url_helper
INFO - 2018-05-10 15:28:05 --> Helper loaded: notification_helper
INFO - 2018-05-10 15:28:05 --> Helper loaded: settings_helper
INFO - 2018-05-10 15:28:05 --> Helper loaded: permission_helper
INFO - 2018-05-10 15:28:05 --> Helper loaded: users_helper
INFO - 2018-05-10 09:58:05 --> Language Class Initialized
INFO - 2018-05-10 09:58:05 --> Config Class Initialized
INFO - 2018-05-10 09:58:05 --> Loader Class Initialized
INFO - 2018-05-10 15:28:05 --> Database Driver Class Initialized
INFO - 2018-05-10 15:28:05 --> Helper loaded: url_helper
INFO - 2018-05-10 15:28:05 --> Helper loaded: notification_helper
INFO - 2018-05-10 15:28:05 --> Helper loaded: settings_helper
INFO - 2018-05-10 15:28:05 --> Helper loaded: permission_helper
INFO - 2018-05-10 15:28:05 --> Helper loaded: users_helper
DEBUG - 2018-05-10 15:28:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 15:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 15:28:05 --> Helper loaded: form_helper
INFO - 2018-05-10 15:28:05 --> Form Validation Class Initialized
INFO - 2018-05-10 15:28:05 --> Controller Class Initialized
INFO - 2018-05-10 15:28:05 --> Model Class Initialized
INFO - 2018-05-10 15:28:05 --> Helper loaded: inflector_helper
INFO - 2018-05-10 15:28:05 --> Database Driver Class Initialized
DEBUG - 2018-05-10 15:28:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 15:28:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 15:28:05 --> Model Class Initialized
INFO - 2018-05-10 15:28:05 --> Model Class Initialized
INFO - 2018-05-10 15:28:05 --> Model Class Initialized
INFO - 2018-05-10 15:28:05 --> Model Class Initialized
INFO - 2018-05-10 15:28:05 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-05-10 15:28:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 15:28:05 --> Final output sent to browser
DEBUG - 2018-05-10 15:28:05 --> Total execution time: 0.1377
INFO - 2018-05-10 15:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 15:28:05 --> Helper loaded: form_helper
INFO - 2018-05-10 15:28:05 --> Form Validation Class Initialized
INFO - 2018-05-10 15:28:05 --> Controller Class Initialized
INFO - 2018-05-10 15:28:05 --> Model Class Initialized
INFO - 2018-05-10 15:28:05 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 15:28:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 15:28:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 15:28:05 --> Model Class Initialized
INFO - 2018-05-10 15:28:05 --> Model Class Initialized
INFO - 2018-05-10 15:28:05 --> Model Class Initialized
INFO - 2018-05-10 15:28:05 --> Model Class Initialized
INFO - 2018-05-10 15:28:05 --> Model Class Initialized
INFO - 2018-05-10 15:28:05 --> Model Class Initialized
INFO - 2018-05-10 15:28:05 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 15:28:05 --> Final output sent to browser
DEBUG - 2018-05-10 15:28:05 --> Total execution time: 0.1594
INFO - 2018-05-10 09:58:09 --> Config Class Initialized
INFO - 2018-05-10 09:58:09 --> Hooks Class Initialized
DEBUG - 2018-05-10 09:58:09 --> UTF-8 Support Enabled
INFO - 2018-05-10 09:58:09 --> Utf8 Class Initialized
INFO - 2018-05-10 09:58:09 --> URI Class Initialized
INFO - 2018-05-10 09:58:09 --> Router Class Initialized
INFO - 2018-05-10 09:58:09 --> Output Class Initialized
INFO - 2018-05-10 09:58:09 --> Security Class Initialized
DEBUG - 2018-05-10 09:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 09:58:09 --> Input Class Initialized
INFO - 2018-05-10 09:58:09 --> Language Class Initialized
INFO - 2018-05-10 09:58:09 --> Language Class Initialized
INFO - 2018-05-10 09:58:09 --> Config Class Initialized
INFO - 2018-05-10 09:58:09 --> Loader Class Initialized
INFO - 2018-05-10 15:28:09 --> Helper loaded: url_helper
INFO - 2018-05-10 15:28:09 --> Helper loaded: notification_helper
INFO - 2018-05-10 15:28:09 --> Helper loaded: settings_helper
INFO - 2018-05-10 15:28:09 --> Helper loaded: permission_helper
INFO - 2018-05-10 15:28:09 --> Helper loaded: users_helper
INFO - 2018-05-10 15:28:09 --> Database Driver Class Initialized
DEBUG - 2018-05-10 15:28:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 15:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 15:28:09 --> Helper loaded: form_helper
INFO - 2018-05-10 15:28:09 --> Form Validation Class Initialized
INFO - 2018-05-10 15:28:09 --> Controller Class Initialized
INFO - 2018-05-10 15:28:09 --> Model Class Initialized
INFO - 2018-05-10 15:28:09 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 15:28:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 15:28:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 15:28:09 --> Model Class Initialized
INFO - 2018-05-10 15:28:09 --> Model Class Initialized
INFO - 2018-05-10 15:28:09 --> Model Class Initialized
INFO - 2018-05-10 15:28:09 --> Model Class Initialized
INFO - 2018-05-10 15:28:09 --> Model Class Initialized
INFO - 2018-05-10 15:28:09 --> Model Class Initialized
INFO - 2018-05-10 15:28:09 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 15:28:09 --> Final output sent to browser
DEBUG - 2018-05-10 15:28:09 --> Total execution time: 0.1219
INFO - 2018-05-10 10:00:02 --> Config Class Initialized
INFO - 2018-05-10 10:00:02 --> Hooks Class Initialized
DEBUG - 2018-05-10 10:00:02 --> UTF-8 Support Enabled
INFO - 2018-05-10 10:00:02 --> Utf8 Class Initialized
INFO - 2018-05-10 10:00:02 --> URI Class Initialized
INFO - 2018-05-10 10:00:02 --> Router Class Initialized
INFO - 2018-05-10 10:00:02 --> Output Class Initialized
INFO - 2018-05-10 10:00:02 --> Security Class Initialized
DEBUG - 2018-05-10 10:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 10:00:02 --> Input Class Initialized
INFO - 2018-05-10 10:00:02 --> Language Class Initialized
INFO - 2018-05-10 10:00:02 --> Language Class Initialized
INFO - 2018-05-10 10:00:02 --> Config Class Initialized
INFO - 2018-05-10 10:00:02 --> Loader Class Initialized
INFO - 2018-05-10 15:30:02 --> Helper loaded: url_helper
INFO - 2018-05-10 15:30:02 --> Helper loaded: notification_helper
INFO - 2018-05-10 15:30:02 --> Helper loaded: settings_helper
INFO - 2018-05-10 15:30:02 --> Helper loaded: permission_helper
INFO - 2018-05-10 15:30:02 --> Helper loaded: users_helper
INFO - 2018-05-10 15:30:02 --> Database Driver Class Initialized
DEBUG - 2018-05-10 15:30:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 15:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 15:30:02 --> Helper loaded: form_helper
INFO - 2018-05-10 15:30:02 --> Form Validation Class Initialized
INFO - 2018-05-10 15:30:02 --> Controller Class Initialized
INFO - 2018-05-10 15:30:02 --> Model Class Initialized
INFO - 2018-05-10 15:30:02 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 15:30:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 15:30:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 15:30:02 --> Model Class Initialized
INFO - 2018-05-10 15:30:02 --> Model Class Initialized
INFO - 2018-05-10 15:30:02 --> Model Class Initialized
INFO - 2018-05-10 15:30:02 --> Model Class Initialized
INFO - 2018-05-10 15:30:02 --> Model Class Initialized
INFO - 2018-05-10 15:30:02 --> Model Class Initialized
INFO - 2018-05-10 15:30:02 --> Model Class Initialized
INFO - 2018-05-10 15:30:02 --> Model Class Initialized
INFO - 2018-05-10 15:30:02 --> Model Class Initialized
INFO - 2018-05-10 15:30:02 --> Model Class Initialized
INFO - 2018-05-10 15:30:02 --> Model Class Initialized
INFO - 2018-05-10 15:30:02 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 15:30:02 --> Model Class Initialized
INFO - 2018-05-10 15:30:02 --> Final output sent to browser
DEBUG - 2018-05-10 15:30:02 --> Total execution time: 0.1102
INFO - 2018-05-10 10:00:03 --> Config Class Initialized
INFO - 2018-05-10 10:00:03 --> Hooks Class Initialized
DEBUG - 2018-05-10 10:00:03 --> UTF-8 Support Enabled
INFO - 2018-05-10 10:00:03 --> Utf8 Class Initialized
INFO - 2018-05-10 10:00:03 --> URI Class Initialized
INFO - 2018-05-10 10:00:03 --> Router Class Initialized
INFO - 2018-05-10 10:00:03 --> Output Class Initialized
INFO - 2018-05-10 10:00:03 --> Security Class Initialized
DEBUG - 2018-05-10 10:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 10:00:03 --> Input Class Initialized
INFO - 2018-05-10 10:00:03 --> Language Class Initialized
INFO - 2018-05-10 10:00:03 --> Language Class Initialized
INFO - 2018-05-10 10:00:03 --> Config Class Initialized
INFO - 2018-05-10 10:00:03 --> Loader Class Initialized
INFO - 2018-05-10 15:30:03 --> Helper loaded: url_helper
INFO - 2018-05-10 15:30:03 --> Helper loaded: notification_helper
INFO - 2018-05-10 15:30:03 --> Helper loaded: settings_helper
INFO - 2018-05-10 15:30:03 --> Helper loaded: permission_helper
INFO - 2018-05-10 15:30:03 --> Helper loaded: users_helper
INFO - 2018-05-10 15:30:03 --> Database Driver Class Initialized
DEBUG - 2018-05-10 15:30:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 15:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 15:30:03 --> Helper loaded: form_helper
INFO - 2018-05-10 15:30:03 --> Form Validation Class Initialized
INFO - 2018-05-10 15:30:03 --> Controller Class Initialized
INFO - 2018-05-10 15:30:03 --> Model Class Initialized
INFO - 2018-05-10 15:30:03 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 15:30:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 15:30:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 15:30:03 --> Model Class Initialized
INFO - 2018-05-10 15:30:03 --> Model Class Initialized
INFO - 2018-05-10 15:30:03 --> Model Class Initialized
INFO - 2018-05-10 15:30:03 --> Model Class Initialized
INFO - 2018-05-10 15:30:03 --> Model Class Initialized
INFO - 2018-05-10 15:30:03 --> Model Class Initialized
INFO - 2018-05-10 15:30:03 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 15:30:03 --> Model Class Initialized
INFO - 2018-05-10 15:30:03 --> Final output sent to browser
DEBUG - 2018-05-10 15:30:03 --> Total execution time: 0.1342
INFO - 2018-05-10 10:00:10 --> Config Class Initialized
INFO - 2018-05-10 10:00:10 --> Hooks Class Initialized
DEBUG - 2018-05-10 10:00:10 --> UTF-8 Support Enabled
INFO - 2018-05-10 10:00:10 --> Utf8 Class Initialized
INFO - 2018-05-10 10:00:10 --> URI Class Initialized
INFO - 2018-05-10 10:00:10 --> Router Class Initialized
INFO - 2018-05-10 10:00:10 --> Output Class Initialized
INFO - 2018-05-10 10:00:10 --> Security Class Initialized
DEBUG - 2018-05-10 10:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 10:00:10 --> Input Class Initialized
INFO - 2018-05-10 10:00:10 --> Config Class Initialized
INFO - 2018-05-10 10:00:10 --> Hooks Class Initialized
INFO - 2018-05-10 10:00:10 --> Language Class Initialized
DEBUG - 2018-05-10 10:00:10 --> UTF-8 Support Enabled
INFO - 2018-05-10 10:00:10 --> Utf8 Class Initialized
INFO - 2018-05-10 10:00:10 --> URI Class Initialized
INFO - 2018-05-10 10:00:10 --> Router Class Initialized
INFO - 2018-05-10 10:00:10 --> Language Class Initialized
INFO - 2018-05-10 10:00:10 --> Config Class Initialized
INFO - 2018-05-10 10:00:10 --> Loader Class Initialized
INFO - 2018-05-10 10:00:10 --> Output Class Initialized
INFO - 2018-05-10 15:30:10 --> Helper loaded: url_helper
INFO - 2018-05-10 15:30:10 --> Helper loaded: notification_helper
INFO - 2018-05-10 15:30:10 --> Helper loaded: settings_helper
INFO - 2018-05-10 15:30:10 --> Helper loaded: permission_helper
INFO - 2018-05-10 15:30:10 --> Helper loaded: users_helper
INFO - 2018-05-10 10:00:10 --> Security Class Initialized
DEBUG - 2018-05-10 10:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 10:00:10 --> Input Class Initialized
INFO - 2018-05-10 10:00:10 --> Language Class Initialized
INFO - 2018-05-10 15:30:10 --> Database Driver Class Initialized
DEBUG - 2018-05-10 15:30:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 15:30:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 15:30:10 --> Helper loaded: form_helper
INFO - 2018-05-10 15:30:10 --> Form Validation Class Initialized
INFO - 2018-05-10 15:30:10 --> Controller Class Initialized
INFO - 2018-05-10 10:00:10 --> Language Class Initialized
INFO - 2018-05-10 10:00:10 --> Config Class Initialized
INFO - 2018-05-10 10:00:10 --> Loader Class Initialized
INFO - 2018-05-10 15:30:10 --> Helper loaded: url_helper
INFO - 2018-05-10 15:30:10 --> Helper loaded: notification_helper
INFO - 2018-05-10 15:30:10 --> Helper loaded: settings_helper
INFO - 2018-05-10 15:30:10 --> Model Class Initialized
INFO - 2018-05-10 15:30:10 --> Helper loaded: permission_helper
INFO - 2018-05-10 15:30:10 --> Helper loaded: inflector_helper
INFO - 2018-05-10 15:30:10 --> Helper loaded: users_helper
DEBUG - 2018-05-10 15:30:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 15:30:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 15:30:10 --> Model Class Initialized
INFO - 2018-05-10 15:30:10 --> Model Class Initialized
INFO - 2018-05-10 15:30:10 --> Model Class Initialized
INFO - 2018-05-10 15:30:10 --> Model Class Initialized
INFO - 2018-05-10 15:30:10 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 15:30:10 --> Final output sent to browser
DEBUG - 2018-05-10 15:30:10 --> Total execution time: 0.1003
INFO - 2018-05-10 15:30:10 --> Database Driver Class Initialized
DEBUG - 2018-05-10 15:30:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 15:30:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 15:30:10 --> Helper loaded: form_helper
INFO - 2018-05-10 15:30:10 --> Form Validation Class Initialized
INFO - 2018-05-10 15:30:10 --> Controller Class Initialized
INFO - 2018-05-10 15:30:10 --> Model Class Initialized
INFO - 2018-05-10 15:30:10 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 15:30:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 15:30:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 15:30:10 --> Model Class Initialized
INFO - 2018-05-10 15:30:10 --> Model Class Initialized
INFO - 2018-05-10 15:30:10 --> Model Class Initialized
INFO - 2018-05-10 15:30:10 --> Model Class Initialized
INFO - 2018-05-10 15:30:10 --> Model Class Initialized
INFO - 2018-05-10 15:30:10 --> Model Class Initialized
INFO - 2018-05-10 15:30:10 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 15:30:10 --> Final output sent to browser
DEBUG - 2018-05-10 15:30:10 --> Total execution time: 0.1345
INFO - 2018-05-10 10:11:41 --> Config Class Initialized
INFO - 2018-05-10 10:11:41 --> Hooks Class Initialized
DEBUG - 2018-05-10 10:11:41 --> UTF-8 Support Enabled
INFO - 2018-05-10 10:11:41 --> Utf8 Class Initialized
INFO - 2018-05-10 10:11:41 --> URI Class Initialized
INFO - 2018-05-10 10:11:41 --> Router Class Initialized
INFO - 2018-05-10 10:11:41 --> Output Class Initialized
INFO - 2018-05-10 10:11:41 --> Security Class Initialized
DEBUG - 2018-05-10 10:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 10:11:41 --> Input Class Initialized
INFO - 2018-05-10 10:11:41 --> Language Class Initialized
INFO - 2018-05-10 10:11:41 --> Language Class Initialized
INFO - 2018-05-10 10:11:41 --> Config Class Initialized
INFO - 2018-05-10 10:11:41 --> Loader Class Initialized
INFO - 2018-05-10 15:41:41 --> Helper loaded: url_helper
INFO - 2018-05-10 15:41:41 --> Helper loaded: notification_helper
INFO - 2018-05-10 15:41:41 --> Helper loaded: settings_helper
INFO - 2018-05-10 15:41:41 --> Helper loaded: permission_helper
INFO - 2018-05-10 15:41:41 --> Helper loaded: users_helper
INFO - 2018-05-10 15:41:41 --> Database Driver Class Initialized
DEBUG - 2018-05-10 15:41:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 15:41:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 15:41:41 --> Helper loaded: form_helper
INFO - 2018-05-10 15:41:41 --> Form Validation Class Initialized
INFO - 2018-05-10 15:41:41 --> Controller Class Initialized
INFO - 2018-05-10 15:41:41 --> Model Class Initialized
INFO - 2018-05-10 15:41:41 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 15:41:41 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 15:41:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 15:41:41 --> Model Class Initialized
INFO - 2018-05-10 15:41:41 --> Model Class Initialized
INFO - 2018-05-10 15:41:41 --> Model Class Initialized
INFO - 2018-05-10 15:41:41 --> Model Class Initialized
INFO - 2018-05-10 15:41:41 --> Model Class Initialized
INFO - 2018-05-10 15:41:41 --> Model Class Initialized
INFO - 2018-05-10 15:41:41 --> Model Class Initialized
INFO - 2018-05-10 15:41:41 --> Model Class Initialized
INFO - 2018-05-10 15:41:41 --> Model Class Initialized
INFO - 2018-05-10 15:41:41 --> Model Class Initialized
INFO - 2018-05-10 15:41:41 --> Model Class Initialized
INFO - 2018-05-10 15:41:41 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 15:41:41 --> Model Class Initialized
INFO - 2018-05-10 15:41:41 --> Final output sent to browser
DEBUG - 2018-05-10 15:41:41 --> Total execution time: 0.1322
INFO - 2018-05-10 10:11:42 --> Config Class Initialized
INFO - 2018-05-10 10:11:42 --> Hooks Class Initialized
DEBUG - 2018-05-10 10:11:42 --> UTF-8 Support Enabled
INFO - 2018-05-10 10:11:42 --> Utf8 Class Initialized
INFO - 2018-05-10 10:11:42 --> URI Class Initialized
INFO - 2018-05-10 10:11:42 --> Router Class Initialized
INFO - 2018-05-10 10:11:42 --> Output Class Initialized
INFO - 2018-05-10 10:11:42 --> Security Class Initialized
DEBUG - 2018-05-10 10:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 10:11:42 --> Input Class Initialized
INFO - 2018-05-10 10:11:42 --> Language Class Initialized
INFO - 2018-05-10 10:11:42 --> Language Class Initialized
INFO - 2018-05-10 10:11:42 --> Config Class Initialized
INFO - 2018-05-10 10:11:42 --> Loader Class Initialized
INFO - 2018-05-10 15:41:42 --> Helper loaded: url_helper
INFO - 2018-05-10 15:41:42 --> Helper loaded: notification_helper
INFO - 2018-05-10 15:41:42 --> Helper loaded: settings_helper
INFO - 2018-05-10 15:41:42 --> Helper loaded: permission_helper
INFO - 2018-05-10 15:41:42 --> Helper loaded: users_helper
INFO - 2018-05-10 15:41:42 --> Database Driver Class Initialized
DEBUG - 2018-05-10 15:41:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 15:41:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 15:41:42 --> Helper loaded: form_helper
INFO - 2018-05-10 15:41:42 --> Form Validation Class Initialized
INFO - 2018-05-10 15:41:42 --> Controller Class Initialized
INFO - 2018-05-10 15:41:42 --> Model Class Initialized
INFO - 2018-05-10 15:41:42 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 15:41:42 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 15:41:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 15:41:42 --> Model Class Initialized
INFO - 2018-05-10 15:41:42 --> Model Class Initialized
INFO - 2018-05-10 15:41:42 --> Model Class Initialized
INFO - 2018-05-10 15:41:42 --> Model Class Initialized
INFO - 2018-05-10 15:41:42 --> Model Class Initialized
INFO - 2018-05-10 15:41:42 --> Model Class Initialized
INFO - 2018-05-10 15:41:42 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 15:41:42 --> Model Class Initialized
INFO - 2018-05-10 15:41:42 --> Final output sent to browser
DEBUG - 2018-05-10 15:41:42 --> Total execution time: 0.1096
INFO - 2018-05-10 10:11:46 --> Config Class Initialized
INFO - 2018-05-10 10:11:46 --> Hooks Class Initialized
DEBUG - 2018-05-10 10:11:46 --> UTF-8 Support Enabled
INFO - 2018-05-10 10:11:46 --> Utf8 Class Initialized
INFO - 2018-05-10 10:11:46 --> URI Class Initialized
INFO - 2018-05-10 10:11:46 --> Router Class Initialized
INFO - 2018-05-10 10:11:46 --> Output Class Initialized
INFO - 2018-05-10 10:11:46 --> Security Class Initialized
DEBUG - 2018-05-10 10:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 10:11:46 --> Input Class Initialized
INFO - 2018-05-10 10:11:46 --> Language Class Initialized
INFO - 2018-05-10 10:11:46 --> Language Class Initialized
INFO - 2018-05-10 10:11:46 --> Config Class Initialized
INFO - 2018-05-10 10:11:46 --> Loader Class Initialized
INFO - 2018-05-10 15:41:46 --> Helper loaded: url_helper
INFO - 2018-05-10 15:41:46 --> Helper loaded: notification_helper
INFO - 2018-05-10 15:41:46 --> Helper loaded: settings_helper
INFO - 2018-05-10 15:41:46 --> Helper loaded: permission_helper
INFO - 2018-05-10 15:41:46 --> Helper loaded: users_helper
INFO - 2018-05-10 15:41:46 --> Database Driver Class Initialized
DEBUG - 2018-05-10 15:41:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 15:41:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 15:41:46 --> Helper loaded: form_helper
INFO - 2018-05-10 15:41:46 --> Form Validation Class Initialized
INFO - 2018-05-10 15:41:46 --> Controller Class Initialized
INFO - 2018-05-10 15:41:46 --> Model Class Initialized
INFO - 2018-05-10 15:41:46 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 15:41:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 15:41:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 15:41:46 --> Model Class Initialized
INFO - 2018-05-10 15:41:46 --> Model Class Initialized
INFO - 2018-05-10 15:41:46 --> Model Class Initialized
INFO - 2018-05-10 15:41:46 --> Model Class Initialized
INFO - 2018-05-10 15:41:46 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 15:41:46 --> Final output sent to browser
DEBUG - 2018-05-10 15:41:46 --> Total execution time: 0.1188
INFO - 2018-05-10 10:11:47 --> Config Class Initialized
INFO - 2018-05-10 10:11:47 --> Hooks Class Initialized
DEBUG - 2018-05-10 10:11:47 --> UTF-8 Support Enabled
INFO - 2018-05-10 10:11:47 --> Utf8 Class Initialized
INFO - 2018-05-10 10:11:47 --> URI Class Initialized
INFO - 2018-05-10 10:11:47 --> Router Class Initialized
INFO - 2018-05-10 10:11:47 --> Output Class Initialized
INFO - 2018-05-10 10:11:47 --> Security Class Initialized
DEBUG - 2018-05-10 10:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 10:11:47 --> Input Class Initialized
INFO - 2018-05-10 10:11:47 --> Language Class Initialized
INFO - 2018-05-10 10:11:47 --> Language Class Initialized
INFO - 2018-05-10 10:11:47 --> Config Class Initialized
INFO - 2018-05-10 10:11:47 --> Loader Class Initialized
INFO - 2018-05-10 15:41:47 --> Helper loaded: url_helper
INFO - 2018-05-10 15:41:47 --> Helper loaded: notification_helper
INFO - 2018-05-10 15:41:47 --> Helper loaded: settings_helper
INFO - 2018-05-10 15:41:47 --> Helper loaded: permission_helper
INFO - 2018-05-10 15:41:47 --> Helper loaded: users_helper
INFO - 2018-05-10 15:41:47 --> Database Driver Class Initialized
DEBUG - 2018-05-10 15:41:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 15:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 15:41:47 --> Helper loaded: form_helper
INFO - 2018-05-10 15:41:47 --> Form Validation Class Initialized
INFO - 2018-05-10 15:41:47 --> Controller Class Initialized
INFO - 2018-05-10 15:41:47 --> Model Class Initialized
INFO - 2018-05-10 15:41:47 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 15:41:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 15:41:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 15:41:47 --> Model Class Initialized
INFO - 2018-05-10 15:41:47 --> Model Class Initialized
INFO - 2018-05-10 15:41:47 --> Model Class Initialized
INFO - 2018-05-10 15:41:47 --> Model Class Initialized
INFO - 2018-05-10 15:41:47 --> Model Class Initialized
INFO - 2018-05-10 15:41:47 --> Model Class Initialized
INFO - 2018-05-10 15:41:47 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 15:41:47 --> Final output sent to browser
DEBUG - 2018-05-10 15:41:47 --> Total execution time: 0.1334
INFO - 2018-05-10 10:11:52 --> Config Class Initialized
INFO - 2018-05-10 10:11:52 --> Hooks Class Initialized
DEBUG - 2018-05-10 10:11:52 --> UTF-8 Support Enabled
INFO - 2018-05-10 10:11:52 --> Utf8 Class Initialized
INFO - 2018-05-10 10:11:52 --> URI Class Initialized
INFO - 2018-05-10 10:11:52 --> Router Class Initialized
INFO - 2018-05-10 10:11:52 --> Output Class Initialized
INFO - 2018-05-10 10:11:52 --> Security Class Initialized
DEBUG - 2018-05-10 10:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 10:11:52 --> Input Class Initialized
INFO - 2018-05-10 10:11:52 --> Language Class Initialized
INFO - 2018-05-10 10:11:52 --> Language Class Initialized
INFO - 2018-05-10 10:11:52 --> Config Class Initialized
INFO - 2018-05-10 10:11:52 --> Loader Class Initialized
INFO - 2018-05-10 15:41:52 --> Helper loaded: url_helper
INFO - 2018-05-10 15:41:52 --> Helper loaded: notification_helper
INFO - 2018-05-10 15:41:52 --> Helper loaded: settings_helper
INFO - 2018-05-10 15:41:52 --> Helper loaded: permission_helper
INFO - 2018-05-10 15:41:52 --> Helper loaded: users_helper
INFO - 2018-05-10 15:41:52 --> Database Driver Class Initialized
DEBUG - 2018-05-10 15:41:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 15:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 15:41:52 --> Helper loaded: form_helper
INFO - 2018-05-10 15:41:52 --> Form Validation Class Initialized
INFO - 2018-05-10 15:41:52 --> Controller Class Initialized
INFO - 2018-05-10 15:41:52 --> Model Class Initialized
INFO - 2018-05-10 15:41:52 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 15:41:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 15:41:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 15:41:52 --> Model Class Initialized
INFO - 2018-05-10 15:41:52 --> Model Class Initialized
INFO - 2018-05-10 15:41:52 --> Model Class Initialized
INFO - 2018-05-10 15:41:52 --> Model Class Initialized
INFO - 2018-05-10 15:41:52 --> Model Class Initialized
INFO - 2018-05-10 15:41:52 --> Model Class Initialized
INFO - 2018-05-10 15:41:52 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 15:41:52 --> Final output sent to browser
DEBUG - 2018-05-10 15:41:52 --> Total execution time: 0.2230
INFO - 2018-05-10 10:12:07 --> Config Class Initialized
INFO - 2018-05-10 10:12:07 --> Hooks Class Initialized
DEBUG - 2018-05-10 10:12:07 --> UTF-8 Support Enabled
INFO - 2018-05-10 10:12:07 --> Utf8 Class Initialized
INFO - 2018-05-10 10:12:07 --> URI Class Initialized
INFO - 2018-05-10 10:12:07 --> Router Class Initialized
INFO - 2018-05-10 10:12:07 --> Output Class Initialized
INFO - 2018-05-10 10:12:07 --> Security Class Initialized
DEBUG - 2018-05-10 10:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 10:12:07 --> Input Class Initialized
INFO - 2018-05-10 10:12:07 --> Language Class Initialized
INFO - 2018-05-10 10:12:07 --> Language Class Initialized
INFO - 2018-05-10 10:12:07 --> Config Class Initialized
INFO - 2018-05-10 10:12:07 --> Loader Class Initialized
INFO - 2018-05-10 15:42:07 --> Helper loaded: url_helper
INFO - 2018-05-10 15:42:07 --> Helper loaded: notification_helper
INFO - 2018-05-10 15:42:07 --> Helper loaded: settings_helper
INFO - 2018-05-10 15:42:07 --> Helper loaded: permission_helper
INFO - 2018-05-10 15:42:07 --> Helper loaded: users_helper
INFO - 2018-05-10 15:42:07 --> Database Driver Class Initialized
DEBUG - 2018-05-10 15:42:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 15:42:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 15:42:07 --> Helper loaded: form_helper
INFO - 2018-05-10 15:42:07 --> Form Validation Class Initialized
INFO - 2018-05-10 15:42:07 --> Controller Class Initialized
INFO - 2018-05-10 15:42:07 --> Model Class Initialized
INFO - 2018-05-10 15:42:07 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 15:42:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 15:42:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 15:42:07 --> Model Class Initialized
INFO - 2018-05-10 15:42:07 --> Model Class Initialized
INFO - 2018-05-10 15:42:07 --> Model Class Initialized
INFO - 2018-05-10 15:42:07 --> Model Class Initialized
INFO - 2018-05-10 15:42:07 --> Model Class Initialized
INFO - 2018-05-10 15:42:07 --> Model Class Initialized
INFO - 2018-05-10 15:42:07 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 15:42:07 --> Final output sent to browser
DEBUG - 2018-05-10 15:42:07 --> Total execution time: 0.1104
INFO - 2018-05-10 10:18:28 --> Config Class Initialized
INFO - 2018-05-10 10:18:28 --> Hooks Class Initialized
DEBUG - 2018-05-10 10:18:28 --> UTF-8 Support Enabled
INFO - 2018-05-10 10:18:28 --> Utf8 Class Initialized
INFO - 2018-05-10 10:18:28 --> URI Class Initialized
INFO - 2018-05-10 10:18:28 --> Router Class Initialized
INFO - 2018-05-10 10:18:28 --> Output Class Initialized
INFO - 2018-05-10 10:18:28 --> Security Class Initialized
DEBUG - 2018-05-10 10:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 10:18:28 --> Input Class Initialized
INFO - 2018-05-10 10:18:28 --> Language Class Initialized
INFO - 2018-05-10 10:18:28 --> Language Class Initialized
INFO - 2018-05-10 10:18:28 --> Config Class Initialized
INFO - 2018-05-10 10:18:28 --> Loader Class Initialized
INFO - 2018-05-10 15:48:28 --> Helper loaded: url_helper
INFO - 2018-05-10 15:48:28 --> Helper loaded: notification_helper
INFO - 2018-05-10 15:48:28 --> Helper loaded: settings_helper
INFO - 2018-05-10 15:48:28 --> Helper loaded: permission_helper
INFO - 2018-05-10 15:48:28 --> Helper loaded: users_helper
INFO - 2018-05-10 15:48:28 --> Database Driver Class Initialized
DEBUG - 2018-05-10 15:48:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 15:48:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 15:48:28 --> Helper loaded: form_helper
INFO - 2018-05-10 15:48:28 --> Form Validation Class Initialized
INFO - 2018-05-10 15:48:28 --> Controller Class Initialized
INFO - 2018-05-10 15:48:28 --> Model Class Initialized
INFO - 2018-05-10 15:48:28 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 15:48:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 15:48:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 15:48:28 --> Model Class Initialized
INFO - 2018-05-10 15:48:28 --> Model Class Initialized
INFO - 2018-05-10 15:48:28 --> Model Class Initialized
INFO - 2018-05-10 15:48:28 --> Model Class Initialized
INFO - 2018-05-10 15:48:28 --> Model Class Initialized
INFO - 2018-05-10 15:48:28 --> Model Class Initialized
INFO - 2018-05-10 15:48:28 --> Model Class Initialized
INFO - 2018-05-10 15:48:28 --> Model Class Initialized
INFO - 2018-05-10 15:48:28 --> Model Class Initialized
INFO - 2018-05-10 15:48:28 --> Model Class Initialized
INFO - 2018-05-10 15:48:28 --> Model Class Initialized
INFO - 2018-05-10 15:48:28 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 15:48:28 --> Model Class Initialized
INFO - 2018-05-10 15:48:28 --> Final output sent to browser
DEBUG - 2018-05-10 15:48:28 --> Total execution time: 0.1310
INFO - 2018-05-10 10:18:28 --> Config Class Initialized
INFO - 2018-05-10 10:18:28 --> Hooks Class Initialized
DEBUG - 2018-05-10 10:18:28 --> UTF-8 Support Enabled
INFO - 2018-05-10 10:18:28 --> Utf8 Class Initialized
INFO - 2018-05-10 10:18:28 --> URI Class Initialized
INFO - 2018-05-10 10:18:28 --> Router Class Initialized
INFO - 2018-05-10 10:18:28 --> Output Class Initialized
INFO - 2018-05-10 10:18:28 --> Security Class Initialized
DEBUG - 2018-05-10 10:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 10:18:28 --> Input Class Initialized
INFO - 2018-05-10 10:18:28 --> Language Class Initialized
INFO - 2018-05-10 10:18:28 --> Language Class Initialized
INFO - 2018-05-10 10:18:28 --> Config Class Initialized
INFO - 2018-05-10 10:18:28 --> Loader Class Initialized
INFO - 2018-05-10 15:48:28 --> Helper loaded: url_helper
INFO - 2018-05-10 15:48:28 --> Helper loaded: notification_helper
INFO - 2018-05-10 15:48:28 --> Helper loaded: settings_helper
INFO - 2018-05-10 15:48:28 --> Helper loaded: permission_helper
INFO - 2018-05-10 15:48:28 --> Helper loaded: users_helper
INFO - 2018-05-10 15:48:28 --> Database Driver Class Initialized
DEBUG - 2018-05-10 15:48:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 15:48:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 15:48:28 --> Helper loaded: form_helper
INFO - 2018-05-10 15:48:28 --> Form Validation Class Initialized
INFO - 2018-05-10 15:48:28 --> Controller Class Initialized
INFO - 2018-05-10 15:48:28 --> Model Class Initialized
INFO - 2018-05-10 15:48:28 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 15:48:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 15:48:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 15:48:28 --> Model Class Initialized
INFO - 2018-05-10 15:48:28 --> Model Class Initialized
INFO - 2018-05-10 15:48:28 --> Model Class Initialized
INFO - 2018-05-10 15:48:28 --> Model Class Initialized
INFO - 2018-05-10 15:48:28 --> Model Class Initialized
INFO - 2018-05-10 15:48:28 --> Model Class Initialized
INFO - 2018-05-10 15:48:28 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 15:48:28 --> Model Class Initialized
INFO - 2018-05-10 15:48:28 --> Final output sent to browser
DEBUG - 2018-05-10 15:48:28 --> Total execution time: 0.1109
INFO - 2018-05-10 10:18:30 --> Config Class Initialized
INFO - 2018-05-10 10:18:30 --> Hooks Class Initialized
DEBUG - 2018-05-10 10:18:30 --> UTF-8 Support Enabled
INFO - 2018-05-10 10:18:30 --> Utf8 Class Initialized
INFO - 2018-05-10 10:18:30 --> URI Class Initialized
INFO - 2018-05-10 10:18:30 --> Router Class Initialized
INFO - 2018-05-10 10:18:30 --> Config Class Initialized
INFO - 2018-05-10 10:18:30 --> Hooks Class Initialized
INFO - 2018-05-10 10:18:30 --> Output Class Initialized
DEBUG - 2018-05-10 10:18:30 --> UTF-8 Support Enabled
INFO - 2018-05-10 10:18:30 --> Utf8 Class Initialized
INFO - 2018-05-10 10:18:30 --> Security Class Initialized
INFO - 2018-05-10 10:18:30 --> URI Class Initialized
DEBUG - 2018-05-10 10:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 10:18:30 --> Input Class Initialized
INFO - 2018-05-10 10:18:30 --> Language Class Initialized
INFO - 2018-05-10 10:18:30 --> Router Class Initialized
INFO - 2018-05-10 10:18:30 --> Output Class Initialized
INFO - 2018-05-10 10:18:30 --> Security Class Initialized
DEBUG - 2018-05-10 10:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 10:18:30 --> Input Class Initialized
INFO - 2018-05-10 10:18:30 --> Language Class Initialized
INFO - 2018-05-10 10:18:30 --> Language Class Initialized
INFO - 2018-05-10 10:18:30 --> Config Class Initialized
INFO - 2018-05-10 10:18:30 --> Loader Class Initialized
INFO - 2018-05-10 15:48:30 --> Helper loaded: url_helper
INFO - 2018-05-10 15:48:30 --> Helper loaded: notification_helper
INFO - 2018-05-10 15:48:30 --> Helper loaded: settings_helper
INFO - 2018-05-10 15:48:30 --> Helper loaded: permission_helper
INFO - 2018-05-10 15:48:30 --> Helper loaded: users_helper
INFO - 2018-05-10 15:48:30 --> Database Driver Class Initialized
INFO - 2018-05-10 10:18:30 --> Language Class Initialized
INFO - 2018-05-10 10:18:30 --> Config Class Initialized
INFO - 2018-05-10 10:18:30 --> Loader Class Initialized
DEBUG - 2018-05-10 15:48:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 15:48:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 15:48:30 --> Helper loaded: url_helper
INFO - 2018-05-10 15:48:30 --> Helper loaded: notification_helper
INFO - 2018-05-10 15:48:30 --> Helper loaded: settings_helper
INFO - 2018-05-10 15:48:30 --> Helper loaded: permission_helper
INFO - 2018-05-10 15:48:30 --> Helper loaded: users_helper
INFO - 2018-05-10 15:48:30 --> Helper loaded: form_helper
INFO - 2018-05-10 15:48:30 --> Form Validation Class Initialized
INFO - 2018-05-10 15:48:30 --> Controller Class Initialized
INFO - 2018-05-10 15:48:30 --> Model Class Initialized
INFO - 2018-05-10 15:48:30 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 15:48:30 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 15:48:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 15:48:30 --> Model Class Initialized
INFO - 2018-05-10 15:48:30 --> Model Class Initialized
INFO - 2018-05-10 15:48:30 --> Model Class Initialized
INFO - 2018-05-10 15:48:30 --> Model Class Initialized
INFO - 2018-05-10 15:48:30 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 15:48:30 --> Final output sent to browser
DEBUG - 2018-05-10 15:48:30 --> Total execution time: 0.1324
INFO - 2018-05-10 15:48:30 --> Database Driver Class Initialized
DEBUG - 2018-05-10 15:48:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 15:48:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 15:48:30 --> Helper loaded: form_helper
INFO - 2018-05-10 15:48:30 --> Form Validation Class Initialized
INFO - 2018-05-10 15:48:30 --> Controller Class Initialized
INFO - 2018-05-10 15:48:30 --> Model Class Initialized
INFO - 2018-05-10 15:48:30 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 15:48:30 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 15:48:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 15:48:30 --> Model Class Initialized
INFO - 2018-05-10 15:48:30 --> Model Class Initialized
INFO - 2018-05-10 15:48:30 --> Model Class Initialized
INFO - 2018-05-10 15:48:30 --> Model Class Initialized
INFO - 2018-05-10 15:48:30 --> Model Class Initialized
INFO - 2018-05-10 15:48:30 --> Model Class Initialized
INFO - 2018-05-10 15:48:30 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 15:48:30 --> Final output sent to browser
DEBUG - 2018-05-10 15:48:30 --> Total execution time: 0.1754
INFO - 2018-05-10 10:19:01 --> Config Class Initialized
INFO - 2018-05-10 10:19:01 --> Hooks Class Initialized
DEBUG - 2018-05-10 10:19:01 --> UTF-8 Support Enabled
INFO - 2018-05-10 10:19:01 --> Utf8 Class Initialized
INFO - 2018-05-10 10:19:01 --> URI Class Initialized
DEBUG - 2018-05-10 10:19:01 --> No URI present. Default controller set.
INFO - 2018-05-10 10:19:01 --> Router Class Initialized
INFO - 2018-05-10 10:19:01 --> Output Class Initialized
INFO - 2018-05-10 10:19:01 --> Security Class Initialized
DEBUG - 2018-05-10 10:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 10:19:01 --> Input Class Initialized
INFO - 2018-05-10 10:19:01 --> Language Class Initialized
INFO - 2018-05-10 10:19:01 --> Language Class Initialized
INFO - 2018-05-10 10:19:01 --> Config Class Initialized
INFO - 2018-05-10 10:19:01 --> Loader Class Initialized
INFO - 2018-05-10 15:49:01 --> Helper loaded: url_helper
INFO - 2018-05-10 15:49:01 --> Helper loaded: notification_helper
INFO - 2018-05-10 15:49:01 --> Helper loaded: settings_helper
INFO - 2018-05-10 15:49:01 --> Helper loaded: permission_helper
INFO - 2018-05-10 15:49:01 --> Helper loaded: users_helper
INFO - 2018-05-10 15:49:01 --> Database Driver Class Initialized
DEBUG - 2018-05-10 15:49:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 15:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 15:49:01 --> Helper loaded: form_helper
INFO - 2018-05-10 15:49:01 --> Form Validation Class Initialized
INFO - 2018-05-10 15:49:01 --> Controller Class Initialized
INFO - 2018-05-10 15:49:01 --> Model Class Initialized
INFO - 2018-05-10 15:49:01 --> Helper loaded: inflector_helper
INFO - 2018-05-10 15:49:01 --> Model Class Initialized
DEBUG - 2018-05-10 15:49:01 --> File loaded: /home/pr01004/public_html/application/views/login.php
INFO - 2018-05-10 15:49:01 --> Final output sent to browser
DEBUG - 2018-05-10 15:49:01 --> Total execution time: 0.0852
INFO - 2018-05-10 10:44:11 --> Config Class Initialized
INFO - 2018-05-10 10:44:11 --> Hooks Class Initialized
DEBUG - 2018-05-10 10:44:11 --> UTF-8 Support Enabled
INFO - 2018-05-10 10:44:11 --> Utf8 Class Initialized
INFO - 2018-05-10 10:44:11 --> URI Class Initialized
DEBUG - 2018-05-10 10:44:11 --> No URI present. Default controller set.
INFO - 2018-05-10 10:44:11 --> Router Class Initialized
INFO - 2018-05-10 10:44:11 --> Output Class Initialized
INFO - 2018-05-10 10:44:11 --> Security Class Initialized
DEBUG - 2018-05-10 10:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 10:44:11 --> Input Class Initialized
INFO - 2018-05-10 10:44:11 --> Language Class Initialized
INFO - 2018-05-10 10:44:11 --> Language Class Initialized
INFO - 2018-05-10 10:44:11 --> Config Class Initialized
INFO - 2018-05-10 10:44:11 --> Loader Class Initialized
INFO - 2018-05-10 16:14:11 --> Helper loaded: url_helper
INFO - 2018-05-10 16:14:11 --> Helper loaded: notification_helper
INFO - 2018-05-10 16:14:11 --> Helper loaded: settings_helper
INFO - 2018-05-10 16:14:11 --> Helper loaded: permission_helper
INFO - 2018-05-10 16:14:11 --> Helper loaded: users_helper
INFO - 2018-05-10 16:14:11 --> Database Driver Class Initialized
DEBUG - 2018-05-10 16:14:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 16:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 16:14:11 --> Helper loaded: form_helper
INFO - 2018-05-10 16:14:11 --> Form Validation Class Initialized
INFO - 2018-05-10 16:14:11 --> Controller Class Initialized
INFO - 2018-05-10 16:14:11 --> Model Class Initialized
INFO - 2018-05-10 16:14:11 --> Helper loaded: inflector_helper
INFO - 2018-05-10 16:14:11 --> Model Class Initialized
DEBUG - 2018-05-10 16:14:11 --> File loaded: /home/pr01004/public_html/application/views/login.php
INFO - 2018-05-10 16:14:11 --> Final output sent to browser
DEBUG - 2018-05-10 16:14:11 --> Total execution time: 0.0878
INFO - 2018-05-10 10:44:17 --> Config Class Initialized
INFO - 2018-05-10 10:44:17 --> Hooks Class Initialized
DEBUG - 2018-05-10 10:44:17 --> UTF-8 Support Enabled
INFO - 2018-05-10 10:44:17 --> Utf8 Class Initialized
INFO - 2018-05-10 10:44:17 --> URI Class Initialized
INFO - 2018-05-10 10:44:17 --> Router Class Initialized
INFO - 2018-05-10 10:44:17 --> Output Class Initialized
INFO - 2018-05-10 10:44:17 --> Security Class Initialized
DEBUG - 2018-05-10 10:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 10:44:17 --> Input Class Initialized
INFO - 2018-05-10 10:44:17 --> Language Class Initialized
INFO - 2018-05-10 10:44:17 --> Language Class Initialized
INFO - 2018-05-10 10:44:17 --> Config Class Initialized
INFO - 2018-05-10 10:44:17 --> Loader Class Initialized
INFO - 2018-05-10 16:14:17 --> Helper loaded: url_helper
INFO - 2018-05-10 16:14:17 --> Helper loaded: notification_helper
INFO - 2018-05-10 16:14:17 --> Helper loaded: settings_helper
INFO - 2018-05-10 16:14:17 --> Helper loaded: permission_helper
INFO - 2018-05-10 16:14:17 --> Helper loaded: users_helper
INFO - 2018-05-10 16:14:17 --> Database Driver Class Initialized
DEBUG - 2018-05-10 16:14:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 16:14:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 16:14:17 --> Helper loaded: form_helper
INFO - 2018-05-10 16:14:17 --> Form Validation Class Initialized
INFO - 2018-05-10 16:14:17 --> Controller Class Initialized
INFO - 2018-05-10 16:14:17 --> Model Class Initialized
INFO - 2018-05-10 16:14:17 --> Helper loaded: inflector_helper
INFO - 2018-05-10 16:14:17 --> Model Class Initialized
INFO - 2018-05-10 16:14:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-05-10 10:44:18 --> Config Class Initialized
INFO - 2018-05-10 10:44:18 --> Hooks Class Initialized
DEBUG - 2018-05-10 10:44:18 --> UTF-8 Support Enabled
INFO - 2018-05-10 10:44:18 --> Utf8 Class Initialized
INFO - 2018-05-10 10:44:18 --> URI Class Initialized
INFO - 2018-05-10 10:44:18 --> Router Class Initialized
INFO - 2018-05-10 10:44:18 --> Output Class Initialized
INFO - 2018-05-10 10:44:18 --> Security Class Initialized
DEBUG - 2018-05-10 10:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 10:44:18 --> Input Class Initialized
INFO - 2018-05-10 10:44:18 --> Language Class Initialized
INFO - 2018-05-10 10:44:18 --> Config Class Initialized
INFO - 2018-05-10 10:44:18 --> Hooks Class Initialized
DEBUG - 2018-05-10 10:44:18 --> UTF-8 Support Enabled
INFO - 2018-05-10 10:44:18 --> Utf8 Class Initialized
INFO - 2018-05-10 10:44:18 --> Language Class Initialized
INFO - 2018-05-10 10:44:18 --> Config Class Initialized
INFO - 2018-05-10 10:44:18 --> Loader Class Initialized
INFO - 2018-05-10 10:44:18 --> URI Class Initialized
INFO - 2018-05-10 16:14:18 --> Helper loaded: url_helper
INFO - 2018-05-10 16:14:18 --> Helper loaded: notification_helper
INFO - 2018-05-10 16:14:18 --> Helper loaded: settings_helper
INFO - 2018-05-10 16:14:18 --> Helper loaded: permission_helper
INFO - 2018-05-10 10:44:18 --> Router Class Initialized
INFO - 2018-05-10 16:14:18 --> Helper loaded: users_helper
INFO - 2018-05-10 10:44:18 --> Output Class Initialized
INFO - 2018-05-10 10:44:18 --> Security Class Initialized
DEBUG - 2018-05-10 10:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 10:44:18 --> Input Class Initialized
INFO - 2018-05-10 10:44:18 --> Language Class Initialized
INFO - 2018-05-10 16:14:18 --> Database Driver Class Initialized
DEBUG - 2018-05-10 16:14:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 16:14:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 16:14:18 --> Helper loaded: form_helper
INFO - 2018-05-10 16:14:18 --> Form Validation Class Initialized
INFO - 2018-05-10 16:14:18 --> Controller Class Initialized
DEBUG - 2018-05-10 16:14:18 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-05-10 10:44:18 --> Language Class Initialized
INFO - 2018-05-10 10:44:18 --> Config Class Initialized
INFO - 2018-05-10 10:44:18 --> Loader Class Initialized
INFO - 2018-05-10 16:14:18 --> Final output sent to browser
DEBUG - 2018-05-10 16:14:18 --> Total execution time: 0.0700
INFO - 2018-05-10 16:14:18 --> Helper loaded: url_helper
INFO - 2018-05-10 16:14:18 --> Helper loaded: notification_helper
INFO - 2018-05-10 16:14:18 --> Helper loaded: settings_helper
INFO - 2018-05-10 16:14:18 --> Helper loaded: permission_helper
INFO - 2018-05-10 16:14:18 --> Helper loaded: users_helper
INFO - 2018-05-10 16:14:18 --> Database Driver Class Initialized
DEBUG - 2018-05-10 16:14:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 16:14:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 16:14:18 --> Helper loaded: form_helper
INFO - 2018-05-10 16:14:18 --> Form Validation Class Initialized
INFO - 2018-05-10 16:14:18 --> Controller Class Initialized
INFO - 2018-05-10 16:14:18 --> Model Class Initialized
INFO - 2018-05-10 16:14:18 --> Helper loaded: inflector_helper
INFO - 2018-05-10 16:14:18 --> Model Class Initialized
INFO - 2018-05-10 16:14:18 --> Model Class Initialized
INFO - 2018-05-10 16:14:18 --> Model Class Initialized
INFO - 2018-05-10 16:14:18 --> Model Class Initialized
INFO - 2018-05-10 16:14:18 --> Model Class Initialized
DEBUG - 2018-05-10 16:14:18 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-05-10 16:14:18 --> File loaded: /home/pr01004/public_html/application/views/admin/dashboard.php
DEBUG - 2018-05-10 16:14:18 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-05-10 16:14:18 --> Final output sent to browser
DEBUG - 2018-05-10 16:14:18 --> Total execution time: 0.2602
INFO - 2018-05-10 10:46:07 --> Config Class Initialized
INFO - 2018-05-10 10:46:07 --> Hooks Class Initialized
DEBUG - 2018-05-10 10:46:07 --> UTF-8 Support Enabled
INFO - 2018-05-10 10:46:07 --> Utf8 Class Initialized
INFO - 2018-05-10 10:46:07 --> URI Class Initialized
INFO - 2018-05-10 10:46:07 --> Router Class Initialized
INFO - 2018-05-10 10:46:07 --> Output Class Initialized
INFO - 2018-05-10 10:46:07 --> Security Class Initialized
DEBUG - 2018-05-10 10:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 10:46:07 --> Input Class Initialized
INFO - 2018-05-10 10:46:07 --> Language Class Initialized
INFO - 2018-05-10 10:46:07 --> Language Class Initialized
INFO - 2018-05-10 10:46:07 --> Config Class Initialized
INFO - 2018-05-10 10:46:07 --> Loader Class Initialized
INFO - 2018-05-10 16:16:07 --> Helper loaded: url_helper
INFO - 2018-05-10 16:16:07 --> Helper loaded: notification_helper
INFO - 2018-05-10 16:16:07 --> Helper loaded: settings_helper
INFO - 2018-05-10 16:16:07 --> Helper loaded: permission_helper
INFO - 2018-05-10 16:16:07 --> Helper loaded: users_helper
INFO - 2018-05-10 16:16:07 --> Database Driver Class Initialized
DEBUG - 2018-05-10 16:16:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 16:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 16:16:07 --> Helper loaded: form_helper
INFO - 2018-05-10 16:16:07 --> Form Validation Class Initialized
INFO - 2018-05-10 16:16:07 --> Controller Class Initialized
INFO - 2018-05-10 16:16:07 --> Model Class Initialized
INFO - 2018-05-10 16:16:07 --> Helper loaded: inflector_helper
INFO - 2018-05-10 16:16:07 --> Model Class Initialized
INFO - 2018-05-10 16:16:07 --> Model Class Initialized
DEBUG - 2018-05-10 16:16:07 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-05-10 16:16:07 --> File loaded: /home/pr01004/public_html/application/views/users/usersList.php
DEBUG - 2018-05-10 16:16:07 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-05-10 16:16:07 --> Final output sent to browser
DEBUG - 2018-05-10 16:16:07 --> Total execution time: 0.1603
INFO - 2018-05-10 10:46:10 --> Config Class Initialized
INFO - 2018-05-10 10:46:10 --> Hooks Class Initialized
DEBUG - 2018-05-10 10:46:10 --> UTF-8 Support Enabled
INFO - 2018-05-10 10:46:10 --> Utf8 Class Initialized
INFO - 2018-05-10 10:46:10 --> URI Class Initialized
INFO - 2018-05-10 10:46:10 --> Router Class Initialized
INFO - 2018-05-10 10:46:10 --> Output Class Initialized
INFO - 2018-05-10 10:46:10 --> Security Class Initialized
DEBUG - 2018-05-10 10:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 10:46:10 --> Input Class Initialized
INFO - 2018-05-10 10:46:10 --> Language Class Initialized
INFO - 2018-05-10 10:46:10 --> Language Class Initialized
INFO - 2018-05-10 10:46:10 --> Config Class Initialized
INFO - 2018-05-10 10:46:10 --> Loader Class Initialized
INFO - 2018-05-10 16:16:10 --> Helper loaded: url_helper
INFO - 2018-05-10 16:16:10 --> Helper loaded: notification_helper
INFO - 2018-05-10 16:16:10 --> Helper loaded: settings_helper
INFO - 2018-05-10 16:16:10 --> Helper loaded: permission_helper
INFO - 2018-05-10 16:16:10 --> Helper loaded: users_helper
INFO - 2018-05-10 16:16:10 --> Database Driver Class Initialized
DEBUG - 2018-05-10 16:16:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 16:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 16:16:10 --> Helper loaded: form_helper
INFO - 2018-05-10 16:16:10 --> Form Validation Class Initialized
INFO - 2018-05-10 16:16:10 --> Controller Class Initialized
INFO - 2018-05-10 16:16:10 --> Model Class Initialized
INFO - 2018-05-10 16:16:10 --> Helper loaded: inflector_helper
INFO - 2018-05-10 16:16:10 --> Model Class Initialized
INFO - 2018-05-10 16:16:10 --> Model Class Initialized
INFO - 2018-05-10 16:16:10 --> Model Class Initialized
INFO - 2018-05-10 16:16:10 --> Final output sent to browser
DEBUG - 2018-05-10 16:16:10 --> Total execution time: 0.1317
INFO - 2018-05-10 10:46:12 --> Config Class Initialized
INFO - 2018-05-10 10:46:12 --> Hooks Class Initialized
DEBUG - 2018-05-10 10:46:12 --> UTF-8 Support Enabled
INFO - 2018-05-10 10:46:12 --> Utf8 Class Initialized
INFO - 2018-05-10 10:46:12 --> URI Class Initialized
INFO - 2018-05-10 10:46:12 --> Router Class Initialized
INFO - 2018-05-10 10:46:12 --> Output Class Initialized
INFO - 2018-05-10 10:46:12 --> Security Class Initialized
DEBUG - 2018-05-10 10:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 10:46:12 --> Input Class Initialized
INFO - 2018-05-10 10:46:12 --> Language Class Initialized
INFO - 2018-05-10 10:46:12 --> Language Class Initialized
INFO - 2018-05-10 10:46:12 --> Config Class Initialized
INFO - 2018-05-10 10:46:12 --> Loader Class Initialized
INFO - 2018-05-10 16:16:12 --> Helper loaded: url_helper
INFO - 2018-05-10 16:16:12 --> Helper loaded: notification_helper
INFO - 2018-05-10 16:16:12 --> Helper loaded: settings_helper
INFO - 2018-05-10 16:16:12 --> Helper loaded: permission_helper
INFO - 2018-05-10 16:16:12 --> Helper loaded: users_helper
INFO - 2018-05-10 16:16:12 --> Database Driver Class Initialized
DEBUG - 2018-05-10 16:16:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 16:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 16:16:12 --> Helper loaded: form_helper
INFO - 2018-05-10 16:16:12 --> Form Validation Class Initialized
INFO - 2018-05-10 16:16:12 --> Controller Class Initialized
INFO - 2018-05-10 16:16:12 --> Model Class Initialized
INFO - 2018-05-10 16:16:12 --> Helper loaded: inflector_helper
INFO - 2018-05-10 16:16:12 --> Model Class Initialized
INFO - 2018-05-10 16:16:12 --> Model Class Initialized
DEBUG - 2018-05-10 16:16:12 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-05-10 16:16:12 --> File loaded: /home/pr01004/public_html/application/views/credits/index.php
DEBUG - 2018-05-10 16:16:12 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-05-10 16:16:12 --> Final output sent to browser
DEBUG - 2018-05-10 16:16:12 --> Total execution time: 0.1375
INFO - 2018-05-10 10:46:16 --> Config Class Initialized
INFO - 2018-05-10 10:46:16 --> Hooks Class Initialized
DEBUG - 2018-05-10 10:46:16 --> UTF-8 Support Enabled
INFO - 2018-05-10 10:46:16 --> Utf8 Class Initialized
INFO - 2018-05-10 10:46:16 --> URI Class Initialized
INFO - 2018-05-10 10:46:16 --> Router Class Initialized
INFO - 2018-05-10 10:46:16 --> Output Class Initialized
INFO - 2018-05-10 10:46:16 --> Security Class Initialized
DEBUG - 2018-05-10 10:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 10:46:16 --> Input Class Initialized
INFO - 2018-05-10 10:46:16 --> Language Class Initialized
INFO - 2018-05-10 10:46:16 --> Language Class Initialized
INFO - 2018-05-10 10:46:16 --> Config Class Initialized
INFO - 2018-05-10 10:46:16 --> Loader Class Initialized
INFO - 2018-05-10 16:16:16 --> Helper loaded: url_helper
INFO - 2018-05-10 16:16:16 --> Helper loaded: notification_helper
INFO - 2018-05-10 16:16:16 --> Helper loaded: settings_helper
INFO - 2018-05-10 16:16:16 --> Helper loaded: permission_helper
INFO - 2018-05-10 16:16:16 --> Helper loaded: users_helper
INFO - 2018-05-10 16:16:16 --> Database Driver Class Initialized
DEBUG - 2018-05-10 16:16:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 16:16:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 16:16:16 --> Helper loaded: form_helper
INFO - 2018-05-10 16:16:16 --> Form Validation Class Initialized
INFO - 2018-05-10 16:16:16 --> Controller Class Initialized
INFO - 2018-05-10 16:16:16 --> Model Class Initialized
INFO - 2018-05-10 16:16:16 --> Helper loaded: inflector_helper
INFO - 2018-05-10 16:16:16 --> Model Class Initialized
INFO - 2018-05-10 16:16:16 --> Model Class Initialized
DEBUG - 2018-05-10 16:16:16 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-05-10 16:16:16 --> File loaded: /home/pr01004/public_html/application/views/credits/create.php
DEBUG - 2018-05-10 16:16:16 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-05-10 16:16:16 --> Final output sent to browser
DEBUG - 2018-05-10 16:16:16 --> Total execution time: 0.0934
INFO - 2018-05-10 10:47:27 --> Config Class Initialized
INFO - 2018-05-10 10:47:27 --> Hooks Class Initialized
DEBUG - 2018-05-10 10:47:27 --> UTF-8 Support Enabled
INFO - 2018-05-10 10:47:27 --> Utf8 Class Initialized
INFO - 2018-05-10 10:47:27 --> URI Class Initialized
INFO - 2018-05-10 10:47:27 --> Router Class Initialized
INFO - 2018-05-10 10:47:27 --> Output Class Initialized
INFO - 2018-05-10 10:47:27 --> Security Class Initialized
DEBUG - 2018-05-10 10:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 10:47:27 --> Input Class Initialized
INFO - 2018-05-10 10:47:27 --> Language Class Initialized
INFO - 2018-05-10 10:47:27 --> Language Class Initialized
INFO - 2018-05-10 10:47:27 --> Config Class Initialized
INFO - 2018-05-10 10:47:27 --> Loader Class Initialized
INFO - 2018-05-10 16:17:27 --> Helper loaded: url_helper
INFO - 2018-05-10 16:17:27 --> Helper loaded: notification_helper
INFO - 2018-05-10 16:17:27 --> Helper loaded: settings_helper
INFO - 2018-05-10 16:17:27 --> Helper loaded: permission_helper
INFO - 2018-05-10 16:17:27 --> Helper loaded: users_helper
INFO - 2018-05-10 16:17:27 --> Database Driver Class Initialized
DEBUG - 2018-05-10 16:17:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 16:17:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 16:17:27 --> Helper loaded: form_helper
INFO - 2018-05-10 16:17:27 --> Form Validation Class Initialized
INFO - 2018-05-10 16:17:27 --> Controller Class Initialized
INFO - 2018-05-10 16:17:27 --> Model Class Initialized
INFO - 2018-05-10 16:17:27 --> Helper loaded: inflector_helper
INFO - 2018-05-10 16:17:27 --> Model Class Initialized
INFO - 2018-05-10 16:17:27 --> Model Class Initialized
INFO - 2018-05-10 10:47:28 --> Config Class Initialized
INFO - 2018-05-10 10:47:28 --> Hooks Class Initialized
DEBUG - 2018-05-10 10:47:28 --> UTF-8 Support Enabled
INFO - 2018-05-10 10:47:28 --> Utf8 Class Initialized
INFO - 2018-05-10 10:47:28 --> URI Class Initialized
INFO - 2018-05-10 10:47:28 --> Router Class Initialized
INFO - 2018-05-10 10:47:28 --> Output Class Initialized
INFO - 2018-05-10 10:47:28 --> Security Class Initialized
DEBUG - 2018-05-10 10:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 10:47:28 --> Input Class Initialized
INFO - 2018-05-10 10:47:28 --> Language Class Initialized
INFO - 2018-05-10 10:47:28 --> Language Class Initialized
INFO - 2018-05-10 10:47:28 --> Config Class Initialized
INFO - 2018-05-10 10:47:28 --> Loader Class Initialized
INFO - 2018-05-10 16:17:28 --> Helper loaded: url_helper
INFO - 2018-05-10 16:17:28 --> Helper loaded: notification_helper
INFO - 2018-05-10 16:17:28 --> Helper loaded: settings_helper
INFO - 2018-05-10 16:17:28 --> Helper loaded: permission_helper
INFO - 2018-05-10 16:17:28 --> Helper loaded: users_helper
INFO - 2018-05-10 16:17:28 --> Database Driver Class Initialized
DEBUG - 2018-05-10 16:17:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 16:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 16:17:28 --> Helper loaded: form_helper
INFO - 2018-05-10 16:17:28 --> Form Validation Class Initialized
INFO - 2018-05-10 16:17:28 --> Controller Class Initialized
INFO - 2018-05-10 16:17:28 --> Model Class Initialized
INFO - 2018-05-10 16:17:28 --> Helper loaded: inflector_helper
INFO - 2018-05-10 16:17:28 --> Model Class Initialized
DEBUG - 2018-05-10 16:17:28 --> File loaded: /home/pr01004/public_html/application/views/login.php
INFO - 2018-05-10 16:17:28 --> Final output sent to browser
DEBUG - 2018-05-10 16:17:28 --> Total execution time: 0.0885
INFO - 2018-05-10 10:53:03 --> Config Class Initialized
INFO - 2018-05-10 10:53:03 --> Hooks Class Initialized
DEBUG - 2018-05-10 10:53:03 --> UTF-8 Support Enabled
INFO - 2018-05-10 10:53:03 --> Utf8 Class Initialized
INFO - 2018-05-10 10:53:03 --> URI Class Initialized
INFO - 2018-05-10 10:53:03 --> Router Class Initialized
INFO - 2018-05-10 10:53:03 --> Output Class Initialized
INFO - 2018-05-10 10:53:03 --> Security Class Initialized
DEBUG - 2018-05-10 10:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 10:53:03 --> Input Class Initialized
INFO - 2018-05-10 10:53:03 --> Language Class Initialized
INFO - 2018-05-10 10:53:03 --> Language Class Initialized
INFO - 2018-05-10 10:53:03 --> Config Class Initialized
INFO - 2018-05-10 10:53:03 --> Loader Class Initialized
INFO - 2018-05-10 16:23:03 --> Helper loaded: url_helper
INFO - 2018-05-10 16:23:03 --> Helper loaded: notification_helper
INFO - 2018-05-10 16:23:03 --> Helper loaded: settings_helper
INFO - 2018-05-10 16:23:03 --> Helper loaded: permission_helper
INFO - 2018-05-10 16:23:03 --> Helper loaded: users_helper
INFO - 2018-05-10 16:23:03 --> Database Driver Class Initialized
DEBUG - 2018-05-10 16:23:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 16:23:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 16:23:03 --> Helper loaded: form_helper
INFO - 2018-05-10 16:23:03 --> Form Validation Class Initialized
INFO - 2018-05-10 16:23:03 --> Controller Class Initialized
INFO - 2018-05-10 16:23:03 --> Model Class Initialized
INFO - 2018-05-10 16:23:03 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 16:23:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 16:23:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 16:23:03 --> Model Class Initialized
INFO - 2018-05-10 16:23:03 --> Model Class Initialized
INFO - 2018-05-10 16:23:03 --> Model Class Initialized
INFO - 2018-05-10 16:23:03 --> Model Class Initialized
INFO - 2018-05-10 16:23:03 --> Model Class Initialized
INFO - 2018-05-10 16:23:03 --> Model Class Initialized
INFO - 2018-05-10 16:23:03 --> Model Class Initialized
INFO - 2018-05-10 16:23:03 --> Model Class Initialized
INFO - 2018-05-10 16:23:03 --> Model Class Initialized
INFO - 2018-05-10 16:23:03 --> Model Class Initialized
INFO - 2018-05-10 16:23:03 --> Model Class Initialized
INFO - 2018-05-10 16:23:03 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 16:23:03 --> Model Class Initialized
INFO - 2018-05-10 16:23:03 --> Final output sent to browser
DEBUG - 2018-05-10 16:23:03 --> Total execution time: 0.1188
INFO - 2018-05-10 10:53:04 --> Config Class Initialized
INFO - 2018-05-10 10:53:04 --> Hooks Class Initialized
DEBUG - 2018-05-10 10:53:04 --> UTF-8 Support Enabled
INFO - 2018-05-10 10:53:04 --> Utf8 Class Initialized
INFO - 2018-05-10 10:53:04 --> URI Class Initialized
INFO - 2018-05-10 10:53:04 --> Router Class Initialized
INFO - 2018-05-10 10:53:04 --> Output Class Initialized
INFO - 2018-05-10 10:53:04 --> Security Class Initialized
DEBUG - 2018-05-10 10:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 10:53:04 --> Input Class Initialized
INFO - 2018-05-10 10:53:04 --> Language Class Initialized
INFO - 2018-05-10 10:53:04 --> Language Class Initialized
INFO - 2018-05-10 10:53:04 --> Config Class Initialized
INFO - 2018-05-10 10:53:04 --> Loader Class Initialized
INFO - 2018-05-10 16:23:04 --> Helper loaded: url_helper
INFO - 2018-05-10 16:23:04 --> Helper loaded: notification_helper
INFO - 2018-05-10 16:23:04 --> Helper loaded: settings_helper
INFO - 2018-05-10 16:23:04 --> Helper loaded: permission_helper
INFO - 2018-05-10 16:23:04 --> Helper loaded: users_helper
INFO - 2018-05-10 16:23:04 --> Database Driver Class Initialized
DEBUG - 2018-05-10 16:23:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 16:23:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 16:23:04 --> Helper loaded: form_helper
INFO - 2018-05-10 16:23:04 --> Form Validation Class Initialized
INFO - 2018-05-10 16:23:04 --> Controller Class Initialized
INFO - 2018-05-10 16:23:04 --> Model Class Initialized
INFO - 2018-05-10 16:23:04 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 16:23:04 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 16:23:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 16:23:04 --> Model Class Initialized
INFO - 2018-05-10 16:23:04 --> Model Class Initialized
INFO - 2018-05-10 16:23:04 --> Model Class Initialized
INFO - 2018-05-10 16:23:04 --> Model Class Initialized
INFO - 2018-05-10 16:23:04 --> Model Class Initialized
INFO - 2018-05-10 16:23:04 --> Model Class Initialized
INFO - 2018-05-10 16:23:04 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 16:23:04 --> Model Class Initialized
INFO - 2018-05-10 16:23:04 --> Final output sent to browser
DEBUG - 2018-05-10 16:23:04 --> Total execution time: 0.0866
INFO - 2018-05-10 10:53:07 --> Config Class Initialized
INFO - 2018-05-10 10:53:07 --> Hooks Class Initialized
DEBUG - 2018-05-10 10:53:07 --> UTF-8 Support Enabled
INFO - 2018-05-10 10:53:07 --> Utf8 Class Initialized
INFO - 2018-05-10 10:53:07 --> URI Class Initialized
INFO - 2018-05-10 10:53:07 --> Router Class Initialized
INFO - 2018-05-10 10:53:07 --> Output Class Initialized
INFO - 2018-05-10 10:53:07 --> Security Class Initialized
DEBUG - 2018-05-10 10:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 10:53:07 --> Input Class Initialized
INFO - 2018-05-10 10:53:07 --> Language Class Initialized
INFO - 2018-05-10 10:53:07 --> Language Class Initialized
INFO - 2018-05-10 10:53:07 --> Config Class Initialized
INFO - 2018-05-10 10:53:07 --> Loader Class Initialized
INFO - 2018-05-10 16:23:07 --> Helper loaded: url_helper
INFO - 2018-05-10 16:23:07 --> Helper loaded: notification_helper
INFO - 2018-05-10 16:23:07 --> Helper loaded: settings_helper
INFO - 2018-05-10 16:23:07 --> Helper loaded: permission_helper
INFO - 2018-05-10 16:23:07 --> Helper loaded: users_helper
INFO - 2018-05-10 16:23:07 --> Database Driver Class Initialized
DEBUG - 2018-05-10 16:23:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 16:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 16:23:07 --> Helper loaded: form_helper
INFO - 2018-05-10 16:23:07 --> Form Validation Class Initialized
INFO - 2018-05-10 16:23:07 --> Controller Class Initialized
INFO - 2018-05-10 16:23:07 --> Model Class Initialized
INFO - 2018-05-10 16:23:07 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 16:23:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 16:23:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 16:23:07 --> Model Class Initialized
INFO - 2018-05-10 16:23:07 --> Model Class Initialized
INFO - 2018-05-10 16:23:07 --> Model Class Initialized
INFO - 2018-05-10 16:23:07 --> Model Class Initialized
INFO - 2018-05-10 16:23:07 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 16:23:07 --> Final output sent to browser
DEBUG - 2018-05-10 16:23:07 --> Total execution time: 0.1051
INFO - 2018-05-10 10:53:08 --> Config Class Initialized
INFO - 2018-05-10 10:53:08 --> Hooks Class Initialized
DEBUG - 2018-05-10 10:53:08 --> UTF-8 Support Enabled
INFO - 2018-05-10 10:53:08 --> Utf8 Class Initialized
INFO - 2018-05-10 10:53:08 --> URI Class Initialized
INFO - 2018-05-10 10:53:08 --> Router Class Initialized
INFO - 2018-05-10 10:53:08 --> Output Class Initialized
INFO - 2018-05-10 10:53:08 --> Security Class Initialized
DEBUG - 2018-05-10 10:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 10:53:08 --> Input Class Initialized
INFO - 2018-05-10 10:53:08 --> Language Class Initialized
INFO - 2018-05-10 10:53:08 --> Language Class Initialized
INFO - 2018-05-10 10:53:08 --> Config Class Initialized
INFO - 2018-05-10 10:53:08 --> Loader Class Initialized
INFO - 2018-05-10 16:23:08 --> Helper loaded: url_helper
INFO - 2018-05-10 16:23:08 --> Helper loaded: notification_helper
INFO - 2018-05-10 16:23:08 --> Helper loaded: settings_helper
INFO - 2018-05-10 16:23:08 --> Helper loaded: permission_helper
INFO - 2018-05-10 16:23:08 --> Helper loaded: users_helper
INFO - 2018-05-10 16:23:08 --> Database Driver Class Initialized
DEBUG - 2018-05-10 16:23:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 16:23:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 16:23:08 --> Helper loaded: form_helper
INFO - 2018-05-10 16:23:08 --> Form Validation Class Initialized
INFO - 2018-05-10 16:23:08 --> Controller Class Initialized
INFO - 2018-05-10 16:23:08 --> Model Class Initialized
INFO - 2018-05-10 16:23:08 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 16:23:08 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 16:23:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 16:23:08 --> Model Class Initialized
INFO - 2018-05-10 16:23:08 --> Model Class Initialized
INFO - 2018-05-10 16:23:08 --> Model Class Initialized
INFO - 2018-05-10 16:23:08 --> Model Class Initialized
INFO - 2018-05-10 16:23:08 --> Model Class Initialized
INFO - 2018-05-10 16:23:08 --> Model Class Initialized
INFO - 2018-05-10 16:23:08 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 16:23:08 --> Final output sent to browser
DEBUG - 2018-05-10 16:23:08 --> Total execution time: 0.1229
INFO - 2018-05-10 10:53:10 --> Config Class Initialized
INFO - 2018-05-10 10:53:10 --> Hooks Class Initialized
DEBUG - 2018-05-10 10:53:10 --> UTF-8 Support Enabled
INFO - 2018-05-10 10:53:10 --> Utf8 Class Initialized
INFO - 2018-05-10 10:53:10 --> URI Class Initialized
INFO - 2018-05-10 10:53:10 --> Router Class Initialized
INFO - 2018-05-10 10:53:10 --> Output Class Initialized
INFO - 2018-05-10 10:53:10 --> Security Class Initialized
DEBUG - 2018-05-10 10:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 10:53:10 --> Input Class Initialized
INFO - 2018-05-10 10:53:10 --> Language Class Initialized
INFO - 2018-05-10 10:53:10 --> Language Class Initialized
INFO - 2018-05-10 10:53:10 --> Config Class Initialized
INFO - 2018-05-10 10:53:10 --> Loader Class Initialized
INFO - 2018-05-10 16:23:10 --> Helper loaded: url_helper
INFO - 2018-05-10 16:23:10 --> Helper loaded: notification_helper
INFO - 2018-05-10 16:23:10 --> Helper loaded: settings_helper
INFO - 2018-05-10 16:23:10 --> Helper loaded: permission_helper
INFO - 2018-05-10 16:23:10 --> Helper loaded: users_helper
INFO - 2018-05-10 16:23:10 --> Database Driver Class Initialized
DEBUG - 2018-05-10 16:23:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 16:23:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 16:23:10 --> Helper loaded: form_helper
INFO - 2018-05-10 16:23:10 --> Form Validation Class Initialized
INFO - 2018-05-10 16:23:10 --> Controller Class Initialized
INFO - 2018-05-10 16:23:10 --> Model Class Initialized
INFO - 2018-05-10 16:23:10 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 16:23:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 16:23:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 16:23:10 --> Model Class Initialized
INFO - 2018-05-10 16:23:10 --> Model Class Initialized
INFO - 2018-05-10 16:23:10 --> Model Class Initialized
INFO - 2018-05-10 16:23:10 --> Model Class Initialized
INFO - 2018-05-10 16:23:10 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 16:23:10 --> Model Class Initialized
INFO - 2018-05-10 16:23:10 --> Final output sent to browser
DEBUG - 2018-05-10 16:23:10 --> Total execution time: 0.1081
INFO - 2018-05-10 10:55:12 --> Config Class Initialized
INFO - 2018-05-10 10:55:12 --> Hooks Class Initialized
DEBUG - 2018-05-10 10:55:12 --> UTF-8 Support Enabled
INFO - 2018-05-10 10:55:12 --> Utf8 Class Initialized
INFO - 2018-05-10 10:55:12 --> URI Class Initialized
INFO - 2018-05-10 10:55:12 --> Router Class Initialized
INFO - 2018-05-10 10:55:12 --> Output Class Initialized
INFO - 2018-05-10 10:55:12 --> Security Class Initialized
DEBUG - 2018-05-10 10:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 10:55:12 --> Input Class Initialized
INFO - 2018-05-10 10:55:12 --> Language Class Initialized
INFO - 2018-05-10 10:55:12 --> Language Class Initialized
INFO - 2018-05-10 10:55:12 --> Config Class Initialized
INFO - 2018-05-10 10:55:12 --> Loader Class Initialized
INFO - 2018-05-10 16:25:12 --> Helper loaded: url_helper
INFO - 2018-05-10 16:25:12 --> Helper loaded: notification_helper
INFO - 2018-05-10 16:25:12 --> Helper loaded: settings_helper
INFO - 2018-05-10 16:25:12 --> Helper loaded: permission_helper
INFO - 2018-05-10 16:25:12 --> Helper loaded: users_helper
INFO - 2018-05-10 16:25:12 --> Database Driver Class Initialized
DEBUG - 2018-05-10 16:25:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 16:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 16:25:12 --> Helper loaded: form_helper
INFO - 2018-05-10 16:25:12 --> Form Validation Class Initialized
INFO - 2018-05-10 16:25:12 --> Controller Class Initialized
INFO - 2018-05-10 16:25:12 --> Model Class Initialized
INFO - 2018-05-10 16:25:12 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 16:25:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 16:25:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 16:25:12 --> Model Class Initialized
INFO - 2018-05-10 16:25:12 --> Model Class Initialized
INFO - 2018-05-10 16:25:12 --> Model Class Initialized
INFO - 2018-05-10 16:25:12 --> Model Class Initialized
INFO - 2018-05-10 16:25:12 --> Model Class Initialized
INFO - 2018-05-10 16:25:12 --> Model Class Initialized
INFO - 2018-05-10 16:25:12 --> Model Class Initialized
INFO - 2018-05-10 16:25:12 --> Model Class Initialized
INFO - 2018-05-10 16:25:12 --> Model Class Initialized
INFO - 2018-05-10 16:25:12 --> Model Class Initialized
INFO - 2018-05-10 16:25:12 --> Model Class Initialized
INFO - 2018-05-10 16:25:12 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 16:25:12 --> Model Class Initialized
INFO - 2018-05-10 16:25:12 --> Final output sent to browser
DEBUG - 2018-05-10 16:25:12 --> Total execution time: 0.1161
INFO - 2018-05-10 10:55:12 --> Config Class Initialized
INFO - 2018-05-10 10:55:12 --> Hooks Class Initialized
DEBUG - 2018-05-10 10:55:12 --> UTF-8 Support Enabled
INFO - 2018-05-10 10:55:12 --> Utf8 Class Initialized
INFO - 2018-05-10 10:55:12 --> URI Class Initialized
INFO - 2018-05-10 10:55:12 --> Router Class Initialized
INFO - 2018-05-10 10:55:12 --> Output Class Initialized
INFO - 2018-05-10 10:55:12 --> Security Class Initialized
DEBUG - 2018-05-10 10:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 10:55:12 --> Input Class Initialized
INFO - 2018-05-10 10:55:12 --> Language Class Initialized
INFO - 2018-05-10 10:55:12 --> Language Class Initialized
INFO - 2018-05-10 10:55:12 --> Config Class Initialized
INFO - 2018-05-10 10:55:12 --> Loader Class Initialized
INFO - 2018-05-10 16:25:12 --> Helper loaded: url_helper
INFO - 2018-05-10 16:25:12 --> Helper loaded: notification_helper
INFO - 2018-05-10 16:25:12 --> Helper loaded: settings_helper
INFO - 2018-05-10 16:25:12 --> Helper loaded: permission_helper
INFO - 2018-05-10 16:25:12 --> Helper loaded: users_helper
INFO - 2018-05-10 16:25:12 --> Database Driver Class Initialized
DEBUG - 2018-05-10 16:25:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 16:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 16:25:12 --> Helper loaded: form_helper
INFO - 2018-05-10 16:25:12 --> Form Validation Class Initialized
INFO - 2018-05-10 16:25:12 --> Controller Class Initialized
INFO - 2018-05-10 16:25:12 --> Model Class Initialized
INFO - 2018-05-10 16:25:12 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 16:25:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 16:25:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 16:25:12 --> Model Class Initialized
INFO - 2018-05-10 16:25:12 --> Model Class Initialized
INFO - 2018-05-10 16:25:12 --> Model Class Initialized
INFO - 2018-05-10 16:25:12 --> Model Class Initialized
INFO - 2018-05-10 16:25:12 --> Model Class Initialized
INFO - 2018-05-10 16:25:12 --> Model Class Initialized
INFO - 2018-05-10 16:25:12 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 16:25:12 --> Model Class Initialized
INFO - 2018-05-10 16:25:12 --> Final output sent to browser
DEBUG - 2018-05-10 16:25:12 --> Total execution time: 0.1053
INFO - 2018-05-10 10:55:16 --> Config Class Initialized
INFO - 2018-05-10 10:55:16 --> Hooks Class Initialized
DEBUG - 2018-05-10 10:55:16 --> UTF-8 Support Enabled
INFO - 2018-05-10 10:55:16 --> Utf8 Class Initialized
INFO - 2018-05-10 10:55:16 --> Config Class Initialized
INFO - 2018-05-10 10:55:16 --> Hooks Class Initialized
INFO - 2018-05-10 10:55:16 --> URI Class Initialized
DEBUG - 2018-05-10 10:55:16 --> UTF-8 Support Enabled
INFO - 2018-05-10 10:55:16 --> Utf8 Class Initialized
INFO - 2018-05-10 10:55:16 --> Router Class Initialized
INFO - 2018-05-10 10:55:16 --> URI Class Initialized
INFO - 2018-05-10 10:55:16 --> Output Class Initialized
INFO - 2018-05-10 10:55:16 --> Router Class Initialized
INFO - 2018-05-10 10:55:16 --> Security Class Initialized
INFO - 2018-05-10 10:55:16 --> Output Class Initialized
DEBUG - 2018-05-10 10:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 10:55:16 --> Input Class Initialized
INFO - 2018-05-10 10:55:16 --> Language Class Initialized
INFO - 2018-05-10 10:55:16 --> Security Class Initialized
DEBUG - 2018-05-10 10:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 10:55:16 --> Input Class Initialized
INFO - 2018-05-10 10:55:16 --> Language Class Initialized
INFO - 2018-05-10 10:55:16 --> Language Class Initialized
INFO - 2018-05-10 10:55:16 --> Config Class Initialized
INFO - 2018-05-10 10:55:16 --> Loader Class Initialized
INFO - 2018-05-10 16:25:16 --> Helper loaded: url_helper
INFO - 2018-05-10 16:25:16 --> Helper loaded: notification_helper
INFO - 2018-05-10 16:25:16 --> Helper loaded: settings_helper
INFO - 2018-05-10 16:25:16 --> Helper loaded: permission_helper
INFO - 2018-05-10 16:25:16 --> Helper loaded: users_helper
INFO - 2018-05-10 10:55:16 --> Language Class Initialized
INFO - 2018-05-10 10:55:16 --> Config Class Initialized
INFO - 2018-05-10 10:55:16 --> Loader Class Initialized
INFO - 2018-05-10 16:25:16 --> Helper loaded: url_helper
INFO - 2018-05-10 16:25:16 --> Helper loaded: notification_helper
INFO - 2018-05-10 16:25:16 --> Helper loaded: settings_helper
INFO - 2018-05-10 16:25:16 --> Helper loaded: permission_helper
INFO - 2018-05-10 16:25:16 --> Helper loaded: users_helper
INFO - 2018-05-10 16:25:16 --> Database Driver Class Initialized
DEBUG - 2018-05-10 16:25:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 16:25:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 16:25:16 --> Helper loaded: form_helper
INFO - 2018-05-10 16:25:16 --> Form Validation Class Initialized
INFO - 2018-05-10 16:25:16 --> Controller Class Initialized
INFO - 2018-05-10 16:25:16 --> Database Driver Class Initialized
DEBUG - 2018-05-10 16:25:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 16:25:16 --> Model Class Initialized
INFO - 2018-05-10 16:25:16 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 16:25:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 16:25:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 16:25:16 --> Model Class Initialized
INFO - 2018-05-10 16:25:16 --> Model Class Initialized
INFO - 2018-05-10 16:25:16 --> Model Class Initialized
INFO - 2018-05-10 16:25:16 --> Model Class Initialized
INFO - 2018-05-10 16:25:16 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 16:25:16 --> Final output sent to browser
DEBUG - 2018-05-10 16:25:16 --> Total execution time: 0.1084
INFO - 2018-05-10 16:25:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 16:25:16 --> Helper loaded: form_helper
INFO - 2018-05-10 16:25:16 --> Form Validation Class Initialized
INFO - 2018-05-10 16:25:16 --> Controller Class Initialized
INFO - 2018-05-10 16:25:16 --> Model Class Initialized
INFO - 2018-05-10 16:25:16 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 16:25:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 16:25:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 16:25:16 --> Model Class Initialized
INFO - 2018-05-10 16:25:16 --> Model Class Initialized
INFO - 2018-05-10 16:25:16 --> Model Class Initialized
INFO - 2018-05-10 16:25:16 --> Model Class Initialized
INFO - 2018-05-10 16:25:16 --> Model Class Initialized
INFO - 2018-05-10 16:25:16 --> Model Class Initialized
INFO - 2018-05-10 16:25:16 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 16:25:16 --> Final output sent to browser
DEBUG - 2018-05-10 16:25:16 --> Total execution time: 0.1385
INFO - 2018-05-10 10:55:19 --> Config Class Initialized
INFO - 2018-05-10 10:55:19 --> Hooks Class Initialized
DEBUG - 2018-05-10 10:55:19 --> UTF-8 Support Enabled
INFO - 2018-05-10 10:55:19 --> Utf8 Class Initialized
INFO - 2018-05-10 10:55:19 --> URI Class Initialized
INFO - 2018-05-10 10:55:19 --> Router Class Initialized
INFO - 2018-05-10 10:55:19 --> Output Class Initialized
INFO - 2018-05-10 10:55:19 --> Security Class Initialized
DEBUG - 2018-05-10 10:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 10:55:19 --> Input Class Initialized
INFO - 2018-05-10 10:55:19 --> Language Class Initialized
INFO - 2018-05-10 10:55:19 --> Language Class Initialized
INFO - 2018-05-10 10:55:19 --> Config Class Initialized
INFO - 2018-05-10 10:55:19 --> Loader Class Initialized
INFO - 2018-05-10 16:25:19 --> Helper loaded: url_helper
INFO - 2018-05-10 16:25:19 --> Helper loaded: notification_helper
INFO - 2018-05-10 16:25:19 --> Helper loaded: settings_helper
INFO - 2018-05-10 16:25:19 --> Helper loaded: permission_helper
INFO - 2018-05-10 16:25:19 --> Helper loaded: users_helper
INFO - 2018-05-10 16:25:19 --> Database Driver Class Initialized
DEBUG - 2018-05-10 16:25:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 16:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 16:25:19 --> Helper loaded: form_helper
INFO - 2018-05-10 16:25:19 --> Form Validation Class Initialized
INFO - 2018-05-10 16:25:19 --> Controller Class Initialized
INFO - 2018-05-10 16:25:19 --> Model Class Initialized
INFO - 2018-05-10 16:25:19 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 16:25:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 16:25:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 16:25:19 --> Model Class Initialized
INFO - 2018-05-10 16:25:19 --> Model Class Initialized
INFO - 2018-05-10 16:25:19 --> Model Class Initialized
INFO - 2018-05-10 16:25:19 --> Model Class Initialized
INFO - 2018-05-10 16:25:19 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 16:25:19 --> Model Class Initialized
INFO - 2018-05-10 16:25:19 --> Final output sent to browser
DEBUG - 2018-05-10 16:25:19 --> Total execution time: 0.1064
INFO - 2018-05-10 11:02:45 --> Config Class Initialized
INFO - 2018-05-10 11:02:45 --> Hooks Class Initialized
DEBUG - 2018-05-10 11:02:45 --> UTF-8 Support Enabled
INFO - 2018-05-10 11:02:45 --> Utf8 Class Initialized
INFO - 2018-05-10 11:02:45 --> URI Class Initialized
INFO - 2018-05-10 11:02:45 --> Router Class Initialized
INFO - 2018-05-10 11:02:45 --> Output Class Initialized
INFO - 2018-05-10 11:02:45 --> Security Class Initialized
DEBUG - 2018-05-10 11:02:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 11:02:45 --> Input Class Initialized
INFO - 2018-05-10 11:02:45 --> Language Class Initialized
INFO - 2018-05-10 11:02:45 --> Language Class Initialized
INFO - 2018-05-10 11:02:45 --> Config Class Initialized
INFO - 2018-05-10 11:02:45 --> Loader Class Initialized
INFO - 2018-05-10 16:32:45 --> Helper loaded: url_helper
INFO - 2018-05-10 16:32:45 --> Helper loaded: notification_helper
INFO - 2018-05-10 16:32:45 --> Helper loaded: settings_helper
INFO - 2018-05-10 16:32:45 --> Helper loaded: permission_helper
INFO - 2018-05-10 16:32:45 --> Helper loaded: users_helper
INFO - 2018-05-10 16:32:45 --> Database Driver Class Initialized
DEBUG - 2018-05-10 16:32:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 16:32:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 16:32:45 --> Helper loaded: form_helper
INFO - 2018-05-10 16:32:45 --> Form Validation Class Initialized
INFO - 2018-05-10 16:32:45 --> Controller Class Initialized
INFO - 2018-05-10 16:32:45 --> Model Class Initialized
INFO - 2018-05-10 16:32:45 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 16:32:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 16:32:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 16:32:45 --> Model Class Initialized
INFO - 2018-05-10 16:32:45 --> Model Class Initialized
INFO - 2018-05-10 16:32:45 --> Model Class Initialized
INFO - 2018-05-10 16:32:45 --> Model Class Initialized
INFO - 2018-05-10 16:32:45 --> Model Class Initialized
INFO - 2018-05-10 16:32:45 --> Model Class Initialized
INFO - 2018-05-10 16:32:45 --> Model Class Initialized
INFO - 2018-05-10 16:32:45 --> Model Class Initialized
INFO - 2018-05-10 16:32:45 --> Model Class Initialized
INFO - 2018-05-10 16:32:45 --> Model Class Initialized
INFO - 2018-05-10 16:32:45 --> Model Class Initialized
INFO - 2018-05-10 16:32:45 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 16:32:45 --> Model Class Initialized
INFO - 2018-05-10 16:32:45 --> Final output sent to browser
DEBUG - 2018-05-10 16:32:45 --> Total execution time: 0.1291
INFO - 2018-05-10 11:02:46 --> Config Class Initialized
INFO - 2018-05-10 11:02:46 --> Hooks Class Initialized
DEBUG - 2018-05-10 11:02:46 --> UTF-8 Support Enabled
INFO - 2018-05-10 11:02:46 --> Utf8 Class Initialized
INFO - 2018-05-10 11:02:46 --> URI Class Initialized
INFO - 2018-05-10 11:02:46 --> Router Class Initialized
INFO - 2018-05-10 11:02:46 --> Output Class Initialized
INFO - 2018-05-10 11:02:46 --> Security Class Initialized
DEBUG - 2018-05-10 11:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 11:02:46 --> Input Class Initialized
INFO - 2018-05-10 11:02:46 --> Language Class Initialized
INFO - 2018-05-10 11:02:46 --> Language Class Initialized
INFO - 2018-05-10 11:02:46 --> Config Class Initialized
INFO - 2018-05-10 11:02:46 --> Loader Class Initialized
INFO - 2018-05-10 16:32:46 --> Helper loaded: url_helper
INFO - 2018-05-10 16:32:46 --> Helper loaded: notification_helper
INFO - 2018-05-10 16:32:46 --> Helper loaded: settings_helper
INFO - 2018-05-10 16:32:46 --> Helper loaded: permission_helper
INFO - 2018-05-10 16:32:46 --> Helper loaded: users_helper
INFO - 2018-05-10 16:32:46 --> Database Driver Class Initialized
DEBUG - 2018-05-10 16:32:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 16:32:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 16:32:46 --> Helper loaded: form_helper
INFO - 2018-05-10 16:32:46 --> Form Validation Class Initialized
INFO - 2018-05-10 16:32:46 --> Controller Class Initialized
INFO - 2018-05-10 16:32:46 --> Model Class Initialized
INFO - 2018-05-10 16:32:46 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 16:32:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 16:32:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 16:32:46 --> Model Class Initialized
INFO - 2018-05-10 16:32:46 --> Model Class Initialized
INFO - 2018-05-10 16:32:46 --> Model Class Initialized
INFO - 2018-05-10 16:32:46 --> Model Class Initialized
INFO - 2018-05-10 16:32:46 --> Model Class Initialized
INFO - 2018-05-10 16:32:46 --> Model Class Initialized
INFO - 2018-05-10 16:32:46 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 16:32:46 --> Model Class Initialized
INFO - 2018-05-10 16:32:46 --> Final output sent to browser
DEBUG - 2018-05-10 16:32:46 --> Total execution time: 0.1211
INFO - 2018-05-10 11:03:23 --> Config Class Initialized
INFO - 2018-05-10 11:03:23 --> Hooks Class Initialized
DEBUG - 2018-05-10 11:03:23 --> UTF-8 Support Enabled
INFO - 2018-05-10 11:03:23 --> Utf8 Class Initialized
INFO - 2018-05-10 11:03:23 --> URI Class Initialized
INFO - 2018-05-10 11:03:23 --> Router Class Initialized
INFO - 2018-05-10 11:03:23 --> Output Class Initialized
INFO - 2018-05-10 11:03:23 --> Security Class Initialized
DEBUG - 2018-05-10 11:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 11:03:23 --> Input Class Initialized
INFO - 2018-05-10 11:03:23 --> Language Class Initialized
INFO - 2018-05-10 11:03:23 --> Language Class Initialized
INFO - 2018-05-10 11:03:23 --> Config Class Initialized
INFO - 2018-05-10 11:03:23 --> Loader Class Initialized
INFO - 2018-05-10 16:33:23 --> Helper loaded: url_helper
INFO - 2018-05-10 16:33:23 --> Helper loaded: notification_helper
INFO - 2018-05-10 16:33:23 --> Helper loaded: settings_helper
INFO - 2018-05-10 11:03:23 --> Config Class Initialized
INFO - 2018-05-10 16:33:23 --> Helper loaded: permission_helper
INFO - 2018-05-10 11:03:23 --> Hooks Class Initialized
INFO - 2018-05-10 16:33:23 --> Helper loaded: users_helper
DEBUG - 2018-05-10 11:03:23 --> UTF-8 Support Enabled
INFO - 2018-05-10 11:03:23 --> Utf8 Class Initialized
INFO - 2018-05-10 11:03:23 --> URI Class Initialized
INFO - 2018-05-10 16:33:23 --> Database Driver Class Initialized
DEBUG - 2018-05-10 16:33:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 16:33:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 11:03:23 --> Router Class Initialized
INFO - 2018-05-10 11:03:23 --> Output Class Initialized
INFO - 2018-05-10 16:33:23 --> Helper loaded: form_helper
INFO - 2018-05-10 16:33:23 --> Form Validation Class Initialized
INFO - 2018-05-10 16:33:23 --> Controller Class Initialized
INFO - 2018-05-10 11:03:23 --> Security Class Initialized
INFO - 2018-05-10 16:33:23 --> Model Class Initialized
DEBUG - 2018-05-10 11:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 11:03:23 --> Input Class Initialized
INFO - 2018-05-10 16:33:23 --> Helper loaded: inflector_helper
INFO - 2018-05-10 11:03:23 --> Language Class Initialized
DEBUG - 2018-05-10 16:33:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 16:33:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 16:33:23 --> Model Class Initialized
INFO - 2018-05-10 16:33:23 --> Model Class Initialized
INFO - 2018-05-10 16:33:23 --> Model Class Initialized
INFO - 2018-05-10 16:33:23 --> Model Class Initialized
INFO - 2018-05-10 16:33:23 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 16:33:23 --> Final output sent to browser
DEBUG - 2018-05-10 16:33:23 --> Total execution time: 0.0991
INFO - 2018-05-10 11:03:23 --> Language Class Initialized
INFO - 2018-05-10 11:03:23 --> Config Class Initialized
INFO - 2018-05-10 11:03:23 --> Loader Class Initialized
INFO - 2018-05-10 16:33:23 --> Helper loaded: url_helper
INFO - 2018-05-10 16:33:23 --> Helper loaded: notification_helper
INFO - 2018-05-10 16:33:23 --> Helper loaded: settings_helper
INFO - 2018-05-10 16:33:23 --> Helper loaded: permission_helper
INFO - 2018-05-10 16:33:23 --> Helper loaded: users_helper
INFO - 2018-05-10 16:33:23 --> Database Driver Class Initialized
DEBUG - 2018-05-10 16:33:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 16:33:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 16:33:23 --> Helper loaded: form_helper
INFO - 2018-05-10 16:33:23 --> Form Validation Class Initialized
INFO - 2018-05-10 16:33:23 --> Controller Class Initialized
INFO - 2018-05-10 16:33:23 --> Model Class Initialized
INFO - 2018-05-10 16:33:23 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 16:33:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 16:33:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 16:33:24 --> Model Class Initialized
INFO - 2018-05-10 16:33:24 --> Model Class Initialized
INFO - 2018-05-10 16:33:24 --> Model Class Initialized
INFO - 2018-05-10 16:33:24 --> Model Class Initialized
INFO - 2018-05-10 16:33:24 --> Model Class Initialized
INFO - 2018-05-10 16:33:24 --> Model Class Initialized
INFO - 2018-05-10 16:33:24 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 16:33:24 --> Final output sent to browser
DEBUG - 2018-05-10 16:33:24 --> Total execution time: 0.1913
INFO - 2018-05-10 11:03:33 --> Config Class Initialized
INFO - 2018-05-10 11:03:33 --> Hooks Class Initialized
DEBUG - 2018-05-10 11:03:33 --> UTF-8 Support Enabled
INFO - 2018-05-10 11:03:33 --> Utf8 Class Initialized
INFO - 2018-05-10 11:03:33 --> URI Class Initialized
INFO - 2018-05-10 11:03:33 --> Router Class Initialized
INFO - 2018-05-10 11:03:33 --> Output Class Initialized
INFO - 2018-05-10 11:03:33 --> Security Class Initialized
DEBUG - 2018-05-10 11:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 11:03:33 --> Input Class Initialized
INFO - 2018-05-10 11:03:33 --> Language Class Initialized
INFO - 2018-05-10 11:03:33 --> Language Class Initialized
INFO - 2018-05-10 11:03:33 --> Config Class Initialized
INFO - 2018-05-10 11:03:33 --> Loader Class Initialized
INFO - 2018-05-10 16:33:33 --> Helper loaded: url_helper
INFO - 2018-05-10 16:33:33 --> Helper loaded: notification_helper
INFO - 2018-05-10 16:33:33 --> Helper loaded: settings_helper
INFO - 2018-05-10 16:33:33 --> Helper loaded: permission_helper
INFO - 2018-05-10 16:33:33 --> Helper loaded: users_helper
INFO - 2018-05-10 16:33:33 --> Database Driver Class Initialized
DEBUG - 2018-05-10 16:33:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 16:33:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 16:33:33 --> Helper loaded: form_helper
INFO - 2018-05-10 16:33:33 --> Form Validation Class Initialized
INFO - 2018-05-10 16:33:33 --> Controller Class Initialized
INFO - 2018-05-10 16:33:33 --> Model Class Initialized
INFO - 2018-05-10 16:33:33 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 16:33:33 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 16:33:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 16:33:33 --> Model Class Initialized
INFO - 2018-05-10 16:33:33 --> Model Class Initialized
INFO - 2018-05-10 16:33:33 --> Model Class Initialized
INFO - 2018-05-10 16:33:33 --> Model Class Initialized
INFO - 2018-05-10 16:33:33 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 16:33:33 --> Model Class Initialized
INFO - 2018-05-10 16:33:33 --> Final output sent to browser
DEBUG - 2018-05-10 16:33:33 --> Total execution time: 0.0970
INFO - 2018-05-10 11:13:16 --> Config Class Initialized
INFO - 2018-05-10 11:13:16 --> Hooks Class Initialized
DEBUG - 2018-05-10 11:13:16 --> UTF-8 Support Enabled
INFO - 2018-05-10 11:13:16 --> Utf8 Class Initialized
INFO - 2018-05-10 11:13:16 --> URI Class Initialized
INFO - 2018-05-10 11:13:16 --> Router Class Initialized
INFO - 2018-05-10 11:13:16 --> Output Class Initialized
INFO - 2018-05-10 11:13:16 --> Security Class Initialized
DEBUG - 2018-05-10 11:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 11:13:16 --> Input Class Initialized
INFO - 2018-05-10 11:13:16 --> Language Class Initialized
INFO - 2018-05-10 11:13:16 --> Language Class Initialized
INFO - 2018-05-10 11:13:16 --> Config Class Initialized
INFO - 2018-05-10 11:13:16 --> Loader Class Initialized
INFO - 2018-05-10 16:43:16 --> Helper loaded: url_helper
INFO - 2018-05-10 16:43:16 --> Helper loaded: notification_helper
INFO - 2018-05-10 16:43:16 --> Helper loaded: settings_helper
INFO - 2018-05-10 16:43:16 --> Helper loaded: permission_helper
INFO - 2018-05-10 16:43:16 --> Helper loaded: users_helper
INFO - 2018-05-10 16:43:16 --> Database Driver Class Initialized
DEBUG - 2018-05-10 16:43:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 16:43:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 16:43:16 --> Helper loaded: form_helper
INFO - 2018-05-10 16:43:16 --> Form Validation Class Initialized
INFO - 2018-05-10 16:43:16 --> Controller Class Initialized
INFO - 2018-05-10 16:43:16 --> Model Class Initialized
INFO - 2018-05-10 16:43:16 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 16:43:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 16:43:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 16:43:16 --> Model Class Initialized
INFO - 2018-05-10 16:43:16 --> Model Class Initialized
INFO - 2018-05-10 16:43:16 --> Model Class Initialized
INFO - 2018-05-10 16:43:16 --> Model Class Initialized
INFO - 2018-05-10 16:43:16 --> Model Class Initialized
INFO - 2018-05-10 16:43:16 --> Model Class Initialized
INFO - 2018-05-10 16:43:16 --> Model Class Initialized
INFO - 2018-05-10 16:43:16 --> Model Class Initialized
INFO - 2018-05-10 16:43:16 --> Model Class Initialized
INFO - 2018-05-10 16:43:16 --> Model Class Initialized
INFO - 2018-05-10 16:43:16 --> Model Class Initialized
INFO - 2018-05-10 16:43:16 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 16:43:16 --> Model Class Initialized
INFO - 2018-05-10 16:43:16 --> Final output sent to browser
DEBUG - 2018-05-10 16:43:16 --> Total execution time: 0.1308
INFO - 2018-05-10 11:13:18 --> Config Class Initialized
INFO - 2018-05-10 11:13:18 --> Hooks Class Initialized
DEBUG - 2018-05-10 11:13:18 --> UTF-8 Support Enabled
INFO - 2018-05-10 11:13:18 --> Utf8 Class Initialized
INFO - 2018-05-10 11:13:18 --> URI Class Initialized
INFO - 2018-05-10 11:13:18 --> Router Class Initialized
INFO - 2018-05-10 11:13:18 --> Output Class Initialized
INFO - 2018-05-10 11:13:18 --> Security Class Initialized
DEBUG - 2018-05-10 11:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 11:13:18 --> Input Class Initialized
INFO - 2018-05-10 11:13:18 --> Language Class Initialized
INFO - 2018-05-10 11:13:18 --> Language Class Initialized
INFO - 2018-05-10 11:13:18 --> Config Class Initialized
INFO - 2018-05-10 11:13:18 --> Loader Class Initialized
INFO - 2018-05-10 16:43:18 --> Helper loaded: url_helper
INFO - 2018-05-10 16:43:18 --> Helper loaded: notification_helper
INFO - 2018-05-10 16:43:18 --> Helper loaded: settings_helper
INFO - 2018-05-10 16:43:18 --> Helper loaded: permission_helper
INFO - 2018-05-10 16:43:18 --> Helper loaded: users_helper
INFO - 2018-05-10 16:43:18 --> Database Driver Class Initialized
DEBUG - 2018-05-10 16:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 16:43:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 16:43:18 --> Helper loaded: form_helper
INFO - 2018-05-10 16:43:18 --> Form Validation Class Initialized
INFO - 2018-05-10 16:43:18 --> Controller Class Initialized
INFO - 2018-05-10 16:43:18 --> Model Class Initialized
INFO - 2018-05-10 16:43:18 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 16:43:18 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 16:43:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 16:43:18 --> Model Class Initialized
INFO - 2018-05-10 16:43:18 --> Model Class Initialized
INFO - 2018-05-10 16:43:18 --> Model Class Initialized
INFO - 2018-05-10 16:43:18 --> Model Class Initialized
INFO - 2018-05-10 16:43:18 --> Model Class Initialized
INFO - 2018-05-10 16:43:18 --> Model Class Initialized
INFO - 2018-05-10 16:43:18 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 16:43:18 --> Model Class Initialized
INFO - 2018-05-10 16:43:18 --> Final output sent to browser
DEBUG - 2018-05-10 16:43:18 --> Total execution time: 0.1115
INFO - 2018-05-10 11:13:31 --> Config Class Initialized
INFO - 2018-05-10 11:13:31 --> Hooks Class Initialized
DEBUG - 2018-05-10 11:13:31 --> UTF-8 Support Enabled
INFO - 2018-05-10 11:13:31 --> Utf8 Class Initialized
INFO - 2018-05-10 11:13:31 --> URI Class Initialized
INFO - 2018-05-10 11:13:31 --> Router Class Initialized
INFO - 2018-05-10 11:13:31 --> Output Class Initialized
INFO - 2018-05-10 11:13:31 --> Security Class Initialized
DEBUG - 2018-05-10 11:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 11:13:31 --> Input Class Initialized
INFO - 2018-05-10 11:13:31 --> Config Class Initialized
INFO - 2018-05-10 11:13:31 --> Hooks Class Initialized
INFO - 2018-05-10 11:13:31 --> Language Class Initialized
DEBUG - 2018-05-10 11:13:31 --> UTF-8 Support Enabled
INFO - 2018-05-10 11:13:31 --> Utf8 Class Initialized
INFO - 2018-05-10 11:13:31 --> URI Class Initialized
INFO - 2018-05-10 11:13:31 --> Router Class Initialized
INFO - 2018-05-10 11:13:31 --> Output Class Initialized
INFO - 2018-05-10 11:13:31 --> Security Class Initialized
INFO - 2018-05-10 11:13:31 --> Language Class Initialized
INFO - 2018-05-10 11:13:31 --> Config Class Initialized
INFO - 2018-05-10 11:13:31 --> Loader Class Initialized
INFO - 2018-05-10 16:43:31 --> Helper loaded: url_helper
DEBUG - 2018-05-10 11:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 11:13:31 --> Input Class Initialized
INFO - 2018-05-10 11:13:31 --> Language Class Initialized
INFO - 2018-05-10 16:43:31 --> Helper loaded: notification_helper
INFO - 2018-05-10 16:43:31 --> Helper loaded: settings_helper
INFO - 2018-05-10 16:43:31 --> Helper loaded: permission_helper
INFO - 2018-05-10 16:43:31 --> Helper loaded: users_helper
INFO - 2018-05-10 11:13:31 --> Language Class Initialized
INFO - 2018-05-10 11:13:31 --> Config Class Initialized
INFO - 2018-05-10 11:13:31 --> Loader Class Initialized
INFO - 2018-05-10 16:43:31 --> Helper loaded: url_helper
INFO - 2018-05-10 16:43:31 --> Database Driver Class Initialized
INFO - 2018-05-10 16:43:31 --> Helper loaded: notification_helper
INFO - 2018-05-10 16:43:31 --> Helper loaded: settings_helper
DEBUG - 2018-05-10 16:43:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 16:43:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 16:43:31 --> Helper loaded: permission_helper
INFO - 2018-05-10 16:43:31 --> Helper loaded: users_helper
INFO - 2018-05-10 16:43:31 --> Helper loaded: form_helper
INFO - 2018-05-10 16:43:31 --> Form Validation Class Initialized
INFO - 2018-05-10 16:43:31 --> Controller Class Initialized
INFO - 2018-05-10 16:43:31 --> Model Class Initialized
INFO - 2018-05-10 16:43:31 --> Helper loaded: inflector_helper
INFO - 2018-05-10 16:43:31 --> Database Driver Class Initialized
DEBUG - 2018-05-10 16:43:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 16:43:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 16:43:31 --> Model Class Initialized
INFO - 2018-05-10 16:43:31 --> Model Class Initialized
INFO - 2018-05-10 16:43:31 --> Model Class Initialized
INFO - 2018-05-10 16:43:31 --> Model Class Initialized
DEBUG - 2018-05-10 16:43:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 16:43:31 --> Model Class Initialized
INFO - 2018-05-10 16:43:31 --> Model Class Initialized
INFO - 2018-05-10 16:43:31 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 16:43:31 --> Final output sent to browser
DEBUG - 2018-05-10 16:43:31 --> Total execution time: 0.1151
INFO - 2018-05-10 16:43:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 16:43:31 --> Helper loaded: form_helper
INFO - 2018-05-10 16:43:31 --> Form Validation Class Initialized
INFO - 2018-05-10 16:43:31 --> Controller Class Initialized
INFO - 2018-05-10 16:43:31 --> Model Class Initialized
INFO - 2018-05-10 16:43:31 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 16:43:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 16:43:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 16:43:31 --> Model Class Initialized
INFO - 2018-05-10 16:43:31 --> Model Class Initialized
INFO - 2018-05-10 16:43:31 --> Model Class Initialized
INFO - 2018-05-10 16:43:31 --> Model Class Initialized
INFO - 2018-05-10 16:43:31 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 16:43:31 --> Final output sent to browser
DEBUG - 2018-05-10 16:43:31 --> Total execution time: 0.1920
INFO - 2018-05-10 11:13:37 --> Config Class Initialized
INFO - 2018-05-10 11:13:37 --> Hooks Class Initialized
DEBUG - 2018-05-10 11:13:37 --> UTF-8 Support Enabled
INFO - 2018-05-10 11:13:37 --> Utf8 Class Initialized
INFO - 2018-05-10 11:13:37 --> URI Class Initialized
INFO - 2018-05-10 11:13:37 --> Router Class Initialized
INFO - 2018-05-10 11:13:37 --> Output Class Initialized
INFO - 2018-05-10 11:13:37 --> Security Class Initialized
DEBUG - 2018-05-10 11:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 11:13:37 --> Input Class Initialized
INFO - 2018-05-10 11:13:37 --> Language Class Initialized
INFO - 2018-05-10 11:13:37 --> Language Class Initialized
INFO - 2018-05-10 11:13:37 --> Config Class Initialized
INFO - 2018-05-10 11:13:37 --> Loader Class Initialized
INFO - 2018-05-10 16:43:37 --> Helper loaded: url_helper
INFO - 2018-05-10 16:43:37 --> Helper loaded: notification_helper
INFO - 2018-05-10 16:43:37 --> Helper loaded: settings_helper
INFO - 2018-05-10 16:43:37 --> Helper loaded: permission_helper
INFO - 2018-05-10 16:43:37 --> Helper loaded: users_helper
INFO - 2018-05-10 16:43:37 --> Database Driver Class Initialized
DEBUG - 2018-05-10 16:43:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 16:43:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 16:43:37 --> Helper loaded: form_helper
INFO - 2018-05-10 16:43:37 --> Form Validation Class Initialized
INFO - 2018-05-10 16:43:37 --> Controller Class Initialized
INFO - 2018-05-10 16:43:37 --> Model Class Initialized
INFO - 2018-05-10 16:43:37 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 16:43:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 16:43:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 16:43:37 --> Model Class Initialized
INFO - 2018-05-10 16:43:37 --> Model Class Initialized
INFO - 2018-05-10 16:43:37 --> Model Class Initialized
INFO - 2018-05-10 16:43:37 --> Model Class Initialized
INFO - 2018-05-10 16:43:37 --> Model Class Initialized
INFO - 2018-05-10 16:43:37 --> Model Class Initialized
INFO - 2018-05-10 16:43:37 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 16:43:37 --> Final output sent to browser
DEBUG - 2018-05-10 16:43:37 --> Total execution time: 0.1018
INFO - 2018-05-10 11:13:38 --> Config Class Initialized
INFO - 2018-05-10 11:13:38 --> Hooks Class Initialized
DEBUG - 2018-05-10 11:13:38 --> UTF-8 Support Enabled
INFO - 2018-05-10 11:13:38 --> Utf8 Class Initialized
INFO - 2018-05-10 11:13:38 --> URI Class Initialized
INFO - 2018-05-10 11:13:38 --> Router Class Initialized
INFO - 2018-05-10 11:13:38 --> Output Class Initialized
INFO - 2018-05-10 11:13:38 --> Security Class Initialized
DEBUG - 2018-05-10 11:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 11:13:38 --> Input Class Initialized
INFO - 2018-05-10 11:13:38 --> Language Class Initialized
INFO - 2018-05-10 11:13:38 --> Language Class Initialized
INFO - 2018-05-10 11:13:38 --> Config Class Initialized
INFO - 2018-05-10 11:13:38 --> Loader Class Initialized
INFO - 2018-05-10 16:43:38 --> Helper loaded: url_helper
INFO - 2018-05-10 16:43:38 --> Helper loaded: notification_helper
INFO - 2018-05-10 16:43:38 --> Helper loaded: settings_helper
INFO - 2018-05-10 16:43:38 --> Helper loaded: permission_helper
INFO - 2018-05-10 16:43:38 --> Helper loaded: users_helper
INFO - 2018-05-10 16:43:38 --> Database Driver Class Initialized
DEBUG - 2018-05-10 16:43:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 16:43:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 16:43:38 --> Helper loaded: form_helper
INFO - 2018-05-10 16:43:38 --> Form Validation Class Initialized
INFO - 2018-05-10 16:43:38 --> Controller Class Initialized
INFO - 2018-05-10 16:43:38 --> Model Class Initialized
INFO - 2018-05-10 16:43:38 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 16:43:38 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 16:43:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 16:43:38 --> Model Class Initialized
INFO - 2018-05-10 16:43:38 --> Model Class Initialized
INFO - 2018-05-10 16:43:38 --> Model Class Initialized
INFO - 2018-05-10 16:43:38 --> Model Class Initialized
INFO - 2018-05-10 16:43:38 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 16:43:38 --> Model Class Initialized
INFO - 2018-05-10 16:43:38 --> Final output sent to browser
DEBUG - 2018-05-10 16:43:38 --> Total execution time: 0.0981
INFO - 2018-05-10 11:14:13 --> Config Class Initialized
INFO - 2018-05-10 11:14:13 --> Hooks Class Initialized
DEBUG - 2018-05-10 11:14:13 --> UTF-8 Support Enabled
INFO - 2018-05-10 11:14:13 --> Utf8 Class Initialized
INFO - 2018-05-10 11:14:13 --> URI Class Initialized
INFO - 2018-05-10 11:14:13 --> Router Class Initialized
INFO - 2018-05-10 11:14:13 --> Output Class Initialized
INFO - 2018-05-10 11:14:13 --> Security Class Initialized
DEBUG - 2018-05-10 11:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 11:14:13 --> Input Class Initialized
INFO - 2018-05-10 11:14:13 --> Language Class Initialized
INFO - 2018-05-10 11:14:13 --> Language Class Initialized
INFO - 2018-05-10 11:14:13 --> Config Class Initialized
INFO - 2018-05-10 11:14:13 --> Loader Class Initialized
INFO - 2018-05-10 16:44:13 --> Helper loaded: url_helper
INFO - 2018-05-10 16:44:13 --> Helper loaded: notification_helper
INFO - 2018-05-10 16:44:13 --> Helper loaded: settings_helper
INFO - 2018-05-10 16:44:13 --> Helper loaded: permission_helper
INFO - 2018-05-10 16:44:13 --> Helper loaded: users_helper
INFO - 2018-05-10 16:44:13 --> Database Driver Class Initialized
DEBUG - 2018-05-10 16:44:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 16:44:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 16:44:13 --> Helper loaded: form_helper
INFO - 2018-05-10 16:44:13 --> Form Validation Class Initialized
INFO - 2018-05-10 16:44:13 --> Controller Class Initialized
INFO - 2018-05-10 16:44:13 --> Model Class Initialized
INFO - 2018-05-10 16:44:13 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 16:44:13 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 16:44:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 16:44:13 --> Model Class Initialized
INFO - 2018-05-10 16:44:13 --> Model Class Initialized
INFO - 2018-05-10 16:44:13 --> Model Class Initialized
INFO - 2018-05-10 16:44:13 --> Model Class Initialized
INFO - 2018-05-10 16:44:13 --> Model Class Initialized
INFO - 2018-05-10 16:44:13 --> Model Class Initialized
INFO - 2018-05-10 16:44:13 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 16:44:13 --> Final output sent to browser
DEBUG - 2018-05-10 16:44:13 --> Total execution time: 0.1298
INFO - 2018-05-10 11:26:50 --> Config Class Initialized
INFO - 2018-05-10 11:26:50 --> Hooks Class Initialized
DEBUG - 2018-05-10 11:26:50 --> UTF-8 Support Enabled
INFO - 2018-05-10 11:26:50 --> Utf8 Class Initialized
INFO - 2018-05-10 11:26:50 --> URI Class Initialized
INFO - 2018-05-10 11:26:50 --> Router Class Initialized
INFO - 2018-05-10 11:26:50 --> Output Class Initialized
INFO - 2018-05-10 11:26:50 --> Security Class Initialized
DEBUG - 2018-05-10 11:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 11:26:50 --> Input Class Initialized
INFO - 2018-05-10 11:26:50 --> Language Class Initialized
INFO - 2018-05-10 11:26:50 --> Language Class Initialized
INFO - 2018-05-10 11:26:50 --> Config Class Initialized
INFO - 2018-05-10 11:26:50 --> Loader Class Initialized
INFO - 2018-05-10 16:56:50 --> Helper loaded: url_helper
INFO - 2018-05-10 16:56:50 --> Helper loaded: notification_helper
INFO - 2018-05-10 16:56:50 --> Helper loaded: settings_helper
INFO - 2018-05-10 16:56:50 --> Helper loaded: permission_helper
INFO - 2018-05-10 16:56:50 --> Helper loaded: users_helper
INFO - 2018-05-10 16:56:50 --> Database Driver Class Initialized
DEBUG - 2018-05-10 16:56:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 16:56:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 16:56:50 --> Helper loaded: form_helper
INFO - 2018-05-10 16:56:50 --> Form Validation Class Initialized
INFO - 2018-05-10 16:56:50 --> Controller Class Initialized
INFO - 2018-05-10 16:56:50 --> Model Class Initialized
INFO - 2018-05-10 16:56:50 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 16:56:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 16:56:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 16:56:50 --> Model Class Initialized
INFO - 2018-05-10 16:56:50 --> Model Class Initialized
INFO - 2018-05-10 16:56:50 --> Model Class Initialized
INFO - 2018-05-10 16:56:50 --> Model Class Initialized
INFO - 2018-05-10 16:56:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 16:56:50 --> Model Class Initialized
INFO - 2018-05-10 16:56:50 --> Final output sent to browser
DEBUG - 2018-05-10 16:56:50 --> Total execution time: 0.0989
INFO - 2018-05-10 11:26:55 --> Config Class Initialized
INFO - 2018-05-10 11:26:55 --> Hooks Class Initialized
DEBUG - 2018-05-10 11:26:55 --> UTF-8 Support Enabled
INFO - 2018-05-10 11:26:55 --> Utf8 Class Initialized
INFO - 2018-05-10 11:26:55 --> URI Class Initialized
INFO - 2018-05-10 11:26:55 --> Router Class Initialized
INFO - 2018-05-10 11:26:55 --> Output Class Initialized
INFO - 2018-05-10 11:26:55 --> Security Class Initialized
DEBUG - 2018-05-10 11:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 11:26:55 --> Input Class Initialized
INFO - 2018-05-10 11:26:55 --> Language Class Initialized
INFO - 2018-05-10 11:26:55 --> Language Class Initialized
INFO - 2018-05-10 11:26:55 --> Config Class Initialized
INFO - 2018-05-10 11:26:55 --> Loader Class Initialized
INFO - 2018-05-10 16:56:55 --> Helper loaded: url_helper
INFO - 2018-05-10 16:56:55 --> Helper loaded: notification_helper
INFO - 2018-05-10 16:56:55 --> Helper loaded: settings_helper
INFO - 2018-05-10 16:56:55 --> Helper loaded: permission_helper
INFO - 2018-05-10 16:56:55 --> Helper loaded: users_helper
INFO - 2018-05-10 16:56:55 --> Database Driver Class Initialized
DEBUG - 2018-05-10 16:56:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 16:56:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 16:56:55 --> Helper loaded: form_helper
INFO - 2018-05-10 16:56:55 --> Form Validation Class Initialized
INFO - 2018-05-10 16:56:55 --> Controller Class Initialized
DEBUG - 2018-05-10 16:56:55 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-05-10 16:56:55 --> Final output sent to browser
DEBUG - 2018-05-10 16:56:55 --> Total execution time: 0.0691
INFO - 2018-05-10 11:56:47 --> Config Class Initialized
INFO - 2018-05-10 11:56:47 --> Hooks Class Initialized
DEBUG - 2018-05-10 11:56:47 --> UTF-8 Support Enabled
INFO - 2018-05-10 11:56:47 --> Utf8 Class Initialized
INFO - 2018-05-10 11:56:47 --> URI Class Initialized
INFO - 2018-05-10 11:56:47 --> Router Class Initialized
INFO - 2018-05-10 11:56:47 --> Output Class Initialized
INFO - 2018-05-10 11:56:47 --> Security Class Initialized
DEBUG - 2018-05-10 11:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 11:56:47 --> Input Class Initialized
INFO - 2018-05-10 11:56:47 --> Language Class Initialized
INFO - 2018-05-10 11:56:47 --> Language Class Initialized
INFO - 2018-05-10 11:56:47 --> Config Class Initialized
INFO - 2018-05-10 11:56:47 --> Loader Class Initialized
INFO - 2018-05-10 17:26:47 --> Helper loaded: url_helper
INFO - 2018-05-10 17:26:47 --> Helper loaded: notification_helper
INFO - 2018-05-10 17:26:47 --> Helper loaded: settings_helper
INFO - 2018-05-10 17:26:47 --> Helper loaded: permission_helper
INFO - 2018-05-10 17:26:47 --> Helper loaded: users_helper
INFO - 2018-05-10 17:26:47 --> Database Driver Class Initialized
DEBUG - 2018-05-10 17:26:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 17:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 17:26:47 --> Helper loaded: form_helper
INFO - 2018-05-10 17:26:47 --> Form Validation Class Initialized
INFO - 2018-05-10 17:26:47 --> Controller Class Initialized
DEBUG - 2018-05-10 17:26:47 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-05-10 17:26:47 --> Final output sent to browser
DEBUG - 2018-05-10 17:26:47 --> Total execution time: 0.1026
INFO - 2018-05-10 11:56:54 --> Config Class Initialized
INFO - 2018-05-10 11:56:54 --> Hooks Class Initialized
DEBUG - 2018-05-10 11:56:54 --> UTF-8 Support Enabled
INFO - 2018-05-10 11:56:54 --> Utf8 Class Initialized
INFO - 2018-05-10 11:56:54 --> URI Class Initialized
INFO - 2018-05-10 11:56:54 --> Router Class Initialized
INFO - 2018-05-10 11:56:54 --> Output Class Initialized
INFO - 2018-05-10 11:56:54 --> Security Class Initialized
DEBUG - 2018-05-10 11:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 11:56:54 --> Input Class Initialized
INFO - 2018-05-10 11:56:54 --> Language Class Initialized
INFO - 2018-05-10 11:56:54 --> Language Class Initialized
INFO - 2018-05-10 11:56:54 --> Config Class Initialized
INFO - 2018-05-10 11:56:54 --> Loader Class Initialized
INFO - 2018-05-10 17:26:54 --> Helper loaded: url_helper
INFO - 2018-05-10 17:26:54 --> Helper loaded: notification_helper
INFO - 2018-05-10 17:26:54 --> Helper loaded: settings_helper
INFO - 2018-05-10 17:26:54 --> Helper loaded: permission_helper
INFO - 2018-05-10 17:26:54 --> Helper loaded: users_helper
INFO - 2018-05-10 17:26:54 --> Database Driver Class Initialized
DEBUG - 2018-05-10 17:26:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 17:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 17:26:54 --> Helper loaded: form_helper
INFO - 2018-05-10 17:26:54 --> Form Validation Class Initialized
INFO - 2018-05-10 17:26:54 --> Controller Class Initialized
INFO - 2018-05-10 17:26:54 --> Model Class Initialized
INFO - 2018-05-10 17:26:54 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 17:26:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 17:26:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 17:26:54 --> Model Class Initialized
INFO - 2018-05-10 17:26:54 --> Model Class Initialized
INFO - 2018-05-10 17:26:54 --> Model Class Initialized
INFO - 2018-05-10 17:26:54 --> Model Class Initialized
INFO - 2018-05-10 17:26:54 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 17:26:54 --> Model Class Initialized
ERROR - 2018-05-10 17:26:54 --> Query error: Unknown column 'credit_function_costs.title' in 'field list' - Invalid query: SELECT `credit_function_costs`.`title`, `credit_function_costs`.`credits`, `credit_function_costs`.`description`
FROM `credit_function_costs`
ERROR - 2018-05-10 17:26:54 --> Severity: error --> Exception: Call to a member function num_rows() on boolean /home/pr01004/public_html/application/core/MY_Model.php 1004
INFO - 2018-05-10 11:57:01 --> Config Class Initialized
INFO - 2018-05-10 11:57:01 --> Hooks Class Initialized
DEBUG - 2018-05-10 11:57:01 --> UTF-8 Support Enabled
INFO - 2018-05-10 11:57:01 --> Utf8 Class Initialized
INFO - 2018-05-10 11:57:01 --> URI Class Initialized
INFO - 2018-05-10 11:57:01 --> Router Class Initialized
INFO - 2018-05-10 11:57:01 --> Output Class Initialized
INFO - 2018-05-10 11:57:01 --> Security Class Initialized
DEBUG - 2018-05-10 11:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 11:57:01 --> Input Class Initialized
INFO - 2018-05-10 11:57:01 --> Language Class Initialized
INFO - 2018-05-10 11:57:01 --> Language Class Initialized
INFO - 2018-05-10 11:57:01 --> Config Class Initialized
INFO - 2018-05-10 11:57:01 --> Loader Class Initialized
INFO - 2018-05-10 17:27:01 --> Helper loaded: url_helper
INFO - 2018-05-10 17:27:01 --> Helper loaded: notification_helper
INFO - 2018-05-10 17:27:01 --> Helper loaded: settings_helper
INFO - 2018-05-10 17:27:01 --> Helper loaded: permission_helper
INFO - 2018-05-10 17:27:01 --> Helper loaded: users_helper
INFO - 2018-05-10 17:27:01 --> Database Driver Class Initialized
DEBUG - 2018-05-10 17:27:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 17:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 17:27:01 --> Helper loaded: form_helper
INFO - 2018-05-10 17:27:01 --> Form Validation Class Initialized
INFO - 2018-05-10 17:27:01 --> Controller Class Initialized
INFO - 2018-05-10 17:27:01 --> Model Class Initialized
INFO - 2018-05-10 17:27:01 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 17:27:01 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 17:27:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 17:27:01 --> Model Class Initialized
INFO - 2018-05-10 17:27:01 --> Model Class Initialized
INFO - 2018-05-10 17:27:01 --> Model Class Initialized
INFO - 2018-05-10 17:27:01 --> Model Class Initialized
INFO - 2018-05-10 17:27:01 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 17:27:01 --> Model Class Initialized
ERROR - 2018-05-10 17:27:01 --> Query error: Unknown column 'credit_function_costs.title' in 'field list' - Invalid query: SELECT `credit_function_costs`.`title`, `credit_function_costs`.`credits`, `credit_function_costs`.`description`
FROM `credit_function_costs`
ERROR - 2018-05-10 17:27:01 --> Severity: error --> Exception: Call to a member function num_rows() on boolean /home/pr01004/public_html/application/core/MY_Model.php 1004
INFO - 2018-05-10 11:58:19 --> Config Class Initialized
INFO - 2018-05-10 11:58:19 --> Hooks Class Initialized
DEBUG - 2018-05-10 11:58:19 --> UTF-8 Support Enabled
INFO - 2018-05-10 11:58:19 --> Utf8 Class Initialized
INFO - 2018-05-10 11:58:19 --> URI Class Initialized
INFO - 2018-05-10 11:58:19 --> Router Class Initialized
INFO - 2018-05-10 11:58:19 --> Output Class Initialized
INFO - 2018-05-10 11:58:19 --> Security Class Initialized
DEBUG - 2018-05-10 11:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 11:58:19 --> Input Class Initialized
INFO - 2018-05-10 11:58:19 --> Language Class Initialized
INFO - 2018-05-10 11:58:19 --> Language Class Initialized
INFO - 2018-05-10 11:58:19 --> Config Class Initialized
INFO - 2018-05-10 11:58:19 --> Loader Class Initialized
INFO - 2018-05-10 17:28:19 --> Helper loaded: url_helper
INFO - 2018-05-10 17:28:19 --> Helper loaded: notification_helper
INFO - 2018-05-10 17:28:19 --> Helper loaded: settings_helper
INFO - 2018-05-10 17:28:19 --> Helper loaded: permission_helper
INFO - 2018-05-10 17:28:19 --> Helper loaded: users_helper
INFO - 2018-05-10 17:28:19 --> Database Driver Class Initialized
DEBUG - 2018-05-10 17:28:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 17:28:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 17:28:19 --> Helper loaded: form_helper
INFO - 2018-05-10 17:28:19 --> Form Validation Class Initialized
INFO - 2018-05-10 17:28:19 --> Controller Class Initialized
INFO - 2018-05-10 17:28:19 --> Model Class Initialized
INFO - 2018-05-10 17:28:19 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 17:28:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 17:28:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 17:28:19 --> Model Class Initialized
INFO - 2018-05-10 17:28:19 --> Model Class Initialized
INFO - 2018-05-10 17:28:19 --> Model Class Initialized
INFO - 2018-05-10 17:28:19 --> Model Class Initialized
INFO - 2018-05-10 17:28:19 --> Model Class Initialized
INFO - 2018-05-10 17:28:19 --> Model Class Initialized
INFO - 2018-05-10 17:28:19 --> Model Class Initialized
INFO - 2018-05-10 17:28:19 --> Model Class Initialized
INFO - 2018-05-10 17:28:19 --> Model Class Initialized
INFO - 2018-05-10 17:28:19 --> Model Class Initialized
INFO - 2018-05-10 17:28:19 --> Model Class Initialized
INFO - 2018-05-10 17:28:19 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 17:28:19 --> Model Class Initialized
INFO - 2018-05-10 17:28:19 --> Final output sent to browser
DEBUG - 2018-05-10 17:28:19 --> Total execution time: 0.1066
INFO - 2018-05-10 11:58:20 --> Config Class Initialized
INFO - 2018-05-10 11:58:20 --> Hooks Class Initialized
DEBUG - 2018-05-10 11:58:20 --> UTF-8 Support Enabled
INFO - 2018-05-10 11:58:20 --> Utf8 Class Initialized
INFO - 2018-05-10 11:58:20 --> URI Class Initialized
INFO - 2018-05-10 11:58:20 --> Router Class Initialized
INFO - 2018-05-10 11:58:20 --> Output Class Initialized
INFO - 2018-05-10 11:58:20 --> Security Class Initialized
DEBUG - 2018-05-10 11:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 11:58:20 --> Input Class Initialized
INFO - 2018-05-10 11:58:20 --> Language Class Initialized
INFO - 2018-05-10 11:58:20 --> Language Class Initialized
INFO - 2018-05-10 11:58:20 --> Config Class Initialized
INFO - 2018-05-10 11:58:20 --> Loader Class Initialized
INFO - 2018-05-10 17:28:20 --> Helper loaded: url_helper
INFO - 2018-05-10 17:28:20 --> Helper loaded: notification_helper
INFO - 2018-05-10 17:28:20 --> Helper loaded: settings_helper
INFO - 2018-05-10 17:28:20 --> Helper loaded: permission_helper
INFO - 2018-05-10 17:28:20 --> Helper loaded: users_helper
INFO - 2018-05-10 17:28:20 --> Database Driver Class Initialized
DEBUG - 2018-05-10 17:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 17:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 17:28:20 --> Helper loaded: form_helper
INFO - 2018-05-10 17:28:20 --> Form Validation Class Initialized
INFO - 2018-05-10 17:28:20 --> Controller Class Initialized
INFO - 2018-05-10 17:28:20 --> Model Class Initialized
INFO - 2018-05-10 17:28:20 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 17:28:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 17:28:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 17:28:20 --> Model Class Initialized
INFO - 2018-05-10 17:28:20 --> Model Class Initialized
INFO - 2018-05-10 17:28:20 --> Model Class Initialized
INFO - 2018-05-10 17:28:20 --> Model Class Initialized
INFO - 2018-05-10 17:28:20 --> Model Class Initialized
INFO - 2018-05-10 17:28:20 --> Model Class Initialized
INFO - 2018-05-10 17:28:20 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 17:28:20 --> Model Class Initialized
INFO - 2018-05-10 17:28:20 --> Final output sent to browser
DEBUG - 2018-05-10 17:28:20 --> Total execution time: 0.1587
INFO - 2018-05-10 11:58:26 --> Config Class Initialized
INFO - 2018-05-10 11:58:26 --> Hooks Class Initialized
DEBUG - 2018-05-10 11:58:26 --> UTF-8 Support Enabled
INFO - 2018-05-10 11:58:26 --> Utf8 Class Initialized
INFO - 2018-05-10 11:58:26 --> Config Class Initialized
INFO - 2018-05-10 11:58:26 --> Hooks Class Initialized
INFO - 2018-05-10 11:58:26 --> URI Class Initialized
DEBUG - 2018-05-10 11:58:26 --> UTF-8 Support Enabled
INFO - 2018-05-10 11:58:26 --> Utf8 Class Initialized
INFO - 2018-05-10 11:58:26 --> URI Class Initialized
INFO - 2018-05-10 11:58:26 --> Router Class Initialized
INFO - 2018-05-10 11:58:26 --> Router Class Initialized
INFO - 2018-05-10 11:58:26 --> Output Class Initialized
INFO - 2018-05-10 11:58:26 --> Output Class Initialized
INFO - 2018-05-10 11:58:26 --> Security Class Initialized
INFO - 2018-05-10 11:58:26 --> Security Class Initialized
DEBUG - 2018-05-10 11:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 11:58:26 --> Input Class Initialized
DEBUG - 2018-05-10 11:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 11:58:26 --> Input Class Initialized
INFO - 2018-05-10 11:58:26 --> Language Class Initialized
INFO - 2018-05-10 11:58:26 --> Language Class Initialized
INFO - 2018-05-10 11:58:26 --> Language Class Initialized
INFO - 2018-05-10 11:58:26 --> Config Class Initialized
INFO - 2018-05-10 11:58:26 --> Loader Class Initialized
INFO - 2018-05-10 17:28:26 --> Helper loaded: url_helper
INFO - 2018-05-10 11:58:26 --> Language Class Initialized
INFO - 2018-05-10 11:58:26 --> Config Class Initialized
INFO - 2018-05-10 11:58:26 --> Loader Class Initialized
INFO - 2018-05-10 17:28:26 --> Helper loaded: notification_helper
INFO - 2018-05-10 17:28:26 --> Helper loaded: settings_helper
INFO - 2018-05-10 17:28:26 --> Helper loaded: permission_helper
INFO - 2018-05-10 17:28:26 --> Helper loaded: url_helper
INFO - 2018-05-10 17:28:26 --> Helper loaded: users_helper
INFO - 2018-05-10 17:28:26 --> Helper loaded: notification_helper
INFO - 2018-05-10 17:28:26 --> Helper loaded: settings_helper
INFO - 2018-05-10 17:28:26 --> Helper loaded: permission_helper
INFO - 2018-05-10 17:28:26 --> Helper loaded: users_helper
INFO - 2018-05-10 17:28:26 --> Database Driver Class Initialized
INFO - 2018-05-10 17:28:26 --> Database Driver Class Initialized
DEBUG - 2018-05-10 17:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 17:28:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-05-10 17:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 17:28:26 --> Helper loaded: form_helper
INFO - 2018-05-10 17:28:26 --> Form Validation Class Initialized
INFO - 2018-05-10 17:28:26 --> Controller Class Initialized
INFO - 2018-05-10 17:28:26 --> Model Class Initialized
INFO - 2018-05-10 17:28:26 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 17:28:26 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 17:28:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 17:28:26 --> Model Class Initialized
INFO - 2018-05-10 17:28:26 --> Model Class Initialized
INFO - 2018-05-10 17:28:26 --> Model Class Initialized
INFO - 2018-05-10 17:28:26 --> Model Class Initialized
INFO - 2018-05-10 17:28:26 --> Model Class Initialized
INFO - 2018-05-10 17:28:26 --> Model Class Initialized
INFO - 2018-05-10 17:28:26 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 17:28:26 --> Final output sent to browser
DEBUG - 2018-05-10 17:28:26 --> Total execution time: 0.1123
INFO - 2018-05-10 17:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 17:28:26 --> Helper loaded: form_helper
INFO - 2018-05-10 17:28:26 --> Form Validation Class Initialized
INFO - 2018-05-10 17:28:26 --> Controller Class Initialized
INFO - 2018-05-10 17:28:26 --> Model Class Initialized
INFO - 2018-05-10 17:28:26 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 17:28:26 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 17:28:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 17:28:26 --> Model Class Initialized
INFO - 2018-05-10 17:28:26 --> Model Class Initialized
INFO - 2018-05-10 17:28:26 --> Model Class Initialized
INFO - 2018-05-10 17:28:26 --> Model Class Initialized
INFO - 2018-05-10 17:28:26 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 17:28:26 --> Final output sent to browser
DEBUG - 2018-05-10 17:28:26 --> Total execution time: 0.1665
INFO - 2018-05-10 11:58:31 --> Config Class Initialized
INFO - 2018-05-10 11:58:31 --> Hooks Class Initialized
DEBUG - 2018-05-10 11:58:31 --> UTF-8 Support Enabled
INFO - 2018-05-10 11:58:31 --> Utf8 Class Initialized
INFO - 2018-05-10 11:58:31 --> URI Class Initialized
INFO - 2018-05-10 11:58:31 --> Router Class Initialized
INFO - 2018-05-10 11:58:31 --> Output Class Initialized
INFO - 2018-05-10 11:58:31 --> Security Class Initialized
DEBUG - 2018-05-10 11:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 11:58:31 --> Input Class Initialized
INFO - 2018-05-10 11:58:31 --> Language Class Initialized
INFO - 2018-05-10 11:58:31 --> Language Class Initialized
INFO - 2018-05-10 11:58:31 --> Config Class Initialized
INFO - 2018-05-10 11:58:31 --> Loader Class Initialized
INFO - 2018-05-10 17:28:31 --> Helper loaded: url_helper
INFO - 2018-05-10 17:28:31 --> Helper loaded: notification_helper
INFO - 2018-05-10 17:28:31 --> Helper loaded: settings_helper
INFO - 2018-05-10 17:28:31 --> Helper loaded: permission_helper
INFO - 2018-05-10 17:28:31 --> Helper loaded: users_helper
INFO - 2018-05-10 17:28:31 --> Database Driver Class Initialized
DEBUG - 2018-05-10 17:28:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 17:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 17:28:31 --> Helper loaded: form_helper
INFO - 2018-05-10 17:28:31 --> Form Validation Class Initialized
INFO - 2018-05-10 17:28:31 --> Controller Class Initialized
INFO - 2018-05-10 17:28:31 --> Model Class Initialized
INFO - 2018-05-10 17:28:31 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 17:28:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 17:28:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 17:28:31 --> Model Class Initialized
INFO - 2018-05-10 17:28:31 --> Model Class Initialized
INFO - 2018-05-10 17:28:31 --> Model Class Initialized
INFO - 2018-05-10 17:28:31 --> Model Class Initialized
INFO - 2018-05-10 17:28:31 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 17:28:31 --> Model Class Initialized
INFO - 2018-05-10 17:28:31 --> Final output sent to browser
DEBUG - 2018-05-10 17:28:31 --> Total execution time: 0.1227
INFO - 2018-05-10 11:58:46 --> Config Class Initialized
INFO - 2018-05-10 11:58:46 --> Hooks Class Initialized
DEBUG - 2018-05-10 11:58:46 --> UTF-8 Support Enabled
INFO - 2018-05-10 11:58:46 --> Utf8 Class Initialized
INFO - 2018-05-10 11:58:46 --> URI Class Initialized
INFO - 2018-05-10 11:58:46 --> Router Class Initialized
INFO - 2018-05-10 11:58:46 --> Output Class Initialized
INFO - 2018-05-10 11:58:46 --> Security Class Initialized
DEBUG - 2018-05-10 11:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 11:58:46 --> Input Class Initialized
INFO - 2018-05-10 11:58:46 --> Language Class Initialized
INFO - 2018-05-10 11:58:46 --> Language Class Initialized
INFO - 2018-05-10 11:58:46 --> Config Class Initialized
INFO - 2018-05-10 11:58:46 --> Loader Class Initialized
INFO - 2018-05-10 17:28:46 --> Helper loaded: url_helper
INFO - 2018-05-10 17:28:46 --> Helper loaded: notification_helper
INFO - 2018-05-10 17:28:46 --> Helper loaded: settings_helper
INFO - 2018-05-10 17:28:46 --> Helper loaded: permission_helper
INFO - 2018-05-10 17:28:46 --> Helper loaded: users_helper
INFO - 2018-05-10 17:28:46 --> Database Driver Class Initialized
DEBUG - 2018-05-10 17:28:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 17:28:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 17:28:46 --> Helper loaded: form_helper
INFO - 2018-05-10 17:28:46 --> Form Validation Class Initialized
INFO - 2018-05-10 17:28:46 --> Controller Class Initialized
INFO - 2018-05-10 17:28:46 --> Model Class Initialized
INFO - 2018-05-10 17:28:46 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 17:28:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 17:28:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 17:28:46 --> Model Class Initialized
INFO - 2018-05-10 17:28:46 --> Model Class Initialized
INFO - 2018-05-10 17:28:46 --> Model Class Initialized
INFO - 2018-05-10 17:28:46 --> Model Class Initialized
INFO - 2018-05-10 17:28:46 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 17:28:46 --> Model Class Initialized
INFO - 2018-05-10 17:28:46 --> Final output sent to browser
DEBUG - 2018-05-10 17:28:46 --> Total execution time: 0.1182
INFO - 2018-05-10 11:58:47 --> Config Class Initialized
INFO - 2018-05-10 11:58:47 --> Hooks Class Initialized
DEBUG - 2018-05-10 11:58:47 --> UTF-8 Support Enabled
INFO - 2018-05-10 11:58:47 --> Utf8 Class Initialized
INFO - 2018-05-10 11:58:47 --> URI Class Initialized
INFO - 2018-05-10 11:58:47 --> Router Class Initialized
INFO - 2018-05-10 11:58:47 --> Output Class Initialized
INFO - 2018-05-10 11:58:47 --> Security Class Initialized
DEBUG - 2018-05-10 11:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 11:58:47 --> Input Class Initialized
INFO - 2018-05-10 11:58:47 --> Language Class Initialized
INFO - 2018-05-10 11:58:47 --> Language Class Initialized
INFO - 2018-05-10 11:58:47 --> Config Class Initialized
INFO - 2018-05-10 11:58:47 --> Loader Class Initialized
INFO - 2018-05-10 17:28:47 --> Helper loaded: url_helper
INFO - 2018-05-10 17:28:47 --> Helper loaded: notification_helper
INFO - 2018-05-10 17:28:47 --> Helper loaded: settings_helper
INFO - 2018-05-10 17:28:47 --> Helper loaded: permission_helper
INFO - 2018-05-10 17:28:47 --> Helper loaded: users_helper
INFO - 2018-05-10 17:28:47 --> Database Driver Class Initialized
DEBUG - 2018-05-10 17:28:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 17:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 17:28:47 --> Helper loaded: form_helper
INFO - 2018-05-10 17:28:47 --> Form Validation Class Initialized
INFO - 2018-05-10 17:28:47 --> Controller Class Initialized
DEBUG - 2018-05-10 17:28:47 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-05-10 17:28:47 --> Final output sent to browser
DEBUG - 2018-05-10 17:28:47 --> Total execution time: 0.0867
INFO - 2018-05-10 11:58:50 --> Config Class Initialized
INFO - 2018-05-10 11:58:50 --> Hooks Class Initialized
DEBUG - 2018-05-10 11:58:50 --> UTF-8 Support Enabled
INFO - 2018-05-10 11:58:50 --> Utf8 Class Initialized
INFO - 2018-05-10 11:58:50 --> URI Class Initialized
INFO - 2018-05-10 11:58:50 --> Router Class Initialized
INFO - 2018-05-10 11:58:50 --> Output Class Initialized
INFO - 2018-05-10 11:58:50 --> Security Class Initialized
DEBUG - 2018-05-10 11:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 11:58:50 --> Input Class Initialized
INFO - 2018-05-10 11:58:50 --> Language Class Initialized
INFO - 2018-05-10 11:58:50 --> Language Class Initialized
INFO - 2018-05-10 11:58:50 --> Config Class Initialized
INFO - 2018-05-10 11:58:50 --> Loader Class Initialized
INFO - 2018-05-10 17:28:50 --> Helper loaded: url_helper
INFO - 2018-05-10 17:28:50 --> Helper loaded: notification_helper
INFO - 2018-05-10 17:28:50 --> Helper loaded: settings_helper
INFO - 2018-05-10 17:28:50 --> Helper loaded: permission_helper
INFO - 2018-05-10 17:28:50 --> Helper loaded: users_helper
INFO - 2018-05-10 17:28:50 --> Database Driver Class Initialized
DEBUG - 2018-05-10 17:28:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 17:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 17:28:50 --> Helper loaded: form_helper
INFO - 2018-05-10 17:28:50 --> Form Validation Class Initialized
INFO - 2018-05-10 17:28:50 --> Controller Class Initialized
INFO - 2018-05-10 17:28:50 --> Model Class Initialized
INFO - 2018-05-10 17:28:50 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 17:28:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 17:28:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 17:28:50 --> Model Class Initialized
INFO - 2018-05-10 17:28:50 --> Model Class Initialized
INFO - 2018-05-10 17:28:50 --> Model Class Initialized
INFO - 2018-05-10 17:28:50 --> Model Class Initialized
INFO - 2018-05-10 17:28:50 --> Model Class Initialized
INFO - 2018-05-10 17:28:50 --> Model Class Initialized
INFO - 2018-05-10 17:28:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 17:28:50 --> Final output sent to browser
DEBUG - 2018-05-10 17:28:50 --> Total execution time: 0.1075
INFO - 2018-05-10 12:00:15 --> Config Class Initialized
INFO - 2018-05-10 12:00:15 --> Hooks Class Initialized
DEBUG - 2018-05-10 12:00:15 --> UTF-8 Support Enabled
INFO - 2018-05-10 12:00:15 --> Utf8 Class Initialized
INFO - 2018-05-10 12:00:15 --> URI Class Initialized
INFO - 2018-05-10 12:00:15 --> Router Class Initialized
INFO - 2018-05-10 12:00:15 --> Output Class Initialized
INFO - 2018-05-10 12:00:15 --> Security Class Initialized
DEBUG - 2018-05-10 12:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 12:00:15 --> Input Class Initialized
INFO - 2018-05-10 12:00:15 --> Language Class Initialized
INFO - 2018-05-10 12:00:15 --> Language Class Initialized
INFO - 2018-05-10 12:00:15 --> Config Class Initialized
INFO - 2018-05-10 12:00:15 --> Loader Class Initialized
INFO - 2018-05-10 17:30:15 --> Helper loaded: url_helper
INFO - 2018-05-10 17:30:15 --> Helper loaded: notification_helper
INFO - 2018-05-10 17:30:15 --> Helper loaded: settings_helper
INFO - 2018-05-10 17:30:15 --> Helper loaded: permission_helper
INFO - 2018-05-10 17:30:15 --> Helper loaded: users_helper
INFO - 2018-05-10 17:30:15 --> Database Driver Class Initialized
DEBUG - 2018-05-10 17:30:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 17:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 17:30:15 --> Helper loaded: form_helper
INFO - 2018-05-10 17:30:15 --> Form Validation Class Initialized
INFO - 2018-05-10 17:30:15 --> Controller Class Initialized
INFO - 2018-05-10 17:30:15 --> Model Class Initialized
INFO - 2018-05-10 17:30:15 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 17:30:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 17:30:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 17:30:15 --> Model Class Initialized
INFO - 2018-05-10 17:30:15 --> Model Class Initialized
INFO - 2018-05-10 17:30:15 --> Model Class Initialized
INFO - 2018-05-10 17:30:15 --> Model Class Initialized
INFO - 2018-05-10 17:30:15 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 17:30:15 --> Model Class Initialized
INFO - 2018-05-10 17:30:15 --> Final output sent to browser
DEBUG - 2018-05-10 17:30:15 --> Total execution time: 0.1016
INFO - 2018-05-10 12:00:41 --> Config Class Initialized
INFO - 2018-05-10 12:00:41 --> Hooks Class Initialized
DEBUG - 2018-05-10 12:00:41 --> UTF-8 Support Enabled
INFO - 2018-05-10 12:00:41 --> Utf8 Class Initialized
INFO - 2018-05-10 12:00:41 --> URI Class Initialized
INFO - 2018-05-10 12:00:41 --> Router Class Initialized
INFO - 2018-05-10 12:00:41 --> Output Class Initialized
INFO - 2018-05-10 12:00:41 --> Security Class Initialized
DEBUG - 2018-05-10 12:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 12:00:41 --> Input Class Initialized
INFO - 2018-05-10 12:00:41 --> Language Class Initialized
INFO - 2018-05-10 12:00:41 --> Language Class Initialized
INFO - 2018-05-10 12:00:41 --> Config Class Initialized
INFO - 2018-05-10 12:00:41 --> Loader Class Initialized
INFO - 2018-05-10 17:30:41 --> Helper loaded: url_helper
INFO - 2018-05-10 17:30:41 --> Helper loaded: notification_helper
INFO - 2018-05-10 17:30:41 --> Helper loaded: settings_helper
INFO - 2018-05-10 17:30:41 --> Helper loaded: permission_helper
INFO - 2018-05-10 17:30:41 --> Helper loaded: users_helper
INFO - 2018-05-10 17:30:41 --> Database Driver Class Initialized
DEBUG - 2018-05-10 17:30:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 17:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 17:30:41 --> Helper loaded: form_helper
INFO - 2018-05-10 17:30:41 --> Form Validation Class Initialized
INFO - 2018-05-10 17:30:41 --> Controller Class Initialized
INFO - 2018-05-10 17:30:41 --> Model Class Initialized
INFO - 2018-05-10 17:30:41 --> Helper loaded: inflector_helper
INFO - 2018-05-10 17:30:41 --> Model Class Initialized
INFO - 2018-05-10 17:30:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-05-10 12:00:41 --> Config Class Initialized
INFO - 2018-05-10 12:00:41 --> Hooks Class Initialized
DEBUG - 2018-05-10 12:00:41 --> UTF-8 Support Enabled
INFO - 2018-05-10 12:00:41 --> Utf8 Class Initialized
INFO - 2018-05-10 12:00:41 --> URI Class Initialized
INFO - 2018-05-10 12:00:41 --> Router Class Initialized
INFO - 2018-05-10 12:00:41 --> Output Class Initialized
INFO - 2018-05-10 12:00:41 --> Security Class Initialized
DEBUG - 2018-05-10 12:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 12:00:41 --> Input Class Initialized
INFO - 2018-05-10 12:00:41 --> Language Class Initialized
INFO - 2018-05-10 12:00:41 --> Language Class Initialized
INFO - 2018-05-10 12:00:41 --> Config Class Initialized
INFO - 2018-05-10 12:00:41 --> Loader Class Initialized
INFO - 2018-05-10 17:30:41 --> Helper loaded: url_helper
INFO - 2018-05-10 17:30:41 --> Helper loaded: notification_helper
INFO - 2018-05-10 17:30:41 --> Helper loaded: settings_helper
INFO - 2018-05-10 17:30:41 --> Helper loaded: permission_helper
INFO - 2018-05-10 17:30:41 --> Helper loaded: users_helper
INFO - 2018-05-10 17:30:41 --> Database Driver Class Initialized
DEBUG - 2018-05-10 17:30:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 17:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 17:30:41 --> Helper loaded: form_helper
INFO - 2018-05-10 17:30:41 --> Form Validation Class Initialized
INFO - 2018-05-10 17:30:41 --> Controller Class Initialized
INFO - 2018-05-10 17:30:41 --> Model Class Initialized
INFO - 2018-05-10 17:30:41 --> Helper loaded: inflector_helper
INFO - 2018-05-10 17:30:41 --> Model Class Initialized
INFO - 2018-05-10 17:30:41 --> Model Class Initialized
INFO - 2018-05-10 17:30:41 --> Model Class Initialized
INFO - 2018-05-10 17:30:41 --> Model Class Initialized
INFO - 2018-05-10 17:30:41 --> Model Class Initialized
DEBUG - 2018-05-10 17:30:41 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-05-10 17:30:41 --> File loaded: /home/pr01004/public_html/application/views/admin/dashboard.php
DEBUG - 2018-05-10 17:30:41 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-05-10 17:30:41 --> Final output sent to browser
DEBUG - 2018-05-10 17:30:41 --> Total execution time: 0.0974
INFO - 2018-05-10 12:00:46 --> Config Class Initialized
INFO - 2018-05-10 12:00:46 --> Hooks Class Initialized
DEBUG - 2018-05-10 12:00:46 --> UTF-8 Support Enabled
INFO - 2018-05-10 12:00:46 --> Utf8 Class Initialized
INFO - 2018-05-10 12:00:46 --> URI Class Initialized
INFO - 2018-05-10 12:00:46 --> Router Class Initialized
INFO - 2018-05-10 12:00:46 --> Output Class Initialized
INFO - 2018-05-10 12:00:46 --> Security Class Initialized
DEBUG - 2018-05-10 12:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 12:00:46 --> Input Class Initialized
INFO - 2018-05-10 12:00:46 --> Language Class Initialized
INFO - 2018-05-10 12:00:46 --> Language Class Initialized
INFO - 2018-05-10 12:00:46 --> Config Class Initialized
INFO - 2018-05-10 12:00:46 --> Loader Class Initialized
INFO - 2018-05-10 17:30:46 --> Helper loaded: url_helper
INFO - 2018-05-10 17:30:46 --> Helper loaded: notification_helper
INFO - 2018-05-10 17:30:46 --> Helper loaded: settings_helper
INFO - 2018-05-10 17:30:46 --> Helper loaded: permission_helper
INFO - 2018-05-10 17:30:46 --> Helper loaded: users_helper
INFO - 2018-05-10 17:30:46 --> Database Driver Class Initialized
DEBUG - 2018-05-10 17:30:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 17:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 17:30:46 --> Helper loaded: form_helper
INFO - 2018-05-10 17:30:46 --> Form Validation Class Initialized
INFO - 2018-05-10 17:30:46 --> Controller Class Initialized
INFO - 2018-05-10 17:30:46 --> Model Class Initialized
INFO - 2018-05-10 17:30:46 --> Helper loaded: inflector_helper
INFO - 2018-05-10 17:30:46 --> Model Class Initialized
INFO - 2018-05-10 17:30:46 --> Model Class Initialized
DEBUG - 2018-05-10 17:30:46 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-05-10 17:30:46 --> File loaded: /home/pr01004/public_html/application/views/credits/index.php
DEBUG - 2018-05-10 17:30:46 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-05-10 17:30:46 --> Final output sent to browser
DEBUG - 2018-05-10 17:30:46 --> Total execution time: 0.1415
INFO - 2018-05-10 12:05:24 --> Config Class Initialized
INFO - 2018-05-10 12:05:24 --> Hooks Class Initialized
DEBUG - 2018-05-10 12:05:24 --> UTF-8 Support Enabled
INFO - 2018-05-10 12:05:24 --> Utf8 Class Initialized
INFO - 2018-05-10 12:05:24 --> URI Class Initialized
INFO - 2018-05-10 12:05:24 --> Router Class Initialized
INFO - 2018-05-10 12:05:24 --> Output Class Initialized
INFO - 2018-05-10 12:05:24 --> Security Class Initialized
DEBUG - 2018-05-10 12:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 12:05:24 --> Input Class Initialized
INFO - 2018-05-10 12:05:24 --> Language Class Initialized
INFO - 2018-05-10 12:05:24 --> Language Class Initialized
INFO - 2018-05-10 12:05:24 --> Config Class Initialized
INFO - 2018-05-10 12:05:24 --> Loader Class Initialized
INFO - 2018-05-10 17:35:24 --> Helper loaded: url_helper
INFO - 2018-05-10 17:35:24 --> Helper loaded: notification_helper
INFO - 2018-05-10 17:35:24 --> Helper loaded: settings_helper
INFO - 2018-05-10 17:35:24 --> Helper loaded: permission_helper
INFO - 2018-05-10 17:35:24 --> Helper loaded: users_helper
INFO - 2018-05-10 17:35:24 --> Database Driver Class Initialized
DEBUG - 2018-05-10 17:35:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 17:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 17:35:24 --> Helper loaded: form_helper
INFO - 2018-05-10 17:35:24 --> Form Validation Class Initialized
INFO - 2018-05-10 17:35:24 --> Controller Class Initialized
INFO - 2018-05-10 17:35:24 --> Model Class Initialized
INFO - 2018-05-10 17:35:24 --> Helper loaded: inflector_helper
INFO - 2018-05-10 17:35:24 --> Model Class Initialized
INFO - 2018-05-10 17:35:24 --> Model Class Initialized
DEBUG - 2018-05-10 17:35:24 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-05-10 17:35:24 --> File loaded: /home/pr01004/public_html/application/views/credits/index.php
DEBUG - 2018-05-10 17:35:24 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-05-10 17:35:24 --> Final output sent to browser
DEBUG - 2018-05-10 17:35:24 --> Total execution time: 0.1157
INFO - 2018-05-10 12:13:02 --> Config Class Initialized
INFO - 2018-05-10 12:13:02 --> Hooks Class Initialized
DEBUG - 2018-05-10 12:13:02 --> UTF-8 Support Enabled
INFO - 2018-05-10 12:13:02 --> Utf8 Class Initialized
INFO - 2018-05-10 12:13:02 --> URI Class Initialized
INFO - 2018-05-10 12:13:02 --> Router Class Initialized
INFO - 2018-05-10 12:13:02 --> Output Class Initialized
INFO - 2018-05-10 12:13:02 --> Security Class Initialized
DEBUG - 2018-05-10 12:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 12:13:02 --> Input Class Initialized
INFO - 2018-05-10 12:13:02 --> Language Class Initialized
INFO - 2018-05-10 12:13:02 --> Language Class Initialized
INFO - 2018-05-10 12:13:02 --> Config Class Initialized
INFO - 2018-05-10 12:13:02 --> Loader Class Initialized
INFO - 2018-05-10 17:43:02 --> Helper loaded: url_helper
INFO - 2018-05-10 17:43:02 --> Helper loaded: notification_helper
INFO - 2018-05-10 17:43:02 --> Helper loaded: settings_helper
INFO - 2018-05-10 17:43:02 --> Helper loaded: permission_helper
INFO - 2018-05-10 17:43:02 --> Helper loaded: users_helper
INFO - 2018-05-10 17:43:02 --> Database Driver Class Initialized
DEBUG - 2018-05-10 17:43:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 17:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 17:43:02 --> Helper loaded: form_helper
INFO - 2018-05-10 17:43:02 --> Form Validation Class Initialized
INFO - 2018-05-10 17:43:02 --> Controller Class Initialized
INFO - 2018-05-10 17:43:02 --> Model Class Initialized
INFO - 2018-05-10 17:43:02 --> Helper loaded: inflector_helper
INFO - 2018-05-10 17:43:02 --> Model Class Initialized
INFO - 2018-05-10 17:43:02 --> Model Class Initialized
DEBUG - 2018-05-10 17:43:02 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-05-10 17:43:02 --> File loaded: /home/pr01004/public_html/application/views/credits/index.php
DEBUG - 2018-05-10 17:43:02 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-05-10 17:43:02 --> Final output sent to browser
DEBUG - 2018-05-10 17:43:02 --> Total execution time: 0.1002
INFO - 2018-05-10 12:16:06 --> Config Class Initialized
INFO - 2018-05-10 12:16:06 --> Hooks Class Initialized
DEBUG - 2018-05-10 12:16:06 --> UTF-8 Support Enabled
INFO - 2018-05-10 12:16:06 --> Utf8 Class Initialized
INFO - 2018-05-10 12:16:06 --> URI Class Initialized
INFO - 2018-05-10 12:16:06 --> Router Class Initialized
INFO - 2018-05-10 12:16:06 --> Output Class Initialized
INFO - 2018-05-10 12:16:06 --> Security Class Initialized
DEBUG - 2018-05-10 12:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 12:16:06 --> Input Class Initialized
INFO - 2018-05-10 12:16:06 --> Language Class Initialized
INFO - 2018-05-10 12:16:06 --> Language Class Initialized
INFO - 2018-05-10 12:16:06 --> Config Class Initialized
INFO - 2018-05-10 12:16:06 --> Loader Class Initialized
INFO - 2018-05-10 17:46:06 --> Helper loaded: url_helper
INFO - 2018-05-10 17:46:06 --> Helper loaded: notification_helper
INFO - 2018-05-10 17:46:06 --> Helper loaded: settings_helper
INFO - 2018-05-10 17:46:06 --> Helper loaded: permission_helper
INFO - 2018-05-10 17:46:06 --> Helper loaded: users_helper
INFO - 2018-05-10 17:46:06 --> Database Driver Class Initialized
DEBUG - 2018-05-10 17:46:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 17:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 17:46:06 --> Helper loaded: form_helper
INFO - 2018-05-10 17:46:06 --> Form Validation Class Initialized
INFO - 2018-05-10 17:46:06 --> Controller Class Initialized
INFO - 2018-05-10 17:46:06 --> Model Class Initialized
INFO - 2018-05-10 17:46:06 --> Helper loaded: inflector_helper
INFO - 2018-05-10 17:46:06 --> Model Class Initialized
INFO - 2018-05-10 17:46:06 --> Model Class Initialized
DEBUG - 2018-05-10 17:46:06 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-05-10 17:46:06 --> File loaded: /home/pr01004/public_html/application/views/credits/index.php
DEBUG - 2018-05-10 17:46:06 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-05-10 17:46:06 --> Final output sent to browser
DEBUG - 2018-05-10 17:46:06 --> Total execution time: 0.1868
INFO - 2018-05-10 12:18:02 --> Config Class Initialized
INFO - 2018-05-10 12:18:02 --> Hooks Class Initialized
DEBUG - 2018-05-10 12:18:02 --> UTF-8 Support Enabled
INFO - 2018-05-10 12:18:02 --> Utf8 Class Initialized
INFO - 2018-05-10 12:18:02 --> URI Class Initialized
INFO - 2018-05-10 12:18:02 --> Router Class Initialized
INFO - 2018-05-10 12:18:02 --> Output Class Initialized
INFO - 2018-05-10 12:18:02 --> Security Class Initialized
DEBUG - 2018-05-10 12:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 12:18:02 --> Input Class Initialized
INFO - 2018-05-10 12:18:02 --> Language Class Initialized
INFO - 2018-05-10 12:18:02 --> Language Class Initialized
INFO - 2018-05-10 12:18:02 --> Config Class Initialized
INFO - 2018-05-10 12:18:02 --> Loader Class Initialized
INFO - 2018-05-10 17:48:02 --> Helper loaded: url_helper
INFO - 2018-05-10 17:48:02 --> Helper loaded: notification_helper
INFO - 2018-05-10 17:48:02 --> Helper loaded: settings_helper
INFO - 2018-05-10 17:48:02 --> Helper loaded: permission_helper
INFO - 2018-05-10 17:48:02 --> Helper loaded: users_helper
INFO - 2018-05-10 17:48:02 --> Database Driver Class Initialized
DEBUG - 2018-05-10 17:48:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 17:48:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 17:48:02 --> Helper loaded: form_helper
INFO - 2018-05-10 17:48:02 --> Form Validation Class Initialized
INFO - 2018-05-10 17:48:02 --> Controller Class Initialized
INFO - 2018-05-10 17:48:02 --> Model Class Initialized
INFO - 2018-05-10 17:48:02 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 17:48:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 17:48:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 17:48:02 --> Model Class Initialized
INFO - 2018-05-10 17:48:02 --> Model Class Initialized
INFO - 2018-05-10 17:48:02 --> Model Class Initialized
INFO - 2018-05-10 17:48:02 --> Model Class Initialized
INFO - 2018-05-10 17:48:02 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 17:48:02 --> Model Class Initialized
INFO - 2018-05-10 17:48:02 --> Final output sent to browser
DEBUG - 2018-05-10 17:48:02 --> Total execution time: 0.1821
INFO - 2018-05-10 12:50:00 --> Config Class Initialized
INFO - 2018-05-10 12:50:00 --> Hooks Class Initialized
DEBUG - 2018-05-10 12:50:00 --> UTF-8 Support Enabled
INFO - 2018-05-10 12:50:00 --> Utf8 Class Initialized
INFO - 2018-05-10 12:50:00 --> URI Class Initialized
INFO - 2018-05-10 12:50:00 --> Router Class Initialized
INFO - 2018-05-10 12:50:00 --> Output Class Initialized
INFO - 2018-05-10 12:50:00 --> Security Class Initialized
DEBUG - 2018-05-10 12:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 12:50:00 --> Input Class Initialized
INFO - 2018-05-10 12:50:00 --> Language Class Initialized
INFO - 2018-05-10 12:50:00 --> Language Class Initialized
INFO - 2018-05-10 12:50:00 --> Config Class Initialized
INFO - 2018-05-10 12:50:00 --> Loader Class Initialized
INFO - 2018-05-10 18:20:00 --> Helper loaded: url_helper
INFO - 2018-05-10 18:20:00 --> Helper loaded: notification_helper
INFO - 2018-05-10 18:20:00 --> Helper loaded: settings_helper
INFO - 2018-05-10 18:20:00 --> Helper loaded: permission_helper
INFO - 2018-05-10 18:20:00 --> Helper loaded: users_helper
INFO - 2018-05-10 18:20:00 --> Database Driver Class Initialized
DEBUG - 2018-05-10 18:20:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 18:20:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 18:20:00 --> Helper loaded: form_helper
INFO - 2018-05-10 18:20:00 --> Form Validation Class Initialized
INFO - 2018-05-10 18:20:00 --> Controller Class Initialized
INFO - 2018-05-10 18:20:00 --> Model Class Initialized
INFO - 2018-05-10 18:20:00 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 18:20:00 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 18:20:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 18:20:00 --> Model Class Initialized
INFO - 2018-05-10 18:20:00 --> Model Class Initialized
INFO - 2018-05-10 18:20:00 --> Model Class Initialized
INFO - 2018-05-10 18:20:00 --> Model Class Initialized
INFO - 2018-05-10 18:20:00 --> Model Class Initialized
INFO - 2018-05-10 18:20:00 --> Model Class Initialized
INFO - 2018-05-10 18:20:00 --> Model Class Initialized
INFO - 2018-05-10 18:20:00 --> Model Class Initialized
INFO - 2018-05-10 18:20:00 --> Model Class Initialized
INFO - 2018-05-10 18:20:00 --> Model Class Initialized
INFO - 2018-05-10 18:20:00 --> Model Class Initialized
INFO - 2018-05-10 18:20:00 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 18:20:00 --> Model Class Initialized
INFO - 2018-05-10 18:20:00 --> Final output sent to browser
DEBUG - 2018-05-10 18:20:00 --> Total execution time: 0.1169
INFO - 2018-05-10 12:50:01 --> Config Class Initialized
INFO - 2018-05-10 12:50:01 --> Hooks Class Initialized
DEBUG - 2018-05-10 12:50:01 --> UTF-8 Support Enabled
INFO - 2018-05-10 12:50:01 --> Utf8 Class Initialized
INFO - 2018-05-10 12:50:01 --> URI Class Initialized
INFO - 2018-05-10 12:50:01 --> Router Class Initialized
INFO - 2018-05-10 12:50:01 --> Output Class Initialized
INFO - 2018-05-10 12:50:01 --> Security Class Initialized
DEBUG - 2018-05-10 12:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 12:50:01 --> Input Class Initialized
INFO - 2018-05-10 12:50:01 --> Language Class Initialized
INFO - 2018-05-10 12:50:01 --> Language Class Initialized
INFO - 2018-05-10 12:50:01 --> Config Class Initialized
INFO - 2018-05-10 12:50:01 --> Loader Class Initialized
INFO - 2018-05-10 18:20:01 --> Helper loaded: url_helper
INFO - 2018-05-10 18:20:01 --> Helper loaded: notification_helper
INFO - 2018-05-10 18:20:01 --> Helper loaded: settings_helper
INFO - 2018-05-10 18:20:01 --> Helper loaded: permission_helper
INFO - 2018-05-10 18:20:01 --> Helper loaded: users_helper
INFO - 2018-05-10 18:20:01 --> Database Driver Class Initialized
DEBUG - 2018-05-10 18:20:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 18:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 18:20:01 --> Helper loaded: form_helper
INFO - 2018-05-10 18:20:01 --> Form Validation Class Initialized
INFO - 2018-05-10 18:20:01 --> Controller Class Initialized
INFO - 2018-05-10 18:20:01 --> Model Class Initialized
INFO - 2018-05-10 18:20:01 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 18:20:01 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 18:20:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 18:20:01 --> Model Class Initialized
INFO - 2018-05-10 18:20:01 --> Model Class Initialized
INFO - 2018-05-10 18:20:01 --> Model Class Initialized
INFO - 2018-05-10 18:20:01 --> Model Class Initialized
INFO - 2018-05-10 18:20:01 --> Model Class Initialized
INFO - 2018-05-10 18:20:01 --> Model Class Initialized
INFO - 2018-05-10 18:20:01 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 18:20:01 --> Model Class Initialized
INFO - 2018-05-10 18:20:01 --> Final output sent to browser
DEBUG - 2018-05-10 18:20:01 --> Total execution time: 0.1121
INFO - 2018-05-10 12:50:07 --> Config Class Initialized
INFO - 2018-05-10 12:50:07 --> Hooks Class Initialized
DEBUG - 2018-05-10 12:50:07 --> UTF-8 Support Enabled
INFO - 2018-05-10 12:50:07 --> Utf8 Class Initialized
INFO - 2018-05-10 12:50:07 --> URI Class Initialized
INFO - 2018-05-10 12:50:07 --> Router Class Initialized
INFO - 2018-05-10 12:50:07 --> Output Class Initialized
INFO - 2018-05-10 12:50:07 --> Security Class Initialized
DEBUG - 2018-05-10 12:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 12:50:07 --> Input Class Initialized
INFO - 2018-05-10 12:50:07 --> Language Class Initialized
INFO - 2018-05-10 12:50:07 --> Config Class Initialized
INFO - 2018-05-10 12:50:07 --> Hooks Class Initialized
DEBUG - 2018-05-10 12:50:07 --> UTF-8 Support Enabled
INFO - 2018-05-10 12:50:07 --> Utf8 Class Initialized
INFO - 2018-05-10 12:50:07 --> URI Class Initialized
INFO - 2018-05-10 12:50:07 --> Router Class Initialized
INFO - 2018-05-10 12:50:07 --> Output Class Initialized
INFO - 2018-05-10 12:50:07 --> Language Class Initialized
INFO - 2018-05-10 12:50:07 --> Config Class Initialized
INFO - 2018-05-10 12:50:07 --> Loader Class Initialized
INFO - 2018-05-10 12:50:07 --> Security Class Initialized
INFO - 2018-05-10 18:20:07 --> Helper loaded: url_helper
INFO - 2018-05-10 18:20:07 --> Helper loaded: notification_helper
INFO - 2018-05-10 18:20:07 --> Helper loaded: settings_helper
DEBUG - 2018-05-10 12:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 12:50:07 --> Input Class Initialized
INFO - 2018-05-10 18:20:07 --> Helper loaded: permission_helper
INFO - 2018-05-10 12:50:07 --> Language Class Initialized
INFO - 2018-05-10 18:20:07 --> Helper loaded: users_helper
INFO - 2018-05-10 18:20:07 --> Database Driver Class Initialized
INFO - 2018-05-10 12:50:07 --> Language Class Initialized
INFO - 2018-05-10 12:50:07 --> Config Class Initialized
INFO - 2018-05-10 12:50:07 --> Loader Class Initialized
DEBUG - 2018-05-10 18:20:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 18:20:07 --> Helper loaded: url_helper
INFO - 2018-05-10 18:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 18:20:07 --> Helper loaded: notification_helper
INFO - 2018-05-10 18:20:07 --> Helper loaded: settings_helper
INFO - 2018-05-10 18:20:07 --> Helper loaded: permission_helper
INFO - 2018-05-10 18:20:07 --> Helper loaded: users_helper
INFO - 2018-05-10 18:20:07 --> Helper loaded: form_helper
INFO - 2018-05-10 18:20:07 --> Form Validation Class Initialized
INFO - 2018-05-10 18:20:07 --> Controller Class Initialized
INFO - 2018-05-10 18:20:07 --> Database Driver Class Initialized
INFO - 2018-05-10 18:20:07 --> Model Class Initialized
DEBUG - 2018-05-10 18:20:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 18:20:07 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 18:20:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 18:20:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 18:20:07 --> Model Class Initialized
INFO - 2018-05-10 18:20:07 --> Model Class Initialized
INFO - 2018-05-10 18:20:07 --> Model Class Initialized
INFO - 2018-05-10 18:20:07 --> Model Class Initialized
INFO - 2018-05-10 18:20:07 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 18:20:07 --> Final output sent to browser
DEBUG - 2018-05-10 18:20:07 --> Total execution time: 0.1118
INFO - 2018-05-10 18:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 18:20:07 --> Helper loaded: form_helper
INFO - 2018-05-10 18:20:07 --> Form Validation Class Initialized
INFO - 2018-05-10 18:20:07 --> Controller Class Initialized
INFO - 2018-05-10 18:20:07 --> Model Class Initialized
INFO - 2018-05-10 18:20:07 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 18:20:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 18:20:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 18:20:07 --> Model Class Initialized
INFO - 2018-05-10 18:20:07 --> Model Class Initialized
INFO - 2018-05-10 18:20:07 --> Model Class Initialized
INFO - 2018-05-10 18:20:07 --> Model Class Initialized
INFO - 2018-05-10 18:20:07 --> Model Class Initialized
INFO - 2018-05-10 18:20:07 --> Model Class Initialized
INFO - 2018-05-10 18:20:07 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 18:20:07 --> Final output sent to browser
DEBUG - 2018-05-10 18:20:07 --> Total execution time: 0.1421
INFO - 2018-05-10 12:50:11 --> Config Class Initialized
INFO - 2018-05-10 12:50:11 --> Hooks Class Initialized
DEBUG - 2018-05-10 12:50:11 --> UTF-8 Support Enabled
INFO - 2018-05-10 12:50:11 --> Utf8 Class Initialized
INFO - 2018-05-10 12:50:11 --> URI Class Initialized
INFO - 2018-05-10 12:50:11 --> Router Class Initialized
INFO - 2018-05-10 12:50:11 --> Output Class Initialized
INFO - 2018-05-10 12:50:11 --> Security Class Initialized
DEBUG - 2018-05-10 12:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 12:50:11 --> Input Class Initialized
INFO - 2018-05-10 12:50:11 --> Language Class Initialized
INFO - 2018-05-10 12:50:11 --> Language Class Initialized
INFO - 2018-05-10 12:50:11 --> Config Class Initialized
INFO - 2018-05-10 12:50:11 --> Loader Class Initialized
INFO - 2018-05-10 18:20:11 --> Helper loaded: url_helper
INFO - 2018-05-10 18:20:11 --> Helper loaded: notification_helper
INFO - 2018-05-10 18:20:11 --> Helper loaded: settings_helper
INFO - 2018-05-10 18:20:11 --> Helper loaded: permission_helper
INFO - 2018-05-10 18:20:11 --> Helper loaded: users_helper
INFO - 2018-05-10 18:20:11 --> Database Driver Class Initialized
DEBUG - 2018-05-10 18:20:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 18:20:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 18:20:11 --> Helper loaded: form_helper
INFO - 2018-05-10 18:20:11 --> Form Validation Class Initialized
INFO - 2018-05-10 18:20:11 --> Controller Class Initialized
INFO - 2018-05-10 18:20:11 --> Model Class Initialized
INFO - 2018-05-10 18:20:11 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 18:20:11 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 18:20:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 18:20:11 --> Model Class Initialized
INFO - 2018-05-10 18:20:11 --> Model Class Initialized
INFO - 2018-05-10 18:20:11 --> Model Class Initialized
INFO - 2018-05-10 18:20:11 --> Model Class Initialized
INFO - 2018-05-10 18:20:11 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 18:20:11 --> Model Class Initialized
INFO - 2018-05-10 18:20:11 --> Final output sent to browser
DEBUG - 2018-05-10 18:20:11 --> Total execution time: 0.1128
INFO - 2018-05-10 12:56:31 --> Config Class Initialized
INFO - 2018-05-10 12:56:31 --> Hooks Class Initialized
DEBUG - 2018-05-10 12:56:31 --> UTF-8 Support Enabled
INFO - 2018-05-10 12:56:31 --> Utf8 Class Initialized
INFO - 2018-05-10 12:56:31 --> URI Class Initialized
INFO - 2018-05-10 12:56:31 --> Router Class Initialized
INFO - 2018-05-10 12:56:31 --> Output Class Initialized
INFO - 2018-05-10 12:56:31 --> Security Class Initialized
DEBUG - 2018-05-10 12:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 12:56:31 --> Input Class Initialized
INFO - 2018-05-10 12:56:31 --> Language Class Initialized
INFO - 2018-05-10 12:56:31 --> Language Class Initialized
INFO - 2018-05-10 12:56:31 --> Config Class Initialized
INFO - 2018-05-10 12:56:31 --> Loader Class Initialized
INFO - 2018-05-10 18:26:31 --> Helper loaded: url_helper
INFO - 2018-05-10 18:26:31 --> Helper loaded: notification_helper
INFO - 2018-05-10 18:26:31 --> Helper loaded: settings_helper
INFO - 2018-05-10 18:26:31 --> Helper loaded: permission_helper
INFO - 2018-05-10 18:26:31 --> Helper loaded: users_helper
INFO - 2018-05-10 18:26:31 --> Database Driver Class Initialized
DEBUG - 2018-05-10 18:26:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 18:26:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 18:26:31 --> Helper loaded: form_helper
INFO - 2018-05-10 18:26:31 --> Form Validation Class Initialized
INFO - 2018-05-10 18:26:31 --> Controller Class Initialized
INFO - 2018-05-10 18:26:31 --> Model Class Initialized
INFO - 2018-05-10 18:26:31 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 18:26:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 18:26:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 18:26:31 --> Model Class Initialized
INFO - 2018-05-10 18:26:31 --> Model Class Initialized
INFO - 2018-05-10 18:26:31 --> Model Class Initialized
INFO - 2018-05-10 18:26:31 --> Model Class Initialized
INFO - 2018-05-10 18:26:31 --> Model Class Initialized
INFO - 2018-05-10 18:26:31 --> Model Class Initialized
INFO - 2018-05-10 18:26:31 --> Model Class Initialized
INFO - 2018-05-10 18:26:31 --> Model Class Initialized
INFO - 2018-05-10 18:26:31 --> Model Class Initialized
INFO - 2018-05-10 18:26:31 --> Model Class Initialized
INFO - 2018-05-10 18:26:31 --> Model Class Initialized
INFO - 2018-05-10 18:26:31 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 18:26:31 --> Model Class Initialized
INFO - 2018-05-10 18:26:31 --> Final output sent to browser
DEBUG - 2018-05-10 18:26:31 --> Total execution time: 0.1180
INFO - 2018-05-10 12:56:31 --> Config Class Initialized
INFO - 2018-05-10 12:56:31 --> Hooks Class Initialized
DEBUG - 2018-05-10 12:56:31 --> UTF-8 Support Enabled
INFO - 2018-05-10 12:56:31 --> Utf8 Class Initialized
INFO - 2018-05-10 12:56:31 --> URI Class Initialized
INFO - 2018-05-10 12:56:31 --> Router Class Initialized
INFO - 2018-05-10 12:56:31 --> Output Class Initialized
INFO - 2018-05-10 12:56:31 --> Security Class Initialized
DEBUG - 2018-05-10 12:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 12:56:31 --> Input Class Initialized
INFO - 2018-05-10 12:56:31 --> Language Class Initialized
INFO - 2018-05-10 12:56:31 --> Language Class Initialized
INFO - 2018-05-10 12:56:31 --> Config Class Initialized
INFO - 2018-05-10 12:56:31 --> Loader Class Initialized
INFO - 2018-05-10 18:26:31 --> Helper loaded: url_helper
INFO - 2018-05-10 18:26:31 --> Helper loaded: notification_helper
INFO - 2018-05-10 18:26:31 --> Helper loaded: settings_helper
INFO - 2018-05-10 18:26:31 --> Helper loaded: permission_helper
INFO - 2018-05-10 18:26:31 --> Helper loaded: users_helper
INFO - 2018-05-10 18:26:31 --> Database Driver Class Initialized
DEBUG - 2018-05-10 18:26:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 18:26:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 18:26:31 --> Helper loaded: form_helper
INFO - 2018-05-10 18:26:31 --> Form Validation Class Initialized
INFO - 2018-05-10 18:26:31 --> Controller Class Initialized
INFO - 2018-05-10 18:26:31 --> Model Class Initialized
INFO - 2018-05-10 18:26:31 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 18:26:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 18:26:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 18:26:31 --> Model Class Initialized
INFO - 2018-05-10 18:26:31 --> Model Class Initialized
INFO - 2018-05-10 18:26:31 --> Model Class Initialized
INFO - 2018-05-10 18:26:31 --> Model Class Initialized
INFO - 2018-05-10 18:26:31 --> Model Class Initialized
INFO - 2018-05-10 18:26:31 --> Model Class Initialized
INFO - 2018-05-10 18:26:31 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 18:26:31 --> Model Class Initialized
INFO - 2018-05-10 18:26:31 --> Final output sent to browser
DEBUG - 2018-05-10 18:26:31 --> Total execution time: 0.1141
INFO - 2018-05-10 12:56:36 --> Config Class Initialized
INFO - 2018-05-10 12:56:36 --> Hooks Class Initialized
DEBUG - 2018-05-10 12:56:36 --> UTF-8 Support Enabled
INFO - 2018-05-10 12:56:36 --> Utf8 Class Initialized
INFO - 2018-05-10 12:56:36 --> URI Class Initialized
INFO - 2018-05-10 12:56:36 --> Router Class Initialized
INFO - 2018-05-10 12:56:36 --> Output Class Initialized
INFO - 2018-05-10 12:56:36 --> Security Class Initialized
DEBUG - 2018-05-10 12:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 12:56:36 --> Input Class Initialized
INFO - 2018-05-10 12:56:36 --> Language Class Initialized
INFO - 2018-05-10 12:56:36 --> Config Class Initialized
INFO - 2018-05-10 12:56:36 --> Hooks Class Initialized
DEBUG - 2018-05-10 12:56:36 --> UTF-8 Support Enabled
INFO - 2018-05-10 12:56:36 --> Utf8 Class Initialized
INFO - 2018-05-10 12:56:36 --> URI Class Initialized
INFO - 2018-05-10 12:56:36 --> Router Class Initialized
INFO - 2018-05-10 12:56:36 --> Language Class Initialized
INFO - 2018-05-10 12:56:36 --> Config Class Initialized
INFO - 2018-05-10 12:56:36 --> Loader Class Initialized
INFO - 2018-05-10 12:56:36 --> Output Class Initialized
INFO - 2018-05-10 18:26:36 --> Helper loaded: url_helper
INFO - 2018-05-10 12:56:36 --> Security Class Initialized
INFO - 2018-05-10 18:26:36 --> Helper loaded: notification_helper
INFO - 2018-05-10 18:26:36 --> Helper loaded: settings_helper
INFO - 2018-05-10 18:26:36 --> Helper loaded: permission_helper
DEBUG - 2018-05-10 12:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 12:56:36 --> Input Class Initialized
INFO - 2018-05-10 18:26:36 --> Helper loaded: users_helper
INFO - 2018-05-10 12:56:36 --> Language Class Initialized
INFO - 2018-05-10 18:26:36 --> Database Driver Class Initialized
DEBUG - 2018-05-10 18:26:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 12:56:36 --> Language Class Initialized
INFO - 2018-05-10 18:26:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 12:56:36 --> Config Class Initialized
INFO - 2018-05-10 12:56:36 --> Loader Class Initialized
INFO - 2018-05-10 18:26:36 --> Helper loaded: url_helper
INFO - 2018-05-10 18:26:36 --> Helper loaded: notification_helper
INFO - 2018-05-10 18:26:36 --> Helper loaded: settings_helper
INFO - 2018-05-10 18:26:36 --> Helper loaded: form_helper
INFO - 2018-05-10 18:26:36 --> Form Validation Class Initialized
INFO - 2018-05-10 18:26:36 --> Controller Class Initialized
INFO - 2018-05-10 18:26:36 --> Helper loaded: permission_helper
INFO - 2018-05-10 18:26:36 --> Helper loaded: users_helper
INFO - 2018-05-10 18:26:36 --> Model Class Initialized
INFO - 2018-05-10 18:26:36 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 18:26:36 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 18:26:36 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 18:26:36 --> Model Class Initialized
INFO - 2018-05-10 18:26:36 --> Model Class Initialized
INFO - 2018-05-10 18:26:36 --> Model Class Initialized
INFO - 2018-05-10 18:26:36 --> Model Class Initialized
INFO - 2018-05-10 18:26:36 --> Model Class Initialized
INFO - 2018-05-10 18:26:36 --> Model Class Initialized
INFO - 2018-05-10 18:26:36 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 18:26:36 --> Database Driver Class Initialized
INFO - 2018-05-10 18:26:36 --> Final output sent to browser
DEBUG - 2018-05-10 18:26:36 --> Total execution time: 0.1074
DEBUG - 2018-05-10 18:26:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 18:26:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 18:26:36 --> Helper loaded: form_helper
INFO - 2018-05-10 18:26:36 --> Form Validation Class Initialized
INFO - 2018-05-10 18:26:36 --> Controller Class Initialized
INFO - 2018-05-10 18:26:36 --> Model Class Initialized
INFO - 2018-05-10 18:26:36 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 18:26:36 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 18:26:36 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 18:26:36 --> Model Class Initialized
INFO - 2018-05-10 18:26:36 --> Model Class Initialized
INFO - 2018-05-10 18:26:36 --> Model Class Initialized
INFO - 2018-05-10 18:26:36 --> Model Class Initialized
INFO - 2018-05-10 18:26:36 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 18:26:36 --> Final output sent to browser
DEBUG - 2018-05-10 18:26:36 --> Total execution time: 0.1608
INFO - 2018-05-10 12:56:41 --> Config Class Initialized
INFO - 2018-05-10 12:56:41 --> Hooks Class Initialized
DEBUG - 2018-05-10 12:56:41 --> UTF-8 Support Enabled
INFO - 2018-05-10 12:56:41 --> Utf8 Class Initialized
INFO - 2018-05-10 12:56:41 --> URI Class Initialized
INFO - 2018-05-10 12:56:41 --> Router Class Initialized
INFO - 2018-05-10 12:56:41 --> Output Class Initialized
INFO - 2018-05-10 12:56:41 --> Security Class Initialized
DEBUG - 2018-05-10 12:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 12:56:41 --> Input Class Initialized
INFO - 2018-05-10 12:56:41 --> Language Class Initialized
INFO - 2018-05-10 12:56:41 --> Language Class Initialized
INFO - 2018-05-10 12:56:41 --> Config Class Initialized
INFO - 2018-05-10 12:56:41 --> Loader Class Initialized
INFO - 2018-05-10 18:26:41 --> Helper loaded: url_helper
INFO - 2018-05-10 18:26:41 --> Helper loaded: notification_helper
INFO - 2018-05-10 18:26:41 --> Helper loaded: settings_helper
INFO - 2018-05-10 18:26:41 --> Helper loaded: permission_helper
INFO - 2018-05-10 18:26:41 --> Helper loaded: users_helper
INFO - 2018-05-10 18:26:41 --> Database Driver Class Initialized
DEBUG - 2018-05-10 18:26:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 18:26:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 18:26:41 --> Helper loaded: form_helper
INFO - 2018-05-10 18:26:41 --> Form Validation Class Initialized
INFO - 2018-05-10 18:26:41 --> Controller Class Initialized
INFO - 2018-05-10 18:26:41 --> Model Class Initialized
INFO - 2018-05-10 18:26:41 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 18:26:41 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 18:26:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 18:26:41 --> Model Class Initialized
INFO - 2018-05-10 18:26:41 --> Model Class Initialized
INFO - 2018-05-10 18:26:41 --> Model Class Initialized
INFO - 2018-05-10 18:26:41 --> Model Class Initialized
INFO - 2018-05-10 18:26:41 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 18:26:41 --> Model Class Initialized
INFO - 2018-05-10 18:26:41 --> Final output sent to browser
DEBUG - 2018-05-10 18:26:41 --> Total execution time: 0.1067
INFO - 2018-05-10 13:01:13 --> Config Class Initialized
INFO - 2018-05-10 13:01:13 --> Hooks Class Initialized
DEBUG - 2018-05-10 13:01:13 --> UTF-8 Support Enabled
INFO - 2018-05-10 13:01:13 --> Utf8 Class Initialized
INFO - 2018-05-10 13:01:13 --> URI Class Initialized
INFO - 2018-05-10 13:01:13 --> Router Class Initialized
INFO - 2018-05-10 13:01:13 --> Output Class Initialized
INFO - 2018-05-10 13:01:13 --> Security Class Initialized
DEBUG - 2018-05-10 13:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 13:01:13 --> Input Class Initialized
INFO - 2018-05-10 13:01:13 --> Language Class Initialized
INFO - 2018-05-10 13:01:13 --> Language Class Initialized
INFO - 2018-05-10 13:01:13 --> Config Class Initialized
INFO - 2018-05-10 13:01:13 --> Loader Class Initialized
INFO - 2018-05-10 18:31:13 --> Helper loaded: url_helper
INFO - 2018-05-10 18:31:13 --> Helper loaded: notification_helper
INFO - 2018-05-10 18:31:13 --> Helper loaded: settings_helper
INFO - 2018-05-10 18:31:13 --> Helper loaded: permission_helper
INFO - 2018-05-10 18:31:13 --> Helper loaded: users_helper
INFO - 2018-05-10 18:31:13 --> Database Driver Class Initialized
DEBUG - 2018-05-10 18:31:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 18:31:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 18:31:13 --> Helper loaded: form_helper
INFO - 2018-05-10 18:31:13 --> Form Validation Class Initialized
INFO - 2018-05-10 18:31:13 --> Controller Class Initialized
INFO - 2018-05-10 18:31:13 --> Model Class Initialized
INFO - 2018-05-10 18:31:13 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 18:31:13 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 18:31:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 18:31:13 --> Model Class Initialized
INFO - 2018-05-10 18:31:13 --> Model Class Initialized
INFO - 2018-05-10 18:31:13 --> Model Class Initialized
INFO - 2018-05-10 18:31:13 --> Model Class Initialized
INFO - 2018-05-10 18:31:13 --> Model Class Initialized
INFO - 2018-05-10 18:31:13 --> Model Class Initialized
INFO - 2018-05-10 18:31:13 --> Model Class Initialized
INFO - 2018-05-10 18:31:13 --> Model Class Initialized
INFO - 2018-05-10 18:31:13 --> Model Class Initialized
INFO - 2018-05-10 18:31:13 --> Model Class Initialized
INFO - 2018-05-10 18:31:13 --> Model Class Initialized
INFO - 2018-05-10 18:31:13 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 18:31:13 --> Model Class Initialized
INFO - 2018-05-10 18:31:13 --> Final output sent to browser
DEBUG - 2018-05-10 18:31:13 --> Total execution time: 0.1201
INFO - 2018-05-10 13:01:15 --> Config Class Initialized
INFO - 2018-05-10 13:01:15 --> Hooks Class Initialized
DEBUG - 2018-05-10 13:01:15 --> UTF-8 Support Enabled
INFO - 2018-05-10 13:01:15 --> Utf8 Class Initialized
INFO - 2018-05-10 13:01:15 --> URI Class Initialized
INFO - 2018-05-10 13:01:15 --> Router Class Initialized
INFO - 2018-05-10 13:01:15 --> Output Class Initialized
INFO - 2018-05-10 13:01:15 --> Security Class Initialized
DEBUG - 2018-05-10 13:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 13:01:15 --> Input Class Initialized
INFO - 2018-05-10 13:01:15 --> Language Class Initialized
INFO - 2018-05-10 13:01:15 --> Language Class Initialized
INFO - 2018-05-10 13:01:15 --> Config Class Initialized
INFO - 2018-05-10 13:01:15 --> Loader Class Initialized
INFO - 2018-05-10 18:31:15 --> Helper loaded: url_helper
INFO - 2018-05-10 18:31:15 --> Helper loaded: notification_helper
INFO - 2018-05-10 18:31:15 --> Helper loaded: settings_helper
INFO - 2018-05-10 18:31:15 --> Helper loaded: permission_helper
INFO - 2018-05-10 18:31:15 --> Helper loaded: users_helper
INFO - 2018-05-10 18:31:15 --> Database Driver Class Initialized
DEBUG - 2018-05-10 18:31:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 18:31:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 18:31:15 --> Helper loaded: form_helper
INFO - 2018-05-10 18:31:15 --> Form Validation Class Initialized
INFO - 2018-05-10 18:31:15 --> Controller Class Initialized
INFO - 2018-05-10 18:31:15 --> Model Class Initialized
INFO - 2018-05-10 18:31:15 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 18:31:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 18:31:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 18:31:15 --> Model Class Initialized
INFO - 2018-05-10 18:31:15 --> Model Class Initialized
INFO - 2018-05-10 18:31:15 --> Model Class Initialized
INFO - 2018-05-10 18:31:15 --> Model Class Initialized
INFO - 2018-05-10 18:31:15 --> Model Class Initialized
INFO - 2018-05-10 18:31:15 --> Model Class Initialized
INFO - 2018-05-10 18:31:15 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 18:31:15 --> Model Class Initialized
INFO - 2018-05-10 18:31:15 --> Final output sent to browser
DEBUG - 2018-05-10 18:31:15 --> Total execution time: 0.1368
INFO - 2018-05-10 13:01:19 --> Config Class Initialized
INFO - 2018-05-10 13:01:19 --> Hooks Class Initialized
DEBUG - 2018-05-10 13:01:19 --> UTF-8 Support Enabled
INFO - 2018-05-10 13:01:19 --> Utf8 Class Initialized
INFO - 2018-05-10 13:01:19 --> URI Class Initialized
INFO - 2018-05-10 13:01:19 --> Router Class Initialized
INFO - 2018-05-10 13:01:19 --> Output Class Initialized
INFO - 2018-05-10 13:01:19 --> Security Class Initialized
DEBUG - 2018-05-10 13:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 13:01:19 --> Input Class Initialized
INFO - 2018-05-10 13:01:19 --> Language Class Initialized
INFO - 2018-05-10 13:01:19 --> Language Class Initialized
INFO - 2018-05-10 13:01:19 --> Config Class Initialized
INFO - 2018-05-10 13:01:19 --> Loader Class Initialized
INFO - 2018-05-10 18:31:19 --> Helper loaded: url_helper
INFO - 2018-05-10 18:31:19 --> Helper loaded: notification_helper
INFO - 2018-05-10 18:31:19 --> Helper loaded: settings_helper
INFO - 2018-05-10 18:31:19 --> Helper loaded: permission_helper
INFO - 2018-05-10 18:31:19 --> Helper loaded: users_helper
INFO - 2018-05-10 18:31:19 --> Database Driver Class Initialized
DEBUG - 2018-05-10 18:31:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 18:31:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 18:31:19 --> Helper loaded: form_helper
INFO - 2018-05-10 18:31:19 --> Form Validation Class Initialized
INFO - 2018-05-10 18:31:19 --> Controller Class Initialized
INFO - 2018-05-10 18:31:19 --> Model Class Initialized
INFO - 2018-05-10 18:31:19 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 18:31:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 18:31:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 18:31:19 --> Model Class Initialized
INFO - 2018-05-10 18:31:19 --> Model Class Initialized
INFO - 2018-05-10 18:31:19 --> Model Class Initialized
INFO - 2018-05-10 18:31:19 --> Model Class Initialized
INFO - 2018-05-10 18:31:19 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 13:01:19 --> Config Class Initialized
INFO - 2018-05-10 13:01:19 --> Hooks Class Initialized
DEBUG - 2018-05-10 13:01:19 --> UTF-8 Support Enabled
INFO - 2018-05-10 13:01:19 --> Utf8 Class Initialized
INFO - 2018-05-10 13:01:19 --> URI Class Initialized
INFO - 2018-05-10 13:01:19 --> Router Class Initialized
INFO - 2018-05-10 13:01:19 --> Output Class Initialized
INFO - 2018-05-10 13:01:19 --> Security Class Initialized
DEBUG - 2018-05-10 13:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 13:01:19 --> Input Class Initialized
INFO - 2018-05-10 13:01:19 --> Language Class Initialized
INFO - 2018-05-10 13:01:19 --> Language Class Initialized
INFO - 2018-05-10 13:01:19 --> Config Class Initialized
INFO - 2018-05-10 13:01:19 --> Loader Class Initialized
INFO - 2018-05-10 18:31:19 --> Final output sent to browser
DEBUG - 2018-05-10 18:31:19 --> Total execution time: 0.3739
INFO - 2018-05-10 18:31:20 --> Helper loaded: url_helper
INFO - 2018-05-10 18:31:20 --> Helper loaded: notification_helper
INFO - 2018-05-10 18:31:20 --> Helper loaded: settings_helper
INFO - 2018-05-10 18:31:20 --> Helper loaded: permission_helper
INFO - 2018-05-10 18:31:20 --> Helper loaded: users_helper
INFO - 2018-05-10 18:31:20 --> Database Driver Class Initialized
DEBUG - 2018-05-10 18:31:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 18:31:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 18:31:20 --> Helper loaded: form_helper
INFO - 2018-05-10 18:31:20 --> Form Validation Class Initialized
INFO - 2018-05-10 18:31:20 --> Controller Class Initialized
INFO - 2018-05-10 18:31:20 --> Model Class Initialized
INFO - 2018-05-10 18:31:20 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 18:31:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 18:31:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 18:31:20 --> Model Class Initialized
INFO - 2018-05-10 18:31:20 --> Model Class Initialized
INFO - 2018-05-10 18:31:20 --> Model Class Initialized
INFO - 2018-05-10 18:31:20 --> Model Class Initialized
INFO - 2018-05-10 18:31:20 --> Model Class Initialized
INFO - 2018-05-10 18:31:20 --> Model Class Initialized
INFO - 2018-05-10 18:31:20 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 18:31:20 --> Final output sent to browser
DEBUG - 2018-05-10 18:31:20 --> Total execution time: 0.1460
INFO - 2018-05-10 13:01:22 --> Config Class Initialized
INFO - 2018-05-10 13:01:22 --> Hooks Class Initialized
DEBUG - 2018-05-10 13:01:22 --> UTF-8 Support Enabled
INFO - 2018-05-10 13:01:22 --> Utf8 Class Initialized
INFO - 2018-05-10 13:01:22 --> URI Class Initialized
INFO - 2018-05-10 13:01:22 --> Router Class Initialized
INFO - 2018-05-10 13:01:22 --> Output Class Initialized
INFO - 2018-05-10 13:01:22 --> Security Class Initialized
DEBUG - 2018-05-10 13:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 13:01:22 --> Input Class Initialized
INFO - 2018-05-10 13:01:22 --> Language Class Initialized
INFO - 2018-05-10 13:01:22 --> Language Class Initialized
INFO - 2018-05-10 13:01:22 --> Config Class Initialized
INFO - 2018-05-10 13:01:22 --> Loader Class Initialized
INFO - 2018-05-10 18:31:22 --> Helper loaded: url_helper
INFO - 2018-05-10 18:31:22 --> Helper loaded: notification_helper
INFO - 2018-05-10 18:31:22 --> Helper loaded: settings_helper
INFO - 2018-05-10 18:31:22 --> Helper loaded: permission_helper
INFO - 2018-05-10 18:31:22 --> Helper loaded: users_helper
INFO - 2018-05-10 18:31:22 --> Database Driver Class Initialized
DEBUG - 2018-05-10 18:31:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 18:31:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 18:31:22 --> Helper loaded: form_helper
INFO - 2018-05-10 18:31:22 --> Form Validation Class Initialized
INFO - 2018-05-10 18:31:22 --> Controller Class Initialized
INFO - 2018-05-10 18:31:22 --> Model Class Initialized
INFO - 2018-05-10 18:31:22 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 18:31:22 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 18:31:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 18:31:22 --> Model Class Initialized
INFO - 2018-05-10 18:31:22 --> Model Class Initialized
INFO - 2018-05-10 18:31:22 --> Model Class Initialized
INFO - 2018-05-10 18:31:22 --> Model Class Initialized
INFO - 2018-05-10 18:31:22 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 18:31:22 --> Model Class Initialized
INFO - 2018-05-10 18:31:22 --> Final output sent to browser
DEBUG - 2018-05-10 18:31:22 --> Total execution time: 0.1170
INFO - 2018-05-10 13:02:19 --> Config Class Initialized
INFO - 2018-05-10 13:02:19 --> Hooks Class Initialized
DEBUG - 2018-05-10 13:02:19 --> UTF-8 Support Enabled
INFO - 2018-05-10 13:02:19 --> Utf8 Class Initialized
INFO - 2018-05-10 13:02:19 --> URI Class Initialized
INFO - 2018-05-10 13:02:19 --> Router Class Initialized
INFO - 2018-05-10 13:02:19 --> Output Class Initialized
INFO - 2018-05-10 13:02:19 --> Security Class Initialized
DEBUG - 2018-05-10 13:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 13:02:19 --> Input Class Initialized
INFO - 2018-05-10 13:02:19 --> Language Class Initialized
INFO - 2018-05-10 13:02:19 --> Language Class Initialized
INFO - 2018-05-10 13:02:19 --> Config Class Initialized
INFO - 2018-05-10 13:02:19 --> Loader Class Initialized
INFO - 2018-05-10 18:32:19 --> Helper loaded: url_helper
INFO - 2018-05-10 18:32:19 --> Helper loaded: notification_helper
INFO - 2018-05-10 18:32:19 --> Helper loaded: settings_helper
INFO - 2018-05-10 18:32:19 --> Helper loaded: permission_helper
INFO - 2018-05-10 18:32:19 --> Helper loaded: users_helper
INFO - 2018-05-10 18:32:19 --> Database Driver Class Initialized
DEBUG - 2018-05-10 18:32:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 18:32:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 18:32:19 --> Helper loaded: form_helper
INFO - 2018-05-10 18:32:19 --> Form Validation Class Initialized
INFO - 2018-05-10 18:32:19 --> Controller Class Initialized
INFO - 2018-05-10 18:32:19 --> Model Class Initialized
INFO - 2018-05-10 18:32:19 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 18:32:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 18:32:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 18:32:19 --> Model Class Initialized
INFO - 2018-05-10 18:32:19 --> Model Class Initialized
INFO - 2018-05-10 18:32:19 --> Model Class Initialized
INFO - 2018-05-10 18:32:19 --> Model Class Initialized
INFO - 2018-05-10 18:32:19 --> Model Class Initialized
INFO - 2018-05-10 18:32:19 --> Model Class Initialized
INFO - 2018-05-10 18:32:19 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 18:32:19 --> Final output sent to browser
DEBUG - 2018-05-10 18:32:19 --> Total execution time: 0.1077
INFO - 2018-05-10 13:02:21 --> Config Class Initialized
INFO - 2018-05-10 13:02:21 --> Hooks Class Initialized
DEBUG - 2018-05-10 13:02:21 --> UTF-8 Support Enabled
INFO - 2018-05-10 13:02:21 --> Utf8 Class Initialized
INFO - 2018-05-10 13:02:21 --> URI Class Initialized
INFO - 2018-05-10 13:02:21 --> Router Class Initialized
INFO - 2018-05-10 13:02:21 --> Output Class Initialized
INFO - 2018-05-10 13:02:21 --> Security Class Initialized
DEBUG - 2018-05-10 13:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 13:02:21 --> Input Class Initialized
INFO - 2018-05-10 13:02:21 --> Language Class Initialized
INFO - 2018-05-10 13:02:21 --> Language Class Initialized
INFO - 2018-05-10 13:02:21 --> Config Class Initialized
INFO - 2018-05-10 13:02:21 --> Loader Class Initialized
INFO - 2018-05-10 18:32:21 --> Helper loaded: url_helper
INFO - 2018-05-10 18:32:21 --> Helper loaded: notification_helper
INFO - 2018-05-10 18:32:21 --> Helper loaded: settings_helper
INFO - 2018-05-10 18:32:21 --> Helper loaded: permission_helper
INFO - 2018-05-10 18:32:21 --> Helper loaded: users_helper
INFO - 2018-05-10 18:32:21 --> Database Driver Class Initialized
DEBUG - 2018-05-10 18:32:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 18:32:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 18:32:21 --> Helper loaded: form_helper
INFO - 2018-05-10 18:32:21 --> Form Validation Class Initialized
INFO - 2018-05-10 18:32:21 --> Controller Class Initialized
INFO - 2018-05-10 18:32:21 --> Model Class Initialized
INFO - 2018-05-10 18:32:21 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 18:32:21 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 18:32:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 18:32:21 --> Model Class Initialized
INFO - 2018-05-10 18:32:21 --> Model Class Initialized
INFO - 2018-05-10 18:32:21 --> Model Class Initialized
INFO - 2018-05-10 18:32:21 --> Model Class Initialized
INFO - 2018-05-10 18:32:21 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 18:32:21 --> Model Class Initialized
INFO - 2018-05-10 18:32:21 --> Final output sent to browser
DEBUG - 2018-05-10 18:32:21 --> Total execution time: 0.0969
INFO - 2018-05-10 13:08:45 --> Config Class Initialized
INFO - 2018-05-10 13:08:45 --> Hooks Class Initialized
DEBUG - 2018-05-10 13:08:45 --> UTF-8 Support Enabled
INFO - 2018-05-10 13:08:45 --> Utf8 Class Initialized
INFO - 2018-05-10 13:08:45 --> URI Class Initialized
INFO - 2018-05-10 13:08:45 --> Router Class Initialized
INFO - 2018-05-10 13:08:45 --> Output Class Initialized
INFO - 2018-05-10 13:08:45 --> Security Class Initialized
DEBUG - 2018-05-10 13:08:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 13:08:45 --> Input Class Initialized
INFO - 2018-05-10 13:08:45 --> Language Class Initialized
INFO - 2018-05-10 13:08:45 --> Language Class Initialized
INFO - 2018-05-10 13:08:45 --> Config Class Initialized
INFO - 2018-05-10 13:08:45 --> Loader Class Initialized
INFO - 2018-05-10 18:38:45 --> Helper loaded: url_helper
INFO - 2018-05-10 18:38:45 --> Helper loaded: notification_helper
INFO - 2018-05-10 18:38:45 --> Helper loaded: settings_helper
INFO - 2018-05-10 18:38:45 --> Helper loaded: permission_helper
INFO - 2018-05-10 18:38:45 --> Helper loaded: users_helper
INFO - 2018-05-10 18:38:45 --> Database Driver Class Initialized
DEBUG - 2018-05-10 18:38:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 18:38:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 18:38:45 --> Helper loaded: form_helper
INFO - 2018-05-10 18:38:45 --> Form Validation Class Initialized
INFO - 2018-05-10 18:38:45 --> Controller Class Initialized
INFO - 2018-05-10 18:38:45 --> Model Class Initialized
INFO - 2018-05-10 18:38:45 --> Helper loaded: inflector_helper
INFO - 2018-05-10 18:38:45 --> Model Class Initialized
DEBUG - 2018-05-10 18:38:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 18:38:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 18:38:45 --> Model Class Initialized
INFO - 2018-05-10 18:38:45 --> Model Class Initialized
INFO - 2018-05-10 18:38:45 --> Model Class Initialized
INFO - 2018-05-10 18:38:45 --> Model Class Initialized
INFO - 2018-05-10 18:38:45 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 18:38:45 --> Model Class Initialized
INFO - 2018-05-10 18:38:45 --> Final output sent to browser
DEBUG - 2018-05-10 18:38:45 --> Total execution time: 0.1220
INFO - 2018-05-10 13:08:46 --> Config Class Initialized
INFO - 2018-05-10 13:08:46 --> Hooks Class Initialized
DEBUG - 2018-05-10 13:08:46 --> UTF-8 Support Enabled
INFO - 2018-05-10 13:08:46 --> Utf8 Class Initialized
INFO - 2018-05-10 13:08:46 --> URI Class Initialized
INFO - 2018-05-10 13:08:46 --> Router Class Initialized
INFO - 2018-05-10 13:08:46 --> Output Class Initialized
INFO - 2018-05-10 13:08:46 --> Security Class Initialized
DEBUG - 2018-05-10 13:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 13:08:46 --> Input Class Initialized
INFO - 2018-05-10 13:08:46 --> Language Class Initialized
INFO - 2018-05-10 13:08:46 --> Language Class Initialized
INFO - 2018-05-10 13:08:46 --> Config Class Initialized
INFO - 2018-05-10 13:08:46 --> Loader Class Initialized
INFO - 2018-05-10 18:38:46 --> Helper loaded: url_helper
INFO - 2018-05-10 18:38:46 --> Helper loaded: notification_helper
INFO - 2018-05-10 18:38:46 --> Helper loaded: settings_helper
INFO - 2018-05-10 18:38:46 --> Helper loaded: permission_helper
INFO - 2018-05-10 18:38:46 --> Helper loaded: users_helper
INFO - 2018-05-10 18:38:46 --> Database Driver Class Initialized
DEBUG - 2018-05-10 18:38:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 18:38:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 18:38:46 --> Helper loaded: form_helper
INFO - 2018-05-10 18:38:46 --> Form Validation Class Initialized
INFO - 2018-05-10 18:38:46 --> Controller Class Initialized
DEBUG - 2018-05-10 18:38:46 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-05-10 18:38:46 --> Final output sent to browser
DEBUG - 2018-05-10 18:38:46 --> Total execution time: 0.0763
INFO - 2018-05-10 13:10:26 --> Config Class Initialized
INFO - 2018-05-10 13:10:26 --> Hooks Class Initialized
DEBUG - 2018-05-10 13:10:26 --> UTF-8 Support Enabled
INFO - 2018-05-10 13:10:26 --> Utf8 Class Initialized
INFO - 2018-05-10 13:10:26 --> URI Class Initialized
INFO - 2018-05-10 13:10:26 --> Router Class Initialized
INFO - 2018-05-10 13:10:26 --> Output Class Initialized
INFO - 2018-05-10 13:10:26 --> Security Class Initialized
DEBUG - 2018-05-10 13:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 13:10:26 --> Input Class Initialized
INFO - 2018-05-10 13:10:26 --> Language Class Initialized
INFO - 2018-05-10 13:10:26 --> Language Class Initialized
INFO - 2018-05-10 13:10:26 --> Config Class Initialized
INFO - 2018-05-10 13:10:26 --> Loader Class Initialized
INFO - 2018-05-10 18:40:26 --> Helper loaded: url_helper
INFO - 2018-05-10 18:40:26 --> Helper loaded: notification_helper
INFO - 2018-05-10 18:40:26 --> Helper loaded: settings_helper
INFO - 2018-05-10 18:40:26 --> Helper loaded: permission_helper
INFO - 2018-05-10 18:40:26 --> Helper loaded: users_helper
INFO - 2018-05-10 18:40:26 --> Database Driver Class Initialized
DEBUG - 2018-05-10 18:40:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 18:40:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 18:40:26 --> Helper loaded: form_helper
INFO - 2018-05-10 18:40:26 --> Form Validation Class Initialized
INFO - 2018-05-10 18:40:26 --> Controller Class Initialized
INFO - 2018-05-10 18:40:26 --> Model Class Initialized
INFO - 2018-05-10 18:40:26 --> Helper loaded: inflector_helper
INFO - 2018-05-10 18:40:26 --> Model Class Initialized
INFO - 2018-05-10 18:40:26 --> Model Class Initialized
DEBUG - 2018-05-10 18:40:26 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-05-10 18:40:26 --> File loaded: /home/pr01004/public_html/application/views/users/usersList.php
DEBUG - 2018-05-10 18:40:26 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-05-10 18:40:26 --> Final output sent to browser
DEBUG - 2018-05-10 18:40:26 --> Total execution time: 0.1049
INFO - 2018-05-10 13:10:27 --> Config Class Initialized
INFO - 2018-05-10 13:10:27 --> Hooks Class Initialized
DEBUG - 2018-05-10 13:10:27 --> UTF-8 Support Enabled
INFO - 2018-05-10 13:10:27 --> Utf8 Class Initialized
INFO - 2018-05-10 13:10:27 --> URI Class Initialized
INFO - 2018-05-10 13:10:27 --> Router Class Initialized
INFO - 2018-05-10 13:10:27 --> Output Class Initialized
INFO - 2018-05-10 13:10:27 --> Security Class Initialized
DEBUG - 2018-05-10 13:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 13:10:27 --> Input Class Initialized
INFO - 2018-05-10 13:10:27 --> Language Class Initialized
INFO - 2018-05-10 13:10:27 --> Language Class Initialized
INFO - 2018-05-10 13:10:27 --> Config Class Initialized
INFO - 2018-05-10 13:10:27 --> Loader Class Initialized
INFO - 2018-05-10 18:40:27 --> Helper loaded: url_helper
INFO - 2018-05-10 18:40:27 --> Helper loaded: notification_helper
INFO - 2018-05-10 18:40:27 --> Helper loaded: settings_helper
INFO - 2018-05-10 18:40:27 --> Helper loaded: permission_helper
INFO - 2018-05-10 18:40:27 --> Helper loaded: users_helper
INFO - 2018-05-10 18:40:27 --> Database Driver Class Initialized
DEBUG - 2018-05-10 18:40:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 18:40:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 18:40:27 --> Helper loaded: form_helper
INFO - 2018-05-10 18:40:27 --> Form Validation Class Initialized
INFO - 2018-05-10 18:40:27 --> Controller Class Initialized
INFO - 2018-05-10 18:40:27 --> Model Class Initialized
INFO - 2018-05-10 18:40:27 --> Helper loaded: inflector_helper
INFO - 2018-05-10 18:40:27 --> Model Class Initialized
INFO - 2018-05-10 18:40:27 --> Model Class Initialized
INFO - 2018-05-10 18:40:27 --> Model Class Initialized
INFO - 2018-05-10 18:40:27 --> Final output sent to browser
DEBUG - 2018-05-10 18:40:27 --> Total execution time: 0.1030
INFO - 2018-05-10 13:11:34 --> Config Class Initialized
INFO - 2018-05-10 13:11:34 --> Hooks Class Initialized
DEBUG - 2018-05-10 13:11:34 --> UTF-8 Support Enabled
INFO - 2018-05-10 13:11:34 --> Utf8 Class Initialized
INFO - 2018-05-10 13:11:34 --> URI Class Initialized
INFO - 2018-05-10 13:11:34 --> Router Class Initialized
INFO - 2018-05-10 13:11:34 --> Output Class Initialized
INFO - 2018-05-10 13:11:34 --> Security Class Initialized
DEBUG - 2018-05-10 13:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 13:11:34 --> Input Class Initialized
INFO - 2018-05-10 13:11:34 --> Language Class Initialized
INFO - 2018-05-10 13:11:34 --> Language Class Initialized
INFO - 2018-05-10 13:11:34 --> Config Class Initialized
INFO - 2018-05-10 13:11:34 --> Loader Class Initialized
INFO - 2018-05-10 18:41:34 --> Helper loaded: url_helper
INFO - 2018-05-10 18:41:34 --> Helper loaded: notification_helper
INFO - 2018-05-10 18:41:34 --> Helper loaded: settings_helper
INFO - 2018-05-10 18:41:34 --> Helper loaded: permission_helper
INFO - 2018-05-10 18:41:34 --> Helper loaded: users_helper
INFO - 2018-05-10 18:41:34 --> Database Driver Class Initialized
DEBUG - 2018-05-10 18:41:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 18:41:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 18:41:34 --> Helper loaded: form_helper
INFO - 2018-05-10 18:41:34 --> Form Validation Class Initialized
INFO - 2018-05-10 18:41:34 --> Controller Class Initialized
INFO - 2018-05-10 18:41:34 --> Model Class Initialized
INFO - 2018-05-10 18:41:34 --> Helper loaded: inflector_helper
INFO - 2018-05-10 18:41:34 --> Model Class Initialized
INFO - 2018-05-10 18:41:34 --> Model Class Initialized
INFO - 2018-05-10 18:41:34 --> Model Class Initialized
INFO - 2018-05-10 18:41:34 --> Final output sent to browser
DEBUG - 2018-05-10 18:41:34 --> Total execution time: 0.0983
INFO - 2018-05-10 13:11:39 --> Config Class Initialized
INFO - 2018-05-10 13:11:39 --> Hooks Class Initialized
DEBUG - 2018-05-10 13:11:39 --> UTF-8 Support Enabled
INFO - 2018-05-10 13:11:39 --> Utf8 Class Initialized
INFO - 2018-05-10 13:11:39 --> URI Class Initialized
INFO - 2018-05-10 13:11:39 --> Router Class Initialized
INFO - 2018-05-10 13:11:39 --> Output Class Initialized
INFO - 2018-05-10 13:11:39 --> Security Class Initialized
DEBUG - 2018-05-10 13:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 13:11:40 --> Input Class Initialized
INFO - 2018-05-10 13:11:40 --> Language Class Initialized
INFO - 2018-05-10 13:11:40 --> Language Class Initialized
INFO - 2018-05-10 13:11:40 --> Config Class Initialized
INFO - 2018-05-10 13:11:40 --> Loader Class Initialized
INFO - 2018-05-10 18:41:40 --> Helper loaded: url_helper
INFO - 2018-05-10 18:41:40 --> Helper loaded: notification_helper
INFO - 2018-05-10 18:41:40 --> Helper loaded: settings_helper
INFO - 2018-05-10 18:41:40 --> Helper loaded: permission_helper
INFO - 2018-05-10 18:41:40 --> Helper loaded: users_helper
INFO - 2018-05-10 18:41:40 --> Database Driver Class Initialized
DEBUG - 2018-05-10 18:41:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 18:41:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 18:41:40 --> Helper loaded: form_helper
INFO - 2018-05-10 18:41:40 --> Form Validation Class Initialized
INFO - 2018-05-10 18:41:40 --> Controller Class Initialized
INFO - 2018-05-10 18:41:40 --> Model Class Initialized
INFO - 2018-05-10 18:41:40 --> Helper loaded: inflector_helper
INFO - 2018-05-10 18:41:40 --> Model Class Initialized
INFO - 2018-05-10 18:41:40 --> Model Class Initialized
INFO - 2018-05-10 18:41:40 --> Model Class Initialized
INFO - 2018-05-10 18:41:40 --> Final output sent to browser
DEBUG - 2018-05-10 18:41:40 --> Total execution time: 0.1246
INFO - 2018-05-10 13:11:45 --> Config Class Initialized
INFO - 2018-05-10 13:11:45 --> Hooks Class Initialized
DEBUG - 2018-05-10 13:11:45 --> UTF-8 Support Enabled
INFO - 2018-05-10 13:11:45 --> Utf8 Class Initialized
INFO - 2018-05-10 13:11:45 --> URI Class Initialized
INFO - 2018-05-10 13:11:45 --> Router Class Initialized
INFO - 2018-05-10 13:11:45 --> Output Class Initialized
INFO - 2018-05-10 13:11:45 --> Security Class Initialized
DEBUG - 2018-05-10 13:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 13:11:45 --> Input Class Initialized
INFO - 2018-05-10 13:11:45 --> Language Class Initialized
INFO - 2018-05-10 13:11:45 --> Language Class Initialized
INFO - 2018-05-10 13:11:45 --> Config Class Initialized
INFO - 2018-05-10 13:11:45 --> Loader Class Initialized
INFO - 2018-05-10 18:41:45 --> Helper loaded: url_helper
INFO - 2018-05-10 18:41:45 --> Helper loaded: notification_helper
INFO - 2018-05-10 18:41:45 --> Helper loaded: settings_helper
INFO - 2018-05-10 18:41:45 --> Helper loaded: permission_helper
INFO - 2018-05-10 18:41:45 --> Helper loaded: users_helper
INFO - 2018-05-10 18:41:45 --> Database Driver Class Initialized
DEBUG - 2018-05-10 18:41:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 18:41:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 18:41:45 --> Helper loaded: form_helper
INFO - 2018-05-10 18:41:45 --> Form Validation Class Initialized
INFO - 2018-05-10 18:41:45 --> Controller Class Initialized
INFO - 2018-05-10 18:41:45 --> Model Class Initialized
INFO - 2018-05-10 18:41:45 --> Helper loaded: inflector_helper
INFO - 2018-05-10 18:41:45 --> Model Class Initialized
INFO - 2018-05-10 18:41:45 --> Model Class Initialized
INFO - 2018-05-10 18:41:45 --> Model Class Initialized
INFO - 2018-05-10 18:41:45 --> Final output sent to browser
DEBUG - 2018-05-10 18:41:45 --> Total execution time: 0.1406
INFO - 2018-05-10 13:11:45 --> Config Class Initialized
INFO - 2018-05-10 13:11:45 --> Hooks Class Initialized
DEBUG - 2018-05-10 13:11:45 --> UTF-8 Support Enabled
INFO - 2018-05-10 13:11:45 --> Utf8 Class Initialized
INFO - 2018-05-10 13:11:45 --> URI Class Initialized
INFO - 2018-05-10 13:11:45 --> Router Class Initialized
INFO - 2018-05-10 13:11:45 --> Output Class Initialized
INFO - 2018-05-10 13:11:45 --> Security Class Initialized
DEBUG - 2018-05-10 13:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 13:11:45 --> Input Class Initialized
INFO - 2018-05-10 13:11:45 --> Language Class Initialized
INFO - 2018-05-10 13:11:45 --> Language Class Initialized
INFO - 2018-05-10 13:11:45 --> Config Class Initialized
INFO - 2018-05-10 13:11:45 --> Loader Class Initialized
INFO - 2018-05-10 18:41:45 --> Helper loaded: url_helper
INFO - 2018-05-10 18:41:45 --> Helper loaded: notification_helper
INFO - 2018-05-10 18:41:45 --> Helper loaded: settings_helper
INFO - 2018-05-10 18:41:45 --> Helper loaded: permission_helper
INFO - 2018-05-10 18:41:45 --> Helper loaded: users_helper
INFO - 2018-05-10 18:41:45 --> Database Driver Class Initialized
DEBUG - 2018-05-10 18:41:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 18:41:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 18:41:45 --> Helper loaded: form_helper
INFO - 2018-05-10 18:41:45 --> Form Validation Class Initialized
INFO - 2018-05-10 18:41:45 --> Controller Class Initialized
INFO - 2018-05-10 18:41:45 --> Model Class Initialized
INFO - 2018-05-10 18:41:45 --> Helper loaded: inflector_helper
INFO - 2018-05-10 18:41:45 --> Model Class Initialized
INFO - 2018-05-10 18:41:45 --> Model Class Initialized
INFO - 2018-05-10 18:41:45 --> Model Class Initialized
INFO - 2018-05-10 18:41:45 --> Final output sent to browser
DEBUG - 2018-05-10 18:41:45 --> Total execution time: 0.1634
INFO - 2018-05-10 13:11:46 --> Config Class Initialized
INFO - 2018-05-10 13:11:46 --> Hooks Class Initialized
DEBUG - 2018-05-10 13:11:46 --> UTF-8 Support Enabled
INFO - 2018-05-10 13:11:46 --> Utf8 Class Initialized
INFO - 2018-05-10 13:11:46 --> URI Class Initialized
INFO - 2018-05-10 13:11:46 --> Router Class Initialized
INFO - 2018-05-10 13:11:46 --> Output Class Initialized
INFO - 2018-05-10 13:11:46 --> Security Class Initialized
DEBUG - 2018-05-10 13:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 13:11:46 --> Input Class Initialized
INFO - 2018-05-10 13:11:46 --> Language Class Initialized
INFO - 2018-05-10 13:11:46 --> Language Class Initialized
INFO - 2018-05-10 13:11:46 --> Config Class Initialized
INFO - 2018-05-10 13:11:46 --> Loader Class Initialized
INFO - 2018-05-10 18:41:46 --> Helper loaded: url_helper
INFO - 2018-05-10 18:41:46 --> Helper loaded: notification_helper
INFO - 2018-05-10 18:41:46 --> Helper loaded: settings_helper
INFO - 2018-05-10 18:41:46 --> Helper loaded: permission_helper
INFO - 2018-05-10 18:41:46 --> Helper loaded: users_helper
INFO - 2018-05-10 18:41:46 --> Database Driver Class Initialized
DEBUG - 2018-05-10 18:41:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 18:41:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 18:41:46 --> Helper loaded: form_helper
INFO - 2018-05-10 18:41:46 --> Form Validation Class Initialized
INFO - 2018-05-10 18:41:46 --> Controller Class Initialized
INFO - 2018-05-10 18:41:46 --> Model Class Initialized
INFO - 2018-05-10 18:41:46 --> Helper loaded: inflector_helper
INFO - 2018-05-10 18:41:46 --> Model Class Initialized
INFO - 2018-05-10 18:41:46 --> Model Class Initialized
INFO - 2018-05-10 18:41:46 --> Model Class Initialized
INFO - 2018-05-10 18:41:46 --> Final output sent to browser
DEBUG - 2018-05-10 18:41:46 --> Total execution time: 0.0990
INFO - 2018-05-10 13:22:32 --> Config Class Initialized
INFO - 2018-05-10 13:22:32 --> Hooks Class Initialized
DEBUG - 2018-05-10 13:22:32 --> UTF-8 Support Enabled
INFO - 2018-05-10 13:22:32 --> Utf8 Class Initialized
INFO - 2018-05-10 13:22:32 --> URI Class Initialized
INFO - 2018-05-10 13:22:32 --> Router Class Initialized
INFO - 2018-05-10 13:22:32 --> Output Class Initialized
INFO - 2018-05-10 13:22:32 --> Security Class Initialized
DEBUG - 2018-05-10 13:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 13:22:32 --> Input Class Initialized
INFO - 2018-05-10 13:22:32 --> Language Class Initialized
INFO - 2018-05-10 13:22:32 --> Language Class Initialized
INFO - 2018-05-10 13:22:32 --> Config Class Initialized
INFO - 2018-05-10 13:22:32 --> Loader Class Initialized
INFO - 2018-05-10 18:52:32 --> Helper loaded: url_helper
INFO - 2018-05-10 18:52:32 --> Helper loaded: notification_helper
INFO - 2018-05-10 18:52:32 --> Helper loaded: settings_helper
INFO - 2018-05-10 18:52:32 --> Helper loaded: permission_helper
INFO - 2018-05-10 18:52:32 --> Helper loaded: users_helper
INFO - 2018-05-10 18:52:32 --> Database Driver Class Initialized
DEBUG - 2018-05-10 18:52:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 18:52:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 18:52:32 --> Helper loaded: form_helper
INFO - 2018-05-10 18:52:32 --> Form Validation Class Initialized
INFO - 2018-05-10 18:52:32 --> Controller Class Initialized
INFO - 2018-05-10 18:52:32 --> Model Class Initialized
INFO - 2018-05-10 18:52:32 --> Helper loaded: inflector_helper
INFO - 2018-05-10 18:52:32 --> Model Class Initialized
INFO - 2018-05-10 18:52:32 --> Model Class Initialized
INFO - 2018-05-10 18:52:32 --> Model Class Initialized
DEBUG - 2018-05-10 18:52:32 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-05-10 18:52:32 --> File loaded: /home/pr01004/public_html/application/views/admin/notifications.php
DEBUG - 2018-05-10 18:52:32 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-05-10 18:52:32 --> Final output sent to browser
DEBUG - 2018-05-10 18:52:32 --> Total execution time: 0.1265
INFO - 2018-05-10 13:22:56 --> Config Class Initialized
INFO - 2018-05-10 13:22:56 --> Hooks Class Initialized
DEBUG - 2018-05-10 13:22:56 --> UTF-8 Support Enabled
INFO - 2018-05-10 13:22:56 --> Utf8 Class Initialized
INFO - 2018-05-10 13:22:56 --> URI Class Initialized
INFO - 2018-05-10 13:22:56 --> Router Class Initialized
INFO - 2018-05-10 13:22:56 --> Output Class Initialized
INFO - 2018-05-10 13:22:56 --> Security Class Initialized
DEBUG - 2018-05-10 13:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 13:22:56 --> Input Class Initialized
INFO - 2018-05-10 13:22:56 --> Language Class Initialized
INFO - 2018-05-10 13:22:56 --> Language Class Initialized
INFO - 2018-05-10 13:22:56 --> Config Class Initialized
INFO - 2018-05-10 13:22:56 --> Loader Class Initialized
INFO - 2018-05-10 18:52:56 --> Helper loaded: url_helper
INFO - 2018-05-10 18:52:56 --> Helper loaded: notification_helper
INFO - 2018-05-10 18:52:56 --> Helper loaded: settings_helper
INFO - 2018-05-10 18:52:56 --> Helper loaded: permission_helper
INFO - 2018-05-10 18:52:56 --> Helper loaded: users_helper
INFO - 2018-05-10 18:52:56 --> Database Driver Class Initialized
DEBUG - 2018-05-10 18:52:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 18:52:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 18:52:56 --> Helper loaded: form_helper
INFO - 2018-05-10 18:52:56 --> Form Validation Class Initialized
INFO - 2018-05-10 18:52:56 --> Controller Class Initialized
INFO - 2018-05-10 18:52:56 --> Model Class Initialized
INFO - 2018-05-10 18:52:56 --> Helper loaded: inflector_helper
INFO - 2018-05-10 18:52:56 --> Model Class Initialized
INFO - 2018-05-10 18:52:56 --> Model Class Initialized
INFO - 2018-05-10 18:52:56 --> Model Class Initialized
ERROR - 2018-05-10 18:53:02 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-05-10 18:53:02 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-05-10 18:53:02 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-05-10 18:53:02 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-05-10 18:53:02 --> Severity: Warning --> pack(): Type H: illegal hex digit k /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-05-10 18:53:02 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-05-10 18:53:02 --> Severity: Warning --> pack(): Type H: illegal hex digit j /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-05-10 18:53:02 --> Severity: Warning --> pack(): Type H: illegal hex digit l /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-05-10 18:53:02 --> Severity: Warning --> pack(): Type H: illegal hex digit k /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-05-10 18:53:02 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-05-10 18:53:02 --> Severity: Warning --> pack(): Type H: illegal hex digit l /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-05-10 18:53:02 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-05-10 18:53:02 --> Severity: Warning --> pack(): Type H: illegal hex digit k /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-05-10 18:53:02 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-05-10 18:53:02 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-05-10 18:53:02 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-05-10 18:53:02 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-05-10 18:53:02 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-05-10 18:53:02 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-05-10 18:53:02 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-05-10 18:53:02 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-05-10 18:53:02 --> Severity: Warning --> pack(): Type H: illegal hex digit k /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-05-10 18:53:02 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-05-10 18:53:02 --> Severity: Warning --> pack(): Type H: illegal hex digit j /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-05-10 18:53:02 --> Severity: Warning --> pack(): Type H: illegal hex digit l /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-05-10 18:53:02 --> Severity: Warning --> pack(): Type H: illegal hex digit k /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-05-10 18:53:02 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-05-10 18:53:02 --> Severity: Warning --> pack(): Type H: illegal hex digit l /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-05-10 18:53:02 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-05-10 18:53:02 --> Severity: Warning --> pack(): Type H: illegal hex digit k /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-05-10 18:53:02 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-05-10 18:53:02 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-05-10 18:53:02 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-05-10 18:53:02 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-05-10 18:53:02 --> Severity: Warning --> pack(): Type H: illegal hex digit s /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-05-10 18:53:02 --> Severity: Warning --> pack(): Type H: illegal hex digit s /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-05-10 18:53:02 --> Severity: Warning --> pack(): Type H: illegal hex digit s /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-05-10 18:53:02 --> Severity: Warning --> pack(): Type H: illegal hex digit s /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-05-10 18:53:02 --> Severity: Warning --> pack(): Type H: illegal hex digit s /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-05-10 18:53:02 --> Severity: Warning --> pack(): Type H: illegal hex digit s /home/pr01004/public_html/application/controllers/Notification.php 156
INFO - 2018-05-10 13:23:03 --> Config Class Initialized
INFO - 2018-05-10 13:23:03 --> Hooks Class Initialized
DEBUG - 2018-05-10 13:23:03 --> UTF-8 Support Enabled
INFO - 2018-05-10 13:23:03 --> Utf8 Class Initialized
INFO - 2018-05-10 13:23:03 --> URI Class Initialized
INFO - 2018-05-10 13:23:03 --> Router Class Initialized
INFO - 2018-05-10 13:23:03 --> Output Class Initialized
INFO - 2018-05-10 13:23:03 --> Security Class Initialized
DEBUG - 2018-05-10 13:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 13:23:03 --> Input Class Initialized
INFO - 2018-05-10 13:23:03 --> Language Class Initialized
INFO - 2018-05-10 13:23:03 --> Language Class Initialized
INFO - 2018-05-10 13:23:03 --> Config Class Initialized
INFO - 2018-05-10 13:23:03 --> Loader Class Initialized
INFO - 2018-05-10 18:53:03 --> Helper loaded: url_helper
INFO - 2018-05-10 18:53:03 --> Helper loaded: notification_helper
INFO - 2018-05-10 18:53:03 --> Helper loaded: settings_helper
INFO - 2018-05-10 18:53:03 --> Helper loaded: permission_helper
INFO - 2018-05-10 18:53:03 --> Helper loaded: users_helper
INFO - 2018-05-10 18:53:03 --> Database Driver Class Initialized
DEBUG - 2018-05-10 18:53:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 18:53:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 18:53:03 --> Helper loaded: form_helper
INFO - 2018-05-10 18:53:03 --> Form Validation Class Initialized
INFO - 2018-05-10 18:53:03 --> Controller Class Initialized
INFO - 2018-05-10 18:53:03 --> Model Class Initialized
INFO - 2018-05-10 18:53:03 --> Helper loaded: inflector_helper
INFO - 2018-05-10 18:53:03 --> Model Class Initialized
INFO - 2018-05-10 18:53:03 --> Model Class Initialized
INFO - 2018-05-10 18:53:03 --> Model Class Initialized
DEBUG - 2018-05-10 18:53:03 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-05-10 18:53:03 --> File loaded: /home/pr01004/public_html/application/views/admin/notifications.php
DEBUG - 2018-05-10 18:53:03 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-05-10 18:53:03 --> Final output sent to browser
DEBUG - 2018-05-10 18:53:03 --> Total execution time: 0.1095
INFO - 2018-05-10 13:26:19 --> Config Class Initialized
INFO - 2018-05-10 13:26:19 --> Hooks Class Initialized
DEBUG - 2018-05-10 13:26:19 --> UTF-8 Support Enabled
INFO - 2018-05-10 13:26:19 --> Utf8 Class Initialized
INFO - 2018-05-10 13:26:19 --> URI Class Initialized
INFO - 2018-05-10 13:26:19 --> Router Class Initialized
INFO - 2018-05-10 13:26:19 --> Output Class Initialized
INFO - 2018-05-10 13:26:19 --> Security Class Initialized
DEBUG - 2018-05-10 13:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 13:26:19 --> Input Class Initialized
INFO - 2018-05-10 13:26:19 --> Language Class Initialized
INFO - 2018-05-10 13:26:19 --> Language Class Initialized
INFO - 2018-05-10 13:26:19 --> Config Class Initialized
INFO - 2018-05-10 13:26:19 --> Loader Class Initialized
INFO - 2018-05-10 18:56:19 --> Helper loaded: url_helper
INFO - 2018-05-10 18:56:19 --> Helper loaded: notification_helper
INFO - 2018-05-10 18:56:19 --> Helper loaded: settings_helper
INFO - 2018-05-10 18:56:19 --> Helper loaded: permission_helper
INFO - 2018-05-10 18:56:19 --> Helper loaded: users_helper
INFO - 2018-05-10 18:56:19 --> Database Driver Class Initialized
DEBUG - 2018-05-10 18:56:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 18:56:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 18:56:19 --> Helper loaded: form_helper
INFO - 2018-05-10 18:56:19 --> Form Validation Class Initialized
INFO - 2018-05-10 18:56:19 --> Controller Class Initialized
INFO - 2018-05-10 18:56:19 --> Model Class Initialized
INFO - 2018-05-10 18:56:19 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 18:56:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 18:56:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 18:56:19 --> Model Class Initialized
INFO - 2018-05-10 18:56:19 --> Model Class Initialized
INFO - 2018-05-10 18:56:19 --> Model Class Initialized
INFO - 2018-05-10 18:56:19 --> Model Class Initialized
INFO - 2018-05-10 18:56:19 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 18:56:19 --> Model Class Initialized
INFO - 2018-05-10 18:56:19 --> Final output sent to browser
DEBUG - 2018-05-10 18:56:19 --> Total execution time: 0.1054
INFO - 2018-05-10 13:26:40 --> Config Class Initialized
INFO - 2018-05-10 13:26:40 --> Hooks Class Initialized
DEBUG - 2018-05-10 13:26:40 --> UTF-8 Support Enabled
INFO - 2018-05-10 13:26:40 --> Utf8 Class Initialized
INFO - 2018-05-10 13:26:40 --> URI Class Initialized
INFO - 2018-05-10 13:26:40 --> Router Class Initialized
INFO - 2018-05-10 13:26:40 --> Output Class Initialized
INFO - 2018-05-10 13:26:40 --> Security Class Initialized
INFO - 2018-05-10 13:26:40 --> Config Class Initialized
INFO - 2018-05-10 13:26:40 --> Hooks Class Initialized
DEBUG - 2018-05-10 13:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 13:26:40 --> Input Class Initialized
INFO - 2018-05-10 13:26:40 --> Language Class Initialized
DEBUG - 2018-05-10 13:26:40 --> UTF-8 Support Enabled
INFO - 2018-05-10 13:26:40 --> Utf8 Class Initialized
INFO - 2018-05-10 13:26:40 --> URI Class Initialized
INFO - 2018-05-10 13:26:40 --> Router Class Initialized
INFO - 2018-05-10 13:26:40 --> Config Class Initialized
INFO - 2018-05-10 13:26:40 --> Hooks Class Initialized
INFO - 2018-05-10 13:26:40 --> Config Class Initialized
INFO - 2018-05-10 13:26:40 --> Hooks Class Initialized
INFO - 2018-05-10 13:26:40 --> Config Class Initialized
INFO - 2018-05-10 13:26:40 --> Hooks Class Initialized
INFO - 2018-05-10 13:26:40 --> Output Class Initialized
DEBUG - 2018-05-10 13:26:40 --> UTF-8 Support Enabled
INFO - 2018-05-10 13:26:40 --> Utf8 Class Initialized
DEBUG - 2018-05-10 13:26:40 --> UTF-8 Support Enabled
INFO - 2018-05-10 13:26:40 --> Utf8 Class Initialized
INFO - 2018-05-10 13:26:40 --> Security Class Initialized
INFO - 2018-05-10 13:26:40 --> URI Class Initialized
INFO - 2018-05-10 13:26:40 --> URI Class Initialized
DEBUG - 2018-05-10 13:26:40 --> UTF-8 Support Enabled
INFO - 2018-05-10 13:26:40 --> Utf8 Class Initialized
DEBUG - 2018-05-10 13:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 13:26:40 --> Input Class Initialized
INFO - 2018-05-10 13:26:40 --> Language Class Initialized
INFO - 2018-05-10 13:26:40 --> Language Class Initialized
INFO - 2018-05-10 13:26:40 --> Config Class Initialized
INFO - 2018-05-10 13:26:40 --> Loader Class Initialized
INFO - 2018-05-10 13:26:40 --> URI Class Initialized
INFO - 2018-05-10 18:56:40 --> Helper loaded: url_helper
INFO - 2018-05-10 13:26:40 --> Router Class Initialized
INFO - 2018-05-10 18:56:40 --> Helper loaded: notification_helper
INFO - 2018-05-10 18:56:40 --> Helper loaded: settings_helper
INFO - 2018-05-10 13:26:40 --> Router Class Initialized
INFO - 2018-05-10 18:56:40 --> Helper loaded: permission_helper
INFO - 2018-05-10 18:56:40 --> Helper loaded: users_helper
INFO - 2018-05-10 13:26:40 --> Output Class Initialized
INFO - 2018-05-10 13:26:40 --> Output Class Initialized
INFO - 2018-05-10 13:26:40 --> Router Class Initialized
INFO - 2018-05-10 13:26:40 --> Security Class Initialized
INFO - 2018-05-10 13:26:40 --> Security Class Initialized
INFO - 2018-05-10 18:56:40 --> Database Driver Class Initialized
INFO - 2018-05-10 13:26:40 --> Output Class Initialized
DEBUG - 2018-05-10 13:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 13:26:40 --> Input Class Initialized
DEBUG - 2018-05-10 13:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 13:26:40 --> Input Class Initialized
INFO - 2018-05-10 13:26:40 --> Language Class Initialized
INFO - 2018-05-10 13:26:40 --> Language Class Initialized
DEBUG - 2018-05-10 18:56:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 18:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 13:26:40 --> Language Class Initialized
INFO - 2018-05-10 13:26:40 --> Config Class Initialized
INFO - 2018-05-10 13:26:40 --> Loader Class Initialized
INFO - 2018-05-10 13:26:40 --> Security Class Initialized
INFO - 2018-05-10 18:56:40 --> Helper loaded: form_helper
INFO - 2018-05-10 18:56:40 --> Form Validation Class Initialized
INFO - 2018-05-10 18:56:40 --> Controller Class Initialized
DEBUG - 2018-05-10 13:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 13:26:40 --> Input Class Initialized
INFO - 2018-05-10 18:56:40 --> Helper loaded: url_helper
INFO - 2018-05-10 13:26:40 --> Language Class Initialized
INFO - 2018-05-10 18:56:40 --> Helper loaded: notification_helper
INFO - 2018-05-10 18:56:40 --> Model Class Initialized
INFO - 2018-05-10 18:56:40 --> Helper loaded: inflector_helper
INFO - 2018-05-10 18:56:40 --> Helper loaded: settings_helper
INFO - 2018-05-10 18:56:40 --> Helper loaded: permission_helper
INFO - 2018-05-10 18:56:40 --> Helper loaded: users_helper
DEBUG - 2018-05-10 18:56:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 18:56:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 18:56:40 --> Model Class Initialized
INFO - 2018-05-10 18:56:40 --> Model Class Initialized
INFO - 2018-05-10 18:56:40 --> Model Class Initialized
INFO - 2018-05-10 18:56:40 --> Model Class Initialized
INFO - 2018-05-10 18:56:40 --> Model Class Initialized
INFO - 2018-05-10 18:56:40 --> Model Class Initialized
INFO - 2018-05-10 18:56:40 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 18:56:40 --> Model Class Initialized
INFO - 2018-05-10 18:56:40 --> Final output sent to browser
DEBUG - 2018-05-10 18:56:40 --> Total execution time: 0.1330
INFO - 2018-05-10 13:26:40 --> Language Class Initialized
INFO - 2018-05-10 13:26:40 --> Config Class Initialized
INFO - 2018-05-10 13:26:40 --> Loader Class Initialized
INFO - 2018-05-10 13:26:40 --> Language Class Initialized
INFO - 2018-05-10 13:26:40 --> Language Class Initialized
INFO - 2018-05-10 13:26:40 --> Config Class Initialized
INFO - 2018-05-10 13:26:40 --> Config Class Initialized
INFO - 2018-05-10 13:26:40 --> Loader Class Initialized
INFO - 2018-05-10 13:26:40 --> Loader Class Initialized
INFO - 2018-05-10 18:56:40 --> Helper loaded: url_helper
INFO - 2018-05-10 18:56:40 --> Database Driver Class Initialized
INFO - 2018-05-10 18:56:40 --> Helper loaded: url_helper
INFO - 2018-05-10 18:56:40 --> Helper loaded: url_helper
INFO - 2018-05-10 18:56:40 --> Helper loaded: notification_helper
INFO - 2018-05-10 18:56:40 --> Helper loaded: notification_helper
INFO - 2018-05-10 18:56:40 --> Helper loaded: settings_helper
INFO - 2018-05-10 18:56:40 --> Helper loaded: settings_helper
INFO - 2018-05-10 18:56:40 --> Helper loaded: notification_helper
INFO - 2018-05-10 18:56:40 --> Helper loaded: permission_helper
INFO - 2018-05-10 18:56:40 --> Helper loaded: settings_helper
INFO - 2018-05-10 18:56:40 --> Helper loaded: users_helper
DEBUG - 2018-05-10 18:56:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 18:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 18:56:40 --> Helper loaded: permission_helper
INFO - 2018-05-10 18:56:40 --> Helper loaded: permission_helper
INFO - 2018-05-10 18:56:40 --> Helper loaded: users_helper
INFO - 2018-05-10 18:56:40 --> Helper loaded: users_helper
INFO - 2018-05-10 18:56:40 --> Helper loaded: form_helper
INFO - 2018-05-10 18:56:40 --> Form Validation Class Initialized
INFO - 2018-05-10 18:56:40 --> Controller Class Initialized
INFO - 2018-05-10 18:56:40 --> Model Class Initialized
INFO - 2018-05-10 18:56:40 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 18:56:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 18:56:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 18:56:40 --> Model Class Initialized
INFO - 2018-05-10 18:56:40 --> Model Class Initialized
INFO - 2018-05-10 18:56:40 --> Model Class Initialized
INFO - 2018-05-10 18:56:40 --> Model Class Initialized
INFO - 2018-05-10 18:56:40 --> Model Class Initialized
INFO - 2018-05-10 18:56:40 --> Model Class Initialized
INFO - 2018-05-10 18:56:40 --> Model Class Initialized
INFO - 2018-05-10 18:56:40 --> Model Class Initialized
INFO - 2018-05-10 18:56:40 --> Model Class Initialized
INFO - 2018-05-10 18:56:40 --> Model Class Initialized
INFO - 2018-05-10 18:56:40 --> Database Driver Class Initialized
INFO - 2018-05-10 18:56:40 --> Model Class Initialized
INFO - 2018-05-10 18:56:40 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 18:56:40 --> Model Class Initialized
INFO - 2018-05-10 18:56:40 --> Database Driver Class Initialized
INFO - 2018-05-10 18:56:40 --> Database Driver Class Initialized
DEBUG - 2018-05-10 18:56:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 18:56:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-05-10 18:56:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 18:56:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-05-10 18:56:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 18:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 18:56:40 --> Helper loaded: form_helper
INFO - 2018-05-10 18:56:40 --> Form Validation Class Initialized
INFO - 2018-05-10 18:56:40 --> Helper loaded: form_helper
INFO - 2018-05-10 18:56:40 --> Controller Class Initialized
INFO - 2018-05-10 18:56:40 --> Form Validation Class Initialized
INFO - 2018-05-10 18:56:40 --> Controller Class Initialized
INFO - 2018-05-10 18:56:40 --> Helper loaded: form_helper
INFO - 2018-05-10 18:56:40 --> Form Validation Class Initialized
INFO - 2018-05-10 18:56:40 --> Controller Class Initialized
INFO - 2018-05-10 18:56:40 --> Model Class Initialized
INFO - 2018-05-10 18:56:40 --> Helper loaded: inflector_helper
INFO - 2018-05-10 18:56:40 --> Model Class Initialized
INFO - 2018-05-10 18:56:40 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 18:56:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 18:56:40 --> Model Class Initialized
INFO - 2018-05-10 18:56:40 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 18:56:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 18:56:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 18:56:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 18:56:40 --> Model Class Initialized
INFO - 2018-05-10 18:56:40 --> Model Class Initialized
DEBUG - 2018-05-10 18:56:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 18:56:40 --> Model Class Initialized
INFO - 2018-05-10 18:56:40 --> Model Class Initialized
INFO - 2018-05-10 18:56:40 --> Model Class Initialized
INFO - 2018-05-10 18:56:40 --> Model Class Initialized
INFO - 2018-05-10 18:56:40 --> Model Class Initialized
INFO - 2018-05-10 18:56:40 --> Model Class Initialized
INFO - 2018-05-10 18:56:40 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 18:56:40 --> Model Class Initialized
INFO - 2018-05-10 18:56:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 18:56:40 --> Model Class Initialized
INFO - 2018-05-10 18:56:40 --> Model Class Initialized
INFO - 2018-05-10 18:56:40 --> Model Class Initialized
INFO - 2018-05-10 18:56:40 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 18:56:40 --> Model Class Initialized
INFO - 2018-05-10 18:56:40 --> Model Class Initialized
INFO - 2018-05-10 18:56:40 --> Model Class Initialized
INFO - 2018-05-10 18:56:40 --> Final output sent to browser
DEBUG - 2018-05-10 18:56:40 --> Total execution time: 0.2189
INFO - 2018-05-10 18:56:40 --> Model Class Initialized
INFO - 2018-05-10 18:56:40 --> Final output sent to browser
DEBUG - 2018-05-10 18:56:40 --> Total execution time: 0.2223
INFO - 2018-05-10 18:56:40 --> Model Class Initialized
INFO - 2018-05-10 18:56:40 --> Model Class Initialized
INFO - 2018-05-10 18:56:40 --> Model Class Initialized
INFO - 2018-05-10 18:56:40 --> Model Class Initialized
INFO - 2018-05-10 18:56:40 --> Model Class Initialized
INFO - 2018-05-10 18:56:40 --> Model Class Initialized
INFO - 2018-05-10 18:56:40 --> Model Class Initialized
INFO - 2018-05-10 18:56:40 --> Model Class Initialized
INFO - 2018-05-10 18:56:40 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 18:56:40 --> Model Class Initialized
INFO - 2018-05-10 18:56:40 --> Final output sent to browser
DEBUG - 2018-05-10 18:56:40 --> Total execution time: 0.2666
INFO - 2018-05-10 18:56:40 --> Final output sent to browser
DEBUG - 2018-05-10 18:56:40 --> Total execution time: 0.2604
INFO - 2018-05-10 13:26:43 --> Config Class Initialized
INFO - 2018-05-10 13:26:43 --> Hooks Class Initialized
DEBUG - 2018-05-10 13:26:43 --> UTF-8 Support Enabled
INFO - 2018-05-10 13:26:43 --> Utf8 Class Initialized
INFO - 2018-05-10 13:26:43 --> URI Class Initialized
INFO - 2018-05-10 13:26:43 --> Router Class Initialized
INFO - 2018-05-10 13:26:43 --> Output Class Initialized
INFO - 2018-05-10 13:26:43 --> Security Class Initialized
INFO - 2018-05-10 13:26:43 --> Config Class Initialized
INFO - 2018-05-10 13:26:43 --> Hooks Class Initialized
DEBUG - 2018-05-10 13:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 13:26:43 --> Input Class Initialized
INFO - 2018-05-10 13:26:43 --> Language Class Initialized
DEBUG - 2018-05-10 13:26:43 --> UTF-8 Support Enabled
INFO - 2018-05-10 13:26:43 --> Utf8 Class Initialized
INFO - 2018-05-10 13:26:43 --> URI Class Initialized
INFO - 2018-05-10 13:26:43 --> Router Class Initialized
INFO - 2018-05-10 13:26:43 --> Language Class Initialized
INFO - 2018-05-10 13:26:43 --> Config Class Initialized
INFO - 2018-05-10 13:26:43 --> Loader Class Initialized
INFO - 2018-05-10 13:26:43 --> Output Class Initialized
INFO - 2018-05-10 18:56:43 --> Helper loaded: url_helper
INFO - 2018-05-10 18:56:43 --> Helper loaded: notification_helper
INFO - 2018-05-10 18:56:43 --> Helper loaded: settings_helper
INFO - 2018-05-10 18:56:43 --> Helper loaded: permission_helper
INFO - 2018-05-10 13:26:43 --> Security Class Initialized
INFO - 2018-05-10 18:56:43 --> Helper loaded: users_helper
DEBUG - 2018-05-10 13:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 13:26:43 --> Input Class Initialized
INFO - 2018-05-10 13:26:43 --> Language Class Initialized
INFO - 2018-05-10 18:56:43 --> Database Driver Class Initialized
DEBUG - 2018-05-10 18:56:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 18:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 13:26:43 --> Language Class Initialized
INFO - 2018-05-10 13:26:43 --> Config Class Initialized
INFO - 2018-05-10 13:26:43 --> Loader Class Initialized
INFO - 2018-05-10 18:56:43 --> Helper loaded: form_helper
INFO - 2018-05-10 18:56:43 --> Helper loaded: url_helper
INFO - 2018-05-10 18:56:43 --> Form Validation Class Initialized
INFO - 2018-05-10 18:56:43 --> Controller Class Initialized
INFO - 2018-05-10 18:56:43 --> Helper loaded: notification_helper
INFO - 2018-05-10 18:56:43 --> Helper loaded: settings_helper
INFO - 2018-05-10 18:56:43 --> Helper loaded: permission_helper
INFO - 2018-05-10 18:56:43 --> Helper loaded: users_helper
INFO - 2018-05-10 18:56:43 --> Model Class Initialized
INFO - 2018-05-10 18:56:43 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 18:56:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 18:56:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 18:56:43 --> Model Class Initialized
INFO - 2018-05-10 18:56:43 --> Model Class Initialized
INFO - 2018-05-10 18:56:43 --> Model Class Initialized
INFO - 2018-05-10 18:56:43 --> Model Class Initialized
INFO - 2018-05-10 18:56:43 --> Final output sent to browser
DEBUG - 2018-05-10 18:56:43 --> Total execution time: 0.0996
INFO - 2018-05-10 18:56:43 --> Database Driver Class Initialized
DEBUG - 2018-05-10 18:56:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 18:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 18:56:43 --> Helper loaded: form_helper
INFO - 2018-05-10 18:56:43 --> Form Validation Class Initialized
INFO - 2018-05-10 18:56:43 --> Controller Class Initialized
INFO - 2018-05-10 18:56:43 --> Model Class Initialized
INFO - 2018-05-10 18:56:43 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 18:56:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 18:56:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 18:56:43 --> Model Class Initialized
INFO - 2018-05-10 18:56:43 --> Model Class Initialized
INFO - 2018-05-10 18:56:43 --> Model Class Initialized
INFO - 2018-05-10 18:56:43 --> Model Class Initialized
INFO - 2018-05-10 18:56:43 --> Final output sent to browser
DEBUG - 2018-05-10 18:56:43 --> Total execution time: 0.1389
INFO - 2018-05-10 13:26:45 --> Config Class Initialized
INFO - 2018-05-10 13:26:45 --> Hooks Class Initialized
DEBUG - 2018-05-10 13:26:45 --> UTF-8 Support Enabled
INFO - 2018-05-10 13:26:45 --> Utf8 Class Initialized
INFO - 2018-05-10 13:26:45 --> URI Class Initialized
INFO - 2018-05-10 13:26:45 --> Router Class Initialized
INFO - 2018-05-10 13:26:45 --> Output Class Initialized
INFO - 2018-05-10 13:26:45 --> Security Class Initialized
DEBUG - 2018-05-10 13:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 13:26:45 --> Input Class Initialized
INFO - 2018-05-10 13:26:45 --> Language Class Initialized
INFO - 2018-05-10 13:26:45 --> Config Class Initialized
INFO - 2018-05-10 13:26:45 --> Hooks Class Initialized
DEBUG - 2018-05-10 13:26:45 --> UTF-8 Support Enabled
INFO - 2018-05-10 13:26:45 --> Utf8 Class Initialized
INFO - 2018-05-10 13:26:45 --> URI Class Initialized
INFO - 2018-05-10 13:26:45 --> Language Class Initialized
INFO - 2018-05-10 13:26:45 --> Config Class Initialized
INFO - 2018-05-10 13:26:45 --> Loader Class Initialized
INFO - 2018-05-10 18:56:45 --> Helper loaded: url_helper
INFO - 2018-05-10 13:26:45 --> Router Class Initialized
INFO - 2018-05-10 18:56:45 --> Helper loaded: notification_helper
INFO - 2018-05-10 18:56:45 --> Helper loaded: settings_helper
INFO - 2018-05-10 18:56:45 --> Helper loaded: permission_helper
INFO - 2018-05-10 18:56:45 --> Helper loaded: users_helper
INFO - 2018-05-10 13:26:45 --> Output Class Initialized
INFO - 2018-05-10 13:26:45 --> Security Class Initialized
INFO - 2018-05-10 13:26:45 --> Config Class Initialized
INFO - 2018-05-10 13:26:45 --> Hooks Class Initialized
DEBUG - 2018-05-10 13:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 13:26:45 --> Input Class Initialized
INFO - 2018-05-10 13:26:45 --> Language Class Initialized
DEBUG - 2018-05-10 13:26:45 --> UTF-8 Support Enabled
INFO - 2018-05-10 13:26:45 --> Utf8 Class Initialized
INFO - 2018-05-10 13:26:45 --> URI Class Initialized
INFO - 2018-05-10 18:56:45 --> Database Driver Class Initialized
INFO - 2018-05-10 13:26:45 --> Router Class Initialized
INFO - 2018-05-10 13:26:45 --> Output Class Initialized
INFO - 2018-05-10 13:26:45 --> Security Class Initialized
DEBUG - 2018-05-10 18:56:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 18:56:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-05-10 13:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 13:26:45 --> Input Class Initialized
INFO - 2018-05-10 13:26:45 --> Language Class Initialized
INFO - 2018-05-10 13:26:45 --> Language Class Initialized
INFO - 2018-05-10 13:26:45 --> Config Class Initialized
INFO - 2018-05-10 13:26:45 --> Loader Class Initialized
INFO - 2018-05-10 18:56:45 --> Helper loaded: url_helper
INFO - 2018-05-10 18:56:45 --> Helper loaded: form_helper
INFO - 2018-05-10 18:56:45 --> Form Validation Class Initialized
INFO - 2018-05-10 18:56:45 --> Controller Class Initialized
INFO - 2018-05-10 18:56:45 --> Helper loaded: notification_helper
INFO - 2018-05-10 18:56:45 --> Helper loaded: settings_helper
INFO - 2018-05-10 18:56:45 --> Helper loaded: permission_helper
INFO - 2018-05-10 18:56:45 --> Helper loaded: users_helper
INFO - 2018-05-10 13:26:45 --> Language Class Initialized
INFO - 2018-05-10 13:26:45 --> Config Class Initialized
INFO - 2018-05-10 18:56:45 --> Model Class Initialized
INFO - 2018-05-10 13:26:45 --> Loader Class Initialized
INFO - 2018-05-10 18:56:45 --> Helper loaded: inflector_helper
INFO - 2018-05-10 18:56:45 --> Helper loaded: url_helper
INFO - 2018-05-10 18:56:45 --> Helper loaded: notification_helper
DEBUG - 2018-05-10 18:56:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 18:56:45 --> Helper loaded: settings_helper
INFO - 2018-05-10 18:56:45 --> Helper loaded: permission_helper
INFO - 2018-05-10 18:56:45 --> Helper loaded: users_helper
INFO - 2018-05-10 18:56:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 18:56:45 --> Model Class Initialized
INFO - 2018-05-10 18:56:45 --> Model Class Initialized
INFO - 2018-05-10 18:56:45 --> Model Class Initialized
INFO - 2018-05-10 18:56:45 --> Database Driver Class Initialized
INFO - 2018-05-10 18:56:45 --> Model Class Initialized
INFO - 2018-05-10 18:56:45 --> Model Class Initialized
INFO - 2018-05-10 18:56:45 --> Model Class Initialized
INFO - 2018-05-10 18:56:45 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 18:56:45 --> Final output sent to browser
DEBUG - 2018-05-10 18:56:45 --> Total execution time: 0.1065
DEBUG - 2018-05-10 18:56:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 18:56:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 18:56:45 --> Database Driver Class Initialized
INFO - 2018-05-10 18:56:45 --> Helper loaded: form_helper
INFO - 2018-05-10 18:56:45 --> Form Validation Class Initialized
INFO - 2018-05-10 18:56:45 --> Controller Class Initialized
DEBUG - 2018-05-10 18:56:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 18:56:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 18:56:45 --> Model Class Initialized
INFO - 2018-05-10 18:56:45 --> Helper loaded: form_helper
INFO - 2018-05-10 18:56:45 --> Form Validation Class Initialized
INFO - 2018-05-10 18:56:45 --> Controller Class Initialized
INFO - 2018-05-10 18:56:45 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 18:56:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 18:56:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 18:56:45 --> Model Class Initialized
INFO - 2018-05-10 18:56:45 --> Model Class Initialized
INFO - 2018-05-10 18:56:45 --> Model Class Initialized
INFO - 2018-05-10 18:56:45 --> Model Class Initialized
INFO - 2018-05-10 18:56:45 --> Model Class Initialized
INFO - 2018-05-10 18:56:45 --> Model Class Initialized
INFO - 2018-05-10 18:56:45 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 18:56:45 --> Model Class Initialized
INFO - 2018-05-10 18:56:45 --> Helper loaded: inflector_helper
INFO - 2018-05-10 18:56:45 --> Final output sent to browser
DEBUG - 2018-05-10 18:56:45 --> Total execution time: 0.1083
DEBUG - 2018-05-10 18:56:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 18:56:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 18:56:45 --> Model Class Initialized
INFO - 2018-05-10 18:56:45 --> Model Class Initialized
INFO - 2018-05-10 18:56:45 --> Model Class Initialized
INFO - 2018-05-10 18:56:45 --> Model Class Initialized
INFO - 2018-05-10 18:56:45 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 18:56:45 --> Final output sent to browser
DEBUG - 2018-05-10 18:56:45 --> Total execution time: 0.1039
INFO - 2018-05-10 13:34:44 --> Config Class Initialized
INFO - 2018-05-10 13:34:44 --> Hooks Class Initialized
DEBUG - 2018-05-10 13:34:44 --> UTF-8 Support Enabled
INFO - 2018-05-10 13:34:44 --> Utf8 Class Initialized
INFO - 2018-05-10 13:34:44 --> URI Class Initialized
INFO - 2018-05-10 13:34:44 --> Router Class Initialized
INFO - 2018-05-10 13:34:44 --> Output Class Initialized
INFO - 2018-05-10 13:34:44 --> Security Class Initialized
DEBUG - 2018-05-10 13:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 13:34:44 --> Input Class Initialized
INFO - 2018-05-10 13:34:44 --> Language Class Initialized
INFO - 2018-05-10 13:34:44 --> Language Class Initialized
INFO - 2018-05-10 13:34:44 --> Config Class Initialized
INFO - 2018-05-10 13:34:44 --> Loader Class Initialized
INFO - 2018-05-10 19:04:44 --> Helper loaded: url_helper
INFO - 2018-05-10 19:04:44 --> Helper loaded: notification_helper
INFO - 2018-05-10 19:04:44 --> Helper loaded: settings_helper
INFO - 2018-05-10 19:04:44 --> Helper loaded: permission_helper
INFO - 2018-05-10 19:04:44 --> Helper loaded: users_helper
INFO - 2018-05-10 19:04:44 --> Database Driver Class Initialized
DEBUG - 2018-05-10 19:04:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 19:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 19:04:44 --> Helper loaded: form_helper
INFO - 2018-05-10 19:04:44 --> Form Validation Class Initialized
INFO - 2018-05-10 19:04:44 --> Controller Class Initialized
INFO - 2018-05-10 19:04:44 --> Model Class Initialized
INFO - 2018-05-10 19:04:44 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 19:04:44 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 19:04:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 19:04:44 --> Model Class Initialized
INFO - 2018-05-10 19:04:44 --> Model Class Initialized
INFO - 2018-05-10 19:04:44 --> Model Class Initialized
INFO - 2018-05-10 19:04:44 --> Model Class Initialized
INFO - 2018-05-10 19:04:44 --> Model Class Initialized
INFO - 2018-05-10 19:04:44 --> Model Class Initialized
INFO - 2018-05-10 19:04:44 --> Model Class Initialized
INFO - 2018-05-10 19:04:44 --> Model Class Initialized
INFO - 2018-05-10 19:04:44 --> Model Class Initialized
INFO - 2018-05-10 19:04:44 --> Model Class Initialized
INFO - 2018-05-10 19:04:44 --> Model Class Initialized
INFO - 2018-05-10 19:04:44 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 19:04:44 --> Model Class Initialized
INFO - 2018-05-10 19:04:44 --> Final output sent to browser
DEBUG - 2018-05-10 19:04:44 --> Total execution time: 0.1037
INFO - 2018-05-10 13:34:44 --> Config Class Initialized
INFO - 2018-05-10 13:34:44 --> Hooks Class Initialized
DEBUG - 2018-05-10 13:34:44 --> UTF-8 Support Enabled
INFO - 2018-05-10 13:34:44 --> Utf8 Class Initialized
INFO - 2018-05-10 13:34:44 --> URI Class Initialized
INFO - 2018-05-10 13:34:44 --> Router Class Initialized
INFO - 2018-05-10 13:34:44 --> Output Class Initialized
INFO - 2018-05-10 13:34:44 --> Security Class Initialized
DEBUG - 2018-05-10 13:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 13:34:44 --> Input Class Initialized
INFO - 2018-05-10 13:34:44 --> Language Class Initialized
INFO - 2018-05-10 13:34:44 --> Language Class Initialized
INFO - 2018-05-10 13:34:44 --> Config Class Initialized
INFO - 2018-05-10 13:34:44 --> Loader Class Initialized
INFO - 2018-05-10 19:04:44 --> Helper loaded: url_helper
INFO - 2018-05-10 19:04:44 --> Helper loaded: notification_helper
INFO - 2018-05-10 19:04:44 --> Helper loaded: settings_helper
INFO - 2018-05-10 19:04:44 --> Helper loaded: permission_helper
INFO - 2018-05-10 19:04:44 --> Helper loaded: users_helper
INFO - 2018-05-10 19:04:44 --> Database Driver Class Initialized
DEBUG - 2018-05-10 19:04:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 19:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 19:04:44 --> Helper loaded: form_helper
INFO - 2018-05-10 19:04:44 --> Form Validation Class Initialized
INFO - 2018-05-10 19:04:44 --> Controller Class Initialized
INFO - 2018-05-10 19:04:44 --> Model Class Initialized
INFO - 2018-05-10 19:04:44 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 19:04:44 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 19:04:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 19:04:44 --> Model Class Initialized
INFO - 2018-05-10 19:04:44 --> Model Class Initialized
INFO - 2018-05-10 19:04:44 --> Model Class Initialized
INFO - 2018-05-10 19:04:44 --> Model Class Initialized
INFO - 2018-05-10 19:04:44 --> Model Class Initialized
INFO - 2018-05-10 19:04:44 --> Model Class Initialized
INFO - 2018-05-10 19:04:44 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 19:04:44 --> Model Class Initialized
INFO - 2018-05-10 19:04:44 --> Final output sent to browser
DEBUG - 2018-05-10 19:04:44 --> Total execution time: 0.1141
INFO - 2018-05-10 13:34:53 --> Config Class Initialized
INFO - 2018-05-10 13:34:53 --> Hooks Class Initialized
DEBUG - 2018-05-10 13:34:53 --> UTF-8 Support Enabled
INFO - 2018-05-10 13:34:53 --> Utf8 Class Initialized
INFO - 2018-05-10 13:34:53 --> URI Class Initialized
INFO - 2018-05-10 13:34:53 --> Router Class Initialized
INFO - 2018-05-10 13:34:53 --> Output Class Initialized
INFO - 2018-05-10 13:34:53 --> Security Class Initialized
DEBUG - 2018-05-10 13:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 13:34:53 --> Input Class Initialized
INFO - 2018-05-10 13:34:53 --> Language Class Initialized
INFO - 2018-05-10 13:34:53 --> Config Class Initialized
INFO - 2018-05-10 13:34:53 --> Hooks Class Initialized
DEBUG - 2018-05-10 13:34:53 --> UTF-8 Support Enabled
INFO - 2018-05-10 13:34:53 --> Utf8 Class Initialized
INFO - 2018-05-10 13:34:53 --> URI Class Initialized
INFO - 2018-05-10 13:34:53 --> Language Class Initialized
INFO - 2018-05-10 13:34:53 --> Config Class Initialized
INFO - 2018-05-10 13:34:53 --> Loader Class Initialized
INFO - 2018-05-10 13:34:53 --> Router Class Initialized
INFO - 2018-05-10 19:04:53 --> Helper loaded: url_helper
INFO - 2018-05-10 19:04:53 --> Helper loaded: notification_helper
INFO - 2018-05-10 19:04:53 --> Helper loaded: settings_helper
INFO - 2018-05-10 19:04:53 --> Helper loaded: permission_helper
INFO - 2018-05-10 19:04:53 --> Helper loaded: users_helper
INFO - 2018-05-10 13:34:53 --> Output Class Initialized
INFO - 2018-05-10 13:34:53 --> Security Class Initialized
DEBUG - 2018-05-10 13:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 13:34:53 --> Input Class Initialized
INFO - 2018-05-10 13:34:53 --> Language Class Initialized
INFO - 2018-05-10 19:04:53 --> Database Driver Class Initialized
INFO - 2018-05-10 13:34:53 --> Language Class Initialized
INFO - 2018-05-10 13:34:53 --> Config Class Initialized
INFO - 2018-05-10 13:34:53 --> Loader Class Initialized
INFO - 2018-05-10 19:04:53 --> Helper loaded: url_helper
INFO - 2018-05-10 19:04:53 --> Helper loaded: notification_helper
INFO - 2018-05-10 19:04:53 --> Helper loaded: settings_helper
DEBUG - 2018-05-10 19:04:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 19:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 19:04:53 --> Helper loaded: permission_helper
INFO - 2018-05-10 19:04:53 --> Helper loaded: users_helper
INFO - 2018-05-10 19:04:53 --> Helper loaded: form_helper
INFO - 2018-05-10 19:04:53 --> Form Validation Class Initialized
INFO - 2018-05-10 19:04:53 --> Controller Class Initialized
INFO - 2018-05-10 19:04:53 --> Database Driver Class Initialized
DEBUG - 2018-05-10 19:04:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 19:04:53 --> Model Class Initialized
INFO - 2018-05-10 19:04:53 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 19:04:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 19:04:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 19:04:53 --> Model Class Initialized
INFO - 2018-05-10 19:04:53 --> Model Class Initialized
INFO - 2018-05-10 19:04:53 --> Model Class Initialized
INFO - 2018-05-10 19:04:53 --> Model Class Initialized
INFO - 2018-05-10 19:04:53 --> Model Class Initialized
INFO - 2018-05-10 19:04:53 --> Model Class Initialized
INFO - 2018-05-10 19:04:53 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 19:04:53 --> Final output sent to browser
DEBUG - 2018-05-10 19:04:53 --> Total execution time: 0.1304
INFO - 2018-05-10 19:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 19:04:53 --> Helper loaded: form_helper
INFO - 2018-05-10 19:04:53 --> Form Validation Class Initialized
INFO - 2018-05-10 19:04:53 --> Controller Class Initialized
INFO - 2018-05-10 19:04:53 --> Model Class Initialized
INFO - 2018-05-10 19:04:53 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 19:04:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 19:04:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 19:04:53 --> Model Class Initialized
INFO - 2018-05-10 19:04:53 --> Model Class Initialized
INFO - 2018-05-10 19:04:53 --> Model Class Initialized
INFO - 2018-05-10 19:04:53 --> Model Class Initialized
INFO - 2018-05-10 19:04:53 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 19:04:53 --> Final output sent to browser
DEBUG - 2018-05-10 19:04:53 --> Total execution time: 0.1356
INFO - 2018-05-10 13:34:55 --> Config Class Initialized
INFO - 2018-05-10 13:34:55 --> Hooks Class Initialized
DEBUG - 2018-05-10 13:34:55 --> UTF-8 Support Enabled
INFO - 2018-05-10 13:34:55 --> Utf8 Class Initialized
INFO - 2018-05-10 13:34:55 --> URI Class Initialized
INFO - 2018-05-10 13:34:55 --> Router Class Initialized
INFO - 2018-05-10 13:34:55 --> Output Class Initialized
INFO - 2018-05-10 13:34:55 --> Security Class Initialized
DEBUG - 2018-05-10 13:34:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 13:34:55 --> Input Class Initialized
INFO - 2018-05-10 13:34:55 --> Language Class Initialized
INFO - 2018-05-10 13:34:55 --> Language Class Initialized
INFO - 2018-05-10 13:34:55 --> Config Class Initialized
INFO - 2018-05-10 13:34:55 --> Loader Class Initialized
INFO - 2018-05-10 19:04:55 --> Helper loaded: url_helper
INFO - 2018-05-10 19:04:55 --> Helper loaded: notification_helper
INFO - 2018-05-10 19:04:55 --> Helper loaded: settings_helper
INFO - 2018-05-10 19:04:55 --> Helper loaded: permission_helper
INFO - 2018-05-10 19:04:55 --> Helper loaded: users_helper
INFO - 2018-05-10 19:04:55 --> Database Driver Class Initialized
DEBUG - 2018-05-10 19:04:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 19:04:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 19:04:55 --> Helper loaded: form_helper
INFO - 2018-05-10 19:04:55 --> Form Validation Class Initialized
INFO - 2018-05-10 19:04:55 --> Controller Class Initialized
INFO - 2018-05-10 19:04:55 --> Model Class Initialized
INFO - 2018-05-10 19:04:55 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 19:04:55 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 19:04:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 19:04:55 --> Model Class Initialized
INFO - 2018-05-10 19:04:55 --> Model Class Initialized
INFO - 2018-05-10 19:04:55 --> Model Class Initialized
INFO - 2018-05-10 19:04:55 --> Model Class Initialized
INFO - 2018-05-10 19:04:55 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 19:04:55 --> Model Class Initialized
INFO - 2018-05-10 19:04:55 --> Final output sent to browser
DEBUG - 2018-05-10 19:04:55 --> Total execution time: 0.1168
INFO - 2018-05-10 13:39:48 --> Config Class Initialized
INFO - 2018-05-10 13:39:48 --> Hooks Class Initialized
DEBUG - 2018-05-10 13:39:48 --> UTF-8 Support Enabled
INFO - 2018-05-10 13:39:48 --> Utf8 Class Initialized
INFO - 2018-05-10 13:39:48 --> URI Class Initialized
INFO - 2018-05-10 13:39:48 --> Config Class Initialized
INFO - 2018-05-10 13:39:48 --> Hooks Class Initialized
INFO - 2018-05-10 13:39:48 --> Router Class Initialized
INFO - 2018-05-10 13:39:48 --> Config Class Initialized
INFO - 2018-05-10 13:39:48 --> Hooks Class Initialized
INFO - 2018-05-10 13:39:48 --> Output Class Initialized
INFO - 2018-05-10 13:39:48 --> Config Class Initialized
INFO - 2018-05-10 13:39:48 --> Hooks Class Initialized
DEBUG - 2018-05-10 13:39:48 --> UTF-8 Support Enabled
INFO - 2018-05-10 13:39:48 --> Utf8 Class Initialized
DEBUG - 2018-05-10 13:39:48 --> UTF-8 Support Enabled
INFO - 2018-05-10 13:39:48 --> Utf8 Class Initialized
INFO - 2018-05-10 13:39:48 --> Security Class Initialized
INFO - 2018-05-10 13:39:48 --> URI Class Initialized
DEBUG - 2018-05-10 13:39:48 --> UTF-8 Support Enabled
INFO - 2018-05-10 13:39:48 --> Utf8 Class Initialized
INFO - 2018-05-10 13:39:48 --> URI Class Initialized
DEBUG - 2018-05-10 13:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 13:39:48 --> Input Class Initialized
INFO - 2018-05-10 13:39:48 --> URI Class Initialized
INFO - 2018-05-10 13:39:48 --> Language Class Initialized
INFO - 2018-05-10 13:39:48 --> Router Class Initialized
INFO - 2018-05-10 13:39:48 --> Router Class Initialized
INFO - 2018-05-10 13:39:48 --> Router Class Initialized
INFO - 2018-05-10 13:39:48 --> Output Class Initialized
INFO - 2018-05-10 13:39:48 --> Output Class Initialized
INFO - 2018-05-10 13:39:48 --> Security Class Initialized
INFO - 2018-05-10 13:39:48 --> Output Class Initialized
INFO - 2018-05-10 13:39:48 --> Security Class Initialized
DEBUG - 2018-05-10 13:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 13:39:48 --> Input Class Initialized
INFO - 2018-05-10 13:39:48 --> Language Class Initialized
INFO - 2018-05-10 13:39:48 --> Security Class Initialized
DEBUG - 2018-05-10 13:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 13:39:48 --> Input Class Initialized
INFO - 2018-05-10 13:39:48 --> Language Class Initialized
DEBUG - 2018-05-10 13:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 13:39:48 --> Input Class Initialized
INFO - 2018-05-10 13:39:48 --> Language Class Initialized
INFO - 2018-05-10 13:39:48 --> Language Class Initialized
INFO - 2018-05-10 13:39:48 --> Config Class Initialized
INFO - 2018-05-10 13:39:48 --> Loader Class Initialized
INFO - 2018-05-10 19:09:48 --> Helper loaded: url_helper
INFO - 2018-05-10 19:09:48 --> Helper loaded: notification_helper
INFO - 2018-05-10 19:09:48 --> Helper loaded: settings_helper
INFO - 2018-05-10 13:39:48 --> Config Class Initialized
INFO - 2018-05-10 13:39:48 --> Hooks Class Initialized
INFO - 2018-05-10 19:09:48 --> Helper loaded: permission_helper
INFO - 2018-05-10 19:09:48 --> Helper loaded: users_helper
INFO - 2018-05-10 13:39:48 --> Language Class Initialized
INFO - 2018-05-10 13:39:48 --> Config Class Initialized
INFO - 2018-05-10 13:39:48 --> Loader Class Initialized
DEBUG - 2018-05-10 13:39:48 --> UTF-8 Support Enabled
INFO - 2018-05-10 13:39:48 --> Utf8 Class Initialized
INFO - 2018-05-10 13:39:48 --> Language Class Initialized
INFO - 2018-05-10 13:39:48 --> Config Class Initialized
INFO - 2018-05-10 13:39:48 --> Loader Class Initialized
INFO - 2018-05-10 19:09:48 --> Helper loaded: url_helper
INFO - 2018-05-10 19:09:48 --> Helper loaded: url_helper
INFO - 2018-05-10 19:09:48 --> Helper loaded: notification_helper
INFO - 2018-05-10 19:09:48 --> Helper loaded: settings_helper
INFO - 2018-05-10 13:39:48 --> URI Class Initialized
INFO - 2018-05-10 19:09:48 --> Helper loaded: notification_helper
INFO - 2018-05-10 19:09:48 --> Helper loaded: permission_helper
INFO - 2018-05-10 19:09:48 --> Helper loaded: settings_helper
INFO - 2018-05-10 19:09:48 --> Helper loaded: users_helper
INFO - 2018-05-10 19:09:48 --> Helper loaded: permission_helper
INFO - 2018-05-10 19:09:48 --> Helper loaded: users_helper
INFO - 2018-05-10 19:09:48 --> Database Driver Class Initialized
INFO - 2018-05-10 13:39:48 --> Router Class Initialized
DEBUG - 2018-05-10 19:09:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 13:39:48 --> Language Class Initialized
INFO - 2018-05-10 13:39:48 --> Config Class Initialized
INFO - 2018-05-10 13:39:48 --> Loader Class Initialized
INFO - 2018-05-10 19:09:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 19:09:48 --> Database Driver Class Initialized
INFO - 2018-05-10 19:09:48 --> Helper loaded: url_helper
INFO - 2018-05-10 19:09:48 --> Database Driver Class Initialized
INFO - 2018-05-10 13:39:48 --> Output Class Initialized
INFO - 2018-05-10 19:09:48 --> Helper loaded: notification_helper
INFO - 2018-05-10 19:09:48 --> Helper loaded: settings_helper
INFO - 2018-05-10 19:09:48 --> Helper loaded: permission_helper
INFO - 2018-05-10 19:09:48 --> Helper loaded: users_helper
INFO - 2018-05-10 19:09:48 --> Helper loaded: form_helper
INFO - 2018-05-10 19:09:48 --> Form Validation Class Initialized
INFO - 2018-05-10 19:09:48 --> Controller Class Initialized
DEBUG - 2018-05-10 19:09:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 19:09:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-05-10 19:09:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 19:09:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 13:39:48 --> Security Class Initialized
INFO - 2018-05-10 19:09:48 --> Model Class Initialized
INFO - 2018-05-10 19:09:48 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 13:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 13:39:48 --> Input Class Initialized
INFO - 2018-05-10 19:09:48 --> Helper loaded: form_helper
INFO - 2018-05-10 19:09:48 --> Form Validation Class Initialized
INFO - 2018-05-10 19:09:48 --> Controller Class Initialized
INFO - 2018-05-10 19:09:48 --> Database Driver Class Initialized
DEBUG - 2018-05-10 19:09:48 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 19:09:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 19:09:48 --> Helper loaded: form_helper
INFO - 2018-05-10 19:09:48 --> Form Validation Class Initialized
INFO - 2018-05-10 19:09:48 --> Controller Class Initialized
INFO - 2018-05-10 13:39:48 --> Language Class Initialized
INFO - 2018-05-10 19:09:48 --> Model Class Initialized
INFO - 2018-05-10 19:09:48 --> Model Class Initialized
INFO - 2018-05-10 19:09:48 --> Model Class Initialized
INFO - 2018-05-10 19:09:48 --> Model Class Initialized
INFO - 2018-05-10 19:09:48 --> Model Class Initialized
INFO - 2018-05-10 19:09:48 --> Model Class Initialized
INFO - 2018-05-10 19:09:48 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-05-10 19:09:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 19:09:48 --> Model Class Initialized
INFO - 2018-05-10 19:09:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 19:09:48 --> Helper loaded: inflector_helper
INFO - 2018-05-10 19:09:48 --> Model Class Initialized
INFO - 2018-05-10 19:09:48 --> Final output sent to browser
DEBUG - 2018-05-10 19:09:48 --> Total execution time: 0.1077
DEBUG - 2018-05-10 19:09:48 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 19:09:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 19:09:48 --> Model Class Initialized
INFO - 2018-05-10 19:09:48 --> Model Class Initialized
INFO - 2018-05-10 19:09:48 --> Model Class Initialized
INFO - 2018-05-10 19:09:48 --> Model Class Initialized
INFO - 2018-05-10 19:09:48 --> Helper loaded: inflector_helper
INFO - 2018-05-10 19:09:48 --> Model Class Initialized
INFO - 2018-05-10 19:09:48 --> Model Class Initialized
INFO - 2018-05-10 19:09:48 --> Model Class Initialized
INFO - 2018-05-10 19:09:48 --> Model Class Initialized
INFO - 2018-05-10 19:09:48 --> Model Class Initialized
INFO - 2018-05-10 19:09:48 --> Model Class Initialized
INFO - 2018-05-10 19:09:48 --> Model Class Initialized
INFO - 2018-05-10 19:09:48 --> Model Class Initialized
INFO - 2018-05-10 19:09:48 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 19:09:49 --> Model Class Initialized
DEBUG - 2018-05-10 19:09:49 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 19:09:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 19:09:49 --> Model Class Initialized
INFO - 2018-05-10 19:09:49 --> Model Class Initialized
INFO - 2018-05-10 19:09:49 --> Helper loaded: form_helper
INFO - 2018-05-10 19:09:49 --> Form Validation Class Initialized
INFO - 2018-05-10 19:09:49 --> Controller Class Initialized
INFO - 2018-05-10 19:09:49 --> Model Class Initialized
INFO - 2018-05-10 19:09:49 --> Model Class Initialized
INFO - 2018-05-10 19:09:49 --> Model Class Initialized
INFO - 2018-05-10 19:09:49 --> Model Class Initialized
INFO - 2018-05-10 19:09:49 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 19:09:49 --> Final output sent to browser
DEBUG - 2018-05-10 19:09:49 --> Total execution time: 0.1175
INFO - 2018-05-10 19:09:49 --> Final output sent to browser
DEBUG - 2018-05-10 19:09:49 --> Total execution time: 0.1254
INFO - 2018-05-10 19:09:49 --> Model Class Initialized
INFO - 2018-05-10 19:09:49 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 19:09:49 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 19:09:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 19:09:49 --> Model Class Initialized
INFO - 2018-05-10 19:09:49 --> Model Class Initialized
INFO - 2018-05-10 19:09:49 --> Model Class Initialized
INFO - 2018-05-10 19:09:49 --> Model Class Initialized
INFO - 2018-05-10 19:09:49 --> Model Class Initialized
INFO - 2018-05-10 19:09:49 --> Model Class Initialized
INFO - 2018-05-10 13:39:49 --> Language Class Initialized
INFO - 2018-05-10 19:09:49 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 13:39:49 --> Config Class Initialized
INFO - 2018-05-10 13:39:49 --> Loader Class Initialized
INFO - 2018-05-10 19:09:49 --> Model Class Initialized
INFO - 2018-05-10 19:09:49 --> Final output sent to browser
DEBUG - 2018-05-10 19:09:49 --> Total execution time: 0.1439
INFO - 2018-05-10 19:09:49 --> Helper loaded: url_helper
INFO - 2018-05-10 19:09:49 --> Helper loaded: notification_helper
INFO - 2018-05-10 19:09:49 --> Helper loaded: settings_helper
INFO - 2018-05-10 19:09:49 --> Helper loaded: permission_helper
INFO - 2018-05-10 19:09:49 --> Helper loaded: users_helper
INFO - 2018-05-10 19:09:49 --> Database Driver Class Initialized
DEBUG - 2018-05-10 19:09:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 19:09:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 19:09:49 --> Helper loaded: form_helper
INFO - 2018-05-10 19:09:49 --> Form Validation Class Initialized
INFO - 2018-05-10 19:09:49 --> Controller Class Initialized
INFO - 2018-05-10 19:09:49 --> Model Class Initialized
INFO - 2018-05-10 19:09:49 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 19:09:49 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 19:09:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 19:09:49 --> Model Class Initialized
INFO - 2018-05-10 19:09:49 --> Model Class Initialized
INFO - 2018-05-10 19:09:49 --> Model Class Initialized
INFO - 2018-05-10 19:09:49 --> Model Class Initialized
INFO - 2018-05-10 19:09:49 --> Model Class Initialized
INFO - 2018-05-10 19:09:49 --> Model Class Initialized
INFO - 2018-05-10 19:09:49 --> Model Class Initialized
INFO - 2018-05-10 19:09:49 --> Model Class Initialized
INFO - 2018-05-10 19:09:49 --> Model Class Initialized
INFO - 2018-05-10 19:09:49 --> Model Class Initialized
INFO - 2018-05-10 19:09:49 --> Model Class Initialized
INFO - 2018-05-10 19:09:49 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 19:09:49 --> Model Class Initialized
INFO - 2018-05-10 19:09:49 --> Final output sent to browser
DEBUG - 2018-05-10 19:09:49 --> Total execution time: 0.1864
INFO - 2018-05-10 13:45:03 --> Config Class Initialized
INFO - 2018-05-10 13:45:03 --> Hooks Class Initialized
DEBUG - 2018-05-10 13:45:03 --> UTF-8 Support Enabled
INFO - 2018-05-10 13:45:03 --> Utf8 Class Initialized
INFO - 2018-05-10 13:45:03 --> URI Class Initialized
INFO - 2018-05-10 13:45:03 --> Router Class Initialized
INFO - 2018-05-10 13:45:03 --> Output Class Initialized
INFO - 2018-05-10 13:45:03 --> Security Class Initialized
DEBUG - 2018-05-10 13:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 13:45:03 --> Input Class Initialized
INFO - 2018-05-10 13:45:03 --> Language Class Initialized
INFO - 2018-05-10 13:45:03 --> Language Class Initialized
INFO - 2018-05-10 13:45:03 --> Config Class Initialized
INFO - 2018-05-10 13:45:03 --> Loader Class Initialized
INFO - 2018-05-10 19:15:03 --> Helper loaded: url_helper
INFO - 2018-05-10 19:15:03 --> Helper loaded: notification_helper
INFO - 2018-05-10 19:15:03 --> Helper loaded: settings_helper
INFO - 2018-05-10 19:15:03 --> Helper loaded: permission_helper
INFO - 2018-05-10 19:15:03 --> Helper loaded: users_helper
INFO - 2018-05-10 19:15:03 --> Database Driver Class Initialized
DEBUG - 2018-05-10 19:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 19:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 19:15:03 --> Helper loaded: form_helper
INFO - 2018-05-10 19:15:03 --> Form Validation Class Initialized
INFO - 2018-05-10 19:15:03 --> Controller Class Initialized
INFO - 2018-05-10 19:15:03 --> Model Class Initialized
INFO - 2018-05-10 19:15:03 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 19:15:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 19:15:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 19:15:03 --> Model Class Initialized
INFO - 2018-05-10 19:15:03 --> Model Class Initialized
INFO - 2018-05-10 19:15:03 --> Model Class Initialized
INFO - 2018-05-10 19:15:03 --> Model Class Initialized
INFO - 2018-05-10 19:15:03 --> Model Class Initialized
INFO - 2018-05-10 19:15:03 --> Model Class Initialized
INFO - 2018-05-10 19:15:03 --> Model Class Initialized
INFO - 2018-05-10 19:15:03 --> Model Class Initialized
INFO - 2018-05-10 19:15:03 --> Model Class Initialized
INFO - 2018-05-10 19:15:03 --> Model Class Initialized
INFO - 2018-05-10 19:15:03 --> Model Class Initialized
INFO - 2018-05-10 19:15:03 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 19:15:03 --> Model Class Initialized
INFO - 2018-05-10 19:15:03 --> Final output sent to browser
DEBUG - 2018-05-10 19:15:03 --> Total execution time: 0.1120
INFO - 2018-05-10 13:45:03 --> Config Class Initialized
INFO - 2018-05-10 13:45:03 --> Hooks Class Initialized
DEBUG - 2018-05-10 13:45:03 --> UTF-8 Support Enabled
INFO - 2018-05-10 13:45:03 --> Utf8 Class Initialized
INFO - 2018-05-10 13:45:03 --> URI Class Initialized
INFO - 2018-05-10 13:45:03 --> Router Class Initialized
INFO - 2018-05-10 13:45:03 --> Output Class Initialized
INFO - 2018-05-10 13:45:03 --> Security Class Initialized
DEBUG - 2018-05-10 13:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 13:45:03 --> Input Class Initialized
INFO - 2018-05-10 13:45:03 --> Language Class Initialized
INFO - 2018-05-10 13:45:03 --> Language Class Initialized
INFO - 2018-05-10 13:45:03 --> Config Class Initialized
INFO - 2018-05-10 13:45:03 --> Loader Class Initialized
INFO - 2018-05-10 19:15:03 --> Helper loaded: url_helper
INFO - 2018-05-10 19:15:03 --> Helper loaded: notification_helper
INFO - 2018-05-10 19:15:03 --> Helper loaded: settings_helper
INFO - 2018-05-10 19:15:03 --> Helper loaded: permission_helper
INFO - 2018-05-10 19:15:03 --> Helper loaded: users_helper
INFO - 2018-05-10 19:15:03 --> Database Driver Class Initialized
DEBUG - 2018-05-10 19:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 19:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 19:15:03 --> Helper loaded: form_helper
INFO - 2018-05-10 19:15:03 --> Form Validation Class Initialized
INFO - 2018-05-10 19:15:03 --> Controller Class Initialized
INFO - 2018-05-10 19:15:03 --> Model Class Initialized
INFO - 2018-05-10 19:15:03 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 19:15:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 19:15:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 19:15:03 --> Model Class Initialized
INFO - 2018-05-10 19:15:03 --> Model Class Initialized
INFO - 2018-05-10 19:15:03 --> Model Class Initialized
INFO - 2018-05-10 19:15:03 --> Model Class Initialized
INFO - 2018-05-10 19:15:03 --> Model Class Initialized
INFO - 2018-05-10 19:15:03 --> Model Class Initialized
INFO - 2018-05-10 19:15:03 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 19:15:03 --> Model Class Initialized
INFO - 2018-05-10 19:15:03 --> Final output sent to browser
DEBUG - 2018-05-10 19:15:03 --> Total execution time: 0.1120
INFO - 2018-05-10 13:45:05 --> Config Class Initialized
INFO - 2018-05-10 13:45:05 --> Hooks Class Initialized
DEBUG - 2018-05-10 13:45:05 --> UTF-8 Support Enabled
INFO - 2018-05-10 13:45:05 --> Utf8 Class Initialized
INFO - 2018-05-10 13:45:05 --> URI Class Initialized
INFO - 2018-05-10 13:45:05 --> Config Class Initialized
INFO - 2018-05-10 13:45:05 --> Hooks Class Initialized
INFO - 2018-05-10 13:45:05 --> Router Class Initialized
DEBUG - 2018-05-10 13:45:05 --> UTF-8 Support Enabled
INFO - 2018-05-10 13:45:05 --> Utf8 Class Initialized
INFO - 2018-05-10 13:45:05 --> Output Class Initialized
INFO - 2018-05-10 13:45:05 --> URI Class Initialized
INFO - 2018-05-10 13:45:05 --> Security Class Initialized
DEBUG - 2018-05-10 13:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 13:45:05 --> Input Class Initialized
INFO - 2018-05-10 13:45:05 --> Language Class Initialized
INFO - 2018-05-10 13:45:05 --> Router Class Initialized
INFO - 2018-05-10 13:45:05 --> Output Class Initialized
INFO - 2018-05-10 13:45:05 --> Security Class Initialized
DEBUG - 2018-05-10 13:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 13:45:05 --> Input Class Initialized
INFO - 2018-05-10 13:45:05 --> Language Class Initialized
INFO - 2018-05-10 13:45:05 --> Language Class Initialized
INFO - 2018-05-10 13:45:05 --> Config Class Initialized
INFO - 2018-05-10 13:45:05 --> Loader Class Initialized
INFO - 2018-05-10 19:15:05 --> Helper loaded: url_helper
INFO - 2018-05-10 19:15:05 --> Helper loaded: notification_helper
INFO - 2018-05-10 19:15:05 --> Helper loaded: settings_helper
INFO - 2018-05-10 19:15:05 --> Helper loaded: permission_helper
INFO - 2018-05-10 19:15:05 --> Helper loaded: users_helper
INFO - 2018-05-10 13:45:05 --> Language Class Initialized
INFO - 2018-05-10 13:45:05 --> Config Class Initialized
INFO - 2018-05-10 13:45:05 --> Loader Class Initialized
INFO - 2018-05-10 19:15:05 --> Helper loaded: url_helper
INFO - 2018-05-10 19:15:05 --> Helper loaded: notification_helper
INFO - 2018-05-10 19:15:05 --> Helper loaded: settings_helper
INFO - 2018-05-10 19:15:05 --> Helper loaded: permission_helper
INFO - 2018-05-10 19:15:05 --> Helper loaded: users_helper
INFO - 2018-05-10 19:15:05 --> Database Driver Class Initialized
DEBUG - 2018-05-10 19:15:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 19:15:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 19:15:05 --> Helper loaded: form_helper
INFO - 2018-05-10 19:15:05 --> Form Validation Class Initialized
INFO - 2018-05-10 19:15:05 --> Controller Class Initialized
INFO - 2018-05-10 19:15:05 --> Database Driver Class Initialized
DEBUG - 2018-05-10 19:15:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 19:15:05 --> Model Class Initialized
INFO - 2018-05-10 19:15:05 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 19:15:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 19:15:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 19:15:05 --> Model Class Initialized
INFO - 2018-05-10 19:15:05 --> Model Class Initialized
INFO - 2018-05-10 19:15:05 --> Model Class Initialized
INFO - 2018-05-10 19:15:05 --> Model Class Initialized
INFO - 2018-05-10 19:15:05 --> Model Class Initialized
INFO - 2018-05-10 19:15:05 --> Model Class Initialized
INFO - 2018-05-10 19:15:05 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 19:15:05 --> Final output sent to browser
DEBUG - 2018-05-10 19:15:05 --> Total execution time: 0.1049
INFO - 2018-05-10 19:15:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 19:15:05 --> Helper loaded: form_helper
INFO - 2018-05-10 19:15:05 --> Form Validation Class Initialized
INFO - 2018-05-10 19:15:05 --> Controller Class Initialized
INFO - 2018-05-10 19:15:05 --> Model Class Initialized
INFO - 2018-05-10 19:15:05 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 19:15:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 19:15:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 19:15:05 --> Model Class Initialized
INFO - 2018-05-10 19:15:05 --> Model Class Initialized
INFO - 2018-05-10 19:15:05 --> Model Class Initialized
INFO - 2018-05-10 19:15:05 --> Model Class Initialized
INFO - 2018-05-10 19:15:05 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 19:15:05 --> Final output sent to browser
DEBUG - 2018-05-10 19:15:05 --> Total execution time: 0.1331
INFO - 2018-05-10 13:45:08 --> Config Class Initialized
INFO - 2018-05-10 13:45:08 --> Hooks Class Initialized
DEBUG - 2018-05-10 13:45:08 --> UTF-8 Support Enabled
INFO - 2018-05-10 13:45:08 --> Utf8 Class Initialized
INFO - 2018-05-10 13:45:08 --> URI Class Initialized
INFO - 2018-05-10 13:45:08 --> Router Class Initialized
INFO - 2018-05-10 13:45:08 --> Output Class Initialized
INFO - 2018-05-10 13:45:08 --> Security Class Initialized
DEBUG - 2018-05-10 13:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 13:45:08 --> Input Class Initialized
INFO - 2018-05-10 13:45:08 --> Language Class Initialized
INFO - 2018-05-10 13:45:08 --> Language Class Initialized
INFO - 2018-05-10 13:45:08 --> Config Class Initialized
INFO - 2018-05-10 13:45:08 --> Loader Class Initialized
INFO - 2018-05-10 19:15:08 --> Helper loaded: url_helper
INFO - 2018-05-10 19:15:08 --> Helper loaded: notification_helper
INFO - 2018-05-10 19:15:08 --> Helper loaded: settings_helper
INFO - 2018-05-10 19:15:08 --> Helper loaded: permission_helper
INFO - 2018-05-10 19:15:08 --> Helper loaded: users_helper
INFO - 2018-05-10 19:15:08 --> Database Driver Class Initialized
DEBUG - 2018-05-10 19:15:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 19:15:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 19:15:08 --> Helper loaded: form_helper
INFO - 2018-05-10 19:15:08 --> Form Validation Class Initialized
INFO - 2018-05-10 19:15:08 --> Controller Class Initialized
INFO - 2018-05-10 19:15:08 --> Model Class Initialized
INFO - 2018-05-10 19:15:08 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 19:15:08 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 19:15:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 19:15:08 --> Model Class Initialized
INFO - 2018-05-10 19:15:08 --> Model Class Initialized
INFO - 2018-05-10 19:15:08 --> Model Class Initialized
INFO - 2018-05-10 19:15:08 --> Model Class Initialized
INFO - 2018-05-10 19:15:08 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 19:15:08 --> Model Class Initialized
INFO - 2018-05-10 19:15:08 --> Final output sent to browser
DEBUG - 2018-05-10 19:15:08 --> Total execution time: 0.1109
INFO - 2018-05-10 13:45:12 --> Config Class Initialized
INFO - 2018-05-10 13:45:12 --> Hooks Class Initialized
DEBUG - 2018-05-10 13:45:12 --> UTF-8 Support Enabled
INFO - 2018-05-10 13:45:12 --> Utf8 Class Initialized
INFO - 2018-05-10 13:45:12 --> URI Class Initialized
INFO - 2018-05-10 13:45:12 --> Router Class Initialized
INFO - 2018-05-10 13:45:12 --> Output Class Initialized
INFO - 2018-05-10 13:45:12 --> Security Class Initialized
DEBUG - 2018-05-10 13:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 13:45:12 --> Input Class Initialized
INFO - 2018-05-10 13:45:12 --> Language Class Initialized
INFO - 2018-05-10 13:45:13 --> Language Class Initialized
INFO - 2018-05-10 13:45:13 --> Config Class Initialized
INFO - 2018-05-10 13:45:13 --> Loader Class Initialized
INFO - 2018-05-10 19:15:13 --> Helper loaded: url_helper
INFO - 2018-05-10 19:15:13 --> Helper loaded: notification_helper
INFO - 2018-05-10 19:15:13 --> Helper loaded: settings_helper
INFO - 2018-05-10 19:15:13 --> Helper loaded: permission_helper
INFO - 2018-05-10 19:15:13 --> Helper loaded: users_helper
INFO - 2018-05-10 19:15:13 --> Database Driver Class Initialized
DEBUG - 2018-05-10 19:15:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 19:15:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 19:15:13 --> Helper loaded: form_helper
INFO - 2018-05-10 19:15:13 --> Form Validation Class Initialized
INFO - 2018-05-10 19:15:13 --> Controller Class Initialized
INFO - 2018-05-10 19:15:13 --> Model Class Initialized
INFO - 2018-05-10 19:15:13 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 19:15:13 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 19:15:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 19:15:13 --> Model Class Initialized
INFO - 2018-05-10 19:15:13 --> Model Class Initialized
INFO - 2018-05-10 19:15:13 --> Model Class Initialized
INFO - 2018-05-10 19:15:13 --> Model Class Initialized
INFO - 2018-05-10 19:15:13 --> Model Class Initialized
INFO - 2018-05-10 19:15:13 --> Model Class Initialized
INFO - 2018-05-10 19:15:13 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 19:15:13 --> Final output sent to browser
DEBUG - 2018-05-10 19:15:13 --> Total execution time: 0.2388
INFO - 2018-05-10 13:45:16 --> Config Class Initialized
INFO - 2018-05-10 13:45:16 --> Hooks Class Initialized
DEBUG - 2018-05-10 13:45:16 --> UTF-8 Support Enabled
INFO - 2018-05-10 13:45:16 --> Utf8 Class Initialized
INFO - 2018-05-10 13:45:16 --> URI Class Initialized
INFO - 2018-05-10 13:45:16 --> Router Class Initialized
INFO - 2018-05-10 13:45:16 --> Output Class Initialized
INFO - 2018-05-10 13:45:16 --> Security Class Initialized
DEBUG - 2018-05-10 13:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 13:45:16 --> Input Class Initialized
INFO - 2018-05-10 13:45:16 --> Language Class Initialized
INFO - 2018-05-10 13:45:16 --> Language Class Initialized
INFO - 2018-05-10 13:45:16 --> Config Class Initialized
INFO - 2018-05-10 13:45:16 --> Loader Class Initialized
INFO - 2018-05-10 19:15:16 --> Helper loaded: url_helper
INFO - 2018-05-10 19:15:16 --> Helper loaded: notification_helper
INFO - 2018-05-10 19:15:16 --> Helper loaded: settings_helper
INFO - 2018-05-10 19:15:16 --> Helper loaded: permission_helper
INFO - 2018-05-10 19:15:16 --> Helper loaded: users_helper
INFO - 2018-05-10 19:15:16 --> Database Driver Class Initialized
DEBUG - 2018-05-10 19:15:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 19:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 19:15:16 --> Helper loaded: form_helper
INFO - 2018-05-10 19:15:16 --> Form Validation Class Initialized
INFO - 2018-05-10 19:15:16 --> Controller Class Initialized
INFO - 2018-05-10 19:15:16 --> Model Class Initialized
INFO - 2018-05-10 19:15:16 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 19:15:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 19:15:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 19:15:16 --> Model Class Initialized
INFO - 2018-05-10 19:15:16 --> Model Class Initialized
INFO - 2018-05-10 19:15:16 --> Model Class Initialized
INFO - 2018-05-10 19:15:16 --> Model Class Initialized
INFO - 2018-05-10 19:15:16 --> Model Class Initialized
INFO - 2018-05-10 19:15:16 --> Model Class Initialized
INFO - 2018-05-10 19:15:16 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 19:15:16 --> Final output sent to browser
DEBUG - 2018-05-10 19:15:16 --> Total execution time: 0.1208
INFO - 2018-05-10 13:45:17 --> Config Class Initialized
INFO - 2018-05-10 13:45:17 --> Hooks Class Initialized
DEBUG - 2018-05-10 13:45:17 --> UTF-8 Support Enabled
INFO - 2018-05-10 13:45:17 --> Utf8 Class Initialized
INFO - 2018-05-10 13:45:17 --> URI Class Initialized
INFO - 2018-05-10 13:45:17 --> Router Class Initialized
INFO - 2018-05-10 13:45:17 --> Output Class Initialized
INFO - 2018-05-10 13:45:17 --> Security Class Initialized
DEBUG - 2018-05-10 13:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 13:45:17 --> Input Class Initialized
INFO - 2018-05-10 13:45:17 --> Language Class Initialized
INFO - 2018-05-10 13:45:17 --> Language Class Initialized
INFO - 2018-05-10 13:45:17 --> Config Class Initialized
INFO - 2018-05-10 13:45:17 --> Loader Class Initialized
INFO - 2018-05-10 19:15:17 --> Helper loaded: url_helper
INFO - 2018-05-10 19:15:17 --> Helper loaded: notification_helper
INFO - 2018-05-10 19:15:17 --> Helper loaded: settings_helper
INFO - 2018-05-10 19:15:17 --> Helper loaded: permission_helper
INFO - 2018-05-10 19:15:17 --> Helper loaded: users_helper
INFO - 2018-05-10 19:15:17 --> Database Driver Class Initialized
DEBUG - 2018-05-10 19:15:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 19:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 19:15:17 --> Helper loaded: form_helper
INFO - 2018-05-10 19:15:17 --> Form Validation Class Initialized
INFO - 2018-05-10 19:15:17 --> Controller Class Initialized
INFO - 2018-05-10 19:15:17 --> Model Class Initialized
INFO - 2018-05-10 19:15:17 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 19:15:17 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 19:15:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 19:15:17 --> Model Class Initialized
INFO - 2018-05-10 19:15:17 --> Model Class Initialized
INFO - 2018-05-10 19:15:17 --> Model Class Initialized
INFO - 2018-05-10 19:15:17 --> Model Class Initialized
INFO - 2018-05-10 19:15:17 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 19:15:17 --> Model Class Initialized
INFO - 2018-05-10 19:15:17 --> Final output sent to browser
DEBUG - 2018-05-10 19:15:17 --> Total execution time: 0.1014
INFO - 2018-05-10 13:49:34 --> Config Class Initialized
INFO - 2018-05-10 13:49:34 --> Hooks Class Initialized
DEBUG - 2018-05-10 13:49:34 --> UTF-8 Support Enabled
INFO - 2018-05-10 13:49:34 --> Utf8 Class Initialized
INFO - 2018-05-10 13:49:34 --> URI Class Initialized
INFO - 2018-05-10 13:49:34 --> Router Class Initialized
INFO - 2018-05-10 13:49:34 --> Output Class Initialized
INFO - 2018-05-10 13:49:34 --> Security Class Initialized
DEBUG - 2018-05-10 13:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 13:49:34 --> Input Class Initialized
INFO - 2018-05-10 13:49:34 --> Language Class Initialized
INFO - 2018-05-10 13:49:34 --> Language Class Initialized
INFO - 2018-05-10 13:49:34 --> Config Class Initialized
INFO - 2018-05-10 13:49:34 --> Loader Class Initialized
INFO - 2018-05-10 19:19:34 --> Helper loaded: url_helper
INFO - 2018-05-10 19:19:34 --> Helper loaded: notification_helper
INFO - 2018-05-10 19:19:34 --> Helper loaded: settings_helper
INFO - 2018-05-10 19:19:34 --> Helper loaded: permission_helper
INFO - 2018-05-10 19:19:34 --> Helper loaded: users_helper
INFO - 2018-05-10 19:19:34 --> Database Driver Class Initialized
DEBUG - 2018-05-10 19:19:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 19:19:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 13:49:34 --> Config Class Initialized
INFO - 2018-05-10 13:49:34 --> Hooks Class Initialized
INFO - 2018-05-10 19:19:34 --> Helper loaded: form_helper
INFO - 2018-05-10 19:19:34 --> Form Validation Class Initialized
INFO - 2018-05-10 19:19:34 --> Controller Class Initialized
DEBUG - 2018-05-10 13:49:34 --> UTF-8 Support Enabled
INFO - 2018-05-10 13:49:34 --> Utf8 Class Initialized
INFO - 2018-05-10 13:49:34 --> URI Class Initialized
INFO - 2018-05-10 13:49:34 --> Router Class Initialized
INFO - 2018-05-10 19:19:34 --> Model Class Initialized
INFO - 2018-05-10 19:19:34 --> Helper loaded: inflector_helper
INFO - 2018-05-10 13:49:34 --> Output Class Initialized
DEBUG - 2018-05-10 19:19:34 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 19:19:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 19:19:34 --> Model Class Initialized
INFO - 2018-05-10 19:19:34 --> Model Class Initialized
INFO - 2018-05-10 13:49:34 --> Security Class Initialized
INFO - 2018-05-10 19:19:34 --> Model Class Initialized
INFO - 2018-05-10 19:19:34 --> Model Class Initialized
INFO - 2018-05-10 19:19:34 --> Model Class Initialized
INFO - 2018-05-10 19:19:34 --> Model Class Initialized
INFO - 2018-05-10 19:19:34 --> Model Class Initialized
DEBUG - 2018-05-10 13:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 13:49:34 --> Input Class Initialized
INFO - 2018-05-10 19:19:34 --> Model Class Initialized
INFO - 2018-05-10 19:19:34 --> Model Class Initialized
INFO - 2018-05-10 19:19:34 --> Model Class Initialized
INFO - 2018-05-10 13:49:34 --> Language Class Initialized
INFO - 2018-05-10 19:19:34 --> Model Class Initialized
INFO - 2018-05-10 19:19:34 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 19:19:34 --> Model Class Initialized
INFO - 2018-05-10 19:19:34 --> Final output sent to browser
DEBUG - 2018-05-10 19:19:34 --> Total execution time: 0.1121
INFO - 2018-05-10 13:49:34 --> Language Class Initialized
INFO - 2018-05-10 13:49:34 --> Config Class Initialized
INFO - 2018-05-10 13:49:34 --> Loader Class Initialized
INFO - 2018-05-10 19:19:34 --> Helper loaded: url_helper
INFO - 2018-05-10 19:19:34 --> Helper loaded: notification_helper
INFO - 2018-05-10 19:19:34 --> Helper loaded: settings_helper
INFO - 2018-05-10 19:19:34 --> Helper loaded: permission_helper
INFO - 2018-05-10 19:19:34 --> Helper loaded: users_helper
INFO - 2018-05-10 19:19:34 --> Database Driver Class Initialized
DEBUG - 2018-05-10 19:19:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 19:19:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 19:19:34 --> Helper loaded: form_helper
INFO - 2018-05-10 19:19:34 --> Form Validation Class Initialized
INFO - 2018-05-10 19:19:34 --> Controller Class Initialized
INFO - 2018-05-10 19:19:34 --> Model Class Initialized
INFO - 2018-05-10 19:19:34 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 19:19:34 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 19:19:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 19:19:34 --> Model Class Initialized
INFO - 2018-05-10 19:19:34 --> Model Class Initialized
INFO - 2018-05-10 19:19:34 --> Model Class Initialized
INFO - 2018-05-10 19:19:34 --> Model Class Initialized
INFO - 2018-05-10 19:19:34 --> Model Class Initialized
INFO - 2018-05-10 19:19:34 --> Model Class Initialized
INFO - 2018-05-10 19:19:34 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 19:19:34 --> Model Class Initialized
INFO - 2018-05-10 19:19:34 --> Final output sent to browser
DEBUG - 2018-05-10 19:19:34 --> Total execution time: 0.1198
INFO - 2018-05-10 13:49:50 --> Config Class Initialized
INFO - 2018-05-10 13:49:50 --> Hooks Class Initialized
INFO - 2018-05-10 13:49:51 --> Config Class Initialized
INFO - 2018-05-10 13:49:51 --> Hooks Class Initialized
DEBUG - 2018-05-10 13:49:51 --> UTF-8 Support Enabled
INFO - 2018-05-10 13:49:51 --> Utf8 Class Initialized
INFO - 2018-05-10 13:49:51 --> URI Class Initialized
DEBUG - 2018-05-10 13:49:51 --> UTF-8 Support Enabled
INFO - 2018-05-10 13:49:51 --> Utf8 Class Initialized
INFO - 2018-05-10 13:49:51 --> URI Class Initialized
INFO - 2018-05-10 13:49:51 --> Router Class Initialized
INFO - 2018-05-10 13:49:51 --> Router Class Initialized
INFO - 2018-05-10 13:49:51 --> Output Class Initialized
INFO - 2018-05-10 13:49:51 --> Security Class Initialized
INFO - 2018-05-10 13:49:51 --> Output Class Initialized
DEBUG - 2018-05-10 13:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 13:49:51 --> Input Class Initialized
INFO - 2018-05-10 13:49:51 --> Security Class Initialized
INFO - 2018-05-10 13:49:51 --> Language Class Initialized
DEBUG - 2018-05-10 13:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 13:49:51 --> Input Class Initialized
INFO - 2018-05-10 13:49:51 --> Language Class Initialized
INFO - 2018-05-10 13:49:51 --> Language Class Initialized
INFO - 2018-05-10 13:49:51 --> Config Class Initialized
INFO - 2018-05-10 13:49:51 --> Loader Class Initialized
INFO - 2018-05-10 19:19:51 --> Helper loaded: url_helper
INFO - 2018-05-10 19:19:51 --> Helper loaded: notification_helper
INFO - 2018-05-10 19:19:51 --> Helper loaded: settings_helper
INFO - 2018-05-10 19:19:51 --> Helper loaded: permission_helper
INFO - 2018-05-10 19:19:51 --> Helper loaded: users_helper
INFO - 2018-05-10 13:49:51 --> Language Class Initialized
INFO - 2018-05-10 13:49:51 --> Config Class Initialized
INFO - 2018-05-10 13:49:51 --> Loader Class Initialized
INFO - 2018-05-10 19:19:51 --> Helper loaded: url_helper
INFO - 2018-05-10 19:19:51 --> Helper loaded: notification_helper
INFO - 2018-05-10 19:19:51 --> Helper loaded: settings_helper
INFO - 2018-05-10 19:19:51 --> Helper loaded: permission_helper
INFO - 2018-05-10 19:19:51 --> Helper loaded: users_helper
INFO - 2018-05-10 19:19:51 --> Database Driver Class Initialized
DEBUG - 2018-05-10 19:19:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 19:19:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 19:19:51 --> Database Driver Class Initialized
INFO - 2018-05-10 19:19:51 --> Helper loaded: form_helper
INFO - 2018-05-10 19:19:51 --> Form Validation Class Initialized
INFO - 2018-05-10 19:19:51 --> Controller Class Initialized
DEBUG - 2018-05-10 19:19:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 19:19:51 --> Model Class Initialized
INFO - 2018-05-10 19:19:51 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 19:19:51 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 19:19:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 19:19:51 --> Model Class Initialized
INFO - 2018-05-10 19:19:51 --> Model Class Initialized
INFO - 2018-05-10 19:19:51 --> Model Class Initialized
INFO - 2018-05-10 19:19:51 --> Model Class Initialized
INFO - 2018-05-10 19:19:51 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 19:19:51 --> Final output sent to browser
DEBUG - 2018-05-10 19:19:51 --> Total execution time: 0.0980
INFO - 2018-05-10 19:19:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 19:19:51 --> Helper loaded: form_helper
INFO - 2018-05-10 19:19:51 --> Form Validation Class Initialized
INFO - 2018-05-10 19:19:51 --> Controller Class Initialized
INFO - 2018-05-10 19:19:51 --> Model Class Initialized
INFO - 2018-05-10 19:19:51 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 19:19:51 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 19:19:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 19:19:51 --> Model Class Initialized
INFO - 2018-05-10 19:19:51 --> Model Class Initialized
INFO - 2018-05-10 19:19:51 --> Model Class Initialized
INFO - 2018-05-10 19:19:51 --> Model Class Initialized
INFO - 2018-05-10 19:19:51 --> Model Class Initialized
INFO - 2018-05-10 19:19:51 --> Model Class Initialized
INFO - 2018-05-10 19:19:51 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 19:19:51 --> Final output sent to browser
DEBUG - 2018-05-10 19:19:51 --> Total execution time: 0.1276
INFO - 2018-05-10 13:50:07 --> Config Class Initialized
INFO - 2018-05-10 13:50:07 --> Hooks Class Initialized
DEBUG - 2018-05-10 13:50:07 --> UTF-8 Support Enabled
INFO - 2018-05-10 13:50:07 --> Utf8 Class Initialized
INFO - 2018-05-10 13:50:07 --> URI Class Initialized
INFO - 2018-05-10 13:50:07 --> Router Class Initialized
INFO - 2018-05-10 13:50:07 --> Output Class Initialized
INFO - 2018-05-10 13:50:07 --> Security Class Initialized
DEBUG - 2018-05-10 13:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 13:50:07 --> Input Class Initialized
INFO - 2018-05-10 13:50:07 --> Language Class Initialized
INFO - 2018-05-10 13:50:07 --> Language Class Initialized
INFO - 2018-05-10 13:50:07 --> Config Class Initialized
INFO - 2018-05-10 13:50:07 --> Loader Class Initialized
INFO - 2018-05-10 19:20:07 --> Helper loaded: url_helper
INFO - 2018-05-10 19:20:07 --> Helper loaded: notification_helper
INFO - 2018-05-10 19:20:07 --> Helper loaded: settings_helper
INFO - 2018-05-10 19:20:07 --> Helper loaded: permission_helper
INFO - 2018-05-10 19:20:07 --> Helper loaded: users_helper
INFO - 2018-05-10 19:20:07 --> Database Driver Class Initialized
DEBUG - 2018-05-10 19:20:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 19:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 19:20:07 --> Helper loaded: form_helper
INFO - 2018-05-10 19:20:07 --> Form Validation Class Initialized
INFO - 2018-05-10 19:20:07 --> Controller Class Initialized
INFO - 2018-05-10 19:20:07 --> Model Class Initialized
INFO - 2018-05-10 19:20:07 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 19:20:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 19:20:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 19:20:07 --> Model Class Initialized
INFO - 2018-05-10 19:20:07 --> Model Class Initialized
INFO - 2018-05-10 19:20:07 --> Model Class Initialized
INFO - 2018-05-10 19:20:07 --> Model Class Initialized
INFO - 2018-05-10 19:20:07 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 19:20:07 --> Model Class Initialized
INFO - 2018-05-10 19:20:07 --> Final output sent to browser
DEBUG - 2018-05-10 19:20:07 --> Total execution time: 0.1005
INFO - 2018-05-10 13:51:09 --> Config Class Initialized
INFO - 2018-05-10 13:51:09 --> Hooks Class Initialized
DEBUG - 2018-05-10 13:51:09 --> UTF-8 Support Enabled
INFO - 2018-05-10 13:51:09 --> Utf8 Class Initialized
INFO - 2018-05-10 13:51:09 --> URI Class Initialized
INFO - 2018-05-10 13:51:09 --> Router Class Initialized
INFO - 2018-05-10 13:51:09 --> Output Class Initialized
INFO - 2018-05-10 13:51:09 --> Security Class Initialized
DEBUG - 2018-05-10 13:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 13:51:09 --> Input Class Initialized
INFO - 2018-05-10 13:51:09 --> Language Class Initialized
INFO - 2018-05-10 13:51:09 --> Language Class Initialized
INFO - 2018-05-10 13:51:09 --> Config Class Initialized
INFO - 2018-05-10 13:51:09 --> Loader Class Initialized
INFO - 2018-05-10 19:21:09 --> Helper loaded: url_helper
INFO - 2018-05-10 19:21:09 --> Helper loaded: notification_helper
INFO - 2018-05-10 19:21:09 --> Helper loaded: settings_helper
INFO - 2018-05-10 19:21:09 --> Helper loaded: permission_helper
INFO - 2018-05-10 19:21:09 --> Helper loaded: users_helper
INFO - 2018-05-10 19:21:09 --> Database Driver Class Initialized
DEBUG - 2018-05-10 19:21:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 19:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 19:21:09 --> Helper loaded: form_helper
INFO - 2018-05-10 19:21:09 --> Form Validation Class Initialized
INFO - 2018-05-10 19:21:09 --> Controller Class Initialized
INFO - 2018-05-10 19:21:09 --> Model Class Initialized
INFO - 2018-05-10 19:21:09 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 19:21:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 19:21:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 19:21:09 --> Model Class Initialized
INFO - 2018-05-10 19:21:09 --> Model Class Initialized
INFO - 2018-05-10 19:21:09 --> Model Class Initialized
INFO - 2018-05-10 19:21:09 --> Model Class Initialized
INFO - 2018-05-10 19:21:09 --> Model Class Initialized
INFO - 2018-05-10 19:21:09 --> Model Class Initialized
INFO - 2018-05-10 19:21:09 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 19:21:09 --> Final output sent to browser
DEBUG - 2018-05-10 19:21:09 --> Total execution time: 0.1089
INFO - 2018-05-10 13:51:10 --> Config Class Initialized
INFO - 2018-05-10 13:51:10 --> Hooks Class Initialized
DEBUG - 2018-05-10 13:51:10 --> UTF-8 Support Enabled
INFO - 2018-05-10 13:51:10 --> Utf8 Class Initialized
INFO - 2018-05-10 13:51:10 --> URI Class Initialized
INFO - 2018-05-10 13:51:10 --> Router Class Initialized
INFO - 2018-05-10 13:51:10 --> Output Class Initialized
INFO - 2018-05-10 13:51:10 --> Security Class Initialized
DEBUG - 2018-05-10 13:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 13:51:10 --> Input Class Initialized
INFO - 2018-05-10 13:51:10 --> Language Class Initialized
INFO - 2018-05-10 13:51:10 --> Language Class Initialized
INFO - 2018-05-10 13:51:10 --> Config Class Initialized
INFO - 2018-05-10 13:51:10 --> Loader Class Initialized
INFO - 2018-05-10 19:21:10 --> Helper loaded: url_helper
INFO - 2018-05-10 19:21:10 --> Helper loaded: notification_helper
INFO - 2018-05-10 19:21:10 --> Helper loaded: settings_helper
INFO - 2018-05-10 19:21:10 --> Helper loaded: permission_helper
INFO - 2018-05-10 19:21:10 --> Helper loaded: users_helper
INFO - 2018-05-10 19:21:10 --> Database Driver Class Initialized
DEBUG - 2018-05-10 19:21:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 19:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 19:21:10 --> Helper loaded: form_helper
INFO - 2018-05-10 19:21:10 --> Form Validation Class Initialized
INFO - 2018-05-10 19:21:10 --> Controller Class Initialized
INFO - 2018-05-10 19:21:10 --> Model Class Initialized
INFO - 2018-05-10 19:21:10 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 19:21:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 19:21:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 19:21:10 --> Model Class Initialized
INFO - 2018-05-10 19:21:10 --> Model Class Initialized
INFO - 2018-05-10 19:21:10 --> Model Class Initialized
INFO - 2018-05-10 19:21:10 --> Model Class Initialized
INFO - 2018-05-10 19:21:10 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 19:21:10 --> Model Class Initialized
INFO - 2018-05-10 19:21:10 --> Final output sent to browser
DEBUG - 2018-05-10 19:21:10 --> Total execution time: 0.1065
INFO - 2018-05-10 13:55:44 --> Config Class Initialized
INFO - 2018-05-10 13:55:44 --> Hooks Class Initialized
DEBUG - 2018-05-10 13:55:44 --> UTF-8 Support Enabled
INFO - 2018-05-10 13:55:44 --> Utf8 Class Initialized
INFO - 2018-05-10 13:55:44 --> URI Class Initialized
INFO - 2018-05-10 13:55:44 --> Router Class Initialized
INFO - 2018-05-10 13:55:44 --> Output Class Initialized
INFO - 2018-05-10 13:55:44 --> Security Class Initialized
DEBUG - 2018-05-10 13:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 13:55:44 --> Input Class Initialized
INFO - 2018-05-10 13:55:44 --> Language Class Initialized
INFO - 2018-05-10 13:55:44 --> Language Class Initialized
INFO - 2018-05-10 13:55:44 --> Config Class Initialized
INFO - 2018-05-10 13:55:44 --> Loader Class Initialized
INFO - 2018-05-10 19:25:44 --> Helper loaded: url_helper
INFO - 2018-05-10 19:25:44 --> Helper loaded: notification_helper
INFO - 2018-05-10 19:25:44 --> Helper loaded: settings_helper
INFO - 2018-05-10 19:25:44 --> Helper loaded: permission_helper
INFO - 2018-05-10 19:25:44 --> Helper loaded: users_helper
INFO - 2018-05-10 19:25:45 --> Database Driver Class Initialized
DEBUG - 2018-05-10 19:25:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 19:25:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 19:25:45 --> Helper loaded: form_helper
INFO - 2018-05-10 19:25:45 --> Form Validation Class Initialized
INFO - 2018-05-10 19:25:45 --> Controller Class Initialized
INFO - 2018-05-10 19:25:45 --> Model Class Initialized
INFO - 2018-05-10 19:25:45 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 19:25:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 19:25:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 19:25:45 --> Model Class Initialized
INFO - 2018-05-10 19:25:45 --> Model Class Initialized
INFO - 2018-05-10 19:25:45 --> Model Class Initialized
INFO - 2018-05-10 19:25:45 --> Model Class Initialized
INFO - 2018-05-10 19:25:45 --> Model Class Initialized
INFO - 2018-05-10 19:25:45 --> Model Class Initialized
INFO - 2018-05-10 19:25:45 --> Model Class Initialized
INFO - 2018-05-10 19:25:45 --> Model Class Initialized
INFO - 2018-05-10 19:25:45 --> Model Class Initialized
INFO - 2018-05-10 19:25:45 --> Model Class Initialized
INFO - 2018-05-10 19:25:45 --> Model Class Initialized
INFO - 2018-05-10 19:25:45 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 19:25:45 --> Model Class Initialized
INFO - 2018-05-10 19:25:45 --> Final output sent to browser
DEBUG - 2018-05-10 19:25:45 --> Total execution time: 0.1468
INFO - 2018-05-10 13:55:45 --> Config Class Initialized
INFO - 2018-05-10 13:55:45 --> Hooks Class Initialized
DEBUG - 2018-05-10 13:55:45 --> UTF-8 Support Enabled
INFO - 2018-05-10 13:55:45 --> Utf8 Class Initialized
INFO - 2018-05-10 13:55:45 --> URI Class Initialized
INFO - 2018-05-10 13:55:45 --> Router Class Initialized
INFO - 2018-05-10 13:55:45 --> Output Class Initialized
INFO - 2018-05-10 13:55:45 --> Security Class Initialized
DEBUG - 2018-05-10 13:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 13:55:45 --> Input Class Initialized
INFO - 2018-05-10 13:55:45 --> Language Class Initialized
INFO - 2018-05-10 13:55:45 --> Language Class Initialized
INFO - 2018-05-10 13:55:45 --> Config Class Initialized
INFO - 2018-05-10 13:55:45 --> Loader Class Initialized
INFO - 2018-05-10 19:25:45 --> Helper loaded: url_helper
INFO - 2018-05-10 19:25:45 --> Helper loaded: notification_helper
INFO - 2018-05-10 19:25:45 --> Helper loaded: settings_helper
INFO - 2018-05-10 19:25:45 --> Helper loaded: permission_helper
INFO - 2018-05-10 19:25:45 --> Helper loaded: users_helper
INFO - 2018-05-10 19:25:45 --> Database Driver Class Initialized
DEBUG - 2018-05-10 19:25:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 19:25:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 19:25:45 --> Helper loaded: form_helper
INFO - 2018-05-10 19:25:45 --> Form Validation Class Initialized
INFO - 2018-05-10 19:25:45 --> Controller Class Initialized
INFO - 2018-05-10 19:25:45 --> Model Class Initialized
INFO - 2018-05-10 19:25:45 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 19:25:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 19:25:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 19:25:45 --> Model Class Initialized
INFO - 2018-05-10 19:25:45 --> Model Class Initialized
INFO - 2018-05-10 19:25:45 --> Model Class Initialized
INFO - 2018-05-10 19:25:45 --> Model Class Initialized
INFO - 2018-05-10 19:25:45 --> Model Class Initialized
INFO - 2018-05-10 19:25:45 --> Model Class Initialized
INFO - 2018-05-10 19:25:45 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 19:25:45 --> Model Class Initialized
INFO - 2018-05-10 19:25:45 --> Final output sent to browser
DEBUG - 2018-05-10 19:25:45 --> Total execution time: 0.1323
INFO - 2018-05-10 13:55:48 --> Config Class Initialized
INFO - 2018-05-10 13:55:48 --> Hooks Class Initialized
INFO - 2018-05-10 13:55:48 --> Config Class Initialized
INFO - 2018-05-10 13:55:48 --> Hooks Class Initialized
DEBUG - 2018-05-10 13:55:48 --> UTF-8 Support Enabled
INFO - 2018-05-10 13:55:48 --> Utf8 Class Initialized
INFO - 2018-05-10 13:55:48 --> URI Class Initialized
DEBUG - 2018-05-10 13:55:48 --> UTF-8 Support Enabled
INFO - 2018-05-10 13:55:48 --> Utf8 Class Initialized
INFO - 2018-05-10 13:55:48 --> URI Class Initialized
INFO - 2018-05-10 13:55:48 --> Router Class Initialized
INFO - 2018-05-10 13:55:48 --> Output Class Initialized
INFO - 2018-05-10 13:55:48 --> Router Class Initialized
INFO - 2018-05-10 13:55:48 --> Security Class Initialized
DEBUG - 2018-05-10 13:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 13:55:48 --> Input Class Initialized
INFO - 2018-05-10 13:55:48 --> Output Class Initialized
INFO - 2018-05-10 13:55:48 --> Language Class Initialized
INFO - 2018-05-10 13:55:48 --> Security Class Initialized
DEBUG - 2018-05-10 13:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 13:55:48 --> Input Class Initialized
INFO - 2018-05-10 13:55:48 --> Language Class Initialized
INFO - 2018-05-10 13:55:48 --> Language Class Initialized
INFO - 2018-05-10 13:55:48 --> Language Class Initialized
INFO - 2018-05-10 13:55:48 --> Config Class Initialized
INFO - 2018-05-10 13:55:48 --> Config Class Initialized
INFO - 2018-05-10 13:55:48 --> Loader Class Initialized
INFO - 2018-05-10 13:55:48 --> Loader Class Initialized
INFO - 2018-05-10 19:25:48 --> Helper loaded: url_helper
INFO - 2018-05-10 19:25:48 --> Helper loaded: url_helper
INFO - 2018-05-10 19:25:48 --> Helper loaded: notification_helper
INFO - 2018-05-10 19:25:48 --> Helper loaded: notification_helper
INFO - 2018-05-10 19:25:48 --> Helper loaded: settings_helper
INFO - 2018-05-10 19:25:48 --> Helper loaded: settings_helper
INFO - 2018-05-10 19:25:48 --> Helper loaded: permission_helper
INFO - 2018-05-10 19:25:48 --> Helper loaded: permission_helper
INFO - 2018-05-10 19:25:48 --> Helper loaded: users_helper
INFO - 2018-05-10 19:25:48 --> Helper loaded: users_helper
INFO - 2018-05-10 19:25:48 --> Database Driver Class Initialized
INFO - 2018-05-10 19:25:48 --> Database Driver Class Initialized
DEBUG - 2018-05-10 19:25:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-05-10 19:25:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 19:25:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 19:25:48 --> Helper loaded: form_helper
INFO - 2018-05-10 19:25:48 --> Form Validation Class Initialized
INFO - 2018-05-10 19:25:48 --> Controller Class Initialized
INFO - 2018-05-10 19:25:48 --> Model Class Initialized
INFO - 2018-05-10 19:25:48 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 19:25:48 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 19:25:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 19:25:48 --> Model Class Initialized
INFO - 2018-05-10 19:25:48 --> Model Class Initialized
INFO - 2018-05-10 19:25:48 --> Model Class Initialized
INFO - 2018-05-10 19:25:48 --> Model Class Initialized
INFO - 2018-05-10 19:25:48 --> Model Class Initialized
INFO - 2018-05-10 19:25:48 --> Model Class Initialized
INFO - 2018-05-10 19:25:48 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 19:25:48 --> Final output sent to browser
DEBUG - 2018-05-10 19:25:48 --> Total execution time: 0.1056
INFO - 2018-05-10 19:25:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 19:25:48 --> Helper loaded: form_helper
INFO - 2018-05-10 19:25:48 --> Form Validation Class Initialized
INFO - 2018-05-10 19:25:48 --> Controller Class Initialized
INFO - 2018-05-10 19:25:48 --> Model Class Initialized
INFO - 2018-05-10 19:25:48 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 19:25:48 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 19:25:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 19:25:48 --> Model Class Initialized
INFO - 2018-05-10 19:25:48 --> Model Class Initialized
INFO - 2018-05-10 19:25:48 --> Model Class Initialized
INFO - 2018-05-10 19:25:48 --> Model Class Initialized
INFO - 2018-05-10 19:25:48 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 19:25:48 --> Final output sent to browser
DEBUG - 2018-05-10 19:25:48 --> Total execution time: 0.1432
INFO - 2018-05-10 13:55:51 --> Config Class Initialized
INFO - 2018-05-10 13:55:51 --> Hooks Class Initialized
DEBUG - 2018-05-10 13:55:51 --> UTF-8 Support Enabled
INFO - 2018-05-10 13:55:51 --> Utf8 Class Initialized
INFO - 2018-05-10 13:55:51 --> URI Class Initialized
INFO - 2018-05-10 13:55:51 --> Router Class Initialized
INFO - 2018-05-10 13:55:51 --> Output Class Initialized
INFO - 2018-05-10 13:55:51 --> Security Class Initialized
DEBUG - 2018-05-10 13:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 13:55:51 --> Input Class Initialized
INFO - 2018-05-10 13:55:51 --> Language Class Initialized
INFO - 2018-05-10 13:55:51 --> Language Class Initialized
INFO - 2018-05-10 13:55:51 --> Config Class Initialized
INFO - 2018-05-10 13:55:51 --> Loader Class Initialized
INFO - 2018-05-10 19:25:51 --> Helper loaded: url_helper
INFO - 2018-05-10 19:25:51 --> Helper loaded: notification_helper
INFO - 2018-05-10 19:25:51 --> Helper loaded: settings_helper
INFO - 2018-05-10 19:25:51 --> Helper loaded: permission_helper
INFO - 2018-05-10 19:25:51 --> Helper loaded: users_helper
INFO - 2018-05-10 19:25:51 --> Database Driver Class Initialized
DEBUG - 2018-05-10 19:25:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 19:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 19:25:51 --> Helper loaded: form_helper
INFO - 2018-05-10 19:25:51 --> Form Validation Class Initialized
INFO - 2018-05-10 19:25:51 --> Controller Class Initialized
INFO - 2018-05-10 19:25:51 --> Model Class Initialized
INFO - 2018-05-10 19:25:51 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 19:25:51 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 19:25:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 19:25:51 --> Model Class Initialized
INFO - 2018-05-10 19:25:51 --> Model Class Initialized
INFO - 2018-05-10 19:25:51 --> Model Class Initialized
INFO - 2018-05-10 19:25:51 --> Model Class Initialized
INFO - 2018-05-10 19:25:51 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 19:25:51 --> Model Class Initialized
INFO - 2018-05-10 19:25:51 --> Final output sent to browser
DEBUG - 2018-05-10 19:25:51 --> Total execution time: 0.1098
INFO - 2018-05-10 13:56:06 --> Config Class Initialized
INFO - 2018-05-10 13:56:06 --> Hooks Class Initialized
DEBUG - 2018-05-10 13:56:06 --> UTF-8 Support Enabled
INFO - 2018-05-10 13:56:06 --> Utf8 Class Initialized
INFO - 2018-05-10 13:56:06 --> URI Class Initialized
INFO - 2018-05-10 13:56:06 --> Router Class Initialized
INFO - 2018-05-10 13:56:06 --> Output Class Initialized
INFO - 2018-05-10 13:56:06 --> Security Class Initialized
DEBUG - 2018-05-10 13:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 13:56:06 --> Input Class Initialized
INFO - 2018-05-10 13:56:06 --> Language Class Initialized
INFO - 2018-05-10 13:56:07 --> Language Class Initialized
INFO - 2018-05-10 13:56:07 --> Config Class Initialized
INFO - 2018-05-10 13:56:07 --> Loader Class Initialized
INFO - 2018-05-10 19:26:07 --> Helper loaded: url_helper
INFO - 2018-05-10 19:26:07 --> Helper loaded: notification_helper
INFO - 2018-05-10 19:26:07 --> Helper loaded: settings_helper
INFO - 2018-05-10 19:26:07 --> Helper loaded: permission_helper
INFO - 2018-05-10 19:26:07 --> Helper loaded: users_helper
INFO - 2018-05-10 19:26:07 --> Database Driver Class Initialized
DEBUG - 2018-05-10 19:26:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 19:26:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 19:26:07 --> Helper loaded: form_helper
INFO - 2018-05-10 19:26:07 --> Form Validation Class Initialized
INFO - 2018-05-10 19:26:07 --> Controller Class Initialized
INFO - 2018-05-10 19:26:07 --> Model Class Initialized
INFO - 2018-05-10 19:26:07 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 19:26:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 19:26:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 19:26:07 --> Model Class Initialized
INFO - 2018-05-10 19:26:07 --> Model Class Initialized
INFO - 2018-05-10 19:26:07 --> Model Class Initialized
INFO - 2018-05-10 19:26:07 --> Model Class Initialized
INFO - 2018-05-10 19:26:07 --> Model Class Initialized
INFO - 2018-05-10 19:26:07 --> Model Class Initialized
INFO - 2018-05-10 19:26:07 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 19:26:07 --> Final output sent to browser
DEBUG - 2018-05-10 19:26:07 --> Total execution time: 0.1358
INFO - 2018-05-10 13:56:07 --> Config Class Initialized
INFO - 2018-05-10 13:56:08 --> Hooks Class Initialized
DEBUG - 2018-05-10 13:56:08 --> UTF-8 Support Enabled
INFO - 2018-05-10 13:56:08 --> Utf8 Class Initialized
INFO - 2018-05-10 13:56:08 --> URI Class Initialized
INFO - 2018-05-10 13:56:08 --> Router Class Initialized
INFO - 2018-05-10 13:56:08 --> Output Class Initialized
INFO - 2018-05-10 13:56:08 --> Security Class Initialized
DEBUG - 2018-05-10 13:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 13:56:08 --> Input Class Initialized
INFO - 2018-05-10 13:56:08 --> Language Class Initialized
INFO - 2018-05-10 13:56:08 --> Language Class Initialized
INFO - 2018-05-10 13:56:08 --> Config Class Initialized
INFO - 2018-05-10 13:56:08 --> Loader Class Initialized
INFO - 2018-05-10 19:26:08 --> Helper loaded: url_helper
INFO - 2018-05-10 19:26:08 --> Helper loaded: notification_helper
INFO - 2018-05-10 19:26:08 --> Helper loaded: settings_helper
INFO - 2018-05-10 19:26:08 --> Helper loaded: permission_helper
INFO - 2018-05-10 19:26:08 --> Helper loaded: users_helper
INFO - 2018-05-10 19:26:08 --> Database Driver Class Initialized
DEBUG - 2018-05-10 19:26:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 19:26:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 19:26:08 --> Helper loaded: form_helper
INFO - 2018-05-10 19:26:08 --> Form Validation Class Initialized
INFO - 2018-05-10 19:26:08 --> Controller Class Initialized
INFO - 2018-05-10 19:26:08 --> Model Class Initialized
INFO - 2018-05-10 19:26:08 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 19:26:08 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 19:26:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 19:26:08 --> Model Class Initialized
INFO - 2018-05-10 19:26:08 --> Model Class Initialized
INFO - 2018-05-10 19:26:08 --> Model Class Initialized
INFO - 2018-05-10 19:26:08 --> Model Class Initialized
INFO - 2018-05-10 19:26:08 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 19:26:08 --> Model Class Initialized
INFO - 2018-05-10 19:26:08 --> Final output sent to browser
DEBUG - 2018-05-10 19:26:08 --> Total execution time: 0.1023
INFO - 2018-05-10 14:02:42 --> Config Class Initialized
INFO - 2018-05-10 14:02:42 --> Hooks Class Initialized
DEBUG - 2018-05-10 14:02:42 --> UTF-8 Support Enabled
INFO - 2018-05-10 14:02:42 --> Utf8 Class Initialized
INFO - 2018-05-10 14:02:42 --> URI Class Initialized
INFO - 2018-05-10 14:02:42 --> Router Class Initialized
INFO - 2018-05-10 14:02:42 --> Output Class Initialized
INFO - 2018-05-10 14:02:42 --> Security Class Initialized
DEBUG - 2018-05-10 14:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 14:02:42 --> Input Class Initialized
INFO - 2018-05-10 14:02:42 --> Language Class Initialized
INFO - 2018-05-10 14:02:42 --> Language Class Initialized
INFO - 2018-05-10 14:02:42 --> Config Class Initialized
INFO - 2018-05-10 14:02:42 --> Loader Class Initialized
INFO - 2018-05-10 19:32:42 --> Helper loaded: url_helper
INFO - 2018-05-10 19:32:42 --> Helper loaded: notification_helper
INFO - 2018-05-10 19:32:42 --> Helper loaded: settings_helper
INFO - 2018-05-10 19:32:42 --> Helper loaded: permission_helper
INFO - 2018-05-10 19:32:42 --> Helper loaded: users_helper
INFO - 2018-05-10 19:32:42 --> Database Driver Class Initialized
DEBUG - 2018-05-10 19:32:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 19:32:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 19:32:42 --> Helper loaded: form_helper
INFO - 2018-05-10 19:32:42 --> Form Validation Class Initialized
INFO - 2018-05-10 19:32:42 --> Controller Class Initialized
INFO - 2018-05-10 19:32:42 --> Model Class Initialized
INFO - 2018-05-10 19:32:42 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 19:32:42 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 19:32:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 19:32:42 --> Model Class Initialized
INFO - 2018-05-10 19:32:42 --> Model Class Initialized
INFO - 2018-05-10 19:32:42 --> Model Class Initialized
INFO - 2018-05-10 19:32:42 --> Model Class Initialized
INFO - 2018-05-10 19:32:42 --> Model Class Initialized
INFO - 2018-05-10 19:32:42 --> Model Class Initialized
INFO - 2018-05-10 19:32:42 --> Model Class Initialized
INFO - 2018-05-10 19:32:42 --> Model Class Initialized
INFO - 2018-05-10 19:32:42 --> Model Class Initialized
INFO - 2018-05-10 19:32:42 --> Model Class Initialized
INFO - 2018-05-10 19:32:42 --> Model Class Initialized
INFO - 2018-05-10 19:32:42 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 19:32:42 --> Model Class Initialized
INFO - 2018-05-10 19:32:42 --> Final output sent to browser
DEBUG - 2018-05-10 19:32:42 --> Total execution time: 0.1143
INFO - 2018-05-10 14:02:50 --> Config Class Initialized
INFO - 2018-05-10 14:02:50 --> Hooks Class Initialized
DEBUG - 2018-05-10 14:02:50 --> UTF-8 Support Enabled
INFO - 2018-05-10 14:02:50 --> Utf8 Class Initialized
INFO - 2018-05-10 14:02:50 --> URI Class Initialized
INFO - 2018-05-10 14:02:50 --> Router Class Initialized
INFO - 2018-05-10 14:02:50 --> Output Class Initialized
INFO - 2018-05-10 14:02:50 --> Security Class Initialized
DEBUG - 2018-05-10 14:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 14:02:50 --> Input Class Initialized
INFO - 2018-05-10 14:02:50 --> Language Class Initialized
INFO - 2018-05-10 14:02:50 --> Language Class Initialized
INFO - 2018-05-10 14:02:50 --> Config Class Initialized
INFO - 2018-05-10 14:02:50 --> Loader Class Initialized
INFO - 2018-05-10 19:32:50 --> Helper loaded: url_helper
INFO - 2018-05-10 19:32:50 --> Helper loaded: notification_helper
INFO - 2018-05-10 19:32:50 --> Helper loaded: settings_helper
INFO - 2018-05-10 19:32:50 --> Helper loaded: permission_helper
INFO - 2018-05-10 19:32:50 --> Helper loaded: users_helper
INFO - 2018-05-10 19:32:50 --> Database Driver Class Initialized
DEBUG - 2018-05-10 19:32:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 19:32:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 19:32:50 --> Helper loaded: form_helper
INFO - 2018-05-10 19:32:50 --> Form Validation Class Initialized
INFO - 2018-05-10 19:32:50 --> Controller Class Initialized
INFO - 2018-05-10 19:32:50 --> Model Class Initialized
INFO - 2018-05-10 19:32:50 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 19:32:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 19:32:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 19:32:50 --> Model Class Initialized
INFO - 2018-05-10 19:32:50 --> Model Class Initialized
INFO - 2018-05-10 19:32:50 --> Model Class Initialized
INFO - 2018-05-10 19:32:50 --> Model Class Initialized
INFO - 2018-05-10 19:32:50 --> Model Class Initialized
INFO - 2018-05-10 19:32:50 --> Model Class Initialized
INFO - 2018-05-10 19:32:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 19:32:50 --> Model Class Initialized
INFO - 2018-05-10 19:32:50 --> Final output sent to browser
DEBUG - 2018-05-10 19:32:50 --> Total execution time: 0.1328
INFO - 2018-05-10 14:02:56 --> Config Class Initialized
INFO - 2018-05-10 14:02:56 --> Hooks Class Initialized
DEBUG - 2018-05-10 14:02:56 --> UTF-8 Support Enabled
INFO - 2018-05-10 14:02:56 --> Utf8 Class Initialized
INFO - 2018-05-10 14:02:56 --> URI Class Initialized
INFO - 2018-05-10 14:02:56 --> Router Class Initialized
INFO - 2018-05-10 14:02:56 --> Output Class Initialized
INFO - 2018-05-10 14:02:56 --> Security Class Initialized
DEBUG - 2018-05-10 14:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 14:02:56 --> Input Class Initialized
INFO - 2018-05-10 14:02:56 --> Language Class Initialized
INFO - 2018-05-10 14:02:56 --> Language Class Initialized
INFO - 2018-05-10 14:02:56 --> Config Class Initialized
INFO - 2018-05-10 14:02:56 --> Loader Class Initialized
INFO - 2018-05-10 19:32:56 --> Helper loaded: url_helper
INFO - 2018-05-10 19:32:56 --> Helper loaded: notification_helper
INFO - 2018-05-10 19:32:56 --> Helper loaded: settings_helper
INFO - 2018-05-10 19:32:56 --> Helper loaded: permission_helper
INFO - 2018-05-10 19:32:56 --> Helper loaded: users_helper
INFO - 2018-05-10 19:32:56 --> Database Driver Class Initialized
DEBUG - 2018-05-10 19:32:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 19:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 14:02:56 --> Config Class Initialized
INFO - 2018-05-10 14:02:56 --> Hooks Class Initialized
INFO - 2018-05-10 19:32:56 --> Helper loaded: form_helper
INFO - 2018-05-10 19:32:56 --> Form Validation Class Initialized
INFO - 2018-05-10 19:32:56 --> Controller Class Initialized
DEBUG - 2018-05-10 14:02:56 --> UTF-8 Support Enabled
INFO - 2018-05-10 14:02:56 --> Utf8 Class Initialized
INFO - 2018-05-10 14:02:56 --> URI Class Initialized
INFO - 2018-05-10 14:02:56 --> Router Class Initialized
INFO - 2018-05-10 19:32:56 --> Model Class Initialized
INFO - 2018-05-10 19:32:56 --> Helper loaded: inflector_helper
INFO - 2018-05-10 14:02:56 --> Output Class Initialized
DEBUG - 2018-05-10 19:32:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 14:02:56 --> Security Class Initialized
INFO - 2018-05-10 19:32:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 19:32:56 --> Model Class Initialized
DEBUG - 2018-05-10 14:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 14:02:56 --> Input Class Initialized
INFO - 2018-05-10 19:32:56 --> Model Class Initialized
INFO - 2018-05-10 14:02:56 --> Language Class Initialized
INFO - 2018-05-10 19:32:56 --> Model Class Initialized
INFO - 2018-05-10 19:32:56 --> Model Class Initialized
INFO - 2018-05-10 19:32:56 --> Model Class Initialized
INFO - 2018-05-10 19:32:56 --> Model Class Initialized
INFO - 2018-05-10 19:32:56 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 19:32:56 --> Final output sent to browser
DEBUG - 2018-05-10 19:32:56 --> Total execution time: 0.1126
INFO - 2018-05-10 14:02:56 --> Language Class Initialized
INFO - 2018-05-10 14:02:56 --> Config Class Initialized
INFO - 2018-05-10 14:02:56 --> Loader Class Initialized
INFO - 2018-05-10 19:32:56 --> Helper loaded: url_helper
INFO - 2018-05-10 19:32:56 --> Helper loaded: notification_helper
INFO - 2018-05-10 19:32:56 --> Helper loaded: settings_helper
INFO - 2018-05-10 19:32:56 --> Helper loaded: permission_helper
INFO - 2018-05-10 19:32:56 --> Helper loaded: users_helper
INFO - 2018-05-10 19:32:56 --> Database Driver Class Initialized
DEBUG - 2018-05-10 19:32:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 19:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 19:32:56 --> Helper loaded: form_helper
INFO - 2018-05-10 19:32:56 --> Form Validation Class Initialized
INFO - 2018-05-10 19:32:56 --> Controller Class Initialized
INFO - 2018-05-10 19:32:56 --> Model Class Initialized
INFO - 2018-05-10 19:32:56 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 19:32:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 19:32:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 19:32:56 --> Model Class Initialized
INFO - 2018-05-10 19:32:56 --> Model Class Initialized
INFO - 2018-05-10 19:32:56 --> Model Class Initialized
INFO - 2018-05-10 19:32:56 --> Model Class Initialized
INFO - 2018-05-10 19:32:56 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 19:32:56 --> Final output sent to browser
DEBUG - 2018-05-10 19:32:56 --> Total execution time: 0.1018
INFO - 2018-05-10 14:02:58 --> Config Class Initialized
INFO - 2018-05-10 14:02:58 --> Hooks Class Initialized
DEBUG - 2018-05-10 14:02:58 --> UTF-8 Support Enabled
INFO - 2018-05-10 14:02:58 --> Utf8 Class Initialized
INFO - 2018-05-10 14:02:58 --> URI Class Initialized
INFO - 2018-05-10 14:02:58 --> Router Class Initialized
INFO - 2018-05-10 14:02:58 --> Output Class Initialized
INFO - 2018-05-10 14:02:58 --> Security Class Initialized
DEBUG - 2018-05-10 14:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 14:02:58 --> Input Class Initialized
INFO - 2018-05-10 14:02:58 --> Language Class Initialized
INFO - 2018-05-10 14:02:58 --> Language Class Initialized
INFO - 2018-05-10 14:02:58 --> Config Class Initialized
INFO - 2018-05-10 14:02:58 --> Loader Class Initialized
INFO - 2018-05-10 19:32:58 --> Helper loaded: url_helper
INFO - 2018-05-10 19:32:58 --> Helper loaded: notification_helper
INFO - 2018-05-10 19:32:58 --> Helper loaded: settings_helper
INFO - 2018-05-10 19:32:58 --> Helper loaded: permission_helper
INFO - 2018-05-10 19:32:58 --> Helper loaded: users_helper
INFO - 2018-05-10 19:32:58 --> Database Driver Class Initialized
DEBUG - 2018-05-10 19:32:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 19:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 19:32:58 --> Helper loaded: form_helper
INFO - 2018-05-10 19:32:58 --> Form Validation Class Initialized
INFO - 2018-05-10 19:32:58 --> Controller Class Initialized
INFO - 2018-05-10 19:32:58 --> Model Class Initialized
INFO - 2018-05-10 19:32:58 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 19:32:58 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 19:32:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 19:32:58 --> Model Class Initialized
INFO - 2018-05-10 19:32:58 --> Model Class Initialized
INFO - 2018-05-10 19:32:58 --> Model Class Initialized
INFO - 2018-05-10 19:32:58 --> Model Class Initialized
INFO - 2018-05-10 19:32:58 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 19:32:58 --> Model Class Initialized
INFO - 2018-05-10 19:32:58 --> Final output sent to browser
DEBUG - 2018-05-10 19:32:58 --> Total execution time: 0.1111
INFO - 2018-05-10 14:13:26 --> Config Class Initialized
INFO - 2018-05-10 14:13:26 --> Hooks Class Initialized
DEBUG - 2018-05-10 14:13:26 --> UTF-8 Support Enabled
INFO - 2018-05-10 14:13:26 --> Utf8 Class Initialized
INFO - 2018-05-10 14:13:26 --> URI Class Initialized
INFO - 2018-05-10 14:13:26 --> Router Class Initialized
INFO - 2018-05-10 14:13:26 --> Output Class Initialized
INFO - 2018-05-10 14:13:26 --> Security Class Initialized
DEBUG - 2018-05-10 14:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 14:13:26 --> Input Class Initialized
INFO - 2018-05-10 14:13:26 --> Language Class Initialized
INFO - 2018-05-10 14:13:26 --> Language Class Initialized
INFO - 2018-05-10 14:13:26 --> Config Class Initialized
INFO - 2018-05-10 14:13:26 --> Loader Class Initialized
INFO - 2018-05-10 19:43:26 --> Helper loaded: url_helper
INFO - 2018-05-10 19:43:26 --> Helper loaded: notification_helper
INFO - 2018-05-10 19:43:26 --> Helper loaded: settings_helper
INFO - 2018-05-10 19:43:26 --> Helper loaded: permission_helper
INFO - 2018-05-10 19:43:26 --> Helper loaded: users_helper
INFO - 2018-05-10 19:43:26 --> Database Driver Class Initialized
DEBUG - 2018-05-10 19:43:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 19:43:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 19:43:26 --> Helper loaded: form_helper
INFO - 2018-05-10 19:43:26 --> Form Validation Class Initialized
INFO - 2018-05-10 19:43:26 --> Controller Class Initialized
INFO - 2018-05-10 19:43:27 --> Model Class Initialized
INFO - 2018-05-10 14:13:27 --> Config Class Initialized
INFO - 2018-05-10 14:13:27 --> Hooks Class Initialized
INFO - 2018-05-10 19:43:27 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 14:13:27 --> UTF-8 Support Enabled
INFO - 2018-05-10 14:13:27 --> Utf8 Class Initialized
DEBUG - 2018-05-10 19:43:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 14:13:27 --> URI Class Initialized
INFO - 2018-05-10 19:43:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 19:43:27 --> Model Class Initialized
INFO - 2018-05-10 19:43:27 --> Model Class Initialized
INFO - 2018-05-10 19:43:27 --> Model Class Initialized
INFO - 2018-05-10 19:43:27 --> Model Class Initialized
INFO - 2018-05-10 14:13:27 --> Router Class Initialized
INFO - 2018-05-10 19:43:27 --> Model Class Initialized
INFO - 2018-05-10 19:43:27 --> Model Class Initialized
INFO - 2018-05-10 19:43:27 --> Model Class Initialized
INFO - 2018-05-10 19:43:27 --> Model Class Initialized
INFO - 2018-05-10 19:43:27 --> Model Class Initialized
INFO - 2018-05-10 19:43:27 --> Model Class Initialized
INFO - 2018-05-10 14:13:27 --> Output Class Initialized
INFO - 2018-05-10 14:13:27 --> Security Class Initialized
INFO - 2018-05-10 19:43:27 --> Model Class Initialized
INFO - 2018-05-10 19:43:27 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 19:43:27 --> Model Class Initialized
DEBUG - 2018-05-10 14:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 14:13:27 --> Input Class Initialized
INFO - 2018-05-10 14:13:27 --> Language Class Initialized
INFO - 2018-05-10 19:43:27 --> Final output sent to browser
DEBUG - 2018-05-10 19:43:27 --> Total execution time: 0.1226
INFO - 2018-05-10 14:13:27 --> Language Class Initialized
INFO - 2018-05-10 14:13:27 --> Config Class Initialized
INFO - 2018-05-10 14:13:27 --> Loader Class Initialized
INFO - 2018-05-10 19:43:27 --> Helper loaded: url_helper
INFO - 2018-05-10 19:43:27 --> Helper loaded: notification_helper
INFO - 2018-05-10 19:43:27 --> Helper loaded: settings_helper
INFO - 2018-05-10 19:43:27 --> Helper loaded: permission_helper
INFO - 2018-05-10 19:43:27 --> Helper loaded: users_helper
INFO - 2018-05-10 19:43:27 --> Database Driver Class Initialized
DEBUG - 2018-05-10 19:43:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 19:43:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 19:43:27 --> Helper loaded: form_helper
INFO - 2018-05-10 19:43:27 --> Form Validation Class Initialized
INFO - 2018-05-10 19:43:27 --> Controller Class Initialized
INFO - 2018-05-10 19:43:27 --> Model Class Initialized
INFO - 2018-05-10 19:43:27 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 19:43:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 19:43:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 19:43:27 --> Model Class Initialized
INFO - 2018-05-10 19:43:27 --> Model Class Initialized
INFO - 2018-05-10 19:43:27 --> Model Class Initialized
INFO - 2018-05-10 19:43:27 --> Model Class Initialized
INFO - 2018-05-10 19:43:27 --> Model Class Initialized
INFO - 2018-05-10 19:43:27 --> Model Class Initialized
INFO - 2018-05-10 19:43:27 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 19:43:27 --> Model Class Initialized
INFO - 2018-05-10 19:43:27 --> Final output sent to browser
DEBUG - 2018-05-10 19:43:27 --> Total execution time: 0.1082
INFO - 2018-05-10 14:13:30 --> Config Class Initialized
INFO - 2018-05-10 14:13:30 --> Hooks Class Initialized
DEBUG - 2018-05-10 14:13:30 --> UTF-8 Support Enabled
INFO - 2018-05-10 14:13:30 --> Utf8 Class Initialized
INFO - 2018-05-10 14:13:30 --> Config Class Initialized
INFO - 2018-05-10 14:13:30 --> Hooks Class Initialized
INFO - 2018-05-10 14:13:30 --> URI Class Initialized
DEBUG - 2018-05-10 14:13:30 --> UTF-8 Support Enabled
INFO - 2018-05-10 14:13:30 --> Utf8 Class Initialized
INFO - 2018-05-10 14:13:30 --> URI Class Initialized
INFO - 2018-05-10 14:13:30 --> Router Class Initialized
INFO - 2018-05-10 14:13:30 --> Output Class Initialized
INFO - 2018-05-10 14:13:30 --> Security Class Initialized
DEBUG - 2018-05-10 14:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 14:13:30 --> Input Class Initialized
INFO - 2018-05-10 14:13:30 --> Router Class Initialized
INFO - 2018-05-10 14:13:30 --> Language Class Initialized
INFO - 2018-05-10 14:13:30 --> Output Class Initialized
INFO - 2018-05-10 14:13:30 --> Security Class Initialized
DEBUG - 2018-05-10 14:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 14:13:30 --> Input Class Initialized
INFO - 2018-05-10 14:13:30 --> Language Class Initialized
INFO - 2018-05-10 14:13:30 --> Language Class Initialized
INFO - 2018-05-10 14:13:30 --> Config Class Initialized
INFO - 2018-05-10 14:13:30 --> Loader Class Initialized
INFO - 2018-05-10 19:43:30 --> Helper loaded: url_helper
INFO - 2018-05-10 19:43:30 --> Helper loaded: notification_helper
INFO - 2018-05-10 19:43:30 --> Helper loaded: settings_helper
INFO - 2018-05-10 19:43:30 --> Helper loaded: permission_helper
INFO - 2018-05-10 19:43:30 --> Helper loaded: users_helper
INFO - 2018-05-10 14:13:30 --> Language Class Initialized
INFO - 2018-05-10 14:13:30 --> Config Class Initialized
INFO - 2018-05-10 14:13:30 --> Loader Class Initialized
INFO - 2018-05-10 19:43:30 --> Helper loaded: url_helper
INFO - 2018-05-10 19:43:30 --> Helper loaded: notification_helper
INFO - 2018-05-10 19:43:30 --> Helper loaded: settings_helper
INFO - 2018-05-10 19:43:30 --> Helper loaded: permission_helper
INFO - 2018-05-10 19:43:30 --> Helper loaded: users_helper
INFO - 2018-05-10 19:43:30 --> Database Driver Class Initialized
DEBUG - 2018-05-10 19:43:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 19:43:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 19:43:30 --> Helper loaded: form_helper
INFO - 2018-05-10 19:43:30 --> Form Validation Class Initialized
INFO - 2018-05-10 19:43:30 --> Controller Class Initialized
INFO - 2018-05-10 19:43:30 --> Database Driver Class Initialized
DEBUG - 2018-05-10 19:43:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 19:43:30 --> Model Class Initialized
INFO - 2018-05-10 19:43:30 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 19:43:30 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 19:43:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 19:43:30 --> Model Class Initialized
INFO - 2018-05-10 19:43:30 --> Model Class Initialized
INFO - 2018-05-10 19:43:30 --> Model Class Initialized
INFO - 2018-05-10 19:43:30 --> Model Class Initialized
INFO - 2018-05-10 19:43:30 --> Model Class Initialized
INFO - 2018-05-10 19:43:30 --> Model Class Initialized
INFO - 2018-05-10 19:43:30 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 19:43:30 --> Final output sent to browser
DEBUG - 2018-05-10 19:43:30 --> Total execution time: 0.1080
INFO - 2018-05-10 19:43:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 19:43:30 --> Helper loaded: form_helper
INFO - 2018-05-10 19:43:30 --> Form Validation Class Initialized
INFO - 2018-05-10 19:43:30 --> Controller Class Initialized
INFO - 2018-05-10 19:43:30 --> Model Class Initialized
INFO - 2018-05-10 19:43:30 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 19:43:30 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 19:43:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 19:43:30 --> Model Class Initialized
INFO - 2018-05-10 19:43:30 --> Model Class Initialized
INFO - 2018-05-10 19:43:30 --> Model Class Initialized
INFO - 2018-05-10 19:43:30 --> Model Class Initialized
INFO - 2018-05-10 19:43:30 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 19:43:30 --> Final output sent to browser
DEBUG - 2018-05-10 19:43:30 --> Total execution time: 0.1465
INFO - 2018-05-10 14:13:32 --> Config Class Initialized
INFO - 2018-05-10 14:13:32 --> Hooks Class Initialized
DEBUG - 2018-05-10 14:13:32 --> UTF-8 Support Enabled
INFO - 2018-05-10 14:13:32 --> Utf8 Class Initialized
INFO - 2018-05-10 14:13:32 --> URI Class Initialized
INFO - 2018-05-10 14:13:32 --> Router Class Initialized
INFO - 2018-05-10 14:13:32 --> Output Class Initialized
INFO - 2018-05-10 14:13:32 --> Security Class Initialized
DEBUG - 2018-05-10 14:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 14:13:32 --> Input Class Initialized
INFO - 2018-05-10 14:13:32 --> Language Class Initialized
INFO - 2018-05-10 14:13:32 --> Language Class Initialized
INFO - 2018-05-10 14:13:32 --> Config Class Initialized
INFO - 2018-05-10 14:13:32 --> Loader Class Initialized
INFO - 2018-05-10 19:43:32 --> Helper loaded: url_helper
INFO - 2018-05-10 19:43:32 --> Helper loaded: notification_helper
INFO - 2018-05-10 19:43:32 --> Helper loaded: settings_helper
INFO - 2018-05-10 19:43:32 --> Helper loaded: permission_helper
INFO - 2018-05-10 19:43:32 --> Helper loaded: users_helper
INFO - 2018-05-10 19:43:32 --> Database Driver Class Initialized
DEBUG - 2018-05-10 19:43:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 19:43:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 19:43:32 --> Helper loaded: form_helper
INFO - 2018-05-10 19:43:32 --> Form Validation Class Initialized
INFO - 2018-05-10 19:43:32 --> Controller Class Initialized
INFO - 2018-05-10 19:43:32 --> Model Class Initialized
INFO - 2018-05-10 19:43:32 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 19:43:32 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 19:43:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 19:43:32 --> Model Class Initialized
INFO - 2018-05-10 19:43:32 --> Model Class Initialized
INFO - 2018-05-10 19:43:32 --> Model Class Initialized
INFO - 2018-05-10 19:43:32 --> Model Class Initialized
INFO - 2018-05-10 19:43:32 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 19:43:32 --> Model Class Initialized
INFO - 2018-05-10 19:43:32 --> Final output sent to browser
DEBUG - 2018-05-10 19:43:32 --> Total execution time: 0.0994
INFO - 2018-05-10 14:19:42 --> Config Class Initialized
INFO - 2018-05-10 14:19:42 --> Hooks Class Initialized
DEBUG - 2018-05-10 14:19:42 --> UTF-8 Support Enabled
INFO - 2018-05-10 14:19:42 --> Utf8 Class Initialized
INFO - 2018-05-10 14:19:42 --> URI Class Initialized
INFO - 2018-05-10 14:19:42 --> Router Class Initialized
INFO - 2018-05-10 14:19:42 --> Output Class Initialized
INFO - 2018-05-10 14:19:42 --> Security Class Initialized
DEBUG - 2018-05-10 14:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 14:19:42 --> Input Class Initialized
INFO - 2018-05-10 14:19:42 --> Language Class Initialized
INFO - 2018-05-10 14:19:42 --> Language Class Initialized
INFO - 2018-05-10 14:19:42 --> Config Class Initialized
INFO - 2018-05-10 14:19:42 --> Loader Class Initialized
INFO - 2018-05-10 19:49:42 --> Helper loaded: url_helper
INFO - 2018-05-10 19:49:42 --> Helper loaded: notification_helper
INFO - 2018-05-10 19:49:42 --> Helper loaded: settings_helper
INFO - 2018-05-10 19:49:42 --> Helper loaded: permission_helper
INFO - 2018-05-10 19:49:42 --> Helper loaded: users_helper
INFO - 2018-05-10 19:49:42 --> Database Driver Class Initialized
DEBUG - 2018-05-10 19:49:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 19:49:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 19:49:42 --> Helper loaded: form_helper
INFO - 2018-05-10 19:49:42 --> Form Validation Class Initialized
INFO - 2018-05-10 19:49:42 --> Controller Class Initialized
INFO - 2018-05-10 19:49:42 --> Model Class Initialized
INFO - 2018-05-10 19:49:42 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 19:49:42 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 19:49:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 19:49:42 --> Model Class Initialized
INFO - 2018-05-10 19:49:42 --> Model Class Initialized
INFO - 2018-05-10 19:49:42 --> Model Class Initialized
INFO - 2018-05-10 19:49:42 --> Model Class Initialized
INFO - 2018-05-10 19:49:42 --> Model Class Initialized
INFO - 2018-05-10 19:49:42 --> Model Class Initialized
INFO - 2018-05-10 19:49:42 --> Model Class Initialized
INFO - 2018-05-10 19:49:42 --> Model Class Initialized
INFO - 2018-05-10 19:49:42 --> Model Class Initialized
INFO - 2018-05-10 19:49:42 --> Model Class Initialized
INFO - 2018-05-10 19:49:42 --> Model Class Initialized
INFO - 2018-05-10 19:49:42 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 19:49:42 --> Model Class Initialized
INFO - 2018-05-10 19:49:42 --> Final output sent to browser
DEBUG - 2018-05-10 19:49:42 --> Total execution time: 0.1174
INFO - 2018-05-10 14:19:42 --> Config Class Initialized
INFO - 2018-05-10 14:19:42 --> Hooks Class Initialized
DEBUG - 2018-05-10 14:19:42 --> UTF-8 Support Enabled
INFO - 2018-05-10 14:19:42 --> Utf8 Class Initialized
INFO - 2018-05-10 14:19:42 --> URI Class Initialized
INFO - 2018-05-10 14:19:42 --> Router Class Initialized
INFO - 2018-05-10 14:19:42 --> Output Class Initialized
INFO - 2018-05-10 14:19:42 --> Security Class Initialized
DEBUG - 2018-05-10 14:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 14:19:42 --> Input Class Initialized
INFO - 2018-05-10 14:19:42 --> Language Class Initialized
INFO - 2018-05-10 14:19:42 --> Language Class Initialized
INFO - 2018-05-10 14:19:42 --> Config Class Initialized
INFO - 2018-05-10 14:19:42 --> Loader Class Initialized
INFO - 2018-05-10 19:49:42 --> Helper loaded: url_helper
INFO - 2018-05-10 19:49:42 --> Helper loaded: notification_helper
INFO - 2018-05-10 19:49:42 --> Helper loaded: settings_helper
INFO - 2018-05-10 19:49:42 --> Helper loaded: permission_helper
INFO - 2018-05-10 19:49:42 --> Helper loaded: users_helper
INFO - 2018-05-10 19:49:42 --> Database Driver Class Initialized
DEBUG - 2018-05-10 19:49:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 19:49:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 19:49:42 --> Helper loaded: form_helper
INFO - 2018-05-10 19:49:42 --> Form Validation Class Initialized
INFO - 2018-05-10 19:49:42 --> Controller Class Initialized
INFO - 2018-05-10 19:49:42 --> Model Class Initialized
INFO - 2018-05-10 19:49:42 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 19:49:42 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 19:49:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 19:49:42 --> Model Class Initialized
INFO - 2018-05-10 19:49:42 --> Model Class Initialized
INFO - 2018-05-10 19:49:42 --> Model Class Initialized
INFO - 2018-05-10 19:49:42 --> Model Class Initialized
INFO - 2018-05-10 19:49:42 --> Model Class Initialized
INFO - 2018-05-10 19:49:42 --> Model Class Initialized
INFO - 2018-05-10 19:49:42 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 19:49:42 --> Model Class Initialized
INFO - 2018-05-10 19:49:42 --> Final output sent to browser
DEBUG - 2018-05-10 19:49:42 --> Total execution time: 0.1365
INFO - 2018-05-10 14:19:50 --> Config Class Initialized
INFO - 2018-05-10 14:19:50 --> Hooks Class Initialized
DEBUG - 2018-05-10 14:19:50 --> UTF-8 Support Enabled
INFO - 2018-05-10 14:19:50 --> Utf8 Class Initialized
INFO - 2018-05-10 14:19:50 --> URI Class Initialized
INFO - 2018-05-10 14:19:50 --> Router Class Initialized
INFO - 2018-05-10 14:19:50 --> Output Class Initialized
INFO - 2018-05-10 14:19:50 --> Config Class Initialized
INFO - 2018-05-10 14:19:50 --> Hooks Class Initialized
INFO - 2018-05-10 14:19:50 --> Security Class Initialized
DEBUG - 2018-05-10 14:19:50 --> UTF-8 Support Enabled
INFO - 2018-05-10 14:19:50 --> Utf8 Class Initialized
DEBUG - 2018-05-10 14:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 14:19:50 --> Input Class Initialized
INFO - 2018-05-10 14:19:50 --> Language Class Initialized
INFO - 2018-05-10 14:19:50 --> URI Class Initialized
INFO - 2018-05-10 14:19:50 --> Router Class Initialized
INFO - 2018-05-10 14:19:50 --> Output Class Initialized
INFO - 2018-05-10 14:19:50 --> Security Class Initialized
DEBUG - 2018-05-10 14:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 14:19:50 --> Input Class Initialized
INFO - 2018-05-10 14:19:50 --> Language Class Initialized
INFO - 2018-05-10 14:19:50 --> Language Class Initialized
INFO - 2018-05-10 14:19:50 --> Config Class Initialized
INFO - 2018-05-10 14:19:50 --> Loader Class Initialized
INFO - 2018-05-10 19:49:50 --> Helper loaded: url_helper
INFO - 2018-05-10 19:49:50 --> Helper loaded: notification_helper
INFO - 2018-05-10 19:49:50 --> Helper loaded: settings_helper
INFO - 2018-05-10 19:49:50 --> Helper loaded: permission_helper
INFO - 2018-05-10 19:49:50 --> Helper loaded: users_helper
INFO - 2018-05-10 14:19:50 --> Language Class Initialized
INFO - 2018-05-10 14:19:50 --> Config Class Initialized
INFO - 2018-05-10 14:19:50 --> Loader Class Initialized
INFO - 2018-05-10 19:49:50 --> Database Driver Class Initialized
INFO - 2018-05-10 19:49:50 --> Helper loaded: url_helper
INFO - 2018-05-10 19:49:50 --> Helper loaded: notification_helper
INFO - 2018-05-10 19:49:50 --> Helper loaded: settings_helper
INFO - 2018-05-10 19:49:50 --> Helper loaded: permission_helper
INFO - 2018-05-10 19:49:50 --> Helper loaded: users_helper
DEBUG - 2018-05-10 19:49:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 19:49:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 19:49:50 --> Helper loaded: form_helper
INFO - 2018-05-10 19:49:50 --> Form Validation Class Initialized
INFO - 2018-05-10 19:49:50 --> Controller Class Initialized
INFO - 2018-05-10 19:49:50 --> Database Driver Class Initialized
INFO - 2018-05-10 19:49:50 --> Model Class Initialized
INFO - 2018-05-10 19:49:50 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 19:49:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-05-10 19:49:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 19:49:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 19:49:50 --> Model Class Initialized
INFO - 2018-05-10 19:49:50 --> Model Class Initialized
INFO - 2018-05-10 19:49:50 --> Model Class Initialized
INFO - 2018-05-10 19:49:50 --> Model Class Initialized
INFO - 2018-05-10 19:49:50 --> Model Class Initialized
INFO - 2018-05-10 19:49:50 --> Model Class Initialized
INFO - 2018-05-10 19:49:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 19:49:50 --> Final output sent to browser
DEBUG - 2018-05-10 19:49:50 --> Total execution time: 0.1083
INFO - 2018-05-10 19:49:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 19:49:50 --> Helper loaded: form_helper
INFO - 2018-05-10 19:49:50 --> Form Validation Class Initialized
INFO - 2018-05-10 19:49:50 --> Controller Class Initialized
INFO - 2018-05-10 19:49:50 --> Model Class Initialized
INFO - 2018-05-10 19:49:50 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 19:49:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 19:49:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 19:49:50 --> Model Class Initialized
INFO - 2018-05-10 19:49:50 --> Model Class Initialized
INFO - 2018-05-10 19:49:50 --> Model Class Initialized
INFO - 2018-05-10 19:49:50 --> Model Class Initialized
INFO - 2018-05-10 19:49:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 19:49:50 --> Final output sent to browser
DEBUG - 2018-05-10 19:49:50 --> Total execution time: 0.1291
INFO - 2018-05-10 14:19:52 --> Config Class Initialized
INFO - 2018-05-10 14:19:52 --> Hooks Class Initialized
DEBUG - 2018-05-10 14:19:52 --> UTF-8 Support Enabled
INFO - 2018-05-10 14:19:52 --> Utf8 Class Initialized
INFO - 2018-05-10 14:19:52 --> URI Class Initialized
INFO - 2018-05-10 14:19:52 --> Router Class Initialized
INFO - 2018-05-10 14:19:52 --> Output Class Initialized
INFO - 2018-05-10 14:19:52 --> Security Class Initialized
DEBUG - 2018-05-10 14:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 14:19:52 --> Input Class Initialized
INFO - 2018-05-10 14:19:52 --> Language Class Initialized
INFO - 2018-05-10 14:19:52 --> Language Class Initialized
INFO - 2018-05-10 14:19:52 --> Config Class Initialized
INFO - 2018-05-10 14:19:52 --> Loader Class Initialized
INFO - 2018-05-10 19:49:52 --> Helper loaded: url_helper
INFO - 2018-05-10 19:49:52 --> Helper loaded: notification_helper
INFO - 2018-05-10 19:49:52 --> Helper loaded: settings_helper
INFO - 2018-05-10 19:49:52 --> Helper loaded: permission_helper
INFO - 2018-05-10 19:49:52 --> Helper loaded: users_helper
INFO - 2018-05-10 19:49:52 --> Database Driver Class Initialized
DEBUG - 2018-05-10 19:49:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 19:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 19:49:52 --> Helper loaded: form_helper
INFO - 2018-05-10 19:49:52 --> Form Validation Class Initialized
INFO - 2018-05-10 19:49:52 --> Controller Class Initialized
INFO - 2018-05-10 19:49:52 --> Model Class Initialized
INFO - 2018-05-10 19:49:52 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 19:49:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 19:49:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 19:49:52 --> Model Class Initialized
INFO - 2018-05-10 19:49:52 --> Model Class Initialized
INFO - 2018-05-10 19:49:52 --> Model Class Initialized
INFO - 2018-05-10 19:49:52 --> Model Class Initialized
INFO - 2018-05-10 19:49:52 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 19:49:52 --> Model Class Initialized
INFO - 2018-05-10 19:49:52 --> Final output sent to browser
DEBUG - 2018-05-10 19:49:52 --> Total execution time: 0.1054
INFO - 2018-05-10 14:20:45 --> Config Class Initialized
INFO - 2018-05-10 14:20:45 --> Hooks Class Initialized
DEBUG - 2018-05-10 14:20:45 --> UTF-8 Support Enabled
INFO - 2018-05-10 14:20:45 --> Utf8 Class Initialized
INFO - 2018-05-10 14:20:45 --> URI Class Initialized
INFO - 2018-05-10 14:20:45 --> Router Class Initialized
INFO - 2018-05-10 14:20:45 --> Output Class Initialized
INFO - 2018-05-10 14:20:45 --> Security Class Initialized
DEBUG - 2018-05-10 14:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 14:20:45 --> Input Class Initialized
INFO - 2018-05-10 14:20:45 --> Language Class Initialized
INFO - 2018-05-10 14:20:45 --> Language Class Initialized
INFO - 2018-05-10 14:20:45 --> Config Class Initialized
INFO - 2018-05-10 14:20:45 --> Loader Class Initialized
INFO - 2018-05-10 19:50:45 --> Helper loaded: url_helper
INFO - 2018-05-10 19:50:45 --> Helper loaded: notification_helper
INFO - 2018-05-10 19:50:45 --> Helper loaded: settings_helper
INFO - 2018-05-10 19:50:45 --> Helper loaded: permission_helper
INFO - 2018-05-10 19:50:45 --> Helper loaded: users_helper
INFO - 2018-05-10 19:50:45 --> Database Driver Class Initialized
DEBUG - 2018-05-10 19:50:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 19:50:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 19:50:45 --> Helper loaded: form_helper
INFO - 2018-05-10 19:50:45 --> Form Validation Class Initialized
INFO - 2018-05-10 19:50:45 --> Controller Class Initialized
INFO - 2018-05-10 19:50:45 --> Model Class Initialized
INFO - 2018-05-10 19:50:46 --> Helper loaded: inflector_helper
DEBUG - 2018-05-10 19:50:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 19:50:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 19:50:46 --> Model Class Initialized
INFO - 2018-05-10 19:50:46 --> Model Class Initialized
INFO - 2018-05-10 19:50:46 --> Model Class Initialized
INFO - 2018-05-10 19:50:46 --> Model Class Initialized
INFO - 2018-05-10 19:50:46 --> Model Class Initialized
INFO - 2018-05-10 19:50:46 --> Model Class Initialized
INFO - 2018-05-10 19:50:46 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 19:50:46 --> Final output sent to browser
DEBUG - 2018-05-10 19:50:46 --> Total execution time: 0.1240
INFO - 2018-05-10 14:25:08 --> Config Class Initialized
INFO - 2018-05-10 14:25:08 --> Hooks Class Initialized
DEBUG - 2018-05-10 14:25:08 --> UTF-8 Support Enabled
INFO - 2018-05-10 14:25:08 --> Utf8 Class Initialized
INFO - 2018-05-10 14:25:08 --> URI Class Initialized
INFO - 2018-05-10 14:25:08 --> Router Class Initialized
INFO - 2018-05-10 14:25:08 --> Output Class Initialized
INFO - 2018-05-10 14:25:08 --> Security Class Initialized
DEBUG - 2018-05-10 14:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 14:25:08 --> Input Class Initialized
INFO - 2018-05-10 14:25:08 --> Language Class Initialized
INFO - 2018-05-10 14:25:08 --> Language Class Initialized
INFO - 2018-05-10 14:25:08 --> Config Class Initialized
INFO - 2018-05-10 14:25:08 --> Loader Class Initialized
INFO - 2018-05-10 19:55:08 --> Helper loaded: url_helper
INFO - 2018-05-10 19:55:08 --> Helper loaded: notification_helper
INFO - 2018-05-10 19:55:08 --> Helper loaded: settings_helper
INFO - 2018-05-10 19:55:08 --> Helper loaded: permission_helper
INFO - 2018-05-10 19:55:08 --> Helper loaded: users_helper
INFO - 2018-05-10 19:55:08 --> Database Driver Class Initialized
DEBUG - 2018-05-10 19:55:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 19:55:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 19:55:08 --> Helper loaded: form_helper
INFO - 2018-05-10 19:55:08 --> Form Validation Class Initialized
INFO - 2018-05-10 19:55:08 --> Controller Class Initialized
INFO - 2018-05-10 19:55:08 --> Model Class Initialized
INFO - 2018-05-10 19:55:08 --> Helper loaded: inflector_helper
INFO - 2018-05-10 19:55:08 --> Model Class Initialized
INFO - 2018-05-10 19:55:08 --> Model Class Initialized
DEBUG - 2018-05-10 19:55:08 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-05-10 19:55:08 --> File loaded: /home/pr01004/public_html/application/views/cmspages/cmspages.php
DEBUG - 2018-05-10 19:55:08 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-05-10 19:55:08 --> Final output sent to browser
DEBUG - 2018-05-10 19:55:08 --> Total execution time: 0.1564
INFO - 2018-05-10 14:25:15 --> Config Class Initialized
INFO - 2018-05-10 14:25:15 --> Hooks Class Initialized
DEBUG - 2018-05-10 14:25:15 --> UTF-8 Support Enabled
INFO - 2018-05-10 14:25:15 --> Utf8 Class Initialized
INFO - 2018-05-10 14:25:15 --> URI Class Initialized
INFO - 2018-05-10 14:25:15 --> Router Class Initialized
INFO - 2018-05-10 14:25:15 --> Output Class Initialized
INFO - 2018-05-10 14:25:15 --> Security Class Initialized
DEBUG - 2018-05-10 14:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 14:25:15 --> Input Class Initialized
INFO - 2018-05-10 14:25:15 --> Language Class Initialized
INFO - 2018-05-10 14:25:15 --> Language Class Initialized
INFO - 2018-05-10 14:25:15 --> Config Class Initialized
INFO - 2018-05-10 14:25:15 --> Loader Class Initialized
INFO - 2018-05-10 19:55:15 --> Helper loaded: url_helper
INFO - 2018-05-10 19:55:15 --> Helper loaded: notification_helper
INFO - 2018-05-10 19:55:15 --> Helper loaded: settings_helper
INFO - 2018-05-10 19:55:15 --> Helper loaded: permission_helper
INFO - 2018-05-10 19:55:15 --> Helper loaded: users_helper
INFO - 2018-05-10 19:55:15 --> Database Driver Class Initialized
DEBUG - 2018-05-10 19:55:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 19:55:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 19:55:15 --> Helper loaded: form_helper
INFO - 2018-05-10 19:55:15 --> Form Validation Class Initialized
INFO - 2018-05-10 19:55:15 --> Controller Class Initialized
INFO - 2018-05-10 19:55:15 --> Model Class Initialized
INFO - 2018-05-10 19:55:15 --> Helper loaded: inflector_helper
INFO - 2018-05-10 19:55:15 --> Model Class Initialized
INFO - 2018-05-10 19:55:15 --> Model Class Initialized
DEBUG - 2018-05-10 19:55:15 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-05-10 19:55:15 --> File loaded: /home/pr01004/public_html/application/views/credits/index.php
DEBUG - 2018-05-10 19:55:15 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-05-10 19:55:15 --> Final output sent to browser
DEBUG - 2018-05-10 19:55:15 --> Total execution time: 0.0906
INFO - 2018-05-10 14:26:56 --> Config Class Initialized
INFO - 2018-05-10 14:26:56 --> Hooks Class Initialized
DEBUG - 2018-05-10 14:26:56 --> UTF-8 Support Enabled
INFO - 2018-05-10 14:26:56 --> Utf8 Class Initialized
INFO - 2018-05-10 14:26:56 --> URI Class Initialized
INFO - 2018-05-10 14:26:56 --> Router Class Initialized
INFO - 2018-05-10 14:26:56 --> Output Class Initialized
INFO - 2018-05-10 14:26:56 --> Security Class Initialized
DEBUG - 2018-05-10 14:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 14:26:56 --> Input Class Initialized
INFO - 2018-05-10 14:26:56 --> Language Class Initialized
INFO - 2018-05-10 14:26:56 --> Language Class Initialized
INFO - 2018-05-10 14:26:56 --> Config Class Initialized
INFO - 2018-05-10 14:26:56 --> Loader Class Initialized
INFO - 2018-05-10 19:56:56 --> Helper loaded: url_helper
INFO - 2018-05-10 19:56:56 --> Helper loaded: notification_helper
INFO - 2018-05-10 19:56:56 --> Helper loaded: settings_helper
INFO - 2018-05-10 19:56:56 --> Helper loaded: permission_helper
INFO - 2018-05-10 19:56:56 --> Helper loaded: users_helper
INFO - 2018-05-10 19:56:56 --> Database Driver Class Initialized
DEBUG - 2018-05-10 19:56:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 19:56:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 19:56:56 --> Helper loaded: form_helper
INFO - 2018-05-10 19:56:56 --> Form Validation Class Initialized
INFO - 2018-05-10 19:56:56 --> Controller Class Initialized
INFO - 2018-05-10 19:56:56 --> Model Class Initialized
INFO - 2018-05-10 19:56:56 --> Helper loaded: inflector_helper
INFO - 2018-05-10 19:56:56 --> Model Class Initialized
DEBUG - 2018-05-10 19:56:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-10 19:56:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-10 19:56:56 --> Model Class Initialized
INFO - 2018-05-10 19:56:56 --> Model Class Initialized
INFO - 2018-05-10 19:56:56 --> Model Class Initialized
INFO - 2018-05-10 19:56:56 --> Model Class Initialized
INFO - 2018-05-10 19:56:56 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-10 19:56:56 --> Model Class Initialized
INFO - 2018-05-10 19:56:56 --> Final output sent to browser
DEBUG - 2018-05-10 19:56:56 --> Total execution time: 0.1107
INFO - 2018-05-10 14:26:57 --> Config Class Initialized
INFO - 2018-05-10 14:26:57 --> Hooks Class Initialized
DEBUG - 2018-05-10 14:26:57 --> UTF-8 Support Enabled
INFO - 2018-05-10 14:26:57 --> Utf8 Class Initialized
INFO - 2018-05-10 14:26:57 --> URI Class Initialized
INFO - 2018-05-10 14:26:57 --> Router Class Initialized
INFO - 2018-05-10 14:26:57 --> Output Class Initialized
INFO - 2018-05-10 14:26:57 --> Security Class Initialized
DEBUG - 2018-05-10 14:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-10 14:26:57 --> Input Class Initialized
INFO - 2018-05-10 14:26:57 --> Language Class Initialized
INFO - 2018-05-10 14:26:57 --> Language Class Initialized
INFO - 2018-05-10 14:26:57 --> Config Class Initialized
INFO - 2018-05-10 14:26:57 --> Loader Class Initialized
INFO - 2018-05-10 19:56:57 --> Helper loaded: url_helper
INFO - 2018-05-10 19:56:57 --> Helper loaded: notification_helper
INFO - 2018-05-10 19:56:57 --> Helper loaded: settings_helper
INFO - 2018-05-10 19:56:57 --> Helper loaded: permission_helper
INFO - 2018-05-10 19:56:57 --> Helper loaded: users_helper
INFO - 2018-05-10 19:56:57 --> Database Driver Class Initialized
DEBUG - 2018-05-10 19:56:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-10 19:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-10 19:56:57 --> Helper loaded: form_helper
INFO - 2018-05-10 19:56:57 --> Form Validation Class Initialized
INFO - 2018-05-10 19:56:57 --> Controller Class Initialized
DEBUG - 2018-05-10 19:56:57 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-05-10 19:56:57 --> Final output sent to browser
DEBUG - 2018-05-10 19:56:57 --> Total execution time: 0.0714
