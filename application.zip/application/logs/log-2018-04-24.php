<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-04-24 11:08:30 --> Config Class Initialized
INFO - 2018-04-24 11:08:30 --> Hooks Class Initialized
DEBUG - 2018-04-24 11:08:30 --> UTF-8 Support Enabled
INFO - 2018-04-24 11:08:30 --> Utf8 Class Initialized
INFO - 2018-04-24 11:08:30 --> URI Class Initialized
INFO - 2018-04-24 11:08:30 --> Router Class Initialized
INFO - 2018-04-24 11:08:30 --> Output Class Initialized
INFO - 2018-04-24 11:08:30 --> Security Class Initialized
DEBUG - 2018-04-24 11:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-24 11:08:30 --> Input Class Initialized
INFO - 2018-04-24 11:08:30 --> Language Class Initialized
INFO - 2018-04-24 11:08:30 --> Language Class Initialized
INFO - 2018-04-24 11:08:30 --> Config Class Initialized
INFO - 2018-04-24 11:08:30 --> Loader Class Initialized
INFO - 2018-04-24 16:38:30 --> Helper loaded: url_helper
INFO - 2018-04-24 16:38:30 --> Helper loaded: notification_helper
INFO - 2018-04-24 16:38:30 --> Helper loaded: settings_helper
INFO - 2018-04-24 16:38:30 --> Helper loaded: permission_helper
INFO - 2018-04-24 16:38:30 --> Helper loaded: users_helper
INFO - 2018-04-24 16:38:30 --> Database Driver Class Initialized
DEBUG - 2018-04-24 16:38:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-24 16:38:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-24 16:38:30 --> Helper loaded: form_helper
INFO - 2018-04-24 16:38:30 --> Form Validation Class Initialized
INFO - 2018-04-24 16:38:30 --> Controller Class Initialized
DEBUG - 2018-04-24 16:38:30 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-04-24 16:38:30 --> Final output sent to browser
DEBUG - 2018-04-24 16:38:30 --> Total execution time: 0.2652
INFO - 2018-04-24 11:09:13 --> Config Class Initialized
INFO - 2018-04-24 11:09:13 --> Hooks Class Initialized
DEBUG - 2018-04-24 11:09:13 --> UTF-8 Support Enabled
INFO - 2018-04-24 11:09:13 --> Utf8 Class Initialized
INFO - 2018-04-24 11:09:13 --> URI Class Initialized
INFO - 2018-04-24 11:09:13 --> Router Class Initialized
INFO - 2018-04-24 11:09:13 --> Output Class Initialized
INFO - 2018-04-24 11:09:13 --> Security Class Initialized
DEBUG - 2018-04-24 11:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-24 11:09:13 --> Input Class Initialized
INFO - 2018-04-24 11:09:13 --> Language Class Initialized
INFO - 2018-04-24 11:09:13 --> Language Class Initialized
INFO - 2018-04-24 11:09:13 --> Config Class Initialized
INFO - 2018-04-24 11:09:13 --> Loader Class Initialized
INFO - 2018-04-24 16:39:13 --> Helper loaded: url_helper
INFO - 2018-04-24 16:39:13 --> Helper loaded: notification_helper
INFO - 2018-04-24 16:39:13 --> Helper loaded: settings_helper
INFO - 2018-04-24 16:39:13 --> Helper loaded: permission_helper
INFO - 2018-04-24 16:39:13 --> Helper loaded: users_helper
INFO - 2018-04-24 16:39:13 --> Database Driver Class Initialized
DEBUG - 2018-04-24 16:39:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-24 16:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-24 16:39:13 --> Helper loaded: form_helper
INFO - 2018-04-24 16:39:13 --> Form Validation Class Initialized
INFO - 2018-04-24 16:39:13 --> Controller Class Initialized
DEBUG - 2018-04-24 16:39:13 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-04-24 16:39:13 --> Final output sent to browser
DEBUG - 2018-04-24 16:39:13 --> Total execution time: 0.0681
INFO - 2018-04-24 11:09:40 --> Config Class Initialized
INFO - 2018-04-24 11:09:40 --> Hooks Class Initialized
DEBUG - 2018-04-24 11:09:40 --> UTF-8 Support Enabled
INFO - 2018-04-24 11:09:40 --> Utf8 Class Initialized
INFO - 2018-04-24 11:09:40 --> URI Class Initialized
INFO - 2018-04-24 11:09:40 --> Router Class Initialized
INFO - 2018-04-24 11:09:40 --> Output Class Initialized
INFO - 2018-04-24 11:09:40 --> Security Class Initialized
DEBUG - 2018-04-24 11:09:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-24 11:09:40 --> Input Class Initialized
INFO - 2018-04-24 11:09:40 --> Language Class Initialized
INFO - 2018-04-24 11:09:40 --> Language Class Initialized
INFO - 2018-04-24 11:09:40 --> Config Class Initialized
INFO - 2018-04-24 11:09:40 --> Loader Class Initialized
INFO - 2018-04-24 16:39:40 --> Helper loaded: url_helper
INFO - 2018-04-24 16:39:40 --> Helper loaded: notification_helper
INFO - 2018-04-24 16:39:40 --> Helper loaded: settings_helper
INFO - 2018-04-24 16:39:40 --> Helper loaded: permission_helper
INFO - 2018-04-24 16:39:40 --> Helper loaded: users_helper
INFO - 2018-04-24 16:39:40 --> Database Driver Class Initialized
DEBUG - 2018-04-24 16:39:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-24 16:39:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-24 16:39:40 --> Helper loaded: form_helper
INFO - 2018-04-24 16:39:40 --> Form Validation Class Initialized
INFO - 2018-04-24 16:39:40 --> Controller Class Initialized
DEBUG - 2018-04-24 16:39:40 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-04-24 16:39:40 --> Final output sent to browser
DEBUG - 2018-04-24 16:39:40 --> Total execution time: 0.0730
INFO - 2018-04-24 11:10:40 --> Config Class Initialized
INFO - 2018-04-24 11:10:40 --> Hooks Class Initialized
DEBUG - 2018-04-24 11:10:40 --> UTF-8 Support Enabled
INFO - 2018-04-24 11:10:40 --> Utf8 Class Initialized
INFO - 2018-04-24 11:10:40 --> URI Class Initialized
INFO - 2018-04-24 11:10:40 --> Router Class Initialized
INFO - 2018-04-24 11:10:40 --> Output Class Initialized
INFO - 2018-04-24 11:10:40 --> Security Class Initialized
DEBUG - 2018-04-24 11:10:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-24 11:10:40 --> Input Class Initialized
INFO - 2018-04-24 11:10:40 --> Language Class Initialized
INFO - 2018-04-24 11:10:40 --> Language Class Initialized
INFO - 2018-04-24 11:10:40 --> Config Class Initialized
INFO - 2018-04-24 11:10:40 --> Loader Class Initialized
INFO - 2018-04-24 16:40:40 --> Helper loaded: url_helper
INFO - 2018-04-24 16:40:40 --> Helper loaded: notification_helper
INFO - 2018-04-24 16:40:40 --> Helper loaded: settings_helper
INFO - 2018-04-24 16:40:40 --> Helper loaded: permission_helper
INFO - 2018-04-24 16:40:40 --> Helper loaded: users_helper
INFO - 2018-04-24 16:40:40 --> Database Driver Class Initialized
DEBUG - 2018-04-24 16:40:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-24 16:40:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-24 16:40:40 --> Helper loaded: form_helper
INFO - 2018-04-24 16:40:40 --> Form Validation Class Initialized
INFO - 2018-04-24 16:40:40 --> Controller Class Initialized
DEBUG - 2018-04-24 16:40:40 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-04-24 16:40:40 --> Final output sent to browser
DEBUG - 2018-04-24 16:40:40 --> Total execution time: 0.0749
INFO - 2018-04-24 11:12:51 --> Config Class Initialized
INFO - 2018-04-24 11:12:51 --> Hooks Class Initialized
DEBUG - 2018-04-24 11:12:51 --> UTF-8 Support Enabled
INFO - 2018-04-24 11:12:51 --> Utf8 Class Initialized
INFO - 2018-04-24 11:12:51 --> URI Class Initialized
INFO - 2018-04-24 11:12:51 --> Router Class Initialized
INFO - 2018-04-24 11:12:51 --> Output Class Initialized
INFO - 2018-04-24 11:12:51 --> Security Class Initialized
DEBUG - 2018-04-24 11:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-24 11:12:51 --> Input Class Initialized
INFO - 2018-04-24 11:12:51 --> Language Class Initialized
INFO - 2018-04-24 11:12:51 --> Language Class Initialized
INFO - 2018-04-24 11:12:51 --> Config Class Initialized
INFO - 2018-04-24 11:12:51 --> Loader Class Initialized
INFO - 2018-04-24 16:42:51 --> Helper loaded: url_helper
INFO - 2018-04-24 16:42:51 --> Helper loaded: notification_helper
INFO - 2018-04-24 16:42:51 --> Helper loaded: settings_helper
INFO - 2018-04-24 16:42:51 --> Helper loaded: permission_helper
INFO - 2018-04-24 16:42:51 --> Helper loaded: users_helper
INFO - 2018-04-24 16:42:51 --> Database Driver Class Initialized
DEBUG - 2018-04-24 16:42:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-24 16:42:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-24 16:42:51 --> Helper loaded: form_helper
INFO - 2018-04-24 16:42:51 --> Form Validation Class Initialized
INFO - 2018-04-24 16:42:51 --> Controller Class Initialized
DEBUG - 2018-04-24 16:42:51 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-04-24 16:42:51 --> Final output sent to browser
DEBUG - 2018-04-24 16:42:51 --> Total execution time: 0.1021
INFO - 2018-04-24 11:13:04 --> Config Class Initialized
INFO - 2018-04-24 11:13:04 --> Hooks Class Initialized
DEBUG - 2018-04-24 11:13:04 --> UTF-8 Support Enabled
INFO - 2018-04-24 11:13:04 --> Utf8 Class Initialized
INFO - 2018-04-24 11:13:04 --> URI Class Initialized
DEBUG - 2018-04-24 11:13:04 --> No URI present. Default controller set.
INFO - 2018-04-24 11:13:04 --> Router Class Initialized
INFO - 2018-04-24 11:13:04 --> Output Class Initialized
INFO - 2018-04-24 11:13:04 --> Security Class Initialized
DEBUG - 2018-04-24 11:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-24 11:13:04 --> Input Class Initialized
INFO - 2018-04-24 11:13:04 --> Language Class Initialized
INFO - 2018-04-24 11:13:04 --> Language Class Initialized
INFO - 2018-04-24 11:13:04 --> Config Class Initialized
INFO - 2018-04-24 11:13:04 --> Loader Class Initialized
INFO - 2018-04-24 16:43:04 --> Helper loaded: url_helper
INFO - 2018-04-24 16:43:04 --> Helper loaded: notification_helper
INFO - 2018-04-24 16:43:04 --> Helper loaded: settings_helper
INFO - 2018-04-24 16:43:04 --> Helper loaded: permission_helper
INFO - 2018-04-24 16:43:04 --> Helper loaded: users_helper
INFO - 2018-04-24 16:43:04 --> Database Driver Class Initialized
DEBUG - 2018-04-24 16:43:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-24 16:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-24 16:43:04 --> Helper loaded: form_helper
INFO - 2018-04-24 16:43:04 --> Form Validation Class Initialized
INFO - 2018-04-24 16:43:04 --> Controller Class Initialized
INFO - 2018-04-24 16:43:04 --> Model Class Initialized
INFO - 2018-04-24 16:43:04 --> Helper loaded: inflector_helper
INFO - 2018-04-24 16:43:04 --> Model Class Initialized
DEBUG - 2018-04-24 16:43:04 --> File loaded: /home/pr01004/public_html/application/views/login.php
INFO - 2018-04-24 16:43:04 --> Final output sent to browser
DEBUG - 2018-04-24 16:43:04 --> Total execution time: 0.2251
INFO - 2018-04-24 11:13:14 --> Config Class Initialized
INFO - 2018-04-24 11:13:14 --> Hooks Class Initialized
DEBUG - 2018-04-24 11:13:14 --> UTF-8 Support Enabled
INFO - 2018-04-24 11:13:14 --> Utf8 Class Initialized
INFO - 2018-04-24 11:13:14 --> URI Class Initialized
INFO - 2018-04-24 11:13:14 --> Router Class Initialized
INFO - 2018-04-24 11:13:14 --> Output Class Initialized
INFO - 2018-04-24 11:13:14 --> Security Class Initialized
DEBUG - 2018-04-24 11:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-24 11:13:14 --> Input Class Initialized
INFO - 2018-04-24 11:13:14 --> Language Class Initialized
INFO - 2018-04-24 11:13:14 --> Language Class Initialized
INFO - 2018-04-24 11:13:14 --> Config Class Initialized
INFO - 2018-04-24 11:13:14 --> Loader Class Initialized
INFO - 2018-04-24 16:43:14 --> Helper loaded: url_helper
INFO - 2018-04-24 16:43:14 --> Helper loaded: notification_helper
INFO - 2018-04-24 16:43:14 --> Helper loaded: settings_helper
INFO - 2018-04-24 16:43:14 --> Helper loaded: permission_helper
INFO - 2018-04-24 16:43:14 --> Helper loaded: users_helper
INFO - 2018-04-24 16:43:14 --> Database Driver Class Initialized
DEBUG - 2018-04-24 16:43:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-24 16:43:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-24 16:43:14 --> Helper loaded: form_helper
INFO - 2018-04-24 16:43:14 --> Form Validation Class Initialized
INFO - 2018-04-24 16:43:14 --> Controller Class Initialized
DEBUG - 2018-04-24 16:43:14 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-04-24 16:43:14 --> Final output sent to browser
DEBUG - 2018-04-24 16:43:14 --> Total execution time: 0.0673
INFO - 2018-04-24 11:18:20 --> Config Class Initialized
INFO - 2018-04-24 11:18:20 --> Hooks Class Initialized
DEBUG - 2018-04-24 11:18:20 --> UTF-8 Support Enabled
INFO - 2018-04-24 11:18:20 --> Utf8 Class Initialized
INFO - 2018-04-24 11:18:20 --> URI Class Initialized
INFO - 2018-04-24 11:18:20 --> Router Class Initialized
INFO - 2018-04-24 11:18:20 --> Output Class Initialized
INFO - 2018-04-24 11:18:20 --> Security Class Initialized
DEBUG - 2018-04-24 11:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-24 11:18:20 --> Input Class Initialized
INFO - 2018-04-24 11:18:20 --> Language Class Initialized
INFO - 2018-04-24 11:18:20 --> Language Class Initialized
INFO - 2018-04-24 11:18:20 --> Config Class Initialized
INFO - 2018-04-24 11:18:20 --> Loader Class Initialized
INFO - 2018-04-24 16:48:20 --> Helper loaded: url_helper
INFO - 2018-04-24 16:48:20 --> Helper loaded: notification_helper
INFO - 2018-04-24 16:48:20 --> Helper loaded: settings_helper
INFO - 2018-04-24 16:48:20 --> Helper loaded: permission_helper
INFO - 2018-04-24 16:48:20 --> Helper loaded: users_helper
INFO - 2018-04-24 16:48:20 --> Database Driver Class Initialized
DEBUG - 2018-04-24 16:48:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-24 16:48:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-24 16:48:20 --> Helper loaded: form_helper
INFO - 2018-04-24 16:48:20 --> Form Validation Class Initialized
INFO - 2018-04-24 16:48:20 --> Controller Class Initialized
DEBUG - 2018-04-24 16:48:20 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-04-24 16:48:20 --> Final output sent to browser
DEBUG - 2018-04-24 16:48:20 --> Total execution time: 0.0681
INFO - 2018-04-24 11:18:49 --> Config Class Initialized
INFO - 2018-04-24 11:18:49 --> Hooks Class Initialized
DEBUG - 2018-04-24 11:18:49 --> UTF-8 Support Enabled
INFO - 2018-04-24 11:18:49 --> Utf8 Class Initialized
INFO - 2018-04-24 11:18:49 --> URI Class Initialized
INFO - 2018-04-24 11:18:49 --> Router Class Initialized
INFO - 2018-04-24 11:18:49 --> Output Class Initialized
INFO - 2018-04-24 11:18:49 --> Security Class Initialized
DEBUG - 2018-04-24 11:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-24 11:18:49 --> Input Class Initialized
INFO - 2018-04-24 11:18:49 --> Language Class Initialized
INFO - 2018-04-24 11:18:49 --> Language Class Initialized
INFO - 2018-04-24 11:18:49 --> Config Class Initialized
INFO - 2018-04-24 11:18:49 --> Loader Class Initialized
INFO - 2018-04-24 16:48:49 --> Helper loaded: url_helper
INFO - 2018-04-24 16:48:49 --> Helper loaded: notification_helper
INFO - 2018-04-24 16:48:49 --> Helper loaded: settings_helper
INFO - 2018-04-24 16:48:49 --> Helper loaded: permission_helper
INFO - 2018-04-24 16:48:49 --> Helper loaded: users_helper
INFO - 2018-04-24 16:48:49 --> Database Driver Class Initialized
DEBUG - 2018-04-24 16:48:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-24 16:48:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-24 16:48:49 --> Helper loaded: form_helper
INFO - 2018-04-24 16:48:49 --> Form Validation Class Initialized
INFO - 2018-04-24 16:48:49 --> Controller Class Initialized
DEBUG - 2018-04-24 16:48:49 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-04-24 16:48:49 --> Final output sent to browser
DEBUG - 2018-04-24 16:48:49 --> Total execution time: 0.0733
INFO - 2018-04-24 11:19:09 --> Config Class Initialized
INFO - 2018-04-24 11:19:09 --> Hooks Class Initialized
DEBUG - 2018-04-24 11:19:09 --> UTF-8 Support Enabled
INFO - 2018-04-24 11:19:09 --> Utf8 Class Initialized
INFO - 2018-04-24 11:19:09 --> URI Class Initialized
INFO - 2018-04-24 11:19:09 --> Router Class Initialized
INFO - 2018-04-24 11:19:09 --> Output Class Initialized
INFO - 2018-04-24 11:19:09 --> Security Class Initialized
DEBUG - 2018-04-24 11:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-24 11:19:09 --> Input Class Initialized
INFO - 2018-04-24 11:19:09 --> Language Class Initialized
INFO - 2018-04-24 11:19:09 --> Language Class Initialized
INFO - 2018-04-24 11:19:09 --> Config Class Initialized
INFO - 2018-04-24 11:19:09 --> Loader Class Initialized
INFO - 2018-04-24 16:49:09 --> Helper loaded: url_helper
INFO - 2018-04-24 16:49:09 --> Helper loaded: notification_helper
INFO - 2018-04-24 16:49:09 --> Helper loaded: settings_helper
INFO - 2018-04-24 16:49:09 --> Helper loaded: permission_helper
INFO - 2018-04-24 16:49:09 --> Helper loaded: users_helper
INFO - 2018-04-24 16:49:09 --> Database Driver Class Initialized
DEBUG - 2018-04-24 16:49:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-24 16:49:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-24 16:49:09 --> Helper loaded: form_helper
INFO - 2018-04-24 16:49:09 --> Form Validation Class Initialized
INFO - 2018-04-24 16:49:09 --> Controller Class Initialized
DEBUG - 2018-04-24 16:49:09 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-04-24 16:49:09 --> Final output sent to browser
DEBUG - 2018-04-24 16:49:09 --> Total execution time: 0.0741
INFO - 2018-04-24 11:24:32 --> Config Class Initialized
INFO - 2018-04-24 11:24:32 --> Hooks Class Initialized
DEBUG - 2018-04-24 11:24:32 --> UTF-8 Support Enabled
INFO - 2018-04-24 11:24:32 --> Utf8 Class Initialized
INFO - 2018-04-24 11:24:32 --> URI Class Initialized
INFO - 2018-04-24 11:24:32 --> Router Class Initialized
INFO - 2018-04-24 11:24:32 --> Output Class Initialized
INFO - 2018-04-24 11:24:32 --> Security Class Initialized
DEBUG - 2018-04-24 11:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-24 11:24:32 --> Input Class Initialized
INFO - 2018-04-24 11:24:32 --> Language Class Initialized
INFO - 2018-04-24 11:24:32 --> Language Class Initialized
INFO - 2018-04-24 11:24:32 --> Config Class Initialized
INFO - 2018-04-24 11:24:32 --> Loader Class Initialized
INFO - 2018-04-24 16:54:32 --> Helper loaded: url_helper
INFO - 2018-04-24 16:54:32 --> Helper loaded: notification_helper
INFO - 2018-04-24 16:54:32 --> Helper loaded: settings_helper
INFO - 2018-04-24 16:54:32 --> Helper loaded: permission_helper
INFO - 2018-04-24 16:54:32 --> Helper loaded: users_helper
INFO - 2018-04-24 16:54:32 --> Database Driver Class Initialized
DEBUG - 2018-04-24 16:54:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-24 16:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-24 16:54:32 --> Helper loaded: form_helper
INFO - 2018-04-24 16:54:32 --> Form Validation Class Initialized
INFO - 2018-04-24 16:54:32 --> Controller Class Initialized
DEBUG - 2018-04-24 16:54:32 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-04-24 16:54:32 --> Final output sent to browser
DEBUG - 2018-04-24 16:54:32 --> Total execution time: 0.0485
INFO - 2018-04-24 11:24:35 --> Config Class Initialized
INFO - 2018-04-24 11:24:35 --> Hooks Class Initialized
DEBUG - 2018-04-24 11:24:35 --> UTF-8 Support Enabled
INFO - 2018-04-24 11:24:35 --> Utf8 Class Initialized
INFO - 2018-04-24 11:24:35 --> URI Class Initialized
INFO - 2018-04-24 11:24:35 --> Router Class Initialized
INFO - 2018-04-24 11:24:35 --> Output Class Initialized
INFO - 2018-04-24 11:24:35 --> Security Class Initialized
DEBUG - 2018-04-24 11:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-24 11:24:35 --> Input Class Initialized
INFO - 2018-04-24 11:24:35 --> Language Class Initialized
INFO - 2018-04-24 11:24:35 --> Language Class Initialized
INFO - 2018-04-24 11:24:35 --> Config Class Initialized
INFO - 2018-04-24 11:24:35 --> Loader Class Initialized
INFO - 2018-04-24 16:54:35 --> Helper loaded: url_helper
INFO - 2018-04-24 16:54:35 --> Helper loaded: notification_helper
INFO - 2018-04-24 16:54:35 --> Helper loaded: settings_helper
INFO - 2018-04-24 16:54:35 --> Helper loaded: permission_helper
INFO - 2018-04-24 16:54:35 --> Helper loaded: users_helper
INFO - 2018-04-24 16:54:35 --> Database Driver Class Initialized
DEBUG - 2018-04-24 16:54:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-24 16:54:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-24 16:54:35 --> Helper loaded: form_helper
INFO - 2018-04-24 16:54:35 --> Form Validation Class Initialized
INFO - 2018-04-24 16:54:35 --> Controller Class Initialized
DEBUG - 2018-04-24 16:54:35 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-04-24 16:54:35 --> Final output sent to browser
DEBUG - 2018-04-24 16:54:35 --> Total execution time: 0.0658
INFO - 2018-04-24 11:24:35 --> Config Class Initialized
INFO - 2018-04-24 11:24:35 --> Hooks Class Initialized
DEBUG - 2018-04-24 11:24:35 --> UTF-8 Support Enabled
INFO - 2018-04-24 11:24:35 --> Utf8 Class Initialized
INFO - 2018-04-24 11:24:35 --> URI Class Initialized
INFO - 2018-04-24 11:24:35 --> Router Class Initialized
INFO - 2018-04-24 11:24:35 --> Output Class Initialized
INFO - 2018-04-24 11:24:35 --> Security Class Initialized
DEBUG - 2018-04-24 11:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-24 11:24:35 --> Input Class Initialized
INFO - 2018-04-24 11:24:35 --> Language Class Initialized
INFO - 2018-04-24 11:24:35 --> Language Class Initialized
INFO - 2018-04-24 11:24:35 --> Config Class Initialized
INFO - 2018-04-24 11:24:35 --> Loader Class Initialized
INFO - 2018-04-24 16:54:35 --> Helper loaded: url_helper
INFO - 2018-04-24 16:54:35 --> Helper loaded: notification_helper
INFO - 2018-04-24 16:54:35 --> Helper loaded: settings_helper
INFO - 2018-04-24 16:54:35 --> Helper loaded: permission_helper
INFO - 2018-04-24 16:54:35 --> Helper loaded: users_helper
INFO - 2018-04-24 16:54:35 --> Database Driver Class Initialized
DEBUG - 2018-04-24 16:54:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-24 16:54:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-24 16:54:35 --> Helper loaded: form_helper
INFO - 2018-04-24 16:54:35 --> Form Validation Class Initialized
INFO - 2018-04-24 16:54:35 --> Controller Class Initialized
DEBUG - 2018-04-24 16:54:35 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-04-24 16:54:35 --> Final output sent to browser
DEBUG - 2018-04-24 16:54:35 --> Total execution time: 0.0745
INFO - 2018-04-24 11:24:36 --> Config Class Initialized
INFO - 2018-04-24 11:24:36 --> Hooks Class Initialized
DEBUG - 2018-04-24 11:24:36 --> UTF-8 Support Enabled
INFO - 2018-04-24 11:24:36 --> Utf8 Class Initialized
INFO - 2018-04-24 11:24:36 --> URI Class Initialized
INFO - 2018-04-24 11:24:36 --> Router Class Initialized
INFO - 2018-04-24 11:24:36 --> Output Class Initialized
INFO - 2018-04-24 11:24:36 --> Security Class Initialized
DEBUG - 2018-04-24 11:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-24 11:24:36 --> Input Class Initialized
INFO - 2018-04-24 11:24:36 --> Language Class Initialized
INFO - 2018-04-24 11:24:36 --> Language Class Initialized
INFO - 2018-04-24 11:24:36 --> Config Class Initialized
INFO - 2018-04-24 11:24:36 --> Loader Class Initialized
INFO - 2018-04-24 16:54:36 --> Helper loaded: url_helper
INFO - 2018-04-24 16:54:36 --> Helper loaded: notification_helper
INFO - 2018-04-24 16:54:36 --> Helper loaded: settings_helper
INFO - 2018-04-24 16:54:36 --> Helper loaded: permission_helper
INFO - 2018-04-24 16:54:36 --> Helper loaded: users_helper
INFO - 2018-04-24 16:54:36 --> Database Driver Class Initialized
DEBUG - 2018-04-24 16:54:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-24 16:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-24 16:54:36 --> Helper loaded: form_helper
INFO - 2018-04-24 16:54:36 --> Form Validation Class Initialized
INFO - 2018-04-24 16:54:36 --> Controller Class Initialized
DEBUG - 2018-04-24 16:54:36 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-04-24 16:54:36 --> Final output sent to browser
DEBUG - 2018-04-24 16:54:36 --> Total execution time: 0.0809
INFO - 2018-04-24 11:25:11 --> Config Class Initialized
INFO - 2018-04-24 11:25:11 --> Hooks Class Initialized
DEBUG - 2018-04-24 11:25:11 --> UTF-8 Support Enabled
INFO - 2018-04-24 11:25:11 --> Utf8 Class Initialized
INFO - 2018-04-24 11:25:11 --> URI Class Initialized
INFO - 2018-04-24 11:25:11 --> Router Class Initialized
INFO - 2018-04-24 11:25:11 --> Output Class Initialized
INFO - 2018-04-24 11:25:11 --> Security Class Initialized
DEBUG - 2018-04-24 11:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-24 11:25:11 --> Input Class Initialized
INFO - 2018-04-24 11:25:11 --> Language Class Initialized
INFO - 2018-04-24 11:25:11 --> Language Class Initialized
INFO - 2018-04-24 11:25:11 --> Config Class Initialized
INFO - 2018-04-24 11:25:11 --> Loader Class Initialized
INFO - 2018-04-24 16:55:11 --> Helper loaded: url_helper
INFO - 2018-04-24 16:55:11 --> Helper loaded: notification_helper
INFO - 2018-04-24 16:55:11 --> Helper loaded: settings_helper
INFO - 2018-04-24 16:55:11 --> Helper loaded: permission_helper
INFO - 2018-04-24 16:55:11 --> Helper loaded: users_helper
INFO - 2018-04-24 16:55:11 --> Database Driver Class Initialized
DEBUG - 2018-04-24 16:55:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-24 16:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-24 16:55:11 --> Helper loaded: form_helper
INFO - 2018-04-24 16:55:11 --> Form Validation Class Initialized
INFO - 2018-04-24 16:55:11 --> Controller Class Initialized
DEBUG - 2018-04-24 16:55:11 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-04-24 16:55:11 --> Final output sent to browser
DEBUG - 2018-04-24 16:55:11 --> Total execution time: 0.0868
INFO - 2018-04-24 11:25:16 --> Config Class Initialized
INFO - 2018-04-24 11:25:16 --> Hooks Class Initialized
DEBUG - 2018-04-24 11:25:16 --> UTF-8 Support Enabled
INFO - 2018-04-24 11:25:16 --> Utf8 Class Initialized
INFO - 2018-04-24 11:25:16 --> URI Class Initialized
INFO - 2018-04-24 11:25:16 --> Router Class Initialized
INFO - 2018-04-24 11:25:16 --> Output Class Initialized
INFO - 2018-04-24 11:25:16 --> Security Class Initialized
DEBUG - 2018-04-24 11:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-24 11:25:16 --> Input Class Initialized
INFO - 2018-04-24 11:25:16 --> Language Class Initialized
INFO - 2018-04-24 11:25:16 --> Language Class Initialized
INFO - 2018-04-24 11:25:16 --> Config Class Initialized
INFO - 2018-04-24 11:25:16 --> Loader Class Initialized
INFO - 2018-04-24 16:55:16 --> Helper loaded: url_helper
INFO - 2018-04-24 16:55:16 --> Helper loaded: notification_helper
INFO - 2018-04-24 16:55:16 --> Helper loaded: settings_helper
INFO - 2018-04-24 16:55:16 --> Helper loaded: permission_helper
INFO - 2018-04-24 16:55:16 --> Helper loaded: users_helper
INFO - 2018-04-24 16:55:16 --> Database Driver Class Initialized
DEBUG - 2018-04-24 16:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-24 16:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-24 16:55:16 --> Helper loaded: form_helper
INFO - 2018-04-24 16:55:16 --> Form Validation Class Initialized
INFO - 2018-04-24 16:55:16 --> Controller Class Initialized
DEBUG - 2018-04-24 16:55:16 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-04-24 16:55:16 --> Final output sent to browser
DEBUG - 2018-04-24 16:55:16 --> Total execution time: 0.0747
INFO - 2018-04-24 11:25:18 --> Config Class Initialized
INFO - 2018-04-24 11:25:18 --> Hooks Class Initialized
DEBUG - 2018-04-24 11:25:18 --> UTF-8 Support Enabled
INFO - 2018-04-24 11:25:18 --> Utf8 Class Initialized
INFO - 2018-04-24 11:25:18 --> URI Class Initialized
INFO - 2018-04-24 11:25:18 --> Router Class Initialized
INFO - 2018-04-24 11:25:18 --> Output Class Initialized
INFO - 2018-04-24 11:25:18 --> Security Class Initialized
DEBUG - 2018-04-24 11:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-24 11:25:18 --> Input Class Initialized
INFO - 2018-04-24 11:25:18 --> Language Class Initialized
INFO - 2018-04-24 11:25:18 --> Language Class Initialized
INFO - 2018-04-24 11:25:18 --> Config Class Initialized
INFO - 2018-04-24 11:25:18 --> Loader Class Initialized
INFO - 2018-04-24 16:55:18 --> Helper loaded: url_helper
INFO - 2018-04-24 16:55:18 --> Helper loaded: notification_helper
INFO - 2018-04-24 16:55:18 --> Helper loaded: settings_helper
INFO - 2018-04-24 16:55:18 --> Helper loaded: permission_helper
INFO - 2018-04-24 16:55:18 --> Helper loaded: users_helper
INFO - 2018-04-24 16:55:18 --> Database Driver Class Initialized
DEBUG - 2018-04-24 16:55:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-24 16:55:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-24 16:55:18 --> Helper loaded: form_helper
INFO - 2018-04-24 16:55:18 --> Form Validation Class Initialized
INFO - 2018-04-24 16:55:18 --> Controller Class Initialized
DEBUG - 2018-04-24 16:55:18 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-04-24 16:55:18 --> Final output sent to browser
DEBUG - 2018-04-24 16:55:18 --> Total execution time: 0.0890
INFO - 2018-04-24 11:25:20 --> Config Class Initialized
INFO - 2018-04-24 11:25:20 --> Hooks Class Initialized
DEBUG - 2018-04-24 11:25:20 --> UTF-8 Support Enabled
INFO - 2018-04-24 11:25:20 --> Utf8 Class Initialized
INFO - 2018-04-24 11:25:20 --> URI Class Initialized
INFO - 2018-04-24 11:25:20 --> Router Class Initialized
INFO - 2018-04-24 11:25:20 --> Output Class Initialized
INFO - 2018-04-24 11:25:20 --> Security Class Initialized
DEBUG - 2018-04-24 11:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-24 11:25:20 --> Input Class Initialized
INFO - 2018-04-24 11:25:20 --> Language Class Initialized
INFO - 2018-04-24 11:25:20 --> Language Class Initialized
INFO - 2018-04-24 11:25:20 --> Config Class Initialized
INFO - 2018-04-24 11:25:20 --> Loader Class Initialized
INFO - 2018-04-24 16:55:20 --> Helper loaded: url_helper
INFO - 2018-04-24 16:55:20 --> Helper loaded: notification_helper
INFO - 2018-04-24 16:55:20 --> Helper loaded: settings_helper
INFO - 2018-04-24 16:55:20 --> Helper loaded: permission_helper
INFO - 2018-04-24 16:55:20 --> Helper loaded: users_helper
INFO - 2018-04-24 16:55:20 --> Database Driver Class Initialized
DEBUG - 2018-04-24 16:55:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-24 16:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-24 16:55:20 --> Helper loaded: form_helper
INFO - 2018-04-24 16:55:20 --> Form Validation Class Initialized
INFO - 2018-04-24 16:55:20 --> Controller Class Initialized
DEBUG - 2018-04-24 16:55:20 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-04-24 16:55:20 --> Final output sent to browser
DEBUG - 2018-04-24 16:55:20 --> Total execution time: 0.0688
INFO - 2018-04-24 11:30:04 --> Config Class Initialized
INFO - 2018-04-24 11:30:04 --> Hooks Class Initialized
DEBUG - 2018-04-24 11:30:04 --> UTF-8 Support Enabled
INFO - 2018-04-24 11:30:04 --> Utf8 Class Initialized
INFO - 2018-04-24 11:30:04 --> URI Class Initialized
INFO - 2018-04-24 11:30:04 --> Router Class Initialized
INFO - 2018-04-24 11:30:04 --> Output Class Initialized
INFO - 2018-04-24 11:30:04 --> Security Class Initialized
DEBUG - 2018-04-24 11:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-24 11:30:04 --> Input Class Initialized
INFO - 2018-04-24 11:30:04 --> Language Class Initialized
INFO - 2018-04-24 11:30:04 --> Language Class Initialized
INFO - 2018-04-24 11:30:04 --> Config Class Initialized
INFO - 2018-04-24 11:30:04 --> Loader Class Initialized
INFO - 2018-04-24 17:00:04 --> Helper loaded: url_helper
INFO - 2018-04-24 17:00:04 --> Helper loaded: notification_helper
INFO - 2018-04-24 17:00:04 --> Helper loaded: settings_helper
INFO - 2018-04-24 17:00:04 --> Helper loaded: permission_helper
INFO - 2018-04-24 17:00:04 --> Helper loaded: users_helper
INFO - 2018-04-24 17:00:04 --> Database Driver Class Initialized
DEBUG - 2018-04-24 17:00:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-24 17:00:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-24 17:00:04 --> Helper loaded: form_helper
INFO - 2018-04-24 17:00:04 --> Form Validation Class Initialized
INFO - 2018-04-24 17:00:04 --> Controller Class Initialized
DEBUG - 2018-04-24 17:00:04 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-04-24 17:00:04 --> Final output sent to browser
DEBUG - 2018-04-24 17:00:04 --> Total execution time: 0.0957
INFO - 2018-04-24 12:48:03 --> Config Class Initialized
INFO - 2018-04-24 12:48:03 --> Hooks Class Initialized
INFO - 2018-04-24 12:48:03 --> Config Class Initialized
INFO - 2018-04-24 12:48:03 --> Hooks Class Initialized
INFO - 2018-04-24 12:48:03 --> Config Class Initialized
INFO - 2018-04-24 12:48:03 --> Hooks Class Initialized
DEBUG - 2018-04-24 12:48:03 --> UTF-8 Support Enabled
INFO - 2018-04-24 12:48:03 --> Utf8 Class Initialized
DEBUG - 2018-04-24 12:48:03 --> UTF-8 Support Enabled
DEBUG - 2018-04-24 12:48:03 --> UTF-8 Support Enabled
INFO - 2018-04-24 12:48:03 --> Utf8 Class Initialized
INFO - 2018-04-24 12:48:03 --> Utf8 Class Initialized
INFO - 2018-04-24 12:48:03 --> URI Class Initialized
INFO - 2018-04-24 12:48:03 --> URI Class Initialized
INFO - 2018-04-24 12:48:03 --> URI Class Initialized
INFO - 2018-04-24 12:48:03 --> Router Class Initialized
INFO - 2018-04-24 12:48:03 --> Router Class Initialized
INFO - 2018-04-24 12:48:03 --> Router Class Initialized
INFO - 2018-04-24 12:48:03 --> Output Class Initialized
INFO - 2018-04-24 12:48:03 --> Output Class Initialized
INFO - 2018-04-24 12:48:03 --> Output Class Initialized
INFO - 2018-04-24 12:48:03 --> Security Class Initialized
INFO - 2018-04-24 12:48:03 --> Security Class Initialized
INFO - 2018-04-24 12:48:03 --> Security Class Initialized
DEBUG - 2018-04-24 12:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-24 12:48:03 --> Input Class Initialized
DEBUG - 2018-04-24 12:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-24 12:48:03 --> Input Class Initialized
INFO - 2018-04-24 12:48:03 --> Language Class Initialized
INFO - 2018-04-24 12:48:03 --> Language Class Initialized
DEBUG - 2018-04-24 12:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-24 12:48:03 --> Input Class Initialized
INFO - 2018-04-24 12:48:03 --> Language Class Initialized
INFO - 2018-04-24 12:48:03 --> Language Class Initialized
INFO - 2018-04-24 12:48:03 --> Config Class Initialized
INFO - 2018-04-24 12:48:03 --> Loader Class Initialized
INFO - 2018-04-24 12:48:03 --> Language Class Initialized
INFO - 2018-04-24 12:48:03 --> Config Class Initialized
INFO - 2018-04-24 12:48:03 --> Loader Class Initialized
INFO - 2018-04-24 18:18:03 --> Helper loaded: url_helper
INFO - 2018-04-24 18:18:03 --> Helper loaded: url_helper
INFO - 2018-04-24 18:18:03 --> Helper loaded: notification_helper
INFO - 2018-04-24 18:18:03 --> Helper loaded: notification_helper
INFO - 2018-04-24 18:18:03 --> Helper loaded: settings_helper
INFO - 2018-04-24 18:18:03 --> Helper loaded: settings_helper
INFO - 2018-04-24 18:18:03 --> Helper loaded: permission_helper
INFO - 2018-04-24 18:18:03 --> Helper loaded: permission_helper
INFO - 2018-04-24 18:18:03 --> Helper loaded: users_helper
INFO - 2018-04-24 18:18:03 --> Helper loaded: users_helper
INFO - 2018-04-24 12:48:03 --> Language Class Initialized
INFO - 2018-04-24 12:48:03 --> Config Class Initialized
INFO - 2018-04-24 12:48:03 --> Loader Class Initialized
INFO - 2018-04-24 18:18:03 --> Helper loaded: url_helper
INFO - 2018-04-24 18:18:03 --> Helper loaded: notification_helper
INFO - 2018-04-24 18:18:03 --> Helper loaded: settings_helper
INFO - 2018-04-24 18:18:03 --> Helper loaded: permission_helper
INFO - 2018-04-24 18:18:03 --> Database Driver Class Initialized
INFO - 2018-04-24 18:18:03 --> Database Driver Class Initialized
INFO - 2018-04-24 18:18:03 --> Helper loaded: users_helper
DEBUG - 2018-04-24 18:18:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-24 18:18:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-04-24 18:18:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-24 18:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-24 18:18:03 --> Helper loaded: form_helper
INFO - 2018-04-24 18:18:03 --> Form Validation Class Initialized
INFO - 2018-04-24 18:18:03 --> Controller Class Initialized
INFO - 2018-04-24 18:18:03 --> Helper loaded: form_helper
INFO - 2018-04-24 18:18:03 --> Form Validation Class Initialized
INFO - 2018-04-24 18:18:03 --> Controller Class Initialized
INFO - 2018-04-24 18:18:03 --> Database Driver Class Initialized
DEBUG - 2018-04-24 18:18:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-24 18:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-24 18:18:03 --> Model Class Initialized
INFO - 2018-04-24 18:18:03 --> Helper loaded: inflector_helper
INFO - 2018-04-24 18:18:03 --> Helper loaded: form_helper
INFO - 2018-04-24 18:18:03 --> Form Validation Class Initialized
INFO - 2018-04-24 18:18:03 --> Controller Class Initialized
DEBUG - 2018-04-24 18:18:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-24 18:18:03 --> Model Class Initialized
INFO - 2018-04-24 18:18:03 --> Helper loaded: inflector_helper
INFO - 2018-04-24 18:18:03 --> Model Class Initialized
INFO - 2018-04-24 18:18:03 --> Helper loaded: inflector_helper
DEBUG - 2018-04-24 18:18:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-04-24 18:18:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-24 18:18:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-24 18:18:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-24 18:18:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-24 18:18:03 --> Model Class Initialized
INFO - 2018-04-24 18:18:03 --> Model Class Initialized
INFO - 2018-04-24 18:18:03 --> Model Class Initialized
INFO - 2018-04-24 18:18:03 --> Model Class Initialized
INFO - 2018-04-24 18:18:03 --> Model Class Initialized
INFO - 2018-04-24 18:18:03 --> Model Class Initialized
INFO - 2018-04-24 18:18:03 --> Model Class Initialized
INFO - 2018-04-24 18:18:03 --> Model Class Initialized
INFO - 2018-04-24 18:18:03 --> Model Class Initialized
INFO - 2018-04-24 18:18:03 --> Model Class Initialized
INFO - 2018-04-24 18:18:03 --> Model Class Initialized
INFO - 2018-04-24 18:18:03 --> Model Class Initialized
INFO - 2018-04-24 18:18:03 --> Model Class Initialized
INFO - 2018-04-24 18:18:03 --> Model Class Initialized
INFO - 2018-04-24 18:18:03 --> Model Class Initialized
INFO - 2018-04-24 18:18:03 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-24 18:18:03 --> Model Class Initialized
INFO - 2018-04-24 18:18:03 --> Model Class Initialized
INFO - 2018-04-24 18:18:03 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-24 18:18:03 --> Model Class Initialized
INFO - 2018-04-24 18:18:03 --> Model Class Initialized
INFO - 2018-04-24 18:18:03 --> Model Class Initialized
INFO - 2018-04-24 18:18:03 --> Model Class Initialized
INFO - 2018-04-24 18:18:03 --> Model Class Initialized
INFO - 2018-04-24 18:18:03 --> Model Class Initialized
INFO - 2018-04-24 18:18:03 --> Final output sent to browser
DEBUG - 2018-04-24 18:18:03 --> Total execution time: 0.2081
INFO - 2018-04-24 18:18:03 --> Final output sent to browser
DEBUG - 2018-04-24 18:18:03 --> Total execution time: 0.2071
INFO - 2018-04-24 18:18:03 --> Model Class Initialized
INFO - 2018-04-24 18:18:03 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-24 18:18:03 --> Model Class Initialized
INFO - 2018-04-24 18:18:03 --> Final output sent to browser
DEBUG - 2018-04-24 18:18:03 --> Total execution time: 0.2671
INFO - 2018-04-24 12:48:05 --> Config Class Initialized
INFO - 2018-04-24 12:48:05 --> Hooks Class Initialized
DEBUG - 2018-04-24 12:48:05 --> UTF-8 Support Enabled
INFO - 2018-04-24 12:48:05 --> Utf8 Class Initialized
INFO - 2018-04-24 12:48:05 --> URI Class Initialized
INFO - 2018-04-24 12:48:05 --> Router Class Initialized
INFO - 2018-04-24 12:48:05 --> Output Class Initialized
INFO - 2018-04-24 12:48:05 --> Security Class Initialized
DEBUG - 2018-04-24 12:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-24 12:48:05 --> Input Class Initialized
INFO - 2018-04-24 12:48:05 --> Language Class Initialized
INFO - 2018-04-24 12:48:05 --> Language Class Initialized
INFO - 2018-04-24 12:48:05 --> Config Class Initialized
INFO - 2018-04-24 12:48:05 --> Loader Class Initialized
INFO - 2018-04-24 18:18:05 --> Helper loaded: url_helper
INFO - 2018-04-24 18:18:05 --> Helper loaded: notification_helper
INFO - 2018-04-24 18:18:05 --> Helper loaded: settings_helper
INFO - 2018-04-24 18:18:05 --> Helper loaded: permission_helper
INFO - 2018-04-24 18:18:05 --> Helper loaded: users_helper
INFO - 2018-04-24 18:18:05 --> Database Driver Class Initialized
DEBUG - 2018-04-24 18:18:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-24 18:18:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-24 18:18:05 --> Helper loaded: form_helper
INFO - 2018-04-24 18:18:05 --> Form Validation Class Initialized
INFO - 2018-04-24 18:18:05 --> Controller Class Initialized
INFO - 2018-04-24 18:18:05 --> Model Class Initialized
INFO - 2018-04-24 18:18:05 --> Helper loaded: inflector_helper
DEBUG - 2018-04-24 18:18:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-24 18:18:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-24 18:18:05 --> Model Class Initialized
INFO - 2018-04-24 18:18:05 --> Model Class Initialized
INFO - 2018-04-24 18:18:05 --> Model Class Initialized
INFO - 2018-04-24 18:18:05 --> Model Class Initialized
INFO - 2018-04-24 18:18:05 --> Model Class Initialized
INFO - 2018-04-24 18:18:05 --> Model Class Initialized
INFO - 2018-04-24 18:18:05 --> Model Class Initialized
INFO - 2018-04-24 18:18:05 --> Model Class Initialized
INFO - 2018-04-24 18:18:05 --> Model Class Initialized
INFO - 2018-04-24 18:18:05 --> Model Class Initialized
INFO - 2018-04-24 18:18:05 --> Model Class Initialized
INFO - 2018-04-24 18:18:05 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-24 18:18:05 --> Model Class Initialized
INFO - 2018-04-24 18:18:05 --> Final output sent to browser
DEBUG - 2018-04-24 18:18:05 --> Total execution time: 0.1168
INFO - 2018-04-24 12:48:08 --> Config Class Initialized
INFO - 2018-04-24 12:48:08 --> Hooks Class Initialized
DEBUG - 2018-04-24 12:48:08 --> UTF-8 Support Enabled
INFO - 2018-04-24 12:48:08 --> Utf8 Class Initialized
INFO - 2018-04-24 12:48:08 --> URI Class Initialized
INFO - 2018-04-24 12:48:08 --> Router Class Initialized
INFO - 2018-04-24 12:48:08 --> Output Class Initialized
INFO - 2018-04-24 12:48:08 --> Security Class Initialized
DEBUG - 2018-04-24 12:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-24 12:48:08 --> Input Class Initialized
INFO - 2018-04-24 12:48:08 --> Language Class Initialized
INFO - 2018-04-24 12:48:08 --> Language Class Initialized
INFO - 2018-04-24 12:48:08 --> Config Class Initialized
INFO - 2018-04-24 12:48:08 --> Loader Class Initialized
INFO - 2018-04-24 18:18:08 --> Helper loaded: url_helper
INFO - 2018-04-24 18:18:08 --> Helper loaded: notification_helper
INFO - 2018-04-24 18:18:08 --> Helper loaded: settings_helper
INFO - 2018-04-24 18:18:08 --> Helper loaded: permission_helper
INFO - 2018-04-24 18:18:08 --> Helper loaded: users_helper
INFO - 2018-04-24 18:18:08 --> Database Driver Class Initialized
DEBUG - 2018-04-24 18:18:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-24 18:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-24 18:18:08 --> Helper loaded: form_helper
INFO - 2018-04-24 18:18:08 --> Form Validation Class Initialized
INFO - 2018-04-24 18:18:08 --> Controller Class Initialized
INFO - 2018-04-24 18:18:08 --> Model Class Initialized
INFO - 2018-04-24 18:18:08 --> Helper loaded: inflector_helper
DEBUG - 2018-04-24 18:18:08 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-24 18:18:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-24 18:18:08 --> Model Class Initialized
INFO - 2018-04-24 18:18:08 --> Model Class Initialized
INFO - 2018-04-24 18:18:08 --> Model Class Initialized
INFO - 2018-04-24 18:18:08 --> Model Class Initialized
INFO - 2018-04-24 18:18:08 --> Model Class Initialized
INFO - 2018-04-24 18:18:08 --> Model Class Initialized
INFO - 2018-04-24 18:18:08 --> Model Class Initialized
INFO - 2018-04-24 18:18:08 --> Model Class Initialized
INFO - 2018-04-24 18:18:08 --> Model Class Initialized
INFO - 2018-04-24 18:18:08 --> Model Class Initialized
INFO - 2018-04-24 18:18:08 --> Model Class Initialized
INFO - 2018-04-24 18:18:08 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-24 18:18:08 --> Model Class Initialized
INFO - 2018-04-24 18:18:08 --> Final output sent to browser
DEBUG - 2018-04-24 18:18:08 --> Total execution time: 0.1203
INFO - 2018-04-24 12:48:16 --> Config Class Initialized
INFO - 2018-04-24 12:48:16 --> Hooks Class Initialized
DEBUG - 2018-04-24 12:48:16 --> UTF-8 Support Enabled
INFO - 2018-04-24 12:48:16 --> Utf8 Class Initialized
INFO - 2018-04-24 12:48:16 --> URI Class Initialized
INFO - 2018-04-24 12:48:16 --> Router Class Initialized
INFO - 2018-04-24 12:48:16 --> Output Class Initialized
INFO - 2018-04-24 12:48:16 --> Security Class Initialized
DEBUG - 2018-04-24 12:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-24 12:48:16 --> Input Class Initialized
INFO - 2018-04-24 12:48:16 --> Language Class Initialized
INFO - 2018-04-24 12:48:16 --> Language Class Initialized
INFO - 2018-04-24 12:48:16 --> Config Class Initialized
INFO - 2018-04-24 12:48:16 --> Loader Class Initialized
INFO - 2018-04-24 18:18:16 --> Helper loaded: url_helper
INFO - 2018-04-24 18:18:16 --> Helper loaded: notification_helper
INFO - 2018-04-24 18:18:16 --> Helper loaded: settings_helper
INFO - 2018-04-24 18:18:16 --> Helper loaded: permission_helper
INFO - 2018-04-24 18:18:16 --> Helper loaded: users_helper
INFO - 2018-04-24 18:18:16 --> Database Driver Class Initialized
DEBUG - 2018-04-24 18:18:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-24 18:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-24 18:18:16 --> Helper loaded: form_helper
INFO - 2018-04-24 18:18:16 --> Form Validation Class Initialized
INFO - 2018-04-24 18:18:16 --> Controller Class Initialized
INFO - 2018-04-24 18:18:16 --> Model Class Initialized
INFO - 2018-04-24 18:18:16 --> Helper loaded: inflector_helper
DEBUG - 2018-04-24 18:18:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-24 18:18:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-24 18:18:16 --> Model Class Initialized
INFO - 2018-04-24 18:18:16 --> Model Class Initialized
INFO - 2018-04-24 18:18:16 --> Model Class Initialized
INFO - 2018-04-24 18:18:16 --> Model Class Initialized
INFO - 2018-04-24 18:18:16 --> Model Class Initialized
INFO - 2018-04-24 18:18:16 --> Model Class Initialized
INFO - 2018-04-24 18:18:16 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-24 18:18:16 --> Final output sent to browser
DEBUG - 2018-04-24 18:18:16 --> Total execution time: 0.1179
