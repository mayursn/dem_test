<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-03-28 05:44:32 --> Config Class Initialized
INFO - 2018-03-28 05:44:32 --> Hooks Class Initialized
DEBUG - 2018-03-28 05:44:32 --> UTF-8 Support Enabled
INFO - 2018-03-28 05:44:32 --> Utf8 Class Initialized
INFO - 2018-03-28 05:44:32 --> URI Class Initialized
INFO - 2018-03-28 05:44:32 --> Router Class Initialized
INFO - 2018-03-28 05:44:32 --> Output Class Initialized
INFO - 2018-03-28 05:44:32 --> Security Class Initialized
DEBUG - 2018-03-28 05:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 05:44:32 --> Input Class Initialized
INFO - 2018-03-28 05:44:32 --> Language Class Initialized
INFO - 2018-03-28 05:44:32 --> Language Class Initialized
INFO - 2018-03-28 05:44:32 --> Config Class Initialized
INFO - 2018-03-28 05:44:32 --> Loader Class Initialized
INFO - 2018-03-28 11:14:32 --> Helper loaded: url_helper
INFO - 2018-03-28 11:14:32 --> Helper loaded: notification_helper
INFO - 2018-03-28 11:14:32 --> Helper loaded: settings_helper
INFO - 2018-03-28 11:14:32 --> Helper loaded: permission_helper
INFO - 2018-03-28 11:14:32 --> Helper loaded: users_helper
INFO - 2018-03-28 11:14:33 --> Database Driver Class Initialized
DEBUG - 2018-03-28 11:14:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 11:14:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 11:14:33 --> Helper loaded: form_helper
INFO - 2018-03-28 11:14:33 --> Form Validation Class Initialized
INFO - 2018-03-28 11:14:33 --> Controller Class Initialized
INFO - 2018-03-28 11:14:33 --> Model Class Initialized
INFO - 2018-03-28 11:14:33 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 11:14:33 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 11:14:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 11:14:33 --> Model Class Initialized
INFO - 2018-03-28 11:14:33 --> Model Class Initialized
INFO - 2018-03-28 11:14:33 --> Model Class Initialized
INFO - 2018-03-28 11:14:33 --> Model Class Initialized
INFO - 2018-03-28 11:14:33 --> Model Class Initialized
INFO - 2018-03-28 11:14:33 --> Model Class Initialized
INFO - 2018-03-28 11:14:33 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 11:14:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-28 11:14:33 --> Final output sent to browser
DEBUG - 2018-03-28 11:14:33 --> Total execution time: 0.1313
INFO - 2018-03-28 05:44:34 --> Config Class Initialized
INFO - 2018-03-28 05:44:34 --> Hooks Class Initialized
DEBUG - 2018-03-28 05:44:34 --> UTF-8 Support Enabled
INFO - 2018-03-28 05:44:34 --> Utf8 Class Initialized
INFO - 2018-03-28 05:44:34 --> URI Class Initialized
INFO - 2018-03-28 05:44:34 --> Router Class Initialized
INFO - 2018-03-28 05:44:34 --> Output Class Initialized
INFO - 2018-03-28 05:44:34 --> Security Class Initialized
INFO - 2018-03-28 05:44:34 --> Config Class Initialized
INFO - 2018-03-28 05:44:34 --> Hooks Class Initialized
DEBUG - 2018-03-28 05:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 05:44:34 --> Input Class Initialized
INFO - 2018-03-28 05:44:34 --> Language Class Initialized
DEBUG - 2018-03-28 05:44:35 --> UTF-8 Support Enabled
INFO - 2018-03-28 05:44:35 --> Utf8 Class Initialized
INFO - 2018-03-28 05:44:35 --> URI Class Initialized
INFO - 2018-03-28 05:44:35 --> Language Class Initialized
INFO - 2018-03-28 05:44:35 --> Config Class Initialized
INFO - 2018-03-28 05:44:35 --> Loader Class Initialized
INFO - 2018-03-28 11:14:35 --> Helper loaded: url_helper
INFO - 2018-03-28 11:14:35 --> Helper loaded: notification_helper
INFO - 2018-03-28 11:14:35 --> Helper loaded: settings_helper
INFO - 2018-03-28 11:14:35 --> Helper loaded: permission_helper
INFO - 2018-03-28 11:14:35 --> Helper loaded: users_helper
INFO - 2018-03-28 05:44:35 --> Router Class Initialized
INFO - 2018-03-28 05:44:35 --> Output Class Initialized
INFO - 2018-03-28 05:44:35 --> Security Class Initialized
DEBUG - 2018-03-28 05:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 05:44:35 --> Input Class Initialized
INFO - 2018-03-28 05:44:35 --> Language Class Initialized
INFO - 2018-03-28 11:14:35 --> Database Driver Class Initialized
DEBUG - 2018-03-28 11:14:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 11:14:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 11:14:35 --> Helper loaded: form_helper
INFO - 2018-03-28 11:14:35 --> Form Validation Class Initialized
INFO - 2018-03-28 11:14:35 --> Controller Class Initialized
INFO - 2018-03-28 05:44:36 --> Language Class Initialized
INFO - 2018-03-28 05:44:36 --> Config Class Initialized
INFO - 2018-03-28 05:44:36 --> Loader Class Initialized
INFO - 2018-03-28 11:14:36 --> Model Class Initialized
INFO - 2018-03-28 11:14:36 --> Helper loaded: inflector_helper
INFO - 2018-03-28 11:14:36 --> Helper loaded: url_helper
DEBUG - 2018-03-28 11:14:36 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 11:14:36 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 11:14:36 --> Helper loaded: notification_helper
INFO - 2018-03-28 11:14:36 --> Helper loaded: settings_helper
INFO - 2018-03-28 11:14:36 --> Model Class Initialized
INFO - 2018-03-28 11:14:36 --> Model Class Initialized
INFO - 2018-03-28 11:14:36 --> Helper loaded: permission_helper
INFO - 2018-03-28 11:14:36 --> Helper loaded: users_helper
INFO - 2018-03-28 11:14:36 --> Model Class Initialized
INFO - 2018-03-28 11:14:36 --> Model Class Initialized
INFO - 2018-03-28 11:14:36 --> Model Class Initialized
INFO - 2018-03-28 11:14:36 --> Model Class Initialized
INFO - 2018-03-28 11:14:36 --> Model Class Initialized
INFO - 2018-03-28 11:14:36 --> Model Class Initialized
INFO - 2018-03-28 11:14:36 --> Model Class Initialized
INFO - 2018-03-28 11:14:36 --> Model Class Initialized
INFO - 2018-03-28 11:14:36 --> Model Class Initialized
INFO - 2018-03-28 11:14:36 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 05:44:36 --> Config Class Initialized
INFO - 2018-03-28 05:44:36 --> Hooks Class Initialized
DEBUG - 2018-03-28 05:44:36 --> UTF-8 Support Enabled
INFO - 2018-03-28 05:44:36 --> Utf8 Class Initialized
INFO - 2018-03-28 05:44:36 --> URI Class Initialized
INFO - 2018-03-28 05:44:36 --> Router Class Initialized
INFO - 2018-03-28 05:44:36 --> Output Class Initialized
INFO - 2018-03-28 11:14:36 --> Model Class Initialized
INFO - 2018-03-28 05:44:36 --> Security Class Initialized
DEBUG - 2018-03-28 05:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 05:44:36 --> Input Class Initialized
INFO - 2018-03-28 05:44:36 --> Language Class Initialized
INFO - 2018-03-28 11:14:36 --> Database Driver Class Initialized
INFO - 2018-03-28 05:44:37 --> Language Class Initialized
INFO - 2018-03-28 05:44:37 --> Config Class Initialized
INFO - 2018-03-28 05:44:37 --> Loader Class Initialized
INFO - 2018-03-28 11:14:37 --> Helper loaded: url_helper
INFO - 2018-03-28 11:14:37 --> Helper loaded: notification_helper
INFO - 2018-03-28 11:14:37 --> Helper loaded: settings_helper
INFO - 2018-03-28 11:14:37 --> Helper loaded: permission_helper
INFO - 2018-03-28 11:14:37 --> Helper loaded: users_helper
INFO - 2018-03-28 11:14:37 --> Final output sent to browser
DEBUG - 2018-03-28 11:14:37 --> Total execution time: 3.0731
INFO - 2018-03-28 11:14:37 --> Database Driver Class Initialized
INFO - 2018-03-28 05:44:37 --> Config Class Initialized
INFO - 2018-03-28 05:44:37 --> Hooks Class Initialized
DEBUG - 2018-03-28 05:44:37 --> UTF-8 Support Enabled
INFO - 2018-03-28 05:44:37 --> Utf8 Class Initialized
INFO - 2018-03-28 05:44:37 --> URI Class Initialized
INFO - 2018-03-28 05:44:37 --> Router Class Initialized
INFO - 2018-03-28 05:44:37 --> Output Class Initialized
INFO - 2018-03-28 05:44:37 --> Security Class Initialized
DEBUG - 2018-03-28 05:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 05:44:37 --> Input Class Initialized
INFO - 2018-03-28 05:44:37 --> Language Class Initialized
INFO - 2018-03-28 05:44:37 --> Language Class Initialized
INFO - 2018-03-28 05:44:37 --> Config Class Initialized
INFO - 2018-03-28 05:44:37 --> Loader Class Initialized
INFO - 2018-03-28 11:14:37 --> Helper loaded: url_helper
INFO - 2018-03-28 11:14:37 --> Helper loaded: notification_helper
INFO - 2018-03-28 11:14:37 --> Helper loaded: settings_helper
INFO - 2018-03-28 11:14:37 --> Helper loaded: permission_helper
INFO - 2018-03-28 11:14:37 --> Helper loaded: users_helper
DEBUG - 2018-03-28 11:14:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 11:14:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 11:14:37 --> Database Driver Class Initialized
DEBUG - 2018-03-28 11:14:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 11:14:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 11:14:37 --> Helper loaded: form_helper
INFO - 2018-03-28 11:14:37 --> Form Validation Class Initialized
INFO - 2018-03-28 11:14:37 --> Controller Class Initialized
DEBUG - 2018-03-28 11:14:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 11:14:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 11:14:37 --> Model Class Initialized
INFO - 2018-03-28 11:14:37 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 11:14:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 11:14:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 11:14:37 --> Model Class Initialized
INFO - 2018-03-28 11:14:37 --> Model Class Initialized
INFO - 2018-03-28 11:14:37 --> Model Class Initialized
INFO - 2018-03-28 11:14:37 --> Model Class Initialized
INFO - 2018-03-28 11:14:37 --> Model Class Initialized
INFO - 2018-03-28 11:14:37 --> Model Class Initialized
INFO - 2018-03-28 11:14:37 --> Model Class Initialized
INFO - 2018-03-28 11:14:37 --> Model Class Initialized
INFO - 2018-03-28 11:14:37 --> Model Class Initialized
INFO - 2018-03-28 11:14:37 --> Model Class Initialized
INFO - 2018-03-28 11:14:37 --> Model Class Initialized
INFO - 2018-03-28 11:14:37 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 11:14:37 --> Model Class Initialized
INFO - 2018-03-28 11:14:37 --> Final output sent to browser
DEBUG - 2018-03-28 11:14:37 --> Total execution time: 0.1770
INFO - 2018-03-28 11:14:37 --> Helper loaded: form_helper
INFO - 2018-03-28 11:14:37 --> Form Validation Class Initialized
INFO - 2018-03-28 11:14:37 --> Controller Class Initialized
INFO - 2018-03-28 11:14:37 --> Model Class Initialized
INFO - 2018-03-28 11:14:37 --> Helper loaded: form_helper
INFO - 2018-03-28 11:14:37 --> Form Validation Class Initialized
INFO - 2018-03-28 11:14:37 --> Helper loaded: inflector_helper
INFO - 2018-03-28 11:14:37 --> Controller Class Initialized
DEBUG - 2018-03-28 11:14:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 11:14:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 11:14:37 --> Model Class Initialized
INFO - 2018-03-28 11:14:37 --> Model Class Initialized
INFO - 2018-03-28 11:14:38 --> Model Class Initialized
INFO - 2018-03-28 11:14:38 --> Model Class Initialized
INFO - 2018-03-28 11:14:38 --> Model Class Initialized
INFO - 2018-03-28 11:14:38 --> Model Class Initialized
INFO - 2018-03-28 11:14:38 --> Model Class Initialized
INFO - 2018-03-28 11:14:38 --> Model Class Initialized
INFO - 2018-03-28 11:14:38 --> Model Class Initialized
INFO - 2018-03-28 11:14:38 --> Model Class Initialized
INFO - 2018-03-28 11:14:38 --> Model Class Initialized
INFO - 2018-03-28 11:14:38 --> Helper loaded: inflector_helper
INFO - 2018-03-28 11:14:38 --> Model Class Initialized
INFO - 2018-03-28 11:14:38 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 11:14:38 --> Model Class Initialized
DEBUG - 2018-03-28 11:14:38 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 11:14:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 11:14:38 --> Final output sent to browser
DEBUG - 2018-03-28 11:14:38 --> Total execution time: 3.6973
INFO - 2018-03-28 11:14:38 --> Model Class Initialized
INFO - 2018-03-28 11:14:38 --> Model Class Initialized
INFO - 2018-03-28 11:14:38 --> Model Class Initialized
INFO - 2018-03-28 11:14:38 --> Model Class Initialized
INFO - 2018-03-28 11:14:38 --> Model Class Initialized
INFO - 2018-03-28 11:14:38 --> Model Class Initialized
INFO - 2018-03-28 11:14:38 --> Model Class Initialized
INFO - 2018-03-28 11:14:38 --> Model Class Initialized
INFO - 2018-03-28 11:14:38 --> Model Class Initialized
INFO - 2018-03-28 11:14:38 --> Model Class Initialized
INFO - 2018-03-28 11:14:38 --> Model Class Initialized
INFO - 2018-03-28 11:14:38 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 11:14:38 --> Model Class Initialized
INFO - 2018-03-28 11:14:38 --> Final output sent to browser
DEBUG - 2018-03-28 11:14:38 --> Total execution time: 1.5799
INFO - 2018-03-28 05:44:40 --> Config Class Initialized
INFO - 2018-03-28 05:44:40 --> Hooks Class Initialized
DEBUG - 2018-03-28 05:44:40 --> UTF-8 Support Enabled
INFO - 2018-03-28 05:44:40 --> Utf8 Class Initialized
INFO - 2018-03-28 05:44:40 --> URI Class Initialized
INFO - 2018-03-28 05:44:40 --> Config Class Initialized
INFO - 2018-03-28 05:44:40 --> Hooks Class Initialized
INFO - 2018-03-28 05:44:40 --> Router Class Initialized
INFO - 2018-03-28 05:44:40 --> Output Class Initialized
DEBUG - 2018-03-28 05:44:40 --> UTF-8 Support Enabled
INFO - 2018-03-28 05:44:40 --> Utf8 Class Initialized
INFO - 2018-03-28 05:44:40 --> Security Class Initialized
INFO - 2018-03-28 05:44:40 --> URI Class Initialized
DEBUG - 2018-03-28 05:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 05:44:40 --> Input Class Initialized
INFO - 2018-03-28 05:44:40 --> Language Class Initialized
INFO - 2018-03-28 05:44:40 --> Router Class Initialized
INFO - 2018-03-28 05:44:40 --> Output Class Initialized
INFO - 2018-03-28 05:44:40 --> Security Class Initialized
DEBUG - 2018-03-28 05:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 05:44:40 --> Input Class Initialized
INFO - 2018-03-28 05:44:40 --> Language Class Initialized
INFO - 2018-03-28 05:44:40 --> Config Class Initialized
INFO - 2018-03-28 05:44:40 --> Loader Class Initialized
INFO - 2018-03-28 05:44:40 --> Language Class Initialized
INFO - 2018-03-28 11:14:40 --> Helper loaded: url_helper
INFO - 2018-03-28 11:14:40 --> Helper loaded: notification_helper
INFO - 2018-03-28 11:14:40 --> Helper loaded: settings_helper
INFO - 2018-03-28 11:14:40 --> Helper loaded: permission_helper
INFO - 2018-03-28 11:14:40 --> Helper loaded: users_helper
INFO - 2018-03-28 05:44:40 --> Language Class Initialized
INFO - 2018-03-28 05:44:40 --> Config Class Initialized
INFO - 2018-03-28 05:44:40 --> Loader Class Initialized
INFO - 2018-03-28 11:14:40 --> Helper loaded: url_helper
INFO - 2018-03-28 11:14:40 --> Database Driver Class Initialized
INFO - 2018-03-28 11:14:40 --> Helper loaded: notification_helper
INFO - 2018-03-28 11:14:40 --> Helper loaded: settings_helper
INFO - 2018-03-28 11:14:40 --> Helper loaded: permission_helper
INFO - 2018-03-28 11:14:40 --> Helper loaded: users_helper
DEBUG - 2018-03-28 11:14:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 11:14:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 11:14:40 --> Helper loaded: form_helper
INFO - 2018-03-28 11:14:40 --> Form Validation Class Initialized
INFO - 2018-03-28 11:14:40 --> Controller Class Initialized
INFO - 2018-03-28 11:14:40 --> Database Driver Class Initialized
INFO - 2018-03-28 11:14:40 --> Model Class Initialized
INFO - 2018-03-28 11:14:40 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 11:14:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 11:14:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 11:14:40 --> Helper loaded: form_helper
INFO - 2018-03-28 11:14:40 --> Form Validation Class Initialized
INFO - 2018-03-28 11:14:40 --> Controller Class Initialized
INFO - 2018-03-28 11:14:40 --> Model Class Initialized
INFO - 2018-03-28 11:14:40 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 11:14:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-03-28 11:14:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 11:14:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 11:14:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 11:14:40 --> Model Class Initialized
INFO - 2018-03-28 11:14:40 --> Model Class Initialized
INFO - 2018-03-28 11:14:40 --> Model Class Initialized
INFO - 2018-03-28 11:14:40 --> Model Class Initialized
INFO - 2018-03-28 11:14:40 --> Model Class Initialized
INFO - 2018-03-28 11:14:40 --> Model Class Initialized
INFO - 2018-03-28 11:14:40 --> Model Class Initialized
INFO - 2018-03-28 11:14:40 --> Model Class Initialized
INFO - 2018-03-28 11:14:40 --> Final output sent to browser
DEBUG - 2018-03-28 11:14:40 --> Total execution time: 0.1193
INFO - 2018-03-28 11:14:40 --> Final output sent to browser
DEBUG - 2018-03-28 11:14:40 --> Total execution time: 0.1158
INFO - 2018-03-28 05:44:43 --> Config Class Initialized
INFO - 2018-03-28 05:44:43 --> Hooks Class Initialized
DEBUG - 2018-03-28 05:44:43 --> UTF-8 Support Enabled
INFO - 2018-03-28 05:44:43 --> Utf8 Class Initialized
INFO - 2018-03-28 05:44:43 --> URI Class Initialized
INFO - 2018-03-28 05:44:43 --> Router Class Initialized
INFO - 2018-03-28 05:44:43 --> Output Class Initialized
INFO - 2018-03-28 05:44:43 --> Security Class Initialized
DEBUG - 2018-03-28 05:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 05:44:43 --> Input Class Initialized
INFO - 2018-03-28 05:44:43 --> Language Class Initialized
INFO - 2018-03-28 05:44:43 --> Language Class Initialized
INFO - 2018-03-28 05:44:43 --> Config Class Initialized
INFO - 2018-03-28 05:44:43 --> Loader Class Initialized
INFO - 2018-03-28 11:14:43 --> Helper loaded: url_helper
INFO - 2018-03-28 11:14:43 --> Helper loaded: notification_helper
INFO - 2018-03-28 11:14:43 --> Helper loaded: settings_helper
INFO - 2018-03-28 11:14:43 --> Helper loaded: permission_helper
INFO - 2018-03-28 11:14:43 --> Helper loaded: users_helper
INFO - 2018-03-28 11:14:43 --> Database Driver Class Initialized
DEBUG - 2018-03-28 11:14:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 11:14:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 11:14:43 --> Helper loaded: form_helper
INFO - 2018-03-28 11:14:43 --> Form Validation Class Initialized
INFO - 2018-03-28 11:14:43 --> Controller Class Initialized
INFO - 2018-03-28 11:14:43 --> Model Class Initialized
INFO - 2018-03-28 11:14:43 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 11:14:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 11:14:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 11:14:43 --> Model Class Initialized
INFO - 2018-03-28 11:14:43 --> Model Class Initialized
INFO - 2018-03-28 11:14:43 --> Model Class Initialized
INFO - 2018-03-28 11:14:43 --> Model Class Initialized
INFO - 2018-03-28 11:14:43 --> Model Class Initialized
INFO - 2018-03-28 11:14:43 --> Model Class Initialized
INFO - 2018-03-28 11:14:43 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-28 11:14:43 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-28 11:14:43 --> Final output sent to browser
DEBUG - 2018-03-28 11:14:43 --> Total execution time: 0.4864
INFO - 2018-03-28 05:44:48 --> Config Class Initialized
INFO - 2018-03-28 05:44:48 --> Hooks Class Initialized
DEBUG - 2018-03-28 05:44:48 --> UTF-8 Support Enabled
INFO - 2018-03-28 05:44:48 --> Utf8 Class Initialized
INFO - 2018-03-28 05:44:48 --> URI Class Initialized
INFO - 2018-03-28 05:44:48 --> Router Class Initialized
INFO - 2018-03-28 05:44:48 --> Output Class Initialized
INFO - 2018-03-28 05:44:48 --> Security Class Initialized
DEBUG - 2018-03-28 05:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 05:44:48 --> Input Class Initialized
INFO - 2018-03-28 05:44:48 --> Language Class Initialized
INFO - 2018-03-28 05:44:48 --> Language Class Initialized
INFO - 2018-03-28 05:44:48 --> Config Class Initialized
INFO - 2018-03-28 05:44:48 --> Loader Class Initialized
INFO - 2018-03-28 11:14:48 --> Helper loaded: url_helper
INFO - 2018-03-28 11:14:48 --> Helper loaded: notification_helper
INFO - 2018-03-28 11:14:48 --> Helper loaded: settings_helper
INFO - 2018-03-28 11:14:48 --> Helper loaded: permission_helper
INFO - 2018-03-28 11:14:48 --> Helper loaded: users_helper
INFO - 2018-03-28 11:14:48 --> Database Driver Class Initialized
DEBUG - 2018-03-28 11:14:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 11:14:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 11:14:48 --> Helper loaded: form_helper
INFO - 2018-03-28 11:14:48 --> Form Validation Class Initialized
INFO - 2018-03-28 11:14:48 --> Controller Class Initialized
INFO - 2018-03-28 11:14:48 --> Model Class Initialized
INFO - 2018-03-28 11:14:48 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 11:14:48 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 11:14:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 11:14:48 --> Model Class Initialized
INFO - 2018-03-28 11:14:48 --> Model Class Initialized
INFO - 2018-03-28 11:14:48 --> Model Class Initialized
INFO - 2018-03-28 11:14:48 --> Model Class Initialized
INFO - 2018-03-28 11:14:48 --> Model Class Initialized
INFO - 2018-03-28 11:14:48 --> Model Class Initialized
INFO - 2018-03-28 11:14:48 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-28 11:14:48 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-28 11:14:48 --> Final output sent to browser
DEBUG - 2018-03-28 11:14:48 --> Total execution time: 0.1806
INFO - 2018-03-28 06:10:26 --> Config Class Initialized
INFO - 2018-03-28 06:10:26 --> Hooks Class Initialized
DEBUG - 2018-03-28 06:10:26 --> UTF-8 Support Enabled
INFO - 2018-03-28 06:10:26 --> Utf8 Class Initialized
INFO - 2018-03-28 06:10:26 --> URI Class Initialized
INFO - 2018-03-28 06:10:26 --> Router Class Initialized
INFO - 2018-03-28 06:10:26 --> Output Class Initialized
INFO - 2018-03-28 06:10:26 --> Security Class Initialized
DEBUG - 2018-03-28 06:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 06:10:26 --> Input Class Initialized
INFO - 2018-03-28 06:10:26 --> Language Class Initialized
INFO - 2018-03-28 06:10:26 --> Language Class Initialized
INFO - 2018-03-28 06:10:26 --> Config Class Initialized
INFO - 2018-03-28 06:10:26 --> Loader Class Initialized
INFO - 2018-03-28 11:40:26 --> Helper loaded: url_helper
INFO - 2018-03-28 11:40:26 --> Helper loaded: notification_helper
INFO - 2018-03-28 11:40:26 --> Helper loaded: settings_helper
INFO - 2018-03-28 11:40:26 --> Helper loaded: permission_helper
INFO - 2018-03-28 11:40:26 --> Helper loaded: users_helper
INFO - 2018-03-28 11:40:26 --> Database Driver Class Initialized
DEBUG - 2018-03-28 11:40:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 11:40:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 11:40:26 --> Helper loaded: form_helper
INFO - 2018-03-28 11:40:26 --> Form Validation Class Initialized
INFO - 2018-03-28 11:40:26 --> Controller Class Initialized
INFO - 2018-03-28 11:40:26 --> Model Class Initialized
INFO - 2018-03-28 11:40:26 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 11:40:26 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 11:40:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 11:40:26 --> Model Class Initialized
INFO - 2018-03-28 11:40:26 --> Model Class Initialized
INFO - 2018-03-28 11:40:26 --> Model Class Initialized
INFO - 2018-03-28 11:40:26 --> Model Class Initialized
INFO - 2018-03-28 11:40:26 --> Model Class Initialized
INFO - 2018-03-28 11:40:26 --> Model Class Initialized
INFO - 2018-03-28 11:40:26 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 11:40:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-28 11:40:26 --> Final output sent to browser
DEBUG - 2018-03-28 11:40:26 --> Total execution time: 0.1635
INFO - 2018-03-28 06:10:27 --> Config Class Initialized
INFO - 2018-03-28 06:10:27 --> Hooks Class Initialized
DEBUG - 2018-03-28 06:10:27 --> UTF-8 Support Enabled
INFO - 2018-03-28 06:10:27 --> Utf8 Class Initialized
INFO - 2018-03-28 06:10:27 --> URI Class Initialized
INFO - 2018-03-28 06:10:28 --> Router Class Initialized
INFO - 2018-03-28 06:10:28 --> Output Class Initialized
INFO - 2018-03-28 06:10:28 --> Security Class Initialized
DEBUG - 2018-03-28 06:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 06:10:28 --> Input Class Initialized
INFO - 2018-03-28 06:10:28 --> Language Class Initialized
INFO - 2018-03-28 06:10:28 --> Config Class Initialized
INFO - 2018-03-28 06:10:28 --> Hooks Class Initialized
DEBUG - 2018-03-28 06:10:29 --> UTF-8 Support Enabled
INFO - 2018-03-28 06:10:29 --> Utf8 Class Initialized
INFO - 2018-03-28 06:10:29 --> URI Class Initialized
INFO - 2018-03-28 06:10:29 --> Router Class Initialized
INFO - 2018-03-28 06:10:29 --> Language Class Initialized
INFO - 2018-03-28 06:10:29 --> Config Class Initialized
INFO - 2018-03-28 06:10:29 --> Loader Class Initialized
INFO - 2018-03-28 06:10:29 --> Output Class Initialized
INFO - 2018-03-28 11:40:29 --> Helper loaded: url_helper
INFO - 2018-03-28 06:10:29 --> Security Class Initialized
INFO - 2018-03-28 11:40:29 --> Helper loaded: notification_helper
INFO - 2018-03-28 11:40:29 --> Helper loaded: settings_helper
INFO - 2018-03-28 11:40:29 --> Helper loaded: permission_helper
INFO - 2018-03-28 11:40:30 --> Helper loaded: users_helper
DEBUG - 2018-03-28 06:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 06:10:30 --> Input Class Initialized
INFO - 2018-03-28 06:10:30 --> Language Class Initialized
INFO - 2018-03-28 06:10:30 --> Config Class Initialized
INFO - 2018-03-28 06:10:30 --> Hooks Class Initialized
DEBUG - 2018-03-28 06:10:30 --> UTF-8 Support Enabled
INFO - 2018-03-28 06:10:30 --> Utf8 Class Initialized
INFO - 2018-03-28 06:10:30 --> URI Class Initialized
INFO - 2018-03-28 06:10:30 --> Router Class Initialized
INFO - 2018-03-28 06:10:30 --> Output Class Initialized
INFO - 2018-03-28 06:10:30 --> Security Class Initialized
DEBUG - 2018-03-28 06:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 06:10:30 --> Input Class Initialized
INFO - 2018-03-28 06:10:30 --> Language Class Initialized
INFO - 2018-03-28 06:10:30 --> Language Class Initialized
INFO - 2018-03-28 06:10:30 --> Config Class Initialized
INFO - 2018-03-28 06:10:30 --> Loader Class Initialized
INFO - 2018-03-28 11:40:30 --> Helper loaded: url_helper
INFO - 2018-03-28 11:40:30 --> Helper loaded: notification_helper
INFO - 2018-03-28 11:40:30 --> Helper loaded: settings_helper
INFO - 2018-03-28 11:40:30 --> Helper loaded: permission_helper
INFO - 2018-03-28 11:40:30 --> Helper loaded: users_helper
INFO - 2018-03-28 06:10:30 --> Config Class Initialized
INFO - 2018-03-28 06:10:30 --> Hooks Class Initialized
DEBUG - 2018-03-28 06:10:30 --> UTF-8 Support Enabled
INFO - 2018-03-28 06:10:30 --> Utf8 Class Initialized
INFO - 2018-03-28 11:40:30 --> Database Driver Class Initialized
INFO - 2018-03-28 06:10:30 --> URI Class Initialized
INFO - 2018-03-28 06:10:30 --> Router Class Initialized
DEBUG - 2018-03-28 11:40:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 11:40:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 06:10:30 --> Output Class Initialized
INFO - 2018-03-28 06:10:30 --> Security Class Initialized
DEBUG - 2018-03-28 06:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 06:10:30 --> Input Class Initialized
INFO - 2018-03-28 11:40:30 --> Helper loaded: form_helper
INFO - 2018-03-28 11:40:30 --> Form Validation Class Initialized
INFO - 2018-03-28 11:40:30 --> Controller Class Initialized
INFO - 2018-03-28 06:10:30 --> Language Class Initialized
INFO - 2018-03-28 11:40:30 --> Model Class Initialized
INFO - 2018-03-28 11:40:30 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 11:40:30 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 11:40:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 11:40:30 --> Model Class Initialized
INFO - 2018-03-28 11:40:30 --> Model Class Initialized
INFO - 2018-03-28 06:10:30 --> Language Class Initialized
INFO - 2018-03-28 06:10:30 --> Config Class Initialized
INFO - 2018-03-28 11:40:30 --> Model Class Initialized
INFO - 2018-03-28 06:10:30 --> Loader Class Initialized
INFO - 2018-03-28 11:40:30 --> Model Class Initialized
INFO - 2018-03-28 11:40:30 --> Helper loaded: url_helper
INFO - 2018-03-28 11:40:30 --> Model Class Initialized
INFO - 2018-03-28 11:40:30 --> Model Class Initialized
INFO - 2018-03-28 11:40:30 --> Model Class Initialized
INFO - 2018-03-28 11:40:30 --> Model Class Initialized
INFO - 2018-03-28 11:40:30 --> Model Class Initialized
INFO - 2018-03-28 11:40:30 --> Model Class Initialized
INFO - 2018-03-28 11:40:30 --> Helper loaded: notification_helper
INFO - 2018-03-28 11:40:30 --> Helper loaded: settings_helper
INFO - 2018-03-28 11:40:30 --> Helper loaded: permission_helper
INFO - 2018-03-28 11:40:30 --> Helper loaded: users_helper
INFO - 2018-03-28 11:40:30 --> Model Class Initialized
INFO - 2018-03-28 11:40:30 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 11:40:30 --> Model Class Initialized
INFO - 2018-03-28 11:40:30 --> Final output sent to browser
DEBUG - 2018-03-28 11:40:30 --> Total execution time: 0.4043
INFO - 2018-03-28 11:40:30 --> Database Driver Class Initialized
DEBUG - 2018-03-28 11:40:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 11:40:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 11:40:30 --> Helper loaded: form_helper
INFO - 2018-03-28 11:40:30 --> Form Validation Class Initialized
INFO - 2018-03-28 11:40:30 --> Controller Class Initialized
INFO - 2018-03-28 11:40:30 --> Model Class Initialized
INFO - 2018-03-28 11:40:30 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 11:40:30 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 11:40:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 11:40:30 --> Model Class Initialized
INFO - 2018-03-28 11:40:30 --> Model Class Initialized
INFO - 2018-03-28 11:40:30 --> Model Class Initialized
INFO - 2018-03-28 11:40:30 --> Model Class Initialized
INFO - 2018-03-28 11:40:30 --> Model Class Initialized
INFO - 2018-03-28 11:40:30 --> Model Class Initialized
INFO - 2018-03-28 11:40:30 --> Model Class Initialized
INFO - 2018-03-28 11:40:30 --> Model Class Initialized
INFO - 2018-03-28 11:40:30 --> Model Class Initialized
INFO - 2018-03-28 11:40:30 --> Model Class Initialized
INFO - 2018-03-28 11:40:30 --> Database Driver Class Initialized
INFO - 2018-03-28 11:40:30 --> Model Class Initialized
INFO - 2018-03-28 11:40:30 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 11:40:30 --> Model Class Initialized
INFO - 2018-03-28 11:40:30 --> Final output sent to browser
DEBUG - 2018-03-28 11:40:30 --> Total execution time: 0.3729
DEBUG - 2018-03-28 11:40:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 11:40:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 11:40:30 --> Helper loaded: form_helper
INFO - 2018-03-28 11:40:30 --> Form Validation Class Initialized
INFO - 2018-03-28 11:40:30 --> Controller Class Initialized
INFO - 2018-03-28 06:10:30 --> Language Class Initialized
INFO - 2018-03-28 06:10:30 --> Config Class Initialized
INFO - 2018-03-28 11:40:30 --> Model Class Initialized
INFO - 2018-03-28 06:10:30 --> Loader Class Initialized
INFO - 2018-03-28 11:40:30 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 11:40:30 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 11:40:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 11:40:30 --> Model Class Initialized
INFO - 2018-03-28 11:40:30 --> Model Class Initialized
INFO - 2018-03-28 11:40:30 --> Model Class Initialized
INFO - 2018-03-28 11:40:30 --> Model Class Initialized
INFO - 2018-03-28 11:40:30 --> Model Class Initialized
INFO - 2018-03-28 11:40:30 --> Model Class Initialized
INFO - 2018-03-28 11:40:30 --> Model Class Initialized
INFO - 2018-03-28 11:40:30 --> Model Class Initialized
INFO - 2018-03-28 11:40:30 --> Model Class Initialized
INFO - 2018-03-28 11:40:30 --> Model Class Initialized
INFO - 2018-03-28 11:40:30 --> Model Class Initialized
INFO - 2018-03-28 11:40:30 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 11:40:30 --> Model Class Initialized
INFO - 2018-03-28 11:40:30 --> Helper loaded: url_helper
INFO - 2018-03-28 11:40:30 --> Final output sent to browser
DEBUG - 2018-03-28 11:40:30 --> Total execution time: 3.2296
INFO - 2018-03-28 11:40:31 --> Helper loaded: notification_helper
INFO - 2018-03-28 11:40:31 --> Helper loaded: settings_helper
INFO - 2018-03-28 11:40:31 --> Helper loaded: permission_helper
INFO - 2018-03-28 11:40:31 --> Helper loaded: users_helper
INFO - 2018-03-28 11:40:31 --> Database Driver Class Initialized
DEBUG - 2018-03-28 11:40:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 11:40:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 11:40:32 --> Helper loaded: form_helper
INFO - 2018-03-28 11:40:32 --> Form Validation Class Initialized
INFO - 2018-03-28 11:40:32 --> Controller Class Initialized
INFO - 2018-03-28 11:40:32 --> Model Class Initialized
INFO - 2018-03-28 11:40:32 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 11:40:32 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 11:40:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 11:40:32 --> Model Class Initialized
INFO - 2018-03-28 11:40:32 --> Model Class Initialized
INFO - 2018-03-28 11:40:32 --> Model Class Initialized
INFO - 2018-03-28 11:40:32 --> Model Class Initialized
INFO - 2018-03-28 11:40:32 --> Model Class Initialized
INFO - 2018-03-28 11:40:32 --> Model Class Initialized
INFO - 2018-03-28 11:40:32 --> Model Class Initialized
INFO - 2018-03-28 11:40:32 --> Model Class Initialized
INFO - 2018-03-28 11:40:32 --> Model Class Initialized
INFO - 2018-03-28 11:40:32 --> Model Class Initialized
INFO - 2018-03-28 11:40:32 --> Model Class Initialized
INFO - 2018-03-28 11:40:32 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 11:40:32 --> Model Class Initialized
INFO - 2018-03-28 11:40:32 --> Final output sent to browser
DEBUG - 2018-03-28 11:40:32 --> Total execution time: 3.5918
INFO - 2018-03-28 06:10:40 --> Config Class Initialized
INFO - 2018-03-28 06:10:40 --> Hooks Class Initialized
DEBUG - 2018-03-28 06:10:40 --> UTF-8 Support Enabled
INFO - 2018-03-28 06:10:40 --> Utf8 Class Initialized
INFO - 2018-03-28 06:10:40 --> URI Class Initialized
INFO - 2018-03-28 06:10:40 --> Router Class Initialized
INFO - 2018-03-28 06:10:40 --> Output Class Initialized
INFO - 2018-03-28 06:10:40 --> Config Class Initialized
INFO - 2018-03-28 06:10:40 --> Hooks Class Initialized
INFO - 2018-03-28 06:10:40 --> Security Class Initialized
DEBUG - 2018-03-28 06:10:40 --> UTF-8 Support Enabled
INFO - 2018-03-28 06:10:40 --> Utf8 Class Initialized
DEBUG - 2018-03-28 06:10:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 06:10:40 --> Input Class Initialized
INFO - 2018-03-28 06:10:40 --> URI Class Initialized
INFO - 2018-03-28 06:10:40 --> Language Class Initialized
INFO - 2018-03-28 06:10:40 --> Router Class Initialized
INFO - 2018-03-28 06:10:40 --> Output Class Initialized
INFO - 2018-03-28 06:10:40 --> Security Class Initialized
DEBUG - 2018-03-28 06:10:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 06:10:40 --> Input Class Initialized
INFO - 2018-03-28 06:10:40 --> Language Class Initialized
INFO - 2018-03-28 06:10:40 --> Language Class Initialized
INFO - 2018-03-28 06:10:40 --> Config Class Initialized
INFO - 2018-03-28 06:10:40 --> Loader Class Initialized
INFO - 2018-03-28 11:40:40 --> Helper loaded: url_helper
INFO - 2018-03-28 11:40:40 --> Helper loaded: notification_helper
INFO - 2018-03-28 11:40:40 --> Helper loaded: settings_helper
INFO - 2018-03-28 11:40:40 --> Helper loaded: permission_helper
INFO - 2018-03-28 11:40:40 --> Helper loaded: users_helper
INFO - 2018-03-28 06:10:40 --> Language Class Initialized
INFO - 2018-03-28 06:10:40 --> Config Class Initialized
INFO - 2018-03-28 06:10:40 --> Loader Class Initialized
INFO - 2018-03-28 11:40:40 --> Helper loaded: url_helper
INFO - 2018-03-28 11:40:40 --> Helper loaded: notification_helper
INFO - 2018-03-28 11:40:40 --> Database Driver Class Initialized
INFO - 2018-03-28 11:40:40 --> Helper loaded: settings_helper
INFO - 2018-03-28 11:40:40 --> Helper loaded: permission_helper
INFO - 2018-03-28 11:40:40 --> Helper loaded: users_helper
DEBUG - 2018-03-28 11:40:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 11:40:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 11:40:40 --> Helper loaded: form_helper
INFO - 2018-03-28 11:40:40 --> Form Validation Class Initialized
INFO - 2018-03-28 11:40:40 --> Controller Class Initialized
INFO - 2018-03-28 11:40:40 --> Database Driver Class Initialized
DEBUG - 2018-03-28 11:40:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 11:40:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 11:40:40 --> Model Class Initialized
INFO - 2018-03-28 11:40:40 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 11:40:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 11:40:40 --> Helper loaded: form_helper
INFO - 2018-03-28 11:40:40 --> Form Validation Class Initialized
INFO - 2018-03-28 11:40:40 --> Controller Class Initialized
INFO - 2018-03-28 11:40:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 11:40:40 --> Model Class Initialized
INFO - 2018-03-28 11:40:40 --> Model Class Initialized
INFO - 2018-03-28 11:40:40 --> Model Class Initialized
INFO - 2018-03-28 11:40:40 --> Model Class Initialized
INFO - 2018-03-28 11:40:40 --> Final output sent to browser
DEBUG - 2018-03-28 11:40:40 --> Total execution time: 0.4259
INFO - 2018-03-28 11:40:40 --> Model Class Initialized
INFO - 2018-03-28 11:40:40 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 11:40:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 11:40:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 11:40:40 --> Model Class Initialized
INFO - 2018-03-28 11:40:40 --> Model Class Initialized
INFO - 2018-03-28 11:40:40 --> Model Class Initialized
INFO - 2018-03-28 11:40:40 --> Model Class Initialized
INFO - 2018-03-28 11:40:40 --> Model Class Initialized
INFO - 2018-03-28 11:40:40 --> Model Class Initialized
INFO - 2018-03-28 11:40:40 --> Model Class Initialized
INFO - 2018-03-28 11:40:40 --> Model Class Initialized
INFO - 2018-03-28 11:40:40 --> Model Class Initialized
INFO - 2018-03-28 11:40:40 --> Model Class Initialized
INFO - 2018-03-28 11:40:40 --> Model Class Initialized
INFO - 2018-03-28 11:40:40 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 11:40:40 --> Model Class Initialized
INFO - 2018-03-28 11:40:40 --> Final output sent to browser
DEBUG - 2018-03-28 11:40:40 --> Total execution time: 0.4875
INFO - 2018-03-28 07:12:22 --> Config Class Initialized
INFO - 2018-03-28 07:12:22 --> Hooks Class Initialized
DEBUG - 2018-03-28 07:12:22 --> UTF-8 Support Enabled
INFO - 2018-03-28 07:12:22 --> Utf8 Class Initialized
INFO - 2018-03-28 07:12:22 --> URI Class Initialized
INFO - 2018-03-28 07:12:22 --> Router Class Initialized
INFO - 2018-03-28 07:12:22 --> Output Class Initialized
INFO - 2018-03-28 07:12:22 --> Security Class Initialized
DEBUG - 2018-03-28 07:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 07:12:22 --> Input Class Initialized
INFO - 2018-03-28 07:12:22 --> Language Class Initialized
INFO - 2018-03-28 07:12:23 --> Language Class Initialized
INFO - 2018-03-28 07:12:23 --> Config Class Initialized
INFO - 2018-03-28 07:12:23 --> Loader Class Initialized
INFO - 2018-03-28 12:42:23 --> Helper loaded: url_helper
INFO - 2018-03-28 12:42:23 --> Helper loaded: notification_helper
INFO - 2018-03-28 12:42:23 --> Helper loaded: settings_helper
INFO - 2018-03-28 12:42:23 --> Helper loaded: permission_helper
INFO - 2018-03-28 12:42:23 --> Helper loaded: users_helper
INFO - 2018-03-28 12:42:23 --> Database Driver Class Initialized
DEBUG - 2018-03-28 12:42:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 12:42:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 12:42:23 --> Helper loaded: form_helper
INFO - 2018-03-28 12:42:23 --> Form Validation Class Initialized
INFO - 2018-03-28 12:42:23 --> Controller Class Initialized
INFO - 2018-03-28 12:42:23 --> Model Class Initialized
INFO - 2018-03-28 12:42:23 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 12:42:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 12:42:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 12:42:23 --> Model Class Initialized
INFO - 2018-03-28 12:42:23 --> Model Class Initialized
INFO - 2018-03-28 12:42:23 --> Model Class Initialized
INFO - 2018-03-28 12:42:23 --> Model Class Initialized
INFO - 2018-03-28 12:42:23 --> Model Class Initialized
INFO - 2018-03-28 12:42:23 --> Model Class Initialized
INFO - 2018-03-28 12:42:23 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 12:42:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-28 12:42:23 --> Final output sent to browser
DEBUG - 2018-03-28 12:42:23 --> Total execution time: 0.2285
INFO - 2018-03-28 07:12:24 --> Config Class Initialized
INFO - 2018-03-28 07:12:24 --> Hooks Class Initialized
DEBUG - 2018-03-28 07:12:24 --> UTF-8 Support Enabled
INFO - 2018-03-28 07:12:24 --> Utf8 Class Initialized
INFO - 2018-03-28 07:12:24 --> URI Class Initialized
INFO - 2018-03-28 07:12:24 --> Router Class Initialized
INFO - 2018-03-28 07:12:24 --> Output Class Initialized
INFO - 2018-03-28 07:12:24 --> Security Class Initialized
DEBUG - 2018-03-28 07:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 07:12:24 --> Input Class Initialized
INFO - 2018-03-28 07:12:24 --> Language Class Initialized
INFO - 2018-03-28 07:12:24 --> Language Class Initialized
INFO - 2018-03-28 07:12:24 --> Config Class Initialized
INFO - 2018-03-28 07:12:24 --> Loader Class Initialized
INFO - 2018-03-28 12:42:24 --> Helper loaded: url_helper
INFO - 2018-03-28 12:42:24 --> Helper loaded: notification_helper
INFO - 2018-03-28 12:42:24 --> Helper loaded: settings_helper
INFO - 2018-03-28 12:42:24 --> Helper loaded: permission_helper
INFO - 2018-03-28 12:42:24 --> Helper loaded: users_helper
INFO - 2018-03-28 12:42:24 --> Database Driver Class Initialized
DEBUG - 2018-03-28 12:42:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 12:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 12:42:24 --> Helper loaded: form_helper
INFO - 2018-03-28 12:42:24 --> Form Validation Class Initialized
INFO - 2018-03-28 12:42:24 --> Controller Class Initialized
INFO - 2018-03-28 12:42:24 --> Model Class Initialized
INFO - 2018-03-28 12:42:24 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 12:42:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 12:42:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 12:42:24 --> Model Class Initialized
INFO - 2018-03-28 12:42:24 --> Model Class Initialized
INFO - 2018-03-28 12:42:24 --> Model Class Initialized
INFO - 2018-03-28 12:42:24 --> Model Class Initialized
INFO - 2018-03-28 12:42:24 --> Model Class Initialized
INFO - 2018-03-28 12:42:24 --> Model Class Initialized
INFO - 2018-03-28 12:42:24 --> Model Class Initialized
INFO - 2018-03-28 12:42:24 --> Model Class Initialized
INFO - 2018-03-28 12:42:24 --> Model Class Initialized
INFO - 2018-03-28 12:42:24 --> Model Class Initialized
INFO - 2018-03-28 12:42:24 --> Model Class Initialized
INFO - 2018-03-28 12:42:24 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 12:42:24 --> Model Class Initialized
INFO - 2018-03-28 12:42:24 --> Final output sent to browser
DEBUG - 2018-03-28 12:42:24 --> Total execution time: 0.4356
INFO - 2018-03-28 07:12:26 --> Config Class Initialized
INFO - 2018-03-28 07:12:26 --> Hooks Class Initialized
DEBUG - 2018-03-28 07:12:26 --> UTF-8 Support Enabled
INFO - 2018-03-28 07:12:26 --> Utf8 Class Initialized
INFO - 2018-03-28 07:12:26 --> URI Class Initialized
INFO - 2018-03-28 07:12:26 --> Router Class Initialized
INFO - 2018-03-28 07:12:26 --> Output Class Initialized
INFO - 2018-03-28 07:12:26 --> Security Class Initialized
DEBUG - 2018-03-28 07:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 07:12:26 --> Input Class Initialized
INFO - 2018-03-28 07:12:26 --> Language Class Initialized
INFO - 2018-03-28 07:12:26 --> Language Class Initialized
INFO - 2018-03-28 07:12:26 --> Config Class Initialized
INFO - 2018-03-28 07:12:26 --> Loader Class Initialized
INFO - 2018-03-28 12:42:26 --> Helper loaded: url_helper
INFO - 2018-03-28 12:42:26 --> Helper loaded: notification_helper
INFO - 2018-03-28 12:42:26 --> Helper loaded: settings_helper
INFO - 2018-03-28 12:42:26 --> Helper loaded: permission_helper
INFO - 2018-03-28 12:42:26 --> Helper loaded: users_helper
INFO - 2018-03-28 12:42:26 --> Database Driver Class Initialized
DEBUG - 2018-03-28 12:42:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 12:42:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 07:12:26 --> Config Class Initialized
INFO - 2018-03-28 07:12:26 --> Hooks Class Initialized
INFO - 2018-03-28 12:42:26 --> Helper loaded: form_helper
INFO - 2018-03-28 12:42:26 --> Form Validation Class Initialized
INFO - 2018-03-28 12:42:26 --> Controller Class Initialized
INFO - 2018-03-28 12:42:26 --> Model Class Initialized
INFO - 2018-03-28 12:42:26 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 12:42:26 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 12:42:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 12:42:26 --> Model Class Initialized
INFO - 2018-03-28 12:42:26 --> Model Class Initialized
INFO - 2018-03-28 12:42:26 --> Model Class Initialized
INFO - 2018-03-28 12:42:26 --> Model Class Initialized
INFO - 2018-03-28 12:42:26 --> Model Class Initialized
INFO - 2018-03-28 12:42:26 --> Model Class Initialized
INFO - 2018-03-28 12:42:26 --> Model Class Initialized
INFO - 2018-03-28 12:42:26 --> Model Class Initialized
INFO - 2018-03-28 12:42:26 --> Model Class Initialized
INFO - 2018-03-28 12:42:26 --> Model Class Initialized
INFO - 2018-03-28 12:42:26 --> Model Class Initialized
INFO - 2018-03-28 12:42:26 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 12:42:26 --> Model Class Initialized
INFO - 2018-03-28 12:42:26 --> Final output sent to browser
DEBUG - 2018-03-28 12:42:26 --> Total execution time: 0.2037
DEBUG - 2018-03-28 07:12:26 --> UTF-8 Support Enabled
INFO - 2018-03-28 07:12:26 --> Utf8 Class Initialized
INFO - 2018-03-28 07:12:26 --> URI Class Initialized
INFO - 2018-03-28 07:12:26 --> Router Class Initialized
INFO - 2018-03-28 07:12:26 --> Output Class Initialized
INFO - 2018-03-28 07:12:26 --> Security Class Initialized
DEBUG - 2018-03-28 07:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 07:12:26 --> Input Class Initialized
INFO - 2018-03-28 07:12:26 --> Language Class Initialized
INFO - 2018-03-28 07:12:26 --> Language Class Initialized
INFO - 2018-03-28 07:12:26 --> Config Class Initialized
INFO - 2018-03-28 07:12:26 --> Loader Class Initialized
INFO - 2018-03-28 12:42:26 --> Helper loaded: url_helper
INFO - 2018-03-28 12:42:26 --> Helper loaded: notification_helper
INFO - 2018-03-28 12:42:26 --> Helper loaded: settings_helper
INFO - 2018-03-28 12:42:26 --> Helper loaded: permission_helper
INFO - 2018-03-28 12:42:26 --> Helper loaded: users_helper
INFO - 2018-03-28 12:42:26 --> Database Driver Class Initialized
DEBUG - 2018-03-28 12:42:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 12:42:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 12:42:26 --> Helper loaded: form_helper
INFO - 2018-03-28 12:42:26 --> Form Validation Class Initialized
INFO - 2018-03-28 12:42:26 --> Controller Class Initialized
INFO - 2018-03-28 12:42:26 --> Model Class Initialized
INFO - 2018-03-28 12:42:26 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 12:42:26 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 12:42:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 12:42:26 --> Model Class Initialized
INFO - 2018-03-28 12:42:26 --> Model Class Initialized
INFO - 2018-03-28 12:42:26 --> Model Class Initialized
INFO - 2018-03-28 12:42:26 --> Model Class Initialized
INFO - 2018-03-28 12:42:26 --> Model Class Initialized
INFO - 2018-03-28 12:42:26 --> Model Class Initialized
INFO - 2018-03-28 12:42:26 --> Model Class Initialized
INFO - 2018-03-28 12:42:26 --> Model Class Initialized
INFO - 2018-03-28 12:42:26 --> Model Class Initialized
INFO - 2018-03-28 12:42:26 --> Model Class Initialized
INFO - 2018-03-28 12:42:26 --> Model Class Initialized
INFO - 2018-03-28 12:42:26 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 12:42:26 --> Model Class Initialized
INFO - 2018-03-28 12:42:26 --> Final output sent to browser
DEBUG - 2018-03-28 12:42:26 --> Total execution time: 0.7278
INFO - 2018-03-28 07:12:28 --> Config Class Initialized
INFO - 2018-03-28 07:12:28 --> Hooks Class Initialized
DEBUG - 2018-03-28 07:12:28 --> UTF-8 Support Enabled
INFO - 2018-03-28 07:12:28 --> Utf8 Class Initialized
INFO - 2018-03-28 07:12:28 --> URI Class Initialized
INFO - 2018-03-28 07:12:28 --> Router Class Initialized
INFO - 2018-03-28 07:12:28 --> Output Class Initialized
INFO - 2018-03-28 07:12:28 --> Security Class Initialized
DEBUG - 2018-03-28 07:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 07:12:28 --> Input Class Initialized
INFO - 2018-03-28 07:12:28 --> Language Class Initialized
INFO - 2018-03-28 07:12:28 --> Language Class Initialized
INFO - 2018-03-28 07:12:28 --> Config Class Initialized
INFO - 2018-03-28 07:12:28 --> Loader Class Initialized
INFO - 2018-03-28 12:42:28 --> Helper loaded: url_helper
INFO - 2018-03-28 12:42:28 --> Helper loaded: notification_helper
INFO - 2018-03-28 12:42:28 --> Helper loaded: settings_helper
INFO - 2018-03-28 12:42:28 --> Helper loaded: permission_helper
INFO - 2018-03-28 12:42:28 --> Helper loaded: users_helper
INFO - 2018-03-28 12:42:28 --> Database Driver Class Initialized
DEBUG - 2018-03-28 12:42:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 12:42:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 12:42:28 --> Helper loaded: form_helper
INFO - 2018-03-28 12:42:28 --> Form Validation Class Initialized
INFO - 2018-03-28 12:42:28 --> Controller Class Initialized
INFO - 2018-03-28 12:42:28 --> Model Class Initialized
INFO - 2018-03-28 12:42:28 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 12:42:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 12:42:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 12:42:28 --> Model Class Initialized
INFO - 2018-03-28 12:42:28 --> Model Class Initialized
INFO - 2018-03-28 12:42:28 --> Model Class Initialized
INFO - 2018-03-28 12:42:28 --> Model Class Initialized
INFO - 2018-03-28 12:42:28 --> Model Class Initialized
INFO - 2018-03-28 12:42:28 --> Model Class Initialized
INFO - 2018-03-28 12:42:28 --> Model Class Initialized
INFO - 2018-03-28 12:42:28 --> Model Class Initialized
INFO - 2018-03-28 12:42:28 --> Model Class Initialized
INFO - 2018-03-28 12:42:28 --> Model Class Initialized
INFO - 2018-03-28 12:42:28 --> Model Class Initialized
INFO - 2018-03-28 12:42:28 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 12:42:28 --> Model Class Initialized
INFO - 2018-03-28 12:42:28 --> Final output sent to browser
DEBUG - 2018-03-28 12:42:28 --> Total execution time: 0.3707
INFO - 2018-03-28 07:14:18 --> Config Class Initialized
INFO - 2018-03-28 07:14:18 --> Hooks Class Initialized
DEBUG - 2018-03-28 07:14:18 --> UTF-8 Support Enabled
INFO - 2018-03-28 07:14:18 --> Utf8 Class Initialized
INFO - 2018-03-28 07:14:18 --> URI Class Initialized
INFO - 2018-03-28 07:14:18 --> Router Class Initialized
INFO - 2018-03-28 07:14:18 --> Output Class Initialized
INFO - 2018-03-28 07:14:18 --> Security Class Initialized
DEBUG - 2018-03-28 07:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 07:14:18 --> Input Class Initialized
INFO - 2018-03-28 07:14:18 --> Language Class Initialized
INFO - 2018-03-28 07:14:19 --> Language Class Initialized
INFO - 2018-03-28 07:14:19 --> Config Class Initialized
INFO - 2018-03-28 07:14:19 --> Loader Class Initialized
INFO - 2018-03-28 12:44:19 --> Helper loaded: url_helper
INFO - 2018-03-28 12:44:19 --> Helper loaded: notification_helper
INFO - 2018-03-28 12:44:19 --> Helper loaded: settings_helper
INFO - 2018-03-28 12:44:19 --> Helper loaded: permission_helper
INFO - 2018-03-28 12:44:19 --> Helper loaded: users_helper
INFO - 2018-03-28 12:44:19 --> Database Driver Class Initialized
DEBUG - 2018-03-28 12:44:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 12:44:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 12:44:19 --> Helper loaded: form_helper
INFO - 2018-03-28 12:44:19 --> Form Validation Class Initialized
INFO - 2018-03-28 12:44:19 --> Controller Class Initialized
INFO - 2018-03-28 12:44:19 --> Model Class Initialized
INFO - 2018-03-28 12:44:19 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 12:44:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 12:44:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 12:44:19 --> Model Class Initialized
INFO - 2018-03-28 12:44:19 --> Model Class Initialized
INFO - 2018-03-28 12:44:19 --> Model Class Initialized
INFO - 2018-03-28 12:44:19 --> Model Class Initialized
INFO - 2018-03-28 12:44:19 --> Model Class Initialized
INFO - 2018-03-28 12:44:19 --> Model Class Initialized
INFO - 2018-03-28 12:44:19 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 12:44:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-28 12:44:19 --> Final output sent to browser
DEBUG - 2018-03-28 12:44:19 --> Total execution time: 0.9651
INFO - 2018-03-28 07:14:20 --> Config Class Initialized
INFO - 2018-03-28 07:14:20 --> Hooks Class Initialized
DEBUG - 2018-03-28 07:14:20 --> UTF-8 Support Enabled
INFO - 2018-03-28 07:14:20 --> Utf8 Class Initialized
INFO - 2018-03-28 07:14:20 --> URI Class Initialized
INFO - 2018-03-28 07:14:20 --> Router Class Initialized
INFO - 2018-03-28 07:14:20 --> Output Class Initialized
INFO - 2018-03-28 07:14:20 --> Security Class Initialized
DEBUG - 2018-03-28 07:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 07:14:20 --> Input Class Initialized
INFO - 2018-03-28 07:14:20 --> Language Class Initialized
INFO - 2018-03-28 07:14:20 --> Language Class Initialized
INFO - 2018-03-28 07:14:20 --> Config Class Initialized
INFO - 2018-03-28 07:14:20 --> Loader Class Initialized
INFO - 2018-03-28 12:44:20 --> Helper loaded: url_helper
INFO - 2018-03-28 12:44:20 --> Helper loaded: notification_helper
INFO - 2018-03-28 12:44:20 --> Helper loaded: settings_helper
INFO - 2018-03-28 12:44:20 --> Helper loaded: permission_helper
INFO - 2018-03-28 12:44:20 --> Helper loaded: users_helper
INFO - 2018-03-28 12:44:20 --> Database Driver Class Initialized
DEBUG - 2018-03-28 12:44:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 12:44:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 12:44:20 --> Helper loaded: form_helper
INFO - 2018-03-28 12:44:20 --> Form Validation Class Initialized
INFO - 2018-03-28 12:44:20 --> Controller Class Initialized
INFO - 2018-03-28 12:44:20 --> Model Class Initialized
INFO - 2018-03-28 12:44:20 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 12:44:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 12:44:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 12:44:20 --> Model Class Initialized
INFO - 2018-03-28 12:44:20 --> Model Class Initialized
INFO - 2018-03-28 12:44:20 --> Model Class Initialized
INFO - 2018-03-28 12:44:20 --> Model Class Initialized
INFO - 2018-03-28 12:44:20 --> Model Class Initialized
INFO - 2018-03-28 12:44:20 --> Model Class Initialized
INFO - 2018-03-28 07:14:20 --> Config Class Initialized
INFO - 2018-03-28 07:14:20 --> Hooks Class Initialized
INFO - 2018-03-28 12:44:20 --> Model Class Initialized
DEBUG - 2018-03-28 07:14:20 --> UTF-8 Support Enabled
INFO - 2018-03-28 07:14:20 --> Utf8 Class Initialized
INFO - 2018-03-28 07:14:20 --> URI Class Initialized
INFO - 2018-03-28 07:14:20 --> Router Class Initialized
INFO - 2018-03-28 07:14:20 --> Output Class Initialized
INFO - 2018-03-28 07:14:20 --> Security Class Initialized
DEBUG - 2018-03-28 07:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 07:14:20 --> Input Class Initialized
INFO - 2018-03-28 07:14:20 --> Language Class Initialized
INFO - 2018-03-28 12:44:20 --> Model Class Initialized
INFO - 2018-03-28 12:44:20 --> Model Class Initialized
INFO - 2018-03-28 07:14:20 --> Language Class Initialized
INFO - 2018-03-28 07:14:20 --> Config Class Initialized
INFO - 2018-03-28 07:14:20 --> Loader Class Initialized
INFO - 2018-03-28 12:44:20 --> Helper loaded: url_helper
INFO - 2018-03-28 12:44:20 --> Model Class Initialized
INFO - 2018-03-28 12:44:20 --> Helper loaded: notification_helper
INFO - 2018-03-28 12:44:20 --> Helper loaded: settings_helper
INFO - 2018-03-28 12:44:20 --> Helper loaded: permission_helper
INFO - 2018-03-28 12:44:20 --> Helper loaded: users_helper
INFO - 2018-03-28 12:44:20 --> Database Driver Class Initialized
DEBUG - 2018-03-28 12:44:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 12:44:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 12:44:20 --> Helper loaded: form_helper
INFO - 2018-03-28 12:44:20 --> Form Validation Class Initialized
INFO - 2018-03-28 12:44:20 --> Controller Class Initialized
INFO - 2018-03-28 12:44:20 --> Model Class Initialized
INFO - 2018-03-28 12:44:20 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 12:44:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 12:44:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 12:44:20 --> Model Class Initialized
INFO - 2018-03-28 12:44:20 --> Model Class Initialized
INFO - 2018-03-28 12:44:20 --> Model Class Initialized
INFO - 2018-03-28 12:44:20 --> Model Class Initialized
INFO - 2018-03-28 12:44:20 --> Model Class Initialized
INFO - 2018-03-28 12:44:20 --> Model Class Initialized
INFO - 2018-03-28 12:44:20 --> Model Class Initialized
INFO - 2018-03-28 12:44:20 --> Model Class Initialized
INFO - 2018-03-28 12:44:20 --> Model Class Initialized
INFO - 2018-03-28 12:44:20 --> Model Class Initialized
INFO - 2018-03-28 12:44:20 --> Model Class Initialized
INFO - 2018-03-28 12:44:20 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 12:44:20 --> Model Class Initialized
INFO - 2018-03-28 12:44:20 --> Final output sent to browser
DEBUG - 2018-03-28 12:44:20 --> Total execution time: 0.1144
INFO - 2018-03-28 12:44:20 --> Model Class Initialized
INFO - 2018-03-28 12:44:20 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 12:44:20 --> Model Class Initialized
INFO - 2018-03-28 12:44:21 --> Final output sent to browser
DEBUG - 2018-03-28 12:44:21 --> Total execution time: 0.7714
INFO - 2018-03-28 07:14:23 --> Config Class Initialized
INFO - 2018-03-28 07:14:23 --> Hooks Class Initialized
DEBUG - 2018-03-28 07:14:23 --> UTF-8 Support Enabled
INFO - 2018-03-28 07:14:23 --> Utf8 Class Initialized
INFO - 2018-03-28 07:14:23 --> URI Class Initialized
INFO - 2018-03-28 07:14:23 --> Router Class Initialized
INFO - 2018-03-28 07:14:23 --> Output Class Initialized
INFO - 2018-03-28 07:14:23 --> Security Class Initialized
DEBUG - 2018-03-28 07:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 07:14:23 --> Input Class Initialized
INFO - 2018-03-28 07:14:23 --> Language Class Initialized
INFO - 2018-03-28 07:14:23 --> Language Class Initialized
INFO - 2018-03-28 07:14:23 --> Config Class Initialized
INFO - 2018-03-28 07:14:23 --> Loader Class Initialized
INFO - 2018-03-28 12:44:23 --> Helper loaded: url_helper
INFO - 2018-03-28 12:44:23 --> Helper loaded: notification_helper
INFO - 2018-03-28 12:44:23 --> Helper loaded: settings_helper
INFO - 2018-03-28 12:44:23 --> Helper loaded: permission_helper
INFO - 2018-03-28 12:44:23 --> Helper loaded: users_helper
INFO - 2018-03-28 12:44:24 --> Database Driver Class Initialized
DEBUG - 2018-03-28 12:44:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 12:44:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 12:44:24 --> Helper loaded: form_helper
INFO - 2018-03-28 12:44:24 --> Form Validation Class Initialized
INFO - 2018-03-28 12:44:24 --> Controller Class Initialized
INFO - 2018-03-28 12:44:24 --> Model Class Initialized
INFO - 2018-03-28 12:44:24 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 12:44:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 12:44:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 12:44:24 --> Model Class Initialized
INFO - 2018-03-28 12:44:24 --> Model Class Initialized
INFO - 2018-03-28 12:44:24 --> Model Class Initialized
INFO - 2018-03-28 12:44:24 --> Model Class Initialized
INFO - 2018-03-28 12:44:24 --> Model Class Initialized
INFO - 2018-03-28 12:44:24 --> Model Class Initialized
INFO - 2018-03-28 12:44:24 --> Model Class Initialized
INFO - 2018-03-28 12:44:24 --> Model Class Initialized
INFO - 2018-03-28 12:44:24 --> Model Class Initialized
INFO - 2018-03-28 12:44:24 --> Model Class Initialized
INFO - 2018-03-28 12:44:24 --> Model Class Initialized
INFO - 2018-03-28 12:44:24 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 12:44:24 --> Model Class Initialized
INFO - 2018-03-28 07:14:24 --> Config Class Initialized
INFO - 2018-03-28 07:14:24 --> Hooks Class Initialized
INFO - 2018-03-28 12:44:24 --> Final output sent to browser
DEBUG - 2018-03-28 12:44:24 --> Total execution time: 0.6627
DEBUG - 2018-03-28 07:14:24 --> UTF-8 Support Enabled
INFO - 2018-03-28 07:14:24 --> Utf8 Class Initialized
INFO - 2018-03-28 07:14:24 --> URI Class Initialized
INFO - 2018-03-28 07:14:24 --> Router Class Initialized
INFO - 2018-03-28 07:14:24 --> Output Class Initialized
INFO - 2018-03-28 07:14:24 --> Security Class Initialized
DEBUG - 2018-03-28 07:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 07:14:24 --> Input Class Initialized
INFO - 2018-03-28 07:14:24 --> Language Class Initialized
INFO - 2018-03-28 07:14:24 --> Language Class Initialized
INFO - 2018-03-28 07:14:24 --> Config Class Initialized
INFO - 2018-03-28 07:14:24 --> Loader Class Initialized
INFO - 2018-03-28 12:44:24 --> Helper loaded: url_helper
INFO - 2018-03-28 12:44:24 --> Helper loaded: notification_helper
INFO - 2018-03-28 12:44:24 --> Helper loaded: settings_helper
INFO - 2018-03-28 12:44:24 --> Helper loaded: permission_helper
INFO - 2018-03-28 12:44:24 --> Helper loaded: users_helper
INFO - 2018-03-28 12:44:25 --> Database Driver Class Initialized
DEBUG - 2018-03-28 12:44:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 12:44:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 12:44:25 --> Helper loaded: form_helper
INFO - 2018-03-28 12:44:25 --> Form Validation Class Initialized
INFO - 2018-03-28 12:44:25 --> Controller Class Initialized
INFO - 2018-03-28 12:44:25 --> Model Class Initialized
INFO - 2018-03-28 12:44:25 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 12:44:25 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 12:44:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 12:44:25 --> Model Class Initialized
INFO - 2018-03-28 12:44:25 --> Model Class Initialized
INFO - 2018-03-28 12:44:25 --> Model Class Initialized
INFO - 2018-03-28 12:44:25 --> Model Class Initialized
INFO - 2018-03-28 12:44:25 --> Model Class Initialized
INFO - 2018-03-28 12:44:25 --> Model Class Initialized
INFO - 2018-03-28 12:44:25 --> Model Class Initialized
INFO - 2018-03-28 12:44:25 --> Model Class Initialized
INFO - 2018-03-28 12:44:25 --> Model Class Initialized
INFO - 2018-03-28 12:44:25 --> Model Class Initialized
INFO - 2018-03-28 12:44:25 --> Model Class Initialized
INFO - 2018-03-28 12:44:25 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 12:44:25 --> Model Class Initialized
INFO - 2018-03-28 12:44:25 --> Final output sent to browser
DEBUG - 2018-03-28 12:44:25 --> Total execution time: 1.2483
INFO - 2018-03-28 07:14:25 --> Config Class Initialized
INFO - 2018-03-28 07:14:25 --> Hooks Class Initialized
DEBUG - 2018-03-28 07:14:25 --> UTF-8 Support Enabled
INFO - 2018-03-28 07:14:25 --> Utf8 Class Initialized
INFO - 2018-03-28 07:14:25 --> URI Class Initialized
INFO - 2018-03-28 07:14:25 --> Router Class Initialized
INFO - 2018-03-28 07:14:25 --> Output Class Initialized
INFO - 2018-03-28 07:14:25 --> Security Class Initialized
DEBUG - 2018-03-28 07:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 07:14:25 --> Input Class Initialized
INFO - 2018-03-28 07:14:25 --> Language Class Initialized
INFO - 2018-03-28 07:14:25 --> Language Class Initialized
INFO - 2018-03-28 07:14:25 --> Config Class Initialized
INFO - 2018-03-28 07:14:25 --> Loader Class Initialized
INFO - 2018-03-28 12:44:25 --> Helper loaded: url_helper
INFO - 2018-03-28 12:44:25 --> Helper loaded: notification_helper
INFO - 2018-03-28 12:44:25 --> Helper loaded: settings_helper
INFO - 2018-03-28 12:44:25 --> Helper loaded: permission_helper
INFO - 2018-03-28 12:44:25 --> Helper loaded: users_helper
INFO - 2018-03-28 12:44:25 --> Database Driver Class Initialized
DEBUG - 2018-03-28 12:44:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 12:44:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 12:44:25 --> Helper loaded: form_helper
INFO - 2018-03-28 12:44:25 --> Form Validation Class Initialized
INFO - 2018-03-28 12:44:25 --> Controller Class Initialized
INFO - 2018-03-28 12:44:25 --> Model Class Initialized
INFO - 2018-03-28 12:44:25 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 12:44:25 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 12:44:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 12:44:25 --> Model Class Initialized
INFO - 2018-03-28 12:44:25 --> Model Class Initialized
INFO - 2018-03-28 12:44:25 --> Model Class Initialized
INFO - 2018-03-28 12:44:25 --> Model Class Initialized
INFO - 2018-03-28 12:44:25 --> Model Class Initialized
INFO - 2018-03-28 12:44:25 --> Model Class Initialized
INFO - 2018-03-28 12:44:25 --> Model Class Initialized
INFO - 2018-03-28 12:44:25 --> Model Class Initialized
INFO - 2018-03-28 12:44:25 --> Model Class Initialized
INFO - 2018-03-28 12:44:25 --> Model Class Initialized
INFO - 2018-03-28 12:44:25 --> Model Class Initialized
INFO - 2018-03-28 12:44:25 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 12:44:25 --> Model Class Initialized
INFO - 2018-03-28 12:44:25 --> Final output sent to browser
DEBUG - 2018-03-28 12:44:25 --> Total execution time: 0.1903
INFO - 2018-03-28 07:14:28 --> Config Class Initialized
INFO - 2018-03-28 07:14:28 --> Hooks Class Initialized
DEBUG - 2018-03-28 07:14:28 --> UTF-8 Support Enabled
INFO - 2018-03-28 07:14:28 --> Utf8 Class Initialized
INFO - 2018-03-28 07:14:28 --> URI Class Initialized
INFO - 2018-03-28 07:14:28 --> Router Class Initialized
INFO - 2018-03-28 07:14:28 --> Output Class Initialized
INFO - 2018-03-28 07:14:28 --> Security Class Initialized
DEBUG - 2018-03-28 07:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 07:14:28 --> Input Class Initialized
INFO - 2018-03-28 07:14:28 --> Language Class Initialized
INFO - 2018-03-28 07:14:28 --> Language Class Initialized
INFO - 2018-03-28 07:14:28 --> Config Class Initialized
INFO - 2018-03-28 07:14:28 --> Loader Class Initialized
INFO - 2018-03-28 12:44:28 --> Helper loaded: url_helper
INFO - 2018-03-28 12:44:28 --> Helper loaded: notification_helper
INFO - 2018-03-28 12:44:28 --> Helper loaded: settings_helper
INFO - 2018-03-28 12:44:28 --> Helper loaded: permission_helper
INFO - 2018-03-28 12:44:28 --> Helper loaded: users_helper
INFO - 2018-03-28 12:44:28 --> Database Driver Class Initialized
DEBUG - 2018-03-28 12:44:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 12:44:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 12:44:29 --> Helper loaded: form_helper
INFO - 2018-03-28 12:44:29 --> Form Validation Class Initialized
INFO - 2018-03-28 12:44:29 --> Controller Class Initialized
INFO - 2018-03-28 12:44:29 --> Model Class Initialized
INFO - 2018-03-28 12:44:29 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 12:44:29 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 12:44:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 12:44:29 --> Model Class Initialized
INFO - 2018-03-28 12:44:29 --> Model Class Initialized
INFO - 2018-03-28 12:44:29 --> Model Class Initialized
INFO - 2018-03-28 12:44:29 --> Model Class Initialized
INFO - 2018-03-28 12:44:29 --> Final output sent to browser
DEBUG - 2018-03-28 12:44:29 --> Total execution time: 1.1185
INFO - 2018-03-28 07:14:31 --> Config Class Initialized
INFO - 2018-03-28 07:14:31 --> Hooks Class Initialized
DEBUG - 2018-03-28 07:14:31 --> UTF-8 Support Enabled
INFO - 2018-03-28 07:14:31 --> Utf8 Class Initialized
INFO - 2018-03-28 07:14:31 --> URI Class Initialized
INFO - 2018-03-28 07:14:31 --> Router Class Initialized
INFO - 2018-03-28 07:14:31 --> Output Class Initialized
INFO - 2018-03-28 07:14:31 --> Security Class Initialized
DEBUG - 2018-03-28 07:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 07:14:31 --> Input Class Initialized
INFO - 2018-03-28 07:14:31 --> Language Class Initialized
INFO - 2018-03-28 07:14:31 --> Language Class Initialized
INFO - 2018-03-28 07:14:31 --> Config Class Initialized
INFO - 2018-03-28 07:14:31 --> Loader Class Initialized
INFO - 2018-03-28 12:44:31 --> Helper loaded: url_helper
INFO - 2018-03-28 12:44:31 --> Helper loaded: notification_helper
INFO - 2018-03-28 12:44:31 --> Helper loaded: settings_helper
INFO - 2018-03-28 12:44:31 --> Helper loaded: permission_helper
INFO - 2018-03-28 12:44:31 --> Helper loaded: users_helper
INFO - 2018-03-28 12:44:31 --> Database Driver Class Initialized
DEBUG - 2018-03-28 12:44:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 12:44:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 12:44:31 --> Helper loaded: form_helper
INFO - 2018-03-28 12:44:31 --> Form Validation Class Initialized
INFO - 2018-03-28 12:44:31 --> Controller Class Initialized
INFO - 2018-03-28 12:44:31 --> Model Class Initialized
INFO - 2018-03-28 12:44:31 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 12:44:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 12:44:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 12:44:31 --> Model Class Initialized
INFO - 2018-03-28 12:44:31 --> Model Class Initialized
INFO - 2018-03-28 12:44:31 --> Model Class Initialized
INFO - 2018-03-28 12:44:31 --> Model Class Initialized
INFO - 2018-03-28 12:44:31 --> Final output sent to browser
DEBUG - 2018-03-28 12:44:31 --> Total execution time: 0.5353
INFO - 2018-03-28 07:14:35 --> Config Class Initialized
INFO - 2018-03-28 07:14:35 --> Hooks Class Initialized
DEBUG - 2018-03-28 07:14:35 --> UTF-8 Support Enabled
INFO - 2018-03-28 07:14:35 --> Utf8 Class Initialized
INFO - 2018-03-28 07:14:35 --> URI Class Initialized
INFO - 2018-03-28 07:14:35 --> Config Class Initialized
INFO - 2018-03-28 07:14:35 --> Hooks Class Initialized
DEBUG - 2018-03-28 07:14:35 --> UTF-8 Support Enabled
INFO - 2018-03-28 07:14:35 --> Utf8 Class Initialized
INFO - 2018-03-28 07:14:35 --> URI Class Initialized
INFO - 2018-03-28 07:14:35 --> Router Class Initialized
INFO - 2018-03-28 07:14:35 --> Router Class Initialized
INFO - 2018-03-28 07:14:35 --> Output Class Initialized
INFO - 2018-03-28 07:14:35 --> Security Class Initialized
DEBUG - 2018-03-28 07:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 07:14:35 --> Input Class Initialized
INFO - 2018-03-28 07:14:35 --> Output Class Initialized
INFO - 2018-03-28 07:14:36 --> Language Class Initialized
INFO - 2018-03-28 07:14:36 --> Security Class Initialized
DEBUG - 2018-03-28 07:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 07:14:36 --> Input Class Initialized
INFO - 2018-03-28 07:14:36 --> Language Class Initialized
INFO - 2018-03-28 07:14:36 --> Language Class Initialized
INFO - 2018-03-28 07:14:36 --> Config Class Initialized
INFO - 2018-03-28 07:14:36 --> Loader Class Initialized
INFO - 2018-03-28 12:44:36 --> Helper loaded: url_helper
INFO - 2018-03-28 12:44:36 --> Helper loaded: notification_helper
INFO - 2018-03-28 12:44:36 --> Helper loaded: settings_helper
INFO - 2018-03-28 12:44:36 --> Helper loaded: permission_helper
INFO - 2018-03-28 12:44:36 --> Helper loaded: users_helper
INFO - 2018-03-28 07:14:36 --> Language Class Initialized
INFO - 2018-03-28 07:14:36 --> Config Class Initialized
INFO - 2018-03-28 07:14:36 --> Loader Class Initialized
INFO - 2018-03-28 12:44:36 --> Helper loaded: url_helper
INFO - 2018-03-28 12:44:36 --> Helper loaded: notification_helper
INFO - 2018-03-28 12:44:36 --> Database Driver Class Initialized
DEBUG - 2018-03-28 12:44:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 12:44:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 12:44:36 --> Helper loaded: settings_helper
INFO - 2018-03-28 12:44:36 --> Helper loaded: form_helper
INFO - 2018-03-28 12:44:36 --> Form Validation Class Initialized
INFO - 2018-03-28 12:44:36 --> Controller Class Initialized
INFO - 2018-03-28 12:44:36 --> Helper loaded: permission_helper
INFO - 2018-03-28 12:44:36 --> Model Class Initialized
INFO - 2018-03-28 12:44:36 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 12:44:36 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 12:44:36 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 12:44:36 --> Model Class Initialized
INFO - 2018-03-28 12:44:36 --> Model Class Initialized
INFO - 2018-03-28 12:44:36 --> Model Class Initialized
INFO - 2018-03-28 12:44:36 --> Model Class Initialized
INFO - 2018-03-28 12:44:36 --> Final output sent to browser
DEBUG - 2018-03-28 12:44:36 --> Total execution time: 1.3300
INFO - 2018-03-28 12:44:37 --> Helper loaded: users_helper
INFO - 2018-03-28 12:44:37 --> Database Driver Class Initialized
DEBUG - 2018-03-28 12:44:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 12:44:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 07:14:38 --> Config Class Initialized
INFO - 2018-03-28 07:14:38 --> Hooks Class Initialized
DEBUG - 2018-03-28 07:14:38 --> UTF-8 Support Enabled
INFO - 2018-03-28 07:14:38 --> Utf8 Class Initialized
INFO - 2018-03-28 07:14:38 --> URI Class Initialized
INFO - 2018-03-28 07:14:38 --> Router Class Initialized
INFO - 2018-03-28 07:14:38 --> Output Class Initialized
INFO - 2018-03-28 07:14:38 --> Security Class Initialized
DEBUG - 2018-03-28 07:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 07:14:38 --> Input Class Initialized
INFO - 2018-03-28 07:14:38 --> Language Class Initialized
INFO - 2018-03-28 07:14:38 --> Language Class Initialized
INFO - 2018-03-28 07:14:38 --> Config Class Initialized
INFO - 2018-03-28 07:14:38 --> Loader Class Initialized
INFO - 2018-03-28 12:44:38 --> Helper loaded: url_helper
INFO - 2018-03-28 12:44:38 --> Helper loaded: notification_helper
INFO - 2018-03-28 12:44:38 --> Helper loaded: settings_helper
INFO - 2018-03-28 12:44:38 --> Helper loaded: permission_helper
INFO - 2018-03-28 12:44:38 --> Helper loaded: users_helper
INFO - 2018-03-28 12:44:38 --> Database Driver Class Initialized
DEBUG - 2018-03-28 12:44:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 12:44:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 12:44:38 --> Helper loaded: form_helper
INFO - 2018-03-28 12:44:38 --> Form Validation Class Initialized
INFO - 2018-03-28 12:44:38 --> Controller Class Initialized
INFO - 2018-03-28 12:44:38 --> Model Class Initialized
INFO - 2018-03-28 12:44:38 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 12:44:38 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 12:44:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 12:44:38 --> Model Class Initialized
INFO - 2018-03-28 12:44:38 --> Model Class Initialized
INFO - 2018-03-28 12:44:38 --> Model Class Initialized
INFO - 2018-03-28 12:44:38 --> Model Class Initialized
INFO - 2018-03-28 12:44:38 --> Model Class Initialized
INFO - 2018-03-28 12:44:38 --> Model Class Initialized
INFO - 2018-03-28 12:44:38 --> Model Class Initialized
INFO - 2018-03-28 12:44:38 --> Model Class Initialized
INFO - 2018-03-28 12:44:38 --> Model Class Initialized
INFO - 2018-03-28 12:44:38 --> Model Class Initialized
INFO - 2018-03-28 12:44:38 --> Model Class Initialized
INFO - 2018-03-28 12:44:38 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 12:44:38 --> Model Class Initialized
INFO - 2018-03-28 12:44:38 --> Final output sent to browser
DEBUG - 2018-03-28 12:44:38 --> Total execution time: 0.1243
INFO - 2018-03-28 12:44:38 --> Helper loaded: form_helper
INFO - 2018-03-28 12:44:38 --> Form Validation Class Initialized
INFO - 2018-03-28 12:44:38 --> Controller Class Initialized
INFO - 2018-03-28 12:44:39 --> Model Class Initialized
INFO - 2018-03-28 12:44:39 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 12:44:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 12:44:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 12:44:39 --> Model Class Initialized
INFO - 2018-03-28 12:44:39 --> Model Class Initialized
INFO - 2018-03-28 12:44:39 --> Model Class Initialized
INFO - 2018-03-28 12:44:39 --> Model Class Initialized
INFO - 2018-03-28 12:44:39 --> Final output sent to browser
DEBUG - 2018-03-28 12:44:39 --> Total execution time: 4.5008
INFO - 2018-03-28 07:14:40 --> Config Class Initialized
INFO - 2018-03-28 07:14:40 --> Hooks Class Initialized
DEBUG - 2018-03-28 07:14:40 --> UTF-8 Support Enabled
INFO - 2018-03-28 07:14:40 --> Utf8 Class Initialized
INFO - 2018-03-28 07:14:40 --> URI Class Initialized
INFO - 2018-03-28 07:14:40 --> Router Class Initialized
INFO - 2018-03-28 07:14:41 --> Output Class Initialized
INFO - 2018-03-28 07:14:41 --> Security Class Initialized
DEBUG - 2018-03-28 07:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 07:14:41 --> Input Class Initialized
INFO - 2018-03-28 07:14:41 --> Language Class Initialized
INFO - 2018-03-28 07:14:41 --> Language Class Initialized
INFO - 2018-03-28 07:14:41 --> Config Class Initialized
INFO - 2018-03-28 07:14:41 --> Loader Class Initialized
INFO - 2018-03-28 12:44:41 --> Helper loaded: url_helper
INFO - 2018-03-28 12:44:42 --> Helper loaded: notification_helper
INFO - 2018-03-28 12:44:42 --> Helper loaded: settings_helper
INFO - 2018-03-28 12:44:42 --> Helper loaded: permission_helper
INFO - 2018-03-28 12:44:42 --> Helper loaded: users_helper
INFO - 2018-03-28 12:44:42 --> Database Driver Class Initialized
DEBUG - 2018-03-28 12:44:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 12:44:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 12:44:42 --> Helper loaded: form_helper
INFO - 2018-03-28 12:44:42 --> Form Validation Class Initialized
INFO - 2018-03-28 12:44:42 --> Controller Class Initialized
INFO - 2018-03-28 12:44:43 --> Model Class Initialized
INFO - 2018-03-28 12:44:43 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 12:44:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 12:44:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 12:44:43 --> Model Class Initialized
INFO - 2018-03-28 12:44:43 --> Model Class Initialized
INFO - 2018-03-28 12:44:43 --> Model Class Initialized
INFO - 2018-03-28 12:44:43 --> Model Class Initialized
INFO - 2018-03-28 12:44:43 --> Model Class Initialized
INFO - 2018-03-28 12:44:43 --> Model Class Initialized
INFO - 2018-03-28 12:44:43 --> Model Class Initialized
INFO - 2018-03-28 12:44:43 --> Model Class Initialized
INFO - 2018-03-28 12:44:43 --> Model Class Initialized
INFO - 2018-03-28 12:44:43 --> Model Class Initialized
INFO - 2018-03-28 12:44:43 --> Model Class Initialized
INFO - 2018-03-28 12:44:43 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 12:44:43 --> Model Class Initialized
INFO - 2018-03-28 12:44:43 --> Final output sent to browser
DEBUG - 2018-03-28 12:44:43 --> Total execution time: 2.7149
INFO - 2018-03-28 07:14:44 --> Config Class Initialized
INFO - 2018-03-28 07:14:44 --> Hooks Class Initialized
DEBUG - 2018-03-28 07:14:45 --> UTF-8 Support Enabled
INFO - 2018-03-28 07:14:45 --> Utf8 Class Initialized
INFO - 2018-03-28 07:14:45 --> URI Class Initialized
INFO - 2018-03-28 07:14:45 --> Router Class Initialized
INFO - 2018-03-28 07:14:45 --> Output Class Initialized
INFO - 2018-03-28 07:14:45 --> Security Class Initialized
DEBUG - 2018-03-28 07:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 07:14:45 --> Input Class Initialized
INFO - 2018-03-28 07:14:45 --> Language Class Initialized
INFO - 2018-03-28 07:14:46 --> Language Class Initialized
INFO - 2018-03-28 07:14:46 --> Config Class Initialized
INFO - 2018-03-28 07:14:46 --> Loader Class Initialized
INFO - 2018-03-28 12:44:46 --> Helper loaded: url_helper
INFO - 2018-03-28 12:44:46 --> Helper loaded: notification_helper
INFO - 2018-03-28 12:44:46 --> Helper loaded: settings_helper
INFO - 2018-03-28 12:44:46 --> Helper loaded: permission_helper
INFO - 2018-03-28 12:44:46 --> Helper loaded: users_helper
INFO - 2018-03-28 12:44:47 --> Database Driver Class Initialized
DEBUG - 2018-03-28 12:44:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 12:44:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 12:44:47 --> Helper loaded: form_helper
INFO - 2018-03-28 12:44:47 --> Form Validation Class Initialized
INFO - 2018-03-28 12:44:47 --> Controller Class Initialized
INFO - 2018-03-28 12:44:47 --> Model Class Initialized
INFO - 2018-03-28 12:44:47 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 12:44:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 12:44:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 12:44:47 --> Model Class Initialized
INFO - 2018-03-28 12:44:47 --> Model Class Initialized
INFO - 2018-03-28 12:44:47 --> Model Class Initialized
INFO - 2018-03-28 12:44:47 --> Model Class Initialized
INFO - 2018-03-28 12:44:47 --> Model Class Initialized
INFO - 2018-03-28 12:44:47 --> Model Class Initialized
INFO - 2018-03-28 12:44:47 --> Model Class Initialized
INFO - 2018-03-28 12:44:47 --> Model Class Initialized
INFO - 2018-03-28 12:44:47 --> Model Class Initialized
INFO - 2018-03-28 12:44:47 --> Model Class Initialized
INFO - 2018-03-28 12:44:47 --> Model Class Initialized
INFO - 2018-03-28 12:44:47 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 12:44:47 --> Model Class Initialized
INFO - 2018-03-28 12:44:47 --> Final output sent to browser
DEBUG - 2018-03-28 12:44:47 --> Total execution time: 2.7469
INFO - 2018-03-28 09:16:03 --> Config Class Initialized
INFO - 2018-03-28 09:16:03 --> Hooks Class Initialized
DEBUG - 2018-03-28 09:16:03 --> UTF-8 Support Enabled
INFO - 2018-03-28 09:16:03 --> Utf8 Class Initialized
INFO - 2018-03-28 09:16:03 --> URI Class Initialized
INFO - 2018-03-28 09:16:03 --> Router Class Initialized
INFO - 2018-03-28 09:16:03 --> Output Class Initialized
INFO - 2018-03-28 09:16:03 --> Security Class Initialized
DEBUG - 2018-03-28 09:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 09:16:03 --> Input Class Initialized
INFO - 2018-03-28 09:16:03 --> Language Class Initialized
INFO - 2018-03-28 09:16:03 --> Language Class Initialized
INFO - 2018-03-28 09:16:03 --> Config Class Initialized
INFO - 2018-03-28 09:16:03 --> Loader Class Initialized
INFO - 2018-03-28 14:46:03 --> Helper loaded: url_helper
INFO - 2018-03-28 14:46:03 --> Helper loaded: notification_helper
INFO - 2018-03-28 14:46:03 --> Helper loaded: settings_helper
INFO - 2018-03-28 14:46:03 --> Helper loaded: permission_helper
INFO - 2018-03-28 14:46:03 --> Helper loaded: users_helper
INFO - 2018-03-28 14:46:03 --> Database Driver Class Initialized
DEBUG - 2018-03-28 14:46:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 14:46:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 14:46:03 --> Helper loaded: form_helper
INFO - 2018-03-28 14:46:03 --> Form Validation Class Initialized
INFO - 2018-03-28 14:46:03 --> Controller Class Initialized
INFO - 2018-03-28 14:46:03 --> Model Class Initialized
INFO - 2018-03-28 14:46:03 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 14:46:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 14:46:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 14:46:03 --> Model Class Initialized
INFO - 2018-03-28 14:46:03 --> Model Class Initialized
INFO - 2018-03-28 14:46:03 --> Model Class Initialized
INFO - 2018-03-28 14:46:03 --> Model Class Initialized
INFO - 2018-03-28 14:46:03 --> Model Class Initialized
INFO - 2018-03-28 14:46:03 --> Model Class Initialized
INFO - 2018-03-28 14:46:03 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 14:46:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-28 14:46:03 --> Final output sent to browser
DEBUG - 2018-03-28 14:46:03 --> Total execution time: 0.1157
INFO - 2018-03-28 09:16:04 --> Config Class Initialized
INFO - 2018-03-28 09:16:04 --> Hooks Class Initialized
DEBUG - 2018-03-28 09:16:04 --> UTF-8 Support Enabled
INFO - 2018-03-28 09:16:04 --> Utf8 Class Initialized
INFO - 2018-03-28 09:16:04 --> URI Class Initialized
INFO - 2018-03-28 09:16:04 --> Router Class Initialized
INFO - 2018-03-28 09:16:04 --> Output Class Initialized
INFO - 2018-03-28 09:16:04 --> Security Class Initialized
DEBUG - 2018-03-28 09:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 09:16:04 --> Input Class Initialized
INFO - 2018-03-28 09:16:04 --> Language Class Initialized
INFO - 2018-03-28 09:16:04 --> Language Class Initialized
INFO - 2018-03-28 09:16:04 --> Config Class Initialized
INFO - 2018-03-28 09:16:04 --> Loader Class Initialized
INFO - 2018-03-28 14:46:04 --> Helper loaded: url_helper
INFO - 2018-03-28 14:46:04 --> Helper loaded: notification_helper
INFO - 2018-03-28 14:46:04 --> Helper loaded: settings_helper
INFO - 2018-03-28 14:46:04 --> Helper loaded: permission_helper
INFO - 2018-03-28 14:46:04 --> Helper loaded: users_helper
INFO - 2018-03-28 14:46:05 --> Database Driver Class Initialized
DEBUG - 2018-03-28 14:46:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 14:46:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 14:46:05 --> Helper loaded: form_helper
INFO - 2018-03-28 14:46:05 --> Form Validation Class Initialized
INFO - 2018-03-28 14:46:05 --> Controller Class Initialized
INFO - 2018-03-28 14:46:05 --> Model Class Initialized
INFO - 2018-03-28 14:46:05 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 14:46:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 14:46:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 14:46:05 --> Model Class Initialized
INFO - 2018-03-28 14:46:05 --> Model Class Initialized
INFO - 2018-03-28 14:46:05 --> Model Class Initialized
INFO - 2018-03-28 14:46:05 --> Model Class Initialized
INFO - 2018-03-28 14:46:05 --> Model Class Initialized
INFO - 2018-03-28 14:46:05 --> Model Class Initialized
INFO - 2018-03-28 14:46:05 --> Model Class Initialized
INFO - 2018-03-28 14:46:05 --> Model Class Initialized
INFO - 2018-03-28 14:46:05 --> Model Class Initialized
INFO - 2018-03-28 14:46:05 --> Model Class Initialized
INFO - 2018-03-28 14:46:05 --> Model Class Initialized
INFO - 2018-03-28 14:46:05 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 14:46:05 --> Model Class Initialized
INFO - 2018-03-28 14:46:05 --> Final output sent to browser
DEBUG - 2018-03-28 14:46:05 --> Total execution time: 0.6296
INFO - 2018-03-28 09:16:06 --> Config Class Initialized
INFO - 2018-03-28 09:16:06 --> Hooks Class Initialized
DEBUG - 2018-03-28 09:16:06 --> UTF-8 Support Enabled
INFO - 2018-03-28 09:16:06 --> Utf8 Class Initialized
INFO - 2018-03-28 09:16:06 --> URI Class Initialized
INFO - 2018-03-28 09:16:06 --> Router Class Initialized
INFO - 2018-03-28 09:16:07 --> Output Class Initialized
INFO - 2018-03-28 09:16:07 --> Security Class Initialized
DEBUG - 2018-03-28 09:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 09:16:07 --> Input Class Initialized
INFO - 2018-03-28 09:16:07 --> Language Class Initialized
INFO - 2018-03-28 09:16:08 --> Config Class Initialized
INFO - 2018-03-28 09:16:08 --> Hooks Class Initialized
DEBUG - 2018-03-28 09:16:08 --> UTF-8 Support Enabled
INFO - 2018-03-28 09:16:08 --> Utf8 Class Initialized
INFO - 2018-03-28 09:16:08 --> URI Class Initialized
INFO - 2018-03-28 09:16:08 --> Router Class Initialized
INFO - 2018-03-28 09:16:08 --> Output Class Initialized
INFO - 2018-03-28 09:16:08 --> Security Class Initialized
INFO - 2018-03-28 09:16:08 --> Language Class Initialized
INFO - 2018-03-28 09:16:08 --> Config Class Initialized
INFO - 2018-03-28 09:16:08 --> Loader Class Initialized
DEBUG - 2018-03-28 09:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 09:16:08 --> Input Class Initialized
INFO - 2018-03-28 09:16:08 --> Language Class Initialized
INFO - 2018-03-28 14:46:08 --> Helper loaded: url_helper
INFO - 2018-03-28 14:46:08 --> Helper loaded: notification_helper
INFO - 2018-03-28 14:46:08 --> Helper loaded: settings_helper
INFO - 2018-03-28 14:46:08 --> Helper loaded: permission_helper
INFO - 2018-03-28 14:46:08 --> Helper loaded: users_helper
INFO - 2018-03-28 09:16:09 --> Language Class Initialized
INFO - 2018-03-28 09:16:09 --> Config Class Initialized
INFO - 2018-03-28 09:16:09 --> Loader Class Initialized
INFO - 2018-03-28 14:46:09 --> Database Driver Class Initialized
DEBUG - 2018-03-28 14:46:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 14:46:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 14:46:09 --> Helper loaded: form_helper
INFO - 2018-03-28 14:46:09 --> Form Validation Class Initialized
INFO - 2018-03-28 14:46:09 --> Controller Class Initialized
INFO - 2018-03-28 14:46:09 --> Model Class Initialized
INFO - 2018-03-28 14:46:09 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 14:46:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 14:46:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 14:46:09 --> Model Class Initialized
INFO - 2018-03-28 14:46:09 --> Model Class Initialized
INFO - 2018-03-28 14:46:09 --> Model Class Initialized
INFO - 2018-03-28 14:46:09 --> Model Class Initialized
INFO - 2018-03-28 14:46:09 --> Model Class Initialized
INFO - 2018-03-28 14:46:09 --> Model Class Initialized
INFO - 2018-03-28 14:46:09 --> Model Class Initialized
INFO - 2018-03-28 14:46:09 --> Model Class Initialized
INFO - 2018-03-28 14:46:09 --> Model Class Initialized
INFO - 2018-03-28 14:46:09 --> Model Class Initialized
INFO - 2018-03-28 14:46:09 --> Helper loaded: url_helper
INFO - 2018-03-28 14:46:09 --> Model Class Initialized
INFO - 2018-03-28 14:46:09 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 14:46:09 --> Model Class Initialized
INFO - 2018-03-28 14:46:09 --> Final output sent to browser
DEBUG - 2018-03-28 14:46:09 --> Total execution time: 3.0841
INFO - 2018-03-28 14:46:09 --> Helper loaded: notification_helper
INFO - 2018-03-28 14:46:09 --> Helper loaded: settings_helper
INFO - 2018-03-28 14:46:09 --> Helper loaded: permission_helper
INFO - 2018-03-28 14:46:09 --> Helper loaded: users_helper
INFO - 2018-03-28 14:46:09 --> Database Driver Class Initialized
DEBUG - 2018-03-28 14:46:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 14:46:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 14:46:09 --> Helper loaded: form_helper
INFO - 2018-03-28 14:46:09 --> Form Validation Class Initialized
INFO - 2018-03-28 14:46:09 --> Controller Class Initialized
INFO - 2018-03-28 14:46:10 --> Model Class Initialized
INFO - 2018-03-28 14:46:10 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 14:46:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 14:46:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 14:46:10 --> Model Class Initialized
INFO - 2018-03-28 14:46:10 --> Model Class Initialized
INFO - 2018-03-28 14:46:10 --> Model Class Initialized
INFO - 2018-03-28 14:46:10 --> Model Class Initialized
INFO - 2018-03-28 14:46:10 --> Model Class Initialized
INFO - 2018-03-28 14:46:10 --> Model Class Initialized
INFO - 2018-03-28 14:46:10 --> Model Class Initialized
INFO - 2018-03-28 14:46:10 --> Model Class Initialized
INFO - 2018-03-28 14:46:10 --> Model Class Initialized
INFO - 2018-03-28 14:46:10 --> Model Class Initialized
INFO - 2018-03-28 14:46:10 --> Model Class Initialized
INFO - 2018-03-28 14:46:10 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 14:46:10 --> Model Class Initialized
INFO - 2018-03-28 14:46:10 --> Final output sent to browser
DEBUG - 2018-03-28 14:46:10 --> Total execution time: 2.2987
INFO - 2018-03-28 09:16:13 --> Config Class Initialized
INFO - 2018-03-28 09:16:13 --> Hooks Class Initialized
DEBUG - 2018-03-28 09:16:14 --> UTF-8 Support Enabled
INFO - 2018-03-28 09:16:14 --> Utf8 Class Initialized
INFO - 2018-03-28 09:16:14 --> URI Class Initialized
INFO - 2018-03-28 09:16:14 --> Router Class Initialized
INFO - 2018-03-28 09:16:14 --> Output Class Initialized
INFO - 2018-03-28 09:16:14 --> Security Class Initialized
DEBUG - 2018-03-28 09:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 09:16:14 --> Input Class Initialized
INFO - 2018-03-28 09:16:14 --> Language Class Initialized
INFO - 2018-03-28 09:16:14 --> Language Class Initialized
INFO - 2018-03-28 09:16:14 --> Config Class Initialized
INFO - 2018-03-28 09:16:14 --> Loader Class Initialized
INFO - 2018-03-28 14:46:14 --> Helper loaded: url_helper
INFO - 2018-03-28 14:46:14 --> Helper loaded: notification_helper
INFO - 2018-03-28 14:46:14 --> Helper loaded: settings_helper
INFO - 2018-03-28 14:46:14 --> Helper loaded: permission_helper
INFO - 2018-03-28 14:46:14 --> Helper loaded: users_helper
INFO - 2018-03-28 14:46:14 --> Database Driver Class Initialized
DEBUG - 2018-03-28 14:46:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 14:46:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 14:46:14 --> Helper loaded: form_helper
INFO - 2018-03-28 14:46:14 --> Form Validation Class Initialized
INFO - 2018-03-28 14:46:14 --> Controller Class Initialized
INFO - 2018-03-28 14:46:14 --> Model Class Initialized
INFO - 2018-03-28 14:46:14 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 14:46:14 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 14:46:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 14:46:14 --> Model Class Initialized
INFO - 2018-03-28 14:46:14 --> Model Class Initialized
INFO - 2018-03-28 14:46:14 --> Model Class Initialized
INFO - 2018-03-28 14:46:14 --> Model Class Initialized
INFO - 2018-03-28 14:46:14 --> Model Class Initialized
INFO - 2018-03-28 14:46:14 --> Model Class Initialized
INFO - 2018-03-28 14:46:14 --> Model Class Initialized
INFO - 2018-03-28 14:46:14 --> Model Class Initialized
INFO - 2018-03-28 14:46:14 --> Model Class Initialized
INFO - 2018-03-28 14:46:14 --> Model Class Initialized
INFO - 2018-03-28 14:46:14 --> Model Class Initialized
INFO - 2018-03-28 14:46:14 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 14:46:14 --> Model Class Initialized
INFO - 2018-03-28 14:46:14 --> Final output sent to browser
DEBUG - 2018-03-28 14:46:14 --> Total execution time: 0.1639
INFO - 2018-03-28 09:19:21 --> Config Class Initialized
INFO - 2018-03-28 09:19:21 --> Hooks Class Initialized
DEBUG - 2018-03-28 09:19:21 --> UTF-8 Support Enabled
INFO - 2018-03-28 09:19:21 --> Utf8 Class Initialized
INFO - 2018-03-28 09:19:22 --> URI Class Initialized
INFO - 2018-03-28 09:19:22 --> Router Class Initialized
INFO - 2018-03-28 09:19:22 --> Output Class Initialized
INFO - 2018-03-28 09:19:22 --> Security Class Initialized
DEBUG - 2018-03-28 09:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 09:19:22 --> Input Class Initialized
INFO - 2018-03-28 09:19:22 --> Language Class Initialized
INFO - 2018-03-28 09:19:22 --> Language Class Initialized
INFO - 2018-03-28 09:19:22 --> Config Class Initialized
INFO - 2018-03-28 09:19:22 --> Loader Class Initialized
INFO - 2018-03-28 14:49:22 --> Helper loaded: url_helper
INFO - 2018-03-28 14:49:22 --> Helper loaded: notification_helper
INFO - 2018-03-28 14:49:22 --> Helper loaded: settings_helper
INFO - 2018-03-28 14:49:22 --> Helper loaded: permission_helper
INFO - 2018-03-28 14:49:22 --> Helper loaded: users_helper
INFO - 2018-03-28 14:49:22 --> Database Driver Class Initialized
DEBUG - 2018-03-28 14:49:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 14:49:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 14:49:22 --> Helper loaded: form_helper
INFO - 2018-03-28 14:49:22 --> Form Validation Class Initialized
INFO - 2018-03-28 14:49:22 --> Controller Class Initialized
INFO - 2018-03-28 14:49:22 --> Model Class Initialized
INFO - 2018-03-28 14:49:22 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 14:49:22 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 14:49:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 14:49:22 --> Model Class Initialized
INFO - 2018-03-28 14:49:22 --> Model Class Initialized
INFO - 2018-03-28 14:49:22 --> Model Class Initialized
INFO - 2018-03-28 14:49:22 --> Model Class Initialized
INFO - 2018-03-28 14:49:22 --> Model Class Initialized
INFO - 2018-03-28 14:49:22 --> Model Class Initialized
INFO - 2018-03-28 14:49:22 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 14:49:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-28 14:49:23 --> Final output sent to browser
DEBUG - 2018-03-28 14:49:23 --> Total execution time: 1.1538
INFO - 2018-03-28 09:19:24 --> Config Class Initialized
INFO - 2018-03-28 09:19:24 --> Hooks Class Initialized
DEBUG - 2018-03-28 09:19:24 --> UTF-8 Support Enabled
INFO - 2018-03-28 09:19:24 --> Utf8 Class Initialized
INFO - 2018-03-28 09:19:24 --> URI Class Initialized
INFO - 2018-03-28 09:19:24 --> Router Class Initialized
INFO - 2018-03-28 09:19:24 --> Output Class Initialized
INFO - 2018-03-28 09:19:24 --> Security Class Initialized
DEBUG - 2018-03-28 09:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 09:19:24 --> Input Class Initialized
INFO - 2018-03-28 09:19:24 --> Language Class Initialized
INFO - 2018-03-28 09:19:24 --> Language Class Initialized
INFO - 2018-03-28 09:19:24 --> Config Class Initialized
INFO - 2018-03-28 09:19:24 --> Loader Class Initialized
INFO - 2018-03-28 14:49:24 --> Helper loaded: url_helper
INFO - 2018-03-28 14:49:24 --> Helper loaded: notification_helper
INFO - 2018-03-28 14:49:24 --> Helper loaded: settings_helper
INFO - 2018-03-28 14:49:24 --> Helper loaded: permission_helper
INFO - 2018-03-28 14:49:24 --> Helper loaded: users_helper
INFO - 2018-03-28 14:49:24 --> Database Driver Class Initialized
DEBUG - 2018-03-28 14:49:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 14:49:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 14:49:24 --> Helper loaded: form_helper
INFO - 2018-03-28 14:49:24 --> Form Validation Class Initialized
INFO - 2018-03-28 14:49:24 --> Controller Class Initialized
INFO - 2018-03-28 14:49:24 --> Model Class Initialized
INFO - 2018-03-28 14:49:24 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 14:49:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 14:49:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 14:49:24 --> Model Class Initialized
INFO - 2018-03-28 14:49:24 --> Model Class Initialized
INFO - 2018-03-28 14:49:24 --> Model Class Initialized
INFO - 2018-03-28 14:49:24 --> Model Class Initialized
INFO - 2018-03-28 14:49:24 --> Model Class Initialized
INFO - 2018-03-28 14:49:24 --> Model Class Initialized
INFO - 2018-03-28 14:49:24 --> Model Class Initialized
INFO - 2018-03-28 14:49:24 --> Model Class Initialized
INFO - 2018-03-28 14:49:24 --> Model Class Initialized
INFO - 2018-03-28 14:49:24 --> Model Class Initialized
INFO - 2018-03-28 14:49:24 --> Model Class Initialized
INFO - 2018-03-28 14:49:24 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 14:49:24 --> Model Class Initialized
INFO - 2018-03-28 14:49:24 --> Final output sent to browser
DEBUG - 2018-03-28 14:49:24 --> Total execution time: 0.1370
INFO - 2018-03-28 09:19:25 --> Config Class Initialized
INFO - 2018-03-28 09:19:25 --> Hooks Class Initialized
DEBUG - 2018-03-28 09:19:25 --> UTF-8 Support Enabled
INFO - 2018-03-28 09:19:25 --> Utf8 Class Initialized
INFO - 2018-03-28 09:19:25 --> URI Class Initialized
INFO - 2018-03-28 09:19:25 --> Router Class Initialized
INFO - 2018-03-28 09:19:25 --> Output Class Initialized
INFO - 2018-03-28 09:19:25 --> Security Class Initialized
DEBUG - 2018-03-28 09:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 09:19:25 --> Input Class Initialized
INFO - 2018-03-28 09:19:25 --> Language Class Initialized
INFO - 2018-03-28 09:19:25 --> Language Class Initialized
INFO - 2018-03-28 09:19:25 --> Config Class Initialized
INFO - 2018-03-28 09:19:25 --> Loader Class Initialized
INFO - 2018-03-28 14:49:25 --> Helper loaded: url_helper
INFO - 2018-03-28 14:49:25 --> Helper loaded: notification_helper
INFO - 2018-03-28 14:49:25 --> Helper loaded: settings_helper
INFO - 2018-03-28 14:49:25 --> Helper loaded: permission_helper
INFO - 2018-03-28 14:49:25 --> Helper loaded: users_helper
INFO - 2018-03-28 14:49:25 --> Database Driver Class Initialized
DEBUG - 2018-03-28 14:49:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 14:49:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 14:49:26 --> Helper loaded: form_helper
INFO - 2018-03-28 14:49:26 --> Form Validation Class Initialized
INFO - 2018-03-28 14:49:26 --> Controller Class Initialized
INFO - 2018-03-28 14:49:26 --> Model Class Initialized
INFO - 2018-03-28 14:49:26 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 14:49:26 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 14:49:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 14:49:26 --> Model Class Initialized
INFO - 2018-03-28 14:49:26 --> Model Class Initialized
INFO - 2018-03-28 14:49:26 --> Model Class Initialized
INFO - 2018-03-28 14:49:26 --> Model Class Initialized
INFO - 2018-03-28 14:49:26 --> Model Class Initialized
INFO - 2018-03-28 14:49:26 --> Model Class Initialized
INFO - 2018-03-28 14:49:26 --> Model Class Initialized
INFO - 2018-03-28 14:49:26 --> Model Class Initialized
INFO - 2018-03-28 14:49:26 --> Model Class Initialized
INFO - 2018-03-28 14:49:26 --> Model Class Initialized
INFO - 2018-03-28 14:49:26 --> Model Class Initialized
INFO - 2018-03-28 14:49:26 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 14:49:26 --> Model Class Initialized
INFO - 2018-03-28 14:49:26 --> Final output sent to browser
DEBUG - 2018-03-28 14:49:26 --> Total execution time: 1.8065
INFO - 2018-03-28 09:19:27 --> Config Class Initialized
INFO - 2018-03-28 09:19:27 --> Hooks Class Initialized
DEBUG - 2018-03-28 09:19:27 --> UTF-8 Support Enabled
INFO - 2018-03-28 09:19:27 --> Utf8 Class Initialized
INFO - 2018-03-28 09:19:27 --> URI Class Initialized
INFO - 2018-03-28 09:19:27 --> Router Class Initialized
INFO - 2018-03-28 09:19:27 --> Output Class Initialized
INFO - 2018-03-28 09:19:27 --> Security Class Initialized
DEBUG - 2018-03-28 09:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 09:19:27 --> Input Class Initialized
INFO - 2018-03-28 09:19:27 --> Language Class Initialized
INFO - 2018-03-28 09:19:27 --> Language Class Initialized
INFO - 2018-03-28 09:19:27 --> Config Class Initialized
INFO - 2018-03-28 09:19:27 --> Loader Class Initialized
INFO - 2018-03-28 14:49:27 --> Helper loaded: url_helper
INFO - 2018-03-28 14:49:27 --> Helper loaded: notification_helper
INFO - 2018-03-28 14:49:27 --> Helper loaded: settings_helper
INFO - 2018-03-28 14:49:27 --> Helper loaded: permission_helper
INFO - 2018-03-28 14:49:27 --> Helper loaded: users_helper
INFO - 2018-03-28 14:49:27 --> Database Driver Class Initialized
DEBUG - 2018-03-28 14:49:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 14:49:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 14:49:27 --> Helper loaded: form_helper
INFO - 2018-03-28 14:49:27 --> Form Validation Class Initialized
INFO - 2018-03-28 14:49:27 --> Controller Class Initialized
INFO - 2018-03-28 14:49:27 --> Model Class Initialized
INFO - 2018-03-28 14:49:27 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 14:49:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 14:49:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 14:49:27 --> Model Class Initialized
INFO - 2018-03-28 14:49:27 --> Model Class Initialized
INFO - 2018-03-28 14:49:27 --> Model Class Initialized
INFO - 2018-03-28 14:49:27 --> Model Class Initialized
INFO - 2018-03-28 14:49:27 --> Model Class Initialized
INFO - 2018-03-28 14:49:27 --> Model Class Initialized
INFO - 2018-03-28 14:49:27 --> Model Class Initialized
INFO - 2018-03-28 14:49:27 --> Model Class Initialized
INFO - 2018-03-28 14:49:27 --> Model Class Initialized
INFO - 2018-03-28 14:49:27 --> Model Class Initialized
INFO - 2018-03-28 14:49:27 --> Model Class Initialized
INFO - 2018-03-28 14:49:27 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 14:49:27 --> Model Class Initialized
INFO - 2018-03-28 14:49:27 --> Final output sent to browser
DEBUG - 2018-03-28 14:49:27 --> Total execution time: 0.2744
INFO - 2018-03-28 09:19:30 --> Config Class Initialized
INFO - 2018-03-28 09:19:30 --> Hooks Class Initialized
DEBUG - 2018-03-28 09:19:30 --> UTF-8 Support Enabled
INFO - 2018-03-28 09:19:30 --> Utf8 Class Initialized
INFO - 2018-03-28 09:19:30 --> URI Class Initialized
INFO - 2018-03-28 09:19:30 --> Router Class Initialized
INFO - 2018-03-28 09:19:30 --> Output Class Initialized
INFO - 2018-03-28 09:19:30 --> Security Class Initialized
DEBUG - 2018-03-28 09:19:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 09:19:30 --> Input Class Initialized
INFO - 2018-03-28 09:19:30 --> Language Class Initialized
INFO - 2018-03-28 09:19:30 --> Language Class Initialized
INFO - 2018-03-28 09:19:30 --> Config Class Initialized
INFO - 2018-03-28 09:19:30 --> Loader Class Initialized
INFO - 2018-03-28 14:49:30 --> Helper loaded: url_helper
INFO - 2018-03-28 14:49:30 --> Helper loaded: notification_helper
INFO - 2018-03-28 14:49:30 --> Helper loaded: settings_helper
INFO - 2018-03-28 14:49:30 --> Helper loaded: permission_helper
INFO - 2018-03-28 14:49:30 --> Helper loaded: users_helper
INFO - 2018-03-28 14:49:30 --> Database Driver Class Initialized
DEBUG - 2018-03-28 14:49:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 14:49:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 14:49:30 --> Helper loaded: form_helper
INFO - 2018-03-28 14:49:30 --> Form Validation Class Initialized
INFO - 2018-03-28 14:49:30 --> Controller Class Initialized
INFO - 2018-03-28 14:49:30 --> Model Class Initialized
INFO - 2018-03-28 14:49:30 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 14:49:30 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 14:49:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 14:49:30 --> Model Class Initialized
INFO - 2018-03-28 14:49:30 --> Model Class Initialized
INFO - 2018-03-28 14:49:30 --> Model Class Initialized
INFO - 2018-03-28 14:49:30 --> Model Class Initialized
INFO - 2018-03-28 14:49:30 --> Model Class Initialized
INFO - 2018-03-28 14:49:30 --> Model Class Initialized
INFO - 2018-03-28 14:49:30 --> Model Class Initialized
INFO - 2018-03-28 14:49:30 --> Model Class Initialized
INFO - 2018-03-28 14:49:30 --> Model Class Initialized
INFO - 2018-03-28 14:49:30 --> Model Class Initialized
INFO - 2018-03-28 14:49:30 --> Model Class Initialized
INFO - 2018-03-28 14:49:30 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 14:49:30 --> Model Class Initialized
INFO - 2018-03-28 14:49:30 --> Final output sent to browser
DEBUG - 2018-03-28 14:49:30 --> Total execution time: 0.1449
INFO - 2018-03-28 09:19:31 --> Config Class Initialized
INFO - 2018-03-28 09:19:31 --> Hooks Class Initialized
DEBUG - 2018-03-28 09:19:31 --> UTF-8 Support Enabled
INFO - 2018-03-28 09:19:31 --> Utf8 Class Initialized
INFO - 2018-03-28 09:19:31 --> URI Class Initialized
INFO - 2018-03-28 09:19:31 --> Router Class Initialized
INFO - 2018-03-28 09:19:31 --> Output Class Initialized
INFO - 2018-03-28 09:19:31 --> Security Class Initialized
DEBUG - 2018-03-28 09:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 09:19:31 --> Input Class Initialized
INFO - 2018-03-28 09:19:31 --> Language Class Initialized
INFO - 2018-03-28 09:19:31 --> Language Class Initialized
INFO - 2018-03-28 09:19:31 --> Config Class Initialized
INFO - 2018-03-28 09:19:31 --> Loader Class Initialized
INFO - 2018-03-28 14:49:31 --> Helper loaded: url_helper
INFO - 2018-03-28 14:49:31 --> Helper loaded: notification_helper
INFO - 2018-03-28 14:49:31 --> Helper loaded: settings_helper
INFO - 2018-03-28 14:49:31 --> Helper loaded: permission_helper
INFO - 2018-03-28 14:49:31 --> Helper loaded: users_helper
INFO - 2018-03-28 14:49:31 --> Database Driver Class Initialized
DEBUG - 2018-03-28 14:49:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 14:49:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 14:49:31 --> Helper loaded: form_helper
INFO - 2018-03-28 14:49:31 --> Form Validation Class Initialized
INFO - 2018-03-28 14:49:31 --> Controller Class Initialized
INFO - 2018-03-28 14:49:31 --> Model Class Initialized
INFO - 2018-03-28 14:49:31 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 14:49:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 14:49:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 14:49:31 --> Model Class Initialized
INFO - 2018-03-28 14:49:31 --> Model Class Initialized
INFO - 2018-03-28 14:49:31 --> Model Class Initialized
INFO - 2018-03-28 14:49:31 --> Model Class Initialized
INFO - 2018-03-28 14:49:31 --> Model Class Initialized
INFO - 2018-03-28 14:49:31 --> Model Class Initialized
INFO - 2018-03-28 14:49:31 --> Model Class Initialized
INFO - 2018-03-28 14:49:31 --> Model Class Initialized
INFO - 2018-03-28 14:49:31 --> Model Class Initialized
INFO - 2018-03-28 14:49:31 --> Model Class Initialized
INFO - 2018-03-28 14:49:31 --> Model Class Initialized
INFO - 2018-03-28 14:49:31 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 14:49:31 --> Final output sent to browser
DEBUG - 2018-03-28 14:49:31 --> Total execution time: 0.1326
INFO - 2018-03-28 09:19:37 --> Config Class Initialized
INFO - 2018-03-28 09:19:37 --> Hooks Class Initialized
DEBUG - 2018-03-28 09:19:37 --> UTF-8 Support Enabled
INFO - 2018-03-28 09:19:37 --> Utf8 Class Initialized
INFO - 2018-03-28 09:19:37 --> URI Class Initialized
INFO - 2018-03-28 09:19:37 --> Router Class Initialized
INFO - 2018-03-28 09:19:37 --> Output Class Initialized
INFO - 2018-03-28 09:19:37 --> Security Class Initialized
DEBUG - 2018-03-28 09:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 09:19:37 --> Input Class Initialized
INFO - 2018-03-28 09:19:37 --> Language Class Initialized
INFO - 2018-03-28 09:19:37 --> Language Class Initialized
INFO - 2018-03-28 09:19:37 --> Config Class Initialized
INFO - 2018-03-28 09:19:37 --> Loader Class Initialized
INFO - 2018-03-28 14:49:37 --> Helper loaded: url_helper
INFO - 2018-03-28 14:49:37 --> Helper loaded: notification_helper
INFO - 2018-03-28 14:49:37 --> Helper loaded: settings_helper
INFO - 2018-03-28 14:49:37 --> Helper loaded: permission_helper
INFO - 2018-03-28 14:49:37 --> Helper loaded: users_helper
INFO - 2018-03-28 14:49:37 --> Database Driver Class Initialized
DEBUG - 2018-03-28 14:49:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 14:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 14:49:37 --> Helper loaded: form_helper
INFO - 2018-03-28 14:49:37 --> Form Validation Class Initialized
INFO - 2018-03-28 14:49:37 --> Controller Class Initialized
INFO - 2018-03-28 14:49:37 --> Model Class Initialized
INFO - 2018-03-28 14:49:37 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 14:49:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 14:49:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 14:49:37 --> Model Class Initialized
INFO - 2018-03-28 14:49:37 --> Model Class Initialized
INFO - 2018-03-28 14:49:37 --> Model Class Initialized
INFO - 2018-03-28 14:49:37 --> Model Class Initialized
INFO - 2018-03-28 14:49:37 --> Model Class Initialized
INFO - 2018-03-28 14:49:37 --> Model Class Initialized
INFO - 2018-03-28 14:49:37 --> Model Class Initialized
INFO - 2018-03-28 14:49:37 --> Model Class Initialized
INFO - 2018-03-28 14:49:37 --> Model Class Initialized
INFO - 2018-03-28 14:49:37 --> Model Class Initialized
INFO - 2018-03-28 14:49:37 --> Model Class Initialized
INFO - 2018-03-28 14:49:37 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 14:49:37 --> Final output sent to browser
DEBUG - 2018-03-28 14:49:37 --> Total execution time: 0.1062
INFO - 2018-03-28 09:19:47 --> Config Class Initialized
INFO - 2018-03-28 09:19:47 --> Hooks Class Initialized
DEBUG - 2018-03-28 09:19:47 --> UTF-8 Support Enabled
INFO - 2018-03-28 09:19:47 --> Utf8 Class Initialized
INFO - 2018-03-28 09:19:47 --> URI Class Initialized
INFO - 2018-03-28 09:19:47 --> Router Class Initialized
INFO - 2018-03-28 09:19:47 --> Output Class Initialized
INFO - 2018-03-28 09:19:47 --> Security Class Initialized
DEBUG - 2018-03-28 09:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 09:19:47 --> Input Class Initialized
INFO - 2018-03-28 09:19:47 --> Language Class Initialized
INFO - 2018-03-28 09:19:47 --> Language Class Initialized
INFO - 2018-03-28 09:19:47 --> Config Class Initialized
INFO - 2018-03-28 09:19:47 --> Loader Class Initialized
INFO - 2018-03-28 14:49:48 --> Helper loaded: url_helper
INFO - 2018-03-28 14:49:48 --> Helper loaded: notification_helper
INFO - 2018-03-28 14:49:48 --> Helper loaded: settings_helper
INFO - 2018-03-28 14:49:48 --> Helper loaded: permission_helper
INFO - 2018-03-28 14:49:48 --> Helper loaded: users_helper
INFO - 2018-03-28 14:49:48 --> Database Driver Class Initialized
DEBUG - 2018-03-28 14:49:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 14:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 14:49:49 --> Helper loaded: form_helper
INFO - 2018-03-28 14:49:49 --> Form Validation Class Initialized
INFO - 2018-03-28 14:49:49 --> Controller Class Initialized
INFO - 2018-03-28 14:49:49 --> Model Class Initialized
INFO - 2018-03-28 14:49:49 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 14:49:49 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 14:49:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 14:49:49 --> Model Class Initialized
INFO - 2018-03-28 14:49:49 --> Model Class Initialized
INFO - 2018-03-28 14:49:49 --> Model Class Initialized
INFO - 2018-03-28 14:49:49 --> Model Class Initialized
INFO - 2018-03-28 14:49:49 --> Model Class Initialized
INFO - 2018-03-28 14:49:49 --> Model Class Initialized
INFO - 2018-03-28 14:49:49 --> Model Class Initialized
INFO - 2018-03-28 14:49:49 --> Model Class Initialized
INFO - 2018-03-28 14:49:49 --> Model Class Initialized
INFO - 2018-03-28 14:49:49 --> Model Class Initialized
INFO - 2018-03-28 14:49:49 --> Model Class Initialized
INFO - 2018-03-28 14:49:49 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 14:49:49 --> Model Class Initialized
INFO - 2018-03-28 09:19:49 --> Config Class Initialized
INFO - 2018-03-28 09:19:49 --> Hooks Class Initialized
DEBUG - 2018-03-28 09:19:49 --> UTF-8 Support Enabled
INFO - 2018-03-28 09:19:49 --> Utf8 Class Initialized
INFO - 2018-03-28 09:19:49 --> URI Class Initialized
INFO - 2018-03-28 09:19:49 --> Router Class Initialized
INFO - 2018-03-28 09:19:49 --> Output Class Initialized
INFO - 2018-03-28 09:19:49 --> Security Class Initialized
DEBUG - 2018-03-28 09:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 09:19:49 --> Input Class Initialized
INFO - 2018-03-28 09:19:49 --> Language Class Initialized
INFO - 2018-03-28 09:19:49 --> Language Class Initialized
INFO - 2018-03-28 09:19:49 --> Config Class Initialized
INFO - 2018-03-28 09:19:49 --> Loader Class Initialized
INFO - 2018-03-28 14:49:49 --> Helper loaded: url_helper
INFO - 2018-03-28 14:49:49 --> Helper loaded: notification_helper
INFO - 2018-03-28 14:49:49 --> Helper loaded: settings_helper
INFO - 2018-03-28 14:49:49 --> Helper loaded: permission_helper
INFO - 2018-03-28 14:49:49 --> Helper loaded: users_helper
INFO - 2018-03-28 14:49:49 --> Final output sent to browser
DEBUG - 2018-03-28 14:49:49 --> Total execution time: 2.0738
INFO - 2018-03-28 14:49:49 --> Database Driver Class Initialized
DEBUG - 2018-03-28 14:49:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 14:49:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 14:49:49 --> Helper loaded: form_helper
INFO - 2018-03-28 14:49:49 --> Form Validation Class Initialized
INFO - 2018-03-28 14:49:49 --> Controller Class Initialized
INFO - 2018-03-28 14:49:49 --> Model Class Initialized
INFO - 2018-03-28 14:49:49 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 14:49:49 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 14:49:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 14:49:49 --> Model Class Initialized
INFO - 2018-03-28 14:49:49 --> Model Class Initialized
INFO - 2018-03-28 14:49:49 --> Model Class Initialized
INFO - 2018-03-28 14:49:49 --> Model Class Initialized
INFO - 2018-03-28 14:49:49 --> Model Class Initialized
INFO - 2018-03-28 14:49:49 --> Model Class Initialized
INFO - 2018-03-28 14:49:49 --> Model Class Initialized
INFO - 2018-03-28 14:49:49 --> Model Class Initialized
INFO - 2018-03-28 14:49:49 --> Model Class Initialized
INFO - 2018-03-28 14:49:49 --> Model Class Initialized
INFO - 2018-03-28 14:49:49 --> Model Class Initialized
INFO - 2018-03-28 14:49:49 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 14:49:49 --> Model Class Initialized
INFO - 2018-03-28 14:49:49 --> Final output sent to browser
DEBUG - 2018-03-28 14:49:49 --> Total execution time: 0.1139
INFO - 2018-03-28 09:19:54 --> Config Class Initialized
INFO - 2018-03-28 09:19:54 --> Hooks Class Initialized
DEBUG - 2018-03-28 09:19:54 --> UTF-8 Support Enabled
INFO - 2018-03-28 09:19:54 --> Utf8 Class Initialized
INFO - 2018-03-28 09:19:54 --> URI Class Initialized
INFO - 2018-03-28 09:19:54 --> Router Class Initialized
INFO - 2018-03-28 09:19:54 --> Output Class Initialized
INFO - 2018-03-28 09:19:54 --> Security Class Initialized
DEBUG - 2018-03-28 09:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 09:19:54 --> Input Class Initialized
INFO - 2018-03-28 09:19:54 --> Language Class Initialized
INFO - 2018-03-28 09:19:55 --> Language Class Initialized
INFO - 2018-03-28 09:19:55 --> Config Class Initialized
INFO - 2018-03-28 09:19:55 --> Loader Class Initialized
INFO - 2018-03-28 14:49:55 --> Helper loaded: url_helper
INFO - 2018-03-28 14:49:55 --> Helper loaded: notification_helper
INFO - 2018-03-28 14:49:55 --> Helper loaded: settings_helper
INFO - 2018-03-28 14:49:55 --> Helper loaded: permission_helper
INFO - 2018-03-28 14:49:55 --> Helper loaded: users_helper
INFO - 2018-03-28 14:49:55 --> Database Driver Class Initialized
DEBUG - 2018-03-28 14:49:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 14:49:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 14:49:55 --> Helper loaded: form_helper
INFO - 2018-03-28 14:49:55 --> Form Validation Class Initialized
INFO - 2018-03-28 14:49:55 --> Controller Class Initialized
INFO - 2018-03-28 14:49:55 --> Model Class Initialized
INFO - 2018-03-28 14:49:55 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 14:49:55 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 14:49:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 14:49:55 --> Model Class Initialized
INFO - 2018-03-28 14:49:55 --> Model Class Initialized
INFO - 2018-03-28 14:49:55 --> Model Class Initialized
INFO - 2018-03-28 14:49:55 --> Model Class Initialized
INFO - 2018-03-28 14:49:55 --> Model Class Initialized
INFO - 2018-03-28 14:49:55 --> Model Class Initialized
INFO - 2018-03-28 14:49:55 --> Model Class Initialized
INFO - 2018-03-28 14:49:55 --> Model Class Initialized
INFO - 2018-03-28 14:49:55 --> Model Class Initialized
INFO - 2018-03-28 14:49:55 --> Model Class Initialized
INFO - 2018-03-28 14:49:55 --> Model Class Initialized
INFO - 2018-03-28 14:49:55 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 14:49:55 --> Final output sent to browser
DEBUG - 2018-03-28 14:49:55 --> Total execution time: 1.4615
INFO - 2018-03-28 09:19:56 --> Config Class Initialized
INFO - 2018-03-28 09:19:56 --> Hooks Class Initialized
DEBUG - 2018-03-28 09:19:56 --> UTF-8 Support Enabled
INFO - 2018-03-28 09:19:56 --> Utf8 Class Initialized
INFO - 2018-03-28 09:19:57 --> URI Class Initialized
INFO - 2018-03-28 09:19:57 --> Router Class Initialized
INFO - 2018-03-28 09:19:57 --> Output Class Initialized
INFO - 2018-03-28 09:19:57 --> Security Class Initialized
DEBUG - 2018-03-28 09:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 09:19:57 --> Input Class Initialized
INFO - 2018-03-28 09:19:57 --> Language Class Initialized
INFO - 2018-03-28 09:19:57 --> Language Class Initialized
INFO - 2018-03-28 09:19:57 --> Config Class Initialized
INFO - 2018-03-28 09:19:57 --> Loader Class Initialized
INFO - 2018-03-28 14:49:57 --> Helper loaded: url_helper
INFO - 2018-03-28 14:49:57 --> Helper loaded: notification_helper
INFO - 2018-03-28 14:49:57 --> Helper loaded: settings_helper
INFO - 2018-03-28 14:49:57 --> Helper loaded: permission_helper
INFO - 2018-03-28 14:49:57 --> Helper loaded: users_helper
INFO - 2018-03-28 14:49:57 --> Database Driver Class Initialized
DEBUG - 2018-03-28 14:49:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 14:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 14:49:57 --> Helper loaded: form_helper
INFO - 2018-03-28 14:49:57 --> Form Validation Class Initialized
INFO - 2018-03-28 14:49:57 --> Controller Class Initialized
INFO - 2018-03-28 14:49:57 --> Model Class Initialized
INFO - 2018-03-28 14:49:57 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 14:49:57 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 14:49:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 14:49:57 --> Model Class Initialized
INFO - 2018-03-28 14:49:57 --> Model Class Initialized
INFO - 2018-03-28 14:49:57 --> Model Class Initialized
INFO - 2018-03-28 14:49:57 --> Model Class Initialized
INFO - 2018-03-28 14:49:57 --> Model Class Initialized
INFO - 2018-03-28 14:49:57 --> Model Class Initialized
INFO - 2018-03-28 14:49:57 --> Model Class Initialized
INFO - 2018-03-28 14:49:57 --> Model Class Initialized
INFO - 2018-03-28 14:49:57 --> Model Class Initialized
INFO - 2018-03-28 14:49:57 --> Model Class Initialized
INFO - 2018-03-28 14:49:57 --> Model Class Initialized
INFO - 2018-03-28 14:49:57 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 14:49:57 --> Final output sent to browser
DEBUG - 2018-03-28 14:49:57 --> Total execution time: 0.8611
INFO - 2018-03-28 09:20:02 --> Config Class Initialized
INFO - 2018-03-28 09:20:02 --> Hooks Class Initialized
DEBUG - 2018-03-28 09:20:02 --> UTF-8 Support Enabled
INFO - 2018-03-28 09:20:02 --> Utf8 Class Initialized
INFO - 2018-03-28 09:20:02 --> URI Class Initialized
INFO - 2018-03-28 09:20:02 --> Router Class Initialized
INFO - 2018-03-28 09:20:02 --> Output Class Initialized
INFO - 2018-03-28 09:20:02 --> Security Class Initialized
DEBUG - 2018-03-28 09:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 09:20:02 --> Input Class Initialized
INFO - 2018-03-28 09:20:02 --> Language Class Initialized
INFO - 2018-03-28 09:20:02 --> Config Class Initialized
INFO - 2018-03-28 09:20:02 --> Hooks Class Initialized
DEBUG - 2018-03-28 09:20:02 --> UTF-8 Support Enabled
INFO - 2018-03-28 09:20:02 --> Utf8 Class Initialized
INFO - 2018-03-28 09:20:02 --> URI Class Initialized
INFO - 2018-03-28 09:20:02 --> Language Class Initialized
INFO - 2018-03-28 09:20:02 --> Config Class Initialized
INFO - 2018-03-28 09:20:02 --> Loader Class Initialized
INFO - 2018-03-28 14:50:02 --> Helper loaded: url_helper
INFO - 2018-03-28 14:50:02 --> Helper loaded: notification_helper
INFO - 2018-03-28 14:50:02 --> Helper loaded: settings_helper
INFO - 2018-03-28 14:50:02 --> Helper loaded: permission_helper
INFO - 2018-03-28 14:50:02 --> Helper loaded: users_helper
INFO - 2018-03-28 09:20:03 --> Router Class Initialized
INFO - 2018-03-28 14:50:03 --> Database Driver Class Initialized
DEBUG - 2018-03-28 14:50:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 14:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 14:50:03 --> Helper loaded: form_helper
INFO - 2018-03-28 14:50:03 --> Form Validation Class Initialized
INFO - 2018-03-28 14:50:03 --> Controller Class Initialized
INFO - 2018-03-28 09:20:03 --> Output Class Initialized
INFO - 2018-03-28 14:50:03 --> Model Class Initialized
INFO - 2018-03-28 14:50:03 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 14:50:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 14:50:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 14:50:03 --> Model Class Initialized
INFO - 2018-03-28 14:50:03 --> Model Class Initialized
INFO - 2018-03-28 14:50:03 --> Model Class Initialized
INFO - 2018-03-28 14:50:03 --> Model Class Initialized
INFO - 2018-03-28 14:50:03 --> Model Class Initialized
INFO - 2018-03-28 14:50:03 --> Model Class Initialized
INFO - 2018-03-28 14:50:03 --> Model Class Initialized
INFO - 2018-03-28 14:50:03 --> Model Class Initialized
INFO - 2018-03-28 14:50:03 --> Model Class Initialized
INFO - 2018-03-28 14:50:03 --> Model Class Initialized
INFO - 2018-03-28 14:50:03 --> Model Class Initialized
INFO - 2018-03-28 09:20:03 --> Security Class Initialized
INFO - 2018-03-28 14:50:03 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 14:50:03 --> Model Class Initialized
INFO - 2018-03-28 14:50:03 --> Final output sent to browser
DEBUG - 2018-03-28 14:50:03 --> Total execution time: 0.9939
DEBUG - 2018-03-28 09:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 09:20:03 --> Input Class Initialized
INFO - 2018-03-28 09:20:03 --> Language Class Initialized
INFO - 2018-03-28 09:20:04 --> Language Class Initialized
INFO - 2018-03-28 09:20:04 --> Config Class Initialized
INFO - 2018-03-28 09:20:04 --> Loader Class Initialized
INFO - 2018-03-28 14:50:04 --> Helper loaded: url_helper
INFO - 2018-03-28 14:50:04 --> Helper loaded: notification_helper
INFO - 2018-03-28 14:50:04 --> Helper loaded: settings_helper
INFO - 2018-03-28 14:50:04 --> Helper loaded: permission_helper
INFO - 2018-03-28 14:50:04 --> Helper loaded: users_helper
INFO - 2018-03-28 14:50:04 --> Database Driver Class Initialized
DEBUG - 2018-03-28 14:50:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 14:50:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 14:50:04 --> Helper loaded: form_helper
INFO - 2018-03-28 14:50:04 --> Form Validation Class Initialized
INFO - 2018-03-28 14:50:04 --> Controller Class Initialized
INFO - 2018-03-28 14:50:04 --> Model Class Initialized
INFO - 2018-03-28 14:50:04 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 14:50:04 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 14:50:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 14:50:04 --> Model Class Initialized
INFO - 2018-03-28 14:50:04 --> Model Class Initialized
INFO - 2018-03-28 14:50:04 --> Model Class Initialized
INFO - 2018-03-28 14:50:04 --> Model Class Initialized
INFO - 2018-03-28 14:50:04 --> Model Class Initialized
INFO - 2018-03-28 14:50:04 --> Model Class Initialized
INFO - 2018-03-28 14:50:04 --> Model Class Initialized
INFO - 2018-03-28 14:50:04 --> Model Class Initialized
INFO - 2018-03-28 14:50:04 --> Model Class Initialized
INFO - 2018-03-28 14:50:04 --> Model Class Initialized
INFO - 2018-03-28 14:50:04 --> Model Class Initialized
INFO - 2018-03-28 14:50:04 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 14:50:04 --> Final output sent to browser
DEBUG - 2018-03-28 14:50:04 --> Total execution time: 1.5230
INFO - 2018-03-28 09:33:49 --> Config Class Initialized
INFO - 2018-03-28 09:33:49 --> Hooks Class Initialized
DEBUG - 2018-03-28 09:33:49 --> UTF-8 Support Enabled
INFO - 2018-03-28 09:33:49 --> Utf8 Class Initialized
INFO - 2018-03-28 09:33:49 --> URI Class Initialized
INFO - 2018-03-28 09:33:49 --> Router Class Initialized
INFO - 2018-03-28 09:33:49 --> Output Class Initialized
INFO - 2018-03-28 09:33:49 --> Security Class Initialized
DEBUG - 2018-03-28 09:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 09:33:49 --> Input Class Initialized
INFO - 2018-03-28 09:33:49 --> Language Class Initialized
INFO - 2018-03-28 09:33:49 --> Language Class Initialized
INFO - 2018-03-28 09:33:49 --> Config Class Initialized
INFO - 2018-03-28 09:33:49 --> Loader Class Initialized
INFO - 2018-03-28 15:03:49 --> Helper loaded: url_helper
INFO - 2018-03-28 15:03:49 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:03:49 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:03:49 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:03:49 --> Helper loaded: users_helper
INFO - 2018-03-28 15:03:50 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:03:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:03:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:03:50 --> Helper loaded: form_helper
INFO - 2018-03-28 15:03:50 --> Form Validation Class Initialized
INFO - 2018-03-28 15:03:50 --> Controller Class Initialized
INFO - 2018-03-28 15:03:50 --> Model Class Initialized
INFO - 2018-03-28 15:03:50 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:03:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:03:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:03:50 --> Model Class Initialized
INFO - 2018-03-28 15:03:50 --> Model Class Initialized
INFO - 2018-03-28 15:03:50 --> Model Class Initialized
INFO - 2018-03-28 15:03:50 --> Model Class Initialized
INFO - 2018-03-28 15:03:50 --> Model Class Initialized
INFO - 2018-03-28 15:03:50 --> Model Class Initialized
INFO - 2018-03-28 15:03:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:03:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-28 15:03:50 --> Final output sent to browser
DEBUG - 2018-03-28 15:03:50 --> Total execution time: 0.3974
INFO - 2018-03-28 09:33:51 --> Config Class Initialized
INFO - 2018-03-28 09:33:51 --> Hooks Class Initialized
DEBUG - 2018-03-28 09:33:51 --> UTF-8 Support Enabled
INFO - 2018-03-28 09:33:51 --> Utf8 Class Initialized
INFO - 2018-03-28 09:33:51 --> URI Class Initialized
INFO - 2018-03-28 09:33:51 --> Router Class Initialized
INFO - 2018-03-28 09:33:51 --> Output Class Initialized
INFO - 2018-03-28 09:33:51 --> Security Class Initialized
DEBUG - 2018-03-28 09:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 09:33:51 --> Input Class Initialized
INFO - 2018-03-28 09:33:51 --> Language Class Initialized
INFO - 2018-03-28 09:33:51 --> Language Class Initialized
INFO - 2018-03-28 09:33:51 --> Config Class Initialized
INFO - 2018-03-28 09:33:51 --> Loader Class Initialized
INFO - 2018-03-28 15:03:51 --> Helper loaded: url_helper
INFO - 2018-03-28 15:03:51 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:03:51 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:03:51 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:03:51 --> Helper loaded: users_helper
INFO - 2018-03-28 09:33:51 --> Config Class Initialized
INFO - 2018-03-28 09:33:51 --> Hooks Class Initialized
DEBUG - 2018-03-28 09:33:51 --> UTF-8 Support Enabled
INFO - 2018-03-28 09:33:51 --> Utf8 Class Initialized
INFO - 2018-03-28 15:03:51 --> Database Driver Class Initialized
INFO - 2018-03-28 09:33:51 --> URI Class Initialized
DEBUG - 2018-03-28 15:03:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:03:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 09:33:51 --> Router Class Initialized
INFO - 2018-03-28 15:03:51 --> Helper loaded: form_helper
INFO - 2018-03-28 15:03:51 --> Form Validation Class Initialized
INFO - 2018-03-28 15:03:51 --> Controller Class Initialized
INFO - 2018-03-28 09:33:51 --> Output Class Initialized
INFO - 2018-03-28 15:03:51 --> Model Class Initialized
INFO - 2018-03-28 15:03:51 --> Helper loaded: inflector_helper
INFO - 2018-03-28 09:33:51 --> Security Class Initialized
DEBUG - 2018-03-28 15:03:51 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:03:51 --> Language file loaded: language/english/rest_controller_lang.php
DEBUG - 2018-03-28 09:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 09:33:51 --> Input Class Initialized
INFO - 2018-03-28 15:03:51 --> Model Class Initialized
INFO - 2018-03-28 15:03:51 --> Model Class Initialized
INFO - 2018-03-28 09:33:51 --> Language Class Initialized
INFO - 2018-03-28 15:03:51 --> Model Class Initialized
INFO - 2018-03-28 15:03:51 --> Model Class Initialized
INFO - 2018-03-28 15:03:51 --> Model Class Initialized
INFO - 2018-03-28 15:03:51 --> Model Class Initialized
INFO - 2018-03-28 15:03:51 --> Model Class Initialized
INFO - 2018-03-28 15:03:51 --> Model Class Initialized
INFO - 2018-03-28 15:03:51 --> Model Class Initialized
INFO - 2018-03-28 15:03:51 --> Model Class Initialized
INFO - 2018-03-28 15:03:51 --> Model Class Initialized
INFO - 2018-03-28 15:03:51 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:03:51 --> Model Class Initialized
INFO - 2018-03-28 15:03:51 --> Final output sent to browser
DEBUG - 2018-03-28 15:03:51 --> Total execution time: 0.2085
INFO - 2018-03-28 09:33:51 --> Language Class Initialized
INFO - 2018-03-28 09:33:51 --> Config Class Initialized
INFO - 2018-03-28 09:33:51 --> Loader Class Initialized
INFO - 2018-03-28 15:03:51 --> Helper loaded: url_helper
INFO - 2018-03-28 15:03:51 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:03:51 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:03:51 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:03:51 --> Helper loaded: users_helper
INFO - 2018-03-28 15:03:51 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:03:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:03:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:03:51 --> Helper loaded: form_helper
INFO - 2018-03-28 15:03:51 --> Form Validation Class Initialized
INFO - 2018-03-28 15:03:51 --> Controller Class Initialized
INFO - 2018-03-28 15:03:51 --> Model Class Initialized
INFO - 2018-03-28 15:03:51 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:03:51 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:03:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:03:51 --> Model Class Initialized
INFO - 2018-03-28 15:03:51 --> Model Class Initialized
INFO - 2018-03-28 15:03:51 --> Model Class Initialized
INFO - 2018-03-28 15:03:51 --> Model Class Initialized
INFO - 2018-03-28 15:03:51 --> Model Class Initialized
INFO - 2018-03-28 15:03:51 --> Model Class Initialized
INFO - 2018-03-28 15:03:51 --> Model Class Initialized
INFO - 2018-03-28 15:03:51 --> Model Class Initialized
INFO - 2018-03-28 15:03:51 --> Model Class Initialized
INFO - 2018-03-28 15:03:51 --> Model Class Initialized
INFO - 2018-03-28 15:03:51 --> Model Class Initialized
INFO - 2018-03-28 15:03:51 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:03:51 --> Model Class Initialized
INFO - 2018-03-28 15:03:51 --> Final output sent to browser
DEBUG - 2018-03-28 15:03:51 --> Total execution time: 0.2893
INFO - 2018-03-28 09:40:54 --> Config Class Initialized
INFO - 2018-03-28 09:40:54 --> Hooks Class Initialized
DEBUG - 2018-03-28 09:40:54 --> UTF-8 Support Enabled
INFO - 2018-03-28 09:40:54 --> Utf8 Class Initialized
INFO - 2018-03-28 09:40:54 --> URI Class Initialized
INFO - 2018-03-28 09:40:55 --> Router Class Initialized
INFO - 2018-03-28 09:40:55 --> Output Class Initialized
INFO - 2018-03-28 09:40:55 --> Security Class Initialized
DEBUG - 2018-03-28 09:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 09:40:55 --> Input Class Initialized
INFO - 2018-03-28 09:40:55 --> Language Class Initialized
INFO - 2018-03-28 09:40:55 --> Language Class Initialized
INFO - 2018-03-28 09:40:55 --> Config Class Initialized
INFO - 2018-03-28 09:40:55 --> Loader Class Initialized
INFO - 2018-03-28 15:10:55 --> Helper loaded: url_helper
INFO - 2018-03-28 15:10:55 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:10:55 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:10:55 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:10:55 --> Helper loaded: users_helper
INFO - 2018-03-28 15:10:55 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:10:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:10:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:10:55 --> Helper loaded: form_helper
INFO - 2018-03-28 15:10:55 --> Form Validation Class Initialized
INFO - 2018-03-28 15:10:55 --> Controller Class Initialized
INFO - 2018-03-28 15:10:55 --> Model Class Initialized
INFO - 2018-03-28 15:10:55 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:10:55 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:10:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:10:55 --> Model Class Initialized
INFO - 2018-03-28 15:10:55 --> Model Class Initialized
INFO - 2018-03-28 15:10:55 --> Model Class Initialized
INFO - 2018-03-28 15:10:55 --> Model Class Initialized
INFO - 2018-03-28 15:10:55 --> Model Class Initialized
INFO - 2018-03-28 15:10:55 --> Model Class Initialized
INFO - 2018-03-28 15:10:55 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:10:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-28 15:10:55 --> Final output sent to browser
DEBUG - 2018-03-28 15:10:55 --> Total execution time: 0.1900
INFO - 2018-03-28 09:40:55 --> Config Class Initialized
INFO - 2018-03-28 09:40:55 --> Hooks Class Initialized
DEBUG - 2018-03-28 09:40:55 --> UTF-8 Support Enabled
INFO - 2018-03-28 09:40:55 --> Utf8 Class Initialized
INFO - 2018-03-28 09:40:55 --> URI Class Initialized
INFO - 2018-03-28 09:40:55 --> Router Class Initialized
INFO - 2018-03-28 09:40:55 --> Output Class Initialized
INFO - 2018-03-28 09:40:55 --> Security Class Initialized
DEBUG - 2018-03-28 09:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 09:40:55 --> Input Class Initialized
INFO - 2018-03-28 09:40:55 --> Language Class Initialized
INFO - 2018-03-28 09:40:56 --> Language Class Initialized
INFO - 2018-03-28 09:40:56 --> Config Class Initialized
INFO - 2018-03-28 09:40:56 --> Loader Class Initialized
INFO - 2018-03-28 15:10:56 --> Helper loaded: url_helper
INFO - 2018-03-28 15:10:56 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:10:56 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:10:56 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:10:56 --> Helper loaded: users_helper
INFO - 2018-03-28 15:10:56 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:10:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:10:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:10:56 --> Helper loaded: form_helper
INFO - 2018-03-28 15:10:56 --> Form Validation Class Initialized
INFO - 2018-03-28 15:10:56 --> Controller Class Initialized
INFO - 2018-03-28 15:10:56 --> Model Class Initialized
INFO - 2018-03-28 15:10:56 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:10:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:10:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:10:56 --> Model Class Initialized
INFO - 2018-03-28 15:10:56 --> Model Class Initialized
INFO - 2018-03-28 15:10:56 --> Model Class Initialized
INFO - 2018-03-28 15:10:56 --> Model Class Initialized
INFO - 2018-03-28 15:10:56 --> Model Class Initialized
INFO - 2018-03-28 15:10:56 --> Model Class Initialized
INFO - 2018-03-28 15:10:56 --> Model Class Initialized
INFO - 2018-03-28 15:10:56 --> Model Class Initialized
INFO - 2018-03-28 15:10:56 --> Model Class Initialized
INFO - 2018-03-28 15:10:56 --> Model Class Initialized
INFO - 2018-03-28 15:10:56 --> Model Class Initialized
INFO - 2018-03-28 15:10:56 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:10:56 --> Model Class Initialized
INFO - 2018-03-28 15:10:56 --> Final output sent to browser
DEBUG - 2018-03-28 15:10:56 --> Total execution time: 0.4897
INFO - 2018-03-28 09:40:57 --> Config Class Initialized
INFO - 2018-03-28 09:40:57 --> Hooks Class Initialized
DEBUG - 2018-03-28 09:40:57 --> UTF-8 Support Enabled
INFO - 2018-03-28 09:40:57 --> Utf8 Class Initialized
INFO - 2018-03-28 09:40:57 --> URI Class Initialized
INFO - 2018-03-28 09:40:57 --> Router Class Initialized
INFO - 2018-03-28 09:40:57 --> Output Class Initialized
INFO - 2018-03-28 09:40:57 --> Security Class Initialized
DEBUG - 2018-03-28 09:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 09:40:57 --> Input Class Initialized
INFO - 2018-03-28 09:40:57 --> Language Class Initialized
INFO - 2018-03-28 09:40:57 --> Language Class Initialized
INFO - 2018-03-28 09:40:57 --> Config Class Initialized
INFO - 2018-03-28 09:40:57 --> Loader Class Initialized
INFO - 2018-03-28 15:10:57 --> Helper loaded: url_helper
INFO - 2018-03-28 15:10:57 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:10:57 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:10:57 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:10:57 --> Helper loaded: users_helper
INFO - 2018-03-28 15:10:58 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:10:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:10:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:10:58 --> Helper loaded: form_helper
INFO - 2018-03-28 15:10:58 --> Form Validation Class Initialized
INFO - 2018-03-28 15:10:58 --> Controller Class Initialized
INFO - 2018-03-28 15:10:58 --> Model Class Initialized
INFO - 2018-03-28 15:10:58 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:10:58 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:10:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:10:58 --> Model Class Initialized
INFO - 2018-03-28 15:10:58 --> Model Class Initialized
INFO - 2018-03-28 15:10:58 --> Model Class Initialized
INFO - 2018-03-28 15:10:58 --> Model Class Initialized
INFO - 2018-03-28 15:10:58 --> Model Class Initialized
INFO - 2018-03-28 15:10:58 --> Model Class Initialized
INFO - 2018-03-28 15:10:58 --> Model Class Initialized
INFO - 2018-03-28 15:10:58 --> Model Class Initialized
INFO - 2018-03-28 15:10:58 --> Model Class Initialized
INFO - 2018-03-28 15:10:58 --> Model Class Initialized
INFO - 2018-03-28 15:10:58 --> Model Class Initialized
INFO - 2018-03-28 15:10:58 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:10:58 --> Model Class Initialized
INFO - 2018-03-28 15:10:58 --> Final output sent to browser
DEBUG - 2018-03-28 15:10:58 --> Total execution time: 1.2843
INFO - 2018-03-28 09:41:00 --> Config Class Initialized
INFO - 2018-03-28 09:41:00 --> Hooks Class Initialized
DEBUG - 2018-03-28 09:41:00 --> UTF-8 Support Enabled
INFO - 2018-03-28 09:41:00 --> Utf8 Class Initialized
INFO - 2018-03-28 09:41:00 --> URI Class Initialized
INFO - 2018-03-28 09:41:00 --> Router Class Initialized
INFO - 2018-03-28 09:41:00 --> Output Class Initialized
INFO - 2018-03-28 09:41:00 --> Security Class Initialized
DEBUG - 2018-03-28 09:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 09:41:00 --> Input Class Initialized
INFO - 2018-03-28 09:41:00 --> Language Class Initialized
INFO - 2018-03-28 09:41:00 --> Language Class Initialized
INFO - 2018-03-28 09:41:00 --> Config Class Initialized
INFO - 2018-03-28 09:41:00 --> Loader Class Initialized
INFO - 2018-03-28 15:11:00 --> Helper loaded: url_helper
INFO - 2018-03-28 15:11:00 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:11:00 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:11:00 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:11:00 --> Helper loaded: users_helper
INFO - 2018-03-28 15:11:01 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:11:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:11:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:11:01 --> Helper loaded: form_helper
INFO - 2018-03-28 15:11:01 --> Form Validation Class Initialized
INFO - 2018-03-28 15:11:01 --> Controller Class Initialized
INFO - 2018-03-28 15:11:01 --> Model Class Initialized
INFO - 2018-03-28 15:11:01 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:11:01 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:11:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:11:01 --> Model Class Initialized
INFO - 2018-03-28 15:11:01 --> Model Class Initialized
INFO - 2018-03-28 15:11:01 --> Model Class Initialized
INFO - 2018-03-28 15:11:01 --> Model Class Initialized
INFO - 2018-03-28 15:11:01 --> Model Class Initialized
INFO - 2018-03-28 15:11:01 --> Model Class Initialized
INFO - 2018-03-28 15:11:01 --> Model Class Initialized
INFO - 2018-03-28 15:11:01 --> Model Class Initialized
INFO - 2018-03-28 15:11:01 --> Model Class Initialized
INFO - 2018-03-28 15:11:01 --> Model Class Initialized
INFO - 2018-03-28 15:11:01 --> Model Class Initialized
INFO - 2018-03-28 15:11:01 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:11:01 --> Model Class Initialized
INFO - 2018-03-28 15:11:01 --> Final output sent to browser
DEBUG - 2018-03-28 15:11:01 --> Total execution time: 1.3531
INFO - 2018-03-28 09:41:03 --> Config Class Initialized
INFO - 2018-03-28 09:41:03 --> Hooks Class Initialized
DEBUG - 2018-03-28 09:41:03 --> UTF-8 Support Enabled
INFO - 2018-03-28 09:41:03 --> Utf8 Class Initialized
INFO - 2018-03-28 09:41:03 --> URI Class Initialized
INFO - 2018-03-28 09:41:03 --> Router Class Initialized
INFO - 2018-03-28 09:41:03 --> Output Class Initialized
INFO - 2018-03-28 09:41:03 --> Security Class Initialized
DEBUG - 2018-03-28 09:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 09:41:03 --> Input Class Initialized
INFO - 2018-03-28 09:41:03 --> Language Class Initialized
INFO - 2018-03-28 09:41:03 --> Language Class Initialized
INFO - 2018-03-28 09:41:03 --> Config Class Initialized
INFO - 2018-03-28 09:41:03 --> Loader Class Initialized
INFO - 2018-03-28 15:11:03 --> Helper loaded: url_helper
INFO - 2018-03-28 15:11:03 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:11:03 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:11:03 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:11:03 --> Helper loaded: users_helper
INFO - 2018-03-28 15:11:03 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:11:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:11:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:11:03 --> Helper loaded: form_helper
INFO - 2018-03-28 15:11:03 --> Form Validation Class Initialized
INFO - 2018-03-28 15:11:03 --> Controller Class Initialized
INFO - 2018-03-28 15:11:03 --> Model Class Initialized
INFO - 2018-03-28 15:11:03 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:11:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:11:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:11:03 --> Model Class Initialized
INFO - 2018-03-28 15:11:03 --> Model Class Initialized
INFO - 2018-03-28 15:11:03 --> Model Class Initialized
INFO - 2018-03-28 15:11:03 --> Model Class Initialized
INFO - 2018-03-28 15:11:03 --> Model Class Initialized
INFO - 2018-03-28 15:11:03 --> Model Class Initialized
INFO - 2018-03-28 15:11:03 --> Model Class Initialized
INFO - 2018-03-28 15:11:03 --> Model Class Initialized
INFO - 2018-03-28 15:11:03 --> Model Class Initialized
INFO - 2018-03-28 15:11:03 --> Model Class Initialized
INFO - 2018-03-28 15:11:03 --> Model Class Initialized
INFO - 2018-03-28 15:11:03 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:11:03 --> Model Class Initialized
INFO - 2018-03-28 15:11:03 --> Final output sent to browser
DEBUG - 2018-03-28 15:11:03 --> Total execution time: 0.2599
INFO - 2018-03-28 09:43:32 --> Config Class Initialized
INFO - 2018-03-28 09:43:32 --> Hooks Class Initialized
DEBUG - 2018-03-28 09:43:32 --> UTF-8 Support Enabled
INFO - 2018-03-28 09:43:32 --> Utf8 Class Initialized
INFO - 2018-03-28 09:43:32 --> URI Class Initialized
INFO - 2018-03-28 09:43:32 --> Router Class Initialized
INFO - 2018-03-28 09:43:32 --> Output Class Initialized
INFO - 2018-03-28 09:43:32 --> Security Class Initialized
DEBUG - 2018-03-28 09:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 09:43:32 --> Input Class Initialized
INFO - 2018-03-28 09:43:32 --> Language Class Initialized
INFO - 2018-03-28 09:43:32 --> Language Class Initialized
INFO - 2018-03-28 09:43:32 --> Config Class Initialized
INFO - 2018-03-28 09:43:32 --> Loader Class Initialized
INFO - 2018-03-28 15:13:32 --> Helper loaded: url_helper
INFO - 2018-03-28 15:13:32 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:13:32 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:13:32 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:13:32 --> Helper loaded: users_helper
INFO - 2018-03-28 15:13:33 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:13:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:13:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:13:33 --> Helper loaded: form_helper
INFO - 2018-03-28 15:13:33 --> Form Validation Class Initialized
INFO - 2018-03-28 15:13:33 --> Controller Class Initialized
INFO - 2018-03-28 15:13:33 --> Model Class Initialized
INFO - 2018-03-28 15:13:33 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:13:33 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:13:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:13:33 --> Model Class Initialized
INFO - 2018-03-28 15:13:33 --> Model Class Initialized
INFO - 2018-03-28 15:13:33 --> Model Class Initialized
INFO - 2018-03-28 15:13:33 --> Model Class Initialized
INFO - 2018-03-28 15:13:33 --> Model Class Initialized
INFO - 2018-03-28 15:13:33 --> Model Class Initialized
INFO - 2018-03-28 15:13:33 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:13:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-28 15:13:34 --> Final output sent to browser
DEBUG - 2018-03-28 15:13:34 --> Total execution time: 1.3646
INFO - 2018-03-28 09:43:35 --> Config Class Initialized
INFO - 2018-03-28 09:43:35 --> Hooks Class Initialized
DEBUG - 2018-03-28 09:43:35 --> UTF-8 Support Enabled
INFO - 2018-03-28 09:43:35 --> Utf8 Class Initialized
INFO - 2018-03-28 09:43:35 --> URI Class Initialized
INFO - 2018-03-28 09:43:35 --> Router Class Initialized
INFO - 2018-03-28 09:43:35 --> Output Class Initialized
INFO - 2018-03-28 09:43:35 --> Security Class Initialized
DEBUG - 2018-03-28 09:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 09:43:35 --> Input Class Initialized
INFO - 2018-03-28 09:43:35 --> Language Class Initialized
INFO - 2018-03-28 09:43:35 --> Language Class Initialized
INFO - 2018-03-28 09:43:35 --> Config Class Initialized
INFO - 2018-03-28 09:43:35 --> Loader Class Initialized
INFO - 2018-03-28 15:13:35 --> Helper loaded: url_helper
INFO - 2018-03-28 15:13:35 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:13:35 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:13:35 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:13:35 --> Helper loaded: users_helper
INFO - 2018-03-28 15:13:35 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:13:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:13:35 --> Helper loaded: form_helper
INFO - 2018-03-28 15:13:35 --> Form Validation Class Initialized
INFO - 2018-03-28 15:13:35 --> Controller Class Initialized
INFO - 2018-03-28 15:13:35 --> Model Class Initialized
INFO - 2018-03-28 15:13:35 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:13:35 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:13:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:13:35 --> Model Class Initialized
INFO - 2018-03-28 15:13:35 --> Model Class Initialized
INFO - 2018-03-28 15:13:35 --> Model Class Initialized
INFO - 2018-03-28 15:13:35 --> Model Class Initialized
INFO - 2018-03-28 15:13:35 --> Model Class Initialized
INFO - 2018-03-28 15:13:35 --> Model Class Initialized
INFO - 2018-03-28 15:13:35 --> Model Class Initialized
INFO - 2018-03-28 15:13:35 --> Model Class Initialized
INFO - 2018-03-28 15:13:35 --> Model Class Initialized
INFO - 2018-03-28 15:13:35 --> Model Class Initialized
INFO - 2018-03-28 15:13:35 --> Model Class Initialized
INFO - 2018-03-28 15:13:35 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:13:35 --> Model Class Initialized
INFO - 2018-03-28 15:13:35 --> Final output sent to browser
DEBUG - 2018-03-28 15:13:35 --> Total execution time: 0.1627
INFO - 2018-03-28 09:43:36 --> Config Class Initialized
INFO - 2018-03-28 09:43:36 --> Hooks Class Initialized
DEBUG - 2018-03-28 09:43:36 --> UTF-8 Support Enabled
INFO - 2018-03-28 09:43:36 --> Utf8 Class Initialized
INFO - 2018-03-28 09:43:36 --> URI Class Initialized
INFO - 2018-03-28 09:43:37 --> Router Class Initialized
INFO - 2018-03-28 09:43:37 --> Output Class Initialized
INFO - 2018-03-28 09:43:37 --> Security Class Initialized
DEBUG - 2018-03-28 09:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 09:43:37 --> Input Class Initialized
INFO - 2018-03-28 09:43:37 --> Language Class Initialized
INFO - 2018-03-28 09:43:37 --> Language Class Initialized
INFO - 2018-03-28 09:43:37 --> Config Class Initialized
INFO - 2018-03-28 09:43:37 --> Loader Class Initialized
INFO - 2018-03-28 15:13:37 --> Helper loaded: url_helper
INFO - 2018-03-28 15:13:37 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:13:37 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:13:37 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:13:37 --> Helper loaded: users_helper
INFO - 2018-03-28 09:43:38 --> Config Class Initialized
INFO - 2018-03-28 09:43:38 --> Hooks Class Initialized
DEBUG - 2018-03-28 09:43:38 --> UTF-8 Support Enabled
INFO - 2018-03-28 09:43:38 --> Utf8 Class Initialized
INFO - 2018-03-28 09:43:38 --> URI Class Initialized
INFO - 2018-03-28 09:43:38 --> Router Class Initialized
INFO - 2018-03-28 15:13:38 --> Database Driver Class Initialized
INFO - 2018-03-28 09:43:38 --> Output Class Initialized
INFO - 2018-03-28 09:43:38 --> Security Class Initialized
DEBUG - 2018-03-28 09:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 09:43:38 --> Input Class Initialized
INFO - 2018-03-28 09:43:38 --> Language Class Initialized
DEBUG - 2018-03-28 15:13:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 09:43:38 --> Language Class Initialized
INFO - 2018-03-28 09:43:38 --> Config Class Initialized
INFO - 2018-03-28 09:43:38 --> Loader Class Initialized
INFO - 2018-03-28 15:13:38 --> Helper loaded: url_helper
INFO - 2018-03-28 15:13:38 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:13:38 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:13:38 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:13:38 --> Helper loaded: users_helper
INFO - 2018-03-28 15:13:38 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:13:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:13:38 --> Helper loaded: form_helper
INFO - 2018-03-28 15:13:38 --> Form Validation Class Initialized
INFO - 2018-03-28 15:13:38 --> Controller Class Initialized
INFO - 2018-03-28 15:13:38 --> Model Class Initialized
INFO - 2018-03-28 15:13:38 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:13:38 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:13:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:13:38 --> Model Class Initialized
INFO - 2018-03-28 15:13:38 --> Model Class Initialized
INFO - 2018-03-28 15:13:38 --> Model Class Initialized
INFO - 2018-03-28 15:13:38 --> Model Class Initialized
INFO - 2018-03-28 15:13:38 --> Model Class Initialized
INFO - 2018-03-28 15:13:38 --> Model Class Initialized
INFO - 2018-03-28 15:13:38 --> Model Class Initialized
INFO - 2018-03-28 15:13:38 --> Model Class Initialized
INFO - 2018-03-28 15:13:38 --> Model Class Initialized
INFO - 2018-03-28 15:13:38 --> Model Class Initialized
INFO - 2018-03-28 15:13:38 --> Helper loaded: form_helper
INFO - 2018-03-28 15:13:38 --> Form Validation Class Initialized
INFO - 2018-03-28 15:13:38 --> Controller Class Initialized
INFO - 2018-03-28 15:13:38 --> Model Class Initialized
INFO - 2018-03-28 15:13:38 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:13:38 --> Model Class Initialized
INFO - 2018-03-28 15:13:38 --> Final output sent to browser
DEBUG - 2018-03-28 15:13:38 --> Total execution time: 0.4610
INFO - 2018-03-28 15:13:39 --> Model Class Initialized
INFO - 2018-03-28 15:13:39 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:13:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:13:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:13:39 --> Model Class Initialized
INFO - 2018-03-28 15:13:39 --> Model Class Initialized
INFO - 2018-03-28 15:13:39 --> Model Class Initialized
INFO - 2018-03-28 15:13:39 --> Model Class Initialized
INFO - 2018-03-28 15:13:39 --> Model Class Initialized
INFO - 2018-03-28 15:13:39 --> Model Class Initialized
INFO - 2018-03-28 15:13:39 --> Model Class Initialized
INFO - 2018-03-28 15:13:39 --> Model Class Initialized
INFO - 2018-03-28 15:13:39 --> Model Class Initialized
INFO - 2018-03-28 15:13:39 --> Model Class Initialized
INFO - 2018-03-28 15:13:39 --> Model Class Initialized
INFO - 2018-03-28 15:13:39 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:13:39 --> Model Class Initialized
INFO - 2018-03-28 15:13:39 --> Final output sent to browser
DEBUG - 2018-03-28 15:13:39 --> Total execution time: 2.4688
INFO - 2018-03-28 09:43:40 --> Config Class Initialized
INFO - 2018-03-28 09:43:40 --> Hooks Class Initialized
DEBUG - 2018-03-28 09:43:40 --> UTF-8 Support Enabled
INFO - 2018-03-28 09:43:40 --> Utf8 Class Initialized
INFO - 2018-03-28 09:43:40 --> URI Class Initialized
INFO - 2018-03-28 09:43:40 --> Router Class Initialized
INFO - 2018-03-28 09:43:40 --> Output Class Initialized
INFO - 2018-03-28 09:43:40 --> Security Class Initialized
DEBUG - 2018-03-28 09:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 09:43:40 --> Input Class Initialized
INFO - 2018-03-28 09:43:40 --> Language Class Initialized
INFO - 2018-03-28 09:43:40 --> Language Class Initialized
INFO - 2018-03-28 09:43:40 --> Config Class Initialized
INFO - 2018-03-28 09:43:40 --> Loader Class Initialized
INFO - 2018-03-28 15:13:40 --> Helper loaded: url_helper
INFO - 2018-03-28 15:13:40 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:13:40 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:13:40 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:13:40 --> Helper loaded: users_helper
INFO - 2018-03-28 15:13:40 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:13:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:13:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:13:40 --> Helper loaded: form_helper
INFO - 2018-03-28 15:13:40 --> Form Validation Class Initialized
INFO - 2018-03-28 15:13:40 --> Controller Class Initialized
INFO - 2018-03-28 15:13:40 --> Model Class Initialized
INFO - 2018-03-28 15:13:40 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:13:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:13:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:13:40 --> Model Class Initialized
INFO - 2018-03-28 15:13:40 --> Model Class Initialized
INFO - 2018-03-28 15:13:40 --> Model Class Initialized
INFO - 2018-03-28 15:13:40 --> Model Class Initialized
INFO - 2018-03-28 15:13:40 --> Model Class Initialized
INFO - 2018-03-28 15:13:40 --> Model Class Initialized
INFO - 2018-03-28 15:13:40 --> Model Class Initialized
INFO - 2018-03-28 15:13:40 --> Model Class Initialized
INFO - 2018-03-28 15:13:40 --> Model Class Initialized
INFO - 2018-03-28 15:13:40 --> Model Class Initialized
INFO - 2018-03-28 15:13:40 --> Model Class Initialized
INFO - 2018-03-28 15:13:40 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:13:40 --> Model Class Initialized
INFO - 2018-03-28 15:13:40 --> Final output sent to browser
DEBUG - 2018-03-28 15:13:40 --> Total execution time: 0.2518
INFO - 2018-03-28 09:43:41 --> Config Class Initialized
INFO - 2018-03-28 09:43:41 --> Hooks Class Initialized
DEBUG - 2018-03-28 09:43:41 --> UTF-8 Support Enabled
INFO - 2018-03-28 09:43:41 --> Utf8 Class Initialized
INFO - 2018-03-28 09:43:41 --> URI Class Initialized
INFO - 2018-03-28 09:43:41 --> Router Class Initialized
INFO - 2018-03-28 09:43:41 --> Output Class Initialized
INFO - 2018-03-28 09:43:41 --> Security Class Initialized
DEBUG - 2018-03-28 09:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 09:43:41 --> Input Class Initialized
INFO - 2018-03-28 09:43:41 --> Language Class Initialized
INFO - 2018-03-28 09:43:41 --> Language Class Initialized
INFO - 2018-03-28 09:43:41 --> Config Class Initialized
INFO - 2018-03-28 09:43:41 --> Loader Class Initialized
INFO - 2018-03-28 15:13:41 --> Helper loaded: url_helper
INFO - 2018-03-28 15:13:41 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:13:41 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:13:41 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:13:41 --> Helper loaded: users_helper
INFO - 2018-03-28 15:13:41 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:13:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:13:41 --> Helper loaded: form_helper
INFO - 2018-03-28 15:13:41 --> Form Validation Class Initialized
INFO - 2018-03-28 15:13:41 --> Controller Class Initialized
INFO - 2018-03-28 15:13:41 --> Model Class Initialized
INFO - 2018-03-28 15:13:41 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:13:41 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:13:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:13:41 --> Model Class Initialized
INFO - 2018-03-28 15:13:41 --> Model Class Initialized
INFO - 2018-03-28 15:13:41 --> Model Class Initialized
INFO - 2018-03-28 15:13:41 --> Model Class Initialized
INFO - 2018-03-28 15:13:41 --> Model Class Initialized
INFO - 2018-03-28 15:13:41 --> Model Class Initialized
INFO - 2018-03-28 15:13:41 --> Model Class Initialized
INFO - 2018-03-28 15:13:41 --> Model Class Initialized
INFO - 2018-03-28 15:13:41 --> Model Class Initialized
INFO - 2018-03-28 15:13:41 --> Model Class Initialized
INFO - 2018-03-28 15:13:41 --> Model Class Initialized
INFO - 2018-03-28 15:13:41 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:13:41 --> Final output sent to browser
DEBUG - 2018-03-28 15:13:41 --> Total execution time: 0.5320
INFO - 2018-03-28 09:43:46 --> Config Class Initialized
INFO - 2018-03-28 09:43:46 --> Hooks Class Initialized
DEBUG - 2018-03-28 09:43:46 --> UTF-8 Support Enabled
INFO - 2018-03-28 09:43:46 --> Utf8 Class Initialized
INFO - 2018-03-28 09:43:46 --> URI Class Initialized
INFO - 2018-03-28 09:43:46 --> Router Class Initialized
INFO - 2018-03-28 09:43:46 --> Output Class Initialized
INFO - 2018-03-28 09:43:46 --> Security Class Initialized
DEBUG - 2018-03-28 09:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 09:43:46 --> Input Class Initialized
INFO - 2018-03-28 09:43:46 --> Language Class Initialized
INFO - 2018-03-28 09:43:46 --> Language Class Initialized
INFO - 2018-03-28 09:43:46 --> Config Class Initialized
INFO - 2018-03-28 09:43:46 --> Loader Class Initialized
INFO - 2018-03-28 15:13:46 --> Helper loaded: url_helper
INFO - 2018-03-28 15:13:46 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:13:46 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:13:46 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:13:46 --> Helper loaded: users_helper
INFO - 2018-03-28 15:13:47 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:13:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:13:47 --> Helper loaded: form_helper
INFO - 2018-03-28 15:13:47 --> Form Validation Class Initialized
INFO - 2018-03-28 15:13:47 --> Controller Class Initialized
INFO - 2018-03-28 15:13:47 --> Model Class Initialized
INFO - 2018-03-28 15:13:47 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:13:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:13:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:13:47 --> Model Class Initialized
INFO - 2018-03-28 15:13:47 --> Model Class Initialized
INFO - 2018-03-28 15:13:47 --> Model Class Initialized
INFO - 2018-03-28 15:13:47 --> Model Class Initialized
INFO - 2018-03-28 15:13:47 --> Model Class Initialized
INFO - 2018-03-28 15:13:47 --> Model Class Initialized
INFO - 2018-03-28 15:13:47 --> Model Class Initialized
INFO - 2018-03-28 15:13:47 --> Model Class Initialized
INFO - 2018-03-28 15:13:47 --> Model Class Initialized
INFO - 2018-03-28 15:13:47 --> Model Class Initialized
INFO - 2018-03-28 15:13:47 --> Model Class Initialized
INFO - 2018-03-28 15:13:47 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:13:47 --> Final output sent to browser
DEBUG - 2018-03-28 15:13:47 --> Total execution time: 0.2043
INFO - 2018-03-28 09:43:52 --> Config Class Initialized
INFO - 2018-03-28 09:43:52 --> Hooks Class Initialized
DEBUG - 2018-03-28 09:43:52 --> UTF-8 Support Enabled
INFO - 2018-03-28 09:43:52 --> Utf8 Class Initialized
INFO - 2018-03-28 09:43:52 --> URI Class Initialized
INFO - 2018-03-28 09:43:52 --> Router Class Initialized
INFO - 2018-03-28 09:43:52 --> Output Class Initialized
INFO - 2018-03-28 09:43:52 --> Security Class Initialized
DEBUG - 2018-03-28 09:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 09:43:52 --> Input Class Initialized
INFO - 2018-03-28 09:43:52 --> Language Class Initialized
INFO - 2018-03-28 09:43:52 --> Language Class Initialized
INFO - 2018-03-28 09:43:52 --> Config Class Initialized
INFO - 2018-03-28 09:43:52 --> Loader Class Initialized
INFO - 2018-03-28 15:13:52 --> Helper loaded: url_helper
INFO - 2018-03-28 15:13:52 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:13:52 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:13:52 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:13:52 --> Helper loaded: users_helper
INFO - 2018-03-28 15:13:52 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:13:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:13:52 --> Helper loaded: form_helper
INFO - 2018-03-28 15:13:52 --> Form Validation Class Initialized
INFO - 2018-03-28 15:13:52 --> Controller Class Initialized
INFO - 2018-03-28 15:13:52 --> Model Class Initialized
INFO - 2018-03-28 15:13:52 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:13:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:13:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:13:52 --> Model Class Initialized
INFO - 2018-03-28 15:13:52 --> Model Class Initialized
INFO - 2018-03-28 15:13:52 --> Model Class Initialized
INFO - 2018-03-28 15:13:52 --> Model Class Initialized
INFO - 2018-03-28 15:13:52 --> Model Class Initialized
INFO - 2018-03-28 15:13:52 --> Model Class Initialized
INFO - 2018-03-28 15:13:52 --> Model Class Initialized
INFO - 2018-03-28 15:13:52 --> Model Class Initialized
INFO - 2018-03-28 15:13:52 --> Model Class Initialized
INFO - 2018-03-28 15:13:52 --> Model Class Initialized
INFO - 2018-03-28 15:13:52 --> Model Class Initialized
INFO - 2018-03-28 15:13:52 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:13:52 --> Model Class Initialized
INFO - 2018-03-28 15:13:52 --> Final output sent to browser
DEBUG - 2018-03-28 15:13:52 --> Total execution time: 0.1619
INFO - 2018-03-28 09:43:54 --> Config Class Initialized
INFO - 2018-03-28 09:43:54 --> Hooks Class Initialized
DEBUG - 2018-03-28 09:43:54 --> UTF-8 Support Enabled
INFO - 2018-03-28 09:43:54 --> Utf8 Class Initialized
INFO - 2018-03-28 09:43:54 --> URI Class Initialized
INFO - 2018-03-28 09:43:54 --> Router Class Initialized
INFO - 2018-03-28 09:43:54 --> Output Class Initialized
INFO - 2018-03-28 09:43:54 --> Security Class Initialized
DEBUG - 2018-03-28 09:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 09:43:54 --> Input Class Initialized
INFO - 2018-03-28 09:43:54 --> Language Class Initialized
INFO - 2018-03-28 09:43:54 --> Language Class Initialized
INFO - 2018-03-28 09:43:54 --> Config Class Initialized
INFO - 2018-03-28 09:43:54 --> Loader Class Initialized
INFO - 2018-03-28 15:13:54 --> Helper loaded: url_helper
INFO - 2018-03-28 15:13:54 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:13:54 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:13:54 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:13:54 --> Helper loaded: users_helper
INFO - 2018-03-28 15:13:54 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:13:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:13:54 --> Helper loaded: form_helper
INFO - 2018-03-28 15:13:54 --> Form Validation Class Initialized
INFO - 2018-03-28 15:13:54 --> Controller Class Initialized
INFO - 2018-03-28 15:13:54 --> Model Class Initialized
INFO - 2018-03-28 15:13:54 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:13:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:13:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:13:54 --> Model Class Initialized
INFO - 2018-03-28 15:13:54 --> Model Class Initialized
INFO - 2018-03-28 15:13:54 --> Model Class Initialized
INFO - 2018-03-28 15:13:54 --> Model Class Initialized
INFO - 2018-03-28 15:13:54 --> Model Class Initialized
INFO - 2018-03-28 15:13:54 --> Model Class Initialized
INFO - 2018-03-28 15:13:54 --> Model Class Initialized
INFO - 2018-03-28 15:13:54 --> Model Class Initialized
INFO - 2018-03-28 15:13:54 --> Model Class Initialized
INFO - 2018-03-28 15:13:54 --> Model Class Initialized
INFO - 2018-03-28 15:13:54 --> Model Class Initialized
INFO - 2018-03-28 15:13:54 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:13:54 --> Final output sent to browser
DEBUG - 2018-03-28 15:13:54 --> Total execution time: 0.1558
INFO - 2018-03-28 09:44:01 --> Config Class Initialized
INFO - 2018-03-28 09:44:01 --> Hooks Class Initialized
DEBUG - 2018-03-28 09:44:01 --> UTF-8 Support Enabled
INFO - 2018-03-28 09:44:01 --> Utf8 Class Initialized
INFO - 2018-03-28 09:44:01 --> URI Class Initialized
INFO - 2018-03-28 09:44:01 --> Router Class Initialized
INFO - 2018-03-28 09:44:01 --> Output Class Initialized
INFO - 2018-03-28 09:44:01 --> Security Class Initialized
DEBUG - 2018-03-28 09:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 09:44:02 --> Input Class Initialized
INFO - 2018-03-28 09:44:02 --> Language Class Initialized
INFO - 2018-03-28 09:44:02 --> Language Class Initialized
INFO - 2018-03-28 09:44:02 --> Config Class Initialized
INFO - 2018-03-28 09:44:02 --> Loader Class Initialized
INFO - 2018-03-28 15:14:02 --> Helper loaded: url_helper
INFO - 2018-03-28 15:14:02 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:14:02 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:14:02 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:14:02 --> Helper loaded: users_helper
INFO - 2018-03-28 15:14:02 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:14:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:14:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:14:03 --> Helper loaded: form_helper
INFO - 2018-03-28 15:14:03 --> Form Validation Class Initialized
INFO - 2018-03-28 15:14:03 --> Controller Class Initialized
INFO - 2018-03-28 15:14:03 --> Model Class Initialized
INFO - 2018-03-28 15:14:03 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:14:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:14:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:14:03 --> Model Class Initialized
INFO - 2018-03-28 15:14:03 --> Model Class Initialized
INFO - 2018-03-28 15:14:04 --> Model Class Initialized
INFO - 2018-03-28 15:14:04 --> Model Class Initialized
INFO - 2018-03-28 15:14:04 --> Model Class Initialized
INFO - 2018-03-28 15:14:04 --> Model Class Initialized
INFO - 2018-03-28 15:14:04 --> Model Class Initialized
INFO - 2018-03-28 15:14:04 --> Model Class Initialized
INFO - 2018-03-28 15:14:04 --> Model Class Initialized
INFO - 2018-03-28 15:14:04 --> Model Class Initialized
INFO - 2018-03-28 15:14:04 --> Model Class Initialized
INFO - 2018-03-28 15:14:04 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:14:04 --> Final output sent to browser
DEBUG - 2018-03-28 15:14:04 --> Total execution time: 3.2009
INFO - 2018-03-28 09:44:10 --> Config Class Initialized
INFO - 2018-03-28 09:44:10 --> Hooks Class Initialized
DEBUG - 2018-03-28 09:44:10 --> UTF-8 Support Enabled
INFO - 2018-03-28 09:44:10 --> Utf8 Class Initialized
INFO - 2018-03-28 09:44:10 --> URI Class Initialized
INFO - 2018-03-28 09:44:10 --> Router Class Initialized
INFO - 2018-03-28 09:44:10 --> Output Class Initialized
INFO - 2018-03-28 09:44:10 --> Security Class Initialized
DEBUG - 2018-03-28 09:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 09:44:10 --> Input Class Initialized
INFO - 2018-03-28 09:44:10 --> Language Class Initialized
INFO - 2018-03-28 09:44:10 --> Language Class Initialized
INFO - 2018-03-28 09:44:10 --> Config Class Initialized
INFO - 2018-03-28 09:44:10 --> Loader Class Initialized
INFO - 2018-03-28 15:14:10 --> Helper loaded: url_helper
INFO - 2018-03-28 15:14:10 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:14:10 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:14:10 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:14:10 --> Helper loaded: users_helper
INFO - 2018-03-28 15:14:10 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:14:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:14:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:14:10 --> Helper loaded: form_helper
INFO - 2018-03-28 15:14:10 --> Form Validation Class Initialized
INFO - 2018-03-28 15:14:10 --> Controller Class Initialized
INFO - 2018-03-28 09:44:10 --> Config Class Initialized
INFO - 2018-03-28 09:44:10 --> Hooks Class Initialized
INFO - 2018-03-28 15:14:10 --> Model Class Initialized
INFO - 2018-03-28 15:14:10 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 09:44:10 --> UTF-8 Support Enabled
INFO - 2018-03-28 09:44:10 --> Utf8 Class Initialized
DEBUG - 2018-03-28 15:14:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:14:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:14:10 --> Model Class Initialized
INFO - 2018-03-28 15:14:10 --> Model Class Initialized
INFO - 2018-03-28 15:14:10 --> Model Class Initialized
INFO - 2018-03-28 15:14:10 --> Model Class Initialized
INFO - 2018-03-28 15:14:10 --> Model Class Initialized
INFO - 2018-03-28 15:14:10 --> Model Class Initialized
INFO - 2018-03-28 15:14:10 --> Model Class Initialized
INFO - 2018-03-28 15:14:10 --> Model Class Initialized
INFO - 2018-03-28 15:14:10 --> Model Class Initialized
INFO - 2018-03-28 15:14:10 --> Model Class Initialized
INFO - 2018-03-28 09:44:10 --> URI Class Initialized
INFO - 2018-03-28 15:14:10 --> Model Class Initialized
INFO - 2018-03-28 15:14:10 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:14:10 --> Final output sent to browser
DEBUG - 2018-03-28 15:14:10 --> Total execution time: 0.1201
INFO - 2018-03-28 09:44:10 --> Router Class Initialized
INFO - 2018-03-28 09:44:10 --> Output Class Initialized
INFO - 2018-03-28 09:44:10 --> Security Class Initialized
DEBUG - 2018-03-28 09:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 09:44:10 --> Input Class Initialized
INFO - 2018-03-28 09:44:10 --> Language Class Initialized
INFO - 2018-03-28 09:44:10 --> Language Class Initialized
INFO - 2018-03-28 09:44:10 --> Config Class Initialized
INFO - 2018-03-28 09:44:10 --> Loader Class Initialized
INFO - 2018-03-28 15:14:10 --> Helper loaded: url_helper
INFO - 2018-03-28 15:14:10 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:14:10 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:14:10 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:14:10 --> Helper loaded: users_helper
INFO - 2018-03-28 15:14:10 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:14:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:14:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:14:10 --> Helper loaded: form_helper
INFO - 2018-03-28 15:14:10 --> Form Validation Class Initialized
INFO - 2018-03-28 15:14:10 --> Controller Class Initialized
INFO - 2018-03-28 15:14:10 --> Model Class Initialized
INFO - 2018-03-28 15:14:10 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:14:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:14:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:14:10 --> Model Class Initialized
INFO - 2018-03-28 15:14:10 --> Model Class Initialized
INFO - 2018-03-28 15:14:10 --> Model Class Initialized
INFO - 2018-03-28 15:14:10 --> Model Class Initialized
INFO - 2018-03-28 15:14:10 --> Model Class Initialized
INFO - 2018-03-28 15:14:10 --> Model Class Initialized
INFO - 2018-03-28 15:14:10 --> Model Class Initialized
INFO - 2018-03-28 15:14:10 --> Model Class Initialized
INFO - 2018-03-28 15:14:10 --> Model Class Initialized
INFO - 2018-03-28 15:14:10 --> Model Class Initialized
INFO - 2018-03-28 15:14:10 --> Model Class Initialized
INFO - 2018-03-28 15:14:10 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:14:10 --> Final output sent to browser
DEBUG - 2018-03-28 15:14:10 --> Total execution time: 0.2371
INFO - 2018-03-28 09:44:12 --> Config Class Initialized
INFO - 2018-03-28 09:44:12 --> Hooks Class Initialized
DEBUG - 2018-03-28 09:44:12 --> UTF-8 Support Enabled
INFO - 2018-03-28 09:44:12 --> Utf8 Class Initialized
INFO - 2018-03-28 09:44:12 --> URI Class Initialized
INFO - 2018-03-28 09:44:12 --> Router Class Initialized
INFO - 2018-03-28 09:44:12 --> Output Class Initialized
INFO - 2018-03-28 09:44:12 --> Security Class Initialized
DEBUG - 2018-03-28 09:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 09:44:12 --> Input Class Initialized
INFO - 2018-03-28 09:44:12 --> Language Class Initialized
INFO - 2018-03-28 09:44:12 --> Language Class Initialized
INFO - 2018-03-28 09:44:12 --> Config Class Initialized
INFO - 2018-03-28 09:44:12 --> Loader Class Initialized
INFO - 2018-03-28 15:14:12 --> Helper loaded: url_helper
INFO - 2018-03-28 15:14:12 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:14:12 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:14:12 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:14:12 --> Helper loaded: users_helper
INFO - 2018-03-28 15:14:12 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:14:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:14:12 --> Helper loaded: form_helper
INFO - 2018-03-28 15:14:12 --> Form Validation Class Initialized
INFO - 2018-03-28 15:14:12 --> Controller Class Initialized
INFO - 2018-03-28 15:14:12 --> Model Class Initialized
INFO - 2018-03-28 15:14:12 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:14:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:14:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:14:12 --> Model Class Initialized
INFO - 2018-03-28 15:14:12 --> Model Class Initialized
INFO - 2018-03-28 15:14:12 --> Model Class Initialized
INFO - 2018-03-28 15:14:12 --> Model Class Initialized
INFO - 2018-03-28 15:14:12 --> Model Class Initialized
INFO - 2018-03-28 15:14:12 --> Model Class Initialized
INFO - 2018-03-28 15:14:12 --> Model Class Initialized
INFO - 2018-03-28 15:14:12 --> Model Class Initialized
INFO - 2018-03-28 15:14:12 --> Model Class Initialized
INFO - 2018-03-28 15:14:12 --> Model Class Initialized
INFO - 2018-03-28 15:14:12 --> Model Class Initialized
INFO - 2018-03-28 15:14:12 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:14:12 --> Final output sent to browser
DEBUG - 2018-03-28 15:14:12 --> Total execution time: 0.3201
INFO - 2018-03-28 09:44:18 --> Config Class Initialized
INFO - 2018-03-28 09:44:18 --> Hooks Class Initialized
DEBUG - 2018-03-28 09:44:18 --> UTF-8 Support Enabled
INFO - 2018-03-28 09:44:18 --> Utf8 Class Initialized
INFO - 2018-03-28 09:44:18 --> URI Class Initialized
INFO - 2018-03-28 09:44:18 --> Router Class Initialized
INFO - 2018-03-28 09:44:18 --> Output Class Initialized
INFO - 2018-03-28 09:44:18 --> Security Class Initialized
DEBUG - 2018-03-28 09:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 09:44:18 --> Input Class Initialized
INFO - 2018-03-28 09:44:18 --> Language Class Initialized
INFO - 2018-03-28 09:44:18 --> Language Class Initialized
INFO - 2018-03-28 09:44:18 --> Config Class Initialized
INFO - 2018-03-28 09:44:18 --> Loader Class Initialized
INFO - 2018-03-28 15:14:18 --> Helper loaded: url_helper
INFO - 2018-03-28 15:14:18 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:14:18 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:14:18 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:14:18 --> Helper loaded: users_helper
INFO - 2018-03-28 15:14:18 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:14:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:14:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:14:18 --> Helper loaded: form_helper
INFO - 2018-03-28 15:14:18 --> Form Validation Class Initialized
INFO - 2018-03-28 15:14:18 --> Controller Class Initialized
INFO - 2018-03-28 15:14:18 --> Model Class Initialized
INFO - 2018-03-28 15:14:18 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:14:18 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:14:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:14:18 --> Model Class Initialized
INFO - 2018-03-28 15:14:18 --> Model Class Initialized
INFO - 2018-03-28 15:14:18 --> Model Class Initialized
INFO - 2018-03-28 15:14:18 --> Model Class Initialized
INFO - 2018-03-28 15:14:18 --> Model Class Initialized
INFO - 2018-03-28 15:14:18 --> Model Class Initialized
INFO - 2018-03-28 15:14:18 --> Model Class Initialized
INFO - 2018-03-28 15:14:18 --> Model Class Initialized
INFO - 2018-03-28 15:14:18 --> Model Class Initialized
INFO - 2018-03-28 15:14:18 --> Model Class Initialized
INFO - 2018-03-28 15:14:18 --> Model Class Initialized
INFO - 2018-03-28 15:14:18 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:14:18 --> Final output sent to browser
DEBUG - 2018-03-28 15:14:18 --> Total execution time: 0.1224
INFO - 2018-03-28 09:44:21 --> Config Class Initialized
INFO - 2018-03-28 09:44:21 --> Hooks Class Initialized
DEBUG - 2018-03-28 09:44:21 --> UTF-8 Support Enabled
INFO - 2018-03-28 09:44:21 --> Utf8 Class Initialized
INFO - 2018-03-28 09:44:21 --> URI Class Initialized
INFO - 2018-03-28 09:44:21 --> Router Class Initialized
INFO - 2018-03-28 09:44:21 --> Output Class Initialized
INFO - 2018-03-28 09:44:21 --> Security Class Initialized
DEBUG - 2018-03-28 09:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 09:44:21 --> Input Class Initialized
INFO - 2018-03-28 09:44:21 --> Language Class Initialized
INFO - 2018-03-28 09:44:21 --> Language Class Initialized
INFO - 2018-03-28 09:44:21 --> Config Class Initialized
INFO - 2018-03-28 09:44:21 --> Loader Class Initialized
INFO - 2018-03-28 15:14:21 --> Helper loaded: url_helper
INFO - 2018-03-28 15:14:21 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:14:21 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:14:21 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:14:21 --> Helper loaded: users_helper
INFO - 2018-03-28 15:14:21 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:14:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:14:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:14:21 --> Helper loaded: form_helper
INFO - 2018-03-28 15:14:21 --> Form Validation Class Initialized
INFO - 2018-03-28 15:14:21 --> Controller Class Initialized
INFO - 2018-03-28 15:14:21 --> Model Class Initialized
INFO - 2018-03-28 15:14:21 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:14:21 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:14:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:14:21 --> Model Class Initialized
INFO - 2018-03-28 15:14:21 --> Model Class Initialized
INFO - 2018-03-28 15:14:21 --> Model Class Initialized
INFO - 2018-03-28 15:14:21 --> Model Class Initialized
INFO - 2018-03-28 15:14:21 --> Model Class Initialized
INFO - 2018-03-28 15:14:21 --> Model Class Initialized
INFO - 2018-03-28 15:14:21 --> Model Class Initialized
INFO - 2018-03-28 15:14:21 --> Model Class Initialized
INFO - 2018-03-28 15:14:21 --> Model Class Initialized
INFO - 2018-03-28 15:14:21 --> Model Class Initialized
INFO - 2018-03-28 15:14:21 --> Model Class Initialized
INFO - 2018-03-28 15:14:21 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:14:21 --> Final output sent to browser
DEBUG - 2018-03-28 15:14:21 --> Total execution time: 0.1135
INFO - 2018-03-28 09:44:26 --> Config Class Initialized
INFO - 2018-03-28 09:44:26 --> Hooks Class Initialized
DEBUG - 2018-03-28 09:44:26 --> UTF-8 Support Enabled
INFO - 2018-03-28 09:44:26 --> Utf8 Class Initialized
INFO - 2018-03-28 09:44:26 --> URI Class Initialized
INFO - 2018-03-28 09:44:26 --> Router Class Initialized
INFO - 2018-03-28 09:44:26 --> Output Class Initialized
INFO - 2018-03-28 09:44:26 --> Security Class Initialized
DEBUG - 2018-03-28 09:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 09:44:26 --> Input Class Initialized
INFO - 2018-03-28 09:44:26 --> Language Class Initialized
INFO - 2018-03-28 09:44:26 --> Language Class Initialized
INFO - 2018-03-28 09:44:26 --> Config Class Initialized
INFO - 2018-03-28 09:44:26 --> Loader Class Initialized
INFO - 2018-03-28 15:14:26 --> Helper loaded: url_helper
INFO - 2018-03-28 15:14:26 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:14:26 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:14:26 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:14:26 --> Helper loaded: users_helper
INFO - 2018-03-28 15:14:26 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:14:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:14:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:14:26 --> Helper loaded: form_helper
INFO - 2018-03-28 15:14:26 --> Form Validation Class Initialized
INFO - 2018-03-28 15:14:26 --> Controller Class Initialized
INFO - 2018-03-28 15:14:26 --> Model Class Initialized
INFO - 2018-03-28 15:14:26 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:14:26 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:14:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:14:26 --> Model Class Initialized
INFO - 2018-03-28 15:14:26 --> Model Class Initialized
INFO - 2018-03-28 15:14:26 --> Model Class Initialized
INFO - 2018-03-28 15:14:26 --> Model Class Initialized
INFO - 2018-03-28 15:14:26 --> Model Class Initialized
INFO - 2018-03-28 15:14:26 --> Model Class Initialized
INFO - 2018-03-28 15:14:26 --> Model Class Initialized
INFO - 2018-03-28 15:14:26 --> Model Class Initialized
INFO - 2018-03-28 15:14:26 --> Model Class Initialized
INFO - 2018-03-28 15:14:26 --> Model Class Initialized
INFO - 2018-03-28 15:14:26 --> Model Class Initialized
INFO - 2018-03-28 15:14:26 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:14:26 --> Final output sent to browser
DEBUG - 2018-03-28 15:14:26 --> Total execution time: 0.7428
INFO - 2018-03-28 09:55:44 --> Config Class Initialized
INFO - 2018-03-28 09:55:44 --> Hooks Class Initialized
DEBUG - 2018-03-28 09:55:44 --> UTF-8 Support Enabled
INFO - 2018-03-28 09:55:44 --> Utf8 Class Initialized
INFO - 2018-03-28 09:55:44 --> URI Class Initialized
INFO - 2018-03-28 09:55:44 --> Router Class Initialized
INFO - 2018-03-28 09:55:44 --> Output Class Initialized
INFO - 2018-03-28 09:55:44 --> Security Class Initialized
DEBUG - 2018-03-28 09:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 09:55:45 --> Input Class Initialized
INFO - 2018-03-28 09:55:45 --> Language Class Initialized
INFO - 2018-03-28 09:55:46 --> Language Class Initialized
INFO - 2018-03-28 09:55:46 --> Config Class Initialized
INFO - 2018-03-28 09:55:46 --> Loader Class Initialized
INFO - 2018-03-28 15:25:46 --> Helper loaded: url_helper
INFO - 2018-03-28 15:25:46 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:25:46 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:25:46 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:25:46 --> Helper loaded: users_helper
INFO - 2018-03-28 15:25:47 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:25:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:25:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:25:47 --> Helper loaded: form_helper
INFO - 2018-03-28 15:25:47 --> Form Validation Class Initialized
INFO - 2018-03-28 15:25:47 --> Controller Class Initialized
INFO - 2018-03-28 15:25:47 --> Model Class Initialized
INFO - 2018-03-28 15:25:47 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:25:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:25:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:25:47 --> Model Class Initialized
INFO - 2018-03-28 15:25:47 --> Model Class Initialized
INFO - 2018-03-28 15:25:47 --> Model Class Initialized
INFO - 2018-03-28 15:25:47 --> Model Class Initialized
INFO - 2018-03-28 15:25:47 --> Model Class Initialized
INFO - 2018-03-28 15:25:47 --> Model Class Initialized
INFO - 2018-03-28 15:25:47 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:25:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-28 15:25:47 --> Final output sent to browser
DEBUG - 2018-03-28 15:25:47 --> Total execution time: 2.6611
INFO - 2018-03-28 09:55:48 --> Config Class Initialized
INFO - 2018-03-28 09:55:48 --> Hooks Class Initialized
DEBUG - 2018-03-28 09:55:48 --> UTF-8 Support Enabled
INFO - 2018-03-28 09:55:48 --> Utf8 Class Initialized
INFO - 2018-03-28 09:55:48 --> URI Class Initialized
INFO - 2018-03-28 09:55:48 --> Router Class Initialized
INFO - 2018-03-28 09:55:48 --> Output Class Initialized
INFO - 2018-03-28 09:55:48 --> Security Class Initialized
DEBUG - 2018-03-28 09:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 09:55:48 --> Input Class Initialized
INFO - 2018-03-28 09:55:48 --> Language Class Initialized
INFO - 2018-03-28 09:55:48 --> Language Class Initialized
INFO - 2018-03-28 09:55:48 --> Config Class Initialized
INFO - 2018-03-28 09:55:48 --> Loader Class Initialized
INFO - 2018-03-28 15:25:48 --> Helper loaded: url_helper
INFO - 2018-03-28 15:25:48 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:25:48 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:25:48 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:25:48 --> Helper loaded: users_helper
INFO - 2018-03-28 15:25:48 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:25:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:25:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 09:55:48 --> Config Class Initialized
INFO - 2018-03-28 09:55:48 --> Hooks Class Initialized
DEBUG - 2018-03-28 09:55:48 --> UTF-8 Support Enabled
INFO - 2018-03-28 09:55:48 --> Utf8 Class Initialized
INFO - 2018-03-28 09:55:48 --> URI Class Initialized
INFO - 2018-03-28 09:55:48 --> Router Class Initialized
INFO - 2018-03-28 09:55:48 --> Output Class Initialized
INFO - 2018-03-28 09:55:48 --> Security Class Initialized
DEBUG - 2018-03-28 09:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 09:55:48 --> Input Class Initialized
INFO - 2018-03-28 09:55:48 --> Language Class Initialized
INFO - 2018-03-28 09:55:48 --> Language Class Initialized
INFO - 2018-03-28 09:55:48 --> Config Class Initialized
INFO - 2018-03-28 09:55:48 --> Loader Class Initialized
INFO - 2018-03-28 15:25:48 --> Helper loaded: url_helper
INFO - 2018-03-28 15:25:48 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:25:48 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:25:48 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:25:48 --> Helper loaded: users_helper
INFO - 2018-03-28 15:25:48 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:25:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:25:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:25:48 --> Helper loaded: form_helper
INFO - 2018-03-28 15:25:48 --> Form Validation Class Initialized
INFO - 2018-03-28 15:25:48 --> Controller Class Initialized
INFO - 2018-03-28 15:25:48 --> Model Class Initialized
INFO - 2018-03-28 15:25:48 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:25:48 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:25:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:25:48 --> Model Class Initialized
INFO - 2018-03-28 15:25:48 --> Model Class Initialized
INFO - 2018-03-28 15:25:48 --> Model Class Initialized
INFO - 2018-03-28 15:25:48 --> Model Class Initialized
INFO - 2018-03-28 15:25:48 --> Model Class Initialized
INFO - 2018-03-28 15:25:48 --> Model Class Initialized
INFO - 2018-03-28 15:25:48 --> Model Class Initialized
INFO - 2018-03-28 15:25:48 --> Model Class Initialized
INFO - 2018-03-28 15:25:48 --> Model Class Initialized
INFO - 2018-03-28 15:25:48 --> Model Class Initialized
INFO - 2018-03-28 15:25:48 --> Model Class Initialized
INFO - 2018-03-28 15:25:48 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:25:48 --> Model Class Initialized
INFO - 2018-03-28 15:25:48 --> Final output sent to browser
DEBUG - 2018-03-28 15:25:48 --> Total execution time: 0.1673
INFO - 2018-03-28 15:25:48 --> Helper loaded: form_helper
INFO - 2018-03-28 15:25:48 --> Form Validation Class Initialized
INFO - 2018-03-28 15:25:48 --> Controller Class Initialized
INFO - 2018-03-28 15:25:49 --> Model Class Initialized
INFO - 2018-03-28 15:25:49 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:25:49 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:25:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:25:49 --> Model Class Initialized
INFO - 2018-03-28 15:25:49 --> Model Class Initialized
INFO - 2018-03-28 15:25:49 --> Model Class Initialized
INFO - 2018-03-28 15:25:49 --> Model Class Initialized
INFO - 2018-03-28 15:25:49 --> Model Class Initialized
INFO - 2018-03-28 15:25:49 --> Model Class Initialized
INFO - 2018-03-28 15:25:49 --> Model Class Initialized
INFO - 2018-03-28 15:25:49 --> Model Class Initialized
INFO - 2018-03-28 15:25:49 --> Model Class Initialized
INFO - 2018-03-28 15:25:49 --> Model Class Initialized
INFO - 2018-03-28 15:25:49 --> Model Class Initialized
INFO - 2018-03-28 15:25:49 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:25:49 --> Model Class Initialized
INFO - 2018-03-28 15:25:49 --> Final output sent to browser
DEBUG - 2018-03-28 15:25:49 --> Total execution time: 1.4869
INFO - 2018-03-28 09:55:51 --> Config Class Initialized
INFO - 2018-03-28 09:55:51 --> Hooks Class Initialized
DEBUG - 2018-03-28 09:55:51 --> UTF-8 Support Enabled
INFO - 2018-03-28 09:55:51 --> Utf8 Class Initialized
INFO - 2018-03-28 09:55:51 --> URI Class Initialized
INFO - 2018-03-28 09:55:51 --> Router Class Initialized
INFO - 2018-03-28 09:55:51 --> Output Class Initialized
INFO - 2018-03-28 09:55:51 --> Security Class Initialized
DEBUG - 2018-03-28 09:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 09:55:51 --> Input Class Initialized
INFO - 2018-03-28 09:55:51 --> Language Class Initialized
INFO - 2018-03-28 09:55:51 --> Language Class Initialized
INFO - 2018-03-28 09:55:51 --> Config Class Initialized
INFO - 2018-03-28 09:55:51 --> Loader Class Initialized
INFO - 2018-03-28 15:25:51 --> Helper loaded: url_helper
INFO - 2018-03-28 15:25:51 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:25:51 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:25:51 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:25:51 --> Helper loaded: users_helper
INFO - 2018-03-28 15:25:51 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:25:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:25:52 --> Helper loaded: form_helper
INFO - 2018-03-28 15:25:52 --> Form Validation Class Initialized
INFO - 2018-03-28 15:25:52 --> Controller Class Initialized
INFO - 2018-03-28 15:25:52 --> Model Class Initialized
INFO - 2018-03-28 15:25:52 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:25:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:25:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:25:52 --> Model Class Initialized
INFO - 2018-03-28 15:25:52 --> Model Class Initialized
INFO - 2018-03-28 15:25:52 --> Model Class Initialized
INFO - 2018-03-28 15:25:52 --> Model Class Initialized
INFO - 2018-03-28 15:25:52 --> Model Class Initialized
INFO - 2018-03-28 15:25:52 --> Model Class Initialized
INFO - 2018-03-28 15:25:52 --> Model Class Initialized
INFO - 2018-03-28 15:25:52 --> Model Class Initialized
INFO - 2018-03-28 15:25:52 --> Model Class Initialized
INFO - 2018-03-28 15:25:52 --> Model Class Initialized
INFO - 2018-03-28 15:25:52 --> Model Class Initialized
INFO - 2018-03-28 15:25:52 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:25:52 --> Final output sent to browser
DEBUG - 2018-03-28 15:25:52 --> Total execution time: 0.2277
INFO - 2018-03-28 09:55:53 --> Config Class Initialized
INFO - 2018-03-28 09:55:53 --> Hooks Class Initialized
DEBUG - 2018-03-28 09:55:53 --> UTF-8 Support Enabled
INFO - 2018-03-28 09:55:53 --> Utf8 Class Initialized
INFO - 2018-03-28 09:55:53 --> URI Class Initialized
INFO - 2018-03-28 09:55:53 --> Router Class Initialized
INFO - 2018-03-28 09:55:54 --> Output Class Initialized
INFO - 2018-03-28 09:55:54 --> Security Class Initialized
DEBUG - 2018-03-28 09:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 09:55:54 --> Input Class Initialized
INFO - 2018-03-28 09:55:54 --> Config Class Initialized
INFO - 2018-03-28 09:55:54 --> Hooks Class Initialized
DEBUG - 2018-03-28 09:55:54 --> UTF-8 Support Enabled
INFO - 2018-03-28 09:55:54 --> Utf8 Class Initialized
INFO - 2018-03-28 09:55:54 --> URI Class Initialized
INFO - 2018-03-28 09:55:54 --> Router Class Initialized
INFO - 2018-03-28 09:55:54 --> Output Class Initialized
INFO - 2018-03-28 09:55:54 --> Language Class Initialized
INFO - 2018-03-28 09:55:54 --> Security Class Initialized
DEBUG - 2018-03-28 09:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 09:55:54 --> Input Class Initialized
INFO - 2018-03-28 09:55:54 --> Language Class Initialized
INFO - 2018-03-28 09:55:54 --> Language Class Initialized
INFO - 2018-03-28 09:55:54 --> Config Class Initialized
INFO - 2018-03-28 09:55:54 --> Loader Class Initialized
INFO - 2018-03-28 15:25:54 --> Helper loaded: url_helper
INFO - 2018-03-28 15:25:54 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:25:54 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:25:54 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:25:54 --> Helper loaded: users_helper
INFO - 2018-03-28 15:25:54 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:25:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:25:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:25:54 --> Helper loaded: form_helper
INFO - 2018-03-28 15:25:54 --> Form Validation Class Initialized
INFO - 2018-03-28 15:25:54 --> Controller Class Initialized
INFO - 2018-03-28 15:25:54 --> Model Class Initialized
INFO - 2018-03-28 15:25:54 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:25:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:25:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:25:54 --> Model Class Initialized
INFO - 2018-03-28 15:25:54 --> Model Class Initialized
INFO - 2018-03-28 15:25:54 --> Model Class Initialized
INFO - 2018-03-28 15:25:54 --> Model Class Initialized
INFO - 2018-03-28 15:25:54 --> Model Class Initialized
INFO - 2018-03-28 15:25:54 --> Model Class Initialized
INFO - 2018-03-28 15:25:54 --> Model Class Initialized
INFO - 2018-03-28 15:25:54 --> Model Class Initialized
INFO - 2018-03-28 15:25:54 --> Model Class Initialized
INFO - 2018-03-28 15:25:54 --> Model Class Initialized
INFO - 2018-03-28 15:25:54 --> Model Class Initialized
INFO - 2018-03-28 15:25:54 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:25:54 --> Model Class Initialized
INFO - 2018-03-28 15:25:54 --> Final output sent to browser
DEBUG - 2018-03-28 15:25:54 --> Total execution time: 0.2026
INFO - 2018-03-28 09:55:55 --> Language Class Initialized
INFO - 2018-03-28 09:55:55 --> Config Class Initialized
INFO - 2018-03-28 09:55:55 --> Loader Class Initialized
INFO - 2018-03-28 15:25:55 --> Helper loaded: url_helper
INFO - 2018-03-28 15:25:55 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:25:55 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:25:55 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:25:55 --> Helper loaded: users_helper
INFO - 2018-03-28 15:25:56 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:25:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:25:56 --> Helper loaded: form_helper
INFO - 2018-03-28 15:25:56 --> Form Validation Class Initialized
INFO - 2018-03-28 15:25:56 --> Controller Class Initialized
INFO - 2018-03-28 15:25:56 --> Model Class Initialized
INFO - 2018-03-28 15:25:56 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:25:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:25:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:25:56 --> Model Class Initialized
INFO - 2018-03-28 15:25:56 --> Model Class Initialized
INFO - 2018-03-28 15:25:56 --> Model Class Initialized
INFO - 2018-03-28 15:25:56 --> Model Class Initialized
INFO - 2018-03-28 15:25:56 --> Model Class Initialized
INFO - 2018-03-28 15:25:56 --> Model Class Initialized
INFO - 2018-03-28 15:25:56 --> Model Class Initialized
INFO - 2018-03-28 15:25:56 --> Model Class Initialized
INFO - 2018-03-28 15:25:56 --> Model Class Initialized
INFO - 2018-03-28 15:25:56 --> Model Class Initialized
INFO - 2018-03-28 15:25:56 --> Model Class Initialized
INFO - 2018-03-28 15:25:56 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:25:56 --> Model Class Initialized
INFO - 2018-03-28 15:25:56 --> Final output sent to browser
DEBUG - 2018-03-28 15:25:56 --> Total execution time: 2.7681
INFO - 2018-03-28 09:56:04 --> Config Class Initialized
INFO - 2018-03-28 09:56:04 --> Hooks Class Initialized
DEBUG - 2018-03-28 09:56:04 --> UTF-8 Support Enabled
INFO - 2018-03-28 09:56:04 --> Utf8 Class Initialized
INFO - 2018-03-28 09:56:04 --> URI Class Initialized
INFO - 2018-03-28 09:56:04 --> Router Class Initialized
INFO - 2018-03-28 09:56:04 --> Output Class Initialized
INFO - 2018-03-28 09:56:04 --> Security Class Initialized
DEBUG - 2018-03-28 09:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 09:56:04 --> Input Class Initialized
INFO - 2018-03-28 09:56:04 --> Language Class Initialized
INFO - 2018-03-28 09:56:05 --> Language Class Initialized
INFO - 2018-03-28 09:56:05 --> Config Class Initialized
INFO - 2018-03-28 09:56:05 --> Loader Class Initialized
INFO - 2018-03-28 15:26:05 --> Helper loaded: url_helper
INFO - 2018-03-28 15:26:05 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:26:05 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:26:05 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:26:05 --> Helper loaded: users_helper
INFO - 2018-03-28 15:26:05 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:26:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:26:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:26:05 --> Helper loaded: form_helper
INFO - 2018-03-28 15:26:05 --> Form Validation Class Initialized
INFO - 2018-03-28 15:26:05 --> Controller Class Initialized
INFO - 2018-03-28 15:26:05 --> Model Class Initialized
INFO - 2018-03-28 15:26:05 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:26:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:26:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:26:05 --> Model Class Initialized
INFO - 2018-03-28 15:26:05 --> Model Class Initialized
INFO - 2018-03-28 15:26:05 --> Model Class Initialized
INFO - 2018-03-28 15:26:05 --> Model Class Initialized
INFO - 2018-03-28 15:26:05 --> Model Class Initialized
INFO - 2018-03-28 15:26:05 --> Model Class Initialized
INFO - 2018-03-28 15:26:05 --> Model Class Initialized
INFO - 2018-03-28 15:26:05 --> Model Class Initialized
INFO - 2018-03-28 15:26:05 --> Model Class Initialized
INFO - 2018-03-28 15:26:05 --> Model Class Initialized
INFO - 2018-03-28 15:26:05 --> Model Class Initialized
INFO - 2018-03-28 15:26:05 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:26:05 --> Final output sent to browser
DEBUG - 2018-03-28 15:26:05 --> Total execution time: 0.4892
INFO - 2018-03-28 09:56:14 --> Config Class Initialized
INFO - 2018-03-28 09:56:14 --> Hooks Class Initialized
DEBUG - 2018-03-28 09:56:14 --> UTF-8 Support Enabled
INFO - 2018-03-28 09:56:14 --> Utf8 Class Initialized
INFO - 2018-03-28 09:56:14 --> URI Class Initialized
INFO - 2018-03-28 09:56:14 --> Router Class Initialized
INFO - 2018-03-28 09:56:14 --> Output Class Initialized
INFO - 2018-03-28 09:56:14 --> Security Class Initialized
DEBUG - 2018-03-28 09:56:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 09:56:14 --> Input Class Initialized
INFO - 2018-03-28 09:56:14 --> Language Class Initialized
INFO - 2018-03-28 09:56:14 --> Language Class Initialized
INFO - 2018-03-28 09:56:14 --> Config Class Initialized
INFO - 2018-03-28 09:56:14 --> Loader Class Initialized
INFO - 2018-03-28 15:26:14 --> Helper loaded: url_helper
INFO - 2018-03-28 15:26:14 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:26:14 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:26:14 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:26:14 --> Helper loaded: users_helper
INFO - 2018-03-28 15:26:14 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:26:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:26:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:26:14 --> Helper loaded: form_helper
INFO - 2018-03-28 15:26:14 --> Form Validation Class Initialized
INFO - 2018-03-28 15:26:14 --> Controller Class Initialized
INFO - 2018-03-28 15:26:14 --> Model Class Initialized
INFO - 2018-03-28 15:26:14 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:26:14 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:26:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:26:14 --> Model Class Initialized
INFO - 2018-03-28 15:26:14 --> Model Class Initialized
INFO - 2018-03-28 15:26:14 --> Model Class Initialized
INFO - 2018-03-28 15:26:14 --> Model Class Initialized
INFO - 2018-03-28 15:26:14 --> Model Class Initialized
INFO - 2018-03-28 15:26:14 --> Model Class Initialized
INFO - 2018-03-28 15:26:14 --> Model Class Initialized
INFO - 2018-03-28 15:26:14 --> Model Class Initialized
INFO - 2018-03-28 15:26:14 --> Model Class Initialized
INFO - 2018-03-28 15:26:14 --> Model Class Initialized
INFO - 2018-03-28 15:26:14 --> Model Class Initialized
INFO - 2018-03-28 15:26:14 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:26:14 --> Model Class Initialized
INFO - 2018-03-28 15:26:14 --> Final output sent to browser
DEBUG - 2018-03-28 15:26:14 --> Total execution time: 0.1207
INFO - 2018-03-28 09:56:15 --> Config Class Initialized
INFO - 2018-03-28 09:56:15 --> Hooks Class Initialized
DEBUG - 2018-03-28 09:56:15 --> UTF-8 Support Enabled
INFO - 2018-03-28 09:56:15 --> Utf8 Class Initialized
INFO - 2018-03-28 09:56:15 --> URI Class Initialized
INFO - 2018-03-28 09:56:15 --> Router Class Initialized
INFO - 2018-03-28 09:56:15 --> Output Class Initialized
INFO - 2018-03-28 09:56:15 --> Security Class Initialized
DEBUG - 2018-03-28 09:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 09:56:15 --> Input Class Initialized
INFO - 2018-03-28 09:56:15 --> Language Class Initialized
INFO - 2018-03-28 09:56:15 --> Language Class Initialized
INFO - 2018-03-28 09:56:15 --> Config Class Initialized
INFO - 2018-03-28 09:56:15 --> Loader Class Initialized
INFO - 2018-03-28 15:26:15 --> Helper loaded: url_helper
INFO - 2018-03-28 15:26:15 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:26:15 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:26:15 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:26:15 --> Helper loaded: users_helper
INFO - 2018-03-28 15:26:15 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:26:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:26:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:26:15 --> Helper loaded: form_helper
INFO - 2018-03-28 15:26:15 --> Form Validation Class Initialized
INFO - 2018-03-28 15:26:15 --> Controller Class Initialized
INFO - 2018-03-28 15:26:15 --> Model Class Initialized
INFO - 2018-03-28 15:26:15 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:26:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:26:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:26:15 --> Model Class Initialized
INFO - 2018-03-28 15:26:15 --> Model Class Initialized
INFO - 2018-03-28 15:26:15 --> Model Class Initialized
INFO - 2018-03-28 15:26:15 --> Model Class Initialized
INFO - 2018-03-28 15:26:15 --> Model Class Initialized
INFO - 2018-03-28 15:26:15 --> Model Class Initialized
INFO - 2018-03-28 15:26:16 --> Model Class Initialized
INFO - 2018-03-28 15:26:16 --> Model Class Initialized
INFO - 2018-03-28 15:26:16 --> Model Class Initialized
INFO - 2018-03-28 15:26:16 --> Model Class Initialized
INFO - 2018-03-28 15:26:16 --> Model Class Initialized
INFO - 2018-03-28 15:26:16 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:26:16 --> Final output sent to browser
DEBUG - 2018-03-28 15:26:16 --> Total execution time: 0.2152
INFO - 2018-03-28 09:56:18 --> Config Class Initialized
INFO - 2018-03-28 09:56:18 --> Hooks Class Initialized
DEBUG - 2018-03-28 09:56:18 --> UTF-8 Support Enabled
INFO - 2018-03-28 09:56:18 --> Utf8 Class Initialized
INFO - 2018-03-28 09:56:18 --> URI Class Initialized
INFO - 2018-03-28 09:56:18 --> Router Class Initialized
INFO - 2018-03-28 09:56:18 --> Output Class Initialized
INFO - 2018-03-28 09:56:18 --> Security Class Initialized
DEBUG - 2018-03-28 09:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 09:56:18 --> Input Class Initialized
INFO - 2018-03-28 09:56:18 --> Language Class Initialized
INFO - 2018-03-28 09:56:18 --> Language Class Initialized
INFO - 2018-03-28 09:56:18 --> Config Class Initialized
INFO - 2018-03-28 09:56:18 --> Loader Class Initialized
INFO - 2018-03-28 15:26:18 --> Helper loaded: url_helper
INFO - 2018-03-28 15:26:18 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:26:18 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:26:18 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:26:18 --> Helper loaded: users_helper
INFO - 2018-03-28 15:26:18 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:26:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:26:18 --> Helper loaded: form_helper
INFO - 2018-03-28 15:26:18 --> Form Validation Class Initialized
INFO - 2018-03-28 15:26:18 --> Controller Class Initialized
INFO - 2018-03-28 15:26:18 --> Model Class Initialized
INFO - 2018-03-28 15:26:18 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:26:18 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:26:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:26:18 --> Model Class Initialized
INFO - 2018-03-28 15:26:18 --> Model Class Initialized
INFO - 2018-03-28 15:26:18 --> Model Class Initialized
INFO - 2018-03-28 15:26:18 --> Model Class Initialized
INFO - 2018-03-28 15:26:18 --> Model Class Initialized
INFO - 2018-03-28 15:26:18 --> Model Class Initialized
INFO - 2018-03-28 15:26:18 --> Model Class Initialized
INFO - 2018-03-28 15:26:18 --> Model Class Initialized
INFO - 2018-03-28 15:26:18 --> Model Class Initialized
INFO - 2018-03-28 15:26:18 --> Model Class Initialized
INFO - 2018-03-28 15:26:18 --> Model Class Initialized
INFO - 2018-03-28 15:26:18 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:26:18 --> Final output sent to browser
DEBUG - 2018-03-28 15:26:18 --> Total execution time: 0.0993
INFO - 2018-03-28 09:56:19 --> Config Class Initialized
INFO - 2018-03-28 09:56:19 --> Hooks Class Initialized
DEBUG - 2018-03-28 09:56:19 --> UTF-8 Support Enabled
INFO - 2018-03-28 09:56:19 --> Utf8 Class Initialized
INFO - 2018-03-28 09:56:19 --> URI Class Initialized
INFO - 2018-03-28 09:56:19 --> Router Class Initialized
INFO - 2018-03-28 09:56:19 --> Output Class Initialized
INFO - 2018-03-28 09:56:20 --> Security Class Initialized
DEBUG - 2018-03-28 09:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 09:56:20 --> Input Class Initialized
INFO - 2018-03-28 09:56:20 --> Language Class Initialized
INFO - 2018-03-28 09:56:20 --> Language Class Initialized
INFO - 2018-03-28 09:56:20 --> Config Class Initialized
INFO - 2018-03-28 09:56:20 --> Loader Class Initialized
INFO - 2018-03-28 15:26:20 --> Helper loaded: url_helper
INFO - 2018-03-28 15:26:20 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:26:20 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:26:20 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:26:20 --> Helper loaded: users_helper
INFO - 2018-03-28 15:26:20 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:26:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:26:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:26:20 --> Helper loaded: form_helper
INFO - 2018-03-28 15:26:20 --> Form Validation Class Initialized
INFO - 2018-03-28 15:26:20 --> Controller Class Initialized
INFO - 2018-03-28 15:26:20 --> Model Class Initialized
INFO - 2018-03-28 15:26:20 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:26:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:26:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:26:20 --> Model Class Initialized
INFO - 2018-03-28 15:26:20 --> Model Class Initialized
INFO - 2018-03-28 15:26:20 --> Model Class Initialized
INFO - 2018-03-28 15:26:20 --> Model Class Initialized
INFO - 2018-03-28 15:26:20 --> Model Class Initialized
INFO - 2018-03-28 15:26:20 --> Model Class Initialized
INFO - 2018-03-28 15:26:20 --> Model Class Initialized
INFO - 2018-03-28 15:26:20 --> Model Class Initialized
INFO - 2018-03-28 15:26:20 --> Model Class Initialized
INFO - 2018-03-28 15:26:20 --> Model Class Initialized
INFO - 2018-03-28 15:26:20 --> Model Class Initialized
INFO - 2018-03-28 15:26:20 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:26:20 --> Final output sent to browser
DEBUG - 2018-03-28 15:26:20 --> Total execution time: 0.6039
INFO - 2018-03-28 09:56:24 --> Config Class Initialized
INFO - 2018-03-28 09:56:24 --> Hooks Class Initialized
DEBUG - 2018-03-28 09:56:24 --> UTF-8 Support Enabled
INFO - 2018-03-28 09:56:24 --> Utf8 Class Initialized
INFO - 2018-03-28 09:56:24 --> URI Class Initialized
INFO - 2018-03-28 09:56:24 --> Router Class Initialized
INFO - 2018-03-28 09:56:24 --> Output Class Initialized
INFO - 2018-03-28 09:56:24 --> Security Class Initialized
DEBUG - 2018-03-28 09:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 09:56:24 --> Input Class Initialized
INFO - 2018-03-28 09:56:24 --> Language Class Initialized
INFO - 2018-03-28 09:56:24 --> Language Class Initialized
INFO - 2018-03-28 09:56:24 --> Config Class Initialized
INFO - 2018-03-28 09:56:24 --> Loader Class Initialized
INFO - 2018-03-28 15:26:24 --> Helper loaded: url_helper
INFO - 2018-03-28 15:26:24 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:26:24 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:26:24 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:26:24 --> Helper loaded: users_helper
INFO - 2018-03-28 15:26:25 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:26:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:26:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:26:25 --> Helper loaded: form_helper
INFO - 2018-03-28 15:26:25 --> Form Validation Class Initialized
INFO - 2018-03-28 15:26:25 --> Controller Class Initialized
INFO - 2018-03-28 15:26:25 --> Model Class Initialized
INFO - 2018-03-28 15:26:25 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:26:25 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:26:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:26:25 --> Model Class Initialized
INFO - 2018-03-28 15:26:25 --> Model Class Initialized
INFO - 2018-03-28 15:26:25 --> Model Class Initialized
INFO - 2018-03-28 15:26:25 --> Model Class Initialized
INFO - 2018-03-28 15:26:25 --> Model Class Initialized
INFO - 2018-03-28 15:26:25 --> Model Class Initialized
INFO - 2018-03-28 15:26:25 --> Model Class Initialized
INFO - 2018-03-28 15:26:25 --> Model Class Initialized
INFO - 2018-03-28 15:26:25 --> Model Class Initialized
INFO - 2018-03-28 15:26:25 --> Model Class Initialized
INFO - 2018-03-28 15:26:25 --> Model Class Initialized
INFO - 2018-03-28 15:26:25 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:26:25 --> Model Class Initialized
INFO - 2018-03-28 15:26:25 --> Final output sent to browser
DEBUG - 2018-03-28 15:26:25 --> Total execution time: 0.9822
INFO - 2018-03-28 09:56:25 --> Config Class Initialized
INFO - 2018-03-28 09:56:25 --> Hooks Class Initialized
DEBUG - 2018-03-28 09:56:25 --> UTF-8 Support Enabled
INFO - 2018-03-28 09:56:25 --> Utf8 Class Initialized
INFO - 2018-03-28 09:56:25 --> URI Class Initialized
INFO - 2018-03-28 09:56:25 --> Router Class Initialized
INFO - 2018-03-28 09:56:25 --> Output Class Initialized
INFO - 2018-03-28 09:56:25 --> Security Class Initialized
DEBUG - 2018-03-28 09:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 09:56:25 --> Input Class Initialized
INFO - 2018-03-28 09:56:25 --> Language Class Initialized
INFO - 2018-03-28 09:56:25 --> Language Class Initialized
INFO - 2018-03-28 09:56:25 --> Config Class Initialized
INFO - 2018-03-28 09:56:25 --> Loader Class Initialized
INFO - 2018-03-28 15:26:25 --> Helper loaded: url_helper
INFO - 2018-03-28 15:26:25 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:26:25 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:26:25 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:26:25 --> Helper loaded: users_helper
INFO - 2018-03-28 15:26:25 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:26:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:26:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:26:25 --> Helper loaded: form_helper
INFO - 2018-03-28 15:26:25 --> Form Validation Class Initialized
INFO - 2018-03-28 15:26:25 --> Controller Class Initialized
INFO - 2018-03-28 15:26:25 --> Model Class Initialized
INFO - 2018-03-28 15:26:25 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:26:25 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:26:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:26:25 --> Model Class Initialized
INFO - 2018-03-28 15:26:25 --> Model Class Initialized
INFO - 2018-03-28 15:26:25 --> Model Class Initialized
INFO - 2018-03-28 15:26:25 --> Model Class Initialized
INFO - 2018-03-28 15:26:25 --> Model Class Initialized
INFO - 2018-03-28 15:26:25 --> Model Class Initialized
INFO - 2018-03-28 15:26:25 --> Model Class Initialized
INFO - 2018-03-28 15:26:25 --> Model Class Initialized
INFO - 2018-03-28 15:26:25 --> Model Class Initialized
INFO - 2018-03-28 15:26:25 --> Model Class Initialized
INFO - 2018-03-28 15:26:25 --> Model Class Initialized
INFO - 2018-03-28 15:26:25 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:26:25 --> Model Class Initialized
INFO - 2018-03-28 15:26:26 --> Final output sent to browser
DEBUG - 2018-03-28 15:26:26 --> Total execution time: 0.6440
INFO - 2018-03-28 09:56:47 --> Config Class Initialized
INFO - 2018-03-28 09:56:47 --> Hooks Class Initialized
DEBUG - 2018-03-28 09:56:47 --> UTF-8 Support Enabled
INFO - 2018-03-28 09:56:47 --> Utf8 Class Initialized
INFO - 2018-03-28 09:56:47 --> URI Class Initialized
INFO - 2018-03-28 09:56:47 --> Router Class Initialized
INFO - 2018-03-28 09:56:47 --> Output Class Initialized
INFO - 2018-03-28 09:56:47 --> Security Class Initialized
DEBUG - 2018-03-28 09:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 09:56:47 --> Input Class Initialized
INFO - 2018-03-28 09:56:47 --> Language Class Initialized
INFO - 2018-03-28 09:56:47 --> Language Class Initialized
INFO - 2018-03-28 09:56:47 --> Config Class Initialized
INFO - 2018-03-28 09:56:47 --> Loader Class Initialized
INFO - 2018-03-28 15:26:47 --> Helper loaded: url_helper
INFO - 2018-03-28 15:26:47 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:26:47 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:26:47 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:26:47 --> Helper loaded: users_helper
INFO - 2018-03-28 15:26:47 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:26:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:26:47 --> Helper loaded: form_helper
INFO - 2018-03-28 15:26:47 --> Form Validation Class Initialized
INFO - 2018-03-28 15:26:47 --> Controller Class Initialized
INFO - 2018-03-28 15:26:48 --> Model Class Initialized
INFO - 2018-03-28 15:26:48 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:26:48 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:26:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:26:48 --> Model Class Initialized
INFO - 2018-03-28 15:26:48 --> Model Class Initialized
INFO - 2018-03-28 15:26:48 --> Model Class Initialized
INFO - 2018-03-28 15:26:48 --> Model Class Initialized
INFO - 2018-03-28 15:26:48 --> Model Class Initialized
INFO - 2018-03-28 15:26:48 --> Model Class Initialized
INFO - 2018-03-28 15:26:48 --> Model Class Initialized
INFO - 2018-03-28 15:26:48 --> Model Class Initialized
INFO - 2018-03-28 15:26:48 --> Model Class Initialized
INFO - 2018-03-28 15:26:48 --> Model Class Initialized
INFO - 2018-03-28 15:26:48 --> Model Class Initialized
INFO - 2018-03-28 15:26:48 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:26:48 --> Final output sent to browser
DEBUG - 2018-03-28 15:26:48 --> Total execution time: 0.2560
INFO - 2018-03-28 09:56:49 --> Config Class Initialized
INFO - 2018-03-28 09:56:49 --> Hooks Class Initialized
DEBUG - 2018-03-28 09:56:49 --> UTF-8 Support Enabled
INFO - 2018-03-28 09:56:49 --> Utf8 Class Initialized
INFO - 2018-03-28 09:56:49 --> URI Class Initialized
INFO - 2018-03-28 09:56:49 --> Router Class Initialized
INFO - 2018-03-28 09:56:49 --> Output Class Initialized
INFO - 2018-03-28 09:56:49 --> Security Class Initialized
DEBUG - 2018-03-28 09:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 09:56:49 --> Input Class Initialized
INFO - 2018-03-28 09:56:49 --> Language Class Initialized
INFO - 2018-03-28 09:56:50 --> Language Class Initialized
INFO - 2018-03-28 09:56:50 --> Config Class Initialized
INFO - 2018-03-28 09:56:50 --> Loader Class Initialized
INFO - 2018-03-28 15:26:50 --> Helper loaded: url_helper
INFO - 2018-03-28 15:26:50 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:26:50 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:26:50 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:26:50 --> Helper loaded: users_helper
INFO - 2018-03-28 15:26:51 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:26:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:26:52 --> Helper loaded: form_helper
INFO - 2018-03-28 15:26:52 --> Form Validation Class Initialized
INFO - 2018-03-28 15:26:52 --> Controller Class Initialized
INFO - 2018-03-28 09:56:52 --> Config Class Initialized
INFO - 2018-03-28 09:56:52 --> Hooks Class Initialized
DEBUG - 2018-03-28 09:56:52 --> UTF-8 Support Enabled
INFO - 2018-03-28 09:56:52 --> Utf8 Class Initialized
INFO - 2018-03-28 09:56:52 --> URI Class Initialized
INFO - 2018-03-28 09:56:52 --> Router Class Initialized
INFO - 2018-03-28 09:56:52 --> Output Class Initialized
INFO - 2018-03-28 09:56:52 --> Security Class Initialized
INFO - 2018-03-28 15:26:52 --> Model Class Initialized
INFO - 2018-03-28 15:26:52 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 09:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 09:56:52 --> Input Class Initialized
INFO - 2018-03-28 09:56:52 --> Language Class Initialized
DEBUG - 2018-03-28 15:26:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:26:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:26:53 --> Model Class Initialized
INFO - 2018-03-28 15:26:53 --> Model Class Initialized
INFO - 2018-03-28 15:26:53 --> Model Class Initialized
INFO - 2018-03-28 09:56:53 --> Language Class Initialized
INFO - 2018-03-28 09:56:53 --> Config Class Initialized
INFO - 2018-03-28 09:56:53 --> Loader Class Initialized
INFO - 2018-03-28 15:26:53 --> Model Class Initialized
INFO - 2018-03-28 15:26:53 --> Model Class Initialized
INFO - 2018-03-28 15:26:53 --> Model Class Initialized
INFO - 2018-03-28 15:26:53 --> Model Class Initialized
INFO - 2018-03-28 15:26:53 --> Model Class Initialized
INFO - 2018-03-28 15:26:53 --> Model Class Initialized
INFO - 2018-03-28 15:26:53 --> Model Class Initialized
INFO - 2018-03-28 15:26:53 --> Helper loaded: url_helper
INFO - 2018-03-28 15:26:53 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:26:53 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:26:53 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:26:53 --> Helper loaded: users_helper
INFO - 2018-03-28 15:26:53 --> Model Class Initialized
INFO - 2018-03-28 15:26:53 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:26:53 --> Model Class Initialized
INFO - 2018-03-28 15:26:53 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:26:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:26:53 --> Final output sent to browser
DEBUG - 2018-03-28 15:26:53 --> Total execution time: 4.0621
INFO - 2018-03-28 15:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:26:53 --> Helper loaded: form_helper
INFO - 2018-03-28 15:26:53 --> Form Validation Class Initialized
INFO - 2018-03-28 15:26:53 --> Controller Class Initialized
INFO - 2018-03-28 15:26:53 --> Model Class Initialized
INFO - 2018-03-28 15:26:53 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:26:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:26:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:26:53 --> Model Class Initialized
INFO - 2018-03-28 15:26:53 --> Model Class Initialized
INFO - 2018-03-28 15:26:53 --> Model Class Initialized
INFO - 2018-03-28 15:26:53 --> Model Class Initialized
INFO - 2018-03-28 15:26:53 --> Model Class Initialized
INFO - 2018-03-28 15:26:53 --> Model Class Initialized
INFO - 2018-03-28 15:26:53 --> Model Class Initialized
INFO - 2018-03-28 15:26:53 --> Model Class Initialized
INFO - 2018-03-28 15:26:53 --> Model Class Initialized
INFO - 2018-03-28 15:26:53 --> Model Class Initialized
INFO - 2018-03-28 15:26:53 --> Model Class Initialized
INFO - 2018-03-28 15:26:53 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:26:53 --> Model Class Initialized
INFO - 2018-03-28 15:26:53 --> Final output sent to browser
DEBUG - 2018-03-28 15:26:53 --> Total execution time: 1.1980
INFO - 2018-03-28 09:56:56 --> Config Class Initialized
INFO - 2018-03-28 09:56:56 --> Hooks Class Initialized
DEBUG - 2018-03-28 09:56:56 --> UTF-8 Support Enabled
INFO - 2018-03-28 09:56:56 --> Utf8 Class Initialized
INFO - 2018-03-28 09:56:56 --> URI Class Initialized
INFO - 2018-03-28 09:56:56 --> Router Class Initialized
INFO - 2018-03-28 09:56:56 --> Output Class Initialized
INFO - 2018-03-28 09:56:56 --> Security Class Initialized
DEBUG - 2018-03-28 09:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 09:56:56 --> Input Class Initialized
INFO - 2018-03-28 09:56:56 --> Language Class Initialized
INFO - 2018-03-28 09:56:56 --> Language Class Initialized
INFO - 2018-03-28 09:56:56 --> Config Class Initialized
INFO - 2018-03-28 09:56:56 --> Loader Class Initialized
INFO - 2018-03-28 15:26:56 --> Helper loaded: url_helper
INFO - 2018-03-28 15:26:56 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:26:56 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:26:56 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:26:56 --> Helper loaded: users_helper
INFO - 2018-03-28 15:26:56 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:26:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:26:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:26:56 --> Helper loaded: form_helper
INFO - 2018-03-28 15:26:56 --> Form Validation Class Initialized
INFO - 2018-03-28 15:26:56 --> Controller Class Initialized
INFO - 2018-03-28 15:26:56 --> Model Class Initialized
INFO - 2018-03-28 15:26:56 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:26:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:26:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:26:56 --> Model Class Initialized
INFO - 2018-03-28 15:26:56 --> Model Class Initialized
INFO - 2018-03-28 15:26:56 --> Model Class Initialized
INFO - 2018-03-28 15:26:56 --> Model Class Initialized
INFO - 2018-03-28 15:26:56 --> Model Class Initialized
INFO - 2018-03-28 15:26:56 --> Model Class Initialized
INFO - 2018-03-28 15:26:56 --> Model Class Initialized
INFO - 2018-03-28 15:26:56 --> Model Class Initialized
INFO - 2018-03-28 15:26:56 --> Model Class Initialized
INFO - 2018-03-28 15:26:56 --> Model Class Initialized
INFO - 2018-03-28 15:26:57 --> Model Class Initialized
INFO - 2018-03-28 15:26:57 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:26:57 --> Final output sent to browser
DEBUG - 2018-03-28 15:26:57 --> Total execution time: 0.8087
INFO - 2018-03-28 09:57:03 --> Config Class Initialized
INFO - 2018-03-28 09:57:03 --> Hooks Class Initialized
DEBUG - 2018-03-28 09:57:03 --> UTF-8 Support Enabled
INFO - 2018-03-28 09:57:03 --> Utf8 Class Initialized
INFO - 2018-03-28 09:57:03 --> URI Class Initialized
INFO - 2018-03-28 09:57:03 --> Router Class Initialized
INFO - 2018-03-28 09:57:03 --> Output Class Initialized
INFO - 2018-03-28 09:57:03 --> Security Class Initialized
DEBUG - 2018-03-28 09:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 09:57:03 --> Input Class Initialized
INFO - 2018-03-28 09:57:03 --> Language Class Initialized
INFO - 2018-03-28 09:57:04 --> Language Class Initialized
INFO - 2018-03-28 09:57:04 --> Config Class Initialized
INFO - 2018-03-28 09:57:04 --> Loader Class Initialized
INFO - 2018-03-28 15:27:04 --> Helper loaded: url_helper
INFO - 2018-03-28 15:27:04 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:27:04 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:27:04 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:27:04 --> Helper loaded: users_helper
INFO - 2018-03-28 15:27:04 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:27:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:27:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:27:04 --> Helper loaded: form_helper
INFO - 2018-03-28 15:27:04 --> Form Validation Class Initialized
INFO - 2018-03-28 15:27:04 --> Controller Class Initialized
INFO - 2018-03-28 15:27:04 --> Model Class Initialized
INFO - 2018-03-28 15:27:04 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:27:04 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:27:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:27:04 --> Model Class Initialized
INFO - 2018-03-28 15:27:04 --> Model Class Initialized
INFO - 2018-03-28 15:27:04 --> Model Class Initialized
INFO - 2018-03-28 15:27:04 --> Model Class Initialized
INFO - 2018-03-28 15:27:04 --> Model Class Initialized
INFO - 2018-03-28 15:27:04 --> Model Class Initialized
INFO - 2018-03-28 15:27:04 --> Model Class Initialized
INFO - 2018-03-28 15:27:04 --> Model Class Initialized
INFO - 2018-03-28 15:27:04 --> Model Class Initialized
INFO - 2018-03-28 15:27:04 --> Model Class Initialized
INFO - 2018-03-28 15:27:04 --> Model Class Initialized
INFO - 2018-03-28 15:27:04 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:27:04 --> Final output sent to browser
DEBUG - 2018-03-28 15:27:04 --> Total execution time: 0.1680
INFO - 2018-03-28 09:57:04 --> Config Class Initialized
INFO - 2018-03-28 09:57:04 --> Hooks Class Initialized
DEBUG - 2018-03-28 09:57:04 --> UTF-8 Support Enabled
INFO - 2018-03-28 09:57:04 --> Utf8 Class Initialized
INFO - 2018-03-28 09:57:04 --> URI Class Initialized
INFO - 2018-03-28 09:57:04 --> Router Class Initialized
INFO - 2018-03-28 09:57:04 --> Output Class Initialized
INFO - 2018-03-28 09:57:04 --> Security Class Initialized
DEBUG - 2018-03-28 09:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 09:57:04 --> Input Class Initialized
INFO - 2018-03-28 09:57:04 --> Language Class Initialized
INFO - 2018-03-28 09:57:04 --> Language Class Initialized
INFO - 2018-03-28 09:57:04 --> Config Class Initialized
INFO - 2018-03-28 09:57:04 --> Loader Class Initialized
INFO - 2018-03-28 15:27:04 --> Helper loaded: url_helper
INFO - 2018-03-28 15:27:04 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:27:04 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:27:04 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:27:04 --> Helper loaded: users_helper
INFO - 2018-03-28 15:27:04 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:27:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:27:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:27:04 --> Helper loaded: form_helper
INFO - 2018-03-28 15:27:04 --> Form Validation Class Initialized
INFO - 2018-03-28 15:27:04 --> Controller Class Initialized
INFO - 2018-03-28 15:27:04 --> Model Class Initialized
INFO - 2018-03-28 15:27:04 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:27:04 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:27:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:27:04 --> Model Class Initialized
INFO - 2018-03-28 15:27:04 --> Model Class Initialized
INFO - 2018-03-28 15:27:04 --> Model Class Initialized
INFO - 2018-03-28 15:27:04 --> Model Class Initialized
INFO - 2018-03-28 15:27:04 --> Model Class Initialized
INFO - 2018-03-28 15:27:04 --> Model Class Initialized
INFO - 2018-03-28 15:27:04 --> Model Class Initialized
INFO - 2018-03-28 15:27:04 --> Model Class Initialized
INFO - 2018-03-28 15:27:04 --> Model Class Initialized
INFO - 2018-03-28 15:27:04 --> Model Class Initialized
INFO - 2018-03-28 15:27:04 --> Model Class Initialized
INFO - 2018-03-28 15:27:04 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:27:04 --> Final output sent to browser
DEBUG - 2018-03-28 15:27:04 --> Total execution time: 0.5230
INFO - 2018-03-28 09:57:08 --> Config Class Initialized
INFO - 2018-03-28 09:57:08 --> Hooks Class Initialized
DEBUG - 2018-03-28 09:57:08 --> UTF-8 Support Enabled
INFO - 2018-03-28 09:57:08 --> Utf8 Class Initialized
INFO - 2018-03-28 09:57:08 --> URI Class Initialized
INFO - 2018-03-28 09:57:08 --> Router Class Initialized
INFO - 2018-03-28 09:57:08 --> Output Class Initialized
INFO - 2018-03-28 09:57:08 --> Security Class Initialized
DEBUG - 2018-03-28 09:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 09:57:08 --> Input Class Initialized
INFO - 2018-03-28 09:57:08 --> Language Class Initialized
INFO - 2018-03-28 09:57:08 --> Config Class Initialized
INFO - 2018-03-28 09:57:08 --> Hooks Class Initialized
DEBUG - 2018-03-28 09:57:08 --> UTF-8 Support Enabled
INFO - 2018-03-28 09:57:08 --> Utf8 Class Initialized
INFO - 2018-03-28 09:57:08 --> URI Class Initialized
INFO - 2018-03-28 09:57:08 --> Router Class Initialized
INFO - 2018-03-28 09:57:08 --> Output Class Initialized
INFO - 2018-03-28 09:57:08 --> Security Class Initialized
DEBUG - 2018-03-28 09:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 09:57:08 --> Input Class Initialized
INFO - 2018-03-28 09:57:08 --> Language Class Initialized
INFO - 2018-03-28 09:57:08 --> Language Class Initialized
INFO - 2018-03-28 09:57:08 --> Config Class Initialized
INFO - 2018-03-28 09:57:08 --> Loader Class Initialized
INFO - 2018-03-28 15:27:08 --> Helper loaded: url_helper
INFO - 2018-03-28 15:27:08 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:27:08 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:27:08 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:27:08 --> Helper loaded: users_helper
INFO - 2018-03-28 15:27:08 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:27:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:27:08 --> Helper loaded: form_helper
INFO - 2018-03-28 15:27:08 --> Form Validation Class Initialized
INFO - 2018-03-28 15:27:08 --> Controller Class Initialized
INFO - 2018-03-28 15:27:08 --> Model Class Initialized
INFO - 2018-03-28 15:27:08 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:27:08 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:27:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:27:08 --> Model Class Initialized
INFO - 2018-03-28 15:27:08 --> Model Class Initialized
INFO - 2018-03-28 15:27:08 --> Model Class Initialized
INFO - 2018-03-28 15:27:08 --> Model Class Initialized
INFO - 2018-03-28 15:27:08 --> Model Class Initialized
INFO - 2018-03-28 15:27:08 --> Model Class Initialized
INFO - 2018-03-28 15:27:08 --> Model Class Initialized
INFO - 2018-03-28 15:27:08 --> Model Class Initialized
INFO - 2018-03-28 15:27:08 --> Model Class Initialized
INFO - 2018-03-28 15:27:08 --> Model Class Initialized
INFO - 2018-03-28 15:27:08 --> Model Class Initialized
INFO - 2018-03-28 15:27:08 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:27:08 --> Model Class Initialized
INFO - 2018-03-28 15:27:08 --> Final output sent to browser
DEBUG - 2018-03-28 15:27:08 --> Total execution time: 0.1487
INFO - 2018-03-28 09:57:08 --> Language Class Initialized
INFO - 2018-03-28 09:57:08 --> Config Class Initialized
INFO - 2018-03-28 09:57:08 --> Loader Class Initialized
INFO - 2018-03-28 15:27:08 --> Helper loaded: url_helper
INFO - 2018-03-28 15:27:08 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:27:08 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:27:08 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:27:08 --> Helper loaded: users_helper
INFO - 2018-03-28 15:27:09 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:27:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:27:09 --> Helper loaded: form_helper
INFO - 2018-03-28 15:27:09 --> Form Validation Class Initialized
INFO - 2018-03-28 15:27:09 --> Controller Class Initialized
INFO - 2018-03-28 15:27:09 --> Model Class Initialized
INFO - 2018-03-28 15:27:09 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:27:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:27:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:27:09 --> Model Class Initialized
INFO - 2018-03-28 15:27:09 --> Model Class Initialized
INFO - 2018-03-28 15:27:09 --> Model Class Initialized
INFO - 2018-03-28 15:27:09 --> Model Class Initialized
INFO - 2018-03-28 15:27:09 --> Model Class Initialized
INFO - 2018-03-28 15:27:09 --> Model Class Initialized
INFO - 2018-03-28 15:27:09 --> Model Class Initialized
INFO - 2018-03-28 15:27:09 --> Model Class Initialized
INFO - 2018-03-28 15:27:09 --> Model Class Initialized
INFO - 2018-03-28 15:27:10 --> Model Class Initialized
INFO - 2018-03-28 15:27:10 --> Model Class Initialized
INFO - 2018-03-28 15:27:10 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:27:10 --> Model Class Initialized
INFO - 2018-03-28 15:27:10 --> Final output sent to browser
DEBUG - 2018-03-28 15:27:10 --> Total execution time: 2.6414
INFO - 2018-03-28 10:02:16 --> Config Class Initialized
INFO - 2018-03-28 10:02:16 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:02:16 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:02:16 --> Utf8 Class Initialized
INFO - 2018-03-28 10:02:16 --> URI Class Initialized
INFO - 2018-03-28 10:02:16 --> Router Class Initialized
INFO - 2018-03-28 10:02:16 --> Output Class Initialized
INFO - 2018-03-28 10:02:16 --> Security Class Initialized
DEBUG - 2018-03-28 10:02:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:02:16 --> Input Class Initialized
INFO - 2018-03-28 10:02:16 --> Language Class Initialized
INFO - 2018-03-28 10:02:16 --> Language Class Initialized
INFO - 2018-03-28 10:02:16 --> Config Class Initialized
INFO - 2018-03-28 10:02:16 --> Loader Class Initialized
INFO - 2018-03-28 15:32:16 --> Helper loaded: url_helper
INFO - 2018-03-28 15:32:16 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:32:16 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:32:16 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:32:16 --> Helper loaded: users_helper
INFO - 2018-03-28 15:32:16 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:32:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:32:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:32:16 --> Helper loaded: form_helper
INFO - 2018-03-28 15:32:16 --> Form Validation Class Initialized
INFO - 2018-03-28 15:32:16 --> Controller Class Initialized
INFO - 2018-03-28 15:32:16 --> Model Class Initialized
INFO - 2018-03-28 15:32:16 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:32:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:32:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:32:16 --> Model Class Initialized
INFO - 2018-03-28 15:32:16 --> Model Class Initialized
INFO - 2018-03-28 15:32:16 --> Model Class Initialized
INFO - 2018-03-28 15:32:16 --> Model Class Initialized
INFO - 2018-03-28 15:32:16 --> Model Class Initialized
INFO - 2018-03-28 15:32:16 --> Model Class Initialized
INFO - 2018-03-28 15:32:16 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:32:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-28 15:32:16 --> Final output sent to browser
DEBUG - 2018-03-28 15:32:16 --> Total execution time: 0.3238
INFO - 2018-03-28 10:02:17 --> Config Class Initialized
INFO - 2018-03-28 10:02:17 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:02:17 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:02:17 --> Utf8 Class Initialized
INFO - 2018-03-28 10:02:17 --> Config Class Initialized
INFO - 2018-03-28 10:02:17 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:02:17 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:02:17 --> Utf8 Class Initialized
INFO - 2018-03-28 10:02:17 --> URI Class Initialized
INFO - 2018-03-28 10:02:17 --> Router Class Initialized
INFO - 2018-03-28 10:02:17 --> Output Class Initialized
INFO - 2018-03-28 10:02:17 --> Security Class Initialized
DEBUG - 2018-03-28 10:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:02:17 --> Input Class Initialized
INFO - 2018-03-28 10:02:17 --> Language Class Initialized
INFO - 2018-03-28 10:02:17 --> URI Class Initialized
INFO - 2018-03-28 10:02:17 --> Language Class Initialized
INFO - 2018-03-28 10:02:17 --> Config Class Initialized
INFO - 2018-03-28 10:02:17 --> Loader Class Initialized
INFO - 2018-03-28 15:32:17 --> Helper loaded: url_helper
INFO - 2018-03-28 15:32:17 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:32:17 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:32:17 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:32:17 --> Helper loaded: users_helper
INFO - 2018-03-28 15:32:17 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:32:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:32:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:32:17 --> Helper loaded: form_helper
INFO - 2018-03-28 15:32:17 --> Form Validation Class Initialized
INFO - 2018-03-28 15:32:17 --> Controller Class Initialized
INFO - 2018-03-28 15:32:17 --> Model Class Initialized
INFO - 2018-03-28 15:32:17 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:32:17 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:32:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:32:17 --> Model Class Initialized
INFO - 2018-03-28 15:32:17 --> Model Class Initialized
INFO - 2018-03-28 15:32:17 --> Model Class Initialized
INFO - 2018-03-28 15:32:17 --> Model Class Initialized
INFO - 2018-03-28 15:32:17 --> Model Class Initialized
INFO - 2018-03-28 15:32:17 --> Model Class Initialized
INFO - 2018-03-28 15:32:17 --> Model Class Initialized
INFO - 2018-03-28 15:32:17 --> Model Class Initialized
INFO - 2018-03-28 15:32:17 --> Model Class Initialized
INFO - 2018-03-28 15:32:17 --> Model Class Initialized
INFO - 2018-03-28 15:32:17 --> Model Class Initialized
INFO - 2018-03-28 15:32:17 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:32:17 --> Model Class Initialized
INFO - 2018-03-28 15:32:17 --> Final output sent to browser
DEBUG - 2018-03-28 15:32:17 --> Total execution time: 0.2705
INFO - 2018-03-28 10:02:17 --> Router Class Initialized
INFO - 2018-03-28 10:02:18 --> Output Class Initialized
INFO - 2018-03-28 10:02:18 --> Security Class Initialized
DEBUG - 2018-03-28 10:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:02:18 --> Input Class Initialized
INFO - 2018-03-28 10:02:18 --> Language Class Initialized
INFO - 2018-03-28 10:02:19 --> Language Class Initialized
INFO - 2018-03-28 10:02:19 --> Config Class Initialized
INFO - 2018-03-28 10:02:19 --> Loader Class Initialized
INFO - 2018-03-28 15:32:19 --> Helper loaded: url_helper
INFO - 2018-03-28 15:32:19 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:32:19 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:32:19 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:32:19 --> Helper loaded: users_helper
INFO - 2018-03-28 15:32:20 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:32:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:32:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:32:20 --> Helper loaded: form_helper
INFO - 2018-03-28 15:32:20 --> Form Validation Class Initialized
INFO - 2018-03-28 15:32:20 --> Controller Class Initialized
INFO - 2018-03-28 15:32:20 --> Model Class Initialized
INFO - 2018-03-28 15:32:20 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:32:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:32:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 10:02:20 --> Config Class Initialized
INFO - 2018-03-28 10:02:20 --> Hooks Class Initialized
INFO - 2018-03-28 15:32:20 --> Model Class Initialized
INFO - 2018-03-28 15:32:20 --> Model Class Initialized
DEBUG - 2018-03-28 10:02:20 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:02:20 --> Utf8 Class Initialized
INFO - 2018-03-28 15:32:20 --> Model Class Initialized
INFO - 2018-03-28 10:02:20 --> URI Class Initialized
INFO - 2018-03-28 15:32:20 --> Model Class Initialized
INFO - 2018-03-28 15:32:20 --> Model Class Initialized
INFO - 2018-03-28 15:32:20 --> Model Class Initialized
INFO - 2018-03-28 15:32:20 --> Model Class Initialized
INFO - 2018-03-28 10:02:20 --> Router Class Initialized
INFO - 2018-03-28 15:32:20 --> Model Class Initialized
INFO - 2018-03-28 15:32:20 --> Model Class Initialized
INFO - 2018-03-28 15:32:20 --> Model Class Initialized
INFO - 2018-03-28 10:02:20 --> Output Class Initialized
INFO - 2018-03-28 15:32:20 --> Model Class Initialized
INFO - 2018-03-28 15:32:20 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:32:20 --> Model Class Initialized
INFO - 2018-03-28 10:02:21 --> Security Class Initialized
INFO - 2018-03-28 15:32:21 --> Final output sent to browser
DEBUG - 2018-03-28 15:32:21 --> Total execution time: 3.6677
DEBUG - 2018-03-28 10:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:02:21 --> Input Class Initialized
INFO - 2018-03-28 10:02:21 --> Language Class Initialized
INFO - 2018-03-28 10:02:21 --> Language Class Initialized
INFO - 2018-03-28 10:02:21 --> Config Class Initialized
INFO - 2018-03-28 10:02:21 --> Loader Class Initialized
INFO - 2018-03-28 15:32:21 --> Helper loaded: url_helper
INFO - 2018-03-28 15:32:21 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:32:21 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:32:21 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:32:21 --> Helper loaded: users_helper
INFO - 2018-03-28 15:32:21 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:32:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:32:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:32:21 --> Helper loaded: form_helper
INFO - 2018-03-28 15:32:21 --> Form Validation Class Initialized
INFO - 2018-03-28 15:32:21 --> Controller Class Initialized
INFO - 2018-03-28 15:32:22 --> Model Class Initialized
INFO - 2018-03-28 15:32:22 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:32:22 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:32:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:32:22 --> Model Class Initialized
INFO - 2018-03-28 15:32:22 --> Model Class Initialized
INFO - 2018-03-28 15:32:22 --> Model Class Initialized
INFO - 2018-03-28 15:32:22 --> Model Class Initialized
INFO - 2018-03-28 15:32:22 --> Model Class Initialized
INFO - 2018-03-28 15:32:22 --> Model Class Initialized
INFO - 2018-03-28 15:32:22 --> Model Class Initialized
INFO - 2018-03-28 15:32:22 --> Model Class Initialized
INFO - 2018-03-28 15:32:22 --> Model Class Initialized
INFO - 2018-03-28 15:32:22 --> Model Class Initialized
INFO - 2018-03-28 15:32:22 --> Model Class Initialized
INFO - 2018-03-28 15:32:22 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:32:22 --> Model Class Initialized
INFO - 2018-03-28 15:32:22 --> Final output sent to browser
DEBUG - 2018-03-28 15:32:22 --> Total execution time: 1.7170
INFO - 2018-03-28 10:02:24 --> Config Class Initialized
INFO - 2018-03-28 10:02:24 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:02:24 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:02:24 --> Utf8 Class Initialized
INFO - 2018-03-28 10:02:24 --> URI Class Initialized
INFO - 2018-03-28 10:02:24 --> Router Class Initialized
INFO - 2018-03-28 10:02:24 --> Output Class Initialized
INFO - 2018-03-28 10:02:24 --> Security Class Initialized
DEBUG - 2018-03-28 10:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:02:24 --> Input Class Initialized
INFO - 2018-03-28 10:02:24 --> Language Class Initialized
INFO - 2018-03-28 10:02:24 --> Language Class Initialized
INFO - 2018-03-28 10:02:24 --> Config Class Initialized
INFO - 2018-03-28 10:02:24 --> Loader Class Initialized
INFO - 2018-03-28 15:32:24 --> Helper loaded: url_helper
INFO - 2018-03-28 15:32:24 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:32:24 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:32:24 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:32:24 --> Helper loaded: users_helper
INFO - 2018-03-28 15:32:25 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:32:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:32:25 --> Helper loaded: form_helper
INFO - 2018-03-28 15:32:25 --> Form Validation Class Initialized
INFO - 2018-03-28 15:32:25 --> Controller Class Initialized
INFO - 2018-03-28 15:32:25 --> Model Class Initialized
INFO - 2018-03-28 15:32:25 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:32:25 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:32:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:32:25 --> Model Class Initialized
INFO - 2018-03-28 15:32:25 --> Model Class Initialized
INFO - 2018-03-28 15:32:25 --> Model Class Initialized
INFO - 2018-03-28 15:32:25 --> Model Class Initialized
INFO - 2018-03-28 15:32:25 --> Model Class Initialized
INFO - 2018-03-28 15:32:25 --> Model Class Initialized
INFO - 2018-03-28 15:32:25 --> Model Class Initialized
INFO - 2018-03-28 15:32:25 --> Model Class Initialized
INFO - 2018-03-28 15:32:25 --> Model Class Initialized
INFO - 2018-03-28 15:32:25 --> Model Class Initialized
INFO - 2018-03-28 15:32:25 --> Model Class Initialized
INFO - 2018-03-28 15:32:25 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:32:25 --> Model Class Initialized
INFO - 2018-03-28 15:32:25 --> Final output sent to browser
DEBUG - 2018-03-28 15:32:25 --> Total execution time: 0.5195
INFO - 2018-03-28 10:02:25 --> Config Class Initialized
INFO - 2018-03-28 10:02:25 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:02:25 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:02:25 --> Utf8 Class Initialized
INFO - 2018-03-28 10:02:25 --> URI Class Initialized
INFO - 2018-03-28 10:02:25 --> Router Class Initialized
INFO - 2018-03-28 10:02:25 --> Output Class Initialized
INFO - 2018-03-28 10:02:25 --> Security Class Initialized
DEBUG - 2018-03-28 10:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:02:25 --> Input Class Initialized
INFO - 2018-03-28 10:02:25 --> Language Class Initialized
INFO - 2018-03-28 10:02:25 --> Language Class Initialized
INFO - 2018-03-28 10:02:25 --> Config Class Initialized
INFO - 2018-03-28 10:02:25 --> Loader Class Initialized
INFO - 2018-03-28 15:32:25 --> Helper loaded: url_helper
INFO - 2018-03-28 15:32:25 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:32:25 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:32:25 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:32:25 --> Helper loaded: users_helper
INFO - 2018-03-28 15:32:25 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:32:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:32:26 --> Helper loaded: form_helper
INFO - 2018-03-28 15:32:26 --> Form Validation Class Initialized
INFO - 2018-03-28 15:32:26 --> Controller Class Initialized
INFO - 2018-03-28 15:32:26 --> Model Class Initialized
INFO - 2018-03-28 15:32:26 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:32:26 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:32:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:32:26 --> Model Class Initialized
INFO - 2018-03-28 15:32:26 --> Model Class Initialized
INFO - 2018-03-28 15:32:26 --> Model Class Initialized
INFO - 2018-03-28 15:32:26 --> Model Class Initialized
INFO - 2018-03-28 15:32:26 --> Model Class Initialized
INFO - 2018-03-28 15:32:26 --> Model Class Initialized
INFO - 2018-03-28 15:32:26 --> Model Class Initialized
INFO - 2018-03-28 15:32:26 --> Model Class Initialized
INFO - 2018-03-28 15:32:26 --> Model Class Initialized
INFO - 2018-03-28 15:32:26 --> Model Class Initialized
INFO - 2018-03-28 15:32:26 --> Model Class Initialized
INFO - 2018-03-28 15:32:26 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:32:26 --> Final output sent to browser
DEBUG - 2018-03-28 15:32:26 --> Total execution time: 0.4001
INFO - 2018-03-28 10:02:29 --> Config Class Initialized
INFO - 2018-03-28 10:02:29 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:02:29 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:02:29 --> Utf8 Class Initialized
INFO - 2018-03-28 10:02:29 --> URI Class Initialized
INFO - 2018-03-28 10:02:29 --> Router Class Initialized
INFO - 2018-03-28 10:02:29 --> Output Class Initialized
INFO - 2018-03-28 10:02:29 --> Security Class Initialized
DEBUG - 2018-03-28 10:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:02:29 --> Input Class Initialized
INFO - 2018-03-28 10:02:29 --> Language Class Initialized
INFO - 2018-03-28 10:02:29 --> Language Class Initialized
INFO - 2018-03-28 10:02:29 --> Config Class Initialized
INFO - 2018-03-28 10:02:29 --> Loader Class Initialized
INFO - 2018-03-28 15:32:29 --> Helper loaded: url_helper
INFO - 2018-03-28 15:32:29 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:32:29 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:32:29 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:32:29 --> Helper loaded: users_helper
INFO - 2018-03-28 15:32:29 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:32:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:32:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:32:29 --> Helper loaded: form_helper
INFO - 2018-03-28 15:32:29 --> Form Validation Class Initialized
INFO - 2018-03-28 15:32:29 --> Controller Class Initialized
INFO - 2018-03-28 15:32:29 --> Model Class Initialized
INFO - 2018-03-28 15:32:29 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:32:30 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:32:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:32:30 --> Model Class Initialized
INFO - 2018-03-28 15:32:30 --> Model Class Initialized
INFO - 2018-03-28 15:32:30 --> Model Class Initialized
INFO - 2018-03-28 15:32:30 --> Model Class Initialized
INFO - 2018-03-28 15:32:30 --> Model Class Initialized
INFO - 2018-03-28 15:32:30 --> Model Class Initialized
INFO - 2018-03-28 15:32:30 --> Model Class Initialized
INFO - 2018-03-28 15:32:30 --> Model Class Initialized
INFO - 2018-03-28 15:32:30 --> Model Class Initialized
INFO - 2018-03-28 15:32:30 --> Model Class Initialized
INFO - 2018-03-28 15:32:30 --> Model Class Initialized
INFO - 2018-03-28 15:32:30 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:32:30 --> Final output sent to browser
DEBUG - 2018-03-28 15:32:30 --> Total execution time: 0.7797
INFO - 2018-03-28 10:02:33 --> Config Class Initialized
INFO - 2018-03-28 10:02:33 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:02:33 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:02:33 --> Utf8 Class Initialized
INFO - 2018-03-28 10:02:33 --> URI Class Initialized
INFO - 2018-03-28 10:02:33 --> Router Class Initialized
INFO - 2018-03-28 10:02:33 --> Output Class Initialized
INFO - 2018-03-28 10:02:33 --> Security Class Initialized
DEBUG - 2018-03-28 10:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:02:33 --> Input Class Initialized
INFO - 2018-03-28 10:02:33 --> Language Class Initialized
INFO - 2018-03-28 10:02:33 --> Language Class Initialized
INFO - 2018-03-28 10:02:33 --> Config Class Initialized
INFO - 2018-03-28 10:02:33 --> Loader Class Initialized
INFO - 2018-03-28 15:32:33 --> Helper loaded: url_helper
INFO - 2018-03-28 15:32:33 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:32:33 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:32:33 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:32:33 --> Helper loaded: users_helper
INFO - 2018-03-28 15:32:33 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:32:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:32:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:32:33 --> Helper loaded: form_helper
INFO - 2018-03-28 15:32:33 --> Form Validation Class Initialized
INFO - 2018-03-28 15:32:33 --> Controller Class Initialized
INFO - 2018-03-28 15:32:33 --> Model Class Initialized
INFO - 2018-03-28 15:32:33 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:32:33 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:32:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:32:33 --> Model Class Initialized
INFO - 2018-03-28 15:32:33 --> Model Class Initialized
INFO - 2018-03-28 15:32:33 --> Model Class Initialized
INFO - 2018-03-28 15:32:33 --> Model Class Initialized
INFO - 2018-03-28 15:32:33 --> Model Class Initialized
INFO - 2018-03-28 15:32:33 --> Model Class Initialized
INFO - 2018-03-28 15:32:33 --> Model Class Initialized
INFO - 2018-03-28 15:32:33 --> Model Class Initialized
INFO - 2018-03-28 15:32:33 --> Model Class Initialized
INFO - 2018-03-28 15:32:33 --> Model Class Initialized
INFO - 2018-03-28 15:32:33 --> Model Class Initialized
INFO - 2018-03-28 15:32:33 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:32:33 --> Model Class Initialized
INFO - 2018-03-28 15:32:34 --> Final output sent to browser
DEBUG - 2018-03-28 15:32:34 --> Total execution time: 0.7824
INFO - 2018-03-28 10:02:37 --> Config Class Initialized
INFO - 2018-03-28 10:02:37 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:02:37 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:02:37 --> Utf8 Class Initialized
INFO - 2018-03-28 10:02:37 --> URI Class Initialized
INFO - 2018-03-28 10:02:37 --> Router Class Initialized
INFO - 2018-03-28 10:02:37 --> Config Class Initialized
INFO - 2018-03-28 10:02:37 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:02:37 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:02:37 --> Utf8 Class Initialized
INFO - 2018-03-28 10:02:37 --> URI Class Initialized
INFO - 2018-03-28 10:02:37 --> Router Class Initialized
INFO - 2018-03-28 10:02:37 --> Output Class Initialized
INFO - 2018-03-28 10:02:37 --> Output Class Initialized
INFO - 2018-03-28 10:02:37 --> Security Class Initialized
DEBUG - 2018-03-28 10:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:02:37 --> Input Class Initialized
INFO - 2018-03-28 10:02:37 --> Language Class Initialized
INFO - 2018-03-28 10:02:37 --> Language Class Initialized
INFO - 2018-03-28 10:02:37 --> Config Class Initialized
INFO - 2018-03-28 10:02:37 --> Loader Class Initialized
INFO - 2018-03-28 15:32:37 --> Helper loaded: url_helper
INFO - 2018-03-28 15:32:37 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:32:37 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:32:37 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:32:37 --> Helper loaded: users_helper
INFO - 2018-03-28 15:32:37 --> Database Driver Class Initialized
INFO - 2018-03-28 10:02:37 --> Security Class Initialized
DEBUG - 2018-03-28 15:32:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:32:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:32:37 --> Helper loaded: form_helper
INFO - 2018-03-28 15:32:37 --> Form Validation Class Initialized
INFO - 2018-03-28 15:32:37 --> Controller Class Initialized
INFO - 2018-03-28 15:32:37 --> Model Class Initialized
INFO - 2018-03-28 15:32:37 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:32:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:32:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:32:37 --> Model Class Initialized
INFO - 2018-03-28 15:32:37 --> Model Class Initialized
INFO - 2018-03-28 15:32:37 --> Model Class Initialized
INFO - 2018-03-28 15:32:37 --> Model Class Initialized
INFO - 2018-03-28 15:32:37 --> Model Class Initialized
INFO - 2018-03-28 15:32:37 --> Model Class Initialized
INFO - 2018-03-28 15:32:37 --> Model Class Initialized
INFO - 2018-03-28 15:32:37 --> Model Class Initialized
INFO - 2018-03-28 15:32:37 --> Model Class Initialized
INFO - 2018-03-28 15:32:37 --> Model Class Initialized
INFO - 2018-03-28 15:32:37 --> Model Class Initialized
INFO - 2018-03-28 15:32:37 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:32:38 --> Final output sent to browser
DEBUG - 2018-03-28 15:32:38 --> Total execution time: 0.2795
DEBUG - 2018-03-28 10:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:02:38 --> Input Class Initialized
INFO - 2018-03-28 10:02:38 --> Language Class Initialized
INFO - 2018-03-28 10:02:38 --> Language Class Initialized
INFO - 2018-03-28 10:02:38 --> Config Class Initialized
INFO - 2018-03-28 10:02:38 --> Loader Class Initialized
INFO - 2018-03-28 15:32:39 --> Helper loaded: url_helper
INFO - 2018-03-28 15:32:39 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:32:39 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:32:39 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:32:39 --> Helper loaded: users_helper
INFO - 2018-03-28 15:32:39 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:32:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:32:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:32:39 --> Helper loaded: form_helper
INFO - 2018-03-28 15:32:39 --> Form Validation Class Initialized
INFO - 2018-03-28 15:32:39 --> Controller Class Initialized
INFO - 2018-03-28 15:32:39 --> Model Class Initialized
INFO - 2018-03-28 15:32:39 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:32:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:32:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:32:39 --> Model Class Initialized
INFO - 2018-03-28 15:32:39 --> Model Class Initialized
INFO - 2018-03-28 15:32:39 --> Model Class Initialized
INFO - 2018-03-28 15:32:39 --> Model Class Initialized
INFO - 2018-03-28 15:32:39 --> Model Class Initialized
INFO - 2018-03-28 15:32:39 --> Model Class Initialized
INFO - 2018-03-28 15:32:39 --> Model Class Initialized
INFO - 2018-03-28 15:32:39 --> Model Class Initialized
INFO - 2018-03-28 15:32:39 --> Model Class Initialized
INFO - 2018-03-28 15:32:39 --> Model Class Initialized
INFO - 2018-03-28 15:32:39 --> Model Class Initialized
INFO - 2018-03-28 15:32:39 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:32:39 --> Final output sent to browser
DEBUG - 2018-03-28 15:32:39 --> Total execution time: 2.7108
INFO - 2018-03-28 10:02:41 --> Config Class Initialized
INFO - 2018-03-28 10:02:41 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:02:41 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:02:41 --> Utf8 Class Initialized
INFO - 2018-03-28 10:02:41 --> URI Class Initialized
INFO - 2018-03-28 10:02:41 --> Router Class Initialized
INFO - 2018-03-28 10:02:41 --> Output Class Initialized
INFO - 2018-03-28 10:02:41 --> Security Class Initialized
DEBUG - 2018-03-28 10:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:02:41 --> Input Class Initialized
INFO - 2018-03-28 10:02:41 --> Language Class Initialized
INFO - 2018-03-28 10:02:41 --> Config Class Initialized
INFO - 2018-03-28 10:02:41 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:02:41 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:02:41 --> Utf8 Class Initialized
INFO - 2018-03-28 10:02:41 --> Language Class Initialized
INFO - 2018-03-28 10:02:41 --> URI Class Initialized
INFO - 2018-03-28 10:02:41 --> Config Class Initialized
INFO - 2018-03-28 10:02:41 --> Loader Class Initialized
INFO - 2018-03-28 15:32:41 --> Helper loaded: url_helper
INFO - 2018-03-28 15:32:41 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:32:41 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:32:41 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:32:41 --> Helper loaded: users_helper
INFO - 2018-03-28 10:02:41 --> Router Class Initialized
INFO - 2018-03-28 10:02:41 --> Output Class Initialized
INFO - 2018-03-28 10:02:41 --> Security Class Initialized
INFO - 2018-03-28 15:32:41 --> Database Driver Class Initialized
DEBUG - 2018-03-28 10:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:02:41 --> Input Class Initialized
INFO - 2018-03-28 10:02:41 --> Language Class Initialized
DEBUG - 2018-03-28 15:32:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:32:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:32:41 --> Helper loaded: form_helper
INFO - 2018-03-28 15:32:41 --> Form Validation Class Initialized
INFO - 2018-03-28 15:32:41 --> Controller Class Initialized
INFO - 2018-03-28 15:32:41 --> Model Class Initialized
INFO - 2018-03-28 15:32:41 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:32:41 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:32:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:32:41 --> Model Class Initialized
INFO - 2018-03-28 15:32:41 --> Model Class Initialized
INFO - 2018-03-28 15:32:41 --> Model Class Initialized
INFO - 2018-03-28 15:32:41 --> Model Class Initialized
INFO - 2018-03-28 15:32:41 --> Model Class Initialized
INFO - 2018-03-28 15:32:41 --> Model Class Initialized
INFO - 2018-03-28 15:32:41 --> Model Class Initialized
INFO - 2018-03-28 10:02:41 --> Language Class Initialized
INFO - 2018-03-28 10:02:41 --> Config Class Initialized
INFO - 2018-03-28 10:02:41 --> Loader Class Initialized
INFO - 2018-03-28 15:32:41 --> Model Class Initialized
INFO - 2018-03-28 15:32:41 --> Model Class Initialized
INFO - 2018-03-28 15:32:41 --> Model Class Initialized
INFO - 2018-03-28 15:32:41 --> Model Class Initialized
INFO - 2018-03-28 15:32:41 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:32:41 --> Helper loaded: url_helper
INFO - 2018-03-28 15:32:41 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:32:41 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:32:41 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:32:41 --> Helper loaded: users_helper
INFO - 2018-03-28 15:32:41 --> Final output sent to browser
DEBUG - 2018-03-28 15:32:41 --> Total execution time: 0.3176
INFO - 2018-03-28 15:32:41 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:32:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:32:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:32:41 --> Helper loaded: form_helper
INFO - 2018-03-28 15:32:41 --> Form Validation Class Initialized
INFO - 2018-03-28 15:32:41 --> Controller Class Initialized
INFO - 2018-03-28 15:32:41 --> Model Class Initialized
INFO - 2018-03-28 15:32:41 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:32:41 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:32:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:32:41 --> Model Class Initialized
INFO - 2018-03-28 15:32:41 --> Model Class Initialized
INFO - 2018-03-28 15:32:41 --> Model Class Initialized
INFO - 2018-03-28 15:32:41 --> Model Class Initialized
INFO - 2018-03-28 15:32:41 --> Model Class Initialized
INFO - 2018-03-28 15:32:41 --> Model Class Initialized
INFO - 2018-03-28 15:32:41 --> Model Class Initialized
INFO - 2018-03-28 15:32:41 --> Model Class Initialized
INFO - 2018-03-28 15:32:41 --> Model Class Initialized
INFO - 2018-03-28 15:32:41 --> Model Class Initialized
INFO - 2018-03-28 15:32:41 --> Model Class Initialized
INFO - 2018-03-28 15:32:41 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:32:41 --> Final output sent to browser
DEBUG - 2018-03-28 15:32:41 --> Total execution time: 0.2070
INFO - 2018-03-28 10:02:42 --> Config Class Initialized
INFO - 2018-03-28 10:02:42 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:02:42 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:02:42 --> Utf8 Class Initialized
INFO - 2018-03-28 10:02:42 --> URI Class Initialized
INFO - 2018-03-28 10:02:42 --> Router Class Initialized
INFO - 2018-03-28 10:02:42 --> Output Class Initialized
INFO - 2018-03-28 10:02:42 --> Security Class Initialized
DEBUG - 2018-03-28 10:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:02:42 --> Input Class Initialized
INFO - 2018-03-28 10:02:42 --> Language Class Initialized
INFO - 2018-03-28 10:02:42 --> Language Class Initialized
INFO - 2018-03-28 10:02:42 --> Config Class Initialized
INFO - 2018-03-28 10:02:42 --> Loader Class Initialized
INFO - 2018-03-28 15:32:42 --> Helper loaded: url_helper
INFO - 2018-03-28 15:32:42 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:32:42 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:32:42 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:32:42 --> Helper loaded: users_helper
INFO - 2018-03-28 15:32:42 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:32:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:32:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:32:42 --> Helper loaded: form_helper
INFO - 2018-03-28 15:32:42 --> Form Validation Class Initialized
INFO - 2018-03-28 15:32:42 --> Controller Class Initialized
INFO - 2018-03-28 15:32:42 --> Model Class Initialized
INFO - 2018-03-28 15:32:42 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:32:42 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:32:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:32:42 --> Model Class Initialized
INFO - 2018-03-28 15:32:42 --> Model Class Initialized
INFO - 2018-03-28 15:32:42 --> Model Class Initialized
INFO - 2018-03-28 15:32:42 --> Model Class Initialized
INFO - 2018-03-28 15:32:42 --> Model Class Initialized
INFO - 2018-03-28 15:32:42 --> Model Class Initialized
INFO - 2018-03-28 15:32:42 --> Model Class Initialized
INFO - 2018-03-28 15:32:42 --> Model Class Initialized
INFO - 2018-03-28 15:32:42 --> Model Class Initialized
INFO - 2018-03-28 15:32:42 --> Model Class Initialized
INFO - 2018-03-28 15:32:42 --> Model Class Initialized
INFO - 2018-03-28 15:32:42 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:32:42 --> Model Class Initialized
INFO - 2018-03-28 15:32:42 --> Final output sent to browser
DEBUG - 2018-03-28 15:32:42 --> Total execution time: 0.1609
INFO - 2018-03-28 10:02:43 --> Config Class Initialized
INFO - 2018-03-28 10:02:43 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:02:43 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:02:43 --> Utf8 Class Initialized
INFO - 2018-03-28 10:02:43 --> URI Class Initialized
INFO - 2018-03-28 10:02:44 --> Router Class Initialized
INFO - 2018-03-28 10:02:44 --> Output Class Initialized
INFO - 2018-03-28 10:02:44 --> Security Class Initialized
DEBUG - 2018-03-28 10:02:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:02:44 --> Input Class Initialized
INFO - 2018-03-28 10:02:44 --> Language Class Initialized
INFO - 2018-03-28 10:02:45 --> Language Class Initialized
INFO - 2018-03-28 10:02:45 --> Config Class Initialized
INFO - 2018-03-28 10:02:45 --> Loader Class Initialized
INFO - 2018-03-28 15:32:45 --> Helper loaded: url_helper
INFO - 2018-03-28 15:32:45 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:32:45 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:32:45 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:32:45 --> Helper loaded: users_helper
INFO - 2018-03-28 15:32:45 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:32:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:32:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:32:45 --> Helper loaded: form_helper
INFO - 2018-03-28 15:32:45 --> Form Validation Class Initialized
INFO - 2018-03-28 15:32:45 --> Controller Class Initialized
INFO - 2018-03-28 15:32:45 --> Model Class Initialized
INFO - 2018-03-28 15:32:45 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:32:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:32:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:32:45 --> Model Class Initialized
INFO - 2018-03-28 15:32:45 --> Model Class Initialized
INFO - 2018-03-28 15:32:45 --> Model Class Initialized
INFO - 2018-03-28 15:32:45 --> Model Class Initialized
INFO - 2018-03-28 15:32:45 --> Model Class Initialized
INFO - 2018-03-28 15:32:45 --> Model Class Initialized
INFO - 2018-03-28 15:32:45 --> Model Class Initialized
INFO - 2018-03-28 15:32:45 --> Model Class Initialized
INFO - 2018-03-28 15:32:45 --> Model Class Initialized
INFO - 2018-03-28 15:32:45 --> Model Class Initialized
INFO - 2018-03-28 15:32:45 --> Model Class Initialized
INFO - 2018-03-28 15:32:45 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:32:45 --> Model Class Initialized
INFO - 2018-03-28 15:32:45 --> Final output sent to browser
DEBUG - 2018-03-28 15:32:45 --> Total execution time: 2.1669
INFO - 2018-03-28 10:02:46 --> Config Class Initialized
INFO - 2018-03-28 10:02:46 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:02:46 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:02:46 --> Utf8 Class Initialized
INFO - 2018-03-28 10:02:46 --> URI Class Initialized
INFO - 2018-03-28 10:02:46 --> Router Class Initialized
INFO - 2018-03-28 10:02:46 --> Output Class Initialized
INFO - 2018-03-28 10:02:46 --> Security Class Initialized
DEBUG - 2018-03-28 10:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:02:46 --> Input Class Initialized
INFO - 2018-03-28 10:02:46 --> Language Class Initialized
INFO - 2018-03-28 10:02:46 --> Language Class Initialized
INFO - 2018-03-28 10:02:46 --> Config Class Initialized
INFO - 2018-03-28 10:02:46 --> Loader Class Initialized
INFO - 2018-03-28 15:32:46 --> Helper loaded: url_helper
INFO - 2018-03-28 15:32:46 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:32:46 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:32:46 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:32:46 --> Helper loaded: users_helper
INFO - 2018-03-28 15:32:46 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:32:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:32:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:32:46 --> Helper loaded: form_helper
INFO - 2018-03-28 15:32:46 --> Form Validation Class Initialized
INFO - 2018-03-28 15:32:46 --> Controller Class Initialized
INFO - 2018-03-28 15:32:46 --> Model Class Initialized
INFO - 2018-03-28 15:32:46 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:32:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:32:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:32:46 --> Model Class Initialized
INFO - 2018-03-28 15:32:46 --> Model Class Initialized
INFO - 2018-03-28 15:32:46 --> Model Class Initialized
INFO - 2018-03-28 15:32:46 --> Model Class Initialized
INFO - 2018-03-28 15:32:46 --> Model Class Initialized
INFO - 2018-03-28 15:32:46 --> Model Class Initialized
INFO - 2018-03-28 15:32:46 --> Model Class Initialized
INFO - 2018-03-28 15:32:46 --> Model Class Initialized
INFO - 2018-03-28 15:32:46 --> Model Class Initialized
INFO - 2018-03-28 15:32:46 --> Model Class Initialized
INFO - 2018-03-28 15:32:46 --> Model Class Initialized
INFO - 2018-03-28 15:32:46 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:32:46 --> Model Class Initialized
INFO - 2018-03-28 15:32:46 --> Final output sent to browser
DEBUG - 2018-03-28 15:32:46 --> Total execution time: 0.3501
INFO - 2018-03-28 10:02:49 --> Config Class Initialized
INFO - 2018-03-28 10:02:49 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:02:50 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:02:50 --> Utf8 Class Initialized
INFO - 2018-03-28 10:02:50 --> URI Class Initialized
INFO - 2018-03-28 10:02:50 --> Router Class Initialized
INFO - 2018-03-28 10:02:50 --> Output Class Initialized
INFO - 2018-03-28 10:02:50 --> Config Class Initialized
INFO - 2018-03-28 10:02:50 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:02:50 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:02:50 --> Utf8 Class Initialized
INFO - 2018-03-28 10:02:50 --> URI Class Initialized
INFO - 2018-03-28 10:02:50 --> Router Class Initialized
INFO - 2018-03-28 10:02:50 --> Output Class Initialized
INFO - 2018-03-28 10:02:50 --> Security Class Initialized
DEBUG - 2018-03-28 10:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:02:50 --> Input Class Initialized
INFO - 2018-03-28 10:02:50 --> Language Class Initialized
INFO - 2018-03-28 10:02:50 --> Security Class Initialized
DEBUG - 2018-03-28 10:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:02:51 --> Input Class Initialized
INFO - 2018-03-28 10:02:51 --> Language Class Initialized
INFO - 2018-03-28 10:02:51 --> Language Class Initialized
INFO - 2018-03-28 10:02:51 --> Config Class Initialized
INFO - 2018-03-28 10:02:51 --> Loader Class Initialized
INFO - 2018-03-28 15:32:51 --> Helper loaded: url_helper
INFO - 2018-03-28 15:32:51 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:32:51 --> Helper loaded: settings_helper
INFO - 2018-03-28 10:02:52 --> Language Class Initialized
INFO - 2018-03-28 10:02:52 --> Config Class Initialized
INFO - 2018-03-28 15:32:52 --> Helper loaded: permission_helper
INFO - 2018-03-28 10:02:52 --> Loader Class Initialized
INFO - 2018-03-28 15:32:52 --> Helper loaded: users_helper
INFO - 2018-03-28 15:32:52 --> Helper loaded: url_helper
INFO - 2018-03-28 15:32:52 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:32:52 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:32:52 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:32:52 --> Helper loaded: users_helper
INFO - 2018-03-28 15:32:52 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:32:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:32:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:32:52 --> Helper loaded: form_helper
INFO - 2018-03-28 15:32:52 --> Form Validation Class Initialized
INFO - 2018-03-28 15:32:52 --> Controller Class Initialized
INFO - 2018-03-28 15:32:52 --> Model Class Initialized
INFO - 2018-03-28 15:32:53 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:32:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:32:53 --> Database Driver Class Initialized
INFO - 2018-03-28 15:32:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:32:53 --> Model Class Initialized
INFO - 2018-03-28 15:32:53 --> Model Class Initialized
DEBUG - 2018-03-28 15:32:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:32:53 --> Model Class Initialized
INFO - 2018-03-28 15:32:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:32:53 --> Model Class Initialized
INFO - 2018-03-28 15:32:53 --> Model Class Initialized
INFO - 2018-03-28 15:32:53 --> Model Class Initialized
INFO - 2018-03-28 15:32:53 --> Model Class Initialized
INFO - 2018-03-28 15:32:53 --> Model Class Initialized
INFO - 2018-03-28 15:32:53 --> Model Class Initialized
INFO - 2018-03-28 15:32:53 --> Model Class Initialized
INFO - 2018-03-28 15:32:54 --> Model Class Initialized
INFO - 2018-03-28 15:32:54 --> Helper loaded: form_helper
INFO - 2018-03-28 15:32:54 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:32:54 --> Form Validation Class Initialized
INFO - 2018-03-28 15:32:54 --> Controller Class Initialized
INFO - 2018-03-28 15:32:54 --> Model Class Initialized
INFO - 2018-03-28 15:32:54 --> Final output sent to browser
DEBUG - 2018-03-28 15:32:54 --> Total execution time: 4.4609
INFO - 2018-03-28 15:32:54 --> Model Class Initialized
INFO - 2018-03-28 15:32:54 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:32:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:32:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:32:55 --> Model Class Initialized
INFO - 2018-03-28 15:32:55 --> Model Class Initialized
INFO - 2018-03-28 15:32:55 --> Model Class Initialized
INFO - 2018-03-28 15:32:55 --> Model Class Initialized
INFO - 2018-03-28 15:32:55 --> Model Class Initialized
INFO - 2018-03-28 15:32:55 --> Model Class Initialized
INFO - 2018-03-28 15:32:55 --> Model Class Initialized
INFO - 2018-03-28 15:32:55 --> Model Class Initialized
INFO - 2018-03-28 15:32:55 --> Model Class Initialized
INFO - 2018-03-28 15:32:55 --> Model Class Initialized
INFO - 2018-03-28 15:32:55 --> Model Class Initialized
INFO - 2018-03-28 15:32:55 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:32:55 --> Model Class Initialized
INFO - 2018-03-28 15:32:55 --> Final output sent to browser
DEBUG - 2018-03-28 15:32:56 --> Total execution time: 5.1875
INFO - 2018-03-28 10:02:59 --> Config Class Initialized
INFO - 2018-03-28 10:02:59 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:02:59 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:02:59 --> Utf8 Class Initialized
INFO - 2018-03-28 10:02:59 --> URI Class Initialized
INFO - 2018-03-28 10:02:59 --> Router Class Initialized
INFO - 2018-03-28 10:02:59 --> Output Class Initialized
INFO - 2018-03-28 10:02:59 --> Security Class Initialized
DEBUG - 2018-03-28 10:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:02:59 --> Input Class Initialized
INFO - 2018-03-28 10:02:59 --> Language Class Initialized
INFO - 2018-03-28 10:02:59 --> Language Class Initialized
INFO - 2018-03-28 10:02:59 --> Config Class Initialized
INFO - 2018-03-28 10:02:59 --> Loader Class Initialized
INFO - 2018-03-28 15:32:59 --> Helper loaded: url_helper
INFO - 2018-03-28 15:32:59 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:32:59 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:32:59 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:32:59 --> Helper loaded: users_helper
INFO - 2018-03-28 15:32:59 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:32:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:32:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:32:59 --> Helper loaded: form_helper
INFO - 2018-03-28 15:32:59 --> Form Validation Class Initialized
INFO - 2018-03-28 15:32:59 --> Controller Class Initialized
INFO - 2018-03-28 15:32:59 --> Model Class Initialized
INFO - 2018-03-28 15:32:59 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:32:59 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:32:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:32:59 --> Model Class Initialized
INFO - 2018-03-28 15:32:59 --> Model Class Initialized
INFO - 2018-03-28 15:32:59 --> Model Class Initialized
INFO - 2018-03-28 15:32:59 --> Model Class Initialized
INFO - 2018-03-28 15:32:59 --> Model Class Initialized
INFO - 2018-03-28 15:32:59 --> Model Class Initialized
INFO - 2018-03-28 15:32:59 --> Model Class Initialized
INFO - 2018-03-28 15:32:59 --> Model Class Initialized
INFO - 2018-03-28 15:32:59 --> Model Class Initialized
INFO - 2018-03-28 15:32:59 --> Model Class Initialized
INFO - 2018-03-28 15:32:59 --> Model Class Initialized
INFO - 2018-03-28 15:32:59 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:32:59 --> Final output sent to browser
DEBUG - 2018-03-28 15:32:59 --> Total execution time: 0.1226
INFO - 2018-03-28 10:03:03 --> Config Class Initialized
INFO - 2018-03-28 10:03:03 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:03:03 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:03:03 --> Utf8 Class Initialized
INFO - 2018-03-28 10:03:04 --> URI Class Initialized
INFO - 2018-03-28 10:03:04 --> Router Class Initialized
INFO - 2018-03-28 10:03:04 --> Output Class Initialized
INFO - 2018-03-28 10:03:04 --> Security Class Initialized
DEBUG - 2018-03-28 10:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:03:04 --> Input Class Initialized
INFO - 2018-03-28 10:03:04 --> Language Class Initialized
INFO - 2018-03-28 10:03:04 --> Language Class Initialized
INFO - 2018-03-28 10:03:04 --> Config Class Initialized
INFO - 2018-03-28 10:03:04 --> Loader Class Initialized
INFO - 2018-03-28 15:33:04 --> Helper loaded: url_helper
INFO - 2018-03-28 15:33:04 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:33:04 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:33:04 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:33:04 --> Helper loaded: users_helper
INFO - 2018-03-28 15:33:04 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:33:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:33:04 --> Helper loaded: form_helper
INFO - 2018-03-28 15:33:04 --> Form Validation Class Initialized
INFO - 2018-03-28 15:33:04 --> Controller Class Initialized
INFO - 2018-03-28 15:33:04 --> Model Class Initialized
INFO - 2018-03-28 15:33:04 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:33:04 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:33:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:33:04 --> Model Class Initialized
INFO - 2018-03-28 15:33:04 --> Model Class Initialized
INFO - 2018-03-28 15:33:04 --> Model Class Initialized
INFO - 2018-03-28 15:33:04 --> Model Class Initialized
INFO - 2018-03-28 15:33:04 --> Model Class Initialized
INFO - 2018-03-28 15:33:04 --> Model Class Initialized
INFO - 2018-03-28 15:33:04 --> Model Class Initialized
INFO - 2018-03-28 15:33:04 --> Model Class Initialized
INFO - 2018-03-28 15:33:04 --> Model Class Initialized
INFO - 2018-03-28 15:33:04 --> Model Class Initialized
INFO - 2018-03-28 15:33:04 --> Model Class Initialized
INFO - 2018-03-28 15:33:04 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:33:04 --> Final output sent to browser
DEBUG - 2018-03-28 15:33:04 --> Total execution time: 0.1166
INFO - 2018-03-28 10:03:09 --> Config Class Initialized
INFO - 2018-03-28 10:03:09 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:03:09 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:03:09 --> Utf8 Class Initialized
INFO - 2018-03-28 10:03:09 --> URI Class Initialized
INFO - 2018-03-28 10:03:09 --> Router Class Initialized
INFO - 2018-03-28 10:03:09 --> Output Class Initialized
INFO - 2018-03-28 10:03:09 --> Security Class Initialized
DEBUG - 2018-03-28 10:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:03:09 --> Input Class Initialized
INFO - 2018-03-28 10:03:09 --> Language Class Initialized
INFO - 2018-03-28 10:03:09 --> Language Class Initialized
INFO - 2018-03-28 10:03:09 --> Config Class Initialized
INFO - 2018-03-28 10:03:09 --> Loader Class Initialized
INFO - 2018-03-28 15:33:09 --> Helper loaded: url_helper
INFO - 2018-03-28 15:33:09 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:33:09 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:33:09 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:33:09 --> Helper loaded: users_helper
INFO - 2018-03-28 15:33:09 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:33:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:33:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:33:09 --> Helper loaded: form_helper
INFO - 2018-03-28 15:33:09 --> Form Validation Class Initialized
INFO - 2018-03-28 15:33:09 --> Controller Class Initialized
INFO - 2018-03-28 15:33:09 --> Model Class Initialized
INFO - 2018-03-28 15:33:09 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:33:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:33:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:33:09 --> Model Class Initialized
INFO - 2018-03-28 15:33:09 --> Model Class Initialized
INFO - 2018-03-28 15:33:09 --> Model Class Initialized
INFO - 2018-03-28 15:33:09 --> Model Class Initialized
INFO - 2018-03-28 15:33:09 --> Model Class Initialized
INFO - 2018-03-28 15:33:09 --> Model Class Initialized
INFO - 2018-03-28 15:33:09 --> Model Class Initialized
INFO - 2018-03-28 15:33:09 --> Model Class Initialized
INFO - 2018-03-28 15:33:09 --> Model Class Initialized
INFO - 2018-03-28 15:33:09 --> Model Class Initialized
INFO - 2018-03-28 15:33:09 --> Model Class Initialized
INFO - 2018-03-28 15:33:09 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:33:09 --> Final output sent to browser
DEBUG - 2018-03-28 15:33:09 --> Total execution time: 0.0990
INFO - 2018-03-28 10:03:10 --> Config Class Initialized
INFO - 2018-03-28 10:03:10 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:03:10 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:03:10 --> Utf8 Class Initialized
INFO - 2018-03-28 10:03:10 --> URI Class Initialized
INFO - 2018-03-28 10:03:10 --> Router Class Initialized
INFO - 2018-03-28 10:03:10 --> Output Class Initialized
INFO - 2018-03-28 10:03:10 --> Security Class Initialized
DEBUG - 2018-03-28 10:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:03:10 --> Input Class Initialized
INFO - 2018-03-28 10:03:10 --> Language Class Initialized
INFO - 2018-03-28 10:03:10 --> Language Class Initialized
INFO - 2018-03-28 10:03:10 --> Config Class Initialized
INFO - 2018-03-28 10:03:10 --> Loader Class Initialized
INFO - 2018-03-28 15:33:10 --> Helper loaded: url_helper
INFO - 2018-03-28 15:33:10 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:33:10 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:33:10 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:33:10 --> Helper loaded: users_helper
INFO - 2018-03-28 15:33:10 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:33:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:33:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:33:10 --> Helper loaded: form_helper
INFO - 2018-03-28 15:33:10 --> Form Validation Class Initialized
INFO - 2018-03-28 15:33:10 --> Controller Class Initialized
INFO - 2018-03-28 15:33:10 --> Model Class Initialized
INFO - 2018-03-28 15:33:10 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:33:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:33:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:33:10 --> Model Class Initialized
INFO - 2018-03-28 15:33:10 --> Model Class Initialized
INFO - 2018-03-28 15:33:10 --> Model Class Initialized
INFO - 2018-03-28 15:33:10 --> Model Class Initialized
INFO - 2018-03-28 15:33:10 --> Model Class Initialized
INFO - 2018-03-28 15:33:10 --> Model Class Initialized
INFO - 2018-03-28 15:33:10 --> Model Class Initialized
INFO - 2018-03-28 15:33:10 --> Model Class Initialized
INFO - 2018-03-28 15:33:10 --> Model Class Initialized
INFO - 2018-03-28 15:33:10 --> Model Class Initialized
INFO - 2018-03-28 15:33:10 --> Model Class Initialized
INFO - 2018-03-28 15:33:10 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:33:10 --> Model Class Initialized
INFO - 2018-03-28 15:33:11 --> Final output sent to browser
DEBUG - 2018-03-28 15:33:11 --> Total execution time: 1.3069
INFO - 2018-03-28 10:03:13 --> Config Class Initialized
INFO - 2018-03-28 10:03:13 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:03:13 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:03:13 --> Utf8 Class Initialized
INFO - 2018-03-28 10:03:13 --> URI Class Initialized
INFO - 2018-03-28 10:03:13 --> Router Class Initialized
INFO - 2018-03-28 10:03:13 --> Output Class Initialized
INFO - 2018-03-28 10:03:13 --> Security Class Initialized
DEBUG - 2018-03-28 10:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:03:13 --> Input Class Initialized
INFO - 2018-03-28 10:03:13 --> Language Class Initialized
INFO - 2018-03-28 10:03:13 --> Language Class Initialized
INFO - 2018-03-28 10:03:13 --> Config Class Initialized
INFO - 2018-03-28 10:03:13 --> Loader Class Initialized
INFO - 2018-03-28 15:33:13 --> Helper loaded: url_helper
INFO - 2018-03-28 15:33:13 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:33:13 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:33:13 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:33:13 --> Helper loaded: users_helper
INFO - 2018-03-28 15:33:13 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:33:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:33:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:33:13 --> Helper loaded: form_helper
INFO - 2018-03-28 15:33:13 --> Form Validation Class Initialized
INFO - 2018-03-28 15:33:13 --> Controller Class Initialized
INFO - 2018-03-28 15:33:13 --> Model Class Initialized
INFO - 2018-03-28 15:33:13 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:33:13 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:33:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:33:13 --> Model Class Initialized
INFO - 2018-03-28 15:33:13 --> Model Class Initialized
INFO - 2018-03-28 15:33:13 --> Model Class Initialized
INFO - 2018-03-28 15:33:13 --> Model Class Initialized
INFO - 2018-03-28 15:33:13 --> Model Class Initialized
INFO - 2018-03-28 15:33:13 --> Model Class Initialized
INFO - 2018-03-28 15:33:13 --> Model Class Initialized
INFO - 2018-03-28 15:33:13 --> Model Class Initialized
INFO - 2018-03-28 15:33:13 --> Model Class Initialized
INFO - 2018-03-28 15:33:13 --> Model Class Initialized
INFO - 2018-03-28 15:33:13 --> Model Class Initialized
INFO - 2018-03-28 15:33:13 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:33:13 --> Model Class Initialized
INFO - 2018-03-28 15:33:13 --> Final output sent to browser
DEBUG - 2018-03-28 15:33:13 --> Total execution time: 0.1165
INFO - 2018-03-28 10:03:19 --> Config Class Initialized
INFO - 2018-03-28 10:03:19 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:03:19 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:03:19 --> Utf8 Class Initialized
INFO - 2018-03-28 10:03:19 --> URI Class Initialized
INFO - 2018-03-28 10:03:19 --> Router Class Initialized
INFO - 2018-03-28 10:03:19 --> Output Class Initialized
INFO - 2018-03-28 10:03:19 --> Security Class Initialized
DEBUG - 2018-03-28 10:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:03:19 --> Input Class Initialized
INFO - 2018-03-28 10:03:19 --> Language Class Initialized
INFO - 2018-03-28 10:03:19 --> Language Class Initialized
INFO - 2018-03-28 10:03:19 --> Config Class Initialized
INFO - 2018-03-28 10:03:19 --> Loader Class Initialized
INFO - 2018-03-28 15:33:19 --> Helper loaded: url_helper
INFO - 2018-03-28 15:33:19 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:33:19 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:33:19 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:33:19 --> Helper loaded: users_helper
INFO - 2018-03-28 15:33:19 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:33:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:33:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:33:19 --> Helper loaded: form_helper
INFO - 2018-03-28 15:33:19 --> Form Validation Class Initialized
INFO - 2018-03-28 15:33:19 --> Controller Class Initialized
INFO - 2018-03-28 15:33:19 --> Model Class Initialized
INFO - 2018-03-28 15:33:19 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:33:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:33:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:33:19 --> Model Class Initialized
INFO - 2018-03-28 15:33:19 --> Model Class Initialized
INFO - 2018-03-28 15:33:19 --> Model Class Initialized
INFO - 2018-03-28 15:33:19 --> Model Class Initialized
INFO - 2018-03-28 15:33:19 --> Model Class Initialized
INFO - 2018-03-28 15:33:19 --> Model Class Initialized
INFO - 2018-03-28 15:33:19 --> Model Class Initialized
INFO - 2018-03-28 15:33:19 --> Model Class Initialized
INFO - 2018-03-28 15:33:19 --> Model Class Initialized
INFO - 2018-03-28 15:33:19 --> Model Class Initialized
INFO - 2018-03-28 15:33:19 --> Model Class Initialized
INFO - 2018-03-28 15:33:19 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:33:19 --> Final output sent to browser
DEBUG - 2018-03-28 15:33:19 --> Total execution time: 0.3098
INFO - 2018-03-28 10:03:27 --> Config Class Initialized
INFO - 2018-03-28 10:03:27 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:03:27 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:03:27 --> Utf8 Class Initialized
INFO - 2018-03-28 10:03:27 --> URI Class Initialized
INFO - 2018-03-28 10:03:27 --> Router Class Initialized
INFO - 2018-03-28 10:03:27 --> Output Class Initialized
INFO - 2018-03-28 10:03:27 --> Security Class Initialized
DEBUG - 2018-03-28 10:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:03:27 --> Input Class Initialized
INFO - 2018-03-28 10:03:27 --> Language Class Initialized
INFO - 2018-03-28 10:03:27 --> Language Class Initialized
INFO - 2018-03-28 10:03:27 --> Config Class Initialized
INFO - 2018-03-28 10:03:27 --> Loader Class Initialized
INFO - 2018-03-28 15:33:27 --> Helper loaded: url_helper
INFO - 2018-03-28 15:33:27 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:33:27 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:33:27 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:33:27 --> Helper loaded: users_helper
INFO - 2018-03-28 15:33:28 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:33:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:33:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:33:28 --> Helper loaded: form_helper
INFO - 2018-03-28 15:33:28 --> Form Validation Class Initialized
INFO - 2018-03-28 15:33:28 --> Controller Class Initialized
INFO - 2018-03-28 15:33:28 --> Model Class Initialized
INFO - 2018-03-28 15:33:28 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:33:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:33:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:33:28 --> Model Class Initialized
INFO - 2018-03-28 15:33:28 --> Model Class Initialized
INFO - 2018-03-28 15:33:28 --> Model Class Initialized
INFO - 2018-03-28 15:33:28 --> Model Class Initialized
INFO - 2018-03-28 15:33:28 --> Model Class Initialized
INFO - 2018-03-28 15:33:28 --> Model Class Initialized
INFO - 2018-03-28 15:33:28 --> Model Class Initialized
INFO - 2018-03-28 15:33:28 --> Model Class Initialized
INFO - 2018-03-28 15:33:28 --> Model Class Initialized
INFO - 2018-03-28 15:33:28 --> Model Class Initialized
INFO - 2018-03-28 15:33:28 --> Model Class Initialized
INFO - 2018-03-28 15:33:28 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:33:28 --> Model Class Initialized
INFO - 2018-03-28 15:33:28 --> Final output sent to browser
DEBUG - 2018-03-28 15:33:28 --> Total execution time: 0.8384
INFO - 2018-03-28 10:03:30 --> Config Class Initialized
INFO - 2018-03-28 10:03:30 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:03:30 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:03:30 --> Utf8 Class Initialized
INFO - 2018-03-28 10:03:30 --> URI Class Initialized
INFO - 2018-03-28 10:03:30 --> Router Class Initialized
INFO - 2018-03-28 10:03:30 --> Output Class Initialized
INFO - 2018-03-28 10:03:30 --> Security Class Initialized
DEBUG - 2018-03-28 10:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:03:30 --> Input Class Initialized
INFO - 2018-03-28 10:03:30 --> Language Class Initialized
INFO - 2018-03-28 10:03:30 --> Language Class Initialized
INFO - 2018-03-28 10:03:30 --> Config Class Initialized
INFO - 2018-03-28 10:03:30 --> Loader Class Initialized
INFO - 2018-03-28 15:33:30 --> Helper loaded: url_helper
INFO - 2018-03-28 15:33:30 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:33:30 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:33:30 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:33:30 --> Helper loaded: users_helper
INFO - 2018-03-28 15:33:30 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:33:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:33:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:33:30 --> Helper loaded: form_helper
INFO - 2018-03-28 15:33:30 --> Form Validation Class Initialized
INFO - 2018-03-28 15:33:30 --> Controller Class Initialized
INFO - 2018-03-28 15:33:30 --> Model Class Initialized
INFO - 2018-03-28 15:33:30 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:33:30 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:33:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:33:30 --> Model Class Initialized
INFO - 2018-03-28 15:33:31 --> Model Class Initialized
INFO - 2018-03-28 15:33:31 --> Model Class Initialized
INFO - 2018-03-28 15:33:31 --> Model Class Initialized
INFO - 2018-03-28 15:33:31 --> Model Class Initialized
INFO - 2018-03-28 15:33:31 --> Model Class Initialized
INFO - 2018-03-28 15:33:31 --> Model Class Initialized
INFO - 2018-03-28 15:33:31 --> Model Class Initialized
INFO - 2018-03-28 15:33:31 --> Model Class Initialized
INFO - 2018-03-28 15:33:31 --> Model Class Initialized
INFO - 2018-03-28 15:33:31 --> Model Class Initialized
INFO - 2018-03-28 15:33:31 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:33:31 --> Final output sent to browser
DEBUG - 2018-03-28 15:33:31 --> Total execution time: 0.5663
INFO - 2018-03-28 10:03:34 --> Config Class Initialized
INFO - 2018-03-28 10:03:34 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:03:34 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:03:34 --> Utf8 Class Initialized
INFO - 2018-03-28 10:03:34 --> URI Class Initialized
INFO - 2018-03-28 10:03:34 --> Router Class Initialized
INFO - 2018-03-28 10:03:34 --> Output Class Initialized
INFO - 2018-03-28 10:03:34 --> Security Class Initialized
DEBUG - 2018-03-28 10:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:03:34 --> Input Class Initialized
INFO - 2018-03-28 10:03:34 --> Language Class Initialized
INFO - 2018-03-28 10:03:34 --> Language Class Initialized
INFO - 2018-03-28 10:03:34 --> Config Class Initialized
INFO - 2018-03-28 10:03:34 --> Loader Class Initialized
INFO - 2018-03-28 15:33:34 --> Helper loaded: url_helper
INFO - 2018-03-28 15:33:34 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:33:34 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:33:34 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:33:34 --> Helper loaded: users_helper
INFO - 2018-03-28 15:33:34 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:33:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:33:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:33:34 --> Helper loaded: form_helper
INFO - 2018-03-28 15:33:34 --> Form Validation Class Initialized
INFO - 2018-03-28 15:33:34 --> Controller Class Initialized
INFO - 2018-03-28 15:33:34 --> Model Class Initialized
INFO - 2018-03-28 15:33:34 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:33:34 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:33:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:33:34 --> Model Class Initialized
INFO - 2018-03-28 15:33:34 --> Model Class Initialized
INFO - 2018-03-28 15:33:34 --> Model Class Initialized
INFO - 2018-03-28 15:33:34 --> Model Class Initialized
INFO - 2018-03-28 15:33:34 --> Model Class Initialized
INFO - 2018-03-28 15:33:34 --> Model Class Initialized
INFO - 2018-03-28 15:33:34 --> Model Class Initialized
INFO - 2018-03-28 15:33:34 --> Model Class Initialized
INFO - 2018-03-28 15:33:34 --> Model Class Initialized
INFO - 2018-03-28 15:33:34 --> Model Class Initialized
INFO - 2018-03-28 15:33:34 --> Model Class Initialized
INFO - 2018-03-28 15:33:34 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:33:34 --> Final output sent to browser
DEBUG - 2018-03-28 15:33:34 --> Total execution time: 0.5164
INFO - 2018-03-28 10:03:36 --> Config Class Initialized
INFO - 2018-03-28 10:03:36 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:03:36 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:03:36 --> Utf8 Class Initialized
INFO - 2018-03-28 10:03:36 --> URI Class Initialized
INFO - 2018-03-28 10:03:36 --> Router Class Initialized
INFO - 2018-03-28 10:03:36 --> Output Class Initialized
INFO - 2018-03-28 10:03:36 --> Security Class Initialized
DEBUG - 2018-03-28 10:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:03:36 --> Input Class Initialized
INFO - 2018-03-28 10:03:36 --> Language Class Initialized
INFO - 2018-03-28 10:03:36 --> Language Class Initialized
INFO - 2018-03-28 10:03:36 --> Config Class Initialized
INFO - 2018-03-28 10:03:36 --> Loader Class Initialized
INFO - 2018-03-28 15:33:36 --> Helper loaded: url_helper
INFO - 2018-03-28 15:33:36 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:33:36 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:33:36 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:33:36 --> Helper loaded: users_helper
INFO - 2018-03-28 15:33:36 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:33:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:33:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:33:37 --> Helper loaded: form_helper
INFO - 2018-03-28 15:33:37 --> Form Validation Class Initialized
INFO - 2018-03-28 15:33:37 --> Controller Class Initialized
INFO - 2018-03-28 15:33:37 --> Model Class Initialized
INFO - 2018-03-28 15:33:37 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:33:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:33:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:33:37 --> Model Class Initialized
INFO - 2018-03-28 15:33:37 --> Model Class Initialized
INFO - 2018-03-28 15:33:37 --> Model Class Initialized
INFO - 2018-03-28 15:33:37 --> Model Class Initialized
INFO - 2018-03-28 15:33:37 --> Model Class Initialized
INFO - 2018-03-28 15:33:37 --> Model Class Initialized
INFO - 2018-03-28 15:33:37 --> Model Class Initialized
INFO - 2018-03-28 15:33:37 --> Model Class Initialized
INFO - 2018-03-28 15:33:37 --> Model Class Initialized
INFO - 2018-03-28 15:33:37 --> Model Class Initialized
INFO - 2018-03-28 15:33:37 --> Model Class Initialized
INFO - 2018-03-28 15:33:37 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:33:37 --> Model Class Initialized
INFO - 2018-03-28 15:33:37 --> Final output sent to browser
DEBUG - 2018-03-28 15:33:37 --> Total execution time: 0.9452
INFO - 2018-03-28 10:03:48 --> Config Class Initialized
INFO - 2018-03-28 10:03:48 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:03:48 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:03:48 --> Utf8 Class Initialized
INFO - 2018-03-28 10:03:49 --> URI Class Initialized
INFO - 2018-03-28 10:03:49 --> Router Class Initialized
INFO - 2018-03-28 10:03:49 --> Output Class Initialized
INFO - 2018-03-28 10:03:49 --> Security Class Initialized
DEBUG - 2018-03-28 10:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:03:49 --> Input Class Initialized
INFO - 2018-03-28 10:03:49 --> Language Class Initialized
INFO - 2018-03-28 10:03:49 --> Language Class Initialized
INFO - 2018-03-28 10:03:49 --> Config Class Initialized
INFO - 2018-03-28 10:03:49 --> Loader Class Initialized
INFO - 2018-03-28 15:33:49 --> Helper loaded: url_helper
INFO - 2018-03-28 15:33:49 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:33:49 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:33:49 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:33:50 --> Helper loaded: users_helper
INFO - 2018-03-28 15:33:50 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:33:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:33:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:33:50 --> Helper loaded: form_helper
INFO - 2018-03-28 15:33:50 --> Form Validation Class Initialized
INFO - 2018-03-28 15:33:50 --> Controller Class Initialized
INFO - 2018-03-28 15:33:50 --> Model Class Initialized
INFO - 2018-03-28 15:33:50 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:33:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:33:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:33:50 --> Model Class Initialized
INFO - 2018-03-28 15:33:50 --> Model Class Initialized
INFO - 2018-03-28 15:33:50 --> Model Class Initialized
INFO - 2018-03-28 15:33:50 --> Model Class Initialized
INFO - 2018-03-28 15:33:50 --> Model Class Initialized
INFO - 2018-03-28 15:33:50 --> Model Class Initialized
INFO - 2018-03-28 15:33:50 --> Model Class Initialized
INFO - 2018-03-28 15:33:50 --> Model Class Initialized
INFO - 2018-03-28 15:33:50 --> Model Class Initialized
INFO - 2018-03-28 15:33:50 --> Model Class Initialized
INFO - 2018-03-28 15:33:50 --> Model Class Initialized
INFO - 2018-03-28 15:33:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:33:50 --> Model Class Initialized
INFO - 2018-03-28 15:33:50 --> Final output sent to browser
DEBUG - 2018-03-28 15:33:50 --> Total execution time: 2.1416
INFO - 2018-03-28 10:03:51 --> Config Class Initialized
INFO - 2018-03-28 10:03:51 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:03:51 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:03:51 --> Utf8 Class Initialized
INFO - 2018-03-28 10:03:51 --> URI Class Initialized
INFO - 2018-03-28 10:03:51 --> Router Class Initialized
INFO - 2018-03-28 10:03:51 --> Output Class Initialized
INFO - 2018-03-28 10:03:51 --> Security Class Initialized
DEBUG - 2018-03-28 10:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:03:51 --> Input Class Initialized
INFO - 2018-03-28 10:03:51 --> Language Class Initialized
INFO - 2018-03-28 10:03:51 --> Language Class Initialized
INFO - 2018-03-28 10:03:51 --> Config Class Initialized
INFO - 2018-03-28 10:03:51 --> Loader Class Initialized
INFO - 2018-03-28 15:33:51 --> Helper loaded: url_helper
INFO - 2018-03-28 15:33:51 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:33:51 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:33:51 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:33:51 --> Helper loaded: users_helper
INFO - 2018-03-28 15:33:51 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:33:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:33:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:33:51 --> Helper loaded: form_helper
INFO - 2018-03-28 15:33:51 --> Form Validation Class Initialized
INFO - 2018-03-28 15:33:51 --> Controller Class Initialized
INFO - 2018-03-28 15:33:51 --> Model Class Initialized
INFO - 2018-03-28 15:33:51 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:33:51 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:33:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:33:51 --> Model Class Initialized
INFO - 2018-03-28 15:33:51 --> Model Class Initialized
INFO - 2018-03-28 15:33:51 --> Model Class Initialized
INFO - 2018-03-28 15:33:51 --> Model Class Initialized
INFO - 2018-03-28 15:33:51 --> Model Class Initialized
INFO - 2018-03-28 15:33:51 --> Model Class Initialized
INFO - 2018-03-28 15:33:51 --> Model Class Initialized
INFO - 2018-03-28 15:33:51 --> Model Class Initialized
INFO - 2018-03-28 15:33:51 --> Model Class Initialized
INFO - 2018-03-28 15:33:51 --> Model Class Initialized
INFO - 2018-03-28 15:33:51 --> Model Class Initialized
INFO - 2018-03-28 15:33:51 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:33:51 --> Model Class Initialized
INFO - 2018-03-28 15:33:51 --> Final output sent to browser
DEBUG - 2018-03-28 15:33:51 --> Total execution time: 0.2717
INFO - 2018-03-28 10:16:08 --> Config Class Initialized
INFO - 2018-03-28 10:16:08 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:16:08 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:16:08 --> Utf8 Class Initialized
INFO - 2018-03-28 10:16:08 --> URI Class Initialized
INFO - 2018-03-28 10:16:08 --> Router Class Initialized
INFO - 2018-03-28 10:16:08 --> Output Class Initialized
INFO - 2018-03-28 10:16:08 --> Security Class Initialized
DEBUG - 2018-03-28 10:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:16:08 --> Input Class Initialized
INFO - 2018-03-28 10:16:08 --> Language Class Initialized
INFO - 2018-03-28 10:16:08 --> Language Class Initialized
INFO - 2018-03-28 10:16:08 --> Config Class Initialized
INFO - 2018-03-28 10:16:08 --> Loader Class Initialized
INFO - 2018-03-28 15:46:08 --> Helper loaded: url_helper
INFO - 2018-03-28 15:46:08 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:46:08 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:46:08 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:46:08 --> Helper loaded: users_helper
INFO - 2018-03-28 15:46:09 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:46:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:46:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:46:09 --> Helper loaded: form_helper
INFO - 2018-03-28 15:46:09 --> Form Validation Class Initialized
INFO - 2018-03-28 15:46:09 --> Controller Class Initialized
INFO - 2018-03-28 15:46:09 --> Model Class Initialized
INFO - 2018-03-28 15:46:09 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:46:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:46:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:46:09 --> Model Class Initialized
INFO - 2018-03-28 15:46:09 --> Model Class Initialized
INFO - 2018-03-28 15:46:09 --> Model Class Initialized
INFO - 2018-03-28 15:46:09 --> Model Class Initialized
INFO - 2018-03-28 15:46:09 --> Model Class Initialized
INFO - 2018-03-28 15:46:09 --> Model Class Initialized
INFO - 2018-03-28 15:46:09 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:46:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-28 15:46:09 --> Final output sent to browser
DEBUG - 2018-03-28 15:46:09 --> Total execution time: 0.8279
INFO - 2018-03-28 10:16:10 --> Config Class Initialized
INFO - 2018-03-28 10:16:10 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:16:10 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:16:10 --> Utf8 Class Initialized
INFO - 2018-03-28 10:16:10 --> URI Class Initialized
INFO - 2018-03-28 10:16:10 --> Router Class Initialized
INFO - 2018-03-28 10:16:10 --> Output Class Initialized
INFO - 2018-03-28 10:16:10 --> Security Class Initialized
DEBUG - 2018-03-28 10:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:16:10 --> Input Class Initialized
INFO - 2018-03-28 10:16:10 --> Language Class Initialized
INFO - 2018-03-28 10:16:10 --> Language Class Initialized
INFO - 2018-03-28 10:16:10 --> Config Class Initialized
INFO - 2018-03-28 10:16:10 --> Loader Class Initialized
INFO - 2018-03-28 15:46:10 --> Helper loaded: url_helper
INFO - 2018-03-28 15:46:10 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:46:10 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:46:10 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:46:10 --> Helper loaded: users_helper
INFO - 2018-03-28 15:46:10 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:46:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:46:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:46:10 --> Helper loaded: form_helper
INFO - 2018-03-28 15:46:10 --> Form Validation Class Initialized
INFO - 2018-03-28 15:46:10 --> Controller Class Initialized
INFO - 2018-03-28 15:46:10 --> Model Class Initialized
INFO - 2018-03-28 15:46:10 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:46:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:46:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:46:10 --> Model Class Initialized
INFO - 2018-03-28 15:46:10 --> Model Class Initialized
INFO - 2018-03-28 15:46:10 --> Model Class Initialized
INFO - 2018-03-28 15:46:10 --> Model Class Initialized
INFO - 2018-03-28 15:46:10 --> Model Class Initialized
INFO - 2018-03-28 15:46:10 --> Model Class Initialized
INFO - 2018-03-28 15:46:10 --> Model Class Initialized
INFO - 2018-03-28 15:46:10 --> Model Class Initialized
INFO - 2018-03-28 15:46:10 --> Model Class Initialized
INFO - 2018-03-28 15:46:10 --> Model Class Initialized
INFO - 2018-03-28 15:46:10 --> Model Class Initialized
INFO - 2018-03-28 15:46:10 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:46:10 --> Model Class Initialized
INFO - 2018-03-28 15:46:10 --> Final output sent to browser
DEBUG - 2018-03-28 15:46:10 --> Total execution time: 0.3715
INFO - 2018-03-28 10:16:13 --> Config Class Initialized
INFO - 2018-03-28 10:16:13 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:16:13 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:16:13 --> Utf8 Class Initialized
INFO - 2018-03-28 10:16:13 --> URI Class Initialized
INFO - 2018-03-28 10:16:13 --> Router Class Initialized
INFO - 2018-03-28 10:16:13 --> Output Class Initialized
INFO - 2018-03-28 10:16:13 --> Security Class Initialized
DEBUG - 2018-03-28 10:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:16:13 --> Input Class Initialized
INFO - 2018-03-28 10:16:13 --> Language Class Initialized
INFO - 2018-03-28 10:16:13 --> Language Class Initialized
INFO - 2018-03-28 10:16:13 --> Config Class Initialized
INFO - 2018-03-28 10:16:13 --> Loader Class Initialized
INFO - 2018-03-28 15:46:13 --> Helper loaded: url_helper
INFO - 2018-03-28 15:46:13 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:46:13 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:46:13 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:46:13 --> Helper loaded: users_helper
INFO - 2018-03-28 15:46:13 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:46:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:46:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:46:13 --> Helper loaded: form_helper
INFO - 2018-03-28 15:46:13 --> Form Validation Class Initialized
INFO - 2018-03-28 15:46:13 --> Controller Class Initialized
INFO - 2018-03-28 15:46:13 --> Model Class Initialized
INFO - 2018-03-28 15:46:13 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:46:13 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:46:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:46:13 --> Model Class Initialized
INFO - 2018-03-28 15:46:13 --> Model Class Initialized
INFO - 2018-03-28 15:46:13 --> Model Class Initialized
INFO - 2018-03-28 15:46:13 --> Model Class Initialized
INFO - 2018-03-28 15:46:13 --> Model Class Initialized
INFO - 2018-03-28 15:46:13 --> Model Class Initialized
INFO - 2018-03-28 15:46:13 --> Model Class Initialized
INFO - 2018-03-28 15:46:13 --> Model Class Initialized
INFO - 2018-03-28 15:46:13 --> Model Class Initialized
INFO - 2018-03-28 15:46:13 --> Model Class Initialized
INFO - 2018-03-28 15:46:13 --> Model Class Initialized
INFO - 2018-03-28 15:46:13 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:46:13 --> Model Class Initialized
INFO - 2018-03-28 15:46:13 --> Final output sent to browser
DEBUG - 2018-03-28 15:46:13 --> Total execution time: 0.1400
INFO - 2018-03-28 10:16:13 --> Config Class Initialized
INFO - 2018-03-28 10:16:13 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:16:13 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:16:13 --> Utf8 Class Initialized
INFO - 2018-03-28 10:16:13 --> URI Class Initialized
INFO - 2018-03-28 10:16:14 --> Router Class Initialized
INFO - 2018-03-28 10:16:14 --> Output Class Initialized
INFO - 2018-03-28 10:16:14 --> Security Class Initialized
DEBUG - 2018-03-28 10:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:16:14 --> Input Class Initialized
INFO - 2018-03-28 10:16:14 --> Language Class Initialized
INFO - 2018-03-28 10:16:15 --> Config Class Initialized
INFO - 2018-03-28 10:16:15 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:16:15 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:16:15 --> Utf8 Class Initialized
INFO - 2018-03-28 10:16:15 --> URI Class Initialized
INFO - 2018-03-28 10:16:15 --> Router Class Initialized
INFO - 2018-03-28 10:16:15 --> Output Class Initialized
INFO - 2018-03-28 10:16:15 --> Security Class Initialized
DEBUG - 2018-03-28 10:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:16:15 --> Input Class Initialized
INFO - 2018-03-28 10:16:15 --> Language Class Initialized
INFO - 2018-03-28 10:16:15 --> Language Class Initialized
INFO - 2018-03-28 10:16:15 --> Config Class Initialized
INFO - 2018-03-28 10:16:15 --> Loader Class Initialized
INFO - 2018-03-28 15:46:15 --> Helper loaded: url_helper
INFO - 2018-03-28 15:46:15 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:46:15 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:46:15 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:46:15 --> Helper loaded: users_helper
INFO - 2018-03-28 15:46:15 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:46:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:46:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:46:15 --> Helper loaded: form_helper
INFO - 2018-03-28 15:46:15 --> Form Validation Class Initialized
INFO - 2018-03-28 15:46:15 --> Controller Class Initialized
INFO - 2018-03-28 15:46:15 --> Model Class Initialized
INFO - 2018-03-28 15:46:15 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:46:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:46:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:46:15 --> Model Class Initialized
INFO - 2018-03-28 15:46:15 --> Model Class Initialized
INFO - 2018-03-28 15:46:15 --> Model Class Initialized
INFO - 2018-03-28 15:46:15 --> Model Class Initialized
INFO - 2018-03-28 15:46:15 --> Model Class Initialized
INFO - 2018-03-28 15:46:15 --> Model Class Initialized
INFO - 2018-03-28 15:46:15 --> Model Class Initialized
INFO - 2018-03-28 15:46:15 --> Model Class Initialized
INFO - 2018-03-28 15:46:15 --> Model Class Initialized
INFO - 2018-03-28 15:46:15 --> Model Class Initialized
INFO - 2018-03-28 15:46:15 --> Model Class Initialized
INFO - 2018-03-28 15:46:15 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:46:15 --> Model Class Initialized
INFO - 2018-03-28 15:46:15 --> Final output sent to browser
DEBUG - 2018-03-28 15:46:15 --> Total execution time: 0.1441
INFO - 2018-03-28 10:16:15 --> Language Class Initialized
INFO - 2018-03-28 10:16:15 --> Config Class Initialized
INFO - 2018-03-28 10:16:15 --> Loader Class Initialized
INFO - 2018-03-28 10:16:15 --> Config Class Initialized
INFO - 2018-03-28 10:16:15 --> Hooks Class Initialized
INFO - 2018-03-28 15:46:15 --> Helper loaded: url_helper
DEBUG - 2018-03-28 10:16:15 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:16:15 --> Utf8 Class Initialized
INFO - 2018-03-28 10:16:15 --> URI Class Initialized
INFO - 2018-03-28 10:16:15 --> Router Class Initialized
INFO - 2018-03-28 15:46:15 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:46:15 --> Helper loaded: settings_helper
INFO - 2018-03-28 10:16:15 --> Output Class Initialized
INFO - 2018-03-28 15:46:15 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:46:15 --> Helper loaded: users_helper
INFO - 2018-03-28 10:16:15 --> Security Class Initialized
DEBUG - 2018-03-28 10:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:16:15 --> Input Class Initialized
INFO - 2018-03-28 10:16:15 --> Language Class Initialized
INFO - 2018-03-28 10:16:15 --> Language Class Initialized
INFO - 2018-03-28 10:16:15 --> Config Class Initialized
INFO - 2018-03-28 10:16:15 --> Loader Class Initialized
INFO - 2018-03-28 15:46:16 --> Helper loaded: url_helper
INFO - 2018-03-28 15:46:16 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:46:16 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:46:16 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:46:16 --> Helper loaded: users_helper
INFO - 2018-03-28 15:46:16 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:46:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:46:16 --> Database Driver Class Initialized
INFO - 2018-03-28 15:46:16 --> Helper loaded: form_helper
INFO - 2018-03-28 15:46:16 --> Form Validation Class Initialized
INFO - 2018-03-28 15:46:16 --> Controller Class Initialized
INFO - 2018-03-28 15:46:16 --> Model Class Initialized
INFO - 2018-03-28 15:46:16 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:46:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:46:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:46:16 --> Model Class Initialized
INFO - 2018-03-28 15:46:16 --> Model Class Initialized
INFO - 2018-03-28 15:46:16 --> Model Class Initialized
INFO - 2018-03-28 15:46:16 --> Model Class Initialized
INFO - 2018-03-28 15:46:16 --> Model Class Initialized
INFO - 2018-03-28 15:46:16 --> Model Class Initialized
INFO - 2018-03-28 15:46:16 --> Model Class Initialized
INFO - 2018-03-28 15:46:16 --> Model Class Initialized
INFO - 2018-03-28 15:46:16 --> Model Class Initialized
INFO - 2018-03-28 15:46:16 --> Model Class Initialized
INFO - 2018-03-28 15:46:16 --> Model Class Initialized
INFO - 2018-03-28 15:46:16 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:46:16 --> Final output sent to browser
DEBUG - 2018-03-28 15:46:16 --> Total execution time: 0.6093
DEBUG - 2018-03-28 15:46:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:46:17 --> Helper loaded: form_helper
INFO - 2018-03-28 15:46:17 --> Form Validation Class Initialized
INFO - 2018-03-28 15:46:17 --> Controller Class Initialized
INFO - 2018-03-28 15:46:17 --> Model Class Initialized
INFO - 2018-03-28 15:46:17 --> Helper loaded: inflector_helper
INFO - 2018-03-28 10:16:17 --> Config Class Initialized
INFO - 2018-03-28 10:16:17 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:16:17 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:16:17 --> Utf8 Class Initialized
INFO - 2018-03-28 10:16:17 --> URI Class Initialized
INFO - 2018-03-28 10:16:17 --> Router Class Initialized
INFO - 2018-03-28 10:16:17 --> Output Class Initialized
INFO - 2018-03-28 10:16:17 --> Security Class Initialized
DEBUG - 2018-03-28 10:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:16:17 --> Input Class Initialized
INFO - 2018-03-28 10:16:17 --> Language Class Initialized
DEBUG - 2018-03-28 15:46:17 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 10:16:17 --> Language Class Initialized
INFO - 2018-03-28 10:16:17 --> Config Class Initialized
INFO - 2018-03-28 10:16:17 --> Loader Class Initialized
INFO - 2018-03-28 15:46:17 --> Helper loaded: url_helper
INFO - 2018-03-28 15:46:17 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:46:17 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:46:17 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:46:17 --> Helper loaded: users_helper
INFO - 2018-03-28 15:46:17 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:46:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:46:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:46:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:46:17 --> Helper loaded: form_helper
INFO - 2018-03-28 15:46:17 --> Form Validation Class Initialized
INFO - 2018-03-28 15:46:17 --> Controller Class Initialized
INFO - 2018-03-28 15:46:17 --> Model Class Initialized
INFO - 2018-03-28 15:46:17 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:46:17 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:46:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:46:17 --> Model Class Initialized
INFO - 2018-03-28 15:46:17 --> Model Class Initialized
INFO - 2018-03-28 15:46:17 --> Model Class Initialized
INFO - 2018-03-28 15:46:17 --> Model Class Initialized
INFO - 2018-03-28 15:46:17 --> Model Class Initialized
INFO - 2018-03-28 15:46:17 --> Model Class Initialized
INFO - 2018-03-28 15:46:17 --> Model Class Initialized
INFO - 2018-03-28 15:46:17 --> Model Class Initialized
INFO - 2018-03-28 15:46:17 --> Model Class Initialized
INFO - 2018-03-28 15:46:17 --> Model Class Initialized
INFO - 2018-03-28 15:46:17 --> Model Class Initialized
INFO - 2018-03-28 15:46:17 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:46:17 --> Final output sent to browser
DEBUG - 2018-03-28 15:46:17 --> Total execution time: 0.2043
INFO - 2018-03-28 15:46:17 --> Model Class Initialized
INFO - 2018-03-28 15:46:17 --> Model Class Initialized
INFO - 2018-03-28 15:46:17 --> Model Class Initialized
INFO - 2018-03-28 15:46:17 --> Model Class Initialized
INFO - 2018-03-28 15:46:17 --> Model Class Initialized
INFO - 2018-03-28 15:46:17 --> Model Class Initialized
INFO - 2018-03-28 15:46:17 --> Model Class Initialized
INFO - 2018-03-28 15:46:17 --> Model Class Initialized
INFO - 2018-03-28 15:46:18 --> Model Class Initialized
INFO - 2018-03-28 15:46:18 --> Model Class Initialized
INFO - 2018-03-28 15:46:18 --> Model Class Initialized
INFO - 2018-03-28 15:46:18 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:46:18 --> Model Class Initialized
INFO - 2018-03-28 15:46:18 --> Final output sent to browser
DEBUG - 2018-03-28 15:46:18 --> Total execution time: 5.6614
INFO - 2018-03-28 10:16:20 --> Config Class Initialized
INFO - 2018-03-28 10:16:20 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:16:20 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:16:20 --> Utf8 Class Initialized
INFO - 2018-03-28 10:16:20 --> URI Class Initialized
INFO - 2018-03-28 10:16:20 --> Router Class Initialized
INFO - 2018-03-28 10:16:20 --> Output Class Initialized
INFO - 2018-03-28 10:16:20 --> Security Class Initialized
DEBUG - 2018-03-28 10:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:16:20 --> Input Class Initialized
INFO - 2018-03-28 10:16:20 --> Language Class Initialized
INFO - 2018-03-28 10:16:20 --> Language Class Initialized
INFO - 2018-03-28 10:16:20 --> Config Class Initialized
INFO - 2018-03-28 10:16:20 --> Loader Class Initialized
INFO - 2018-03-28 15:46:20 --> Helper loaded: url_helper
INFO - 2018-03-28 15:46:20 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:46:20 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:46:20 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:46:20 --> Helper loaded: users_helper
INFO - 2018-03-28 15:46:20 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:46:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:46:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:46:20 --> Helper loaded: form_helper
INFO - 2018-03-28 15:46:20 --> Form Validation Class Initialized
INFO - 2018-03-28 15:46:20 --> Controller Class Initialized
INFO - 2018-03-28 15:46:20 --> Model Class Initialized
INFO - 2018-03-28 15:46:20 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:46:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:46:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:46:20 --> Model Class Initialized
INFO - 2018-03-28 15:46:20 --> Model Class Initialized
INFO - 2018-03-28 15:46:20 --> Model Class Initialized
INFO - 2018-03-28 15:46:20 --> Model Class Initialized
INFO - 2018-03-28 15:46:20 --> Model Class Initialized
INFO - 2018-03-28 15:46:20 --> Model Class Initialized
INFO - 2018-03-28 15:46:20 --> Model Class Initialized
INFO - 2018-03-28 15:46:20 --> Model Class Initialized
INFO - 2018-03-28 15:46:20 --> Model Class Initialized
INFO - 2018-03-28 15:46:20 --> Model Class Initialized
INFO - 2018-03-28 15:46:20 --> Model Class Initialized
INFO - 2018-03-28 15:46:20 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:46:20 --> Final output sent to browser
DEBUG - 2018-03-28 15:46:20 --> Total execution time: 0.1713
INFO - 2018-03-28 10:22:03 --> Config Class Initialized
INFO - 2018-03-28 10:22:03 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:22:03 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:22:03 --> Utf8 Class Initialized
INFO - 2018-03-28 10:22:03 --> URI Class Initialized
INFO - 2018-03-28 10:22:03 --> Router Class Initialized
INFO - 2018-03-28 10:22:03 --> Output Class Initialized
INFO - 2018-03-28 10:22:03 --> Security Class Initialized
DEBUG - 2018-03-28 10:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:22:03 --> Input Class Initialized
INFO - 2018-03-28 10:22:03 --> Language Class Initialized
INFO - 2018-03-28 10:22:03 --> Language Class Initialized
INFO - 2018-03-28 10:22:03 --> Config Class Initialized
INFO - 2018-03-28 10:22:03 --> Loader Class Initialized
INFO - 2018-03-28 15:52:03 --> Helper loaded: url_helper
INFO - 2018-03-28 15:52:03 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:52:03 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:52:03 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:52:03 --> Helper loaded: users_helper
INFO - 2018-03-28 15:52:03 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:52:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:52:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:52:03 --> Helper loaded: form_helper
INFO - 2018-03-28 15:52:03 --> Form Validation Class Initialized
INFO - 2018-03-28 15:52:03 --> Controller Class Initialized
INFO - 2018-03-28 15:52:03 --> Model Class Initialized
INFO - 2018-03-28 15:52:03 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:52:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:52:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:52:03 --> Model Class Initialized
INFO - 2018-03-28 15:52:03 --> Model Class Initialized
INFO - 2018-03-28 15:52:03 --> Model Class Initialized
INFO - 2018-03-28 15:52:03 --> Model Class Initialized
INFO - 2018-03-28 15:52:03 --> Model Class Initialized
INFO - 2018-03-28 15:52:03 --> Model Class Initialized
INFO - 2018-03-28 15:52:03 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:52:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-28 15:52:03 --> Final output sent to browser
DEBUG - 2018-03-28 15:52:03 --> Total execution time: 0.1214
INFO - 2018-03-28 10:22:04 --> Config Class Initialized
INFO - 2018-03-28 10:22:04 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:22:04 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:22:04 --> Utf8 Class Initialized
INFO - 2018-03-28 10:22:04 --> URI Class Initialized
INFO - 2018-03-28 10:22:04 --> Router Class Initialized
INFO - 2018-03-28 10:22:04 --> Output Class Initialized
INFO - 2018-03-28 10:22:04 --> Security Class Initialized
DEBUG - 2018-03-28 10:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:22:04 --> Input Class Initialized
INFO - 2018-03-28 10:22:04 --> Language Class Initialized
INFO - 2018-03-28 10:22:04 --> Language Class Initialized
INFO - 2018-03-28 10:22:04 --> Config Class Initialized
INFO - 2018-03-28 10:22:04 --> Loader Class Initialized
INFO - 2018-03-28 15:52:04 --> Helper loaded: url_helper
INFO - 2018-03-28 15:52:04 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:52:04 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:52:04 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:52:04 --> Helper loaded: users_helper
INFO - 2018-03-28 15:52:04 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:52:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:52:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:52:04 --> Helper loaded: form_helper
INFO - 2018-03-28 15:52:04 --> Form Validation Class Initialized
INFO - 2018-03-28 15:52:04 --> Controller Class Initialized
INFO - 2018-03-28 15:52:04 --> Model Class Initialized
INFO - 2018-03-28 15:52:04 --> Helper loaded: inflector_helper
INFO - 2018-03-28 10:22:04 --> Config Class Initialized
INFO - 2018-03-28 10:22:04 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:52:04 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:52:05 --> Language file loaded: language/english/rest_controller_lang.php
DEBUG - 2018-03-28 10:22:05 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:22:05 --> Utf8 Class Initialized
INFO - 2018-03-28 15:52:05 --> Model Class Initialized
INFO - 2018-03-28 15:52:05 --> Model Class Initialized
INFO - 2018-03-28 15:52:05 --> Model Class Initialized
INFO - 2018-03-28 10:22:05 --> URI Class Initialized
INFO - 2018-03-28 15:52:05 --> Model Class Initialized
INFO - 2018-03-28 15:52:05 --> Model Class Initialized
INFO - 2018-03-28 15:52:05 --> Model Class Initialized
INFO - 2018-03-28 15:52:05 --> Model Class Initialized
INFO - 2018-03-28 15:52:05 --> Model Class Initialized
INFO - 2018-03-28 15:52:05 --> Model Class Initialized
INFO - 2018-03-28 15:52:05 --> Model Class Initialized
INFO - 2018-03-28 10:22:05 --> Router Class Initialized
INFO - 2018-03-28 15:52:05 --> Model Class Initialized
INFO - 2018-03-28 15:52:05 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:52:05 --> Model Class Initialized
INFO - 2018-03-28 10:22:05 --> Output Class Initialized
INFO - 2018-03-28 10:22:05 --> Security Class Initialized
INFO - 2018-03-28 15:52:05 --> Final output sent to browser
DEBUG - 2018-03-28 15:52:05 --> Total execution time: 0.2941
DEBUG - 2018-03-28 10:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:22:05 --> Input Class Initialized
INFO - 2018-03-28 10:22:05 --> Language Class Initialized
INFO - 2018-03-28 10:22:05 --> Language Class Initialized
INFO - 2018-03-28 10:22:05 --> Config Class Initialized
INFO - 2018-03-28 10:22:05 --> Loader Class Initialized
INFO - 2018-03-28 15:52:05 --> Helper loaded: url_helper
INFO - 2018-03-28 15:52:05 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:52:05 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:52:05 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:52:05 --> Helper loaded: users_helper
INFO - 2018-03-28 15:52:05 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:52:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:52:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:52:05 --> Helper loaded: form_helper
INFO - 2018-03-28 15:52:05 --> Form Validation Class Initialized
INFO - 2018-03-28 15:52:05 --> Controller Class Initialized
INFO - 2018-03-28 15:52:05 --> Model Class Initialized
INFO - 2018-03-28 15:52:05 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:52:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:52:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:52:05 --> Model Class Initialized
INFO - 2018-03-28 15:52:05 --> Model Class Initialized
INFO - 2018-03-28 15:52:05 --> Model Class Initialized
INFO - 2018-03-28 15:52:05 --> Model Class Initialized
INFO - 2018-03-28 15:52:05 --> Model Class Initialized
INFO - 2018-03-28 15:52:05 --> Model Class Initialized
INFO - 2018-03-28 15:52:05 --> Model Class Initialized
INFO - 2018-03-28 15:52:05 --> Model Class Initialized
INFO - 2018-03-28 15:52:05 --> Model Class Initialized
INFO - 2018-03-28 15:52:05 --> Model Class Initialized
INFO - 2018-03-28 15:52:05 --> Model Class Initialized
INFO - 2018-03-28 15:52:05 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:52:05 --> Model Class Initialized
INFO - 2018-03-28 15:52:05 --> Final output sent to browser
DEBUG - 2018-03-28 15:52:05 --> Total execution time: 0.6701
INFO - 2018-03-28 10:22:07 --> Config Class Initialized
INFO - 2018-03-28 10:22:07 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:22:07 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:22:07 --> Utf8 Class Initialized
INFO - 2018-03-28 10:22:07 --> URI Class Initialized
INFO - 2018-03-28 10:22:07 --> Router Class Initialized
INFO - 2018-03-28 10:22:07 --> Output Class Initialized
INFO - 2018-03-28 10:22:07 --> Security Class Initialized
DEBUG - 2018-03-28 10:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:22:07 --> Input Class Initialized
INFO - 2018-03-28 10:22:07 --> Language Class Initialized
INFO - 2018-03-28 10:22:07 --> Language Class Initialized
INFO - 2018-03-28 10:22:07 --> Config Class Initialized
INFO - 2018-03-28 10:22:07 --> Loader Class Initialized
INFO - 2018-03-28 15:52:07 --> Helper loaded: url_helper
INFO - 2018-03-28 15:52:07 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:52:07 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:52:07 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:52:07 --> Helper loaded: users_helper
INFO - 2018-03-28 15:52:07 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:52:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:52:07 --> Helper loaded: form_helper
INFO - 2018-03-28 15:52:07 --> Form Validation Class Initialized
INFO - 2018-03-28 15:52:07 --> Controller Class Initialized
INFO - 2018-03-28 15:52:07 --> Model Class Initialized
INFO - 2018-03-28 15:52:08 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:52:08 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:52:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:52:08 --> Model Class Initialized
INFO - 2018-03-28 15:52:08 --> Model Class Initialized
INFO - 2018-03-28 15:52:08 --> Model Class Initialized
INFO - 2018-03-28 15:52:08 --> Model Class Initialized
INFO - 2018-03-28 15:52:08 --> Model Class Initialized
INFO - 2018-03-28 15:52:08 --> Model Class Initialized
INFO - 2018-03-28 15:52:08 --> Model Class Initialized
INFO - 2018-03-28 15:52:08 --> Model Class Initialized
INFO - 2018-03-28 15:52:08 --> Model Class Initialized
INFO - 2018-03-28 15:52:08 --> Model Class Initialized
INFO - 2018-03-28 15:52:08 --> Model Class Initialized
INFO - 2018-03-28 15:52:08 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:52:08 --> Final output sent to browser
DEBUG - 2018-03-28 15:52:08 --> Total execution time: 0.4104
INFO - 2018-03-28 10:22:08 --> Config Class Initialized
INFO - 2018-03-28 10:22:08 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:22:08 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:22:08 --> Utf8 Class Initialized
INFO - 2018-03-28 10:22:08 --> URI Class Initialized
INFO - 2018-03-28 10:22:08 --> Router Class Initialized
INFO - 2018-03-28 10:22:08 --> Output Class Initialized
INFO - 2018-03-28 10:22:08 --> Security Class Initialized
DEBUG - 2018-03-28 10:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:22:08 --> Input Class Initialized
INFO - 2018-03-28 10:22:08 --> Language Class Initialized
INFO - 2018-03-28 10:22:08 --> Language Class Initialized
INFO - 2018-03-28 10:22:08 --> Config Class Initialized
INFO - 2018-03-28 10:22:08 --> Loader Class Initialized
INFO - 2018-03-28 15:52:08 --> Helper loaded: url_helper
INFO - 2018-03-28 15:52:08 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:52:08 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:52:08 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:52:09 --> Helper loaded: users_helper
INFO - 2018-03-28 15:52:09 --> Database Driver Class Initialized
INFO - 2018-03-28 10:22:10 --> Config Class Initialized
INFO - 2018-03-28 10:22:10 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:22:10 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:22:10 --> Utf8 Class Initialized
INFO - 2018-03-28 10:22:10 --> URI Class Initialized
INFO - 2018-03-28 10:22:10 --> Router Class Initialized
INFO - 2018-03-28 10:22:10 --> Output Class Initialized
INFO - 2018-03-28 10:22:10 --> Security Class Initialized
DEBUG - 2018-03-28 10:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:22:10 --> Input Class Initialized
INFO - 2018-03-28 10:22:10 --> Language Class Initialized
INFO - 2018-03-28 10:22:10 --> Language Class Initialized
INFO - 2018-03-28 10:22:10 --> Config Class Initialized
INFO - 2018-03-28 10:22:10 --> Loader Class Initialized
INFO - 2018-03-28 15:52:10 --> Helper loaded: url_helper
INFO - 2018-03-28 15:52:10 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:52:10 --> Helper loaded: settings_helper
DEBUG - 2018-03-28 15:52:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:52:10 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:52:10 --> Helper loaded: users_helper
INFO - 2018-03-28 15:52:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:52:10 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:52:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:52:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:52:10 --> Helper loaded: form_helper
INFO - 2018-03-28 15:52:10 --> Form Validation Class Initialized
INFO - 2018-03-28 15:52:10 --> Controller Class Initialized
INFO - 2018-03-28 15:52:10 --> Model Class Initialized
INFO - 2018-03-28 15:52:10 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:52:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:52:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:52:10 --> Model Class Initialized
INFO - 2018-03-28 15:52:10 --> Model Class Initialized
INFO - 2018-03-28 15:52:10 --> Model Class Initialized
INFO - 2018-03-28 15:52:10 --> Model Class Initialized
INFO - 2018-03-28 15:52:10 --> Model Class Initialized
INFO - 2018-03-28 15:52:10 --> Model Class Initialized
INFO - 2018-03-28 15:52:10 --> Helper loaded: form_helper
INFO - 2018-03-28 15:52:10 --> Model Class Initialized
INFO - 2018-03-28 15:52:10 --> Form Validation Class Initialized
INFO - 2018-03-28 15:52:10 --> Controller Class Initialized
INFO - 2018-03-28 15:52:10 --> Model Class Initialized
INFO - 2018-03-28 15:52:10 --> Model Class Initialized
INFO - 2018-03-28 15:52:10 --> Model Class Initialized
INFO - 2018-03-28 15:52:10 --> Model Class Initialized
INFO - 2018-03-28 15:52:10 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:52:10 --> Model Class Initialized
INFO - 2018-03-28 15:52:10 --> Final output sent to browser
DEBUG - 2018-03-28 15:52:10 --> Total execution time: 0.3656
INFO - 2018-03-28 15:52:10 --> Model Class Initialized
INFO - 2018-03-28 15:52:10 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:52:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:52:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:52:10 --> Model Class Initialized
INFO - 2018-03-28 15:52:10 --> Model Class Initialized
INFO - 2018-03-28 15:52:10 --> Model Class Initialized
INFO - 2018-03-28 15:52:10 --> Model Class Initialized
INFO - 2018-03-28 15:52:10 --> Model Class Initialized
INFO - 2018-03-28 15:52:10 --> Model Class Initialized
INFO - 2018-03-28 15:52:10 --> Model Class Initialized
INFO - 2018-03-28 15:52:10 --> Model Class Initialized
INFO - 2018-03-28 15:52:10 --> Model Class Initialized
INFO - 2018-03-28 15:52:11 --> Model Class Initialized
INFO - 2018-03-28 15:52:11 --> Model Class Initialized
INFO - 2018-03-28 15:52:11 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:52:11 --> Model Class Initialized
INFO - 2018-03-28 15:52:11 --> Final output sent to browser
DEBUG - 2018-03-28 15:52:11 --> Total execution time: 3.4583
INFO - 2018-03-28 10:22:13 --> Config Class Initialized
INFO - 2018-03-28 10:22:13 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:22:13 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:22:13 --> Utf8 Class Initialized
INFO - 2018-03-28 10:22:13 --> URI Class Initialized
INFO - 2018-03-28 10:22:13 --> Router Class Initialized
INFO - 2018-03-28 10:22:13 --> Output Class Initialized
INFO - 2018-03-28 10:22:14 --> Security Class Initialized
DEBUG - 2018-03-28 10:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:22:14 --> Input Class Initialized
INFO - 2018-03-28 10:22:14 --> Language Class Initialized
INFO - 2018-03-28 10:22:15 --> Language Class Initialized
INFO - 2018-03-28 10:22:15 --> Config Class Initialized
INFO - 2018-03-28 10:22:15 --> Hooks Class Initialized
INFO - 2018-03-28 10:22:15 --> Config Class Initialized
INFO - 2018-03-28 10:22:15 --> Loader Class Initialized
DEBUG - 2018-03-28 10:22:15 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:22:15 --> Utf8 Class Initialized
INFO - 2018-03-28 10:22:15 --> URI Class Initialized
INFO - 2018-03-28 10:22:15 --> Router Class Initialized
INFO - 2018-03-28 10:22:15 --> Output Class Initialized
INFO - 2018-03-28 10:22:15 --> Security Class Initialized
DEBUG - 2018-03-28 10:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:22:15 --> Input Class Initialized
INFO - 2018-03-28 10:22:15 --> Language Class Initialized
INFO - 2018-03-28 10:22:15 --> Language Class Initialized
INFO - 2018-03-28 10:22:15 --> Config Class Initialized
INFO - 2018-03-28 10:22:15 --> Loader Class Initialized
INFO - 2018-03-28 15:52:15 --> Helper loaded: url_helper
INFO - 2018-03-28 15:52:15 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:52:15 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:52:15 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:52:15 --> Helper loaded: users_helper
INFO - 2018-03-28 15:52:15 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:52:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:52:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:52:15 --> Helper loaded: form_helper
INFO - 2018-03-28 15:52:15 --> Form Validation Class Initialized
INFO - 2018-03-28 15:52:15 --> Controller Class Initialized
INFO - 2018-03-28 15:52:15 --> Model Class Initialized
INFO - 2018-03-28 15:52:15 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:52:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:52:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:52:15 --> Model Class Initialized
INFO - 2018-03-28 15:52:15 --> Model Class Initialized
INFO - 2018-03-28 15:52:15 --> Model Class Initialized
INFO - 2018-03-28 15:52:15 --> Model Class Initialized
INFO - 2018-03-28 15:52:15 --> Model Class Initialized
INFO - 2018-03-28 15:52:15 --> Model Class Initialized
INFO - 2018-03-28 15:52:15 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-28 15:52:15 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-28 15:52:15 --> Final output sent to browser
DEBUG - 2018-03-28 15:52:15 --> Total execution time: 0.1123
INFO - 2018-03-28 15:52:15 --> Helper loaded: url_helper
INFO - 2018-03-28 15:52:15 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:52:15 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:52:15 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:52:15 --> Helper loaded: users_helper
INFO - 2018-03-28 15:52:16 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:52:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:52:16 --> Helper loaded: form_helper
INFO - 2018-03-28 15:52:16 --> Form Validation Class Initialized
INFO - 2018-03-28 15:52:16 --> Controller Class Initialized
INFO - 2018-03-28 10:22:16 --> Config Class Initialized
INFO - 2018-03-28 10:22:16 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:22:16 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:22:16 --> Utf8 Class Initialized
INFO - 2018-03-28 10:22:16 --> URI Class Initialized
INFO - 2018-03-28 10:22:16 --> Router Class Initialized
INFO - 2018-03-28 10:22:16 --> Config Class Initialized
INFO - 2018-03-28 10:22:16 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:22:16 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:22:16 --> Utf8 Class Initialized
INFO - 2018-03-28 10:22:16 --> Output Class Initialized
INFO - 2018-03-28 10:22:16 --> URI Class Initialized
INFO - 2018-03-28 10:22:16 --> Security Class Initialized
INFO - 2018-03-28 10:22:16 --> Router Class Initialized
INFO - 2018-03-28 10:22:16 --> Output Class Initialized
INFO - 2018-03-28 10:22:16 --> Security Class Initialized
DEBUG - 2018-03-28 10:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:22:16 --> Input Class Initialized
INFO - 2018-03-28 10:22:16 --> Language Class Initialized
DEBUG - 2018-03-28 10:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:22:16 --> Input Class Initialized
INFO - 2018-03-28 10:22:16 --> Language Class Initialized
INFO - 2018-03-28 10:22:16 --> Language Class Initialized
INFO - 2018-03-28 10:22:16 --> Config Class Initialized
INFO - 2018-03-28 10:22:16 --> Loader Class Initialized
INFO - 2018-03-28 15:52:16 --> Helper loaded: url_helper
INFO - 2018-03-28 15:52:16 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:52:16 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:52:16 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:52:16 --> Helper loaded: users_helper
INFO - 2018-03-28 10:22:16 --> Config Class Initialized
INFO - 2018-03-28 10:22:16 --> Hooks Class Initialized
INFO - 2018-03-28 15:52:16 --> Database Driver Class Initialized
INFO - 2018-03-28 10:22:16 --> Language Class Initialized
INFO - 2018-03-28 10:22:16 --> Config Class Initialized
INFO - 2018-03-28 10:22:16 --> Loader Class Initialized
DEBUG - 2018-03-28 15:52:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:52:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-03-28 10:22:16 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:22:16 --> Utf8 Class Initialized
INFO - 2018-03-28 15:52:16 --> Helper loaded: url_helper
INFO - 2018-03-28 10:22:16 --> URI Class Initialized
INFO - 2018-03-28 15:52:16 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:52:16 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:52:16 --> Helper loaded: form_helper
INFO - 2018-03-28 15:52:16 --> Form Validation Class Initialized
INFO - 2018-03-28 15:52:16 --> Controller Class Initialized
INFO - 2018-03-28 15:52:16 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:52:16 --> Helper loaded: users_helper
INFO - 2018-03-28 10:22:16 --> Router Class Initialized
INFO - 2018-03-28 15:52:16 --> Model Class Initialized
INFO - 2018-03-28 15:52:16 --> Helper loaded: inflector_helper
INFO - 2018-03-28 10:22:16 --> Output Class Initialized
DEBUG - 2018-03-28 15:52:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:52:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:52:16 --> Model Class Initialized
INFO - 2018-03-28 15:52:16 --> Model Class Initialized
INFO - 2018-03-28 15:52:16 --> Model Class Initialized
INFO - 2018-03-28 10:22:16 --> Security Class Initialized
INFO - 2018-03-28 15:52:16 --> Model Class Initialized
INFO - 2018-03-28 15:52:16 --> Model Class Initialized
INFO - 2018-03-28 15:52:16 --> Model Class Initialized
INFO - 2018-03-28 15:52:16 --> Model Class Initialized
INFO - 2018-03-28 15:52:16 --> Model Class Initialized
INFO - 2018-03-28 15:52:16 --> Model Class Initialized
INFO - 2018-03-28 15:52:16 --> Model Class Initialized
DEBUG - 2018-03-28 10:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:22:16 --> Input Class Initialized
INFO - 2018-03-28 10:22:16 --> Language Class Initialized
INFO - 2018-03-28 15:52:16 --> Model Class Initialized
INFO - 2018-03-28 15:52:16 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:52:16 --> Model Class Initialized
INFO - 2018-03-28 10:22:16 --> Config Class Initialized
INFO - 2018-03-28 10:22:16 --> Hooks Class Initialized
INFO - 2018-03-28 15:52:16 --> Database Driver Class Initialized
DEBUG - 2018-03-28 10:22:16 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:22:16 --> Utf8 Class Initialized
INFO - 2018-03-28 10:22:16 --> URI Class Initialized
INFO - 2018-03-28 15:52:16 --> Final output sent to browser
DEBUG - 2018-03-28 15:52:16 --> Total execution time: 0.1232
DEBUG - 2018-03-28 15:52:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 10:22:16 --> Router Class Initialized
INFO - 2018-03-28 10:22:16 --> Output Class Initialized
INFO - 2018-03-28 10:22:16 --> Security Class Initialized
INFO - 2018-03-28 15:52:16 --> Helper loaded: form_helper
INFO - 2018-03-28 15:52:16 --> Form Validation Class Initialized
INFO - 2018-03-28 15:52:16 --> Controller Class Initialized
DEBUG - 2018-03-28 10:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:22:16 --> Input Class Initialized
INFO - 2018-03-28 10:22:16 --> Language Class Initialized
INFO - 2018-03-28 15:52:16 --> Model Class Initialized
INFO - 2018-03-28 15:52:16 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:52:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 10:22:16 --> Language Class Initialized
INFO - 2018-03-28 10:22:16 --> Config Class Initialized
INFO - 2018-03-28 10:22:16 --> Loader Class Initialized
INFO - 2018-03-28 15:52:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:52:16 --> Model Class Initialized
INFO - 2018-03-28 15:52:16 --> Model Class Initialized
INFO - 2018-03-28 15:52:16 --> Helper loaded: url_helper
INFO - 2018-03-28 15:52:16 --> Model Class Initialized
INFO - 2018-03-28 15:52:16 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:52:16 --> Model Class Initialized
INFO - 2018-03-28 15:52:16 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:52:16 --> Model Class Initialized
INFO - 2018-03-28 15:52:16 --> Model Class Initialized
INFO - 2018-03-28 15:52:16 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:52:16 --> Model Class Initialized
INFO - 2018-03-28 15:52:16 --> Helper loaded: users_helper
INFO - 2018-03-28 15:52:16 --> Model Class Initialized
INFO - 2018-03-28 15:52:16 --> Model Class Initialized
INFO - 2018-03-28 15:52:16 --> Model Class Initialized
INFO - 2018-03-28 15:52:16 --> Model Class Initialized
INFO - 2018-03-28 15:52:16 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:52:16 --> Database Driver Class Initialized
INFO - 2018-03-28 10:22:17 --> Language Class Initialized
INFO - 2018-03-28 10:22:17 --> Config Class Initialized
INFO - 2018-03-28 10:22:17 --> Loader Class Initialized
INFO - 2018-03-28 15:52:17 --> Helper loaded: url_helper
INFO - 2018-03-28 15:52:17 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:52:17 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:52:17 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:52:17 --> Helper loaded: users_helper
INFO - 2018-03-28 15:52:17 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:52:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:52:17 --> Helper loaded: form_helper
INFO - 2018-03-28 15:52:17 --> Form Validation Class Initialized
INFO - 2018-03-28 15:52:17 --> Controller Class Initialized
INFO - 2018-03-28 10:22:17 --> Config Class Initialized
INFO - 2018-03-28 10:22:17 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:22:17 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:22:17 --> Utf8 Class Initialized
INFO - 2018-03-28 10:22:17 --> URI Class Initialized
INFO - 2018-03-28 15:52:17 --> Final output sent to browser
DEBUG - 2018-03-28 15:52:17 --> Total execution time: 0.3231
INFO - 2018-03-28 10:22:17 --> Router Class Initialized
INFO - 2018-03-28 10:22:17 --> Output Class Initialized
DEBUG - 2018-03-28 15:52:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 10:22:17 --> Security Class Initialized
DEBUG - 2018-03-28 10:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:22:17 --> Input Class Initialized
INFO - 2018-03-28 10:22:17 --> Language Class Initialized
INFO - 2018-03-28 15:52:17 --> Model Class Initialized
INFO - 2018-03-28 15:52:17 --> Model Class Initialized
INFO - 2018-03-28 10:22:17 --> Language Class Initialized
INFO - 2018-03-28 10:22:17 --> Config Class Initialized
INFO - 2018-03-28 10:22:17 --> Loader Class Initialized
INFO - 2018-03-28 15:52:17 --> Helper loaded: url_helper
INFO - 2018-03-28 15:52:17 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:52:17 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:52:17 --> Helper loaded: inflector_helper
INFO - 2018-03-28 15:52:17 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:52:17 --> Helper loaded: users_helper
INFO - 2018-03-28 15:52:17 --> Helper loaded: inflector_helper
INFO - 2018-03-28 15:52:17 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:52:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:52:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-03-28 15:52:17 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:52:17 --> Helper loaded: form_helper
INFO - 2018-03-28 15:52:17 --> Form Validation Class Initialized
INFO - 2018-03-28 15:52:17 --> Controller Class Initialized
INFO - 2018-03-28 15:52:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:52:17 --> Model Class Initialized
INFO - 2018-03-28 15:52:17 --> Model Class Initialized
INFO - 2018-03-28 15:52:17 --> Model Class Initialized
INFO - 2018-03-28 15:52:17 --> Model Class Initialized
INFO - 2018-03-28 15:52:17 --> Model Class Initialized
INFO - 2018-03-28 15:52:17 --> Model Class Initialized
INFO - 2018-03-28 15:52:17 --> Model Class Initialized
INFO - 2018-03-28 15:52:17 --> Model Class Initialized
INFO - 2018-03-28 15:52:17 --> Model Class Initialized
INFO - 2018-03-28 15:52:17 --> Model Class Initialized
INFO - 2018-03-28 15:52:17 --> Model Class Initialized
INFO - 2018-03-28 15:52:17 --> Helper loaded: inflector_helper
INFO - 2018-03-28 15:52:17 --> Model Class Initialized
INFO - 2018-03-28 15:52:17 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:52:17 --> Model Class Initialized
DEBUG - 2018-03-28 15:52:17 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:52:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:52:17 --> Model Class Initialized
INFO - 2018-03-28 15:52:17 --> Model Class Initialized
INFO - 2018-03-28 15:52:17 --> Model Class Initialized
INFO - 2018-03-28 15:52:17 --> Model Class Initialized
INFO - 2018-03-28 15:52:17 --> Model Class Initialized
INFO - 2018-03-28 15:52:17 --> Final output sent to browser
DEBUG - 2018-03-28 15:52:17 --> Total execution time: 0.4736
INFO - 2018-03-28 15:52:17 --> Model Class Initialized
INFO - 2018-03-28 15:52:17 --> Model Class Initialized
INFO - 2018-03-28 15:52:17 --> Model Class Initialized
INFO - 2018-03-28 15:52:17 --> Model Class Initialized
INFO - 2018-03-28 15:52:17 --> Model Class Initialized
INFO - 2018-03-28 15:52:17 --> Model Class Initialized
INFO - 2018-03-28 15:52:17 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:52:17 --> Final output sent to browser
DEBUG - 2018-03-28 15:52:17 --> Total execution time: 0.2686
DEBUG - 2018-03-28 15:52:17 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:52:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:52:17 --> Model Class Initialized
INFO - 2018-03-28 15:52:17 --> Model Class Initialized
INFO - 2018-03-28 15:52:17 --> Helper loaded: form_helper
INFO - 2018-03-28 15:52:17 --> Form Validation Class Initialized
INFO - 2018-03-28 15:52:17 --> Controller Class Initialized
INFO - 2018-03-28 15:52:17 --> Model Class Initialized
INFO - 2018-03-28 15:52:17 --> Model Class Initialized
INFO - 2018-03-28 15:52:17 --> Model Class Initialized
INFO - 2018-03-28 15:52:17 --> Model Class Initialized
INFO - 2018-03-28 15:52:17 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-28 15:52:17 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-28 15:52:17 --> Final output sent to browser
DEBUG - 2018-03-28 15:52:17 --> Total execution time: 4.8060
INFO - 2018-03-28 15:52:18 --> Model Class Initialized
INFO - 2018-03-28 15:52:18 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:52:18 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:52:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:52:18 --> Model Class Initialized
INFO - 2018-03-28 15:52:18 --> Model Class Initialized
INFO - 2018-03-28 15:52:18 --> Model Class Initialized
INFO - 2018-03-28 15:52:18 --> Model Class Initialized
INFO - 2018-03-28 15:52:18 --> Model Class Initialized
INFO - 2018-03-28 15:52:18 --> Model Class Initialized
INFO - 2018-03-28 15:52:18 --> Model Class Initialized
INFO - 2018-03-28 15:52:18 --> Model Class Initialized
INFO - 2018-03-28 15:52:18 --> Model Class Initialized
INFO - 2018-03-28 15:52:18 --> Model Class Initialized
INFO - 2018-03-28 15:52:18 --> Model Class Initialized
INFO - 2018-03-28 15:52:18 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:52:18 --> Model Class Initialized
INFO - 2018-03-28 15:52:18 --> Final output sent to browser
DEBUG - 2018-03-28 15:52:18 --> Total execution time: 1.3989
INFO - 2018-03-28 10:22:19 --> Config Class Initialized
INFO - 2018-03-28 10:22:19 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:22:19 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:22:19 --> Utf8 Class Initialized
INFO - 2018-03-28 10:22:19 --> URI Class Initialized
INFO - 2018-03-28 10:22:19 --> Router Class Initialized
INFO - 2018-03-28 10:22:19 --> Output Class Initialized
INFO - 2018-03-28 10:22:19 --> Security Class Initialized
DEBUG - 2018-03-28 10:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:22:19 --> Input Class Initialized
INFO - 2018-03-28 10:22:19 --> Language Class Initialized
INFO - 2018-03-28 10:22:20 --> Language Class Initialized
INFO - 2018-03-28 10:22:20 --> Config Class Initialized
INFO - 2018-03-28 10:22:20 --> Loader Class Initialized
INFO - 2018-03-28 15:52:20 --> Helper loaded: url_helper
INFO - 2018-03-28 15:52:20 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:52:20 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:52:20 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:52:20 --> Helper loaded: users_helper
INFO - 2018-03-28 10:22:20 --> Config Class Initialized
INFO - 2018-03-28 10:22:20 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:22:20 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:22:20 --> Utf8 Class Initialized
INFO - 2018-03-28 10:22:20 --> URI Class Initialized
INFO - 2018-03-28 15:52:20 --> Database Driver Class Initialized
INFO - 2018-03-28 10:22:20 --> Router Class Initialized
DEBUG - 2018-03-28 15:52:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:52:20 --> Helper loaded: form_helper
INFO - 2018-03-28 15:52:20 --> Form Validation Class Initialized
INFO - 2018-03-28 15:52:20 --> Controller Class Initialized
INFO - 2018-03-28 10:22:20 --> Output Class Initialized
INFO - 2018-03-28 15:52:20 --> Model Class Initialized
INFO - 2018-03-28 15:52:20 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:52:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 10:22:20 --> Security Class Initialized
INFO - 2018-03-28 15:52:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:52:20 --> Model Class Initialized
INFO - 2018-03-28 15:52:20 --> Model Class Initialized
INFO - 2018-03-28 15:52:20 --> Model Class Initialized
INFO - 2018-03-28 15:52:20 --> Model Class Initialized
INFO - 2018-03-28 15:52:20 --> Model Class Initialized
INFO - 2018-03-28 15:52:20 --> Model Class Initialized
INFO - 2018-03-28 15:52:20 --> Model Class Initialized
INFO - 2018-03-28 15:52:20 --> Model Class Initialized
INFO - 2018-03-28 15:52:20 --> Model Class Initialized
INFO - 2018-03-28 15:52:20 --> Model Class Initialized
INFO - 2018-03-28 15:52:20 --> Model Class Initialized
INFO - 2018-03-28 15:52:20 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:52:20 --> Model Class Initialized
DEBUG - 2018-03-28 10:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:22:20 --> Input Class Initialized
INFO - 2018-03-28 15:52:20 --> Final output sent to browser
DEBUG - 2018-03-28 15:52:20 --> Total execution time: 1.5962
INFO - 2018-03-28 10:22:20 --> Language Class Initialized
INFO - 2018-03-28 10:22:20 --> Language Class Initialized
INFO - 2018-03-28 10:22:20 --> Config Class Initialized
INFO - 2018-03-28 10:22:20 --> Loader Class Initialized
INFO - 2018-03-28 15:52:20 --> Helper loaded: url_helper
INFO - 2018-03-28 15:52:20 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:52:20 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:52:21 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:52:21 --> Helper loaded: users_helper
INFO - 2018-03-28 15:52:21 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:52:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:52:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:52:21 --> Helper loaded: form_helper
INFO - 2018-03-28 15:52:21 --> Form Validation Class Initialized
INFO - 2018-03-28 15:52:21 --> Controller Class Initialized
INFO - 2018-03-28 15:52:21 --> Model Class Initialized
INFO - 2018-03-28 15:52:21 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:52:21 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:52:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:52:21 --> Model Class Initialized
INFO - 2018-03-28 15:52:21 --> Model Class Initialized
INFO - 2018-03-28 15:52:21 --> Model Class Initialized
INFO - 2018-03-28 15:52:21 --> Model Class Initialized
INFO - 2018-03-28 15:52:21 --> Model Class Initialized
INFO - 2018-03-28 15:52:21 --> Model Class Initialized
INFO - 2018-03-28 15:52:21 --> Model Class Initialized
INFO - 2018-03-28 15:52:21 --> Model Class Initialized
INFO - 2018-03-28 15:52:21 --> Model Class Initialized
INFO - 2018-03-28 15:52:21 --> Model Class Initialized
INFO - 2018-03-28 15:52:21 --> Model Class Initialized
INFO - 2018-03-28 15:52:21 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:52:21 --> Model Class Initialized
INFO - 2018-03-28 15:52:21 --> Final output sent to browser
DEBUG - 2018-03-28 15:52:21 --> Total execution time: 1.1266
INFO - 2018-03-28 10:22:24 --> Config Class Initialized
INFO - 2018-03-28 10:22:24 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:22:24 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:22:24 --> Utf8 Class Initialized
INFO - 2018-03-28 10:22:24 --> URI Class Initialized
INFO - 2018-03-28 10:22:24 --> Router Class Initialized
INFO - 2018-03-28 10:22:24 --> Output Class Initialized
INFO - 2018-03-28 10:22:24 --> Security Class Initialized
DEBUG - 2018-03-28 10:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:22:24 --> Input Class Initialized
INFO - 2018-03-28 10:22:24 --> Language Class Initialized
INFO - 2018-03-28 10:22:24 --> Language Class Initialized
INFO - 2018-03-28 10:22:24 --> Config Class Initialized
INFO - 2018-03-28 10:22:24 --> Loader Class Initialized
INFO - 2018-03-28 15:52:24 --> Helper loaded: url_helper
INFO - 2018-03-28 15:52:24 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:52:24 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:52:24 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:52:24 --> Helper loaded: users_helper
INFO - 2018-03-28 15:52:24 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:52:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:52:24 --> Helper loaded: form_helper
INFO - 2018-03-28 15:52:24 --> Form Validation Class Initialized
INFO - 2018-03-28 15:52:24 --> Controller Class Initialized
INFO - 2018-03-28 15:52:24 --> Model Class Initialized
INFO - 2018-03-28 15:52:24 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:52:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:52:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:52:24 --> Model Class Initialized
INFO - 2018-03-28 15:52:24 --> Model Class Initialized
INFO - 2018-03-28 15:52:24 --> Model Class Initialized
INFO - 2018-03-28 15:52:24 --> Model Class Initialized
INFO - 2018-03-28 15:52:24 --> Model Class Initialized
INFO - 2018-03-28 15:52:24 --> Model Class Initialized
INFO - 2018-03-28 15:52:24 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-28 15:52:24 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-28 15:52:24 --> Final output sent to browser
DEBUG - 2018-03-28 15:52:24 --> Total execution time: 0.4409
INFO - 2018-03-28 10:22:26 --> Config Class Initialized
INFO - 2018-03-28 10:22:26 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:22:26 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:22:26 --> Utf8 Class Initialized
INFO - 2018-03-28 10:22:26 --> URI Class Initialized
INFO - 2018-03-28 10:22:26 --> Router Class Initialized
INFO - 2018-03-28 10:22:26 --> Output Class Initialized
INFO - 2018-03-28 10:22:26 --> Security Class Initialized
DEBUG - 2018-03-28 10:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:22:26 --> Input Class Initialized
INFO - 2018-03-28 10:22:26 --> Language Class Initialized
INFO - 2018-03-28 10:22:26 --> Language Class Initialized
INFO - 2018-03-28 10:22:26 --> Config Class Initialized
INFO - 2018-03-28 10:22:26 --> Loader Class Initialized
INFO - 2018-03-28 15:52:26 --> Helper loaded: url_helper
INFO - 2018-03-28 15:52:26 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:52:26 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:52:26 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:52:26 --> Helper loaded: users_helper
INFO - 2018-03-28 10:22:26 --> Config Class Initialized
INFO - 2018-03-28 10:22:26 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:22:26 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:22:26 --> Utf8 Class Initialized
INFO - 2018-03-28 10:22:26 --> URI Class Initialized
INFO - 2018-03-28 10:22:26 --> Router Class Initialized
INFO - 2018-03-28 10:22:26 --> Output Class Initialized
INFO - 2018-03-28 10:22:26 --> Security Class Initialized
DEBUG - 2018-03-28 10:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:22:26 --> Input Class Initialized
INFO - 2018-03-28 10:22:26 --> Language Class Initialized
INFO - 2018-03-28 10:22:26 --> Language Class Initialized
INFO - 2018-03-28 10:22:26 --> Config Class Initialized
INFO - 2018-03-28 10:22:26 --> Loader Class Initialized
INFO - 2018-03-28 15:52:26 --> Helper loaded: url_helper
INFO - 2018-03-28 15:52:26 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:52:26 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:52:26 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:52:26 --> Helper loaded: users_helper
INFO - 2018-03-28 15:52:26 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:52:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:52:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:52:26 --> Helper loaded: form_helper
INFO - 2018-03-28 15:52:26 --> Form Validation Class Initialized
INFO - 2018-03-28 15:52:26 --> Controller Class Initialized
INFO - 2018-03-28 10:22:26 --> Config Class Initialized
INFO - 2018-03-28 10:22:26 --> Hooks Class Initialized
INFO - 2018-03-28 15:52:26 --> Model Class Initialized
INFO - 2018-03-28 15:52:26 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:52:26 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:52:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:52:26 --> Model Class Initialized
INFO - 2018-03-28 15:52:26 --> Model Class Initialized
INFO - 2018-03-28 15:52:26 --> Model Class Initialized
INFO - 2018-03-28 15:52:26 --> Model Class Initialized
INFO - 2018-03-28 15:52:26 --> Model Class Initialized
INFO - 2018-03-28 15:52:26 --> Model Class Initialized
INFO - 2018-03-28 15:52:26 --> Model Class Initialized
INFO - 2018-03-28 15:52:26 --> Model Class Initialized
INFO - 2018-03-28 15:52:26 --> Model Class Initialized
INFO - 2018-03-28 15:52:26 --> Model Class Initialized
INFO - 2018-03-28 15:52:27 --> Model Class Initialized
INFO - 2018-03-28 15:52:27 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:52:27 --> Final output sent to browser
DEBUG - 2018-03-28 15:52:27 --> Total execution time: 0.2476
INFO - 2018-03-28 15:52:27 --> Database Driver Class Initialized
INFO - 2018-03-28 10:22:27 --> Config Class Initialized
INFO - 2018-03-28 10:22:27 --> Hooks Class Initialized
INFO - 2018-03-28 10:22:27 --> Config Class Initialized
INFO - 2018-03-28 10:22:27 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:22:27 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:22:27 --> Utf8 Class Initialized
DEBUG - 2018-03-28 10:22:27 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:22:27 --> URI Class Initialized
INFO - 2018-03-28 10:22:27 --> Utf8 Class Initialized
INFO - 2018-03-28 10:22:27 --> Router Class Initialized
DEBUG - 2018-03-28 10:22:27 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:22:27 --> Utf8 Class Initialized
INFO - 2018-03-28 10:22:27 --> Output Class Initialized
INFO - 2018-03-28 10:22:27 --> URI Class Initialized
INFO - 2018-03-28 10:22:27 --> Security Class Initialized
DEBUG - 2018-03-28 10:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:22:27 --> Input Class Initialized
INFO - 2018-03-28 10:22:27 --> Language Class Initialized
INFO - 2018-03-28 10:22:27 --> Router Class Initialized
INFO - 2018-03-28 10:22:27 --> URI Class Initialized
INFO - 2018-03-28 10:22:27 --> Output Class Initialized
INFO - 2018-03-28 10:22:27 --> Language Class Initialized
INFO - 2018-03-28 10:22:27 --> Config Class Initialized
INFO - 2018-03-28 10:22:27 --> Loader Class Initialized
INFO - 2018-03-28 10:22:27 --> Security Class Initialized
INFO - 2018-03-28 15:52:27 --> Helper loaded: url_helper
INFO - 2018-03-28 15:52:27 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:52:27 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:52:27 --> Helper loaded: permission_helper
DEBUG - 2018-03-28 15:52:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-28 10:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:22:27 --> Input Class Initialized
INFO - 2018-03-28 15:52:27 --> Helper loaded: users_helper
INFO - 2018-03-28 10:22:27 --> Language Class Initialized
INFO - 2018-03-28 15:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 10:22:27 --> Config Class Initialized
INFO - 2018-03-28 10:22:27 --> Hooks Class Initialized
INFO - 2018-03-28 15:52:27 --> Database Driver Class Initialized
INFO - 2018-03-28 10:22:27 --> Language Class Initialized
INFO - 2018-03-28 10:22:27 --> Config Class Initialized
INFO - 2018-03-28 10:22:27 --> Loader Class Initialized
DEBUG - 2018-03-28 15:52:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:52:27 --> Helper loaded: url_helper
INFO - 2018-03-28 15:52:27 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:52:27 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:52:27 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:52:27 --> Helper loaded: users_helper
INFO - 2018-03-28 15:52:27 --> Helper loaded: form_helper
INFO - 2018-03-28 15:52:27 --> Form Validation Class Initialized
INFO - 2018-03-28 15:52:27 --> Controller Class Initialized
INFO - 2018-03-28 15:52:27 --> Model Class Initialized
INFO - 2018-03-28 10:22:27 --> Router Class Initialized
INFO - 2018-03-28 15:52:27 --> Helper loaded: inflector_helper
INFO - 2018-03-28 15:52:27 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:52:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-28 15:52:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:52:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:52:27 --> Model Class Initialized
INFO - 2018-03-28 15:52:27 --> Helper loaded: form_helper
INFO - 2018-03-28 15:52:27 --> Form Validation Class Initialized
INFO - 2018-03-28 15:52:27 --> Controller Class Initialized
INFO - 2018-03-28 15:52:27 --> Model Class Initialized
INFO - 2018-03-28 15:52:27 --> Model Class Initialized
INFO - 2018-03-28 15:52:27 --> Model Class Initialized
INFO - 2018-03-28 15:52:27 --> Model Class Initialized
INFO - 2018-03-28 15:52:27 --> Model Class Initialized
INFO - 2018-03-28 15:52:27 --> Model Class Initialized
INFO - 2018-03-28 15:52:27 --> Model Class Initialized
INFO - 2018-03-28 15:52:27 --> Model Class Initialized
INFO - 2018-03-28 15:52:27 --> Model Class Initialized
INFO - 2018-03-28 15:52:27 --> Model Class Initialized
INFO - 2018-03-28 15:52:27 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:52:27 --> Model Class Initialized
INFO - 2018-03-28 15:52:27 --> Final output sent to browser
DEBUG - 2018-03-28 15:52:27 --> Total execution time: 0.3090
DEBUG - 2018-03-28 10:22:27 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:22:27 --> Utf8 Class Initialized
INFO - 2018-03-28 10:22:27 --> Output Class Initialized
INFO - 2018-03-28 10:22:27 --> Security Class Initialized
INFO - 2018-03-28 10:22:27 --> URI Class Initialized
INFO - 2018-03-28 15:52:27 --> Helper loaded: form_helper
INFO - 2018-03-28 15:52:27 --> Form Validation Class Initialized
INFO - 2018-03-28 15:52:27 --> Controller Class Initialized
DEBUG - 2018-03-28 10:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:22:27 --> Input Class Initialized
INFO - 2018-03-28 10:22:27 --> Language Class Initialized
INFO - 2018-03-28 10:22:27 --> Router Class Initialized
INFO - 2018-03-28 10:22:27 --> Output Class Initialized
INFO - 2018-03-28 15:52:27 --> Model Class Initialized
INFO - 2018-03-28 15:52:27 --> Helper loaded: inflector_helper
INFO - 2018-03-28 10:22:27 --> Security Class Initialized
INFO - 2018-03-28 15:52:27 --> Model Class Initialized
INFO - 2018-03-28 15:52:27 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:52:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:52:27 --> Language file loaded: language/english/rest_controller_lang.php
DEBUG - 2018-03-28 10:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:22:27 --> Input Class Initialized
INFO - 2018-03-28 10:22:27 --> Language Class Initialized
INFO - 2018-03-28 15:52:28 --> Model Class Initialized
INFO - 2018-03-28 15:52:28 --> Model Class Initialized
DEBUG - 2018-03-28 15:52:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:52:28 --> Model Class Initialized
INFO - 2018-03-28 15:52:28 --> Model Class Initialized
INFO - 2018-03-28 15:52:28 --> Model Class Initialized
INFO - 2018-03-28 15:52:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:52:28 --> Model Class Initialized
INFO - 2018-03-28 15:52:28 --> Model Class Initialized
INFO - 2018-03-28 15:52:28 --> Model Class Initialized
INFO - 2018-03-28 15:52:28 --> Model Class Initialized
INFO - 2018-03-28 15:52:28 --> Model Class Initialized
INFO - 2018-03-28 15:52:28 --> Model Class Initialized
INFO - 2018-03-28 15:52:28 --> Model Class Initialized
INFO - 2018-03-28 10:22:28 --> Language Class Initialized
INFO - 2018-03-28 10:22:28 --> Config Class Initialized
INFO - 2018-03-28 10:22:28 --> Loader Class Initialized
INFO - 2018-03-28 15:52:28 --> Model Class Initialized
INFO - 2018-03-28 15:52:28 --> Model Class Initialized
INFO - 2018-03-28 15:52:28 --> Model Class Initialized
INFO - 2018-03-28 15:52:28 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:52:28 --> Model Class Initialized
INFO - 2018-03-28 15:52:28 --> Model Class Initialized
INFO - 2018-03-28 15:52:28 --> Helper loaded: url_helper
INFO - 2018-03-28 15:52:28 --> Model Class Initialized
INFO - 2018-03-28 15:52:28 --> Model Class Initialized
INFO - 2018-03-28 15:52:28 --> Model Class Initialized
INFO - 2018-03-28 15:52:28 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:52:28 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:52:28 --> Model Class Initialized
INFO - 2018-03-28 15:52:28 --> Model Class Initialized
INFO - 2018-03-28 15:52:28 --> Model Class Initialized
INFO - 2018-03-28 15:52:28 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:52:28 --> Final output sent to browser
INFO - 2018-03-28 15:52:28 --> Model Class Initialized
DEBUG - 2018-03-28 15:52:28 --> Total execution time: 1.4920
INFO - 2018-03-28 15:52:28 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:52:28 --> Final output sent to browser
DEBUG - 2018-03-28 15:52:28 --> Total execution time: 1.9056
INFO - 2018-03-28 15:52:28 --> Helper loaded: users_helper
INFO - 2018-03-28 10:22:28 --> Language Class Initialized
INFO - 2018-03-28 10:22:28 --> Config Class Initialized
INFO - 2018-03-28 10:22:28 --> Loader Class Initialized
INFO - 2018-03-28 15:52:28 --> Helper loaded: url_helper
INFO - 2018-03-28 15:52:28 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:52:28 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:52:28 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:52:28 --> Helper loaded: users_helper
INFO - 2018-03-28 15:52:28 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:52:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:52:28 --> Database Driver Class Initialized
INFO - 2018-03-28 15:52:28 --> Helper loaded: form_helper
INFO - 2018-03-28 15:52:28 --> Form Validation Class Initialized
INFO - 2018-03-28 15:52:28 --> Controller Class Initialized
INFO - 2018-03-28 15:52:28 --> Model Class Initialized
INFO - 2018-03-28 15:52:28 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:52:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:52:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:52:28 --> Model Class Initialized
INFO - 2018-03-28 15:52:28 --> Model Class Initialized
INFO - 2018-03-28 15:52:28 --> Model Class Initialized
INFO - 2018-03-28 15:52:28 --> Model Class Initialized
INFO - 2018-03-28 15:52:28 --> Model Class Initialized
INFO - 2018-03-28 15:52:28 --> Model Class Initialized
INFO - 2018-03-28 15:52:28 --> Model Class Initialized
INFO - 2018-03-28 15:52:28 --> Model Class Initialized
INFO - 2018-03-28 15:52:28 --> Model Class Initialized
INFO - 2018-03-28 15:52:28 --> Model Class Initialized
DEBUG - 2018-03-28 15:52:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:52:28 --> Model Class Initialized
INFO - 2018-03-28 15:52:28 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:52:28 --> Final output sent to browser
DEBUG - 2018-03-28 15:52:28 --> Total execution time: 1.8664
INFO - 2018-03-28 15:52:28 --> Helper loaded: form_helper
INFO - 2018-03-28 15:52:28 --> Form Validation Class Initialized
INFO - 2018-03-28 15:52:28 --> Controller Class Initialized
INFO - 2018-03-28 15:52:28 --> Model Class Initialized
INFO - 2018-03-28 15:52:28 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:52:29 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:52:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:52:29 --> Model Class Initialized
INFO - 2018-03-28 15:52:29 --> Model Class Initialized
INFO - 2018-03-28 15:52:29 --> Model Class Initialized
INFO - 2018-03-28 15:52:29 --> Model Class Initialized
INFO - 2018-03-28 15:52:29 --> Model Class Initialized
INFO - 2018-03-28 15:52:29 --> Model Class Initialized
INFO - 2018-03-28 15:52:29 --> Model Class Initialized
INFO - 2018-03-28 15:52:29 --> Model Class Initialized
INFO - 2018-03-28 15:52:29 --> Model Class Initialized
INFO - 2018-03-28 15:52:29 --> Model Class Initialized
INFO - 2018-03-28 15:52:29 --> Model Class Initialized
INFO - 2018-03-28 15:52:29 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:52:29 --> Model Class Initialized
INFO - 2018-03-28 15:52:29 --> Final output sent to browser
DEBUG - 2018-03-28 15:52:29 --> Total execution time: 2.3555
INFO - 2018-03-28 10:22:29 --> Config Class Initialized
INFO - 2018-03-28 10:22:29 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:22:29 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:22:29 --> Utf8 Class Initialized
INFO - 2018-03-28 10:22:29 --> URI Class Initialized
INFO - 2018-03-28 10:22:29 --> Router Class Initialized
INFO - 2018-03-28 10:22:29 --> Output Class Initialized
INFO - 2018-03-28 10:22:29 --> Security Class Initialized
DEBUG - 2018-03-28 10:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:22:29 --> Input Class Initialized
INFO - 2018-03-28 10:22:29 --> Language Class Initialized
INFO - 2018-03-28 10:22:29 --> Language Class Initialized
INFO - 2018-03-28 10:22:29 --> Config Class Initialized
INFO - 2018-03-28 10:22:29 --> Loader Class Initialized
INFO - 2018-03-28 10:22:29 --> Config Class Initialized
INFO - 2018-03-28 10:22:29 --> Hooks Class Initialized
INFO - 2018-03-28 15:52:29 --> Helper loaded: url_helper
DEBUG - 2018-03-28 10:22:29 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:22:29 --> Utf8 Class Initialized
INFO - 2018-03-28 15:52:29 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:52:29 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:52:30 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:52:30 --> Helper loaded: users_helper
INFO - 2018-03-28 10:22:30 --> URI Class Initialized
INFO - 2018-03-28 10:22:30 --> Router Class Initialized
INFO - 2018-03-28 10:22:30 --> Output Class Initialized
INFO - 2018-03-28 10:22:30 --> Security Class Initialized
INFO - 2018-03-28 15:52:30 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:52:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:52:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-03-28 10:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:22:30 --> Input Class Initialized
INFO - 2018-03-28 15:52:30 --> Helper loaded: form_helper
INFO - 2018-03-28 15:52:30 --> Form Validation Class Initialized
INFO - 2018-03-28 15:52:30 --> Controller Class Initialized
INFO - 2018-03-28 15:52:30 --> Model Class Initialized
INFO - 2018-03-28 10:22:30 --> Language Class Initialized
INFO - 2018-03-28 15:52:30 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:52:30 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:52:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:52:30 --> Model Class Initialized
INFO - 2018-03-28 15:52:30 --> Model Class Initialized
INFO - 2018-03-28 15:52:30 --> Model Class Initialized
INFO - 2018-03-28 15:52:30 --> Model Class Initialized
INFO - 2018-03-28 15:52:30 --> Model Class Initialized
INFO - 2018-03-28 15:52:30 --> Model Class Initialized
INFO - 2018-03-28 15:52:30 --> Model Class Initialized
INFO - 2018-03-28 15:52:30 --> Model Class Initialized
INFO - 2018-03-28 15:52:30 --> Model Class Initialized
INFO - 2018-03-28 15:52:30 --> Model Class Initialized
INFO - 2018-03-28 15:52:30 --> Model Class Initialized
INFO - 2018-03-28 15:52:30 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:52:30 --> Final output sent to browser
DEBUG - 2018-03-28 15:52:30 --> Total execution time: 0.8302
INFO - 2018-03-28 10:22:31 --> Language Class Initialized
INFO - 2018-03-28 10:22:31 --> Config Class Initialized
INFO - 2018-03-28 10:22:31 --> Loader Class Initialized
INFO - 2018-03-28 15:52:31 --> Helper loaded: url_helper
INFO - 2018-03-28 15:52:31 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:52:31 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:52:31 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:52:31 --> Helper loaded: users_helper
INFO - 2018-03-28 15:52:32 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:52:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:52:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:52:33 --> Helper loaded: form_helper
INFO - 2018-03-28 15:52:33 --> Form Validation Class Initialized
INFO - 2018-03-28 15:52:33 --> Controller Class Initialized
INFO - 2018-03-28 15:52:33 --> Model Class Initialized
INFO - 2018-03-28 15:52:33 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:52:33 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:52:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:52:33 --> Model Class Initialized
INFO - 2018-03-28 15:52:33 --> Model Class Initialized
INFO - 2018-03-28 15:52:33 --> Model Class Initialized
INFO - 2018-03-28 15:52:33 --> Model Class Initialized
INFO - 2018-03-28 15:52:33 --> Model Class Initialized
INFO - 2018-03-28 15:52:33 --> Model Class Initialized
INFO - 2018-03-28 15:52:33 --> Model Class Initialized
INFO - 2018-03-28 15:52:33 --> Model Class Initialized
INFO - 2018-03-28 15:52:33 --> Model Class Initialized
INFO - 2018-03-28 15:52:33 --> Model Class Initialized
INFO - 2018-03-28 15:52:34 --> Model Class Initialized
INFO - 2018-03-28 15:52:34 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:52:34 --> Model Class Initialized
INFO - 2018-03-28 15:52:34 --> Final output sent to browser
DEBUG - 2018-03-28 15:52:34 --> Total execution time: 4.6088
INFO - 2018-03-28 10:23:49 --> Config Class Initialized
INFO - 2018-03-28 10:23:49 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:23:49 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:23:49 --> Utf8 Class Initialized
INFO - 2018-03-28 10:23:49 --> URI Class Initialized
INFO - 2018-03-28 10:23:49 --> Router Class Initialized
INFO - 2018-03-28 10:23:49 --> Output Class Initialized
INFO - 2018-03-28 10:23:49 --> Security Class Initialized
DEBUG - 2018-03-28 10:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:23:49 --> Input Class Initialized
INFO - 2018-03-28 10:23:49 --> Language Class Initialized
INFO - 2018-03-28 10:23:50 --> Language Class Initialized
INFO - 2018-03-28 10:23:50 --> Config Class Initialized
INFO - 2018-03-28 10:23:50 --> Loader Class Initialized
INFO - 2018-03-28 15:53:50 --> Helper loaded: url_helper
INFO - 2018-03-28 15:53:51 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:53:51 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:53:51 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:53:51 --> Helper loaded: users_helper
INFO - 2018-03-28 15:53:51 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:53:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:53:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:53:51 --> Helper loaded: form_helper
INFO - 2018-03-28 15:53:51 --> Form Validation Class Initialized
INFO - 2018-03-28 15:53:51 --> Controller Class Initialized
INFO - 2018-03-28 15:53:52 --> Model Class Initialized
INFO - 2018-03-28 15:53:52 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:53:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:53:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:53:52 --> Model Class Initialized
INFO - 2018-03-28 15:53:52 --> Model Class Initialized
INFO - 2018-03-28 15:53:52 --> Model Class Initialized
INFO - 2018-03-28 15:53:52 --> Model Class Initialized
INFO - 2018-03-28 15:53:52 --> Model Class Initialized
INFO - 2018-03-28 15:53:52 --> Model Class Initialized
INFO - 2018-03-28 15:53:52 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:53:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-28 15:53:52 --> Final output sent to browser
DEBUG - 2018-03-28 15:53:52 --> Total execution time: 2.9412
INFO - 2018-03-28 10:23:53 --> Config Class Initialized
INFO - 2018-03-28 10:23:53 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:23:53 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:23:53 --> Utf8 Class Initialized
INFO - 2018-03-28 10:23:53 --> URI Class Initialized
INFO - 2018-03-28 10:23:53 --> Router Class Initialized
INFO - 2018-03-28 10:23:53 --> Output Class Initialized
INFO - 2018-03-28 10:23:53 --> Security Class Initialized
DEBUG - 2018-03-28 10:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:23:53 --> Input Class Initialized
INFO - 2018-03-28 10:23:53 --> Language Class Initialized
INFO - 2018-03-28 10:23:53 --> Language Class Initialized
INFO - 2018-03-28 10:23:53 --> Config Class Initialized
INFO - 2018-03-28 10:23:53 --> Loader Class Initialized
INFO - 2018-03-28 15:53:53 --> Helper loaded: url_helper
INFO - 2018-03-28 15:53:53 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:53:53 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:53:53 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:53:53 --> Helper loaded: users_helper
INFO - 2018-03-28 15:53:53 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:53:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:53:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:53:53 --> Helper loaded: form_helper
INFO - 2018-03-28 15:53:53 --> Form Validation Class Initialized
INFO - 2018-03-28 15:53:53 --> Controller Class Initialized
INFO - 2018-03-28 15:53:53 --> Model Class Initialized
INFO - 2018-03-28 15:53:53 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:53:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:53:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:53:53 --> Model Class Initialized
INFO - 2018-03-28 15:53:53 --> Model Class Initialized
INFO - 2018-03-28 15:53:53 --> Model Class Initialized
INFO - 2018-03-28 15:53:53 --> Model Class Initialized
INFO - 2018-03-28 15:53:53 --> Model Class Initialized
INFO - 2018-03-28 15:53:53 --> Model Class Initialized
INFO - 2018-03-28 15:53:53 --> Model Class Initialized
INFO - 2018-03-28 15:53:53 --> Model Class Initialized
INFO - 2018-03-28 15:53:53 --> Model Class Initialized
INFO - 2018-03-28 15:53:53 --> Model Class Initialized
INFO - 2018-03-28 15:53:53 --> Model Class Initialized
INFO - 2018-03-28 15:53:53 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:53:53 --> Model Class Initialized
INFO - 2018-03-28 15:53:53 --> Final output sent to browser
DEBUG - 2018-03-28 15:53:53 --> Total execution time: 0.2369
INFO - 2018-03-28 10:23:54 --> Config Class Initialized
INFO - 2018-03-28 10:23:54 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:23:54 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:23:54 --> Utf8 Class Initialized
INFO - 2018-03-28 10:23:55 --> URI Class Initialized
INFO - 2018-03-28 10:23:55 --> Router Class Initialized
INFO - 2018-03-28 10:23:55 --> Output Class Initialized
INFO - 2018-03-28 10:23:55 --> Config Class Initialized
INFO - 2018-03-28 10:23:55 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:23:55 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:23:55 --> Utf8 Class Initialized
INFO - 2018-03-28 10:23:55 --> URI Class Initialized
INFO - 2018-03-28 10:23:55 --> Router Class Initialized
INFO - 2018-03-28 10:23:55 --> Output Class Initialized
INFO - 2018-03-28 10:23:55 --> Security Class Initialized
DEBUG - 2018-03-28 10:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:23:55 --> Input Class Initialized
INFO - 2018-03-28 10:23:55 --> Language Class Initialized
INFO - 2018-03-28 10:23:55 --> Security Class Initialized
INFO - 2018-03-28 10:23:55 --> Language Class Initialized
INFO - 2018-03-28 10:23:55 --> Config Class Initialized
INFO - 2018-03-28 10:23:55 --> Loader Class Initialized
INFO - 2018-03-28 15:53:55 --> Helper loaded: url_helper
INFO - 2018-03-28 15:53:55 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:53:55 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:53:55 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:53:55 --> Helper loaded: users_helper
INFO - 2018-03-28 15:53:55 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:53:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:53:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-03-28 10:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:23:55 --> Input Class Initialized
INFO - 2018-03-28 15:53:55 --> Helper loaded: form_helper
INFO - 2018-03-28 15:53:55 --> Form Validation Class Initialized
INFO - 2018-03-28 15:53:55 --> Controller Class Initialized
INFO - 2018-03-28 10:23:55 --> Language Class Initialized
INFO - 2018-03-28 15:53:55 --> Model Class Initialized
INFO - 2018-03-28 15:53:55 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:53:55 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:53:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:53:55 --> Model Class Initialized
INFO - 2018-03-28 15:53:55 --> Model Class Initialized
INFO - 2018-03-28 15:53:55 --> Model Class Initialized
INFO - 2018-03-28 15:53:55 --> Model Class Initialized
INFO - 2018-03-28 15:53:55 --> Model Class Initialized
INFO - 2018-03-28 15:53:55 --> Model Class Initialized
INFO - 2018-03-28 15:53:55 --> Model Class Initialized
INFO - 2018-03-28 15:53:55 --> Model Class Initialized
INFO - 2018-03-28 15:53:55 --> Model Class Initialized
INFO - 2018-03-28 15:53:55 --> Model Class Initialized
INFO - 2018-03-28 15:53:55 --> Model Class Initialized
INFO - 2018-03-28 15:53:55 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:53:55 --> Model Class Initialized
INFO - 2018-03-28 15:53:55 --> Final output sent to browser
DEBUG - 2018-03-28 15:53:55 --> Total execution time: 0.4254
INFO - 2018-03-28 10:23:56 --> Language Class Initialized
INFO - 2018-03-28 10:23:56 --> Config Class Initialized
INFO - 2018-03-28 10:23:56 --> Loader Class Initialized
INFO - 2018-03-28 15:53:56 --> Helper loaded: url_helper
INFO - 2018-03-28 15:53:56 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:53:56 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:53:56 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:53:56 --> Helper loaded: users_helper
INFO - 2018-03-28 15:53:57 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:53:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:53:57 --> Helper loaded: form_helper
INFO - 2018-03-28 15:53:57 --> Form Validation Class Initialized
INFO - 2018-03-28 15:53:57 --> Controller Class Initialized
INFO - 2018-03-28 15:53:58 --> Model Class Initialized
INFO - 2018-03-28 15:53:58 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:53:58 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:53:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:53:58 --> Model Class Initialized
INFO - 2018-03-28 15:53:58 --> Model Class Initialized
INFO - 2018-03-28 15:53:58 --> Model Class Initialized
INFO - 2018-03-28 15:53:58 --> Model Class Initialized
INFO - 2018-03-28 15:53:58 --> Model Class Initialized
INFO - 2018-03-28 15:53:58 --> Model Class Initialized
INFO - 2018-03-28 15:53:58 --> Model Class Initialized
INFO - 2018-03-28 15:53:58 --> Model Class Initialized
INFO - 2018-03-28 15:53:58 --> Model Class Initialized
INFO - 2018-03-28 15:53:58 --> Model Class Initialized
INFO - 2018-03-28 15:53:58 --> Model Class Initialized
INFO - 2018-03-28 15:53:58 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:53:58 --> Model Class Initialized
INFO - 2018-03-28 15:53:58 --> Final output sent to browser
DEBUG - 2018-03-28 15:53:58 --> Total execution time: 3.9489
INFO - 2018-03-28 10:23:59 --> Config Class Initialized
INFO - 2018-03-28 10:23:59 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:23:59 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:23:59 --> Utf8 Class Initialized
INFO - 2018-03-28 10:23:59 --> URI Class Initialized
INFO - 2018-03-28 10:23:59 --> Router Class Initialized
INFO - 2018-03-28 10:23:59 --> Output Class Initialized
INFO - 2018-03-28 10:23:59 --> Security Class Initialized
DEBUG - 2018-03-28 10:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:23:59 --> Input Class Initialized
INFO - 2018-03-28 10:23:59 --> Language Class Initialized
INFO - 2018-03-28 10:23:59 --> Language Class Initialized
INFO - 2018-03-28 10:23:59 --> Config Class Initialized
INFO - 2018-03-28 10:23:59 --> Loader Class Initialized
INFO - 2018-03-28 15:53:59 --> Helper loaded: url_helper
INFO - 2018-03-28 15:53:59 --> Helper loaded: notification_helper
INFO - 2018-03-28 10:23:59 --> Config Class Initialized
INFO - 2018-03-28 10:23:59 --> Hooks Class Initialized
INFO - 2018-03-28 15:53:59 --> Helper loaded: settings_helper
DEBUG - 2018-03-28 10:23:59 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:23:59 --> Utf8 Class Initialized
INFO - 2018-03-28 10:23:59 --> URI Class Initialized
INFO - 2018-03-28 15:53:59 --> Helper loaded: permission_helper
INFO - 2018-03-28 10:23:59 --> Router Class Initialized
INFO - 2018-03-28 10:23:59 --> Output Class Initialized
INFO - 2018-03-28 10:23:59 --> Security Class Initialized
INFO - 2018-03-28 15:53:59 --> Helper loaded: users_helper
DEBUG - 2018-03-28 10:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:23:59 --> Input Class Initialized
INFO - 2018-03-28 10:23:59 --> Language Class Initialized
INFO - 2018-03-28 10:23:59 --> Language Class Initialized
INFO - 2018-03-28 10:23:59 --> Config Class Initialized
INFO - 2018-03-28 10:23:59 --> Loader Class Initialized
INFO - 2018-03-28 15:53:59 --> Helper loaded: url_helper
INFO - 2018-03-28 15:53:59 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:53:59 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:53:59 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:53:59 --> Helper loaded: users_helper
INFO - 2018-03-28 15:53:59 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:53:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:53:59 --> Helper loaded: form_helper
INFO - 2018-03-28 15:53:59 --> Form Validation Class Initialized
INFO - 2018-03-28 15:53:59 --> Controller Class Initialized
INFO - 2018-03-28 15:53:59 --> Model Class Initialized
INFO - 2018-03-28 15:53:59 --> Helper loaded: inflector_helper
INFO - 2018-03-28 15:53:59 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:53:59 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:53:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:53:59 --> Model Class Initialized
INFO - 2018-03-28 15:53:59 --> Model Class Initialized
INFO - 2018-03-28 15:53:59 --> Model Class Initialized
INFO - 2018-03-28 15:53:59 --> Model Class Initialized
INFO - 2018-03-28 15:53:59 --> Model Class Initialized
INFO - 2018-03-28 15:53:59 --> Model Class Initialized
INFO - 2018-03-28 15:53:59 --> Model Class Initialized
INFO - 2018-03-28 15:53:59 --> Model Class Initialized
INFO - 2018-03-28 15:53:59 --> Model Class Initialized
INFO - 2018-03-28 15:53:59 --> Model Class Initialized
INFO - 2018-03-28 15:53:59 --> Model Class Initialized
INFO - 2018-03-28 15:53:59 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:53:59 --> Final output sent to browser
DEBUG - 2018-03-28 15:53:59 --> Total execution time: 0.1267
DEBUG - 2018-03-28 15:53:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:54:00 --> Helper loaded: form_helper
INFO - 2018-03-28 15:54:00 --> Form Validation Class Initialized
INFO - 2018-03-28 15:54:00 --> Controller Class Initialized
INFO - 2018-03-28 15:54:00 --> Model Class Initialized
INFO - 2018-03-28 15:54:00 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:54:00 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:54:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:54:00 --> Model Class Initialized
INFO - 2018-03-28 15:54:00 --> Model Class Initialized
INFO - 2018-03-28 15:54:01 --> Model Class Initialized
INFO - 2018-03-28 15:54:01 --> Model Class Initialized
INFO - 2018-03-28 15:54:01 --> Model Class Initialized
INFO - 2018-03-28 15:54:01 --> Model Class Initialized
INFO - 2018-03-28 15:54:01 --> Model Class Initialized
INFO - 2018-03-28 15:54:01 --> Model Class Initialized
INFO - 2018-03-28 15:54:01 --> Model Class Initialized
INFO - 2018-03-28 15:54:01 --> Model Class Initialized
INFO - 2018-03-28 15:54:01 --> Model Class Initialized
INFO - 2018-03-28 15:54:01 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:54:01 --> Model Class Initialized
INFO - 2018-03-28 15:54:01 --> Final output sent to browser
DEBUG - 2018-03-28 15:54:01 --> Total execution time: 1.9815
INFO - 2018-03-28 10:24:05 --> Config Class Initialized
INFO - 2018-03-28 10:24:05 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:24:05 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:24:05 --> Utf8 Class Initialized
INFO - 2018-03-28 10:24:05 --> URI Class Initialized
INFO - 2018-03-28 10:24:05 --> Router Class Initialized
INFO - 2018-03-28 10:24:05 --> Output Class Initialized
INFO - 2018-03-28 10:24:05 --> Security Class Initialized
DEBUG - 2018-03-28 10:24:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:24:05 --> Input Class Initialized
INFO - 2018-03-28 10:24:05 --> Language Class Initialized
INFO - 2018-03-28 10:24:05 --> Language Class Initialized
INFO - 2018-03-28 10:24:05 --> Config Class Initialized
INFO - 2018-03-28 10:24:05 --> Loader Class Initialized
INFO - 2018-03-28 15:54:06 --> Helper loaded: url_helper
INFO - 2018-03-28 15:54:06 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:54:06 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:54:06 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:54:06 --> Helper loaded: users_helper
INFO - 2018-03-28 15:54:06 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:54:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:54:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:54:06 --> Helper loaded: form_helper
INFO - 2018-03-28 15:54:06 --> Form Validation Class Initialized
INFO - 2018-03-28 15:54:06 --> Controller Class Initialized
INFO - 2018-03-28 15:54:06 --> Model Class Initialized
INFO - 2018-03-28 15:54:06 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:54:06 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:54:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:54:06 --> Model Class Initialized
INFO - 2018-03-28 15:54:06 --> Model Class Initialized
INFO - 2018-03-28 15:54:06 --> Model Class Initialized
INFO - 2018-03-28 15:54:06 --> Model Class Initialized
INFO - 2018-03-28 15:54:06 --> Model Class Initialized
INFO - 2018-03-28 15:54:06 --> Model Class Initialized
INFO - 2018-03-28 15:54:06 --> Model Class Initialized
INFO - 2018-03-28 15:54:06 --> Model Class Initialized
INFO - 2018-03-28 15:54:06 --> Model Class Initialized
INFO - 2018-03-28 15:54:06 --> Model Class Initialized
INFO - 2018-03-28 15:54:06 --> Model Class Initialized
INFO - 2018-03-28 15:54:06 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:54:06 --> Model Class Initialized
INFO - 2018-03-28 15:54:06 --> Final output sent to browser
DEBUG - 2018-03-28 15:54:06 --> Total execution time: 1.4672
INFO - 2018-03-28 10:24:22 --> Config Class Initialized
INFO - 2018-03-28 10:24:22 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:24:22 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:24:22 --> Utf8 Class Initialized
INFO - 2018-03-28 10:24:22 --> URI Class Initialized
INFO - 2018-03-28 10:24:22 --> Router Class Initialized
INFO - 2018-03-28 10:24:22 --> Output Class Initialized
INFO - 2018-03-28 10:24:22 --> Security Class Initialized
DEBUG - 2018-03-28 10:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:24:22 --> Input Class Initialized
INFO - 2018-03-28 10:24:22 --> Language Class Initialized
INFO - 2018-03-28 10:24:22 --> Language Class Initialized
INFO - 2018-03-28 10:24:22 --> Config Class Initialized
INFO - 2018-03-28 10:24:22 --> Loader Class Initialized
INFO - 2018-03-28 15:54:22 --> Helper loaded: url_helper
INFO - 2018-03-28 15:54:22 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:54:22 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:54:22 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:54:22 --> Helper loaded: users_helper
INFO - 2018-03-28 15:54:22 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:54:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:54:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:54:22 --> Helper loaded: form_helper
INFO - 2018-03-28 15:54:22 --> Form Validation Class Initialized
INFO - 2018-03-28 15:54:22 --> Controller Class Initialized
INFO - 2018-03-28 15:54:22 --> Model Class Initialized
INFO - 2018-03-28 15:54:22 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:54:22 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:54:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:54:22 --> Model Class Initialized
INFO - 2018-03-28 15:54:22 --> Model Class Initialized
INFO - 2018-03-28 15:54:22 --> Model Class Initialized
INFO - 2018-03-28 15:54:22 --> Model Class Initialized
INFO - 2018-03-28 15:54:22 --> Model Class Initialized
INFO - 2018-03-28 15:54:22 --> Model Class Initialized
INFO - 2018-03-28 15:54:22 --> Model Class Initialized
INFO - 2018-03-28 15:54:22 --> Model Class Initialized
INFO - 2018-03-28 15:54:22 --> Model Class Initialized
INFO - 2018-03-28 15:54:22 --> Model Class Initialized
INFO - 2018-03-28 15:54:22 --> Model Class Initialized
INFO - 2018-03-28 15:54:22 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:54:22 --> Final output sent to browser
DEBUG - 2018-03-28 15:54:22 --> Total execution time: 0.1134
INFO - 2018-03-28 10:24:26 --> Config Class Initialized
INFO - 2018-03-28 10:24:26 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:24:26 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:24:26 --> Utf8 Class Initialized
INFO - 2018-03-28 10:24:26 --> URI Class Initialized
INFO - 2018-03-28 10:24:26 --> Router Class Initialized
INFO - 2018-03-28 10:24:26 --> Output Class Initialized
INFO - 2018-03-28 10:24:26 --> Security Class Initialized
DEBUG - 2018-03-28 10:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:24:26 --> Input Class Initialized
INFO - 2018-03-28 10:24:26 --> Language Class Initialized
INFO - 2018-03-28 10:24:26 --> Language Class Initialized
INFO - 2018-03-28 10:24:26 --> Config Class Initialized
INFO - 2018-03-28 10:24:26 --> Loader Class Initialized
INFO - 2018-03-28 15:54:26 --> Helper loaded: url_helper
INFO - 2018-03-28 15:54:26 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:54:26 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:54:26 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:54:26 --> Helper loaded: users_helper
INFO - 2018-03-28 15:54:26 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:54:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:54:26 --> Helper loaded: form_helper
INFO - 2018-03-28 15:54:26 --> Form Validation Class Initialized
INFO - 2018-03-28 15:54:26 --> Controller Class Initialized
INFO - 2018-03-28 15:54:26 --> Model Class Initialized
INFO - 2018-03-28 15:54:26 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:54:26 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:54:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:54:26 --> Model Class Initialized
INFO - 2018-03-28 15:54:26 --> Model Class Initialized
INFO - 2018-03-28 15:54:26 --> Model Class Initialized
INFO - 2018-03-28 15:54:26 --> Model Class Initialized
INFO - 2018-03-28 15:54:26 --> Model Class Initialized
INFO - 2018-03-28 15:54:26 --> Model Class Initialized
INFO - 2018-03-28 15:54:26 --> Model Class Initialized
INFO - 2018-03-28 15:54:26 --> Model Class Initialized
INFO - 2018-03-28 15:54:26 --> Model Class Initialized
INFO - 2018-03-28 15:54:26 --> Model Class Initialized
INFO - 2018-03-28 15:54:26 --> Model Class Initialized
INFO - 2018-03-28 15:54:26 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:54:26 --> Model Class Initialized
INFO - 2018-03-28 15:54:26 --> Final output sent to browser
DEBUG - 2018-03-28 15:54:26 --> Total execution time: 0.4563
INFO - 2018-03-28 10:24:28 --> Config Class Initialized
INFO - 2018-03-28 10:24:28 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:24:28 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:24:28 --> Utf8 Class Initialized
INFO - 2018-03-28 10:24:28 --> URI Class Initialized
INFO - 2018-03-28 10:24:28 --> Router Class Initialized
INFO - 2018-03-28 10:24:28 --> Output Class Initialized
INFO - 2018-03-28 10:24:28 --> Security Class Initialized
DEBUG - 2018-03-28 10:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:24:28 --> Input Class Initialized
INFO - 2018-03-28 10:24:28 --> Language Class Initialized
INFO - 2018-03-28 10:24:28 --> Language Class Initialized
INFO - 2018-03-28 10:24:28 --> Config Class Initialized
INFO - 2018-03-28 10:24:28 --> Loader Class Initialized
INFO - 2018-03-28 15:54:28 --> Helper loaded: url_helper
INFO - 2018-03-28 15:54:28 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:54:28 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:54:28 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:54:28 --> Helper loaded: users_helper
INFO - 2018-03-28 15:54:28 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:54:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:54:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:54:28 --> Helper loaded: form_helper
INFO - 2018-03-28 15:54:28 --> Form Validation Class Initialized
INFO - 2018-03-28 15:54:28 --> Controller Class Initialized
INFO - 2018-03-28 15:54:28 --> Model Class Initialized
INFO - 2018-03-28 15:54:28 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:54:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:54:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:54:28 --> Model Class Initialized
INFO - 2018-03-28 15:54:28 --> Model Class Initialized
INFO - 2018-03-28 15:54:28 --> Model Class Initialized
INFO - 2018-03-28 15:54:28 --> Model Class Initialized
INFO - 2018-03-28 15:54:28 --> Model Class Initialized
INFO - 2018-03-28 15:54:28 --> Model Class Initialized
INFO - 2018-03-28 15:54:28 --> Model Class Initialized
INFO - 2018-03-28 15:54:28 --> Model Class Initialized
INFO - 2018-03-28 15:54:28 --> Model Class Initialized
INFO - 2018-03-28 15:54:28 --> Model Class Initialized
INFO - 2018-03-28 15:54:28 --> Model Class Initialized
INFO - 2018-03-28 15:54:28 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:54:28 --> Model Class Initialized
INFO - 2018-03-28 15:54:28 --> Final output sent to browser
DEBUG - 2018-03-28 15:54:28 --> Total execution time: 0.2368
INFO - 2018-03-28 10:24:31 --> Config Class Initialized
INFO - 2018-03-28 10:24:31 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:24:31 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:24:31 --> Utf8 Class Initialized
INFO - 2018-03-28 10:24:31 --> URI Class Initialized
INFO - 2018-03-28 10:24:31 --> Router Class Initialized
INFO - 2018-03-28 10:24:31 --> Output Class Initialized
INFO - 2018-03-28 10:24:31 --> Security Class Initialized
DEBUG - 2018-03-28 10:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:24:31 --> Input Class Initialized
INFO - 2018-03-28 10:24:31 --> Language Class Initialized
INFO - 2018-03-28 10:24:32 --> Language Class Initialized
INFO - 2018-03-28 10:24:32 --> Config Class Initialized
INFO - 2018-03-28 10:24:32 --> Loader Class Initialized
INFO - 2018-03-28 15:54:33 --> Helper loaded: url_helper
INFO - 2018-03-28 15:54:33 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:54:33 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:54:33 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:54:33 --> Helper loaded: users_helper
INFO - 2018-03-28 15:54:34 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:54:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:54:34 --> Helper loaded: form_helper
INFO - 2018-03-28 15:54:34 --> Form Validation Class Initialized
INFO - 2018-03-28 15:54:34 --> Controller Class Initialized
INFO - 2018-03-28 15:54:34 --> Model Class Initialized
INFO - 2018-03-28 15:54:34 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:54:34 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:54:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:54:34 --> Model Class Initialized
INFO - 2018-03-28 15:54:34 --> Model Class Initialized
INFO - 2018-03-28 15:54:34 --> Model Class Initialized
INFO - 2018-03-28 15:54:34 --> Model Class Initialized
INFO - 2018-03-28 15:54:34 --> Model Class Initialized
INFO - 2018-03-28 15:54:34 --> Model Class Initialized
INFO - 2018-03-28 15:54:34 --> Model Class Initialized
INFO - 2018-03-28 15:54:34 --> Model Class Initialized
INFO - 2018-03-28 15:54:34 --> Model Class Initialized
INFO - 2018-03-28 15:54:34 --> Model Class Initialized
INFO - 2018-03-28 15:54:34 --> Model Class Initialized
INFO - 2018-03-28 15:54:34 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:54:34 --> Final output sent to browser
DEBUG - 2018-03-28 15:54:34 --> Total execution time: 3.3928
INFO - 2018-03-28 10:24:34 --> Config Class Initialized
INFO - 2018-03-28 10:24:34 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:24:34 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:24:34 --> Utf8 Class Initialized
INFO - 2018-03-28 10:24:34 --> URI Class Initialized
INFO - 2018-03-28 10:24:34 --> Router Class Initialized
INFO - 2018-03-28 10:24:34 --> Output Class Initialized
INFO - 2018-03-28 10:24:35 --> Security Class Initialized
DEBUG - 2018-03-28 10:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:24:35 --> Input Class Initialized
INFO - 2018-03-28 10:24:35 --> Language Class Initialized
INFO - 2018-03-28 10:24:35 --> Language Class Initialized
INFO - 2018-03-28 10:24:35 --> Config Class Initialized
INFO - 2018-03-28 10:24:35 --> Loader Class Initialized
INFO - 2018-03-28 15:54:35 --> Helper loaded: url_helper
INFO - 2018-03-28 15:54:35 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:54:35 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:54:35 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:54:35 --> Helper loaded: users_helper
INFO - 2018-03-28 15:54:36 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:54:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:54:36 --> Helper loaded: form_helper
INFO - 2018-03-28 15:54:36 --> Form Validation Class Initialized
INFO - 2018-03-28 15:54:36 --> Controller Class Initialized
INFO - 2018-03-28 15:54:36 --> Model Class Initialized
INFO - 2018-03-28 15:54:36 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:54:36 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:54:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:54:37 --> Model Class Initialized
INFO - 2018-03-28 15:54:37 --> Model Class Initialized
INFO - 2018-03-28 15:54:37 --> Model Class Initialized
INFO - 2018-03-28 15:54:37 --> Model Class Initialized
INFO - 2018-03-28 15:54:37 --> Model Class Initialized
INFO - 2018-03-28 15:54:37 --> Model Class Initialized
INFO - 2018-03-28 15:54:37 --> Model Class Initialized
INFO - 2018-03-28 15:54:37 --> Model Class Initialized
INFO - 2018-03-28 15:54:37 --> Model Class Initialized
INFO - 2018-03-28 15:54:37 --> Model Class Initialized
INFO - 2018-03-28 15:54:37 --> Model Class Initialized
INFO - 2018-03-28 15:54:37 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:54:37 --> Final output sent to browser
DEBUG - 2018-03-28 15:54:37 --> Total execution time: 3.1286
INFO - 2018-03-28 10:25:15 --> Config Class Initialized
INFO - 2018-03-28 10:25:15 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:25:15 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:25:15 --> Utf8 Class Initialized
INFO - 2018-03-28 10:25:15 --> URI Class Initialized
INFO - 2018-03-28 10:25:16 --> Router Class Initialized
INFO - 2018-03-28 10:25:16 --> Output Class Initialized
INFO - 2018-03-28 10:25:16 --> Security Class Initialized
DEBUG - 2018-03-28 10:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:25:16 --> Input Class Initialized
INFO - 2018-03-28 10:25:17 --> Language Class Initialized
INFO - 2018-03-28 10:25:18 --> Language Class Initialized
INFO - 2018-03-28 10:25:18 --> Config Class Initialized
INFO - 2018-03-28 10:25:18 --> Loader Class Initialized
INFO - 2018-03-28 15:55:18 --> Helper loaded: url_helper
INFO - 2018-03-28 15:55:18 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:55:18 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:55:18 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:55:18 --> Helper loaded: users_helper
INFO - 2018-03-28 10:25:19 --> Config Class Initialized
INFO - 2018-03-28 10:25:19 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:25:19 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:25:19 --> Utf8 Class Initialized
INFO - 2018-03-28 10:25:19 --> URI Class Initialized
INFO - 2018-03-28 10:25:19 --> Router Class Initialized
INFO - 2018-03-28 10:25:19 --> Output Class Initialized
INFO - 2018-03-28 10:25:19 --> Security Class Initialized
DEBUG - 2018-03-28 10:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:25:19 --> Input Class Initialized
INFO - 2018-03-28 10:25:19 --> Language Class Initialized
INFO - 2018-03-28 10:25:19 --> Language Class Initialized
INFO - 2018-03-28 10:25:19 --> Config Class Initialized
INFO - 2018-03-28 10:25:19 --> Loader Class Initialized
INFO - 2018-03-28 15:55:19 --> Helper loaded: url_helper
INFO - 2018-03-28 15:55:19 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:55:19 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:55:19 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:55:19 --> Helper loaded: users_helper
INFO - 2018-03-28 15:55:19 --> Database Driver Class Initialized
INFO - 2018-03-28 15:55:19 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:55:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:55:19 --> Helper loaded: form_helper
INFO - 2018-03-28 15:55:19 --> Form Validation Class Initialized
INFO - 2018-03-28 15:55:19 --> Controller Class Initialized
INFO - 2018-03-28 15:55:19 --> Model Class Initialized
INFO - 2018-03-28 15:55:19 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:55:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:55:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:55:19 --> Model Class Initialized
INFO - 2018-03-28 15:55:19 --> Model Class Initialized
INFO - 2018-03-28 15:55:19 --> Model Class Initialized
INFO - 2018-03-28 15:55:19 --> Model Class Initialized
INFO - 2018-03-28 15:55:19 --> Model Class Initialized
INFO - 2018-03-28 15:55:19 --> Model Class Initialized
INFO - 2018-03-28 15:55:19 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-28 15:55:19 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-28 15:55:19 --> Final output sent to browser
DEBUG - 2018-03-28 15:55:19 --> Total execution time: 0.5647
DEBUG - 2018-03-28 15:55:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:55:20 --> Helper loaded: form_helper
INFO - 2018-03-28 15:55:20 --> Form Validation Class Initialized
INFO - 2018-03-28 15:55:20 --> Controller Class Initialized
INFO - 2018-03-28 15:55:20 --> Model Class Initialized
INFO - 2018-03-28 15:55:20 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:55:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:55:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:55:20 --> Model Class Initialized
INFO - 2018-03-28 15:55:20 --> Model Class Initialized
INFO - 2018-03-28 15:55:20 --> Model Class Initialized
INFO - 2018-03-28 15:55:20 --> Model Class Initialized
INFO - 2018-03-28 15:55:20 --> Model Class Initialized
INFO - 2018-03-28 15:55:20 --> Model Class Initialized
INFO - 2018-03-28 15:55:20 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-28 15:55:20 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-28 15:55:20 --> Final output sent to browser
DEBUG - 2018-03-28 15:55:20 --> Total execution time: 5.1674
INFO - 2018-03-28 10:27:04 --> Config Class Initialized
INFO - 2018-03-28 10:27:04 --> Hooks Class Initialized
INFO - 2018-03-28 10:27:04 --> Config Class Initialized
INFO - 2018-03-28 10:27:04 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:27:04 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:27:04 --> Utf8 Class Initialized
DEBUG - 2018-03-28 10:27:04 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:27:04 --> Utf8 Class Initialized
INFO - 2018-03-28 10:27:04 --> URI Class Initialized
INFO - 2018-03-28 10:27:04 --> URI Class Initialized
INFO - 2018-03-28 10:27:04 --> Config Class Initialized
INFO - 2018-03-28 10:27:04 --> Hooks Class Initialized
INFO - 2018-03-28 10:27:04 --> Router Class Initialized
INFO - 2018-03-28 10:27:04 --> Router Class Initialized
DEBUG - 2018-03-28 10:27:04 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:27:04 --> Utf8 Class Initialized
INFO - 2018-03-28 10:27:04 --> Output Class Initialized
INFO - 2018-03-28 10:27:04 --> Output Class Initialized
INFO - 2018-03-28 10:27:04 --> URI Class Initialized
INFO - 2018-03-28 10:27:04 --> Router Class Initialized
INFO - 2018-03-28 10:27:04 --> Security Class Initialized
INFO - 2018-03-28 10:27:04 --> Security Class Initialized
INFO - 2018-03-28 10:27:04 --> Output Class Initialized
INFO - 2018-03-28 10:27:04 --> Security Class Initialized
DEBUG - 2018-03-28 10:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:27:04 --> Input Class Initialized
INFO - 2018-03-28 10:27:04 --> Language Class Initialized
DEBUG - 2018-03-28 10:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:27:04 --> Input Class Initialized
DEBUG - 2018-03-28 10:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:27:04 --> Input Class Initialized
INFO - 2018-03-28 10:27:04 --> Language Class Initialized
INFO - 2018-03-28 10:27:04 --> Language Class Initialized
INFO - 2018-03-28 10:27:04 --> Language Class Initialized
INFO - 2018-03-28 10:27:04 --> Config Class Initialized
INFO - 2018-03-28 10:27:04 --> Loader Class Initialized
INFO - 2018-03-28 15:57:04 --> Helper loaded: url_helper
INFO - 2018-03-28 15:57:04 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:57:04 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:57:04 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:57:04 --> Helper loaded: users_helper
INFO - 2018-03-28 15:57:04 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:57:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:57:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:57:04 --> Helper loaded: form_helper
INFO - 2018-03-28 15:57:04 --> Form Validation Class Initialized
INFO - 2018-03-28 15:57:04 --> Controller Class Initialized
INFO - 2018-03-28 10:27:04 --> Config Class Initialized
INFO - 2018-03-28 10:27:04 --> Hooks Class Initialized
INFO - 2018-03-28 10:27:04 --> Language Class Initialized
INFO - 2018-03-28 10:27:04 --> Config Class Initialized
INFO - 2018-03-28 10:27:04 --> Loader Class Initialized
INFO - 2018-03-28 10:27:04 --> Language Class Initialized
INFO - 2018-03-28 10:27:04 --> Config Class Initialized
INFO - 2018-03-28 10:27:04 --> Loader Class Initialized
INFO - 2018-03-28 15:57:04 --> Model Class Initialized
INFO - 2018-03-28 15:57:04 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:57:04 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:57:04 --> Helper loaded: url_helper
INFO - 2018-03-28 15:57:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:57:04 --> Helper loaded: url_helper
INFO - 2018-03-28 15:57:04 --> Model Class Initialized
INFO - 2018-03-28 15:57:04 --> Model Class Initialized
INFO - 2018-03-28 15:57:04 --> Model Class Initialized
INFO - 2018-03-28 15:57:04 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:57:04 --> Model Class Initialized
INFO - 2018-03-28 15:57:04 --> Model Class Initialized
INFO - 2018-03-28 15:57:04 --> Model Class Initialized
INFO - 2018-03-28 15:57:04 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:57:04 --> Model Class Initialized
DEBUG - 2018-03-28 10:27:04 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:27:04 --> Utf8 Class Initialized
INFO - 2018-03-28 15:57:04 --> Model Class Initialized
INFO - 2018-03-28 15:57:04 --> Model Class Initialized
INFO - 2018-03-28 15:57:04 --> Model Class Initialized
INFO - 2018-03-28 15:57:04 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:57:04 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:57:04 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:57:04 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:57:04 --> Model Class Initialized
INFO - 2018-03-28 15:57:04 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:57:04 --> Model Class Initialized
INFO - 2018-03-28 15:57:04 --> Helper loaded: users_helper
INFO - 2018-03-28 15:57:04 --> Helper loaded: users_helper
INFO - 2018-03-28 10:27:04 --> URI Class Initialized
INFO - 2018-03-28 15:57:04 --> Final output sent to browser
DEBUG - 2018-03-28 15:57:04 --> Total execution time: 0.1382
INFO - 2018-03-28 10:27:04 --> Router Class Initialized
INFO - 2018-03-28 15:57:04 --> Database Driver Class Initialized
INFO - 2018-03-28 15:57:04 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:57:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:57:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-03-28 15:57:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:57:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 10:27:04 --> Output Class Initialized
INFO - 2018-03-28 15:57:04 --> Helper loaded: form_helper
INFO - 2018-03-28 15:57:04 --> Helper loaded: form_helper
INFO - 2018-03-28 15:57:04 --> Form Validation Class Initialized
INFO - 2018-03-28 15:57:04 --> Form Validation Class Initialized
INFO - 2018-03-28 15:57:04 --> Controller Class Initialized
INFO - 2018-03-28 15:57:04 --> Controller Class Initialized
INFO - 2018-03-28 15:57:04 --> Model Class Initialized
INFO - 2018-03-28 15:57:04 --> Model Class Initialized
INFO - 2018-03-28 15:57:04 --> Helper loaded: inflector_helper
INFO - 2018-03-28 15:57:04 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:57:04 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-03-28 15:57:04 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:57:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:57:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:57:04 --> Model Class Initialized
INFO - 2018-03-28 15:57:04 --> Model Class Initialized
INFO - 2018-03-28 15:57:04 --> Model Class Initialized
INFO - 2018-03-28 15:57:04 --> Model Class Initialized
INFO - 2018-03-28 15:57:04 --> Model Class Initialized
INFO - 2018-03-28 15:57:04 --> Model Class Initialized
INFO - 2018-03-28 15:57:04 --> Model Class Initialized
INFO - 2018-03-28 15:57:04 --> Model Class Initialized
INFO - 2018-03-28 15:57:04 --> Model Class Initialized
INFO - 2018-03-28 15:57:04 --> Model Class Initialized
INFO - 2018-03-28 15:57:04 --> Model Class Initialized
INFO - 2018-03-28 15:57:04 --> Model Class Initialized
INFO - 2018-03-28 15:57:04 --> Model Class Initialized
INFO - 2018-03-28 15:57:04 --> Model Class Initialized
INFO - 2018-03-28 15:57:04 --> Model Class Initialized
INFO - 2018-03-28 15:57:04 --> Model Class Initialized
INFO - 2018-03-28 15:57:04 --> Model Class Initialized
INFO - 2018-03-28 15:57:04 --> Model Class Initialized
INFO - 2018-03-28 15:57:04 --> Model Class Initialized
INFO - 2018-03-28 15:57:04 --> Model Class Initialized
INFO - 2018-03-28 15:57:04 --> Model Class Initialized
INFO - 2018-03-28 15:57:04 --> Model Class Initialized
INFO - 2018-03-28 15:57:04 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:57:04 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 10:27:04 --> Security Class Initialized
INFO - 2018-03-28 15:57:04 --> Model Class Initialized
INFO - 2018-03-28 15:57:04 --> Final output sent to browser
DEBUG - 2018-03-28 15:57:04 --> Total execution time: 0.2377
INFO - 2018-03-28 15:57:04 --> Final output sent to browser
DEBUG - 2018-03-28 15:57:04 --> Total execution time: 0.2404
DEBUG - 2018-03-28 10:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:27:04 --> Input Class Initialized
INFO - 2018-03-28 10:27:04 --> Language Class Initialized
INFO - 2018-03-28 10:27:05 --> Language Class Initialized
INFO - 2018-03-28 10:27:05 --> Config Class Initialized
INFO - 2018-03-28 10:27:05 --> Loader Class Initialized
INFO - 2018-03-28 15:57:05 --> Helper loaded: url_helper
INFO - 2018-03-28 15:57:05 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:57:05 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:57:05 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:57:05 --> Helper loaded: users_helper
INFO - 2018-03-28 15:57:05 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:57:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:57:05 --> Helper loaded: form_helper
INFO - 2018-03-28 15:57:05 --> Form Validation Class Initialized
INFO - 2018-03-28 15:57:05 --> Controller Class Initialized
INFO - 2018-03-28 15:57:05 --> Model Class Initialized
INFO - 2018-03-28 15:57:05 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:57:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:57:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:57:05 --> Model Class Initialized
INFO - 2018-03-28 15:57:05 --> Model Class Initialized
INFO - 2018-03-28 15:57:05 --> Model Class Initialized
INFO - 2018-03-28 15:57:05 --> Model Class Initialized
INFO - 2018-03-28 15:57:05 --> Model Class Initialized
INFO - 2018-03-28 15:57:05 --> Model Class Initialized
INFO - 2018-03-28 15:57:05 --> Model Class Initialized
INFO - 2018-03-28 15:57:05 --> Model Class Initialized
INFO - 2018-03-28 15:57:05 --> Model Class Initialized
INFO - 2018-03-28 15:57:05 --> Model Class Initialized
INFO - 2018-03-28 15:57:05 --> Model Class Initialized
INFO - 2018-03-28 15:57:05 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:57:05 --> Model Class Initialized
INFO - 2018-03-28 15:57:05 --> Final output sent to browser
DEBUG - 2018-03-28 15:57:05 --> Total execution time: 0.3994
INFO - 2018-03-28 10:27:05 --> Config Class Initialized
INFO - 2018-03-28 10:27:05 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:27:05 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:27:05 --> Utf8 Class Initialized
INFO - 2018-03-28 10:27:05 --> URI Class Initialized
INFO - 2018-03-28 10:27:05 --> Router Class Initialized
INFO - 2018-03-28 10:27:05 --> Output Class Initialized
INFO - 2018-03-28 10:27:05 --> Security Class Initialized
DEBUG - 2018-03-28 10:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:27:05 --> Input Class Initialized
INFO - 2018-03-28 10:27:05 --> Language Class Initialized
INFO - 2018-03-28 10:27:05 --> Config Class Initialized
INFO - 2018-03-28 10:27:05 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:27:06 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:27:06 --> Utf8 Class Initialized
INFO - 2018-03-28 10:27:06 --> URI Class Initialized
INFO - 2018-03-28 10:27:06 --> Language Class Initialized
INFO - 2018-03-28 10:27:06 --> Config Class Initialized
INFO - 2018-03-28 10:27:06 --> Loader Class Initialized
INFO - 2018-03-28 10:27:06 --> Router Class Initialized
INFO - 2018-03-28 15:57:06 --> Helper loaded: url_helper
INFO - 2018-03-28 15:57:06 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:57:06 --> Helper loaded: settings_helper
INFO - 2018-03-28 10:27:06 --> Output Class Initialized
INFO - 2018-03-28 15:57:06 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:57:06 --> Helper loaded: users_helper
INFO - 2018-03-28 10:27:06 --> Security Class Initialized
DEBUG - 2018-03-28 10:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:27:06 --> Input Class Initialized
INFO - 2018-03-28 10:27:06 --> Language Class Initialized
INFO - 2018-03-28 15:57:06 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:57:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:57:06 --> Helper loaded: form_helper
INFO - 2018-03-28 15:57:06 --> Form Validation Class Initialized
INFO - 2018-03-28 15:57:06 --> Controller Class Initialized
INFO - 2018-03-28 10:27:06 --> Language Class Initialized
INFO - 2018-03-28 10:27:06 --> Config Class Initialized
INFO - 2018-03-28 10:27:06 --> Loader Class Initialized
INFO - 2018-03-28 15:57:06 --> Model Class Initialized
INFO - 2018-03-28 15:57:06 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:57:06 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:57:06 --> Helper loaded: url_helper
INFO - 2018-03-28 15:57:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:57:06 --> Model Class Initialized
INFO - 2018-03-28 15:57:06 --> Model Class Initialized
INFO - 2018-03-28 15:57:06 --> Model Class Initialized
INFO - 2018-03-28 15:57:06 --> Model Class Initialized
INFO - 2018-03-28 15:57:06 --> Model Class Initialized
INFO - 2018-03-28 15:57:06 --> Model Class Initialized
INFO - 2018-03-28 15:57:06 --> Model Class Initialized
INFO - 2018-03-28 15:57:06 --> Model Class Initialized
INFO - 2018-03-28 15:57:06 --> Model Class Initialized
INFO - 2018-03-28 15:57:06 --> Model Class Initialized
INFO - 2018-03-28 15:57:06 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:57:06 --> Model Class Initialized
INFO - 2018-03-28 15:57:06 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:57:06 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:57:06 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:57:06 --> Helper loaded: users_helper
INFO - 2018-03-28 15:57:06 --> Final output sent to browser
DEBUG - 2018-03-28 15:57:06 --> Total execution time: 1.5992
INFO - 2018-03-28 15:57:07 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:57:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:57:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:57:07 --> Helper loaded: form_helper
INFO - 2018-03-28 15:57:07 --> Form Validation Class Initialized
INFO - 2018-03-28 15:57:07 --> Controller Class Initialized
INFO - 2018-03-28 15:57:07 --> Model Class Initialized
INFO - 2018-03-28 15:57:07 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:57:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:57:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:57:07 --> Model Class Initialized
INFO - 2018-03-28 15:57:07 --> Model Class Initialized
INFO - 2018-03-28 15:57:07 --> Model Class Initialized
INFO - 2018-03-28 15:57:07 --> Model Class Initialized
INFO - 2018-03-28 15:57:07 --> Model Class Initialized
INFO - 2018-03-28 15:57:07 --> Model Class Initialized
INFO - 2018-03-28 15:57:07 --> Model Class Initialized
INFO - 2018-03-28 15:57:07 --> Model Class Initialized
INFO - 2018-03-28 15:57:07 --> Model Class Initialized
INFO - 2018-03-28 15:57:07 --> Model Class Initialized
INFO - 2018-03-28 15:57:07 --> Model Class Initialized
INFO - 2018-03-28 15:57:07 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:57:07 --> Model Class Initialized
INFO - 2018-03-28 15:57:07 --> Final output sent to browser
DEBUG - 2018-03-28 15:57:07 --> Total execution time: 2.0517
INFO - 2018-03-28 10:27:07 --> Config Class Initialized
INFO - 2018-03-28 10:27:07 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:27:07 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:27:07 --> Utf8 Class Initialized
INFO - 2018-03-28 10:27:08 --> URI Class Initialized
INFO - 2018-03-28 10:27:08 --> Router Class Initialized
INFO - 2018-03-28 10:27:08 --> Output Class Initialized
INFO - 2018-03-28 10:27:08 --> Security Class Initialized
DEBUG - 2018-03-28 10:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:27:08 --> Input Class Initialized
INFO - 2018-03-28 10:27:08 --> Language Class Initialized
INFO - 2018-03-28 10:27:09 --> Language Class Initialized
INFO - 2018-03-28 10:27:09 --> Config Class Initialized
INFO - 2018-03-28 10:27:09 --> Loader Class Initialized
INFO - 2018-03-28 15:57:09 --> Helper loaded: url_helper
INFO - 2018-03-28 15:57:09 --> Helper loaded: notification_helper
INFO - 2018-03-28 15:57:09 --> Helper loaded: settings_helper
INFO - 2018-03-28 15:57:09 --> Helper loaded: permission_helper
INFO - 2018-03-28 15:57:09 --> Helper loaded: users_helper
INFO - 2018-03-28 15:57:09 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:57:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:57:09 --> Helper loaded: form_helper
INFO - 2018-03-28 15:57:09 --> Form Validation Class Initialized
INFO - 2018-03-28 15:57:09 --> Controller Class Initialized
INFO - 2018-03-28 15:57:09 --> Model Class Initialized
INFO - 2018-03-28 15:57:09 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 15:57:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 15:57:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 15:57:09 --> Model Class Initialized
INFO - 2018-03-28 15:57:09 --> Model Class Initialized
INFO - 2018-03-28 15:57:09 --> Model Class Initialized
INFO - 2018-03-28 15:57:09 --> Model Class Initialized
INFO - 2018-03-28 15:57:09 --> Model Class Initialized
INFO - 2018-03-28 15:57:09 --> Model Class Initialized
INFO - 2018-03-28 15:57:09 --> Model Class Initialized
INFO - 2018-03-28 15:57:09 --> Model Class Initialized
INFO - 2018-03-28 15:57:09 --> Model Class Initialized
INFO - 2018-03-28 15:57:09 --> Model Class Initialized
INFO - 2018-03-28 15:57:09 --> Model Class Initialized
INFO - 2018-03-28 15:57:09 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 15:57:09 --> Model Class Initialized
INFO - 2018-03-28 15:57:09 --> Final output sent to browser
DEBUG - 2018-03-28 15:57:09 --> Total execution time: 2.0574
INFO - 2018-03-28 10:35:02 --> Config Class Initialized
INFO - 2018-03-28 10:35:02 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:35:02 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:35:02 --> Utf8 Class Initialized
INFO - 2018-03-28 10:35:02 --> URI Class Initialized
INFO - 2018-03-28 10:35:02 --> Router Class Initialized
INFO - 2018-03-28 10:35:02 --> Output Class Initialized
INFO - 2018-03-28 10:35:02 --> Security Class Initialized
DEBUG - 2018-03-28 10:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:35:02 --> Input Class Initialized
INFO - 2018-03-28 10:35:02 --> Language Class Initialized
INFO - 2018-03-28 10:35:02 --> Language Class Initialized
INFO - 2018-03-28 10:35:02 --> Config Class Initialized
INFO - 2018-03-28 10:35:02 --> Loader Class Initialized
INFO - 2018-03-28 16:05:02 --> Helper loaded: url_helper
INFO - 2018-03-28 16:05:02 --> Helper loaded: notification_helper
INFO - 2018-03-28 16:05:02 --> Helper loaded: settings_helper
INFO - 2018-03-28 16:05:02 --> Helper loaded: permission_helper
INFO - 2018-03-28 16:05:02 --> Helper loaded: users_helper
INFO - 2018-03-28 16:05:02 --> Database Driver Class Initialized
DEBUG - 2018-03-28 16:05:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 16:05:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 16:05:02 --> Helper loaded: form_helper
INFO - 2018-03-28 16:05:02 --> Form Validation Class Initialized
INFO - 2018-03-28 16:05:02 --> Controller Class Initialized
INFO - 2018-03-28 16:05:02 --> Model Class Initialized
INFO - 2018-03-28 16:05:02 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 16:05:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 16:05:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 16:05:02 --> Model Class Initialized
INFO - 2018-03-28 16:05:02 --> Model Class Initialized
INFO - 2018-03-28 16:05:02 --> Model Class Initialized
INFO - 2018-03-28 16:05:02 --> Model Class Initialized
INFO - 2018-03-28 16:05:02 --> Model Class Initialized
INFO - 2018-03-28 16:05:02 --> Model Class Initialized
INFO - 2018-03-28 16:05:02 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 16:05:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-28 16:05:02 --> Final output sent to browser
DEBUG - 2018-03-28 16:05:02 --> Total execution time: 0.1210
INFO - 2018-03-28 10:35:04 --> Config Class Initialized
INFO - 2018-03-28 10:35:04 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:35:04 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:35:04 --> Utf8 Class Initialized
INFO - 2018-03-28 10:35:04 --> URI Class Initialized
INFO - 2018-03-28 10:35:04 --> Router Class Initialized
INFO - 2018-03-28 10:35:04 --> Output Class Initialized
INFO - 2018-03-28 10:35:04 --> Security Class Initialized
DEBUG - 2018-03-28 10:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:35:04 --> Input Class Initialized
INFO - 2018-03-28 10:35:04 --> Config Class Initialized
INFO - 2018-03-28 10:35:04 --> Hooks Class Initialized
INFO - 2018-03-28 10:35:04 --> Language Class Initialized
DEBUG - 2018-03-28 10:35:04 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:35:04 --> Utf8 Class Initialized
INFO - 2018-03-28 10:35:04 --> URI Class Initialized
INFO - 2018-03-28 10:35:04 --> Router Class Initialized
INFO - 2018-03-28 10:35:04 --> Output Class Initialized
INFO - 2018-03-28 10:35:04 --> Security Class Initialized
DEBUG - 2018-03-28 10:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:35:04 --> Input Class Initialized
INFO - 2018-03-28 10:35:04 --> Language Class Initialized
INFO - 2018-03-28 10:35:04 --> Config Class Initialized
INFO - 2018-03-28 10:35:04 --> Loader Class Initialized
INFO - 2018-03-28 10:35:04 --> Language Class Initialized
INFO - 2018-03-28 16:05:04 --> Helper loaded: url_helper
INFO - 2018-03-28 16:05:04 --> Helper loaded: notification_helper
INFO - 2018-03-28 16:05:04 --> Helper loaded: settings_helper
INFO - 2018-03-28 16:05:04 --> Helper loaded: permission_helper
INFO - 2018-03-28 16:05:04 --> Helper loaded: users_helper
INFO - 2018-03-28 10:35:04 --> Language Class Initialized
INFO - 2018-03-28 10:35:04 --> Config Class Initialized
INFO - 2018-03-28 10:35:04 --> Loader Class Initialized
INFO - 2018-03-28 16:05:04 --> Database Driver Class Initialized
INFO - 2018-03-28 16:05:04 --> Helper loaded: url_helper
INFO - 2018-03-28 16:05:04 --> Helper loaded: notification_helper
INFO - 2018-03-28 16:05:04 --> Helper loaded: settings_helper
DEBUG - 2018-03-28 16:05:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 16:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 16:05:04 --> Helper loaded: permission_helper
INFO - 2018-03-28 16:05:04 --> Helper loaded: users_helper
INFO - 2018-03-28 16:05:04 --> Helper loaded: form_helper
INFO - 2018-03-28 16:05:04 --> Form Validation Class Initialized
INFO - 2018-03-28 16:05:04 --> Controller Class Initialized
INFO - 2018-03-28 16:05:04 --> Model Class Initialized
INFO - 2018-03-28 16:05:04 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 16:05:04 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 16:05:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 16:05:04 --> Model Class Initialized
INFO - 2018-03-28 16:05:04 --> Model Class Initialized
INFO - 2018-03-28 16:05:04 --> Model Class Initialized
INFO - 2018-03-28 16:05:04 --> Model Class Initialized
INFO - 2018-03-28 16:05:04 --> Model Class Initialized
INFO - 2018-03-28 16:05:04 --> Model Class Initialized
INFO - 2018-03-28 16:05:04 --> Model Class Initialized
INFO - 2018-03-28 16:05:04 --> Model Class Initialized
INFO - 2018-03-28 16:05:04 --> Model Class Initialized
INFO - 2018-03-28 16:05:04 --> Model Class Initialized
INFO - 2018-03-28 16:05:04 --> Model Class Initialized
INFO - 2018-03-28 16:05:04 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 16:05:04 --> Model Class Initialized
INFO - 2018-03-28 16:05:04 --> Database Driver Class Initialized
INFO - 2018-03-28 16:05:04 --> Final output sent to browser
DEBUG - 2018-03-28 16:05:04 --> Total execution time: 0.2414
DEBUG - 2018-03-28 16:05:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 16:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 16:05:04 --> Helper loaded: form_helper
INFO - 2018-03-28 16:05:04 --> Form Validation Class Initialized
INFO - 2018-03-28 16:05:04 --> Controller Class Initialized
INFO - 2018-03-28 16:05:04 --> Model Class Initialized
INFO - 2018-03-28 16:05:04 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 16:05:04 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 16:05:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 16:05:04 --> Model Class Initialized
INFO - 2018-03-28 16:05:04 --> Model Class Initialized
INFO - 2018-03-28 16:05:04 --> Model Class Initialized
INFO - 2018-03-28 16:05:04 --> Model Class Initialized
INFO - 2018-03-28 16:05:04 --> Model Class Initialized
INFO - 2018-03-28 16:05:04 --> Model Class Initialized
INFO - 2018-03-28 16:05:04 --> Model Class Initialized
INFO - 2018-03-28 16:05:04 --> Model Class Initialized
INFO - 2018-03-28 16:05:04 --> Model Class Initialized
INFO - 2018-03-28 16:05:04 --> Model Class Initialized
INFO - 2018-03-28 16:05:04 --> Model Class Initialized
INFO - 2018-03-28 16:05:04 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 16:05:04 --> Model Class Initialized
INFO - 2018-03-28 16:05:04 --> Final output sent to browser
DEBUG - 2018-03-28 16:05:04 --> Total execution time: 0.2834
INFO - 2018-03-28 10:35:06 --> Config Class Initialized
INFO - 2018-03-28 10:35:06 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:35:06 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:35:06 --> Utf8 Class Initialized
INFO - 2018-03-28 10:35:06 --> URI Class Initialized
INFO - 2018-03-28 10:35:06 --> Router Class Initialized
INFO - 2018-03-28 10:35:06 --> Output Class Initialized
INFO - 2018-03-28 10:35:06 --> Security Class Initialized
INFO - 2018-03-28 10:35:06 --> Config Class Initialized
INFO - 2018-03-28 10:35:06 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:35:06 --> Input Class Initialized
INFO - 2018-03-28 10:35:06 --> Language Class Initialized
DEBUG - 2018-03-28 10:35:06 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:35:06 --> Utf8 Class Initialized
INFO - 2018-03-28 10:35:06 --> URI Class Initialized
INFO - 2018-03-28 10:35:06 --> Router Class Initialized
INFO - 2018-03-28 10:35:06 --> Output Class Initialized
INFO - 2018-03-28 10:35:06 --> Security Class Initialized
INFO - 2018-03-28 10:35:06 --> Language Class Initialized
INFO - 2018-03-28 10:35:06 --> Config Class Initialized
INFO - 2018-03-28 10:35:06 --> Loader Class Initialized
INFO - 2018-03-28 16:05:06 --> Helper loaded: url_helper
INFO - 2018-03-28 16:05:06 --> Helper loaded: notification_helper
INFO - 2018-03-28 16:05:06 --> Helper loaded: settings_helper
INFO - 2018-03-28 16:05:06 --> Helper loaded: permission_helper
DEBUG - 2018-03-28 10:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:35:06 --> Input Class Initialized
INFO - 2018-03-28 16:05:06 --> Helper loaded: users_helper
INFO - 2018-03-28 10:35:06 --> Language Class Initialized
INFO - 2018-03-28 16:05:06 --> Database Driver Class Initialized
INFO - 2018-03-28 10:35:06 --> Language Class Initialized
INFO - 2018-03-28 10:35:06 --> Config Class Initialized
INFO - 2018-03-28 10:35:06 --> Loader Class Initialized
DEBUG - 2018-03-28 16:05:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 16:05:06 --> Helper loaded: url_helper
INFO - 2018-03-28 16:05:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 16:05:06 --> Helper loaded: notification_helper
INFO - 2018-03-28 16:05:06 --> Helper loaded: settings_helper
INFO - 2018-03-28 16:05:06 --> Helper loaded: permission_helper
INFO - 2018-03-28 16:05:06 --> Helper loaded: users_helper
INFO - 2018-03-28 16:05:06 --> Helper loaded: form_helper
INFO - 2018-03-28 16:05:06 --> Form Validation Class Initialized
INFO - 2018-03-28 16:05:06 --> Controller Class Initialized
INFO - 2018-03-28 16:05:06 --> Model Class Initialized
INFO - 2018-03-28 16:05:06 --> Database Driver Class Initialized
INFO - 2018-03-28 16:05:06 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 16:05:06 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-03-28 16:05:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 16:05:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 16:05:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 16:05:06 --> Model Class Initialized
INFO - 2018-03-28 16:05:06 --> Model Class Initialized
INFO - 2018-03-28 16:05:06 --> Model Class Initialized
INFO - 2018-03-28 16:05:06 --> Model Class Initialized
INFO - 2018-03-28 16:05:06 --> Model Class Initialized
INFO - 2018-03-28 16:05:06 --> Model Class Initialized
INFO - 2018-03-28 16:05:06 --> Model Class Initialized
INFO - 2018-03-28 16:05:06 --> Model Class Initialized
INFO - 2018-03-28 16:05:06 --> Model Class Initialized
INFO - 2018-03-28 16:05:06 --> Model Class Initialized
INFO - 2018-03-28 16:05:06 --> Helper loaded: form_helper
INFO - 2018-03-28 16:05:06 --> Form Validation Class Initialized
INFO - 2018-03-28 16:05:06 --> Controller Class Initialized
INFO - 2018-03-28 16:05:06 --> Model Class Initialized
INFO - 2018-03-28 16:05:06 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 16:05:06 --> Model Class Initialized
INFO - 2018-03-28 16:05:06 --> Model Class Initialized
INFO - 2018-03-28 16:05:06 --> Helper loaded: inflector_helper
INFO - 2018-03-28 16:05:06 --> Final output sent to browser
DEBUG - 2018-03-28 16:05:06 --> Total execution time: 0.1255
DEBUG - 2018-03-28 16:05:06 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 16:05:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 16:05:06 --> Model Class Initialized
INFO - 2018-03-28 16:05:06 --> Model Class Initialized
INFO - 2018-03-28 16:05:06 --> Model Class Initialized
INFO - 2018-03-28 16:05:06 --> Model Class Initialized
INFO - 2018-03-28 16:05:06 --> Model Class Initialized
INFO - 2018-03-28 16:05:06 --> Model Class Initialized
INFO - 2018-03-28 16:05:06 --> Model Class Initialized
INFO - 2018-03-28 16:05:06 --> Model Class Initialized
INFO - 2018-03-28 16:05:06 --> Model Class Initialized
INFO - 2018-03-28 16:05:06 --> Model Class Initialized
INFO - 2018-03-28 16:05:06 --> Model Class Initialized
INFO - 2018-03-28 16:05:06 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 16:05:06 --> Final output sent to browser
DEBUG - 2018-03-28 16:05:06 --> Total execution time: 0.1568
INFO - 2018-03-28 10:35:09 --> Config Class Initialized
INFO - 2018-03-28 10:35:09 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:35:09 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:35:09 --> Utf8 Class Initialized
INFO - 2018-03-28 10:35:09 --> URI Class Initialized
INFO - 2018-03-28 10:35:09 --> Router Class Initialized
INFO - 2018-03-28 10:35:09 --> Output Class Initialized
INFO - 2018-03-28 10:35:09 --> Security Class Initialized
DEBUG - 2018-03-28 10:35:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:35:09 --> Input Class Initialized
INFO - 2018-03-28 10:35:09 --> Language Class Initialized
INFO - 2018-03-28 10:35:10 --> Language Class Initialized
INFO - 2018-03-28 10:35:10 --> Config Class Initialized
INFO - 2018-03-28 10:35:10 --> Loader Class Initialized
INFO - 2018-03-28 16:05:10 --> Helper loaded: url_helper
INFO - 2018-03-28 16:05:10 --> Helper loaded: notification_helper
INFO - 2018-03-28 16:05:10 --> Helper loaded: settings_helper
INFO - 2018-03-28 16:05:10 --> Helper loaded: permission_helper
INFO - 2018-03-28 16:05:10 --> Helper loaded: users_helper
INFO - 2018-03-28 16:05:10 --> Database Driver Class Initialized
DEBUG - 2018-03-28 16:05:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 16:05:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 16:05:10 --> Helper loaded: form_helper
INFO - 2018-03-28 16:05:10 --> Form Validation Class Initialized
INFO - 2018-03-28 16:05:10 --> Controller Class Initialized
INFO - 2018-03-28 16:05:11 --> Model Class Initialized
INFO - 2018-03-28 16:05:11 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 16:05:11 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 16:05:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 16:05:11 --> Model Class Initialized
INFO - 2018-03-28 16:05:11 --> Model Class Initialized
INFO - 2018-03-28 16:05:11 --> Model Class Initialized
INFO - 2018-03-28 16:05:11 --> Model Class Initialized
INFO - 2018-03-28 16:05:11 --> Model Class Initialized
INFO - 2018-03-28 16:05:11 --> Model Class Initialized
INFO - 2018-03-28 16:05:11 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-28 16:05:11 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-28 16:05:11 --> Final output sent to browser
DEBUG - 2018-03-28 16:05:11 --> Total execution time: 1.3603
INFO - 2018-03-28 10:35:11 --> Config Class Initialized
INFO - 2018-03-28 10:35:11 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:35:11 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:35:11 --> Utf8 Class Initialized
INFO - 2018-03-28 10:35:12 --> URI Class Initialized
INFO - 2018-03-28 10:35:12 --> Router Class Initialized
INFO - 2018-03-28 10:35:12 --> Output Class Initialized
INFO - 2018-03-28 10:35:12 --> Security Class Initialized
DEBUG - 2018-03-28 10:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:35:12 --> Input Class Initialized
INFO - 2018-03-28 10:35:12 --> Language Class Initialized
INFO - 2018-03-28 10:35:12 --> Language Class Initialized
INFO - 2018-03-28 10:35:12 --> Config Class Initialized
INFO - 2018-03-28 10:35:12 --> Loader Class Initialized
INFO - 2018-03-28 16:05:12 --> Helper loaded: url_helper
INFO - 2018-03-28 16:05:12 --> Helper loaded: notification_helper
INFO - 2018-03-28 16:05:12 --> Helper loaded: settings_helper
INFO - 2018-03-28 16:05:12 --> Helper loaded: permission_helper
INFO - 2018-03-28 16:05:12 --> Helper loaded: users_helper
INFO - 2018-03-28 16:05:12 --> Database Driver Class Initialized
DEBUG - 2018-03-28 16:05:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 16:05:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 16:05:12 --> Helper loaded: form_helper
INFO - 2018-03-28 16:05:12 --> Form Validation Class Initialized
INFO - 2018-03-28 16:05:12 --> Controller Class Initialized
INFO - 2018-03-28 16:05:12 --> Model Class Initialized
INFO - 2018-03-28 16:05:12 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 16:05:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 16:05:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 16:05:12 --> Model Class Initialized
INFO - 2018-03-28 16:05:12 --> Model Class Initialized
INFO - 2018-03-28 16:05:12 --> Model Class Initialized
INFO - 2018-03-28 16:05:12 --> Model Class Initialized
INFO - 2018-03-28 16:05:12 --> Model Class Initialized
INFO - 2018-03-28 16:05:12 --> Model Class Initialized
INFO - 2018-03-28 16:05:12 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-28 16:05:12 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-28 16:05:12 --> Final output sent to browser
DEBUG - 2018-03-28 16:05:12 --> Total execution time: 0.6192
INFO - 2018-03-28 10:35:13 --> Config Class Initialized
INFO - 2018-03-28 10:35:13 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:35:13 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:35:13 --> Utf8 Class Initialized
INFO - 2018-03-28 10:35:14 --> URI Class Initialized
INFO - 2018-03-28 10:35:14 --> Router Class Initialized
INFO - 2018-03-28 10:35:14 --> Output Class Initialized
INFO - 2018-03-28 10:35:14 --> Security Class Initialized
INFO - 2018-03-28 10:35:14 --> Config Class Initialized
INFO - 2018-03-28 10:35:14 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:35:14 --> Input Class Initialized
INFO - 2018-03-28 10:35:14 --> Language Class Initialized
DEBUG - 2018-03-28 10:35:14 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:35:14 --> Utf8 Class Initialized
INFO - 2018-03-28 10:35:14 --> Language Class Initialized
INFO - 2018-03-28 10:35:14 --> Config Class Initialized
INFO - 2018-03-28 10:35:14 --> Loader Class Initialized
INFO - 2018-03-28 10:35:14 --> URI Class Initialized
INFO - 2018-03-28 16:05:14 --> Helper loaded: url_helper
INFO - 2018-03-28 16:05:14 --> Helper loaded: notification_helper
INFO - 2018-03-28 16:05:14 --> Helper loaded: settings_helper
INFO - 2018-03-28 16:05:14 --> Helper loaded: permission_helper
INFO - 2018-03-28 16:05:14 --> Helper loaded: users_helper
INFO - 2018-03-28 10:35:14 --> Router Class Initialized
INFO - 2018-03-28 16:05:14 --> Database Driver Class Initialized
DEBUG - 2018-03-28 16:05:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 16:05:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 10:35:14 --> Output Class Initialized
INFO - 2018-03-28 16:05:14 --> Helper loaded: form_helper
INFO - 2018-03-28 16:05:14 --> Form Validation Class Initialized
INFO - 2018-03-28 16:05:14 --> Controller Class Initialized
INFO - 2018-03-28 10:35:14 --> Security Class Initialized
DEBUG - 2018-03-28 10:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:35:14 --> Input Class Initialized
INFO - 2018-03-28 16:05:14 --> Model Class Initialized
INFO - 2018-03-28 16:05:14 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 16:05:14 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 10:35:14 --> Language Class Initialized
INFO - 2018-03-28 16:05:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 16:05:14 --> Model Class Initialized
INFO - 2018-03-28 16:05:14 --> Model Class Initialized
INFO - 2018-03-28 16:05:14 --> Model Class Initialized
INFO - 2018-03-28 16:05:14 --> Model Class Initialized
INFO - 2018-03-28 16:05:14 --> Model Class Initialized
INFO - 2018-03-28 16:05:14 --> Model Class Initialized
INFO - 2018-03-28 16:05:14 --> Model Class Initialized
INFO - 2018-03-28 16:05:14 --> Model Class Initialized
INFO - 2018-03-28 16:05:14 --> Model Class Initialized
INFO - 2018-03-28 16:05:14 --> Model Class Initialized
INFO - 2018-03-28 16:05:14 --> Model Class Initialized
INFO - 2018-03-28 16:05:14 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 16:05:14 --> Model Class Initialized
INFO - 2018-03-28 16:05:14 --> Final output sent to browser
DEBUG - 2018-03-28 16:05:14 --> Total execution time: 0.4199
INFO - 2018-03-28 10:35:14 --> Language Class Initialized
INFO - 2018-03-28 10:35:14 --> Config Class Initialized
INFO - 2018-03-28 10:35:14 --> Loader Class Initialized
INFO - 2018-03-28 16:05:14 --> Helper loaded: url_helper
INFO - 2018-03-28 16:05:14 --> Helper loaded: notification_helper
INFO - 2018-03-28 16:05:14 --> Helper loaded: settings_helper
INFO - 2018-03-28 16:05:14 --> Helper loaded: permission_helper
INFO - 2018-03-28 16:05:14 --> Helper loaded: users_helper
INFO - 2018-03-28 10:35:14 --> Config Class Initialized
INFO - 2018-03-28 10:35:14 --> Hooks Class Initialized
INFO - 2018-03-28 16:05:14 --> Database Driver Class Initialized
DEBUG - 2018-03-28 16:05:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 16:05:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 16:05:14 --> Helper loaded: form_helper
INFO - 2018-03-28 16:05:14 --> Form Validation Class Initialized
INFO - 2018-03-28 16:05:14 --> Controller Class Initialized
DEBUG - 2018-03-28 10:35:14 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:35:14 --> Utf8 Class Initialized
INFO - 2018-03-28 10:35:14 --> URI Class Initialized
INFO - 2018-03-28 16:05:14 --> Model Class Initialized
INFO - 2018-03-28 16:05:14 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 16:05:14 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 16:05:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 16:05:14 --> Model Class Initialized
INFO - 2018-03-28 16:05:14 --> Model Class Initialized
INFO - 2018-03-28 16:05:14 --> Model Class Initialized
INFO - 2018-03-28 16:05:14 --> Model Class Initialized
INFO - 2018-03-28 16:05:14 --> Model Class Initialized
INFO - 2018-03-28 16:05:14 --> Model Class Initialized
INFO - 2018-03-28 10:35:14 --> Router Class Initialized
INFO - 2018-03-28 16:05:14 --> Model Class Initialized
INFO - 2018-03-28 16:05:14 --> Model Class Initialized
INFO - 2018-03-28 16:05:14 --> Model Class Initialized
INFO - 2018-03-28 16:05:14 --> Model Class Initialized
INFO - 2018-03-28 16:05:14 --> Model Class Initialized
INFO - 2018-03-28 16:05:14 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 16:05:14 --> Model Class Initialized
INFO - 2018-03-28 10:35:14 --> Output Class Initialized
INFO - 2018-03-28 16:05:14 --> Final output sent to browser
DEBUG - 2018-03-28 16:05:14 --> Total execution time: 0.7038
INFO - 2018-03-28 10:35:14 --> Security Class Initialized
DEBUG - 2018-03-28 10:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:35:14 --> Input Class Initialized
INFO - 2018-03-28 10:35:14 --> Language Class Initialized
INFO - 2018-03-28 10:35:14 --> Config Class Initialized
INFO - 2018-03-28 10:35:14 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:35:14 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:35:14 --> Utf8 Class Initialized
INFO - 2018-03-28 10:35:14 --> URI Class Initialized
INFO - 2018-03-28 10:35:14 --> Router Class Initialized
INFO - 2018-03-28 10:35:14 --> Output Class Initialized
INFO - 2018-03-28 10:35:14 --> Security Class Initialized
INFO - 2018-03-28 10:35:14 --> Config Class Initialized
INFO - 2018-03-28 10:35:14 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:35:14 --> Input Class Initialized
INFO - 2018-03-28 10:35:14 --> Language Class Initialized
INFO - 2018-03-28 10:35:14 --> Language Class Initialized
INFO - 2018-03-28 10:35:14 --> Config Class Initialized
INFO - 2018-03-28 10:35:14 --> Loader Class Initialized
INFO - 2018-03-28 16:05:14 --> Helper loaded: url_helper
INFO - 2018-03-28 16:05:14 --> Helper loaded: notification_helper
INFO - 2018-03-28 16:05:14 --> Helper loaded: settings_helper
INFO - 2018-03-28 16:05:14 --> Helper loaded: permission_helper
INFO - 2018-03-28 16:05:14 --> Helper loaded: users_helper
DEBUG - 2018-03-28 10:35:14 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:35:14 --> Utf8 Class Initialized
INFO - 2018-03-28 10:35:14 --> URI Class Initialized
INFO - 2018-03-28 10:35:14 --> Language Class Initialized
INFO - 2018-03-28 10:35:14 --> Config Class Initialized
INFO - 2018-03-28 10:35:14 --> Loader Class Initialized
INFO - 2018-03-28 16:05:14 --> Helper loaded: url_helper
INFO - 2018-03-28 16:05:14 --> Helper loaded: notification_helper
INFO - 2018-03-28 16:05:14 --> Helper loaded: settings_helper
INFO - 2018-03-28 10:35:15 --> Config Class Initialized
INFO - 2018-03-28 10:35:15 --> Hooks Class Initialized
INFO - 2018-03-28 16:05:15 --> Helper loaded: permission_helper
INFO - 2018-03-28 16:05:15 --> Helper loaded: users_helper
INFO - 2018-03-28 16:05:15 --> Database Driver Class Initialized
DEBUG - 2018-03-28 16:05:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 16:05:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 10:35:15 --> Router Class Initialized
INFO - 2018-03-28 10:35:15 --> Output Class Initialized
INFO - 2018-03-28 16:05:15 --> Database Driver Class Initialized
INFO - 2018-03-28 10:35:15 --> Security Class Initialized
DEBUG - 2018-03-28 16:05:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 16:05:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 16:05:15 --> Helper loaded: form_helper
INFO - 2018-03-28 16:05:15 --> Form Validation Class Initialized
INFO - 2018-03-28 16:05:15 --> Controller Class Initialized
INFO - 2018-03-28 16:05:15 --> Helper loaded: form_helper
INFO - 2018-03-28 16:05:15 --> Form Validation Class Initialized
INFO - 2018-03-28 16:05:15 --> Controller Class Initialized
INFO - 2018-03-28 16:05:15 --> Model Class Initialized
INFO - 2018-03-28 16:05:15 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 10:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:35:15 --> Input Class Initialized
DEBUG - 2018-03-28 16:05:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-03-28 10:35:15 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:35:15 --> Utf8 Class Initialized
INFO - 2018-03-28 10:35:15 --> Language Class Initialized
INFO - 2018-03-28 16:05:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 10:35:15 --> URI Class Initialized
INFO - 2018-03-28 16:05:15 --> Model Class Initialized
INFO - 2018-03-28 16:05:15 --> Model Class Initialized
INFO - 2018-03-28 16:05:15 --> Model Class Initialized
INFO - 2018-03-28 16:05:15 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 16:05:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 16:05:15 --> Model Class Initialized
INFO - 2018-03-28 16:05:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 16:05:15 --> Model Class Initialized
INFO - 2018-03-28 16:05:15 --> Model Class Initialized
INFO - 2018-03-28 16:05:15 --> Model Class Initialized
INFO - 2018-03-28 16:05:15 --> Model Class Initialized
INFO - 2018-03-28 16:05:15 --> Model Class Initialized
INFO - 2018-03-28 16:05:15 --> Model Class Initialized
INFO - 2018-03-28 16:05:15 --> Model Class Initialized
INFO - 2018-03-28 16:05:15 --> Model Class Initialized
INFO - 2018-03-28 16:05:15 --> Model Class Initialized
INFO - 2018-03-28 16:05:15 --> Model Class Initialized
INFO - 2018-03-28 16:05:15 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 16:05:15 --> Final output sent to browser
DEBUG - 2018-03-28 16:05:15 --> Total execution time: 1.2283
INFO - 2018-03-28 16:05:15 --> Model Class Initialized
INFO - 2018-03-28 16:05:15 --> Model Class Initialized
INFO - 2018-03-28 16:05:15 --> Model Class Initialized
INFO - 2018-03-28 16:05:15 --> Model Class Initialized
INFO - 2018-03-28 16:05:15 --> Model Class Initialized
INFO - 2018-03-28 16:05:15 --> Model Class Initialized
INFO - 2018-03-28 16:05:15 --> Model Class Initialized
INFO - 2018-03-28 16:05:15 --> Model Class Initialized
INFO - 2018-03-28 10:35:15 --> Router Class Initialized
INFO - 2018-03-28 16:05:15 --> Model Class Initialized
INFO - 2018-03-28 16:05:15 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 16:05:15 --> Model Class Initialized
INFO - 2018-03-28 16:05:15 --> Final output sent to browser
DEBUG - 2018-03-28 16:05:15 --> Total execution time: 1.1957
INFO - 2018-03-28 10:35:16 --> Language Class Initialized
INFO - 2018-03-28 10:35:16 --> Config Class Initialized
INFO - 2018-03-28 10:35:16 --> Loader Class Initialized
INFO - 2018-03-28 10:35:16 --> Output Class Initialized
INFO - 2018-03-28 16:05:16 --> Helper loaded: url_helper
INFO - 2018-03-28 16:05:16 --> Helper loaded: notification_helper
INFO - 2018-03-28 16:05:16 --> Helper loaded: settings_helper
INFO - 2018-03-28 16:05:16 --> Helper loaded: permission_helper
INFO - 2018-03-28 16:05:16 --> Helper loaded: users_helper
INFO - 2018-03-28 10:35:16 --> Security Class Initialized
INFO - 2018-03-28 16:05:16 --> Database Driver Class Initialized
INFO - 2018-03-28 10:35:16 --> Config Class Initialized
INFO - 2018-03-28 10:35:16 --> Hooks Class Initialized
DEBUG - 2018-03-28 16:05:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 16:05:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-03-28 10:35:16 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:35:16 --> Utf8 Class Initialized
INFO - 2018-03-28 10:35:16 --> URI Class Initialized
INFO - 2018-03-28 10:35:16 --> Router Class Initialized
INFO - 2018-03-28 10:35:16 --> Output Class Initialized
INFO - 2018-03-28 10:35:16 --> Config Class Initialized
INFO - 2018-03-28 10:35:16 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:35:16 --> Input Class Initialized
INFO - 2018-03-28 10:35:16 --> Security Class Initialized
DEBUG - 2018-03-28 10:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:35:16 --> Input Class Initialized
INFO - 2018-03-28 16:05:16 --> Helper loaded: form_helper
INFO - 2018-03-28 10:35:16 --> Language Class Initialized
INFO - 2018-03-28 16:05:16 --> Form Validation Class Initialized
INFO - 2018-03-28 16:05:16 --> Controller Class Initialized
DEBUG - 2018-03-28 10:35:16 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:35:16 --> Utf8 Class Initialized
INFO - 2018-03-28 10:35:16 --> URI Class Initialized
INFO - 2018-03-28 10:35:16 --> Router Class Initialized
INFO - 2018-03-28 10:35:16 --> Output Class Initialized
INFO - 2018-03-28 10:35:16 --> Language Class Initialized
INFO - 2018-03-28 10:35:16 --> Config Class Initialized
INFO - 2018-03-28 10:35:16 --> Loader Class Initialized
INFO - 2018-03-28 16:05:16 --> Model Class Initialized
INFO - 2018-03-28 16:05:16 --> Helper loaded: url_helper
INFO - 2018-03-28 16:05:16 --> Helper loaded: inflector_helper
INFO - 2018-03-28 16:05:16 --> Helper loaded: notification_helper
INFO - 2018-03-28 10:35:16 --> Security Class Initialized
INFO - 2018-03-28 16:05:16 --> Helper loaded: settings_helper
INFO - 2018-03-28 10:35:16 --> Language Class Initialized
INFO - 2018-03-28 16:05:16 --> Helper loaded: permission_helper
INFO - 2018-03-28 16:05:16 --> Helper loaded: users_helper
DEBUG - 2018-03-28 10:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:35:16 --> Input Class Initialized
DEBUG - 2018-03-28 16:05:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 10:35:16 --> Language Class Initialized
INFO - 2018-03-28 16:05:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 16:05:16 --> Model Class Initialized
INFO - 2018-03-28 16:05:16 --> Model Class Initialized
INFO - 2018-03-28 16:05:16 --> Model Class Initialized
INFO - 2018-03-28 16:05:16 --> Model Class Initialized
INFO - 2018-03-28 16:05:16 --> Model Class Initialized
INFO - 2018-03-28 16:05:16 --> Database Driver Class Initialized
INFO - 2018-03-28 16:05:16 --> Model Class Initialized
INFO - 2018-03-28 16:05:16 --> Model Class Initialized
DEBUG - 2018-03-28 16:05:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 16:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 16:05:16 --> Model Class Initialized
INFO - 2018-03-28 16:05:16 --> Model Class Initialized
INFO - 2018-03-28 16:05:16 --> Model Class Initialized
INFO - 2018-03-28 16:05:16 --> Helper loaded: form_helper
INFO - 2018-03-28 16:05:16 --> Form Validation Class Initialized
INFO - 2018-03-28 16:05:16 --> Controller Class Initialized
INFO - 2018-03-28 16:05:16 --> Model Class Initialized
INFO - 2018-03-28 16:05:16 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 16:05:16 --> Model Class Initialized
INFO - 2018-03-28 16:05:16 --> Model Class Initialized
INFO - 2018-03-28 16:05:16 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 16:05:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 16:05:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 16:05:16 --> Model Class Initialized
INFO - 2018-03-28 16:05:16 --> Model Class Initialized
INFO - 2018-03-28 16:05:16 --> Model Class Initialized
INFO - 2018-03-28 16:05:16 --> Model Class Initialized
INFO - 2018-03-28 16:05:16 --> Model Class Initialized
INFO - 2018-03-28 16:05:16 --> Model Class Initialized
INFO - 2018-03-28 16:05:16 --> Model Class Initialized
INFO - 2018-03-28 16:05:16 --> Model Class Initialized
INFO - 2018-03-28 16:05:16 --> Model Class Initialized
INFO - 2018-03-28 16:05:16 --> Model Class Initialized
INFO - 2018-03-28 16:05:16 --> Model Class Initialized
INFO - 2018-03-28 16:05:16 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 16:05:16 --> Model Class Initialized
INFO - 2018-03-28 10:35:16 --> Language Class Initialized
INFO - 2018-03-28 10:35:16 --> Config Class Initialized
INFO - 2018-03-28 10:35:16 --> Loader Class Initialized
INFO - 2018-03-28 16:05:16 --> Final output sent to browser
INFO - 2018-03-28 16:05:16 --> Final output sent to browser
DEBUG - 2018-03-28 16:05:16 --> Total execution time: 0.4335
DEBUG - 2018-03-28 16:05:16 --> Total execution time: 2.2089
INFO - 2018-03-28 16:05:16 --> Helper loaded: url_helper
INFO - 2018-03-28 16:05:16 --> Helper loaded: notification_helper
INFO - 2018-03-28 16:05:16 --> Helper loaded: settings_helper
INFO - 2018-03-28 16:05:16 --> Helper loaded: permission_helper
INFO - 2018-03-28 16:05:16 --> Helper loaded: users_helper
INFO - 2018-03-28 16:05:17 --> Database Driver Class Initialized
DEBUG - 2018-03-28 16:05:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 16:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 16:05:17 --> Helper loaded: form_helper
INFO - 2018-03-28 16:05:17 --> Form Validation Class Initialized
INFO - 2018-03-28 16:05:17 --> Controller Class Initialized
INFO - 2018-03-28 16:05:17 --> Model Class Initialized
INFO - 2018-03-28 16:05:17 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 16:05:17 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 16:05:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 16:05:17 --> Model Class Initialized
INFO - 2018-03-28 16:05:17 --> Model Class Initialized
INFO - 2018-03-28 16:05:17 --> Model Class Initialized
INFO - 2018-03-28 16:05:17 --> Model Class Initialized
INFO - 2018-03-28 16:05:17 --> Model Class Initialized
INFO - 2018-03-28 16:05:17 --> Model Class Initialized
INFO - 2018-03-28 16:05:17 --> Model Class Initialized
INFO - 2018-03-28 16:05:17 --> Model Class Initialized
INFO - 2018-03-28 16:05:17 --> Model Class Initialized
INFO - 2018-03-28 16:05:17 --> Model Class Initialized
INFO - 2018-03-28 16:05:17 --> Model Class Initialized
INFO - 2018-03-28 16:05:17 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 16:05:18 --> Final output sent to browser
DEBUG - 2018-03-28 16:05:18 --> Total execution time: 1.4429
INFO - 2018-03-28 10:35:18 --> Language Class Initialized
INFO - 2018-03-28 10:35:18 --> Config Class Initialized
INFO - 2018-03-28 10:35:18 --> Loader Class Initialized
INFO - 2018-03-28 10:35:18 --> Config Class Initialized
INFO - 2018-03-28 10:35:18 --> Hooks Class Initialized
INFO - 2018-03-28 16:05:18 --> Helper loaded: url_helper
INFO - 2018-03-28 16:05:18 --> Helper loaded: notification_helper
INFO - 2018-03-28 16:05:18 --> Helper loaded: settings_helper
INFO - 2018-03-28 16:05:18 --> Helper loaded: permission_helper
DEBUG - 2018-03-28 10:35:18 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:35:18 --> Utf8 Class Initialized
INFO - 2018-03-28 16:05:18 --> Helper loaded: users_helper
INFO - 2018-03-28 10:35:19 --> URI Class Initialized
INFO - 2018-03-28 10:35:19 --> Router Class Initialized
INFO - 2018-03-28 10:35:19 --> Output Class Initialized
INFO - 2018-03-28 10:35:19 --> Security Class Initialized
DEBUG - 2018-03-28 10:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:35:19 --> Input Class Initialized
INFO - 2018-03-28 10:35:19 --> Language Class Initialized
INFO - 2018-03-28 10:35:19 --> Language Class Initialized
INFO - 2018-03-28 10:35:19 --> Config Class Initialized
INFO - 2018-03-28 10:35:19 --> Loader Class Initialized
INFO - 2018-03-28 16:05:19 --> Helper loaded: url_helper
INFO - 2018-03-28 16:05:19 --> Helper loaded: notification_helper
INFO - 2018-03-28 16:05:19 --> Helper loaded: settings_helper
INFO - 2018-03-28 16:05:19 --> Helper loaded: permission_helper
INFO - 2018-03-28 16:05:19 --> Helper loaded: users_helper
INFO - 2018-03-28 16:05:19 --> Database Driver Class Initialized
DEBUG - 2018-03-28 16:05:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 16:05:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 16:05:20 --> Helper loaded: form_helper
INFO - 2018-03-28 16:05:20 --> Form Validation Class Initialized
INFO - 2018-03-28 16:05:20 --> Controller Class Initialized
INFO - 2018-03-28 16:05:20 --> Database Driver Class Initialized
INFO - 2018-03-28 16:05:20 --> Model Class Initialized
INFO - 2018-03-28 16:05:20 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 16:05:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 16:05:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 16:05:20 --> Model Class Initialized
INFO - 2018-03-28 16:05:20 --> Model Class Initialized
INFO - 2018-03-28 16:05:20 --> Model Class Initialized
INFO - 2018-03-28 16:05:20 --> Model Class Initialized
INFO - 2018-03-28 16:05:20 --> Model Class Initialized
INFO - 2018-03-28 16:05:20 --> Model Class Initialized
INFO - 2018-03-28 16:05:20 --> Model Class Initialized
INFO - 2018-03-28 16:05:20 --> Model Class Initialized
INFO - 2018-03-28 16:05:20 --> Model Class Initialized
INFO - 2018-03-28 16:05:20 --> Model Class Initialized
INFO - 2018-03-28 16:05:20 --> Model Class Initialized
INFO - 2018-03-28 16:05:20 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 16:05:20 --> Final output sent to browser
DEBUG - 2018-03-28 16:05:20 --> Total execution time: 5.6362
DEBUG - 2018-03-28 16:05:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 16:05:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 16:05:20 --> Helper loaded: form_helper
INFO - 2018-03-28 16:05:20 --> Form Validation Class Initialized
INFO - 2018-03-28 16:05:20 --> Controller Class Initialized
INFO - 2018-03-28 16:05:20 --> Model Class Initialized
INFO - 2018-03-28 16:05:20 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 16:05:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 16:05:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 16:05:20 --> Model Class Initialized
INFO - 2018-03-28 16:05:20 --> Model Class Initialized
INFO - 2018-03-28 16:05:20 --> Model Class Initialized
INFO - 2018-03-28 16:05:20 --> Model Class Initialized
INFO - 2018-03-28 16:05:20 --> Model Class Initialized
INFO - 2018-03-28 16:05:20 --> Model Class Initialized
INFO - 2018-03-28 16:05:20 --> Model Class Initialized
INFO - 2018-03-28 16:05:20 --> Model Class Initialized
INFO - 2018-03-28 16:05:20 --> Model Class Initialized
INFO - 2018-03-28 16:05:20 --> Model Class Initialized
INFO - 2018-03-28 16:05:20 --> Model Class Initialized
INFO - 2018-03-28 16:05:20 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 16:05:20 --> Final output sent to browser
DEBUG - 2018-03-28 16:05:20 --> Total execution time: 2.0832
INFO - 2018-03-28 10:44:05 --> Config Class Initialized
INFO - 2018-03-28 10:44:05 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:44:05 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:44:05 --> Utf8 Class Initialized
INFO - 2018-03-28 10:44:06 --> URI Class Initialized
INFO - 2018-03-28 10:44:06 --> Router Class Initialized
INFO - 2018-03-28 10:44:06 --> Output Class Initialized
INFO - 2018-03-28 10:44:06 --> Security Class Initialized
DEBUG - 2018-03-28 10:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:44:06 --> Input Class Initialized
INFO - 2018-03-28 10:44:06 --> Language Class Initialized
INFO - 2018-03-28 10:44:07 --> Language Class Initialized
INFO - 2018-03-28 10:44:07 --> Config Class Initialized
INFO - 2018-03-28 10:44:07 --> Loader Class Initialized
INFO - 2018-03-28 16:14:07 --> Helper loaded: url_helper
INFO - 2018-03-28 16:14:07 --> Helper loaded: notification_helper
INFO - 2018-03-28 16:14:07 --> Helper loaded: settings_helper
INFO - 2018-03-28 16:14:07 --> Helper loaded: permission_helper
INFO - 2018-03-28 16:14:07 --> Helper loaded: users_helper
INFO - 2018-03-28 16:14:08 --> Database Driver Class Initialized
DEBUG - 2018-03-28 16:14:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 16:14:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 16:14:08 --> Helper loaded: form_helper
INFO - 2018-03-28 16:14:08 --> Form Validation Class Initialized
INFO - 2018-03-28 16:14:08 --> Controller Class Initialized
INFO - 2018-03-28 16:14:09 --> Model Class Initialized
INFO - 2018-03-28 16:14:09 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 16:14:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 16:14:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 16:14:09 --> Model Class Initialized
INFO - 2018-03-28 16:14:09 --> Model Class Initialized
INFO - 2018-03-28 16:14:09 --> Model Class Initialized
INFO - 2018-03-28 16:14:09 --> Model Class Initialized
INFO - 2018-03-28 16:14:09 --> Model Class Initialized
INFO - 2018-03-28 16:14:09 --> Model Class Initialized
INFO - 2018-03-28 16:14:09 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 16:14:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-28 16:14:09 --> Final output sent to browser
DEBUG - 2018-03-28 16:14:09 --> Total execution time: 4.1289
INFO - 2018-03-28 10:44:11 --> Config Class Initialized
INFO - 2018-03-28 10:44:11 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:44:11 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:44:11 --> Utf8 Class Initialized
INFO - 2018-03-28 10:44:11 --> URI Class Initialized
INFO - 2018-03-28 10:44:11 --> Router Class Initialized
INFO - 2018-03-28 10:44:11 --> Output Class Initialized
INFO - 2018-03-28 10:44:11 --> Security Class Initialized
DEBUG - 2018-03-28 10:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:44:12 --> Input Class Initialized
INFO - 2018-03-28 10:44:12 --> Language Class Initialized
INFO - 2018-03-28 10:44:12 --> Language Class Initialized
INFO - 2018-03-28 10:44:12 --> Config Class Initialized
INFO - 2018-03-28 10:44:12 --> Loader Class Initialized
INFO - 2018-03-28 16:14:12 --> Helper loaded: url_helper
INFO - 2018-03-28 16:14:12 --> Helper loaded: notification_helper
INFO - 2018-03-28 16:14:12 --> Helper loaded: settings_helper
INFO - 2018-03-28 16:14:12 --> Helper loaded: permission_helper
INFO - 2018-03-28 16:14:12 --> Helper loaded: users_helper
INFO - 2018-03-28 16:14:12 --> Database Driver Class Initialized
DEBUG - 2018-03-28 16:14:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 16:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 16:14:12 --> Helper loaded: form_helper
INFO - 2018-03-28 16:14:12 --> Form Validation Class Initialized
INFO - 2018-03-28 16:14:12 --> Controller Class Initialized
INFO - 2018-03-28 16:14:12 --> Model Class Initialized
INFO - 2018-03-28 16:14:12 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 16:14:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 16:14:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 16:14:12 --> Model Class Initialized
INFO - 2018-03-28 16:14:12 --> Model Class Initialized
INFO - 2018-03-28 16:14:12 --> Model Class Initialized
INFO - 2018-03-28 16:14:12 --> Model Class Initialized
INFO - 2018-03-28 16:14:12 --> Model Class Initialized
INFO - 2018-03-28 16:14:12 --> Model Class Initialized
INFO - 2018-03-28 16:14:12 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 16:14:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-28 16:14:12 --> Final output sent to browser
DEBUG - 2018-03-28 16:14:12 --> Total execution time: 1.5523
INFO - 2018-03-28 10:44:13 --> Config Class Initialized
INFO - 2018-03-28 10:44:13 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:44:13 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:44:13 --> Utf8 Class Initialized
INFO - 2018-03-28 10:44:13 --> URI Class Initialized
INFO - 2018-03-28 10:44:13 --> Router Class Initialized
INFO - 2018-03-28 10:44:13 --> Output Class Initialized
INFO - 2018-03-28 10:44:13 --> Security Class Initialized
DEBUG - 2018-03-28 10:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:44:13 --> Input Class Initialized
INFO - 2018-03-28 10:44:13 --> Language Class Initialized
INFO - 2018-03-28 10:44:13 --> Language Class Initialized
INFO - 2018-03-28 10:44:13 --> Config Class Initialized
INFO - 2018-03-28 10:44:13 --> Loader Class Initialized
INFO - 2018-03-28 16:14:13 --> Helper loaded: url_helper
INFO - 2018-03-28 16:14:13 --> Helper loaded: notification_helper
INFO - 2018-03-28 16:14:13 --> Helper loaded: settings_helper
INFO - 2018-03-28 16:14:13 --> Helper loaded: permission_helper
INFO - 2018-03-28 16:14:13 --> Helper loaded: users_helper
INFO - 2018-03-28 16:14:13 --> Database Driver Class Initialized
DEBUG - 2018-03-28 16:14:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 16:14:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 16:14:13 --> Helper loaded: form_helper
INFO - 2018-03-28 16:14:13 --> Form Validation Class Initialized
INFO - 2018-03-28 16:14:13 --> Controller Class Initialized
INFO - 2018-03-28 16:14:13 --> Model Class Initialized
INFO - 2018-03-28 16:14:13 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 16:14:13 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 16:14:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 16:14:13 --> Model Class Initialized
INFO - 2018-03-28 16:14:13 --> Model Class Initialized
INFO - 2018-03-28 16:14:13 --> Model Class Initialized
INFO - 2018-03-28 16:14:13 --> Model Class Initialized
INFO - 2018-03-28 16:14:13 --> Model Class Initialized
INFO - 2018-03-28 16:14:13 --> Model Class Initialized
INFO - 2018-03-28 16:14:13 --> Model Class Initialized
INFO - 2018-03-28 16:14:13 --> Model Class Initialized
INFO - 2018-03-28 16:14:13 --> Model Class Initialized
INFO - 2018-03-28 16:14:13 --> Model Class Initialized
INFO - 2018-03-28 16:14:13 --> Model Class Initialized
INFO - 2018-03-28 16:14:13 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 16:14:13 --> Model Class Initialized
INFO - 2018-03-28 16:14:13 --> Final output sent to browser
DEBUG - 2018-03-28 16:14:13 --> Total execution time: 0.2881
INFO - 2018-03-28 10:44:13 --> Config Class Initialized
INFO - 2018-03-28 10:44:13 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:44:13 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:44:13 --> Utf8 Class Initialized
INFO - 2018-03-28 10:44:13 --> URI Class Initialized
INFO - 2018-03-28 10:44:13 --> Router Class Initialized
INFO - 2018-03-28 10:44:13 --> Output Class Initialized
INFO - 2018-03-28 10:44:13 --> Security Class Initialized
DEBUG - 2018-03-28 10:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:44:13 --> Input Class Initialized
INFO - 2018-03-28 10:44:13 --> Language Class Initialized
INFO - 2018-03-28 10:44:13 --> Language Class Initialized
INFO - 2018-03-28 10:44:13 --> Config Class Initialized
INFO - 2018-03-28 10:44:13 --> Loader Class Initialized
INFO - 2018-03-28 16:14:13 --> Helper loaded: url_helper
INFO - 2018-03-28 16:14:13 --> Helper loaded: notification_helper
INFO - 2018-03-28 16:14:14 --> Helper loaded: settings_helper
INFO - 2018-03-28 16:14:14 --> Helper loaded: permission_helper
INFO - 2018-03-28 16:14:14 --> Helper loaded: users_helper
INFO - 2018-03-28 16:14:14 --> Database Driver Class Initialized
DEBUG - 2018-03-28 16:14:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 16:14:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 16:14:14 --> Helper loaded: form_helper
INFO - 2018-03-28 16:14:14 --> Form Validation Class Initialized
INFO - 2018-03-28 16:14:14 --> Controller Class Initialized
INFO - 2018-03-28 16:14:14 --> Model Class Initialized
INFO - 2018-03-28 16:14:14 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 16:14:14 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 16:14:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 16:14:14 --> Model Class Initialized
INFO - 2018-03-28 16:14:14 --> Model Class Initialized
INFO - 2018-03-28 16:14:14 --> Model Class Initialized
INFO - 2018-03-28 16:14:14 --> Model Class Initialized
INFO - 2018-03-28 16:14:14 --> Model Class Initialized
INFO - 2018-03-28 16:14:14 --> Model Class Initialized
INFO - 2018-03-28 16:14:14 --> Model Class Initialized
INFO - 2018-03-28 16:14:14 --> Model Class Initialized
INFO - 2018-03-28 16:14:14 --> Model Class Initialized
INFO - 2018-03-28 16:14:14 --> Model Class Initialized
INFO - 2018-03-28 16:14:14 --> Model Class Initialized
INFO - 2018-03-28 16:14:14 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 16:14:14 --> Model Class Initialized
INFO - 2018-03-28 16:14:14 --> Final output sent to browser
DEBUG - 2018-03-28 16:14:14 --> Total execution time: 0.1415
INFO - 2018-03-28 10:44:17 --> Config Class Initialized
INFO - 2018-03-28 10:44:17 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:44:17 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:44:17 --> Utf8 Class Initialized
INFO - 2018-03-28 10:44:17 --> URI Class Initialized
INFO - 2018-03-28 10:44:17 --> Router Class Initialized
INFO - 2018-03-28 10:44:17 --> Output Class Initialized
INFO - 2018-03-28 10:44:17 --> Security Class Initialized
DEBUG - 2018-03-28 10:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:44:17 --> Input Class Initialized
INFO - 2018-03-28 10:44:17 --> Language Class Initialized
INFO - 2018-03-28 10:44:18 --> Language Class Initialized
INFO - 2018-03-28 10:44:18 --> Config Class Initialized
INFO - 2018-03-28 10:44:18 --> Loader Class Initialized
INFO - 2018-03-28 16:14:18 --> Helper loaded: url_helper
INFO - 2018-03-28 16:14:18 --> Helper loaded: notification_helper
INFO - 2018-03-28 16:14:18 --> Helper loaded: settings_helper
INFO - 2018-03-28 16:14:18 --> Helper loaded: permission_helper
INFO - 2018-03-28 10:44:18 --> Config Class Initialized
INFO - 2018-03-28 10:44:18 --> Hooks Class Initialized
INFO - 2018-03-28 16:14:18 --> Helper loaded: users_helper
DEBUG - 2018-03-28 10:44:18 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:44:18 --> Utf8 Class Initialized
INFO - 2018-03-28 10:44:18 --> URI Class Initialized
INFO - 2018-03-28 10:44:18 --> Router Class Initialized
INFO - 2018-03-28 16:14:18 --> Database Driver Class Initialized
INFO - 2018-03-28 10:44:19 --> Output Class Initialized
DEBUG - 2018-03-28 16:14:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 16:14:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 10:44:19 --> Security Class Initialized
INFO - 2018-03-28 16:14:19 --> Helper loaded: form_helper
INFO - 2018-03-28 16:14:19 --> Form Validation Class Initialized
INFO - 2018-03-28 16:14:19 --> Controller Class Initialized
DEBUG - 2018-03-28 10:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:44:19 --> Input Class Initialized
INFO - 2018-03-28 10:44:19 --> Config Class Initialized
INFO - 2018-03-28 10:44:19 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:44:19 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:44:19 --> Utf8 Class Initialized
INFO - 2018-03-28 10:44:19 --> URI Class Initialized
INFO - 2018-03-28 10:44:19 --> Router Class Initialized
INFO - 2018-03-28 10:44:19 --> Output Class Initialized
INFO - 2018-03-28 10:44:19 --> Security Class Initialized
INFO - 2018-03-28 10:44:19 --> Language Class Initialized
DEBUG - 2018-03-28 10:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:44:19 --> Input Class Initialized
INFO - 2018-03-28 10:44:19 --> Language Class Initialized
INFO - 2018-03-28 10:44:19 --> Language Class Initialized
INFO - 2018-03-28 10:44:19 --> Config Class Initialized
INFO - 2018-03-28 10:44:19 --> Loader Class Initialized
INFO - 2018-03-28 16:14:19 --> Helper loaded: url_helper
INFO - 2018-03-28 16:14:19 --> Helper loaded: notification_helper
INFO - 2018-03-28 16:14:19 --> Helper loaded: settings_helper
INFO - 2018-03-28 16:14:19 --> Helper loaded: permission_helper
INFO - 2018-03-28 16:14:19 --> Helper loaded: users_helper
INFO - 2018-03-28 16:14:19 --> Database Driver Class Initialized
DEBUG - 2018-03-28 16:14:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 16:14:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 16:14:19 --> Helper loaded: form_helper
INFO - 2018-03-28 16:14:19 --> Form Validation Class Initialized
INFO - 2018-03-28 16:14:19 --> Controller Class Initialized
INFO - 2018-03-28 16:14:19 --> Model Class Initialized
INFO - 2018-03-28 16:14:19 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 16:14:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 16:14:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 16:14:19 --> Model Class Initialized
INFO - 2018-03-28 16:14:19 --> Model Class Initialized
INFO - 2018-03-28 16:14:19 --> Model Class Initialized
INFO - 2018-03-28 16:14:19 --> Model Class Initialized
INFO - 2018-03-28 16:14:19 --> Model Class Initialized
INFO - 2018-03-28 16:14:19 --> Model Class Initialized
INFO - 2018-03-28 16:14:19 --> Model Class Initialized
INFO - 2018-03-28 16:14:19 --> Model Class Initialized
INFO - 2018-03-28 16:14:19 --> Model Class Initialized
INFO - 2018-03-28 16:14:19 --> Model Class Initialized
INFO - 2018-03-28 16:14:19 --> Model Class Initialized
INFO - 2018-03-28 16:14:19 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 16:14:19 --> Final output sent to browser
DEBUG - 2018-03-28 16:14:19 --> Total execution time: 0.1321
INFO - 2018-03-28 16:14:19 --> Model Class Initialized
INFO - 2018-03-28 16:14:19 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 16:14:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 16:14:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 16:14:20 --> Model Class Initialized
INFO - 2018-03-28 16:14:20 --> Model Class Initialized
INFO - 2018-03-28 16:14:20 --> Model Class Initialized
INFO - 2018-03-28 10:44:20 --> Config Class Initialized
INFO - 2018-03-28 10:44:20 --> Hooks Class Initialized
INFO - 2018-03-28 16:14:20 --> Model Class Initialized
INFO - 2018-03-28 16:14:20 --> Model Class Initialized
INFO - 2018-03-28 16:14:20 --> Model Class Initialized
INFO - 2018-03-28 16:14:20 --> Model Class Initialized
INFO - 2018-03-28 16:14:20 --> Model Class Initialized
INFO - 2018-03-28 16:14:20 --> Model Class Initialized
INFO - 2018-03-28 16:14:20 --> Model Class Initialized
INFO - 2018-03-28 16:14:20 --> Model Class Initialized
INFO - 2018-03-28 16:14:20 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 16:14:20 --> Final output sent to browser
DEBUG - 2018-03-28 16:14:20 --> Total execution time: 3.0345
DEBUG - 2018-03-28 10:44:20 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:44:20 --> Utf8 Class Initialized
INFO - 2018-03-28 10:44:20 --> URI Class Initialized
INFO - 2018-03-28 10:44:20 --> Router Class Initialized
INFO - 2018-03-28 10:44:20 --> Output Class Initialized
INFO - 2018-03-28 10:44:20 --> Security Class Initialized
DEBUG - 2018-03-28 10:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:44:20 --> Input Class Initialized
INFO - 2018-03-28 10:44:20 --> Language Class Initialized
INFO - 2018-03-28 10:44:20 --> Language Class Initialized
INFO - 2018-03-28 10:44:20 --> Config Class Initialized
INFO - 2018-03-28 10:44:20 --> Loader Class Initialized
INFO - 2018-03-28 16:14:20 --> Helper loaded: url_helper
INFO - 2018-03-28 16:14:20 --> Helper loaded: notification_helper
INFO - 2018-03-28 16:14:20 --> Helper loaded: settings_helper
INFO - 2018-03-28 16:14:20 --> Helper loaded: permission_helper
INFO - 2018-03-28 16:14:20 --> Helper loaded: users_helper
INFO - 2018-03-28 16:14:20 --> Database Driver Class Initialized
DEBUG - 2018-03-28 16:14:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 16:14:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 16:14:20 --> Helper loaded: form_helper
INFO - 2018-03-28 16:14:20 --> Form Validation Class Initialized
INFO - 2018-03-28 16:14:20 --> Controller Class Initialized
INFO - 2018-03-28 16:14:20 --> Model Class Initialized
INFO - 2018-03-28 16:14:20 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 16:14:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 16:14:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 16:14:20 --> Model Class Initialized
INFO - 2018-03-28 16:14:20 --> Model Class Initialized
INFO - 2018-03-28 16:14:20 --> Model Class Initialized
INFO - 2018-03-28 16:14:20 --> Model Class Initialized
INFO - 2018-03-28 16:14:20 --> Model Class Initialized
INFO - 2018-03-28 16:14:20 --> Model Class Initialized
INFO - 2018-03-28 16:14:20 --> Model Class Initialized
INFO - 2018-03-28 16:14:20 --> Model Class Initialized
INFO - 2018-03-28 16:14:20 --> Model Class Initialized
INFO - 2018-03-28 16:14:20 --> Model Class Initialized
INFO - 2018-03-28 16:14:20 --> Model Class Initialized
INFO - 2018-03-28 16:14:20 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 16:14:20 --> Model Class Initialized
INFO - 2018-03-28 16:14:20 --> Final output sent to browser
DEBUG - 2018-03-28 16:14:20 --> Total execution time: 0.5553
INFO - 2018-03-28 10:44:20 --> Language Class Initialized
INFO - 2018-03-28 10:44:20 --> Config Class Initialized
INFO - 2018-03-28 10:44:20 --> Loader Class Initialized
INFO - 2018-03-28 16:14:20 --> Helper loaded: url_helper
INFO - 2018-03-28 16:14:20 --> Helper loaded: notification_helper
INFO - 2018-03-28 16:14:21 --> Helper loaded: settings_helper
INFO - 2018-03-28 16:14:21 --> Helper loaded: permission_helper
INFO - 2018-03-28 16:14:21 --> Helper loaded: users_helper
INFO - 2018-03-28 16:14:21 --> Database Driver Class Initialized
DEBUG - 2018-03-28 16:14:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 16:14:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 16:14:21 --> Helper loaded: form_helper
INFO - 2018-03-28 16:14:21 --> Form Validation Class Initialized
INFO - 2018-03-28 16:14:21 --> Controller Class Initialized
INFO - 2018-03-28 16:14:21 --> Model Class Initialized
INFO - 2018-03-28 16:14:21 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 16:14:21 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 16:14:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 16:14:21 --> Model Class Initialized
INFO - 2018-03-28 16:14:21 --> Model Class Initialized
INFO - 2018-03-28 16:14:21 --> Model Class Initialized
INFO - 2018-03-28 16:14:21 --> Model Class Initialized
INFO - 2018-03-28 16:14:21 --> Model Class Initialized
INFO - 2018-03-28 16:14:21 --> Model Class Initialized
INFO - 2018-03-28 16:14:21 --> Model Class Initialized
INFO - 2018-03-28 16:14:21 --> Model Class Initialized
INFO - 2018-03-28 16:14:21 --> Model Class Initialized
INFO - 2018-03-28 16:14:21 --> Model Class Initialized
INFO - 2018-03-28 16:14:21 --> Model Class Initialized
INFO - 2018-03-28 16:14:21 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 16:14:21 --> Model Class Initialized
INFO - 2018-03-28 16:14:21 --> Final output sent to browser
DEBUG - 2018-03-28 16:14:21 --> Total execution time: 3.4715
INFO - 2018-03-28 10:44:25 --> Config Class Initialized
INFO - 2018-03-28 10:44:25 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:44:26 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:44:26 --> Utf8 Class Initialized
INFO - 2018-03-28 10:44:26 --> URI Class Initialized
INFO - 2018-03-28 10:44:26 --> Router Class Initialized
INFO - 2018-03-28 10:44:26 --> Output Class Initialized
INFO - 2018-03-28 10:44:26 --> Security Class Initialized
DEBUG - 2018-03-28 10:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:44:26 --> Input Class Initialized
INFO - 2018-03-28 10:44:27 --> Language Class Initialized
INFO - 2018-03-28 10:44:27 --> Language Class Initialized
INFO - 2018-03-28 10:44:27 --> Config Class Initialized
INFO - 2018-03-28 10:44:27 --> Loader Class Initialized
INFO - 2018-03-28 16:14:27 --> Helper loaded: url_helper
INFO - 2018-03-28 16:14:28 --> Helper loaded: notification_helper
INFO - 2018-03-28 16:14:28 --> Helper loaded: settings_helper
INFO - 2018-03-28 16:14:28 --> Helper loaded: permission_helper
INFO - 2018-03-28 16:14:28 --> Helper loaded: users_helper
INFO - 2018-03-28 10:44:28 --> Config Class Initialized
INFO - 2018-03-28 10:44:28 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:44:28 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:44:28 --> Utf8 Class Initialized
INFO - 2018-03-28 10:44:28 --> URI Class Initialized
INFO - 2018-03-28 10:44:28 --> Router Class Initialized
INFO - 2018-03-28 10:44:28 --> Output Class Initialized
INFO - 2018-03-28 10:44:28 --> Security Class Initialized
DEBUG - 2018-03-28 10:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:44:28 --> Input Class Initialized
INFO - 2018-03-28 10:44:28 --> Language Class Initialized
INFO - 2018-03-28 10:44:28 --> Language Class Initialized
INFO - 2018-03-28 10:44:28 --> Config Class Initialized
INFO - 2018-03-28 10:44:28 --> Loader Class Initialized
INFO - 2018-03-28 16:14:28 --> Helper loaded: url_helper
INFO - 2018-03-28 16:14:28 --> Helper loaded: notification_helper
INFO - 2018-03-28 16:14:28 --> Helper loaded: settings_helper
INFO - 2018-03-28 16:14:28 --> Helper loaded: permission_helper
INFO - 2018-03-28 16:14:28 --> Helper loaded: users_helper
INFO - 2018-03-28 16:14:28 --> Database Driver Class Initialized
DEBUG - 2018-03-28 16:14:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 16:14:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 16:14:28 --> Helper loaded: form_helper
INFO - 2018-03-28 16:14:28 --> Form Validation Class Initialized
INFO - 2018-03-28 16:14:28 --> Controller Class Initialized
INFO - 2018-03-28 16:14:28 --> Model Class Initialized
INFO - 2018-03-28 16:14:28 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 16:14:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 16:14:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 16:14:28 --> Model Class Initialized
INFO - 2018-03-28 16:14:28 --> Model Class Initialized
INFO - 2018-03-28 16:14:28 --> Model Class Initialized
INFO - 2018-03-28 16:14:28 --> Model Class Initialized
INFO - 2018-03-28 16:14:28 --> Model Class Initialized
INFO - 2018-03-28 16:14:28 --> Model Class Initialized
INFO - 2018-03-28 16:14:28 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-28 16:14:28 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-28 16:14:28 --> Final output sent to browser
DEBUG - 2018-03-28 16:14:28 --> Total execution time: 0.1667
INFO - 2018-03-28 16:14:28 --> Database Driver Class Initialized
DEBUG - 2018-03-28 16:14:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 16:14:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 16:14:28 --> Helper loaded: form_helper
INFO - 2018-03-28 16:14:28 --> Form Validation Class Initialized
INFO - 2018-03-28 16:14:28 --> Controller Class Initialized
INFO - 2018-03-28 16:14:29 --> Model Class Initialized
INFO - 2018-03-28 16:14:29 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 16:14:29 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 16:14:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 16:14:29 --> Model Class Initialized
INFO - 2018-03-28 16:14:29 --> Model Class Initialized
INFO - 2018-03-28 16:14:29 --> Model Class Initialized
INFO - 2018-03-28 16:14:29 --> Model Class Initialized
INFO - 2018-03-28 16:14:29 --> Model Class Initialized
INFO - 2018-03-28 16:14:29 --> Model Class Initialized
INFO - 2018-03-28 16:14:29 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-28 16:14:29 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-28 16:14:29 --> Final output sent to browser
DEBUG - 2018-03-28 16:14:29 --> Total execution time: 3.6886
INFO - 2018-03-28 10:44:30 --> Config Class Initialized
INFO - 2018-03-28 10:44:30 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:44:30 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:44:30 --> Utf8 Class Initialized
INFO - 2018-03-28 10:44:30 --> URI Class Initialized
INFO - 2018-03-28 10:44:30 --> Router Class Initialized
INFO - 2018-03-28 10:44:30 --> Output Class Initialized
INFO - 2018-03-28 10:44:30 --> Security Class Initialized
DEBUG - 2018-03-28 10:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:44:30 --> Input Class Initialized
INFO - 2018-03-28 10:44:30 --> Language Class Initialized
INFO - 2018-03-28 10:44:30 --> Config Class Initialized
INFO - 2018-03-28 10:44:30 --> Hooks Class Initialized
INFO - 2018-03-28 10:44:30 --> Language Class Initialized
INFO - 2018-03-28 10:44:30 --> Config Class Initialized
INFO - 2018-03-28 10:44:30 --> Loader Class Initialized
INFO - 2018-03-28 16:14:30 --> Helper loaded: url_helper
DEBUG - 2018-03-28 10:44:30 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:44:30 --> Utf8 Class Initialized
INFO - 2018-03-28 16:14:30 --> Helper loaded: notification_helper
INFO - 2018-03-28 16:14:30 --> Helper loaded: settings_helper
INFO - 2018-03-28 16:14:30 --> Helper loaded: permission_helper
INFO - 2018-03-28 16:14:30 --> Helper loaded: users_helper
INFO - 2018-03-28 10:44:30 --> URI Class Initialized
INFO - 2018-03-28 10:44:30 --> Router Class Initialized
INFO - 2018-03-28 16:14:30 --> Database Driver Class Initialized
DEBUG - 2018-03-28 16:14:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 16:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 10:44:30 --> Output Class Initialized
INFO - 2018-03-28 10:44:30 --> Security Class Initialized
DEBUG - 2018-03-28 10:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:44:30 --> Input Class Initialized
INFO - 2018-03-28 16:14:30 --> Helper loaded: form_helper
INFO - 2018-03-28 16:14:30 --> Form Validation Class Initialized
INFO - 2018-03-28 16:14:30 --> Controller Class Initialized
INFO - 2018-03-28 10:44:30 --> Language Class Initialized
INFO - 2018-03-28 16:14:30 --> Model Class Initialized
INFO - 2018-03-28 16:14:30 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 16:14:30 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 16:14:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 16:14:30 --> Model Class Initialized
INFO - 2018-03-28 16:14:30 --> Model Class Initialized
INFO - 2018-03-28 16:14:30 --> Model Class Initialized
INFO - 2018-03-28 16:14:30 --> Model Class Initialized
INFO - 2018-03-28 16:14:30 --> Model Class Initialized
INFO - 2018-03-28 16:14:30 --> Model Class Initialized
INFO - 2018-03-28 16:14:30 --> Model Class Initialized
INFO - 2018-03-28 16:14:30 --> Model Class Initialized
INFO - 2018-03-28 16:14:30 --> Model Class Initialized
INFO - 2018-03-28 16:14:30 --> Model Class Initialized
INFO - 2018-03-28 16:14:30 --> Model Class Initialized
INFO - 2018-03-28 16:14:30 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 16:14:30 --> Model Class Initialized
INFO - 2018-03-28 16:14:30 --> Final output sent to browser
DEBUG - 2018-03-28 16:14:30 --> Total execution time: 0.1314
INFO - 2018-03-28 10:44:30 --> Config Class Initialized
INFO - 2018-03-28 10:44:30 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:44:30 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:44:30 --> Utf8 Class Initialized
INFO - 2018-03-28 10:44:30 --> Language Class Initialized
INFO - 2018-03-28 10:44:30 --> Config Class Initialized
INFO - 2018-03-28 10:44:30 --> Loader Class Initialized
INFO - 2018-03-28 16:14:30 --> Helper loaded: url_helper
INFO - 2018-03-28 16:14:30 --> Helper loaded: notification_helper
INFO - 2018-03-28 16:14:30 --> Helper loaded: settings_helper
INFO - 2018-03-28 16:14:30 --> Helper loaded: permission_helper
INFO - 2018-03-28 16:14:30 --> Helper loaded: users_helper
INFO - 2018-03-28 10:44:30 --> URI Class Initialized
INFO - 2018-03-28 10:44:30 --> Router Class Initialized
INFO - 2018-03-28 10:44:30 --> Output Class Initialized
INFO - 2018-03-28 16:14:30 --> Database Driver Class Initialized
DEBUG - 2018-03-28 16:14:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 16:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 16:14:30 --> Helper loaded: form_helper
INFO - 2018-03-28 16:14:30 --> Form Validation Class Initialized
INFO - 2018-03-28 16:14:30 --> Controller Class Initialized
INFO - 2018-03-28 10:44:30 --> Config Class Initialized
INFO - 2018-03-28 10:44:30 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:44:30 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:44:30 --> Utf8 Class Initialized
INFO - 2018-03-28 16:14:30 --> Model Class Initialized
INFO - 2018-03-28 10:44:30 --> URI Class Initialized
INFO - 2018-03-28 16:14:30 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 16:14:30 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 16:14:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 16:14:30 --> Model Class Initialized
INFO - 2018-03-28 10:44:30 --> Router Class Initialized
INFO - 2018-03-28 16:14:30 --> Model Class Initialized
INFO - 2018-03-28 16:14:30 --> Model Class Initialized
INFO - 2018-03-28 16:14:30 --> Model Class Initialized
INFO - 2018-03-28 16:14:30 --> Model Class Initialized
INFO - 2018-03-28 16:14:30 --> Model Class Initialized
INFO - 2018-03-28 16:14:30 --> Model Class Initialized
INFO - 2018-03-28 16:14:30 --> Model Class Initialized
INFO - 2018-03-28 16:14:30 --> Model Class Initialized
INFO - 2018-03-28 16:14:30 --> Model Class Initialized
INFO - 2018-03-28 10:44:30 --> Output Class Initialized
INFO - 2018-03-28 16:14:30 --> Model Class Initialized
INFO - 2018-03-28 16:14:30 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 10:44:30 --> Security Class Initialized
DEBUG - 2018-03-28 10:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:44:30 --> Input Class Initialized
INFO - 2018-03-28 16:14:30 --> Final output sent to browser
DEBUG - 2018-03-28 16:14:30 --> Total execution time: 0.2538
INFO - 2018-03-28 10:44:30 --> Language Class Initialized
INFO - 2018-03-28 10:44:30 --> Security Class Initialized
INFO - 2018-03-28 10:44:30 --> Language Class Initialized
INFO - 2018-03-28 10:44:30 --> Config Class Initialized
INFO - 2018-03-28 10:44:30 --> Loader Class Initialized
INFO - 2018-03-28 16:14:30 --> Helper loaded: url_helper
INFO - 2018-03-28 16:14:30 --> Helper loaded: notification_helper
INFO - 2018-03-28 16:14:30 --> Helper loaded: settings_helper
INFO - 2018-03-28 16:14:30 --> Helper loaded: permission_helper
INFO - 2018-03-28 16:14:30 --> Helper loaded: users_helper
INFO - 2018-03-28 16:14:30 --> Database Driver Class Initialized
DEBUG - 2018-03-28 10:44:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-28 16:14:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 16:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 10:44:30 --> Input Class Initialized
INFO - 2018-03-28 16:14:30 --> Helper loaded: form_helper
INFO - 2018-03-28 16:14:30 --> Form Validation Class Initialized
INFO - 2018-03-28 16:14:30 --> Controller Class Initialized
INFO - 2018-03-28 16:14:30 --> Model Class Initialized
INFO - 2018-03-28 16:14:30 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 16:14:30 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 16:14:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 16:14:30 --> Model Class Initialized
INFO - 2018-03-28 16:14:30 --> Model Class Initialized
INFO - 2018-03-28 16:14:30 --> Model Class Initialized
INFO - 2018-03-28 16:14:30 --> Model Class Initialized
INFO - 2018-03-28 16:14:30 --> Model Class Initialized
INFO - 2018-03-28 16:14:30 --> Model Class Initialized
INFO - 2018-03-28 16:14:30 --> Model Class Initialized
INFO - 2018-03-28 16:14:30 --> Model Class Initialized
INFO - 2018-03-28 16:14:30 --> Model Class Initialized
INFO - 2018-03-28 16:14:30 --> Model Class Initialized
INFO - 2018-03-28 16:14:30 --> Model Class Initialized
INFO - 2018-03-28 16:14:30 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 16:14:30 --> Final output sent to browser
DEBUG - 2018-03-28 16:14:30 --> Total execution time: 0.2397
INFO - 2018-03-28 10:44:30 --> Language Class Initialized
INFO - 2018-03-28 10:44:30 --> Config Class Initialized
INFO - 2018-03-28 10:44:30 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:44:30 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:44:30 --> Utf8 Class Initialized
INFO - 2018-03-28 10:44:30 --> URI Class Initialized
INFO - 2018-03-28 10:44:30 --> Router Class Initialized
INFO - 2018-03-28 10:44:30 --> Output Class Initialized
INFO - 2018-03-28 10:44:30 --> Security Class Initialized
DEBUG - 2018-03-28 10:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:44:30 --> Input Class Initialized
INFO - 2018-03-28 10:44:30 --> Language Class Initialized
INFO - 2018-03-28 10:44:31 --> Language Class Initialized
INFO - 2018-03-28 10:44:31 --> Config Class Initialized
INFO - 2018-03-28 10:44:31 --> Loader Class Initialized
INFO - 2018-03-28 16:14:31 --> Helper loaded: url_helper
INFO - 2018-03-28 16:14:31 --> Helper loaded: notification_helper
INFO - 2018-03-28 16:14:31 --> Helper loaded: settings_helper
INFO - 2018-03-28 10:44:31 --> Config Class Initialized
INFO - 2018-03-28 10:44:31 --> Hooks Class Initialized
INFO - 2018-03-28 16:14:31 --> Helper loaded: permission_helper
INFO - 2018-03-28 16:14:31 --> Helper loaded: users_helper
DEBUG - 2018-03-28 10:44:31 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:44:31 --> Utf8 Class Initialized
INFO - 2018-03-28 10:44:31 --> URI Class Initialized
INFO - 2018-03-28 10:44:31 --> Router Class Initialized
INFO - 2018-03-28 10:44:31 --> Output Class Initialized
INFO - 2018-03-28 10:44:31 --> Security Class Initialized
INFO - 2018-03-28 16:14:31 --> Database Driver Class Initialized
DEBUG - 2018-03-28 10:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:44:31 --> Input Class Initialized
INFO - 2018-03-28 10:44:31 --> Language Class Initialized
DEBUG - 2018-03-28 16:14:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 16:14:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 16:14:31 --> Helper loaded: form_helper
INFO - 2018-03-28 16:14:31 --> Form Validation Class Initialized
INFO - 2018-03-28 16:14:31 --> Controller Class Initialized
INFO - 2018-03-28 16:14:31 --> Model Class Initialized
INFO - 2018-03-28 16:14:31 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 16:14:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 16:14:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 10:44:31 --> Language Class Initialized
INFO - 2018-03-28 10:44:31 --> Config Class Initialized
INFO - 2018-03-28 10:44:31 --> Loader Class Initialized
INFO - 2018-03-28 16:14:31 --> Model Class Initialized
INFO - 2018-03-28 16:14:31 --> Model Class Initialized
INFO - 2018-03-28 16:14:31 --> Model Class Initialized
INFO - 2018-03-28 16:14:31 --> Model Class Initialized
INFO - 2018-03-28 16:14:31 --> Model Class Initialized
INFO - 2018-03-28 16:14:31 --> Model Class Initialized
INFO - 2018-03-28 16:14:31 --> Helper loaded: url_helper
INFO - 2018-03-28 16:14:31 --> Model Class Initialized
INFO - 2018-03-28 16:14:31 --> Model Class Initialized
INFO - 2018-03-28 16:14:31 --> Model Class Initialized
INFO - 2018-03-28 16:14:31 --> Model Class Initialized
INFO - 2018-03-28 16:14:31 --> Helper loaded: notification_helper
INFO - 2018-03-28 16:14:31 --> Helper loaded: settings_helper
INFO - 2018-03-28 16:14:31 --> Helper loaded: permission_helper
INFO - 2018-03-28 16:14:31 --> Model Class Initialized
INFO - 2018-03-28 16:14:31 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 16:14:31 --> Helper loaded: users_helper
INFO - 2018-03-28 16:14:31 --> Model Class Initialized
INFO - 2018-03-28 16:14:31 --> Final output sent to browser
DEBUG - 2018-03-28 16:14:31 --> Total execution time: 0.6878
INFO - 2018-03-28 16:14:31 --> Database Driver Class Initialized
DEBUG - 2018-03-28 16:14:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 16:14:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 16:14:31 --> Helper loaded: form_helper
INFO - 2018-03-28 16:14:31 --> Form Validation Class Initialized
INFO - 2018-03-28 16:14:31 --> Controller Class Initialized
INFO - 2018-03-28 16:14:31 --> Model Class Initialized
INFO - 2018-03-28 16:14:31 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 16:14:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 16:14:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 16:14:31 --> Model Class Initialized
INFO - 2018-03-28 16:14:31 --> Model Class Initialized
INFO - 2018-03-28 16:14:31 --> Model Class Initialized
INFO - 2018-03-28 16:14:31 --> Model Class Initialized
INFO - 2018-03-28 16:14:31 --> Model Class Initialized
INFO - 2018-03-28 16:14:31 --> Model Class Initialized
INFO - 2018-03-28 16:14:31 --> Model Class Initialized
INFO - 2018-03-28 16:14:31 --> Model Class Initialized
INFO - 2018-03-28 16:14:31 --> Model Class Initialized
INFO - 2018-03-28 16:14:31 --> Model Class Initialized
INFO - 2018-03-28 16:14:31 --> Model Class Initialized
INFO - 2018-03-28 16:14:31 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 16:14:31 --> Model Class Initialized
INFO - 2018-03-28 16:14:31 --> Final output sent to browser
DEBUG - 2018-03-28 16:14:31 --> Total execution time: 0.1395
INFO - 2018-03-28 10:44:32 --> Language Class Initialized
INFO - 2018-03-28 10:44:32 --> Config Class Initialized
INFO - 2018-03-28 10:44:32 --> Loader Class Initialized
INFO - 2018-03-28 16:14:32 --> Helper loaded: url_helper
INFO - 2018-03-28 16:14:32 --> Helper loaded: notification_helper
INFO - 2018-03-28 16:14:32 --> Helper loaded: settings_helper
INFO - 2018-03-28 16:14:32 --> Helper loaded: permission_helper
INFO - 2018-03-28 16:14:32 --> Helper loaded: users_helper
INFO - 2018-03-28 16:14:32 --> Database Driver Class Initialized
DEBUG - 2018-03-28 16:14:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 16:14:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 16:14:32 --> Helper loaded: form_helper
INFO - 2018-03-28 16:14:32 --> Form Validation Class Initialized
INFO - 2018-03-28 16:14:32 --> Controller Class Initialized
INFO - 2018-03-28 16:14:32 --> Model Class Initialized
INFO - 2018-03-28 16:14:32 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 16:14:32 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 16:14:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 16:14:32 --> Model Class Initialized
INFO - 2018-03-28 16:14:32 --> Model Class Initialized
INFO - 2018-03-28 16:14:32 --> Model Class Initialized
INFO - 2018-03-28 16:14:32 --> Model Class Initialized
INFO - 2018-03-28 16:14:32 --> Model Class Initialized
INFO - 2018-03-28 16:14:32 --> Model Class Initialized
INFO - 2018-03-28 16:14:32 --> Model Class Initialized
INFO - 2018-03-28 16:14:32 --> Model Class Initialized
INFO - 2018-03-28 16:14:32 --> Model Class Initialized
INFO - 2018-03-28 16:14:32 --> Model Class Initialized
INFO - 2018-03-28 16:14:32 --> Model Class Initialized
INFO - 2018-03-28 16:14:32 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 16:14:32 --> Model Class Initialized
INFO - 2018-03-28 16:14:32 --> Final output sent to browser
DEBUG - 2018-03-28 16:14:32 --> Total execution time: 2.3577
INFO - 2018-03-28 10:44:33 --> Config Class Initialized
INFO - 2018-03-28 10:44:33 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:44:33 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:44:33 --> Utf8 Class Initialized
INFO - 2018-03-28 10:44:33 --> URI Class Initialized
INFO - 2018-03-28 10:44:33 --> Router Class Initialized
INFO - 2018-03-28 10:44:33 --> Output Class Initialized
INFO - 2018-03-28 10:44:33 --> Security Class Initialized
DEBUG - 2018-03-28 10:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:44:33 --> Input Class Initialized
INFO - 2018-03-28 10:44:33 --> Language Class Initialized
INFO - 2018-03-28 10:44:33 --> Language Class Initialized
INFO - 2018-03-28 10:44:33 --> Config Class Initialized
INFO - 2018-03-28 10:44:33 --> Loader Class Initialized
INFO - 2018-03-28 16:14:33 --> Helper loaded: url_helper
INFO - 2018-03-28 16:14:33 --> Helper loaded: notification_helper
INFO - 2018-03-28 16:14:33 --> Helper loaded: settings_helper
INFO - 2018-03-28 16:14:33 --> Helper loaded: permission_helper
INFO - 2018-03-28 16:14:33 --> Helper loaded: users_helper
INFO - 2018-03-28 16:14:35 --> Database Driver Class Initialized
DEBUG - 2018-03-28 16:14:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 16:14:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 16:14:35 --> Helper loaded: form_helper
INFO - 2018-03-28 16:14:35 --> Form Validation Class Initialized
INFO - 2018-03-28 16:14:35 --> Controller Class Initialized
INFO - 2018-03-28 16:14:35 --> Model Class Initialized
INFO - 2018-03-28 16:14:35 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 16:14:35 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 16:14:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 16:14:35 --> Model Class Initialized
INFO - 2018-03-28 16:14:35 --> Model Class Initialized
INFO - 2018-03-28 16:14:35 --> Model Class Initialized
INFO - 2018-03-28 16:14:35 --> Model Class Initialized
INFO - 2018-03-28 16:14:35 --> Model Class Initialized
INFO - 2018-03-28 16:14:35 --> Model Class Initialized
INFO - 2018-03-28 16:14:35 --> Model Class Initialized
INFO - 2018-03-28 16:14:35 --> Model Class Initialized
INFO - 2018-03-28 16:14:35 --> Model Class Initialized
INFO - 2018-03-28 16:14:35 --> Model Class Initialized
INFO - 2018-03-28 16:14:35 --> Model Class Initialized
INFO - 2018-03-28 16:14:35 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 16:14:35 --> Model Class Initialized
INFO - 2018-03-28 16:14:35 --> Final output sent to browser
DEBUG - 2018-03-28 16:14:35 --> Total execution time: 2.1853
INFO - 2018-03-28 10:46:20 --> Config Class Initialized
INFO - 2018-03-28 10:46:20 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:46:20 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:46:20 --> Utf8 Class Initialized
INFO - 2018-03-28 10:46:21 --> URI Class Initialized
INFO - 2018-03-28 10:46:21 --> Config Class Initialized
INFO - 2018-03-28 10:46:21 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:46:21 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:46:21 --> Utf8 Class Initialized
INFO - 2018-03-28 10:46:21 --> URI Class Initialized
INFO - 2018-03-28 10:46:21 --> Router Class Initialized
INFO - 2018-03-28 10:46:21 --> Output Class Initialized
INFO - 2018-03-28 10:46:21 --> Security Class Initialized
DEBUG - 2018-03-28 10:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:46:21 --> Input Class Initialized
INFO - 2018-03-28 10:46:21 --> Language Class Initialized
INFO - 2018-03-28 10:46:21 --> Language Class Initialized
INFO - 2018-03-28 10:46:21 --> Config Class Initialized
INFO - 2018-03-28 10:46:21 --> Loader Class Initialized
INFO - 2018-03-28 10:46:21 --> Router Class Initialized
INFO - 2018-03-28 16:16:21 --> Helper loaded: url_helper
INFO - 2018-03-28 16:16:21 --> Helper loaded: notification_helper
INFO - 2018-03-28 16:16:21 --> Helper loaded: settings_helper
INFO - 2018-03-28 10:46:21 --> Output Class Initialized
INFO - 2018-03-28 16:16:21 --> Helper loaded: permission_helper
INFO - 2018-03-28 16:16:21 --> Helper loaded: users_helper
INFO - 2018-03-28 10:46:21 --> Security Class Initialized
DEBUG - 2018-03-28 10:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:46:21 --> Input Class Initialized
INFO - 2018-03-28 10:46:21 --> Language Class Initialized
INFO - 2018-03-28 16:16:21 --> Database Driver Class Initialized
DEBUG - 2018-03-28 16:16:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 16:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 16:16:21 --> Helper loaded: form_helper
INFO - 2018-03-28 16:16:21 --> Form Validation Class Initialized
INFO - 2018-03-28 16:16:21 --> Controller Class Initialized
INFO - 2018-03-28 10:46:21 --> Language Class Initialized
INFO - 2018-03-28 10:46:21 --> Config Class Initialized
INFO - 2018-03-28 10:46:21 --> Loader Class Initialized
INFO - 2018-03-28 16:16:21 --> Model Class Initialized
INFO - 2018-03-28 16:16:21 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 16:16:21 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 16:16:21 --> Helper loaded: url_helper
INFO - 2018-03-28 16:16:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 16:16:21 --> Model Class Initialized
INFO - 2018-03-28 16:16:21 --> Model Class Initialized
INFO - 2018-03-28 16:16:21 --> Model Class Initialized
INFO - 2018-03-28 16:16:21 --> Model Class Initialized
INFO - 2018-03-28 16:16:21 --> Model Class Initialized
INFO - 2018-03-28 16:16:21 --> Helper loaded: notification_helper
INFO - 2018-03-28 16:16:21 --> Helper loaded: settings_helper
INFO - 2018-03-28 16:16:21 --> Helper loaded: permission_helper
INFO - 2018-03-28 16:16:21 --> Helper loaded: users_helper
INFO - 2018-03-28 16:16:21 --> Model Class Initialized
INFO - 2018-03-28 16:16:21 --> Model Class Initialized
INFO - 2018-03-28 16:16:21 --> Model Class Initialized
INFO - 2018-03-28 16:16:21 --> Model Class Initialized
INFO - 2018-03-28 16:16:21 --> Model Class Initialized
INFO - 2018-03-28 16:16:21 --> Model Class Initialized
INFO - 2018-03-28 16:16:21 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 16:16:21 --> Model Class Initialized
INFO - 2018-03-28 16:16:21 --> Final output sent to browser
DEBUG - 2018-03-28 16:16:21 --> Total execution time: 0.3963
INFO - 2018-03-28 16:16:21 --> Database Driver Class Initialized
DEBUG - 2018-03-28 16:16:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 16:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 16:16:21 --> Helper loaded: form_helper
INFO - 2018-03-28 16:16:21 --> Form Validation Class Initialized
INFO - 2018-03-28 16:16:21 --> Controller Class Initialized
INFO - 2018-03-28 16:16:21 --> Model Class Initialized
INFO - 2018-03-28 16:16:21 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 16:16:21 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 16:16:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 16:16:21 --> Model Class Initialized
INFO - 2018-03-28 16:16:21 --> Model Class Initialized
INFO - 2018-03-28 16:16:21 --> Model Class Initialized
INFO - 2018-03-28 16:16:21 --> Model Class Initialized
INFO - 2018-03-28 16:16:21 --> Model Class Initialized
INFO - 2018-03-28 16:16:21 --> Model Class Initialized
INFO - 2018-03-28 16:16:21 --> Model Class Initialized
INFO - 2018-03-28 16:16:21 --> Model Class Initialized
INFO - 2018-03-28 16:16:21 --> Model Class Initialized
INFO - 2018-03-28 16:16:21 --> Model Class Initialized
INFO - 2018-03-28 16:16:21 --> Model Class Initialized
INFO - 2018-03-28 16:16:21 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 16:16:21 --> Model Class Initialized
INFO - 2018-03-28 16:16:21 --> Final output sent to browser
DEBUG - 2018-03-28 16:16:21 --> Total execution time: 1.1349
INFO - 2018-03-28 10:46:23 --> Config Class Initialized
INFO - 2018-03-28 10:46:23 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:46:23 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:46:23 --> Utf8 Class Initialized
INFO - 2018-03-28 10:46:23 --> URI Class Initialized
INFO - 2018-03-28 10:46:23 --> Router Class Initialized
INFO - 2018-03-28 10:46:23 --> Output Class Initialized
INFO - 2018-03-28 10:46:23 --> Security Class Initialized
DEBUG - 2018-03-28 10:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:46:23 --> Input Class Initialized
INFO - 2018-03-28 10:46:23 --> Language Class Initialized
INFO - 2018-03-28 10:46:23 --> Language Class Initialized
INFO - 2018-03-28 10:46:23 --> Config Class Initialized
INFO - 2018-03-28 10:46:23 --> Loader Class Initialized
INFO - 2018-03-28 16:16:23 --> Helper loaded: url_helper
INFO - 2018-03-28 16:16:23 --> Helper loaded: notification_helper
INFO - 2018-03-28 16:16:23 --> Helper loaded: settings_helper
INFO - 2018-03-28 16:16:23 --> Helper loaded: permission_helper
INFO - 2018-03-28 16:16:23 --> Helper loaded: users_helper
INFO - 2018-03-28 16:16:23 --> Database Driver Class Initialized
DEBUG - 2018-03-28 16:16:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 16:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 16:16:23 --> Helper loaded: form_helper
INFO - 2018-03-28 16:16:23 --> Form Validation Class Initialized
INFO - 2018-03-28 16:16:23 --> Controller Class Initialized
INFO - 2018-03-28 16:16:23 --> Model Class Initialized
INFO - 2018-03-28 16:16:23 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 16:16:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 16:16:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 16:16:23 --> Model Class Initialized
INFO - 2018-03-28 16:16:23 --> Model Class Initialized
INFO - 2018-03-28 16:16:23 --> Model Class Initialized
INFO - 2018-03-28 16:16:23 --> Model Class Initialized
INFO - 2018-03-28 16:16:23 --> Model Class Initialized
INFO - 2018-03-28 16:16:23 --> Model Class Initialized
INFO - 2018-03-28 16:16:23 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-28 16:16:23 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-28 16:16:23 --> Final output sent to browser
DEBUG - 2018-03-28 16:16:23 --> Total execution time: 0.1297
INFO - 2018-03-28 10:46:24 --> Config Class Initialized
INFO - 2018-03-28 10:46:24 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:46:25 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:46:25 --> Utf8 Class Initialized
INFO - 2018-03-28 10:46:25 --> URI Class Initialized
INFO - 2018-03-28 10:46:25 --> Router Class Initialized
INFO - 2018-03-28 10:46:25 --> Output Class Initialized
INFO - 2018-03-28 10:46:25 --> Security Class Initialized
DEBUG - 2018-03-28 10:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:46:25 --> Input Class Initialized
INFO - 2018-03-28 10:46:25 --> Language Class Initialized
INFO - 2018-03-28 10:46:26 --> Config Class Initialized
INFO - 2018-03-28 10:46:26 --> Hooks Class Initialized
INFO - 2018-03-28 10:46:26 --> Config Class Initialized
INFO - 2018-03-28 10:46:26 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:46:26 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:46:26 --> Utf8 Class Initialized
INFO - 2018-03-28 10:46:26 --> Language Class Initialized
INFO - 2018-03-28 10:46:26 --> Config Class Initialized
INFO - 2018-03-28 10:46:26 --> Loader Class Initialized
INFO - 2018-03-28 10:46:26 --> URI Class Initialized
DEBUG - 2018-03-28 10:46:26 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:46:26 --> Utf8 Class Initialized
INFO - 2018-03-28 16:16:26 --> Helper loaded: url_helper
INFO - 2018-03-28 16:16:26 --> Helper loaded: notification_helper
INFO - 2018-03-28 10:46:26 --> URI Class Initialized
INFO - 2018-03-28 16:16:26 --> Helper loaded: settings_helper
INFO - 2018-03-28 16:16:26 --> Helper loaded: permission_helper
INFO - 2018-03-28 10:46:26 --> Router Class Initialized
INFO - 2018-03-28 10:46:26 --> Router Class Initialized
INFO - 2018-03-28 16:16:26 --> Helper loaded: users_helper
INFO - 2018-03-28 10:46:26 --> Output Class Initialized
INFO - 2018-03-28 10:46:27 --> Output Class Initialized
INFO - 2018-03-28 10:46:27 --> Security Class Initialized
INFO - 2018-03-28 10:46:27 --> Security Class Initialized
DEBUG - 2018-03-28 10:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:46:27 --> Input Class Initialized
DEBUG - 2018-03-28 10:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:46:27 --> Input Class Initialized
INFO - 2018-03-28 10:46:27 --> Language Class Initialized
INFO - 2018-03-28 10:46:27 --> Language Class Initialized
INFO - 2018-03-28 10:46:27 --> Language Class Initialized
INFO - 2018-03-28 10:46:27 --> Config Class Initialized
INFO - 2018-03-28 10:46:27 --> Loader Class Initialized
INFO - 2018-03-28 16:16:27 --> Helper loaded: url_helper
INFO - 2018-03-28 16:16:27 --> Helper loaded: notification_helper
INFO - 2018-03-28 16:16:27 --> Helper loaded: settings_helper
INFO - 2018-03-28 16:16:27 --> Helper loaded: permission_helper
INFO - 2018-03-28 16:16:27 --> Helper loaded: users_helper
INFO - 2018-03-28 16:16:27 --> Database Driver Class Initialized
DEBUG - 2018-03-28 16:16:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 16:16:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 10:46:27 --> Language Class Initialized
INFO - 2018-03-28 10:46:27 --> Config Class Initialized
INFO - 2018-03-28 10:46:27 --> Loader Class Initialized
INFO - 2018-03-28 16:16:27 --> Helper loaded: form_helper
INFO - 2018-03-28 16:16:27 --> Form Validation Class Initialized
INFO - 2018-03-28 16:16:27 --> Controller Class Initialized
INFO - 2018-03-28 16:16:27 --> Helper loaded: url_helper
INFO - 2018-03-28 16:16:27 --> Helper loaded: notification_helper
INFO - 2018-03-28 16:16:27 --> Helper loaded: settings_helper
INFO - 2018-03-28 16:16:27 --> Helper loaded: permission_helper
INFO - 2018-03-28 16:16:27 --> Helper loaded: users_helper
INFO - 2018-03-28 16:16:27 --> Model Class Initialized
INFO - 2018-03-28 10:46:27 --> Config Class Initialized
INFO - 2018-03-28 10:46:27 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:46:27 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:46:27 --> Utf8 Class Initialized
INFO - 2018-03-28 10:46:27 --> URI Class Initialized
INFO - 2018-03-28 16:16:27 --> Helper loaded: inflector_helper
INFO - 2018-03-28 10:46:27 --> Router Class Initialized
INFO - 2018-03-28 10:46:27 --> Output Class Initialized
INFO - 2018-03-28 10:46:27 --> Security Class Initialized
DEBUG - 2018-03-28 10:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:46:27 --> Input Class Initialized
INFO - 2018-03-28 10:46:27 --> Config Class Initialized
INFO - 2018-03-28 10:46:27 --> Hooks Class Initialized
INFO - 2018-03-28 10:46:27 --> Language Class Initialized
INFO - 2018-03-28 16:16:27 --> Database Driver Class Initialized
DEBUG - 2018-03-28 10:46:27 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:46:27 --> Utf8 Class Initialized
INFO - 2018-03-28 10:46:27 --> URI Class Initialized
INFO - 2018-03-28 10:46:27 --> Router Class Initialized
INFO - 2018-03-28 10:46:27 --> Language Class Initialized
INFO - 2018-03-28 10:46:27 --> Config Class Initialized
INFO - 2018-03-28 10:46:27 --> Loader Class Initialized
INFO - 2018-03-28 10:46:27 --> Output Class Initialized
INFO - 2018-03-28 16:16:27 --> Helper loaded: url_helper
INFO - 2018-03-28 16:16:27 --> Helper loaded: notification_helper
INFO - 2018-03-28 16:16:27 --> Helper loaded: settings_helper
INFO - 2018-03-28 16:16:27 --> Helper loaded: permission_helper
INFO - 2018-03-28 16:16:27 --> Helper loaded: users_helper
INFO - 2018-03-28 10:46:27 --> Security Class Initialized
INFO - 2018-03-28 16:16:27 --> Database Driver Class Initialized
DEBUG - 2018-03-28 16:16:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-28 16:16:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 16:16:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-03-28 16:16:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 16:16:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 10:46:27 --> Config Class Initialized
INFO - 2018-03-28 10:46:27 --> Hooks Class Initialized
INFO - 2018-03-28 16:16:27 --> Helper loaded: form_helper
INFO - 2018-03-28 16:16:27 --> Form Validation Class Initialized
INFO - 2018-03-28 16:16:27 --> Controller Class Initialized
DEBUG - 2018-03-28 10:46:27 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:46:27 --> Utf8 Class Initialized
INFO - 2018-03-28 10:46:27 --> URI Class Initialized
INFO - 2018-03-28 10:46:27 --> Router Class Initialized
INFO - 2018-03-28 10:46:27 --> Output Class Initialized
INFO - 2018-03-28 16:16:27 --> Model Class Initialized
INFO - 2018-03-28 16:16:27 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 10:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:46:27 --> Input Class Initialized
INFO - 2018-03-28 10:46:27 --> Security Class Initialized
DEBUG - 2018-03-28 16:16:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-03-28 10:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:46:27 --> Input Class Initialized
INFO - 2018-03-28 16:16:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 10:46:27 --> Language Class Initialized
INFO - 2018-03-28 16:16:27 --> Model Class Initialized
INFO - 2018-03-28 16:16:27 --> Model Class Initialized
INFO - 2018-03-28 16:16:27 --> Model Class Initialized
INFO - 2018-03-28 16:16:27 --> Model Class Initialized
INFO - 2018-03-28 16:16:27 --> Model Class Initialized
INFO - 2018-03-28 16:16:27 --> Model Class Initialized
INFO - 2018-03-28 16:16:27 --> Model Class Initialized
INFO - 2018-03-28 16:16:27 --> Model Class Initialized
INFO - 2018-03-28 16:16:27 --> Model Class Initialized
INFO - 2018-03-28 16:16:27 --> Model Class Initialized
INFO - 2018-03-28 16:16:27 --> Model Class Initialized
INFO - 2018-03-28 16:16:27 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 16:16:27 --> Model Class Initialized
INFO - 2018-03-28 10:46:27 --> Language Class Initialized
INFO - 2018-03-28 10:46:27 --> Config Class Initialized
INFO - 2018-03-28 10:46:27 --> Loader Class Initialized
INFO - 2018-03-28 16:16:27 --> Helper loaded: url_helper
INFO - 2018-03-28 16:16:27 --> Helper loaded: notification_helper
INFO - 2018-03-28 16:16:27 --> Helper loaded: settings_helper
INFO - 2018-03-28 16:16:27 --> Helper loaded: permission_helper
INFO - 2018-03-28 16:16:27 --> Helper loaded: users_helper
INFO - 2018-03-28 16:16:27 --> Final output sent to browser
DEBUG - 2018-03-28 16:16:27 --> Total execution time: 0.2799
INFO - 2018-03-28 16:16:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 10:46:27 --> Language Class Initialized
INFO - 2018-03-28 16:16:27 --> Database Driver Class Initialized
DEBUG - 2018-03-28 16:16:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 16:16:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 16:16:27 --> Helper loaded: form_helper
INFO - 2018-03-28 16:16:27 --> Form Validation Class Initialized
INFO - 2018-03-28 16:16:27 --> Controller Class Initialized
INFO - 2018-03-28 16:16:27 --> Helper loaded: form_helper
INFO - 2018-03-28 16:16:27 --> Form Validation Class Initialized
INFO - 2018-03-28 16:16:27 --> Controller Class Initialized
INFO - 2018-03-28 16:16:27 --> Model Class Initialized
INFO - 2018-03-28 16:16:27 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 16:16:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 16:16:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 16:16:27 --> Model Class Initialized
INFO - 2018-03-28 16:16:27 --> Model Class Initialized
INFO - 2018-03-28 16:16:27 --> Model Class Initialized
INFO - 2018-03-28 16:16:27 --> Model Class Initialized
INFO - 2018-03-28 16:16:27 --> Model Class Initialized
INFO - 2018-03-28 16:16:27 --> Model Class Initialized
INFO - 2018-03-28 16:16:27 --> Model Class Initialized
INFO - 2018-03-28 16:16:27 --> Model Class Initialized
INFO - 2018-03-28 16:16:27 --> Model Class Initialized
INFO - 2018-03-28 16:16:27 --> Model Class Initialized
INFO - 2018-03-28 16:16:27 --> Model Class Initialized
INFO - 2018-03-28 16:16:27 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 16:16:28 --> Model Class Initialized
INFO - 2018-03-28 16:16:28 --> Final output sent to browser
DEBUG - 2018-03-28 16:16:28 --> Total execution time: 0.2014
INFO - 2018-03-28 16:16:28 --> Model Class Initialized
INFO - 2018-03-28 16:16:28 --> Model Class Initialized
INFO - 2018-03-28 10:46:28 --> Language Class Initialized
INFO - 2018-03-28 10:46:28 --> Config Class Initialized
INFO - 2018-03-28 10:46:28 --> Loader Class Initialized
INFO - 2018-03-28 16:16:28 --> Model Class Initialized
INFO - 2018-03-28 16:16:28 --> Helper loaded: url_helper
INFO - 2018-03-28 16:16:28 --> Helper loaded: notification_helper
INFO - 2018-03-28 16:16:28 --> Model Class Initialized
INFO - 2018-03-28 16:16:28 --> Helper loaded: settings_helper
INFO - 2018-03-28 16:16:28 --> Model Class Initialized
INFO - 2018-03-28 16:16:28 --> Helper loaded: permission_helper
INFO - 2018-03-28 16:16:28 --> Helper loaded: users_helper
INFO - 2018-03-28 16:16:28 --> Model Class Initialized
INFO - 2018-03-28 16:16:28 --> Helper loaded: inflector_helper
INFO - 2018-03-28 16:16:28 --> Model Class Initialized
INFO - 2018-03-28 16:16:28 --> Model Class Initialized
INFO - 2018-03-28 16:16:28 --> Model Class Initialized
INFO - 2018-03-28 16:16:28 --> Model Class Initialized
INFO - 2018-03-28 16:16:28 --> Model Class Initialized
INFO - 2018-03-28 16:16:28 --> Database Driver Class Initialized
DEBUG - 2018-03-28 16:16:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 16:16:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-03-28 16:16:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 16:16:28 --> Helper loaded: form_helper
INFO - 2018-03-28 16:16:28 --> Form Validation Class Initialized
INFO - 2018-03-28 16:16:28 --> Controller Class Initialized
INFO - 2018-03-28 16:16:28 --> Database Driver Class Initialized
INFO - 2018-03-28 16:16:28 --> Model Class Initialized
INFO - 2018-03-28 16:16:28 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 16:16:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 16:16:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 16:16:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 16:16:28 --> Model Class Initialized
INFO - 2018-03-28 16:16:28 --> Model Class Initialized
INFO - 2018-03-28 16:16:28 --> Model Class Initialized
INFO - 2018-03-28 16:16:28 --> Model Class Initialized
INFO - 2018-03-28 16:16:28 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 16:16:28 --> Model Class Initialized
INFO - 2018-03-28 16:16:28 --> Model Class Initialized
INFO - 2018-03-28 16:16:28 --> Model Class Initialized
INFO - 2018-03-28 16:16:28 --> Model Class Initialized
INFO - 2018-03-28 16:16:28 --> Model Class Initialized
INFO - 2018-03-28 16:16:28 --> Model Class Initialized
INFO - 2018-03-28 16:16:28 --> Model Class Initialized
INFO - 2018-03-28 16:16:28 --> Model Class Initialized
DEBUG - 2018-03-28 16:16:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 16:16:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 16:16:28 --> Model Class Initialized
INFO - 2018-03-28 16:16:28 --> Model Class Initialized
INFO - 2018-03-28 16:16:28 --> Model Class Initialized
INFO - 2018-03-28 16:16:28 --> Model Class Initialized
INFO - 2018-03-28 16:16:28 --> Model Class Initialized
INFO - 2018-03-28 16:16:28 --> Model Class Initialized
INFO - 2018-03-28 16:16:28 --> Model Class Initialized
INFO - 2018-03-28 16:16:28 --> Model Class Initialized
INFO - 2018-03-28 16:16:28 --> Model Class Initialized
INFO - 2018-03-28 16:16:28 --> Model Class Initialized
INFO - 2018-03-28 16:16:28 --> Final output sent to browser
DEBUG - 2018-03-28 16:16:28 --> Total execution time: 2.3714
INFO - 2018-03-28 16:16:28 --> Model Class Initialized
INFO - 2018-03-28 16:16:28 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 16:16:28 --> Model Class Initialized
INFO - 2018-03-28 16:16:28 --> Model Class Initialized
INFO - 2018-03-28 16:16:28 --> Final output sent to browser
DEBUG - 2018-03-28 16:16:28 --> Total execution time: 0.9798
INFO - 2018-03-28 16:16:28 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 16:16:28 --> Model Class Initialized
INFO - 2018-03-28 16:16:28 --> Helper loaded: form_helper
INFO - 2018-03-28 16:16:28 --> Form Validation Class Initialized
INFO - 2018-03-28 16:16:28 --> Controller Class Initialized
INFO - 2018-03-28 16:16:28 --> Final output sent to browser
DEBUG - 2018-03-28 16:16:28 --> Total execution time: 3.8445
INFO - 2018-03-28 16:16:28 --> Model Class Initialized
INFO - 2018-03-28 16:16:28 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 16:16:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 16:16:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 16:16:28 --> Model Class Initialized
INFO - 2018-03-28 16:16:28 --> Model Class Initialized
INFO - 2018-03-28 16:16:29 --> Model Class Initialized
INFO - 2018-03-28 16:16:29 --> Model Class Initialized
INFO - 2018-03-28 16:16:29 --> Model Class Initialized
INFO - 2018-03-28 16:16:29 --> Model Class Initialized
INFO - 2018-03-28 16:16:29 --> Model Class Initialized
INFO - 2018-03-28 16:16:29 --> Model Class Initialized
INFO - 2018-03-28 16:16:29 --> Model Class Initialized
INFO - 2018-03-28 16:16:29 --> Model Class Initialized
INFO - 2018-03-28 16:16:29 --> Model Class Initialized
INFO - 2018-03-28 16:16:29 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 16:16:29 --> Model Class Initialized
INFO - 2018-03-28 16:16:29 --> Final output sent to browser
DEBUG - 2018-03-28 16:16:29 --> Total execution time: 3.3717
INFO - 2018-03-28 10:48:22 --> Config Class Initialized
INFO - 2018-03-28 10:48:22 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:48:22 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:48:22 --> Utf8 Class Initialized
INFO - 2018-03-28 10:48:22 --> URI Class Initialized
INFO - 2018-03-28 10:48:22 --> Router Class Initialized
INFO - 2018-03-28 10:48:22 --> Output Class Initialized
INFO - 2018-03-28 10:48:22 --> Security Class Initialized
DEBUG - 2018-03-28 10:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:48:22 --> Input Class Initialized
INFO - 2018-03-28 10:48:22 --> Language Class Initialized
INFO - 2018-03-28 10:48:22 --> Language Class Initialized
INFO - 2018-03-28 10:48:22 --> Config Class Initialized
INFO - 2018-03-28 10:48:22 --> Loader Class Initialized
INFO - 2018-03-28 16:18:22 --> Helper loaded: url_helper
INFO - 2018-03-28 16:18:22 --> Helper loaded: notification_helper
INFO - 2018-03-28 16:18:22 --> Helper loaded: settings_helper
INFO - 2018-03-28 16:18:22 --> Helper loaded: permission_helper
INFO - 2018-03-28 16:18:22 --> Helper loaded: users_helper
INFO - 2018-03-28 16:18:23 --> Database Driver Class Initialized
DEBUG - 2018-03-28 16:18:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 16:18:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 16:18:23 --> Helper loaded: form_helper
INFO - 2018-03-28 16:18:23 --> Form Validation Class Initialized
INFO - 2018-03-28 16:18:23 --> Controller Class Initialized
INFO - 2018-03-28 16:18:23 --> Model Class Initialized
INFO - 2018-03-28 16:18:23 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 16:18:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 16:18:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 16:18:23 --> Model Class Initialized
INFO - 2018-03-28 16:18:23 --> Model Class Initialized
INFO - 2018-03-28 16:18:23 --> Model Class Initialized
INFO - 2018-03-28 16:18:23 --> Model Class Initialized
INFO - 2018-03-28 16:18:23 --> Model Class Initialized
INFO - 2018-03-28 16:18:23 --> Model Class Initialized
INFO - 2018-03-28 16:18:23 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 16:18:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-28 16:18:23 --> Final output sent to browser
DEBUG - 2018-03-28 16:18:23 --> Total execution time: 0.1125
INFO - 2018-03-28 10:48:24 --> Config Class Initialized
INFO - 2018-03-28 10:48:24 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:48:24 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:48:24 --> Utf8 Class Initialized
INFO - 2018-03-28 10:48:24 --> URI Class Initialized
INFO - 2018-03-28 10:48:25 --> Router Class Initialized
INFO - 2018-03-28 10:48:25 --> Output Class Initialized
INFO - 2018-03-28 10:48:25 --> Security Class Initialized
DEBUG - 2018-03-28 10:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:48:25 --> Input Class Initialized
INFO - 2018-03-28 10:48:25 --> Language Class Initialized
INFO - 2018-03-28 10:48:25 --> Language Class Initialized
INFO - 2018-03-28 10:48:25 --> Config Class Initialized
INFO - 2018-03-28 10:48:25 --> Loader Class Initialized
INFO - 2018-03-28 16:18:25 --> Helper loaded: url_helper
INFO - 2018-03-28 16:18:25 --> Helper loaded: notification_helper
INFO - 2018-03-28 16:18:25 --> Helper loaded: settings_helper
INFO - 2018-03-28 16:18:25 --> Helper loaded: permission_helper
INFO - 2018-03-28 16:18:25 --> Helper loaded: users_helper
INFO - 2018-03-28 16:18:25 --> Database Driver Class Initialized
DEBUG - 2018-03-28 16:18:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 16:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 16:18:25 --> Helper loaded: form_helper
INFO - 2018-03-28 16:18:25 --> Form Validation Class Initialized
INFO - 2018-03-28 16:18:25 --> Controller Class Initialized
INFO - 2018-03-28 10:48:25 --> Config Class Initialized
INFO - 2018-03-28 10:48:25 --> Hooks Class Initialized
INFO - 2018-03-28 16:18:25 --> Model Class Initialized
INFO - 2018-03-28 16:18:25 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 16:18:25 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 16:18:25 --> Language file loaded: language/english/rest_controller_lang.php
DEBUG - 2018-03-28 10:48:25 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:48:25 --> Utf8 Class Initialized
INFO - 2018-03-28 16:18:25 --> Model Class Initialized
INFO - 2018-03-28 16:18:25 --> Model Class Initialized
INFO - 2018-03-28 10:48:25 --> URI Class Initialized
INFO - 2018-03-28 16:18:25 --> Model Class Initialized
INFO - 2018-03-28 16:18:25 --> Model Class Initialized
INFO - 2018-03-28 16:18:25 --> Model Class Initialized
INFO - 2018-03-28 16:18:25 --> Model Class Initialized
INFO - 2018-03-28 16:18:25 --> Model Class Initialized
INFO - 2018-03-28 16:18:25 --> Model Class Initialized
INFO - 2018-03-28 16:18:25 --> Model Class Initialized
INFO - 2018-03-28 16:18:25 --> Model Class Initialized
INFO - 2018-03-28 16:18:26 --> Model Class Initialized
INFO - 2018-03-28 16:18:26 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 16:18:26 --> Model Class Initialized
INFO - 2018-03-28 16:18:26 --> Final output sent to browser
DEBUG - 2018-03-28 16:18:26 --> Total execution time: 1.2605
INFO - 2018-03-28 10:48:26 --> Router Class Initialized
INFO - 2018-03-28 10:48:26 --> Output Class Initialized
INFO - 2018-03-28 10:48:26 --> Security Class Initialized
DEBUG - 2018-03-28 10:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:48:26 --> Input Class Initialized
INFO - 2018-03-28 10:48:26 --> Language Class Initialized
INFO - 2018-03-28 10:48:27 --> Language Class Initialized
INFO - 2018-03-28 10:48:27 --> Config Class Initialized
INFO - 2018-03-28 10:48:27 --> Loader Class Initialized
INFO - 2018-03-28 16:18:27 --> Helper loaded: url_helper
INFO - 2018-03-28 16:18:27 --> Helper loaded: notification_helper
INFO - 2018-03-28 16:18:27 --> Helper loaded: settings_helper
INFO - 2018-03-28 16:18:27 --> Helper loaded: permission_helper
INFO - 2018-03-28 16:18:27 --> Helper loaded: users_helper
INFO - 2018-03-28 10:48:28 --> Config Class Initialized
INFO - 2018-03-28 10:48:28 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:48:28 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:48:28 --> Utf8 Class Initialized
INFO - 2018-03-28 10:48:28 --> URI Class Initialized
INFO - 2018-03-28 10:48:28 --> Router Class Initialized
INFO - 2018-03-28 10:48:28 --> Output Class Initialized
INFO - 2018-03-28 10:48:28 --> Security Class Initialized
DEBUG - 2018-03-28 10:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:48:28 --> Input Class Initialized
INFO - 2018-03-28 10:48:28 --> Language Class Initialized
INFO - 2018-03-28 10:48:28 --> Language Class Initialized
INFO - 2018-03-28 10:48:28 --> Config Class Initialized
INFO - 2018-03-28 10:48:28 --> Loader Class Initialized
INFO - 2018-03-28 16:18:28 --> Helper loaded: url_helper
INFO - 2018-03-28 16:18:28 --> Helper loaded: notification_helper
INFO - 2018-03-28 16:18:28 --> Helper loaded: settings_helper
INFO - 2018-03-28 16:18:28 --> Helper loaded: permission_helper
INFO - 2018-03-28 16:18:28 --> Helper loaded: users_helper
INFO - 2018-03-28 16:18:28 --> Database Driver Class Initialized
DEBUG - 2018-03-28 16:18:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 16:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 16:18:28 --> Helper loaded: form_helper
INFO - 2018-03-28 16:18:28 --> Form Validation Class Initialized
INFO - 2018-03-28 16:18:28 --> Controller Class Initialized
INFO - 2018-03-28 16:18:28 --> Model Class Initialized
INFO - 2018-03-28 16:18:28 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 16:18:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 16:18:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 16:18:28 --> Model Class Initialized
INFO - 2018-03-28 16:18:28 --> Model Class Initialized
INFO - 2018-03-28 16:18:28 --> Model Class Initialized
INFO - 2018-03-28 16:18:28 --> Model Class Initialized
INFO - 2018-03-28 16:18:28 --> Model Class Initialized
INFO - 2018-03-28 16:18:28 --> Model Class Initialized
INFO - 2018-03-28 16:18:28 --> Model Class Initialized
INFO - 2018-03-28 16:18:28 --> Model Class Initialized
INFO - 2018-03-28 16:18:28 --> Model Class Initialized
INFO - 2018-03-28 16:18:28 --> Model Class Initialized
INFO - 2018-03-28 16:18:28 --> Model Class Initialized
INFO - 2018-03-28 16:18:28 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 16:18:28 --> Model Class Initialized
INFO - 2018-03-28 16:18:28 --> Final output sent to browser
DEBUG - 2018-03-28 16:18:28 --> Total execution time: 0.1980
INFO - 2018-03-28 16:18:28 --> Database Driver Class Initialized
DEBUG - 2018-03-28 16:18:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 16:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 16:18:28 --> Helper loaded: form_helper
INFO - 2018-03-28 16:18:28 --> Form Validation Class Initialized
INFO - 2018-03-28 16:18:28 --> Controller Class Initialized
INFO - 2018-03-28 16:18:28 --> Model Class Initialized
INFO - 2018-03-28 16:18:28 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 16:18:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 16:18:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 16:18:28 --> Model Class Initialized
INFO - 2018-03-28 16:18:28 --> Model Class Initialized
INFO - 2018-03-28 16:18:28 --> Model Class Initialized
INFO - 2018-03-28 16:18:28 --> Model Class Initialized
INFO - 2018-03-28 16:18:28 --> Model Class Initialized
INFO - 2018-03-28 16:18:28 --> Model Class Initialized
INFO - 2018-03-28 16:18:28 --> Model Class Initialized
INFO - 2018-03-28 16:18:28 --> Model Class Initialized
INFO - 2018-03-28 16:18:28 --> Model Class Initialized
INFO - 2018-03-28 16:18:28 --> Model Class Initialized
INFO - 2018-03-28 16:18:28 --> Model Class Initialized
INFO - 2018-03-28 16:18:28 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 16:18:28 --> Model Class Initialized
INFO - 2018-03-28 16:18:28 --> Final output sent to browser
DEBUG - 2018-03-28 16:18:28 --> Total execution time: 3.3907
INFO - 2018-03-28 10:48:30 --> Config Class Initialized
INFO - 2018-03-28 10:48:30 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:48:30 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:48:30 --> Utf8 Class Initialized
INFO - 2018-03-28 10:48:30 --> URI Class Initialized
INFO - 2018-03-28 10:48:30 --> Router Class Initialized
INFO - 2018-03-28 10:48:30 --> Output Class Initialized
INFO - 2018-03-28 10:48:30 --> Security Class Initialized
DEBUG - 2018-03-28 10:48:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:48:30 --> Input Class Initialized
INFO - 2018-03-28 10:48:30 --> Language Class Initialized
INFO - 2018-03-28 10:48:30 --> Language Class Initialized
INFO - 2018-03-28 10:48:30 --> Config Class Initialized
INFO - 2018-03-28 10:48:30 --> Loader Class Initialized
INFO - 2018-03-28 16:18:30 --> Helper loaded: url_helper
INFO - 2018-03-28 16:18:30 --> Helper loaded: notification_helper
INFO - 2018-03-28 16:18:30 --> Helper loaded: settings_helper
INFO - 2018-03-28 16:18:30 --> Helper loaded: permission_helper
INFO - 2018-03-28 16:18:30 --> Helper loaded: users_helper
INFO - 2018-03-28 16:18:31 --> Database Driver Class Initialized
DEBUG - 2018-03-28 16:18:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 16:18:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 16:18:31 --> Helper loaded: form_helper
INFO - 2018-03-28 16:18:31 --> Form Validation Class Initialized
INFO - 2018-03-28 16:18:31 --> Controller Class Initialized
INFO - 2018-03-28 16:18:31 --> Model Class Initialized
INFO - 2018-03-28 16:18:31 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 16:18:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 16:18:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 16:18:31 --> Model Class Initialized
INFO - 2018-03-28 16:18:31 --> Model Class Initialized
INFO - 2018-03-28 16:18:31 --> Model Class Initialized
INFO - 2018-03-28 16:18:31 --> Model Class Initialized
INFO - 2018-03-28 16:18:31 --> Model Class Initialized
INFO - 2018-03-28 16:18:31 --> Model Class Initialized
INFO - 2018-03-28 16:18:31 --> Model Class Initialized
INFO - 2018-03-28 16:18:31 --> Model Class Initialized
INFO - 2018-03-28 16:18:31 --> Model Class Initialized
INFO - 2018-03-28 16:18:31 --> Model Class Initialized
INFO - 2018-03-28 16:18:31 --> Model Class Initialized
INFO - 2018-03-28 16:18:31 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 16:18:31 --> Model Class Initialized
INFO - 2018-03-28 16:18:31 --> Final output sent to browser
DEBUG - 2018-03-28 16:18:31 --> Total execution time: 1.6942
INFO - 2018-03-28 10:48:33 --> Config Class Initialized
INFO - 2018-03-28 10:48:33 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:48:33 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:48:33 --> Utf8 Class Initialized
INFO - 2018-03-28 10:48:33 --> URI Class Initialized
INFO - 2018-03-28 10:48:33 --> Router Class Initialized
INFO - 2018-03-28 10:48:33 --> Output Class Initialized
INFO - 2018-03-28 10:48:33 --> Security Class Initialized
DEBUG - 2018-03-28 10:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:48:33 --> Input Class Initialized
INFO - 2018-03-28 10:48:33 --> Language Class Initialized
INFO - 2018-03-28 10:48:33 --> Language Class Initialized
INFO - 2018-03-28 10:48:33 --> Config Class Initialized
INFO - 2018-03-28 10:48:33 --> Loader Class Initialized
INFO - 2018-03-28 16:18:33 --> Helper loaded: url_helper
INFO - 2018-03-28 16:18:33 --> Helper loaded: notification_helper
INFO - 2018-03-28 16:18:33 --> Helper loaded: settings_helper
INFO - 2018-03-28 16:18:33 --> Helper loaded: permission_helper
INFO - 2018-03-28 16:18:33 --> Helper loaded: users_helper
INFO - 2018-03-28 16:18:33 --> Database Driver Class Initialized
DEBUG - 2018-03-28 16:18:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 16:18:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 16:18:33 --> Helper loaded: form_helper
INFO - 2018-03-28 16:18:33 --> Form Validation Class Initialized
INFO - 2018-03-28 16:18:33 --> Controller Class Initialized
INFO - 2018-03-28 16:18:33 --> Model Class Initialized
INFO - 2018-03-28 16:18:33 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 16:18:33 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 16:18:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 16:18:33 --> Model Class Initialized
INFO - 2018-03-28 16:18:33 --> Model Class Initialized
INFO - 2018-03-28 16:18:33 --> Model Class Initialized
INFO - 2018-03-28 16:18:33 --> Model Class Initialized
INFO - 2018-03-28 16:18:33 --> Model Class Initialized
INFO - 2018-03-28 16:18:33 --> Model Class Initialized
INFO - 2018-03-28 16:18:33 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-28 16:18:33 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-28 16:18:33 --> Final output sent to browser
DEBUG - 2018-03-28 16:18:33 --> Total execution time: 0.2344
INFO - 2018-03-28 10:48:47 --> Config Class Initialized
INFO - 2018-03-28 10:48:47 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:48:47 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:48:47 --> Utf8 Class Initialized
INFO - 2018-03-28 10:48:47 --> URI Class Initialized
INFO - 2018-03-28 10:48:47 --> Router Class Initialized
INFO - 2018-03-28 10:48:47 --> Output Class Initialized
INFO - 2018-03-28 10:48:47 --> Security Class Initialized
DEBUG - 2018-03-28 10:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:48:47 --> Input Class Initialized
INFO - 2018-03-28 10:48:48 --> Language Class Initialized
INFO - 2018-03-28 10:48:48 --> Language Class Initialized
INFO - 2018-03-28 10:48:48 --> Config Class Initialized
INFO - 2018-03-28 10:48:48 --> Loader Class Initialized
INFO - 2018-03-28 16:18:49 --> Helper loaded: url_helper
INFO - 2018-03-28 16:18:49 --> Helper loaded: notification_helper
INFO - 2018-03-28 16:18:49 --> Helper loaded: settings_helper
INFO - 2018-03-28 16:18:49 --> Helper loaded: permission_helper
INFO - 2018-03-28 16:18:49 --> Helper loaded: users_helper
INFO - 2018-03-28 16:18:50 --> Database Driver Class Initialized
DEBUG - 2018-03-28 16:18:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 16:18:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 16:18:50 --> Helper loaded: form_helper
INFO - 2018-03-28 16:18:50 --> Form Validation Class Initialized
INFO - 2018-03-28 16:18:50 --> Controller Class Initialized
INFO - 2018-03-28 16:18:50 --> Model Class Initialized
INFO - 2018-03-28 16:18:50 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 16:18:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 16:18:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 16:18:50 --> Model Class Initialized
INFO - 2018-03-28 16:18:50 --> Model Class Initialized
INFO - 2018-03-28 16:18:50 --> Model Class Initialized
INFO - 2018-03-28 16:18:50 --> Model Class Initialized
INFO - 2018-03-28 16:18:50 --> Model Class Initialized
INFO - 2018-03-28 16:18:50 --> Model Class Initialized
INFO - 2018-03-28 16:18:50 --> Model Class Initialized
INFO - 2018-03-28 16:18:50 --> Model Class Initialized
INFO - 2018-03-28 16:18:50 --> Model Class Initialized
INFO - 2018-03-28 16:18:50 --> Model Class Initialized
INFO - 2018-03-28 16:18:50 --> Model Class Initialized
INFO - 2018-03-28 16:18:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 16:18:50 --> Final output sent to browser
DEBUG - 2018-03-28 16:18:50 --> Total execution time: 3.1277
INFO - 2018-03-28 10:48:53 --> Config Class Initialized
INFO - 2018-03-28 10:48:53 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:48:53 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:48:53 --> Utf8 Class Initialized
INFO - 2018-03-28 10:48:53 --> URI Class Initialized
INFO - 2018-03-28 10:48:53 --> Router Class Initialized
INFO - 2018-03-28 10:48:53 --> Output Class Initialized
INFO - 2018-03-28 10:48:53 --> Security Class Initialized
DEBUG - 2018-03-28 10:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:48:53 --> Input Class Initialized
INFO - 2018-03-28 10:48:53 --> Language Class Initialized
INFO - 2018-03-28 10:48:53 --> Language Class Initialized
INFO - 2018-03-28 10:48:53 --> Config Class Initialized
INFO - 2018-03-28 10:48:53 --> Loader Class Initialized
INFO - 2018-03-28 16:18:53 --> Helper loaded: url_helper
INFO - 2018-03-28 16:18:53 --> Helper loaded: notification_helper
INFO - 2018-03-28 16:18:53 --> Helper loaded: settings_helper
INFO - 2018-03-28 16:18:53 --> Helper loaded: permission_helper
INFO - 2018-03-28 16:18:53 --> Helper loaded: users_helper
INFO - 2018-03-28 16:18:54 --> Database Driver Class Initialized
DEBUG - 2018-03-28 16:18:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 16:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 16:18:54 --> Helper loaded: form_helper
INFO - 2018-03-28 16:18:54 --> Form Validation Class Initialized
INFO - 2018-03-28 16:18:54 --> Controller Class Initialized
INFO - 2018-03-28 16:18:54 --> Model Class Initialized
INFO - 2018-03-28 16:18:54 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 16:18:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 16:18:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 16:18:54 --> Model Class Initialized
INFO - 2018-03-28 16:18:54 --> Model Class Initialized
INFO - 2018-03-28 16:18:54 --> Model Class Initialized
INFO - 2018-03-28 16:18:54 --> Model Class Initialized
INFO - 2018-03-28 16:18:54 --> Model Class Initialized
INFO - 2018-03-28 16:18:54 --> Model Class Initialized
INFO - 2018-03-28 16:18:54 --> Model Class Initialized
INFO - 2018-03-28 16:18:54 --> Model Class Initialized
INFO - 2018-03-28 16:18:54 --> Model Class Initialized
INFO - 2018-03-28 16:18:54 --> Model Class Initialized
INFO - 2018-03-28 16:18:54 --> Model Class Initialized
INFO - 2018-03-28 16:18:54 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 16:18:54 --> Final output sent to browser
DEBUG - 2018-03-28 16:18:54 --> Total execution time: 1.5668
INFO - 2018-03-28 10:48:57 --> Config Class Initialized
INFO - 2018-03-28 10:48:57 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:48:58 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:48:58 --> Utf8 Class Initialized
INFO - 2018-03-28 10:48:58 --> URI Class Initialized
INFO - 2018-03-28 10:48:58 --> Router Class Initialized
INFO - 2018-03-28 10:48:58 --> Output Class Initialized
INFO - 2018-03-28 10:48:58 --> Security Class Initialized
DEBUG - 2018-03-28 10:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:48:58 --> Input Class Initialized
INFO - 2018-03-28 10:48:58 --> Language Class Initialized
INFO - 2018-03-28 10:48:59 --> Language Class Initialized
INFO - 2018-03-28 10:48:59 --> Config Class Initialized
INFO - 2018-03-28 10:48:59 --> Loader Class Initialized
INFO - 2018-03-28 16:18:59 --> Helper loaded: url_helper
INFO - 2018-03-28 16:18:59 --> Helper loaded: notification_helper
INFO - 2018-03-28 16:18:59 --> Helper loaded: settings_helper
INFO - 2018-03-28 16:18:59 --> Helper loaded: permission_helper
INFO - 2018-03-28 16:18:59 --> Helper loaded: users_helper
INFO - 2018-03-28 16:18:59 --> Database Driver Class Initialized
DEBUG - 2018-03-28 16:18:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 16:18:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 16:18:59 --> Helper loaded: form_helper
INFO - 2018-03-28 16:18:59 --> Form Validation Class Initialized
INFO - 2018-03-28 16:18:59 --> Controller Class Initialized
INFO - 2018-03-28 16:19:00 --> Model Class Initialized
INFO - 2018-03-28 16:19:00 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 16:19:00 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 16:19:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 10:49:01 --> Config Class Initialized
INFO - 2018-03-28 10:49:01 --> Hooks Class Initialized
INFO - 2018-03-28 16:19:01 --> Model Class Initialized
INFO - 2018-03-28 16:19:01 --> Model Class Initialized
INFO - 2018-03-28 16:19:01 --> Model Class Initialized
INFO - 2018-03-28 16:19:01 --> Model Class Initialized
INFO - 2018-03-28 16:19:01 --> Model Class Initialized
INFO - 2018-03-28 16:19:01 --> Model Class Initialized
INFO - 2018-03-28 16:19:01 --> Model Class Initialized
INFO - 2018-03-28 16:19:01 --> Model Class Initialized
INFO - 2018-03-28 16:19:01 --> Model Class Initialized
INFO - 2018-03-28 16:19:01 --> Model Class Initialized
DEBUG - 2018-03-28 10:49:01 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:49:01 --> Utf8 Class Initialized
INFO - 2018-03-28 16:19:01 --> Model Class Initialized
INFO - 2018-03-28 16:19:01 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 10:49:01 --> URI Class Initialized
INFO - 2018-03-28 10:49:01 --> Router Class Initialized
INFO - 2018-03-28 16:19:01 --> Final output sent to browser
DEBUG - 2018-03-28 16:19:01 --> Total execution time: 3.8528
INFO - 2018-03-28 10:49:01 --> Output Class Initialized
INFO - 2018-03-28 10:49:01 --> Security Class Initialized
DEBUG - 2018-03-28 10:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:49:01 --> Input Class Initialized
INFO - 2018-03-28 10:49:01 --> Language Class Initialized
INFO - 2018-03-28 10:49:02 --> Language Class Initialized
INFO - 2018-03-28 10:49:02 --> Config Class Initialized
INFO - 2018-03-28 10:49:02 --> Loader Class Initialized
INFO - 2018-03-28 16:19:02 --> Helper loaded: url_helper
INFO - 2018-03-28 16:19:02 --> Helper loaded: notification_helper
INFO - 2018-03-28 16:19:02 --> Helper loaded: settings_helper
INFO - 2018-03-28 16:19:02 --> Helper loaded: permission_helper
INFO - 2018-03-28 16:19:02 --> Helper loaded: users_helper
INFO - 2018-03-28 16:19:02 --> Database Driver Class Initialized
DEBUG - 2018-03-28 16:19:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 16:19:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 16:19:03 --> Helper loaded: form_helper
INFO - 2018-03-28 16:19:03 --> Form Validation Class Initialized
INFO - 2018-03-28 16:19:03 --> Controller Class Initialized
INFO - 2018-03-28 16:19:03 --> Model Class Initialized
INFO - 2018-03-28 16:19:03 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 16:19:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 16:19:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 16:19:03 --> Model Class Initialized
INFO - 2018-03-28 16:19:03 --> Model Class Initialized
INFO - 2018-03-28 16:19:03 --> Model Class Initialized
INFO - 2018-03-28 16:19:03 --> Model Class Initialized
INFO - 2018-03-28 16:19:03 --> Model Class Initialized
INFO - 2018-03-28 16:19:03 --> Model Class Initialized
INFO - 2018-03-28 16:19:03 --> Model Class Initialized
INFO - 2018-03-28 16:19:03 --> Model Class Initialized
INFO - 2018-03-28 16:19:03 --> Model Class Initialized
INFO - 2018-03-28 16:19:03 --> Model Class Initialized
INFO - 2018-03-28 16:19:03 --> Model Class Initialized
INFO - 2018-03-28 16:19:03 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 16:19:03 --> Final output sent to browser
DEBUG - 2018-03-28 16:19:03 --> Total execution time: 2.2279
INFO - 2018-03-28 10:49:05 --> Config Class Initialized
INFO - 2018-03-28 10:49:05 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:49:05 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:49:05 --> Utf8 Class Initialized
INFO - 2018-03-28 10:49:05 --> URI Class Initialized
INFO - 2018-03-28 10:49:05 --> Router Class Initialized
INFO - 2018-03-28 10:49:05 --> Output Class Initialized
INFO - 2018-03-28 10:49:05 --> Security Class Initialized
DEBUG - 2018-03-28 10:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:49:05 --> Input Class Initialized
INFO - 2018-03-28 10:49:05 --> Language Class Initialized
INFO - 2018-03-28 10:49:05 --> Language Class Initialized
INFO - 2018-03-28 10:49:05 --> Config Class Initialized
INFO - 2018-03-28 10:49:05 --> Loader Class Initialized
INFO - 2018-03-28 16:19:05 --> Helper loaded: url_helper
INFO - 2018-03-28 16:19:05 --> Helper loaded: notification_helper
INFO - 2018-03-28 16:19:05 --> Helper loaded: settings_helper
INFO - 2018-03-28 16:19:05 --> Helper loaded: permission_helper
INFO - 2018-03-28 16:19:05 --> Helper loaded: users_helper
INFO - 2018-03-28 16:19:05 --> Database Driver Class Initialized
DEBUG - 2018-03-28 16:19:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 16:19:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 16:19:05 --> Helper loaded: form_helper
INFO - 2018-03-28 16:19:05 --> Form Validation Class Initialized
INFO - 2018-03-28 16:19:05 --> Controller Class Initialized
INFO - 2018-03-28 16:19:05 --> Model Class Initialized
INFO - 2018-03-28 16:19:05 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 16:19:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 16:19:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 16:19:05 --> Model Class Initialized
INFO - 2018-03-28 16:19:05 --> Model Class Initialized
INFO - 2018-03-28 16:19:05 --> Model Class Initialized
INFO - 2018-03-28 16:19:05 --> Model Class Initialized
INFO - 2018-03-28 16:19:05 --> Model Class Initialized
INFO - 2018-03-28 16:19:05 --> Model Class Initialized
INFO - 2018-03-28 16:19:05 --> Model Class Initialized
INFO - 2018-03-28 16:19:05 --> Model Class Initialized
INFO - 2018-03-28 16:19:05 --> Model Class Initialized
INFO - 2018-03-28 16:19:05 --> Model Class Initialized
INFO - 2018-03-28 16:19:05 --> Model Class Initialized
INFO - 2018-03-28 16:19:05 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 16:19:05 --> Final output sent to browser
DEBUG - 2018-03-28 16:19:05 --> Total execution time: 0.1203
INFO - 2018-03-28 10:49:06 --> Config Class Initialized
INFO - 2018-03-28 10:49:06 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:49:06 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:49:06 --> Utf8 Class Initialized
INFO - 2018-03-28 10:49:06 --> URI Class Initialized
INFO - 2018-03-28 10:49:06 --> Router Class Initialized
INFO - 2018-03-28 10:49:06 --> Output Class Initialized
INFO - 2018-03-28 10:49:06 --> Security Class Initialized
DEBUG - 2018-03-28 10:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:49:06 --> Input Class Initialized
INFO - 2018-03-28 10:49:06 --> Language Class Initialized
INFO - 2018-03-28 10:49:06 --> Language Class Initialized
INFO - 2018-03-28 10:49:06 --> Config Class Initialized
INFO - 2018-03-28 10:49:06 --> Loader Class Initialized
INFO - 2018-03-28 16:19:06 --> Helper loaded: url_helper
INFO - 2018-03-28 16:19:06 --> Helper loaded: notification_helper
INFO - 2018-03-28 16:19:06 --> Helper loaded: settings_helper
INFO - 2018-03-28 16:19:06 --> Helper loaded: permission_helper
INFO - 2018-03-28 16:19:06 --> Helper loaded: users_helper
INFO - 2018-03-28 16:19:06 --> Database Driver Class Initialized
DEBUG - 2018-03-28 16:19:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 16:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 16:19:06 --> Helper loaded: form_helper
INFO - 2018-03-28 16:19:06 --> Form Validation Class Initialized
INFO - 2018-03-28 16:19:06 --> Controller Class Initialized
INFO - 2018-03-28 16:19:06 --> Model Class Initialized
INFO - 2018-03-28 16:19:06 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 16:19:06 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 16:19:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 16:19:06 --> Model Class Initialized
INFO - 2018-03-28 16:19:06 --> Model Class Initialized
INFO - 2018-03-28 16:19:06 --> Model Class Initialized
INFO - 2018-03-28 16:19:06 --> Model Class Initialized
INFO - 2018-03-28 16:19:06 --> Model Class Initialized
INFO - 2018-03-28 16:19:06 --> Model Class Initialized
INFO - 2018-03-28 16:19:06 --> Model Class Initialized
INFO - 2018-03-28 16:19:06 --> Model Class Initialized
INFO - 2018-03-28 16:19:06 --> Model Class Initialized
INFO - 2018-03-28 16:19:06 --> Model Class Initialized
INFO - 2018-03-28 16:19:06 --> Model Class Initialized
INFO - 2018-03-28 16:19:06 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 16:19:06 --> Model Class Initialized
INFO - 2018-03-28 16:19:06 --> Final output sent to browser
DEBUG - 2018-03-28 16:19:06 --> Total execution time: 0.2520
INFO - 2018-03-28 10:49:09 --> Config Class Initialized
INFO - 2018-03-28 10:49:09 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:49:09 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:49:09 --> Utf8 Class Initialized
INFO - 2018-03-28 10:49:09 --> URI Class Initialized
INFO - 2018-03-28 10:49:10 --> Router Class Initialized
INFO - 2018-03-28 10:49:10 --> Output Class Initialized
INFO - 2018-03-28 10:49:10 --> Security Class Initialized
DEBUG - 2018-03-28 10:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:49:10 --> Input Class Initialized
INFO - 2018-03-28 10:49:10 --> Language Class Initialized
INFO - 2018-03-28 10:49:11 --> Language Class Initialized
INFO - 2018-03-28 10:49:11 --> Config Class Initialized
INFO - 2018-03-28 10:49:11 --> Loader Class Initialized
INFO - 2018-03-28 16:19:11 --> Helper loaded: url_helper
INFO - 2018-03-28 16:19:11 --> Helper loaded: notification_helper
INFO - 2018-03-28 16:19:11 --> Helper loaded: settings_helper
INFO - 2018-03-28 16:19:11 --> Helper loaded: permission_helper
INFO - 2018-03-28 16:19:11 --> Helper loaded: users_helper
INFO - 2018-03-28 16:19:12 --> Database Driver Class Initialized
DEBUG - 2018-03-28 16:19:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 16:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 16:19:12 --> Helper loaded: form_helper
INFO - 2018-03-28 16:19:12 --> Form Validation Class Initialized
INFO - 2018-03-28 16:19:12 --> Controller Class Initialized
INFO - 2018-03-28 16:19:12 --> Model Class Initialized
INFO - 2018-03-28 16:19:12 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 16:19:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 16:19:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 10:49:12 --> Config Class Initialized
INFO - 2018-03-28 10:49:12 --> Hooks Class Initialized
INFO - 2018-03-28 16:19:12 --> Model Class Initialized
INFO - 2018-03-28 16:19:12 --> Model Class Initialized
DEBUG - 2018-03-28 10:49:12 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:49:12 --> Utf8 Class Initialized
INFO - 2018-03-28 16:19:12 --> Model Class Initialized
INFO - 2018-03-28 16:19:12 --> Model Class Initialized
INFO - 2018-03-28 10:49:12 --> URI Class Initialized
INFO - 2018-03-28 16:19:12 --> Model Class Initialized
INFO - 2018-03-28 16:19:12 --> Model Class Initialized
INFO - 2018-03-28 16:19:12 --> Model Class Initialized
INFO - 2018-03-28 16:19:12 --> Model Class Initialized
INFO - 2018-03-28 16:19:12 --> Model Class Initialized
INFO - 2018-03-28 16:19:12 --> Model Class Initialized
INFO - 2018-03-28 10:49:12 --> Router Class Initialized
INFO - 2018-03-28 16:19:12 --> Model Class Initialized
INFO - 2018-03-28 16:19:12 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 16:19:12 --> Model Class Initialized
INFO - 2018-03-28 10:49:12 --> Output Class Initialized
INFO - 2018-03-28 10:49:12 --> Security Class Initialized
DEBUG - 2018-03-28 10:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:49:12 --> Input Class Initialized
INFO - 2018-03-28 10:49:12 --> Language Class Initialized
INFO - 2018-03-28 16:19:12 --> Final output sent to browser
DEBUG - 2018-03-28 16:19:12 --> Total execution time: 2.8662
INFO - 2018-03-28 10:49:12 --> Language Class Initialized
INFO - 2018-03-28 10:49:12 --> Config Class Initialized
INFO - 2018-03-28 10:49:12 --> Loader Class Initialized
INFO - 2018-03-28 16:19:12 --> Helper loaded: url_helper
INFO - 2018-03-28 16:19:12 --> Helper loaded: notification_helper
INFO - 2018-03-28 16:19:12 --> Helper loaded: settings_helper
INFO - 2018-03-28 16:19:12 --> Helper loaded: permission_helper
INFO - 2018-03-28 16:19:12 --> Helper loaded: users_helper
INFO - 2018-03-28 16:19:12 --> Database Driver Class Initialized
DEBUG - 2018-03-28 16:19:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 16:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 16:19:12 --> Helper loaded: form_helper
INFO - 2018-03-28 16:19:12 --> Form Validation Class Initialized
INFO - 2018-03-28 16:19:12 --> Controller Class Initialized
INFO - 2018-03-28 16:19:12 --> Model Class Initialized
INFO - 2018-03-28 16:19:12 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 16:19:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 16:19:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 16:19:12 --> Model Class Initialized
INFO - 2018-03-28 16:19:12 --> Model Class Initialized
INFO - 2018-03-28 16:19:12 --> Model Class Initialized
INFO - 2018-03-28 16:19:12 --> Model Class Initialized
INFO - 2018-03-28 16:19:12 --> Model Class Initialized
INFO - 2018-03-28 16:19:12 --> Model Class Initialized
INFO - 2018-03-28 16:19:12 --> Model Class Initialized
INFO - 2018-03-28 16:19:12 --> Model Class Initialized
INFO - 2018-03-28 16:19:12 --> Model Class Initialized
INFO - 2018-03-28 16:19:12 --> Model Class Initialized
INFO - 2018-03-28 16:19:12 --> Model Class Initialized
INFO - 2018-03-28 16:19:12 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 16:19:12 --> Model Class Initialized
INFO - 2018-03-28 16:19:12 --> Final output sent to browser
DEBUG - 2018-03-28 16:19:12 --> Total execution time: 0.1825
INFO - 2018-03-28 10:49:14 --> Config Class Initialized
INFO - 2018-03-28 10:49:14 --> Hooks Class Initialized
DEBUG - 2018-03-28 10:49:14 --> UTF-8 Support Enabled
INFO - 2018-03-28 10:49:14 --> Utf8 Class Initialized
INFO - 2018-03-28 10:49:15 --> URI Class Initialized
INFO - 2018-03-28 10:49:15 --> Router Class Initialized
INFO - 2018-03-28 10:49:15 --> Output Class Initialized
INFO - 2018-03-28 10:49:15 --> Security Class Initialized
DEBUG - 2018-03-28 10:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 10:49:15 --> Input Class Initialized
INFO - 2018-03-28 10:49:15 --> Language Class Initialized
INFO - 2018-03-28 10:49:15 --> Language Class Initialized
INFO - 2018-03-28 10:49:15 --> Config Class Initialized
INFO - 2018-03-28 10:49:15 --> Loader Class Initialized
INFO - 2018-03-28 16:19:15 --> Helper loaded: url_helper
INFO - 2018-03-28 16:19:15 --> Helper loaded: notification_helper
INFO - 2018-03-28 16:19:15 --> Helper loaded: settings_helper
INFO - 2018-03-28 16:19:15 --> Helper loaded: permission_helper
INFO - 2018-03-28 16:19:15 --> Helper loaded: users_helper
INFO - 2018-03-28 16:19:15 --> Database Driver Class Initialized
DEBUG - 2018-03-28 16:19:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 16:19:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 16:19:15 --> Helper loaded: form_helper
INFO - 2018-03-28 16:19:15 --> Form Validation Class Initialized
INFO - 2018-03-28 16:19:15 --> Controller Class Initialized
INFO - 2018-03-28 16:19:15 --> Model Class Initialized
INFO - 2018-03-28 16:19:15 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 16:19:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 16:19:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 16:19:15 --> Model Class Initialized
INFO - 2018-03-28 16:19:15 --> Model Class Initialized
INFO - 2018-03-28 16:19:15 --> Model Class Initialized
INFO - 2018-03-28 16:19:15 --> Model Class Initialized
INFO - 2018-03-28 16:19:15 --> Model Class Initialized
INFO - 2018-03-28 16:19:15 --> Model Class Initialized
INFO - 2018-03-28 16:19:15 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-28 16:19:15 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-28 16:19:15 --> Final output sent to browser
DEBUG - 2018-03-28 16:19:15 --> Total execution time: 0.9170
INFO - 2018-03-28 12:14:34 --> Config Class Initialized
INFO - 2018-03-28 12:14:34 --> Hooks Class Initialized
DEBUG - 2018-03-28 12:14:34 --> UTF-8 Support Enabled
INFO - 2018-03-28 12:14:34 --> Utf8 Class Initialized
INFO - 2018-03-28 12:14:35 --> URI Class Initialized
INFO - 2018-03-28 12:14:35 --> Router Class Initialized
INFO - 2018-03-28 12:14:35 --> Output Class Initialized
INFO - 2018-03-28 12:14:36 --> Security Class Initialized
DEBUG - 2018-03-28 12:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 12:14:36 --> Input Class Initialized
INFO - 2018-03-28 12:14:36 --> Language Class Initialized
INFO - 2018-03-28 12:14:37 --> Language Class Initialized
INFO - 2018-03-28 12:14:37 --> Config Class Initialized
INFO - 2018-03-28 12:14:37 --> Loader Class Initialized
INFO - 2018-03-28 17:44:37 --> Helper loaded: url_helper
INFO - 2018-03-28 17:44:37 --> Helper loaded: notification_helper
INFO - 2018-03-28 17:44:37 --> Helper loaded: settings_helper
INFO - 2018-03-28 17:44:37 --> Helper loaded: permission_helper
INFO - 2018-03-28 17:44:37 --> Helper loaded: users_helper
INFO - 2018-03-28 17:44:38 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:44:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:44:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:44:38 --> Helper loaded: form_helper
INFO - 2018-03-28 17:44:38 --> Form Validation Class Initialized
INFO - 2018-03-28 17:44:38 --> Controller Class Initialized
INFO - 2018-03-28 17:44:38 --> Model Class Initialized
INFO - 2018-03-28 17:44:38 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 17:44:38 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 17:44:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 17:44:38 --> Model Class Initialized
INFO - 2018-03-28 17:44:38 --> Model Class Initialized
INFO - 2018-03-28 17:44:38 --> Model Class Initialized
INFO - 2018-03-28 17:44:38 --> Model Class Initialized
INFO - 2018-03-28 17:44:38 --> Model Class Initialized
INFO - 2018-03-28 17:44:38 --> Model Class Initialized
INFO - 2018-03-28 17:44:38 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 17:44:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-28 17:44:38 --> Final output sent to browser
DEBUG - 2018-03-28 17:44:38 --> Total execution time: 3.5692
INFO - 2018-03-28 12:14:39 --> Config Class Initialized
INFO - 2018-03-28 12:14:39 --> Hooks Class Initialized
DEBUG - 2018-03-28 12:14:39 --> UTF-8 Support Enabled
INFO - 2018-03-28 12:14:39 --> Utf8 Class Initialized
INFO - 2018-03-28 12:14:39 --> URI Class Initialized
INFO - 2018-03-28 12:14:39 --> Router Class Initialized
INFO - 2018-03-28 12:14:39 --> Output Class Initialized
INFO - 2018-03-28 12:14:39 --> Security Class Initialized
DEBUG - 2018-03-28 12:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 12:14:39 --> Input Class Initialized
INFO - 2018-03-28 12:14:39 --> Language Class Initialized
INFO - 2018-03-28 12:14:39 --> Language Class Initialized
INFO - 2018-03-28 12:14:39 --> Config Class Initialized
INFO - 2018-03-28 12:14:39 --> Loader Class Initialized
INFO - 2018-03-28 17:44:39 --> Helper loaded: url_helper
INFO - 2018-03-28 17:44:39 --> Helper loaded: notification_helper
INFO - 2018-03-28 17:44:39 --> Helper loaded: settings_helper
INFO - 2018-03-28 17:44:39 --> Helper loaded: permission_helper
INFO - 2018-03-28 17:44:39 --> Helper loaded: users_helper
INFO - 2018-03-28 17:44:39 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:44:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:44:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:44:39 --> Helper loaded: form_helper
INFO - 2018-03-28 17:44:39 --> Form Validation Class Initialized
INFO - 2018-03-28 17:44:39 --> Controller Class Initialized
INFO - 2018-03-28 17:44:39 --> Model Class Initialized
INFO - 2018-03-28 17:44:39 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 17:44:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 17:44:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 17:44:39 --> Model Class Initialized
INFO - 2018-03-28 17:44:39 --> Model Class Initialized
INFO - 2018-03-28 17:44:39 --> Model Class Initialized
INFO - 2018-03-28 17:44:39 --> Model Class Initialized
INFO - 2018-03-28 17:44:39 --> Model Class Initialized
INFO - 2018-03-28 17:44:39 --> Model Class Initialized
INFO - 2018-03-28 17:44:39 --> Model Class Initialized
INFO - 2018-03-28 17:44:39 --> Model Class Initialized
INFO - 2018-03-28 17:44:39 --> Model Class Initialized
INFO - 2018-03-28 17:44:39 --> Model Class Initialized
INFO - 2018-03-28 17:44:39 --> Model Class Initialized
INFO - 2018-03-28 17:44:39 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 17:44:39 --> Model Class Initialized
INFO - 2018-03-28 17:44:39 --> Final output sent to browser
DEBUG - 2018-03-28 17:44:39 --> Total execution time: 0.1190
INFO - 2018-03-28 12:14:40 --> Config Class Initialized
INFO - 2018-03-28 12:14:41 --> Hooks Class Initialized
DEBUG - 2018-03-28 12:14:41 --> UTF-8 Support Enabled
INFO - 2018-03-28 12:14:41 --> Utf8 Class Initialized
INFO - 2018-03-28 12:14:41 --> URI Class Initialized
INFO - 2018-03-28 12:14:41 --> Router Class Initialized
INFO - 2018-03-28 12:14:41 --> Output Class Initialized
INFO - 2018-03-28 12:14:41 --> Security Class Initialized
DEBUG - 2018-03-28 12:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 12:14:41 --> Input Class Initialized
INFO - 2018-03-28 12:14:41 --> Language Class Initialized
INFO - 2018-03-28 12:14:42 --> Config Class Initialized
INFO - 2018-03-28 12:14:42 --> Hooks Class Initialized
INFO - 2018-03-28 12:14:42 --> Language Class Initialized
INFO - 2018-03-28 12:14:42 --> Config Class Initialized
INFO - 2018-03-28 12:14:42 --> Loader Class Initialized
DEBUG - 2018-03-28 12:14:42 --> UTF-8 Support Enabled
INFO - 2018-03-28 12:14:42 --> Utf8 Class Initialized
INFO - 2018-03-28 17:44:42 --> Helper loaded: url_helper
INFO - 2018-03-28 12:14:42 --> URI Class Initialized
INFO - 2018-03-28 17:44:42 --> Helper loaded: notification_helper
INFO - 2018-03-28 17:44:42 --> Helper loaded: settings_helper
INFO - 2018-03-28 17:44:42 --> Helper loaded: permission_helper
INFO - 2018-03-28 17:44:42 --> Helper loaded: users_helper
INFO - 2018-03-28 12:14:42 --> Router Class Initialized
INFO - 2018-03-28 12:14:42 --> Output Class Initialized
INFO - 2018-03-28 12:14:42 --> Security Class Initialized
DEBUG - 2018-03-28 12:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 12:14:43 --> Input Class Initialized
INFO - 2018-03-28 12:14:43 --> Language Class Initialized
INFO - 2018-03-28 17:44:43 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:44:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:44:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:44:43 --> Helper loaded: form_helper
INFO - 2018-03-28 17:44:43 --> Form Validation Class Initialized
INFO - 2018-03-28 17:44:43 --> Controller Class Initialized
INFO - 2018-03-28 17:44:43 --> Model Class Initialized
INFO - 2018-03-28 17:44:43 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 17:44:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 17:44:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 17:44:43 --> Model Class Initialized
INFO - 2018-03-28 17:44:43 --> Model Class Initialized
INFO - 2018-03-28 17:44:43 --> Model Class Initialized
INFO - 2018-03-28 17:44:43 --> Model Class Initialized
INFO - 2018-03-28 17:44:43 --> Model Class Initialized
INFO - 2018-03-28 17:44:43 --> Model Class Initialized
INFO - 2018-03-28 17:44:43 --> Model Class Initialized
INFO - 2018-03-28 17:44:43 --> Model Class Initialized
INFO - 2018-03-28 17:44:43 --> Model Class Initialized
INFO - 2018-03-28 17:44:43 --> Model Class Initialized
INFO - 2018-03-28 17:44:43 --> Model Class Initialized
INFO - 2018-03-28 17:44:43 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 17:44:43 --> Model Class Initialized
INFO - 2018-03-28 17:44:43 --> Final output sent to browser
DEBUG - 2018-03-28 17:44:43 --> Total execution time: 2.4754
INFO - 2018-03-28 12:14:43 --> Language Class Initialized
INFO - 2018-03-28 12:14:43 --> Config Class Initialized
INFO - 2018-03-28 12:14:43 --> Loader Class Initialized
INFO - 2018-03-28 17:44:43 --> Helper loaded: url_helper
INFO - 2018-03-28 17:44:43 --> Helper loaded: notification_helper
INFO - 2018-03-28 17:44:43 --> Helper loaded: settings_helper
INFO - 2018-03-28 17:44:43 --> Helper loaded: permission_helper
INFO - 2018-03-28 17:44:43 --> Helper loaded: users_helper
INFO - 2018-03-28 17:44:43 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:44:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:44:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:44:43 --> Helper loaded: form_helper
INFO - 2018-03-28 17:44:43 --> Form Validation Class Initialized
INFO - 2018-03-28 17:44:43 --> Controller Class Initialized
INFO - 2018-03-28 17:44:44 --> Model Class Initialized
INFO - 2018-03-28 17:44:44 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 17:44:44 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 17:44:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 17:44:44 --> Model Class Initialized
INFO - 2018-03-28 17:44:44 --> Model Class Initialized
INFO - 2018-03-28 17:44:44 --> Model Class Initialized
INFO - 2018-03-28 17:44:44 --> Model Class Initialized
INFO - 2018-03-28 17:44:44 --> Model Class Initialized
INFO - 2018-03-28 17:44:44 --> Model Class Initialized
INFO - 2018-03-28 17:44:44 --> Model Class Initialized
INFO - 2018-03-28 17:44:44 --> Model Class Initialized
INFO - 2018-03-28 17:44:44 --> Model Class Initialized
INFO - 2018-03-28 17:44:44 --> Model Class Initialized
INFO - 2018-03-28 17:44:44 --> Model Class Initialized
INFO - 2018-03-28 17:44:44 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 17:44:44 --> Model Class Initialized
INFO - 2018-03-28 17:44:44 --> Final output sent to browser
DEBUG - 2018-03-28 17:44:44 --> Total execution time: 2.6238
INFO - 2018-03-28 12:15:15 --> Config Class Initialized
INFO - 2018-03-28 12:15:15 --> Hooks Class Initialized
DEBUG - 2018-03-28 12:15:15 --> UTF-8 Support Enabled
INFO - 2018-03-28 12:15:15 --> Utf8 Class Initialized
INFO - 2018-03-28 12:15:15 --> URI Class Initialized
INFO - 2018-03-28 12:15:16 --> Config Class Initialized
INFO - 2018-03-28 12:15:16 --> Hooks Class Initialized
DEBUG - 2018-03-28 12:15:16 --> UTF-8 Support Enabled
INFO - 2018-03-28 12:15:16 --> Utf8 Class Initialized
INFO - 2018-03-28 12:15:16 --> URI Class Initialized
INFO - 2018-03-28 12:15:16 --> Router Class Initialized
INFO - 2018-03-28 12:15:16 --> Output Class Initialized
INFO - 2018-03-28 12:15:16 --> Security Class Initialized
INFO - 2018-03-28 12:15:16 --> Router Class Initialized
DEBUG - 2018-03-28 12:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 12:15:16 --> Input Class Initialized
INFO - 2018-03-28 12:15:16 --> Language Class Initialized
INFO - 2018-03-28 12:15:16 --> Output Class Initialized
INFO - 2018-03-28 12:15:16 --> Security Class Initialized
DEBUG - 2018-03-28 12:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 12:15:16 --> Input Class Initialized
INFO - 2018-03-28 12:15:17 --> Language Class Initialized
INFO - 2018-03-28 12:15:17 --> Config Class Initialized
INFO - 2018-03-28 12:15:17 --> Hooks Class Initialized
DEBUG - 2018-03-28 12:15:17 --> UTF-8 Support Enabled
INFO - 2018-03-28 12:15:17 --> Utf8 Class Initialized
INFO - 2018-03-28 12:15:17 --> URI Class Initialized
INFO - 2018-03-28 12:15:17 --> Router Class Initialized
INFO - 2018-03-28 12:15:17 --> Output Class Initialized
INFO - 2018-03-28 12:15:17 --> Security Class Initialized
DEBUG - 2018-03-28 12:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 12:15:17 --> Input Class Initialized
INFO - 2018-03-28 12:15:17 --> Language Class Initialized
INFO - 2018-03-28 12:15:17 --> Language Class Initialized
INFO - 2018-03-28 12:15:17 --> Config Class Initialized
INFO - 2018-03-28 12:15:17 --> Loader Class Initialized
INFO - 2018-03-28 17:45:17 --> Helper loaded: url_helper
INFO - 2018-03-28 17:45:17 --> Helper loaded: notification_helper
INFO - 2018-03-28 17:45:17 --> Helper loaded: settings_helper
INFO - 2018-03-28 17:45:17 --> Helper loaded: permission_helper
INFO - 2018-03-28 17:45:17 --> Helper loaded: users_helper
INFO - 2018-03-28 17:45:17 --> Database Driver Class Initialized
INFO - 2018-03-28 12:15:17 --> Config Class Initialized
INFO - 2018-03-28 12:15:17 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:45:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:45:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-03-28 12:15:17 --> UTF-8 Support Enabled
INFO - 2018-03-28 12:15:17 --> Utf8 Class Initialized
INFO - 2018-03-28 17:45:17 --> Helper loaded: form_helper
INFO - 2018-03-28 17:45:17 --> Form Validation Class Initialized
INFO - 2018-03-28 17:45:17 --> Controller Class Initialized
INFO - 2018-03-28 12:15:17 --> URI Class Initialized
INFO - 2018-03-28 17:45:17 --> Model Class Initialized
INFO - 2018-03-28 12:15:17 --> Router Class Initialized
INFO - 2018-03-28 17:45:17 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 17:45:17 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 17:45:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 17:45:17 --> Model Class Initialized
INFO - 2018-03-28 12:15:17 --> Output Class Initialized
INFO - 2018-03-28 17:45:17 --> Model Class Initialized
INFO - 2018-03-28 17:45:17 --> Model Class Initialized
INFO - 2018-03-28 17:45:17 --> Model Class Initialized
INFO - 2018-03-28 17:45:17 --> Model Class Initialized
INFO - 2018-03-28 17:45:17 --> Model Class Initialized
INFO - 2018-03-28 17:45:17 --> Model Class Initialized
INFO - 2018-03-28 17:45:17 --> Model Class Initialized
INFO - 2018-03-28 17:45:17 --> Model Class Initialized
INFO - 2018-03-28 17:45:17 --> Model Class Initialized
INFO - 2018-03-28 12:15:17 --> Security Class Initialized
INFO - 2018-03-28 17:45:17 --> Model Class Initialized
INFO - 2018-03-28 17:45:17 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 17:45:17 --> Model Class Initialized
DEBUG - 2018-03-28 12:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 12:15:17 --> Input Class Initialized
INFO - 2018-03-28 12:15:17 --> Language Class Initialized
INFO - 2018-03-28 17:45:17 --> Final output sent to browser
DEBUG - 2018-03-28 17:45:17 --> Total execution time: 0.1254
INFO - 2018-03-28 12:15:17 --> Language Class Initialized
INFO - 2018-03-28 12:15:17 --> Config Class Initialized
INFO - 2018-03-28 12:15:17 --> Loader Class Initialized
INFO - 2018-03-28 17:45:17 --> Helper loaded: url_helper
INFO - 2018-03-28 17:45:17 --> Helper loaded: notification_helper
INFO - 2018-03-28 17:45:17 --> Helper loaded: settings_helper
INFO - 2018-03-28 17:45:17 --> Helper loaded: permission_helper
INFO - 2018-03-28 17:45:17 --> Helper loaded: users_helper
INFO - 2018-03-28 17:45:17 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:45:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:45:17 --> Helper loaded: form_helper
INFO - 2018-03-28 17:45:17 --> Form Validation Class Initialized
INFO - 2018-03-28 17:45:17 --> Controller Class Initialized
INFO - 2018-03-28 12:15:17 --> Language Class Initialized
INFO - 2018-03-28 12:15:17 --> Config Class Initialized
INFO - 2018-03-28 17:45:17 --> Model Class Initialized
INFO - 2018-03-28 17:45:17 --> Helper loaded: inflector_helper
INFO - 2018-03-28 12:15:17 --> Loader Class Initialized
DEBUG - 2018-03-28 17:45:17 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 17:45:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 17:45:17 --> Model Class Initialized
INFO - 2018-03-28 17:45:17 --> Model Class Initialized
INFO - 2018-03-28 17:45:17 --> Model Class Initialized
INFO - 2018-03-28 17:45:17 --> Model Class Initialized
INFO - 2018-03-28 17:45:17 --> Model Class Initialized
INFO - 2018-03-28 17:45:17 --> Model Class Initialized
INFO - 2018-03-28 17:45:17 --> Model Class Initialized
INFO - 2018-03-28 17:45:17 --> Model Class Initialized
INFO - 2018-03-28 17:45:17 --> Model Class Initialized
INFO - 2018-03-28 17:45:17 --> Model Class Initialized
INFO - 2018-03-28 17:45:17 --> Model Class Initialized
INFO - 2018-03-28 17:45:17 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 17:45:17 --> Final output sent to browser
DEBUG - 2018-03-28 17:45:17 --> Total execution time: 0.1863
INFO - 2018-03-28 17:45:17 --> Helper loaded: url_helper
INFO - 2018-03-28 17:45:17 --> Helper loaded: notification_helper
INFO - 2018-03-28 17:45:17 --> Helper loaded: settings_helper
INFO - 2018-03-28 17:45:17 --> Helper loaded: permission_helper
INFO - 2018-03-28 17:45:17 --> Helper loaded: users_helper
INFO - 2018-03-28 12:15:17 --> Language Class Initialized
INFO - 2018-03-28 12:15:17 --> Config Class Initialized
INFO - 2018-03-28 12:15:17 --> Loader Class Initialized
INFO - 2018-03-28 17:45:18 --> Helper loaded: url_helper
INFO - 2018-03-28 17:45:18 --> Helper loaded: notification_helper
INFO - 2018-03-28 17:45:18 --> Helper loaded: settings_helper
INFO - 2018-03-28 17:45:18 --> Helper loaded: permission_helper
INFO - 2018-03-28 17:45:18 --> Helper loaded: users_helper
INFO - 2018-03-28 17:45:18 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:45:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:45:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:45:18 --> Helper loaded: form_helper
INFO - 2018-03-28 17:45:18 --> Form Validation Class Initialized
INFO - 2018-03-28 17:45:18 --> Controller Class Initialized
INFO - 2018-03-28 17:45:18 --> Model Class Initialized
INFO - 2018-03-28 17:45:18 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 17:45:18 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 17:45:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 17:45:18 --> Model Class Initialized
INFO - 2018-03-28 17:45:18 --> Model Class Initialized
INFO - 2018-03-28 17:45:18 --> Model Class Initialized
INFO - 2018-03-28 17:45:18 --> Model Class Initialized
INFO - 2018-03-28 17:45:18 --> Model Class Initialized
INFO - 2018-03-28 17:45:18 --> Model Class Initialized
INFO - 2018-03-28 17:45:18 --> Model Class Initialized
INFO - 2018-03-28 17:45:18 --> Model Class Initialized
INFO - 2018-03-28 17:45:18 --> Model Class Initialized
INFO - 2018-03-28 17:45:18 --> Model Class Initialized
INFO - 2018-03-28 17:45:18 --> Model Class Initialized
INFO - 2018-03-28 17:45:18 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 17:45:18 --> Model Class Initialized
INFO - 2018-03-28 17:45:18 --> Final output sent to browser
DEBUG - 2018-03-28 17:45:18 --> Total execution time: 2.9703
INFO - 2018-03-28 17:45:18 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:45:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:45:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:45:19 --> Helper loaded: form_helper
INFO - 2018-03-28 17:45:19 --> Form Validation Class Initialized
INFO - 2018-03-28 17:45:19 --> Controller Class Initialized
INFO - 2018-03-28 17:45:19 --> Model Class Initialized
INFO - 2018-03-28 17:45:19 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 17:45:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 17:45:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 17:45:20 --> Model Class Initialized
INFO - 2018-03-28 17:45:20 --> Model Class Initialized
INFO - 2018-03-28 17:45:20 --> Model Class Initialized
INFO - 2018-03-28 17:45:20 --> Model Class Initialized
INFO - 2018-03-28 17:45:20 --> Model Class Initialized
INFO - 2018-03-28 17:45:20 --> Model Class Initialized
INFO - 2018-03-28 17:45:20 --> Model Class Initialized
INFO - 2018-03-28 17:45:20 --> Model Class Initialized
INFO - 2018-03-28 17:45:20 --> Model Class Initialized
INFO - 2018-03-28 17:45:20 --> Model Class Initialized
INFO - 2018-03-28 17:45:20 --> Model Class Initialized
INFO - 2018-03-28 17:45:20 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 17:45:20 --> Final output sent to browser
DEBUG - 2018-03-28 17:45:20 --> Total execution time: 4.4407
INFO - 2018-03-28 12:15:22 --> Config Class Initialized
INFO - 2018-03-28 12:15:22 --> Hooks Class Initialized
DEBUG - 2018-03-28 12:15:22 --> UTF-8 Support Enabled
INFO - 2018-03-28 12:15:22 --> Utf8 Class Initialized
INFO - 2018-03-28 12:15:22 --> URI Class Initialized
INFO - 2018-03-28 12:15:22 --> Router Class Initialized
INFO - 2018-03-28 12:15:22 --> Output Class Initialized
INFO - 2018-03-28 12:15:22 --> Security Class Initialized
DEBUG - 2018-03-28 12:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 12:15:22 --> Input Class Initialized
INFO - 2018-03-28 12:15:22 --> Language Class Initialized
INFO - 2018-03-28 12:15:22 --> Language Class Initialized
INFO - 2018-03-28 12:15:22 --> Config Class Initialized
INFO - 2018-03-28 12:15:22 --> Loader Class Initialized
INFO - 2018-03-28 17:45:22 --> Helper loaded: url_helper
INFO - 2018-03-28 17:45:22 --> Helper loaded: notification_helper
INFO - 2018-03-28 17:45:22 --> Helper loaded: settings_helper
INFO - 2018-03-28 17:45:22 --> Helper loaded: permission_helper
INFO - 2018-03-28 17:45:22 --> Helper loaded: users_helper
INFO - 2018-03-28 17:45:22 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:45:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:45:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:45:22 --> Helper loaded: form_helper
INFO - 2018-03-28 17:45:22 --> Form Validation Class Initialized
INFO - 2018-03-28 17:45:22 --> Controller Class Initialized
INFO - 2018-03-28 17:45:22 --> Model Class Initialized
INFO - 2018-03-28 17:45:22 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 17:45:22 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 17:45:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 17:45:22 --> Model Class Initialized
INFO - 2018-03-28 17:45:22 --> Model Class Initialized
INFO - 2018-03-28 17:45:22 --> Model Class Initialized
INFO - 2018-03-28 17:45:22 --> Model Class Initialized
INFO - 2018-03-28 17:45:22 --> Model Class Initialized
INFO - 2018-03-28 17:45:22 --> Model Class Initialized
INFO - 2018-03-28 17:45:22 --> Model Class Initialized
INFO - 2018-03-28 17:45:22 --> Model Class Initialized
INFO - 2018-03-28 17:45:22 --> Model Class Initialized
INFO - 2018-03-28 17:45:22 --> Model Class Initialized
INFO - 2018-03-28 17:45:22 --> Model Class Initialized
INFO - 2018-03-28 17:45:22 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 17:45:22 --> Final output sent to browser
DEBUG - 2018-03-28 17:45:22 --> Total execution time: 0.5576
INFO - 2018-03-28 12:15:28 --> Config Class Initialized
INFO - 2018-03-28 12:15:28 --> Hooks Class Initialized
DEBUG - 2018-03-28 12:15:28 --> UTF-8 Support Enabled
INFO - 2018-03-28 12:15:28 --> Utf8 Class Initialized
INFO - 2018-03-28 12:15:28 --> URI Class Initialized
INFO - 2018-03-28 12:15:28 --> Router Class Initialized
INFO - 2018-03-28 12:15:28 --> Output Class Initialized
INFO - 2018-03-28 12:15:28 --> Security Class Initialized
DEBUG - 2018-03-28 12:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 12:15:28 --> Input Class Initialized
INFO - 2018-03-28 12:15:28 --> Language Class Initialized
INFO - 2018-03-28 12:15:28 --> Language Class Initialized
INFO - 2018-03-28 12:15:28 --> Config Class Initialized
INFO - 2018-03-28 12:15:28 --> Loader Class Initialized
INFO - 2018-03-28 17:45:28 --> Helper loaded: url_helper
INFO - 2018-03-28 17:45:28 --> Helper loaded: notification_helper
INFO - 2018-03-28 17:45:28 --> Helper loaded: settings_helper
INFO - 2018-03-28 17:45:29 --> Helper loaded: permission_helper
INFO - 2018-03-28 17:45:29 --> Helper loaded: users_helper
INFO - 2018-03-28 17:45:29 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:45:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:45:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:45:29 --> Helper loaded: form_helper
INFO - 2018-03-28 17:45:29 --> Form Validation Class Initialized
INFO - 2018-03-28 17:45:29 --> Controller Class Initialized
INFO - 2018-03-28 17:45:29 --> Model Class Initialized
INFO - 2018-03-28 17:45:29 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 17:45:29 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 17:45:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 17:45:29 --> Model Class Initialized
INFO - 2018-03-28 17:45:29 --> Model Class Initialized
INFO - 2018-03-28 17:45:29 --> Model Class Initialized
INFO - 2018-03-28 17:45:29 --> Model Class Initialized
INFO - 2018-03-28 17:45:29 --> Model Class Initialized
INFO - 2018-03-28 17:45:29 --> Model Class Initialized
INFO - 2018-03-28 17:45:29 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-28 17:45:29 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-28 17:45:29 --> Final output sent to browser
DEBUG - 2018-03-28 17:45:29 --> Total execution time: 0.4914
INFO - 2018-03-28 12:37:46 --> Config Class Initialized
INFO - 2018-03-28 12:37:46 --> Hooks Class Initialized
DEBUG - 2018-03-28 12:37:46 --> UTF-8 Support Enabled
INFO - 2018-03-28 12:37:46 --> Utf8 Class Initialized
INFO - 2018-03-28 12:37:46 --> URI Class Initialized
INFO - 2018-03-28 12:37:46 --> Router Class Initialized
INFO - 2018-03-28 12:37:46 --> Output Class Initialized
INFO - 2018-03-28 12:37:46 --> Security Class Initialized
DEBUG - 2018-03-28 12:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 12:37:46 --> Input Class Initialized
INFO - 2018-03-28 12:37:46 --> Language Class Initialized
INFO - 2018-03-28 12:37:47 --> Language Class Initialized
INFO - 2018-03-28 12:37:47 --> Config Class Initialized
INFO - 2018-03-28 12:37:47 --> Loader Class Initialized
INFO - 2018-03-28 18:07:47 --> Helper loaded: url_helper
INFO - 2018-03-28 18:07:47 --> Helper loaded: notification_helper
INFO - 2018-03-28 18:07:47 --> Helper loaded: settings_helper
INFO - 2018-03-28 18:07:47 --> Helper loaded: permission_helper
INFO - 2018-03-28 18:07:47 --> Helper loaded: users_helper
INFO - 2018-03-28 18:07:48 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:07:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:07:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:07:48 --> Helper loaded: form_helper
INFO - 2018-03-28 18:07:48 --> Form Validation Class Initialized
INFO - 2018-03-28 18:07:48 --> Controller Class Initialized
INFO - 2018-03-28 18:07:48 --> Model Class Initialized
INFO - 2018-03-28 18:07:48 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 18:07:48 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 18:07:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 18:07:48 --> Model Class Initialized
INFO - 2018-03-28 18:07:48 --> Model Class Initialized
INFO - 2018-03-28 18:07:48 --> Model Class Initialized
INFO - 2018-03-28 18:07:48 --> Model Class Initialized
INFO - 2018-03-28 18:07:48 --> Model Class Initialized
INFO - 2018-03-28 18:07:48 --> Model Class Initialized
INFO - 2018-03-28 18:07:48 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 18:07:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-28 18:07:48 --> Final output sent to browser
DEBUG - 2018-03-28 18:07:48 --> Total execution time: 1.8230
INFO - 2018-03-28 12:37:49 --> Config Class Initialized
INFO - 2018-03-28 12:37:49 --> Hooks Class Initialized
DEBUG - 2018-03-28 12:37:50 --> UTF-8 Support Enabled
INFO - 2018-03-28 12:37:50 --> Utf8 Class Initialized
INFO - 2018-03-28 12:37:50 --> URI Class Initialized
INFO - 2018-03-28 12:37:50 --> Router Class Initialized
INFO - 2018-03-28 12:37:50 --> Output Class Initialized
INFO - 2018-03-28 12:37:50 --> Security Class Initialized
INFO - 2018-03-28 12:37:50 --> Config Class Initialized
INFO - 2018-03-28 12:37:50 --> Hooks Class Initialized
DEBUG - 2018-03-28 12:37:50 --> UTF-8 Support Enabled
DEBUG - 2018-03-28 12:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 12:37:50 --> Input Class Initialized
INFO - 2018-03-28 12:37:50 --> Language Class Initialized
INFO - 2018-03-28 12:37:50 --> Utf8 Class Initialized
INFO - 2018-03-28 12:37:50 --> URI Class Initialized
INFO - 2018-03-28 12:37:50 --> Router Class Initialized
INFO - 2018-03-28 12:37:50 --> Output Class Initialized
INFO - 2018-03-28 12:37:50 --> Security Class Initialized
DEBUG - 2018-03-28 12:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 12:37:50 --> Input Class Initialized
INFO - 2018-03-28 12:37:50 --> Language Class Initialized
INFO - 2018-03-28 12:37:50 --> Language Class Initialized
INFO - 2018-03-28 12:37:50 --> Config Class Initialized
INFO - 2018-03-28 12:37:50 --> Loader Class Initialized
INFO - 2018-03-28 18:07:50 --> Helper loaded: url_helper
INFO - 2018-03-28 18:07:50 --> Helper loaded: notification_helper
INFO - 2018-03-28 18:07:50 --> Helper loaded: settings_helper
INFO - 2018-03-28 18:07:50 --> Helper loaded: permission_helper
INFO - 2018-03-28 18:07:50 --> Helper loaded: users_helper
INFO - 2018-03-28 12:37:50 --> Language Class Initialized
INFO - 2018-03-28 12:37:50 --> Config Class Initialized
INFO - 2018-03-28 12:37:50 --> Loader Class Initialized
INFO - 2018-03-28 18:07:50 --> Database Driver Class Initialized
INFO - 2018-03-28 18:07:50 --> Helper loaded: url_helper
DEBUG - 2018-03-28 18:07:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:07:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:07:50 --> Helper loaded: notification_helper
INFO - 2018-03-28 18:07:50 --> Helper loaded: settings_helper
INFO - 2018-03-28 18:07:50 --> Helper loaded: permission_helper
INFO - 2018-03-28 18:07:50 --> Helper loaded: users_helper
INFO - 2018-03-28 18:07:50 --> Helper loaded: form_helper
INFO - 2018-03-28 18:07:50 --> Form Validation Class Initialized
INFO - 2018-03-28 18:07:50 --> Controller Class Initialized
INFO - 2018-03-28 18:07:51 --> Database Driver Class Initialized
INFO - 2018-03-28 18:07:51 --> Model Class Initialized
INFO - 2018-03-28 18:07:51 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 18:07:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:07:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-03-28 18:07:51 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 18:07:51 --> Helper loaded: form_helper
INFO - 2018-03-28 18:07:51 --> Form Validation Class Initialized
INFO - 2018-03-28 18:07:51 --> Controller Class Initialized
INFO - 2018-03-28 18:07:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 18:07:51 --> Model Class Initialized
INFO - 2018-03-28 18:07:51 --> Model Class Initialized
INFO - 2018-03-28 18:07:51 --> Model Class Initialized
INFO - 2018-03-28 18:07:51 --> Model Class Initialized
INFO - 2018-03-28 18:07:51 --> Model Class Initialized
INFO - 2018-03-28 18:07:51 --> Model Class Initialized
INFO - 2018-03-28 18:07:51 --> Model Class Initialized
INFO - 2018-03-28 18:07:51 --> Helper loaded: inflector_helper
INFO - 2018-03-28 18:07:51 --> Model Class Initialized
INFO - 2018-03-28 18:07:51 --> Model Class Initialized
INFO - 2018-03-28 18:07:51 --> Model Class Initialized
INFO - 2018-03-28 18:07:51 --> Model Class Initialized
DEBUG - 2018-03-28 18:07:51 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 18:07:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 18:07:51 --> Model Class Initialized
INFO - 2018-03-28 18:07:51 --> Model Class Initialized
INFO - 2018-03-28 18:07:51 --> Model Class Initialized
INFO - 2018-03-28 18:07:51 --> Model Class Initialized
INFO - 2018-03-28 18:07:51 --> Model Class Initialized
INFO - 2018-03-28 18:07:51 --> Model Class Initialized
INFO - 2018-03-28 18:07:51 --> Model Class Initialized
INFO - 2018-03-28 18:07:51 --> Model Class Initialized
INFO - 2018-03-28 18:07:51 --> Model Class Initialized
INFO - 2018-03-28 18:07:51 --> Model Class Initialized
INFO - 2018-03-28 18:07:51 --> Model Class Initialized
INFO - 2018-03-28 18:07:51 --> Model Class Initialized
INFO - 2018-03-28 18:07:51 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 18:07:51 --> Model Class Initialized
INFO - 2018-03-28 18:07:51 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 18:07:51 --> Model Class Initialized
INFO - 2018-03-28 18:07:51 --> Final output sent to browser
DEBUG - 2018-03-28 18:07:51 --> Total execution time: 1.2348
INFO - 2018-03-28 18:07:51 --> Final output sent to browser
DEBUG - 2018-03-28 18:07:51 --> Total execution time: 1.5474
INFO - 2018-03-28 12:37:52 --> Config Class Initialized
INFO - 2018-03-28 12:37:52 --> Hooks Class Initialized
DEBUG - 2018-03-28 12:37:52 --> UTF-8 Support Enabled
INFO - 2018-03-28 12:37:52 --> Utf8 Class Initialized
INFO - 2018-03-28 12:37:52 --> URI Class Initialized
INFO - 2018-03-28 12:37:53 --> Router Class Initialized
INFO - 2018-03-28 12:37:53 --> Output Class Initialized
INFO - 2018-03-28 12:37:53 --> Security Class Initialized
DEBUG - 2018-03-28 12:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 12:37:53 --> Input Class Initialized
INFO - 2018-03-28 12:37:53 --> Language Class Initialized
INFO - 2018-03-28 12:37:53 --> Language Class Initialized
INFO - 2018-03-28 12:37:53 --> Config Class Initialized
INFO - 2018-03-28 12:37:53 --> Loader Class Initialized
INFO - 2018-03-28 18:07:53 --> Helper loaded: url_helper
INFO - 2018-03-28 18:07:53 --> Helper loaded: notification_helper
INFO - 2018-03-28 18:07:53 --> Helper loaded: settings_helper
INFO - 2018-03-28 18:07:53 --> Helper loaded: permission_helper
INFO - 2018-03-28 18:07:53 --> Helper loaded: users_helper
INFO - 2018-03-28 18:07:53 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:07:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:07:53 --> Helper loaded: form_helper
INFO - 2018-03-28 18:07:53 --> Form Validation Class Initialized
INFO - 2018-03-28 18:07:53 --> Controller Class Initialized
INFO - 2018-03-28 18:07:53 --> Model Class Initialized
INFO - 2018-03-28 18:07:53 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 18:07:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 18:07:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 18:07:53 --> Model Class Initialized
INFO - 2018-03-28 18:07:53 --> Model Class Initialized
INFO - 2018-03-28 18:07:53 --> Model Class Initialized
INFO - 2018-03-28 18:07:53 --> Model Class Initialized
INFO - 2018-03-28 18:07:53 --> Model Class Initialized
INFO - 2018-03-28 18:07:53 --> Model Class Initialized
INFO - 2018-03-28 18:07:53 --> Model Class Initialized
INFO - 2018-03-28 18:07:53 --> Model Class Initialized
INFO - 2018-03-28 18:07:53 --> Model Class Initialized
INFO - 2018-03-28 18:07:53 --> Model Class Initialized
INFO - 2018-03-28 18:07:53 --> Model Class Initialized
INFO - 2018-03-28 18:07:53 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 18:07:53 --> Model Class Initialized
INFO - 2018-03-28 18:07:53 --> Final output sent to browser
DEBUG - 2018-03-28 18:07:53 --> Total execution time: 0.9574
INFO - 2018-03-28 12:38:02 --> Config Class Initialized
INFO - 2018-03-28 12:38:02 --> Hooks Class Initialized
DEBUG - 2018-03-28 12:38:02 --> UTF-8 Support Enabled
INFO - 2018-03-28 12:38:02 --> Utf8 Class Initialized
INFO - 2018-03-28 12:38:03 --> URI Class Initialized
INFO - 2018-03-28 12:38:03 --> Router Class Initialized
INFO - 2018-03-28 12:38:03 --> Output Class Initialized
INFO - 2018-03-28 12:38:03 --> Security Class Initialized
DEBUG - 2018-03-28 12:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 12:38:03 --> Input Class Initialized
INFO - 2018-03-28 12:38:03 --> Language Class Initialized
INFO - 2018-03-28 12:38:04 --> Language Class Initialized
INFO - 2018-03-28 12:38:04 --> Config Class Initialized
INFO - 2018-03-28 12:38:04 --> Loader Class Initialized
INFO - 2018-03-28 18:08:04 --> Helper loaded: url_helper
INFO - 2018-03-28 18:08:04 --> Helper loaded: notification_helper
INFO - 2018-03-28 18:08:04 --> Helper loaded: settings_helper
INFO - 2018-03-28 18:08:04 --> Helper loaded: permission_helper
INFO - 2018-03-28 18:08:04 --> Helper loaded: users_helper
INFO - 2018-03-28 18:08:05 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:08:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:08:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:08:06 --> Helper loaded: form_helper
INFO - 2018-03-28 18:08:06 --> Form Validation Class Initialized
INFO - 2018-03-28 18:08:06 --> Controller Class Initialized
INFO - 2018-03-28 12:38:06 --> Config Class Initialized
INFO - 2018-03-28 12:38:06 --> Hooks Class Initialized
INFO - 2018-03-28 18:08:06 --> Model Class Initialized
INFO - 2018-03-28 18:08:06 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 18:08:06 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-03-28 12:38:06 --> UTF-8 Support Enabled
INFO - 2018-03-28 12:38:06 --> Utf8 Class Initialized
INFO - 2018-03-28 18:08:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 18:08:06 --> Model Class Initialized
INFO - 2018-03-28 18:08:06 --> Model Class Initialized
INFO - 2018-03-28 12:38:06 --> URI Class Initialized
INFO - 2018-03-28 18:08:06 --> Model Class Initialized
INFO - 2018-03-28 18:08:06 --> Model Class Initialized
INFO - 2018-03-28 18:08:06 --> Model Class Initialized
INFO - 2018-03-28 18:08:06 --> Model Class Initialized
INFO - 2018-03-28 18:08:06 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-28 18:08:06 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-28 18:08:06 --> Final output sent to browser
DEBUG - 2018-03-28 18:08:06 --> Total execution time: 4.2128
INFO - 2018-03-28 12:38:06 --> Router Class Initialized
INFO - 2018-03-28 12:38:06 --> Output Class Initialized
INFO - 2018-03-28 12:38:07 --> Security Class Initialized
DEBUG - 2018-03-28 12:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 12:38:07 --> Input Class Initialized
INFO - 2018-03-28 12:38:07 --> Language Class Initialized
INFO - 2018-03-28 12:38:08 --> Language Class Initialized
INFO - 2018-03-28 12:38:08 --> Config Class Initialized
INFO - 2018-03-28 12:38:08 --> Loader Class Initialized
INFO - 2018-03-28 18:08:08 --> Helper loaded: url_helper
INFO - 2018-03-28 18:08:08 --> Helper loaded: notification_helper
INFO - 2018-03-28 18:08:08 --> Helper loaded: settings_helper
INFO - 2018-03-28 18:08:08 --> Helper loaded: permission_helper
INFO - 2018-03-28 18:08:08 --> Helper loaded: users_helper
INFO - 2018-03-28 18:08:08 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:08:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:08:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:08:08 --> Helper loaded: form_helper
INFO - 2018-03-28 18:08:08 --> Form Validation Class Initialized
INFO - 2018-03-28 18:08:08 --> Controller Class Initialized
INFO - 2018-03-28 18:08:08 --> Model Class Initialized
INFO - 2018-03-28 18:08:08 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 18:08:08 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 18:08:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 18:08:08 --> Model Class Initialized
INFO - 2018-03-28 18:08:08 --> Model Class Initialized
INFO - 2018-03-28 18:08:08 --> Model Class Initialized
INFO - 2018-03-28 18:08:08 --> Model Class Initialized
INFO - 2018-03-28 18:08:08 --> Model Class Initialized
INFO - 2018-03-28 18:08:08 --> Model Class Initialized
INFO - 2018-03-28 18:08:08 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-28 18:08:08 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-28 18:08:08 --> Final output sent to browser
DEBUG - 2018-03-28 18:08:08 --> Total execution time: 2.8358
INFO - 2018-03-28 12:38:14 --> Config Class Initialized
INFO - 2018-03-28 12:38:14 --> Hooks Class Initialized
DEBUG - 2018-03-28 12:38:14 --> UTF-8 Support Enabled
INFO - 2018-03-28 12:38:14 --> Utf8 Class Initialized
INFO - 2018-03-28 12:38:14 --> URI Class Initialized
INFO - 2018-03-28 12:38:14 --> Router Class Initialized
INFO - 2018-03-28 12:38:14 --> Output Class Initialized
INFO - 2018-03-28 12:38:14 --> Security Class Initialized
DEBUG - 2018-03-28 12:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 12:38:14 --> Input Class Initialized
INFO - 2018-03-28 12:38:14 --> Language Class Initialized
INFO - 2018-03-28 12:38:14 --> Language Class Initialized
INFO - 2018-03-28 12:38:14 --> Config Class Initialized
INFO - 2018-03-28 12:38:14 --> Loader Class Initialized
INFO - 2018-03-28 18:08:14 --> Helper loaded: url_helper
INFO - 2018-03-28 18:08:14 --> Helper loaded: notification_helper
INFO - 2018-03-28 18:08:14 --> Helper loaded: settings_helper
INFO - 2018-03-28 18:08:14 --> Helper loaded: permission_helper
INFO - 2018-03-28 18:08:14 --> Helper loaded: users_helper
INFO - 2018-03-28 18:08:14 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:08:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:08:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:08:14 --> Helper loaded: form_helper
INFO - 2018-03-28 18:08:14 --> Form Validation Class Initialized
INFO - 2018-03-28 18:08:14 --> Controller Class Initialized
INFO - 2018-03-28 18:08:14 --> Model Class Initialized
INFO - 2018-03-28 18:08:14 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 18:08:14 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 18:08:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 18:08:14 --> Model Class Initialized
INFO - 2018-03-28 18:08:14 --> Model Class Initialized
INFO - 2018-03-28 18:08:14 --> Model Class Initialized
INFO - 2018-03-28 18:08:14 --> Model Class Initialized
INFO - 2018-03-28 18:08:14 --> Model Class Initialized
INFO - 2018-03-28 18:08:14 --> Model Class Initialized
INFO - 2018-03-28 18:08:14 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-28 18:08:14 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-28 18:08:14 --> Final output sent to browser
DEBUG - 2018-03-28 18:08:14 --> Total execution time: 0.1091
INFO - 2018-03-28 12:39:43 --> Config Class Initialized
INFO - 2018-03-28 12:39:43 --> Hooks Class Initialized
DEBUG - 2018-03-28 12:39:43 --> UTF-8 Support Enabled
INFO - 2018-03-28 12:39:43 --> Utf8 Class Initialized
INFO - 2018-03-28 12:39:43 --> URI Class Initialized
INFO - 2018-03-28 12:39:43 --> Router Class Initialized
INFO - 2018-03-28 12:39:43 --> Output Class Initialized
INFO - 2018-03-28 12:39:43 --> Security Class Initialized
DEBUG - 2018-03-28 12:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 12:39:43 --> Input Class Initialized
INFO - 2018-03-28 12:39:43 --> Language Class Initialized
INFO - 2018-03-28 12:39:44 --> Language Class Initialized
INFO - 2018-03-28 12:39:44 --> Config Class Initialized
INFO - 2018-03-28 12:39:44 --> Loader Class Initialized
INFO - 2018-03-28 18:09:44 --> Helper loaded: url_helper
INFO - 2018-03-28 18:09:44 --> Helper loaded: notification_helper
INFO - 2018-03-28 18:09:44 --> Helper loaded: settings_helper
INFO - 2018-03-28 18:09:44 --> Helper loaded: permission_helper
INFO - 2018-03-28 18:09:44 --> Helper loaded: users_helper
INFO - 2018-03-28 18:09:44 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:09:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:09:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:09:44 --> Helper loaded: form_helper
INFO - 2018-03-28 18:09:44 --> Form Validation Class Initialized
INFO - 2018-03-28 18:09:44 --> Controller Class Initialized
INFO - 2018-03-28 18:09:44 --> Model Class Initialized
INFO - 2018-03-28 18:09:44 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 18:09:44 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 18:09:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 18:09:44 --> Model Class Initialized
INFO - 2018-03-28 18:09:44 --> Model Class Initialized
INFO - 2018-03-28 18:09:44 --> Model Class Initialized
INFO - 2018-03-28 18:09:44 --> Model Class Initialized
INFO - 2018-03-28 18:09:44 --> Model Class Initialized
INFO - 2018-03-28 18:09:44 --> Model Class Initialized
INFO - 2018-03-28 18:09:44 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 18:09:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-28 18:09:44 --> Final output sent to browser
DEBUG - 2018-03-28 18:09:44 --> Total execution time: 0.5802
INFO - 2018-03-28 12:39:45 --> Config Class Initialized
INFO - 2018-03-28 12:39:45 --> Hooks Class Initialized
DEBUG - 2018-03-28 12:39:45 --> UTF-8 Support Enabled
INFO - 2018-03-28 12:39:45 --> Utf8 Class Initialized
INFO - 2018-03-28 12:39:45 --> URI Class Initialized
INFO - 2018-03-28 12:39:45 --> Router Class Initialized
INFO - 2018-03-28 12:39:45 --> Output Class Initialized
INFO - 2018-03-28 12:39:45 --> Security Class Initialized
DEBUG - 2018-03-28 12:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 12:39:45 --> Input Class Initialized
INFO - 2018-03-28 12:39:46 --> Language Class Initialized
INFO - 2018-03-28 12:39:46 --> Language Class Initialized
INFO - 2018-03-28 12:39:46 --> Config Class Initialized
INFO - 2018-03-28 12:39:46 --> Loader Class Initialized
INFO - 2018-03-28 18:09:46 --> Helper loaded: url_helper
INFO - 2018-03-28 18:09:46 --> Helper loaded: notification_helper
INFO - 2018-03-28 18:09:46 --> Helper loaded: settings_helper
INFO - 2018-03-28 18:09:46 --> Helper loaded: permission_helper
INFO - 2018-03-28 18:09:46 --> Helper loaded: users_helper
INFO - 2018-03-28 18:09:46 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:09:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:09:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:09:46 --> Helper loaded: form_helper
INFO - 2018-03-28 18:09:46 --> Form Validation Class Initialized
INFO - 2018-03-28 18:09:46 --> Controller Class Initialized
INFO - 2018-03-28 18:09:46 --> Model Class Initialized
INFO - 2018-03-28 18:09:46 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 18:09:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 18:09:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 18:09:46 --> Model Class Initialized
INFO - 2018-03-28 18:09:46 --> Model Class Initialized
INFO - 2018-03-28 18:09:46 --> Model Class Initialized
INFO - 2018-03-28 18:09:46 --> Model Class Initialized
INFO - 2018-03-28 18:09:46 --> Model Class Initialized
INFO - 2018-03-28 18:09:46 --> Model Class Initialized
INFO - 2018-03-28 18:09:46 --> Model Class Initialized
INFO - 2018-03-28 18:09:46 --> Model Class Initialized
INFO - 2018-03-28 18:09:46 --> Model Class Initialized
INFO - 2018-03-28 18:09:46 --> Model Class Initialized
INFO - 2018-03-28 18:09:46 --> Model Class Initialized
INFO - 2018-03-28 18:09:46 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 18:09:46 --> Model Class Initialized
INFO - 2018-03-28 18:09:46 --> Final output sent to browser
DEBUG - 2018-03-28 18:09:46 --> Total execution time: 0.2267
INFO - 2018-03-28 12:39:46 --> Config Class Initialized
INFO - 2018-03-28 12:39:46 --> Hooks Class Initialized
DEBUG - 2018-03-28 12:39:46 --> UTF-8 Support Enabled
INFO - 2018-03-28 12:39:46 --> Utf8 Class Initialized
INFO - 2018-03-28 12:39:46 --> URI Class Initialized
INFO - 2018-03-28 12:39:47 --> Router Class Initialized
INFO - 2018-03-28 12:39:47 --> Output Class Initialized
INFO - 2018-03-28 12:39:47 --> Security Class Initialized
DEBUG - 2018-03-28 12:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 12:39:47 --> Input Class Initialized
INFO - 2018-03-28 12:39:47 --> Language Class Initialized
INFO - 2018-03-28 12:39:47 --> Config Class Initialized
INFO - 2018-03-28 12:39:47 --> Hooks Class Initialized
DEBUG - 2018-03-28 12:39:47 --> UTF-8 Support Enabled
INFO - 2018-03-28 12:39:47 --> Utf8 Class Initialized
INFO - 2018-03-28 12:39:47 --> URI Class Initialized
INFO - 2018-03-28 12:39:47 --> Router Class Initialized
INFO - 2018-03-28 12:39:47 --> Output Class Initialized
INFO - 2018-03-28 12:39:47 --> Security Class Initialized
DEBUG - 2018-03-28 12:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 12:39:47 --> Input Class Initialized
INFO - 2018-03-28 12:39:47 --> Language Class Initialized
INFO - 2018-03-28 12:39:47 --> Language Class Initialized
INFO - 2018-03-28 12:39:47 --> Config Class Initialized
INFO - 2018-03-28 12:39:47 --> Loader Class Initialized
INFO - 2018-03-28 18:09:47 --> Helper loaded: url_helper
INFO - 2018-03-28 18:09:47 --> Helper loaded: notification_helper
INFO - 2018-03-28 18:09:47 --> Helper loaded: settings_helper
INFO - 2018-03-28 18:09:47 --> Helper loaded: permission_helper
INFO - 2018-03-28 18:09:47 --> Helper loaded: users_helper
INFO - 2018-03-28 18:09:47 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:09:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:09:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:09:47 --> Helper loaded: form_helper
INFO - 2018-03-28 18:09:47 --> Form Validation Class Initialized
INFO - 2018-03-28 18:09:47 --> Controller Class Initialized
INFO - 2018-03-28 18:09:47 --> Model Class Initialized
INFO - 2018-03-28 18:09:47 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 18:09:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 18:09:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 18:09:47 --> Model Class Initialized
INFO - 2018-03-28 18:09:47 --> Model Class Initialized
INFO - 2018-03-28 18:09:47 --> Model Class Initialized
INFO - 2018-03-28 18:09:47 --> Model Class Initialized
INFO - 2018-03-28 18:09:47 --> Model Class Initialized
INFO - 2018-03-28 18:09:47 --> Model Class Initialized
INFO - 2018-03-28 18:09:47 --> Model Class Initialized
INFO - 2018-03-28 18:09:47 --> Model Class Initialized
INFO - 2018-03-28 18:09:47 --> Model Class Initialized
INFO - 2018-03-28 18:09:47 --> Model Class Initialized
INFO - 2018-03-28 18:09:47 --> Model Class Initialized
INFO - 2018-03-28 18:09:47 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 18:09:47 --> Model Class Initialized
INFO - 2018-03-28 18:09:47 --> Final output sent to browser
DEBUG - 2018-03-28 18:09:47 --> Total execution time: 0.1194
INFO - 2018-03-28 12:39:48 --> Language Class Initialized
INFO - 2018-03-28 12:39:48 --> Config Class Initialized
INFO - 2018-03-28 12:39:48 --> Loader Class Initialized
INFO - 2018-03-28 18:09:48 --> Helper loaded: url_helper
INFO - 2018-03-28 18:09:48 --> Helper loaded: notification_helper
INFO - 2018-03-28 18:09:48 --> Helper loaded: settings_helper
INFO - 2018-03-28 18:09:48 --> Helper loaded: permission_helper
INFO - 2018-03-28 18:09:48 --> Helper loaded: users_helper
INFO - 2018-03-28 18:09:49 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:09:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:09:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:09:49 --> Helper loaded: form_helper
INFO - 2018-03-28 18:09:49 --> Form Validation Class Initialized
INFO - 2018-03-28 18:09:49 --> Controller Class Initialized
INFO - 2018-03-28 18:09:49 --> Model Class Initialized
INFO - 2018-03-28 18:09:49 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 18:09:49 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 18:09:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 18:09:49 --> Model Class Initialized
INFO - 2018-03-28 18:09:49 --> Model Class Initialized
INFO - 2018-03-28 18:09:49 --> Model Class Initialized
INFO - 2018-03-28 18:09:49 --> Model Class Initialized
INFO - 2018-03-28 18:09:49 --> Model Class Initialized
INFO - 2018-03-28 18:09:49 --> Model Class Initialized
INFO - 2018-03-28 18:09:49 --> Model Class Initialized
INFO - 2018-03-28 18:09:49 --> Model Class Initialized
INFO - 2018-03-28 18:09:49 --> Model Class Initialized
INFO - 2018-03-28 18:09:49 --> Model Class Initialized
INFO - 2018-03-28 18:09:49 --> Model Class Initialized
INFO - 2018-03-28 18:09:49 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 18:09:49 --> Model Class Initialized
INFO - 2018-03-28 18:09:49 --> Final output sent to browser
DEBUG - 2018-03-28 18:09:49 --> Total execution time: 3.1119
INFO - 2018-03-28 12:39:51 --> Config Class Initialized
INFO - 2018-03-28 12:39:51 --> Hooks Class Initialized
DEBUG - 2018-03-28 12:39:51 --> UTF-8 Support Enabled
INFO - 2018-03-28 12:39:51 --> Utf8 Class Initialized
INFO - 2018-03-28 12:39:51 --> URI Class Initialized
INFO - 2018-03-28 12:39:51 --> Router Class Initialized
INFO - 2018-03-28 12:39:51 --> Output Class Initialized
INFO - 2018-03-28 12:39:51 --> Security Class Initialized
DEBUG - 2018-03-28 12:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 12:39:51 --> Input Class Initialized
INFO - 2018-03-28 12:39:51 --> Language Class Initialized
INFO - 2018-03-28 12:39:52 --> Language Class Initialized
INFO - 2018-03-28 12:39:52 --> Config Class Initialized
INFO - 2018-03-28 12:39:52 --> Loader Class Initialized
INFO - 2018-03-28 18:09:52 --> Helper loaded: url_helper
INFO - 2018-03-28 18:09:52 --> Helper loaded: notification_helper
INFO - 2018-03-28 18:09:52 --> Helper loaded: settings_helper
INFO - 2018-03-28 18:09:52 --> Helper loaded: permission_helper
INFO - 2018-03-28 18:09:52 --> Helper loaded: users_helper
INFO - 2018-03-28 12:39:54 --> Config Class Initialized
INFO - 2018-03-28 12:39:54 --> Hooks Class Initialized
DEBUG - 2018-03-28 12:39:54 --> UTF-8 Support Enabled
INFO - 2018-03-28 12:39:54 --> Utf8 Class Initialized
INFO - 2018-03-28 12:39:54 --> URI Class Initialized
INFO - 2018-03-28 12:39:54 --> Router Class Initialized
INFO - 2018-03-28 12:39:54 --> Output Class Initialized
INFO - 2018-03-28 12:39:54 --> Security Class Initialized
DEBUG - 2018-03-28 12:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 12:39:54 --> Input Class Initialized
INFO - 2018-03-28 12:39:54 --> Language Class Initialized
INFO - 2018-03-28 12:39:54 --> Language Class Initialized
INFO - 2018-03-28 12:39:54 --> Config Class Initialized
INFO - 2018-03-28 12:39:54 --> Loader Class Initialized
INFO - 2018-03-28 18:09:54 --> Helper loaded: url_helper
INFO - 2018-03-28 18:09:54 --> Helper loaded: notification_helper
INFO - 2018-03-28 18:09:54 --> Helper loaded: settings_helper
INFO - 2018-03-28 18:09:54 --> Helper loaded: permission_helper
INFO - 2018-03-28 18:09:54 --> Helper loaded: users_helper
INFO - 2018-03-28 18:09:54 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:09:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:09:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:09:54 --> Helper loaded: form_helper
INFO - 2018-03-28 18:09:54 --> Form Validation Class Initialized
INFO - 2018-03-28 18:09:54 --> Controller Class Initialized
INFO - 2018-03-28 18:09:54 --> Model Class Initialized
INFO - 2018-03-28 18:09:54 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 18:09:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 18:09:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 18:09:54 --> Model Class Initialized
INFO - 2018-03-28 18:09:54 --> Model Class Initialized
INFO - 2018-03-28 18:09:54 --> Model Class Initialized
INFO - 2018-03-28 18:09:54 --> Model Class Initialized
INFO - 2018-03-28 18:09:54 --> Model Class Initialized
INFO - 2018-03-28 18:09:54 --> Model Class Initialized
INFO - 2018-03-28 18:09:54 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-28 18:09:54 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-28 18:09:54 --> Final output sent to browser
DEBUG - 2018-03-28 18:09:54 --> Total execution time: 0.1143
INFO - 2018-03-28 18:09:54 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:09:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:09:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:09:54 --> Helper loaded: form_helper
INFO - 2018-03-28 18:09:54 --> Form Validation Class Initialized
INFO - 2018-03-28 18:09:54 --> Controller Class Initialized
INFO - 2018-03-28 18:09:54 --> Model Class Initialized
INFO - 2018-03-28 18:09:54 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 18:09:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 18:09:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 18:09:54 --> Model Class Initialized
INFO - 2018-03-28 18:09:54 --> Model Class Initialized
INFO - 2018-03-28 18:09:54 --> Model Class Initialized
INFO - 2018-03-28 18:09:54 --> Model Class Initialized
INFO - 2018-03-28 18:09:54 --> Model Class Initialized
INFO - 2018-03-28 18:09:54 --> Model Class Initialized
INFO - 2018-03-28 18:09:54 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-28 18:09:54 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-28 18:09:54 --> Final output sent to browser
DEBUG - 2018-03-28 18:09:54 --> Total execution time: 3.2277
INFO - 2018-03-28 12:42:23 --> Config Class Initialized
INFO - 2018-03-28 12:42:23 --> Hooks Class Initialized
DEBUG - 2018-03-28 12:42:23 --> UTF-8 Support Enabled
INFO - 2018-03-28 12:42:23 --> Utf8 Class Initialized
INFO - 2018-03-28 12:42:23 --> URI Class Initialized
INFO - 2018-03-28 12:42:23 --> Router Class Initialized
INFO - 2018-03-28 12:42:23 --> Output Class Initialized
INFO - 2018-03-28 12:42:23 --> Security Class Initialized
DEBUG - 2018-03-28 12:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 12:42:23 --> Input Class Initialized
INFO - 2018-03-28 12:42:23 --> Language Class Initialized
INFO - 2018-03-28 12:42:23 --> Language Class Initialized
INFO - 2018-03-28 12:42:23 --> Config Class Initialized
INFO - 2018-03-28 12:42:23 --> Loader Class Initialized
INFO - 2018-03-28 18:12:23 --> Helper loaded: url_helper
INFO - 2018-03-28 18:12:23 --> Helper loaded: notification_helper
INFO - 2018-03-28 18:12:23 --> Helper loaded: settings_helper
INFO - 2018-03-28 18:12:23 --> Helper loaded: permission_helper
INFO - 2018-03-28 18:12:23 --> Helper loaded: users_helper
INFO - 2018-03-28 18:12:23 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:12:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:12:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:12:23 --> Helper loaded: form_helper
INFO - 2018-03-28 18:12:23 --> Form Validation Class Initialized
INFO - 2018-03-28 18:12:23 --> Controller Class Initialized
INFO - 2018-03-28 18:12:23 --> Model Class Initialized
INFO - 2018-03-28 18:12:23 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 18:12:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 18:12:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 18:12:23 --> Model Class Initialized
INFO - 2018-03-28 18:12:23 --> Model Class Initialized
INFO - 2018-03-28 18:12:23 --> Model Class Initialized
INFO - 2018-03-28 18:12:23 --> Model Class Initialized
INFO - 2018-03-28 18:12:23 --> Model Class Initialized
INFO - 2018-03-28 18:12:23 --> Model Class Initialized
INFO - 2018-03-28 18:12:23 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 18:12:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-28 18:12:23 --> Final output sent to browser
DEBUG - 2018-03-28 18:12:23 --> Total execution time: 0.9330
INFO - 2018-03-28 12:42:25 --> Config Class Initialized
INFO - 2018-03-28 12:42:25 --> Hooks Class Initialized
DEBUG - 2018-03-28 12:42:25 --> UTF-8 Support Enabled
INFO - 2018-03-28 12:42:25 --> Utf8 Class Initialized
INFO - 2018-03-28 12:42:25 --> URI Class Initialized
INFO - 2018-03-28 12:42:25 --> Router Class Initialized
INFO - 2018-03-28 12:42:25 --> Output Class Initialized
INFO - 2018-03-28 12:42:25 --> Security Class Initialized
DEBUG - 2018-03-28 12:42:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 12:42:25 --> Input Class Initialized
INFO - 2018-03-28 12:42:25 --> Language Class Initialized
INFO - 2018-03-28 12:42:25 --> Language Class Initialized
INFO - 2018-03-28 12:42:25 --> Config Class Initialized
INFO - 2018-03-28 12:42:25 --> Loader Class Initialized
INFO - 2018-03-28 18:12:25 --> Helper loaded: url_helper
INFO - 2018-03-28 18:12:25 --> Helper loaded: notification_helper
INFO - 2018-03-28 18:12:25 --> Helper loaded: settings_helper
INFO - 2018-03-28 18:12:25 --> Helper loaded: permission_helper
INFO - 2018-03-28 18:12:25 --> Helper loaded: users_helper
INFO - 2018-03-28 12:42:25 --> Config Class Initialized
INFO - 2018-03-28 12:42:25 --> Hooks Class Initialized
DEBUG - 2018-03-28 12:42:25 --> UTF-8 Support Enabled
INFO - 2018-03-28 12:42:25 --> Utf8 Class Initialized
INFO - 2018-03-28 12:42:25 --> URI Class Initialized
INFO - 2018-03-28 12:42:25 --> Router Class Initialized
INFO - 2018-03-28 12:42:25 --> Output Class Initialized
INFO - 2018-03-28 18:12:25 --> Database Driver Class Initialized
INFO - 2018-03-28 12:42:25 --> Security Class Initialized
DEBUG - 2018-03-28 12:42:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 12:42:25 --> Input Class Initialized
DEBUG - 2018-03-28 18:12:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:12:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 12:42:25 --> Language Class Initialized
INFO - 2018-03-28 18:12:25 --> Helper loaded: form_helper
INFO - 2018-03-28 18:12:25 --> Form Validation Class Initialized
INFO - 2018-03-28 18:12:25 --> Controller Class Initialized
INFO - 2018-03-28 18:12:25 --> Model Class Initialized
INFO - 2018-03-28 18:12:25 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 18:12:25 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 18:12:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 18:12:25 --> Model Class Initialized
INFO - 2018-03-28 18:12:25 --> Model Class Initialized
INFO - 2018-03-28 18:12:25 --> Model Class Initialized
INFO - 2018-03-28 18:12:25 --> Model Class Initialized
INFO - 2018-03-28 18:12:25 --> Model Class Initialized
INFO - 2018-03-28 18:12:25 --> Model Class Initialized
INFO - 2018-03-28 18:12:25 --> Model Class Initialized
INFO - 2018-03-28 18:12:25 --> Model Class Initialized
INFO - 2018-03-28 18:12:25 --> Model Class Initialized
INFO - 2018-03-28 18:12:25 --> Model Class Initialized
INFO - 2018-03-28 18:12:25 --> Model Class Initialized
INFO - 2018-03-28 18:12:25 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 18:12:25 --> Model Class Initialized
INFO - 2018-03-28 18:12:25 --> Final output sent to browser
DEBUG - 2018-03-28 18:12:25 --> Total execution time: 0.4136
INFO - 2018-03-28 12:42:26 --> Language Class Initialized
INFO - 2018-03-28 12:42:26 --> Config Class Initialized
INFO - 2018-03-28 12:42:26 --> Loader Class Initialized
INFO - 2018-03-28 18:12:26 --> Helper loaded: url_helper
INFO - 2018-03-28 18:12:26 --> Helper loaded: notification_helper
INFO - 2018-03-28 18:12:26 --> Helper loaded: settings_helper
INFO - 2018-03-28 18:12:26 --> Helper loaded: permission_helper
INFO - 2018-03-28 18:12:26 --> Helper loaded: users_helper
INFO - 2018-03-28 18:12:27 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:12:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 12:42:27 --> Config Class Initialized
INFO - 2018-03-28 12:42:27 --> Hooks Class Initialized
DEBUG - 2018-03-28 12:42:27 --> UTF-8 Support Enabled
INFO - 2018-03-28 12:42:27 --> Utf8 Class Initialized
INFO - 2018-03-28 12:42:27 --> URI Class Initialized
INFO - 2018-03-28 12:42:27 --> Router Class Initialized
INFO - 2018-03-28 12:42:27 --> Output Class Initialized
INFO - 2018-03-28 12:42:27 --> Security Class Initialized
DEBUG - 2018-03-28 12:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 12:42:27 --> Input Class Initialized
INFO - 2018-03-28 12:42:27 --> Language Class Initialized
INFO - 2018-03-28 18:12:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 12:42:27 --> Language Class Initialized
INFO - 2018-03-28 12:42:27 --> Config Class Initialized
INFO - 2018-03-28 12:42:27 --> Loader Class Initialized
INFO - 2018-03-28 18:12:27 --> Helper loaded: url_helper
INFO - 2018-03-28 18:12:27 --> Helper loaded: notification_helper
INFO - 2018-03-28 18:12:27 --> Helper loaded: settings_helper
INFO - 2018-03-28 18:12:27 --> Helper loaded: permission_helper
INFO - 2018-03-28 18:12:27 --> Helper loaded: users_helper
INFO - 2018-03-28 18:12:27 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:12:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:12:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:12:27 --> Helper loaded: form_helper
INFO - 2018-03-28 18:12:27 --> Form Validation Class Initialized
INFO - 2018-03-28 18:12:27 --> Controller Class Initialized
INFO - 2018-03-28 18:12:27 --> Model Class Initialized
INFO - 2018-03-28 18:12:27 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 18:12:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 18:12:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 18:12:27 --> Model Class Initialized
INFO - 2018-03-28 18:12:27 --> Model Class Initialized
INFO - 2018-03-28 18:12:27 --> Model Class Initialized
INFO - 2018-03-28 18:12:27 --> Model Class Initialized
INFO - 2018-03-28 18:12:27 --> Model Class Initialized
INFO - 2018-03-28 18:12:27 --> Model Class Initialized
INFO - 2018-03-28 18:12:27 --> Model Class Initialized
INFO - 2018-03-28 18:12:27 --> Model Class Initialized
INFO - 2018-03-28 18:12:27 --> Model Class Initialized
INFO - 2018-03-28 18:12:27 --> Model Class Initialized
INFO - 2018-03-28 18:12:27 --> Model Class Initialized
INFO - 2018-03-28 18:12:27 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 18:12:27 --> Model Class Initialized
INFO - 2018-03-28 18:12:27 --> Final output sent to browser
DEBUG - 2018-03-28 18:12:27 --> Total execution time: 0.1669
INFO - 2018-03-28 18:12:27 --> Helper loaded: form_helper
INFO - 2018-03-28 18:12:27 --> Form Validation Class Initialized
INFO - 2018-03-28 18:12:27 --> Controller Class Initialized
INFO - 2018-03-28 18:12:28 --> Model Class Initialized
INFO - 2018-03-28 18:12:28 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 18:12:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 18:12:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 18:12:28 --> Model Class Initialized
INFO - 2018-03-28 18:12:28 --> Model Class Initialized
INFO - 2018-03-28 18:12:28 --> Model Class Initialized
INFO - 2018-03-28 18:12:28 --> Model Class Initialized
INFO - 2018-03-28 18:12:28 --> Model Class Initialized
INFO - 2018-03-28 18:12:28 --> Model Class Initialized
INFO - 2018-03-28 18:12:28 --> Model Class Initialized
INFO - 2018-03-28 18:12:28 --> Model Class Initialized
INFO - 2018-03-28 18:12:28 --> Model Class Initialized
INFO - 2018-03-28 18:12:28 --> Model Class Initialized
INFO - 2018-03-28 18:12:28 --> Model Class Initialized
INFO - 2018-03-28 18:12:28 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 18:12:28 --> Model Class Initialized
INFO - 2018-03-28 18:12:28 --> Final output sent to browser
DEBUG - 2018-03-28 18:12:28 --> Total execution time: 3.2360
INFO - 2018-03-28 12:42:29 --> Config Class Initialized
INFO - 2018-03-28 12:42:29 --> Hooks Class Initialized
DEBUG - 2018-03-28 12:42:29 --> UTF-8 Support Enabled
INFO - 2018-03-28 12:42:29 --> Utf8 Class Initialized
INFO - 2018-03-28 12:42:29 --> URI Class Initialized
INFO - 2018-03-28 12:42:29 --> Router Class Initialized
INFO - 2018-03-28 12:42:29 --> Output Class Initialized
INFO - 2018-03-28 12:42:29 --> Security Class Initialized
DEBUG - 2018-03-28 12:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 12:42:29 --> Input Class Initialized
INFO - 2018-03-28 12:42:29 --> Language Class Initialized
INFO - 2018-03-28 12:42:29 --> Language Class Initialized
INFO - 2018-03-28 12:42:29 --> Config Class Initialized
INFO - 2018-03-28 12:42:29 --> Loader Class Initialized
INFO - 2018-03-28 18:12:29 --> Helper loaded: url_helper
INFO - 2018-03-28 18:12:29 --> Helper loaded: notification_helper
INFO - 2018-03-28 18:12:29 --> Helper loaded: settings_helper
INFO - 2018-03-28 18:12:29 --> Helper loaded: permission_helper
INFO - 2018-03-28 18:12:29 --> Helper loaded: users_helper
INFO - 2018-03-28 18:12:29 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:12:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:12:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:12:29 --> Helper loaded: form_helper
INFO - 2018-03-28 18:12:29 --> Form Validation Class Initialized
INFO - 2018-03-28 18:12:29 --> Controller Class Initialized
INFO - 2018-03-28 18:12:29 --> Model Class Initialized
INFO - 2018-03-28 18:12:29 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 18:12:29 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 18:12:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 18:12:29 --> Model Class Initialized
INFO - 2018-03-28 18:12:29 --> Model Class Initialized
INFO - 2018-03-28 18:12:29 --> Model Class Initialized
INFO - 2018-03-28 18:12:29 --> Model Class Initialized
INFO - 2018-03-28 18:12:29 --> Model Class Initialized
INFO - 2018-03-28 18:12:29 --> Model Class Initialized
INFO - 2018-03-28 18:12:29 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-28 18:12:29 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-28 18:12:29 --> Final output sent to browser
DEBUG - 2018-03-28 18:12:29 --> Total execution time: 0.4278
INFO - 2018-03-28 12:42:35 --> Config Class Initialized
INFO - 2018-03-28 12:42:35 --> Hooks Class Initialized
DEBUG - 2018-03-28 12:42:35 --> UTF-8 Support Enabled
INFO - 2018-03-28 12:42:35 --> Utf8 Class Initialized
INFO - 2018-03-28 12:42:35 --> URI Class Initialized
INFO - 2018-03-28 12:42:35 --> Router Class Initialized
INFO - 2018-03-28 12:42:35 --> Output Class Initialized
INFO - 2018-03-28 12:42:35 --> Security Class Initialized
DEBUG - 2018-03-28 12:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 12:42:35 --> Input Class Initialized
INFO - 2018-03-28 12:42:35 --> Language Class Initialized
INFO - 2018-03-28 12:42:35 --> Language Class Initialized
INFO - 2018-03-28 12:42:35 --> Config Class Initialized
INFO - 2018-03-28 12:42:35 --> Loader Class Initialized
INFO - 2018-03-28 12:42:35 --> Config Class Initialized
INFO - 2018-03-28 12:42:35 --> Hooks Class Initialized
INFO - 2018-03-28 18:12:35 --> Helper loaded: url_helper
INFO - 2018-03-28 18:12:35 --> Helper loaded: notification_helper
INFO - 2018-03-28 18:12:35 --> Helper loaded: settings_helper
INFO - 2018-03-28 18:12:35 --> Helper loaded: permission_helper
INFO - 2018-03-28 18:12:35 --> Helper loaded: users_helper
DEBUG - 2018-03-28 12:42:35 --> UTF-8 Support Enabled
INFO - 2018-03-28 12:42:35 --> Utf8 Class Initialized
INFO - 2018-03-28 12:42:35 --> URI Class Initialized
INFO - 2018-03-28 12:42:35 --> Router Class Initialized
INFO - 2018-03-28 12:42:35 --> Output Class Initialized
INFO - 2018-03-28 12:42:35 --> Security Class Initialized
INFO - 2018-03-28 18:12:35 --> Database Driver Class Initialized
DEBUG - 2018-03-28 12:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 12:42:35 --> Input Class Initialized
INFO - 2018-03-28 12:42:35 --> Language Class Initialized
DEBUG - 2018-03-28 18:12:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:12:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 12:42:36 --> Language Class Initialized
INFO - 2018-03-28 12:42:36 --> Config Class Initialized
INFO - 2018-03-28 12:42:36 --> Loader Class Initialized
INFO - 2018-03-28 18:12:36 --> Helper loaded: url_helper
INFO - 2018-03-28 18:12:36 --> Helper loaded: notification_helper
INFO - 2018-03-28 18:12:36 --> Helper loaded: settings_helper
INFO - 2018-03-28 18:12:36 --> Helper loaded: permission_helper
INFO - 2018-03-28 18:12:36 --> Helper loaded: users_helper
INFO - 2018-03-28 18:12:36 --> Helper loaded: form_helper
INFO - 2018-03-28 18:12:36 --> Form Validation Class Initialized
INFO - 2018-03-28 18:12:36 --> Controller Class Initialized
INFO - 2018-03-28 18:12:36 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:12:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:12:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:12:36 --> Helper loaded: form_helper
INFO - 2018-03-28 18:12:36 --> Form Validation Class Initialized
INFO - 2018-03-28 18:12:36 --> Controller Class Initialized
INFO - 2018-03-28 18:12:36 --> Model Class Initialized
INFO - 2018-03-28 18:12:36 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 18:12:36 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 18:12:36 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 18:12:36 --> Model Class Initialized
INFO - 2018-03-28 18:12:36 --> Model Class Initialized
INFO - 2018-03-28 18:12:36 --> Model Class Initialized
INFO - 2018-03-28 18:12:36 --> Model Class Initialized
INFO - 2018-03-28 18:12:36 --> Model Class Initialized
INFO - 2018-03-28 18:12:36 --> Model Class Initialized
INFO - 2018-03-28 18:12:36 --> Model Class Initialized
INFO - 2018-03-28 18:12:36 --> Model Class Initialized
INFO - 2018-03-28 18:12:36 --> Model Class Initialized
INFO - 2018-03-28 18:12:36 --> Model Class Initialized
INFO - 2018-03-28 18:12:36 --> Model Class Initialized
INFO - 2018-03-28 18:12:36 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 18:12:37 --> Final output sent to browser
DEBUG - 2018-03-28 18:12:37 --> Total execution time: 2.0605
INFO - 2018-03-28 18:12:37 --> Model Class Initialized
INFO - 2018-03-28 18:12:37 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 18:12:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 18:12:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 18:12:37 --> Model Class Initialized
INFO - 2018-03-28 18:12:37 --> Model Class Initialized
INFO - 2018-03-28 18:12:37 --> Model Class Initialized
INFO - 2018-03-28 18:12:37 --> Model Class Initialized
INFO - 2018-03-28 18:12:37 --> Model Class Initialized
INFO - 2018-03-28 18:12:37 --> Model Class Initialized
INFO - 2018-03-28 18:12:37 --> Model Class Initialized
INFO - 2018-03-28 18:12:37 --> Model Class Initialized
INFO - 2018-03-28 18:12:37 --> Model Class Initialized
INFO - 2018-03-28 18:12:37 --> Model Class Initialized
INFO - 2018-03-28 18:12:37 --> Model Class Initialized
INFO - 2018-03-28 18:12:37 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 18:12:37 --> Model Class Initialized
INFO - 2018-03-28 18:12:37 --> Final output sent to browser
DEBUG - 2018-03-28 18:12:37 --> Total execution time: 2.2009
INFO - 2018-03-28 12:42:37 --> Config Class Initialized
INFO - 2018-03-28 12:42:37 --> Hooks Class Initialized
DEBUG - 2018-03-28 12:42:37 --> UTF-8 Support Enabled
INFO - 2018-03-28 12:42:37 --> Utf8 Class Initialized
INFO - 2018-03-28 12:42:37 --> URI Class Initialized
INFO - 2018-03-28 12:42:37 --> Router Class Initialized
INFO - 2018-03-28 12:42:37 --> Output Class Initialized
INFO - 2018-03-28 12:42:37 --> Security Class Initialized
DEBUG - 2018-03-28 12:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 12:42:37 --> Input Class Initialized
INFO - 2018-03-28 12:42:37 --> Language Class Initialized
INFO - 2018-03-28 12:42:37 --> Config Class Initialized
INFO - 2018-03-28 12:42:37 --> Hooks Class Initialized
DEBUG - 2018-03-28 12:42:37 --> UTF-8 Support Enabled
INFO - 2018-03-28 12:42:37 --> Utf8 Class Initialized
INFO - 2018-03-28 12:42:37 --> URI Class Initialized
INFO - 2018-03-28 12:42:37 --> Router Class Initialized
INFO - 2018-03-28 12:42:37 --> Output Class Initialized
INFO - 2018-03-28 12:42:37 --> Security Class Initialized
DEBUG - 2018-03-28 12:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 12:42:37 --> Input Class Initialized
INFO - 2018-03-28 12:42:37 --> Language Class Initialized
INFO - 2018-03-28 12:42:37 --> Language Class Initialized
INFO - 2018-03-28 12:42:37 --> Config Class Initialized
INFO - 2018-03-28 12:42:37 --> Loader Class Initialized
INFO - 2018-03-28 18:12:37 --> Helper loaded: url_helper
INFO - 2018-03-28 18:12:37 --> Helper loaded: notification_helper
INFO - 2018-03-28 18:12:37 --> Helper loaded: settings_helper
INFO - 2018-03-28 18:12:37 --> Helper loaded: permission_helper
INFO - 2018-03-28 18:12:37 --> Helper loaded: users_helper
INFO - 2018-03-28 12:42:37 --> Language Class Initialized
INFO - 2018-03-28 12:42:37 --> Config Class Initialized
INFO - 2018-03-28 12:42:37 --> Loader Class Initialized
INFO - 2018-03-28 18:12:37 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:12:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:12:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:12:37 --> Helper loaded: url_helper
INFO - 2018-03-28 18:12:37 --> Helper loaded: notification_helper
INFO - 2018-03-28 18:12:37 --> Helper loaded: settings_helper
INFO - 2018-03-28 18:12:37 --> Helper loaded: form_helper
INFO - 2018-03-28 18:12:37 --> Form Validation Class Initialized
INFO - 2018-03-28 18:12:37 --> Controller Class Initialized
INFO - 2018-03-28 18:12:37 --> Helper loaded: permission_helper
INFO - 2018-03-28 18:12:37 --> Helper loaded: users_helper
INFO - 2018-03-28 18:12:37 --> Model Class Initialized
INFO - 2018-03-28 18:12:37 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 18:12:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 18:12:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 18:12:37 --> Model Class Initialized
INFO - 2018-03-28 18:12:37 --> Model Class Initialized
INFO - 2018-03-28 18:12:37 --> Model Class Initialized
INFO - 2018-03-28 18:12:37 --> Model Class Initialized
INFO - 2018-03-28 18:12:37 --> Model Class Initialized
INFO - 2018-03-28 18:12:37 --> Model Class Initialized
INFO - 2018-03-28 18:12:37 --> Model Class Initialized
INFO - 2018-03-28 18:12:37 --> Model Class Initialized
INFO - 2018-03-28 18:12:37 --> Model Class Initialized
INFO - 2018-03-28 18:12:37 --> Model Class Initialized
INFO - 2018-03-28 18:12:37 --> Model Class Initialized
INFO - 2018-03-28 18:12:37 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 18:12:37 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:12:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:12:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:12:37 --> Final output sent to browser
DEBUG - 2018-03-28 18:12:37 --> Total execution time: 0.1565
INFO - 2018-03-28 18:12:37 --> Helper loaded: form_helper
INFO - 2018-03-28 18:12:37 --> Form Validation Class Initialized
INFO - 2018-03-28 18:12:37 --> Controller Class Initialized
INFO - 2018-03-28 18:12:37 --> Model Class Initialized
INFO - 2018-03-28 18:12:37 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 18:12:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 18:12:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 18:12:37 --> Model Class Initialized
INFO - 2018-03-28 18:12:37 --> Model Class Initialized
INFO - 2018-03-28 18:12:37 --> Model Class Initialized
INFO - 2018-03-28 18:12:37 --> Model Class Initialized
INFO - 2018-03-28 18:12:37 --> Model Class Initialized
INFO - 2018-03-28 18:12:37 --> Model Class Initialized
INFO - 2018-03-28 18:12:37 --> Model Class Initialized
INFO - 2018-03-28 18:12:37 --> Model Class Initialized
INFO - 2018-03-28 18:12:37 --> Model Class Initialized
INFO - 2018-03-28 18:12:37 --> Model Class Initialized
INFO - 2018-03-28 18:12:37 --> Model Class Initialized
INFO - 2018-03-28 18:12:37 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 18:12:37 --> Model Class Initialized
INFO - 2018-03-28 18:12:37 --> Final output sent to browser
DEBUG - 2018-03-28 18:12:37 --> Total execution time: 0.3580
INFO - 2018-03-28 12:42:41 --> Config Class Initialized
INFO - 2018-03-28 12:42:41 --> Hooks Class Initialized
DEBUG - 2018-03-28 12:42:41 --> UTF-8 Support Enabled
INFO - 2018-03-28 12:42:41 --> Utf8 Class Initialized
INFO - 2018-03-28 12:42:41 --> URI Class Initialized
INFO - 2018-03-28 12:42:41 --> Router Class Initialized
INFO - 2018-03-28 12:42:41 --> Output Class Initialized
INFO - 2018-03-28 12:42:41 --> Security Class Initialized
DEBUG - 2018-03-28 12:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 12:42:41 --> Input Class Initialized
INFO - 2018-03-28 12:42:41 --> Language Class Initialized
INFO - 2018-03-28 12:42:42 --> Config Class Initialized
INFO - 2018-03-28 12:42:42 --> Hooks Class Initialized
DEBUG - 2018-03-28 12:42:42 --> UTF-8 Support Enabled
INFO - 2018-03-28 12:42:42 --> Utf8 Class Initialized
INFO - 2018-03-28 12:42:42 --> URI Class Initialized
INFO - 2018-03-28 12:42:42 --> Router Class Initialized
INFO - 2018-03-28 12:42:42 --> Output Class Initialized
INFO - 2018-03-28 12:42:42 --> Security Class Initialized
DEBUG - 2018-03-28 12:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 12:42:42 --> Input Class Initialized
INFO - 2018-03-28 12:42:42 --> Language Class Initialized
INFO - 2018-03-28 12:42:42 --> Language Class Initialized
INFO - 2018-03-28 12:42:42 --> Config Class Initialized
INFO - 2018-03-28 12:42:42 --> Loader Class Initialized
INFO - 2018-03-28 18:12:42 --> Helper loaded: url_helper
INFO - 2018-03-28 18:12:42 --> Helper loaded: notification_helper
INFO - 2018-03-28 18:12:42 --> Helper loaded: settings_helper
INFO - 2018-03-28 18:12:42 --> Helper loaded: permission_helper
INFO - 2018-03-28 18:12:42 --> Helper loaded: users_helper
INFO - 2018-03-28 12:42:42 --> Language Class Initialized
INFO - 2018-03-28 12:42:42 --> Config Class Initialized
INFO - 2018-03-28 12:42:42 --> Loader Class Initialized
INFO - 2018-03-28 18:12:42 --> Helper loaded: url_helper
INFO - 2018-03-28 18:12:42 --> Helper loaded: notification_helper
INFO - 2018-03-28 18:12:42 --> Helper loaded: settings_helper
INFO - 2018-03-28 18:12:42 --> Helper loaded: permission_helper
INFO - 2018-03-28 18:12:42 --> Helper loaded: users_helper
INFO - 2018-03-28 18:12:42 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:12:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:12:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:12:42 --> Helper loaded: form_helper
INFO - 2018-03-28 18:12:42 --> Form Validation Class Initialized
INFO - 2018-03-28 18:12:42 --> Controller Class Initialized
INFO - 2018-03-28 18:12:42 --> Model Class Initialized
INFO - 2018-03-28 18:12:42 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 18:12:42 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 18:12:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 18:12:42 --> Model Class Initialized
INFO - 2018-03-28 18:12:42 --> Model Class Initialized
INFO - 2018-03-28 18:12:42 --> Model Class Initialized
INFO - 2018-03-28 18:12:42 --> Model Class Initialized
INFO - 2018-03-28 18:12:42 --> Model Class Initialized
INFO - 2018-03-28 18:12:42 --> Model Class Initialized
INFO - 2018-03-28 18:12:42 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-28 18:12:42 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-28 18:12:42 --> Final output sent to browser
DEBUG - 2018-03-28 18:12:42 --> Total execution time: 0.6907
INFO - 2018-03-28 18:12:42 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:12:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:12:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:12:42 --> Helper loaded: form_helper
INFO - 2018-03-28 18:12:42 --> Form Validation Class Initialized
INFO - 2018-03-28 18:12:42 --> Controller Class Initialized
INFO - 2018-03-28 18:12:42 --> Model Class Initialized
INFO - 2018-03-28 18:12:42 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 18:12:42 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 18:12:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 18:12:42 --> Model Class Initialized
INFO - 2018-03-28 18:12:42 --> Model Class Initialized
INFO - 2018-03-28 18:12:42 --> Model Class Initialized
INFO - 2018-03-28 18:12:42 --> Model Class Initialized
INFO - 2018-03-28 18:12:42 --> Model Class Initialized
INFO - 2018-03-28 18:12:42 --> Model Class Initialized
INFO - 2018-03-28 18:12:42 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-28 18:12:42 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-28 18:12:42 --> Final output sent to browser
DEBUG - 2018-03-28 18:12:42 --> Total execution time: 2.0800
INFO - 2018-03-28 12:42:49 --> Config Class Initialized
INFO - 2018-03-28 12:42:49 --> Hooks Class Initialized
DEBUG - 2018-03-28 12:42:49 --> UTF-8 Support Enabled
INFO - 2018-03-28 12:42:49 --> Utf8 Class Initialized
INFO - 2018-03-28 12:42:49 --> URI Class Initialized
INFO - 2018-03-28 12:42:49 --> Router Class Initialized
INFO - 2018-03-28 12:42:49 --> Output Class Initialized
INFO - 2018-03-28 12:42:49 --> Security Class Initialized
DEBUG - 2018-03-28 12:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 12:42:49 --> Input Class Initialized
INFO - 2018-03-28 12:42:49 --> Language Class Initialized
INFO - 2018-03-28 12:42:49 --> Language Class Initialized
INFO - 2018-03-28 12:42:49 --> Config Class Initialized
INFO - 2018-03-28 12:42:49 --> Loader Class Initialized
INFO - 2018-03-28 18:12:49 --> Helper loaded: url_helper
INFO - 2018-03-28 18:12:49 --> Helper loaded: notification_helper
INFO - 2018-03-28 18:12:49 --> Helper loaded: settings_helper
INFO - 2018-03-28 18:12:49 --> Helper loaded: permission_helper
INFO - 2018-03-28 12:42:49 --> Config Class Initialized
INFO - 2018-03-28 18:12:49 --> Helper loaded: users_helper
INFO - 2018-03-28 12:42:49 --> Hooks Class Initialized
DEBUG - 2018-03-28 12:42:49 --> UTF-8 Support Enabled
INFO - 2018-03-28 12:42:49 --> Utf8 Class Initialized
INFO - 2018-03-28 12:42:49 --> URI Class Initialized
INFO - 2018-03-28 12:42:49 --> Router Class Initialized
INFO - 2018-03-28 12:42:49 --> Output Class Initialized
INFO - 2018-03-28 18:12:49 --> Database Driver Class Initialized
INFO - 2018-03-28 12:42:49 --> Security Class Initialized
DEBUG - 2018-03-28 18:12:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:12:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-03-28 12:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 12:42:49 --> Input Class Initialized
INFO - 2018-03-28 12:42:49 --> Language Class Initialized
INFO - 2018-03-28 18:12:49 --> Helper loaded: form_helper
INFO - 2018-03-28 18:12:49 --> Form Validation Class Initialized
INFO - 2018-03-28 18:12:49 --> Controller Class Initialized
INFO - 2018-03-28 18:12:49 --> Model Class Initialized
INFO - 2018-03-28 18:12:49 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 18:12:49 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 18:12:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 18:12:49 --> Model Class Initialized
INFO - 2018-03-28 18:12:49 --> Model Class Initialized
INFO - 2018-03-28 18:12:49 --> Model Class Initialized
INFO - 2018-03-28 18:12:49 --> Model Class Initialized
INFO - 2018-03-28 12:42:49 --> Language Class Initialized
INFO - 2018-03-28 12:42:49 --> Config Class Initialized
INFO - 2018-03-28 12:42:49 --> Loader Class Initialized
INFO - 2018-03-28 18:12:49 --> Final output sent to browser
DEBUG - 2018-03-28 18:12:49 --> Total execution time: 0.2026
INFO - 2018-03-28 18:12:49 --> Helper loaded: url_helper
INFO - 2018-03-28 18:12:49 --> Helper loaded: notification_helper
INFO - 2018-03-28 18:12:49 --> Helper loaded: settings_helper
INFO - 2018-03-28 18:12:49 --> Helper loaded: permission_helper
INFO - 2018-03-28 18:12:49 --> Helper loaded: users_helper
INFO - 2018-03-28 18:12:49 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:12:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:12:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:12:49 --> Helper loaded: form_helper
INFO - 2018-03-28 18:12:49 --> Form Validation Class Initialized
INFO - 2018-03-28 18:12:49 --> Controller Class Initialized
INFO - 2018-03-28 18:12:49 --> Model Class Initialized
INFO - 2018-03-28 18:12:49 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 18:12:49 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 18:12:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 18:12:49 --> Model Class Initialized
INFO - 2018-03-28 18:12:49 --> Model Class Initialized
INFO - 2018-03-28 18:12:49 --> Model Class Initialized
INFO - 2018-03-28 18:12:49 --> Model Class Initialized
INFO - 2018-03-28 18:12:49 --> Final output sent to browser
DEBUG - 2018-03-28 18:12:49 --> Total execution time: 0.2477
INFO - 2018-03-28 12:42:53 --> Config Class Initialized
INFO - 2018-03-28 12:42:53 --> Hooks Class Initialized
DEBUG - 2018-03-28 12:42:53 --> UTF-8 Support Enabled
INFO - 2018-03-28 12:42:53 --> Utf8 Class Initialized
INFO - 2018-03-28 12:42:53 --> URI Class Initialized
INFO - 2018-03-28 12:42:53 --> Router Class Initialized
INFO - 2018-03-28 12:42:53 --> Output Class Initialized
INFO - 2018-03-28 12:42:53 --> Security Class Initialized
DEBUG - 2018-03-28 12:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 12:42:53 --> Input Class Initialized
INFO - 2018-03-28 12:42:53 --> Language Class Initialized
INFO - 2018-03-28 12:42:53 --> Language Class Initialized
INFO - 2018-03-28 12:42:53 --> Config Class Initialized
INFO - 2018-03-28 12:42:53 --> Loader Class Initialized
INFO - 2018-03-28 18:12:53 --> Helper loaded: url_helper
INFO - 2018-03-28 18:12:53 --> Helper loaded: notification_helper
INFO - 2018-03-28 18:12:53 --> Helper loaded: settings_helper
INFO - 2018-03-28 18:12:53 --> Helper loaded: permission_helper
INFO - 2018-03-28 18:12:53 --> Helper loaded: users_helper
INFO - 2018-03-28 18:12:53 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:12:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:12:53 --> Helper loaded: form_helper
INFO - 2018-03-28 18:12:53 --> Form Validation Class Initialized
INFO - 2018-03-28 18:12:53 --> Controller Class Initialized
INFO - 2018-03-28 18:12:53 --> Model Class Initialized
INFO - 2018-03-28 18:12:53 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 18:12:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 18:12:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 18:12:53 --> Model Class Initialized
INFO - 2018-03-28 18:12:53 --> Model Class Initialized
INFO - 2018-03-28 18:12:53 --> Model Class Initialized
INFO - 2018-03-28 18:12:53 --> Model Class Initialized
INFO - 2018-03-28 18:12:53 --> Model Class Initialized
INFO - 2018-03-28 18:12:53 --> Model Class Initialized
INFO - 2018-03-28 18:12:53 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-28 18:12:53 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-28 18:12:53 --> Final output sent to browser
DEBUG - 2018-03-28 18:12:53 --> Total execution time: 0.2804
INFO - 2018-03-28 12:43:00 --> Config Class Initialized
INFO - 2018-03-28 12:43:00 --> Hooks Class Initialized
DEBUG - 2018-03-28 12:43:00 --> UTF-8 Support Enabled
INFO - 2018-03-28 12:43:00 --> Utf8 Class Initialized
INFO - 2018-03-28 12:43:00 --> URI Class Initialized
INFO - 2018-03-28 12:43:00 --> Router Class Initialized
INFO - 2018-03-28 12:43:00 --> Output Class Initialized
INFO - 2018-03-28 12:43:00 --> Security Class Initialized
DEBUG - 2018-03-28 12:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 12:43:00 --> Input Class Initialized
INFO - 2018-03-28 12:43:00 --> Language Class Initialized
INFO - 2018-03-28 12:43:00 --> Language Class Initialized
INFO - 2018-03-28 12:43:00 --> Config Class Initialized
INFO - 2018-03-28 12:43:00 --> Loader Class Initialized
INFO - 2018-03-28 18:13:00 --> Helper loaded: url_helper
INFO - 2018-03-28 18:13:00 --> Helper loaded: notification_helper
INFO - 2018-03-28 18:13:00 --> Helper loaded: settings_helper
INFO - 2018-03-28 18:13:00 --> Helper loaded: permission_helper
INFO - 2018-03-28 18:13:00 --> Helper loaded: users_helper
INFO - 2018-03-28 18:13:00 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:13:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:13:00 --> Helper loaded: form_helper
INFO - 2018-03-28 18:13:00 --> Form Validation Class Initialized
INFO - 2018-03-28 18:13:00 --> Controller Class Initialized
INFO - 2018-03-28 18:13:00 --> Model Class Initialized
INFO - 2018-03-28 18:13:00 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 18:13:00 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 18:13:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 18:13:00 --> Model Class Initialized
INFO - 2018-03-28 18:13:00 --> Model Class Initialized
INFO - 2018-03-28 18:13:00 --> Model Class Initialized
INFO - 2018-03-28 18:13:00 --> Model Class Initialized
INFO - 2018-03-28 18:13:00 --> Model Class Initialized
INFO - 2018-03-28 18:13:00 --> Model Class Initialized
INFO - 2018-03-28 18:13:00 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-28 18:13:01 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-28 18:13:01 --> Final output sent to browser
DEBUG - 2018-03-28 18:13:01 --> Total execution time: 0.4034
INFO - 2018-03-28 12:43:03 --> Config Class Initialized
INFO - 2018-03-28 12:43:03 --> Hooks Class Initialized
DEBUG - 2018-03-28 12:43:03 --> UTF-8 Support Enabled
INFO - 2018-03-28 12:43:03 --> Utf8 Class Initialized
INFO - 2018-03-28 12:43:03 --> URI Class Initialized
INFO - 2018-03-28 12:43:03 --> Router Class Initialized
INFO - 2018-03-28 12:43:03 --> Output Class Initialized
INFO - 2018-03-28 12:43:03 --> Security Class Initialized
DEBUG - 2018-03-28 12:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 12:43:03 --> Input Class Initialized
INFO - 2018-03-28 12:43:03 --> Language Class Initialized
INFO - 2018-03-28 12:43:03 --> Language Class Initialized
INFO - 2018-03-28 12:43:03 --> Config Class Initialized
INFO - 2018-03-28 12:43:03 --> Loader Class Initialized
INFO - 2018-03-28 18:13:03 --> Helper loaded: url_helper
INFO - 2018-03-28 18:13:03 --> Helper loaded: notification_helper
INFO - 2018-03-28 18:13:03 --> Helper loaded: settings_helper
INFO - 2018-03-28 18:13:03 --> Helper loaded: permission_helper
INFO - 2018-03-28 18:13:03 --> Helper loaded: users_helper
INFO - 2018-03-28 18:13:03 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:13:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:13:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:13:03 --> Helper loaded: form_helper
INFO - 2018-03-28 18:13:03 --> Form Validation Class Initialized
INFO - 2018-03-28 18:13:03 --> Controller Class Initialized
INFO - 2018-03-28 18:13:03 --> Model Class Initialized
INFO - 2018-03-28 18:13:03 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 18:13:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 18:13:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 18:13:03 --> Model Class Initialized
INFO - 2018-03-28 18:13:03 --> Model Class Initialized
INFO - 2018-03-28 18:13:03 --> Model Class Initialized
INFO - 2018-03-28 18:13:03 --> Model Class Initialized
INFO - 2018-03-28 18:13:03 --> Model Class Initialized
INFO - 2018-03-28 18:13:03 --> Model Class Initialized
INFO - 2018-03-28 18:13:03 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-28 18:13:03 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
ERROR - 2018-03-28 18:13:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 784
INFO - 2018-03-28 18:13:03 --> Final output sent to browser
DEBUG - 2018-03-28 18:13:03 --> Total execution time: 0.2610
INFO - 2018-03-28 12:43:06 --> Config Class Initialized
INFO - 2018-03-28 12:43:06 --> Hooks Class Initialized
DEBUG - 2018-03-28 12:43:06 --> UTF-8 Support Enabled
INFO - 2018-03-28 12:43:06 --> Utf8 Class Initialized
INFO - 2018-03-28 12:43:06 --> URI Class Initialized
INFO - 2018-03-28 12:43:06 --> Router Class Initialized
INFO - 2018-03-28 12:43:06 --> Output Class Initialized
INFO - 2018-03-28 12:43:06 --> Security Class Initialized
DEBUG - 2018-03-28 12:43:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 12:43:06 --> Input Class Initialized
INFO - 2018-03-28 12:43:06 --> Language Class Initialized
INFO - 2018-03-28 12:43:06 --> Language Class Initialized
INFO - 2018-03-28 12:43:06 --> Config Class Initialized
INFO - 2018-03-28 12:43:06 --> Loader Class Initialized
INFO - 2018-03-28 18:13:06 --> Helper loaded: url_helper
INFO - 2018-03-28 18:13:06 --> Helper loaded: notification_helper
INFO - 2018-03-28 18:13:06 --> Helper loaded: settings_helper
INFO - 2018-03-28 18:13:06 --> Helper loaded: permission_helper
INFO - 2018-03-28 18:13:06 --> Helper loaded: users_helper
INFO - 2018-03-28 18:13:06 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:13:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:13:06 --> Helper loaded: form_helper
INFO - 2018-03-28 18:13:06 --> Form Validation Class Initialized
INFO - 2018-03-28 18:13:06 --> Controller Class Initialized
INFO - 2018-03-28 18:13:06 --> Model Class Initialized
INFO - 2018-03-28 18:13:06 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 18:13:06 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 18:13:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 18:13:06 --> Model Class Initialized
INFO - 2018-03-28 18:13:06 --> Model Class Initialized
INFO - 2018-03-28 18:13:06 --> Model Class Initialized
INFO - 2018-03-28 18:13:06 --> Model Class Initialized
INFO - 2018-03-28 18:13:06 --> Model Class Initialized
INFO - 2018-03-28 18:13:06 --> Model Class Initialized
INFO - 2018-03-28 18:13:06 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-28 18:13:06 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
ERROR - 2018-03-28 18:13:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 784
INFO - 2018-03-28 18:13:06 --> Final output sent to browser
DEBUG - 2018-03-28 18:13:06 --> Total execution time: 0.1141
INFO - 2018-03-28 12:43:10 --> Config Class Initialized
INFO - 2018-03-28 12:43:10 --> Hooks Class Initialized
DEBUG - 2018-03-28 12:43:10 --> UTF-8 Support Enabled
INFO - 2018-03-28 12:43:10 --> Utf8 Class Initialized
INFO - 2018-03-28 12:43:10 --> URI Class Initialized
INFO - 2018-03-28 12:43:10 --> Router Class Initialized
INFO - 2018-03-28 12:43:10 --> Output Class Initialized
INFO - 2018-03-28 12:43:10 --> Security Class Initialized
DEBUG - 2018-03-28 12:43:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 12:43:11 --> Input Class Initialized
INFO - 2018-03-28 12:43:11 --> Language Class Initialized
INFO - 2018-03-28 12:43:11 --> Config Class Initialized
INFO - 2018-03-28 12:43:11 --> Hooks Class Initialized
DEBUG - 2018-03-28 12:43:11 --> UTF-8 Support Enabled
INFO - 2018-03-28 12:43:11 --> Utf8 Class Initialized
INFO - 2018-03-28 12:43:11 --> URI Class Initialized
INFO - 2018-03-28 12:43:11 --> Router Class Initialized
INFO - 2018-03-28 12:43:11 --> Output Class Initialized
INFO - 2018-03-28 12:43:11 --> Language Class Initialized
INFO - 2018-03-28 12:43:11 --> Config Class Initialized
INFO - 2018-03-28 12:43:11 --> Loader Class Initialized
INFO - 2018-03-28 12:43:11 --> Security Class Initialized
DEBUG - 2018-03-28 12:43:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 12:43:11 --> Input Class Initialized
INFO - 2018-03-28 12:43:11 --> Language Class Initialized
INFO - 2018-03-28 12:43:11 --> Language Class Initialized
INFO - 2018-03-28 12:43:11 --> Config Class Initialized
INFO - 2018-03-28 12:43:11 --> Loader Class Initialized
INFO - 2018-03-28 18:13:11 --> Helper loaded: url_helper
INFO - 2018-03-28 18:13:11 --> Helper loaded: notification_helper
INFO - 2018-03-28 18:13:11 --> Helper loaded: settings_helper
INFO - 2018-03-28 18:13:11 --> Helper loaded: permission_helper
INFO - 2018-03-28 18:13:11 --> Helper loaded: users_helper
INFO - 2018-03-28 18:13:11 --> Database Driver Class Initialized
INFO - 2018-03-28 18:13:11 --> Helper loaded: url_helper
DEBUG - 2018-03-28 18:13:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:13:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:13:11 --> Helper loaded: notification_helper
INFO - 2018-03-28 18:13:11 --> Helper loaded: settings_helper
INFO - 2018-03-28 18:13:11 --> Helper loaded: form_helper
INFO - 2018-03-28 18:13:11 --> Form Validation Class Initialized
INFO - 2018-03-28 18:13:11 --> Controller Class Initialized
INFO - 2018-03-28 18:13:11 --> Model Class Initialized
INFO - 2018-03-28 18:13:11 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 18:13:11 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 18:13:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 18:13:11 --> Model Class Initialized
INFO - 2018-03-28 18:13:11 --> Model Class Initialized
INFO - 2018-03-28 18:13:11 --> Model Class Initialized
INFO - 2018-03-28 18:13:11 --> Model Class Initialized
INFO - 2018-03-28 18:13:11 --> Model Class Initialized
INFO - 2018-03-28 18:13:11 --> Model Class Initialized
INFO - 2018-03-28 18:13:11 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-28 18:13:11 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
ERROR - 2018-03-28 18:13:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 784
INFO - 2018-03-28 18:13:11 --> Final output sent to browser
DEBUG - 2018-03-28 18:13:11 --> Total execution time: 0.1183
INFO - 2018-03-28 18:13:11 --> Helper loaded: permission_helper
INFO - 2018-03-28 18:13:11 --> Helper loaded: users_helper
INFO - 2018-03-28 18:13:12 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:13:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:13:12 --> Helper loaded: form_helper
INFO - 2018-03-28 18:13:12 --> Form Validation Class Initialized
INFO - 2018-03-28 18:13:12 --> Controller Class Initialized
INFO - 2018-03-28 18:13:12 --> Model Class Initialized
INFO - 2018-03-28 18:13:12 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 18:13:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 18:13:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 18:13:12 --> Model Class Initialized
INFO - 2018-03-28 18:13:12 --> Model Class Initialized
INFO - 2018-03-28 18:13:12 --> Model Class Initialized
INFO - 2018-03-28 18:13:12 --> Model Class Initialized
INFO - 2018-03-28 18:13:12 --> Model Class Initialized
INFO - 2018-03-28 18:13:12 --> Model Class Initialized
INFO - 2018-03-28 18:13:12 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-28 18:13:12 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
ERROR - 2018-03-28 18:13:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 784
INFO - 2018-03-28 18:13:12 --> Final output sent to browser
DEBUG - 2018-03-28 18:13:12 --> Total execution time: 2.1659
INFO - 2018-03-28 12:43:17 --> Config Class Initialized
INFO - 2018-03-28 12:43:17 --> Hooks Class Initialized
DEBUG - 2018-03-28 12:43:17 --> UTF-8 Support Enabled
INFO - 2018-03-28 12:43:17 --> Utf8 Class Initialized
INFO - 2018-03-28 12:43:17 --> URI Class Initialized
INFO - 2018-03-28 12:43:17 --> Router Class Initialized
INFO - 2018-03-28 12:43:17 --> Output Class Initialized
INFO - 2018-03-28 12:43:17 --> Security Class Initialized
DEBUG - 2018-03-28 12:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 12:43:17 --> Input Class Initialized
INFO - 2018-03-28 12:43:17 --> Language Class Initialized
INFO - 2018-03-28 12:43:17 --> Language Class Initialized
INFO - 2018-03-28 12:43:17 --> Config Class Initialized
INFO - 2018-03-28 12:43:17 --> Loader Class Initialized
INFO - 2018-03-28 18:13:17 --> Helper loaded: url_helper
INFO - 2018-03-28 18:13:17 --> Helper loaded: notification_helper
INFO - 2018-03-28 18:13:17 --> Helper loaded: settings_helper
INFO - 2018-03-28 18:13:17 --> Helper loaded: permission_helper
INFO - 2018-03-28 18:13:17 --> Helper loaded: users_helper
INFO - 2018-03-28 18:13:17 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:13:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:13:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:13:17 --> Helper loaded: form_helper
INFO - 2018-03-28 18:13:17 --> Form Validation Class Initialized
INFO - 2018-03-28 18:13:17 --> Controller Class Initialized
INFO - 2018-03-28 18:13:17 --> Model Class Initialized
INFO - 2018-03-28 18:13:17 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 18:13:17 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 18:13:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 18:13:17 --> Model Class Initialized
INFO - 2018-03-28 18:13:17 --> Model Class Initialized
INFO - 2018-03-28 18:13:17 --> Model Class Initialized
INFO - 2018-03-28 18:13:17 --> Model Class Initialized
INFO - 2018-03-28 18:13:17 --> Model Class Initialized
INFO - 2018-03-28 18:13:17 --> Model Class Initialized
INFO - 2018-03-28 18:13:17 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-28 18:13:18 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-28 18:13:18 --> Final output sent to browser
DEBUG - 2018-03-28 18:13:18 --> Total execution time: 0.9494
INFO - 2018-03-28 12:43:22 --> Config Class Initialized
INFO - 2018-03-28 12:43:22 --> Hooks Class Initialized
DEBUG - 2018-03-28 12:43:22 --> UTF-8 Support Enabled
INFO - 2018-03-28 12:43:22 --> Utf8 Class Initialized
INFO - 2018-03-28 12:43:22 --> URI Class Initialized
INFO - 2018-03-28 12:43:22 --> Router Class Initialized
INFO - 2018-03-28 12:43:22 --> Output Class Initialized
INFO - 2018-03-28 12:43:22 --> Security Class Initialized
DEBUG - 2018-03-28 12:43:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 12:43:22 --> Input Class Initialized
INFO - 2018-03-28 12:43:22 --> Language Class Initialized
INFO - 2018-03-28 12:43:22 --> Language Class Initialized
INFO - 2018-03-28 12:43:22 --> Config Class Initialized
INFO - 2018-03-28 12:43:22 --> Loader Class Initialized
INFO - 2018-03-28 18:13:22 --> Helper loaded: url_helper
INFO - 2018-03-28 18:13:22 --> Helper loaded: notification_helper
INFO - 2018-03-28 18:13:22 --> Helper loaded: settings_helper
INFO - 2018-03-28 18:13:22 --> Helper loaded: permission_helper
INFO - 2018-03-28 18:13:22 --> Helper loaded: users_helper
INFO - 2018-03-28 18:13:23 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:13:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:13:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:13:23 --> Helper loaded: form_helper
INFO - 2018-03-28 18:13:23 --> Form Validation Class Initialized
INFO - 2018-03-28 18:13:23 --> Controller Class Initialized
INFO - 2018-03-28 18:13:23 --> Model Class Initialized
INFO - 2018-03-28 18:13:23 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 18:13:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 18:13:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 18:13:23 --> Model Class Initialized
INFO - 2018-03-28 18:13:23 --> Model Class Initialized
INFO - 2018-03-28 18:13:23 --> Model Class Initialized
INFO - 2018-03-28 18:13:23 --> Model Class Initialized
INFO - 2018-03-28 18:13:23 --> Model Class Initialized
INFO - 2018-03-28 18:13:23 --> Model Class Initialized
INFO - 2018-03-28 18:13:23 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-28 18:13:23 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-28 18:13:23 --> Final output sent to browser
DEBUG - 2018-03-28 18:13:23 --> Total execution time: 0.6498
INFO - 2018-03-28 12:43:25 --> Config Class Initialized
INFO - 2018-03-28 12:43:25 --> Hooks Class Initialized
DEBUG - 2018-03-28 12:43:25 --> UTF-8 Support Enabled
INFO - 2018-03-28 12:43:25 --> Utf8 Class Initialized
INFO - 2018-03-28 12:43:25 --> URI Class Initialized
INFO - 2018-03-28 12:43:25 --> Router Class Initialized
INFO - 2018-03-28 12:43:25 --> Output Class Initialized
INFO - 2018-03-28 12:43:25 --> Security Class Initialized
DEBUG - 2018-03-28 12:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 12:43:25 --> Input Class Initialized
INFO - 2018-03-28 12:43:25 --> Language Class Initialized
INFO - 2018-03-28 12:43:25 --> Language Class Initialized
INFO - 2018-03-28 12:43:25 --> Config Class Initialized
INFO - 2018-03-28 12:43:25 --> Loader Class Initialized
INFO - 2018-03-28 18:13:25 --> Helper loaded: url_helper
INFO - 2018-03-28 18:13:25 --> Helper loaded: notification_helper
INFO - 2018-03-28 18:13:25 --> Helper loaded: settings_helper
INFO - 2018-03-28 18:13:25 --> Helper loaded: permission_helper
INFO - 2018-03-28 18:13:25 --> Helper loaded: users_helper
INFO - 2018-03-28 18:13:25 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:13:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:13:25 --> Helper loaded: form_helper
INFO - 2018-03-28 18:13:25 --> Form Validation Class Initialized
INFO - 2018-03-28 18:13:25 --> Controller Class Initialized
INFO - 2018-03-28 18:13:25 --> Model Class Initialized
INFO - 2018-03-28 18:13:25 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 18:13:25 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 18:13:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 18:13:25 --> Model Class Initialized
INFO - 2018-03-28 18:13:25 --> Model Class Initialized
INFO - 2018-03-28 18:13:25 --> Model Class Initialized
INFO - 2018-03-28 18:13:25 --> Model Class Initialized
INFO - 2018-03-28 18:13:25 --> Model Class Initialized
INFO - 2018-03-28 18:13:25 --> Model Class Initialized
INFO - 2018-03-28 18:13:25 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-28 18:13:25 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-28 18:13:25 --> Final output sent to browser
DEBUG - 2018-03-28 18:13:25 --> Total execution time: 0.1149
INFO - 2018-03-28 13:17:46 --> Config Class Initialized
INFO - 2018-03-28 13:17:46 --> Hooks Class Initialized
DEBUG - 2018-03-28 13:17:46 --> UTF-8 Support Enabled
INFO - 2018-03-28 13:17:46 --> Utf8 Class Initialized
INFO - 2018-03-28 13:17:46 --> URI Class Initialized
INFO - 2018-03-28 13:17:46 --> Router Class Initialized
INFO - 2018-03-28 13:17:46 --> Output Class Initialized
INFO - 2018-03-28 13:17:46 --> Security Class Initialized
DEBUG - 2018-03-28 13:17:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 13:17:46 --> Input Class Initialized
INFO - 2018-03-28 13:17:46 --> Language Class Initialized
INFO - 2018-03-28 13:17:46 --> Language Class Initialized
INFO - 2018-03-28 13:17:46 --> Config Class Initialized
INFO - 2018-03-28 13:17:46 --> Loader Class Initialized
INFO - 2018-03-28 18:47:46 --> Helper loaded: url_helper
INFO - 2018-03-28 18:47:46 --> Helper loaded: notification_helper
INFO - 2018-03-28 18:47:46 --> Helper loaded: settings_helper
INFO - 2018-03-28 18:47:46 --> Helper loaded: permission_helper
INFO - 2018-03-28 18:47:46 --> Helper loaded: users_helper
INFO - 2018-03-28 18:47:47 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:47:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:47:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:47:47 --> Helper loaded: form_helper
INFO - 2018-03-28 18:47:47 --> Form Validation Class Initialized
INFO - 2018-03-28 18:47:47 --> Controller Class Initialized
INFO - 2018-03-28 18:47:47 --> Model Class Initialized
INFO - 2018-03-28 18:47:47 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 18:47:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 18:47:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 18:47:47 --> Model Class Initialized
INFO - 2018-03-28 18:47:47 --> Model Class Initialized
INFO - 2018-03-28 18:47:47 --> Model Class Initialized
INFO - 2018-03-28 18:47:47 --> Model Class Initialized
INFO - 2018-03-28 18:47:47 --> Model Class Initialized
INFO - 2018-03-28 18:47:47 --> Model Class Initialized
INFO - 2018-03-28 18:47:47 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 18:47:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-28 18:47:47 --> Final output sent to browser
DEBUG - 2018-03-28 18:47:47 --> Total execution time: 1.3993
INFO - 2018-03-28 13:17:48 --> Config Class Initialized
INFO - 2018-03-28 13:17:48 --> Hooks Class Initialized
DEBUG - 2018-03-28 13:17:48 --> UTF-8 Support Enabled
INFO - 2018-03-28 13:17:48 --> Utf8 Class Initialized
INFO - 2018-03-28 13:17:48 --> URI Class Initialized
INFO - 2018-03-28 13:17:48 --> Router Class Initialized
INFO - 2018-03-28 13:17:48 --> Output Class Initialized
INFO - 2018-03-28 13:17:48 --> Security Class Initialized
DEBUG - 2018-03-28 13:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 13:17:48 --> Input Class Initialized
INFO - 2018-03-28 13:17:48 --> Language Class Initialized
INFO - 2018-03-28 13:17:48 --> Language Class Initialized
INFO - 2018-03-28 13:17:48 --> Config Class Initialized
INFO - 2018-03-28 13:17:48 --> Loader Class Initialized
INFO - 2018-03-28 18:47:48 --> Helper loaded: url_helper
INFO - 2018-03-28 18:47:48 --> Helper loaded: notification_helper
INFO - 2018-03-28 18:47:48 --> Helper loaded: settings_helper
INFO - 2018-03-28 18:47:48 --> Helper loaded: permission_helper
INFO - 2018-03-28 18:47:48 --> Helper loaded: users_helper
INFO - 2018-03-28 18:47:48 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:47:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:47:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:47:48 --> Helper loaded: form_helper
INFO - 2018-03-28 18:47:48 --> Form Validation Class Initialized
INFO - 2018-03-28 18:47:48 --> Controller Class Initialized
INFO - 2018-03-28 18:47:48 --> Model Class Initialized
INFO - 2018-03-28 18:47:48 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 18:47:48 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 18:47:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 18:47:48 --> Model Class Initialized
INFO - 2018-03-28 18:47:48 --> Model Class Initialized
INFO - 2018-03-28 18:47:48 --> Model Class Initialized
INFO - 2018-03-28 18:47:48 --> Model Class Initialized
INFO - 2018-03-28 18:47:48 --> Model Class Initialized
INFO - 2018-03-28 18:47:48 --> Model Class Initialized
INFO - 2018-03-28 18:47:48 --> Model Class Initialized
INFO - 2018-03-28 18:47:48 --> Model Class Initialized
INFO - 2018-03-28 18:47:48 --> Model Class Initialized
INFO - 2018-03-28 18:47:48 --> Model Class Initialized
INFO - 2018-03-28 18:47:48 --> Model Class Initialized
INFO - 2018-03-28 18:47:48 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 18:47:48 --> Model Class Initialized
INFO - 2018-03-28 18:47:48 --> Final output sent to browser
DEBUG - 2018-03-28 18:47:48 --> Total execution time: 0.1319
INFO - 2018-03-28 13:17:48 --> Config Class Initialized
INFO - 2018-03-28 13:17:48 --> Hooks Class Initialized
DEBUG - 2018-03-28 13:17:48 --> UTF-8 Support Enabled
INFO - 2018-03-28 13:17:48 --> Utf8 Class Initialized
INFO - 2018-03-28 13:17:48 --> URI Class Initialized
INFO - 2018-03-28 13:17:48 --> Router Class Initialized
INFO - 2018-03-28 13:17:48 --> Output Class Initialized
INFO - 2018-03-28 13:17:48 --> Security Class Initialized
DEBUG - 2018-03-28 13:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 13:17:48 --> Input Class Initialized
INFO - 2018-03-28 13:17:48 --> Language Class Initialized
INFO - 2018-03-28 13:17:48 --> Language Class Initialized
INFO - 2018-03-28 13:17:48 --> Config Class Initialized
INFO - 2018-03-28 13:17:48 --> Loader Class Initialized
INFO - 2018-03-28 18:47:48 --> Helper loaded: url_helper
INFO - 2018-03-28 18:47:48 --> Helper loaded: notification_helper
INFO - 2018-03-28 18:47:48 --> Helper loaded: settings_helper
INFO - 2018-03-28 18:47:48 --> Helper loaded: permission_helper
INFO - 2018-03-28 18:47:48 --> Helper loaded: users_helper
INFO - 2018-03-28 18:47:48 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:47:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:47:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:47:48 --> Helper loaded: form_helper
INFO - 2018-03-28 18:47:48 --> Form Validation Class Initialized
INFO - 2018-03-28 18:47:48 --> Controller Class Initialized
INFO - 2018-03-28 18:47:48 --> Model Class Initialized
INFO - 2018-03-28 18:47:48 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 18:47:48 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 18:47:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 18:47:48 --> Model Class Initialized
INFO - 2018-03-28 18:47:48 --> Model Class Initialized
INFO - 2018-03-28 18:47:48 --> Model Class Initialized
INFO - 2018-03-28 18:47:48 --> Model Class Initialized
INFO - 2018-03-28 18:47:48 --> Model Class Initialized
INFO - 2018-03-28 18:47:48 --> Model Class Initialized
INFO - 2018-03-28 18:47:48 --> Model Class Initialized
INFO - 2018-03-28 18:47:48 --> Model Class Initialized
INFO - 2018-03-28 18:47:48 --> Model Class Initialized
INFO - 2018-03-28 18:47:48 --> Model Class Initialized
INFO - 2018-03-28 18:47:48 --> Model Class Initialized
INFO - 2018-03-28 18:47:48 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 18:47:48 --> Model Class Initialized
INFO - 2018-03-28 18:47:48 --> Final output sent to browser
DEBUG - 2018-03-28 18:47:48 --> Total execution time: 0.1182
INFO - 2018-03-28 13:17:51 --> Config Class Initialized
INFO - 2018-03-28 13:17:51 --> Hooks Class Initialized
DEBUG - 2018-03-28 13:17:51 --> UTF-8 Support Enabled
INFO - 2018-03-28 13:17:51 --> Utf8 Class Initialized
INFO - 2018-03-28 13:17:51 --> URI Class Initialized
INFO - 2018-03-28 13:17:51 --> Router Class Initialized
INFO - 2018-03-28 13:17:51 --> Output Class Initialized
INFO - 2018-03-28 13:17:51 --> Security Class Initialized
DEBUG - 2018-03-28 13:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 13:17:51 --> Input Class Initialized
INFO - 2018-03-28 13:17:51 --> Language Class Initialized
INFO - 2018-03-28 13:17:51 --> Language Class Initialized
INFO - 2018-03-28 13:17:51 --> Config Class Initialized
INFO - 2018-03-28 13:17:51 --> Loader Class Initialized
INFO - 2018-03-28 18:47:51 --> Helper loaded: url_helper
INFO - 2018-03-28 18:47:51 --> Helper loaded: notification_helper
INFO - 2018-03-28 18:47:51 --> Helper loaded: settings_helper
INFO - 2018-03-28 18:47:51 --> Helper loaded: permission_helper
INFO - 2018-03-28 18:47:51 --> Helper loaded: users_helper
INFO - 2018-03-28 18:47:51 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:47:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:47:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:47:51 --> Helper loaded: form_helper
INFO - 2018-03-28 18:47:51 --> Form Validation Class Initialized
INFO - 2018-03-28 18:47:51 --> Controller Class Initialized
INFO - 2018-03-28 18:47:51 --> Model Class Initialized
INFO - 2018-03-28 18:47:51 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 18:47:51 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 18:47:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 18:47:51 --> Model Class Initialized
INFO - 2018-03-28 18:47:51 --> Model Class Initialized
INFO - 2018-03-28 18:47:51 --> Model Class Initialized
INFO - 2018-03-28 18:47:51 --> Model Class Initialized
INFO - 2018-03-28 18:47:51 --> Model Class Initialized
INFO - 2018-03-28 18:47:51 --> Model Class Initialized
INFO - 2018-03-28 18:47:51 --> Model Class Initialized
INFO - 2018-03-28 18:47:51 --> Model Class Initialized
INFO - 2018-03-28 18:47:51 --> Model Class Initialized
INFO - 2018-03-28 18:47:51 --> Model Class Initialized
INFO - 2018-03-28 18:47:51 --> Model Class Initialized
INFO - 2018-03-28 18:47:51 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 18:47:51 --> Model Class Initialized
INFO - 2018-03-28 18:47:51 --> Final output sent to browser
DEBUG - 2018-03-28 18:47:51 --> Total execution time: 0.1293
INFO - 2018-03-28 13:17:51 --> Config Class Initialized
INFO - 2018-03-28 13:17:51 --> Hooks Class Initialized
DEBUG - 2018-03-28 13:17:51 --> UTF-8 Support Enabled
INFO - 2018-03-28 13:17:51 --> Utf8 Class Initialized
INFO - 2018-03-28 13:17:51 --> URI Class Initialized
INFO - 2018-03-28 13:17:51 --> Router Class Initialized
INFO - 2018-03-28 13:17:51 --> Output Class Initialized
INFO - 2018-03-28 13:17:51 --> Security Class Initialized
DEBUG - 2018-03-28 13:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 13:17:51 --> Input Class Initialized
INFO - 2018-03-28 13:17:51 --> Language Class Initialized
INFO - 2018-03-28 13:17:51 --> Language Class Initialized
INFO - 2018-03-28 13:17:51 --> Config Class Initialized
INFO - 2018-03-28 13:17:51 --> Loader Class Initialized
INFO - 2018-03-28 18:47:51 --> Helper loaded: url_helper
INFO - 2018-03-28 18:47:51 --> Helper loaded: notification_helper
INFO - 2018-03-28 18:47:51 --> Helper loaded: settings_helper
INFO - 2018-03-28 18:47:51 --> Helper loaded: permission_helper
INFO - 2018-03-28 18:47:51 --> Helper loaded: users_helper
INFO - 2018-03-28 18:47:51 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:47:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:47:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:47:52 --> Helper loaded: form_helper
INFO - 2018-03-28 18:47:52 --> Form Validation Class Initialized
INFO - 2018-03-28 18:47:52 --> Controller Class Initialized
INFO - 2018-03-28 18:47:52 --> Model Class Initialized
INFO - 2018-03-28 18:47:52 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 18:47:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 18:47:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 18:47:52 --> Model Class Initialized
INFO - 2018-03-28 18:47:52 --> Model Class Initialized
INFO - 2018-03-28 18:47:52 --> Model Class Initialized
INFO - 2018-03-28 18:47:52 --> Model Class Initialized
INFO - 2018-03-28 18:47:52 --> Model Class Initialized
INFO - 2018-03-28 18:47:52 --> Model Class Initialized
INFO - 2018-03-28 18:47:52 --> Model Class Initialized
INFO - 2018-03-28 18:47:52 --> Model Class Initialized
INFO - 2018-03-28 18:47:52 --> Model Class Initialized
INFO - 2018-03-28 18:47:52 --> Model Class Initialized
INFO - 2018-03-28 18:47:53 --> Model Class Initialized
INFO - 2018-03-28 18:47:53 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 18:47:53 --> Final output sent to browser
DEBUG - 2018-03-28 18:47:53 --> Total execution time: 1.3845
INFO - 2018-03-28 13:17:58 --> Config Class Initialized
INFO - 2018-03-28 13:17:58 --> Hooks Class Initialized
DEBUG - 2018-03-28 13:17:58 --> UTF-8 Support Enabled
INFO - 2018-03-28 13:17:58 --> Utf8 Class Initialized
INFO - 2018-03-28 13:17:58 --> URI Class Initialized
INFO - 2018-03-28 13:17:58 --> Router Class Initialized
INFO - 2018-03-28 13:17:58 --> Output Class Initialized
INFO - 2018-03-28 13:17:58 --> Security Class Initialized
DEBUG - 2018-03-28 13:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 13:17:58 --> Input Class Initialized
INFO - 2018-03-28 13:17:58 --> Language Class Initialized
INFO - 2018-03-28 13:17:58 --> Language Class Initialized
INFO - 2018-03-28 13:17:58 --> Config Class Initialized
INFO - 2018-03-28 13:17:58 --> Loader Class Initialized
INFO - 2018-03-28 18:47:58 --> Helper loaded: url_helper
INFO - 2018-03-28 18:47:58 --> Helper loaded: notification_helper
INFO - 2018-03-28 18:47:58 --> Helper loaded: settings_helper
INFO - 2018-03-28 18:47:58 --> Helper loaded: permission_helper
INFO - 2018-03-28 18:47:58 --> Helper loaded: users_helper
INFO - 2018-03-28 18:47:58 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:47:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:47:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:47:58 --> Helper loaded: form_helper
INFO - 2018-03-28 18:47:58 --> Form Validation Class Initialized
INFO - 2018-03-28 18:47:58 --> Controller Class Initialized
INFO - 2018-03-28 18:47:58 --> Model Class Initialized
INFO - 2018-03-28 18:47:58 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 18:47:58 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 18:47:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 18:47:58 --> Model Class Initialized
INFO - 2018-03-28 18:47:58 --> Model Class Initialized
INFO - 2018-03-28 18:47:58 --> Model Class Initialized
INFO - 2018-03-28 18:47:58 --> Model Class Initialized
INFO - 2018-03-28 18:47:58 --> Model Class Initialized
INFO - 2018-03-28 18:47:58 --> Model Class Initialized
INFO - 2018-03-28 18:47:58 --> Model Class Initialized
INFO - 2018-03-28 18:47:58 --> Model Class Initialized
INFO - 2018-03-28 18:47:58 --> Model Class Initialized
INFO - 2018-03-28 18:47:58 --> Model Class Initialized
INFO - 2018-03-28 18:47:58 --> Model Class Initialized
INFO - 2018-03-28 18:47:58 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 18:47:58 --> Final output sent to browser
DEBUG - 2018-03-28 18:47:58 --> Total execution time: 0.1241
INFO - 2018-03-28 13:18:01 --> Config Class Initialized
INFO - 2018-03-28 13:18:01 --> Hooks Class Initialized
DEBUG - 2018-03-28 13:18:01 --> UTF-8 Support Enabled
INFO - 2018-03-28 13:18:01 --> Utf8 Class Initialized
INFO - 2018-03-28 13:18:01 --> URI Class Initialized
INFO - 2018-03-28 13:18:01 --> Router Class Initialized
INFO - 2018-03-28 13:18:01 --> Output Class Initialized
INFO - 2018-03-28 13:18:01 --> Security Class Initialized
DEBUG - 2018-03-28 13:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 13:18:01 --> Input Class Initialized
INFO - 2018-03-28 13:18:01 --> Language Class Initialized
INFO - 2018-03-28 13:18:01 --> Language Class Initialized
INFO - 2018-03-28 13:18:01 --> Config Class Initialized
INFO - 2018-03-28 13:18:01 --> Loader Class Initialized
INFO - 2018-03-28 18:48:01 --> Helper loaded: url_helper
INFO - 2018-03-28 18:48:01 --> Helper loaded: notification_helper
INFO - 2018-03-28 18:48:01 --> Helper loaded: settings_helper
INFO - 2018-03-28 18:48:01 --> Helper loaded: permission_helper
INFO - 2018-03-28 18:48:01 --> Helper loaded: users_helper
INFO - 2018-03-28 18:48:01 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:48:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:48:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:48:01 --> Helper loaded: form_helper
INFO - 2018-03-28 18:48:01 --> Form Validation Class Initialized
INFO - 2018-03-28 18:48:01 --> Controller Class Initialized
INFO - 2018-03-28 18:48:01 --> Model Class Initialized
INFO - 2018-03-28 18:48:01 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 18:48:01 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 18:48:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 18:48:01 --> Model Class Initialized
INFO - 2018-03-28 18:48:01 --> Model Class Initialized
INFO - 2018-03-28 18:48:01 --> Model Class Initialized
INFO - 2018-03-28 18:48:01 --> Model Class Initialized
INFO - 2018-03-28 18:48:01 --> Model Class Initialized
INFO - 2018-03-28 18:48:01 --> Model Class Initialized
INFO - 2018-03-28 18:48:01 --> Model Class Initialized
INFO - 2018-03-28 18:48:01 --> Model Class Initialized
INFO - 2018-03-28 18:48:01 --> Model Class Initialized
INFO - 2018-03-28 18:48:01 --> Model Class Initialized
INFO - 2018-03-28 18:48:01 --> Model Class Initialized
INFO - 2018-03-28 18:48:01 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 18:48:01 --> Final output sent to browser
DEBUG - 2018-03-28 18:48:01 --> Total execution time: 0.1906
INFO - 2018-03-28 13:18:02 --> Config Class Initialized
INFO - 2018-03-28 13:18:02 --> Hooks Class Initialized
DEBUG - 2018-03-28 13:18:02 --> UTF-8 Support Enabled
INFO - 2018-03-28 13:18:02 --> Utf8 Class Initialized
INFO - 2018-03-28 13:18:02 --> URI Class Initialized
INFO - 2018-03-28 13:18:02 --> Router Class Initialized
INFO - 2018-03-28 13:18:02 --> Output Class Initialized
INFO - 2018-03-28 13:18:02 --> Security Class Initialized
DEBUG - 2018-03-28 13:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 13:18:02 --> Input Class Initialized
INFO - 2018-03-28 13:18:02 --> Language Class Initialized
INFO - 2018-03-28 13:18:02 --> Language Class Initialized
INFO - 2018-03-28 13:18:02 --> Config Class Initialized
INFO - 2018-03-28 13:18:02 --> Loader Class Initialized
INFO - 2018-03-28 18:48:02 --> Helper loaded: url_helper
INFO - 2018-03-28 18:48:02 --> Helper loaded: notification_helper
INFO - 2018-03-28 18:48:02 --> Helper loaded: settings_helper
INFO - 2018-03-28 18:48:02 --> Helper loaded: permission_helper
INFO - 2018-03-28 18:48:02 --> Helper loaded: users_helper
INFO - 2018-03-28 18:48:02 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:48:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:48:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:48:02 --> Helper loaded: form_helper
INFO - 2018-03-28 18:48:02 --> Form Validation Class Initialized
INFO - 2018-03-28 18:48:02 --> Controller Class Initialized
INFO - 2018-03-28 18:48:02 --> Model Class Initialized
INFO - 2018-03-28 18:48:02 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 18:48:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 18:48:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 18:48:02 --> Model Class Initialized
INFO - 2018-03-28 18:48:02 --> Model Class Initialized
INFO - 2018-03-28 18:48:02 --> Model Class Initialized
INFO - 2018-03-28 18:48:02 --> Model Class Initialized
INFO - 2018-03-28 18:48:02 --> Model Class Initialized
INFO - 2018-03-28 18:48:02 --> Model Class Initialized
INFO - 2018-03-28 18:48:02 --> Model Class Initialized
INFO - 2018-03-28 18:48:02 --> Model Class Initialized
INFO - 2018-03-28 18:48:02 --> Model Class Initialized
INFO - 2018-03-28 18:48:02 --> Model Class Initialized
INFO - 2018-03-28 18:48:02 --> Model Class Initialized
INFO - 2018-03-28 18:48:02 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 18:48:02 --> Model Class Initialized
INFO - 2018-03-28 18:48:02 --> Final output sent to browser
DEBUG - 2018-03-28 18:48:02 --> Total execution time: 0.1070
INFO - 2018-03-28 13:20:21 --> Config Class Initialized
INFO - 2018-03-28 13:20:21 --> Hooks Class Initialized
DEBUG - 2018-03-28 13:20:21 --> UTF-8 Support Enabled
INFO - 2018-03-28 13:20:21 --> Utf8 Class Initialized
INFO - 2018-03-28 13:20:21 --> URI Class Initialized
INFO - 2018-03-28 13:20:21 --> Router Class Initialized
INFO - 2018-03-28 13:20:21 --> Output Class Initialized
INFO - 2018-03-28 13:20:21 --> Security Class Initialized
DEBUG - 2018-03-28 13:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 13:20:21 --> Input Class Initialized
INFO - 2018-03-28 13:20:21 --> Language Class Initialized
INFO - 2018-03-28 13:20:21 --> Language Class Initialized
INFO - 2018-03-28 13:20:21 --> Config Class Initialized
INFO - 2018-03-28 13:20:21 --> Loader Class Initialized
INFO - 2018-03-28 18:50:21 --> Helper loaded: url_helper
INFO - 2018-03-28 18:50:21 --> Helper loaded: notification_helper
INFO - 2018-03-28 18:50:21 --> Helper loaded: settings_helper
INFO - 2018-03-28 18:50:21 --> Helper loaded: permission_helper
INFO - 2018-03-28 18:50:21 --> Helper loaded: users_helper
INFO - 2018-03-28 18:50:21 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:50:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:50:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:50:21 --> Helper loaded: form_helper
INFO - 2018-03-28 18:50:21 --> Form Validation Class Initialized
INFO - 2018-03-28 18:50:21 --> Controller Class Initialized
INFO - 2018-03-28 18:50:21 --> Model Class Initialized
INFO - 2018-03-28 18:50:21 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 18:50:21 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 18:50:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 18:50:21 --> Model Class Initialized
INFO - 2018-03-28 18:50:21 --> Model Class Initialized
INFO - 2018-03-28 18:50:21 --> Model Class Initialized
INFO - 2018-03-28 18:50:21 --> Model Class Initialized
INFO - 2018-03-28 18:50:21 --> Model Class Initialized
INFO - 2018-03-28 18:50:21 --> Model Class Initialized
INFO - 2018-03-28 18:50:21 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 18:50:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-28 18:50:21 --> Final output sent to browser
DEBUG - 2018-03-28 18:50:21 --> Total execution time: 0.2411
INFO - 2018-03-28 13:20:22 --> Config Class Initialized
INFO - 2018-03-28 13:20:22 --> Hooks Class Initialized
DEBUG - 2018-03-28 13:20:22 --> UTF-8 Support Enabled
INFO - 2018-03-28 13:20:22 --> Utf8 Class Initialized
INFO - 2018-03-28 13:20:22 --> URI Class Initialized
INFO - 2018-03-28 13:20:22 --> Router Class Initialized
INFO - 2018-03-28 13:20:22 --> Output Class Initialized
INFO - 2018-03-28 13:20:22 --> Security Class Initialized
DEBUG - 2018-03-28 13:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 13:20:22 --> Input Class Initialized
INFO - 2018-03-28 13:20:22 --> Language Class Initialized
INFO - 2018-03-28 13:20:22 --> Language Class Initialized
INFO - 2018-03-28 13:20:22 --> Config Class Initialized
INFO - 2018-03-28 13:20:22 --> Loader Class Initialized
INFO - 2018-03-28 18:50:22 --> Helper loaded: url_helper
INFO - 2018-03-28 18:50:22 --> Helper loaded: notification_helper
INFO - 2018-03-28 18:50:22 --> Helper loaded: settings_helper
INFO - 2018-03-28 18:50:22 --> Helper loaded: permission_helper
INFO - 2018-03-28 18:50:22 --> Helper loaded: users_helper
INFO - 2018-03-28 18:50:22 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:50:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:50:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:50:22 --> Helper loaded: form_helper
INFO - 2018-03-28 18:50:22 --> Form Validation Class Initialized
INFO - 2018-03-28 18:50:22 --> Controller Class Initialized
INFO - 2018-03-28 18:50:22 --> Model Class Initialized
INFO - 2018-03-28 18:50:22 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 18:50:22 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 18:50:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 18:50:22 --> Model Class Initialized
INFO - 2018-03-28 18:50:22 --> Model Class Initialized
INFO - 2018-03-28 18:50:22 --> Model Class Initialized
INFO - 2018-03-28 18:50:22 --> Model Class Initialized
INFO - 2018-03-28 18:50:22 --> Model Class Initialized
INFO - 2018-03-28 18:50:22 --> Model Class Initialized
INFO - 2018-03-28 18:50:22 --> Model Class Initialized
INFO - 2018-03-28 18:50:22 --> Model Class Initialized
INFO - 2018-03-28 18:50:22 --> Model Class Initialized
INFO - 2018-03-28 18:50:22 --> Model Class Initialized
INFO - 2018-03-28 18:50:22 --> Model Class Initialized
INFO - 2018-03-28 18:50:22 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 18:50:22 --> Model Class Initialized
INFO - 2018-03-28 18:50:22 --> Final output sent to browser
DEBUG - 2018-03-28 18:50:22 --> Total execution time: 0.2056
INFO - 2018-03-28 13:20:23 --> Config Class Initialized
INFO - 2018-03-28 13:20:23 --> Hooks Class Initialized
DEBUG - 2018-03-28 13:20:23 --> UTF-8 Support Enabled
INFO - 2018-03-28 13:20:23 --> Utf8 Class Initialized
INFO - 2018-03-28 13:20:23 --> URI Class Initialized
INFO - 2018-03-28 13:20:23 --> Router Class Initialized
INFO - 2018-03-28 13:20:23 --> Output Class Initialized
INFO - 2018-03-28 13:20:23 --> Security Class Initialized
DEBUG - 2018-03-28 13:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 13:20:23 --> Input Class Initialized
INFO - 2018-03-28 13:20:23 --> Language Class Initialized
INFO - 2018-03-28 13:20:24 --> Language Class Initialized
INFO - 2018-03-28 13:20:24 --> Config Class Initialized
INFO - 2018-03-28 13:20:24 --> Loader Class Initialized
INFO - 2018-03-28 18:50:24 --> Helper loaded: url_helper
INFO - 2018-03-28 18:50:24 --> Helper loaded: notification_helper
INFO - 2018-03-28 18:50:24 --> Helper loaded: settings_helper
INFO - 2018-03-28 18:50:24 --> Helper loaded: permission_helper
INFO - 2018-03-28 18:50:24 --> Helper loaded: users_helper
INFO - 2018-03-28 18:50:24 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:50:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:50:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:50:24 --> Helper loaded: form_helper
INFO - 2018-03-28 18:50:24 --> Form Validation Class Initialized
INFO - 2018-03-28 18:50:24 --> Controller Class Initialized
INFO - 2018-03-28 18:50:24 --> Model Class Initialized
INFO - 2018-03-28 18:50:24 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 18:50:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 18:50:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 18:50:24 --> Model Class Initialized
INFO - 2018-03-28 18:50:24 --> Model Class Initialized
INFO - 2018-03-28 18:50:24 --> Model Class Initialized
INFO - 2018-03-28 18:50:24 --> Model Class Initialized
INFO - 2018-03-28 18:50:24 --> Model Class Initialized
INFO - 2018-03-28 18:50:24 --> Model Class Initialized
INFO - 2018-03-28 18:50:24 --> Model Class Initialized
INFO - 2018-03-28 18:50:24 --> Model Class Initialized
INFO - 2018-03-28 18:50:24 --> Model Class Initialized
INFO - 2018-03-28 18:50:24 --> Model Class Initialized
INFO - 2018-03-28 18:50:24 --> Model Class Initialized
INFO - 2018-03-28 18:50:24 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 18:50:24 --> Model Class Initialized
INFO - 2018-03-28 18:50:24 --> Final output sent to browser
DEBUG - 2018-03-28 18:50:24 --> Total execution time: 1.3792
INFO - 2018-03-28 13:20:25 --> Config Class Initialized
INFO - 2018-03-28 13:20:25 --> Hooks Class Initialized
DEBUG - 2018-03-28 13:20:25 --> UTF-8 Support Enabled
INFO - 2018-03-28 13:20:25 --> Utf8 Class Initialized
INFO - 2018-03-28 13:20:25 --> URI Class Initialized
INFO - 2018-03-28 13:20:25 --> Router Class Initialized
INFO - 2018-03-28 13:20:25 --> Output Class Initialized
INFO - 2018-03-28 13:20:25 --> Security Class Initialized
DEBUG - 2018-03-28 13:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 13:20:25 --> Input Class Initialized
INFO - 2018-03-28 13:20:25 --> Language Class Initialized
INFO - 2018-03-28 13:20:25 --> Language Class Initialized
INFO - 2018-03-28 13:20:25 --> Config Class Initialized
INFO - 2018-03-28 13:20:25 --> Loader Class Initialized
INFO - 2018-03-28 18:50:25 --> Helper loaded: url_helper
INFO - 2018-03-28 18:50:25 --> Helper loaded: notification_helper
INFO - 2018-03-28 18:50:25 --> Helper loaded: settings_helper
INFO - 2018-03-28 18:50:25 --> Helper loaded: permission_helper
INFO - 2018-03-28 18:50:25 --> Helper loaded: users_helper
INFO - 2018-03-28 18:50:26 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:50:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:50:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:50:26 --> Helper loaded: form_helper
INFO - 2018-03-28 18:50:26 --> Form Validation Class Initialized
INFO - 2018-03-28 18:50:26 --> Controller Class Initialized
INFO - 2018-03-28 18:50:26 --> Model Class Initialized
INFO - 2018-03-28 18:50:26 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 18:50:26 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 18:50:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 18:50:26 --> Model Class Initialized
INFO - 2018-03-28 18:50:26 --> Model Class Initialized
INFO - 2018-03-28 18:50:26 --> Model Class Initialized
INFO - 2018-03-28 18:50:26 --> Model Class Initialized
INFO - 2018-03-28 18:50:26 --> Model Class Initialized
INFO - 2018-03-28 18:50:26 --> Model Class Initialized
INFO - 2018-03-28 18:50:26 --> Model Class Initialized
INFO - 2018-03-28 18:50:26 --> Model Class Initialized
INFO - 2018-03-28 18:50:26 --> Model Class Initialized
INFO - 2018-03-28 18:50:26 --> Model Class Initialized
INFO - 2018-03-28 18:50:26 --> Model Class Initialized
INFO - 2018-03-28 18:50:26 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 18:50:26 --> Model Class Initialized
INFO - 2018-03-28 18:50:26 --> Final output sent to browser
DEBUG - 2018-03-28 18:50:26 --> Total execution time: 1.0609
INFO - 2018-03-28 13:20:30 --> Config Class Initialized
INFO - 2018-03-28 13:20:30 --> Hooks Class Initialized
DEBUG - 2018-03-28 13:20:30 --> UTF-8 Support Enabled
INFO - 2018-03-28 13:20:30 --> Utf8 Class Initialized
INFO - 2018-03-28 13:20:30 --> URI Class Initialized
INFO - 2018-03-28 13:20:30 --> Router Class Initialized
INFO - 2018-03-28 13:20:30 --> Output Class Initialized
INFO - 2018-03-28 13:20:30 --> Security Class Initialized
DEBUG - 2018-03-28 13:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 13:20:30 --> Input Class Initialized
INFO - 2018-03-28 13:20:30 --> Language Class Initialized
INFO - 2018-03-28 13:20:30 --> Language Class Initialized
INFO - 2018-03-28 13:20:30 --> Config Class Initialized
INFO - 2018-03-28 13:20:30 --> Loader Class Initialized
INFO - 2018-03-28 18:50:30 --> Helper loaded: url_helper
INFO - 2018-03-28 18:50:30 --> Helper loaded: notification_helper
INFO - 2018-03-28 18:50:30 --> Helper loaded: settings_helper
INFO - 2018-03-28 18:50:30 --> Helper loaded: permission_helper
INFO - 2018-03-28 18:50:30 --> Helper loaded: users_helper
INFO - 2018-03-28 18:50:30 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:50:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:50:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:50:30 --> Helper loaded: form_helper
INFO - 2018-03-28 18:50:30 --> Form Validation Class Initialized
INFO - 2018-03-28 18:50:30 --> Controller Class Initialized
INFO - 2018-03-28 18:50:30 --> Model Class Initialized
INFO - 2018-03-28 18:50:30 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 18:50:30 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 18:50:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 18:50:30 --> Model Class Initialized
INFO - 2018-03-28 18:50:30 --> Model Class Initialized
INFO - 2018-03-28 18:50:30 --> Model Class Initialized
INFO - 2018-03-28 18:50:30 --> Model Class Initialized
INFO - 2018-03-28 18:50:30 --> Model Class Initialized
INFO - 2018-03-28 18:50:30 --> Model Class Initialized
INFO - 2018-03-28 18:50:30 --> Model Class Initialized
INFO - 2018-03-28 18:50:30 --> Model Class Initialized
INFO - 2018-03-28 18:50:30 --> Model Class Initialized
INFO - 2018-03-28 18:50:30 --> Model Class Initialized
INFO - 2018-03-28 18:50:30 --> Model Class Initialized
INFO - 2018-03-28 18:50:30 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 18:50:30 --> Model Class Initialized
INFO - 2018-03-28 18:50:30 --> Final output sent to browser
DEBUG - 2018-03-28 18:50:30 --> Total execution time: 0.0954
INFO - 2018-03-28 13:20:30 --> Config Class Initialized
INFO - 2018-03-28 13:20:30 --> Hooks Class Initialized
DEBUG - 2018-03-28 13:20:30 --> UTF-8 Support Enabled
INFO - 2018-03-28 13:20:30 --> Utf8 Class Initialized
INFO - 2018-03-28 13:20:30 --> URI Class Initialized
INFO - 2018-03-28 13:20:30 --> Router Class Initialized
INFO - 2018-03-28 13:20:30 --> Output Class Initialized
INFO - 2018-03-28 13:20:30 --> Security Class Initialized
DEBUG - 2018-03-28 13:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 13:20:30 --> Input Class Initialized
INFO - 2018-03-28 13:20:30 --> Language Class Initialized
INFO - 2018-03-28 13:20:30 --> Language Class Initialized
INFO - 2018-03-28 13:20:30 --> Config Class Initialized
INFO - 2018-03-28 13:20:30 --> Loader Class Initialized
INFO - 2018-03-28 18:50:30 --> Helper loaded: url_helper
INFO - 2018-03-28 18:50:30 --> Helper loaded: notification_helper
INFO - 2018-03-28 18:50:30 --> Helper loaded: settings_helper
INFO - 2018-03-28 18:50:30 --> Helper loaded: permission_helper
INFO - 2018-03-28 18:50:30 --> Helper loaded: users_helper
INFO - 2018-03-28 18:50:30 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:50:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:50:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:50:30 --> Helper loaded: form_helper
INFO - 2018-03-28 18:50:30 --> Form Validation Class Initialized
INFO - 2018-03-28 18:50:30 --> Controller Class Initialized
INFO - 2018-03-28 18:50:30 --> Model Class Initialized
INFO - 2018-03-28 18:50:30 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 18:50:30 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 18:50:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 18:50:30 --> Model Class Initialized
INFO - 2018-03-28 18:50:30 --> Model Class Initialized
INFO - 2018-03-28 18:50:30 --> Model Class Initialized
INFO - 2018-03-28 18:50:30 --> Model Class Initialized
INFO - 2018-03-28 18:50:30 --> Model Class Initialized
INFO - 2018-03-28 18:50:30 --> Model Class Initialized
INFO - 2018-03-28 18:50:30 --> Model Class Initialized
INFO - 2018-03-28 18:50:30 --> Model Class Initialized
INFO - 2018-03-28 18:50:30 --> Model Class Initialized
INFO - 2018-03-28 18:50:30 --> Model Class Initialized
INFO - 2018-03-28 18:50:30 --> Model Class Initialized
INFO - 2018-03-28 18:50:30 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 18:50:30 --> Final output sent to browser
DEBUG - 2018-03-28 18:50:30 --> Total execution time: 0.1199
INFO - 2018-03-28 13:20:42 --> Config Class Initialized
INFO - 2018-03-28 13:20:42 --> Hooks Class Initialized
INFO - 2018-03-28 13:20:42 --> Config Class Initialized
INFO - 2018-03-28 13:20:42 --> Hooks Class Initialized
DEBUG - 2018-03-28 13:20:42 --> UTF-8 Support Enabled
INFO - 2018-03-28 13:20:42 --> Utf8 Class Initialized
INFO - 2018-03-28 13:20:42 --> URI Class Initialized
DEBUG - 2018-03-28 13:20:42 --> UTF-8 Support Enabled
INFO - 2018-03-28 13:20:42 --> Utf8 Class Initialized
INFO - 2018-03-28 13:20:42 --> Router Class Initialized
INFO - 2018-03-28 13:20:42 --> URI Class Initialized
INFO - 2018-03-28 13:20:42 --> Router Class Initialized
INFO - 2018-03-28 13:20:42 --> Output Class Initialized
INFO - 2018-03-28 13:20:42 --> Output Class Initialized
INFO - 2018-03-28 13:20:42 --> Security Class Initialized
INFO - 2018-03-28 13:20:42 --> Security Class Initialized
DEBUG - 2018-03-28 13:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 13:20:42 --> Input Class Initialized
INFO - 2018-03-28 13:20:42 --> Language Class Initialized
DEBUG - 2018-03-28 13:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 13:20:42 --> Input Class Initialized
INFO - 2018-03-28 13:20:42 --> Language Class Initialized
INFO - 2018-03-28 13:20:42 --> Language Class Initialized
INFO - 2018-03-28 13:20:42 --> Config Class Initialized
INFO - 2018-03-28 13:20:42 --> Loader Class Initialized
INFO - 2018-03-28 18:50:42 --> Helper loaded: url_helper
INFO - 2018-03-28 13:20:42 --> Language Class Initialized
INFO - 2018-03-28 13:20:42 --> Config Class Initialized
INFO - 2018-03-28 13:20:42 --> Loader Class Initialized
INFO - 2018-03-28 18:50:42 --> Helper loaded: notification_helper
INFO - 2018-03-28 18:50:42 --> Helper loaded: settings_helper
INFO - 2018-03-28 18:50:42 --> Helper loaded: permission_helper
INFO - 2018-03-28 18:50:42 --> Helper loaded: url_helper
INFO - 2018-03-28 18:50:42 --> Helper loaded: users_helper
INFO - 2018-03-28 18:50:42 --> Helper loaded: notification_helper
INFO - 2018-03-28 18:50:42 --> Helper loaded: settings_helper
INFO - 2018-03-28 18:50:42 --> Helper loaded: permission_helper
INFO - 2018-03-28 18:50:42 --> Helper loaded: users_helper
INFO - 2018-03-28 18:50:42 --> Database Driver Class Initialized
INFO - 2018-03-28 18:50:42 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:50:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:50:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-03-28 18:50:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:50:42 --> Helper loaded: form_helper
INFO - 2018-03-28 18:50:42 --> Form Validation Class Initialized
INFO - 2018-03-28 18:50:42 --> Controller Class Initialized
INFO - 2018-03-28 18:50:42 --> Model Class Initialized
INFO - 2018-03-28 18:50:42 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 18:50:42 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 18:50:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 18:50:42 --> Model Class Initialized
INFO - 2018-03-28 18:50:42 --> Model Class Initialized
INFO - 2018-03-28 18:50:42 --> Model Class Initialized
INFO - 2018-03-28 18:50:42 --> Model Class Initialized
INFO - 2018-03-28 18:50:42 --> Model Class Initialized
INFO - 2018-03-28 18:50:42 --> Model Class Initialized
INFO - 2018-03-28 18:50:42 --> Model Class Initialized
INFO - 2018-03-28 18:50:42 --> Model Class Initialized
INFO - 2018-03-28 18:50:42 --> Model Class Initialized
INFO - 2018-03-28 18:50:42 --> Model Class Initialized
INFO - 2018-03-28 18:50:42 --> Model Class Initialized
INFO - 2018-03-28 18:50:42 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 18:50:42 --> Model Class Initialized
INFO - 2018-03-28 18:50:42 --> Helper loaded: form_helper
INFO - 2018-03-28 18:50:42 --> Form Validation Class Initialized
INFO - 2018-03-28 18:50:42 --> Controller Class Initialized
INFO - 2018-03-28 18:50:42 --> Final output sent to browser
DEBUG - 2018-03-28 18:50:42 --> Total execution time: 0.7963
INFO - 2018-03-28 18:50:42 --> Model Class Initialized
INFO - 2018-03-28 18:50:42 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 18:50:42 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 18:50:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 18:50:42 --> Model Class Initialized
INFO - 2018-03-28 18:50:42 --> Model Class Initialized
INFO - 2018-03-28 18:50:42 --> Model Class Initialized
INFO - 2018-03-28 18:50:42 --> Model Class Initialized
INFO - 2018-03-28 18:50:42 --> Model Class Initialized
INFO - 2018-03-28 18:50:43 --> Model Class Initialized
INFO - 2018-03-28 18:50:43 --> Model Class Initialized
INFO - 2018-03-28 18:50:43 --> Model Class Initialized
INFO - 2018-03-28 18:50:43 --> Model Class Initialized
INFO - 2018-03-28 18:50:43 --> Model Class Initialized
INFO - 2018-03-28 18:50:43 --> Model Class Initialized
INFO - 2018-03-28 18:50:43 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 18:50:43 --> Final output sent to browser
DEBUG - 2018-03-28 18:50:43 --> Total execution time: 1.1412
INFO - 2018-03-28 13:26:02 --> Config Class Initialized
INFO - 2018-03-28 13:26:02 --> Hooks Class Initialized
DEBUG - 2018-03-28 13:26:02 --> UTF-8 Support Enabled
INFO - 2018-03-28 13:26:02 --> Utf8 Class Initialized
INFO - 2018-03-28 13:26:02 --> URI Class Initialized
INFO - 2018-03-28 13:26:02 --> Router Class Initialized
INFO - 2018-03-28 13:26:02 --> Output Class Initialized
INFO - 2018-03-28 13:26:02 --> Security Class Initialized
DEBUG - 2018-03-28 13:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 13:26:02 --> Input Class Initialized
INFO - 2018-03-28 13:26:02 --> Language Class Initialized
INFO - 2018-03-28 13:26:02 --> Language Class Initialized
INFO - 2018-03-28 13:26:02 --> Config Class Initialized
INFO - 2018-03-28 13:26:02 --> Loader Class Initialized
INFO - 2018-03-28 18:56:02 --> Helper loaded: url_helper
INFO - 2018-03-28 18:56:02 --> Helper loaded: notification_helper
INFO - 2018-03-28 18:56:02 --> Helper loaded: settings_helper
INFO - 2018-03-28 18:56:02 --> Helper loaded: permission_helper
INFO - 2018-03-28 18:56:02 --> Helper loaded: users_helper
INFO - 2018-03-28 18:56:02 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:56:02 --> Helper loaded: form_helper
INFO - 2018-03-28 18:56:02 --> Form Validation Class Initialized
INFO - 2018-03-28 18:56:02 --> Controller Class Initialized
INFO - 2018-03-28 18:56:02 --> Model Class Initialized
INFO - 2018-03-28 18:56:02 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 18:56:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 18:56:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 18:56:02 --> Model Class Initialized
INFO - 2018-03-28 18:56:02 --> Model Class Initialized
INFO - 2018-03-28 18:56:02 --> Model Class Initialized
INFO - 2018-03-28 18:56:02 --> Model Class Initialized
INFO - 2018-03-28 18:56:02 --> Model Class Initialized
INFO - 2018-03-28 18:56:02 --> Model Class Initialized
INFO - 2018-03-28 18:56:02 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 18:56:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-28 18:56:02 --> Final output sent to browser
DEBUG - 2018-03-28 18:56:02 --> Total execution time: 0.7620
INFO - 2018-03-28 13:26:04 --> Config Class Initialized
INFO - 2018-03-28 13:26:04 --> Hooks Class Initialized
DEBUG - 2018-03-28 13:26:04 --> UTF-8 Support Enabled
INFO - 2018-03-28 13:26:04 --> Utf8 Class Initialized
INFO - 2018-03-28 13:26:04 --> URI Class Initialized
INFO - 2018-03-28 13:26:04 --> Router Class Initialized
INFO - 2018-03-28 13:26:04 --> Output Class Initialized
INFO - 2018-03-28 13:26:04 --> Security Class Initialized
DEBUG - 2018-03-28 13:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 13:26:04 --> Input Class Initialized
INFO - 2018-03-28 13:26:04 --> Language Class Initialized
INFO - 2018-03-28 13:26:04 --> Language Class Initialized
INFO - 2018-03-28 13:26:04 --> Config Class Initialized
INFO - 2018-03-28 13:26:04 --> Loader Class Initialized
INFO - 2018-03-28 18:56:04 --> Helper loaded: url_helper
INFO - 2018-03-28 18:56:04 --> Helper loaded: notification_helper
INFO - 2018-03-28 18:56:04 --> Helper loaded: settings_helper
INFO - 2018-03-28 18:56:04 --> Helper loaded: permission_helper
INFO - 2018-03-28 18:56:04 --> Helper loaded: users_helper
INFO - 2018-03-28 18:56:04 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:56:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:56:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:56:04 --> Helper loaded: form_helper
INFO - 2018-03-28 18:56:04 --> Form Validation Class Initialized
INFO - 2018-03-28 18:56:04 --> Controller Class Initialized
INFO - 2018-03-28 18:56:04 --> Model Class Initialized
INFO - 2018-03-28 18:56:04 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 18:56:04 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 18:56:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 18:56:04 --> Model Class Initialized
INFO - 2018-03-28 18:56:04 --> Model Class Initialized
INFO - 2018-03-28 18:56:04 --> Model Class Initialized
INFO - 2018-03-28 18:56:04 --> Model Class Initialized
INFO - 2018-03-28 13:26:04 --> Config Class Initialized
INFO - 2018-03-28 13:26:04 --> Hooks Class Initialized
INFO - 2018-03-28 18:56:04 --> Model Class Initialized
INFO - 2018-03-28 18:56:04 --> Model Class Initialized
INFO - 2018-03-28 18:56:04 --> Model Class Initialized
DEBUG - 2018-03-28 13:26:04 --> UTF-8 Support Enabled
INFO - 2018-03-28 13:26:04 --> Utf8 Class Initialized
INFO - 2018-03-28 18:56:04 --> Model Class Initialized
INFO - 2018-03-28 18:56:04 --> Model Class Initialized
INFO - 2018-03-28 18:56:04 --> Model Class Initialized
INFO - 2018-03-28 13:26:04 --> URI Class Initialized
INFO - 2018-03-28 18:56:04 --> Model Class Initialized
INFO - 2018-03-28 13:26:04 --> Router Class Initialized
INFO - 2018-03-28 18:56:04 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 18:56:04 --> Model Class Initialized
INFO - 2018-03-28 13:26:04 --> Output Class Initialized
INFO - 2018-03-28 13:26:04 --> Security Class Initialized
DEBUG - 2018-03-28 13:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 13:26:04 --> Input Class Initialized
INFO - 2018-03-28 13:26:04 --> Language Class Initialized
INFO - 2018-03-28 18:56:04 --> Final output sent to browser
DEBUG - 2018-03-28 18:56:04 --> Total execution time: 0.3141
INFO - 2018-03-28 13:26:04 --> Language Class Initialized
INFO - 2018-03-28 13:26:04 --> Config Class Initialized
INFO - 2018-03-28 13:26:04 --> Loader Class Initialized
INFO - 2018-03-28 18:56:04 --> Helper loaded: url_helper
INFO - 2018-03-28 18:56:04 --> Helper loaded: notification_helper
INFO - 2018-03-28 18:56:04 --> Helper loaded: settings_helper
INFO - 2018-03-28 18:56:04 --> Helper loaded: permission_helper
INFO - 2018-03-28 18:56:04 --> Helper loaded: users_helper
INFO - 2018-03-28 18:56:04 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:56:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:56:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:56:04 --> Helper loaded: form_helper
INFO - 2018-03-28 18:56:04 --> Form Validation Class Initialized
INFO - 2018-03-28 18:56:04 --> Controller Class Initialized
INFO - 2018-03-28 18:56:04 --> Model Class Initialized
INFO - 2018-03-28 18:56:04 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 18:56:04 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 18:56:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 18:56:04 --> Model Class Initialized
INFO - 2018-03-28 18:56:04 --> Model Class Initialized
INFO - 2018-03-28 18:56:04 --> Model Class Initialized
INFO - 2018-03-28 18:56:04 --> Model Class Initialized
INFO - 2018-03-28 18:56:04 --> Model Class Initialized
INFO - 2018-03-28 18:56:04 --> Model Class Initialized
INFO - 2018-03-28 18:56:04 --> Model Class Initialized
INFO - 2018-03-28 18:56:04 --> Model Class Initialized
INFO - 2018-03-28 18:56:04 --> Model Class Initialized
INFO - 2018-03-28 18:56:04 --> Model Class Initialized
INFO - 2018-03-28 18:56:04 --> Model Class Initialized
INFO - 2018-03-28 18:56:04 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 18:56:04 --> Model Class Initialized
INFO - 2018-03-28 18:56:04 --> Final output sent to browser
DEBUG - 2018-03-28 18:56:04 --> Total execution time: 0.2574
INFO - 2018-03-28 13:26:08 --> Config Class Initialized
INFO - 2018-03-28 13:26:08 --> Hooks Class Initialized
DEBUG - 2018-03-28 13:26:08 --> UTF-8 Support Enabled
INFO - 2018-03-28 13:26:08 --> Utf8 Class Initialized
INFO - 2018-03-28 13:26:08 --> URI Class Initialized
INFO - 2018-03-28 13:26:08 --> Router Class Initialized
INFO - 2018-03-28 13:26:08 --> Output Class Initialized
INFO - 2018-03-28 13:26:08 --> Security Class Initialized
DEBUG - 2018-03-28 13:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 13:26:08 --> Input Class Initialized
INFO - 2018-03-28 13:26:08 --> Language Class Initialized
INFO - 2018-03-28 13:26:08 --> Language Class Initialized
INFO - 2018-03-28 13:26:08 --> Config Class Initialized
INFO - 2018-03-28 13:26:08 --> Loader Class Initialized
INFO - 2018-03-28 18:56:08 --> Helper loaded: url_helper
INFO - 2018-03-28 18:56:08 --> Helper loaded: notification_helper
INFO - 2018-03-28 18:56:08 --> Helper loaded: settings_helper
INFO - 2018-03-28 18:56:08 --> Helper loaded: permission_helper
INFO - 2018-03-28 18:56:08 --> Helper loaded: users_helper
INFO - 2018-03-28 18:56:08 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:56:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:56:08 --> Helper loaded: form_helper
INFO - 2018-03-28 18:56:08 --> Form Validation Class Initialized
INFO - 2018-03-28 18:56:08 --> Controller Class Initialized
INFO - 2018-03-28 18:56:08 --> Model Class Initialized
INFO - 2018-03-28 18:56:08 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 18:56:08 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 18:56:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 18:56:08 --> Model Class Initialized
INFO - 2018-03-28 18:56:08 --> Model Class Initialized
INFO - 2018-03-28 18:56:08 --> Model Class Initialized
INFO - 2018-03-28 18:56:08 --> Model Class Initialized
INFO - 2018-03-28 18:56:08 --> Model Class Initialized
INFO - 2018-03-28 18:56:08 --> Model Class Initialized
INFO - 2018-03-28 18:56:08 --> Model Class Initialized
INFO - 2018-03-28 18:56:08 --> Model Class Initialized
INFO - 2018-03-28 18:56:08 --> Model Class Initialized
INFO - 2018-03-28 18:56:08 --> Model Class Initialized
INFO - 2018-03-28 18:56:08 --> Model Class Initialized
INFO - 2018-03-28 18:56:08 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 18:56:08 --> Model Class Initialized
INFO - 2018-03-28 18:56:08 --> Final output sent to browser
DEBUG - 2018-03-28 18:56:08 --> Total execution time: 0.2626
INFO - 2018-03-28 13:26:09 --> Config Class Initialized
INFO - 2018-03-28 13:26:09 --> Hooks Class Initialized
DEBUG - 2018-03-28 13:26:09 --> UTF-8 Support Enabled
INFO - 2018-03-28 13:26:09 --> Utf8 Class Initialized
INFO - 2018-03-28 13:26:09 --> URI Class Initialized
INFO - 2018-03-28 13:26:09 --> Router Class Initialized
INFO - 2018-03-28 13:26:09 --> Output Class Initialized
INFO - 2018-03-28 13:26:09 --> Security Class Initialized
DEBUG - 2018-03-28 13:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 13:26:09 --> Input Class Initialized
INFO - 2018-03-28 13:26:09 --> Language Class Initialized
INFO - 2018-03-28 13:26:10 --> Language Class Initialized
INFO - 2018-03-28 13:26:10 --> Config Class Initialized
INFO - 2018-03-28 13:26:10 --> Loader Class Initialized
INFO - 2018-03-28 18:56:10 --> Helper loaded: url_helper
INFO - 2018-03-28 18:56:10 --> Helper loaded: notification_helper
INFO - 2018-03-28 18:56:10 --> Helper loaded: settings_helper
INFO - 2018-03-28 18:56:10 --> Helper loaded: permission_helper
INFO - 2018-03-28 18:56:10 --> Helper loaded: users_helper
INFO - 2018-03-28 18:56:10 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:56:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:56:10 --> Helper loaded: form_helper
INFO - 2018-03-28 18:56:10 --> Form Validation Class Initialized
INFO - 2018-03-28 18:56:10 --> Controller Class Initialized
INFO - 2018-03-28 18:56:10 --> Model Class Initialized
INFO - 2018-03-28 18:56:10 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 18:56:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 18:56:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 18:56:10 --> Model Class Initialized
INFO - 2018-03-28 18:56:10 --> Model Class Initialized
INFO - 2018-03-28 18:56:10 --> Model Class Initialized
INFO - 2018-03-28 18:56:10 --> Model Class Initialized
INFO - 2018-03-28 18:56:10 --> Model Class Initialized
INFO - 2018-03-28 18:56:10 --> Model Class Initialized
INFO - 2018-03-28 18:56:10 --> Model Class Initialized
INFO - 2018-03-28 18:56:10 --> Model Class Initialized
INFO - 2018-03-28 18:56:10 --> Model Class Initialized
INFO - 2018-03-28 18:56:10 --> Model Class Initialized
INFO - 2018-03-28 18:56:10 --> Model Class Initialized
INFO - 2018-03-28 18:56:10 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 18:56:10 --> Final output sent to browser
DEBUG - 2018-03-28 18:56:10 --> Total execution time: 1.2852
INFO - 2018-03-28 13:26:11 --> Config Class Initialized
INFO - 2018-03-28 13:26:11 --> Hooks Class Initialized
DEBUG - 2018-03-28 13:26:11 --> UTF-8 Support Enabled
INFO - 2018-03-28 13:26:11 --> Utf8 Class Initialized
INFO - 2018-03-28 13:26:11 --> URI Class Initialized
INFO - 2018-03-28 13:26:12 --> Router Class Initialized
INFO - 2018-03-28 13:26:12 --> Output Class Initialized
INFO - 2018-03-28 13:26:12 --> Security Class Initialized
DEBUG - 2018-03-28 13:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 13:26:12 --> Input Class Initialized
INFO - 2018-03-28 13:26:12 --> Language Class Initialized
INFO - 2018-03-28 13:26:12 --> Language Class Initialized
INFO - 2018-03-28 13:26:12 --> Config Class Initialized
INFO - 2018-03-28 13:26:12 --> Loader Class Initialized
INFO - 2018-03-28 18:56:12 --> Helper loaded: url_helper
INFO - 2018-03-28 18:56:12 --> Helper loaded: notification_helper
INFO - 2018-03-28 18:56:12 --> Helper loaded: settings_helper
INFO - 2018-03-28 18:56:12 --> Helper loaded: permission_helper
INFO - 2018-03-28 18:56:12 --> Helper loaded: users_helper
INFO - 2018-03-28 18:56:13 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:56:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:56:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:56:13 --> Helper loaded: form_helper
INFO - 2018-03-28 18:56:13 --> Form Validation Class Initialized
INFO - 2018-03-28 18:56:13 --> Controller Class Initialized
INFO - 2018-03-28 18:56:13 --> Model Class Initialized
INFO - 2018-03-28 18:56:13 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 18:56:13 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 18:56:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 18:56:13 --> Model Class Initialized
INFO - 2018-03-28 18:56:13 --> Model Class Initialized
INFO - 2018-03-28 18:56:13 --> Model Class Initialized
INFO - 2018-03-28 18:56:13 --> Model Class Initialized
INFO - 2018-03-28 18:56:13 --> Model Class Initialized
INFO - 2018-03-28 18:56:13 --> Model Class Initialized
INFO - 2018-03-28 18:56:13 --> Model Class Initialized
INFO - 2018-03-28 18:56:13 --> Model Class Initialized
INFO - 2018-03-28 18:56:13 --> Model Class Initialized
INFO - 2018-03-28 18:56:13 --> Model Class Initialized
INFO - 2018-03-28 18:56:13 --> Model Class Initialized
INFO - 2018-03-28 18:56:13 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 18:56:13 --> Final output sent to browser
DEBUG - 2018-03-28 18:56:13 --> Total execution time: 2.3226
INFO - 2018-03-28 13:27:32 --> Config Class Initialized
INFO - 2018-03-28 13:27:32 --> Hooks Class Initialized
DEBUG - 2018-03-28 13:27:32 --> UTF-8 Support Enabled
INFO - 2018-03-28 13:27:32 --> Utf8 Class Initialized
INFO - 2018-03-28 13:27:32 --> URI Class Initialized
INFO - 2018-03-28 13:27:32 --> Router Class Initialized
INFO - 2018-03-28 13:27:32 --> Output Class Initialized
INFO - 2018-03-28 13:27:32 --> Security Class Initialized
DEBUG - 2018-03-28 13:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 13:27:32 --> Input Class Initialized
INFO - 2018-03-28 13:27:32 --> Language Class Initialized
INFO - 2018-03-28 13:27:32 --> Language Class Initialized
INFO - 2018-03-28 13:27:32 --> Config Class Initialized
INFO - 2018-03-28 13:27:32 --> Loader Class Initialized
INFO - 2018-03-28 18:57:32 --> Helper loaded: url_helper
INFO - 2018-03-28 18:57:32 --> Helper loaded: notification_helper
INFO - 2018-03-28 18:57:32 --> Helper loaded: settings_helper
INFO - 2018-03-28 18:57:32 --> Helper loaded: permission_helper
INFO - 2018-03-28 18:57:32 --> Helper loaded: users_helper
INFO - 2018-03-28 18:57:32 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:57:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:57:32 --> Helper loaded: form_helper
INFO - 2018-03-28 18:57:32 --> Form Validation Class Initialized
INFO - 2018-03-28 18:57:32 --> Controller Class Initialized
INFO - 2018-03-28 18:57:32 --> Model Class Initialized
INFO - 2018-03-28 18:57:32 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 18:57:32 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 18:57:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 18:57:32 --> Model Class Initialized
INFO - 2018-03-28 18:57:32 --> Model Class Initialized
INFO - 2018-03-28 18:57:32 --> Model Class Initialized
INFO - 2018-03-28 18:57:32 --> Model Class Initialized
INFO - 2018-03-28 18:57:32 --> Model Class Initialized
INFO - 2018-03-28 18:57:32 --> Model Class Initialized
INFO - 2018-03-28 18:57:32 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 18:57:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-28 18:57:33 --> Final output sent to browser
DEBUG - 2018-03-28 18:57:33 --> Total execution time: 0.6346
INFO - 2018-03-28 13:27:34 --> Config Class Initialized
INFO - 2018-03-28 13:27:34 --> Hooks Class Initialized
DEBUG - 2018-03-28 13:27:34 --> UTF-8 Support Enabled
INFO - 2018-03-28 13:27:34 --> Utf8 Class Initialized
INFO - 2018-03-28 13:27:34 --> URI Class Initialized
INFO - 2018-03-28 13:27:34 --> Router Class Initialized
INFO - 2018-03-28 13:27:34 --> Output Class Initialized
INFO - 2018-03-28 13:27:34 --> Security Class Initialized
DEBUG - 2018-03-28 13:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 13:27:34 --> Input Class Initialized
INFO - 2018-03-28 13:27:34 --> Language Class Initialized
INFO - 2018-03-28 13:27:34 --> Language Class Initialized
INFO - 2018-03-28 13:27:34 --> Config Class Initialized
INFO - 2018-03-28 13:27:34 --> Loader Class Initialized
INFO - 2018-03-28 18:57:34 --> Helper loaded: url_helper
INFO - 2018-03-28 18:57:34 --> Helper loaded: notification_helper
INFO - 2018-03-28 18:57:34 --> Helper loaded: settings_helper
INFO - 2018-03-28 18:57:34 --> Helper loaded: permission_helper
INFO - 2018-03-28 18:57:34 --> Helper loaded: users_helper
INFO - 2018-03-28 18:57:34 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:57:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:57:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:57:34 --> Helper loaded: form_helper
INFO - 2018-03-28 18:57:34 --> Form Validation Class Initialized
INFO - 2018-03-28 18:57:34 --> Controller Class Initialized
INFO - 2018-03-28 18:57:34 --> Model Class Initialized
INFO - 2018-03-28 18:57:34 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 18:57:34 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 18:57:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 18:57:34 --> Model Class Initialized
INFO - 2018-03-28 18:57:34 --> Model Class Initialized
INFO - 2018-03-28 18:57:34 --> Model Class Initialized
INFO - 2018-03-28 18:57:34 --> Model Class Initialized
INFO - 2018-03-28 18:57:34 --> Model Class Initialized
INFO - 2018-03-28 18:57:34 --> Model Class Initialized
INFO - 2018-03-28 18:57:34 --> Model Class Initialized
INFO - 2018-03-28 18:57:34 --> Model Class Initialized
INFO - 2018-03-28 18:57:34 --> Model Class Initialized
INFO - 2018-03-28 18:57:34 --> Model Class Initialized
INFO - 2018-03-28 18:57:34 --> Model Class Initialized
INFO - 2018-03-28 18:57:34 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 18:57:34 --> Model Class Initialized
INFO - 2018-03-28 18:57:34 --> Final output sent to browser
DEBUG - 2018-03-28 18:57:34 --> Total execution time: 0.1347
INFO - 2018-03-28 13:27:34 --> Config Class Initialized
INFO - 2018-03-28 13:27:34 --> Hooks Class Initialized
DEBUG - 2018-03-28 13:27:34 --> UTF-8 Support Enabled
INFO - 2018-03-28 13:27:34 --> Utf8 Class Initialized
INFO - 2018-03-28 13:27:34 --> URI Class Initialized
INFO - 2018-03-28 13:27:34 --> Router Class Initialized
INFO - 2018-03-28 13:27:34 --> Output Class Initialized
INFO - 2018-03-28 13:27:34 --> Security Class Initialized
DEBUG - 2018-03-28 13:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 13:27:34 --> Input Class Initialized
INFO - 2018-03-28 13:27:34 --> Language Class Initialized
INFO - 2018-03-28 13:27:34 --> Language Class Initialized
INFO - 2018-03-28 13:27:34 --> Config Class Initialized
INFO - 2018-03-28 13:27:34 --> Loader Class Initialized
INFO - 2018-03-28 18:57:34 --> Helper loaded: url_helper
INFO - 2018-03-28 18:57:34 --> Helper loaded: notification_helper
INFO - 2018-03-28 18:57:34 --> Helper loaded: settings_helper
INFO - 2018-03-28 18:57:34 --> Helper loaded: permission_helper
INFO - 2018-03-28 18:57:34 --> Helper loaded: users_helper
INFO - 2018-03-28 18:57:34 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:57:35 --> Helper loaded: form_helper
INFO - 2018-03-28 18:57:35 --> Form Validation Class Initialized
INFO - 2018-03-28 18:57:35 --> Controller Class Initialized
INFO - 2018-03-28 18:57:35 --> Model Class Initialized
INFO - 2018-03-28 18:57:35 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 18:57:35 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 18:57:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 18:57:35 --> Model Class Initialized
INFO - 2018-03-28 18:57:35 --> Model Class Initialized
INFO - 2018-03-28 18:57:36 --> Model Class Initialized
INFO - 2018-03-28 18:57:36 --> Model Class Initialized
INFO - 2018-03-28 18:57:36 --> Model Class Initialized
INFO - 2018-03-28 18:57:36 --> Model Class Initialized
INFO - 2018-03-28 18:57:36 --> Model Class Initialized
INFO - 2018-03-28 18:57:36 --> Model Class Initialized
INFO - 2018-03-28 18:57:36 --> Model Class Initialized
INFO - 2018-03-28 18:57:36 --> Model Class Initialized
INFO - 2018-03-28 18:57:36 --> Model Class Initialized
INFO - 2018-03-28 18:57:36 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 18:57:36 --> Model Class Initialized
INFO - 2018-03-28 18:57:36 --> Final output sent to browser
DEBUG - 2018-03-28 18:57:36 --> Total execution time: 1.8513
INFO - 2018-03-28 13:27:38 --> Config Class Initialized
INFO - 2018-03-28 13:27:38 --> Hooks Class Initialized
DEBUG - 2018-03-28 13:27:39 --> UTF-8 Support Enabled
INFO - 2018-03-28 13:27:39 --> Utf8 Class Initialized
INFO - 2018-03-28 13:27:39 --> URI Class Initialized
INFO - 2018-03-28 13:27:39 --> Router Class Initialized
INFO - 2018-03-28 13:27:39 --> Output Class Initialized
INFO - 2018-03-28 13:27:39 --> Security Class Initialized
DEBUG - 2018-03-28 13:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 13:27:39 --> Input Class Initialized
INFO - 2018-03-28 13:27:39 --> Language Class Initialized
INFO - 2018-03-28 13:27:40 --> Language Class Initialized
INFO - 2018-03-28 13:27:40 --> Config Class Initialized
INFO - 2018-03-28 13:27:40 --> Loader Class Initialized
INFO - 2018-03-28 18:57:40 --> Helper loaded: url_helper
INFO - 2018-03-28 18:57:40 --> Helper loaded: notification_helper
INFO - 2018-03-28 18:57:40 --> Helper loaded: settings_helper
INFO - 2018-03-28 18:57:40 --> Helper loaded: permission_helper
INFO - 2018-03-28 18:57:40 --> Helper loaded: users_helper
INFO - 2018-03-28 18:57:40 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:57:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:57:40 --> Helper loaded: form_helper
INFO - 2018-03-28 18:57:40 --> Form Validation Class Initialized
INFO - 2018-03-28 18:57:40 --> Controller Class Initialized
INFO - 2018-03-28 18:57:40 --> Model Class Initialized
INFO - 2018-03-28 18:57:40 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 18:57:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 18:57:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 18:57:40 --> Model Class Initialized
INFO - 2018-03-28 18:57:40 --> Model Class Initialized
INFO - 2018-03-28 18:57:40 --> Model Class Initialized
INFO - 2018-03-28 18:57:40 --> Model Class Initialized
INFO - 2018-03-28 18:57:40 --> Model Class Initialized
INFO - 2018-03-28 18:57:40 --> Model Class Initialized
INFO - 2018-03-28 18:57:40 --> Model Class Initialized
INFO - 2018-03-28 18:57:40 --> Model Class Initialized
INFO - 2018-03-28 18:57:40 --> Model Class Initialized
INFO - 2018-03-28 18:57:40 --> Model Class Initialized
INFO - 2018-03-28 18:57:40 --> Model Class Initialized
INFO - 2018-03-28 18:57:40 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 18:57:40 --> Model Class Initialized
INFO - 2018-03-28 18:57:40 --> Final output sent to browser
DEBUG - 2018-03-28 18:57:40 --> Total execution time: 2.0684
INFO - 2018-03-28 13:27:46 --> Config Class Initialized
INFO - 2018-03-28 13:27:46 --> Hooks Class Initialized
DEBUG - 2018-03-28 13:27:46 --> UTF-8 Support Enabled
INFO - 2018-03-28 13:27:46 --> Utf8 Class Initialized
INFO - 2018-03-28 13:27:46 --> URI Class Initialized
INFO - 2018-03-28 13:27:46 --> Config Class Initialized
INFO - 2018-03-28 13:27:46 --> Hooks Class Initialized
INFO - 2018-03-28 13:27:46 --> Router Class Initialized
INFO - 2018-03-28 13:27:46 --> Output Class Initialized
INFO - 2018-03-28 13:27:46 --> Security Class Initialized
DEBUG - 2018-03-28 13:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 13:27:46 --> Input Class Initialized
INFO - 2018-03-28 13:27:46 --> Language Class Initialized
DEBUG - 2018-03-28 13:27:46 --> UTF-8 Support Enabled
INFO - 2018-03-28 13:27:46 --> Utf8 Class Initialized
INFO - 2018-03-28 13:27:46 --> Language Class Initialized
INFO - 2018-03-28 13:27:46 --> Config Class Initialized
INFO - 2018-03-28 13:27:46 --> Loader Class Initialized
INFO - 2018-03-28 13:27:46 --> URI Class Initialized
INFO - 2018-03-28 18:57:46 --> Helper loaded: url_helper
INFO - 2018-03-28 18:57:46 --> Helper loaded: notification_helper
INFO - 2018-03-28 18:57:46 --> Helper loaded: settings_helper
INFO - 2018-03-28 18:57:46 --> Helper loaded: permission_helper
INFO - 2018-03-28 18:57:46 --> Helper loaded: users_helper
INFO - 2018-03-28 18:57:46 --> Database Driver Class Initialized
INFO - 2018-03-28 13:27:46 --> Router Class Initialized
DEBUG - 2018-03-28 18:57:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:57:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:57:46 --> Helper loaded: form_helper
INFO - 2018-03-28 18:57:46 --> Form Validation Class Initialized
INFO - 2018-03-28 18:57:46 --> Controller Class Initialized
INFO - 2018-03-28 18:57:46 --> Model Class Initialized
INFO - 2018-03-28 18:57:46 --> Helper loaded: inflector_helper
INFO - 2018-03-28 13:27:46 --> Output Class Initialized
DEBUG - 2018-03-28 18:57:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 18:57:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 18:57:46 --> Model Class Initialized
INFO - 2018-03-28 18:57:46 --> Model Class Initialized
INFO - 2018-03-28 18:57:46 --> Model Class Initialized
INFO - 2018-03-28 18:57:46 --> Model Class Initialized
INFO - 2018-03-28 18:57:46 --> Model Class Initialized
INFO - 2018-03-28 18:57:46 --> Model Class Initialized
INFO - 2018-03-28 18:57:46 --> Model Class Initialized
INFO - 2018-03-28 18:57:46 --> Model Class Initialized
INFO - 2018-03-28 18:57:46 --> Model Class Initialized
INFO - 2018-03-28 18:57:46 --> Model Class Initialized
INFO - 2018-03-28 18:57:46 --> Model Class Initialized
INFO - 2018-03-28 18:57:46 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 18:57:46 --> Model Class Initialized
INFO - 2018-03-28 13:27:46 --> Security Class Initialized
INFO - 2018-03-28 18:57:46 --> Final output sent to browser
DEBUG - 2018-03-28 18:57:46 --> Total execution time: 0.1183
DEBUG - 2018-03-28 13:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 13:27:46 --> Input Class Initialized
INFO - 2018-03-28 13:27:46 --> Language Class Initialized
INFO - 2018-03-28 13:27:46 --> Language Class Initialized
INFO - 2018-03-28 13:27:46 --> Config Class Initialized
INFO - 2018-03-28 13:27:46 --> Loader Class Initialized
INFO - 2018-03-28 18:57:46 --> Helper loaded: url_helper
INFO - 2018-03-28 18:57:46 --> Helper loaded: notification_helper
INFO - 2018-03-28 18:57:46 --> Helper loaded: settings_helper
INFO - 2018-03-28 18:57:46 --> Helper loaded: permission_helper
INFO - 2018-03-28 18:57:46 --> Helper loaded: users_helper
INFO - 2018-03-28 18:57:46 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:57:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:57:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:57:47 --> Helper loaded: form_helper
INFO - 2018-03-28 18:57:47 --> Form Validation Class Initialized
INFO - 2018-03-28 18:57:47 --> Controller Class Initialized
INFO - 2018-03-28 18:57:47 --> Model Class Initialized
INFO - 2018-03-28 18:57:47 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 18:57:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 18:57:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 18:57:47 --> Model Class Initialized
INFO - 2018-03-28 18:57:47 --> Model Class Initialized
INFO - 2018-03-28 18:57:47 --> Model Class Initialized
INFO - 2018-03-28 18:57:47 --> Model Class Initialized
INFO - 2018-03-28 18:57:47 --> Model Class Initialized
INFO - 2018-03-28 18:57:47 --> Model Class Initialized
INFO - 2018-03-28 18:57:47 --> Model Class Initialized
INFO - 2018-03-28 18:57:47 --> Model Class Initialized
INFO - 2018-03-28 18:57:47 --> Model Class Initialized
INFO - 2018-03-28 18:57:47 --> Model Class Initialized
INFO - 2018-03-28 18:57:47 --> Model Class Initialized
INFO - 2018-03-28 18:57:47 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 18:57:47 --> Final output sent to browser
DEBUG - 2018-03-28 18:57:47 --> Total execution time: 0.5710
INFO - 2018-03-28 13:27:51 --> Config Class Initialized
INFO - 2018-03-28 13:27:51 --> Hooks Class Initialized
DEBUG - 2018-03-28 13:27:51 --> UTF-8 Support Enabled
INFO - 2018-03-28 13:27:51 --> Utf8 Class Initialized
INFO - 2018-03-28 13:27:51 --> URI Class Initialized
INFO - 2018-03-28 13:27:51 --> Router Class Initialized
INFO - 2018-03-28 13:27:51 --> Output Class Initialized
INFO - 2018-03-28 13:27:51 --> Security Class Initialized
DEBUG - 2018-03-28 13:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 13:27:51 --> Input Class Initialized
INFO - 2018-03-28 13:27:51 --> Language Class Initialized
INFO - 2018-03-28 13:27:51 --> Language Class Initialized
INFO - 2018-03-28 13:27:51 --> Config Class Initialized
INFO - 2018-03-28 13:27:51 --> Loader Class Initialized
INFO - 2018-03-28 18:57:51 --> Helper loaded: url_helper
INFO - 2018-03-28 18:57:51 --> Helper loaded: notification_helper
INFO - 2018-03-28 18:57:51 --> Helper loaded: settings_helper
INFO - 2018-03-28 18:57:51 --> Helper loaded: permission_helper
INFO - 2018-03-28 18:57:51 --> Helper loaded: users_helper
INFO - 2018-03-28 18:57:51 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:57:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:57:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:57:51 --> Helper loaded: form_helper
INFO - 2018-03-28 18:57:51 --> Form Validation Class Initialized
INFO - 2018-03-28 18:57:51 --> Controller Class Initialized
INFO - 2018-03-28 18:57:51 --> Model Class Initialized
INFO - 2018-03-28 18:57:52 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 18:57:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 18:57:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 18:57:52 --> Model Class Initialized
INFO - 2018-03-28 18:57:52 --> Model Class Initialized
INFO - 2018-03-28 18:57:52 --> Model Class Initialized
INFO - 2018-03-28 18:57:52 --> Model Class Initialized
INFO - 2018-03-28 18:57:52 --> Model Class Initialized
INFO - 2018-03-28 18:57:52 --> Model Class Initialized
INFO - 2018-03-28 18:57:52 --> Model Class Initialized
INFO - 2018-03-28 18:57:52 --> Model Class Initialized
INFO - 2018-03-28 18:57:52 --> Model Class Initialized
INFO - 2018-03-28 18:57:52 --> Model Class Initialized
INFO - 2018-03-28 18:57:52 --> Model Class Initialized
INFO - 2018-03-28 18:57:52 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 18:57:52 --> Final output sent to browser
DEBUG - 2018-03-28 18:57:52 --> Total execution time: 1.2535
INFO - 2018-03-28 13:50:29 --> Config Class Initialized
INFO - 2018-03-28 13:50:29 --> Hooks Class Initialized
DEBUG - 2018-03-28 13:50:29 --> UTF-8 Support Enabled
INFO - 2018-03-28 13:50:29 --> Utf8 Class Initialized
INFO - 2018-03-28 13:50:29 --> URI Class Initialized
INFO - 2018-03-28 13:50:29 --> Router Class Initialized
INFO - 2018-03-28 13:50:30 --> Output Class Initialized
INFO - 2018-03-28 13:50:30 --> Security Class Initialized
DEBUG - 2018-03-28 13:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 13:50:30 --> Input Class Initialized
INFO - 2018-03-28 13:50:30 --> Language Class Initialized
INFO - 2018-03-28 13:50:30 --> Language Class Initialized
INFO - 2018-03-28 13:50:30 --> Config Class Initialized
INFO - 2018-03-28 13:50:30 --> Loader Class Initialized
INFO - 2018-03-28 19:20:30 --> Helper loaded: url_helper
INFO - 2018-03-28 19:20:30 --> Helper loaded: notification_helper
INFO - 2018-03-28 19:20:30 --> Helper loaded: settings_helper
INFO - 2018-03-28 19:20:30 --> Helper loaded: permission_helper
INFO - 2018-03-28 19:20:30 --> Helper loaded: users_helper
INFO - 2018-03-28 19:20:31 --> Database Driver Class Initialized
DEBUG - 2018-03-28 19:20:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 19:20:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 19:20:31 --> Helper loaded: form_helper
INFO - 2018-03-28 19:20:31 --> Form Validation Class Initialized
INFO - 2018-03-28 19:20:31 --> Controller Class Initialized
INFO - 2018-03-28 19:20:31 --> Model Class Initialized
INFO - 2018-03-28 19:20:31 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 19:20:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 19:20:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 19:20:31 --> Model Class Initialized
INFO - 2018-03-28 19:20:31 --> Model Class Initialized
INFO - 2018-03-28 19:20:31 --> Model Class Initialized
INFO - 2018-03-28 19:20:31 --> Model Class Initialized
INFO - 2018-03-28 19:20:31 --> Model Class Initialized
INFO - 2018-03-28 19:20:31 --> Model Class Initialized
INFO - 2018-03-28 19:20:31 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 19:20:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-28 19:20:31 --> Final output sent to browser
DEBUG - 2018-03-28 19:20:31 --> Total execution time: 1.9127
INFO - 2018-03-28 13:50:33 --> Config Class Initialized
INFO - 2018-03-28 13:50:33 --> Hooks Class Initialized
DEBUG - 2018-03-28 13:50:33 --> UTF-8 Support Enabled
INFO - 2018-03-28 13:50:33 --> Utf8 Class Initialized
INFO - 2018-03-28 13:50:33 --> URI Class Initialized
INFO - 2018-03-28 13:50:33 --> Router Class Initialized
INFO - 2018-03-28 13:50:33 --> Output Class Initialized
INFO - 2018-03-28 13:50:33 --> Security Class Initialized
DEBUG - 2018-03-28 13:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 13:50:33 --> Input Class Initialized
INFO - 2018-03-28 13:50:33 --> Language Class Initialized
INFO - 2018-03-28 13:50:33 --> Config Class Initialized
INFO - 2018-03-28 13:50:33 --> Hooks Class Initialized
DEBUG - 2018-03-28 13:50:33 --> UTF-8 Support Enabled
INFO - 2018-03-28 13:50:33 --> Utf8 Class Initialized
INFO - 2018-03-28 13:50:33 --> URI Class Initialized
INFO - 2018-03-28 13:50:33 --> Router Class Initialized
INFO - 2018-03-28 13:50:33 --> Output Class Initialized
INFO - 2018-03-28 13:50:33 --> Security Class Initialized
DEBUG - 2018-03-28 13:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 13:50:33 --> Input Class Initialized
INFO - 2018-03-28 13:50:33 --> Language Class Initialized
INFO - 2018-03-28 13:50:33 --> Language Class Initialized
INFO - 2018-03-28 13:50:33 --> Config Class Initialized
INFO - 2018-03-28 13:50:33 --> Loader Class Initialized
INFO - 2018-03-28 19:20:33 --> Helper loaded: url_helper
INFO - 2018-03-28 19:20:33 --> Helper loaded: notification_helper
INFO - 2018-03-28 19:20:33 --> Helper loaded: settings_helper
INFO - 2018-03-28 19:20:33 --> Helper loaded: permission_helper
INFO - 2018-03-28 19:20:33 --> Helper loaded: users_helper
INFO - 2018-03-28 19:20:33 --> Database Driver Class Initialized
DEBUG - 2018-03-28 19:20:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 19:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 19:20:33 --> Helper loaded: form_helper
INFO - 2018-03-28 19:20:33 --> Form Validation Class Initialized
INFO - 2018-03-28 19:20:33 --> Controller Class Initialized
INFO - 2018-03-28 19:20:33 --> Model Class Initialized
INFO - 2018-03-28 19:20:33 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 19:20:33 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 19:20:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 19:20:33 --> Model Class Initialized
INFO - 2018-03-28 19:20:33 --> Model Class Initialized
INFO - 2018-03-28 19:20:33 --> Model Class Initialized
INFO - 2018-03-28 19:20:33 --> Model Class Initialized
INFO - 2018-03-28 19:20:33 --> Model Class Initialized
INFO - 2018-03-28 19:20:33 --> Model Class Initialized
INFO - 2018-03-28 19:20:33 --> Model Class Initialized
INFO - 2018-03-28 19:20:33 --> Model Class Initialized
INFO - 2018-03-28 19:20:33 --> Model Class Initialized
INFO - 2018-03-28 19:20:33 --> Model Class Initialized
INFO - 2018-03-28 19:20:33 --> Model Class Initialized
INFO - 2018-03-28 19:20:33 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 19:20:33 --> Model Class Initialized
INFO - 2018-03-28 19:20:33 --> Final output sent to browser
DEBUG - 2018-03-28 19:20:33 --> Total execution time: 0.1272
INFO - 2018-03-28 13:50:33 --> Language Class Initialized
INFO - 2018-03-28 13:50:33 --> Config Class Initialized
INFO - 2018-03-28 13:50:33 --> Loader Class Initialized
INFO - 2018-03-28 19:20:33 --> Helper loaded: url_helper
INFO - 2018-03-28 19:20:33 --> Helper loaded: notification_helper
INFO - 2018-03-28 19:20:33 --> Helper loaded: settings_helper
INFO - 2018-03-28 19:20:33 --> Helper loaded: permission_helper
INFO - 2018-03-28 19:20:33 --> Helper loaded: users_helper
INFO - 2018-03-28 19:20:34 --> Database Driver Class Initialized
DEBUG - 2018-03-28 19:20:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 19:20:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 19:20:34 --> Helper loaded: form_helper
INFO - 2018-03-28 19:20:34 --> Form Validation Class Initialized
INFO - 2018-03-28 19:20:34 --> Controller Class Initialized
INFO - 2018-03-28 19:20:34 --> Model Class Initialized
INFO - 2018-03-28 19:20:34 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 19:20:34 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 19:20:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 19:20:34 --> Model Class Initialized
INFO - 2018-03-28 19:20:34 --> Model Class Initialized
INFO - 2018-03-28 19:20:34 --> Model Class Initialized
INFO - 2018-03-28 19:20:34 --> Model Class Initialized
INFO - 2018-03-28 19:20:34 --> Model Class Initialized
INFO - 2018-03-28 19:20:34 --> Model Class Initialized
INFO - 2018-03-28 19:20:34 --> Model Class Initialized
INFO - 2018-03-28 19:20:34 --> Model Class Initialized
INFO - 2018-03-28 19:20:34 --> Model Class Initialized
INFO - 2018-03-28 19:20:34 --> Model Class Initialized
INFO - 2018-03-28 19:20:34 --> Model Class Initialized
INFO - 2018-03-28 19:20:34 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 19:20:34 --> Model Class Initialized
INFO - 2018-03-28 19:20:34 --> Final output sent to browser
DEBUG - 2018-03-28 19:20:34 --> Total execution time: 0.9546
INFO - 2018-03-28 13:50:36 --> Config Class Initialized
INFO - 2018-03-28 13:50:36 --> Hooks Class Initialized
DEBUG - 2018-03-28 13:50:36 --> UTF-8 Support Enabled
INFO - 2018-03-28 13:50:36 --> Utf8 Class Initialized
INFO - 2018-03-28 13:50:36 --> URI Class Initialized
INFO - 2018-03-28 13:50:36 --> Router Class Initialized
INFO - 2018-03-28 13:50:36 --> Output Class Initialized
INFO - 2018-03-28 13:50:36 --> Security Class Initialized
DEBUG - 2018-03-28 13:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 13:50:36 --> Input Class Initialized
INFO - 2018-03-28 13:50:36 --> Language Class Initialized
INFO - 2018-03-28 13:50:36 --> Language Class Initialized
INFO - 2018-03-28 13:50:36 --> Config Class Initialized
INFO - 2018-03-28 13:50:36 --> Loader Class Initialized
INFO - 2018-03-28 19:20:36 --> Helper loaded: url_helper
INFO - 2018-03-28 19:20:36 --> Helper loaded: notification_helper
INFO - 2018-03-28 19:20:36 --> Helper loaded: settings_helper
INFO - 2018-03-28 19:20:36 --> Helper loaded: permission_helper
INFO - 2018-03-28 19:20:36 --> Helper loaded: users_helper
INFO - 2018-03-28 19:20:36 --> Database Driver Class Initialized
DEBUG - 2018-03-28 19:20:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 19:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 19:20:36 --> Helper loaded: form_helper
INFO - 2018-03-28 19:20:36 --> Form Validation Class Initialized
INFO - 2018-03-28 19:20:36 --> Controller Class Initialized
INFO - 2018-03-28 13:50:36 --> Config Class Initialized
INFO - 2018-03-28 13:50:36 --> Hooks Class Initialized
DEBUG - 2018-03-28 13:50:36 --> UTF-8 Support Enabled
INFO - 2018-03-28 13:50:36 --> Utf8 Class Initialized
INFO - 2018-03-28 19:20:36 --> Model Class Initialized
INFO - 2018-03-28 19:20:36 --> Helper loaded: inflector_helper
INFO - 2018-03-28 13:50:36 --> URI Class Initialized
DEBUG - 2018-03-28 19:20:36 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 19:20:36 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 19:20:36 --> Model Class Initialized
INFO - 2018-03-28 19:20:36 --> Model Class Initialized
INFO - 2018-03-28 19:20:36 --> Model Class Initialized
INFO - 2018-03-28 19:20:36 --> Model Class Initialized
INFO - 2018-03-28 13:50:36 --> Router Class Initialized
INFO - 2018-03-28 19:20:36 --> Model Class Initialized
INFO - 2018-03-28 19:20:36 --> Model Class Initialized
INFO - 2018-03-28 19:20:36 --> Model Class Initialized
INFO - 2018-03-28 19:20:36 --> Model Class Initialized
INFO - 2018-03-28 19:20:36 --> Model Class Initialized
INFO - 2018-03-28 19:20:36 --> Model Class Initialized
INFO - 2018-03-28 13:50:36 --> Output Class Initialized
INFO - 2018-03-28 19:20:36 --> Model Class Initialized
INFO - 2018-03-28 19:20:36 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 19:20:36 --> Model Class Initialized
INFO - 2018-03-28 13:50:36 --> Security Class Initialized
DEBUG - 2018-03-28 13:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 13:50:36 --> Input Class Initialized
INFO - 2018-03-28 19:20:36 --> Final output sent to browser
DEBUG - 2018-03-28 19:20:36 --> Total execution time: 0.2397
INFO - 2018-03-28 13:50:36 --> Language Class Initialized
INFO - 2018-03-28 13:50:36 --> Language Class Initialized
INFO - 2018-03-28 13:50:36 --> Config Class Initialized
INFO - 2018-03-28 13:50:36 --> Loader Class Initialized
INFO - 2018-03-28 19:20:36 --> Helper loaded: url_helper
INFO - 2018-03-28 19:20:36 --> Helper loaded: notification_helper
INFO - 2018-03-28 19:20:36 --> Helper loaded: settings_helper
INFO - 2018-03-28 19:20:36 --> Helper loaded: permission_helper
INFO - 2018-03-28 19:20:36 --> Helper loaded: users_helper
INFO - 2018-03-28 19:20:36 --> Database Driver Class Initialized
DEBUG - 2018-03-28 19:20:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 19:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 19:20:36 --> Helper loaded: form_helper
INFO - 2018-03-28 19:20:36 --> Form Validation Class Initialized
INFO - 2018-03-28 19:20:36 --> Controller Class Initialized
INFO - 2018-03-28 19:20:36 --> Model Class Initialized
INFO - 2018-03-28 19:20:36 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 19:20:36 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 19:20:36 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 19:20:36 --> Model Class Initialized
INFO - 2018-03-28 19:20:36 --> Model Class Initialized
INFO - 2018-03-28 19:20:36 --> Model Class Initialized
INFO - 2018-03-28 19:20:36 --> Model Class Initialized
INFO - 2018-03-28 19:20:36 --> Model Class Initialized
INFO - 2018-03-28 19:20:36 --> Model Class Initialized
INFO - 2018-03-28 19:20:36 --> Model Class Initialized
INFO - 2018-03-28 19:20:36 --> Model Class Initialized
INFO - 2018-03-28 19:20:36 --> Model Class Initialized
INFO - 2018-03-28 19:20:36 --> Model Class Initialized
INFO - 2018-03-28 19:20:36 --> Model Class Initialized
INFO - 2018-03-28 19:20:36 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 19:20:36 --> Final output sent to browser
DEBUG - 2018-03-28 19:20:36 --> Total execution time: 0.1638
INFO - 2018-03-28 13:50:42 --> Config Class Initialized
INFO - 2018-03-28 13:50:42 --> Hooks Class Initialized
DEBUG - 2018-03-28 13:50:42 --> UTF-8 Support Enabled
INFO - 2018-03-28 13:50:42 --> Utf8 Class Initialized
INFO - 2018-03-28 13:50:42 --> URI Class Initialized
INFO - 2018-03-28 13:50:42 --> Router Class Initialized
INFO - 2018-03-28 13:50:42 --> Output Class Initialized
INFO - 2018-03-28 13:50:42 --> Security Class Initialized
DEBUG - 2018-03-28 13:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 13:50:42 --> Input Class Initialized
INFO - 2018-03-28 13:50:42 --> Language Class Initialized
INFO - 2018-03-28 13:50:42 --> Language Class Initialized
INFO - 2018-03-28 13:50:42 --> Config Class Initialized
INFO - 2018-03-28 13:50:42 --> Loader Class Initialized
INFO - 2018-03-28 19:20:42 --> Helper loaded: url_helper
INFO - 2018-03-28 19:20:42 --> Helper loaded: notification_helper
INFO - 2018-03-28 19:20:42 --> Helper loaded: settings_helper
INFO - 2018-03-28 19:20:42 --> Helper loaded: permission_helper
INFO - 2018-03-28 19:20:42 --> Helper loaded: users_helper
INFO - 2018-03-28 19:20:42 --> Database Driver Class Initialized
DEBUG - 2018-03-28 19:20:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 19:20:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 19:20:42 --> Helper loaded: form_helper
INFO - 2018-03-28 19:20:42 --> Form Validation Class Initialized
INFO - 2018-03-28 19:20:42 --> Controller Class Initialized
INFO - 2018-03-28 19:20:42 --> Model Class Initialized
INFO - 2018-03-28 19:20:42 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 19:20:42 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 19:20:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 19:20:42 --> Model Class Initialized
INFO - 2018-03-28 19:20:42 --> Model Class Initialized
INFO - 2018-03-28 19:20:42 --> Model Class Initialized
INFO - 2018-03-28 19:20:42 --> Model Class Initialized
INFO - 2018-03-28 19:20:42 --> Model Class Initialized
INFO - 2018-03-28 19:20:42 --> Model Class Initialized
INFO - 2018-03-28 19:20:42 --> Model Class Initialized
INFO - 2018-03-28 19:20:42 --> Model Class Initialized
INFO - 2018-03-28 19:20:42 --> Model Class Initialized
INFO - 2018-03-28 19:20:42 --> Model Class Initialized
INFO - 2018-03-28 19:20:42 --> Model Class Initialized
INFO - 2018-03-28 19:20:42 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 19:20:43 --> Final output sent to browser
DEBUG - 2018-03-28 19:20:43 --> Total execution time: 0.9567
INFO - 2018-03-28 13:50:47 --> Config Class Initialized
INFO - 2018-03-28 13:50:47 --> Hooks Class Initialized
DEBUG - 2018-03-28 13:50:47 --> UTF-8 Support Enabled
INFO - 2018-03-28 13:50:47 --> Utf8 Class Initialized
INFO - 2018-03-28 13:50:47 --> URI Class Initialized
INFO - 2018-03-28 13:50:47 --> Router Class Initialized
INFO - 2018-03-28 13:50:47 --> Output Class Initialized
INFO - 2018-03-28 13:50:47 --> Security Class Initialized
DEBUG - 2018-03-28 13:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 13:50:47 --> Input Class Initialized
INFO - 2018-03-28 13:50:47 --> Language Class Initialized
INFO - 2018-03-28 13:50:47 --> Language Class Initialized
INFO - 2018-03-28 13:50:47 --> Config Class Initialized
INFO - 2018-03-28 13:50:47 --> Loader Class Initialized
INFO - 2018-03-28 19:20:47 --> Helper loaded: url_helper
INFO - 2018-03-28 19:20:47 --> Helper loaded: notification_helper
INFO - 2018-03-28 19:20:47 --> Helper loaded: settings_helper
INFO - 2018-03-28 19:20:47 --> Helper loaded: permission_helper
INFO - 2018-03-28 19:20:47 --> Helper loaded: users_helper
INFO - 2018-03-28 19:20:48 --> Database Driver Class Initialized
DEBUG - 2018-03-28 19:20:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 19:20:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 19:20:48 --> Helper loaded: form_helper
INFO - 2018-03-28 19:20:48 --> Form Validation Class Initialized
INFO - 2018-03-28 19:20:48 --> Controller Class Initialized
INFO - 2018-03-28 19:20:48 --> Model Class Initialized
INFO - 2018-03-28 19:20:48 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 19:20:48 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 19:20:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 19:20:48 --> Model Class Initialized
INFO - 2018-03-28 19:20:48 --> Model Class Initialized
INFO - 2018-03-28 19:20:48 --> Model Class Initialized
INFO - 2018-03-28 19:20:48 --> Model Class Initialized
INFO - 2018-03-28 19:20:48 --> Model Class Initialized
INFO - 2018-03-28 19:20:48 --> Model Class Initialized
INFO - 2018-03-28 19:20:48 --> Model Class Initialized
INFO - 2018-03-28 19:20:48 --> Model Class Initialized
INFO - 2018-03-28 19:20:48 --> Model Class Initialized
INFO - 2018-03-28 19:20:48 --> Model Class Initialized
INFO - 2018-03-28 19:20:48 --> Model Class Initialized
INFO - 2018-03-28 19:20:48 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 19:20:48 --> Model Class Initialized
INFO - 2018-03-28 19:20:48 --> Final output sent to browser
DEBUG - 2018-03-28 19:20:48 --> Total execution time: 0.8750
INFO - 2018-03-28 13:50:51 --> Config Class Initialized
INFO - 2018-03-28 13:50:51 --> Hooks Class Initialized
DEBUG - 2018-03-28 13:50:51 --> UTF-8 Support Enabled
INFO - 2018-03-28 13:50:51 --> Utf8 Class Initialized
INFO - 2018-03-28 13:50:51 --> URI Class Initialized
INFO - 2018-03-28 13:50:51 --> Router Class Initialized
INFO - 2018-03-28 13:50:51 --> Output Class Initialized
INFO - 2018-03-28 13:50:51 --> Security Class Initialized
DEBUG - 2018-03-28 13:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 13:50:51 --> Input Class Initialized
INFO - 2018-03-28 13:50:51 --> Language Class Initialized
INFO - 2018-03-28 13:50:51 --> Language Class Initialized
INFO - 2018-03-28 13:50:51 --> Config Class Initialized
INFO - 2018-03-28 13:50:51 --> Loader Class Initialized
INFO - 2018-03-28 19:20:51 --> Helper loaded: url_helper
INFO - 2018-03-28 19:20:51 --> Helper loaded: notification_helper
INFO - 2018-03-28 19:20:51 --> Helper loaded: settings_helper
INFO - 2018-03-28 19:20:51 --> Helper loaded: permission_helper
INFO - 2018-03-28 19:20:51 --> Helper loaded: users_helper
INFO - 2018-03-28 19:20:51 --> Database Driver Class Initialized
DEBUG - 2018-03-28 19:20:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 19:20:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 19:20:51 --> Helper loaded: form_helper
INFO - 2018-03-28 19:20:51 --> Form Validation Class Initialized
INFO - 2018-03-28 19:20:51 --> Controller Class Initialized
INFO - 2018-03-28 19:20:51 --> Model Class Initialized
INFO - 2018-03-28 19:20:51 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 19:20:51 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 19:20:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 19:20:51 --> Model Class Initialized
INFO - 2018-03-28 19:20:51 --> Model Class Initialized
INFO - 2018-03-28 19:20:51 --> Model Class Initialized
INFO - 2018-03-28 19:20:51 --> Model Class Initialized
INFO - 2018-03-28 19:20:51 --> Final output sent to browser
DEBUG - 2018-03-28 19:20:51 --> Total execution time: 0.2345
INFO - 2018-03-28 13:50:53 --> Config Class Initialized
INFO - 2018-03-28 13:50:53 --> Hooks Class Initialized
DEBUG - 2018-03-28 13:50:53 --> UTF-8 Support Enabled
INFO - 2018-03-28 13:50:53 --> Utf8 Class Initialized
INFO - 2018-03-28 13:50:53 --> URI Class Initialized
INFO - 2018-03-28 13:50:53 --> Router Class Initialized
INFO - 2018-03-28 13:50:53 --> Output Class Initialized
INFO - 2018-03-28 13:50:53 --> Security Class Initialized
DEBUG - 2018-03-28 13:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 13:50:53 --> Input Class Initialized
INFO - 2018-03-28 13:50:53 --> Language Class Initialized
INFO - 2018-03-28 13:50:54 --> Language Class Initialized
INFO - 2018-03-28 13:50:54 --> Config Class Initialized
INFO - 2018-03-28 13:50:54 --> Loader Class Initialized
INFO - 2018-03-28 19:20:54 --> Helper loaded: url_helper
INFO - 2018-03-28 19:20:54 --> Helper loaded: notification_helper
INFO - 2018-03-28 19:20:54 --> Helper loaded: settings_helper
INFO - 2018-03-28 19:20:54 --> Helper loaded: permission_helper
INFO - 2018-03-28 19:20:54 --> Helper loaded: users_helper
INFO - 2018-03-28 19:20:54 --> Database Driver Class Initialized
DEBUG - 2018-03-28 19:20:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 19:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 19:20:54 --> Helper loaded: form_helper
INFO - 2018-03-28 19:20:54 --> Form Validation Class Initialized
INFO - 2018-03-28 19:20:54 --> Controller Class Initialized
INFO - 2018-03-28 19:20:54 --> Model Class Initialized
INFO - 2018-03-28 19:20:54 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 19:20:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 19:20:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 19:20:54 --> Model Class Initialized
INFO - 2018-03-28 19:20:54 --> Model Class Initialized
INFO - 2018-03-28 19:20:54 --> Model Class Initialized
INFO - 2018-03-28 19:20:54 --> Model Class Initialized
INFO - 2018-03-28 19:20:54 --> Final output sent to browser
DEBUG - 2018-03-28 19:20:54 --> Total execution time: 1.7808
INFO - 2018-03-28 13:50:55 --> Config Class Initialized
INFO - 2018-03-28 13:50:55 --> Hooks Class Initialized
DEBUG - 2018-03-28 13:50:55 --> UTF-8 Support Enabled
INFO - 2018-03-28 13:50:55 --> Utf8 Class Initialized
INFO - 2018-03-28 13:50:55 --> URI Class Initialized
INFO - 2018-03-28 13:50:55 --> Router Class Initialized
INFO - 2018-03-28 13:50:55 --> Output Class Initialized
INFO - 2018-03-28 13:50:55 --> Security Class Initialized
DEBUG - 2018-03-28 13:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 13:50:55 --> Input Class Initialized
INFO - 2018-03-28 13:50:55 --> Language Class Initialized
INFO - 2018-03-28 13:50:56 --> Language Class Initialized
INFO - 2018-03-28 13:50:56 --> Config Class Initialized
INFO - 2018-03-28 13:50:56 --> Loader Class Initialized
INFO - 2018-03-28 19:20:56 --> Helper loaded: url_helper
INFO - 2018-03-28 19:20:56 --> Helper loaded: notification_helper
INFO - 2018-03-28 19:20:56 --> Helper loaded: settings_helper
INFO - 2018-03-28 19:20:56 --> Helper loaded: permission_helper
INFO - 2018-03-28 19:20:56 --> Helper loaded: users_helper
INFO - 2018-03-28 19:20:56 --> Database Driver Class Initialized
DEBUG - 2018-03-28 19:20:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 19:20:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 19:20:56 --> Helper loaded: form_helper
INFO - 2018-03-28 19:20:56 --> Form Validation Class Initialized
INFO - 2018-03-28 19:20:56 --> Controller Class Initialized
INFO - 2018-03-28 19:20:56 --> Model Class Initialized
INFO - 2018-03-28 19:20:56 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 19:20:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 19:20:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 19:20:57 --> Model Class Initialized
INFO - 2018-03-28 19:20:57 --> Model Class Initialized
INFO - 2018-03-28 19:20:57 --> Model Class Initialized
INFO - 2018-03-28 19:20:57 --> Model Class Initialized
INFO - 2018-03-28 19:20:57 --> Final output sent to browser
DEBUG - 2018-03-28 19:20:57 --> Total execution time: 2.0680
INFO - 2018-03-28 13:50:59 --> Config Class Initialized
INFO - 2018-03-28 13:50:59 --> Hooks Class Initialized
DEBUG - 2018-03-28 13:50:59 --> UTF-8 Support Enabled
INFO - 2018-03-28 13:50:59 --> Utf8 Class Initialized
INFO - 2018-03-28 13:50:59 --> URI Class Initialized
INFO - 2018-03-28 13:50:59 --> Router Class Initialized
INFO - 2018-03-28 13:50:59 --> Output Class Initialized
INFO - 2018-03-28 13:50:59 --> Security Class Initialized
DEBUG - 2018-03-28 13:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 13:50:59 --> Input Class Initialized
INFO - 2018-03-28 13:50:59 --> Language Class Initialized
INFO - 2018-03-28 13:50:59 --> Language Class Initialized
INFO - 2018-03-28 13:50:59 --> Config Class Initialized
INFO - 2018-03-28 13:50:59 --> Loader Class Initialized
INFO - 2018-03-28 19:20:59 --> Helper loaded: url_helper
INFO - 2018-03-28 19:20:59 --> Helper loaded: notification_helper
INFO - 2018-03-28 19:20:59 --> Helper loaded: settings_helper
INFO - 2018-03-28 19:20:59 --> Helper loaded: permission_helper
INFO - 2018-03-28 19:20:59 --> Helper loaded: users_helper
INFO - 2018-03-28 19:21:00 --> Database Driver Class Initialized
DEBUG - 2018-03-28 19:21:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 19:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 19:21:00 --> Helper loaded: form_helper
INFO - 2018-03-28 19:21:00 --> Form Validation Class Initialized
INFO - 2018-03-28 19:21:00 --> Controller Class Initialized
INFO - 2018-03-28 19:21:00 --> Model Class Initialized
INFO - 2018-03-28 19:21:00 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 19:21:00 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 19:21:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 19:21:00 --> Model Class Initialized
INFO - 2018-03-28 19:21:00 --> Model Class Initialized
INFO - 2018-03-28 19:21:00 --> Model Class Initialized
INFO - 2018-03-28 19:21:00 --> Model Class Initialized
INFO - 2018-03-28 19:21:00 --> Model Class Initialized
INFO - 2018-03-28 19:21:00 --> Model Class Initialized
INFO - 2018-03-28 19:21:00 --> Model Class Initialized
INFO - 2018-03-28 19:21:00 --> Model Class Initialized
INFO - 2018-03-28 19:21:00 --> Model Class Initialized
INFO - 2018-03-28 19:21:00 --> Model Class Initialized
INFO - 2018-03-28 19:21:00 --> Model Class Initialized
INFO - 2018-03-28 19:21:00 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 19:21:00 --> Model Class Initialized
INFO - 2018-03-28 19:21:00 --> Final output sent to browser
DEBUG - 2018-03-28 19:21:00 --> Total execution time: 0.9804
INFO - 2018-03-28 13:51:02 --> Config Class Initialized
INFO - 2018-03-28 13:51:02 --> Hooks Class Initialized
DEBUG - 2018-03-28 13:51:02 --> UTF-8 Support Enabled
INFO - 2018-03-28 13:51:02 --> Utf8 Class Initialized
INFO - 2018-03-28 13:51:02 --> URI Class Initialized
INFO - 2018-03-28 13:51:02 --> Router Class Initialized
INFO - 2018-03-28 13:51:02 --> Output Class Initialized
INFO - 2018-03-28 13:51:02 --> Security Class Initialized
DEBUG - 2018-03-28 13:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 13:51:02 --> Input Class Initialized
INFO - 2018-03-28 13:51:02 --> Language Class Initialized
INFO - 2018-03-28 13:51:02 --> Language Class Initialized
INFO - 2018-03-28 13:51:02 --> Config Class Initialized
INFO - 2018-03-28 13:51:02 --> Loader Class Initialized
INFO - 2018-03-28 19:21:02 --> Helper loaded: url_helper
INFO - 2018-03-28 19:21:02 --> Helper loaded: notification_helper
INFO - 2018-03-28 19:21:02 --> Helper loaded: settings_helper
INFO - 2018-03-28 19:21:02 --> Helper loaded: permission_helper
INFO - 2018-03-28 19:21:02 --> Helper loaded: users_helper
INFO - 2018-03-28 19:21:02 --> Database Driver Class Initialized
DEBUG - 2018-03-28 19:21:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 19:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 19:21:02 --> Helper loaded: form_helper
INFO - 2018-03-28 19:21:02 --> Form Validation Class Initialized
INFO - 2018-03-28 19:21:02 --> Controller Class Initialized
INFO - 2018-03-28 19:21:02 --> Model Class Initialized
INFO - 2018-03-28 19:21:02 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 19:21:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 19:21:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 19:21:02 --> Model Class Initialized
INFO - 2018-03-28 19:21:02 --> Model Class Initialized
INFO - 2018-03-28 19:21:02 --> Model Class Initialized
INFO - 2018-03-28 19:21:02 --> Model Class Initialized
INFO - 2018-03-28 19:21:02 --> Model Class Initialized
INFO - 2018-03-28 19:21:02 --> Model Class Initialized
INFO - 2018-03-28 19:21:02 --> Model Class Initialized
INFO - 2018-03-28 19:21:02 --> Model Class Initialized
INFO - 2018-03-28 19:21:02 --> Model Class Initialized
INFO - 2018-03-28 19:21:02 --> Model Class Initialized
INFO - 2018-03-28 19:21:02 --> Model Class Initialized
INFO - 2018-03-28 19:21:02 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 19:21:02 --> Model Class Initialized
INFO - 2018-03-28 19:21:02 --> Final output sent to browser
DEBUG - 2018-03-28 19:21:02 --> Total execution time: 0.4889
INFO - 2018-03-28 13:51:02 --> Config Class Initialized
INFO - 2018-03-28 13:51:02 --> Hooks Class Initialized
DEBUG - 2018-03-28 13:51:02 --> UTF-8 Support Enabled
INFO - 2018-03-28 13:51:02 --> Utf8 Class Initialized
INFO - 2018-03-28 13:51:02 --> URI Class Initialized
INFO - 2018-03-28 13:51:03 --> Router Class Initialized
INFO - 2018-03-28 13:51:03 --> Output Class Initialized
INFO - 2018-03-28 13:51:03 --> Security Class Initialized
DEBUG - 2018-03-28 13:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 13:51:03 --> Input Class Initialized
INFO - 2018-03-28 13:51:03 --> Language Class Initialized
INFO - 2018-03-28 13:51:04 --> Language Class Initialized
INFO - 2018-03-28 13:51:04 --> Config Class Initialized
INFO - 2018-03-28 13:51:04 --> Loader Class Initialized
INFO - 2018-03-28 19:21:04 --> Helper loaded: url_helper
INFO - 2018-03-28 19:21:04 --> Helper loaded: notification_helper
INFO - 2018-03-28 19:21:04 --> Helper loaded: settings_helper
INFO - 2018-03-28 19:21:04 --> Helper loaded: permission_helper
INFO - 2018-03-28 19:21:04 --> Helper loaded: users_helper
INFO - 2018-03-28 19:21:04 --> Database Driver Class Initialized
DEBUG - 2018-03-28 19:21:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 19:21:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 19:21:04 --> Helper loaded: form_helper
INFO - 2018-03-28 19:21:04 --> Form Validation Class Initialized
INFO - 2018-03-28 19:21:04 --> Controller Class Initialized
INFO - 2018-03-28 19:21:04 --> Model Class Initialized
INFO - 2018-03-28 19:21:04 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 19:21:04 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 19:21:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 19:21:04 --> Model Class Initialized
INFO - 2018-03-28 19:21:04 --> Model Class Initialized
INFO - 2018-03-28 19:21:04 --> Model Class Initialized
INFO - 2018-03-28 19:21:04 --> Model Class Initialized
INFO - 2018-03-28 19:21:04 --> Model Class Initialized
INFO - 2018-03-28 19:21:04 --> Model Class Initialized
INFO - 2018-03-28 19:21:04 --> Model Class Initialized
INFO - 2018-03-28 19:21:04 --> Model Class Initialized
INFO - 2018-03-28 19:21:04 --> Model Class Initialized
INFO - 2018-03-28 19:21:04 --> Model Class Initialized
INFO - 2018-03-28 19:21:04 --> Model Class Initialized
INFO - 2018-03-28 19:21:04 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 19:21:04 --> Final output sent to browser
DEBUG - 2018-03-28 19:21:04 --> Total execution time: 2.1772
INFO - 2018-03-28 13:51:05 --> Config Class Initialized
INFO - 2018-03-28 13:51:05 --> Hooks Class Initialized
DEBUG - 2018-03-28 13:51:05 --> UTF-8 Support Enabled
INFO - 2018-03-28 13:51:05 --> Utf8 Class Initialized
INFO - 2018-03-28 13:51:05 --> URI Class Initialized
INFO - 2018-03-28 13:51:05 --> Router Class Initialized
INFO - 2018-03-28 13:51:05 --> Output Class Initialized
INFO - 2018-03-28 13:51:05 --> Security Class Initialized
DEBUG - 2018-03-28 13:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 13:51:05 --> Input Class Initialized
INFO - 2018-03-28 13:51:05 --> Language Class Initialized
INFO - 2018-03-28 13:51:05 --> Language Class Initialized
INFO - 2018-03-28 13:51:05 --> Config Class Initialized
INFO - 2018-03-28 13:51:05 --> Loader Class Initialized
INFO - 2018-03-28 19:21:05 --> Helper loaded: url_helper
INFO - 2018-03-28 19:21:05 --> Helper loaded: notification_helper
INFO - 2018-03-28 19:21:05 --> Helper loaded: settings_helper
INFO - 2018-03-28 19:21:05 --> Helper loaded: permission_helper
INFO - 2018-03-28 19:21:05 --> Helper loaded: users_helper
INFO - 2018-03-28 19:21:05 --> Database Driver Class Initialized
DEBUG - 2018-03-28 19:21:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 19:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 19:21:05 --> Helper loaded: form_helper
INFO - 2018-03-28 19:21:05 --> Form Validation Class Initialized
INFO - 2018-03-28 19:21:05 --> Controller Class Initialized
INFO - 2018-03-28 19:21:05 --> Model Class Initialized
INFO - 2018-03-28 19:21:05 --> Helper loaded: inflector_helper
DEBUG - 2018-03-28 19:21:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-28 19:21:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-28 19:21:05 --> Model Class Initialized
INFO - 2018-03-28 19:21:05 --> Model Class Initialized
INFO - 2018-03-28 19:21:05 --> Model Class Initialized
INFO - 2018-03-28 19:21:05 --> Model Class Initialized
INFO - 2018-03-28 19:21:05 --> Model Class Initialized
INFO - 2018-03-28 19:21:05 --> Model Class Initialized
INFO - 2018-03-28 19:21:05 --> Model Class Initialized
INFO - 2018-03-28 19:21:05 --> Model Class Initialized
INFO - 2018-03-28 19:21:05 --> Model Class Initialized
INFO - 2018-03-28 19:21:05 --> Model Class Initialized
INFO - 2018-03-28 19:21:05 --> Model Class Initialized
INFO - 2018-03-28 19:21:05 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-28 19:21:05 --> Final output sent to browser
DEBUG - 2018-03-28 19:21:05 --> Total execution time: 0.1176
