<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-02-24 14:10:55 --> Config Class Initialized
INFO - 2018-02-24 14:10:55 --> Hooks Class Initialized
DEBUG - 2018-02-24 14:10:55 --> UTF-8 Support Enabled
INFO - 2018-02-24 14:10:55 --> Utf8 Class Initialized
INFO - 2018-02-24 14:10:55 --> URI Class Initialized
INFO - 2018-02-24 14:10:55 --> Router Class Initialized
INFO - 2018-02-24 14:10:55 --> Output Class Initialized
INFO - 2018-02-24 14:10:55 --> Security Class Initialized
DEBUG - 2018-02-24 14:10:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-24 14:10:55 --> Input Class Initialized
INFO - 2018-02-24 14:10:55 --> Language Class Initialized
INFO - 2018-02-24 14:10:55 --> Language Class Initialized
INFO - 2018-02-24 14:10:55 --> Config Class Initialized
INFO - 2018-02-24 14:10:55 --> Loader Class Initialized
INFO - 2018-02-24 19:40:55 --> Helper loaded: url_helper
INFO - 2018-02-24 19:40:55 --> Helper loaded: notification_helper
INFO - 2018-02-24 19:40:55 --> Helper loaded: settings_helper
INFO - 2018-02-24 19:40:55 --> Helper loaded: permission_helper
INFO - 2018-02-24 19:40:55 --> Helper loaded: users_helper
INFO - 2018-02-24 19:40:55 --> Database Driver Class Initialized
DEBUG - 2018-02-24 19:40:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-24 19:40:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-24 19:40:55 --> Helper loaded: form_helper
INFO - 2018-02-24 19:40:55 --> Form Validation Class Initialized
INFO - 2018-02-24 19:40:55 --> Controller Class Initialized
INFO - 2018-02-24 19:40:55 --> Model Class Initialized
INFO - 2018-02-24 19:40:55 --> Helper loaded: inflector_helper
DEBUG - 2018-02-24 19:40:55 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-24 19:40:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-24 19:40:55 --> Model Class Initialized
INFO - 2018-02-24 19:40:55 --> Model Class Initialized
INFO - 2018-02-24 19:40:55 --> Model Class Initialized
INFO - 2018-02-24 19:40:55 --> Model Class Initialized
INFO - 2018-02-24 19:40:55 --> Model Class Initialized
INFO - 2018-02-24 19:40:55 --> Model Class Initialized
INFO - 2018-02-24 19:40:55 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-24 19:40:55 --> Final output sent to browser
DEBUG - 2018-02-24 19:40:55 --> Total execution time: 0.1336
INFO - 2018-02-24 14:10:56 --> Config Class Initialized
INFO - 2018-02-24 14:10:56 --> Hooks Class Initialized
DEBUG - 2018-02-24 14:10:56 --> UTF-8 Support Enabled
INFO - 2018-02-24 14:10:56 --> Utf8 Class Initialized
INFO - 2018-02-24 14:10:56 --> URI Class Initialized
INFO - 2018-02-24 14:10:56 --> Router Class Initialized
INFO - 2018-02-24 14:10:56 --> Output Class Initialized
INFO - 2018-02-24 14:10:56 --> Security Class Initialized
DEBUG - 2018-02-24 14:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-24 14:10:56 --> Input Class Initialized
INFO - 2018-02-24 14:10:56 --> Language Class Initialized
INFO - 2018-02-24 14:10:56 --> Language Class Initialized
INFO - 2018-02-24 14:10:56 --> Config Class Initialized
INFO - 2018-02-24 14:10:56 --> Loader Class Initialized
INFO - 2018-02-24 19:40:56 --> Helper loaded: url_helper
INFO - 2018-02-24 19:40:56 --> Helper loaded: notification_helper
INFO - 2018-02-24 19:40:56 --> Helper loaded: settings_helper
INFO - 2018-02-24 19:40:56 --> Helper loaded: permission_helper
INFO - 2018-02-24 19:40:56 --> Helper loaded: users_helper
INFO - 2018-02-24 19:40:56 --> Database Driver Class Initialized
DEBUG - 2018-02-24 19:40:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-24 19:40:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-24 19:40:56 --> Helper loaded: form_helper
INFO - 2018-02-24 19:40:56 --> Form Validation Class Initialized
INFO - 2018-02-24 19:40:56 --> Controller Class Initialized
INFO - 2018-02-24 19:40:56 --> Model Class Initialized
INFO - 2018-02-24 19:40:56 --> Helper loaded: inflector_helper
DEBUG - 2018-02-24 19:40:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-24 19:40:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-24 19:40:56 --> Model Class Initialized
INFO - 2018-02-24 19:40:56 --> Model Class Initialized
INFO - 2018-02-24 19:40:56 --> Model Class Initialized
INFO - 2018-02-24 19:40:56 --> Model Class Initialized
INFO - 2018-02-24 19:40:56 --> Model Class Initialized
INFO - 2018-02-24 19:40:56 --> Model Class Initialized
INFO - 2018-02-24 19:40:56 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-24 19:40:56 --> Final output sent to browser
DEBUG - 2018-02-24 19:40:56 --> Total execution time: 0.1145
INFO - 2018-02-24 14:10:56 --> Config Class Initialized
INFO - 2018-02-24 14:10:56 --> Hooks Class Initialized
DEBUG - 2018-02-24 14:10:56 --> UTF-8 Support Enabled
INFO - 2018-02-24 14:10:56 --> Utf8 Class Initialized
INFO - 2018-02-24 14:10:56 --> URI Class Initialized
INFO - 2018-02-24 14:10:56 --> Router Class Initialized
INFO - 2018-02-24 14:10:56 --> Output Class Initialized
INFO - 2018-02-24 14:10:56 --> Security Class Initialized
DEBUG - 2018-02-24 14:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-24 14:10:56 --> Input Class Initialized
INFO - 2018-02-24 14:10:56 --> Language Class Initialized
INFO - 2018-02-24 14:10:56 --> Language Class Initialized
INFO - 2018-02-24 14:10:56 --> Config Class Initialized
INFO - 2018-02-24 14:10:56 --> Loader Class Initialized
INFO - 2018-02-24 19:40:56 --> Helper loaded: url_helper
INFO - 2018-02-24 19:40:56 --> Helper loaded: notification_helper
INFO - 2018-02-24 19:40:56 --> Helper loaded: settings_helper
INFO - 2018-02-24 19:40:56 --> Helper loaded: permission_helper
INFO - 2018-02-24 19:40:56 --> Helper loaded: users_helper
INFO - 2018-02-24 14:10:56 --> Config Class Initialized
INFO - 2018-02-24 14:10:56 --> Hooks Class Initialized
DEBUG - 2018-02-24 14:10:56 --> UTF-8 Support Enabled
INFO - 2018-02-24 14:10:56 --> Utf8 Class Initialized
INFO - 2018-02-24 14:10:56 --> URI Class Initialized
INFO - 2018-02-24 14:10:56 --> Router Class Initialized
INFO - 2018-02-24 19:40:56 --> Database Driver Class Initialized
INFO - 2018-02-24 14:10:56 --> Output Class Initialized
INFO - 2018-02-24 14:10:56 --> Security Class Initialized
DEBUG - 2018-02-24 19:40:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-24 19:40:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-24 14:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-24 14:10:56 --> Input Class Initialized
INFO - 2018-02-24 14:10:56 --> Language Class Initialized
INFO - 2018-02-24 19:40:56 --> Helper loaded: form_helper
INFO - 2018-02-24 19:40:56 --> Form Validation Class Initialized
INFO - 2018-02-24 19:40:56 --> Controller Class Initialized
INFO - 2018-02-24 14:10:56 --> Language Class Initialized
INFO - 2018-02-24 14:10:56 --> Config Class Initialized
INFO - 2018-02-24 14:10:56 --> Loader Class Initialized
INFO - 2018-02-24 19:40:56 --> Model Class Initialized
INFO - 2018-02-24 19:40:56 --> Helper loaded: inflector_helper
INFO - 2018-02-24 19:40:56 --> Helper loaded: url_helper
INFO - 2018-02-24 19:40:56 --> Helper loaded: notification_helper
INFO - 2018-02-24 19:40:56 --> Helper loaded: settings_helper
INFO - 2018-02-24 19:40:56 --> Helper loaded: permission_helper
DEBUG - 2018-02-24 19:40:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-24 14:10:56 --> Config Class Initialized
INFO - 2018-02-24 14:10:56 --> Hooks Class Initialized
INFO - 2018-02-24 14:10:56 --> Config Class Initialized
INFO - 2018-02-24 19:40:56 --> Helper loaded: users_helper
INFO - 2018-02-24 14:10:56 --> Hooks Class Initialized
INFO - 2018-02-24 19:40:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-24 19:40:56 --> Model Class Initialized
INFO - 2018-02-24 19:40:56 --> Model Class Initialized
INFO - 2018-02-24 19:40:56 --> Model Class Initialized
INFO - 2018-02-24 19:40:56 --> Model Class Initialized
INFO - 2018-02-24 19:40:56 --> Model Class Initialized
INFO - 2018-02-24 19:40:56 --> Model Class Initialized
INFO - 2018-02-24 19:40:56 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-02-24 14:10:56 --> UTF-8 Support Enabled
INFO - 2018-02-24 14:10:56 --> Utf8 Class Initialized
DEBUG - 2018-02-24 14:10:56 --> UTF-8 Support Enabled
INFO - 2018-02-24 14:10:56 --> Utf8 Class Initialized
INFO - 2018-02-24 19:40:56 --> Model Class Initialized
INFO - 2018-02-24 19:40:56 --> Final output sent to browser
DEBUG - 2018-02-24 19:40:56 --> Total execution time: 0.1107
INFO - 2018-02-24 14:10:56 --> URI Class Initialized
INFO - 2018-02-24 14:10:56 --> URI Class Initialized
INFO - 2018-02-24 19:40:56 --> Database Driver Class Initialized
INFO - 2018-02-24 14:10:56 --> Router Class Initialized
INFO - 2018-02-24 14:10:56 --> Router Class Initialized
DEBUG - 2018-02-24 19:40:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-24 19:40:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-24 14:10:56 --> Output Class Initialized
INFO - 2018-02-24 14:10:56 --> Output Class Initialized
INFO - 2018-02-24 19:40:56 --> Helper loaded: form_helper
INFO - 2018-02-24 19:40:56 --> Form Validation Class Initialized
INFO - 2018-02-24 19:40:56 --> Controller Class Initialized
INFO - 2018-02-24 14:10:56 --> Security Class Initialized
INFO - 2018-02-24 14:10:56 --> Security Class Initialized
DEBUG - 2018-02-24 14:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-24 14:10:56 --> Input Class Initialized
DEBUG - 2018-02-24 14:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-24 14:10:56 --> Input Class Initialized
INFO - 2018-02-24 14:10:56 --> Language Class Initialized
INFO - 2018-02-24 14:10:56 --> Language Class Initialized
INFO - 2018-02-24 19:40:56 --> Model Class Initialized
INFO - 2018-02-24 19:40:56 --> Helper loaded: inflector_helper
DEBUG - 2018-02-24 19:40:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-24 19:40:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-24 19:40:56 --> Model Class Initialized
INFO - 2018-02-24 19:40:56 --> Model Class Initialized
INFO - 2018-02-24 14:10:56 --> Language Class Initialized
INFO - 2018-02-24 14:10:56 --> Config Class Initialized
INFO - 2018-02-24 14:10:56 --> Loader Class Initialized
INFO - 2018-02-24 19:40:56 --> Model Class Initialized
INFO - 2018-02-24 19:40:56 --> Model Class Initialized
INFO - 2018-02-24 19:40:56 --> Model Class Initialized
INFO - 2018-02-24 19:40:56 --> Model Class Initialized
INFO - 2018-02-24 19:40:56 --> Helper loaded: url_helper
INFO - 2018-02-24 19:40:56 --> Model Class Initialized
INFO - 2018-02-24 19:40:56 --> Model Class Initialized
INFO - 2018-02-24 19:40:56 --> Helper loaded: notification_helper
INFO - 2018-02-24 19:40:56 --> Model Class Initialized
INFO - 2018-02-24 19:40:56 --> Model Class Initialized
INFO - 2018-02-24 19:40:56 --> Helper loaded: settings_helper
INFO - 2018-02-24 19:40:56 --> Helper loaded: permission_helper
INFO - 2018-02-24 19:40:56 --> Helper loaded: users_helper
INFO - 2018-02-24 19:40:56 --> Model Class Initialized
INFO - 2018-02-24 19:40:56 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-24 19:40:56 --> Model Class Initialized
INFO - 2018-02-24 14:10:56 --> Language Class Initialized
INFO - 2018-02-24 14:10:56 --> Config Class Initialized
INFO - 2018-02-24 14:10:56 --> Loader Class Initialized
INFO - 2018-02-24 19:40:57 --> Helper loaded: url_helper
INFO - 2018-02-24 19:40:57 --> Helper loaded: notification_helper
INFO - 2018-02-24 19:40:57 --> Helper loaded: settings_helper
INFO - 2018-02-24 19:40:57 --> Helper loaded: permission_helper
INFO - 2018-02-24 19:40:57 --> Helper loaded: users_helper
INFO - 2018-02-24 19:40:57 --> Database Driver Class Initialized
DEBUG - 2018-02-24 19:40:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-24 19:40:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-24 19:40:57 --> Database Driver Class Initialized
INFO - 2018-02-24 19:40:57 --> Helper loaded: form_helper
INFO - 2018-02-24 19:40:57 --> Form Validation Class Initialized
INFO - 2018-02-24 19:40:57 --> Controller Class Initialized
DEBUG - 2018-02-24 19:40:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-24 19:40:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-24 19:40:57 --> Model Class Initialized
INFO - 2018-02-24 19:40:57 --> Helper loaded: inflector_helper
INFO - 2018-02-24 19:40:57 --> Helper loaded: form_helper
INFO - 2018-02-24 19:40:57 --> Form Validation Class Initialized
INFO - 2018-02-24 19:40:57 --> Controller Class Initialized
INFO - 2018-02-24 19:40:57 --> Final output sent to browser
DEBUG - 2018-02-24 19:40:57 --> Total execution time: 0.1411
DEBUG - 2018-02-24 19:40:57 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-24 19:40:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-24 19:40:57 --> Model Class Initialized
INFO - 2018-02-24 19:40:57 --> Model Class Initialized
INFO - 2018-02-24 19:40:57 --> Model Class Initialized
INFO - 2018-02-24 19:40:57 --> Model Class Initialized
INFO - 2018-02-24 19:40:57 --> Model Class Initialized
INFO - 2018-02-24 19:40:57 --> Model Class Initialized
INFO - 2018-02-24 19:40:57 --> Model Class Initialized
INFO - 2018-02-24 19:40:57 --> Model Class Initialized
INFO - 2018-02-24 19:40:57 --> Model Class Initialized
INFO - 2018-02-24 19:40:57 --> Model Class Initialized
INFO - 2018-02-24 19:40:57 --> Model Class Initialized
INFO - 2018-02-24 19:40:57 --> Helper loaded: inflector_helper
INFO - 2018-02-24 19:40:57 --> Model Class Initialized
INFO - 2018-02-24 19:40:57 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-24 19:40:57 --> Model Class Initialized
DEBUG - 2018-02-24 19:40:57 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-24 19:40:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-24 19:40:57 --> Model Class Initialized
INFO - 2018-02-24 19:40:57 --> Model Class Initialized
INFO - 2018-02-24 19:40:57 --> Model Class Initialized
INFO - 2018-02-24 19:40:57 --> Model Class Initialized
INFO - 2018-02-24 19:40:57 --> Model Class Initialized
INFO - 2018-02-24 19:40:57 --> Model Class Initialized
INFO - 2018-02-24 19:40:57 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-24 19:40:57 --> Model Class Initialized
INFO - 2018-02-24 19:40:57 --> Final output sent to browser
DEBUG - 2018-02-24 19:40:57 --> Total execution time: 0.1260
INFO - 2018-02-24 19:40:57 --> Final output sent to browser
DEBUG - 2018-02-24 19:40:57 --> Total execution time: 0.1474
