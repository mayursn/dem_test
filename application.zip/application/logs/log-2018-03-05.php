<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-03-05 09:57:08 --> Config Class Initialized
INFO - 2018-03-05 09:57:08 --> Hooks Class Initialized
DEBUG - 2018-03-05 09:57:08 --> UTF-8 Support Enabled
INFO - 2018-03-05 09:57:08 --> Utf8 Class Initialized
INFO - 2018-03-05 09:57:08 --> URI Class Initialized
INFO - 2018-03-05 09:57:08 --> Router Class Initialized
INFO - 2018-03-05 09:57:08 --> Output Class Initialized
INFO - 2018-03-05 09:57:08 --> Security Class Initialized
DEBUG - 2018-03-05 09:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 09:57:08 --> Input Class Initialized
INFO - 2018-03-05 09:57:08 --> Language Class Initialized
INFO - 2018-03-05 09:57:08 --> Language Class Initialized
INFO - 2018-03-05 09:57:08 --> Config Class Initialized
INFO - 2018-03-05 09:57:08 --> Loader Class Initialized
INFO - 2018-03-05 15:27:08 --> Helper loaded: url_helper
INFO - 2018-03-05 15:27:08 --> Helper loaded: notification_helper
INFO - 2018-03-05 15:27:08 --> Helper loaded: settings_helper
INFO - 2018-03-05 15:27:08 --> Helper loaded: permission_helper
INFO - 2018-03-05 15:27:08 --> Helper loaded: users_helper
INFO - 2018-03-05 15:27:08 --> Database Driver Class Initialized
DEBUG - 2018-03-05 15:27:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 15:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 15:27:09 --> Helper loaded: form_helper
INFO - 2018-03-05 15:27:09 --> Form Validation Class Initialized
INFO - 2018-03-05 15:27:09 --> Controller Class Initialized
INFO - 2018-03-05 15:27:09 --> Model Class Initialized
INFO - 2018-03-05 15:27:09 --> Helper loaded: inflector_helper
DEBUG - 2018-03-05 15:27:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-05 15:27:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-05 15:27:09 --> Model Class Initialized
INFO - 2018-03-05 15:27:09 --> Model Class Initialized
INFO - 2018-03-05 15:27:09 --> Model Class Initialized
INFO - 2018-03-05 15:27:09 --> Model Class Initialized
INFO - 2018-03-05 15:27:09 --> Model Class Initialized
INFO - 2018-03-05 15:27:09 --> Model Class Initialized
INFO - 2018-03-05 15:27:09 --> Model Class Initialized
INFO - 2018-03-05 15:27:09 --> Model Class Initialized
INFO - 2018-03-05 15:27:09 --> Model Class Initialized
INFO - 2018-03-05 15:27:09 --> Model Class Initialized
INFO - 2018-03-05 15:27:09 --> Model Class Initialized
INFO - 2018-03-05 15:27:09 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-05 15:27:09 --> Model Class Initialized
INFO - 2018-03-05 15:27:09 --> Final output sent to browser
DEBUG - 2018-03-05 15:27:09 --> Total execution time: 0.6443
INFO - 2018-03-05 09:57:12 --> Config Class Initialized
INFO - 2018-03-05 09:57:12 --> Hooks Class Initialized
DEBUG - 2018-03-05 09:57:12 --> UTF-8 Support Enabled
INFO - 2018-03-05 09:57:12 --> Utf8 Class Initialized
INFO - 2018-03-05 09:57:12 --> URI Class Initialized
INFO - 2018-03-05 09:57:12 --> Router Class Initialized
INFO - 2018-03-05 09:57:12 --> Output Class Initialized
INFO - 2018-03-05 09:57:12 --> Security Class Initialized
DEBUG - 2018-03-05 09:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 09:57:12 --> Input Class Initialized
INFO - 2018-03-05 09:57:12 --> Language Class Initialized
INFO - 2018-03-05 09:57:12 --> Language Class Initialized
INFO - 2018-03-05 09:57:12 --> Config Class Initialized
INFO - 2018-03-05 09:57:12 --> Loader Class Initialized
INFO - 2018-03-05 15:27:12 --> Helper loaded: url_helper
INFO - 2018-03-05 15:27:12 --> Helper loaded: notification_helper
INFO - 2018-03-05 15:27:12 --> Helper loaded: settings_helper
INFO - 2018-03-05 15:27:12 --> Helper loaded: permission_helper
INFO - 2018-03-05 15:27:12 --> Helper loaded: users_helper
INFO - 2018-03-05 15:27:12 --> Database Driver Class Initialized
DEBUG - 2018-03-05 15:27:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 15:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 15:27:12 --> Helper loaded: form_helper
INFO - 2018-03-05 15:27:12 --> Form Validation Class Initialized
INFO - 2018-03-05 15:27:12 --> Controller Class Initialized
INFO - 2018-03-05 15:27:12 --> Model Class Initialized
INFO - 2018-03-05 15:27:12 --> Helper loaded: inflector_helper
DEBUG - 2018-03-05 15:27:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-05 15:27:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-05 15:27:12 --> Model Class Initialized
INFO - 2018-03-05 15:27:12 --> Model Class Initialized
INFO - 2018-03-05 15:27:12 --> Model Class Initialized
INFO - 2018-03-05 15:27:12 --> Model Class Initialized
INFO - 2018-03-05 15:27:12 --> Model Class Initialized
INFO - 2018-03-05 15:27:12 --> Model Class Initialized
INFO - 2018-03-05 15:27:12 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-05 15:27:12 --> Model Class Initialized
INFO - 2018-03-05 15:27:12 --> Final output sent to browser
DEBUG - 2018-03-05 15:27:12 --> Total execution time: 0.1524
INFO - 2018-03-05 09:59:00 --> Config Class Initialized
INFO - 2018-03-05 09:59:00 --> Hooks Class Initialized
DEBUG - 2018-03-05 09:59:00 --> UTF-8 Support Enabled
INFO - 2018-03-05 09:59:00 --> Utf8 Class Initialized
INFO - 2018-03-05 09:59:00 --> URI Class Initialized
INFO - 2018-03-05 09:59:00 --> Router Class Initialized
INFO - 2018-03-05 09:59:00 --> Output Class Initialized
INFO - 2018-03-05 09:59:00 --> Security Class Initialized
DEBUG - 2018-03-05 09:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 09:59:00 --> Input Class Initialized
INFO - 2018-03-05 09:59:00 --> Language Class Initialized
INFO - 2018-03-05 09:59:00 --> Language Class Initialized
INFO - 2018-03-05 09:59:00 --> Config Class Initialized
INFO - 2018-03-05 09:59:00 --> Loader Class Initialized
INFO - 2018-03-05 15:29:00 --> Helper loaded: url_helper
INFO - 2018-03-05 15:29:00 --> Helper loaded: notification_helper
INFO - 2018-03-05 15:29:00 --> Helper loaded: settings_helper
INFO - 2018-03-05 15:29:00 --> Helper loaded: permission_helper
INFO - 2018-03-05 15:29:00 --> Helper loaded: users_helper
INFO - 2018-03-05 15:29:00 --> Database Driver Class Initialized
DEBUG - 2018-03-05 15:29:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 15:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 15:29:00 --> Helper loaded: form_helper
INFO - 2018-03-05 15:29:00 --> Form Validation Class Initialized
INFO - 2018-03-05 15:29:00 --> Controller Class Initialized
INFO - 2018-03-05 15:29:00 --> Model Class Initialized
INFO - 2018-03-05 15:29:00 --> Helper loaded: inflector_helper
DEBUG - 2018-03-05 15:29:00 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-05 15:29:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-05 15:29:00 --> Model Class Initialized
INFO - 2018-03-05 15:29:00 --> Model Class Initialized
INFO - 2018-03-05 15:29:00 --> Model Class Initialized
INFO - 2018-03-05 15:29:00 --> Model Class Initialized
INFO - 2018-03-05 15:29:00 --> Model Class Initialized
INFO - 2018-03-05 15:29:00 --> Model Class Initialized
INFO - 2018-03-05 15:29:00 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-05 15:29:00 --> Model Class Initialized
INFO - 2018-03-05 15:29:00 --> Final output sent to browser
DEBUG - 2018-03-05 15:29:00 --> Total execution time: 0.3068
INFO - 2018-03-05 09:59:01 --> Config Class Initialized
INFO - 2018-03-05 09:59:01 --> Hooks Class Initialized
DEBUG - 2018-03-05 09:59:01 --> UTF-8 Support Enabled
INFO - 2018-03-05 09:59:01 --> Utf8 Class Initialized
INFO - 2018-03-05 09:59:01 --> URI Class Initialized
INFO - 2018-03-05 09:59:01 --> Router Class Initialized
INFO - 2018-03-05 09:59:01 --> Output Class Initialized
INFO - 2018-03-05 09:59:01 --> Security Class Initialized
DEBUG - 2018-03-05 09:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 09:59:01 --> Input Class Initialized
INFO - 2018-03-05 09:59:01 --> Language Class Initialized
INFO - 2018-03-05 09:59:02 --> Language Class Initialized
INFO - 2018-03-05 09:59:02 --> Config Class Initialized
INFO - 2018-03-05 09:59:02 --> Loader Class Initialized
INFO - 2018-03-05 15:29:02 --> Helper loaded: url_helper
INFO - 2018-03-05 15:29:02 --> Helper loaded: notification_helper
INFO - 2018-03-05 15:29:02 --> Helper loaded: settings_helper
INFO - 2018-03-05 15:29:02 --> Helper loaded: permission_helper
INFO - 2018-03-05 15:29:02 --> Helper loaded: users_helper
INFO - 2018-03-05 15:29:03 --> Database Driver Class Initialized
DEBUG - 2018-03-05 15:29:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 15:29:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 15:29:03 --> Helper loaded: form_helper
INFO - 2018-03-05 15:29:03 --> Form Validation Class Initialized
INFO - 2018-03-05 15:29:03 --> Controller Class Initialized
INFO - 2018-03-05 15:29:04 --> Model Class Initialized
INFO - 2018-03-05 15:29:04 --> Helper loaded: inflector_helper
DEBUG - 2018-03-05 15:29:04 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-05 15:29:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-05 15:29:04 --> Model Class Initialized
INFO - 2018-03-05 15:29:04 --> Model Class Initialized
INFO - 2018-03-05 15:29:04 --> Model Class Initialized
INFO - 2018-03-05 15:29:04 --> Model Class Initialized
INFO - 2018-03-05 15:29:04 --> Model Class Initialized
INFO - 2018-03-05 15:29:04 --> Model Class Initialized
INFO - 2018-03-05 15:29:04 --> Model Class Initialized
INFO - 2018-03-05 15:29:04 --> Model Class Initialized
INFO - 2018-03-05 15:29:04 --> Model Class Initialized
INFO - 2018-03-05 15:29:04 --> Model Class Initialized
INFO - 2018-03-05 15:29:04 --> Model Class Initialized
INFO - 2018-03-05 15:29:04 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-05 15:29:04 --> Model Class Initialized
INFO - 2018-03-05 15:29:04 --> Final output sent to browser
DEBUG - 2018-03-05 15:29:04 --> Total execution time: 3.7070
INFO - 2018-03-05 10:24:10 --> Config Class Initialized
INFO - 2018-03-05 10:24:10 --> Hooks Class Initialized
DEBUG - 2018-03-05 10:24:10 --> UTF-8 Support Enabled
INFO - 2018-03-05 10:24:10 --> Utf8 Class Initialized
INFO - 2018-03-05 10:24:10 --> URI Class Initialized
INFO - 2018-03-05 10:24:10 --> Router Class Initialized
INFO - 2018-03-05 10:24:10 --> Output Class Initialized
INFO - 2018-03-05 10:24:10 --> Security Class Initialized
DEBUG - 2018-03-05 10:24:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 10:24:10 --> Input Class Initialized
INFO - 2018-03-05 10:24:10 --> Language Class Initialized
INFO - 2018-03-05 10:24:10 --> Config Class Initialized
INFO - 2018-03-05 10:24:10 --> Hooks Class Initialized
DEBUG - 2018-03-05 10:24:10 --> UTF-8 Support Enabled
INFO - 2018-03-05 10:24:10 --> Utf8 Class Initialized
INFO - 2018-03-05 10:24:10 --> URI Class Initialized
INFO - 2018-03-05 10:24:11 --> Router Class Initialized
INFO - 2018-03-05 10:24:11 --> Output Class Initialized
INFO - 2018-03-05 10:24:11 --> Security Class Initialized
DEBUG - 2018-03-05 10:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 10:24:11 --> Input Class Initialized
INFO - 2018-03-05 10:24:11 --> Language Class Initialized
INFO - 2018-03-05 10:24:11 --> Language Class Initialized
INFO - 2018-03-05 10:24:11 --> Config Class Initialized
INFO - 2018-03-05 10:24:11 --> Loader Class Initialized
INFO - 2018-03-05 10:24:11 --> Language Class Initialized
INFO - 2018-03-05 10:24:11 --> Config Class Initialized
INFO - 2018-03-05 10:24:11 --> Loader Class Initialized
INFO - 2018-03-05 15:54:11 --> Helper loaded: url_helper
INFO - 2018-03-05 15:54:11 --> Helper loaded: notification_helper
INFO - 2018-03-05 15:54:11 --> Helper loaded: settings_helper
INFO - 2018-03-05 15:54:11 --> Helper loaded: permission_helper
INFO - 2018-03-05 15:54:11 --> Helper loaded: users_helper
INFO - 2018-03-05 15:54:11 --> Helper loaded: url_helper
INFO - 2018-03-05 15:54:11 --> Database Driver Class Initialized
INFO - 2018-03-05 15:54:11 --> Helper loaded: notification_helper
INFO - 2018-03-05 15:54:11 --> Helper loaded: settings_helper
DEBUG - 2018-03-05 15:54:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 15:54:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 15:54:11 --> Helper loaded: permission_helper
INFO - 2018-03-05 15:54:11 --> Helper loaded: users_helper
INFO - 2018-03-05 15:54:11 --> Helper loaded: form_helper
INFO - 2018-03-05 15:54:11 --> Form Validation Class Initialized
INFO - 2018-03-05 15:54:11 --> Controller Class Initialized
INFO - 2018-03-05 15:54:11 --> Model Class Initialized
INFO - 2018-03-05 15:54:11 --> Helper loaded: inflector_helper
DEBUG - 2018-03-05 15:54:11 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-05 15:54:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-05 15:54:11 --> Model Class Initialized
INFO - 2018-03-05 15:54:11 --> Model Class Initialized
INFO - 2018-03-05 15:54:11 --> Model Class Initialized
INFO - 2018-03-05 15:54:11 --> Model Class Initialized
INFO - 2018-03-05 15:54:11 --> Model Class Initialized
INFO - 2018-03-05 15:54:11 --> Model Class Initialized
INFO - 2018-03-05 15:54:11 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-05 15:54:11 --> Database Driver Class Initialized
INFO - 2018-03-05 15:54:11 --> Model Class Initialized
INFO - 2018-03-05 15:54:11 --> Final output sent to browser
DEBUG - 2018-03-05 15:54:11 --> Total execution time: 0.3879
DEBUG - 2018-03-05 15:54:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 15:54:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 15:54:12 --> Helper loaded: form_helper
INFO - 2018-03-05 15:54:12 --> Form Validation Class Initialized
INFO - 2018-03-05 15:54:12 --> Controller Class Initialized
INFO - 2018-03-05 15:54:12 --> Model Class Initialized
INFO - 2018-03-05 15:54:12 --> Helper loaded: inflector_helper
DEBUG - 2018-03-05 15:54:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-05 15:54:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-05 15:54:12 --> Model Class Initialized
INFO - 2018-03-05 15:54:12 --> Model Class Initialized
INFO - 2018-03-05 15:54:12 --> Model Class Initialized
INFO - 2018-03-05 15:54:12 --> Model Class Initialized
INFO - 2018-03-05 15:54:12 --> Model Class Initialized
INFO - 2018-03-05 15:54:12 --> Model Class Initialized
INFO - 2018-03-05 15:54:12 --> Model Class Initialized
INFO - 2018-03-05 15:54:12 --> Model Class Initialized
INFO - 2018-03-05 15:54:12 --> Model Class Initialized
INFO - 2018-03-05 15:54:12 --> Model Class Initialized
INFO - 2018-03-05 15:54:12 --> Model Class Initialized
INFO - 2018-03-05 15:54:12 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-05 15:54:12 --> Model Class Initialized
INFO - 2018-03-05 15:54:12 --> Final output sent to browser
DEBUG - 2018-03-05 15:54:12 --> Total execution time: 2.2050
INFO - 2018-03-05 10:24:51 --> Config Class Initialized
INFO - 2018-03-05 10:24:51 --> Hooks Class Initialized
DEBUG - 2018-03-05 10:24:51 --> UTF-8 Support Enabled
INFO - 2018-03-05 10:24:51 --> Utf8 Class Initialized
INFO - 2018-03-05 10:24:51 --> URI Class Initialized
INFO - 2018-03-05 10:24:51 --> Router Class Initialized
INFO - 2018-03-05 10:24:51 --> Output Class Initialized
INFO - 2018-03-05 10:24:51 --> Security Class Initialized
DEBUG - 2018-03-05 10:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 10:24:51 --> Input Class Initialized
INFO - 2018-03-05 10:24:51 --> Language Class Initialized
INFO - 2018-03-05 10:24:51 --> Language Class Initialized
INFO - 2018-03-05 10:24:51 --> Config Class Initialized
INFO - 2018-03-05 10:24:51 --> Loader Class Initialized
INFO - 2018-03-05 15:54:51 --> Helper loaded: url_helper
INFO - 2018-03-05 15:54:51 --> Helper loaded: notification_helper
INFO - 2018-03-05 15:54:51 --> Helper loaded: settings_helper
INFO - 2018-03-05 15:54:51 --> Helper loaded: permission_helper
INFO - 2018-03-05 15:54:51 --> Helper loaded: users_helper
INFO - 2018-03-05 15:54:51 --> Database Driver Class Initialized
DEBUG - 2018-03-05 15:54:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 15:54:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 15:54:51 --> Helper loaded: form_helper
INFO - 2018-03-05 15:54:51 --> Form Validation Class Initialized
INFO - 2018-03-05 15:54:51 --> Controller Class Initialized
INFO - 2018-03-05 15:54:51 --> Model Class Initialized
INFO - 2018-03-05 15:54:51 --> Helper loaded: inflector_helper
DEBUG - 2018-03-05 15:54:51 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-05 15:54:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-05 15:54:52 --> Model Class Initialized
INFO - 2018-03-05 15:54:52 --> Model Class Initialized
INFO - 2018-03-05 15:54:52 --> Model Class Initialized
INFO - 2018-03-05 15:54:52 --> Model Class Initialized
INFO - 2018-03-05 15:54:52 --> Model Class Initialized
INFO - 2018-03-05 15:54:52 --> Model Class Initialized
INFO - 2018-03-05 15:54:52 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-05 15:54:52 --> Model Class Initialized
INFO - 2018-03-05 15:54:52 --> Final output sent to browser
DEBUG - 2018-03-05 15:54:52 --> Total execution time: 0.5214
INFO - 2018-03-05 10:24:54 --> Config Class Initialized
INFO - 2018-03-05 10:24:54 --> Hooks Class Initialized
DEBUG - 2018-03-05 10:24:54 --> UTF-8 Support Enabled
INFO - 2018-03-05 10:24:54 --> Utf8 Class Initialized
INFO - 2018-03-05 10:24:54 --> URI Class Initialized
INFO - 2018-03-05 10:24:54 --> Router Class Initialized
INFO - 2018-03-05 10:24:54 --> Output Class Initialized
INFO - 2018-03-05 10:24:54 --> Security Class Initialized
DEBUG - 2018-03-05 10:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 10:24:54 --> Input Class Initialized
INFO - 2018-03-05 10:24:54 --> Language Class Initialized
INFO - 2018-03-05 10:24:55 --> Language Class Initialized
INFO - 2018-03-05 10:24:55 --> Config Class Initialized
INFO - 2018-03-05 10:24:55 --> Loader Class Initialized
INFO - 2018-03-05 15:54:55 --> Helper loaded: url_helper
INFO - 2018-03-05 15:54:56 --> Helper loaded: notification_helper
INFO - 2018-03-05 15:54:56 --> Helper loaded: settings_helper
INFO - 2018-03-05 15:54:56 --> Helper loaded: permission_helper
INFO - 2018-03-05 15:54:56 --> Helper loaded: users_helper
INFO - 2018-03-05 15:54:56 --> Database Driver Class Initialized
DEBUG - 2018-03-05 15:54:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 15:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 15:54:56 --> Helper loaded: form_helper
INFO - 2018-03-05 15:54:56 --> Form Validation Class Initialized
INFO - 2018-03-05 15:54:56 --> Controller Class Initialized
INFO - 2018-03-05 15:54:56 --> Model Class Initialized
INFO - 2018-03-05 15:54:56 --> Helper loaded: inflector_helper
DEBUG - 2018-03-05 15:54:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-05 15:54:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-05 15:54:56 --> Model Class Initialized
INFO - 2018-03-05 15:54:56 --> Model Class Initialized
INFO - 2018-03-05 15:54:56 --> Model Class Initialized
INFO - 2018-03-05 15:54:56 --> Model Class Initialized
INFO - 2018-03-05 15:54:56 --> Model Class Initialized
INFO - 2018-03-05 15:54:56 --> Model Class Initialized
INFO - 2018-03-05 15:54:56 --> Model Class Initialized
INFO - 2018-03-05 15:54:56 --> Model Class Initialized
INFO - 2018-03-05 15:54:56 --> Model Class Initialized
INFO - 2018-03-05 15:54:56 --> Model Class Initialized
INFO - 2018-03-05 15:54:56 --> Model Class Initialized
INFO - 2018-03-05 15:54:56 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-05 15:54:56 --> Model Class Initialized
INFO - 2018-03-05 15:54:56 --> Final output sent to browser
DEBUG - 2018-03-05 15:54:56 --> Total execution time: 3.2773
INFO - 2018-03-05 10:29:31 --> Config Class Initialized
INFO - 2018-03-05 10:29:31 --> Hooks Class Initialized
DEBUG - 2018-03-05 10:29:32 --> UTF-8 Support Enabled
INFO - 2018-03-05 10:29:32 --> Utf8 Class Initialized
INFO - 2018-03-05 10:29:32 --> URI Class Initialized
INFO - 2018-03-05 10:29:32 --> Router Class Initialized
INFO - 2018-03-05 10:29:32 --> Output Class Initialized
INFO - 2018-03-05 10:29:32 --> Security Class Initialized
DEBUG - 2018-03-05 10:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 10:29:32 --> Input Class Initialized
INFO - 2018-03-05 10:29:32 --> Language Class Initialized
INFO - 2018-03-05 10:29:33 --> Language Class Initialized
INFO - 2018-03-05 10:29:33 --> Config Class Initialized
INFO - 2018-03-05 10:29:33 --> Loader Class Initialized
INFO - 2018-03-05 15:59:33 --> Helper loaded: url_helper
INFO - 2018-03-05 15:59:33 --> Helper loaded: notification_helper
INFO - 2018-03-05 15:59:33 --> Helper loaded: settings_helper
INFO - 2018-03-05 15:59:33 --> Helper loaded: permission_helper
INFO - 2018-03-05 15:59:33 --> Helper loaded: users_helper
INFO - 2018-03-05 15:59:33 --> Database Driver Class Initialized
DEBUG - 2018-03-05 15:59:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 15:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 15:59:33 --> Helper loaded: form_helper
INFO - 2018-03-05 15:59:33 --> Form Validation Class Initialized
INFO - 2018-03-05 15:59:33 --> Controller Class Initialized
INFO - 2018-03-05 15:59:33 --> Model Class Initialized
INFO - 2018-03-05 15:59:33 --> Helper loaded: inflector_helper
DEBUG - 2018-03-05 15:59:33 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-05 15:59:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-05 15:59:33 --> Model Class Initialized
INFO - 2018-03-05 15:59:33 --> Model Class Initialized
INFO - 2018-03-05 15:59:33 --> Model Class Initialized
INFO - 2018-03-05 15:59:33 --> Model Class Initialized
INFO - 2018-03-05 15:59:33 --> Model Class Initialized
INFO - 2018-03-05 15:59:33 --> Model Class Initialized
INFO - 2018-03-05 15:59:33 --> Model Class Initialized
INFO - 2018-03-05 15:59:33 --> Model Class Initialized
INFO - 2018-03-05 15:59:33 --> Model Class Initialized
INFO - 2018-03-05 15:59:33 --> Model Class Initialized
INFO - 2018-03-05 15:59:33 --> Model Class Initialized
INFO - 2018-03-05 15:59:33 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-05 15:59:33 --> Model Class Initialized
INFO - 2018-03-05 15:59:33 --> Final output sent to browser
DEBUG - 2018-03-05 15:59:33 --> Total execution time: 1.7958
INFO - 2018-03-05 10:40:44 --> Config Class Initialized
INFO - 2018-03-05 10:40:44 --> Hooks Class Initialized
DEBUG - 2018-03-05 10:40:44 --> UTF-8 Support Enabled
INFO - 2018-03-05 10:40:44 --> Utf8 Class Initialized
INFO - 2018-03-05 10:40:44 --> URI Class Initialized
INFO - 2018-03-05 10:40:44 --> Router Class Initialized
INFO - 2018-03-05 10:40:44 --> Output Class Initialized
INFO - 2018-03-05 10:40:44 --> Security Class Initialized
DEBUG - 2018-03-05 10:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 10:40:44 --> Input Class Initialized
INFO - 2018-03-05 10:40:44 --> Language Class Initialized
INFO - 2018-03-05 10:40:44 --> Language Class Initialized
INFO - 2018-03-05 10:40:44 --> Config Class Initialized
INFO - 2018-03-05 10:40:44 --> Loader Class Initialized
INFO - 2018-03-05 16:10:44 --> Helper loaded: url_helper
INFO - 2018-03-05 16:10:44 --> Helper loaded: notification_helper
INFO - 2018-03-05 16:10:44 --> Helper loaded: settings_helper
INFO - 2018-03-05 16:10:44 --> Helper loaded: permission_helper
INFO - 2018-03-05 16:10:44 --> Helper loaded: users_helper
INFO - 2018-03-05 16:10:44 --> Database Driver Class Initialized
DEBUG - 2018-03-05 16:10:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 16:10:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 16:10:44 --> Helper loaded: form_helper
INFO - 2018-03-05 16:10:44 --> Form Validation Class Initialized
INFO - 2018-03-05 16:10:44 --> Controller Class Initialized
INFO - 2018-03-05 16:10:44 --> Model Class Initialized
INFO - 2018-03-05 16:10:44 --> Helper loaded: inflector_helper
DEBUG - 2018-03-05 16:10:44 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-05 16:10:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-05 16:10:44 --> Model Class Initialized
INFO - 2018-03-05 16:10:44 --> Model Class Initialized
INFO - 2018-03-05 16:10:44 --> Model Class Initialized
INFO - 2018-03-05 16:10:44 --> Model Class Initialized
INFO - 2018-03-05 16:10:44 --> Model Class Initialized
INFO - 2018-03-05 16:10:44 --> Model Class Initialized
INFO - 2018-03-05 16:10:44 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-05 16:10:44 --> Model Class Initialized
INFO - 2018-03-05 16:10:44 --> Final output sent to browser
DEBUG - 2018-03-05 16:10:44 --> Total execution time: 0.1674
INFO - 2018-03-05 10:40:44 --> Config Class Initialized
INFO - 2018-03-05 10:40:44 --> Hooks Class Initialized
DEBUG - 2018-03-05 10:40:45 --> UTF-8 Support Enabled
INFO - 2018-03-05 10:40:45 --> Utf8 Class Initialized
INFO - 2018-03-05 10:40:45 --> URI Class Initialized
INFO - 2018-03-05 10:40:45 --> Router Class Initialized
INFO - 2018-03-05 10:40:45 --> Output Class Initialized
INFO - 2018-03-05 10:40:45 --> Security Class Initialized
DEBUG - 2018-03-05 10:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 10:40:45 --> Input Class Initialized
INFO - 2018-03-05 10:40:45 --> Language Class Initialized
INFO - 2018-03-05 10:40:45 --> Language Class Initialized
INFO - 2018-03-05 10:40:45 --> Config Class Initialized
INFO - 2018-03-05 10:40:45 --> Loader Class Initialized
INFO - 2018-03-05 16:10:45 --> Helper loaded: url_helper
INFO - 2018-03-05 16:10:45 --> Helper loaded: notification_helper
INFO - 2018-03-05 16:10:45 --> Helper loaded: settings_helper
INFO - 2018-03-05 16:10:45 --> Helper loaded: permission_helper
INFO - 2018-03-05 16:10:45 --> Helper loaded: users_helper
INFO - 2018-03-05 16:10:45 --> Database Driver Class Initialized
DEBUG - 2018-03-05 16:10:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 16:10:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 16:10:45 --> Helper loaded: form_helper
INFO - 2018-03-05 16:10:45 --> Form Validation Class Initialized
INFO - 2018-03-05 16:10:45 --> Controller Class Initialized
INFO - 2018-03-05 16:10:45 --> Model Class Initialized
INFO - 2018-03-05 16:10:45 --> Helper loaded: inflector_helper
DEBUG - 2018-03-05 16:10:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-05 16:10:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-05 16:10:45 --> Model Class Initialized
INFO - 2018-03-05 16:10:45 --> Model Class Initialized
INFO - 2018-03-05 16:10:45 --> Model Class Initialized
INFO - 2018-03-05 16:10:45 --> Model Class Initialized
INFO - 2018-03-05 16:10:45 --> Model Class Initialized
INFO - 2018-03-05 16:10:45 --> Model Class Initialized
INFO - 2018-03-05 16:10:45 --> Model Class Initialized
INFO - 2018-03-05 16:10:45 --> Model Class Initialized
INFO - 2018-03-05 16:10:45 --> Model Class Initialized
INFO - 2018-03-05 16:10:45 --> Model Class Initialized
INFO - 2018-03-05 16:10:45 --> Model Class Initialized
INFO - 2018-03-05 16:10:45 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-05 16:10:45 --> Model Class Initialized
INFO - 2018-03-05 16:10:45 --> Final output sent to browser
DEBUG - 2018-03-05 16:10:45 --> Total execution time: 0.9139
INFO - 2018-03-05 10:41:16 --> Config Class Initialized
INFO - 2018-03-05 10:41:16 --> Hooks Class Initialized
DEBUG - 2018-03-05 10:41:16 --> UTF-8 Support Enabled
INFO - 2018-03-05 10:41:16 --> Utf8 Class Initialized
INFO - 2018-03-05 10:41:16 --> URI Class Initialized
INFO - 2018-03-05 10:41:17 --> Router Class Initialized
INFO - 2018-03-05 10:41:17 --> Output Class Initialized
INFO - 2018-03-05 10:41:17 --> Security Class Initialized
DEBUG - 2018-03-05 10:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 10:41:17 --> Input Class Initialized
INFO - 2018-03-05 10:41:17 --> Language Class Initialized
INFO - 2018-03-05 10:41:17 --> Language Class Initialized
INFO - 2018-03-05 10:41:17 --> Config Class Initialized
INFO - 2018-03-05 10:41:17 --> Loader Class Initialized
INFO - 2018-03-05 16:11:17 --> Helper loaded: url_helper
INFO - 2018-03-05 16:11:17 --> Helper loaded: notification_helper
INFO - 2018-03-05 16:11:17 --> Helper loaded: settings_helper
INFO - 2018-03-05 16:11:17 --> Helper loaded: permission_helper
INFO - 2018-03-05 16:11:17 --> Helper loaded: users_helper
INFO - 2018-03-05 16:11:17 --> Database Driver Class Initialized
DEBUG - 2018-03-05 16:11:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 16:11:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 16:11:17 --> Helper loaded: form_helper
INFO - 2018-03-05 16:11:17 --> Form Validation Class Initialized
INFO - 2018-03-05 16:11:17 --> Controller Class Initialized
INFO - 2018-03-05 16:11:17 --> Model Class Initialized
INFO - 2018-03-05 16:11:17 --> Helper loaded: inflector_helper
DEBUG - 2018-03-05 16:11:17 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-05 16:11:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-05 16:11:17 --> Model Class Initialized
INFO - 2018-03-05 16:11:17 --> Model Class Initialized
INFO - 2018-03-05 16:11:17 --> Model Class Initialized
INFO - 2018-03-05 16:11:17 --> Model Class Initialized
INFO - 2018-03-05 16:11:17 --> Model Class Initialized
INFO - 2018-03-05 16:11:17 --> Model Class Initialized
INFO - 2018-03-05 16:11:17 --> Model Class Initialized
INFO - 2018-03-05 16:11:17 --> Model Class Initialized
INFO - 2018-03-05 16:11:17 --> Model Class Initialized
INFO - 2018-03-05 16:11:17 --> Model Class Initialized
INFO - 2018-03-05 16:11:17 --> Model Class Initialized
INFO - 2018-03-05 16:11:17 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-05 16:11:17 --> Model Class Initialized
INFO - 2018-03-05 16:11:17 --> Final output sent to browser
DEBUG - 2018-03-05 16:11:17 --> Total execution time: 1.4143
INFO - 2018-03-05 10:41:23 --> Config Class Initialized
INFO - 2018-03-05 10:41:23 --> Hooks Class Initialized
DEBUG - 2018-03-05 10:41:23 --> UTF-8 Support Enabled
INFO - 2018-03-05 10:41:23 --> Utf8 Class Initialized
INFO - 2018-03-05 10:41:23 --> URI Class Initialized
INFO - 2018-03-05 10:41:23 --> Router Class Initialized
INFO - 2018-03-05 10:41:23 --> Output Class Initialized
INFO - 2018-03-05 10:41:23 --> Security Class Initialized
DEBUG - 2018-03-05 10:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 10:41:24 --> Input Class Initialized
INFO - 2018-03-05 10:41:24 --> Language Class Initialized
INFO - 2018-03-05 10:41:24 --> Language Class Initialized
INFO - 2018-03-05 10:41:24 --> Config Class Initialized
INFO - 2018-03-05 10:41:24 --> Loader Class Initialized
INFO - 2018-03-05 16:11:24 --> Helper loaded: url_helper
INFO - 2018-03-05 16:11:24 --> Helper loaded: notification_helper
INFO - 2018-03-05 16:11:24 --> Helper loaded: settings_helper
INFO - 2018-03-05 16:11:24 --> Helper loaded: permission_helper
INFO - 2018-03-05 16:11:24 --> Helper loaded: users_helper
INFO - 2018-03-05 16:11:25 --> Database Driver Class Initialized
DEBUG - 2018-03-05 16:11:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 16:11:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 16:11:26 --> Helper loaded: form_helper
INFO - 2018-03-05 16:11:26 --> Form Validation Class Initialized
INFO - 2018-03-05 16:11:26 --> Controller Class Initialized
INFO - 2018-03-05 16:11:26 --> Model Class Initialized
INFO - 2018-03-05 16:11:26 --> Helper loaded: inflector_helper
DEBUG - 2018-03-05 16:11:26 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-05 16:11:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-05 16:11:26 --> Model Class Initialized
INFO - 2018-03-05 16:11:26 --> Model Class Initialized
INFO - 2018-03-05 16:11:26 --> Model Class Initialized
INFO - 2018-03-05 16:11:26 --> Model Class Initialized
INFO - 2018-03-05 16:11:26 --> Model Class Initialized
INFO - 2018-03-05 16:11:26 --> Model Class Initialized
INFO - 2018-03-05 16:11:26 --> Model Class Initialized
INFO - 2018-03-05 16:11:26 --> Model Class Initialized
INFO - 2018-03-05 16:11:26 --> Model Class Initialized
INFO - 2018-03-05 16:11:26 --> Model Class Initialized
INFO - 2018-03-05 16:11:26 --> Model Class Initialized
INFO - 2018-03-05 16:11:26 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-05 16:11:26 --> Model Class Initialized
INFO - 2018-03-05 16:11:27 --> Final output sent to browser
DEBUG - 2018-03-05 16:11:27 --> Total execution time: 4.5167
INFO - 2018-03-05 10:41:29 --> Config Class Initialized
INFO - 2018-03-05 10:41:29 --> Hooks Class Initialized
DEBUG - 2018-03-05 10:41:29 --> UTF-8 Support Enabled
INFO - 2018-03-05 10:41:29 --> Utf8 Class Initialized
INFO - 2018-03-05 10:41:29 --> URI Class Initialized
INFO - 2018-03-05 10:41:29 --> Router Class Initialized
INFO - 2018-03-05 10:41:29 --> Output Class Initialized
INFO - 2018-03-05 10:41:29 --> Security Class Initialized
DEBUG - 2018-03-05 10:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 10:41:29 --> Input Class Initialized
INFO - 2018-03-05 10:41:29 --> Language Class Initialized
INFO - 2018-03-05 10:41:30 --> Language Class Initialized
INFO - 2018-03-05 10:41:30 --> Config Class Initialized
INFO - 2018-03-05 10:41:30 --> Loader Class Initialized
INFO - 2018-03-05 16:11:30 --> Helper loaded: url_helper
INFO - 2018-03-05 16:11:30 --> Helper loaded: notification_helper
INFO - 2018-03-05 16:11:30 --> Helper loaded: settings_helper
INFO - 2018-03-05 16:11:30 --> Helper loaded: permission_helper
INFO - 2018-03-05 16:11:30 --> Helper loaded: users_helper
INFO - 2018-03-05 16:11:31 --> Database Driver Class Initialized
DEBUG - 2018-03-05 16:11:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 16:11:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 16:11:31 --> Helper loaded: form_helper
INFO - 2018-03-05 16:11:31 --> Form Validation Class Initialized
INFO - 2018-03-05 16:11:31 --> Controller Class Initialized
INFO - 2018-03-05 16:11:31 --> Model Class Initialized
INFO - 2018-03-05 16:11:31 --> Helper loaded: inflector_helper
DEBUG - 2018-03-05 16:11:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-05 16:11:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-05 16:11:31 --> Model Class Initialized
INFO - 2018-03-05 16:11:31 --> Model Class Initialized
INFO - 2018-03-05 16:11:31 --> Model Class Initialized
INFO - 2018-03-05 16:11:31 --> Model Class Initialized
INFO - 2018-03-05 16:11:31 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-05 16:11:31 --> Final output sent to browser
DEBUG - 2018-03-05 16:11:31 --> Total execution time: 2.2172
INFO - 2018-03-05 10:41:32 --> Config Class Initialized
INFO - 2018-03-05 10:41:32 --> Hooks Class Initialized
DEBUG - 2018-03-05 10:41:32 --> UTF-8 Support Enabled
INFO - 2018-03-05 10:41:32 --> Utf8 Class Initialized
INFO - 2018-03-05 10:41:32 --> URI Class Initialized
INFO - 2018-03-05 10:41:33 --> Router Class Initialized
INFO - 2018-03-05 10:41:33 --> Output Class Initialized
INFO - 2018-03-05 10:41:33 --> Security Class Initialized
DEBUG - 2018-03-05 10:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 10:41:33 --> Input Class Initialized
INFO - 2018-03-05 10:41:33 --> Language Class Initialized
INFO - 2018-03-05 10:41:34 --> Language Class Initialized
INFO - 2018-03-05 10:41:34 --> Config Class Initialized
INFO - 2018-03-05 10:41:34 --> Loader Class Initialized
INFO - 2018-03-05 16:11:34 --> Helper loaded: url_helper
INFO - 2018-03-05 16:11:34 --> Helper loaded: notification_helper
INFO - 2018-03-05 16:11:34 --> Helper loaded: settings_helper
INFO - 2018-03-05 16:11:34 --> Helper loaded: permission_helper
INFO - 2018-03-05 16:11:34 --> Helper loaded: users_helper
INFO - 2018-03-05 10:41:34 --> Config Class Initialized
INFO - 2018-03-05 10:41:34 --> Hooks Class Initialized
DEBUG - 2018-03-05 10:41:34 --> UTF-8 Support Enabled
INFO - 2018-03-05 10:41:34 --> Utf8 Class Initialized
INFO - 2018-03-05 10:41:34 --> URI Class Initialized
INFO - 2018-03-05 10:41:34 --> Router Class Initialized
INFO - 2018-03-05 10:41:34 --> Output Class Initialized
INFO - 2018-03-05 10:41:34 --> Security Class Initialized
DEBUG - 2018-03-05 10:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 10:41:34 --> Input Class Initialized
INFO - 2018-03-05 10:41:34 --> Language Class Initialized
INFO - 2018-03-05 10:41:34 --> Language Class Initialized
INFO - 2018-03-05 10:41:34 --> Config Class Initialized
INFO - 2018-03-05 10:41:34 --> Loader Class Initialized
INFO - 2018-03-05 16:11:34 --> Helper loaded: url_helper
INFO - 2018-03-05 16:11:34 --> Helper loaded: notification_helper
INFO - 2018-03-05 16:11:34 --> Helper loaded: settings_helper
INFO - 2018-03-05 16:11:34 --> Helper loaded: permission_helper
INFO - 2018-03-05 16:11:34 --> Helper loaded: users_helper
INFO - 2018-03-05 16:11:34 --> Database Driver Class Initialized
DEBUG - 2018-03-05 16:11:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 16:11:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 16:11:34 --> Helper loaded: form_helper
INFO - 2018-03-05 16:11:34 --> Form Validation Class Initialized
INFO - 2018-03-05 16:11:34 --> Controller Class Initialized
INFO - 2018-03-05 16:11:34 --> Model Class Initialized
INFO - 2018-03-05 16:11:34 --> Helper loaded: inflector_helper
DEBUG - 2018-03-05 16:11:34 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-05 16:11:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-05 16:11:34 --> Model Class Initialized
INFO - 2018-03-05 16:11:34 --> Model Class Initialized
INFO - 2018-03-05 16:11:34 --> Model Class Initialized
INFO - 2018-03-05 16:11:34 --> Model Class Initialized
INFO - 2018-03-05 16:11:34 --> Model Class Initialized
INFO - 2018-03-05 16:11:34 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-05 16:11:34 --> Model Class Initialized
INFO - 2018-03-05 16:11:34 --> Final output sent to browser
DEBUG - 2018-03-05 16:11:34 --> Total execution time: 0.1203
INFO - 2018-03-05 16:11:34 --> Database Driver Class Initialized
DEBUG - 2018-03-05 16:11:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 16:11:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 16:11:35 --> Helper loaded: form_helper
INFO - 2018-03-05 16:11:35 --> Form Validation Class Initialized
INFO - 2018-03-05 16:11:35 --> Controller Class Initialized
INFO - 2018-03-05 16:11:35 --> Model Class Initialized
INFO - 2018-03-05 16:11:35 --> Helper loaded: inflector_helper
DEBUG - 2018-03-05 16:11:35 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-05 16:11:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-05 16:11:35 --> Model Class Initialized
INFO - 2018-03-05 16:11:35 --> Model Class Initialized
INFO - 2018-03-05 16:11:35 --> Model Class Initialized
INFO - 2018-03-05 16:11:35 --> Model Class Initialized
INFO - 2018-03-05 16:11:35 --> Model Class Initialized
INFO - 2018-03-05 16:11:35 --> Model Class Initialized
INFO - 2018-03-05 16:11:35 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-05 16:11:35 --> Final output sent to browser
DEBUG - 2018-03-05 16:11:35 --> Total execution time: 3.3442
INFO - 2018-03-05 10:41:45 --> Config Class Initialized
INFO - 2018-03-05 10:41:45 --> Hooks Class Initialized
DEBUG - 2018-03-05 10:41:45 --> UTF-8 Support Enabled
INFO - 2018-03-05 10:41:45 --> Utf8 Class Initialized
INFO - 2018-03-05 10:41:45 --> URI Class Initialized
INFO - 2018-03-05 10:41:46 --> Router Class Initialized
INFO - 2018-03-05 10:41:46 --> Output Class Initialized
INFO - 2018-03-05 10:41:46 --> Security Class Initialized
DEBUG - 2018-03-05 10:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 10:41:46 --> Input Class Initialized
INFO - 2018-03-05 10:41:46 --> Language Class Initialized
INFO - 2018-03-05 10:41:47 --> Language Class Initialized
INFO - 2018-03-05 10:41:47 --> Config Class Initialized
INFO - 2018-03-05 10:41:47 --> Loader Class Initialized
INFO - 2018-03-05 16:11:47 --> Helper loaded: url_helper
INFO - 2018-03-05 16:11:47 --> Helper loaded: notification_helper
INFO - 2018-03-05 16:11:47 --> Helper loaded: settings_helper
INFO - 2018-03-05 16:11:47 --> Helper loaded: permission_helper
INFO - 2018-03-05 16:11:47 --> Helper loaded: users_helper
INFO - 2018-03-05 16:11:47 --> Database Driver Class Initialized
DEBUG - 2018-03-05 16:11:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 16:11:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 16:11:47 --> Helper loaded: form_helper
INFO - 2018-03-05 16:11:47 --> Form Validation Class Initialized
INFO - 2018-03-05 16:11:47 --> Controller Class Initialized
INFO - 2018-03-05 16:11:48 --> Model Class Initialized
INFO - 2018-03-05 16:11:48 --> Helper loaded: inflector_helper
DEBUG - 2018-03-05 16:11:48 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-05 16:11:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-05 16:11:48 --> Model Class Initialized
INFO - 2018-03-05 16:11:48 --> Model Class Initialized
INFO - 2018-03-05 16:11:48 --> Model Class Initialized
INFO - 2018-03-05 16:11:48 --> Model Class Initialized
INFO - 2018-03-05 16:11:48 --> Model Class Initialized
INFO - 2018-03-05 16:11:48 --> Model Class Initialized
INFO - 2018-03-05 16:11:48 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-05 16:11:48 --> Final output sent to browser
DEBUG - 2018-03-05 16:11:48 --> Total execution time: 2.6481
INFO - 2018-03-05 10:41:55 --> Config Class Initialized
INFO - 2018-03-05 10:41:55 --> Hooks Class Initialized
DEBUG - 2018-03-05 10:41:55 --> UTF-8 Support Enabled
INFO - 2018-03-05 10:41:55 --> Utf8 Class Initialized
INFO - 2018-03-05 10:41:55 --> URI Class Initialized
INFO - 2018-03-05 10:41:55 --> Router Class Initialized
INFO - 2018-03-05 10:41:55 --> Output Class Initialized
INFO - 2018-03-05 10:41:55 --> Security Class Initialized
DEBUG - 2018-03-05 10:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 10:41:55 --> Input Class Initialized
INFO - 2018-03-05 10:41:55 --> Language Class Initialized
INFO - 2018-03-05 10:41:55 --> Language Class Initialized
INFO - 2018-03-05 10:41:55 --> Config Class Initialized
INFO - 2018-03-05 10:41:55 --> Loader Class Initialized
INFO - 2018-03-05 16:11:55 --> Helper loaded: url_helper
INFO - 2018-03-05 16:11:55 --> Helper loaded: notification_helper
INFO - 2018-03-05 16:11:55 --> Helper loaded: settings_helper
INFO - 2018-03-05 16:11:55 --> Helper loaded: permission_helper
INFO - 2018-03-05 16:11:55 --> Helper loaded: users_helper
INFO - 2018-03-05 16:11:55 --> Database Driver Class Initialized
DEBUG - 2018-03-05 16:11:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 16:11:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 16:11:55 --> Helper loaded: form_helper
INFO - 2018-03-05 16:11:55 --> Form Validation Class Initialized
INFO - 2018-03-05 16:11:55 --> Controller Class Initialized
INFO - 2018-03-05 16:11:55 --> Model Class Initialized
INFO - 2018-03-05 16:11:55 --> Helper loaded: inflector_helper
DEBUG - 2018-03-05 16:11:55 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-05 16:11:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-05 16:11:55 --> Model Class Initialized
INFO - 2018-03-05 16:11:55 --> Model Class Initialized
INFO - 2018-03-05 16:11:55 --> Model Class Initialized
INFO - 2018-03-05 16:11:55 --> Model Class Initialized
INFO - 2018-03-05 16:11:55 --> Model Class Initialized
INFO - 2018-03-05 16:11:55 --> Model Class Initialized
INFO - 2018-03-05 16:11:55 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-05 16:11:55 --> Final output sent to browser
DEBUG - 2018-03-05 16:11:55 --> Total execution time: 0.3173
INFO - 2018-03-05 10:42:01 --> Config Class Initialized
INFO - 2018-03-05 10:42:01 --> Hooks Class Initialized
DEBUG - 2018-03-05 10:42:01 --> UTF-8 Support Enabled
INFO - 2018-03-05 10:42:01 --> Utf8 Class Initialized
INFO - 2018-03-05 10:42:01 --> URI Class Initialized
INFO - 2018-03-05 10:42:01 --> Router Class Initialized
INFO - 2018-03-05 10:42:01 --> Output Class Initialized
INFO - 2018-03-05 10:42:01 --> Security Class Initialized
DEBUG - 2018-03-05 10:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 10:42:01 --> Input Class Initialized
INFO - 2018-03-05 10:42:01 --> Language Class Initialized
INFO - 2018-03-05 10:42:01 --> Language Class Initialized
INFO - 2018-03-05 10:42:01 --> Config Class Initialized
INFO - 2018-03-05 10:42:01 --> Loader Class Initialized
INFO - 2018-03-05 16:12:01 --> Helper loaded: url_helper
INFO - 2018-03-05 16:12:01 --> Helper loaded: notification_helper
INFO - 2018-03-05 16:12:01 --> Helper loaded: settings_helper
INFO - 2018-03-05 16:12:01 --> Helper loaded: permission_helper
INFO - 2018-03-05 16:12:01 --> Helper loaded: users_helper
INFO - 2018-03-05 16:12:01 --> Database Driver Class Initialized
DEBUG - 2018-03-05 16:12:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 16:12:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 16:12:01 --> Helper loaded: form_helper
INFO - 2018-03-05 16:12:01 --> Form Validation Class Initialized
INFO - 2018-03-05 16:12:01 --> Controller Class Initialized
INFO - 2018-03-05 16:12:01 --> Model Class Initialized
INFO - 2018-03-05 16:12:01 --> Helper loaded: inflector_helper
DEBUG - 2018-03-05 16:12:01 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-05 16:12:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-05 16:12:01 --> Model Class Initialized
INFO - 2018-03-05 16:12:01 --> Model Class Initialized
INFO - 2018-03-05 16:12:01 --> Model Class Initialized
INFO - 2018-03-05 16:12:01 --> Model Class Initialized
INFO - 2018-03-05 16:12:01 --> Final output sent to browser
DEBUG - 2018-03-05 16:12:01 --> Total execution time: 0.4043
INFO - 2018-03-05 10:43:03 --> Config Class Initialized
INFO - 2018-03-05 10:43:03 --> Hooks Class Initialized
DEBUG - 2018-03-05 10:43:03 --> UTF-8 Support Enabled
INFO - 2018-03-05 10:43:03 --> Utf8 Class Initialized
INFO - 2018-03-05 10:43:03 --> URI Class Initialized
INFO - 2018-03-05 10:43:03 --> Router Class Initialized
INFO - 2018-03-05 10:43:03 --> Output Class Initialized
INFO - 2018-03-05 10:43:03 --> Security Class Initialized
DEBUG - 2018-03-05 10:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 10:43:03 --> Input Class Initialized
INFO - 2018-03-05 10:43:03 --> Language Class Initialized
INFO - 2018-03-05 10:43:03 --> Language Class Initialized
INFO - 2018-03-05 10:43:03 --> Config Class Initialized
INFO - 2018-03-05 10:43:03 --> Loader Class Initialized
INFO - 2018-03-05 16:13:03 --> Helper loaded: url_helper
INFO - 2018-03-05 16:13:03 --> Helper loaded: notification_helper
INFO - 2018-03-05 16:13:03 --> Helper loaded: settings_helper
INFO - 2018-03-05 16:13:03 --> Helper loaded: permission_helper
INFO - 2018-03-05 16:13:03 --> Helper loaded: users_helper
INFO - 2018-03-05 16:13:03 --> Database Driver Class Initialized
DEBUG - 2018-03-05 16:13:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 16:13:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 16:13:03 --> Helper loaded: form_helper
INFO - 2018-03-05 16:13:03 --> Form Validation Class Initialized
INFO - 2018-03-05 16:13:03 --> Controller Class Initialized
INFO - 2018-03-05 16:13:03 --> Model Class Initialized
INFO - 2018-03-05 16:13:03 --> Helper loaded: inflector_helper
DEBUG - 2018-03-05 16:13:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-05 16:13:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-05 16:13:03 --> Model Class Initialized
INFO - 2018-03-05 16:13:03 --> Model Class Initialized
INFO - 2018-03-05 16:13:03 --> Model Class Initialized
INFO - 2018-03-05 16:13:03 --> Model Class Initialized
INFO - 2018-03-05 16:13:03 --> Model Class Initialized
INFO - 2018-03-05 16:13:03 --> Model Class Initialized
INFO - 2018-03-05 16:13:03 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-05 16:13:03 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-05 16:13:03 --> Final output sent to browser
DEBUG - 2018-03-05 16:13:03 --> Total execution time: 0.2443
INFO - 2018-03-05 10:47:14 --> Config Class Initialized
INFO - 2018-03-05 10:47:14 --> Hooks Class Initialized
DEBUG - 2018-03-05 10:47:14 --> UTF-8 Support Enabled
INFO - 2018-03-05 10:47:14 --> Utf8 Class Initialized
INFO - 2018-03-05 10:47:14 --> URI Class Initialized
INFO - 2018-03-05 10:47:14 --> Router Class Initialized
INFO - 2018-03-05 10:47:14 --> Output Class Initialized
INFO - 2018-03-05 10:47:14 --> Security Class Initialized
DEBUG - 2018-03-05 10:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 10:47:14 --> Input Class Initialized
INFO - 2018-03-05 10:47:14 --> Language Class Initialized
INFO - 2018-03-05 10:47:14 --> Language Class Initialized
INFO - 2018-03-05 10:47:14 --> Config Class Initialized
INFO - 2018-03-05 10:47:14 --> Loader Class Initialized
INFO - 2018-03-05 16:17:14 --> Helper loaded: url_helper
INFO - 2018-03-05 16:17:14 --> Helper loaded: notification_helper
INFO - 2018-03-05 16:17:14 --> Helper loaded: settings_helper
INFO - 2018-03-05 16:17:14 --> Helper loaded: permission_helper
INFO - 2018-03-05 16:17:14 --> Helper loaded: users_helper
INFO - 2018-03-05 16:17:14 --> Database Driver Class Initialized
DEBUG - 2018-03-05 16:17:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 16:17:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 16:17:14 --> Helper loaded: form_helper
INFO - 2018-03-05 16:17:14 --> Form Validation Class Initialized
INFO - 2018-03-05 16:17:14 --> Controller Class Initialized
INFO - 2018-03-05 16:17:14 --> Model Class Initialized
INFO - 2018-03-05 16:17:14 --> Helper loaded: inflector_helper
DEBUG - 2018-03-05 16:17:14 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-05 16:17:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-05 16:17:14 --> Model Class Initialized
INFO - 2018-03-05 16:17:14 --> Model Class Initialized
INFO - 2018-03-05 16:17:14 --> Model Class Initialized
INFO - 2018-03-05 16:17:14 --> Model Class Initialized
INFO - 2018-03-05 16:17:14 --> Model Class Initialized
INFO - 2018-03-05 16:17:14 --> Model Class Initialized
INFO - 2018-03-05 16:17:14 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-05 16:17:14 --> Model Class Initialized
INFO - 2018-03-05 16:17:14 --> Final output sent to browser
DEBUG - 2018-03-05 16:17:14 --> Total execution time: 0.1136
INFO - 2018-03-05 10:47:15 --> Config Class Initialized
INFO - 2018-03-05 10:47:15 --> Hooks Class Initialized
DEBUG - 2018-03-05 10:47:15 --> UTF-8 Support Enabled
INFO - 2018-03-05 10:47:15 --> Utf8 Class Initialized
INFO - 2018-03-05 10:47:15 --> URI Class Initialized
INFO - 2018-03-05 10:47:15 --> Router Class Initialized
INFO - 2018-03-05 10:47:15 --> Output Class Initialized
INFO - 2018-03-05 10:47:16 --> Security Class Initialized
DEBUG - 2018-03-05 10:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 10:47:16 --> Input Class Initialized
INFO - 2018-03-05 10:47:16 --> Language Class Initialized
INFO - 2018-03-05 10:47:17 --> Language Class Initialized
INFO - 2018-03-05 10:47:17 --> Config Class Initialized
INFO - 2018-03-05 10:47:17 --> Loader Class Initialized
INFO - 2018-03-05 16:17:17 --> Helper loaded: url_helper
INFO - 2018-03-05 16:17:17 --> Helper loaded: notification_helper
INFO - 2018-03-05 16:17:17 --> Helper loaded: settings_helper
INFO - 2018-03-05 16:17:17 --> Helper loaded: permission_helper
INFO - 2018-03-05 16:17:17 --> Helper loaded: users_helper
INFO - 2018-03-05 16:17:19 --> Database Driver Class Initialized
DEBUG - 2018-03-05 16:17:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 16:17:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 16:17:19 --> Helper loaded: form_helper
INFO - 2018-03-05 16:17:19 --> Form Validation Class Initialized
INFO - 2018-03-05 16:17:19 --> Controller Class Initialized
INFO - 2018-03-05 16:17:19 --> Model Class Initialized
INFO - 2018-03-05 16:17:19 --> Helper loaded: inflector_helper
DEBUG - 2018-03-05 16:17:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-05 16:17:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-05 16:17:19 --> Model Class Initialized
INFO - 2018-03-05 16:17:19 --> Model Class Initialized
INFO - 2018-03-05 16:17:19 --> Model Class Initialized
INFO - 2018-03-05 16:17:19 --> Model Class Initialized
INFO - 2018-03-05 16:17:19 --> Model Class Initialized
INFO - 2018-03-05 16:17:19 --> Model Class Initialized
INFO - 2018-03-05 16:17:19 --> Model Class Initialized
INFO - 2018-03-05 16:17:19 --> Model Class Initialized
INFO - 2018-03-05 16:17:19 --> Model Class Initialized
INFO - 2018-03-05 16:17:19 --> Model Class Initialized
INFO - 2018-03-05 16:17:19 --> Model Class Initialized
INFO - 2018-03-05 16:17:19 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-05 16:17:19 --> Model Class Initialized
INFO - 2018-03-05 16:17:20 --> Final output sent to browser
DEBUG - 2018-03-05 16:17:20 --> Total execution time: 5.4639
INFO - 2018-03-05 10:47:26 --> Config Class Initialized
INFO - 2018-03-05 10:47:26 --> Hooks Class Initialized
DEBUG - 2018-03-05 10:47:26 --> UTF-8 Support Enabled
INFO - 2018-03-05 10:47:26 --> Utf8 Class Initialized
INFO - 2018-03-05 10:47:26 --> URI Class Initialized
INFO - 2018-03-05 10:47:26 --> Router Class Initialized
INFO - 2018-03-05 10:47:26 --> Output Class Initialized
INFO - 2018-03-05 10:47:26 --> Security Class Initialized
DEBUG - 2018-03-05 10:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 10:47:26 --> Input Class Initialized
INFO - 2018-03-05 10:47:26 --> Language Class Initialized
INFO - 2018-03-05 10:47:26 --> Language Class Initialized
INFO - 2018-03-05 10:47:26 --> Config Class Initialized
INFO - 2018-03-05 10:47:26 --> Loader Class Initialized
INFO - 2018-03-05 16:17:26 --> Helper loaded: url_helper
INFO - 2018-03-05 16:17:26 --> Helper loaded: notification_helper
INFO - 2018-03-05 16:17:26 --> Helper loaded: settings_helper
INFO - 2018-03-05 16:17:26 --> Helper loaded: permission_helper
INFO - 2018-03-05 16:17:26 --> Helper loaded: users_helper
INFO - 2018-03-05 16:17:26 --> Database Driver Class Initialized
DEBUG - 2018-03-05 16:17:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 16:17:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 16:17:26 --> Helper loaded: form_helper
INFO - 2018-03-05 16:17:26 --> Form Validation Class Initialized
INFO - 2018-03-05 16:17:26 --> Controller Class Initialized
INFO - 2018-03-05 16:17:26 --> Model Class Initialized
INFO - 2018-03-05 16:17:26 --> Helper loaded: inflector_helper
DEBUG - 2018-03-05 16:17:26 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-05 16:17:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-05 16:17:26 --> Model Class Initialized
INFO - 2018-03-05 16:17:26 --> Model Class Initialized
INFO - 2018-03-05 16:17:26 --> Model Class Initialized
INFO - 2018-03-05 16:17:26 --> Model Class Initialized
INFO - 2018-03-05 16:17:26 --> Model Class Initialized
INFO - 2018-03-05 16:17:26 --> Model Class Initialized
INFO - 2018-03-05 16:17:26 --> Model Class Initialized
INFO - 2018-03-05 16:17:26 --> Model Class Initialized
INFO - 2018-03-05 16:17:26 --> Model Class Initialized
INFO - 2018-03-05 16:17:26 --> Model Class Initialized
INFO - 2018-03-05 16:17:26 --> Model Class Initialized
INFO - 2018-03-05 16:17:26 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-05 16:17:26 --> Model Class Initialized
INFO - 2018-03-05 16:17:26 --> Final output sent to browser
DEBUG - 2018-03-05 16:17:26 --> Total execution time: 0.1328
INFO - 2018-03-05 10:47:58 --> Config Class Initialized
INFO - 2018-03-05 10:47:58 --> Hooks Class Initialized
DEBUG - 2018-03-05 10:47:58 --> UTF-8 Support Enabled
INFO - 2018-03-05 10:47:58 --> Utf8 Class Initialized
INFO - 2018-03-05 10:47:58 --> Config Class Initialized
INFO - 2018-03-05 10:47:58 --> Hooks Class Initialized
DEBUG - 2018-03-05 10:47:58 --> UTF-8 Support Enabled
INFO - 2018-03-05 10:47:58 --> Utf8 Class Initialized
INFO - 2018-03-05 10:47:58 --> URI Class Initialized
INFO - 2018-03-05 10:47:58 --> Router Class Initialized
INFO - 2018-03-05 10:47:58 --> Output Class Initialized
INFO - 2018-03-05 10:47:58 --> Security Class Initialized
DEBUG - 2018-03-05 10:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 10:47:58 --> Input Class Initialized
INFO - 2018-03-05 10:47:58 --> Language Class Initialized
INFO - 2018-03-05 10:47:58 --> Language Class Initialized
INFO - 2018-03-05 10:47:58 --> Config Class Initialized
INFO - 2018-03-05 10:47:58 --> Loader Class Initialized
INFO - 2018-03-05 16:17:58 --> Helper loaded: url_helper
INFO - 2018-03-05 16:17:58 --> Helper loaded: notification_helper
INFO - 2018-03-05 16:17:58 --> Helper loaded: settings_helper
INFO - 2018-03-05 16:17:58 --> Helper loaded: permission_helper
INFO - 2018-03-05 16:17:58 --> Helper loaded: users_helper
INFO - 2018-03-05 16:17:58 --> Database Driver Class Initialized
DEBUG - 2018-03-05 16:17:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 16:17:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 16:17:58 --> Helper loaded: form_helper
INFO - 2018-03-05 16:17:58 --> Form Validation Class Initialized
INFO - 2018-03-05 16:17:58 --> Controller Class Initialized
INFO - 2018-03-05 16:17:58 --> Model Class Initialized
INFO - 2018-03-05 16:17:58 --> Helper loaded: inflector_helper
DEBUG - 2018-03-05 16:17:58 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-05 16:17:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-05 16:17:58 --> Model Class Initialized
INFO - 2018-03-05 16:17:58 --> Model Class Initialized
INFO - 2018-03-05 16:17:58 --> Model Class Initialized
INFO - 2018-03-05 16:17:58 --> Model Class Initialized
INFO - 2018-03-05 16:17:58 --> Model Class Initialized
INFO - 2018-03-05 16:17:58 --> Model Class Initialized
INFO - 2018-03-05 16:17:58 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-05 16:17:58 --> Model Class Initialized
INFO - 2018-03-05 16:17:58 --> Final output sent to browser
DEBUG - 2018-03-05 16:17:58 --> Total execution time: 0.1223
INFO - 2018-03-05 10:47:58 --> URI Class Initialized
INFO - 2018-03-05 10:47:58 --> Router Class Initialized
INFO - 2018-03-05 10:47:58 --> Output Class Initialized
INFO - 2018-03-05 10:47:58 --> Security Class Initialized
DEBUG - 2018-03-05 10:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 10:47:58 --> Input Class Initialized
INFO - 2018-03-05 10:47:58 --> Language Class Initialized
INFO - 2018-03-05 10:47:59 --> Language Class Initialized
INFO - 2018-03-05 10:47:59 --> Config Class Initialized
INFO - 2018-03-05 10:47:59 --> Loader Class Initialized
INFO - 2018-03-05 16:17:59 --> Helper loaded: url_helper
INFO - 2018-03-05 16:17:59 --> Helper loaded: notification_helper
INFO - 2018-03-05 16:17:59 --> Helper loaded: settings_helper
INFO - 2018-03-05 16:17:59 --> Helper loaded: permission_helper
INFO - 2018-03-05 16:17:59 --> Helper loaded: users_helper
INFO - 2018-03-05 16:18:00 --> Database Driver Class Initialized
DEBUG - 2018-03-05 16:18:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 16:18:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 16:18:00 --> Helper loaded: form_helper
INFO - 2018-03-05 16:18:00 --> Form Validation Class Initialized
INFO - 2018-03-05 16:18:00 --> Controller Class Initialized
INFO - 2018-03-05 16:18:00 --> Model Class Initialized
INFO - 2018-03-05 16:18:00 --> Helper loaded: inflector_helper
DEBUG - 2018-03-05 16:18:00 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-05 16:18:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-05 16:18:00 --> Model Class Initialized
INFO - 2018-03-05 16:18:01 --> Model Class Initialized
INFO - 2018-03-05 16:18:01 --> Model Class Initialized
INFO - 2018-03-05 16:18:01 --> Model Class Initialized
INFO - 2018-03-05 16:18:01 --> Model Class Initialized
INFO - 2018-03-05 16:18:01 --> Model Class Initialized
INFO - 2018-03-05 16:18:01 --> Model Class Initialized
INFO - 2018-03-05 16:18:01 --> Model Class Initialized
INFO - 2018-03-05 16:18:01 --> Model Class Initialized
INFO - 2018-03-05 16:18:01 --> Model Class Initialized
INFO - 2018-03-05 16:18:01 --> Model Class Initialized
INFO - 2018-03-05 16:18:01 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-05 16:18:01 --> Model Class Initialized
INFO - 2018-03-05 16:18:01 --> Final output sent to browser
DEBUG - 2018-03-05 16:18:01 --> Total execution time: 3.1986
INFO - 2018-03-05 10:55:22 --> Config Class Initialized
INFO - 2018-03-05 10:55:22 --> Hooks Class Initialized
DEBUG - 2018-03-05 10:55:22 --> UTF-8 Support Enabled
INFO - 2018-03-05 10:55:22 --> Utf8 Class Initialized
INFO - 2018-03-05 10:55:22 --> URI Class Initialized
INFO - 2018-03-05 10:55:22 --> Router Class Initialized
INFO - 2018-03-05 10:55:22 --> Output Class Initialized
INFO - 2018-03-05 10:55:22 --> Security Class Initialized
INFO - 2018-03-05 10:55:22 --> Config Class Initialized
INFO - 2018-03-05 10:55:22 --> Hooks Class Initialized
DEBUG - 2018-03-05 10:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 10:55:22 --> Input Class Initialized
INFO - 2018-03-05 10:55:22 --> Language Class Initialized
DEBUG - 2018-03-05 10:55:22 --> UTF-8 Support Enabled
INFO - 2018-03-05 10:55:22 --> Utf8 Class Initialized
INFO - 2018-03-05 10:55:22 --> URI Class Initialized
INFO - 2018-03-05 10:55:22 --> Router Class Initialized
INFO - 2018-03-05 10:55:22 --> Output Class Initialized
INFO - 2018-03-05 10:55:22 --> Security Class Initialized
DEBUG - 2018-03-05 10:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 10:55:22 --> Input Class Initialized
INFO - 2018-03-05 10:55:22 --> Language Class Initialized
INFO - 2018-03-05 10:55:22 --> Language Class Initialized
INFO - 2018-03-05 10:55:22 --> Config Class Initialized
INFO - 2018-03-05 10:55:22 --> Loader Class Initialized
INFO - 2018-03-05 16:25:22 --> Helper loaded: url_helper
INFO - 2018-03-05 16:25:22 --> Helper loaded: notification_helper
INFO - 2018-03-05 16:25:22 --> Helper loaded: settings_helper
INFO - 2018-03-05 16:25:22 --> Helper loaded: permission_helper
INFO - 2018-03-05 16:25:22 --> Helper loaded: users_helper
INFO - 2018-03-05 10:55:22 --> Language Class Initialized
INFO - 2018-03-05 10:55:22 --> Config Class Initialized
INFO - 2018-03-05 10:55:22 --> Loader Class Initialized
INFO - 2018-03-05 16:25:22 --> Database Driver Class Initialized
INFO - 2018-03-05 16:25:22 --> Helper loaded: url_helper
INFO - 2018-03-05 16:25:22 --> Helper loaded: notification_helper
INFO - 2018-03-05 16:25:22 --> Helper loaded: settings_helper
INFO - 2018-03-05 16:25:22 --> Helper loaded: permission_helper
INFO - 2018-03-05 16:25:22 --> Helper loaded: users_helper
DEBUG - 2018-03-05 16:25:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 16:25:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 16:25:22 --> Helper loaded: form_helper
INFO - 2018-03-05 16:25:22 --> Form Validation Class Initialized
INFO - 2018-03-05 16:25:22 --> Controller Class Initialized
INFO - 2018-03-05 16:25:22 --> Database Driver Class Initialized
INFO - 2018-03-05 16:25:22 --> Model Class Initialized
INFO - 2018-03-05 16:25:22 --> Helper loaded: inflector_helper
DEBUG - 2018-03-05 16:25:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 16:25:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-03-05 16:25:22 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-05 16:25:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-05 16:25:22 --> Model Class Initialized
INFO - 2018-03-05 16:25:22 --> Model Class Initialized
INFO - 2018-03-05 16:25:22 --> Model Class Initialized
INFO - 2018-03-05 16:25:22 --> Model Class Initialized
INFO - 2018-03-05 16:25:22 --> Model Class Initialized
INFO - 2018-03-05 16:25:22 --> Helper loaded: form_helper
INFO - 2018-03-05 16:25:22 --> Form Validation Class Initialized
INFO - 2018-03-05 16:25:22 --> Controller Class Initialized
INFO - 2018-03-05 16:25:22 --> Model Class Initialized
INFO - 2018-03-05 16:25:22 --> Model Class Initialized
INFO - 2018-03-05 16:25:22 --> Model Class Initialized
INFO - 2018-03-05 16:25:22 --> Model Class Initialized
INFO - 2018-03-05 16:25:22 --> Model Class Initialized
INFO - 2018-03-05 16:25:22 --> Model Class Initialized
INFO - 2018-03-05 16:25:22 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-05 16:25:22 --> Model Class Initialized
INFO - 2018-03-05 16:25:22 --> Model Class Initialized
INFO - 2018-03-05 16:25:22 --> Helper loaded: inflector_helper
DEBUG - 2018-03-05 16:25:22 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-05 16:25:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-05 16:25:22 --> Model Class Initialized
INFO - 2018-03-05 16:25:22 --> Model Class Initialized
INFO - 2018-03-05 16:25:22 --> Model Class Initialized
INFO - 2018-03-05 16:25:22 --> Model Class Initialized
INFO - 2018-03-05 16:25:22 --> Final output sent to browser
DEBUG - 2018-03-05 16:25:22 --> Total execution time: 0.3268
INFO - 2018-03-05 16:25:22 --> Model Class Initialized
INFO - 2018-03-05 16:25:22 --> Model Class Initialized
INFO - 2018-03-05 16:25:22 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-05 16:25:22 --> Model Class Initialized
INFO - 2018-03-05 16:25:22 --> Final output sent to browser
DEBUG - 2018-03-05 16:25:22 --> Total execution time: 0.2968
INFO - 2018-03-05 10:55:54 --> Config Class Initialized
INFO - 2018-03-05 10:55:54 --> Hooks Class Initialized
DEBUG - 2018-03-05 10:55:55 --> UTF-8 Support Enabled
INFO - 2018-03-05 10:55:55 --> Utf8 Class Initialized
INFO - 2018-03-05 10:55:55 --> URI Class Initialized
INFO - 2018-03-05 10:55:55 --> Router Class Initialized
INFO - 2018-03-05 10:55:56 --> Output Class Initialized
INFO - 2018-03-05 10:55:56 --> Security Class Initialized
DEBUG - 2018-03-05 10:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 10:55:56 --> Input Class Initialized
INFO - 2018-03-05 10:55:56 --> Language Class Initialized
INFO - 2018-03-05 10:55:56 --> Config Class Initialized
INFO - 2018-03-05 10:55:56 --> Hooks Class Initialized
DEBUG - 2018-03-05 10:55:56 --> UTF-8 Support Enabled
INFO - 2018-03-05 10:55:56 --> Utf8 Class Initialized
INFO - 2018-03-05 10:55:57 --> URI Class Initialized
INFO - 2018-03-05 10:55:57 --> Router Class Initialized
INFO - 2018-03-05 10:55:57 --> Output Class Initialized
INFO - 2018-03-05 10:55:57 --> Security Class Initialized
DEBUG - 2018-03-05 10:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 10:55:57 --> Input Class Initialized
INFO - 2018-03-05 10:55:57 --> Language Class Initialized
INFO - 2018-03-05 10:55:57 --> Language Class Initialized
INFO - 2018-03-05 10:55:57 --> Config Class Initialized
INFO - 2018-03-05 10:55:57 --> Loader Class Initialized
INFO - 2018-03-05 16:25:57 --> Helper loaded: url_helper
INFO - 2018-03-05 16:25:57 --> Helper loaded: notification_helper
INFO - 2018-03-05 16:25:57 --> Helper loaded: settings_helper
INFO - 2018-03-05 16:25:57 --> Helper loaded: permission_helper
INFO - 2018-03-05 16:25:57 --> Helper loaded: users_helper
INFO - 2018-03-05 16:25:57 --> Database Driver Class Initialized
DEBUG - 2018-03-05 16:25:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 16:25:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 16:25:57 --> Helper loaded: form_helper
INFO - 2018-03-05 16:25:57 --> Form Validation Class Initialized
INFO - 2018-03-05 16:25:57 --> Controller Class Initialized
INFO - 2018-03-05 16:25:57 --> Model Class Initialized
INFO - 2018-03-05 16:25:58 --> Helper loaded: inflector_helper
DEBUG - 2018-03-05 16:25:58 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-05 16:25:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-05 16:25:58 --> Model Class Initialized
INFO - 2018-03-05 16:25:58 --> Model Class Initialized
INFO - 2018-03-05 16:25:58 --> Model Class Initialized
INFO - 2018-03-05 16:25:58 --> Model Class Initialized
INFO - 2018-03-05 16:25:58 --> Model Class Initialized
INFO - 2018-03-05 16:25:58 --> Model Class Initialized
INFO - 2018-03-05 16:25:58 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-05 16:25:58 --> Model Class Initialized
INFO - 2018-03-05 16:25:58 --> Final output sent to browser
DEBUG - 2018-03-05 16:25:58 --> Total execution time: 3.2724
INFO - 2018-03-05 10:55:58 --> Language Class Initialized
INFO - 2018-03-05 10:55:58 --> Config Class Initialized
INFO - 2018-03-05 10:55:58 --> Loader Class Initialized
INFO - 2018-03-05 16:25:58 --> Helper loaded: url_helper
INFO - 2018-03-05 16:25:58 --> Helper loaded: notification_helper
INFO - 2018-03-05 16:25:58 --> Helper loaded: settings_helper
INFO - 2018-03-05 16:25:58 --> Helper loaded: permission_helper
INFO - 2018-03-05 16:25:58 --> Helper loaded: users_helper
INFO - 2018-03-05 16:25:59 --> Database Driver Class Initialized
DEBUG - 2018-03-05 16:25:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 16:25:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 16:26:00 --> Helper loaded: form_helper
INFO - 2018-03-05 16:26:00 --> Form Validation Class Initialized
INFO - 2018-03-05 16:26:00 --> Controller Class Initialized
INFO - 2018-03-05 16:26:00 --> Model Class Initialized
INFO - 2018-03-05 16:26:00 --> Helper loaded: inflector_helper
DEBUG - 2018-03-05 16:26:00 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-05 16:26:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-05 16:26:01 --> Model Class Initialized
INFO - 2018-03-05 16:26:01 --> Model Class Initialized
INFO - 2018-03-05 16:26:01 --> Model Class Initialized
INFO - 2018-03-05 16:26:01 --> Model Class Initialized
INFO - 2018-03-05 16:26:01 --> Model Class Initialized
INFO - 2018-03-05 16:26:01 --> Model Class Initialized
INFO - 2018-03-05 16:26:01 --> Model Class Initialized
INFO - 2018-03-05 16:26:01 --> Model Class Initialized
INFO - 2018-03-05 16:26:01 --> Model Class Initialized
INFO - 2018-03-05 16:26:01 --> Model Class Initialized
INFO - 2018-03-05 16:26:01 --> Model Class Initialized
INFO - 2018-03-05 16:26:01 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-05 16:26:01 --> Model Class Initialized
INFO - 2018-03-05 16:26:02 --> Final output sent to browser
DEBUG - 2018-03-05 16:26:02 --> Total execution time: 5.9238
INFO - 2018-03-05 10:59:46 --> Config Class Initialized
INFO - 2018-03-05 10:59:46 --> Hooks Class Initialized
DEBUG - 2018-03-05 10:59:46 --> UTF-8 Support Enabled
INFO - 2018-03-05 10:59:46 --> Utf8 Class Initialized
INFO - 2018-03-05 10:59:46 --> URI Class Initialized
INFO - 2018-03-05 10:59:46 --> Router Class Initialized
INFO - 2018-03-05 10:59:46 --> Output Class Initialized
INFO - 2018-03-05 10:59:46 --> Security Class Initialized
DEBUG - 2018-03-05 10:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 10:59:46 --> Input Class Initialized
INFO - 2018-03-05 10:59:46 --> Language Class Initialized
INFO - 2018-03-05 10:59:46 --> Language Class Initialized
INFO - 2018-03-05 10:59:46 --> Config Class Initialized
INFO - 2018-03-05 10:59:46 --> Loader Class Initialized
INFO - 2018-03-05 16:29:46 --> Helper loaded: url_helper
INFO - 2018-03-05 16:29:46 --> Helper loaded: notification_helper
INFO - 2018-03-05 16:29:46 --> Helper loaded: settings_helper
INFO - 2018-03-05 16:29:46 --> Helper loaded: permission_helper
INFO - 2018-03-05 16:29:46 --> Helper loaded: users_helper
INFO - 2018-03-05 16:29:46 --> Database Driver Class Initialized
DEBUG - 2018-03-05 16:29:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 16:29:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 16:29:46 --> Helper loaded: form_helper
INFO - 2018-03-05 16:29:46 --> Form Validation Class Initialized
INFO - 2018-03-05 16:29:46 --> Controller Class Initialized
INFO - 2018-03-05 16:29:46 --> Model Class Initialized
INFO - 2018-03-05 16:29:46 --> Helper loaded: inflector_helper
DEBUG - 2018-03-05 16:29:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-05 16:29:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-05 16:29:46 --> Model Class Initialized
INFO - 2018-03-05 16:29:46 --> Model Class Initialized
INFO - 2018-03-05 16:29:46 --> Model Class Initialized
INFO - 2018-03-05 16:29:46 --> Model Class Initialized
INFO - 2018-03-05 16:29:46 --> Model Class Initialized
INFO - 2018-03-05 16:29:46 --> Model Class Initialized
INFO - 2018-03-05 16:29:46 --> Model Class Initialized
INFO - 2018-03-05 16:29:46 --> Model Class Initialized
INFO - 2018-03-05 16:29:46 --> Model Class Initialized
INFO - 2018-03-05 16:29:46 --> Model Class Initialized
INFO - 2018-03-05 16:29:46 --> Model Class Initialized
INFO - 2018-03-05 16:29:46 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-05 16:29:46 --> Model Class Initialized
INFO - 2018-03-05 16:29:46 --> Final output sent to browser
DEBUG - 2018-03-05 16:29:46 --> Total execution time: 0.1288
INFO - 2018-03-05 10:59:47 --> Config Class Initialized
INFO - 2018-03-05 10:59:47 --> Hooks Class Initialized
DEBUG - 2018-03-05 10:59:47 --> UTF-8 Support Enabled
INFO - 2018-03-05 10:59:47 --> Utf8 Class Initialized
INFO - 2018-03-05 10:59:47 --> URI Class Initialized
INFO - 2018-03-05 10:59:47 --> Router Class Initialized
INFO - 2018-03-05 10:59:47 --> Output Class Initialized
INFO - 2018-03-05 10:59:47 --> Security Class Initialized
DEBUG - 2018-03-05 10:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 10:59:47 --> Input Class Initialized
INFO - 2018-03-05 10:59:47 --> Language Class Initialized
INFO - 2018-03-05 10:59:47 --> Language Class Initialized
INFO - 2018-03-05 10:59:47 --> Config Class Initialized
INFO - 2018-03-05 10:59:47 --> Loader Class Initialized
INFO - 2018-03-05 16:29:47 --> Helper loaded: url_helper
INFO - 2018-03-05 16:29:47 --> Helper loaded: notification_helper
INFO - 2018-03-05 16:29:47 --> Helper loaded: settings_helper
INFO - 2018-03-05 16:29:47 --> Helper loaded: permission_helper
INFO - 2018-03-05 16:29:47 --> Helper loaded: users_helper
INFO - 2018-03-05 16:29:47 --> Database Driver Class Initialized
DEBUG - 2018-03-05 16:29:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 16:29:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 16:29:47 --> Helper loaded: form_helper
INFO - 2018-03-05 16:29:47 --> Form Validation Class Initialized
INFO - 2018-03-05 16:29:47 --> Controller Class Initialized
INFO - 2018-03-05 16:29:47 --> Model Class Initialized
INFO - 2018-03-05 16:29:47 --> Helper loaded: inflector_helper
DEBUG - 2018-03-05 16:29:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-05 16:29:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-05 16:29:47 --> Model Class Initialized
INFO - 2018-03-05 16:29:47 --> Model Class Initialized
INFO - 2018-03-05 16:29:47 --> Model Class Initialized
INFO - 2018-03-05 16:29:47 --> Model Class Initialized
INFO - 2018-03-05 16:29:47 --> Model Class Initialized
INFO - 2018-03-05 16:29:47 --> Model Class Initialized
INFO - 2018-03-05 16:29:47 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-05 16:29:47 --> Model Class Initialized
INFO - 2018-03-05 16:29:47 --> Final output sent to browser
DEBUG - 2018-03-05 16:29:47 --> Total execution time: 0.1122
INFO - 2018-03-05 11:03:38 --> Config Class Initialized
INFO - 2018-03-05 11:03:38 --> Hooks Class Initialized
DEBUG - 2018-03-05 11:03:38 --> UTF-8 Support Enabled
INFO - 2018-03-05 11:03:38 --> Utf8 Class Initialized
INFO - 2018-03-05 11:03:38 --> URI Class Initialized
INFO - 2018-03-05 11:03:38 --> Router Class Initialized
INFO - 2018-03-05 11:03:38 --> Output Class Initialized
INFO - 2018-03-05 11:03:38 --> Security Class Initialized
DEBUG - 2018-03-05 11:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 11:03:38 --> Input Class Initialized
INFO - 2018-03-05 11:03:38 --> Language Class Initialized
INFO - 2018-03-05 11:03:38 --> Language Class Initialized
INFO - 2018-03-05 11:03:38 --> Config Class Initialized
INFO - 2018-03-05 11:03:38 --> Loader Class Initialized
INFO - 2018-03-05 16:33:38 --> Helper loaded: url_helper
INFO - 2018-03-05 16:33:38 --> Helper loaded: notification_helper
INFO - 2018-03-05 16:33:38 --> Helper loaded: settings_helper
INFO - 2018-03-05 16:33:38 --> Helper loaded: permission_helper
INFO - 2018-03-05 16:33:38 --> Helper loaded: users_helper
INFO - 2018-03-05 16:33:38 --> Database Driver Class Initialized
DEBUG - 2018-03-05 16:33:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 16:33:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 16:33:38 --> Helper loaded: form_helper
INFO - 2018-03-05 16:33:38 --> Form Validation Class Initialized
INFO - 2018-03-05 16:33:38 --> Controller Class Initialized
INFO - 2018-03-05 16:33:38 --> Model Class Initialized
INFO - 2018-03-05 16:33:38 --> Helper loaded: inflector_helper
DEBUG - 2018-03-05 16:33:38 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-05 16:33:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-05 16:33:38 --> Model Class Initialized
INFO - 2018-03-05 16:33:38 --> Model Class Initialized
INFO - 2018-03-05 16:33:38 --> Model Class Initialized
INFO - 2018-03-05 16:33:38 --> Model Class Initialized
INFO - 2018-03-05 16:33:38 --> Model Class Initialized
INFO - 2018-03-05 16:33:38 --> Model Class Initialized
INFO - 2018-03-05 16:33:38 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-05 16:33:39 --> Model Class Initialized
INFO - 2018-03-05 16:33:39 --> Final output sent to browser
DEBUG - 2018-03-05 16:33:39 --> Total execution time: 0.2854
INFO - 2018-03-05 11:03:40 --> Config Class Initialized
INFO - 2018-03-05 11:03:40 --> Hooks Class Initialized
DEBUG - 2018-03-05 11:03:40 --> UTF-8 Support Enabled
INFO - 2018-03-05 11:03:40 --> Utf8 Class Initialized
INFO - 2018-03-05 11:03:40 --> URI Class Initialized
INFO - 2018-03-05 11:03:40 --> Router Class Initialized
INFO - 2018-03-05 11:03:40 --> Output Class Initialized
INFO - 2018-03-05 11:03:40 --> Security Class Initialized
DEBUG - 2018-03-05 11:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 11:03:41 --> Input Class Initialized
INFO - 2018-03-05 11:03:41 --> Language Class Initialized
INFO - 2018-03-05 11:03:41 --> Language Class Initialized
INFO - 2018-03-05 11:03:41 --> Config Class Initialized
INFO - 2018-03-05 11:03:41 --> Loader Class Initialized
INFO - 2018-03-05 16:33:42 --> Helper loaded: url_helper
INFO - 2018-03-05 16:33:42 --> Helper loaded: notification_helper
INFO - 2018-03-05 16:33:42 --> Helper loaded: settings_helper
INFO - 2018-03-05 16:33:42 --> Helper loaded: permission_helper
INFO - 2018-03-05 16:33:42 --> Helper loaded: users_helper
INFO - 2018-03-05 16:33:42 --> Database Driver Class Initialized
DEBUG - 2018-03-05 16:33:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 16:33:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 16:33:42 --> Helper loaded: form_helper
INFO - 2018-03-05 16:33:42 --> Form Validation Class Initialized
INFO - 2018-03-05 16:33:42 --> Controller Class Initialized
INFO - 2018-03-05 16:33:43 --> Model Class Initialized
INFO - 2018-03-05 16:33:43 --> Helper loaded: inflector_helper
DEBUG - 2018-03-05 16:33:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-05 16:33:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-05 16:33:43 --> Model Class Initialized
INFO - 2018-03-05 16:33:43 --> Model Class Initialized
INFO - 2018-03-05 16:33:43 --> Model Class Initialized
INFO - 2018-03-05 16:33:43 --> Model Class Initialized
INFO - 2018-03-05 16:33:43 --> Model Class Initialized
INFO - 2018-03-05 16:33:43 --> Model Class Initialized
INFO - 2018-03-05 16:33:43 --> Model Class Initialized
INFO - 2018-03-05 16:33:43 --> Model Class Initialized
INFO - 2018-03-05 16:33:43 --> Model Class Initialized
INFO - 2018-03-05 16:33:43 --> Model Class Initialized
INFO - 2018-03-05 16:33:43 --> Model Class Initialized
INFO - 2018-03-05 16:33:43 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-05 16:33:43 --> Model Class Initialized
INFO - 2018-03-05 16:33:43 --> Final output sent to browser
DEBUG - 2018-03-05 16:33:43 --> Total execution time: 3.7828
INFO - 2018-03-05 11:06:56 --> Config Class Initialized
INFO - 2018-03-05 11:06:56 --> Hooks Class Initialized
DEBUG - 2018-03-05 11:06:56 --> UTF-8 Support Enabled
INFO - 2018-03-05 11:06:56 --> Utf8 Class Initialized
INFO - 2018-03-05 11:06:56 --> URI Class Initialized
INFO - 2018-03-05 11:06:56 --> Router Class Initialized
INFO - 2018-03-05 11:06:56 --> Output Class Initialized
INFO - 2018-03-05 11:06:56 --> Security Class Initialized
DEBUG - 2018-03-05 11:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 11:06:56 --> Input Class Initialized
INFO - 2018-03-05 11:06:56 --> Language Class Initialized
INFO - 2018-03-05 11:06:56 --> Language Class Initialized
INFO - 2018-03-05 11:06:56 --> Config Class Initialized
INFO - 2018-03-05 11:06:56 --> Loader Class Initialized
INFO - 2018-03-05 16:36:56 --> Helper loaded: url_helper
INFO - 2018-03-05 16:36:56 --> Helper loaded: notification_helper
INFO - 2018-03-05 16:36:56 --> Helper loaded: settings_helper
INFO - 2018-03-05 16:36:56 --> Helper loaded: permission_helper
INFO - 2018-03-05 16:36:56 --> Helper loaded: users_helper
INFO - 2018-03-05 16:36:56 --> Database Driver Class Initialized
DEBUG - 2018-03-05 16:36:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 16:36:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 16:36:56 --> Helper loaded: form_helper
INFO - 2018-03-05 16:36:56 --> Form Validation Class Initialized
INFO - 2018-03-05 16:36:56 --> Controller Class Initialized
INFO - 2018-03-05 16:36:56 --> Model Class Initialized
INFO - 2018-03-05 16:36:56 --> Helper loaded: inflector_helper
DEBUG - 2018-03-05 16:36:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-05 16:36:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-05 16:36:56 --> Model Class Initialized
INFO - 2018-03-05 16:36:56 --> Model Class Initialized
INFO - 2018-03-05 16:36:56 --> Model Class Initialized
INFO - 2018-03-05 16:36:56 --> Model Class Initialized
INFO - 2018-03-05 16:36:56 --> Model Class Initialized
INFO - 2018-03-05 16:36:56 --> Model Class Initialized
INFO - 2018-03-05 16:36:56 --> Model Class Initialized
INFO - 2018-03-05 16:36:56 --> Model Class Initialized
INFO - 2018-03-05 16:36:56 --> Model Class Initialized
INFO - 2018-03-05 16:36:56 --> Model Class Initialized
INFO - 2018-03-05 16:36:56 --> Model Class Initialized
INFO - 2018-03-05 16:36:56 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-05 16:36:56 --> Model Class Initialized
INFO - 2018-03-05 16:36:56 --> Final output sent to browser
DEBUG - 2018-03-05 16:36:56 --> Total execution time: 0.2874
INFO - 2018-03-05 11:06:58 --> Config Class Initialized
INFO - 2018-03-05 11:06:58 --> Hooks Class Initialized
DEBUG - 2018-03-05 11:06:58 --> UTF-8 Support Enabled
INFO - 2018-03-05 11:06:58 --> Utf8 Class Initialized
INFO - 2018-03-05 11:06:58 --> URI Class Initialized
INFO - 2018-03-05 11:06:58 --> Router Class Initialized
INFO - 2018-03-05 11:06:58 --> Output Class Initialized
INFO - 2018-03-05 11:06:58 --> Security Class Initialized
DEBUG - 2018-03-05 11:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 11:06:59 --> Input Class Initialized
INFO - 2018-03-05 11:06:59 --> Language Class Initialized
INFO - 2018-03-05 11:06:59 --> Language Class Initialized
INFO - 2018-03-05 11:06:59 --> Config Class Initialized
INFO - 2018-03-05 11:06:59 --> Loader Class Initialized
INFO - 2018-03-05 16:37:00 --> Helper loaded: url_helper
INFO - 2018-03-05 16:37:00 --> Helper loaded: notification_helper
INFO - 2018-03-05 16:37:00 --> Helper loaded: settings_helper
INFO - 2018-03-05 16:37:00 --> Helper loaded: permission_helper
INFO - 2018-03-05 16:37:00 --> Helper loaded: users_helper
INFO - 2018-03-05 16:37:00 --> Database Driver Class Initialized
DEBUG - 2018-03-05 16:37:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 16:37:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 16:37:00 --> Helper loaded: form_helper
INFO - 2018-03-05 16:37:00 --> Form Validation Class Initialized
INFO - 2018-03-05 16:37:00 --> Controller Class Initialized
INFO - 2018-03-05 16:37:00 --> Model Class Initialized
INFO - 2018-03-05 16:37:00 --> Helper loaded: inflector_helper
DEBUG - 2018-03-05 16:37:00 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-05 16:37:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-05 16:37:00 --> Model Class Initialized
INFO - 2018-03-05 16:37:00 --> Model Class Initialized
INFO - 2018-03-05 16:37:00 --> Model Class Initialized
INFO - 2018-03-05 16:37:00 --> Model Class Initialized
INFO - 2018-03-05 16:37:00 --> Model Class Initialized
INFO - 2018-03-05 16:37:00 --> Model Class Initialized
INFO - 2018-03-05 16:37:00 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-05 16:37:00 --> Model Class Initialized
INFO - 2018-03-05 16:37:00 --> Final output sent to browser
DEBUG - 2018-03-05 16:37:00 --> Total execution time: 2.6627
INFO - 2018-03-05 11:07:40 --> Config Class Initialized
INFO - 2018-03-05 11:07:40 --> Hooks Class Initialized
DEBUG - 2018-03-05 11:07:40 --> UTF-8 Support Enabled
INFO - 2018-03-05 11:07:40 --> Utf8 Class Initialized
INFO - 2018-03-05 11:07:40 --> URI Class Initialized
INFO - 2018-03-05 11:07:40 --> Router Class Initialized
INFO - 2018-03-05 11:07:40 --> Output Class Initialized
INFO - 2018-03-05 11:07:40 --> Security Class Initialized
DEBUG - 2018-03-05 11:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 11:07:40 --> Input Class Initialized
INFO - 2018-03-05 11:07:40 --> Language Class Initialized
INFO - 2018-03-05 11:07:40 --> Config Class Initialized
INFO - 2018-03-05 11:07:40 --> Hooks Class Initialized
DEBUG - 2018-03-05 11:07:40 --> UTF-8 Support Enabled
INFO - 2018-03-05 11:07:40 --> Utf8 Class Initialized
INFO - 2018-03-05 11:07:40 --> URI Class Initialized
INFO - 2018-03-05 11:07:40 --> Language Class Initialized
INFO - 2018-03-05 11:07:40 --> Config Class Initialized
INFO - 2018-03-05 11:07:40 --> Loader Class Initialized
INFO - 2018-03-05 16:37:40 --> Helper loaded: url_helper
INFO - 2018-03-05 16:37:40 --> Helper loaded: notification_helper
INFO - 2018-03-05 16:37:40 --> Helper loaded: settings_helper
INFO - 2018-03-05 16:37:40 --> Helper loaded: permission_helper
INFO - 2018-03-05 16:37:40 --> Helper loaded: users_helper
INFO - 2018-03-05 11:07:40 --> Router Class Initialized
INFO - 2018-03-05 11:07:40 --> Output Class Initialized
INFO - 2018-03-05 11:07:40 --> Security Class Initialized
INFO - 2018-03-05 16:37:40 --> Database Driver Class Initialized
DEBUG - 2018-03-05 11:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 11:07:40 --> Input Class Initialized
DEBUG - 2018-03-05 16:37:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 16:37:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 11:07:40 --> Language Class Initialized
INFO - 2018-03-05 16:37:40 --> Helper loaded: form_helper
INFO - 2018-03-05 16:37:40 --> Form Validation Class Initialized
INFO - 2018-03-05 16:37:40 --> Controller Class Initialized
INFO - 2018-03-05 16:37:40 --> Model Class Initialized
INFO - 2018-03-05 16:37:40 --> Helper loaded: inflector_helper
DEBUG - 2018-03-05 16:37:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-05 16:37:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-05 11:07:40 --> Language Class Initialized
INFO - 2018-03-05 11:07:40 --> Config Class Initialized
INFO - 2018-03-05 11:07:40 --> Loader Class Initialized
INFO - 2018-03-05 16:37:40 --> Helper loaded: url_helper
INFO - 2018-03-05 16:37:40 --> Helper loaded: notification_helper
INFO - 2018-03-05 16:37:40 --> Helper loaded: settings_helper
INFO - 2018-03-05 16:37:40 --> Helper loaded: permission_helper
INFO - 2018-03-05 16:37:40 --> Helper loaded: users_helper
INFO - 2018-03-05 16:37:40 --> Model Class Initialized
INFO - 2018-03-05 16:37:40 --> Model Class Initialized
INFO - 2018-03-05 16:37:40 --> Database Driver Class Initialized
DEBUG - 2018-03-05 16:37:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 16:37:40 --> Model Class Initialized
INFO - 2018-03-05 16:37:40 --> Model Class Initialized
INFO - 2018-03-05 16:37:40 --> Model Class Initialized
INFO - 2018-03-05 16:37:40 --> Model Class Initialized
INFO - 2018-03-05 16:37:40 --> Model Class Initialized
INFO - 2018-03-05 16:37:40 --> Model Class Initialized
INFO - 2018-03-05 16:37:40 --> Model Class Initialized
INFO - 2018-03-05 16:37:41 --> Model Class Initialized
INFO - 2018-03-05 16:37:41 --> Model Class Initialized
INFO - 2018-03-05 16:37:41 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-05 16:37:41 --> Model Class Initialized
INFO - 2018-03-05 16:37:41 --> Final output sent to browser
DEBUG - 2018-03-05 16:37:41 --> Total execution time: 1.3949
INFO - 2018-03-05 16:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 16:37:41 --> Helper loaded: form_helper
INFO - 2018-03-05 16:37:41 --> Form Validation Class Initialized
INFO - 2018-03-05 16:37:41 --> Controller Class Initialized
INFO - 2018-03-05 16:37:42 --> Model Class Initialized
INFO - 2018-03-05 16:37:42 --> Helper loaded: inflector_helper
DEBUG - 2018-03-05 16:37:42 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-05 16:37:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-05 16:37:42 --> Model Class Initialized
INFO - 2018-03-05 16:37:42 --> Model Class Initialized
INFO - 2018-03-05 16:37:42 --> Model Class Initialized
INFO - 2018-03-05 16:37:42 --> Model Class Initialized
INFO - 2018-03-05 16:37:42 --> Model Class Initialized
INFO - 2018-03-05 16:37:42 --> Model Class Initialized
INFO - 2018-03-05 16:37:42 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-05 16:37:42 --> Model Class Initialized
INFO - 2018-03-05 16:37:42 --> Final output sent to browser
DEBUG - 2018-03-05 16:37:42 --> Total execution time: 1.7216
INFO - 2018-03-05 11:39:51 --> Config Class Initialized
INFO - 2018-03-05 11:39:51 --> Hooks Class Initialized
DEBUG - 2018-03-05 11:39:51 --> UTF-8 Support Enabled
INFO - 2018-03-05 11:39:51 --> Utf8 Class Initialized
INFO - 2018-03-05 11:39:51 --> URI Class Initialized
INFO - 2018-03-05 11:39:51 --> Router Class Initialized
INFO - 2018-03-05 11:39:51 --> Output Class Initialized
INFO - 2018-03-05 11:39:51 --> Security Class Initialized
DEBUG - 2018-03-05 11:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 11:39:51 --> Input Class Initialized
INFO - 2018-03-05 11:39:51 --> Language Class Initialized
INFO - 2018-03-05 11:39:51 --> Language Class Initialized
INFO - 2018-03-05 11:39:51 --> Config Class Initialized
INFO - 2018-03-05 11:39:51 --> Loader Class Initialized
INFO - 2018-03-05 17:09:51 --> Helper loaded: url_helper
INFO - 2018-03-05 17:09:51 --> Helper loaded: notification_helper
INFO - 2018-03-05 17:09:51 --> Helper loaded: settings_helper
INFO - 2018-03-05 17:09:51 --> Helper loaded: permission_helper
INFO - 2018-03-05 17:09:51 --> Helper loaded: users_helper
INFO - 2018-03-05 17:09:51 --> Database Driver Class Initialized
DEBUG - 2018-03-05 17:09:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 17:09:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 17:09:51 --> Helper loaded: form_helper
INFO - 2018-03-05 17:09:51 --> Form Validation Class Initialized
INFO - 2018-03-05 17:09:51 --> Controller Class Initialized
INFO - 2018-03-05 17:09:51 --> Model Class Initialized
INFO - 2018-03-05 17:09:51 --> Helper loaded: inflector_helper
DEBUG - 2018-03-05 17:09:51 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-05 17:09:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-05 17:09:51 --> Model Class Initialized
INFO - 2018-03-05 17:09:51 --> Model Class Initialized
INFO - 2018-03-05 17:09:51 --> Model Class Initialized
INFO - 2018-03-05 17:09:51 --> Model Class Initialized
INFO - 2018-03-05 17:09:51 --> Model Class Initialized
INFO - 2018-03-05 17:09:51 --> Model Class Initialized
INFO - 2018-03-05 17:09:51 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-05 17:09:51 --> Model Class Initialized
INFO - 2018-03-05 17:09:51 --> Final output sent to browser
DEBUG - 2018-03-05 17:09:51 --> Total execution time: 0.1000
INFO - 2018-03-05 11:39:52 --> Config Class Initialized
INFO - 2018-03-05 11:39:52 --> Hooks Class Initialized
DEBUG - 2018-03-05 11:39:52 --> UTF-8 Support Enabled
INFO - 2018-03-05 11:39:52 --> Utf8 Class Initialized
INFO - 2018-03-05 11:39:52 --> URI Class Initialized
INFO - 2018-03-05 11:39:53 --> Router Class Initialized
INFO - 2018-03-05 11:39:53 --> Output Class Initialized
INFO - 2018-03-05 11:39:53 --> Security Class Initialized
DEBUG - 2018-03-05 11:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 11:39:53 --> Input Class Initialized
INFO - 2018-03-05 11:39:53 --> Language Class Initialized
INFO - 2018-03-05 11:39:54 --> Language Class Initialized
INFO - 2018-03-05 11:39:54 --> Config Class Initialized
INFO - 2018-03-05 11:39:54 --> Loader Class Initialized
INFO - 2018-03-05 17:09:54 --> Helper loaded: url_helper
INFO - 2018-03-05 17:09:54 --> Helper loaded: notification_helper
INFO - 2018-03-05 17:09:54 --> Helper loaded: settings_helper
INFO - 2018-03-05 17:09:54 --> Helper loaded: permission_helper
INFO - 2018-03-05 17:09:54 --> Helper loaded: users_helper
INFO - 2018-03-05 17:09:54 --> Database Driver Class Initialized
DEBUG - 2018-03-05 17:09:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 17:09:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 17:09:55 --> Helper loaded: form_helper
INFO - 2018-03-05 17:09:55 --> Form Validation Class Initialized
INFO - 2018-03-05 17:09:55 --> Controller Class Initialized
INFO - 2018-03-05 17:09:55 --> Model Class Initialized
INFO - 2018-03-05 17:09:55 --> Helper loaded: inflector_helper
DEBUG - 2018-03-05 17:09:55 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-05 17:09:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-05 17:09:55 --> Model Class Initialized
INFO - 2018-03-05 17:09:55 --> Model Class Initialized
INFO - 2018-03-05 17:09:55 --> Model Class Initialized
INFO - 2018-03-05 17:09:55 --> Model Class Initialized
INFO - 2018-03-05 17:09:55 --> Model Class Initialized
INFO - 2018-03-05 17:09:55 --> Model Class Initialized
INFO - 2018-03-05 17:09:55 --> Model Class Initialized
INFO - 2018-03-05 17:09:55 --> Model Class Initialized
INFO - 2018-03-05 17:09:55 --> Model Class Initialized
INFO - 2018-03-05 17:09:55 --> Model Class Initialized
INFO - 2018-03-05 17:09:55 --> Model Class Initialized
INFO - 2018-03-05 17:09:55 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-05 17:09:55 --> Model Class Initialized
INFO - 2018-03-05 17:09:55 --> Final output sent to browser
DEBUG - 2018-03-05 17:09:55 --> Total execution time: 2.4399
INFO - 2018-03-05 11:53:22 --> Config Class Initialized
INFO - 2018-03-05 11:53:22 --> Hooks Class Initialized
DEBUG - 2018-03-05 11:53:22 --> UTF-8 Support Enabled
INFO - 2018-03-05 11:53:22 --> Utf8 Class Initialized
INFO - 2018-03-05 11:53:22 --> URI Class Initialized
INFO - 2018-03-05 11:53:22 --> Router Class Initialized
INFO - 2018-03-05 11:53:22 --> Output Class Initialized
INFO - 2018-03-05 11:53:22 --> Security Class Initialized
DEBUG - 2018-03-05 11:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 11:53:22 --> Input Class Initialized
INFO - 2018-03-05 11:53:22 --> Language Class Initialized
INFO - 2018-03-05 11:53:22 --> Language Class Initialized
INFO - 2018-03-05 11:53:22 --> Config Class Initialized
INFO - 2018-03-05 11:53:22 --> Loader Class Initialized
INFO - 2018-03-05 11:53:22 --> Config Class Initialized
INFO - 2018-03-05 11:53:22 --> Hooks Class Initialized
DEBUG - 2018-03-05 11:53:22 --> UTF-8 Support Enabled
INFO - 2018-03-05 11:53:22 --> Utf8 Class Initialized
INFO - 2018-03-05 17:23:22 --> Helper loaded: url_helper
INFO - 2018-03-05 17:23:22 --> Helper loaded: notification_helper
INFO - 2018-03-05 17:23:22 --> Helper loaded: settings_helper
INFO - 2018-03-05 17:23:22 --> Helper loaded: permission_helper
INFO - 2018-03-05 17:23:23 --> Helper loaded: users_helper
INFO - 2018-03-05 11:53:23 --> URI Class Initialized
INFO - 2018-03-05 11:53:23 --> Router Class Initialized
INFO - 2018-03-05 11:53:23 --> Output Class Initialized
INFO - 2018-03-05 11:53:23 --> Security Class Initialized
INFO - 2018-03-05 17:23:23 --> Database Driver Class Initialized
DEBUG - 2018-03-05 11:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-05 17:23:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 17:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 11:53:23 --> Input Class Initialized
INFO - 2018-03-05 17:23:23 --> Helper loaded: form_helper
INFO - 2018-03-05 17:23:23 --> Form Validation Class Initialized
INFO - 2018-03-05 17:23:23 --> Controller Class Initialized
INFO - 2018-03-05 17:23:23 --> Model Class Initialized
INFO - 2018-03-05 17:23:23 --> Helper loaded: inflector_helper
DEBUG - 2018-03-05 17:23:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-05 17:23:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-05 17:23:23 --> Model Class Initialized
INFO - 2018-03-05 17:23:23 --> Model Class Initialized
INFO - 2018-03-05 17:23:23 --> Model Class Initialized
INFO - 2018-03-05 17:23:23 --> Model Class Initialized
INFO - 2018-03-05 17:23:23 --> Model Class Initialized
INFO - 2018-03-05 17:23:23 --> Model Class Initialized
INFO - 2018-03-05 17:23:23 --> Model Class Initialized
INFO - 2018-03-05 17:23:23 --> Model Class Initialized
INFO - 2018-03-05 17:23:23 --> Model Class Initialized
INFO - 2018-03-05 17:23:23 --> Model Class Initialized
INFO - 2018-03-05 17:23:23 --> Model Class Initialized
INFO - 2018-03-05 17:23:23 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-05 17:23:23 --> Model Class Initialized
INFO - 2018-03-05 11:53:23 --> Language Class Initialized
INFO - 2018-03-05 17:23:23 --> Final output sent to browser
DEBUG - 2018-03-05 17:23:23 --> Total execution time: 1.4886
INFO - 2018-03-05 11:53:24 --> Language Class Initialized
INFO - 2018-03-05 11:53:24 --> Config Class Initialized
INFO - 2018-03-05 11:53:24 --> Loader Class Initialized
INFO - 2018-03-05 17:23:24 --> Helper loaded: url_helper
INFO - 2018-03-05 17:23:24 --> Helper loaded: notification_helper
INFO - 2018-03-05 17:23:24 --> Helper loaded: settings_helper
INFO - 2018-03-05 17:23:24 --> Helper loaded: permission_helper
INFO - 2018-03-05 17:23:24 --> Helper loaded: users_helper
INFO - 2018-03-05 17:23:24 --> Database Driver Class Initialized
DEBUG - 2018-03-05 17:23:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 17:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 17:23:24 --> Helper loaded: form_helper
INFO - 2018-03-05 17:23:24 --> Form Validation Class Initialized
INFO - 2018-03-05 17:23:24 --> Controller Class Initialized
INFO - 2018-03-05 17:23:24 --> Model Class Initialized
INFO - 2018-03-05 17:23:24 --> Helper loaded: inflector_helper
DEBUG - 2018-03-05 17:23:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-05 17:23:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-05 17:23:24 --> Model Class Initialized
INFO - 2018-03-05 17:23:24 --> Model Class Initialized
INFO - 2018-03-05 17:23:24 --> Model Class Initialized
INFO - 2018-03-05 17:23:24 --> Model Class Initialized
INFO - 2018-03-05 17:23:25 --> Model Class Initialized
INFO - 2018-03-05 17:23:25 --> Model Class Initialized
INFO - 2018-03-05 17:23:25 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-05 17:23:25 --> Model Class Initialized
INFO - 2018-03-05 17:23:25 --> Final output sent to browser
DEBUG - 2018-03-05 17:23:25 --> Total execution time: 2.3713
INFO - 2018-03-05 11:53:51 --> Config Class Initialized
INFO - 2018-03-05 11:53:51 --> Hooks Class Initialized
DEBUG - 2018-03-05 11:53:51 --> UTF-8 Support Enabled
INFO - 2018-03-05 11:53:51 --> Utf8 Class Initialized
INFO - 2018-03-05 11:53:51 --> URI Class Initialized
INFO - 2018-03-05 11:53:51 --> Router Class Initialized
INFO - 2018-03-05 11:53:51 --> Output Class Initialized
INFO - 2018-03-05 11:53:51 --> Security Class Initialized
DEBUG - 2018-03-05 11:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 11:53:51 --> Input Class Initialized
INFO - 2018-03-05 11:53:51 --> Language Class Initialized
INFO - 2018-03-05 11:53:51 --> Language Class Initialized
INFO - 2018-03-05 11:53:51 --> Config Class Initialized
INFO - 2018-03-05 11:53:51 --> Loader Class Initialized
INFO - 2018-03-05 17:23:51 --> Helper loaded: url_helper
INFO - 2018-03-05 17:23:51 --> Helper loaded: notification_helper
INFO - 2018-03-05 17:23:51 --> Helper loaded: settings_helper
INFO - 2018-03-05 17:23:51 --> Helper loaded: permission_helper
INFO - 2018-03-05 17:23:51 --> Helper loaded: users_helper
INFO - 2018-03-05 17:23:51 --> Database Driver Class Initialized
DEBUG - 2018-03-05 17:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 17:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 17:23:51 --> Helper loaded: form_helper
INFO - 2018-03-05 17:23:51 --> Form Validation Class Initialized
INFO - 2018-03-05 17:23:51 --> Controller Class Initialized
INFO - 2018-03-05 17:23:51 --> Model Class Initialized
INFO - 2018-03-05 17:23:51 --> Helper loaded: inflector_helper
DEBUG - 2018-03-05 17:23:51 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-05 17:23:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-05 17:23:51 --> Model Class Initialized
INFO - 2018-03-05 17:23:51 --> Model Class Initialized
INFO - 2018-03-05 17:23:51 --> Model Class Initialized
INFO - 2018-03-05 17:23:51 --> Model Class Initialized
INFO - 2018-03-05 17:23:51 --> Model Class Initialized
INFO - 2018-03-05 17:23:51 --> Model Class Initialized
INFO - 2018-03-05 17:23:51 --> Model Class Initialized
INFO - 2018-03-05 17:23:51 --> Model Class Initialized
INFO - 2018-03-05 17:23:51 --> Model Class Initialized
INFO - 2018-03-05 17:23:51 --> Model Class Initialized
INFO - 2018-03-05 17:23:51 --> Model Class Initialized
INFO - 2018-03-05 17:23:51 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-05 17:23:51 --> Model Class Initialized
INFO - 2018-03-05 17:23:51 --> Final output sent to browser
DEBUG - 2018-03-05 17:23:51 --> Total execution time: 0.1345
INFO - 2018-03-05 11:54:00 --> Config Class Initialized
INFO - 2018-03-05 11:54:00 --> Hooks Class Initialized
DEBUG - 2018-03-05 11:54:00 --> UTF-8 Support Enabled
INFO - 2018-03-05 11:54:00 --> Utf8 Class Initialized
INFO - 2018-03-05 11:54:00 --> URI Class Initialized
INFO - 2018-03-05 11:54:00 --> Router Class Initialized
INFO - 2018-03-05 11:54:00 --> Output Class Initialized
INFO - 2018-03-05 11:54:01 --> Security Class Initialized
DEBUG - 2018-03-05 11:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 11:54:01 --> Input Class Initialized
INFO - 2018-03-05 11:54:01 --> Language Class Initialized
INFO - 2018-03-05 11:54:01 --> Language Class Initialized
INFO - 2018-03-05 11:54:01 --> Config Class Initialized
INFO - 2018-03-05 11:54:01 --> Loader Class Initialized
INFO - 2018-03-05 17:24:01 --> Helper loaded: url_helper
INFO - 2018-03-05 17:24:01 --> Helper loaded: notification_helper
INFO - 2018-03-05 17:24:01 --> Helper loaded: settings_helper
INFO - 2018-03-05 17:24:01 --> Helper loaded: permission_helper
INFO - 2018-03-05 17:24:01 --> Helper loaded: users_helper
INFO - 2018-03-05 17:24:01 --> Database Driver Class Initialized
DEBUG - 2018-03-05 17:24:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 17:24:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 17:24:01 --> Helper loaded: form_helper
INFO - 2018-03-05 17:24:01 --> Form Validation Class Initialized
INFO - 2018-03-05 17:24:01 --> Controller Class Initialized
INFO - 2018-03-05 17:24:01 --> Model Class Initialized
INFO - 2018-03-05 17:24:01 --> Helper loaded: inflector_helper
DEBUG - 2018-03-05 17:24:01 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-05 17:24:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-05 17:24:01 --> Model Class Initialized
INFO - 2018-03-05 17:24:01 --> Model Class Initialized
INFO - 2018-03-05 17:24:01 --> Model Class Initialized
INFO - 2018-03-05 17:24:01 --> Model Class Initialized
INFO - 2018-03-05 17:24:01 --> Model Class Initialized
INFO - 2018-03-05 17:24:01 --> Model Class Initialized
INFO - 2018-03-05 17:24:01 --> Model Class Initialized
INFO - 2018-03-05 17:24:01 --> Model Class Initialized
INFO - 2018-03-05 17:24:01 --> Model Class Initialized
INFO - 2018-03-05 17:24:01 --> Model Class Initialized
INFO - 2018-03-05 17:24:01 --> Model Class Initialized
INFO - 2018-03-05 17:24:01 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-05 17:24:01 --> Model Class Initialized
INFO - 2018-03-05 17:24:01 --> Final output sent to browser
DEBUG - 2018-03-05 17:24:01 --> Total execution time: 0.6295
INFO - 2018-03-05 11:54:06 --> Config Class Initialized
INFO - 2018-03-05 11:54:06 --> Hooks Class Initialized
DEBUG - 2018-03-05 11:54:06 --> UTF-8 Support Enabled
INFO - 2018-03-05 11:54:06 --> Utf8 Class Initialized
INFO - 2018-03-05 11:54:06 --> URI Class Initialized
INFO - 2018-03-05 11:54:06 --> Router Class Initialized
INFO - 2018-03-05 11:54:06 --> Output Class Initialized
INFO - 2018-03-05 11:54:06 --> Security Class Initialized
DEBUG - 2018-03-05 11:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 11:54:06 --> Input Class Initialized
INFO - 2018-03-05 11:54:06 --> Language Class Initialized
INFO - 2018-03-05 11:54:06 --> Language Class Initialized
INFO - 2018-03-05 11:54:06 --> Config Class Initialized
INFO - 2018-03-05 11:54:06 --> Loader Class Initialized
INFO - 2018-03-05 17:24:06 --> Helper loaded: url_helper
INFO - 2018-03-05 17:24:06 --> Helper loaded: notification_helper
INFO - 2018-03-05 17:24:06 --> Helper loaded: settings_helper
INFO - 2018-03-05 17:24:06 --> Helper loaded: permission_helper
INFO - 2018-03-05 17:24:06 --> Helper loaded: users_helper
INFO - 2018-03-05 17:24:06 --> Database Driver Class Initialized
DEBUG - 2018-03-05 17:24:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 17:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 17:24:06 --> Helper loaded: form_helper
INFO - 2018-03-05 17:24:06 --> Form Validation Class Initialized
INFO - 2018-03-05 17:24:06 --> Controller Class Initialized
INFO - 2018-03-05 17:24:06 --> Model Class Initialized
INFO - 2018-03-05 17:24:06 --> Helper loaded: inflector_helper
DEBUG - 2018-03-05 17:24:06 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-05 17:24:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-05 17:24:06 --> Model Class Initialized
INFO - 2018-03-05 17:24:06 --> Model Class Initialized
INFO - 2018-03-05 17:24:06 --> Model Class Initialized
INFO - 2018-03-05 17:24:06 --> Model Class Initialized
INFO - 2018-03-05 17:24:06 --> Model Class Initialized
INFO - 2018-03-05 17:24:06 --> Model Class Initialized
INFO - 2018-03-05 17:24:06 --> Model Class Initialized
INFO - 2018-03-05 17:24:06 --> Model Class Initialized
INFO - 2018-03-05 17:24:06 --> Model Class Initialized
INFO - 2018-03-05 17:24:06 --> Model Class Initialized
INFO - 2018-03-05 17:24:06 --> Model Class Initialized
INFO - 2018-03-05 17:24:06 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-05 17:24:06 --> Final output sent to browser
DEBUG - 2018-03-05 17:24:06 --> Total execution time: 0.4570
INFO - 2018-03-05 11:54:08 --> Config Class Initialized
INFO - 2018-03-05 11:54:08 --> Hooks Class Initialized
DEBUG - 2018-03-05 11:54:08 --> UTF-8 Support Enabled
INFO - 2018-03-05 11:54:08 --> Utf8 Class Initialized
INFO - 2018-03-05 11:54:08 --> URI Class Initialized
INFO - 2018-03-05 11:54:08 --> Router Class Initialized
INFO - 2018-03-05 11:54:08 --> Output Class Initialized
INFO - 2018-03-05 11:54:08 --> Security Class Initialized
DEBUG - 2018-03-05 11:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 11:54:08 --> Input Class Initialized
INFO - 2018-03-05 11:54:08 --> Language Class Initialized
INFO - 2018-03-05 11:54:08 --> Language Class Initialized
INFO - 2018-03-05 11:54:08 --> Config Class Initialized
INFO - 2018-03-05 11:54:08 --> Loader Class Initialized
INFO - 2018-03-05 17:24:08 --> Helper loaded: url_helper
INFO - 2018-03-05 17:24:08 --> Helper loaded: notification_helper
INFO - 2018-03-05 17:24:08 --> Helper loaded: settings_helper
INFO - 2018-03-05 17:24:08 --> Helper loaded: permission_helper
INFO - 2018-03-05 17:24:08 --> Helper loaded: users_helper
INFO - 2018-03-05 17:24:08 --> Database Driver Class Initialized
DEBUG - 2018-03-05 17:24:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 17:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 17:24:08 --> Helper loaded: form_helper
INFO - 2018-03-05 17:24:08 --> Form Validation Class Initialized
INFO - 2018-03-05 17:24:08 --> Controller Class Initialized
INFO - 2018-03-05 17:24:08 --> Model Class Initialized
INFO - 2018-03-05 17:24:08 --> Helper loaded: inflector_helper
DEBUG - 2018-03-05 17:24:08 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-05 17:24:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-05 17:24:08 --> Model Class Initialized
INFO - 2018-03-05 17:24:08 --> Model Class Initialized
INFO - 2018-03-05 17:24:08 --> Model Class Initialized
INFO - 2018-03-05 17:24:08 --> Model Class Initialized
INFO - 2018-03-05 17:24:08 --> Model Class Initialized
INFO - 2018-03-05 17:24:08 --> Model Class Initialized
INFO - 2018-03-05 17:24:08 --> Model Class Initialized
INFO - 2018-03-05 17:24:08 --> Model Class Initialized
INFO - 2018-03-05 17:24:08 --> Model Class Initialized
INFO - 2018-03-05 17:24:08 --> Model Class Initialized
INFO - 2018-03-05 17:24:08 --> Model Class Initialized
INFO - 2018-03-05 17:24:08 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-05 17:24:08 --> Final output sent to browser
DEBUG - 2018-03-05 17:24:08 --> Total execution time: 0.2872
INFO - 2018-03-05 11:54:20 --> Config Class Initialized
INFO - 2018-03-05 11:54:20 --> Hooks Class Initialized
DEBUG - 2018-03-05 11:54:20 --> UTF-8 Support Enabled
INFO - 2018-03-05 11:54:20 --> Utf8 Class Initialized
INFO - 2018-03-05 11:54:20 --> URI Class Initialized
INFO - 2018-03-05 11:54:20 --> Router Class Initialized
INFO - 2018-03-05 11:54:20 --> Output Class Initialized
INFO - 2018-03-05 11:54:20 --> Security Class Initialized
DEBUG - 2018-03-05 11:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 11:54:20 --> Input Class Initialized
INFO - 2018-03-05 11:54:20 --> Language Class Initialized
INFO - 2018-03-05 11:54:20 --> Language Class Initialized
INFO - 2018-03-05 11:54:20 --> Config Class Initialized
INFO - 2018-03-05 11:54:20 --> Loader Class Initialized
INFO - 2018-03-05 11:54:20 --> Config Class Initialized
INFO - 2018-03-05 11:54:20 --> Hooks Class Initialized
INFO - 2018-03-05 17:24:20 --> Helper loaded: url_helper
INFO - 2018-03-05 17:24:20 --> Helper loaded: notification_helper
INFO - 2018-03-05 17:24:20 --> Helper loaded: settings_helper
INFO - 2018-03-05 17:24:20 --> Helper loaded: permission_helper
INFO - 2018-03-05 17:24:20 --> Helper loaded: users_helper
DEBUG - 2018-03-05 11:54:20 --> UTF-8 Support Enabled
INFO - 2018-03-05 11:54:20 --> Utf8 Class Initialized
INFO - 2018-03-05 11:54:20 --> URI Class Initialized
INFO - 2018-03-05 17:24:20 --> Database Driver Class Initialized
DEBUG - 2018-03-05 17:24:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 17:24:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 11:54:20 --> Router Class Initialized
INFO - 2018-03-05 17:24:20 --> Helper loaded: form_helper
INFO - 2018-03-05 17:24:20 --> Form Validation Class Initialized
INFO - 2018-03-05 17:24:20 --> Controller Class Initialized
INFO - 2018-03-05 17:24:20 --> Model Class Initialized
INFO - 2018-03-05 17:24:20 --> Helper loaded: inflector_helper
INFO - 2018-03-05 11:54:20 --> Output Class Initialized
DEBUG - 2018-03-05 17:24:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-05 17:24:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-05 17:24:20 --> Model Class Initialized
INFO - 2018-03-05 17:24:20 --> Model Class Initialized
INFO - 2018-03-05 17:24:20 --> Model Class Initialized
INFO - 2018-03-05 17:24:20 --> Model Class Initialized
INFO - 2018-03-05 17:24:20 --> Model Class Initialized
INFO - 2018-03-05 17:24:20 --> Model Class Initialized
INFO - 2018-03-05 17:24:20 --> Final output sent to browser
DEBUG - 2018-03-05 17:24:20 --> Total execution time: 0.1818
INFO - 2018-03-05 11:54:20 --> Security Class Initialized
DEBUG - 2018-03-05 11:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 11:54:20 --> Input Class Initialized
INFO - 2018-03-05 11:54:20 --> Language Class Initialized
INFO - 2018-03-05 11:54:20 --> Language Class Initialized
INFO - 2018-03-05 11:54:20 --> Config Class Initialized
INFO - 2018-03-05 11:54:20 --> Loader Class Initialized
INFO - 2018-03-05 17:24:20 --> Helper loaded: url_helper
INFO - 2018-03-05 17:24:20 --> Helper loaded: notification_helper
INFO - 2018-03-05 17:24:20 --> Helper loaded: settings_helper
INFO - 2018-03-05 17:24:20 --> Helper loaded: permission_helper
INFO - 2018-03-05 17:24:20 --> Helper loaded: users_helper
INFO - 2018-03-05 11:54:20 --> Config Class Initialized
INFO - 2018-03-05 11:54:20 --> Hooks Class Initialized
DEBUG - 2018-03-05 11:54:20 --> UTF-8 Support Enabled
INFO - 2018-03-05 11:54:20 --> Utf8 Class Initialized
INFO - 2018-03-05 11:54:20 --> URI Class Initialized
INFO - 2018-03-05 11:54:20 --> Router Class Initialized
INFO - 2018-03-05 11:54:20 --> Output Class Initialized
INFO - 2018-03-05 17:24:20 --> Database Driver Class Initialized
INFO - 2018-03-05 11:54:20 --> Security Class Initialized
DEBUG - 2018-03-05 11:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 11:54:20 --> Input Class Initialized
DEBUG - 2018-03-05 17:24:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 11:54:20 --> Language Class Initialized
INFO - 2018-03-05 17:24:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 17:24:20 --> Helper loaded: form_helper
INFO - 2018-03-05 17:24:20 --> Form Validation Class Initialized
INFO - 2018-03-05 17:24:20 --> Controller Class Initialized
INFO - 2018-03-05 11:54:20 --> Language Class Initialized
INFO - 2018-03-05 11:54:20 --> Config Class Initialized
INFO - 2018-03-05 11:54:20 --> Loader Class Initialized
INFO - 2018-03-05 17:24:20 --> Model Class Initialized
INFO - 2018-03-05 17:24:20 --> Helper loaded: url_helper
INFO - 2018-03-05 17:24:20 --> Helper loaded: inflector_helper
INFO - 2018-03-05 17:24:20 --> Helper loaded: notification_helper
INFO - 2018-03-05 17:24:20 --> Helper loaded: settings_helper
INFO - 2018-03-05 17:24:20 --> Helper loaded: permission_helper
DEBUG - 2018-03-05 17:24:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-05 17:24:20 --> Helper loaded: users_helper
INFO - 2018-03-05 17:24:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-05 17:24:21 --> Model Class Initialized
INFO - 2018-03-05 17:24:21 --> Model Class Initialized
INFO - 2018-03-05 17:24:21 --> Model Class Initialized
INFO - 2018-03-05 17:24:21 --> Model Class Initialized
INFO - 2018-03-05 17:24:21 --> Model Class Initialized
INFO - 2018-03-05 17:24:21 --> Model Class Initialized
INFO - 2018-03-05 17:24:21 --> Final output sent to browser
DEBUG - 2018-03-05 17:24:21 --> Total execution time: 0.5655
INFO - 2018-03-05 17:24:21 --> Database Driver Class Initialized
DEBUG - 2018-03-05 17:24:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 17:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 17:24:21 --> Helper loaded: form_helper
INFO - 2018-03-05 17:24:21 --> Form Validation Class Initialized
INFO - 2018-03-05 17:24:21 --> Controller Class Initialized
INFO - 2018-03-05 17:24:21 --> Model Class Initialized
INFO - 2018-03-05 17:24:21 --> Helper loaded: inflector_helper
DEBUG - 2018-03-05 17:24:21 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-05 17:24:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-05 17:24:21 --> Model Class Initialized
INFO - 2018-03-05 17:24:21 --> Model Class Initialized
INFO - 2018-03-05 17:24:21 --> Model Class Initialized
INFO - 2018-03-05 17:24:21 --> Model Class Initialized
INFO - 2018-03-05 17:24:21 --> Model Class Initialized
INFO - 2018-03-05 17:24:21 --> Model Class Initialized
INFO - 2018-03-05 17:24:21 --> Final output sent to browser
DEBUG - 2018-03-05 17:24:21 --> Total execution time: 0.5306
INFO - 2018-03-05 11:54:21 --> Config Class Initialized
INFO - 2018-03-05 11:54:21 --> Hooks Class Initialized
DEBUG - 2018-03-05 11:54:21 --> UTF-8 Support Enabled
INFO - 2018-03-05 11:54:21 --> Utf8 Class Initialized
INFO - 2018-03-05 11:54:21 --> URI Class Initialized
INFO - 2018-03-05 11:54:21 --> Router Class Initialized
INFO - 2018-03-05 11:54:21 --> Output Class Initialized
INFO - 2018-03-05 11:54:21 --> Security Class Initialized
DEBUG - 2018-03-05 11:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 11:54:21 --> Input Class Initialized
INFO - 2018-03-05 11:54:21 --> Language Class Initialized
INFO - 2018-03-05 11:54:21 --> Language Class Initialized
INFO - 2018-03-05 11:54:21 --> Config Class Initialized
INFO - 2018-03-05 11:54:21 --> Loader Class Initialized
INFO - 2018-03-05 17:24:21 --> Helper loaded: url_helper
INFO - 2018-03-05 17:24:21 --> Helper loaded: notification_helper
INFO - 2018-03-05 17:24:21 --> Helper loaded: settings_helper
INFO - 2018-03-05 17:24:21 --> Helper loaded: permission_helper
INFO - 2018-03-05 17:24:21 --> Helper loaded: users_helper
INFO - 2018-03-05 17:24:21 --> Database Driver Class Initialized
DEBUG - 2018-03-05 17:24:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 17:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 17:24:21 --> Helper loaded: form_helper
INFO - 2018-03-05 17:24:21 --> Form Validation Class Initialized
INFO - 2018-03-05 17:24:21 --> Controller Class Initialized
INFO - 2018-03-05 17:24:21 --> Model Class Initialized
INFO - 2018-03-05 17:24:21 --> Helper loaded: inflector_helper
DEBUG - 2018-03-05 17:24:21 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-05 17:24:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-05 17:24:21 --> Model Class Initialized
INFO - 2018-03-05 17:24:21 --> Model Class Initialized
INFO - 2018-03-05 17:24:21 --> Model Class Initialized
INFO - 2018-03-05 17:24:21 --> Model Class Initialized
INFO - 2018-03-05 17:24:21 --> Model Class Initialized
INFO - 2018-03-05 17:24:21 --> Model Class Initialized
INFO - 2018-03-05 17:24:21 --> Final output sent to browser
DEBUG - 2018-03-05 17:24:21 --> Total execution time: 0.1001
INFO - 2018-03-05 11:54:22 --> Config Class Initialized
INFO - 2018-03-05 11:54:22 --> Hooks Class Initialized
DEBUG - 2018-03-05 11:54:22 --> UTF-8 Support Enabled
INFO - 2018-03-05 11:54:22 --> Utf8 Class Initialized
INFO - 2018-03-05 11:54:22 --> URI Class Initialized
INFO - 2018-03-05 11:54:23 --> Router Class Initialized
INFO - 2018-03-05 11:54:23 --> Output Class Initialized
INFO - 2018-03-05 11:54:23 --> Security Class Initialized
DEBUG - 2018-03-05 11:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 11:54:23 --> Input Class Initialized
INFO - 2018-03-05 11:54:23 --> Language Class Initialized
INFO - 2018-03-05 11:54:24 --> Language Class Initialized
INFO - 2018-03-05 11:54:24 --> Config Class Initialized
INFO - 2018-03-05 11:54:24 --> Loader Class Initialized
INFO - 2018-03-05 17:24:24 --> Helper loaded: url_helper
INFO - 2018-03-05 17:24:24 --> Helper loaded: notification_helper
INFO - 2018-03-05 17:24:24 --> Helper loaded: settings_helper
INFO - 2018-03-05 17:24:24 --> Helper loaded: permission_helper
INFO - 2018-03-05 17:24:24 --> Helper loaded: users_helper
INFO - 2018-03-05 17:24:24 --> Database Driver Class Initialized
DEBUG - 2018-03-05 17:24:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 17:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 17:24:24 --> Helper loaded: form_helper
INFO - 2018-03-05 17:24:24 --> Form Validation Class Initialized
INFO - 2018-03-05 17:24:24 --> Controller Class Initialized
INFO - 2018-03-05 17:24:24 --> Model Class Initialized
INFO - 2018-03-05 17:24:24 --> Helper loaded: inflector_helper
DEBUG - 2018-03-05 17:24:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-05 17:24:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-05 17:24:24 --> Model Class Initialized
INFO - 2018-03-05 17:24:24 --> Model Class Initialized
INFO - 2018-03-05 17:24:24 --> Model Class Initialized
INFO - 2018-03-05 17:24:24 --> Model Class Initialized
INFO - 2018-03-05 17:24:24 --> Model Class Initialized
INFO - 2018-03-05 17:24:24 --> Model Class Initialized
INFO - 2018-03-05 17:24:24 --> Final output sent to browser
DEBUG - 2018-03-05 17:24:24 --> Total execution time: 2.4268
INFO - 2018-03-05 11:54:46 --> Config Class Initialized
INFO - 2018-03-05 11:54:46 --> Hooks Class Initialized
DEBUG - 2018-03-05 11:54:46 --> UTF-8 Support Enabled
INFO - 2018-03-05 11:54:46 --> Utf8 Class Initialized
INFO - 2018-03-05 11:54:46 --> URI Class Initialized
INFO - 2018-03-05 11:54:46 --> Router Class Initialized
INFO - 2018-03-05 11:54:46 --> Output Class Initialized
INFO - 2018-03-05 11:54:46 --> Security Class Initialized
DEBUG - 2018-03-05 11:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 11:54:46 --> Input Class Initialized
INFO - 2018-03-05 11:54:46 --> Language Class Initialized
INFO - 2018-03-05 11:54:46 --> Language Class Initialized
INFO - 2018-03-05 11:54:46 --> Config Class Initialized
INFO - 2018-03-05 11:54:46 --> Loader Class Initialized
INFO - 2018-03-05 17:24:46 --> Helper loaded: url_helper
INFO - 2018-03-05 17:24:46 --> Helper loaded: notification_helper
INFO - 2018-03-05 17:24:46 --> Helper loaded: settings_helper
INFO - 2018-03-05 17:24:46 --> Helper loaded: permission_helper
INFO - 2018-03-05 17:24:46 --> Helper loaded: users_helper
INFO - 2018-03-05 17:24:46 --> Database Driver Class Initialized
DEBUG - 2018-03-05 17:24:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 17:24:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 17:24:46 --> Helper loaded: form_helper
INFO - 2018-03-05 17:24:46 --> Form Validation Class Initialized
INFO - 2018-03-05 17:24:46 --> Controller Class Initialized
INFO - 2018-03-05 17:24:46 --> Model Class Initialized
INFO - 2018-03-05 17:24:46 --> Helper loaded: inflector_helper
DEBUG - 2018-03-05 17:24:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-05 17:24:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-05 17:24:46 --> Model Class Initialized
INFO - 2018-03-05 17:24:46 --> Model Class Initialized
INFO - 2018-03-05 17:24:46 --> Model Class Initialized
INFO - 2018-03-05 17:24:46 --> Model Class Initialized
INFO - 2018-03-05 17:24:46 --> Model Class Initialized
INFO - 2018-03-05 17:24:46 --> Model Class Initialized
INFO - 2018-03-05 17:24:46 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-05 17:24:46 --> Final output sent to browser
DEBUG - 2018-03-05 17:24:46 --> Total execution time: 0.1207
INFO - 2018-03-05 11:54:46 --> Config Class Initialized
INFO - 2018-03-05 11:54:46 --> Hooks Class Initialized
DEBUG - 2018-03-05 11:54:46 --> UTF-8 Support Enabled
INFO - 2018-03-05 11:54:46 --> Utf8 Class Initialized
INFO - 2018-03-05 11:54:46 --> URI Class Initialized
INFO - 2018-03-05 11:54:46 --> Router Class Initialized
INFO - 2018-03-05 11:54:46 --> Output Class Initialized
INFO - 2018-03-05 11:54:46 --> Security Class Initialized
DEBUG - 2018-03-05 11:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 11:54:46 --> Input Class Initialized
INFO - 2018-03-05 11:54:46 --> Language Class Initialized
INFO - 2018-03-05 11:54:47 --> Language Class Initialized
INFO - 2018-03-05 11:54:47 --> Config Class Initialized
INFO - 2018-03-05 11:54:47 --> Loader Class Initialized
INFO - 2018-03-05 17:24:47 --> Helper loaded: url_helper
INFO - 2018-03-05 17:24:47 --> Helper loaded: notification_helper
INFO - 2018-03-05 17:24:47 --> Helper loaded: settings_helper
INFO - 2018-03-05 17:24:47 --> Helper loaded: permission_helper
INFO - 2018-03-05 17:24:47 --> Helper loaded: users_helper
INFO - 2018-03-05 17:24:47 --> Database Driver Class Initialized
DEBUG - 2018-03-05 17:24:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 17:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 17:24:47 --> Helper loaded: form_helper
INFO - 2018-03-05 17:24:47 --> Form Validation Class Initialized
INFO - 2018-03-05 17:24:47 --> Controller Class Initialized
INFO - 2018-03-05 17:24:47 --> Model Class Initialized
INFO - 2018-03-05 17:24:47 --> Helper loaded: inflector_helper
DEBUG - 2018-03-05 17:24:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-05 17:24:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-05 17:24:47 --> Model Class Initialized
INFO - 2018-03-05 17:24:47 --> Model Class Initialized
INFO - 2018-03-05 17:24:47 --> Model Class Initialized
INFO - 2018-03-05 17:24:47 --> Model Class Initialized
INFO - 2018-03-05 17:24:47 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-05 17:24:47 --> Final output sent to browser
DEBUG - 2018-03-05 17:24:47 --> Total execution time: 0.6391
INFO - 2018-03-05 11:55:01 --> Config Class Initialized
INFO - 2018-03-05 11:55:01 --> Hooks Class Initialized
DEBUG - 2018-03-05 11:55:01 --> UTF-8 Support Enabled
INFO - 2018-03-05 11:55:01 --> Utf8 Class Initialized
INFO - 2018-03-05 11:55:01 --> URI Class Initialized
INFO - 2018-03-05 11:55:01 --> Router Class Initialized
INFO - 2018-03-05 11:55:01 --> Output Class Initialized
INFO - 2018-03-05 11:55:01 --> Security Class Initialized
DEBUG - 2018-03-05 11:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 11:55:01 --> Input Class Initialized
INFO - 2018-03-05 11:55:01 --> Language Class Initialized
INFO - 2018-03-05 11:55:02 --> Language Class Initialized
INFO - 2018-03-05 11:55:02 --> Config Class Initialized
INFO - 2018-03-05 11:55:02 --> Loader Class Initialized
INFO - 2018-03-05 17:25:02 --> Helper loaded: url_helper
INFO - 2018-03-05 17:25:02 --> Helper loaded: notification_helper
INFO - 2018-03-05 17:25:02 --> Helper loaded: settings_helper
INFO - 2018-03-05 17:25:02 --> Helper loaded: permission_helper
INFO - 2018-03-05 17:25:02 --> Helper loaded: users_helper
INFO - 2018-03-05 17:25:02 --> Database Driver Class Initialized
DEBUG - 2018-03-05 17:25:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 17:25:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 17:25:02 --> Helper loaded: form_helper
INFO - 2018-03-05 17:25:02 --> Form Validation Class Initialized
INFO - 2018-03-05 17:25:02 --> Controller Class Initialized
INFO - 2018-03-05 17:25:02 --> Model Class Initialized
INFO - 2018-03-05 17:25:02 --> Helper loaded: inflector_helper
DEBUG - 2018-03-05 17:25:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-05 17:25:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-05 17:25:02 --> Model Class Initialized
INFO - 2018-03-05 17:25:02 --> Model Class Initialized
INFO - 2018-03-05 17:25:02 --> Model Class Initialized
INFO - 2018-03-05 17:25:02 --> Model Class Initialized
INFO - 2018-03-05 17:25:02 --> Model Class Initialized
INFO - 2018-03-05 17:25:02 --> Model Class Initialized
INFO - 2018-03-05 17:25:02 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-05 17:25:02 --> Model Class Initialized
INFO - 2018-03-05 17:25:02 --> Final output sent to browser
DEBUG - 2018-03-05 17:25:02 --> Total execution time: 0.9719
INFO - 2018-03-05 11:55:09 --> Config Class Initialized
INFO - 2018-03-05 11:55:09 --> Hooks Class Initialized
DEBUG - 2018-03-05 11:55:09 --> UTF-8 Support Enabled
INFO - 2018-03-05 11:55:09 --> Utf8 Class Initialized
INFO - 2018-03-05 11:55:09 --> URI Class Initialized
INFO - 2018-03-05 11:55:10 --> Router Class Initialized
INFO - 2018-03-05 11:55:10 --> Output Class Initialized
INFO - 2018-03-05 11:55:10 --> Security Class Initialized
DEBUG - 2018-03-05 11:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 11:55:10 --> Input Class Initialized
INFO - 2018-03-05 11:55:10 --> Language Class Initialized
INFO - 2018-03-05 11:55:11 --> Language Class Initialized
INFO - 2018-03-05 11:55:11 --> Config Class Initialized
INFO - 2018-03-05 11:55:11 --> Loader Class Initialized
INFO - 2018-03-05 17:25:11 --> Helper loaded: url_helper
INFO - 2018-03-05 17:25:11 --> Helper loaded: notification_helper
INFO - 2018-03-05 17:25:11 --> Helper loaded: settings_helper
INFO - 2018-03-05 17:25:11 --> Helper loaded: permission_helper
INFO - 2018-03-05 17:25:11 --> Helper loaded: users_helper
INFO - 2018-03-05 17:25:11 --> Database Driver Class Initialized
DEBUG - 2018-03-05 17:25:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 17:25:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 17:25:11 --> Helper loaded: form_helper
INFO - 2018-03-05 17:25:11 --> Form Validation Class Initialized
INFO - 2018-03-05 17:25:11 --> Controller Class Initialized
INFO - 2018-03-05 17:25:11 --> Model Class Initialized
INFO - 2018-03-05 17:25:12 --> Helper loaded: inflector_helper
DEBUG - 2018-03-05 17:25:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-05 17:25:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-05 17:25:12 --> Model Class Initialized
INFO - 2018-03-05 17:25:12 --> Model Class Initialized
INFO - 2018-03-05 17:25:12 --> Model Class Initialized
INFO - 2018-03-05 17:25:12 --> Model Class Initialized
INFO - 2018-03-05 17:25:12 --> Model Class Initialized
INFO - 2018-03-05 17:25:12 --> Model Class Initialized
INFO - 2018-03-05 17:25:12 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-05 17:25:12 --> Final output sent to browser
DEBUG - 2018-03-05 17:25:12 --> Total execution time: 2.7802
INFO - 2018-03-05 11:55:23 --> Config Class Initialized
INFO - 2018-03-05 11:55:23 --> Hooks Class Initialized
DEBUG - 2018-03-05 11:55:23 --> UTF-8 Support Enabled
INFO - 2018-03-05 11:55:23 --> Utf8 Class Initialized
INFO - 2018-03-05 11:55:23 --> URI Class Initialized
INFO - 2018-03-05 11:55:23 --> Router Class Initialized
INFO - 2018-03-05 11:55:24 --> Output Class Initialized
INFO - 2018-03-05 11:55:24 --> Security Class Initialized
DEBUG - 2018-03-05 11:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 11:55:24 --> Input Class Initialized
INFO - 2018-03-05 11:55:24 --> Language Class Initialized
INFO - 2018-03-05 11:55:24 --> Language Class Initialized
INFO - 2018-03-05 11:55:24 --> Config Class Initialized
INFO - 2018-03-05 11:55:24 --> Loader Class Initialized
INFO - 2018-03-05 17:25:24 --> Helper loaded: url_helper
INFO - 2018-03-05 17:25:24 --> Helper loaded: notification_helper
INFO - 2018-03-05 17:25:24 --> Helper loaded: settings_helper
INFO - 2018-03-05 17:25:24 --> Helper loaded: permission_helper
INFO - 2018-03-05 17:25:25 --> Helper loaded: users_helper
INFO - 2018-03-05 17:25:25 --> Database Driver Class Initialized
DEBUG - 2018-03-05 17:25:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 17:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 17:25:26 --> Helper loaded: form_helper
INFO - 2018-03-05 17:25:26 --> Form Validation Class Initialized
INFO - 2018-03-05 17:25:26 --> Controller Class Initialized
INFO - 2018-03-05 17:25:26 --> Model Class Initialized
INFO - 2018-03-05 17:25:26 --> Helper loaded: inflector_helper
DEBUG - 2018-03-05 17:25:26 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-05 17:25:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-05 17:25:26 --> Model Class Initialized
INFO - 2018-03-05 17:25:26 --> Model Class Initialized
INFO - 2018-03-05 17:25:26 --> Model Class Initialized
INFO - 2018-03-05 17:25:26 --> Model Class Initialized
INFO - 2018-03-05 17:25:26 --> Model Class Initialized
INFO - 2018-03-05 17:25:26 --> Model Class Initialized
INFO - 2018-03-05 17:25:26 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-05 17:25:26 --> Final output sent to browser
DEBUG - 2018-03-05 17:25:26 --> Total execution time: 2.9389
INFO - 2018-03-05 11:56:03 --> Config Class Initialized
INFO - 2018-03-05 11:56:03 --> Hooks Class Initialized
DEBUG - 2018-03-05 11:56:03 --> UTF-8 Support Enabled
INFO - 2018-03-05 11:56:03 --> Utf8 Class Initialized
INFO - 2018-03-05 11:56:03 --> URI Class Initialized
INFO - 2018-03-05 11:56:03 --> Router Class Initialized
INFO - 2018-03-05 11:56:03 --> Output Class Initialized
INFO - 2018-03-05 11:56:03 --> Security Class Initialized
DEBUG - 2018-03-05 11:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 11:56:03 --> Input Class Initialized
INFO - 2018-03-05 11:56:03 --> Language Class Initialized
INFO - 2018-03-05 11:56:03 --> Language Class Initialized
INFO - 2018-03-05 11:56:03 --> Config Class Initialized
INFO - 2018-03-05 11:56:03 --> Loader Class Initialized
INFO - 2018-03-05 17:26:03 --> Helper loaded: url_helper
INFO - 2018-03-05 17:26:03 --> Helper loaded: notification_helper
INFO - 2018-03-05 17:26:03 --> Helper loaded: settings_helper
INFO - 2018-03-05 17:26:03 --> Helper loaded: permission_helper
INFO - 2018-03-05 17:26:03 --> Helper loaded: users_helper
INFO - 2018-03-05 17:26:03 --> Database Driver Class Initialized
DEBUG - 2018-03-05 17:26:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 17:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 17:26:03 --> Helper loaded: form_helper
INFO - 2018-03-05 17:26:03 --> Form Validation Class Initialized
INFO - 2018-03-05 17:26:03 --> Controller Class Initialized
INFO - 2018-03-05 17:26:03 --> Model Class Initialized
INFO - 2018-03-05 17:26:03 --> Helper loaded: inflector_helper
DEBUG - 2018-03-05 17:26:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-05 17:26:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-05 17:26:03 --> Model Class Initialized
INFO - 2018-03-05 17:26:03 --> Model Class Initialized
INFO - 2018-03-05 17:26:03 --> Model Class Initialized
INFO - 2018-03-05 17:26:03 --> Model Class Initialized
INFO - 2018-03-05 17:26:03 --> Model Class Initialized
INFO - 2018-03-05 17:26:03 --> Model Class Initialized
INFO - 2018-03-05 17:26:03 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-05 17:26:03 --> Final output sent to browser
DEBUG - 2018-03-05 17:26:03 --> Total execution time: 0.1151
