<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-01-31 08:58:29 --> Config Class Initialized
INFO - 2018-01-31 08:58:29 --> Hooks Class Initialized
DEBUG - 2018-01-31 08:58:29 --> UTF-8 Support Enabled
INFO - 2018-01-31 08:58:29 --> Utf8 Class Initialized
INFO - 2018-01-31 08:58:29 --> URI Class Initialized
DEBUG - 2018-01-31 08:58:29 --> No URI present. Default controller set.
INFO - 2018-01-31 08:58:29 --> Router Class Initialized
INFO - 2018-01-31 08:58:29 --> Output Class Initialized
INFO - 2018-01-31 08:58:29 --> Security Class Initialized
DEBUG - 2018-01-31 08:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 08:58:29 --> Input Class Initialized
INFO - 2018-01-31 08:58:29 --> Language Class Initialized
INFO - 2018-01-31 08:58:29 --> Language Class Initialized
INFO - 2018-01-31 08:58:29 --> Config Class Initialized
INFO - 2018-01-31 08:58:29 --> Loader Class Initialized
INFO - 2018-01-31 14:28:29 --> Helper loaded: url_helper
INFO - 2018-01-31 14:28:29 --> Helper loaded: notification_helper
INFO - 2018-01-31 14:28:29 --> Helper loaded: settings_helper
INFO - 2018-01-31 14:28:29 --> Helper loaded: permission_helper
INFO - 2018-01-31 14:28:29 --> Helper loaded: users_helper
INFO - 2018-01-31 14:28:29 --> Database Driver Class Initialized
DEBUG - 2018-01-31 14:28:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 14:28:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 14:28:29 --> Helper loaded: form_helper
INFO - 2018-01-31 14:28:29 --> Form Validation Class Initialized
INFO - 2018-01-31 14:28:29 --> Controller Class Initialized
INFO - 2018-01-31 14:28:29 --> Model Class Initialized
INFO - 2018-01-31 14:28:29 --> Helper loaded: inflector_helper
INFO - 2018-01-31 14:28:29 --> Model Class Initialized
DEBUG - 2018-01-31 14:28:29 --> File loaded: /home/pr01004/public_html/application/views/login.php
INFO - 2018-01-31 14:28:29 --> Final output sent to browser
DEBUG - 2018-01-31 14:28:29 --> Total execution time: 0.0934
INFO - 2018-01-31 09:07:47 --> Config Class Initialized
INFO - 2018-01-31 09:07:47 --> Hooks Class Initialized
DEBUG - 2018-01-31 09:07:47 --> UTF-8 Support Enabled
INFO - 2018-01-31 09:07:47 --> Utf8 Class Initialized
INFO - 2018-01-31 09:07:47 --> URI Class Initialized
INFO - 2018-01-31 09:07:47 --> Router Class Initialized
INFO - 2018-01-31 09:07:47 --> Output Class Initialized
INFO - 2018-01-31 09:07:47 --> Security Class Initialized
DEBUG - 2018-01-31 09:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 09:07:47 --> Input Class Initialized
INFO - 2018-01-31 09:07:47 --> Language Class Initialized
INFO - 2018-01-31 09:07:47 --> Language Class Initialized
INFO - 2018-01-31 09:07:47 --> Config Class Initialized
INFO - 2018-01-31 09:07:47 --> Loader Class Initialized
INFO - 2018-01-31 14:37:47 --> Helper loaded: url_helper
INFO - 2018-01-31 14:37:47 --> Helper loaded: notification_helper
INFO - 2018-01-31 14:37:47 --> Helper loaded: settings_helper
INFO - 2018-01-31 14:37:47 --> Helper loaded: permission_helper
INFO - 2018-01-31 14:37:47 --> Helper loaded: users_helper
INFO - 2018-01-31 14:37:47 --> Database Driver Class Initialized
DEBUG - 2018-01-31 14:37:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 14:37:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 14:37:47 --> Helper loaded: form_helper
INFO - 2018-01-31 14:37:47 --> Form Validation Class Initialized
INFO - 2018-01-31 14:37:47 --> Controller Class Initialized
INFO - 2018-01-31 14:37:47 --> Model Class Initialized
INFO - 2018-01-31 14:37:47 --> Helper loaded: inflector_helper
DEBUG - 2018-01-31 14:37:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-31 14:37:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-31 14:37:47 --> Model Class Initialized
INFO - 2018-01-31 14:37:47 --> Model Class Initialized
INFO - 2018-01-31 14:37:47 --> Model Class Initialized
INFO - 2018-01-31 14:37:47 --> Model Class Initialized
INFO - 2018-01-31 14:37:47 --> Model Class Initialized
INFO - 2018-01-31 14:37:47 --> Model Class Initialized
INFO - 2018-01-31 14:37:47 --> Language file loaded: language/english/message_lang.php
INFO - 2018-01-31 14:37:47 --> Final output sent to browser
DEBUG - 2018-01-31 14:37:47 --> Total execution time: 0.1372
INFO - 2018-01-31 09:25:31 --> Config Class Initialized
INFO - 2018-01-31 09:25:31 --> Hooks Class Initialized
DEBUG - 2018-01-31 09:25:31 --> UTF-8 Support Enabled
INFO - 2018-01-31 09:25:31 --> Utf8 Class Initialized
INFO - 2018-01-31 09:25:31 --> URI Class Initialized
INFO - 2018-01-31 09:25:31 --> Router Class Initialized
INFO - 2018-01-31 09:25:31 --> Output Class Initialized
INFO - 2018-01-31 09:25:31 --> Security Class Initialized
DEBUG - 2018-01-31 09:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 09:25:31 --> Input Class Initialized
INFO - 2018-01-31 09:25:31 --> Language Class Initialized
INFO - 2018-01-31 09:25:31 --> Language Class Initialized
INFO - 2018-01-31 09:25:31 --> Config Class Initialized
INFO - 2018-01-31 09:25:31 --> Loader Class Initialized
INFO - 2018-01-31 14:55:31 --> Helper loaded: url_helper
INFO - 2018-01-31 14:55:31 --> Helper loaded: notification_helper
INFO - 2018-01-31 14:55:31 --> Helper loaded: settings_helper
INFO - 2018-01-31 14:55:31 --> Helper loaded: permission_helper
INFO - 2018-01-31 14:55:31 --> Helper loaded: users_helper
INFO - 2018-01-31 14:55:31 --> Database Driver Class Initialized
DEBUG - 2018-01-31 14:55:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 14:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 14:55:31 --> Helper loaded: form_helper
INFO - 2018-01-31 14:55:31 --> Form Validation Class Initialized
INFO - 2018-01-31 14:55:31 --> Controller Class Initialized
INFO - 2018-01-31 14:55:31 --> Model Class Initialized
INFO - 2018-01-31 14:55:31 --> Helper loaded: inflector_helper
DEBUG - 2018-01-31 14:55:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-31 14:55:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-31 14:55:31 --> Model Class Initialized
INFO - 2018-01-31 14:55:31 --> Model Class Initialized
INFO - 2018-01-31 14:55:31 --> Model Class Initialized
INFO - 2018-01-31 14:55:31 --> Model Class Initialized
INFO - 2018-01-31 14:55:31 --> Model Class Initialized
INFO - 2018-01-31 14:55:31 --> Model Class Initialized
INFO - 2018-01-31 14:55:31 --> Language file loaded: language/english/message_lang.php
INFO - 2018-01-31 14:55:31 --> Final output sent to browser
DEBUG - 2018-01-31 14:55:31 --> Total execution time: 0.1152
INFO - 2018-01-31 09:32:42 --> Config Class Initialized
INFO - 2018-01-31 09:32:42 --> Hooks Class Initialized
DEBUG - 2018-01-31 09:32:42 --> UTF-8 Support Enabled
INFO - 2018-01-31 09:32:42 --> Utf8 Class Initialized
INFO - 2018-01-31 09:32:42 --> URI Class Initialized
INFO - 2018-01-31 09:32:42 --> Router Class Initialized
INFO - 2018-01-31 09:32:42 --> Output Class Initialized
INFO - 2018-01-31 09:32:42 --> Security Class Initialized
DEBUG - 2018-01-31 09:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 09:32:42 --> Input Class Initialized
INFO - 2018-01-31 09:32:42 --> Language Class Initialized
INFO - 2018-01-31 09:32:42 --> Language Class Initialized
INFO - 2018-01-31 09:32:42 --> Config Class Initialized
INFO - 2018-01-31 09:32:42 --> Loader Class Initialized
INFO - 2018-01-31 15:02:42 --> Helper loaded: url_helper
INFO - 2018-01-31 15:02:42 --> Helper loaded: notification_helper
INFO - 2018-01-31 15:02:42 --> Helper loaded: settings_helper
INFO - 2018-01-31 15:02:42 --> Helper loaded: permission_helper
INFO - 2018-01-31 15:02:42 --> Helper loaded: users_helper
INFO - 2018-01-31 15:02:42 --> Database Driver Class Initialized
DEBUG - 2018-01-31 15:02:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 15:02:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 15:02:42 --> Helper loaded: form_helper
INFO - 2018-01-31 15:02:42 --> Form Validation Class Initialized
INFO - 2018-01-31 15:02:42 --> Controller Class Initialized
INFO - 2018-01-31 15:02:42 --> Model Class Initialized
INFO - 2018-01-31 15:02:42 --> Helper loaded: inflector_helper
DEBUG - 2018-01-31 15:02:42 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-31 15:02:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-31 15:02:42 --> Model Class Initialized
INFO - 2018-01-31 15:02:42 --> Model Class Initialized
INFO - 2018-01-31 15:02:42 --> Model Class Initialized
INFO - 2018-01-31 15:02:42 --> Model Class Initialized
INFO - 2018-01-31 15:02:42 --> Model Class Initialized
INFO - 2018-01-31 15:02:42 --> Model Class Initialized
INFO - 2018-01-31 15:02:42 --> Language file loaded: language/english/message_lang.php
INFO - 2018-01-31 15:02:42 --> Final output sent to browser
DEBUG - 2018-01-31 15:02:42 --> Total execution time: 0.0821
INFO - 2018-01-31 09:32:56 --> Config Class Initialized
INFO - 2018-01-31 09:32:56 --> Hooks Class Initialized
DEBUG - 2018-01-31 09:32:56 --> UTF-8 Support Enabled
INFO - 2018-01-31 09:32:56 --> Utf8 Class Initialized
INFO - 2018-01-31 09:32:56 --> URI Class Initialized
INFO - 2018-01-31 09:32:56 --> Router Class Initialized
INFO - 2018-01-31 09:32:56 --> Output Class Initialized
INFO - 2018-01-31 09:32:56 --> Security Class Initialized
DEBUG - 2018-01-31 09:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 09:32:56 --> Input Class Initialized
INFO - 2018-01-31 09:32:56 --> Language Class Initialized
INFO - 2018-01-31 09:32:56 --> Language Class Initialized
INFO - 2018-01-31 09:32:56 --> Config Class Initialized
INFO - 2018-01-31 09:32:56 --> Loader Class Initialized
INFO - 2018-01-31 15:02:56 --> Helper loaded: url_helper
INFO - 2018-01-31 15:02:56 --> Helper loaded: notification_helper
INFO - 2018-01-31 15:02:56 --> Helper loaded: settings_helper
INFO - 2018-01-31 15:02:56 --> Helper loaded: permission_helper
INFO - 2018-01-31 15:02:56 --> Helper loaded: users_helper
INFO - 2018-01-31 15:02:56 --> Database Driver Class Initialized
DEBUG - 2018-01-31 15:02:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 15:02:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 15:02:56 --> Helper loaded: form_helper
INFO - 2018-01-31 15:02:56 --> Form Validation Class Initialized
INFO - 2018-01-31 15:02:56 --> Controller Class Initialized
INFO - 2018-01-31 15:02:56 --> Model Class Initialized
INFO - 2018-01-31 15:02:56 --> Helper loaded: inflector_helper
DEBUG - 2018-01-31 15:02:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-31 15:02:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-31 15:02:56 --> Model Class Initialized
INFO - 2018-01-31 15:02:56 --> Model Class Initialized
INFO - 2018-01-31 15:02:56 --> Model Class Initialized
INFO - 2018-01-31 15:02:56 --> Model Class Initialized
INFO - 2018-01-31 15:02:56 --> Model Class Initialized
INFO - 2018-01-31 15:02:56 --> Model Class Initialized
INFO - 2018-01-31 15:02:56 --> Language file loaded: language/english/message_lang.php
INFO - 2018-01-31 15:02:56 --> Final output sent to browser
DEBUG - 2018-01-31 15:02:56 --> Total execution time: 0.0769
INFO - 2018-01-31 09:51:50 --> Config Class Initialized
INFO - 2018-01-31 09:51:50 --> Hooks Class Initialized
DEBUG - 2018-01-31 09:51:50 --> UTF-8 Support Enabled
INFO - 2018-01-31 09:51:50 --> Utf8 Class Initialized
INFO - 2018-01-31 09:51:50 --> URI Class Initialized
INFO - 2018-01-31 09:51:50 --> Router Class Initialized
INFO - 2018-01-31 09:51:50 --> Output Class Initialized
INFO - 2018-01-31 09:51:50 --> Security Class Initialized
DEBUG - 2018-01-31 09:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 09:51:50 --> Input Class Initialized
INFO - 2018-01-31 09:51:50 --> Language Class Initialized
INFO - 2018-01-31 09:51:50 --> Language Class Initialized
INFO - 2018-01-31 09:51:50 --> Config Class Initialized
INFO - 2018-01-31 09:51:50 --> Loader Class Initialized
INFO - 2018-01-31 15:21:50 --> Helper loaded: url_helper
INFO - 2018-01-31 15:21:50 --> Helper loaded: notification_helper
INFO - 2018-01-31 15:21:50 --> Helper loaded: settings_helper
INFO - 2018-01-31 15:21:50 --> Helper loaded: permission_helper
INFO - 2018-01-31 15:21:50 --> Helper loaded: users_helper
INFO - 2018-01-31 15:21:50 --> Database Driver Class Initialized
DEBUG - 2018-01-31 15:21:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 15:21:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 15:21:50 --> Helper loaded: form_helper
INFO - 2018-01-31 15:21:50 --> Form Validation Class Initialized
INFO - 2018-01-31 15:21:50 --> Controller Class Initialized
INFO - 2018-01-31 15:21:50 --> Model Class Initialized
INFO - 2018-01-31 15:21:50 --> Helper loaded: inflector_helper
DEBUG - 2018-01-31 15:21:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-31 15:21:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-31 15:21:50 --> Model Class Initialized
INFO - 2018-01-31 15:21:50 --> Model Class Initialized
INFO - 2018-01-31 15:21:50 --> Model Class Initialized
INFO - 2018-01-31 15:21:50 --> Model Class Initialized
INFO - 2018-01-31 15:21:50 --> Model Class Initialized
INFO - 2018-01-31 15:21:50 --> Model Class Initialized
INFO - 2018-01-31 15:21:50 --> Model Class Initialized
INFO - 2018-01-31 15:21:50 --> Model Class Initialized
INFO - 2018-01-31 15:21:50 --> Model Class Initialized
INFO - 2018-01-31 15:21:50 --> Model Class Initialized
INFO - 2018-01-31 15:21:50 --> Model Class Initialized
INFO - 2018-01-31 15:21:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-01-31 15:21:50 --> Model Class Initialized
INFO - 2018-01-31 15:21:51 --> Final output sent to browser
DEBUG - 2018-01-31 15:21:51 --> Total execution time: 0.1265
INFO - 2018-01-31 09:51:56 --> Config Class Initialized
INFO - 2018-01-31 09:51:56 --> Hooks Class Initialized
DEBUG - 2018-01-31 09:51:56 --> UTF-8 Support Enabled
INFO - 2018-01-31 09:51:56 --> Utf8 Class Initialized
INFO - 2018-01-31 09:51:56 --> URI Class Initialized
INFO - 2018-01-31 09:51:56 --> Router Class Initialized
INFO - 2018-01-31 09:51:56 --> Output Class Initialized
INFO - 2018-01-31 09:51:56 --> Security Class Initialized
DEBUG - 2018-01-31 09:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 09:51:56 --> Input Class Initialized
INFO - 2018-01-31 09:51:56 --> Language Class Initialized
INFO - 2018-01-31 09:51:56 --> Language Class Initialized
INFO - 2018-01-31 09:51:56 --> Config Class Initialized
INFO - 2018-01-31 09:51:56 --> Loader Class Initialized
INFO - 2018-01-31 15:21:56 --> Helper loaded: url_helper
INFO - 2018-01-31 15:21:56 --> Helper loaded: notification_helper
INFO - 2018-01-31 15:21:56 --> Helper loaded: settings_helper
INFO - 2018-01-31 15:21:56 --> Helper loaded: permission_helper
INFO - 2018-01-31 15:21:56 --> Helper loaded: users_helper
INFO - 2018-01-31 15:21:56 --> Database Driver Class Initialized
DEBUG - 2018-01-31 15:21:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 15:21:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 15:21:56 --> Helper loaded: form_helper
INFO - 2018-01-31 15:21:56 --> Form Validation Class Initialized
INFO - 2018-01-31 15:21:56 --> Controller Class Initialized
INFO - 2018-01-31 15:21:56 --> Model Class Initialized
INFO - 2018-01-31 15:21:56 --> Helper loaded: inflector_helper
DEBUG - 2018-01-31 15:21:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-31 15:21:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-31 15:21:56 --> Model Class Initialized
INFO - 2018-01-31 15:21:56 --> Model Class Initialized
INFO - 2018-01-31 15:21:56 --> Model Class Initialized
INFO - 2018-01-31 15:21:56 --> Model Class Initialized
INFO - 2018-01-31 15:21:56 --> Model Class Initialized
INFO - 2018-01-31 15:21:56 --> Model Class Initialized
INFO - 2018-01-31 15:21:56 --> Model Class Initialized
INFO - 2018-01-31 15:21:56 --> Model Class Initialized
INFO - 2018-01-31 15:21:56 --> Model Class Initialized
INFO - 2018-01-31 15:21:56 --> Model Class Initialized
INFO - 2018-01-31 15:21:56 --> Model Class Initialized
INFO - 2018-01-31 15:21:56 --> Language file loaded: language/english/message_lang.php
INFO - 2018-01-31 15:21:56 --> Model Class Initialized
INFO - 2018-01-31 15:21:56 --> Final output sent to browser
DEBUG - 2018-01-31 15:21:56 --> Total execution time: 0.1083
INFO - 2018-01-31 09:52:01 --> Config Class Initialized
INFO - 2018-01-31 09:52:01 --> Hooks Class Initialized
DEBUG - 2018-01-31 09:52:01 --> UTF-8 Support Enabled
INFO - 2018-01-31 09:52:01 --> Utf8 Class Initialized
INFO - 2018-01-31 09:52:01 --> URI Class Initialized
INFO - 2018-01-31 09:52:01 --> Router Class Initialized
INFO - 2018-01-31 09:52:01 --> Output Class Initialized
INFO - 2018-01-31 09:52:01 --> Security Class Initialized
DEBUG - 2018-01-31 09:52:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 09:52:01 --> Input Class Initialized
INFO - 2018-01-31 09:52:01 --> Language Class Initialized
INFO - 2018-01-31 09:52:01 --> Language Class Initialized
INFO - 2018-01-31 09:52:01 --> Config Class Initialized
INFO - 2018-01-31 09:52:01 --> Loader Class Initialized
INFO - 2018-01-31 15:22:01 --> Helper loaded: url_helper
INFO - 2018-01-31 15:22:01 --> Helper loaded: notification_helper
INFO - 2018-01-31 15:22:01 --> Helper loaded: settings_helper
INFO - 2018-01-31 15:22:01 --> Helper loaded: permission_helper
INFO - 2018-01-31 15:22:01 --> Helper loaded: users_helper
INFO - 2018-01-31 15:22:01 --> Database Driver Class Initialized
DEBUG - 2018-01-31 15:22:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 15:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 15:22:01 --> Helper loaded: form_helper
INFO - 2018-01-31 15:22:01 --> Form Validation Class Initialized
INFO - 2018-01-31 15:22:01 --> Controller Class Initialized
INFO - 2018-01-31 15:22:01 --> Model Class Initialized
INFO - 2018-01-31 15:22:01 --> Helper loaded: inflector_helper
DEBUG - 2018-01-31 15:22:01 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-31 15:22:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-31 15:22:01 --> Model Class Initialized
INFO - 2018-01-31 15:22:01 --> Model Class Initialized
INFO - 2018-01-31 15:22:01 --> Model Class Initialized
INFO - 2018-01-31 15:22:01 --> Model Class Initialized
INFO - 2018-01-31 15:22:01 --> Model Class Initialized
INFO - 2018-01-31 15:22:01 --> Model Class Initialized
INFO - 2018-01-31 15:22:01 --> Model Class Initialized
INFO - 2018-01-31 15:22:01 --> Model Class Initialized
INFO - 2018-01-31 15:22:01 --> Model Class Initialized
INFO - 2018-01-31 15:22:01 --> Model Class Initialized
INFO - 2018-01-31 15:22:01 --> Model Class Initialized
INFO - 2018-01-31 15:22:01 --> Language file loaded: language/english/message_lang.php
INFO - 2018-01-31 15:22:01 --> Model Class Initialized
INFO - 2018-01-31 15:22:01 --> Final output sent to browser
DEBUG - 2018-01-31 15:22:01 --> Total execution time: 0.1137
INFO - 2018-01-31 09:52:05 --> Config Class Initialized
INFO - 2018-01-31 09:52:05 --> Hooks Class Initialized
DEBUG - 2018-01-31 09:52:05 --> UTF-8 Support Enabled
INFO - 2018-01-31 09:52:05 --> Utf8 Class Initialized
INFO - 2018-01-31 09:52:05 --> URI Class Initialized
INFO - 2018-01-31 09:52:05 --> Router Class Initialized
INFO - 2018-01-31 09:52:05 --> Output Class Initialized
INFO - 2018-01-31 09:52:05 --> Security Class Initialized
DEBUG - 2018-01-31 09:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 09:52:05 --> Input Class Initialized
INFO - 2018-01-31 09:52:05 --> Language Class Initialized
INFO - 2018-01-31 09:52:05 --> Language Class Initialized
INFO - 2018-01-31 09:52:05 --> Config Class Initialized
INFO - 2018-01-31 09:52:05 --> Loader Class Initialized
INFO - 2018-01-31 15:22:05 --> Helper loaded: url_helper
INFO - 2018-01-31 15:22:05 --> Helper loaded: notification_helper
INFO - 2018-01-31 15:22:05 --> Helper loaded: settings_helper
INFO - 2018-01-31 15:22:05 --> Helper loaded: permission_helper
INFO - 2018-01-31 15:22:05 --> Helper loaded: users_helper
INFO - 2018-01-31 15:22:06 --> Database Driver Class Initialized
DEBUG - 2018-01-31 15:22:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 15:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 15:22:06 --> Helper loaded: form_helper
INFO - 2018-01-31 15:22:06 --> Form Validation Class Initialized
INFO - 2018-01-31 15:22:06 --> Controller Class Initialized
INFO - 2018-01-31 15:22:06 --> Model Class Initialized
INFO - 2018-01-31 15:22:06 --> Helper loaded: inflector_helper
DEBUG - 2018-01-31 15:22:06 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-31 15:22:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-31 15:22:06 --> Model Class Initialized
INFO - 2018-01-31 15:22:06 --> Model Class Initialized
INFO - 2018-01-31 15:22:06 --> Model Class Initialized
INFO - 2018-01-31 15:22:06 --> Model Class Initialized
INFO - 2018-01-31 15:22:06 --> Model Class Initialized
INFO - 2018-01-31 15:22:06 --> Model Class Initialized
INFO - 2018-01-31 15:22:06 --> Model Class Initialized
INFO - 2018-01-31 15:22:06 --> Model Class Initialized
INFO - 2018-01-31 15:22:06 --> Model Class Initialized
INFO - 2018-01-31 15:22:06 --> Model Class Initialized
INFO - 2018-01-31 15:22:06 --> Model Class Initialized
INFO - 2018-01-31 15:22:06 --> Language file loaded: language/english/message_lang.php
INFO - 2018-01-31 15:22:06 --> Model Class Initialized
INFO - 2018-01-31 15:22:06 --> Final output sent to browser
DEBUG - 2018-01-31 15:22:06 --> Total execution time: 0.1275
INFO - 2018-01-31 09:53:15 --> Config Class Initialized
INFO - 2018-01-31 09:53:15 --> Hooks Class Initialized
DEBUG - 2018-01-31 09:53:15 --> UTF-8 Support Enabled
INFO - 2018-01-31 09:53:15 --> Utf8 Class Initialized
INFO - 2018-01-31 09:53:15 --> URI Class Initialized
INFO - 2018-01-31 09:53:15 --> Router Class Initialized
INFO - 2018-01-31 09:53:15 --> Output Class Initialized
INFO - 2018-01-31 09:53:15 --> Security Class Initialized
DEBUG - 2018-01-31 09:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 09:53:15 --> Input Class Initialized
INFO - 2018-01-31 09:53:15 --> Language Class Initialized
INFO - 2018-01-31 09:53:15 --> Language Class Initialized
INFO - 2018-01-31 09:53:15 --> Config Class Initialized
INFO - 2018-01-31 09:53:15 --> Loader Class Initialized
INFO - 2018-01-31 15:23:15 --> Helper loaded: url_helper
INFO - 2018-01-31 15:23:15 --> Helper loaded: notification_helper
INFO - 2018-01-31 15:23:15 --> Helper loaded: settings_helper
INFO - 2018-01-31 15:23:15 --> Helper loaded: permission_helper
INFO - 2018-01-31 15:23:15 --> Helper loaded: users_helper
INFO - 2018-01-31 15:23:15 --> Database Driver Class Initialized
DEBUG - 2018-01-31 15:23:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 15:23:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 15:23:15 --> Helper loaded: form_helper
INFO - 2018-01-31 15:23:15 --> Form Validation Class Initialized
INFO - 2018-01-31 15:23:15 --> Controller Class Initialized
INFO - 2018-01-31 15:23:15 --> Model Class Initialized
INFO - 2018-01-31 15:23:15 --> Helper loaded: inflector_helper
DEBUG - 2018-01-31 15:23:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-31 15:23:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-31 15:23:15 --> Model Class Initialized
INFO - 2018-01-31 15:23:15 --> Model Class Initialized
INFO - 2018-01-31 15:23:15 --> Model Class Initialized
INFO - 2018-01-31 15:23:15 --> Model Class Initialized
INFO - 2018-01-31 15:23:15 --> Model Class Initialized
INFO - 2018-01-31 15:23:15 --> Model Class Initialized
INFO - 2018-01-31 15:23:15 --> Model Class Initialized
INFO - 2018-01-31 15:23:15 --> Model Class Initialized
INFO - 2018-01-31 15:23:15 --> Model Class Initialized
INFO - 2018-01-31 15:23:15 --> Model Class Initialized
INFO - 2018-01-31 15:23:15 --> Model Class Initialized
INFO - 2018-01-31 15:23:15 --> Language file loaded: language/english/message_lang.php
INFO - 2018-01-31 15:23:15 --> Model Class Initialized
INFO - 2018-01-31 15:23:15 --> Final output sent to browser
DEBUG - 2018-01-31 15:23:15 --> Total execution time: 0.1073
INFO - 2018-01-31 09:53:22 --> Config Class Initialized
INFO - 2018-01-31 09:53:22 --> Hooks Class Initialized
DEBUG - 2018-01-31 09:53:22 --> UTF-8 Support Enabled
INFO - 2018-01-31 09:53:22 --> Utf8 Class Initialized
INFO - 2018-01-31 09:53:22 --> URI Class Initialized
INFO - 2018-01-31 09:53:22 --> Router Class Initialized
INFO - 2018-01-31 09:53:22 --> Output Class Initialized
INFO - 2018-01-31 09:53:22 --> Security Class Initialized
DEBUG - 2018-01-31 09:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 09:53:22 --> Input Class Initialized
INFO - 2018-01-31 09:53:22 --> Language Class Initialized
INFO - 2018-01-31 09:53:22 --> Language Class Initialized
INFO - 2018-01-31 09:53:22 --> Config Class Initialized
INFO - 2018-01-31 09:53:22 --> Loader Class Initialized
INFO - 2018-01-31 15:23:22 --> Helper loaded: url_helper
INFO - 2018-01-31 15:23:22 --> Helper loaded: notification_helper
INFO - 2018-01-31 15:23:22 --> Helper loaded: settings_helper
INFO - 2018-01-31 15:23:22 --> Helper loaded: permission_helper
INFO - 2018-01-31 15:23:22 --> Helper loaded: users_helper
INFO - 2018-01-31 15:23:22 --> Database Driver Class Initialized
DEBUG - 2018-01-31 15:23:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 15:23:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 15:23:23 --> Helper loaded: form_helper
INFO - 2018-01-31 15:23:23 --> Form Validation Class Initialized
INFO - 2018-01-31 15:23:23 --> Controller Class Initialized
INFO - 2018-01-31 15:23:23 --> Model Class Initialized
INFO - 2018-01-31 15:23:23 --> Helper loaded: inflector_helper
DEBUG - 2018-01-31 15:23:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-31 15:23:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-31 15:23:23 --> Model Class Initialized
INFO - 2018-01-31 15:23:23 --> Model Class Initialized
INFO - 2018-01-31 15:23:23 --> Model Class Initialized
INFO - 2018-01-31 15:23:23 --> Model Class Initialized
INFO - 2018-01-31 15:23:23 --> Model Class Initialized
INFO - 2018-01-31 15:23:23 --> Model Class Initialized
INFO - 2018-01-31 15:23:23 --> Model Class Initialized
INFO - 2018-01-31 15:23:23 --> Model Class Initialized
INFO - 2018-01-31 15:23:23 --> Model Class Initialized
INFO - 2018-01-31 15:23:23 --> Model Class Initialized
INFO - 2018-01-31 15:23:23 --> Model Class Initialized
INFO - 2018-01-31 15:23:23 --> Language file loaded: language/english/message_lang.php
INFO - 2018-01-31 15:23:23 --> Model Class Initialized
INFO - 2018-01-31 15:23:23 --> Final output sent to browser
DEBUG - 2018-01-31 15:23:23 --> Total execution time: 0.1204
INFO - 2018-01-31 09:54:18 --> Config Class Initialized
INFO - 2018-01-31 09:54:18 --> Hooks Class Initialized
DEBUG - 2018-01-31 09:54:18 --> UTF-8 Support Enabled
INFO - 2018-01-31 09:54:18 --> Utf8 Class Initialized
INFO - 2018-01-31 09:54:18 --> URI Class Initialized
INFO - 2018-01-31 09:54:18 --> Router Class Initialized
INFO - 2018-01-31 09:54:18 --> Output Class Initialized
INFO - 2018-01-31 09:54:18 --> Security Class Initialized
DEBUG - 2018-01-31 09:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 09:54:18 --> Input Class Initialized
INFO - 2018-01-31 09:54:18 --> Language Class Initialized
INFO - 2018-01-31 09:54:18 --> Language Class Initialized
INFO - 2018-01-31 09:54:18 --> Config Class Initialized
INFO - 2018-01-31 09:54:18 --> Loader Class Initialized
INFO - 2018-01-31 15:24:18 --> Helper loaded: url_helper
INFO - 2018-01-31 15:24:18 --> Helper loaded: notification_helper
INFO - 2018-01-31 15:24:18 --> Helper loaded: settings_helper
INFO - 2018-01-31 15:24:18 --> Helper loaded: permission_helper
INFO - 2018-01-31 15:24:18 --> Helper loaded: users_helper
INFO - 2018-01-31 15:24:18 --> Database Driver Class Initialized
DEBUG - 2018-01-31 15:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 15:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 15:24:18 --> Helper loaded: form_helper
INFO - 2018-01-31 15:24:18 --> Form Validation Class Initialized
INFO - 2018-01-31 15:24:18 --> Controller Class Initialized
INFO - 2018-01-31 15:24:18 --> Model Class Initialized
INFO - 2018-01-31 15:24:18 --> Helper loaded: inflector_helper
DEBUG - 2018-01-31 15:24:18 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-31 15:24:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-31 15:24:18 --> Model Class Initialized
INFO - 2018-01-31 15:24:18 --> Model Class Initialized
INFO - 2018-01-31 15:24:18 --> Model Class Initialized
INFO - 2018-01-31 15:24:18 --> Model Class Initialized
INFO - 2018-01-31 15:24:18 --> Model Class Initialized
INFO - 2018-01-31 15:24:18 --> Model Class Initialized
INFO - 2018-01-31 15:24:18 --> Model Class Initialized
INFO - 2018-01-31 15:24:18 --> Model Class Initialized
INFO - 2018-01-31 15:24:18 --> Model Class Initialized
INFO - 2018-01-31 15:24:18 --> Model Class Initialized
INFO - 2018-01-31 15:24:18 --> Model Class Initialized
INFO - 2018-01-31 15:24:18 --> Language file loaded: language/english/message_lang.php
INFO - 2018-01-31 15:24:18 --> Model Class Initialized
INFO - 2018-01-31 15:24:18 --> Final output sent to browser
DEBUG - 2018-01-31 15:24:18 --> Total execution time: 0.1217
INFO - 2018-01-31 09:54:34 --> Config Class Initialized
INFO - 2018-01-31 09:54:34 --> Hooks Class Initialized
DEBUG - 2018-01-31 09:54:34 --> UTF-8 Support Enabled
INFO - 2018-01-31 09:54:34 --> Utf8 Class Initialized
INFO - 2018-01-31 09:54:34 --> URI Class Initialized
INFO - 2018-01-31 09:54:34 --> Router Class Initialized
INFO - 2018-01-31 09:54:34 --> Output Class Initialized
INFO - 2018-01-31 09:54:34 --> Security Class Initialized
DEBUG - 2018-01-31 09:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 09:54:34 --> Input Class Initialized
INFO - 2018-01-31 09:54:34 --> Language Class Initialized
INFO - 2018-01-31 09:54:34 --> Language Class Initialized
INFO - 2018-01-31 09:54:34 --> Config Class Initialized
INFO - 2018-01-31 09:54:34 --> Loader Class Initialized
INFO - 2018-01-31 15:24:34 --> Helper loaded: url_helper
INFO - 2018-01-31 15:24:34 --> Helper loaded: notification_helper
INFO - 2018-01-31 15:24:34 --> Helper loaded: settings_helper
INFO - 2018-01-31 15:24:34 --> Helper loaded: permission_helper
INFO - 2018-01-31 15:24:34 --> Helper loaded: users_helper
INFO - 2018-01-31 15:24:34 --> Database Driver Class Initialized
DEBUG - 2018-01-31 15:24:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 15:24:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 15:24:34 --> Helper loaded: form_helper
INFO - 2018-01-31 15:24:34 --> Form Validation Class Initialized
INFO - 2018-01-31 15:24:34 --> Controller Class Initialized
INFO - 2018-01-31 15:24:34 --> Model Class Initialized
INFO - 2018-01-31 15:24:34 --> Helper loaded: inflector_helper
DEBUG - 2018-01-31 15:24:34 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-31 15:24:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-31 15:24:34 --> Model Class Initialized
INFO - 2018-01-31 15:24:34 --> Model Class Initialized
INFO - 2018-01-31 15:24:34 --> Model Class Initialized
INFO - 2018-01-31 15:24:34 --> Model Class Initialized
INFO - 2018-01-31 15:24:34 --> Model Class Initialized
INFO - 2018-01-31 15:24:34 --> Model Class Initialized
INFO - 2018-01-31 15:24:34 --> Model Class Initialized
INFO - 2018-01-31 15:24:34 --> Model Class Initialized
INFO - 2018-01-31 15:24:34 --> Model Class Initialized
INFO - 2018-01-31 15:24:34 --> Model Class Initialized
INFO - 2018-01-31 15:24:34 --> Model Class Initialized
INFO - 2018-01-31 15:24:34 --> Language file loaded: language/english/message_lang.php
INFO - 2018-01-31 15:24:34 --> Model Class Initialized
INFO - 2018-01-31 15:24:34 --> Final output sent to browser
DEBUG - 2018-01-31 15:24:34 --> Total execution time: 0.1289
INFO - 2018-01-31 09:54:56 --> Config Class Initialized
INFO - 2018-01-31 09:54:56 --> Hooks Class Initialized
DEBUG - 2018-01-31 09:54:56 --> UTF-8 Support Enabled
INFO - 2018-01-31 09:54:56 --> Utf8 Class Initialized
INFO - 2018-01-31 09:54:56 --> URI Class Initialized
INFO - 2018-01-31 09:54:56 --> Router Class Initialized
INFO - 2018-01-31 09:54:56 --> Output Class Initialized
INFO - 2018-01-31 09:54:56 --> Security Class Initialized
DEBUG - 2018-01-31 09:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 09:54:56 --> Input Class Initialized
INFO - 2018-01-31 09:54:56 --> Language Class Initialized
INFO - 2018-01-31 09:54:56 --> Language Class Initialized
INFO - 2018-01-31 09:54:56 --> Config Class Initialized
INFO - 2018-01-31 09:54:56 --> Loader Class Initialized
INFO - 2018-01-31 15:24:56 --> Helper loaded: url_helper
INFO - 2018-01-31 15:24:56 --> Helper loaded: notification_helper
INFO - 2018-01-31 15:24:56 --> Helper loaded: settings_helper
INFO - 2018-01-31 15:24:56 --> Helper loaded: permission_helper
INFO - 2018-01-31 15:24:56 --> Helper loaded: users_helper
INFO - 2018-01-31 15:24:56 --> Database Driver Class Initialized
DEBUG - 2018-01-31 15:24:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 15:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 15:24:56 --> Helper loaded: form_helper
INFO - 2018-01-31 15:24:56 --> Form Validation Class Initialized
INFO - 2018-01-31 15:24:56 --> Controller Class Initialized
INFO - 2018-01-31 15:24:56 --> Model Class Initialized
INFO - 2018-01-31 15:24:56 --> Helper loaded: inflector_helper
DEBUG - 2018-01-31 15:24:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-31 15:24:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-31 15:24:56 --> Model Class Initialized
INFO - 2018-01-31 15:24:56 --> Model Class Initialized
INFO - 2018-01-31 15:24:56 --> Model Class Initialized
INFO - 2018-01-31 15:24:56 --> Model Class Initialized
INFO - 2018-01-31 15:24:56 --> Model Class Initialized
INFO - 2018-01-31 15:24:56 --> Model Class Initialized
INFO - 2018-01-31 15:24:56 --> Model Class Initialized
INFO - 2018-01-31 15:24:56 --> Model Class Initialized
INFO - 2018-01-31 15:24:56 --> Model Class Initialized
INFO - 2018-01-31 15:24:56 --> Model Class Initialized
INFO - 2018-01-31 15:24:56 --> Model Class Initialized
INFO - 2018-01-31 15:24:56 --> Language file loaded: language/english/message_lang.php
INFO - 2018-01-31 15:24:56 --> Model Class Initialized
INFO - 2018-01-31 15:24:56 --> Final output sent to browser
DEBUG - 2018-01-31 15:24:56 --> Total execution time: 0.1285
INFO - 2018-01-31 09:55:43 --> Config Class Initialized
INFO - 2018-01-31 09:55:43 --> Hooks Class Initialized
DEBUG - 2018-01-31 09:55:43 --> UTF-8 Support Enabled
INFO - 2018-01-31 09:55:43 --> Utf8 Class Initialized
INFO - 2018-01-31 09:55:43 --> URI Class Initialized
INFO - 2018-01-31 09:55:43 --> Router Class Initialized
INFO - 2018-01-31 09:55:43 --> Output Class Initialized
INFO - 2018-01-31 09:55:43 --> Security Class Initialized
DEBUG - 2018-01-31 09:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 09:55:43 --> Input Class Initialized
INFO - 2018-01-31 09:55:43 --> Language Class Initialized
INFO - 2018-01-31 09:55:43 --> Language Class Initialized
INFO - 2018-01-31 09:55:43 --> Config Class Initialized
INFO - 2018-01-31 09:55:43 --> Loader Class Initialized
INFO - 2018-01-31 15:25:43 --> Helper loaded: url_helper
INFO - 2018-01-31 15:25:43 --> Helper loaded: notification_helper
INFO - 2018-01-31 15:25:43 --> Helper loaded: settings_helper
INFO - 2018-01-31 15:25:43 --> Helper loaded: permission_helper
INFO - 2018-01-31 15:25:43 --> Helper loaded: users_helper
INFO - 2018-01-31 15:25:43 --> Database Driver Class Initialized
DEBUG - 2018-01-31 15:25:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 15:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 15:25:43 --> Helper loaded: form_helper
INFO - 2018-01-31 15:25:43 --> Form Validation Class Initialized
INFO - 2018-01-31 15:25:43 --> Controller Class Initialized
INFO - 2018-01-31 15:25:43 --> Model Class Initialized
INFO - 2018-01-31 15:25:43 --> Helper loaded: inflector_helper
DEBUG - 2018-01-31 15:25:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-31 15:25:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-31 15:25:43 --> Model Class Initialized
INFO - 2018-01-31 15:25:43 --> Model Class Initialized
INFO - 2018-01-31 15:25:43 --> Model Class Initialized
INFO - 2018-01-31 15:25:43 --> Model Class Initialized
INFO - 2018-01-31 15:25:43 --> Model Class Initialized
INFO - 2018-01-31 15:25:43 --> Model Class Initialized
INFO - 2018-01-31 15:25:43 --> Model Class Initialized
INFO - 2018-01-31 15:25:43 --> Model Class Initialized
INFO - 2018-01-31 15:25:43 --> Model Class Initialized
INFO - 2018-01-31 15:25:43 --> Model Class Initialized
INFO - 2018-01-31 15:25:43 --> Model Class Initialized
INFO - 2018-01-31 15:25:43 --> Language file loaded: language/english/message_lang.php
INFO - 2018-01-31 15:25:43 --> Model Class Initialized
INFO - 2018-01-31 15:25:43 --> Final output sent to browser
DEBUG - 2018-01-31 15:25:43 --> Total execution time: 0.1287
INFO - 2018-01-31 09:55:59 --> Config Class Initialized
INFO - 2018-01-31 09:55:59 --> Hooks Class Initialized
DEBUG - 2018-01-31 09:55:59 --> UTF-8 Support Enabled
INFO - 2018-01-31 09:55:59 --> Utf8 Class Initialized
INFO - 2018-01-31 09:55:59 --> URI Class Initialized
INFO - 2018-01-31 09:55:59 --> Router Class Initialized
INFO - 2018-01-31 09:55:59 --> Output Class Initialized
INFO - 2018-01-31 09:55:59 --> Security Class Initialized
DEBUG - 2018-01-31 09:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 09:55:59 --> Input Class Initialized
INFO - 2018-01-31 09:55:59 --> Language Class Initialized
INFO - 2018-01-31 09:55:59 --> Language Class Initialized
INFO - 2018-01-31 09:55:59 --> Config Class Initialized
INFO - 2018-01-31 09:55:59 --> Loader Class Initialized
INFO - 2018-01-31 15:25:59 --> Helper loaded: url_helper
INFO - 2018-01-31 15:25:59 --> Helper loaded: notification_helper
INFO - 2018-01-31 15:25:59 --> Helper loaded: settings_helper
INFO - 2018-01-31 15:25:59 --> Helper loaded: permission_helper
INFO - 2018-01-31 15:25:59 --> Helper loaded: users_helper
INFO - 2018-01-31 15:25:59 --> Database Driver Class Initialized
DEBUG - 2018-01-31 15:25:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 15:25:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 15:25:59 --> Helper loaded: form_helper
INFO - 2018-01-31 15:25:59 --> Form Validation Class Initialized
INFO - 2018-01-31 15:25:59 --> Controller Class Initialized
INFO - 2018-01-31 15:25:59 --> Model Class Initialized
INFO - 2018-01-31 15:25:59 --> Helper loaded: inflector_helper
DEBUG - 2018-01-31 15:25:59 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-31 15:25:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-31 15:25:59 --> Model Class Initialized
INFO - 2018-01-31 15:25:59 --> Model Class Initialized
INFO - 2018-01-31 15:25:59 --> Model Class Initialized
INFO - 2018-01-31 15:25:59 --> Model Class Initialized
INFO - 2018-01-31 15:25:59 --> Model Class Initialized
INFO - 2018-01-31 15:25:59 --> Model Class Initialized
INFO - 2018-01-31 15:25:59 --> Model Class Initialized
INFO - 2018-01-31 15:25:59 --> Model Class Initialized
INFO - 2018-01-31 15:25:59 --> Model Class Initialized
INFO - 2018-01-31 15:25:59 --> Model Class Initialized
INFO - 2018-01-31 15:25:59 --> Model Class Initialized
INFO - 2018-01-31 15:25:59 --> Language file loaded: language/english/message_lang.php
INFO - 2018-01-31 15:25:59 --> Model Class Initialized
INFO - 2018-01-31 15:25:59 --> Final output sent to browser
DEBUG - 2018-01-31 15:25:59 --> Total execution time: 0.1311
INFO - 2018-01-31 10:02:16 --> Config Class Initialized
INFO - 2018-01-31 10:02:16 --> Hooks Class Initialized
DEBUG - 2018-01-31 10:02:16 --> UTF-8 Support Enabled
INFO - 2018-01-31 10:02:16 --> Utf8 Class Initialized
INFO - 2018-01-31 10:02:16 --> URI Class Initialized
DEBUG - 2018-01-31 10:02:16 --> No URI present. Default controller set.
INFO - 2018-01-31 10:02:16 --> Router Class Initialized
INFO - 2018-01-31 10:02:16 --> Output Class Initialized
INFO - 2018-01-31 10:02:16 --> Security Class Initialized
DEBUG - 2018-01-31 10:02:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 10:02:16 --> Input Class Initialized
INFO - 2018-01-31 10:02:16 --> Language Class Initialized
INFO - 2018-01-31 10:02:16 --> Language Class Initialized
INFO - 2018-01-31 10:02:16 --> Config Class Initialized
INFO - 2018-01-31 10:02:16 --> Loader Class Initialized
INFO - 2018-01-31 15:32:16 --> Helper loaded: url_helper
INFO - 2018-01-31 15:32:16 --> Helper loaded: notification_helper
INFO - 2018-01-31 15:32:16 --> Helper loaded: settings_helper
INFO - 2018-01-31 15:32:16 --> Helper loaded: permission_helper
INFO - 2018-01-31 15:32:16 --> Helper loaded: users_helper
INFO - 2018-01-31 15:32:16 --> Database Driver Class Initialized
DEBUG - 2018-01-31 15:32:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 15:32:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 15:32:16 --> Helper loaded: form_helper
INFO - 2018-01-31 15:32:16 --> Form Validation Class Initialized
INFO - 2018-01-31 15:32:16 --> Controller Class Initialized
INFO - 2018-01-31 15:32:16 --> Model Class Initialized
INFO - 2018-01-31 15:32:16 --> Helper loaded: inflector_helper
INFO - 2018-01-31 15:32:16 --> Model Class Initialized
DEBUG - 2018-01-31 15:32:16 --> File loaded: /home/pr01004/public_html/application/views/login.php
INFO - 2018-01-31 15:32:16 --> Final output sent to browser
DEBUG - 2018-01-31 15:32:16 --> Total execution time: 0.0770
INFO - 2018-01-31 10:02:43 --> Config Class Initialized
INFO - 2018-01-31 10:02:43 --> Hooks Class Initialized
DEBUG - 2018-01-31 10:02:43 --> UTF-8 Support Enabled
INFO - 2018-01-31 10:02:43 --> Utf8 Class Initialized
INFO - 2018-01-31 10:02:43 --> URI Class Initialized
INFO - 2018-01-31 10:02:43 --> Router Class Initialized
INFO - 2018-01-31 10:02:43 --> Output Class Initialized
INFO - 2018-01-31 10:02:43 --> Security Class Initialized
DEBUG - 2018-01-31 10:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 10:02:43 --> Input Class Initialized
INFO - 2018-01-31 10:02:43 --> Language Class Initialized
INFO - 2018-01-31 10:02:43 --> Language Class Initialized
INFO - 2018-01-31 10:02:43 --> Config Class Initialized
INFO - 2018-01-31 10:02:43 --> Loader Class Initialized
INFO - 2018-01-31 15:32:43 --> Helper loaded: url_helper
INFO - 2018-01-31 15:32:43 --> Helper loaded: notification_helper
INFO - 2018-01-31 15:32:43 --> Helper loaded: settings_helper
INFO - 2018-01-31 15:32:43 --> Helper loaded: permission_helper
INFO - 2018-01-31 15:32:43 --> Helper loaded: users_helper
INFO - 2018-01-31 15:32:43 --> Database Driver Class Initialized
DEBUG - 2018-01-31 15:32:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 15:32:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 15:32:43 --> Helper loaded: form_helper
INFO - 2018-01-31 15:32:43 --> Form Validation Class Initialized
INFO - 2018-01-31 15:32:43 --> Controller Class Initialized
INFO - 2018-01-31 15:32:43 --> Model Class Initialized
INFO - 2018-01-31 15:32:43 --> Helper loaded: inflector_helper
INFO - 2018-01-31 15:32:43 --> Model Class Initialized
INFO - 2018-01-31 15:32:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-01-31 10:02:43 --> Config Class Initialized
INFO - 2018-01-31 10:02:43 --> Hooks Class Initialized
DEBUG - 2018-01-31 10:02:43 --> UTF-8 Support Enabled
INFO - 2018-01-31 10:02:43 --> Utf8 Class Initialized
INFO - 2018-01-31 10:02:43 --> URI Class Initialized
INFO - 2018-01-31 10:02:43 --> Router Class Initialized
INFO - 2018-01-31 10:02:43 --> Config Class Initialized
INFO - 2018-01-31 10:02:43 --> Hooks Class Initialized
INFO - 2018-01-31 10:02:43 --> Output Class Initialized
DEBUG - 2018-01-31 10:02:43 --> UTF-8 Support Enabled
INFO - 2018-01-31 10:02:43 --> Utf8 Class Initialized
INFO - 2018-01-31 10:02:43 --> Security Class Initialized
INFO - 2018-01-31 10:02:43 --> URI Class Initialized
DEBUG - 2018-01-31 10:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 10:02:43 --> Input Class Initialized
INFO - 2018-01-31 10:02:43 --> Language Class Initialized
INFO - 2018-01-31 10:02:43 --> Router Class Initialized
INFO - 2018-01-31 10:02:43 --> Output Class Initialized
INFO - 2018-01-31 10:02:43 --> Security Class Initialized
INFO - 2018-01-31 10:02:43 --> Language Class Initialized
INFO - 2018-01-31 10:02:43 --> Config Class Initialized
INFO - 2018-01-31 10:02:43 --> Loader Class Initialized
DEBUG - 2018-01-31 10:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 10:02:43 --> Input Class Initialized
INFO - 2018-01-31 15:32:43 --> Helper loaded: url_helper
INFO - 2018-01-31 10:02:43 --> Language Class Initialized
INFO - 2018-01-31 15:32:43 --> Helper loaded: notification_helper
INFO - 2018-01-31 15:32:43 --> Helper loaded: settings_helper
INFO - 2018-01-31 15:32:43 --> Helper loaded: permission_helper
INFO - 2018-01-31 15:32:43 --> Helper loaded: users_helper
INFO - 2018-01-31 10:02:43 --> Language Class Initialized
INFO - 2018-01-31 10:02:43 --> Config Class Initialized
INFO - 2018-01-31 10:02:43 --> Loader Class Initialized
INFO - 2018-01-31 15:32:43 --> Helper loaded: url_helper
INFO - 2018-01-31 15:32:43 --> Helper loaded: notification_helper
INFO - 2018-01-31 15:32:43 --> Helper loaded: settings_helper
INFO - 2018-01-31 15:32:43 --> Helper loaded: permission_helper
INFO - 2018-01-31 15:32:43 --> Helper loaded: users_helper
INFO - 2018-01-31 15:32:43 --> Database Driver Class Initialized
DEBUG - 2018-01-31 15:32:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 15:32:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 15:32:43 --> Database Driver Class Initialized
INFO - 2018-01-31 15:32:43 --> Helper loaded: form_helper
INFO - 2018-01-31 15:32:43 --> Form Validation Class Initialized
INFO - 2018-01-31 15:32:43 --> Controller Class Initialized
DEBUG - 2018-01-31 15:32:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 15:32:43 --> Model Class Initialized
INFO - 2018-01-31 15:32:43 --> Helper loaded: inflector_helper
INFO - 2018-01-31 15:32:43 --> Model Class Initialized
INFO - 2018-01-31 15:32:43 --> Model Class Initialized
INFO - 2018-01-31 15:32:43 --> Model Class Initialized
INFO - 2018-01-31 15:32:43 --> Model Class Initialized
INFO - 2018-01-31 15:32:43 --> Model Class Initialized
DEBUG - 2018-01-31 15:32:43 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-01-31 15:32:43 --> File loaded: /home/pr01004/public_html/application/views/admin/dashboard.php
DEBUG - 2018-01-31 15:32:43 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-01-31 15:32:43 --> Final output sent to browser
DEBUG - 2018-01-31 15:32:43 --> Total execution time: 0.0988
INFO - 2018-01-31 15:32:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 15:32:43 --> Helper loaded: form_helper
INFO - 2018-01-31 15:32:43 --> Form Validation Class Initialized
INFO - 2018-01-31 15:32:43 --> Controller Class Initialized
DEBUG - 2018-01-31 15:32:43 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-01-31 15:32:43 --> Final output sent to browser
DEBUG - 2018-01-31 15:32:43 --> Total execution time: 0.1004
INFO - 2018-01-31 10:02:58 --> Config Class Initialized
INFO - 2018-01-31 10:02:58 --> Hooks Class Initialized
DEBUG - 2018-01-31 10:02:58 --> UTF-8 Support Enabled
INFO - 2018-01-31 10:02:58 --> Utf8 Class Initialized
INFO - 2018-01-31 10:02:58 --> URI Class Initialized
INFO - 2018-01-31 10:02:58 --> Router Class Initialized
INFO - 2018-01-31 10:02:58 --> Output Class Initialized
INFO - 2018-01-31 10:02:58 --> Security Class Initialized
DEBUG - 2018-01-31 10:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 10:02:58 --> Input Class Initialized
INFO - 2018-01-31 10:02:58 --> Language Class Initialized
INFO - 2018-01-31 10:02:58 --> Language Class Initialized
INFO - 2018-01-31 10:02:58 --> Config Class Initialized
INFO - 2018-01-31 10:02:58 --> Loader Class Initialized
INFO - 2018-01-31 15:32:58 --> Helper loaded: url_helper
INFO - 2018-01-31 15:32:58 --> Helper loaded: notification_helper
INFO - 2018-01-31 15:32:58 --> Helper loaded: settings_helper
INFO - 2018-01-31 15:32:58 --> Helper loaded: permission_helper
INFO - 2018-01-31 15:32:58 --> Helper loaded: users_helper
INFO - 2018-01-31 15:32:58 --> Database Driver Class Initialized
DEBUG - 2018-01-31 15:32:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 15:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 15:32:58 --> Helper loaded: form_helper
INFO - 2018-01-31 15:32:58 --> Form Validation Class Initialized
INFO - 2018-01-31 15:32:58 --> Controller Class Initialized
INFO - 2018-01-31 15:32:58 --> Model Class Initialized
INFO - 2018-01-31 15:32:58 --> Helper loaded: inflector_helper
INFO - 2018-01-31 15:32:58 --> Model Class Initialized
INFO - 2018-01-31 15:32:58 --> Model Class Initialized
DEBUG - 2018-01-31 15:32:58 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-01-31 15:32:58 --> File loaded: /home/pr01004/public_html/application/views/users/usersList.php
DEBUG - 2018-01-31 15:32:58 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-01-31 15:32:58 --> Final output sent to browser
DEBUG - 2018-01-31 15:32:58 --> Total execution time: 0.1128
INFO - 2018-01-31 10:03:12 --> Config Class Initialized
INFO - 2018-01-31 10:03:12 --> Hooks Class Initialized
DEBUG - 2018-01-31 10:03:12 --> UTF-8 Support Enabled
INFO - 2018-01-31 10:03:12 --> Utf8 Class Initialized
INFO - 2018-01-31 10:03:12 --> URI Class Initialized
INFO - 2018-01-31 10:03:12 --> Router Class Initialized
INFO - 2018-01-31 10:03:12 --> Output Class Initialized
INFO - 2018-01-31 10:03:12 --> Security Class Initialized
DEBUG - 2018-01-31 10:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 10:03:12 --> Input Class Initialized
INFO - 2018-01-31 10:03:12 --> Language Class Initialized
INFO - 2018-01-31 10:03:12 --> Language Class Initialized
INFO - 2018-01-31 10:03:12 --> Config Class Initialized
INFO - 2018-01-31 10:03:12 --> Loader Class Initialized
INFO - 2018-01-31 15:33:12 --> Helper loaded: url_helper
INFO - 2018-01-31 15:33:12 --> Helper loaded: notification_helper
INFO - 2018-01-31 15:33:12 --> Helper loaded: settings_helper
INFO - 2018-01-31 15:33:12 --> Helper loaded: permission_helper
INFO - 2018-01-31 15:33:12 --> Helper loaded: users_helper
INFO - 2018-01-31 15:33:12 --> Database Driver Class Initialized
DEBUG - 2018-01-31 15:33:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 15:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 10:03:12 --> Config Class Initialized
INFO - 2018-01-31 10:03:12 --> Hooks Class Initialized
DEBUG - 2018-01-31 10:03:12 --> UTF-8 Support Enabled
INFO - 2018-01-31 10:03:12 --> Utf8 Class Initialized
INFO - 2018-01-31 15:33:12 --> Helper loaded: form_helper
INFO - 2018-01-31 15:33:12 --> Form Validation Class Initialized
INFO - 2018-01-31 15:33:12 --> Controller Class Initialized
INFO - 2018-01-31 10:03:12 --> URI Class Initialized
INFO - 2018-01-31 10:03:12 --> Router Class Initialized
INFO - 2018-01-31 10:03:12 --> Output Class Initialized
INFO - 2018-01-31 15:33:12 --> Model Class Initialized
INFO - 2018-01-31 15:33:12 --> Helper loaded: inflector_helper
INFO - 2018-01-31 10:03:12 --> Security Class Initialized
INFO - 2018-01-31 15:33:12 --> Model Class Initialized
DEBUG - 2018-01-31 10:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 10:03:12 --> Input Class Initialized
INFO - 2018-01-31 10:03:12 --> Language Class Initialized
INFO - 2018-01-31 15:33:12 --> Model Class Initialized
DEBUG - 2018-01-31 15:33:12 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
INFO - 2018-01-31 10:03:12 --> Language Class Initialized
INFO - 2018-01-31 10:03:12 --> Config Class Initialized
INFO - 2018-01-31 10:03:12 --> Loader Class Initialized
DEBUG - 2018-01-31 15:33:12 --> File loaded: /home/pr01004/public_html/application/views/users/usersList.php
DEBUG - 2018-01-31 15:33:12 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-01-31 15:33:12 --> Final output sent to browser
DEBUG - 2018-01-31 15:33:12 --> Total execution time: 0.0994
INFO - 2018-01-31 15:33:12 --> Helper loaded: url_helper
INFO - 2018-01-31 15:33:12 --> Helper loaded: notification_helper
INFO - 2018-01-31 15:33:12 --> Helper loaded: settings_helper
INFO - 2018-01-31 15:33:12 --> Helper loaded: permission_helper
INFO - 2018-01-31 15:33:12 --> Helper loaded: users_helper
INFO - 2018-01-31 15:33:12 --> Database Driver Class Initialized
DEBUG - 2018-01-31 15:33:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 15:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 15:33:12 --> Helper loaded: form_helper
INFO - 2018-01-31 15:33:12 --> Form Validation Class Initialized
INFO - 2018-01-31 15:33:12 --> Controller Class Initialized
INFO - 2018-01-31 15:33:12 --> Model Class Initialized
INFO - 2018-01-31 15:33:12 --> Helper loaded: inflector_helper
INFO - 2018-01-31 15:33:12 --> Model Class Initialized
INFO - 2018-01-31 15:33:12 --> Model Class Initialized
INFO - 2018-01-31 15:33:12 --> Model Class Initialized
INFO - 2018-01-31 15:33:12 --> Final output sent to browser
DEBUG - 2018-01-31 15:33:12 --> Total execution time: 0.1058
INFO - 2018-01-31 10:03:13 --> Config Class Initialized
INFO - 2018-01-31 10:03:13 --> Hooks Class Initialized
DEBUG - 2018-01-31 10:03:13 --> UTF-8 Support Enabled
INFO - 2018-01-31 10:03:13 --> Utf8 Class Initialized
INFO - 2018-01-31 10:03:13 --> URI Class Initialized
INFO - 2018-01-31 10:03:13 --> Router Class Initialized
INFO - 2018-01-31 10:03:13 --> Output Class Initialized
INFO - 2018-01-31 10:03:13 --> Security Class Initialized
DEBUG - 2018-01-31 10:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 10:03:13 --> Input Class Initialized
INFO - 2018-01-31 10:03:13 --> Language Class Initialized
INFO - 2018-01-31 10:03:13 --> Language Class Initialized
INFO - 2018-01-31 10:03:13 --> Config Class Initialized
INFO - 2018-01-31 10:03:13 --> Loader Class Initialized
INFO - 2018-01-31 15:33:13 --> Helper loaded: url_helper
INFO - 2018-01-31 15:33:13 --> Helper loaded: notification_helper
INFO - 2018-01-31 15:33:13 --> Helper loaded: settings_helper
INFO - 2018-01-31 15:33:13 --> Helper loaded: permission_helper
INFO - 2018-01-31 15:33:13 --> Helper loaded: users_helper
INFO - 2018-01-31 15:33:13 --> Database Driver Class Initialized
DEBUG - 2018-01-31 15:33:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 15:33:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 15:33:13 --> Helper loaded: form_helper
INFO - 2018-01-31 15:33:13 --> Form Validation Class Initialized
INFO - 2018-01-31 15:33:13 --> Controller Class Initialized
INFO - 2018-01-31 15:33:13 --> Model Class Initialized
INFO - 2018-01-31 15:33:13 --> Helper loaded: inflector_helper
INFO - 2018-01-31 15:33:13 --> Model Class Initialized
INFO - 2018-01-31 15:33:13 --> Model Class Initialized
INFO - 2018-01-31 15:33:13 --> Model Class Initialized
INFO - 2018-01-31 15:33:13 --> Final output sent to browser
DEBUG - 2018-01-31 15:33:13 --> Total execution time: 0.1017
INFO - 2018-01-31 10:03:16 --> Config Class Initialized
INFO - 2018-01-31 10:03:16 --> Hooks Class Initialized
DEBUG - 2018-01-31 10:03:16 --> UTF-8 Support Enabled
INFO - 2018-01-31 10:03:16 --> Utf8 Class Initialized
INFO - 2018-01-31 10:03:16 --> URI Class Initialized
INFO - 2018-01-31 10:03:16 --> Router Class Initialized
INFO - 2018-01-31 10:03:16 --> Output Class Initialized
INFO - 2018-01-31 10:03:16 --> Security Class Initialized
DEBUG - 2018-01-31 10:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 10:03:16 --> Input Class Initialized
INFO - 2018-01-31 10:03:16 --> Language Class Initialized
INFO - 2018-01-31 10:03:16 --> Language Class Initialized
INFO - 2018-01-31 10:03:16 --> Config Class Initialized
INFO - 2018-01-31 10:03:16 --> Loader Class Initialized
INFO - 2018-01-31 15:33:16 --> Helper loaded: url_helper
INFO - 2018-01-31 15:33:16 --> Helper loaded: notification_helper
INFO - 2018-01-31 15:33:16 --> Helper loaded: settings_helper
INFO - 2018-01-31 15:33:16 --> Helper loaded: permission_helper
INFO - 2018-01-31 15:33:16 --> Helper loaded: users_helper
INFO - 2018-01-31 15:33:16 --> Database Driver Class Initialized
DEBUG - 2018-01-31 15:33:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 15:33:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 15:33:16 --> Helper loaded: form_helper
INFO - 2018-01-31 15:33:16 --> Form Validation Class Initialized
INFO - 2018-01-31 15:33:16 --> Controller Class Initialized
INFO - 2018-01-31 15:33:16 --> Model Class Initialized
INFO - 2018-01-31 15:33:16 --> Helper loaded: inflector_helper
INFO - 2018-01-31 15:33:16 --> Model Class Initialized
INFO - 2018-01-31 15:33:16 --> Model Class Initialized
INFO - 2018-01-31 15:33:16 --> Model Class Initialized
INFO - 2018-01-31 15:33:16 --> Final output sent to browser
DEBUG - 2018-01-31 15:33:16 --> Total execution time: 0.1059
INFO - 2018-01-31 10:03:17 --> Config Class Initialized
INFO - 2018-01-31 10:03:17 --> Hooks Class Initialized
DEBUG - 2018-01-31 10:03:17 --> UTF-8 Support Enabled
INFO - 2018-01-31 10:03:17 --> Utf8 Class Initialized
INFO - 2018-01-31 10:03:17 --> URI Class Initialized
INFO - 2018-01-31 10:03:17 --> Router Class Initialized
INFO - 2018-01-31 10:03:17 --> Output Class Initialized
INFO - 2018-01-31 10:03:17 --> Security Class Initialized
DEBUG - 2018-01-31 10:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 10:03:17 --> Input Class Initialized
INFO - 2018-01-31 10:03:17 --> Language Class Initialized
INFO - 2018-01-31 10:03:17 --> Language Class Initialized
INFO - 2018-01-31 10:03:17 --> Config Class Initialized
INFO - 2018-01-31 10:03:17 --> Loader Class Initialized
INFO - 2018-01-31 15:33:17 --> Helper loaded: url_helper
INFO - 2018-01-31 15:33:17 --> Helper loaded: notification_helper
INFO - 2018-01-31 15:33:17 --> Helper loaded: settings_helper
INFO - 2018-01-31 15:33:17 --> Helper loaded: permission_helper
INFO - 2018-01-31 15:33:17 --> Helper loaded: users_helper
INFO - 2018-01-31 15:33:17 --> Database Driver Class Initialized
DEBUG - 2018-01-31 15:33:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 15:33:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 15:33:17 --> Helper loaded: form_helper
INFO - 2018-01-31 15:33:17 --> Form Validation Class Initialized
INFO - 2018-01-31 15:33:17 --> Controller Class Initialized
INFO - 2018-01-31 15:33:17 --> Model Class Initialized
INFO - 2018-01-31 15:33:17 --> Helper loaded: inflector_helper
INFO - 2018-01-31 15:33:17 --> Model Class Initialized
INFO - 2018-01-31 15:33:17 --> Model Class Initialized
INFO - 2018-01-31 15:33:17 --> Model Class Initialized
INFO - 2018-01-31 15:33:17 --> Final output sent to browser
DEBUG - 2018-01-31 15:33:17 --> Total execution time: 0.0787
INFO - 2018-01-31 10:03:18 --> Config Class Initialized
INFO - 2018-01-31 10:03:18 --> Hooks Class Initialized
DEBUG - 2018-01-31 10:03:18 --> UTF-8 Support Enabled
INFO - 2018-01-31 10:03:18 --> Utf8 Class Initialized
INFO - 2018-01-31 10:03:18 --> URI Class Initialized
INFO - 2018-01-31 10:03:18 --> Router Class Initialized
INFO - 2018-01-31 10:03:18 --> Output Class Initialized
INFO - 2018-01-31 10:03:18 --> Security Class Initialized
DEBUG - 2018-01-31 10:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 10:03:18 --> Input Class Initialized
INFO - 2018-01-31 10:03:18 --> Language Class Initialized
INFO - 2018-01-31 10:03:18 --> Language Class Initialized
INFO - 2018-01-31 10:03:18 --> Config Class Initialized
INFO - 2018-01-31 10:03:18 --> Loader Class Initialized
INFO - 2018-01-31 15:33:18 --> Helper loaded: url_helper
INFO - 2018-01-31 15:33:18 --> Helper loaded: notification_helper
INFO - 2018-01-31 15:33:18 --> Helper loaded: settings_helper
INFO - 2018-01-31 15:33:18 --> Helper loaded: permission_helper
INFO - 2018-01-31 15:33:18 --> Helper loaded: users_helper
INFO - 2018-01-31 15:33:18 --> Database Driver Class Initialized
DEBUG - 2018-01-31 15:33:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 15:33:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 15:33:18 --> Helper loaded: form_helper
INFO - 2018-01-31 15:33:18 --> Form Validation Class Initialized
INFO - 2018-01-31 15:33:18 --> Controller Class Initialized
INFO - 2018-01-31 10:03:18 --> Config Class Initialized
INFO - 2018-01-31 10:03:18 --> Hooks Class Initialized
DEBUG - 2018-01-31 10:03:18 --> UTF-8 Support Enabled
INFO - 2018-01-31 10:03:18 --> Utf8 Class Initialized
INFO - 2018-01-31 15:33:18 --> Model Class Initialized
INFO - 2018-01-31 10:03:18 --> URI Class Initialized
INFO - 2018-01-31 15:33:18 --> Helper loaded: inflector_helper
INFO - 2018-01-31 15:33:18 --> Model Class Initialized
INFO - 2018-01-31 10:03:18 --> Router Class Initialized
INFO - 2018-01-31 15:33:18 --> Model Class Initialized
INFO - 2018-01-31 10:03:18 --> Output Class Initialized
INFO - 2018-01-31 15:33:18 --> Model Class Initialized
INFO - 2018-01-31 10:03:18 --> Security Class Initialized
INFO - 2018-01-31 15:33:18 --> Final output sent to browser
DEBUG - 2018-01-31 15:33:18 --> Total execution time: 0.0980
DEBUG - 2018-01-31 10:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 10:03:18 --> Input Class Initialized
INFO - 2018-01-31 10:03:18 --> Language Class Initialized
INFO - 2018-01-31 10:03:18 --> Language Class Initialized
INFO - 2018-01-31 10:03:18 --> Config Class Initialized
INFO - 2018-01-31 10:03:18 --> Loader Class Initialized
INFO - 2018-01-31 15:33:18 --> Helper loaded: url_helper
INFO - 2018-01-31 15:33:18 --> Helper loaded: notification_helper
INFO - 2018-01-31 15:33:18 --> Helper loaded: settings_helper
INFO - 2018-01-31 15:33:18 --> Helper loaded: permission_helper
INFO - 2018-01-31 15:33:18 --> Helper loaded: users_helper
INFO - 2018-01-31 15:33:18 --> Database Driver Class Initialized
DEBUG - 2018-01-31 15:33:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 15:33:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 15:33:18 --> Helper loaded: form_helper
INFO - 2018-01-31 15:33:18 --> Form Validation Class Initialized
INFO - 2018-01-31 15:33:18 --> Controller Class Initialized
INFO - 2018-01-31 15:33:18 --> Model Class Initialized
INFO - 2018-01-31 15:33:18 --> Helper loaded: inflector_helper
INFO - 2018-01-31 15:33:18 --> Model Class Initialized
INFO - 2018-01-31 15:33:18 --> Model Class Initialized
INFO - 2018-01-31 15:33:18 --> Model Class Initialized
INFO - 2018-01-31 15:33:18 --> Final output sent to browser
DEBUG - 2018-01-31 15:33:18 --> Total execution time: 0.1051
INFO - 2018-01-31 10:03:21 --> Config Class Initialized
INFO - 2018-01-31 10:03:21 --> Hooks Class Initialized
DEBUG - 2018-01-31 10:03:21 --> UTF-8 Support Enabled
INFO - 2018-01-31 10:03:21 --> Utf8 Class Initialized
INFO - 2018-01-31 10:03:21 --> URI Class Initialized
INFO - 2018-01-31 10:03:21 --> Router Class Initialized
INFO - 2018-01-31 10:03:21 --> Output Class Initialized
INFO - 2018-01-31 10:03:21 --> Security Class Initialized
DEBUG - 2018-01-31 10:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 10:03:21 --> Input Class Initialized
INFO - 2018-01-31 10:03:21 --> Language Class Initialized
INFO - 2018-01-31 10:03:21 --> Language Class Initialized
INFO - 2018-01-31 10:03:21 --> Config Class Initialized
INFO - 2018-01-31 10:03:21 --> Loader Class Initialized
INFO - 2018-01-31 15:33:21 --> Helper loaded: url_helper
INFO - 2018-01-31 15:33:21 --> Helper loaded: notification_helper
INFO - 2018-01-31 15:33:21 --> Helper loaded: settings_helper
INFO - 2018-01-31 15:33:21 --> Helper loaded: permission_helper
INFO - 2018-01-31 15:33:21 --> Helper loaded: users_helper
INFO - 2018-01-31 15:33:21 --> Database Driver Class Initialized
DEBUG - 2018-01-31 15:33:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 15:33:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 15:33:21 --> Helper loaded: form_helper
INFO - 2018-01-31 15:33:21 --> Form Validation Class Initialized
INFO - 2018-01-31 15:33:21 --> Controller Class Initialized
INFO - 2018-01-31 15:33:21 --> Model Class Initialized
INFO - 2018-01-31 15:33:21 --> Helper loaded: inflector_helper
INFO - 2018-01-31 15:33:21 --> Model Class Initialized
INFO - 2018-01-31 15:33:21 --> Model Class Initialized
INFO - 2018-01-31 15:33:21 --> Model Class Initialized
DEBUG - 2018-01-31 15:33:22 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-01-31 15:33:22 --> File loaded: /home/pr01004/public_html/application/views/users/user_details.php
DEBUG - 2018-01-31 15:33:22 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-01-31 15:33:22 --> Final output sent to browser
DEBUG - 2018-01-31 15:33:22 --> Total execution time: 0.0917
INFO - 2018-01-31 10:03:25 --> Config Class Initialized
INFO - 2018-01-31 10:03:25 --> Hooks Class Initialized
DEBUG - 2018-01-31 10:03:25 --> UTF-8 Support Enabled
INFO - 2018-01-31 10:03:25 --> Utf8 Class Initialized
INFO - 2018-01-31 10:03:25 --> URI Class Initialized
INFO - 2018-01-31 10:03:25 --> Router Class Initialized
INFO - 2018-01-31 10:03:25 --> Output Class Initialized
INFO - 2018-01-31 10:03:25 --> Security Class Initialized
DEBUG - 2018-01-31 10:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 10:03:25 --> Input Class Initialized
INFO - 2018-01-31 10:03:25 --> Language Class Initialized
INFO - 2018-01-31 10:03:25 --> Language Class Initialized
INFO - 2018-01-31 10:03:25 --> Config Class Initialized
INFO - 2018-01-31 10:03:25 --> Loader Class Initialized
INFO - 2018-01-31 15:33:25 --> Helper loaded: url_helper
INFO - 2018-01-31 15:33:25 --> Helper loaded: notification_helper
INFO - 2018-01-31 15:33:25 --> Helper loaded: settings_helper
INFO - 2018-01-31 15:33:25 --> Helper loaded: permission_helper
INFO - 2018-01-31 15:33:25 --> Helper loaded: users_helper
INFO - 2018-01-31 15:33:25 --> Database Driver Class Initialized
DEBUG - 2018-01-31 15:33:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 15:33:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 15:33:25 --> Helper loaded: form_helper
INFO - 2018-01-31 15:33:25 --> Form Validation Class Initialized
INFO - 2018-01-31 15:33:25 --> Controller Class Initialized
INFO - 2018-01-31 15:33:25 --> Model Class Initialized
INFO - 2018-01-31 15:33:25 --> Helper loaded: inflector_helper
INFO - 2018-01-31 15:33:25 --> Model Class Initialized
INFO - 2018-01-31 15:33:25 --> Model Class Initialized
INFO - 2018-01-31 10:03:25 --> Config Class Initialized
INFO - 2018-01-31 10:03:25 --> Hooks Class Initialized
DEBUG - 2018-01-31 10:03:25 --> UTF-8 Support Enabled
INFO - 2018-01-31 10:03:25 --> Utf8 Class Initialized
INFO - 2018-01-31 10:03:25 --> URI Class Initialized
INFO - 2018-01-31 10:03:25 --> Router Class Initialized
INFO - 2018-01-31 10:03:25 --> Output Class Initialized
INFO - 2018-01-31 10:03:25 --> Security Class Initialized
DEBUG - 2018-01-31 10:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 10:03:25 --> Input Class Initialized
INFO - 2018-01-31 10:03:25 --> Language Class Initialized
INFO - 2018-01-31 10:03:25 --> Language Class Initialized
INFO - 2018-01-31 10:03:25 --> Config Class Initialized
INFO - 2018-01-31 10:03:25 --> Loader Class Initialized
INFO - 2018-01-31 15:33:25 --> Helper loaded: url_helper
INFO - 2018-01-31 15:33:25 --> Helper loaded: notification_helper
INFO - 2018-01-31 15:33:25 --> Helper loaded: settings_helper
INFO - 2018-01-31 15:33:25 --> Helper loaded: permission_helper
INFO - 2018-01-31 15:33:25 --> Helper loaded: users_helper
INFO - 2018-01-31 15:33:25 --> Database Driver Class Initialized
DEBUG - 2018-01-31 15:33:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 15:33:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 15:33:25 --> Helper loaded: form_helper
INFO - 2018-01-31 15:33:25 --> Form Validation Class Initialized
INFO - 2018-01-31 15:33:25 --> Controller Class Initialized
INFO - 2018-01-31 15:33:25 --> Model Class Initialized
INFO - 2018-01-31 15:33:25 --> Helper loaded: inflector_helper
INFO - 2018-01-31 15:33:25 --> Model Class Initialized
INFO - 2018-01-31 15:33:25 --> Model Class Initialized
INFO - 2018-01-31 15:33:25 --> Model Class Initialized
DEBUG - 2018-01-31 15:33:25 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-01-31 15:33:25 --> File loaded: /home/pr01004/public_html/application/views/users/user_details.php
DEBUG - 2018-01-31 15:33:25 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-01-31 15:33:25 --> Final output sent to browser
DEBUG - 2018-01-31 15:33:25 --> Total execution time: 0.0992
INFO - 2018-01-31 10:03:32 --> Config Class Initialized
INFO - 2018-01-31 10:03:32 --> Hooks Class Initialized
DEBUG - 2018-01-31 10:03:32 --> UTF-8 Support Enabled
INFO - 2018-01-31 10:03:32 --> Utf8 Class Initialized
INFO - 2018-01-31 10:03:32 --> URI Class Initialized
INFO - 2018-01-31 10:03:32 --> Router Class Initialized
INFO - 2018-01-31 10:03:32 --> Output Class Initialized
INFO - 2018-01-31 10:03:32 --> Security Class Initialized
DEBUG - 2018-01-31 10:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 10:03:32 --> Input Class Initialized
INFO - 2018-01-31 10:03:32 --> Language Class Initialized
INFO - 2018-01-31 10:03:32 --> Language Class Initialized
INFO - 2018-01-31 10:03:32 --> Config Class Initialized
INFO - 2018-01-31 10:03:32 --> Loader Class Initialized
INFO - 2018-01-31 15:33:32 --> Helper loaded: url_helper
INFO - 2018-01-31 15:33:32 --> Helper loaded: notification_helper
INFO - 2018-01-31 15:33:32 --> Helper loaded: settings_helper
INFO - 2018-01-31 15:33:32 --> Helper loaded: permission_helper
INFO - 2018-01-31 15:33:32 --> Helper loaded: users_helper
INFO - 2018-01-31 15:33:32 --> Database Driver Class Initialized
DEBUG - 2018-01-31 15:33:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 15:33:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 15:33:32 --> Helper loaded: form_helper
INFO - 2018-01-31 15:33:32 --> Form Validation Class Initialized
INFO - 2018-01-31 15:33:32 --> Controller Class Initialized
INFO - 2018-01-31 15:33:32 --> Model Class Initialized
INFO - 2018-01-31 15:33:32 --> Helper loaded: inflector_helper
DEBUG - 2018-01-31 15:33:32 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-31 15:33:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-31 15:33:32 --> Model Class Initialized
INFO - 2018-01-31 15:33:32 --> Model Class Initialized
INFO - 2018-01-31 15:33:32 --> Model Class Initialized
INFO - 2018-01-31 15:33:32 --> Model Class Initialized
INFO - 2018-01-31 15:33:32 --> Model Class Initialized
INFO - 2018-01-31 15:33:32 --> Model Class Initialized
INFO - 2018-01-31 15:33:32 --> Model Class Initialized
INFO - 2018-01-31 15:33:32 --> Model Class Initialized
INFO - 2018-01-31 15:33:32 --> Model Class Initialized
INFO - 2018-01-31 15:33:32 --> Model Class Initialized
INFO - 2018-01-31 15:33:32 --> Model Class Initialized
INFO - 2018-01-31 15:33:32 --> Language file loaded: language/english/message_lang.php
INFO - 2018-01-31 15:33:32 --> Model Class Initialized
INFO - 2018-01-31 15:33:32 --> Final output sent to browser
DEBUG - 2018-01-31 15:33:32 --> Total execution time: 0.1179
INFO - 2018-01-31 10:03:40 --> Config Class Initialized
INFO - 2018-01-31 10:03:40 --> Hooks Class Initialized
DEBUG - 2018-01-31 10:03:40 --> UTF-8 Support Enabled
INFO - 2018-01-31 10:03:40 --> Utf8 Class Initialized
INFO - 2018-01-31 10:03:40 --> URI Class Initialized
INFO - 2018-01-31 10:03:40 --> Router Class Initialized
INFO - 2018-01-31 10:03:40 --> Output Class Initialized
INFO - 2018-01-31 10:03:40 --> Security Class Initialized
DEBUG - 2018-01-31 10:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 10:03:40 --> Input Class Initialized
INFO - 2018-01-31 10:03:40 --> Language Class Initialized
INFO - 2018-01-31 10:03:40 --> Language Class Initialized
INFO - 2018-01-31 10:03:40 --> Config Class Initialized
INFO - 2018-01-31 10:03:40 --> Loader Class Initialized
INFO - 2018-01-31 15:33:40 --> Helper loaded: url_helper
INFO - 2018-01-31 15:33:40 --> Helper loaded: notification_helper
INFO - 2018-01-31 15:33:40 --> Helper loaded: settings_helper
INFO - 2018-01-31 15:33:40 --> Helper loaded: permission_helper
INFO - 2018-01-31 15:33:40 --> Helper loaded: users_helper
INFO - 2018-01-31 15:33:40 --> Database Driver Class Initialized
DEBUG - 2018-01-31 15:33:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 15:33:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 15:33:40 --> Helper loaded: form_helper
INFO - 2018-01-31 15:33:40 --> Form Validation Class Initialized
INFO - 2018-01-31 15:33:40 --> Controller Class Initialized
INFO - 2018-01-31 15:33:40 --> Model Class Initialized
INFO - 2018-01-31 15:33:40 --> Helper loaded: inflector_helper
INFO - 2018-01-31 15:33:40 --> Model Class Initialized
INFO - 2018-01-31 15:33:40 --> Model Class Initialized
INFO - 2018-01-31 10:03:40 --> Config Class Initialized
INFO - 2018-01-31 10:03:40 --> Hooks Class Initialized
DEBUG - 2018-01-31 10:03:40 --> UTF-8 Support Enabled
INFO - 2018-01-31 10:03:40 --> Utf8 Class Initialized
INFO - 2018-01-31 10:03:40 --> URI Class Initialized
INFO - 2018-01-31 10:03:40 --> Router Class Initialized
INFO - 2018-01-31 10:03:40 --> Output Class Initialized
INFO - 2018-01-31 10:03:40 --> Security Class Initialized
DEBUG - 2018-01-31 10:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 10:03:40 --> Input Class Initialized
INFO - 2018-01-31 10:03:40 --> Language Class Initialized
INFO - 2018-01-31 10:03:40 --> Language Class Initialized
INFO - 2018-01-31 10:03:40 --> Config Class Initialized
INFO - 2018-01-31 10:03:40 --> Loader Class Initialized
INFO - 2018-01-31 15:33:41 --> Helper loaded: url_helper
INFO - 2018-01-31 15:33:41 --> Helper loaded: notification_helper
INFO - 2018-01-31 15:33:41 --> Helper loaded: settings_helper
INFO - 2018-01-31 15:33:41 --> Helper loaded: permission_helper
INFO - 2018-01-31 15:33:41 --> Helper loaded: users_helper
INFO - 2018-01-31 15:33:41 --> Database Driver Class Initialized
DEBUG - 2018-01-31 15:33:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 15:33:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 15:33:41 --> Helper loaded: form_helper
INFO - 2018-01-31 15:33:41 --> Form Validation Class Initialized
INFO - 2018-01-31 15:33:41 --> Controller Class Initialized
INFO - 2018-01-31 15:33:41 --> Model Class Initialized
INFO - 2018-01-31 15:33:41 --> Helper loaded: inflector_helper
INFO - 2018-01-31 15:33:41 --> Model Class Initialized
INFO - 2018-01-31 15:33:41 --> Model Class Initialized
INFO - 2018-01-31 15:33:41 --> Model Class Initialized
DEBUG - 2018-01-31 15:33:41 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-01-31 15:33:41 --> File loaded: /home/pr01004/public_html/application/views/users/user_details.php
DEBUG - 2018-01-31 15:33:41 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-01-31 15:33:41 --> Final output sent to browser
DEBUG - 2018-01-31 15:33:41 --> Total execution time: 0.1067
INFO - 2018-01-31 10:03:44 --> Config Class Initialized
INFO - 2018-01-31 10:03:44 --> Hooks Class Initialized
DEBUG - 2018-01-31 10:03:44 --> UTF-8 Support Enabled
INFO - 2018-01-31 10:03:44 --> Utf8 Class Initialized
INFO - 2018-01-31 10:03:44 --> URI Class Initialized
INFO - 2018-01-31 10:03:44 --> Router Class Initialized
INFO - 2018-01-31 10:03:44 --> Output Class Initialized
INFO - 2018-01-31 10:03:44 --> Security Class Initialized
DEBUG - 2018-01-31 10:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 10:03:44 --> Input Class Initialized
INFO - 2018-01-31 10:03:44 --> Language Class Initialized
INFO - 2018-01-31 10:03:44 --> Language Class Initialized
INFO - 2018-01-31 10:03:44 --> Config Class Initialized
INFO - 2018-01-31 10:03:44 --> Loader Class Initialized
INFO - 2018-01-31 15:33:44 --> Helper loaded: url_helper
INFO - 2018-01-31 15:33:44 --> Helper loaded: notification_helper
INFO - 2018-01-31 15:33:44 --> Helper loaded: settings_helper
INFO - 2018-01-31 15:33:44 --> Helper loaded: permission_helper
INFO - 2018-01-31 15:33:44 --> Helper loaded: users_helper
INFO - 2018-01-31 15:33:44 --> Database Driver Class Initialized
DEBUG - 2018-01-31 15:33:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 15:33:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 15:33:44 --> Helper loaded: form_helper
INFO - 2018-01-31 15:33:44 --> Form Validation Class Initialized
INFO - 2018-01-31 15:33:44 --> Controller Class Initialized
INFO - 2018-01-31 15:33:44 --> Model Class Initialized
INFO - 2018-01-31 15:33:44 --> Helper loaded: inflector_helper
DEBUG - 2018-01-31 15:33:44 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-31 15:33:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-31 15:33:44 --> Model Class Initialized
INFO - 2018-01-31 15:33:44 --> Model Class Initialized
INFO - 2018-01-31 15:33:44 --> Model Class Initialized
INFO - 2018-01-31 15:33:44 --> Model Class Initialized
INFO - 2018-01-31 15:33:44 --> Model Class Initialized
INFO - 2018-01-31 15:33:44 --> Model Class Initialized
INFO - 2018-01-31 15:33:44 --> Model Class Initialized
INFO - 2018-01-31 15:33:44 --> Model Class Initialized
INFO - 2018-01-31 15:33:44 --> Model Class Initialized
INFO - 2018-01-31 15:33:44 --> Model Class Initialized
INFO - 2018-01-31 15:33:44 --> Model Class Initialized
INFO - 2018-01-31 15:33:44 --> Language file loaded: language/english/message_lang.php
INFO - 2018-01-31 15:33:44 --> Model Class Initialized
INFO - 2018-01-31 15:33:44 --> Final output sent to browser
DEBUG - 2018-01-31 15:33:44 --> Total execution time: 0.1310
INFO - 2018-01-31 10:08:30 --> Config Class Initialized
INFO - 2018-01-31 10:08:30 --> Hooks Class Initialized
DEBUG - 2018-01-31 10:08:30 --> UTF-8 Support Enabled
INFO - 2018-01-31 10:08:30 --> Utf8 Class Initialized
INFO - 2018-01-31 10:08:30 --> URI Class Initialized
INFO - 2018-01-31 10:08:30 --> Router Class Initialized
INFO - 2018-01-31 10:08:30 --> Output Class Initialized
INFO - 2018-01-31 10:08:30 --> Security Class Initialized
DEBUG - 2018-01-31 10:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 10:08:30 --> Input Class Initialized
INFO - 2018-01-31 10:08:30 --> Language Class Initialized
INFO - 2018-01-31 10:08:30 --> Language Class Initialized
INFO - 2018-01-31 10:08:30 --> Config Class Initialized
INFO - 2018-01-31 10:08:30 --> Loader Class Initialized
INFO - 2018-01-31 15:38:30 --> Helper loaded: url_helper
INFO - 2018-01-31 15:38:30 --> Helper loaded: notification_helper
INFO - 2018-01-31 15:38:30 --> Helper loaded: settings_helper
INFO - 2018-01-31 15:38:30 --> Helper loaded: permission_helper
INFO - 2018-01-31 15:38:30 --> Helper loaded: users_helper
INFO - 2018-01-31 15:38:30 --> Database Driver Class Initialized
DEBUG - 2018-01-31 15:38:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 15:38:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 15:38:30 --> Helper loaded: form_helper
INFO - 2018-01-31 15:38:30 --> Form Validation Class Initialized
INFO - 2018-01-31 15:38:30 --> Controller Class Initialized
INFO - 2018-01-31 15:38:30 --> Model Class Initialized
INFO - 2018-01-31 15:38:30 --> Helper loaded: inflector_helper
DEBUG - 2018-01-31 15:38:30 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-31 15:38:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-31 15:38:30 --> Model Class Initialized
INFO - 2018-01-31 15:38:30 --> Model Class Initialized
INFO - 2018-01-31 15:38:30 --> Model Class Initialized
INFO - 2018-01-31 15:38:30 --> Model Class Initialized
INFO - 2018-01-31 15:38:30 --> Model Class Initialized
INFO - 2018-01-31 15:38:30 --> Model Class Initialized
INFO - 2018-01-31 15:38:30 --> Model Class Initialized
INFO - 2018-01-31 15:38:30 --> Model Class Initialized
INFO - 2018-01-31 15:38:30 --> Model Class Initialized
INFO - 2018-01-31 15:38:30 --> Model Class Initialized
INFO - 2018-01-31 15:38:30 --> Model Class Initialized
INFO - 2018-01-31 15:38:30 --> Language file loaded: language/english/message_lang.php
INFO - 2018-01-31 15:38:30 --> Model Class Initialized
INFO - 2018-01-31 15:38:30 --> Final output sent to browser
DEBUG - 2018-01-31 15:38:30 --> Total execution time: 0.1357
INFO - 2018-01-31 10:09:08 --> Config Class Initialized
INFO - 2018-01-31 10:09:08 --> Hooks Class Initialized
DEBUG - 2018-01-31 10:09:08 --> UTF-8 Support Enabled
INFO - 2018-01-31 10:09:08 --> Utf8 Class Initialized
INFO - 2018-01-31 10:09:08 --> URI Class Initialized
INFO - 2018-01-31 10:09:08 --> Router Class Initialized
INFO - 2018-01-31 10:09:08 --> Output Class Initialized
INFO - 2018-01-31 10:09:08 --> Security Class Initialized
DEBUG - 2018-01-31 10:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 10:09:08 --> Input Class Initialized
INFO - 2018-01-31 10:09:08 --> Language Class Initialized
INFO - 2018-01-31 10:09:08 --> Language Class Initialized
INFO - 2018-01-31 10:09:08 --> Config Class Initialized
INFO - 2018-01-31 10:09:08 --> Loader Class Initialized
INFO - 2018-01-31 15:39:08 --> Helper loaded: url_helper
INFO - 2018-01-31 15:39:08 --> Helper loaded: notification_helper
INFO - 2018-01-31 15:39:08 --> Helper loaded: settings_helper
INFO - 2018-01-31 15:39:08 --> Helper loaded: permission_helper
INFO - 2018-01-31 15:39:08 --> Helper loaded: users_helper
INFO - 2018-01-31 15:39:08 --> Database Driver Class Initialized
DEBUG - 2018-01-31 15:39:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 15:39:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 15:39:08 --> Helper loaded: form_helper
INFO - 2018-01-31 15:39:08 --> Form Validation Class Initialized
INFO - 2018-01-31 15:39:08 --> Controller Class Initialized
INFO - 2018-01-31 15:39:08 --> Model Class Initialized
INFO - 2018-01-31 15:39:08 --> Helper loaded: inflector_helper
DEBUG - 2018-01-31 15:39:08 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-31 15:39:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-31 15:39:08 --> Model Class Initialized
INFO - 2018-01-31 15:39:08 --> Model Class Initialized
INFO - 2018-01-31 15:39:08 --> Model Class Initialized
INFO - 2018-01-31 15:39:08 --> Model Class Initialized
INFO - 2018-01-31 15:39:08 --> Model Class Initialized
INFO - 2018-01-31 15:39:08 --> Model Class Initialized
INFO - 2018-01-31 15:39:08 --> Model Class Initialized
INFO - 2018-01-31 15:39:08 --> Model Class Initialized
INFO - 2018-01-31 15:39:08 --> Model Class Initialized
INFO - 2018-01-31 15:39:08 --> Model Class Initialized
INFO - 2018-01-31 15:39:08 --> Model Class Initialized
INFO - 2018-01-31 15:39:08 --> Language file loaded: language/english/message_lang.php
INFO - 2018-01-31 15:39:08 --> Final output sent to browser
DEBUG - 2018-01-31 15:39:08 --> Total execution time: 0.1370
INFO - 2018-01-31 10:20:42 --> Config Class Initialized
INFO - 2018-01-31 10:20:42 --> Hooks Class Initialized
DEBUG - 2018-01-31 10:20:42 --> UTF-8 Support Enabled
INFO - 2018-01-31 10:20:42 --> Utf8 Class Initialized
INFO - 2018-01-31 10:20:42 --> URI Class Initialized
INFO - 2018-01-31 10:20:42 --> Router Class Initialized
INFO - 2018-01-31 10:20:42 --> Output Class Initialized
INFO - 2018-01-31 10:20:42 --> Security Class Initialized
DEBUG - 2018-01-31 10:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 10:20:42 --> Input Class Initialized
INFO - 2018-01-31 10:20:42 --> Language Class Initialized
INFO - 2018-01-31 10:20:43 --> Language Class Initialized
INFO - 2018-01-31 10:20:43 --> Config Class Initialized
INFO - 2018-01-31 10:20:43 --> Loader Class Initialized
INFO - 2018-01-31 15:50:43 --> Helper loaded: url_helper
INFO - 2018-01-31 15:50:43 --> Helper loaded: notification_helper
INFO - 2018-01-31 15:50:43 --> Helper loaded: settings_helper
INFO - 2018-01-31 15:50:43 --> Helper loaded: permission_helper
INFO - 2018-01-31 15:50:43 --> Helper loaded: users_helper
INFO - 2018-01-31 15:50:43 --> Database Driver Class Initialized
DEBUG - 2018-01-31 15:50:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 15:50:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 15:50:43 --> Helper loaded: form_helper
INFO - 2018-01-31 15:50:43 --> Form Validation Class Initialized
INFO - 2018-01-31 15:50:43 --> Controller Class Initialized
INFO - 2018-01-31 15:50:43 --> Model Class Initialized
INFO - 2018-01-31 15:50:43 --> Helper loaded: inflector_helper
DEBUG - 2018-01-31 15:50:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-31 15:50:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-31 15:50:43 --> Model Class Initialized
INFO - 2018-01-31 15:50:43 --> Model Class Initialized
INFO - 2018-01-31 15:50:43 --> Model Class Initialized
INFO - 2018-01-31 15:50:43 --> Model Class Initialized
INFO - 2018-01-31 15:50:43 --> Model Class Initialized
INFO - 2018-01-31 15:50:43 --> Model Class Initialized
INFO - 2018-01-31 15:50:43 --> Model Class Initialized
INFO - 2018-01-31 15:50:43 --> Model Class Initialized
INFO - 2018-01-31 15:50:43 --> Model Class Initialized
INFO - 2018-01-31 15:50:43 --> Model Class Initialized
INFO - 2018-01-31 15:50:43 --> Model Class Initialized
INFO - 2018-01-31 15:50:43 --> Language file loaded: language/english/message_lang.php
INFO - 2018-01-31 15:50:43 --> Final output sent to browser
DEBUG - 2018-01-31 15:50:43 --> Total execution time: 0.0930
INFO - 2018-01-31 10:20:58 --> Config Class Initialized
INFO - 2018-01-31 10:20:58 --> Hooks Class Initialized
DEBUG - 2018-01-31 10:20:58 --> UTF-8 Support Enabled
INFO - 2018-01-31 10:20:58 --> Utf8 Class Initialized
INFO - 2018-01-31 10:20:58 --> URI Class Initialized
INFO - 2018-01-31 10:20:58 --> Router Class Initialized
INFO - 2018-01-31 10:20:58 --> Output Class Initialized
INFO - 2018-01-31 10:20:58 --> Security Class Initialized
DEBUG - 2018-01-31 10:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 10:20:58 --> Input Class Initialized
INFO - 2018-01-31 10:20:58 --> Language Class Initialized
INFO - 2018-01-31 10:20:58 --> Language Class Initialized
INFO - 2018-01-31 10:20:58 --> Config Class Initialized
INFO - 2018-01-31 10:20:58 --> Loader Class Initialized
INFO - 2018-01-31 15:50:58 --> Helper loaded: url_helper
INFO - 2018-01-31 15:50:58 --> Helper loaded: notification_helper
INFO - 2018-01-31 15:50:58 --> Helper loaded: settings_helper
INFO - 2018-01-31 15:50:58 --> Helper loaded: permission_helper
INFO - 2018-01-31 15:50:58 --> Helper loaded: users_helper
INFO - 2018-01-31 15:50:58 --> Database Driver Class Initialized
DEBUG - 2018-01-31 15:50:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 15:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 15:50:58 --> Helper loaded: form_helper
INFO - 2018-01-31 15:50:58 --> Form Validation Class Initialized
INFO - 2018-01-31 15:50:58 --> Controller Class Initialized
INFO - 2018-01-31 15:50:58 --> Model Class Initialized
INFO - 2018-01-31 15:50:58 --> Helper loaded: inflector_helper
DEBUG - 2018-01-31 15:50:58 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-31 15:50:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-31 15:50:58 --> Model Class Initialized
INFO - 2018-01-31 15:50:58 --> Model Class Initialized
INFO - 2018-01-31 15:50:58 --> Model Class Initialized
INFO - 2018-01-31 15:50:58 --> Model Class Initialized
INFO - 2018-01-31 15:50:58 --> Model Class Initialized
INFO - 2018-01-31 15:50:58 --> Model Class Initialized
INFO - 2018-01-31 15:50:58 --> Model Class Initialized
INFO - 2018-01-31 15:50:58 --> Model Class Initialized
INFO - 2018-01-31 15:50:58 --> Model Class Initialized
INFO - 2018-01-31 15:50:58 --> Model Class Initialized
INFO - 2018-01-31 15:50:58 --> Model Class Initialized
INFO - 2018-01-31 15:50:58 --> Language file loaded: language/english/message_lang.php
INFO - 2018-01-31 15:50:58 --> Final output sent to browser
DEBUG - 2018-01-31 15:50:58 --> Total execution time: 0.0845
INFO - 2018-01-31 10:22:51 --> Config Class Initialized
INFO - 2018-01-31 10:22:51 --> Hooks Class Initialized
DEBUG - 2018-01-31 10:22:51 --> UTF-8 Support Enabled
INFO - 2018-01-31 10:22:51 --> Utf8 Class Initialized
INFO - 2018-01-31 10:22:51 --> URI Class Initialized
INFO - 2018-01-31 10:22:51 --> Router Class Initialized
INFO - 2018-01-31 10:22:51 --> Output Class Initialized
INFO - 2018-01-31 10:22:51 --> Security Class Initialized
DEBUG - 2018-01-31 10:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 10:22:51 --> Input Class Initialized
INFO - 2018-01-31 10:22:51 --> Language Class Initialized
INFO - 2018-01-31 10:22:51 --> Language Class Initialized
INFO - 2018-01-31 10:22:51 --> Config Class Initialized
INFO - 2018-01-31 10:22:51 --> Loader Class Initialized
INFO - 2018-01-31 15:52:51 --> Helper loaded: url_helper
INFO - 2018-01-31 15:52:51 --> Helper loaded: notification_helper
INFO - 2018-01-31 15:52:51 --> Helper loaded: settings_helper
INFO - 2018-01-31 15:52:51 --> Helper loaded: permission_helper
INFO - 2018-01-31 15:52:51 --> Helper loaded: users_helper
INFO - 2018-01-31 15:52:51 --> Database Driver Class Initialized
DEBUG - 2018-01-31 15:52:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 15:52:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 15:52:51 --> Helper loaded: form_helper
INFO - 2018-01-31 15:52:51 --> Form Validation Class Initialized
INFO - 2018-01-31 15:52:51 --> Controller Class Initialized
INFO - 2018-01-31 15:52:51 --> Model Class Initialized
INFO - 2018-01-31 15:52:51 --> Helper loaded: inflector_helper
INFO - 2018-01-31 15:52:51 --> Model Class Initialized
INFO - 2018-01-31 15:52:51 --> Model Class Initialized
DEBUG - 2018-01-31 15:52:51 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-01-31 15:52:51 --> File loaded: /home/pr01004/public_html/application/views/users/usersList.php
DEBUG - 2018-01-31 15:52:51 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-01-31 15:52:51 --> Final output sent to browser
DEBUG - 2018-01-31 15:52:51 --> Total execution time: 0.0981
INFO - 2018-01-31 10:22:52 --> Config Class Initialized
INFO - 2018-01-31 10:22:52 --> Hooks Class Initialized
DEBUG - 2018-01-31 10:22:52 --> UTF-8 Support Enabled
INFO - 2018-01-31 10:22:52 --> Utf8 Class Initialized
INFO - 2018-01-31 10:22:52 --> URI Class Initialized
INFO - 2018-01-31 10:22:52 --> Router Class Initialized
INFO - 2018-01-31 10:22:52 --> Output Class Initialized
INFO - 2018-01-31 10:22:52 --> Security Class Initialized
DEBUG - 2018-01-31 10:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 10:22:52 --> Input Class Initialized
INFO - 2018-01-31 10:22:52 --> Language Class Initialized
INFO - 2018-01-31 10:22:52 --> Language Class Initialized
INFO - 2018-01-31 10:22:52 --> Config Class Initialized
INFO - 2018-01-31 10:22:52 --> Loader Class Initialized
INFO - 2018-01-31 15:52:52 --> Helper loaded: url_helper
INFO - 2018-01-31 15:52:52 --> Helper loaded: notification_helper
INFO - 2018-01-31 15:52:52 --> Helper loaded: settings_helper
INFO - 2018-01-31 15:52:52 --> Helper loaded: permission_helper
INFO - 2018-01-31 15:52:52 --> Helper loaded: users_helper
INFO - 2018-01-31 15:52:52 --> Database Driver Class Initialized
DEBUG - 2018-01-31 15:52:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 15:52:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 15:52:52 --> Helper loaded: form_helper
INFO - 2018-01-31 15:52:52 --> Form Validation Class Initialized
INFO - 2018-01-31 15:52:52 --> Controller Class Initialized
INFO - 2018-01-31 15:52:52 --> Model Class Initialized
INFO - 2018-01-31 15:52:52 --> Helper loaded: inflector_helper
INFO - 2018-01-31 15:52:52 --> Model Class Initialized
INFO - 2018-01-31 15:52:52 --> Model Class Initialized
INFO - 2018-01-31 15:52:52 --> Model Class Initialized
INFO - 2018-01-31 15:52:52 --> Final output sent to browser
DEBUG - 2018-01-31 15:52:52 --> Total execution time: 0.0864
INFO - 2018-01-31 10:23:33 --> Config Class Initialized
INFO - 2018-01-31 10:23:33 --> Hooks Class Initialized
DEBUG - 2018-01-31 10:23:33 --> UTF-8 Support Enabled
INFO - 2018-01-31 10:23:33 --> Utf8 Class Initialized
INFO - 2018-01-31 10:23:33 --> URI Class Initialized
INFO - 2018-01-31 10:23:33 --> Router Class Initialized
INFO - 2018-01-31 10:23:33 --> Output Class Initialized
INFO - 2018-01-31 10:23:33 --> Security Class Initialized
DEBUG - 2018-01-31 10:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 10:23:33 --> Input Class Initialized
INFO - 2018-01-31 10:23:33 --> Language Class Initialized
INFO - 2018-01-31 10:23:33 --> Language Class Initialized
INFO - 2018-01-31 10:23:33 --> Config Class Initialized
INFO - 2018-01-31 10:23:33 --> Loader Class Initialized
INFO - 2018-01-31 15:53:33 --> Helper loaded: url_helper
INFO - 2018-01-31 15:53:33 --> Helper loaded: notification_helper
INFO - 2018-01-31 15:53:33 --> Helper loaded: settings_helper
INFO - 2018-01-31 15:53:33 --> Helper loaded: permission_helper
INFO - 2018-01-31 15:53:33 --> Helper loaded: users_helper
INFO - 2018-01-31 15:53:33 --> Database Driver Class Initialized
DEBUG - 2018-01-31 15:53:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 15:53:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 15:53:33 --> Helper loaded: form_helper
INFO - 2018-01-31 15:53:33 --> Form Validation Class Initialized
INFO - 2018-01-31 15:53:33 --> Controller Class Initialized
INFO - 2018-01-31 15:53:33 --> Model Class Initialized
INFO - 2018-01-31 15:53:33 --> Helper loaded: inflector_helper
DEBUG - 2018-01-31 15:53:33 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-31 15:53:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-31 15:53:33 --> Model Class Initialized
INFO - 2018-01-31 15:53:33 --> Model Class Initialized
INFO - 2018-01-31 15:53:33 --> Model Class Initialized
INFO - 2018-01-31 15:53:33 --> Model Class Initialized
INFO - 2018-01-31 15:53:33 --> Model Class Initialized
INFO - 2018-01-31 15:53:33 --> Model Class Initialized
INFO - 2018-01-31 15:53:33 --> Model Class Initialized
INFO - 2018-01-31 15:53:33 --> Model Class Initialized
INFO - 2018-01-31 15:53:33 --> Model Class Initialized
INFO - 2018-01-31 15:53:33 --> Model Class Initialized
INFO - 2018-01-31 15:53:33 --> Model Class Initialized
INFO - 2018-01-31 15:53:33 --> Language file loaded: language/english/message_lang.php
INFO - 2018-01-31 15:53:33 --> Final output sent to browser
DEBUG - 2018-01-31 15:53:33 --> Total execution time: 0.1519
INFO - 2018-01-31 10:23:54 --> Config Class Initialized
INFO - 2018-01-31 10:23:54 --> Hooks Class Initialized
DEBUG - 2018-01-31 10:23:54 --> UTF-8 Support Enabled
INFO - 2018-01-31 10:23:54 --> Utf8 Class Initialized
INFO - 2018-01-31 10:23:54 --> URI Class Initialized
INFO - 2018-01-31 10:23:54 --> Router Class Initialized
INFO - 2018-01-31 10:23:54 --> Output Class Initialized
INFO - 2018-01-31 10:23:54 --> Security Class Initialized
DEBUG - 2018-01-31 10:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 10:23:54 --> Input Class Initialized
INFO - 2018-01-31 10:23:54 --> Language Class Initialized
INFO - 2018-01-31 10:23:54 --> Language Class Initialized
INFO - 2018-01-31 10:23:54 --> Config Class Initialized
INFO - 2018-01-31 10:23:54 --> Loader Class Initialized
INFO - 2018-01-31 15:53:54 --> Helper loaded: url_helper
INFO - 2018-01-31 15:53:54 --> Helper loaded: notification_helper
INFO - 2018-01-31 15:53:54 --> Helper loaded: settings_helper
INFO - 2018-01-31 15:53:54 --> Helper loaded: permission_helper
INFO - 2018-01-31 15:53:54 --> Helper loaded: users_helper
INFO - 2018-01-31 15:53:54 --> Database Driver Class Initialized
DEBUG - 2018-01-31 15:53:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 15:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 15:53:54 --> Helper loaded: form_helper
INFO - 2018-01-31 15:53:54 --> Form Validation Class Initialized
INFO - 2018-01-31 15:53:54 --> Controller Class Initialized
INFO - 2018-01-31 15:53:54 --> Model Class Initialized
INFO - 2018-01-31 15:53:54 --> Helper loaded: inflector_helper
DEBUG - 2018-01-31 15:53:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-31 15:53:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-31 15:53:54 --> Model Class Initialized
INFO - 2018-01-31 15:53:54 --> Model Class Initialized
INFO - 2018-01-31 15:53:54 --> Model Class Initialized
INFO - 2018-01-31 15:53:54 --> Model Class Initialized
INFO - 2018-01-31 15:53:54 --> Model Class Initialized
INFO - 2018-01-31 15:53:54 --> Model Class Initialized
INFO - 2018-01-31 15:53:54 --> Model Class Initialized
INFO - 2018-01-31 15:53:54 --> Model Class Initialized
INFO - 2018-01-31 15:53:54 --> Model Class Initialized
INFO - 2018-01-31 15:53:54 --> Model Class Initialized
INFO - 2018-01-31 15:53:54 --> Model Class Initialized
INFO - 2018-01-31 15:53:54 --> Language file loaded: language/english/message_lang.php
INFO - 2018-01-31 15:53:54 --> Final output sent to browser
DEBUG - 2018-01-31 15:53:54 --> Total execution time: 0.1355
INFO - 2018-01-31 10:26:24 --> Config Class Initialized
INFO - 2018-01-31 10:26:24 --> Hooks Class Initialized
DEBUG - 2018-01-31 10:26:24 --> UTF-8 Support Enabled
INFO - 2018-01-31 10:26:24 --> Utf8 Class Initialized
INFO - 2018-01-31 10:26:24 --> URI Class Initialized
INFO - 2018-01-31 10:26:24 --> Router Class Initialized
INFO - 2018-01-31 10:26:24 --> Output Class Initialized
INFO - 2018-01-31 10:26:24 --> Security Class Initialized
DEBUG - 2018-01-31 10:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 10:26:24 --> Input Class Initialized
INFO - 2018-01-31 10:26:24 --> Language Class Initialized
INFO - 2018-01-31 10:26:24 --> Language Class Initialized
INFO - 2018-01-31 10:26:24 --> Config Class Initialized
INFO - 2018-01-31 10:26:24 --> Loader Class Initialized
INFO - 2018-01-31 15:56:24 --> Helper loaded: url_helper
INFO - 2018-01-31 15:56:24 --> Helper loaded: notification_helper
INFO - 2018-01-31 15:56:24 --> Helper loaded: settings_helper
INFO - 2018-01-31 15:56:24 --> Helper loaded: permission_helper
INFO - 2018-01-31 15:56:24 --> Helper loaded: users_helper
INFO - 2018-01-31 15:56:24 --> Database Driver Class Initialized
DEBUG - 2018-01-31 15:56:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 15:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 15:56:24 --> Helper loaded: form_helper
INFO - 2018-01-31 15:56:24 --> Form Validation Class Initialized
INFO - 2018-01-31 15:56:24 --> Controller Class Initialized
INFO - 2018-01-31 15:56:24 --> Model Class Initialized
INFO - 2018-01-31 15:56:24 --> Helper loaded: inflector_helper
DEBUG - 2018-01-31 15:56:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-31 15:56:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-31 15:56:24 --> Model Class Initialized
INFO - 2018-01-31 15:56:24 --> Model Class Initialized
INFO - 2018-01-31 15:56:24 --> Model Class Initialized
INFO - 2018-01-31 15:56:24 --> Model Class Initialized
INFO - 2018-01-31 15:56:24 --> Model Class Initialized
INFO - 2018-01-31 15:56:24 --> Model Class Initialized
INFO - 2018-01-31 15:56:24 --> Model Class Initialized
INFO - 2018-01-31 15:56:24 --> Model Class Initialized
INFO - 2018-01-31 15:56:24 --> Model Class Initialized
INFO - 2018-01-31 15:56:24 --> Model Class Initialized
INFO - 2018-01-31 15:56:24 --> Model Class Initialized
INFO - 2018-01-31 15:56:24 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-01-31 15:56:24 --> Severity: error --> Exception: [] operator not supported for strings /home/pr01004/public_html/application/controllers/api/Filter.php 409
INFO - 2018-01-31 10:27:47 --> Config Class Initialized
INFO - 2018-01-31 10:27:47 --> Hooks Class Initialized
DEBUG - 2018-01-31 10:27:47 --> UTF-8 Support Enabled
INFO - 2018-01-31 10:27:47 --> Utf8 Class Initialized
INFO - 2018-01-31 10:27:47 --> URI Class Initialized
INFO - 2018-01-31 10:27:47 --> Router Class Initialized
INFO - 2018-01-31 10:27:47 --> Output Class Initialized
INFO - 2018-01-31 10:27:47 --> Security Class Initialized
DEBUG - 2018-01-31 10:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 10:27:47 --> Input Class Initialized
INFO - 2018-01-31 10:27:47 --> Language Class Initialized
INFO - 2018-01-31 10:27:47 --> Language Class Initialized
INFO - 2018-01-31 10:27:47 --> Config Class Initialized
INFO - 2018-01-31 10:27:47 --> Loader Class Initialized
INFO - 2018-01-31 15:57:47 --> Helper loaded: url_helper
INFO - 2018-01-31 15:57:47 --> Helper loaded: notification_helper
INFO - 2018-01-31 15:57:47 --> Helper loaded: settings_helper
INFO - 2018-01-31 15:57:47 --> Helper loaded: permission_helper
INFO - 2018-01-31 15:57:47 --> Helper loaded: users_helper
INFO - 2018-01-31 15:57:47 --> Database Driver Class Initialized
DEBUG - 2018-01-31 15:57:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 15:57:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 15:57:47 --> Helper loaded: form_helper
INFO - 2018-01-31 15:57:47 --> Form Validation Class Initialized
INFO - 2018-01-31 15:57:47 --> Controller Class Initialized
INFO - 2018-01-31 15:57:47 --> Model Class Initialized
INFO - 2018-01-31 15:57:47 --> Helper loaded: inflector_helper
DEBUG - 2018-01-31 15:57:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-31 15:57:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-31 15:57:47 --> Model Class Initialized
INFO - 2018-01-31 15:57:47 --> Model Class Initialized
INFO - 2018-01-31 15:57:47 --> Model Class Initialized
INFO - 2018-01-31 15:57:47 --> Model Class Initialized
INFO - 2018-01-31 15:57:47 --> Model Class Initialized
INFO - 2018-01-31 15:57:47 --> Model Class Initialized
INFO - 2018-01-31 15:57:47 --> Model Class Initialized
INFO - 2018-01-31 15:57:47 --> Model Class Initialized
INFO - 2018-01-31 15:57:47 --> Model Class Initialized
INFO - 2018-01-31 15:57:47 --> Model Class Initialized
INFO - 2018-01-31 15:57:47 --> Model Class Initialized
INFO - 2018-01-31 15:57:47 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-01-31 15:57:47 --> Severity: error --> Exception: [] operator not supported for strings /home/pr01004/public_html/application/controllers/api/Filter.php 409
INFO - 2018-01-31 10:28:10 --> Config Class Initialized
INFO - 2018-01-31 10:28:10 --> Hooks Class Initialized
DEBUG - 2018-01-31 10:28:10 --> UTF-8 Support Enabled
INFO - 2018-01-31 10:28:10 --> Utf8 Class Initialized
INFO - 2018-01-31 10:28:10 --> URI Class Initialized
INFO - 2018-01-31 10:28:10 --> Router Class Initialized
INFO - 2018-01-31 10:28:10 --> Output Class Initialized
INFO - 2018-01-31 10:28:10 --> Security Class Initialized
DEBUG - 2018-01-31 10:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 10:28:10 --> Input Class Initialized
INFO - 2018-01-31 10:28:10 --> Language Class Initialized
INFO - 2018-01-31 10:28:11 --> Language Class Initialized
INFO - 2018-01-31 10:28:11 --> Config Class Initialized
INFO - 2018-01-31 10:28:11 --> Loader Class Initialized
INFO - 2018-01-31 15:58:11 --> Helper loaded: url_helper
INFO - 2018-01-31 15:58:11 --> Helper loaded: notification_helper
INFO - 2018-01-31 15:58:11 --> Helper loaded: settings_helper
INFO - 2018-01-31 15:58:11 --> Helper loaded: permission_helper
INFO - 2018-01-31 15:58:11 --> Helper loaded: users_helper
INFO - 2018-01-31 15:58:11 --> Database Driver Class Initialized
DEBUG - 2018-01-31 15:58:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 15:58:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 15:58:11 --> Helper loaded: form_helper
INFO - 2018-01-31 15:58:11 --> Form Validation Class Initialized
INFO - 2018-01-31 15:58:11 --> Controller Class Initialized
INFO - 2018-01-31 15:58:11 --> Model Class Initialized
INFO - 2018-01-31 15:58:11 --> Helper loaded: inflector_helper
DEBUG - 2018-01-31 15:58:11 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-31 15:58:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-31 15:58:11 --> Model Class Initialized
INFO - 2018-01-31 15:58:11 --> Model Class Initialized
INFO - 2018-01-31 15:58:11 --> Model Class Initialized
INFO - 2018-01-31 15:58:11 --> Model Class Initialized
INFO - 2018-01-31 15:58:11 --> Model Class Initialized
INFO - 2018-01-31 15:58:11 --> Model Class Initialized
INFO - 2018-01-31 15:58:11 --> Model Class Initialized
INFO - 2018-01-31 15:58:11 --> Model Class Initialized
INFO - 2018-01-31 15:58:11 --> Model Class Initialized
INFO - 2018-01-31 15:58:11 --> Model Class Initialized
INFO - 2018-01-31 15:58:11 --> Model Class Initialized
INFO - 2018-01-31 15:58:11 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-01-31 15:58:11 --> Severity: Notice --> Undefined property: stdClass::$users_dob /home/pr01004/public_html/application/helpers/users_helper.php 120
ERROR - 2018-01-31 15:58:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/pr01004/public_html/system/core/Exceptions.php:271) /home/pr01004/public_html/system/core/Common.php 564
INFO - 2018-01-31 15:58:11 --> Final output sent to browser
DEBUG - 2018-01-31 15:58:11 --> Total execution time: 0.1316
INFO - 2018-01-31 10:29:41 --> Config Class Initialized
INFO - 2018-01-31 10:29:41 --> Hooks Class Initialized
DEBUG - 2018-01-31 10:29:41 --> UTF-8 Support Enabled
INFO - 2018-01-31 10:29:41 --> Utf8 Class Initialized
INFO - 2018-01-31 10:29:41 --> URI Class Initialized
INFO - 2018-01-31 10:29:41 --> Router Class Initialized
INFO - 2018-01-31 10:29:41 --> Output Class Initialized
INFO - 2018-01-31 10:29:41 --> Security Class Initialized
DEBUG - 2018-01-31 10:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 10:29:41 --> Input Class Initialized
INFO - 2018-01-31 10:29:41 --> Language Class Initialized
INFO - 2018-01-31 10:29:41 --> Language Class Initialized
INFO - 2018-01-31 10:29:41 --> Config Class Initialized
INFO - 2018-01-31 10:29:41 --> Loader Class Initialized
INFO - 2018-01-31 15:59:41 --> Helper loaded: url_helper
INFO - 2018-01-31 15:59:41 --> Helper loaded: notification_helper
INFO - 2018-01-31 15:59:41 --> Helper loaded: settings_helper
INFO - 2018-01-31 15:59:41 --> Helper loaded: permission_helper
INFO - 2018-01-31 15:59:41 --> Helper loaded: users_helper
INFO - 2018-01-31 15:59:42 --> Database Driver Class Initialized
DEBUG - 2018-01-31 15:59:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 15:59:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 15:59:42 --> Helper loaded: form_helper
INFO - 2018-01-31 15:59:42 --> Form Validation Class Initialized
INFO - 2018-01-31 15:59:42 --> Controller Class Initialized
INFO - 2018-01-31 15:59:42 --> Model Class Initialized
INFO - 2018-01-31 15:59:42 --> Helper loaded: inflector_helper
DEBUG - 2018-01-31 15:59:42 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-31 15:59:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-31 15:59:42 --> Model Class Initialized
INFO - 2018-01-31 15:59:42 --> Model Class Initialized
INFO - 2018-01-31 15:59:42 --> Model Class Initialized
INFO - 2018-01-31 15:59:42 --> Model Class Initialized
INFO - 2018-01-31 15:59:42 --> Model Class Initialized
INFO - 2018-01-31 15:59:42 --> Model Class Initialized
INFO - 2018-01-31 15:59:42 --> Model Class Initialized
INFO - 2018-01-31 15:59:42 --> Model Class Initialized
INFO - 2018-01-31 15:59:42 --> Model Class Initialized
INFO - 2018-01-31 15:59:42 --> Model Class Initialized
INFO - 2018-01-31 15:59:42 --> Model Class Initialized
INFO - 2018-01-31 15:59:42 --> Language file loaded: language/english/message_lang.php
INFO - 2018-01-31 15:59:42 --> Final output sent to browser
DEBUG - 2018-01-31 15:59:42 --> Total execution time: 0.1285
INFO - 2018-01-31 10:30:54 --> Config Class Initialized
INFO - 2018-01-31 10:30:54 --> Hooks Class Initialized
DEBUG - 2018-01-31 10:30:54 --> UTF-8 Support Enabled
INFO - 2018-01-31 10:30:54 --> Utf8 Class Initialized
INFO - 2018-01-31 10:30:54 --> URI Class Initialized
INFO - 2018-01-31 10:30:54 --> Router Class Initialized
INFO - 2018-01-31 10:30:54 --> Output Class Initialized
INFO - 2018-01-31 10:30:54 --> Security Class Initialized
DEBUG - 2018-01-31 10:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 10:30:54 --> Input Class Initialized
INFO - 2018-01-31 10:30:54 --> Language Class Initialized
INFO - 2018-01-31 10:30:54 --> Language Class Initialized
INFO - 2018-01-31 10:30:54 --> Config Class Initialized
INFO - 2018-01-31 10:30:54 --> Loader Class Initialized
INFO - 2018-01-31 16:00:54 --> Helper loaded: url_helper
INFO - 2018-01-31 16:00:54 --> Helper loaded: notification_helper
INFO - 2018-01-31 16:00:54 --> Helper loaded: settings_helper
INFO - 2018-01-31 16:00:54 --> Helper loaded: permission_helper
INFO - 2018-01-31 16:00:54 --> Helper loaded: users_helper
INFO - 2018-01-31 16:00:54 --> Database Driver Class Initialized
DEBUG - 2018-01-31 16:00:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 16:00:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 16:00:54 --> Helper loaded: form_helper
INFO - 2018-01-31 16:00:54 --> Form Validation Class Initialized
INFO - 2018-01-31 16:00:54 --> Controller Class Initialized
INFO - 2018-01-31 16:00:54 --> Model Class Initialized
INFO - 2018-01-31 16:00:54 --> Helper loaded: inflector_helper
DEBUG - 2018-01-31 16:00:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-31 16:00:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-31 16:00:54 --> Model Class Initialized
INFO - 2018-01-31 16:00:54 --> Model Class Initialized
INFO - 2018-01-31 16:00:54 --> Model Class Initialized
INFO - 2018-01-31 16:00:54 --> Model Class Initialized
INFO - 2018-01-31 16:00:54 --> Model Class Initialized
INFO - 2018-01-31 16:00:54 --> Model Class Initialized
INFO - 2018-01-31 16:00:54 --> Model Class Initialized
INFO - 2018-01-31 16:00:54 --> Model Class Initialized
INFO - 2018-01-31 16:00:54 --> Model Class Initialized
INFO - 2018-01-31 16:00:54 --> Model Class Initialized
INFO - 2018-01-31 16:00:54 --> Model Class Initialized
INFO - 2018-01-31 16:00:54 --> Language file loaded: language/english/message_lang.php
INFO - 2018-01-31 16:00:54 --> Final output sent to browser
DEBUG - 2018-01-31 16:00:54 --> Total execution time: 0.1288
INFO - 2018-01-31 10:34:22 --> Config Class Initialized
INFO - 2018-01-31 10:34:22 --> Hooks Class Initialized
DEBUG - 2018-01-31 10:34:22 --> UTF-8 Support Enabled
INFO - 2018-01-31 10:34:22 --> Utf8 Class Initialized
INFO - 2018-01-31 10:34:22 --> URI Class Initialized
INFO - 2018-01-31 10:34:22 --> Router Class Initialized
INFO - 2018-01-31 10:34:22 --> Output Class Initialized
INFO - 2018-01-31 10:34:22 --> Security Class Initialized
DEBUG - 2018-01-31 10:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 10:34:22 --> Input Class Initialized
INFO - 2018-01-31 10:34:22 --> Language Class Initialized
INFO - 2018-01-31 10:34:22 --> Language Class Initialized
INFO - 2018-01-31 10:34:22 --> Config Class Initialized
INFO - 2018-01-31 10:34:22 --> Loader Class Initialized
INFO - 2018-01-31 16:04:22 --> Helper loaded: url_helper
INFO - 2018-01-31 16:04:22 --> Helper loaded: notification_helper
INFO - 2018-01-31 16:04:22 --> Helper loaded: settings_helper
INFO - 2018-01-31 16:04:22 --> Helper loaded: permission_helper
INFO - 2018-01-31 16:04:22 --> Helper loaded: users_helper
INFO - 2018-01-31 16:04:22 --> Database Driver Class Initialized
DEBUG - 2018-01-31 16:04:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 16:04:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 16:04:22 --> Helper loaded: form_helper
INFO - 2018-01-31 16:04:22 --> Form Validation Class Initialized
INFO - 2018-01-31 16:04:22 --> Controller Class Initialized
INFO - 2018-01-31 16:04:22 --> Model Class Initialized
INFO - 2018-01-31 16:04:22 --> Helper loaded: inflector_helper
DEBUG - 2018-01-31 16:04:22 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-31 16:04:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-31 16:04:22 --> Model Class Initialized
INFO - 2018-01-31 16:04:22 --> Model Class Initialized
INFO - 2018-01-31 16:04:22 --> Model Class Initialized
INFO - 2018-01-31 16:04:22 --> Model Class Initialized
INFO - 2018-01-31 16:04:22 --> Model Class Initialized
INFO - 2018-01-31 16:04:22 --> Model Class Initialized
INFO - 2018-01-31 16:04:22 --> Model Class Initialized
INFO - 2018-01-31 16:04:22 --> Model Class Initialized
INFO - 2018-01-31 16:04:22 --> Model Class Initialized
INFO - 2018-01-31 16:04:22 --> Model Class Initialized
INFO - 2018-01-31 16:04:22 --> Model Class Initialized
INFO - 2018-01-31 16:04:22 --> Language file loaded: language/english/message_lang.php
INFO - 2018-01-31 16:04:22 --> Final output sent to browser
DEBUG - 2018-01-31 16:04:22 --> Total execution time: 0.1388
INFO - 2018-01-31 10:38:46 --> Config Class Initialized
INFO - 2018-01-31 10:38:46 --> Hooks Class Initialized
DEBUG - 2018-01-31 10:38:46 --> UTF-8 Support Enabled
INFO - 2018-01-31 10:38:46 --> Utf8 Class Initialized
INFO - 2018-01-31 10:38:46 --> URI Class Initialized
INFO - 2018-01-31 10:38:46 --> Router Class Initialized
INFO - 2018-01-31 10:38:46 --> Output Class Initialized
INFO - 2018-01-31 10:38:46 --> Security Class Initialized
DEBUG - 2018-01-31 10:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 10:38:46 --> Input Class Initialized
INFO - 2018-01-31 10:38:46 --> Language Class Initialized
INFO - 2018-01-31 10:38:46 --> Language Class Initialized
INFO - 2018-01-31 10:38:46 --> Config Class Initialized
INFO - 2018-01-31 10:38:46 --> Loader Class Initialized
INFO - 2018-01-31 16:08:46 --> Helper loaded: url_helper
INFO - 2018-01-31 16:08:46 --> Helper loaded: notification_helper
INFO - 2018-01-31 16:08:46 --> Helper loaded: settings_helper
INFO - 2018-01-31 16:08:46 --> Helper loaded: permission_helper
INFO - 2018-01-31 16:08:46 --> Helper loaded: users_helper
INFO - 2018-01-31 16:08:46 --> Database Driver Class Initialized
DEBUG - 2018-01-31 16:08:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 16:08:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 16:08:46 --> Helper loaded: form_helper
INFO - 2018-01-31 16:08:46 --> Form Validation Class Initialized
INFO - 2018-01-31 16:08:46 --> Controller Class Initialized
INFO - 2018-01-31 16:08:46 --> Model Class Initialized
INFO - 2018-01-31 16:08:46 --> Helper loaded: inflector_helper
DEBUG - 2018-01-31 16:08:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-31 16:08:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-31 16:08:46 --> Model Class Initialized
INFO - 2018-01-31 16:08:46 --> Model Class Initialized
INFO - 2018-01-31 16:08:46 --> Model Class Initialized
INFO - 2018-01-31 16:08:46 --> Model Class Initialized
INFO - 2018-01-31 16:08:46 --> Model Class Initialized
INFO - 2018-01-31 16:08:46 --> Model Class Initialized
INFO - 2018-01-31 16:08:46 --> Model Class Initialized
INFO - 2018-01-31 16:08:46 --> Model Class Initialized
INFO - 2018-01-31 16:08:46 --> Model Class Initialized
INFO - 2018-01-31 16:08:46 --> Model Class Initialized
INFO - 2018-01-31 16:08:46 --> Model Class Initialized
INFO - 2018-01-31 16:08:46 --> Language file loaded: language/english/message_lang.php
INFO - 2018-01-31 16:08:46 --> Final output sent to browser
DEBUG - 2018-01-31 16:08:46 --> Total execution time: 0.1287
INFO - 2018-01-31 10:40:41 --> Config Class Initialized
INFO - 2018-01-31 10:40:41 --> Hooks Class Initialized
DEBUG - 2018-01-31 10:40:41 --> UTF-8 Support Enabled
INFO - 2018-01-31 10:40:41 --> Utf8 Class Initialized
INFO - 2018-01-31 10:40:41 --> URI Class Initialized
INFO - 2018-01-31 10:40:41 --> Router Class Initialized
INFO - 2018-01-31 10:40:41 --> Output Class Initialized
INFO - 2018-01-31 10:40:41 --> Security Class Initialized
DEBUG - 2018-01-31 10:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 10:40:41 --> Input Class Initialized
INFO - 2018-01-31 10:40:41 --> Language Class Initialized
INFO - 2018-01-31 10:40:41 --> Language Class Initialized
INFO - 2018-01-31 10:40:41 --> Config Class Initialized
INFO - 2018-01-31 10:40:41 --> Loader Class Initialized
INFO - 2018-01-31 16:10:41 --> Helper loaded: url_helper
INFO - 2018-01-31 16:10:41 --> Helper loaded: notification_helper
INFO - 2018-01-31 16:10:41 --> Helper loaded: settings_helper
INFO - 2018-01-31 16:10:41 --> Helper loaded: permission_helper
INFO - 2018-01-31 16:10:41 --> Helper loaded: users_helper
INFO - 2018-01-31 16:10:41 --> Database Driver Class Initialized
DEBUG - 2018-01-31 16:10:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 16:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 16:10:41 --> Helper loaded: form_helper
INFO - 2018-01-31 16:10:41 --> Form Validation Class Initialized
INFO - 2018-01-31 16:10:41 --> Controller Class Initialized
INFO - 2018-01-31 16:10:41 --> Model Class Initialized
INFO - 2018-01-31 16:10:41 --> Helper loaded: inflector_helper
DEBUG - 2018-01-31 16:10:41 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-31 16:10:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-31 16:10:41 --> Model Class Initialized
INFO - 2018-01-31 16:10:41 --> Model Class Initialized
INFO - 2018-01-31 16:10:41 --> Model Class Initialized
INFO - 2018-01-31 16:10:41 --> Model Class Initialized
INFO - 2018-01-31 16:10:41 --> Model Class Initialized
INFO - 2018-01-31 16:10:41 --> Model Class Initialized
INFO - 2018-01-31 16:10:41 --> Model Class Initialized
INFO - 2018-01-31 16:10:41 --> Model Class Initialized
INFO - 2018-01-31 16:10:41 --> Model Class Initialized
INFO - 2018-01-31 16:10:41 --> Model Class Initialized
ERROR - 2018-01-31 16:10:41 --> Severity: error --> Exception: syntax error, unexpected end of file /home/pr01004/public_html/application/models/Filter_model.php 474
INFO - 2018-01-31 10:40:44 --> Config Class Initialized
INFO - 2018-01-31 10:40:44 --> Hooks Class Initialized
DEBUG - 2018-01-31 10:40:44 --> UTF-8 Support Enabled
INFO - 2018-01-31 10:40:44 --> Utf8 Class Initialized
INFO - 2018-01-31 10:40:44 --> URI Class Initialized
INFO - 2018-01-31 10:40:44 --> Router Class Initialized
INFO - 2018-01-31 10:40:44 --> Output Class Initialized
INFO - 2018-01-31 10:40:44 --> Security Class Initialized
DEBUG - 2018-01-31 10:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 10:40:44 --> Input Class Initialized
INFO - 2018-01-31 10:40:44 --> Language Class Initialized
INFO - 2018-01-31 10:40:44 --> Language Class Initialized
INFO - 2018-01-31 10:40:44 --> Config Class Initialized
INFO - 2018-01-31 10:40:44 --> Loader Class Initialized
INFO - 2018-01-31 16:10:44 --> Helper loaded: url_helper
INFO - 2018-01-31 16:10:44 --> Helper loaded: notification_helper
INFO - 2018-01-31 16:10:44 --> Helper loaded: settings_helper
INFO - 2018-01-31 16:10:44 --> Helper loaded: permission_helper
INFO - 2018-01-31 16:10:44 --> Helper loaded: users_helper
INFO - 2018-01-31 16:10:44 --> Database Driver Class Initialized
DEBUG - 2018-01-31 16:10:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 16:10:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 16:10:44 --> Helper loaded: form_helper
INFO - 2018-01-31 16:10:44 --> Form Validation Class Initialized
INFO - 2018-01-31 16:10:44 --> Controller Class Initialized
INFO - 2018-01-31 16:10:44 --> Model Class Initialized
INFO - 2018-01-31 16:10:44 --> Helper loaded: inflector_helper
DEBUG - 2018-01-31 16:10:44 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-31 16:10:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-31 16:10:44 --> Model Class Initialized
INFO - 2018-01-31 16:10:44 --> Model Class Initialized
INFO - 2018-01-31 16:10:44 --> Model Class Initialized
INFO - 2018-01-31 16:10:44 --> Model Class Initialized
INFO - 2018-01-31 16:10:44 --> Model Class Initialized
INFO - 2018-01-31 16:10:44 --> Model Class Initialized
INFO - 2018-01-31 16:10:44 --> Model Class Initialized
INFO - 2018-01-31 16:10:44 --> Model Class Initialized
INFO - 2018-01-31 16:10:44 --> Model Class Initialized
INFO - 2018-01-31 16:10:44 --> Model Class Initialized
INFO - 2018-01-31 16:10:44 --> Model Class Initialized
INFO - 2018-01-31 16:10:44 --> Language file loaded: language/english/message_lang.php
INFO - 2018-01-31 16:10:44 --> Final output sent to browser
DEBUG - 2018-01-31 16:10:44 --> Total execution time: 0.1396
INFO - 2018-01-31 10:43:06 --> Config Class Initialized
INFO - 2018-01-31 10:43:06 --> Hooks Class Initialized
DEBUG - 2018-01-31 10:43:06 --> UTF-8 Support Enabled
INFO - 2018-01-31 10:43:06 --> Utf8 Class Initialized
INFO - 2018-01-31 10:43:06 --> URI Class Initialized
INFO - 2018-01-31 10:43:06 --> Router Class Initialized
INFO - 2018-01-31 10:43:06 --> Output Class Initialized
INFO - 2018-01-31 10:43:06 --> Security Class Initialized
DEBUG - 2018-01-31 10:43:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 10:43:06 --> Input Class Initialized
INFO - 2018-01-31 10:43:06 --> Language Class Initialized
INFO - 2018-01-31 10:43:06 --> Language Class Initialized
INFO - 2018-01-31 10:43:06 --> Config Class Initialized
INFO - 2018-01-31 10:43:06 --> Loader Class Initialized
INFO - 2018-01-31 16:13:06 --> Helper loaded: url_helper
INFO - 2018-01-31 16:13:06 --> Helper loaded: notification_helper
INFO - 2018-01-31 16:13:06 --> Helper loaded: settings_helper
INFO - 2018-01-31 16:13:06 --> Helper loaded: permission_helper
INFO - 2018-01-31 16:13:06 --> Helper loaded: users_helper
INFO - 2018-01-31 16:13:06 --> Database Driver Class Initialized
DEBUG - 2018-01-31 16:13:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 16:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 16:13:06 --> Helper loaded: form_helper
INFO - 2018-01-31 16:13:06 --> Form Validation Class Initialized
INFO - 2018-01-31 16:13:06 --> Controller Class Initialized
INFO - 2018-01-31 16:13:06 --> Model Class Initialized
INFO - 2018-01-31 16:13:06 --> Helper loaded: inflector_helper
DEBUG - 2018-01-31 16:13:06 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-31 16:13:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-31 16:13:06 --> Model Class Initialized
INFO - 2018-01-31 16:13:06 --> Model Class Initialized
INFO - 2018-01-31 16:13:06 --> Model Class Initialized
INFO - 2018-01-31 16:13:06 --> Model Class Initialized
INFO - 2018-01-31 16:13:06 --> Model Class Initialized
INFO - 2018-01-31 16:13:06 --> Model Class Initialized
INFO - 2018-01-31 16:13:06 --> Model Class Initialized
INFO - 2018-01-31 16:13:06 --> Model Class Initialized
INFO - 2018-01-31 16:13:06 --> Model Class Initialized
INFO - 2018-01-31 16:13:06 --> Model Class Initialized
INFO - 2018-01-31 16:13:06 --> Model Class Initialized
INFO - 2018-01-31 16:13:06 --> Language file loaded: language/english/message_lang.php
INFO - 2018-01-31 16:13:06 --> Model Class Initialized
INFO - 2018-01-31 16:13:06 --> Final output sent to browser
DEBUG - 2018-01-31 16:13:06 --> Total execution time: 0.1275
INFO - 2018-01-31 10:44:03 --> Config Class Initialized
INFO - 2018-01-31 10:44:03 --> Hooks Class Initialized
DEBUG - 2018-01-31 10:44:03 --> UTF-8 Support Enabled
INFO - 2018-01-31 10:44:03 --> Utf8 Class Initialized
INFO - 2018-01-31 10:44:03 --> URI Class Initialized
INFO - 2018-01-31 10:44:03 --> Router Class Initialized
INFO - 2018-01-31 10:44:03 --> Output Class Initialized
INFO - 2018-01-31 10:44:03 --> Security Class Initialized
DEBUG - 2018-01-31 10:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 10:44:03 --> Input Class Initialized
INFO - 2018-01-31 10:44:03 --> Language Class Initialized
INFO - 2018-01-31 10:44:03 --> Language Class Initialized
INFO - 2018-01-31 10:44:03 --> Config Class Initialized
INFO - 2018-01-31 10:44:03 --> Loader Class Initialized
INFO - 2018-01-31 16:14:03 --> Helper loaded: url_helper
INFO - 2018-01-31 16:14:03 --> Helper loaded: notification_helper
INFO - 2018-01-31 16:14:03 --> Helper loaded: settings_helper
INFO - 2018-01-31 16:14:03 --> Helper loaded: permission_helper
INFO - 2018-01-31 16:14:03 --> Helper loaded: users_helper
INFO - 2018-01-31 16:14:03 --> Database Driver Class Initialized
DEBUG - 2018-01-31 16:14:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 16:14:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 16:14:03 --> Helper loaded: form_helper
INFO - 2018-01-31 16:14:03 --> Form Validation Class Initialized
INFO - 2018-01-31 16:14:03 --> Controller Class Initialized
INFO - 2018-01-31 16:14:03 --> Model Class Initialized
INFO - 2018-01-31 16:14:03 --> Helper loaded: inflector_helper
DEBUG - 2018-01-31 16:14:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-31 16:14:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-31 16:14:03 --> Model Class Initialized
INFO - 2018-01-31 16:14:03 --> Model Class Initialized
INFO - 2018-01-31 16:14:03 --> Model Class Initialized
INFO - 2018-01-31 16:14:03 --> Model Class Initialized
INFO - 2018-01-31 16:14:03 --> Model Class Initialized
INFO - 2018-01-31 16:14:03 --> Model Class Initialized
INFO - 2018-01-31 16:14:03 --> Model Class Initialized
INFO - 2018-01-31 16:14:03 --> Model Class Initialized
INFO - 2018-01-31 16:14:03 --> Model Class Initialized
INFO - 2018-01-31 16:14:03 --> Model Class Initialized
INFO - 2018-01-31 16:14:03 --> Model Class Initialized
INFO - 2018-01-31 16:14:03 --> Language file loaded: language/english/message_lang.php
INFO - 2018-01-31 16:14:03 --> Model Class Initialized
INFO - 2018-01-31 16:14:03 --> Final output sent to browser
DEBUG - 2018-01-31 16:14:03 --> Total execution time: 0.1594
INFO - 2018-01-31 10:45:24 --> Config Class Initialized
INFO - 2018-01-31 10:45:24 --> Hooks Class Initialized
DEBUG - 2018-01-31 10:45:24 --> UTF-8 Support Enabled
INFO - 2018-01-31 10:45:24 --> Utf8 Class Initialized
INFO - 2018-01-31 10:45:24 --> URI Class Initialized
INFO - 2018-01-31 10:45:24 --> Router Class Initialized
INFO - 2018-01-31 10:45:24 --> Output Class Initialized
INFO - 2018-01-31 10:45:24 --> Security Class Initialized
DEBUG - 2018-01-31 10:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 10:45:24 --> Input Class Initialized
INFO - 2018-01-31 10:45:24 --> Language Class Initialized
INFO - 2018-01-31 10:45:24 --> Language Class Initialized
INFO - 2018-01-31 10:45:24 --> Config Class Initialized
INFO - 2018-01-31 10:45:24 --> Loader Class Initialized
INFO - 2018-01-31 16:15:24 --> Helper loaded: url_helper
INFO - 2018-01-31 16:15:24 --> Helper loaded: notification_helper
INFO - 2018-01-31 16:15:24 --> Helper loaded: settings_helper
INFO - 2018-01-31 16:15:24 --> Helper loaded: permission_helper
INFO - 2018-01-31 16:15:24 --> Helper loaded: users_helper
INFO - 2018-01-31 16:15:24 --> Database Driver Class Initialized
DEBUG - 2018-01-31 16:15:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 16:15:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 16:15:25 --> Helper loaded: form_helper
INFO - 2018-01-31 16:15:25 --> Form Validation Class Initialized
INFO - 2018-01-31 16:15:25 --> Controller Class Initialized
INFO - 2018-01-31 16:15:25 --> Model Class Initialized
INFO - 2018-01-31 16:15:25 --> Helper loaded: inflector_helper
DEBUG - 2018-01-31 16:15:25 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-31 16:15:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-31 16:15:25 --> Model Class Initialized
INFO - 2018-01-31 16:15:25 --> Model Class Initialized
INFO - 2018-01-31 16:15:25 --> Model Class Initialized
INFO - 2018-01-31 16:15:25 --> Model Class Initialized
INFO - 2018-01-31 16:15:25 --> Model Class Initialized
INFO - 2018-01-31 16:15:25 --> Model Class Initialized
INFO - 2018-01-31 16:15:25 --> Model Class Initialized
INFO - 2018-01-31 16:15:25 --> Model Class Initialized
INFO - 2018-01-31 16:15:25 --> Model Class Initialized
INFO - 2018-01-31 16:15:25 --> Model Class Initialized
INFO - 2018-01-31 16:15:25 --> Model Class Initialized
INFO - 2018-01-31 16:15:25 --> Language file loaded: language/english/message_lang.php
INFO - 2018-01-31 16:15:25 --> Final output sent to browser
DEBUG - 2018-01-31 16:15:25 --> Total execution time: 0.0925
INFO - 2018-01-31 10:45:40 --> Config Class Initialized
INFO - 2018-01-31 10:45:40 --> Hooks Class Initialized
DEBUG - 2018-01-31 10:45:40 --> UTF-8 Support Enabled
INFO - 2018-01-31 10:45:40 --> Utf8 Class Initialized
INFO - 2018-01-31 10:45:40 --> URI Class Initialized
INFO - 2018-01-31 10:45:40 --> Router Class Initialized
INFO - 2018-01-31 10:45:40 --> Output Class Initialized
INFO - 2018-01-31 10:45:40 --> Security Class Initialized
DEBUG - 2018-01-31 10:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 10:45:40 --> Input Class Initialized
INFO - 2018-01-31 10:45:40 --> Language Class Initialized
INFO - 2018-01-31 10:45:40 --> Language Class Initialized
INFO - 2018-01-31 10:45:40 --> Config Class Initialized
INFO - 2018-01-31 10:45:40 --> Loader Class Initialized
INFO - 2018-01-31 16:15:40 --> Helper loaded: url_helper
INFO - 2018-01-31 16:15:40 --> Helper loaded: notification_helper
INFO - 2018-01-31 16:15:40 --> Helper loaded: settings_helper
INFO - 2018-01-31 16:15:40 --> Helper loaded: permission_helper
INFO - 2018-01-31 16:15:40 --> Helper loaded: users_helper
INFO - 2018-01-31 16:15:40 --> Database Driver Class Initialized
DEBUG - 2018-01-31 16:15:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 16:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 16:15:40 --> Helper loaded: form_helper
INFO - 2018-01-31 16:15:40 --> Form Validation Class Initialized
INFO - 2018-01-31 16:15:40 --> Controller Class Initialized
INFO - 2018-01-31 16:15:40 --> Model Class Initialized
INFO - 2018-01-31 16:15:40 --> Helper loaded: inflector_helper
DEBUG - 2018-01-31 16:15:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-31 16:15:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-31 16:15:40 --> Model Class Initialized
INFO - 2018-01-31 16:15:40 --> Model Class Initialized
INFO - 2018-01-31 16:15:40 --> Model Class Initialized
INFO - 2018-01-31 16:15:40 --> Model Class Initialized
INFO - 2018-01-31 16:15:40 --> Model Class Initialized
INFO - 2018-01-31 16:15:40 --> Model Class Initialized
INFO - 2018-01-31 16:15:40 --> Model Class Initialized
INFO - 2018-01-31 16:15:40 --> Model Class Initialized
INFO - 2018-01-31 16:15:40 --> Model Class Initialized
INFO - 2018-01-31 16:15:40 --> Model Class Initialized
INFO - 2018-01-31 16:15:40 --> Model Class Initialized
INFO - 2018-01-31 16:15:40 --> Language file loaded: language/english/message_lang.php
INFO - 2018-01-31 16:15:40 --> Final output sent to browser
DEBUG - 2018-01-31 16:15:40 --> Total execution time: 0.1225
INFO - 2018-01-31 10:46:50 --> Config Class Initialized
INFO - 2018-01-31 10:46:50 --> Hooks Class Initialized
DEBUG - 2018-01-31 10:46:50 --> UTF-8 Support Enabled
INFO - 2018-01-31 10:46:50 --> Utf8 Class Initialized
INFO - 2018-01-31 10:46:50 --> URI Class Initialized
INFO - 2018-01-31 10:46:50 --> Router Class Initialized
INFO - 2018-01-31 10:46:50 --> Output Class Initialized
INFO - 2018-01-31 10:46:50 --> Security Class Initialized
DEBUG - 2018-01-31 10:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 10:46:50 --> Input Class Initialized
INFO - 2018-01-31 10:46:50 --> Language Class Initialized
INFO - 2018-01-31 10:46:50 --> Language Class Initialized
INFO - 2018-01-31 10:46:50 --> Config Class Initialized
INFO - 2018-01-31 10:46:50 --> Loader Class Initialized
INFO - 2018-01-31 16:16:50 --> Helper loaded: url_helper
INFO - 2018-01-31 16:16:50 --> Helper loaded: notification_helper
INFO - 2018-01-31 16:16:50 --> Helper loaded: settings_helper
INFO - 2018-01-31 16:16:50 --> Helper loaded: permission_helper
INFO - 2018-01-31 16:16:50 --> Helper loaded: users_helper
INFO - 2018-01-31 16:16:50 --> Database Driver Class Initialized
DEBUG - 2018-01-31 16:16:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 16:16:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 16:16:50 --> Helper loaded: form_helper
INFO - 2018-01-31 16:16:50 --> Form Validation Class Initialized
INFO - 2018-01-31 16:16:50 --> Controller Class Initialized
INFO - 2018-01-31 16:16:50 --> Model Class Initialized
INFO - 2018-01-31 16:16:50 --> Helper loaded: inflector_helper
DEBUG - 2018-01-31 16:16:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-31 16:16:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-31 16:16:50 --> Model Class Initialized
INFO - 2018-01-31 16:16:50 --> Model Class Initialized
INFO - 2018-01-31 16:16:50 --> Model Class Initialized
INFO - 2018-01-31 16:16:50 --> Model Class Initialized
INFO - 2018-01-31 16:16:50 --> Model Class Initialized
INFO - 2018-01-31 16:16:50 --> Model Class Initialized
INFO - 2018-01-31 16:16:50 --> Model Class Initialized
INFO - 2018-01-31 16:16:50 --> Model Class Initialized
INFO - 2018-01-31 16:16:50 --> Model Class Initialized
INFO - 2018-01-31 16:16:50 --> Model Class Initialized
INFO - 2018-01-31 16:16:50 --> Model Class Initialized
INFO - 2018-01-31 16:16:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-01-31 16:16:50 --> Final output sent to browser
DEBUG - 2018-01-31 16:16:50 --> Total execution time: 0.1372
INFO - 2018-01-31 10:50:40 --> Config Class Initialized
INFO - 2018-01-31 10:50:40 --> Hooks Class Initialized
DEBUG - 2018-01-31 10:50:40 --> UTF-8 Support Enabled
INFO - 2018-01-31 10:50:40 --> Utf8 Class Initialized
INFO - 2018-01-31 10:50:40 --> URI Class Initialized
INFO - 2018-01-31 10:50:40 --> Router Class Initialized
INFO - 2018-01-31 10:50:40 --> Output Class Initialized
INFO - 2018-01-31 10:50:40 --> Security Class Initialized
DEBUG - 2018-01-31 10:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 10:50:40 --> Input Class Initialized
INFO - 2018-01-31 10:50:40 --> Language Class Initialized
INFO - 2018-01-31 10:50:40 --> Language Class Initialized
INFO - 2018-01-31 10:50:40 --> Config Class Initialized
INFO - 2018-01-31 10:50:40 --> Loader Class Initialized
INFO - 2018-01-31 16:20:40 --> Helper loaded: url_helper
INFO - 2018-01-31 16:20:40 --> Helper loaded: notification_helper
INFO - 2018-01-31 16:20:40 --> Helper loaded: settings_helper
INFO - 2018-01-31 16:20:40 --> Helper loaded: permission_helper
INFO - 2018-01-31 16:20:40 --> Helper loaded: users_helper
INFO - 2018-01-31 16:20:40 --> Database Driver Class Initialized
DEBUG - 2018-01-31 16:20:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 16:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 16:20:40 --> Helper loaded: form_helper
INFO - 2018-01-31 16:20:40 --> Form Validation Class Initialized
INFO - 2018-01-31 16:20:40 --> Controller Class Initialized
INFO - 2018-01-31 16:20:40 --> Model Class Initialized
INFO - 2018-01-31 16:20:40 --> Helper loaded: inflector_helper
DEBUG - 2018-01-31 16:20:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-31 16:20:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-31 16:20:40 --> Model Class Initialized
INFO - 2018-01-31 16:20:40 --> Model Class Initialized
INFO - 2018-01-31 16:20:40 --> Model Class Initialized
INFO - 2018-01-31 16:20:40 --> Model Class Initialized
INFO - 2018-01-31 16:20:40 --> Model Class Initialized
INFO - 2018-01-31 16:20:40 --> Model Class Initialized
INFO - 2018-01-31 16:20:40 --> Model Class Initialized
INFO - 2018-01-31 16:20:40 --> Model Class Initialized
INFO - 2018-01-31 16:20:40 --> Model Class Initialized
INFO - 2018-01-31 16:20:40 --> Model Class Initialized
INFO - 2018-01-31 16:20:40 --> Model Class Initialized
INFO - 2018-01-31 16:20:40 --> Language file loaded: language/english/message_lang.php
INFO - 2018-01-31 16:20:40 --> Final output sent to browser
DEBUG - 2018-01-31 16:20:40 --> Total execution time: 0.1261
INFO - 2018-01-31 10:50:46 --> Config Class Initialized
INFO - 2018-01-31 10:50:46 --> Hooks Class Initialized
DEBUG - 2018-01-31 10:50:46 --> UTF-8 Support Enabled
INFO - 2018-01-31 10:50:46 --> Utf8 Class Initialized
INFO - 2018-01-31 10:50:46 --> URI Class Initialized
INFO - 2018-01-31 10:50:46 --> Router Class Initialized
INFO - 2018-01-31 10:50:46 --> Output Class Initialized
INFO - 2018-01-31 10:50:46 --> Security Class Initialized
DEBUG - 2018-01-31 10:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 10:50:46 --> Input Class Initialized
INFO - 2018-01-31 10:50:46 --> Language Class Initialized
INFO - 2018-01-31 10:50:47 --> Language Class Initialized
INFO - 2018-01-31 10:50:47 --> Config Class Initialized
INFO - 2018-01-31 10:50:47 --> Loader Class Initialized
INFO - 2018-01-31 16:20:47 --> Helper loaded: url_helper
INFO - 2018-01-31 16:20:47 --> Helper loaded: notification_helper
INFO - 2018-01-31 16:20:47 --> Helper loaded: settings_helper
INFO - 2018-01-31 16:20:47 --> Helper loaded: permission_helper
INFO - 2018-01-31 16:20:47 --> Helper loaded: users_helper
INFO - 2018-01-31 16:20:47 --> Database Driver Class Initialized
DEBUG - 2018-01-31 16:20:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 16:20:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 16:20:47 --> Helper loaded: form_helper
INFO - 2018-01-31 16:20:47 --> Form Validation Class Initialized
INFO - 2018-01-31 16:20:47 --> Controller Class Initialized
INFO - 2018-01-31 16:20:47 --> Model Class Initialized
INFO - 2018-01-31 16:20:47 --> Helper loaded: inflector_helper
DEBUG - 2018-01-31 16:20:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-31 16:20:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-31 16:20:47 --> Model Class Initialized
INFO - 2018-01-31 16:20:47 --> Model Class Initialized
INFO - 2018-01-31 16:20:47 --> Model Class Initialized
INFO - 2018-01-31 16:20:47 --> Model Class Initialized
INFO - 2018-01-31 16:20:47 --> Model Class Initialized
INFO - 2018-01-31 16:20:47 --> Model Class Initialized
INFO - 2018-01-31 16:20:47 --> Model Class Initialized
INFO - 2018-01-31 16:20:47 --> Model Class Initialized
INFO - 2018-01-31 16:20:47 --> Model Class Initialized
INFO - 2018-01-31 16:20:47 --> Model Class Initialized
INFO - 2018-01-31 16:20:47 --> Model Class Initialized
INFO - 2018-01-31 16:20:47 --> Language file loaded: language/english/message_lang.php
INFO - 2018-01-31 16:20:47 --> Final output sent to browser
DEBUG - 2018-01-31 16:20:47 --> Total execution time: 0.3697
INFO - 2018-01-31 10:53:19 --> Config Class Initialized
INFO - 2018-01-31 10:53:19 --> Hooks Class Initialized
DEBUG - 2018-01-31 10:53:19 --> UTF-8 Support Enabled
INFO - 2018-01-31 10:53:19 --> Utf8 Class Initialized
INFO - 2018-01-31 10:53:19 --> URI Class Initialized
INFO - 2018-01-31 10:53:19 --> Router Class Initialized
INFO - 2018-01-31 10:53:19 --> Output Class Initialized
INFO - 2018-01-31 10:53:19 --> Security Class Initialized
DEBUG - 2018-01-31 10:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 10:53:19 --> Input Class Initialized
INFO - 2018-01-31 10:53:19 --> Language Class Initialized
INFO - 2018-01-31 10:53:19 --> Language Class Initialized
INFO - 2018-01-31 10:53:19 --> Config Class Initialized
INFO - 2018-01-31 10:53:19 --> Loader Class Initialized
INFO - 2018-01-31 16:23:19 --> Helper loaded: url_helper
INFO - 2018-01-31 16:23:19 --> Helper loaded: notification_helper
INFO - 2018-01-31 16:23:19 --> Helper loaded: settings_helper
INFO - 2018-01-31 16:23:19 --> Helper loaded: permission_helper
INFO - 2018-01-31 16:23:19 --> Helper loaded: users_helper
INFO - 2018-01-31 16:23:19 --> Database Driver Class Initialized
DEBUG - 2018-01-31 16:23:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 16:23:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 16:23:19 --> Helper loaded: form_helper
INFO - 2018-01-31 16:23:19 --> Form Validation Class Initialized
INFO - 2018-01-31 16:23:19 --> Controller Class Initialized
INFO - 2018-01-31 16:23:19 --> Model Class Initialized
INFO - 2018-01-31 16:23:19 --> Helper loaded: inflector_helper
DEBUG - 2018-01-31 16:23:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-31 16:23:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-31 16:23:19 --> Model Class Initialized
INFO - 2018-01-31 16:23:19 --> Model Class Initialized
INFO - 2018-01-31 16:23:19 --> Model Class Initialized
INFO - 2018-01-31 16:23:19 --> Model Class Initialized
INFO - 2018-01-31 16:23:19 --> Model Class Initialized
INFO - 2018-01-31 16:23:19 --> Model Class Initialized
INFO - 2018-01-31 16:23:19 --> Model Class Initialized
INFO - 2018-01-31 16:23:19 --> Model Class Initialized
INFO - 2018-01-31 16:23:19 --> Model Class Initialized
INFO - 2018-01-31 16:23:19 --> Model Class Initialized
INFO - 2018-01-31 16:23:19 --> Model Class Initialized
INFO - 2018-01-31 16:23:19 --> Language file loaded: language/english/message_lang.php
INFO - 2018-01-31 16:23:19 --> Final output sent to browser
DEBUG - 2018-01-31 16:23:19 --> Total execution time: 0.1005
INFO - 2018-01-31 10:53:44 --> Config Class Initialized
INFO - 2018-01-31 10:53:44 --> Hooks Class Initialized
DEBUG - 2018-01-31 10:53:44 --> UTF-8 Support Enabled
INFO - 2018-01-31 10:53:44 --> Utf8 Class Initialized
INFO - 2018-01-31 10:53:44 --> URI Class Initialized
INFO - 2018-01-31 10:53:44 --> Router Class Initialized
INFO - 2018-01-31 10:53:44 --> Output Class Initialized
INFO - 2018-01-31 10:53:44 --> Security Class Initialized
DEBUG - 2018-01-31 10:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 10:53:44 --> Input Class Initialized
INFO - 2018-01-31 10:53:44 --> Language Class Initialized
INFO - 2018-01-31 10:53:44 --> Language Class Initialized
INFO - 2018-01-31 10:53:44 --> Config Class Initialized
INFO - 2018-01-31 10:53:44 --> Loader Class Initialized
INFO - 2018-01-31 16:23:44 --> Helper loaded: url_helper
INFO - 2018-01-31 16:23:44 --> Helper loaded: notification_helper
INFO - 2018-01-31 16:23:44 --> Helper loaded: settings_helper
INFO - 2018-01-31 16:23:44 --> Helper loaded: permission_helper
INFO - 2018-01-31 16:23:44 --> Helper loaded: users_helper
INFO - 2018-01-31 16:23:44 --> Database Driver Class Initialized
DEBUG - 2018-01-31 16:23:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 16:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 16:23:44 --> Helper loaded: form_helper
INFO - 2018-01-31 16:23:44 --> Form Validation Class Initialized
INFO - 2018-01-31 16:23:44 --> Controller Class Initialized
INFO - 2018-01-31 16:23:44 --> Model Class Initialized
INFO - 2018-01-31 16:23:44 --> Helper loaded: inflector_helper
DEBUG - 2018-01-31 16:23:44 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-31 16:23:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-31 16:23:44 --> Model Class Initialized
INFO - 2018-01-31 16:23:44 --> Model Class Initialized
INFO - 2018-01-31 16:23:44 --> Model Class Initialized
INFO - 2018-01-31 16:23:44 --> Model Class Initialized
INFO - 2018-01-31 16:23:44 --> Model Class Initialized
INFO - 2018-01-31 16:23:44 --> Model Class Initialized
INFO - 2018-01-31 16:23:44 --> Model Class Initialized
INFO - 2018-01-31 16:23:44 --> Model Class Initialized
INFO - 2018-01-31 16:23:44 --> Model Class Initialized
INFO - 2018-01-31 16:23:44 --> Model Class Initialized
INFO - 2018-01-31 16:23:44 --> Model Class Initialized
INFO - 2018-01-31 16:23:44 --> Language file loaded: language/english/message_lang.php
INFO - 2018-01-31 16:23:44 --> Final output sent to browser
DEBUG - 2018-01-31 16:23:44 --> Total execution time: 0.1256
INFO - 2018-01-31 10:54:00 --> Config Class Initialized
INFO - 2018-01-31 10:54:00 --> Hooks Class Initialized
DEBUG - 2018-01-31 10:54:00 --> UTF-8 Support Enabled
INFO - 2018-01-31 10:54:00 --> Utf8 Class Initialized
INFO - 2018-01-31 10:54:00 --> URI Class Initialized
INFO - 2018-01-31 10:54:00 --> Router Class Initialized
INFO - 2018-01-31 10:54:00 --> Output Class Initialized
INFO - 2018-01-31 10:54:00 --> Security Class Initialized
DEBUG - 2018-01-31 10:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 10:54:00 --> Input Class Initialized
INFO - 2018-01-31 10:54:00 --> Language Class Initialized
INFO - 2018-01-31 10:54:00 --> Language Class Initialized
INFO - 2018-01-31 10:54:00 --> Config Class Initialized
INFO - 2018-01-31 10:54:00 --> Loader Class Initialized
INFO - 2018-01-31 16:24:00 --> Helper loaded: url_helper
INFO - 2018-01-31 16:24:00 --> Helper loaded: notification_helper
INFO - 2018-01-31 16:24:00 --> Helper loaded: settings_helper
INFO - 2018-01-31 16:24:00 --> Helper loaded: permission_helper
INFO - 2018-01-31 16:24:00 --> Helper loaded: users_helper
INFO - 2018-01-31 16:24:00 --> Database Driver Class Initialized
DEBUG - 2018-01-31 16:24:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 16:24:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 16:24:00 --> Helper loaded: form_helper
INFO - 2018-01-31 16:24:00 --> Form Validation Class Initialized
INFO - 2018-01-31 16:24:00 --> Controller Class Initialized
INFO - 2018-01-31 16:24:00 --> Model Class Initialized
INFO - 2018-01-31 16:24:00 --> Helper loaded: inflector_helper
DEBUG - 2018-01-31 16:24:00 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-31 16:24:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-31 16:24:00 --> Model Class Initialized
INFO - 2018-01-31 16:24:00 --> Model Class Initialized
INFO - 2018-01-31 16:24:00 --> Model Class Initialized
INFO - 2018-01-31 16:24:00 --> Model Class Initialized
INFO - 2018-01-31 16:24:00 --> Model Class Initialized
INFO - 2018-01-31 16:24:00 --> Model Class Initialized
INFO - 2018-01-31 16:24:00 --> Model Class Initialized
INFO - 2018-01-31 16:24:00 --> Model Class Initialized
INFO - 2018-01-31 16:24:00 --> Model Class Initialized
INFO - 2018-01-31 16:24:00 --> Model Class Initialized
INFO - 2018-01-31 16:24:00 --> Model Class Initialized
INFO - 2018-01-31 16:24:00 --> Language file loaded: language/english/message_lang.php
INFO - 2018-01-31 16:24:00 --> Final output sent to browser
DEBUG - 2018-01-31 16:24:00 --> Total execution time: 0.1140
INFO - 2018-01-31 10:54:09 --> Config Class Initialized
INFO - 2018-01-31 10:54:09 --> Hooks Class Initialized
DEBUG - 2018-01-31 10:54:09 --> UTF-8 Support Enabled
INFO - 2018-01-31 10:54:09 --> Utf8 Class Initialized
INFO - 2018-01-31 10:54:09 --> URI Class Initialized
INFO - 2018-01-31 10:54:09 --> Router Class Initialized
INFO - 2018-01-31 10:54:09 --> Output Class Initialized
INFO - 2018-01-31 10:54:09 --> Security Class Initialized
DEBUG - 2018-01-31 10:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 10:54:09 --> Input Class Initialized
INFO - 2018-01-31 10:54:09 --> Language Class Initialized
INFO - 2018-01-31 10:54:09 --> Language Class Initialized
INFO - 2018-01-31 10:54:09 --> Config Class Initialized
INFO - 2018-01-31 10:54:09 --> Loader Class Initialized
INFO - 2018-01-31 16:24:09 --> Helper loaded: url_helper
INFO - 2018-01-31 16:24:09 --> Helper loaded: notification_helper
INFO - 2018-01-31 16:24:09 --> Helper loaded: settings_helper
INFO - 2018-01-31 16:24:09 --> Helper loaded: permission_helper
INFO - 2018-01-31 16:24:09 --> Helper loaded: users_helper
INFO - 2018-01-31 16:24:09 --> Database Driver Class Initialized
DEBUG - 2018-01-31 16:24:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 16:24:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 16:24:09 --> Helper loaded: form_helper
INFO - 2018-01-31 16:24:09 --> Form Validation Class Initialized
INFO - 2018-01-31 16:24:09 --> Controller Class Initialized
INFO - 2018-01-31 16:24:09 --> Model Class Initialized
INFO - 2018-01-31 16:24:09 --> Helper loaded: inflector_helper
DEBUG - 2018-01-31 16:24:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-31 16:24:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-31 16:24:09 --> Model Class Initialized
INFO - 2018-01-31 16:24:09 --> Model Class Initialized
INFO - 2018-01-31 16:24:09 --> Model Class Initialized
INFO - 2018-01-31 16:24:09 --> Model Class Initialized
INFO - 2018-01-31 16:24:09 --> Model Class Initialized
INFO - 2018-01-31 16:24:09 --> Model Class Initialized
INFO - 2018-01-31 16:24:09 --> Model Class Initialized
INFO - 2018-01-31 16:24:09 --> Model Class Initialized
INFO - 2018-01-31 16:24:09 --> Model Class Initialized
INFO - 2018-01-31 16:24:09 --> Model Class Initialized
INFO - 2018-01-31 16:24:09 --> Model Class Initialized
INFO - 2018-01-31 16:24:09 --> Language file loaded: language/english/message_lang.php
INFO - 2018-01-31 16:24:09 --> Final output sent to browser
DEBUG - 2018-01-31 16:24:09 --> Total execution time: 0.1250
INFO - 2018-01-31 10:54:50 --> Config Class Initialized
INFO - 2018-01-31 10:54:50 --> Hooks Class Initialized
DEBUG - 2018-01-31 10:54:50 --> UTF-8 Support Enabled
INFO - 2018-01-31 10:54:50 --> Utf8 Class Initialized
INFO - 2018-01-31 10:54:50 --> URI Class Initialized
INFO - 2018-01-31 10:54:50 --> Router Class Initialized
INFO - 2018-01-31 10:54:50 --> Output Class Initialized
INFO - 2018-01-31 10:54:50 --> Security Class Initialized
DEBUG - 2018-01-31 10:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 10:54:50 --> Input Class Initialized
INFO - 2018-01-31 10:54:50 --> Language Class Initialized
INFO - 2018-01-31 10:54:50 --> Language Class Initialized
INFO - 2018-01-31 10:54:50 --> Config Class Initialized
INFO - 2018-01-31 10:54:50 --> Loader Class Initialized
INFO - 2018-01-31 16:24:50 --> Helper loaded: url_helper
INFO - 2018-01-31 16:24:50 --> Helper loaded: notification_helper
INFO - 2018-01-31 16:24:50 --> Helper loaded: settings_helper
INFO - 2018-01-31 16:24:50 --> Helper loaded: permission_helper
INFO - 2018-01-31 16:24:50 --> Helper loaded: users_helper
INFO - 2018-01-31 16:24:50 --> Database Driver Class Initialized
DEBUG - 2018-01-31 16:24:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 16:24:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 16:24:50 --> Helper loaded: form_helper
INFO - 2018-01-31 16:24:50 --> Form Validation Class Initialized
INFO - 2018-01-31 16:24:50 --> Controller Class Initialized
INFO - 2018-01-31 16:24:50 --> Model Class Initialized
INFO - 2018-01-31 16:24:50 --> Helper loaded: inflector_helper
DEBUG - 2018-01-31 16:24:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-31 16:24:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-31 16:24:50 --> Model Class Initialized
INFO - 2018-01-31 16:24:50 --> Model Class Initialized
INFO - 2018-01-31 16:24:50 --> Model Class Initialized
INFO - 2018-01-31 16:24:50 --> Model Class Initialized
INFO - 2018-01-31 16:24:50 --> Model Class Initialized
INFO - 2018-01-31 16:24:50 --> Model Class Initialized
INFO - 2018-01-31 16:24:50 --> Model Class Initialized
INFO - 2018-01-31 16:24:50 --> Model Class Initialized
INFO - 2018-01-31 16:24:50 --> Model Class Initialized
INFO - 2018-01-31 16:24:50 --> Model Class Initialized
INFO - 2018-01-31 16:24:50 --> Model Class Initialized
INFO - 2018-01-31 16:24:50 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-01-31 16:24:50 --> Severity: Notice --> Trying to get property 'name' of non-object /home/pr01004/public_html/application/controllers/api/Filter.php 611
ERROR - 2018-01-31 16:24:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/pr01004/public_html/system/core/Exceptions.php:271) /home/pr01004/public_html/system/core/Common.php 564
INFO - 2018-01-31 16:24:50 --> Final output sent to browser
DEBUG - 2018-01-31 16:24:50 --> Total execution time: 0.1214
INFO - 2018-01-31 10:55:45 --> Config Class Initialized
INFO - 2018-01-31 10:55:45 --> Hooks Class Initialized
DEBUG - 2018-01-31 10:55:45 --> UTF-8 Support Enabled
INFO - 2018-01-31 10:55:45 --> Utf8 Class Initialized
INFO - 2018-01-31 10:55:45 --> URI Class Initialized
INFO - 2018-01-31 10:55:45 --> Router Class Initialized
INFO - 2018-01-31 10:55:45 --> Output Class Initialized
INFO - 2018-01-31 10:55:45 --> Security Class Initialized
DEBUG - 2018-01-31 10:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 10:55:45 --> Input Class Initialized
INFO - 2018-01-31 10:55:45 --> Language Class Initialized
INFO - 2018-01-31 10:55:45 --> Language Class Initialized
INFO - 2018-01-31 10:55:45 --> Config Class Initialized
INFO - 2018-01-31 10:55:45 --> Loader Class Initialized
INFO - 2018-01-31 16:25:45 --> Helper loaded: url_helper
INFO - 2018-01-31 16:25:45 --> Helper loaded: notification_helper
INFO - 2018-01-31 16:25:45 --> Helper loaded: settings_helper
INFO - 2018-01-31 16:25:45 --> Helper loaded: permission_helper
INFO - 2018-01-31 16:25:45 --> Helper loaded: users_helper
INFO - 2018-01-31 16:25:45 --> Database Driver Class Initialized
DEBUG - 2018-01-31 16:25:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 16:25:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 16:25:45 --> Helper loaded: form_helper
INFO - 2018-01-31 16:25:45 --> Form Validation Class Initialized
INFO - 2018-01-31 16:25:45 --> Controller Class Initialized
INFO - 2018-01-31 16:25:45 --> Model Class Initialized
INFO - 2018-01-31 16:25:45 --> Helper loaded: inflector_helper
DEBUG - 2018-01-31 16:25:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-31 16:25:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-31 16:25:45 --> Model Class Initialized
INFO - 2018-01-31 16:25:45 --> Model Class Initialized
INFO - 2018-01-31 16:25:45 --> Model Class Initialized
INFO - 2018-01-31 16:25:45 --> Model Class Initialized
INFO - 2018-01-31 16:25:45 --> Model Class Initialized
INFO - 2018-01-31 16:25:45 --> Model Class Initialized
INFO - 2018-01-31 16:25:45 --> Model Class Initialized
INFO - 2018-01-31 16:25:45 --> Model Class Initialized
INFO - 2018-01-31 16:25:45 --> Model Class Initialized
INFO - 2018-01-31 16:25:45 --> Model Class Initialized
INFO - 2018-01-31 16:25:45 --> Model Class Initialized
INFO - 2018-01-31 16:25:45 --> Language file loaded: language/english/message_lang.php
INFO - 2018-01-31 16:25:45 --> Final output sent to browser
DEBUG - 2018-01-31 16:25:45 --> Total execution time: 0.1063
INFO - 2018-01-31 10:56:16 --> Config Class Initialized
INFO - 2018-01-31 10:56:16 --> Hooks Class Initialized
DEBUG - 2018-01-31 10:56:16 --> UTF-8 Support Enabled
INFO - 2018-01-31 10:56:16 --> Utf8 Class Initialized
INFO - 2018-01-31 10:56:16 --> URI Class Initialized
INFO - 2018-01-31 10:56:16 --> Router Class Initialized
INFO - 2018-01-31 10:56:16 --> Output Class Initialized
INFO - 2018-01-31 10:56:16 --> Security Class Initialized
DEBUG - 2018-01-31 10:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 10:56:16 --> Input Class Initialized
INFO - 2018-01-31 10:56:16 --> Language Class Initialized
INFO - 2018-01-31 10:56:16 --> Language Class Initialized
INFO - 2018-01-31 10:56:16 --> Config Class Initialized
INFO - 2018-01-31 10:56:16 --> Loader Class Initialized
INFO - 2018-01-31 16:26:16 --> Helper loaded: url_helper
INFO - 2018-01-31 16:26:16 --> Helper loaded: notification_helper
INFO - 2018-01-31 16:26:16 --> Helper loaded: settings_helper
INFO - 2018-01-31 16:26:16 --> Helper loaded: permission_helper
INFO - 2018-01-31 16:26:16 --> Helper loaded: users_helper
INFO - 2018-01-31 16:26:16 --> Database Driver Class Initialized
DEBUG - 2018-01-31 16:26:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 16:26:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 16:26:16 --> Helper loaded: form_helper
INFO - 2018-01-31 16:26:16 --> Form Validation Class Initialized
INFO - 2018-01-31 16:26:16 --> Controller Class Initialized
INFO - 2018-01-31 16:26:16 --> Model Class Initialized
INFO - 2018-01-31 16:26:16 --> Helper loaded: inflector_helper
DEBUG - 2018-01-31 16:26:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-31 16:26:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-31 16:26:16 --> Model Class Initialized
INFO - 2018-01-31 16:26:16 --> Model Class Initialized
INFO - 2018-01-31 16:26:16 --> Model Class Initialized
INFO - 2018-01-31 16:26:16 --> Model Class Initialized
INFO - 2018-01-31 16:26:16 --> Model Class Initialized
INFO - 2018-01-31 16:26:16 --> Model Class Initialized
INFO - 2018-01-31 16:26:16 --> Model Class Initialized
INFO - 2018-01-31 16:26:16 --> Model Class Initialized
INFO - 2018-01-31 16:26:16 --> Model Class Initialized
INFO - 2018-01-31 16:26:16 --> Model Class Initialized
INFO - 2018-01-31 16:26:16 --> Model Class Initialized
INFO - 2018-01-31 16:26:16 --> Language file loaded: language/english/message_lang.php
INFO - 2018-01-31 16:26:16 --> Final output sent to browser
DEBUG - 2018-01-31 16:26:16 --> Total execution time: 0.1241
INFO - 2018-01-31 10:56:44 --> Config Class Initialized
INFO - 2018-01-31 10:56:44 --> Hooks Class Initialized
DEBUG - 2018-01-31 10:56:44 --> UTF-8 Support Enabled
INFO - 2018-01-31 10:56:44 --> Utf8 Class Initialized
INFO - 2018-01-31 10:56:44 --> URI Class Initialized
INFO - 2018-01-31 10:56:44 --> Router Class Initialized
INFO - 2018-01-31 10:56:44 --> Output Class Initialized
INFO - 2018-01-31 10:56:44 --> Security Class Initialized
DEBUG - 2018-01-31 10:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 10:56:44 --> Input Class Initialized
INFO - 2018-01-31 10:56:44 --> Language Class Initialized
INFO - 2018-01-31 10:56:44 --> Language Class Initialized
INFO - 2018-01-31 10:56:44 --> Config Class Initialized
INFO - 2018-01-31 10:56:44 --> Loader Class Initialized
INFO - 2018-01-31 16:26:44 --> Helper loaded: url_helper
INFO - 2018-01-31 16:26:44 --> Helper loaded: notification_helper
INFO - 2018-01-31 16:26:44 --> Helper loaded: settings_helper
INFO - 2018-01-31 16:26:44 --> Helper loaded: permission_helper
INFO - 2018-01-31 16:26:44 --> Helper loaded: users_helper
INFO - 2018-01-31 16:26:44 --> Database Driver Class Initialized
DEBUG - 2018-01-31 16:26:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 16:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 16:26:44 --> Helper loaded: form_helper
INFO - 2018-01-31 16:26:44 --> Form Validation Class Initialized
INFO - 2018-01-31 16:26:44 --> Controller Class Initialized
INFO - 2018-01-31 16:26:44 --> Model Class Initialized
INFO - 2018-01-31 16:26:44 --> Helper loaded: inflector_helper
DEBUG - 2018-01-31 16:26:44 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-31 16:26:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-31 16:26:44 --> Model Class Initialized
INFO - 2018-01-31 16:26:44 --> Model Class Initialized
INFO - 2018-01-31 16:26:44 --> Model Class Initialized
INFO - 2018-01-31 16:26:44 --> Model Class Initialized
INFO - 2018-01-31 16:26:44 --> Model Class Initialized
INFO - 2018-01-31 16:26:44 --> Model Class Initialized
INFO - 2018-01-31 16:26:44 --> Model Class Initialized
INFO - 2018-01-31 16:26:44 --> Model Class Initialized
INFO - 2018-01-31 16:26:44 --> Model Class Initialized
INFO - 2018-01-31 16:26:44 --> Model Class Initialized
INFO - 2018-01-31 16:26:44 --> Model Class Initialized
INFO - 2018-01-31 16:26:44 --> Language file loaded: language/english/message_lang.php
INFO - 2018-01-31 10:57:22 --> Config Class Initialized
INFO - 2018-01-31 10:57:22 --> Hooks Class Initialized
DEBUG - 2018-01-31 10:57:22 --> UTF-8 Support Enabled
INFO - 2018-01-31 10:57:22 --> Utf8 Class Initialized
INFO - 2018-01-31 10:57:22 --> URI Class Initialized
INFO - 2018-01-31 10:57:22 --> Router Class Initialized
INFO - 2018-01-31 10:57:22 --> Output Class Initialized
INFO - 2018-01-31 10:57:22 --> Security Class Initialized
DEBUG - 2018-01-31 10:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 10:57:22 --> Input Class Initialized
INFO - 2018-01-31 10:57:22 --> Language Class Initialized
INFO - 2018-01-31 10:57:22 --> Language Class Initialized
INFO - 2018-01-31 10:57:22 --> Config Class Initialized
INFO - 2018-01-31 10:57:22 --> Loader Class Initialized
INFO - 2018-01-31 16:27:22 --> Helper loaded: url_helper
INFO - 2018-01-31 16:27:22 --> Helper loaded: notification_helper
INFO - 2018-01-31 16:27:22 --> Helper loaded: settings_helper
INFO - 2018-01-31 16:27:22 --> Helper loaded: permission_helper
INFO - 2018-01-31 16:27:22 --> Helper loaded: users_helper
INFO - 2018-01-31 16:27:22 --> Database Driver Class Initialized
DEBUG - 2018-01-31 16:27:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 16:27:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 16:27:22 --> Helper loaded: form_helper
INFO - 2018-01-31 16:27:22 --> Form Validation Class Initialized
INFO - 2018-01-31 16:27:22 --> Controller Class Initialized
INFO - 2018-01-31 16:27:22 --> Model Class Initialized
INFO - 2018-01-31 16:27:22 --> Helper loaded: inflector_helper
DEBUG - 2018-01-31 16:27:22 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-31 16:27:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-31 16:27:22 --> Model Class Initialized
INFO - 2018-01-31 16:27:22 --> Model Class Initialized
INFO - 2018-01-31 16:27:22 --> Model Class Initialized
INFO - 2018-01-31 16:27:22 --> Model Class Initialized
INFO - 2018-01-31 16:27:22 --> Model Class Initialized
INFO - 2018-01-31 16:27:22 --> Model Class Initialized
INFO - 2018-01-31 16:27:22 --> Model Class Initialized
INFO - 2018-01-31 16:27:22 --> Model Class Initialized
INFO - 2018-01-31 16:27:22 --> Model Class Initialized
INFO - 2018-01-31 16:27:22 --> Model Class Initialized
INFO - 2018-01-31 16:27:22 --> Model Class Initialized
INFO - 2018-01-31 16:27:22 --> Language file loaded: language/english/message_lang.php
INFO - 2018-01-31 11:00:37 --> Config Class Initialized
INFO - 2018-01-31 11:00:37 --> Hooks Class Initialized
DEBUG - 2018-01-31 11:00:37 --> UTF-8 Support Enabled
INFO - 2018-01-31 11:00:37 --> Utf8 Class Initialized
INFO - 2018-01-31 11:00:37 --> URI Class Initialized
INFO - 2018-01-31 11:00:37 --> Router Class Initialized
INFO - 2018-01-31 11:00:37 --> Output Class Initialized
INFO - 2018-01-31 11:00:37 --> Security Class Initialized
DEBUG - 2018-01-31 11:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 11:00:37 --> Input Class Initialized
INFO - 2018-01-31 11:00:37 --> Language Class Initialized
INFO - 2018-01-31 11:00:37 --> Language Class Initialized
INFO - 2018-01-31 11:00:37 --> Config Class Initialized
INFO - 2018-01-31 11:00:37 --> Loader Class Initialized
INFO - 2018-01-31 16:30:37 --> Helper loaded: url_helper
INFO - 2018-01-31 16:30:37 --> Helper loaded: notification_helper
INFO - 2018-01-31 16:30:37 --> Helper loaded: settings_helper
INFO - 2018-01-31 16:30:37 --> Helper loaded: permission_helper
INFO - 2018-01-31 16:30:37 --> Helper loaded: users_helper
INFO - 2018-01-31 16:30:37 --> Database Driver Class Initialized
DEBUG - 2018-01-31 16:30:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 16:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 16:30:37 --> Helper loaded: form_helper
INFO - 2018-01-31 16:30:37 --> Form Validation Class Initialized
INFO - 2018-01-31 16:30:37 --> Controller Class Initialized
INFO - 2018-01-31 16:30:37 --> Model Class Initialized
INFO - 2018-01-31 16:30:37 --> Helper loaded: inflector_helper
DEBUG - 2018-01-31 16:30:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-31 16:30:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-31 16:30:37 --> Model Class Initialized
INFO - 2018-01-31 16:30:37 --> Model Class Initialized
INFO - 2018-01-31 16:30:37 --> Model Class Initialized
INFO - 2018-01-31 16:30:37 --> Model Class Initialized
INFO - 2018-01-31 16:30:37 --> Model Class Initialized
INFO - 2018-01-31 16:30:37 --> Model Class Initialized
INFO - 2018-01-31 16:30:37 --> Model Class Initialized
INFO - 2018-01-31 16:30:37 --> Model Class Initialized
INFO - 2018-01-31 16:30:37 --> Model Class Initialized
INFO - 2018-01-31 16:30:37 --> Model Class Initialized
INFO - 2018-01-31 16:30:37 --> Model Class Initialized
INFO - 2018-01-31 16:30:37 --> Language file loaded: language/english/message_lang.php
INFO - 2018-01-31 16:30:37 --> Final output sent to browser
DEBUG - 2018-01-31 16:30:37 --> Total execution time: 0.1214
INFO - 2018-01-31 11:01:35 --> Config Class Initialized
INFO - 2018-01-31 11:01:35 --> Hooks Class Initialized
DEBUG - 2018-01-31 11:01:35 --> UTF-8 Support Enabled
INFO - 2018-01-31 11:01:35 --> Utf8 Class Initialized
INFO - 2018-01-31 11:01:35 --> URI Class Initialized
INFO - 2018-01-31 11:01:35 --> Router Class Initialized
INFO - 2018-01-31 11:01:35 --> Output Class Initialized
INFO - 2018-01-31 11:01:35 --> Security Class Initialized
DEBUG - 2018-01-31 11:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 11:01:35 --> Input Class Initialized
INFO - 2018-01-31 11:01:35 --> Language Class Initialized
INFO - 2018-01-31 11:01:35 --> Language Class Initialized
INFO - 2018-01-31 11:01:35 --> Config Class Initialized
INFO - 2018-01-31 11:01:35 --> Loader Class Initialized
INFO - 2018-01-31 16:31:35 --> Helper loaded: url_helper
INFO - 2018-01-31 16:31:35 --> Helper loaded: notification_helper
INFO - 2018-01-31 16:31:35 --> Helper loaded: settings_helper
INFO - 2018-01-31 16:31:35 --> Helper loaded: permission_helper
INFO - 2018-01-31 16:31:35 --> Helper loaded: users_helper
INFO - 2018-01-31 16:31:35 --> Database Driver Class Initialized
DEBUG - 2018-01-31 16:31:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 16:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 16:31:35 --> Helper loaded: form_helper
INFO - 2018-01-31 16:31:35 --> Form Validation Class Initialized
INFO - 2018-01-31 16:31:35 --> Controller Class Initialized
INFO - 2018-01-31 16:31:35 --> Model Class Initialized
INFO - 2018-01-31 16:31:35 --> Helper loaded: inflector_helper
DEBUG - 2018-01-31 16:31:35 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-31 16:31:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-31 16:31:35 --> Model Class Initialized
INFO - 2018-01-31 16:31:35 --> Model Class Initialized
INFO - 2018-01-31 16:31:35 --> Model Class Initialized
INFO - 2018-01-31 16:31:35 --> Model Class Initialized
INFO - 2018-01-31 16:31:35 --> Model Class Initialized
INFO - 2018-01-31 16:31:35 --> Model Class Initialized
INFO - 2018-01-31 16:31:35 --> Model Class Initialized
INFO - 2018-01-31 16:31:35 --> Model Class Initialized
INFO - 2018-01-31 16:31:35 --> Model Class Initialized
INFO - 2018-01-31 16:31:35 --> Model Class Initialized
INFO - 2018-01-31 16:31:35 --> Model Class Initialized
INFO - 2018-01-31 16:31:35 --> Language file loaded: language/english/message_lang.php
INFO - 2018-01-31 16:31:35 --> Final output sent to browser
DEBUG - 2018-01-31 16:31:35 --> Total execution time: 0.0809
INFO - 2018-01-31 11:01:47 --> Config Class Initialized
INFO - 2018-01-31 11:01:47 --> Hooks Class Initialized
DEBUG - 2018-01-31 11:01:47 --> UTF-8 Support Enabled
INFO - 2018-01-31 11:01:47 --> Utf8 Class Initialized
INFO - 2018-01-31 11:01:47 --> URI Class Initialized
INFO - 2018-01-31 11:01:47 --> Router Class Initialized
INFO - 2018-01-31 11:01:47 --> Output Class Initialized
INFO - 2018-01-31 11:01:47 --> Security Class Initialized
DEBUG - 2018-01-31 11:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 11:01:47 --> Input Class Initialized
INFO - 2018-01-31 11:01:47 --> Language Class Initialized
INFO - 2018-01-31 11:01:47 --> Language Class Initialized
INFO - 2018-01-31 11:01:47 --> Config Class Initialized
INFO - 2018-01-31 11:01:47 --> Loader Class Initialized
INFO - 2018-01-31 16:31:47 --> Helper loaded: url_helper
INFO - 2018-01-31 16:31:47 --> Helper loaded: notification_helper
INFO - 2018-01-31 16:31:47 --> Helper loaded: settings_helper
INFO - 2018-01-31 16:31:47 --> Helper loaded: permission_helper
INFO - 2018-01-31 16:31:47 --> Helper loaded: users_helper
INFO - 2018-01-31 16:31:47 --> Database Driver Class Initialized
DEBUG - 2018-01-31 16:31:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 16:31:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 16:31:47 --> Helper loaded: form_helper
INFO - 2018-01-31 16:31:47 --> Form Validation Class Initialized
INFO - 2018-01-31 16:31:47 --> Controller Class Initialized
INFO - 2018-01-31 16:31:47 --> Model Class Initialized
INFO - 2018-01-31 16:31:47 --> Helper loaded: inflector_helper
DEBUG - 2018-01-31 16:31:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-31 16:31:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-31 16:31:47 --> Model Class Initialized
INFO - 2018-01-31 16:31:47 --> Model Class Initialized
INFO - 2018-01-31 16:31:47 --> Model Class Initialized
INFO - 2018-01-31 16:31:47 --> Model Class Initialized
INFO - 2018-01-31 16:31:47 --> Model Class Initialized
INFO - 2018-01-31 16:31:47 --> Model Class Initialized
INFO - 2018-01-31 16:31:47 --> Model Class Initialized
INFO - 2018-01-31 16:31:47 --> Model Class Initialized
INFO - 2018-01-31 16:31:47 --> Model Class Initialized
INFO - 2018-01-31 16:31:47 --> Model Class Initialized
INFO - 2018-01-31 16:31:47 --> Model Class Initialized
INFO - 2018-01-31 16:31:47 --> Language file loaded: language/english/message_lang.php
INFO - 2018-01-31 16:31:47 --> Final output sent to browser
DEBUG - 2018-01-31 16:31:47 --> Total execution time: 0.0957
INFO - 2018-01-31 11:05:59 --> Config Class Initialized
INFO - 2018-01-31 11:05:59 --> Hooks Class Initialized
DEBUG - 2018-01-31 11:05:59 --> UTF-8 Support Enabled
INFO - 2018-01-31 11:05:59 --> Utf8 Class Initialized
INFO - 2018-01-31 11:05:59 --> URI Class Initialized
INFO - 2018-01-31 11:05:59 --> Router Class Initialized
INFO - 2018-01-31 11:05:59 --> Output Class Initialized
INFO - 2018-01-31 11:05:59 --> Security Class Initialized
DEBUG - 2018-01-31 11:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 11:05:59 --> Input Class Initialized
INFO - 2018-01-31 11:05:59 --> Language Class Initialized
INFO - 2018-01-31 11:05:59 --> Language Class Initialized
INFO - 2018-01-31 11:05:59 --> Config Class Initialized
INFO - 2018-01-31 11:05:59 --> Loader Class Initialized
INFO - 2018-01-31 16:35:59 --> Helper loaded: url_helper
INFO - 2018-01-31 16:35:59 --> Helper loaded: notification_helper
INFO - 2018-01-31 16:35:59 --> Helper loaded: settings_helper
INFO - 2018-01-31 16:35:59 --> Helper loaded: permission_helper
INFO - 2018-01-31 16:35:59 --> Helper loaded: users_helper
INFO - 2018-01-31 16:35:59 --> Database Driver Class Initialized
DEBUG - 2018-01-31 16:35:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 16:35:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 16:35:59 --> Helper loaded: form_helper
INFO - 2018-01-31 16:35:59 --> Form Validation Class Initialized
INFO - 2018-01-31 16:35:59 --> Controller Class Initialized
INFO - 2018-01-31 16:35:59 --> Model Class Initialized
INFO - 2018-01-31 16:35:59 --> Helper loaded: inflector_helper
DEBUG - 2018-01-31 16:35:59 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-31 16:35:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-31 16:35:59 --> Model Class Initialized
INFO - 2018-01-31 16:35:59 --> Model Class Initialized
INFO - 2018-01-31 16:35:59 --> Model Class Initialized
INFO - 2018-01-31 16:35:59 --> Model Class Initialized
INFO - 2018-01-31 16:35:59 --> Model Class Initialized
INFO - 2018-01-31 16:35:59 --> Model Class Initialized
INFO - 2018-01-31 16:35:59 --> Model Class Initialized
INFO - 2018-01-31 16:35:59 --> Model Class Initialized
INFO - 2018-01-31 16:35:59 --> Model Class Initialized
INFO - 2018-01-31 16:35:59 --> Model Class Initialized
INFO - 2018-01-31 16:35:59 --> Model Class Initialized
INFO - 2018-01-31 16:35:59 --> Language file loaded: language/english/message_lang.php
INFO - 2018-01-31 16:35:59 --> Model Class Initialized
INFO - 2018-01-31 16:35:59 --> Final output sent to browser
DEBUG - 2018-01-31 16:35:59 --> Total execution time: 0.1325
INFO - 2018-01-31 11:10:00 --> Config Class Initialized
INFO - 2018-01-31 11:10:00 --> Hooks Class Initialized
DEBUG - 2018-01-31 11:10:00 --> UTF-8 Support Enabled
INFO - 2018-01-31 11:10:00 --> Utf8 Class Initialized
INFO - 2018-01-31 11:10:00 --> URI Class Initialized
INFO - 2018-01-31 11:10:00 --> Router Class Initialized
INFO - 2018-01-31 11:10:00 --> Output Class Initialized
INFO - 2018-01-31 11:10:00 --> Security Class Initialized
DEBUG - 2018-01-31 11:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 11:10:00 --> Input Class Initialized
INFO - 2018-01-31 11:10:00 --> Language Class Initialized
INFO - 2018-01-31 11:10:00 --> Language Class Initialized
INFO - 2018-01-31 11:10:00 --> Config Class Initialized
INFO - 2018-01-31 11:10:00 --> Loader Class Initialized
INFO - 2018-01-31 16:40:00 --> Helper loaded: url_helper
INFO - 2018-01-31 16:40:00 --> Helper loaded: notification_helper
INFO - 2018-01-31 16:40:00 --> Helper loaded: settings_helper
INFO - 2018-01-31 16:40:00 --> Helper loaded: permission_helper
INFO - 2018-01-31 16:40:00 --> Helper loaded: users_helper
INFO - 2018-01-31 16:40:00 --> Database Driver Class Initialized
DEBUG - 2018-01-31 16:40:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 16:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 16:40:00 --> Helper loaded: form_helper
INFO - 2018-01-31 16:40:00 --> Form Validation Class Initialized
INFO - 2018-01-31 16:40:00 --> Controller Class Initialized
INFO - 2018-01-31 16:40:00 --> Model Class Initialized
INFO - 2018-01-31 16:40:00 --> Helper loaded: inflector_helper
INFO - 2018-01-31 16:40:00 --> Model Class Initialized
INFO - 2018-01-31 16:40:00 --> Model Class Initialized
INFO - 2018-01-31 16:40:00 --> Model Class Initialized
INFO - 2018-01-31 16:40:00 --> Final output sent to browser
DEBUG - 2018-01-31 16:40:00 --> Total execution time: 0.1061
INFO - 2018-01-31 11:10:00 --> Config Class Initialized
INFO - 2018-01-31 11:10:00 --> Hooks Class Initialized
DEBUG - 2018-01-31 11:10:00 --> UTF-8 Support Enabled
INFO - 2018-01-31 11:10:00 --> Utf8 Class Initialized
INFO - 2018-01-31 11:10:00 --> URI Class Initialized
INFO - 2018-01-31 11:10:00 --> Router Class Initialized
INFO - 2018-01-31 11:10:00 --> Output Class Initialized
INFO - 2018-01-31 11:10:00 --> Security Class Initialized
DEBUG - 2018-01-31 11:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 11:10:00 --> Input Class Initialized
INFO - 2018-01-31 11:10:00 --> Language Class Initialized
INFO - 2018-01-31 11:10:00 --> Language Class Initialized
INFO - 2018-01-31 11:10:00 --> Config Class Initialized
INFO - 2018-01-31 11:10:00 --> Loader Class Initialized
INFO - 2018-01-31 16:40:00 --> Helper loaded: url_helper
INFO - 2018-01-31 16:40:00 --> Helper loaded: notification_helper
INFO - 2018-01-31 16:40:00 --> Helper loaded: settings_helper
INFO - 2018-01-31 16:40:00 --> Helper loaded: permission_helper
INFO - 2018-01-31 16:40:00 --> Helper loaded: users_helper
INFO - 2018-01-31 16:40:00 --> Database Driver Class Initialized
DEBUG - 2018-01-31 16:40:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 16:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 16:40:00 --> Helper loaded: form_helper
INFO - 2018-01-31 16:40:00 --> Form Validation Class Initialized
INFO - 2018-01-31 16:40:00 --> Controller Class Initialized
INFO - 2018-01-31 16:40:00 --> Model Class Initialized
INFO - 2018-01-31 16:40:00 --> Helper loaded: inflector_helper
INFO - 2018-01-31 16:40:00 --> Model Class Initialized
INFO - 2018-01-31 16:40:00 --> Model Class Initialized
INFO - 2018-01-31 16:40:00 --> Model Class Initialized
INFO - 2018-01-31 16:40:00 --> Final output sent to browser
DEBUG - 2018-01-31 16:40:00 --> Total execution time: 0.1031
INFO - 2018-01-31 11:10:00 --> Config Class Initialized
INFO - 2018-01-31 11:10:00 --> Hooks Class Initialized
DEBUG - 2018-01-31 11:10:00 --> UTF-8 Support Enabled
INFO - 2018-01-31 11:10:00 --> Utf8 Class Initialized
INFO - 2018-01-31 11:10:00 --> URI Class Initialized
INFO - 2018-01-31 11:10:00 --> Router Class Initialized
INFO - 2018-01-31 11:10:00 --> Output Class Initialized
INFO - 2018-01-31 11:10:00 --> Security Class Initialized
DEBUG - 2018-01-31 11:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 11:10:00 --> Input Class Initialized
INFO - 2018-01-31 11:10:00 --> Language Class Initialized
INFO - 2018-01-31 11:10:00 --> Language Class Initialized
INFO - 2018-01-31 11:10:00 --> Config Class Initialized
INFO - 2018-01-31 11:10:00 --> Loader Class Initialized
INFO - 2018-01-31 16:40:00 --> Helper loaded: url_helper
INFO - 2018-01-31 16:40:00 --> Helper loaded: notification_helper
INFO - 2018-01-31 16:40:00 --> Helper loaded: settings_helper
INFO - 2018-01-31 16:40:00 --> Helper loaded: permission_helper
INFO - 2018-01-31 16:40:00 --> Helper loaded: users_helper
INFO - 2018-01-31 16:40:00 --> Database Driver Class Initialized
DEBUG - 2018-01-31 16:40:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 16:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 16:40:00 --> Helper loaded: form_helper
INFO - 2018-01-31 16:40:00 --> Form Validation Class Initialized
INFO - 2018-01-31 16:40:00 --> Controller Class Initialized
INFO - 2018-01-31 16:40:00 --> Model Class Initialized
INFO - 2018-01-31 16:40:00 --> Helper loaded: inflector_helper
INFO - 2018-01-31 16:40:00 --> Model Class Initialized
INFO - 2018-01-31 16:40:00 --> Model Class Initialized
INFO - 2018-01-31 16:40:00 --> Model Class Initialized
INFO - 2018-01-31 16:40:00 --> Final output sent to browser
DEBUG - 2018-01-31 16:40:00 --> Total execution time: 0.1063
INFO - 2018-01-31 11:10:07 --> Config Class Initialized
INFO - 2018-01-31 11:10:07 --> Hooks Class Initialized
DEBUG - 2018-01-31 11:10:07 --> UTF-8 Support Enabled
INFO - 2018-01-31 11:10:07 --> Utf8 Class Initialized
INFO - 2018-01-31 11:10:07 --> URI Class Initialized
INFO - 2018-01-31 11:10:07 --> Router Class Initialized
INFO - 2018-01-31 11:10:07 --> Output Class Initialized
INFO - 2018-01-31 11:10:07 --> Security Class Initialized
DEBUG - 2018-01-31 11:10:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 11:10:07 --> Input Class Initialized
INFO - 2018-01-31 11:10:07 --> Language Class Initialized
INFO - 2018-01-31 11:10:07 --> Language Class Initialized
INFO - 2018-01-31 11:10:07 --> Config Class Initialized
INFO - 2018-01-31 11:10:07 --> Loader Class Initialized
INFO - 2018-01-31 16:40:07 --> Helper loaded: url_helper
INFO - 2018-01-31 16:40:07 --> Helper loaded: notification_helper
INFO - 2018-01-31 16:40:07 --> Helper loaded: settings_helper
INFO - 2018-01-31 16:40:07 --> Helper loaded: permission_helper
INFO - 2018-01-31 16:40:07 --> Helper loaded: users_helper
INFO - 2018-01-31 16:40:07 --> Database Driver Class Initialized
DEBUG - 2018-01-31 16:40:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 16:40:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 16:40:07 --> Helper loaded: form_helper
INFO - 2018-01-31 16:40:07 --> Form Validation Class Initialized
INFO - 2018-01-31 16:40:07 --> Controller Class Initialized
INFO - 2018-01-31 16:40:07 --> Model Class Initialized
INFO - 2018-01-31 16:40:07 --> Helper loaded: inflector_helper
DEBUG - 2018-01-31 16:40:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-31 16:40:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-31 16:40:07 --> Model Class Initialized
INFO - 2018-01-31 16:40:07 --> Model Class Initialized
INFO - 2018-01-31 16:40:07 --> Model Class Initialized
INFO - 2018-01-31 16:40:07 --> Model Class Initialized
INFO - 2018-01-31 16:40:07 --> Model Class Initialized
INFO - 2018-01-31 16:40:07 --> Model Class Initialized
INFO - 2018-01-31 16:40:07 --> Model Class Initialized
INFO - 2018-01-31 16:40:07 --> Model Class Initialized
INFO - 2018-01-31 16:40:07 --> Model Class Initialized
INFO - 2018-01-31 16:40:07 --> Model Class Initialized
INFO - 2018-01-31 16:40:07 --> Model Class Initialized
INFO - 2018-01-31 16:40:07 --> Language file loaded: language/english/message_lang.php
INFO - 2018-01-31 16:40:07 --> Model Class Initialized
INFO - 2018-01-31 16:40:07 --> Final output sent to browser
DEBUG - 2018-01-31 16:40:07 --> Total execution time: 0.1260
INFO - 2018-01-31 11:11:09 --> Config Class Initialized
INFO - 2018-01-31 11:11:09 --> Hooks Class Initialized
DEBUG - 2018-01-31 11:11:09 --> UTF-8 Support Enabled
INFO - 2018-01-31 11:11:09 --> Utf8 Class Initialized
INFO - 2018-01-31 11:11:09 --> URI Class Initialized
INFO - 2018-01-31 11:11:09 --> Router Class Initialized
INFO - 2018-01-31 11:11:09 --> Output Class Initialized
INFO - 2018-01-31 11:11:09 --> Security Class Initialized
DEBUG - 2018-01-31 11:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 11:11:09 --> Input Class Initialized
INFO - 2018-01-31 11:11:09 --> Language Class Initialized
INFO - 2018-01-31 11:11:09 --> Language Class Initialized
INFO - 2018-01-31 11:11:09 --> Config Class Initialized
INFO - 2018-01-31 11:11:09 --> Loader Class Initialized
INFO - 2018-01-31 16:41:09 --> Helper loaded: url_helper
INFO - 2018-01-31 16:41:09 --> Helper loaded: notification_helper
INFO - 2018-01-31 16:41:09 --> Helper loaded: settings_helper
INFO - 2018-01-31 16:41:09 --> Helper loaded: permission_helper
INFO - 2018-01-31 16:41:09 --> Helper loaded: users_helper
INFO - 2018-01-31 16:41:09 --> Database Driver Class Initialized
DEBUG - 2018-01-31 16:41:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 16:41:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 16:41:09 --> Helper loaded: form_helper
INFO - 2018-01-31 16:41:09 --> Form Validation Class Initialized
INFO - 2018-01-31 16:41:09 --> Controller Class Initialized
INFO - 2018-01-31 16:41:09 --> Model Class Initialized
INFO - 2018-01-31 16:41:09 --> Helper loaded: inflector_helper
DEBUG - 2018-01-31 16:41:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-31 16:41:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-31 16:41:09 --> Model Class Initialized
INFO - 2018-01-31 16:41:10 --> Model Class Initialized
INFO - 2018-01-31 16:41:10 --> Model Class Initialized
INFO - 2018-01-31 16:41:10 --> Model Class Initialized
INFO - 2018-01-31 16:41:10 --> Model Class Initialized
INFO - 2018-01-31 16:41:10 --> Model Class Initialized
INFO - 2018-01-31 16:41:10 --> Model Class Initialized
INFO - 2018-01-31 16:41:10 --> Model Class Initialized
INFO - 2018-01-31 16:41:10 --> Model Class Initialized
INFO - 2018-01-31 16:41:10 --> Model Class Initialized
INFO - 2018-01-31 16:41:10 --> Model Class Initialized
INFO - 2018-01-31 16:41:10 --> Language file loaded: language/english/message_lang.php
INFO - 2018-01-31 16:41:10 --> Model Class Initialized
INFO - 2018-01-31 16:41:10 --> Final output sent to browser
DEBUG - 2018-01-31 16:41:10 --> Total execution time: 0.1346
INFO - 2018-01-31 11:17:42 --> Config Class Initialized
INFO - 2018-01-31 11:17:42 --> Hooks Class Initialized
DEBUG - 2018-01-31 11:17:42 --> UTF-8 Support Enabled
INFO - 2018-01-31 11:17:42 --> Utf8 Class Initialized
INFO - 2018-01-31 11:17:42 --> URI Class Initialized
INFO - 2018-01-31 11:17:42 --> Router Class Initialized
INFO - 2018-01-31 11:17:42 --> Output Class Initialized
INFO - 2018-01-31 11:17:42 --> Security Class Initialized
DEBUG - 2018-01-31 11:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 11:17:42 --> Input Class Initialized
INFO - 2018-01-31 11:17:42 --> Language Class Initialized
INFO - 2018-01-31 11:17:42 --> Language Class Initialized
INFO - 2018-01-31 11:17:42 --> Config Class Initialized
INFO - 2018-01-31 11:17:42 --> Loader Class Initialized
INFO - 2018-01-31 16:47:42 --> Helper loaded: url_helper
INFO - 2018-01-31 16:47:42 --> Helper loaded: notification_helper
INFO - 2018-01-31 16:47:42 --> Helper loaded: settings_helper
INFO - 2018-01-31 16:47:42 --> Helper loaded: permission_helper
INFO - 2018-01-31 16:47:42 --> Helper loaded: users_helper
INFO - 2018-01-31 16:47:42 --> Database Driver Class Initialized
DEBUG - 2018-01-31 16:47:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 16:47:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 16:47:42 --> Helper loaded: form_helper
INFO - 2018-01-31 16:47:42 --> Form Validation Class Initialized
INFO - 2018-01-31 16:47:42 --> Controller Class Initialized
INFO - 2018-01-31 16:47:42 --> Model Class Initialized
INFO - 2018-01-31 16:47:42 --> Helper loaded: inflector_helper
INFO - 2018-01-31 16:47:42 --> Model Class Initialized
INFO - 2018-01-31 16:47:42 --> Model Class Initialized
INFO - 2018-01-31 16:47:42 --> Model Class Initialized
INFO - 2018-01-31 16:47:42 --> Final output sent to browser
DEBUG - 2018-01-31 16:47:42 --> Total execution time: 0.0956
INFO - 2018-01-31 11:17:43 --> Config Class Initialized
INFO - 2018-01-31 11:17:43 --> Hooks Class Initialized
DEBUG - 2018-01-31 11:17:43 --> UTF-8 Support Enabled
INFO - 2018-01-31 11:17:43 --> Utf8 Class Initialized
INFO - 2018-01-31 11:17:43 --> URI Class Initialized
INFO - 2018-01-31 11:17:43 --> Router Class Initialized
INFO - 2018-01-31 11:17:43 --> Output Class Initialized
INFO - 2018-01-31 11:17:43 --> Security Class Initialized
DEBUG - 2018-01-31 11:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 11:17:43 --> Input Class Initialized
INFO - 2018-01-31 11:17:43 --> Language Class Initialized
INFO - 2018-01-31 11:17:43 --> Language Class Initialized
INFO - 2018-01-31 11:17:43 --> Config Class Initialized
INFO - 2018-01-31 11:17:43 --> Loader Class Initialized
INFO - 2018-01-31 16:47:43 --> Helper loaded: url_helper
INFO - 2018-01-31 16:47:43 --> Helper loaded: notification_helper
INFO - 2018-01-31 16:47:43 --> Helper loaded: settings_helper
INFO - 2018-01-31 16:47:43 --> Helper loaded: permission_helper
INFO - 2018-01-31 16:47:43 --> Helper loaded: users_helper
INFO - 2018-01-31 16:47:43 --> Database Driver Class Initialized
DEBUG - 2018-01-31 16:47:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 16:47:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 16:47:43 --> Helper loaded: form_helper
INFO - 2018-01-31 16:47:43 --> Form Validation Class Initialized
INFO - 2018-01-31 16:47:43 --> Controller Class Initialized
INFO - 2018-01-31 16:47:43 --> Model Class Initialized
INFO - 2018-01-31 16:47:43 --> Helper loaded: inflector_helper
INFO - 2018-01-31 16:47:43 --> Model Class Initialized
INFO - 2018-01-31 16:47:43 --> Model Class Initialized
INFO - 2018-01-31 16:47:43 --> Model Class Initialized
INFO - 2018-01-31 16:47:43 --> Final output sent to browser
DEBUG - 2018-01-31 16:47:43 --> Total execution time: 0.0889
INFO - 2018-01-31 11:17:44 --> Config Class Initialized
INFO - 2018-01-31 11:17:44 --> Hooks Class Initialized
DEBUG - 2018-01-31 11:17:44 --> UTF-8 Support Enabled
INFO - 2018-01-31 11:17:44 --> Utf8 Class Initialized
INFO - 2018-01-31 11:17:44 --> URI Class Initialized
INFO - 2018-01-31 11:17:44 --> Router Class Initialized
INFO - 2018-01-31 11:17:44 --> Output Class Initialized
INFO - 2018-01-31 11:17:44 --> Security Class Initialized
DEBUG - 2018-01-31 11:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 11:17:44 --> Input Class Initialized
INFO - 2018-01-31 11:17:44 --> Language Class Initialized
INFO - 2018-01-31 11:17:44 --> Language Class Initialized
INFO - 2018-01-31 11:17:44 --> Config Class Initialized
INFO - 2018-01-31 11:17:44 --> Loader Class Initialized
INFO - 2018-01-31 16:47:44 --> Helper loaded: url_helper
INFO - 2018-01-31 16:47:44 --> Helper loaded: notification_helper
INFO - 2018-01-31 16:47:44 --> Helper loaded: settings_helper
INFO - 2018-01-31 16:47:44 --> Helper loaded: permission_helper
INFO - 2018-01-31 16:47:44 --> Helper loaded: users_helper
INFO - 2018-01-31 16:47:44 --> Database Driver Class Initialized
DEBUG - 2018-01-31 16:47:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 16:47:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 16:47:44 --> Helper loaded: form_helper
INFO - 2018-01-31 16:47:44 --> Form Validation Class Initialized
INFO - 2018-01-31 16:47:44 --> Controller Class Initialized
INFO - 2018-01-31 16:47:44 --> Model Class Initialized
INFO - 2018-01-31 16:47:44 --> Helper loaded: inflector_helper
INFO - 2018-01-31 16:47:44 --> Model Class Initialized
INFO - 2018-01-31 16:47:44 --> Model Class Initialized
INFO - 2018-01-31 16:47:44 --> Model Class Initialized
INFO - 2018-01-31 16:47:44 --> Final output sent to browser
DEBUG - 2018-01-31 16:47:44 --> Total execution time: 0.0866
INFO - 2018-01-31 11:17:45 --> Config Class Initialized
INFO - 2018-01-31 11:17:45 --> Hooks Class Initialized
DEBUG - 2018-01-31 11:17:45 --> UTF-8 Support Enabled
INFO - 2018-01-31 11:17:45 --> Utf8 Class Initialized
INFO - 2018-01-31 11:17:45 --> URI Class Initialized
INFO - 2018-01-31 11:17:45 --> Router Class Initialized
INFO - 2018-01-31 11:17:45 --> Output Class Initialized
INFO - 2018-01-31 11:17:45 --> Security Class Initialized
DEBUG - 2018-01-31 11:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 11:17:45 --> Input Class Initialized
INFO - 2018-01-31 11:17:45 --> Language Class Initialized
INFO - 2018-01-31 11:17:45 --> Language Class Initialized
INFO - 2018-01-31 11:17:45 --> Config Class Initialized
INFO - 2018-01-31 11:17:45 --> Loader Class Initialized
INFO - 2018-01-31 16:47:45 --> Helper loaded: url_helper
INFO - 2018-01-31 16:47:45 --> Helper loaded: notification_helper
INFO - 2018-01-31 16:47:45 --> Helper loaded: settings_helper
INFO - 2018-01-31 16:47:45 --> Helper loaded: permission_helper
INFO - 2018-01-31 16:47:45 --> Helper loaded: users_helper
INFO - 2018-01-31 16:47:45 --> Database Driver Class Initialized
DEBUG - 2018-01-31 16:47:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 16:47:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 16:47:45 --> Helper loaded: form_helper
INFO - 2018-01-31 16:47:45 --> Form Validation Class Initialized
INFO - 2018-01-31 16:47:45 --> Controller Class Initialized
INFO - 2018-01-31 16:47:45 --> Model Class Initialized
INFO - 2018-01-31 16:47:45 --> Helper loaded: inflector_helper
INFO - 2018-01-31 16:47:45 --> Model Class Initialized
INFO - 2018-01-31 16:47:45 --> Model Class Initialized
INFO - 2018-01-31 16:47:45 --> Model Class Initialized
INFO - 2018-01-31 16:47:45 --> Final output sent to browser
DEBUG - 2018-01-31 16:47:45 --> Total execution time: 0.1051
INFO - 2018-01-31 11:17:47 --> Config Class Initialized
INFO - 2018-01-31 11:17:47 --> Hooks Class Initialized
DEBUG - 2018-01-31 11:17:47 --> UTF-8 Support Enabled
INFO - 2018-01-31 11:17:47 --> Utf8 Class Initialized
INFO - 2018-01-31 11:17:47 --> URI Class Initialized
INFO - 2018-01-31 11:17:47 --> Router Class Initialized
INFO - 2018-01-31 11:17:47 --> Output Class Initialized
INFO - 2018-01-31 11:17:47 --> Security Class Initialized
DEBUG - 2018-01-31 11:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 11:17:47 --> Input Class Initialized
INFO - 2018-01-31 11:17:47 --> Language Class Initialized
INFO - 2018-01-31 11:17:47 --> Language Class Initialized
INFO - 2018-01-31 11:17:47 --> Config Class Initialized
INFO - 2018-01-31 11:17:47 --> Loader Class Initialized
INFO - 2018-01-31 16:47:47 --> Helper loaded: url_helper
INFO - 2018-01-31 16:47:47 --> Helper loaded: notification_helper
INFO - 2018-01-31 16:47:47 --> Helper loaded: settings_helper
INFO - 2018-01-31 16:47:47 --> Helper loaded: permission_helper
INFO - 2018-01-31 16:47:47 --> Helper loaded: users_helper
INFO - 2018-01-31 16:47:47 --> Database Driver Class Initialized
DEBUG - 2018-01-31 16:47:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 16:47:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 16:47:47 --> Helper loaded: form_helper
INFO - 2018-01-31 16:47:47 --> Form Validation Class Initialized
INFO - 2018-01-31 16:47:47 --> Controller Class Initialized
INFO - 2018-01-31 16:47:47 --> Model Class Initialized
INFO - 2018-01-31 16:47:47 --> Helper loaded: inflector_helper
INFO - 2018-01-31 16:47:47 --> Model Class Initialized
INFO - 2018-01-31 16:47:47 --> Model Class Initialized
INFO - 2018-01-31 16:47:47 --> Model Class Initialized
INFO - 2018-01-31 16:47:47 --> Final output sent to browser
DEBUG - 2018-01-31 16:47:47 --> Total execution time: 0.0966
INFO - 2018-01-31 11:25:54 --> Config Class Initialized
INFO - 2018-01-31 11:25:54 --> Hooks Class Initialized
DEBUG - 2018-01-31 11:25:54 --> UTF-8 Support Enabled
INFO - 2018-01-31 11:25:54 --> Utf8 Class Initialized
INFO - 2018-01-31 11:25:54 --> URI Class Initialized
INFO - 2018-01-31 11:25:54 --> Router Class Initialized
INFO - 2018-01-31 11:25:54 --> Output Class Initialized
INFO - 2018-01-31 11:25:54 --> Security Class Initialized
DEBUG - 2018-01-31 11:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 11:25:54 --> Input Class Initialized
INFO - 2018-01-31 11:25:54 --> Language Class Initialized
INFO - 2018-01-31 11:25:54 --> Language Class Initialized
INFO - 2018-01-31 11:25:54 --> Config Class Initialized
INFO - 2018-01-31 11:25:54 --> Loader Class Initialized
INFO - 2018-01-31 16:55:54 --> Helper loaded: url_helper
INFO - 2018-01-31 16:55:54 --> Helper loaded: notification_helper
INFO - 2018-01-31 16:55:54 --> Helper loaded: settings_helper
INFO - 2018-01-31 16:55:54 --> Helper loaded: permission_helper
INFO - 2018-01-31 16:55:54 --> Helper loaded: users_helper
INFO - 2018-01-31 16:55:54 --> Database Driver Class Initialized
DEBUG - 2018-01-31 16:55:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 16:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 16:55:54 --> Helper loaded: form_helper
INFO - 2018-01-31 16:55:54 --> Form Validation Class Initialized
INFO - 2018-01-31 16:55:54 --> Controller Class Initialized
INFO - 2018-01-31 16:55:54 --> Model Class Initialized
INFO - 2018-01-31 16:55:54 --> Helper loaded: inflector_helper
DEBUG - 2018-01-31 16:55:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-31 16:55:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-31 16:55:54 --> Model Class Initialized
INFO - 2018-01-31 16:55:54 --> Model Class Initialized
INFO - 2018-01-31 16:55:54 --> Model Class Initialized
INFO - 2018-01-31 16:55:54 --> Model Class Initialized
INFO - 2018-01-31 16:55:54 --> Model Class Initialized
INFO - 2018-01-31 16:55:54 --> Model Class Initialized
INFO - 2018-01-31 16:55:54 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-01-31 16:55:54 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 771
INFO - 2018-01-31 16:55:54 --> Final output sent to browser
DEBUG - 2018-01-31 16:55:54 --> Total execution time: 0.1100
INFO - 2018-01-31 11:26:10 --> Config Class Initialized
INFO - 2018-01-31 11:26:10 --> Hooks Class Initialized
DEBUG - 2018-01-31 11:26:10 --> UTF-8 Support Enabled
INFO - 2018-01-31 11:26:10 --> Utf8 Class Initialized
INFO - 2018-01-31 11:26:10 --> URI Class Initialized
INFO - 2018-01-31 11:26:10 --> Router Class Initialized
INFO - 2018-01-31 11:26:10 --> Output Class Initialized
INFO - 2018-01-31 11:26:10 --> Security Class Initialized
DEBUG - 2018-01-31 11:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 11:26:10 --> Input Class Initialized
INFO - 2018-01-31 11:26:10 --> Language Class Initialized
INFO - 2018-01-31 11:26:10 --> Language Class Initialized
INFO - 2018-01-31 11:26:10 --> Config Class Initialized
INFO - 2018-01-31 11:26:10 --> Loader Class Initialized
INFO - 2018-01-31 16:56:10 --> Helper loaded: url_helper
INFO - 2018-01-31 16:56:10 --> Helper loaded: notification_helper
INFO - 2018-01-31 16:56:10 --> Helper loaded: settings_helper
INFO - 2018-01-31 16:56:10 --> Helper loaded: permission_helper
INFO - 2018-01-31 16:56:10 --> Helper loaded: users_helper
INFO - 2018-01-31 16:56:10 --> Database Driver Class Initialized
DEBUG - 2018-01-31 16:56:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 16:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 16:56:10 --> Helper loaded: form_helper
INFO - 2018-01-31 16:56:10 --> Form Validation Class Initialized
INFO - 2018-01-31 16:56:10 --> Controller Class Initialized
INFO - 2018-01-31 16:56:10 --> Model Class Initialized
INFO - 2018-01-31 16:56:10 --> Helper loaded: inflector_helper
DEBUG - 2018-01-31 16:56:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-31 16:56:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-31 16:56:10 --> Model Class Initialized
INFO - 2018-01-31 16:56:10 --> Model Class Initialized
INFO - 2018-01-31 16:56:10 --> Model Class Initialized
INFO - 2018-01-31 16:56:10 --> Model Class Initialized
INFO - 2018-01-31 16:56:10 --> Model Class Initialized
INFO - 2018-01-31 16:56:10 --> Model Class Initialized
INFO - 2018-01-31 16:56:10 --> Language file loaded: language/english/message_lang.php
INFO - 2018-01-31 16:56:10 --> Final output sent to browser
DEBUG - 2018-01-31 16:56:10 --> Total execution time: 0.1060
INFO - 2018-01-31 11:37:25 --> Config Class Initialized
INFO - 2018-01-31 11:37:25 --> Hooks Class Initialized
DEBUG - 2018-01-31 11:37:25 --> UTF-8 Support Enabled
INFO - 2018-01-31 11:37:25 --> Utf8 Class Initialized
INFO - 2018-01-31 11:37:25 --> URI Class Initialized
INFO - 2018-01-31 11:37:25 --> Router Class Initialized
INFO - 2018-01-31 11:37:25 --> Output Class Initialized
INFO - 2018-01-31 11:37:25 --> Security Class Initialized
DEBUG - 2018-01-31 11:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 11:37:25 --> Input Class Initialized
INFO - 2018-01-31 11:37:25 --> Language Class Initialized
INFO - 2018-01-31 11:37:25 --> Language Class Initialized
INFO - 2018-01-31 11:37:25 --> Config Class Initialized
INFO - 2018-01-31 11:37:25 --> Loader Class Initialized
INFO - 2018-01-31 17:07:25 --> Helper loaded: url_helper
INFO - 2018-01-31 17:07:25 --> Helper loaded: notification_helper
INFO - 2018-01-31 17:07:25 --> Helper loaded: settings_helper
INFO - 2018-01-31 17:07:25 --> Helper loaded: permission_helper
INFO - 2018-01-31 17:07:25 --> Helper loaded: users_helper
INFO - 2018-01-31 17:07:25 --> Database Driver Class Initialized
DEBUG - 2018-01-31 17:07:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 17:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 17:07:25 --> Helper loaded: form_helper
INFO - 2018-01-31 17:07:25 --> Form Validation Class Initialized
INFO - 2018-01-31 17:07:25 --> Controller Class Initialized
INFO - 2018-01-31 17:07:25 --> Model Class Initialized
INFO - 2018-01-31 17:07:25 --> Helper loaded: inflector_helper
DEBUG - 2018-01-31 17:07:25 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-31 17:07:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-31 17:07:25 --> Model Class Initialized
INFO - 2018-01-31 17:07:25 --> Model Class Initialized
INFO - 2018-01-31 17:07:25 --> Model Class Initialized
INFO - 2018-01-31 17:07:25 --> Model Class Initialized
INFO - 2018-01-31 17:07:25 --> Model Class Initialized
INFO - 2018-01-31 17:07:25 --> Model Class Initialized
INFO - 2018-01-31 17:07:25 --> Model Class Initialized
INFO - 2018-01-31 17:07:25 --> Model Class Initialized
INFO - 2018-01-31 17:07:25 --> Model Class Initialized
INFO - 2018-01-31 17:07:25 --> Model Class Initialized
INFO - 2018-01-31 17:07:25 --> Model Class Initialized
INFO - 2018-01-31 17:07:25 --> Language file loaded: language/english/message_lang.php
INFO - 2018-01-31 17:07:25 --> Model Class Initialized
INFO - 2018-01-31 17:07:25 --> Final output sent to browser
DEBUG - 2018-01-31 17:07:25 --> Total execution time: 0.1314
INFO - 2018-01-31 12:07:14 --> Config Class Initialized
INFO - 2018-01-31 12:07:14 --> Hooks Class Initialized
DEBUG - 2018-01-31 12:07:14 --> UTF-8 Support Enabled
INFO - 2018-01-31 12:07:14 --> Utf8 Class Initialized
INFO - 2018-01-31 12:07:14 --> URI Class Initialized
INFO - 2018-01-31 12:07:14 --> Router Class Initialized
INFO - 2018-01-31 12:07:14 --> Output Class Initialized
INFO - 2018-01-31 12:07:14 --> Security Class Initialized
DEBUG - 2018-01-31 12:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 12:07:14 --> Input Class Initialized
INFO - 2018-01-31 12:07:14 --> Language Class Initialized
INFO - 2018-01-31 12:07:14 --> Language Class Initialized
INFO - 2018-01-31 12:07:14 --> Config Class Initialized
INFO - 2018-01-31 12:07:14 --> Loader Class Initialized
INFO - 2018-01-31 17:37:14 --> Helper loaded: url_helper
INFO - 2018-01-31 17:37:14 --> Helper loaded: notification_helper
INFO - 2018-01-31 17:37:14 --> Helper loaded: settings_helper
INFO - 2018-01-31 17:37:14 --> Helper loaded: permission_helper
INFO - 2018-01-31 17:37:14 --> Helper loaded: users_helper
INFO - 2018-01-31 17:37:14 --> Database Driver Class Initialized
DEBUG - 2018-01-31 17:37:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 17:37:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 17:37:14 --> Helper loaded: form_helper
INFO - 2018-01-31 17:37:14 --> Form Validation Class Initialized
INFO - 2018-01-31 17:37:14 --> Controller Class Initialized
INFO - 2018-01-31 17:37:14 --> Model Class Initialized
INFO - 2018-01-31 17:37:14 --> Helper loaded: inflector_helper
DEBUG - 2018-01-31 17:37:14 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-31 17:37:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-31 17:37:14 --> Model Class Initialized
INFO - 2018-01-31 17:37:14 --> Model Class Initialized
INFO - 2018-01-31 17:37:14 --> Model Class Initialized
INFO - 2018-01-31 17:37:14 --> Model Class Initialized
INFO - 2018-01-31 17:37:14 --> Model Class Initialized
INFO - 2018-01-31 17:37:14 --> Model Class Initialized
INFO - 2018-01-31 17:37:14 --> Model Class Initialized
INFO - 2018-01-31 17:37:14 --> Model Class Initialized
INFO - 2018-01-31 17:37:14 --> Model Class Initialized
INFO - 2018-01-31 17:37:14 --> Model Class Initialized
INFO - 2018-01-31 17:37:14 --> Model Class Initialized
INFO - 2018-01-31 17:37:14 --> Language file loaded: language/english/message_lang.php
INFO - 2018-01-31 17:37:14 --> Model Class Initialized
INFO - 2018-01-31 17:37:14 --> Final output sent to browser
DEBUG - 2018-01-31 17:37:14 --> Total execution time: 0.1330
INFO - 2018-01-31 12:07:24 --> Config Class Initialized
INFO - 2018-01-31 12:07:24 --> Hooks Class Initialized
DEBUG - 2018-01-31 12:07:24 --> UTF-8 Support Enabled
INFO - 2018-01-31 12:07:24 --> Utf8 Class Initialized
INFO - 2018-01-31 12:07:24 --> URI Class Initialized
INFO - 2018-01-31 12:07:24 --> Router Class Initialized
INFO - 2018-01-31 12:07:24 --> Output Class Initialized
INFO - 2018-01-31 12:07:24 --> Security Class Initialized
DEBUG - 2018-01-31 12:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 12:07:24 --> Input Class Initialized
INFO - 2018-01-31 12:07:24 --> Language Class Initialized
INFO - 2018-01-31 12:07:24 --> Language Class Initialized
INFO - 2018-01-31 12:07:24 --> Config Class Initialized
INFO - 2018-01-31 12:07:24 --> Loader Class Initialized
INFO - 2018-01-31 17:37:24 --> Helper loaded: url_helper
INFO - 2018-01-31 17:37:24 --> Helper loaded: notification_helper
INFO - 2018-01-31 17:37:24 --> Helper loaded: settings_helper
INFO - 2018-01-31 17:37:24 --> Helper loaded: permission_helper
INFO - 2018-01-31 17:37:24 --> Helper loaded: users_helper
INFO - 2018-01-31 17:37:24 --> Database Driver Class Initialized
DEBUG - 2018-01-31 17:37:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 17:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 17:37:24 --> Helper loaded: form_helper
INFO - 2018-01-31 17:37:24 --> Form Validation Class Initialized
INFO - 2018-01-31 17:37:24 --> Controller Class Initialized
INFO - 2018-01-31 17:37:24 --> Model Class Initialized
INFO - 2018-01-31 17:37:24 --> Helper loaded: inflector_helper
DEBUG - 2018-01-31 17:37:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-31 17:37:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-31 17:37:24 --> Model Class Initialized
INFO - 2018-01-31 17:37:24 --> Model Class Initialized
INFO - 2018-01-31 17:37:24 --> Model Class Initialized
INFO - 2018-01-31 17:37:24 --> Model Class Initialized
INFO - 2018-01-31 17:37:24 --> Model Class Initialized
INFO - 2018-01-31 17:37:24 --> Model Class Initialized
INFO - 2018-01-31 17:37:24 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-01-31 17:37:24 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 771
INFO - 2018-01-31 17:37:24 --> Final output sent to browser
DEBUG - 2018-01-31 17:37:24 --> Total execution time: 0.0874
INFO - 2018-01-31 12:08:46 --> Config Class Initialized
INFO - 2018-01-31 12:08:46 --> Hooks Class Initialized
DEBUG - 2018-01-31 12:08:47 --> UTF-8 Support Enabled
INFO - 2018-01-31 12:08:47 --> Utf8 Class Initialized
INFO - 2018-01-31 12:08:47 --> URI Class Initialized
INFO - 2018-01-31 12:08:47 --> Router Class Initialized
INFO - 2018-01-31 12:08:47 --> Output Class Initialized
INFO - 2018-01-31 12:08:47 --> Security Class Initialized
DEBUG - 2018-01-31 12:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 12:08:47 --> Input Class Initialized
INFO - 2018-01-31 12:08:47 --> Language Class Initialized
INFO - 2018-01-31 12:08:47 --> Language Class Initialized
INFO - 2018-01-31 12:08:47 --> Config Class Initialized
INFO - 2018-01-31 12:08:47 --> Loader Class Initialized
INFO - 2018-01-31 17:38:47 --> Helper loaded: url_helper
INFO - 2018-01-31 17:38:47 --> Helper loaded: notification_helper
INFO - 2018-01-31 17:38:47 --> Helper loaded: settings_helper
INFO - 2018-01-31 17:38:47 --> Helper loaded: permission_helper
INFO - 2018-01-31 17:38:47 --> Helper loaded: users_helper
INFO - 2018-01-31 17:38:47 --> Database Driver Class Initialized
DEBUG - 2018-01-31 17:38:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 17:38:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 17:38:47 --> Helper loaded: form_helper
INFO - 2018-01-31 17:38:47 --> Form Validation Class Initialized
INFO - 2018-01-31 17:38:47 --> Controller Class Initialized
INFO - 2018-01-31 17:38:47 --> Model Class Initialized
INFO - 2018-01-31 17:38:47 --> Helper loaded: inflector_helper
DEBUG - 2018-01-31 17:38:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-31 17:38:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-31 17:38:47 --> Model Class Initialized
INFO - 2018-01-31 17:38:47 --> Model Class Initialized
INFO - 2018-01-31 17:38:47 --> Model Class Initialized
INFO - 2018-01-31 17:38:47 --> Model Class Initialized
INFO - 2018-01-31 17:38:47 --> Model Class Initialized
INFO - 2018-01-31 17:38:47 --> Model Class Initialized
INFO - 2018-01-31 17:38:47 --> Model Class Initialized
INFO - 2018-01-31 17:38:47 --> Model Class Initialized
INFO - 2018-01-31 17:38:47 --> Model Class Initialized
INFO - 2018-01-31 17:38:47 --> Model Class Initialized
INFO - 2018-01-31 17:38:47 --> Model Class Initialized
INFO - 2018-01-31 17:38:47 --> Language file loaded: language/english/message_lang.php
INFO - 2018-01-31 17:38:47 --> Model Class Initialized
INFO - 2018-01-31 17:38:47 --> Final output sent to browser
DEBUG - 2018-01-31 17:38:47 --> Total execution time: 0.1341
INFO - 2018-01-31 12:08:47 --> Config Class Initialized
INFO - 2018-01-31 12:08:47 --> Hooks Class Initialized
DEBUG - 2018-01-31 12:08:47 --> UTF-8 Support Enabled
INFO - 2018-01-31 12:08:47 --> Utf8 Class Initialized
INFO - 2018-01-31 12:08:47 --> URI Class Initialized
INFO - 2018-01-31 12:08:47 --> Router Class Initialized
INFO - 2018-01-31 12:08:47 --> Output Class Initialized
INFO - 2018-01-31 12:08:47 --> Security Class Initialized
DEBUG - 2018-01-31 12:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 12:08:47 --> Input Class Initialized
INFO - 2018-01-31 12:08:47 --> Language Class Initialized
INFO - 2018-01-31 12:08:47 --> Language Class Initialized
INFO - 2018-01-31 12:08:47 --> Config Class Initialized
INFO - 2018-01-31 12:08:47 --> Loader Class Initialized
INFO - 2018-01-31 17:38:47 --> Helper loaded: url_helper
INFO - 2018-01-31 17:38:47 --> Helper loaded: notification_helper
INFO - 2018-01-31 17:38:47 --> Helper loaded: settings_helper
INFO - 2018-01-31 17:38:47 --> Helper loaded: permission_helper
INFO - 2018-01-31 17:38:47 --> Helper loaded: users_helper
INFO - 2018-01-31 17:38:47 --> Database Driver Class Initialized
DEBUG - 2018-01-31 17:38:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 17:38:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 17:38:47 --> Helper loaded: form_helper
INFO - 2018-01-31 17:38:47 --> Form Validation Class Initialized
INFO - 2018-01-31 17:38:47 --> Controller Class Initialized
INFO - 2018-01-31 17:38:47 --> Model Class Initialized
INFO - 2018-01-31 17:38:47 --> Helper loaded: inflector_helper
DEBUG - 2018-01-31 17:38:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-31 17:38:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-31 17:38:47 --> Model Class Initialized
INFO - 2018-01-31 17:38:47 --> Model Class Initialized
INFO - 2018-01-31 17:38:47 --> Model Class Initialized
INFO - 2018-01-31 17:38:47 --> Model Class Initialized
INFO - 2018-01-31 17:38:47 --> Model Class Initialized
INFO - 2018-01-31 17:38:47 --> Model Class Initialized
INFO - 2018-01-31 17:38:47 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-01-31 17:38:47 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 771
INFO - 2018-01-31 17:38:47 --> Final output sent to browser
DEBUG - 2018-01-31 17:38:47 --> Total execution time: 0.1269
INFO - 2018-01-31 12:11:01 --> Config Class Initialized
INFO - 2018-01-31 12:11:01 --> Hooks Class Initialized
DEBUG - 2018-01-31 12:11:01 --> UTF-8 Support Enabled
INFO - 2018-01-31 12:11:01 --> Utf8 Class Initialized
INFO - 2018-01-31 12:11:01 --> URI Class Initialized
INFO - 2018-01-31 12:11:01 --> Router Class Initialized
INFO - 2018-01-31 12:11:01 --> Output Class Initialized
INFO - 2018-01-31 12:11:01 --> Security Class Initialized
DEBUG - 2018-01-31 12:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-31 12:11:01 --> Input Class Initialized
INFO - 2018-01-31 12:11:01 --> Language Class Initialized
INFO - 2018-01-31 12:11:01 --> Language Class Initialized
INFO - 2018-01-31 12:11:01 --> Config Class Initialized
INFO - 2018-01-31 12:11:01 --> Loader Class Initialized
INFO - 2018-01-31 17:41:01 --> Helper loaded: url_helper
INFO - 2018-01-31 17:41:01 --> Helper loaded: notification_helper
INFO - 2018-01-31 17:41:01 --> Helper loaded: settings_helper
INFO - 2018-01-31 17:41:01 --> Helper loaded: permission_helper
INFO - 2018-01-31 17:41:01 --> Helper loaded: users_helper
INFO - 2018-01-31 17:41:01 --> Database Driver Class Initialized
DEBUG - 2018-01-31 17:41:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-31 17:41:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-31 17:41:01 --> Helper loaded: form_helper
INFO - 2018-01-31 17:41:01 --> Form Validation Class Initialized
INFO - 2018-01-31 17:41:01 --> Controller Class Initialized
INFO - 2018-01-31 17:41:01 --> Model Class Initialized
INFO - 2018-01-31 17:41:01 --> Helper loaded: inflector_helper
DEBUG - 2018-01-31 17:41:01 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-01-31 17:41:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-01-31 17:41:01 --> Model Class Initialized
INFO - 2018-01-31 17:41:01 --> Model Class Initialized
INFO - 2018-01-31 17:41:01 --> Model Class Initialized
INFO - 2018-01-31 17:41:01 --> Model Class Initialized
INFO - 2018-01-31 17:41:01 --> Model Class Initialized
INFO - 2018-01-31 17:41:01 --> Model Class Initialized
INFO - 2018-01-31 17:41:01 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-01-31 17:41:01 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 771
INFO - 2018-01-31 17:41:01 --> Final output sent to browser
DEBUG - 2018-01-31 17:41:01 --> Total execution time: 0.1099
