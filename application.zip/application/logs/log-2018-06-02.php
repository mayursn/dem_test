<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-06-02 00:00:01 --> Helper loaded: url_helper
INFO - 2018-06-02 00:00:01 --> Helper loaded: notification_helper
INFO - 2018-06-02 00:00:01 --> Helper loaded: settings_helper
INFO - 2018-06-02 00:00:01 --> Helper loaded: permission_helper
INFO - 2018-06-02 00:00:01 --> Helper loaded: users_helper
INFO - 2018-06-02 00:00:01 --> Database Driver Class Initialized
DEBUG - 2018-06-02 00:00:01 --> Session: Initialization under CLI aborted.
INFO - 2018-06-02 00:00:01 --> Helper loaded: form_helper
INFO - 2018-06-02 00:00:01 --> Form Validation Class Initialized
INFO - 2018-06-02 00:00:01 --> Controller Class Initialized
INFO - 2018-06-02 00:00:01 --> Model Class Initialized
INFO - 2018-06-02 00:00:01 --> Helper loaded: inflector_helper
DEBUG - 2018-06-02 00:00:01 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-02 00:00:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-02 00:00:01 --> Model Class Initialized
INFO - 2018-06-02 00:00:01 --> Model Class Initialized
INFO - 2018-06-02 00:00:01 --> Model Class Initialized
INFO - 2018-06-02 00:00:01 --> Model Class Initialized
INFO - 2018-06-02 00:00:01 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-02 00:00:01 --> Model Class Initialized
INFO - 2018-06-02 00:00:01 --> Final output sent to browser
DEBUG - 2018-06-02 00:00:01 --> Total execution time: 0.1302
INFO - 2018-06-02 00:00:01 --> Helper loaded: url_helper
INFO - 2018-06-02 00:00:01 --> Helper loaded: notification_helper
INFO - 2018-06-02 00:00:01 --> Helper loaded: settings_helper
INFO - 2018-06-02 00:00:01 --> Helper loaded: permission_helper
INFO - 2018-06-02 00:00:01 --> Helper loaded: users_helper
INFO - 2018-06-02 00:00:01 --> Database Driver Class Initialized
DEBUG - 2018-06-02 00:00:01 --> Session: Initialization under CLI aborted.
INFO - 2018-06-02 00:00:01 --> Helper loaded: form_helper
INFO - 2018-06-02 00:00:01 --> Form Validation Class Initialized
INFO - 2018-06-02 00:00:01 --> Controller Class Initialized
INFO - 2018-06-02 00:00:01 --> Model Class Initialized
INFO - 2018-06-02 00:00:01 --> Helper loaded: inflector_helper
DEBUG - 2018-06-02 00:00:01 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-02 00:00:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-02 00:00:01 --> Model Class Initialized
INFO - 2018-06-02 00:00:01 --> Model Class Initialized
INFO - 2018-06-02 00:00:01 --> Model Class Initialized
INFO - 2018-06-02 00:00:01 --> Model Class Initialized
INFO - 2018-06-02 00:00:01 --> Model Class Initialized
INFO - 2018-06-02 00:00:01 --> Model Class Initialized
INFO - 2018-06-02 00:00:01 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-02 00:00:01 --> Model Class Initialized
INFO - 2018-06-02 00:00:01 --> Final output sent to browser
DEBUG - 2018-06-02 00:00:01 --> Total execution time: 0.1402
INFO - 2018-06-02 03:35:04 --> Config Class Initialized
INFO - 2018-06-02 03:35:04 --> Hooks Class Initialized
DEBUG - 2018-06-02 03:35:04 --> UTF-8 Support Enabled
INFO - 2018-06-02 03:35:04 --> Utf8 Class Initialized
INFO - 2018-06-02 03:35:04 --> URI Class Initialized
DEBUG - 2018-06-02 03:35:04 --> No URI present. Default controller set.
INFO - 2018-06-02 03:35:04 --> Router Class Initialized
INFO - 2018-06-02 03:35:04 --> Output Class Initialized
INFO - 2018-06-02 03:35:04 --> Security Class Initialized
DEBUG - 2018-06-02 03:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-02 03:35:04 --> Input Class Initialized
INFO - 2018-06-02 03:35:04 --> Language Class Initialized
INFO - 2018-06-02 03:35:04 --> Language Class Initialized
INFO - 2018-06-02 03:35:04 --> Config Class Initialized
INFO - 2018-06-02 03:35:04 --> Loader Class Initialized
INFO - 2018-06-02 09:05:04 --> Helper loaded: url_helper
INFO - 2018-06-02 09:05:04 --> Helper loaded: notification_helper
INFO - 2018-06-02 09:05:04 --> Helper loaded: settings_helper
INFO - 2018-06-02 09:05:04 --> Helper loaded: permission_helper
INFO - 2018-06-02 09:05:04 --> Helper loaded: users_helper
INFO - 2018-06-02 09:05:04 --> Database Driver Class Initialized
DEBUG - 2018-06-02 09:05:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-02 09:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-02 09:05:04 --> Helper loaded: form_helper
INFO - 2018-06-02 09:05:04 --> Form Validation Class Initialized
INFO - 2018-06-02 09:05:04 --> Controller Class Initialized
INFO - 2018-06-02 09:05:04 --> Model Class Initialized
INFO - 2018-06-02 09:05:04 --> Helper loaded: inflector_helper
INFO - 2018-06-02 09:05:04 --> Model Class Initialized
DEBUG - 2018-06-02 09:05:04 --> File loaded: /home/pr01004/public_html/application/views/login.php
INFO - 2018-06-02 09:05:04 --> Final output sent to browser
DEBUG - 2018-06-02 09:05:04 --> Total execution time: 0.2155
INFO - 2018-06-02 18:30:02 --> Config Class Initialized
INFO - 2018-06-02 18:30:02 --> Hooks Class Initialized
DEBUG - 2018-06-02 18:30:02 --> UTF-8 Support Enabled
INFO - 2018-06-02 18:30:02 --> Utf8 Class Initialized
INFO - 2018-06-02 18:30:02 --> URI Class Initialized
INFO - 2018-06-02 18:30:02 --> Router Class Initialized
INFO - 2018-06-02 18:30:02 --> Output Class Initialized
INFO - 2018-06-02 18:30:02 --> Security Class Initialized
DEBUG - 2018-06-02 18:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-02 18:30:02 --> Input Class Initialized
INFO - 2018-06-02 18:30:02 --> Config Class Initialized
INFO - 2018-06-02 18:30:02 --> Hooks Class Initialized
DEBUG - 2018-06-02 18:30:02 --> UTF-8 Support Enabled
INFO - 2018-06-02 18:30:02 --> Utf8 Class Initialized
INFO - 2018-06-02 18:30:02 --> URI Class Initialized
INFO - 2018-06-02 18:30:02 --> Language Class Initialized
INFO - 2018-06-02 18:30:02 --> Router Class Initialized
INFO - 2018-06-02 18:30:02 --> Output Class Initialized
INFO - 2018-06-02 18:30:02 --> Security Class Initialized
DEBUG - 2018-06-02 18:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-02 18:30:02 --> Input Class Initialized
INFO - 2018-06-02 18:30:02 --> Language Class Initialized
INFO - 2018-06-02 18:30:02 --> Language Class Initialized
INFO - 2018-06-02 18:30:02 --> Config Class Initialized
INFO - 2018-06-02 18:30:02 --> Loader Class Initialized
INFO - 2018-06-02 18:30:02 --> Language Class Initialized
INFO - 2018-06-02 18:30:02 --> Config Class Initialized
INFO - 2018-06-02 18:30:02 --> Loader Class Initialized
