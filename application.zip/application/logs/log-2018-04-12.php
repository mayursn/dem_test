<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-04-12 17:11:56 --> Config Class Initialized
INFO - 2018-04-12 17:11:56 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:11:56 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:11:56 --> Utf8 Class Initialized
INFO - 2018-04-12 17:11:56 --> URI Class Initialized
INFO - 2018-04-12 17:11:56 --> Router Class Initialized
INFO - 2018-04-12 17:11:56 --> Output Class Initialized
INFO - 2018-04-12 17:11:56 --> Security Class Initialized
DEBUG - 2018-04-12 17:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:11:56 --> Input Class Initialized
INFO - 2018-04-12 17:11:56 --> Language Class Initialized
INFO - 2018-04-12 17:11:57 --> Language Class Initialized
INFO - 2018-04-12 17:11:57 --> Config Class Initialized
INFO - 2018-04-12 17:11:57 --> Loader Class Initialized
INFO - 2018-04-12 22:41:57 --> Helper loaded: url_helper
INFO - 2018-04-12 22:41:57 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:41:57 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:41:57 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:41:57 --> Helper loaded: users_helper
INFO - 2018-04-12 22:41:57 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:41:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:41:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:41:57 --> Helper loaded: form_helper
INFO - 2018-04-12 22:41:57 --> Form Validation Class Initialized
INFO - 2018-04-12 22:41:57 --> Controller Class Initialized
INFO - 2018-04-12 22:41:57 --> Model Class Initialized
INFO - 2018-04-12 22:41:57 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:41:57 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:41:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:41:57 --> Model Class Initialized
INFO - 2018-04-12 22:41:57 --> Model Class Initialized
INFO - 2018-04-12 22:41:57 --> Model Class Initialized
INFO - 2018-04-12 22:41:57 --> Model Class Initialized
INFO - 2018-04-12 22:41:57 --> Model Class Initialized
INFO - 2018-04-12 22:41:57 --> Model Class Initialized
INFO - 2018-04-12 22:41:57 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-12 22:41:57 --> Final output sent to browser
DEBUG - 2018-04-12 22:41:57 --> Total execution time: 0.4027
INFO - 2018-04-12 17:11:58 --> Config Class Initialized
INFO - 2018-04-12 17:11:58 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:11:58 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:11:58 --> Utf8 Class Initialized
INFO - 2018-04-12 17:11:58 --> URI Class Initialized
INFO - 2018-04-12 17:11:58 --> Router Class Initialized
INFO - 2018-04-12 17:11:58 --> Output Class Initialized
INFO - 2018-04-12 17:11:58 --> Security Class Initialized
DEBUG - 2018-04-12 17:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:11:58 --> Input Class Initialized
INFO - 2018-04-12 17:11:58 --> Language Class Initialized
INFO - 2018-04-12 17:11:58 --> Language Class Initialized
INFO - 2018-04-12 17:11:58 --> Config Class Initialized
INFO - 2018-04-12 17:11:58 --> Loader Class Initialized
INFO - 2018-04-12 22:41:58 --> Helper loaded: url_helper
INFO - 2018-04-12 22:41:58 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:41:58 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:41:58 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:41:58 --> Helper loaded: users_helper
INFO - 2018-04-12 22:41:58 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:41:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:41:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:41:58 --> Helper loaded: form_helper
INFO - 2018-04-12 22:41:58 --> Form Validation Class Initialized
INFO - 2018-04-12 22:41:58 --> Controller Class Initialized
INFO - 2018-04-12 22:41:58 --> Model Class Initialized
INFO - 2018-04-12 22:41:58 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:41:58 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:41:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:41:58 --> Model Class Initialized
INFO - 2018-04-12 22:41:58 --> Model Class Initialized
INFO - 2018-04-12 22:41:58 --> Model Class Initialized
INFO - 2018-04-12 22:41:58 --> Model Class Initialized
INFO - 2018-04-12 22:41:58 --> Model Class Initialized
INFO - 2018-04-12 22:41:58 --> Model Class Initialized
INFO - 2018-04-12 22:41:58 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-12 22:41:58 --> Final output sent to browser
DEBUG - 2018-04-12 22:41:58 --> Total execution time: 0.1076
INFO - 2018-04-12 17:12:18 --> Config Class Initialized
INFO - 2018-04-12 17:12:18 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:12:18 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:12:18 --> Utf8 Class Initialized
INFO - 2018-04-12 17:12:18 --> URI Class Initialized
INFO - 2018-04-12 17:12:18 --> Router Class Initialized
INFO - 2018-04-12 17:12:18 --> Output Class Initialized
INFO - 2018-04-12 17:12:18 --> Security Class Initialized
DEBUG - 2018-04-12 17:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:12:18 --> Input Class Initialized
INFO - 2018-04-12 17:12:18 --> Language Class Initialized
INFO - 2018-04-12 17:12:18 --> Language Class Initialized
INFO - 2018-04-12 17:12:18 --> Config Class Initialized
INFO - 2018-04-12 17:12:18 --> Loader Class Initialized
INFO - 2018-04-12 22:42:18 --> Helper loaded: url_helper
INFO - 2018-04-12 22:42:18 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:42:18 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:42:18 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:42:18 --> Helper loaded: users_helper
INFO - 2018-04-12 22:42:18 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:42:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:42:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:42:18 --> Helper loaded: form_helper
INFO - 2018-04-12 22:42:18 --> Form Validation Class Initialized
INFO - 2018-04-12 22:42:18 --> Controller Class Initialized
INFO - 2018-04-12 22:42:18 --> Model Class Initialized
INFO - 2018-04-12 22:42:18 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:42:18 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:42:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:42:18 --> Model Class Initialized
INFO - 2018-04-12 22:42:18 --> Model Class Initialized
INFO - 2018-04-12 22:42:18 --> Model Class Initialized
INFO - 2018-04-12 22:42:18 --> Model Class Initialized
INFO - 2018-04-12 22:42:18 --> Model Class Initialized
INFO - 2018-04-12 22:42:18 --> Model Class Initialized
INFO - 2018-04-12 22:42:18 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-12 22:42:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-12 22:42:18 --> Final output sent to browser
DEBUG - 2018-04-12 22:42:18 --> Total execution time: 0.1340
INFO - 2018-04-12 17:12:19 --> Config Class Initialized
INFO - 2018-04-12 17:12:19 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:12:19 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:12:19 --> Utf8 Class Initialized
INFO - 2018-04-12 17:12:19 --> URI Class Initialized
INFO - 2018-04-12 17:12:19 --> Router Class Initialized
INFO - 2018-04-12 17:12:19 --> Output Class Initialized
INFO - 2018-04-12 17:12:19 --> Security Class Initialized
DEBUG - 2018-04-12 17:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:12:19 --> Input Class Initialized
INFO - 2018-04-12 17:12:19 --> Language Class Initialized
INFO - 2018-04-12 17:12:19 --> Language Class Initialized
INFO - 2018-04-12 17:12:19 --> Config Class Initialized
INFO - 2018-04-12 17:12:19 --> Loader Class Initialized
INFO - 2018-04-12 22:42:19 --> Helper loaded: url_helper
INFO - 2018-04-12 22:42:19 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:42:19 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:42:19 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:42:19 --> Helper loaded: users_helper
INFO - 2018-04-12 22:42:19 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:42:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:42:19 --> Helper loaded: form_helper
INFO - 2018-04-12 22:42:19 --> Form Validation Class Initialized
INFO - 2018-04-12 22:42:19 --> Controller Class Initialized
INFO - 2018-04-12 22:42:19 --> Model Class Initialized
INFO - 2018-04-12 22:42:19 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:42:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:42:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:42:19 --> Model Class Initialized
INFO - 2018-04-12 22:42:19 --> Model Class Initialized
INFO - 2018-04-12 22:42:19 --> Model Class Initialized
INFO - 2018-04-12 22:42:19 --> Model Class Initialized
INFO - 2018-04-12 22:42:19 --> Model Class Initialized
INFO - 2018-04-12 22:42:19 --> Model Class Initialized
INFO - 2018-04-12 22:42:19 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-12 22:42:19 --> Final output sent to browser
DEBUG - 2018-04-12 22:42:19 --> Total execution time: 0.1168
INFO - 2018-04-12 17:12:19 --> Config Class Initialized
INFO - 2018-04-12 17:12:19 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:12:19 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:12:19 --> Utf8 Class Initialized
INFO - 2018-04-12 17:12:19 --> URI Class Initialized
INFO - 2018-04-12 17:12:19 --> Config Class Initialized
INFO - 2018-04-12 17:12:19 --> Hooks Class Initialized
INFO - 2018-04-12 17:12:19 --> Router Class Initialized
DEBUG - 2018-04-12 17:12:19 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:12:19 --> Utf8 Class Initialized
INFO - 2018-04-12 17:12:19 --> URI Class Initialized
INFO - 2018-04-12 17:12:19 --> Output Class Initialized
INFO - 2018-04-12 17:12:19 --> Security Class Initialized
INFO - 2018-04-12 17:12:19 --> Router Class Initialized
DEBUG - 2018-04-12 17:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:12:19 --> Input Class Initialized
INFO - 2018-04-12 17:12:19 --> Output Class Initialized
INFO - 2018-04-12 17:12:19 --> Language Class Initialized
INFO - 2018-04-12 17:12:20 --> Security Class Initialized
DEBUG - 2018-04-12 17:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:12:20 --> Input Class Initialized
INFO - 2018-04-12 17:12:20 --> Language Class Initialized
INFO - 2018-04-12 17:12:20 --> Config Class Initialized
INFO - 2018-04-12 17:12:20 --> Hooks Class Initialized
INFO - 2018-04-12 17:12:20 --> Config Class Initialized
INFO - 2018-04-12 17:12:20 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:12:20 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:12:20 --> Utf8 Class Initialized
DEBUG - 2018-04-12 17:12:20 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:12:20 --> Utf8 Class Initialized
INFO - 2018-04-12 17:12:20 --> URI Class Initialized
INFO - 2018-04-12 17:12:20 --> URI Class Initialized
INFO - 2018-04-12 17:12:20 --> Router Class Initialized
INFO - 2018-04-12 17:12:20 --> Router Class Initialized
INFO - 2018-04-12 17:12:20 --> Output Class Initialized
INFO - 2018-04-12 17:12:20 --> Language Class Initialized
INFO - 2018-04-12 17:12:20 --> Config Class Initialized
INFO - 2018-04-12 17:12:20 --> Loader Class Initialized
INFO - 2018-04-12 17:12:20 --> Security Class Initialized
INFO - 2018-04-12 17:12:20 --> Output Class Initialized
INFO - 2018-04-12 22:42:20 --> Helper loaded: url_helper
DEBUG - 2018-04-12 17:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:12:20 --> Input Class Initialized
INFO - 2018-04-12 22:42:20 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:42:20 --> Helper loaded: settings_helper
INFO - 2018-04-12 17:12:20 --> Language Class Initialized
INFO - 2018-04-12 22:42:20 --> Helper loaded: permission_helper
INFO - 2018-04-12 17:12:20 --> Security Class Initialized
INFO - 2018-04-12 22:42:20 --> Helper loaded: users_helper
DEBUG - 2018-04-12 17:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:12:20 --> Input Class Initialized
INFO - 2018-04-12 17:12:20 --> Language Class Initialized
INFO - 2018-04-12 17:12:20 --> Language Class Initialized
INFO - 2018-04-12 17:12:20 --> Config Class Initialized
INFO - 2018-04-12 17:12:20 --> Loader Class Initialized
INFO - 2018-04-12 22:42:20 --> Helper loaded: url_helper
INFO - 2018-04-12 22:42:20 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:42:20 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:42:20 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:42:20 --> Helper loaded: users_helper
INFO - 2018-04-12 22:42:20 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:42:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:42:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 17:12:20 --> Language Class Initialized
INFO - 2018-04-12 17:12:20 --> Config Class Initialized
INFO - 2018-04-12 17:12:20 --> Loader Class Initialized
INFO - 2018-04-12 22:42:20 --> Helper loaded: url_helper
INFO - 2018-04-12 22:42:20 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:42:20 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:42:20 --> Database Driver Class Initialized
INFO - 2018-04-12 22:42:20 --> Helper loaded: permission_helper
INFO - 2018-04-12 17:12:20 --> Language Class Initialized
INFO - 2018-04-12 17:12:20 --> Config Class Initialized
INFO - 2018-04-12 17:12:20 --> Loader Class Initialized
INFO - 2018-04-12 22:42:20 --> Helper loaded: users_helper
INFO - 2018-04-12 22:42:20 --> Helper loaded: form_helper
INFO - 2018-04-12 22:42:20 --> Helper loaded: url_helper
INFO - 2018-04-12 22:42:20 --> Form Validation Class Initialized
INFO - 2018-04-12 22:42:20 --> Controller Class Initialized
DEBUG - 2018-04-12 22:42:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:42:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:42:20 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:42:20 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:42:20 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:42:20 --> Helper loaded: users_helper
INFO - 2018-04-12 22:42:20 --> Model Class Initialized
INFO - 2018-04-12 22:42:20 --> Helper loaded: form_helper
INFO - 2018-04-12 22:42:20 --> Form Validation Class Initialized
INFO - 2018-04-12 22:42:20 --> Controller Class Initialized
INFO - 2018-04-12 22:42:20 --> Helper loaded: inflector_helper
INFO - 2018-04-12 22:42:20 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:42:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:42:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:42:20 --> Model Class Initialized
INFO - 2018-04-12 22:42:20 --> Model Class Initialized
INFO - 2018-04-12 22:42:20 --> Model Class Initialized
INFO - 2018-04-12 22:42:20 --> Model Class Initialized
INFO - 2018-04-12 22:42:20 --> Model Class Initialized
INFO - 2018-04-12 22:42:20 --> Model Class Initialized
INFO - 2018-04-12 22:42:20 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-12 22:42:20 --> Model Class Initialized
INFO - 2018-04-12 22:42:20 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:42:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:42:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:42:20 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:42:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:42:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:42:20 --> Model Class Initialized
INFO - 2018-04-12 22:42:20 --> Model Class Initialized
INFO - 2018-04-12 22:42:20 --> Model Class Initialized
DEBUG - 2018-04-12 22:42:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:42:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:42:20 --> Helper loaded: form_helper
INFO - 2018-04-12 22:42:20 --> Form Validation Class Initialized
INFO - 2018-04-12 22:42:20 --> Controller Class Initialized
INFO - 2018-04-12 22:42:20 --> Model Class Initialized
INFO - 2018-04-12 22:42:20 --> Helper loaded: form_helper
INFO - 2018-04-12 22:42:20 --> Form Validation Class Initialized
INFO - 2018-04-12 22:42:20 --> Controller Class Initialized
INFO - 2018-04-12 22:42:20 --> Model Class Initialized
INFO - 2018-04-12 22:42:20 --> Model Class Initialized
INFO - 2018-04-12 22:42:20 --> Final output sent to browser
DEBUG - 2018-04-12 22:42:20 --> Total execution time: 0.1318
INFO - 2018-04-12 22:42:20 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:42:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:42:20 --> Model Class Initialized
INFO - 2018-04-12 22:42:20 --> Model Class Initialized
INFO - 2018-04-12 22:42:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:42:20 --> Helper loaded: inflector_helper
INFO - 2018-04-12 22:42:20 --> Model Class Initialized
INFO - 2018-04-12 22:42:20 --> Model Class Initialized
INFO - 2018-04-12 22:42:20 --> Model Class Initialized
INFO - 2018-04-12 22:42:20 --> Model Class Initialized
INFO - 2018-04-12 22:42:20 --> Model Class Initialized
INFO - 2018-04-12 22:42:20 --> Model Class Initialized
INFO - 2018-04-12 22:42:20 --> Model Class Initialized
INFO - 2018-04-12 22:42:20 --> Model Class Initialized
INFO - 2018-04-12 22:42:20 --> Model Class Initialized
DEBUG - 2018-04-12 22:42:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:42:20 --> Model Class Initialized
INFO - 2018-04-12 22:42:20 --> Model Class Initialized
INFO - 2018-04-12 22:42:20 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-12 22:42:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:42:20 --> Model Class Initialized
INFO - 2018-04-12 22:42:20 --> Model Class Initialized
INFO - 2018-04-12 22:42:20 --> Model Class Initialized
INFO - 2018-04-12 22:42:20 --> Model Class Initialized
INFO - 2018-04-12 22:42:20 --> Model Class Initialized
INFO - 2018-04-12 22:42:20 --> Model Class Initialized
INFO - 2018-04-12 22:42:20 --> Model Class Initialized
INFO - 2018-04-12 22:42:20 --> Model Class Initialized
INFO - 2018-04-12 22:42:20 --> Model Class Initialized
INFO - 2018-04-12 22:42:20 --> Model Class Initialized
INFO - 2018-04-12 22:42:20 --> Model Class Initialized
INFO - 2018-04-12 22:42:20 --> Model Class Initialized
INFO - 2018-04-12 22:42:20 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-12 22:42:20 --> Final output sent to browser
DEBUG - 2018-04-12 22:42:20 --> Total execution time: 0.1190
INFO - 2018-04-12 22:42:20 --> Model Class Initialized
INFO - 2018-04-12 22:42:20 --> Model Class Initialized
INFO - 2018-04-12 22:42:20 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-12 22:42:20 --> Model Class Initialized
INFO - 2018-04-12 22:42:20 --> Final output sent to browser
INFO - 2018-04-12 22:42:20 --> Final output sent to browser
DEBUG - 2018-04-12 22:42:20 --> Total execution time: 0.2117
DEBUG - 2018-04-12 22:42:20 --> Total execution time: 0.2335
INFO - 2018-04-12 17:12:21 --> Config Class Initialized
INFO - 2018-04-12 17:12:21 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:12:21 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:12:21 --> Utf8 Class Initialized
INFO - 2018-04-12 17:12:21 --> URI Class Initialized
INFO - 2018-04-12 17:12:21 --> Router Class Initialized
INFO - 2018-04-12 17:12:21 --> Output Class Initialized
INFO - 2018-04-12 17:12:21 --> Security Class Initialized
DEBUG - 2018-04-12 17:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:12:21 --> Input Class Initialized
INFO - 2018-04-12 17:12:21 --> Language Class Initialized
INFO - 2018-04-12 17:12:21 --> Config Class Initialized
INFO - 2018-04-12 17:12:21 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:12:21 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:12:21 --> Utf8 Class Initialized
INFO - 2018-04-12 17:12:21 --> Language Class Initialized
INFO - 2018-04-12 17:12:21 --> Config Class Initialized
INFO - 2018-04-12 17:12:21 --> Loader Class Initialized
INFO - 2018-04-12 17:12:21 --> URI Class Initialized
INFO - 2018-04-12 22:42:21 --> Helper loaded: url_helper
INFO - 2018-04-12 22:42:21 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:42:21 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:42:21 --> Helper loaded: permission_helper
INFO - 2018-04-12 17:12:21 --> Router Class Initialized
INFO - 2018-04-12 22:42:21 --> Helper loaded: users_helper
INFO - 2018-04-12 17:12:22 --> Output Class Initialized
INFO - 2018-04-12 17:12:22 --> Security Class Initialized
DEBUG - 2018-04-12 17:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:12:22 --> Input Class Initialized
INFO - 2018-04-12 17:12:22 --> Language Class Initialized
INFO - 2018-04-12 22:42:22 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:42:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:42:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 17:12:22 --> Language Class Initialized
INFO - 2018-04-12 17:12:22 --> Config Class Initialized
INFO - 2018-04-12 17:12:22 --> Loader Class Initialized
INFO - 2018-04-12 22:42:22 --> Helper loaded: url_helper
INFO - 2018-04-12 22:42:22 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:42:22 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:42:22 --> Helper loaded: form_helper
INFO - 2018-04-12 22:42:22 --> Form Validation Class Initialized
INFO - 2018-04-12 22:42:22 --> Controller Class Initialized
INFO - 2018-04-12 22:42:22 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:42:22 --> Helper loaded: users_helper
INFO - 2018-04-12 22:42:22 --> Model Class Initialized
INFO - 2018-04-12 22:42:22 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:42:22 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:42:22 --> Database Driver Class Initialized
INFO - 2018-04-12 22:42:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:42:22 --> Model Class Initialized
INFO - 2018-04-12 22:42:22 --> Model Class Initialized
INFO - 2018-04-12 22:42:22 --> Model Class Initialized
INFO - 2018-04-12 22:42:22 --> Model Class Initialized
DEBUG - 2018-04-12 22:42:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:42:22 --> Model Class Initialized
INFO - 2018-04-12 22:42:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:42:22 --> Model Class Initialized
INFO - 2018-04-12 22:42:22 --> Model Class Initialized
INFO - 2018-04-12 22:42:22 --> Model Class Initialized
INFO - 2018-04-12 22:42:22 --> Model Class Initialized
INFO - 2018-04-12 22:42:22 --> Model Class Initialized
INFO - 2018-04-12 22:42:22 --> Model Class Initialized
INFO - 2018-04-12 22:42:22 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-12 22:42:22 --> Model Class Initialized
INFO - 2018-04-12 22:42:22 --> Helper loaded: form_helper
INFO - 2018-04-12 22:42:22 --> Form Validation Class Initialized
INFO - 2018-04-12 22:42:22 --> Controller Class Initialized
INFO - 2018-04-12 22:42:22 --> Final output sent to browser
DEBUG - 2018-04-12 22:42:22 --> Total execution time: 0.1202
INFO - 2018-04-12 22:42:22 --> Model Class Initialized
INFO - 2018-04-12 22:42:22 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:42:22 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:42:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:42:22 --> Model Class Initialized
INFO - 2018-04-12 22:42:22 --> Model Class Initialized
INFO - 2018-04-12 22:42:22 --> Model Class Initialized
INFO - 2018-04-12 22:42:22 --> Model Class Initialized
INFO - 2018-04-12 22:42:22 --> Model Class Initialized
INFO - 2018-04-12 22:42:22 --> Model Class Initialized
INFO - 2018-04-12 22:42:22 --> Model Class Initialized
INFO - 2018-04-12 22:42:22 --> Model Class Initialized
INFO - 2018-04-12 22:42:22 --> Model Class Initialized
INFO - 2018-04-12 22:42:22 --> Model Class Initialized
INFO - 2018-04-12 22:42:22 --> Model Class Initialized
INFO - 2018-04-12 22:42:22 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-12 22:42:22 --> Final output sent to browser
DEBUG - 2018-04-12 22:42:22 --> Total execution time: 0.1302
INFO - 2018-04-12 17:12:23 --> Config Class Initialized
INFO - 2018-04-12 17:12:23 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:12:23 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:12:23 --> Utf8 Class Initialized
INFO - 2018-04-12 17:12:23 --> URI Class Initialized
INFO - 2018-04-12 17:12:23 --> Router Class Initialized
INFO - 2018-04-12 17:12:23 --> Output Class Initialized
INFO - 2018-04-12 17:12:23 --> Security Class Initialized
DEBUG - 2018-04-12 17:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:12:23 --> Input Class Initialized
INFO - 2018-04-12 17:12:23 --> Language Class Initialized
INFO - 2018-04-12 17:12:23 --> Language Class Initialized
INFO - 2018-04-12 17:12:23 --> Config Class Initialized
INFO - 2018-04-12 17:12:23 --> Loader Class Initialized
INFO - 2018-04-12 22:42:23 --> Helper loaded: url_helper
INFO - 2018-04-12 22:42:23 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:42:23 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:42:23 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:42:23 --> Helper loaded: users_helper
INFO - 2018-04-12 22:42:23 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:42:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:42:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:42:23 --> Helper loaded: form_helper
INFO - 2018-04-12 22:42:23 --> Form Validation Class Initialized
INFO - 2018-04-12 22:42:23 --> Controller Class Initialized
INFO - 2018-04-12 22:42:23 --> Model Class Initialized
INFO - 2018-04-12 22:42:23 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:42:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:42:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:42:23 --> Model Class Initialized
INFO - 2018-04-12 22:42:23 --> Model Class Initialized
INFO - 2018-04-12 22:42:23 --> Model Class Initialized
INFO - 2018-04-12 22:42:23 --> Model Class Initialized
INFO - 2018-04-12 22:42:23 --> Final output sent to browser
DEBUG - 2018-04-12 22:42:23 --> Total execution time: 0.1263
INFO - 2018-04-12 17:12:24 --> Config Class Initialized
INFO - 2018-04-12 17:12:24 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:12:24 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:12:24 --> Utf8 Class Initialized
INFO - 2018-04-12 17:12:24 --> URI Class Initialized
INFO - 2018-04-12 17:12:24 --> Router Class Initialized
INFO - 2018-04-12 17:12:24 --> Output Class Initialized
INFO - 2018-04-12 17:12:24 --> Security Class Initialized
DEBUG - 2018-04-12 17:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:12:24 --> Input Class Initialized
INFO - 2018-04-12 17:12:24 --> Language Class Initialized
INFO - 2018-04-12 17:12:24 --> Language Class Initialized
INFO - 2018-04-12 17:12:24 --> Config Class Initialized
INFO - 2018-04-12 17:12:24 --> Loader Class Initialized
INFO - 2018-04-12 22:42:24 --> Helper loaded: url_helper
INFO - 2018-04-12 17:12:24 --> Config Class Initialized
INFO - 2018-04-12 17:12:24 --> Hooks Class Initialized
INFO - 2018-04-12 22:42:24 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:42:24 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:42:24 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:42:24 --> Helper loaded: users_helper
DEBUG - 2018-04-12 17:12:24 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:12:24 --> Utf8 Class Initialized
INFO - 2018-04-12 17:12:24 --> URI Class Initialized
INFO - 2018-04-12 17:12:24 --> Router Class Initialized
INFO - 2018-04-12 17:12:24 --> Output Class Initialized
INFO - 2018-04-12 17:12:24 --> Security Class Initialized
DEBUG - 2018-04-12 17:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:12:24 --> Input Class Initialized
INFO - 2018-04-12 22:42:24 --> Database Driver Class Initialized
INFO - 2018-04-12 17:12:24 --> Language Class Initialized
DEBUG - 2018-04-12 22:42:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:42:24 --> Helper loaded: form_helper
INFO - 2018-04-12 22:42:24 --> Form Validation Class Initialized
INFO - 2018-04-12 22:42:24 --> Controller Class Initialized
INFO - 2018-04-12 17:12:24 --> Language Class Initialized
INFO - 2018-04-12 17:12:24 --> Config Class Initialized
INFO - 2018-04-12 17:12:24 --> Loader Class Initialized
INFO - 2018-04-12 22:42:24 --> Helper loaded: url_helper
INFO - 2018-04-12 22:42:24 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:42:24 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:42:24 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:42:24 --> Helper loaded: users_helper
INFO - 2018-04-12 22:42:24 --> Model Class Initialized
INFO - 2018-04-12 22:42:24 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:42:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:42:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:42:24 --> Model Class Initialized
INFO - 2018-04-12 22:42:24 --> Model Class Initialized
INFO - 2018-04-12 22:42:24 --> Model Class Initialized
INFO - 2018-04-12 22:42:24 --> Model Class Initialized
INFO - 2018-04-12 22:42:24 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:42:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:42:24 --> Helper loaded: form_helper
INFO - 2018-04-12 22:42:24 --> Form Validation Class Initialized
INFO - 2018-04-12 22:42:24 --> Controller Class Initialized
INFO - 2018-04-12 22:42:24 --> Model Class Initialized
INFO - 2018-04-12 22:42:24 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:42:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:42:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:42:24 --> Model Class Initialized
INFO - 2018-04-12 22:42:24 --> Model Class Initialized
INFO - 2018-04-12 22:42:24 --> Model Class Initialized
INFO - 2018-04-12 22:42:24 --> Model Class Initialized
INFO - 2018-04-12 22:42:24 --> Final output sent to browser
DEBUG - 2018-04-12 22:42:24 --> Total execution time: 0.1021
INFO - 2018-04-12 22:42:24 --> Final output sent to browser
DEBUG - 2018-04-12 22:42:24 --> Total execution time: 0.2219
INFO - 2018-04-12 17:12:27 --> Config Class Initialized
INFO - 2018-04-12 17:12:27 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:12:27 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:12:27 --> Utf8 Class Initialized
INFO - 2018-04-12 17:12:27 --> URI Class Initialized
INFO - 2018-04-12 17:12:27 --> Router Class Initialized
INFO - 2018-04-12 17:12:27 --> Output Class Initialized
INFO - 2018-04-12 17:12:27 --> Security Class Initialized
DEBUG - 2018-04-12 17:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:12:27 --> Input Class Initialized
INFO - 2018-04-12 17:12:27 --> Language Class Initialized
INFO - 2018-04-12 17:12:27 --> Language Class Initialized
INFO - 2018-04-12 17:12:27 --> Config Class Initialized
INFO - 2018-04-12 17:12:27 --> Loader Class Initialized
INFO - 2018-04-12 22:42:27 --> Helper loaded: url_helper
INFO - 2018-04-12 22:42:27 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:42:27 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:42:27 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:42:27 --> Helper loaded: users_helper
INFO - 2018-04-12 22:42:27 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:42:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:42:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:42:27 --> Helper loaded: form_helper
INFO - 2018-04-12 22:42:27 --> Form Validation Class Initialized
INFO - 2018-04-12 22:42:27 --> Controller Class Initialized
INFO - 2018-04-12 22:42:27 --> Model Class Initialized
INFO - 2018-04-12 22:42:27 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:42:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:42:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:42:27 --> Model Class Initialized
INFO - 2018-04-12 22:42:27 --> Model Class Initialized
INFO - 2018-04-12 22:42:27 --> Model Class Initialized
INFO - 2018-04-12 22:42:27 --> Model Class Initialized
INFO - 2018-04-12 22:42:27 --> Model Class Initialized
INFO - 2018-04-12 22:42:27 --> Model Class Initialized
INFO - 2018-04-12 22:42:27 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-04-12 22:42:27 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
ERROR - 2018-04-12 22:42:27 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 784
INFO - 2018-04-12 22:42:27 --> Final output sent to browser
DEBUG - 2018-04-12 22:42:27 --> Total execution time: 0.2805
INFO - 2018-04-12 17:12:29 --> Config Class Initialized
INFO - 2018-04-12 17:12:29 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:12:29 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:12:29 --> Utf8 Class Initialized
INFO - 2018-04-12 17:12:29 --> URI Class Initialized
INFO - 2018-04-12 17:12:29 --> Router Class Initialized
INFO - 2018-04-12 17:12:29 --> Output Class Initialized
INFO - 2018-04-12 17:12:29 --> Security Class Initialized
DEBUG - 2018-04-12 17:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:12:29 --> Input Class Initialized
INFO - 2018-04-12 17:12:29 --> Language Class Initialized
INFO - 2018-04-12 17:12:29 --> Language Class Initialized
INFO - 2018-04-12 17:12:29 --> Config Class Initialized
INFO - 2018-04-12 17:12:29 --> Loader Class Initialized
INFO - 2018-04-12 22:42:29 --> Helper loaded: url_helper
INFO - 2018-04-12 22:42:29 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:42:29 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:42:29 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:42:29 --> Helper loaded: users_helper
INFO - 2018-04-12 22:42:29 --> Database Driver Class Initialized
INFO - 2018-04-12 17:12:29 --> Config Class Initialized
INFO - 2018-04-12 17:12:29 --> Hooks Class Initialized
DEBUG - 2018-04-12 22:42:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:42:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-04-12 17:12:29 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:12:29 --> Utf8 Class Initialized
INFO - 2018-04-12 22:42:29 --> Helper loaded: form_helper
INFO - 2018-04-12 22:42:29 --> Form Validation Class Initialized
INFO - 2018-04-12 17:12:29 --> URI Class Initialized
INFO - 2018-04-12 22:42:29 --> Controller Class Initialized
INFO - 2018-04-12 17:12:29 --> Router Class Initialized
INFO - 2018-04-12 17:12:29 --> Output Class Initialized
INFO - 2018-04-12 22:42:29 --> Model Class Initialized
INFO - 2018-04-12 22:42:29 --> Helper loaded: inflector_helper
INFO - 2018-04-12 17:12:29 --> Security Class Initialized
DEBUG - 2018-04-12 17:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:12:29 --> Input Class Initialized
DEBUG - 2018-04-12 22:42:29 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 17:12:29 --> Language Class Initialized
INFO - 2018-04-12 22:42:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:42:29 --> Model Class Initialized
INFO - 2018-04-12 22:42:29 --> Model Class Initialized
INFO - 2018-04-12 22:42:29 --> Model Class Initialized
INFO - 2018-04-12 22:42:29 --> Model Class Initialized
INFO - 2018-04-12 22:42:29 --> Final output sent to browser
DEBUG - 2018-04-12 22:42:29 --> Total execution time: 0.1020
INFO - 2018-04-12 17:12:29 --> Language Class Initialized
INFO - 2018-04-12 17:12:29 --> Config Class Initialized
INFO - 2018-04-12 17:12:29 --> Loader Class Initialized
INFO - 2018-04-12 22:42:29 --> Helper loaded: url_helper
INFO - 2018-04-12 22:42:29 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:42:29 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:42:29 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:42:29 --> Helper loaded: users_helper
INFO - 2018-04-12 22:42:29 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:42:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:42:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:42:29 --> Helper loaded: form_helper
INFO - 2018-04-12 22:42:29 --> Form Validation Class Initialized
INFO - 2018-04-12 22:42:29 --> Controller Class Initialized
INFO - 2018-04-12 22:42:29 --> Model Class Initialized
INFO - 2018-04-12 22:42:29 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:42:29 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:42:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:42:29 --> Model Class Initialized
INFO - 2018-04-12 22:42:29 --> Model Class Initialized
INFO - 2018-04-12 22:42:29 --> Model Class Initialized
INFO - 2018-04-12 22:42:29 --> Model Class Initialized
INFO - 2018-04-12 22:42:29 --> Final output sent to browser
DEBUG - 2018-04-12 22:42:29 --> Total execution time: 0.1284
INFO - 2018-04-12 17:12:30 --> Config Class Initialized
INFO - 2018-04-12 17:12:30 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:12:30 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:12:30 --> Utf8 Class Initialized
INFO - 2018-04-12 17:12:30 --> URI Class Initialized
INFO - 2018-04-12 17:12:30 --> Router Class Initialized
INFO - 2018-04-12 17:12:30 --> Output Class Initialized
INFO - 2018-04-12 17:12:30 --> Security Class Initialized
DEBUG - 2018-04-12 17:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:12:30 --> Input Class Initialized
INFO - 2018-04-12 17:12:30 --> Language Class Initialized
INFO - 2018-04-12 17:12:30 --> Language Class Initialized
INFO - 2018-04-12 17:12:30 --> Config Class Initialized
INFO - 2018-04-12 17:12:30 --> Loader Class Initialized
INFO - 2018-04-12 22:42:30 --> Helper loaded: url_helper
INFO - 2018-04-12 22:42:30 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:42:30 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:42:30 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:42:30 --> Helper loaded: users_helper
INFO - 2018-04-12 22:42:30 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:42:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:42:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:42:30 --> Helper loaded: form_helper
INFO - 2018-04-12 22:42:30 --> Form Validation Class Initialized
INFO - 2018-04-12 22:42:30 --> Controller Class Initialized
INFO - 2018-04-12 22:42:30 --> Model Class Initialized
INFO - 2018-04-12 22:42:30 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:42:30 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:42:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:42:30 --> Model Class Initialized
INFO - 2018-04-12 22:42:30 --> Model Class Initialized
INFO - 2018-04-12 22:42:30 --> Model Class Initialized
INFO - 2018-04-12 22:42:30 --> Model Class Initialized
INFO - 2018-04-12 22:42:30 --> Final output sent to browser
DEBUG - 2018-04-12 22:42:30 --> Total execution time: 0.1111
INFO - 2018-04-12 17:12:34 --> Config Class Initialized
INFO - 2018-04-12 17:12:34 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:12:34 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:12:34 --> Utf8 Class Initialized
INFO - 2018-04-12 17:12:34 --> URI Class Initialized
INFO - 2018-04-12 17:12:34 --> Router Class Initialized
INFO - 2018-04-12 17:12:34 --> Output Class Initialized
INFO - 2018-04-12 17:12:34 --> Security Class Initialized
DEBUG - 2018-04-12 17:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:12:34 --> Input Class Initialized
INFO - 2018-04-12 17:12:34 --> Language Class Initialized
INFO - 2018-04-12 17:12:34 --> Language Class Initialized
INFO - 2018-04-12 17:12:34 --> Config Class Initialized
INFO - 2018-04-12 17:12:34 --> Loader Class Initialized
INFO - 2018-04-12 22:42:34 --> Helper loaded: url_helper
INFO - 2018-04-12 22:42:34 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:42:34 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:42:34 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:42:34 --> Helper loaded: users_helper
INFO - 2018-04-12 22:42:34 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:42:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:42:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:42:34 --> Helper loaded: form_helper
INFO - 2018-04-12 22:42:34 --> Form Validation Class Initialized
INFO - 2018-04-12 22:42:34 --> Controller Class Initialized
INFO - 2018-04-12 22:42:34 --> Model Class Initialized
INFO - 2018-04-12 22:42:34 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:42:34 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:42:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:42:34 --> Model Class Initialized
INFO - 2018-04-12 22:42:34 --> Model Class Initialized
INFO - 2018-04-12 22:42:34 --> Model Class Initialized
INFO - 2018-04-12 22:42:34 --> Model Class Initialized
INFO - 2018-04-12 22:42:34 --> Model Class Initialized
INFO - 2018-04-12 22:42:34 --> Model Class Initialized
INFO - 2018-04-12 22:42:34 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-04-12 22:42:34 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-04-12 22:42:34 --> Final output sent to browser
DEBUG - 2018-04-12 22:42:34 --> Total execution time: 0.1111
INFO - 2018-04-12 17:12:43 --> Config Class Initialized
INFO - 2018-04-12 17:12:43 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:12:43 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:12:43 --> Utf8 Class Initialized
INFO - 2018-04-12 17:12:43 --> URI Class Initialized
INFO - 2018-04-12 17:12:43 --> Router Class Initialized
INFO - 2018-04-12 17:12:43 --> Output Class Initialized
INFO - 2018-04-12 17:12:43 --> Security Class Initialized
DEBUG - 2018-04-12 17:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:12:43 --> Input Class Initialized
INFO - 2018-04-12 17:12:43 --> Language Class Initialized
INFO - 2018-04-12 17:12:43 --> Language Class Initialized
INFO - 2018-04-12 17:12:43 --> Config Class Initialized
INFO - 2018-04-12 17:12:43 --> Loader Class Initialized
INFO - 2018-04-12 22:42:43 --> Helper loaded: url_helper
INFO - 2018-04-12 22:42:43 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:42:43 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:42:43 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:42:43 --> Helper loaded: users_helper
INFO - 2018-04-12 22:42:43 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:42:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:42:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:42:43 --> Helper loaded: form_helper
INFO - 2018-04-12 22:42:43 --> Form Validation Class Initialized
INFO - 2018-04-12 22:42:43 --> Controller Class Initialized
INFO - 2018-04-12 22:42:43 --> Model Class Initialized
INFO - 2018-04-12 22:42:43 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:42:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:42:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:42:43 --> Model Class Initialized
INFO - 2018-04-12 22:42:43 --> Model Class Initialized
INFO - 2018-04-12 22:42:43 --> Model Class Initialized
INFO - 2018-04-12 22:42:43 --> Model Class Initialized
INFO - 2018-04-12 22:42:43 --> Model Class Initialized
INFO - 2018-04-12 22:42:43 --> Model Class Initialized
INFO - 2018-04-12 22:42:43 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-12 22:42:43 --> Model Class Initialized
INFO - 2018-04-12 22:42:43 --> Model Class Initialized
INFO - 2018-04-12 22:42:43 --> Final output sent to browser
DEBUG - 2018-04-12 22:42:43 --> Total execution time: 0.2007
INFO - 2018-04-12 17:12:44 --> Config Class Initialized
INFO - 2018-04-12 17:12:44 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:12:44 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:12:44 --> Utf8 Class Initialized
INFO - 2018-04-12 17:12:44 --> URI Class Initialized
INFO - 2018-04-12 17:12:44 --> Router Class Initialized
INFO - 2018-04-12 17:12:44 --> Output Class Initialized
INFO - 2018-04-12 17:12:44 --> Security Class Initialized
DEBUG - 2018-04-12 17:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:12:44 --> Input Class Initialized
INFO - 2018-04-12 17:12:44 --> Language Class Initialized
INFO - 2018-04-12 17:12:44 --> Language Class Initialized
INFO - 2018-04-12 17:12:44 --> Config Class Initialized
INFO - 2018-04-12 17:12:44 --> Loader Class Initialized
INFO - 2018-04-12 22:42:44 --> Helper loaded: url_helper
INFO - 2018-04-12 22:42:44 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:42:44 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:42:44 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:42:44 --> Helper loaded: users_helper
INFO - 2018-04-12 22:42:44 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:42:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:42:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:42:44 --> Helper loaded: form_helper
INFO - 2018-04-12 22:42:44 --> Form Validation Class Initialized
INFO - 2018-04-12 22:42:44 --> Controller Class Initialized
INFO - 2018-04-12 22:42:44 --> Model Class Initialized
INFO - 2018-04-12 22:42:44 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:42:44 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:42:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:42:44 --> Model Class Initialized
INFO - 2018-04-12 22:42:44 --> Model Class Initialized
INFO - 2018-04-12 22:42:44 --> Model Class Initialized
INFO - 2018-04-12 22:42:44 --> Model Class Initialized
INFO - 2018-04-12 22:42:44 --> Final output sent to browser
DEBUG - 2018-04-12 22:42:44 --> Total execution time: 0.1034
INFO - 2018-04-12 17:12:44 --> Config Class Initialized
INFO - 2018-04-12 17:12:44 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:12:44 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:12:44 --> Utf8 Class Initialized
INFO - 2018-04-12 17:12:44 --> URI Class Initialized
INFO - 2018-04-12 17:12:44 --> Router Class Initialized
INFO - 2018-04-12 17:12:44 --> Output Class Initialized
INFO - 2018-04-12 17:12:44 --> Security Class Initialized
DEBUG - 2018-04-12 17:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:12:44 --> Input Class Initialized
INFO - 2018-04-12 17:12:44 --> Language Class Initialized
INFO - 2018-04-12 17:12:44 --> Language Class Initialized
INFO - 2018-04-12 17:12:44 --> Config Class Initialized
INFO - 2018-04-12 17:12:44 --> Loader Class Initialized
INFO - 2018-04-12 22:42:44 --> Helper loaded: url_helper
INFO - 2018-04-12 22:42:44 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:42:44 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:42:44 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:42:44 --> Helper loaded: users_helper
INFO - 2018-04-12 22:42:44 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:42:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:42:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:42:44 --> Helper loaded: form_helper
INFO - 2018-04-12 22:42:44 --> Form Validation Class Initialized
INFO - 2018-04-12 22:42:44 --> Controller Class Initialized
INFO - 2018-04-12 22:42:44 --> Model Class Initialized
INFO - 2018-04-12 22:42:44 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:42:44 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:42:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:42:44 --> Model Class Initialized
INFO - 2018-04-12 22:42:44 --> Model Class Initialized
INFO - 2018-04-12 22:42:44 --> Model Class Initialized
INFO - 2018-04-12 22:42:44 --> Model Class Initialized
INFO - 2018-04-12 22:42:44 --> Final output sent to browser
DEBUG - 2018-04-12 22:42:44 --> Total execution time: 0.1101
INFO - 2018-04-12 17:12:46 --> Config Class Initialized
INFO - 2018-04-12 17:12:46 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:12:46 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:12:46 --> Utf8 Class Initialized
INFO - 2018-04-12 17:12:46 --> URI Class Initialized
INFO - 2018-04-12 17:12:46 --> Router Class Initialized
INFO - 2018-04-12 17:12:46 --> Output Class Initialized
INFO - 2018-04-12 17:12:46 --> Security Class Initialized
DEBUG - 2018-04-12 17:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:12:46 --> Input Class Initialized
INFO - 2018-04-12 17:12:46 --> Language Class Initialized
INFO - 2018-04-12 17:12:46 --> Language Class Initialized
INFO - 2018-04-12 17:12:46 --> Config Class Initialized
INFO - 2018-04-12 17:12:46 --> Loader Class Initialized
INFO - 2018-04-12 22:42:46 --> Helper loaded: url_helper
INFO - 2018-04-12 22:42:46 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:42:46 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:42:46 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:42:46 --> Helper loaded: users_helper
INFO - 2018-04-12 22:42:46 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:42:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:42:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:42:46 --> Helper loaded: form_helper
INFO - 2018-04-12 22:42:46 --> Form Validation Class Initialized
INFO - 2018-04-12 22:42:46 --> Controller Class Initialized
INFO - 2018-04-12 22:42:46 --> Model Class Initialized
INFO - 2018-04-12 22:42:46 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:42:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:42:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:42:46 --> Model Class Initialized
INFO - 2018-04-12 22:42:46 --> Model Class Initialized
INFO - 2018-04-12 22:42:46 --> Model Class Initialized
INFO - 2018-04-12 22:42:46 --> Model Class Initialized
INFO - 2018-04-12 22:42:46 --> Final output sent to browser
DEBUG - 2018-04-12 22:42:46 --> Total execution time: 0.1082
INFO - 2018-04-12 17:12:50 --> Config Class Initialized
INFO - 2018-04-12 17:12:50 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:12:50 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:12:50 --> Utf8 Class Initialized
INFO - 2018-04-12 17:12:50 --> URI Class Initialized
INFO - 2018-04-12 17:12:50 --> Router Class Initialized
INFO - 2018-04-12 17:12:50 --> Output Class Initialized
INFO - 2018-04-12 17:12:50 --> Security Class Initialized
DEBUG - 2018-04-12 17:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:12:50 --> Input Class Initialized
INFO - 2018-04-12 17:12:50 --> Language Class Initialized
INFO - 2018-04-12 17:12:50 --> Language Class Initialized
INFO - 2018-04-12 17:12:50 --> Config Class Initialized
INFO - 2018-04-12 17:12:50 --> Loader Class Initialized
INFO - 2018-04-12 22:42:50 --> Helper loaded: url_helper
INFO - 2018-04-12 22:42:50 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:42:50 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:42:50 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:42:50 --> Helper loaded: users_helper
INFO - 2018-04-12 22:42:50 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:42:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:42:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:42:50 --> Helper loaded: form_helper
INFO - 2018-04-12 22:42:50 --> Form Validation Class Initialized
INFO - 2018-04-12 22:42:50 --> Controller Class Initialized
INFO - 2018-04-12 22:42:50 --> Model Class Initialized
INFO - 2018-04-12 22:42:50 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:42:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:42:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:42:50 --> Model Class Initialized
INFO - 2018-04-12 22:42:50 --> Model Class Initialized
INFO - 2018-04-12 22:42:50 --> Model Class Initialized
INFO - 2018-04-12 22:42:50 --> Model Class Initialized
INFO - 2018-04-12 22:42:50 --> Final output sent to browser
DEBUG - 2018-04-12 22:42:50 --> Total execution time: 0.1051
INFO - 2018-04-12 17:12:54 --> Config Class Initialized
INFO - 2018-04-12 17:12:54 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:12:54 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:12:54 --> Utf8 Class Initialized
INFO - 2018-04-12 17:12:54 --> URI Class Initialized
INFO - 2018-04-12 17:12:54 --> Router Class Initialized
INFO - 2018-04-12 17:12:54 --> Output Class Initialized
INFO - 2018-04-12 17:12:54 --> Security Class Initialized
DEBUG - 2018-04-12 17:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:12:54 --> Input Class Initialized
INFO - 2018-04-12 17:12:54 --> Language Class Initialized
INFO - 2018-04-12 17:12:54 --> Language Class Initialized
INFO - 2018-04-12 17:12:54 --> Config Class Initialized
INFO - 2018-04-12 17:12:54 --> Loader Class Initialized
INFO - 2018-04-12 22:42:54 --> Helper loaded: url_helper
INFO - 2018-04-12 22:42:54 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:42:54 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:42:54 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:42:54 --> Helper loaded: users_helper
INFO - 2018-04-12 22:42:54 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:42:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:42:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:42:54 --> Helper loaded: form_helper
INFO - 2018-04-12 22:42:54 --> Form Validation Class Initialized
INFO - 2018-04-12 22:42:54 --> Controller Class Initialized
INFO - 2018-04-12 22:42:54 --> Model Class Initialized
INFO - 2018-04-12 22:42:54 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:42:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:42:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:42:54 --> Model Class Initialized
INFO - 2018-04-12 22:42:54 --> Model Class Initialized
INFO - 2018-04-12 22:42:54 --> Model Class Initialized
INFO - 2018-04-12 22:42:54 --> Model Class Initialized
INFO - 2018-04-12 22:42:54 --> Final output sent to browser
DEBUG - 2018-04-12 22:42:54 --> Total execution time: 0.0793
INFO - 2018-04-12 17:12:56 --> Config Class Initialized
INFO - 2018-04-12 17:12:56 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:12:56 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:12:56 --> Utf8 Class Initialized
INFO - 2018-04-12 17:12:56 --> URI Class Initialized
INFO - 2018-04-12 17:12:56 --> Router Class Initialized
INFO - 2018-04-12 17:12:56 --> Output Class Initialized
INFO - 2018-04-12 17:12:56 --> Security Class Initialized
DEBUG - 2018-04-12 17:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:12:56 --> Input Class Initialized
INFO - 2018-04-12 17:12:56 --> Language Class Initialized
INFO - 2018-04-12 17:12:56 --> Language Class Initialized
INFO - 2018-04-12 17:12:56 --> Config Class Initialized
INFO - 2018-04-12 17:12:56 --> Loader Class Initialized
INFO - 2018-04-12 22:42:56 --> Helper loaded: url_helper
INFO - 2018-04-12 22:42:56 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:42:56 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:42:56 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:42:56 --> Helper loaded: users_helper
INFO - 2018-04-12 22:42:56 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:42:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:42:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:42:56 --> Helper loaded: form_helper
INFO - 2018-04-12 22:42:56 --> Form Validation Class Initialized
INFO - 2018-04-12 22:42:56 --> Controller Class Initialized
INFO - 2018-04-12 22:42:56 --> Model Class Initialized
INFO - 2018-04-12 22:42:56 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:42:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:42:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:42:56 --> Model Class Initialized
INFO - 2018-04-12 22:42:56 --> Model Class Initialized
INFO - 2018-04-12 22:42:56 --> Model Class Initialized
INFO - 2018-04-12 22:42:56 --> Model Class Initialized
INFO - 2018-04-12 22:42:56 --> Model Class Initialized
INFO - 2018-04-12 22:42:56 --> Model Class Initialized
INFO - 2018-04-12 22:42:56 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-04-12 22:42:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-04-12 22:42:56 --> Final output sent to browser
DEBUG - 2018-04-12 22:42:56 --> Total execution time: 0.1157
INFO - 2018-04-12 17:12:57 --> Config Class Initialized
INFO - 2018-04-12 17:12:57 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:12:57 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:12:57 --> Utf8 Class Initialized
INFO - 2018-04-12 17:12:57 --> URI Class Initialized
INFO - 2018-04-12 17:12:57 --> Router Class Initialized
INFO - 2018-04-12 17:12:57 --> Output Class Initialized
INFO - 2018-04-12 17:12:57 --> Security Class Initialized
DEBUG - 2018-04-12 17:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:12:57 --> Input Class Initialized
INFO - 2018-04-12 17:12:57 --> Language Class Initialized
INFO - 2018-04-12 17:12:57 --> Config Class Initialized
INFO - 2018-04-12 17:12:57 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:12:57 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:12:57 --> Utf8 Class Initialized
INFO - 2018-04-12 17:12:57 --> URI Class Initialized
INFO - 2018-04-12 17:12:57 --> Router Class Initialized
INFO - 2018-04-12 17:12:57 --> Language Class Initialized
INFO - 2018-04-12 17:12:57 --> Config Class Initialized
INFO - 2018-04-12 17:12:57 --> Loader Class Initialized
INFO - 2018-04-12 17:12:57 --> Output Class Initialized
INFO - 2018-04-12 22:42:57 --> Helper loaded: url_helper
INFO - 2018-04-12 22:42:57 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:42:57 --> Helper loaded: settings_helper
INFO - 2018-04-12 17:12:57 --> Security Class Initialized
INFO - 2018-04-12 22:42:57 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:42:57 --> Helper loaded: users_helper
DEBUG - 2018-04-12 17:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:12:57 --> Input Class Initialized
INFO - 2018-04-12 17:12:57 --> Language Class Initialized
INFO - 2018-04-12 22:42:57 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:42:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:42:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 17:12:57 --> Language Class Initialized
INFO - 2018-04-12 17:12:57 --> Config Class Initialized
INFO - 2018-04-12 17:12:57 --> Loader Class Initialized
INFO - 2018-04-12 22:42:57 --> Helper loaded: form_helper
INFO - 2018-04-12 22:42:57 --> Form Validation Class Initialized
INFO - 2018-04-12 22:42:57 --> Controller Class Initialized
INFO - 2018-04-12 22:42:57 --> Helper loaded: url_helper
INFO - 2018-04-12 22:42:57 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:42:57 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:42:57 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:42:57 --> Helper loaded: users_helper
INFO - 2018-04-12 22:42:57 --> Model Class Initialized
INFO - 2018-04-12 22:42:57 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:42:57 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:42:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:42:57 --> Database Driver Class Initialized
INFO - 2018-04-12 22:42:57 --> Model Class Initialized
INFO - 2018-04-12 22:42:57 --> Model Class Initialized
INFO - 2018-04-12 22:42:57 --> Model Class Initialized
INFO - 2018-04-12 22:42:57 --> Model Class Initialized
INFO - 2018-04-12 22:42:57 --> Model Class Initialized
INFO - 2018-04-12 22:42:57 --> Model Class Initialized
INFO - 2018-04-12 22:42:57 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-04-12 22:42:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:42:57 --> Session: Class initialized using 'files' driver.
ERROR - 2018-04-12 22:42:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-04-12 22:42:57 --> Final output sent to browser
DEBUG - 2018-04-12 22:42:57 --> Total execution time: 0.0929
INFO - 2018-04-12 22:42:57 --> Helper loaded: form_helper
INFO - 2018-04-12 22:42:57 --> Form Validation Class Initialized
INFO - 2018-04-12 22:42:57 --> Controller Class Initialized
INFO - 2018-04-12 22:42:57 --> Model Class Initialized
INFO - 2018-04-12 22:42:57 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:42:57 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:42:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:42:57 --> Model Class Initialized
INFO - 2018-04-12 22:42:57 --> Model Class Initialized
INFO - 2018-04-12 22:42:57 --> Model Class Initialized
INFO - 2018-04-12 22:42:57 --> Model Class Initialized
INFO - 2018-04-12 22:42:57 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-12 22:42:57 --> Final output sent to browser
DEBUG - 2018-04-12 22:42:57 --> Total execution time: 0.1534
INFO - 2018-04-12 17:12:58 --> Config Class Initialized
INFO - 2018-04-12 17:12:58 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:12:58 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:12:58 --> Utf8 Class Initialized
INFO - 2018-04-12 17:12:58 --> URI Class Initialized
INFO - 2018-04-12 17:12:58 --> Router Class Initialized
INFO - 2018-04-12 17:12:58 --> Output Class Initialized
INFO - 2018-04-12 17:12:58 --> Security Class Initialized
DEBUG - 2018-04-12 17:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:12:58 --> Input Class Initialized
INFO - 2018-04-12 17:12:58 --> Language Class Initialized
INFO - 2018-04-12 17:12:58 --> Language Class Initialized
INFO - 2018-04-12 17:12:58 --> Config Class Initialized
INFO - 2018-04-12 17:12:58 --> Loader Class Initialized
INFO - 2018-04-12 22:42:58 --> Helper loaded: url_helper
INFO - 2018-04-12 22:42:58 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:42:58 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:42:58 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:42:58 --> Helper loaded: users_helper
INFO - 2018-04-12 22:42:58 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:42:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:42:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:42:58 --> Helper loaded: form_helper
INFO - 2018-04-12 22:42:58 --> Form Validation Class Initialized
INFO - 2018-04-12 22:42:58 --> Controller Class Initialized
INFO - 2018-04-12 22:42:58 --> Model Class Initialized
INFO - 2018-04-12 22:42:58 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:42:58 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:42:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:42:58 --> Model Class Initialized
INFO - 2018-04-12 22:42:58 --> Model Class Initialized
INFO - 2018-04-12 22:42:58 --> Final output sent to browser
DEBUG - 2018-04-12 22:42:58 --> Total execution time: 0.1234
INFO - 2018-04-12 17:13:00 --> Config Class Initialized
INFO - 2018-04-12 17:13:00 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:13:00 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:13:00 --> Utf8 Class Initialized
INFO - 2018-04-12 17:13:00 --> URI Class Initialized
INFO - 2018-04-12 17:13:00 --> Router Class Initialized
INFO - 2018-04-12 17:13:00 --> Output Class Initialized
INFO - 2018-04-12 17:13:00 --> Security Class Initialized
DEBUG - 2018-04-12 17:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:13:00 --> Input Class Initialized
INFO - 2018-04-12 17:13:00 --> Language Class Initialized
INFO - 2018-04-12 17:13:00 --> Config Class Initialized
INFO - 2018-04-12 17:13:00 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:13:00 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:13:00 --> Utf8 Class Initialized
INFO - 2018-04-12 17:13:00 --> URI Class Initialized
INFO - 2018-04-12 17:13:00 --> Router Class Initialized
INFO - 2018-04-12 17:13:00 --> Output Class Initialized
INFO - 2018-04-12 17:13:00 --> Security Class Initialized
DEBUG - 2018-04-12 17:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:13:00 --> Input Class Initialized
INFO - 2018-04-12 17:13:00 --> Language Class Initialized
INFO - 2018-04-12 17:13:00 --> Language Class Initialized
INFO - 2018-04-12 17:13:00 --> Config Class Initialized
INFO - 2018-04-12 17:13:00 --> Loader Class Initialized
INFO - 2018-04-12 22:43:00 --> Helper loaded: url_helper
INFO - 2018-04-12 22:43:00 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:43:00 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:43:00 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:43:00 --> Helper loaded: users_helper
INFO - 2018-04-12 17:13:00 --> Language Class Initialized
INFO - 2018-04-12 17:13:00 --> Config Class Initialized
INFO - 2018-04-12 17:13:00 --> Loader Class Initialized
INFO - 2018-04-12 22:43:00 --> Helper loaded: url_helper
INFO - 2018-04-12 22:43:00 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:43:00 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:43:00 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:43:00 --> Helper loaded: users_helper
INFO - 2018-04-12 22:43:00 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:43:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:43:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:43:00 --> Database Driver Class Initialized
INFO - 2018-04-12 22:43:00 --> Helper loaded: form_helper
INFO - 2018-04-12 22:43:00 --> Form Validation Class Initialized
DEBUG - 2018-04-12 22:43:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:43:00 --> Controller Class Initialized
INFO - 2018-04-12 22:43:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:43:00 --> Helper loaded: form_helper
INFO - 2018-04-12 22:43:00 --> Form Validation Class Initialized
INFO - 2018-04-12 22:43:00 --> Controller Class Initialized
INFO - 2018-04-12 22:43:00 --> Model Class Initialized
INFO - 2018-04-12 22:43:00 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:43:00 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:43:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:43:00 --> Model Class Initialized
INFO - 2018-04-12 22:43:00 --> Model Class Initialized
INFO - 2018-04-12 22:43:00 --> Model Class Initialized
INFO - 2018-04-12 22:43:00 --> Model Class Initialized
INFO - 2018-04-12 22:43:00 --> Model Class Initialized
INFO - 2018-04-12 22:43:00 --> Model Class Initialized
INFO - 2018-04-12 22:43:00 --> Model Class Initialized
INFO - 2018-04-12 22:43:00 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-12 22:43:00 --> Helper loaded: inflector_helper
ERROR - 2018-04-12 22:43:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-04-12 22:43:00 --> Final output sent to browser
DEBUG - 2018-04-12 22:43:00 --> Total execution time: 0.1077
DEBUG - 2018-04-12 22:43:00 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:43:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:43:00 --> Model Class Initialized
INFO - 2018-04-12 22:43:00 --> Model Class Initialized
INFO - 2018-04-12 22:43:00 --> Model Class Initialized
INFO - 2018-04-12 22:43:00 --> Model Class Initialized
INFO - 2018-04-12 22:43:00 --> Model Class Initialized
INFO - 2018-04-12 22:43:00 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-12 22:43:00 --> Model Class Initialized
INFO - 2018-04-12 22:43:00 --> Final output sent to browser
DEBUG - 2018-04-12 22:43:00 --> Total execution time: 0.1790
INFO - 2018-04-12 17:13:19 --> Config Class Initialized
INFO - 2018-04-12 17:13:19 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:13:19 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:13:19 --> Utf8 Class Initialized
INFO - 2018-04-12 17:13:19 --> URI Class Initialized
INFO - 2018-04-12 17:13:19 --> Router Class Initialized
INFO - 2018-04-12 17:13:19 --> Output Class Initialized
INFO - 2018-04-12 17:13:19 --> Security Class Initialized
DEBUG - 2018-04-12 17:13:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:13:19 --> Input Class Initialized
INFO - 2018-04-12 17:13:19 --> Language Class Initialized
INFO - 2018-04-12 17:13:19 --> Config Class Initialized
INFO - 2018-04-12 17:13:19 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:13:19 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:13:19 --> Utf8 Class Initialized
INFO - 2018-04-12 17:13:19 --> URI Class Initialized
INFO - 2018-04-12 17:13:19 --> Router Class Initialized
INFO - 2018-04-12 17:13:19 --> Output Class Initialized
INFO - 2018-04-12 17:13:19 --> Security Class Initialized
INFO - 2018-04-12 17:13:19 --> Config Class Initialized
INFO - 2018-04-12 17:13:19 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:13:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:13:19 --> Input Class Initialized
INFO - 2018-04-12 17:13:19 --> Language Class Initialized
INFO - 2018-04-12 17:13:19 --> Language Class Initialized
INFO - 2018-04-12 17:13:19 --> Config Class Initialized
INFO - 2018-04-12 17:13:19 --> Loader Class Initialized
DEBUG - 2018-04-12 17:13:19 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:13:19 --> Utf8 Class Initialized
INFO - 2018-04-12 22:43:19 --> Helper loaded: url_helper
INFO - 2018-04-12 22:43:19 --> Helper loaded: notification_helper
INFO - 2018-04-12 17:13:19 --> URI Class Initialized
INFO - 2018-04-12 22:43:19 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:43:19 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:43:19 --> Helper loaded: users_helper
INFO - 2018-04-12 17:13:19 --> Router Class Initialized
INFO - 2018-04-12 17:13:19 --> Output Class Initialized
INFO - 2018-04-12 17:13:19 --> Config Class Initialized
INFO - 2018-04-12 17:13:19 --> Hooks Class Initialized
INFO - 2018-04-12 17:13:19 --> Security Class Initialized
INFO - 2018-04-12 22:43:19 --> Database Driver Class Initialized
DEBUG - 2018-04-12 17:13:19 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:13:19 --> Utf8 Class Initialized
INFO - 2018-04-12 17:13:19 --> URI Class Initialized
DEBUG - 2018-04-12 17:13:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:13:19 --> Input Class Initialized
INFO - 2018-04-12 17:13:19 --> Language Class Initialized
INFO - 2018-04-12 17:13:19 --> Language Class Initialized
DEBUG - 2018-04-12 22:43:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 17:13:19 --> Config Class Initialized
INFO - 2018-04-12 17:13:19 --> Router Class Initialized
INFO - 2018-04-12 17:13:19 --> Loader Class Initialized
INFO - 2018-04-12 22:43:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 17:13:19 --> Output Class Initialized
INFO - 2018-04-12 22:43:19 --> Helper loaded: url_helper
INFO - 2018-04-12 17:13:19 --> Security Class Initialized
INFO - 2018-04-12 22:43:19 --> Helper loaded: notification_helper
DEBUG - 2018-04-12 17:13:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:13:19 --> Input Class Initialized
INFO - 2018-04-12 22:43:19 --> Helper loaded: form_helper
INFO - 2018-04-12 22:43:19 --> Form Validation Class Initialized
INFO - 2018-04-12 22:43:19 --> Controller Class Initialized
INFO - 2018-04-12 22:43:19 --> Helper loaded: settings_helper
INFO - 2018-04-12 17:13:19 --> Language Class Initialized
INFO - 2018-04-12 22:43:19 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:43:19 --> Helper loaded: users_helper
INFO - 2018-04-12 17:13:19 --> Language Class Initialized
INFO - 2018-04-12 17:13:19 --> Config Class Initialized
INFO - 2018-04-12 17:13:19 --> Loader Class Initialized
INFO - 2018-04-12 22:43:19 --> Helper loaded: url_helper
INFO - 2018-04-12 17:13:19 --> Config Class Initialized
INFO - 2018-04-12 17:13:19 --> Hooks Class Initialized
INFO - 2018-04-12 22:43:19 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:43:19 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:43:19 --> Helper loaded: users_helper
INFO - 2018-04-12 22:43:19 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 17:13:19 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:13:19 --> Utf8 Class Initialized
INFO - 2018-04-12 17:13:19 --> URI Class Initialized
DEBUG - 2018-04-12 22:43:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:43:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 17:13:19 --> Router Class Initialized
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-12 17:13:19 --> Output Class Initialized
INFO - 2018-04-12 17:13:19 --> Language Class Initialized
INFO - 2018-04-12 17:13:19 --> Config Class Initialized
INFO - 2018-04-12 17:13:19 --> Loader Class Initialized
ERROR - 2018-04-12 22:43:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-04-12 17:13:19 --> Security Class Initialized
INFO - 2018-04-12 22:43:19 --> Final output sent to browser
DEBUG - 2018-04-12 22:43:19 --> Total execution time: 0.1224
INFO - 2018-04-12 22:43:19 --> Helper loaded: url_helper
INFO - 2018-04-12 22:43:19 --> Helper loaded: notification_helper
DEBUG - 2018-04-12 17:13:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:13:19 --> Input Class Initialized
INFO - 2018-04-12 17:13:19 --> Language Class Initialized
INFO - 2018-04-12 22:43:19 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:43:19 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:43:19 --> Helper loaded: users_helper
INFO - 2018-04-12 22:43:19 --> Database Driver Class Initialized
INFO - 2018-04-12 17:13:19 --> Config Class Initialized
INFO - 2018-04-12 17:13:19 --> Hooks Class Initialized
INFO - 2018-04-12 22:43:19 --> Database Driver Class Initialized
DEBUG - 2018-04-12 17:13:19 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:13:19 --> Utf8 Class Initialized
DEBUG - 2018-04-12 22:43:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 17:13:19 --> URI Class Initialized
INFO - 2018-04-12 22:43:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-04-12 22:43:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:43:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 17:13:19 --> Router Class Initialized
INFO - 2018-04-12 22:43:19 --> Database Driver Class Initialized
INFO - 2018-04-12 17:13:19 --> Language Class Initialized
INFO - 2018-04-12 17:13:19 --> Config Class Initialized
INFO - 2018-04-12 17:13:19 --> Loader Class Initialized
INFO - 2018-04-12 17:13:19 --> Output Class Initialized
INFO - 2018-04-12 22:43:19 --> Helper loaded: url_helper
INFO - 2018-04-12 22:43:19 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:43:19 --> Helper loaded: settings_helper
DEBUG - 2018-04-12 22:43:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:43:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 17:13:19 --> Security Class Initialized
INFO - 2018-04-12 22:43:19 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:43:19 --> Helper loaded: users_helper
INFO - 2018-04-12 22:43:19 --> Helper loaded: form_helper
INFO - 2018-04-12 22:43:19 --> Form Validation Class Initialized
INFO - 2018-04-12 22:43:19 --> Controller Class Initialized
DEBUG - 2018-04-12 17:13:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:13:19 --> Input Class Initialized
INFO - 2018-04-12 17:13:19 --> Language Class Initialized
INFO - 2018-04-12 22:43:19 --> Helper loaded: form_helper
INFO - 2018-04-12 22:43:19 --> Form Validation Class Initialized
INFO - 2018-04-12 22:43:19 --> Controller Class Initialized
INFO - 2018-04-12 17:13:19 --> Config Class Initialized
INFO - 2018-04-12 17:13:19 --> Hooks Class Initialized
INFO - 2018-04-12 22:43:19 --> Helper loaded: form_helper
INFO - 2018-04-12 22:43:19 --> Form Validation Class Initialized
INFO - 2018-04-12 22:43:19 --> Controller Class Initialized
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Helper loaded: inflector_helper
INFO - 2018-04-12 22:43:19 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:43:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:43:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Helper loaded: inflector_helper
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-04-12 17:13:19 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:13:19 --> Utf8 Class Initialized
DEBUG - 2018-04-12 22:43:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:43:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 17:13:19 --> URI Class Initialized
DEBUG - 2018-04-12 22:43:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 17:13:19 --> Router Class Initialized
INFO - 2018-04-12 22:43:19 --> Final output sent to browser
DEBUG - 2018-04-12 22:43:19 --> Total execution time: 0.1356
INFO - 2018-04-12 17:13:19 --> Language Class Initialized
INFO - 2018-04-12 17:13:19 --> Config Class Initialized
INFO - 2018-04-12 17:13:19 --> Loader Class Initialized
INFO - 2018-04-12 22:43:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 17:13:19 --> Output Class Initialized
INFO - 2018-04-12 22:43:19 --> Helper loaded: url_helper
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:43:19 --> Helper loaded: form_helper
INFO - 2018-04-12 22:43:19 --> Form Validation Class Initialized
INFO - 2018-04-12 22:43:19 --> Helper loaded: inflector_helper
INFO - 2018-04-12 22:43:19 --> Controller Class Initialized
INFO - 2018-04-12 22:43:19 --> Helper loaded: settings_helper
INFO - 2018-04-12 17:13:19 --> Security Class Initialized
INFO - 2018-04-12 22:43:19 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Helper loaded: users_helper
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
DEBUG - 2018-04-12 17:13:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:13:19 --> Input Class Initialized
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 17:13:19 --> Language Class Initialized
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-04-12 22:43:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Helper loaded: inflector_helper
INFO - 2018-04-12 22:43:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Final output sent to browser
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
DEBUG - 2018-04-12 22:43:19 --> Total execution time: 0.1337
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
DEBUG - 2018-04-12 22:43:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-12 22:43:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:43:19 --> Database Driver Class Initialized
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 17:13:19 --> Language Class Initialized
INFO - 2018-04-12 17:13:19 --> Config Class Initialized
INFO - 2018-04-12 17:13:19 --> Loader Class Initialized
DEBUG - 2018-04-12 22:43:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:43:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:43:19 --> Final output sent to browser
DEBUG - 2018-04-12 22:43:19 --> Total execution time: 0.1822
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Helper loaded: url_helper
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:43:19 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:43:19 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-12 22:43:19 --> Helper loaded: users_helper
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Helper loaded: form_helper
INFO - 2018-04-12 22:43:19 --> Form Validation Class Initialized
INFO - 2018-04-12 22:43:19 --> Controller Class Initialized
INFO - 2018-04-12 22:43:19 --> Final output sent to browser
DEBUG - 2018-04-12 22:43:19 --> Total execution time: 0.1284
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Helper loaded: inflector_helper
INFO - 2018-04-12 22:43:19 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:43:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:43:19 --> Language file loaded: language/english/rest_controller_lang.php
DEBUG - 2018-04-12 22:43:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:43:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Final output sent to browser
DEBUG - 2018-04-12 22:43:19 --> Total execution time: 0.1194
INFO - 2018-04-12 22:43:19 --> Helper loaded: form_helper
INFO - 2018-04-12 22:43:19 --> Form Validation Class Initialized
INFO - 2018-04-12 22:43:19 --> Controller Class Initialized
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:43:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:43:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-04-12 22:43:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-04-12 22:43:19 --> Final output sent to browser
DEBUG - 2018-04-12 22:43:19 --> Total execution time: 0.1252
INFO - 2018-04-12 17:13:19 --> Config Class Initialized
INFO - 2018-04-12 17:13:19 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:13:19 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:13:19 --> Utf8 Class Initialized
INFO - 2018-04-12 17:13:19 --> URI Class Initialized
INFO - 2018-04-12 17:13:19 --> Router Class Initialized
INFO - 2018-04-12 17:13:19 --> Output Class Initialized
INFO - 2018-04-12 17:13:19 --> Security Class Initialized
DEBUG - 2018-04-12 17:13:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:13:19 --> Input Class Initialized
INFO - 2018-04-12 17:13:19 --> Language Class Initialized
INFO - 2018-04-12 17:13:19 --> Language Class Initialized
INFO - 2018-04-12 17:13:19 --> Config Class Initialized
INFO - 2018-04-12 17:13:19 --> Loader Class Initialized
INFO - 2018-04-12 22:43:19 --> Helper loaded: url_helper
INFO - 2018-04-12 22:43:19 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:43:19 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:43:19 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:43:19 --> Helper loaded: users_helper
INFO - 2018-04-12 22:43:19 --> Database Driver Class Initialized
INFO - 2018-04-12 17:13:19 --> Config Class Initialized
INFO - 2018-04-12 17:13:19 --> Hooks Class Initialized
DEBUG - 2018-04-12 22:43:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-04-12 17:13:19 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:13:19 --> Utf8 Class Initialized
INFO - 2018-04-12 22:43:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 17:13:19 --> URI Class Initialized
INFO - 2018-04-12 17:13:19 --> Router Class Initialized
INFO - 2018-04-12 22:43:19 --> Helper loaded: form_helper
INFO - 2018-04-12 22:43:19 --> Form Validation Class Initialized
INFO - 2018-04-12 22:43:19 --> Controller Class Initialized
INFO - 2018-04-12 17:13:19 --> Output Class Initialized
INFO - 2018-04-12 17:13:19 --> Security Class Initialized
DEBUG - 2018-04-12 17:13:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:13:19 --> Input Class Initialized
INFO - 2018-04-12 17:13:19 --> Language Class Initialized
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:43:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:43:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-04-12 22:43:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-04-12 22:43:19 --> Final output sent to browser
DEBUG - 2018-04-12 22:43:19 --> Total execution time: 0.1021
INFO - 2018-04-12 17:13:19 --> Config Class Initialized
INFO - 2018-04-12 17:13:19 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:13:19 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:13:19 --> Utf8 Class Initialized
INFO - 2018-04-12 17:13:19 --> Language Class Initialized
INFO - 2018-04-12 17:13:19 --> Config Class Initialized
INFO - 2018-04-12 17:13:19 --> Loader Class Initialized
INFO - 2018-04-12 17:13:19 --> URI Class Initialized
INFO - 2018-04-12 22:43:19 --> Helper loaded: url_helper
INFO - 2018-04-12 22:43:19 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:43:19 --> Helper loaded: settings_helper
INFO - 2018-04-12 17:13:19 --> Router Class Initialized
INFO - 2018-04-12 22:43:19 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:43:19 --> Helper loaded: users_helper
INFO - 2018-04-12 17:13:19 --> Output Class Initialized
INFO - 2018-04-12 17:13:19 --> Security Class Initialized
DEBUG - 2018-04-12 17:13:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:13:19 --> Input Class Initialized
INFO - 2018-04-12 17:13:19 --> Language Class Initialized
INFO - 2018-04-12 22:43:19 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:43:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:43:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 17:13:19 --> Language Class Initialized
INFO - 2018-04-12 17:13:19 --> Config Class Initialized
INFO - 2018-04-12 17:13:19 --> Loader Class Initialized
INFO - 2018-04-12 22:43:19 --> Helper loaded: form_helper
INFO - 2018-04-12 22:43:19 --> Form Validation Class Initialized
INFO - 2018-04-12 22:43:19 --> Helper loaded: url_helper
INFO - 2018-04-12 22:43:19 --> Controller Class Initialized
INFO - 2018-04-12 22:43:19 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:43:19 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:43:19 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:43:19 --> Helper loaded: users_helper
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:43:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:43:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Database Driver Class Initialized
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-04-12 22:43:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
DEBUG - 2018-04-12 22:43:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:43:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:43:19 --> Final output sent to browser
DEBUG - 2018-04-12 22:43:19 --> Total execution time: 0.1058
INFO - 2018-04-12 22:43:19 --> Helper loaded: form_helper
INFO - 2018-04-12 22:43:19 --> Form Validation Class Initialized
INFO - 2018-04-12 22:43:19 --> Controller Class Initialized
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:43:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:43:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Final output sent to browser
DEBUG - 2018-04-12 22:43:19 --> Total execution time: 0.1107
INFO - 2018-04-12 17:13:19 --> Config Class Initialized
INFO - 2018-04-12 17:13:19 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:13:19 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:13:19 --> Utf8 Class Initialized
INFO - 2018-04-12 17:13:19 --> URI Class Initialized
INFO - 2018-04-12 17:13:19 --> Router Class Initialized
INFO - 2018-04-12 17:13:19 --> Output Class Initialized
INFO - 2018-04-12 17:13:19 --> Security Class Initialized
DEBUG - 2018-04-12 17:13:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:13:19 --> Input Class Initialized
INFO - 2018-04-12 17:13:19 --> Language Class Initialized
INFO - 2018-04-12 17:13:19 --> Language Class Initialized
INFO - 2018-04-12 17:13:19 --> Config Class Initialized
INFO - 2018-04-12 17:13:19 --> Loader Class Initialized
INFO - 2018-04-12 22:43:19 --> Helper loaded: url_helper
INFO - 2018-04-12 22:43:19 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:43:19 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:43:19 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:43:19 --> Helper loaded: users_helper
INFO - 2018-04-12 22:43:19 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:43:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:43:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:43:19 --> Helper loaded: form_helper
INFO - 2018-04-12 22:43:19 --> Form Validation Class Initialized
INFO - 2018-04-12 22:43:19 --> Controller Class Initialized
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:43:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:43:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Model Class Initialized
INFO - 2018-04-12 22:43:19 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-12 22:43:19 --> Final output sent to browser
DEBUG - 2018-04-12 22:43:19 --> Total execution time: 0.1045
INFO - 2018-04-12 17:13:24 --> Config Class Initialized
INFO - 2018-04-12 17:13:24 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:13:24 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:13:24 --> Utf8 Class Initialized
INFO - 2018-04-12 17:13:24 --> Config Class Initialized
INFO - 2018-04-12 17:13:24 --> Hooks Class Initialized
INFO - 2018-04-12 17:13:24 --> URI Class Initialized
DEBUG - 2018-04-12 17:13:24 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:13:24 --> Utf8 Class Initialized
INFO - 2018-04-12 17:13:24 --> Router Class Initialized
INFO - 2018-04-12 17:13:24 --> URI Class Initialized
INFO - 2018-04-12 17:13:24 --> Output Class Initialized
INFO - 2018-04-12 17:13:24 --> Router Class Initialized
INFO - 2018-04-12 17:13:24 --> Security Class Initialized
DEBUG - 2018-04-12 17:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:13:24 --> Input Class Initialized
INFO - 2018-04-12 17:13:24 --> Output Class Initialized
INFO - 2018-04-12 17:13:24 --> Language Class Initialized
INFO - 2018-04-12 17:13:24 --> Security Class Initialized
DEBUG - 2018-04-12 17:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:13:24 --> Input Class Initialized
INFO - 2018-04-12 17:13:24 --> Language Class Initialized
INFO - 2018-04-12 17:13:24 --> Language Class Initialized
INFO - 2018-04-12 17:13:24 --> Config Class Initialized
INFO - 2018-04-12 17:13:24 --> Loader Class Initialized
INFO - 2018-04-12 22:43:24 --> Helper loaded: url_helper
INFO - 2018-04-12 22:43:24 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:43:24 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:43:24 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:43:24 --> Helper loaded: users_helper
INFO - 2018-04-12 17:13:24 --> Language Class Initialized
INFO - 2018-04-12 17:13:24 --> Config Class Initialized
INFO - 2018-04-12 17:13:24 --> Loader Class Initialized
INFO - 2018-04-12 22:43:24 --> Helper loaded: url_helper
INFO - 2018-04-12 22:43:24 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:43:24 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:43:24 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:43:24 --> Helper loaded: users_helper
INFO - 2018-04-12 22:43:24 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:43:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:43:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:43:24 --> Helper loaded: form_helper
INFO - 2018-04-12 22:43:24 --> Form Validation Class Initialized
INFO - 2018-04-12 22:43:24 --> Controller Class Initialized
INFO - 2018-04-12 22:43:24 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:43:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:43:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:43:24 --> Model Class Initialized
INFO - 2018-04-12 22:43:24 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:43:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:43:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:43:24 --> Model Class Initialized
INFO - 2018-04-12 22:43:24 --> Helper loaded: form_helper
INFO - 2018-04-12 22:43:24 --> Form Validation Class Initialized
INFO - 2018-04-12 22:43:24 --> Controller Class Initialized
INFO - 2018-04-12 22:43:24 --> Model Class Initialized
INFO - 2018-04-12 22:43:24 --> Model Class Initialized
INFO - 2018-04-12 22:43:24 --> Model Class Initialized
INFO - 2018-04-12 22:43:24 --> Model Class Initialized
INFO - 2018-04-12 22:43:24 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-12 22:43:24 --> Model Class Initialized
INFO - 2018-04-12 22:43:24 --> Final output sent to browser
DEBUG - 2018-04-12 22:43:24 --> Total execution time: 0.1024
INFO - 2018-04-12 22:43:24 --> Model Class Initialized
INFO - 2018-04-12 22:43:24 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:43:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:43:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:43:24 --> Model Class Initialized
INFO - 2018-04-12 22:43:24 --> Model Class Initialized
INFO - 2018-04-12 22:43:24 --> Model Class Initialized
INFO - 2018-04-12 22:43:24 --> Model Class Initialized
INFO - 2018-04-12 22:43:24 --> Model Class Initialized
INFO - 2018-04-12 22:43:24 --> Model Class Initialized
INFO - 2018-04-12 22:43:24 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-04-12 22:43:24 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-04-12 22:43:24 --> Final output sent to browser
DEBUG - 2018-04-12 22:43:24 --> Total execution time: 0.1146
INFO - 2018-04-12 17:13:39 --> Config Class Initialized
INFO - 2018-04-12 17:13:39 --> Hooks Class Initialized
INFO - 2018-04-12 17:13:39 --> Config Class Initialized
INFO - 2018-04-12 17:13:39 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:13:39 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:13:39 --> Utf8 Class Initialized
INFO - 2018-04-12 17:13:39 --> URI Class Initialized
DEBUG - 2018-04-12 17:13:39 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:13:39 --> Utf8 Class Initialized
INFO - 2018-04-12 17:13:39 --> Config Class Initialized
INFO - 2018-04-12 17:13:39 --> URI Class Initialized
INFO - 2018-04-12 17:13:39 --> Hooks Class Initialized
INFO - 2018-04-12 17:13:39 --> Router Class Initialized
INFO - 2018-04-12 17:13:39 --> Output Class Initialized
INFO - 2018-04-12 17:13:39 --> Router Class Initialized
DEBUG - 2018-04-12 17:13:39 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:13:39 --> Utf8 Class Initialized
INFO - 2018-04-12 17:13:39 --> Security Class Initialized
INFO - 2018-04-12 17:13:39 --> URI Class Initialized
INFO - 2018-04-12 17:13:39 --> Output Class Initialized
DEBUG - 2018-04-12 17:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:13:39 --> Input Class Initialized
INFO - 2018-04-12 17:13:39 --> Language Class Initialized
INFO - 2018-04-12 17:13:39 --> Security Class Initialized
INFO - 2018-04-12 17:13:39 --> Router Class Initialized
DEBUG - 2018-04-12 17:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:13:39 --> Input Class Initialized
INFO - 2018-04-12 17:13:39 --> Language Class Initialized
INFO - 2018-04-12 17:13:39 --> Output Class Initialized
INFO - 2018-04-12 17:13:39 --> Security Class Initialized
DEBUG - 2018-04-12 17:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:13:39 --> Input Class Initialized
INFO - 2018-04-12 17:13:39 --> Language Class Initialized
INFO - 2018-04-12 17:13:39 --> Language Class Initialized
INFO - 2018-04-12 17:13:39 --> Config Class Initialized
INFO - 2018-04-12 17:13:39 --> Loader Class Initialized
INFO - 2018-04-12 22:43:39 --> Helper loaded: url_helper
INFO - 2018-04-12 22:43:39 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:43:39 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:43:39 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:43:39 --> Helper loaded: users_helper
INFO - 2018-04-12 17:13:39 --> Language Class Initialized
INFO - 2018-04-12 17:13:39 --> Config Class Initialized
INFO - 2018-04-12 17:13:39 --> Loader Class Initialized
INFO - 2018-04-12 22:43:39 --> Helper loaded: url_helper
INFO - 2018-04-12 22:43:39 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:43:39 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:43:39 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:43:39 --> Helper loaded: users_helper
INFO - 2018-04-12 17:13:39 --> Language Class Initialized
INFO - 2018-04-12 17:13:39 --> Config Class Initialized
INFO - 2018-04-12 17:13:39 --> Loader Class Initialized
INFO - 2018-04-12 22:43:39 --> Helper loaded: url_helper
INFO - 2018-04-12 22:43:39 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:43:39 --> Database Driver Class Initialized
INFO - 2018-04-12 22:43:39 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:43:39 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:43:39 --> Helper loaded: users_helper
DEBUG - 2018-04-12 22:43:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:43:39 --> Database Driver Class Initialized
INFO - 2018-04-12 22:43:39 --> Helper loaded: form_helper
INFO - 2018-04-12 22:43:39 --> Form Validation Class Initialized
INFO - 2018-04-12 22:43:39 --> Controller Class Initialized
DEBUG - 2018-04-12 22:43:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:43:39 --> Database Driver Class Initialized
INFO - 2018-04-12 22:43:39 --> Helper loaded: form_helper
INFO - 2018-04-12 22:43:39 --> Form Validation Class Initialized
INFO - 2018-04-12 22:43:39 --> Controller Class Initialized
INFO - 2018-04-12 22:43:39 --> Model Class Initialized
DEBUG - 2018-04-12 22:43:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:43:39 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:43:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:43:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:43:39 --> Model Class Initialized
INFO - 2018-04-12 22:43:39 --> Model Class Initialized
INFO - 2018-04-12 22:43:39 --> Model Class Initialized
INFO - 2018-04-12 22:43:39 --> Model Class Initialized
INFO - 2018-04-12 22:43:39 --> Model Class Initialized
INFO - 2018-04-12 22:43:39 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-12 22:43:39 --> Helper loaded: form_helper
INFO - 2018-04-12 22:43:39 --> Form Validation Class Initialized
INFO - 2018-04-12 22:43:39 --> Controller Class Initialized
INFO - 2018-04-12 22:43:39 --> Helper loaded: inflector_helper
INFO - 2018-04-12 22:43:39 --> Final output sent to browser
DEBUG - 2018-04-12 22:43:39 --> Total execution time: 0.1056
DEBUG - 2018-04-12 22:43:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:43:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:43:39 --> Model Class Initialized
INFO - 2018-04-12 22:43:39 --> Model Class Initialized
INFO - 2018-04-12 22:43:39 --> Model Class Initialized
INFO - 2018-04-12 22:43:39 --> Model Class Initialized
INFO - 2018-04-12 22:43:39 --> Model Class Initialized
INFO - 2018-04-12 22:43:39 --> Model Class Initialized
INFO - 2018-04-12 22:43:39 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-12 22:43:39 --> Model Class Initialized
ERROR - 2018-04-12 22:43:39 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-04-12 22:43:39 --> Helper loaded: inflector_helper
INFO - 2018-04-12 22:43:39 --> Final output sent to browser
DEBUG - 2018-04-12 22:43:39 --> Total execution time: 0.1123
DEBUG - 2018-04-12 22:43:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:43:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:43:39 --> Model Class Initialized
INFO - 2018-04-12 22:43:39 --> Model Class Initialized
INFO - 2018-04-12 22:43:39 --> Model Class Initialized
INFO - 2018-04-12 22:43:39 --> Model Class Initialized
INFO - 2018-04-12 22:43:39 --> Model Class Initialized
INFO - 2018-04-12 22:43:39 --> Model Class Initialized
INFO - 2018-04-12 22:43:39 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-04-12 22:43:39 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-04-12 22:43:39 --> Final output sent to browser
DEBUG - 2018-04-12 22:43:39 --> Total execution time: 0.1214
INFO - 2018-04-12 17:13:43 --> Config Class Initialized
INFO - 2018-04-12 17:13:43 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:13:43 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:13:43 --> Utf8 Class Initialized
INFO - 2018-04-12 17:13:43 --> URI Class Initialized
INFO - 2018-04-12 17:13:43 --> Config Class Initialized
INFO - 2018-04-12 17:13:43 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:13:43 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:13:43 --> Utf8 Class Initialized
INFO - 2018-04-12 17:13:43 --> Router Class Initialized
INFO - 2018-04-12 17:13:43 --> URI Class Initialized
INFO - 2018-04-12 17:13:43 --> Output Class Initialized
INFO - 2018-04-12 17:13:43 --> Security Class Initialized
INFO - 2018-04-12 17:13:43 --> Router Class Initialized
DEBUG - 2018-04-12 17:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:13:43 --> Input Class Initialized
INFO - 2018-04-12 17:13:43 --> Output Class Initialized
INFO - 2018-04-12 17:13:43 --> Language Class Initialized
INFO - 2018-04-12 17:13:43 --> Security Class Initialized
DEBUG - 2018-04-12 17:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:13:43 --> Input Class Initialized
INFO - 2018-04-12 17:13:43 --> Language Class Initialized
INFO - 2018-04-12 17:13:43 --> Language Class Initialized
INFO - 2018-04-12 17:13:43 --> Config Class Initialized
INFO - 2018-04-12 17:13:43 --> Loader Class Initialized
INFO - 2018-04-12 17:13:43 --> Language Class Initialized
INFO - 2018-04-12 17:13:43 --> Config Class Initialized
INFO - 2018-04-12 17:13:43 --> Loader Class Initialized
INFO - 2018-04-12 22:43:43 --> Helper loaded: url_helper
INFO - 2018-04-12 22:43:43 --> Helper loaded: url_helper
INFO - 2018-04-12 22:43:43 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:43:43 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:43:43 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:43:43 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:43:43 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:43:43 --> Helper loaded: users_helper
INFO - 2018-04-12 22:43:43 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:43:43 --> Helper loaded: users_helper
INFO - 2018-04-12 22:43:43 --> Database Driver Class Initialized
INFO - 2018-04-12 22:43:43 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:43:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:43:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-04-12 22:43:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:43:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:43:43 --> Helper loaded: form_helper
INFO - 2018-04-12 22:43:43 --> Form Validation Class Initialized
INFO - 2018-04-12 22:43:43 --> Controller Class Initialized
INFO - 2018-04-12 22:43:43 --> Helper loaded: form_helper
INFO - 2018-04-12 22:43:43 --> Form Validation Class Initialized
INFO - 2018-04-12 22:43:43 --> Controller Class Initialized
INFO - 2018-04-12 22:43:43 --> Model Class Initialized
INFO - 2018-04-12 22:43:43 --> Helper loaded: inflector_helper
INFO - 2018-04-12 22:43:43 --> Model Class Initialized
INFO - 2018-04-12 22:43:43 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:43:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-04-12 22:43:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:43:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:43:43 --> Model Class Initialized
INFO - 2018-04-12 22:43:43 --> Model Class Initialized
INFO - 2018-04-12 22:43:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:43:43 --> Model Class Initialized
INFO - 2018-04-12 22:43:43 --> Model Class Initialized
INFO - 2018-04-12 22:43:43 --> Model Class Initialized
INFO - 2018-04-12 22:43:43 --> Model Class Initialized
INFO - 2018-04-12 22:43:43 --> Model Class Initialized
INFO - 2018-04-12 22:43:43 --> Model Class Initialized
INFO - 2018-04-12 22:43:43 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-12 22:43:43 --> Model Class Initialized
INFO - 2018-04-12 22:43:43 --> Model Class Initialized
INFO - 2018-04-12 22:43:43 --> Model Class Initialized
INFO - 2018-04-12 22:43:43 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-04-12 22:43:43 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-04-12 22:43:43 --> Model Class Initialized
INFO - 2018-04-12 22:43:43 --> Final output sent to browser
DEBUG - 2018-04-12 22:43:43 --> Total execution time: 0.1018
INFO - 2018-04-12 22:43:43 --> Final output sent to browser
DEBUG - 2018-04-12 22:43:43 --> Total execution time: 0.1013
INFO - 2018-04-12 17:13:50 --> Config Class Initialized
INFO - 2018-04-12 17:13:50 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:13:50 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:13:50 --> Utf8 Class Initialized
INFO - 2018-04-12 17:13:50 --> URI Class Initialized
INFO - 2018-04-12 17:13:50 --> Router Class Initialized
INFO - 2018-04-12 17:13:50 --> Output Class Initialized
INFO - 2018-04-12 17:13:50 --> Security Class Initialized
DEBUG - 2018-04-12 17:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:13:50 --> Input Class Initialized
INFO - 2018-04-12 17:13:50 --> Language Class Initialized
INFO - 2018-04-12 17:13:50 --> Language Class Initialized
INFO - 2018-04-12 17:13:50 --> Config Class Initialized
INFO - 2018-04-12 17:13:50 --> Loader Class Initialized
INFO - 2018-04-12 22:43:50 --> Helper loaded: url_helper
INFO - 2018-04-12 22:43:50 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:43:50 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:43:50 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:43:50 --> Helper loaded: users_helper
INFO - 2018-04-12 22:43:50 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:43:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:43:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:43:50 --> Helper loaded: form_helper
INFO - 2018-04-12 22:43:50 --> Form Validation Class Initialized
INFO - 2018-04-12 22:43:50 --> Controller Class Initialized
INFO - 2018-04-12 22:43:50 --> Model Class Initialized
INFO - 2018-04-12 22:43:50 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:43:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:43:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:43:50 --> Model Class Initialized
INFO - 2018-04-12 22:43:50 --> Model Class Initialized
INFO - 2018-04-12 22:43:50 --> Model Class Initialized
INFO - 2018-04-12 22:43:50 --> Model Class Initialized
INFO - 2018-04-12 22:43:50 --> Model Class Initialized
INFO - 2018-04-12 22:43:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-12 22:43:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-12 22:43:51 --> Final output sent to browser
DEBUG - 2018-04-12 22:43:51 --> Total execution time: 0.1651
INFO - 2018-04-12 17:13:51 --> Config Class Initialized
INFO - 2018-04-12 17:13:51 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:13:51 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:13:51 --> Utf8 Class Initialized
INFO - 2018-04-12 17:13:51 --> URI Class Initialized
INFO - 2018-04-12 17:13:51 --> Router Class Initialized
INFO - 2018-04-12 17:13:51 --> Output Class Initialized
INFO - 2018-04-12 17:13:51 --> Security Class Initialized
DEBUG - 2018-04-12 17:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:13:51 --> Input Class Initialized
INFO - 2018-04-12 17:13:51 --> Language Class Initialized
INFO - 2018-04-12 17:13:51 --> Language Class Initialized
INFO - 2018-04-12 17:13:51 --> Config Class Initialized
INFO - 2018-04-12 17:13:51 --> Loader Class Initialized
INFO - 2018-04-12 22:43:51 --> Helper loaded: url_helper
INFO - 2018-04-12 22:43:51 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:43:51 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:43:51 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:43:51 --> Helper loaded: users_helper
INFO - 2018-04-12 22:43:51 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:43:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:43:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:43:51 --> Helper loaded: form_helper
INFO - 2018-04-12 22:43:51 --> Form Validation Class Initialized
INFO - 2018-04-12 22:43:51 --> Controller Class Initialized
INFO - 2018-04-12 22:43:51 --> Model Class Initialized
INFO - 2018-04-12 22:43:51 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:43:51 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:43:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:43:51 --> Model Class Initialized
INFO - 2018-04-12 22:43:51 --> Model Class Initialized
INFO - 2018-04-12 22:43:51 --> Model Class Initialized
INFO - 2018-04-12 22:43:51 --> Model Class Initialized
INFO - 2018-04-12 22:43:51 --> Model Class Initialized
INFO - 2018-04-12 22:43:51 --> Model Class Initialized
INFO - 2018-04-12 22:43:51 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-04-12 22:43:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-04-12 22:43:51 --> Final output sent to browser
DEBUG - 2018-04-12 22:43:51 --> Total execution time: 0.1125
INFO - 2018-04-12 17:13:52 --> Config Class Initialized
INFO - 2018-04-12 17:13:52 --> Hooks Class Initialized
INFO - 2018-04-12 17:13:52 --> Config Class Initialized
INFO - 2018-04-12 17:13:52 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:13:52 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:13:52 --> Utf8 Class Initialized
DEBUG - 2018-04-12 17:13:52 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:13:52 --> Utf8 Class Initialized
INFO - 2018-04-12 17:13:52 --> URI Class Initialized
INFO - 2018-04-12 17:13:52 --> URI Class Initialized
INFO - 2018-04-12 17:13:52 --> Router Class Initialized
INFO - 2018-04-12 17:13:52 --> Router Class Initialized
INFO - 2018-04-12 17:13:52 --> Output Class Initialized
INFO - 2018-04-12 17:13:52 --> Output Class Initialized
INFO - 2018-04-12 17:13:52 --> Security Class Initialized
INFO - 2018-04-12 17:13:52 --> Security Class Initialized
DEBUG - 2018-04-12 17:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:13:52 --> Input Class Initialized
DEBUG - 2018-04-12 17:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:13:52 --> Input Class Initialized
INFO - 2018-04-12 17:13:52 --> Language Class Initialized
INFO - 2018-04-12 17:13:52 --> Language Class Initialized
INFO - 2018-04-12 17:13:52 --> Language Class Initialized
INFO - 2018-04-12 17:13:52 --> Config Class Initialized
INFO - 2018-04-12 17:13:52 --> Loader Class Initialized
INFO - 2018-04-12 22:43:52 --> Helper loaded: url_helper
INFO - 2018-04-12 17:13:52 --> Language Class Initialized
INFO - 2018-04-12 17:13:52 --> Config Class Initialized
INFO - 2018-04-12 17:13:52 --> Loader Class Initialized
INFO - 2018-04-12 22:43:52 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:43:52 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:43:52 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:43:52 --> Helper loaded: users_helper
INFO - 2018-04-12 22:43:52 --> Helper loaded: url_helper
INFO - 2018-04-12 22:43:52 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:43:52 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:43:52 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:43:52 --> Helper loaded: users_helper
INFO - 2018-04-12 22:43:52 --> Database Driver Class Initialized
INFO - 2018-04-12 22:43:52 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:43:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:43:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-04-12 22:43:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:43:52 --> Helper loaded: form_helper
INFO - 2018-04-12 22:43:52 --> Form Validation Class Initialized
INFO - 2018-04-12 22:43:52 --> Controller Class Initialized
INFO - 2018-04-12 22:43:52 --> Helper loaded: form_helper
INFO - 2018-04-12 22:43:52 --> Form Validation Class Initialized
INFO - 2018-04-12 22:43:52 --> Controller Class Initialized
INFO - 2018-04-12 22:43:52 --> Model Class Initialized
INFO - 2018-04-12 22:43:52 --> Helper loaded: inflector_helper
INFO - 2018-04-12 22:43:52 --> Model Class Initialized
INFO - 2018-04-12 22:43:52 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:43:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:43:52 --> Language file loaded: language/english/rest_controller_lang.php
DEBUG - 2018-04-12 22:43:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:43:52 --> Model Class Initialized
INFO - 2018-04-12 22:43:52 --> Model Class Initialized
INFO - 2018-04-12 22:43:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:43:52 --> Model Class Initialized
INFO - 2018-04-12 22:43:52 --> Model Class Initialized
INFO - 2018-04-12 22:43:52 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-12 22:43:52 --> Model Class Initialized
INFO - 2018-04-12 22:43:52 --> Model Class Initialized
INFO - 2018-04-12 22:43:52 --> Model Class Initialized
INFO - 2018-04-12 22:43:52 --> Model Class Initialized
INFO - 2018-04-12 22:43:52 --> Model Class Initialized
INFO - 2018-04-12 22:43:52 --> Model Class Initialized
INFO - 2018-04-12 22:43:52 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-12 22:43:52 --> Final output sent to browser
DEBUG - 2018-04-12 22:43:52 --> Total execution time: 0.1017
ERROR - 2018-04-12 22:43:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-04-12 22:43:52 --> Final output sent to browser
DEBUG - 2018-04-12 22:43:52 --> Total execution time: 0.1074
INFO - 2018-04-12 17:13:54 --> Config Class Initialized
INFO - 2018-04-12 17:13:54 --> Hooks Class Initialized
INFO - 2018-04-12 17:13:54 --> Config Class Initialized
INFO - 2018-04-12 17:13:54 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:13:54 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:13:54 --> Utf8 Class Initialized
INFO - 2018-04-12 17:13:54 --> URI Class Initialized
DEBUG - 2018-04-12 17:13:54 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:13:54 --> Utf8 Class Initialized
INFO - 2018-04-12 17:13:54 --> URI Class Initialized
INFO - 2018-04-12 17:13:54 --> Router Class Initialized
INFO - 2018-04-12 17:13:54 --> Router Class Initialized
INFO - 2018-04-12 17:13:54 --> Output Class Initialized
INFO - 2018-04-12 17:13:54 --> Output Class Initialized
INFO - 2018-04-12 17:13:54 --> Security Class Initialized
INFO - 2018-04-12 17:13:54 --> Security Class Initialized
DEBUG - 2018-04-12 17:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:13:54 --> Input Class Initialized
INFO - 2018-04-12 17:13:54 --> Language Class Initialized
DEBUG - 2018-04-12 17:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:13:54 --> Input Class Initialized
INFO - 2018-04-12 17:13:54 --> Language Class Initialized
INFO - 2018-04-12 17:13:54 --> Language Class Initialized
INFO - 2018-04-12 17:13:54 --> Config Class Initialized
INFO - 2018-04-12 17:13:54 --> Loader Class Initialized
INFO - 2018-04-12 22:43:54 --> Helper loaded: url_helper
INFO - 2018-04-12 22:43:54 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:43:54 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:43:54 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:43:54 --> Helper loaded: users_helper
INFO - 2018-04-12 17:13:54 --> Language Class Initialized
INFO - 2018-04-12 17:13:54 --> Config Class Initialized
INFO - 2018-04-12 17:13:54 --> Loader Class Initialized
INFO - 2018-04-12 22:43:54 --> Helper loaded: url_helper
INFO - 2018-04-12 22:43:54 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:43:54 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:43:54 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:43:54 --> Helper loaded: users_helper
INFO - 2018-04-12 22:43:54 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:43:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:43:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:43:54 --> Database Driver Class Initialized
INFO - 2018-04-12 22:43:54 --> Helper loaded: form_helper
INFO - 2018-04-12 22:43:54 --> Form Validation Class Initialized
INFO - 2018-04-12 22:43:54 --> Controller Class Initialized
DEBUG - 2018-04-12 22:43:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:43:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:43:54 --> Model Class Initialized
INFO - 2018-04-12 22:43:54 --> Helper loaded: inflector_helper
INFO - 2018-04-12 22:43:54 --> Helper loaded: form_helper
INFO - 2018-04-12 22:43:54 --> Form Validation Class Initialized
INFO - 2018-04-12 22:43:54 --> Controller Class Initialized
DEBUG - 2018-04-12 22:43:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:43:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:43:54 --> Model Class Initialized
INFO - 2018-04-12 22:43:54 --> Model Class Initialized
INFO - 2018-04-12 22:43:54 --> Model Class Initialized
INFO - 2018-04-12 22:43:54 --> Model Class Initialized
INFO - 2018-04-12 22:43:54 --> Model Class Initialized
INFO - 2018-04-12 22:43:54 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-12 22:43:54 --> Model Class Initialized
INFO - 2018-04-12 22:43:54 --> Model Class Initialized
INFO - 2018-04-12 22:43:54 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:43:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:43:54 --> Final output sent to browser
DEBUG - 2018-04-12 22:43:54 --> Total execution time: 0.1088
INFO - 2018-04-12 22:43:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:43:54 --> Model Class Initialized
INFO - 2018-04-12 22:43:54 --> Model Class Initialized
INFO - 2018-04-12 22:43:54 --> Model Class Initialized
INFO - 2018-04-12 22:43:54 --> Model Class Initialized
INFO - 2018-04-12 22:43:54 --> Model Class Initialized
INFO - 2018-04-12 22:43:54 --> Model Class Initialized
INFO - 2018-04-12 22:43:54 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-04-12 22:43:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-04-12 22:43:54 --> Final output sent to browser
DEBUG - 2018-04-12 22:43:54 --> Total execution time: 0.1137
INFO - 2018-04-12 17:13:57 --> Config Class Initialized
INFO - 2018-04-12 17:13:57 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:13:57 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:13:57 --> Utf8 Class Initialized
INFO - 2018-04-12 17:13:57 --> Config Class Initialized
INFO - 2018-04-12 17:13:57 --> Hooks Class Initialized
INFO - 2018-04-12 17:13:57 --> URI Class Initialized
DEBUG - 2018-04-12 17:13:57 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:13:57 --> Utf8 Class Initialized
INFO - 2018-04-12 17:13:57 --> Router Class Initialized
INFO - 2018-04-12 17:13:57 --> URI Class Initialized
INFO - 2018-04-12 17:13:57 --> Output Class Initialized
INFO - 2018-04-12 17:13:57 --> Router Class Initialized
INFO - 2018-04-12 17:13:57 --> Security Class Initialized
DEBUG - 2018-04-12 17:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:13:57 --> Input Class Initialized
INFO - 2018-04-12 17:13:57 --> Output Class Initialized
INFO - 2018-04-12 17:13:57 --> Language Class Initialized
INFO - 2018-04-12 17:13:57 --> Security Class Initialized
DEBUG - 2018-04-12 17:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:13:57 --> Input Class Initialized
INFO - 2018-04-12 17:13:57 --> Language Class Initialized
INFO - 2018-04-12 17:13:57 --> Language Class Initialized
INFO - 2018-04-12 17:13:57 --> Config Class Initialized
INFO - 2018-04-12 17:13:57 --> Loader Class Initialized
INFO - 2018-04-12 22:43:57 --> Helper loaded: url_helper
INFO - 2018-04-12 22:43:57 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:43:57 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:43:57 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:43:57 --> Helper loaded: users_helper
INFO - 2018-04-12 17:13:57 --> Language Class Initialized
INFO - 2018-04-12 17:13:57 --> Config Class Initialized
INFO - 2018-04-12 17:13:57 --> Loader Class Initialized
INFO - 2018-04-12 22:43:57 --> Database Driver Class Initialized
INFO - 2018-04-12 22:43:57 --> Helper loaded: url_helper
INFO - 2018-04-12 22:43:57 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:43:57 --> Helper loaded: settings_helper
DEBUG - 2018-04-12 22:43:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:43:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:43:57 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:43:57 --> Helper loaded: users_helper
INFO - 2018-04-12 22:43:57 --> Helper loaded: form_helper
INFO - 2018-04-12 22:43:57 --> Form Validation Class Initialized
INFO - 2018-04-12 22:43:57 --> Controller Class Initialized
INFO - 2018-04-12 22:43:57 --> Model Class Initialized
INFO - 2018-04-12 22:43:57 --> Helper loaded: inflector_helper
INFO - 2018-04-12 22:43:57 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:43:57 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:43:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:43:57 --> Model Class Initialized
INFO - 2018-04-12 22:43:57 --> Model Class Initialized
INFO - 2018-04-12 22:43:57 --> Model Class Initialized
INFO - 2018-04-12 22:43:57 --> Model Class Initialized
INFO - 2018-04-12 22:43:57 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-04-12 22:43:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:43:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:43:57 --> Final output sent to browser
DEBUG - 2018-04-12 22:43:57 --> Total execution time: 0.0797
INFO - 2018-04-12 22:43:57 --> Helper loaded: form_helper
INFO - 2018-04-12 22:43:57 --> Form Validation Class Initialized
INFO - 2018-04-12 22:43:57 --> Controller Class Initialized
INFO - 2018-04-12 22:43:57 --> Model Class Initialized
INFO - 2018-04-12 22:43:57 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:43:57 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:43:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:43:57 --> Model Class Initialized
INFO - 2018-04-12 22:43:57 --> Model Class Initialized
INFO - 2018-04-12 22:43:57 --> Model Class Initialized
INFO - 2018-04-12 22:43:57 --> Model Class Initialized
INFO - 2018-04-12 22:43:57 --> Model Class Initialized
INFO - 2018-04-12 22:43:57 --> Model Class Initialized
INFO - 2018-04-12 22:43:57 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-04-12 22:43:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-04-12 22:43:57 --> Final output sent to browser
DEBUG - 2018-04-12 22:43:57 --> Total execution time: 0.1068
INFO - 2018-04-12 17:13:58 --> Config Class Initialized
INFO - 2018-04-12 17:13:58 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:13:58 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:13:58 --> Utf8 Class Initialized
INFO - 2018-04-12 17:13:58 --> URI Class Initialized
INFO - 2018-04-12 17:13:58 --> Router Class Initialized
INFO - 2018-04-12 17:13:58 --> Output Class Initialized
INFO - 2018-04-12 17:13:58 --> Security Class Initialized
DEBUG - 2018-04-12 17:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:13:58 --> Input Class Initialized
INFO - 2018-04-12 17:13:58 --> Language Class Initialized
INFO - 2018-04-12 17:13:58 --> Language Class Initialized
INFO - 2018-04-12 17:13:58 --> Config Class Initialized
INFO - 2018-04-12 17:13:58 --> Loader Class Initialized
INFO - 2018-04-12 22:43:58 --> Helper loaded: url_helper
INFO - 2018-04-12 22:43:58 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:43:58 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:43:58 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:43:58 --> Helper loaded: users_helper
INFO - 2018-04-12 22:43:58 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:43:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:43:58 --> Helper loaded: form_helper
INFO - 2018-04-12 22:43:58 --> Form Validation Class Initialized
INFO - 2018-04-12 22:43:58 --> Controller Class Initialized
INFO - 2018-04-12 22:43:58 --> Model Class Initialized
INFO - 2018-04-12 22:43:58 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:43:58 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:43:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:43:58 --> Model Class Initialized
INFO - 2018-04-12 22:43:58 --> Model Class Initialized
INFO - 2018-04-12 22:43:58 --> Model Class Initialized
INFO - 2018-04-12 22:43:58 --> Model Class Initialized
INFO - 2018-04-12 22:43:58 --> Model Class Initialized
INFO - 2018-04-12 22:43:58 --> Model Class Initialized
INFO - 2018-04-12 22:43:58 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-04-12 22:43:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-04-12 22:43:58 --> Final output sent to browser
DEBUG - 2018-04-12 22:43:58 --> Total execution time: 0.1051
INFO - 2018-04-12 17:13:59 --> Config Class Initialized
INFO - 2018-04-12 17:13:59 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:13:59 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:13:59 --> Utf8 Class Initialized
INFO - 2018-04-12 17:13:59 --> URI Class Initialized
INFO - 2018-04-12 17:13:59 --> Router Class Initialized
INFO - 2018-04-12 17:13:59 --> Output Class Initialized
INFO - 2018-04-12 17:13:59 --> Security Class Initialized
DEBUG - 2018-04-12 17:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:13:59 --> Input Class Initialized
INFO - 2018-04-12 17:13:59 --> Language Class Initialized
INFO - 2018-04-12 17:13:59 --> Config Class Initialized
INFO - 2018-04-12 17:13:59 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:13:59 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:13:59 --> Utf8 Class Initialized
INFO - 2018-04-12 17:13:59 --> URI Class Initialized
INFO - 2018-04-12 17:13:59 --> Router Class Initialized
INFO - 2018-04-12 17:13:59 --> Language Class Initialized
INFO - 2018-04-12 17:13:59 --> Config Class Initialized
INFO - 2018-04-12 17:13:59 --> Loader Class Initialized
INFO - 2018-04-12 17:13:59 --> Output Class Initialized
INFO - 2018-04-12 22:43:59 --> Helper loaded: url_helper
INFO - 2018-04-12 22:43:59 --> Helper loaded: notification_helper
INFO - 2018-04-12 17:13:59 --> Security Class Initialized
INFO - 2018-04-12 22:43:59 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:43:59 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:43:59 --> Helper loaded: users_helper
DEBUG - 2018-04-12 17:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:13:59 --> Input Class Initialized
INFO - 2018-04-12 17:13:59 --> Language Class Initialized
INFO - 2018-04-12 22:43:59 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:43:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 17:13:59 --> Language Class Initialized
INFO - 2018-04-12 17:13:59 --> Config Class Initialized
INFO - 2018-04-12 17:13:59 --> Loader Class Initialized
INFO - 2018-04-12 22:43:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:43:59 --> Helper loaded: url_helper
INFO - 2018-04-12 22:43:59 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:43:59 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:43:59 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:43:59 --> Helper loaded: users_helper
INFO - 2018-04-12 22:43:59 --> Helper loaded: form_helper
INFO - 2018-04-12 22:43:59 --> Form Validation Class Initialized
INFO - 2018-04-12 22:43:59 --> Controller Class Initialized
INFO - 2018-04-12 22:43:59 --> Model Class Initialized
INFO - 2018-04-12 22:43:59 --> Helper loaded: inflector_helper
INFO - 2018-04-12 22:43:59 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:43:59 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:43:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:43:59 --> Model Class Initialized
INFO - 2018-04-12 22:43:59 --> Model Class Initialized
DEBUG - 2018-04-12 22:43:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:43:59 --> Model Class Initialized
INFO - 2018-04-12 22:43:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:43:59 --> Model Class Initialized
INFO - 2018-04-12 22:43:59 --> Model Class Initialized
INFO - 2018-04-12 22:43:59 --> Model Class Initialized
INFO - 2018-04-12 22:43:59 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-12 22:43:59 --> Model Class Initialized
INFO - 2018-04-12 22:43:59 --> Final output sent to browser
DEBUG - 2018-04-12 22:43:59 --> Total execution time: 0.1024
INFO - 2018-04-12 22:43:59 --> Helper loaded: form_helper
INFO - 2018-04-12 22:43:59 --> Form Validation Class Initialized
INFO - 2018-04-12 22:43:59 --> Controller Class Initialized
INFO - 2018-04-12 22:43:59 --> Model Class Initialized
INFO - 2018-04-12 22:43:59 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:43:59 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:43:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:43:59 --> Model Class Initialized
INFO - 2018-04-12 22:43:59 --> Model Class Initialized
INFO - 2018-04-12 22:43:59 --> Model Class Initialized
INFO - 2018-04-12 22:43:59 --> Model Class Initialized
INFO - 2018-04-12 22:43:59 --> Model Class Initialized
INFO - 2018-04-12 22:43:59 --> Model Class Initialized
INFO - 2018-04-12 22:43:59 --> Model Class Initialized
INFO - 2018-04-12 22:43:59 --> Model Class Initialized
INFO - 2018-04-12 22:43:59 --> Model Class Initialized
INFO - 2018-04-12 22:43:59 --> Model Class Initialized
INFO - 2018-04-12 22:43:59 --> Model Class Initialized
INFO - 2018-04-12 22:43:59 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-12 22:43:59 --> Model Class Initialized
INFO - 2018-04-12 22:43:59 --> Final output sent to browser
DEBUG - 2018-04-12 22:43:59 --> Total execution time: 0.1124
INFO - 2018-04-12 17:14:01 --> Config Class Initialized
INFO - 2018-04-12 17:14:01 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:14:01 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:14:01 --> Utf8 Class Initialized
INFO - 2018-04-12 17:14:01 --> URI Class Initialized
INFO - 2018-04-12 17:14:01 --> Router Class Initialized
INFO - 2018-04-12 17:14:01 --> Output Class Initialized
INFO - 2018-04-12 17:14:01 --> Security Class Initialized
DEBUG - 2018-04-12 17:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:14:01 --> Input Class Initialized
INFO - 2018-04-12 17:14:01 --> Language Class Initialized
INFO - 2018-04-12 17:14:01 --> Language Class Initialized
INFO - 2018-04-12 17:14:01 --> Config Class Initialized
INFO - 2018-04-12 17:14:01 --> Loader Class Initialized
INFO - 2018-04-12 22:44:01 --> Helper loaded: url_helper
INFO - 2018-04-12 22:44:01 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:44:01 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:44:01 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:44:01 --> Helper loaded: users_helper
INFO - 2018-04-12 22:44:01 --> Database Driver Class Initialized
INFO - 2018-04-12 17:14:01 --> Config Class Initialized
INFO - 2018-04-12 17:14:01 --> Hooks Class Initialized
DEBUG - 2018-04-12 22:44:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:44:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-04-12 17:14:01 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:14:01 --> Utf8 Class Initialized
INFO - 2018-04-12 17:14:01 --> URI Class Initialized
INFO - 2018-04-12 22:44:01 --> Helper loaded: form_helper
INFO - 2018-04-12 22:44:01 --> Form Validation Class Initialized
INFO - 2018-04-12 22:44:01 --> Controller Class Initialized
INFO - 2018-04-12 17:14:01 --> Router Class Initialized
INFO - 2018-04-12 17:14:01 --> Output Class Initialized
INFO - 2018-04-12 22:44:01 --> Model Class Initialized
INFO - 2018-04-12 22:44:01 --> Helper loaded: inflector_helper
INFO - 2018-04-12 17:14:01 --> Security Class Initialized
DEBUG - 2018-04-12 22:44:01 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-04-12 17:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:14:01 --> Input Class Initialized
INFO - 2018-04-12 17:14:01 --> Language Class Initialized
INFO - 2018-04-12 22:44:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:44:01 --> Model Class Initialized
INFO - 2018-04-12 22:44:01 --> Model Class Initialized
INFO - 2018-04-12 22:44:01 --> Model Class Initialized
INFO - 2018-04-12 22:44:01 --> Model Class Initialized
INFO - 2018-04-12 22:44:01 --> Model Class Initialized
INFO - 2018-04-12 22:44:01 --> Model Class Initialized
INFO - 2018-04-12 22:44:01 --> Model Class Initialized
INFO - 2018-04-12 22:44:01 --> Model Class Initialized
INFO - 2018-04-12 22:44:01 --> Model Class Initialized
INFO - 2018-04-12 22:44:01 --> Model Class Initialized
INFO - 2018-04-12 22:44:01 --> Model Class Initialized
INFO - 2018-04-12 22:44:01 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-12 22:44:01 --> Model Class Initialized
INFO - 2018-04-12 17:14:01 --> Language Class Initialized
INFO - 2018-04-12 17:14:01 --> Config Class Initialized
INFO - 2018-04-12 17:14:01 --> Loader Class Initialized
INFO - 2018-04-12 22:44:01 --> Final output sent to browser
DEBUG - 2018-04-12 22:44:01 --> Total execution time: 0.1295
INFO - 2018-04-12 22:44:01 --> Helper loaded: url_helper
INFO - 2018-04-12 22:44:01 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:44:01 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:44:01 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:44:01 --> Helper loaded: users_helper
INFO - 2018-04-12 22:44:01 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:44:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:44:01 --> Helper loaded: form_helper
INFO - 2018-04-12 22:44:01 --> Form Validation Class Initialized
INFO - 2018-04-12 22:44:01 --> Controller Class Initialized
INFO - 2018-04-12 22:44:01 --> Model Class Initialized
INFO - 2018-04-12 22:44:01 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:44:01 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:44:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:44:01 --> Model Class Initialized
INFO - 2018-04-12 22:44:01 --> Model Class Initialized
INFO - 2018-04-12 22:44:01 --> Model Class Initialized
INFO - 2018-04-12 22:44:01 --> Model Class Initialized
INFO - 2018-04-12 22:44:01 --> Model Class Initialized
INFO - 2018-04-12 22:44:01 --> Model Class Initialized
INFO - 2018-04-12 22:44:01 --> Model Class Initialized
INFO - 2018-04-12 22:44:01 --> Model Class Initialized
INFO - 2018-04-12 22:44:01 --> Model Class Initialized
INFO - 2018-04-12 22:44:01 --> Model Class Initialized
INFO - 2018-04-12 22:44:01 --> Model Class Initialized
INFO - 2018-04-12 22:44:01 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-12 22:44:01 --> Final output sent to browser
DEBUG - 2018-04-12 22:44:01 --> Total execution time: 0.1357
INFO - 2018-04-12 17:14:03 --> Config Class Initialized
INFO - 2018-04-12 17:14:03 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:14:03 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:14:03 --> Utf8 Class Initialized
INFO - 2018-04-12 17:14:03 --> URI Class Initialized
INFO - 2018-04-12 17:14:03 --> Router Class Initialized
INFO - 2018-04-12 17:14:03 --> Output Class Initialized
INFO - 2018-04-12 17:14:03 --> Security Class Initialized
DEBUG - 2018-04-12 17:14:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:14:03 --> Input Class Initialized
INFO - 2018-04-12 17:14:03 --> Language Class Initialized
INFO - 2018-04-12 17:14:03 --> Language Class Initialized
INFO - 2018-04-12 17:14:03 --> Config Class Initialized
INFO - 2018-04-12 17:14:03 --> Loader Class Initialized
INFO - 2018-04-12 22:44:03 --> Helper loaded: url_helper
INFO - 2018-04-12 22:44:03 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:44:03 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:44:03 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:44:03 --> Helper loaded: users_helper
INFO - 2018-04-12 22:44:03 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:44:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:44:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:44:03 --> Helper loaded: form_helper
INFO - 2018-04-12 22:44:03 --> Form Validation Class Initialized
INFO - 2018-04-12 22:44:03 --> Controller Class Initialized
INFO - 2018-04-12 17:14:03 --> Config Class Initialized
INFO - 2018-04-12 17:14:03 --> Hooks Class Initialized
INFO - 2018-04-12 22:44:03 --> Model Class Initialized
INFO - 2018-04-12 22:44:03 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 17:14:03 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:14:03 --> Utf8 Class Initialized
DEBUG - 2018-04-12 22:44:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:44:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 17:14:03 --> URI Class Initialized
INFO - 2018-04-12 22:44:03 --> Model Class Initialized
INFO - 2018-04-12 22:44:03 --> Model Class Initialized
INFO - 2018-04-12 22:44:03 --> Model Class Initialized
INFO - 2018-04-12 22:44:03 --> Model Class Initialized
INFO - 2018-04-12 22:44:03 --> Model Class Initialized
INFO - 2018-04-12 22:44:03 --> Model Class Initialized
INFO - 2018-04-12 22:44:03 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-12 17:14:03 --> Router Class Initialized
ERROR - 2018-04-12 22:44:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-04-12 22:44:03 --> Final output sent to browser
DEBUG - 2018-04-12 22:44:03 --> Total execution time: 0.1065
INFO - 2018-04-12 17:14:03 --> Output Class Initialized
INFO - 2018-04-12 17:14:03 --> Security Class Initialized
DEBUG - 2018-04-12 17:14:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:14:03 --> Input Class Initialized
INFO - 2018-04-12 17:14:03 --> Language Class Initialized
INFO - 2018-04-12 17:14:03 --> Config Class Initialized
INFO - 2018-04-12 17:14:03 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:14:03 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:14:03 --> Utf8 Class Initialized
INFO - 2018-04-12 17:14:03 --> Language Class Initialized
INFO - 2018-04-12 17:14:03 --> Config Class Initialized
INFO - 2018-04-12 17:14:03 --> Loader Class Initialized
INFO - 2018-04-12 17:14:03 --> URI Class Initialized
INFO - 2018-04-12 22:44:03 --> Helper loaded: url_helper
INFO - 2018-04-12 22:44:03 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:44:03 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:44:03 --> Helper loaded: permission_helper
INFO - 2018-04-12 17:14:03 --> Router Class Initialized
INFO - 2018-04-12 22:44:03 --> Helper loaded: users_helper
INFO - 2018-04-12 17:14:03 --> Output Class Initialized
INFO - 2018-04-12 17:14:03 --> Security Class Initialized
DEBUG - 2018-04-12 17:14:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:14:03 --> Input Class Initialized
INFO - 2018-04-12 17:14:03 --> Language Class Initialized
INFO - 2018-04-12 22:44:03 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:44:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:44:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 17:14:03 --> Language Class Initialized
INFO - 2018-04-12 17:14:03 --> Config Class Initialized
INFO - 2018-04-12 17:14:03 --> Loader Class Initialized
INFO - 2018-04-12 22:44:03 --> Helper loaded: url_helper
INFO - 2018-04-12 22:44:03 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:44:03 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:44:03 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:44:03 --> Helper loaded: form_helper
INFO - 2018-04-12 22:44:03 --> Form Validation Class Initialized
INFO - 2018-04-12 22:44:03 --> Controller Class Initialized
INFO - 2018-04-12 22:44:03 --> Helper loaded: users_helper
INFO - 2018-04-12 22:44:03 --> Model Class Initialized
INFO - 2018-04-12 22:44:03 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:44:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:44:03 --> Database Driver Class Initialized
INFO - 2018-04-12 22:44:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:44:03 --> Model Class Initialized
INFO - 2018-04-12 22:44:03 --> Model Class Initialized
INFO - 2018-04-12 22:44:03 --> Model Class Initialized
INFO - 2018-04-12 22:44:03 --> Model Class Initialized
INFO - 2018-04-12 22:44:03 --> Model Class Initialized
INFO - 2018-04-12 22:44:03 --> Model Class Initialized
INFO - 2018-04-12 22:44:03 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-04-12 22:44:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:44:03 --> Session: Class initialized using 'files' driver.
ERROR - 2018-04-12 22:44:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-04-12 22:44:03 --> Final output sent to browser
DEBUG - 2018-04-12 22:44:03 --> Total execution time: 0.1149
INFO - 2018-04-12 22:44:03 --> Helper loaded: form_helper
INFO - 2018-04-12 22:44:03 --> Form Validation Class Initialized
INFO - 2018-04-12 22:44:03 --> Controller Class Initialized
INFO - 2018-04-12 22:44:03 --> Model Class Initialized
INFO - 2018-04-12 22:44:03 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:44:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:44:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:44:03 --> Model Class Initialized
INFO - 2018-04-12 22:44:03 --> Model Class Initialized
INFO - 2018-04-12 22:44:03 --> Model Class Initialized
INFO - 2018-04-12 22:44:03 --> Model Class Initialized
INFO - 2018-04-12 22:44:03 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-12 22:44:03 --> Final output sent to browser
DEBUG - 2018-04-12 22:44:03 --> Total execution time: 0.1051
INFO - 2018-04-12 17:14:05 --> Config Class Initialized
INFO - 2018-04-12 17:14:05 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:14:05 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:14:05 --> Utf8 Class Initialized
INFO - 2018-04-12 17:14:05 --> URI Class Initialized
INFO - 2018-04-12 17:14:05 --> Router Class Initialized
INFO - 2018-04-12 17:14:06 --> Output Class Initialized
INFO - 2018-04-12 17:14:06 --> Security Class Initialized
DEBUG - 2018-04-12 17:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:14:06 --> Input Class Initialized
INFO - 2018-04-12 17:14:06 --> Language Class Initialized
INFO - 2018-04-12 17:14:06 --> Config Class Initialized
INFO - 2018-04-12 17:14:06 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:14:06 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:14:06 --> Utf8 Class Initialized
INFO - 2018-04-12 17:14:06 --> URI Class Initialized
INFO - 2018-04-12 17:14:06 --> Router Class Initialized
INFO - 2018-04-12 17:14:06 --> Language Class Initialized
INFO - 2018-04-12 17:14:06 --> Config Class Initialized
INFO - 2018-04-12 17:14:06 --> Loader Class Initialized
INFO - 2018-04-12 17:14:06 --> Output Class Initialized
INFO - 2018-04-12 17:14:06 --> Security Class Initialized
INFO - 2018-04-12 22:44:06 --> Helper loaded: url_helper
DEBUG - 2018-04-12 17:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:14:06 --> Input Class Initialized
INFO - 2018-04-12 17:14:06 --> Language Class Initialized
INFO - 2018-04-12 22:44:06 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:44:06 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:44:06 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:44:06 --> Helper loaded: users_helper
INFO - 2018-04-12 17:14:06 --> Language Class Initialized
INFO - 2018-04-12 17:14:06 --> Config Class Initialized
INFO - 2018-04-12 17:14:06 --> Loader Class Initialized
INFO - 2018-04-12 22:44:06 --> Helper loaded: url_helper
INFO - 2018-04-12 22:44:06 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:44:06 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:44:06 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:44:06 --> Helper loaded: users_helper
INFO - 2018-04-12 22:44:06 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:44:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:44:06 --> Helper loaded: form_helper
INFO - 2018-04-12 22:44:06 --> Database Driver Class Initialized
INFO - 2018-04-12 22:44:06 --> Form Validation Class Initialized
INFO - 2018-04-12 22:44:06 --> Controller Class Initialized
DEBUG - 2018-04-12 22:44:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:44:06 --> Model Class Initialized
INFO - 2018-04-12 22:44:06 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:44:06 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:44:06 --> Helper loaded: form_helper
INFO - 2018-04-12 22:44:06 --> Form Validation Class Initialized
INFO - 2018-04-12 22:44:06 --> Controller Class Initialized
INFO - 2018-04-12 22:44:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:44:06 --> Model Class Initialized
INFO - 2018-04-12 22:44:06 --> Model Class Initialized
INFO - 2018-04-12 22:44:06 --> Model Class Initialized
INFO - 2018-04-12 22:44:06 --> Model Class Initialized
INFO - 2018-04-12 22:44:06 --> Model Class Initialized
INFO - 2018-04-12 22:44:06 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-12 22:44:06 --> Model Class Initialized
INFO - 2018-04-12 22:44:06 --> Final output sent to browser
DEBUG - 2018-04-12 22:44:06 --> Total execution time: 0.1020
INFO - 2018-04-12 22:44:06 --> Model Class Initialized
INFO - 2018-04-12 22:44:06 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:44:06 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:44:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:44:06 --> Model Class Initialized
INFO - 2018-04-12 22:44:06 --> Model Class Initialized
INFO - 2018-04-12 22:44:06 --> Model Class Initialized
INFO - 2018-04-12 22:44:06 --> Model Class Initialized
INFO - 2018-04-12 22:44:06 --> Model Class Initialized
INFO - 2018-04-12 22:44:06 --> Model Class Initialized
INFO - 2018-04-12 22:44:06 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-04-12 22:44:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-04-12 22:44:06 --> Final output sent to browser
DEBUG - 2018-04-12 22:44:06 --> Total execution time: 0.1810
INFO - 2018-04-12 17:14:19 --> Config Class Initialized
INFO - 2018-04-12 17:14:19 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:14:19 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:14:19 --> Utf8 Class Initialized
INFO - 2018-04-12 17:14:19 --> URI Class Initialized
INFO - 2018-04-12 17:14:19 --> Router Class Initialized
INFO - 2018-04-12 17:14:19 --> Output Class Initialized
INFO - 2018-04-12 17:14:19 --> Security Class Initialized
DEBUG - 2018-04-12 17:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:14:19 --> Input Class Initialized
INFO - 2018-04-12 17:14:19 --> Language Class Initialized
INFO - 2018-04-12 17:14:19 --> Language Class Initialized
INFO - 2018-04-12 17:14:19 --> Config Class Initialized
INFO - 2018-04-12 17:14:19 --> Loader Class Initialized
INFO - 2018-04-12 22:44:19 --> Helper loaded: url_helper
INFO - 2018-04-12 22:44:19 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:44:19 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:44:19 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:44:19 --> Helper loaded: users_helper
INFO - 2018-04-12 22:44:19 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:44:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:44:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:44:19 --> Helper loaded: form_helper
INFO - 2018-04-12 22:44:19 --> Form Validation Class Initialized
INFO - 2018-04-12 22:44:19 --> Controller Class Initialized
INFO - 2018-04-12 22:44:19 --> Model Class Initialized
INFO - 2018-04-12 22:44:19 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:44:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:44:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:44:19 --> Model Class Initialized
INFO - 2018-04-12 22:44:19 --> Model Class Initialized
INFO - 2018-04-12 22:44:19 --> Model Class Initialized
INFO - 2018-04-12 22:44:19 --> Model Class Initialized
INFO - 2018-04-12 22:44:19 --> Model Class Initialized
INFO - 2018-04-12 22:44:19 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-12 22:44:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-12 22:44:19 --> Final output sent to browser
DEBUG - 2018-04-12 22:44:19 --> Total execution time: 0.0987
INFO - 2018-04-12 17:14:20 --> Config Class Initialized
INFO - 2018-04-12 17:14:20 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:14:20 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:14:20 --> Utf8 Class Initialized
INFO - 2018-04-12 17:14:20 --> URI Class Initialized
INFO - 2018-04-12 17:14:20 --> Router Class Initialized
INFO - 2018-04-12 17:14:20 --> Output Class Initialized
INFO - 2018-04-12 17:14:20 --> Security Class Initialized
DEBUG - 2018-04-12 17:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:14:20 --> Input Class Initialized
INFO - 2018-04-12 17:14:20 --> Language Class Initialized
INFO - 2018-04-12 17:14:20 --> Language Class Initialized
INFO - 2018-04-12 17:14:20 --> Config Class Initialized
INFO - 2018-04-12 17:14:20 --> Loader Class Initialized
INFO - 2018-04-12 22:44:20 --> Helper loaded: url_helper
INFO - 2018-04-12 22:44:20 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:44:20 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:44:20 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:44:20 --> Helper loaded: users_helper
INFO - 2018-04-12 22:44:20 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:44:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:44:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:44:20 --> Helper loaded: form_helper
INFO - 2018-04-12 22:44:20 --> Form Validation Class Initialized
INFO - 2018-04-12 22:44:20 --> Controller Class Initialized
INFO - 2018-04-12 22:44:20 --> Model Class Initialized
INFO - 2018-04-12 22:44:20 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:44:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:44:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:44:20 --> Model Class Initialized
INFO - 2018-04-12 22:44:20 --> Model Class Initialized
INFO - 2018-04-12 22:44:20 --> Model Class Initialized
INFO - 2018-04-12 22:44:20 --> Model Class Initialized
INFO - 2018-04-12 22:44:20 --> Model Class Initialized
INFO - 2018-04-12 22:44:20 --> Model Class Initialized
INFO - 2018-04-12 22:44:20 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-04-12 22:44:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-04-12 22:44:20 --> Final output sent to browser
DEBUG - 2018-04-12 22:44:20 --> Total execution time: 0.1092
INFO - 2018-04-12 17:14:20 --> Config Class Initialized
INFO - 2018-04-12 17:14:20 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:14:20 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:14:20 --> Utf8 Class Initialized
INFO - 2018-04-12 17:14:20 --> URI Class Initialized
INFO - 2018-04-12 17:14:20 --> Router Class Initialized
INFO - 2018-04-12 17:14:20 --> Output Class Initialized
INFO - 2018-04-12 17:14:20 --> Security Class Initialized
DEBUG - 2018-04-12 17:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:14:20 --> Input Class Initialized
INFO - 2018-04-12 17:14:20 --> Language Class Initialized
INFO - 2018-04-12 17:14:20 --> Language Class Initialized
INFO - 2018-04-12 17:14:20 --> Config Class Initialized
INFO - 2018-04-12 17:14:20 --> Loader Class Initialized
INFO - 2018-04-12 22:44:20 --> Helper loaded: url_helper
INFO - 2018-04-12 22:44:20 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:44:20 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:44:20 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:44:20 --> Helper loaded: users_helper
INFO - 2018-04-12 22:44:20 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:44:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:44:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 17:14:20 --> Config Class Initialized
INFO - 2018-04-12 17:14:20 --> Hooks Class Initialized
INFO - 2018-04-12 22:44:20 --> Helper loaded: form_helper
INFO - 2018-04-12 22:44:20 --> Form Validation Class Initialized
INFO - 2018-04-12 22:44:20 --> Controller Class Initialized
DEBUG - 2018-04-12 17:14:20 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:14:20 --> Utf8 Class Initialized
INFO - 2018-04-12 17:14:20 --> URI Class Initialized
INFO - 2018-04-12 17:14:20 --> Router Class Initialized
INFO - 2018-04-12 22:44:20 --> Model Class Initialized
INFO - 2018-04-12 22:44:20 --> Helper loaded: inflector_helper
INFO - 2018-04-12 17:14:20 --> Output Class Initialized
DEBUG - 2018-04-12 22:44:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 17:14:20 --> Security Class Initialized
INFO - 2018-04-12 22:44:20 --> Language file loaded: language/english/rest_controller_lang.php
DEBUG - 2018-04-12 17:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:14:20 --> Input Class Initialized
INFO - 2018-04-12 22:44:20 --> Model Class Initialized
INFO - 2018-04-12 22:44:20 --> Model Class Initialized
INFO - 2018-04-12 17:14:20 --> Language Class Initialized
INFO - 2018-04-12 22:44:20 --> Model Class Initialized
INFO - 2018-04-12 22:44:20 --> Model Class Initialized
INFO - 2018-04-12 22:44:20 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-12 22:44:20 --> Final output sent to browser
DEBUG - 2018-04-12 22:44:20 --> Total execution time: 0.1023
INFO - 2018-04-12 17:14:20 --> Language Class Initialized
INFO - 2018-04-12 17:14:20 --> Config Class Initialized
INFO - 2018-04-12 17:14:20 --> Loader Class Initialized
INFO - 2018-04-12 22:44:20 --> Helper loaded: url_helper
INFO - 2018-04-12 22:44:20 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:44:20 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:44:20 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:44:20 --> Helper loaded: users_helper
INFO - 2018-04-12 22:44:20 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:44:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:44:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:44:20 --> Helper loaded: form_helper
INFO - 2018-04-12 22:44:20 --> Form Validation Class Initialized
INFO - 2018-04-12 22:44:20 --> Controller Class Initialized
INFO - 2018-04-12 22:44:20 --> Model Class Initialized
INFO - 2018-04-12 22:44:20 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:44:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:44:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:44:20 --> Model Class Initialized
INFO - 2018-04-12 22:44:20 --> Model Class Initialized
INFO - 2018-04-12 22:44:20 --> Model Class Initialized
INFO - 2018-04-12 22:44:20 --> Model Class Initialized
INFO - 2018-04-12 22:44:20 --> Model Class Initialized
INFO - 2018-04-12 22:44:20 --> Model Class Initialized
INFO - 2018-04-12 22:44:20 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-04-12 22:44:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-04-12 22:44:20 --> Final output sent to browser
DEBUG - 2018-04-12 22:44:20 --> Total execution time: 0.1091
INFO - 2018-04-12 17:14:23 --> Config Class Initialized
INFO - 2018-04-12 17:14:23 --> Hooks Class Initialized
INFO - 2018-04-12 17:14:23 --> Config Class Initialized
INFO - 2018-04-12 17:14:23 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:14:23 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:14:23 --> Utf8 Class Initialized
DEBUG - 2018-04-12 17:14:23 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:14:23 --> Utf8 Class Initialized
INFO - 2018-04-12 17:14:23 --> URI Class Initialized
INFO - 2018-04-12 17:14:23 --> URI Class Initialized
INFO - 2018-04-12 17:14:23 --> Router Class Initialized
INFO - 2018-04-12 17:14:23 --> Output Class Initialized
INFO - 2018-04-12 17:14:23 --> Router Class Initialized
INFO - 2018-04-12 17:14:23 --> Security Class Initialized
INFO - 2018-04-12 17:14:23 --> Output Class Initialized
DEBUG - 2018-04-12 17:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:14:23 --> Input Class Initialized
INFO - 2018-04-12 17:14:23 --> Language Class Initialized
INFO - 2018-04-12 17:14:23 --> Security Class Initialized
DEBUG - 2018-04-12 17:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:14:23 --> Input Class Initialized
INFO - 2018-04-12 17:14:23 --> Language Class Initialized
INFO - 2018-04-12 17:14:23 --> Language Class Initialized
INFO - 2018-04-12 17:14:23 --> Config Class Initialized
INFO - 2018-04-12 17:14:23 --> Loader Class Initialized
INFO - 2018-04-12 22:44:23 --> Helper loaded: url_helper
INFO - 2018-04-12 22:44:23 --> Helper loaded: notification_helper
INFO - 2018-04-12 17:14:23 --> Language Class Initialized
INFO - 2018-04-12 17:14:23 --> Config Class Initialized
INFO - 2018-04-12 22:44:23 --> Helper loaded: settings_helper
INFO - 2018-04-12 17:14:23 --> Loader Class Initialized
INFO - 2018-04-12 22:44:23 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:44:23 --> Helper loaded: users_helper
INFO - 2018-04-12 22:44:23 --> Helper loaded: url_helper
INFO - 2018-04-12 22:44:23 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:44:23 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:44:23 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:44:23 --> Helper loaded: users_helper
INFO - 2018-04-12 22:44:23 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:44:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:44:23 --> Database Driver Class Initialized
INFO - 2018-04-12 22:44:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-04-12 22:44:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:44:23 --> Helper loaded: form_helper
INFO - 2018-04-12 22:44:23 --> Form Validation Class Initialized
INFO - 2018-04-12 22:44:23 --> Controller Class Initialized
INFO - 2018-04-12 22:44:23 --> Helper loaded: form_helper
INFO - 2018-04-12 22:44:23 --> Form Validation Class Initialized
INFO - 2018-04-12 22:44:23 --> Controller Class Initialized
INFO - 2018-04-12 22:44:23 --> Model Class Initialized
INFO - 2018-04-12 22:44:23 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:44:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:44:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:44:23 --> Model Class Initialized
INFO - 2018-04-12 22:44:23 --> Helper loaded: inflector_helper
INFO - 2018-04-12 22:44:23 --> Model Class Initialized
INFO - 2018-04-12 22:44:23 --> Model Class Initialized
INFO - 2018-04-12 22:44:23 --> Model Class Initialized
INFO - 2018-04-12 22:44:23 --> Model Class Initialized
INFO - 2018-04-12 22:44:23 --> Model Class Initialized
INFO - 2018-04-12 22:44:23 --> Model Class Initialized
INFO - 2018-04-12 22:44:23 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-04-12 22:44:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:44:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:44:23 --> Model Class Initialized
INFO - 2018-04-12 22:44:23 --> Model Class Initialized
INFO - 2018-04-12 22:44:23 --> Final output sent to browser
DEBUG - 2018-04-12 22:44:23 --> Total execution time: 0.0958
INFO - 2018-04-12 22:44:23 --> Model Class Initialized
INFO - 2018-04-12 22:44:23 --> Model Class Initialized
INFO - 2018-04-12 22:44:23 --> Model Class Initialized
INFO - 2018-04-12 22:44:23 --> Model Class Initialized
INFO - 2018-04-12 22:44:23 --> Model Class Initialized
INFO - 2018-04-12 22:44:23 --> Model Class Initialized
INFO - 2018-04-12 22:44:23 --> Model Class Initialized
INFO - 2018-04-12 22:44:23 --> Model Class Initialized
INFO - 2018-04-12 22:44:23 --> Model Class Initialized
INFO - 2018-04-12 22:44:23 --> Model Class Initialized
INFO - 2018-04-12 22:44:23 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-12 22:44:23 --> Model Class Initialized
INFO - 2018-04-12 22:44:23 --> Final output sent to browser
DEBUG - 2018-04-12 22:44:23 --> Total execution time: 0.1132
INFO - 2018-04-12 17:14:25 --> Config Class Initialized
INFO - 2018-04-12 17:14:25 --> Hooks Class Initialized
INFO - 2018-04-12 17:14:25 --> Config Class Initialized
INFO - 2018-04-12 17:14:25 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:14:25 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:14:25 --> Utf8 Class Initialized
INFO - 2018-04-12 17:14:25 --> URI Class Initialized
DEBUG - 2018-04-12 17:14:25 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:14:25 --> Utf8 Class Initialized
INFO - 2018-04-12 17:14:25 --> URI Class Initialized
INFO - 2018-04-12 17:14:25 --> Router Class Initialized
INFO - 2018-04-12 17:14:25 --> Config Class Initialized
INFO - 2018-04-12 17:14:25 --> Hooks Class Initialized
INFO - 2018-04-12 17:14:25 --> Output Class Initialized
INFO - 2018-04-12 17:14:25 --> Router Class Initialized
DEBUG - 2018-04-12 17:14:25 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:14:25 --> Security Class Initialized
INFO - 2018-04-12 17:14:25 --> Utf8 Class Initialized
INFO - 2018-04-12 17:14:25 --> Output Class Initialized
INFO - 2018-04-12 17:14:25 --> URI Class Initialized
DEBUG - 2018-04-12 17:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:14:25 --> Input Class Initialized
INFO - 2018-04-12 17:14:25 --> Language Class Initialized
INFO - 2018-04-12 17:14:25 --> Security Class Initialized
INFO - 2018-04-12 17:14:25 --> Router Class Initialized
DEBUG - 2018-04-12 17:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:14:25 --> Input Class Initialized
INFO - 2018-04-12 17:14:25 --> Output Class Initialized
INFO - 2018-04-12 17:14:25 --> Language Class Initialized
INFO - 2018-04-12 17:14:25 --> Security Class Initialized
DEBUG - 2018-04-12 17:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:14:25 --> Input Class Initialized
INFO - 2018-04-12 17:14:25 --> Language Class Initialized
INFO - 2018-04-12 17:14:25 --> Language Class Initialized
INFO - 2018-04-12 17:14:25 --> Config Class Initialized
INFO - 2018-04-12 17:14:25 --> Loader Class Initialized
INFO - 2018-04-12 22:44:25 --> Helper loaded: url_helper
INFO - 2018-04-12 17:14:25 --> Language Class Initialized
INFO - 2018-04-12 17:14:25 --> Config Class Initialized
INFO - 2018-04-12 17:14:25 --> Loader Class Initialized
INFO - 2018-04-12 22:44:25 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:44:25 --> Helper loaded: settings_helper
INFO - 2018-04-12 17:14:25 --> Language Class Initialized
INFO - 2018-04-12 17:14:25 --> Config Class Initialized
INFO - 2018-04-12 17:14:25 --> Loader Class Initialized
INFO - 2018-04-12 22:44:25 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:44:25 --> Helper loaded: users_helper
INFO - 2018-04-12 22:44:25 --> Helper loaded: url_helper
INFO - 2018-04-12 22:44:25 --> Helper loaded: url_helper
INFO - 2018-04-12 22:44:25 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:44:25 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:44:25 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:44:25 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:44:25 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:44:25 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:44:25 --> Helper loaded: users_helper
INFO - 2018-04-12 22:44:25 --> Helper loaded: users_helper
INFO - 2018-04-12 22:44:25 --> Database Driver Class Initialized
INFO - 2018-04-12 22:44:25 --> Database Driver Class Initialized
INFO - 2018-04-12 22:44:25 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:44:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:44:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-04-12 22:44:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:44:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-04-12 22:44:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:44:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:44:25 --> Helper loaded: form_helper
INFO - 2018-04-12 22:44:25 --> Form Validation Class Initialized
INFO - 2018-04-12 22:44:25 --> Controller Class Initialized
INFO - 2018-04-12 22:44:25 --> Helper loaded: form_helper
INFO - 2018-04-12 22:44:25 --> Form Validation Class Initialized
INFO - 2018-04-12 22:44:25 --> Controller Class Initialized
INFO - 2018-04-12 22:44:25 --> Helper loaded: form_helper
INFO - 2018-04-12 22:44:25 --> Form Validation Class Initialized
INFO - 2018-04-12 22:44:25 --> Controller Class Initialized
INFO - 2018-04-12 22:44:25 --> Model Class Initialized
INFO - 2018-04-12 22:44:25 --> Model Class Initialized
INFO - 2018-04-12 22:44:25 --> Helper loaded: inflector_helper
INFO - 2018-04-12 22:44:25 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:44:25 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-04-12 22:44:25 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:44:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:44:25 --> Model Class Initialized
INFO - 2018-04-12 22:44:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:44:25 --> Model Class Initialized
INFO - 2018-04-12 22:44:25 --> Model Class Initialized
INFO - 2018-04-12 22:44:25 --> Helper loaded: inflector_helper
INFO - 2018-04-12 22:44:25 --> Model Class Initialized
INFO - 2018-04-12 22:44:25 --> Model Class Initialized
INFO - 2018-04-12 22:44:25 --> Model Class Initialized
INFO - 2018-04-12 22:44:25 --> Model Class Initialized
INFO - 2018-04-12 22:44:25 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-12 22:44:25 --> Model Class Initialized
INFO - 2018-04-12 22:44:25 --> Model Class Initialized
INFO - 2018-04-12 22:44:25 --> Model Class Initialized
INFO - 2018-04-12 22:44:25 --> Model Class Initialized
INFO - 2018-04-12 22:44:25 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-04-12 22:44:25 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:44:25 --> Final output sent to browser
DEBUG - 2018-04-12 22:44:25 --> Total execution time: 0.0961
ERROR - 2018-04-12 22:44:25 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-04-12 22:44:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:44:25 --> Final output sent to browser
DEBUG - 2018-04-12 22:44:25 --> Total execution time: 0.1119
INFO - 2018-04-12 22:44:25 --> Model Class Initialized
INFO - 2018-04-12 22:44:25 --> Model Class Initialized
INFO - 2018-04-12 22:44:25 --> Model Class Initialized
INFO - 2018-04-12 22:44:25 --> Model Class Initialized
INFO - 2018-04-12 22:44:25 --> Model Class Initialized
INFO - 2018-04-12 22:44:25 --> Model Class Initialized
INFO - 2018-04-12 22:44:25 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-04-12 22:44:25 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-04-12 22:44:25 --> Final output sent to browser
DEBUG - 2018-04-12 22:44:25 --> Total execution time: 0.1172
INFO - 2018-04-12 17:14:28 --> Config Class Initialized
INFO - 2018-04-12 17:14:28 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:14:28 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:14:28 --> Utf8 Class Initialized
INFO - 2018-04-12 17:14:28 --> URI Class Initialized
INFO - 2018-04-12 17:14:28 --> Router Class Initialized
INFO - 2018-04-12 17:14:28 --> Output Class Initialized
INFO - 2018-04-12 17:14:28 --> Security Class Initialized
DEBUG - 2018-04-12 17:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:14:28 --> Input Class Initialized
INFO - 2018-04-12 17:14:28 --> Language Class Initialized
INFO - 2018-04-12 17:14:28 --> Language Class Initialized
INFO - 2018-04-12 17:14:28 --> Config Class Initialized
INFO - 2018-04-12 17:14:28 --> Loader Class Initialized
INFO - 2018-04-12 22:44:28 --> Helper loaded: url_helper
INFO - 2018-04-12 22:44:28 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:44:28 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:44:28 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:44:28 --> Helper loaded: users_helper
INFO - 2018-04-12 22:44:28 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:44:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:44:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:44:28 --> Helper loaded: form_helper
INFO - 2018-04-12 22:44:28 --> Form Validation Class Initialized
INFO - 2018-04-12 22:44:28 --> Controller Class Initialized
INFO - 2018-04-12 22:44:28 --> Model Class Initialized
INFO - 2018-04-12 22:44:28 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:44:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:44:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:44:28 --> Model Class Initialized
INFO - 2018-04-12 22:44:28 --> Model Class Initialized
INFO - 2018-04-12 22:44:28 --> Final output sent to browser
DEBUG - 2018-04-12 22:44:28 --> Total execution time: 0.0980
INFO - 2018-04-12 17:14:31 --> Config Class Initialized
INFO - 2018-04-12 17:14:31 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:14:31 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:14:31 --> Utf8 Class Initialized
INFO - 2018-04-12 17:14:31 --> URI Class Initialized
INFO - 2018-04-12 17:14:31 --> Router Class Initialized
INFO - 2018-04-12 17:14:31 --> Output Class Initialized
INFO - 2018-04-12 17:14:31 --> Security Class Initialized
DEBUG - 2018-04-12 17:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:14:31 --> Input Class Initialized
INFO - 2018-04-12 17:14:31 --> Language Class Initialized
INFO - 2018-04-12 17:14:31 --> Language Class Initialized
INFO - 2018-04-12 17:14:31 --> Config Class Initialized
INFO - 2018-04-12 17:14:31 --> Loader Class Initialized
INFO - 2018-04-12 22:44:31 --> Helper loaded: url_helper
INFO - 2018-04-12 22:44:31 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:44:31 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:44:31 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:44:31 --> Helper loaded: users_helper
INFO - 2018-04-12 22:44:31 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:44:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:44:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:44:31 --> Helper loaded: form_helper
INFO - 2018-04-12 22:44:31 --> Form Validation Class Initialized
INFO - 2018-04-12 22:44:31 --> Controller Class Initialized
INFO - 2018-04-12 22:44:32 --> Model Class Initialized
INFO - 2018-04-12 22:44:32 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:44:32 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:44:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:44:32 --> Model Class Initialized
INFO - 2018-04-12 22:44:32 --> Model Class Initialized
INFO - 2018-04-12 22:44:32 --> Model Class Initialized
INFO - 2018-04-12 22:44:32 --> Model Class Initialized
INFO - 2018-04-12 22:44:32 --> Model Class Initialized
INFO - 2018-04-12 22:44:32 --> Model Class Initialized
INFO - 2018-04-12 22:44:32 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-12 22:44:32 --> Final output sent to browser
DEBUG - 2018-04-12 22:44:32 --> Total execution time: 0.1062
INFO - 2018-04-12 17:14:32 --> Config Class Initialized
INFO - 2018-04-12 17:14:32 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:14:32 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:14:32 --> Utf8 Class Initialized
INFO - 2018-04-12 17:14:32 --> URI Class Initialized
INFO - 2018-04-12 17:14:32 --> Router Class Initialized
INFO - 2018-04-12 17:14:32 --> Output Class Initialized
INFO - 2018-04-12 17:14:32 --> Security Class Initialized
DEBUG - 2018-04-12 17:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:14:32 --> Input Class Initialized
INFO - 2018-04-12 17:14:32 --> Language Class Initialized
INFO - 2018-04-12 17:14:32 --> Language Class Initialized
INFO - 2018-04-12 17:14:32 --> Config Class Initialized
INFO - 2018-04-12 17:14:32 --> Loader Class Initialized
INFO - 2018-04-12 22:44:32 --> Helper loaded: url_helper
INFO - 2018-04-12 22:44:32 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:44:32 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:44:32 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:44:32 --> Helper loaded: users_helper
INFO - 2018-04-12 22:44:32 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:44:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:44:32 --> Helper loaded: form_helper
INFO - 2018-04-12 22:44:32 --> Form Validation Class Initialized
INFO - 2018-04-12 22:44:32 --> Controller Class Initialized
INFO - 2018-04-12 22:44:32 --> Model Class Initialized
INFO - 2018-04-12 22:44:32 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:44:32 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:44:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:44:32 --> Model Class Initialized
INFO - 2018-04-12 22:44:32 --> Model Class Initialized
INFO - 2018-04-12 22:44:32 --> Model Class Initialized
INFO - 2018-04-12 22:44:32 --> Model Class Initialized
INFO - 2018-04-12 22:44:32 --> Model Class Initialized
INFO - 2018-04-12 22:44:32 --> Model Class Initialized
INFO - 2018-04-12 22:44:32 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-12 22:44:32 --> Final output sent to browser
DEBUG - 2018-04-12 22:44:32 --> Total execution time: 0.1051
INFO - 2018-04-12 17:14:51 --> Config Class Initialized
INFO - 2018-04-12 17:14:51 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:14:51 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:14:51 --> Utf8 Class Initialized
INFO - 2018-04-12 17:14:51 --> URI Class Initialized
INFO - 2018-04-12 17:14:51 --> Router Class Initialized
INFO - 2018-04-12 17:14:51 --> Output Class Initialized
INFO - 2018-04-12 17:14:51 --> Security Class Initialized
DEBUG - 2018-04-12 17:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:14:51 --> Input Class Initialized
INFO - 2018-04-12 17:14:51 --> Language Class Initialized
INFO - 2018-04-12 17:14:51 --> Language Class Initialized
INFO - 2018-04-12 17:14:51 --> Config Class Initialized
INFO - 2018-04-12 17:14:51 --> Loader Class Initialized
INFO - 2018-04-12 22:44:51 --> Helper loaded: url_helper
INFO - 2018-04-12 22:44:51 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:44:51 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:44:51 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:44:51 --> Helper loaded: users_helper
INFO - 2018-04-12 22:44:51 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:44:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:44:51 --> Helper loaded: form_helper
INFO - 2018-04-12 22:44:51 --> Form Validation Class Initialized
INFO - 2018-04-12 22:44:51 --> Controller Class Initialized
INFO - 2018-04-12 22:44:51 --> Model Class Initialized
INFO - 2018-04-12 22:44:51 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:44:51 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:44:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:44:51 --> Model Class Initialized
INFO - 2018-04-12 22:44:51 --> Model Class Initialized
INFO - 2018-04-12 22:44:51 --> Model Class Initialized
INFO - 2018-04-12 22:44:51 --> Model Class Initialized
INFO - 2018-04-12 22:44:51 --> Model Class Initialized
INFO - 2018-04-12 22:44:51 --> Model Class Initialized
INFO - 2018-04-12 22:44:51 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-12 22:44:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-12 22:44:51 --> Final output sent to browser
DEBUG - 2018-04-12 22:44:51 --> Total execution time: 0.1073
INFO - 2018-04-12 17:14:52 --> Config Class Initialized
INFO - 2018-04-12 17:14:52 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:14:52 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:14:52 --> Utf8 Class Initialized
INFO - 2018-04-12 17:14:52 --> URI Class Initialized
INFO - 2018-04-12 17:14:52 --> Router Class Initialized
INFO - 2018-04-12 17:14:52 --> Output Class Initialized
INFO - 2018-04-12 17:14:52 --> Security Class Initialized
DEBUG - 2018-04-12 17:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:14:52 --> Input Class Initialized
INFO - 2018-04-12 17:14:52 --> Language Class Initialized
INFO - 2018-04-12 17:14:52 --> Language Class Initialized
INFO - 2018-04-12 17:14:52 --> Config Class Initialized
INFO - 2018-04-12 17:14:52 --> Loader Class Initialized
INFO - 2018-04-12 22:44:52 --> Helper loaded: url_helper
INFO - 2018-04-12 22:44:52 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:44:52 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:44:52 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:44:52 --> Helper loaded: users_helper
INFO - 2018-04-12 22:44:52 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:44:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:44:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:44:52 --> Helper loaded: form_helper
INFO - 2018-04-12 22:44:52 --> Form Validation Class Initialized
INFO - 2018-04-12 22:44:52 --> Controller Class Initialized
INFO - 2018-04-12 22:44:52 --> Model Class Initialized
INFO - 2018-04-12 22:44:52 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:44:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:44:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:44:52 --> Model Class Initialized
INFO - 2018-04-12 22:44:52 --> Model Class Initialized
INFO - 2018-04-12 22:44:52 --> Model Class Initialized
INFO - 2018-04-12 22:44:52 --> Model Class Initialized
INFO - 2018-04-12 22:44:52 --> Model Class Initialized
INFO - 2018-04-12 22:44:52 --> Model Class Initialized
INFO - 2018-04-12 22:44:52 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-12 22:44:52 --> Final output sent to browser
DEBUG - 2018-04-12 22:44:52 --> Total execution time: 0.1108
INFO - 2018-04-12 17:14:52 --> Config Class Initialized
INFO - 2018-04-12 17:14:52 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:14:52 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:14:52 --> Utf8 Class Initialized
INFO - 2018-04-12 17:14:52 --> URI Class Initialized
INFO - 2018-04-12 17:14:52 --> Router Class Initialized
INFO - 2018-04-12 17:14:52 --> Output Class Initialized
INFO - 2018-04-12 17:14:52 --> Security Class Initialized
DEBUG - 2018-04-12 17:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:14:52 --> Input Class Initialized
INFO - 2018-04-12 17:14:52 --> Config Class Initialized
INFO - 2018-04-12 17:14:52 --> Hooks Class Initialized
INFO - 2018-04-12 17:14:52 --> Language Class Initialized
DEBUG - 2018-04-12 17:14:52 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:14:52 --> Utf8 Class Initialized
INFO - 2018-04-12 17:14:52 --> URI Class Initialized
INFO - 2018-04-12 17:14:52 --> Router Class Initialized
INFO - 2018-04-12 17:14:52 --> Output Class Initialized
INFO - 2018-04-12 17:14:52 --> Security Class Initialized
DEBUG - 2018-04-12 17:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:14:52 --> Input Class Initialized
INFO - 2018-04-12 17:14:52 --> Language Class Initialized
INFO - 2018-04-12 17:14:52 --> Config Class Initialized
INFO - 2018-04-12 17:14:52 --> Hooks Class Initialized
INFO - 2018-04-12 17:14:52 --> Language Class Initialized
INFO - 2018-04-12 17:14:52 --> Config Class Initialized
INFO - 2018-04-12 17:14:52 --> Loader Class Initialized
DEBUG - 2018-04-12 17:14:52 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:14:52 --> Utf8 Class Initialized
INFO - 2018-04-12 22:44:52 --> Helper loaded: url_helper
INFO - 2018-04-12 17:14:52 --> URI Class Initialized
INFO - 2018-04-12 22:44:52 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:44:52 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:44:52 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:44:52 --> Helper loaded: users_helper
INFO - 2018-04-12 17:14:52 --> Router Class Initialized
INFO - 2018-04-12 17:14:52 --> Output Class Initialized
INFO - 2018-04-12 17:14:52 --> Security Class Initialized
INFO - 2018-04-12 17:14:52 --> Language Class Initialized
INFO - 2018-04-12 17:14:52 --> Config Class Initialized
INFO - 2018-04-12 17:14:52 --> Loader Class Initialized
DEBUG - 2018-04-12 17:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:14:52 --> Input Class Initialized
INFO - 2018-04-12 22:44:52 --> Helper loaded: url_helper
INFO - 2018-04-12 17:14:52 --> Language Class Initialized
INFO - 2018-04-12 22:44:52 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:44:52 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:44:52 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:44:52 --> Helper loaded: users_helper
INFO - 2018-04-12 22:44:52 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:44:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:44:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 17:14:52 --> Config Class Initialized
INFO - 2018-04-12 17:14:52 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:14:52 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:14:52 --> Utf8 Class Initialized
INFO - 2018-04-12 17:14:52 --> URI Class Initialized
INFO - 2018-04-12 22:44:52 --> Helper loaded: form_helper
INFO - 2018-04-12 22:44:52 --> Form Validation Class Initialized
INFO - 2018-04-12 22:44:52 --> Controller Class Initialized
INFO - 2018-04-12 22:44:52 --> Database Driver Class Initialized
INFO - 2018-04-12 17:14:52 --> Router Class Initialized
INFO - 2018-04-12 17:14:52 --> Language Class Initialized
INFO - 2018-04-12 17:14:52 --> Config Class Initialized
INFO - 2018-04-12 17:14:52 --> Loader Class Initialized
DEBUG - 2018-04-12 22:44:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:44:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 17:14:52 --> Output Class Initialized
INFO - 2018-04-12 22:44:52 --> Helper loaded: url_helper
INFO - 2018-04-12 22:44:52 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:44:52 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:44:52 --> Model Class Initialized
INFO - 2018-04-12 17:14:52 --> Security Class Initialized
INFO - 2018-04-12 22:44:52 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:44:52 --> Helper loaded: inflector_helper
INFO - 2018-04-12 22:44:52 --> Helper loaded: users_helper
DEBUG - 2018-04-12 17:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:14:52 --> Input Class Initialized
INFO - 2018-04-12 17:14:52 --> Language Class Initialized
DEBUG - 2018-04-12 22:44:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:44:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:44:52 --> Helper loaded: form_helper
INFO - 2018-04-12 22:44:52 --> Form Validation Class Initialized
INFO - 2018-04-12 22:44:52 --> Controller Class Initialized
INFO - 2018-04-12 22:44:52 --> Model Class Initialized
INFO - 2018-04-12 22:44:52 --> Model Class Initialized
INFO - 2018-04-12 22:44:52 --> Model Class Initialized
INFO - 2018-04-12 22:44:52 --> Model Class Initialized
INFO - 2018-04-12 22:44:52 --> Model Class Initialized
INFO - 2018-04-12 22:44:52 --> Model Class Initialized
INFO - 2018-04-12 22:44:52 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-12 22:44:52 --> Model Class Initialized
INFO - 2018-04-12 22:44:52 --> Final output sent to browser
DEBUG - 2018-04-12 22:44:52 --> Total execution time: 0.1058
INFO - 2018-04-12 22:44:52 --> Database Driver Class Initialized
INFO - 2018-04-12 22:44:52 --> Model Class Initialized
INFO - 2018-04-12 22:44:52 --> Helper loaded: inflector_helper
INFO - 2018-04-12 17:14:52 --> Language Class Initialized
INFO - 2018-04-12 17:14:52 --> Config Class Initialized
INFO - 2018-04-12 17:14:52 --> Loader Class Initialized
DEBUG - 2018-04-12 22:44:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-04-12 22:44:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:44:52 --> Helper loaded: url_helper
INFO - 2018-04-12 22:44:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:44:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:44:52 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:44:52 --> Model Class Initialized
INFO - 2018-04-12 22:44:52 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:44:52 --> Model Class Initialized
INFO - 2018-04-12 22:44:52 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:44:52 --> Model Class Initialized
INFO - 2018-04-12 22:44:52 --> Helper loaded: users_helper
INFO - 2018-04-12 22:44:52 --> Model Class Initialized
INFO - 2018-04-12 22:44:52 --> Model Class Initialized
INFO - 2018-04-12 22:44:52 --> Model Class Initialized
INFO - 2018-04-12 22:44:52 --> Model Class Initialized
INFO - 2018-04-12 22:44:52 --> Model Class Initialized
INFO - 2018-04-12 22:44:52 --> Model Class Initialized
INFO - 2018-04-12 22:44:52 --> Model Class Initialized
INFO - 2018-04-12 22:44:52 --> Helper loaded: form_helper
INFO - 2018-04-12 22:44:52 --> Form Validation Class Initialized
INFO - 2018-04-12 22:44:52 --> Controller Class Initialized
INFO - 2018-04-12 22:44:52 --> Model Class Initialized
INFO - 2018-04-12 22:44:52 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-12 22:44:52 --> Model Class Initialized
INFO - 2018-04-12 22:44:52 --> Database Driver Class Initialized
INFO - 2018-04-12 22:44:52 --> Model Class Initialized
INFO - 2018-04-12 22:44:52 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:44:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:44:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-04-12 22:44:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:44:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:44:52 --> Model Class Initialized
INFO - 2018-04-12 22:44:52 --> Model Class Initialized
INFO - 2018-04-12 22:44:52 --> Model Class Initialized
INFO - 2018-04-12 22:44:52 --> Model Class Initialized
INFO - 2018-04-12 22:44:52 --> Model Class Initialized
INFO - 2018-04-12 22:44:52 --> Model Class Initialized
INFO - 2018-04-12 22:44:52 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-12 22:44:52 --> Helper loaded: form_helper
INFO - 2018-04-12 22:44:52 --> Form Validation Class Initialized
INFO - 2018-04-12 22:44:52 --> Controller Class Initialized
INFO - 2018-04-12 22:44:52 --> Model Class Initialized
INFO - 2018-04-12 22:44:52 --> Final output sent to browser
DEBUG - 2018-04-12 22:44:52 --> Total execution time: 0.1145
INFO - 2018-04-12 22:44:52 --> Final output sent to browser
DEBUG - 2018-04-12 22:44:52 --> Total execution time: 0.1382
INFO - 2018-04-12 22:44:52 --> Model Class Initialized
INFO - 2018-04-12 22:44:52 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:44:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:44:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:44:52 --> Model Class Initialized
INFO - 2018-04-12 22:44:52 --> Model Class Initialized
INFO - 2018-04-12 22:44:52 --> Model Class Initialized
INFO - 2018-04-12 22:44:52 --> Model Class Initialized
INFO - 2018-04-12 22:44:52 --> Model Class Initialized
INFO - 2018-04-12 22:44:52 --> Model Class Initialized
INFO - 2018-04-12 22:44:52 --> Model Class Initialized
INFO - 2018-04-12 22:44:52 --> Model Class Initialized
INFO - 2018-04-12 22:44:52 --> Model Class Initialized
INFO - 2018-04-12 22:44:52 --> Model Class Initialized
INFO - 2018-04-12 22:44:52 --> Model Class Initialized
INFO - 2018-04-12 22:44:52 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-12 22:44:52 --> Model Class Initialized
INFO - 2018-04-12 22:44:52 --> Final output sent to browser
DEBUG - 2018-04-12 22:44:52 --> Total execution time: 0.1174
INFO - 2018-04-12 17:14:58 --> Config Class Initialized
INFO - 2018-04-12 17:14:58 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:14:58 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:14:58 --> Utf8 Class Initialized
INFO - 2018-04-12 17:14:58 --> URI Class Initialized
INFO - 2018-04-12 17:14:58 --> Router Class Initialized
INFO - 2018-04-12 17:14:58 --> Output Class Initialized
INFO - 2018-04-12 17:14:58 --> Security Class Initialized
DEBUG - 2018-04-12 17:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:14:58 --> Input Class Initialized
INFO - 2018-04-12 17:14:58 --> Language Class Initialized
INFO - 2018-04-12 17:14:58 --> Language Class Initialized
INFO - 2018-04-12 17:14:58 --> Config Class Initialized
INFO - 2018-04-12 17:14:58 --> Loader Class Initialized
INFO - 2018-04-12 22:44:58 --> Helper loaded: url_helper
INFO - 2018-04-12 22:44:58 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:44:58 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:44:58 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:44:58 --> Helper loaded: users_helper
INFO - 2018-04-12 22:44:58 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:44:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:44:58 --> Helper loaded: form_helper
INFO - 2018-04-12 22:44:58 --> Form Validation Class Initialized
INFO - 2018-04-12 22:44:58 --> Controller Class Initialized
INFO - 2018-04-12 22:44:58 --> Model Class Initialized
INFO - 2018-04-12 22:44:58 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:44:58 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:44:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:44:58 --> Model Class Initialized
INFO - 2018-04-12 22:44:58 --> Model Class Initialized
INFO - 2018-04-12 22:44:58 --> Model Class Initialized
INFO - 2018-04-12 22:44:58 --> Model Class Initialized
INFO - 2018-04-12 22:44:58 --> Model Class Initialized
INFO - 2018-04-12 22:44:58 --> Model Class Initialized
INFO - 2018-04-12 22:44:58 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-04-12 22:44:58 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-04-12 22:44:58 --> Final output sent to browser
DEBUG - 2018-04-12 22:44:58 --> Total execution time: 0.1144
INFO - 2018-04-12 17:15:00 --> Config Class Initialized
INFO - 2018-04-12 17:15:00 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:15:00 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:15:00 --> Utf8 Class Initialized
INFO - 2018-04-12 17:15:00 --> URI Class Initialized
INFO - 2018-04-12 17:15:00 --> Router Class Initialized
INFO - 2018-04-12 17:15:00 --> Output Class Initialized
INFO - 2018-04-12 17:15:00 --> Security Class Initialized
DEBUG - 2018-04-12 17:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:15:00 --> Input Class Initialized
INFO - 2018-04-12 17:15:00 --> Language Class Initialized
INFO - 2018-04-12 17:15:00 --> Language Class Initialized
INFO - 2018-04-12 17:15:00 --> Config Class Initialized
INFO - 2018-04-12 17:15:00 --> Loader Class Initialized
INFO - 2018-04-12 22:45:00 --> Helper loaded: url_helper
INFO - 2018-04-12 22:45:00 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:45:00 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:45:00 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:45:00 --> Helper loaded: users_helper
INFO - 2018-04-12 22:45:00 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:45:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:45:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:45:00 --> Helper loaded: form_helper
INFO - 2018-04-12 22:45:00 --> Form Validation Class Initialized
INFO - 2018-04-12 22:45:00 --> Controller Class Initialized
INFO - 2018-04-12 22:45:00 --> Model Class Initialized
INFO - 2018-04-12 22:45:00 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:45:00 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:45:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:45:00 --> Model Class Initialized
INFO - 2018-04-12 22:45:00 --> Model Class Initialized
INFO - 2018-04-12 22:45:00 --> Model Class Initialized
INFO - 2018-04-12 22:45:00 --> Model Class Initialized
INFO - 2018-04-12 22:45:00 --> Model Class Initialized
INFO - 2018-04-12 22:45:00 --> Model Class Initialized
INFO - 2018-04-12 22:45:00 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-12 22:45:00 --> Model Class Initialized
INFO - 2018-04-12 22:45:00 --> Final output sent to browser
DEBUG - 2018-04-12 22:45:00 --> Total execution time: 0.1079
INFO - 2018-04-12 17:15:00 --> Config Class Initialized
INFO - 2018-04-12 17:15:00 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:15:00 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:15:00 --> Utf8 Class Initialized
INFO - 2018-04-12 17:15:00 --> URI Class Initialized
INFO - 2018-04-12 17:15:00 --> Router Class Initialized
INFO - 2018-04-12 17:15:00 --> Output Class Initialized
INFO - 2018-04-12 17:15:00 --> Security Class Initialized
DEBUG - 2018-04-12 17:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:15:00 --> Input Class Initialized
INFO - 2018-04-12 17:15:00 --> Language Class Initialized
INFO - 2018-04-12 17:15:00 --> Language Class Initialized
INFO - 2018-04-12 17:15:00 --> Config Class Initialized
INFO - 2018-04-12 17:15:00 --> Loader Class Initialized
INFO - 2018-04-12 22:45:00 --> Helper loaded: url_helper
INFO - 2018-04-12 22:45:00 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:45:00 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:45:00 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:45:00 --> Helper loaded: users_helper
INFO - 2018-04-12 22:45:00 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:45:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:45:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:45:00 --> Helper loaded: form_helper
INFO - 2018-04-12 22:45:00 --> Form Validation Class Initialized
INFO - 2018-04-12 22:45:00 --> Controller Class Initialized
INFO - 2018-04-12 22:45:00 --> Model Class Initialized
INFO - 2018-04-12 22:45:00 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:45:00 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:45:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:45:00 --> Model Class Initialized
INFO - 2018-04-12 22:45:00 --> Model Class Initialized
INFO - 2018-04-12 22:45:00 --> Model Class Initialized
INFO - 2018-04-12 22:45:00 --> Model Class Initialized
INFO - 2018-04-12 22:45:00 --> Model Class Initialized
INFO - 2018-04-12 22:45:00 --> Model Class Initialized
INFO - 2018-04-12 22:45:00 --> Model Class Initialized
INFO - 2018-04-12 22:45:00 --> Model Class Initialized
INFO - 2018-04-12 22:45:00 --> Model Class Initialized
INFO - 2018-04-12 22:45:00 --> Model Class Initialized
INFO - 2018-04-12 22:45:00 --> Model Class Initialized
INFO - 2018-04-12 22:45:00 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-12 22:45:00 --> Model Class Initialized
INFO - 2018-04-12 22:45:00 --> Final output sent to browser
DEBUG - 2018-04-12 22:45:00 --> Total execution time: 0.1256
INFO - 2018-04-12 17:15:01 --> Config Class Initialized
INFO - 2018-04-12 17:15:01 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:15:01 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:15:01 --> Utf8 Class Initialized
INFO - 2018-04-12 17:15:01 --> URI Class Initialized
INFO - 2018-04-12 17:15:01 --> Router Class Initialized
INFO - 2018-04-12 17:15:01 --> Output Class Initialized
INFO - 2018-04-12 17:15:01 --> Security Class Initialized
DEBUG - 2018-04-12 17:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:15:01 --> Input Class Initialized
INFO - 2018-04-12 17:15:01 --> Language Class Initialized
INFO - 2018-04-12 17:15:01 --> Language Class Initialized
INFO - 2018-04-12 17:15:01 --> Config Class Initialized
INFO - 2018-04-12 17:15:01 --> Loader Class Initialized
INFO - 2018-04-12 22:45:01 --> Helper loaded: url_helper
INFO - 2018-04-12 22:45:01 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:45:01 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:45:01 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:45:01 --> Helper loaded: users_helper
INFO - 2018-04-12 22:45:01 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:45:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:45:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 17:15:01 --> Config Class Initialized
INFO - 2018-04-12 17:15:01 --> Hooks Class Initialized
INFO - 2018-04-12 22:45:01 --> Helper loaded: form_helper
INFO - 2018-04-12 22:45:01 --> Form Validation Class Initialized
INFO - 2018-04-12 22:45:01 --> Controller Class Initialized
DEBUG - 2018-04-12 17:15:01 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:15:01 --> Utf8 Class Initialized
INFO - 2018-04-12 17:15:01 --> URI Class Initialized
INFO - 2018-04-12 17:15:01 --> Router Class Initialized
INFO - 2018-04-12 22:45:01 --> Model Class Initialized
INFO - 2018-04-12 22:45:01 --> Helper loaded: inflector_helper
INFO - 2018-04-12 17:15:01 --> Output Class Initialized
INFO - 2018-04-12 17:15:01 --> Security Class Initialized
DEBUG - 2018-04-12 22:45:01 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-04-12 17:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 22:45:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 17:15:01 --> Input Class Initialized
INFO - 2018-04-12 17:15:01 --> Language Class Initialized
INFO - 2018-04-12 22:45:01 --> Model Class Initialized
INFO - 2018-04-12 22:45:01 --> Model Class Initialized
INFO - 2018-04-12 22:45:01 --> Model Class Initialized
INFO - 2018-04-12 22:45:01 --> Model Class Initialized
INFO - 2018-04-12 22:45:01 --> Model Class Initialized
INFO - 2018-04-12 22:45:01 --> Model Class Initialized
INFO - 2018-04-12 22:45:01 --> Model Class Initialized
INFO - 2018-04-12 22:45:01 --> Model Class Initialized
INFO - 2018-04-12 22:45:01 --> Model Class Initialized
INFO - 2018-04-12 22:45:01 --> Model Class Initialized
INFO - 2018-04-12 22:45:01 --> Model Class Initialized
INFO - 2018-04-12 22:45:01 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-12 22:45:01 --> Model Class Initialized
INFO - 2018-04-12 17:15:01 --> Language Class Initialized
INFO - 2018-04-12 17:15:01 --> Config Class Initialized
INFO - 2018-04-12 17:15:01 --> Loader Class Initialized
INFO - 2018-04-12 22:45:01 --> Helper loaded: url_helper
INFO - 2018-04-12 22:45:01 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:45:01 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:45:01 --> Final output sent to browser
DEBUG - 2018-04-12 22:45:01 --> Total execution time: 0.1857
INFO - 2018-04-12 22:45:01 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:45:01 --> Helper loaded: users_helper
INFO - 2018-04-12 22:45:01 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:45:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:45:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:45:02 --> Helper loaded: form_helper
INFO - 2018-04-12 22:45:02 --> Form Validation Class Initialized
INFO - 2018-04-12 22:45:02 --> Controller Class Initialized
INFO - 2018-04-12 22:45:02 --> Model Class Initialized
INFO - 2018-04-12 22:45:02 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:45:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:45:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:45:02 --> Model Class Initialized
INFO - 2018-04-12 22:45:02 --> Model Class Initialized
INFO - 2018-04-12 22:45:02 --> Model Class Initialized
INFO - 2018-04-12 22:45:02 --> Model Class Initialized
INFO - 2018-04-12 22:45:02 --> Model Class Initialized
INFO - 2018-04-12 22:45:02 --> Model Class Initialized
INFO - 2018-04-12 22:45:02 --> Model Class Initialized
INFO - 2018-04-12 22:45:02 --> Model Class Initialized
INFO - 2018-04-12 22:45:02 --> Model Class Initialized
INFO - 2018-04-12 22:45:02 --> Model Class Initialized
INFO - 2018-04-12 22:45:02 --> Model Class Initialized
INFO - 2018-04-12 22:45:02 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-12 22:45:02 --> Final output sent to browser
DEBUG - 2018-04-12 22:45:02 --> Total execution time: 0.1788
INFO - 2018-04-12 17:15:04 --> Config Class Initialized
INFO - 2018-04-12 17:15:04 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:15:04 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:15:04 --> Utf8 Class Initialized
INFO - 2018-04-12 17:15:04 --> URI Class Initialized
INFO - 2018-04-12 17:15:04 --> Router Class Initialized
INFO - 2018-04-12 17:15:04 --> Output Class Initialized
INFO - 2018-04-12 17:15:04 --> Security Class Initialized
DEBUG - 2018-04-12 17:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:15:04 --> Input Class Initialized
INFO - 2018-04-12 17:15:04 --> Language Class Initialized
INFO - 2018-04-12 17:15:04 --> Language Class Initialized
INFO - 2018-04-12 17:15:04 --> Config Class Initialized
INFO - 2018-04-12 17:15:04 --> Loader Class Initialized
INFO - 2018-04-12 22:45:04 --> Helper loaded: url_helper
INFO - 2018-04-12 22:45:04 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:45:04 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:45:04 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:45:04 --> Helper loaded: users_helper
INFO - 2018-04-12 22:45:04 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:45:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:45:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:45:04 --> Helper loaded: form_helper
INFO - 2018-04-12 22:45:04 --> Form Validation Class Initialized
INFO - 2018-04-12 22:45:04 --> Controller Class Initialized
INFO - 2018-04-12 22:45:04 --> Model Class Initialized
INFO - 2018-04-12 22:45:04 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:45:04 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:45:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:45:04 --> Model Class Initialized
INFO - 2018-04-12 22:45:04 --> Model Class Initialized
INFO - 2018-04-12 22:45:04 --> Model Class Initialized
INFO - 2018-04-12 22:45:04 --> Model Class Initialized
INFO - 2018-04-12 22:45:04 --> Model Class Initialized
INFO - 2018-04-12 22:45:04 --> Model Class Initialized
INFO - 2018-04-12 22:45:04 --> Model Class Initialized
INFO - 2018-04-12 22:45:04 --> Model Class Initialized
INFO - 2018-04-12 22:45:04 --> Model Class Initialized
INFO - 2018-04-12 22:45:04 --> Model Class Initialized
INFO - 2018-04-12 22:45:04 --> Model Class Initialized
INFO - 2018-04-12 22:45:04 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-12 22:45:04 --> Final output sent to browser
DEBUG - 2018-04-12 22:45:04 --> Total execution time: 0.1282
INFO - 2018-04-12 17:15:07 --> Config Class Initialized
INFO - 2018-04-12 17:15:07 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:15:07 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:15:07 --> Utf8 Class Initialized
INFO - 2018-04-12 17:15:07 --> URI Class Initialized
INFO - 2018-04-12 17:15:07 --> Router Class Initialized
INFO - 2018-04-12 17:15:07 --> Output Class Initialized
INFO - 2018-04-12 17:15:07 --> Security Class Initialized
DEBUG - 2018-04-12 17:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:15:07 --> Input Class Initialized
INFO - 2018-04-12 17:15:07 --> Language Class Initialized
INFO - 2018-04-12 17:15:07 --> Language Class Initialized
INFO - 2018-04-12 17:15:07 --> Config Class Initialized
INFO - 2018-04-12 17:15:07 --> Loader Class Initialized
INFO - 2018-04-12 22:45:07 --> Helper loaded: url_helper
INFO - 2018-04-12 22:45:07 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:45:07 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:45:07 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:45:07 --> Helper loaded: users_helper
INFO - 2018-04-12 22:45:07 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:45:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:45:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:45:07 --> Helper loaded: form_helper
INFO - 2018-04-12 22:45:07 --> Form Validation Class Initialized
INFO - 2018-04-12 22:45:07 --> Controller Class Initialized
INFO - 2018-04-12 22:45:07 --> Model Class Initialized
INFO - 2018-04-12 22:45:07 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:45:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:45:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:45:07 --> Model Class Initialized
INFO - 2018-04-12 22:45:07 --> Model Class Initialized
INFO - 2018-04-12 22:45:07 --> Model Class Initialized
INFO - 2018-04-12 22:45:07 --> Model Class Initialized
INFO - 2018-04-12 22:45:07 --> Model Class Initialized
INFO - 2018-04-12 22:45:07 --> Model Class Initialized
INFO - 2018-04-12 22:45:07 --> Model Class Initialized
INFO - 2018-04-12 22:45:07 --> Model Class Initialized
INFO - 2018-04-12 22:45:07 --> Model Class Initialized
INFO - 2018-04-12 22:45:07 --> Model Class Initialized
INFO - 2018-04-12 22:45:07 --> Model Class Initialized
INFO - 2018-04-12 22:45:07 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-12 22:45:07 --> Model Class Initialized
INFO - 2018-04-12 22:45:07 --> Final output sent to browser
DEBUG - 2018-04-12 22:45:07 --> Total execution time: 0.1133
INFO - 2018-04-12 17:15:07 --> Config Class Initialized
INFO - 2018-04-12 17:15:07 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:15:07 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:15:07 --> Utf8 Class Initialized
INFO - 2018-04-12 17:15:07 --> URI Class Initialized
INFO - 2018-04-12 17:15:07 --> Router Class Initialized
INFO - 2018-04-12 17:15:07 --> Output Class Initialized
INFO - 2018-04-12 17:15:07 --> Security Class Initialized
DEBUG - 2018-04-12 17:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:15:07 --> Input Class Initialized
INFO - 2018-04-12 17:15:07 --> Language Class Initialized
INFO - 2018-04-12 17:15:07 --> Language Class Initialized
INFO - 2018-04-12 17:15:07 --> Config Class Initialized
INFO - 2018-04-12 17:15:07 --> Loader Class Initialized
INFO - 2018-04-12 22:45:07 --> Helper loaded: url_helper
INFO - 2018-04-12 22:45:07 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:45:07 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:45:07 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:45:07 --> Helper loaded: users_helper
INFO - 2018-04-12 22:45:07 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:45:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:45:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:45:07 --> Helper loaded: form_helper
INFO - 2018-04-12 22:45:07 --> Form Validation Class Initialized
INFO - 2018-04-12 22:45:07 --> Controller Class Initialized
INFO - 2018-04-12 22:45:07 --> Model Class Initialized
INFO - 2018-04-12 22:45:07 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:45:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:45:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:45:07 --> Model Class Initialized
INFO - 2018-04-12 22:45:07 --> Model Class Initialized
INFO - 2018-04-12 22:45:07 --> Model Class Initialized
INFO - 2018-04-12 22:45:07 --> Model Class Initialized
INFO - 2018-04-12 22:45:07 --> Model Class Initialized
INFO - 2018-04-12 22:45:07 --> Model Class Initialized
INFO - 2018-04-12 22:45:07 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-12 22:45:07 --> Model Class Initialized
INFO - 2018-04-12 22:45:07 --> Final output sent to browser
DEBUG - 2018-04-12 22:45:07 --> Total execution time: 0.1093
INFO - 2018-04-12 17:15:10 --> Config Class Initialized
INFO - 2018-04-12 17:15:10 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:15:10 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:15:10 --> Utf8 Class Initialized
INFO - 2018-04-12 17:15:10 --> URI Class Initialized
INFO - 2018-04-12 17:15:10 --> Router Class Initialized
INFO - 2018-04-12 17:15:10 --> Output Class Initialized
INFO - 2018-04-12 17:15:10 --> Security Class Initialized
DEBUG - 2018-04-12 17:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:15:10 --> Input Class Initialized
INFO - 2018-04-12 17:15:10 --> Language Class Initialized
INFO - 2018-04-12 17:15:10 --> Config Class Initialized
INFO - 2018-04-12 17:15:10 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:15:10 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:15:10 --> Utf8 Class Initialized
INFO - 2018-04-12 17:15:10 --> URI Class Initialized
INFO - 2018-04-12 17:15:10 --> Language Class Initialized
INFO - 2018-04-12 17:15:10 --> Config Class Initialized
INFO - 2018-04-12 17:15:10 --> Loader Class Initialized
INFO - 2018-04-12 17:15:10 --> Router Class Initialized
INFO - 2018-04-12 22:45:10 --> Helper loaded: url_helper
INFO - 2018-04-12 22:45:10 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:45:10 --> Helper loaded: settings_helper
INFO - 2018-04-12 17:15:10 --> Output Class Initialized
INFO - 2018-04-12 22:45:10 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:45:10 --> Helper loaded: users_helper
INFO - 2018-04-12 17:15:10 --> Security Class Initialized
DEBUG - 2018-04-12 17:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:15:10 --> Input Class Initialized
INFO - 2018-04-12 17:15:10 --> Language Class Initialized
INFO - 2018-04-12 22:45:10 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:45:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:45:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 17:15:10 --> Language Class Initialized
INFO - 2018-04-12 17:15:10 --> Config Class Initialized
INFO - 2018-04-12 17:15:10 --> Loader Class Initialized
INFO - 2018-04-12 22:45:10 --> Helper loaded: form_helper
INFO - 2018-04-12 22:45:10 --> Form Validation Class Initialized
INFO - 2018-04-12 22:45:10 --> Controller Class Initialized
INFO - 2018-04-12 22:45:10 --> Helper loaded: url_helper
INFO - 2018-04-12 22:45:10 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:45:10 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:45:10 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:45:10 --> Helper loaded: users_helper
INFO - 2018-04-12 22:45:10 --> Model Class Initialized
INFO - 2018-04-12 22:45:10 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:45:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:45:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:45:10 --> Model Class Initialized
INFO - 2018-04-12 22:45:10 --> Model Class Initialized
INFO - 2018-04-12 22:45:10 --> Model Class Initialized
INFO - 2018-04-12 22:45:10 --> Model Class Initialized
INFO - 2018-04-12 22:45:10 --> Model Class Initialized
INFO - 2018-04-12 22:45:10 --> Model Class Initialized
INFO - 2018-04-12 22:45:10 --> Model Class Initialized
INFO - 2018-04-12 22:45:10 --> Model Class Initialized
INFO - 2018-04-12 22:45:10 --> Model Class Initialized
INFO - 2018-04-12 22:45:10 --> Model Class Initialized
INFO - 2018-04-12 22:45:10 --> Database Driver Class Initialized
INFO - 2018-04-12 22:45:10 --> Model Class Initialized
INFO - 2018-04-12 22:45:10 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-12 22:45:10 --> Model Class Initialized
DEBUG - 2018-04-12 22:45:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:45:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:45:10 --> Helper loaded: form_helper
INFO - 2018-04-12 22:45:10 --> Form Validation Class Initialized
INFO - 2018-04-12 22:45:10 --> Controller Class Initialized
INFO - 2018-04-12 22:45:10 --> Final output sent to browser
DEBUG - 2018-04-12 22:45:10 --> Total execution time: 0.1122
INFO - 2018-04-12 22:45:10 --> Model Class Initialized
INFO - 2018-04-12 22:45:10 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:45:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:45:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:45:10 --> Model Class Initialized
INFO - 2018-04-12 22:45:10 --> Model Class Initialized
INFO - 2018-04-12 22:45:10 --> Model Class Initialized
INFO - 2018-04-12 22:45:10 --> Model Class Initialized
INFO - 2018-04-12 22:45:10 --> Model Class Initialized
INFO - 2018-04-12 22:45:10 --> Model Class Initialized
INFO - 2018-04-12 22:45:10 --> Model Class Initialized
INFO - 2018-04-12 22:45:10 --> Model Class Initialized
INFO - 2018-04-12 22:45:10 --> Model Class Initialized
INFO - 2018-04-12 22:45:10 --> Model Class Initialized
INFO - 2018-04-12 22:45:10 --> Model Class Initialized
INFO - 2018-04-12 22:45:10 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-12 22:45:10 --> Final output sent to browser
DEBUG - 2018-04-12 22:45:10 --> Total execution time: 0.1229
INFO - 2018-04-12 17:15:11 --> Config Class Initialized
INFO - 2018-04-12 17:15:11 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:15:11 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:15:11 --> Utf8 Class Initialized
INFO - 2018-04-12 17:15:11 --> URI Class Initialized
INFO - 2018-04-12 17:15:11 --> Router Class Initialized
INFO - 2018-04-12 17:15:11 --> Output Class Initialized
INFO - 2018-04-12 17:15:11 --> Security Class Initialized
DEBUG - 2018-04-12 17:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:15:11 --> Input Class Initialized
INFO - 2018-04-12 17:15:11 --> Language Class Initialized
INFO - 2018-04-12 17:15:11 --> Language Class Initialized
INFO - 2018-04-12 17:15:11 --> Config Class Initialized
INFO - 2018-04-12 17:15:11 --> Loader Class Initialized
INFO - 2018-04-12 22:45:11 --> Helper loaded: url_helper
INFO - 2018-04-12 22:45:11 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:45:11 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:45:11 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:45:11 --> Helper loaded: users_helper
INFO - 2018-04-12 22:45:11 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:45:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:45:11 --> Helper loaded: form_helper
INFO - 2018-04-12 22:45:11 --> Form Validation Class Initialized
INFO - 2018-04-12 22:45:11 --> Controller Class Initialized
INFO - 2018-04-12 22:45:11 --> Model Class Initialized
INFO - 2018-04-12 22:45:11 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:45:11 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:45:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:45:11 --> Model Class Initialized
INFO - 2018-04-12 22:45:11 --> Model Class Initialized
INFO - 2018-04-12 22:45:11 --> Model Class Initialized
INFO - 2018-04-12 22:45:11 --> Model Class Initialized
INFO - 2018-04-12 22:45:11 --> Final output sent to browser
DEBUG - 2018-04-12 22:45:11 --> Total execution time: 0.1087
INFO - 2018-04-12 17:15:14 --> Config Class Initialized
INFO - 2018-04-12 17:15:14 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:15:14 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:15:14 --> Utf8 Class Initialized
INFO - 2018-04-12 17:15:14 --> URI Class Initialized
INFO - 2018-04-12 17:15:14 --> Router Class Initialized
INFO - 2018-04-12 17:15:14 --> Output Class Initialized
INFO - 2018-04-12 17:15:14 --> Security Class Initialized
DEBUG - 2018-04-12 17:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:15:14 --> Input Class Initialized
INFO - 2018-04-12 17:15:14 --> Language Class Initialized
INFO - 2018-04-12 17:15:14 --> Language Class Initialized
INFO - 2018-04-12 17:15:14 --> Config Class Initialized
INFO - 2018-04-12 17:15:14 --> Loader Class Initialized
INFO - 2018-04-12 22:45:14 --> Helper loaded: url_helper
INFO - 2018-04-12 22:45:14 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:45:14 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:45:14 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:45:14 --> Helper loaded: users_helper
INFO - 2018-04-12 22:45:14 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:45:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:45:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:45:14 --> Helper loaded: form_helper
INFO - 2018-04-12 22:45:14 --> Form Validation Class Initialized
INFO - 2018-04-12 22:45:14 --> Controller Class Initialized
INFO - 2018-04-12 22:45:14 --> Model Class Initialized
INFO - 2018-04-12 22:45:14 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:45:14 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:45:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:45:14 --> Model Class Initialized
INFO - 2018-04-12 22:45:14 --> Model Class Initialized
INFO - 2018-04-12 22:45:14 --> Final output sent to browser
DEBUG - 2018-04-12 22:45:14 --> Total execution time: 0.1086
INFO - 2018-04-12 17:15:17 --> Config Class Initialized
INFO - 2018-04-12 17:15:17 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:15:17 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:15:17 --> Utf8 Class Initialized
INFO - 2018-04-12 17:15:17 --> URI Class Initialized
INFO - 2018-04-12 17:15:17 --> Router Class Initialized
INFO - 2018-04-12 17:15:17 --> Output Class Initialized
INFO - 2018-04-12 17:15:17 --> Security Class Initialized
DEBUG - 2018-04-12 17:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:15:17 --> Input Class Initialized
INFO - 2018-04-12 17:15:17 --> Language Class Initialized
INFO - 2018-04-12 17:15:17 --> Language Class Initialized
INFO - 2018-04-12 17:15:17 --> Config Class Initialized
INFO - 2018-04-12 17:15:17 --> Loader Class Initialized
INFO - 2018-04-12 22:45:17 --> Helper loaded: url_helper
INFO - 2018-04-12 22:45:17 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:45:17 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:45:17 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:45:17 --> Helper loaded: users_helper
INFO - 2018-04-12 22:45:17 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:45:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:45:17 --> Helper loaded: form_helper
INFO - 2018-04-12 22:45:17 --> Form Validation Class Initialized
INFO - 2018-04-12 22:45:17 --> Controller Class Initialized
INFO - 2018-04-12 22:45:17 --> Model Class Initialized
INFO - 2018-04-12 22:45:17 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:45:17 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:45:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:45:17 --> Model Class Initialized
INFO - 2018-04-12 22:45:17 --> Model Class Initialized
INFO - 2018-04-12 22:45:17 --> Final output sent to browser
DEBUG - 2018-04-12 22:45:17 --> Total execution time: 0.1328
INFO - 2018-04-12 17:15:23 --> Config Class Initialized
INFO - 2018-04-12 17:15:23 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:15:23 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:15:23 --> Utf8 Class Initialized
INFO - 2018-04-12 17:15:23 --> URI Class Initialized
INFO - 2018-04-12 17:15:23 --> Router Class Initialized
INFO - 2018-04-12 17:15:23 --> Output Class Initialized
INFO - 2018-04-12 17:15:23 --> Security Class Initialized
DEBUG - 2018-04-12 17:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:15:23 --> Input Class Initialized
INFO - 2018-04-12 17:15:23 --> Language Class Initialized
INFO - 2018-04-12 17:15:23 --> Language Class Initialized
INFO - 2018-04-12 17:15:23 --> Config Class Initialized
INFO - 2018-04-12 17:15:23 --> Loader Class Initialized
INFO - 2018-04-12 22:45:23 --> Helper loaded: url_helper
INFO - 2018-04-12 22:45:23 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:45:23 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:45:23 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:45:23 --> Helper loaded: users_helper
INFO - 2018-04-12 22:45:23 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:45:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:45:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:45:23 --> Helper loaded: form_helper
INFO - 2018-04-12 22:45:23 --> Form Validation Class Initialized
INFO - 2018-04-12 22:45:23 --> Controller Class Initialized
INFO - 2018-04-12 22:45:23 --> Model Class Initialized
INFO - 2018-04-12 22:45:23 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:45:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:45:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:45:23 --> Model Class Initialized
INFO - 2018-04-12 22:45:23 --> Model Class Initialized
INFO - 2018-04-12 22:45:23 --> Model Class Initialized
INFO - 2018-04-12 22:45:23 --> Model Class Initialized
INFO - 2018-04-12 22:45:23 --> Final output sent to browser
DEBUG - 2018-04-12 22:45:23 --> Total execution time: 0.1004
INFO - 2018-04-12 17:15:23 --> Config Class Initialized
INFO - 2018-04-12 17:15:23 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:15:23 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:15:23 --> Utf8 Class Initialized
INFO - 2018-04-12 17:15:23 --> URI Class Initialized
INFO - 2018-04-12 17:15:23 --> Router Class Initialized
INFO - 2018-04-12 17:15:23 --> Output Class Initialized
INFO - 2018-04-12 17:15:23 --> Security Class Initialized
DEBUG - 2018-04-12 17:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:15:23 --> Input Class Initialized
INFO - 2018-04-12 17:15:23 --> Language Class Initialized
INFO - 2018-04-12 17:15:23 --> Language Class Initialized
INFO - 2018-04-12 17:15:23 --> Config Class Initialized
INFO - 2018-04-12 17:15:23 --> Loader Class Initialized
INFO - 2018-04-12 22:45:23 --> Helper loaded: url_helper
INFO - 2018-04-12 22:45:23 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:45:23 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:45:23 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:45:23 --> Helper loaded: users_helper
INFO - 2018-04-12 22:45:23 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:45:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:45:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:45:23 --> Helper loaded: form_helper
INFO - 2018-04-12 22:45:23 --> Form Validation Class Initialized
INFO - 2018-04-12 22:45:23 --> Controller Class Initialized
INFO - 2018-04-12 22:45:23 --> Model Class Initialized
INFO - 2018-04-12 22:45:23 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:45:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:45:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:45:23 --> Model Class Initialized
INFO - 2018-04-12 22:45:23 --> Model Class Initialized
INFO - 2018-04-12 22:45:23 --> Model Class Initialized
INFO - 2018-04-12 22:45:23 --> Model Class Initialized
INFO - 2018-04-12 22:45:23 --> Final output sent to browser
DEBUG - 2018-04-12 22:45:23 --> Total execution time: 0.1012
INFO - 2018-04-12 17:15:24 --> Config Class Initialized
INFO - 2018-04-12 17:15:24 --> Config Class Initialized
INFO - 2018-04-12 17:15:24 --> Hooks Class Initialized
INFO - 2018-04-12 17:15:24 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:15:24 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:15:24 --> Utf8 Class Initialized
DEBUG - 2018-04-12 17:15:24 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:15:24 --> Utf8 Class Initialized
INFO - 2018-04-12 17:15:24 --> URI Class Initialized
INFO - 2018-04-12 17:15:24 --> URI Class Initialized
INFO - 2018-04-12 17:15:24 --> Router Class Initialized
INFO - 2018-04-12 17:15:24 --> Router Class Initialized
INFO - 2018-04-12 17:15:24 --> Output Class Initialized
INFO - 2018-04-12 17:15:24 --> Output Class Initialized
INFO - 2018-04-12 17:15:24 --> Security Class Initialized
INFO - 2018-04-12 17:15:24 --> Security Class Initialized
DEBUG - 2018-04-12 17:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:15:24 --> Input Class Initialized
DEBUG - 2018-04-12 17:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:15:24 --> Input Class Initialized
INFO - 2018-04-12 17:15:24 --> Language Class Initialized
INFO - 2018-04-12 17:15:24 --> Language Class Initialized
INFO - 2018-04-12 17:15:24 --> Language Class Initialized
INFO - 2018-04-12 17:15:24 --> Config Class Initialized
INFO - 2018-04-12 17:15:24 --> Loader Class Initialized
INFO - 2018-04-12 17:15:24 --> Language Class Initialized
INFO - 2018-04-12 17:15:24 --> Config Class Initialized
INFO - 2018-04-12 17:15:24 --> Loader Class Initialized
INFO - 2018-04-12 22:45:24 --> Helper loaded: url_helper
INFO - 2018-04-12 22:45:24 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:45:24 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:45:24 --> Helper loaded: url_helper
INFO - 2018-04-12 22:45:24 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:45:24 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:45:24 --> Helper loaded: users_helper
INFO - 2018-04-12 22:45:24 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:45:24 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:45:24 --> Helper loaded: users_helper
INFO - 2018-04-12 22:45:24 --> Database Driver Class Initialized
INFO - 2018-04-12 22:45:24 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:45:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:45:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-04-12 22:45:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:45:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:45:24 --> Helper loaded: form_helper
INFO - 2018-04-12 22:45:24 --> Form Validation Class Initialized
INFO - 2018-04-12 22:45:24 --> Controller Class Initialized
INFO - 2018-04-12 22:45:24 --> Helper loaded: form_helper
INFO - 2018-04-12 22:45:24 --> Form Validation Class Initialized
INFO - 2018-04-12 22:45:24 --> Controller Class Initialized
INFO - 2018-04-12 22:45:24 --> Model Class Initialized
INFO - 2018-04-12 22:45:24 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:45:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:45:24 --> Model Class Initialized
INFO - 2018-04-12 22:45:24 --> Helper loaded: inflector_helper
INFO - 2018-04-12 22:45:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:45:24 --> Model Class Initialized
INFO - 2018-04-12 22:45:24 --> Model Class Initialized
INFO - 2018-04-12 22:45:24 --> Model Class Initialized
DEBUG - 2018-04-12 22:45:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:45:24 --> Model Class Initialized
INFO - 2018-04-12 22:45:24 --> Model Class Initialized
INFO - 2018-04-12 22:45:24 --> Model Class Initialized
INFO - 2018-04-12 22:45:24 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-12 22:45:24 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2018-04-12 22:45:24 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-04-12 22:45:24 --> Model Class Initialized
INFO - 2018-04-12 22:45:24 --> Model Class Initialized
INFO - 2018-04-12 22:45:24 --> Final output sent to browser
DEBUG - 2018-04-12 22:45:24 --> Total execution time: 0.1038
INFO - 2018-04-12 22:45:24 --> Model Class Initialized
INFO - 2018-04-12 22:45:24 --> Model Class Initialized
INFO - 2018-04-12 22:45:24 --> Model Class Initialized
INFO - 2018-04-12 22:45:24 --> Model Class Initialized
INFO - 2018-04-12 22:45:24 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-04-12 22:45:24 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-04-12 22:45:24 --> Final output sent to browser
DEBUG - 2018-04-12 22:45:24 --> Total execution time: 0.1107
INFO - 2018-04-12 17:15:25 --> Config Class Initialized
INFO - 2018-04-12 17:15:25 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:15:25 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:15:25 --> Utf8 Class Initialized
INFO - 2018-04-12 17:15:25 --> URI Class Initialized
INFO - 2018-04-12 17:15:25 --> Router Class Initialized
INFO - 2018-04-12 17:15:25 --> Output Class Initialized
INFO - 2018-04-12 17:15:25 --> Security Class Initialized
DEBUG - 2018-04-12 17:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:15:25 --> Input Class Initialized
INFO - 2018-04-12 17:15:25 --> Language Class Initialized
INFO - 2018-04-12 17:15:25 --> Language Class Initialized
INFO - 2018-04-12 17:15:25 --> Config Class Initialized
INFO - 2018-04-12 17:15:25 --> Loader Class Initialized
INFO - 2018-04-12 22:45:25 --> Helper loaded: url_helper
INFO - 2018-04-12 22:45:25 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:45:25 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:45:25 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:45:25 --> Helper loaded: users_helper
INFO - 2018-04-12 22:45:25 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:45:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:45:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:45:25 --> Helper loaded: form_helper
INFO - 2018-04-12 22:45:25 --> Form Validation Class Initialized
INFO - 2018-04-12 22:45:25 --> Controller Class Initialized
INFO - 2018-04-12 22:45:25 --> Model Class Initialized
INFO - 2018-04-12 22:45:25 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:45:25 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:45:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:45:25 --> Model Class Initialized
INFO - 2018-04-12 22:45:25 --> Model Class Initialized
INFO - 2018-04-12 22:45:25 --> Model Class Initialized
INFO - 2018-04-12 22:45:25 --> Model Class Initialized
INFO - 2018-04-12 22:45:25 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-12 22:45:25 --> Final output sent to browser
DEBUG - 2018-04-12 22:45:25 --> Total execution time: 0.0921
INFO - 2018-04-12 17:15:27 --> Config Class Initialized
INFO - 2018-04-12 17:15:27 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:15:27 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:15:27 --> Utf8 Class Initialized
INFO - 2018-04-12 17:15:27 --> URI Class Initialized
INFO - 2018-04-12 17:15:27 --> Config Class Initialized
INFO - 2018-04-12 17:15:27 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:15:27 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:15:27 --> Utf8 Class Initialized
INFO - 2018-04-12 17:15:27 --> Router Class Initialized
INFO - 2018-04-12 17:15:27 --> URI Class Initialized
INFO - 2018-04-12 17:15:27 --> Output Class Initialized
INFO - 2018-04-12 17:15:27 --> Router Class Initialized
INFO - 2018-04-12 17:15:27 --> Security Class Initialized
DEBUG - 2018-04-12 17:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:15:27 --> Input Class Initialized
INFO - 2018-04-12 17:15:27 --> Output Class Initialized
INFO - 2018-04-12 17:15:27 --> Language Class Initialized
INFO - 2018-04-12 17:15:27 --> Security Class Initialized
DEBUG - 2018-04-12 17:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:15:27 --> Input Class Initialized
INFO - 2018-04-12 17:15:27 --> Language Class Initialized
INFO - 2018-04-12 17:15:27 --> Language Class Initialized
INFO - 2018-04-12 17:15:27 --> Config Class Initialized
INFO - 2018-04-12 17:15:27 --> Loader Class Initialized
INFO - 2018-04-12 22:45:27 --> Helper loaded: url_helper
INFO - 2018-04-12 22:45:27 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:45:27 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:45:27 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:45:27 --> Helper loaded: users_helper
INFO - 2018-04-12 17:15:27 --> Language Class Initialized
INFO - 2018-04-12 17:15:27 --> Config Class Initialized
INFO - 2018-04-12 17:15:27 --> Loader Class Initialized
INFO - 2018-04-12 22:45:27 --> Helper loaded: url_helper
INFO - 2018-04-12 22:45:27 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:45:27 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:45:27 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:45:27 --> Helper loaded: users_helper
INFO - 2018-04-12 22:45:27 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:45:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:45:27 --> Database Driver Class Initialized
INFO - 2018-04-12 22:45:27 --> Helper loaded: form_helper
INFO - 2018-04-12 22:45:27 --> Form Validation Class Initialized
INFO - 2018-04-12 22:45:27 --> Controller Class Initialized
DEBUG - 2018-04-12 22:45:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:45:27 --> Model Class Initialized
INFO - 2018-04-12 22:45:27 --> Helper loaded: inflector_helper
INFO - 2018-04-12 22:45:27 --> Helper loaded: form_helper
INFO - 2018-04-12 22:45:27 --> Form Validation Class Initialized
INFO - 2018-04-12 22:45:27 --> Controller Class Initialized
DEBUG - 2018-04-12 22:45:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:45:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:45:27 --> Model Class Initialized
INFO - 2018-04-12 22:45:27 --> Model Class Initialized
INFO - 2018-04-12 22:45:27 --> Model Class Initialized
INFO - 2018-04-12 22:45:27 --> Model Class Initialized
INFO - 2018-04-12 22:45:27 --> Model Class Initialized
INFO - 2018-04-12 22:45:27 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-12 22:45:27 --> Model Class Initialized
INFO - 2018-04-12 22:45:27 --> Model Class Initialized
INFO - 2018-04-12 22:45:27 --> Helper loaded: inflector_helper
INFO - 2018-04-12 22:45:27 --> Final output sent to browser
DEBUG - 2018-04-12 22:45:27 --> Total execution time: 0.1092
DEBUG - 2018-04-12 22:45:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:45:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:45:27 --> Model Class Initialized
INFO - 2018-04-12 22:45:27 --> Model Class Initialized
INFO - 2018-04-12 22:45:27 --> Model Class Initialized
INFO - 2018-04-12 22:45:27 --> Model Class Initialized
INFO - 2018-04-12 22:45:27 --> Model Class Initialized
INFO - 2018-04-12 22:45:27 --> Model Class Initialized
INFO - 2018-04-12 22:45:27 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-04-12 22:45:27 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-04-12 22:45:27 --> Final output sent to browser
DEBUG - 2018-04-12 22:45:27 --> Total execution time: 0.1139
INFO - 2018-04-12 17:15:47 --> Config Class Initialized
INFO - 2018-04-12 17:15:47 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:15:47 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:15:47 --> Utf8 Class Initialized
INFO - 2018-04-12 17:15:47 --> URI Class Initialized
INFO - 2018-04-12 17:15:47 --> Router Class Initialized
INFO - 2018-04-12 17:15:47 --> Output Class Initialized
INFO - 2018-04-12 17:15:47 --> Security Class Initialized
DEBUG - 2018-04-12 17:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:15:47 --> Input Class Initialized
INFO - 2018-04-12 17:15:47 --> Language Class Initialized
INFO - 2018-04-12 17:15:47 --> Config Class Initialized
INFO - 2018-04-12 17:15:47 --> Config Class Initialized
INFO - 2018-04-12 17:15:47 --> Hooks Class Initialized
INFO - 2018-04-12 17:15:47 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:15:47 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:15:47 --> Utf8 Class Initialized
DEBUG - 2018-04-12 17:15:47 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:15:47 --> Utf8 Class Initialized
INFO - 2018-04-12 17:15:47 --> URI Class Initialized
INFO - 2018-04-12 17:15:47 --> URI Class Initialized
INFO - 2018-04-12 17:15:47 --> Language Class Initialized
INFO - 2018-04-12 17:15:47 --> Config Class Initialized
INFO - 2018-04-12 17:15:47 --> Loader Class Initialized
INFO - 2018-04-12 17:15:47 --> Router Class Initialized
INFO - 2018-04-12 22:45:47 --> Helper loaded: url_helper
INFO - 2018-04-12 17:15:47 --> Router Class Initialized
INFO - 2018-04-12 22:45:47 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:45:47 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:45:47 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:45:47 --> Helper loaded: users_helper
INFO - 2018-04-12 17:15:47 --> Output Class Initialized
INFO - 2018-04-12 17:15:47 --> Output Class Initialized
INFO - 2018-04-12 17:15:47 --> Security Class Initialized
INFO - 2018-04-12 17:15:47 --> Security Class Initialized
DEBUG - 2018-04-12 17:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:15:47 --> Input Class Initialized
DEBUG - 2018-04-12 17:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:15:47 --> Input Class Initialized
INFO - 2018-04-12 22:45:47 --> Database Driver Class Initialized
INFO - 2018-04-12 17:15:47 --> Language Class Initialized
INFO - 2018-04-12 17:15:47 --> Language Class Initialized
DEBUG - 2018-04-12 22:45:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:45:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:45:47 --> Helper loaded: form_helper
INFO - 2018-04-12 22:45:47 --> Form Validation Class Initialized
INFO - 2018-04-12 22:45:47 --> Controller Class Initialized
INFO - 2018-04-12 22:45:47 --> Model Class Initialized
INFO - 2018-04-12 22:45:47 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:45:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:45:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:45:47 --> Model Class Initialized
INFO - 2018-04-12 22:45:47 --> Model Class Initialized
INFO - 2018-04-12 22:45:47 --> Model Class Initialized
INFO - 2018-04-12 22:45:47 --> Model Class Initialized
INFO - 2018-04-12 22:45:47 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-12 22:45:47 --> Final output sent to browser
DEBUG - 2018-04-12 22:45:47 --> Total execution time: 0.1052
INFO - 2018-04-12 17:15:47 --> Language Class Initialized
INFO - 2018-04-12 17:15:47 --> Config Class Initialized
INFO - 2018-04-12 17:15:47 --> Loader Class Initialized
INFO - 2018-04-12 17:15:47 --> Language Class Initialized
INFO - 2018-04-12 17:15:47 --> Config Class Initialized
INFO - 2018-04-12 17:15:47 --> Loader Class Initialized
INFO - 2018-04-12 22:45:47 --> Helper loaded: url_helper
INFO - 2018-04-12 22:45:47 --> Helper loaded: url_helper
INFO - 2018-04-12 22:45:47 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:45:47 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:45:47 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:45:47 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:45:47 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:45:47 --> Helper loaded: users_helper
INFO - 2018-04-12 22:45:47 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:45:47 --> Helper loaded: users_helper
INFO - 2018-04-12 22:45:47 --> Database Driver Class Initialized
INFO - 2018-04-12 22:45:47 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:45:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:45:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-04-12 22:45:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:45:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:45:47 --> Helper loaded: form_helper
INFO - 2018-04-12 22:45:47 --> Form Validation Class Initialized
INFO - 2018-04-12 22:45:47 --> Controller Class Initialized
INFO - 2018-04-12 22:45:47 --> Helper loaded: form_helper
INFO - 2018-04-12 22:45:47 --> Form Validation Class Initialized
INFO - 2018-04-12 22:45:47 --> Controller Class Initialized
INFO - 2018-04-12 22:45:47 --> Model Class Initialized
INFO - 2018-04-12 22:45:47 --> Helper loaded: inflector_helper
INFO - 2018-04-12 22:45:47 --> Model Class Initialized
INFO - 2018-04-12 22:45:47 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:45:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:45:47 --> Language file loaded: language/english/rest_controller_lang.php
DEBUG - 2018-04-12 22:45:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:45:47 --> Model Class Initialized
INFO - 2018-04-12 22:45:47 --> Model Class Initialized
INFO - 2018-04-12 22:45:47 --> Model Class Initialized
INFO - 2018-04-12 22:45:47 --> Model Class Initialized
INFO - 2018-04-12 22:45:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:45:47 --> Model Class Initialized
INFO - 2018-04-12 22:45:47 --> Model Class Initialized
INFO - 2018-04-12 22:45:47 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-04-12 22:45:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-04-12 22:45:47 --> Final output sent to browser
DEBUG - 2018-04-12 22:45:47 --> Total execution time: 0.1553
INFO - 2018-04-12 22:45:47 --> Model Class Initialized
INFO - 2018-04-12 22:45:47 --> Model Class Initialized
INFO - 2018-04-12 22:45:47 --> Model Class Initialized
INFO - 2018-04-12 22:45:47 --> Model Class Initialized
INFO - 2018-04-12 22:45:47 --> Model Class Initialized
INFO - 2018-04-12 22:45:47 --> Model Class Initialized
INFO - 2018-04-12 22:45:47 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-04-12 22:45:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-04-12 22:45:47 --> Final output sent to browser
DEBUG - 2018-04-12 22:45:47 --> Total execution time: 0.1644
INFO - 2018-04-12 17:15:49 --> Config Class Initialized
INFO - 2018-04-12 17:15:49 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:15:49 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:15:49 --> Utf8 Class Initialized
INFO - 2018-04-12 17:15:49 --> URI Class Initialized
INFO - 2018-04-12 17:15:49 --> Router Class Initialized
INFO - 2018-04-12 17:15:49 --> Config Class Initialized
INFO - 2018-04-12 17:15:49 --> Hooks Class Initialized
INFO - 2018-04-12 17:15:49 --> Output Class Initialized
DEBUG - 2018-04-12 17:15:49 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:15:49 --> Utf8 Class Initialized
INFO - 2018-04-12 17:15:49 --> Security Class Initialized
INFO - 2018-04-12 17:15:49 --> URI Class Initialized
DEBUG - 2018-04-12 17:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:15:49 --> Input Class Initialized
INFO - 2018-04-12 17:15:49 --> Language Class Initialized
INFO - 2018-04-12 17:15:49 --> Router Class Initialized
INFO - 2018-04-12 17:15:49 --> Output Class Initialized
INFO - 2018-04-12 17:15:49 --> Security Class Initialized
DEBUG - 2018-04-12 17:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:15:49 --> Input Class Initialized
INFO - 2018-04-12 17:15:49 --> Language Class Initialized
INFO - 2018-04-12 17:15:49 --> Language Class Initialized
INFO - 2018-04-12 17:15:49 --> Config Class Initialized
INFO - 2018-04-12 17:15:49 --> Loader Class Initialized
INFO - 2018-04-12 22:45:49 --> Helper loaded: url_helper
INFO - 2018-04-12 22:45:49 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:45:49 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:45:49 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:45:49 --> Helper loaded: users_helper
INFO - 2018-04-12 17:15:49 --> Language Class Initialized
INFO - 2018-04-12 17:15:49 --> Config Class Initialized
INFO - 2018-04-12 17:15:49 --> Loader Class Initialized
INFO - 2018-04-12 22:45:49 --> Database Driver Class Initialized
INFO - 2018-04-12 22:45:49 --> Helper loaded: url_helper
INFO - 2018-04-12 22:45:49 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:45:49 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:45:49 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:45:49 --> Helper loaded: users_helper
DEBUG - 2018-04-12 22:45:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:45:49 --> Helper loaded: form_helper
INFO - 2018-04-12 22:45:49 --> Form Validation Class Initialized
INFO - 2018-04-12 22:45:49 --> Controller Class Initialized
INFO - 2018-04-12 22:45:49 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:45:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:45:49 --> Model Class Initialized
INFO - 2018-04-12 22:45:49 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:45:49 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:45:49 --> Helper loaded: form_helper
INFO - 2018-04-12 22:45:49 --> Form Validation Class Initialized
INFO - 2018-04-12 22:45:49 --> Controller Class Initialized
INFO - 2018-04-12 22:45:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:45:49 --> Model Class Initialized
INFO - 2018-04-12 22:45:49 --> Model Class Initialized
INFO - 2018-04-12 22:45:49 --> Model Class Initialized
INFO - 2018-04-12 22:45:49 --> Model Class Initialized
INFO - 2018-04-12 22:45:49 --> Model Class Initialized
INFO - 2018-04-12 22:45:49 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-12 22:45:49 --> Model Class Initialized
INFO - 2018-04-12 22:45:49 --> Model Class Initialized
INFO - 2018-04-12 22:45:49 --> Helper loaded: inflector_helper
INFO - 2018-04-12 22:45:49 --> Final output sent to browser
DEBUG - 2018-04-12 22:45:49 --> Total execution time: 0.1164
DEBUG - 2018-04-12 22:45:49 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:45:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:45:49 --> Model Class Initialized
INFO - 2018-04-12 22:45:49 --> Model Class Initialized
INFO - 2018-04-12 22:45:49 --> Model Class Initialized
INFO - 2018-04-12 22:45:49 --> Model Class Initialized
INFO - 2018-04-12 22:45:49 --> Model Class Initialized
INFO - 2018-04-12 22:45:49 --> Model Class Initialized
INFO - 2018-04-12 22:45:49 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-04-12 22:45:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-04-12 22:45:49 --> Final output sent to browser
DEBUG - 2018-04-12 22:45:49 --> Total execution time: 0.1148
INFO - 2018-04-12 17:15:51 --> Config Class Initialized
INFO - 2018-04-12 17:15:51 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:15:51 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:15:51 --> Utf8 Class Initialized
INFO - 2018-04-12 17:15:51 --> URI Class Initialized
INFO - 2018-04-12 17:15:51 --> Router Class Initialized
INFO - 2018-04-12 17:15:51 --> Output Class Initialized
INFO - 2018-04-12 17:15:51 --> Security Class Initialized
DEBUG - 2018-04-12 17:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:15:51 --> Input Class Initialized
INFO - 2018-04-12 17:15:51 --> Language Class Initialized
INFO - 2018-04-12 17:15:51 --> Language Class Initialized
INFO - 2018-04-12 17:15:51 --> Config Class Initialized
INFO - 2018-04-12 17:15:51 --> Loader Class Initialized
INFO - 2018-04-12 22:45:51 --> Helper loaded: url_helper
INFO - 2018-04-12 22:45:51 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:45:51 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:45:51 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:45:51 --> Helper loaded: users_helper
INFO - 2018-04-12 22:45:51 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:45:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:45:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:45:51 --> Helper loaded: form_helper
INFO - 2018-04-12 22:45:51 --> Form Validation Class Initialized
INFO - 2018-04-12 22:45:51 --> Controller Class Initialized
INFO - 2018-04-12 22:45:51 --> Model Class Initialized
INFO - 2018-04-12 22:45:51 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:45:51 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:45:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:45:51 --> Model Class Initialized
INFO - 2018-04-12 22:45:51 --> Model Class Initialized
INFO - 2018-04-12 22:45:51 --> Model Class Initialized
INFO - 2018-04-12 22:45:51 --> Model Class Initialized
INFO - 2018-04-12 22:45:51 --> Model Class Initialized
INFO - 2018-04-12 22:45:51 --> Model Class Initialized
INFO - 2018-04-12 22:45:51 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-04-12 22:45:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-04-12 22:45:51 --> Final output sent to browser
DEBUG - 2018-04-12 22:45:51 --> Total execution time: 0.1018
INFO - 2018-04-12 17:18:24 --> Config Class Initialized
INFO - 2018-04-12 17:18:24 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:18:24 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:18:24 --> Utf8 Class Initialized
INFO - 2018-04-12 17:18:24 --> URI Class Initialized
INFO - 2018-04-12 17:18:24 --> Router Class Initialized
INFO - 2018-04-12 17:18:24 --> Output Class Initialized
INFO - 2018-04-12 17:18:24 --> Security Class Initialized
DEBUG - 2018-04-12 17:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:18:24 --> Input Class Initialized
INFO - 2018-04-12 17:18:24 --> Language Class Initialized
INFO - 2018-04-12 17:18:24 --> Language Class Initialized
INFO - 2018-04-12 17:18:24 --> Config Class Initialized
INFO - 2018-04-12 17:18:24 --> Loader Class Initialized
INFO - 2018-04-12 22:48:24 --> Helper loaded: url_helper
INFO - 2018-04-12 22:48:24 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:48:24 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:48:24 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:48:24 --> Helper loaded: users_helper
INFO - 2018-04-12 22:48:24 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:48:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:48:24 --> Helper loaded: form_helper
INFO - 2018-04-12 22:48:24 --> Form Validation Class Initialized
INFO - 2018-04-12 22:48:24 --> Controller Class Initialized
INFO - 2018-04-12 22:48:24 --> Model Class Initialized
INFO - 2018-04-12 22:48:24 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:48:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:48:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:48:24 --> Model Class Initialized
INFO - 2018-04-12 22:48:24 --> Model Class Initialized
INFO - 2018-04-12 22:48:24 --> Model Class Initialized
INFO - 2018-04-12 22:48:24 --> Model Class Initialized
INFO - 2018-04-12 22:48:24 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-12 22:48:24 --> Final output sent to browser
DEBUG - 2018-04-12 22:48:24 --> Total execution time: 0.1072
INFO - 2018-04-12 17:18:24 --> Config Class Initialized
INFO - 2018-04-12 17:18:24 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:18:24 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:18:24 --> Utf8 Class Initialized
INFO - 2018-04-12 17:18:24 --> URI Class Initialized
INFO - 2018-04-12 17:18:24 --> Router Class Initialized
INFO - 2018-04-12 17:18:24 --> Output Class Initialized
INFO - 2018-04-12 17:18:24 --> Security Class Initialized
INFO - 2018-04-12 17:18:24 --> Config Class Initialized
INFO - 2018-04-12 17:18:24 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:18:24 --> Input Class Initialized
INFO - 2018-04-12 17:18:24 --> Language Class Initialized
DEBUG - 2018-04-12 17:18:24 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:18:24 --> Utf8 Class Initialized
INFO - 2018-04-12 17:18:24 --> URI Class Initialized
INFO - 2018-04-12 17:18:24 --> Router Class Initialized
INFO - 2018-04-12 17:18:24 --> Output Class Initialized
INFO - 2018-04-12 17:18:24 --> Security Class Initialized
DEBUG - 2018-04-12 17:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:18:24 --> Input Class Initialized
INFO - 2018-04-12 17:18:24 --> Language Class Initialized
INFO - 2018-04-12 17:18:24 --> Language Class Initialized
INFO - 2018-04-12 17:18:24 --> Config Class Initialized
INFO - 2018-04-12 17:18:24 --> Loader Class Initialized
INFO - 2018-04-12 22:48:24 --> Helper loaded: url_helper
INFO - 2018-04-12 22:48:24 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:48:24 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:48:24 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:48:24 --> Helper loaded: users_helper
INFO - 2018-04-12 17:18:24 --> Language Class Initialized
INFO - 2018-04-12 17:18:24 --> Config Class Initialized
INFO - 2018-04-12 17:18:24 --> Loader Class Initialized
INFO - 2018-04-12 22:48:24 --> Helper loaded: url_helper
INFO - 2018-04-12 22:48:24 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:48:24 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:48:24 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:48:24 --> Helper loaded: users_helper
INFO - 2018-04-12 22:48:24 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:48:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:48:24 --> Database Driver Class Initialized
INFO - 2018-04-12 22:48:24 --> Helper loaded: form_helper
INFO - 2018-04-12 22:48:24 --> Form Validation Class Initialized
INFO - 2018-04-12 22:48:24 --> Controller Class Initialized
DEBUG - 2018-04-12 22:48:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:48:24 --> Model Class Initialized
INFO - 2018-04-12 22:48:24 --> Helper loaded: inflector_helper
INFO - 2018-04-12 22:48:24 --> Helper loaded: form_helper
INFO - 2018-04-12 22:48:24 --> Form Validation Class Initialized
INFO - 2018-04-12 22:48:24 --> Controller Class Initialized
DEBUG - 2018-04-12 22:48:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:48:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:48:24 --> Model Class Initialized
INFO - 2018-04-12 22:48:24 --> Model Class Initialized
INFO - 2018-04-12 22:48:24 --> Model Class Initialized
INFO - 2018-04-12 22:48:24 --> Model Class Initialized
INFO - 2018-04-12 22:48:24 --> Model Class Initialized
INFO - 2018-04-12 22:48:24 --> Model Class Initialized
INFO - 2018-04-12 22:48:24 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-04-12 22:48:24 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-04-12 22:48:24 --> Model Class Initialized
INFO - 2018-04-12 22:48:24 --> Final output sent to browser
DEBUG - 2018-04-12 22:48:24 --> Total execution time: 0.1167
INFO - 2018-04-12 22:48:24 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:48:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:48:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:48:24 --> Model Class Initialized
INFO - 2018-04-12 22:48:24 --> Model Class Initialized
INFO - 2018-04-12 22:48:24 --> Model Class Initialized
INFO - 2018-04-12 22:48:24 --> Model Class Initialized
INFO - 2018-04-12 22:48:24 --> Model Class Initialized
INFO - 2018-04-12 22:48:24 --> Model Class Initialized
INFO - 2018-04-12 22:48:24 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-04-12 22:48:24 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-04-12 22:48:24 --> Final output sent to browser
DEBUG - 2018-04-12 22:48:24 --> Total execution time: 0.1096
INFO - 2018-04-12 17:18:26 --> Config Class Initialized
INFO - 2018-04-12 17:18:26 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:18:26 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:18:26 --> Utf8 Class Initialized
INFO - 2018-04-12 17:18:26 --> URI Class Initialized
INFO - 2018-04-12 17:18:26 --> Router Class Initialized
INFO - 2018-04-12 17:18:26 --> Output Class Initialized
INFO - 2018-04-12 17:18:26 --> Security Class Initialized
DEBUG - 2018-04-12 17:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:18:26 --> Input Class Initialized
INFO - 2018-04-12 17:18:26 --> Language Class Initialized
INFO - 2018-04-12 17:18:26 --> Language Class Initialized
INFO - 2018-04-12 17:18:26 --> Config Class Initialized
INFO - 2018-04-12 17:18:26 --> Loader Class Initialized
INFO - 2018-04-12 22:48:26 --> Helper loaded: url_helper
INFO - 2018-04-12 22:48:26 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:48:26 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:48:26 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:48:26 --> Helper loaded: users_helper
INFO - 2018-04-12 17:18:26 --> Config Class Initialized
INFO - 2018-04-12 17:18:26 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:18:26 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:18:26 --> Utf8 Class Initialized
INFO - 2018-04-12 17:18:26 --> URI Class Initialized
INFO - 2018-04-12 17:18:26 --> Router Class Initialized
INFO - 2018-04-12 17:18:26 --> Output Class Initialized
INFO - 2018-04-12 22:48:26 --> Database Driver Class Initialized
INFO - 2018-04-12 17:18:26 --> Security Class Initialized
DEBUG - 2018-04-12 17:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:18:26 --> Input Class Initialized
INFO - 2018-04-12 17:18:26 --> Language Class Initialized
DEBUG - 2018-04-12 22:48:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:48:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 17:18:26 --> Language Class Initialized
INFO - 2018-04-12 17:18:26 --> Config Class Initialized
INFO - 2018-04-12 17:18:26 --> Loader Class Initialized
INFO - 2018-04-12 22:48:26 --> Helper loaded: url_helper
INFO - 2018-04-12 22:48:26 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:48:26 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:48:26 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:48:26 --> Helper loaded: users_helper
INFO - 2018-04-12 22:48:26 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:48:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:48:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:48:26 --> Helper loaded: form_helper
INFO - 2018-04-12 22:48:26 --> Form Validation Class Initialized
INFO - 2018-04-12 22:48:26 --> Controller Class Initialized
INFO - 2018-04-12 22:48:26 --> Helper loaded: form_helper
INFO - 2018-04-12 22:48:26 --> Form Validation Class Initialized
INFO - 2018-04-12 22:48:26 --> Controller Class Initialized
INFO - 2018-04-12 22:48:26 --> Model Class Initialized
INFO - 2018-04-12 22:48:26 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:48:26 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:48:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:48:26 --> Model Class Initialized
INFO - 2018-04-12 22:48:26 --> Model Class Initialized
INFO - 2018-04-12 22:48:26 --> Model Class Initialized
INFO - 2018-04-12 22:48:26 --> Model Class Initialized
INFO - 2018-04-12 22:48:26 --> Model Class Initialized
INFO - 2018-04-12 22:48:26 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-12 22:48:26 --> Model Class Initialized
INFO - 2018-04-12 22:48:26 --> Final output sent to browser
DEBUG - 2018-04-12 22:48:26 --> Total execution time: 0.1039
INFO - 2018-04-12 22:48:26 --> Model Class Initialized
INFO - 2018-04-12 22:48:26 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:48:26 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:48:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:48:26 --> Model Class Initialized
INFO - 2018-04-12 22:48:26 --> Model Class Initialized
INFO - 2018-04-12 22:48:26 --> Model Class Initialized
INFO - 2018-04-12 22:48:26 --> Model Class Initialized
INFO - 2018-04-12 22:48:26 --> Model Class Initialized
INFO - 2018-04-12 22:48:26 --> Model Class Initialized
INFO - 2018-04-12 22:48:26 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-04-12 22:48:26 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-04-12 22:48:26 --> Final output sent to browser
DEBUG - 2018-04-12 22:48:26 --> Total execution time: 0.1998
INFO - 2018-04-12 17:18:35 --> Config Class Initialized
INFO - 2018-04-12 17:18:35 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:18:35 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:18:35 --> Utf8 Class Initialized
INFO - 2018-04-12 17:18:35 --> URI Class Initialized
INFO - 2018-04-12 17:18:35 --> Config Class Initialized
INFO - 2018-04-12 17:18:35 --> Hooks Class Initialized
INFO - 2018-04-12 17:18:35 --> Router Class Initialized
DEBUG - 2018-04-12 17:18:35 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:18:35 --> Utf8 Class Initialized
INFO - 2018-04-12 17:18:35 --> Output Class Initialized
INFO - 2018-04-12 17:18:35 --> URI Class Initialized
INFO - 2018-04-12 17:18:35 --> Security Class Initialized
INFO - 2018-04-12 17:18:35 --> Config Class Initialized
INFO - 2018-04-12 17:18:35 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:18:35 --> Input Class Initialized
INFO - 2018-04-12 17:18:35 --> Router Class Initialized
INFO - 2018-04-12 17:18:35 --> Language Class Initialized
DEBUG - 2018-04-12 17:18:35 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:18:35 --> Utf8 Class Initialized
INFO - 2018-04-12 17:18:35 --> Output Class Initialized
INFO - 2018-04-12 17:18:35 --> URI Class Initialized
INFO - 2018-04-12 17:18:35 --> Security Class Initialized
INFO - 2018-04-12 17:18:35 --> Router Class Initialized
DEBUG - 2018-04-12 17:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:18:35 --> Input Class Initialized
INFO - 2018-04-12 17:18:35 --> Language Class Initialized
INFO - 2018-04-12 17:18:35 --> Output Class Initialized
INFO - 2018-04-12 17:18:35 --> Security Class Initialized
INFO - 2018-04-12 17:18:35 --> Language Class Initialized
INFO - 2018-04-12 17:18:35 --> Config Class Initialized
INFO - 2018-04-12 17:18:35 --> Loader Class Initialized
DEBUG - 2018-04-12 17:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 22:48:35 --> Helper loaded: url_helper
INFO - 2018-04-12 17:18:35 --> Input Class Initialized
INFO - 2018-04-12 22:48:35 --> Helper loaded: notification_helper
INFO - 2018-04-12 17:18:35 --> Language Class Initialized
INFO - 2018-04-12 22:48:35 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:48:35 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:48:35 --> Helper loaded: users_helper
INFO - 2018-04-12 17:18:35 --> Language Class Initialized
INFO - 2018-04-12 17:18:35 --> Config Class Initialized
INFO - 2018-04-12 17:18:35 --> Loader Class Initialized
INFO - 2018-04-12 22:48:35 --> Database Driver Class Initialized
INFO - 2018-04-12 22:48:35 --> Helper loaded: url_helper
INFO - 2018-04-12 22:48:35 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:48:35 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:48:35 --> Helper loaded: permission_helper
DEBUG - 2018-04-12 22:48:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:48:35 --> Helper loaded: users_helper
INFO - 2018-04-12 22:48:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 17:18:35 --> Language Class Initialized
INFO - 2018-04-12 17:18:35 --> Config Class Initialized
INFO - 2018-04-12 17:18:35 --> Loader Class Initialized
INFO - 2018-04-12 22:48:35 --> Helper loaded: url_helper
INFO - 2018-04-12 22:48:35 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:48:35 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:48:35 --> Helper loaded: form_helper
INFO - 2018-04-12 22:48:35 --> Form Validation Class Initialized
INFO - 2018-04-12 22:48:35 --> Controller Class Initialized
INFO - 2018-04-12 22:48:35 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:48:35 --> Helper loaded: users_helper
INFO - 2018-04-12 22:48:35 --> Database Driver Class Initialized
INFO - 2018-04-12 22:48:35 --> Model Class Initialized
INFO - 2018-04-12 22:48:35 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:48:35 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:48:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:48:35 --> Model Class Initialized
DEBUG - 2018-04-12 22:48:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:48:35 --> Model Class Initialized
INFO - 2018-04-12 22:48:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:48:35 --> Database Driver Class Initialized
INFO - 2018-04-12 22:48:35 --> Model Class Initialized
INFO - 2018-04-12 22:48:35 --> Model Class Initialized
INFO - 2018-04-12 22:48:35 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-12 22:48:35 --> Final output sent to browser
DEBUG - 2018-04-12 22:48:35 --> Total execution time: 0.0951
DEBUG - 2018-04-12 22:48:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:48:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:48:35 --> Helper loaded: form_helper
INFO - 2018-04-12 22:48:35 --> Form Validation Class Initialized
INFO - 2018-04-12 22:48:35 --> Controller Class Initialized
INFO - 2018-04-12 22:48:35 --> Helper loaded: form_helper
INFO - 2018-04-12 22:48:35 --> Form Validation Class Initialized
INFO - 2018-04-12 22:48:35 --> Controller Class Initialized
INFO - 2018-04-12 22:48:35 --> Model Class Initialized
INFO - 2018-04-12 22:48:35 --> Helper loaded: inflector_helper
INFO - 2018-04-12 22:48:35 --> Model Class Initialized
DEBUG - 2018-04-12 22:48:35 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:48:35 --> Helper loaded: inflector_helper
INFO - 2018-04-12 22:48:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:48:35 --> Model Class Initialized
INFO - 2018-04-12 22:48:35 --> Model Class Initialized
DEBUG - 2018-04-12 22:48:35 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:48:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:48:35 --> Model Class Initialized
INFO - 2018-04-12 22:48:35 --> Model Class Initialized
INFO - 2018-04-12 22:48:35 --> Model Class Initialized
INFO - 2018-04-12 22:48:35 --> Model Class Initialized
INFO - 2018-04-12 22:48:35 --> Model Class Initialized
INFO - 2018-04-12 22:48:35 --> Model Class Initialized
INFO - 2018-04-12 22:48:35 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-12 22:48:35 --> Model Class Initialized
INFO - 2018-04-12 22:48:35 --> Model Class Initialized
INFO - 2018-04-12 22:48:35 --> Model Class Initialized
INFO - 2018-04-12 22:48:35 --> Model Class Initialized
INFO - 2018-04-12 22:48:35 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-04-12 22:48:35 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-04-12 22:48:35 --> Final output sent to browser
DEBUG - 2018-04-12 22:48:35 --> Total execution time: 0.1234
ERROR - 2018-04-12 22:48:35 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-04-12 22:48:35 --> Final output sent to browser
DEBUG - 2018-04-12 22:48:35 --> Total execution time: 0.1157
INFO - 2018-04-12 17:18:41 --> Config Class Initialized
INFO - 2018-04-12 17:18:41 --> Hooks Class Initialized
DEBUG - 2018-04-12 17:18:41 --> UTF-8 Support Enabled
INFO - 2018-04-12 17:18:41 --> Utf8 Class Initialized
INFO - 2018-04-12 17:18:41 --> URI Class Initialized
INFO - 2018-04-12 17:18:41 --> Router Class Initialized
INFO - 2018-04-12 17:18:41 --> Output Class Initialized
INFO - 2018-04-12 17:18:41 --> Security Class Initialized
DEBUG - 2018-04-12 17:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 17:18:41 --> Input Class Initialized
INFO - 2018-04-12 17:18:41 --> Language Class Initialized
INFO - 2018-04-12 17:18:41 --> Language Class Initialized
INFO - 2018-04-12 17:18:41 --> Config Class Initialized
INFO - 2018-04-12 17:18:41 --> Loader Class Initialized
INFO - 2018-04-12 22:48:41 --> Helper loaded: url_helper
INFO - 2018-04-12 22:48:41 --> Helper loaded: notification_helper
INFO - 2018-04-12 22:48:41 --> Helper loaded: settings_helper
INFO - 2018-04-12 22:48:41 --> Helper loaded: permission_helper
INFO - 2018-04-12 22:48:41 --> Helper loaded: users_helper
INFO - 2018-04-12 22:48:41 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:48:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:48:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:48:42 --> Helper loaded: form_helper
INFO - 2018-04-12 22:48:42 --> Form Validation Class Initialized
INFO - 2018-04-12 22:48:42 --> Controller Class Initialized
INFO - 2018-04-12 22:48:42 --> Model Class Initialized
INFO - 2018-04-12 22:48:42 --> Helper loaded: inflector_helper
DEBUG - 2018-04-12 22:48:42 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-12 22:48:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-12 22:48:42 --> Model Class Initialized
INFO - 2018-04-12 22:48:42 --> Model Class Initialized
INFO - 2018-04-12 22:48:42 --> Model Class Initialized
INFO - 2018-04-12 22:48:42 --> Model Class Initialized
INFO - 2018-04-12 22:48:42 --> Model Class Initialized
INFO - 2018-04-12 22:48:42 --> Model Class Initialized
INFO - 2018-04-12 22:48:42 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-12 22:48:42 --> Final output sent to browser
DEBUG - 2018-04-12 22:48:42 --> Total execution time: 0.1244
