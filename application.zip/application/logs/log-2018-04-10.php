<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-04-10 05:28:51 --> Config Class Initialized
INFO - 2018-04-10 05:28:51 --> Hooks Class Initialized
DEBUG - 2018-04-10 05:28:51 --> UTF-8 Support Enabled
INFO - 2018-04-10 05:28:51 --> Utf8 Class Initialized
INFO - 2018-04-10 05:28:51 --> URI Class Initialized
INFO - 2018-04-10 05:28:51 --> Router Class Initialized
INFO - 2018-04-10 05:28:51 --> Output Class Initialized
INFO - 2018-04-10 05:28:51 --> Security Class Initialized
DEBUG - 2018-04-10 05:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 05:28:51 --> Input Class Initialized
INFO - 2018-04-10 05:28:51 --> Language Class Initialized
INFO - 2018-04-10 05:28:51 --> Language Class Initialized
INFO - 2018-04-10 05:28:51 --> Config Class Initialized
INFO - 2018-04-10 05:28:51 --> Loader Class Initialized
INFO - 2018-04-10 10:58:51 --> Helper loaded: url_helper
INFO - 2018-04-10 10:58:51 --> Helper loaded: notification_helper
INFO - 2018-04-10 10:58:51 --> Helper loaded: settings_helper
INFO - 2018-04-10 10:58:51 --> Helper loaded: permission_helper
INFO - 2018-04-10 10:58:51 --> Helper loaded: users_helper
INFO - 2018-04-10 10:58:51 --> Database Driver Class Initialized
DEBUG - 2018-04-10 10:58:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 10:58:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 10:58:51 --> Helper loaded: form_helper
INFO - 2018-04-10 10:58:51 --> Form Validation Class Initialized
INFO - 2018-04-10 10:58:51 --> Controller Class Initialized
INFO - 2018-04-10 10:58:51 --> Model Class Initialized
INFO - 2018-04-10 10:58:51 --> Helper loaded: inflector_helper
DEBUG - 2018-04-10 10:58:51 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-10 10:58:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-10 10:58:51 --> Model Class Initialized
INFO - 2018-04-10 10:58:51 --> Model Class Initialized
INFO - 2018-04-10 10:58:51 --> Model Class Initialized
INFO - 2018-04-10 10:58:51 --> Model Class Initialized
INFO - 2018-04-10 10:58:51 --> Model Class Initialized
INFO - 2018-04-10 10:58:51 --> Model Class Initialized
INFO - 2018-04-10 10:58:51 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-10 10:58:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-10 10:58:51 --> Final output sent to browser
DEBUG - 2018-04-10 10:58:51 --> Total execution time: 0.1058
INFO - 2018-04-10 05:28:52 --> Config Class Initialized
INFO - 2018-04-10 05:28:52 --> Hooks Class Initialized
DEBUG - 2018-04-10 05:28:52 --> UTF-8 Support Enabled
INFO - 2018-04-10 05:28:52 --> Utf8 Class Initialized
INFO - 2018-04-10 05:28:52 --> URI Class Initialized
INFO - 2018-04-10 05:28:52 --> Router Class Initialized
INFO - 2018-04-10 05:28:52 --> Output Class Initialized
INFO - 2018-04-10 05:28:52 --> Security Class Initialized
DEBUG - 2018-04-10 05:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 05:28:52 --> Input Class Initialized
INFO - 2018-04-10 05:28:52 --> Language Class Initialized
INFO - 2018-04-10 05:28:52 --> Language Class Initialized
INFO - 2018-04-10 05:28:52 --> Config Class Initialized
INFO - 2018-04-10 05:28:52 --> Loader Class Initialized
INFO - 2018-04-10 10:58:52 --> Helper loaded: url_helper
INFO - 2018-04-10 10:58:52 --> Helper loaded: notification_helper
INFO - 2018-04-10 10:58:52 --> Helper loaded: settings_helper
INFO - 2018-04-10 10:58:52 --> Helper loaded: permission_helper
INFO - 2018-04-10 10:58:52 --> Helper loaded: users_helper
INFO - 2018-04-10 10:58:52 --> Database Driver Class Initialized
DEBUG - 2018-04-10 10:58:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 10:58:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 10:58:52 --> Helper loaded: form_helper
INFO - 2018-04-10 10:58:52 --> Form Validation Class Initialized
INFO - 2018-04-10 10:58:52 --> Controller Class Initialized
INFO - 2018-04-10 10:58:52 --> Model Class Initialized
INFO - 2018-04-10 10:58:52 --> Helper loaded: inflector_helper
DEBUG - 2018-04-10 10:58:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-10 10:58:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-10 10:58:52 --> Model Class Initialized
INFO - 2018-04-10 10:58:52 --> Model Class Initialized
INFO - 2018-04-10 10:58:52 --> Model Class Initialized
INFO - 2018-04-10 10:58:52 --> Model Class Initialized
INFO - 2018-04-10 10:58:52 --> Model Class Initialized
INFO - 2018-04-10 10:58:52 --> Model Class Initialized
INFO - 2018-04-10 10:58:52 --> Model Class Initialized
INFO - 2018-04-10 10:58:52 --> Model Class Initialized
INFO - 2018-04-10 10:58:52 --> Model Class Initialized
INFO - 2018-04-10 10:58:52 --> Model Class Initialized
INFO - 2018-04-10 10:58:52 --> Model Class Initialized
INFO - 2018-04-10 10:58:52 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-10 10:58:52 --> Model Class Initialized
INFO - 2018-04-10 10:58:52 --> Final output sent to browser
DEBUG - 2018-04-10 10:58:52 --> Total execution time: 0.1350
INFO - 2018-04-10 05:28:52 --> Config Class Initialized
INFO - 2018-04-10 05:28:52 --> Hooks Class Initialized
DEBUG - 2018-04-10 05:28:52 --> UTF-8 Support Enabled
INFO - 2018-04-10 05:28:52 --> Utf8 Class Initialized
INFO - 2018-04-10 05:28:52 --> URI Class Initialized
INFO - 2018-04-10 05:28:52 --> Router Class Initialized
INFO - 2018-04-10 05:28:52 --> Output Class Initialized
INFO - 2018-04-10 05:28:52 --> Security Class Initialized
DEBUG - 2018-04-10 05:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 05:28:52 --> Input Class Initialized
INFO - 2018-04-10 05:28:52 --> Language Class Initialized
INFO - 2018-04-10 05:28:52 --> Language Class Initialized
INFO - 2018-04-10 05:28:52 --> Config Class Initialized
INFO - 2018-04-10 05:28:52 --> Loader Class Initialized
INFO - 2018-04-10 10:58:52 --> Helper loaded: url_helper
INFO - 2018-04-10 10:58:52 --> Helper loaded: notification_helper
INFO - 2018-04-10 10:58:52 --> Helper loaded: settings_helper
INFO - 2018-04-10 10:58:52 --> Helper loaded: permission_helper
INFO - 2018-04-10 10:58:52 --> Helper loaded: users_helper
INFO - 2018-04-10 10:58:52 --> Database Driver Class Initialized
DEBUG - 2018-04-10 10:58:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 10:58:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 10:58:52 --> Helper loaded: form_helper
INFO - 2018-04-10 10:58:52 --> Form Validation Class Initialized
INFO - 2018-04-10 10:58:52 --> Controller Class Initialized
INFO - 2018-04-10 10:58:52 --> Model Class Initialized
INFO - 2018-04-10 10:58:52 --> Helper loaded: inflector_helper
DEBUG - 2018-04-10 10:58:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-10 10:58:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-10 10:58:52 --> Model Class Initialized
INFO - 2018-04-10 10:58:52 --> Model Class Initialized
INFO - 2018-04-10 10:58:52 --> Model Class Initialized
INFO - 2018-04-10 10:58:52 --> Model Class Initialized
INFO - 2018-04-10 10:58:52 --> Model Class Initialized
INFO - 2018-04-10 10:58:52 --> Model Class Initialized
INFO - 2018-04-10 10:58:52 --> Model Class Initialized
INFO - 2018-04-10 10:58:52 --> Model Class Initialized
INFO - 2018-04-10 10:58:52 --> Model Class Initialized
INFO - 2018-04-10 10:58:52 --> Model Class Initialized
INFO - 2018-04-10 10:58:52 --> Model Class Initialized
INFO - 2018-04-10 10:58:52 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-10 10:58:52 --> Model Class Initialized
INFO - 2018-04-10 10:58:52 --> Final output sent to browser
DEBUG - 2018-04-10 10:58:52 --> Total execution time: 0.1223
INFO - 2018-04-10 05:28:54 --> Config Class Initialized
INFO - 2018-04-10 05:28:54 --> Hooks Class Initialized
DEBUG - 2018-04-10 05:28:54 --> UTF-8 Support Enabled
INFO - 2018-04-10 05:28:54 --> Utf8 Class Initialized
INFO - 2018-04-10 05:28:54 --> URI Class Initialized
INFO - 2018-04-10 05:28:54 --> Router Class Initialized
INFO - 2018-04-10 05:28:54 --> Output Class Initialized
INFO - 2018-04-10 05:28:54 --> Security Class Initialized
DEBUG - 2018-04-10 05:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 05:28:54 --> Input Class Initialized
INFO - 2018-04-10 05:28:54 --> Language Class Initialized
INFO - 2018-04-10 05:28:54 --> Config Class Initialized
INFO - 2018-04-10 05:28:54 --> Hooks Class Initialized
INFO - 2018-04-10 05:28:54 --> Language Class Initialized
INFO - 2018-04-10 05:28:54 --> Config Class Initialized
INFO - 2018-04-10 05:28:54 --> Loader Class Initialized
INFO - 2018-04-10 10:58:54 --> Helper loaded: url_helper
DEBUG - 2018-04-10 05:28:54 --> UTF-8 Support Enabled
INFO - 2018-04-10 05:28:54 --> Utf8 Class Initialized
INFO - 2018-04-10 10:58:54 --> Helper loaded: notification_helper
INFO - 2018-04-10 10:58:54 --> Helper loaded: settings_helper
INFO - 2018-04-10 10:58:54 --> Helper loaded: permission_helper
INFO - 2018-04-10 05:28:54 --> URI Class Initialized
INFO - 2018-04-10 10:58:54 --> Helper loaded: users_helper
INFO - 2018-04-10 05:28:54 --> Router Class Initialized
INFO - 2018-04-10 05:28:54 --> Output Class Initialized
INFO - 2018-04-10 05:28:54 --> Security Class Initialized
DEBUG - 2018-04-10 05:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 05:28:54 --> Input Class Initialized
INFO - 2018-04-10 05:28:54 --> Language Class Initialized
INFO - 2018-04-10 10:58:54 --> Database Driver Class Initialized
DEBUG - 2018-04-10 10:58:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 10:58:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 10:58:55 --> Helper loaded: form_helper
INFO - 2018-04-10 10:58:55 --> Form Validation Class Initialized
INFO - 2018-04-10 10:58:55 --> Controller Class Initialized
INFO - 2018-04-10 05:28:55 --> Language Class Initialized
INFO - 2018-04-10 05:28:55 --> Config Class Initialized
INFO - 2018-04-10 05:28:55 --> Loader Class Initialized
INFO - 2018-04-10 10:58:55 --> Helper loaded: url_helper
INFO - 2018-04-10 10:58:55 --> Helper loaded: notification_helper
INFO - 2018-04-10 10:58:55 --> Helper loaded: settings_helper
INFO - 2018-04-10 10:58:55 --> Helper loaded: permission_helper
INFO - 2018-04-10 10:58:55 --> Helper loaded: users_helper
INFO - 2018-04-10 10:58:55 --> Model Class Initialized
INFO - 2018-04-10 10:58:55 --> Helper loaded: inflector_helper
DEBUG - 2018-04-10 10:58:55 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-10 10:58:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-10 10:58:55 --> Model Class Initialized
INFO - 2018-04-10 10:58:55 --> Model Class Initialized
INFO - 2018-04-10 10:58:55 --> Model Class Initialized
INFO - 2018-04-10 10:58:55 --> Model Class Initialized
INFO - 2018-04-10 10:58:55 --> Database Driver Class Initialized
INFO - 2018-04-10 10:58:55 --> Model Class Initialized
INFO - 2018-04-10 10:58:55 --> Model Class Initialized
INFO - 2018-04-10 10:58:55 --> Model Class Initialized
INFO - 2018-04-10 10:58:55 --> Model Class Initialized
INFO - 2018-04-10 10:58:55 --> Model Class Initialized
INFO - 2018-04-10 10:58:55 --> Model Class Initialized
DEBUG - 2018-04-10 10:58:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 10:58:55 --> Model Class Initialized
INFO - 2018-04-10 10:58:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 10:58:55 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-10 10:58:55 --> Model Class Initialized
INFO - 2018-04-10 10:58:55 --> Helper loaded: form_helper
INFO - 2018-04-10 10:58:55 --> Form Validation Class Initialized
INFO - 2018-04-10 10:58:55 --> Controller Class Initialized
INFO - 2018-04-10 10:58:55 --> Final output sent to browser
DEBUG - 2018-04-10 10:58:55 --> Total execution time: 0.1190
INFO - 2018-04-10 10:58:55 --> Model Class Initialized
INFO - 2018-04-10 10:58:55 --> Helper loaded: inflector_helper
DEBUG - 2018-04-10 10:58:55 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-10 10:58:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-10 10:58:55 --> Model Class Initialized
INFO - 2018-04-10 10:58:55 --> Model Class Initialized
INFO - 2018-04-10 10:58:55 --> Model Class Initialized
INFO - 2018-04-10 10:58:55 --> Model Class Initialized
INFO - 2018-04-10 10:58:55 --> Model Class Initialized
INFO - 2018-04-10 10:58:55 --> Model Class Initialized
INFO - 2018-04-10 10:58:55 --> Model Class Initialized
INFO - 2018-04-10 10:58:55 --> Model Class Initialized
INFO - 2018-04-10 10:58:55 --> Model Class Initialized
INFO - 2018-04-10 10:58:55 --> Model Class Initialized
INFO - 2018-04-10 10:58:55 --> Model Class Initialized
INFO - 2018-04-10 10:58:55 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-10 10:58:55 --> Final output sent to browser
DEBUG - 2018-04-10 10:58:55 --> Total execution time: 0.1372
