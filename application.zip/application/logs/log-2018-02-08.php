<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-02-08 05:05:29 --> Config Class Initialized
INFO - 2018-02-08 05:05:29 --> Hooks Class Initialized
DEBUG - 2018-02-08 05:05:29 --> UTF-8 Support Enabled
INFO - 2018-02-08 05:05:29 --> Utf8 Class Initialized
INFO - 2018-02-08 05:05:29 --> URI Class Initialized
DEBUG - 2018-02-08 05:05:29 --> No URI present. Default controller set.
INFO - 2018-02-08 05:05:29 --> Router Class Initialized
INFO - 2018-02-08 05:05:29 --> Output Class Initialized
INFO - 2018-02-08 05:05:29 --> Security Class Initialized
DEBUG - 2018-02-08 05:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-08 05:05:29 --> Input Class Initialized
INFO - 2018-02-08 05:05:29 --> Language Class Initialized
INFO - 2018-02-08 05:05:29 --> Language Class Initialized
INFO - 2018-02-08 05:05:29 --> Config Class Initialized
INFO - 2018-02-08 05:05:29 --> Loader Class Initialized
INFO - 2018-02-08 10:35:29 --> Helper loaded: url_helper
INFO - 2018-02-08 10:35:29 --> Helper loaded: notification_helper
INFO - 2018-02-08 10:35:29 --> Helper loaded: settings_helper
INFO - 2018-02-08 10:35:29 --> Helper loaded: permission_helper
INFO - 2018-02-08 10:35:29 --> Helper loaded: users_helper
INFO - 2018-02-08 10:35:29 --> Database Driver Class Initialized
DEBUG - 2018-02-08 10:35:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-08 10:35:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-08 10:35:29 --> Helper loaded: form_helper
INFO - 2018-02-08 10:35:29 --> Form Validation Class Initialized
INFO - 2018-02-08 10:35:29 --> Controller Class Initialized
INFO - 2018-02-08 10:35:29 --> Model Class Initialized
INFO - 2018-02-08 10:35:29 --> Helper loaded: inflector_helper
INFO - 2018-02-08 10:35:29 --> Model Class Initialized
DEBUG - 2018-02-08 10:35:29 --> File loaded: /home/pr01004/public_html/application/views/login.php
INFO - 2018-02-08 10:35:29 --> Final output sent to browser
DEBUG - 2018-02-08 10:35:29 --> Total execution time: 0.1358
INFO - 2018-02-08 05:12:24 --> Config Class Initialized
INFO - 2018-02-08 05:12:24 --> Hooks Class Initialized
DEBUG - 2018-02-08 05:12:24 --> UTF-8 Support Enabled
INFO - 2018-02-08 05:12:24 --> Utf8 Class Initialized
INFO - 2018-02-08 05:12:24 --> URI Class Initialized
INFO - 2018-02-08 05:12:24 --> Router Class Initialized
INFO - 2018-02-08 05:12:24 --> Output Class Initialized
INFO - 2018-02-08 05:12:24 --> Security Class Initialized
DEBUG - 2018-02-08 05:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-08 05:12:24 --> Input Class Initialized
INFO - 2018-02-08 05:12:24 --> Language Class Initialized
INFO - 2018-02-08 05:12:24 --> Language Class Initialized
INFO - 2018-02-08 05:12:24 --> Config Class Initialized
INFO - 2018-02-08 05:12:24 --> Loader Class Initialized
INFO - 2018-02-08 10:42:24 --> Helper loaded: url_helper
INFO - 2018-02-08 10:42:24 --> Helper loaded: notification_helper
INFO - 2018-02-08 10:42:24 --> Helper loaded: settings_helper
INFO - 2018-02-08 10:42:24 --> Helper loaded: permission_helper
INFO - 2018-02-08 10:42:24 --> Helper loaded: users_helper
INFO - 2018-02-08 10:42:24 --> Database Driver Class Initialized
DEBUG - 2018-02-08 10:42:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-08 10:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-08 10:42:24 --> Helper loaded: form_helper
INFO - 2018-02-08 10:42:24 --> Form Validation Class Initialized
INFO - 2018-02-08 10:42:24 --> Controller Class Initialized
INFO - 2018-02-08 10:42:24 --> Model Class Initialized
INFO - 2018-02-08 10:42:24 --> Helper loaded: inflector_helper
DEBUG - 2018-02-08 10:42:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-08 10:42:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-08 10:42:24 --> Model Class Initialized
INFO - 2018-02-08 10:42:24 --> Model Class Initialized
INFO - 2018-02-08 10:42:24 --> Model Class Initialized
INFO - 2018-02-08 10:42:24 --> Model Class Initialized
INFO - 2018-02-08 10:42:24 --> Model Class Initialized
INFO - 2018-02-08 10:42:24 --> Model Class Initialized
INFO - 2018-02-08 10:42:24 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-08 10:42:24 --> Model Class Initialized
INFO - 2018-02-08 10:42:24 --> Final output sent to browser
DEBUG - 2018-02-08 10:42:24 --> Total execution time: 0.1084
INFO - 2018-02-08 05:12:25 --> Config Class Initialized
INFO - 2018-02-08 05:12:25 --> Hooks Class Initialized
DEBUG - 2018-02-08 05:12:25 --> UTF-8 Support Enabled
INFO - 2018-02-08 05:12:25 --> Utf8 Class Initialized
INFO - 2018-02-08 05:12:25 --> URI Class Initialized
INFO - 2018-02-08 05:12:25 --> Router Class Initialized
INFO - 2018-02-08 05:12:25 --> Output Class Initialized
INFO - 2018-02-08 05:12:25 --> Security Class Initialized
DEBUG - 2018-02-08 05:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-08 05:12:25 --> Input Class Initialized
INFO - 2018-02-08 05:12:25 --> Language Class Initialized
INFO - 2018-02-08 05:12:25 --> Language Class Initialized
INFO - 2018-02-08 05:12:25 --> Config Class Initialized
INFO - 2018-02-08 05:12:25 --> Loader Class Initialized
INFO - 2018-02-08 10:42:25 --> Helper loaded: url_helper
INFO - 2018-02-08 10:42:25 --> Helper loaded: notification_helper
INFO - 2018-02-08 10:42:25 --> Helper loaded: settings_helper
INFO - 2018-02-08 10:42:25 --> Helper loaded: permission_helper
INFO - 2018-02-08 10:42:25 --> Helper loaded: users_helper
INFO - 2018-02-08 10:42:25 --> Database Driver Class Initialized
DEBUG - 2018-02-08 10:42:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-08 10:42:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-08 10:42:25 --> Helper loaded: form_helper
INFO - 2018-02-08 10:42:25 --> Form Validation Class Initialized
INFO - 2018-02-08 10:42:25 --> Controller Class Initialized
DEBUG - 2018-02-08 10:42:25 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-02-08 10:42:25 --> Final output sent to browser
DEBUG - 2018-02-08 10:42:25 --> Total execution time: 0.1417
INFO - 2018-02-08 05:16:49 --> Config Class Initialized
INFO - 2018-02-08 05:16:49 --> Hooks Class Initialized
DEBUG - 2018-02-08 05:16:49 --> UTF-8 Support Enabled
INFO - 2018-02-08 05:16:49 --> Utf8 Class Initialized
INFO - 2018-02-08 05:16:49 --> URI Class Initialized
INFO - 2018-02-08 05:16:49 --> Router Class Initialized
INFO - 2018-02-08 05:16:49 --> Output Class Initialized
INFO - 2018-02-08 05:16:49 --> Security Class Initialized
DEBUG - 2018-02-08 05:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-08 05:16:49 --> Input Class Initialized
INFO - 2018-02-08 05:16:49 --> Language Class Initialized
INFO - 2018-02-08 05:16:49 --> Language Class Initialized
INFO - 2018-02-08 05:16:49 --> Config Class Initialized
INFO - 2018-02-08 05:16:49 --> Loader Class Initialized
INFO - 2018-02-08 10:46:49 --> Helper loaded: url_helper
INFO - 2018-02-08 10:46:49 --> Helper loaded: notification_helper
INFO - 2018-02-08 10:46:49 --> Helper loaded: settings_helper
INFO - 2018-02-08 10:46:49 --> Helper loaded: permission_helper
INFO - 2018-02-08 10:46:49 --> Helper loaded: users_helper
INFO - 2018-02-08 10:46:49 --> Database Driver Class Initialized
DEBUG - 2018-02-08 10:46:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-08 10:46:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-08 10:46:49 --> Helper loaded: form_helper
INFO - 2018-02-08 10:46:49 --> Form Validation Class Initialized
INFO - 2018-02-08 10:46:49 --> Controller Class Initialized
INFO - 2018-02-08 10:46:49 --> Model Class Initialized
INFO - 2018-02-08 10:46:49 --> Helper loaded: inflector_helper
DEBUG - 2018-02-08 10:46:49 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-08 10:46:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-08 10:46:49 --> Model Class Initialized
INFO - 2018-02-08 10:46:49 --> Model Class Initialized
INFO - 2018-02-08 10:46:49 --> Model Class Initialized
INFO - 2018-02-08 10:46:49 --> Model Class Initialized
INFO - 2018-02-08 10:46:49 --> Model Class Initialized
INFO - 2018-02-08 10:46:49 --> Model Class Initialized
INFO - 2018-02-08 10:46:49 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-08 10:46:49 --> Model Class Initialized
INFO - 2018-02-08 10:46:49 --> Final output sent to browser
DEBUG - 2018-02-08 10:46:49 --> Total execution time: 0.1047
INFO - 2018-02-08 05:16:53 --> Config Class Initialized
INFO - 2018-02-08 05:16:53 --> Hooks Class Initialized
DEBUG - 2018-02-08 05:16:53 --> UTF-8 Support Enabled
INFO - 2018-02-08 05:16:53 --> Utf8 Class Initialized
INFO - 2018-02-08 05:16:53 --> URI Class Initialized
DEBUG - 2018-02-08 05:16:53 --> No URI present. Default controller set.
INFO - 2018-02-08 05:16:53 --> Router Class Initialized
INFO - 2018-02-08 05:16:53 --> Output Class Initialized
INFO - 2018-02-08 05:16:53 --> Security Class Initialized
DEBUG - 2018-02-08 05:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-08 05:16:53 --> Input Class Initialized
INFO - 2018-02-08 05:16:53 --> Language Class Initialized
INFO - 2018-02-08 05:16:53 --> Language Class Initialized
INFO - 2018-02-08 05:16:53 --> Config Class Initialized
INFO - 2018-02-08 05:16:53 --> Loader Class Initialized
INFO - 2018-02-08 10:46:53 --> Helper loaded: url_helper
INFO - 2018-02-08 10:46:53 --> Helper loaded: notification_helper
INFO - 2018-02-08 10:46:53 --> Helper loaded: settings_helper
INFO - 2018-02-08 10:46:53 --> Helper loaded: permission_helper
INFO - 2018-02-08 10:46:53 --> Helper loaded: users_helper
INFO - 2018-02-08 10:46:53 --> Database Driver Class Initialized
DEBUG - 2018-02-08 10:46:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-08 10:46:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-08 10:46:53 --> Helper loaded: form_helper
INFO - 2018-02-08 10:46:53 --> Form Validation Class Initialized
INFO - 2018-02-08 10:46:53 --> Controller Class Initialized
INFO - 2018-02-08 10:46:53 --> Model Class Initialized
INFO - 2018-02-08 10:46:53 --> Helper loaded: inflector_helper
INFO - 2018-02-08 10:46:53 --> Model Class Initialized
DEBUG - 2018-02-08 10:46:53 --> File loaded: /home/pr01004/public_html/application/views/login.php
INFO - 2018-02-08 10:46:53 --> Final output sent to browser
DEBUG - 2018-02-08 10:46:53 --> Total execution time: 0.0894
INFO - 2018-02-08 05:16:59 --> Config Class Initialized
INFO - 2018-02-08 05:16:59 --> Hooks Class Initialized
DEBUG - 2018-02-08 05:16:59 --> UTF-8 Support Enabled
INFO - 2018-02-08 05:16:59 --> Utf8 Class Initialized
INFO - 2018-02-08 05:16:59 --> URI Class Initialized
INFO - 2018-02-08 05:16:59 --> Router Class Initialized
INFO - 2018-02-08 05:16:59 --> Output Class Initialized
INFO - 2018-02-08 05:16:59 --> Security Class Initialized
DEBUG - 2018-02-08 05:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-08 05:16:59 --> Input Class Initialized
INFO - 2018-02-08 05:16:59 --> Language Class Initialized
INFO - 2018-02-08 05:16:59 --> Language Class Initialized
INFO - 2018-02-08 05:16:59 --> Config Class Initialized
INFO - 2018-02-08 05:16:59 --> Loader Class Initialized
INFO - 2018-02-08 10:46:59 --> Helper loaded: url_helper
INFO - 2018-02-08 10:46:59 --> Helper loaded: notification_helper
INFO - 2018-02-08 10:46:59 --> Helper loaded: settings_helper
INFO - 2018-02-08 10:46:59 --> Helper loaded: permission_helper
INFO - 2018-02-08 10:46:59 --> Helper loaded: users_helper
INFO - 2018-02-08 10:46:59 --> Database Driver Class Initialized
DEBUG - 2018-02-08 10:46:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-08 10:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-08 10:46:59 --> Helper loaded: form_helper
INFO - 2018-02-08 10:46:59 --> Form Validation Class Initialized
INFO - 2018-02-08 10:46:59 --> Controller Class Initialized
INFO - 2018-02-08 10:46:59 --> Model Class Initialized
INFO - 2018-02-08 10:46:59 --> Helper loaded: inflector_helper
INFO - 2018-02-08 10:46:59 --> Model Class Initialized
INFO - 2018-02-08 10:46:59 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2018-02-08 10:46:59 --> File loaded: /home/pr01004/public_html/application/views/login.php
INFO - 2018-02-08 10:46:59 --> Final output sent to browser
DEBUG - 2018-02-08 10:46:59 --> Total execution time: 0.1016
INFO - 2018-02-08 05:17:08 --> Config Class Initialized
INFO - 2018-02-08 05:17:08 --> Hooks Class Initialized
DEBUG - 2018-02-08 05:17:08 --> UTF-8 Support Enabled
INFO - 2018-02-08 05:17:08 --> Utf8 Class Initialized
INFO - 2018-02-08 05:17:08 --> URI Class Initialized
INFO - 2018-02-08 05:17:08 --> Router Class Initialized
INFO - 2018-02-08 05:17:08 --> Output Class Initialized
INFO - 2018-02-08 05:17:08 --> Security Class Initialized
DEBUG - 2018-02-08 05:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-08 05:17:08 --> Input Class Initialized
INFO - 2018-02-08 05:17:08 --> Language Class Initialized
INFO - 2018-02-08 05:17:08 --> Language Class Initialized
INFO - 2018-02-08 05:17:08 --> Config Class Initialized
INFO - 2018-02-08 05:17:08 --> Loader Class Initialized
INFO - 2018-02-08 10:47:08 --> Helper loaded: url_helper
INFO - 2018-02-08 10:47:08 --> Helper loaded: notification_helper
INFO - 2018-02-08 10:47:08 --> Helper loaded: settings_helper
INFO - 2018-02-08 10:47:08 --> Helper loaded: permission_helper
INFO - 2018-02-08 10:47:08 --> Helper loaded: users_helper
INFO - 2018-02-08 10:47:08 --> Database Driver Class Initialized
DEBUG - 2018-02-08 10:47:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-08 10:47:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-08 10:47:08 --> Helper loaded: form_helper
INFO - 2018-02-08 10:47:08 --> Form Validation Class Initialized
INFO - 2018-02-08 10:47:08 --> Controller Class Initialized
INFO - 2018-02-08 10:47:08 --> Model Class Initialized
INFO - 2018-02-08 10:47:08 --> Helper loaded: inflector_helper
INFO - 2018-02-08 10:47:08 --> Model Class Initialized
INFO - 2018-02-08 10:47:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-08 05:17:08 --> Config Class Initialized
INFO - 2018-02-08 05:17:08 --> Hooks Class Initialized
DEBUG - 2018-02-08 05:17:08 --> UTF-8 Support Enabled
INFO - 2018-02-08 05:17:08 --> Utf8 Class Initialized
INFO - 2018-02-08 05:17:08 --> URI Class Initialized
INFO - 2018-02-08 05:17:08 --> Router Class Initialized
INFO - 2018-02-08 05:17:08 --> Output Class Initialized
INFO - 2018-02-08 05:17:08 --> Security Class Initialized
DEBUG - 2018-02-08 05:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-08 05:17:08 --> Input Class Initialized
INFO - 2018-02-08 05:17:08 --> Language Class Initialized
INFO - 2018-02-08 05:17:08 --> Language Class Initialized
INFO - 2018-02-08 05:17:08 --> Config Class Initialized
INFO - 2018-02-08 05:17:08 --> Loader Class Initialized
INFO - 2018-02-08 10:47:08 --> Helper loaded: url_helper
INFO - 2018-02-08 10:47:08 --> Helper loaded: notification_helper
INFO - 2018-02-08 10:47:08 --> Helper loaded: settings_helper
INFO - 2018-02-08 10:47:08 --> Helper loaded: permission_helper
INFO - 2018-02-08 10:47:08 --> Helper loaded: users_helper
INFO - 2018-02-08 10:47:08 --> Database Driver Class Initialized
DEBUG - 2018-02-08 10:47:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-08 10:47:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-08 10:47:08 --> Helper loaded: form_helper
INFO - 2018-02-08 10:47:08 --> Form Validation Class Initialized
INFO - 2018-02-08 10:47:08 --> Controller Class Initialized
INFO - 2018-02-08 10:47:08 --> Model Class Initialized
INFO - 2018-02-08 10:47:08 --> Helper loaded: inflector_helper
INFO - 2018-02-08 10:47:08 --> Model Class Initialized
INFO - 2018-02-08 10:47:08 --> Model Class Initialized
INFO - 2018-02-08 10:47:08 --> Model Class Initialized
INFO - 2018-02-08 10:47:08 --> Model Class Initialized
INFO - 2018-02-08 10:47:08 --> Model Class Initialized
DEBUG - 2018-02-08 10:47:08 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-02-08 10:47:08 --> File loaded: /home/pr01004/public_html/application/views/admin/dashboard.php
DEBUG - 2018-02-08 10:47:08 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-02-08 10:47:08 --> Final output sent to browser
DEBUG - 2018-02-08 10:47:08 --> Total execution time: 0.1849
INFO - 2018-02-08 05:17:28 --> Config Class Initialized
INFO - 2018-02-08 05:17:28 --> Hooks Class Initialized
DEBUG - 2018-02-08 05:17:28 --> UTF-8 Support Enabled
INFO - 2018-02-08 05:17:28 --> Utf8 Class Initialized
INFO - 2018-02-08 05:17:28 --> URI Class Initialized
INFO - 2018-02-08 05:17:28 --> Router Class Initialized
INFO - 2018-02-08 05:17:28 --> Output Class Initialized
INFO - 2018-02-08 05:17:28 --> Security Class Initialized
DEBUG - 2018-02-08 05:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-08 05:17:28 --> Input Class Initialized
INFO - 2018-02-08 05:17:28 --> Language Class Initialized
INFO - 2018-02-08 05:17:28 --> Language Class Initialized
INFO - 2018-02-08 05:17:28 --> Config Class Initialized
INFO - 2018-02-08 05:17:28 --> Loader Class Initialized
INFO - 2018-02-08 10:47:28 --> Helper loaded: url_helper
INFO - 2018-02-08 10:47:28 --> Helper loaded: notification_helper
INFO - 2018-02-08 10:47:28 --> Helper loaded: settings_helper
INFO - 2018-02-08 10:47:28 --> Helper loaded: permission_helper
INFO - 2018-02-08 10:47:28 --> Helper loaded: users_helper
INFO - 2018-02-08 10:47:28 --> Database Driver Class Initialized
DEBUG - 2018-02-08 10:47:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-08 10:47:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-08 10:47:28 --> Helper loaded: form_helper
INFO - 2018-02-08 10:47:28 --> Form Validation Class Initialized
INFO - 2018-02-08 10:47:28 --> Controller Class Initialized
INFO - 2018-02-08 10:47:28 --> Model Class Initialized
INFO - 2018-02-08 10:47:28 --> Helper loaded: inflector_helper
INFO - 2018-02-08 10:47:28 --> Model Class Initialized
DEBUG - 2018-02-08 10:47:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-08 10:47:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-08 10:47:28 --> Model Class Initialized
INFO - 2018-02-08 10:47:28 --> Model Class Initialized
INFO - 2018-02-08 10:47:28 --> Model Class Initialized
INFO - 2018-02-08 10:47:28 --> Model Class Initialized
INFO - 2018-02-08 10:47:28 --> Model Class Initialized
INFO - 2018-02-08 10:47:28 --> Model Class Initialized
INFO - 2018-02-08 10:47:28 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-08 10:47:28 --> Model Class Initialized
INFO - 2018-02-08 10:47:28 --> Final output sent to browser
DEBUG - 2018-02-08 10:47:28 --> Total execution time: 0.1136
INFO - 2018-02-08 05:17:28 --> Config Class Initialized
INFO - 2018-02-08 05:17:28 --> Hooks Class Initialized
DEBUG - 2018-02-08 05:17:28 --> UTF-8 Support Enabled
INFO - 2018-02-08 05:17:28 --> Utf8 Class Initialized
INFO - 2018-02-08 05:17:28 --> URI Class Initialized
INFO - 2018-02-08 05:17:28 --> Router Class Initialized
INFO - 2018-02-08 05:17:28 --> Output Class Initialized
INFO - 2018-02-08 05:17:28 --> Security Class Initialized
DEBUG - 2018-02-08 05:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-08 05:17:28 --> Input Class Initialized
INFO - 2018-02-08 05:17:28 --> Language Class Initialized
INFO - 2018-02-08 05:17:29 --> Language Class Initialized
INFO - 2018-02-08 05:17:29 --> Config Class Initialized
INFO - 2018-02-08 05:17:29 --> Loader Class Initialized
INFO - 2018-02-08 10:47:29 --> Helper loaded: url_helper
INFO - 2018-02-08 10:47:29 --> Helper loaded: notification_helper
INFO - 2018-02-08 10:47:29 --> Helper loaded: settings_helper
INFO - 2018-02-08 10:47:29 --> Helper loaded: permission_helper
INFO - 2018-02-08 10:47:29 --> Helper loaded: users_helper
INFO - 2018-02-08 10:47:29 --> Database Driver Class Initialized
DEBUG - 2018-02-08 10:47:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-08 10:47:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-08 10:47:29 --> Helper loaded: form_helper
INFO - 2018-02-08 10:47:29 --> Form Validation Class Initialized
INFO - 2018-02-08 10:47:29 --> Controller Class Initialized
DEBUG - 2018-02-08 10:47:29 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-02-08 10:47:29 --> Final output sent to browser
DEBUG - 2018-02-08 10:47:29 --> Total execution time: 0.0772
INFO - 2018-02-08 05:28:41 --> Config Class Initialized
INFO - 2018-02-08 05:28:41 --> Hooks Class Initialized
DEBUG - 2018-02-08 05:28:41 --> UTF-8 Support Enabled
INFO - 2018-02-08 05:28:41 --> Utf8 Class Initialized
INFO - 2018-02-08 05:28:41 --> URI Class Initialized
INFO - 2018-02-08 05:28:41 --> Router Class Initialized
INFO - 2018-02-08 05:28:41 --> Output Class Initialized
INFO - 2018-02-08 05:28:41 --> Security Class Initialized
DEBUG - 2018-02-08 05:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-08 05:28:41 --> Input Class Initialized
INFO - 2018-02-08 05:28:41 --> Language Class Initialized
INFO - 2018-02-08 05:28:41 --> Language Class Initialized
INFO - 2018-02-08 05:28:41 --> Config Class Initialized
INFO - 2018-02-08 05:28:41 --> Loader Class Initialized
INFO - 2018-02-08 10:58:41 --> Helper loaded: url_helper
INFO - 2018-02-08 10:58:41 --> Helper loaded: notification_helper
INFO - 2018-02-08 10:58:41 --> Helper loaded: settings_helper
INFO - 2018-02-08 10:58:41 --> Helper loaded: permission_helper
INFO - 2018-02-08 10:58:41 --> Helper loaded: users_helper
INFO - 2018-02-08 10:58:41 --> Database Driver Class Initialized
DEBUG - 2018-02-08 10:58:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-08 10:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-08 10:58:41 --> Helper loaded: form_helper
INFO - 2018-02-08 10:58:41 --> Form Validation Class Initialized
INFO - 2018-02-08 10:58:41 --> Controller Class Initialized
INFO - 2018-02-08 10:58:41 --> Model Class Initialized
INFO - 2018-02-08 10:58:41 --> Helper loaded: inflector_helper
INFO - 2018-02-08 10:58:41 --> Model Class Initialized
INFO - 2018-02-08 10:58:41 --> Model Class Initialized
INFO - 2018-02-08 10:58:41 --> Model Class Initialized
INFO - 2018-02-08 10:58:41 --> Model Class Initialized
INFO - 2018-02-08 10:58:41 --> Model Class Initialized
DEBUG - 2018-02-08 10:58:41 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-02-08 10:58:41 --> File loaded: /home/pr01004/public_html/application/views/admin/dashboard.php
DEBUG - 2018-02-08 10:58:41 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-02-08 10:58:41 --> Final output sent to browser
DEBUG - 2018-02-08 10:58:41 --> Total execution time: 0.1113
INFO - 2018-02-08 05:28:56 --> Config Class Initialized
INFO - 2018-02-08 05:28:56 --> Hooks Class Initialized
DEBUG - 2018-02-08 05:28:56 --> UTF-8 Support Enabled
INFO - 2018-02-08 05:28:56 --> Utf8 Class Initialized
INFO - 2018-02-08 05:28:56 --> URI Class Initialized
INFO - 2018-02-08 05:28:56 --> Router Class Initialized
INFO - 2018-02-08 05:28:56 --> Output Class Initialized
INFO - 2018-02-08 05:28:56 --> Security Class Initialized
DEBUG - 2018-02-08 05:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-08 05:28:56 --> Input Class Initialized
INFO - 2018-02-08 05:28:56 --> Language Class Initialized
INFO - 2018-02-08 05:28:56 --> Language Class Initialized
INFO - 2018-02-08 05:28:56 --> Config Class Initialized
INFO - 2018-02-08 05:28:56 --> Loader Class Initialized
INFO - 2018-02-08 10:58:56 --> Helper loaded: url_helper
INFO - 2018-02-08 10:58:56 --> Helper loaded: notification_helper
INFO - 2018-02-08 10:58:56 --> Helper loaded: settings_helper
INFO - 2018-02-08 10:58:56 --> Helper loaded: permission_helper
INFO - 2018-02-08 10:58:56 --> Helper loaded: users_helper
INFO - 2018-02-08 10:58:56 --> Database Driver Class Initialized
DEBUG - 2018-02-08 10:58:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-08 10:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-08 10:58:56 --> Helper loaded: form_helper
INFO - 2018-02-08 10:58:56 --> Form Validation Class Initialized
INFO - 2018-02-08 10:58:56 --> Controller Class Initialized
INFO - 2018-02-08 10:58:56 --> Model Class Initialized
INFO - 2018-02-08 10:58:56 --> Helper loaded: inflector_helper
INFO - 2018-02-08 10:58:56 --> Model Class Initialized
INFO - 2018-02-08 10:58:56 --> Model Class Initialized
DEBUG - 2018-02-08 10:58:56 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-02-08 10:58:56 --> File loaded: /home/pr01004/public_html/application/views/users/reported.php
DEBUG - 2018-02-08 10:58:56 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-02-08 10:58:56 --> Final output sent to browser
DEBUG - 2018-02-08 10:58:56 --> Total execution time: 0.1159
INFO - 2018-02-08 05:28:58 --> Config Class Initialized
INFO - 2018-02-08 05:28:58 --> Hooks Class Initialized
DEBUG - 2018-02-08 05:28:58 --> UTF-8 Support Enabled
INFO - 2018-02-08 05:28:58 --> Utf8 Class Initialized
INFO - 2018-02-08 05:28:58 --> URI Class Initialized
INFO - 2018-02-08 05:28:58 --> Router Class Initialized
INFO - 2018-02-08 05:28:58 --> Output Class Initialized
INFO - 2018-02-08 05:28:58 --> Security Class Initialized
DEBUG - 2018-02-08 05:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-08 05:28:58 --> Input Class Initialized
INFO - 2018-02-08 05:28:58 --> Language Class Initialized
INFO - 2018-02-08 05:28:58 --> Language Class Initialized
INFO - 2018-02-08 05:28:58 --> Config Class Initialized
INFO - 2018-02-08 05:28:58 --> Loader Class Initialized
INFO - 2018-02-08 10:58:58 --> Helper loaded: url_helper
INFO - 2018-02-08 10:58:58 --> Helper loaded: notification_helper
INFO - 2018-02-08 10:58:58 --> Helper loaded: settings_helper
INFO - 2018-02-08 10:58:58 --> Helper loaded: permission_helper
INFO - 2018-02-08 10:58:58 --> Helper loaded: users_helper
INFO - 2018-02-08 10:58:58 --> Database Driver Class Initialized
DEBUG - 2018-02-08 10:58:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-08 10:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-08 10:58:58 --> Helper loaded: form_helper
INFO - 2018-02-08 10:58:58 --> Form Validation Class Initialized
INFO - 2018-02-08 10:58:58 --> Controller Class Initialized
INFO - 2018-02-08 10:58:58 --> Model Class Initialized
INFO - 2018-02-08 10:58:58 --> Helper loaded: inflector_helper
INFO - 2018-02-08 10:58:58 --> Model Class Initialized
INFO - 2018-02-08 10:58:58 --> Model Class Initialized
INFO - 2018-02-08 10:58:58 --> Model Class Initialized
INFO - 2018-02-08 10:58:58 --> Model Class Initialized
INFO - 2018-02-08 10:58:58 --> Final output sent to browser
DEBUG - 2018-02-08 10:58:58 --> Total execution time: 0.0996
INFO - 2018-02-08 05:30:38 --> Config Class Initialized
INFO - 2018-02-08 05:30:38 --> Hooks Class Initialized
DEBUG - 2018-02-08 05:30:38 --> UTF-8 Support Enabled
INFO - 2018-02-08 05:30:38 --> Utf8 Class Initialized
INFO - 2018-02-08 05:30:38 --> URI Class Initialized
INFO - 2018-02-08 05:30:38 --> Router Class Initialized
INFO - 2018-02-08 05:30:38 --> Output Class Initialized
INFO - 2018-02-08 05:30:38 --> Security Class Initialized
DEBUG - 2018-02-08 05:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-08 05:30:38 --> Input Class Initialized
INFO - 2018-02-08 05:30:38 --> Language Class Initialized
INFO - 2018-02-08 05:30:38 --> Language Class Initialized
INFO - 2018-02-08 05:30:38 --> Config Class Initialized
INFO - 2018-02-08 05:30:38 --> Loader Class Initialized
INFO - 2018-02-08 11:00:38 --> Helper loaded: url_helper
INFO - 2018-02-08 11:00:38 --> Helper loaded: notification_helper
INFO - 2018-02-08 11:00:38 --> Helper loaded: settings_helper
INFO - 2018-02-08 11:00:38 --> Helper loaded: permission_helper
INFO - 2018-02-08 11:00:38 --> Helper loaded: users_helper
INFO - 2018-02-08 11:00:38 --> Database Driver Class Initialized
DEBUG - 2018-02-08 11:00:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-08 11:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-08 11:00:38 --> Helper loaded: form_helper
INFO - 2018-02-08 11:00:38 --> Form Validation Class Initialized
INFO - 2018-02-08 11:00:38 --> Controller Class Initialized
INFO - 2018-02-08 11:00:38 --> Model Class Initialized
INFO - 2018-02-08 11:00:38 --> Helper loaded: inflector_helper
INFO - 2018-02-08 11:00:38 --> Model Class Initialized
DEBUG - 2018-02-08 11:00:38 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-08 11:00:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-08 11:00:38 --> Model Class Initialized
INFO - 2018-02-08 11:00:38 --> Model Class Initialized
INFO - 2018-02-08 11:00:38 --> Model Class Initialized
INFO - 2018-02-08 11:00:38 --> Model Class Initialized
INFO - 2018-02-08 11:00:38 --> Model Class Initialized
INFO - 2018-02-08 11:00:38 --> Model Class Initialized
INFO - 2018-02-08 11:00:38 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-08 11:00:38 --> Model Class Initialized
INFO - 2018-02-08 11:00:38 --> Final output sent to browser
DEBUG - 2018-02-08 11:00:38 --> Total execution time: 0.1033
INFO - 2018-02-08 05:31:07 --> Config Class Initialized
INFO - 2018-02-08 05:31:07 --> Hooks Class Initialized
DEBUG - 2018-02-08 05:31:07 --> UTF-8 Support Enabled
INFO - 2018-02-08 05:31:07 --> Utf8 Class Initialized
INFO - 2018-02-08 05:31:07 --> URI Class Initialized
INFO - 2018-02-08 05:31:07 --> Router Class Initialized
INFO - 2018-02-08 05:31:07 --> Output Class Initialized
INFO - 2018-02-08 05:31:07 --> Security Class Initialized
DEBUG - 2018-02-08 05:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-08 05:31:07 --> Input Class Initialized
INFO - 2018-02-08 05:31:07 --> Language Class Initialized
INFO - 2018-02-08 05:31:07 --> Language Class Initialized
INFO - 2018-02-08 05:31:07 --> Config Class Initialized
INFO - 2018-02-08 05:31:07 --> Loader Class Initialized
INFO - 2018-02-08 11:01:07 --> Helper loaded: url_helper
INFO - 2018-02-08 11:01:07 --> Helper loaded: notification_helper
INFO - 2018-02-08 11:01:07 --> Helper loaded: settings_helper
INFO - 2018-02-08 11:01:07 --> Helper loaded: permission_helper
INFO - 2018-02-08 11:01:07 --> Helper loaded: users_helper
INFO - 2018-02-08 11:01:07 --> Database Driver Class Initialized
DEBUG - 2018-02-08 11:01:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-08 11:01:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-08 11:01:07 --> Helper loaded: form_helper
INFO - 2018-02-08 11:01:07 --> Form Validation Class Initialized
INFO - 2018-02-08 11:01:07 --> Controller Class Initialized
INFO - 2018-02-08 11:01:07 --> Model Class Initialized
INFO - 2018-02-08 11:01:07 --> Helper loaded: inflector_helper
DEBUG - 2018-02-08 11:01:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-08 11:01:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-08 11:01:07 --> Model Class Initialized
INFO - 2018-02-08 11:01:07 --> Model Class Initialized
INFO - 2018-02-08 11:01:07 --> Model Class Initialized
INFO - 2018-02-08 11:01:07 --> Model Class Initialized
INFO - 2018-02-08 11:01:07 --> Model Class Initialized
INFO - 2018-02-08 11:01:07 --> Model Class Initialized
INFO - 2018-02-08 11:01:07 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-08 11:01:07 --> Model Class Initialized
INFO - 2018-02-08 11:01:07 --> Final output sent to browser
DEBUG - 2018-02-08 11:01:07 --> Total execution time: 0.1183
