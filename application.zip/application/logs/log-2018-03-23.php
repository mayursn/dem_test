<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-03-23 13:51:00 --> Config Class Initialized
INFO - 2018-03-23 13:51:00 --> Hooks Class Initialized
DEBUG - 2018-03-23 13:51:00 --> UTF-8 Support Enabled
INFO - 2018-03-23 13:51:00 --> Utf8 Class Initialized
INFO - 2018-03-23 13:51:00 --> Config Class Initialized
INFO - 2018-03-23 13:51:00 --> Hooks Class Initialized
INFO - 2018-03-23 13:51:00 --> URI Class Initialized
DEBUG - 2018-03-23 13:51:00 --> UTF-8 Support Enabled
INFO - 2018-03-23 13:51:00 --> Utf8 Class Initialized
INFO - 2018-03-23 13:51:00 --> URI Class Initialized
INFO - 2018-03-23 13:51:00 --> Router Class Initialized
INFO - 2018-03-23 13:51:00 --> Output Class Initialized
INFO - 2018-03-23 13:51:00 --> Security Class Initialized
DEBUG - 2018-03-23 13:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 13:51:00 --> Input Class Initialized
INFO - 2018-03-23 13:51:00 --> Language Class Initialized
INFO - 2018-03-23 13:51:00 --> Router Class Initialized
INFO - 2018-03-23 13:51:00 --> Language Class Initialized
INFO - 2018-03-23 13:51:00 --> Config Class Initialized
INFO - 2018-03-23 13:51:00 --> Loader Class Initialized
INFO - 2018-03-23 19:21:00 --> Helper loaded: url_helper
INFO - 2018-03-23 13:51:00 --> Output Class Initialized
INFO - 2018-03-23 19:21:00 --> Helper loaded: notification_helper
INFO - 2018-03-23 19:21:00 --> Helper loaded: settings_helper
INFO - 2018-03-23 19:21:00 --> Helper loaded: permission_helper
INFO - 2018-03-23 13:51:00 --> Security Class Initialized
INFO - 2018-03-23 19:21:00 --> Helper loaded: users_helper
INFO - 2018-03-23 13:51:00 --> Config Class Initialized
INFO - 2018-03-23 13:51:00 --> Hooks Class Initialized
DEBUG - 2018-03-23 13:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 13:51:00 --> Input Class Initialized
INFO - 2018-03-23 13:51:01 --> Language Class Initialized
DEBUG - 2018-03-23 13:51:01 --> UTF-8 Support Enabled
INFO - 2018-03-23 13:51:01 --> Utf8 Class Initialized
INFO - 2018-03-23 13:51:01 --> URI Class Initialized
INFO - 2018-03-23 13:51:01 --> Router Class Initialized
INFO - 2018-03-23 13:51:01 --> Output Class Initialized
INFO - 2018-03-23 19:21:01 --> Database Driver Class Initialized
DEBUG - 2018-03-23 19:21:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 19:21:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 13:51:01 --> Security Class Initialized
INFO - 2018-03-23 19:21:01 --> Helper loaded: form_helper
INFO - 2018-03-23 19:21:01 --> Form Validation Class Initialized
INFO - 2018-03-23 19:21:01 --> Controller Class Initialized
INFO - 2018-03-23 19:21:01 --> Model Class Initialized
DEBUG - 2018-03-23 13:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 19:21:02 --> Helper loaded: inflector_helper
INFO - 2018-03-23 13:51:02 --> Input Class Initialized
INFO - 2018-03-23 13:51:02 --> Language Class Initialized
DEBUG - 2018-03-23 19:21:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-23 13:51:02 --> Language Class Initialized
INFO - 2018-03-23 13:51:02 --> Config Class Initialized
INFO - 2018-03-23 13:51:02 --> Loader Class Initialized
INFO - 2018-03-23 19:21:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-23 19:21:02 --> Model Class Initialized
INFO - 2018-03-23 19:21:02 --> Model Class Initialized
INFO - 2018-03-23 19:21:02 --> Model Class Initialized
INFO - 2018-03-23 19:21:02 --> Model Class Initialized
INFO - 2018-03-23 19:21:02 --> Model Class Initialized
INFO - 2018-03-23 19:21:02 --> Helper loaded: url_helper
INFO - 2018-03-23 19:21:02 --> Model Class Initialized
INFO - 2018-03-23 19:21:02 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-23 19:21:02 --> Helper loaded: notification_helper
INFO - 2018-03-23 19:21:02 --> Helper loaded: settings_helper
INFO - 2018-03-23 19:21:02 --> Model Class Initialized
INFO - 2018-03-23 19:21:02 --> Helper loaded: permission_helper
INFO - 2018-03-23 19:21:02 --> Helper loaded: users_helper
INFO - 2018-03-23 19:21:02 --> Final output sent to browser
DEBUG - 2018-03-23 19:21:02 --> Total execution time: 2.4649
INFO - 2018-03-23 13:51:04 --> Language Class Initialized
INFO - 2018-03-23 13:51:04 --> Config Class Initialized
INFO - 2018-03-23 13:51:04 --> Loader Class Initialized
INFO - 2018-03-23 19:21:04 --> Database Driver Class Initialized
DEBUG - 2018-03-23 19:21:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 19:21:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 19:21:04 --> Helper loaded: url_helper
INFO - 2018-03-23 19:21:04 --> Helper loaded: form_helper
INFO - 2018-03-23 19:21:04 --> Form Validation Class Initialized
INFO - 2018-03-23 19:21:04 --> Controller Class Initialized
INFO - 2018-03-23 19:21:04 --> Helper loaded: notification_helper
INFO - 2018-03-23 19:21:04 --> Helper loaded: settings_helper
INFO - 2018-03-23 19:21:04 --> Helper loaded: permission_helper
INFO - 2018-03-23 19:21:04 --> Model Class Initialized
INFO - 2018-03-23 19:21:04 --> Helper loaded: inflector_helper
INFO - 2018-03-23 19:21:04 --> Helper loaded: users_helper
DEBUG - 2018-03-23 19:21:04 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-23 19:21:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-23 19:21:04 --> Model Class Initialized
INFO - 2018-03-23 19:21:04 --> Model Class Initialized
INFO - 2018-03-23 19:21:04 --> Model Class Initialized
INFO - 2018-03-23 19:21:04 --> Model Class Initialized
INFO - 2018-03-23 19:21:04 --> Model Class Initialized
INFO - 2018-03-23 19:21:04 --> Model Class Initialized
INFO - 2018-03-23 19:21:04 --> Model Class Initialized
INFO - 2018-03-23 19:21:04 --> Model Class Initialized
INFO - 2018-03-23 19:21:04 --> Model Class Initialized
INFO - 2018-03-23 19:21:04 --> Model Class Initialized
INFO - 2018-03-23 19:21:04 --> Model Class Initialized
INFO - 2018-03-23 19:21:04 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-23 19:21:04 --> Model Class Initialized
INFO - 2018-03-23 19:21:04 --> Final output sent to browser
DEBUG - 2018-03-23 19:21:04 --> Total execution time: 4.4043
INFO - 2018-03-23 19:21:05 --> Database Driver Class Initialized
DEBUG - 2018-03-23 19:21:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 19:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 19:21:05 --> Helper loaded: form_helper
INFO - 2018-03-23 19:21:05 --> Form Validation Class Initialized
INFO - 2018-03-23 19:21:05 --> Controller Class Initialized
INFO - 2018-03-23 19:21:05 --> Model Class Initialized
INFO - 2018-03-23 19:21:05 --> Helper loaded: inflector_helper
DEBUG - 2018-03-23 19:21:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-23 19:21:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-23 19:21:05 --> Model Class Initialized
INFO - 2018-03-23 19:21:05 --> Model Class Initialized
INFO - 2018-03-23 19:21:05 --> Model Class Initialized
INFO - 2018-03-23 19:21:05 --> Model Class Initialized
INFO - 2018-03-23 19:21:05 --> Model Class Initialized
INFO - 2018-03-23 19:21:05 --> Model Class Initialized
INFO - 2018-03-23 19:21:05 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-23 19:21:05 --> Final output sent to browser
DEBUG - 2018-03-23 19:21:05 --> Total execution time: 4.5282
INFO - 2018-03-23 13:51:09 --> Config Class Initialized
INFO - 2018-03-23 13:51:09 --> Hooks Class Initialized
DEBUG - 2018-03-23 13:51:10 --> UTF-8 Support Enabled
INFO - 2018-03-23 13:51:10 --> Utf8 Class Initialized
INFO - 2018-03-23 13:51:10 --> URI Class Initialized
INFO - 2018-03-23 13:51:10 --> Router Class Initialized
INFO - 2018-03-23 13:51:10 --> Output Class Initialized
INFO - 2018-03-23 13:51:10 --> Security Class Initialized
DEBUG - 2018-03-23 13:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 13:51:10 --> Input Class Initialized
INFO - 2018-03-23 13:51:10 --> Language Class Initialized
INFO - 2018-03-23 13:51:10 --> Language Class Initialized
INFO - 2018-03-23 13:51:10 --> Config Class Initialized
INFO - 2018-03-23 13:51:10 --> Loader Class Initialized
INFO - 2018-03-23 19:21:10 --> Helper loaded: url_helper
INFO - 2018-03-23 19:21:10 --> Helper loaded: notification_helper
INFO - 2018-03-23 19:21:10 --> Helper loaded: settings_helper
INFO - 2018-03-23 19:21:10 --> Helper loaded: permission_helper
INFO - 2018-03-23 19:21:10 --> Helper loaded: users_helper
INFO - 2018-03-23 19:21:10 --> Database Driver Class Initialized
DEBUG - 2018-03-23 19:21:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 19:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 19:21:10 --> Helper loaded: form_helper
INFO - 2018-03-23 19:21:10 --> Form Validation Class Initialized
INFO - 2018-03-23 19:21:10 --> Controller Class Initialized
INFO - 2018-03-23 19:21:10 --> Model Class Initialized
INFO - 2018-03-23 19:21:10 --> Helper loaded: inflector_helper
DEBUG - 2018-03-23 19:21:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-23 19:21:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-23 19:21:10 --> Model Class Initialized
INFO - 2018-03-23 19:21:10 --> Model Class Initialized
INFO - 2018-03-23 19:21:10 --> Model Class Initialized
INFO - 2018-03-23 19:21:10 --> Model Class Initialized
INFO - 2018-03-23 19:21:10 --> Model Class Initialized
INFO - 2018-03-23 19:21:10 --> Model Class Initialized
INFO - 2018-03-23 19:21:10 --> Model Class Initialized
INFO - 2018-03-23 19:21:10 --> Model Class Initialized
INFO - 2018-03-23 19:21:10 --> Model Class Initialized
INFO - 2018-03-23 19:21:10 --> Model Class Initialized
INFO - 2018-03-23 19:21:10 --> Model Class Initialized
INFO - 2018-03-23 19:21:10 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-23 19:21:10 --> Model Class Initialized
INFO - 2018-03-23 19:21:10 --> Final output sent to browser
DEBUG - 2018-03-23 19:21:10 --> Total execution time: 0.7845
INFO - 2018-03-23 13:51:12 --> Config Class Initialized
INFO - 2018-03-23 13:51:12 --> Hooks Class Initialized
DEBUG - 2018-03-23 13:51:13 --> UTF-8 Support Enabled
INFO - 2018-03-23 13:51:13 --> Utf8 Class Initialized
INFO - 2018-03-23 13:51:13 --> URI Class Initialized
INFO - 2018-03-23 13:51:13 --> Router Class Initialized
INFO - 2018-03-23 13:51:13 --> Output Class Initialized
INFO - 2018-03-23 13:51:14 --> Security Class Initialized
DEBUG - 2018-03-23 13:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 13:51:14 --> Input Class Initialized
INFO - 2018-03-23 13:51:14 --> Language Class Initialized
INFO - 2018-03-23 13:51:15 --> Language Class Initialized
INFO - 2018-03-23 13:51:15 --> Config Class Initialized
INFO - 2018-03-23 13:51:15 --> Loader Class Initialized
INFO - 2018-03-23 19:21:15 --> Helper loaded: url_helper
INFO - 2018-03-23 19:21:15 --> Helper loaded: notification_helper
INFO - 2018-03-23 19:21:15 --> Helper loaded: settings_helper
INFO - 2018-03-23 19:21:15 --> Helper loaded: permission_helper
INFO - 2018-03-23 19:21:15 --> Helper loaded: users_helper
INFO - 2018-03-23 19:21:15 --> Database Driver Class Initialized
DEBUG - 2018-03-23 19:21:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 19:21:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 19:21:16 --> Helper loaded: form_helper
INFO - 2018-03-23 19:21:16 --> Form Validation Class Initialized
INFO - 2018-03-23 19:21:16 --> Controller Class Initialized
INFO - 2018-03-23 19:21:16 --> Model Class Initialized
INFO - 2018-03-23 19:21:16 --> Helper loaded: inflector_helper
DEBUG - 2018-03-23 19:21:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-23 19:21:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-23 19:21:16 --> Model Class Initialized
INFO - 2018-03-23 19:21:16 --> Model Class Initialized
INFO - 2018-03-23 19:21:16 --> Model Class Initialized
INFO - 2018-03-23 19:21:16 --> Model Class Initialized
INFO - 2018-03-23 19:21:16 --> Final output sent to browser
DEBUG - 2018-03-23 19:21:16 --> Total execution time: 3.9488
INFO - 2018-03-23 13:51:36 --> Config Class Initialized
INFO - 2018-03-23 13:51:36 --> Hooks Class Initialized
DEBUG - 2018-03-23 13:51:37 --> UTF-8 Support Enabled
INFO - 2018-03-23 13:51:37 --> Utf8 Class Initialized
INFO - 2018-03-23 13:51:37 --> URI Class Initialized
INFO - 2018-03-23 13:51:37 --> Router Class Initialized
INFO - 2018-03-23 13:51:37 --> Output Class Initialized
INFO - 2018-03-23 13:51:37 --> Security Class Initialized
DEBUG - 2018-03-23 13:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 13:51:37 --> Input Class Initialized
INFO - 2018-03-23 13:51:37 --> Language Class Initialized
INFO - 2018-03-23 13:51:37 --> Language Class Initialized
INFO - 2018-03-23 13:51:37 --> Config Class Initialized
INFO - 2018-03-23 13:51:37 --> Loader Class Initialized
INFO - 2018-03-23 19:21:37 --> Helper loaded: url_helper
INFO - 2018-03-23 19:21:37 --> Helper loaded: notification_helper
INFO - 2018-03-23 19:21:37 --> Helper loaded: settings_helper
INFO - 2018-03-23 19:21:37 --> Helper loaded: permission_helper
INFO - 2018-03-23 19:21:37 --> Helper loaded: users_helper
INFO - 2018-03-23 19:21:37 --> Database Driver Class Initialized
DEBUG - 2018-03-23 19:21:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 19:21:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 19:21:37 --> Helper loaded: form_helper
INFO - 2018-03-23 19:21:37 --> Form Validation Class Initialized
INFO - 2018-03-23 19:21:37 --> Controller Class Initialized
INFO - 2018-03-23 19:21:37 --> Model Class Initialized
INFO - 2018-03-23 19:21:37 --> Helper loaded: inflector_helper
DEBUG - 2018-03-23 19:21:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-23 19:21:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-23 19:21:37 --> Model Class Initialized
INFO - 2018-03-23 19:21:37 --> Model Class Initialized
INFO - 2018-03-23 19:21:37 --> Model Class Initialized
INFO - 2018-03-23 19:21:37 --> Model Class Initialized
INFO - 2018-03-23 19:21:37 --> Final output sent to browser
DEBUG - 2018-03-23 19:21:37 --> Total execution time: 0.3579
INFO - 2018-03-23 13:51:39 --> Config Class Initialized
INFO - 2018-03-23 13:51:39 --> Hooks Class Initialized
DEBUG - 2018-03-23 13:51:39 --> UTF-8 Support Enabled
INFO - 2018-03-23 13:51:39 --> Utf8 Class Initialized
INFO - 2018-03-23 13:51:39 --> URI Class Initialized
INFO - 2018-03-23 13:51:39 --> Router Class Initialized
INFO - 2018-03-23 13:51:39 --> Output Class Initialized
INFO - 2018-03-23 13:51:39 --> Security Class Initialized
DEBUG - 2018-03-23 13:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 13:51:39 --> Input Class Initialized
INFO - 2018-03-23 13:51:39 --> Language Class Initialized
INFO - 2018-03-23 13:51:39 --> Language Class Initialized
INFO - 2018-03-23 13:51:39 --> Config Class Initialized
INFO - 2018-03-23 13:51:39 --> Loader Class Initialized
INFO - 2018-03-23 19:21:39 --> Helper loaded: url_helper
INFO - 2018-03-23 19:21:39 --> Helper loaded: notification_helper
INFO - 2018-03-23 19:21:39 --> Helper loaded: settings_helper
INFO - 2018-03-23 19:21:39 --> Helper loaded: permission_helper
INFO - 2018-03-23 19:21:39 --> Helper loaded: users_helper
INFO - 2018-03-23 19:21:39 --> Database Driver Class Initialized
DEBUG - 2018-03-23 19:21:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 19:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 19:21:39 --> Helper loaded: form_helper
INFO - 2018-03-23 19:21:39 --> Form Validation Class Initialized
INFO - 2018-03-23 19:21:39 --> Controller Class Initialized
INFO - 2018-03-23 19:21:39 --> Model Class Initialized
INFO - 2018-03-23 19:21:39 --> Helper loaded: inflector_helper
DEBUG - 2018-03-23 19:21:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-23 19:21:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-23 19:21:39 --> Model Class Initialized
INFO - 2018-03-23 19:21:39 --> Model Class Initialized
INFO - 2018-03-23 19:21:39 --> Model Class Initialized
INFO - 2018-03-23 19:21:39 --> Model Class Initialized
INFO - 2018-03-23 19:21:39 --> Final output sent to browser
DEBUG - 2018-03-23 19:21:39 --> Total execution time: 0.2169
INFO - 2018-03-23 13:51:46 --> Config Class Initialized
INFO - 2018-03-23 13:51:46 --> Hooks Class Initialized
DEBUG - 2018-03-23 13:51:46 --> UTF-8 Support Enabled
INFO - 2018-03-23 13:51:46 --> Utf8 Class Initialized
INFO - 2018-03-23 13:51:46 --> URI Class Initialized
INFO - 2018-03-23 13:51:47 --> Router Class Initialized
INFO - 2018-03-23 13:51:47 --> Output Class Initialized
INFO - 2018-03-23 13:51:47 --> Config Class Initialized
INFO - 2018-03-23 13:51:47 --> Hooks Class Initialized
INFO - 2018-03-23 13:51:47 --> Security Class Initialized
DEBUG - 2018-03-23 13:51:47 --> UTF-8 Support Enabled
INFO - 2018-03-23 13:51:47 --> Utf8 Class Initialized
DEBUG - 2018-03-23 13:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 13:51:47 --> Input Class Initialized
INFO - 2018-03-23 13:51:47 --> URI Class Initialized
INFO - 2018-03-23 13:51:47 --> Language Class Initialized
INFO - 2018-03-23 13:51:47 --> Language Class Initialized
INFO - 2018-03-23 13:51:47 --> Config Class Initialized
INFO - 2018-03-23 13:51:47 --> Loader Class Initialized
INFO - 2018-03-23 19:21:47 --> Helper loaded: url_helper
INFO - 2018-03-23 19:21:47 --> Helper loaded: notification_helper
INFO - 2018-03-23 19:21:47 --> Helper loaded: settings_helper
INFO - 2018-03-23 19:21:47 --> Helper loaded: permission_helper
INFO - 2018-03-23 19:21:47 --> Helper loaded: users_helper
INFO - 2018-03-23 19:21:47 --> Database Driver Class Initialized
DEBUG - 2018-03-23 19:21:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 19:21:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 19:21:47 --> Helper loaded: form_helper
INFO - 2018-03-23 19:21:47 --> Form Validation Class Initialized
INFO - 2018-03-23 19:21:47 --> Controller Class Initialized
INFO - 2018-03-23 19:21:47 --> Model Class Initialized
INFO - 2018-03-23 19:21:47 --> Helper loaded: inflector_helper
DEBUG - 2018-03-23 19:21:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-23 19:21:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-23 19:21:47 --> Model Class Initialized
INFO - 2018-03-23 19:21:47 --> Model Class Initialized
INFO - 2018-03-23 19:21:47 --> Model Class Initialized
INFO - 2018-03-23 19:21:47 --> Model Class Initialized
INFO - 2018-03-23 19:21:47 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-23 19:21:47 --> Final output sent to browser
DEBUG - 2018-03-23 19:21:47 --> Total execution time: 1.0535
INFO - 2018-03-23 13:51:47 --> Router Class Initialized
INFO - 2018-03-23 13:51:48 --> Output Class Initialized
INFO - 2018-03-23 13:51:48 --> Security Class Initialized
DEBUG - 2018-03-23 13:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 13:51:48 --> Input Class Initialized
INFO - 2018-03-23 13:51:48 --> Language Class Initialized
INFO - 2018-03-23 13:51:49 --> Language Class Initialized
INFO - 2018-03-23 13:51:49 --> Config Class Initialized
INFO - 2018-03-23 13:51:49 --> Loader Class Initialized
INFO - 2018-03-23 19:21:49 --> Helper loaded: url_helper
INFO - 2018-03-23 19:21:50 --> Helper loaded: notification_helper
INFO - 2018-03-23 19:21:50 --> Helper loaded: settings_helper
INFO - 2018-03-23 19:21:50 --> Helper loaded: permission_helper
INFO - 2018-03-23 19:21:50 --> Helper loaded: users_helper
INFO - 2018-03-23 19:21:51 --> Database Driver Class Initialized
DEBUG - 2018-03-23 19:21:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 19:21:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 19:21:52 --> Helper loaded: form_helper
INFO - 2018-03-23 19:21:52 --> Form Validation Class Initialized
INFO - 2018-03-23 19:21:52 --> Controller Class Initialized
INFO - 2018-03-23 19:21:52 --> Model Class Initialized
INFO - 2018-03-23 19:21:52 --> Helper loaded: inflector_helper
DEBUG - 2018-03-23 19:21:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-23 13:51:52 --> Config Class Initialized
INFO - 2018-03-23 13:51:52 --> Hooks Class Initialized
DEBUG - 2018-03-23 13:51:52 --> UTF-8 Support Enabled
INFO - 2018-03-23 13:51:52 --> Utf8 Class Initialized
INFO - 2018-03-23 13:51:52 --> URI Class Initialized
INFO - 2018-03-23 13:51:52 --> Router Class Initialized
INFO - 2018-03-23 13:51:52 --> Output Class Initialized
INFO - 2018-03-23 13:51:52 --> Security Class Initialized
DEBUG - 2018-03-23 13:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 13:51:52 --> Input Class Initialized
INFO - 2018-03-23 13:51:52 --> Language Class Initialized
INFO - 2018-03-23 19:21:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-23 13:51:53 --> Language Class Initialized
INFO - 2018-03-23 13:51:53 --> Config Class Initialized
INFO - 2018-03-23 13:51:53 --> Loader Class Initialized
INFO - 2018-03-23 19:21:53 --> Helper loaded: url_helper
INFO - 2018-03-23 19:21:53 --> Helper loaded: notification_helper
INFO - 2018-03-23 19:21:53 --> Helper loaded: settings_helper
INFO - 2018-03-23 19:21:53 --> Helper loaded: permission_helper
INFO - 2018-03-23 19:21:53 --> Helper loaded: users_helper
INFO - 2018-03-23 19:21:53 --> Database Driver Class Initialized
DEBUG - 2018-03-23 19:21:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 19:21:53 --> Model Class Initialized
INFO - 2018-03-23 19:21:53 --> Model Class Initialized
INFO - 2018-03-23 19:21:53 --> Model Class Initialized
INFO - 2018-03-23 19:21:53 --> Model Class Initialized
INFO - 2018-03-23 19:21:53 --> Model Class Initialized
INFO - 2018-03-23 19:21:53 --> Model Class Initialized
INFO - 2018-03-23 19:21:53 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-23 19:21:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-03-23 19:21:53 --> Final output sent to browser
DEBUG - 2018-03-23 19:21:53 --> Total execution time: 6.7551
INFO - 2018-03-23 19:21:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 19:21:53 --> Helper loaded: form_helper
INFO - 2018-03-23 19:21:53 --> Form Validation Class Initialized
INFO - 2018-03-23 19:21:53 --> Controller Class Initialized
INFO - 2018-03-23 19:21:53 --> Model Class Initialized
INFO - 2018-03-23 19:21:53 --> Helper loaded: inflector_helper
DEBUG - 2018-03-23 19:21:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-23 19:21:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-23 19:21:53 --> Model Class Initialized
INFO - 2018-03-23 19:21:53 --> Model Class Initialized
INFO - 2018-03-23 19:21:53 --> Model Class Initialized
INFO - 2018-03-23 19:21:53 --> Model Class Initialized
INFO - 2018-03-23 19:21:53 --> Model Class Initialized
INFO - 2018-03-23 19:21:53 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-23 19:21:53 --> Model Class Initialized
INFO - 2018-03-23 19:21:53 --> Final output sent to browser
DEBUG - 2018-03-23 19:21:53 --> Total execution time: 0.7611
INFO - 2018-03-23 13:51:54 --> Config Class Initialized
INFO - 2018-03-23 13:51:54 --> Hooks Class Initialized
DEBUG - 2018-03-23 13:51:54 --> UTF-8 Support Enabled
INFO - 2018-03-23 13:51:54 --> Utf8 Class Initialized
INFO - 2018-03-23 13:51:54 --> URI Class Initialized
INFO - 2018-03-23 13:51:54 --> Router Class Initialized
INFO - 2018-03-23 13:51:54 --> Output Class Initialized
INFO - 2018-03-23 13:51:54 --> Security Class Initialized
DEBUG - 2018-03-23 13:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 13:51:54 --> Input Class Initialized
INFO - 2018-03-23 13:51:54 --> Language Class Initialized
INFO - 2018-03-23 13:51:54 --> Language Class Initialized
INFO - 2018-03-23 13:51:54 --> Config Class Initialized
INFO - 2018-03-23 13:51:54 --> Loader Class Initialized
INFO - 2018-03-23 19:21:54 --> Helper loaded: url_helper
INFO - 2018-03-23 19:21:54 --> Helper loaded: notification_helper
INFO - 2018-03-23 19:21:54 --> Helper loaded: settings_helper
INFO - 2018-03-23 19:21:54 --> Helper loaded: permission_helper
INFO - 2018-03-23 19:21:54 --> Helper loaded: users_helper
INFO - 2018-03-23 19:21:54 --> Database Driver Class Initialized
DEBUG - 2018-03-23 19:21:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 19:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 19:21:54 --> Helper loaded: form_helper
INFO - 2018-03-23 19:21:54 --> Form Validation Class Initialized
INFO - 2018-03-23 19:21:54 --> Controller Class Initialized
INFO - 2018-03-23 19:21:54 --> Model Class Initialized
INFO - 2018-03-23 19:21:54 --> Helper loaded: inflector_helper
DEBUG - 2018-03-23 19:21:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-23 19:21:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-23 19:21:54 --> Model Class Initialized
INFO - 2018-03-23 19:21:54 --> Model Class Initialized
INFO - 2018-03-23 19:21:54 --> Model Class Initialized
INFO - 2018-03-23 19:21:54 --> Model Class Initialized
INFO - 2018-03-23 19:21:54 --> Model Class Initialized
INFO - 2018-03-23 19:21:54 --> Model Class Initialized
INFO - 2018-03-23 19:21:54 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-23 19:21:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-03-23 19:21:54 --> Final output sent to browser
DEBUG - 2018-03-23 19:21:54 --> Total execution time: 0.7198
INFO - 2018-03-23 13:51:59 --> Config Class Initialized
INFO - 2018-03-23 13:51:59 --> Hooks Class Initialized
DEBUG - 2018-03-23 13:52:00 --> UTF-8 Support Enabled
INFO - 2018-03-23 13:52:00 --> Utf8 Class Initialized
INFO - 2018-03-23 13:52:00 --> URI Class Initialized
INFO - 2018-03-23 13:52:01 --> Router Class Initialized
INFO - 2018-03-23 13:52:01 --> Output Class Initialized
INFO - 2018-03-23 13:52:01 --> Security Class Initialized
DEBUG - 2018-03-23 13:52:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 13:52:01 --> Input Class Initialized
INFO - 2018-03-23 13:52:01 --> Language Class Initialized
INFO - 2018-03-23 13:52:02 --> Language Class Initialized
INFO - 2018-03-23 13:52:02 --> Config Class Initialized
INFO - 2018-03-23 13:52:02 --> Loader Class Initialized
INFO - 2018-03-23 19:22:02 --> Helper loaded: url_helper
INFO - 2018-03-23 19:22:02 --> Helper loaded: notification_helper
INFO - 2018-03-23 19:22:02 --> Helper loaded: settings_helper
INFO - 2018-03-23 19:22:02 --> Helper loaded: permission_helper
INFO - 2018-03-23 19:22:02 --> Helper loaded: users_helper
INFO - 2018-03-23 19:22:03 --> Database Driver Class Initialized
DEBUG - 2018-03-23 19:22:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 19:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 19:22:03 --> Helper loaded: form_helper
INFO - 2018-03-23 19:22:03 --> Form Validation Class Initialized
INFO - 2018-03-23 19:22:03 --> Controller Class Initialized
INFO - 2018-03-23 19:22:03 --> Model Class Initialized
INFO - 2018-03-23 19:22:03 --> Helper loaded: inflector_helper
DEBUG - 2018-03-23 19:22:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-23 19:22:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-23 19:22:03 --> Model Class Initialized
INFO - 2018-03-23 19:22:03 --> Model Class Initialized
INFO - 2018-03-23 19:22:03 --> Model Class Initialized
INFO - 2018-03-23 19:22:03 --> Model Class Initialized
INFO - 2018-03-23 19:22:03 --> Model Class Initialized
INFO - 2018-03-23 19:22:03 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-23 19:22:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-23 19:22:03 --> Final output sent to browser
DEBUG - 2018-03-23 19:22:03 --> Total execution time: 4.1794
INFO - 2018-03-23 13:52:06 --> Config Class Initialized
INFO - 2018-03-23 13:52:06 --> Hooks Class Initialized
DEBUG - 2018-03-23 13:52:06 --> UTF-8 Support Enabled
INFO - 2018-03-23 13:52:06 --> Utf8 Class Initialized
INFO - 2018-03-23 13:52:06 --> URI Class Initialized
INFO - 2018-03-23 13:52:06 --> Router Class Initialized
INFO - 2018-03-23 13:52:06 --> Output Class Initialized
INFO - 2018-03-23 13:52:06 --> Security Class Initialized
DEBUG - 2018-03-23 13:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 13:52:06 --> Input Class Initialized
INFO - 2018-03-23 13:52:06 --> Language Class Initialized
INFO - 2018-03-23 13:52:06 --> Language Class Initialized
INFO - 2018-03-23 13:52:06 --> Config Class Initialized
INFO - 2018-03-23 13:52:06 --> Loader Class Initialized
INFO - 2018-03-23 19:22:06 --> Helper loaded: url_helper
INFO - 2018-03-23 19:22:06 --> Helper loaded: notification_helper
INFO - 2018-03-23 19:22:06 --> Helper loaded: settings_helper
INFO - 2018-03-23 19:22:06 --> Helper loaded: permission_helper
INFO - 2018-03-23 19:22:06 --> Helper loaded: users_helper
INFO - 2018-03-23 19:22:06 --> Database Driver Class Initialized
DEBUG - 2018-03-23 19:22:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 19:22:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 19:22:07 --> Helper loaded: form_helper
INFO - 2018-03-23 19:22:07 --> Form Validation Class Initialized
INFO - 2018-03-23 19:22:07 --> Controller Class Initialized
INFO - 2018-03-23 19:22:08 --> Model Class Initialized
INFO - 2018-03-23 19:22:08 --> Helper loaded: inflector_helper
DEBUG - 2018-03-23 19:22:08 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-23 19:22:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-23 19:22:08 --> Model Class Initialized
INFO - 2018-03-23 19:22:08 --> Model Class Initialized
INFO - 2018-03-23 19:22:08 --> Model Class Initialized
INFO - 2018-03-23 19:22:08 --> Model Class Initialized
INFO - 2018-03-23 19:22:08 --> Model Class Initialized
INFO - 2018-03-23 19:22:08 --> Model Class Initialized
INFO - 2018-03-23 19:22:08 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-23 19:22:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-03-23 19:22:08 --> Final output sent to browser
DEBUG - 2018-03-23 19:22:08 --> Total execution time: 1.9800
INFO - 2018-03-23 13:52:16 --> Config Class Initialized
INFO - 2018-03-23 13:52:16 --> Hooks Class Initialized
DEBUG - 2018-03-23 13:52:16 --> UTF-8 Support Enabled
INFO - 2018-03-23 13:52:16 --> Utf8 Class Initialized
INFO - 2018-03-23 13:52:16 --> URI Class Initialized
INFO - 2018-03-23 13:52:16 --> Router Class Initialized
INFO - 2018-03-23 13:52:16 --> Output Class Initialized
INFO - 2018-03-23 13:52:16 --> Security Class Initialized
DEBUG - 2018-03-23 13:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 13:52:16 --> Input Class Initialized
INFO - 2018-03-23 13:52:16 --> Language Class Initialized
INFO - 2018-03-23 13:52:17 --> Language Class Initialized
INFO - 2018-03-23 13:52:17 --> Config Class Initialized
INFO - 2018-03-23 13:52:17 --> Loader Class Initialized
INFO - 2018-03-23 19:22:17 --> Helper loaded: url_helper
INFO - 2018-03-23 19:22:17 --> Helper loaded: notification_helper
INFO - 2018-03-23 19:22:17 --> Helper loaded: settings_helper
INFO - 2018-03-23 19:22:17 --> Helper loaded: permission_helper
INFO - 2018-03-23 19:22:17 --> Helper loaded: users_helper
INFO - 2018-03-23 19:22:17 --> Database Driver Class Initialized
DEBUG - 2018-03-23 19:22:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 19:22:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 19:22:17 --> Helper loaded: form_helper
INFO - 2018-03-23 19:22:17 --> Form Validation Class Initialized
INFO - 2018-03-23 19:22:17 --> Controller Class Initialized
INFO - 2018-03-23 19:22:17 --> Model Class Initialized
INFO - 2018-03-23 19:22:17 --> Helper loaded: inflector_helper
DEBUG - 2018-03-23 19:22:17 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-23 19:22:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-23 19:22:17 --> Model Class Initialized
INFO - 2018-03-23 19:22:17 --> Model Class Initialized
INFO - 2018-03-23 19:22:17 --> Model Class Initialized
INFO - 2018-03-23 19:22:17 --> Model Class Initialized
INFO - 2018-03-23 19:22:17 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-23 19:22:17 --> Final output sent to browser
DEBUG - 2018-03-23 19:22:17 --> Total execution time: 1.2514
INFO - 2018-03-23 13:52:17 --> Config Class Initialized
INFO - 2018-03-23 13:52:17 --> Hooks Class Initialized
DEBUG - 2018-03-23 13:52:17 --> UTF-8 Support Enabled
INFO - 2018-03-23 13:52:17 --> Utf8 Class Initialized
INFO - 2018-03-23 13:52:17 --> URI Class Initialized
INFO - 2018-03-23 13:52:17 --> Router Class Initialized
INFO - 2018-03-23 13:52:17 --> Output Class Initialized
INFO - 2018-03-23 13:52:17 --> Security Class Initialized
DEBUG - 2018-03-23 13:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 13:52:17 --> Input Class Initialized
INFO - 2018-03-23 13:52:18 --> Language Class Initialized
INFO - 2018-03-23 13:52:18 --> Language Class Initialized
INFO - 2018-03-23 13:52:18 --> Config Class Initialized
INFO - 2018-03-23 13:52:18 --> Loader Class Initialized
INFO - 2018-03-23 19:22:18 --> Helper loaded: url_helper
INFO - 2018-03-23 19:22:18 --> Helper loaded: notification_helper
INFO - 2018-03-23 19:22:18 --> Helper loaded: settings_helper
INFO - 2018-03-23 19:22:18 --> Helper loaded: permission_helper
INFO - 2018-03-23 19:22:18 --> Helper loaded: users_helper
INFO - 2018-03-23 19:22:18 --> Database Driver Class Initialized
DEBUG - 2018-03-23 19:22:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 19:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 19:22:18 --> Helper loaded: form_helper
INFO - 2018-03-23 19:22:18 --> Form Validation Class Initialized
INFO - 2018-03-23 19:22:18 --> Controller Class Initialized
INFO - 2018-03-23 19:22:18 --> Model Class Initialized
INFO - 2018-03-23 19:22:18 --> Helper loaded: inflector_helper
DEBUG - 2018-03-23 19:22:18 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-23 19:22:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-23 19:22:18 --> Model Class Initialized
INFO - 2018-03-23 19:22:18 --> Model Class Initialized
INFO - 2018-03-23 19:22:18 --> Model Class Initialized
INFO - 2018-03-23 19:22:18 --> Model Class Initialized
INFO - 2018-03-23 19:22:18 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-23 19:22:18 --> Final output sent to browser
DEBUG - 2018-03-23 19:22:18 --> Total execution time: 0.8450
INFO - 2018-03-23 13:52:21 --> Config Class Initialized
INFO - 2018-03-23 13:52:21 --> Hooks Class Initialized
DEBUG - 2018-03-23 13:52:21 --> UTF-8 Support Enabled
INFO - 2018-03-23 13:52:21 --> Utf8 Class Initialized
INFO - 2018-03-23 13:52:21 --> URI Class Initialized
INFO - 2018-03-23 13:52:21 --> Router Class Initialized
INFO - 2018-03-23 13:52:21 --> Output Class Initialized
INFO - 2018-03-23 13:52:21 --> Security Class Initialized
DEBUG - 2018-03-23 13:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 13:52:21 --> Input Class Initialized
INFO - 2018-03-23 13:52:21 --> Language Class Initialized
INFO - 2018-03-23 13:52:21 --> Language Class Initialized
INFO - 2018-03-23 13:52:21 --> Config Class Initialized
INFO - 2018-03-23 13:52:21 --> Loader Class Initialized
INFO - 2018-03-23 19:22:21 --> Helper loaded: url_helper
INFO - 2018-03-23 19:22:21 --> Helper loaded: notification_helper
INFO - 2018-03-23 19:22:21 --> Helper loaded: settings_helper
INFO - 2018-03-23 19:22:21 --> Helper loaded: permission_helper
INFO - 2018-03-23 19:22:21 --> Helper loaded: users_helper
INFO - 2018-03-23 19:22:21 --> Database Driver Class Initialized
DEBUG - 2018-03-23 19:22:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 19:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 19:22:21 --> Helper loaded: form_helper
INFO - 2018-03-23 19:22:21 --> Form Validation Class Initialized
INFO - 2018-03-23 19:22:21 --> Controller Class Initialized
INFO - 2018-03-23 19:22:21 --> Model Class Initialized
INFO - 2018-03-23 19:22:21 --> Helper loaded: inflector_helper
DEBUG - 2018-03-23 19:22:21 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-23 19:22:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-23 19:22:21 --> Model Class Initialized
INFO - 2018-03-23 19:22:21 --> Model Class Initialized
INFO - 2018-03-23 19:22:21 --> Model Class Initialized
INFO - 2018-03-23 19:22:21 --> Model Class Initialized
INFO - 2018-03-23 19:22:21 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-23 19:22:21 --> Final output sent to browser
DEBUG - 2018-03-23 19:22:21 --> Total execution time: 0.2142
INFO - 2018-03-23 13:52:23 --> Config Class Initialized
INFO - 2018-03-23 13:52:23 --> Hooks Class Initialized
DEBUG - 2018-03-23 13:52:23 --> UTF-8 Support Enabled
INFO - 2018-03-23 13:52:23 --> Utf8 Class Initialized
INFO - 2018-03-23 13:52:23 --> URI Class Initialized
INFO - 2018-03-23 13:52:23 --> Router Class Initialized
INFO - 2018-03-23 13:52:23 --> Output Class Initialized
INFO - 2018-03-23 13:52:23 --> Security Class Initialized
DEBUG - 2018-03-23 13:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 13:52:23 --> Input Class Initialized
INFO - 2018-03-23 13:52:23 --> Language Class Initialized
INFO - 2018-03-23 13:52:24 --> Language Class Initialized
INFO - 2018-03-23 13:52:24 --> Config Class Initialized
INFO - 2018-03-23 13:52:24 --> Loader Class Initialized
INFO - 2018-03-23 19:22:24 --> Helper loaded: url_helper
INFO - 2018-03-23 19:22:24 --> Helper loaded: notification_helper
INFO - 2018-03-23 19:22:24 --> Helper loaded: settings_helper
INFO - 2018-03-23 19:22:24 --> Helper loaded: permission_helper
INFO - 2018-03-23 19:22:24 --> Helper loaded: users_helper
INFO - 2018-03-23 19:22:25 --> Database Driver Class Initialized
DEBUG - 2018-03-23 19:22:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 19:22:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 19:22:25 --> Helper loaded: form_helper
INFO - 2018-03-23 19:22:25 --> Form Validation Class Initialized
INFO - 2018-03-23 19:22:25 --> Controller Class Initialized
INFO - 2018-03-23 19:22:25 --> Model Class Initialized
INFO - 2018-03-23 19:22:25 --> Helper loaded: inflector_helper
DEBUG - 2018-03-23 19:22:25 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-23 19:22:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-23 19:22:25 --> Model Class Initialized
INFO - 2018-03-23 19:22:25 --> Model Class Initialized
INFO - 2018-03-23 19:22:25 --> Model Class Initialized
INFO - 2018-03-23 19:22:25 --> Model Class Initialized
INFO - 2018-03-23 19:22:25 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-23 19:22:25 --> Final output sent to browser
DEBUG - 2018-03-23 19:22:25 --> Total execution time: 2.0563
INFO - 2018-03-23 13:52:29 --> Config Class Initialized
INFO - 2018-03-23 13:52:29 --> Hooks Class Initialized
DEBUG - 2018-03-23 13:52:29 --> UTF-8 Support Enabled
INFO - 2018-03-23 13:52:29 --> Utf8 Class Initialized
INFO - 2018-03-23 13:52:29 --> URI Class Initialized
INFO - 2018-03-23 13:52:29 --> Router Class Initialized
INFO - 2018-03-23 13:52:30 --> Output Class Initialized
INFO - 2018-03-23 13:52:30 --> Security Class Initialized
DEBUG - 2018-03-23 13:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 13:52:30 --> Input Class Initialized
INFO - 2018-03-23 13:52:30 --> Language Class Initialized
INFO - 2018-03-23 13:52:30 --> Language Class Initialized
INFO - 2018-03-23 13:52:30 --> Config Class Initialized
INFO - 2018-03-23 13:52:30 --> Loader Class Initialized
INFO - 2018-03-23 19:22:31 --> Helper loaded: url_helper
INFO - 2018-03-23 19:22:31 --> Helper loaded: notification_helper
INFO - 2018-03-23 19:22:31 --> Helper loaded: settings_helper
INFO - 2018-03-23 19:22:31 --> Helper loaded: permission_helper
INFO - 2018-03-23 19:22:31 --> Helper loaded: users_helper
INFO - 2018-03-23 19:22:32 --> Database Driver Class Initialized
DEBUG - 2018-03-23 19:22:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 19:22:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 19:22:32 --> Helper loaded: form_helper
INFO - 2018-03-23 19:22:32 --> Form Validation Class Initialized
INFO - 2018-03-23 19:22:32 --> Controller Class Initialized
INFO - 2018-03-23 19:22:32 --> Model Class Initialized
INFO - 2018-03-23 19:22:32 --> Helper loaded: inflector_helper
DEBUG - 2018-03-23 19:22:32 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-23 19:22:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-23 19:22:32 --> Model Class Initialized
INFO - 2018-03-23 19:22:32 --> Model Class Initialized
INFO - 2018-03-23 19:22:32 --> Model Class Initialized
INFO - 2018-03-23 19:22:32 --> Model Class Initialized
INFO - 2018-03-23 19:22:32 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-23 19:22:32 --> Final output sent to browser
DEBUG - 2018-03-23 19:22:32 --> Total execution time: 2.9885
INFO - 2018-03-23 13:52:33 --> Config Class Initialized
INFO - 2018-03-23 13:52:33 --> Hooks Class Initialized
DEBUG - 2018-03-23 13:52:34 --> UTF-8 Support Enabled
INFO - 2018-03-23 13:52:34 --> Utf8 Class Initialized
INFO - 2018-03-23 13:52:34 --> URI Class Initialized
INFO - 2018-03-23 13:52:34 --> Router Class Initialized
INFO - 2018-03-23 13:52:34 --> Output Class Initialized
INFO - 2018-03-23 13:52:34 --> Security Class Initialized
DEBUG - 2018-03-23 13:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 13:52:34 --> Input Class Initialized
INFO - 2018-03-23 13:52:34 --> Language Class Initialized
INFO - 2018-03-23 13:52:35 --> Language Class Initialized
INFO - 2018-03-23 13:52:35 --> Config Class Initialized
INFO - 2018-03-23 13:52:35 --> Loader Class Initialized
INFO - 2018-03-23 19:22:35 --> Helper loaded: url_helper
INFO - 2018-03-23 19:22:35 --> Helper loaded: notification_helper
INFO - 2018-03-23 19:22:35 --> Helper loaded: settings_helper
INFO - 2018-03-23 19:22:35 --> Helper loaded: permission_helper
INFO - 2018-03-23 19:22:35 --> Helper loaded: users_helper
INFO - 2018-03-23 19:22:35 --> Database Driver Class Initialized
DEBUG - 2018-03-23 19:22:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 19:22:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 19:22:35 --> Helper loaded: form_helper
INFO - 2018-03-23 19:22:35 --> Form Validation Class Initialized
INFO - 2018-03-23 19:22:35 --> Controller Class Initialized
INFO - 2018-03-23 19:22:35 --> Model Class Initialized
INFO - 2018-03-23 19:22:35 --> Helper loaded: inflector_helper
DEBUG - 2018-03-23 19:22:35 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-23 19:22:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-23 19:22:35 --> Model Class Initialized
INFO - 2018-03-23 19:22:35 --> Model Class Initialized
INFO - 2018-03-23 19:22:35 --> Model Class Initialized
INFO - 2018-03-23 19:22:35 --> Model Class Initialized
INFO - 2018-03-23 19:22:35 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-23 19:22:35 --> Final output sent to browser
DEBUG - 2018-03-23 19:22:35 --> Total execution time: 2.1386
INFO - 2018-03-23 13:52:39 --> Config Class Initialized
INFO - 2018-03-23 13:52:39 --> Hooks Class Initialized
DEBUG - 2018-03-23 13:52:39 --> UTF-8 Support Enabled
INFO - 2018-03-23 13:52:39 --> Utf8 Class Initialized
INFO - 2018-03-23 13:52:40 --> URI Class Initialized
INFO - 2018-03-23 13:52:40 --> Router Class Initialized
INFO - 2018-03-23 13:52:40 --> Output Class Initialized
INFO - 2018-03-23 13:52:40 --> Security Class Initialized
DEBUG - 2018-03-23 13:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 13:52:40 --> Input Class Initialized
INFO - 2018-03-23 13:52:40 --> Language Class Initialized
INFO - 2018-03-23 13:52:41 --> Language Class Initialized
INFO - 2018-03-23 13:52:41 --> Config Class Initialized
INFO - 2018-03-23 13:52:41 --> Loader Class Initialized
INFO - 2018-03-23 19:22:42 --> Helper loaded: url_helper
INFO - 2018-03-23 19:22:42 --> Helper loaded: notification_helper
INFO - 2018-03-23 19:22:42 --> Helper loaded: settings_helper
INFO - 2018-03-23 19:22:42 --> Helper loaded: permission_helper
INFO - 2018-03-23 19:22:42 --> Helper loaded: users_helper
INFO - 2018-03-23 19:22:43 --> Database Driver Class Initialized
DEBUG - 2018-03-23 19:22:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 19:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 19:22:43 --> Helper loaded: form_helper
INFO - 2018-03-23 19:22:43 --> Form Validation Class Initialized
INFO - 2018-03-23 19:22:43 --> Controller Class Initialized
INFO - 2018-03-23 19:22:43 --> Model Class Initialized
INFO - 2018-03-23 19:22:43 --> Helper loaded: inflector_helper
DEBUG - 2018-03-23 19:22:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-23 19:22:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-23 19:22:43 --> Model Class Initialized
INFO - 2018-03-23 19:22:43 --> Model Class Initialized
INFO - 2018-03-23 19:22:43 --> Model Class Initialized
INFO - 2018-03-23 19:22:43 --> Model Class Initialized
INFO - 2018-03-23 19:22:43 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-23 19:22:43 --> Model Class Initialized
INFO - 2018-03-23 19:22:43 --> Final output sent to browser
DEBUG - 2018-03-23 19:22:43 --> Total execution time: 3.9017
INFO - 2018-03-23 13:52:45 --> Config Class Initialized
INFO - 2018-03-23 13:52:45 --> Hooks Class Initialized
DEBUG - 2018-03-23 13:52:45 --> UTF-8 Support Enabled
INFO - 2018-03-23 13:52:45 --> Utf8 Class Initialized
INFO - 2018-03-23 13:52:45 --> URI Class Initialized
INFO - 2018-03-23 13:52:45 --> Router Class Initialized
INFO - 2018-03-23 13:52:46 --> Output Class Initialized
INFO - 2018-03-23 13:52:46 --> Security Class Initialized
DEBUG - 2018-03-23 13:52:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 13:52:46 --> Input Class Initialized
INFO - 2018-03-23 13:52:46 --> Language Class Initialized
INFO - 2018-03-23 13:52:47 --> Language Class Initialized
INFO - 2018-03-23 13:52:47 --> Config Class Initialized
INFO - 2018-03-23 13:52:47 --> Loader Class Initialized
INFO - 2018-03-23 19:22:47 --> Helper loaded: url_helper
INFO - 2018-03-23 19:22:47 --> Helper loaded: notification_helper
INFO - 2018-03-23 19:22:47 --> Helper loaded: settings_helper
INFO - 2018-03-23 19:22:47 --> Helper loaded: permission_helper
INFO - 2018-03-23 19:22:47 --> Helper loaded: users_helper
INFO - 2018-03-23 19:22:48 --> Database Driver Class Initialized
DEBUG - 2018-03-23 19:22:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 19:22:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 19:22:48 --> Helper loaded: form_helper
INFO - 2018-03-23 19:22:48 --> Form Validation Class Initialized
INFO - 2018-03-23 19:22:48 --> Controller Class Initialized
INFO - 2018-03-23 19:22:48 --> Model Class Initialized
INFO - 2018-03-23 19:22:48 --> Helper loaded: inflector_helper
DEBUG - 2018-03-23 19:22:48 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-23 19:22:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-23 19:22:48 --> Model Class Initialized
INFO - 2018-03-23 19:22:48 --> Model Class Initialized
INFO - 2018-03-23 19:22:48 --> Model Class Initialized
INFO - 2018-03-23 19:22:48 --> Model Class Initialized
INFO - 2018-03-23 19:22:48 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-23 19:22:48 --> Final output sent to browser
DEBUG - 2018-03-23 19:22:48 --> Total execution time: 3.7923
INFO - 2018-03-23 13:52:50 --> Config Class Initialized
INFO - 2018-03-23 13:52:50 --> Hooks Class Initialized
DEBUG - 2018-03-23 13:52:50 --> UTF-8 Support Enabled
INFO - 2018-03-23 13:52:50 --> Utf8 Class Initialized
INFO - 2018-03-23 13:52:50 --> URI Class Initialized
INFO - 2018-03-23 13:52:50 --> Router Class Initialized
INFO - 2018-03-23 13:52:50 --> Output Class Initialized
INFO - 2018-03-23 13:52:50 --> Security Class Initialized
DEBUG - 2018-03-23 13:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 13:52:50 --> Input Class Initialized
INFO - 2018-03-23 13:52:50 --> Language Class Initialized
INFO - 2018-03-23 13:52:50 --> Language Class Initialized
INFO - 2018-03-23 13:52:50 --> Config Class Initialized
INFO - 2018-03-23 13:52:50 --> Loader Class Initialized
INFO - 2018-03-23 19:22:50 --> Helper loaded: url_helper
INFO - 2018-03-23 19:22:50 --> Helper loaded: notification_helper
INFO - 2018-03-23 19:22:50 --> Helper loaded: settings_helper
INFO - 2018-03-23 19:22:50 --> Helper loaded: permission_helper
INFO - 2018-03-23 19:22:50 --> Helper loaded: users_helper
INFO - 2018-03-23 19:22:50 --> Database Driver Class Initialized
DEBUG - 2018-03-23 19:22:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 19:22:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 19:22:50 --> Helper loaded: form_helper
INFO - 2018-03-23 19:22:50 --> Form Validation Class Initialized
INFO - 2018-03-23 19:22:50 --> Controller Class Initialized
INFO - 2018-03-23 19:22:50 --> Model Class Initialized
INFO - 2018-03-23 19:22:50 --> Helper loaded: inflector_helper
DEBUG - 2018-03-23 19:22:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-23 19:22:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-23 19:22:50 --> Model Class Initialized
INFO - 2018-03-23 19:22:50 --> Model Class Initialized
INFO - 2018-03-23 19:22:50 --> Model Class Initialized
INFO - 2018-03-23 19:22:50 --> Model Class Initialized
INFO - 2018-03-23 19:22:50 --> Model Class Initialized
INFO - 2018-03-23 19:22:50 --> Model Class Initialized
INFO - 2018-03-23 19:22:50 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-23 19:22:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-03-23 19:22:50 --> Final output sent to browser
DEBUG - 2018-03-23 19:22:50 --> Total execution time: 0.2314
INFO - 2018-03-23 13:52:58 --> Config Class Initialized
INFO - 2018-03-23 13:52:58 --> Hooks Class Initialized
DEBUG - 2018-03-23 13:52:59 --> UTF-8 Support Enabled
INFO - 2018-03-23 13:52:59 --> Utf8 Class Initialized
INFO - 2018-03-23 13:52:59 --> URI Class Initialized
INFO - 2018-03-23 13:52:59 --> Router Class Initialized
INFO - 2018-03-23 13:52:59 --> Config Class Initialized
INFO - 2018-03-23 13:52:59 --> Hooks Class Initialized
DEBUG - 2018-03-23 13:52:59 --> UTF-8 Support Enabled
INFO - 2018-03-23 13:52:59 --> Utf8 Class Initialized
INFO - 2018-03-23 13:52:59 --> URI Class Initialized
INFO - 2018-03-23 13:52:59 --> Output Class Initialized
INFO - 2018-03-23 13:53:00 --> Router Class Initialized
INFO - 2018-03-23 13:53:00 --> Security Class Initialized
DEBUG - 2018-03-23 13:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 13:53:00 --> Input Class Initialized
INFO - 2018-03-23 13:53:00 --> Output Class Initialized
INFO - 2018-03-23 13:53:00 --> Language Class Initialized
INFO - 2018-03-23 13:53:00 --> Security Class Initialized
DEBUG - 2018-03-23 13:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 13:53:00 --> Input Class Initialized
INFO - 2018-03-23 13:53:00 --> Language Class Initialized
INFO - 2018-03-23 13:53:01 --> Language Class Initialized
INFO - 2018-03-23 13:53:01 --> Config Class Initialized
INFO - 2018-03-23 13:53:01 --> Loader Class Initialized
INFO - 2018-03-23 19:23:01 --> Helper loaded: url_helper
INFO - 2018-03-23 19:23:01 --> Helper loaded: notification_helper
INFO - 2018-03-23 19:23:01 --> Helper loaded: settings_helper
INFO - 2018-03-23 19:23:01 --> Helper loaded: permission_helper
INFO - 2018-03-23 19:23:01 --> Helper loaded: users_helper
INFO - 2018-03-23 13:53:02 --> Language Class Initialized
INFO - 2018-03-23 13:53:02 --> Config Class Initialized
INFO - 2018-03-23 13:53:02 --> Loader Class Initialized
INFO - 2018-03-23 19:23:02 --> Helper loaded: url_helper
INFO - 2018-03-23 19:23:02 --> Helper loaded: notification_helper
INFO - 2018-03-23 19:23:02 --> Helper loaded: settings_helper
INFO - 2018-03-23 13:53:02 --> Config Class Initialized
INFO - 2018-03-23 13:53:02 --> Hooks Class Initialized
INFO - 2018-03-23 19:23:02 --> Helper loaded: permission_helper
INFO - 2018-03-23 19:23:02 --> Database Driver Class Initialized
DEBUG - 2018-03-23 13:53:02 --> UTF-8 Support Enabled
INFO - 2018-03-23 13:53:02 --> Utf8 Class Initialized
INFO - 2018-03-23 19:23:02 --> Helper loaded: users_helper
INFO - 2018-03-23 13:53:02 --> URI Class Initialized
INFO - 2018-03-23 13:53:02 --> Config Class Initialized
INFO - 2018-03-23 13:53:02 --> Hooks Class Initialized
INFO - 2018-03-23 13:53:02 --> Router Class Initialized
DEBUG - 2018-03-23 19:23:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 19:23:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 13:53:03 --> Output Class Initialized
INFO - 2018-03-23 13:53:03 --> Security Class Initialized
DEBUG - 2018-03-23 13:53:03 --> UTF-8 Support Enabled
INFO - 2018-03-23 13:53:03 --> Utf8 Class Initialized
DEBUG - 2018-03-23 13:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 13:53:03 --> Input Class Initialized
INFO - 2018-03-23 13:53:03 --> Language Class Initialized
INFO - 2018-03-23 13:53:03 --> URI Class Initialized
INFO - 2018-03-23 19:23:03 --> Helper loaded: form_helper
INFO - 2018-03-23 19:23:03 --> Form Validation Class Initialized
INFO - 2018-03-23 13:53:03 --> Router Class Initialized
INFO - 2018-03-23 19:23:03 --> Controller Class Initialized
INFO - 2018-03-23 13:53:03 --> Output Class Initialized
INFO - 2018-03-23 13:53:03 --> Language Class Initialized
INFO - 2018-03-23 13:53:03 --> Config Class Initialized
INFO - 2018-03-23 13:53:03 --> Loader Class Initialized
INFO - 2018-03-23 19:23:03 --> Helper loaded: url_helper
INFO - 2018-03-23 19:23:03 --> Helper loaded: notification_helper
INFO - 2018-03-23 19:23:03 --> Helper loaded: settings_helper
INFO - 2018-03-23 19:23:03 --> Helper loaded: permission_helper
INFO - 2018-03-23 19:23:03 --> Helper loaded: users_helper
INFO - 2018-03-23 19:23:03 --> Database Driver Class Initialized
INFO - 2018-03-23 13:53:03 --> Security Class Initialized
DEBUG - 2018-03-23 19:23:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-23 13:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 13:53:04 --> Input Class Initialized
INFO - 2018-03-23 13:53:04 --> Language Class Initialized
INFO - 2018-03-23 19:23:04 --> Model Class Initialized
INFO - 2018-03-23 19:23:04 --> Helper loaded: inflector_helper
INFO - 2018-03-23 19:23:04 --> Database Driver Class Initialized
DEBUG - 2018-03-23 19:23:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-23 19:23:04 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-23 19:23:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-23 19:23:04 --> Model Class Initialized
INFO - 2018-03-23 19:23:04 --> Model Class Initialized
INFO - 2018-03-23 19:23:04 --> Model Class Initialized
INFO - 2018-03-23 19:23:04 --> Model Class Initialized
INFO - 2018-03-23 19:23:04 --> Model Class Initialized
INFO - 2018-03-23 19:23:04 --> Model Class Initialized
INFO - 2018-03-23 19:23:04 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-23 19:23:05 --> Model Class Initialized
INFO - 2018-03-23 19:23:05 --> Model Class Initialized
INFO - 2018-03-23 19:23:05 --> Final output sent to browser
DEBUG - 2018-03-23 19:23:05 --> Total execution time: 6.7591
INFO - 2018-03-23 19:23:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 19:23:05 --> Helper loaded: form_helper
INFO - 2018-03-23 19:23:05 --> Form Validation Class Initialized
INFO - 2018-03-23 19:23:05 --> Controller Class Initialized
INFO - 2018-03-23 19:23:05 --> Model Class Initialized
INFO - 2018-03-23 19:23:05 --> Helper loaded: inflector_helper
DEBUG - 2018-03-23 19:23:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-23 19:23:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-23 19:23:05 --> Model Class Initialized
INFO - 2018-03-23 19:23:05 --> Model Class Initialized
INFO - 2018-03-23 19:23:05 --> Model Class Initialized
INFO - 2018-03-23 19:23:05 --> Model Class Initialized
INFO - 2018-03-23 19:23:05 --> Model Class Initialized
INFO - 2018-03-23 19:23:05 --> Model Class Initialized
INFO - 2018-03-23 19:23:05 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-23 19:23:05 --> Model Class Initialized
INFO - 2018-03-23 19:23:05 --> Model Class Initialized
INFO - 2018-03-23 19:23:05 --> Model Class Initialized
INFO - 2018-03-23 13:53:05 --> Language Class Initialized
INFO - 2018-03-23 13:53:05 --> Config Class Initialized
INFO - 2018-03-23 13:53:05 --> Loader Class Initialized
INFO - 2018-03-23 19:23:05 --> Helper loaded: url_helper
INFO - 2018-03-23 19:23:05 --> Helper loaded: notification_helper
INFO - 2018-03-23 19:23:05 --> Helper loaded: settings_helper
INFO - 2018-03-23 19:23:05 --> Helper loaded: permission_helper
INFO - 2018-03-23 19:23:05 --> Helper loaded: users_helper
INFO - 2018-03-23 19:23:06 --> Final output sent to browser
DEBUG - 2018-03-23 19:23:06 --> Total execution time: 3.8238
INFO - 2018-03-23 19:23:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 19:23:06 --> Helper loaded: form_helper
INFO - 2018-03-23 19:23:06 --> Form Validation Class Initialized
INFO - 2018-03-23 19:23:06 --> Controller Class Initialized
INFO - 2018-03-23 19:23:06 --> Model Class Initialized
INFO - 2018-03-23 19:23:06 --> Helper loaded: inflector_helper
DEBUG - 2018-03-23 19:23:06 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-23 19:23:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-23 19:23:06 --> Model Class Initialized
INFO - 2018-03-23 19:23:06 --> Model Class Initialized
INFO - 2018-03-23 19:23:06 --> Model Class Initialized
INFO - 2018-03-23 19:23:06 --> Model Class Initialized
INFO - 2018-03-23 19:23:06 --> Model Class Initialized
INFO - 2018-03-23 19:23:06 --> Model Class Initialized
INFO - 2018-03-23 19:23:06 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-23 19:23:06 --> Model Class Initialized
INFO - 2018-03-23 19:23:06 --> Model Class Initialized
INFO - 2018-03-23 19:23:06 --> Model Class Initialized
INFO - 2018-03-23 19:23:06 --> Database Driver Class Initialized
DEBUG - 2018-03-23 19:23:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 19:23:06 --> Final output sent to browser
DEBUG - 2018-03-23 19:23:06 --> Total execution time: 7.1692
INFO - 2018-03-23 19:23:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 19:23:06 --> Helper loaded: form_helper
INFO - 2018-03-23 19:23:06 --> Form Validation Class Initialized
INFO - 2018-03-23 19:23:06 --> Controller Class Initialized
INFO - 2018-03-23 19:23:06 --> Model Class Initialized
INFO - 2018-03-23 19:23:06 --> Helper loaded: inflector_helper
DEBUG - 2018-03-23 19:23:06 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-23 19:23:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-23 19:23:06 --> Model Class Initialized
INFO - 2018-03-23 19:23:06 --> Model Class Initialized
INFO - 2018-03-23 19:23:06 --> Model Class Initialized
INFO - 2018-03-23 19:23:06 --> Model Class Initialized
INFO - 2018-03-23 19:23:06 --> Model Class Initialized
INFO - 2018-03-23 19:23:06 --> Model Class Initialized
INFO - 2018-03-23 19:23:06 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-23 19:23:06 --> Model Class Initialized
INFO - 2018-03-23 19:23:06 --> Model Class Initialized
INFO - 2018-03-23 19:23:06 --> Model Class Initialized
INFO - 2018-03-23 19:23:06 --> Final output sent to browser
DEBUG - 2018-03-23 19:23:06 --> Total execution time: 4.4744
INFO - 2018-03-23 13:53:07 --> Config Class Initialized
INFO - 2018-03-23 13:53:07 --> Hooks Class Initialized
DEBUG - 2018-03-23 13:53:07 --> UTF-8 Support Enabled
INFO - 2018-03-23 13:53:07 --> Utf8 Class Initialized
INFO - 2018-03-23 13:53:07 --> URI Class Initialized
INFO - 2018-03-23 13:53:07 --> Router Class Initialized
INFO - 2018-03-23 13:53:07 --> Output Class Initialized
INFO - 2018-03-23 13:53:07 --> Security Class Initialized
DEBUG - 2018-03-23 13:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 13:53:07 --> Input Class Initialized
INFO - 2018-03-23 13:53:07 --> Language Class Initialized
INFO - 2018-03-23 13:53:07 --> Language Class Initialized
INFO - 2018-03-23 13:53:07 --> Config Class Initialized
INFO - 2018-03-23 13:53:07 --> Loader Class Initialized
INFO - 2018-03-23 19:23:07 --> Helper loaded: url_helper
INFO - 2018-03-23 19:23:07 --> Helper loaded: notification_helper
INFO - 2018-03-23 19:23:07 --> Helper loaded: settings_helper
INFO - 2018-03-23 19:23:07 --> Helper loaded: permission_helper
INFO - 2018-03-23 19:23:07 --> Helper loaded: users_helper
INFO - 2018-03-23 19:23:07 --> Database Driver Class Initialized
DEBUG - 2018-03-23 19:23:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 19:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 19:23:07 --> Helper loaded: form_helper
INFO - 2018-03-23 19:23:07 --> Form Validation Class Initialized
INFO - 2018-03-23 19:23:07 --> Controller Class Initialized
INFO - 2018-03-23 19:23:07 --> Model Class Initialized
INFO - 2018-03-23 19:23:07 --> Helper loaded: inflector_helper
DEBUG - 2018-03-23 19:23:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-23 19:23:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-23 19:23:07 --> Model Class Initialized
INFO - 2018-03-23 19:23:07 --> Model Class Initialized
INFO - 2018-03-23 19:23:07 --> Model Class Initialized
INFO - 2018-03-23 19:23:07 --> Model Class Initialized
INFO - 2018-03-23 19:23:07 --> Model Class Initialized
INFO - 2018-03-23 19:23:07 --> Model Class Initialized
INFO - 2018-03-23 19:23:07 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-23 19:23:07 --> Model Class Initialized
INFO - 2018-03-23 19:23:07 --> Model Class Initialized
INFO - 2018-03-23 19:23:07 --> Model Class Initialized
INFO - 2018-03-23 19:23:07 --> Final output sent to browser
DEBUG - 2018-03-23 19:23:07 --> Total execution time: 0.1979
INFO - 2018-03-23 13:53:08 --> Config Class Initialized
INFO - 2018-03-23 13:53:08 --> Hooks Class Initialized
DEBUG - 2018-03-23 13:53:08 --> UTF-8 Support Enabled
INFO - 2018-03-23 13:53:08 --> Utf8 Class Initialized
INFO - 2018-03-23 13:53:08 --> URI Class Initialized
INFO - 2018-03-23 13:53:08 --> Router Class Initialized
INFO - 2018-03-23 13:53:08 --> Output Class Initialized
INFO - 2018-03-23 13:53:08 --> Security Class Initialized
DEBUG - 2018-03-23 13:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 13:53:08 --> Input Class Initialized
INFO - 2018-03-23 13:53:08 --> Language Class Initialized
INFO - 2018-03-23 13:53:08 --> Language Class Initialized
INFO - 2018-03-23 13:53:08 --> Config Class Initialized
INFO - 2018-03-23 13:53:08 --> Loader Class Initialized
INFO - 2018-03-23 19:23:08 --> Helper loaded: url_helper
INFO - 2018-03-23 19:23:08 --> Helper loaded: notification_helper
INFO - 2018-03-23 19:23:08 --> Helper loaded: settings_helper
INFO - 2018-03-23 19:23:08 --> Helper loaded: permission_helper
INFO - 2018-03-23 19:23:08 --> Helper loaded: users_helper
INFO - 2018-03-23 19:23:08 --> Database Driver Class Initialized
DEBUG - 2018-03-23 19:23:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 19:23:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 19:23:08 --> Helper loaded: form_helper
INFO - 2018-03-23 19:23:08 --> Form Validation Class Initialized
INFO - 2018-03-23 19:23:08 --> Controller Class Initialized
INFO - 2018-03-23 19:23:08 --> Model Class Initialized
INFO - 2018-03-23 19:23:08 --> Helper loaded: inflector_helper
DEBUG - 2018-03-23 19:23:08 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-23 19:23:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-23 19:23:08 --> Model Class Initialized
INFO - 2018-03-23 19:23:08 --> Model Class Initialized
INFO - 2018-03-23 19:23:08 --> Model Class Initialized
INFO - 2018-03-23 19:23:08 --> Model Class Initialized
INFO - 2018-03-23 19:23:08 --> Model Class Initialized
INFO - 2018-03-23 19:23:08 --> Model Class Initialized
INFO - 2018-03-23 19:23:08 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-23 19:23:08 --> Model Class Initialized
INFO - 2018-03-23 19:23:08 --> Model Class Initialized
INFO - 2018-03-23 19:23:08 --> Model Class Initialized
INFO - 2018-03-23 19:23:08 --> Final output sent to browser
DEBUG - 2018-03-23 19:23:08 --> Total execution time: 0.6165
INFO - 2018-03-23 13:53:09 --> Config Class Initialized
INFO - 2018-03-23 13:53:09 --> Hooks Class Initialized
DEBUG - 2018-03-23 13:53:09 --> UTF-8 Support Enabled
INFO - 2018-03-23 13:53:09 --> Utf8 Class Initialized
INFO - 2018-03-23 13:53:09 --> URI Class Initialized
INFO - 2018-03-23 13:53:09 --> Router Class Initialized
INFO - 2018-03-23 13:53:09 --> Output Class Initialized
INFO - 2018-03-23 13:53:09 --> Security Class Initialized
DEBUG - 2018-03-23 13:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 13:53:10 --> Input Class Initialized
INFO - 2018-03-23 13:53:10 --> Language Class Initialized
INFO - 2018-03-23 13:53:11 --> Config Class Initialized
INFO - 2018-03-23 13:53:11 --> Hooks Class Initialized
INFO - 2018-03-23 13:53:11 --> Language Class Initialized
INFO - 2018-03-23 13:53:11 --> Config Class Initialized
INFO - 2018-03-23 13:53:11 --> Loader Class Initialized
DEBUG - 2018-03-23 13:53:11 --> UTF-8 Support Enabled
INFO - 2018-03-23 19:23:11 --> Helper loaded: url_helper
INFO - 2018-03-23 13:53:11 --> Utf8 Class Initialized
INFO - 2018-03-23 19:23:11 --> Helper loaded: notification_helper
INFO - 2018-03-23 19:23:11 --> Helper loaded: settings_helper
INFO - 2018-03-23 13:53:11 --> URI Class Initialized
INFO - 2018-03-23 19:23:11 --> Helper loaded: permission_helper
INFO - 2018-03-23 19:23:11 --> Helper loaded: users_helper
INFO - 2018-03-23 13:53:11 --> Router Class Initialized
INFO - 2018-03-23 13:53:12 --> Output Class Initialized
INFO - 2018-03-23 13:53:12 --> Security Class Initialized
DEBUG - 2018-03-23 13:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 13:53:12 --> Input Class Initialized
INFO - 2018-03-23 13:53:12 --> Language Class Initialized
INFO - 2018-03-23 19:23:12 --> Database Driver Class Initialized
DEBUG - 2018-03-23 19:23:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 19:23:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 19:23:12 --> Helper loaded: form_helper
INFO - 2018-03-23 19:23:12 --> Form Validation Class Initialized
INFO - 2018-03-23 19:23:12 --> Controller Class Initialized
INFO - 2018-03-23 19:23:12 --> Model Class Initialized
INFO - 2018-03-23 19:23:12 --> Helper loaded: inflector_helper
DEBUG - 2018-03-23 19:23:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-23 19:23:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-23 19:23:12 --> Model Class Initialized
INFO - 2018-03-23 19:23:12 --> Model Class Initialized
INFO - 2018-03-23 19:23:12 --> Model Class Initialized
INFO - 2018-03-23 19:23:12 --> Model Class Initialized
INFO - 2018-03-23 19:23:12 --> Model Class Initialized
INFO - 2018-03-23 19:23:12 --> Model Class Initialized
INFO - 2018-03-23 19:23:12 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-23 19:23:12 --> Model Class Initialized
INFO - 2018-03-23 19:23:12 --> Model Class Initialized
INFO - 2018-03-23 19:23:12 --> Model Class Initialized
INFO - 2018-03-23 19:23:12 --> Final output sent to browser
DEBUG - 2018-03-23 19:23:12 --> Total execution time: 4.0191
INFO - 2018-03-23 13:53:12 --> Config Class Initialized
INFO - 2018-03-23 13:53:12 --> Hooks Class Initialized
DEBUG - 2018-03-23 13:53:12 --> UTF-8 Support Enabled
INFO - 2018-03-23 13:53:12 --> Utf8 Class Initialized
INFO - 2018-03-23 13:53:12 --> URI Class Initialized
INFO - 2018-03-23 13:53:12 --> Router Class Initialized
INFO - 2018-03-23 13:53:12 --> Output Class Initialized
INFO - 2018-03-23 13:53:12 --> Security Class Initialized
DEBUG - 2018-03-23 13:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 13:53:12 --> Input Class Initialized
INFO - 2018-03-23 13:53:12 --> Language Class Initialized
INFO - 2018-03-23 13:53:13 --> Language Class Initialized
INFO - 2018-03-23 13:53:13 --> Config Class Initialized
INFO - 2018-03-23 13:53:13 --> Loader Class Initialized
INFO - 2018-03-23 19:23:13 --> Helper loaded: url_helper
INFO - 2018-03-23 19:23:13 --> Helper loaded: notification_helper
INFO - 2018-03-23 19:23:13 --> Helper loaded: settings_helper
INFO - 2018-03-23 19:23:13 --> Helper loaded: permission_helper
INFO - 2018-03-23 19:23:13 --> Helper loaded: users_helper
INFO - 2018-03-23 19:23:13 --> Database Driver Class Initialized
DEBUG - 2018-03-23 19:23:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 19:23:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 19:23:13 --> Helper loaded: form_helper
INFO - 2018-03-23 19:23:13 --> Form Validation Class Initialized
INFO - 2018-03-23 19:23:13 --> Controller Class Initialized
INFO - 2018-03-23 19:23:13 --> Model Class Initialized
INFO - 2018-03-23 19:23:13 --> Helper loaded: inflector_helper
DEBUG - 2018-03-23 19:23:13 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-23 19:23:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-23 19:23:13 --> Model Class Initialized
INFO - 2018-03-23 19:23:13 --> Model Class Initialized
INFO - 2018-03-23 19:23:13 --> Model Class Initialized
INFO - 2018-03-23 19:23:13 --> Model Class Initialized
INFO - 2018-03-23 19:23:13 --> Model Class Initialized
INFO - 2018-03-23 19:23:13 --> Model Class Initialized
INFO - 2018-03-23 19:23:13 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-23 19:23:13 --> Model Class Initialized
INFO - 2018-03-23 19:23:13 --> Model Class Initialized
INFO - 2018-03-23 19:23:13 --> Final output sent to browser
DEBUG - 2018-03-23 19:23:13 --> Total execution time: 0.2356
INFO - 2018-03-23 13:53:13 --> Config Class Initialized
INFO - 2018-03-23 13:53:13 --> Hooks Class Initialized
DEBUG - 2018-03-23 13:53:13 --> UTF-8 Support Enabled
INFO - 2018-03-23 13:53:13 --> Utf8 Class Initialized
INFO - 2018-03-23 13:53:13 --> URI Class Initialized
INFO - 2018-03-23 13:53:13 --> Router Class Initialized
INFO - 2018-03-23 13:53:13 --> Output Class Initialized
INFO - 2018-03-23 13:53:13 --> Security Class Initialized
DEBUG - 2018-03-23 13:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 13:53:13 --> Input Class Initialized
INFO - 2018-03-23 13:53:13 --> Language Class Initialized
INFO - 2018-03-23 13:53:13 --> Language Class Initialized
INFO - 2018-03-23 13:53:13 --> Config Class Initialized
INFO - 2018-03-23 13:53:13 --> Loader Class Initialized
INFO - 2018-03-23 19:23:13 --> Helper loaded: url_helper
INFO - 2018-03-23 19:23:13 --> Helper loaded: notification_helper
INFO - 2018-03-23 19:23:13 --> Helper loaded: settings_helper
INFO - 2018-03-23 19:23:13 --> Helper loaded: permission_helper
INFO - 2018-03-23 19:23:13 --> Helper loaded: users_helper
INFO - 2018-03-23 13:53:13 --> Language Class Initialized
INFO - 2018-03-23 13:53:13 --> Config Class Initialized
INFO - 2018-03-23 13:53:13 --> Loader Class Initialized
INFO - 2018-03-23 19:23:13 --> Database Driver Class Initialized
DEBUG - 2018-03-23 19:23:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 19:23:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 19:23:13 --> Helper loaded: form_helper
INFO - 2018-03-23 19:23:13 --> Form Validation Class Initialized
INFO - 2018-03-23 19:23:13 --> Controller Class Initialized
INFO - 2018-03-23 19:23:13 --> Model Class Initialized
INFO - 2018-03-23 19:23:13 --> Helper loaded: inflector_helper
DEBUG - 2018-03-23 19:23:13 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-23 19:23:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-23 19:23:13 --> Model Class Initialized
INFO - 2018-03-23 19:23:13 --> Model Class Initialized
INFO - 2018-03-23 19:23:13 --> Model Class Initialized
INFO - 2018-03-23 19:23:13 --> Model Class Initialized
INFO - 2018-03-23 19:23:13 --> Model Class Initialized
INFO - 2018-03-23 19:23:13 --> Model Class Initialized
INFO - 2018-03-23 19:23:13 --> Model Class Initialized
INFO - 2018-03-23 19:23:13 --> Model Class Initialized
INFO - 2018-03-23 19:23:13 --> Model Class Initialized
INFO - 2018-03-23 19:23:13 --> Model Class Initialized
INFO - 2018-03-23 19:23:13 --> Model Class Initialized
INFO - 2018-03-23 19:23:13 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-23 19:23:13 --> Model Class Initialized
INFO - 2018-03-23 19:23:13 --> Final output sent to browser
DEBUG - 2018-03-23 19:23:13 --> Total execution time: 0.2427
INFO - 2018-03-23 19:23:13 --> Helper loaded: url_helper
INFO - 2018-03-23 19:23:13 --> Helper loaded: notification_helper
INFO - 2018-03-23 19:23:13 --> Helper loaded: settings_helper
INFO - 2018-03-23 19:23:13 --> Helper loaded: permission_helper
INFO - 2018-03-23 19:23:14 --> Helper loaded: users_helper
INFO - 2018-03-23 19:23:15 --> Database Driver Class Initialized
DEBUG - 2018-03-23 19:23:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 19:23:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 19:23:15 --> Helper loaded: form_helper
INFO - 2018-03-23 19:23:15 --> Form Validation Class Initialized
INFO - 2018-03-23 19:23:15 --> Controller Class Initialized
INFO - 2018-03-23 19:23:15 --> Model Class Initialized
INFO - 2018-03-23 19:23:15 --> Helper loaded: inflector_helper
DEBUG - 2018-03-23 19:23:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-23 19:23:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-23 19:23:15 --> Model Class Initialized
INFO - 2018-03-23 19:23:15 --> Model Class Initialized
INFO - 2018-03-23 19:23:15 --> Model Class Initialized
INFO - 2018-03-23 19:23:15 --> Model Class Initialized
INFO - 2018-03-23 19:23:15 --> Model Class Initialized
INFO - 2018-03-23 19:23:15 --> Model Class Initialized
INFO - 2018-03-23 19:23:15 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-23 19:23:15 --> Model Class Initialized
INFO - 2018-03-23 19:23:15 --> Model Class Initialized
INFO - 2018-03-23 19:23:15 --> Model Class Initialized
INFO - 2018-03-23 19:23:15 --> Final output sent to browser
DEBUG - 2018-03-23 19:23:15 --> Total execution time: 4.9256
INFO - 2018-03-23 13:53:17 --> Config Class Initialized
INFO - 2018-03-23 13:53:17 --> Hooks Class Initialized
DEBUG - 2018-03-23 13:53:17 --> UTF-8 Support Enabled
INFO - 2018-03-23 13:53:17 --> Utf8 Class Initialized
INFO - 2018-03-23 13:53:17 --> URI Class Initialized
INFO - 2018-03-23 13:53:17 --> Router Class Initialized
INFO - 2018-03-23 13:53:17 --> Output Class Initialized
INFO - 2018-03-23 13:53:17 --> Security Class Initialized
DEBUG - 2018-03-23 13:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 13:53:17 --> Input Class Initialized
INFO - 2018-03-23 13:53:17 --> Language Class Initialized
INFO - 2018-03-23 13:53:17 --> Language Class Initialized
INFO - 2018-03-23 13:53:17 --> Config Class Initialized
INFO - 2018-03-23 13:53:17 --> Loader Class Initialized
INFO - 2018-03-23 19:23:17 --> Helper loaded: url_helper
INFO - 2018-03-23 19:23:17 --> Helper loaded: notification_helper
INFO - 2018-03-23 19:23:17 --> Helper loaded: settings_helper
INFO - 2018-03-23 19:23:17 --> Helper loaded: permission_helper
INFO - 2018-03-23 19:23:17 --> Helper loaded: users_helper
INFO - 2018-03-23 19:23:17 --> Database Driver Class Initialized
DEBUG - 2018-03-23 19:23:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 19:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 19:23:17 --> Helper loaded: form_helper
INFO - 2018-03-23 19:23:17 --> Form Validation Class Initialized
INFO - 2018-03-23 19:23:17 --> Controller Class Initialized
INFO - 2018-03-23 19:23:17 --> Model Class Initialized
INFO - 2018-03-23 19:23:17 --> Helper loaded: inflector_helper
DEBUG - 2018-03-23 19:23:17 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-23 19:23:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-23 19:23:17 --> Model Class Initialized
INFO - 2018-03-23 19:23:17 --> Model Class Initialized
INFO - 2018-03-23 19:23:17 --> Model Class Initialized
INFO - 2018-03-23 19:23:17 --> Model Class Initialized
INFO - 2018-03-23 19:23:17 --> Model Class Initialized
INFO - 2018-03-23 19:23:17 --> Model Class Initialized
INFO - 2018-03-23 19:23:17 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-23 19:23:17 --> Model Class Initialized
INFO - 2018-03-23 19:23:17 --> Model Class Initialized
INFO - 2018-03-23 19:23:17 --> Final output sent to browser
DEBUG - 2018-03-23 19:23:17 --> Total execution time: 0.2640
INFO - 2018-03-23 13:53:17 --> Config Class Initialized
INFO - 2018-03-23 13:53:17 --> Hooks Class Initialized
DEBUG - 2018-03-23 13:53:17 --> UTF-8 Support Enabled
INFO - 2018-03-23 13:53:17 --> Utf8 Class Initialized
INFO - 2018-03-23 13:53:17 --> URI Class Initialized
INFO - 2018-03-23 13:53:18 --> Router Class Initialized
INFO - 2018-03-23 13:53:18 --> Output Class Initialized
INFO - 2018-03-23 13:53:18 --> Security Class Initialized
DEBUG - 2018-03-23 13:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 13:53:18 --> Input Class Initialized
INFO - 2018-03-23 13:53:18 --> Language Class Initialized
INFO - 2018-03-23 13:53:18 --> Language Class Initialized
INFO - 2018-03-23 13:53:18 --> Config Class Initialized
INFO - 2018-03-23 13:53:18 --> Loader Class Initialized
INFO - 2018-03-23 19:23:19 --> Helper loaded: url_helper
INFO - 2018-03-23 19:23:19 --> Helper loaded: notification_helper
INFO - 2018-03-23 19:23:19 --> Helper loaded: settings_helper
INFO - 2018-03-23 19:23:19 --> Helper loaded: permission_helper
INFO - 2018-03-23 19:23:19 --> Helper loaded: users_helper
INFO - 2018-03-23 13:53:19 --> Config Class Initialized
INFO - 2018-03-23 13:53:19 --> Hooks Class Initialized
DEBUG - 2018-03-23 13:53:19 --> UTF-8 Support Enabled
INFO - 2018-03-23 13:53:19 --> Utf8 Class Initialized
INFO - 2018-03-23 13:53:19 --> Config Class Initialized
INFO - 2018-03-23 13:53:19 --> Hooks Class Initialized
INFO - 2018-03-23 13:53:19 --> URI Class Initialized
INFO - 2018-03-23 19:23:19 --> Database Driver Class Initialized
INFO - 2018-03-23 13:53:19 --> Router Class Initialized
DEBUG - 2018-03-23 19:23:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 19:23:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-03-23 13:53:19 --> UTF-8 Support Enabled
INFO - 2018-03-23 13:53:19 --> Utf8 Class Initialized
INFO - 2018-03-23 13:53:19 --> Output Class Initialized
INFO - 2018-03-23 13:53:19 --> URI Class Initialized
INFO - 2018-03-23 13:53:19 --> Security Class Initialized
INFO - 2018-03-23 13:53:19 --> Router Class Initialized
DEBUG - 2018-03-23 13:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 13:53:19 --> Input Class Initialized
INFO - 2018-03-23 13:53:19 --> Language Class Initialized
INFO - 2018-03-23 19:23:19 --> Helper loaded: form_helper
INFO - 2018-03-23 13:53:19 --> Output Class Initialized
INFO - 2018-03-23 19:23:19 --> Form Validation Class Initialized
INFO - 2018-03-23 19:23:19 --> Controller Class Initialized
INFO - 2018-03-23 13:53:20 --> Security Class Initialized
DEBUG - 2018-03-23 13:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 13:53:20 --> Input Class Initialized
INFO - 2018-03-23 13:53:20 --> Language Class Initialized
INFO - 2018-03-23 13:53:20 --> Language Class Initialized
INFO - 2018-03-23 13:53:20 --> Config Class Initialized
INFO - 2018-03-23 13:53:20 --> Loader Class Initialized
INFO - 2018-03-23 19:23:20 --> Helper loaded: url_helper
INFO - 2018-03-23 19:23:20 --> Helper loaded: notification_helper
INFO - 2018-03-23 19:23:20 --> Helper loaded: settings_helper
INFO - 2018-03-23 19:23:20 --> Helper loaded: permission_helper
INFO - 2018-03-23 19:23:20 --> Helper loaded: users_helper
INFO - 2018-03-23 19:23:20 --> Database Driver Class Initialized
DEBUG - 2018-03-23 19:23:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 19:23:20 --> Model Class Initialized
INFO - 2018-03-23 19:23:20 --> Helper loaded: inflector_helper
DEBUG - 2018-03-23 19:23:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-23 19:23:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-23 19:23:20 --> Model Class Initialized
INFO - 2018-03-23 19:23:20 --> Model Class Initialized
INFO - 2018-03-23 19:23:20 --> Model Class Initialized
INFO - 2018-03-23 19:23:20 --> Model Class Initialized
INFO - 2018-03-23 19:23:20 --> Model Class Initialized
INFO - 2018-03-23 19:23:20 --> Model Class Initialized
INFO - 2018-03-23 13:53:20 --> Language Class Initialized
INFO - 2018-03-23 13:53:20 --> Config Class Initialized
INFO - 2018-03-23 13:53:20 --> Loader Class Initialized
INFO - 2018-03-23 19:23:20 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-23 19:23:20 --> Model Class Initialized
INFO - 2018-03-23 19:23:20 --> Model Class Initialized
INFO - 2018-03-23 19:23:20 --> Helper loaded: url_helper
INFO - 2018-03-23 19:23:21 --> Helper loaded: notification_helper
INFO - 2018-03-23 19:23:21 --> Helper loaded: settings_helper
INFO - 2018-03-23 19:23:21 --> Final output sent to browser
DEBUG - 2018-03-23 19:23:21 --> Total execution time: 3.2280
INFO - 2018-03-23 19:23:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 19:23:21 --> Helper loaded: form_helper
INFO - 2018-03-23 19:23:21 --> Form Validation Class Initialized
INFO - 2018-03-23 19:23:21 --> Controller Class Initialized
INFO - 2018-03-23 19:23:21 --> Model Class Initialized
INFO - 2018-03-23 19:23:21 --> Helper loaded: permission_helper
INFO - 2018-03-23 19:23:21 --> Helper loaded: inflector_helper
DEBUG - 2018-03-23 19:23:21 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-23 19:23:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-23 19:23:21 --> Model Class Initialized
INFO - 2018-03-23 19:23:21 --> Model Class Initialized
INFO - 2018-03-23 19:23:21 --> Model Class Initialized
INFO - 2018-03-23 19:23:21 --> Model Class Initialized
INFO - 2018-03-23 19:23:21 --> Model Class Initialized
INFO - 2018-03-23 19:23:21 --> Model Class Initialized
INFO - 2018-03-23 19:23:21 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-23 19:23:21 --> Model Class Initialized
INFO - 2018-03-23 19:23:21 --> Model Class Initialized
INFO - 2018-03-23 19:23:21 --> Model Class Initialized
INFO - 2018-03-23 19:23:21 --> Helper loaded: users_helper
INFO - 2018-03-23 19:23:21 --> Final output sent to browser
DEBUG - 2018-03-23 19:23:21 --> Total execution time: 2.3058
INFO - 2018-03-23 13:53:21 --> Config Class Initialized
INFO - 2018-03-23 13:53:21 --> Hooks Class Initialized
DEBUG - 2018-03-23 13:53:21 --> UTF-8 Support Enabled
INFO - 2018-03-23 13:53:21 --> Utf8 Class Initialized
INFO - 2018-03-23 13:53:21 --> URI Class Initialized
INFO - 2018-03-23 13:53:21 --> Router Class Initialized
INFO - 2018-03-23 13:53:21 --> Output Class Initialized
INFO - 2018-03-23 13:53:21 --> Security Class Initialized
DEBUG - 2018-03-23 13:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 13:53:21 --> Input Class Initialized
INFO - 2018-03-23 13:53:21 --> Language Class Initialized
INFO - 2018-03-23 13:53:21 --> Language Class Initialized
INFO - 2018-03-23 13:53:21 --> Config Class Initialized
INFO - 2018-03-23 13:53:21 --> Loader Class Initialized
INFO - 2018-03-23 19:23:21 --> Helper loaded: url_helper
INFO - 2018-03-23 19:23:21 --> Helper loaded: notification_helper
INFO - 2018-03-23 19:23:21 --> Helper loaded: settings_helper
INFO - 2018-03-23 19:23:21 --> Helper loaded: permission_helper
INFO - 2018-03-23 19:23:21 --> Helper loaded: users_helper
INFO - 2018-03-23 19:23:21 --> Database Driver Class Initialized
DEBUG - 2018-03-23 19:23:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 19:23:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 19:23:21 --> Helper loaded: form_helper
INFO - 2018-03-23 19:23:21 --> Form Validation Class Initialized
INFO - 2018-03-23 19:23:21 --> Controller Class Initialized
INFO - 2018-03-23 19:23:21 --> Model Class Initialized
INFO - 2018-03-23 19:23:21 --> Helper loaded: inflector_helper
DEBUG - 2018-03-23 19:23:21 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-23 19:23:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-23 19:23:21 --> Model Class Initialized
INFO - 2018-03-23 19:23:21 --> Model Class Initialized
INFO - 2018-03-23 19:23:21 --> Model Class Initialized
INFO - 2018-03-23 19:23:21 --> Model Class Initialized
INFO - 2018-03-23 19:23:21 --> Model Class Initialized
INFO - 2018-03-23 19:23:21 --> Model Class Initialized
INFO - 2018-03-23 19:23:21 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-23 19:23:21 --> Model Class Initialized
INFO - 2018-03-23 19:23:21 --> Model Class Initialized
INFO - 2018-03-23 19:23:21 --> Model Class Initialized
INFO - 2018-03-23 19:23:22 --> Database Driver Class Initialized
DEBUG - 2018-03-23 19:23:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 19:23:22 --> Final output sent to browser
DEBUG - 2018-03-23 19:23:22 --> Total execution time: 0.3072
INFO - 2018-03-23 19:23:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 13:53:22 --> Config Class Initialized
INFO - 2018-03-23 13:53:22 --> Hooks Class Initialized
INFO - 2018-03-23 19:23:22 --> Helper loaded: form_helper
INFO - 2018-03-23 19:23:22 --> Form Validation Class Initialized
INFO - 2018-03-23 19:23:22 --> Controller Class Initialized
DEBUG - 2018-03-23 13:53:22 --> UTF-8 Support Enabled
INFO - 2018-03-23 13:53:22 --> Utf8 Class Initialized
INFO - 2018-03-23 13:53:22 --> URI Class Initialized
INFO - 2018-03-23 13:53:22 --> Router Class Initialized
INFO - 2018-03-23 13:53:22 --> Config Class Initialized
INFO - 2018-03-23 13:53:22 --> Hooks Class Initialized
DEBUG - 2018-03-23 13:53:22 --> UTF-8 Support Enabled
INFO - 2018-03-23 13:53:22 --> Utf8 Class Initialized
INFO - 2018-03-23 13:53:22 --> URI Class Initialized
INFO - 2018-03-23 13:53:22 --> Router Class Initialized
INFO - 2018-03-23 13:53:22 --> Output Class Initialized
INFO - 2018-03-23 13:53:22 --> Security Class Initialized
DEBUG - 2018-03-23 13:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 13:53:22 --> Input Class Initialized
INFO - 2018-03-23 13:53:22 --> Language Class Initialized
INFO - 2018-03-23 13:53:22 --> Language Class Initialized
INFO - 2018-03-23 13:53:22 --> Config Class Initialized
INFO - 2018-03-23 13:53:22 --> Loader Class Initialized
INFO - 2018-03-23 19:23:22 --> Helper loaded: url_helper
INFO - 2018-03-23 19:23:22 --> Helper loaded: notification_helper
INFO - 2018-03-23 19:23:22 --> Helper loaded: settings_helper
INFO - 2018-03-23 19:23:22 --> Helper loaded: permission_helper
INFO - 2018-03-23 19:23:22 --> Helper loaded: users_helper
INFO - 2018-03-23 19:23:22 --> Database Driver Class Initialized
DEBUG - 2018-03-23 19:23:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 13:53:22 --> Output Class Initialized
INFO - 2018-03-23 19:23:22 --> Model Class Initialized
INFO - 2018-03-23 19:23:22 --> Helper loaded: inflector_helper
INFO - 2018-03-23 13:53:22 --> Security Class Initialized
DEBUG - 2018-03-23 19:23:22 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-03-23 13:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 13:53:22 --> Input Class Initialized
INFO - 2018-03-23 19:23:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-23 13:53:22 --> Language Class Initialized
INFO - 2018-03-23 19:23:22 --> Model Class Initialized
INFO - 2018-03-23 19:23:22 --> Model Class Initialized
INFO - 2018-03-23 19:23:22 --> Model Class Initialized
INFO - 2018-03-23 19:23:22 --> Model Class Initialized
INFO - 2018-03-23 19:23:22 --> Model Class Initialized
INFO - 2018-03-23 19:23:22 --> Model Class Initialized
INFO - 2018-03-23 19:23:22 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-23 19:23:22 --> Model Class Initialized
INFO - 2018-03-23 19:23:22 --> Model Class Initialized
INFO - 2018-03-23 19:23:23 --> Model Class Initialized
INFO - 2018-03-23 19:23:23 --> Final output sent to browser
DEBUG - 2018-03-23 19:23:23 --> Total execution time: 4.1920
INFO - 2018-03-23 19:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 19:23:23 --> Helper loaded: form_helper
INFO - 2018-03-23 19:23:23 --> Form Validation Class Initialized
INFO - 2018-03-23 19:23:23 --> Controller Class Initialized
INFO - 2018-03-23 19:23:23 --> Model Class Initialized
INFO - 2018-03-23 19:23:23 --> Helper loaded: inflector_helper
DEBUG - 2018-03-23 19:23:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-23 19:23:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-23 19:23:23 --> Model Class Initialized
INFO - 2018-03-23 19:23:23 --> Model Class Initialized
INFO - 2018-03-23 19:23:23 --> Model Class Initialized
INFO - 2018-03-23 19:23:23 --> Model Class Initialized
INFO - 2018-03-23 19:23:23 --> Model Class Initialized
INFO - 2018-03-23 19:23:23 --> Model Class Initialized
INFO - 2018-03-23 19:23:23 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-23 19:23:23 --> Model Class Initialized
INFO - 2018-03-23 19:23:23 --> Model Class Initialized
INFO - 2018-03-23 19:23:23 --> Final output sent to browser
DEBUG - 2018-03-23 19:23:23 --> Total execution time: 1.1380
INFO - 2018-03-23 13:53:23 --> Language Class Initialized
INFO - 2018-03-23 13:53:23 --> Config Class Initialized
INFO - 2018-03-23 13:53:23 --> Loader Class Initialized
INFO - 2018-03-23 19:23:23 --> Helper loaded: url_helper
INFO - 2018-03-23 13:53:24 --> Config Class Initialized
INFO - 2018-03-23 13:53:24 --> Hooks Class Initialized
INFO - 2018-03-23 19:23:24 --> Helper loaded: notification_helper
INFO - 2018-03-23 19:23:24 --> Helper loaded: settings_helper
INFO - 2018-03-23 19:23:24 --> Helper loaded: permission_helper
INFO - 2018-03-23 19:23:24 --> Helper loaded: users_helper
DEBUG - 2018-03-23 13:53:24 --> UTF-8 Support Enabled
INFO - 2018-03-23 13:53:24 --> Utf8 Class Initialized
INFO - 2018-03-23 13:53:24 --> URI Class Initialized
INFO - 2018-03-23 13:53:24 --> Router Class Initialized
INFO - 2018-03-23 13:53:24 --> Output Class Initialized
INFO - 2018-03-23 13:53:24 --> Security Class Initialized
DEBUG - 2018-03-23 13:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 13:53:24 --> Input Class Initialized
INFO - 2018-03-23 13:53:24 --> Language Class Initialized
INFO - 2018-03-23 19:23:24 --> Database Driver Class Initialized
DEBUG - 2018-03-23 19:23:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 19:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 19:23:24 --> Helper loaded: form_helper
INFO - 2018-03-23 19:23:24 --> Form Validation Class Initialized
INFO - 2018-03-23 19:23:24 --> Controller Class Initialized
INFO - 2018-03-23 13:53:24 --> Language Class Initialized
INFO - 2018-03-23 13:53:24 --> Config Class Initialized
INFO - 2018-03-23 13:53:24 --> Loader Class Initialized
INFO - 2018-03-23 19:23:24 --> Helper loaded: url_helper
INFO - 2018-03-23 19:23:24 --> Helper loaded: notification_helper
INFO - 2018-03-23 19:23:24 --> Helper loaded: settings_helper
INFO - 2018-03-23 19:23:24 --> Helper loaded: permission_helper
INFO - 2018-03-23 19:23:24 --> Model Class Initialized
INFO - 2018-03-23 19:23:24 --> Helper loaded: users_helper
INFO - 2018-03-23 19:23:24 --> Helper loaded: inflector_helper
DEBUG - 2018-03-23 19:23:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-23 19:23:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-23 19:23:24 --> Model Class Initialized
INFO - 2018-03-23 19:23:24 --> Model Class Initialized
INFO - 2018-03-23 19:23:24 --> Model Class Initialized
INFO - 2018-03-23 19:23:24 --> Model Class Initialized
INFO - 2018-03-23 19:23:24 --> Model Class Initialized
INFO - 2018-03-23 19:23:24 --> Model Class Initialized
INFO - 2018-03-23 19:23:24 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-23 19:23:24 --> Model Class Initialized
INFO - 2018-03-23 19:23:24 --> Model Class Initialized
INFO - 2018-03-23 19:23:24 --> Final output sent to browser
DEBUG - 2018-03-23 19:23:24 --> Total execution time: 2.2690
INFO - 2018-03-23 19:23:24 --> Database Driver Class Initialized
DEBUG - 2018-03-23 19:23:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 19:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 19:23:24 --> Helper loaded: form_helper
INFO - 2018-03-23 19:23:24 --> Form Validation Class Initialized
INFO - 2018-03-23 19:23:24 --> Controller Class Initialized
INFO - 2018-03-23 19:23:24 --> Model Class Initialized
INFO - 2018-03-23 19:23:24 --> Helper loaded: inflector_helper
DEBUG - 2018-03-23 19:23:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-23 19:23:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-23 19:23:24 --> Model Class Initialized
INFO - 2018-03-23 19:23:24 --> Model Class Initialized
INFO - 2018-03-23 19:23:24 --> Model Class Initialized
INFO - 2018-03-23 19:23:24 --> Model Class Initialized
INFO - 2018-03-23 19:23:24 --> Model Class Initialized
INFO - 2018-03-23 19:23:24 --> Model Class Initialized
INFO - 2018-03-23 19:23:24 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-23 19:23:24 --> Model Class Initialized
INFO - 2018-03-23 19:23:24 --> Model Class Initialized
INFO - 2018-03-23 19:23:24 --> Final output sent to browser
DEBUG - 2018-03-23 19:23:24 --> Total execution time: 0.2026
INFO - 2018-03-23 13:53:24 --> Config Class Initialized
INFO - 2018-03-23 13:53:24 --> Hooks Class Initialized
DEBUG - 2018-03-23 13:53:24 --> UTF-8 Support Enabled
INFO - 2018-03-23 13:53:24 --> Utf8 Class Initialized
INFO - 2018-03-23 13:53:24 --> URI Class Initialized
INFO - 2018-03-23 13:53:24 --> Router Class Initialized
INFO - 2018-03-23 13:53:24 --> Output Class Initialized
INFO - 2018-03-23 13:53:24 --> Security Class Initialized
DEBUG - 2018-03-23 13:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 13:53:24 --> Input Class Initialized
INFO - 2018-03-23 13:53:24 --> Language Class Initialized
INFO - 2018-03-23 13:53:24 --> Language Class Initialized
INFO - 2018-03-23 13:53:24 --> Config Class Initialized
INFO - 2018-03-23 13:53:24 --> Loader Class Initialized
INFO - 2018-03-23 19:23:24 --> Helper loaded: url_helper
INFO - 2018-03-23 19:23:24 --> Helper loaded: notification_helper
INFO - 2018-03-23 19:23:24 --> Helper loaded: settings_helper
INFO - 2018-03-23 19:23:24 --> Helper loaded: permission_helper
INFO - 2018-03-23 19:23:24 --> Helper loaded: users_helper
INFO - 2018-03-23 19:23:25 --> Database Driver Class Initialized
DEBUG - 2018-03-23 19:23:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 19:23:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 19:23:25 --> Helper loaded: form_helper
INFO - 2018-03-23 19:23:25 --> Form Validation Class Initialized
INFO - 2018-03-23 19:23:25 --> Controller Class Initialized
INFO - 2018-03-23 19:23:26 --> Model Class Initialized
INFO - 2018-03-23 19:23:26 --> Helper loaded: inflector_helper
DEBUG - 2018-03-23 19:23:26 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-23 19:23:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-23 19:23:26 --> Model Class Initialized
INFO - 2018-03-23 19:23:26 --> Model Class Initialized
INFO - 2018-03-23 19:23:26 --> Model Class Initialized
INFO - 2018-03-23 19:23:26 --> Model Class Initialized
INFO - 2018-03-23 19:23:26 --> Model Class Initialized
INFO - 2018-03-23 19:23:26 --> Model Class Initialized
INFO - 2018-03-23 19:23:26 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-23 19:23:26 --> Model Class Initialized
INFO - 2018-03-23 19:23:26 --> Model Class Initialized
INFO - 2018-03-23 19:23:26 --> Final output sent to browser
DEBUG - 2018-03-23 19:23:26 --> Total execution time: 2.4001
INFO - 2018-03-23 13:53:28 --> Config Class Initialized
INFO - 2018-03-23 13:53:28 --> Hooks Class Initialized
DEBUG - 2018-03-23 13:53:28 --> UTF-8 Support Enabled
INFO - 2018-03-23 13:53:28 --> Utf8 Class Initialized
INFO - 2018-03-23 13:53:28 --> URI Class Initialized
INFO - 2018-03-23 13:53:28 --> Router Class Initialized
INFO - 2018-03-23 13:53:28 --> Output Class Initialized
INFO - 2018-03-23 13:53:28 --> Security Class Initialized
DEBUG - 2018-03-23 13:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 13:53:28 --> Input Class Initialized
INFO - 2018-03-23 13:53:28 --> Language Class Initialized
INFO - 2018-03-23 13:53:28 --> Language Class Initialized
INFO - 2018-03-23 13:53:28 --> Config Class Initialized
INFO - 2018-03-23 13:53:28 --> Loader Class Initialized
INFO - 2018-03-23 19:23:28 --> Helper loaded: url_helper
INFO - 2018-03-23 19:23:28 --> Helper loaded: notification_helper
INFO - 2018-03-23 19:23:28 --> Helper loaded: settings_helper
INFO - 2018-03-23 19:23:28 --> Helper loaded: permission_helper
INFO - 2018-03-23 19:23:28 --> Helper loaded: users_helper
INFO - 2018-03-23 19:23:28 --> Database Driver Class Initialized
DEBUG - 2018-03-23 19:23:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 19:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 19:23:28 --> Helper loaded: form_helper
INFO - 2018-03-23 19:23:28 --> Form Validation Class Initialized
INFO - 2018-03-23 19:23:28 --> Controller Class Initialized
INFO - 2018-03-23 19:23:28 --> Model Class Initialized
INFO - 2018-03-23 19:23:28 --> Helper loaded: inflector_helper
DEBUG - 2018-03-23 19:23:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-23 19:23:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-23 19:23:28 --> Model Class Initialized
INFO - 2018-03-23 19:23:28 --> Model Class Initialized
INFO - 2018-03-23 19:23:28 --> Model Class Initialized
INFO - 2018-03-23 19:23:28 --> Model Class Initialized
INFO - 2018-03-23 19:23:28 --> Model Class Initialized
INFO - 2018-03-23 19:23:28 --> Model Class Initialized
INFO - 2018-03-23 19:23:28 --> Model Class Initialized
INFO - 2018-03-23 19:23:28 --> Model Class Initialized
INFO - 2018-03-23 19:23:28 --> Model Class Initialized
INFO - 2018-03-23 19:23:28 --> Model Class Initialized
INFO - 2018-03-23 19:23:28 --> Model Class Initialized
INFO - 2018-03-23 19:23:28 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-23 19:23:28 --> Model Class Initialized
INFO - 2018-03-23 19:23:28 --> Final output sent to browser
DEBUG - 2018-03-23 19:23:28 --> Total execution time: 0.1696
INFO - 2018-03-23 13:53:29 --> Config Class Initialized
INFO - 2018-03-23 13:53:29 --> Hooks Class Initialized
DEBUG - 2018-03-23 13:53:30 --> UTF-8 Support Enabled
INFO - 2018-03-23 13:53:30 --> Utf8 Class Initialized
INFO - 2018-03-23 13:53:30 --> URI Class Initialized
INFO - 2018-03-23 13:53:30 --> Router Class Initialized
INFO - 2018-03-23 13:53:30 --> Output Class Initialized
INFO - 2018-03-23 13:53:30 --> Security Class Initialized
DEBUG - 2018-03-23 13:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 13:53:31 --> Input Class Initialized
INFO - 2018-03-23 13:53:31 --> Language Class Initialized
INFO - 2018-03-23 13:53:32 --> Language Class Initialized
INFO - 2018-03-23 13:53:32 --> Config Class Initialized
INFO - 2018-03-23 13:53:32 --> Loader Class Initialized
INFO - 2018-03-23 19:23:32 --> Helper loaded: url_helper
INFO - 2018-03-23 19:23:32 --> Helper loaded: notification_helper
INFO - 2018-03-23 19:23:32 --> Helper loaded: settings_helper
INFO - 2018-03-23 19:23:32 --> Helper loaded: permission_helper
INFO - 2018-03-23 19:23:32 --> Helper loaded: users_helper
INFO - 2018-03-23 19:23:33 --> Database Driver Class Initialized
DEBUG - 2018-03-23 19:23:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 19:23:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 19:23:34 --> Helper loaded: form_helper
INFO - 2018-03-23 19:23:34 --> Form Validation Class Initialized
INFO - 2018-03-23 19:23:34 --> Controller Class Initialized
INFO - 2018-03-23 19:23:35 --> Model Class Initialized
INFO - 2018-03-23 19:23:35 --> Helper loaded: inflector_helper
DEBUG - 2018-03-23 19:23:35 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-23 19:23:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-23 19:23:35 --> Model Class Initialized
INFO - 2018-03-23 19:23:35 --> Model Class Initialized
INFO - 2018-03-23 19:23:35 --> Model Class Initialized
INFO - 2018-03-23 19:23:35 --> Model Class Initialized
INFO - 2018-03-23 19:23:35 --> Model Class Initialized
INFO - 2018-03-23 19:23:35 --> Model Class Initialized
INFO - 2018-03-23 19:23:35 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-23 19:23:35 --> Model Class Initialized
INFO - 2018-03-23 19:23:35 --> Model Class Initialized
INFO - 2018-03-23 19:23:35 --> Final output sent to browser
DEBUG - 2018-03-23 19:23:35 --> Total execution time: 6.3034
INFO - 2018-03-23 13:53:45 --> Config Class Initialized
INFO - 2018-03-23 13:53:45 --> Hooks Class Initialized
DEBUG - 2018-03-23 13:53:45 --> UTF-8 Support Enabled
INFO - 2018-03-23 13:53:45 --> Utf8 Class Initialized
INFO - 2018-03-23 13:53:45 --> URI Class Initialized
INFO - 2018-03-23 13:53:45 --> Router Class Initialized
INFO - 2018-03-23 13:53:45 --> Output Class Initialized
INFO - 2018-03-23 13:53:45 --> Security Class Initialized
DEBUG - 2018-03-23 13:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 13:53:45 --> Input Class Initialized
INFO - 2018-03-23 13:53:45 --> Language Class Initialized
INFO - 2018-03-23 13:53:45 --> Language Class Initialized
INFO - 2018-03-23 13:53:45 --> Config Class Initialized
INFO - 2018-03-23 13:53:45 --> Loader Class Initialized
INFO - 2018-03-23 19:23:45 --> Helper loaded: url_helper
INFO - 2018-03-23 19:23:45 --> Helper loaded: notification_helper
INFO - 2018-03-23 19:23:45 --> Helper loaded: settings_helper
INFO - 2018-03-23 19:23:45 --> Helper loaded: permission_helper
INFO - 2018-03-23 19:23:45 --> Helper loaded: users_helper
INFO - 2018-03-23 19:23:45 --> Database Driver Class Initialized
DEBUG - 2018-03-23 19:23:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 19:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 19:23:45 --> Helper loaded: form_helper
INFO - 2018-03-23 19:23:45 --> Form Validation Class Initialized
INFO - 2018-03-23 19:23:45 --> Controller Class Initialized
INFO - 2018-03-23 19:23:45 --> Model Class Initialized
INFO - 2018-03-23 19:23:45 --> Helper loaded: inflector_helper
DEBUG - 2018-03-23 19:23:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-23 19:23:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-23 19:23:45 --> Model Class Initialized
INFO - 2018-03-23 19:23:45 --> Model Class Initialized
INFO - 2018-03-23 19:23:45 --> Model Class Initialized
INFO - 2018-03-23 19:23:45 --> Model Class Initialized
INFO - 2018-03-23 19:23:45 --> Model Class Initialized
INFO - 2018-03-23 19:23:45 --> Model Class Initialized
INFO - 2018-03-23 19:23:45 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-23 19:23:45 --> Model Class Initialized
INFO - 2018-03-23 19:23:45 --> Model Class Initialized
INFO - 2018-03-23 19:23:45 --> Final output sent to browser
DEBUG - 2018-03-23 19:23:45 --> Total execution time: 0.2786
INFO - 2018-03-23 13:53:46 --> Config Class Initialized
INFO - 2018-03-23 13:53:46 --> Hooks Class Initialized
DEBUG - 2018-03-23 13:53:46 --> UTF-8 Support Enabled
INFO - 2018-03-23 13:53:46 --> Utf8 Class Initialized
INFO - 2018-03-23 13:53:46 --> URI Class Initialized
INFO - 2018-03-23 13:53:46 --> Router Class Initialized
INFO - 2018-03-23 13:53:46 --> Output Class Initialized
INFO - 2018-03-23 13:53:46 --> Security Class Initialized
DEBUG - 2018-03-23 13:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 13:53:46 --> Input Class Initialized
INFO - 2018-03-23 13:53:46 --> Language Class Initialized
INFO - 2018-03-23 13:53:46 --> Language Class Initialized
INFO - 2018-03-23 13:53:46 --> Config Class Initialized
INFO - 2018-03-23 13:53:46 --> Loader Class Initialized
INFO - 2018-03-23 19:23:46 --> Helper loaded: url_helper
INFO - 2018-03-23 19:23:46 --> Helper loaded: notification_helper
INFO - 2018-03-23 19:23:46 --> Helper loaded: settings_helper
INFO - 2018-03-23 19:23:46 --> Helper loaded: permission_helper
INFO - 2018-03-23 19:23:46 --> Helper loaded: users_helper
INFO - 2018-03-23 19:23:46 --> Database Driver Class Initialized
DEBUG - 2018-03-23 19:23:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 19:23:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 19:23:46 --> Helper loaded: form_helper
INFO - 2018-03-23 19:23:46 --> Form Validation Class Initialized
INFO - 2018-03-23 19:23:46 --> Controller Class Initialized
INFO - 2018-03-23 19:23:46 --> Model Class Initialized
INFO - 2018-03-23 19:23:46 --> Helper loaded: inflector_helper
DEBUG - 2018-03-23 19:23:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-23 19:23:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-23 19:23:46 --> Model Class Initialized
INFO - 2018-03-23 19:23:46 --> Model Class Initialized
INFO - 2018-03-23 19:23:46 --> Model Class Initialized
INFO - 2018-03-23 19:23:46 --> Model Class Initialized
INFO - 2018-03-23 19:23:46 --> Model Class Initialized
INFO - 2018-03-23 19:23:46 --> Model Class Initialized
INFO - 2018-03-23 19:23:46 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-23 19:23:46 --> Model Class Initialized
INFO - 2018-03-23 19:23:46 --> Model Class Initialized
INFO - 2018-03-23 19:23:46 --> Final output sent to browser
DEBUG - 2018-03-23 19:23:46 --> Total execution time: 0.2579
INFO - 2018-03-23 13:53:47 --> Config Class Initialized
INFO - 2018-03-23 13:53:47 --> Hooks Class Initialized
DEBUG - 2018-03-23 13:53:47 --> UTF-8 Support Enabled
INFO - 2018-03-23 13:53:47 --> Utf8 Class Initialized
INFO - 2018-03-23 13:53:47 --> URI Class Initialized
INFO - 2018-03-23 13:53:47 --> Router Class Initialized
INFO - 2018-03-23 13:53:47 --> Output Class Initialized
INFO - 2018-03-23 13:53:47 --> Security Class Initialized
DEBUG - 2018-03-23 13:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 13:53:47 --> Input Class Initialized
INFO - 2018-03-23 13:53:47 --> Language Class Initialized
INFO - 2018-03-23 13:53:47 --> Language Class Initialized
INFO - 2018-03-23 13:53:47 --> Config Class Initialized
INFO - 2018-03-23 13:53:47 --> Loader Class Initialized
INFO - 2018-03-23 19:23:48 --> Helper loaded: url_helper
INFO - 2018-03-23 19:23:48 --> Helper loaded: notification_helper
INFO - 2018-03-23 19:23:48 --> Helper loaded: settings_helper
INFO - 2018-03-23 19:23:48 --> Helper loaded: permission_helper
INFO - 2018-03-23 19:23:48 --> Helper loaded: users_helper
INFO - 2018-03-23 19:23:48 --> Database Driver Class Initialized
DEBUG - 2018-03-23 19:23:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 19:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 19:23:48 --> Helper loaded: form_helper
INFO - 2018-03-23 19:23:48 --> Form Validation Class Initialized
INFO - 2018-03-23 19:23:48 --> Controller Class Initialized
INFO - 2018-03-23 19:23:48 --> Model Class Initialized
INFO - 2018-03-23 19:23:48 --> Helper loaded: inflector_helper
DEBUG - 2018-03-23 19:23:48 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-23 19:23:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-23 19:23:48 --> Model Class Initialized
INFO - 2018-03-23 19:23:48 --> Model Class Initialized
INFO - 2018-03-23 19:23:48 --> Model Class Initialized
INFO - 2018-03-23 19:23:48 --> Model Class Initialized
INFO - 2018-03-23 19:23:48 --> Model Class Initialized
INFO - 2018-03-23 19:23:48 --> Model Class Initialized
INFO - 2018-03-23 19:23:48 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-23 19:23:48 --> Model Class Initialized
INFO - 2018-03-23 19:23:48 --> Model Class Initialized
INFO - 2018-03-23 19:23:48 --> Final output sent to browser
DEBUG - 2018-03-23 19:23:48 --> Total execution time: 1.5208
INFO - 2018-03-23 13:53:49 --> Config Class Initialized
INFO - 2018-03-23 13:53:49 --> Hooks Class Initialized
DEBUG - 2018-03-23 13:53:49 --> UTF-8 Support Enabled
INFO - 2018-03-23 13:53:49 --> Utf8 Class Initialized
INFO - 2018-03-23 13:53:49 --> URI Class Initialized
INFO - 2018-03-23 13:53:49 --> Router Class Initialized
INFO - 2018-03-23 13:53:49 --> Output Class Initialized
INFO - 2018-03-23 13:53:49 --> Security Class Initialized
DEBUG - 2018-03-23 13:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 13:53:49 --> Input Class Initialized
INFO - 2018-03-23 13:53:49 --> Language Class Initialized
INFO - 2018-03-23 13:53:49 --> Language Class Initialized
INFO - 2018-03-23 13:53:49 --> Config Class Initialized
INFO - 2018-03-23 13:53:49 --> Loader Class Initialized
INFO - 2018-03-23 19:23:49 --> Helper loaded: url_helper
INFO - 2018-03-23 19:23:49 --> Helper loaded: notification_helper
INFO - 2018-03-23 19:23:49 --> Helper loaded: settings_helper
INFO - 2018-03-23 19:23:49 --> Helper loaded: permission_helper
INFO - 2018-03-23 19:23:49 --> Helper loaded: users_helper
INFO - 2018-03-23 19:23:49 --> Database Driver Class Initialized
DEBUG - 2018-03-23 19:23:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 19:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 19:23:49 --> Helper loaded: form_helper
INFO - 2018-03-23 19:23:49 --> Form Validation Class Initialized
INFO - 2018-03-23 19:23:49 --> Controller Class Initialized
INFO - 2018-03-23 19:23:49 --> Model Class Initialized
INFO - 2018-03-23 19:23:49 --> Helper loaded: inflector_helper
DEBUG - 2018-03-23 19:23:49 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-23 19:23:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-23 19:23:49 --> Model Class Initialized
INFO - 2018-03-23 19:23:49 --> Model Class Initialized
INFO - 2018-03-23 19:23:49 --> Model Class Initialized
INFO - 2018-03-23 19:23:49 --> Model Class Initialized
INFO - 2018-03-23 19:23:49 --> Model Class Initialized
INFO - 2018-03-23 19:23:49 --> Model Class Initialized
INFO - 2018-03-23 19:23:49 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-23 19:23:49 --> Model Class Initialized
INFO - 2018-03-23 19:23:49 --> Model Class Initialized
INFO - 2018-03-23 19:23:49 --> Final output sent to browser
DEBUG - 2018-03-23 19:23:49 --> Total execution time: 0.4641
INFO - 2018-03-23 13:53:49 --> Config Class Initialized
INFO - 2018-03-23 13:53:49 --> Hooks Class Initialized
DEBUG - 2018-03-23 13:53:49 --> UTF-8 Support Enabled
INFO - 2018-03-23 13:53:49 --> Utf8 Class Initialized
INFO - 2018-03-23 13:53:49 --> URI Class Initialized
INFO - 2018-03-23 13:53:49 --> Router Class Initialized
INFO - 2018-03-23 13:53:49 --> Output Class Initialized
INFO - 2018-03-23 13:53:49 --> Security Class Initialized
INFO - 2018-03-23 13:53:49 --> Config Class Initialized
INFO - 2018-03-23 13:53:49 --> Hooks Class Initialized
DEBUG - 2018-03-23 13:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 13:53:49 --> Input Class Initialized
INFO - 2018-03-23 13:53:49 --> Language Class Initialized
INFO - 2018-03-23 13:53:49 --> Language Class Initialized
INFO - 2018-03-23 13:53:49 --> Config Class Initialized
INFO - 2018-03-23 13:53:49 --> Loader Class Initialized
INFO - 2018-03-23 19:23:49 --> Helper loaded: url_helper
INFO - 2018-03-23 19:23:49 --> Helper loaded: notification_helper
INFO - 2018-03-23 19:23:49 --> Helper loaded: settings_helper
INFO - 2018-03-23 19:23:49 --> Helper loaded: permission_helper
INFO - 2018-03-23 19:23:49 --> Helper loaded: users_helper
DEBUG - 2018-03-23 13:53:49 --> UTF-8 Support Enabled
INFO - 2018-03-23 13:53:49 --> Utf8 Class Initialized
INFO - 2018-03-23 19:23:49 --> Database Driver Class Initialized
DEBUG - 2018-03-23 19:23:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 19:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 19:23:50 --> Helper loaded: form_helper
INFO - 2018-03-23 19:23:50 --> Form Validation Class Initialized
INFO - 2018-03-23 19:23:50 --> Controller Class Initialized
INFO - 2018-03-23 13:53:50 --> URI Class Initialized
INFO - 2018-03-23 19:23:50 --> Model Class Initialized
INFO - 2018-03-23 19:23:50 --> Helper loaded: inflector_helper
DEBUG - 2018-03-23 19:23:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-23 19:23:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-23 19:23:50 --> Model Class Initialized
INFO - 2018-03-23 19:23:50 --> Model Class Initialized
INFO - 2018-03-23 19:23:50 --> Model Class Initialized
INFO - 2018-03-23 19:23:50 --> Model Class Initialized
INFO - 2018-03-23 19:23:50 --> Model Class Initialized
INFO - 2018-03-23 19:23:50 --> Model Class Initialized
INFO - 2018-03-23 19:23:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-23 19:23:50 --> Model Class Initialized
INFO - 2018-03-23 19:23:50 --> Model Class Initialized
INFO - 2018-03-23 19:23:50 --> Final output sent to browser
DEBUG - 2018-03-23 19:23:50 --> Total execution time: 0.3342
INFO - 2018-03-23 13:53:50 --> Router Class Initialized
INFO - 2018-03-23 13:53:50 --> Output Class Initialized
INFO - 2018-03-23 13:53:50 --> Security Class Initialized
DEBUG - 2018-03-23 13:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 13:53:50 --> Input Class Initialized
INFO - 2018-03-23 13:53:50 --> Language Class Initialized
INFO - 2018-03-23 13:53:50 --> Language Class Initialized
INFO - 2018-03-23 13:53:50 --> Config Class Initialized
INFO - 2018-03-23 13:53:50 --> Loader Class Initialized
INFO - 2018-03-23 19:23:50 --> Helper loaded: url_helper
INFO - 2018-03-23 19:23:50 --> Helper loaded: notification_helper
INFO - 2018-03-23 19:23:50 --> Helper loaded: settings_helper
INFO - 2018-03-23 19:23:50 --> Helper loaded: permission_helper
INFO - 2018-03-23 19:23:50 --> Helper loaded: users_helper
INFO - 2018-03-23 13:53:50 --> Config Class Initialized
INFO - 2018-03-23 13:53:50 --> Hooks Class Initialized
INFO - 2018-03-23 13:53:50 --> Config Class Initialized
INFO - 2018-03-23 13:53:50 --> Hooks Class Initialized
DEBUG - 2018-03-23 13:53:50 --> UTF-8 Support Enabled
INFO - 2018-03-23 13:53:50 --> Utf8 Class Initialized
INFO - 2018-03-23 13:53:50 --> URI Class Initialized
INFO - 2018-03-23 13:53:50 --> Router Class Initialized
INFO - 2018-03-23 13:53:50 --> Output Class Initialized
INFO - 2018-03-23 13:53:50 --> Security Class Initialized
DEBUG - 2018-03-23 13:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 13:53:50 --> Input Class Initialized
INFO - 2018-03-23 13:53:50 --> Language Class Initialized
DEBUG - 2018-03-23 13:53:50 --> UTF-8 Support Enabled
INFO - 2018-03-23 13:53:50 --> Utf8 Class Initialized
INFO - 2018-03-23 13:53:50 --> Language Class Initialized
INFO - 2018-03-23 13:53:50 --> Config Class Initialized
INFO - 2018-03-23 13:53:50 --> Loader Class Initialized
INFO - 2018-03-23 19:23:50 --> Helper loaded: url_helper
INFO - 2018-03-23 19:23:50 --> Helper loaded: notification_helper
INFO - 2018-03-23 19:23:50 --> Helper loaded: settings_helper
INFO - 2018-03-23 19:23:50 --> Helper loaded: permission_helper
INFO - 2018-03-23 19:23:50 --> Helper loaded: users_helper
INFO - 2018-03-23 19:23:50 --> Database Driver Class Initialized
DEBUG - 2018-03-23 19:23:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 19:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 13:53:50 --> URI Class Initialized
INFO - 2018-03-23 19:23:50 --> Helper loaded: form_helper
INFO - 2018-03-23 19:23:50 --> Form Validation Class Initialized
INFO - 2018-03-23 19:23:50 --> Controller Class Initialized
INFO - 2018-03-23 19:23:50 --> Model Class Initialized
INFO - 2018-03-23 19:23:50 --> Helper loaded: inflector_helper
DEBUG - 2018-03-23 19:23:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-23 19:23:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-23 19:23:50 --> Model Class Initialized
INFO - 2018-03-23 19:23:50 --> Model Class Initialized
INFO - 2018-03-23 19:23:50 --> Model Class Initialized
INFO - 2018-03-23 19:23:50 --> Model Class Initialized
INFO - 2018-03-23 19:23:50 --> Model Class Initialized
INFO - 2018-03-23 19:23:50 --> Model Class Initialized
INFO - 2018-03-23 19:23:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-23 19:23:50 --> Model Class Initialized
INFO - 2018-03-23 19:23:50 --> Model Class Initialized
INFO - 2018-03-23 19:23:50 --> Final output sent to browser
DEBUG - 2018-03-23 19:23:50 --> Total execution time: 0.3277
INFO - 2018-03-23 13:53:51 --> Router Class Initialized
INFO - 2018-03-23 13:53:51 --> Output Class Initialized
INFO - 2018-03-23 19:23:51 --> Database Driver Class Initialized
DEBUG - 2018-03-23 19:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 19:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 13:53:51 --> Security Class Initialized
INFO - 2018-03-23 19:23:51 --> Helper loaded: form_helper
INFO - 2018-03-23 19:23:51 --> Form Validation Class Initialized
INFO - 2018-03-23 19:23:51 --> Controller Class Initialized
INFO - 2018-03-23 19:23:51 --> Model Class Initialized
INFO - 2018-03-23 19:23:51 --> Helper loaded: inflector_helper
DEBUG - 2018-03-23 19:23:51 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-23 19:23:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-23 19:23:51 --> Model Class Initialized
INFO - 2018-03-23 19:23:51 --> Model Class Initialized
INFO - 2018-03-23 19:23:51 --> Model Class Initialized
INFO - 2018-03-23 19:23:51 --> Model Class Initialized
INFO - 2018-03-23 19:23:51 --> Model Class Initialized
INFO - 2018-03-23 19:23:51 --> Model Class Initialized
INFO - 2018-03-23 19:23:51 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-23 19:23:51 --> Model Class Initialized
INFO - 2018-03-23 19:23:51 --> Model Class Initialized
INFO - 2018-03-23 19:23:51 --> Model Class Initialized
DEBUG - 2018-03-23 13:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 13:53:51 --> Input Class Initialized
INFO - 2018-03-23 13:53:51 --> Language Class Initialized
INFO - 2018-03-23 13:53:51 --> Config Class Initialized
INFO - 2018-03-23 13:53:51 --> Hooks Class Initialized
DEBUG - 2018-03-23 13:53:51 --> UTF-8 Support Enabled
INFO - 2018-03-23 13:53:51 --> Utf8 Class Initialized
INFO - 2018-03-23 13:53:51 --> URI Class Initialized
INFO - 2018-03-23 13:53:51 --> Router Class Initialized
INFO - 2018-03-23 13:53:51 --> Output Class Initialized
INFO - 2018-03-23 13:53:51 --> Security Class Initialized
DEBUG - 2018-03-23 13:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 13:53:51 --> Input Class Initialized
INFO - 2018-03-23 13:53:51 --> Language Class Initialized
INFO - 2018-03-23 13:53:51 --> Language Class Initialized
INFO - 2018-03-23 13:53:51 --> Config Class Initialized
INFO - 2018-03-23 13:53:51 --> Loader Class Initialized
INFO - 2018-03-23 19:23:51 --> Helper loaded: url_helper
INFO - 2018-03-23 19:23:51 --> Helper loaded: notification_helper
INFO - 2018-03-23 19:23:51 --> Helper loaded: settings_helper
INFO - 2018-03-23 19:23:51 --> Helper loaded: permission_helper
INFO - 2018-03-23 19:23:51 --> Helper loaded: users_helper
INFO - 2018-03-23 19:23:51 --> Database Driver Class Initialized
DEBUG - 2018-03-23 19:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 19:23:51 --> Final output sent to browser
DEBUG - 2018-03-23 19:23:51 --> Total execution time: 2.0542
INFO - 2018-03-23 19:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 19:23:51 --> Helper loaded: form_helper
INFO - 2018-03-23 19:23:51 --> Form Validation Class Initialized
INFO - 2018-03-23 19:23:51 --> Controller Class Initialized
INFO - 2018-03-23 19:23:51 --> Model Class Initialized
INFO - 2018-03-23 19:23:51 --> Helper loaded: inflector_helper
DEBUG - 2018-03-23 19:23:51 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-23 19:23:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-23 19:23:51 --> Model Class Initialized
INFO - 2018-03-23 19:23:51 --> Model Class Initialized
INFO - 2018-03-23 19:23:51 --> Model Class Initialized
INFO - 2018-03-23 19:23:51 --> Model Class Initialized
INFO - 2018-03-23 19:23:51 --> Model Class Initialized
INFO - 2018-03-23 19:23:51 --> Model Class Initialized
INFO - 2018-03-23 19:23:51 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-23 19:23:51 --> Model Class Initialized
INFO - 2018-03-23 19:23:51 --> Model Class Initialized
INFO - 2018-03-23 19:23:51 --> Model Class Initialized
INFO - 2018-03-23 13:53:52 --> Language Class Initialized
INFO - 2018-03-23 13:53:52 --> Config Class Initialized
INFO - 2018-03-23 13:53:52 --> Loader Class Initialized
INFO - 2018-03-23 19:23:52 --> Helper loaded: url_helper
INFO - 2018-03-23 19:23:52 --> Helper loaded: notification_helper
INFO - 2018-03-23 13:53:52 --> Config Class Initialized
INFO - 2018-03-23 13:53:52 --> Hooks Class Initialized
DEBUG - 2018-03-23 13:53:52 --> UTF-8 Support Enabled
INFO - 2018-03-23 13:53:52 --> Utf8 Class Initialized
INFO - 2018-03-23 13:53:52 --> URI Class Initialized
INFO - 2018-03-23 13:53:52 --> Router Class Initialized
INFO - 2018-03-23 19:23:52 --> Helper loaded: settings_helper
INFO - 2018-03-23 13:53:52 --> Output Class Initialized
INFO - 2018-03-23 13:53:52 --> Security Class Initialized
DEBUG - 2018-03-23 13:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 13:53:52 --> Input Class Initialized
INFO - 2018-03-23 13:53:52 --> Language Class Initialized
INFO - 2018-03-23 19:23:52 --> Helper loaded: permission_helper
INFO - 2018-03-23 13:53:52 --> Language Class Initialized
INFO - 2018-03-23 13:53:52 --> Config Class Initialized
INFO - 2018-03-23 13:53:52 --> Loader Class Initialized
INFO - 2018-03-23 19:23:52 --> Helper loaded: users_helper
INFO - 2018-03-23 19:23:52 --> Helper loaded: url_helper
INFO - 2018-03-23 19:23:52 --> Helper loaded: notification_helper
INFO - 2018-03-23 19:23:52 --> Helper loaded: settings_helper
INFO - 2018-03-23 19:23:52 --> Helper loaded: permission_helper
INFO - 2018-03-23 19:23:52 --> Helper loaded: users_helper
INFO - 2018-03-23 19:23:52 --> Database Driver Class Initialized
DEBUG - 2018-03-23 19:23:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 19:23:52 --> Database Driver Class Initialized
DEBUG - 2018-03-23 19:23:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 19:23:52 --> Final output sent to browser
DEBUG - 2018-03-23 19:23:52 --> Total execution time: 1.2916
INFO - 2018-03-23 19:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 19:23:52 --> Helper loaded: form_helper
INFO - 2018-03-23 19:23:52 --> Form Validation Class Initialized
INFO - 2018-03-23 19:23:52 --> Controller Class Initialized
INFO - 2018-03-23 19:23:52 --> Model Class Initialized
INFO - 2018-03-23 19:23:52 --> Helper loaded: inflector_helper
DEBUG - 2018-03-23 19:23:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-23 19:23:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-23 19:23:52 --> Model Class Initialized
INFO - 2018-03-23 19:23:52 --> Model Class Initialized
INFO - 2018-03-23 19:23:52 --> Model Class Initialized
INFO - 2018-03-23 19:23:52 --> Model Class Initialized
INFO - 2018-03-23 19:23:52 --> Model Class Initialized
INFO - 2018-03-23 19:23:52 --> Model Class Initialized
INFO - 2018-03-23 19:23:52 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-23 19:23:52 --> Model Class Initialized
INFO - 2018-03-23 19:23:52 --> Model Class Initialized
INFO - 2018-03-23 19:23:52 --> Final output sent to browser
DEBUG - 2018-03-23 19:23:52 --> Total execution time: 0.5703
INFO - 2018-03-23 19:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 19:23:52 --> Helper loaded: form_helper
INFO - 2018-03-23 19:23:52 --> Form Validation Class Initialized
INFO - 2018-03-23 19:23:52 --> Controller Class Initialized
INFO - 2018-03-23 19:23:52 --> Model Class Initialized
INFO - 2018-03-23 19:23:52 --> Helper loaded: inflector_helper
DEBUG - 2018-03-23 19:23:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-23 19:23:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-23 19:23:52 --> Model Class Initialized
INFO - 2018-03-23 19:23:52 --> Model Class Initialized
INFO - 2018-03-23 19:23:52 --> Model Class Initialized
INFO - 2018-03-23 19:23:52 --> Model Class Initialized
INFO - 2018-03-23 19:23:52 --> Model Class Initialized
INFO - 2018-03-23 19:23:52 --> Model Class Initialized
INFO - 2018-03-23 19:23:52 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-23 19:23:52 --> Model Class Initialized
INFO - 2018-03-23 19:23:52 --> Model Class Initialized
INFO - 2018-03-23 19:23:52 --> Final output sent to browser
DEBUG - 2018-03-23 19:23:52 --> Total execution time: 2.4391
INFO - 2018-03-23 13:53:53 --> Config Class Initialized
INFO - 2018-03-23 13:53:53 --> Hooks Class Initialized
DEBUG - 2018-03-23 13:53:53 --> UTF-8 Support Enabled
INFO - 2018-03-23 13:53:53 --> Utf8 Class Initialized
INFO - 2018-03-23 13:53:53 --> URI Class Initialized
INFO - 2018-03-23 13:53:53 --> Router Class Initialized
INFO - 2018-03-23 13:53:53 --> Output Class Initialized
INFO - 2018-03-23 13:53:53 --> Security Class Initialized
DEBUG - 2018-03-23 13:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 13:53:53 --> Input Class Initialized
INFO - 2018-03-23 13:53:53 --> Language Class Initialized
INFO - 2018-03-23 13:53:53 --> Language Class Initialized
INFO - 2018-03-23 13:53:53 --> Config Class Initialized
INFO - 2018-03-23 13:53:53 --> Loader Class Initialized
INFO - 2018-03-23 19:23:53 --> Helper loaded: url_helper
INFO - 2018-03-23 19:23:53 --> Helper loaded: notification_helper
INFO - 2018-03-23 19:23:53 --> Helper loaded: settings_helper
INFO - 2018-03-23 19:23:53 --> Helper loaded: permission_helper
INFO - 2018-03-23 19:23:53 --> Helper loaded: users_helper
INFO - 2018-03-23 19:23:53 --> Database Driver Class Initialized
DEBUG - 2018-03-23 19:23:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 19:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 19:23:53 --> Helper loaded: form_helper
INFO - 2018-03-23 19:23:53 --> Form Validation Class Initialized
INFO - 2018-03-23 19:23:53 --> Controller Class Initialized
INFO - 2018-03-23 19:23:53 --> Model Class Initialized
INFO - 2018-03-23 19:23:53 --> Helper loaded: inflector_helper
DEBUG - 2018-03-23 19:23:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-23 19:23:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-23 19:23:53 --> Model Class Initialized
INFO - 2018-03-23 19:23:53 --> Model Class Initialized
INFO - 2018-03-23 19:23:53 --> Model Class Initialized
INFO - 2018-03-23 19:23:53 --> Model Class Initialized
INFO - 2018-03-23 19:23:53 --> Model Class Initialized
INFO - 2018-03-23 19:23:53 --> Model Class Initialized
INFO - 2018-03-23 19:23:53 --> Model Class Initialized
INFO - 2018-03-23 19:23:53 --> Model Class Initialized
INFO - 2018-03-23 19:23:53 --> Model Class Initialized
INFO - 2018-03-23 19:23:53 --> Model Class Initialized
INFO - 2018-03-23 19:23:53 --> Model Class Initialized
INFO - 2018-03-23 19:23:53 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-23 19:23:53 --> Model Class Initialized
INFO - 2018-03-23 19:23:53 --> Final output sent to browser
DEBUG - 2018-03-23 19:23:53 --> Total execution time: 0.1721
INFO - 2018-03-23 13:53:56 --> Config Class Initialized
INFO - 2018-03-23 13:53:56 --> Hooks Class Initialized
DEBUG - 2018-03-23 13:53:56 --> UTF-8 Support Enabled
INFO - 2018-03-23 13:53:56 --> Utf8 Class Initialized
INFO - 2018-03-23 13:53:56 --> URI Class Initialized
INFO - 2018-03-23 13:53:56 --> Router Class Initialized
INFO - 2018-03-23 13:53:56 --> Output Class Initialized
INFO - 2018-03-23 13:53:56 --> Security Class Initialized
DEBUG - 2018-03-23 13:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 13:53:56 --> Input Class Initialized
INFO - 2018-03-23 13:53:56 --> Language Class Initialized
INFO - 2018-03-23 13:53:56 --> Language Class Initialized
INFO - 2018-03-23 13:53:56 --> Config Class Initialized
INFO - 2018-03-23 13:53:56 --> Loader Class Initialized
INFO - 2018-03-23 19:23:56 --> Helper loaded: url_helper
INFO - 2018-03-23 19:23:56 --> Helper loaded: notification_helper
INFO - 2018-03-23 19:23:56 --> Helper loaded: settings_helper
INFO - 2018-03-23 19:23:56 --> Helper loaded: permission_helper
INFO - 2018-03-23 19:23:56 --> Helper loaded: users_helper
INFO - 2018-03-23 19:23:56 --> Database Driver Class Initialized
DEBUG - 2018-03-23 19:23:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 19:23:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 19:23:56 --> Helper loaded: form_helper
INFO - 2018-03-23 19:23:56 --> Form Validation Class Initialized
INFO - 2018-03-23 19:23:56 --> Controller Class Initialized
INFO - 2018-03-23 19:23:56 --> Model Class Initialized
INFO - 2018-03-23 19:23:56 --> Helper loaded: inflector_helper
DEBUG - 2018-03-23 19:23:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-23 19:23:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-23 19:23:56 --> Model Class Initialized
INFO - 2018-03-23 19:23:56 --> Model Class Initialized
INFO - 2018-03-23 19:23:56 --> Model Class Initialized
INFO - 2018-03-23 19:23:56 --> Model Class Initialized
INFO - 2018-03-23 19:23:56 --> Model Class Initialized
INFO - 2018-03-23 19:23:56 --> Model Class Initialized
INFO - 2018-03-23 19:23:56 --> Model Class Initialized
INFO - 2018-03-23 19:23:56 --> Model Class Initialized
INFO - 2018-03-23 19:23:56 --> Model Class Initialized
INFO - 2018-03-23 19:23:56 --> Model Class Initialized
INFO - 2018-03-23 19:23:56 --> Model Class Initialized
INFO - 2018-03-23 19:23:56 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-23 19:23:56 --> Model Class Initialized
INFO - 2018-03-23 19:23:56 --> Final output sent to browser
DEBUG - 2018-03-23 19:23:56 --> Total execution time: 0.2919
INFO - 2018-03-23 13:53:59 --> Config Class Initialized
INFO - 2018-03-23 13:53:59 --> Hooks Class Initialized
DEBUG - 2018-03-23 13:53:59 --> UTF-8 Support Enabled
INFO - 2018-03-23 13:53:59 --> Utf8 Class Initialized
INFO - 2018-03-23 13:53:59 --> URI Class Initialized
INFO - 2018-03-23 13:53:59 --> Router Class Initialized
INFO - 2018-03-23 13:53:59 --> Output Class Initialized
INFO - 2018-03-23 13:53:59 --> Security Class Initialized
DEBUG - 2018-03-23 13:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 13:53:59 --> Input Class Initialized
INFO - 2018-03-23 13:53:59 --> Language Class Initialized
INFO - 2018-03-23 13:53:59 --> Language Class Initialized
INFO - 2018-03-23 13:53:59 --> Config Class Initialized
INFO - 2018-03-23 13:53:59 --> Loader Class Initialized
INFO - 2018-03-23 19:23:59 --> Helper loaded: url_helper
INFO - 2018-03-23 19:23:59 --> Helper loaded: notification_helper
INFO - 2018-03-23 19:23:59 --> Helper loaded: settings_helper
INFO - 2018-03-23 19:23:59 --> Helper loaded: permission_helper
INFO - 2018-03-23 19:23:59 --> Helper loaded: users_helper
INFO - 2018-03-23 19:23:59 --> Database Driver Class Initialized
DEBUG - 2018-03-23 19:23:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 19:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 19:24:00 --> Helper loaded: form_helper
INFO - 2018-03-23 19:24:00 --> Form Validation Class Initialized
INFO - 2018-03-23 19:24:00 --> Controller Class Initialized
INFO - 2018-03-23 19:24:00 --> Model Class Initialized
INFO - 2018-03-23 19:24:00 --> Helper loaded: inflector_helper
DEBUG - 2018-03-23 19:24:00 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-23 19:24:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-23 19:24:00 --> Model Class Initialized
INFO - 2018-03-23 19:24:00 --> Model Class Initialized
INFO - 2018-03-23 19:24:01 --> Model Class Initialized
INFO - 2018-03-23 19:24:01 --> Model Class Initialized
INFO - 2018-03-23 19:24:01 --> Final output sent to browser
DEBUG - 2018-03-23 19:24:01 --> Total execution time: 1.9862
INFO - 2018-03-23 13:54:03 --> Config Class Initialized
INFO - 2018-03-23 13:54:03 --> Hooks Class Initialized
DEBUG - 2018-03-23 13:54:03 --> UTF-8 Support Enabled
INFO - 2018-03-23 13:54:03 --> Utf8 Class Initialized
INFO - 2018-03-23 13:54:03 --> URI Class Initialized
INFO - 2018-03-23 13:54:03 --> Router Class Initialized
INFO - 2018-03-23 13:54:03 --> Output Class Initialized
INFO - 2018-03-23 13:54:03 --> Security Class Initialized
DEBUG - 2018-03-23 13:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 13:54:03 --> Input Class Initialized
INFO - 2018-03-23 13:54:03 --> Language Class Initialized
INFO - 2018-03-23 13:54:03 --> Language Class Initialized
INFO - 2018-03-23 13:54:03 --> Config Class Initialized
INFO - 2018-03-23 13:54:03 --> Loader Class Initialized
INFO - 2018-03-23 19:24:03 --> Helper loaded: url_helper
INFO - 2018-03-23 19:24:03 --> Helper loaded: notification_helper
INFO - 2018-03-23 19:24:03 --> Helper loaded: settings_helper
INFO - 2018-03-23 19:24:03 --> Helper loaded: permission_helper
INFO - 2018-03-23 19:24:03 --> Helper loaded: users_helper
INFO - 2018-03-23 19:24:03 --> Database Driver Class Initialized
DEBUG - 2018-03-23 19:24:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 19:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 19:24:03 --> Helper loaded: form_helper
INFO - 2018-03-23 19:24:03 --> Form Validation Class Initialized
INFO - 2018-03-23 19:24:03 --> Controller Class Initialized
INFO - 2018-03-23 19:24:03 --> Model Class Initialized
INFO - 2018-03-23 19:24:03 --> Helper loaded: inflector_helper
DEBUG - 2018-03-23 19:24:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-23 19:24:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-23 19:24:03 --> Model Class Initialized
INFO - 2018-03-23 19:24:03 --> Model Class Initialized
INFO - 2018-03-23 19:24:03 --> Model Class Initialized
INFO - 2018-03-23 19:24:03 --> Model Class Initialized
INFO - 2018-03-23 19:24:03 --> Final output sent to browser
DEBUG - 2018-03-23 19:24:03 --> Total execution time: 0.2707
INFO - 2018-03-23 13:54:09 --> Config Class Initialized
INFO - 2018-03-23 13:54:09 --> Hooks Class Initialized
DEBUG - 2018-03-23 13:54:09 --> UTF-8 Support Enabled
INFO - 2018-03-23 13:54:09 --> Utf8 Class Initialized
INFO - 2018-03-23 13:54:09 --> URI Class Initialized
INFO - 2018-03-23 13:54:10 --> Router Class Initialized
INFO - 2018-03-23 13:54:10 --> Output Class Initialized
INFO - 2018-03-23 13:54:10 --> Security Class Initialized
DEBUG - 2018-03-23 13:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 13:54:10 --> Input Class Initialized
INFO - 2018-03-23 13:54:10 --> Language Class Initialized
INFO - 2018-03-23 13:54:11 --> Language Class Initialized
INFO - 2018-03-23 13:54:11 --> Config Class Initialized
INFO - 2018-03-23 13:54:11 --> Loader Class Initialized
INFO - 2018-03-23 19:24:11 --> Helper loaded: url_helper
INFO - 2018-03-23 19:24:11 --> Helper loaded: notification_helper
INFO - 2018-03-23 19:24:11 --> Helper loaded: settings_helper
INFO - 2018-03-23 19:24:11 --> Helper loaded: permission_helper
INFO - 2018-03-23 19:24:12 --> Helper loaded: users_helper
INFO - 2018-03-23 19:24:13 --> Database Driver Class Initialized
DEBUG - 2018-03-23 19:24:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 19:24:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 19:24:13 --> Helper loaded: form_helper
INFO - 2018-03-23 19:24:13 --> Form Validation Class Initialized
INFO - 2018-03-23 19:24:13 --> Controller Class Initialized
INFO - 2018-03-23 19:24:14 --> Model Class Initialized
INFO - 2018-03-23 19:24:14 --> Helper loaded: inflector_helper
DEBUG - 2018-03-23 19:24:14 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-23 19:24:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-23 19:24:14 --> Model Class Initialized
INFO - 2018-03-23 19:24:14 --> Model Class Initialized
INFO - 2018-03-23 19:24:14 --> Model Class Initialized
INFO - 2018-03-23 19:24:14 --> Model Class Initialized
INFO - 2018-03-23 19:24:15 --> Final output sent to browser
DEBUG - 2018-03-23 19:24:15 --> Total execution time: 6.3159
INFO - 2018-03-23 13:54:17 --> Config Class Initialized
INFO - 2018-03-23 13:54:17 --> Hooks Class Initialized
DEBUG - 2018-03-23 13:54:17 --> UTF-8 Support Enabled
INFO - 2018-03-23 13:54:17 --> Utf8 Class Initialized
INFO - 2018-03-23 13:54:17 --> URI Class Initialized
INFO - 2018-03-23 13:54:17 --> Router Class Initialized
INFO - 2018-03-23 13:54:17 --> Output Class Initialized
INFO - 2018-03-23 13:54:17 --> Security Class Initialized
DEBUG - 2018-03-23 13:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 13:54:17 --> Input Class Initialized
INFO - 2018-03-23 13:54:17 --> Language Class Initialized
INFO - 2018-03-23 13:54:17 --> Language Class Initialized
INFO - 2018-03-23 13:54:17 --> Config Class Initialized
INFO - 2018-03-23 13:54:17 --> Loader Class Initialized
INFO - 2018-03-23 19:24:17 --> Helper loaded: url_helper
INFO - 2018-03-23 19:24:17 --> Helper loaded: notification_helper
INFO - 2018-03-23 19:24:17 --> Helper loaded: settings_helper
INFO - 2018-03-23 19:24:17 --> Helper loaded: permission_helper
INFO - 2018-03-23 19:24:17 --> Helper loaded: users_helper
INFO - 2018-03-23 19:24:17 --> Database Driver Class Initialized
DEBUG - 2018-03-23 19:24:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 19:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 19:24:17 --> Helper loaded: form_helper
INFO - 2018-03-23 19:24:17 --> Form Validation Class Initialized
INFO - 2018-03-23 19:24:17 --> Controller Class Initialized
INFO - 2018-03-23 19:24:17 --> Model Class Initialized
INFO - 2018-03-23 19:24:17 --> Helper loaded: inflector_helper
DEBUG - 2018-03-23 19:24:17 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-23 19:24:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-23 19:24:17 --> Model Class Initialized
INFO - 2018-03-23 19:24:17 --> Model Class Initialized
INFO - 2018-03-23 19:24:17 --> Model Class Initialized
INFO - 2018-03-23 19:24:17 --> Model Class Initialized
INFO - 2018-03-23 19:24:17 --> Final output sent to browser
DEBUG - 2018-03-23 19:24:17 --> Total execution time: 0.1037
INFO - 2018-03-23 13:54:19 --> Config Class Initialized
INFO - 2018-03-23 13:54:19 --> Hooks Class Initialized
DEBUG - 2018-03-23 13:54:19 --> UTF-8 Support Enabled
INFO - 2018-03-23 13:54:19 --> Utf8 Class Initialized
INFO - 2018-03-23 13:54:19 --> URI Class Initialized
INFO - 2018-03-23 13:54:19 --> Router Class Initialized
INFO - 2018-03-23 13:54:19 --> Output Class Initialized
INFO - 2018-03-23 13:54:19 --> Security Class Initialized
DEBUG - 2018-03-23 13:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 13:54:19 --> Input Class Initialized
INFO - 2018-03-23 13:54:19 --> Language Class Initialized
INFO - 2018-03-23 13:54:20 --> Language Class Initialized
INFO - 2018-03-23 13:54:20 --> Config Class Initialized
INFO - 2018-03-23 13:54:20 --> Loader Class Initialized
INFO - 2018-03-23 19:24:20 --> Helper loaded: url_helper
INFO - 2018-03-23 19:24:20 --> Helper loaded: notification_helper
INFO - 2018-03-23 19:24:20 --> Helper loaded: settings_helper
INFO - 2018-03-23 19:24:20 --> Helper loaded: permission_helper
INFO - 2018-03-23 19:24:20 --> Helper loaded: users_helper
INFO - 2018-03-23 19:24:20 --> Database Driver Class Initialized
DEBUG - 2018-03-23 19:24:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 19:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 19:24:21 --> Helper loaded: form_helper
INFO - 2018-03-23 19:24:21 --> Form Validation Class Initialized
INFO - 2018-03-23 19:24:21 --> Controller Class Initialized
INFO - 2018-03-23 19:24:21 --> Model Class Initialized
INFO - 2018-03-23 19:24:21 --> Helper loaded: inflector_helper
DEBUG - 2018-03-23 19:24:22 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-23 19:24:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-23 19:24:22 --> Model Class Initialized
INFO - 2018-03-23 19:24:22 --> Model Class Initialized
INFO - 2018-03-23 19:24:22 --> Model Class Initialized
INFO - 2018-03-23 19:24:22 --> Model Class Initialized
INFO - 2018-03-23 19:24:22 --> Final output sent to browser
DEBUG - 2018-03-23 19:24:22 --> Total execution time: 2.7744
INFO - 2018-03-23 13:54:24 --> Config Class Initialized
INFO - 2018-03-23 13:54:24 --> Hooks Class Initialized
DEBUG - 2018-03-23 13:54:24 --> UTF-8 Support Enabled
INFO - 2018-03-23 13:54:24 --> Utf8 Class Initialized
INFO - 2018-03-23 13:54:24 --> URI Class Initialized
INFO - 2018-03-23 13:54:24 --> Router Class Initialized
INFO - 2018-03-23 13:54:24 --> Output Class Initialized
INFO - 2018-03-23 13:54:24 --> Security Class Initialized
DEBUG - 2018-03-23 13:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 13:54:24 --> Input Class Initialized
INFO - 2018-03-23 13:54:24 --> Language Class Initialized
INFO - 2018-03-23 13:54:24 --> Language Class Initialized
INFO - 2018-03-23 13:54:24 --> Config Class Initialized
INFO - 2018-03-23 13:54:24 --> Loader Class Initialized
INFO - 2018-03-23 19:24:24 --> Helper loaded: url_helper
INFO - 2018-03-23 19:24:24 --> Helper loaded: notification_helper
INFO - 2018-03-23 19:24:24 --> Helper loaded: settings_helper
INFO - 2018-03-23 19:24:24 --> Helper loaded: permission_helper
INFO - 2018-03-23 19:24:24 --> Helper loaded: users_helper
INFO - 2018-03-23 19:24:24 --> Database Driver Class Initialized
DEBUG - 2018-03-23 19:24:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 19:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 19:24:24 --> Helper loaded: form_helper
INFO - 2018-03-23 19:24:24 --> Form Validation Class Initialized
INFO - 2018-03-23 19:24:24 --> Controller Class Initialized
INFO - 2018-03-23 19:24:24 --> Model Class Initialized
INFO - 2018-03-23 19:24:24 --> Helper loaded: inflector_helper
DEBUG - 2018-03-23 19:24:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-23 19:24:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-23 19:24:24 --> Model Class Initialized
INFO - 2018-03-23 19:24:24 --> Model Class Initialized
INFO - 2018-03-23 19:24:24 --> Model Class Initialized
INFO - 2018-03-23 19:24:24 --> Model Class Initialized
INFO - 2018-03-23 19:24:24 --> Final output sent to browser
DEBUG - 2018-03-23 19:24:24 --> Total execution time: 0.3392
INFO - 2018-03-23 13:54:33 --> Config Class Initialized
INFO - 2018-03-23 13:54:33 --> Hooks Class Initialized
DEBUG - 2018-03-23 13:54:33 --> UTF-8 Support Enabled
INFO - 2018-03-23 13:54:33 --> Utf8 Class Initialized
INFO - 2018-03-23 13:54:33 --> URI Class Initialized
INFO - 2018-03-23 13:54:34 --> Router Class Initialized
INFO - 2018-03-23 13:54:34 --> Output Class Initialized
INFO - 2018-03-23 13:54:34 --> Security Class Initialized
DEBUG - 2018-03-23 13:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 13:54:34 --> Input Class Initialized
INFO - 2018-03-23 13:54:34 --> Language Class Initialized
INFO - 2018-03-23 13:54:35 --> Language Class Initialized
INFO - 2018-03-23 13:54:35 --> Config Class Initialized
INFO - 2018-03-23 13:54:35 --> Loader Class Initialized
INFO - 2018-03-23 19:24:35 --> Helper loaded: url_helper
INFO - 2018-03-23 19:24:35 --> Helper loaded: notification_helper
INFO - 2018-03-23 19:24:35 --> Helper loaded: settings_helper
INFO - 2018-03-23 19:24:35 --> Helper loaded: permission_helper
INFO - 2018-03-23 19:24:35 --> Helper loaded: users_helper
INFO - 2018-03-23 19:24:35 --> Database Driver Class Initialized
DEBUG - 2018-03-23 19:24:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 19:24:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 19:24:35 --> Helper loaded: form_helper
INFO - 2018-03-23 19:24:35 --> Form Validation Class Initialized
INFO - 2018-03-23 19:24:35 --> Controller Class Initialized
INFO - 2018-03-23 19:24:35 --> Model Class Initialized
INFO - 2018-03-23 19:24:35 --> Helper loaded: inflector_helper
DEBUG - 2018-03-23 19:24:35 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-23 19:24:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-23 19:24:35 --> Model Class Initialized
INFO - 2018-03-23 19:24:35 --> Model Class Initialized
INFO - 2018-03-23 19:24:35 --> Model Class Initialized
INFO - 2018-03-23 19:24:35 --> Model Class Initialized
INFO - 2018-03-23 19:24:35 --> Final output sent to browser
DEBUG - 2018-03-23 19:24:35 --> Total execution time: 2.8699
INFO - 2018-03-23 13:54:38 --> Config Class Initialized
INFO - 2018-03-23 13:54:38 --> Hooks Class Initialized
DEBUG - 2018-03-23 13:54:38 --> UTF-8 Support Enabled
INFO - 2018-03-23 13:54:38 --> Utf8 Class Initialized
INFO - 2018-03-23 13:54:38 --> URI Class Initialized
INFO - 2018-03-23 13:54:38 --> Router Class Initialized
INFO - 2018-03-23 13:54:38 --> Output Class Initialized
INFO - 2018-03-23 13:54:38 --> Security Class Initialized
DEBUG - 2018-03-23 13:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 13:54:38 --> Input Class Initialized
INFO - 2018-03-23 13:54:38 --> Language Class Initialized
INFO - 2018-03-23 13:54:38 --> Language Class Initialized
INFO - 2018-03-23 13:54:38 --> Config Class Initialized
INFO - 2018-03-23 13:54:38 --> Loader Class Initialized
INFO - 2018-03-23 19:24:38 --> Helper loaded: url_helper
INFO - 2018-03-23 19:24:38 --> Helper loaded: notification_helper
INFO - 2018-03-23 19:24:38 --> Helper loaded: settings_helper
INFO - 2018-03-23 19:24:38 --> Helper loaded: permission_helper
INFO - 2018-03-23 19:24:38 --> Helper loaded: users_helper
INFO - 2018-03-23 19:24:38 --> Database Driver Class Initialized
DEBUG - 2018-03-23 19:24:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 19:24:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 19:24:39 --> Helper loaded: form_helper
INFO - 2018-03-23 19:24:39 --> Form Validation Class Initialized
INFO - 2018-03-23 19:24:39 --> Controller Class Initialized
INFO - 2018-03-23 19:24:39 --> Model Class Initialized
INFO - 2018-03-23 19:24:39 --> Helper loaded: inflector_helper
DEBUG - 2018-03-23 19:24:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-23 19:24:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-23 19:24:39 --> Model Class Initialized
INFO - 2018-03-23 19:24:39 --> Model Class Initialized
INFO - 2018-03-23 19:24:39 --> Model Class Initialized
INFO - 2018-03-23 19:24:39 --> Model Class Initialized
INFO - 2018-03-23 19:24:39 --> Model Class Initialized
INFO - 2018-03-23 19:24:39 --> Model Class Initialized
INFO - 2018-03-23 19:24:39 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-23 19:24:39 --> Final output sent to browser
DEBUG - 2018-03-23 19:24:39 --> Total execution time: 0.2461
INFO - 2018-03-23 13:54:39 --> Config Class Initialized
INFO - 2018-03-23 13:54:39 --> Hooks Class Initialized
DEBUG - 2018-03-23 13:54:39 --> UTF-8 Support Enabled
INFO - 2018-03-23 13:54:39 --> Utf8 Class Initialized
INFO - 2018-03-23 13:54:39 --> URI Class Initialized
INFO - 2018-03-23 13:54:39 --> Router Class Initialized
INFO - 2018-03-23 13:54:39 --> Output Class Initialized
INFO - 2018-03-23 13:54:39 --> Security Class Initialized
DEBUG - 2018-03-23 13:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 13:54:39 --> Input Class Initialized
INFO - 2018-03-23 13:54:39 --> Language Class Initialized
INFO - 2018-03-23 13:54:39 --> Language Class Initialized
INFO - 2018-03-23 13:54:39 --> Config Class Initialized
INFO - 2018-03-23 13:54:39 --> Loader Class Initialized
INFO - 2018-03-23 19:24:39 --> Helper loaded: url_helper
INFO - 2018-03-23 19:24:39 --> Helper loaded: notification_helper
INFO - 2018-03-23 19:24:39 --> Helper loaded: settings_helper
INFO - 2018-03-23 19:24:39 --> Helper loaded: permission_helper
INFO - 2018-03-23 19:24:39 --> Helper loaded: users_helper
INFO - 2018-03-23 19:24:39 --> Database Driver Class Initialized
DEBUG - 2018-03-23 19:24:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 19:24:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 19:24:40 --> Helper loaded: form_helper
INFO - 2018-03-23 19:24:40 --> Form Validation Class Initialized
INFO - 2018-03-23 19:24:40 --> Controller Class Initialized
INFO - 2018-03-23 19:24:40 --> Model Class Initialized
INFO - 2018-03-23 19:24:40 --> Helper loaded: inflector_helper
DEBUG - 2018-03-23 19:24:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-23 19:24:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-23 19:24:40 --> Model Class Initialized
INFO - 2018-03-23 19:24:40 --> Model Class Initialized
INFO - 2018-03-23 19:24:40 --> Model Class Initialized
INFO - 2018-03-23 19:24:40 --> Model Class Initialized
INFO - 2018-03-23 19:24:40 --> Model Class Initialized
INFO - 2018-03-23 19:24:40 --> Model Class Initialized
INFO - 2018-03-23 19:24:40 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-23 19:24:40 --> Final output sent to browser
DEBUG - 2018-03-23 19:24:40 --> Total execution time: 0.2025
