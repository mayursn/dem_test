<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-02-12 06:09:58 --> Config Class Initialized
INFO - 2018-02-12 06:09:58 --> Hooks Class Initialized
INFO - 2018-02-12 06:09:58 --> Config Class Initialized
INFO - 2018-02-12 06:09:58 --> Hooks Class Initialized
DEBUG - 2018-02-12 06:09:58 --> UTF-8 Support Enabled
INFO - 2018-02-12 06:09:58 --> Utf8 Class Initialized
DEBUG - 2018-02-12 06:09:58 --> UTF-8 Support Enabled
INFO - 2018-02-12 06:09:58 --> Utf8 Class Initialized
INFO - 2018-02-12 06:09:58 --> URI Class Initialized
INFO - 2018-02-12 06:09:58 --> URI Class Initialized
INFO - 2018-02-12 06:09:58 --> Router Class Initialized
INFO - 2018-02-12 06:09:58 --> Router Class Initialized
INFO - 2018-02-12 06:09:58 --> Output Class Initialized
INFO - 2018-02-12 06:09:58 --> Output Class Initialized
INFO - 2018-02-12 06:09:59 --> Security Class Initialized
INFO - 2018-02-12 06:09:59 --> Security Class Initialized
DEBUG - 2018-02-12 06:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 06:09:59 --> Input Class Initialized
DEBUG - 2018-02-12 06:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 06:09:59 --> Input Class Initialized
INFO - 2018-02-12 06:09:59 --> Language Class Initialized
INFO - 2018-02-12 06:09:59 --> Language Class Initialized
INFO - 2018-02-12 06:09:59 --> Language Class Initialized
INFO - 2018-02-12 06:09:59 --> Config Class Initialized
INFO - 2018-02-12 06:09:59 --> Loader Class Initialized
INFO - 2018-02-12 06:09:59 --> Language Class Initialized
INFO - 2018-02-12 06:09:59 --> Config Class Initialized
INFO - 2018-02-12 06:09:59 --> Loader Class Initialized
INFO - 2018-02-12 11:39:59 --> Helper loaded: url_helper
INFO - 2018-02-12 11:39:59 --> Helper loaded: notification_helper
INFO - 2018-02-12 11:39:59 --> Helper loaded: url_helper
INFO - 2018-02-12 11:39:59 --> Helper loaded: notification_helper
INFO - 2018-02-12 11:39:59 --> Helper loaded: settings_helper
INFO - 2018-02-12 11:39:59 --> Helper loaded: permission_helper
INFO - 2018-02-12 11:39:59 --> Helper loaded: settings_helper
INFO - 2018-02-12 11:39:59 --> Helper loaded: permission_helper
INFO - 2018-02-12 11:39:59 --> Helper loaded: users_helper
INFO - 2018-02-12 11:39:59 --> Helper loaded: users_helper
INFO - 2018-02-12 11:39:59 --> Database Driver Class Initialized
INFO - 2018-02-12 11:39:59 --> Database Driver Class Initialized
DEBUG - 2018-02-12 11:39:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 11:39:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-12 11:39:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 11:39:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 11:39:59 --> Helper loaded: form_helper
INFO - 2018-02-12 11:39:59 --> Form Validation Class Initialized
INFO - 2018-02-12 11:39:59 --> Controller Class Initialized
INFO - 2018-02-12 11:39:59 --> Helper loaded: form_helper
INFO - 2018-02-12 11:39:59 --> Form Validation Class Initialized
INFO - 2018-02-12 11:39:59 --> Controller Class Initialized
INFO - 2018-02-12 11:39:59 --> Model Class Initialized
INFO - 2018-02-12 11:39:59 --> Model Class Initialized
INFO - 2018-02-12 11:39:59 --> Helper loaded: inflector_helper
INFO - 2018-02-12 11:39:59 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 11:39:59 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-02-12 11:39:59 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 11:39:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 11:39:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 11:39:59 --> Model Class Initialized
INFO - 2018-02-12 11:39:59 --> Model Class Initialized
INFO - 2018-02-12 11:39:59 --> Model Class Initialized
INFO - 2018-02-12 11:39:59 --> Model Class Initialized
INFO - 2018-02-12 11:39:59 --> Model Class Initialized
INFO - 2018-02-12 11:39:59 --> Model Class Initialized
INFO - 2018-02-12 11:39:59 --> Model Class Initialized
INFO - 2018-02-12 11:39:59 --> Model Class Initialized
INFO - 2018-02-12 11:39:59 --> Model Class Initialized
INFO - 2018-02-12 11:39:59 --> Model Class Initialized
INFO - 2018-02-12 11:39:59 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 11:39:59 --> Model Class Initialized
INFO - 2018-02-12 11:39:59 --> Model Class Initialized
INFO - 2018-02-12 11:39:59 --> Model Class Initialized
INFO - 2018-02-12 11:39:59 --> Model Class Initialized
INFO - 2018-02-12 11:39:59 --> Model Class Initialized
INFO - 2018-02-12 11:39:59 --> Model Class Initialized
INFO - 2018-02-12 11:39:59 --> Model Class Initialized
INFO - 2018-02-12 11:39:59 --> Model Class Initialized
INFO - 2018-02-12 11:39:59 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 11:39:59 --> Model Class Initialized
INFO - 2018-02-12 11:39:59 --> Final output sent to browser
DEBUG - 2018-02-12 11:39:59 --> Total execution time: 0.4065
INFO - 2018-02-12 11:39:59 --> Final output sent to browser
DEBUG - 2018-02-12 11:39:59 --> Total execution time: 0.5010
INFO - 2018-02-12 06:10:09 --> Config Class Initialized
INFO - 2018-02-12 06:10:09 --> Hooks Class Initialized
DEBUG - 2018-02-12 06:10:09 --> UTF-8 Support Enabled
INFO - 2018-02-12 06:10:09 --> Utf8 Class Initialized
INFO - 2018-02-12 06:10:09 --> Config Class Initialized
INFO - 2018-02-12 06:10:09 --> Hooks Class Initialized
INFO - 2018-02-12 06:10:09 --> URI Class Initialized
DEBUG - 2018-02-12 06:10:09 --> UTF-8 Support Enabled
INFO - 2018-02-12 06:10:09 --> Utf8 Class Initialized
INFO - 2018-02-12 06:10:09 --> Router Class Initialized
INFO - 2018-02-12 06:10:09 --> URI Class Initialized
INFO - 2018-02-12 06:10:09 --> Output Class Initialized
INFO - 2018-02-12 06:10:09 --> Router Class Initialized
INFO - 2018-02-12 06:10:09 --> Security Class Initialized
INFO - 2018-02-12 06:10:09 --> Output Class Initialized
DEBUG - 2018-02-12 06:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 06:10:09 --> Input Class Initialized
INFO - 2018-02-12 06:10:09 --> Security Class Initialized
INFO - 2018-02-12 06:10:09 --> Language Class Initialized
DEBUG - 2018-02-12 06:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 06:10:09 --> Input Class Initialized
INFO - 2018-02-12 06:10:09 --> Language Class Initialized
INFO - 2018-02-12 06:10:09 --> Language Class Initialized
INFO - 2018-02-12 06:10:09 --> Config Class Initialized
INFO - 2018-02-12 06:10:09 --> Loader Class Initialized
INFO - 2018-02-12 06:10:09 --> Language Class Initialized
INFO - 2018-02-12 06:10:09 --> Config Class Initialized
INFO - 2018-02-12 06:10:09 --> Loader Class Initialized
INFO - 2018-02-12 11:40:09 --> Helper loaded: url_helper
INFO - 2018-02-12 11:40:09 --> Helper loaded: url_helper
INFO - 2018-02-12 11:40:09 --> Helper loaded: notification_helper
INFO - 2018-02-12 11:40:09 --> Helper loaded: notification_helper
INFO - 2018-02-12 11:40:09 --> Helper loaded: settings_helper
INFO - 2018-02-12 11:40:09 --> Helper loaded: settings_helper
INFO - 2018-02-12 11:40:09 --> Helper loaded: permission_helper
INFO - 2018-02-12 11:40:09 --> Helper loaded: permission_helper
INFO - 2018-02-12 11:40:09 --> Helper loaded: users_helper
INFO - 2018-02-12 11:40:09 --> Helper loaded: users_helper
INFO - 2018-02-12 11:40:09 --> Database Driver Class Initialized
INFO - 2018-02-12 11:40:09 --> Database Driver Class Initialized
DEBUG - 2018-02-12 11:40:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 11:40:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-12 11:40:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 11:40:09 --> Helper loaded: form_helper
INFO - 2018-02-12 11:40:09 --> Form Validation Class Initialized
INFO - 2018-02-12 11:40:09 --> Controller Class Initialized
INFO - 2018-02-12 11:40:09 --> Model Class Initialized
INFO - 2018-02-12 11:40:09 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 11:40:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 11:40:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 11:40:09 --> Model Class Initialized
INFO - 2018-02-12 11:40:09 --> Model Class Initialized
INFO - 2018-02-12 11:40:09 --> Model Class Initialized
INFO - 2018-02-12 11:40:09 --> Model Class Initialized
INFO - 2018-02-12 11:40:09 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 11:40:09 --> Final output sent to browser
DEBUG - 2018-02-12 11:40:09 --> Total execution time: 0.1542
INFO - 2018-02-12 11:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 11:40:09 --> Helper loaded: form_helper
INFO - 2018-02-12 11:40:09 --> Form Validation Class Initialized
INFO - 2018-02-12 11:40:09 --> Controller Class Initialized
INFO - 2018-02-12 11:40:09 --> Model Class Initialized
INFO - 2018-02-12 11:40:09 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 11:40:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 11:40:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 11:40:09 --> Model Class Initialized
INFO - 2018-02-12 11:40:09 --> Model Class Initialized
INFO - 2018-02-12 11:40:09 --> Model Class Initialized
INFO - 2018-02-12 11:40:09 --> Model Class Initialized
INFO - 2018-02-12 11:40:09 --> Model Class Initialized
INFO - 2018-02-12 11:40:09 --> Model Class Initialized
INFO - 2018-02-12 11:40:09 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 11:40:09 --> Final output sent to browser
DEBUG - 2018-02-12 11:40:09 --> Total execution time: 0.1853
INFO - 2018-02-12 06:10:22 --> Config Class Initialized
INFO - 2018-02-12 06:10:22 --> Hooks Class Initialized
DEBUG - 2018-02-12 06:10:22 --> UTF-8 Support Enabled
INFO - 2018-02-12 06:10:22 --> Utf8 Class Initialized
INFO - 2018-02-12 06:10:22 --> URI Class Initialized
INFO - 2018-02-12 06:10:22 --> Router Class Initialized
INFO - 2018-02-12 06:10:22 --> Output Class Initialized
INFO - 2018-02-12 06:10:22 --> Security Class Initialized
DEBUG - 2018-02-12 06:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 06:10:22 --> Input Class Initialized
INFO - 2018-02-12 06:10:22 --> Language Class Initialized
INFO - 2018-02-12 06:10:22 --> Language Class Initialized
INFO - 2018-02-12 06:10:22 --> Config Class Initialized
INFO - 2018-02-12 06:10:22 --> Loader Class Initialized
INFO - 2018-02-12 11:40:22 --> Helper loaded: url_helper
INFO - 2018-02-12 11:40:22 --> Helper loaded: notification_helper
INFO - 2018-02-12 11:40:22 --> Helper loaded: settings_helper
INFO - 2018-02-12 11:40:22 --> Helper loaded: permission_helper
INFO - 2018-02-12 11:40:22 --> Helper loaded: users_helper
INFO - 2018-02-12 11:40:22 --> Database Driver Class Initialized
DEBUG - 2018-02-12 11:40:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 11:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 11:40:22 --> Helper loaded: form_helper
INFO - 2018-02-12 11:40:22 --> Form Validation Class Initialized
INFO - 2018-02-12 11:40:22 --> Controller Class Initialized
INFO - 2018-02-12 11:40:22 --> Model Class Initialized
INFO - 2018-02-12 11:40:22 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 11:40:22 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 11:40:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 11:40:22 --> Model Class Initialized
INFO - 2018-02-12 11:40:22 --> Model Class Initialized
INFO - 2018-02-12 11:40:22 --> Model Class Initialized
INFO - 2018-02-12 11:40:22 --> Model Class Initialized
INFO - 2018-02-12 11:40:22 --> Model Class Initialized
INFO - 2018-02-12 11:40:22 --> Model Class Initialized
INFO - 2018-02-12 11:40:22 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 11:40:22 --> Model Class Initialized
INFO - 2018-02-12 11:40:22 --> Final output sent to browser
DEBUG - 2018-02-12 11:40:22 --> Total execution time: 0.1089
INFO - 2018-02-12 06:10:28 --> Config Class Initialized
INFO - 2018-02-12 06:10:28 --> Hooks Class Initialized
DEBUG - 2018-02-12 06:10:28 --> UTF-8 Support Enabled
INFO - 2018-02-12 06:10:28 --> Utf8 Class Initialized
INFO - 2018-02-12 06:10:28 --> URI Class Initialized
INFO - 2018-02-12 06:10:28 --> Router Class Initialized
INFO - 2018-02-12 06:10:28 --> Output Class Initialized
INFO - 2018-02-12 06:10:28 --> Security Class Initialized
DEBUG - 2018-02-12 06:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 06:10:28 --> Input Class Initialized
INFO - 2018-02-12 06:10:28 --> Language Class Initialized
INFO - 2018-02-12 06:10:28 --> Language Class Initialized
INFO - 2018-02-12 06:10:28 --> Config Class Initialized
INFO - 2018-02-12 06:10:28 --> Loader Class Initialized
INFO - 2018-02-12 11:40:28 --> Helper loaded: url_helper
INFO - 2018-02-12 11:40:28 --> Helper loaded: notification_helper
INFO - 2018-02-12 11:40:28 --> Helper loaded: settings_helper
INFO - 2018-02-12 11:40:28 --> Helper loaded: permission_helper
INFO - 2018-02-12 11:40:28 --> Helper loaded: users_helper
INFO - 2018-02-12 11:40:28 --> Database Driver Class Initialized
DEBUG - 2018-02-12 11:40:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 11:40:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 11:40:28 --> Helper loaded: form_helper
INFO - 2018-02-12 11:40:28 --> Form Validation Class Initialized
INFO - 2018-02-12 11:40:28 --> Controller Class Initialized
INFO - 2018-02-12 11:40:28 --> Model Class Initialized
INFO - 2018-02-12 11:40:28 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 11:40:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 11:40:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 11:40:28 --> Model Class Initialized
INFO - 2018-02-12 11:40:28 --> Model Class Initialized
INFO - 2018-02-12 11:40:28 --> Model Class Initialized
INFO - 2018-02-12 11:40:28 --> Model Class Initialized
INFO - 2018-02-12 11:40:28 --> Model Class Initialized
INFO - 2018-02-12 11:40:28 --> Model Class Initialized
INFO - 2018-02-12 11:40:28 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 11:40:28 --> Model Class Initialized
INFO - 2018-02-12 11:40:28 --> Final output sent to browser
DEBUG - 2018-02-12 11:40:28 --> Total execution time: 0.0810
INFO - 2018-02-12 06:10:31 --> Config Class Initialized
INFO - 2018-02-12 06:10:31 --> Hooks Class Initialized
DEBUG - 2018-02-12 06:10:31 --> UTF-8 Support Enabled
INFO - 2018-02-12 06:10:31 --> Utf8 Class Initialized
INFO - 2018-02-12 06:10:31 --> URI Class Initialized
INFO - 2018-02-12 06:10:31 --> Router Class Initialized
INFO - 2018-02-12 06:10:31 --> Output Class Initialized
INFO - 2018-02-12 06:10:31 --> Security Class Initialized
DEBUG - 2018-02-12 06:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 06:10:31 --> Input Class Initialized
INFO - 2018-02-12 06:10:31 --> Language Class Initialized
INFO - 2018-02-12 06:10:31 --> Language Class Initialized
INFO - 2018-02-12 06:10:31 --> Config Class Initialized
INFO - 2018-02-12 06:10:31 --> Loader Class Initialized
INFO - 2018-02-12 11:40:31 --> Helper loaded: url_helper
INFO - 2018-02-12 11:40:31 --> Helper loaded: notification_helper
INFO - 2018-02-12 11:40:31 --> Helper loaded: settings_helper
INFO - 2018-02-12 11:40:31 --> Helper loaded: permission_helper
INFO - 2018-02-12 11:40:31 --> Helper loaded: users_helper
INFO - 2018-02-12 11:40:31 --> Database Driver Class Initialized
DEBUG - 2018-02-12 11:40:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 11:40:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 11:40:31 --> Helper loaded: form_helper
INFO - 2018-02-12 11:40:31 --> Form Validation Class Initialized
INFO - 2018-02-12 11:40:31 --> Controller Class Initialized
INFO - 2018-02-12 11:40:31 --> Model Class Initialized
INFO - 2018-02-12 11:40:31 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 11:40:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 11:40:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 11:40:31 --> Model Class Initialized
INFO - 2018-02-12 11:40:31 --> Model Class Initialized
INFO - 2018-02-12 11:40:31 --> Model Class Initialized
INFO - 2018-02-12 11:40:31 --> Model Class Initialized
INFO - 2018-02-12 11:40:31 --> Model Class Initialized
INFO - 2018-02-12 11:40:31 --> Model Class Initialized
INFO - 2018-02-12 11:40:31 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 11:40:31 --> Model Class Initialized
INFO - 2018-02-12 11:40:31 --> Final output sent to browser
DEBUG - 2018-02-12 11:40:31 --> Total execution time: 0.0888
INFO - 2018-02-12 06:10:32 --> Config Class Initialized
INFO - 2018-02-12 06:10:32 --> Hooks Class Initialized
DEBUG - 2018-02-12 06:10:32 --> UTF-8 Support Enabled
INFO - 2018-02-12 06:10:32 --> Utf8 Class Initialized
INFO - 2018-02-12 06:10:32 --> URI Class Initialized
INFO - 2018-02-12 06:10:32 --> Router Class Initialized
INFO - 2018-02-12 06:10:32 --> Output Class Initialized
INFO - 2018-02-12 06:10:32 --> Security Class Initialized
DEBUG - 2018-02-12 06:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 06:10:32 --> Input Class Initialized
INFO - 2018-02-12 06:10:32 --> Language Class Initialized
INFO - 2018-02-12 06:10:32 --> Language Class Initialized
INFO - 2018-02-12 06:10:32 --> Config Class Initialized
INFO - 2018-02-12 06:10:32 --> Loader Class Initialized
INFO - 2018-02-12 11:40:32 --> Helper loaded: url_helper
INFO - 2018-02-12 11:40:32 --> Helper loaded: notification_helper
INFO - 2018-02-12 11:40:32 --> Helper loaded: settings_helper
INFO - 2018-02-12 11:40:32 --> Helper loaded: permission_helper
INFO - 2018-02-12 11:40:32 --> Helper loaded: users_helper
INFO - 2018-02-12 11:40:32 --> Database Driver Class Initialized
DEBUG - 2018-02-12 11:40:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 11:40:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 11:40:32 --> Helper loaded: form_helper
INFO - 2018-02-12 11:40:32 --> Form Validation Class Initialized
INFO - 2018-02-12 11:40:32 --> Controller Class Initialized
INFO - 2018-02-12 11:40:32 --> Model Class Initialized
INFO - 2018-02-12 11:40:32 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 11:40:32 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 11:40:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 11:40:32 --> Model Class Initialized
INFO - 2018-02-12 11:40:32 --> Model Class Initialized
INFO - 2018-02-12 11:40:32 --> Model Class Initialized
INFO - 2018-02-12 11:40:32 --> Model Class Initialized
INFO - 2018-02-12 11:40:32 --> Model Class Initialized
INFO - 2018-02-12 11:40:32 --> Model Class Initialized
INFO - 2018-02-12 11:40:32 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 11:40:32 --> Model Class Initialized
INFO - 2018-02-12 11:40:32 --> Final output sent to browser
DEBUG - 2018-02-12 11:40:32 --> Total execution time: 0.1155
INFO - 2018-02-12 06:10:34 --> Config Class Initialized
INFO - 2018-02-12 06:10:34 --> Hooks Class Initialized
DEBUG - 2018-02-12 06:10:34 --> UTF-8 Support Enabled
INFO - 2018-02-12 06:10:34 --> Utf8 Class Initialized
INFO - 2018-02-12 06:10:34 --> URI Class Initialized
INFO - 2018-02-12 06:10:34 --> Router Class Initialized
INFO - 2018-02-12 06:10:34 --> Output Class Initialized
INFO - 2018-02-12 06:10:34 --> Security Class Initialized
DEBUG - 2018-02-12 06:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 06:10:34 --> Input Class Initialized
INFO - 2018-02-12 06:10:34 --> Language Class Initialized
INFO - 2018-02-12 06:10:34 --> Language Class Initialized
INFO - 2018-02-12 06:10:34 --> Config Class Initialized
INFO - 2018-02-12 06:10:34 --> Loader Class Initialized
INFO - 2018-02-12 11:40:34 --> Helper loaded: url_helper
INFO - 2018-02-12 11:40:34 --> Helper loaded: notification_helper
INFO - 2018-02-12 11:40:34 --> Helper loaded: settings_helper
INFO - 2018-02-12 11:40:34 --> Helper loaded: permission_helper
INFO - 2018-02-12 11:40:34 --> Helper loaded: users_helper
INFO - 2018-02-12 11:40:34 --> Database Driver Class Initialized
DEBUG - 2018-02-12 11:40:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 11:40:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 11:40:34 --> Helper loaded: form_helper
INFO - 2018-02-12 11:40:34 --> Form Validation Class Initialized
INFO - 2018-02-12 11:40:34 --> Controller Class Initialized
INFO - 2018-02-12 11:40:34 --> Model Class Initialized
INFO - 2018-02-12 11:40:34 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 11:40:34 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 11:40:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 11:40:34 --> Model Class Initialized
INFO - 2018-02-12 11:40:34 --> Model Class Initialized
INFO - 2018-02-12 11:40:34 --> Model Class Initialized
INFO - 2018-02-12 11:40:34 --> Model Class Initialized
INFO - 2018-02-12 11:40:34 --> Model Class Initialized
INFO - 2018-02-12 11:40:34 --> Model Class Initialized
INFO - 2018-02-12 11:40:34 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 11:40:34 --> Model Class Initialized
INFO - 2018-02-12 11:40:34 --> Final output sent to browser
DEBUG - 2018-02-12 11:40:34 --> Total execution time: 0.0861
INFO - 2018-02-12 06:13:02 --> Config Class Initialized
INFO - 2018-02-12 06:13:02 --> Config Class Initialized
INFO - 2018-02-12 06:13:02 --> Hooks Class Initialized
INFO - 2018-02-12 06:13:02 --> Hooks Class Initialized
DEBUG - 2018-02-12 06:13:02 --> UTF-8 Support Enabled
INFO - 2018-02-12 06:13:02 --> Utf8 Class Initialized
DEBUG - 2018-02-12 06:13:02 --> UTF-8 Support Enabled
INFO - 2018-02-12 06:13:02 --> Utf8 Class Initialized
INFO - 2018-02-12 06:13:02 --> URI Class Initialized
INFO - 2018-02-12 06:13:02 --> URI Class Initialized
INFO - 2018-02-12 06:13:02 --> Router Class Initialized
INFO - 2018-02-12 06:13:02 --> Output Class Initialized
INFO - 2018-02-12 06:13:02 --> Router Class Initialized
INFO - 2018-02-12 06:13:02 --> Output Class Initialized
INFO - 2018-02-12 06:13:02 --> Security Class Initialized
INFO - 2018-02-12 06:13:02 --> Security Class Initialized
DEBUG - 2018-02-12 06:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 06:13:02 --> Input Class Initialized
INFO - 2018-02-12 06:13:02 --> Language Class Initialized
DEBUG - 2018-02-12 06:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 06:13:02 --> Input Class Initialized
INFO - 2018-02-12 06:13:02 --> Language Class Initialized
INFO - 2018-02-12 06:13:02 --> Language Class Initialized
INFO - 2018-02-12 06:13:02 --> Config Class Initialized
INFO - 2018-02-12 06:13:02 --> Loader Class Initialized
INFO - 2018-02-12 11:43:02 --> Helper loaded: url_helper
INFO - 2018-02-12 11:43:02 --> Helper loaded: notification_helper
INFO - 2018-02-12 11:43:02 --> Helper loaded: settings_helper
INFO - 2018-02-12 11:43:02 --> Helper loaded: permission_helper
INFO - 2018-02-12 06:13:02 --> Language Class Initialized
INFO - 2018-02-12 06:13:02 --> Config Class Initialized
INFO - 2018-02-12 06:13:02 --> Loader Class Initialized
INFO - 2018-02-12 11:43:02 --> Helper loaded: users_helper
INFO - 2018-02-12 11:43:02 --> Helper loaded: url_helper
INFO - 2018-02-12 11:43:02 --> Helper loaded: notification_helper
INFO - 2018-02-12 11:43:02 --> Helper loaded: settings_helper
INFO - 2018-02-12 11:43:02 --> Helper loaded: permission_helper
INFO - 2018-02-12 11:43:02 --> Helper loaded: users_helper
INFO - 2018-02-12 11:43:02 --> Database Driver Class Initialized
DEBUG - 2018-02-12 11:43:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 11:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 11:43:02 --> Database Driver Class Initialized
DEBUG - 2018-02-12 11:43:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 11:43:02 --> Helper loaded: form_helper
INFO - 2018-02-12 11:43:02 --> Form Validation Class Initialized
INFO - 2018-02-12 11:43:02 --> Controller Class Initialized
INFO - 2018-02-12 11:43:02 --> Model Class Initialized
INFO - 2018-02-12 11:43:02 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 11:43:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 11:43:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 11:43:02 --> Model Class Initialized
INFO - 2018-02-12 11:43:02 --> Model Class Initialized
INFO - 2018-02-12 11:43:02 --> Model Class Initialized
INFO - 2018-02-12 11:43:02 --> Model Class Initialized
INFO - 2018-02-12 11:43:02 --> Model Class Initialized
INFO - 2018-02-12 11:43:02 --> Model Class Initialized
INFO - 2018-02-12 11:43:02 --> Model Class Initialized
INFO - 2018-02-12 11:43:02 --> Model Class Initialized
INFO - 2018-02-12 11:43:02 --> Model Class Initialized
INFO - 2018-02-12 11:43:02 --> Model Class Initialized
INFO - 2018-02-12 11:43:02 --> Model Class Initialized
INFO - 2018-02-12 11:43:02 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 11:43:02 --> Model Class Initialized
INFO - 2018-02-12 11:43:02 --> Final output sent to browser
DEBUG - 2018-02-12 11:43:02 --> Total execution time: 0.1639
INFO - 2018-02-12 11:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 11:43:02 --> Helper loaded: form_helper
INFO - 2018-02-12 11:43:02 --> Form Validation Class Initialized
INFO - 2018-02-12 11:43:02 --> Controller Class Initialized
INFO - 2018-02-12 11:43:02 --> Model Class Initialized
INFO - 2018-02-12 11:43:02 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 11:43:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 11:43:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 11:43:02 --> Model Class Initialized
INFO - 2018-02-12 11:43:02 --> Model Class Initialized
INFO - 2018-02-12 11:43:02 --> Model Class Initialized
INFO - 2018-02-12 11:43:02 --> Model Class Initialized
INFO - 2018-02-12 11:43:02 --> Model Class Initialized
INFO - 2018-02-12 11:43:02 --> Model Class Initialized
INFO - 2018-02-12 11:43:02 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 11:43:02 --> Model Class Initialized
INFO - 2018-02-12 11:43:02 --> Final output sent to browser
DEBUG - 2018-02-12 11:43:02 --> Total execution time: 0.2093
INFO - 2018-02-12 06:13:03 --> Config Class Initialized
INFO - 2018-02-12 06:13:03 --> Config Class Initialized
INFO - 2018-02-12 06:13:03 --> Hooks Class Initialized
INFO - 2018-02-12 06:13:03 --> Hooks Class Initialized
DEBUG - 2018-02-12 06:13:03 --> UTF-8 Support Enabled
INFO - 2018-02-12 06:13:03 --> Utf8 Class Initialized
DEBUG - 2018-02-12 06:13:03 --> UTF-8 Support Enabled
INFO - 2018-02-12 06:13:03 --> Utf8 Class Initialized
INFO - 2018-02-12 06:13:03 --> URI Class Initialized
INFO - 2018-02-12 06:13:03 --> URI Class Initialized
INFO - 2018-02-12 06:13:03 --> Router Class Initialized
INFO - 2018-02-12 06:13:03 --> Router Class Initialized
INFO - 2018-02-12 06:13:03 --> Output Class Initialized
INFO - 2018-02-12 06:13:03 --> Output Class Initialized
INFO - 2018-02-12 06:13:03 --> Security Class Initialized
INFO - 2018-02-12 06:13:03 --> Security Class Initialized
DEBUG - 2018-02-12 06:13:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 06:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 06:13:03 --> Input Class Initialized
INFO - 2018-02-12 06:13:03 --> Input Class Initialized
INFO - 2018-02-12 06:13:03 --> Language Class Initialized
INFO - 2018-02-12 06:13:03 --> Language Class Initialized
INFO - 2018-02-12 06:13:03 --> Language Class Initialized
INFO - 2018-02-12 06:13:03 --> Config Class Initialized
INFO - 2018-02-12 06:13:03 --> Loader Class Initialized
INFO - 2018-02-12 11:43:03 --> Helper loaded: url_helper
INFO - 2018-02-12 11:43:04 --> Helper loaded: notification_helper
INFO - 2018-02-12 11:43:04 --> Helper loaded: settings_helper
INFO - 2018-02-12 11:43:04 --> Helper loaded: permission_helper
INFO - 2018-02-12 06:13:04 --> Language Class Initialized
INFO - 2018-02-12 06:13:04 --> Config Class Initialized
INFO - 2018-02-12 06:13:04 --> Loader Class Initialized
INFO - 2018-02-12 11:43:04 --> Helper loaded: users_helper
INFO - 2018-02-12 11:43:04 --> Helper loaded: url_helper
INFO - 2018-02-12 11:43:04 --> Helper loaded: notification_helper
INFO - 2018-02-12 11:43:04 --> Helper loaded: settings_helper
INFO - 2018-02-12 11:43:04 --> Helper loaded: permission_helper
INFO - 2018-02-12 11:43:04 --> Helper loaded: users_helper
INFO - 2018-02-12 11:43:04 --> Database Driver Class Initialized
INFO - 2018-02-12 11:43:04 --> Database Driver Class Initialized
DEBUG - 2018-02-12 11:43:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 11:43:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-12 11:43:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 11:43:04 --> Helper loaded: form_helper
INFO - 2018-02-12 11:43:04 --> Form Validation Class Initialized
INFO - 2018-02-12 11:43:04 --> Controller Class Initialized
INFO - 2018-02-12 11:43:04 --> Model Class Initialized
INFO - 2018-02-12 11:43:04 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 11:43:04 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 11:43:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 11:43:04 --> Model Class Initialized
INFO - 2018-02-12 11:43:04 --> Model Class Initialized
INFO - 2018-02-12 11:43:04 --> Model Class Initialized
INFO - 2018-02-12 11:43:04 --> Model Class Initialized
INFO - 2018-02-12 11:43:04 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 11:43:04 --> Final output sent to browser
DEBUG - 2018-02-12 11:43:04 --> Total execution time: 0.1094
INFO - 2018-02-12 11:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 11:43:04 --> Helper loaded: form_helper
INFO - 2018-02-12 11:43:04 --> Form Validation Class Initialized
INFO - 2018-02-12 11:43:04 --> Controller Class Initialized
INFO - 2018-02-12 11:43:04 --> Model Class Initialized
INFO - 2018-02-12 11:43:04 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 11:43:04 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 11:43:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 11:43:04 --> Model Class Initialized
INFO - 2018-02-12 11:43:04 --> Model Class Initialized
INFO - 2018-02-12 11:43:04 --> Model Class Initialized
INFO - 2018-02-12 11:43:04 --> Model Class Initialized
INFO - 2018-02-12 11:43:04 --> Model Class Initialized
INFO - 2018-02-12 11:43:04 --> Model Class Initialized
INFO - 2018-02-12 11:43:04 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 11:43:04 --> Final output sent to browser
DEBUG - 2018-02-12 11:43:04 --> Total execution time: 0.1444
INFO - 2018-02-12 06:13:06 --> Config Class Initialized
INFO - 2018-02-12 06:13:06 --> Hooks Class Initialized
DEBUG - 2018-02-12 06:13:06 --> UTF-8 Support Enabled
INFO - 2018-02-12 06:13:06 --> Utf8 Class Initialized
INFO - 2018-02-12 06:13:06 --> URI Class Initialized
INFO - 2018-02-12 06:13:06 --> Router Class Initialized
INFO - 2018-02-12 06:13:06 --> Output Class Initialized
INFO - 2018-02-12 06:13:06 --> Security Class Initialized
DEBUG - 2018-02-12 06:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 06:13:06 --> Input Class Initialized
INFO - 2018-02-12 06:13:06 --> Language Class Initialized
INFO - 2018-02-12 06:13:07 --> Language Class Initialized
INFO - 2018-02-12 06:13:07 --> Config Class Initialized
INFO - 2018-02-12 06:13:07 --> Loader Class Initialized
INFO - 2018-02-12 11:43:07 --> Helper loaded: url_helper
INFO - 2018-02-12 11:43:07 --> Helper loaded: notification_helper
INFO - 2018-02-12 11:43:07 --> Helper loaded: settings_helper
INFO - 2018-02-12 11:43:07 --> Helper loaded: permission_helper
INFO - 2018-02-12 11:43:07 --> Helper loaded: users_helper
INFO - 2018-02-12 11:43:07 --> Database Driver Class Initialized
DEBUG - 2018-02-12 11:43:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 11:43:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 11:43:07 --> Helper loaded: form_helper
INFO - 2018-02-12 11:43:07 --> Form Validation Class Initialized
INFO - 2018-02-12 11:43:07 --> Controller Class Initialized
INFO - 2018-02-12 11:43:07 --> Model Class Initialized
INFO - 2018-02-12 11:43:07 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 11:43:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 11:43:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 11:43:07 --> Model Class Initialized
INFO - 2018-02-12 11:43:07 --> Model Class Initialized
INFO - 2018-02-12 11:43:07 --> Model Class Initialized
INFO - 2018-02-12 11:43:07 --> Model Class Initialized
INFO - 2018-02-12 11:43:07 --> Model Class Initialized
INFO - 2018-02-12 11:43:07 --> Model Class Initialized
INFO - 2018-02-12 11:43:07 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 11:43:07 --> Model Class Initialized
INFO - 2018-02-12 11:43:07 --> Final output sent to browser
DEBUG - 2018-02-12 11:43:07 --> Total execution time: 0.1138
INFO - 2018-02-12 06:16:18 --> Config Class Initialized
INFO - 2018-02-12 06:16:18 --> Hooks Class Initialized
DEBUG - 2018-02-12 06:16:18 --> UTF-8 Support Enabled
INFO - 2018-02-12 06:16:18 --> Utf8 Class Initialized
INFO - 2018-02-12 06:16:18 --> URI Class Initialized
INFO - 2018-02-12 06:16:18 --> Router Class Initialized
INFO - 2018-02-12 06:16:18 --> Output Class Initialized
INFO - 2018-02-12 06:16:18 --> Security Class Initialized
DEBUG - 2018-02-12 06:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 06:16:18 --> Input Class Initialized
INFO - 2018-02-12 06:16:18 --> Language Class Initialized
INFO - 2018-02-12 06:16:18 --> Language Class Initialized
INFO - 2018-02-12 06:16:18 --> Config Class Initialized
INFO - 2018-02-12 06:16:18 --> Loader Class Initialized
INFO - 2018-02-12 11:46:18 --> Helper loaded: url_helper
INFO - 2018-02-12 11:46:18 --> Helper loaded: notification_helper
INFO - 2018-02-12 11:46:18 --> Helper loaded: settings_helper
INFO - 2018-02-12 11:46:18 --> Helper loaded: permission_helper
INFO - 2018-02-12 11:46:18 --> Helper loaded: users_helper
INFO - 2018-02-12 06:16:18 --> Config Class Initialized
INFO - 2018-02-12 06:16:18 --> Hooks Class Initialized
DEBUG - 2018-02-12 06:16:18 --> UTF-8 Support Enabled
INFO - 2018-02-12 06:16:18 --> Utf8 Class Initialized
INFO - 2018-02-12 06:16:18 --> URI Class Initialized
INFO - 2018-02-12 06:16:18 --> Router Class Initialized
INFO - 2018-02-12 06:16:18 --> Output Class Initialized
INFO - 2018-02-12 11:46:18 --> Database Driver Class Initialized
INFO - 2018-02-12 06:16:18 --> Security Class Initialized
DEBUG - 2018-02-12 06:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 06:16:18 --> Input Class Initialized
INFO - 2018-02-12 06:16:18 --> Language Class Initialized
DEBUG - 2018-02-12 11:46:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 11:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 11:46:18 --> Helper loaded: form_helper
INFO - 2018-02-12 11:46:18 --> Form Validation Class Initialized
INFO - 2018-02-12 11:46:18 --> Controller Class Initialized
INFO - 2018-02-12 06:16:18 --> Language Class Initialized
INFO - 2018-02-12 06:16:18 --> Config Class Initialized
INFO - 2018-02-12 06:16:18 --> Loader Class Initialized
INFO - 2018-02-12 11:46:18 --> Model Class Initialized
INFO - 2018-02-12 11:46:18 --> Helper loaded: inflector_helper
INFO - 2018-02-12 11:46:18 --> Helper loaded: url_helper
INFO - 2018-02-12 11:46:18 --> Helper loaded: notification_helper
INFO - 2018-02-12 11:46:18 --> Helper loaded: settings_helper
INFO - 2018-02-12 11:46:18 --> Helper loaded: permission_helper
DEBUG - 2018-02-12 11:46:18 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 11:46:18 --> Helper loaded: users_helper
INFO - 2018-02-12 11:46:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 11:46:18 --> Model Class Initialized
INFO - 2018-02-12 11:46:18 --> Model Class Initialized
INFO - 2018-02-12 11:46:18 --> Model Class Initialized
INFO - 2018-02-12 11:46:18 --> Model Class Initialized
INFO - 2018-02-12 11:46:18 --> Model Class Initialized
INFO - 2018-02-12 11:46:18 --> Model Class Initialized
INFO - 2018-02-12 11:46:18 --> Model Class Initialized
INFO - 2018-02-12 11:46:18 --> Model Class Initialized
INFO - 2018-02-12 11:46:18 --> Model Class Initialized
INFO - 2018-02-12 11:46:18 --> Model Class Initialized
INFO - 2018-02-12 11:46:18 --> Model Class Initialized
INFO - 2018-02-12 11:46:18 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 11:46:18 --> Model Class Initialized
INFO - 2018-02-12 11:46:18 --> Database Driver Class Initialized
DEBUG - 2018-02-12 11:46:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 11:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 11:46:18 --> Final output sent to browser
INFO - 2018-02-12 11:46:18 --> Helper loaded: form_helper
DEBUG - 2018-02-12 11:46:18 --> Total execution time: 0.1385
INFO - 2018-02-12 11:46:18 --> Form Validation Class Initialized
INFO - 2018-02-12 11:46:18 --> Controller Class Initialized
INFO - 2018-02-12 11:46:18 --> Model Class Initialized
INFO - 2018-02-12 11:46:18 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 11:46:18 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 11:46:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 11:46:18 --> Model Class Initialized
INFO - 2018-02-12 11:46:18 --> Model Class Initialized
INFO - 2018-02-12 11:46:18 --> Model Class Initialized
INFO - 2018-02-12 11:46:18 --> Model Class Initialized
INFO - 2018-02-12 11:46:18 --> Model Class Initialized
INFO - 2018-02-12 11:46:18 --> Model Class Initialized
INFO - 2018-02-12 11:46:18 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 11:46:18 --> Model Class Initialized
INFO - 2018-02-12 11:46:18 --> Final output sent to browser
DEBUG - 2018-02-12 11:46:18 --> Total execution time: 0.1098
INFO - 2018-02-12 06:16:22 --> Config Class Initialized
INFO - 2018-02-12 06:16:22 --> Hooks Class Initialized
DEBUG - 2018-02-12 06:16:22 --> UTF-8 Support Enabled
INFO - 2018-02-12 06:16:22 --> Utf8 Class Initialized
INFO - 2018-02-12 06:16:22 --> URI Class Initialized
INFO - 2018-02-12 06:16:22 --> Router Class Initialized
INFO - 2018-02-12 06:16:22 --> Output Class Initialized
INFO - 2018-02-12 06:16:22 --> Security Class Initialized
DEBUG - 2018-02-12 06:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 06:16:22 --> Input Class Initialized
INFO - 2018-02-12 06:16:22 --> Language Class Initialized
INFO - 2018-02-12 06:16:22 --> Language Class Initialized
INFO - 2018-02-12 06:16:22 --> Config Class Initialized
INFO - 2018-02-12 06:16:22 --> Loader Class Initialized
INFO - 2018-02-12 11:46:22 --> Helper loaded: url_helper
INFO - 2018-02-12 11:46:22 --> Helper loaded: notification_helper
INFO - 2018-02-12 11:46:22 --> Helper loaded: settings_helper
INFO - 2018-02-12 11:46:22 --> Helper loaded: permission_helper
INFO - 2018-02-12 11:46:22 --> Helper loaded: users_helper
INFO - 2018-02-12 06:16:22 --> Config Class Initialized
INFO - 2018-02-12 06:16:22 --> Hooks Class Initialized
INFO - 2018-02-12 11:46:22 --> Database Driver Class Initialized
DEBUG - 2018-02-12 06:16:22 --> UTF-8 Support Enabled
INFO - 2018-02-12 06:16:22 --> Utf8 Class Initialized
INFO - 2018-02-12 06:16:22 --> URI Class Initialized
DEBUG - 2018-02-12 11:46:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 11:46:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 06:16:22 --> Router Class Initialized
INFO - 2018-02-12 06:16:22 --> Output Class Initialized
INFO - 2018-02-12 06:16:22 --> Security Class Initialized
INFO - 2018-02-12 11:46:22 --> Helper loaded: form_helper
INFO - 2018-02-12 11:46:22 --> Form Validation Class Initialized
INFO - 2018-02-12 11:46:22 --> Controller Class Initialized
DEBUG - 2018-02-12 06:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 06:16:22 --> Input Class Initialized
INFO - 2018-02-12 06:16:22 --> Language Class Initialized
INFO - 2018-02-12 11:46:22 --> Model Class Initialized
INFO - 2018-02-12 11:46:22 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 11:46:22 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 11:46:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 11:46:22 --> Model Class Initialized
INFO - 2018-02-12 11:46:22 --> Model Class Initialized
INFO - 2018-02-12 11:46:22 --> Model Class Initialized
INFO - 2018-02-12 11:46:22 --> Model Class Initialized
INFO - 2018-02-12 11:46:22 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 06:16:22 --> Language Class Initialized
INFO - 2018-02-12 06:16:22 --> Config Class Initialized
INFO - 2018-02-12 06:16:22 --> Loader Class Initialized
INFO - 2018-02-12 11:46:22 --> Final output sent to browser
DEBUG - 2018-02-12 11:46:22 --> Total execution time: 0.1096
INFO - 2018-02-12 11:46:22 --> Helper loaded: url_helper
INFO - 2018-02-12 11:46:22 --> Helper loaded: notification_helper
INFO - 2018-02-12 11:46:22 --> Helper loaded: settings_helper
INFO - 2018-02-12 11:46:22 --> Helper loaded: permission_helper
INFO - 2018-02-12 11:46:22 --> Helper loaded: users_helper
INFO - 2018-02-12 11:46:22 --> Database Driver Class Initialized
DEBUG - 2018-02-12 11:46:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 11:46:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 11:46:22 --> Helper loaded: form_helper
INFO - 2018-02-12 11:46:22 --> Form Validation Class Initialized
INFO - 2018-02-12 11:46:22 --> Controller Class Initialized
INFO - 2018-02-12 11:46:22 --> Model Class Initialized
INFO - 2018-02-12 11:46:22 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 11:46:22 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 11:46:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 11:46:22 --> Model Class Initialized
INFO - 2018-02-12 11:46:22 --> Model Class Initialized
INFO - 2018-02-12 11:46:22 --> Model Class Initialized
INFO - 2018-02-12 11:46:22 --> Model Class Initialized
INFO - 2018-02-12 11:46:22 --> Model Class Initialized
INFO - 2018-02-12 11:46:22 --> Model Class Initialized
INFO - 2018-02-12 11:46:22 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 11:46:22 --> Final output sent to browser
DEBUG - 2018-02-12 11:46:22 --> Total execution time: 0.1047
INFO - 2018-02-12 06:16:25 --> Config Class Initialized
INFO - 2018-02-12 06:16:25 --> Hooks Class Initialized
DEBUG - 2018-02-12 06:16:25 --> UTF-8 Support Enabled
INFO - 2018-02-12 06:16:25 --> Utf8 Class Initialized
INFO - 2018-02-12 06:16:25 --> URI Class Initialized
INFO - 2018-02-12 06:16:25 --> Router Class Initialized
INFO - 2018-02-12 06:16:25 --> Output Class Initialized
INFO - 2018-02-12 06:16:25 --> Security Class Initialized
DEBUG - 2018-02-12 06:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 06:16:25 --> Input Class Initialized
INFO - 2018-02-12 06:16:25 --> Language Class Initialized
INFO - 2018-02-12 06:16:25 --> Language Class Initialized
INFO - 2018-02-12 06:16:25 --> Config Class Initialized
INFO - 2018-02-12 06:16:25 --> Loader Class Initialized
INFO - 2018-02-12 11:46:25 --> Helper loaded: url_helper
INFO - 2018-02-12 11:46:25 --> Helper loaded: notification_helper
INFO - 2018-02-12 11:46:25 --> Helper loaded: settings_helper
INFO - 2018-02-12 11:46:25 --> Helper loaded: permission_helper
INFO - 2018-02-12 11:46:25 --> Helper loaded: users_helper
INFO - 2018-02-12 11:46:25 --> Database Driver Class Initialized
DEBUG - 2018-02-12 11:46:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 11:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 11:46:25 --> Helper loaded: form_helper
INFO - 2018-02-12 11:46:25 --> Form Validation Class Initialized
INFO - 2018-02-12 11:46:25 --> Controller Class Initialized
INFO - 2018-02-12 11:46:25 --> Model Class Initialized
INFO - 2018-02-12 11:46:25 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 11:46:25 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 11:46:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 11:46:25 --> Model Class Initialized
INFO - 2018-02-12 11:46:25 --> Model Class Initialized
INFO - 2018-02-12 11:46:25 --> Model Class Initialized
INFO - 2018-02-12 11:46:25 --> Model Class Initialized
INFO - 2018-02-12 11:46:25 --> Model Class Initialized
INFO - 2018-02-12 11:46:25 --> Model Class Initialized
INFO - 2018-02-12 11:46:25 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 11:46:25 --> Model Class Initialized
INFO - 2018-02-12 11:46:25 --> Final output sent to browser
DEBUG - 2018-02-12 11:46:25 --> Total execution time: 0.0850
INFO - 2018-02-12 06:20:16 --> Config Class Initialized
INFO - 2018-02-12 06:20:16 --> Hooks Class Initialized
DEBUG - 2018-02-12 06:20:16 --> UTF-8 Support Enabled
INFO - 2018-02-12 06:20:16 --> Utf8 Class Initialized
INFO - 2018-02-12 06:20:16 --> URI Class Initialized
INFO - 2018-02-12 06:20:16 --> Router Class Initialized
INFO - 2018-02-12 06:20:16 --> Output Class Initialized
INFO - 2018-02-12 06:20:16 --> Security Class Initialized
DEBUG - 2018-02-12 06:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 06:20:16 --> Input Class Initialized
INFO - 2018-02-12 06:20:16 --> Language Class Initialized
INFO - 2018-02-12 06:20:16 --> Language Class Initialized
INFO - 2018-02-12 06:20:16 --> Config Class Initialized
INFO - 2018-02-12 06:20:16 --> Loader Class Initialized
INFO - 2018-02-12 11:50:16 --> Helper loaded: url_helper
INFO - 2018-02-12 11:50:16 --> Helper loaded: notification_helper
INFO - 2018-02-12 11:50:16 --> Helper loaded: settings_helper
INFO - 2018-02-12 11:50:16 --> Helper loaded: permission_helper
INFO - 2018-02-12 11:50:16 --> Helper loaded: users_helper
INFO - 2018-02-12 11:50:16 --> Database Driver Class Initialized
DEBUG - 2018-02-12 11:50:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 11:50:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 11:50:16 --> Helper loaded: form_helper
INFO - 2018-02-12 11:50:16 --> Form Validation Class Initialized
INFO - 2018-02-12 11:50:16 --> Controller Class Initialized
INFO - 2018-02-12 06:20:17 --> Config Class Initialized
INFO - 2018-02-12 06:20:17 --> Hooks Class Initialized
INFO - 2018-02-12 11:50:17 --> Model Class Initialized
DEBUG - 2018-02-12 06:20:17 --> UTF-8 Support Enabled
INFO - 2018-02-12 06:20:17 --> Utf8 Class Initialized
INFO - 2018-02-12 11:50:17 --> Helper loaded: inflector_helper
INFO - 2018-02-12 06:20:17 --> URI Class Initialized
DEBUG - 2018-02-12 11:50:17 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 11:50:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 06:20:17 --> Router Class Initialized
INFO - 2018-02-12 11:50:17 --> Model Class Initialized
INFO - 2018-02-12 11:50:17 --> Model Class Initialized
INFO - 2018-02-12 11:50:17 --> Model Class Initialized
INFO - 2018-02-12 11:50:17 --> Model Class Initialized
INFO - 2018-02-12 11:50:17 --> Model Class Initialized
INFO - 2018-02-12 11:50:17 --> Model Class Initialized
INFO - 2018-02-12 11:50:17 --> Model Class Initialized
INFO - 2018-02-12 06:20:17 --> Output Class Initialized
INFO - 2018-02-12 11:50:17 --> Model Class Initialized
INFO - 2018-02-12 11:50:17 --> Model Class Initialized
INFO - 2018-02-12 11:50:17 --> Model Class Initialized
INFO - 2018-02-12 06:20:17 --> Security Class Initialized
INFO - 2018-02-12 11:50:17 --> Model Class Initialized
INFO - 2018-02-12 11:50:17 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 11:50:17 --> Model Class Initialized
DEBUG - 2018-02-12 06:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 06:20:17 --> Input Class Initialized
INFO - 2018-02-12 06:20:17 --> Language Class Initialized
INFO - 2018-02-12 11:50:17 --> Final output sent to browser
DEBUG - 2018-02-12 11:50:17 --> Total execution time: 0.1173
INFO - 2018-02-12 06:20:17 --> Language Class Initialized
INFO - 2018-02-12 06:20:17 --> Config Class Initialized
INFO - 2018-02-12 06:20:17 --> Loader Class Initialized
INFO - 2018-02-12 11:50:17 --> Helper loaded: url_helper
INFO - 2018-02-12 11:50:17 --> Helper loaded: notification_helper
INFO - 2018-02-12 11:50:17 --> Helper loaded: settings_helper
INFO - 2018-02-12 11:50:17 --> Helper loaded: permission_helper
INFO - 2018-02-12 11:50:17 --> Helper loaded: users_helper
INFO - 2018-02-12 11:50:17 --> Database Driver Class Initialized
DEBUG - 2018-02-12 11:50:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 11:50:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 11:50:17 --> Helper loaded: form_helper
INFO - 2018-02-12 11:50:17 --> Form Validation Class Initialized
INFO - 2018-02-12 11:50:17 --> Controller Class Initialized
INFO - 2018-02-12 11:50:17 --> Model Class Initialized
INFO - 2018-02-12 11:50:17 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 11:50:17 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 11:50:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 11:50:17 --> Model Class Initialized
INFO - 2018-02-12 11:50:17 --> Model Class Initialized
INFO - 2018-02-12 11:50:17 --> Model Class Initialized
INFO - 2018-02-12 11:50:17 --> Model Class Initialized
INFO - 2018-02-12 11:50:17 --> Model Class Initialized
INFO - 2018-02-12 11:50:17 --> Model Class Initialized
INFO - 2018-02-12 11:50:17 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 11:50:17 --> Model Class Initialized
INFO - 2018-02-12 11:50:17 --> Final output sent to browser
DEBUG - 2018-02-12 11:50:17 --> Total execution time: 0.1201
INFO - 2018-02-12 06:21:25 --> Config Class Initialized
INFO - 2018-02-12 06:21:25 --> Hooks Class Initialized
INFO - 2018-02-12 06:21:25 --> Config Class Initialized
INFO - 2018-02-12 06:21:25 --> Hooks Class Initialized
DEBUG - 2018-02-12 06:21:25 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 06:21:25 --> UTF-8 Support Enabled
INFO - 2018-02-12 06:21:25 --> Utf8 Class Initialized
INFO - 2018-02-12 06:21:25 --> Utf8 Class Initialized
INFO - 2018-02-12 06:21:25 --> URI Class Initialized
INFO - 2018-02-12 06:21:25 --> URI Class Initialized
INFO - 2018-02-12 06:21:25 --> Router Class Initialized
INFO - 2018-02-12 06:21:25 --> Router Class Initialized
INFO - 2018-02-12 06:21:25 --> Output Class Initialized
INFO - 2018-02-12 06:21:25 --> Output Class Initialized
INFO - 2018-02-12 06:21:25 --> Security Class Initialized
INFO - 2018-02-12 06:21:25 --> Security Class Initialized
DEBUG - 2018-02-12 06:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 06:21:25 --> Input Class Initialized
DEBUG - 2018-02-12 06:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 06:21:25 --> Input Class Initialized
INFO - 2018-02-12 06:21:25 --> Language Class Initialized
INFO - 2018-02-12 06:21:25 --> Language Class Initialized
INFO - 2018-02-12 06:21:25 --> Language Class Initialized
INFO - 2018-02-12 06:21:25 --> Config Class Initialized
INFO - 2018-02-12 06:21:25 --> Loader Class Initialized
INFO - 2018-02-12 11:51:25 --> Helper loaded: url_helper
INFO - 2018-02-12 11:51:25 --> Helper loaded: notification_helper
INFO - 2018-02-12 11:51:25 --> Helper loaded: settings_helper
INFO - 2018-02-12 11:51:25 --> Helper loaded: permission_helper
INFO - 2018-02-12 06:21:25 --> Language Class Initialized
INFO - 2018-02-12 06:21:25 --> Config Class Initialized
INFO - 2018-02-12 06:21:25 --> Loader Class Initialized
INFO - 2018-02-12 11:51:25 --> Helper loaded: users_helper
INFO - 2018-02-12 11:51:25 --> Helper loaded: url_helper
INFO - 2018-02-12 11:51:25 --> Helper loaded: notification_helper
INFO - 2018-02-12 11:51:25 --> Helper loaded: settings_helper
INFO - 2018-02-12 11:51:25 --> Helper loaded: permission_helper
INFO - 2018-02-12 11:51:25 --> Helper loaded: users_helper
INFO - 2018-02-12 11:51:25 --> Database Driver Class Initialized
INFO - 2018-02-12 11:51:25 --> Database Driver Class Initialized
DEBUG - 2018-02-12 11:51:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 11:51:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-12 11:51:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 11:51:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 11:51:25 --> Helper loaded: form_helper
INFO - 2018-02-12 11:51:25 --> Form Validation Class Initialized
INFO - 2018-02-12 11:51:25 --> Controller Class Initialized
INFO - 2018-02-12 11:51:25 --> Helper loaded: form_helper
INFO - 2018-02-12 11:51:25 --> Form Validation Class Initialized
INFO - 2018-02-12 11:51:25 --> Controller Class Initialized
INFO - 2018-02-12 11:51:25 --> Model Class Initialized
INFO - 2018-02-12 11:51:25 --> Helper loaded: inflector_helper
INFO - 2018-02-12 11:51:25 --> Model Class Initialized
DEBUG - 2018-02-12 11:51:25 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 11:51:25 --> Helper loaded: inflector_helper
INFO - 2018-02-12 11:51:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 11:51:25 --> Model Class Initialized
INFO - 2018-02-12 11:51:25 --> Model Class Initialized
DEBUG - 2018-02-12 11:51:25 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 11:51:25 --> Model Class Initialized
INFO - 2018-02-12 11:51:25 --> Model Class Initialized
INFO - 2018-02-12 11:51:25 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 11:51:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 11:51:25 --> Model Class Initialized
INFO - 2018-02-12 11:51:25 --> Model Class Initialized
INFO - 2018-02-12 11:51:25 --> Model Class Initialized
INFO - 2018-02-12 11:51:25 --> Model Class Initialized
INFO - 2018-02-12 11:51:25 --> Final output sent to browser
DEBUG - 2018-02-12 11:51:25 --> Total execution time: 0.1858
INFO - 2018-02-12 11:51:25 --> Model Class Initialized
INFO - 2018-02-12 11:51:25 --> Model Class Initialized
INFO - 2018-02-12 11:51:25 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 11:51:25 --> Final output sent to browser
DEBUG - 2018-02-12 11:51:25 --> Total execution time: 0.1943
INFO - 2018-02-12 06:21:30 --> Config Class Initialized
INFO - 2018-02-12 06:21:30 --> Hooks Class Initialized
DEBUG - 2018-02-12 06:21:30 --> UTF-8 Support Enabled
INFO - 2018-02-12 06:21:30 --> Utf8 Class Initialized
INFO - 2018-02-12 06:21:30 --> URI Class Initialized
INFO - 2018-02-12 06:21:30 --> Router Class Initialized
INFO - 2018-02-12 06:21:30 --> Output Class Initialized
INFO - 2018-02-12 06:21:30 --> Security Class Initialized
DEBUG - 2018-02-12 06:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 06:21:30 --> Input Class Initialized
INFO - 2018-02-12 06:21:30 --> Language Class Initialized
INFO - 2018-02-12 06:21:30 --> Language Class Initialized
INFO - 2018-02-12 06:21:30 --> Config Class Initialized
INFO - 2018-02-12 06:21:30 --> Loader Class Initialized
INFO - 2018-02-12 11:51:30 --> Helper loaded: url_helper
INFO - 2018-02-12 11:51:30 --> Helper loaded: notification_helper
INFO - 2018-02-12 11:51:30 --> Helper loaded: settings_helper
INFO - 2018-02-12 11:51:30 --> Helper loaded: permission_helper
INFO - 2018-02-12 11:51:30 --> Helper loaded: users_helper
INFO - 2018-02-12 11:51:30 --> Database Driver Class Initialized
DEBUG - 2018-02-12 11:51:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 11:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 11:51:30 --> Helper loaded: form_helper
INFO - 2018-02-12 11:51:30 --> Form Validation Class Initialized
INFO - 2018-02-12 11:51:30 --> Controller Class Initialized
INFO - 2018-02-12 11:51:30 --> Model Class Initialized
INFO - 2018-02-12 11:51:30 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 11:51:30 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 11:51:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 11:51:30 --> Model Class Initialized
INFO - 2018-02-12 11:51:30 --> Model Class Initialized
INFO - 2018-02-12 11:51:30 --> Model Class Initialized
INFO - 2018-02-12 11:51:30 --> Model Class Initialized
INFO - 2018-02-12 11:51:30 --> Model Class Initialized
INFO - 2018-02-12 11:51:30 --> Model Class Initialized
INFO - 2018-02-12 11:51:30 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 11:51:30 --> Model Class Initialized
INFO - 2018-02-12 11:51:30 --> Final output sent to browser
DEBUG - 2018-02-12 11:51:30 --> Total execution time: 0.1027
INFO - 2018-02-12 06:22:28 --> Config Class Initialized
INFO - 2018-02-12 06:22:28 --> Hooks Class Initialized
DEBUG - 2018-02-12 06:22:28 --> UTF-8 Support Enabled
INFO - 2018-02-12 06:22:28 --> Utf8 Class Initialized
INFO - 2018-02-12 06:22:28 --> URI Class Initialized
INFO - 2018-02-12 06:22:28 --> Router Class Initialized
INFO - 2018-02-12 06:22:28 --> Output Class Initialized
INFO - 2018-02-12 06:22:28 --> Security Class Initialized
DEBUG - 2018-02-12 06:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 06:22:28 --> Input Class Initialized
INFO - 2018-02-12 06:22:28 --> Language Class Initialized
INFO - 2018-02-12 06:22:28 --> Language Class Initialized
INFO - 2018-02-12 06:22:28 --> Config Class Initialized
INFO - 2018-02-12 06:22:28 --> Loader Class Initialized
INFO - 2018-02-12 11:52:28 --> Helper loaded: url_helper
INFO - 2018-02-12 11:52:28 --> Helper loaded: notification_helper
INFO - 2018-02-12 11:52:28 --> Helper loaded: settings_helper
INFO - 2018-02-12 11:52:28 --> Helper loaded: permission_helper
INFO - 2018-02-12 11:52:28 --> Helper loaded: users_helper
INFO - 2018-02-12 11:52:28 --> Database Driver Class Initialized
DEBUG - 2018-02-12 11:52:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 11:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 11:52:28 --> Helper loaded: form_helper
INFO - 2018-02-12 11:52:28 --> Form Validation Class Initialized
INFO - 2018-02-12 11:52:28 --> Controller Class Initialized
INFO - 2018-02-12 11:52:28 --> Model Class Initialized
INFO - 2018-02-12 11:52:28 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 11:52:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 11:52:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 11:52:28 --> Model Class Initialized
INFO - 2018-02-12 11:52:28 --> Model Class Initialized
INFO - 2018-02-12 11:52:28 --> Model Class Initialized
INFO - 2018-02-12 11:52:28 --> Model Class Initialized
INFO - 2018-02-12 11:52:28 --> Model Class Initialized
INFO - 2018-02-12 11:52:28 --> Model Class Initialized
INFO - 2018-02-12 11:52:28 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 11:52:28 --> Final output sent to browser
DEBUG - 2018-02-12 11:52:28 --> Total execution time: 0.0901
INFO - 2018-02-12 06:22:29 --> Config Class Initialized
INFO - 2018-02-12 06:22:29 --> Hooks Class Initialized
DEBUG - 2018-02-12 06:22:29 --> UTF-8 Support Enabled
INFO - 2018-02-12 06:22:29 --> Utf8 Class Initialized
INFO - 2018-02-12 06:22:29 --> URI Class Initialized
INFO - 2018-02-12 06:22:29 --> Router Class Initialized
INFO - 2018-02-12 06:22:29 --> Output Class Initialized
INFO - 2018-02-12 06:22:29 --> Security Class Initialized
DEBUG - 2018-02-12 06:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 06:22:29 --> Input Class Initialized
INFO - 2018-02-12 06:22:29 --> Language Class Initialized
INFO - 2018-02-12 06:22:29 --> Language Class Initialized
INFO - 2018-02-12 06:22:29 --> Config Class Initialized
INFO - 2018-02-12 06:22:29 --> Loader Class Initialized
INFO - 2018-02-12 11:52:29 --> Helper loaded: url_helper
INFO - 2018-02-12 11:52:29 --> Helper loaded: notification_helper
INFO - 2018-02-12 11:52:29 --> Helper loaded: settings_helper
INFO - 2018-02-12 11:52:29 --> Helper loaded: permission_helper
INFO - 2018-02-12 11:52:29 --> Helper loaded: users_helper
INFO - 2018-02-12 11:52:29 --> Database Driver Class Initialized
DEBUG - 2018-02-12 11:52:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 11:52:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 11:52:29 --> Helper loaded: form_helper
INFO - 2018-02-12 11:52:29 --> Form Validation Class Initialized
INFO - 2018-02-12 11:52:29 --> Controller Class Initialized
INFO - 2018-02-12 11:52:29 --> Model Class Initialized
INFO - 2018-02-12 11:52:29 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 11:52:29 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 11:52:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 11:52:29 --> Model Class Initialized
INFO - 2018-02-12 11:52:29 --> Model Class Initialized
INFO - 2018-02-12 11:52:29 --> Model Class Initialized
INFO - 2018-02-12 11:52:29 --> Model Class Initialized
INFO - 2018-02-12 11:52:29 --> Final output sent to browser
DEBUG - 2018-02-12 11:52:29 --> Total execution time: 0.1320
INFO - 2018-02-12 06:22:33 --> Config Class Initialized
INFO - 2018-02-12 06:22:33 --> Hooks Class Initialized
DEBUG - 2018-02-12 06:22:33 --> UTF-8 Support Enabled
INFO - 2018-02-12 06:22:33 --> Utf8 Class Initialized
INFO - 2018-02-12 06:22:33 --> URI Class Initialized
INFO - 2018-02-12 06:22:33 --> Router Class Initialized
INFO - 2018-02-12 06:22:33 --> Output Class Initialized
INFO - 2018-02-12 06:22:33 --> Security Class Initialized
DEBUG - 2018-02-12 06:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 06:22:33 --> Input Class Initialized
INFO - 2018-02-12 06:22:33 --> Language Class Initialized
INFO - 2018-02-12 06:22:33 --> Language Class Initialized
INFO - 2018-02-12 06:22:33 --> Config Class Initialized
INFO - 2018-02-12 06:22:33 --> Loader Class Initialized
INFO - 2018-02-12 11:52:33 --> Helper loaded: url_helper
INFO - 2018-02-12 11:52:33 --> Helper loaded: notification_helper
INFO - 2018-02-12 11:52:33 --> Helper loaded: settings_helper
INFO - 2018-02-12 11:52:33 --> Helper loaded: permission_helper
INFO - 2018-02-12 11:52:33 --> Helper loaded: users_helper
INFO - 2018-02-12 11:52:33 --> Database Driver Class Initialized
DEBUG - 2018-02-12 11:52:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 11:52:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 11:52:33 --> Helper loaded: form_helper
INFO - 2018-02-12 11:52:33 --> Form Validation Class Initialized
INFO - 2018-02-12 11:52:33 --> Controller Class Initialized
INFO - 2018-02-12 11:52:33 --> Model Class Initialized
INFO - 2018-02-12 11:52:33 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 11:52:33 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 11:52:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 11:52:33 --> Model Class Initialized
INFO - 2018-02-12 11:52:33 --> Model Class Initialized
INFO - 2018-02-12 11:52:33 --> Model Class Initialized
INFO - 2018-02-12 11:52:33 --> Model Class Initialized
INFO - 2018-02-12 11:52:33 --> Final output sent to browser
DEBUG - 2018-02-12 11:52:33 --> Total execution time: 0.0907
INFO - 2018-02-12 06:22:34 --> Config Class Initialized
INFO - 2018-02-12 06:22:34 --> Hooks Class Initialized
DEBUG - 2018-02-12 06:22:34 --> UTF-8 Support Enabled
INFO - 2018-02-12 06:22:34 --> Utf8 Class Initialized
INFO - 2018-02-12 06:22:34 --> URI Class Initialized
INFO - 2018-02-12 06:22:34 --> Router Class Initialized
INFO - 2018-02-12 06:22:34 --> Output Class Initialized
INFO - 2018-02-12 06:22:34 --> Security Class Initialized
DEBUG - 2018-02-12 06:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 06:22:34 --> Input Class Initialized
INFO - 2018-02-12 06:22:34 --> Language Class Initialized
INFO - 2018-02-12 06:22:34 --> Language Class Initialized
INFO - 2018-02-12 06:22:34 --> Config Class Initialized
INFO - 2018-02-12 06:22:34 --> Loader Class Initialized
INFO - 2018-02-12 11:52:34 --> Helper loaded: url_helper
INFO - 2018-02-12 11:52:34 --> Helper loaded: notification_helper
INFO - 2018-02-12 11:52:34 --> Helper loaded: settings_helper
INFO - 2018-02-12 11:52:34 --> Helper loaded: permission_helper
INFO - 2018-02-12 11:52:34 --> Helper loaded: users_helper
INFO - 2018-02-12 11:52:34 --> Database Driver Class Initialized
DEBUG - 2018-02-12 11:52:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 11:52:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 11:52:34 --> Helper loaded: form_helper
INFO - 2018-02-12 11:52:34 --> Form Validation Class Initialized
INFO - 2018-02-12 11:52:34 --> Controller Class Initialized
INFO - 2018-02-12 11:52:34 --> Model Class Initialized
INFO - 2018-02-12 11:52:34 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 11:52:34 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 11:52:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 11:52:34 --> Model Class Initialized
INFO - 2018-02-12 11:52:34 --> Model Class Initialized
INFO - 2018-02-12 11:52:34 --> Model Class Initialized
INFO - 2018-02-12 11:52:34 --> Model Class Initialized
INFO - 2018-02-12 11:52:34 --> Final output sent to browser
DEBUG - 2018-02-12 11:52:34 --> Total execution time: 0.0844
INFO - 2018-02-12 06:22:41 --> Config Class Initialized
INFO - 2018-02-12 06:22:41 --> Hooks Class Initialized
DEBUG - 2018-02-12 06:22:41 --> UTF-8 Support Enabled
INFO - 2018-02-12 06:22:41 --> Utf8 Class Initialized
INFO - 2018-02-12 06:22:41 --> URI Class Initialized
INFO - 2018-02-12 06:22:41 --> Router Class Initialized
INFO - 2018-02-12 06:22:41 --> Output Class Initialized
INFO - 2018-02-12 06:22:41 --> Security Class Initialized
DEBUG - 2018-02-12 06:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 06:22:41 --> Input Class Initialized
INFO - 2018-02-12 06:22:41 --> Language Class Initialized
INFO - 2018-02-12 06:22:41 --> Language Class Initialized
INFO - 2018-02-12 06:22:41 --> Config Class Initialized
INFO - 2018-02-12 06:22:41 --> Loader Class Initialized
INFO - 2018-02-12 11:52:41 --> Helper loaded: url_helper
INFO - 2018-02-12 11:52:41 --> Helper loaded: notification_helper
INFO - 2018-02-12 11:52:41 --> Helper loaded: settings_helper
INFO - 2018-02-12 11:52:41 --> Helper loaded: permission_helper
INFO - 2018-02-12 11:52:41 --> Helper loaded: users_helper
INFO - 2018-02-12 11:52:41 --> Database Driver Class Initialized
DEBUG - 2018-02-12 11:52:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 11:52:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 11:52:41 --> Helper loaded: form_helper
INFO - 2018-02-12 11:52:41 --> Form Validation Class Initialized
INFO - 2018-02-12 11:52:41 --> Controller Class Initialized
INFO - 2018-02-12 11:52:41 --> Model Class Initialized
INFO - 2018-02-12 11:52:41 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 11:52:41 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 11:52:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 11:52:41 --> Model Class Initialized
INFO - 2018-02-12 11:52:41 --> Model Class Initialized
INFO - 2018-02-12 11:52:41 --> Model Class Initialized
INFO - 2018-02-12 11:52:41 --> Model Class Initialized
INFO - 2018-02-12 11:52:41 --> Model Class Initialized
INFO - 2018-02-12 11:52:41 --> Model Class Initialized
INFO - 2018-02-12 11:52:41 --> Model Class Initialized
INFO - 2018-02-12 11:52:41 --> Model Class Initialized
INFO - 2018-02-12 11:52:41 --> Model Class Initialized
INFO - 2018-02-12 11:52:41 --> Model Class Initialized
INFO - 2018-02-12 11:52:41 --> Model Class Initialized
INFO - 2018-02-12 11:52:41 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 11:52:41 --> Model Class Initialized
INFO - 2018-02-12 11:52:41 --> Final output sent to browser
DEBUG - 2018-02-12 11:52:41 --> Total execution time: 0.1113
INFO - 2018-02-12 06:22:44 --> Config Class Initialized
INFO - 2018-02-12 06:22:44 --> Hooks Class Initialized
DEBUG - 2018-02-12 06:22:44 --> UTF-8 Support Enabled
INFO - 2018-02-12 06:22:44 --> Utf8 Class Initialized
INFO - 2018-02-12 06:22:44 --> URI Class Initialized
INFO - 2018-02-12 06:22:44 --> Router Class Initialized
INFO - 2018-02-12 06:22:44 --> Output Class Initialized
INFO - 2018-02-12 06:22:44 --> Security Class Initialized
DEBUG - 2018-02-12 06:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 06:22:44 --> Input Class Initialized
INFO - 2018-02-12 06:22:44 --> Language Class Initialized
INFO - 2018-02-12 06:22:44 --> Language Class Initialized
INFO - 2018-02-12 06:22:44 --> Config Class Initialized
INFO - 2018-02-12 06:22:44 --> Loader Class Initialized
INFO - 2018-02-12 11:52:44 --> Helper loaded: url_helper
INFO - 2018-02-12 11:52:44 --> Helper loaded: notification_helper
INFO - 2018-02-12 11:52:44 --> Helper loaded: settings_helper
INFO - 2018-02-12 11:52:44 --> Helper loaded: permission_helper
INFO - 2018-02-12 11:52:44 --> Helper loaded: users_helper
INFO - 2018-02-12 11:52:44 --> Database Driver Class Initialized
DEBUG - 2018-02-12 11:52:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 11:52:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 11:52:44 --> Helper loaded: form_helper
INFO - 2018-02-12 11:52:44 --> Form Validation Class Initialized
INFO - 2018-02-12 11:52:44 --> Controller Class Initialized
INFO - 2018-02-12 11:52:44 --> Model Class Initialized
INFO - 2018-02-12 11:52:44 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 11:52:44 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 11:52:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 11:52:44 --> Model Class Initialized
INFO - 2018-02-12 11:52:44 --> Model Class Initialized
INFO - 2018-02-12 11:52:44 --> Model Class Initialized
INFO - 2018-02-12 11:52:44 --> Model Class Initialized
INFO - 2018-02-12 11:52:44 --> Model Class Initialized
INFO - 2018-02-12 11:52:44 --> Model Class Initialized
INFO - 2018-02-12 11:52:44 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 11:52:44 --> Final output sent to browser
DEBUG - 2018-02-12 11:52:44 --> Total execution time: 0.1170
INFO - 2018-02-12 06:22:50 --> Config Class Initialized
INFO - 2018-02-12 06:22:50 --> Hooks Class Initialized
DEBUG - 2018-02-12 06:22:50 --> UTF-8 Support Enabled
INFO - 2018-02-12 06:22:50 --> Utf8 Class Initialized
INFO - 2018-02-12 06:22:50 --> URI Class Initialized
INFO - 2018-02-12 06:22:50 --> Router Class Initialized
INFO - 2018-02-12 06:22:50 --> Output Class Initialized
INFO - 2018-02-12 06:22:50 --> Security Class Initialized
DEBUG - 2018-02-12 06:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 06:22:50 --> Input Class Initialized
INFO - 2018-02-12 06:22:50 --> Language Class Initialized
INFO - 2018-02-12 06:22:50 --> Language Class Initialized
INFO - 2018-02-12 06:22:50 --> Config Class Initialized
INFO - 2018-02-12 06:22:50 --> Loader Class Initialized
INFO - 2018-02-12 11:52:50 --> Helper loaded: url_helper
INFO - 2018-02-12 11:52:50 --> Helper loaded: notification_helper
INFO - 2018-02-12 11:52:50 --> Helper loaded: settings_helper
INFO - 2018-02-12 11:52:50 --> Helper loaded: permission_helper
INFO - 2018-02-12 11:52:50 --> Helper loaded: users_helper
INFO - 2018-02-12 11:52:50 --> Database Driver Class Initialized
DEBUG - 2018-02-12 11:52:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 11:52:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 11:52:50 --> Helper loaded: form_helper
INFO - 2018-02-12 11:52:50 --> Form Validation Class Initialized
INFO - 2018-02-12 11:52:50 --> Controller Class Initialized
INFO - 2018-02-12 11:52:50 --> Model Class Initialized
INFO - 2018-02-12 11:52:50 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 11:52:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 11:52:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 11:52:50 --> Model Class Initialized
INFO - 2018-02-12 11:52:50 --> Model Class Initialized
INFO - 2018-02-12 11:52:50 --> Model Class Initialized
INFO - 2018-02-12 11:52:50 --> Model Class Initialized
INFO - 2018-02-12 11:52:50 --> Model Class Initialized
INFO - 2018-02-12 11:52:50 --> Model Class Initialized
INFO - 2018-02-12 11:52:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 11:52:50 --> Final output sent to browser
DEBUG - 2018-02-12 11:52:50 --> Total execution time: 0.0860
INFO - 2018-02-12 06:22:50 --> Config Class Initialized
INFO - 2018-02-12 06:22:50 --> Hooks Class Initialized
DEBUG - 2018-02-12 06:22:50 --> UTF-8 Support Enabled
INFO - 2018-02-12 06:22:50 --> Utf8 Class Initialized
INFO - 2018-02-12 06:22:50 --> URI Class Initialized
INFO - 2018-02-12 06:22:50 --> Router Class Initialized
INFO - 2018-02-12 06:22:50 --> Output Class Initialized
INFO - 2018-02-12 06:22:50 --> Security Class Initialized
DEBUG - 2018-02-12 06:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 06:22:50 --> Input Class Initialized
INFO - 2018-02-12 06:22:50 --> Language Class Initialized
INFO - 2018-02-12 06:22:50 --> Language Class Initialized
INFO - 2018-02-12 06:22:50 --> Config Class Initialized
INFO - 2018-02-12 06:22:50 --> Loader Class Initialized
INFO - 2018-02-12 11:52:50 --> Helper loaded: url_helper
INFO - 2018-02-12 11:52:50 --> Helper loaded: notification_helper
INFO - 2018-02-12 11:52:50 --> Helper loaded: settings_helper
INFO - 2018-02-12 11:52:50 --> Helper loaded: permission_helper
INFO - 2018-02-12 11:52:50 --> Helper loaded: users_helper
INFO - 2018-02-12 11:52:50 --> Database Driver Class Initialized
DEBUG - 2018-02-12 11:52:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 11:52:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 11:52:50 --> Helper loaded: form_helper
INFO - 2018-02-12 11:52:50 --> Form Validation Class Initialized
INFO - 2018-02-12 11:52:50 --> Controller Class Initialized
INFO - 2018-02-12 11:52:50 --> Model Class Initialized
INFO - 2018-02-12 11:52:50 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 11:52:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 11:52:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 11:52:50 --> Model Class Initialized
INFO - 2018-02-12 11:52:50 --> Model Class Initialized
INFO - 2018-02-12 11:52:50 --> Model Class Initialized
INFO - 2018-02-12 11:52:50 --> Model Class Initialized
INFO - 2018-02-12 11:52:50 --> Model Class Initialized
INFO - 2018-02-12 11:52:50 --> Model Class Initialized
INFO - 2018-02-12 11:52:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 11:52:50 --> Model Class Initialized
INFO - 2018-02-12 11:52:50 --> Final output sent to browser
DEBUG - 2018-02-12 11:52:50 --> Total execution time: 0.1159
INFO - 2018-02-12 06:25:55 --> Config Class Initialized
INFO - 2018-02-12 06:25:55 --> Hooks Class Initialized
DEBUG - 2018-02-12 06:25:55 --> UTF-8 Support Enabled
INFO - 2018-02-12 06:25:55 --> Utf8 Class Initialized
INFO - 2018-02-12 06:25:55 --> URI Class Initialized
INFO - 2018-02-12 06:25:55 --> Router Class Initialized
INFO - 2018-02-12 06:25:55 --> Output Class Initialized
INFO - 2018-02-12 06:25:55 --> Security Class Initialized
DEBUG - 2018-02-12 06:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 06:25:55 --> Input Class Initialized
INFO - 2018-02-12 06:25:55 --> Language Class Initialized
INFO - 2018-02-12 06:25:55 --> Language Class Initialized
INFO - 2018-02-12 06:25:55 --> Config Class Initialized
INFO - 2018-02-12 06:25:55 --> Loader Class Initialized
INFO - 2018-02-12 11:55:55 --> Helper loaded: url_helper
INFO - 2018-02-12 11:55:55 --> Helper loaded: notification_helper
INFO - 2018-02-12 11:55:55 --> Helper loaded: settings_helper
INFO - 2018-02-12 11:55:55 --> Helper loaded: permission_helper
INFO - 2018-02-12 11:55:56 --> Helper loaded: users_helper
INFO - 2018-02-12 11:55:56 --> Database Driver Class Initialized
DEBUG - 2018-02-12 11:55:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 11:55:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 11:55:56 --> Helper loaded: form_helper
INFO - 2018-02-12 11:55:56 --> Form Validation Class Initialized
INFO - 2018-02-12 11:55:56 --> Controller Class Initialized
INFO - 2018-02-12 11:55:56 --> Model Class Initialized
INFO - 2018-02-12 11:55:56 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 11:55:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 11:55:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 11:55:56 --> Model Class Initialized
INFO - 2018-02-12 11:55:56 --> Model Class Initialized
INFO - 2018-02-12 11:55:56 --> Model Class Initialized
INFO - 2018-02-12 11:55:56 --> Model Class Initialized
INFO - 2018-02-12 11:55:56 --> Model Class Initialized
INFO - 2018-02-12 11:55:56 --> Model Class Initialized
INFO - 2018-02-12 11:55:56 --> Model Class Initialized
INFO - 2018-02-12 11:55:56 --> Model Class Initialized
INFO - 2018-02-12 11:55:56 --> Model Class Initialized
INFO - 2018-02-12 11:55:56 --> Model Class Initialized
INFO - 2018-02-12 11:55:56 --> Model Class Initialized
INFO - 2018-02-12 11:55:56 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 11:55:56 --> Model Class Initialized
INFO - 2018-02-12 11:55:56 --> Final output sent to browser
DEBUG - 2018-02-12 11:55:56 --> Total execution time: 0.1401
INFO - 2018-02-12 06:25:56 --> Config Class Initialized
INFO - 2018-02-12 06:25:56 --> Hooks Class Initialized
DEBUG - 2018-02-12 06:25:56 --> UTF-8 Support Enabled
INFO - 2018-02-12 06:25:56 --> Utf8 Class Initialized
INFO - 2018-02-12 06:25:56 --> URI Class Initialized
INFO - 2018-02-12 06:25:56 --> Router Class Initialized
INFO - 2018-02-12 06:25:56 --> Output Class Initialized
INFO - 2018-02-12 06:25:56 --> Security Class Initialized
DEBUG - 2018-02-12 06:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 06:25:56 --> Input Class Initialized
INFO - 2018-02-12 06:25:56 --> Language Class Initialized
INFO - 2018-02-12 06:25:56 --> Language Class Initialized
INFO - 2018-02-12 06:25:56 --> Config Class Initialized
INFO - 2018-02-12 06:25:56 --> Loader Class Initialized
INFO - 2018-02-12 11:55:56 --> Helper loaded: url_helper
INFO - 2018-02-12 11:55:56 --> Helper loaded: notification_helper
INFO - 2018-02-12 11:55:56 --> Helper loaded: settings_helper
INFO - 2018-02-12 11:55:56 --> Helper loaded: permission_helper
INFO - 2018-02-12 11:55:56 --> Helper loaded: users_helper
INFO - 2018-02-12 11:55:56 --> Database Driver Class Initialized
DEBUG - 2018-02-12 11:55:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 11:55:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 11:55:56 --> Helper loaded: form_helper
INFO - 2018-02-12 11:55:56 --> Form Validation Class Initialized
INFO - 2018-02-12 11:55:56 --> Controller Class Initialized
INFO - 2018-02-12 11:55:56 --> Model Class Initialized
INFO - 2018-02-12 11:55:56 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 11:55:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 11:55:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 11:55:56 --> Model Class Initialized
INFO - 2018-02-12 11:55:56 --> Model Class Initialized
INFO - 2018-02-12 11:55:56 --> Model Class Initialized
INFO - 2018-02-12 11:55:56 --> Model Class Initialized
INFO - 2018-02-12 11:55:56 --> Model Class Initialized
INFO - 2018-02-12 11:55:56 --> Model Class Initialized
INFO - 2018-02-12 11:55:56 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 11:55:56 --> Model Class Initialized
INFO - 2018-02-12 11:55:56 --> Final output sent to browser
DEBUG - 2018-02-12 11:55:56 --> Total execution time: 0.1181
INFO - 2018-02-12 06:26:01 --> Config Class Initialized
INFO - 2018-02-12 06:26:01 --> Hooks Class Initialized
DEBUG - 2018-02-12 06:26:01 --> UTF-8 Support Enabled
INFO - 2018-02-12 06:26:01 --> Utf8 Class Initialized
INFO - 2018-02-12 06:26:01 --> URI Class Initialized
INFO - 2018-02-12 06:26:01 --> Router Class Initialized
INFO - 2018-02-12 06:26:01 --> Output Class Initialized
INFO - 2018-02-12 06:26:01 --> Security Class Initialized
DEBUG - 2018-02-12 06:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 06:26:01 --> Input Class Initialized
INFO - 2018-02-12 06:26:01 --> Language Class Initialized
INFO - 2018-02-12 06:26:02 --> Language Class Initialized
INFO - 2018-02-12 06:26:02 --> Config Class Initialized
INFO - 2018-02-12 06:26:02 --> Loader Class Initialized
INFO - 2018-02-12 11:56:02 --> Helper loaded: url_helper
INFO - 2018-02-12 11:56:02 --> Helper loaded: notification_helper
INFO - 2018-02-12 11:56:02 --> Helper loaded: settings_helper
INFO - 2018-02-12 11:56:02 --> Helper loaded: permission_helper
INFO - 2018-02-12 11:56:02 --> Helper loaded: users_helper
INFO - 2018-02-12 11:56:02 --> Database Driver Class Initialized
DEBUG - 2018-02-12 11:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 11:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 11:56:02 --> Helper loaded: form_helper
INFO - 2018-02-12 11:56:02 --> Form Validation Class Initialized
INFO - 2018-02-12 11:56:02 --> Controller Class Initialized
INFO - 2018-02-12 11:56:02 --> Model Class Initialized
INFO - 2018-02-12 11:56:02 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 11:56:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 11:56:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 11:56:02 --> Model Class Initialized
INFO - 2018-02-12 11:56:02 --> Model Class Initialized
INFO - 2018-02-12 11:56:02 --> Model Class Initialized
INFO - 2018-02-12 11:56:02 --> Model Class Initialized
INFO - 2018-02-12 11:56:02 --> Model Class Initialized
INFO - 2018-02-12 11:56:02 --> Model Class Initialized
INFO - 2018-02-12 11:56:02 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 11:56:02 --> Final output sent to browser
DEBUG - 2018-02-12 11:56:02 --> Total execution time: 0.1340
INFO - 2018-02-12 06:26:02 --> Config Class Initialized
INFO - 2018-02-12 06:26:02 --> Hooks Class Initialized
DEBUG - 2018-02-12 06:26:02 --> UTF-8 Support Enabled
INFO - 2018-02-12 06:26:02 --> Utf8 Class Initialized
INFO - 2018-02-12 06:26:02 --> URI Class Initialized
INFO - 2018-02-12 06:26:02 --> Router Class Initialized
INFO - 2018-02-12 06:26:02 --> Output Class Initialized
INFO - 2018-02-12 06:26:02 --> Security Class Initialized
DEBUG - 2018-02-12 06:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 06:26:02 --> Input Class Initialized
INFO - 2018-02-12 06:26:02 --> Language Class Initialized
INFO - 2018-02-12 06:26:02 --> Language Class Initialized
INFO - 2018-02-12 06:26:02 --> Config Class Initialized
INFO - 2018-02-12 06:26:02 --> Loader Class Initialized
INFO - 2018-02-12 11:56:02 --> Helper loaded: url_helper
INFO - 2018-02-12 11:56:02 --> Helper loaded: notification_helper
INFO - 2018-02-12 11:56:02 --> Helper loaded: settings_helper
INFO - 2018-02-12 11:56:02 --> Helper loaded: permission_helper
INFO - 2018-02-12 11:56:02 --> Helper loaded: users_helper
INFO - 2018-02-12 11:56:02 --> Database Driver Class Initialized
DEBUG - 2018-02-12 11:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 11:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 11:56:02 --> Helper loaded: form_helper
INFO - 2018-02-12 11:56:02 --> Form Validation Class Initialized
INFO - 2018-02-12 11:56:02 --> Controller Class Initialized
INFO - 2018-02-12 11:56:02 --> Model Class Initialized
INFO - 2018-02-12 11:56:02 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 11:56:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 11:56:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 11:56:02 --> Model Class Initialized
INFO - 2018-02-12 11:56:02 --> Model Class Initialized
INFO - 2018-02-12 11:56:02 --> Model Class Initialized
INFO - 2018-02-12 11:56:02 --> Model Class Initialized
INFO - 2018-02-12 11:56:02 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 11:56:02 --> Final output sent to browser
DEBUG - 2018-02-12 11:56:02 --> Total execution time: 0.1054
INFO - 2018-02-12 06:26:05 --> Config Class Initialized
INFO - 2018-02-12 06:26:05 --> Hooks Class Initialized
DEBUG - 2018-02-12 06:26:05 --> UTF-8 Support Enabled
INFO - 2018-02-12 06:26:05 --> Utf8 Class Initialized
INFO - 2018-02-12 06:26:05 --> URI Class Initialized
INFO - 2018-02-12 06:26:05 --> Router Class Initialized
INFO - 2018-02-12 06:26:05 --> Output Class Initialized
INFO - 2018-02-12 06:26:05 --> Security Class Initialized
DEBUG - 2018-02-12 06:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 06:26:05 --> Input Class Initialized
INFO - 2018-02-12 06:26:05 --> Language Class Initialized
INFO - 2018-02-12 06:26:05 --> Language Class Initialized
INFO - 2018-02-12 06:26:05 --> Config Class Initialized
INFO - 2018-02-12 06:26:05 --> Loader Class Initialized
INFO - 2018-02-12 11:56:05 --> Helper loaded: url_helper
INFO - 2018-02-12 11:56:05 --> Helper loaded: notification_helper
INFO - 2018-02-12 11:56:05 --> Helper loaded: settings_helper
INFO - 2018-02-12 11:56:05 --> Helper loaded: permission_helper
INFO - 2018-02-12 11:56:05 --> Helper loaded: users_helper
INFO - 2018-02-12 11:56:05 --> Database Driver Class Initialized
DEBUG - 2018-02-12 11:56:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 11:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 11:56:05 --> Helper loaded: form_helper
INFO - 2018-02-12 11:56:05 --> Form Validation Class Initialized
INFO - 2018-02-12 11:56:05 --> Controller Class Initialized
INFO - 2018-02-12 11:56:05 --> Model Class Initialized
INFO - 2018-02-12 11:56:05 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 11:56:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 11:56:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 11:56:05 --> Model Class Initialized
INFO - 2018-02-12 11:56:05 --> Model Class Initialized
INFO - 2018-02-12 11:56:05 --> Model Class Initialized
INFO - 2018-02-12 11:56:05 --> Model Class Initialized
INFO - 2018-02-12 11:56:05 --> Model Class Initialized
INFO - 2018-02-12 11:56:05 --> Model Class Initialized
INFO - 2018-02-12 11:56:05 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 11:56:05 --> Model Class Initialized
INFO - 2018-02-12 11:56:05 --> Final output sent to browser
DEBUG - 2018-02-12 11:56:05 --> Total execution time: 0.1175
INFO - 2018-02-12 06:33:47 --> Config Class Initialized
INFO - 2018-02-12 06:33:47 --> Hooks Class Initialized
DEBUG - 2018-02-12 06:33:47 --> UTF-8 Support Enabled
INFO - 2018-02-12 06:33:47 --> Utf8 Class Initialized
INFO - 2018-02-12 06:33:47 --> URI Class Initialized
INFO - 2018-02-12 06:33:47 --> Router Class Initialized
INFO - 2018-02-12 06:33:47 --> Output Class Initialized
INFO - 2018-02-12 06:33:47 --> Security Class Initialized
DEBUG - 2018-02-12 06:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 06:33:47 --> Input Class Initialized
INFO - 2018-02-12 06:33:47 --> Language Class Initialized
INFO - 2018-02-12 06:33:47 --> Language Class Initialized
INFO - 2018-02-12 06:33:47 --> Config Class Initialized
INFO - 2018-02-12 06:33:47 --> Loader Class Initialized
INFO - 2018-02-12 12:03:47 --> Helper loaded: url_helper
INFO - 2018-02-12 12:03:47 --> Helper loaded: notification_helper
INFO - 2018-02-12 12:03:47 --> Helper loaded: settings_helper
INFO - 2018-02-12 12:03:47 --> Helper loaded: permission_helper
INFO - 2018-02-12 12:03:47 --> Helper loaded: users_helper
INFO - 2018-02-12 12:03:47 --> Database Driver Class Initialized
DEBUG - 2018-02-12 12:03:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 12:03:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 12:03:47 --> Helper loaded: form_helper
INFO - 2018-02-12 12:03:47 --> Form Validation Class Initialized
INFO - 2018-02-12 12:03:47 --> Controller Class Initialized
INFO - 2018-02-12 12:03:47 --> Model Class Initialized
INFO - 2018-02-12 12:03:47 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 12:03:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 12:03:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 12:03:47 --> Model Class Initialized
INFO - 2018-02-12 12:03:47 --> Model Class Initialized
INFO - 2018-02-12 12:03:47 --> Model Class Initialized
INFO - 2018-02-12 12:03:47 --> Model Class Initialized
INFO - 2018-02-12 12:03:47 --> Model Class Initialized
INFO - 2018-02-12 12:03:47 --> Model Class Initialized
INFO - 2018-02-12 12:03:47 --> Model Class Initialized
INFO - 2018-02-12 12:03:47 --> Model Class Initialized
INFO - 2018-02-12 12:03:47 --> Model Class Initialized
INFO - 2018-02-12 12:03:47 --> Model Class Initialized
INFO - 2018-02-12 12:03:47 --> Model Class Initialized
INFO - 2018-02-12 12:03:47 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 12:03:47 --> Model Class Initialized
INFO - 2018-02-12 12:03:47 --> Final output sent to browser
DEBUG - 2018-02-12 12:03:47 --> Total execution time: 0.1210
INFO - 2018-02-12 06:33:47 --> Config Class Initialized
INFO - 2018-02-12 06:33:47 --> Hooks Class Initialized
DEBUG - 2018-02-12 06:33:47 --> UTF-8 Support Enabled
INFO - 2018-02-12 06:33:47 --> Utf8 Class Initialized
INFO - 2018-02-12 06:33:47 --> URI Class Initialized
INFO - 2018-02-12 06:33:47 --> Router Class Initialized
INFO - 2018-02-12 06:33:47 --> Output Class Initialized
INFO - 2018-02-12 06:33:47 --> Security Class Initialized
DEBUG - 2018-02-12 06:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 06:33:47 --> Input Class Initialized
INFO - 2018-02-12 06:33:47 --> Language Class Initialized
INFO - 2018-02-12 06:33:47 --> Language Class Initialized
INFO - 2018-02-12 06:33:47 --> Config Class Initialized
INFO - 2018-02-12 06:33:47 --> Loader Class Initialized
INFO - 2018-02-12 12:03:47 --> Helper loaded: url_helper
INFO - 2018-02-12 12:03:47 --> Helper loaded: notification_helper
INFO - 2018-02-12 12:03:47 --> Helper loaded: settings_helper
INFO - 2018-02-12 12:03:47 --> Helper loaded: permission_helper
INFO - 2018-02-12 12:03:47 --> Helper loaded: users_helper
INFO - 2018-02-12 12:03:47 --> Database Driver Class Initialized
DEBUG - 2018-02-12 12:03:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 12:03:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 12:03:47 --> Helper loaded: form_helper
INFO - 2018-02-12 12:03:47 --> Form Validation Class Initialized
INFO - 2018-02-12 12:03:47 --> Controller Class Initialized
INFO - 2018-02-12 12:03:47 --> Model Class Initialized
INFO - 2018-02-12 12:03:47 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 12:03:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 12:03:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 12:03:47 --> Model Class Initialized
INFO - 2018-02-12 12:03:47 --> Model Class Initialized
INFO - 2018-02-12 12:03:47 --> Model Class Initialized
INFO - 2018-02-12 12:03:47 --> Model Class Initialized
INFO - 2018-02-12 12:03:47 --> Model Class Initialized
INFO - 2018-02-12 12:03:47 --> Model Class Initialized
INFO - 2018-02-12 12:03:47 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 12:03:47 --> Model Class Initialized
INFO - 2018-02-12 12:03:47 --> Final output sent to browser
DEBUG - 2018-02-12 12:03:47 --> Total execution time: 0.1065
INFO - 2018-02-12 06:33:53 --> Config Class Initialized
INFO - 2018-02-12 06:33:53 --> Config Class Initialized
INFO - 2018-02-12 06:33:53 --> Hooks Class Initialized
INFO - 2018-02-12 06:33:53 --> Hooks Class Initialized
DEBUG - 2018-02-12 06:33:53 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 06:33:53 --> UTF-8 Support Enabled
INFO - 2018-02-12 06:33:53 --> Utf8 Class Initialized
INFO - 2018-02-12 06:33:53 --> Utf8 Class Initialized
INFO - 2018-02-12 06:33:53 --> URI Class Initialized
INFO - 2018-02-12 06:33:53 --> URI Class Initialized
INFO - 2018-02-12 06:33:53 --> Router Class Initialized
INFO - 2018-02-12 06:33:53 --> Router Class Initialized
INFO - 2018-02-12 06:33:53 --> Output Class Initialized
INFO - 2018-02-12 06:33:53 --> Output Class Initialized
INFO - 2018-02-12 06:33:53 --> Security Class Initialized
INFO - 2018-02-12 06:33:53 --> Security Class Initialized
DEBUG - 2018-02-12 06:33:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 06:33:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 06:33:53 --> Input Class Initialized
INFO - 2018-02-12 06:33:53 --> Input Class Initialized
INFO - 2018-02-12 06:33:53 --> Language Class Initialized
INFO - 2018-02-12 06:33:53 --> Language Class Initialized
INFO - 2018-02-12 06:33:53 --> Language Class Initialized
INFO - 2018-02-12 06:33:53 --> Config Class Initialized
INFO - 2018-02-12 06:33:53 --> Loader Class Initialized
INFO - 2018-02-12 12:03:53 --> Helper loaded: url_helper
INFO - 2018-02-12 12:03:53 --> Helper loaded: notification_helper
INFO - 2018-02-12 12:03:53 --> Helper loaded: settings_helper
INFO - 2018-02-12 12:03:53 --> Helper loaded: permission_helper
INFO - 2018-02-12 12:03:53 --> Helper loaded: users_helper
INFO - 2018-02-12 06:33:53 --> Language Class Initialized
INFO - 2018-02-12 06:33:53 --> Config Class Initialized
INFO - 2018-02-12 06:33:53 --> Loader Class Initialized
INFO - 2018-02-12 12:03:53 --> Helper loaded: url_helper
INFO - 2018-02-12 12:03:53 --> Helper loaded: notification_helper
INFO - 2018-02-12 12:03:53 --> Helper loaded: settings_helper
INFO - 2018-02-12 12:03:53 --> Helper loaded: permission_helper
INFO - 2018-02-12 12:03:53 --> Helper loaded: users_helper
INFO - 2018-02-12 12:03:53 --> Database Driver Class Initialized
DEBUG - 2018-02-12 12:03:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 12:03:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 12:03:53 --> Database Driver Class Initialized
DEBUG - 2018-02-12 12:03:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 12:03:53 --> Helper loaded: form_helper
INFO - 2018-02-12 12:03:53 --> Form Validation Class Initialized
INFO - 2018-02-12 12:03:53 --> Controller Class Initialized
INFO - 2018-02-12 12:03:53 --> Model Class Initialized
INFO - 2018-02-12 12:03:53 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 12:03:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 12:03:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 12:03:53 --> Model Class Initialized
INFO - 2018-02-12 12:03:53 --> Model Class Initialized
INFO - 2018-02-12 12:03:53 --> Model Class Initialized
INFO - 2018-02-12 12:03:53 --> Model Class Initialized
INFO - 2018-02-12 12:03:53 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 12:03:53 --> Final output sent to browser
DEBUG - 2018-02-12 12:03:53 --> Total execution time: 0.1119
INFO - 2018-02-12 12:03:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 12:03:53 --> Helper loaded: form_helper
INFO - 2018-02-12 12:03:53 --> Form Validation Class Initialized
INFO - 2018-02-12 12:03:53 --> Controller Class Initialized
INFO - 2018-02-12 12:03:53 --> Model Class Initialized
INFO - 2018-02-12 12:03:53 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 12:03:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 12:03:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 12:03:53 --> Model Class Initialized
INFO - 2018-02-12 12:03:53 --> Model Class Initialized
INFO - 2018-02-12 12:03:53 --> Model Class Initialized
INFO - 2018-02-12 12:03:53 --> Model Class Initialized
INFO - 2018-02-12 12:03:53 --> Model Class Initialized
INFO - 2018-02-12 12:03:53 --> Model Class Initialized
INFO - 2018-02-12 12:03:53 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 12:03:53 --> Final output sent to browser
DEBUG - 2018-02-12 12:03:53 --> Total execution time: 0.1487
INFO - 2018-02-12 06:33:56 --> Config Class Initialized
INFO - 2018-02-12 06:33:56 --> Hooks Class Initialized
DEBUG - 2018-02-12 06:33:56 --> UTF-8 Support Enabled
INFO - 2018-02-12 06:33:56 --> Utf8 Class Initialized
INFO - 2018-02-12 06:33:56 --> URI Class Initialized
INFO - 2018-02-12 06:33:56 --> Router Class Initialized
INFO - 2018-02-12 06:33:56 --> Output Class Initialized
INFO - 2018-02-12 06:33:56 --> Security Class Initialized
DEBUG - 2018-02-12 06:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 06:33:56 --> Input Class Initialized
INFO - 2018-02-12 06:33:56 --> Language Class Initialized
INFO - 2018-02-12 06:33:56 --> Language Class Initialized
INFO - 2018-02-12 06:33:56 --> Config Class Initialized
INFO - 2018-02-12 06:33:56 --> Loader Class Initialized
INFO - 2018-02-12 12:03:56 --> Helper loaded: url_helper
INFO - 2018-02-12 12:03:56 --> Helper loaded: notification_helper
INFO - 2018-02-12 12:03:56 --> Helper loaded: settings_helper
INFO - 2018-02-12 12:03:56 --> Helper loaded: permission_helper
INFO - 2018-02-12 12:03:56 --> Helper loaded: users_helper
INFO - 2018-02-12 12:03:56 --> Database Driver Class Initialized
DEBUG - 2018-02-12 12:03:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 12:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 12:03:56 --> Helper loaded: form_helper
INFO - 2018-02-12 12:03:56 --> Form Validation Class Initialized
INFO - 2018-02-12 12:03:56 --> Controller Class Initialized
INFO - 2018-02-12 12:03:56 --> Model Class Initialized
INFO - 2018-02-12 12:03:56 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 12:03:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 12:03:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 12:03:56 --> Model Class Initialized
INFO - 2018-02-12 12:03:56 --> Model Class Initialized
INFO - 2018-02-12 12:03:56 --> Model Class Initialized
INFO - 2018-02-12 12:03:56 --> Model Class Initialized
INFO - 2018-02-12 12:03:56 --> Model Class Initialized
INFO - 2018-02-12 12:03:56 --> Model Class Initialized
INFO - 2018-02-12 12:03:56 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 12:03:56 --> Model Class Initialized
INFO - 2018-02-12 12:03:56 --> Final output sent to browser
DEBUG - 2018-02-12 12:03:56 --> Total execution time: 0.1227
INFO - 2018-02-12 06:34:38 --> Config Class Initialized
INFO - 2018-02-12 06:34:38 --> Hooks Class Initialized
DEBUG - 2018-02-12 06:34:38 --> UTF-8 Support Enabled
INFO - 2018-02-12 06:34:38 --> Utf8 Class Initialized
INFO - 2018-02-12 06:34:38 --> URI Class Initialized
INFO - 2018-02-12 06:34:38 --> Router Class Initialized
INFO - 2018-02-12 06:34:38 --> Output Class Initialized
INFO - 2018-02-12 06:34:38 --> Security Class Initialized
DEBUG - 2018-02-12 06:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 06:34:38 --> Input Class Initialized
INFO - 2018-02-12 06:34:38 --> Language Class Initialized
INFO - 2018-02-12 06:34:38 --> Language Class Initialized
INFO - 2018-02-12 06:34:38 --> Config Class Initialized
INFO - 2018-02-12 06:34:38 --> Loader Class Initialized
INFO - 2018-02-12 12:04:38 --> Helper loaded: url_helper
INFO - 2018-02-12 12:04:38 --> Helper loaded: notification_helper
INFO - 2018-02-12 12:04:38 --> Helper loaded: settings_helper
INFO - 2018-02-12 12:04:38 --> Helper loaded: permission_helper
INFO - 2018-02-12 12:04:38 --> Helper loaded: users_helper
INFO - 2018-02-12 12:04:38 --> Database Driver Class Initialized
DEBUG - 2018-02-12 12:04:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 12:04:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 12:04:38 --> Helper loaded: form_helper
INFO - 2018-02-12 12:04:38 --> Form Validation Class Initialized
INFO - 2018-02-12 12:04:38 --> Controller Class Initialized
INFO - 2018-02-12 12:04:38 --> Model Class Initialized
INFO - 2018-02-12 12:04:38 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 12:04:38 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 12:04:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 12:04:38 --> Model Class Initialized
INFO - 2018-02-12 12:04:38 --> Model Class Initialized
INFO - 2018-02-12 12:04:38 --> Model Class Initialized
INFO - 2018-02-12 12:04:38 --> Model Class Initialized
INFO - 2018-02-12 12:04:38 --> Model Class Initialized
INFO - 2018-02-12 12:04:38 --> Model Class Initialized
INFO - 2018-02-12 12:04:38 --> Model Class Initialized
INFO - 2018-02-12 12:04:38 --> Model Class Initialized
INFO - 2018-02-12 12:04:38 --> Model Class Initialized
INFO - 2018-02-12 12:04:38 --> Model Class Initialized
INFO - 2018-02-12 12:04:38 --> Model Class Initialized
INFO - 2018-02-12 12:04:38 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 12:04:38 --> Model Class Initialized
INFO - 2018-02-12 12:04:38 --> Final output sent to browser
DEBUG - 2018-02-12 12:04:38 --> Total execution time: 0.1292
INFO - 2018-02-12 06:34:38 --> Config Class Initialized
INFO - 2018-02-12 06:34:38 --> Hooks Class Initialized
DEBUG - 2018-02-12 06:34:38 --> UTF-8 Support Enabled
INFO - 2018-02-12 06:34:38 --> Utf8 Class Initialized
INFO - 2018-02-12 06:34:38 --> URI Class Initialized
INFO - 2018-02-12 06:34:38 --> Router Class Initialized
INFO - 2018-02-12 06:34:38 --> Output Class Initialized
INFO - 2018-02-12 06:34:38 --> Security Class Initialized
DEBUG - 2018-02-12 06:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 06:34:38 --> Input Class Initialized
INFO - 2018-02-12 06:34:38 --> Language Class Initialized
INFO - 2018-02-12 06:34:38 --> Language Class Initialized
INFO - 2018-02-12 06:34:38 --> Config Class Initialized
INFO - 2018-02-12 06:34:38 --> Loader Class Initialized
INFO - 2018-02-12 12:04:38 --> Helper loaded: url_helper
INFO - 2018-02-12 12:04:38 --> Helper loaded: notification_helper
INFO - 2018-02-12 12:04:38 --> Helper loaded: settings_helper
INFO - 2018-02-12 12:04:38 --> Helper loaded: permission_helper
INFO - 2018-02-12 12:04:38 --> Helper loaded: users_helper
INFO - 2018-02-12 12:04:38 --> Database Driver Class Initialized
DEBUG - 2018-02-12 12:04:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 12:04:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 12:04:38 --> Helper loaded: form_helper
INFO - 2018-02-12 12:04:38 --> Form Validation Class Initialized
INFO - 2018-02-12 12:04:38 --> Controller Class Initialized
INFO - 2018-02-12 12:04:38 --> Model Class Initialized
INFO - 2018-02-12 12:04:38 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 12:04:38 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 12:04:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 12:04:38 --> Model Class Initialized
INFO - 2018-02-12 12:04:38 --> Model Class Initialized
INFO - 2018-02-12 12:04:38 --> Model Class Initialized
INFO - 2018-02-12 12:04:38 --> Model Class Initialized
INFO - 2018-02-12 12:04:38 --> Model Class Initialized
INFO - 2018-02-12 12:04:38 --> Model Class Initialized
INFO - 2018-02-12 12:04:38 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 12:04:38 --> Model Class Initialized
INFO - 2018-02-12 12:04:38 --> Final output sent to browser
DEBUG - 2018-02-12 12:04:38 --> Total execution time: 0.1052
INFO - 2018-02-12 06:34:44 --> Config Class Initialized
INFO - 2018-02-12 06:34:44 --> Hooks Class Initialized
DEBUG - 2018-02-12 06:34:44 --> UTF-8 Support Enabled
INFO - 2018-02-12 06:34:44 --> Utf8 Class Initialized
INFO - 2018-02-12 06:34:44 --> URI Class Initialized
INFO - 2018-02-12 06:34:44 --> Router Class Initialized
INFO - 2018-02-12 06:34:44 --> Output Class Initialized
INFO - 2018-02-12 06:34:44 --> Security Class Initialized
DEBUG - 2018-02-12 06:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 06:34:44 --> Input Class Initialized
INFO - 2018-02-12 06:34:44 --> Language Class Initialized
INFO - 2018-02-12 06:34:44 --> Language Class Initialized
INFO - 2018-02-12 06:34:44 --> Config Class Initialized
INFO - 2018-02-12 06:34:44 --> Loader Class Initialized
INFO - 2018-02-12 12:04:44 --> Helper loaded: url_helper
INFO - 2018-02-12 12:04:44 --> Helper loaded: notification_helper
INFO - 2018-02-12 12:04:44 --> Helper loaded: settings_helper
INFO - 2018-02-12 12:04:44 --> Helper loaded: permission_helper
INFO - 2018-02-12 12:04:44 --> Helper loaded: users_helper
INFO - 2018-02-12 12:04:44 --> Database Driver Class Initialized
DEBUG - 2018-02-12 12:04:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 12:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 12:04:44 --> Helper loaded: form_helper
INFO - 2018-02-12 12:04:44 --> Form Validation Class Initialized
INFO - 2018-02-12 12:04:44 --> Controller Class Initialized
INFO - 2018-02-12 12:04:44 --> Model Class Initialized
INFO - 2018-02-12 12:04:44 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 12:04:44 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 12:04:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 12:04:44 --> Model Class Initialized
INFO - 2018-02-12 12:04:44 --> Model Class Initialized
INFO - 2018-02-12 12:04:44 --> Model Class Initialized
INFO - 2018-02-12 12:04:44 --> Model Class Initialized
INFO - 2018-02-12 12:04:44 --> Final output sent to browser
DEBUG - 2018-02-12 12:04:44 --> Total execution time: 0.1075
INFO - 2018-02-12 06:44:06 --> Config Class Initialized
INFO - 2018-02-12 06:44:06 --> Hooks Class Initialized
DEBUG - 2018-02-12 06:44:06 --> UTF-8 Support Enabled
INFO - 2018-02-12 06:44:06 --> Utf8 Class Initialized
INFO - 2018-02-12 06:44:06 --> URI Class Initialized
INFO - 2018-02-12 06:44:06 --> Router Class Initialized
INFO - 2018-02-12 06:44:06 --> Output Class Initialized
INFO - 2018-02-12 06:44:06 --> Security Class Initialized
DEBUG - 2018-02-12 06:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 06:44:06 --> Input Class Initialized
INFO - 2018-02-12 06:44:06 --> Language Class Initialized
INFO - 2018-02-12 06:44:06 --> Config Class Initialized
INFO - 2018-02-12 06:44:06 --> Hooks Class Initialized
DEBUG - 2018-02-12 06:44:06 --> UTF-8 Support Enabled
INFO - 2018-02-12 06:44:06 --> Utf8 Class Initialized
INFO - 2018-02-12 06:44:06 --> Language Class Initialized
INFO - 2018-02-12 06:44:06 --> Config Class Initialized
INFO - 2018-02-12 06:44:06 --> Loader Class Initialized
INFO - 2018-02-12 06:44:06 --> URI Class Initialized
INFO - 2018-02-12 12:14:06 --> Helper loaded: url_helper
INFO - 2018-02-12 12:14:06 --> Helper loaded: notification_helper
INFO - 2018-02-12 06:44:06 --> Router Class Initialized
INFO - 2018-02-12 12:14:06 --> Helper loaded: settings_helper
INFO - 2018-02-12 12:14:06 --> Helper loaded: permission_helper
INFO - 2018-02-12 12:14:06 --> Helper loaded: users_helper
INFO - 2018-02-12 06:44:06 --> Output Class Initialized
INFO - 2018-02-12 06:44:06 --> Security Class Initialized
DEBUG - 2018-02-12 06:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 06:44:06 --> Input Class Initialized
INFO - 2018-02-12 06:44:06 --> Language Class Initialized
INFO - 2018-02-12 12:14:06 --> Database Driver Class Initialized
DEBUG - 2018-02-12 12:14:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 12:14:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 12:14:06 --> Helper loaded: form_helper
INFO - 2018-02-12 12:14:06 --> Form Validation Class Initialized
INFO - 2018-02-12 12:14:06 --> Controller Class Initialized
INFO - 2018-02-12 06:44:06 --> Language Class Initialized
INFO - 2018-02-12 06:44:06 --> Config Class Initialized
INFO - 2018-02-12 06:44:06 --> Loader Class Initialized
INFO - 2018-02-12 12:14:06 --> Helper loaded: url_helper
INFO - 2018-02-12 12:14:06 --> Helper loaded: notification_helper
INFO - 2018-02-12 12:14:06 --> Helper loaded: settings_helper
INFO - 2018-02-12 12:14:06 --> Model Class Initialized
INFO - 2018-02-12 12:14:06 --> Helper loaded: permission_helper
INFO - 2018-02-12 12:14:06 --> Helper loaded: inflector_helper
INFO - 2018-02-12 12:14:06 --> Helper loaded: users_helper
DEBUG - 2018-02-12 12:14:06 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 12:14:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 12:14:06 --> Model Class Initialized
INFO - 2018-02-12 12:14:06 --> Model Class Initialized
INFO - 2018-02-12 12:14:06 --> Model Class Initialized
INFO - 2018-02-12 12:14:06 --> Model Class Initialized
INFO - 2018-02-12 12:14:06 --> Model Class Initialized
INFO - 2018-02-12 12:14:06 --> Model Class Initialized
INFO - 2018-02-12 12:14:06 --> Model Class Initialized
INFO - 2018-02-12 12:14:06 --> Model Class Initialized
INFO - 2018-02-12 12:14:06 --> Model Class Initialized
INFO - 2018-02-12 12:14:06 --> Model Class Initialized
INFO - 2018-02-12 12:14:06 --> Model Class Initialized
INFO - 2018-02-12 12:14:06 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 12:14:06 --> Database Driver Class Initialized
INFO - 2018-02-12 12:14:06 --> Model Class Initialized
DEBUG - 2018-02-12 12:14:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 12:14:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 12:14:06 --> Helper loaded: form_helper
INFO - 2018-02-12 12:14:06 --> Form Validation Class Initialized
INFO - 2018-02-12 12:14:06 --> Controller Class Initialized
INFO - 2018-02-12 12:14:06 --> Final output sent to browser
DEBUG - 2018-02-12 12:14:06 --> Total execution time: 0.1148
INFO - 2018-02-12 12:14:06 --> Model Class Initialized
INFO - 2018-02-12 12:14:06 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 12:14:06 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 12:14:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 12:14:06 --> Model Class Initialized
INFO - 2018-02-12 12:14:06 --> Model Class Initialized
INFO - 2018-02-12 12:14:06 --> Model Class Initialized
INFO - 2018-02-12 12:14:06 --> Model Class Initialized
INFO - 2018-02-12 12:14:06 --> Model Class Initialized
INFO - 2018-02-12 12:14:06 --> Model Class Initialized
INFO - 2018-02-12 12:14:06 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 12:14:06 --> Model Class Initialized
INFO - 2018-02-12 12:14:06 --> Final output sent to browser
DEBUG - 2018-02-12 12:14:06 --> Total execution time: 0.0904
INFO - 2018-02-12 06:44:10 --> Config Class Initialized
INFO - 2018-02-12 06:44:10 --> Hooks Class Initialized
DEBUG - 2018-02-12 06:44:10 --> UTF-8 Support Enabled
INFO - 2018-02-12 06:44:10 --> Utf8 Class Initialized
INFO - 2018-02-12 06:44:10 --> URI Class Initialized
INFO - 2018-02-12 06:44:10 --> Config Class Initialized
INFO - 2018-02-12 06:44:10 --> Hooks Class Initialized
INFO - 2018-02-12 06:44:10 --> Router Class Initialized
DEBUG - 2018-02-12 06:44:10 --> UTF-8 Support Enabled
INFO - 2018-02-12 06:44:10 --> Utf8 Class Initialized
INFO - 2018-02-12 06:44:10 --> Output Class Initialized
INFO - 2018-02-12 06:44:10 --> URI Class Initialized
INFO - 2018-02-12 06:44:10 --> Security Class Initialized
DEBUG - 2018-02-12 06:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 06:44:10 --> Input Class Initialized
INFO - 2018-02-12 06:44:10 --> Router Class Initialized
INFO - 2018-02-12 06:44:10 --> Language Class Initialized
INFO - 2018-02-12 06:44:10 --> Output Class Initialized
INFO - 2018-02-12 06:44:10 --> Security Class Initialized
DEBUG - 2018-02-12 06:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 06:44:10 --> Input Class Initialized
INFO - 2018-02-12 06:44:10 --> Language Class Initialized
INFO - 2018-02-12 06:44:10 --> Language Class Initialized
INFO - 2018-02-12 06:44:10 --> Config Class Initialized
INFO - 2018-02-12 06:44:10 --> Loader Class Initialized
INFO - 2018-02-12 12:14:10 --> Helper loaded: url_helper
INFO - 2018-02-12 06:44:10 --> Language Class Initialized
INFO - 2018-02-12 06:44:10 --> Config Class Initialized
INFO - 2018-02-12 06:44:10 --> Loader Class Initialized
INFO - 2018-02-12 12:14:10 --> Helper loaded: notification_helper
INFO - 2018-02-12 12:14:10 --> Helper loaded: settings_helper
INFO - 2018-02-12 12:14:10 --> Helper loaded: permission_helper
INFO - 2018-02-12 12:14:10 --> Helper loaded: url_helper
INFO - 2018-02-12 12:14:10 --> Helper loaded: users_helper
INFO - 2018-02-12 12:14:10 --> Helper loaded: notification_helper
INFO - 2018-02-12 12:14:10 --> Helper loaded: settings_helper
INFO - 2018-02-12 12:14:10 --> Helper loaded: permission_helper
INFO - 2018-02-12 12:14:10 --> Helper loaded: users_helper
INFO - 2018-02-12 12:14:10 --> Database Driver Class Initialized
INFO - 2018-02-12 12:14:10 --> Database Driver Class Initialized
DEBUG - 2018-02-12 12:14:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 12:14:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-12 12:14:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 12:14:10 --> Helper loaded: form_helper
INFO - 2018-02-12 12:14:10 --> Form Validation Class Initialized
INFO - 2018-02-12 12:14:10 --> Controller Class Initialized
INFO - 2018-02-12 12:14:10 --> Model Class Initialized
INFO - 2018-02-12 12:14:10 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 12:14:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 12:14:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 12:14:10 --> Model Class Initialized
INFO - 2018-02-12 12:14:10 --> Model Class Initialized
INFO - 2018-02-12 12:14:10 --> Model Class Initialized
INFO - 2018-02-12 12:14:10 --> Model Class Initialized
INFO - 2018-02-12 12:14:10 --> Model Class Initialized
INFO - 2018-02-12 12:14:10 --> Model Class Initialized
INFO - 2018-02-12 12:14:10 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 12:14:10 --> Final output sent to browser
DEBUG - 2018-02-12 12:14:10 --> Total execution time: 0.1135
INFO - 2018-02-12 12:14:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 12:14:10 --> Helper loaded: form_helper
INFO - 2018-02-12 12:14:10 --> Form Validation Class Initialized
INFO - 2018-02-12 12:14:10 --> Controller Class Initialized
INFO - 2018-02-12 12:14:10 --> Model Class Initialized
INFO - 2018-02-12 12:14:10 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 12:14:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 12:14:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 12:14:10 --> Model Class Initialized
INFO - 2018-02-12 12:14:10 --> Model Class Initialized
INFO - 2018-02-12 12:14:10 --> Model Class Initialized
INFO - 2018-02-12 12:14:10 --> Model Class Initialized
INFO - 2018-02-12 12:14:10 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 12:14:10 --> Final output sent to browser
DEBUG - 2018-02-12 12:14:10 --> Total execution time: 0.1371
INFO - 2018-02-12 06:44:13 --> Config Class Initialized
INFO - 2018-02-12 06:44:13 --> Hooks Class Initialized
DEBUG - 2018-02-12 06:44:13 --> UTF-8 Support Enabled
INFO - 2018-02-12 06:44:13 --> Utf8 Class Initialized
INFO - 2018-02-12 06:44:13 --> URI Class Initialized
INFO - 2018-02-12 06:44:13 --> Router Class Initialized
INFO - 2018-02-12 06:44:13 --> Output Class Initialized
INFO - 2018-02-12 06:44:13 --> Security Class Initialized
DEBUG - 2018-02-12 06:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 06:44:13 --> Input Class Initialized
INFO - 2018-02-12 06:44:13 --> Language Class Initialized
INFO - 2018-02-12 06:44:13 --> Language Class Initialized
INFO - 2018-02-12 06:44:13 --> Config Class Initialized
INFO - 2018-02-12 06:44:13 --> Loader Class Initialized
INFO - 2018-02-12 12:14:13 --> Helper loaded: url_helper
INFO - 2018-02-12 12:14:13 --> Helper loaded: notification_helper
INFO - 2018-02-12 12:14:13 --> Helper loaded: settings_helper
INFO - 2018-02-12 12:14:13 --> Helper loaded: permission_helper
INFO - 2018-02-12 12:14:13 --> Helper loaded: users_helper
INFO - 2018-02-12 12:14:13 --> Database Driver Class Initialized
DEBUG - 2018-02-12 12:14:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 12:14:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 12:14:13 --> Helper loaded: form_helper
INFO - 2018-02-12 12:14:13 --> Form Validation Class Initialized
INFO - 2018-02-12 12:14:13 --> Controller Class Initialized
INFO - 2018-02-12 12:14:13 --> Model Class Initialized
INFO - 2018-02-12 12:14:13 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 12:14:13 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 12:14:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 12:14:14 --> Model Class Initialized
INFO - 2018-02-12 12:14:14 --> Model Class Initialized
INFO - 2018-02-12 12:14:14 --> Model Class Initialized
INFO - 2018-02-12 12:14:14 --> Model Class Initialized
INFO - 2018-02-12 12:14:14 --> Model Class Initialized
INFO - 2018-02-12 12:14:14 --> Model Class Initialized
INFO - 2018-02-12 12:14:14 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 12:14:14 --> Model Class Initialized
INFO - 2018-02-12 12:14:14 --> Final output sent to browser
DEBUG - 2018-02-12 12:14:14 --> Total execution time: 0.1081
INFO - 2018-02-12 06:51:47 --> Config Class Initialized
INFO - 2018-02-12 06:51:47 --> Hooks Class Initialized
DEBUG - 2018-02-12 06:51:47 --> UTF-8 Support Enabled
INFO - 2018-02-12 06:51:47 --> Utf8 Class Initialized
INFO - 2018-02-12 06:51:47 --> URI Class Initialized
INFO - 2018-02-12 06:51:47 --> Router Class Initialized
INFO - 2018-02-12 06:51:47 --> Output Class Initialized
INFO - 2018-02-12 06:51:47 --> Security Class Initialized
DEBUG - 2018-02-12 06:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 06:51:47 --> Input Class Initialized
INFO - 2018-02-12 06:51:47 --> Language Class Initialized
INFO - 2018-02-12 06:51:47 --> Language Class Initialized
INFO - 2018-02-12 06:51:47 --> Config Class Initialized
INFO - 2018-02-12 06:51:47 --> Loader Class Initialized
INFO - 2018-02-12 12:21:47 --> Helper loaded: url_helper
INFO - 2018-02-12 12:21:47 --> Helper loaded: notification_helper
INFO - 2018-02-12 12:21:47 --> Helper loaded: settings_helper
INFO - 2018-02-12 12:21:47 --> Helper loaded: permission_helper
INFO - 2018-02-12 12:21:47 --> Helper loaded: users_helper
INFO - 2018-02-12 12:21:47 --> Database Driver Class Initialized
DEBUG - 2018-02-12 12:21:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 12:21:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 12:21:47 --> Helper loaded: form_helper
INFO - 2018-02-12 12:21:47 --> Form Validation Class Initialized
INFO - 2018-02-12 12:21:47 --> Controller Class Initialized
INFO - 2018-02-12 12:21:47 --> Model Class Initialized
INFO - 2018-02-12 12:21:47 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 12:21:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 12:21:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 12:21:47 --> Model Class Initialized
INFO - 2018-02-12 12:21:47 --> Model Class Initialized
INFO - 2018-02-12 12:21:47 --> Model Class Initialized
INFO - 2018-02-12 12:21:47 --> Model Class Initialized
INFO - 2018-02-12 12:21:47 --> Model Class Initialized
INFO - 2018-02-12 12:21:47 --> Model Class Initialized
INFO - 2018-02-12 12:21:47 --> Model Class Initialized
INFO - 2018-02-12 12:21:47 --> Model Class Initialized
INFO - 2018-02-12 12:21:47 --> Model Class Initialized
INFO - 2018-02-12 12:21:47 --> Model Class Initialized
INFO - 2018-02-12 12:21:47 --> Model Class Initialized
INFO - 2018-02-12 12:21:47 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 12:21:47 --> Model Class Initialized
INFO - 2018-02-12 12:21:47 --> Final output sent to browser
DEBUG - 2018-02-12 12:21:47 --> Total execution time: 0.0914
INFO - 2018-02-12 06:51:47 --> Config Class Initialized
INFO - 2018-02-12 06:51:47 --> Hooks Class Initialized
DEBUG - 2018-02-12 06:51:47 --> UTF-8 Support Enabled
INFO - 2018-02-12 06:51:47 --> Utf8 Class Initialized
INFO - 2018-02-12 06:51:47 --> URI Class Initialized
INFO - 2018-02-12 06:51:47 --> Router Class Initialized
INFO - 2018-02-12 06:51:47 --> Output Class Initialized
INFO - 2018-02-12 06:51:47 --> Security Class Initialized
DEBUG - 2018-02-12 06:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 06:51:47 --> Input Class Initialized
INFO - 2018-02-12 06:51:47 --> Language Class Initialized
INFO - 2018-02-12 06:51:47 --> Language Class Initialized
INFO - 2018-02-12 06:51:47 --> Config Class Initialized
INFO - 2018-02-12 06:51:47 --> Loader Class Initialized
INFO - 2018-02-12 12:21:47 --> Helper loaded: url_helper
INFO - 2018-02-12 12:21:47 --> Helper loaded: notification_helper
INFO - 2018-02-12 12:21:47 --> Helper loaded: settings_helper
INFO - 2018-02-12 12:21:47 --> Helper loaded: permission_helper
INFO - 2018-02-12 12:21:47 --> Helper loaded: users_helper
INFO - 2018-02-12 12:21:47 --> Database Driver Class Initialized
DEBUG - 2018-02-12 12:21:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 12:21:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 12:21:47 --> Helper loaded: form_helper
INFO - 2018-02-12 12:21:47 --> Form Validation Class Initialized
INFO - 2018-02-12 12:21:47 --> Controller Class Initialized
INFO - 2018-02-12 12:21:47 --> Model Class Initialized
INFO - 2018-02-12 12:21:47 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 12:21:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 12:21:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 12:21:47 --> Model Class Initialized
INFO - 2018-02-12 12:21:47 --> Model Class Initialized
INFO - 2018-02-12 12:21:47 --> Model Class Initialized
INFO - 2018-02-12 12:21:47 --> Model Class Initialized
INFO - 2018-02-12 12:21:47 --> Model Class Initialized
INFO - 2018-02-12 12:21:47 --> Model Class Initialized
INFO - 2018-02-12 12:21:47 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 12:21:47 --> Model Class Initialized
INFO - 2018-02-12 12:21:47 --> Final output sent to browser
DEBUG - 2018-02-12 12:21:47 --> Total execution time: 0.0863
INFO - 2018-02-12 06:52:40 --> Config Class Initialized
INFO - 2018-02-12 06:52:40 --> Hooks Class Initialized
DEBUG - 2018-02-12 06:52:40 --> UTF-8 Support Enabled
INFO - 2018-02-12 06:52:40 --> Utf8 Class Initialized
INFO - 2018-02-12 06:52:40 --> URI Class Initialized
INFO - 2018-02-12 06:52:40 --> Router Class Initialized
INFO - 2018-02-12 06:52:40 --> Config Class Initialized
INFO - 2018-02-12 06:52:40 --> Hooks Class Initialized
INFO - 2018-02-12 06:52:40 --> Output Class Initialized
INFO - 2018-02-12 06:52:40 --> Security Class Initialized
DEBUG - 2018-02-12 06:52:40 --> UTF-8 Support Enabled
INFO - 2018-02-12 06:52:40 --> Utf8 Class Initialized
DEBUG - 2018-02-12 06:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 06:52:40 --> Input Class Initialized
INFO - 2018-02-12 06:52:40 --> Language Class Initialized
INFO - 2018-02-12 06:52:40 --> URI Class Initialized
INFO - 2018-02-12 06:52:40 --> Router Class Initialized
INFO - 2018-02-12 06:52:40 --> Output Class Initialized
INFO - 2018-02-12 06:52:40 --> Security Class Initialized
DEBUG - 2018-02-12 06:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 06:52:40 --> Input Class Initialized
INFO - 2018-02-12 06:52:40 --> Language Class Initialized
INFO - 2018-02-12 06:52:40 --> Config Class Initialized
INFO - 2018-02-12 06:52:40 --> Loader Class Initialized
INFO - 2018-02-12 06:52:40 --> Language Class Initialized
INFO - 2018-02-12 12:22:40 --> Helper loaded: url_helper
INFO - 2018-02-12 12:22:40 --> Helper loaded: notification_helper
INFO - 2018-02-12 12:22:40 --> Helper loaded: settings_helper
INFO - 2018-02-12 12:22:40 --> Helper loaded: permission_helper
INFO - 2018-02-12 12:22:40 --> Helper loaded: users_helper
INFO - 2018-02-12 12:22:40 --> Database Driver Class Initialized
INFO - 2018-02-12 06:52:40 --> Language Class Initialized
INFO - 2018-02-12 06:52:40 --> Config Class Initialized
INFO - 2018-02-12 06:52:40 --> Loader Class Initialized
INFO - 2018-02-12 12:22:40 --> Helper loaded: url_helper
DEBUG - 2018-02-12 12:22:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 12:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 12:22:40 --> Helper loaded: notification_helper
INFO - 2018-02-12 12:22:40 --> Helper loaded: settings_helper
INFO - 2018-02-12 12:22:40 --> Helper loaded: permission_helper
INFO - 2018-02-12 12:22:40 --> Helper loaded: users_helper
INFO - 2018-02-12 12:22:40 --> Helper loaded: form_helper
INFO - 2018-02-12 12:22:40 --> Form Validation Class Initialized
INFO - 2018-02-12 12:22:40 --> Controller Class Initialized
INFO - 2018-02-12 12:22:40 --> Model Class Initialized
INFO - 2018-02-12 12:22:40 --> Helper loaded: inflector_helper
INFO - 2018-02-12 12:22:40 --> Database Driver Class Initialized
DEBUG - 2018-02-12 12:22:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 12:22:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 12:22:40 --> Model Class Initialized
INFO - 2018-02-12 12:22:40 --> Model Class Initialized
INFO - 2018-02-12 12:22:40 --> Model Class Initialized
INFO - 2018-02-12 12:22:40 --> Model Class Initialized
INFO - 2018-02-12 12:22:40 --> Model Class Initialized
INFO - 2018-02-12 12:22:40 --> Model Class Initialized
INFO - 2018-02-12 12:22:40 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-02-12 12:22:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 12:22:40 --> Final output sent to browser
DEBUG - 2018-02-12 12:22:40 --> Total execution time: 0.0868
INFO - 2018-02-12 12:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 12:22:40 --> Helper loaded: form_helper
INFO - 2018-02-12 12:22:40 --> Form Validation Class Initialized
INFO - 2018-02-12 12:22:40 --> Controller Class Initialized
INFO - 2018-02-12 12:22:40 --> Model Class Initialized
INFO - 2018-02-12 12:22:40 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 12:22:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 12:22:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 12:22:40 --> Model Class Initialized
INFO - 2018-02-12 12:22:40 --> Model Class Initialized
INFO - 2018-02-12 12:22:40 --> Model Class Initialized
INFO - 2018-02-12 12:22:40 --> Model Class Initialized
INFO - 2018-02-12 12:22:40 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 12:22:40 --> Final output sent to browser
DEBUG - 2018-02-12 12:22:40 --> Total execution time: 0.1158
INFO - 2018-02-12 06:52:44 --> Config Class Initialized
INFO - 2018-02-12 06:52:44 --> Hooks Class Initialized
DEBUG - 2018-02-12 06:52:44 --> UTF-8 Support Enabled
INFO - 2018-02-12 06:52:44 --> Utf8 Class Initialized
INFO - 2018-02-12 06:52:44 --> URI Class Initialized
INFO - 2018-02-12 06:52:44 --> Router Class Initialized
INFO - 2018-02-12 06:52:44 --> Output Class Initialized
INFO - 2018-02-12 06:52:44 --> Security Class Initialized
DEBUG - 2018-02-12 06:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 06:52:44 --> Input Class Initialized
INFO - 2018-02-12 06:52:44 --> Language Class Initialized
INFO - 2018-02-12 06:52:44 --> Language Class Initialized
INFO - 2018-02-12 06:52:44 --> Config Class Initialized
INFO - 2018-02-12 06:52:44 --> Loader Class Initialized
INFO - 2018-02-12 12:22:44 --> Helper loaded: url_helper
INFO - 2018-02-12 12:22:44 --> Helper loaded: notification_helper
INFO - 2018-02-12 12:22:44 --> Helper loaded: settings_helper
INFO - 2018-02-12 12:22:44 --> Helper loaded: permission_helper
INFO - 2018-02-12 12:22:44 --> Helper loaded: users_helper
INFO - 2018-02-12 12:22:44 --> Database Driver Class Initialized
DEBUG - 2018-02-12 12:22:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 12:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 12:22:44 --> Helper loaded: form_helper
INFO - 2018-02-12 12:22:44 --> Form Validation Class Initialized
INFO - 2018-02-12 12:22:44 --> Controller Class Initialized
INFO - 2018-02-12 12:22:44 --> Model Class Initialized
INFO - 2018-02-12 12:22:44 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 12:22:44 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 12:22:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 12:22:44 --> Model Class Initialized
INFO - 2018-02-12 12:22:44 --> Model Class Initialized
INFO - 2018-02-12 12:22:44 --> Model Class Initialized
INFO - 2018-02-12 12:22:44 --> Model Class Initialized
INFO - 2018-02-12 12:22:44 --> Model Class Initialized
INFO - 2018-02-12 12:22:44 --> Model Class Initialized
INFO - 2018-02-12 12:22:44 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 12:22:44 --> Model Class Initialized
INFO - 2018-02-12 12:22:44 --> Final output sent to browser
DEBUG - 2018-02-12 12:22:44 --> Total execution time: 0.1186
INFO - 2018-02-12 07:26:57 --> Config Class Initialized
INFO - 2018-02-12 07:26:57 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:26:57 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:26:57 --> Utf8 Class Initialized
INFO - 2018-02-12 07:26:57 --> URI Class Initialized
INFO - 2018-02-12 07:26:57 --> Router Class Initialized
INFO - 2018-02-12 07:26:57 --> Output Class Initialized
INFO - 2018-02-12 07:26:57 --> Security Class Initialized
DEBUG - 2018-02-12 07:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:26:57 --> Input Class Initialized
INFO - 2018-02-12 07:26:57 --> Language Class Initialized
INFO - 2018-02-12 07:26:57 --> Language Class Initialized
INFO - 2018-02-12 07:26:57 --> Config Class Initialized
INFO - 2018-02-12 07:26:57 --> Loader Class Initialized
INFO - 2018-02-12 12:56:57 --> Helper loaded: url_helper
INFO - 2018-02-12 12:56:57 --> Helper loaded: notification_helper
INFO - 2018-02-12 12:56:57 --> Helper loaded: settings_helper
INFO - 2018-02-12 12:56:57 --> Helper loaded: permission_helper
INFO - 2018-02-12 12:56:57 --> Helper loaded: users_helper
INFO - 2018-02-12 12:56:57 --> Database Driver Class Initialized
DEBUG - 2018-02-12 12:56:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 12:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 12:56:57 --> Helper loaded: form_helper
INFO - 2018-02-12 12:56:57 --> Form Validation Class Initialized
INFO - 2018-02-12 12:56:57 --> Controller Class Initialized
INFO - 2018-02-12 12:56:57 --> Model Class Initialized
INFO - 2018-02-12 12:56:57 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 12:56:57 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 12:56:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 12:56:57 --> Model Class Initialized
INFO - 2018-02-12 12:56:57 --> Model Class Initialized
INFO - 2018-02-12 12:56:57 --> Model Class Initialized
INFO - 2018-02-12 12:56:57 --> Model Class Initialized
INFO - 2018-02-12 12:56:57 --> Model Class Initialized
INFO - 2018-02-12 12:56:57 --> Model Class Initialized
INFO - 2018-02-12 12:56:57 --> Model Class Initialized
INFO - 2018-02-12 12:56:57 --> Model Class Initialized
INFO - 2018-02-12 12:56:57 --> Model Class Initialized
INFO - 2018-02-12 12:56:57 --> Model Class Initialized
INFO - 2018-02-12 12:56:57 --> Model Class Initialized
INFO - 2018-02-12 12:56:57 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 12:56:57 --> Model Class Initialized
INFO - 2018-02-12 12:56:57 --> Final output sent to browser
DEBUG - 2018-02-12 12:56:57 --> Total execution time: 0.1293
INFO - 2018-02-12 07:26:58 --> Config Class Initialized
INFO - 2018-02-12 07:26:58 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:26:58 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:26:58 --> Utf8 Class Initialized
INFO - 2018-02-12 07:26:58 --> URI Class Initialized
INFO - 2018-02-12 07:26:58 --> Router Class Initialized
INFO - 2018-02-12 07:26:58 --> Output Class Initialized
INFO - 2018-02-12 07:26:58 --> Security Class Initialized
DEBUG - 2018-02-12 07:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:26:58 --> Input Class Initialized
INFO - 2018-02-12 07:26:58 --> Language Class Initialized
INFO - 2018-02-12 07:26:58 --> Language Class Initialized
INFO - 2018-02-12 07:26:58 --> Config Class Initialized
INFO - 2018-02-12 07:26:58 --> Loader Class Initialized
INFO - 2018-02-12 12:56:58 --> Helper loaded: url_helper
INFO - 2018-02-12 12:56:58 --> Helper loaded: notification_helper
INFO - 2018-02-12 12:56:58 --> Helper loaded: settings_helper
INFO - 2018-02-12 12:56:58 --> Helper loaded: permission_helper
INFO - 2018-02-12 12:56:58 --> Helper loaded: users_helper
INFO - 2018-02-12 12:56:58 --> Database Driver Class Initialized
DEBUG - 2018-02-12 12:56:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 12:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 12:56:58 --> Helper loaded: form_helper
INFO - 2018-02-12 12:56:58 --> Form Validation Class Initialized
INFO - 2018-02-12 12:56:58 --> Controller Class Initialized
INFO - 2018-02-12 12:56:58 --> Model Class Initialized
INFO - 2018-02-12 12:56:58 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 12:56:58 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 12:56:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 12:56:58 --> Model Class Initialized
INFO - 2018-02-12 12:56:58 --> Model Class Initialized
INFO - 2018-02-12 12:56:58 --> Model Class Initialized
INFO - 2018-02-12 12:56:58 --> Model Class Initialized
INFO - 2018-02-12 12:56:58 --> Model Class Initialized
INFO - 2018-02-12 12:56:58 --> Model Class Initialized
INFO - 2018-02-12 12:56:58 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 12:56:58 --> Model Class Initialized
INFO - 2018-02-12 12:56:58 --> Final output sent to browser
DEBUG - 2018-02-12 12:56:58 --> Total execution time: 0.1164
INFO - 2018-02-12 07:27:18 --> Config Class Initialized
INFO - 2018-02-12 07:27:18 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:27:18 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:27:18 --> Utf8 Class Initialized
INFO - 2018-02-12 07:27:18 --> URI Class Initialized
INFO - 2018-02-12 07:27:18 --> Router Class Initialized
INFO - 2018-02-12 07:27:18 --> Output Class Initialized
INFO - 2018-02-12 07:27:18 --> Security Class Initialized
DEBUG - 2018-02-12 07:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:27:18 --> Input Class Initialized
INFO - 2018-02-12 07:27:18 --> Language Class Initialized
INFO - 2018-02-12 07:27:18 --> Config Class Initialized
INFO - 2018-02-12 07:27:18 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:27:18 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:27:18 --> Utf8 Class Initialized
INFO - 2018-02-12 07:27:18 --> URI Class Initialized
INFO - 2018-02-12 07:27:18 --> Language Class Initialized
INFO - 2018-02-12 07:27:18 --> Config Class Initialized
INFO - 2018-02-12 07:27:18 --> Loader Class Initialized
INFO - 2018-02-12 07:27:18 --> Router Class Initialized
INFO - 2018-02-12 12:57:18 --> Helper loaded: url_helper
INFO - 2018-02-12 07:27:18 --> Output Class Initialized
INFO - 2018-02-12 12:57:18 --> Helper loaded: notification_helper
INFO - 2018-02-12 12:57:18 --> Helper loaded: settings_helper
INFO - 2018-02-12 12:57:18 --> Helper loaded: permission_helper
INFO - 2018-02-12 12:57:18 --> Helper loaded: users_helper
INFO - 2018-02-12 07:27:18 --> Security Class Initialized
DEBUG - 2018-02-12 07:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:27:18 --> Input Class Initialized
INFO - 2018-02-12 07:27:18 --> Language Class Initialized
INFO - 2018-02-12 12:57:18 --> Database Driver Class Initialized
DEBUG - 2018-02-12 12:57:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 12:57:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 07:27:18 --> Language Class Initialized
INFO - 2018-02-12 07:27:18 --> Config Class Initialized
INFO - 2018-02-12 07:27:18 --> Loader Class Initialized
INFO - 2018-02-12 12:57:18 --> Helper loaded: url_helper
INFO - 2018-02-12 12:57:18 --> Helper loaded: notification_helper
INFO - 2018-02-12 12:57:18 --> Helper loaded: form_helper
INFO - 2018-02-12 12:57:18 --> Form Validation Class Initialized
INFO - 2018-02-12 12:57:18 --> Controller Class Initialized
INFO - 2018-02-12 12:57:18 --> Helper loaded: settings_helper
INFO - 2018-02-12 12:57:18 --> Helper loaded: permission_helper
INFO - 2018-02-12 12:57:18 --> Helper loaded: users_helper
INFO - 2018-02-12 12:57:18 --> Model Class Initialized
INFO - 2018-02-12 12:57:18 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 12:57:18 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 12:57:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 12:57:18 --> Model Class Initialized
INFO - 2018-02-12 12:57:18 --> Database Driver Class Initialized
INFO - 2018-02-12 12:57:18 --> Model Class Initialized
INFO - 2018-02-12 12:57:18 --> Model Class Initialized
INFO - 2018-02-12 12:57:18 --> Model Class Initialized
INFO - 2018-02-12 12:57:18 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 12:57:18 --> Final output sent to browser
DEBUG - 2018-02-12 12:57:18 --> Total execution time: 0.1007
DEBUG - 2018-02-12 12:57:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 12:57:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 12:57:18 --> Helper loaded: form_helper
INFO - 2018-02-12 12:57:18 --> Form Validation Class Initialized
INFO - 2018-02-12 12:57:18 --> Controller Class Initialized
INFO - 2018-02-12 12:57:18 --> Model Class Initialized
INFO - 2018-02-12 12:57:18 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 12:57:18 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 12:57:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 12:57:18 --> Model Class Initialized
INFO - 2018-02-12 12:57:18 --> Model Class Initialized
INFO - 2018-02-12 12:57:18 --> Model Class Initialized
INFO - 2018-02-12 12:57:18 --> Model Class Initialized
INFO - 2018-02-12 12:57:18 --> Model Class Initialized
INFO - 2018-02-12 12:57:18 --> Model Class Initialized
INFO - 2018-02-12 12:57:18 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 12:57:18 --> Final output sent to browser
DEBUG - 2018-02-12 12:57:18 --> Total execution time: 0.1082
INFO - 2018-02-12 07:27:25 --> Config Class Initialized
INFO - 2018-02-12 07:27:25 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:27:25 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:27:25 --> Utf8 Class Initialized
INFO - 2018-02-12 07:27:25 --> URI Class Initialized
INFO - 2018-02-12 07:27:25 --> Router Class Initialized
INFO - 2018-02-12 07:27:25 --> Output Class Initialized
INFO - 2018-02-12 07:27:25 --> Security Class Initialized
DEBUG - 2018-02-12 07:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:27:25 --> Input Class Initialized
INFO - 2018-02-12 07:27:25 --> Language Class Initialized
INFO - 2018-02-12 07:27:25 --> Language Class Initialized
INFO - 2018-02-12 07:27:25 --> Config Class Initialized
INFO - 2018-02-12 07:27:25 --> Loader Class Initialized
INFO - 2018-02-12 12:57:25 --> Helper loaded: url_helper
INFO - 2018-02-12 12:57:25 --> Helper loaded: notification_helper
INFO - 2018-02-12 12:57:25 --> Helper loaded: settings_helper
INFO - 2018-02-12 12:57:25 --> Helper loaded: permission_helper
INFO - 2018-02-12 12:57:25 --> Helper loaded: users_helper
INFO - 2018-02-12 12:57:25 --> Database Driver Class Initialized
DEBUG - 2018-02-12 12:57:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 12:57:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 12:57:25 --> Helper loaded: form_helper
INFO - 2018-02-12 12:57:25 --> Form Validation Class Initialized
INFO - 2018-02-12 12:57:25 --> Controller Class Initialized
INFO - 2018-02-12 12:57:25 --> Model Class Initialized
INFO - 2018-02-12 12:57:25 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 12:57:25 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 12:57:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 12:57:25 --> Model Class Initialized
INFO - 2018-02-12 12:57:25 --> Model Class Initialized
INFO - 2018-02-12 12:57:25 --> Model Class Initialized
INFO - 2018-02-12 12:57:25 --> Model Class Initialized
INFO - 2018-02-12 12:57:25 --> Model Class Initialized
INFO - 2018-02-12 12:57:25 --> Model Class Initialized
INFO - 2018-02-12 12:57:25 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 12:57:25 --> Model Class Initialized
INFO - 2018-02-12 12:57:25 --> Final output sent to browser
DEBUG - 2018-02-12 12:57:25 --> Total execution time: 0.1157
INFO - 2018-02-12 07:30:14 --> Config Class Initialized
INFO - 2018-02-12 07:30:14 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:30:14 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:30:14 --> Utf8 Class Initialized
INFO - 2018-02-12 07:30:14 --> URI Class Initialized
INFO - 2018-02-12 07:30:14 --> Router Class Initialized
INFO - 2018-02-12 07:30:14 --> Output Class Initialized
INFO - 2018-02-12 07:30:14 --> Security Class Initialized
DEBUG - 2018-02-12 07:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:30:14 --> Input Class Initialized
INFO - 2018-02-12 07:30:14 --> Language Class Initialized
INFO - 2018-02-12 07:30:14 --> Language Class Initialized
INFO - 2018-02-12 07:30:14 --> Config Class Initialized
INFO - 2018-02-12 07:30:14 --> Loader Class Initialized
INFO - 2018-02-12 13:00:14 --> Helper loaded: url_helper
INFO - 2018-02-12 13:00:14 --> Helper loaded: notification_helper
INFO - 2018-02-12 13:00:14 --> Helper loaded: settings_helper
INFO - 2018-02-12 13:00:14 --> Helper loaded: permission_helper
INFO - 2018-02-12 13:00:14 --> Helper loaded: users_helper
INFO - 2018-02-12 13:00:14 --> Database Driver Class Initialized
DEBUG - 2018-02-12 13:00:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 13:00:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 13:00:14 --> Helper loaded: form_helper
INFO - 2018-02-12 13:00:14 --> Form Validation Class Initialized
INFO - 2018-02-12 13:00:14 --> Controller Class Initialized
INFO - 2018-02-12 13:00:14 --> Model Class Initialized
INFO - 2018-02-12 13:00:14 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 13:00:14 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 13:00:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 13:00:14 --> Model Class Initialized
INFO - 2018-02-12 13:00:14 --> Model Class Initialized
INFO - 2018-02-12 13:00:14 --> Model Class Initialized
INFO - 2018-02-12 13:00:14 --> Model Class Initialized
INFO - 2018-02-12 13:00:14 --> Model Class Initialized
INFO - 2018-02-12 13:00:14 --> Model Class Initialized
INFO - 2018-02-12 13:00:14 --> Model Class Initialized
INFO - 2018-02-12 13:00:14 --> Model Class Initialized
INFO - 2018-02-12 13:00:14 --> Model Class Initialized
INFO - 2018-02-12 13:00:14 --> Model Class Initialized
INFO - 2018-02-12 13:00:14 --> Model Class Initialized
INFO - 2018-02-12 13:00:14 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 13:00:14 --> Model Class Initialized
INFO - 2018-02-12 13:00:14 --> Final output sent to browser
DEBUG - 2018-02-12 13:00:14 --> Total execution time: 0.0920
INFO - 2018-02-12 07:30:14 --> Config Class Initialized
INFO - 2018-02-12 07:30:14 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:30:14 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:30:14 --> Utf8 Class Initialized
INFO - 2018-02-12 07:30:14 --> URI Class Initialized
INFO - 2018-02-12 07:30:14 --> Router Class Initialized
INFO - 2018-02-12 07:30:14 --> Output Class Initialized
INFO - 2018-02-12 07:30:14 --> Security Class Initialized
DEBUG - 2018-02-12 07:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:30:14 --> Input Class Initialized
INFO - 2018-02-12 07:30:14 --> Language Class Initialized
INFO - 2018-02-12 07:30:14 --> Language Class Initialized
INFO - 2018-02-12 07:30:14 --> Config Class Initialized
INFO - 2018-02-12 07:30:14 --> Loader Class Initialized
INFO - 2018-02-12 13:00:14 --> Helper loaded: url_helper
INFO - 2018-02-12 13:00:14 --> Helper loaded: notification_helper
INFO - 2018-02-12 13:00:14 --> Helper loaded: settings_helper
INFO - 2018-02-12 13:00:14 --> Helper loaded: permission_helper
INFO - 2018-02-12 13:00:14 --> Helper loaded: users_helper
INFO - 2018-02-12 13:00:14 --> Database Driver Class Initialized
DEBUG - 2018-02-12 13:00:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 13:00:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 13:00:14 --> Helper loaded: form_helper
INFO - 2018-02-12 13:00:14 --> Form Validation Class Initialized
INFO - 2018-02-12 13:00:14 --> Controller Class Initialized
INFO - 2018-02-12 13:00:14 --> Model Class Initialized
INFO - 2018-02-12 13:00:14 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 13:00:14 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 13:00:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 13:00:14 --> Model Class Initialized
INFO - 2018-02-12 13:00:14 --> Model Class Initialized
INFO - 2018-02-12 13:00:14 --> Model Class Initialized
INFO - 2018-02-12 13:00:14 --> Model Class Initialized
INFO - 2018-02-12 13:00:14 --> Model Class Initialized
INFO - 2018-02-12 13:00:14 --> Model Class Initialized
INFO - 2018-02-12 13:00:14 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 13:00:14 --> Model Class Initialized
INFO - 2018-02-12 13:00:14 --> Final output sent to browser
DEBUG - 2018-02-12 13:00:14 --> Total execution time: 0.1195
INFO - 2018-02-12 07:30:23 --> Config Class Initialized
INFO - 2018-02-12 07:30:23 --> Hooks Class Initialized
INFO - 2018-02-12 07:30:23 --> Config Class Initialized
INFO - 2018-02-12 07:30:23 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:30:23 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:30:23 --> Utf8 Class Initialized
INFO - 2018-02-12 07:30:23 --> URI Class Initialized
DEBUG - 2018-02-12 07:30:23 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:30:23 --> Utf8 Class Initialized
INFO - 2018-02-12 07:30:23 --> URI Class Initialized
INFO - 2018-02-12 07:30:23 --> Router Class Initialized
INFO - 2018-02-12 07:30:23 --> Router Class Initialized
INFO - 2018-02-12 07:30:23 --> Output Class Initialized
INFO - 2018-02-12 07:30:23 --> Security Class Initialized
INFO - 2018-02-12 07:30:23 --> Output Class Initialized
DEBUG - 2018-02-12 07:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:30:23 --> Input Class Initialized
INFO - 2018-02-12 07:30:23 --> Security Class Initialized
INFO - 2018-02-12 07:30:23 --> Language Class Initialized
DEBUG - 2018-02-12 07:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:30:23 --> Input Class Initialized
INFO - 2018-02-12 07:30:23 --> Language Class Initialized
INFO - 2018-02-12 07:30:23 --> Language Class Initialized
INFO - 2018-02-12 07:30:23 --> Config Class Initialized
INFO - 2018-02-12 07:30:23 --> Loader Class Initialized
INFO - 2018-02-12 07:30:23 --> Language Class Initialized
INFO - 2018-02-12 07:30:23 --> Config Class Initialized
INFO - 2018-02-12 07:30:23 --> Loader Class Initialized
INFO - 2018-02-12 13:00:23 --> Helper loaded: url_helper
INFO - 2018-02-12 13:00:23 --> Helper loaded: url_helper
INFO - 2018-02-12 13:00:23 --> Helper loaded: notification_helper
INFO - 2018-02-12 13:00:23 --> Helper loaded: notification_helper
INFO - 2018-02-12 13:00:23 --> Helper loaded: settings_helper
INFO - 2018-02-12 13:00:23 --> Helper loaded: settings_helper
INFO - 2018-02-12 13:00:23 --> Helper loaded: permission_helper
INFO - 2018-02-12 13:00:23 --> Helper loaded: permission_helper
INFO - 2018-02-12 13:00:23 --> Helper loaded: users_helper
INFO - 2018-02-12 13:00:23 --> Helper loaded: users_helper
INFO - 2018-02-12 13:00:23 --> Database Driver Class Initialized
INFO - 2018-02-12 13:00:23 --> Database Driver Class Initialized
DEBUG - 2018-02-12 13:00:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-12 13:00:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 13:00:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 13:00:23 --> Helper loaded: form_helper
INFO - 2018-02-12 13:00:23 --> Form Validation Class Initialized
INFO - 2018-02-12 13:00:23 --> Controller Class Initialized
INFO - 2018-02-12 13:00:23 --> Model Class Initialized
INFO - 2018-02-12 13:00:23 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 13:00:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 13:00:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 13:00:23 --> Model Class Initialized
INFO - 2018-02-12 13:00:23 --> Model Class Initialized
INFO - 2018-02-12 13:00:23 --> Model Class Initialized
INFO - 2018-02-12 13:00:23 --> Model Class Initialized
INFO - 2018-02-12 13:00:23 --> Model Class Initialized
INFO - 2018-02-12 13:00:23 --> Model Class Initialized
INFO - 2018-02-12 13:00:23 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 13:00:23 --> Final output sent to browser
DEBUG - 2018-02-12 13:00:23 --> Total execution time: 0.1129
INFO - 2018-02-12 13:00:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 13:00:23 --> Helper loaded: form_helper
INFO - 2018-02-12 13:00:23 --> Form Validation Class Initialized
INFO - 2018-02-12 13:00:23 --> Controller Class Initialized
INFO - 2018-02-12 13:00:23 --> Model Class Initialized
INFO - 2018-02-12 13:00:23 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 13:00:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 13:00:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 13:00:23 --> Model Class Initialized
INFO - 2018-02-12 13:00:23 --> Model Class Initialized
INFO - 2018-02-12 13:00:23 --> Model Class Initialized
INFO - 2018-02-12 13:00:23 --> Model Class Initialized
INFO - 2018-02-12 13:00:23 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 13:00:23 --> Final output sent to browser
DEBUG - 2018-02-12 13:00:23 --> Total execution time: 0.1471
INFO - 2018-02-12 07:30:26 --> Config Class Initialized
INFO - 2018-02-12 07:30:26 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:30:26 --> UTF-8 Support Enabled
INFO - 2018-02-12 07:30:26 --> Utf8 Class Initialized
INFO - 2018-02-12 07:30:26 --> URI Class Initialized
INFO - 2018-02-12 07:30:26 --> Router Class Initialized
INFO - 2018-02-12 07:30:26 --> Output Class Initialized
INFO - 2018-02-12 07:30:26 --> Security Class Initialized
DEBUG - 2018-02-12 07:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 07:30:26 --> Input Class Initialized
INFO - 2018-02-12 07:30:26 --> Language Class Initialized
INFO - 2018-02-12 07:30:26 --> Language Class Initialized
INFO - 2018-02-12 07:30:26 --> Config Class Initialized
INFO - 2018-02-12 07:30:26 --> Loader Class Initialized
INFO - 2018-02-12 13:00:26 --> Helper loaded: url_helper
INFO - 2018-02-12 13:00:26 --> Helper loaded: notification_helper
INFO - 2018-02-12 13:00:26 --> Helper loaded: settings_helper
INFO - 2018-02-12 13:00:26 --> Helper loaded: permission_helper
INFO - 2018-02-12 13:00:26 --> Helper loaded: users_helper
INFO - 2018-02-12 13:00:26 --> Database Driver Class Initialized
DEBUG - 2018-02-12 13:00:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 13:00:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 13:00:26 --> Helper loaded: form_helper
INFO - 2018-02-12 13:00:26 --> Form Validation Class Initialized
INFO - 2018-02-12 13:00:26 --> Controller Class Initialized
INFO - 2018-02-12 13:00:26 --> Model Class Initialized
INFO - 2018-02-12 13:00:26 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 13:00:26 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 13:00:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 13:00:26 --> Model Class Initialized
INFO - 2018-02-12 13:00:26 --> Model Class Initialized
INFO - 2018-02-12 13:00:26 --> Model Class Initialized
INFO - 2018-02-12 13:00:26 --> Model Class Initialized
INFO - 2018-02-12 13:00:26 --> Model Class Initialized
INFO - 2018-02-12 13:00:26 --> Model Class Initialized
INFO - 2018-02-12 13:00:26 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 13:00:26 --> Model Class Initialized
INFO - 2018-02-12 13:00:26 --> Final output sent to browser
DEBUG - 2018-02-12 13:00:26 --> Total execution time: 0.1075
INFO - 2018-02-12 08:25:32 --> Config Class Initialized
INFO - 2018-02-12 08:25:32 --> Hooks Class Initialized
DEBUG - 2018-02-12 08:25:32 --> UTF-8 Support Enabled
INFO - 2018-02-12 08:25:32 --> Utf8 Class Initialized
INFO - 2018-02-12 08:25:32 --> URI Class Initialized
INFO - 2018-02-12 08:25:32 --> Router Class Initialized
INFO - 2018-02-12 08:25:32 --> Output Class Initialized
INFO - 2018-02-12 08:25:32 --> Security Class Initialized
DEBUG - 2018-02-12 08:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 08:25:32 --> Input Class Initialized
INFO - 2018-02-12 08:25:32 --> Language Class Initialized
INFO - 2018-02-12 08:25:32 --> Language Class Initialized
INFO - 2018-02-12 08:25:32 --> Config Class Initialized
INFO - 2018-02-12 08:25:32 --> Loader Class Initialized
INFO - 2018-02-12 13:55:32 --> Helper loaded: url_helper
INFO - 2018-02-12 13:55:32 --> Helper loaded: notification_helper
INFO - 2018-02-12 13:55:32 --> Helper loaded: settings_helper
INFO - 2018-02-12 13:55:32 --> Helper loaded: permission_helper
INFO - 2018-02-12 13:55:32 --> Helper loaded: users_helper
INFO - 2018-02-12 13:55:32 --> Database Driver Class Initialized
DEBUG - 2018-02-12 13:55:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 13:55:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 13:55:32 --> Helper loaded: form_helper
INFO - 2018-02-12 13:55:32 --> Form Validation Class Initialized
INFO - 2018-02-12 13:55:32 --> Controller Class Initialized
INFO - 2018-02-12 13:55:32 --> Model Class Initialized
INFO - 2018-02-12 13:55:32 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 13:55:32 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 13:55:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 13:55:32 --> Model Class Initialized
INFO - 2018-02-12 13:55:32 --> Model Class Initialized
INFO - 2018-02-12 13:55:32 --> Model Class Initialized
INFO - 2018-02-12 13:55:32 --> Model Class Initialized
INFO - 2018-02-12 13:55:32 --> Model Class Initialized
INFO - 2018-02-12 13:55:32 --> Model Class Initialized
INFO - 2018-02-12 13:55:32 --> Model Class Initialized
INFO - 2018-02-12 13:55:32 --> Model Class Initialized
INFO - 2018-02-12 13:55:32 --> Model Class Initialized
INFO - 2018-02-12 13:55:32 --> Model Class Initialized
INFO - 2018-02-12 13:55:32 --> Model Class Initialized
INFO - 2018-02-12 13:55:32 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 13:55:32 --> Model Class Initialized
INFO - 2018-02-12 13:55:32 --> Final output sent to browser
DEBUG - 2018-02-12 13:55:32 --> Total execution time: 0.0889
INFO - 2018-02-12 08:25:33 --> Config Class Initialized
INFO - 2018-02-12 08:25:33 --> Hooks Class Initialized
DEBUG - 2018-02-12 08:25:33 --> UTF-8 Support Enabled
INFO - 2018-02-12 08:25:33 --> Utf8 Class Initialized
INFO - 2018-02-12 08:25:33 --> URI Class Initialized
INFO - 2018-02-12 08:25:33 --> Router Class Initialized
INFO - 2018-02-12 08:25:33 --> Output Class Initialized
INFO - 2018-02-12 08:25:33 --> Security Class Initialized
DEBUG - 2018-02-12 08:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 08:25:33 --> Input Class Initialized
INFO - 2018-02-12 08:25:33 --> Language Class Initialized
INFO - 2018-02-12 08:25:33 --> Language Class Initialized
INFO - 2018-02-12 08:25:33 --> Config Class Initialized
INFO - 2018-02-12 08:25:33 --> Loader Class Initialized
INFO - 2018-02-12 13:55:33 --> Helper loaded: url_helper
INFO - 2018-02-12 13:55:33 --> Helper loaded: notification_helper
INFO - 2018-02-12 13:55:33 --> Helper loaded: settings_helper
INFO - 2018-02-12 13:55:33 --> Helper loaded: permission_helper
INFO - 2018-02-12 13:55:33 --> Helper loaded: users_helper
INFO - 2018-02-12 13:55:33 --> Database Driver Class Initialized
DEBUG - 2018-02-12 13:55:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 13:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 13:55:33 --> Helper loaded: form_helper
INFO - 2018-02-12 13:55:33 --> Form Validation Class Initialized
INFO - 2018-02-12 13:55:33 --> Controller Class Initialized
INFO - 2018-02-12 13:55:34 --> Model Class Initialized
INFO - 2018-02-12 13:55:34 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 13:55:34 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 13:55:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 13:55:34 --> Model Class Initialized
INFO - 2018-02-12 13:55:34 --> Model Class Initialized
INFO - 2018-02-12 13:55:34 --> Model Class Initialized
INFO - 2018-02-12 13:55:34 --> Model Class Initialized
INFO - 2018-02-12 13:55:34 --> Model Class Initialized
INFO - 2018-02-12 13:55:34 --> Model Class Initialized
INFO - 2018-02-12 13:55:34 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 13:55:34 --> Model Class Initialized
INFO - 2018-02-12 13:55:34 --> Final output sent to browser
DEBUG - 2018-02-12 13:55:34 --> Total execution time: 0.1107
INFO - 2018-02-12 08:25:57 --> Config Class Initialized
INFO - 2018-02-12 08:25:57 --> Hooks Class Initialized
DEBUG - 2018-02-12 08:25:57 --> UTF-8 Support Enabled
INFO - 2018-02-12 08:25:57 --> Utf8 Class Initialized
INFO - 2018-02-12 08:25:57 --> URI Class Initialized
INFO - 2018-02-12 08:25:57 --> Router Class Initialized
INFO - 2018-02-12 08:25:57 --> Config Class Initialized
INFO - 2018-02-12 08:25:57 --> Hooks Class Initialized
INFO - 2018-02-12 08:25:57 --> Output Class Initialized
INFO - 2018-02-12 08:25:57 --> Security Class Initialized
DEBUG - 2018-02-12 08:25:57 --> UTF-8 Support Enabled
INFO - 2018-02-12 08:25:57 --> Utf8 Class Initialized
DEBUG - 2018-02-12 08:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 08:25:57 --> Input Class Initialized
INFO - 2018-02-12 08:25:57 --> URI Class Initialized
INFO - 2018-02-12 08:25:57 --> Language Class Initialized
INFO - 2018-02-12 08:25:57 --> Router Class Initialized
INFO - 2018-02-12 08:25:57 --> Output Class Initialized
INFO - 2018-02-12 08:25:57 --> Security Class Initialized
DEBUG - 2018-02-12 08:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 08:25:57 --> Input Class Initialized
INFO - 2018-02-12 08:25:57 --> Language Class Initialized
INFO - 2018-02-12 08:25:57 --> Language Class Initialized
INFO - 2018-02-12 08:25:57 --> Config Class Initialized
INFO - 2018-02-12 08:25:57 --> Loader Class Initialized
INFO - 2018-02-12 13:55:57 --> Helper loaded: url_helper
INFO - 2018-02-12 13:55:57 --> Helper loaded: notification_helper
INFO - 2018-02-12 13:55:57 --> Helper loaded: settings_helper
INFO - 2018-02-12 13:55:57 --> Helper loaded: permission_helper
INFO - 2018-02-12 13:55:57 --> Helper loaded: users_helper
INFO - 2018-02-12 13:55:57 --> Database Driver Class Initialized
INFO - 2018-02-12 08:25:57 --> Language Class Initialized
INFO - 2018-02-12 08:25:57 --> Config Class Initialized
INFO - 2018-02-12 08:25:57 --> Loader Class Initialized
INFO - 2018-02-12 13:55:57 --> Helper loaded: url_helper
DEBUG - 2018-02-12 13:55:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 13:55:57 --> Helper loaded: notification_helper
INFO - 2018-02-12 13:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 13:55:57 --> Helper loaded: settings_helper
INFO - 2018-02-12 13:55:57 --> Helper loaded: permission_helper
INFO - 2018-02-12 13:55:57 --> Helper loaded: users_helper
INFO - 2018-02-12 13:55:57 --> Helper loaded: form_helper
INFO - 2018-02-12 13:55:57 --> Form Validation Class Initialized
INFO - 2018-02-12 13:55:57 --> Controller Class Initialized
INFO - 2018-02-12 13:55:57 --> Model Class Initialized
INFO - 2018-02-12 13:55:57 --> Database Driver Class Initialized
INFO - 2018-02-12 13:55:57 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 13:55:57 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 13:55:57 --> Language file loaded: language/english/rest_controller_lang.php
DEBUG - 2018-02-12 13:55:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 13:55:57 --> Model Class Initialized
INFO - 2018-02-12 13:55:57 --> Model Class Initialized
INFO - 2018-02-12 13:55:57 --> Model Class Initialized
INFO - 2018-02-12 13:55:57 --> Model Class Initialized
INFO - 2018-02-12 13:55:57 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 13:55:57 --> Final output sent to browser
DEBUG - 2018-02-12 13:55:57 --> Total execution time: 0.1018
INFO - 2018-02-12 13:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 13:55:57 --> Helper loaded: form_helper
INFO - 2018-02-12 13:55:57 --> Form Validation Class Initialized
INFO - 2018-02-12 13:55:57 --> Controller Class Initialized
INFO - 2018-02-12 13:55:57 --> Model Class Initialized
INFO - 2018-02-12 13:55:57 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 13:55:57 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 13:55:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 13:55:57 --> Model Class Initialized
INFO - 2018-02-12 13:55:57 --> Model Class Initialized
INFO - 2018-02-12 13:55:57 --> Model Class Initialized
INFO - 2018-02-12 13:55:57 --> Model Class Initialized
INFO - 2018-02-12 13:55:57 --> Model Class Initialized
INFO - 2018-02-12 13:55:57 --> Model Class Initialized
INFO - 2018-02-12 13:55:57 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 13:55:57 --> Final output sent to browser
DEBUG - 2018-02-12 13:55:57 --> Total execution time: 0.1262
INFO - 2018-02-12 08:26:01 --> Config Class Initialized
INFO - 2018-02-12 08:26:01 --> Hooks Class Initialized
DEBUG - 2018-02-12 08:26:02 --> UTF-8 Support Enabled
INFO - 2018-02-12 08:26:02 --> Utf8 Class Initialized
INFO - 2018-02-12 08:26:02 --> URI Class Initialized
INFO - 2018-02-12 08:26:02 --> Router Class Initialized
INFO - 2018-02-12 08:26:02 --> Output Class Initialized
INFO - 2018-02-12 08:26:02 --> Security Class Initialized
DEBUG - 2018-02-12 08:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 08:26:02 --> Input Class Initialized
INFO - 2018-02-12 08:26:02 --> Language Class Initialized
INFO - 2018-02-12 08:26:02 --> Language Class Initialized
INFO - 2018-02-12 08:26:02 --> Config Class Initialized
INFO - 2018-02-12 08:26:02 --> Loader Class Initialized
INFO - 2018-02-12 13:56:02 --> Helper loaded: url_helper
INFO - 2018-02-12 13:56:02 --> Helper loaded: notification_helper
INFO - 2018-02-12 13:56:02 --> Helper loaded: settings_helper
INFO - 2018-02-12 13:56:02 --> Helper loaded: permission_helper
INFO - 2018-02-12 13:56:02 --> Helper loaded: users_helper
INFO - 2018-02-12 13:56:02 --> Database Driver Class Initialized
DEBUG - 2018-02-12 13:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 13:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 13:56:02 --> Helper loaded: form_helper
INFO - 2018-02-12 13:56:02 --> Form Validation Class Initialized
INFO - 2018-02-12 13:56:02 --> Controller Class Initialized
INFO - 2018-02-12 13:56:02 --> Model Class Initialized
INFO - 2018-02-12 13:56:02 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 13:56:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 13:56:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 13:56:02 --> Model Class Initialized
INFO - 2018-02-12 13:56:02 --> Model Class Initialized
INFO - 2018-02-12 13:56:02 --> Model Class Initialized
INFO - 2018-02-12 13:56:02 --> Model Class Initialized
INFO - 2018-02-12 13:56:02 --> Model Class Initialized
INFO - 2018-02-12 13:56:02 --> Model Class Initialized
INFO - 2018-02-12 13:56:02 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 13:56:02 --> Model Class Initialized
INFO - 2018-02-12 13:56:02 --> Final output sent to browser
DEBUG - 2018-02-12 13:56:02 --> Total execution time: 0.1100
INFO - 2018-02-12 08:26:15 --> Config Class Initialized
INFO - 2018-02-12 08:26:15 --> Hooks Class Initialized
DEBUG - 2018-02-12 08:26:15 --> UTF-8 Support Enabled
INFO - 2018-02-12 08:26:15 --> Utf8 Class Initialized
INFO - 2018-02-12 08:26:15 --> URI Class Initialized
INFO - 2018-02-12 08:26:15 --> Router Class Initialized
INFO - 2018-02-12 08:26:15 --> Output Class Initialized
INFO - 2018-02-12 08:26:15 --> Security Class Initialized
DEBUG - 2018-02-12 08:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 08:26:15 --> Input Class Initialized
INFO - 2018-02-12 08:26:15 --> Language Class Initialized
INFO - 2018-02-12 08:26:15 --> Language Class Initialized
INFO - 2018-02-12 08:26:15 --> Config Class Initialized
INFO - 2018-02-12 08:26:15 --> Loader Class Initialized
INFO - 2018-02-12 13:56:15 --> Helper loaded: url_helper
INFO - 2018-02-12 13:56:15 --> Helper loaded: notification_helper
INFO - 2018-02-12 13:56:15 --> Helper loaded: settings_helper
INFO - 2018-02-12 13:56:15 --> Helper loaded: permission_helper
INFO - 2018-02-12 13:56:15 --> Helper loaded: users_helper
INFO - 2018-02-12 13:56:15 --> Database Driver Class Initialized
DEBUG - 2018-02-12 13:56:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 13:56:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 13:56:15 --> Helper loaded: form_helper
INFO - 2018-02-12 13:56:15 --> Form Validation Class Initialized
INFO - 2018-02-12 13:56:15 --> Controller Class Initialized
INFO - 2018-02-12 13:56:15 --> Model Class Initialized
INFO - 2018-02-12 13:56:15 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 13:56:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 13:56:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 13:56:15 --> Model Class Initialized
INFO - 2018-02-12 13:56:15 --> Model Class Initialized
INFO - 2018-02-12 13:56:15 --> Model Class Initialized
INFO - 2018-02-12 13:56:15 --> Model Class Initialized
INFO - 2018-02-12 13:56:15 --> Model Class Initialized
INFO - 2018-02-12 13:56:15 --> Model Class Initialized
INFO - 2018-02-12 13:56:15 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 13:56:15 --> Model Class Initialized
INFO - 2018-02-12 13:56:15 --> Final output sent to browser
DEBUG - 2018-02-12 13:56:15 --> Total execution time: 0.0816
INFO - 2018-02-12 08:26:16 --> Config Class Initialized
INFO - 2018-02-12 08:26:16 --> Hooks Class Initialized
DEBUG - 2018-02-12 08:26:16 --> UTF-8 Support Enabled
INFO - 2018-02-12 08:26:16 --> Utf8 Class Initialized
INFO - 2018-02-12 08:26:16 --> URI Class Initialized
INFO - 2018-02-12 08:26:16 --> Router Class Initialized
INFO - 2018-02-12 08:26:16 --> Output Class Initialized
INFO - 2018-02-12 08:26:16 --> Security Class Initialized
DEBUG - 2018-02-12 08:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 08:26:16 --> Input Class Initialized
INFO - 2018-02-12 08:26:16 --> Language Class Initialized
INFO - 2018-02-12 08:26:16 --> Language Class Initialized
INFO - 2018-02-12 08:26:16 --> Config Class Initialized
INFO - 2018-02-12 08:26:16 --> Loader Class Initialized
INFO - 2018-02-12 13:56:16 --> Helper loaded: url_helper
INFO - 2018-02-12 13:56:16 --> Helper loaded: notification_helper
INFO - 2018-02-12 13:56:16 --> Helper loaded: settings_helper
INFO - 2018-02-12 13:56:16 --> Helper loaded: permission_helper
INFO - 2018-02-12 13:56:16 --> Helper loaded: users_helper
INFO - 2018-02-12 13:56:16 --> Database Driver Class Initialized
DEBUG - 2018-02-12 13:56:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 13:56:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 13:56:16 --> Helper loaded: form_helper
INFO - 2018-02-12 13:56:16 --> Form Validation Class Initialized
INFO - 2018-02-12 13:56:16 --> Controller Class Initialized
INFO - 2018-02-12 13:56:16 --> Model Class Initialized
INFO - 2018-02-12 13:56:16 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 13:56:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 13:56:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 13:56:16 --> Model Class Initialized
INFO - 2018-02-12 13:56:16 --> Model Class Initialized
INFO - 2018-02-12 13:56:16 --> Model Class Initialized
INFO - 2018-02-12 13:56:16 --> Model Class Initialized
INFO - 2018-02-12 13:56:16 --> Model Class Initialized
INFO - 2018-02-12 13:56:16 --> Model Class Initialized
INFO - 2018-02-12 13:56:16 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 13:56:16 --> Model Class Initialized
INFO - 2018-02-12 13:56:16 --> Final output sent to browser
DEBUG - 2018-02-12 13:56:16 --> Total execution time: 0.1178
INFO - 2018-02-12 08:26:17 --> Config Class Initialized
INFO - 2018-02-12 08:26:17 --> Hooks Class Initialized
DEBUG - 2018-02-12 08:26:17 --> UTF-8 Support Enabled
INFO - 2018-02-12 08:26:17 --> Utf8 Class Initialized
INFO - 2018-02-12 08:26:17 --> URI Class Initialized
INFO - 2018-02-12 08:26:17 --> Router Class Initialized
INFO - 2018-02-12 08:26:17 --> Output Class Initialized
INFO - 2018-02-12 08:26:17 --> Security Class Initialized
DEBUG - 2018-02-12 08:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 08:26:17 --> Input Class Initialized
INFO - 2018-02-12 08:26:17 --> Language Class Initialized
INFO - 2018-02-12 08:26:17 --> Language Class Initialized
INFO - 2018-02-12 08:26:17 --> Config Class Initialized
INFO - 2018-02-12 08:26:17 --> Loader Class Initialized
INFO - 2018-02-12 13:56:17 --> Helper loaded: url_helper
INFO - 2018-02-12 13:56:17 --> Helper loaded: notification_helper
INFO - 2018-02-12 13:56:17 --> Helper loaded: settings_helper
INFO - 2018-02-12 13:56:17 --> Helper loaded: permission_helper
INFO - 2018-02-12 13:56:17 --> Helper loaded: users_helper
INFO - 2018-02-12 13:56:17 --> Database Driver Class Initialized
DEBUG - 2018-02-12 13:56:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 13:56:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 13:56:17 --> Helper loaded: form_helper
INFO - 2018-02-12 13:56:17 --> Form Validation Class Initialized
INFO - 2018-02-12 13:56:17 --> Controller Class Initialized
INFO - 2018-02-12 13:56:17 --> Model Class Initialized
INFO - 2018-02-12 13:56:17 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 13:56:17 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 13:56:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 13:56:17 --> Model Class Initialized
INFO - 2018-02-12 13:56:17 --> Model Class Initialized
INFO - 2018-02-12 13:56:17 --> Model Class Initialized
INFO - 2018-02-12 13:56:17 --> Model Class Initialized
INFO - 2018-02-12 13:56:17 --> Model Class Initialized
INFO - 2018-02-12 13:56:17 --> Model Class Initialized
INFO - 2018-02-12 13:56:17 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 13:56:17 --> Model Class Initialized
INFO - 2018-02-12 13:56:17 --> Final output sent to browser
DEBUG - 2018-02-12 13:56:17 --> Total execution time: 0.1084
INFO - 2018-02-12 08:43:53 --> Config Class Initialized
INFO - 2018-02-12 08:43:53 --> Hooks Class Initialized
DEBUG - 2018-02-12 08:43:53 --> UTF-8 Support Enabled
INFO - 2018-02-12 08:43:53 --> Utf8 Class Initialized
INFO - 2018-02-12 08:43:53 --> URI Class Initialized
INFO - 2018-02-12 08:43:53 --> Router Class Initialized
INFO - 2018-02-12 08:43:53 --> Output Class Initialized
INFO - 2018-02-12 08:43:53 --> Security Class Initialized
DEBUG - 2018-02-12 08:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 08:43:53 --> Input Class Initialized
INFO - 2018-02-12 08:43:53 --> Language Class Initialized
INFO - 2018-02-12 08:43:53 --> Language Class Initialized
INFO - 2018-02-12 08:43:53 --> Config Class Initialized
INFO - 2018-02-12 08:43:53 --> Loader Class Initialized
INFO - 2018-02-12 14:13:53 --> Helper loaded: url_helper
INFO - 2018-02-12 14:13:53 --> Helper loaded: notification_helper
INFO - 2018-02-12 14:13:53 --> Helper loaded: settings_helper
INFO - 2018-02-12 14:13:53 --> Helper loaded: permission_helper
INFO - 2018-02-12 14:13:53 --> Helper loaded: users_helper
INFO - 2018-02-12 14:13:53 --> Database Driver Class Initialized
DEBUG - 2018-02-12 14:13:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 14:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 14:13:53 --> Helper loaded: form_helper
INFO - 2018-02-12 14:13:53 --> Form Validation Class Initialized
INFO - 2018-02-12 14:13:53 --> Controller Class Initialized
INFO - 2018-02-12 14:13:53 --> Model Class Initialized
INFO - 2018-02-12 14:13:53 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 14:13:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 14:13:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 14:13:53 --> Model Class Initialized
INFO - 2018-02-12 14:13:53 --> Model Class Initialized
INFO - 2018-02-12 14:13:53 --> Model Class Initialized
INFO - 2018-02-12 14:13:53 --> Model Class Initialized
INFO - 2018-02-12 14:13:53 --> Model Class Initialized
INFO - 2018-02-12 14:13:53 --> Model Class Initialized
INFO - 2018-02-12 14:13:53 --> Model Class Initialized
INFO - 2018-02-12 14:13:53 --> Model Class Initialized
INFO - 2018-02-12 14:13:53 --> Model Class Initialized
INFO - 2018-02-12 14:13:53 --> Model Class Initialized
INFO - 2018-02-12 14:13:53 --> Model Class Initialized
INFO - 2018-02-12 14:13:53 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 14:13:53 --> Model Class Initialized
INFO - 2018-02-12 14:13:54 --> Final output sent to browser
DEBUG - 2018-02-12 14:13:54 --> Total execution time: 0.1272
INFO - 2018-02-12 08:43:55 --> Config Class Initialized
INFO - 2018-02-12 08:43:55 --> Hooks Class Initialized
DEBUG - 2018-02-12 08:43:55 --> UTF-8 Support Enabled
INFO - 2018-02-12 08:43:55 --> Utf8 Class Initialized
INFO - 2018-02-12 08:43:55 --> URI Class Initialized
INFO - 2018-02-12 08:43:55 --> Router Class Initialized
INFO - 2018-02-12 08:43:55 --> Output Class Initialized
INFO - 2018-02-12 08:43:55 --> Security Class Initialized
DEBUG - 2018-02-12 08:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 08:43:55 --> Input Class Initialized
INFO - 2018-02-12 08:43:55 --> Language Class Initialized
INFO - 2018-02-12 08:43:55 --> Language Class Initialized
INFO - 2018-02-12 08:43:55 --> Config Class Initialized
INFO - 2018-02-12 08:43:55 --> Loader Class Initialized
INFO - 2018-02-12 14:13:55 --> Helper loaded: url_helper
INFO - 2018-02-12 14:13:55 --> Helper loaded: notification_helper
INFO - 2018-02-12 14:13:55 --> Helper loaded: settings_helper
INFO - 2018-02-12 14:13:55 --> Helper loaded: permission_helper
INFO - 2018-02-12 14:13:55 --> Helper loaded: users_helper
INFO - 2018-02-12 14:13:55 --> Database Driver Class Initialized
DEBUG - 2018-02-12 14:13:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 14:13:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 14:13:55 --> Helper loaded: form_helper
INFO - 2018-02-12 14:13:55 --> Form Validation Class Initialized
INFO - 2018-02-12 14:13:55 --> Controller Class Initialized
INFO - 2018-02-12 14:13:55 --> Model Class Initialized
INFO - 2018-02-12 14:13:55 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 14:13:55 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 14:13:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 14:13:55 --> Model Class Initialized
INFO - 2018-02-12 14:13:55 --> Model Class Initialized
INFO - 2018-02-12 14:13:55 --> Model Class Initialized
INFO - 2018-02-12 14:13:55 --> Model Class Initialized
INFO - 2018-02-12 14:13:55 --> Model Class Initialized
INFO - 2018-02-12 14:13:55 --> Model Class Initialized
INFO - 2018-02-12 14:13:55 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 14:13:55 --> Model Class Initialized
INFO - 2018-02-12 14:13:55 --> Final output sent to browser
DEBUG - 2018-02-12 14:13:55 --> Total execution time: 0.1059
INFO - 2018-02-12 08:44:22 --> Config Class Initialized
INFO - 2018-02-12 08:44:22 --> Hooks Class Initialized
DEBUG - 2018-02-12 08:44:22 --> UTF-8 Support Enabled
INFO - 2018-02-12 08:44:22 --> Utf8 Class Initialized
INFO - 2018-02-12 08:44:22 --> URI Class Initialized
INFO - 2018-02-12 08:44:22 --> Config Class Initialized
INFO - 2018-02-12 08:44:22 --> Hooks Class Initialized
DEBUG - 2018-02-12 08:44:22 --> UTF-8 Support Enabled
INFO - 2018-02-12 08:44:22 --> Utf8 Class Initialized
INFO - 2018-02-12 08:44:22 --> Router Class Initialized
INFO - 2018-02-12 08:44:22 --> URI Class Initialized
INFO - 2018-02-12 08:44:22 --> Output Class Initialized
INFO - 2018-02-12 08:44:22 --> Router Class Initialized
INFO - 2018-02-12 08:44:22 --> Security Class Initialized
DEBUG - 2018-02-12 08:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 08:44:22 --> Input Class Initialized
INFO - 2018-02-12 08:44:22 --> Output Class Initialized
INFO - 2018-02-12 08:44:22 --> Language Class Initialized
INFO - 2018-02-12 08:44:22 --> Security Class Initialized
DEBUG - 2018-02-12 08:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 08:44:22 --> Input Class Initialized
INFO - 2018-02-12 08:44:22 --> Language Class Initialized
INFO - 2018-02-12 08:44:22 --> Language Class Initialized
INFO - 2018-02-12 08:44:22 --> Config Class Initialized
INFO - 2018-02-12 08:44:22 --> Loader Class Initialized
INFO - 2018-02-12 14:14:22 --> Helper loaded: url_helper
INFO - 2018-02-12 14:14:22 --> Helper loaded: notification_helper
INFO - 2018-02-12 14:14:22 --> Helper loaded: settings_helper
INFO - 2018-02-12 14:14:22 --> Helper loaded: permission_helper
INFO - 2018-02-12 14:14:22 --> Helper loaded: users_helper
INFO - 2018-02-12 08:44:22 --> Language Class Initialized
INFO - 2018-02-12 08:44:22 --> Config Class Initialized
INFO - 2018-02-12 08:44:22 --> Loader Class Initialized
INFO - 2018-02-12 14:14:22 --> Helper loaded: url_helper
INFO - 2018-02-12 14:14:22 --> Helper loaded: notification_helper
INFO - 2018-02-12 14:14:22 --> Helper loaded: settings_helper
INFO - 2018-02-12 14:14:22 --> Helper loaded: permission_helper
INFO - 2018-02-12 14:14:22 --> Helper loaded: users_helper
INFO - 2018-02-12 14:14:22 --> Database Driver Class Initialized
DEBUG - 2018-02-12 14:14:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 14:14:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 14:14:22 --> Database Driver Class Initialized
INFO - 2018-02-12 14:14:22 --> Helper loaded: form_helper
INFO - 2018-02-12 14:14:22 --> Form Validation Class Initialized
INFO - 2018-02-12 14:14:22 --> Controller Class Initialized
DEBUG - 2018-02-12 14:14:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 14:14:22 --> Model Class Initialized
INFO - 2018-02-12 14:14:22 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 14:14:22 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 14:14:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 14:14:22 --> Model Class Initialized
INFO - 2018-02-12 14:14:22 --> Model Class Initialized
INFO - 2018-02-12 14:14:22 --> Model Class Initialized
INFO - 2018-02-12 14:14:22 --> Model Class Initialized
INFO - 2018-02-12 14:14:22 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 14:14:22 --> Final output sent to browser
DEBUG - 2018-02-12 14:14:22 --> Total execution time: 0.1063
INFO - 2018-02-12 14:14:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 14:14:22 --> Helper loaded: form_helper
INFO - 2018-02-12 14:14:22 --> Form Validation Class Initialized
INFO - 2018-02-12 14:14:22 --> Controller Class Initialized
INFO - 2018-02-12 14:14:22 --> Model Class Initialized
INFO - 2018-02-12 14:14:22 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 14:14:22 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 14:14:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 14:14:22 --> Model Class Initialized
INFO - 2018-02-12 14:14:22 --> Model Class Initialized
INFO - 2018-02-12 14:14:22 --> Model Class Initialized
INFO - 2018-02-12 14:14:22 --> Model Class Initialized
INFO - 2018-02-12 14:14:22 --> Model Class Initialized
INFO - 2018-02-12 14:14:22 --> Model Class Initialized
INFO - 2018-02-12 14:14:22 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 14:14:22 --> Final output sent to browser
DEBUG - 2018-02-12 14:14:22 --> Total execution time: 0.1352
INFO - 2018-02-12 08:44:29 --> Config Class Initialized
INFO - 2018-02-12 08:44:29 --> Hooks Class Initialized
DEBUG - 2018-02-12 08:44:29 --> UTF-8 Support Enabled
INFO - 2018-02-12 08:44:29 --> Utf8 Class Initialized
INFO - 2018-02-12 08:44:29 --> URI Class Initialized
INFO - 2018-02-12 08:44:29 --> Router Class Initialized
INFO - 2018-02-12 08:44:29 --> Output Class Initialized
INFO - 2018-02-12 08:44:29 --> Security Class Initialized
DEBUG - 2018-02-12 08:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 08:44:29 --> Input Class Initialized
INFO - 2018-02-12 08:44:29 --> Language Class Initialized
INFO - 2018-02-12 08:44:29 --> Language Class Initialized
INFO - 2018-02-12 08:44:29 --> Config Class Initialized
INFO - 2018-02-12 08:44:29 --> Loader Class Initialized
INFO - 2018-02-12 14:14:29 --> Helper loaded: url_helper
INFO - 2018-02-12 14:14:29 --> Helper loaded: notification_helper
INFO - 2018-02-12 14:14:29 --> Helper loaded: settings_helper
INFO - 2018-02-12 14:14:29 --> Helper loaded: permission_helper
INFO - 2018-02-12 14:14:29 --> Helper loaded: users_helper
INFO - 2018-02-12 14:14:29 --> Database Driver Class Initialized
DEBUG - 2018-02-12 14:14:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 14:14:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 14:14:29 --> Helper loaded: form_helper
INFO - 2018-02-12 14:14:29 --> Form Validation Class Initialized
INFO - 2018-02-12 14:14:29 --> Controller Class Initialized
INFO - 2018-02-12 14:14:29 --> Model Class Initialized
INFO - 2018-02-12 14:14:29 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 14:14:29 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 14:14:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 14:14:29 --> Model Class Initialized
INFO - 2018-02-12 14:14:29 --> Model Class Initialized
INFO - 2018-02-12 14:14:29 --> Model Class Initialized
INFO - 2018-02-12 14:14:29 --> Model Class Initialized
INFO - 2018-02-12 14:14:29 --> Model Class Initialized
INFO - 2018-02-12 14:14:29 --> Model Class Initialized
INFO - 2018-02-12 14:14:29 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 14:14:29 --> Model Class Initialized
INFO - 2018-02-12 14:14:29 --> Final output sent to browser
DEBUG - 2018-02-12 14:14:29 --> Total execution time: 0.1165
INFO - 2018-02-12 08:44:42 --> Config Class Initialized
INFO - 2018-02-12 08:44:42 --> Hooks Class Initialized
DEBUG - 2018-02-12 08:44:42 --> UTF-8 Support Enabled
INFO - 2018-02-12 08:44:42 --> Utf8 Class Initialized
INFO - 2018-02-12 08:44:42 --> URI Class Initialized
INFO - 2018-02-12 08:44:42 --> Router Class Initialized
INFO - 2018-02-12 08:44:42 --> Output Class Initialized
INFO - 2018-02-12 08:44:42 --> Security Class Initialized
DEBUG - 2018-02-12 08:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 08:44:42 --> Input Class Initialized
INFO - 2018-02-12 08:44:42 --> Language Class Initialized
INFO - 2018-02-12 08:44:42 --> Language Class Initialized
INFO - 2018-02-12 08:44:42 --> Config Class Initialized
INFO - 2018-02-12 08:44:42 --> Loader Class Initialized
INFO - 2018-02-12 14:14:42 --> Helper loaded: url_helper
INFO - 2018-02-12 14:14:42 --> Helper loaded: notification_helper
INFO - 2018-02-12 14:14:42 --> Helper loaded: settings_helper
INFO - 2018-02-12 14:14:42 --> Helper loaded: permission_helper
INFO - 2018-02-12 14:14:42 --> Helper loaded: users_helper
INFO - 2018-02-12 14:14:42 --> Database Driver Class Initialized
DEBUG - 2018-02-12 14:14:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 14:14:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 14:14:42 --> Helper loaded: form_helper
INFO - 2018-02-12 14:14:42 --> Form Validation Class Initialized
INFO - 2018-02-12 14:14:42 --> Controller Class Initialized
INFO - 2018-02-12 14:14:42 --> Model Class Initialized
INFO - 2018-02-12 14:14:42 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 14:14:42 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 14:14:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 14:14:42 --> Model Class Initialized
INFO - 2018-02-12 14:14:42 --> Model Class Initialized
INFO - 2018-02-12 14:14:42 --> Model Class Initialized
INFO - 2018-02-12 14:14:42 --> Model Class Initialized
INFO - 2018-02-12 14:14:42 --> Model Class Initialized
INFO - 2018-02-12 14:14:42 --> Model Class Initialized
INFO - 2018-02-12 14:14:42 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 14:14:42 --> Model Class Initialized
INFO - 2018-02-12 14:14:42 --> Final output sent to browser
DEBUG - 2018-02-12 14:14:42 --> Total execution time: 0.1071
INFO - 2018-02-12 08:44:46 --> Config Class Initialized
INFO - 2018-02-12 08:44:46 --> Hooks Class Initialized
DEBUG - 2018-02-12 08:44:46 --> UTF-8 Support Enabled
INFO - 2018-02-12 08:44:46 --> Utf8 Class Initialized
INFO - 2018-02-12 08:44:46 --> URI Class Initialized
INFO - 2018-02-12 08:44:46 --> Router Class Initialized
INFO - 2018-02-12 08:44:46 --> Output Class Initialized
INFO - 2018-02-12 08:44:46 --> Security Class Initialized
DEBUG - 2018-02-12 08:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 08:44:46 --> Input Class Initialized
INFO - 2018-02-12 08:44:46 --> Language Class Initialized
INFO - 2018-02-12 08:44:46 --> Language Class Initialized
INFO - 2018-02-12 08:44:46 --> Config Class Initialized
INFO - 2018-02-12 08:44:46 --> Loader Class Initialized
INFO - 2018-02-12 14:14:46 --> Helper loaded: url_helper
INFO - 2018-02-12 14:14:46 --> Helper loaded: notification_helper
INFO - 2018-02-12 14:14:46 --> Helper loaded: settings_helper
INFO - 2018-02-12 14:14:46 --> Helper loaded: permission_helper
INFO - 2018-02-12 14:14:46 --> Helper loaded: users_helper
INFO - 2018-02-12 14:14:46 --> Database Driver Class Initialized
DEBUG - 2018-02-12 14:14:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 14:14:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 14:14:46 --> Helper loaded: form_helper
INFO - 2018-02-12 14:14:46 --> Form Validation Class Initialized
INFO - 2018-02-12 14:14:46 --> Controller Class Initialized
INFO - 2018-02-12 14:14:46 --> Model Class Initialized
INFO - 2018-02-12 14:14:46 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 14:14:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 14:14:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 14:14:46 --> Model Class Initialized
INFO - 2018-02-12 14:14:46 --> Model Class Initialized
INFO - 2018-02-12 14:14:46 --> Model Class Initialized
INFO - 2018-02-12 14:14:46 --> Model Class Initialized
INFO - 2018-02-12 14:14:46 --> Model Class Initialized
INFO - 2018-02-12 14:14:46 --> Model Class Initialized
INFO - 2018-02-12 14:14:46 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 14:14:46 --> Model Class Initialized
INFO - 2018-02-12 14:14:46 --> Final output sent to browser
DEBUG - 2018-02-12 14:14:46 --> Total execution time: 0.1101
INFO - 2018-02-12 08:44:50 --> Config Class Initialized
INFO - 2018-02-12 08:44:50 --> Hooks Class Initialized
DEBUG - 2018-02-12 08:44:50 --> UTF-8 Support Enabled
INFO - 2018-02-12 08:44:50 --> Utf8 Class Initialized
INFO - 2018-02-12 08:44:50 --> URI Class Initialized
INFO - 2018-02-12 08:44:50 --> Router Class Initialized
INFO - 2018-02-12 08:44:50 --> Output Class Initialized
INFO - 2018-02-12 08:44:50 --> Security Class Initialized
DEBUG - 2018-02-12 08:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 08:44:50 --> Input Class Initialized
INFO - 2018-02-12 08:44:50 --> Language Class Initialized
INFO - 2018-02-12 08:44:50 --> Language Class Initialized
INFO - 2018-02-12 08:44:50 --> Config Class Initialized
INFO - 2018-02-12 08:44:50 --> Loader Class Initialized
INFO - 2018-02-12 14:14:50 --> Helper loaded: url_helper
INFO - 2018-02-12 14:14:50 --> Helper loaded: notification_helper
INFO - 2018-02-12 14:14:50 --> Helper loaded: settings_helper
INFO - 2018-02-12 14:14:50 --> Helper loaded: permission_helper
INFO - 2018-02-12 14:14:50 --> Helper loaded: users_helper
INFO - 2018-02-12 14:14:50 --> Database Driver Class Initialized
DEBUG - 2018-02-12 14:14:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 14:14:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 14:14:50 --> Helper loaded: form_helper
INFO - 2018-02-12 14:14:50 --> Form Validation Class Initialized
INFO - 2018-02-12 14:14:50 --> Controller Class Initialized
INFO - 2018-02-12 14:14:50 --> Model Class Initialized
INFO - 2018-02-12 14:14:50 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 14:14:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 14:14:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 14:14:50 --> Model Class Initialized
INFO - 2018-02-12 14:14:50 --> Model Class Initialized
INFO - 2018-02-12 14:14:50 --> Model Class Initialized
INFO - 2018-02-12 14:14:50 --> Model Class Initialized
INFO - 2018-02-12 14:14:50 --> Model Class Initialized
INFO - 2018-02-12 14:14:50 --> Model Class Initialized
INFO - 2018-02-12 14:14:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 14:14:50 --> Model Class Initialized
INFO - 2018-02-12 14:14:50 --> Final output sent to browser
DEBUG - 2018-02-12 14:14:50 --> Total execution time: 0.1180
INFO - 2018-02-12 08:44:54 --> Config Class Initialized
INFO - 2018-02-12 08:44:54 --> Hooks Class Initialized
DEBUG - 2018-02-12 08:44:54 --> UTF-8 Support Enabled
INFO - 2018-02-12 08:44:54 --> Utf8 Class Initialized
INFO - 2018-02-12 08:44:54 --> URI Class Initialized
INFO - 2018-02-12 08:44:54 --> Router Class Initialized
INFO - 2018-02-12 08:44:54 --> Output Class Initialized
INFO - 2018-02-12 08:44:54 --> Security Class Initialized
DEBUG - 2018-02-12 08:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 08:44:54 --> Input Class Initialized
INFO - 2018-02-12 08:44:54 --> Language Class Initialized
INFO - 2018-02-12 08:44:54 --> Language Class Initialized
INFO - 2018-02-12 08:44:54 --> Config Class Initialized
INFO - 2018-02-12 08:44:54 --> Loader Class Initialized
INFO - 2018-02-12 14:14:54 --> Helper loaded: url_helper
INFO - 2018-02-12 14:14:54 --> Helper loaded: notification_helper
INFO - 2018-02-12 14:14:54 --> Helper loaded: settings_helper
INFO - 2018-02-12 14:14:54 --> Helper loaded: permission_helper
INFO - 2018-02-12 14:14:54 --> Helper loaded: users_helper
INFO - 2018-02-12 14:14:54 --> Database Driver Class Initialized
DEBUG - 2018-02-12 14:14:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 14:14:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 14:14:54 --> Helper loaded: form_helper
INFO - 2018-02-12 14:14:54 --> Form Validation Class Initialized
INFO - 2018-02-12 14:14:54 --> Controller Class Initialized
INFO - 2018-02-12 14:14:54 --> Model Class Initialized
INFO - 2018-02-12 14:14:54 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 14:14:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 14:14:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 14:14:54 --> Model Class Initialized
INFO - 2018-02-12 14:14:54 --> Model Class Initialized
INFO - 2018-02-12 14:14:54 --> Model Class Initialized
INFO - 2018-02-12 14:14:54 --> Model Class Initialized
INFO - 2018-02-12 14:14:54 --> Model Class Initialized
INFO - 2018-02-12 14:14:54 --> Model Class Initialized
INFO - 2018-02-12 14:14:54 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 14:14:54 --> Model Class Initialized
INFO - 2018-02-12 14:14:54 --> Final output sent to browser
DEBUG - 2018-02-12 14:14:54 --> Total execution time: 0.1037
INFO - 2018-02-12 08:45:02 --> Config Class Initialized
INFO - 2018-02-12 08:45:02 --> Hooks Class Initialized
DEBUG - 2018-02-12 08:45:02 --> UTF-8 Support Enabled
INFO - 2018-02-12 08:45:02 --> Utf8 Class Initialized
INFO - 2018-02-12 08:45:02 --> URI Class Initialized
INFO - 2018-02-12 08:45:02 --> Router Class Initialized
INFO - 2018-02-12 08:45:02 --> Output Class Initialized
INFO - 2018-02-12 08:45:02 --> Security Class Initialized
DEBUG - 2018-02-12 08:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 08:45:02 --> Input Class Initialized
INFO - 2018-02-12 08:45:02 --> Language Class Initialized
INFO - 2018-02-12 08:45:02 --> Language Class Initialized
INFO - 2018-02-12 08:45:02 --> Config Class Initialized
INFO - 2018-02-12 08:45:02 --> Loader Class Initialized
INFO - 2018-02-12 14:15:02 --> Helper loaded: url_helper
INFO - 2018-02-12 14:15:02 --> Helper loaded: notification_helper
INFO - 2018-02-12 14:15:02 --> Helper loaded: settings_helper
INFO - 2018-02-12 14:15:02 --> Helper loaded: permission_helper
INFO - 2018-02-12 14:15:02 --> Helper loaded: users_helper
INFO - 2018-02-12 14:15:02 --> Database Driver Class Initialized
DEBUG - 2018-02-12 14:15:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 14:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 14:15:02 --> Helper loaded: form_helper
INFO - 2018-02-12 14:15:02 --> Form Validation Class Initialized
INFO - 2018-02-12 14:15:02 --> Controller Class Initialized
INFO - 2018-02-12 14:15:02 --> Model Class Initialized
INFO - 2018-02-12 14:15:02 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 14:15:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 14:15:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 14:15:02 --> Model Class Initialized
INFO - 2018-02-12 14:15:02 --> Model Class Initialized
INFO - 2018-02-12 14:15:02 --> Model Class Initialized
INFO - 2018-02-12 14:15:02 --> Model Class Initialized
INFO - 2018-02-12 14:15:02 --> Model Class Initialized
INFO - 2018-02-12 14:15:02 --> Model Class Initialized
INFO - 2018-02-12 14:15:02 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 14:15:02 --> Final output sent to browser
DEBUG - 2018-02-12 14:15:02 --> Total execution time: 0.1316
INFO - 2018-02-12 08:45:04 --> Config Class Initialized
INFO - 2018-02-12 08:45:04 --> Hooks Class Initialized
DEBUG - 2018-02-12 08:45:04 --> UTF-8 Support Enabled
INFO - 2018-02-12 08:45:04 --> Utf8 Class Initialized
INFO - 2018-02-12 08:45:04 --> URI Class Initialized
INFO - 2018-02-12 08:45:04 --> Router Class Initialized
INFO - 2018-02-12 08:45:04 --> Output Class Initialized
INFO - 2018-02-12 08:45:04 --> Security Class Initialized
DEBUG - 2018-02-12 08:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 08:45:04 --> Input Class Initialized
INFO - 2018-02-12 08:45:04 --> Language Class Initialized
INFO - 2018-02-12 08:45:04 --> Language Class Initialized
INFO - 2018-02-12 08:45:04 --> Config Class Initialized
INFO - 2018-02-12 08:45:04 --> Loader Class Initialized
INFO - 2018-02-12 14:15:04 --> Helper loaded: url_helper
INFO - 2018-02-12 14:15:04 --> Helper loaded: notification_helper
INFO - 2018-02-12 14:15:04 --> Helper loaded: settings_helper
INFO - 2018-02-12 14:15:04 --> Helper loaded: permission_helper
INFO - 2018-02-12 14:15:04 --> Helper loaded: users_helper
INFO - 2018-02-12 14:15:04 --> Database Driver Class Initialized
DEBUG - 2018-02-12 14:15:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 14:15:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 14:15:04 --> Helper loaded: form_helper
INFO - 2018-02-12 14:15:04 --> Form Validation Class Initialized
INFO - 2018-02-12 14:15:04 --> Controller Class Initialized
INFO - 2018-02-12 14:15:04 --> Model Class Initialized
INFO - 2018-02-12 14:15:04 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 14:15:04 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 14:15:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 14:15:04 --> Model Class Initialized
INFO - 2018-02-12 14:15:04 --> Model Class Initialized
INFO - 2018-02-12 14:15:04 --> Model Class Initialized
INFO - 2018-02-12 14:15:04 --> Model Class Initialized
INFO - 2018-02-12 14:15:04 --> Model Class Initialized
INFO - 2018-02-12 14:15:04 --> Model Class Initialized
INFO - 2018-02-12 14:15:04 --> Model Class Initialized
INFO - 2018-02-12 14:15:04 --> Model Class Initialized
INFO - 2018-02-12 14:15:04 --> Model Class Initialized
INFO - 2018-02-12 14:15:04 --> Model Class Initialized
INFO - 2018-02-12 14:15:04 --> Model Class Initialized
INFO - 2018-02-12 14:15:04 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 14:15:04 --> Model Class Initialized
INFO - 2018-02-12 14:15:04 --> Final output sent to browser
DEBUG - 2018-02-12 14:15:04 --> Total execution time: 0.1373
INFO - 2018-02-12 08:45:12 --> Config Class Initialized
INFO - 2018-02-12 08:45:12 --> Hooks Class Initialized
DEBUG - 2018-02-12 08:45:12 --> UTF-8 Support Enabled
INFO - 2018-02-12 08:45:12 --> Utf8 Class Initialized
INFO - 2018-02-12 08:45:12 --> URI Class Initialized
INFO - 2018-02-12 08:45:12 --> Router Class Initialized
INFO - 2018-02-12 08:45:12 --> Output Class Initialized
INFO - 2018-02-12 08:45:12 --> Security Class Initialized
DEBUG - 2018-02-12 08:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 08:45:12 --> Input Class Initialized
INFO - 2018-02-12 08:45:12 --> Language Class Initialized
INFO - 2018-02-12 08:45:12 --> Language Class Initialized
INFO - 2018-02-12 08:45:12 --> Config Class Initialized
INFO - 2018-02-12 08:45:12 --> Loader Class Initialized
INFO - 2018-02-12 14:15:12 --> Helper loaded: url_helper
INFO - 2018-02-12 14:15:12 --> Helper loaded: notification_helper
INFO - 2018-02-12 14:15:12 --> Helper loaded: settings_helper
INFO - 2018-02-12 14:15:12 --> Helper loaded: permission_helper
INFO - 2018-02-12 14:15:12 --> Helper loaded: users_helper
INFO - 2018-02-12 14:15:12 --> Database Driver Class Initialized
DEBUG - 2018-02-12 14:15:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 14:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 14:15:12 --> Helper loaded: form_helper
INFO - 2018-02-12 14:15:12 --> Form Validation Class Initialized
INFO - 2018-02-12 14:15:12 --> Controller Class Initialized
INFO - 2018-02-12 14:15:12 --> Model Class Initialized
INFO - 2018-02-12 14:15:12 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 14:15:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 14:15:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 14:15:12 --> Model Class Initialized
INFO - 2018-02-12 14:15:12 --> Model Class Initialized
INFO - 2018-02-12 14:15:12 --> Model Class Initialized
INFO - 2018-02-12 14:15:12 --> Model Class Initialized
INFO - 2018-02-12 14:15:12 --> Model Class Initialized
INFO - 2018-02-12 14:15:12 --> Model Class Initialized
INFO - 2018-02-12 14:15:12 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-02-12 14:15:12 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 771
INFO - 2018-02-12 14:15:12 --> Final output sent to browser
DEBUG - 2018-02-12 14:15:12 --> Total execution time: 0.0968
INFO - 2018-02-12 08:45:21 --> Config Class Initialized
INFO - 2018-02-12 08:45:21 --> Hooks Class Initialized
DEBUG - 2018-02-12 08:45:21 --> UTF-8 Support Enabled
INFO - 2018-02-12 08:45:21 --> Utf8 Class Initialized
INFO - 2018-02-12 08:45:21 --> URI Class Initialized
INFO - 2018-02-12 08:45:21 --> Router Class Initialized
INFO - 2018-02-12 08:45:21 --> Output Class Initialized
INFO - 2018-02-12 08:45:21 --> Security Class Initialized
DEBUG - 2018-02-12 08:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 08:45:21 --> Input Class Initialized
INFO - 2018-02-12 08:45:21 --> Language Class Initialized
INFO - 2018-02-12 08:45:21 --> Language Class Initialized
INFO - 2018-02-12 08:45:21 --> Config Class Initialized
INFO - 2018-02-12 08:45:21 --> Loader Class Initialized
INFO - 2018-02-12 14:15:21 --> Helper loaded: url_helper
INFO - 2018-02-12 14:15:21 --> Helper loaded: notification_helper
INFO - 2018-02-12 14:15:21 --> Helper loaded: settings_helper
INFO - 2018-02-12 14:15:21 --> Helper loaded: permission_helper
INFO - 2018-02-12 14:15:21 --> Helper loaded: users_helper
INFO - 2018-02-12 14:15:21 --> Database Driver Class Initialized
DEBUG - 2018-02-12 14:15:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 14:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 14:15:21 --> Helper loaded: form_helper
INFO - 2018-02-12 14:15:21 --> Form Validation Class Initialized
INFO - 2018-02-12 14:15:21 --> Controller Class Initialized
INFO - 2018-02-12 14:15:21 --> Model Class Initialized
INFO - 2018-02-12 14:15:21 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 14:15:21 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 14:15:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 14:15:21 --> Model Class Initialized
INFO - 2018-02-12 14:15:21 --> Model Class Initialized
INFO - 2018-02-12 14:15:21 --> Model Class Initialized
INFO - 2018-02-12 14:15:21 --> Model Class Initialized
INFO - 2018-02-12 14:15:21 --> Model Class Initialized
INFO - 2018-02-12 14:15:21 --> Model Class Initialized
INFO - 2018-02-12 14:15:21 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 14:15:21 --> Model Class Initialized
INFO - 2018-02-12 14:15:21 --> Final output sent to browser
DEBUG - 2018-02-12 14:15:21 --> Total execution time: 0.1064
INFO - 2018-02-12 08:45:42 --> Config Class Initialized
INFO - 2018-02-12 08:45:42 --> Hooks Class Initialized
DEBUG - 2018-02-12 08:45:42 --> UTF-8 Support Enabled
INFO - 2018-02-12 08:45:42 --> Utf8 Class Initialized
INFO - 2018-02-12 08:45:42 --> URI Class Initialized
INFO - 2018-02-12 08:45:42 --> Router Class Initialized
INFO - 2018-02-12 08:45:42 --> Output Class Initialized
INFO - 2018-02-12 08:45:42 --> Security Class Initialized
DEBUG - 2018-02-12 08:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 08:45:42 --> Input Class Initialized
INFO - 2018-02-12 08:45:42 --> Language Class Initialized
INFO - 2018-02-12 08:45:42 --> Language Class Initialized
INFO - 2018-02-12 08:45:42 --> Config Class Initialized
INFO - 2018-02-12 08:45:42 --> Loader Class Initialized
INFO - 2018-02-12 14:15:42 --> Helper loaded: url_helper
INFO - 2018-02-12 14:15:42 --> Helper loaded: notification_helper
INFO - 2018-02-12 14:15:42 --> Helper loaded: settings_helper
INFO - 2018-02-12 14:15:42 --> Helper loaded: permission_helper
INFO - 2018-02-12 14:15:42 --> Helper loaded: users_helper
INFO - 2018-02-12 14:15:42 --> Database Driver Class Initialized
DEBUG - 2018-02-12 14:15:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 14:15:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 14:15:42 --> Helper loaded: form_helper
INFO - 2018-02-12 14:15:42 --> Form Validation Class Initialized
INFO - 2018-02-12 14:15:42 --> Controller Class Initialized
INFO - 2018-02-12 14:15:42 --> Model Class Initialized
INFO - 2018-02-12 14:15:42 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 14:15:42 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 14:15:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 14:15:42 --> Model Class Initialized
INFO - 2018-02-12 14:15:42 --> Model Class Initialized
INFO - 2018-02-12 14:15:42 --> Model Class Initialized
INFO - 2018-02-12 14:15:42 --> Model Class Initialized
INFO - 2018-02-12 14:15:42 --> Model Class Initialized
INFO - 2018-02-12 14:15:42 --> Model Class Initialized
INFO - 2018-02-12 14:15:42 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-02-12 14:15:42 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 771
ERROR - 2018-02-12 14:15:42 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 781
INFO - 2018-02-12 14:15:42 --> Final output sent to browser
DEBUG - 2018-02-12 14:15:42 --> Total execution time: 0.1145
INFO - 2018-02-12 08:45:50 --> Config Class Initialized
INFO - 2018-02-12 08:45:50 --> Hooks Class Initialized
DEBUG - 2018-02-12 08:45:50 --> UTF-8 Support Enabled
INFO - 2018-02-12 08:45:50 --> Utf8 Class Initialized
INFO - 2018-02-12 08:45:50 --> URI Class Initialized
INFO - 2018-02-12 08:45:50 --> Router Class Initialized
INFO - 2018-02-12 08:45:50 --> Output Class Initialized
INFO - 2018-02-12 08:45:50 --> Security Class Initialized
DEBUG - 2018-02-12 08:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 08:45:50 --> Input Class Initialized
INFO - 2018-02-12 08:45:50 --> Language Class Initialized
INFO - 2018-02-12 08:45:50 --> Language Class Initialized
INFO - 2018-02-12 08:45:50 --> Config Class Initialized
INFO - 2018-02-12 08:45:50 --> Loader Class Initialized
INFO - 2018-02-12 14:15:50 --> Helper loaded: url_helper
INFO - 2018-02-12 14:15:50 --> Helper loaded: notification_helper
INFO - 2018-02-12 14:15:50 --> Helper loaded: settings_helper
INFO - 2018-02-12 14:15:50 --> Helper loaded: permission_helper
INFO - 2018-02-12 14:15:50 --> Helper loaded: users_helper
INFO - 2018-02-12 14:15:50 --> Database Driver Class Initialized
DEBUG - 2018-02-12 14:15:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 14:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 14:15:50 --> Helper loaded: form_helper
INFO - 2018-02-12 14:15:50 --> Form Validation Class Initialized
INFO - 2018-02-12 14:15:50 --> Controller Class Initialized
INFO - 2018-02-12 14:15:50 --> Model Class Initialized
INFO - 2018-02-12 14:15:50 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 14:15:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 14:15:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 14:15:50 --> Model Class Initialized
INFO - 2018-02-12 14:15:50 --> Model Class Initialized
INFO - 2018-02-12 14:15:50 --> Model Class Initialized
INFO - 2018-02-12 14:15:50 --> Model Class Initialized
INFO - 2018-02-12 14:15:50 --> Model Class Initialized
INFO - 2018-02-12 14:15:50 --> Model Class Initialized
INFO - 2018-02-12 14:15:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 14:15:50 --> Model Class Initialized
INFO - 2018-02-12 14:15:50 --> Final output sent to browser
DEBUG - 2018-02-12 14:15:50 --> Total execution time: 0.0966
INFO - 2018-02-12 08:45:54 --> Config Class Initialized
INFO - 2018-02-12 08:45:54 --> Hooks Class Initialized
DEBUG - 2018-02-12 08:45:54 --> UTF-8 Support Enabled
INFO - 2018-02-12 08:45:54 --> Utf8 Class Initialized
INFO - 2018-02-12 08:45:54 --> URI Class Initialized
INFO - 2018-02-12 08:45:54 --> Router Class Initialized
INFO - 2018-02-12 08:45:54 --> Output Class Initialized
INFO - 2018-02-12 08:45:54 --> Security Class Initialized
DEBUG - 2018-02-12 08:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 08:45:54 --> Input Class Initialized
INFO - 2018-02-12 08:45:54 --> Language Class Initialized
INFO - 2018-02-12 08:45:54 --> Language Class Initialized
INFO - 2018-02-12 08:45:54 --> Config Class Initialized
INFO - 2018-02-12 08:45:54 --> Loader Class Initialized
INFO - 2018-02-12 14:15:54 --> Helper loaded: url_helper
INFO - 2018-02-12 14:15:54 --> Helper loaded: notification_helper
INFO - 2018-02-12 14:15:54 --> Helper loaded: settings_helper
INFO - 2018-02-12 14:15:54 --> Helper loaded: permission_helper
INFO - 2018-02-12 14:15:54 --> Helper loaded: users_helper
INFO - 2018-02-12 14:15:54 --> Database Driver Class Initialized
DEBUG - 2018-02-12 14:15:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 14:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 14:15:54 --> Helper loaded: form_helper
INFO - 2018-02-12 14:15:54 --> Form Validation Class Initialized
INFO - 2018-02-12 14:15:54 --> Controller Class Initialized
INFO - 2018-02-12 14:15:54 --> Model Class Initialized
INFO - 2018-02-12 14:15:54 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 14:15:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 14:15:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 14:15:54 --> Model Class Initialized
INFO - 2018-02-12 14:15:54 --> Model Class Initialized
INFO - 2018-02-12 14:15:54 --> Model Class Initialized
INFO - 2018-02-12 14:15:54 --> Model Class Initialized
INFO - 2018-02-12 14:15:54 --> Model Class Initialized
INFO - 2018-02-12 14:15:54 --> Model Class Initialized
INFO - 2018-02-12 14:15:54 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 14:15:55 --> Final output sent to browser
DEBUG - 2018-02-12 14:15:55 --> Total execution time: 0.1235
INFO - 2018-02-12 08:45:56 --> Config Class Initialized
INFO - 2018-02-12 08:45:56 --> Hooks Class Initialized
DEBUG - 2018-02-12 08:45:56 --> UTF-8 Support Enabled
INFO - 2018-02-12 08:45:56 --> Utf8 Class Initialized
INFO - 2018-02-12 08:45:56 --> URI Class Initialized
INFO - 2018-02-12 08:45:56 --> Router Class Initialized
INFO - 2018-02-12 08:45:56 --> Output Class Initialized
INFO - 2018-02-12 08:45:56 --> Security Class Initialized
DEBUG - 2018-02-12 08:45:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 08:45:56 --> Input Class Initialized
INFO - 2018-02-12 08:45:56 --> Language Class Initialized
INFO - 2018-02-12 08:45:56 --> Language Class Initialized
INFO - 2018-02-12 08:45:56 --> Config Class Initialized
INFO - 2018-02-12 08:45:56 --> Loader Class Initialized
INFO - 2018-02-12 14:15:56 --> Helper loaded: url_helper
INFO - 2018-02-12 14:15:56 --> Helper loaded: notification_helper
INFO - 2018-02-12 14:15:56 --> Helper loaded: settings_helper
INFO - 2018-02-12 14:15:56 --> Helper loaded: permission_helper
INFO - 2018-02-12 14:15:56 --> Helper loaded: users_helper
INFO - 2018-02-12 14:15:56 --> Database Driver Class Initialized
DEBUG - 2018-02-12 14:15:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 14:15:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 14:15:56 --> Helper loaded: form_helper
INFO - 2018-02-12 14:15:56 --> Form Validation Class Initialized
INFO - 2018-02-12 14:15:56 --> Controller Class Initialized
INFO - 2018-02-12 14:15:56 --> Model Class Initialized
INFO - 2018-02-12 14:15:56 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 14:15:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 14:15:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 14:15:56 --> Model Class Initialized
INFO - 2018-02-12 14:15:56 --> Model Class Initialized
INFO - 2018-02-12 14:15:56 --> Model Class Initialized
INFO - 2018-02-12 14:15:56 --> Model Class Initialized
INFO - 2018-02-12 14:15:56 --> Model Class Initialized
INFO - 2018-02-12 14:15:56 --> Model Class Initialized
INFO - 2018-02-12 14:15:56 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 14:15:56 --> Model Class Initialized
INFO - 2018-02-12 14:15:56 --> Final output sent to browser
DEBUG - 2018-02-12 14:15:56 --> Total execution time: 0.1148
INFO - 2018-02-12 08:46:03 --> Config Class Initialized
INFO - 2018-02-12 08:46:03 --> Hooks Class Initialized
DEBUG - 2018-02-12 08:46:03 --> UTF-8 Support Enabled
INFO - 2018-02-12 08:46:03 --> Utf8 Class Initialized
INFO - 2018-02-12 08:46:03 --> URI Class Initialized
INFO - 2018-02-12 08:46:03 --> Router Class Initialized
INFO - 2018-02-12 08:46:03 --> Output Class Initialized
INFO - 2018-02-12 08:46:03 --> Security Class Initialized
DEBUG - 2018-02-12 08:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 08:46:03 --> Input Class Initialized
INFO - 2018-02-12 08:46:03 --> Language Class Initialized
INFO - 2018-02-12 08:46:03 --> Language Class Initialized
INFO - 2018-02-12 08:46:03 --> Config Class Initialized
INFO - 2018-02-12 08:46:03 --> Loader Class Initialized
INFO - 2018-02-12 14:16:03 --> Helper loaded: url_helper
INFO - 2018-02-12 14:16:03 --> Helper loaded: notification_helper
INFO - 2018-02-12 14:16:03 --> Helper loaded: settings_helper
INFO - 2018-02-12 14:16:03 --> Helper loaded: permission_helper
INFO - 2018-02-12 14:16:03 --> Helper loaded: users_helper
INFO - 2018-02-12 14:16:03 --> Database Driver Class Initialized
DEBUG - 2018-02-12 14:16:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 14:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 14:16:03 --> Helper loaded: form_helper
INFO - 2018-02-12 14:16:03 --> Form Validation Class Initialized
INFO - 2018-02-12 14:16:03 --> Controller Class Initialized
INFO - 2018-02-12 14:16:03 --> Model Class Initialized
INFO - 2018-02-12 14:16:03 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 14:16:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 14:16:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 14:16:03 --> Model Class Initialized
INFO - 2018-02-12 14:16:03 --> Model Class Initialized
INFO - 2018-02-12 14:16:03 --> Model Class Initialized
INFO - 2018-02-12 14:16:03 --> Model Class Initialized
INFO - 2018-02-12 14:16:03 --> Model Class Initialized
INFO - 2018-02-12 14:16:03 --> Model Class Initialized
INFO - 2018-02-12 14:16:03 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 14:16:03 --> Model Class Initialized
INFO - 2018-02-12 14:16:03 --> Final output sent to browser
DEBUG - 2018-02-12 14:16:03 --> Total execution time: 0.1125
INFO - 2018-02-12 08:46:05 --> Config Class Initialized
INFO - 2018-02-12 08:46:05 --> Hooks Class Initialized
DEBUG - 2018-02-12 08:46:05 --> UTF-8 Support Enabled
INFO - 2018-02-12 08:46:05 --> Utf8 Class Initialized
INFO - 2018-02-12 08:46:05 --> URI Class Initialized
INFO - 2018-02-12 08:46:05 --> Router Class Initialized
INFO - 2018-02-12 08:46:05 --> Output Class Initialized
INFO - 2018-02-12 08:46:05 --> Security Class Initialized
DEBUG - 2018-02-12 08:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 08:46:05 --> Input Class Initialized
INFO - 2018-02-12 08:46:05 --> Language Class Initialized
INFO - 2018-02-12 08:46:05 --> Language Class Initialized
INFO - 2018-02-12 08:46:05 --> Config Class Initialized
INFO - 2018-02-12 08:46:05 --> Loader Class Initialized
INFO - 2018-02-12 14:16:05 --> Helper loaded: url_helper
INFO - 2018-02-12 14:16:05 --> Helper loaded: notification_helper
INFO - 2018-02-12 14:16:05 --> Helper loaded: settings_helper
INFO - 2018-02-12 14:16:05 --> Helper loaded: permission_helper
INFO - 2018-02-12 14:16:05 --> Helper loaded: users_helper
INFO - 2018-02-12 14:16:05 --> Database Driver Class Initialized
DEBUG - 2018-02-12 14:16:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 14:16:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 14:16:05 --> Helper loaded: form_helper
INFO - 2018-02-12 14:16:05 --> Form Validation Class Initialized
INFO - 2018-02-12 14:16:05 --> Controller Class Initialized
INFO - 2018-02-12 14:16:05 --> Model Class Initialized
INFO - 2018-02-12 14:16:05 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 14:16:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 14:16:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 14:16:05 --> Model Class Initialized
INFO - 2018-02-12 14:16:05 --> Model Class Initialized
INFO - 2018-02-12 14:16:05 --> Model Class Initialized
INFO - 2018-02-12 14:16:05 --> Model Class Initialized
INFO - 2018-02-12 14:16:05 --> Model Class Initialized
INFO - 2018-02-12 14:16:05 --> Model Class Initialized
INFO - 2018-02-12 14:16:05 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 14:16:05 --> Model Class Initialized
INFO - 2018-02-12 14:16:05 --> Final output sent to browser
DEBUG - 2018-02-12 14:16:05 --> Total execution time: 0.0951
INFO - 2018-02-12 08:46:09 --> Config Class Initialized
INFO - 2018-02-12 08:46:09 --> Hooks Class Initialized
DEBUG - 2018-02-12 08:46:09 --> UTF-8 Support Enabled
INFO - 2018-02-12 08:46:09 --> Utf8 Class Initialized
INFO - 2018-02-12 08:46:09 --> URI Class Initialized
INFO - 2018-02-12 08:46:09 --> Router Class Initialized
INFO - 2018-02-12 08:46:09 --> Output Class Initialized
INFO - 2018-02-12 08:46:09 --> Security Class Initialized
DEBUG - 2018-02-12 08:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 08:46:09 --> Input Class Initialized
INFO - 2018-02-12 08:46:09 --> Language Class Initialized
INFO - 2018-02-12 08:46:09 --> Language Class Initialized
INFO - 2018-02-12 08:46:09 --> Config Class Initialized
INFO - 2018-02-12 08:46:09 --> Loader Class Initialized
INFO - 2018-02-12 14:16:09 --> Helper loaded: url_helper
INFO - 2018-02-12 14:16:09 --> Helper loaded: notification_helper
INFO - 2018-02-12 14:16:09 --> Helper loaded: settings_helper
INFO - 2018-02-12 14:16:09 --> Helper loaded: permission_helper
INFO - 2018-02-12 14:16:09 --> Helper loaded: users_helper
INFO - 2018-02-12 14:16:09 --> Database Driver Class Initialized
DEBUG - 2018-02-12 14:16:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 14:16:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 14:16:09 --> Helper loaded: form_helper
INFO - 2018-02-12 14:16:09 --> Form Validation Class Initialized
INFO - 2018-02-12 14:16:09 --> Controller Class Initialized
INFO - 2018-02-12 14:16:09 --> Model Class Initialized
INFO - 2018-02-12 14:16:09 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 14:16:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 14:16:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 14:16:09 --> Model Class Initialized
INFO - 2018-02-12 14:16:09 --> Model Class Initialized
INFO - 2018-02-12 14:16:09 --> Model Class Initialized
INFO - 2018-02-12 14:16:09 --> Model Class Initialized
INFO - 2018-02-12 14:16:09 --> Model Class Initialized
INFO - 2018-02-12 14:16:09 --> Model Class Initialized
INFO - 2018-02-12 14:16:09 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 14:16:09 --> Model Class Initialized
INFO - 2018-02-12 14:16:09 --> Final output sent to browser
DEBUG - 2018-02-12 14:16:09 --> Total execution time: 0.1081
INFO - 2018-02-12 08:46:16 --> Config Class Initialized
INFO - 2018-02-12 08:46:16 --> Hooks Class Initialized
DEBUG - 2018-02-12 08:46:16 --> UTF-8 Support Enabled
INFO - 2018-02-12 08:46:16 --> Utf8 Class Initialized
INFO - 2018-02-12 08:46:16 --> URI Class Initialized
INFO - 2018-02-12 08:46:16 --> Router Class Initialized
INFO - 2018-02-12 08:46:16 --> Output Class Initialized
INFO - 2018-02-12 08:46:16 --> Security Class Initialized
DEBUG - 2018-02-12 08:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 08:46:16 --> Input Class Initialized
INFO - 2018-02-12 08:46:16 --> Language Class Initialized
INFO - 2018-02-12 08:46:16 --> Language Class Initialized
INFO - 2018-02-12 08:46:16 --> Config Class Initialized
INFO - 2018-02-12 08:46:16 --> Loader Class Initialized
INFO - 2018-02-12 14:16:16 --> Helper loaded: url_helper
INFO - 2018-02-12 14:16:16 --> Helper loaded: notification_helper
INFO - 2018-02-12 14:16:16 --> Helper loaded: settings_helper
INFO - 2018-02-12 14:16:16 --> Helper loaded: permission_helper
INFO - 2018-02-12 14:16:16 --> Helper loaded: users_helper
INFO - 2018-02-12 14:16:16 --> Database Driver Class Initialized
DEBUG - 2018-02-12 14:16:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 14:16:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 14:16:16 --> Helper loaded: form_helper
INFO - 2018-02-12 14:16:16 --> Form Validation Class Initialized
INFO - 2018-02-12 14:16:16 --> Controller Class Initialized
INFO - 2018-02-12 14:16:16 --> Model Class Initialized
INFO - 2018-02-12 14:16:16 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 14:16:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 14:16:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 14:16:16 --> Model Class Initialized
INFO - 2018-02-12 14:16:16 --> Model Class Initialized
INFO - 2018-02-12 14:16:16 --> Model Class Initialized
INFO - 2018-02-12 14:16:16 --> Model Class Initialized
INFO - 2018-02-12 14:16:16 --> Model Class Initialized
INFO - 2018-02-12 14:16:16 --> Model Class Initialized
INFO - 2018-02-12 14:16:16 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 14:16:16 --> Final output sent to browser
DEBUG - 2018-02-12 14:16:16 --> Total execution time: 0.1298
INFO - 2018-02-12 08:46:19 --> Config Class Initialized
INFO - 2018-02-12 08:46:19 --> Hooks Class Initialized
DEBUG - 2018-02-12 08:46:19 --> UTF-8 Support Enabled
INFO - 2018-02-12 08:46:19 --> Utf8 Class Initialized
INFO - 2018-02-12 08:46:19 --> URI Class Initialized
INFO - 2018-02-12 08:46:19 --> Router Class Initialized
INFO - 2018-02-12 08:46:19 --> Output Class Initialized
INFO - 2018-02-12 08:46:19 --> Security Class Initialized
DEBUG - 2018-02-12 08:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 08:46:19 --> Input Class Initialized
INFO - 2018-02-12 08:46:19 --> Language Class Initialized
INFO - 2018-02-12 08:46:19 --> Language Class Initialized
INFO - 2018-02-12 08:46:19 --> Config Class Initialized
INFO - 2018-02-12 08:46:19 --> Loader Class Initialized
INFO - 2018-02-12 14:16:19 --> Helper loaded: url_helper
INFO - 2018-02-12 14:16:19 --> Helper loaded: notification_helper
INFO - 2018-02-12 14:16:19 --> Helper loaded: settings_helper
INFO - 2018-02-12 14:16:19 --> Helper loaded: permission_helper
INFO - 2018-02-12 14:16:19 --> Helper loaded: users_helper
INFO - 2018-02-12 14:16:19 --> Database Driver Class Initialized
DEBUG - 2018-02-12 14:16:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 14:16:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 14:16:19 --> Helper loaded: form_helper
INFO - 2018-02-12 14:16:19 --> Form Validation Class Initialized
INFO - 2018-02-12 14:16:19 --> Controller Class Initialized
INFO - 2018-02-12 14:16:19 --> Model Class Initialized
INFO - 2018-02-12 14:16:19 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 14:16:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 14:16:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 14:16:19 --> Model Class Initialized
INFO - 2018-02-12 14:16:19 --> Model Class Initialized
INFO - 2018-02-12 14:16:19 --> Model Class Initialized
INFO - 2018-02-12 14:16:19 --> Model Class Initialized
INFO - 2018-02-12 14:16:19 --> Model Class Initialized
INFO - 2018-02-12 14:16:19 --> Model Class Initialized
INFO - 2018-02-12 14:16:19 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 14:16:19 --> Final output sent to browser
DEBUG - 2018-02-12 14:16:19 --> Total execution time: 0.1107
INFO - 2018-02-12 08:46:23 --> Config Class Initialized
INFO - 2018-02-12 08:46:23 --> Hooks Class Initialized
DEBUG - 2018-02-12 08:46:23 --> UTF-8 Support Enabled
INFO - 2018-02-12 08:46:23 --> Utf8 Class Initialized
INFO - 2018-02-12 08:46:23 --> URI Class Initialized
INFO - 2018-02-12 08:46:23 --> Router Class Initialized
INFO - 2018-02-12 08:46:23 --> Output Class Initialized
INFO - 2018-02-12 08:46:23 --> Security Class Initialized
DEBUG - 2018-02-12 08:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 08:46:23 --> Input Class Initialized
INFO - 2018-02-12 08:46:23 --> Language Class Initialized
INFO - 2018-02-12 08:46:23 --> Language Class Initialized
INFO - 2018-02-12 08:46:23 --> Config Class Initialized
INFO - 2018-02-12 08:46:23 --> Loader Class Initialized
INFO - 2018-02-12 14:16:23 --> Helper loaded: url_helper
INFO - 2018-02-12 14:16:23 --> Helper loaded: notification_helper
INFO - 2018-02-12 14:16:23 --> Helper loaded: settings_helper
INFO - 2018-02-12 14:16:23 --> Helper loaded: permission_helper
INFO - 2018-02-12 14:16:23 --> Helper loaded: users_helper
INFO - 2018-02-12 14:16:23 --> Database Driver Class Initialized
DEBUG - 2018-02-12 14:16:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 14:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 14:16:23 --> Helper loaded: form_helper
INFO - 2018-02-12 14:16:23 --> Form Validation Class Initialized
INFO - 2018-02-12 14:16:23 --> Controller Class Initialized
INFO - 2018-02-12 14:16:23 --> Model Class Initialized
INFO - 2018-02-12 14:16:23 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 14:16:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 14:16:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 14:16:23 --> Model Class Initialized
INFO - 2018-02-12 14:16:23 --> Model Class Initialized
INFO - 2018-02-12 14:16:23 --> Model Class Initialized
INFO - 2018-02-12 14:16:23 --> Model Class Initialized
INFO - 2018-02-12 14:16:23 --> Model Class Initialized
INFO - 2018-02-12 14:16:23 --> Model Class Initialized
INFO - 2018-02-12 14:16:23 --> Model Class Initialized
INFO - 2018-02-12 14:16:23 --> Model Class Initialized
INFO - 2018-02-12 14:16:23 --> Model Class Initialized
INFO - 2018-02-12 14:16:23 --> Model Class Initialized
INFO - 2018-02-12 14:16:23 --> Model Class Initialized
INFO - 2018-02-12 14:16:23 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 14:16:23 --> Model Class Initialized
INFO - 2018-02-12 14:16:23 --> Final output sent to browser
DEBUG - 2018-02-12 14:16:23 --> Total execution time: 0.1306
INFO - 2018-02-12 08:46:25 --> Config Class Initialized
INFO - 2018-02-12 08:46:25 --> Hooks Class Initialized
DEBUG - 2018-02-12 08:46:25 --> UTF-8 Support Enabled
INFO - 2018-02-12 08:46:25 --> Utf8 Class Initialized
INFO - 2018-02-12 08:46:25 --> URI Class Initialized
INFO - 2018-02-12 08:46:25 --> Router Class Initialized
INFO - 2018-02-12 08:46:25 --> Output Class Initialized
INFO - 2018-02-12 08:46:25 --> Security Class Initialized
DEBUG - 2018-02-12 08:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 08:46:25 --> Input Class Initialized
INFO - 2018-02-12 08:46:25 --> Language Class Initialized
INFO - 2018-02-12 08:46:25 --> Language Class Initialized
INFO - 2018-02-12 08:46:25 --> Config Class Initialized
INFO - 2018-02-12 08:46:25 --> Loader Class Initialized
INFO - 2018-02-12 14:16:25 --> Helper loaded: url_helper
INFO - 2018-02-12 14:16:25 --> Helper loaded: notification_helper
INFO - 2018-02-12 14:16:25 --> Helper loaded: settings_helper
INFO - 2018-02-12 14:16:25 --> Helper loaded: permission_helper
INFO - 2018-02-12 14:16:25 --> Helper loaded: users_helper
INFO - 2018-02-12 14:16:25 --> Database Driver Class Initialized
DEBUG - 2018-02-12 14:16:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 14:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 14:16:25 --> Helper loaded: form_helper
INFO - 2018-02-12 14:16:25 --> Form Validation Class Initialized
INFO - 2018-02-12 14:16:25 --> Controller Class Initialized
INFO - 2018-02-12 14:16:25 --> Model Class Initialized
INFO - 2018-02-12 14:16:25 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 14:16:25 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 14:16:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 14:16:25 --> Model Class Initialized
INFO - 2018-02-12 14:16:25 --> Model Class Initialized
INFO - 2018-02-12 14:16:25 --> Model Class Initialized
INFO - 2018-02-12 14:16:25 --> Model Class Initialized
INFO - 2018-02-12 14:16:25 --> Model Class Initialized
INFO - 2018-02-12 14:16:25 --> Model Class Initialized
INFO - 2018-02-12 14:16:25 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-02-12 14:16:25 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 771
INFO - 2018-02-12 14:16:25 --> Final output sent to browser
DEBUG - 2018-02-12 14:16:25 --> Total execution time: 0.1111
INFO - 2018-02-12 08:46:34 --> Config Class Initialized
INFO - 2018-02-12 08:46:34 --> Hooks Class Initialized
DEBUG - 2018-02-12 08:46:34 --> UTF-8 Support Enabled
INFO - 2018-02-12 08:46:34 --> Utf8 Class Initialized
INFO - 2018-02-12 08:46:34 --> URI Class Initialized
INFO - 2018-02-12 08:46:34 --> Router Class Initialized
INFO - 2018-02-12 08:46:34 --> Output Class Initialized
INFO - 2018-02-12 08:46:34 --> Security Class Initialized
DEBUG - 2018-02-12 08:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 08:46:34 --> Input Class Initialized
INFO - 2018-02-12 08:46:34 --> Language Class Initialized
INFO - 2018-02-12 08:46:34 --> Language Class Initialized
INFO - 2018-02-12 08:46:34 --> Config Class Initialized
INFO - 2018-02-12 08:46:34 --> Loader Class Initialized
INFO - 2018-02-12 14:16:34 --> Helper loaded: url_helper
INFO - 2018-02-12 14:16:34 --> Helper loaded: notification_helper
INFO - 2018-02-12 14:16:34 --> Helper loaded: settings_helper
INFO - 2018-02-12 14:16:34 --> Helper loaded: permission_helper
INFO - 2018-02-12 14:16:34 --> Helper loaded: users_helper
INFO - 2018-02-12 14:16:34 --> Database Driver Class Initialized
DEBUG - 2018-02-12 14:16:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 14:16:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 14:16:34 --> Helper loaded: form_helper
INFO - 2018-02-12 14:16:34 --> Form Validation Class Initialized
INFO - 2018-02-12 14:16:34 --> Controller Class Initialized
INFO - 2018-02-12 14:16:34 --> Model Class Initialized
INFO - 2018-02-12 14:16:34 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 14:16:34 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 14:16:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 14:16:34 --> Model Class Initialized
INFO - 2018-02-12 14:16:34 --> Model Class Initialized
INFO - 2018-02-12 14:16:34 --> Model Class Initialized
INFO - 2018-02-12 14:16:34 --> Model Class Initialized
INFO - 2018-02-12 14:16:34 --> Model Class Initialized
INFO - 2018-02-12 14:16:34 --> Model Class Initialized
INFO - 2018-02-12 14:16:34 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 14:16:34 --> Model Class Initialized
INFO - 2018-02-12 14:16:34 --> Final output sent to browser
DEBUG - 2018-02-12 14:16:34 --> Total execution time: 0.1189
INFO - 2018-02-12 08:46:39 --> Config Class Initialized
INFO - 2018-02-12 08:46:39 --> Hooks Class Initialized
DEBUG - 2018-02-12 08:46:39 --> UTF-8 Support Enabled
INFO - 2018-02-12 08:46:39 --> Utf8 Class Initialized
INFO - 2018-02-12 08:46:39 --> URI Class Initialized
INFO - 2018-02-12 08:46:39 --> Router Class Initialized
INFO - 2018-02-12 08:46:39 --> Output Class Initialized
INFO - 2018-02-12 08:46:39 --> Security Class Initialized
DEBUG - 2018-02-12 08:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 08:46:39 --> Input Class Initialized
INFO - 2018-02-12 08:46:39 --> Language Class Initialized
INFO - 2018-02-12 08:46:39 --> Language Class Initialized
INFO - 2018-02-12 08:46:39 --> Config Class Initialized
INFO - 2018-02-12 08:46:39 --> Loader Class Initialized
INFO - 2018-02-12 14:16:40 --> Helper loaded: url_helper
INFO - 2018-02-12 14:16:40 --> Helper loaded: notification_helper
INFO - 2018-02-12 14:16:40 --> Helper loaded: settings_helper
INFO - 2018-02-12 14:16:40 --> Helper loaded: permission_helper
INFO - 2018-02-12 14:16:40 --> Helper loaded: users_helper
INFO - 2018-02-12 14:16:40 --> Database Driver Class Initialized
DEBUG - 2018-02-12 14:16:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 14:16:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 14:16:40 --> Helper loaded: form_helper
INFO - 2018-02-12 14:16:40 --> Form Validation Class Initialized
INFO - 2018-02-12 14:16:40 --> Controller Class Initialized
INFO - 2018-02-12 14:16:40 --> Model Class Initialized
INFO - 2018-02-12 14:16:40 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 14:16:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 14:16:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 14:16:40 --> Model Class Initialized
INFO - 2018-02-12 14:16:40 --> Model Class Initialized
INFO - 2018-02-12 14:16:40 --> Model Class Initialized
INFO - 2018-02-12 14:16:40 --> Model Class Initialized
INFO - 2018-02-12 14:16:40 --> Model Class Initialized
INFO - 2018-02-12 14:16:40 --> Model Class Initialized
INFO - 2018-02-12 14:16:40 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 14:16:40 --> Final output sent to browser
DEBUG - 2018-02-12 14:16:40 --> Total execution time: 0.1065
INFO - 2018-02-12 08:46:42 --> Config Class Initialized
INFO - 2018-02-12 08:46:42 --> Hooks Class Initialized
DEBUG - 2018-02-12 08:46:42 --> UTF-8 Support Enabled
INFO - 2018-02-12 08:46:42 --> Utf8 Class Initialized
INFO - 2018-02-12 08:46:42 --> URI Class Initialized
INFO - 2018-02-12 08:46:42 --> Router Class Initialized
INFO - 2018-02-12 08:46:42 --> Output Class Initialized
INFO - 2018-02-12 08:46:42 --> Security Class Initialized
DEBUG - 2018-02-12 08:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 08:46:42 --> Input Class Initialized
INFO - 2018-02-12 08:46:42 --> Language Class Initialized
INFO - 2018-02-12 08:46:42 --> Language Class Initialized
INFO - 2018-02-12 08:46:42 --> Config Class Initialized
INFO - 2018-02-12 08:46:42 --> Loader Class Initialized
INFO - 2018-02-12 14:16:42 --> Helper loaded: url_helper
INFO - 2018-02-12 14:16:42 --> Helper loaded: notification_helper
INFO - 2018-02-12 14:16:42 --> Helper loaded: settings_helper
INFO - 2018-02-12 14:16:42 --> Helper loaded: permission_helper
INFO - 2018-02-12 14:16:42 --> Helper loaded: users_helper
INFO - 2018-02-12 14:16:42 --> Database Driver Class Initialized
DEBUG - 2018-02-12 14:16:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 14:16:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 14:16:42 --> Helper loaded: form_helper
INFO - 2018-02-12 14:16:42 --> Form Validation Class Initialized
INFO - 2018-02-12 14:16:42 --> Controller Class Initialized
INFO - 2018-02-12 14:16:42 --> Model Class Initialized
INFO - 2018-02-12 14:16:42 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 14:16:42 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 14:16:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 14:16:42 --> Model Class Initialized
INFO - 2018-02-12 14:16:42 --> Model Class Initialized
INFO - 2018-02-12 14:16:42 --> Model Class Initialized
INFO - 2018-02-12 14:16:42 --> Model Class Initialized
INFO - 2018-02-12 14:16:42 --> Model Class Initialized
INFO - 2018-02-12 14:16:42 --> Model Class Initialized
INFO - 2018-02-12 14:16:42 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 14:16:42 --> Model Class Initialized
INFO - 2018-02-12 14:16:42 --> Final output sent to browser
DEBUG - 2018-02-12 14:16:42 --> Total execution time: 0.0919
INFO - 2018-02-12 08:48:20 --> Config Class Initialized
INFO - 2018-02-12 08:48:20 --> Hooks Class Initialized
DEBUG - 2018-02-12 08:48:20 --> UTF-8 Support Enabled
INFO - 2018-02-12 08:48:20 --> Utf8 Class Initialized
INFO - 2018-02-12 08:48:20 --> URI Class Initialized
INFO - 2018-02-12 08:48:20 --> Router Class Initialized
INFO - 2018-02-12 08:48:20 --> Output Class Initialized
INFO - 2018-02-12 08:48:20 --> Security Class Initialized
DEBUG - 2018-02-12 08:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 08:48:20 --> Input Class Initialized
INFO - 2018-02-12 08:48:20 --> Language Class Initialized
INFO - 2018-02-12 08:48:20 --> Language Class Initialized
INFO - 2018-02-12 08:48:20 --> Config Class Initialized
INFO - 2018-02-12 08:48:20 --> Loader Class Initialized
INFO - 2018-02-12 14:18:20 --> Helper loaded: url_helper
INFO - 2018-02-12 14:18:20 --> Helper loaded: notification_helper
INFO - 2018-02-12 14:18:20 --> Helper loaded: settings_helper
INFO - 2018-02-12 14:18:20 --> Helper loaded: permission_helper
INFO - 2018-02-12 14:18:20 --> Helper loaded: users_helper
INFO - 2018-02-12 14:18:20 --> Database Driver Class Initialized
DEBUG - 2018-02-12 14:18:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 14:18:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 08:48:20 --> Config Class Initialized
INFO - 2018-02-12 08:48:20 --> Hooks Class Initialized
INFO - 2018-02-12 14:18:20 --> Helper loaded: form_helper
INFO - 2018-02-12 14:18:20 --> Form Validation Class Initialized
INFO - 2018-02-12 14:18:20 --> Controller Class Initialized
DEBUG - 2018-02-12 08:48:20 --> UTF-8 Support Enabled
INFO - 2018-02-12 08:48:20 --> Utf8 Class Initialized
INFO - 2018-02-12 08:48:20 --> URI Class Initialized
INFO - 2018-02-12 08:48:20 --> Router Class Initialized
INFO - 2018-02-12 08:48:20 --> Output Class Initialized
INFO - 2018-02-12 14:18:20 --> Model Class Initialized
INFO - 2018-02-12 14:18:20 --> Helper loaded: inflector_helper
INFO - 2018-02-12 08:48:20 --> Security Class Initialized
DEBUG - 2018-02-12 14:18:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-02-12 08:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 08:48:20 --> Input Class Initialized
INFO - 2018-02-12 08:48:20 --> Language Class Initialized
INFO - 2018-02-12 14:18:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 14:18:20 --> Model Class Initialized
INFO - 2018-02-12 14:18:20 --> Model Class Initialized
INFO - 2018-02-12 14:18:20 --> Model Class Initialized
INFO - 2018-02-12 14:18:20 --> Model Class Initialized
INFO - 2018-02-12 14:18:20 --> Model Class Initialized
INFO - 2018-02-12 14:18:20 --> Model Class Initialized
INFO - 2018-02-12 14:18:20 --> Model Class Initialized
INFO - 2018-02-12 14:18:20 --> Model Class Initialized
INFO - 2018-02-12 14:18:20 --> Model Class Initialized
INFO - 2018-02-12 14:18:20 --> Model Class Initialized
INFO - 2018-02-12 14:18:20 --> Model Class Initialized
INFO - 2018-02-12 14:18:20 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 14:18:20 --> Model Class Initialized
INFO - 2018-02-12 08:48:20 --> Language Class Initialized
INFO - 2018-02-12 08:48:20 --> Config Class Initialized
INFO - 2018-02-12 08:48:20 --> Loader Class Initialized
INFO - 2018-02-12 14:18:20 --> Helper loaded: url_helper
INFO - 2018-02-12 14:18:20 --> Helper loaded: notification_helper
INFO - 2018-02-12 14:18:20 --> Final output sent to browser
DEBUG - 2018-02-12 14:18:20 --> Total execution time: 0.1095
INFO - 2018-02-12 14:18:20 --> Helper loaded: settings_helper
INFO - 2018-02-12 14:18:20 --> Helper loaded: permission_helper
INFO - 2018-02-12 14:18:20 --> Helper loaded: users_helper
INFO - 2018-02-12 14:18:20 --> Database Driver Class Initialized
DEBUG - 2018-02-12 14:18:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 14:18:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 14:18:20 --> Helper loaded: form_helper
INFO - 2018-02-12 14:18:20 --> Form Validation Class Initialized
INFO - 2018-02-12 14:18:20 --> Controller Class Initialized
INFO - 2018-02-12 14:18:20 --> Model Class Initialized
INFO - 2018-02-12 14:18:20 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 14:18:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 14:18:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 14:18:20 --> Model Class Initialized
INFO - 2018-02-12 14:18:20 --> Model Class Initialized
INFO - 2018-02-12 14:18:20 --> Model Class Initialized
INFO - 2018-02-12 14:18:20 --> Model Class Initialized
INFO - 2018-02-12 14:18:20 --> Model Class Initialized
INFO - 2018-02-12 14:18:20 --> Model Class Initialized
INFO - 2018-02-12 14:18:20 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 14:18:20 --> Model Class Initialized
INFO - 2018-02-12 14:18:20 --> Final output sent to browser
DEBUG - 2018-02-12 14:18:20 --> Total execution time: 0.1116
INFO - 2018-02-12 08:50:45 --> Config Class Initialized
INFO - 2018-02-12 08:50:45 --> Hooks Class Initialized
INFO - 2018-02-12 08:50:45 --> Config Class Initialized
INFO - 2018-02-12 08:50:45 --> Hooks Class Initialized
DEBUG - 2018-02-12 08:50:45 --> UTF-8 Support Enabled
INFO - 2018-02-12 08:50:45 --> Utf8 Class Initialized
DEBUG - 2018-02-12 08:50:45 --> UTF-8 Support Enabled
INFO - 2018-02-12 08:50:45 --> Utf8 Class Initialized
INFO - 2018-02-12 08:50:45 --> URI Class Initialized
INFO - 2018-02-12 08:50:45 --> URI Class Initialized
INFO - 2018-02-12 08:50:45 --> Router Class Initialized
INFO - 2018-02-12 08:50:45 --> Router Class Initialized
INFO - 2018-02-12 08:50:45 --> Output Class Initialized
INFO - 2018-02-12 08:50:45 --> Output Class Initialized
INFO - 2018-02-12 08:50:45 --> Security Class Initialized
INFO - 2018-02-12 08:50:45 --> Security Class Initialized
DEBUG - 2018-02-12 08:50:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-12 08:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 08:50:45 --> Input Class Initialized
INFO - 2018-02-12 08:50:45 --> Input Class Initialized
INFO - 2018-02-12 08:50:45 --> Language Class Initialized
INFO - 2018-02-12 08:50:45 --> Language Class Initialized
INFO - 2018-02-12 08:50:45 --> Language Class Initialized
INFO - 2018-02-12 08:50:45 --> Config Class Initialized
INFO - 2018-02-12 08:50:45 --> Loader Class Initialized
INFO - 2018-02-12 08:50:45 --> Language Class Initialized
INFO - 2018-02-12 08:50:45 --> Config Class Initialized
INFO - 2018-02-12 08:50:45 --> Loader Class Initialized
INFO - 2018-02-12 14:20:45 --> Helper loaded: url_helper
INFO - 2018-02-12 14:20:45 --> Helper loaded: notification_helper
INFO - 2018-02-12 14:20:45 --> Helper loaded: settings_helper
INFO - 2018-02-12 14:20:45 --> Helper loaded: url_helper
INFO - 2018-02-12 14:20:45 --> Helper loaded: permission_helper
INFO - 2018-02-12 14:20:45 --> Helper loaded: notification_helper
INFO - 2018-02-12 14:20:45 --> Helper loaded: users_helper
INFO - 2018-02-12 14:20:45 --> Helper loaded: settings_helper
INFO - 2018-02-12 14:20:45 --> Helper loaded: permission_helper
INFO - 2018-02-12 14:20:45 --> Helper loaded: users_helper
INFO - 2018-02-12 14:20:45 --> Database Driver Class Initialized
INFO - 2018-02-12 14:20:45 --> Database Driver Class Initialized
DEBUG - 2018-02-12 14:20:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 14:20:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-12 14:20:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 14:20:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 14:20:45 --> Helper loaded: form_helper
INFO - 2018-02-12 14:20:45 --> Form Validation Class Initialized
INFO - 2018-02-12 14:20:45 --> Controller Class Initialized
INFO - 2018-02-12 14:20:45 --> Helper loaded: form_helper
INFO - 2018-02-12 14:20:45 --> Form Validation Class Initialized
INFO - 2018-02-12 14:20:45 --> Controller Class Initialized
INFO - 2018-02-12 14:20:45 --> Model Class Initialized
INFO - 2018-02-12 14:20:45 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 14:20:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 14:20:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 14:20:45 --> Model Class Initialized
INFO - 2018-02-12 14:20:45 --> Model Class Initialized
INFO - 2018-02-12 14:20:45 --> Model Class Initialized
INFO - 2018-02-12 14:20:45 --> Helper loaded: inflector_helper
INFO - 2018-02-12 14:20:45 --> Model Class Initialized
INFO - 2018-02-12 14:20:45 --> Model Class Initialized
INFO - 2018-02-12 14:20:45 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-02-12 14:20:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 14:20:45 --> Final output sent to browser
DEBUG - 2018-02-12 14:20:45 --> Total execution time: 0.1082
INFO - 2018-02-12 14:20:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 14:20:45 --> Model Class Initialized
INFO - 2018-02-12 14:20:45 --> Model Class Initialized
INFO - 2018-02-12 14:20:45 --> Model Class Initialized
INFO - 2018-02-12 14:20:45 --> Model Class Initialized
INFO - 2018-02-12 14:20:45 --> Model Class Initialized
INFO - 2018-02-12 14:20:45 --> Model Class Initialized
INFO - 2018-02-12 14:20:45 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 14:20:45 --> Final output sent to browser
DEBUG - 2018-02-12 14:20:45 --> Total execution time: 0.1159
INFO - 2018-02-12 08:55:09 --> Config Class Initialized
INFO - 2018-02-12 08:55:09 --> Hooks Class Initialized
DEBUG - 2018-02-12 08:55:09 --> UTF-8 Support Enabled
INFO - 2018-02-12 08:55:09 --> Utf8 Class Initialized
INFO - 2018-02-12 08:55:09 --> URI Class Initialized
INFO - 2018-02-12 08:55:09 --> Router Class Initialized
INFO - 2018-02-12 08:55:09 --> Output Class Initialized
INFO - 2018-02-12 08:55:09 --> Security Class Initialized
DEBUG - 2018-02-12 08:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 08:55:09 --> Input Class Initialized
INFO - 2018-02-12 08:55:09 --> Language Class Initialized
INFO - 2018-02-12 08:55:09 --> Language Class Initialized
INFO - 2018-02-12 08:55:09 --> Config Class Initialized
INFO - 2018-02-12 08:55:09 --> Loader Class Initialized
INFO - 2018-02-12 14:25:09 --> Helper loaded: url_helper
INFO - 2018-02-12 14:25:09 --> Helper loaded: notification_helper
INFO - 2018-02-12 14:25:09 --> Helper loaded: settings_helper
INFO - 2018-02-12 14:25:09 --> Helper loaded: permission_helper
INFO - 2018-02-12 14:25:09 --> Helper loaded: users_helper
INFO - 2018-02-12 14:25:09 --> Database Driver Class Initialized
DEBUG - 2018-02-12 14:25:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 14:25:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 14:25:09 --> Helper loaded: form_helper
INFO - 2018-02-12 14:25:09 --> Form Validation Class Initialized
INFO - 2018-02-12 14:25:09 --> Controller Class Initialized
INFO - 2018-02-12 14:25:09 --> Model Class Initialized
INFO - 2018-02-12 14:25:09 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 14:25:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 14:25:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 14:25:09 --> Model Class Initialized
INFO - 2018-02-12 14:25:09 --> Model Class Initialized
INFO - 2018-02-12 14:25:09 --> Model Class Initialized
INFO - 2018-02-12 14:25:09 --> Model Class Initialized
INFO - 2018-02-12 14:25:09 --> Model Class Initialized
INFO - 2018-02-12 14:25:09 --> Model Class Initialized
INFO - 2018-02-12 14:25:09 --> Model Class Initialized
INFO - 2018-02-12 14:25:09 --> Model Class Initialized
INFO - 2018-02-12 14:25:09 --> Model Class Initialized
INFO - 2018-02-12 14:25:09 --> Model Class Initialized
INFO - 2018-02-12 14:25:09 --> Model Class Initialized
INFO - 2018-02-12 14:25:09 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 14:25:09 --> Model Class Initialized
INFO - 2018-02-12 14:25:09 --> Final output sent to browser
DEBUG - 2018-02-12 14:25:09 --> Total execution time: 0.1337
INFO - 2018-02-12 08:55:09 --> Config Class Initialized
INFO - 2018-02-12 08:55:09 --> Hooks Class Initialized
DEBUG - 2018-02-12 08:55:09 --> UTF-8 Support Enabled
INFO - 2018-02-12 08:55:09 --> Utf8 Class Initialized
INFO - 2018-02-12 08:55:09 --> URI Class Initialized
INFO - 2018-02-12 08:55:09 --> Router Class Initialized
INFO - 2018-02-12 08:55:09 --> Output Class Initialized
INFO - 2018-02-12 08:55:09 --> Security Class Initialized
DEBUG - 2018-02-12 08:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 08:55:09 --> Input Class Initialized
INFO - 2018-02-12 08:55:09 --> Language Class Initialized
INFO - 2018-02-12 08:55:09 --> Language Class Initialized
INFO - 2018-02-12 08:55:09 --> Config Class Initialized
INFO - 2018-02-12 08:55:09 --> Loader Class Initialized
INFO - 2018-02-12 14:25:09 --> Helper loaded: url_helper
INFO - 2018-02-12 14:25:09 --> Helper loaded: notification_helper
INFO - 2018-02-12 14:25:09 --> Helper loaded: settings_helper
INFO - 2018-02-12 14:25:09 --> Helper loaded: permission_helper
INFO - 2018-02-12 14:25:09 --> Helper loaded: users_helper
INFO - 2018-02-12 14:25:09 --> Database Driver Class Initialized
DEBUG - 2018-02-12 14:25:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 14:25:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 14:25:09 --> Helper loaded: form_helper
INFO - 2018-02-12 14:25:09 --> Form Validation Class Initialized
INFO - 2018-02-12 14:25:09 --> Controller Class Initialized
INFO - 2018-02-12 14:25:09 --> Model Class Initialized
INFO - 2018-02-12 14:25:09 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 14:25:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 14:25:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 14:25:09 --> Model Class Initialized
INFO - 2018-02-12 14:25:09 --> Model Class Initialized
INFO - 2018-02-12 14:25:09 --> Model Class Initialized
INFO - 2018-02-12 14:25:09 --> Model Class Initialized
INFO - 2018-02-12 14:25:09 --> Model Class Initialized
INFO - 2018-02-12 14:25:09 --> Model Class Initialized
INFO - 2018-02-12 14:25:09 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 14:25:09 --> Model Class Initialized
INFO - 2018-02-12 14:25:09 --> Final output sent to browser
DEBUG - 2018-02-12 14:25:09 --> Total execution time: 0.1027
INFO - 2018-02-12 08:55:14 --> Config Class Initialized
INFO - 2018-02-12 08:55:14 --> Hooks Class Initialized
DEBUG - 2018-02-12 08:55:14 --> UTF-8 Support Enabled
INFO - 2018-02-12 08:55:14 --> Utf8 Class Initialized
INFO - 2018-02-12 08:55:14 --> Config Class Initialized
INFO - 2018-02-12 08:55:14 --> Hooks Class Initialized
INFO - 2018-02-12 08:55:14 --> URI Class Initialized
DEBUG - 2018-02-12 08:55:14 --> UTF-8 Support Enabled
INFO - 2018-02-12 08:55:14 --> Utf8 Class Initialized
INFO - 2018-02-12 08:55:14 --> Router Class Initialized
INFO - 2018-02-12 08:55:14 --> URI Class Initialized
INFO - 2018-02-12 08:55:14 --> Output Class Initialized
INFO - 2018-02-12 08:55:14 --> Router Class Initialized
INFO - 2018-02-12 08:55:14 --> Security Class Initialized
INFO - 2018-02-12 08:55:14 --> Output Class Initialized
DEBUG - 2018-02-12 08:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 08:55:14 --> Input Class Initialized
INFO - 2018-02-12 08:55:14 --> Language Class Initialized
INFO - 2018-02-12 08:55:14 --> Security Class Initialized
DEBUG - 2018-02-12 08:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 08:55:14 --> Input Class Initialized
INFO - 2018-02-12 08:55:14 --> Language Class Initialized
INFO - 2018-02-12 08:55:14 --> Language Class Initialized
INFO - 2018-02-12 08:55:14 --> Config Class Initialized
INFO - 2018-02-12 08:55:14 --> Loader Class Initialized
INFO - 2018-02-12 14:25:14 --> Helper loaded: url_helper
INFO - 2018-02-12 14:25:14 --> Helper loaded: notification_helper
INFO - 2018-02-12 14:25:14 --> Helper loaded: settings_helper
INFO - 2018-02-12 14:25:14 --> Helper loaded: permission_helper
INFO - 2018-02-12 14:25:14 --> Helper loaded: users_helper
INFO - 2018-02-12 08:55:14 --> Language Class Initialized
INFO - 2018-02-12 08:55:14 --> Config Class Initialized
INFO - 2018-02-12 08:55:14 --> Loader Class Initialized
INFO - 2018-02-12 14:25:14 --> Helper loaded: url_helper
INFO - 2018-02-12 14:25:14 --> Helper loaded: notification_helper
INFO - 2018-02-12 14:25:14 --> Helper loaded: settings_helper
INFO - 2018-02-12 14:25:14 --> Helper loaded: permission_helper
INFO - 2018-02-12 14:25:14 --> Helper loaded: users_helper
INFO - 2018-02-12 14:25:14 --> Database Driver Class Initialized
DEBUG - 2018-02-12 14:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 14:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 14:25:14 --> Database Driver Class Initialized
INFO - 2018-02-12 14:25:14 --> Helper loaded: form_helper
INFO - 2018-02-12 14:25:14 --> Form Validation Class Initialized
INFO - 2018-02-12 14:25:14 --> Controller Class Initialized
DEBUG - 2018-02-12 14:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 14:25:14 --> Model Class Initialized
INFO - 2018-02-12 14:25:14 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 14:25:14 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 14:25:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 14:25:14 --> Model Class Initialized
INFO - 2018-02-12 14:25:14 --> Model Class Initialized
INFO - 2018-02-12 14:25:14 --> Model Class Initialized
INFO - 2018-02-12 14:25:14 --> Model Class Initialized
INFO - 2018-02-12 14:25:14 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 14:25:14 --> Final output sent to browser
DEBUG - 2018-02-12 14:25:14 --> Total execution time: 0.1087
INFO - 2018-02-12 14:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 14:25:14 --> Helper loaded: form_helper
INFO - 2018-02-12 14:25:14 --> Form Validation Class Initialized
INFO - 2018-02-12 14:25:14 --> Controller Class Initialized
INFO - 2018-02-12 14:25:14 --> Model Class Initialized
INFO - 2018-02-12 14:25:14 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 14:25:14 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 14:25:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 14:25:14 --> Model Class Initialized
INFO - 2018-02-12 14:25:14 --> Model Class Initialized
INFO - 2018-02-12 14:25:14 --> Model Class Initialized
INFO - 2018-02-12 14:25:14 --> Model Class Initialized
INFO - 2018-02-12 14:25:14 --> Model Class Initialized
INFO - 2018-02-12 14:25:14 --> Model Class Initialized
INFO - 2018-02-12 14:25:14 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 14:25:14 --> Final output sent to browser
DEBUG - 2018-02-12 14:25:14 --> Total execution time: 0.1342
INFO - 2018-02-12 08:55:18 --> Config Class Initialized
INFO - 2018-02-12 08:55:18 --> Hooks Class Initialized
DEBUG - 2018-02-12 08:55:18 --> UTF-8 Support Enabled
INFO - 2018-02-12 08:55:18 --> Utf8 Class Initialized
INFO - 2018-02-12 08:55:18 --> URI Class Initialized
INFO - 2018-02-12 08:55:18 --> Router Class Initialized
INFO - 2018-02-12 08:55:18 --> Output Class Initialized
INFO - 2018-02-12 08:55:18 --> Security Class Initialized
DEBUG - 2018-02-12 08:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 08:55:18 --> Input Class Initialized
INFO - 2018-02-12 08:55:18 --> Language Class Initialized
INFO - 2018-02-12 08:55:18 --> Language Class Initialized
INFO - 2018-02-12 08:55:18 --> Config Class Initialized
INFO - 2018-02-12 08:55:18 --> Loader Class Initialized
INFO - 2018-02-12 14:25:18 --> Helper loaded: url_helper
INFO - 2018-02-12 14:25:18 --> Helper loaded: notification_helper
INFO - 2018-02-12 14:25:18 --> Helper loaded: settings_helper
INFO - 2018-02-12 14:25:18 --> Helper loaded: permission_helper
INFO - 2018-02-12 14:25:18 --> Helper loaded: users_helper
INFO - 2018-02-12 14:25:18 --> Database Driver Class Initialized
DEBUG - 2018-02-12 14:25:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 14:25:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 14:25:18 --> Helper loaded: form_helper
INFO - 2018-02-12 14:25:18 --> Form Validation Class Initialized
INFO - 2018-02-12 14:25:18 --> Controller Class Initialized
INFO - 2018-02-12 14:25:18 --> Model Class Initialized
INFO - 2018-02-12 14:25:18 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 14:25:18 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 14:25:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 14:25:18 --> Model Class Initialized
INFO - 2018-02-12 14:25:18 --> Model Class Initialized
INFO - 2018-02-12 14:25:18 --> Model Class Initialized
INFO - 2018-02-12 14:25:18 --> Model Class Initialized
INFO - 2018-02-12 14:25:18 --> Model Class Initialized
INFO - 2018-02-12 14:25:18 --> Model Class Initialized
INFO - 2018-02-12 14:25:18 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 14:25:18 --> Final output sent to browser
DEBUG - 2018-02-12 14:25:18 --> Total execution time: 0.1170
INFO - 2018-02-12 08:56:48 --> Config Class Initialized
INFO - 2018-02-12 08:56:48 --> Hooks Class Initialized
DEBUG - 2018-02-12 08:56:48 --> UTF-8 Support Enabled
INFO - 2018-02-12 08:56:48 --> Utf8 Class Initialized
INFO - 2018-02-12 08:56:48 --> URI Class Initialized
INFO - 2018-02-12 08:56:48 --> Router Class Initialized
INFO - 2018-02-12 08:56:48 --> Output Class Initialized
INFO - 2018-02-12 08:56:48 --> Security Class Initialized
DEBUG - 2018-02-12 08:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 08:56:48 --> Input Class Initialized
INFO - 2018-02-12 08:56:48 --> Language Class Initialized
INFO - 2018-02-12 08:56:48 --> Language Class Initialized
INFO - 2018-02-12 08:56:48 --> Config Class Initialized
INFO - 2018-02-12 08:56:48 --> Loader Class Initialized
INFO - 2018-02-12 14:26:48 --> Helper loaded: url_helper
INFO - 2018-02-12 14:26:48 --> Helper loaded: notification_helper
INFO - 2018-02-12 14:26:48 --> Helper loaded: settings_helper
INFO - 2018-02-12 14:26:48 --> Helper loaded: permission_helper
INFO - 2018-02-12 14:26:48 --> Helper loaded: users_helper
INFO - 2018-02-12 14:26:48 --> Database Driver Class Initialized
DEBUG - 2018-02-12 14:26:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 14:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 14:26:48 --> Helper loaded: form_helper
INFO - 2018-02-12 14:26:48 --> Form Validation Class Initialized
INFO - 2018-02-12 14:26:48 --> Controller Class Initialized
INFO - 2018-02-12 14:26:48 --> Model Class Initialized
INFO - 2018-02-12 14:26:48 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 14:26:48 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 14:26:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 14:26:48 --> Model Class Initialized
INFO - 2018-02-12 14:26:48 --> Model Class Initialized
INFO - 2018-02-12 14:26:48 --> Model Class Initialized
INFO - 2018-02-12 14:26:48 --> Model Class Initialized
INFO - 2018-02-12 14:26:48 --> Model Class Initialized
INFO - 2018-02-12 14:26:48 --> Model Class Initialized
INFO - 2018-02-12 14:26:48 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 14:26:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-12 14:26:48 --> Final output sent to browser
DEBUG - 2018-02-12 14:26:48 --> Total execution time: 0.1413
INFO - 2018-02-12 08:56:48 --> Config Class Initialized
INFO - 2018-02-12 08:56:48 --> Hooks Class Initialized
DEBUG - 2018-02-12 08:56:48 --> UTF-8 Support Enabled
INFO - 2018-02-12 08:56:48 --> Utf8 Class Initialized
INFO - 2018-02-12 08:56:48 --> URI Class Initialized
INFO - 2018-02-12 08:56:48 --> Router Class Initialized
INFO - 2018-02-12 08:56:48 --> Output Class Initialized
INFO - 2018-02-12 08:56:48 --> Security Class Initialized
DEBUG - 2018-02-12 08:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 08:56:48 --> Input Class Initialized
INFO - 2018-02-12 08:56:48 --> Language Class Initialized
INFO - 2018-02-12 08:56:48 --> Language Class Initialized
INFO - 2018-02-12 08:56:48 --> Config Class Initialized
INFO - 2018-02-12 08:56:48 --> Loader Class Initialized
INFO - 2018-02-12 14:26:48 --> Helper loaded: url_helper
INFO - 2018-02-12 14:26:48 --> Helper loaded: notification_helper
INFO - 2018-02-12 14:26:48 --> Helper loaded: settings_helper
INFO - 2018-02-12 14:26:48 --> Helper loaded: permission_helper
INFO - 2018-02-12 14:26:48 --> Helper loaded: users_helper
INFO - 2018-02-12 14:26:48 --> Database Driver Class Initialized
DEBUG - 2018-02-12 14:26:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 14:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 14:26:48 --> Helper loaded: form_helper
INFO - 2018-02-12 14:26:48 --> Form Validation Class Initialized
INFO - 2018-02-12 14:26:48 --> Controller Class Initialized
INFO - 2018-02-12 14:26:48 --> Model Class Initialized
INFO - 2018-02-12 14:26:48 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 14:26:48 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 14:26:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 14:26:48 --> Model Class Initialized
INFO - 2018-02-12 14:26:48 --> Model Class Initialized
INFO - 2018-02-12 14:26:48 --> Model Class Initialized
INFO - 2018-02-12 14:26:48 --> Model Class Initialized
INFO - 2018-02-12 14:26:48 --> Model Class Initialized
INFO - 2018-02-12 14:26:48 --> Model Class Initialized
INFO - 2018-02-12 14:26:48 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 14:26:48 --> Final output sent to browser
DEBUG - 2018-02-12 14:26:48 --> Total execution time: 0.1173
INFO - 2018-02-12 08:56:49 --> Config Class Initialized
INFO - 2018-02-12 08:56:49 --> Hooks Class Initialized
DEBUG - 2018-02-12 08:56:49 --> UTF-8 Support Enabled
INFO - 2018-02-12 08:56:49 --> Utf8 Class Initialized
INFO - 2018-02-12 08:56:49 --> URI Class Initialized
INFO - 2018-02-12 08:56:49 --> Router Class Initialized
INFO - 2018-02-12 08:56:49 --> Output Class Initialized
INFO - 2018-02-12 08:56:49 --> Security Class Initialized
DEBUG - 2018-02-12 08:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 08:56:49 --> Input Class Initialized
INFO - 2018-02-12 08:56:49 --> Language Class Initialized
INFO - 2018-02-12 08:56:49 --> Language Class Initialized
INFO - 2018-02-12 08:56:49 --> Config Class Initialized
INFO - 2018-02-12 08:56:49 --> Loader Class Initialized
INFO - 2018-02-12 14:26:49 --> Helper loaded: url_helper
INFO - 2018-02-12 14:26:49 --> Helper loaded: notification_helper
INFO - 2018-02-12 14:26:49 --> Helper loaded: settings_helper
INFO - 2018-02-12 14:26:49 --> Helper loaded: permission_helper
INFO - 2018-02-12 14:26:49 --> Helper loaded: users_helper
INFO - 2018-02-12 14:26:49 --> Database Driver Class Initialized
DEBUG - 2018-02-12 14:26:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 14:26:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 14:26:49 --> Helper loaded: form_helper
INFO - 2018-02-12 14:26:49 --> Form Validation Class Initialized
INFO - 2018-02-12 14:26:49 --> Controller Class Initialized
INFO - 2018-02-12 14:26:49 --> Model Class Initialized
INFO - 2018-02-12 14:26:49 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 14:26:49 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 14:26:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 14:26:49 --> Model Class Initialized
INFO - 2018-02-12 14:26:49 --> Model Class Initialized
INFO - 2018-02-12 14:26:49 --> Model Class Initialized
INFO - 2018-02-12 14:26:49 --> Model Class Initialized
INFO - 2018-02-12 14:26:49 --> Model Class Initialized
INFO - 2018-02-12 14:26:49 --> Model Class Initialized
INFO - 2018-02-12 14:26:49 --> Model Class Initialized
INFO - 2018-02-12 14:26:49 --> Model Class Initialized
INFO - 2018-02-12 14:26:49 --> Model Class Initialized
INFO - 2018-02-12 14:26:49 --> Model Class Initialized
INFO - 2018-02-12 14:26:49 --> Model Class Initialized
INFO - 2018-02-12 14:26:49 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 14:26:49 --> Model Class Initialized
INFO - 2018-02-12 14:26:49 --> Final output sent to browser
DEBUG - 2018-02-12 14:26:49 --> Total execution time: 0.1311
INFO - 2018-02-12 09:14:06 --> Config Class Initialized
INFO - 2018-02-12 09:14:06 --> Hooks Class Initialized
DEBUG - 2018-02-12 09:14:06 --> UTF-8 Support Enabled
INFO - 2018-02-12 09:14:06 --> Utf8 Class Initialized
INFO - 2018-02-12 09:14:06 --> URI Class Initialized
INFO - 2018-02-12 09:14:06 --> Router Class Initialized
INFO - 2018-02-12 09:14:06 --> Output Class Initialized
INFO - 2018-02-12 09:14:06 --> Security Class Initialized
DEBUG - 2018-02-12 09:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 09:14:06 --> Input Class Initialized
INFO - 2018-02-12 09:14:06 --> Language Class Initialized
INFO - 2018-02-12 09:14:06 --> Language Class Initialized
INFO - 2018-02-12 09:14:06 --> Config Class Initialized
INFO - 2018-02-12 09:14:06 --> Loader Class Initialized
INFO - 2018-02-12 14:44:06 --> Helper loaded: url_helper
INFO - 2018-02-12 14:44:06 --> Helper loaded: notification_helper
INFO - 2018-02-12 14:44:06 --> Helper loaded: settings_helper
INFO - 2018-02-12 14:44:06 --> Helper loaded: permission_helper
INFO - 2018-02-12 14:44:06 --> Helper loaded: users_helper
INFO - 2018-02-12 14:44:06 --> Database Driver Class Initialized
DEBUG - 2018-02-12 14:44:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 14:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 14:44:06 --> Helper loaded: form_helper
INFO - 2018-02-12 14:44:06 --> Form Validation Class Initialized
INFO - 2018-02-12 14:44:06 --> Controller Class Initialized
INFO - 2018-02-12 14:44:06 --> Model Class Initialized
INFO - 2018-02-12 14:44:06 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 14:44:06 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 14:44:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 14:44:06 --> Model Class Initialized
INFO - 2018-02-12 14:44:06 --> Model Class Initialized
INFO - 2018-02-12 14:44:06 --> Model Class Initialized
INFO - 2018-02-12 14:44:06 --> Model Class Initialized
INFO - 2018-02-12 14:44:06 --> Model Class Initialized
INFO - 2018-02-12 14:44:06 --> Model Class Initialized
INFO - 2018-02-12 14:44:06 --> Model Class Initialized
INFO - 2018-02-12 14:44:06 --> Model Class Initialized
INFO - 2018-02-12 14:44:06 --> Model Class Initialized
INFO - 2018-02-12 14:44:06 --> Model Class Initialized
INFO - 2018-02-12 14:44:06 --> Model Class Initialized
INFO - 2018-02-12 14:44:06 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 14:44:06 --> Model Class Initialized
INFO - 2018-02-12 14:44:06 --> Final output sent to browser
DEBUG - 2018-02-12 14:44:06 --> Total execution time: 0.1297
INFO - 2018-02-12 09:14:08 --> Config Class Initialized
INFO - 2018-02-12 09:14:08 --> Hooks Class Initialized
DEBUG - 2018-02-12 09:14:08 --> UTF-8 Support Enabled
INFO - 2018-02-12 09:14:08 --> Utf8 Class Initialized
INFO - 2018-02-12 09:14:08 --> URI Class Initialized
INFO - 2018-02-12 09:14:08 --> Router Class Initialized
INFO - 2018-02-12 09:14:08 --> Output Class Initialized
INFO - 2018-02-12 09:14:08 --> Security Class Initialized
DEBUG - 2018-02-12 09:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 09:14:08 --> Input Class Initialized
INFO - 2018-02-12 09:14:08 --> Language Class Initialized
INFO - 2018-02-12 09:14:08 --> Language Class Initialized
INFO - 2018-02-12 09:14:08 --> Config Class Initialized
INFO - 2018-02-12 09:14:08 --> Loader Class Initialized
INFO - 2018-02-12 14:44:08 --> Helper loaded: url_helper
INFO - 2018-02-12 14:44:08 --> Helper loaded: notification_helper
INFO - 2018-02-12 14:44:08 --> Helper loaded: settings_helper
INFO - 2018-02-12 14:44:08 --> Helper loaded: permission_helper
INFO - 2018-02-12 14:44:08 --> Helper loaded: users_helper
INFO - 2018-02-12 14:44:08 --> Database Driver Class Initialized
DEBUG - 2018-02-12 14:44:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 14:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 14:44:08 --> Helper loaded: form_helper
INFO - 2018-02-12 14:44:08 --> Form Validation Class Initialized
INFO - 2018-02-12 14:44:08 --> Controller Class Initialized
INFO - 2018-02-12 14:44:08 --> Model Class Initialized
INFO - 2018-02-12 14:44:08 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 14:44:08 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 14:44:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 14:44:08 --> Model Class Initialized
INFO - 2018-02-12 14:44:08 --> Model Class Initialized
INFO - 2018-02-12 14:44:08 --> Model Class Initialized
INFO - 2018-02-12 14:44:08 --> Model Class Initialized
INFO - 2018-02-12 14:44:08 --> Model Class Initialized
INFO - 2018-02-12 14:44:08 --> Model Class Initialized
INFO - 2018-02-12 14:44:08 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 14:44:08 --> Model Class Initialized
INFO - 2018-02-12 14:44:08 --> Final output sent to browser
DEBUG - 2018-02-12 14:44:08 --> Total execution time: 0.1221
INFO - 2018-02-12 09:14:16 --> Config Class Initialized
INFO - 2018-02-12 09:14:16 --> Hooks Class Initialized
DEBUG - 2018-02-12 09:14:16 --> UTF-8 Support Enabled
INFO - 2018-02-12 09:14:16 --> Utf8 Class Initialized
INFO - 2018-02-12 09:14:16 --> URI Class Initialized
INFO - 2018-02-12 09:14:16 --> Config Class Initialized
INFO - 2018-02-12 09:14:16 --> Hooks Class Initialized
DEBUG - 2018-02-12 09:14:16 --> UTF-8 Support Enabled
INFO - 2018-02-12 09:14:16 --> Utf8 Class Initialized
INFO - 2018-02-12 09:14:16 --> Router Class Initialized
INFO - 2018-02-12 09:14:16 --> URI Class Initialized
INFO - 2018-02-12 09:14:16 --> Output Class Initialized
INFO - 2018-02-12 09:14:16 --> Router Class Initialized
INFO - 2018-02-12 09:14:16 --> Security Class Initialized
DEBUG - 2018-02-12 09:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 09:14:16 --> Input Class Initialized
INFO - 2018-02-12 09:14:16 --> Output Class Initialized
INFO - 2018-02-12 09:14:16 --> Language Class Initialized
INFO - 2018-02-12 09:14:16 --> Security Class Initialized
DEBUG - 2018-02-12 09:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 09:14:16 --> Input Class Initialized
INFO - 2018-02-12 09:14:16 --> Language Class Initialized
INFO - 2018-02-12 09:14:16 --> Language Class Initialized
INFO - 2018-02-12 09:14:16 --> Config Class Initialized
INFO - 2018-02-12 09:14:16 --> Loader Class Initialized
INFO - 2018-02-12 09:14:16 --> Language Class Initialized
INFO - 2018-02-12 09:14:16 --> Config Class Initialized
INFO - 2018-02-12 09:14:16 --> Loader Class Initialized
INFO - 2018-02-12 14:44:16 --> Helper loaded: url_helper
INFO - 2018-02-12 14:44:16 --> Helper loaded: notification_helper
INFO - 2018-02-12 14:44:16 --> Helper loaded: url_helper
INFO - 2018-02-12 14:44:16 --> Helper loaded: settings_helper
INFO - 2018-02-12 14:44:16 --> Helper loaded: permission_helper
INFO - 2018-02-12 14:44:16 --> Helper loaded: notification_helper
INFO - 2018-02-12 14:44:16 --> Helper loaded: settings_helper
INFO - 2018-02-12 14:44:16 --> Helper loaded: users_helper
INFO - 2018-02-12 14:44:16 --> Helper loaded: permission_helper
INFO - 2018-02-12 14:44:16 --> Helper loaded: users_helper
INFO - 2018-02-12 14:44:16 --> Database Driver Class Initialized
INFO - 2018-02-12 14:44:16 --> Database Driver Class Initialized
DEBUG - 2018-02-12 14:44:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 14:44:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-12 14:44:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 14:44:16 --> Helper loaded: form_helper
INFO - 2018-02-12 14:44:16 --> Form Validation Class Initialized
INFO - 2018-02-12 14:44:16 --> Controller Class Initialized
INFO - 2018-02-12 14:44:16 --> Model Class Initialized
INFO - 2018-02-12 14:44:16 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 14:44:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 14:44:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 14:44:16 --> Model Class Initialized
INFO - 2018-02-12 14:44:16 --> Model Class Initialized
INFO - 2018-02-12 14:44:16 --> Model Class Initialized
INFO - 2018-02-12 14:44:16 --> Model Class Initialized
INFO - 2018-02-12 14:44:16 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 14:44:16 --> Final output sent to browser
DEBUG - 2018-02-12 14:44:16 --> Total execution time: 0.0901
INFO - 2018-02-12 14:44:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 14:44:16 --> Helper loaded: form_helper
INFO - 2018-02-12 14:44:16 --> Form Validation Class Initialized
INFO - 2018-02-12 14:44:16 --> Controller Class Initialized
INFO - 2018-02-12 14:44:16 --> Model Class Initialized
INFO - 2018-02-12 14:44:16 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 14:44:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 14:44:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 14:44:16 --> Model Class Initialized
INFO - 2018-02-12 14:44:16 --> Model Class Initialized
INFO - 2018-02-12 14:44:16 --> Model Class Initialized
INFO - 2018-02-12 14:44:16 --> Model Class Initialized
INFO - 2018-02-12 14:44:16 --> Model Class Initialized
INFO - 2018-02-12 14:44:16 --> Model Class Initialized
INFO - 2018-02-12 14:44:16 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 14:44:16 --> Final output sent to browser
DEBUG - 2018-02-12 14:44:16 --> Total execution time: 0.1366
INFO - 2018-02-12 09:19:11 --> Config Class Initialized
INFO - 2018-02-12 09:19:11 --> Hooks Class Initialized
DEBUG - 2018-02-12 09:19:11 --> UTF-8 Support Enabled
INFO - 2018-02-12 09:19:11 --> Utf8 Class Initialized
INFO - 2018-02-12 09:19:11 --> URI Class Initialized
INFO - 2018-02-12 09:19:11 --> Router Class Initialized
INFO - 2018-02-12 09:19:11 --> Output Class Initialized
INFO - 2018-02-12 09:19:11 --> Security Class Initialized
DEBUG - 2018-02-12 09:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 09:19:11 --> Input Class Initialized
INFO - 2018-02-12 09:19:11 --> Language Class Initialized
INFO - 2018-02-12 09:19:11 --> Language Class Initialized
INFO - 2018-02-12 09:19:11 --> Config Class Initialized
INFO - 2018-02-12 09:19:11 --> Loader Class Initialized
INFO - 2018-02-12 14:49:11 --> Helper loaded: url_helper
INFO - 2018-02-12 14:49:11 --> Helper loaded: notification_helper
INFO - 2018-02-12 14:49:11 --> Helper loaded: settings_helper
INFO - 2018-02-12 14:49:11 --> Helper loaded: permission_helper
INFO - 2018-02-12 14:49:11 --> Helper loaded: users_helper
INFO - 2018-02-12 14:49:11 --> Database Driver Class Initialized
DEBUG - 2018-02-12 14:49:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 14:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 14:49:11 --> Helper loaded: form_helper
INFO - 2018-02-12 14:49:11 --> Form Validation Class Initialized
INFO - 2018-02-12 14:49:11 --> Controller Class Initialized
INFO - 2018-02-12 14:49:11 --> Model Class Initialized
INFO - 2018-02-12 14:49:11 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 14:49:11 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 14:49:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 14:49:11 --> Model Class Initialized
INFO - 2018-02-12 14:49:11 --> Model Class Initialized
INFO - 2018-02-12 14:49:11 --> Model Class Initialized
INFO - 2018-02-12 14:49:11 --> Model Class Initialized
INFO - 2018-02-12 14:49:11 --> Model Class Initialized
INFO - 2018-02-12 14:49:11 --> Model Class Initialized
INFO - 2018-02-12 14:49:11 --> Model Class Initialized
INFO - 2018-02-12 14:49:11 --> Model Class Initialized
INFO - 2018-02-12 14:49:11 --> Model Class Initialized
INFO - 2018-02-12 14:49:11 --> Model Class Initialized
INFO - 2018-02-12 14:49:11 --> Model Class Initialized
INFO - 2018-02-12 14:49:11 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 14:49:11 --> Model Class Initialized
INFO - 2018-02-12 14:49:11 --> Final output sent to browser
DEBUG - 2018-02-12 14:49:11 --> Total execution time: 0.1021
INFO - 2018-02-12 09:19:13 --> Config Class Initialized
INFO - 2018-02-12 09:19:13 --> Hooks Class Initialized
DEBUG - 2018-02-12 09:19:13 --> UTF-8 Support Enabled
INFO - 2018-02-12 09:19:13 --> Utf8 Class Initialized
INFO - 2018-02-12 09:19:13 --> URI Class Initialized
INFO - 2018-02-12 09:19:13 --> Router Class Initialized
INFO - 2018-02-12 09:19:13 --> Output Class Initialized
INFO - 2018-02-12 09:19:13 --> Security Class Initialized
DEBUG - 2018-02-12 09:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 09:19:13 --> Input Class Initialized
INFO - 2018-02-12 09:19:13 --> Language Class Initialized
INFO - 2018-02-12 09:19:13 --> Language Class Initialized
INFO - 2018-02-12 09:19:13 --> Config Class Initialized
INFO - 2018-02-12 09:19:13 --> Loader Class Initialized
INFO - 2018-02-12 14:49:13 --> Helper loaded: url_helper
INFO - 2018-02-12 14:49:13 --> Helper loaded: notification_helper
INFO - 2018-02-12 14:49:13 --> Helper loaded: settings_helper
INFO - 2018-02-12 14:49:13 --> Helper loaded: permission_helper
INFO - 2018-02-12 14:49:13 --> Helper loaded: users_helper
INFO - 2018-02-12 14:49:13 --> Database Driver Class Initialized
DEBUG - 2018-02-12 14:49:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 14:49:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 14:49:13 --> Helper loaded: form_helper
INFO - 2018-02-12 14:49:13 --> Form Validation Class Initialized
INFO - 2018-02-12 14:49:13 --> Controller Class Initialized
INFO - 2018-02-12 14:49:13 --> Model Class Initialized
INFO - 2018-02-12 14:49:13 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 14:49:13 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 14:49:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 14:49:13 --> Model Class Initialized
INFO - 2018-02-12 14:49:13 --> Model Class Initialized
INFO - 2018-02-12 14:49:13 --> Model Class Initialized
INFO - 2018-02-12 14:49:13 --> Model Class Initialized
INFO - 2018-02-12 14:49:13 --> Model Class Initialized
INFO - 2018-02-12 14:49:13 --> Model Class Initialized
INFO - 2018-02-12 14:49:13 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 14:49:13 --> Model Class Initialized
INFO - 2018-02-12 14:49:13 --> Final output sent to browser
DEBUG - 2018-02-12 14:49:13 --> Total execution time: 0.0808
INFO - 2018-02-12 09:19:20 --> Config Class Initialized
INFO - 2018-02-12 09:19:20 --> Hooks Class Initialized
DEBUG - 2018-02-12 09:19:20 --> UTF-8 Support Enabled
INFO - 2018-02-12 09:19:20 --> Utf8 Class Initialized
INFO - 2018-02-12 09:19:20 --> URI Class Initialized
INFO - 2018-02-12 09:19:20 --> Router Class Initialized
INFO - 2018-02-12 09:19:20 --> Output Class Initialized
INFO - 2018-02-12 09:19:20 --> Security Class Initialized
DEBUG - 2018-02-12 09:19:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 09:19:20 --> Input Class Initialized
INFO - 2018-02-12 09:19:20 --> Language Class Initialized
INFO - 2018-02-12 09:19:20 --> Config Class Initialized
INFO - 2018-02-12 09:19:20 --> Hooks Class Initialized
DEBUG - 2018-02-12 09:19:20 --> UTF-8 Support Enabled
INFO - 2018-02-12 09:19:20 --> Utf8 Class Initialized
INFO - 2018-02-12 09:19:20 --> URI Class Initialized
INFO - 2018-02-12 09:19:20 --> Router Class Initialized
INFO - 2018-02-12 09:19:20 --> Output Class Initialized
INFO - 2018-02-12 09:19:20 --> Language Class Initialized
INFO - 2018-02-12 09:19:20 --> Config Class Initialized
INFO - 2018-02-12 09:19:20 --> Loader Class Initialized
INFO - 2018-02-12 14:49:20 --> Helper loaded: url_helper
INFO - 2018-02-12 09:19:20 --> Security Class Initialized
INFO - 2018-02-12 14:49:20 --> Helper loaded: notification_helper
INFO - 2018-02-12 14:49:20 --> Helper loaded: settings_helper
INFO - 2018-02-12 14:49:20 --> Helper loaded: permission_helper
DEBUG - 2018-02-12 09:19:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 09:19:20 --> Input Class Initialized
INFO - 2018-02-12 14:49:20 --> Helper loaded: users_helper
INFO - 2018-02-12 09:19:20 --> Language Class Initialized
INFO - 2018-02-12 14:49:20 --> Database Driver Class Initialized
DEBUG - 2018-02-12 14:49:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 14:49:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 09:19:20 --> Language Class Initialized
INFO - 2018-02-12 09:19:20 --> Config Class Initialized
INFO - 2018-02-12 09:19:20 --> Loader Class Initialized
INFO - 2018-02-12 14:49:20 --> Helper loaded: url_helper
INFO - 2018-02-12 14:49:20 --> Helper loaded: notification_helper
INFO - 2018-02-12 14:49:20 --> Helper loaded: settings_helper
INFO - 2018-02-12 14:49:20 --> Helper loaded: permission_helper
INFO - 2018-02-12 14:49:20 --> Helper loaded: users_helper
INFO - 2018-02-12 14:49:20 --> Helper loaded: form_helper
INFO - 2018-02-12 14:49:20 --> Form Validation Class Initialized
INFO - 2018-02-12 14:49:20 --> Controller Class Initialized
INFO - 2018-02-12 14:49:20 --> Model Class Initialized
INFO - 2018-02-12 14:49:20 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 14:49:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 14:49:20 --> Database Driver Class Initialized
INFO - 2018-02-12 14:49:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 14:49:20 --> Model Class Initialized
INFO - 2018-02-12 14:49:20 --> Model Class Initialized
INFO - 2018-02-12 14:49:20 --> Model Class Initialized
INFO - 2018-02-12 14:49:20 --> Model Class Initialized
INFO - 2018-02-12 14:49:20 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-02-12 14:49:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 14:49:20 --> Final output sent to browser
DEBUG - 2018-02-12 14:49:20 --> Total execution time: 0.0983
INFO - 2018-02-12 14:49:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 14:49:20 --> Helper loaded: form_helper
INFO - 2018-02-12 14:49:20 --> Form Validation Class Initialized
INFO - 2018-02-12 14:49:20 --> Controller Class Initialized
INFO - 2018-02-12 14:49:20 --> Model Class Initialized
INFO - 2018-02-12 14:49:20 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 14:49:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 14:49:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 14:49:20 --> Model Class Initialized
INFO - 2018-02-12 14:49:20 --> Model Class Initialized
INFO - 2018-02-12 14:49:20 --> Model Class Initialized
INFO - 2018-02-12 14:49:20 --> Model Class Initialized
INFO - 2018-02-12 14:49:20 --> Model Class Initialized
INFO - 2018-02-12 14:49:20 --> Model Class Initialized
INFO - 2018-02-12 14:49:20 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 14:49:20 --> Final output sent to browser
DEBUG - 2018-02-12 14:49:20 --> Total execution time: 0.1131
INFO - 2018-02-12 09:19:25 --> Config Class Initialized
INFO - 2018-02-12 09:19:25 --> Hooks Class Initialized
DEBUG - 2018-02-12 09:19:25 --> UTF-8 Support Enabled
INFO - 2018-02-12 09:19:25 --> Utf8 Class Initialized
INFO - 2018-02-12 09:19:25 --> URI Class Initialized
INFO - 2018-02-12 09:19:25 --> Router Class Initialized
INFO - 2018-02-12 09:19:25 --> Output Class Initialized
INFO - 2018-02-12 09:19:25 --> Security Class Initialized
DEBUG - 2018-02-12 09:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 09:19:25 --> Input Class Initialized
INFO - 2018-02-12 09:19:25 --> Language Class Initialized
INFO - 2018-02-12 09:19:25 --> Language Class Initialized
INFO - 2018-02-12 09:19:25 --> Config Class Initialized
INFO - 2018-02-12 09:19:25 --> Loader Class Initialized
INFO - 2018-02-12 14:49:25 --> Helper loaded: url_helper
INFO - 2018-02-12 14:49:25 --> Helper loaded: notification_helper
INFO - 2018-02-12 14:49:25 --> Helper loaded: settings_helper
INFO - 2018-02-12 14:49:25 --> Helper loaded: permission_helper
INFO - 2018-02-12 14:49:25 --> Helper loaded: users_helper
INFO - 2018-02-12 14:49:25 --> Database Driver Class Initialized
DEBUG - 2018-02-12 14:49:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 14:49:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 14:49:25 --> Helper loaded: form_helper
INFO - 2018-02-12 14:49:25 --> Form Validation Class Initialized
INFO - 2018-02-12 14:49:25 --> Controller Class Initialized
INFO - 2018-02-12 14:49:25 --> Model Class Initialized
INFO - 2018-02-12 14:49:25 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 14:49:25 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 14:49:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 14:49:25 --> Model Class Initialized
INFO - 2018-02-12 14:49:25 --> Model Class Initialized
INFO - 2018-02-12 14:49:25 --> Model Class Initialized
INFO - 2018-02-12 14:49:25 --> Model Class Initialized
INFO - 2018-02-12 14:49:25 --> Model Class Initialized
INFO - 2018-02-12 14:49:25 --> Model Class Initialized
INFO - 2018-02-12 14:49:25 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 14:49:25 --> Final output sent to browser
DEBUG - 2018-02-12 14:49:25 --> Total execution time: 0.1118
INFO - 2018-02-12 09:20:27 --> Config Class Initialized
INFO - 2018-02-12 09:20:27 --> Hooks Class Initialized
DEBUG - 2018-02-12 09:20:27 --> UTF-8 Support Enabled
INFO - 2018-02-12 09:20:27 --> Utf8 Class Initialized
INFO - 2018-02-12 09:20:27 --> URI Class Initialized
INFO - 2018-02-12 09:20:27 --> Router Class Initialized
INFO - 2018-02-12 09:20:27 --> Output Class Initialized
INFO - 2018-02-12 09:20:27 --> Security Class Initialized
DEBUG - 2018-02-12 09:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 09:20:27 --> Input Class Initialized
INFO - 2018-02-12 09:20:27 --> Language Class Initialized
INFO - 2018-02-12 09:20:28 --> Language Class Initialized
INFO - 2018-02-12 09:20:28 --> Config Class Initialized
INFO - 2018-02-12 09:20:28 --> Loader Class Initialized
INFO - 2018-02-12 14:50:28 --> Helper loaded: url_helper
INFO - 2018-02-12 14:50:28 --> Helper loaded: notification_helper
INFO - 2018-02-12 14:50:28 --> Helper loaded: settings_helper
INFO - 2018-02-12 14:50:28 --> Helper loaded: permission_helper
INFO - 2018-02-12 14:50:28 --> Helper loaded: users_helper
INFO - 2018-02-12 14:50:28 --> Database Driver Class Initialized
DEBUG - 2018-02-12 14:50:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 14:50:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 14:50:28 --> Helper loaded: form_helper
INFO - 2018-02-12 14:50:28 --> Form Validation Class Initialized
INFO - 2018-02-12 14:50:28 --> Controller Class Initialized
INFO - 2018-02-12 14:50:28 --> Model Class Initialized
INFO - 2018-02-12 14:50:28 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 14:50:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 14:50:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 14:50:28 --> Model Class Initialized
INFO - 2018-02-12 14:50:28 --> Model Class Initialized
INFO - 2018-02-12 14:50:28 --> Model Class Initialized
INFO - 2018-02-12 14:50:28 --> Model Class Initialized
INFO - 2018-02-12 14:50:28 --> Model Class Initialized
INFO - 2018-02-12 14:50:28 --> Model Class Initialized
INFO - 2018-02-12 14:50:28 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 14:50:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-12 14:50:28 --> Final output sent to browser
DEBUG - 2018-02-12 14:50:28 --> Total execution time: 0.1229
INFO - 2018-02-12 09:20:28 --> Config Class Initialized
INFO - 2018-02-12 09:20:28 --> Hooks Class Initialized
DEBUG - 2018-02-12 09:20:28 --> UTF-8 Support Enabled
INFO - 2018-02-12 09:20:28 --> Utf8 Class Initialized
INFO - 2018-02-12 09:20:28 --> URI Class Initialized
INFO - 2018-02-12 09:20:28 --> Router Class Initialized
INFO - 2018-02-12 09:20:28 --> Output Class Initialized
INFO - 2018-02-12 09:20:28 --> Security Class Initialized
DEBUG - 2018-02-12 09:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 09:20:28 --> Input Class Initialized
INFO - 2018-02-12 09:20:28 --> Language Class Initialized
INFO - 2018-02-12 09:20:28 --> Language Class Initialized
INFO - 2018-02-12 09:20:28 --> Config Class Initialized
INFO - 2018-02-12 09:20:28 --> Loader Class Initialized
INFO - 2018-02-12 14:50:28 --> Helper loaded: url_helper
INFO - 2018-02-12 14:50:28 --> Helper loaded: notification_helper
INFO - 2018-02-12 14:50:28 --> Helper loaded: settings_helper
INFO - 2018-02-12 14:50:28 --> Helper loaded: permission_helper
INFO - 2018-02-12 14:50:28 --> Helper loaded: users_helper
INFO - 2018-02-12 14:50:28 --> Database Driver Class Initialized
DEBUG - 2018-02-12 14:50:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 14:50:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 14:50:28 --> Helper loaded: form_helper
INFO - 2018-02-12 14:50:28 --> Form Validation Class Initialized
INFO - 2018-02-12 14:50:28 --> Controller Class Initialized
INFO - 2018-02-12 14:50:28 --> Model Class Initialized
INFO - 2018-02-12 14:50:28 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 14:50:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 14:50:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 14:50:28 --> Model Class Initialized
INFO - 2018-02-12 14:50:28 --> Model Class Initialized
INFO - 2018-02-12 14:50:28 --> Model Class Initialized
INFO - 2018-02-12 14:50:28 --> Model Class Initialized
INFO - 2018-02-12 14:50:28 --> Model Class Initialized
INFO - 2018-02-12 14:50:28 --> Model Class Initialized
INFO - 2018-02-12 14:50:28 --> Model Class Initialized
INFO - 2018-02-12 14:50:28 --> Model Class Initialized
INFO - 2018-02-12 14:50:28 --> Model Class Initialized
INFO - 2018-02-12 14:50:28 --> Model Class Initialized
INFO - 2018-02-12 14:50:28 --> Model Class Initialized
INFO - 2018-02-12 14:50:28 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 14:50:28 --> Model Class Initialized
INFO - 2018-02-12 14:50:28 --> Final output sent to browser
DEBUG - 2018-02-12 14:50:28 --> Total execution time: 0.1608
INFO - 2018-02-12 09:21:08 --> Config Class Initialized
INFO - 2018-02-12 09:21:08 --> Hooks Class Initialized
DEBUG - 2018-02-12 09:21:08 --> UTF-8 Support Enabled
INFO - 2018-02-12 09:21:08 --> Utf8 Class Initialized
INFO - 2018-02-12 09:21:08 --> URI Class Initialized
INFO - 2018-02-12 09:21:08 --> Router Class Initialized
INFO - 2018-02-12 09:21:08 --> Output Class Initialized
INFO - 2018-02-12 09:21:08 --> Security Class Initialized
DEBUG - 2018-02-12 09:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 09:21:08 --> Input Class Initialized
INFO - 2018-02-12 09:21:08 --> Language Class Initialized
INFO - 2018-02-12 09:21:08 --> Language Class Initialized
INFO - 2018-02-12 09:21:08 --> Config Class Initialized
INFO - 2018-02-12 09:21:08 --> Loader Class Initialized
INFO - 2018-02-12 14:51:08 --> Helper loaded: url_helper
INFO - 2018-02-12 14:51:08 --> Helper loaded: notification_helper
INFO - 2018-02-12 14:51:08 --> Helper loaded: settings_helper
INFO - 2018-02-12 14:51:08 --> Helper loaded: permission_helper
INFO - 2018-02-12 14:51:08 --> Helper loaded: users_helper
INFO - 2018-02-12 14:51:08 --> Database Driver Class Initialized
DEBUG - 2018-02-12 14:51:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 14:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 14:51:08 --> Helper loaded: form_helper
INFO - 2018-02-12 14:51:08 --> Form Validation Class Initialized
INFO - 2018-02-12 14:51:08 --> Controller Class Initialized
INFO - 2018-02-12 14:51:08 --> Model Class Initialized
INFO - 2018-02-12 14:51:08 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 14:51:08 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 14:51:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 14:51:08 --> Model Class Initialized
INFO - 2018-02-12 14:51:08 --> Model Class Initialized
INFO - 2018-02-12 14:51:08 --> Model Class Initialized
INFO - 2018-02-12 14:51:08 --> Model Class Initialized
INFO - 2018-02-12 14:51:08 --> Model Class Initialized
INFO - 2018-02-12 14:51:08 --> Model Class Initialized
INFO - 2018-02-12 14:51:08 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 14:51:08 --> Final output sent to browser
DEBUG - 2018-02-12 14:51:08 --> Total execution time: 0.1138
INFO - 2018-02-12 09:30:15 --> Config Class Initialized
INFO - 2018-02-12 09:30:15 --> Hooks Class Initialized
DEBUG - 2018-02-12 09:30:15 --> UTF-8 Support Enabled
INFO - 2018-02-12 09:30:15 --> Utf8 Class Initialized
INFO - 2018-02-12 09:30:15 --> URI Class Initialized
INFO - 2018-02-12 09:30:15 --> Router Class Initialized
INFO - 2018-02-12 09:30:15 --> Output Class Initialized
INFO - 2018-02-12 09:30:15 --> Security Class Initialized
DEBUG - 2018-02-12 09:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 09:30:15 --> Input Class Initialized
INFO - 2018-02-12 09:30:15 --> Language Class Initialized
INFO - 2018-02-12 09:30:15 --> Language Class Initialized
INFO - 2018-02-12 09:30:15 --> Config Class Initialized
INFO - 2018-02-12 09:30:15 --> Loader Class Initialized
INFO - 2018-02-12 15:00:15 --> Helper loaded: url_helper
INFO - 2018-02-12 15:00:15 --> Helper loaded: notification_helper
INFO - 2018-02-12 15:00:15 --> Helper loaded: settings_helper
INFO - 2018-02-12 15:00:15 --> Helper loaded: permission_helper
INFO - 2018-02-12 15:00:15 --> Helper loaded: users_helper
INFO - 2018-02-12 15:00:15 --> Database Driver Class Initialized
DEBUG - 2018-02-12 15:00:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 15:00:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 15:00:15 --> Helper loaded: form_helper
INFO - 2018-02-12 15:00:15 --> Form Validation Class Initialized
INFO - 2018-02-12 15:00:15 --> Controller Class Initialized
INFO - 2018-02-12 15:00:15 --> Model Class Initialized
INFO - 2018-02-12 15:00:15 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 15:00:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 15:00:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 15:00:15 --> Model Class Initialized
INFO - 2018-02-12 15:00:15 --> Model Class Initialized
INFO - 2018-02-12 15:00:15 --> Model Class Initialized
INFO - 2018-02-12 15:00:15 --> Model Class Initialized
INFO - 2018-02-12 15:00:15 --> Model Class Initialized
INFO - 2018-02-12 15:00:15 --> Model Class Initialized
INFO - 2018-02-12 15:00:15 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-02-12 15:00:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-02-12 15:00:15 --> Final output sent to browser
DEBUG - 2018-02-12 15:00:15 --> Total execution time: 0.1194
INFO - 2018-02-12 09:30:22 --> Config Class Initialized
INFO - 2018-02-12 09:30:22 --> Hooks Class Initialized
DEBUG - 2018-02-12 09:30:22 --> UTF-8 Support Enabled
INFO - 2018-02-12 09:30:22 --> Utf8 Class Initialized
INFO - 2018-02-12 09:30:22 --> URI Class Initialized
INFO - 2018-02-12 09:30:22 --> Router Class Initialized
INFO - 2018-02-12 09:30:22 --> Output Class Initialized
INFO - 2018-02-12 09:30:22 --> Security Class Initialized
DEBUG - 2018-02-12 09:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 09:30:22 --> Input Class Initialized
INFO - 2018-02-12 09:30:22 --> Language Class Initialized
INFO - 2018-02-12 09:30:22 --> Language Class Initialized
INFO - 2018-02-12 09:30:22 --> Config Class Initialized
INFO - 2018-02-12 09:30:22 --> Loader Class Initialized
INFO - 2018-02-12 15:00:22 --> Helper loaded: url_helper
INFO - 2018-02-12 15:00:22 --> Helper loaded: notification_helper
INFO - 2018-02-12 15:00:22 --> Helper loaded: settings_helper
INFO - 2018-02-12 15:00:22 --> Helper loaded: permission_helper
INFO - 2018-02-12 15:00:22 --> Helper loaded: users_helper
INFO - 2018-02-12 15:00:22 --> Database Driver Class Initialized
DEBUG - 2018-02-12 15:00:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 15:00:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 15:00:22 --> Helper loaded: form_helper
INFO - 2018-02-12 15:00:22 --> Form Validation Class Initialized
INFO - 2018-02-12 15:00:22 --> Controller Class Initialized
INFO - 2018-02-12 15:00:22 --> Model Class Initialized
INFO - 2018-02-12 15:00:22 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 15:00:22 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 15:00:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 15:00:22 --> Model Class Initialized
INFO - 2018-02-12 15:00:22 --> Model Class Initialized
INFO - 2018-02-12 15:00:22 --> Model Class Initialized
INFO - 2018-02-12 15:00:22 --> Model Class Initialized
INFO - 2018-02-12 15:00:22 --> Model Class Initialized
INFO - 2018-02-12 15:00:22 --> Model Class Initialized
INFO - 2018-02-12 15:00:22 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 15:00:22 --> Final output sent to browser
DEBUG - 2018-02-12 15:00:22 --> Total execution time: 0.1124
INFO - 2018-02-12 09:30:35 --> Config Class Initialized
INFO - 2018-02-12 09:30:35 --> Hooks Class Initialized
DEBUG - 2018-02-12 09:30:35 --> UTF-8 Support Enabled
INFO - 2018-02-12 09:30:35 --> Utf8 Class Initialized
INFO - 2018-02-12 09:30:35 --> URI Class Initialized
INFO - 2018-02-12 09:30:35 --> Router Class Initialized
INFO - 2018-02-12 09:30:35 --> Output Class Initialized
INFO - 2018-02-12 09:30:35 --> Security Class Initialized
DEBUG - 2018-02-12 09:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 09:30:35 --> Input Class Initialized
INFO - 2018-02-12 09:30:35 --> Language Class Initialized
INFO - 2018-02-12 09:30:35 --> Language Class Initialized
INFO - 2018-02-12 09:30:35 --> Config Class Initialized
INFO - 2018-02-12 09:30:35 --> Loader Class Initialized
INFO - 2018-02-12 15:00:35 --> Helper loaded: url_helper
INFO - 2018-02-12 15:00:35 --> Helper loaded: notification_helper
INFO - 2018-02-12 15:00:35 --> Helper loaded: settings_helper
INFO - 2018-02-12 15:00:35 --> Helper loaded: permission_helper
INFO - 2018-02-12 15:00:35 --> Helper loaded: users_helper
INFO - 2018-02-12 15:00:35 --> Database Driver Class Initialized
DEBUG - 2018-02-12 15:00:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 15:00:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 15:00:35 --> Helper loaded: form_helper
INFO - 2018-02-12 15:00:35 --> Form Validation Class Initialized
INFO - 2018-02-12 15:00:35 --> Controller Class Initialized
INFO - 2018-02-12 15:00:35 --> Model Class Initialized
INFO - 2018-02-12 15:00:35 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 15:00:35 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 15:00:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 15:00:35 --> Model Class Initialized
INFO - 2018-02-12 15:00:35 --> Model Class Initialized
INFO - 2018-02-12 15:00:35 --> Model Class Initialized
INFO - 2018-02-12 15:00:35 --> Model Class Initialized
INFO - 2018-02-12 15:00:35 --> Model Class Initialized
INFO - 2018-02-12 15:00:35 --> Model Class Initialized
INFO - 2018-02-12 15:00:35 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 15:00:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-12 15:00:35 --> Final output sent to browser
DEBUG - 2018-02-12 15:00:35 --> Total execution time: 0.1213
INFO - 2018-02-12 09:30:36 --> Config Class Initialized
INFO - 2018-02-12 09:30:36 --> Hooks Class Initialized
DEBUG - 2018-02-12 09:30:36 --> UTF-8 Support Enabled
INFO - 2018-02-12 09:30:36 --> Utf8 Class Initialized
INFO - 2018-02-12 09:30:36 --> URI Class Initialized
INFO - 2018-02-12 09:30:36 --> Router Class Initialized
INFO - 2018-02-12 09:30:36 --> Output Class Initialized
INFO - 2018-02-12 09:30:36 --> Security Class Initialized
DEBUG - 2018-02-12 09:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 09:30:36 --> Input Class Initialized
INFO - 2018-02-12 09:30:36 --> Language Class Initialized
INFO - 2018-02-12 09:30:36 --> Language Class Initialized
INFO - 2018-02-12 09:30:36 --> Config Class Initialized
INFO - 2018-02-12 09:30:36 --> Loader Class Initialized
INFO - 2018-02-12 15:00:36 --> Helper loaded: url_helper
INFO - 2018-02-12 15:00:36 --> Helper loaded: notification_helper
INFO - 2018-02-12 15:00:36 --> Helper loaded: settings_helper
INFO - 2018-02-12 15:00:36 --> Helper loaded: permission_helper
INFO - 2018-02-12 15:00:36 --> Helper loaded: users_helper
INFO - 2018-02-12 15:00:36 --> Database Driver Class Initialized
DEBUG - 2018-02-12 15:00:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 15:00:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 15:00:36 --> Helper loaded: form_helper
INFO - 2018-02-12 15:00:36 --> Form Validation Class Initialized
INFO - 2018-02-12 15:00:36 --> Controller Class Initialized
INFO - 2018-02-12 15:00:36 --> Model Class Initialized
INFO - 2018-02-12 15:00:36 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 15:00:36 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 15:00:36 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 15:00:36 --> Model Class Initialized
INFO - 2018-02-12 15:00:36 --> Model Class Initialized
INFO - 2018-02-12 15:00:36 --> Model Class Initialized
INFO - 2018-02-12 15:00:36 --> Model Class Initialized
INFO - 2018-02-12 15:00:36 --> Model Class Initialized
INFO - 2018-02-12 15:00:36 --> Model Class Initialized
INFO - 2018-02-12 15:00:36 --> Model Class Initialized
INFO - 2018-02-12 15:00:36 --> Model Class Initialized
INFO - 2018-02-12 15:00:36 --> Model Class Initialized
INFO - 2018-02-12 15:00:36 --> Model Class Initialized
INFO - 2018-02-12 15:00:36 --> Model Class Initialized
INFO - 2018-02-12 15:00:36 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 15:00:36 --> Model Class Initialized
INFO - 2018-02-12 15:00:36 --> Final output sent to browser
DEBUG - 2018-02-12 15:00:36 --> Total execution time: 0.1381
INFO - 2018-02-12 10:26:29 --> Config Class Initialized
INFO - 2018-02-12 10:26:29 --> Hooks Class Initialized
DEBUG - 2018-02-12 10:26:29 --> UTF-8 Support Enabled
INFO - 2018-02-12 10:26:29 --> Utf8 Class Initialized
INFO - 2018-02-12 10:26:29 --> URI Class Initialized
INFO - 2018-02-12 10:26:29 --> Router Class Initialized
INFO - 2018-02-12 10:26:29 --> Output Class Initialized
INFO - 2018-02-12 10:26:29 --> Security Class Initialized
DEBUG - 2018-02-12 10:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 10:26:29 --> Input Class Initialized
INFO - 2018-02-12 10:26:29 --> Language Class Initialized
INFO - 2018-02-12 10:26:29 --> Language Class Initialized
INFO - 2018-02-12 10:26:29 --> Config Class Initialized
INFO - 2018-02-12 10:26:29 --> Loader Class Initialized
INFO - 2018-02-12 15:56:29 --> Helper loaded: url_helper
INFO - 2018-02-12 15:56:29 --> Helper loaded: notification_helper
INFO - 2018-02-12 15:56:29 --> Helper loaded: settings_helper
INFO - 2018-02-12 15:56:29 --> Helper loaded: permission_helper
INFO - 2018-02-12 15:56:29 --> Helper loaded: users_helper
INFO - 2018-02-12 15:56:29 --> Database Driver Class Initialized
DEBUG - 2018-02-12 15:56:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 15:56:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 15:56:29 --> Helper loaded: form_helper
INFO - 2018-02-12 15:56:29 --> Form Validation Class Initialized
INFO - 2018-02-12 15:56:29 --> Controller Class Initialized
INFO - 2018-02-12 15:56:29 --> Model Class Initialized
INFO - 2018-02-12 15:56:29 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 15:56:29 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 15:56:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 15:56:29 --> Model Class Initialized
INFO - 2018-02-12 15:56:29 --> Model Class Initialized
INFO - 2018-02-12 15:56:29 --> Model Class Initialized
INFO - 2018-02-12 15:56:29 --> Model Class Initialized
INFO - 2018-02-12 15:56:29 --> Model Class Initialized
INFO - 2018-02-12 15:56:29 --> Model Class Initialized
INFO - 2018-02-12 15:56:29 --> Model Class Initialized
INFO - 2018-02-12 15:56:29 --> Model Class Initialized
INFO - 2018-02-12 15:56:29 --> Model Class Initialized
INFO - 2018-02-12 15:56:29 --> Model Class Initialized
INFO - 2018-02-12 15:56:29 --> Model Class Initialized
INFO - 2018-02-12 15:56:29 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 15:56:29 --> Model Class Initialized
INFO - 2018-02-12 15:56:29 --> Final output sent to browser
DEBUG - 2018-02-12 15:56:29 --> Total execution time: 0.1375
INFO - 2018-02-12 10:26:56 --> Config Class Initialized
INFO - 2018-02-12 10:26:56 --> Hooks Class Initialized
DEBUG - 2018-02-12 10:26:56 --> UTF-8 Support Enabled
INFO - 2018-02-12 10:26:56 --> Utf8 Class Initialized
INFO - 2018-02-12 10:26:56 --> URI Class Initialized
INFO - 2018-02-12 10:26:56 --> Router Class Initialized
INFO - 2018-02-12 10:26:56 --> Output Class Initialized
INFO - 2018-02-12 10:26:56 --> Security Class Initialized
DEBUG - 2018-02-12 10:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 10:26:56 --> Input Class Initialized
INFO - 2018-02-12 10:26:56 --> Language Class Initialized
INFO - 2018-02-12 10:26:56 --> Language Class Initialized
INFO - 2018-02-12 10:26:56 --> Config Class Initialized
INFO - 2018-02-12 10:26:56 --> Loader Class Initialized
INFO - 2018-02-12 15:56:56 --> Helper loaded: url_helper
INFO - 2018-02-12 15:56:56 --> Helper loaded: notification_helper
INFO - 2018-02-12 15:56:56 --> Helper loaded: settings_helper
INFO - 2018-02-12 15:56:56 --> Helper loaded: permission_helper
INFO - 2018-02-12 15:56:56 --> Helper loaded: users_helper
INFO - 2018-02-12 15:56:56 --> Database Driver Class Initialized
DEBUG - 2018-02-12 15:56:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 15:56:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 15:56:56 --> Helper loaded: form_helper
INFO - 2018-02-12 15:56:56 --> Form Validation Class Initialized
INFO - 2018-02-12 15:56:56 --> Controller Class Initialized
INFO - 2018-02-12 15:56:56 --> Model Class Initialized
INFO - 2018-02-12 15:56:56 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 15:56:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 15:56:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 15:56:56 --> Model Class Initialized
INFO - 2018-02-12 15:56:56 --> Model Class Initialized
INFO - 2018-02-12 15:56:56 --> Model Class Initialized
INFO - 2018-02-12 15:56:56 --> Model Class Initialized
INFO - 2018-02-12 15:56:56 --> Model Class Initialized
INFO - 2018-02-12 15:56:56 --> Model Class Initialized
INFO - 2018-02-12 15:56:56 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 15:56:56 --> Model Class Initialized
INFO - 2018-02-12 15:56:56 --> Final output sent to browser
DEBUG - 2018-02-12 15:56:56 --> Total execution time: 0.1194
INFO - 2018-02-12 10:26:56 --> Config Class Initialized
INFO - 2018-02-12 10:26:56 --> Hooks Class Initialized
DEBUG - 2018-02-12 10:26:56 --> UTF-8 Support Enabled
INFO - 2018-02-12 10:26:56 --> Utf8 Class Initialized
INFO - 2018-02-12 10:26:56 --> URI Class Initialized
INFO - 2018-02-12 10:26:56 --> Router Class Initialized
INFO - 2018-02-12 10:26:56 --> Output Class Initialized
INFO - 2018-02-12 10:26:56 --> Security Class Initialized
DEBUG - 2018-02-12 10:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 10:26:56 --> Input Class Initialized
INFO - 2018-02-12 10:26:56 --> Language Class Initialized
INFO - 2018-02-12 10:26:56 --> Language Class Initialized
INFO - 2018-02-12 10:26:56 --> Config Class Initialized
INFO - 2018-02-12 10:26:56 --> Loader Class Initialized
INFO - 2018-02-12 15:56:56 --> Helper loaded: url_helper
INFO - 2018-02-12 15:56:56 --> Helper loaded: notification_helper
INFO - 2018-02-12 15:56:56 --> Helper loaded: settings_helper
INFO - 2018-02-12 15:56:56 --> Helper loaded: permission_helper
INFO - 2018-02-12 15:56:56 --> Helper loaded: users_helper
INFO - 2018-02-12 15:56:56 --> Database Driver Class Initialized
DEBUG - 2018-02-12 15:56:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 15:56:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 15:56:56 --> Helper loaded: form_helper
INFO - 2018-02-12 15:56:56 --> Form Validation Class Initialized
INFO - 2018-02-12 15:56:56 --> Controller Class Initialized
INFO - 2018-02-12 15:56:56 --> Model Class Initialized
INFO - 2018-02-12 15:56:56 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 15:56:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 15:56:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 15:56:56 --> Model Class Initialized
INFO - 2018-02-12 15:56:56 --> Model Class Initialized
INFO - 2018-02-12 15:56:56 --> Model Class Initialized
INFO - 2018-02-12 15:56:56 --> Model Class Initialized
INFO - 2018-02-12 15:56:56 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 15:56:56 --> Final output sent to browser
DEBUG - 2018-02-12 15:56:56 --> Total execution time: 0.0808
INFO - 2018-02-12 10:26:56 --> Config Class Initialized
INFO - 2018-02-12 10:26:56 --> Hooks Class Initialized
DEBUG - 2018-02-12 10:26:56 --> UTF-8 Support Enabled
INFO - 2018-02-12 10:26:56 --> Utf8 Class Initialized
INFO - 2018-02-12 10:26:56 --> URI Class Initialized
INFO - 2018-02-12 10:26:56 --> Router Class Initialized
INFO - 2018-02-12 10:26:57 --> Output Class Initialized
INFO - 2018-02-12 10:26:57 --> Security Class Initialized
DEBUG - 2018-02-12 10:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 10:26:57 --> Input Class Initialized
INFO - 2018-02-12 10:26:57 --> Language Class Initialized
INFO - 2018-02-12 10:26:57 --> Language Class Initialized
INFO - 2018-02-12 10:26:57 --> Config Class Initialized
INFO - 2018-02-12 10:26:57 --> Loader Class Initialized
INFO - 2018-02-12 15:56:57 --> Helper loaded: url_helper
INFO - 2018-02-12 15:56:57 --> Helper loaded: notification_helper
INFO - 2018-02-12 15:56:57 --> Helper loaded: settings_helper
INFO - 2018-02-12 15:56:57 --> Helper loaded: permission_helper
INFO - 2018-02-12 15:56:57 --> Helper loaded: users_helper
INFO - 2018-02-12 15:56:57 --> Database Driver Class Initialized
DEBUG - 2018-02-12 15:56:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 15:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 15:56:57 --> Helper loaded: form_helper
INFO - 2018-02-12 15:56:57 --> Form Validation Class Initialized
INFO - 2018-02-12 15:56:57 --> Controller Class Initialized
INFO - 2018-02-12 15:56:57 --> Model Class Initialized
INFO - 2018-02-12 15:56:57 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 15:56:57 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 15:56:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 15:56:57 --> Model Class Initialized
INFO - 2018-02-12 15:56:57 --> Model Class Initialized
INFO - 2018-02-12 15:56:57 --> Model Class Initialized
INFO - 2018-02-12 15:56:57 --> Model Class Initialized
INFO - 2018-02-12 15:56:57 --> Model Class Initialized
INFO - 2018-02-12 15:56:57 --> Model Class Initialized
INFO - 2018-02-12 15:56:57 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-02-12 15:56:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-02-12 15:56:57 --> Final output sent to browser
DEBUG - 2018-02-12 15:56:57 --> Total execution time: 0.1114
INFO - 2018-02-12 10:27:22 --> Config Class Initialized
INFO - 2018-02-12 10:27:22 --> Hooks Class Initialized
DEBUG - 2018-02-12 10:27:22 --> UTF-8 Support Enabled
INFO - 2018-02-12 10:27:22 --> Utf8 Class Initialized
INFO - 2018-02-12 10:27:22 --> URI Class Initialized
INFO - 2018-02-12 10:27:22 --> Router Class Initialized
INFO - 2018-02-12 10:27:22 --> Output Class Initialized
INFO - 2018-02-12 10:27:22 --> Security Class Initialized
DEBUG - 2018-02-12 10:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 10:27:22 --> Input Class Initialized
INFO - 2018-02-12 10:27:22 --> Language Class Initialized
INFO - 2018-02-12 10:27:22 --> Language Class Initialized
INFO - 2018-02-12 10:27:22 --> Config Class Initialized
INFO - 2018-02-12 10:27:22 --> Loader Class Initialized
INFO - 2018-02-12 15:57:22 --> Helper loaded: url_helper
INFO - 2018-02-12 15:57:22 --> Helper loaded: notification_helper
INFO - 2018-02-12 15:57:22 --> Helper loaded: settings_helper
INFO - 2018-02-12 15:57:22 --> Helper loaded: permission_helper
INFO - 2018-02-12 15:57:22 --> Helper loaded: users_helper
INFO - 2018-02-12 15:57:22 --> Database Driver Class Initialized
DEBUG - 2018-02-12 15:57:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 15:57:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 15:57:22 --> Helper loaded: form_helper
INFO - 2018-02-12 15:57:22 --> Form Validation Class Initialized
INFO - 2018-02-12 15:57:22 --> Controller Class Initialized
INFO - 2018-02-12 15:57:22 --> Model Class Initialized
INFO - 2018-02-12 15:57:22 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 15:57:22 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 15:57:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 15:57:22 --> Model Class Initialized
INFO - 2018-02-12 15:57:22 --> Model Class Initialized
INFO - 2018-02-12 15:57:22 --> Model Class Initialized
INFO - 2018-02-12 15:57:22 --> Model Class Initialized
INFO - 2018-02-12 15:57:22 --> Model Class Initialized
INFO - 2018-02-12 15:57:22 --> Model Class Initialized
INFO - 2018-02-12 15:57:22 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 15:57:22 --> Final output sent to browser
DEBUG - 2018-02-12 15:57:22 --> Total execution time: 0.0958
INFO - 2018-02-12 10:28:37 --> Config Class Initialized
INFO - 2018-02-12 10:28:37 --> Hooks Class Initialized
DEBUG - 2018-02-12 10:28:37 --> UTF-8 Support Enabled
INFO - 2018-02-12 10:28:37 --> Utf8 Class Initialized
INFO - 2018-02-12 10:28:37 --> URI Class Initialized
INFO - 2018-02-12 10:28:37 --> Router Class Initialized
INFO - 2018-02-12 10:28:37 --> Output Class Initialized
INFO - 2018-02-12 10:28:37 --> Security Class Initialized
DEBUG - 2018-02-12 10:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 10:28:37 --> Input Class Initialized
INFO - 2018-02-12 10:28:37 --> Language Class Initialized
INFO - 2018-02-12 10:28:37 --> Language Class Initialized
INFO - 2018-02-12 10:28:37 --> Config Class Initialized
INFO - 2018-02-12 10:28:37 --> Loader Class Initialized
INFO - 2018-02-12 15:58:37 --> Helper loaded: url_helper
INFO - 2018-02-12 15:58:37 --> Helper loaded: notification_helper
INFO - 2018-02-12 15:58:37 --> Helper loaded: settings_helper
INFO - 2018-02-12 15:58:37 --> Helper loaded: permission_helper
INFO - 2018-02-12 15:58:37 --> Helper loaded: users_helper
INFO - 2018-02-12 15:58:37 --> Database Driver Class Initialized
DEBUG - 2018-02-12 15:58:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 15:58:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 15:58:37 --> Helper loaded: form_helper
INFO - 2018-02-12 15:58:37 --> Form Validation Class Initialized
INFO - 2018-02-12 15:58:37 --> Controller Class Initialized
INFO - 2018-02-12 15:58:37 --> Model Class Initialized
INFO - 2018-02-12 15:58:37 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 15:58:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 15:58:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 15:58:37 --> Model Class Initialized
INFO - 2018-02-12 15:58:37 --> Model Class Initialized
INFO - 2018-02-12 15:58:37 --> Model Class Initialized
INFO - 2018-02-12 15:58:37 --> Model Class Initialized
INFO - 2018-02-12 15:58:37 --> Model Class Initialized
INFO - 2018-02-12 15:58:37 --> Model Class Initialized
INFO - 2018-02-12 15:58:37 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 15:58:37 --> Final output sent to browser
DEBUG - 2018-02-12 15:58:37 --> Total execution time: 0.1059
INFO - 2018-02-12 10:36:47 --> Config Class Initialized
INFO - 2018-02-12 10:36:47 --> Hooks Class Initialized
DEBUG - 2018-02-12 10:36:47 --> UTF-8 Support Enabled
INFO - 2018-02-12 10:36:47 --> Utf8 Class Initialized
INFO - 2018-02-12 10:36:47 --> URI Class Initialized
INFO - 2018-02-12 10:36:47 --> Router Class Initialized
INFO - 2018-02-12 10:36:47 --> Output Class Initialized
INFO - 2018-02-12 10:36:47 --> Security Class Initialized
DEBUG - 2018-02-12 10:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 10:36:47 --> Input Class Initialized
INFO - 2018-02-12 10:36:47 --> Language Class Initialized
INFO - 2018-02-12 10:36:47 --> Language Class Initialized
INFO - 2018-02-12 10:36:47 --> Config Class Initialized
INFO - 2018-02-12 10:36:47 --> Loader Class Initialized
INFO - 2018-02-12 16:06:47 --> Helper loaded: url_helper
INFO - 2018-02-12 16:06:47 --> Helper loaded: notification_helper
INFO - 2018-02-12 16:06:47 --> Helper loaded: settings_helper
INFO - 2018-02-12 16:06:47 --> Helper loaded: permission_helper
INFO - 2018-02-12 16:06:47 --> Helper loaded: users_helper
INFO - 2018-02-12 16:06:47 --> Database Driver Class Initialized
DEBUG - 2018-02-12 16:06:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 16:06:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 16:06:48 --> Helper loaded: form_helper
INFO - 2018-02-12 16:06:48 --> Form Validation Class Initialized
INFO - 2018-02-12 16:06:48 --> Controller Class Initialized
INFO - 2018-02-12 16:06:48 --> Model Class Initialized
INFO - 2018-02-12 16:06:48 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 16:06:48 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 16:06:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 16:06:48 --> Model Class Initialized
INFO - 2018-02-12 16:06:48 --> Model Class Initialized
INFO - 2018-02-12 16:06:48 --> Model Class Initialized
INFO - 2018-02-12 16:06:48 --> Model Class Initialized
INFO - 2018-02-12 16:06:48 --> Model Class Initialized
INFO - 2018-02-12 16:06:48 --> Model Class Initialized
INFO - 2018-02-12 16:06:48 --> Model Class Initialized
INFO - 2018-02-12 16:06:48 --> Model Class Initialized
INFO - 2018-02-12 16:06:48 --> Model Class Initialized
INFO - 2018-02-12 16:06:48 --> Model Class Initialized
INFO - 2018-02-12 16:06:48 --> Model Class Initialized
INFO - 2018-02-12 16:06:48 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 16:06:48 --> Model Class Initialized
INFO - 2018-02-12 16:06:48 --> Final output sent to browser
DEBUG - 2018-02-12 16:06:48 --> Total execution time: 0.1476
INFO - 2018-02-12 10:36:48 --> Config Class Initialized
INFO - 2018-02-12 10:36:48 --> Hooks Class Initialized
DEBUG - 2018-02-12 10:36:48 --> UTF-8 Support Enabled
INFO - 2018-02-12 10:36:48 --> Utf8 Class Initialized
INFO - 2018-02-12 10:36:48 --> URI Class Initialized
INFO - 2018-02-12 10:36:48 --> Router Class Initialized
INFO - 2018-02-12 10:36:48 --> Output Class Initialized
INFO - 2018-02-12 10:36:48 --> Security Class Initialized
DEBUG - 2018-02-12 10:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 10:36:48 --> Input Class Initialized
INFO - 2018-02-12 10:36:48 --> Language Class Initialized
INFO - 2018-02-12 10:36:48 --> Language Class Initialized
INFO - 2018-02-12 10:36:48 --> Config Class Initialized
INFO - 2018-02-12 10:36:48 --> Loader Class Initialized
INFO - 2018-02-12 16:06:48 --> Helper loaded: url_helper
INFO - 2018-02-12 16:06:48 --> Helper loaded: notification_helper
INFO - 2018-02-12 16:06:48 --> Helper loaded: settings_helper
INFO - 2018-02-12 16:06:48 --> Helper loaded: permission_helper
INFO - 2018-02-12 16:06:48 --> Helper loaded: users_helper
INFO - 2018-02-12 16:06:48 --> Database Driver Class Initialized
DEBUG - 2018-02-12 16:06:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 16:06:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 16:06:48 --> Helper loaded: form_helper
INFO - 2018-02-12 16:06:48 --> Form Validation Class Initialized
INFO - 2018-02-12 16:06:48 --> Controller Class Initialized
INFO - 2018-02-12 16:06:48 --> Model Class Initialized
INFO - 2018-02-12 16:06:48 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 16:06:48 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 16:06:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 16:06:48 --> Model Class Initialized
INFO - 2018-02-12 16:06:48 --> Model Class Initialized
INFO - 2018-02-12 16:06:48 --> Model Class Initialized
INFO - 2018-02-12 16:06:48 --> Model Class Initialized
INFO - 2018-02-12 16:06:48 --> Model Class Initialized
INFO - 2018-02-12 16:06:48 --> Model Class Initialized
INFO - 2018-02-12 16:06:48 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 16:06:48 --> Model Class Initialized
INFO - 2018-02-12 16:06:48 --> Final output sent to browser
DEBUG - 2018-02-12 16:06:48 --> Total execution time: 0.1094
INFO - 2018-02-12 10:38:07 --> Config Class Initialized
INFO - 2018-02-12 10:38:07 --> Hooks Class Initialized
DEBUG - 2018-02-12 10:38:07 --> UTF-8 Support Enabled
INFO - 2018-02-12 10:38:07 --> Utf8 Class Initialized
INFO - 2018-02-12 10:38:07 --> URI Class Initialized
INFO - 2018-02-12 10:38:07 --> Router Class Initialized
INFO - 2018-02-12 10:38:07 --> Output Class Initialized
INFO - 2018-02-12 10:38:07 --> Security Class Initialized
DEBUG - 2018-02-12 10:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 10:38:07 --> Input Class Initialized
INFO - 2018-02-12 10:38:07 --> Language Class Initialized
INFO - 2018-02-12 10:38:07 --> Language Class Initialized
INFO - 2018-02-12 10:38:07 --> Config Class Initialized
INFO - 2018-02-12 10:38:07 --> Loader Class Initialized
INFO - 2018-02-12 16:08:07 --> Helper loaded: url_helper
INFO - 2018-02-12 16:08:07 --> Helper loaded: notification_helper
INFO - 2018-02-12 16:08:07 --> Helper loaded: settings_helper
INFO - 2018-02-12 16:08:07 --> Helper loaded: permission_helper
INFO - 2018-02-12 16:08:07 --> Helper loaded: users_helper
INFO - 2018-02-12 16:08:07 --> Database Driver Class Initialized
DEBUG - 2018-02-12 16:08:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 16:08:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 16:08:07 --> Helper loaded: form_helper
INFO - 2018-02-12 16:08:07 --> Form Validation Class Initialized
INFO - 2018-02-12 16:08:07 --> Controller Class Initialized
DEBUG - 2018-02-12 16:08:07 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-02-12 16:08:07 --> Final output sent to browser
DEBUG - 2018-02-12 16:08:07 --> Total execution time: 0.0700
INFO - 2018-02-12 10:38:12 --> Config Class Initialized
INFO - 2018-02-12 10:38:12 --> Hooks Class Initialized
INFO - 2018-02-12 10:38:12 --> Config Class Initialized
INFO - 2018-02-12 10:38:12 --> Hooks Class Initialized
DEBUG - 2018-02-12 10:38:12 --> UTF-8 Support Enabled
INFO - 2018-02-12 10:38:12 --> Utf8 Class Initialized
DEBUG - 2018-02-12 10:38:12 --> UTF-8 Support Enabled
INFO - 2018-02-12 10:38:12 --> Utf8 Class Initialized
INFO - 2018-02-12 10:38:12 --> URI Class Initialized
INFO - 2018-02-12 10:38:12 --> URI Class Initialized
INFO - 2018-02-12 10:38:12 --> Router Class Initialized
INFO - 2018-02-12 10:38:12 --> Router Class Initialized
INFO - 2018-02-12 10:38:12 --> Output Class Initialized
INFO - 2018-02-12 10:38:12 --> Output Class Initialized
INFO - 2018-02-12 10:38:12 --> Security Class Initialized
INFO - 2018-02-12 10:38:12 --> Security Class Initialized
DEBUG - 2018-02-12 10:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 10:38:12 --> Input Class Initialized
INFO - 2018-02-12 10:38:12 --> Language Class Initialized
DEBUG - 2018-02-12 10:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 10:38:12 --> Input Class Initialized
INFO - 2018-02-12 10:38:12 --> Language Class Initialized
INFO - 2018-02-12 10:38:12 --> Language Class Initialized
INFO - 2018-02-12 10:38:12 --> Config Class Initialized
INFO - 2018-02-12 10:38:12 --> Loader Class Initialized
INFO - 2018-02-12 10:38:12 --> Language Class Initialized
INFO - 2018-02-12 10:38:12 --> Config Class Initialized
INFO - 2018-02-12 10:38:12 --> Loader Class Initialized
INFO - 2018-02-12 16:08:12 --> Helper loaded: url_helper
INFO - 2018-02-12 16:08:12 --> Helper loaded: notification_helper
INFO - 2018-02-12 16:08:12 --> Helper loaded: settings_helper
INFO - 2018-02-12 16:08:12 --> Helper loaded: url_helper
INFO - 2018-02-12 16:08:12 --> Helper loaded: permission_helper
INFO - 2018-02-12 16:08:12 --> Helper loaded: notification_helper
INFO - 2018-02-12 16:08:12 --> Helper loaded: users_helper
INFO - 2018-02-12 16:08:12 --> Helper loaded: settings_helper
INFO - 2018-02-12 16:08:12 --> Helper loaded: permission_helper
INFO - 2018-02-12 16:08:12 --> Helper loaded: users_helper
INFO - 2018-02-12 16:08:12 --> Database Driver Class Initialized
INFO - 2018-02-12 16:08:12 --> Database Driver Class Initialized
DEBUG - 2018-02-12 16:08:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 16:08:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-12 16:08:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 16:08:12 --> Helper loaded: form_helper
INFO - 2018-02-12 16:08:12 --> Form Validation Class Initialized
INFO - 2018-02-12 16:08:12 --> Controller Class Initialized
INFO - 2018-02-12 16:08:12 --> Model Class Initialized
INFO - 2018-02-12 16:08:12 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 16:08:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 16:08:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 16:08:12 --> Model Class Initialized
INFO - 2018-02-12 16:08:12 --> Model Class Initialized
INFO - 2018-02-12 16:08:12 --> Model Class Initialized
INFO - 2018-02-12 16:08:12 --> Model Class Initialized
INFO - 2018-02-12 16:08:12 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 16:08:12 --> Final output sent to browser
DEBUG - 2018-02-12 16:08:12 --> Total execution time: 0.1085
INFO - 2018-02-12 16:08:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 16:08:12 --> Helper loaded: form_helper
INFO - 2018-02-12 16:08:12 --> Form Validation Class Initialized
INFO - 2018-02-12 16:08:12 --> Controller Class Initialized
INFO - 2018-02-12 16:08:12 --> Model Class Initialized
INFO - 2018-02-12 16:08:12 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 16:08:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 16:08:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 16:08:12 --> Model Class Initialized
INFO - 2018-02-12 16:08:12 --> Model Class Initialized
INFO - 2018-02-12 16:08:12 --> Model Class Initialized
INFO - 2018-02-12 16:08:12 --> Model Class Initialized
INFO - 2018-02-12 16:08:12 --> Model Class Initialized
INFO - 2018-02-12 16:08:12 --> Model Class Initialized
INFO - 2018-02-12 16:08:12 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-02-12 16:08:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-02-12 16:08:12 --> Final output sent to browser
DEBUG - 2018-02-12 16:08:12 --> Total execution time: 0.1462
INFO - 2018-02-12 10:38:16 --> Config Class Initialized
INFO - 2018-02-12 10:38:16 --> Hooks Class Initialized
DEBUG - 2018-02-12 10:38:16 --> UTF-8 Support Enabled
INFO - 2018-02-12 10:38:16 --> Utf8 Class Initialized
INFO - 2018-02-12 10:38:16 --> URI Class Initialized
INFO - 2018-02-12 10:38:16 --> Router Class Initialized
INFO - 2018-02-12 10:38:16 --> Output Class Initialized
INFO - 2018-02-12 10:38:16 --> Security Class Initialized
DEBUG - 2018-02-12 10:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 10:38:16 --> Input Class Initialized
INFO - 2018-02-12 10:38:16 --> Language Class Initialized
INFO - 2018-02-12 10:38:16 --> Language Class Initialized
INFO - 2018-02-12 10:38:16 --> Config Class Initialized
INFO - 2018-02-12 10:38:16 --> Loader Class Initialized
INFO - 2018-02-12 16:08:16 --> Helper loaded: url_helper
INFO - 2018-02-12 16:08:16 --> Helper loaded: notification_helper
INFO - 2018-02-12 16:08:16 --> Helper loaded: settings_helper
INFO - 2018-02-12 16:08:16 --> Helper loaded: permission_helper
INFO - 2018-02-12 16:08:16 --> Helper loaded: users_helper
INFO - 2018-02-12 16:08:16 --> Database Driver Class Initialized
DEBUG - 2018-02-12 16:08:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 16:08:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 16:08:16 --> Helper loaded: form_helper
INFO - 2018-02-12 16:08:16 --> Form Validation Class Initialized
INFO - 2018-02-12 16:08:16 --> Controller Class Initialized
INFO - 2018-02-12 16:08:16 --> Model Class Initialized
INFO - 2018-02-12 16:08:16 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 16:08:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 16:08:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 16:08:16 --> Model Class Initialized
INFO - 2018-02-12 16:08:16 --> Model Class Initialized
INFO - 2018-02-12 16:08:16 --> Model Class Initialized
INFO - 2018-02-12 16:08:16 --> Model Class Initialized
INFO - 2018-02-12 16:08:16 --> Model Class Initialized
INFO - 2018-02-12 16:08:16 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 16:08:16 --> Model Class Initialized
INFO - 2018-02-12 16:08:16 --> Final output sent to browser
DEBUG - 2018-02-12 16:08:16 --> Total execution time: 0.1186
INFO - 2018-02-12 10:38:16 --> Config Class Initialized
INFO - 2018-02-12 10:38:16 --> Hooks Class Initialized
DEBUG - 2018-02-12 10:38:16 --> UTF-8 Support Enabled
INFO - 2018-02-12 10:38:16 --> Utf8 Class Initialized
INFO - 2018-02-12 10:38:16 --> URI Class Initialized
INFO - 2018-02-12 10:38:16 --> Router Class Initialized
INFO - 2018-02-12 10:38:16 --> Output Class Initialized
INFO - 2018-02-12 10:38:16 --> Security Class Initialized
DEBUG - 2018-02-12 10:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 10:38:16 --> Input Class Initialized
INFO - 2018-02-12 10:38:16 --> Language Class Initialized
INFO - 2018-02-12 10:38:16 --> Language Class Initialized
INFO - 2018-02-12 10:38:16 --> Config Class Initialized
INFO - 2018-02-12 10:38:16 --> Loader Class Initialized
INFO - 2018-02-12 16:08:16 --> Helper loaded: url_helper
INFO - 2018-02-12 16:08:16 --> Helper loaded: notification_helper
INFO - 2018-02-12 16:08:16 --> Helper loaded: settings_helper
INFO - 2018-02-12 16:08:16 --> Helper loaded: permission_helper
INFO - 2018-02-12 16:08:16 --> Helper loaded: users_helper
INFO - 2018-02-12 16:08:16 --> Database Driver Class Initialized
DEBUG - 2018-02-12 16:08:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 16:08:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 16:08:16 --> Helper loaded: form_helper
INFO - 2018-02-12 16:08:16 --> Form Validation Class Initialized
INFO - 2018-02-12 16:08:16 --> Controller Class Initialized
INFO - 2018-02-12 16:08:16 --> Model Class Initialized
INFO - 2018-02-12 16:08:16 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 16:08:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 16:08:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 16:08:16 --> Model Class Initialized
INFO - 2018-02-12 16:08:16 --> Model Class Initialized
INFO - 2018-02-12 16:08:16 --> Model Class Initialized
INFO - 2018-02-12 16:08:16 --> Model Class Initialized
INFO - 2018-02-12 16:08:16 --> Model Class Initialized
INFO - 2018-02-12 16:08:16 --> Model Class Initialized
INFO - 2018-02-12 16:08:16 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-02-12 16:08:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-02-12 16:08:16 --> Final output sent to browser
DEBUG - 2018-02-12 16:08:16 --> Total execution time: 0.1169
INFO - 2018-02-12 10:38:18 --> Config Class Initialized
INFO - 2018-02-12 10:38:18 --> Hooks Class Initialized
DEBUG - 2018-02-12 10:38:18 --> UTF-8 Support Enabled
INFO - 2018-02-12 10:38:18 --> Utf8 Class Initialized
INFO - 2018-02-12 10:38:18 --> URI Class Initialized
INFO - 2018-02-12 10:38:18 --> Router Class Initialized
INFO - 2018-02-12 10:38:18 --> Output Class Initialized
INFO - 2018-02-12 10:38:18 --> Security Class Initialized
DEBUG - 2018-02-12 10:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 10:38:18 --> Input Class Initialized
INFO - 2018-02-12 10:38:18 --> Language Class Initialized
INFO - 2018-02-12 10:38:18 --> Language Class Initialized
INFO - 2018-02-12 10:38:18 --> Config Class Initialized
INFO - 2018-02-12 10:38:18 --> Loader Class Initialized
INFO - 2018-02-12 16:08:18 --> Helper loaded: url_helper
INFO - 2018-02-12 16:08:18 --> Helper loaded: notification_helper
INFO - 2018-02-12 16:08:18 --> Helper loaded: settings_helper
INFO - 2018-02-12 16:08:18 --> Helper loaded: permission_helper
INFO - 2018-02-12 16:08:18 --> Helper loaded: users_helper
INFO - 2018-02-12 16:08:18 --> Database Driver Class Initialized
DEBUG - 2018-02-12 16:08:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 16:08:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 16:08:18 --> Helper loaded: form_helper
INFO - 2018-02-12 16:08:18 --> Form Validation Class Initialized
INFO - 2018-02-12 16:08:18 --> Controller Class Initialized
INFO - 2018-02-12 16:08:18 --> Model Class Initialized
INFO - 2018-02-12 16:08:18 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 16:08:18 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 16:08:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 16:08:18 --> Model Class Initialized
INFO - 2018-02-12 16:08:18 --> Model Class Initialized
INFO - 2018-02-12 16:08:18 --> Model Class Initialized
INFO - 2018-02-12 16:08:18 --> Model Class Initialized
INFO - 2018-02-12 16:08:18 --> Model Class Initialized
INFO - 2018-02-12 16:08:18 --> Model Class Initialized
INFO - 2018-02-12 16:08:18 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-02-12 16:08:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-02-12 16:08:18 --> Final output sent to browser
DEBUG - 2018-02-12 16:08:18 --> Total execution time: 0.0932
INFO - 2018-02-12 10:38:32 --> Config Class Initialized
INFO - 2018-02-12 10:38:32 --> Hooks Class Initialized
DEBUG - 2018-02-12 10:38:32 --> UTF-8 Support Enabled
INFO - 2018-02-12 10:38:32 --> Utf8 Class Initialized
INFO - 2018-02-12 10:38:32 --> URI Class Initialized
INFO - 2018-02-12 10:38:32 --> Router Class Initialized
INFO - 2018-02-12 10:38:32 --> Output Class Initialized
INFO - 2018-02-12 10:38:32 --> Security Class Initialized
DEBUG - 2018-02-12 10:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 10:38:32 --> Input Class Initialized
INFO - 2018-02-12 10:38:32 --> Language Class Initialized
INFO - 2018-02-12 10:38:32 --> Language Class Initialized
INFO - 2018-02-12 10:38:32 --> Config Class Initialized
INFO - 2018-02-12 10:38:32 --> Loader Class Initialized
INFO - 2018-02-12 16:08:32 --> Helper loaded: url_helper
INFO - 2018-02-12 16:08:32 --> Helper loaded: notification_helper
INFO - 2018-02-12 16:08:32 --> Helper loaded: settings_helper
INFO - 2018-02-12 16:08:32 --> Helper loaded: permission_helper
INFO - 2018-02-12 16:08:32 --> Helper loaded: users_helper
INFO - 2018-02-12 16:08:32 --> Database Driver Class Initialized
DEBUG - 2018-02-12 16:08:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 16:08:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 16:08:32 --> Helper loaded: form_helper
INFO - 2018-02-12 16:08:32 --> Form Validation Class Initialized
INFO - 2018-02-12 16:08:32 --> Controller Class Initialized
INFO - 2018-02-12 16:08:32 --> Model Class Initialized
INFO - 2018-02-12 16:08:32 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 16:08:32 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 16:08:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 16:08:32 --> Model Class Initialized
INFO - 2018-02-12 16:08:32 --> Model Class Initialized
INFO - 2018-02-12 16:08:32 --> Model Class Initialized
INFO - 2018-02-12 16:08:32 --> Model Class Initialized
INFO - 2018-02-12 16:08:32 --> Model Class Initialized
INFO - 2018-02-12 16:08:32 --> Model Class Initialized
INFO - 2018-02-12 16:08:32 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 16:08:32 --> Final output sent to browser
DEBUG - 2018-02-12 16:08:32 --> Total execution time: 0.1077
INFO - 2018-02-12 10:38:50 --> Config Class Initialized
INFO - 2018-02-12 10:38:50 --> Hooks Class Initialized
DEBUG - 2018-02-12 10:38:50 --> UTF-8 Support Enabled
INFO - 2018-02-12 10:38:50 --> Utf8 Class Initialized
INFO - 2018-02-12 10:38:50 --> URI Class Initialized
DEBUG - 2018-02-12 10:38:50 --> No URI present. Default controller set.
INFO - 2018-02-12 10:38:50 --> Router Class Initialized
INFO - 2018-02-12 10:38:50 --> Output Class Initialized
INFO - 2018-02-12 10:38:50 --> Security Class Initialized
DEBUG - 2018-02-12 10:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 10:38:50 --> Input Class Initialized
INFO - 2018-02-12 10:38:50 --> Language Class Initialized
INFO - 2018-02-12 10:38:50 --> Language Class Initialized
INFO - 2018-02-12 10:38:50 --> Config Class Initialized
INFO - 2018-02-12 10:38:50 --> Loader Class Initialized
INFO - 2018-02-12 16:08:50 --> Helper loaded: url_helper
INFO - 2018-02-12 16:08:50 --> Helper loaded: notification_helper
INFO - 2018-02-12 16:08:50 --> Helper loaded: settings_helper
INFO - 2018-02-12 16:08:50 --> Helper loaded: permission_helper
INFO - 2018-02-12 16:08:50 --> Helper loaded: users_helper
INFO - 2018-02-12 16:08:50 --> Database Driver Class Initialized
DEBUG - 2018-02-12 16:08:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 16:08:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 16:08:50 --> Helper loaded: form_helper
INFO - 2018-02-12 16:08:50 --> Form Validation Class Initialized
INFO - 2018-02-12 16:08:50 --> Controller Class Initialized
INFO - 2018-02-12 16:08:50 --> Model Class Initialized
INFO - 2018-02-12 16:08:50 --> Helper loaded: inflector_helper
INFO - 2018-02-12 16:08:50 --> Model Class Initialized
DEBUG - 2018-02-12 16:08:50 --> File loaded: /home/pr01004/public_html/application/views/login.php
INFO - 2018-02-12 16:08:50 --> Final output sent to browser
DEBUG - 2018-02-12 16:08:50 --> Total execution time: 0.3677
INFO - 2018-02-12 10:45:34 --> Config Class Initialized
INFO - 2018-02-12 10:45:34 --> Hooks Class Initialized
DEBUG - 2018-02-12 10:45:34 --> UTF-8 Support Enabled
INFO - 2018-02-12 10:45:34 --> Utf8 Class Initialized
INFO - 2018-02-12 10:45:34 --> URI Class Initialized
INFO - 2018-02-12 10:45:34 --> Router Class Initialized
INFO - 2018-02-12 10:45:34 --> Output Class Initialized
INFO - 2018-02-12 10:45:34 --> Security Class Initialized
DEBUG - 2018-02-12 10:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 10:45:34 --> Input Class Initialized
INFO - 2018-02-12 10:45:34 --> Language Class Initialized
INFO - 2018-02-12 10:45:34 --> Language Class Initialized
INFO - 2018-02-12 10:45:34 --> Config Class Initialized
INFO - 2018-02-12 10:45:34 --> Loader Class Initialized
INFO - 2018-02-12 16:15:34 --> Helper loaded: url_helper
INFO - 2018-02-12 16:15:34 --> Helper loaded: notification_helper
INFO - 2018-02-12 16:15:34 --> Helper loaded: settings_helper
INFO - 2018-02-12 16:15:34 --> Helper loaded: permission_helper
INFO - 2018-02-12 16:15:34 --> Helper loaded: users_helper
INFO - 2018-02-12 16:15:34 --> Database Driver Class Initialized
DEBUG - 2018-02-12 16:15:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 16:15:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 16:15:34 --> Helper loaded: form_helper
INFO - 2018-02-12 16:15:34 --> Form Validation Class Initialized
INFO - 2018-02-12 16:15:34 --> Controller Class Initialized
INFO - 2018-02-12 16:15:34 --> Model Class Initialized
INFO - 2018-02-12 16:15:34 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 16:15:34 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 16:15:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 16:15:34 --> Model Class Initialized
INFO - 2018-02-12 16:15:34 --> Model Class Initialized
INFO - 2018-02-12 16:15:34 --> Model Class Initialized
INFO - 2018-02-12 16:15:34 --> Model Class Initialized
INFO - 2018-02-12 16:15:34 --> Model Class Initialized
INFO - 2018-02-12 16:15:34 --> Model Class Initialized
INFO - 2018-02-12 16:15:34 --> Model Class Initialized
INFO - 2018-02-12 16:15:34 --> Model Class Initialized
INFO - 2018-02-12 16:15:34 --> Model Class Initialized
INFO - 2018-02-12 16:15:34 --> Model Class Initialized
INFO - 2018-02-12 16:15:34 --> Model Class Initialized
INFO - 2018-02-12 16:15:34 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 16:15:34 --> Model Class Initialized
INFO - 2018-02-12 16:15:34 --> Final output sent to browser
DEBUG - 2018-02-12 16:15:34 --> Total execution time: 0.1472
INFO - 2018-02-12 10:45:36 --> Config Class Initialized
INFO - 2018-02-12 10:45:36 --> Hooks Class Initialized
DEBUG - 2018-02-12 10:45:36 --> UTF-8 Support Enabled
INFO - 2018-02-12 10:45:36 --> Utf8 Class Initialized
INFO - 2018-02-12 10:45:36 --> URI Class Initialized
INFO - 2018-02-12 10:45:36 --> Router Class Initialized
INFO - 2018-02-12 10:45:36 --> Output Class Initialized
INFO - 2018-02-12 10:45:36 --> Security Class Initialized
DEBUG - 2018-02-12 10:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 10:45:36 --> Input Class Initialized
INFO - 2018-02-12 10:45:36 --> Language Class Initialized
INFO - 2018-02-12 10:45:36 --> Language Class Initialized
INFO - 2018-02-12 10:45:36 --> Config Class Initialized
INFO - 2018-02-12 10:45:36 --> Loader Class Initialized
INFO - 2018-02-12 16:15:36 --> Helper loaded: url_helper
INFO - 2018-02-12 16:15:36 --> Helper loaded: notification_helper
INFO - 2018-02-12 16:15:36 --> Helper loaded: settings_helper
INFO - 2018-02-12 16:15:36 --> Helper loaded: permission_helper
INFO - 2018-02-12 16:15:36 --> Helper loaded: users_helper
INFO - 2018-02-12 16:15:36 --> Database Driver Class Initialized
DEBUG - 2018-02-12 16:15:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 16:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 16:15:36 --> Helper loaded: form_helper
INFO - 2018-02-12 16:15:36 --> Form Validation Class Initialized
INFO - 2018-02-12 16:15:36 --> Controller Class Initialized
INFO - 2018-02-12 16:15:36 --> Model Class Initialized
INFO - 2018-02-12 16:15:36 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 16:15:36 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 16:15:36 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 16:15:36 --> Model Class Initialized
INFO - 2018-02-12 16:15:36 --> Model Class Initialized
INFO - 2018-02-12 16:15:36 --> Model Class Initialized
INFO - 2018-02-12 16:15:36 --> Model Class Initialized
INFO - 2018-02-12 16:15:36 --> Model Class Initialized
INFO - 2018-02-12 16:15:36 --> Model Class Initialized
INFO - 2018-02-12 16:15:36 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 16:15:36 --> Model Class Initialized
INFO - 2018-02-12 16:15:36 --> Final output sent to browser
DEBUG - 2018-02-12 16:15:36 --> Total execution time: 0.1174
INFO - 2018-02-12 10:47:28 --> Config Class Initialized
INFO - 2018-02-12 10:47:28 --> Hooks Class Initialized
DEBUG - 2018-02-12 10:47:28 --> UTF-8 Support Enabled
INFO - 2018-02-12 10:47:28 --> Utf8 Class Initialized
INFO - 2018-02-12 10:47:28 --> URI Class Initialized
INFO - 2018-02-12 10:47:28 --> Router Class Initialized
INFO - 2018-02-12 10:47:28 --> Output Class Initialized
INFO - 2018-02-12 10:47:28 --> Config Class Initialized
INFO - 2018-02-12 10:47:28 --> Hooks Class Initialized
INFO - 2018-02-12 10:47:28 --> Security Class Initialized
DEBUG - 2018-02-12 10:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 10:47:28 --> Input Class Initialized
DEBUG - 2018-02-12 10:47:28 --> UTF-8 Support Enabled
INFO - 2018-02-12 10:47:28 --> Language Class Initialized
INFO - 2018-02-12 10:47:28 --> Utf8 Class Initialized
INFO - 2018-02-12 10:47:28 --> URI Class Initialized
INFO - 2018-02-12 10:47:28 --> Router Class Initialized
INFO - 2018-02-12 10:47:28 --> Output Class Initialized
INFO - 2018-02-12 10:47:28 --> Security Class Initialized
INFO - 2018-02-12 10:47:28 --> Language Class Initialized
INFO - 2018-02-12 10:47:28 --> Config Class Initialized
INFO - 2018-02-12 10:47:28 --> Loader Class Initialized
DEBUG - 2018-02-12 10:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 10:47:28 --> Input Class Initialized
INFO - 2018-02-12 10:47:28 --> Language Class Initialized
INFO - 2018-02-12 16:17:28 --> Helper loaded: url_helper
INFO - 2018-02-12 16:17:28 --> Helper loaded: notification_helper
INFO - 2018-02-12 16:17:28 --> Helper loaded: settings_helper
INFO - 2018-02-12 16:17:28 --> Helper loaded: permission_helper
INFO - 2018-02-12 16:17:28 --> Helper loaded: users_helper
INFO - 2018-02-12 16:17:28 --> Database Driver Class Initialized
INFO - 2018-02-12 10:47:28 --> Language Class Initialized
INFO - 2018-02-12 10:47:28 --> Config Class Initialized
INFO - 2018-02-12 10:47:28 --> Loader Class Initialized
INFO - 2018-02-12 16:17:28 --> Helper loaded: url_helper
DEBUG - 2018-02-12 16:17:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 16:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 16:17:28 --> Helper loaded: notification_helper
INFO - 2018-02-12 16:17:28 --> Helper loaded: settings_helper
INFO - 2018-02-12 16:17:28 --> Helper loaded: permission_helper
INFO - 2018-02-12 16:17:28 --> Helper loaded: users_helper
INFO - 2018-02-12 16:17:28 --> Helper loaded: form_helper
INFO - 2018-02-12 16:17:28 --> Form Validation Class Initialized
INFO - 2018-02-12 16:17:28 --> Controller Class Initialized
INFO - 2018-02-12 16:17:28 --> Model Class Initialized
INFO - 2018-02-12 16:17:28 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 16:17:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 16:17:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 16:17:28 --> Database Driver Class Initialized
INFO - 2018-02-12 16:17:28 --> Model Class Initialized
INFO - 2018-02-12 16:17:28 --> Model Class Initialized
INFO - 2018-02-12 16:17:28 --> Model Class Initialized
INFO - 2018-02-12 16:17:28 --> Model Class Initialized
INFO - 2018-02-12 16:17:28 --> Model Class Initialized
INFO - 2018-02-12 16:17:28 --> Model Class Initialized
INFO - 2018-02-12 16:17:28 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-02-12 16:17:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-02-12 16:17:28 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-02-12 16:17:28 --> Final output sent to browser
DEBUG - 2018-02-12 16:17:28 --> Total execution time: 0.0818
INFO - 2018-02-12 16:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 16:17:28 --> Helper loaded: form_helper
INFO - 2018-02-12 16:17:28 --> Form Validation Class Initialized
INFO - 2018-02-12 16:17:28 --> Controller Class Initialized
INFO - 2018-02-12 16:17:28 --> Model Class Initialized
INFO - 2018-02-12 16:17:28 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 16:17:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 16:17:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 16:17:28 --> Model Class Initialized
INFO - 2018-02-12 16:17:28 --> Model Class Initialized
INFO - 2018-02-12 16:17:28 --> Model Class Initialized
INFO - 2018-02-12 16:17:28 --> Model Class Initialized
INFO - 2018-02-12 16:17:28 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 16:17:28 --> Final output sent to browser
DEBUG - 2018-02-12 16:17:28 --> Total execution time: 0.1065
INFO - 2018-02-12 10:47:36 --> Config Class Initialized
INFO - 2018-02-12 10:47:36 --> Hooks Class Initialized
DEBUG - 2018-02-12 10:47:36 --> UTF-8 Support Enabled
INFO - 2018-02-12 10:47:36 --> Utf8 Class Initialized
INFO - 2018-02-12 10:47:36 --> URI Class Initialized
INFO - 2018-02-12 10:47:36 --> Router Class Initialized
INFO - 2018-02-12 10:47:36 --> Output Class Initialized
INFO - 2018-02-12 10:47:36 --> Security Class Initialized
DEBUG - 2018-02-12 10:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 10:47:36 --> Input Class Initialized
INFO - 2018-02-12 10:47:36 --> Language Class Initialized
INFO - 2018-02-12 10:47:36 --> Language Class Initialized
INFO - 2018-02-12 10:47:36 --> Config Class Initialized
INFO - 2018-02-12 10:47:36 --> Loader Class Initialized
INFO - 2018-02-12 16:17:36 --> Helper loaded: url_helper
INFO - 2018-02-12 16:17:36 --> Helper loaded: notification_helper
INFO - 2018-02-12 16:17:36 --> Helper loaded: settings_helper
INFO - 2018-02-12 16:17:36 --> Helper loaded: permission_helper
INFO - 2018-02-12 16:17:36 --> Helper loaded: users_helper
INFO - 2018-02-12 16:17:36 --> Database Driver Class Initialized
DEBUG - 2018-02-12 16:17:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 16:17:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 16:17:36 --> Helper loaded: form_helper
INFO - 2018-02-12 16:17:36 --> Form Validation Class Initialized
INFO - 2018-02-12 16:17:36 --> Controller Class Initialized
INFO - 2018-02-12 16:17:36 --> Model Class Initialized
INFO - 2018-02-12 16:17:36 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 16:17:36 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 16:17:36 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 16:17:36 --> Model Class Initialized
INFO - 2018-02-12 16:17:36 --> Model Class Initialized
INFO - 2018-02-12 16:17:36 --> Model Class Initialized
INFO - 2018-02-12 16:17:36 --> Model Class Initialized
INFO - 2018-02-12 16:17:36 --> Model Class Initialized
INFO - 2018-02-12 16:17:36 --> Model Class Initialized
INFO - 2018-02-12 16:17:36 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 16:17:36 --> Final output sent to browser
DEBUG - 2018-02-12 16:17:36 --> Total execution time: 0.0755
INFO - 2018-02-12 11:03:04 --> Config Class Initialized
INFO - 2018-02-12 11:03:04 --> Hooks Class Initialized
DEBUG - 2018-02-12 11:03:04 --> UTF-8 Support Enabled
INFO - 2018-02-12 11:03:04 --> Utf8 Class Initialized
INFO - 2018-02-12 11:03:04 --> URI Class Initialized
INFO - 2018-02-12 11:03:04 --> Config Class Initialized
INFO - 2018-02-12 11:03:04 --> Hooks Class Initialized
DEBUG - 2018-02-12 11:03:04 --> UTF-8 Support Enabled
INFO - 2018-02-12 11:03:04 --> Utf8 Class Initialized
INFO - 2018-02-12 11:03:04 --> Router Class Initialized
INFO - 2018-02-12 11:03:04 --> URI Class Initialized
INFO - 2018-02-12 11:03:04 --> Output Class Initialized
INFO - 2018-02-12 11:03:04 --> Router Class Initialized
INFO - 2018-02-12 11:03:04 --> Security Class Initialized
INFO - 2018-02-12 11:03:04 --> Output Class Initialized
DEBUG - 2018-02-12 11:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 11:03:04 --> Input Class Initialized
INFO - 2018-02-12 11:03:04 --> Security Class Initialized
INFO - 2018-02-12 11:03:04 --> Language Class Initialized
DEBUG - 2018-02-12 11:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 11:03:04 --> Input Class Initialized
INFO - 2018-02-12 11:03:04 --> Language Class Initialized
INFO - 2018-02-12 11:03:04 --> Language Class Initialized
INFO - 2018-02-12 11:03:04 --> Config Class Initialized
INFO - 2018-02-12 11:03:04 --> Loader Class Initialized
INFO - 2018-02-12 16:33:04 --> Helper loaded: url_helper
INFO - 2018-02-12 16:33:04 --> Helper loaded: notification_helper
INFO - 2018-02-12 16:33:04 --> Helper loaded: settings_helper
INFO - 2018-02-12 16:33:04 --> Helper loaded: permission_helper
INFO - 2018-02-12 16:33:04 --> Helper loaded: users_helper
INFO - 2018-02-12 11:03:04 --> Language Class Initialized
INFO - 2018-02-12 11:03:04 --> Config Class Initialized
INFO - 2018-02-12 11:03:04 --> Loader Class Initialized
INFO - 2018-02-12 16:33:04 --> Helper loaded: url_helper
INFO - 2018-02-12 16:33:04 --> Helper loaded: notification_helper
INFO - 2018-02-12 16:33:04 --> Helper loaded: settings_helper
INFO - 2018-02-12 16:33:04 --> Helper loaded: permission_helper
INFO - 2018-02-12 16:33:04 --> Helper loaded: users_helper
INFO - 2018-02-12 16:33:04 --> Database Driver Class Initialized
DEBUG - 2018-02-12 16:33:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 16:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 16:33:04 --> Database Driver Class Initialized
INFO - 2018-02-12 16:33:04 --> Helper loaded: form_helper
INFO - 2018-02-12 16:33:04 --> Form Validation Class Initialized
INFO - 2018-02-12 16:33:04 --> Controller Class Initialized
DEBUG - 2018-02-12 16:33:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 16:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 16:33:04 --> Model Class Initialized
INFO - 2018-02-12 16:33:04 --> Helper loaded: form_helper
INFO - 2018-02-12 16:33:04 --> Helper loaded: inflector_helper
INFO - 2018-02-12 16:33:04 --> Form Validation Class Initialized
INFO - 2018-02-12 16:33:04 --> Controller Class Initialized
DEBUG - 2018-02-12 16:33:04 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 16:33:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 16:33:04 --> Model Class Initialized
INFO - 2018-02-12 16:33:04 --> Model Class Initialized
INFO - 2018-02-12 16:33:04 --> Model Class Initialized
INFO - 2018-02-12 16:33:04 --> Model Class Initialized
INFO - 2018-02-12 16:33:04 --> Model Class Initialized
INFO - 2018-02-12 16:33:04 --> Model Class Initialized
INFO - 2018-02-12 16:33:04 --> Model Class Initialized
INFO - 2018-02-12 16:33:04 --> Model Class Initialized
INFO - 2018-02-12 16:33:04 --> Model Class Initialized
INFO - 2018-02-12 16:33:04 --> Model Class Initialized
INFO - 2018-02-12 16:33:04 --> Model Class Initialized
INFO - 2018-02-12 16:33:04 --> Helper loaded: inflector_helper
INFO - 2018-02-12 16:33:04 --> Model Class Initialized
INFO - 2018-02-12 16:33:04 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 16:33:04 --> Model Class Initialized
DEBUG - 2018-02-12 16:33:04 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 16:33:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 16:33:04 --> Model Class Initialized
INFO - 2018-02-12 16:33:04 --> Model Class Initialized
INFO - 2018-02-12 16:33:04 --> Model Class Initialized
INFO - 2018-02-12 16:33:04 --> Model Class Initialized
INFO - 2018-02-12 16:33:04 --> Model Class Initialized
INFO - 2018-02-12 16:33:04 --> Model Class Initialized
INFO - 2018-02-12 16:33:04 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 16:33:04 --> Model Class Initialized
INFO - 2018-02-12 16:33:04 --> Final output sent to browser
DEBUG - 2018-02-12 16:33:04 --> Total execution time: 0.1096
INFO - 2018-02-12 16:33:04 --> Final output sent to browser
DEBUG - 2018-02-12 16:33:04 --> Total execution time: 0.1294
INFO - 2018-02-12 11:03:14 --> Config Class Initialized
INFO - 2018-02-12 11:03:14 --> Hooks Class Initialized
DEBUG - 2018-02-12 11:03:14 --> UTF-8 Support Enabled
INFO - 2018-02-12 11:03:14 --> Utf8 Class Initialized
INFO - 2018-02-12 11:03:14 --> URI Class Initialized
INFO - 2018-02-12 11:03:14 --> Config Class Initialized
INFO - 2018-02-12 11:03:14 --> Hooks Class Initialized
INFO - 2018-02-12 11:03:14 --> Router Class Initialized
DEBUG - 2018-02-12 11:03:14 --> UTF-8 Support Enabled
INFO - 2018-02-12 11:03:14 --> Utf8 Class Initialized
INFO - 2018-02-12 11:03:14 --> URI Class Initialized
INFO - 2018-02-12 11:03:14 --> Output Class Initialized
INFO - 2018-02-12 11:03:14 --> Security Class Initialized
INFO - 2018-02-12 11:03:14 --> Router Class Initialized
DEBUG - 2018-02-12 11:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 11:03:14 --> Input Class Initialized
INFO - 2018-02-12 11:03:14 --> Language Class Initialized
INFO - 2018-02-12 11:03:14 --> Output Class Initialized
INFO - 2018-02-12 11:03:14 --> Security Class Initialized
DEBUG - 2018-02-12 11:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 11:03:14 --> Input Class Initialized
INFO - 2018-02-12 11:03:14 --> Language Class Initialized
INFO - 2018-02-12 11:03:14 --> Language Class Initialized
INFO - 2018-02-12 11:03:14 --> Config Class Initialized
INFO - 2018-02-12 11:03:14 --> Loader Class Initialized
INFO - 2018-02-12 16:33:14 --> Helper loaded: url_helper
INFO - 2018-02-12 16:33:14 --> Helper loaded: notification_helper
INFO - 2018-02-12 16:33:14 --> Helper loaded: settings_helper
INFO - 2018-02-12 16:33:14 --> Helper loaded: permission_helper
INFO - 2018-02-12 16:33:14 --> Helper loaded: users_helper
INFO - 2018-02-12 11:03:14 --> Language Class Initialized
INFO - 2018-02-12 11:03:14 --> Config Class Initialized
INFO - 2018-02-12 11:03:14 --> Loader Class Initialized
INFO - 2018-02-12 16:33:14 --> Helper loaded: url_helper
INFO - 2018-02-12 16:33:14 --> Helper loaded: notification_helper
INFO - 2018-02-12 16:33:14 --> Helper loaded: settings_helper
INFO - 2018-02-12 16:33:14 --> Helper loaded: permission_helper
INFO - 2018-02-12 16:33:14 --> Helper loaded: users_helper
INFO - 2018-02-12 16:33:14 --> Database Driver Class Initialized
DEBUG - 2018-02-12 16:33:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 16:33:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 16:33:14 --> Database Driver Class Initialized
INFO - 2018-02-12 16:33:14 --> Helper loaded: form_helper
INFO - 2018-02-12 16:33:14 --> Form Validation Class Initialized
INFO - 2018-02-12 16:33:14 --> Controller Class Initialized
DEBUG - 2018-02-12 16:33:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 16:33:14 --> Model Class Initialized
INFO - 2018-02-12 16:33:14 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 16:33:14 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 16:33:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 16:33:14 --> Model Class Initialized
INFO - 2018-02-12 16:33:14 --> Model Class Initialized
INFO - 2018-02-12 16:33:14 --> Model Class Initialized
INFO - 2018-02-12 16:33:14 --> Model Class Initialized
INFO - 2018-02-12 16:33:14 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 16:33:14 --> Final output sent to browser
DEBUG - 2018-02-12 16:33:14 --> Total execution time: 0.1084
INFO - 2018-02-12 16:33:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 16:33:14 --> Helper loaded: form_helper
INFO - 2018-02-12 16:33:14 --> Form Validation Class Initialized
INFO - 2018-02-12 16:33:14 --> Controller Class Initialized
INFO - 2018-02-12 16:33:14 --> Model Class Initialized
INFO - 2018-02-12 16:33:14 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 16:33:14 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 16:33:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 16:33:14 --> Model Class Initialized
INFO - 2018-02-12 16:33:14 --> Model Class Initialized
INFO - 2018-02-12 16:33:14 --> Model Class Initialized
INFO - 2018-02-12 16:33:14 --> Model Class Initialized
INFO - 2018-02-12 16:33:14 --> Model Class Initialized
INFO - 2018-02-12 16:33:14 --> Model Class Initialized
INFO - 2018-02-12 16:33:14 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-02-12 16:33:14 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-02-12 16:33:14 --> Final output sent to browser
DEBUG - 2018-02-12 16:33:14 --> Total execution time: 0.1370
INFO - 2018-02-12 11:03:23 --> Config Class Initialized
INFO - 2018-02-12 11:03:23 --> Hooks Class Initialized
DEBUG - 2018-02-12 11:03:23 --> UTF-8 Support Enabled
INFO - 2018-02-12 11:03:23 --> Utf8 Class Initialized
INFO - 2018-02-12 11:03:23 --> URI Class Initialized
INFO - 2018-02-12 11:03:23 --> Router Class Initialized
INFO - 2018-02-12 11:03:23 --> Output Class Initialized
INFO - 2018-02-12 11:03:23 --> Security Class Initialized
DEBUG - 2018-02-12 11:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 11:03:23 --> Input Class Initialized
INFO - 2018-02-12 11:03:23 --> Language Class Initialized
INFO - 2018-02-12 11:03:23 --> Language Class Initialized
INFO - 2018-02-12 11:03:23 --> Config Class Initialized
INFO - 2018-02-12 11:03:23 --> Loader Class Initialized
INFO - 2018-02-12 16:33:23 --> Helper loaded: url_helper
INFO - 2018-02-12 16:33:23 --> Helper loaded: notification_helper
INFO - 2018-02-12 16:33:23 --> Helper loaded: settings_helper
INFO - 2018-02-12 16:33:23 --> Helper loaded: permission_helper
INFO - 2018-02-12 16:33:23 --> Helper loaded: users_helper
INFO - 2018-02-12 16:33:23 --> Database Driver Class Initialized
DEBUG - 2018-02-12 16:33:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 16:33:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 16:33:23 --> Helper loaded: form_helper
INFO - 2018-02-12 16:33:23 --> Form Validation Class Initialized
INFO - 2018-02-12 16:33:23 --> Controller Class Initialized
INFO - 2018-02-12 16:33:23 --> Model Class Initialized
INFO - 2018-02-12 16:33:23 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 16:33:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 16:33:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 16:33:23 --> Model Class Initialized
INFO - 2018-02-12 16:33:23 --> Model Class Initialized
INFO - 2018-02-12 16:33:23 --> Model Class Initialized
INFO - 2018-02-12 16:33:23 --> Model Class Initialized
INFO - 2018-02-12 16:33:23 --> Model Class Initialized
INFO - 2018-02-12 16:33:23 --> Model Class Initialized
INFO - 2018-02-12 16:33:23 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 16:33:23 --> Final output sent to browser
DEBUG - 2018-02-12 16:33:23 --> Total execution time: 0.1149
INFO - 2018-02-12 11:08:38 --> Config Class Initialized
INFO - 2018-02-12 11:08:38 --> Hooks Class Initialized
DEBUG - 2018-02-12 11:08:38 --> UTF-8 Support Enabled
INFO - 2018-02-12 11:08:38 --> Utf8 Class Initialized
INFO - 2018-02-12 11:08:38 --> URI Class Initialized
INFO - 2018-02-12 11:08:38 --> Router Class Initialized
INFO - 2018-02-12 11:08:38 --> Output Class Initialized
INFO - 2018-02-12 11:08:38 --> Security Class Initialized
DEBUG - 2018-02-12 11:08:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 11:08:38 --> Input Class Initialized
INFO - 2018-02-12 11:08:38 --> Language Class Initialized
INFO - 2018-02-12 11:08:38 --> Language Class Initialized
INFO - 2018-02-12 11:08:38 --> Config Class Initialized
INFO - 2018-02-12 11:08:38 --> Loader Class Initialized
INFO - 2018-02-12 16:38:38 --> Helper loaded: url_helper
INFO - 2018-02-12 16:38:38 --> Helper loaded: notification_helper
INFO - 2018-02-12 16:38:38 --> Helper loaded: settings_helper
INFO - 2018-02-12 16:38:38 --> Helper loaded: permission_helper
INFO - 2018-02-12 16:38:38 --> Helper loaded: users_helper
INFO - 2018-02-12 16:38:38 --> Database Driver Class Initialized
DEBUG - 2018-02-12 16:38:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 16:38:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 16:38:38 --> Helper loaded: form_helper
INFO - 2018-02-12 16:38:38 --> Form Validation Class Initialized
INFO - 2018-02-12 16:38:38 --> Controller Class Initialized
INFO - 2018-02-12 16:38:38 --> Model Class Initialized
INFO - 2018-02-12 16:38:38 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 16:38:38 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 16:38:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 16:38:38 --> Model Class Initialized
INFO - 2018-02-12 16:38:38 --> Model Class Initialized
INFO - 2018-02-12 16:38:38 --> Model Class Initialized
INFO - 2018-02-12 16:38:38 --> Model Class Initialized
INFO - 2018-02-12 16:38:38 --> Model Class Initialized
INFO - 2018-02-12 16:38:38 --> Model Class Initialized
INFO - 2018-02-12 16:38:38 --> Model Class Initialized
INFO - 2018-02-12 16:38:38 --> Model Class Initialized
INFO - 2018-02-12 16:38:38 --> Model Class Initialized
INFO - 2018-02-12 16:38:38 --> Model Class Initialized
INFO - 2018-02-12 16:38:38 --> Model Class Initialized
INFO - 2018-02-12 16:38:38 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 16:38:38 --> Model Class Initialized
INFO - 2018-02-12 16:38:38 --> Final output sent to browser
DEBUG - 2018-02-12 16:38:38 --> Total execution time: 0.1399
INFO - 2018-02-12 11:08:39 --> Config Class Initialized
INFO - 2018-02-12 11:08:39 --> Hooks Class Initialized
DEBUG - 2018-02-12 11:08:39 --> UTF-8 Support Enabled
INFO - 2018-02-12 11:08:39 --> Utf8 Class Initialized
INFO - 2018-02-12 11:08:39 --> URI Class Initialized
INFO - 2018-02-12 11:08:39 --> Router Class Initialized
INFO - 2018-02-12 11:08:39 --> Output Class Initialized
INFO - 2018-02-12 11:08:39 --> Security Class Initialized
DEBUG - 2018-02-12 11:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 11:08:39 --> Input Class Initialized
INFO - 2018-02-12 11:08:39 --> Language Class Initialized
INFO - 2018-02-12 11:08:39 --> Language Class Initialized
INFO - 2018-02-12 11:08:39 --> Config Class Initialized
INFO - 2018-02-12 11:08:39 --> Loader Class Initialized
INFO - 2018-02-12 16:38:39 --> Helper loaded: url_helper
INFO - 2018-02-12 16:38:39 --> Helper loaded: notification_helper
INFO - 2018-02-12 16:38:39 --> Helper loaded: settings_helper
INFO - 2018-02-12 16:38:39 --> Helper loaded: permission_helper
INFO - 2018-02-12 16:38:39 --> Helper loaded: users_helper
INFO - 2018-02-12 16:38:39 --> Database Driver Class Initialized
DEBUG - 2018-02-12 16:38:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 16:38:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 16:38:39 --> Helper loaded: form_helper
INFO - 2018-02-12 16:38:39 --> Form Validation Class Initialized
INFO - 2018-02-12 16:38:39 --> Controller Class Initialized
INFO - 2018-02-12 16:38:39 --> Model Class Initialized
INFO - 2018-02-12 16:38:39 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 16:38:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 16:38:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 16:38:39 --> Model Class Initialized
INFO - 2018-02-12 16:38:39 --> Model Class Initialized
INFO - 2018-02-12 16:38:39 --> Model Class Initialized
INFO - 2018-02-12 16:38:39 --> Model Class Initialized
INFO - 2018-02-12 16:38:39 --> Model Class Initialized
INFO - 2018-02-12 16:38:39 --> Model Class Initialized
INFO - 2018-02-12 16:38:39 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 16:38:39 --> Model Class Initialized
INFO - 2018-02-12 16:38:39 --> Final output sent to browser
DEBUG - 2018-02-12 16:38:39 --> Total execution time: 0.1126
INFO - 2018-02-12 11:08:48 --> Config Class Initialized
INFO - 2018-02-12 11:08:48 --> Hooks Class Initialized
DEBUG - 2018-02-12 11:08:48 --> UTF-8 Support Enabled
INFO - 2018-02-12 11:08:48 --> Utf8 Class Initialized
INFO - 2018-02-12 11:08:48 --> URI Class Initialized
INFO - 2018-02-12 11:08:48 --> Router Class Initialized
INFO - 2018-02-12 11:08:48 --> Output Class Initialized
INFO - 2018-02-12 11:08:48 --> Security Class Initialized
DEBUG - 2018-02-12 11:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 11:08:48 --> Input Class Initialized
INFO - 2018-02-12 11:08:48 --> Language Class Initialized
INFO - 2018-02-12 11:08:48 --> Language Class Initialized
INFO - 2018-02-12 11:08:48 --> Config Class Initialized
INFO - 2018-02-12 11:08:48 --> Loader Class Initialized
INFO - 2018-02-12 16:38:48 --> Helper loaded: url_helper
INFO - 2018-02-12 16:38:48 --> Helper loaded: notification_helper
INFO - 2018-02-12 16:38:48 --> Helper loaded: settings_helper
INFO - 2018-02-12 16:38:48 --> Helper loaded: permission_helper
INFO - 2018-02-12 16:38:48 --> Helper loaded: users_helper
INFO - 2018-02-12 16:38:48 --> Database Driver Class Initialized
DEBUG - 2018-02-12 16:38:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 16:38:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 16:38:48 --> Helper loaded: form_helper
INFO - 2018-02-12 16:38:48 --> Form Validation Class Initialized
INFO - 2018-02-12 16:38:48 --> Controller Class Initialized
INFO - 2018-02-12 11:08:48 --> Config Class Initialized
INFO - 2018-02-12 11:08:48 --> Hooks Class Initialized
DEBUG - 2018-02-12 11:08:48 --> UTF-8 Support Enabled
INFO - 2018-02-12 11:08:48 --> Utf8 Class Initialized
INFO - 2018-02-12 16:38:48 --> Model Class Initialized
INFO - 2018-02-12 16:38:48 --> Helper loaded: inflector_helper
INFO - 2018-02-12 11:08:48 --> URI Class Initialized
DEBUG - 2018-02-12 16:38:48 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 11:08:48 --> Router Class Initialized
INFO - 2018-02-12 16:38:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 16:38:48 --> Model Class Initialized
INFO - 2018-02-12 16:38:48 --> Model Class Initialized
INFO - 2018-02-12 11:08:48 --> Output Class Initialized
INFO - 2018-02-12 16:38:48 --> Model Class Initialized
INFO - 2018-02-12 16:38:48 --> Model Class Initialized
INFO - 2018-02-12 16:38:48 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 11:08:48 --> Security Class Initialized
INFO - 2018-02-12 16:38:48 --> Final output sent to browser
DEBUG - 2018-02-12 16:38:48 --> Total execution time: 0.0811
DEBUG - 2018-02-12 11:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 11:08:48 --> Input Class Initialized
INFO - 2018-02-12 11:08:48 --> Language Class Initialized
INFO - 2018-02-12 11:08:48 --> Language Class Initialized
INFO - 2018-02-12 11:08:48 --> Config Class Initialized
INFO - 2018-02-12 11:08:48 --> Loader Class Initialized
INFO - 2018-02-12 16:38:48 --> Helper loaded: url_helper
INFO - 2018-02-12 16:38:48 --> Helper loaded: notification_helper
INFO - 2018-02-12 16:38:48 --> Helper loaded: settings_helper
INFO - 2018-02-12 16:38:48 --> Helper loaded: permission_helper
INFO - 2018-02-12 16:38:48 --> Helper loaded: users_helper
INFO - 2018-02-12 16:38:48 --> Database Driver Class Initialized
DEBUG - 2018-02-12 16:38:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 16:38:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 16:38:48 --> Helper loaded: form_helper
INFO - 2018-02-12 16:38:48 --> Form Validation Class Initialized
INFO - 2018-02-12 16:38:48 --> Controller Class Initialized
INFO - 2018-02-12 16:38:48 --> Model Class Initialized
INFO - 2018-02-12 16:38:48 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 16:38:48 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 16:38:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 16:38:48 --> Model Class Initialized
INFO - 2018-02-12 16:38:48 --> Model Class Initialized
INFO - 2018-02-12 16:38:48 --> Model Class Initialized
INFO - 2018-02-12 16:38:48 --> Model Class Initialized
INFO - 2018-02-12 16:38:48 --> Model Class Initialized
INFO - 2018-02-12 16:38:48 --> Model Class Initialized
INFO - 2018-02-12 16:38:48 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-02-12 16:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-02-12 16:38:48 --> Final output sent to browser
DEBUG - 2018-02-12 16:38:48 --> Total execution time: 0.1087
INFO - 2018-02-12 11:08:52 --> Config Class Initialized
INFO - 2018-02-12 11:08:52 --> Hooks Class Initialized
DEBUG - 2018-02-12 11:08:52 --> UTF-8 Support Enabled
INFO - 2018-02-12 11:08:52 --> Utf8 Class Initialized
INFO - 2018-02-12 11:08:52 --> URI Class Initialized
INFO - 2018-02-12 11:08:52 --> Router Class Initialized
INFO - 2018-02-12 11:08:52 --> Output Class Initialized
INFO - 2018-02-12 11:08:52 --> Security Class Initialized
DEBUG - 2018-02-12 11:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 11:08:52 --> Input Class Initialized
INFO - 2018-02-12 11:08:52 --> Language Class Initialized
INFO - 2018-02-12 11:08:52 --> Language Class Initialized
INFO - 2018-02-12 11:08:52 --> Config Class Initialized
INFO - 2018-02-12 11:08:52 --> Loader Class Initialized
INFO - 2018-02-12 16:38:52 --> Helper loaded: url_helper
INFO - 2018-02-12 16:38:52 --> Helper loaded: notification_helper
INFO - 2018-02-12 16:38:52 --> Helper loaded: settings_helper
INFO - 2018-02-12 16:38:52 --> Helper loaded: permission_helper
INFO - 2018-02-12 16:38:52 --> Helper loaded: users_helper
INFO - 2018-02-12 16:38:52 --> Database Driver Class Initialized
DEBUG - 2018-02-12 16:38:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 16:38:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 16:38:52 --> Helper loaded: form_helper
INFO - 2018-02-12 16:38:52 --> Form Validation Class Initialized
INFO - 2018-02-12 16:38:52 --> Controller Class Initialized
INFO - 2018-02-12 16:38:52 --> Model Class Initialized
INFO - 2018-02-12 16:38:52 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 16:38:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 16:38:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 16:38:52 --> Model Class Initialized
INFO - 2018-02-12 16:38:52 --> Model Class Initialized
INFO - 2018-02-12 16:38:52 --> Model Class Initialized
INFO - 2018-02-12 16:38:52 --> Model Class Initialized
INFO - 2018-02-12 16:38:52 --> Model Class Initialized
INFO - 2018-02-12 16:38:52 --> Model Class Initialized
INFO - 2018-02-12 16:38:52 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 16:38:52 --> Final output sent to browser
DEBUG - 2018-02-12 16:38:52 --> Total execution time: 0.1049
INFO - 2018-02-12 11:09:24 --> Config Class Initialized
INFO - 2018-02-12 11:09:24 --> Hooks Class Initialized
DEBUG - 2018-02-12 11:09:24 --> UTF-8 Support Enabled
INFO - 2018-02-12 11:09:24 --> Utf8 Class Initialized
INFO - 2018-02-12 11:09:24 --> URI Class Initialized
INFO - 2018-02-12 11:09:24 --> Router Class Initialized
INFO - 2018-02-12 11:09:24 --> Output Class Initialized
INFO - 2018-02-12 11:09:24 --> Security Class Initialized
DEBUG - 2018-02-12 11:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 11:09:24 --> Input Class Initialized
INFO - 2018-02-12 11:09:24 --> Language Class Initialized
INFO - 2018-02-12 11:09:24 --> Language Class Initialized
INFO - 2018-02-12 11:09:24 --> Config Class Initialized
INFO - 2018-02-12 11:09:24 --> Loader Class Initialized
INFO - 2018-02-12 16:39:24 --> Helper loaded: url_helper
INFO - 2018-02-12 16:39:24 --> Helper loaded: notification_helper
INFO - 2018-02-12 16:39:24 --> Helper loaded: settings_helper
INFO - 2018-02-12 16:39:24 --> Helper loaded: permission_helper
INFO - 2018-02-12 16:39:24 --> Helper loaded: users_helper
INFO - 2018-02-12 16:39:24 --> Database Driver Class Initialized
DEBUG - 2018-02-12 16:39:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 16:39:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 16:39:24 --> Helper loaded: form_helper
INFO - 2018-02-12 16:39:24 --> Form Validation Class Initialized
INFO - 2018-02-12 16:39:24 --> Controller Class Initialized
INFO - 2018-02-12 16:39:24 --> Model Class Initialized
INFO - 2018-02-12 16:39:24 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 16:39:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 16:39:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 16:39:24 --> Model Class Initialized
INFO - 2018-02-12 16:39:24 --> Model Class Initialized
INFO - 2018-02-12 16:39:24 --> Model Class Initialized
INFO - 2018-02-12 16:39:24 --> Model Class Initialized
INFO - 2018-02-12 16:39:24 --> Model Class Initialized
INFO - 2018-02-12 16:39:24 --> Model Class Initialized
INFO - 2018-02-12 16:39:24 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 16:39:24 --> Final output sent to browser
DEBUG - 2018-02-12 16:39:24 --> Total execution time: 0.1111
INFO - 2018-02-12 11:15:51 --> Config Class Initialized
INFO - 2018-02-12 11:15:51 --> Hooks Class Initialized
DEBUG - 2018-02-12 11:15:51 --> UTF-8 Support Enabled
INFO - 2018-02-12 11:15:51 --> Utf8 Class Initialized
INFO - 2018-02-12 11:15:51 --> URI Class Initialized
INFO - 2018-02-12 11:15:51 --> Router Class Initialized
INFO - 2018-02-12 11:15:51 --> Output Class Initialized
INFO - 2018-02-12 11:15:51 --> Security Class Initialized
DEBUG - 2018-02-12 11:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 11:15:51 --> Input Class Initialized
INFO - 2018-02-12 11:15:51 --> Language Class Initialized
INFO - 2018-02-12 11:15:51 --> Language Class Initialized
INFO - 2018-02-12 11:15:51 --> Config Class Initialized
INFO - 2018-02-12 11:15:51 --> Loader Class Initialized
INFO - 2018-02-12 16:45:51 --> Helper loaded: url_helper
INFO - 2018-02-12 16:45:51 --> Helper loaded: notification_helper
INFO - 2018-02-12 16:45:51 --> Helper loaded: settings_helper
INFO - 2018-02-12 16:45:51 --> Helper loaded: permission_helper
INFO - 2018-02-12 16:45:51 --> Helper loaded: users_helper
INFO - 2018-02-12 16:45:51 --> Database Driver Class Initialized
DEBUG - 2018-02-12 16:45:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 16:45:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 16:45:51 --> Helper loaded: form_helper
INFO - 2018-02-12 16:45:51 --> Form Validation Class Initialized
INFO - 2018-02-12 16:45:51 --> Controller Class Initialized
INFO - 2018-02-12 16:45:51 --> Model Class Initialized
INFO - 2018-02-12 16:45:51 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 16:45:51 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 16:45:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 16:45:51 --> Model Class Initialized
INFO - 2018-02-12 16:45:51 --> Model Class Initialized
INFO - 2018-02-12 16:45:51 --> Model Class Initialized
INFO - 2018-02-12 16:45:51 --> Model Class Initialized
INFO - 2018-02-12 16:45:51 --> Model Class Initialized
INFO - 2018-02-12 16:45:51 --> Model Class Initialized
INFO - 2018-02-12 16:45:51 --> Model Class Initialized
INFO - 2018-02-12 16:45:51 --> Model Class Initialized
INFO - 2018-02-12 16:45:51 --> Model Class Initialized
INFO - 2018-02-12 16:45:51 --> Model Class Initialized
INFO - 2018-02-12 16:45:51 --> Model Class Initialized
INFO - 2018-02-12 16:45:51 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 16:45:51 --> Model Class Initialized
INFO - 2018-02-12 16:45:51 --> Final output sent to browser
DEBUG - 2018-02-12 16:45:51 --> Total execution time: 0.1361
INFO - 2018-02-12 11:15:54 --> Config Class Initialized
INFO - 2018-02-12 11:15:54 --> Hooks Class Initialized
DEBUG - 2018-02-12 11:15:54 --> UTF-8 Support Enabled
INFO - 2018-02-12 11:15:54 --> Utf8 Class Initialized
INFO - 2018-02-12 11:15:54 --> URI Class Initialized
INFO - 2018-02-12 11:15:54 --> Router Class Initialized
INFO - 2018-02-12 11:15:54 --> Output Class Initialized
INFO - 2018-02-12 11:15:54 --> Security Class Initialized
DEBUG - 2018-02-12 11:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 11:15:54 --> Input Class Initialized
INFO - 2018-02-12 11:15:54 --> Language Class Initialized
INFO - 2018-02-12 11:15:54 --> Language Class Initialized
INFO - 2018-02-12 11:15:54 --> Config Class Initialized
INFO - 2018-02-12 11:15:54 --> Loader Class Initialized
INFO - 2018-02-12 16:45:54 --> Helper loaded: url_helper
INFO - 2018-02-12 16:45:54 --> Helper loaded: notification_helper
INFO - 2018-02-12 16:45:54 --> Helper loaded: settings_helper
INFO - 2018-02-12 16:45:54 --> Helper loaded: permission_helper
INFO - 2018-02-12 16:45:54 --> Helper loaded: users_helper
INFO - 2018-02-12 16:45:54 --> Database Driver Class Initialized
DEBUG - 2018-02-12 16:45:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 16:45:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 16:45:54 --> Helper loaded: form_helper
INFO - 2018-02-12 16:45:54 --> Form Validation Class Initialized
INFO - 2018-02-12 16:45:54 --> Controller Class Initialized
INFO - 2018-02-12 16:45:54 --> Model Class Initialized
INFO - 2018-02-12 16:45:54 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 16:45:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 16:45:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 16:45:54 --> Model Class Initialized
INFO - 2018-02-12 16:45:54 --> Model Class Initialized
INFO - 2018-02-12 16:45:54 --> Model Class Initialized
INFO - 2018-02-12 16:45:54 --> Model Class Initialized
INFO - 2018-02-12 16:45:54 --> Model Class Initialized
INFO - 2018-02-12 16:45:54 --> Model Class Initialized
INFO - 2018-02-12 16:45:54 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 16:45:54 --> Model Class Initialized
INFO - 2018-02-12 16:45:54 --> Final output sent to browser
DEBUG - 2018-02-12 16:45:54 --> Total execution time: 0.1054
INFO - 2018-02-12 11:16:02 --> Config Class Initialized
INFO - 2018-02-12 11:16:02 --> Hooks Class Initialized
DEBUG - 2018-02-12 11:16:02 --> UTF-8 Support Enabled
INFO - 2018-02-12 11:16:02 --> Utf8 Class Initialized
INFO - 2018-02-12 11:16:02 --> URI Class Initialized
INFO - 2018-02-12 11:16:02 --> Config Class Initialized
INFO - 2018-02-12 11:16:02 --> Hooks Class Initialized
INFO - 2018-02-12 11:16:02 --> Router Class Initialized
DEBUG - 2018-02-12 11:16:02 --> UTF-8 Support Enabled
INFO - 2018-02-12 11:16:02 --> Utf8 Class Initialized
INFO - 2018-02-12 11:16:02 --> Output Class Initialized
INFO - 2018-02-12 11:16:02 --> URI Class Initialized
INFO - 2018-02-12 11:16:02 --> Security Class Initialized
INFO - 2018-02-12 11:16:02 --> Router Class Initialized
INFO - 2018-02-12 11:16:02 --> Output Class Initialized
INFO - 2018-02-12 11:16:02 --> Security Class Initialized
DEBUG - 2018-02-12 11:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 11:16:02 --> Input Class Initialized
INFO - 2018-02-12 11:16:02 --> Language Class Initialized
DEBUG - 2018-02-12 11:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 11:16:02 --> Input Class Initialized
INFO - 2018-02-12 11:16:02 --> Language Class Initialized
INFO - 2018-02-12 11:16:02 --> Language Class Initialized
INFO - 2018-02-12 11:16:02 --> Config Class Initialized
INFO - 2018-02-12 11:16:02 --> Loader Class Initialized
INFO - 2018-02-12 16:46:02 --> Helper loaded: url_helper
INFO - 2018-02-12 16:46:02 --> Helper loaded: notification_helper
INFO - 2018-02-12 16:46:02 --> Helper loaded: settings_helper
INFO - 2018-02-12 16:46:02 --> Helper loaded: permission_helper
INFO - 2018-02-12 16:46:02 --> Helper loaded: users_helper
INFO - 2018-02-12 16:46:02 --> Database Driver Class Initialized
DEBUG - 2018-02-12 16:46:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 16:46:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 16:46:02 --> Helper loaded: form_helper
INFO - 2018-02-12 16:46:02 --> Form Validation Class Initialized
INFO - 2018-02-12 16:46:02 --> Controller Class Initialized
INFO - 2018-02-12 16:46:02 --> Model Class Initialized
INFO - 2018-02-12 16:46:02 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 16:46:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 16:46:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 16:46:02 --> Model Class Initialized
INFO - 2018-02-12 16:46:02 --> Model Class Initialized
INFO - 2018-02-12 16:46:02 --> Model Class Initialized
INFO - 2018-02-12 16:46:02 --> Model Class Initialized
INFO - 2018-02-12 16:46:02 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 16:46:02 --> Final output sent to browser
DEBUG - 2018-02-12 16:46:02 --> Total execution time: 0.1106
INFO - 2018-02-12 11:16:02 --> Language Class Initialized
INFO - 2018-02-12 11:16:02 --> Config Class Initialized
INFO - 2018-02-12 11:16:02 --> Loader Class Initialized
INFO - 2018-02-12 16:46:02 --> Helper loaded: url_helper
INFO - 2018-02-12 16:46:02 --> Helper loaded: notification_helper
INFO - 2018-02-12 16:46:02 --> Helper loaded: settings_helper
INFO - 2018-02-12 16:46:02 --> Helper loaded: permission_helper
INFO - 2018-02-12 16:46:02 --> Helper loaded: users_helper
INFO - 2018-02-12 16:46:02 --> Database Driver Class Initialized
DEBUG - 2018-02-12 16:46:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 16:46:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 16:46:02 --> Helper loaded: form_helper
INFO - 2018-02-12 16:46:02 --> Form Validation Class Initialized
INFO - 2018-02-12 16:46:02 --> Controller Class Initialized
INFO - 2018-02-12 16:46:02 --> Model Class Initialized
INFO - 2018-02-12 16:46:02 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 16:46:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 16:46:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 16:46:02 --> Model Class Initialized
INFO - 2018-02-12 16:46:02 --> Model Class Initialized
INFO - 2018-02-12 16:46:02 --> Model Class Initialized
INFO - 2018-02-12 16:46:02 --> Model Class Initialized
INFO - 2018-02-12 16:46:02 --> Model Class Initialized
INFO - 2018-02-12 16:46:02 --> Model Class Initialized
INFO - 2018-02-12 16:46:02 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-02-12 16:46:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-02-12 16:46:02 --> Final output sent to browser
DEBUG - 2018-02-12 16:46:02 --> Total execution time: 0.3158
INFO - 2018-02-12 11:16:25 --> Config Class Initialized
INFO - 2018-02-12 11:16:25 --> Hooks Class Initialized
DEBUG - 2018-02-12 11:16:25 --> UTF-8 Support Enabled
INFO - 2018-02-12 11:16:25 --> Utf8 Class Initialized
INFO - 2018-02-12 11:16:25 --> URI Class Initialized
INFO - 2018-02-12 11:16:25 --> Router Class Initialized
INFO - 2018-02-12 11:16:25 --> Output Class Initialized
INFO - 2018-02-12 11:16:25 --> Security Class Initialized
DEBUG - 2018-02-12 11:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 11:16:25 --> Input Class Initialized
INFO - 2018-02-12 11:16:25 --> Language Class Initialized
INFO - 2018-02-12 11:16:25 --> Language Class Initialized
INFO - 2018-02-12 11:16:25 --> Config Class Initialized
INFO - 2018-02-12 11:16:25 --> Loader Class Initialized
INFO - 2018-02-12 16:46:25 --> Helper loaded: url_helper
INFO - 2018-02-12 16:46:25 --> Helper loaded: notification_helper
INFO - 2018-02-12 16:46:25 --> Helper loaded: settings_helper
INFO - 2018-02-12 16:46:25 --> Helper loaded: permission_helper
INFO - 2018-02-12 16:46:25 --> Helper loaded: users_helper
INFO - 2018-02-12 16:46:25 --> Database Driver Class Initialized
DEBUG - 2018-02-12 16:46:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 16:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 16:46:25 --> Helper loaded: form_helper
INFO - 2018-02-12 16:46:25 --> Form Validation Class Initialized
INFO - 2018-02-12 16:46:25 --> Controller Class Initialized
INFO - 2018-02-12 16:46:25 --> Model Class Initialized
INFO - 2018-02-12 16:46:25 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 16:46:25 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 16:46:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 16:46:25 --> Model Class Initialized
INFO - 2018-02-12 16:46:25 --> Model Class Initialized
INFO - 2018-02-12 16:46:25 --> Model Class Initialized
INFO - 2018-02-12 16:46:25 --> Model Class Initialized
INFO - 2018-02-12 16:46:25 --> Model Class Initialized
INFO - 2018-02-12 16:46:25 --> Model Class Initialized
INFO - 2018-02-12 16:46:25 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 16:46:25 --> Final output sent to browser
DEBUG - 2018-02-12 16:46:25 --> Total execution time: 0.0878
INFO - 2018-02-12 11:16:30 --> Config Class Initialized
INFO - 2018-02-12 11:16:30 --> Hooks Class Initialized
DEBUG - 2018-02-12 11:16:30 --> UTF-8 Support Enabled
INFO - 2018-02-12 11:16:30 --> Utf8 Class Initialized
INFO - 2018-02-12 11:16:30 --> URI Class Initialized
INFO - 2018-02-12 11:16:30 --> Router Class Initialized
INFO - 2018-02-12 11:16:30 --> Output Class Initialized
INFO - 2018-02-12 11:16:30 --> Security Class Initialized
DEBUG - 2018-02-12 11:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 11:16:30 --> Input Class Initialized
INFO - 2018-02-12 11:16:30 --> Language Class Initialized
INFO - 2018-02-12 11:16:30 --> Language Class Initialized
INFO - 2018-02-12 11:16:30 --> Config Class Initialized
INFO - 2018-02-12 11:16:30 --> Loader Class Initialized
INFO - 2018-02-12 16:46:30 --> Helper loaded: url_helper
INFO - 2018-02-12 16:46:30 --> Helper loaded: notification_helper
INFO - 2018-02-12 16:46:30 --> Helper loaded: settings_helper
INFO - 2018-02-12 16:46:30 --> Helper loaded: permission_helper
INFO - 2018-02-12 16:46:30 --> Helper loaded: users_helper
INFO - 2018-02-12 16:46:30 --> Database Driver Class Initialized
DEBUG - 2018-02-12 16:46:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 16:46:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 16:46:30 --> Helper loaded: form_helper
INFO - 2018-02-12 16:46:30 --> Form Validation Class Initialized
INFO - 2018-02-12 16:46:30 --> Controller Class Initialized
INFO - 2018-02-12 16:46:30 --> Model Class Initialized
INFO - 2018-02-12 16:46:30 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 16:46:30 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 16:46:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 16:46:30 --> Model Class Initialized
INFO - 2018-02-12 16:46:30 --> Model Class Initialized
INFO - 2018-02-12 16:46:30 --> Model Class Initialized
INFO - 2018-02-12 16:46:30 --> Model Class Initialized
INFO - 2018-02-12 16:46:30 --> Model Class Initialized
INFO - 2018-02-12 16:46:30 --> Model Class Initialized
INFO - 2018-02-12 16:46:30 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-02-12 16:46:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-02-12 16:46:30 --> Final output sent to browser
DEBUG - 2018-02-12 16:46:30 --> Total execution time: 0.0936
INFO - 2018-02-12 11:19:31 --> Config Class Initialized
INFO - 2018-02-12 11:19:31 --> Hooks Class Initialized
DEBUG - 2018-02-12 11:19:31 --> UTF-8 Support Enabled
INFO - 2018-02-12 11:19:31 --> Utf8 Class Initialized
INFO - 2018-02-12 11:19:31 --> URI Class Initialized
INFO - 2018-02-12 11:19:31 --> Router Class Initialized
INFO - 2018-02-12 11:19:31 --> Output Class Initialized
INFO - 2018-02-12 11:19:31 --> Security Class Initialized
DEBUG - 2018-02-12 11:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 11:19:31 --> Input Class Initialized
INFO - 2018-02-12 11:19:31 --> Language Class Initialized
INFO - 2018-02-12 11:19:31 --> Language Class Initialized
INFO - 2018-02-12 11:19:31 --> Config Class Initialized
INFO - 2018-02-12 11:19:31 --> Loader Class Initialized
INFO - 2018-02-12 16:49:31 --> Helper loaded: url_helper
INFO - 2018-02-12 16:49:31 --> Helper loaded: notification_helper
INFO - 2018-02-12 16:49:31 --> Helper loaded: settings_helper
INFO - 2018-02-12 16:49:31 --> Helper loaded: permission_helper
INFO - 2018-02-12 16:49:31 --> Helper loaded: users_helper
INFO - 2018-02-12 16:49:31 --> Database Driver Class Initialized
DEBUG - 2018-02-12 16:49:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 16:49:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 16:49:31 --> Helper loaded: form_helper
INFO - 2018-02-12 16:49:31 --> Form Validation Class Initialized
INFO - 2018-02-12 16:49:31 --> Controller Class Initialized
INFO - 2018-02-12 16:49:31 --> Model Class Initialized
INFO - 2018-02-12 16:49:31 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 16:49:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 16:49:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 16:49:31 --> Model Class Initialized
INFO - 2018-02-12 16:49:31 --> Model Class Initialized
INFO - 2018-02-12 16:49:31 --> Model Class Initialized
INFO - 2018-02-12 16:49:31 --> Model Class Initialized
INFO - 2018-02-12 16:49:31 --> Model Class Initialized
INFO - 2018-02-12 16:49:31 --> Model Class Initialized
INFO - 2018-02-12 16:49:31 --> Model Class Initialized
INFO - 2018-02-12 16:49:31 --> Model Class Initialized
INFO - 2018-02-12 16:49:31 --> Model Class Initialized
INFO - 2018-02-12 16:49:31 --> Model Class Initialized
INFO - 2018-02-12 16:49:31 --> Model Class Initialized
INFO - 2018-02-12 16:49:31 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 16:49:31 --> Model Class Initialized
INFO - 2018-02-12 16:49:31 --> Final output sent to browser
DEBUG - 2018-02-12 16:49:31 --> Total execution time: 0.1455
INFO - 2018-02-12 11:19:32 --> Config Class Initialized
INFO - 2018-02-12 11:19:32 --> Hooks Class Initialized
DEBUG - 2018-02-12 11:19:32 --> UTF-8 Support Enabled
INFO - 2018-02-12 11:19:32 --> Utf8 Class Initialized
INFO - 2018-02-12 11:19:32 --> URI Class Initialized
INFO - 2018-02-12 11:19:32 --> Router Class Initialized
INFO - 2018-02-12 11:19:32 --> Output Class Initialized
INFO - 2018-02-12 11:19:32 --> Security Class Initialized
DEBUG - 2018-02-12 11:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 11:19:32 --> Input Class Initialized
INFO - 2018-02-12 11:19:32 --> Language Class Initialized
INFO - 2018-02-12 11:19:32 --> Language Class Initialized
INFO - 2018-02-12 11:19:32 --> Config Class Initialized
INFO - 2018-02-12 11:19:32 --> Loader Class Initialized
INFO - 2018-02-12 16:49:32 --> Helper loaded: url_helper
INFO - 2018-02-12 16:49:32 --> Helper loaded: notification_helper
INFO - 2018-02-12 16:49:32 --> Helper loaded: settings_helper
INFO - 2018-02-12 16:49:32 --> Helper loaded: permission_helper
INFO - 2018-02-12 16:49:32 --> Helper loaded: users_helper
INFO - 2018-02-12 16:49:32 --> Database Driver Class Initialized
DEBUG - 2018-02-12 16:49:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 16:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 16:49:32 --> Helper loaded: form_helper
INFO - 2018-02-12 16:49:32 --> Form Validation Class Initialized
INFO - 2018-02-12 16:49:32 --> Controller Class Initialized
INFO - 2018-02-12 16:49:32 --> Model Class Initialized
INFO - 2018-02-12 16:49:32 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 16:49:32 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 16:49:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 16:49:32 --> Model Class Initialized
INFO - 2018-02-12 16:49:32 --> Model Class Initialized
INFO - 2018-02-12 16:49:32 --> Model Class Initialized
INFO - 2018-02-12 16:49:32 --> Model Class Initialized
INFO - 2018-02-12 16:49:32 --> Model Class Initialized
INFO - 2018-02-12 16:49:32 --> Model Class Initialized
INFO - 2018-02-12 16:49:32 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 16:49:32 --> Model Class Initialized
INFO - 2018-02-12 16:49:32 --> Final output sent to browser
DEBUG - 2018-02-12 16:49:32 --> Total execution time: 0.1163
INFO - 2018-02-12 11:19:38 --> Config Class Initialized
INFO - 2018-02-12 11:19:38 --> Hooks Class Initialized
INFO - 2018-02-12 11:19:38 --> Config Class Initialized
INFO - 2018-02-12 11:19:38 --> Hooks Class Initialized
DEBUG - 2018-02-12 11:19:38 --> UTF-8 Support Enabled
INFO - 2018-02-12 11:19:38 --> Utf8 Class Initialized
INFO - 2018-02-12 11:19:38 --> URI Class Initialized
DEBUG - 2018-02-12 11:19:38 --> UTF-8 Support Enabled
INFO - 2018-02-12 11:19:38 --> Utf8 Class Initialized
INFO - 2018-02-12 11:19:38 --> URI Class Initialized
INFO - 2018-02-12 11:19:38 --> Router Class Initialized
INFO - 2018-02-12 11:19:38 --> Router Class Initialized
INFO - 2018-02-12 11:19:38 --> Output Class Initialized
INFO - 2018-02-12 11:19:38 --> Output Class Initialized
INFO - 2018-02-12 11:19:38 --> Security Class Initialized
INFO - 2018-02-12 11:19:38 --> Security Class Initialized
DEBUG - 2018-02-12 11:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 11:19:38 --> Input Class Initialized
INFO - 2018-02-12 11:19:38 --> Language Class Initialized
DEBUG - 2018-02-12 11:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 11:19:38 --> Input Class Initialized
INFO - 2018-02-12 11:19:38 --> Language Class Initialized
INFO - 2018-02-12 11:19:38 --> Language Class Initialized
INFO - 2018-02-12 11:19:38 --> Config Class Initialized
INFO - 2018-02-12 11:19:38 --> Loader Class Initialized
INFO - 2018-02-12 16:49:38 --> Helper loaded: url_helper
INFO - 2018-02-12 11:19:38 --> Language Class Initialized
INFO - 2018-02-12 11:19:38 --> Config Class Initialized
INFO - 2018-02-12 11:19:38 --> Loader Class Initialized
INFO - 2018-02-12 16:49:38 --> Helper loaded: notification_helper
INFO - 2018-02-12 16:49:38 --> Helper loaded: settings_helper
INFO - 2018-02-12 16:49:38 --> Helper loaded: permission_helper
INFO - 2018-02-12 16:49:38 --> Helper loaded: users_helper
INFO - 2018-02-12 16:49:38 --> Helper loaded: url_helper
INFO - 2018-02-12 16:49:38 --> Helper loaded: notification_helper
INFO - 2018-02-12 16:49:38 --> Helper loaded: settings_helper
INFO - 2018-02-12 16:49:38 --> Helper loaded: permission_helper
INFO - 2018-02-12 16:49:38 --> Helper loaded: users_helper
INFO - 2018-02-12 16:49:38 --> Database Driver Class Initialized
INFO - 2018-02-12 16:49:39 --> Database Driver Class Initialized
DEBUG - 2018-02-12 16:49:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 16:49:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-12 16:49:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 16:49:39 --> Helper loaded: form_helper
INFO - 2018-02-12 16:49:39 --> Form Validation Class Initialized
INFO - 2018-02-12 16:49:39 --> Controller Class Initialized
INFO - 2018-02-12 16:49:39 --> Model Class Initialized
INFO - 2018-02-12 16:49:39 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 16:49:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 16:49:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 16:49:39 --> Model Class Initialized
INFO - 2018-02-12 16:49:39 --> Model Class Initialized
INFO - 2018-02-12 16:49:39 --> Model Class Initialized
INFO - 2018-02-12 16:49:39 --> Model Class Initialized
INFO - 2018-02-12 16:49:39 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 16:49:39 --> Final output sent to browser
DEBUG - 2018-02-12 16:49:39 --> Total execution time: 0.1040
INFO - 2018-02-12 16:49:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 16:49:39 --> Helper loaded: form_helper
INFO - 2018-02-12 16:49:39 --> Form Validation Class Initialized
INFO - 2018-02-12 16:49:39 --> Controller Class Initialized
INFO - 2018-02-12 16:49:39 --> Model Class Initialized
INFO - 2018-02-12 16:49:39 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 16:49:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 16:49:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 16:49:39 --> Model Class Initialized
INFO - 2018-02-12 16:49:39 --> Model Class Initialized
INFO - 2018-02-12 16:49:39 --> Model Class Initialized
INFO - 2018-02-12 16:49:39 --> Model Class Initialized
INFO - 2018-02-12 16:49:39 --> Model Class Initialized
INFO - 2018-02-12 16:49:39 --> Model Class Initialized
INFO - 2018-02-12 16:49:39 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-02-12 16:49:39 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-02-12 16:49:39 --> Final output sent to browser
DEBUG - 2018-02-12 16:49:39 --> Total execution time: 0.1400
INFO - 2018-02-12 11:19:47 --> Config Class Initialized
INFO - 2018-02-12 11:19:47 --> Hooks Class Initialized
DEBUG - 2018-02-12 11:19:47 --> UTF-8 Support Enabled
INFO - 2018-02-12 11:19:47 --> Utf8 Class Initialized
INFO - 2018-02-12 11:19:47 --> URI Class Initialized
INFO - 2018-02-12 11:19:47 --> Router Class Initialized
INFO - 2018-02-12 11:19:47 --> Output Class Initialized
INFO - 2018-02-12 11:19:47 --> Security Class Initialized
DEBUG - 2018-02-12 11:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 11:19:47 --> Input Class Initialized
INFO - 2018-02-12 11:19:47 --> Language Class Initialized
INFO - 2018-02-12 11:19:48 --> Language Class Initialized
INFO - 2018-02-12 11:19:48 --> Config Class Initialized
INFO - 2018-02-12 11:19:48 --> Loader Class Initialized
INFO - 2018-02-12 16:49:48 --> Helper loaded: url_helper
INFO - 2018-02-12 16:49:48 --> Helper loaded: notification_helper
INFO - 2018-02-12 16:49:48 --> Helper loaded: settings_helper
INFO - 2018-02-12 16:49:48 --> Helper loaded: permission_helper
INFO - 2018-02-12 16:49:48 --> Helper loaded: users_helper
INFO - 2018-02-12 16:49:48 --> Database Driver Class Initialized
DEBUG - 2018-02-12 16:49:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 16:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 16:49:48 --> Helper loaded: form_helper
INFO - 2018-02-12 16:49:48 --> Form Validation Class Initialized
INFO - 2018-02-12 16:49:48 --> Controller Class Initialized
INFO - 2018-02-12 16:49:48 --> Model Class Initialized
INFO - 2018-02-12 16:49:48 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 16:49:48 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 16:49:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 16:49:48 --> Model Class Initialized
INFO - 2018-02-12 16:49:48 --> Model Class Initialized
INFO - 2018-02-12 16:49:48 --> Model Class Initialized
INFO - 2018-02-12 16:49:48 --> Model Class Initialized
INFO - 2018-02-12 16:49:48 --> Model Class Initialized
INFO - 2018-02-12 16:49:48 --> Model Class Initialized
INFO - 2018-02-12 16:49:48 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 16:49:48 --> Final output sent to browser
DEBUG - 2018-02-12 16:49:48 --> Total execution time: 0.1093
INFO - 2018-02-12 11:19:49 --> Config Class Initialized
INFO - 2018-02-12 11:19:49 --> Hooks Class Initialized
DEBUG - 2018-02-12 11:19:49 --> UTF-8 Support Enabled
INFO - 2018-02-12 11:19:49 --> Utf8 Class Initialized
INFO - 2018-02-12 11:19:49 --> URI Class Initialized
INFO - 2018-02-12 11:19:49 --> Router Class Initialized
INFO - 2018-02-12 11:19:49 --> Output Class Initialized
INFO - 2018-02-12 11:19:49 --> Security Class Initialized
DEBUG - 2018-02-12 11:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 11:19:49 --> Input Class Initialized
INFO - 2018-02-12 11:19:49 --> Language Class Initialized
INFO - 2018-02-12 11:19:49 --> Language Class Initialized
INFO - 2018-02-12 11:19:49 --> Config Class Initialized
INFO - 2018-02-12 11:19:49 --> Loader Class Initialized
INFO - 2018-02-12 16:49:49 --> Helper loaded: url_helper
INFO - 2018-02-12 16:49:49 --> Helper loaded: notification_helper
INFO - 2018-02-12 16:49:49 --> Helper loaded: settings_helper
INFO - 2018-02-12 16:49:49 --> Helper loaded: permission_helper
INFO - 2018-02-12 16:49:49 --> Helper loaded: users_helper
INFO - 2018-02-12 16:49:49 --> Database Driver Class Initialized
DEBUG - 2018-02-12 16:49:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 16:49:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 16:49:49 --> Helper loaded: form_helper
INFO - 2018-02-12 16:49:49 --> Form Validation Class Initialized
INFO - 2018-02-12 16:49:49 --> Controller Class Initialized
INFO - 2018-02-12 16:49:49 --> Model Class Initialized
INFO - 2018-02-12 16:49:49 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 16:49:49 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 16:49:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 16:49:49 --> Model Class Initialized
INFO - 2018-02-12 16:49:49 --> Model Class Initialized
INFO - 2018-02-12 16:49:49 --> Model Class Initialized
INFO - 2018-02-12 16:49:49 --> Model Class Initialized
INFO - 2018-02-12 16:49:49 --> Model Class Initialized
INFO - 2018-02-12 16:49:49 --> Model Class Initialized
INFO - 2018-02-12 16:49:49 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-02-12 16:49:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-02-12 16:49:49 --> Final output sent to browser
DEBUG - 2018-02-12 16:49:49 --> Total execution time: 0.1109
INFO - 2018-02-12 11:19:52 --> Config Class Initialized
INFO - 2018-02-12 11:19:52 --> Hooks Class Initialized
DEBUG - 2018-02-12 11:19:52 --> UTF-8 Support Enabled
INFO - 2018-02-12 11:19:52 --> Utf8 Class Initialized
INFO - 2018-02-12 11:19:52 --> URI Class Initialized
INFO - 2018-02-12 11:19:52 --> Router Class Initialized
INFO - 2018-02-12 11:19:52 --> Output Class Initialized
INFO - 2018-02-12 11:19:52 --> Security Class Initialized
DEBUG - 2018-02-12 11:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 11:19:52 --> Input Class Initialized
INFO - 2018-02-12 11:19:52 --> Language Class Initialized
INFO - 2018-02-12 11:19:52 --> Language Class Initialized
INFO - 2018-02-12 11:19:52 --> Config Class Initialized
INFO - 2018-02-12 11:19:52 --> Loader Class Initialized
INFO - 2018-02-12 16:49:52 --> Helper loaded: url_helper
INFO - 2018-02-12 16:49:52 --> Helper loaded: notification_helper
INFO - 2018-02-12 16:49:52 --> Helper loaded: settings_helper
INFO - 2018-02-12 16:49:52 --> Helper loaded: permission_helper
INFO - 2018-02-12 16:49:52 --> Helper loaded: users_helper
INFO - 2018-02-12 16:49:52 --> Database Driver Class Initialized
DEBUG - 2018-02-12 16:49:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 16:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 16:49:52 --> Helper loaded: form_helper
INFO - 2018-02-12 16:49:52 --> Form Validation Class Initialized
INFO - 2018-02-12 16:49:52 --> Controller Class Initialized
INFO - 2018-02-12 16:49:52 --> Model Class Initialized
INFO - 2018-02-12 16:49:52 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 16:49:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 16:49:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 16:49:52 --> Model Class Initialized
INFO - 2018-02-12 16:49:52 --> Model Class Initialized
INFO - 2018-02-12 16:49:52 --> Model Class Initialized
INFO - 2018-02-12 16:49:52 --> Model Class Initialized
INFO - 2018-02-12 16:49:52 --> Model Class Initialized
INFO - 2018-02-12 16:49:52 --> Model Class Initialized
INFO - 2018-02-12 16:49:52 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 16:49:52 --> Final output sent to browser
DEBUG - 2018-02-12 16:49:52 --> Total execution time: 0.1116
INFO - 2018-02-12 11:19:54 --> Config Class Initialized
INFO - 2018-02-12 11:19:54 --> Hooks Class Initialized
DEBUG - 2018-02-12 11:19:54 --> UTF-8 Support Enabled
INFO - 2018-02-12 11:19:54 --> Utf8 Class Initialized
INFO - 2018-02-12 11:19:54 --> URI Class Initialized
INFO - 2018-02-12 11:19:54 --> Router Class Initialized
INFO - 2018-02-12 11:19:54 --> Output Class Initialized
INFO - 2018-02-12 11:19:54 --> Security Class Initialized
DEBUG - 2018-02-12 11:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 11:19:54 --> Input Class Initialized
INFO - 2018-02-12 11:19:54 --> Language Class Initialized
INFO - 2018-02-12 11:19:54 --> Language Class Initialized
INFO - 2018-02-12 11:19:54 --> Config Class Initialized
INFO - 2018-02-12 11:19:54 --> Loader Class Initialized
INFO - 2018-02-12 16:49:54 --> Helper loaded: url_helper
INFO - 2018-02-12 16:49:54 --> Helper loaded: notification_helper
INFO - 2018-02-12 16:49:54 --> Helper loaded: settings_helper
INFO - 2018-02-12 16:49:54 --> Helper loaded: permission_helper
INFO - 2018-02-12 16:49:54 --> Helper loaded: users_helper
INFO - 2018-02-12 16:49:54 --> Database Driver Class Initialized
DEBUG - 2018-02-12 16:49:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 16:49:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 16:49:54 --> Helper loaded: form_helper
INFO - 2018-02-12 16:49:54 --> Form Validation Class Initialized
INFO - 2018-02-12 16:49:54 --> Controller Class Initialized
INFO - 2018-02-12 16:49:54 --> Model Class Initialized
INFO - 2018-02-12 16:49:54 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 16:49:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 16:49:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 16:49:54 --> Model Class Initialized
INFO - 2018-02-12 16:49:54 --> Model Class Initialized
INFO - 2018-02-12 16:49:54 --> Model Class Initialized
INFO - 2018-02-12 16:49:54 --> Model Class Initialized
INFO - 2018-02-12 16:49:54 --> Model Class Initialized
INFO - 2018-02-12 16:49:54 --> Model Class Initialized
INFO - 2018-02-12 16:49:54 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-02-12 16:49:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-02-12 16:49:54 --> Final output sent to browser
DEBUG - 2018-02-12 16:49:54 --> Total execution time: 0.1048
INFO - 2018-02-12 11:20:00 --> Config Class Initialized
INFO - 2018-02-12 11:20:00 --> Hooks Class Initialized
DEBUG - 2018-02-12 11:20:00 --> UTF-8 Support Enabled
INFO - 2018-02-12 11:20:00 --> Utf8 Class Initialized
INFO - 2018-02-12 11:20:00 --> URI Class Initialized
INFO - 2018-02-12 11:20:00 --> Router Class Initialized
INFO - 2018-02-12 11:20:00 --> Output Class Initialized
INFO - 2018-02-12 11:20:00 --> Security Class Initialized
DEBUG - 2018-02-12 11:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 11:20:00 --> Input Class Initialized
INFO - 2018-02-12 11:20:00 --> Language Class Initialized
INFO - 2018-02-12 11:20:00 --> Language Class Initialized
INFO - 2018-02-12 11:20:00 --> Config Class Initialized
INFO - 2018-02-12 11:20:00 --> Loader Class Initialized
INFO - 2018-02-12 16:50:00 --> Helper loaded: url_helper
INFO - 2018-02-12 16:50:00 --> Helper loaded: notification_helper
INFO - 2018-02-12 16:50:00 --> Helper loaded: settings_helper
INFO - 2018-02-12 16:50:00 --> Helper loaded: permission_helper
INFO - 2018-02-12 16:50:00 --> Helper loaded: users_helper
INFO - 2018-02-12 16:50:00 --> Database Driver Class Initialized
DEBUG - 2018-02-12 16:50:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 16:50:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 16:50:00 --> Helper loaded: form_helper
INFO - 2018-02-12 16:50:00 --> Form Validation Class Initialized
INFO - 2018-02-12 16:50:00 --> Controller Class Initialized
INFO - 2018-02-12 16:50:00 --> Model Class Initialized
INFO - 2018-02-12 16:50:00 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 16:50:00 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 16:50:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 16:50:00 --> Model Class Initialized
INFO - 2018-02-12 16:50:00 --> Model Class Initialized
INFO - 2018-02-12 16:50:00 --> Model Class Initialized
INFO - 2018-02-12 16:50:00 --> Model Class Initialized
INFO - 2018-02-12 16:50:00 --> Model Class Initialized
INFO - 2018-02-12 16:50:00 --> Model Class Initialized
INFO - 2018-02-12 16:50:00 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 16:50:00 --> Final output sent to browser
DEBUG - 2018-02-12 16:50:00 --> Total execution time: 0.1527
INFO - 2018-02-12 11:51:12 --> Config Class Initialized
INFO - 2018-02-12 11:51:12 --> Hooks Class Initialized
DEBUG - 2018-02-12 11:51:12 --> UTF-8 Support Enabled
INFO - 2018-02-12 11:51:12 --> Utf8 Class Initialized
INFO - 2018-02-12 11:51:12 --> URI Class Initialized
INFO - 2018-02-12 11:51:12 --> Router Class Initialized
INFO - 2018-02-12 11:51:12 --> Output Class Initialized
INFO - 2018-02-12 11:51:12 --> Security Class Initialized
DEBUG - 2018-02-12 11:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 11:51:12 --> Input Class Initialized
INFO - 2018-02-12 11:51:12 --> Language Class Initialized
INFO - 2018-02-12 11:51:12 --> Language Class Initialized
INFO - 2018-02-12 11:51:12 --> Config Class Initialized
INFO - 2018-02-12 11:51:12 --> Loader Class Initialized
INFO - 2018-02-12 17:21:12 --> Helper loaded: url_helper
INFO - 2018-02-12 17:21:12 --> Helper loaded: notification_helper
INFO - 2018-02-12 17:21:12 --> Helper loaded: settings_helper
INFO - 2018-02-12 17:21:12 --> Helper loaded: permission_helper
INFO - 2018-02-12 17:21:12 --> Helper loaded: users_helper
INFO - 2018-02-12 17:21:12 --> Database Driver Class Initialized
DEBUG - 2018-02-12 17:21:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 17:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 17:21:12 --> Helper loaded: form_helper
INFO - 2018-02-12 17:21:12 --> Form Validation Class Initialized
INFO - 2018-02-12 17:21:12 --> Controller Class Initialized
INFO - 2018-02-12 17:21:12 --> Model Class Initialized
INFO - 2018-02-12 17:21:12 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 17:21:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 17:21:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 17:21:12 --> Model Class Initialized
INFO - 2018-02-12 17:21:12 --> Model Class Initialized
INFO - 2018-02-12 17:21:12 --> Model Class Initialized
INFO - 2018-02-12 17:21:12 --> Model Class Initialized
INFO - 2018-02-12 17:21:12 --> Model Class Initialized
INFO - 2018-02-12 17:21:12 --> Model Class Initialized
INFO - 2018-02-12 17:21:12 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 17:21:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-12 17:21:12 --> Final output sent to browser
DEBUG - 2018-02-12 17:21:12 --> Total execution time: 0.1112
INFO - 2018-02-12 11:51:12 --> Config Class Initialized
INFO - 2018-02-12 11:51:12 --> Hooks Class Initialized
DEBUG - 2018-02-12 11:51:12 --> UTF-8 Support Enabled
INFO - 2018-02-12 11:51:12 --> Utf8 Class Initialized
INFO - 2018-02-12 11:51:12 --> URI Class Initialized
INFO - 2018-02-12 11:51:12 --> Router Class Initialized
INFO - 2018-02-12 11:51:12 --> Output Class Initialized
INFO - 2018-02-12 11:51:12 --> Security Class Initialized
DEBUG - 2018-02-12 11:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 11:51:12 --> Input Class Initialized
INFO - 2018-02-12 11:51:12 --> Language Class Initialized
INFO - 2018-02-12 11:51:13 --> Language Class Initialized
INFO - 2018-02-12 11:51:13 --> Config Class Initialized
INFO - 2018-02-12 11:51:13 --> Loader Class Initialized
INFO - 2018-02-12 17:21:13 --> Helper loaded: url_helper
INFO - 2018-02-12 17:21:13 --> Helper loaded: notification_helper
INFO - 2018-02-12 17:21:13 --> Helper loaded: settings_helper
INFO - 2018-02-12 17:21:13 --> Helper loaded: permission_helper
INFO - 2018-02-12 17:21:13 --> Helper loaded: users_helper
INFO - 2018-02-12 17:21:13 --> Database Driver Class Initialized
DEBUG - 2018-02-12 17:21:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 17:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 17:21:13 --> Helper loaded: form_helper
INFO - 2018-02-12 17:21:13 --> Form Validation Class Initialized
INFO - 2018-02-12 17:21:13 --> Controller Class Initialized
INFO - 2018-02-12 17:21:13 --> Model Class Initialized
INFO - 2018-02-12 17:21:13 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 17:21:13 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 17:21:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 17:21:13 --> Model Class Initialized
INFO - 2018-02-12 17:21:13 --> Model Class Initialized
INFO - 2018-02-12 17:21:13 --> Model Class Initialized
INFO - 2018-02-12 17:21:13 --> Model Class Initialized
INFO - 2018-02-12 17:21:13 --> Model Class Initialized
INFO - 2018-02-12 17:21:13 --> Model Class Initialized
INFO - 2018-02-12 17:21:13 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 17:21:13 --> Final output sent to browser
DEBUG - 2018-02-12 17:21:13 --> Total execution time: 0.1157
INFO - 2018-02-12 11:55:44 --> Config Class Initialized
INFO - 2018-02-12 11:55:44 --> Hooks Class Initialized
DEBUG - 2018-02-12 11:55:44 --> UTF-8 Support Enabled
INFO - 2018-02-12 11:55:44 --> Utf8 Class Initialized
INFO - 2018-02-12 11:55:44 --> URI Class Initialized
INFO - 2018-02-12 11:55:44 --> Router Class Initialized
INFO - 2018-02-12 11:55:44 --> Output Class Initialized
INFO - 2018-02-12 11:55:44 --> Security Class Initialized
DEBUG - 2018-02-12 11:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 11:55:44 --> Input Class Initialized
INFO - 2018-02-12 11:55:44 --> Language Class Initialized
INFO - 2018-02-12 11:55:44 --> Language Class Initialized
INFO - 2018-02-12 11:55:44 --> Config Class Initialized
INFO - 2018-02-12 11:55:44 --> Loader Class Initialized
INFO - 2018-02-12 17:25:44 --> Helper loaded: url_helper
INFO - 2018-02-12 17:25:44 --> Helper loaded: notification_helper
INFO - 2018-02-12 17:25:44 --> Helper loaded: settings_helper
INFO - 2018-02-12 17:25:44 --> Helper loaded: permission_helper
INFO - 2018-02-12 17:25:44 --> Helper loaded: users_helper
INFO - 2018-02-12 17:25:44 --> Database Driver Class Initialized
DEBUG - 2018-02-12 17:25:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 17:25:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 17:25:44 --> Helper loaded: form_helper
INFO - 2018-02-12 17:25:44 --> Form Validation Class Initialized
INFO - 2018-02-12 17:25:44 --> Controller Class Initialized
INFO - 2018-02-12 17:25:44 --> Model Class Initialized
INFO - 2018-02-12 17:25:44 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 17:25:44 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 17:25:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 17:25:44 --> Model Class Initialized
INFO - 2018-02-12 17:25:44 --> Model Class Initialized
INFO - 2018-02-12 17:25:44 --> Model Class Initialized
INFO - 2018-02-12 17:25:44 --> Model Class Initialized
INFO - 2018-02-12 17:25:44 --> Model Class Initialized
INFO - 2018-02-12 17:25:44 --> Model Class Initialized
INFO - 2018-02-12 17:25:44 --> Model Class Initialized
INFO - 2018-02-12 17:25:44 --> Model Class Initialized
INFO - 2018-02-12 17:25:44 --> Model Class Initialized
INFO - 2018-02-12 17:25:44 --> Model Class Initialized
INFO - 2018-02-12 17:25:44 --> Model Class Initialized
INFO - 2018-02-12 17:25:44 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 17:25:44 --> Model Class Initialized
INFO - 2018-02-12 17:25:44 --> Final output sent to browser
DEBUG - 2018-02-12 17:25:44 --> Total execution time: 0.1267
INFO - 2018-02-12 11:55:45 --> Config Class Initialized
INFO - 2018-02-12 11:55:45 --> Hooks Class Initialized
DEBUG - 2018-02-12 11:55:45 --> UTF-8 Support Enabled
INFO - 2018-02-12 11:55:45 --> Utf8 Class Initialized
INFO - 2018-02-12 11:55:45 --> URI Class Initialized
INFO - 2018-02-12 11:55:45 --> Router Class Initialized
INFO - 2018-02-12 11:55:45 --> Output Class Initialized
INFO - 2018-02-12 11:55:45 --> Security Class Initialized
DEBUG - 2018-02-12 11:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 11:55:45 --> Input Class Initialized
INFO - 2018-02-12 11:55:45 --> Language Class Initialized
INFO - 2018-02-12 11:55:45 --> Language Class Initialized
INFO - 2018-02-12 11:55:45 --> Config Class Initialized
INFO - 2018-02-12 11:55:45 --> Loader Class Initialized
INFO - 2018-02-12 17:25:45 --> Helper loaded: url_helper
INFO - 2018-02-12 17:25:45 --> Helper loaded: notification_helper
INFO - 2018-02-12 17:25:45 --> Helper loaded: settings_helper
INFO - 2018-02-12 17:25:45 --> Helper loaded: permission_helper
INFO - 2018-02-12 17:25:45 --> Helper loaded: users_helper
INFO - 2018-02-12 17:25:45 --> Database Driver Class Initialized
DEBUG - 2018-02-12 17:25:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 17:25:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 17:25:45 --> Helper loaded: form_helper
INFO - 2018-02-12 17:25:45 --> Form Validation Class Initialized
INFO - 2018-02-12 17:25:45 --> Controller Class Initialized
INFO - 2018-02-12 17:25:45 --> Model Class Initialized
INFO - 2018-02-12 17:25:45 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 17:25:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 17:25:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 17:25:45 --> Model Class Initialized
INFO - 2018-02-12 17:25:45 --> Model Class Initialized
INFO - 2018-02-12 17:25:45 --> Model Class Initialized
INFO - 2018-02-12 17:25:45 --> Model Class Initialized
INFO - 2018-02-12 17:25:45 --> Model Class Initialized
INFO - 2018-02-12 17:25:45 --> Model Class Initialized
INFO - 2018-02-12 17:25:45 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 17:25:45 --> Model Class Initialized
INFO - 2018-02-12 17:25:45 --> Final output sent to browser
DEBUG - 2018-02-12 17:25:45 --> Total execution time: 0.1169
INFO - 2018-02-12 11:55:55 --> Config Class Initialized
INFO - 2018-02-12 11:55:55 --> Hooks Class Initialized
DEBUG - 2018-02-12 11:55:55 --> UTF-8 Support Enabled
INFO - 2018-02-12 11:55:55 --> Utf8 Class Initialized
INFO - 2018-02-12 11:55:55 --> URI Class Initialized
INFO - 2018-02-12 11:55:55 --> Router Class Initialized
INFO - 2018-02-12 11:55:55 --> Output Class Initialized
INFO - 2018-02-12 11:55:55 --> Security Class Initialized
INFO - 2018-02-12 11:55:55 --> Config Class Initialized
INFO - 2018-02-12 11:55:55 --> Hooks Class Initialized
DEBUG - 2018-02-12 11:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 11:55:55 --> Input Class Initialized
INFO - 2018-02-12 11:55:55 --> Language Class Initialized
DEBUG - 2018-02-12 11:55:55 --> UTF-8 Support Enabled
INFO - 2018-02-12 11:55:55 --> Utf8 Class Initialized
INFO - 2018-02-12 11:55:55 --> URI Class Initialized
INFO - 2018-02-12 11:55:55 --> Router Class Initialized
INFO - 2018-02-12 11:55:55 --> Language Class Initialized
INFO - 2018-02-12 11:55:55 --> Config Class Initialized
INFO - 2018-02-12 11:55:55 --> Loader Class Initialized
INFO - 2018-02-12 17:25:55 --> Helper loaded: url_helper
INFO - 2018-02-12 11:55:55 --> Output Class Initialized
INFO - 2018-02-12 17:25:55 --> Helper loaded: notification_helper
INFO - 2018-02-12 17:25:55 --> Helper loaded: settings_helper
INFO - 2018-02-12 17:25:55 --> Helper loaded: permission_helper
INFO - 2018-02-12 17:25:55 --> Helper loaded: users_helper
INFO - 2018-02-12 11:55:55 --> Security Class Initialized
DEBUG - 2018-02-12 11:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 11:55:55 --> Input Class Initialized
INFO - 2018-02-12 11:55:55 --> Language Class Initialized
INFO - 2018-02-12 17:25:55 --> Database Driver Class Initialized
DEBUG - 2018-02-12 17:25:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 17:25:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 17:25:55 --> Helper loaded: form_helper
INFO - 2018-02-12 17:25:55 --> Form Validation Class Initialized
INFO - 2018-02-12 17:25:55 --> Controller Class Initialized
INFO - 2018-02-12 17:25:55 --> Model Class Initialized
INFO - 2018-02-12 17:25:55 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 17:25:55 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 11:55:55 --> Language Class Initialized
INFO - 2018-02-12 11:55:55 --> Config Class Initialized
INFO - 2018-02-12 11:55:55 --> Loader Class Initialized
INFO - 2018-02-12 17:25:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 17:25:55 --> Model Class Initialized
INFO - 2018-02-12 17:25:55 --> Model Class Initialized
INFO - 2018-02-12 17:25:55 --> Model Class Initialized
INFO - 2018-02-12 17:25:55 --> Helper loaded: url_helper
INFO - 2018-02-12 17:25:55 --> Model Class Initialized
INFO - 2018-02-12 17:25:55 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 17:25:55 --> Helper loaded: notification_helper
INFO - 2018-02-12 17:25:55 --> Helper loaded: settings_helper
INFO - 2018-02-12 17:25:55 --> Final output sent to browser
INFO - 2018-02-12 17:25:55 --> Helper loaded: permission_helper
DEBUG - 2018-02-12 17:25:55 --> Total execution time: 0.0799
INFO - 2018-02-12 17:25:55 --> Helper loaded: users_helper
INFO - 2018-02-12 17:25:55 --> Database Driver Class Initialized
DEBUG - 2018-02-12 17:25:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 17:25:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 17:25:55 --> Helper loaded: form_helper
INFO - 2018-02-12 17:25:55 --> Form Validation Class Initialized
INFO - 2018-02-12 17:25:55 --> Controller Class Initialized
INFO - 2018-02-12 17:25:55 --> Model Class Initialized
INFO - 2018-02-12 17:25:55 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 17:25:55 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 17:25:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 17:25:55 --> Model Class Initialized
INFO - 2018-02-12 17:25:55 --> Model Class Initialized
INFO - 2018-02-12 17:25:55 --> Model Class Initialized
INFO - 2018-02-12 17:25:55 --> Model Class Initialized
INFO - 2018-02-12 17:25:55 --> Model Class Initialized
INFO - 2018-02-12 17:25:55 --> Model Class Initialized
INFO - 2018-02-12 17:25:55 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 17:25:55 --> Final output sent to browser
DEBUG - 2018-02-12 17:25:55 --> Total execution time: 0.1407
INFO - 2018-02-12 11:56:03 --> Config Class Initialized
INFO - 2018-02-12 11:56:03 --> Hooks Class Initialized
DEBUG - 2018-02-12 11:56:03 --> UTF-8 Support Enabled
INFO - 2018-02-12 11:56:03 --> Utf8 Class Initialized
INFO - 2018-02-12 11:56:03 --> URI Class Initialized
INFO - 2018-02-12 11:56:03 --> Router Class Initialized
INFO - 2018-02-12 11:56:03 --> Output Class Initialized
INFO - 2018-02-12 11:56:03 --> Security Class Initialized
DEBUG - 2018-02-12 11:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 11:56:03 --> Input Class Initialized
INFO - 2018-02-12 11:56:03 --> Language Class Initialized
INFO - 2018-02-12 11:56:03 --> Language Class Initialized
INFO - 2018-02-12 11:56:03 --> Config Class Initialized
INFO - 2018-02-12 11:56:03 --> Loader Class Initialized
INFO - 2018-02-12 17:26:03 --> Helper loaded: url_helper
INFO - 2018-02-12 17:26:03 --> Helper loaded: notification_helper
INFO - 2018-02-12 17:26:03 --> Helper loaded: settings_helper
INFO - 2018-02-12 17:26:03 --> Helper loaded: permission_helper
INFO - 2018-02-12 17:26:03 --> Helper loaded: users_helper
INFO - 2018-02-12 17:26:03 --> Database Driver Class Initialized
DEBUG - 2018-02-12 17:26:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 17:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 17:26:03 --> Helper loaded: form_helper
INFO - 2018-02-12 17:26:03 --> Form Validation Class Initialized
INFO - 2018-02-12 17:26:03 --> Controller Class Initialized
INFO - 2018-02-12 17:26:03 --> Model Class Initialized
INFO - 2018-02-12 17:26:03 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 17:26:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 17:26:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 17:26:03 --> Model Class Initialized
INFO - 2018-02-12 17:26:03 --> Model Class Initialized
INFO - 2018-02-12 17:26:03 --> Model Class Initialized
INFO - 2018-02-12 17:26:03 --> Model Class Initialized
INFO - 2018-02-12 17:26:03 --> Model Class Initialized
INFO - 2018-02-12 17:26:03 --> Model Class Initialized
INFO - 2018-02-12 17:26:03 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 17:26:03 --> Final output sent to browser
DEBUG - 2018-02-12 17:26:03 --> Total execution time: 0.1146
INFO - 2018-02-12 11:57:50 --> Config Class Initialized
INFO - 2018-02-12 11:57:50 --> Hooks Class Initialized
DEBUG - 2018-02-12 11:57:50 --> UTF-8 Support Enabled
INFO - 2018-02-12 11:57:50 --> Utf8 Class Initialized
INFO - 2018-02-12 11:57:50 --> URI Class Initialized
INFO - 2018-02-12 11:57:50 --> Router Class Initialized
INFO - 2018-02-12 11:57:50 --> Output Class Initialized
INFO - 2018-02-12 11:57:50 --> Security Class Initialized
DEBUG - 2018-02-12 11:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 11:57:50 --> Input Class Initialized
INFO - 2018-02-12 11:57:50 --> Language Class Initialized
INFO - 2018-02-12 11:57:50 --> Language Class Initialized
INFO - 2018-02-12 11:57:50 --> Config Class Initialized
INFO - 2018-02-12 11:57:50 --> Loader Class Initialized
INFO - 2018-02-12 17:27:50 --> Helper loaded: url_helper
INFO - 2018-02-12 17:27:50 --> Helper loaded: notification_helper
INFO - 2018-02-12 17:27:50 --> Helper loaded: settings_helper
INFO - 2018-02-12 17:27:50 --> Helper loaded: permission_helper
INFO - 2018-02-12 17:27:50 --> Helper loaded: users_helper
INFO - 2018-02-12 17:27:50 --> Database Driver Class Initialized
DEBUG - 2018-02-12 17:27:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 17:27:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 17:27:50 --> Helper loaded: form_helper
INFO - 2018-02-12 17:27:50 --> Form Validation Class Initialized
INFO - 2018-02-12 17:27:50 --> Controller Class Initialized
INFO - 2018-02-12 17:27:50 --> Model Class Initialized
INFO - 2018-02-12 17:27:50 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 17:27:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 17:27:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 17:27:50 --> Model Class Initialized
INFO - 2018-02-12 17:27:50 --> Model Class Initialized
INFO - 2018-02-12 17:27:50 --> Model Class Initialized
INFO - 2018-02-12 17:27:50 --> Model Class Initialized
INFO - 2018-02-12 17:27:50 --> Model Class Initialized
INFO - 2018-02-12 17:27:50 --> Model Class Initialized
INFO - 2018-02-12 17:27:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 17:27:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-12 17:27:50 --> Final output sent to browser
DEBUG - 2018-02-12 17:27:50 --> Total execution time: 0.1038
INFO - 2018-02-12 11:57:51 --> Config Class Initialized
INFO - 2018-02-12 11:57:51 --> Hooks Class Initialized
DEBUG - 2018-02-12 11:57:51 --> UTF-8 Support Enabled
INFO - 2018-02-12 11:57:51 --> Utf8 Class Initialized
INFO - 2018-02-12 11:57:51 --> URI Class Initialized
INFO - 2018-02-12 11:57:51 --> Router Class Initialized
INFO - 2018-02-12 11:57:51 --> Output Class Initialized
INFO - 2018-02-12 11:57:51 --> Security Class Initialized
DEBUG - 2018-02-12 11:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 11:57:51 --> Input Class Initialized
INFO - 2018-02-12 11:57:51 --> Language Class Initialized
INFO - 2018-02-12 11:57:51 --> Language Class Initialized
INFO - 2018-02-12 11:57:51 --> Config Class Initialized
INFO - 2018-02-12 11:57:51 --> Loader Class Initialized
INFO - 2018-02-12 17:27:51 --> Helper loaded: url_helper
INFO - 2018-02-12 17:27:51 --> Helper loaded: notification_helper
INFO - 2018-02-12 17:27:51 --> Helper loaded: settings_helper
INFO - 2018-02-12 17:27:51 --> Helper loaded: permission_helper
INFO - 2018-02-12 17:27:51 --> Helper loaded: users_helper
INFO - 2018-02-12 17:27:51 --> Database Driver Class Initialized
DEBUG - 2018-02-12 17:27:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 17:27:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 17:27:51 --> Helper loaded: form_helper
INFO - 2018-02-12 17:27:51 --> Form Validation Class Initialized
INFO - 2018-02-12 17:27:51 --> Controller Class Initialized
INFO - 2018-02-12 17:27:51 --> Model Class Initialized
INFO - 2018-02-12 17:27:51 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 17:27:51 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 17:27:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 17:27:51 --> Model Class Initialized
INFO - 2018-02-12 17:27:51 --> Model Class Initialized
INFO - 2018-02-12 17:27:51 --> Model Class Initialized
INFO - 2018-02-12 17:27:51 --> Model Class Initialized
INFO - 2018-02-12 17:27:51 --> Model Class Initialized
INFO - 2018-02-12 17:27:51 --> Model Class Initialized
INFO - 2018-02-12 17:27:51 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 17:27:51 --> Final output sent to browser
DEBUG - 2018-02-12 17:27:51 --> Total execution time: 0.0853
INFO - 2018-02-12 11:57:51 --> Config Class Initialized
INFO - 2018-02-12 11:57:51 --> Hooks Class Initialized
DEBUG - 2018-02-12 11:57:51 --> UTF-8 Support Enabled
INFO - 2018-02-12 11:57:51 --> Utf8 Class Initialized
INFO - 2018-02-12 11:57:51 --> URI Class Initialized
INFO - 2018-02-12 11:57:51 --> Router Class Initialized
INFO - 2018-02-12 11:57:51 --> Output Class Initialized
INFO - 2018-02-12 11:57:51 --> Security Class Initialized
DEBUG - 2018-02-12 11:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 11:57:51 --> Input Class Initialized
INFO - 2018-02-12 11:57:51 --> Language Class Initialized
INFO - 2018-02-12 11:57:51 --> Language Class Initialized
INFO - 2018-02-12 11:57:51 --> Config Class Initialized
INFO - 2018-02-12 11:57:51 --> Loader Class Initialized
INFO - 2018-02-12 17:27:51 --> Helper loaded: url_helper
INFO - 2018-02-12 17:27:51 --> Helper loaded: notification_helper
INFO - 2018-02-12 17:27:51 --> Helper loaded: settings_helper
INFO - 2018-02-12 17:27:51 --> Helper loaded: permission_helper
INFO - 2018-02-12 17:27:51 --> Helper loaded: users_helper
INFO - 2018-02-12 17:27:51 --> Database Driver Class Initialized
DEBUG - 2018-02-12 17:27:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 17:27:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 17:27:51 --> Helper loaded: form_helper
INFO - 2018-02-12 17:27:51 --> Form Validation Class Initialized
INFO - 2018-02-12 17:27:51 --> Controller Class Initialized
INFO - 2018-02-12 17:27:51 --> Model Class Initialized
INFO - 2018-02-12 17:27:51 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 17:27:51 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 17:27:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 17:27:51 --> Model Class Initialized
INFO - 2018-02-12 17:27:51 --> Model Class Initialized
INFO - 2018-02-12 17:27:51 --> Model Class Initialized
INFO - 2018-02-12 17:27:51 --> Model Class Initialized
INFO - 2018-02-12 17:27:51 --> Model Class Initialized
INFO - 2018-02-12 17:27:51 --> Model Class Initialized
INFO - 2018-02-12 17:27:51 --> Model Class Initialized
INFO - 2018-02-12 17:27:51 --> Model Class Initialized
INFO - 2018-02-12 17:27:51 --> Model Class Initialized
INFO - 2018-02-12 17:27:51 --> Model Class Initialized
INFO - 2018-02-12 17:27:51 --> Model Class Initialized
INFO - 2018-02-12 17:27:51 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 17:27:51 --> Model Class Initialized
INFO - 2018-02-12 17:27:51 --> Final output sent to browser
DEBUG - 2018-02-12 17:27:51 --> Total execution time: 0.1064
INFO - 2018-02-12 11:57:54 --> Config Class Initialized
INFO - 2018-02-12 11:57:54 --> Hooks Class Initialized
DEBUG - 2018-02-12 11:57:54 --> UTF-8 Support Enabled
INFO - 2018-02-12 11:57:54 --> Utf8 Class Initialized
INFO - 2018-02-12 11:57:54 --> URI Class Initialized
INFO - 2018-02-12 11:57:54 --> Router Class Initialized
INFO - 2018-02-12 11:57:54 --> Output Class Initialized
INFO - 2018-02-12 11:57:54 --> Security Class Initialized
DEBUG - 2018-02-12 11:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 11:57:54 --> Input Class Initialized
INFO - 2018-02-12 11:57:54 --> Language Class Initialized
INFO - 2018-02-12 11:57:54 --> Language Class Initialized
INFO - 2018-02-12 11:57:54 --> Config Class Initialized
INFO - 2018-02-12 11:57:54 --> Loader Class Initialized
INFO - 2018-02-12 17:27:54 --> Helper loaded: url_helper
INFO - 2018-02-12 17:27:54 --> Helper loaded: notification_helper
INFO - 2018-02-12 17:27:54 --> Helper loaded: settings_helper
INFO - 2018-02-12 17:27:54 --> Helper loaded: permission_helper
INFO - 2018-02-12 17:27:54 --> Helper loaded: users_helper
INFO - 2018-02-12 17:27:54 --> Database Driver Class Initialized
DEBUG - 2018-02-12 17:27:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 17:27:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 17:27:54 --> Helper loaded: form_helper
INFO - 2018-02-12 17:27:54 --> Form Validation Class Initialized
INFO - 2018-02-12 17:27:54 --> Controller Class Initialized
INFO - 2018-02-12 17:27:54 --> Model Class Initialized
INFO - 2018-02-12 17:27:54 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 17:27:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 17:27:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 17:27:54 --> Model Class Initialized
INFO - 2018-02-12 17:27:54 --> Model Class Initialized
INFO - 2018-02-12 17:27:54 --> Model Class Initialized
INFO - 2018-02-12 17:27:54 --> Model Class Initialized
INFO - 2018-02-12 17:27:54 --> Model Class Initialized
INFO - 2018-02-12 17:27:54 --> Model Class Initialized
INFO - 2018-02-12 17:27:54 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 17:27:54 --> Final output sent to browser
DEBUG - 2018-02-12 17:27:54 --> Total execution time: 0.1148
INFO - 2018-02-12 11:58:04 --> Config Class Initialized
INFO - 2018-02-12 11:58:04 --> Hooks Class Initialized
DEBUG - 2018-02-12 11:58:04 --> UTF-8 Support Enabled
INFO - 2018-02-12 11:58:04 --> Utf8 Class Initialized
INFO - 2018-02-12 11:58:04 --> URI Class Initialized
INFO - 2018-02-12 11:58:04 --> Router Class Initialized
INFO - 2018-02-12 11:58:04 --> Output Class Initialized
INFO - 2018-02-12 11:58:04 --> Security Class Initialized
DEBUG - 2018-02-12 11:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 11:58:04 --> Input Class Initialized
INFO - 2018-02-12 11:58:04 --> Language Class Initialized
INFO - 2018-02-12 11:58:04 --> Language Class Initialized
INFO - 2018-02-12 11:58:04 --> Config Class Initialized
INFO - 2018-02-12 11:58:04 --> Loader Class Initialized
INFO - 2018-02-12 17:28:04 --> Helper loaded: url_helper
INFO - 2018-02-12 17:28:04 --> Helper loaded: notification_helper
INFO - 2018-02-12 17:28:04 --> Helper loaded: settings_helper
INFO - 2018-02-12 17:28:04 --> Helper loaded: permission_helper
INFO - 2018-02-12 17:28:04 --> Helper loaded: users_helper
INFO - 2018-02-12 17:28:04 --> Database Driver Class Initialized
DEBUG - 2018-02-12 17:28:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 17:28:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 17:28:04 --> Helper loaded: form_helper
INFO - 2018-02-12 17:28:04 --> Form Validation Class Initialized
INFO - 2018-02-12 17:28:04 --> Controller Class Initialized
INFO - 2018-02-12 17:28:04 --> Model Class Initialized
INFO - 2018-02-12 17:28:04 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 17:28:04 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 17:28:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 17:28:04 --> Model Class Initialized
INFO - 2018-02-12 17:28:04 --> Model Class Initialized
INFO - 2018-02-12 17:28:04 --> Model Class Initialized
INFO - 2018-02-12 17:28:04 --> Model Class Initialized
INFO - 2018-02-12 17:28:04 --> Model Class Initialized
INFO - 2018-02-12 17:28:04 --> Model Class Initialized
INFO - 2018-02-12 17:28:04 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 17:28:04 --> Final output sent to browser
DEBUG - 2018-02-12 17:28:04 --> Total execution time: 0.1191
INFO - 2018-02-12 11:58:12 --> Config Class Initialized
INFO - 2018-02-12 11:58:12 --> Hooks Class Initialized
DEBUG - 2018-02-12 11:58:12 --> UTF-8 Support Enabled
INFO - 2018-02-12 11:58:12 --> Utf8 Class Initialized
INFO - 2018-02-12 11:58:12 --> URI Class Initialized
INFO - 2018-02-12 11:58:12 --> Router Class Initialized
INFO - 2018-02-12 11:58:12 --> Output Class Initialized
INFO - 2018-02-12 11:58:12 --> Security Class Initialized
DEBUG - 2018-02-12 11:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 11:58:12 --> Input Class Initialized
INFO - 2018-02-12 11:58:12 --> Language Class Initialized
INFO - 2018-02-12 11:58:12 --> Language Class Initialized
INFO - 2018-02-12 11:58:12 --> Config Class Initialized
INFO - 2018-02-12 11:58:12 --> Loader Class Initialized
INFO - 2018-02-12 17:28:12 --> Helper loaded: url_helper
INFO - 2018-02-12 17:28:12 --> Helper loaded: notification_helper
INFO - 2018-02-12 17:28:12 --> Helper loaded: settings_helper
INFO - 2018-02-12 17:28:12 --> Helper loaded: permission_helper
INFO - 2018-02-12 17:28:12 --> Helper loaded: users_helper
INFO - 2018-02-12 17:28:12 --> Database Driver Class Initialized
DEBUG - 2018-02-12 17:28:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 17:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 17:28:12 --> Helper loaded: form_helper
INFO - 2018-02-12 17:28:12 --> Form Validation Class Initialized
INFO - 2018-02-12 17:28:12 --> Controller Class Initialized
INFO - 2018-02-12 17:28:12 --> Model Class Initialized
INFO - 2018-02-12 17:28:12 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 17:28:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 17:28:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 17:28:12 --> Model Class Initialized
INFO - 2018-02-12 17:28:12 --> Model Class Initialized
INFO - 2018-02-12 17:28:12 --> Model Class Initialized
INFO - 2018-02-12 17:28:12 --> Model Class Initialized
INFO - 2018-02-12 17:28:12 --> Model Class Initialized
INFO - 2018-02-12 17:28:12 --> Model Class Initialized
INFO - 2018-02-12 17:28:12 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 17:28:12 --> Final output sent to browser
DEBUG - 2018-02-12 17:28:12 --> Total execution time: 0.0763
INFO - 2018-02-12 11:58:15 --> Config Class Initialized
INFO - 2018-02-12 11:58:15 --> Hooks Class Initialized
DEBUG - 2018-02-12 11:58:15 --> UTF-8 Support Enabled
INFO - 2018-02-12 11:58:15 --> Utf8 Class Initialized
INFO - 2018-02-12 11:58:15 --> URI Class Initialized
INFO - 2018-02-12 11:58:15 --> Router Class Initialized
INFO - 2018-02-12 11:58:15 --> Output Class Initialized
INFO - 2018-02-12 11:58:15 --> Security Class Initialized
DEBUG - 2018-02-12 11:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 11:58:15 --> Input Class Initialized
INFO - 2018-02-12 11:58:15 --> Language Class Initialized
INFO - 2018-02-12 11:58:15 --> Language Class Initialized
INFO - 2018-02-12 11:58:15 --> Config Class Initialized
INFO - 2018-02-12 11:58:15 --> Loader Class Initialized
INFO - 2018-02-12 17:28:15 --> Helper loaded: url_helper
INFO - 2018-02-12 17:28:15 --> Helper loaded: notification_helper
INFO - 2018-02-12 17:28:15 --> Helper loaded: settings_helper
INFO - 2018-02-12 17:28:15 --> Helper loaded: permission_helper
INFO - 2018-02-12 17:28:15 --> Helper loaded: users_helper
INFO - 2018-02-12 17:28:15 --> Database Driver Class Initialized
DEBUG - 2018-02-12 17:28:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 17:28:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 17:28:15 --> Helper loaded: form_helper
INFO - 2018-02-12 17:28:15 --> Form Validation Class Initialized
INFO - 2018-02-12 17:28:15 --> Controller Class Initialized
INFO - 2018-02-12 17:28:15 --> Model Class Initialized
INFO - 2018-02-12 17:28:15 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 17:28:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 17:28:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 17:28:15 --> Model Class Initialized
INFO - 2018-02-12 17:28:15 --> Model Class Initialized
INFO - 2018-02-12 17:28:15 --> Model Class Initialized
INFO - 2018-02-12 17:28:15 --> Model Class Initialized
INFO - 2018-02-12 17:28:15 --> Model Class Initialized
INFO - 2018-02-12 17:28:15 --> Model Class Initialized
INFO - 2018-02-12 17:28:15 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 17:28:15 --> Final output sent to browser
DEBUG - 2018-02-12 17:28:15 --> Total execution time: 0.1188
INFO - 2018-02-12 11:58:29 --> Config Class Initialized
INFO - 2018-02-12 11:58:29 --> Hooks Class Initialized
DEBUG - 2018-02-12 11:58:29 --> UTF-8 Support Enabled
INFO - 2018-02-12 11:58:29 --> Utf8 Class Initialized
INFO - 2018-02-12 11:58:29 --> URI Class Initialized
INFO - 2018-02-12 11:58:29 --> Router Class Initialized
INFO - 2018-02-12 11:58:29 --> Output Class Initialized
INFO - 2018-02-12 11:58:29 --> Security Class Initialized
DEBUG - 2018-02-12 11:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 11:58:29 --> Input Class Initialized
INFO - 2018-02-12 11:58:29 --> Language Class Initialized
INFO - 2018-02-12 11:58:29 --> Language Class Initialized
INFO - 2018-02-12 11:58:29 --> Config Class Initialized
INFO - 2018-02-12 11:58:29 --> Loader Class Initialized
INFO - 2018-02-12 17:28:29 --> Helper loaded: url_helper
INFO - 2018-02-12 17:28:29 --> Helper loaded: notification_helper
INFO - 2018-02-12 17:28:29 --> Helper loaded: settings_helper
INFO - 2018-02-12 17:28:29 --> Helper loaded: permission_helper
INFO - 2018-02-12 17:28:29 --> Helper loaded: users_helper
INFO - 2018-02-12 17:28:29 --> Database Driver Class Initialized
DEBUG - 2018-02-12 17:28:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 17:28:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 17:28:29 --> Helper loaded: form_helper
INFO - 2018-02-12 17:28:29 --> Form Validation Class Initialized
INFO - 2018-02-12 17:28:29 --> Controller Class Initialized
INFO - 2018-02-12 17:28:29 --> Model Class Initialized
INFO - 2018-02-12 17:28:29 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 17:28:29 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 17:28:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 17:28:29 --> Model Class Initialized
INFO - 2018-02-12 17:28:29 --> Model Class Initialized
INFO - 2018-02-12 17:28:29 --> Model Class Initialized
INFO - 2018-02-12 17:28:29 --> Model Class Initialized
INFO - 2018-02-12 17:28:29 --> Model Class Initialized
INFO - 2018-02-12 17:28:29 --> Model Class Initialized
INFO - 2018-02-12 17:28:29 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 17:28:29 --> Final output sent to browser
DEBUG - 2018-02-12 17:28:29 --> Total execution time: 0.1165
INFO - 2018-02-12 11:59:00 --> Config Class Initialized
INFO - 2018-02-12 11:59:00 --> Hooks Class Initialized
DEBUG - 2018-02-12 11:59:00 --> UTF-8 Support Enabled
INFO - 2018-02-12 11:59:00 --> Utf8 Class Initialized
INFO - 2018-02-12 11:59:00 --> URI Class Initialized
INFO - 2018-02-12 11:59:00 --> Router Class Initialized
INFO - 2018-02-12 11:59:00 --> Output Class Initialized
INFO - 2018-02-12 11:59:00 --> Security Class Initialized
DEBUG - 2018-02-12 11:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 11:59:00 --> Input Class Initialized
INFO - 2018-02-12 11:59:00 --> Language Class Initialized
INFO - 2018-02-12 11:59:00 --> Language Class Initialized
INFO - 2018-02-12 11:59:00 --> Config Class Initialized
INFO - 2018-02-12 11:59:00 --> Loader Class Initialized
INFO - 2018-02-12 17:29:00 --> Helper loaded: url_helper
INFO - 2018-02-12 17:29:00 --> Helper loaded: notification_helper
INFO - 2018-02-12 17:29:00 --> Helper loaded: settings_helper
INFO - 2018-02-12 17:29:00 --> Helper loaded: permission_helper
INFO - 2018-02-12 17:29:00 --> Helper loaded: users_helper
INFO - 2018-02-12 17:29:00 --> Database Driver Class Initialized
DEBUG - 2018-02-12 17:29:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 17:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 17:29:00 --> Helper loaded: form_helper
INFO - 2018-02-12 17:29:00 --> Form Validation Class Initialized
INFO - 2018-02-12 17:29:00 --> Controller Class Initialized
INFO - 2018-02-12 17:29:00 --> Model Class Initialized
INFO - 2018-02-12 17:29:00 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 17:29:00 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 17:29:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 17:29:00 --> Model Class Initialized
INFO - 2018-02-12 17:29:00 --> Model Class Initialized
INFO - 2018-02-12 17:29:00 --> Model Class Initialized
INFO - 2018-02-12 17:29:00 --> Model Class Initialized
INFO - 2018-02-12 17:29:00 --> Model Class Initialized
INFO - 2018-02-12 17:29:00 --> Model Class Initialized
INFO - 2018-02-12 17:29:00 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 17:29:00 --> Final output sent to browser
DEBUG - 2018-02-12 17:29:00 --> Total execution time: 0.0995
INFO - 2018-02-12 12:03:06 --> Config Class Initialized
INFO - 2018-02-12 12:03:06 --> Hooks Class Initialized
DEBUG - 2018-02-12 12:03:06 --> UTF-8 Support Enabled
INFO - 2018-02-12 12:03:06 --> Utf8 Class Initialized
INFO - 2018-02-12 12:03:06 --> URI Class Initialized
INFO - 2018-02-12 12:03:06 --> Router Class Initialized
INFO - 2018-02-12 12:03:06 --> Output Class Initialized
INFO - 2018-02-12 12:03:06 --> Security Class Initialized
DEBUG - 2018-02-12 12:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 12:03:06 --> Input Class Initialized
INFO - 2018-02-12 12:03:06 --> Language Class Initialized
INFO - 2018-02-12 12:03:06 --> Language Class Initialized
INFO - 2018-02-12 12:03:06 --> Config Class Initialized
INFO - 2018-02-12 12:03:06 --> Loader Class Initialized
INFO - 2018-02-12 17:33:06 --> Helper loaded: url_helper
INFO - 2018-02-12 17:33:06 --> Helper loaded: notification_helper
INFO - 2018-02-12 17:33:06 --> Helper loaded: settings_helper
INFO - 2018-02-12 17:33:06 --> Helper loaded: permission_helper
INFO - 2018-02-12 17:33:06 --> Helper loaded: users_helper
INFO - 2018-02-12 17:33:06 --> Database Driver Class Initialized
DEBUG - 2018-02-12 17:33:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 17:33:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 17:33:06 --> Helper loaded: form_helper
INFO - 2018-02-12 17:33:06 --> Form Validation Class Initialized
INFO - 2018-02-12 17:33:06 --> Controller Class Initialized
INFO - 2018-02-12 17:33:06 --> Model Class Initialized
INFO - 2018-02-12 17:33:06 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 17:33:06 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 17:33:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 17:33:06 --> Model Class Initialized
INFO - 2018-02-12 17:33:06 --> Model Class Initialized
INFO - 2018-02-12 17:33:06 --> Model Class Initialized
INFO - 2018-02-12 17:33:06 --> Model Class Initialized
INFO - 2018-02-12 17:33:06 --> Model Class Initialized
INFO - 2018-02-12 17:33:06 --> Model Class Initialized
INFO - 2018-02-12 17:33:06 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 17:33:06 --> Final output sent to browser
DEBUG - 2018-02-12 17:33:06 --> Total execution time: 0.1084
INFO - 2018-02-12 12:03:18 --> Config Class Initialized
INFO - 2018-02-12 12:03:18 --> Hooks Class Initialized
DEBUG - 2018-02-12 12:03:18 --> UTF-8 Support Enabled
INFO - 2018-02-12 12:03:18 --> Utf8 Class Initialized
INFO - 2018-02-12 12:03:18 --> URI Class Initialized
INFO - 2018-02-12 12:03:18 --> Router Class Initialized
INFO - 2018-02-12 12:03:18 --> Output Class Initialized
INFO - 2018-02-12 12:03:18 --> Security Class Initialized
DEBUG - 2018-02-12 12:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 12:03:18 --> Input Class Initialized
INFO - 2018-02-12 12:03:18 --> Language Class Initialized
INFO - 2018-02-12 12:03:18 --> Language Class Initialized
INFO - 2018-02-12 12:03:18 --> Config Class Initialized
INFO - 2018-02-12 12:03:18 --> Loader Class Initialized
INFO - 2018-02-12 17:33:18 --> Helper loaded: url_helper
INFO - 2018-02-12 17:33:18 --> Helper loaded: notification_helper
INFO - 2018-02-12 17:33:18 --> Helper loaded: settings_helper
INFO - 2018-02-12 17:33:18 --> Helper loaded: permission_helper
INFO - 2018-02-12 17:33:18 --> Helper loaded: users_helper
INFO - 2018-02-12 17:33:18 --> Database Driver Class Initialized
DEBUG - 2018-02-12 17:33:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 17:33:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 17:33:18 --> Helper loaded: form_helper
INFO - 2018-02-12 17:33:18 --> Form Validation Class Initialized
INFO - 2018-02-12 17:33:18 --> Controller Class Initialized
INFO - 2018-02-12 17:33:18 --> Model Class Initialized
INFO - 2018-02-12 17:33:18 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 17:33:18 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 17:33:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 17:33:18 --> Model Class Initialized
INFO - 2018-02-12 17:33:18 --> Model Class Initialized
INFO - 2018-02-12 17:33:18 --> Model Class Initialized
INFO - 2018-02-12 17:33:18 --> Model Class Initialized
INFO - 2018-02-12 17:33:18 --> Model Class Initialized
INFO - 2018-02-12 17:33:18 --> Model Class Initialized
INFO - 2018-02-12 17:33:18 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 17:33:18 --> Final output sent to browser
DEBUG - 2018-02-12 17:33:18 --> Total execution time: 0.1085
INFO - 2018-02-12 12:03:25 --> Config Class Initialized
INFO - 2018-02-12 12:03:25 --> Hooks Class Initialized
DEBUG - 2018-02-12 12:03:25 --> UTF-8 Support Enabled
INFO - 2018-02-12 12:03:25 --> Utf8 Class Initialized
INFO - 2018-02-12 12:03:25 --> URI Class Initialized
INFO - 2018-02-12 12:03:25 --> Router Class Initialized
INFO - 2018-02-12 12:03:25 --> Output Class Initialized
INFO - 2018-02-12 12:03:25 --> Security Class Initialized
DEBUG - 2018-02-12 12:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 12:03:25 --> Input Class Initialized
INFO - 2018-02-12 12:03:25 --> Language Class Initialized
INFO - 2018-02-12 12:03:25 --> Language Class Initialized
INFO - 2018-02-12 12:03:25 --> Config Class Initialized
INFO - 2018-02-12 12:03:25 --> Loader Class Initialized
INFO - 2018-02-12 17:33:25 --> Helper loaded: url_helper
INFO - 2018-02-12 17:33:25 --> Helper loaded: notification_helper
INFO - 2018-02-12 17:33:25 --> Helper loaded: settings_helper
INFO - 2018-02-12 17:33:25 --> Helper loaded: permission_helper
INFO - 2018-02-12 17:33:25 --> Helper loaded: users_helper
INFO - 2018-02-12 17:33:25 --> Database Driver Class Initialized
DEBUG - 2018-02-12 17:33:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 17:33:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 17:33:25 --> Helper loaded: form_helper
INFO - 2018-02-12 17:33:25 --> Form Validation Class Initialized
INFO - 2018-02-12 17:33:25 --> Controller Class Initialized
INFO - 2018-02-12 17:33:25 --> Model Class Initialized
INFO - 2018-02-12 17:33:25 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 17:33:25 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 17:33:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 17:33:25 --> Model Class Initialized
INFO - 2018-02-12 17:33:25 --> Model Class Initialized
INFO - 2018-02-12 17:33:25 --> Model Class Initialized
INFO - 2018-02-12 17:33:25 --> Model Class Initialized
INFO - 2018-02-12 17:33:25 --> Model Class Initialized
INFO - 2018-02-12 17:33:25 --> Model Class Initialized
INFO - 2018-02-12 17:33:25 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 17:33:25 --> Model Class Initialized
INFO - 2018-02-12 17:33:25 --> Final output sent to browser
DEBUG - 2018-02-12 17:33:25 --> Total execution time: 0.1148
INFO - 2018-02-12 12:03:45 --> Config Class Initialized
INFO - 2018-02-12 12:03:45 --> Hooks Class Initialized
DEBUG - 2018-02-12 12:03:45 --> UTF-8 Support Enabled
INFO - 2018-02-12 12:03:45 --> Utf8 Class Initialized
INFO - 2018-02-12 12:03:45 --> URI Class Initialized
INFO - 2018-02-12 12:03:45 --> Router Class Initialized
INFO - 2018-02-12 12:03:45 --> Output Class Initialized
INFO - 2018-02-12 12:03:45 --> Security Class Initialized
DEBUG - 2018-02-12 12:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 12:03:45 --> Input Class Initialized
INFO - 2018-02-12 12:03:45 --> Language Class Initialized
INFO - 2018-02-12 12:03:45 --> Language Class Initialized
INFO - 2018-02-12 12:03:45 --> Config Class Initialized
INFO - 2018-02-12 12:03:45 --> Loader Class Initialized
INFO - 2018-02-12 17:33:45 --> Helper loaded: url_helper
INFO - 2018-02-12 17:33:45 --> Helper loaded: notification_helper
INFO - 2018-02-12 17:33:45 --> Helper loaded: settings_helper
INFO - 2018-02-12 17:33:45 --> Helper loaded: permission_helper
INFO - 2018-02-12 17:33:45 --> Helper loaded: users_helper
INFO - 2018-02-12 17:33:45 --> Database Driver Class Initialized
DEBUG - 2018-02-12 17:33:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 17:33:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 17:33:45 --> Helper loaded: form_helper
INFO - 2018-02-12 17:33:45 --> Form Validation Class Initialized
INFO - 2018-02-12 17:33:45 --> Controller Class Initialized
INFO - 2018-02-12 17:33:45 --> Model Class Initialized
INFO - 2018-02-12 17:33:45 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 17:33:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 17:33:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 17:33:45 --> Model Class Initialized
INFO - 2018-02-12 17:33:45 --> Model Class Initialized
INFO - 2018-02-12 17:33:45 --> Model Class Initialized
INFO - 2018-02-12 17:33:45 --> Model Class Initialized
INFO - 2018-02-12 17:33:45 --> Model Class Initialized
INFO - 2018-02-12 17:33:45 --> Model Class Initialized
INFO - 2018-02-12 17:33:45 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 17:33:45 --> Model Class Initialized
INFO - 2018-02-12 17:33:45 --> Final output sent to browser
DEBUG - 2018-02-12 17:33:45 --> Total execution time: 0.1182
INFO - 2018-02-12 12:03:51 --> Config Class Initialized
INFO - 2018-02-12 12:03:51 --> Hooks Class Initialized
DEBUG - 2018-02-12 12:03:51 --> UTF-8 Support Enabled
INFO - 2018-02-12 12:03:51 --> Utf8 Class Initialized
INFO - 2018-02-12 12:03:51 --> URI Class Initialized
INFO - 2018-02-12 12:03:51 --> Router Class Initialized
INFO - 2018-02-12 12:03:51 --> Output Class Initialized
INFO - 2018-02-12 12:03:51 --> Security Class Initialized
DEBUG - 2018-02-12 12:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 12:03:51 --> Input Class Initialized
INFO - 2018-02-12 12:03:51 --> Language Class Initialized
INFO - 2018-02-12 12:03:51 --> Language Class Initialized
INFO - 2018-02-12 12:03:51 --> Config Class Initialized
INFO - 2018-02-12 12:03:51 --> Loader Class Initialized
INFO - 2018-02-12 17:33:51 --> Helper loaded: url_helper
INFO - 2018-02-12 17:33:51 --> Helper loaded: notification_helper
INFO - 2018-02-12 17:33:51 --> Helper loaded: settings_helper
INFO - 2018-02-12 17:33:51 --> Helper loaded: permission_helper
INFO - 2018-02-12 17:33:51 --> Helper loaded: users_helper
INFO - 2018-02-12 17:33:51 --> Database Driver Class Initialized
DEBUG - 2018-02-12 17:33:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 17:33:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 17:33:51 --> Helper loaded: form_helper
INFO - 2018-02-12 17:33:51 --> Form Validation Class Initialized
INFO - 2018-02-12 17:33:51 --> Controller Class Initialized
INFO - 2018-02-12 17:33:52 --> Model Class Initialized
INFO - 2018-02-12 17:33:52 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 17:33:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 17:33:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 17:33:52 --> Model Class Initialized
INFO - 2018-02-12 17:33:52 --> Model Class Initialized
INFO - 2018-02-12 17:33:52 --> Model Class Initialized
INFO - 2018-02-12 17:33:52 --> Model Class Initialized
INFO - 2018-02-12 17:33:52 --> Model Class Initialized
INFO - 2018-02-12 17:33:52 --> Model Class Initialized
INFO - 2018-02-12 17:33:52 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 17:33:52 --> Final output sent to browser
DEBUG - 2018-02-12 17:33:52 --> Total execution time: 0.1147
INFO - 2018-02-12 12:03:55 --> Config Class Initialized
INFO - 2018-02-12 12:03:55 --> Hooks Class Initialized
DEBUG - 2018-02-12 12:03:55 --> UTF-8 Support Enabled
INFO - 2018-02-12 12:03:55 --> Utf8 Class Initialized
INFO - 2018-02-12 12:03:55 --> URI Class Initialized
INFO - 2018-02-12 12:03:55 --> Router Class Initialized
INFO - 2018-02-12 12:03:55 --> Output Class Initialized
INFO - 2018-02-12 12:03:55 --> Security Class Initialized
DEBUG - 2018-02-12 12:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 12:03:55 --> Input Class Initialized
INFO - 2018-02-12 12:03:55 --> Language Class Initialized
INFO - 2018-02-12 12:03:55 --> Language Class Initialized
INFO - 2018-02-12 12:03:55 --> Config Class Initialized
INFO - 2018-02-12 12:03:55 --> Loader Class Initialized
INFO - 2018-02-12 17:33:55 --> Helper loaded: url_helper
INFO - 2018-02-12 17:33:55 --> Helper loaded: notification_helper
INFO - 2018-02-12 17:33:55 --> Helper loaded: settings_helper
INFO - 2018-02-12 17:33:55 --> Helper loaded: permission_helper
INFO - 2018-02-12 17:33:55 --> Helper loaded: users_helper
INFO - 2018-02-12 17:33:55 --> Database Driver Class Initialized
DEBUG - 2018-02-12 17:33:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 17:33:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 17:33:55 --> Helper loaded: form_helper
INFO - 2018-02-12 17:33:55 --> Form Validation Class Initialized
INFO - 2018-02-12 17:33:55 --> Controller Class Initialized
INFO - 2018-02-12 17:33:55 --> Model Class Initialized
INFO - 2018-02-12 17:33:55 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 17:33:55 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 17:33:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 17:33:55 --> Model Class Initialized
INFO - 2018-02-12 17:33:55 --> Model Class Initialized
INFO - 2018-02-12 17:33:55 --> Model Class Initialized
INFO - 2018-02-12 17:33:55 --> Model Class Initialized
INFO - 2018-02-12 17:33:55 --> Model Class Initialized
INFO - 2018-02-12 17:33:55 --> Model Class Initialized
INFO - 2018-02-12 17:33:55 --> Model Class Initialized
INFO - 2018-02-12 17:33:55 --> Model Class Initialized
INFO - 2018-02-12 17:33:55 --> Model Class Initialized
INFO - 2018-02-12 17:33:55 --> Model Class Initialized
INFO - 2018-02-12 17:33:55 --> Model Class Initialized
INFO - 2018-02-12 17:33:55 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 17:33:55 --> Model Class Initialized
INFO - 2018-02-12 17:33:55 --> Final output sent to browser
DEBUG - 2018-02-12 17:33:55 --> Total execution time: 0.0997
INFO - 2018-02-12 12:03:58 --> Config Class Initialized
INFO - 2018-02-12 12:03:58 --> Hooks Class Initialized
DEBUG - 2018-02-12 12:03:58 --> UTF-8 Support Enabled
INFO - 2018-02-12 12:03:58 --> Utf8 Class Initialized
INFO - 2018-02-12 12:03:58 --> URI Class Initialized
INFO - 2018-02-12 12:03:58 --> Router Class Initialized
INFO - 2018-02-12 12:03:58 --> Output Class Initialized
INFO - 2018-02-12 12:03:58 --> Security Class Initialized
DEBUG - 2018-02-12 12:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 12:03:58 --> Input Class Initialized
INFO - 2018-02-12 12:03:58 --> Language Class Initialized
INFO - 2018-02-12 12:03:58 --> Language Class Initialized
INFO - 2018-02-12 12:03:58 --> Config Class Initialized
INFO - 2018-02-12 12:03:58 --> Loader Class Initialized
INFO - 2018-02-12 17:33:58 --> Helper loaded: url_helper
INFO - 2018-02-12 17:33:58 --> Helper loaded: notification_helper
INFO - 2018-02-12 17:33:58 --> Helper loaded: settings_helper
INFO - 2018-02-12 17:33:58 --> Helper loaded: permission_helper
INFO - 2018-02-12 17:33:58 --> Helper loaded: users_helper
INFO - 2018-02-12 17:33:58 --> Database Driver Class Initialized
DEBUG - 2018-02-12 17:33:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 17:33:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 17:33:58 --> Helper loaded: form_helper
INFO - 2018-02-12 17:33:58 --> Form Validation Class Initialized
INFO - 2018-02-12 17:33:58 --> Controller Class Initialized
INFO - 2018-02-12 17:33:58 --> Model Class Initialized
INFO - 2018-02-12 17:33:58 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 17:33:58 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 17:33:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 17:33:58 --> Model Class Initialized
INFO - 2018-02-12 17:33:58 --> Model Class Initialized
INFO - 2018-02-12 17:33:58 --> Model Class Initialized
INFO - 2018-02-12 17:33:58 --> Model Class Initialized
INFO - 2018-02-12 17:33:58 --> Model Class Initialized
INFO - 2018-02-12 17:33:58 --> Model Class Initialized
INFO - 2018-02-12 17:33:58 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-02-12 17:33:58 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
ERROR - 2018-02-12 17:33:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 784
INFO - 2018-02-12 17:33:58 --> Final output sent to browser
DEBUG - 2018-02-12 17:33:58 --> Total execution time: 0.1150
INFO - 2018-02-12 12:04:05 --> Config Class Initialized
INFO - 2018-02-12 12:04:05 --> Hooks Class Initialized
DEBUG - 2018-02-12 12:04:05 --> UTF-8 Support Enabled
INFO - 2018-02-12 12:04:05 --> Utf8 Class Initialized
INFO - 2018-02-12 12:04:05 --> URI Class Initialized
INFO - 2018-02-12 12:04:05 --> Router Class Initialized
INFO - 2018-02-12 12:04:05 --> Output Class Initialized
INFO - 2018-02-12 12:04:05 --> Security Class Initialized
DEBUG - 2018-02-12 12:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 12:04:05 --> Input Class Initialized
INFO - 2018-02-12 12:04:05 --> Language Class Initialized
INFO - 2018-02-12 12:04:05 --> Language Class Initialized
INFO - 2018-02-12 12:04:05 --> Config Class Initialized
INFO - 2018-02-12 12:04:05 --> Loader Class Initialized
INFO - 2018-02-12 17:34:05 --> Helper loaded: url_helper
INFO - 2018-02-12 17:34:05 --> Helper loaded: notification_helper
INFO - 2018-02-12 17:34:05 --> Helper loaded: settings_helper
INFO - 2018-02-12 17:34:05 --> Helper loaded: permission_helper
INFO - 2018-02-12 17:34:05 --> Helper loaded: users_helper
INFO - 2018-02-12 17:34:05 --> Database Driver Class Initialized
DEBUG - 2018-02-12 17:34:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 17:34:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 17:34:05 --> Helper loaded: form_helper
INFO - 2018-02-12 17:34:05 --> Form Validation Class Initialized
INFO - 2018-02-12 17:34:05 --> Controller Class Initialized
INFO - 2018-02-12 17:34:05 --> Model Class Initialized
INFO - 2018-02-12 17:34:05 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 17:34:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 17:34:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 17:34:05 --> Model Class Initialized
INFO - 2018-02-12 17:34:05 --> Model Class Initialized
INFO - 2018-02-12 17:34:05 --> Model Class Initialized
INFO - 2018-02-12 17:34:05 --> Model Class Initialized
INFO - 2018-02-12 17:34:05 --> Model Class Initialized
INFO - 2018-02-12 17:34:05 --> Model Class Initialized
INFO - 2018-02-12 17:34:05 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 17:34:05 --> Model Class Initialized
INFO - 2018-02-12 17:34:05 --> Final output sent to browser
DEBUG - 2018-02-12 17:34:05 --> Total execution time: 0.1130
INFO - 2018-02-12 12:04:09 --> Config Class Initialized
INFO - 2018-02-12 12:04:09 --> Hooks Class Initialized
DEBUG - 2018-02-12 12:04:09 --> UTF-8 Support Enabled
INFO - 2018-02-12 12:04:09 --> Utf8 Class Initialized
INFO - 2018-02-12 12:04:09 --> URI Class Initialized
INFO - 2018-02-12 12:04:09 --> Router Class Initialized
INFO - 2018-02-12 12:04:09 --> Output Class Initialized
INFO - 2018-02-12 12:04:09 --> Security Class Initialized
DEBUG - 2018-02-12 12:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 12:04:09 --> Input Class Initialized
INFO - 2018-02-12 12:04:09 --> Language Class Initialized
INFO - 2018-02-12 12:04:09 --> Language Class Initialized
INFO - 2018-02-12 12:04:09 --> Config Class Initialized
INFO - 2018-02-12 12:04:09 --> Loader Class Initialized
INFO - 2018-02-12 17:34:09 --> Helper loaded: url_helper
INFO - 2018-02-12 17:34:09 --> Helper loaded: notification_helper
INFO - 2018-02-12 17:34:09 --> Helper loaded: settings_helper
INFO - 2018-02-12 17:34:09 --> Helper loaded: permission_helper
INFO - 2018-02-12 17:34:09 --> Helper loaded: users_helper
INFO - 2018-02-12 17:34:09 --> Database Driver Class Initialized
DEBUG - 2018-02-12 17:34:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 17:34:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 17:34:09 --> Helper loaded: form_helper
INFO - 2018-02-12 17:34:09 --> Form Validation Class Initialized
INFO - 2018-02-12 17:34:09 --> Controller Class Initialized
INFO - 2018-02-12 17:34:09 --> Model Class Initialized
INFO - 2018-02-12 17:34:09 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 17:34:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 17:34:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 17:34:09 --> Model Class Initialized
INFO - 2018-02-12 17:34:09 --> Model Class Initialized
INFO - 2018-02-12 17:34:09 --> Model Class Initialized
INFO - 2018-02-12 17:34:09 --> Model Class Initialized
INFO - 2018-02-12 17:34:09 --> Model Class Initialized
INFO - 2018-02-12 17:34:09 --> Model Class Initialized
INFO - 2018-02-12 17:34:09 --> Model Class Initialized
INFO - 2018-02-12 17:34:09 --> Model Class Initialized
INFO - 2018-02-12 17:34:09 --> Model Class Initialized
INFO - 2018-02-12 17:34:09 --> Model Class Initialized
INFO - 2018-02-12 17:34:09 --> Model Class Initialized
INFO - 2018-02-12 17:34:09 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 17:34:09 --> Model Class Initialized
INFO - 2018-02-12 17:34:09 --> Final output sent to browser
DEBUG - 2018-02-12 17:34:09 --> Total execution time: 0.1285
INFO - 2018-02-12 12:04:11 --> Config Class Initialized
INFO - 2018-02-12 12:04:11 --> Hooks Class Initialized
DEBUG - 2018-02-12 12:04:11 --> UTF-8 Support Enabled
INFO - 2018-02-12 12:04:11 --> Utf8 Class Initialized
INFO - 2018-02-12 12:04:11 --> URI Class Initialized
INFO - 2018-02-12 12:04:11 --> Router Class Initialized
INFO - 2018-02-12 12:04:11 --> Output Class Initialized
INFO - 2018-02-12 12:04:11 --> Security Class Initialized
DEBUG - 2018-02-12 12:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 12:04:11 --> Input Class Initialized
INFO - 2018-02-12 12:04:11 --> Language Class Initialized
INFO - 2018-02-12 12:04:11 --> Language Class Initialized
INFO - 2018-02-12 12:04:11 --> Config Class Initialized
INFO - 2018-02-12 12:04:11 --> Loader Class Initialized
INFO - 2018-02-12 17:34:11 --> Helper loaded: url_helper
INFO - 2018-02-12 17:34:11 --> Helper loaded: notification_helper
INFO - 2018-02-12 17:34:11 --> Helper loaded: settings_helper
INFO - 2018-02-12 17:34:11 --> Helper loaded: permission_helper
INFO - 2018-02-12 17:34:11 --> Helper loaded: users_helper
INFO - 2018-02-12 17:34:11 --> Database Driver Class Initialized
DEBUG - 2018-02-12 17:34:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 17:34:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 17:34:11 --> Helper loaded: form_helper
INFO - 2018-02-12 17:34:11 --> Form Validation Class Initialized
INFO - 2018-02-12 17:34:11 --> Controller Class Initialized
INFO - 2018-02-12 17:34:11 --> Model Class Initialized
INFO - 2018-02-12 17:34:11 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 17:34:11 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 17:34:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 17:34:11 --> Model Class Initialized
INFO - 2018-02-12 17:34:11 --> Model Class Initialized
INFO - 2018-02-12 17:34:11 --> Model Class Initialized
INFO - 2018-02-12 17:34:11 --> Model Class Initialized
INFO - 2018-02-12 17:34:11 --> Model Class Initialized
INFO - 2018-02-12 17:34:12 --> Model Class Initialized
INFO - 2018-02-12 17:34:12 --> Model Class Initialized
INFO - 2018-02-12 17:34:12 --> Model Class Initialized
INFO - 2018-02-12 17:34:12 --> Model Class Initialized
INFO - 2018-02-12 17:34:12 --> Model Class Initialized
INFO - 2018-02-12 17:34:12 --> Model Class Initialized
INFO - 2018-02-12 17:34:12 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 17:34:12 --> Final output sent to browser
DEBUG - 2018-02-12 17:34:12 --> Total execution time: 0.1387
INFO - 2018-02-12 12:04:16 --> Config Class Initialized
INFO - 2018-02-12 12:04:16 --> Hooks Class Initialized
DEBUG - 2018-02-12 12:04:16 --> UTF-8 Support Enabled
INFO - 2018-02-12 12:04:16 --> Utf8 Class Initialized
INFO - 2018-02-12 12:04:16 --> URI Class Initialized
INFO - 2018-02-12 12:04:17 --> Router Class Initialized
INFO - 2018-02-12 12:04:17 --> Output Class Initialized
INFO - 2018-02-12 12:04:17 --> Security Class Initialized
DEBUG - 2018-02-12 12:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 12:04:17 --> Input Class Initialized
INFO - 2018-02-12 12:04:17 --> Language Class Initialized
INFO - 2018-02-12 12:04:17 --> Language Class Initialized
INFO - 2018-02-12 12:04:17 --> Config Class Initialized
INFO - 2018-02-12 12:04:17 --> Loader Class Initialized
INFO - 2018-02-12 17:34:17 --> Helper loaded: url_helper
INFO - 2018-02-12 17:34:17 --> Helper loaded: notification_helper
INFO - 2018-02-12 17:34:17 --> Helper loaded: settings_helper
INFO - 2018-02-12 17:34:17 --> Helper loaded: permission_helper
INFO - 2018-02-12 17:34:17 --> Helper loaded: users_helper
INFO - 2018-02-12 17:34:17 --> Database Driver Class Initialized
DEBUG - 2018-02-12 17:34:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 17:34:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 17:34:17 --> Helper loaded: form_helper
INFO - 2018-02-12 17:34:17 --> Form Validation Class Initialized
INFO - 2018-02-12 17:34:17 --> Controller Class Initialized
INFO - 2018-02-12 17:34:17 --> Model Class Initialized
INFO - 2018-02-12 17:34:17 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 17:34:17 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 17:34:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 17:34:17 --> Model Class Initialized
INFO - 2018-02-12 17:34:17 --> Model Class Initialized
INFO - 2018-02-12 17:34:17 --> Model Class Initialized
INFO - 2018-02-12 17:34:17 --> Model Class Initialized
INFO - 2018-02-12 17:34:17 --> Model Class Initialized
INFO - 2018-02-12 17:34:17 --> Model Class Initialized
INFO - 2018-02-12 17:34:17 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-02-12 17:34:17 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-02-12 17:34:17 --> Final output sent to browser
DEBUG - 2018-02-12 17:34:17 --> Total execution time: 0.1168
INFO - 2018-02-12 12:04:24 --> Config Class Initialized
INFO - 2018-02-12 12:04:24 --> Hooks Class Initialized
DEBUG - 2018-02-12 12:04:24 --> UTF-8 Support Enabled
INFO - 2018-02-12 12:04:24 --> Utf8 Class Initialized
INFO - 2018-02-12 12:04:24 --> URI Class Initialized
INFO - 2018-02-12 12:04:24 --> Router Class Initialized
INFO - 2018-02-12 12:04:24 --> Output Class Initialized
INFO - 2018-02-12 12:04:24 --> Security Class Initialized
DEBUG - 2018-02-12 12:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 12:04:24 --> Input Class Initialized
INFO - 2018-02-12 12:04:24 --> Language Class Initialized
INFO - 2018-02-12 12:04:24 --> Language Class Initialized
INFO - 2018-02-12 12:04:24 --> Config Class Initialized
INFO - 2018-02-12 12:04:24 --> Loader Class Initialized
INFO - 2018-02-12 17:34:24 --> Helper loaded: url_helper
INFO - 2018-02-12 17:34:24 --> Helper loaded: notification_helper
INFO - 2018-02-12 17:34:24 --> Helper loaded: settings_helper
INFO - 2018-02-12 17:34:24 --> Helper loaded: permission_helper
INFO - 2018-02-12 17:34:24 --> Helper loaded: users_helper
INFO - 2018-02-12 17:34:24 --> Database Driver Class Initialized
DEBUG - 2018-02-12 17:34:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 17:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 17:34:24 --> Helper loaded: form_helper
INFO - 2018-02-12 17:34:24 --> Form Validation Class Initialized
INFO - 2018-02-12 17:34:24 --> Controller Class Initialized
INFO - 2018-02-12 17:34:24 --> Model Class Initialized
INFO - 2018-02-12 17:34:24 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 17:34:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 17:34:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 17:34:24 --> Model Class Initialized
INFO - 2018-02-12 17:34:24 --> Model Class Initialized
INFO - 2018-02-12 17:34:24 --> Model Class Initialized
INFO - 2018-02-12 17:34:24 --> Model Class Initialized
INFO - 2018-02-12 17:34:24 --> Model Class Initialized
INFO - 2018-02-12 17:34:24 --> Model Class Initialized
INFO - 2018-02-12 17:34:24 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 17:34:24 --> Model Class Initialized
INFO - 2018-02-12 17:34:24 --> Final output sent to browser
DEBUG - 2018-02-12 17:34:24 --> Total execution time: 0.0872
INFO - 2018-02-12 12:04:29 --> Config Class Initialized
INFO - 2018-02-12 12:04:29 --> Hooks Class Initialized
DEBUG - 2018-02-12 12:04:29 --> UTF-8 Support Enabled
INFO - 2018-02-12 12:04:29 --> Utf8 Class Initialized
INFO - 2018-02-12 12:04:29 --> URI Class Initialized
INFO - 2018-02-12 12:04:29 --> Router Class Initialized
INFO - 2018-02-12 12:04:29 --> Output Class Initialized
INFO - 2018-02-12 12:04:29 --> Security Class Initialized
DEBUG - 2018-02-12 12:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 12:04:29 --> Input Class Initialized
INFO - 2018-02-12 12:04:29 --> Language Class Initialized
INFO - 2018-02-12 12:04:29 --> Language Class Initialized
INFO - 2018-02-12 12:04:29 --> Config Class Initialized
INFO - 2018-02-12 12:04:29 --> Loader Class Initialized
INFO - 2018-02-12 17:34:29 --> Helper loaded: url_helper
INFO - 2018-02-12 17:34:29 --> Helper loaded: notification_helper
INFO - 2018-02-12 17:34:29 --> Helper loaded: settings_helper
INFO - 2018-02-12 17:34:29 --> Helper loaded: permission_helper
INFO - 2018-02-12 17:34:29 --> Helper loaded: users_helper
INFO - 2018-02-12 17:34:29 --> Database Driver Class Initialized
DEBUG - 2018-02-12 17:34:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 17:34:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 17:34:29 --> Helper loaded: form_helper
INFO - 2018-02-12 17:34:29 --> Form Validation Class Initialized
INFO - 2018-02-12 17:34:29 --> Controller Class Initialized
INFO - 2018-02-12 17:34:29 --> Model Class Initialized
INFO - 2018-02-12 17:34:29 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 17:34:29 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 17:34:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 17:34:29 --> Model Class Initialized
INFO - 2018-02-12 17:34:29 --> Model Class Initialized
INFO - 2018-02-12 17:34:29 --> Model Class Initialized
INFO - 2018-02-12 17:34:29 --> Model Class Initialized
INFO - 2018-02-12 17:34:29 --> Model Class Initialized
INFO - 2018-02-12 17:34:29 --> Model Class Initialized
INFO - 2018-02-12 17:34:29 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 17:34:29 --> Final output sent to browser
DEBUG - 2018-02-12 17:34:29 --> Total execution time: 0.1079
INFO - 2018-02-12 12:04:31 --> Config Class Initialized
INFO - 2018-02-12 12:04:31 --> Hooks Class Initialized
DEBUG - 2018-02-12 12:04:31 --> UTF-8 Support Enabled
INFO - 2018-02-12 12:04:31 --> Utf8 Class Initialized
INFO - 2018-02-12 12:04:31 --> URI Class Initialized
INFO - 2018-02-12 12:04:31 --> Router Class Initialized
INFO - 2018-02-12 12:04:31 --> Output Class Initialized
INFO - 2018-02-12 12:04:31 --> Security Class Initialized
DEBUG - 2018-02-12 12:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 12:04:31 --> Input Class Initialized
INFO - 2018-02-12 12:04:31 --> Language Class Initialized
INFO - 2018-02-12 12:04:31 --> Language Class Initialized
INFO - 2018-02-12 12:04:31 --> Config Class Initialized
INFO - 2018-02-12 12:04:31 --> Loader Class Initialized
INFO - 2018-02-12 17:34:31 --> Helper loaded: url_helper
INFO - 2018-02-12 17:34:31 --> Helper loaded: notification_helper
INFO - 2018-02-12 17:34:31 --> Helper loaded: settings_helper
INFO - 2018-02-12 17:34:31 --> Helper loaded: permission_helper
INFO - 2018-02-12 17:34:31 --> Helper loaded: users_helper
INFO - 2018-02-12 17:34:31 --> Database Driver Class Initialized
DEBUG - 2018-02-12 17:34:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 17:34:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 17:34:31 --> Helper loaded: form_helper
INFO - 2018-02-12 17:34:31 --> Form Validation Class Initialized
INFO - 2018-02-12 17:34:31 --> Controller Class Initialized
INFO - 2018-02-12 17:34:31 --> Model Class Initialized
INFO - 2018-02-12 17:34:31 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 17:34:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 17:34:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 17:34:31 --> Model Class Initialized
INFO - 2018-02-12 17:34:31 --> Model Class Initialized
INFO - 2018-02-12 17:34:31 --> Model Class Initialized
INFO - 2018-02-12 17:34:31 --> Model Class Initialized
INFO - 2018-02-12 17:34:31 --> Model Class Initialized
INFO - 2018-02-12 17:34:31 --> Model Class Initialized
INFO - 2018-02-12 17:34:31 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 17:34:31 --> Model Class Initialized
INFO - 2018-02-12 17:34:31 --> Final output sent to browser
DEBUG - 2018-02-12 17:34:31 --> Total execution time: 0.0925
INFO - 2018-02-12 12:04:42 --> Config Class Initialized
INFO - 2018-02-12 12:04:42 --> Hooks Class Initialized
DEBUG - 2018-02-12 12:04:42 --> UTF-8 Support Enabled
INFO - 2018-02-12 12:04:42 --> Utf8 Class Initialized
INFO - 2018-02-12 12:04:42 --> URI Class Initialized
INFO - 2018-02-12 12:04:42 --> Router Class Initialized
INFO - 2018-02-12 12:04:42 --> Output Class Initialized
INFO - 2018-02-12 12:04:42 --> Security Class Initialized
DEBUG - 2018-02-12 12:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 12:04:42 --> Input Class Initialized
INFO - 2018-02-12 12:04:42 --> Language Class Initialized
INFO - 2018-02-12 12:04:42 --> Language Class Initialized
INFO - 2018-02-12 12:04:42 --> Config Class Initialized
INFO - 2018-02-12 12:04:42 --> Loader Class Initialized
INFO - 2018-02-12 17:34:42 --> Helper loaded: url_helper
INFO - 2018-02-12 17:34:42 --> Helper loaded: notification_helper
INFO - 2018-02-12 17:34:42 --> Helper loaded: settings_helper
INFO - 2018-02-12 17:34:42 --> Helper loaded: permission_helper
INFO - 2018-02-12 17:34:42 --> Helper loaded: users_helper
INFO - 2018-02-12 17:34:42 --> Database Driver Class Initialized
DEBUG - 2018-02-12 17:34:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 17:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 17:34:42 --> Helper loaded: form_helper
INFO - 2018-02-12 17:34:42 --> Form Validation Class Initialized
INFO - 2018-02-12 17:34:42 --> Controller Class Initialized
INFO - 2018-02-12 17:34:42 --> Model Class Initialized
INFO - 2018-02-12 17:34:42 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 17:34:42 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 17:34:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 17:34:42 --> Model Class Initialized
INFO - 2018-02-12 17:34:42 --> Model Class Initialized
INFO - 2018-02-12 17:34:42 --> Model Class Initialized
INFO - 2018-02-12 17:34:42 --> Model Class Initialized
INFO - 2018-02-12 17:34:42 --> Model Class Initialized
INFO - 2018-02-12 17:34:42 --> Model Class Initialized
INFO - 2018-02-12 17:34:42 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 17:34:42 --> Model Class Initialized
INFO - 2018-02-12 17:34:42 --> Final output sent to browser
DEBUG - 2018-02-12 17:34:42 --> Total execution time: 0.1179
INFO - 2018-02-12 12:09:19 --> Config Class Initialized
INFO - 2018-02-12 12:09:19 --> Hooks Class Initialized
DEBUG - 2018-02-12 12:09:19 --> UTF-8 Support Enabled
INFO - 2018-02-12 12:09:19 --> Utf8 Class Initialized
INFO - 2018-02-12 12:09:19 --> URI Class Initialized
INFO - 2018-02-12 12:09:19 --> Router Class Initialized
INFO - 2018-02-12 12:09:19 --> Output Class Initialized
INFO - 2018-02-12 12:09:19 --> Security Class Initialized
DEBUG - 2018-02-12 12:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 12:09:19 --> Input Class Initialized
INFO - 2018-02-12 12:09:19 --> Language Class Initialized
INFO - 2018-02-12 12:09:19 --> Language Class Initialized
INFO - 2018-02-12 12:09:19 --> Config Class Initialized
INFO - 2018-02-12 12:09:19 --> Loader Class Initialized
INFO - 2018-02-12 17:39:19 --> Helper loaded: url_helper
INFO - 2018-02-12 17:39:19 --> Helper loaded: notification_helper
INFO - 2018-02-12 17:39:19 --> Helper loaded: settings_helper
INFO - 2018-02-12 17:39:19 --> Helper loaded: permission_helper
INFO - 2018-02-12 17:39:19 --> Helper loaded: users_helper
INFO - 2018-02-12 17:39:19 --> Database Driver Class Initialized
DEBUG - 2018-02-12 17:39:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 17:39:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 17:39:19 --> Helper loaded: form_helper
INFO - 2018-02-12 17:39:19 --> Form Validation Class Initialized
INFO - 2018-02-12 17:39:19 --> Controller Class Initialized
INFO - 2018-02-12 17:39:19 --> Model Class Initialized
INFO - 2018-02-12 17:39:19 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 17:39:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 17:39:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 17:39:19 --> Model Class Initialized
INFO - 2018-02-12 17:39:19 --> Model Class Initialized
INFO - 2018-02-12 17:39:19 --> Model Class Initialized
INFO - 2018-02-12 17:39:19 --> Model Class Initialized
INFO - 2018-02-12 17:39:19 --> Model Class Initialized
INFO - 2018-02-12 17:39:19 --> Model Class Initialized
INFO - 2018-02-12 17:39:19 --> Model Class Initialized
INFO - 2018-02-12 17:39:19 --> Model Class Initialized
INFO - 2018-02-12 17:39:19 --> Model Class Initialized
INFO - 2018-02-12 17:39:19 --> Model Class Initialized
INFO - 2018-02-12 17:39:19 --> Model Class Initialized
INFO - 2018-02-12 17:39:19 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 17:39:19 --> Model Class Initialized
INFO - 2018-02-12 17:39:19 --> Final output sent to browser
DEBUG - 2018-02-12 17:39:19 --> Total execution time: 0.1245
INFO - 2018-02-12 12:09:20 --> Config Class Initialized
INFO - 2018-02-12 12:09:20 --> Hooks Class Initialized
DEBUG - 2018-02-12 12:09:20 --> UTF-8 Support Enabled
INFO - 2018-02-12 12:09:20 --> Utf8 Class Initialized
INFO - 2018-02-12 12:09:20 --> URI Class Initialized
INFO - 2018-02-12 12:09:20 --> Router Class Initialized
INFO - 2018-02-12 12:09:20 --> Output Class Initialized
INFO - 2018-02-12 12:09:20 --> Security Class Initialized
DEBUG - 2018-02-12 12:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 12:09:20 --> Input Class Initialized
INFO - 2018-02-12 12:09:20 --> Language Class Initialized
INFO - 2018-02-12 12:09:20 --> Language Class Initialized
INFO - 2018-02-12 12:09:20 --> Config Class Initialized
INFO - 2018-02-12 12:09:20 --> Loader Class Initialized
INFO - 2018-02-12 17:39:20 --> Helper loaded: url_helper
INFO - 2018-02-12 17:39:20 --> Helper loaded: notification_helper
INFO - 2018-02-12 17:39:20 --> Helper loaded: settings_helper
INFO - 2018-02-12 17:39:20 --> Helper loaded: permission_helper
INFO - 2018-02-12 17:39:20 --> Helper loaded: users_helper
INFO - 2018-02-12 17:39:21 --> Database Driver Class Initialized
DEBUG - 2018-02-12 17:39:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 17:39:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 17:39:21 --> Helper loaded: form_helper
INFO - 2018-02-12 17:39:21 --> Form Validation Class Initialized
INFO - 2018-02-12 17:39:21 --> Controller Class Initialized
INFO - 2018-02-12 17:39:21 --> Model Class Initialized
INFO - 2018-02-12 17:39:21 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 17:39:21 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 17:39:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 17:39:21 --> Model Class Initialized
INFO - 2018-02-12 17:39:21 --> Model Class Initialized
INFO - 2018-02-12 17:39:21 --> Model Class Initialized
INFO - 2018-02-12 17:39:21 --> Model Class Initialized
INFO - 2018-02-12 17:39:21 --> Model Class Initialized
INFO - 2018-02-12 17:39:21 --> Model Class Initialized
INFO - 2018-02-12 17:39:21 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 17:39:21 --> Model Class Initialized
INFO - 2018-02-12 17:39:21 --> Final output sent to browser
DEBUG - 2018-02-12 17:39:21 --> Total execution time: 0.1160
INFO - 2018-02-12 12:09:36 --> Config Class Initialized
INFO - 2018-02-12 12:09:36 --> Hooks Class Initialized
DEBUG - 2018-02-12 12:09:36 --> UTF-8 Support Enabled
INFO - 2018-02-12 12:09:36 --> Utf8 Class Initialized
INFO - 2018-02-12 12:09:36 --> URI Class Initialized
INFO - 2018-02-12 12:09:36 --> Router Class Initialized
INFO - 2018-02-12 12:09:36 --> Output Class Initialized
INFO - 2018-02-12 12:09:36 --> Security Class Initialized
DEBUG - 2018-02-12 12:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 12:09:36 --> Input Class Initialized
INFO - 2018-02-12 12:09:36 --> Language Class Initialized
INFO - 2018-02-12 12:09:36 --> Language Class Initialized
INFO - 2018-02-12 12:09:36 --> Config Class Initialized
INFO - 2018-02-12 12:09:36 --> Loader Class Initialized
INFO - 2018-02-12 17:39:36 --> Helper loaded: url_helper
INFO - 2018-02-12 17:39:36 --> Helper loaded: notification_helper
INFO - 2018-02-12 17:39:36 --> Helper loaded: settings_helper
INFO - 2018-02-12 17:39:36 --> Helper loaded: permission_helper
INFO - 2018-02-12 17:39:36 --> Helper loaded: users_helper
INFO - 2018-02-12 17:39:36 --> Database Driver Class Initialized
DEBUG - 2018-02-12 17:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 17:39:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 17:39:36 --> Helper loaded: form_helper
INFO - 2018-02-12 17:39:36 --> Form Validation Class Initialized
INFO - 2018-02-12 17:39:36 --> Controller Class Initialized
INFO - 2018-02-12 17:39:36 --> Model Class Initialized
INFO - 2018-02-12 17:39:36 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 17:39:36 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 17:39:36 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 17:39:36 --> Model Class Initialized
INFO - 2018-02-12 17:39:36 --> Model Class Initialized
INFO - 2018-02-12 17:39:36 --> Model Class Initialized
INFO - 2018-02-12 17:39:36 --> Model Class Initialized
INFO - 2018-02-12 17:39:36 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 17:39:36 --> Final output sent to browser
DEBUG - 2018-02-12 17:39:36 --> Total execution time: 0.1038
INFO - 2018-02-12 12:09:37 --> Config Class Initialized
INFO - 2018-02-12 12:09:37 --> Hooks Class Initialized
DEBUG - 2018-02-12 12:09:37 --> UTF-8 Support Enabled
INFO - 2018-02-12 12:09:37 --> Utf8 Class Initialized
INFO - 2018-02-12 12:09:37 --> URI Class Initialized
INFO - 2018-02-12 12:09:37 --> Router Class Initialized
INFO - 2018-02-12 12:09:37 --> Output Class Initialized
INFO - 2018-02-12 12:09:37 --> Security Class Initialized
DEBUG - 2018-02-12 12:09:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 12:09:37 --> Input Class Initialized
INFO - 2018-02-12 12:09:37 --> Language Class Initialized
INFO - 2018-02-12 12:09:37 --> Language Class Initialized
INFO - 2018-02-12 12:09:37 --> Config Class Initialized
INFO - 2018-02-12 12:09:37 --> Loader Class Initialized
INFO - 2018-02-12 17:39:37 --> Helper loaded: url_helper
INFO - 2018-02-12 17:39:37 --> Helper loaded: notification_helper
INFO - 2018-02-12 17:39:37 --> Helper loaded: settings_helper
INFO - 2018-02-12 17:39:37 --> Helper loaded: permission_helper
INFO - 2018-02-12 17:39:37 --> Helper loaded: users_helper
INFO - 2018-02-12 17:39:37 --> Database Driver Class Initialized
DEBUG - 2018-02-12 17:39:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 17:39:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 17:39:37 --> Helper loaded: form_helper
INFO - 2018-02-12 17:39:37 --> Form Validation Class Initialized
INFO - 2018-02-12 17:39:37 --> Controller Class Initialized
INFO - 2018-02-12 17:39:37 --> Model Class Initialized
INFO - 2018-02-12 17:39:37 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 17:39:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 17:39:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 17:39:37 --> Model Class Initialized
INFO - 2018-02-12 17:39:37 --> Model Class Initialized
INFO - 2018-02-12 17:39:37 --> Model Class Initialized
INFO - 2018-02-12 17:39:37 --> Model Class Initialized
INFO - 2018-02-12 17:39:37 --> Model Class Initialized
INFO - 2018-02-12 17:39:37 --> Model Class Initialized
INFO - 2018-02-12 17:39:37 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 17:39:37 --> Final output sent to browser
DEBUG - 2018-02-12 17:39:37 --> Total execution time: 0.1118
INFO - 2018-02-12 12:09:41 --> Config Class Initialized
INFO - 2018-02-12 12:09:41 --> Hooks Class Initialized
DEBUG - 2018-02-12 12:09:41 --> UTF-8 Support Enabled
INFO - 2018-02-12 12:09:41 --> Utf8 Class Initialized
INFO - 2018-02-12 12:09:41 --> URI Class Initialized
INFO - 2018-02-12 12:09:41 --> Router Class Initialized
INFO - 2018-02-12 12:09:41 --> Output Class Initialized
INFO - 2018-02-12 12:09:41 --> Security Class Initialized
DEBUG - 2018-02-12 12:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 12:09:41 --> Input Class Initialized
INFO - 2018-02-12 12:09:41 --> Language Class Initialized
INFO - 2018-02-12 12:09:41 --> Language Class Initialized
INFO - 2018-02-12 12:09:41 --> Config Class Initialized
INFO - 2018-02-12 12:09:41 --> Loader Class Initialized
INFO - 2018-02-12 17:39:41 --> Helper loaded: url_helper
INFO - 2018-02-12 17:39:41 --> Helper loaded: notification_helper
INFO - 2018-02-12 17:39:41 --> Helper loaded: settings_helper
INFO - 2018-02-12 17:39:41 --> Helper loaded: permission_helper
INFO - 2018-02-12 17:39:41 --> Helper loaded: users_helper
INFO - 2018-02-12 17:39:41 --> Database Driver Class Initialized
DEBUG - 2018-02-12 17:39:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 17:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 17:39:41 --> Helper loaded: form_helper
INFO - 2018-02-12 17:39:41 --> Form Validation Class Initialized
INFO - 2018-02-12 17:39:41 --> Controller Class Initialized
INFO - 2018-02-12 17:39:41 --> Model Class Initialized
INFO - 2018-02-12 17:39:41 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 17:39:41 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 17:39:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 17:39:41 --> Model Class Initialized
INFO - 2018-02-12 17:39:41 --> Model Class Initialized
INFO - 2018-02-12 17:39:41 --> Model Class Initialized
INFO - 2018-02-12 17:39:41 --> Model Class Initialized
INFO - 2018-02-12 17:39:41 --> Model Class Initialized
INFO - 2018-02-12 17:39:41 --> Model Class Initialized
INFO - 2018-02-12 17:39:41 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 17:39:41 --> Final output sent to browser
DEBUG - 2018-02-12 17:39:41 --> Total execution time: 0.1041
INFO - 2018-02-12 12:09:49 --> Config Class Initialized
INFO - 2018-02-12 12:09:49 --> Hooks Class Initialized
DEBUG - 2018-02-12 12:09:49 --> UTF-8 Support Enabled
INFO - 2018-02-12 12:09:49 --> Utf8 Class Initialized
INFO - 2018-02-12 12:09:49 --> URI Class Initialized
INFO - 2018-02-12 12:09:49 --> Router Class Initialized
INFO - 2018-02-12 12:09:49 --> Output Class Initialized
INFO - 2018-02-12 12:09:49 --> Security Class Initialized
DEBUG - 2018-02-12 12:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 12:09:49 --> Input Class Initialized
INFO - 2018-02-12 12:09:49 --> Language Class Initialized
INFO - 2018-02-12 12:09:49 --> Language Class Initialized
INFO - 2018-02-12 12:09:49 --> Config Class Initialized
INFO - 2018-02-12 12:09:49 --> Loader Class Initialized
INFO - 2018-02-12 17:39:49 --> Helper loaded: url_helper
INFO - 2018-02-12 17:39:49 --> Helper loaded: notification_helper
INFO - 2018-02-12 17:39:49 --> Helper loaded: settings_helper
INFO - 2018-02-12 17:39:49 --> Helper loaded: permission_helper
INFO - 2018-02-12 17:39:49 --> Helper loaded: users_helper
INFO - 2018-02-12 17:39:49 --> Database Driver Class Initialized
DEBUG - 2018-02-12 17:39:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 17:39:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 17:39:50 --> Helper loaded: form_helper
INFO - 2018-02-12 17:39:50 --> Form Validation Class Initialized
INFO - 2018-02-12 17:39:50 --> Controller Class Initialized
INFO - 2018-02-12 17:39:50 --> Model Class Initialized
INFO - 2018-02-12 17:39:50 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 17:39:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 17:39:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 17:39:50 --> Model Class Initialized
INFO - 2018-02-12 17:39:50 --> Model Class Initialized
INFO - 2018-02-12 17:39:50 --> Model Class Initialized
INFO - 2018-02-12 17:39:50 --> Model Class Initialized
INFO - 2018-02-12 17:39:50 --> Model Class Initialized
INFO - 2018-02-12 17:39:50 --> Model Class Initialized
INFO - 2018-02-12 17:39:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 17:39:50 --> Model Class Initialized
INFO - 2018-02-12 17:39:50 --> Final output sent to browser
DEBUG - 2018-02-12 17:39:50 --> Total execution time: 0.1123
INFO - 2018-02-12 12:16:29 --> Config Class Initialized
INFO - 2018-02-12 12:16:29 --> Hooks Class Initialized
DEBUG - 2018-02-12 12:16:29 --> UTF-8 Support Enabled
INFO - 2018-02-12 12:16:29 --> Utf8 Class Initialized
INFO - 2018-02-12 12:16:29 --> URI Class Initialized
INFO - 2018-02-12 12:16:29 --> Router Class Initialized
INFO - 2018-02-12 12:16:29 --> Output Class Initialized
INFO - 2018-02-12 12:16:29 --> Security Class Initialized
DEBUG - 2018-02-12 12:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 12:16:30 --> Input Class Initialized
INFO - 2018-02-12 12:16:30 --> Language Class Initialized
INFO - 2018-02-12 12:16:30 --> Language Class Initialized
INFO - 2018-02-12 12:16:30 --> Config Class Initialized
INFO - 2018-02-12 12:16:30 --> Loader Class Initialized
INFO - 2018-02-12 17:46:30 --> Helper loaded: url_helper
INFO - 2018-02-12 17:46:30 --> Helper loaded: notification_helper
INFO - 2018-02-12 17:46:30 --> Helper loaded: settings_helper
INFO - 2018-02-12 17:46:30 --> Helper loaded: permission_helper
INFO - 2018-02-12 17:46:30 --> Helper loaded: users_helper
INFO - 2018-02-12 17:46:30 --> Database Driver Class Initialized
DEBUG - 2018-02-12 17:46:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 17:46:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 17:46:30 --> Helper loaded: form_helper
INFO - 2018-02-12 17:46:30 --> Form Validation Class Initialized
INFO - 2018-02-12 17:46:30 --> Controller Class Initialized
INFO - 2018-02-12 17:46:30 --> Model Class Initialized
INFO - 2018-02-12 17:46:30 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 17:46:30 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 17:46:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 17:46:30 --> Model Class Initialized
INFO - 2018-02-12 17:46:30 --> Model Class Initialized
INFO - 2018-02-12 17:46:30 --> Model Class Initialized
INFO - 2018-02-12 17:46:30 --> Model Class Initialized
INFO - 2018-02-12 17:46:30 --> Model Class Initialized
INFO - 2018-02-12 17:46:30 --> Model Class Initialized
INFO - 2018-02-12 17:46:30 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 17:46:30 --> Model Class Initialized
INFO - 2018-02-12 17:46:30 --> Final output sent to browser
DEBUG - 2018-02-12 17:46:30 --> Total execution time: 0.0824
INFO - 2018-02-12 12:16:30 --> Config Class Initialized
INFO - 2018-02-12 12:16:30 --> Hooks Class Initialized
DEBUG - 2018-02-12 12:16:30 --> UTF-8 Support Enabled
INFO - 2018-02-12 12:16:30 --> Utf8 Class Initialized
INFO - 2018-02-12 12:16:30 --> URI Class Initialized
INFO - 2018-02-12 12:16:30 --> Router Class Initialized
INFO - 2018-02-12 12:16:30 --> Output Class Initialized
INFO - 2018-02-12 12:16:30 --> Security Class Initialized
DEBUG - 2018-02-12 12:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 12:16:30 --> Input Class Initialized
INFO - 2018-02-12 12:16:30 --> Language Class Initialized
INFO - 2018-02-12 12:16:30 --> Language Class Initialized
INFO - 2018-02-12 12:16:30 --> Config Class Initialized
INFO - 2018-02-12 12:16:30 --> Loader Class Initialized
INFO - 2018-02-12 17:46:30 --> Helper loaded: url_helper
INFO - 2018-02-12 17:46:30 --> Helper loaded: notification_helper
INFO - 2018-02-12 17:46:30 --> Helper loaded: settings_helper
INFO - 2018-02-12 17:46:30 --> Helper loaded: permission_helper
INFO - 2018-02-12 17:46:30 --> Helper loaded: users_helper
INFO - 2018-02-12 17:46:30 --> Database Driver Class Initialized
DEBUG - 2018-02-12 17:46:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 17:46:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 17:46:30 --> Helper loaded: form_helper
INFO - 2018-02-12 17:46:30 --> Form Validation Class Initialized
INFO - 2018-02-12 17:46:30 --> Controller Class Initialized
INFO - 2018-02-12 17:46:30 --> Model Class Initialized
INFO - 2018-02-12 17:46:30 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 17:46:30 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 17:46:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 17:46:30 --> Model Class Initialized
INFO - 2018-02-12 17:46:30 --> Model Class Initialized
INFO - 2018-02-12 17:46:30 --> Model Class Initialized
INFO - 2018-02-12 17:46:30 --> Model Class Initialized
INFO - 2018-02-12 17:46:30 --> Model Class Initialized
INFO - 2018-02-12 17:46:30 --> Model Class Initialized
INFO - 2018-02-12 17:46:30 --> Model Class Initialized
INFO - 2018-02-12 17:46:30 --> Model Class Initialized
INFO - 2018-02-12 17:46:30 --> Model Class Initialized
INFO - 2018-02-12 17:46:30 --> Model Class Initialized
INFO - 2018-02-12 17:46:30 --> Model Class Initialized
INFO - 2018-02-12 17:46:30 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 17:46:30 --> Model Class Initialized
INFO - 2018-02-12 17:46:30 --> Final output sent to browser
DEBUG - 2018-02-12 17:46:30 --> Total execution time: 0.0902
INFO - 2018-02-12 12:16:59 --> Config Class Initialized
INFO - 2018-02-12 12:16:59 --> Hooks Class Initialized
DEBUG - 2018-02-12 12:16:59 --> UTF-8 Support Enabled
INFO - 2018-02-12 12:16:59 --> Utf8 Class Initialized
INFO - 2018-02-12 12:16:59 --> Config Class Initialized
INFO - 2018-02-12 12:16:59 --> Hooks Class Initialized
INFO - 2018-02-12 12:16:59 --> URI Class Initialized
DEBUG - 2018-02-12 12:16:59 --> UTF-8 Support Enabled
INFO - 2018-02-12 12:16:59 --> Utf8 Class Initialized
INFO - 2018-02-12 12:16:59 --> Router Class Initialized
INFO - 2018-02-12 12:16:59 --> URI Class Initialized
INFO - 2018-02-12 12:16:59 --> Output Class Initialized
INFO - 2018-02-12 12:16:59 --> Router Class Initialized
INFO - 2018-02-12 12:16:59 --> Security Class Initialized
INFO - 2018-02-12 12:16:59 --> Output Class Initialized
DEBUG - 2018-02-12 12:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 12:16:59 --> Input Class Initialized
INFO - 2018-02-12 12:16:59 --> Language Class Initialized
INFO - 2018-02-12 12:16:59 --> Security Class Initialized
DEBUG - 2018-02-12 12:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 12:16:59 --> Input Class Initialized
INFO - 2018-02-12 12:16:59 --> Language Class Initialized
INFO - 2018-02-12 12:16:59 --> Language Class Initialized
INFO - 2018-02-12 12:16:59 --> Config Class Initialized
INFO - 2018-02-12 12:16:59 --> Loader Class Initialized
INFO - 2018-02-12 17:46:59 --> Helper loaded: url_helper
INFO - 2018-02-12 17:46:59 --> Helper loaded: notification_helper
INFO - 2018-02-12 17:46:59 --> Helper loaded: settings_helper
INFO - 2018-02-12 17:46:59 --> Helper loaded: permission_helper
INFO - 2018-02-12 17:46:59 --> Helper loaded: users_helper
INFO - 2018-02-12 12:16:59 --> Language Class Initialized
INFO - 2018-02-12 12:16:59 --> Config Class Initialized
INFO - 2018-02-12 12:16:59 --> Loader Class Initialized
INFO - 2018-02-12 17:46:59 --> Helper loaded: url_helper
INFO - 2018-02-12 17:46:59 --> Helper loaded: notification_helper
INFO - 2018-02-12 17:46:59 --> Helper loaded: settings_helper
INFO - 2018-02-12 17:46:59 --> Helper loaded: permission_helper
INFO - 2018-02-12 17:46:59 --> Helper loaded: users_helper
INFO - 2018-02-12 17:46:59 --> Database Driver Class Initialized
DEBUG - 2018-02-12 17:46:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 17:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 17:46:59 --> Database Driver Class Initialized
INFO - 2018-02-12 17:46:59 --> Helper loaded: form_helper
INFO - 2018-02-12 17:46:59 --> Form Validation Class Initialized
INFO - 2018-02-12 17:46:59 --> Controller Class Initialized
DEBUG - 2018-02-12 17:46:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 17:46:59 --> Model Class Initialized
INFO - 2018-02-12 17:46:59 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 17:46:59 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 17:46:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 17:46:59 --> Model Class Initialized
INFO - 2018-02-12 17:46:59 --> Model Class Initialized
INFO - 2018-02-12 17:46:59 --> Model Class Initialized
INFO - 2018-02-12 17:46:59 --> Model Class Initialized
INFO - 2018-02-12 17:46:59 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 17:46:59 --> Final output sent to browser
DEBUG - 2018-02-12 17:46:59 --> Total execution time: 0.1026
INFO - 2018-02-12 17:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 17:46:59 --> Helper loaded: form_helper
INFO - 2018-02-12 17:46:59 --> Form Validation Class Initialized
INFO - 2018-02-12 17:46:59 --> Controller Class Initialized
INFO - 2018-02-12 17:46:59 --> Model Class Initialized
INFO - 2018-02-12 17:46:59 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 17:46:59 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 17:46:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 17:46:59 --> Model Class Initialized
INFO - 2018-02-12 17:46:59 --> Model Class Initialized
INFO - 2018-02-12 17:46:59 --> Model Class Initialized
INFO - 2018-02-12 17:46:59 --> Model Class Initialized
INFO - 2018-02-12 17:46:59 --> Model Class Initialized
INFO - 2018-02-12 17:46:59 --> Model Class Initialized
INFO - 2018-02-12 17:46:59 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 17:46:59 --> Final output sent to browser
DEBUG - 2018-02-12 17:46:59 --> Total execution time: 0.1331
INFO - 2018-02-12 12:17:09 --> Config Class Initialized
INFO - 2018-02-12 12:17:09 --> Hooks Class Initialized
DEBUG - 2018-02-12 12:17:09 --> UTF-8 Support Enabled
INFO - 2018-02-12 12:17:09 --> Utf8 Class Initialized
INFO - 2018-02-12 12:17:09 --> URI Class Initialized
INFO - 2018-02-12 12:17:09 --> Router Class Initialized
INFO - 2018-02-12 12:17:09 --> Output Class Initialized
INFO - 2018-02-12 12:17:09 --> Security Class Initialized
DEBUG - 2018-02-12 12:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 12:17:09 --> Input Class Initialized
INFO - 2018-02-12 12:17:09 --> Language Class Initialized
INFO - 2018-02-12 12:17:09 --> Language Class Initialized
INFO - 2018-02-12 12:17:09 --> Config Class Initialized
INFO - 2018-02-12 12:17:09 --> Loader Class Initialized
INFO - 2018-02-12 17:47:09 --> Helper loaded: url_helper
INFO - 2018-02-12 17:47:09 --> Helper loaded: notification_helper
INFO - 2018-02-12 17:47:09 --> Helper loaded: settings_helper
INFO - 2018-02-12 17:47:09 --> Helper loaded: permission_helper
INFO - 2018-02-12 17:47:09 --> Helper loaded: users_helper
INFO - 2018-02-12 17:47:09 --> Database Driver Class Initialized
DEBUG - 2018-02-12 17:47:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 17:47:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 17:47:09 --> Helper loaded: form_helper
INFO - 2018-02-12 17:47:09 --> Form Validation Class Initialized
INFO - 2018-02-12 17:47:09 --> Controller Class Initialized
INFO - 2018-02-12 17:47:09 --> Model Class Initialized
INFO - 2018-02-12 17:47:09 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 17:47:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 17:47:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 17:47:09 --> Model Class Initialized
INFO - 2018-02-12 17:47:09 --> Model Class Initialized
INFO - 2018-02-12 17:47:09 --> Model Class Initialized
INFO - 2018-02-12 17:47:09 --> Model Class Initialized
INFO - 2018-02-12 17:47:09 --> Model Class Initialized
INFO - 2018-02-12 17:47:09 --> Model Class Initialized
INFO - 2018-02-12 17:47:09 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 17:47:09 --> Model Class Initialized
INFO - 2018-02-12 17:47:09 --> Final output sent to browser
DEBUG - 2018-02-12 17:47:09 --> Total execution time: 0.0966
INFO - 2018-02-12 12:18:23 --> Config Class Initialized
INFO - 2018-02-12 12:18:23 --> Hooks Class Initialized
DEBUG - 2018-02-12 12:18:23 --> UTF-8 Support Enabled
INFO - 2018-02-12 12:18:23 --> Utf8 Class Initialized
INFO - 2018-02-12 12:18:23 --> URI Class Initialized
INFO - 2018-02-12 12:18:23 --> Router Class Initialized
INFO - 2018-02-12 12:18:23 --> Output Class Initialized
INFO - 2018-02-12 12:18:23 --> Security Class Initialized
DEBUG - 2018-02-12 12:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 12:18:23 --> Input Class Initialized
INFO - 2018-02-12 12:18:23 --> Language Class Initialized
INFO - 2018-02-12 12:18:23 --> Language Class Initialized
INFO - 2018-02-12 12:18:23 --> Config Class Initialized
INFO - 2018-02-12 12:18:23 --> Loader Class Initialized
INFO - 2018-02-12 17:48:23 --> Helper loaded: url_helper
INFO - 2018-02-12 17:48:23 --> Helper loaded: notification_helper
INFO - 2018-02-12 17:48:23 --> Helper loaded: settings_helper
INFO - 2018-02-12 17:48:23 --> Helper loaded: permission_helper
INFO - 2018-02-12 17:48:23 --> Helper loaded: users_helper
INFO - 2018-02-12 17:48:23 --> Database Driver Class Initialized
DEBUG - 2018-02-12 17:48:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 17:48:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 17:48:23 --> Helper loaded: form_helper
INFO - 2018-02-12 17:48:23 --> Form Validation Class Initialized
INFO - 2018-02-12 17:48:23 --> Controller Class Initialized
INFO - 2018-02-12 17:48:23 --> Model Class Initialized
INFO - 2018-02-12 17:48:23 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 17:48:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 17:48:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 17:48:23 --> Model Class Initialized
INFO - 2018-02-12 17:48:23 --> Model Class Initialized
INFO - 2018-02-12 17:48:23 --> Model Class Initialized
INFO - 2018-02-12 17:48:23 --> Model Class Initialized
INFO - 2018-02-12 17:48:23 --> Model Class Initialized
INFO - 2018-02-12 17:48:23 --> Model Class Initialized
INFO - 2018-02-12 17:48:23 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 17:48:23 --> Final output sent to browser
DEBUG - 2018-02-12 17:48:23 --> Total execution time: 0.1154
INFO - 2018-02-12 12:18:27 --> Config Class Initialized
INFO - 2018-02-12 12:18:27 --> Hooks Class Initialized
DEBUG - 2018-02-12 12:18:27 --> UTF-8 Support Enabled
INFO - 2018-02-12 12:18:27 --> Utf8 Class Initialized
INFO - 2018-02-12 12:18:27 --> URI Class Initialized
INFO - 2018-02-12 12:18:27 --> Router Class Initialized
INFO - 2018-02-12 12:18:27 --> Output Class Initialized
INFO - 2018-02-12 12:18:27 --> Security Class Initialized
DEBUG - 2018-02-12 12:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 12:18:27 --> Input Class Initialized
INFO - 2018-02-12 12:18:27 --> Language Class Initialized
INFO - 2018-02-12 12:18:27 --> Language Class Initialized
INFO - 2018-02-12 12:18:27 --> Config Class Initialized
INFO - 2018-02-12 12:18:27 --> Loader Class Initialized
INFO - 2018-02-12 17:48:27 --> Helper loaded: url_helper
INFO - 2018-02-12 17:48:27 --> Helper loaded: notification_helper
INFO - 2018-02-12 17:48:27 --> Helper loaded: settings_helper
INFO - 2018-02-12 17:48:27 --> Helper loaded: permission_helper
INFO - 2018-02-12 17:48:27 --> Helper loaded: users_helper
INFO - 2018-02-12 17:48:27 --> Database Driver Class Initialized
DEBUG - 2018-02-12 17:48:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 17:48:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 17:48:27 --> Helper loaded: form_helper
INFO - 2018-02-12 17:48:27 --> Form Validation Class Initialized
INFO - 2018-02-12 17:48:27 --> Controller Class Initialized
INFO - 2018-02-12 17:48:27 --> Model Class Initialized
INFO - 2018-02-12 17:48:27 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 17:48:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 17:48:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 17:48:27 --> Model Class Initialized
INFO - 2018-02-12 17:48:27 --> Model Class Initialized
INFO - 2018-02-12 17:48:27 --> Model Class Initialized
INFO - 2018-02-12 17:48:27 --> Model Class Initialized
INFO - 2018-02-12 17:48:27 --> Model Class Initialized
INFO - 2018-02-12 17:48:27 --> Model Class Initialized
INFO - 2018-02-12 17:48:27 --> Model Class Initialized
INFO - 2018-02-12 17:48:27 --> Model Class Initialized
INFO - 2018-02-12 17:48:27 --> Model Class Initialized
INFO - 2018-02-12 17:48:27 --> Model Class Initialized
INFO - 2018-02-12 17:48:27 --> Model Class Initialized
INFO - 2018-02-12 17:48:27 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 17:48:27 --> Model Class Initialized
INFO - 2018-02-12 17:48:27 --> Final output sent to browser
DEBUG - 2018-02-12 17:48:27 --> Total execution time: 0.1273
INFO - 2018-02-12 12:18:28 --> Config Class Initialized
INFO - 2018-02-12 12:18:28 --> Hooks Class Initialized
DEBUG - 2018-02-12 12:18:28 --> UTF-8 Support Enabled
INFO - 2018-02-12 12:18:28 --> Utf8 Class Initialized
INFO - 2018-02-12 12:18:28 --> URI Class Initialized
INFO - 2018-02-12 12:18:28 --> Router Class Initialized
INFO - 2018-02-12 12:18:28 --> Output Class Initialized
INFO - 2018-02-12 12:18:28 --> Security Class Initialized
DEBUG - 2018-02-12 12:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 12:18:28 --> Input Class Initialized
INFO - 2018-02-12 12:18:28 --> Language Class Initialized
INFO - 2018-02-12 12:18:28 --> Language Class Initialized
INFO - 2018-02-12 12:18:28 --> Config Class Initialized
INFO - 2018-02-12 12:18:28 --> Loader Class Initialized
INFO - 2018-02-12 17:48:28 --> Helper loaded: url_helper
INFO - 2018-02-12 17:48:28 --> Helper loaded: notification_helper
INFO - 2018-02-12 17:48:28 --> Helper loaded: settings_helper
INFO - 2018-02-12 17:48:28 --> Helper loaded: permission_helper
INFO - 2018-02-12 17:48:28 --> Helper loaded: users_helper
INFO - 2018-02-12 17:48:28 --> Database Driver Class Initialized
DEBUG - 2018-02-12 17:48:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 17:48:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 17:48:28 --> Helper loaded: form_helper
INFO - 2018-02-12 17:48:28 --> Form Validation Class Initialized
INFO - 2018-02-12 17:48:28 --> Controller Class Initialized
INFO - 2018-02-12 17:48:28 --> Model Class Initialized
INFO - 2018-02-12 17:48:28 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 17:48:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 17:48:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 17:48:28 --> Model Class Initialized
INFO - 2018-02-12 17:48:28 --> Model Class Initialized
INFO - 2018-02-12 17:48:28 --> Model Class Initialized
INFO - 2018-02-12 17:48:28 --> Model Class Initialized
INFO - 2018-02-12 17:48:28 --> Model Class Initialized
INFO - 2018-02-12 17:48:28 --> Model Class Initialized
INFO - 2018-02-12 17:48:28 --> Model Class Initialized
INFO - 2018-02-12 17:48:28 --> Model Class Initialized
INFO - 2018-02-12 17:48:28 --> Model Class Initialized
INFO - 2018-02-12 17:48:28 --> Model Class Initialized
INFO - 2018-02-12 17:48:28 --> Model Class Initialized
INFO - 2018-02-12 17:48:28 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 17:48:28 --> Model Class Initialized
INFO - 2018-02-12 17:48:28 --> Final output sent to browser
DEBUG - 2018-02-12 17:48:28 --> Total execution time: 0.0962
INFO - 2018-02-12 12:18:33 --> Config Class Initialized
INFO - 2018-02-12 12:18:33 --> Hooks Class Initialized
DEBUG - 2018-02-12 12:18:33 --> UTF-8 Support Enabled
INFO - 2018-02-12 12:18:33 --> Utf8 Class Initialized
INFO - 2018-02-12 12:18:33 --> URI Class Initialized
INFO - 2018-02-12 12:18:33 --> Router Class Initialized
INFO - 2018-02-12 12:18:33 --> Output Class Initialized
INFO - 2018-02-12 12:18:33 --> Security Class Initialized
DEBUG - 2018-02-12 12:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 12:18:33 --> Input Class Initialized
INFO - 2018-02-12 12:18:33 --> Language Class Initialized
INFO - 2018-02-12 12:18:33 --> Language Class Initialized
INFO - 2018-02-12 12:18:33 --> Config Class Initialized
INFO - 2018-02-12 12:18:33 --> Loader Class Initialized
INFO - 2018-02-12 17:48:33 --> Helper loaded: url_helper
INFO - 2018-02-12 17:48:33 --> Helper loaded: notification_helper
INFO - 2018-02-12 17:48:33 --> Helper loaded: settings_helper
INFO - 2018-02-12 17:48:33 --> Helper loaded: permission_helper
INFO - 2018-02-12 17:48:33 --> Helper loaded: users_helper
INFO - 2018-02-12 17:48:33 --> Database Driver Class Initialized
DEBUG - 2018-02-12 17:48:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 17:48:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 17:48:33 --> Helper loaded: form_helper
INFO - 2018-02-12 17:48:33 --> Form Validation Class Initialized
INFO - 2018-02-12 17:48:33 --> Controller Class Initialized
INFO - 2018-02-12 17:48:33 --> Model Class Initialized
INFO - 2018-02-12 17:48:33 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 17:48:33 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 17:48:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 17:48:33 --> Model Class Initialized
INFO - 2018-02-12 17:48:33 --> Model Class Initialized
INFO - 2018-02-12 17:48:33 --> Model Class Initialized
INFO - 2018-02-12 17:48:33 --> Model Class Initialized
INFO - 2018-02-12 17:48:33 --> Final output sent to browser
DEBUG - 2018-02-12 17:48:33 --> Total execution time: 0.0863
INFO - 2018-02-12 12:18:34 --> Config Class Initialized
INFO - 2018-02-12 12:18:34 --> Hooks Class Initialized
DEBUG - 2018-02-12 12:18:34 --> UTF-8 Support Enabled
INFO - 2018-02-12 12:18:34 --> Utf8 Class Initialized
INFO - 2018-02-12 12:18:34 --> URI Class Initialized
INFO - 2018-02-12 12:18:34 --> Router Class Initialized
INFO - 2018-02-12 12:18:34 --> Output Class Initialized
INFO - 2018-02-12 12:18:34 --> Security Class Initialized
DEBUG - 2018-02-12 12:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 12:18:34 --> Input Class Initialized
INFO - 2018-02-12 12:18:34 --> Language Class Initialized
INFO - 2018-02-12 12:18:34 --> Language Class Initialized
INFO - 2018-02-12 12:18:34 --> Config Class Initialized
INFO - 2018-02-12 12:18:34 --> Loader Class Initialized
INFO - 2018-02-12 17:48:34 --> Helper loaded: url_helper
INFO - 2018-02-12 17:48:34 --> Helper loaded: notification_helper
INFO - 2018-02-12 17:48:34 --> Helper loaded: settings_helper
INFO - 2018-02-12 17:48:34 --> Helper loaded: permission_helper
INFO - 2018-02-12 17:48:34 --> Helper loaded: users_helper
INFO - 2018-02-12 17:48:34 --> Database Driver Class Initialized
DEBUG - 2018-02-12 17:48:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 17:48:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 17:48:34 --> Helper loaded: form_helper
INFO - 2018-02-12 17:48:34 --> Form Validation Class Initialized
INFO - 2018-02-12 17:48:34 --> Controller Class Initialized
INFO - 2018-02-12 17:48:34 --> Model Class Initialized
INFO - 2018-02-12 17:48:34 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 17:48:34 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 17:48:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 17:48:34 --> Model Class Initialized
INFO - 2018-02-12 17:48:34 --> Model Class Initialized
INFO - 2018-02-12 17:48:34 --> Model Class Initialized
INFO - 2018-02-12 17:48:34 --> Model Class Initialized
INFO - 2018-02-12 17:48:34 --> Final output sent to browser
DEBUG - 2018-02-12 17:48:34 --> Total execution time: 0.0720
INFO - 2018-02-12 12:18:49 --> Config Class Initialized
INFO - 2018-02-12 12:18:49 --> Hooks Class Initialized
DEBUG - 2018-02-12 12:18:49 --> UTF-8 Support Enabled
INFO - 2018-02-12 12:18:49 --> Utf8 Class Initialized
INFO - 2018-02-12 12:18:49 --> URI Class Initialized
INFO - 2018-02-12 12:18:49 --> Router Class Initialized
INFO - 2018-02-12 12:18:49 --> Output Class Initialized
INFO - 2018-02-12 12:18:49 --> Security Class Initialized
DEBUG - 2018-02-12 12:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 12:18:49 --> Input Class Initialized
INFO - 2018-02-12 12:18:49 --> Language Class Initialized
INFO - 2018-02-12 12:18:49 --> Language Class Initialized
INFO - 2018-02-12 12:18:49 --> Config Class Initialized
INFO - 2018-02-12 12:18:49 --> Loader Class Initialized
INFO - 2018-02-12 17:48:49 --> Helper loaded: url_helper
INFO - 2018-02-12 17:48:49 --> Helper loaded: notification_helper
INFO - 2018-02-12 17:48:49 --> Helper loaded: settings_helper
INFO - 2018-02-12 17:48:49 --> Helper loaded: permission_helper
INFO - 2018-02-12 17:48:49 --> Helper loaded: users_helper
INFO - 2018-02-12 17:48:49 --> Database Driver Class Initialized
DEBUG - 2018-02-12 17:48:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 17:48:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 17:48:49 --> Helper loaded: form_helper
INFO - 2018-02-12 17:48:49 --> Form Validation Class Initialized
INFO - 2018-02-12 17:48:49 --> Controller Class Initialized
INFO - 2018-02-12 17:48:49 --> Model Class Initialized
INFO - 2018-02-12 17:48:49 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 17:48:49 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 17:48:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 17:48:49 --> Model Class Initialized
INFO - 2018-02-12 17:48:49 --> Model Class Initialized
INFO - 2018-02-12 17:48:49 --> Model Class Initialized
INFO - 2018-02-12 17:48:49 --> Model Class Initialized
INFO - 2018-02-12 17:48:49 --> Final output sent to browser
DEBUG - 2018-02-12 17:48:49 --> Total execution time: 0.1090
INFO - 2018-02-12 12:18:51 --> Config Class Initialized
INFO - 2018-02-12 12:18:51 --> Hooks Class Initialized
DEBUG - 2018-02-12 12:18:51 --> UTF-8 Support Enabled
INFO - 2018-02-12 12:18:51 --> Utf8 Class Initialized
INFO - 2018-02-12 12:18:51 --> URI Class Initialized
INFO - 2018-02-12 12:18:51 --> Router Class Initialized
INFO - 2018-02-12 12:18:51 --> Output Class Initialized
INFO - 2018-02-12 12:18:51 --> Security Class Initialized
DEBUG - 2018-02-12 12:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 12:18:51 --> Input Class Initialized
INFO - 2018-02-12 12:18:51 --> Language Class Initialized
INFO - 2018-02-12 12:18:52 --> Language Class Initialized
INFO - 2018-02-12 12:18:52 --> Config Class Initialized
INFO - 2018-02-12 12:18:52 --> Loader Class Initialized
INFO - 2018-02-12 17:48:52 --> Helper loaded: url_helper
INFO - 2018-02-12 17:48:52 --> Helper loaded: notification_helper
INFO - 2018-02-12 17:48:52 --> Helper loaded: settings_helper
INFO - 2018-02-12 17:48:52 --> Helper loaded: permission_helper
INFO - 2018-02-12 17:48:52 --> Helper loaded: users_helper
INFO - 2018-02-12 17:48:52 --> Database Driver Class Initialized
DEBUG - 2018-02-12 17:48:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 17:48:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 17:48:52 --> Helper loaded: form_helper
INFO - 2018-02-12 17:48:52 --> Form Validation Class Initialized
INFO - 2018-02-12 17:48:52 --> Controller Class Initialized
INFO - 2018-02-12 17:48:52 --> Model Class Initialized
INFO - 2018-02-12 17:48:52 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 17:48:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 17:48:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 17:48:52 --> Model Class Initialized
INFO - 2018-02-12 17:48:52 --> Model Class Initialized
INFO - 2018-02-12 17:48:52 --> Model Class Initialized
INFO - 2018-02-12 17:48:52 --> Model Class Initialized
INFO - 2018-02-12 17:48:52 --> Model Class Initialized
INFO - 2018-02-12 17:48:52 --> Model Class Initialized
INFO - 2018-02-12 17:48:52 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 17:48:52 --> Final output sent to browser
DEBUG - 2018-02-12 17:48:52 --> Total execution time: 0.2072
INFO - 2018-02-12 12:20:36 --> Config Class Initialized
INFO - 2018-02-12 12:20:36 --> Hooks Class Initialized
DEBUG - 2018-02-12 12:20:36 --> UTF-8 Support Enabled
INFO - 2018-02-12 12:20:36 --> Utf8 Class Initialized
INFO - 2018-02-12 12:20:36 --> URI Class Initialized
INFO - 2018-02-12 12:20:36 --> Router Class Initialized
INFO - 2018-02-12 12:20:36 --> Output Class Initialized
INFO - 2018-02-12 12:20:36 --> Security Class Initialized
DEBUG - 2018-02-12 12:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 12:20:36 --> Input Class Initialized
INFO - 2018-02-12 12:20:36 --> Language Class Initialized
INFO - 2018-02-12 12:20:36 --> Language Class Initialized
INFO - 2018-02-12 12:20:36 --> Config Class Initialized
INFO - 2018-02-12 12:20:36 --> Loader Class Initialized
INFO - 2018-02-12 17:50:36 --> Helper loaded: url_helper
INFO - 2018-02-12 17:50:36 --> Helper loaded: notification_helper
INFO - 2018-02-12 17:50:36 --> Helper loaded: settings_helper
INFO - 2018-02-12 17:50:36 --> Helper loaded: permission_helper
INFO - 2018-02-12 17:50:36 --> Helper loaded: users_helper
INFO - 2018-02-12 17:50:36 --> Database Driver Class Initialized
DEBUG - 2018-02-12 17:50:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 17:50:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 17:50:36 --> Helper loaded: form_helper
INFO - 2018-02-12 17:50:36 --> Form Validation Class Initialized
INFO - 2018-02-12 17:50:36 --> Controller Class Initialized
INFO - 2018-02-12 17:50:36 --> Model Class Initialized
INFO - 2018-02-12 17:50:36 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 17:50:36 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 17:50:36 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 17:50:36 --> Model Class Initialized
INFO - 2018-02-12 17:50:36 --> Model Class Initialized
INFO - 2018-02-12 17:50:36 --> Model Class Initialized
INFO - 2018-02-12 17:50:36 --> Model Class Initialized
INFO - 2018-02-12 17:50:36 --> Model Class Initialized
INFO - 2018-02-12 17:50:36 --> Model Class Initialized
INFO - 2018-02-12 17:50:36 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 17:50:36 --> Final output sent to browser
DEBUG - 2018-02-12 17:50:36 --> Total execution time: 0.0978
INFO - 2018-02-12 12:56:55 --> Config Class Initialized
INFO - 2018-02-12 12:56:55 --> Hooks Class Initialized
DEBUG - 2018-02-12 12:56:55 --> UTF-8 Support Enabled
INFO - 2018-02-12 12:56:55 --> Utf8 Class Initialized
INFO - 2018-02-12 12:56:55 --> URI Class Initialized
INFO - 2018-02-12 12:56:55 --> Router Class Initialized
INFO - 2018-02-12 12:56:55 --> Output Class Initialized
INFO - 2018-02-12 12:56:55 --> Security Class Initialized
DEBUG - 2018-02-12 12:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 12:56:55 --> Input Class Initialized
INFO - 2018-02-12 12:56:55 --> Language Class Initialized
INFO - 2018-02-12 12:56:55 --> Language Class Initialized
INFO - 2018-02-12 12:56:55 --> Config Class Initialized
INFO - 2018-02-12 12:56:55 --> Loader Class Initialized
INFO - 2018-02-12 18:26:55 --> Helper loaded: url_helper
INFO - 2018-02-12 18:26:55 --> Helper loaded: notification_helper
INFO - 2018-02-12 18:26:55 --> Helper loaded: settings_helper
INFO - 2018-02-12 18:26:55 --> Helper loaded: permission_helper
INFO - 2018-02-12 18:26:55 --> Helper loaded: users_helper
INFO - 2018-02-12 18:26:55 --> Database Driver Class Initialized
DEBUG - 2018-02-12 18:26:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 18:26:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 18:26:55 --> Helper loaded: form_helper
INFO - 2018-02-12 18:26:55 --> Form Validation Class Initialized
INFO - 2018-02-12 18:26:55 --> Controller Class Initialized
INFO - 2018-02-12 18:26:55 --> Model Class Initialized
INFO - 2018-02-12 18:26:55 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 18:26:55 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 18:26:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 18:26:55 --> Model Class Initialized
INFO - 2018-02-12 18:26:55 --> Model Class Initialized
INFO - 2018-02-12 18:26:55 --> Model Class Initialized
INFO - 2018-02-12 18:26:55 --> Model Class Initialized
INFO - 2018-02-12 18:26:55 --> Model Class Initialized
INFO - 2018-02-12 18:26:55 --> Model Class Initialized
INFO - 2018-02-12 18:26:55 --> Model Class Initialized
INFO - 2018-02-12 18:26:55 --> Model Class Initialized
INFO - 2018-02-12 18:26:55 --> Model Class Initialized
INFO - 2018-02-12 18:26:55 --> Model Class Initialized
INFO - 2018-02-12 18:26:55 --> Model Class Initialized
INFO - 2018-02-12 18:26:55 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 18:26:55 --> Model Class Initialized
INFO - 2018-02-12 18:26:55 --> Final output sent to browser
DEBUG - 2018-02-12 18:26:55 --> Total execution time: 0.1180
INFO - 2018-02-12 12:56:56 --> Config Class Initialized
INFO - 2018-02-12 12:56:56 --> Hooks Class Initialized
DEBUG - 2018-02-12 12:56:56 --> UTF-8 Support Enabled
INFO - 2018-02-12 12:56:56 --> Utf8 Class Initialized
INFO - 2018-02-12 12:56:56 --> URI Class Initialized
INFO - 2018-02-12 12:56:56 --> Router Class Initialized
INFO - 2018-02-12 12:56:56 --> Output Class Initialized
INFO - 2018-02-12 12:56:56 --> Security Class Initialized
DEBUG - 2018-02-12 12:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 12:56:56 --> Input Class Initialized
INFO - 2018-02-12 12:56:56 --> Language Class Initialized
INFO - 2018-02-12 12:56:56 --> Language Class Initialized
INFO - 2018-02-12 12:56:56 --> Config Class Initialized
INFO - 2018-02-12 12:56:56 --> Loader Class Initialized
INFO - 2018-02-12 18:26:56 --> Helper loaded: url_helper
INFO - 2018-02-12 18:26:56 --> Helper loaded: notification_helper
INFO - 2018-02-12 18:26:56 --> Helper loaded: settings_helper
INFO - 2018-02-12 18:26:56 --> Helper loaded: permission_helper
INFO - 2018-02-12 18:26:56 --> Helper loaded: users_helper
INFO - 2018-02-12 18:26:56 --> Database Driver Class Initialized
DEBUG - 2018-02-12 18:26:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 18:26:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 18:26:56 --> Helper loaded: form_helper
INFO - 2018-02-12 18:26:56 --> Form Validation Class Initialized
INFO - 2018-02-12 18:26:56 --> Controller Class Initialized
INFO - 2018-02-12 18:26:56 --> Model Class Initialized
INFO - 2018-02-12 18:26:56 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 18:26:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 18:26:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 18:26:56 --> Model Class Initialized
INFO - 2018-02-12 18:26:56 --> Model Class Initialized
INFO - 2018-02-12 18:26:56 --> Model Class Initialized
INFO - 2018-02-12 18:26:56 --> Model Class Initialized
INFO - 2018-02-12 18:26:56 --> Model Class Initialized
INFO - 2018-02-12 18:26:56 --> Model Class Initialized
INFO - 2018-02-12 18:26:56 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 18:26:56 --> Model Class Initialized
INFO - 2018-02-12 18:26:56 --> Final output sent to browser
DEBUG - 2018-02-12 18:26:56 --> Total execution time: 0.0816
INFO - 2018-02-12 12:57:07 --> Config Class Initialized
INFO - 2018-02-12 12:57:07 --> Hooks Class Initialized
DEBUG - 2018-02-12 12:57:07 --> UTF-8 Support Enabled
INFO - 2018-02-12 12:57:07 --> Utf8 Class Initialized
INFO - 2018-02-12 12:57:07 --> URI Class Initialized
INFO - 2018-02-12 12:57:07 --> Router Class Initialized
INFO - 2018-02-12 12:57:07 --> Output Class Initialized
INFO - 2018-02-12 12:57:07 --> Security Class Initialized
DEBUG - 2018-02-12 12:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 12:57:07 --> Input Class Initialized
INFO - 2018-02-12 12:57:07 --> Language Class Initialized
INFO - 2018-02-12 12:57:07 --> Config Class Initialized
INFO - 2018-02-12 12:57:07 --> Hooks Class Initialized
DEBUG - 2018-02-12 12:57:07 --> UTF-8 Support Enabled
INFO - 2018-02-12 12:57:07 --> Utf8 Class Initialized
INFO - 2018-02-12 12:57:07 --> URI Class Initialized
INFO - 2018-02-12 12:57:07 --> Language Class Initialized
INFO - 2018-02-12 12:57:07 --> Config Class Initialized
INFO - 2018-02-12 12:57:07 --> Loader Class Initialized
INFO - 2018-02-12 12:57:07 --> Router Class Initialized
INFO - 2018-02-12 18:27:07 --> Helper loaded: url_helper
INFO - 2018-02-12 18:27:07 --> Helper loaded: notification_helper
INFO - 2018-02-12 12:57:07 --> Output Class Initialized
INFO - 2018-02-12 18:27:07 --> Helper loaded: settings_helper
INFO - 2018-02-12 18:27:07 --> Helper loaded: permission_helper
INFO - 2018-02-12 18:27:07 --> Helper loaded: users_helper
INFO - 2018-02-12 12:57:07 --> Security Class Initialized
DEBUG - 2018-02-12 12:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 12:57:07 --> Input Class Initialized
INFO - 2018-02-12 12:57:07 --> Language Class Initialized
INFO - 2018-02-12 18:27:07 --> Database Driver Class Initialized
DEBUG - 2018-02-12 18:27:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 18:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 12:57:07 --> Language Class Initialized
INFO - 2018-02-12 12:57:07 --> Config Class Initialized
INFO - 2018-02-12 12:57:07 --> Loader Class Initialized
INFO - 2018-02-12 18:27:07 --> Helper loaded: form_helper
INFO - 2018-02-12 18:27:07 --> Form Validation Class Initialized
INFO - 2018-02-12 18:27:07 --> Controller Class Initialized
INFO - 2018-02-12 18:27:07 --> Helper loaded: url_helper
INFO - 2018-02-12 18:27:07 --> Helper loaded: notification_helper
INFO - 2018-02-12 18:27:07 --> Helper loaded: settings_helper
INFO - 2018-02-12 18:27:07 --> Helper loaded: permission_helper
INFO - 2018-02-12 18:27:07 --> Helper loaded: users_helper
INFO - 2018-02-12 18:27:07 --> Model Class Initialized
INFO - 2018-02-12 18:27:07 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 18:27:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 18:27:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 18:27:07 --> Model Class Initialized
INFO - 2018-02-12 18:27:07 --> Model Class Initialized
INFO - 2018-02-12 18:27:07 --> Model Class Initialized
INFO - 2018-02-12 18:27:07 --> Model Class Initialized
INFO - 2018-02-12 18:27:07 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 18:27:07 --> Database Driver Class Initialized
INFO - 2018-02-12 18:27:07 --> Final output sent to browser
DEBUG - 2018-02-12 18:27:07 --> Total execution time: 0.0753
DEBUG - 2018-02-12 18:27:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 18:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 18:27:07 --> Helper loaded: form_helper
INFO - 2018-02-12 18:27:07 --> Form Validation Class Initialized
INFO - 2018-02-12 18:27:07 --> Controller Class Initialized
INFO - 2018-02-12 18:27:07 --> Model Class Initialized
INFO - 2018-02-12 18:27:07 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 18:27:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 18:27:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 18:27:07 --> Model Class Initialized
INFO - 2018-02-12 18:27:07 --> Model Class Initialized
INFO - 2018-02-12 18:27:07 --> Model Class Initialized
INFO - 2018-02-12 18:27:07 --> Model Class Initialized
INFO - 2018-02-12 18:27:07 --> Model Class Initialized
INFO - 2018-02-12 18:27:07 --> Model Class Initialized
INFO - 2018-02-12 18:27:07 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 18:27:07 --> Final output sent to browser
DEBUG - 2018-02-12 18:27:07 --> Total execution time: 0.0908
INFO - 2018-02-12 13:10:52 --> Config Class Initialized
INFO - 2018-02-12 13:10:52 --> Hooks Class Initialized
DEBUG - 2018-02-12 13:10:52 --> UTF-8 Support Enabled
INFO - 2018-02-12 13:10:52 --> Utf8 Class Initialized
INFO - 2018-02-12 13:10:52 --> URI Class Initialized
INFO - 2018-02-12 13:10:52 --> Router Class Initialized
INFO - 2018-02-12 13:10:52 --> Output Class Initialized
INFO - 2018-02-12 13:10:52 --> Security Class Initialized
DEBUG - 2018-02-12 13:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 13:10:52 --> Input Class Initialized
INFO - 2018-02-12 13:10:52 --> Language Class Initialized
INFO - 2018-02-12 13:10:52 --> Language Class Initialized
INFO - 2018-02-12 13:10:52 --> Config Class Initialized
INFO - 2018-02-12 13:10:52 --> Loader Class Initialized
INFO - 2018-02-12 18:40:52 --> Helper loaded: url_helper
INFO - 2018-02-12 18:40:52 --> Helper loaded: notification_helper
INFO - 2018-02-12 18:40:52 --> Helper loaded: settings_helper
INFO - 2018-02-12 18:40:52 --> Helper loaded: permission_helper
INFO - 2018-02-12 18:40:52 --> Helper loaded: users_helper
INFO - 2018-02-12 18:40:52 --> Database Driver Class Initialized
DEBUG - 2018-02-12 18:40:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 18:40:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 18:40:52 --> Helper loaded: form_helper
INFO - 2018-02-12 18:40:52 --> Form Validation Class Initialized
INFO - 2018-02-12 18:40:52 --> Controller Class Initialized
INFO - 2018-02-12 18:40:53 --> Model Class Initialized
INFO - 2018-02-12 18:40:53 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 18:40:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 18:40:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 18:40:53 --> Model Class Initialized
INFO - 2018-02-12 18:40:53 --> Model Class Initialized
INFO - 2018-02-12 18:40:53 --> Model Class Initialized
INFO - 2018-02-12 18:40:53 --> Model Class Initialized
INFO - 2018-02-12 18:40:53 --> Model Class Initialized
INFO - 2018-02-12 18:40:53 --> Model Class Initialized
INFO - 2018-02-12 18:40:53 --> Model Class Initialized
INFO - 2018-02-12 18:40:53 --> Model Class Initialized
INFO - 2018-02-12 18:40:53 --> Model Class Initialized
INFO - 2018-02-12 18:40:53 --> Model Class Initialized
INFO - 2018-02-12 18:40:53 --> Model Class Initialized
INFO - 2018-02-12 18:40:53 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 18:40:53 --> Model Class Initialized
INFO - 2018-02-12 18:40:53 --> Final output sent to browser
DEBUG - 2018-02-12 18:40:53 --> Total execution time: 0.1094
INFO - 2018-02-12 13:10:54 --> Config Class Initialized
INFO - 2018-02-12 13:10:54 --> Hooks Class Initialized
DEBUG - 2018-02-12 13:10:54 --> UTF-8 Support Enabled
INFO - 2018-02-12 13:10:54 --> Utf8 Class Initialized
INFO - 2018-02-12 13:10:54 --> URI Class Initialized
INFO - 2018-02-12 13:10:54 --> Router Class Initialized
INFO - 2018-02-12 13:10:54 --> Output Class Initialized
INFO - 2018-02-12 13:10:54 --> Security Class Initialized
DEBUG - 2018-02-12 13:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 13:10:54 --> Input Class Initialized
INFO - 2018-02-12 13:10:54 --> Language Class Initialized
INFO - 2018-02-12 13:10:54 --> Language Class Initialized
INFO - 2018-02-12 13:10:54 --> Config Class Initialized
INFO - 2018-02-12 13:10:54 --> Loader Class Initialized
INFO - 2018-02-12 18:40:54 --> Helper loaded: url_helper
INFO - 2018-02-12 18:40:54 --> Helper loaded: notification_helper
INFO - 2018-02-12 18:40:54 --> Helper loaded: settings_helper
INFO - 2018-02-12 18:40:54 --> Helper loaded: permission_helper
INFO - 2018-02-12 18:40:54 --> Helper loaded: users_helper
INFO - 2018-02-12 18:40:54 --> Database Driver Class Initialized
DEBUG - 2018-02-12 18:40:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 18:40:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 18:40:54 --> Helper loaded: form_helper
INFO - 2018-02-12 18:40:54 --> Form Validation Class Initialized
INFO - 2018-02-12 18:40:54 --> Controller Class Initialized
INFO - 2018-02-12 18:40:54 --> Model Class Initialized
INFO - 2018-02-12 18:40:54 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 18:40:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 18:40:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 18:40:54 --> Model Class Initialized
INFO - 2018-02-12 18:40:54 --> Model Class Initialized
INFO - 2018-02-12 18:40:54 --> Model Class Initialized
INFO - 2018-02-12 18:40:54 --> Model Class Initialized
INFO - 2018-02-12 18:40:54 --> Model Class Initialized
INFO - 2018-02-12 18:40:54 --> Model Class Initialized
INFO - 2018-02-12 18:40:54 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 18:40:54 --> Model Class Initialized
INFO - 2018-02-12 18:40:54 --> Final output sent to browser
DEBUG - 2018-02-12 18:40:54 --> Total execution time: 0.1038
INFO - 2018-02-12 13:11:02 --> Config Class Initialized
INFO - 2018-02-12 13:11:02 --> Hooks Class Initialized
DEBUG - 2018-02-12 13:11:02 --> UTF-8 Support Enabled
INFO - 2018-02-12 13:11:02 --> Utf8 Class Initialized
INFO - 2018-02-12 13:11:02 --> URI Class Initialized
INFO - 2018-02-12 13:11:02 --> Router Class Initialized
INFO - 2018-02-12 13:11:02 --> Output Class Initialized
INFO - 2018-02-12 13:11:02 --> Security Class Initialized
INFO - 2018-02-12 13:11:02 --> Config Class Initialized
INFO - 2018-02-12 13:11:02 --> Hooks Class Initialized
DEBUG - 2018-02-12 13:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 13:11:02 --> Input Class Initialized
INFO - 2018-02-12 13:11:02 --> Language Class Initialized
DEBUG - 2018-02-12 13:11:02 --> UTF-8 Support Enabled
INFO - 2018-02-12 13:11:02 --> Utf8 Class Initialized
INFO - 2018-02-12 13:11:02 --> URI Class Initialized
INFO - 2018-02-12 13:11:02 --> Router Class Initialized
INFO - 2018-02-12 13:11:02 --> Output Class Initialized
INFO - 2018-02-12 13:11:02 --> Language Class Initialized
INFO - 2018-02-12 13:11:02 --> Config Class Initialized
INFO - 2018-02-12 13:11:02 --> Loader Class Initialized
INFO - 2018-02-12 13:11:02 --> Security Class Initialized
INFO - 2018-02-12 18:41:02 --> Helper loaded: url_helper
INFO - 2018-02-12 18:41:02 --> Helper loaded: notification_helper
INFO - 2018-02-12 18:41:02 --> Helper loaded: settings_helper
INFO - 2018-02-12 18:41:02 --> Helper loaded: permission_helper
DEBUG - 2018-02-12 13:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 13:11:02 --> Input Class Initialized
INFO - 2018-02-12 18:41:02 --> Helper loaded: users_helper
INFO - 2018-02-12 13:11:02 --> Language Class Initialized
INFO - 2018-02-12 18:41:02 --> Database Driver Class Initialized
DEBUG - 2018-02-12 18:41:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 18:41:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 13:11:02 --> Language Class Initialized
INFO - 2018-02-12 13:11:02 --> Config Class Initialized
INFO - 2018-02-12 13:11:02 --> Loader Class Initialized
INFO - 2018-02-12 18:41:02 --> Helper loaded: form_helper
INFO - 2018-02-12 18:41:02 --> Form Validation Class Initialized
INFO - 2018-02-12 18:41:02 --> Controller Class Initialized
INFO - 2018-02-12 18:41:02 --> Helper loaded: url_helper
INFO - 2018-02-12 18:41:02 --> Helper loaded: notification_helper
INFO - 2018-02-12 18:41:02 --> Helper loaded: settings_helper
INFO - 2018-02-12 18:41:02 --> Helper loaded: permission_helper
INFO - 2018-02-12 18:41:02 --> Helper loaded: users_helper
INFO - 2018-02-12 18:41:02 --> Model Class Initialized
INFO - 2018-02-12 18:41:02 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 18:41:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 18:41:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 18:41:02 --> Model Class Initialized
INFO - 2018-02-12 18:41:02 --> Model Class Initialized
INFO - 2018-02-12 18:41:02 --> Model Class Initialized
INFO - 2018-02-12 18:41:02 --> Model Class Initialized
INFO - 2018-02-12 18:41:02 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 18:41:02 --> Database Driver Class Initialized
INFO - 2018-02-12 18:41:02 --> Final output sent to browser
DEBUG - 2018-02-12 18:41:02 --> Total execution time: 0.0822
DEBUG - 2018-02-12 18:41:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 18:41:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 18:41:02 --> Helper loaded: form_helper
INFO - 2018-02-12 18:41:02 --> Form Validation Class Initialized
INFO - 2018-02-12 18:41:02 --> Controller Class Initialized
INFO - 2018-02-12 18:41:02 --> Model Class Initialized
INFO - 2018-02-12 18:41:02 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 18:41:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 18:41:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 18:41:02 --> Model Class Initialized
INFO - 2018-02-12 18:41:02 --> Model Class Initialized
INFO - 2018-02-12 18:41:02 --> Model Class Initialized
INFO - 2018-02-12 18:41:02 --> Model Class Initialized
INFO - 2018-02-12 18:41:02 --> Model Class Initialized
INFO - 2018-02-12 18:41:02 --> Model Class Initialized
INFO - 2018-02-12 18:41:02 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 18:41:02 --> Final output sent to browser
DEBUG - 2018-02-12 18:41:02 --> Total execution time: 0.1060
INFO - 2018-02-12 13:11:54 --> Config Class Initialized
INFO - 2018-02-12 13:11:54 --> Hooks Class Initialized
DEBUG - 2018-02-12 13:11:54 --> UTF-8 Support Enabled
INFO - 2018-02-12 13:11:54 --> Utf8 Class Initialized
INFO - 2018-02-12 13:11:54 --> URI Class Initialized
INFO - 2018-02-12 13:11:54 --> Router Class Initialized
INFO - 2018-02-12 13:11:54 --> Output Class Initialized
INFO - 2018-02-12 13:11:54 --> Security Class Initialized
DEBUG - 2018-02-12 13:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 13:11:54 --> Input Class Initialized
INFO - 2018-02-12 13:11:54 --> Language Class Initialized
INFO - 2018-02-12 13:11:54 --> Language Class Initialized
INFO - 2018-02-12 13:11:54 --> Config Class Initialized
INFO - 2018-02-12 13:11:54 --> Loader Class Initialized
INFO - 2018-02-12 18:41:54 --> Helper loaded: url_helper
INFO - 2018-02-12 18:41:54 --> Helper loaded: notification_helper
INFO - 2018-02-12 18:41:54 --> Helper loaded: settings_helper
INFO - 2018-02-12 18:41:54 --> Helper loaded: permission_helper
INFO - 2018-02-12 18:41:54 --> Helper loaded: users_helper
INFO - 2018-02-12 18:41:54 --> Database Driver Class Initialized
DEBUG - 2018-02-12 18:41:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 18:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 18:41:54 --> Helper loaded: form_helper
INFO - 2018-02-12 18:41:54 --> Form Validation Class Initialized
INFO - 2018-02-12 18:41:54 --> Controller Class Initialized
INFO - 2018-02-12 18:41:54 --> Model Class Initialized
INFO - 2018-02-12 18:41:54 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 18:41:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 18:41:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 18:41:54 --> Model Class Initialized
INFO - 2018-02-12 18:41:54 --> Model Class Initialized
INFO - 2018-02-12 18:41:54 --> Model Class Initialized
INFO - 2018-02-12 18:41:54 --> Model Class Initialized
INFO - 2018-02-12 18:41:54 --> Model Class Initialized
INFO - 2018-02-12 18:41:54 --> Model Class Initialized
INFO - 2018-02-12 18:41:54 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 18:41:54 --> Final output sent to browser
DEBUG - 2018-02-12 18:41:54 --> Total execution time: 0.1141
INFO - 2018-02-12 13:12:07 --> Config Class Initialized
INFO - 2018-02-12 13:12:07 --> Hooks Class Initialized
DEBUG - 2018-02-12 13:12:07 --> UTF-8 Support Enabled
INFO - 2018-02-12 13:12:07 --> Utf8 Class Initialized
INFO - 2018-02-12 13:12:07 --> URI Class Initialized
INFO - 2018-02-12 13:12:07 --> Router Class Initialized
INFO - 2018-02-12 13:12:07 --> Output Class Initialized
INFO - 2018-02-12 13:12:07 --> Security Class Initialized
DEBUG - 2018-02-12 13:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 13:12:07 --> Input Class Initialized
INFO - 2018-02-12 13:12:07 --> Language Class Initialized
INFO - 2018-02-12 13:12:07 --> Language Class Initialized
INFO - 2018-02-12 13:12:07 --> Config Class Initialized
INFO - 2018-02-12 13:12:07 --> Loader Class Initialized
INFO - 2018-02-12 18:42:07 --> Helper loaded: url_helper
INFO - 2018-02-12 18:42:07 --> Helper loaded: notification_helper
INFO - 2018-02-12 18:42:07 --> Helper loaded: settings_helper
INFO - 2018-02-12 18:42:07 --> Helper loaded: permission_helper
INFO - 2018-02-12 18:42:07 --> Helper loaded: users_helper
INFO - 2018-02-12 18:42:07 --> Database Driver Class Initialized
DEBUG - 2018-02-12 18:42:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 18:42:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 18:42:07 --> Helper loaded: form_helper
INFO - 2018-02-12 18:42:07 --> Form Validation Class Initialized
INFO - 2018-02-12 18:42:07 --> Controller Class Initialized
INFO - 2018-02-12 18:42:07 --> Model Class Initialized
INFO - 2018-02-12 18:42:07 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 18:42:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 18:42:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 18:42:07 --> Model Class Initialized
INFO - 2018-02-12 18:42:07 --> Model Class Initialized
INFO - 2018-02-12 18:42:07 --> Model Class Initialized
INFO - 2018-02-12 18:42:07 --> Model Class Initialized
INFO - 2018-02-12 18:42:07 --> Model Class Initialized
INFO - 2018-02-12 18:42:07 --> Model Class Initialized
INFO - 2018-02-12 18:42:07 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 18:42:07 --> Final output sent to browser
DEBUG - 2018-02-12 18:42:07 --> Total execution time: 0.1204
INFO - 2018-02-12 13:12:09 --> Config Class Initialized
INFO - 2018-02-12 13:12:09 --> Hooks Class Initialized
DEBUG - 2018-02-12 13:12:09 --> UTF-8 Support Enabled
INFO - 2018-02-12 13:12:09 --> Utf8 Class Initialized
INFO - 2018-02-12 13:12:09 --> URI Class Initialized
INFO - 2018-02-12 13:12:09 --> Router Class Initialized
INFO - 2018-02-12 13:12:09 --> Output Class Initialized
INFO - 2018-02-12 13:12:09 --> Security Class Initialized
DEBUG - 2018-02-12 13:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 13:12:09 --> Input Class Initialized
INFO - 2018-02-12 13:12:09 --> Language Class Initialized
INFO - 2018-02-12 13:12:09 --> Language Class Initialized
INFO - 2018-02-12 13:12:09 --> Config Class Initialized
INFO - 2018-02-12 13:12:09 --> Loader Class Initialized
INFO - 2018-02-12 18:42:09 --> Helper loaded: url_helper
INFO - 2018-02-12 18:42:09 --> Helper loaded: notification_helper
INFO - 2018-02-12 18:42:09 --> Helper loaded: settings_helper
INFO - 2018-02-12 18:42:09 --> Helper loaded: permission_helper
INFO - 2018-02-12 18:42:09 --> Helper loaded: users_helper
INFO - 2018-02-12 18:42:09 --> Database Driver Class Initialized
DEBUG - 2018-02-12 18:42:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 18:42:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 18:42:09 --> Helper loaded: form_helper
INFO - 2018-02-12 18:42:09 --> Form Validation Class Initialized
INFO - 2018-02-12 18:42:09 --> Controller Class Initialized
INFO - 2018-02-12 18:42:09 --> Model Class Initialized
INFO - 2018-02-12 18:42:09 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 18:42:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 18:42:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 18:42:09 --> Model Class Initialized
INFO - 2018-02-12 18:42:09 --> Model Class Initialized
INFO - 2018-02-12 18:42:09 --> Model Class Initialized
INFO - 2018-02-12 18:42:09 --> Model Class Initialized
INFO - 2018-02-12 18:42:09 --> Model Class Initialized
INFO - 2018-02-12 18:42:09 --> Model Class Initialized
INFO - 2018-02-12 18:42:09 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 18:42:09 --> Final output sent to browser
DEBUG - 2018-02-12 18:42:09 --> Total execution time: 0.0867
INFO - 2018-02-12 13:12:11 --> Config Class Initialized
INFO - 2018-02-12 13:12:11 --> Hooks Class Initialized
DEBUG - 2018-02-12 13:12:11 --> UTF-8 Support Enabled
INFO - 2018-02-12 13:12:11 --> Utf8 Class Initialized
INFO - 2018-02-12 13:12:11 --> URI Class Initialized
INFO - 2018-02-12 13:12:11 --> Router Class Initialized
INFO - 2018-02-12 13:12:11 --> Output Class Initialized
INFO - 2018-02-12 13:12:11 --> Security Class Initialized
DEBUG - 2018-02-12 13:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 13:12:11 --> Input Class Initialized
INFO - 2018-02-12 13:12:11 --> Language Class Initialized
INFO - 2018-02-12 13:12:11 --> Language Class Initialized
INFO - 2018-02-12 13:12:11 --> Config Class Initialized
INFO - 2018-02-12 13:12:11 --> Loader Class Initialized
INFO - 2018-02-12 18:42:11 --> Helper loaded: url_helper
INFO - 2018-02-12 18:42:11 --> Helper loaded: notification_helper
INFO - 2018-02-12 18:42:11 --> Helper loaded: settings_helper
INFO - 2018-02-12 18:42:11 --> Helper loaded: permission_helper
INFO - 2018-02-12 18:42:11 --> Helper loaded: users_helper
INFO - 2018-02-12 18:42:11 --> Database Driver Class Initialized
DEBUG - 2018-02-12 18:42:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 18:42:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 18:42:11 --> Helper loaded: form_helper
INFO - 2018-02-12 18:42:11 --> Form Validation Class Initialized
INFO - 2018-02-12 18:42:11 --> Controller Class Initialized
INFO - 2018-02-12 18:42:11 --> Model Class Initialized
INFO - 2018-02-12 18:42:11 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 18:42:11 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 18:42:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 18:42:11 --> Model Class Initialized
INFO - 2018-02-12 18:42:11 --> Model Class Initialized
INFO - 2018-02-12 18:42:11 --> Model Class Initialized
INFO - 2018-02-12 18:42:11 --> Model Class Initialized
INFO - 2018-02-12 18:42:11 --> Model Class Initialized
INFO - 2018-02-12 18:42:11 --> Model Class Initialized
INFO - 2018-02-12 18:42:11 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 18:42:11 --> Final output sent to browser
DEBUG - 2018-02-12 18:42:11 --> Total execution time: 0.0948
INFO - 2018-02-12 13:12:13 --> Config Class Initialized
INFO - 2018-02-12 13:12:13 --> Hooks Class Initialized
DEBUG - 2018-02-12 13:12:13 --> UTF-8 Support Enabled
INFO - 2018-02-12 13:12:13 --> Utf8 Class Initialized
INFO - 2018-02-12 13:12:13 --> URI Class Initialized
INFO - 2018-02-12 13:12:13 --> Router Class Initialized
INFO - 2018-02-12 13:12:13 --> Output Class Initialized
INFO - 2018-02-12 13:12:13 --> Security Class Initialized
DEBUG - 2018-02-12 13:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 13:12:13 --> Input Class Initialized
INFO - 2018-02-12 13:12:13 --> Language Class Initialized
INFO - 2018-02-12 13:12:13 --> Language Class Initialized
INFO - 2018-02-12 13:12:13 --> Config Class Initialized
INFO - 2018-02-12 13:12:13 --> Loader Class Initialized
INFO - 2018-02-12 18:42:13 --> Helper loaded: url_helper
INFO - 2018-02-12 18:42:13 --> Helper loaded: notification_helper
INFO - 2018-02-12 18:42:13 --> Helper loaded: settings_helper
INFO - 2018-02-12 18:42:13 --> Helper loaded: permission_helper
INFO - 2018-02-12 18:42:13 --> Helper loaded: users_helper
INFO - 2018-02-12 18:42:13 --> Database Driver Class Initialized
DEBUG - 2018-02-12 18:42:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 18:42:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 18:42:13 --> Helper loaded: form_helper
INFO - 2018-02-12 18:42:13 --> Form Validation Class Initialized
INFO - 2018-02-12 18:42:13 --> Controller Class Initialized
INFO - 2018-02-12 18:42:13 --> Model Class Initialized
INFO - 2018-02-12 18:42:13 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 18:42:13 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 18:42:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 18:42:13 --> Model Class Initialized
INFO - 2018-02-12 18:42:13 --> Model Class Initialized
INFO - 2018-02-12 18:42:13 --> Model Class Initialized
INFO - 2018-02-12 18:42:13 --> Model Class Initialized
INFO - 2018-02-12 18:42:13 --> Model Class Initialized
INFO - 2018-02-12 18:42:13 --> Model Class Initialized
INFO - 2018-02-12 18:42:13 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 18:42:13 --> Final output sent to browser
DEBUG - 2018-02-12 18:42:13 --> Total execution time: 0.1093
INFO - 2018-02-12 13:21:33 --> Config Class Initialized
INFO - 2018-02-12 13:21:33 --> Hooks Class Initialized
DEBUG - 2018-02-12 13:21:33 --> UTF-8 Support Enabled
INFO - 2018-02-12 13:21:33 --> Utf8 Class Initialized
INFO - 2018-02-12 13:21:33 --> URI Class Initialized
INFO - 2018-02-12 13:21:33 --> Router Class Initialized
INFO - 2018-02-12 13:21:33 --> Output Class Initialized
INFO - 2018-02-12 13:21:33 --> Security Class Initialized
DEBUG - 2018-02-12 13:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 13:21:33 --> Input Class Initialized
INFO - 2018-02-12 13:21:33 --> Language Class Initialized
INFO - 2018-02-12 13:21:33 --> Language Class Initialized
INFO - 2018-02-12 13:21:33 --> Config Class Initialized
INFO - 2018-02-12 13:21:33 --> Loader Class Initialized
INFO - 2018-02-12 18:51:33 --> Helper loaded: url_helper
INFO - 2018-02-12 18:51:33 --> Helper loaded: notification_helper
INFO - 2018-02-12 18:51:33 --> Helper loaded: settings_helper
INFO - 2018-02-12 18:51:33 --> Helper loaded: permission_helper
INFO - 2018-02-12 18:51:33 --> Helper loaded: users_helper
INFO - 2018-02-12 18:51:33 --> Database Driver Class Initialized
DEBUG - 2018-02-12 18:51:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 18:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 18:51:33 --> Helper loaded: form_helper
INFO - 2018-02-12 18:51:33 --> Form Validation Class Initialized
INFO - 2018-02-12 18:51:33 --> Controller Class Initialized
INFO - 2018-02-12 18:51:33 --> Model Class Initialized
INFO - 2018-02-12 18:51:33 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 18:51:33 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 18:51:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 18:51:33 --> Model Class Initialized
INFO - 2018-02-12 18:51:33 --> Model Class Initialized
INFO - 2018-02-12 18:51:33 --> Model Class Initialized
INFO - 2018-02-12 18:51:33 --> Model Class Initialized
INFO - 2018-02-12 18:51:33 --> Model Class Initialized
INFO - 2018-02-12 18:51:33 --> Model Class Initialized
INFO - 2018-02-12 18:51:33 --> Model Class Initialized
INFO - 2018-02-12 18:51:33 --> Model Class Initialized
INFO - 2018-02-12 18:51:33 --> Model Class Initialized
INFO - 2018-02-12 18:51:33 --> Model Class Initialized
INFO - 2018-02-12 18:51:33 --> Model Class Initialized
INFO - 2018-02-12 18:51:33 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 18:51:33 --> Model Class Initialized
INFO - 2018-02-12 18:51:33 --> Final output sent to browser
DEBUG - 2018-02-12 18:51:33 --> Total execution time: 0.0926
INFO - 2018-02-12 13:21:34 --> Config Class Initialized
INFO - 2018-02-12 13:21:34 --> Hooks Class Initialized
DEBUG - 2018-02-12 13:21:34 --> UTF-8 Support Enabled
INFO - 2018-02-12 13:21:34 --> Utf8 Class Initialized
INFO - 2018-02-12 13:21:34 --> URI Class Initialized
INFO - 2018-02-12 13:21:34 --> Router Class Initialized
INFO - 2018-02-12 13:21:34 --> Output Class Initialized
INFO - 2018-02-12 13:21:34 --> Security Class Initialized
DEBUG - 2018-02-12 13:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 13:21:34 --> Input Class Initialized
INFO - 2018-02-12 13:21:34 --> Language Class Initialized
INFO - 2018-02-12 13:21:34 --> Language Class Initialized
INFO - 2018-02-12 13:21:34 --> Config Class Initialized
INFO - 2018-02-12 13:21:34 --> Loader Class Initialized
INFO - 2018-02-12 18:51:34 --> Helper loaded: url_helper
INFO - 2018-02-12 18:51:34 --> Helper loaded: notification_helper
INFO - 2018-02-12 18:51:34 --> Helper loaded: settings_helper
INFO - 2018-02-12 18:51:34 --> Helper loaded: permission_helper
INFO - 2018-02-12 18:51:34 --> Helper loaded: users_helper
INFO - 2018-02-12 18:51:34 --> Database Driver Class Initialized
DEBUG - 2018-02-12 18:51:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 18:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 18:51:34 --> Helper loaded: form_helper
INFO - 2018-02-12 18:51:34 --> Form Validation Class Initialized
INFO - 2018-02-12 18:51:34 --> Controller Class Initialized
INFO - 2018-02-12 18:51:34 --> Model Class Initialized
INFO - 2018-02-12 18:51:34 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 18:51:34 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 18:51:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 18:51:34 --> Model Class Initialized
INFO - 2018-02-12 18:51:34 --> Model Class Initialized
INFO - 2018-02-12 18:51:34 --> Model Class Initialized
INFO - 2018-02-12 18:51:34 --> Model Class Initialized
INFO - 2018-02-12 18:51:34 --> Model Class Initialized
INFO - 2018-02-12 18:51:34 --> Model Class Initialized
INFO - 2018-02-12 18:51:34 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 18:51:34 --> Model Class Initialized
INFO - 2018-02-12 18:51:34 --> Final output sent to browser
DEBUG - 2018-02-12 18:51:34 --> Total execution time: 0.1063
INFO - 2018-02-12 13:22:51 --> Config Class Initialized
INFO - 2018-02-12 13:22:51 --> Hooks Class Initialized
INFO - 2018-02-12 13:22:51 --> Config Class Initialized
INFO - 2018-02-12 13:22:51 --> Hooks Class Initialized
DEBUG - 2018-02-12 13:22:51 --> UTF-8 Support Enabled
INFO - 2018-02-12 13:22:51 --> Utf8 Class Initialized
DEBUG - 2018-02-12 13:22:51 --> UTF-8 Support Enabled
INFO - 2018-02-12 13:22:51 --> URI Class Initialized
INFO - 2018-02-12 13:22:51 --> Utf8 Class Initialized
INFO - 2018-02-12 13:22:51 --> URI Class Initialized
INFO - 2018-02-12 13:22:51 --> Router Class Initialized
INFO - 2018-02-12 13:22:51 --> Router Class Initialized
INFO - 2018-02-12 13:22:51 --> Output Class Initialized
INFO - 2018-02-12 13:22:51 --> Output Class Initialized
INFO - 2018-02-12 13:22:51 --> Security Class Initialized
INFO - 2018-02-12 13:22:51 --> Security Class Initialized
DEBUG - 2018-02-12 13:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 13:22:51 --> Input Class Initialized
DEBUG - 2018-02-12 13:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 13:22:51 --> Input Class Initialized
INFO - 2018-02-12 13:22:51 --> Language Class Initialized
INFO - 2018-02-12 13:22:52 --> Language Class Initialized
INFO - 2018-02-12 13:22:52 --> Language Class Initialized
INFO - 2018-02-12 13:22:52 --> Config Class Initialized
INFO - 2018-02-12 13:22:52 --> Loader Class Initialized
INFO - 2018-02-12 18:52:52 --> Helper loaded: url_helper
INFO - 2018-02-12 18:52:52 --> Helper loaded: notification_helper
INFO - 2018-02-12 18:52:52 --> Helper loaded: settings_helper
INFO - 2018-02-12 18:52:52 --> Helper loaded: permission_helper
INFO - 2018-02-12 18:52:52 --> Helper loaded: users_helper
INFO - 2018-02-12 13:22:52 --> Language Class Initialized
INFO - 2018-02-12 13:22:52 --> Config Class Initialized
INFO - 2018-02-12 13:22:52 --> Loader Class Initialized
INFO - 2018-02-12 18:52:52 --> Helper loaded: url_helper
INFO - 2018-02-12 18:52:52 --> Helper loaded: notification_helper
INFO - 2018-02-12 18:52:52 --> Helper loaded: settings_helper
INFO - 2018-02-12 18:52:52 --> Helper loaded: permission_helper
INFO - 2018-02-12 18:52:52 --> Helper loaded: users_helper
INFO - 2018-02-12 18:52:52 --> Database Driver Class Initialized
DEBUG - 2018-02-12 18:52:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 18:52:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 18:52:52 --> Database Driver Class Initialized
INFO - 2018-02-12 18:52:52 --> Helper loaded: form_helper
INFO - 2018-02-12 18:52:52 --> Form Validation Class Initialized
INFO - 2018-02-12 18:52:52 --> Controller Class Initialized
DEBUG - 2018-02-12 18:52:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 18:52:52 --> Model Class Initialized
INFO - 2018-02-12 18:52:52 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 18:52:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 18:52:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 18:52:52 --> Model Class Initialized
INFO - 2018-02-12 18:52:52 --> Model Class Initialized
INFO - 2018-02-12 18:52:52 --> Model Class Initialized
INFO - 2018-02-12 18:52:52 --> Model Class Initialized
INFO - 2018-02-12 18:52:52 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 18:52:52 --> Final output sent to browser
DEBUG - 2018-02-12 18:52:52 --> Total execution time: 0.0981
INFO - 2018-02-12 18:52:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 18:52:52 --> Helper loaded: form_helper
INFO - 2018-02-12 18:52:52 --> Form Validation Class Initialized
INFO - 2018-02-12 18:52:52 --> Controller Class Initialized
INFO - 2018-02-12 18:52:52 --> Model Class Initialized
INFO - 2018-02-12 18:52:52 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 18:52:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 18:52:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 18:52:52 --> Model Class Initialized
INFO - 2018-02-12 18:52:52 --> Model Class Initialized
INFO - 2018-02-12 18:52:52 --> Model Class Initialized
INFO - 2018-02-12 18:52:52 --> Model Class Initialized
INFO - 2018-02-12 18:52:52 --> Model Class Initialized
INFO - 2018-02-12 18:52:52 --> Model Class Initialized
INFO - 2018-02-12 18:52:52 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 18:52:52 --> Final output sent to browser
DEBUG - 2018-02-12 18:52:52 --> Total execution time: 0.1362
INFO - 2018-02-12 13:22:56 --> Config Class Initialized
INFO - 2018-02-12 13:22:56 --> Hooks Class Initialized
DEBUG - 2018-02-12 13:22:56 --> UTF-8 Support Enabled
INFO - 2018-02-12 13:22:56 --> Utf8 Class Initialized
INFO - 2018-02-12 13:22:56 --> URI Class Initialized
INFO - 2018-02-12 13:22:56 --> Router Class Initialized
INFO - 2018-02-12 13:22:56 --> Output Class Initialized
INFO - 2018-02-12 13:22:56 --> Security Class Initialized
DEBUG - 2018-02-12 13:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 13:22:56 --> Input Class Initialized
INFO - 2018-02-12 13:22:56 --> Language Class Initialized
INFO - 2018-02-12 13:22:56 --> Language Class Initialized
INFO - 2018-02-12 13:22:56 --> Config Class Initialized
INFO - 2018-02-12 13:22:56 --> Loader Class Initialized
INFO - 2018-02-12 18:52:56 --> Helper loaded: url_helper
INFO - 2018-02-12 18:52:56 --> Helper loaded: notification_helper
INFO - 2018-02-12 18:52:56 --> Helper loaded: settings_helper
INFO - 2018-02-12 18:52:56 --> Helper loaded: permission_helper
INFO - 2018-02-12 18:52:56 --> Helper loaded: users_helper
INFO - 2018-02-12 18:52:56 --> Database Driver Class Initialized
DEBUG - 2018-02-12 18:52:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 18:52:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 18:52:56 --> Helper loaded: form_helper
INFO - 2018-02-12 18:52:56 --> Form Validation Class Initialized
INFO - 2018-02-12 18:52:56 --> Controller Class Initialized
INFO - 2018-02-12 18:52:56 --> Model Class Initialized
INFO - 2018-02-12 18:52:56 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 18:52:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 18:52:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 18:52:56 --> Model Class Initialized
INFO - 2018-02-12 18:52:56 --> Model Class Initialized
INFO - 2018-02-12 18:52:56 --> Model Class Initialized
INFO - 2018-02-12 18:52:56 --> Model Class Initialized
INFO - 2018-02-12 18:52:56 --> Model Class Initialized
INFO - 2018-02-12 18:52:56 --> Model Class Initialized
INFO - 2018-02-12 18:52:56 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 18:52:56 --> Final output sent to browser
DEBUG - 2018-02-12 18:52:56 --> Total execution time: 0.1108
INFO - 2018-02-12 13:22:57 --> Config Class Initialized
INFO - 2018-02-12 13:22:57 --> Hooks Class Initialized
DEBUG - 2018-02-12 13:22:57 --> UTF-8 Support Enabled
INFO - 2018-02-12 13:22:57 --> Utf8 Class Initialized
INFO - 2018-02-12 13:22:57 --> URI Class Initialized
INFO - 2018-02-12 13:22:57 --> Router Class Initialized
INFO - 2018-02-12 13:22:57 --> Output Class Initialized
INFO - 2018-02-12 13:22:57 --> Security Class Initialized
DEBUG - 2018-02-12 13:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 13:22:57 --> Input Class Initialized
INFO - 2018-02-12 13:22:57 --> Language Class Initialized
INFO - 2018-02-12 13:22:57 --> Language Class Initialized
INFO - 2018-02-12 13:22:57 --> Config Class Initialized
INFO - 2018-02-12 13:22:57 --> Loader Class Initialized
INFO - 2018-02-12 18:52:57 --> Helper loaded: url_helper
INFO - 2018-02-12 18:52:57 --> Helper loaded: notification_helper
INFO - 2018-02-12 18:52:57 --> Helper loaded: settings_helper
INFO - 2018-02-12 18:52:57 --> Helper loaded: permission_helper
INFO - 2018-02-12 18:52:57 --> Helper loaded: users_helper
INFO - 2018-02-12 18:52:57 --> Database Driver Class Initialized
DEBUG - 2018-02-12 18:52:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 18:52:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 18:52:57 --> Helper loaded: form_helper
INFO - 2018-02-12 18:52:57 --> Form Validation Class Initialized
INFO - 2018-02-12 18:52:57 --> Controller Class Initialized
INFO - 2018-02-12 18:52:57 --> Model Class Initialized
INFO - 2018-02-12 18:52:57 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 18:52:57 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 18:52:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 18:52:57 --> Model Class Initialized
INFO - 2018-02-12 18:52:57 --> Model Class Initialized
INFO - 2018-02-12 18:52:57 --> Model Class Initialized
INFO - 2018-02-12 18:52:57 --> Model Class Initialized
INFO - 2018-02-12 18:52:57 --> Model Class Initialized
INFO - 2018-02-12 18:52:57 --> Model Class Initialized
INFO - 2018-02-12 18:52:57 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 18:52:57 --> Final output sent to browser
DEBUG - 2018-02-12 18:52:57 --> Total execution time: 0.1144
INFO - 2018-02-12 13:33:43 --> Config Class Initialized
INFO - 2018-02-12 13:33:43 --> Hooks Class Initialized
DEBUG - 2018-02-12 13:33:43 --> UTF-8 Support Enabled
INFO - 2018-02-12 13:33:43 --> Utf8 Class Initialized
INFO - 2018-02-12 13:33:43 --> URI Class Initialized
INFO - 2018-02-12 13:33:43 --> Router Class Initialized
INFO - 2018-02-12 13:33:43 --> Output Class Initialized
INFO - 2018-02-12 13:33:43 --> Security Class Initialized
DEBUG - 2018-02-12 13:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 13:33:43 --> Input Class Initialized
INFO - 2018-02-12 13:33:43 --> Language Class Initialized
INFO - 2018-02-12 13:33:43 --> Language Class Initialized
INFO - 2018-02-12 13:33:43 --> Config Class Initialized
INFO - 2018-02-12 13:33:43 --> Loader Class Initialized
INFO - 2018-02-12 19:03:43 --> Helper loaded: url_helper
INFO - 2018-02-12 19:03:43 --> Helper loaded: notification_helper
INFO - 2018-02-12 19:03:43 --> Helper loaded: settings_helper
INFO - 2018-02-12 19:03:43 --> Helper loaded: permission_helper
INFO - 2018-02-12 19:03:43 --> Helper loaded: users_helper
INFO - 2018-02-12 19:03:43 --> Database Driver Class Initialized
DEBUG - 2018-02-12 19:03:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 19:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 19:03:43 --> Helper loaded: form_helper
INFO - 2018-02-12 19:03:43 --> Form Validation Class Initialized
INFO - 2018-02-12 19:03:43 --> Controller Class Initialized
INFO - 2018-02-12 19:03:43 --> Model Class Initialized
INFO - 2018-02-12 19:03:43 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 19:03:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 19:03:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 19:03:43 --> Model Class Initialized
INFO - 2018-02-12 19:03:43 --> Model Class Initialized
INFO - 2018-02-12 19:03:43 --> Model Class Initialized
INFO - 2018-02-12 19:03:43 --> Model Class Initialized
INFO - 2018-02-12 19:03:43 --> Model Class Initialized
INFO - 2018-02-12 19:03:43 --> Model Class Initialized
INFO - 2018-02-12 19:03:43 --> Model Class Initialized
INFO - 2018-02-12 19:03:43 --> Model Class Initialized
INFO - 2018-02-12 19:03:43 --> Model Class Initialized
INFO - 2018-02-12 19:03:43 --> Model Class Initialized
INFO - 2018-02-12 19:03:43 --> Model Class Initialized
INFO - 2018-02-12 19:03:43 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 19:03:43 --> Model Class Initialized
INFO - 2018-02-12 19:03:43 --> Final output sent to browser
DEBUG - 2018-02-12 19:03:43 --> Total execution time: 0.1128
INFO - 2018-02-12 13:33:43 --> Config Class Initialized
INFO - 2018-02-12 13:33:43 --> Hooks Class Initialized
DEBUG - 2018-02-12 13:33:43 --> UTF-8 Support Enabled
INFO - 2018-02-12 13:33:43 --> Utf8 Class Initialized
INFO - 2018-02-12 13:33:43 --> URI Class Initialized
INFO - 2018-02-12 13:33:43 --> Router Class Initialized
INFO - 2018-02-12 13:33:43 --> Output Class Initialized
INFO - 2018-02-12 13:33:43 --> Security Class Initialized
DEBUG - 2018-02-12 13:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 13:33:43 --> Input Class Initialized
INFO - 2018-02-12 13:33:43 --> Language Class Initialized
INFO - 2018-02-12 13:33:43 --> Language Class Initialized
INFO - 2018-02-12 13:33:43 --> Config Class Initialized
INFO - 2018-02-12 13:33:43 --> Loader Class Initialized
INFO - 2018-02-12 19:03:43 --> Helper loaded: url_helper
INFO - 2018-02-12 19:03:43 --> Helper loaded: notification_helper
INFO - 2018-02-12 19:03:43 --> Helper loaded: settings_helper
INFO - 2018-02-12 19:03:43 --> Helper loaded: permission_helper
INFO - 2018-02-12 19:03:43 --> Helper loaded: users_helper
INFO - 2018-02-12 19:03:43 --> Database Driver Class Initialized
DEBUG - 2018-02-12 19:03:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 19:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 19:03:43 --> Helper loaded: form_helper
INFO - 2018-02-12 19:03:43 --> Form Validation Class Initialized
INFO - 2018-02-12 19:03:43 --> Controller Class Initialized
INFO - 2018-02-12 19:03:43 --> Model Class Initialized
INFO - 2018-02-12 19:03:43 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 19:03:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 19:03:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 19:03:43 --> Model Class Initialized
INFO - 2018-02-12 19:03:43 --> Model Class Initialized
INFO - 2018-02-12 19:03:43 --> Model Class Initialized
INFO - 2018-02-12 19:03:43 --> Model Class Initialized
INFO - 2018-02-12 19:03:43 --> Model Class Initialized
INFO - 2018-02-12 19:03:43 --> Model Class Initialized
INFO - 2018-02-12 19:03:43 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 19:03:43 --> Model Class Initialized
INFO - 2018-02-12 19:03:43 --> Final output sent to browser
DEBUG - 2018-02-12 19:03:43 --> Total execution time: 0.1671
INFO - 2018-02-12 13:33:50 --> Config Class Initialized
INFO - 2018-02-12 13:33:50 --> Hooks Class Initialized
INFO - 2018-02-12 13:33:50 --> Config Class Initialized
DEBUG - 2018-02-12 13:33:50 --> UTF-8 Support Enabled
INFO - 2018-02-12 13:33:50 --> Hooks Class Initialized
INFO - 2018-02-12 13:33:50 --> Utf8 Class Initialized
INFO - 2018-02-12 13:33:50 --> URI Class Initialized
DEBUG - 2018-02-12 13:33:50 --> UTF-8 Support Enabled
INFO - 2018-02-12 13:33:50 --> Utf8 Class Initialized
INFO - 2018-02-12 13:33:50 --> URI Class Initialized
INFO - 2018-02-12 13:33:50 --> Router Class Initialized
INFO - 2018-02-12 13:33:50 --> Output Class Initialized
INFO - 2018-02-12 13:33:50 --> Router Class Initialized
INFO - 2018-02-12 13:33:50 --> Security Class Initialized
INFO - 2018-02-12 13:33:50 --> Output Class Initialized
DEBUG - 2018-02-12 13:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 13:33:50 --> Input Class Initialized
INFO - 2018-02-12 13:33:50 --> Language Class Initialized
INFO - 2018-02-12 13:33:50 --> Security Class Initialized
DEBUG - 2018-02-12 13:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 13:33:50 --> Input Class Initialized
INFO - 2018-02-12 13:33:50 --> Language Class Initialized
INFO - 2018-02-12 13:33:50 --> Language Class Initialized
INFO - 2018-02-12 13:33:50 --> Config Class Initialized
INFO - 2018-02-12 13:33:50 --> Loader Class Initialized
INFO - 2018-02-12 19:03:50 --> Helper loaded: url_helper
INFO - 2018-02-12 19:03:50 --> Helper loaded: notification_helper
INFO - 2018-02-12 19:03:50 --> Helper loaded: settings_helper
INFO - 2018-02-12 19:03:50 --> Helper loaded: permission_helper
INFO - 2018-02-12 19:03:50 --> Helper loaded: users_helper
INFO - 2018-02-12 13:33:50 --> Language Class Initialized
INFO - 2018-02-12 13:33:50 --> Config Class Initialized
INFO - 2018-02-12 13:33:50 --> Loader Class Initialized
INFO - 2018-02-12 19:03:50 --> Helper loaded: url_helper
INFO - 2018-02-12 19:03:50 --> Helper loaded: notification_helper
INFO - 2018-02-12 19:03:50 --> Helper loaded: settings_helper
INFO - 2018-02-12 19:03:50 --> Helper loaded: permission_helper
INFO - 2018-02-12 19:03:50 --> Database Driver Class Initialized
INFO - 2018-02-12 19:03:50 --> Helper loaded: users_helper
DEBUG - 2018-02-12 19:03:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 19:03:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 19:03:50 --> Helper loaded: form_helper
INFO - 2018-02-12 19:03:50 --> Form Validation Class Initialized
INFO - 2018-02-12 19:03:50 --> Controller Class Initialized
INFO - 2018-02-12 19:03:50 --> Database Driver Class Initialized
DEBUG - 2018-02-12 19:03:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 19:03:50 --> Model Class Initialized
INFO - 2018-02-12 19:03:50 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 19:03:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 19:03:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 19:03:50 --> Model Class Initialized
INFO - 2018-02-12 19:03:50 --> Model Class Initialized
INFO - 2018-02-12 19:03:50 --> Model Class Initialized
INFO - 2018-02-12 19:03:50 --> Model Class Initialized
INFO - 2018-02-12 19:03:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 19:03:50 --> Final output sent to browser
DEBUG - 2018-02-12 19:03:50 --> Total execution time: 0.1036
INFO - 2018-02-12 19:03:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 19:03:50 --> Helper loaded: form_helper
INFO - 2018-02-12 19:03:50 --> Form Validation Class Initialized
INFO - 2018-02-12 19:03:50 --> Controller Class Initialized
INFO - 2018-02-12 19:03:50 --> Model Class Initialized
INFO - 2018-02-12 19:03:50 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 19:03:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 19:03:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 19:03:50 --> Model Class Initialized
INFO - 2018-02-12 19:03:50 --> Model Class Initialized
INFO - 2018-02-12 19:03:50 --> Model Class Initialized
INFO - 2018-02-12 19:03:50 --> Model Class Initialized
INFO - 2018-02-12 19:03:50 --> Model Class Initialized
INFO - 2018-02-12 19:03:50 --> Model Class Initialized
INFO - 2018-02-12 19:03:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 19:03:50 --> Final output sent to browser
DEBUG - 2018-02-12 19:03:50 --> Total execution time: 0.1483
INFO - 2018-02-12 13:34:01 --> Config Class Initialized
INFO - 2018-02-12 13:34:01 --> Hooks Class Initialized
DEBUG - 2018-02-12 13:34:01 --> UTF-8 Support Enabled
INFO - 2018-02-12 13:34:01 --> Utf8 Class Initialized
INFO - 2018-02-12 13:34:01 --> URI Class Initialized
INFO - 2018-02-12 13:34:01 --> Router Class Initialized
INFO - 2018-02-12 13:34:01 --> Output Class Initialized
INFO - 2018-02-12 13:34:01 --> Security Class Initialized
DEBUG - 2018-02-12 13:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 13:34:01 --> Input Class Initialized
INFO - 2018-02-12 13:34:01 --> Language Class Initialized
INFO - 2018-02-12 13:34:01 --> Language Class Initialized
INFO - 2018-02-12 13:34:01 --> Config Class Initialized
INFO - 2018-02-12 13:34:01 --> Loader Class Initialized
INFO - 2018-02-12 19:04:01 --> Helper loaded: url_helper
INFO - 2018-02-12 19:04:01 --> Helper loaded: notification_helper
INFO - 2018-02-12 19:04:01 --> Helper loaded: settings_helper
INFO - 2018-02-12 19:04:01 --> Helper loaded: permission_helper
INFO - 2018-02-12 19:04:01 --> Helper loaded: users_helper
INFO - 2018-02-12 19:04:01 --> Database Driver Class Initialized
DEBUG - 2018-02-12 19:04:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 19:04:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 19:04:01 --> Helper loaded: form_helper
INFO - 2018-02-12 19:04:01 --> Form Validation Class Initialized
INFO - 2018-02-12 19:04:01 --> Controller Class Initialized
INFO - 2018-02-12 19:04:01 --> Model Class Initialized
INFO - 2018-02-12 19:04:01 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 19:04:01 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 19:04:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 19:04:01 --> Model Class Initialized
INFO - 2018-02-12 19:04:01 --> Model Class Initialized
INFO - 2018-02-12 19:04:01 --> Model Class Initialized
INFO - 2018-02-12 19:04:01 --> Model Class Initialized
INFO - 2018-02-12 19:04:01 --> Model Class Initialized
INFO - 2018-02-12 19:04:01 --> Model Class Initialized
INFO - 2018-02-12 19:04:01 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 19:04:01 --> Final output sent to browser
DEBUG - 2018-02-12 19:04:01 --> Total execution time: 0.1093
INFO - 2018-02-12 13:34:05 --> Config Class Initialized
INFO - 2018-02-12 13:34:05 --> Hooks Class Initialized
DEBUG - 2018-02-12 13:34:05 --> UTF-8 Support Enabled
INFO - 2018-02-12 13:34:05 --> Utf8 Class Initialized
INFO - 2018-02-12 13:34:05 --> URI Class Initialized
INFO - 2018-02-12 13:34:05 --> Router Class Initialized
INFO - 2018-02-12 13:34:05 --> Output Class Initialized
INFO - 2018-02-12 13:34:05 --> Security Class Initialized
DEBUG - 2018-02-12 13:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 13:34:05 --> Input Class Initialized
INFO - 2018-02-12 13:34:05 --> Language Class Initialized
INFO - 2018-02-12 13:34:05 --> Language Class Initialized
INFO - 2018-02-12 13:34:05 --> Config Class Initialized
INFO - 2018-02-12 13:34:05 --> Loader Class Initialized
INFO - 2018-02-12 19:04:05 --> Helper loaded: url_helper
INFO - 2018-02-12 19:04:05 --> Helper loaded: notification_helper
INFO - 2018-02-12 19:04:05 --> Helper loaded: settings_helper
INFO - 2018-02-12 19:04:05 --> Helper loaded: permission_helper
INFO - 2018-02-12 19:04:05 --> Helper loaded: users_helper
INFO - 2018-02-12 19:04:05 --> Database Driver Class Initialized
DEBUG - 2018-02-12 19:04:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 19:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 19:04:05 --> Helper loaded: form_helper
INFO - 2018-02-12 19:04:05 --> Form Validation Class Initialized
INFO - 2018-02-12 19:04:05 --> Controller Class Initialized
INFO - 2018-02-12 19:04:05 --> Model Class Initialized
INFO - 2018-02-12 19:04:05 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 19:04:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 19:04:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 19:04:05 --> Model Class Initialized
INFO - 2018-02-12 19:04:05 --> Model Class Initialized
INFO - 2018-02-12 19:04:05 --> Model Class Initialized
INFO - 2018-02-12 19:04:05 --> Model Class Initialized
INFO - 2018-02-12 19:04:05 --> Model Class Initialized
INFO - 2018-02-12 19:04:05 --> Model Class Initialized
INFO - 2018-02-12 19:04:05 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 19:04:05 --> Final output sent to browser
DEBUG - 2018-02-12 19:04:05 --> Total execution time: 0.1177
INFO - 2018-02-12 13:34:09 --> Config Class Initialized
INFO - 2018-02-12 13:34:09 --> Hooks Class Initialized
DEBUG - 2018-02-12 13:34:09 --> UTF-8 Support Enabled
INFO - 2018-02-12 13:34:09 --> Utf8 Class Initialized
INFO - 2018-02-12 13:34:09 --> URI Class Initialized
INFO - 2018-02-12 13:34:09 --> Router Class Initialized
INFO - 2018-02-12 13:34:09 --> Output Class Initialized
INFO - 2018-02-12 13:34:09 --> Security Class Initialized
DEBUG - 2018-02-12 13:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 13:34:09 --> Input Class Initialized
INFO - 2018-02-12 13:34:09 --> Language Class Initialized
INFO - 2018-02-12 13:34:09 --> Language Class Initialized
INFO - 2018-02-12 13:34:09 --> Config Class Initialized
INFO - 2018-02-12 13:34:09 --> Loader Class Initialized
INFO - 2018-02-12 19:04:09 --> Helper loaded: url_helper
INFO - 2018-02-12 19:04:09 --> Helper loaded: notification_helper
INFO - 2018-02-12 19:04:09 --> Helper loaded: settings_helper
INFO - 2018-02-12 19:04:09 --> Helper loaded: permission_helper
INFO - 2018-02-12 19:04:09 --> Helper loaded: users_helper
INFO - 2018-02-12 19:04:09 --> Database Driver Class Initialized
DEBUG - 2018-02-12 19:04:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 19:04:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 19:04:09 --> Helper loaded: form_helper
INFO - 2018-02-12 19:04:09 --> Form Validation Class Initialized
INFO - 2018-02-12 19:04:09 --> Controller Class Initialized
INFO - 2018-02-12 19:04:09 --> Model Class Initialized
INFO - 2018-02-12 19:04:09 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 19:04:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 19:04:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 19:04:09 --> Model Class Initialized
INFO - 2018-02-12 19:04:09 --> Model Class Initialized
INFO - 2018-02-12 19:04:09 --> Model Class Initialized
INFO - 2018-02-12 19:04:09 --> Model Class Initialized
INFO - 2018-02-12 19:04:09 --> Model Class Initialized
INFO - 2018-02-12 19:04:09 --> Model Class Initialized
INFO - 2018-02-12 19:04:09 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 19:04:09 --> Final output sent to browser
DEBUG - 2018-02-12 19:04:09 --> Total execution time: 0.1171
INFO - 2018-02-12 13:34:11 --> Config Class Initialized
INFO - 2018-02-12 13:34:11 --> Hooks Class Initialized
DEBUG - 2018-02-12 13:34:11 --> UTF-8 Support Enabled
INFO - 2018-02-12 13:34:11 --> Utf8 Class Initialized
INFO - 2018-02-12 13:34:11 --> URI Class Initialized
INFO - 2018-02-12 13:34:11 --> Router Class Initialized
INFO - 2018-02-12 13:34:11 --> Output Class Initialized
INFO - 2018-02-12 13:34:11 --> Security Class Initialized
DEBUG - 2018-02-12 13:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 13:34:11 --> Input Class Initialized
INFO - 2018-02-12 13:34:11 --> Language Class Initialized
INFO - 2018-02-12 13:34:11 --> Language Class Initialized
INFO - 2018-02-12 13:34:11 --> Config Class Initialized
INFO - 2018-02-12 13:34:11 --> Loader Class Initialized
INFO - 2018-02-12 19:04:11 --> Helper loaded: url_helper
INFO - 2018-02-12 19:04:11 --> Helper loaded: notification_helper
INFO - 2018-02-12 19:04:11 --> Helper loaded: settings_helper
INFO - 2018-02-12 19:04:11 --> Helper loaded: permission_helper
INFO - 2018-02-12 19:04:11 --> Helper loaded: users_helper
INFO - 2018-02-12 19:04:11 --> Database Driver Class Initialized
DEBUG - 2018-02-12 19:04:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 19:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 19:04:11 --> Helper loaded: form_helper
INFO - 2018-02-12 19:04:11 --> Form Validation Class Initialized
INFO - 2018-02-12 19:04:11 --> Controller Class Initialized
INFO - 2018-02-12 19:04:11 --> Model Class Initialized
INFO - 2018-02-12 19:04:11 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 19:04:11 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 19:04:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 19:04:11 --> Model Class Initialized
INFO - 2018-02-12 19:04:11 --> Model Class Initialized
INFO - 2018-02-12 19:04:11 --> Model Class Initialized
INFO - 2018-02-12 19:04:11 --> Model Class Initialized
INFO - 2018-02-12 19:04:11 --> Model Class Initialized
INFO - 2018-02-12 19:04:11 --> Model Class Initialized
INFO - 2018-02-12 19:04:11 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 19:04:11 --> Final output sent to browser
DEBUG - 2018-02-12 19:04:11 --> Total execution time: 0.1170
INFO - 2018-02-12 13:34:12 --> Config Class Initialized
INFO - 2018-02-12 13:34:12 --> Hooks Class Initialized
DEBUG - 2018-02-12 13:34:12 --> UTF-8 Support Enabled
INFO - 2018-02-12 13:34:12 --> Utf8 Class Initialized
INFO - 2018-02-12 13:34:12 --> URI Class Initialized
INFO - 2018-02-12 13:34:12 --> Router Class Initialized
INFO - 2018-02-12 13:34:12 --> Output Class Initialized
INFO - 2018-02-12 13:34:12 --> Security Class Initialized
DEBUG - 2018-02-12 13:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 13:34:12 --> Input Class Initialized
INFO - 2018-02-12 13:34:12 --> Language Class Initialized
INFO - 2018-02-12 13:34:12 --> Language Class Initialized
INFO - 2018-02-12 13:34:12 --> Config Class Initialized
INFO - 2018-02-12 13:34:13 --> Loader Class Initialized
INFO - 2018-02-12 19:04:13 --> Helper loaded: url_helper
INFO - 2018-02-12 19:04:13 --> Helper loaded: notification_helper
INFO - 2018-02-12 19:04:13 --> Helper loaded: settings_helper
INFO - 2018-02-12 19:04:13 --> Helper loaded: permission_helper
INFO - 2018-02-12 19:04:13 --> Helper loaded: users_helper
INFO - 2018-02-12 19:04:13 --> Database Driver Class Initialized
DEBUG - 2018-02-12 19:04:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 19:04:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 19:04:13 --> Helper loaded: form_helper
INFO - 2018-02-12 19:04:13 --> Form Validation Class Initialized
INFO - 2018-02-12 19:04:13 --> Controller Class Initialized
INFO - 2018-02-12 19:04:13 --> Model Class Initialized
INFO - 2018-02-12 19:04:13 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 19:04:13 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 19:04:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 19:04:13 --> Model Class Initialized
INFO - 2018-02-12 19:04:13 --> Model Class Initialized
INFO - 2018-02-12 19:04:13 --> Model Class Initialized
INFO - 2018-02-12 19:04:13 --> Model Class Initialized
INFO - 2018-02-12 19:04:13 --> Model Class Initialized
INFO - 2018-02-12 19:04:13 --> Model Class Initialized
INFO - 2018-02-12 19:04:13 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 19:04:13 --> Final output sent to browser
DEBUG - 2018-02-12 19:04:13 --> Total execution time: 0.1101
INFO - 2018-02-12 13:34:17 --> Config Class Initialized
INFO - 2018-02-12 13:34:17 --> Hooks Class Initialized
DEBUG - 2018-02-12 13:34:17 --> UTF-8 Support Enabled
INFO - 2018-02-12 13:34:17 --> Utf8 Class Initialized
INFO - 2018-02-12 13:34:17 --> URI Class Initialized
INFO - 2018-02-12 13:34:17 --> Router Class Initialized
INFO - 2018-02-12 13:34:17 --> Output Class Initialized
INFO - 2018-02-12 13:34:17 --> Security Class Initialized
DEBUG - 2018-02-12 13:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 13:34:17 --> Input Class Initialized
INFO - 2018-02-12 13:34:17 --> Language Class Initialized
INFO - 2018-02-12 13:34:17 --> Language Class Initialized
INFO - 2018-02-12 13:34:17 --> Config Class Initialized
INFO - 2018-02-12 13:34:17 --> Loader Class Initialized
INFO - 2018-02-12 19:04:17 --> Helper loaded: url_helper
INFO - 2018-02-12 19:04:17 --> Helper loaded: notification_helper
INFO - 2018-02-12 19:04:17 --> Helper loaded: settings_helper
INFO - 2018-02-12 19:04:17 --> Helper loaded: permission_helper
INFO - 2018-02-12 19:04:17 --> Helper loaded: users_helper
INFO - 2018-02-12 19:04:17 --> Database Driver Class Initialized
DEBUG - 2018-02-12 19:04:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 19:04:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 19:04:17 --> Helper loaded: form_helper
INFO - 2018-02-12 19:04:17 --> Form Validation Class Initialized
INFO - 2018-02-12 19:04:17 --> Controller Class Initialized
INFO - 2018-02-12 19:04:17 --> Model Class Initialized
INFO - 2018-02-12 19:04:17 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 19:04:17 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 19:04:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 19:04:17 --> Model Class Initialized
INFO - 2018-02-12 19:04:17 --> Model Class Initialized
INFO - 2018-02-12 19:04:17 --> Final output sent to browser
DEBUG - 2018-02-12 19:04:17 --> Total execution time: 0.1104
INFO - 2018-02-12 13:35:52 --> Config Class Initialized
INFO - 2018-02-12 13:35:52 --> Hooks Class Initialized
DEBUG - 2018-02-12 13:35:52 --> UTF-8 Support Enabled
INFO - 2018-02-12 13:35:52 --> Utf8 Class Initialized
INFO - 2018-02-12 13:35:52 --> URI Class Initialized
INFO - 2018-02-12 13:35:52 --> Router Class Initialized
INFO - 2018-02-12 13:35:52 --> Output Class Initialized
INFO - 2018-02-12 13:35:52 --> Security Class Initialized
DEBUG - 2018-02-12 13:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 13:35:52 --> Input Class Initialized
INFO - 2018-02-12 13:35:52 --> Language Class Initialized
INFO - 2018-02-12 13:35:52 --> Language Class Initialized
INFO - 2018-02-12 13:35:52 --> Config Class Initialized
INFO - 2018-02-12 13:35:52 --> Loader Class Initialized
INFO - 2018-02-12 19:05:52 --> Helper loaded: url_helper
INFO - 2018-02-12 19:05:52 --> Helper loaded: notification_helper
INFO - 2018-02-12 19:05:52 --> Helper loaded: settings_helper
INFO - 2018-02-12 19:05:52 --> Helper loaded: permission_helper
INFO - 2018-02-12 19:05:52 --> Helper loaded: users_helper
INFO - 2018-02-12 19:05:52 --> Database Driver Class Initialized
DEBUG - 2018-02-12 19:05:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 19:05:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 19:05:52 --> Helper loaded: form_helper
INFO - 2018-02-12 19:05:52 --> Form Validation Class Initialized
INFO - 2018-02-12 19:05:52 --> Controller Class Initialized
INFO - 2018-02-12 19:05:52 --> Model Class Initialized
INFO - 2018-02-12 19:05:52 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 19:05:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 19:05:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 19:05:52 --> Model Class Initialized
INFO - 2018-02-12 19:05:52 --> Model Class Initialized
INFO - 2018-02-12 19:05:52 --> Model Class Initialized
INFO - 2018-02-12 19:05:52 --> Model Class Initialized
INFO - 2018-02-12 19:05:52 --> Model Class Initialized
INFO - 2018-02-12 19:05:52 --> Model Class Initialized
INFO - 2018-02-12 19:05:52 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 19:05:52 --> Final output sent to browser
DEBUG - 2018-02-12 19:05:52 --> Total execution time: 0.1164
INFO - 2018-02-12 13:35:57 --> Config Class Initialized
INFO - 2018-02-12 13:35:57 --> Hooks Class Initialized
DEBUG - 2018-02-12 13:35:57 --> UTF-8 Support Enabled
INFO - 2018-02-12 13:35:57 --> Utf8 Class Initialized
INFO - 2018-02-12 13:35:57 --> URI Class Initialized
INFO - 2018-02-12 13:35:57 --> Router Class Initialized
INFO - 2018-02-12 13:35:57 --> Output Class Initialized
INFO - 2018-02-12 13:35:57 --> Security Class Initialized
DEBUG - 2018-02-12 13:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 13:35:57 --> Input Class Initialized
INFO - 2018-02-12 13:35:57 --> Language Class Initialized
INFO - 2018-02-12 13:35:57 --> Language Class Initialized
INFO - 2018-02-12 13:35:57 --> Config Class Initialized
INFO - 2018-02-12 13:35:57 --> Loader Class Initialized
INFO - 2018-02-12 19:05:57 --> Helper loaded: url_helper
INFO - 2018-02-12 19:05:57 --> Helper loaded: notification_helper
INFO - 2018-02-12 19:05:57 --> Helper loaded: settings_helper
INFO - 2018-02-12 19:05:57 --> Helper loaded: permission_helper
INFO - 2018-02-12 19:05:57 --> Helper loaded: users_helper
INFO - 2018-02-12 19:05:57 --> Database Driver Class Initialized
DEBUG - 2018-02-12 19:05:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 19:05:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 19:05:57 --> Helper loaded: form_helper
INFO - 2018-02-12 19:05:57 --> Form Validation Class Initialized
INFO - 2018-02-12 19:05:57 --> Controller Class Initialized
INFO - 2018-02-12 19:05:57 --> Model Class Initialized
INFO - 2018-02-12 19:05:57 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 19:05:57 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 19:05:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 19:05:57 --> Model Class Initialized
INFO - 2018-02-12 19:05:57 --> Model Class Initialized
INFO - 2018-02-12 13:35:57 --> Config Class Initialized
INFO - 2018-02-12 13:35:57 --> Hooks Class Initialized
INFO - 2018-02-12 19:05:57 --> Model Class Initialized
INFO - 2018-02-12 19:05:57 --> Model Class Initialized
INFO - 2018-02-12 19:05:57 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-02-12 13:35:57 --> UTF-8 Support Enabled
INFO - 2018-02-12 13:35:57 --> Utf8 Class Initialized
INFO - 2018-02-12 19:05:57 --> Final output sent to browser
DEBUG - 2018-02-12 19:05:57 --> Total execution time: 0.1020
INFO - 2018-02-12 13:35:57 --> URI Class Initialized
INFO - 2018-02-12 13:35:57 --> Router Class Initialized
INFO - 2018-02-12 13:35:57 --> Output Class Initialized
INFO - 2018-02-12 13:35:57 --> Security Class Initialized
DEBUG - 2018-02-12 13:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 13:35:57 --> Input Class Initialized
INFO - 2018-02-12 13:35:57 --> Language Class Initialized
INFO - 2018-02-12 13:35:57 --> Language Class Initialized
INFO - 2018-02-12 13:35:57 --> Config Class Initialized
INFO - 2018-02-12 13:35:57 --> Loader Class Initialized
INFO - 2018-02-12 19:05:57 --> Helper loaded: url_helper
INFO - 2018-02-12 19:05:57 --> Helper loaded: notification_helper
INFO - 2018-02-12 19:05:57 --> Helper loaded: settings_helper
INFO - 2018-02-12 19:05:57 --> Helper loaded: permission_helper
INFO - 2018-02-12 19:05:57 --> Helper loaded: users_helper
INFO - 2018-02-12 19:05:57 --> Database Driver Class Initialized
DEBUG - 2018-02-12 19:05:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 19:05:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 19:05:57 --> Helper loaded: form_helper
INFO - 2018-02-12 19:05:57 --> Form Validation Class Initialized
INFO - 2018-02-12 19:05:57 --> Controller Class Initialized
INFO - 2018-02-12 19:05:57 --> Model Class Initialized
INFO - 2018-02-12 19:05:57 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 19:05:57 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 19:05:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 19:05:57 --> Model Class Initialized
INFO - 2018-02-12 19:05:57 --> Model Class Initialized
INFO - 2018-02-12 19:05:57 --> Model Class Initialized
INFO - 2018-02-12 19:05:57 --> Model Class Initialized
INFO - 2018-02-12 19:05:57 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 19:05:57 --> Final output sent to browser
DEBUG - 2018-02-12 19:05:57 --> Total execution time: 0.1170
INFO - 2018-02-12 13:36:00 --> Config Class Initialized
INFO - 2018-02-12 13:36:00 --> Hooks Class Initialized
DEBUG - 2018-02-12 13:36:00 --> UTF-8 Support Enabled
INFO - 2018-02-12 13:36:00 --> Utf8 Class Initialized
INFO - 2018-02-12 13:36:00 --> URI Class Initialized
INFO - 2018-02-12 13:36:00 --> Router Class Initialized
INFO - 2018-02-12 13:36:00 --> Output Class Initialized
INFO - 2018-02-12 13:36:00 --> Security Class Initialized
DEBUG - 2018-02-12 13:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 13:36:00 --> Input Class Initialized
INFO - 2018-02-12 13:36:00 --> Language Class Initialized
INFO - 2018-02-12 13:36:00 --> Language Class Initialized
INFO - 2018-02-12 13:36:00 --> Config Class Initialized
INFO - 2018-02-12 13:36:00 --> Loader Class Initialized
INFO - 2018-02-12 19:06:00 --> Helper loaded: url_helper
INFO - 2018-02-12 19:06:00 --> Helper loaded: notification_helper
INFO - 2018-02-12 19:06:00 --> Helper loaded: settings_helper
INFO - 2018-02-12 19:06:00 --> Helper loaded: permission_helper
INFO - 2018-02-12 19:06:00 --> Helper loaded: users_helper
INFO - 2018-02-12 19:06:00 --> Database Driver Class Initialized
DEBUG - 2018-02-12 19:06:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 19:06:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 19:06:00 --> Helper loaded: form_helper
INFO - 2018-02-12 19:06:00 --> Form Validation Class Initialized
INFO - 2018-02-12 19:06:00 --> Controller Class Initialized
INFO - 2018-02-12 19:06:00 --> Model Class Initialized
INFO - 2018-02-12 19:06:00 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 19:06:00 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 19:06:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 19:06:00 --> Model Class Initialized
INFO - 2018-02-12 19:06:00 --> Model Class Initialized
INFO - 2018-02-12 19:06:00 --> Model Class Initialized
INFO - 2018-02-12 19:06:00 --> Model Class Initialized
INFO - 2018-02-12 19:06:00 --> Model Class Initialized
INFO - 2018-02-12 19:06:00 --> Model Class Initialized
INFO - 2018-02-12 19:06:00 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 19:06:00 --> Final output sent to browser
DEBUG - 2018-02-12 19:06:00 --> Total execution time: 0.1205
INFO - 2018-02-12 13:36:24 --> Config Class Initialized
INFO - 2018-02-12 13:36:24 --> Hooks Class Initialized
DEBUG - 2018-02-12 13:36:24 --> UTF-8 Support Enabled
INFO - 2018-02-12 13:36:24 --> Utf8 Class Initialized
INFO - 2018-02-12 13:36:24 --> URI Class Initialized
INFO - 2018-02-12 13:36:24 --> Router Class Initialized
INFO - 2018-02-12 13:36:24 --> Output Class Initialized
INFO - 2018-02-12 13:36:24 --> Security Class Initialized
DEBUG - 2018-02-12 13:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 13:36:24 --> Input Class Initialized
INFO - 2018-02-12 13:36:24 --> Language Class Initialized
INFO - 2018-02-12 13:36:24 --> Language Class Initialized
INFO - 2018-02-12 13:36:24 --> Config Class Initialized
INFO - 2018-02-12 13:36:24 --> Loader Class Initialized
INFO - 2018-02-12 19:06:24 --> Helper loaded: url_helper
INFO - 2018-02-12 19:06:24 --> Helper loaded: notification_helper
INFO - 2018-02-12 19:06:24 --> Helper loaded: settings_helper
INFO - 2018-02-12 19:06:24 --> Helper loaded: permission_helper
INFO - 2018-02-12 19:06:24 --> Helper loaded: users_helper
INFO - 2018-02-12 19:06:24 --> Database Driver Class Initialized
DEBUG - 2018-02-12 19:06:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 19:06:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 19:06:24 --> Helper loaded: form_helper
INFO - 2018-02-12 19:06:24 --> Form Validation Class Initialized
INFO - 2018-02-12 19:06:24 --> Controller Class Initialized
INFO - 2018-02-12 19:06:24 --> Model Class Initialized
INFO - 2018-02-12 19:06:24 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 19:06:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 19:06:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 19:06:24 --> Model Class Initialized
INFO - 2018-02-12 19:06:24 --> Model Class Initialized
INFO - 2018-02-12 19:06:24 --> Model Class Initialized
INFO - 2018-02-12 19:06:24 --> Model Class Initialized
INFO - 2018-02-12 19:06:24 --> Final output sent to browser
DEBUG - 2018-02-12 19:06:24 --> Total execution time: 0.1060
INFO - 2018-02-12 13:36:26 --> Config Class Initialized
INFO - 2018-02-12 13:36:26 --> Hooks Class Initialized
DEBUG - 2018-02-12 13:36:26 --> UTF-8 Support Enabled
INFO - 2018-02-12 13:36:26 --> Utf8 Class Initialized
INFO - 2018-02-12 13:36:26 --> URI Class Initialized
INFO - 2018-02-12 13:36:26 --> Router Class Initialized
INFO - 2018-02-12 13:36:26 --> Output Class Initialized
INFO - 2018-02-12 13:36:26 --> Security Class Initialized
DEBUG - 2018-02-12 13:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 13:36:26 --> Input Class Initialized
INFO - 2018-02-12 13:36:26 --> Language Class Initialized
INFO - 2018-02-12 13:36:26 --> Language Class Initialized
INFO - 2018-02-12 13:36:26 --> Config Class Initialized
INFO - 2018-02-12 13:36:26 --> Loader Class Initialized
INFO - 2018-02-12 19:06:26 --> Helper loaded: url_helper
INFO - 2018-02-12 19:06:26 --> Helper loaded: notification_helper
INFO - 2018-02-12 19:06:26 --> Helper loaded: settings_helper
INFO - 2018-02-12 19:06:26 --> Helper loaded: permission_helper
INFO - 2018-02-12 19:06:26 --> Helper loaded: users_helper
INFO - 2018-02-12 19:06:26 --> Database Driver Class Initialized
DEBUG - 2018-02-12 19:06:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 19:06:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 19:06:26 --> Helper loaded: form_helper
INFO - 2018-02-12 19:06:26 --> Form Validation Class Initialized
INFO - 2018-02-12 19:06:26 --> Controller Class Initialized
INFO - 2018-02-12 19:06:26 --> Model Class Initialized
INFO - 2018-02-12 19:06:26 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 19:06:26 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 19:06:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 19:06:26 --> Model Class Initialized
INFO - 2018-02-12 19:06:26 --> Model Class Initialized
INFO - 2018-02-12 19:06:26 --> Model Class Initialized
INFO - 2018-02-12 19:06:26 --> Model Class Initialized
INFO - 2018-02-12 19:06:26 --> Final output sent to browser
DEBUG - 2018-02-12 19:06:26 --> Total execution time: 0.1019
INFO - 2018-02-12 13:36:31 --> Config Class Initialized
INFO - 2018-02-12 13:36:31 --> Hooks Class Initialized
DEBUG - 2018-02-12 13:36:31 --> UTF-8 Support Enabled
INFO - 2018-02-12 13:36:31 --> Utf8 Class Initialized
INFO - 2018-02-12 13:36:31 --> URI Class Initialized
INFO - 2018-02-12 13:36:31 --> Router Class Initialized
INFO - 2018-02-12 13:36:31 --> Output Class Initialized
INFO - 2018-02-12 13:36:31 --> Security Class Initialized
DEBUG - 2018-02-12 13:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 13:36:31 --> Input Class Initialized
INFO - 2018-02-12 13:36:31 --> Language Class Initialized
INFO - 2018-02-12 13:36:31 --> Language Class Initialized
INFO - 2018-02-12 13:36:31 --> Config Class Initialized
INFO - 2018-02-12 13:36:31 --> Loader Class Initialized
INFO - 2018-02-12 19:06:31 --> Helper loaded: url_helper
INFO - 2018-02-12 19:06:31 --> Helper loaded: notification_helper
INFO - 2018-02-12 19:06:31 --> Helper loaded: settings_helper
INFO - 2018-02-12 19:06:31 --> Helper loaded: permission_helper
INFO - 2018-02-12 19:06:31 --> Helper loaded: users_helper
INFO - 2018-02-12 19:06:31 --> Database Driver Class Initialized
DEBUG - 2018-02-12 19:06:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 19:06:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 19:06:31 --> Helper loaded: form_helper
INFO - 2018-02-12 19:06:31 --> Form Validation Class Initialized
INFO - 2018-02-12 19:06:31 --> Controller Class Initialized
INFO - 2018-02-12 19:06:31 --> Model Class Initialized
INFO - 2018-02-12 19:06:31 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 19:06:32 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 19:06:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 19:06:32 --> Model Class Initialized
INFO - 2018-02-12 19:06:32 --> Model Class Initialized
INFO - 2018-02-12 19:06:32 --> Model Class Initialized
INFO - 2018-02-12 19:06:32 --> Model Class Initialized
INFO - 2018-02-12 19:06:32 --> Final output sent to browser
DEBUG - 2018-02-12 19:06:32 --> Total execution time: 0.1043
INFO - 2018-02-12 13:36:33 --> Config Class Initialized
INFO - 2018-02-12 13:36:33 --> Hooks Class Initialized
DEBUG - 2018-02-12 13:36:33 --> UTF-8 Support Enabled
INFO - 2018-02-12 13:36:33 --> Utf8 Class Initialized
INFO - 2018-02-12 13:36:33 --> URI Class Initialized
INFO - 2018-02-12 13:36:33 --> Router Class Initialized
INFO - 2018-02-12 13:36:33 --> Output Class Initialized
INFO - 2018-02-12 13:36:33 --> Security Class Initialized
DEBUG - 2018-02-12 13:36:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 13:36:33 --> Input Class Initialized
INFO - 2018-02-12 13:36:33 --> Language Class Initialized
INFO - 2018-02-12 13:36:33 --> Language Class Initialized
INFO - 2018-02-12 13:36:33 --> Config Class Initialized
INFO - 2018-02-12 13:36:33 --> Loader Class Initialized
INFO - 2018-02-12 19:06:33 --> Helper loaded: url_helper
INFO - 2018-02-12 19:06:33 --> Helper loaded: notification_helper
INFO - 2018-02-12 19:06:33 --> Helper loaded: settings_helper
INFO - 2018-02-12 19:06:33 --> Helper loaded: permission_helper
INFO - 2018-02-12 19:06:33 --> Helper loaded: users_helper
INFO - 2018-02-12 19:06:33 --> Database Driver Class Initialized
DEBUG - 2018-02-12 19:06:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 19:06:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 19:06:33 --> Helper loaded: form_helper
INFO - 2018-02-12 19:06:33 --> Form Validation Class Initialized
INFO - 2018-02-12 19:06:33 --> Controller Class Initialized
INFO - 2018-02-12 19:06:33 --> Model Class Initialized
INFO - 2018-02-12 19:06:33 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 19:06:33 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 19:06:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 19:06:33 --> Model Class Initialized
INFO - 2018-02-12 19:06:33 --> Model Class Initialized
INFO - 2018-02-12 19:06:33 --> Model Class Initialized
INFO - 2018-02-12 19:06:33 --> Model Class Initialized
INFO - 2018-02-12 19:06:33 --> Model Class Initialized
INFO - 2018-02-12 19:06:33 --> Model Class Initialized
INFO - 2018-02-12 19:06:33 --> Model Class Initialized
INFO - 2018-02-12 19:06:33 --> Model Class Initialized
INFO - 2018-02-12 19:06:33 --> Model Class Initialized
INFO - 2018-02-12 19:06:33 --> Model Class Initialized
INFO - 2018-02-12 19:06:33 --> Model Class Initialized
INFO - 2018-02-12 19:06:33 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 19:06:33 --> Model Class Initialized
INFO - 2018-02-12 19:06:33 --> Final output sent to browser
DEBUG - 2018-02-12 19:06:33 --> Total execution time: 0.1158
INFO - 2018-02-12 13:36:35 --> Config Class Initialized
INFO - 2018-02-12 13:36:35 --> Hooks Class Initialized
DEBUG - 2018-02-12 13:36:35 --> UTF-8 Support Enabled
INFO - 2018-02-12 13:36:35 --> Utf8 Class Initialized
INFO - 2018-02-12 13:36:35 --> URI Class Initialized
INFO - 2018-02-12 13:36:35 --> Router Class Initialized
INFO - 2018-02-12 13:36:35 --> Output Class Initialized
INFO - 2018-02-12 13:36:35 --> Security Class Initialized
DEBUG - 2018-02-12 13:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 13:36:35 --> Input Class Initialized
INFO - 2018-02-12 13:36:35 --> Language Class Initialized
INFO - 2018-02-12 13:36:35 --> Language Class Initialized
INFO - 2018-02-12 13:36:35 --> Config Class Initialized
INFO - 2018-02-12 13:36:35 --> Loader Class Initialized
INFO - 2018-02-12 19:06:35 --> Helper loaded: url_helper
INFO - 2018-02-12 19:06:35 --> Helper loaded: notification_helper
INFO - 2018-02-12 19:06:35 --> Helper loaded: settings_helper
INFO - 2018-02-12 19:06:35 --> Helper loaded: permission_helper
INFO - 2018-02-12 19:06:35 --> Helper loaded: users_helper
INFO - 2018-02-12 19:06:35 --> Database Driver Class Initialized
DEBUG - 2018-02-12 19:06:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 19:06:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 19:06:35 --> Helper loaded: form_helper
INFO - 2018-02-12 19:06:35 --> Form Validation Class Initialized
INFO - 2018-02-12 19:06:35 --> Controller Class Initialized
INFO - 2018-02-12 19:06:35 --> Model Class Initialized
INFO - 2018-02-12 19:06:35 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 19:06:35 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 19:06:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 19:06:35 --> Model Class Initialized
INFO - 2018-02-12 19:06:35 --> Model Class Initialized
INFO - 2018-02-12 19:06:35 --> Model Class Initialized
INFO - 2018-02-12 19:06:35 --> Model Class Initialized
INFO - 2018-02-12 19:06:35 --> Model Class Initialized
INFO - 2018-02-12 19:06:35 --> Model Class Initialized
INFO - 2018-02-12 19:06:35 --> Model Class Initialized
INFO - 2018-02-12 19:06:35 --> Model Class Initialized
INFO - 2018-02-12 19:06:35 --> Model Class Initialized
INFO - 2018-02-12 19:06:35 --> Model Class Initialized
INFO - 2018-02-12 19:06:35 --> Model Class Initialized
INFO - 2018-02-12 19:06:35 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 19:06:35 --> Model Class Initialized
INFO - 2018-02-12 19:06:35 --> Final output sent to browser
DEBUG - 2018-02-12 19:06:35 --> Total execution time: 0.1127
INFO - 2018-02-12 13:36:38 --> Config Class Initialized
INFO - 2018-02-12 13:36:38 --> Hooks Class Initialized
DEBUG - 2018-02-12 13:36:38 --> UTF-8 Support Enabled
INFO - 2018-02-12 13:36:38 --> Utf8 Class Initialized
INFO - 2018-02-12 13:36:38 --> URI Class Initialized
INFO - 2018-02-12 13:36:38 --> Router Class Initialized
INFO - 2018-02-12 13:36:38 --> Output Class Initialized
INFO - 2018-02-12 13:36:38 --> Security Class Initialized
DEBUG - 2018-02-12 13:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 13:36:38 --> Input Class Initialized
INFO - 2018-02-12 13:36:38 --> Language Class Initialized
INFO - 2018-02-12 13:36:38 --> Language Class Initialized
INFO - 2018-02-12 13:36:38 --> Config Class Initialized
INFO - 2018-02-12 13:36:38 --> Loader Class Initialized
INFO - 2018-02-12 19:06:38 --> Helper loaded: url_helper
INFO - 2018-02-12 19:06:38 --> Helper loaded: notification_helper
INFO - 2018-02-12 19:06:38 --> Helper loaded: settings_helper
INFO - 2018-02-12 19:06:38 --> Helper loaded: permission_helper
INFO - 2018-02-12 19:06:38 --> Helper loaded: users_helper
INFO - 2018-02-12 19:06:38 --> Database Driver Class Initialized
DEBUG - 2018-02-12 19:06:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 19:06:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 19:06:38 --> Helper loaded: form_helper
INFO - 2018-02-12 19:06:38 --> Form Validation Class Initialized
INFO - 2018-02-12 19:06:38 --> Controller Class Initialized
INFO - 2018-02-12 19:06:38 --> Model Class Initialized
INFO - 2018-02-12 19:06:38 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 19:06:38 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 19:06:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 19:06:38 --> Model Class Initialized
INFO - 2018-02-12 19:06:38 --> Model Class Initialized
INFO - 2018-02-12 19:06:38 --> Model Class Initialized
INFO - 2018-02-12 19:06:38 --> Model Class Initialized
INFO - 2018-02-12 19:06:38 --> Model Class Initialized
INFO - 2018-02-12 19:06:38 --> Model Class Initialized
ERROR - 2018-02-12 19:06:38 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/FilterOption.php 79
INFO - 2018-02-12 19:06:38 --> Final output sent to browser
DEBUG - 2018-02-12 19:06:38 --> Total execution time: 0.1292
INFO - 2018-02-12 13:36:38 --> Config Class Initialized
INFO - 2018-02-12 13:36:38 --> Hooks Class Initialized
DEBUG - 2018-02-12 13:36:38 --> UTF-8 Support Enabled
INFO - 2018-02-12 13:36:38 --> Utf8 Class Initialized
INFO - 2018-02-12 13:36:38 --> URI Class Initialized
INFO - 2018-02-12 13:36:38 --> Router Class Initialized
INFO - 2018-02-12 13:36:38 --> Output Class Initialized
INFO - 2018-02-12 13:36:38 --> Config Class Initialized
INFO - 2018-02-12 13:36:38 --> Hooks Class Initialized
INFO - 2018-02-12 13:36:38 --> Security Class Initialized
DEBUG - 2018-02-12 13:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 13:36:38 --> Input Class Initialized
DEBUG - 2018-02-12 13:36:38 --> UTF-8 Support Enabled
INFO - 2018-02-12 13:36:38 --> Utf8 Class Initialized
INFO - 2018-02-12 13:36:38 --> Language Class Initialized
INFO - 2018-02-12 13:36:38 --> URI Class Initialized
INFO - 2018-02-12 13:36:38 --> Router Class Initialized
INFO - 2018-02-12 13:36:38 --> Output Class Initialized
INFO - 2018-02-12 13:36:38 --> Security Class Initialized
DEBUG - 2018-02-12 13:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 13:36:38 --> Input Class Initialized
INFO - 2018-02-12 13:36:38 --> Language Class Initialized
INFO - 2018-02-12 13:36:38 --> Language Class Initialized
INFO - 2018-02-12 13:36:38 --> Config Class Initialized
INFO - 2018-02-12 13:36:38 --> Loader Class Initialized
INFO - 2018-02-12 19:06:38 --> Helper loaded: url_helper
INFO - 2018-02-12 19:06:38 --> Helper loaded: notification_helper
INFO - 2018-02-12 19:06:38 --> Helper loaded: settings_helper
INFO - 2018-02-12 19:06:38 --> Helper loaded: permission_helper
INFO - 2018-02-12 19:06:38 --> Helper loaded: users_helper
INFO - 2018-02-12 13:36:38 --> Language Class Initialized
INFO - 2018-02-12 13:36:38 --> Config Class Initialized
INFO - 2018-02-12 13:36:38 --> Loader Class Initialized
INFO - 2018-02-12 19:06:38 --> Helper loaded: url_helper
INFO - 2018-02-12 19:06:38 --> Helper loaded: notification_helper
INFO - 2018-02-12 19:06:38 --> Helper loaded: settings_helper
INFO - 2018-02-12 19:06:38 --> Database Driver Class Initialized
INFO - 2018-02-12 19:06:38 --> Helper loaded: permission_helper
INFO - 2018-02-12 19:06:38 --> Helper loaded: users_helper
INFO - 2018-02-12 13:36:38 --> Config Class Initialized
INFO - 2018-02-12 13:36:38 --> Hooks Class Initialized
DEBUG - 2018-02-12 19:06:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 19:06:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-12 13:36:38 --> UTF-8 Support Enabled
INFO - 2018-02-12 13:36:38 --> Utf8 Class Initialized
INFO - 2018-02-12 19:06:38 --> Helper loaded: form_helper
INFO - 2018-02-12 19:06:38 --> Form Validation Class Initialized
INFO - 2018-02-12 19:06:38 --> Controller Class Initialized
INFO - 2018-02-12 19:06:38 --> Database Driver Class Initialized
INFO - 2018-02-12 13:36:38 --> URI Class Initialized
DEBUG - 2018-02-12 19:06:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 19:06:38 --> Model Class Initialized
INFO - 2018-02-12 19:06:38 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 19:06:38 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 13:36:38 --> Router Class Initialized
INFO - 2018-02-12 19:06:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 19:06:38 --> Model Class Initialized
INFO - 2018-02-12 19:06:38 --> Model Class Initialized
INFO - 2018-02-12 19:06:38 --> Model Class Initialized
INFO - 2018-02-12 19:06:38 --> Model Class Initialized
INFO - 2018-02-12 19:06:38 --> Model Class Initialized
INFO - 2018-02-12 19:06:38 --> Model Class Initialized
ERROR - 2018-02-12 19:06:38 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/FilterOption.php 147
INFO - 2018-02-12 13:36:38 --> Output Class Initialized
ERROR - 2018-02-12 19:06:38 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/FilterOption.php 189
ERROR - 2018-02-12 19:06:38 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/FilterOption.php 227
INFO - 2018-02-12 19:06:38 --> Final output sent to browser
DEBUG - 2018-02-12 19:06:38 --> Total execution time: 0.1014
INFO - 2018-02-12 19:06:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 13:36:38 --> Security Class Initialized
DEBUG - 2018-02-12 13:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 13:36:38 --> Input Class Initialized
INFO - 2018-02-12 13:36:38 --> Language Class Initialized
INFO - 2018-02-12 19:06:38 --> Helper loaded: form_helper
INFO - 2018-02-12 19:06:38 --> Form Validation Class Initialized
INFO - 2018-02-12 19:06:38 --> Controller Class Initialized
INFO - 2018-02-12 19:06:38 --> Model Class Initialized
INFO - 2018-02-12 19:06:38 --> Helper loaded: inflector_helper
INFO - 2018-02-12 13:36:38 --> Language Class Initialized
INFO - 2018-02-12 13:36:38 --> Config Class Initialized
INFO - 2018-02-12 13:36:38 --> Loader Class Initialized
INFO - 2018-02-12 19:06:38 --> Helper loaded: url_helper
INFO - 2018-02-12 19:06:38 --> Helper loaded: notification_helper
INFO - 2018-02-12 19:06:38 --> Helper loaded: settings_helper
INFO - 2018-02-12 19:06:38 --> Helper loaded: permission_helper
INFO - 2018-02-12 19:06:38 --> Helper loaded: users_helper
DEBUG - 2018-02-12 19:06:38 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 19:06:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 19:06:38 --> Model Class Initialized
INFO - 2018-02-12 19:06:38 --> Model Class Initialized
INFO - 2018-02-12 19:06:38 --> Model Class Initialized
INFO - 2018-02-12 19:06:38 --> Model Class Initialized
INFO - 2018-02-12 19:06:38 --> Model Class Initialized
INFO - 2018-02-12 19:06:38 --> Model Class Initialized
ERROR - 2018-02-12 19:06:38 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/FilterOption.php 289
INFO - 2018-02-12 19:06:38 --> Final output sent to browser
DEBUG - 2018-02-12 19:06:38 --> Total execution time: 0.1253
INFO - 2018-02-12 19:06:38 --> Database Driver Class Initialized
DEBUG - 2018-02-12 19:06:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 19:06:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 19:06:38 --> Helper loaded: form_helper
INFO - 2018-02-12 19:06:38 --> Form Validation Class Initialized
INFO - 2018-02-12 19:06:38 --> Controller Class Initialized
INFO - 2018-02-12 19:06:38 --> Model Class Initialized
INFO - 2018-02-12 19:06:38 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 19:06:38 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 19:06:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 19:06:38 --> Model Class Initialized
INFO - 2018-02-12 19:06:38 --> Model Class Initialized
INFO - 2018-02-12 19:06:38 --> Model Class Initialized
INFO - 2018-02-12 19:06:38 --> Model Class Initialized
INFO - 2018-02-12 19:06:38 --> Model Class Initialized
INFO - 2018-02-12 19:06:38 --> Model Class Initialized
ERROR - 2018-02-12 19:06:38 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/FilterOption.php 349
INFO - 2018-02-12 13:36:38 --> Config Class Initialized
INFO - 2018-02-12 13:36:38 --> Hooks Class Initialized
ERROR - 2018-02-12 19:06:38 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/FilterOption.php 389
ERROR - 2018-02-12 19:06:38 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/FilterOption.php 427
INFO - 2018-02-12 19:06:38 --> Final output sent to browser
DEBUG - 2018-02-12 19:06:38 --> Total execution time: 0.1325
DEBUG - 2018-02-12 13:36:38 --> UTF-8 Support Enabled
INFO - 2018-02-12 13:36:38 --> Utf8 Class Initialized
INFO - 2018-02-12 13:36:38 --> URI Class Initialized
INFO - 2018-02-12 13:36:38 --> Router Class Initialized
INFO - 2018-02-12 13:36:38 --> Output Class Initialized
INFO - 2018-02-12 13:36:38 --> Security Class Initialized
DEBUG - 2018-02-12 13:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 13:36:38 --> Input Class Initialized
INFO - 2018-02-12 13:36:38 --> Language Class Initialized
INFO - 2018-02-12 13:36:38 --> Language Class Initialized
INFO - 2018-02-12 13:36:38 --> Config Class Initialized
INFO - 2018-02-12 13:36:38 --> Loader Class Initialized
INFO - 2018-02-12 19:06:38 --> Helper loaded: url_helper
INFO - 2018-02-12 19:06:38 --> Helper loaded: notification_helper
INFO - 2018-02-12 19:06:38 --> Helper loaded: settings_helper
INFO - 2018-02-12 19:06:38 --> Helper loaded: permission_helper
INFO - 2018-02-12 19:06:38 --> Helper loaded: users_helper
INFO - 2018-02-12 19:06:38 --> Database Driver Class Initialized
DEBUG - 2018-02-12 19:06:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 19:06:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 19:06:38 --> Helper loaded: form_helper
INFO - 2018-02-12 19:06:38 --> Form Validation Class Initialized
INFO - 2018-02-12 19:06:38 --> Controller Class Initialized
INFO - 2018-02-12 19:06:38 --> Model Class Initialized
INFO - 2018-02-12 19:06:38 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 19:06:38 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 19:06:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 19:06:38 --> Model Class Initialized
INFO - 2018-02-12 19:06:38 --> Model Class Initialized
INFO - 2018-02-12 19:06:38 --> Model Class Initialized
INFO - 2018-02-12 19:06:38 --> Model Class Initialized
INFO - 2018-02-12 19:06:38 --> Model Class Initialized
INFO - 2018-02-12 19:06:38 --> Model Class Initialized
ERROR - 2018-02-12 19:06:38 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/FilterOption.php 625
ERROR - 2018-02-12 19:06:38 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/FilterOption.php 625
INFO - 2018-02-12 19:06:38 --> Final output sent to browser
DEBUG - 2018-02-12 19:06:38 --> Total execution time: 0.1094
INFO - 2018-02-12 13:36:43 --> Config Class Initialized
INFO - 2018-02-12 13:36:43 --> Hooks Class Initialized
DEBUG - 2018-02-12 13:36:43 --> UTF-8 Support Enabled
INFO - 2018-02-12 13:36:43 --> Utf8 Class Initialized
INFO - 2018-02-12 13:36:43 --> URI Class Initialized
INFO - 2018-02-12 13:36:43 --> Router Class Initialized
INFO - 2018-02-12 13:36:43 --> Output Class Initialized
INFO - 2018-02-12 13:36:43 --> Security Class Initialized
DEBUG - 2018-02-12 13:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 13:36:43 --> Input Class Initialized
INFO - 2018-02-12 13:36:43 --> Language Class Initialized
INFO - 2018-02-12 13:36:43 --> Language Class Initialized
INFO - 2018-02-12 13:36:43 --> Config Class Initialized
INFO - 2018-02-12 13:36:43 --> Loader Class Initialized
INFO - 2018-02-12 19:06:43 --> Helper loaded: url_helper
INFO - 2018-02-12 19:06:43 --> Helper loaded: notification_helper
INFO - 2018-02-12 19:06:43 --> Helper loaded: settings_helper
INFO - 2018-02-12 19:06:43 --> Helper loaded: permission_helper
INFO - 2018-02-12 19:06:43 --> Helper loaded: users_helper
INFO - 2018-02-12 19:06:43 --> Database Driver Class Initialized
DEBUG - 2018-02-12 19:06:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 19:06:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 19:06:43 --> Helper loaded: form_helper
INFO - 2018-02-12 19:06:43 --> Form Validation Class Initialized
INFO - 2018-02-12 19:06:43 --> Controller Class Initialized
INFO - 2018-02-12 19:06:43 --> Model Class Initialized
INFO - 2018-02-12 19:06:43 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 19:06:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 19:06:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 19:06:43 --> Model Class Initialized
INFO - 2018-02-12 19:06:43 --> Model Class Initialized
INFO - 2018-02-12 19:06:43 --> Model Class Initialized
INFO - 2018-02-12 19:06:43 --> Model Class Initialized
INFO - 2018-02-12 19:06:43 --> Model Class Initialized
INFO - 2018-02-12 19:06:43 --> Model Class Initialized
INFO - 2018-02-12 19:06:43 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 19:06:43 --> Final output sent to browser
DEBUG - 2018-02-12 19:06:43 --> Total execution time: 0.1208
INFO - 2018-02-12 13:36:50 --> Config Class Initialized
INFO - 2018-02-12 13:36:50 --> Hooks Class Initialized
DEBUG - 2018-02-12 13:36:50 --> UTF-8 Support Enabled
INFO - 2018-02-12 13:36:50 --> Utf8 Class Initialized
INFO - 2018-02-12 13:36:50 --> URI Class Initialized
INFO - 2018-02-12 13:36:50 --> Router Class Initialized
INFO - 2018-02-12 13:36:50 --> Output Class Initialized
INFO - 2018-02-12 13:36:50 --> Security Class Initialized
DEBUG - 2018-02-12 13:36:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 13:36:50 --> Input Class Initialized
INFO - 2018-02-12 13:36:50 --> Language Class Initialized
INFO - 2018-02-12 13:36:50 --> Language Class Initialized
INFO - 2018-02-12 13:36:50 --> Config Class Initialized
INFO - 2018-02-12 13:36:50 --> Loader Class Initialized
INFO - 2018-02-12 19:06:50 --> Helper loaded: url_helper
INFO - 2018-02-12 19:06:50 --> Helper loaded: notification_helper
INFO - 2018-02-12 19:06:50 --> Helper loaded: settings_helper
INFO - 2018-02-12 19:06:50 --> Helper loaded: permission_helper
INFO - 2018-02-12 19:06:50 --> Helper loaded: users_helper
INFO - 2018-02-12 19:06:50 --> Database Driver Class Initialized
DEBUG - 2018-02-12 19:06:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 19:06:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 19:06:50 --> Helper loaded: form_helper
INFO - 2018-02-12 19:06:50 --> Form Validation Class Initialized
INFO - 2018-02-12 19:06:50 --> Controller Class Initialized
INFO - 2018-02-12 19:06:50 --> Model Class Initialized
INFO - 2018-02-12 19:06:50 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 19:06:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 19:06:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 19:06:50 --> Model Class Initialized
INFO - 2018-02-12 19:06:50 --> Model Class Initialized
INFO - 2018-02-12 19:06:50 --> Model Class Initialized
INFO - 2018-02-12 19:06:50 --> Model Class Initialized
INFO - 2018-02-12 19:06:50 --> Model Class Initialized
INFO - 2018-02-12 19:06:50 --> Model Class Initialized
INFO - 2018-02-12 19:06:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 19:06:50 --> Final output sent to browser
DEBUG - 2018-02-12 19:06:50 --> Total execution time: 0.1081
INFO - 2018-02-12 13:36:53 --> Config Class Initialized
INFO - 2018-02-12 13:36:53 --> Hooks Class Initialized
DEBUG - 2018-02-12 13:36:53 --> UTF-8 Support Enabled
INFO - 2018-02-12 13:36:53 --> Utf8 Class Initialized
INFO - 2018-02-12 13:36:53 --> URI Class Initialized
INFO - 2018-02-12 13:36:53 --> Router Class Initialized
INFO - 2018-02-12 13:36:53 --> Output Class Initialized
INFO - 2018-02-12 13:36:53 --> Security Class Initialized
DEBUG - 2018-02-12 13:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 13:36:53 --> Input Class Initialized
INFO - 2018-02-12 13:36:53 --> Language Class Initialized
INFO - 2018-02-12 13:36:53 --> Language Class Initialized
INFO - 2018-02-12 13:36:53 --> Config Class Initialized
INFO - 2018-02-12 13:36:53 --> Loader Class Initialized
INFO - 2018-02-12 19:06:53 --> Helper loaded: url_helper
INFO - 2018-02-12 19:06:53 --> Helper loaded: notification_helper
INFO - 2018-02-12 19:06:53 --> Helper loaded: settings_helper
INFO - 2018-02-12 19:06:53 --> Helper loaded: permission_helper
INFO - 2018-02-12 19:06:53 --> Helper loaded: users_helper
INFO - 2018-02-12 19:06:53 --> Database Driver Class Initialized
DEBUG - 2018-02-12 19:06:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 19:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 19:06:53 --> Helper loaded: form_helper
INFO - 2018-02-12 19:06:53 --> Form Validation Class Initialized
INFO - 2018-02-12 19:06:53 --> Controller Class Initialized
INFO - 2018-02-12 19:06:53 --> Model Class Initialized
INFO - 2018-02-12 19:06:53 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 19:06:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 19:06:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 19:06:53 --> Model Class Initialized
INFO - 2018-02-12 19:06:53 --> Model Class Initialized
INFO - 2018-02-12 19:06:53 --> Model Class Initialized
INFO - 2018-02-12 19:06:53 --> Model Class Initialized
INFO - 2018-02-12 19:06:53 --> Model Class Initialized
INFO - 2018-02-12 19:06:53 --> Model Class Initialized
INFO - 2018-02-12 19:06:53 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 19:06:53 --> Final output sent to browser
DEBUG - 2018-02-12 19:06:53 --> Total execution time: 0.1125
INFO - 2018-02-12 13:36:54 --> Config Class Initialized
INFO - 2018-02-12 13:36:54 --> Hooks Class Initialized
DEBUG - 2018-02-12 13:36:54 --> UTF-8 Support Enabled
INFO - 2018-02-12 13:36:54 --> Utf8 Class Initialized
INFO - 2018-02-12 13:36:54 --> URI Class Initialized
INFO - 2018-02-12 13:36:54 --> Router Class Initialized
INFO - 2018-02-12 13:36:54 --> Output Class Initialized
INFO - 2018-02-12 13:36:54 --> Security Class Initialized
DEBUG - 2018-02-12 13:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 13:36:54 --> Input Class Initialized
INFO - 2018-02-12 13:36:54 --> Language Class Initialized
INFO - 2018-02-12 13:36:54 --> Language Class Initialized
INFO - 2018-02-12 13:36:54 --> Config Class Initialized
INFO - 2018-02-12 13:36:54 --> Loader Class Initialized
INFO - 2018-02-12 19:06:54 --> Helper loaded: url_helper
INFO - 2018-02-12 19:06:54 --> Helper loaded: notification_helper
INFO - 2018-02-12 19:06:54 --> Helper loaded: settings_helper
INFO - 2018-02-12 19:06:54 --> Helper loaded: permission_helper
INFO - 2018-02-12 19:06:54 --> Helper loaded: users_helper
INFO - 2018-02-12 19:06:54 --> Database Driver Class Initialized
DEBUG - 2018-02-12 19:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 19:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 19:06:54 --> Helper loaded: form_helper
INFO - 2018-02-12 19:06:54 --> Form Validation Class Initialized
INFO - 2018-02-12 19:06:54 --> Controller Class Initialized
INFO - 2018-02-12 19:06:54 --> Model Class Initialized
INFO - 2018-02-12 19:06:54 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 19:06:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 19:06:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 19:06:54 --> Model Class Initialized
INFO - 2018-02-12 19:06:54 --> Model Class Initialized
INFO - 2018-02-12 19:06:54 --> Model Class Initialized
INFO - 2018-02-12 19:06:54 --> Model Class Initialized
INFO - 2018-02-12 19:06:54 --> Model Class Initialized
INFO - 2018-02-12 19:06:54 --> Model Class Initialized
INFO - 2018-02-12 19:06:54 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 19:06:54 --> Final output sent to browser
DEBUG - 2018-02-12 19:06:54 --> Total execution time: 0.1197
INFO - 2018-02-12 13:37:09 --> Config Class Initialized
INFO - 2018-02-12 13:37:09 --> Hooks Class Initialized
DEBUG - 2018-02-12 13:37:09 --> UTF-8 Support Enabled
INFO - 2018-02-12 13:37:09 --> Utf8 Class Initialized
INFO - 2018-02-12 13:37:09 --> URI Class Initialized
INFO - 2018-02-12 13:37:09 --> Router Class Initialized
INFO - 2018-02-12 13:37:09 --> Output Class Initialized
INFO - 2018-02-12 13:37:09 --> Security Class Initialized
DEBUG - 2018-02-12 13:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-12 13:37:09 --> Input Class Initialized
INFO - 2018-02-12 13:37:09 --> Language Class Initialized
INFO - 2018-02-12 13:37:09 --> Language Class Initialized
INFO - 2018-02-12 13:37:09 --> Config Class Initialized
INFO - 2018-02-12 13:37:09 --> Loader Class Initialized
INFO - 2018-02-12 19:07:09 --> Helper loaded: url_helper
INFO - 2018-02-12 19:07:09 --> Helper loaded: notification_helper
INFO - 2018-02-12 19:07:09 --> Helper loaded: settings_helper
INFO - 2018-02-12 19:07:09 --> Helper loaded: permission_helper
INFO - 2018-02-12 19:07:09 --> Helper loaded: users_helper
INFO - 2018-02-12 19:07:09 --> Database Driver Class Initialized
DEBUG - 2018-02-12 19:07:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-12 19:07:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-12 19:07:09 --> Helper loaded: form_helper
INFO - 2018-02-12 19:07:09 --> Form Validation Class Initialized
INFO - 2018-02-12 19:07:09 --> Controller Class Initialized
INFO - 2018-02-12 19:07:09 --> Model Class Initialized
INFO - 2018-02-12 19:07:09 --> Helper loaded: inflector_helper
DEBUG - 2018-02-12 19:07:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-12 19:07:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-12 19:07:09 --> Model Class Initialized
INFO - 2018-02-12 19:07:09 --> Model Class Initialized
INFO - 2018-02-12 19:07:09 --> Model Class Initialized
INFO - 2018-02-12 19:07:09 --> Model Class Initialized
INFO - 2018-02-12 19:07:09 --> Model Class Initialized
INFO - 2018-02-12 19:07:09 --> Model Class Initialized
INFO - 2018-02-12 19:07:09 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-12 19:07:09 --> Final output sent to browser
DEBUG - 2018-02-12 19:07:09 --> Total execution time: 0.1148
