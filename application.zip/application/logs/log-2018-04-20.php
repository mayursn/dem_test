<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-04-20 11:34:43 --> Config Class Initialized
INFO - 2018-04-20 11:34:43 --> Config Class Initialized
INFO - 2018-04-20 11:34:43 --> Config Class Initialized
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-04-20 11:34:43 --> Config Class Initialized
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-04-20 11:34:43 --> Config Class Initialized
INFO - 2018-04-20 11:34:43 --> Hooks Class Initialized
INFO - 2018-04-20 11:34:43 --> Hooks Class Initialized
INFO - 2018-04-20 11:34:43 --> Hooks Class Initialized
INFO - 2018-04-20 11:34:43 --> Hooks Class Initialized
INFO - 2018-04-20 11:34:43 --> Hooks Class Initialized
DEBUG - 2018-04-20 11:34:43 --> UTF-8 Support Enabled
DEBUG - 2018-04-20 11:34:43 --> UTF-8 Support Enabled
DEBUG - 2018-04-20 11:34:43 --> UTF-8 Support Enabled
INFO - 2018-04-20 11:34:43 --> Utf8 Class Initialized
INFO - 2018-04-20 11:34:43 --> Utf8 Class Initialized
DEBUG - 2018-04-20 11:34:43 --> UTF-8 Support Enabled
INFO - 2018-04-20 11:34:43 --> Utf8 Class Initialized
INFO - 2018-04-20 11:34:43 --> Utf8 Class Initialized
DEBUG - 2018-04-20 11:34:43 --> UTF-8 Support Enabled
INFO - 2018-04-20 11:34:43 --> Utf8 Class Initialized
INFO - 2018-04-20 11:34:43 --> URI Class Initialized
INFO - 2018-04-20 11:34:43 --> URI Class Initialized
INFO - 2018-04-20 11:34:43 --> URI Class Initialized
INFO - 2018-04-20 11:34:43 --> URI Class Initialized
INFO - 2018-04-20 11:34:43 --> URI Class Initialized
INFO - 2018-04-20 11:34:43 --> Router Class Initialized
INFO - 2018-04-20 11:34:43 --> Router Class Initialized
INFO - 2018-04-20 11:34:43 --> Router Class Initialized
INFO - 2018-04-20 11:34:43 --> Router Class Initialized
INFO - 2018-04-20 11:34:43 --> Router Class Initialized
INFO - 2018-04-20 11:34:43 --> Output Class Initialized
INFO - 2018-04-20 11:34:43 --> Output Class Initialized
INFO - 2018-04-20 11:34:43 --> Output Class Initialized
INFO - 2018-04-20 11:34:43 --> Output Class Initialized
INFO - 2018-04-20 11:34:43 --> Output Class Initialized
INFO - 2018-04-20 11:34:43 --> Security Class Initialized
INFO - 2018-04-20 11:34:43 --> Security Class Initialized
INFO - 2018-04-20 11:34:43 --> Security Class Initialized
INFO - 2018-04-20 11:34:43 --> Security Class Initialized
INFO - 2018-04-20 11:34:43 --> Security Class Initialized
DEBUG - 2018-04-20 11:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 11:34:43 --> Input Class Initialized
DEBUG - 2018-04-20 11:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 11:34:43 --> Input Class Initialized
DEBUG - 2018-04-20 11:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 11:34:43 --> Input Class Initialized
DEBUG - 2018-04-20 11:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 11:34:43 --> Input Class Initialized
DEBUG - 2018-04-20 11:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 11:34:43 --> Input Class Initialized
INFO - 2018-04-20 11:34:43 --> Language Class Initialized
INFO - 2018-04-20 11:34:43 --> Language Class Initialized
INFO - 2018-04-20 11:34:43 --> Language Class Initialized
INFO - 2018-04-20 11:34:43 --> Language Class Initialized
INFO - 2018-04-20 11:34:43 --> Language Class Initialized
INFO - 2018-04-20 11:34:43 --> Language Class Initialized
INFO - 2018-04-20 11:34:43 --> Language Class Initialized
INFO - 2018-04-20 11:34:43 --> Config Class Initialized
INFO - 2018-04-20 11:34:43 --> Config Class Initialized
INFO - 2018-04-20 11:34:43 --> Loader Class Initialized
INFO - 2018-04-20 11:34:43 --> Loader Class Initialized
INFO - 2018-04-20 11:34:43 --> Language Class Initialized
INFO - 2018-04-20 11:34:43 --> Config Class Initialized
INFO - 2018-04-20 11:34:43 --> Loader Class Initialized
INFO - 2018-04-20 11:34:43 --> Language Class Initialized
INFO - 2018-04-20 11:34:43 --> Config Class Initialized
INFO - 2018-04-20 11:34:43 --> Loader Class Initialized
INFO - 2018-04-20 11:34:43 --> Language Class Initialized
INFO - 2018-04-20 11:34:43 --> Config Class Initialized
INFO - 2018-04-20 11:34:43 --> Loader Class Initialized
INFO - 2018-04-20 17:04:43 --> Helper loaded: url_helper
INFO - 2018-04-20 17:04:43 --> Helper loaded: url_helper
INFO - 2018-04-20 17:04:43 --> Helper loaded: url_helper
INFO - 2018-04-20 17:04:43 --> Helper loaded: url_helper
INFO - 2018-04-20 17:04:43 --> Helper loaded: url_helper
INFO - 2018-04-20 17:04:43 --> Helper loaded: notification_helper
INFO - 2018-04-20 17:04:43 --> Helper loaded: notification_helper
INFO - 2018-04-20 17:04:43 --> Helper loaded: notification_helper
INFO - 2018-04-20 17:04:43 --> Helper loaded: notification_helper
INFO - 2018-04-20 17:04:43 --> Helper loaded: notification_helper
INFO - 2018-04-20 17:04:43 --> Helper loaded: settings_helper
INFO - 2018-04-20 17:04:43 --> Helper loaded: settings_helper
INFO - 2018-04-20 17:04:43 --> Helper loaded: settings_helper
INFO - 2018-04-20 17:04:43 --> Helper loaded: settings_helper
INFO - 2018-04-20 17:04:43 --> Helper loaded: settings_helper
INFO - 2018-04-20 17:04:43 --> Helper loaded: permission_helper
INFO - 2018-04-20 17:04:43 --> Helper loaded: permission_helper
INFO - 2018-04-20 17:04:43 --> Helper loaded: permission_helper
INFO - 2018-04-20 17:04:43 --> Helper loaded: permission_helper
INFO - 2018-04-20 17:04:43 --> Helper loaded: permission_helper
INFO - 2018-04-20 17:04:43 --> Helper loaded: users_helper
INFO - 2018-04-20 17:04:43 --> Helper loaded: users_helper
INFO - 2018-04-20 17:04:43 --> Helper loaded: users_helper
INFO - 2018-04-20 17:04:43 --> Helper loaded: users_helper
INFO - 2018-04-20 17:04:43 --> Helper loaded: users_helper
INFO - 2018-04-20 17:04:43 --> Database Driver Class Initialized
INFO - 2018-04-20 17:04:43 --> Database Driver Class Initialized
INFO - 2018-04-20 17:04:43 --> Database Driver Class Initialized
INFO - 2018-04-20 17:04:43 --> Database Driver Class Initialized
INFO - 2018-04-20 17:04:43 --> Database Driver Class Initialized
DEBUG - 2018-04-20 17:04:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 17:04:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-04-20 17:04:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-04-20 17:04:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 17:04:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 17:04:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-04-20 17:04:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-04-20 17:04:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 17:04:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 17:04:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 17:04:43 --> Helper loaded: form_helper
INFO - 2018-04-20 17:04:43 --> Form Validation Class Initialized
INFO - 2018-04-20 17:04:43 --> Controller Class Initialized
INFO - 2018-04-20 17:04:43 --> Helper loaded: form_helper
INFO - 2018-04-20 17:04:43 --> Helper loaded: form_helper
INFO - 2018-04-20 17:04:43 --> Form Validation Class Initialized
INFO - 2018-04-20 17:04:43 --> Form Validation Class Initialized
INFO - 2018-04-20 17:04:43 --> Controller Class Initialized
INFO - 2018-04-20 17:04:43 --> Controller Class Initialized
INFO - 2018-04-20 17:04:43 --> Helper loaded: form_helper
INFO - 2018-04-20 17:04:43 --> Form Validation Class Initialized
INFO - 2018-04-20 17:04:43 --> Controller Class Initialized
INFO - 2018-04-20 17:04:43 --> Helper loaded: form_helper
INFO - 2018-04-20 17:04:43 --> Form Validation Class Initialized
INFO - 2018-04-20 17:04:43 --> Controller Class Initialized
INFO - 2018-04-20 17:04:43 --> Model Class Initialized
INFO - 2018-04-20 17:04:43 --> Model Class Initialized
INFO - 2018-04-20 17:04:43 --> Helper loaded: inflector_helper
INFO - 2018-04-20 17:04:43 --> Model Class Initialized
INFO - 2018-04-20 17:04:43 --> Helper loaded: inflector_helper
INFO - 2018-04-20 17:04:43 --> Helper loaded: inflector_helper
INFO - 2018-04-20 17:04:43 --> Model Class Initialized
INFO - 2018-04-20 17:04:43 --> Helper loaded: inflector_helper
INFO - 2018-04-20 17:04:43 --> Model Class Initialized
INFO - 2018-04-20 17:04:43 --> Helper loaded: inflector_helper
DEBUG - 2018-04-20 17:04:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-04-20 17:04:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-04-20 17:04:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-04-20 17:04:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-04-20 17:04:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-20 17:04:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-20 17:04:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-20 17:04:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-20 17:04:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-20 17:04:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-20 17:04:43 --> Model Class Initialized
INFO - 2018-04-20 17:04:43 --> Model Class Initialized
INFO - 2018-04-20 17:04:43 --> Model Class Initialized
INFO - 2018-04-20 17:04:43 --> Model Class Initialized
INFO - 2018-04-20 17:04:43 --> Model Class Initialized
INFO - 2018-04-20 17:04:43 --> Model Class Initialized
INFO - 2018-04-20 17:04:43 --> Model Class Initialized
INFO - 2018-04-20 17:04:43 --> Model Class Initialized
INFO - 2018-04-20 17:04:43 --> Model Class Initialized
INFO - 2018-04-20 17:04:43 --> Model Class Initialized
INFO - 2018-04-20 17:04:43 --> Model Class Initialized
INFO - 2018-04-20 17:04:43 --> Model Class Initialized
INFO - 2018-04-20 17:04:43 --> Model Class Initialized
INFO - 2018-04-20 17:04:43 --> Model Class Initialized
INFO - 2018-04-20 17:04:43 --> Model Class Initialized
INFO - 2018-04-20 17:04:43 --> Model Class Initialized
INFO - 2018-04-20 17:04:43 --> Model Class Initialized
INFO - 2018-04-20 17:04:43 --> Model Class Initialized
INFO - 2018-04-20 17:04:43 --> Model Class Initialized
INFO - 2018-04-20 17:04:43 --> Model Class Initialized
INFO - 2018-04-20 17:04:43 --> Model Class Initialized
INFO - 2018-04-20 17:04:43 --> Model Class Initialized
INFO - 2018-04-20 17:04:43 --> Model Class Initialized
INFO - 2018-04-20 17:04:43 --> Model Class Initialized
INFO - 2018-04-20 17:04:43 --> Model Class Initialized
INFO - 2018-04-20 17:04:43 --> Model Class Initialized
INFO - 2018-04-20 17:04:43 --> Model Class Initialized
INFO - 2018-04-20 17:04:43 --> Model Class Initialized
INFO - 2018-04-20 17:04:43 --> Model Class Initialized
INFO - 2018-04-20 17:04:43 --> Model Class Initialized
INFO - 2018-04-20 17:04:43 --> Model Class Initialized
INFO - 2018-04-20 17:04:43 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-20 17:04:43 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-20 17:04:43 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-20 17:04:43 --> Model Class Initialized
INFO - 2018-04-20 17:04:43 --> Model Class Initialized
INFO - 2018-04-20 17:04:43 --> Model Class Initialized
INFO - 2018-04-20 17:04:43 --> Model Class Initialized
INFO - 2018-04-20 17:04:43 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-20 17:04:43 --> Model Class Initialized
INFO - 2018-04-20 17:04:43 --> Model Class Initialized
INFO - 2018-04-20 17:04:43 --> Model Class Initialized
INFO - 2018-04-20 17:04:43 --> Model Class Initialized
INFO - 2018-04-20 17:04:43 --> Model Class Initialized
INFO - 2018-04-20 17:04:43 --> Model Class Initialized
INFO - 2018-04-20 17:04:43 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-20 17:04:43 --> Model Class Initialized
INFO - 2018-04-20 17:04:43 --> Model Class Initialized
INFO - 2018-04-20 17:04:43 --> Model Class Initialized
INFO - 2018-04-20 17:04:43 --> Final output sent to browser
DEBUG - 2018-04-20 17:04:43 --> Total execution time: 0.4082
INFO - 2018-04-20 17:04:43 --> Final output sent to browser
DEBUG - 2018-04-20 17:04:43 --> Total execution time: 0.4085
INFO - 2018-04-20 17:04:43 --> Final output sent to browser
DEBUG - 2018-04-20 17:04:43 --> Total execution time: 0.4083
INFO - 2018-04-20 17:04:43 --> Final output sent to browser
DEBUG - 2018-04-20 17:04:43 --> Total execution time: 0.4565
INFO - 2018-04-20 17:04:43 --> Final output sent to browser
DEBUG - 2018-04-20 17:04:43 --> Total execution time: 0.4568
INFO - 2018-04-20 11:34:45 --> Config Class Initialized
INFO - 2018-04-20 11:34:45 --> Hooks Class Initialized
INFO - 2018-04-20 11:34:45 --> Config Class Initialized
DEBUG - 2018-04-20 11:34:45 --> UTF-8 Support Enabled
INFO - 2018-04-20 11:34:45 --> Hooks Class Initialized
INFO - 2018-04-20 11:34:45 --> Utf8 Class Initialized
INFO - 2018-04-20 11:34:45 --> URI Class Initialized
DEBUG - 2018-04-20 11:34:45 --> UTF-8 Support Enabled
INFO - 2018-04-20 11:34:45 --> Utf8 Class Initialized
INFO - 2018-04-20 11:34:45 --> URI Class Initialized
INFO - 2018-04-20 11:34:45 --> Router Class Initialized
INFO - 2018-04-20 11:34:45 --> Output Class Initialized
INFO - 2018-04-20 11:34:45 --> Router Class Initialized
INFO - 2018-04-20 11:34:45 --> Security Class Initialized
INFO - 2018-04-20 11:34:45 --> Output Class Initialized
DEBUG - 2018-04-20 11:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 11:34:45 --> Input Class Initialized
INFO - 2018-04-20 11:34:45 --> Language Class Initialized
INFO - 2018-04-20 11:34:45 --> Security Class Initialized
DEBUG - 2018-04-20 11:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 11:34:45 --> Input Class Initialized
INFO - 2018-04-20 11:34:45 --> Language Class Initialized
INFO - 2018-04-20 11:34:45 --> Config Class Initialized
INFO - 2018-04-20 11:34:45 --> Hooks Class Initialized
DEBUG - 2018-04-20 11:34:45 --> UTF-8 Support Enabled
INFO - 2018-04-20 11:34:45 --> Utf8 Class Initialized
INFO - 2018-04-20 11:34:45 --> URI Class Initialized
INFO - 2018-04-20 11:34:45 --> Language Class Initialized
INFO - 2018-04-20 11:34:45 --> Config Class Initialized
INFO - 2018-04-20 11:34:45 --> Loader Class Initialized
INFO - 2018-04-20 17:04:45 --> Helper loaded: url_helper
INFO - 2018-04-20 17:04:45 --> Helper loaded: notification_helper
INFO - 2018-04-20 11:34:45 --> Router Class Initialized
INFO - 2018-04-20 17:04:45 --> Helper loaded: settings_helper
INFO - 2018-04-20 11:34:45 --> Language Class Initialized
INFO - 2018-04-20 11:34:45 --> Config Class Initialized
INFO - 2018-04-20 11:34:45 --> Loader Class Initialized
INFO - 2018-04-20 17:04:45 --> Helper loaded: permission_helper
INFO - 2018-04-20 17:04:45 --> Helper loaded: users_helper
INFO - 2018-04-20 17:04:45 --> Helper loaded: url_helper
INFO - 2018-04-20 11:34:45 --> Output Class Initialized
INFO - 2018-04-20 17:04:45 --> Helper loaded: notification_helper
INFO - 2018-04-20 17:04:45 --> Helper loaded: settings_helper
INFO - 2018-04-20 17:04:45 --> Helper loaded: permission_helper
INFO - 2018-04-20 11:34:45 --> Security Class Initialized
INFO - 2018-04-20 17:04:45 --> Helper loaded: users_helper
DEBUG - 2018-04-20 11:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 11:34:45 --> Input Class Initialized
INFO - 2018-04-20 11:34:45 --> Language Class Initialized
INFO - 2018-04-20 17:04:45 --> Database Driver Class Initialized
INFO - 2018-04-20 17:04:45 --> Database Driver Class Initialized
DEBUG - 2018-04-20 17:04:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 17:04:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-04-20 17:04:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 17:04:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 17:04:45 --> Helper loaded: form_helper
INFO - 2018-04-20 17:04:45 --> Form Validation Class Initialized
INFO - 2018-04-20 17:04:45 --> Controller Class Initialized
INFO - 2018-04-20 17:04:45 --> Helper loaded: form_helper
INFO - 2018-04-20 17:04:45 --> Form Validation Class Initialized
INFO - 2018-04-20 17:04:45 --> Controller Class Initialized
INFO - 2018-04-20 17:04:45 --> Model Class Initialized
INFO - 2018-04-20 17:04:45 --> Helper loaded: inflector_helper
INFO - 2018-04-20 11:34:45 --> Language Class Initialized
INFO - 2018-04-20 11:34:45 --> Config Class Initialized
INFO - 2018-04-20 11:34:45 --> Loader Class Initialized
DEBUG - 2018-04-20 17:04:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-20 17:04:45 --> Helper loaded: url_helper
INFO - 2018-04-20 17:04:45 --> Helper loaded: notification_helper
INFO - 2018-04-20 17:04:45 --> Helper loaded: settings_helper
INFO - 2018-04-20 17:04:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-20 17:04:45 --> Model Class Initialized
INFO - 2018-04-20 17:04:45 --> Helper loaded: permission_helper
INFO - 2018-04-20 17:04:45 --> Model Class Initialized
INFO - 2018-04-20 17:04:45 --> Helper loaded: inflector_helper
INFO - 2018-04-20 17:04:45 --> Model Class Initialized
INFO - 2018-04-20 17:04:45 --> Helper loaded: users_helper
INFO - 2018-04-20 17:04:45 --> Model Class Initialized
INFO - 2018-04-20 17:04:45 --> Model Class Initialized
INFO - 2018-04-20 17:04:45 --> Model Class Initialized
INFO - 2018-04-20 17:04:45 --> Model Class Initialized
INFO - 2018-04-20 17:04:45 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-04-20 17:04:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-20 17:04:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-20 17:04:45 --> Model Class Initialized
INFO - 2018-04-20 17:04:45 --> Model Class Initialized
INFO - 2018-04-20 17:04:45 --> Model Class Initialized
INFO - 2018-04-20 17:04:45 --> Model Class Initialized
INFO - 2018-04-20 17:04:45 --> Model Class Initialized
INFO - 2018-04-20 17:04:45 --> Model Class Initialized
INFO - 2018-04-20 17:04:45 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-20 17:04:45 --> Database Driver Class Initialized
DEBUG - 2018-04-20 17:04:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 17:04:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 17:04:45 --> Helper loaded: form_helper
INFO - 2018-04-20 17:04:45 --> Form Validation Class Initialized
INFO - 2018-04-20 17:04:45 --> Controller Class Initialized
INFO - 2018-04-20 17:04:45 --> Model Class Initialized
INFO - 2018-04-20 17:04:45 --> Helper loaded: inflector_helper
INFO - 2018-04-20 17:04:45 --> Final output sent to browser
DEBUG - 2018-04-20 17:04:45 --> Total execution time: 0.1621
DEBUG - 2018-04-20 17:04:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-20 17:04:45 --> Final output sent to browser
DEBUG - 2018-04-20 17:04:45 --> Total execution time: 0.1609
INFO - 2018-04-20 17:04:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-20 17:04:45 --> Model Class Initialized
INFO - 2018-04-20 17:04:45 --> Model Class Initialized
INFO - 2018-04-20 17:04:45 --> Model Class Initialized
INFO - 2018-04-20 17:04:45 --> Model Class Initialized
INFO - 2018-04-20 17:04:45 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-20 17:04:45 --> Final output sent to browser
DEBUG - 2018-04-20 17:04:45 --> Total execution time: 0.2573
INFO - 2018-04-20 11:34:50 --> Config Class Initialized
INFO - 2018-04-20 11:34:50 --> Hooks Class Initialized
DEBUG - 2018-04-20 11:34:50 --> UTF-8 Support Enabled
INFO - 2018-04-20 11:34:50 --> Utf8 Class Initialized
INFO - 2018-04-20 11:34:50 --> URI Class Initialized
INFO - 2018-04-20 11:34:50 --> Router Class Initialized
INFO - 2018-04-20 11:34:50 --> Output Class Initialized
INFO - 2018-04-20 11:34:50 --> Security Class Initialized
DEBUG - 2018-04-20 11:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 11:34:50 --> Input Class Initialized
INFO - 2018-04-20 11:34:50 --> Language Class Initialized
INFO - 2018-04-20 11:34:50 --> Config Class Initialized
INFO - 2018-04-20 11:34:50 --> Hooks Class Initialized
DEBUG - 2018-04-20 11:34:50 --> UTF-8 Support Enabled
INFO - 2018-04-20 11:34:50 --> Utf8 Class Initialized
INFO - 2018-04-20 11:34:50 --> URI Class Initialized
INFO - 2018-04-20 11:34:50 --> Router Class Initialized
INFO - 2018-04-20 11:34:50 --> Output Class Initialized
INFO - 2018-04-20 11:34:50 --> Security Class Initialized
DEBUG - 2018-04-20 11:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 11:34:50 --> Input Class Initialized
INFO - 2018-04-20 11:34:50 --> Language Class Initialized
INFO - 2018-04-20 11:34:50 --> Language Class Initialized
INFO - 2018-04-20 11:34:50 --> Config Class Initialized
INFO - 2018-04-20 11:34:50 --> Loader Class Initialized
INFO - 2018-04-20 17:04:50 --> Helper loaded: url_helper
INFO - 2018-04-20 17:04:50 --> Helper loaded: notification_helper
INFO - 2018-04-20 17:04:50 --> Helper loaded: settings_helper
INFO - 2018-04-20 17:04:50 --> Helper loaded: permission_helper
INFO - 2018-04-20 17:04:50 --> Helper loaded: users_helper
INFO - 2018-04-20 17:04:50 --> Database Driver Class Initialized
INFO - 2018-04-20 11:34:50 --> Language Class Initialized
INFO - 2018-04-20 11:34:50 --> Config Class Initialized
INFO - 2018-04-20 11:34:50 --> Loader Class Initialized
INFO - 2018-04-20 17:04:50 --> Helper loaded: url_helper
DEBUG - 2018-04-20 17:04:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 17:04:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 17:04:50 --> Helper loaded: notification_helper
INFO - 2018-04-20 17:04:50 --> Helper loaded: settings_helper
INFO - 2018-04-20 17:04:50 --> Helper loaded: permission_helper
INFO - 2018-04-20 17:04:50 --> Helper loaded: users_helper
INFO - 2018-04-20 17:04:50 --> Helper loaded: form_helper
INFO - 2018-04-20 17:04:50 --> Form Validation Class Initialized
INFO - 2018-04-20 17:04:50 --> Controller Class Initialized
INFO - 2018-04-20 17:04:50 --> Database Driver Class Initialized
INFO - 2018-04-20 17:04:50 --> Model Class Initialized
INFO - 2018-04-20 17:04:50 --> Helper loaded: inflector_helper
DEBUG - 2018-04-20 17:04:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 17:04:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-04-20 17:04:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-20 17:04:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-20 17:04:50 --> Model Class Initialized
INFO - 2018-04-20 17:04:50 --> Model Class Initialized
INFO - 2018-04-20 17:04:50 --> Model Class Initialized
INFO - 2018-04-20 17:04:50 --> Model Class Initialized
INFO - 2018-04-20 17:04:50 --> Model Class Initialized
INFO - 2018-04-20 17:04:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-20 17:04:50 --> Helper loaded: form_helper
INFO - 2018-04-20 17:04:50 --> Form Validation Class Initialized
INFO - 2018-04-20 17:04:50 --> Controller Class Initialized
INFO - 2018-04-20 17:04:50 --> Model Class Initialized
INFO - 2018-04-20 17:04:50 --> Model Class Initialized
INFO - 2018-04-20 17:04:50 --> Helper loaded: inflector_helper
DEBUG - 2018-04-20 17:04:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-20 17:04:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-20 17:04:50 --> Final output sent to browser
DEBUG - 2018-04-20 17:04:50 --> Total execution time: 0.1358
INFO - 2018-04-20 17:04:50 --> Model Class Initialized
INFO - 2018-04-20 17:04:50 --> Model Class Initialized
INFO - 2018-04-20 17:04:50 --> Model Class Initialized
INFO - 2018-04-20 17:04:50 --> Model Class Initialized
INFO - 2018-04-20 17:04:50 --> Model Class Initialized
INFO - 2018-04-20 17:04:50 --> Model Class Initialized
INFO - 2018-04-20 17:04:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-20 17:04:50 --> Final output sent to browser
DEBUG - 2018-04-20 17:04:50 --> Total execution time: 0.1206
INFO - 2018-04-20 11:35:14 --> Config Class Initialized
INFO - 2018-04-20 11:35:14 --> Hooks Class Initialized
DEBUG - 2018-04-20 11:35:14 --> UTF-8 Support Enabled
INFO - 2018-04-20 11:35:14 --> Utf8 Class Initialized
INFO - 2018-04-20 11:35:14 --> URI Class Initialized
INFO - 2018-04-20 11:35:14 --> Router Class Initialized
INFO - 2018-04-20 11:35:14 --> Output Class Initialized
INFO - 2018-04-20 11:35:14 --> Security Class Initialized
DEBUG - 2018-04-20 11:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 11:35:14 --> Input Class Initialized
INFO - 2018-04-20 11:35:14 --> Language Class Initialized
INFO - 2018-04-20 11:35:14 --> Language Class Initialized
INFO - 2018-04-20 11:35:14 --> Config Class Initialized
INFO - 2018-04-20 11:35:14 --> Loader Class Initialized
INFO - 2018-04-20 17:05:14 --> Helper loaded: url_helper
INFO - 2018-04-20 17:05:14 --> Helper loaded: notification_helper
INFO - 2018-04-20 17:05:14 --> Helper loaded: settings_helper
INFO - 2018-04-20 17:05:14 --> Helper loaded: permission_helper
INFO - 2018-04-20 17:05:14 --> Helper loaded: users_helper
INFO - 2018-04-20 17:05:14 --> Database Driver Class Initialized
DEBUG - 2018-04-20 17:05:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 17:05:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 17:05:14 --> Helper loaded: form_helper
INFO - 2018-04-20 17:05:14 --> Form Validation Class Initialized
INFO - 2018-04-20 17:05:14 --> Controller Class Initialized
INFO - 2018-04-20 17:05:14 --> Model Class Initialized
INFO - 2018-04-20 17:05:14 --> Helper loaded: inflector_helper
DEBUG - 2018-04-20 17:05:14 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-20 17:05:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-20 17:05:14 --> Model Class Initialized
INFO - 2018-04-20 17:05:14 --> Model Class Initialized
INFO - 2018-04-20 17:05:14 --> Model Class Initialized
INFO - 2018-04-20 17:05:14 --> Model Class Initialized
INFO - 2018-04-20 17:05:14 --> Model Class Initialized
INFO - 2018-04-20 17:05:14 --> Model Class Initialized
INFO - 2018-04-20 17:05:14 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-20 17:05:14 --> Upload Class Initialized
INFO - 2018-04-20 17:05:14 --> Final output sent to browser
DEBUG - 2018-04-20 17:05:14 --> Total execution time: 0.1629
INFO - 2018-04-20 11:35:15 --> Config Class Initialized
INFO - 2018-04-20 11:35:15 --> Hooks Class Initialized
DEBUG - 2018-04-20 11:35:15 --> UTF-8 Support Enabled
INFO - 2018-04-20 11:35:15 --> Utf8 Class Initialized
INFO - 2018-04-20 11:35:15 --> URI Class Initialized
INFO - 2018-04-20 11:35:15 --> Router Class Initialized
INFO - 2018-04-20 11:35:15 --> Output Class Initialized
INFO - 2018-04-20 11:35:15 --> Security Class Initialized
DEBUG - 2018-04-20 11:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 11:35:15 --> Input Class Initialized
INFO - 2018-04-20 11:35:15 --> Language Class Initialized
INFO - 2018-04-20 11:35:15 --> Language Class Initialized
INFO - 2018-04-20 11:35:15 --> Config Class Initialized
INFO - 2018-04-20 11:35:15 --> Loader Class Initialized
INFO - 2018-04-20 17:05:15 --> Helper loaded: url_helper
INFO - 2018-04-20 17:05:15 --> Helper loaded: notification_helper
INFO - 2018-04-20 17:05:15 --> Helper loaded: settings_helper
INFO - 2018-04-20 17:05:15 --> Helper loaded: permission_helper
INFO - 2018-04-20 17:05:15 --> Helper loaded: users_helper
INFO - 2018-04-20 17:05:15 --> Database Driver Class Initialized
DEBUG - 2018-04-20 17:05:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 17:05:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 17:05:15 --> Helper loaded: form_helper
INFO - 2018-04-20 17:05:15 --> Form Validation Class Initialized
INFO - 2018-04-20 17:05:15 --> Controller Class Initialized
INFO - 2018-04-20 17:05:15 --> Model Class Initialized
INFO - 2018-04-20 17:05:15 --> Helper loaded: inflector_helper
DEBUG - 2018-04-20 17:05:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-20 17:05:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-20 17:05:15 --> Model Class Initialized
INFO - 2018-04-20 17:05:15 --> Model Class Initialized
INFO - 2018-04-20 17:05:15 --> Model Class Initialized
INFO - 2018-04-20 17:05:15 --> Model Class Initialized
INFO - 2018-04-20 17:05:15 --> Model Class Initialized
INFO - 2018-04-20 17:05:15 --> Model Class Initialized
INFO - 2018-04-20 17:05:15 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-20 17:05:15 --> Final output sent to browser
DEBUG - 2018-04-20 17:05:15 --> Total execution time: 0.1040
INFO - 2018-04-20 11:35:35 --> Config Class Initialized
INFO - 2018-04-20 11:35:35 --> Hooks Class Initialized
DEBUG - 2018-04-20 11:35:35 --> UTF-8 Support Enabled
INFO - 2018-04-20 11:35:35 --> Utf8 Class Initialized
INFO - 2018-04-20 11:35:35 --> URI Class Initialized
INFO - 2018-04-20 11:35:35 --> Router Class Initialized
INFO - 2018-04-20 11:35:35 --> Output Class Initialized
INFO - 2018-04-20 11:35:35 --> Security Class Initialized
DEBUG - 2018-04-20 11:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 11:35:35 --> Input Class Initialized
INFO - 2018-04-20 11:35:35 --> Language Class Initialized
INFO - 2018-04-20 11:35:35 --> Language Class Initialized
INFO - 2018-04-20 11:35:35 --> Config Class Initialized
INFO - 2018-04-20 11:35:35 --> Loader Class Initialized
INFO - 2018-04-20 17:05:35 --> Helper loaded: url_helper
INFO - 2018-04-20 17:05:35 --> Helper loaded: notification_helper
INFO - 2018-04-20 17:05:35 --> Helper loaded: settings_helper
INFO - 2018-04-20 17:05:35 --> Helper loaded: permission_helper
INFO - 2018-04-20 17:05:35 --> Helper loaded: users_helper
INFO - 2018-04-20 17:05:35 --> Database Driver Class Initialized
DEBUG - 2018-04-20 17:05:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 17:05:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 17:05:35 --> Helper loaded: form_helper
INFO - 2018-04-20 17:05:35 --> Form Validation Class Initialized
INFO - 2018-04-20 17:05:35 --> Controller Class Initialized
INFO - 2018-04-20 17:05:35 --> Model Class Initialized
INFO - 2018-04-20 17:05:35 --> Helper loaded: inflector_helper
DEBUG - 2018-04-20 17:05:35 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-20 17:05:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-20 17:05:35 --> Model Class Initialized
INFO - 2018-04-20 17:05:35 --> Model Class Initialized
INFO - 2018-04-20 17:05:35 --> Model Class Initialized
INFO - 2018-04-20 17:05:35 --> Model Class Initialized
INFO - 2018-04-20 17:05:35 --> Model Class Initialized
INFO - 2018-04-20 17:05:35 --> Model Class Initialized
INFO - 2018-04-20 17:05:35 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-20 17:05:35 --> Final output sent to browser
DEBUG - 2018-04-20 17:05:35 --> Total execution time: 0.1076
INFO - 2018-04-20 11:35:36 --> Config Class Initialized
INFO - 2018-04-20 11:35:36 --> Hooks Class Initialized
DEBUG - 2018-04-20 11:35:36 --> UTF-8 Support Enabled
INFO - 2018-04-20 11:35:36 --> Utf8 Class Initialized
INFO - 2018-04-20 11:35:36 --> URI Class Initialized
INFO - 2018-04-20 11:35:36 --> Router Class Initialized
INFO - 2018-04-20 11:35:36 --> Output Class Initialized
INFO - 2018-04-20 11:35:36 --> Security Class Initialized
DEBUG - 2018-04-20 11:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 11:35:36 --> Input Class Initialized
INFO - 2018-04-20 11:35:36 --> Language Class Initialized
INFO - 2018-04-20 11:35:37 --> Language Class Initialized
INFO - 2018-04-20 11:35:37 --> Config Class Initialized
INFO - 2018-04-20 11:35:37 --> Loader Class Initialized
INFO - 2018-04-20 17:05:37 --> Helper loaded: url_helper
INFO - 2018-04-20 17:05:37 --> Helper loaded: notification_helper
INFO - 2018-04-20 17:05:37 --> Helper loaded: settings_helper
INFO - 2018-04-20 17:05:37 --> Helper loaded: permission_helper
INFO - 2018-04-20 17:05:37 --> Helper loaded: users_helper
INFO - 2018-04-20 17:05:37 --> Database Driver Class Initialized
DEBUG - 2018-04-20 17:05:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 17:05:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 17:05:37 --> Helper loaded: form_helper
INFO - 2018-04-20 17:05:37 --> Form Validation Class Initialized
INFO - 2018-04-20 17:05:37 --> Controller Class Initialized
INFO - 2018-04-20 17:05:37 --> Model Class Initialized
INFO - 2018-04-20 17:05:37 --> Helper loaded: inflector_helper
DEBUG - 2018-04-20 17:05:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-20 17:05:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-20 17:05:37 --> Model Class Initialized
INFO - 2018-04-20 17:05:37 --> Model Class Initialized
INFO - 2018-04-20 17:05:37 --> Model Class Initialized
INFO - 2018-04-20 17:05:37 --> Model Class Initialized
INFO - 2018-04-20 17:05:37 --> Model Class Initialized
INFO - 2018-04-20 17:05:37 --> Model Class Initialized
INFO - 2018-04-20 17:05:37 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-20 17:05:37 --> Final output sent to browser
DEBUG - 2018-04-20 17:05:37 --> Total execution time: 0.1217
INFO - 2018-04-20 11:36:16 --> Config Class Initialized
INFO - 2018-04-20 11:36:16 --> Hooks Class Initialized
DEBUG - 2018-04-20 11:36:16 --> UTF-8 Support Enabled
INFO - 2018-04-20 11:36:16 --> Utf8 Class Initialized
INFO - 2018-04-20 11:36:16 --> URI Class Initialized
INFO - 2018-04-20 11:36:16 --> Router Class Initialized
INFO - 2018-04-20 11:36:16 --> Output Class Initialized
INFO - 2018-04-20 11:36:16 --> Security Class Initialized
DEBUG - 2018-04-20 11:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 11:36:16 --> Input Class Initialized
INFO - 2018-04-20 11:36:16 --> Language Class Initialized
INFO - 2018-04-20 11:36:16 --> Language Class Initialized
INFO - 2018-04-20 11:36:16 --> Config Class Initialized
INFO - 2018-04-20 11:36:16 --> Loader Class Initialized
INFO - 2018-04-20 17:06:16 --> Helper loaded: url_helper
INFO - 2018-04-20 17:06:16 --> Helper loaded: notification_helper
INFO - 2018-04-20 17:06:16 --> Helper loaded: settings_helper
INFO - 2018-04-20 17:06:16 --> Helper loaded: permission_helper
INFO - 2018-04-20 17:06:16 --> Helper loaded: users_helper
INFO - 2018-04-20 17:06:16 --> Database Driver Class Initialized
DEBUG - 2018-04-20 17:06:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 17:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 17:06:16 --> Helper loaded: form_helper
INFO - 2018-04-20 17:06:16 --> Form Validation Class Initialized
INFO - 2018-04-20 17:06:16 --> Controller Class Initialized
INFO - 2018-04-20 17:06:16 --> Model Class Initialized
INFO - 2018-04-20 17:06:16 --> Helper loaded: inflector_helper
DEBUG - 2018-04-20 17:06:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-20 17:06:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-20 17:06:16 --> Model Class Initialized
INFO - 2018-04-20 17:06:16 --> Model Class Initialized
INFO - 2018-04-20 17:06:16 --> Model Class Initialized
INFO - 2018-04-20 17:06:16 --> Model Class Initialized
INFO - 2018-04-20 17:06:16 --> Model Class Initialized
INFO - 2018-04-20 17:06:16 --> Model Class Initialized
INFO - 2018-04-20 17:06:16 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-20 17:06:16 --> Upload Class Initialized
INFO - 2018-04-20 17:06:16 --> Final output sent to browser
DEBUG - 2018-04-20 17:06:16 --> Total execution time: 0.1177
INFO - 2018-04-20 11:36:17 --> Config Class Initialized
INFO - 2018-04-20 11:36:17 --> Hooks Class Initialized
DEBUG - 2018-04-20 11:36:17 --> UTF-8 Support Enabled
INFO - 2018-04-20 11:36:17 --> Utf8 Class Initialized
INFO - 2018-04-20 11:36:17 --> URI Class Initialized
INFO - 2018-04-20 11:36:17 --> Router Class Initialized
INFO - 2018-04-20 11:36:17 --> Output Class Initialized
INFO - 2018-04-20 11:36:17 --> Security Class Initialized
DEBUG - 2018-04-20 11:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 11:36:17 --> Input Class Initialized
INFO - 2018-04-20 11:36:17 --> Language Class Initialized
INFO - 2018-04-20 11:36:17 --> Language Class Initialized
INFO - 2018-04-20 11:36:17 --> Config Class Initialized
INFO - 2018-04-20 11:36:17 --> Loader Class Initialized
INFO - 2018-04-20 17:06:17 --> Helper loaded: url_helper
INFO - 2018-04-20 17:06:17 --> Helper loaded: notification_helper
INFO - 2018-04-20 17:06:17 --> Helper loaded: settings_helper
INFO - 2018-04-20 17:06:17 --> Helper loaded: permission_helper
INFO - 2018-04-20 17:06:17 --> Helper loaded: users_helper
INFO - 2018-04-20 17:06:17 --> Database Driver Class Initialized
DEBUG - 2018-04-20 17:06:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 17:06:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 17:06:17 --> Helper loaded: form_helper
INFO - 2018-04-20 17:06:17 --> Form Validation Class Initialized
INFO - 2018-04-20 17:06:17 --> Controller Class Initialized
INFO - 2018-04-20 17:06:17 --> Model Class Initialized
INFO - 2018-04-20 17:06:17 --> Helper loaded: inflector_helper
DEBUG - 2018-04-20 17:06:17 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-20 17:06:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-20 17:06:17 --> Model Class Initialized
INFO - 2018-04-20 17:06:17 --> Model Class Initialized
INFO - 2018-04-20 17:06:17 --> Model Class Initialized
INFO - 2018-04-20 17:06:17 --> Model Class Initialized
INFO - 2018-04-20 17:06:17 --> Model Class Initialized
INFO - 2018-04-20 17:06:17 --> Model Class Initialized
INFO - 2018-04-20 17:06:17 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-20 17:06:17 --> Final output sent to browser
DEBUG - 2018-04-20 17:06:17 --> Total execution time: 0.1199
INFO - 2018-04-20 11:36:37 --> Config Class Initialized
INFO - 2018-04-20 11:36:37 --> Hooks Class Initialized
DEBUG - 2018-04-20 11:36:37 --> UTF-8 Support Enabled
INFO - 2018-04-20 11:36:37 --> Utf8 Class Initialized
INFO - 2018-04-20 11:36:37 --> URI Class Initialized
INFO - 2018-04-20 11:36:37 --> Router Class Initialized
INFO - 2018-04-20 11:36:37 --> Output Class Initialized
INFO - 2018-04-20 11:36:37 --> Security Class Initialized
DEBUG - 2018-04-20 11:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 11:36:37 --> Input Class Initialized
INFO - 2018-04-20 11:36:37 --> Language Class Initialized
INFO - 2018-04-20 11:36:37 --> Language Class Initialized
INFO - 2018-04-20 11:36:37 --> Config Class Initialized
INFO - 2018-04-20 11:36:37 --> Loader Class Initialized
INFO - 2018-04-20 17:06:37 --> Helper loaded: url_helper
INFO - 2018-04-20 17:06:37 --> Helper loaded: notification_helper
INFO - 2018-04-20 17:06:37 --> Helper loaded: settings_helper
INFO - 2018-04-20 17:06:37 --> Helper loaded: permission_helper
INFO - 2018-04-20 17:06:37 --> Helper loaded: users_helper
INFO - 2018-04-20 17:06:37 --> Database Driver Class Initialized
DEBUG - 2018-04-20 17:06:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 17:06:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 17:06:37 --> Helper loaded: form_helper
INFO - 2018-04-20 17:06:37 --> Form Validation Class Initialized
INFO - 2018-04-20 17:06:37 --> Controller Class Initialized
INFO - 2018-04-20 17:06:37 --> Model Class Initialized
INFO - 2018-04-20 17:06:37 --> Helper loaded: inflector_helper
DEBUG - 2018-04-20 17:06:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-20 17:06:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-20 17:06:37 --> Model Class Initialized
INFO - 2018-04-20 17:06:37 --> Model Class Initialized
INFO - 2018-04-20 17:06:37 --> Model Class Initialized
INFO - 2018-04-20 17:06:37 --> Model Class Initialized
INFO - 2018-04-20 17:06:37 --> Model Class Initialized
INFO - 2018-04-20 17:06:37 --> Model Class Initialized
INFO - 2018-04-20 17:06:37 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-20 17:06:37 --> Final output sent to browser
DEBUG - 2018-04-20 17:06:37 --> Total execution time: 0.1056
INFO - 2018-04-20 11:36:38 --> Config Class Initialized
INFO - 2018-04-20 11:36:38 --> Hooks Class Initialized
DEBUG - 2018-04-20 11:36:38 --> UTF-8 Support Enabled
INFO - 2018-04-20 11:36:38 --> Utf8 Class Initialized
INFO - 2018-04-20 11:36:38 --> URI Class Initialized
INFO - 2018-04-20 11:36:38 --> Router Class Initialized
INFO - 2018-04-20 11:36:38 --> Output Class Initialized
INFO - 2018-04-20 11:36:38 --> Security Class Initialized
DEBUG - 2018-04-20 11:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 11:36:38 --> Input Class Initialized
INFO - 2018-04-20 11:36:38 --> Language Class Initialized
INFO - 2018-04-20 11:36:38 --> Language Class Initialized
INFO - 2018-04-20 11:36:38 --> Config Class Initialized
INFO - 2018-04-20 11:36:38 --> Loader Class Initialized
INFO - 2018-04-20 17:06:38 --> Helper loaded: url_helper
INFO - 2018-04-20 17:06:38 --> Helper loaded: notification_helper
INFO - 2018-04-20 17:06:38 --> Helper loaded: settings_helper
INFO - 2018-04-20 17:06:38 --> Helper loaded: permission_helper
INFO - 2018-04-20 17:06:38 --> Helper loaded: users_helper
INFO - 2018-04-20 17:06:38 --> Database Driver Class Initialized
DEBUG - 2018-04-20 17:06:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 17:06:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 17:06:38 --> Helper loaded: form_helper
INFO - 2018-04-20 17:06:38 --> Form Validation Class Initialized
INFO - 2018-04-20 17:06:38 --> Controller Class Initialized
INFO - 2018-04-20 17:06:38 --> Model Class Initialized
INFO - 2018-04-20 17:06:38 --> Helper loaded: inflector_helper
DEBUG - 2018-04-20 17:06:38 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-20 17:06:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-20 17:06:38 --> Model Class Initialized
INFO - 2018-04-20 17:06:38 --> Model Class Initialized
INFO - 2018-04-20 17:06:38 --> Model Class Initialized
INFO - 2018-04-20 17:06:38 --> Model Class Initialized
INFO - 2018-04-20 17:06:38 --> Model Class Initialized
INFO - 2018-04-20 17:06:38 --> Model Class Initialized
INFO - 2018-04-20 17:06:38 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-20 17:06:38 --> Final output sent to browser
DEBUG - 2018-04-20 17:06:38 --> Total execution time: 0.1213
INFO - 2018-04-20 11:36:42 --> Config Class Initialized
INFO - 2018-04-20 11:36:42 --> Hooks Class Initialized
DEBUG - 2018-04-20 11:36:42 --> UTF-8 Support Enabled
INFO - 2018-04-20 11:36:42 --> Utf8 Class Initialized
INFO - 2018-04-20 11:36:42 --> URI Class Initialized
INFO - 2018-04-20 11:36:42 --> Router Class Initialized
INFO - 2018-04-20 11:36:42 --> Output Class Initialized
INFO - 2018-04-20 11:36:42 --> Security Class Initialized
DEBUG - 2018-04-20 11:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 11:36:42 --> Input Class Initialized
INFO - 2018-04-20 11:36:42 --> Language Class Initialized
INFO - 2018-04-20 11:36:42 --> Language Class Initialized
INFO - 2018-04-20 11:36:42 --> Config Class Initialized
INFO - 2018-04-20 11:36:42 --> Loader Class Initialized
INFO - 2018-04-20 17:06:42 --> Helper loaded: url_helper
INFO - 2018-04-20 17:06:42 --> Helper loaded: notification_helper
INFO - 2018-04-20 17:06:42 --> Helper loaded: settings_helper
INFO - 2018-04-20 17:06:42 --> Helper loaded: permission_helper
INFO - 2018-04-20 17:06:42 --> Helper loaded: users_helper
INFO - 2018-04-20 17:06:42 --> Database Driver Class Initialized
DEBUG - 2018-04-20 17:06:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 17:06:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 17:06:42 --> Helper loaded: form_helper
INFO - 2018-04-20 17:06:42 --> Form Validation Class Initialized
INFO - 2018-04-20 17:06:42 --> Controller Class Initialized
INFO - 2018-04-20 17:06:42 --> Model Class Initialized
INFO - 2018-04-20 17:06:42 --> Helper loaded: inflector_helper
DEBUG - 2018-04-20 17:06:42 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-20 17:06:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-20 17:06:42 --> Model Class Initialized
INFO - 2018-04-20 17:06:42 --> Model Class Initialized
INFO - 2018-04-20 17:06:42 --> Model Class Initialized
INFO - 2018-04-20 17:06:42 --> Model Class Initialized
INFO - 2018-04-20 17:06:42 --> Model Class Initialized
INFO - 2018-04-20 17:06:42 --> Model Class Initialized
INFO - 2018-04-20 17:06:42 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-20 17:06:42 --> Final output sent to browser
DEBUG - 2018-04-20 17:06:42 --> Total execution time: 0.1225
INFO - 2018-04-20 11:36:43 --> Config Class Initialized
INFO - 2018-04-20 11:36:43 --> Hooks Class Initialized
DEBUG - 2018-04-20 11:36:43 --> UTF-8 Support Enabled
INFO - 2018-04-20 11:36:43 --> Utf8 Class Initialized
INFO - 2018-04-20 11:36:43 --> URI Class Initialized
INFO - 2018-04-20 11:36:43 --> Router Class Initialized
INFO - 2018-04-20 11:36:43 --> Output Class Initialized
INFO - 2018-04-20 11:36:43 --> Security Class Initialized
DEBUG - 2018-04-20 11:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 11:36:43 --> Input Class Initialized
INFO - 2018-04-20 11:36:43 --> Language Class Initialized
INFO - 2018-04-20 11:36:43 --> Config Class Initialized
INFO - 2018-04-20 11:36:43 --> Hooks Class Initialized
DEBUG - 2018-04-20 11:36:43 --> UTF-8 Support Enabled
INFO - 2018-04-20 11:36:43 --> Utf8 Class Initialized
INFO - 2018-04-20 11:36:43 --> URI Class Initialized
INFO - 2018-04-20 11:36:43 --> Language Class Initialized
INFO - 2018-04-20 11:36:43 --> Config Class Initialized
INFO - 2018-04-20 11:36:43 --> Loader Class Initialized
INFO - 2018-04-20 11:36:43 --> Router Class Initialized
INFO - 2018-04-20 17:06:43 --> Helper loaded: url_helper
INFO - 2018-04-20 17:06:43 --> Helper loaded: notification_helper
INFO - 2018-04-20 11:36:43 --> Output Class Initialized
INFO - 2018-04-20 17:06:43 --> Helper loaded: settings_helper
INFO - 2018-04-20 17:06:43 --> Helper loaded: permission_helper
INFO - 2018-04-20 17:06:43 --> Helper loaded: users_helper
INFO - 2018-04-20 11:36:43 --> Security Class Initialized
DEBUG - 2018-04-20 11:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 11:36:43 --> Input Class Initialized
INFO - 2018-04-20 11:36:43 --> Language Class Initialized
INFO - 2018-04-20 17:06:43 --> Database Driver Class Initialized
DEBUG - 2018-04-20 17:06:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 17:06:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 11:36:43 --> Language Class Initialized
INFO - 2018-04-20 11:36:43 --> Config Class Initialized
INFO - 2018-04-20 11:36:43 --> Loader Class Initialized
INFO - 2018-04-20 17:06:43 --> Helper loaded: form_helper
INFO - 2018-04-20 17:06:43 --> Form Validation Class Initialized
INFO - 2018-04-20 17:06:43 --> Controller Class Initialized
INFO - 2018-04-20 17:06:43 --> Helper loaded: url_helper
INFO - 2018-04-20 17:06:43 --> Helper loaded: notification_helper
INFO - 2018-04-20 17:06:43 --> Helper loaded: settings_helper
INFO - 2018-04-20 17:06:43 --> Helper loaded: permission_helper
INFO - 2018-04-20 17:06:43 --> Helper loaded: users_helper
INFO - 2018-04-20 17:06:43 --> Model Class Initialized
INFO - 2018-04-20 17:06:43 --> Helper loaded: inflector_helper
DEBUG - 2018-04-20 17:06:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-20 17:06:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-20 17:06:43 --> Model Class Initialized
INFO - 2018-04-20 17:06:43 --> Model Class Initialized
INFO - 2018-04-20 17:06:43 --> Model Class Initialized
INFO - 2018-04-20 17:06:43 --> Model Class Initialized
INFO - 2018-04-20 17:06:43 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-20 17:06:43 --> Database Driver Class Initialized
INFO - 2018-04-20 17:06:43 --> Final output sent to browser
DEBUG - 2018-04-20 17:06:43 --> Total execution time: 0.1000
DEBUG - 2018-04-20 17:06:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 17:06:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 17:06:43 --> Helper loaded: form_helper
INFO - 2018-04-20 17:06:43 --> Form Validation Class Initialized
INFO - 2018-04-20 17:06:43 --> Controller Class Initialized
INFO - 2018-04-20 17:06:43 --> Model Class Initialized
INFO - 2018-04-20 17:06:43 --> Helper loaded: inflector_helper
DEBUG - 2018-04-20 17:06:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-20 17:06:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-20 17:06:43 --> Model Class Initialized
INFO - 2018-04-20 17:06:43 --> Model Class Initialized
INFO - 2018-04-20 17:06:43 --> Model Class Initialized
INFO - 2018-04-20 17:06:43 --> Model Class Initialized
INFO - 2018-04-20 17:06:43 --> Model Class Initialized
INFO - 2018-04-20 17:06:43 --> Model Class Initialized
INFO - 2018-04-20 17:06:43 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-20 17:06:43 --> Final output sent to browser
DEBUG - 2018-04-20 17:06:43 --> Total execution time: 0.1137
INFO - 2018-04-20 11:36:45 --> Config Class Initialized
INFO - 2018-04-20 11:36:45 --> Hooks Class Initialized
DEBUG - 2018-04-20 11:36:45 --> UTF-8 Support Enabled
INFO - 2018-04-20 11:36:45 --> Utf8 Class Initialized
INFO - 2018-04-20 11:36:45 --> URI Class Initialized
INFO - 2018-04-20 11:36:45 --> Router Class Initialized
INFO - 2018-04-20 11:36:45 --> Output Class Initialized
INFO - 2018-04-20 11:36:45 --> Security Class Initialized
DEBUG - 2018-04-20 11:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 11:36:45 --> Input Class Initialized
INFO - 2018-04-20 11:36:45 --> Language Class Initialized
INFO - 2018-04-20 11:36:45 --> Language Class Initialized
INFO - 2018-04-20 11:36:45 --> Config Class Initialized
INFO - 2018-04-20 11:36:45 --> Loader Class Initialized
INFO - 2018-04-20 17:06:45 --> Helper loaded: url_helper
INFO - 2018-04-20 17:06:45 --> Helper loaded: notification_helper
INFO - 2018-04-20 17:06:45 --> Helper loaded: settings_helper
INFO - 2018-04-20 17:06:45 --> Helper loaded: permission_helper
INFO - 2018-04-20 17:06:45 --> Helper loaded: users_helper
INFO - 2018-04-20 11:36:45 --> Config Class Initialized
INFO - 2018-04-20 11:36:45 --> Hooks Class Initialized
DEBUG - 2018-04-20 11:36:45 --> UTF-8 Support Enabled
INFO - 2018-04-20 11:36:45 --> Utf8 Class Initialized
INFO - 2018-04-20 11:36:45 --> URI Class Initialized
INFO - 2018-04-20 11:36:46 --> Router Class Initialized
INFO - 2018-04-20 17:06:46 --> Database Driver Class Initialized
INFO - 2018-04-20 11:36:46 --> Output Class Initialized
INFO - 2018-04-20 11:36:46 --> Security Class Initialized
DEBUG - 2018-04-20 17:06:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-04-20 11:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 17:06:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 11:36:46 --> Input Class Initialized
INFO - 2018-04-20 11:36:46 --> Language Class Initialized
INFO - 2018-04-20 17:06:46 --> Helper loaded: form_helper
INFO - 2018-04-20 17:06:46 --> Form Validation Class Initialized
INFO - 2018-04-20 17:06:46 --> Controller Class Initialized
INFO - 2018-04-20 17:06:46 --> Model Class Initialized
INFO - 2018-04-20 17:06:46 --> Helper loaded: inflector_helper
INFO - 2018-04-20 11:36:46 --> Language Class Initialized
INFO - 2018-04-20 11:36:46 --> Config Class Initialized
INFO - 2018-04-20 11:36:46 --> Loader Class Initialized
DEBUG - 2018-04-20 17:06:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-20 17:06:46 --> Helper loaded: url_helper
INFO - 2018-04-20 17:06:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-20 17:06:46 --> Helper loaded: notification_helper
INFO - 2018-04-20 17:06:46 --> Model Class Initialized
INFO - 2018-04-20 17:06:46 --> Helper loaded: settings_helper
INFO - 2018-04-20 17:06:46 --> Model Class Initialized
INFO - 2018-04-20 17:06:46 --> Helper loaded: permission_helper
INFO - 2018-04-20 17:06:46 --> Model Class Initialized
INFO - 2018-04-20 17:06:46 --> Model Class Initialized
INFO - 2018-04-20 17:06:46 --> Helper loaded: users_helper
INFO - 2018-04-20 17:06:46 --> Model Class Initialized
INFO - 2018-04-20 17:06:46 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-20 17:06:46 --> Model Class Initialized
INFO - 2018-04-20 17:06:46 --> Final output sent to browser
DEBUG - 2018-04-20 17:06:46 --> Total execution time: 0.1095
INFO - 2018-04-20 17:06:46 --> Database Driver Class Initialized
DEBUG - 2018-04-20 17:06:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 17:06:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 17:06:46 --> Helper loaded: form_helper
INFO - 2018-04-20 17:06:46 --> Form Validation Class Initialized
INFO - 2018-04-20 17:06:46 --> Controller Class Initialized
INFO - 2018-04-20 17:06:46 --> Model Class Initialized
INFO - 2018-04-20 17:06:46 --> Helper loaded: inflector_helper
DEBUG - 2018-04-20 17:06:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-20 17:06:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-20 17:06:46 --> Model Class Initialized
INFO - 2018-04-20 17:06:46 --> Model Class Initialized
INFO - 2018-04-20 17:06:46 --> Model Class Initialized
INFO - 2018-04-20 17:06:46 --> Model Class Initialized
INFO - 2018-04-20 17:06:46 --> Model Class Initialized
INFO - 2018-04-20 17:06:46 --> Model Class Initialized
INFO - 2018-04-20 17:06:46 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-20 17:06:46 --> Final output sent to browser
DEBUG - 2018-04-20 17:06:46 --> Total execution time: 0.1036
INFO - 2018-04-20 11:37:02 --> Config Class Initialized
INFO - 2018-04-20 11:37:02 --> Hooks Class Initialized
DEBUG - 2018-04-20 11:37:02 --> UTF-8 Support Enabled
INFO - 2018-04-20 11:37:02 --> Utf8 Class Initialized
INFO - 2018-04-20 11:37:02 --> URI Class Initialized
INFO - 2018-04-20 11:37:02 --> Router Class Initialized
INFO - 2018-04-20 11:37:02 --> Output Class Initialized
INFO - 2018-04-20 11:37:02 --> Security Class Initialized
DEBUG - 2018-04-20 11:37:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 11:37:02 --> Input Class Initialized
INFO - 2018-04-20 11:37:02 --> Language Class Initialized
INFO - 2018-04-20 11:37:02 --> Language Class Initialized
INFO - 2018-04-20 11:37:02 --> Config Class Initialized
INFO - 2018-04-20 11:37:02 --> Loader Class Initialized
INFO - 2018-04-20 17:07:02 --> Helper loaded: url_helper
INFO - 2018-04-20 17:07:02 --> Helper loaded: notification_helper
INFO - 2018-04-20 17:07:02 --> Helper loaded: settings_helper
INFO - 2018-04-20 17:07:02 --> Helper loaded: permission_helper
INFO - 2018-04-20 17:07:02 --> Helper loaded: users_helper
INFO - 2018-04-20 17:07:02 --> Database Driver Class Initialized
DEBUG - 2018-04-20 17:07:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 17:07:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 17:07:02 --> Helper loaded: form_helper
INFO - 2018-04-20 17:07:02 --> Form Validation Class Initialized
INFO - 2018-04-20 17:07:02 --> Controller Class Initialized
INFO - 2018-04-20 17:07:02 --> Model Class Initialized
INFO - 2018-04-20 17:07:02 --> Helper loaded: inflector_helper
DEBUG - 2018-04-20 17:07:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-20 17:07:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-20 17:07:02 --> Model Class Initialized
INFO - 2018-04-20 17:07:02 --> Model Class Initialized
INFO - 2018-04-20 17:07:02 --> Model Class Initialized
INFO - 2018-04-20 17:07:02 --> Model Class Initialized
INFO - 2018-04-20 17:07:02 --> Model Class Initialized
INFO - 2018-04-20 17:07:02 --> Model Class Initialized
INFO - 2018-04-20 17:07:02 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-20 17:07:02 --> Upload Class Initialized
INFO - 2018-04-20 17:07:02 --> Final output sent to browser
DEBUG - 2018-04-20 17:07:02 --> Total execution time: 0.1090
INFO - 2018-04-20 11:37:03 --> Config Class Initialized
INFO - 2018-04-20 11:37:03 --> Hooks Class Initialized
DEBUG - 2018-04-20 11:37:03 --> UTF-8 Support Enabled
INFO - 2018-04-20 11:37:03 --> Utf8 Class Initialized
INFO - 2018-04-20 11:37:03 --> URI Class Initialized
INFO - 2018-04-20 11:37:03 --> Router Class Initialized
INFO - 2018-04-20 11:37:03 --> Output Class Initialized
INFO - 2018-04-20 11:37:03 --> Security Class Initialized
DEBUG - 2018-04-20 11:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 11:37:03 --> Input Class Initialized
INFO - 2018-04-20 11:37:03 --> Language Class Initialized
INFO - 2018-04-20 11:37:03 --> Language Class Initialized
INFO - 2018-04-20 11:37:03 --> Config Class Initialized
INFO - 2018-04-20 11:37:03 --> Loader Class Initialized
INFO - 2018-04-20 17:07:03 --> Helper loaded: url_helper
INFO - 2018-04-20 17:07:03 --> Helper loaded: notification_helper
INFO - 2018-04-20 17:07:03 --> Helper loaded: settings_helper
INFO - 2018-04-20 17:07:03 --> Helper loaded: permission_helper
INFO - 2018-04-20 17:07:03 --> Helper loaded: users_helper
INFO - 2018-04-20 17:07:03 --> Database Driver Class Initialized
DEBUG - 2018-04-20 17:07:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 17:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 17:07:03 --> Helper loaded: form_helper
INFO - 2018-04-20 17:07:03 --> Form Validation Class Initialized
INFO - 2018-04-20 17:07:03 --> Controller Class Initialized
INFO - 2018-04-20 17:07:03 --> Model Class Initialized
INFO - 2018-04-20 17:07:03 --> Helper loaded: inflector_helper
DEBUG - 2018-04-20 17:07:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-20 17:07:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-20 17:07:03 --> Model Class Initialized
INFO - 2018-04-20 17:07:03 --> Model Class Initialized
INFO - 2018-04-20 17:07:03 --> Model Class Initialized
INFO - 2018-04-20 17:07:03 --> Model Class Initialized
INFO - 2018-04-20 17:07:03 --> Model Class Initialized
INFO - 2018-04-20 17:07:03 --> Model Class Initialized
INFO - 2018-04-20 17:07:03 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-20 17:07:03 --> Final output sent to browser
DEBUG - 2018-04-20 17:07:03 --> Total execution time: 0.1117
INFO - 2018-04-20 11:37:06 --> Config Class Initialized
INFO - 2018-04-20 11:37:06 --> Hooks Class Initialized
DEBUG - 2018-04-20 11:37:06 --> UTF-8 Support Enabled
INFO - 2018-04-20 11:37:06 --> Utf8 Class Initialized
INFO - 2018-04-20 11:37:06 --> URI Class Initialized
INFO - 2018-04-20 11:37:06 --> Router Class Initialized
INFO - 2018-04-20 11:37:06 --> Output Class Initialized
INFO - 2018-04-20 11:37:06 --> Security Class Initialized
DEBUG - 2018-04-20 11:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 11:37:06 --> Input Class Initialized
INFO - 2018-04-20 11:37:06 --> Language Class Initialized
INFO - 2018-04-20 11:37:06 --> Language Class Initialized
INFO - 2018-04-20 11:37:06 --> Config Class Initialized
INFO - 2018-04-20 11:37:06 --> Loader Class Initialized
INFO - 2018-04-20 17:07:06 --> Helper loaded: url_helper
INFO - 2018-04-20 17:07:06 --> Helper loaded: notification_helper
INFO - 2018-04-20 17:07:06 --> Helper loaded: settings_helper
INFO - 2018-04-20 17:07:06 --> Helper loaded: permission_helper
INFO - 2018-04-20 17:07:06 --> Helper loaded: users_helper
INFO - 2018-04-20 17:07:06 --> Database Driver Class Initialized
DEBUG - 2018-04-20 17:07:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 17:07:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 17:07:06 --> Helper loaded: form_helper
INFO - 2018-04-20 17:07:06 --> Form Validation Class Initialized
INFO - 2018-04-20 17:07:06 --> Controller Class Initialized
INFO - 2018-04-20 17:07:06 --> Model Class Initialized
INFO - 2018-04-20 17:07:06 --> Helper loaded: inflector_helper
DEBUG - 2018-04-20 17:07:06 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-20 17:07:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-20 17:07:06 --> Model Class Initialized
INFO - 2018-04-20 17:07:06 --> Model Class Initialized
INFO - 2018-04-20 17:07:06 --> Model Class Initialized
INFO - 2018-04-20 17:07:06 --> Model Class Initialized
INFO - 2018-04-20 17:07:06 --> Model Class Initialized
INFO - 2018-04-20 17:07:06 --> Model Class Initialized
INFO - 2018-04-20 17:07:06 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-20 17:07:06 --> Final output sent to browser
DEBUG - 2018-04-20 17:07:06 --> Total execution time: 0.1183
INFO - 2018-04-20 11:37:07 --> Config Class Initialized
INFO - 2018-04-20 11:37:07 --> Hooks Class Initialized
DEBUG - 2018-04-20 11:37:07 --> UTF-8 Support Enabled
INFO - 2018-04-20 11:37:07 --> Utf8 Class Initialized
INFO - 2018-04-20 11:37:07 --> URI Class Initialized
INFO - 2018-04-20 11:37:07 --> Router Class Initialized
INFO - 2018-04-20 11:37:07 --> Output Class Initialized
INFO - 2018-04-20 11:37:07 --> Security Class Initialized
DEBUG - 2018-04-20 11:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 11:37:07 --> Input Class Initialized
INFO - 2018-04-20 11:37:07 --> Language Class Initialized
INFO - 2018-04-20 11:37:07 --> Language Class Initialized
INFO - 2018-04-20 11:37:07 --> Config Class Initialized
INFO - 2018-04-20 11:37:07 --> Loader Class Initialized
INFO - 2018-04-20 17:07:07 --> Helper loaded: url_helper
INFO - 2018-04-20 17:07:07 --> Helper loaded: notification_helper
INFO - 2018-04-20 17:07:07 --> Helper loaded: settings_helper
INFO - 2018-04-20 17:07:07 --> Helper loaded: permission_helper
INFO - 2018-04-20 17:07:07 --> Helper loaded: users_helper
INFO - 2018-04-20 17:07:07 --> Database Driver Class Initialized
DEBUG - 2018-04-20 17:07:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 17:07:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 17:07:07 --> Helper loaded: form_helper
INFO - 2018-04-20 17:07:07 --> Form Validation Class Initialized
INFO - 2018-04-20 17:07:07 --> Controller Class Initialized
INFO - 2018-04-20 17:07:07 --> Model Class Initialized
INFO - 2018-04-20 17:07:07 --> Helper loaded: inflector_helper
DEBUG - 2018-04-20 17:07:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-20 17:07:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-20 17:07:07 --> Model Class Initialized
INFO - 2018-04-20 17:07:07 --> Model Class Initialized
INFO - 2018-04-20 17:07:07 --> Model Class Initialized
INFO - 2018-04-20 17:07:07 --> Model Class Initialized
INFO - 2018-04-20 17:07:07 --> Model Class Initialized
INFO - 2018-04-20 17:07:07 --> Model Class Initialized
INFO - 2018-04-20 17:07:07 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-20 17:07:07 --> Final output sent to browser
DEBUG - 2018-04-20 17:07:07 --> Total execution time: 0.1100
INFO - 2018-04-20 11:37:08 --> Config Class Initialized
INFO - 2018-04-20 11:37:08 --> Hooks Class Initialized
DEBUG - 2018-04-20 11:37:08 --> UTF-8 Support Enabled
INFO - 2018-04-20 11:37:08 --> Utf8 Class Initialized
INFO - 2018-04-20 11:37:08 --> URI Class Initialized
INFO - 2018-04-20 11:37:08 --> Router Class Initialized
INFO - 2018-04-20 11:37:08 --> Output Class Initialized
INFO - 2018-04-20 11:37:08 --> Security Class Initialized
DEBUG - 2018-04-20 11:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 11:37:08 --> Input Class Initialized
INFO - 2018-04-20 11:37:08 --> Language Class Initialized
INFO - 2018-04-20 11:37:08 --> Language Class Initialized
INFO - 2018-04-20 11:37:08 --> Config Class Initialized
INFO - 2018-04-20 11:37:08 --> Loader Class Initialized
INFO - 2018-04-20 17:07:08 --> Helper loaded: url_helper
INFO - 2018-04-20 17:07:08 --> Helper loaded: notification_helper
INFO - 2018-04-20 17:07:08 --> Helper loaded: settings_helper
INFO - 2018-04-20 17:07:08 --> Helper loaded: permission_helper
INFO - 2018-04-20 17:07:08 --> Helper loaded: users_helper
INFO - 2018-04-20 17:07:08 --> Database Driver Class Initialized
DEBUG - 2018-04-20 17:07:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 17:07:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 17:07:08 --> Helper loaded: form_helper
INFO - 2018-04-20 17:07:08 --> Form Validation Class Initialized
INFO - 2018-04-20 17:07:08 --> Controller Class Initialized
INFO - 2018-04-20 17:07:08 --> Model Class Initialized
INFO - 2018-04-20 17:07:08 --> Helper loaded: inflector_helper
DEBUG - 2018-04-20 17:07:08 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-20 17:07:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-20 17:07:08 --> Model Class Initialized
INFO - 2018-04-20 17:07:08 --> Model Class Initialized
INFO - 2018-04-20 17:07:08 --> Model Class Initialized
INFO - 2018-04-20 17:07:08 --> Model Class Initialized
INFO - 2018-04-20 17:07:08 --> Model Class Initialized
INFO - 2018-04-20 17:07:08 --> Model Class Initialized
INFO - 2018-04-20 17:07:08 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-20 17:07:08 --> Final output sent to browser
DEBUG - 2018-04-20 17:07:08 --> Total execution time: 0.1069
INFO - 2018-04-20 11:37:09 --> Config Class Initialized
INFO - 2018-04-20 11:37:09 --> Hooks Class Initialized
INFO - 2018-04-20 11:37:09 --> Config Class Initialized
INFO - 2018-04-20 11:37:09 --> Hooks Class Initialized
DEBUG - 2018-04-20 11:37:09 --> UTF-8 Support Enabled
INFO - 2018-04-20 11:37:09 --> Utf8 Class Initialized
DEBUG - 2018-04-20 11:37:09 --> UTF-8 Support Enabled
INFO - 2018-04-20 11:37:09 --> Utf8 Class Initialized
INFO - 2018-04-20 11:37:09 --> URI Class Initialized
INFO - 2018-04-20 11:37:09 --> URI Class Initialized
INFO - 2018-04-20 11:37:09 --> Router Class Initialized
INFO - 2018-04-20 11:37:09 --> Router Class Initialized
INFO - 2018-04-20 11:37:09 --> Output Class Initialized
INFO - 2018-04-20 11:37:09 --> Output Class Initialized
INFO - 2018-04-20 11:37:09 --> Security Class Initialized
INFO - 2018-04-20 11:37:09 --> Security Class Initialized
DEBUG - 2018-04-20 11:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 11:37:09 --> Input Class Initialized
INFO - 2018-04-20 11:37:09 --> Language Class Initialized
DEBUG - 2018-04-20 11:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-20 11:37:09 --> Input Class Initialized
INFO - 2018-04-20 11:37:09 --> Language Class Initialized
INFO - 2018-04-20 11:37:09 --> Language Class Initialized
INFO - 2018-04-20 11:37:09 --> Config Class Initialized
INFO - 2018-04-20 11:37:09 --> Loader Class Initialized
INFO - 2018-04-20 11:37:09 --> Language Class Initialized
INFO - 2018-04-20 11:37:09 --> Config Class Initialized
INFO - 2018-04-20 11:37:09 --> Loader Class Initialized
INFO - 2018-04-20 17:07:09 --> Helper loaded: url_helper
INFO - 2018-04-20 17:07:09 --> Helper loaded: url_helper
INFO - 2018-04-20 17:07:09 --> Helper loaded: notification_helper
INFO - 2018-04-20 17:07:09 --> Helper loaded: settings_helper
INFO - 2018-04-20 17:07:09 --> Helper loaded: notification_helper
INFO - 2018-04-20 17:07:09 --> Helper loaded: settings_helper
INFO - 2018-04-20 17:07:09 --> Helper loaded: permission_helper
INFO - 2018-04-20 17:07:09 --> Helper loaded: users_helper
INFO - 2018-04-20 17:07:09 --> Helper loaded: permission_helper
INFO - 2018-04-20 17:07:09 --> Helper loaded: users_helper
INFO - 2018-04-20 17:07:09 --> Database Driver Class Initialized
INFO - 2018-04-20 17:07:09 --> Database Driver Class Initialized
DEBUG - 2018-04-20 17:07:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 17:07:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-04-20 17:07:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-20 17:07:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-20 17:07:09 --> Helper loaded: form_helper
INFO - 2018-04-20 17:07:09 --> Form Validation Class Initialized
INFO - 2018-04-20 17:07:09 --> Controller Class Initialized
INFO - 2018-04-20 17:07:09 --> Helper loaded: form_helper
INFO - 2018-04-20 17:07:09 --> Form Validation Class Initialized
INFO - 2018-04-20 17:07:09 --> Controller Class Initialized
INFO - 2018-04-20 17:07:09 --> Model Class Initialized
INFO - 2018-04-20 17:07:09 --> Helper loaded: inflector_helper
INFO - 2018-04-20 17:07:09 --> Model Class Initialized
INFO - 2018-04-20 17:07:09 --> Helper loaded: inflector_helper
DEBUG - 2018-04-20 17:07:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-04-20 17:07:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-20 17:07:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-20 17:07:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-20 17:07:09 --> Model Class Initialized
INFO - 2018-04-20 17:07:09 --> Model Class Initialized
INFO - 2018-04-20 17:07:09 --> Model Class Initialized
INFO - 2018-04-20 17:07:09 --> Model Class Initialized
INFO - 2018-04-20 17:07:09 --> Model Class Initialized
INFO - 2018-04-20 17:07:09 --> Model Class Initialized
INFO - 2018-04-20 17:07:09 --> Model Class Initialized
INFO - 2018-04-20 17:07:09 --> Model Class Initialized
INFO - 2018-04-20 17:07:09 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-20 17:07:09 --> Model Class Initialized
INFO - 2018-04-20 17:07:09 --> Model Class Initialized
INFO - 2018-04-20 17:07:09 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-20 17:07:09 --> Final output sent to browser
INFO - 2018-04-20 17:07:09 --> Final output sent to browser
DEBUG - 2018-04-20 17:07:09 --> Total execution time: 0.0973
DEBUG - 2018-04-20 17:07:09 --> Total execution time: 0.0962
