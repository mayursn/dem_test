<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-06-09 00:00:01 --> Helper loaded: url_helper
INFO - 2018-06-09 00:00:01 --> Helper loaded: notification_helper
INFO - 2018-06-09 00:00:01 --> Helper loaded: settings_helper
INFO - 2018-06-09 00:00:01 --> Helper loaded: permission_helper
INFO - 2018-06-09 00:00:01 --> Helper loaded: users_helper
INFO - 2018-06-09 00:00:01 --> Database Driver Class Initialized
DEBUG - 2018-06-09 00:00:01 --> Session: Initialization under CLI aborted.
INFO - 2018-06-09 00:00:01 --> Helper loaded: form_helper
INFO - 2018-06-09 00:00:01 --> Form Validation Class Initialized
INFO - 2018-06-09 00:00:01 --> Controller Class Initialized
INFO - 2018-06-09 00:00:01 --> Model Class Initialized
INFO - 2018-06-09 00:00:01 --> Helper loaded: inflector_helper
DEBUG - 2018-06-09 00:00:01 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-09 00:00:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-09 00:00:01 --> Model Class Initialized
INFO - 2018-06-09 00:00:01 --> Model Class Initialized
INFO - 2018-06-09 00:00:01 --> Model Class Initialized
INFO - 2018-06-09 00:00:01 --> Model Class Initialized
INFO - 2018-06-09 00:00:01 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-09 00:00:01 --> Model Class Initialized
INFO - 2018-06-09 00:00:01 --> Final output sent to browser
DEBUG - 2018-06-09 00:00:01 --> Total execution time: 0.0984
INFO - 2018-06-09 00:00:01 --> Helper loaded: url_helper
INFO - 2018-06-09 00:00:01 --> Helper loaded: notification_helper
INFO - 2018-06-09 00:00:01 --> Helper loaded: settings_helper
INFO - 2018-06-09 00:00:01 --> Helper loaded: permission_helper
INFO - 2018-06-09 00:00:01 --> Helper loaded: users_helper
INFO - 2018-06-09 00:00:01 --> Database Driver Class Initialized
DEBUG - 2018-06-09 00:00:01 --> Session: Initialization under CLI aborted.
INFO - 2018-06-09 00:00:01 --> Helper loaded: form_helper
INFO - 2018-06-09 00:00:01 --> Form Validation Class Initialized
INFO - 2018-06-09 00:00:01 --> Controller Class Initialized
INFO - 2018-06-09 00:00:01 --> Model Class Initialized
INFO - 2018-06-09 00:00:01 --> Helper loaded: inflector_helper
DEBUG - 2018-06-09 00:00:01 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-09 00:00:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-09 00:00:01 --> Model Class Initialized
INFO - 2018-06-09 00:00:01 --> Model Class Initialized
INFO - 2018-06-09 00:00:01 --> Model Class Initialized
INFO - 2018-06-09 00:00:01 --> Model Class Initialized
INFO - 2018-06-09 00:00:01 --> Model Class Initialized
INFO - 2018-06-09 00:00:01 --> Model Class Initialized
INFO - 2018-06-09 00:00:01 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-09 00:00:01 --> Model Class Initialized
INFO - 2018-06-09 00:00:01 --> Final output sent to browser
DEBUG - 2018-06-09 00:00:01 --> Total execution time: 0.0722
INFO - 2018-06-09 18:30:02 --> Config Class Initialized
INFO - 2018-06-09 18:30:02 --> Hooks Class Initialized
DEBUG - 2018-06-09 18:30:02 --> UTF-8 Support Enabled
INFO - 2018-06-09 18:30:02 --> Utf8 Class Initialized
INFO - 2018-06-09 18:30:02 --> URI Class Initialized
INFO - 2018-06-09 18:30:02 --> Router Class Initialized
INFO - 2018-06-09 18:30:02 --> Output Class Initialized
INFO - 2018-06-09 18:30:02 --> Security Class Initialized
DEBUG - 2018-06-09 18:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-09 18:30:02 --> Input Class Initialized
INFO - 2018-06-09 18:30:02 --> Language Class Initialized
INFO - 2018-06-09 18:30:02 --> Language Class Initialized
INFO - 2018-06-09 18:30:02 --> Config Class Initialized
INFO - 2018-06-09 18:30:02 --> Loader Class Initialized
INFO - 2018-06-09 18:30:02 --> Config Class Initialized
INFO - 2018-06-09 18:30:02 --> Hooks Class Initialized
DEBUG - 2018-06-09 18:30:02 --> UTF-8 Support Enabled
INFO - 2018-06-09 18:30:02 --> Utf8 Class Initialized
INFO - 2018-06-09 18:30:02 --> URI Class Initialized
INFO - 2018-06-09 18:30:02 --> Router Class Initialized
INFO - 2018-06-09 18:30:02 --> Output Class Initialized
INFO - 2018-06-09 18:30:02 --> Security Class Initialized
DEBUG - 2018-06-09 18:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-09 18:30:02 --> Input Class Initialized
INFO - 2018-06-09 18:30:02 --> Language Class Initialized
INFO - 2018-06-09 18:30:02 --> Language Class Initialized
INFO - 2018-06-09 18:30:02 --> Config Class Initialized
INFO - 2018-06-09 18:30:02 --> Loader Class Initialized
