<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-03-13 10:48:05 --> Config Class Initialized
INFO - 2018-03-13 10:48:05 --> Hooks Class Initialized
DEBUG - 2018-03-13 10:48:05 --> UTF-8 Support Enabled
INFO - 2018-03-13 10:48:05 --> Utf8 Class Initialized
INFO - 2018-03-13 10:48:05 --> URI Class Initialized
INFO - 2018-03-13 10:48:05 --> Router Class Initialized
INFO - 2018-03-13 10:48:05 --> Output Class Initialized
INFO - 2018-03-13 10:48:05 --> Security Class Initialized
DEBUG - 2018-03-13 10:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 10:48:05 --> Input Class Initialized
INFO - 2018-03-13 10:48:05 --> Language Class Initialized
INFO - 2018-03-13 10:48:05 --> Language Class Initialized
INFO - 2018-03-13 10:48:05 --> Config Class Initialized
INFO - 2018-03-13 10:48:05 --> Loader Class Initialized
INFO - 2018-03-13 16:18:05 --> Helper loaded: url_helper
INFO - 2018-03-13 16:18:05 --> Helper loaded: notification_helper
INFO - 2018-03-13 16:18:05 --> Helper loaded: settings_helper
INFO - 2018-03-13 16:18:05 --> Helper loaded: permission_helper
INFO - 2018-03-13 16:18:05 --> Helper loaded: users_helper
INFO - 2018-03-13 16:18:05 --> Database Driver Class Initialized
DEBUG - 2018-03-13 16:18:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 16:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 16:18:06 --> Helper loaded: form_helper
INFO - 2018-03-13 16:18:06 --> Form Validation Class Initialized
INFO - 2018-03-13 16:18:06 --> Controller Class Initialized
INFO - 2018-03-13 16:18:06 --> Model Class Initialized
INFO - 2018-03-13 16:18:06 --> Helper loaded: inflector_helper
DEBUG - 2018-03-13 16:18:06 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-13 16:18:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-13 16:18:06 --> Model Class Initialized
INFO - 2018-03-13 16:18:06 --> Model Class Initialized
INFO - 2018-03-13 16:18:06 --> Model Class Initialized
INFO - 2018-03-13 16:18:06 --> Model Class Initialized
INFO - 2018-03-13 16:18:06 --> Model Class Initialized
INFO - 2018-03-13 16:18:06 --> Model Class Initialized
INFO - 2018-03-13 16:18:06 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-13 16:18:06 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`pr01004_1`.`logs`, CONSTRAINT `logs_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`users_id`) ON DELETE CASCADE ON UPDATE CASCADE) - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `ip_address`, `time`, `authorized`, `message`, `status`, `user_id`) VALUES ('api/users/userProfile', 'post', 'a:1:{s:8:\"users_id\";s:3:\"167\";}', '111.93.247.154', 1520938086, 1, 'User not found', 1, '167')
INFO - 2018-03-13 16:18:06 --> Final output sent to browser
DEBUG - 2018-03-13 16:18:06 --> Total execution time: 0.7764
INFO - 2018-03-13 10:51:06 --> Config Class Initialized
INFO - 2018-03-13 10:51:06 --> Hooks Class Initialized
DEBUG - 2018-03-13 10:51:06 --> UTF-8 Support Enabled
INFO - 2018-03-13 10:51:06 --> Utf8 Class Initialized
INFO - 2018-03-13 10:51:06 --> URI Class Initialized
INFO - 2018-03-13 10:51:06 --> Router Class Initialized
INFO - 2018-03-13 10:51:06 --> Output Class Initialized
INFO - 2018-03-13 10:51:06 --> Security Class Initialized
DEBUG - 2018-03-13 10:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 10:51:06 --> Input Class Initialized
INFO - 2018-03-13 10:51:06 --> Language Class Initialized
INFO - 2018-03-13 10:51:06 --> Language Class Initialized
INFO - 2018-03-13 10:51:06 --> Config Class Initialized
INFO - 2018-03-13 10:51:06 --> Loader Class Initialized
INFO - 2018-03-13 16:21:07 --> Helper loaded: url_helper
INFO - 2018-03-13 16:21:07 --> Helper loaded: notification_helper
INFO - 2018-03-13 16:21:07 --> Helper loaded: settings_helper
INFO - 2018-03-13 16:21:07 --> Helper loaded: permission_helper
INFO - 2018-03-13 16:21:07 --> Helper loaded: users_helper
INFO - 2018-03-13 16:21:07 --> Database Driver Class Initialized
DEBUG - 2018-03-13 16:21:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 16:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 16:21:07 --> Helper loaded: form_helper
INFO - 2018-03-13 16:21:07 --> Form Validation Class Initialized
INFO - 2018-03-13 16:21:07 --> Controller Class Initialized
INFO - 2018-03-13 10:51:08 --> Config Class Initialized
INFO - 2018-03-13 10:51:08 --> Hooks Class Initialized
DEBUG - 2018-03-13 10:51:08 --> UTF-8 Support Enabled
INFO - 2018-03-13 10:51:08 --> Utf8 Class Initialized
INFO - 2018-03-13 10:51:08 --> URI Class Initialized
INFO - 2018-03-13 10:51:08 --> Router Class Initialized
INFO - 2018-03-13 10:51:08 --> Output Class Initialized
INFO - 2018-03-13 10:51:08 --> Security Class Initialized
DEBUG - 2018-03-13 10:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 10:51:08 --> Input Class Initialized
INFO - 2018-03-13 10:51:08 --> Language Class Initialized
INFO - 2018-03-13 10:51:08 --> Language Class Initialized
INFO - 2018-03-13 10:51:08 --> Config Class Initialized
INFO - 2018-03-13 10:51:08 --> Loader Class Initialized
INFO - 2018-03-13 16:21:08 --> Helper loaded: url_helper
INFO - 2018-03-13 16:21:08 --> Helper loaded: notification_helper
INFO - 2018-03-13 16:21:08 --> Helper loaded: settings_helper
INFO - 2018-03-13 16:21:08 --> Helper loaded: permission_helper
INFO - 2018-03-13 16:21:08 --> Helper loaded: users_helper
INFO - 2018-03-13 16:21:08 --> Database Driver Class Initialized
DEBUG - 2018-03-13 16:21:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 16:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 16:21:08 --> Helper loaded: form_helper
INFO - 2018-03-13 16:21:08 --> Form Validation Class Initialized
INFO - 2018-03-13 16:21:08 --> Controller Class Initialized
INFO - 2018-03-13 16:21:08 --> Model Class Initialized
INFO - 2018-03-13 16:21:08 --> Helper loaded: inflector_helper
DEBUG - 2018-03-13 16:21:08 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-13 16:21:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-13 16:21:08 --> Model Class Initialized
INFO - 2018-03-13 16:21:08 --> Model Class Initialized
INFO - 2018-03-13 16:21:08 --> Model Class Initialized
INFO - 2018-03-13 16:21:08 --> Model Class Initialized
INFO - 2018-03-13 16:21:08 --> Model Class Initialized
INFO - 2018-03-13 16:21:08 --> Model Class Initialized
INFO - 2018-03-13 16:21:08 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-13 16:21:08 --> Final output sent to browser
DEBUG - 2018-03-13 16:21:08 --> Total execution time: 0.1150
INFO - 2018-03-13 16:21:08 --> Model Class Initialized
INFO - 2018-03-13 16:21:08 --> Helper loaded: inflector_helper
DEBUG - 2018-03-13 16:21:08 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-13 16:21:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-13 16:21:08 --> Model Class Initialized
INFO - 2018-03-13 16:21:08 --> Model Class Initialized
INFO - 2018-03-13 16:21:08 --> Model Class Initialized
INFO - 2018-03-13 16:21:08 --> Model Class Initialized
INFO - 2018-03-13 16:21:08 --> Model Class Initialized
INFO - 2018-03-13 16:21:08 --> Model Class Initialized
INFO - 2018-03-13 16:21:08 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-13 16:21:08 --> Final output sent to browser
DEBUG - 2018-03-13 16:21:08 --> Total execution time: 2.6413
INFO - 2018-03-13 10:56:30 --> Config Class Initialized
INFO - 2018-03-13 10:56:30 --> Hooks Class Initialized
DEBUG - 2018-03-13 10:56:30 --> UTF-8 Support Enabled
INFO - 2018-03-13 10:56:30 --> Utf8 Class Initialized
INFO - 2018-03-13 10:56:30 --> URI Class Initialized
INFO - 2018-03-13 10:56:31 --> Router Class Initialized
INFO - 2018-03-13 10:56:31 --> Output Class Initialized
INFO - 2018-03-13 10:56:31 --> Security Class Initialized
DEBUG - 2018-03-13 10:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 10:56:31 --> Input Class Initialized
INFO - 2018-03-13 10:56:31 --> Language Class Initialized
INFO - 2018-03-13 10:56:31 --> Language Class Initialized
INFO - 2018-03-13 10:56:31 --> Config Class Initialized
INFO - 2018-03-13 10:56:31 --> Loader Class Initialized
INFO - 2018-03-13 16:26:31 --> Helper loaded: url_helper
INFO - 2018-03-13 16:26:31 --> Helper loaded: notification_helper
INFO - 2018-03-13 16:26:31 --> Helper loaded: settings_helper
INFO - 2018-03-13 16:26:31 --> Helper loaded: permission_helper
INFO - 2018-03-13 16:26:31 --> Helper loaded: users_helper
INFO - 2018-03-13 16:26:31 --> Database Driver Class Initialized
DEBUG - 2018-03-13 16:26:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 16:26:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 16:26:31 --> Helper loaded: form_helper
INFO - 2018-03-13 16:26:31 --> Form Validation Class Initialized
INFO - 2018-03-13 16:26:31 --> Controller Class Initialized
INFO - 2018-03-13 16:26:31 --> Model Class Initialized
INFO - 2018-03-13 16:26:31 --> Helper loaded: inflector_helper
DEBUG - 2018-03-13 16:26:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-13 16:26:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-13 16:26:31 --> Model Class Initialized
INFO - 2018-03-13 16:26:31 --> Model Class Initialized
INFO - 2018-03-13 16:26:31 --> Model Class Initialized
INFO - 2018-03-13 16:26:31 --> Model Class Initialized
INFO - 2018-03-13 16:26:31 --> Model Class Initialized
INFO - 2018-03-13 16:26:31 --> Model Class Initialized
INFO - 2018-03-13 16:26:31 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-13 16:26:31 --> Final output sent to browser
DEBUG - 2018-03-13 16:26:31 --> Total execution time: 0.2357
INFO - 2018-03-13 10:57:12 --> Config Class Initialized
INFO - 2018-03-13 10:57:12 --> Hooks Class Initialized
DEBUG - 2018-03-13 10:57:12 --> UTF-8 Support Enabled
INFO - 2018-03-13 10:57:12 --> Utf8 Class Initialized
INFO - 2018-03-13 10:57:12 --> URI Class Initialized
INFO - 2018-03-13 10:57:12 --> Router Class Initialized
INFO - 2018-03-13 10:57:12 --> Output Class Initialized
INFO - 2018-03-13 10:57:12 --> Security Class Initialized
DEBUG - 2018-03-13 10:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 10:57:12 --> Input Class Initialized
INFO - 2018-03-13 10:57:12 --> Language Class Initialized
INFO - 2018-03-13 10:57:12 --> Language Class Initialized
INFO - 2018-03-13 10:57:12 --> Config Class Initialized
INFO - 2018-03-13 10:57:12 --> Loader Class Initialized
INFO - 2018-03-13 16:27:12 --> Helper loaded: url_helper
INFO - 2018-03-13 16:27:12 --> Helper loaded: notification_helper
INFO - 2018-03-13 16:27:12 --> Helper loaded: settings_helper
INFO - 2018-03-13 16:27:12 --> Helper loaded: permission_helper
INFO - 2018-03-13 16:27:12 --> Helper loaded: users_helper
INFO - 2018-03-13 16:27:12 --> Database Driver Class Initialized
DEBUG - 2018-03-13 16:27:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 16:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 16:27:12 --> Helper loaded: form_helper
INFO - 2018-03-13 16:27:12 --> Form Validation Class Initialized
INFO - 2018-03-13 16:27:12 --> Controller Class Initialized
INFO - 2018-03-13 16:27:12 --> Model Class Initialized
INFO - 2018-03-13 16:27:12 --> Helper loaded: inflector_helper
DEBUG - 2018-03-13 16:27:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-13 16:27:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-13 16:27:12 --> Model Class Initialized
INFO - 2018-03-13 16:27:12 --> Model Class Initialized
INFO - 2018-03-13 16:27:12 --> Model Class Initialized
INFO - 2018-03-13 16:27:12 --> Model Class Initialized
INFO - 2018-03-13 16:27:12 --> Model Class Initialized
INFO - 2018-03-13 16:27:12 --> Model Class Initialized
INFO - 2018-03-13 16:27:12 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-13 16:27:12 --> Final output sent to browser
DEBUG - 2018-03-13 16:27:12 --> Total execution time: 0.2836
INFO - 2018-03-13 11:04:30 --> Config Class Initialized
INFO - 2018-03-13 11:04:30 --> Hooks Class Initialized
DEBUG - 2018-03-13 11:04:30 --> UTF-8 Support Enabled
INFO - 2018-03-13 11:04:30 --> Utf8 Class Initialized
INFO - 2018-03-13 11:04:30 --> URI Class Initialized
INFO - 2018-03-13 11:04:30 --> Router Class Initialized
INFO - 2018-03-13 11:04:30 --> Output Class Initialized
INFO - 2018-03-13 11:04:30 --> Security Class Initialized
DEBUG - 2018-03-13 11:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 11:04:30 --> Input Class Initialized
INFO - 2018-03-13 11:04:30 --> Language Class Initialized
INFO - 2018-03-13 11:04:30 --> Language Class Initialized
INFO - 2018-03-13 11:04:30 --> Config Class Initialized
INFO - 2018-03-13 11:04:30 --> Loader Class Initialized
INFO - 2018-03-13 16:34:30 --> Helper loaded: url_helper
INFO - 2018-03-13 16:34:30 --> Helper loaded: notification_helper
INFO - 2018-03-13 16:34:30 --> Helper loaded: settings_helper
INFO - 2018-03-13 16:34:30 --> Helper loaded: permission_helper
INFO - 2018-03-13 16:34:30 --> Helper loaded: users_helper
INFO - 2018-03-13 16:34:30 --> Database Driver Class Initialized
DEBUG - 2018-03-13 16:34:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 16:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 16:34:30 --> Helper loaded: form_helper
INFO - 2018-03-13 16:34:30 --> Form Validation Class Initialized
INFO - 2018-03-13 16:34:30 --> Controller Class Initialized
INFO - 2018-03-13 16:34:30 --> Model Class Initialized
INFO - 2018-03-13 16:34:30 --> Helper loaded: inflector_helper
DEBUG - 2018-03-13 16:34:30 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-13 16:34:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-13 16:34:30 --> Model Class Initialized
INFO - 2018-03-13 16:34:30 --> Model Class Initialized
INFO - 2018-03-13 16:34:30 --> Model Class Initialized
INFO - 2018-03-13 16:34:30 --> Model Class Initialized
INFO - 2018-03-13 16:34:30 --> Model Class Initialized
INFO - 2018-03-13 16:34:30 --> Model Class Initialized
INFO - 2018-03-13 16:34:30 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-13 16:34:30 --> Final output sent to browser
DEBUG - 2018-03-13 16:34:30 --> Total execution time: 0.2387
INFO - 2018-03-13 11:04:31 --> Config Class Initialized
INFO - 2018-03-13 11:04:31 --> Hooks Class Initialized
DEBUG - 2018-03-13 11:04:31 --> UTF-8 Support Enabled
INFO - 2018-03-13 11:04:31 --> Utf8 Class Initialized
INFO - 2018-03-13 11:04:31 --> URI Class Initialized
INFO - 2018-03-13 11:04:31 --> Router Class Initialized
INFO - 2018-03-13 11:04:31 --> Output Class Initialized
INFO - 2018-03-13 11:04:31 --> Security Class Initialized
DEBUG - 2018-03-13 11:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 11:04:32 --> Input Class Initialized
INFO - 2018-03-13 11:04:32 --> Language Class Initialized
INFO - 2018-03-13 11:04:33 --> Language Class Initialized
INFO - 2018-03-13 11:04:33 --> Config Class Initialized
INFO - 2018-03-13 11:04:33 --> Loader Class Initialized
INFO - 2018-03-13 16:34:33 --> Helper loaded: url_helper
INFO - 2018-03-13 16:34:33 --> Helper loaded: notification_helper
INFO - 2018-03-13 16:34:33 --> Helper loaded: settings_helper
INFO - 2018-03-13 16:34:33 --> Helper loaded: permission_helper
INFO - 2018-03-13 16:34:33 --> Helper loaded: users_helper
INFO - 2018-03-13 16:34:34 --> Database Driver Class Initialized
DEBUG - 2018-03-13 16:34:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 16:34:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 16:34:34 --> Helper loaded: form_helper
INFO - 2018-03-13 16:34:34 --> Form Validation Class Initialized
INFO - 2018-03-13 16:34:34 --> Controller Class Initialized
INFO - 2018-03-13 16:34:34 --> Model Class Initialized
INFO - 2018-03-13 16:34:34 --> Helper loaded: inflector_helper
DEBUG - 2018-03-13 16:34:34 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-13 16:34:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-13 16:34:34 --> Model Class Initialized
INFO - 2018-03-13 16:34:34 --> Model Class Initialized
INFO - 2018-03-13 16:34:34 --> Model Class Initialized
INFO - 2018-03-13 16:34:34 --> Model Class Initialized
INFO - 2018-03-13 16:34:34 --> Model Class Initialized
INFO - 2018-03-13 16:34:34 --> Model Class Initialized
INFO - 2018-03-13 16:34:34 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-13 16:34:34 --> Final output sent to browser
DEBUG - 2018-03-13 16:34:34 --> Total execution time: 3.6481
INFO - 2018-03-13 11:05:17 --> Config Class Initialized
INFO - 2018-03-13 11:05:17 --> Hooks Class Initialized
DEBUG - 2018-03-13 11:05:18 --> UTF-8 Support Enabled
INFO - 2018-03-13 11:05:18 --> Utf8 Class Initialized
INFO - 2018-03-13 11:05:18 --> URI Class Initialized
INFO - 2018-03-13 11:05:18 --> Router Class Initialized
INFO - 2018-03-13 11:05:18 --> Output Class Initialized
INFO - 2018-03-13 11:05:18 --> Security Class Initialized
INFO - 2018-03-13 11:05:18 --> Config Class Initialized
INFO - 2018-03-13 11:05:18 --> Hooks Class Initialized
DEBUG - 2018-03-13 11:05:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 11:05:18 --> Input Class Initialized
DEBUG - 2018-03-13 11:05:18 --> UTF-8 Support Enabled
INFO - 2018-03-13 11:05:18 --> Utf8 Class Initialized
INFO - 2018-03-13 11:05:18 --> Language Class Initialized
INFO - 2018-03-13 11:05:18 --> URI Class Initialized
INFO - 2018-03-13 11:05:18 --> Router Class Initialized
INFO - 2018-03-13 11:05:18 --> Output Class Initialized
INFO - 2018-03-13 11:05:19 --> Security Class Initialized
DEBUG - 2018-03-13 11:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 11:05:19 --> Input Class Initialized
INFO - 2018-03-13 11:05:19 --> Language Class Initialized
INFO - 2018-03-13 11:05:19 --> Language Class Initialized
INFO - 2018-03-13 11:05:19 --> Config Class Initialized
INFO - 2018-03-13 11:05:19 --> Loader Class Initialized
INFO - 2018-03-13 16:35:19 --> Helper loaded: url_helper
INFO - 2018-03-13 16:35:19 --> Helper loaded: notification_helper
INFO - 2018-03-13 16:35:19 --> Helper loaded: settings_helper
INFO - 2018-03-13 16:35:19 --> Helper loaded: permission_helper
INFO - 2018-03-13 16:35:19 --> Helper loaded: users_helper
INFO - 2018-03-13 11:05:19 --> Language Class Initialized
INFO - 2018-03-13 11:05:19 --> Config Class Initialized
INFO - 2018-03-13 11:05:19 --> Loader Class Initialized
INFO - 2018-03-13 16:35:19 --> Helper loaded: url_helper
INFO - 2018-03-13 16:35:19 --> Helper loaded: notification_helper
INFO - 2018-03-13 16:35:19 --> Helper loaded: settings_helper
INFO - 2018-03-13 16:35:19 --> Helper loaded: permission_helper
INFO - 2018-03-13 16:35:19 --> Helper loaded: users_helper
INFO - 2018-03-13 16:35:19 --> Database Driver Class Initialized
DEBUG - 2018-03-13 16:35:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 16:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 16:35:19 --> Helper loaded: form_helper
INFO - 2018-03-13 16:35:19 --> Form Validation Class Initialized
INFO - 2018-03-13 16:35:19 --> Controller Class Initialized
INFO - 2018-03-13 16:35:19 --> Model Class Initialized
INFO - 2018-03-13 16:35:19 --> Helper loaded: inflector_helper
DEBUG - 2018-03-13 16:35:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-13 16:35:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-13 16:35:19 --> Model Class Initialized
INFO - 2018-03-13 16:35:19 --> Model Class Initialized
INFO - 2018-03-13 16:35:19 --> Model Class Initialized
INFO - 2018-03-13 16:35:19 --> Model Class Initialized
INFO - 2018-03-13 16:35:19 --> Model Class Initialized
INFO - 2018-03-13 16:35:19 --> Model Class Initialized
INFO - 2018-03-13 16:35:19 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-13 16:35:19 --> Final output sent to browser
DEBUG - 2018-03-13 16:35:19 --> Total execution time: 1.4184
INFO - 2018-03-13 16:35:20 --> Database Driver Class Initialized
DEBUG - 2018-03-13 16:35:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 16:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 16:35:20 --> Helper loaded: form_helper
INFO - 2018-03-13 16:35:20 --> Form Validation Class Initialized
INFO - 2018-03-13 16:35:20 --> Controller Class Initialized
INFO - 2018-03-13 16:35:20 --> Model Class Initialized
INFO - 2018-03-13 16:35:20 --> Helper loaded: inflector_helper
DEBUG - 2018-03-13 16:35:21 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-13 16:35:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-13 16:35:21 --> Model Class Initialized
INFO - 2018-03-13 16:35:21 --> Model Class Initialized
INFO - 2018-03-13 16:35:21 --> Model Class Initialized
INFO - 2018-03-13 16:35:21 --> Model Class Initialized
INFO - 2018-03-13 16:35:21 --> Model Class Initialized
INFO - 2018-03-13 16:35:21 --> Model Class Initialized
INFO - 2018-03-13 16:35:21 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-13 16:35:21 --> Final output sent to browser
DEBUG - 2018-03-13 16:35:21 --> Total execution time: 3.5511
INFO - 2018-03-13 11:08:50 --> Config Class Initialized
INFO - 2018-03-13 11:08:50 --> Hooks Class Initialized
DEBUG - 2018-03-13 11:08:50 --> UTF-8 Support Enabled
INFO - 2018-03-13 11:08:50 --> Utf8 Class Initialized
INFO - 2018-03-13 11:08:50 --> URI Class Initialized
INFO - 2018-03-13 11:08:50 --> Router Class Initialized
INFO - 2018-03-13 11:08:50 --> Output Class Initialized
INFO - 2018-03-13 11:08:50 --> Security Class Initialized
DEBUG - 2018-03-13 11:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 11:08:50 --> Input Class Initialized
INFO - 2018-03-13 11:08:50 --> Language Class Initialized
INFO - 2018-03-13 11:08:50 --> Language Class Initialized
INFO - 2018-03-13 11:08:50 --> Config Class Initialized
INFO - 2018-03-13 11:08:50 --> Loader Class Initialized
INFO - 2018-03-13 16:38:50 --> Helper loaded: url_helper
INFO - 2018-03-13 16:38:50 --> Helper loaded: notification_helper
INFO - 2018-03-13 16:38:50 --> Helper loaded: settings_helper
INFO - 2018-03-13 16:38:50 --> Helper loaded: permission_helper
INFO - 2018-03-13 16:38:50 --> Helper loaded: users_helper
INFO - 2018-03-13 16:38:51 --> Database Driver Class Initialized
DEBUG - 2018-03-13 16:38:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 16:38:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 16:38:51 --> Helper loaded: form_helper
INFO - 2018-03-13 16:38:51 --> Form Validation Class Initialized
INFO - 2018-03-13 16:38:51 --> Controller Class Initialized
INFO - 2018-03-13 16:38:51 --> Model Class Initialized
INFO - 2018-03-13 16:38:51 --> Helper loaded: inflector_helper
DEBUG - 2018-03-13 16:38:51 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-13 16:38:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-13 16:38:51 --> Model Class Initialized
INFO - 2018-03-13 16:38:51 --> Model Class Initialized
INFO - 2018-03-13 16:38:51 --> Model Class Initialized
INFO - 2018-03-13 16:38:51 --> Model Class Initialized
INFO - 2018-03-13 16:38:51 --> Model Class Initialized
INFO - 2018-03-13 16:38:51 --> Model Class Initialized
INFO - 2018-03-13 16:38:51 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-13 16:38:51 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`pr01004_1`.`logs`, CONSTRAINT `logs_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`users_id`) ON DELETE CASCADE ON UPDATE CASCADE) - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `ip_address`, `time`, `authorized`, `message`, `status`, `user_id`) VALUES ('api/users/userProfile', 'post', 'a:1:{s:8:\"users_id\";s:4:\"3040\";}', '111.93.247.154', 1520939331, 1, 'User not found', 1, '3040')
INFO - 2018-03-13 16:38:51 --> Final output sent to browser
DEBUG - 2018-03-13 16:38:51 --> Total execution time: 0.1285
INFO - 2018-03-13 11:10:33 --> Config Class Initialized
INFO - 2018-03-13 11:10:33 --> Hooks Class Initialized
DEBUG - 2018-03-13 11:10:33 --> UTF-8 Support Enabled
INFO - 2018-03-13 11:10:33 --> Utf8 Class Initialized
INFO - 2018-03-13 11:10:33 --> URI Class Initialized
INFO - 2018-03-13 11:10:33 --> Router Class Initialized
INFO - 2018-03-13 11:10:33 --> Output Class Initialized
INFO - 2018-03-13 11:10:33 --> Security Class Initialized
DEBUG - 2018-03-13 11:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 11:10:33 --> Input Class Initialized
INFO - 2018-03-13 11:10:33 --> Language Class Initialized
INFO - 2018-03-13 11:10:33 --> Language Class Initialized
INFO - 2018-03-13 11:10:33 --> Config Class Initialized
INFO - 2018-03-13 11:10:33 --> Loader Class Initialized
INFO - 2018-03-13 16:40:33 --> Helper loaded: url_helper
INFO - 2018-03-13 16:40:33 --> Helper loaded: notification_helper
INFO - 2018-03-13 16:40:33 --> Helper loaded: settings_helper
INFO - 2018-03-13 16:40:33 --> Helper loaded: permission_helper
INFO - 2018-03-13 16:40:33 --> Helper loaded: users_helper
INFO - 2018-03-13 16:40:33 --> Database Driver Class Initialized
DEBUG - 2018-03-13 16:40:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 16:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 16:40:33 --> Helper loaded: form_helper
INFO - 2018-03-13 16:40:33 --> Form Validation Class Initialized
INFO - 2018-03-13 16:40:33 --> Controller Class Initialized
INFO - 2018-03-13 16:40:33 --> Model Class Initialized
INFO - 2018-03-13 16:40:33 --> Helper loaded: inflector_helper
DEBUG - 2018-03-13 16:40:33 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-13 16:40:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-13 16:40:33 --> Model Class Initialized
INFO - 2018-03-13 16:40:33 --> Model Class Initialized
INFO - 2018-03-13 16:40:33 --> Model Class Initialized
INFO - 2018-03-13 16:40:33 --> Model Class Initialized
INFO - 2018-03-13 16:40:33 --> Model Class Initialized
INFO - 2018-03-13 16:40:33 --> Model Class Initialized
INFO - 2018-03-13 16:40:33 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-13 16:40:33 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`pr01004_1`.`logs`, CONSTRAINT `logs_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`users_id`) ON DELETE CASCADE ON UPDATE CASCADE) - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `ip_address`, `time`, `authorized`, `message`, `status`, `user_id`) VALUES ('api/users/userProfile', 'post', 'a:1:{s:8:\"users_id\";s:4:\"3040\";}', '111.93.247.154', 1520939433, 1, 'User not found', 1, '3040')
INFO - 2018-03-13 16:40:33 --> Final output sent to browser
DEBUG - 2018-03-13 16:40:33 --> Total execution time: 0.1101
INFO - 2018-03-13 11:12:06 --> Config Class Initialized
INFO - 2018-03-13 11:12:06 --> Hooks Class Initialized
DEBUG - 2018-03-13 11:12:06 --> UTF-8 Support Enabled
INFO - 2018-03-13 11:12:06 --> Utf8 Class Initialized
INFO - 2018-03-13 11:12:06 --> URI Class Initialized
INFO - 2018-03-13 11:12:06 --> Router Class Initialized
INFO - 2018-03-13 11:12:06 --> Output Class Initialized
INFO - 2018-03-13 11:12:06 --> Security Class Initialized
DEBUG - 2018-03-13 11:12:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 11:12:06 --> Input Class Initialized
INFO - 2018-03-13 11:12:06 --> Language Class Initialized
INFO - 2018-03-13 11:12:06 --> Language Class Initialized
INFO - 2018-03-13 11:12:06 --> Config Class Initialized
INFO - 2018-03-13 11:12:06 --> Loader Class Initialized
INFO - 2018-03-13 16:42:06 --> Helper loaded: url_helper
INFO - 2018-03-13 16:42:06 --> Helper loaded: notification_helper
INFO - 2018-03-13 16:42:06 --> Helper loaded: settings_helper
INFO - 2018-03-13 16:42:06 --> Helper loaded: permission_helper
INFO - 2018-03-13 16:42:06 --> Helper loaded: users_helper
INFO - 2018-03-13 16:42:06 --> Database Driver Class Initialized
DEBUG - 2018-03-13 16:42:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 16:42:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 16:42:06 --> Helper loaded: form_helper
INFO - 2018-03-13 16:42:06 --> Form Validation Class Initialized
INFO - 2018-03-13 16:42:06 --> Controller Class Initialized
INFO - 2018-03-13 16:42:06 --> Model Class Initialized
INFO - 2018-03-13 16:42:06 --> Helper loaded: inflector_helper
DEBUG - 2018-03-13 16:42:06 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-13 16:42:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-13 16:42:06 --> Model Class Initialized
INFO - 2018-03-13 16:42:06 --> Model Class Initialized
INFO - 2018-03-13 16:42:06 --> Model Class Initialized
INFO - 2018-03-13 16:42:06 --> Model Class Initialized
INFO - 2018-03-13 16:42:06 --> Model Class Initialized
INFO - 2018-03-13 16:42:06 --> Model Class Initialized
INFO - 2018-03-13 16:42:06 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-13 16:42:06 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`pr01004_1`.`logs`, CONSTRAINT `logs_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`users_id`) ON DELETE CASCADE ON UPDATE CASCADE) - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `ip_address`, `time`, `authorized`, `message`, `status`, `user_id`) VALUES ('api/users/userProfile', 'post', 'a:1:{s:8:\"users_id\";s:4:\"3040\";}', '111.93.247.154', 1520939526, 1, 'User not found', 1, '3040')
INFO - 2018-03-13 16:42:06 --> Final output sent to browser
DEBUG - 2018-03-13 16:42:06 --> Total execution time: 0.5433
INFO - 2018-03-13 11:12:29 --> Config Class Initialized
INFO - 2018-03-13 11:12:29 --> Hooks Class Initialized
DEBUG - 2018-03-13 11:12:29 --> UTF-8 Support Enabled
INFO - 2018-03-13 11:12:29 --> Utf8 Class Initialized
INFO - 2018-03-13 11:12:29 --> URI Class Initialized
INFO - 2018-03-13 11:12:29 --> Router Class Initialized
INFO - 2018-03-13 11:12:29 --> Output Class Initialized
INFO - 2018-03-13 11:12:29 --> Security Class Initialized
DEBUG - 2018-03-13 11:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 11:12:29 --> Input Class Initialized
INFO - 2018-03-13 11:12:29 --> Language Class Initialized
INFO - 2018-03-13 11:12:29 --> Language Class Initialized
INFO - 2018-03-13 11:12:29 --> Config Class Initialized
INFO - 2018-03-13 11:12:29 --> Loader Class Initialized
INFO - 2018-03-13 16:42:29 --> Helper loaded: url_helper
INFO - 2018-03-13 16:42:29 --> Helper loaded: notification_helper
INFO - 2018-03-13 16:42:29 --> Helper loaded: settings_helper
INFO - 2018-03-13 16:42:29 --> Helper loaded: permission_helper
INFO - 2018-03-13 16:42:29 --> Helper loaded: users_helper
INFO - 2018-03-13 16:42:29 --> Database Driver Class Initialized
DEBUG - 2018-03-13 16:42:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 16:42:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 16:42:29 --> Helper loaded: form_helper
INFO - 2018-03-13 16:42:29 --> Form Validation Class Initialized
INFO - 2018-03-13 16:42:29 --> Controller Class Initialized
INFO - 2018-03-13 16:42:29 --> Model Class Initialized
INFO - 2018-03-13 16:42:29 --> Helper loaded: inflector_helper
DEBUG - 2018-03-13 16:42:29 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-13 16:42:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-13 16:42:30 --> Model Class Initialized
INFO - 2018-03-13 16:42:30 --> Model Class Initialized
INFO - 2018-03-13 16:42:30 --> Model Class Initialized
INFO - 2018-03-13 16:42:30 --> Model Class Initialized
INFO - 2018-03-13 16:42:30 --> Model Class Initialized
INFO - 2018-03-13 16:42:30 --> Model Class Initialized
INFO - 2018-03-13 16:42:30 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-13 16:42:30 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`pr01004_1`.`logs`, CONSTRAINT `logs_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`users_id`) ON DELETE CASCADE ON UPDATE CASCADE) - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `ip_address`, `time`, `authorized`, `message`, `status`, `user_id`) VALUES ('api/users/userProfile', 'post', 'a:1:{s:8:\"users_id\";s:4:\"3040\";}', '111.93.247.154', 1520939550, 1, 'User not found', 1, '3040')
INFO - 2018-03-13 16:42:30 --> Final output sent to browser
DEBUG - 2018-03-13 16:42:30 --> Total execution time: 1.1595
INFO - 2018-03-13 11:13:50 --> Config Class Initialized
INFO - 2018-03-13 11:13:50 --> Hooks Class Initialized
DEBUG - 2018-03-13 11:13:50 --> UTF-8 Support Enabled
INFO - 2018-03-13 11:13:50 --> Utf8 Class Initialized
INFO - 2018-03-13 11:13:50 --> URI Class Initialized
INFO - 2018-03-13 11:13:50 --> Router Class Initialized
INFO - 2018-03-13 11:13:50 --> Output Class Initialized
INFO - 2018-03-13 11:13:51 --> Security Class Initialized
DEBUG - 2018-03-13 11:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 11:13:51 --> Input Class Initialized
INFO - 2018-03-13 11:13:51 --> Language Class Initialized
INFO - 2018-03-13 11:13:51 --> Language Class Initialized
INFO - 2018-03-13 11:13:51 --> Config Class Initialized
INFO - 2018-03-13 11:13:51 --> Loader Class Initialized
INFO - 2018-03-13 16:43:51 --> Helper loaded: url_helper
INFO - 2018-03-13 16:43:51 --> Helper loaded: notification_helper
INFO - 2018-03-13 16:43:51 --> Helper loaded: settings_helper
INFO - 2018-03-13 16:43:51 --> Helper loaded: permission_helper
INFO - 2018-03-13 16:43:51 --> Helper loaded: users_helper
INFO - 2018-03-13 11:13:52 --> Config Class Initialized
INFO - 2018-03-13 11:13:52 --> Hooks Class Initialized
DEBUG - 2018-03-13 11:13:52 --> UTF-8 Support Enabled
INFO - 2018-03-13 11:13:52 --> Utf8 Class Initialized
INFO - 2018-03-13 11:13:52 --> URI Class Initialized
INFO - 2018-03-13 11:13:52 --> Router Class Initialized
INFO - 2018-03-13 11:13:52 --> Output Class Initialized
INFO - 2018-03-13 11:13:52 --> Security Class Initialized
DEBUG - 2018-03-13 11:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 11:13:52 --> Input Class Initialized
INFO - 2018-03-13 11:13:52 --> Language Class Initialized
INFO - 2018-03-13 11:13:52 --> Language Class Initialized
INFO - 2018-03-13 11:13:52 --> Config Class Initialized
INFO - 2018-03-13 11:13:52 --> Loader Class Initialized
INFO - 2018-03-13 16:43:52 --> Helper loaded: url_helper
INFO - 2018-03-13 16:43:52 --> Helper loaded: notification_helper
INFO - 2018-03-13 16:43:52 --> Helper loaded: settings_helper
INFO - 2018-03-13 16:43:52 --> Helper loaded: permission_helper
INFO - 2018-03-13 16:43:52 --> Helper loaded: users_helper
INFO - 2018-03-13 16:43:52 --> Database Driver Class Initialized
DEBUG - 2018-03-13 16:43:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 16:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 16:43:52 --> Helper loaded: form_helper
INFO - 2018-03-13 16:43:52 --> Form Validation Class Initialized
INFO - 2018-03-13 16:43:52 --> Controller Class Initialized
INFO - 2018-03-13 16:43:52 --> Model Class Initialized
INFO - 2018-03-13 16:43:52 --> Helper loaded: inflector_helper
DEBUG - 2018-03-13 16:43:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-13 16:43:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-13 16:43:52 --> Model Class Initialized
INFO - 2018-03-13 16:43:52 --> Model Class Initialized
INFO - 2018-03-13 16:43:52 --> Model Class Initialized
INFO - 2018-03-13 16:43:52 --> Model Class Initialized
INFO - 2018-03-13 16:43:52 --> Model Class Initialized
INFO - 2018-03-13 16:43:52 --> Model Class Initialized
INFO - 2018-03-13 16:43:52 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-13 16:43:52 --> Database Driver Class Initialized
ERROR - 2018-03-13 16:43:52 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`pr01004_1`.`logs`, CONSTRAINT `logs_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`users_id`) ON DELETE CASCADE ON UPDATE CASCADE) - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `ip_address`, `time`, `authorized`, `message`, `status`, `user_id`) VALUES ('api/users/userProfile', 'post', 'a:1:{s:8:\"users_id\";s:4:\"3040\";}', '111.93.247.154', 1520939632, 1, 'User not found', 1, '3040')
INFO - 2018-03-13 16:43:52 --> Final output sent to browser
DEBUG - 2018-03-13 16:43:52 --> Total execution time: 2.0788
DEBUG - 2018-03-13 16:43:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 16:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 16:43:52 --> Helper loaded: form_helper
INFO - 2018-03-13 16:43:52 --> Form Validation Class Initialized
INFO - 2018-03-13 16:43:52 --> Controller Class Initialized
INFO - 2018-03-13 16:43:52 --> Model Class Initialized
INFO - 2018-03-13 16:43:52 --> Helper loaded: inflector_helper
DEBUG - 2018-03-13 16:43:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-13 16:43:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-13 16:43:52 --> Model Class Initialized
INFO - 2018-03-13 16:43:52 --> Model Class Initialized
INFO - 2018-03-13 16:43:52 --> Model Class Initialized
INFO - 2018-03-13 16:43:52 --> Model Class Initialized
INFO - 2018-03-13 16:43:52 --> Model Class Initialized
INFO - 2018-03-13 16:43:52 --> Model Class Initialized
INFO - 2018-03-13 16:43:52 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-13 16:43:52 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`pr01004_1`.`logs`, CONSTRAINT `logs_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`users_id`) ON DELETE CASCADE ON UPDATE CASCADE) - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `ip_address`, `time`, `authorized`, `message`, `status`, `user_id`) VALUES ('api/users/userProfile', 'post', 'a:1:{s:8:\"users_id\";s:4:\"3040\";}', '111.93.247.154', 1520939632, 1, 'User not found', 1, '3040')
INFO - 2018-03-13 16:43:52 --> Final output sent to browser
DEBUG - 2018-03-13 16:43:52 --> Total execution time: 0.7057
INFO - 2018-03-13 11:14:44 --> Config Class Initialized
INFO - 2018-03-13 11:14:44 --> Hooks Class Initialized
DEBUG - 2018-03-13 11:14:44 --> UTF-8 Support Enabled
INFO - 2018-03-13 11:14:44 --> Utf8 Class Initialized
INFO - 2018-03-13 11:14:44 --> URI Class Initialized
INFO - 2018-03-13 11:14:45 --> Router Class Initialized
INFO - 2018-03-13 11:14:45 --> Output Class Initialized
INFO - 2018-03-13 11:14:45 --> Security Class Initialized
DEBUG - 2018-03-13 11:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 11:14:45 --> Input Class Initialized
INFO - 2018-03-13 11:14:45 --> Language Class Initialized
INFO - 2018-03-13 11:14:45 --> Language Class Initialized
INFO - 2018-03-13 11:14:45 --> Config Class Initialized
INFO - 2018-03-13 11:14:45 --> Loader Class Initialized
INFO - 2018-03-13 16:44:45 --> Helper loaded: url_helper
INFO - 2018-03-13 16:44:45 --> Helper loaded: notification_helper
INFO - 2018-03-13 16:44:45 --> Helper loaded: settings_helper
INFO - 2018-03-13 16:44:45 --> Helper loaded: permission_helper
INFO - 2018-03-13 16:44:45 --> Helper loaded: users_helper
INFO - 2018-03-13 16:44:45 --> Database Driver Class Initialized
DEBUG - 2018-03-13 16:44:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 16:44:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 16:44:45 --> Helper loaded: form_helper
INFO - 2018-03-13 16:44:45 --> Form Validation Class Initialized
INFO - 2018-03-13 16:44:45 --> Controller Class Initialized
INFO - 2018-03-13 16:44:45 --> Model Class Initialized
INFO - 2018-03-13 16:44:45 --> Helper loaded: inflector_helper
DEBUG - 2018-03-13 16:44:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-13 16:44:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-13 16:44:45 --> Model Class Initialized
INFO - 2018-03-13 16:44:45 --> Model Class Initialized
INFO - 2018-03-13 16:44:45 --> Model Class Initialized
INFO - 2018-03-13 16:44:45 --> Model Class Initialized
INFO - 2018-03-13 16:44:45 --> Model Class Initialized
INFO - 2018-03-13 16:44:45 --> Model Class Initialized
INFO - 2018-03-13 16:44:45 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-13 16:44:45 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`pr01004_1`.`logs`, CONSTRAINT `logs_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`users_id`) ON DELETE CASCADE ON UPDATE CASCADE) - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `ip_address`, `time`, `authorized`, `message`, `status`, `user_id`) VALUES ('api/users/userProfile', 'post', 'a:1:{s:8:\"users_id\";s:4:\"3040\";}', '111.93.247.154', 1520939685, 1, 'User not found', 1, '3040')
INFO - 2018-03-13 16:44:45 --> Final output sent to browser
DEBUG - 2018-03-13 16:44:45 --> Total execution time: 0.5795
INFO - 2018-03-13 11:16:39 --> Config Class Initialized
INFO - 2018-03-13 11:16:39 --> Hooks Class Initialized
DEBUG - 2018-03-13 11:16:39 --> UTF-8 Support Enabled
INFO - 2018-03-13 11:16:39 --> Utf8 Class Initialized
INFO - 2018-03-13 11:16:39 --> URI Class Initialized
INFO - 2018-03-13 11:16:39 --> Router Class Initialized
INFO - 2018-03-13 11:16:39 --> Output Class Initialized
INFO - 2018-03-13 11:16:39 --> Security Class Initialized
DEBUG - 2018-03-13 11:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 11:16:39 --> Input Class Initialized
INFO - 2018-03-13 11:16:39 --> Language Class Initialized
INFO - 2018-03-13 11:16:39 --> Language Class Initialized
INFO - 2018-03-13 11:16:39 --> Config Class Initialized
INFO - 2018-03-13 11:16:39 --> Loader Class Initialized
INFO - 2018-03-13 16:46:39 --> Helper loaded: url_helper
INFO - 2018-03-13 16:46:39 --> Helper loaded: notification_helper
INFO - 2018-03-13 16:46:39 --> Helper loaded: settings_helper
INFO - 2018-03-13 16:46:39 --> Helper loaded: permission_helper
INFO - 2018-03-13 16:46:39 --> Helper loaded: users_helper
INFO - 2018-03-13 16:46:39 --> Database Driver Class Initialized
DEBUG - 2018-03-13 16:46:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 16:46:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 16:46:39 --> Helper loaded: form_helper
INFO - 2018-03-13 16:46:39 --> Form Validation Class Initialized
INFO - 2018-03-13 16:46:39 --> Controller Class Initialized
INFO - 2018-03-13 16:46:39 --> Model Class Initialized
INFO - 2018-03-13 16:46:39 --> Helper loaded: inflector_helper
DEBUG - 2018-03-13 16:46:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-13 16:46:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-13 16:46:39 --> Model Class Initialized
INFO - 2018-03-13 16:46:39 --> Model Class Initialized
INFO - 2018-03-13 16:46:39 --> Model Class Initialized
INFO - 2018-03-13 16:46:39 --> Model Class Initialized
INFO - 2018-03-13 16:46:39 --> Model Class Initialized
INFO - 2018-03-13 16:46:39 --> Model Class Initialized
INFO - 2018-03-13 16:46:39 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-13 16:46:39 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`pr01004_1`.`logs`, CONSTRAINT `logs_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`users_id`) ON DELETE CASCADE ON UPDATE CASCADE) - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `ip_address`, `time`, `authorized`, `message`, `status`, `user_id`) VALUES ('api/users/userProfile', 'post', 'a:1:{s:8:\"users_id\";s:1:\" \";}', '111.93.247.154', 1520939799, 1, 'User not found', 1, ' ')
INFO - 2018-03-13 16:46:39 --> Final output sent to browser
DEBUG - 2018-03-13 16:46:39 --> Total execution time: 0.2287
INFO - 2018-03-13 11:18:33 --> Config Class Initialized
INFO - 2018-03-13 11:18:33 --> Hooks Class Initialized
DEBUG - 2018-03-13 11:18:33 --> UTF-8 Support Enabled
INFO - 2018-03-13 11:18:33 --> Utf8 Class Initialized
INFO - 2018-03-13 11:18:34 --> URI Class Initialized
INFO - 2018-03-13 11:18:34 --> Router Class Initialized
INFO - 2018-03-13 11:18:34 --> Output Class Initialized
INFO - 2018-03-13 11:18:34 --> Security Class Initialized
DEBUG - 2018-03-13 11:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 11:18:34 --> Input Class Initialized
INFO - 2018-03-13 11:18:34 --> Language Class Initialized
INFO - 2018-03-13 11:18:36 --> Language Class Initialized
INFO - 2018-03-13 11:18:36 --> Config Class Initialized
INFO - 2018-03-13 11:18:36 --> Loader Class Initialized
INFO - 2018-03-13 16:48:36 --> Helper loaded: url_helper
INFO - 2018-03-13 16:48:36 --> Helper loaded: notification_helper
INFO - 2018-03-13 16:48:36 --> Helper loaded: settings_helper
INFO - 2018-03-13 16:48:36 --> Helper loaded: permission_helper
INFO - 2018-03-13 16:48:36 --> Helper loaded: users_helper
INFO - 2018-03-13 16:48:36 --> Database Driver Class Initialized
DEBUG - 2018-03-13 16:48:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 16:48:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 16:48:36 --> Helper loaded: form_helper
INFO - 2018-03-13 16:48:36 --> Form Validation Class Initialized
INFO - 2018-03-13 16:48:36 --> Controller Class Initialized
INFO - 2018-03-13 16:48:36 --> Model Class Initialized
INFO - 2018-03-13 16:48:36 --> Helper loaded: inflector_helper
DEBUG - 2018-03-13 16:48:36 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-13 16:48:36 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-13 16:48:36 --> Model Class Initialized
INFO - 2018-03-13 16:48:36 --> Model Class Initialized
INFO - 2018-03-13 16:48:36 --> Model Class Initialized
INFO - 2018-03-13 16:48:36 --> Model Class Initialized
INFO - 2018-03-13 16:48:36 --> Model Class Initialized
INFO - 2018-03-13 16:48:36 --> Model Class Initialized
INFO - 2018-03-13 16:48:36 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-13 16:48:37 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`pr01004_1`.`logs`, CONSTRAINT `logs_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`users_id`) ON DELETE CASCADE ON UPDATE CASCADE) - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `ip_address`, `time`, `authorized`, `message`, `status`, `user_id`) VALUES ('api/users/userProfile', 'post', 'a:1:{s:8:\"users_id\";s:1:\" \";}', '111.93.247.154', 1520939917, 1, 'User not found', 1, ' ')
INFO - 2018-03-13 16:48:37 --> Final output sent to browser
DEBUG - 2018-03-13 16:48:37 --> Total execution time: 3.3086
INFO - 2018-03-13 11:18:38 --> Config Class Initialized
INFO - 2018-03-13 11:18:38 --> Hooks Class Initialized
DEBUG - 2018-03-13 11:18:38 --> UTF-8 Support Enabled
INFO - 2018-03-13 11:18:38 --> Utf8 Class Initialized
INFO - 2018-03-13 11:18:38 --> URI Class Initialized
INFO - 2018-03-13 11:18:38 --> Router Class Initialized
INFO - 2018-03-13 11:18:39 --> Output Class Initialized
INFO - 2018-03-13 11:18:39 --> Security Class Initialized
DEBUG - 2018-03-13 11:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 11:18:39 --> Input Class Initialized
INFO - 2018-03-13 11:18:39 --> Language Class Initialized
INFO - 2018-03-13 11:18:40 --> Language Class Initialized
INFO - 2018-03-13 11:18:40 --> Config Class Initialized
INFO - 2018-03-13 11:18:40 --> Loader Class Initialized
INFO - 2018-03-13 16:48:40 --> Helper loaded: url_helper
INFO - 2018-03-13 16:48:40 --> Helper loaded: notification_helper
INFO - 2018-03-13 16:48:40 --> Helper loaded: settings_helper
INFO - 2018-03-13 16:48:40 --> Helper loaded: permission_helper
INFO - 2018-03-13 16:48:40 --> Helper loaded: users_helper
INFO - 2018-03-13 16:48:40 --> Database Driver Class Initialized
DEBUG - 2018-03-13 16:48:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 16:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 16:48:40 --> Helper loaded: form_helper
INFO - 2018-03-13 16:48:40 --> Form Validation Class Initialized
INFO - 2018-03-13 16:48:40 --> Controller Class Initialized
INFO - 2018-03-13 16:48:40 --> Model Class Initialized
INFO - 2018-03-13 16:48:40 --> Helper loaded: inflector_helper
DEBUG - 2018-03-13 16:48:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-13 16:48:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-13 16:48:40 --> Model Class Initialized
INFO - 2018-03-13 16:48:40 --> Model Class Initialized
INFO - 2018-03-13 16:48:40 --> Model Class Initialized
INFO - 2018-03-13 16:48:40 --> Model Class Initialized
INFO - 2018-03-13 16:48:40 --> Model Class Initialized
INFO - 2018-03-13 16:48:40 --> Model Class Initialized
INFO - 2018-03-13 16:48:40 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-13 16:48:40 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`pr01004_1`.`logs`, CONSTRAINT `logs_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`users_id`) ON DELETE CASCADE ON UPDATE CASCADE) - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `ip_address`, `time`, `authorized`, `message`, `status`, `user_id`) VALUES ('api/users/userProfile', 'post', 'a:1:{s:8:\"users_id\";s:1:\" \";}', '111.93.247.154', 1520939920, 1, 'User not found', 1, ' ')
INFO - 2018-03-13 16:48:40 --> Final output sent to browser
DEBUG - 2018-03-13 16:48:40 --> Total execution time: 3.2165
INFO - 2018-03-13 11:19:11 --> Config Class Initialized
INFO - 2018-03-13 11:19:11 --> Hooks Class Initialized
DEBUG - 2018-03-13 11:19:11 --> UTF-8 Support Enabled
INFO - 2018-03-13 11:19:11 --> Utf8 Class Initialized
INFO - 2018-03-13 11:19:11 --> URI Class Initialized
INFO - 2018-03-13 11:19:11 --> Router Class Initialized
INFO - 2018-03-13 11:19:11 --> Output Class Initialized
INFO - 2018-03-13 11:19:11 --> Security Class Initialized
DEBUG - 2018-03-13 11:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 11:19:11 --> Input Class Initialized
INFO - 2018-03-13 11:19:11 --> Language Class Initialized
INFO - 2018-03-13 11:19:11 --> Language Class Initialized
INFO - 2018-03-13 11:19:11 --> Config Class Initialized
INFO - 2018-03-13 11:19:11 --> Loader Class Initialized
INFO - 2018-03-13 16:49:11 --> Helper loaded: url_helper
INFO - 2018-03-13 16:49:11 --> Helper loaded: notification_helper
INFO - 2018-03-13 16:49:11 --> Helper loaded: settings_helper
INFO - 2018-03-13 16:49:11 --> Helper loaded: permission_helper
INFO - 2018-03-13 16:49:11 --> Helper loaded: users_helper
INFO - 2018-03-13 16:49:12 --> Database Driver Class Initialized
DEBUG - 2018-03-13 16:49:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 16:49:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 16:49:12 --> Helper loaded: form_helper
INFO - 2018-03-13 16:49:12 --> Form Validation Class Initialized
INFO - 2018-03-13 16:49:12 --> Controller Class Initialized
INFO - 2018-03-13 16:49:13 --> Model Class Initialized
INFO - 2018-03-13 16:49:13 --> Helper loaded: inflector_helper
DEBUG - 2018-03-13 16:49:13 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-13 16:49:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-13 11:19:13 --> Config Class Initialized
INFO - 2018-03-13 11:19:13 --> Hooks Class Initialized
DEBUG - 2018-03-13 11:19:13 --> UTF-8 Support Enabled
INFO - 2018-03-13 11:19:13 --> Utf8 Class Initialized
INFO - 2018-03-13 11:19:13 --> URI Class Initialized
INFO - 2018-03-13 11:19:13 --> Router Class Initialized
INFO - 2018-03-13 11:19:13 --> Output Class Initialized
INFO - 2018-03-13 11:19:13 --> Security Class Initialized
DEBUG - 2018-03-13 11:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 11:19:13 --> Input Class Initialized
INFO - 2018-03-13 16:49:13 --> Model Class Initialized
INFO - 2018-03-13 11:19:13 --> Language Class Initialized
INFO - 2018-03-13 11:19:13 --> Language Class Initialized
INFO - 2018-03-13 11:19:13 --> Config Class Initialized
INFO - 2018-03-13 11:19:13 --> Loader Class Initialized
INFO - 2018-03-13 16:49:13 --> Model Class Initialized
INFO - 2018-03-13 16:49:13 --> Helper loaded: url_helper
INFO - 2018-03-13 16:49:13 --> Helper loaded: notification_helper
INFO - 2018-03-13 16:49:13 --> Helper loaded: settings_helper
INFO - 2018-03-13 16:49:13 --> Helper loaded: permission_helper
INFO - 2018-03-13 16:49:13 --> Helper loaded: users_helper
INFO - 2018-03-13 16:49:13 --> Database Driver Class Initialized
DEBUG - 2018-03-13 16:49:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 16:49:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 16:49:13 --> Helper loaded: form_helper
INFO - 2018-03-13 16:49:13 --> Form Validation Class Initialized
INFO - 2018-03-13 16:49:13 --> Controller Class Initialized
INFO - 2018-03-13 16:49:13 --> Model Class Initialized
INFO - 2018-03-13 16:49:13 --> Model Class Initialized
INFO - 2018-03-13 16:49:13 --> Helper loaded: inflector_helper
DEBUG - 2018-03-13 16:49:13 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-13 16:49:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-13 16:49:13 --> Model Class Initialized
INFO - 2018-03-13 16:49:13 --> Model Class Initialized
INFO - 2018-03-13 16:49:13 --> Model Class Initialized
INFO - 2018-03-13 16:49:13 --> Model Class Initialized
INFO - 2018-03-13 16:49:13 --> Model Class Initialized
INFO - 2018-03-13 16:49:13 --> Model Class Initialized
INFO - 2018-03-13 16:49:13 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-13 16:49:13 --> Model Class Initialized
INFO - 2018-03-13 16:49:13 --> Model Class Initialized
ERROR - 2018-03-13 16:49:13 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`pr01004_1`.`logs`, CONSTRAINT `logs_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`users_id`) ON DELETE CASCADE ON UPDATE CASCADE) - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `ip_address`, `time`, `authorized`, `message`, `status`, `user_id`) VALUES ('api/users/userProfile', 'post', 'a:1:{s:8:\"users_id\";s:1:\" \";}', '111.93.247.154', 1520939953, 1, 'User not found', 1, ' ')
INFO - 2018-03-13 16:49:13 --> Final output sent to browser
DEBUG - 2018-03-13 16:49:13 --> Total execution time: 0.2286
INFO - 2018-03-13 16:49:13 --> Model Class Initialized
INFO - 2018-03-13 16:49:13 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-13 16:49:13 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`pr01004_1`.`logs`, CONSTRAINT `logs_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`users_id`) ON DELETE CASCADE ON UPDATE CASCADE) - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `ip_address`, `time`, `authorized`, `message`, `status`, `user_id`) VALUES ('api/users/userProfile', 'post', 'a:1:{s:8:\"users_id\";s:1:\" \";}', '111.93.247.154', 1520939953, 1, 'User not found', 1, ' ')
INFO - 2018-03-13 16:49:13 --> Final output sent to browser
DEBUG - 2018-03-13 16:49:13 --> Total execution time: 2.8556
INFO - 2018-03-13 11:26:35 --> Config Class Initialized
INFO - 2018-03-13 11:26:35 --> Hooks Class Initialized
DEBUG - 2018-03-13 11:26:35 --> UTF-8 Support Enabled
INFO - 2018-03-13 11:26:35 --> Utf8 Class Initialized
INFO - 2018-03-13 11:26:35 --> URI Class Initialized
INFO - 2018-03-13 11:26:36 --> Router Class Initialized
INFO - 2018-03-13 11:26:36 --> Output Class Initialized
INFO - 2018-03-13 11:26:36 --> Security Class Initialized
DEBUG - 2018-03-13 11:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 11:26:36 --> Input Class Initialized
INFO - 2018-03-13 11:26:36 --> Language Class Initialized
INFO - 2018-03-13 11:26:36 --> Language Class Initialized
INFO - 2018-03-13 11:26:36 --> Config Class Initialized
INFO - 2018-03-13 11:26:36 --> Loader Class Initialized
INFO - 2018-03-13 16:56:36 --> Helper loaded: url_helper
INFO - 2018-03-13 16:56:36 --> Helper loaded: notification_helper
INFO - 2018-03-13 16:56:36 --> Helper loaded: settings_helper
INFO - 2018-03-13 16:56:36 --> Helper loaded: permission_helper
INFO - 2018-03-13 16:56:36 --> Helper loaded: users_helper
INFO - 2018-03-13 16:56:36 --> Database Driver Class Initialized
DEBUG - 2018-03-13 16:56:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 16:56:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 16:56:37 --> Helper loaded: form_helper
INFO - 2018-03-13 16:56:37 --> Form Validation Class Initialized
INFO - 2018-03-13 16:56:37 --> Controller Class Initialized
INFO - 2018-03-13 16:56:37 --> Model Class Initialized
INFO - 2018-03-13 16:56:37 --> Helper loaded: inflector_helper
DEBUG - 2018-03-13 16:56:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-13 16:56:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-13 16:56:37 --> Model Class Initialized
INFO - 2018-03-13 16:56:37 --> Model Class Initialized
INFO - 2018-03-13 16:56:37 --> Model Class Initialized
INFO - 2018-03-13 16:56:37 --> Model Class Initialized
INFO - 2018-03-13 16:56:37 --> Model Class Initialized
INFO - 2018-03-13 16:56:37 --> Model Class Initialized
INFO - 2018-03-13 16:56:37 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-13 16:56:37 --> Final output sent to browser
DEBUG - 2018-03-13 16:56:37 --> Total execution time: 2.0059
INFO - 2018-03-13 11:26:38 --> Config Class Initialized
INFO - 2018-03-13 11:26:38 --> Hooks Class Initialized
DEBUG - 2018-03-13 11:26:38 --> UTF-8 Support Enabled
INFO - 2018-03-13 11:26:38 --> Utf8 Class Initialized
INFO - 2018-03-13 11:26:38 --> URI Class Initialized
INFO - 2018-03-13 11:26:38 --> Router Class Initialized
INFO - 2018-03-13 11:26:38 --> Output Class Initialized
INFO - 2018-03-13 11:26:38 --> Security Class Initialized
DEBUG - 2018-03-13 11:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 11:26:38 --> Input Class Initialized
INFO - 2018-03-13 11:26:38 --> Language Class Initialized
INFO - 2018-03-13 11:26:39 --> Language Class Initialized
INFO - 2018-03-13 11:26:39 --> Config Class Initialized
INFO - 2018-03-13 11:26:39 --> Loader Class Initialized
INFO - 2018-03-13 16:56:39 --> Helper loaded: url_helper
INFO - 2018-03-13 16:56:39 --> Helper loaded: notification_helper
INFO - 2018-03-13 16:56:39 --> Helper loaded: settings_helper
INFO - 2018-03-13 16:56:39 --> Helper loaded: permission_helper
INFO - 2018-03-13 16:56:39 --> Helper loaded: users_helper
INFO - 2018-03-13 16:56:39 --> Database Driver Class Initialized
DEBUG - 2018-03-13 16:56:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 16:56:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 16:56:39 --> Helper loaded: form_helper
INFO - 2018-03-13 16:56:39 --> Form Validation Class Initialized
INFO - 2018-03-13 16:56:39 --> Controller Class Initialized
INFO - 2018-03-13 16:56:39 --> Model Class Initialized
INFO - 2018-03-13 16:56:39 --> Helper loaded: inflector_helper
DEBUG - 2018-03-13 16:56:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-13 16:56:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-13 16:56:39 --> Model Class Initialized
INFO - 2018-03-13 16:56:39 --> Model Class Initialized
INFO - 2018-03-13 16:56:39 --> Model Class Initialized
INFO - 2018-03-13 16:56:39 --> Model Class Initialized
INFO - 2018-03-13 16:56:39 --> Model Class Initialized
INFO - 2018-03-13 16:56:39 --> Model Class Initialized
INFO - 2018-03-13 16:56:39 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-13 16:56:39 --> Final output sent to browser
DEBUG - 2018-03-13 16:56:39 --> Total execution time: 1.2893
INFO - 2018-03-13 11:26:54 --> Config Class Initialized
INFO - 2018-03-13 11:26:54 --> Hooks Class Initialized
DEBUG - 2018-03-13 11:26:54 --> UTF-8 Support Enabled
INFO - 2018-03-13 11:26:54 --> Utf8 Class Initialized
INFO - 2018-03-13 11:26:54 --> URI Class Initialized
INFO - 2018-03-13 11:26:54 --> Router Class Initialized
INFO - 2018-03-13 11:26:54 --> Output Class Initialized
INFO - 2018-03-13 11:26:54 --> Security Class Initialized
DEBUG - 2018-03-13 11:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 11:26:54 --> Input Class Initialized
INFO - 2018-03-13 11:26:54 --> Language Class Initialized
INFO - 2018-03-13 11:26:55 --> Language Class Initialized
INFO - 2018-03-13 11:26:55 --> Config Class Initialized
INFO - 2018-03-13 11:26:55 --> Loader Class Initialized
INFO - 2018-03-13 16:56:55 --> Helper loaded: url_helper
INFO - 2018-03-13 16:56:55 --> Helper loaded: notification_helper
INFO - 2018-03-13 16:56:55 --> Helper loaded: settings_helper
INFO - 2018-03-13 16:56:55 --> Helper loaded: permission_helper
INFO - 2018-03-13 16:56:55 --> Helper loaded: users_helper
INFO - 2018-03-13 16:56:56 --> Database Driver Class Initialized
DEBUG - 2018-03-13 16:56:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 16:56:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 16:56:56 --> Helper loaded: form_helper
INFO - 2018-03-13 16:56:56 --> Form Validation Class Initialized
INFO - 2018-03-13 16:56:56 --> Controller Class Initialized
INFO - 2018-03-13 16:56:56 --> Model Class Initialized
INFO - 2018-03-13 16:56:56 --> Helper loaded: inflector_helper
DEBUG - 2018-03-13 16:56:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-13 16:56:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-13 16:56:56 --> Model Class Initialized
INFO - 2018-03-13 16:56:56 --> Model Class Initialized
INFO - 2018-03-13 16:56:56 --> Model Class Initialized
INFO - 2018-03-13 16:56:56 --> Model Class Initialized
INFO - 2018-03-13 16:56:56 --> Model Class Initialized
INFO - 2018-03-13 16:56:56 --> Model Class Initialized
INFO - 2018-03-13 16:56:56 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-13 16:56:56 --> Final output sent to browser
DEBUG - 2018-03-13 16:56:56 --> Total execution time: 1.6618
INFO - 2018-03-13 11:27:39 --> Config Class Initialized
INFO - 2018-03-13 11:27:39 --> Hooks Class Initialized
DEBUG - 2018-03-13 11:27:39 --> UTF-8 Support Enabled
INFO - 2018-03-13 11:27:39 --> Utf8 Class Initialized
INFO - 2018-03-13 11:27:39 --> URI Class Initialized
INFO - 2018-03-13 11:27:39 --> Router Class Initialized
INFO - 2018-03-13 11:27:39 --> Output Class Initialized
INFO - 2018-03-13 11:27:39 --> Security Class Initialized
INFO - 2018-03-13 11:27:39 --> Config Class Initialized
INFO - 2018-03-13 11:27:39 --> Hooks Class Initialized
DEBUG - 2018-03-13 11:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 11:27:39 --> Input Class Initialized
INFO - 2018-03-13 11:27:39 --> Config Class Initialized
INFO - 2018-03-13 11:27:39 --> Hooks Class Initialized
DEBUG - 2018-03-13 11:27:39 --> UTF-8 Support Enabled
INFO - 2018-03-13 11:27:39 --> Utf8 Class Initialized
INFO - 2018-03-13 11:27:39 --> Language Class Initialized
DEBUG - 2018-03-13 11:27:39 --> UTF-8 Support Enabled
INFO - 2018-03-13 11:27:39 --> Utf8 Class Initialized
INFO - 2018-03-13 11:27:39 --> URI Class Initialized
INFO - 2018-03-13 11:27:39 --> URI Class Initialized
INFO - 2018-03-13 11:27:39 --> Router Class Initialized
INFO - 2018-03-13 11:27:39 --> Router Class Initialized
INFO - 2018-03-13 11:27:39 --> Output Class Initialized
INFO - 2018-03-13 11:27:39 --> Output Class Initialized
INFO - 2018-03-13 11:27:39 --> Security Class Initialized
INFO - 2018-03-13 11:27:39 --> Security Class Initialized
DEBUG - 2018-03-13 11:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 11:27:39 --> Input Class Initialized
INFO - 2018-03-13 11:27:39 --> Language Class Initialized
DEBUG - 2018-03-13 11:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 11:27:39 --> Input Class Initialized
INFO - 2018-03-13 11:27:39 --> Language Class Initialized
INFO - 2018-03-13 11:27:39 --> Language Class Initialized
INFO - 2018-03-13 11:27:39 --> Config Class Initialized
INFO - 2018-03-13 11:27:39 --> Loader Class Initialized
INFO - 2018-03-13 16:57:39 --> Helper loaded: url_helper
INFO - 2018-03-13 16:57:39 --> Helper loaded: notification_helper
INFO - 2018-03-13 16:57:39 --> Helper loaded: settings_helper
INFO - 2018-03-13 16:57:39 --> Helper loaded: permission_helper
INFO - 2018-03-13 16:57:39 --> Helper loaded: users_helper
INFO - 2018-03-13 11:27:40 --> Language Class Initialized
INFO - 2018-03-13 11:27:40 --> Config Class Initialized
INFO - 2018-03-13 11:27:40 --> Loader Class Initialized
INFO - 2018-03-13 16:57:40 --> Helper loaded: url_helper
INFO - 2018-03-13 16:57:40 --> Helper loaded: notification_helper
INFO - 2018-03-13 16:57:40 --> Helper loaded: settings_helper
INFO - 2018-03-13 16:57:40 --> Database Driver Class Initialized
INFO - 2018-03-13 16:57:40 --> Helper loaded: permission_helper
INFO - 2018-03-13 16:57:40 --> Helper loaded: users_helper
DEBUG - 2018-03-13 16:57:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 16:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 16:57:40 --> Helper loaded: form_helper
INFO - 2018-03-13 16:57:40 --> Form Validation Class Initialized
INFO - 2018-03-13 16:57:40 --> Controller Class Initialized
INFO - 2018-03-13 16:57:40 --> Database Driver Class Initialized
INFO - 2018-03-13 11:27:40 --> Language Class Initialized
INFO - 2018-03-13 11:27:40 --> Config Class Initialized
INFO - 2018-03-13 11:27:40 --> Loader Class Initialized
INFO - 2018-03-13 16:57:40 --> Helper loaded: url_helper
INFO - 2018-03-13 16:57:40 --> Helper loaded: notification_helper
INFO - 2018-03-13 16:57:40 --> Helper loaded: settings_helper
DEBUG - 2018-03-13 16:57:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 16:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 16:57:40 --> Helper loaded: permission_helper
INFO - 2018-03-13 16:57:40 --> Helper loaded: users_helper
INFO - 2018-03-13 16:57:40 --> Model Class Initialized
INFO - 2018-03-13 16:57:40 --> Helper loaded: inflector_helper
DEBUG - 2018-03-13 16:57:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-13 16:57:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-13 16:57:40 --> Helper loaded: form_helper
INFO - 2018-03-13 16:57:40 --> Model Class Initialized
INFO - 2018-03-13 16:57:40 --> Form Validation Class Initialized
INFO - 2018-03-13 16:57:40 --> Controller Class Initialized
INFO - 2018-03-13 16:57:40 --> Model Class Initialized
INFO - 2018-03-13 16:57:40 --> Model Class Initialized
INFO - 2018-03-13 16:57:40 --> Model Class Initialized
INFO - 2018-03-13 16:57:40 --> Model Class Initialized
INFO - 2018-03-13 16:57:40 --> Model Class Initialized
INFO - 2018-03-13 16:57:40 --> Helper loaded: inflector_helper
INFO - 2018-03-13 16:57:40 --> Model Class Initialized
DEBUG - 2018-03-13 16:57:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-13 16:57:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-13 16:57:40 --> Model Class Initialized
INFO - 2018-03-13 16:57:40 --> Model Class Initialized
INFO - 2018-03-13 16:57:40 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-13 16:57:40 --> Model Class Initialized
INFO - 2018-03-13 16:57:40 --> Model Class Initialized
INFO - 2018-03-13 16:57:40 --> Model Class Initialized
INFO - 2018-03-13 16:57:40 --> Model Class Initialized
INFO - 2018-03-13 16:57:40 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-13 16:57:40 --> Final output sent to browser
DEBUG - 2018-03-13 16:57:40 --> Total execution time: 0.4133
INFO - 2018-03-13 16:57:40 --> Database Driver Class Initialized
DEBUG - 2018-03-13 16:57:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 16:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 16:57:40 --> Model Class Initialized
INFO - 2018-03-13 16:57:40 --> Helper loaded: form_helper
INFO - 2018-03-13 16:57:40 --> Form Validation Class Initialized
INFO - 2018-03-13 16:57:40 --> Controller Class Initialized
INFO - 2018-03-13 16:57:40 --> Model Class Initialized
INFO - 2018-03-13 16:57:40 --> Helper loaded: inflector_helper
DEBUG - 2018-03-13 16:57:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-13 16:57:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-13 16:57:40 --> Model Class Initialized
INFO - 2018-03-13 16:57:40 --> Model Class Initialized
INFO - 2018-03-13 16:57:40 --> Model Class Initialized
INFO - 2018-03-13 16:57:40 --> Final output sent to browser
DEBUG - 2018-03-13 16:57:40 --> Total execution time: 0.5757
INFO - 2018-03-13 16:57:40 --> Model Class Initialized
INFO - 2018-03-13 16:57:40 --> Model Class Initialized
INFO - 2018-03-13 16:57:40 --> Model Class Initialized
INFO - 2018-03-13 16:57:40 --> Model Class Initialized
INFO - 2018-03-13 16:57:40 --> Model Class Initialized
INFO - 2018-03-13 16:57:40 --> Model Class Initialized
INFO - 2018-03-13 16:57:40 --> Model Class Initialized
INFO - 2018-03-13 16:57:40 --> Model Class Initialized
INFO - 2018-03-13 16:57:40 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-13 16:57:40 --> Model Class Initialized
INFO - 2018-03-13 16:57:42 --> Final output sent to browser
DEBUG - 2018-03-13 16:57:42 --> Total execution time: 2.4372
INFO - 2018-03-13 11:27:44 --> Config Class Initialized
INFO - 2018-03-13 11:27:44 --> Hooks Class Initialized
DEBUG - 2018-03-13 11:27:45 --> UTF-8 Support Enabled
INFO - 2018-03-13 11:27:45 --> Utf8 Class Initialized
INFO - 2018-03-13 11:27:45 --> URI Class Initialized
INFO - 2018-03-13 11:27:45 --> Router Class Initialized
INFO - 2018-03-13 11:27:45 --> Output Class Initialized
INFO - 2018-03-13 11:27:45 --> Security Class Initialized
DEBUG - 2018-03-13 11:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 11:27:45 --> Input Class Initialized
INFO - 2018-03-13 11:27:45 --> Language Class Initialized
INFO - 2018-03-13 11:27:45 --> Config Class Initialized
INFO - 2018-03-13 11:27:45 --> Hooks Class Initialized
DEBUG - 2018-03-13 11:27:45 --> UTF-8 Support Enabled
INFO - 2018-03-13 11:27:45 --> Utf8 Class Initialized
INFO - 2018-03-13 11:27:45 --> Language Class Initialized
INFO - 2018-03-13 11:27:45 --> Config Class Initialized
INFO - 2018-03-13 11:27:45 --> Loader Class Initialized
INFO - 2018-03-13 11:27:45 --> URI Class Initialized
INFO - 2018-03-13 16:57:45 --> Helper loaded: url_helper
INFO - 2018-03-13 11:27:45 --> Router Class Initialized
INFO - 2018-03-13 16:57:45 --> Helper loaded: notification_helper
INFO - 2018-03-13 16:57:45 --> Helper loaded: settings_helper
INFO - 2018-03-13 16:57:45 --> Helper loaded: permission_helper
INFO - 2018-03-13 16:57:45 --> Helper loaded: users_helper
INFO - 2018-03-13 11:27:45 --> Output Class Initialized
INFO - 2018-03-13 11:27:45 --> Security Class Initialized
DEBUG - 2018-03-13 11:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 11:27:45 --> Input Class Initialized
INFO - 2018-03-13 11:27:45 --> Language Class Initialized
INFO - 2018-03-13 16:57:45 --> Database Driver Class Initialized
DEBUG - 2018-03-13 16:57:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 16:57:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 16:57:45 --> Helper loaded: form_helper
INFO - 2018-03-13 16:57:45 --> Form Validation Class Initialized
INFO - 2018-03-13 16:57:45 --> Controller Class Initialized
INFO - 2018-03-13 16:57:45 --> Model Class Initialized
INFO - 2018-03-13 16:57:45 --> Helper loaded: inflector_helper
DEBUG - 2018-03-13 16:57:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-13 16:57:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-13 16:57:45 --> Model Class Initialized
INFO - 2018-03-13 16:57:45 --> Model Class Initialized
INFO - 2018-03-13 16:57:45 --> Model Class Initialized
INFO - 2018-03-13 16:57:45 --> Model Class Initialized
INFO - 2018-03-13 16:57:45 --> Model Class Initialized
INFO - 2018-03-13 16:57:45 --> Model Class Initialized
INFO - 2018-03-13 16:57:45 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-13 16:57:45 --> Final output sent to browser
DEBUG - 2018-03-13 16:57:45 --> Total execution time: 0.4682
INFO - 2018-03-13 11:27:45 --> Language Class Initialized
INFO - 2018-03-13 11:27:45 --> Config Class Initialized
INFO - 2018-03-13 11:27:45 --> Loader Class Initialized
INFO - 2018-03-13 16:57:45 --> Helper loaded: url_helper
INFO - 2018-03-13 16:57:45 --> Helper loaded: notification_helper
INFO - 2018-03-13 16:57:45 --> Helper loaded: settings_helper
INFO - 2018-03-13 16:57:45 --> Helper loaded: permission_helper
INFO - 2018-03-13 16:57:45 --> Helper loaded: users_helper
INFO - 2018-03-13 16:57:45 --> Database Driver Class Initialized
DEBUG - 2018-03-13 16:57:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 16:57:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 16:57:45 --> Helper loaded: form_helper
INFO - 2018-03-13 16:57:45 --> Form Validation Class Initialized
INFO - 2018-03-13 16:57:45 --> Controller Class Initialized
INFO - 2018-03-13 16:57:45 --> Model Class Initialized
INFO - 2018-03-13 16:57:45 --> Helper loaded: inflector_helper
DEBUG - 2018-03-13 16:57:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-13 16:57:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-13 16:57:45 --> Model Class Initialized
INFO - 2018-03-13 16:57:45 --> Model Class Initialized
INFO - 2018-03-13 16:57:45 --> Model Class Initialized
INFO - 2018-03-13 16:57:45 --> Model Class Initialized
INFO - 2018-03-13 16:57:45 --> Model Class Initialized
INFO - 2018-03-13 16:57:45 --> Model Class Initialized
INFO - 2018-03-13 16:57:45 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-13 16:57:45 --> Final output sent to browser
DEBUG - 2018-03-13 16:57:45 --> Total execution time: 0.5726
INFO - 2018-03-13 11:27:49 --> Config Class Initialized
INFO - 2018-03-13 11:27:49 --> Hooks Class Initialized
DEBUG - 2018-03-13 11:27:49 --> UTF-8 Support Enabled
INFO - 2018-03-13 11:27:49 --> Utf8 Class Initialized
INFO - 2018-03-13 11:27:49 --> URI Class Initialized
INFO - 2018-03-13 11:27:49 --> Router Class Initialized
INFO - 2018-03-13 11:27:49 --> Output Class Initialized
INFO - 2018-03-13 11:27:49 --> Security Class Initialized
DEBUG - 2018-03-13 11:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 11:27:49 --> Input Class Initialized
INFO - 2018-03-13 11:27:49 --> Language Class Initialized
INFO - 2018-03-13 11:27:49 --> Language Class Initialized
INFO - 2018-03-13 11:27:49 --> Config Class Initialized
INFO - 2018-03-13 11:27:49 --> Loader Class Initialized
INFO - 2018-03-13 16:57:49 --> Helper loaded: url_helper
INFO - 2018-03-13 16:57:49 --> Helper loaded: notification_helper
INFO - 2018-03-13 16:57:49 --> Helper loaded: settings_helper
INFO - 2018-03-13 16:57:49 --> Helper loaded: permission_helper
INFO - 2018-03-13 16:57:49 --> Helper loaded: users_helper
INFO - 2018-03-13 16:57:49 --> Database Driver Class Initialized
DEBUG - 2018-03-13 16:57:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 16:57:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 16:57:49 --> Helper loaded: form_helper
INFO - 2018-03-13 16:57:49 --> Form Validation Class Initialized
INFO - 2018-03-13 16:57:49 --> Controller Class Initialized
INFO - 2018-03-13 16:57:49 --> Model Class Initialized
INFO - 2018-03-13 16:57:49 --> Helper loaded: inflector_helper
DEBUG - 2018-03-13 16:57:49 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-13 16:57:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-13 16:57:49 --> Model Class Initialized
INFO - 2018-03-13 16:57:49 --> Model Class Initialized
INFO - 2018-03-13 16:57:49 --> Model Class Initialized
INFO - 2018-03-13 16:57:49 --> Model Class Initialized
INFO - 2018-03-13 16:57:49 --> Model Class Initialized
INFO - 2018-03-13 16:57:49 --> Model Class Initialized
INFO - 2018-03-13 16:57:49 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-13 16:57:49 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`pr01004_1`.`logs`, CONSTRAINT `logs_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`users_id`) ON DELETE CASCADE ON UPDATE CASCADE) - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `ip_address`, `time`, `authorized`, `message`, `status`, `user_id`) VALUES ('api/users/userProfile', 'post', 'a:1:{s:8:\"users_id\";s:4:\"3040\";}', '111.93.247.154', 1520940469, 1, 'User not found', 1, '3040')
INFO - 2018-03-13 16:57:49 --> Final output sent to browser
DEBUG - 2018-03-13 16:57:49 --> Total execution time: 0.1079
INFO - 2018-03-13 11:40:32 --> Config Class Initialized
INFO - 2018-03-13 11:40:32 --> Hooks Class Initialized
DEBUG - 2018-03-13 11:40:32 --> UTF-8 Support Enabled
INFO - 2018-03-13 11:40:32 --> Utf8 Class Initialized
INFO - 2018-03-13 11:40:32 --> URI Class Initialized
INFO - 2018-03-13 11:40:32 --> Router Class Initialized
INFO - 2018-03-13 11:40:32 --> Output Class Initialized
INFO - 2018-03-13 11:40:33 --> Security Class Initialized
DEBUG - 2018-03-13 11:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 11:40:33 --> Input Class Initialized
INFO - 2018-03-13 11:40:33 --> Language Class Initialized
INFO - 2018-03-13 11:40:33 --> Language Class Initialized
INFO - 2018-03-13 11:40:33 --> Config Class Initialized
INFO - 2018-03-13 11:40:33 --> Loader Class Initialized
INFO - 2018-03-13 17:10:33 --> Helper loaded: url_helper
INFO - 2018-03-13 17:10:33 --> Helper loaded: notification_helper
INFO - 2018-03-13 17:10:33 --> Helper loaded: settings_helper
INFO - 2018-03-13 17:10:33 --> Helper loaded: permission_helper
INFO - 2018-03-13 17:10:33 --> Helper loaded: users_helper
INFO - 2018-03-13 17:10:33 --> Database Driver Class Initialized
DEBUG - 2018-03-13 17:10:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 17:10:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 17:10:33 --> Helper loaded: form_helper
INFO - 2018-03-13 17:10:33 --> Form Validation Class Initialized
INFO - 2018-03-13 17:10:33 --> Controller Class Initialized
INFO - 2018-03-13 17:10:33 --> Model Class Initialized
INFO - 2018-03-13 17:10:33 --> Helper loaded: inflector_helper
DEBUG - 2018-03-13 17:10:33 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-13 17:10:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-13 17:10:33 --> Model Class Initialized
INFO - 2018-03-13 17:10:33 --> Model Class Initialized
INFO - 2018-03-13 17:10:33 --> Model Class Initialized
INFO - 2018-03-13 17:10:33 --> Model Class Initialized
INFO - 2018-03-13 17:10:34 --> Model Class Initialized
INFO - 2018-03-13 17:10:34 --> Model Class Initialized
INFO - 2018-03-13 17:10:34 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-13 17:10:34 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`pr01004_1`.`logs`, CONSTRAINT `logs_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`users_id`) ON DELETE CASCADE ON UPDATE CASCADE) - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `ip_address`, `time`, `authorized`, `message`, `status`, `user_id`) VALUES ('api/users/userProfile', 'post', 'a:1:{s:8:\"users_id\";s:4:\"3040\";}', '111.93.247.154', 1520941234, 1, 'User not found', 1, '3040')
INFO - 2018-03-13 17:10:34 --> Final output sent to browser
DEBUG - 2018-03-13 17:10:34 --> Total execution time: 1.2369
INFO - 2018-03-13 11:40:35 --> Config Class Initialized
INFO - 2018-03-13 11:40:35 --> Hooks Class Initialized
DEBUG - 2018-03-13 11:40:35 --> UTF-8 Support Enabled
INFO - 2018-03-13 11:40:35 --> Utf8 Class Initialized
INFO - 2018-03-13 11:40:35 --> URI Class Initialized
INFO - 2018-03-13 11:40:35 --> Router Class Initialized
INFO - 2018-03-13 11:40:35 --> Output Class Initialized
INFO - 2018-03-13 11:40:35 --> Security Class Initialized
DEBUG - 2018-03-13 11:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 11:40:35 --> Input Class Initialized
INFO - 2018-03-13 11:40:35 --> Language Class Initialized
INFO - 2018-03-13 11:40:35 --> Language Class Initialized
INFO - 2018-03-13 11:40:35 --> Config Class Initialized
INFO - 2018-03-13 11:40:35 --> Loader Class Initialized
INFO - 2018-03-13 17:10:35 --> Helper loaded: url_helper
INFO - 2018-03-13 17:10:35 --> Helper loaded: notification_helper
INFO - 2018-03-13 17:10:35 --> Helper loaded: settings_helper
INFO - 2018-03-13 17:10:35 --> Helper loaded: permission_helper
INFO - 2018-03-13 17:10:35 --> Helper loaded: users_helper
INFO - 2018-03-13 17:10:35 --> Database Driver Class Initialized
DEBUG - 2018-03-13 17:10:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 17:10:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 17:10:35 --> Helper loaded: form_helper
INFO - 2018-03-13 17:10:35 --> Form Validation Class Initialized
INFO - 2018-03-13 17:10:35 --> Controller Class Initialized
INFO - 2018-03-13 17:10:35 --> Model Class Initialized
INFO - 2018-03-13 17:10:35 --> Helper loaded: inflector_helper
DEBUG - 2018-03-13 17:10:35 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-13 17:10:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-13 17:10:35 --> Model Class Initialized
INFO - 2018-03-13 17:10:35 --> Model Class Initialized
INFO - 2018-03-13 17:10:35 --> Model Class Initialized
INFO - 2018-03-13 17:10:35 --> Model Class Initialized
INFO - 2018-03-13 17:10:35 --> Model Class Initialized
INFO - 2018-03-13 17:10:35 --> Model Class Initialized
INFO - 2018-03-13 17:10:35 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-13 17:10:35 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`pr01004_1`.`logs`, CONSTRAINT `logs_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`users_id`) ON DELETE CASCADE ON UPDATE CASCADE) - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `ip_address`, `time`, `authorized`, `message`, `status`, `user_id`) VALUES ('api/users/userProfile', 'post', 'a:1:{s:8:\"users_id\";s:4:\"3040\";}', '111.93.247.154', 1520941235, 1, 'User not found', 1, '3040')
INFO - 2018-03-13 17:10:35 --> Final output sent to browser
DEBUG - 2018-03-13 17:10:35 --> Total execution time: 0.1980
INFO - 2018-03-13 11:51:51 --> Config Class Initialized
INFO - 2018-03-13 11:51:51 --> Hooks Class Initialized
DEBUG - 2018-03-13 11:51:51 --> UTF-8 Support Enabled
INFO - 2018-03-13 11:51:51 --> Utf8 Class Initialized
INFO - 2018-03-13 11:51:51 --> URI Class Initialized
INFO - 2018-03-13 11:51:51 --> Router Class Initialized
INFO - 2018-03-13 11:51:51 --> Output Class Initialized
INFO - 2018-03-13 11:51:51 --> Security Class Initialized
DEBUG - 2018-03-13 11:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 11:51:51 --> Input Class Initialized
INFO - 2018-03-13 11:51:51 --> Language Class Initialized
INFO - 2018-03-13 11:51:51 --> Language Class Initialized
INFO - 2018-03-13 11:51:51 --> Config Class Initialized
INFO - 2018-03-13 11:51:51 --> Loader Class Initialized
INFO - 2018-03-13 17:21:51 --> Helper loaded: url_helper
INFO - 2018-03-13 17:21:51 --> Helper loaded: notification_helper
INFO - 2018-03-13 17:21:51 --> Helper loaded: settings_helper
INFO - 2018-03-13 17:21:51 --> Helper loaded: permission_helper
INFO - 2018-03-13 17:21:51 --> Helper loaded: users_helper
INFO - 2018-03-13 17:21:51 --> Database Driver Class Initialized
DEBUG - 2018-03-13 17:21:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 17:21:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 17:21:51 --> Helper loaded: form_helper
INFO - 2018-03-13 17:21:51 --> Form Validation Class Initialized
INFO - 2018-03-13 17:21:51 --> Controller Class Initialized
INFO - 2018-03-13 17:21:51 --> Model Class Initialized
INFO - 2018-03-13 17:21:51 --> Helper loaded: inflector_helper
DEBUG - 2018-03-13 17:21:51 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-13 17:21:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-13 17:21:51 --> Model Class Initialized
INFO - 2018-03-13 17:21:51 --> Model Class Initialized
INFO - 2018-03-13 17:21:51 --> Model Class Initialized
INFO - 2018-03-13 17:21:51 --> Model Class Initialized
INFO - 2018-03-13 17:21:51 --> Model Class Initialized
INFO - 2018-03-13 17:21:51 --> Model Class Initialized
INFO - 2018-03-13 17:21:51 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-13 17:21:51 --> Final output sent to browser
DEBUG - 2018-03-13 17:21:51 --> Total execution time: 0.1196
INFO - 2018-03-13 11:52:16 --> Config Class Initialized
INFO - 2018-03-13 11:52:16 --> Hooks Class Initialized
DEBUG - 2018-03-13 11:52:16 --> UTF-8 Support Enabled
INFO - 2018-03-13 11:52:16 --> Utf8 Class Initialized
INFO - 2018-03-13 11:52:16 --> URI Class Initialized
INFO - 2018-03-13 11:52:16 --> Router Class Initialized
INFO - 2018-03-13 11:52:16 --> Output Class Initialized
INFO - 2018-03-13 11:52:16 --> Security Class Initialized
DEBUG - 2018-03-13 11:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 11:52:16 --> Input Class Initialized
INFO - 2018-03-13 11:52:16 --> Language Class Initialized
INFO - 2018-03-13 11:52:16 --> Language Class Initialized
INFO - 2018-03-13 11:52:16 --> Config Class Initialized
INFO - 2018-03-13 11:52:16 --> Loader Class Initialized
INFO - 2018-03-13 17:22:16 --> Helper loaded: url_helper
INFO - 2018-03-13 17:22:16 --> Helper loaded: notification_helper
INFO - 2018-03-13 17:22:16 --> Helper loaded: settings_helper
INFO - 2018-03-13 17:22:16 --> Helper loaded: permission_helper
INFO - 2018-03-13 17:22:16 --> Helper loaded: users_helper
INFO - 2018-03-13 17:22:16 --> Database Driver Class Initialized
DEBUG - 2018-03-13 17:22:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 17:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 17:22:16 --> Helper loaded: form_helper
INFO - 2018-03-13 17:22:16 --> Form Validation Class Initialized
INFO - 2018-03-13 17:22:16 --> Controller Class Initialized
INFO - 2018-03-13 17:22:16 --> Model Class Initialized
INFO - 2018-03-13 17:22:16 --> Helper loaded: inflector_helper
DEBUG - 2018-03-13 17:22:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-13 17:22:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-13 17:22:16 --> Model Class Initialized
INFO - 2018-03-13 17:22:16 --> Model Class Initialized
INFO - 2018-03-13 17:22:16 --> Model Class Initialized
INFO - 2018-03-13 17:22:16 --> Model Class Initialized
INFO - 2018-03-13 17:22:16 --> Model Class Initialized
INFO - 2018-03-13 17:22:16 --> Model Class Initialized
INFO - 2018-03-13 17:22:16 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-13 17:22:16 --> Final output sent to browser
DEBUG - 2018-03-13 17:22:16 --> Total execution time: 0.4412
INFO - 2018-03-13 11:53:13 --> Config Class Initialized
INFO - 2018-03-13 11:53:13 --> Hooks Class Initialized
DEBUG - 2018-03-13 11:53:13 --> UTF-8 Support Enabled
INFO - 2018-03-13 11:53:13 --> Utf8 Class Initialized
INFO - 2018-03-13 11:53:13 --> URI Class Initialized
INFO - 2018-03-13 11:53:13 --> Router Class Initialized
INFO - 2018-03-13 11:53:13 --> Output Class Initialized
INFO - 2018-03-13 11:53:13 --> Security Class Initialized
DEBUG - 2018-03-13 11:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 11:53:13 --> Input Class Initialized
INFO - 2018-03-13 11:53:13 --> Language Class Initialized
INFO - 2018-03-13 11:53:14 --> Language Class Initialized
INFO - 2018-03-13 11:53:14 --> Config Class Initialized
INFO - 2018-03-13 11:53:14 --> Loader Class Initialized
INFO - 2018-03-13 17:23:14 --> Helper loaded: url_helper
INFO - 2018-03-13 17:23:14 --> Helper loaded: notification_helper
INFO - 2018-03-13 17:23:14 --> Helper loaded: settings_helper
INFO - 2018-03-13 17:23:14 --> Helper loaded: permission_helper
INFO - 2018-03-13 17:23:14 --> Helper loaded: users_helper
INFO - 2018-03-13 17:23:14 --> Database Driver Class Initialized
DEBUG - 2018-03-13 17:23:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 17:23:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 17:23:14 --> Helper loaded: form_helper
INFO - 2018-03-13 17:23:14 --> Form Validation Class Initialized
INFO - 2018-03-13 17:23:14 --> Controller Class Initialized
INFO - 2018-03-13 17:23:14 --> Model Class Initialized
INFO - 2018-03-13 17:23:14 --> Helper loaded: inflector_helper
DEBUG - 2018-03-13 17:23:14 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-13 17:23:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-13 17:23:14 --> Model Class Initialized
INFO - 2018-03-13 17:23:14 --> Model Class Initialized
INFO - 2018-03-13 17:23:14 --> Model Class Initialized
INFO - 2018-03-13 17:23:14 --> Model Class Initialized
INFO - 2018-03-13 17:23:14 --> Model Class Initialized
INFO - 2018-03-13 17:23:14 --> Model Class Initialized
INFO - 2018-03-13 17:23:14 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-13 17:23:14 --> Final output sent to browser
DEBUG - 2018-03-13 17:23:14 --> Total execution time: 0.1984
INFO - 2018-03-13 12:07:30 --> Config Class Initialized
INFO - 2018-03-13 12:07:30 --> Hooks Class Initialized
DEBUG - 2018-03-13 12:07:30 --> UTF-8 Support Enabled
INFO - 2018-03-13 12:07:30 --> Utf8 Class Initialized
INFO - 2018-03-13 12:07:30 --> URI Class Initialized
INFO - 2018-03-13 12:07:30 --> Router Class Initialized
INFO - 2018-03-13 12:07:30 --> Output Class Initialized
INFO - 2018-03-13 12:07:30 --> Security Class Initialized
DEBUG - 2018-03-13 12:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 12:07:30 --> Input Class Initialized
INFO - 2018-03-13 12:07:30 --> Language Class Initialized
INFO - 2018-03-13 12:07:30 --> Language Class Initialized
INFO - 2018-03-13 12:07:30 --> Config Class Initialized
INFO - 2018-03-13 12:07:30 --> Loader Class Initialized
INFO - 2018-03-13 17:37:30 --> Helper loaded: url_helper
INFO - 2018-03-13 17:37:30 --> Helper loaded: notification_helper
INFO - 2018-03-13 17:37:30 --> Helper loaded: settings_helper
INFO - 2018-03-13 17:37:30 --> Helper loaded: permission_helper
INFO - 2018-03-13 17:37:30 --> Helper loaded: users_helper
INFO - 2018-03-13 17:37:31 --> Database Driver Class Initialized
DEBUG - 2018-03-13 17:37:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 17:37:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 17:37:31 --> Helper loaded: form_helper
INFO - 2018-03-13 17:37:31 --> Form Validation Class Initialized
INFO - 2018-03-13 17:37:31 --> Controller Class Initialized
INFO - 2018-03-13 12:07:31 --> Config Class Initialized
INFO - 2018-03-13 12:07:31 --> Hooks Class Initialized
DEBUG - 2018-03-13 12:07:31 --> UTF-8 Support Enabled
INFO - 2018-03-13 12:07:31 --> Utf8 Class Initialized
INFO - 2018-03-13 17:37:31 --> Model Class Initialized
INFO - 2018-03-13 12:07:31 --> URI Class Initialized
INFO - 2018-03-13 12:07:31 --> Router Class Initialized
INFO - 2018-03-13 12:07:31 --> Output Class Initialized
INFO - 2018-03-13 17:37:31 --> Helper loaded: inflector_helper
INFO - 2018-03-13 12:07:31 --> Security Class Initialized
DEBUG - 2018-03-13 12:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 12:07:32 --> Input Class Initialized
INFO - 2018-03-13 12:07:32 --> Language Class Initialized
DEBUG - 2018-03-13 17:37:32 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-13 12:07:32 --> Language Class Initialized
INFO - 2018-03-13 12:07:32 --> Config Class Initialized
INFO - 2018-03-13 12:07:32 --> Loader Class Initialized
INFO - 2018-03-13 17:37:32 --> Helper loaded: url_helper
INFO - 2018-03-13 17:37:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-13 17:37:32 --> Helper loaded: notification_helper
INFO - 2018-03-13 17:37:32 --> Helper loaded: settings_helper
INFO - 2018-03-13 17:37:32 --> Helper loaded: permission_helper
INFO - 2018-03-13 17:37:32 --> Helper loaded: users_helper
INFO - 2018-03-13 17:37:32 --> Model Class Initialized
INFO - 2018-03-13 17:37:32 --> Model Class Initialized
INFO - 2018-03-13 17:37:32 --> Model Class Initialized
INFO - 2018-03-13 17:37:32 --> Model Class Initialized
INFO - 2018-03-13 17:37:32 --> Model Class Initialized
INFO - 2018-03-13 17:37:32 --> Database Driver Class Initialized
DEBUG - 2018-03-13 17:37:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 17:37:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 17:37:32 --> Helper loaded: form_helper
INFO - 2018-03-13 17:37:32 --> Form Validation Class Initialized
INFO - 2018-03-13 17:37:32 --> Controller Class Initialized
INFO - 2018-03-13 17:37:32 --> Model Class Initialized
INFO - 2018-03-13 17:37:32 --> Helper loaded: inflector_helper
DEBUG - 2018-03-13 17:37:32 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-13 17:37:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-13 17:37:32 --> Model Class Initialized
INFO - 2018-03-13 17:37:32 --> Model Class Initialized
INFO - 2018-03-13 17:37:32 --> Model Class Initialized
INFO - 2018-03-13 17:37:32 --> Model Class Initialized
INFO - 2018-03-13 17:37:32 --> Model Class Initialized
INFO - 2018-03-13 17:37:32 --> Model Class Initialized
INFO - 2018-03-13 17:37:32 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-13 17:37:32 --> Model Class Initialized
INFO - 2018-03-13 17:37:32 --> Final output sent to browser
DEBUG - 2018-03-13 17:37:32 --> Total execution time: 0.4801
INFO - 2018-03-13 17:37:32 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-13 17:37:32 --> Final output sent to browser
DEBUG - 2018-03-13 17:37:32 --> Total execution time: 2.5340
INFO - 2018-03-13 12:15:25 --> Config Class Initialized
INFO - 2018-03-13 12:15:25 --> Hooks Class Initialized
DEBUG - 2018-03-13 12:15:25 --> UTF-8 Support Enabled
INFO - 2018-03-13 12:15:25 --> Utf8 Class Initialized
INFO - 2018-03-13 12:15:25 --> URI Class Initialized
INFO - 2018-03-13 12:15:26 --> Router Class Initialized
INFO - 2018-03-13 12:15:26 --> Output Class Initialized
INFO - 2018-03-13 12:15:26 --> Security Class Initialized
DEBUG - 2018-03-13 12:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 12:15:26 --> Input Class Initialized
INFO - 2018-03-13 12:15:26 --> Language Class Initialized
INFO - 2018-03-13 12:15:27 --> Language Class Initialized
INFO - 2018-03-13 12:15:27 --> Config Class Initialized
INFO - 2018-03-13 12:15:27 --> Loader Class Initialized
INFO - 2018-03-13 17:45:27 --> Helper loaded: url_helper
INFO - 2018-03-13 17:45:27 --> Helper loaded: notification_helper
INFO - 2018-03-13 17:45:27 --> Helper loaded: settings_helper
INFO - 2018-03-13 17:45:27 --> Helper loaded: permission_helper
INFO - 2018-03-13 17:45:27 --> Helper loaded: users_helper
INFO - 2018-03-13 17:45:28 --> Database Driver Class Initialized
DEBUG - 2018-03-13 17:45:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 17:45:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 17:45:28 --> Helper loaded: form_helper
INFO - 2018-03-13 17:45:28 --> Form Validation Class Initialized
INFO - 2018-03-13 17:45:28 --> Controller Class Initialized
INFO - 2018-03-13 17:45:28 --> Model Class Initialized
INFO - 2018-03-13 17:45:28 --> Helper loaded: inflector_helper
DEBUG - 2018-03-13 17:45:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-13 17:45:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-13 17:45:28 --> Model Class Initialized
INFO - 2018-03-13 17:45:28 --> Model Class Initialized
INFO - 2018-03-13 17:45:28 --> Model Class Initialized
INFO - 2018-03-13 17:45:28 --> Model Class Initialized
INFO - 2018-03-13 17:45:28 --> Model Class Initialized
INFO - 2018-03-13 17:45:28 --> Model Class Initialized
INFO - 2018-03-13 17:45:28 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-13 17:45:28 --> Final output sent to browser
DEBUG - 2018-03-13 17:45:28 --> Total execution time: 2.9296
INFO - 2018-03-13 12:23:20 --> Config Class Initialized
INFO - 2018-03-13 12:23:20 --> Hooks Class Initialized
DEBUG - 2018-03-13 12:23:20 --> UTF-8 Support Enabled
INFO - 2018-03-13 12:23:20 --> Utf8 Class Initialized
INFO - 2018-03-13 12:23:20 --> URI Class Initialized
INFO - 2018-03-13 12:23:20 --> Router Class Initialized
INFO - 2018-03-13 12:23:20 --> Output Class Initialized
INFO - 2018-03-13 12:23:20 --> Security Class Initialized
DEBUG - 2018-03-13 12:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 12:23:20 --> Input Class Initialized
INFO - 2018-03-13 12:23:20 --> Language Class Initialized
INFO - 2018-03-13 12:23:20 --> Language Class Initialized
INFO - 2018-03-13 12:23:20 --> Config Class Initialized
INFO - 2018-03-13 12:23:20 --> Loader Class Initialized
INFO - 2018-03-13 17:53:20 --> Helper loaded: url_helper
INFO - 2018-03-13 17:53:20 --> Helper loaded: notification_helper
INFO - 2018-03-13 17:53:20 --> Helper loaded: settings_helper
INFO - 2018-03-13 17:53:20 --> Helper loaded: permission_helper
INFO - 2018-03-13 17:53:20 --> Helper loaded: users_helper
INFO - 2018-03-13 17:53:20 --> Database Driver Class Initialized
DEBUG - 2018-03-13 17:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 17:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 17:53:20 --> Helper loaded: form_helper
INFO - 2018-03-13 17:53:20 --> Form Validation Class Initialized
INFO - 2018-03-13 17:53:20 --> Controller Class Initialized
INFO - 2018-03-13 17:53:20 --> Model Class Initialized
INFO - 2018-03-13 17:53:20 --> Helper loaded: inflector_helper
DEBUG - 2018-03-13 17:53:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-13 17:53:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-13 17:53:20 --> Model Class Initialized
INFO - 2018-03-13 17:53:20 --> Model Class Initialized
INFO - 2018-03-13 17:53:20 --> Model Class Initialized
INFO - 2018-03-13 17:53:20 --> Model Class Initialized
INFO - 2018-03-13 17:53:20 --> Model Class Initialized
INFO - 2018-03-13 17:53:20 --> Model Class Initialized
INFO - 2018-03-13 17:53:20 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-13 17:53:20 --> Final output sent to browser
DEBUG - 2018-03-13 17:53:20 --> Total execution time: 0.3325
INFO - 2018-03-13 12:38:52 --> Config Class Initialized
INFO - 2018-03-13 12:38:52 --> Hooks Class Initialized
DEBUG - 2018-03-13 12:38:53 --> UTF-8 Support Enabled
INFO - 2018-03-13 12:38:53 --> Utf8 Class Initialized
INFO - 2018-03-13 12:38:53 --> URI Class Initialized
INFO - 2018-03-13 12:38:53 --> Router Class Initialized
INFO - 2018-03-13 12:38:53 --> Output Class Initialized
INFO - 2018-03-13 12:38:53 --> Security Class Initialized
DEBUG - 2018-03-13 12:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 12:38:53 --> Input Class Initialized
INFO - 2018-03-13 12:38:53 --> Language Class Initialized
INFO - 2018-03-13 12:38:53 --> Language Class Initialized
INFO - 2018-03-13 12:38:53 --> Config Class Initialized
INFO - 2018-03-13 12:38:53 --> Loader Class Initialized
INFO - 2018-03-13 18:08:53 --> Helper loaded: url_helper
INFO - 2018-03-13 18:08:53 --> Helper loaded: notification_helper
INFO - 2018-03-13 18:08:53 --> Helper loaded: settings_helper
INFO - 2018-03-13 18:08:53 --> Helper loaded: permission_helper
INFO - 2018-03-13 18:08:53 --> Helper loaded: users_helper
INFO - 2018-03-13 18:08:54 --> Database Driver Class Initialized
DEBUG - 2018-03-13 18:08:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 18:08:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 18:08:54 --> Helper loaded: form_helper
INFO - 2018-03-13 18:08:54 --> Form Validation Class Initialized
INFO - 2018-03-13 18:08:54 --> Controller Class Initialized
INFO - 2018-03-13 18:08:54 --> Model Class Initialized
INFO - 2018-03-13 18:08:54 --> Helper loaded: inflector_helper
DEBUG - 2018-03-13 18:08:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-13 18:08:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-13 18:08:54 --> Model Class Initialized
INFO - 2018-03-13 18:08:54 --> Model Class Initialized
INFO - 2018-03-13 18:08:54 --> Model Class Initialized
INFO - 2018-03-13 18:08:54 --> Model Class Initialized
INFO - 2018-03-13 18:08:54 --> Model Class Initialized
INFO - 2018-03-13 18:08:54 --> Model Class Initialized
INFO - 2018-03-13 18:08:54 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-13 18:08:54 --> Final output sent to browser
DEBUG - 2018-03-13 18:08:54 --> Total execution time: 1.3101
INFO - 2018-03-13 12:40:16 --> Config Class Initialized
INFO - 2018-03-13 12:40:16 --> Hooks Class Initialized
DEBUG - 2018-03-13 12:40:16 --> UTF-8 Support Enabled
INFO - 2018-03-13 12:40:16 --> Utf8 Class Initialized
INFO - 2018-03-13 12:40:16 --> URI Class Initialized
INFO - 2018-03-13 12:40:16 --> Router Class Initialized
INFO - 2018-03-13 12:40:16 --> Output Class Initialized
INFO - 2018-03-13 12:40:16 --> Security Class Initialized
DEBUG - 2018-03-13 12:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 12:40:16 --> Input Class Initialized
INFO - 2018-03-13 12:40:16 --> Language Class Initialized
INFO - 2018-03-13 12:40:16 --> Language Class Initialized
INFO - 2018-03-13 12:40:16 --> Config Class Initialized
INFO - 2018-03-13 12:40:16 --> Loader Class Initialized
INFO - 2018-03-13 18:10:16 --> Helper loaded: url_helper
INFO - 2018-03-13 18:10:16 --> Helper loaded: notification_helper
INFO - 2018-03-13 18:10:16 --> Helper loaded: settings_helper
INFO - 2018-03-13 18:10:16 --> Helper loaded: permission_helper
INFO - 2018-03-13 18:10:16 --> Helper loaded: users_helper
INFO - 2018-03-13 18:10:16 --> Database Driver Class Initialized
DEBUG - 2018-03-13 18:10:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 18:10:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 18:10:16 --> Helper loaded: form_helper
INFO - 2018-03-13 18:10:16 --> Form Validation Class Initialized
INFO - 2018-03-13 18:10:16 --> Controller Class Initialized
INFO - 2018-03-13 18:10:17 --> Model Class Initialized
INFO - 2018-03-13 18:10:17 --> Helper loaded: inflector_helper
DEBUG - 2018-03-13 18:10:17 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-13 18:10:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-13 18:10:17 --> Model Class Initialized
INFO - 2018-03-13 18:10:17 --> Model Class Initialized
INFO - 2018-03-13 18:10:17 --> Model Class Initialized
INFO - 2018-03-13 18:10:17 --> Model Class Initialized
INFO - 2018-03-13 18:10:17 --> Model Class Initialized
INFO - 2018-03-13 18:10:17 --> Model Class Initialized
INFO - 2018-03-13 18:10:17 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-13 18:10:17 --> Final output sent to browser
DEBUG - 2018-03-13 18:10:17 --> Total execution time: 0.6276
INFO - 2018-03-13 12:41:27 --> Config Class Initialized
INFO - 2018-03-13 12:41:27 --> Hooks Class Initialized
DEBUG - 2018-03-13 12:41:27 --> UTF-8 Support Enabled
INFO - 2018-03-13 12:41:27 --> Utf8 Class Initialized
INFO - 2018-03-13 12:41:27 --> URI Class Initialized
INFO - 2018-03-13 12:41:27 --> Router Class Initialized
INFO - 2018-03-13 12:41:27 --> Output Class Initialized
INFO - 2018-03-13 12:41:27 --> Security Class Initialized
DEBUG - 2018-03-13 12:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 12:41:27 --> Input Class Initialized
INFO - 2018-03-13 12:41:27 --> Language Class Initialized
INFO - 2018-03-13 12:41:28 --> Language Class Initialized
INFO - 2018-03-13 12:41:28 --> Config Class Initialized
INFO - 2018-03-13 12:41:28 --> Loader Class Initialized
INFO - 2018-03-13 18:11:28 --> Helper loaded: url_helper
INFO - 2018-03-13 18:11:28 --> Helper loaded: notification_helper
INFO - 2018-03-13 18:11:28 --> Helper loaded: settings_helper
INFO - 2018-03-13 18:11:28 --> Helper loaded: permission_helper
INFO - 2018-03-13 18:11:28 --> Helper loaded: users_helper
INFO - 2018-03-13 18:11:28 --> Database Driver Class Initialized
DEBUG - 2018-03-13 18:11:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 18:11:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 18:11:28 --> Helper loaded: form_helper
INFO - 2018-03-13 18:11:28 --> Form Validation Class Initialized
INFO - 2018-03-13 18:11:28 --> Controller Class Initialized
INFO - 2018-03-13 18:11:28 --> Model Class Initialized
INFO - 2018-03-13 18:11:28 --> Helper loaded: inflector_helper
DEBUG - 2018-03-13 18:11:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-13 18:11:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-13 18:11:28 --> Model Class Initialized
INFO - 2018-03-13 18:11:28 --> Model Class Initialized
INFO - 2018-03-13 18:11:28 --> Model Class Initialized
INFO - 2018-03-13 18:11:28 --> Model Class Initialized
INFO - 2018-03-13 18:11:28 --> Model Class Initialized
INFO - 2018-03-13 18:11:28 --> Model Class Initialized
INFO - 2018-03-13 18:11:28 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-13 18:11:28 --> Final output sent to browser
DEBUG - 2018-03-13 18:11:28 --> Total execution time: 0.2794
INFO - 2018-03-13 12:41:48 --> Config Class Initialized
INFO - 2018-03-13 12:41:48 --> Hooks Class Initialized
DEBUG - 2018-03-13 12:41:48 --> UTF-8 Support Enabled
INFO - 2018-03-13 12:41:48 --> Utf8 Class Initialized
INFO - 2018-03-13 12:41:48 --> URI Class Initialized
INFO - 2018-03-13 12:41:48 --> Router Class Initialized
INFO - 2018-03-13 12:41:48 --> Output Class Initialized
INFO - 2018-03-13 12:41:48 --> Security Class Initialized
DEBUG - 2018-03-13 12:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 12:41:48 --> Input Class Initialized
INFO - 2018-03-13 12:41:48 --> Language Class Initialized
INFO - 2018-03-13 12:41:48 --> Language Class Initialized
INFO - 2018-03-13 12:41:48 --> Config Class Initialized
INFO - 2018-03-13 12:41:48 --> Loader Class Initialized
INFO - 2018-03-13 18:11:48 --> Helper loaded: url_helper
INFO - 2018-03-13 18:11:48 --> Helper loaded: notification_helper
INFO - 2018-03-13 18:11:48 --> Helper loaded: settings_helper
INFO - 2018-03-13 18:11:48 --> Helper loaded: permission_helper
INFO - 2018-03-13 18:11:48 --> Helper loaded: users_helper
INFO - 2018-03-13 18:11:48 --> Database Driver Class Initialized
DEBUG - 2018-03-13 18:11:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 18:11:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 18:11:48 --> Helper loaded: form_helper
INFO - 2018-03-13 18:11:48 --> Form Validation Class Initialized
INFO - 2018-03-13 18:11:48 --> Controller Class Initialized
INFO - 2018-03-13 18:11:48 --> Model Class Initialized
INFO - 2018-03-13 18:11:48 --> Helper loaded: inflector_helper
DEBUG - 2018-03-13 18:11:48 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-13 18:11:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-13 18:11:48 --> Model Class Initialized
INFO - 2018-03-13 18:11:48 --> Model Class Initialized
INFO - 2018-03-13 18:11:48 --> Model Class Initialized
INFO - 2018-03-13 18:11:48 --> Model Class Initialized
INFO - 2018-03-13 18:11:48 --> Model Class Initialized
INFO - 2018-03-13 18:11:48 --> Model Class Initialized
INFO - 2018-03-13 18:11:48 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-13 18:11:48 --> Final output sent to browser
DEBUG - 2018-03-13 18:11:48 --> Total execution time: 0.1076
INFO - 2018-03-13 12:42:38 --> Config Class Initialized
INFO - 2018-03-13 12:42:38 --> Hooks Class Initialized
DEBUG - 2018-03-13 12:42:38 --> UTF-8 Support Enabled
INFO - 2018-03-13 12:42:38 --> Utf8 Class Initialized
INFO - 2018-03-13 12:42:38 --> URI Class Initialized
INFO - 2018-03-13 12:42:38 --> Router Class Initialized
INFO - 2018-03-13 12:42:38 --> Output Class Initialized
INFO - 2018-03-13 12:42:38 --> Security Class Initialized
DEBUG - 2018-03-13 12:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 12:42:38 --> Input Class Initialized
INFO - 2018-03-13 12:42:38 --> Language Class Initialized
INFO - 2018-03-13 12:42:38 --> Language Class Initialized
INFO - 2018-03-13 12:42:38 --> Config Class Initialized
INFO - 2018-03-13 12:42:38 --> Loader Class Initialized
INFO - 2018-03-13 18:12:38 --> Helper loaded: url_helper
INFO - 2018-03-13 18:12:38 --> Helper loaded: notification_helper
INFO - 2018-03-13 18:12:38 --> Helper loaded: settings_helper
INFO - 2018-03-13 18:12:38 --> Helper loaded: permission_helper
INFO - 2018-03-13 18:12:38 --> Helper loaded: users_helper
INFO - 2018-03-13 18:12:38 --> Database Driver Class Initialized
DEBUG - 2018-03-13 18:12:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 18:12:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 18:12:38 --> Helper loaded: form_helper
INFO - 2018-03-13 18:12:38 --> Form Validation Class Initialized
INFO - 2018-03-13 18:12:38 --> Controller Class Initialized
INFO - 2018-03-13 18:12:38 --> Model Class Initialized
INFO - 2018-03-13 18:12:38 --> Helper loaded: inflector_helper
DEBUG - 2018-03-13 18:12:38 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-13 18:12:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-13 18:12:38 --> Model Class Initialized
INFO - 2018-03-13 18:12:38 --> Model Class Initialized
INFO - 2018-03-13 18:12:38 --> Model Class Initialized
INFO - 2018-03-13 18:12:38 --> Model Class Initialized
INFO - 2018-03-13 18:12:38 --> Model Class Initialized
INFO - 2018-03-13 18:12:38 --> Model Class Initialized
INFO - 2018-03-13 18:12:38 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-13 18:12:38 --> Final output sent to browser
DEBUG - 2018-03-13 18:12:38 --> Total execution time: 0.1920
INFO - 2018-03-13 12:43:27 --> Config Class Initialized
INFO - 2018-03-13 12:43:27 --> Hooks Class Initialized
DEBUG - 2018-03-13 12:43:27 --> UTF-8 Support Enabled
INFO - 2018-03-13 12:43:27 --> Utf8 Class Initialized
INFO - 2018-03-13 12:43:27 --> URI Class Initialized
INFO - 2018-03-13 12:43:27 --> Router Class Initialized
INFO - 2018-03-13 12:43:27 --> Output Class Initialized
INFO - 2018-03-13 12:43:27 --> Security Class Initialized
DEBUG - 2018-03-13 12:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 12:43:27 --> Input Class Initialized
INFO - 2018-03-13 12:43:27 --> Language Class Initialized
INFO - 2018-03-13 12:43:27 --> Language Class Initialized
INFO - 2018-03-13 12:43:27 --> Config Class Initialized
INFO - 2018-03-13 12:43:27 --> Loader Class Initialized
INFO - 2018-03-13 18:13:27 --> Helper loaded: url_helper
INFO - 2018-03-13 18:13:27 --> Helper loaded: notification_helper
INFO - 2018-03-13 18:13:27 --> Helper loaded: settings_helper
INFO - 2018-03-13 18:13:27 --> Helper loaded: permission_helper
INFO - 2018-03-13 18:13:27 --> Helper loaded: users_helper
INFO - 2018-03-13 18:13:28 --> Database Driver Class Initialized
DEBUG - 2018-03-13 18:13:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 18:13:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 18:13:28 --> Helper loaded: form_helper
INFO - 2018-03-13 18:13:28 --> Form Validation Class Initialized
INFO - 2018-03-13 18:13:28 --> Controller Class Initialized
INFO - 2018-03-13 18:13:28 --> Model Class Initialized
INFO - 2018-03-13 18:13:28 --> Helper loaded: inflector_helper
DEBUG - 2018-03-13 18:13:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-13 18:13:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-13 18:13:28 --> Model Class Initialized
INFO - 2018-03-13 18:13:28 --> Model Class Initialized
INFO - 2018-03-13 18:13:28 --> Model Class Initialized
INFO - 2018-03-13 18:13:28 --> Model Class Initialized
INFO - 2018-03-13 18:13:28 --> Model Class Initialized
INFO - 2018-03-13 18:13:28 --> Model Class Initialized
INFO - 2018-03-13 18:13:28 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-13 18:13:28 --> Final output sent to browser
DEBUG - 2018-03-13 18:13:28 --> Total execution time: 0.2846
INFO - 2018-03-13 12:46:47 --> Config Class Initialized
INFO - 2018-03-13 12:46:47 --> Hooks Class Initialized
DEBUG - 2018-03-13 12:46:47 --> UTF-8 Support Enabled
INFO - 2018-03-13 12:46:47 --> Utf8 Class Initialized
INFO - 2018-03-13 12:46:47 --> URI Class Initialized
INFO - 2018-03-13 12:46:47 --> Router Class Initialized
INFO - 2018-03-13 12:46:47 --> Output Class Initialized
INFO - 2018-03-13 12:46:47 --> Security Class Initialized
DEBUG - 2018-03-13 12:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 12:46:47 --> Input Class Initialized
INFO - 2018-03-13 12:46:47 --> Language Class Initialized
INFO - 2018-03-13 12:46:47 --> Language Class Initialized
INFO - 2018-03-13 12:46:47 --> Config Class Initialized
INFO - 2018-03-13 12:46:47 --> Loader Class Initialized
INFO - 2018-03-13 18:16:47 --> Helper loaded: url_helper
INFO - 2018-03-13 18:16:47 --> Helper loaded: notification_helper
INFO - 2018-03-13 18:16:47 --> Helper loaded: settings_helper
INFO - 2018-03-13 18:16:47 --> Helper loaded: permission_helper
INFO - 2018-03-13 18:16:47 --> Helper loaded: users_helper
INFO - 2018-03-13 18:16:47 --> Database Driver Class Initialized
DEBUG - 2018-03-13 18:16:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 18:16:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 18:16:47 --> Helper loaded: form_helper
INFO - 2018-03-13 18:16:47 --> Form Validation Class Initialized
INFO - 2018-03-13 18:16:47 --> Controller Class Initialized
INFO - 2018-03-13 18:16:47 --> Model Class Initialized
INFO - 2018-03-13 18:16:47 --> Helper loaded: inflector_helper
DEBUG - 2018-03-13 18:16:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-13 18:16:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-13 18:16:47 --> Model Class Initialized
INFO - 2018-03-13 18:16:47 --> Model Class Initialized
INFO - 2018-03-13 18:16:47 --> Model Class Initialized
INFO - 2018-03-13 18:16:47 --> Model Class Initialized
INFO - 2018-03-13 18:16:47 --> Model Class Initialized
INFO - 2018-03-13 18:16:47 --> Model Class Initialized
INFO - 2018-03-13 18:16:47 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-13 18:16:47 --> Final output sent to browser
DEBUG - 2018-03-13 18:16:47 --> Total execution time: 0.2378
INFO - 2018-03-13 12:48:54 --> Config Class Initialized
INFO - 2018-03-13 12:48:54 --> Hooks Class Initialized
DEBUG - 2018-03-13 12:48:54 --> UTF-8 Support Enabled
INFO - 2018-03-13 12:48:54 --> Utf8 Class Initialized
INFO - 2018-03-13 12:48:54 --> URI Class Initialized
INFO - 2018-03-13 12:48:54 --> Router Class Initialized
INFO - 2018-03-13 12:48:54 --> Output Class Initialized
INFO - 2018-03-13 12:48:54 --> Security Class Initialized
DEBUG - 2018-03-13 12:48:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 12:48:54 --> Input Class Initialized
INFO - 2018-03-13 12:48:55 --> Language Class Initialized
INFO - 2018-03-13 12:48:55 --> Language Class Initialized
INFO - 2018-03-13 12:48:55 --> Config Class Initialized
INFO - 2018-03-13 12:48:55 --> Loader Class Initialized
INFO - 2018-03-13 18:18:55 --> Helper loaded: url_helper
INFO - 2018-03-13 18:18:55 --> Helper loaded: notification_helper
INFO - 2018-03-13 18:18:55 --> Helper loaded: settings_helper
INFO - 2018-03-13 18:18:55 --> Helper loaded: permission_helper
INFO - 2018-03-13 18:18:55 --> Helper loaded: users_helper
INFO - 2018-03-13 18:18:55 --> Database Driver Class Initialized
DEBUG - 2018-03-13 18:18:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 18:18:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 18:18:55 --> Helper loaded: form_helper
INFO - 2018-03-13 18:18:55 --> Form Validation Class Initialized
INFO - 2018-03-13 18:18:55 --> Controller Class Initialized
INFO - 2018-03-13 18:18:55 --> Model Class Initialized
INFO - 2018-03-13 18:18:55 --> Helper loaded: inflector_helper
DEBUG - 2018-03-13 18:18:55 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-13 18:18:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-13 18:18:55 --> Model Class Initialized
INFO - 2018-03-13 18:18:55 --> Model Class Initialized
INFO - 2018-03-13 18:18:55 --> Model Class Initialized
INFO - 2018-03-13 18:18:55 --> Model Class Initialized
INFO - 2018-03-13 18:18:55 --> Model Class Initialized
INFO - 2018-03-13 18:18:55 --> Model Class Initialized
INFO - 2018-03-13 18:18:55 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-13 18:18:55 --> Final output sent to browser
DEBUG - 2018-03-13 18:18:55 --> Total execution time: 0.3592
INFO - 2018-03-13 13:49:23 --> Config Class Initialized
INFO - 2018-03-13 13:49:23 --> Hooks Class Initialized
DEBUG - 2018-03-13 13:49:23 --> UTF-8 Support Enabled
INFO - 2018-03-13 13:49:23 --> Utf8 Class Initialized
INFO - 2018-03-13 13:49:23 --> URI Class Initialized
INFO - 2018-03-13 13:49:23 --> Router Class Initialized
INFO - 2018-03-13 13:49:23 --> Output Class Initialized
INFO - 2018-03-13 13:49:23 --> Security Class Initialized
DEBUG - 2018-03-13 13:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 13:49:23 --> Input Class Initialized
INFO - 2018-03-13 13:49:23 --> Language Class Initialized
INFO - 2018-03-13 13:49:24 --> Language Class Initialized
INFO - 2018-03-13 13:49:24 --> Config Class Initialized
INFO - 2018-03-13 13:49:24 --> Loader Class Initialized
INFO - 2018-03-13 19:19:25 --> Helper loaded: url_helper
INFO - 2018-03-13 19:19:25 --> Helper loaded: notification_helper
INFO - 2018-03-13 19:19:25 --> Helper loaded: settings_helper
INFO - 2018-03-13 19:19:25 --> Helper loaded: permission_helper
INFO - 2018-03-13 19:19:25 --> Helper loaded: users_helper
INFO - 2018-03-13 19:19:25 --> Database Driver Class Initialized
DEBUG - 2018-03-13 19:19:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 19:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 19:19:26 --> Helper loaded: form_helper
INFO - 2018-03-13 19:19:26 --> Form Validation Class Initialized
INFO - 2018-03-13 19:19:26 --> Controller Class Initialized
INFO - 2018-03-13 19:19:26 --> Model Class Initialized
INFO - 2018-03-13 19:19:26 --> Helper loaded: inflector_helper
DEBUG - 2018-03-13 19:19:26 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-13 19:19:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-13 19:19:26 --> Model Class Initialized
INFO - 2018-03-13 19:19:26 --> Model Class Initialized
INFO - 2018-03-13 19:19:26 --> Model Class Initialized
INFO - 2018-03-13 19:19:26 --> Model Class Initialized
INFO - 2018-03-13 19:19:26 --> Model Class Initialized
INFO - 2018-03-13 19:19:26 --> Model Class Initialized
INFO - 2018-03-13 19:19:26 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-13 19:19:26 --> Final output sent to browser
DEBUG - 2018-03-13 19:19:26 --> Total execution time: 3.3071
INFO - 2018-03-13 13:49:26 --> Config Class Initialized
INFO - 2018-03-13 13:49:26 --> Hooks Class Initialized
DEBUG - 2018-03-13 13:49:26 --> UTF-8 Support Enabled
INFO - 2018-03-13 13:49:26 --> Utf8 Class Initialized
INFO - 2018-03-13 13:49:26 --> URI Class Initialized
INFO - 2018-03-13 13:49:26 --> Router Class Initialized
INFO - 2018-03-13 13:49:26 --> Output Class Initialized
INFO - 2018-03-13 13:49:26 --> Security Class Initialized
DEBUG - 2018-03-13 13:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-13 13:49:26 --> Input Class Initialized
INFO - 2018-03-13 13:49:26 --> Language Class Initialized
INFO - 2018-03-13 13:49:26 --> Language Class Initialized
INFO - 2018-03-13 13:49:26 --> Config Class Initialized
INFO - 2018-03-13 13:49:26 --> Loader Class Initialized
INFO - 2018-03-13 19:19:26 --> Helper loaded: url_helper
INFO - 2018-03-13 19:19:26 --> Helper loaded: notification_helper
INFO - 2018-03-13 19:19:26 --> Helper loaded: settings_helper
INFO - 2018-03-13 19:19:26 --> Helper loaded: permission_helper
INFO - 2018-03-13 19:19:26 --> Helper loaded: users_helper
INFO - 2018-03-13 19:19:27 --> Database Driver Class Initialized
DEBUG - 2018-03-13 19:19:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-13 19:19:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-13 19:19:27 --> Helper loaded: form_helper
INFO - 2018-03-13 19:19:27 --> Form Validation Class Initialized
INFO - 2018-03-13 19:19:27 --> Controller Class Initialized
INFO - 2018-03-13 19:19:27 --> Model Class Initialized
INFO - 2018-03-13 19:19:27 --> Helper loaded: inflector_helper
DEBUG - 2018-03-13 19:19:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-13 19:19:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-13 19:19:27 --> Model Class Initialized
INFO - 2018-03-13 19:19:27 --> Model Class Initialized
INFO - 2018-03-13 19:19:27 --> Model Class Initialized
INFO - 2018-03-13 19:19:27 --> Model Class Initialized
INFO - 2018-03-13 19:19:27 --> Model Class Initialized
INFO - 2018-03-13 19:19:27 --> Model Class Initialized
INFO - 2018-03-13 19:19:27 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-13 19:19:27 --> Final output sent to browser
DEBUG - 2018-03-13 19:19:27 --> Total execution time: 0.4094
