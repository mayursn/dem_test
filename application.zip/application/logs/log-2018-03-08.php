<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-03-08 13:38:55 --> Config Class Initialized
INFO - 2018-03-08 13:38:55 --> Hooks Class Initialized
INFO - 2018-03-08 13:38:55 --> Config Class Initialized
INFO - 2018-03-08 13:38:55 --> Hooks Class Initialized
DEBUG - 2018-03-08 13:38:55 --> UTF-8 Support Enabled
INFO - 2018-03-08 13:38:55 --> Utf8 Class Initialized
DEBUG - 2018-03-08 13:38:55 --> UTF-8 Support Enabled
INFO - 2018-03-08 13:38:55 --> Utf8 Class Initialized
INFO - 2018-03-08 13:38:55 --> Config Class Initialized
INFO - 2018-03-08 13:38:55 --> Hooks Class Initialized
INFO - 2018-03-08 13:38:55 --> URI Class Initialized
INFO - 2018-03-08 13:38:55 --> URI Class Initialized
DEBUG - 2018-03-08 13:38:56 --> UTF-8 Support Enabled
INFO - 2018-03-08 13:38:56 --> Utf8 Class Initialized
INFO - 2018-03-08 13:38:56 --> Router Class Initialized
INFO - 2018-03-08 13:38:56 --> URI Class Initialized
INFO - 2018-03-08 13:38:56 --> Router Class Initialized
INFO - 2018-03-08 13:38:56 --> Output Class Initialized
INFO - 2018-03-08 13:38:56 --> Router Class Initialized
INFO - 2018-03-08 13:38:56 --> Output Class Initialized
INFO - 2018-03-08 13:38:56 --> Security Class Initialized
INFO - 2018-03-08 13:38:56 --> Security Class Initialized
INFO - 2018-03-08 13:38:56 --> Output Class Initialized
DEBUG - 2018-03-08 13:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 13:38:56 --> Input Class Initialized
INFO - 2018-03-08 13:38:56 --> Security Class Initialized
DEBUG - 2018-03-08 13:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 13:38:56 --> Input Class Initialized
INFO - 2018-03-08 13:38:56 --> Language Class Initialized
DEBUG - 2018-03-08 13:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 13:38:56 --> Input Class Initialized
INFO - 2018-03-08 13:38:56 --> Language Class Initialized
INFO - 2018-03-08 13:38:56 --> Language Class Initialized
INFO - 2018-03-08 13:38:56 --> Language Class Initialized
INFO - 2018-03-08 13:38:56 --> Config Class Initialized
INFO - 2018-03-08 13:38:56 --> Loader Class Initialized
INFO - 2018-03-08 13:38:56 --> Language Class Initialized
INFO - 2018-03-08 13:38:56 --> Config Class Initialized
INFO - 2018-03-08 13:38:56 --> Loader Class Initialized
INFO - 2018-03-08 19:08:56 --> Helper loaded: url_helper
INFO - 2018-03-08 19:08:56 --> Helper loaded: url_helper
INFO - 2018-03-08 19:08:56 --> Helper loaded: notification_helper
INFO - 2018-03-08 19:08:56 --> Helper loaded: notification_helper
INFO - 2018-03-08 19:08:56 --> Helper loaded: settings_helper
INFO - 2018-03-08 19:08:56 --> Helper loaded: settings_helper
INFO - 2018-03-08 19:08:56 --> Helper loaded: permission_helper
INFO - 2018-03-08 19:08:56 --> Helper loaded: permission_helper
INFO - 2018-03-08 19:08:56 --> Helper loaded: users_helper
INFO - 2018-03-08 19:08:56 --> Helper loaded: users_helper
INFO - 2018-03-08 19:08:56 --> Database Driver Class Initialized
INFO - 2018-03-08 19:08:56 --> Database Driver Class Initialized
DEBUG - 2018-03-08 19:08:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-08 19:08:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-03-08 19:08:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-08 19:08:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 19:08:56 --> Helper loaded: form_helper
INFO - 2018-03-08 19:08:56 --> Helper loaded: form_helper
INFO - 2018-03-08 19:08:56 --> Form Validation Class Initialized
INFO - 2018-03-08 19:08:56 --> Form Validation Class Initialized
INFO - 2018-03-08 19:08:56 --> Controller Class Initialized
INFO - 2018-03-08 19:08:56 --> Controller Class Initialized
INFO - 2018-03-08 19:08:56 --> Model Class Initialized
INFO - 2018-03-08 19:08:56 --> Helper loaded: inflector_helper
INFO - 2018-03-08 19:08:56 --> Model Class Initialized
DEBUG - 2018-03-08 19:08:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-08 19:08:56 --> Helper loaded: inflector_helper
INFO - 2018-03-08 13:38:56 --> Language Class Initialized
INFO - 2018-03-08 19:08:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-08 19:08:56 --> Model Class Initialized
INFO - 2018-03-08 13:38:56 --> Config Class Initialized
INFO - 2018-03-08 13:38:56 --> Loader Class Initialized
INFO - 2018-03-08 19:08:56 --> Model Class Initialized
INFO - 2018-03-08 19:08:56 --> Model Class Initialized
INFO - 2018-03-08 19:08:56 --> Model Class Initialized
INFO - 2018-03-08 19:08:56 --> Model Class Initialized
INFO - 2018-03-08 19:08:56 --> Model Class Initialized
INFO - 2018-03-08 19:08:56 --> Model Class Initialized
INFO - 2018-03-08 19:08:56 --> Model Class Initialized
INFO - 2018-03-08 19:08:56 --> Model Class Initialized
INFO - 2018-03-08 19:08:56 --> Model Class Initialized
DEBUG - 2018-03-08 19:08:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-08 19:08:56 --> Helper loaded: url_helper
INFO - 2018-03-08 19:08:56 --> Model Class Initialized
INFO - 2018-03-08 19:08:56 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-08 19:08:56 --> Model Class Initialized
INFO - 2018-03-08 19:08:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-08 19:08:56 --> Helper loaded: notification_helper
INFO - 2018-03-08 19:08:56 --> Helper loaded: settings_helper
INFO - 2018-03-08 19:08:56 --> Helper loaded: permission_helper
INFO - 2018-03-08 19:08:56 --> Helper loaded: users_helper
INFO - 2018-03-08 19:08:56 --> Model Class Initialized
INFO - 2018-03-08 19:08:56 --> Model Class Initialized
INFO - 2018-03-08 19:08:56 --> Final output sent to browser
DEBUG - 2018-03-08 19:08:56 --> Total execution time: 0.7452
INFO - 2018-03-08 19:08:56 --> Model Class Initialized
INFO - 2018-03-08 19:08:56 --> Model Class Initialized
INFO - 2018-03-08 19:08:56 --> Model Class Initialized
INFO - 2018-03-08 19:08:56 --> Model Class Initialized
INFO - 2018-03-08 19:08:56 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-08 19:08:56 --> Model Class Initialized
INFO - 2018-03-08 19:08:56 --> Final output sent to browser
DEBUG - 2018-03-08 19:08:56 --> Total execution time: 0.8322
INFO - 2018-03-08 19:08:57 --> Database Driver Class Initialized
DEBUG - 2018-03-08 19:08:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-08 19:08:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 19:08:57 --> Helper loaded: form_helper
INFO - 2018-03-08 19:08:57 --> Form Validation Class Initialized
INFO - 2018-03-08 19:08:57 --> Controller Class Initialized
INFO - 2018-03-08 19:08:57 --> Model Class Initialized
INFO - 2018-03-08 19:08:57 --> Helper loaded: inflector_helper
DEBUG - 2018-03-08 19:08:57 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-08 19:08:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-08 19:08:57 --> Model Class Initialized
INFO - 2018-03-08 19:08:57 --> Model Class Initialized
INFO - 2018-03-08 19:08:57 --> Model Class Initialized
INFO - 2018-03-08 19:08:57 --> Model Class Initialized
INFO - 2018-03-08 19:08:57 --> Model Class Initialized
INFO - 2018-03-08 19:08:57 --> Model Class Initialized
INFO - 2018-03-08 19:08:57 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-08 19:08:57 --> Final output sent to browser
DEBUG - 2018-03-08 19:08:57 --> Total execution time: 1.6660
INFO - 2018-03-08 13:39:02 --> Config Class Initialized
INFO - 2018-03-08 13:39:02 --> Hooks Class Initialized
DEBUG - 2018-03-08 13:39:02 --> UTF-8 Support Enabled
INFO - 2018-03-08 13:39:02 --> Utf8 Class Initialized
INFO - 2018-03-08 13:39:02 --> URI Class Initialized
INFO - 2018-03-08 13:39:02 --> Router Class Initialized
INFO - 2018-03-08 13:39:02 --> Output Class Initialized
INFO - 2018-03-08 13:39:02 --> Security Class Initialized
DEBUG - 2018-03-08 13:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 13:39:02 --> Input Class Initialized
INFO - 2018-03-08 13:39:02 --> Language Class Initialized
INFO - 2018-03-08 13:39:02 --> Language Class Initialized
INFO - 2018-03-08 13:39:02 --> Config Class Initialized
INFO - 2018-03-08 13:39:02 --> Loader Class Initialized
INFO - 2018-03-08 19:09:02 --> Helper loaded: url_helper
INFO - 2018-03-08 19:09:02 --> Helper loaded: notification_helper
INFO - 2018-03-08 19:09:02 --> Helper loaded: settings_helper
INFO - 2018-03-08 19:09:02 --> Helper loaded: permission_helper
INFO - 2018-03-08 19:09:02 --> Helper loaded: users_helper
INFO - 2018-03-08 19:09:02 --> Database Driver Class Initialized
DEBUG - 2018-03-08 19:09:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-08 19:09:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 19:09:02 --> Helper loaded: form_helper
INFO - 2018-03-08 19:09:02 --> Form Validation Class Initialized
INFO - 2018-03-08 19:09:02 --> Controller Class Initialized
INFO - 2018-03-08 19:09:02 --> Model Class Initialized
INFO - 2018-03-08 19:09:02 --> Helper loaded: inflector_helper
DEBUG - 2018-03-08 19:09:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-08 19:09:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-08 19:09:02 --> Model Class Initialized
INFO - 2018-03-08 19:09:02 --> Model Class Initialized
INFO - 2018-03-08 19:09:02 --> Model Class Initialized
INFO - 2018-03-08 19:09:02 --> Model Class Initialized
INFO - 2018-03-08 19:09:02 --> Model Class Initialized
INFO - 2018-03-08 19:09:02 --> Model Class Initialized
INFO - 2018-03-08 19:09:02 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-08 19:09:02 --> Final output sent to browser
DEBUG - 2018-03-08 19:09:02 --> Total execution time: 0.1124
INFO - 2018-03-08 13:39:03 --> Config Class Initialized
INFO - 2018-03-08 13:39:03 --> Hooks Class Initialized
DEBUG - 2018-03-08 13:39:03 --> UTF-8 Support Enabled
INFO - 2018-03-08 13:39:03 --> Utf8 Class Initialized
INFO - 2018-03-08 13:39:03 --> URI Class Initialized
INFO - 2018-03-08 13:39:03 --> Router Class Initialized
INFO - 2018-03-08 13:39:03 --> Output Class Initialized
INFO - 2018-03-08 13:39:03 --> Security Class Initialized
DEBUG - 2018-03-08 13:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 13:39:03 --> Input Class Initialized
INFO - 2018-03-08 13:39:03 --> Language Class Initialized
INFO - 2018-03-08 13:39:03 --> Language Class Initialized
INFO - 2018-03-08 13:39:03 --> Config Class Initialized
INFO - 2018-03-08 13:39:03 --> Loader Class Initialized
INFO - 2018-03-08 19:09:03 --> Helper loaded: url_helper
INFO - 2018-03-08 19:09:04 --> Helper loaded: notification_helper
INFO - 2018-03-08 19:09:04 --> Helper loaded: settings_helper
INFO - 2018-03-08 19:09:04 --> Helper loaded: permission_helper
INFO - 2018-03-08 19:09:04 --> Helper loaded: users_helper
INFO - 2018-03-08 19:09:04 --> Database Driver Class Initialized
DEBUG - 2018-03-08 19:09:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-08 19:09:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 19:09:04 --> Helper loaded: form_helper
INFO - 2018-03-08 19:09:04 --> Form Validation Class Initialized
INFO - 2018-03-08 19:09:04 --> Controller Class Initialized
INFO - 2018-03-08 19:09:04 --> Model Class Initialized
INFO - 2018-03-08 19:09:04 --> Helper loaded: inflector_helper
DEBUG - 2018-03-08 19:09:04 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-08 19:09:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-08 19:09:04 --> Model Class Initialized
INFO - 2018-03-08 19:09:04 --> Model Class Initialized
INFO - 2018-03-08 19:09:04 --> Model Class Initialized
INFO - 2018-03-08 19:09:04 --> Model Class Initialized
INFO - 2018-03-08 19:09:04 --> Model Class Initialized
INFO - 2018-03-08 19:09:04 --> Model Class Initialized
INFO - 2018-03-08 19:09:04 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-08 19:09:04 --> Final output sent to browser
DEBUG - 2018-03-08 19:09:04 --> Total execution time: 1.2344
