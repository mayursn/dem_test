<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-03-15 13:00:46 --> Config Class Initialized
INFO - 2018-03-15 13:00:46 --> Hooks Class Initialized
DEBUG - 2018-03-15 13:00:46 --> UTF-8 Support Enabled
INFO - 2018-03-15 13:00:46 --> Utf8 Class Initialized
INFO - 2018-03-15 13:00:46 --> URI Class Initialized
DEBUG - 2018-03-15 13:00:46 --> No URI present. Default controller set.
INFO - 2018-03-15 13:00:46 --> Router Class Initialized
INFO - 2018-03-15 13:00:46 --> Output Class Initialized
INFO - 2018-03-15 13:00:46 --> Security Class Initialized
DEBUG - 2018-03-15 13:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 13:00:46 --> Input Class Initialized
INFO - 2018-03-15 13:00:46 --> Language Class Initialized
INFO - 2018-03-15 13:00:46 --> Language Class Initialized
INFO - 2018-03-15 13:00:46 --> Config Class Initialized
INFO - 2018-03-15 13:00:46 --> Loader Class Initialized
INFO - 2018-03-15 18:30:46 --> Helper loaded: url_helper
INFO - 2018-03-15 18:30:46 --> Helper loaded: notification_helper
INFO - 2018-03-15 18:30:46 --> Helper loaded: settings_helper
INFO - 2018-03-15 18:30:46 --> Helper loaded: permission_helper
INFO - 2018-03-15 18:30:46 --> Helper loaded: users_helper
INFO - 2018-03-15 18:30:46 --> Database Driver Class Initialized
DEBUG - 2018-03-15 18:30:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 18:30:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 18:30:47 --> Helper loaded: form_helper
INFO - 2018-03-15 18:30:47 --> Form Validation Class Initialized
INFO - 2018-03-15 18:30:47 --> Controller Class Initialized
INFO - 2018-03-15 18:30:47 --> Model Class Initialized
INFO - 2018-03-15 18:30:47 --> Helper loaded: inflector_helper
INFO - 2018-03-15 18:30:47 --> Model Class Initialized
DEBUG - 2018-03-15 18:30:47 --> File loaded: /home/pr01004/public_html/application/views/login.php
INFO - 2018-03-15 18:30:47 --> Final output sent to browser
DEBUG - 2018-03-15 18:30:47 --> Total execution time: 1.6335
INFO - 2018-03-15 13:00:57 --> Config Class Initialized
INFO - 2018-03-15 13:00:57 --> Hooks Class Initialized
DEBUG - 2018-03-15 13:00:57 --> UTF-8 Support Enabled
INFO - 2018-03-15 13:00:57 --> Utf8 Class Initialized
INFO - 2018-03-15 13:00:57 --> URI Class Initialized
INFO - 2018-03-15 13:00:57 --> Router Class Initialized
INFO - 2018-03-15 13:00:57 --> Output Class Initialized
INFO - 2018-03-15 13:00:57 --> Security Class Initialized
DEBUG - 2018-03-15 13:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 13:00:57 --> Input Class Initialized
INFO - 2018-03-15 13:00:57 --> Language Class Initialized
INFO - 2018-03-15 13:00:57 --> Language Class Initialized
INFO - 2018-03-15 13:00:57 --> Config Class Initialized
INFO - 2018-03-15 13:00:57 --> Loader Class Initialized
INFO - 2018-03-15 18:30:57 --> Helper loaded: url_helper
INFO - 2018-03-15 18:30:57 --> Helper loaded: notification_helper
INFO - 2018-03-15 18:30:57 --> Helper loaded: settings_helper
INFO - 2018-03-15 18:30:57 --> Helper loaded: permission_helper
INFO - 2018-03-15 18:30:57 --> Helper loaded: users_helper
INFO - 2018-03-15 18:30:57 --> Database Driver Class Initialized
DEBUG - 2018-03-15 18:30:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 18:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 18:30:57 --> Helper loaded: form_helper
INFO - 2018-03-15 18:30:57 --> Form Validation Class Initialized
INFO - 2018-03-15 18:30:57 --> Controller Class Initialized
INFO - 2018-03-15 18:30:57 --> Model Class Initialized
INFO - 2018-03-15 18:30:57 --> Helper loaded: inflector_helper
INFO - 2018-03-15 18:30:57 --> Model Class Initialized
DEBUG - 2018-03-15 18:30:57 --> File loaded: /home/pr01004/public_html/application/views/forgot_password.php
INFO - 2018-03-15 18:30:57 --> Final output sent to browser
DEBUG - 2018-03-15 18:30:57 --> Total execution time: 0.2130
INFO - 2018-03-15 13:01:08 --> Config Class Initialized
INFO - 2018-03-15 13:01:08 --> Hooks Class Initialized
DEBUG - 2018-03-15 13:01:08 --> UTF-8 Support Enabled
INFO - 2018-03-15 13:01:08 --> Utf8 Class Initialized
INFO - 2018-03-15 13:01:08 --> URI Class Initialized
INFO - 2018-03-15 13:01:08 --> Router Class Initialized
INFO - 2018-03-15 13:01:08 --> Output Class Initialized
INFO - 2018-03-15 13:01:08 --> Security Class Initialized
DEBUG - 2018-03-15 13:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 13:01:08 --> Input Class Initialized
INFO - 2018-03-15 13:01:08 --> Language Class Initialized
INFO - 2018-03-15 13:01:09 --> Language Class Initialized
INFO - 2018-03-15 13:01:09 --> Config Class Initialized
INFO - 2018-03-15 13:01:09 --> Loader Class Initialized
INFO - 2018-03-15 18:31:09 --> Helper loaded: url_helper
INFO - 2018-03-15 18:31:09 --> Helper loaded: notification_helper
INFO - 2018-03-15 18:31:09 --> Helper loaded: settings_helper
INFO - 2018-03-15 18:31:09 --> Helper loaded: permission_helper
INFO - 2018-03-15 18:31:09 --> Helper loaded: users_helper
INFO - 2018-03-15 18:31:09 --> Database Driver Class Initialized
DEBUG - 2018-03-15 18:31:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 18:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 18:31:09 --> Helper loaded: form_helper
INFO - 2018-03-15 18:31:09 --> Form Validation Class Initialized
INFO - 2018-03-15 18:31:09 --> Controller Class Initialized
INFO - 2018-03-15 18:31:10 --> Model Class Initialized
INFO - 2018-03-15 18:31:10 --> Helper loaded: inflector_helper
INFO - 2018-03-15 18:31:10 --> Model Class Initialized
INFO - 2018-03-15 18:31:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-15 18:31:10 --> Helper loaded: string_helper
DEBUG - 2018-03-15 18:31:10 --> File loaded: /home/pr01004/public_html/application/views/reset_password_email_template.php
INFO - 2018-03-15 18:31:10 --> Model Class Initialized
INFO - 2018-03-15 18:31:11 --> Email Class Initialized
INFO - 2018-03-15 18:31:12 --> Language file loaded: language/english/email_lang.php
INFO - 2018-03-15 13:01:15 --> Config Class Initialized
INFO - 2018-03-15 13:01:15 --> Hooks Class Initialized
DEBUG - 2018-03-15 13:01:15 --> UTF-8 Support Enabled
INFO - 2018-03-15 13:01:15 --> Utf8 Class Initialized
INFO - 2018-03-15 13:01:15 --> URI Class Initialized
INFO - 2018-03-15 13:01:15 --> Router Class Initialized
INFO - 2018-03-15 13:01:15 --> Output Class Initialized
INFO - 2018-03-15 13:01:15 --> Security Class Initialized
DEBUG - 2018-03-15 13:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 13:01:15 --> Input Class Initialized
INFO - 2018-03-15 13:01:15 --> Language Class Initialized
INFO - 2018-03-15 13:01:15 --> Language Class Initialized
INFO - 2018-03-15 13:01:15 --> Config Class Initialized
INFO - 2018-03-15 13:01:15 --> Loader Class Initialized
INFO - 2018-03-15 18:31:15 --> Helper loaded: url_helper
INFO - 2018-03-15 18:31:15 --> Helper loaded: notification_helper
INFO - 2018-03-15 18:31:15 --> Helper loaded: settings_helper
INFO - 2018-03-15 18:31:15 --> Helper loaded: permission_helper
INFO - 2018-03-15 18:31:15 --> Helper loaded: users_helper
INFO - 2018-03-15 18:31:15 --> Database Driver Class Initialized
DEBUG - 2018-03-15 18:31:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 18:31:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 18:31:15 --> Helper loaded: form_helper
INFO - 2018-03-15 18:31:15 --> Form Validation Class Initialized
INFO - 2018-03-15 18:31:15 --> Controller Class Initialized
DEBUG - 2018-03-15 18:31:15 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-03-15 18:31:15 --> Final output sent to browser
DEBUG - 2018-03-15 18:31:15 --> Total execution time: 0.1359
INFO - 2018-03-15 13:01:15 --> Config Class Initialized
INFO - 2018-03-15 13:01:15 --> Hooks Class Initialized
DEBUG - 2018-03-15 13:01:15 --> UTF-8 Support Enabled
INFO - 2018-03-15 13:01:15 --> Utf8 Class Initialized
INFO - 2018-03-15 13:01:15 --> URI Class Initialized
INFO - 2018-03-15 13:01:15 --> Router Class Initialized
INFO - 2018-03-15 13:01:15 --> Output Class Initialized
INFO - 2018-03-15 13:01:15 --> Security Class Initialized
DEBUG - 2018-03-15 13:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 13:01:15 --> Input Class Initialized
INFO - 2018-03-15 13:01:15 --> Language Class Initialized
INFO - 2018-03-15 13:01:15 --> Language Class Initialized
INFO - 2018-03-15 13:01:15 --> Config Class Initialized
INFO - 2018-03-15 13:01:15 --> Loader Class Initialized
INFO - 2018-03-15 18:31:15 --> Helper loaded: url_helper
INFO - 2018-03-15 18:31:15 --> Helper loaded: notification_helper
INFO - 2018-03-15 18:31:15 --> Helper loaded: settings_helper
INFO - 2018-03-15 18:31:15 --> Helper loaded: permission_helper
INFO - 2018-03-15 18:31:15 --> Helper loaded: users_helper
INFO - 2018-03-15 18:31:16 --> Database Driver Class Initialized
DEBUG - 2018-03-15 18:31:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 18:31:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 18:31:16 --> Helper loaded: form_helper
INFO - 2018-03-15 18:31:16 --> Form Validation Class Initialized
INFO - 2018-03-15 18:31:16 --> Controller Class Initialized
INFO - 2018-03-15 18:31:16 --> Model Class Initialized
INFO - 2018-03-15 18:31:16 --> Helper loaded: inflector_helper
INFO - 2018-03-15 18:31:16 --> Model Class Initialized
DEBUG - 2018-03-15 18:31:16 --> File loaded: /home/pr01004/public_html/application/views/login.php
INFO - 2018-03-15 18:31:16 --> Final output sent to browser
DEBUG - 2018-03-15 18:31:16 --> Total execution time: 0.0862
INFO - 2018-03-15 14:28:37 --> Config Class Initialized
INFO - 2018-03-15 14:28:37 --> Hooks Class Initialized
DEBUG - 2018-03-15 14:28:37 --> UTF-8 Support Enabled
INFO - 2018-03-15 14:28:37 --> Utf8 Class Initialized
INFO - 2018-03-15 14:28:37 --> URI Class Initialized
INFO - 2018-03-15 14:28:37 --> Router Class Initialized
INFO - 2018-03-15 14:28:37 --> Output Class Initialized
INFO - 2018-03-15 14:28:37 --> Config Class Initialized
INFO - 2018-03-15 14:28:37 --> Security Class Initialized
INFO - 2018-03-15 14:28:37 --> Hooks Class Initialized
DEBUG - 2018-03-15 14:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 14:28:37 --> Input Class Initialized
INFO - 2018-03-15 14:28:37 --> Language Class Initialized
INFO - 2018-03-15 14:28:38 --> Config Class Initialized
INFO - 2018-03-15 14:28:38 --> Hooks Class Initialized
DEBUG - 2018-03-15 14:28:38 --> UTF-8 Support Enabled
INFO - 2018-03-15 14:28:38 --> Utf8 Class Initialized
INFO - 2018-03-15 14:28:38 --> URI Class Initialized
INFO - 2018-03-15 14:28:38 --> Router Class Initialized
INFO - 2018-03-15 14:28:38 --> Output Class Initialized
INFO - 2018-03-15 14:28:38 --> Security Class Initialized
DEBUG - 2018-03-15 14:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 14:28:38 --> Input Class Initialized
INFO - 2018-03-15 14:28:38 --> Language Class Initialized
INFO - 2018-03-15 14:28:38 --> Language Class Initialized
INFO - 2018-03-15 14:28:38 --> Config Class Initialized
INFO - 2018-03-15 14:28:38 --> Loader Class Initialized
INFO - 2018-03-15 19:58:38 --> Helper loaded: url_helper
INFO - 2018-03-15 19:58:38 --> Helper loaded: notification_helper
INFO - 2018-03-15 19:58:38 --> Helper loaded: settings_helper
INFO - 2018-03-15 19:58:38 --> Helper loaded: permission_helper
INFO - 2018-03-15 19:58:38 --> Helper loaded: users_helper
DEBUG - 2018-03-15 14:28:38 --> UTF-8 Support Enabled
INFO - 2018-03-15 14:28:38 --> Utf8 Class Initialized
INFO - 2018-03-15 19:58:38 --> Database Driver Class Initialized
DEBUG - 2018-03-15 19:58:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 19:58:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 14:28:38 --> Language Class Initialized
INFO - 2018-03-15 14:28:38 --> Config Class Initialized
INFO - 2018-03-15 14:28:38 --> Loader Class Initialized
INFO - 2018-03-15 19:58:38 --> Helper loaded: form_helper
INFO - 2018-03-15 19:58:38 --> Form Validation Class Initialized
INFO - 2018-03-15 19:58:38 --> Controller Class Initialized
INFO - 2018-03-15 19:58:38 --> Model Class Initialized
INFO - 2018-03-15 19:58:38 --> Helper loaded: inflector_helper
DEBUG - 2018-03-15 19:58:38 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-15 19:58:38 --> Helper loaded: url_helper
INFO - 2018-03-15 19:58:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-15 19:58:38 --> Helper loaded: notification_helper
INFO - 2018-03-15 19:58:38 --> Model Class Initialized
INFO - 2018-03-15 19:58:38 --> Helper loaded: settings_helper
INFO - 2018-03-15 14:28:38 --> URI Class Initialized
INFO - 2018-03-15 19:58:38 --> Model Class Initialized
INFO - 2018-03-15 19:58:38 --> Helper loaded: permission_helper
INFO - 2018-03-15 19:58:38 --> Model Class Initialized
INFO - 2018-03-15 19:58:38 --> Model Class Initialized
INFO - 2018-03-15 19:58:38 --> Model Class Initialized
INFO - 2018-03-15 19:58:38 --> Model Class Initialized
INFO - 2018-03-15 19:58:38 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-15 19:58:38 --> Helper loaded: users_helper
INFO - 2018-03-15 19:58:38 --> Final output sent to browser
DEBUG - 2018-03-15 19:58:38 --> Total execution time: 0.1714
INFO - 2018-03-15 19:58:38 --> Database Driver Class Initialized
INFO - 2018-03-15 14:28:38 --> Router Class Initialized
DEBUG - 2018-03-15 19:58:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 19:58:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 19:58:38 --> Helper loaded: form_helper
INFO - 2018-03-15 19:58:38 --> Form Validation Class Initialized
INFO - 2018-03-15 19:58:38 --> Controller Class Initialized
INFO - 2018-03-15 14:28:38 --> Output Class Initialized
INFO - 2018-03-15 19:58:38 --> Model Class Initialized
INFO - 2018-03-15 19:58:38 --> Helper loaded: inflector_helper
DEBUG - 2018-03-15 19:58:38 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-15 19:58:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-15 14:28:38 --> Security Class Initialized
INFO - 2018-03-15 19:58:38 --> Model Class Initialized
INFO - 2018-03-15 19:58:38 --> Model Class Initialized
INFO - 2018-03-15 19:58:38 --> Model Class Initialized
INFO - 2018-03-15 19:58:38 --> Model Class Initialized
INFO - 2018-03-15 19:58:38 --> Model Class Initialized
INFO - 2018-03-15 19:58:38 --> Model Class Initialized
INFO - 2018-03-15 19:58:38 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-15 19:58:38 --> Model Class Initialized
INFO - 2018-03-15 19:58:38 --> Final output sent to browser
DEBUG - 2018-03-15 19:58:38 --> Total execution time: 1.0121
DEBUG - 2018-03-15 14:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 14:28:38 --> Input Class Initialized
INFO - 2018-03-15 14:28:38 --> Language Class Initialized
INFO - 2018-03-15 14:28:39 --> Language Class Initialized
INFO - 2018-03-15 14:28:39 --> Config Class Initialized
INFO - 2018-03-15 14:28:39 --> Loader Class Initialized
INFO - 2018-03-15 19:58:39 --> Helper loaded: url_helper
INFO - 2018-03-15 19:58:39 --> Helper loaded: notification_helper
INFO - 2018-03-15 19:58:39 --> Helper loaded: settings_helper
INFO - 2018-03-15 19:58:39 --> Helper loaded: permission_helper
INFO - 2018-03-15 19:58:39 --> Helper loaded: users_helper
INFO - 2018-03-15 19:58:39 --> Database Driver Class Initialized
DEBUG - 2018-03-15 19:58:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 19:58:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 19:58:39 --> Helper loaded: form_helper
INFO - 2018-03-15 19:58:39 --> Form Validation Class Initialized
INFO - 2018-03-15 19:58:39 --> Controller Class Initialized
INFO - 2018-03-15 19:58:39 --> Model Class Initialized
INFO - 2018-03-15 19:58:39 --> Helper loaded: inflector_helper
DEBUG - 2018-03-15 19:58:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-15 19:58:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-15 19:58:39 --> Model Class Initialized
INFO - 2018-03-15 19:58:39 --> Model Class Initialized
INFO - 2018-03-15 19:58:39 --> Model Class Initialized
INFO - 2018-03-15 19:58:39 --> Model Class Initialized
INFO - 2018-03-15 19:58:39 --> Model Class Initialized
INFO - 2018-03-15 19:58:39 --> Model Class Initialized
INFO - 2018-03-15 19:58:39 --> Model Class Initialized
INFO - 2018-03-15 19:58:39 --> Model Class Initialized
INFO - 2018-03-15 19:58:39 --> Model Class Initialized
INFO - 2018-03-15 19:58:39 --> Model Class Initialized
INFO - 2018-03-15 19:58:39 --> Model Class Initialized
INFO - 2018-03-15 19:58:39 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-15 19:58:39 --> Model Class Initialized
INFO - 2018-03-15 19:58:40 --> Final output sent to browser
DEBUG - 2018-03-15 19:58:40 --> Total execution time: 2.9335
INFO - 2018-03-15 14:28:40 --> Config Class Initialized
INFO - 2018-03-15 14:28:40 --> Hooks Class Initialized
DEBUG - 2018-03-15 14:28:41 --> UTF-8 Support Enabled
INFO - 2018-03-15 14:28:41 --> Utf8 Class Initialized
INFO - 2018-03-15 14:28:41 --> URI Class Initialized
INFO - 2018-03-15 14:28:41 --> Router Class Initialized
INFO - 2018-03-15 14:28:41 --> Output Class Initialized
INFO - 2018-03-15 14:28:41 --> Security Class Initialized
DEBUG - 2018-03-15 14:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-15 14:28:42 --> Input Class Initialized
INFO - 2018-03-15 14:28:42 --> Language Class Initialized
INFO - 2018-03-15 14:28:42 --> Language Class Initialized
INFO - 2018-03-15 14:28:42 --> Config Class Initialized
INFO - 2018-03-15 14:28:42 --> Loader Class Initialized
INFO - 2018-03-15 19:58:42 --> Helper loaded: url_helper
INFO - 2018-03-15 19:58:42 --> Helper loaded: notification_helper
INFO - 2018-03-15 19:58:42 --> Helper loaded: settings_helper
INFO - 2018-03-15 19:58:42 --> Helper loaded: permission_helper
INFO - 2018-03-15 19:58:42 --> Helper loaded: users_helper
INFO - 2018-03-15 19:58:42 --> Database Driver Class Initialized
DEBUG - 2018-03-15 19:58:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-15 19:58:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-15 19:58:43 --> Helper loaded: form_helper
INFO - 2018-03-15 19:58:43 --> Form Validation Class Initialized
INFO - 2018-03-15 19:58:43 --> Controller Class Initialized
INFO - 2018-03-15 19:58:43 --> Model Class Initialized
INFO - 2018-03-15 19:58:43 --> Helper loaded: inflector_helper
DEBUG - 2018-03-15 19:58:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-15 19:58:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-15 19:58:43 --> Model Class Initialized
INFO - 2018-03-15 19:58:43 --> Model Class Initialized
INFO - 2018-03-15 19:58:43 --> Model Class Initialized
INFO - 2018-03-15 19:58:43 --> Model Class Initialized
INFO - 2018-03-15 19:58:43 --> Model Class Initialized
INFO - 2018-03-15 19:58:43 --> Model Class Initialized
INFO - 2018-03-15 19:58:43 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-15 19:58:43 --> Final output sent to browser
DEBUG - 2018-03-15 19:58:43 --> Total execution time: 2.8150
