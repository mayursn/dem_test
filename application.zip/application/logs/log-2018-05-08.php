<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-05-08 06:04:20 --> Config Class Initialized
INFO - 2018-05-08 06:04:20 --> Hooks Class Initialized
DEBUG - 2018-05-08 06:04:20 --> UTF-8 Support Enabled
INFO - 2018-05-08 06:04:20 --> Utf8 Class Initialized
INFO - 2018-05-08 06:04:20 --> URI Class Initialized
INFO - 2018-05-08 06:04:20 --> Router Class Initialized
INFO - 2018-05-08 06:04:20 --> Output Class Initialized
INFO - 2018-05-08 06:04:20 --> Security Class Initialized
DEBUG - 2018-05-08 06:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 06:04:20 --> Input Class Initialized
INFO - 2018-05-08 06:04:20 --> Language Class Initialized
INFO - 2018-05-08 06:04:20 --> Language Class Initialized
INFO - 2018-05-08 06:04:20 --> Config Class Initialized
INFO - 2018-05-08 06:04:20 --> Loader Class Initialized
INFO - 2018-05-08 11:34:20 --> Helper loaded: url_helper
INFO - 2018-05-08 11:34:20 --> Helper loaded: notification_helper
INFO - 2018-05-08 11:34:20 --> Helper loaded: settings_helper
INFO - 2018-05-08 11:34:20 --> Helper loaded: permission_helper
INFO - 2018-05-08 11:34:20 --> Helper loaded: users_helper
INFO - 2018-05-08 11:34:20 --> Database Driver Class Initialized
DEBUG - 2018-05-08 11:34:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 11:34:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 11:34:20 --> Helper loaded: form_helper
INFO - 2018-05-08 11:34:20 --> Form Validation Class Initialized
INFO - 2018-05-08 11:34:20 --> Controller Class Initialized
INFO - 2018-05-08 11:34:20 --> Model Class Initialized
INFO - 2018-05-08 11:34:20 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 11:34:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 11:34:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 11:34:20 --> Model Class Initialized
INFO - 2018-05-08 11:34:20 --> Model Class Initialized
INFO - 2018-05-08 11:34:20 --> Model Class Initialized
INFO - 2018-05-08 11:34:20 --> Model Class Initialized
INFO - 2018-05-08 11:34:20 --> Model Class Initialized
INFO - 2018-05-08 11:34:20 --> Model Class Initialized
INFO - 2018-05-08 11:34:20 --> Model Class Initialized
INFO - 2018-05-08 11:34:20 --> Model Class Initialized
INFO - 2018-05-08 11:34:20 --> Model Class Initialized
INFO - 2018-05-08 11:34:21 --> Model Class Initialized
INFO - 2018-05-08 11:34:21 --> Model Class Initialized
INFO - 2018-05-08 11:34:21 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 11:34:21 --> Model Class Initialized
INFO - 2018-05-08 11:34:21 --> Final output sent to browser
DEBUG - 2018-05-08 11:34:21 --> Total execution time: 0.5154
INFO - 2018-05-08 06:04:21 --> Config Class Initialized
INFO - 2018-05-08 06:04:21 --> Hooks Class Initialized
DEBUG - 2018-05-08 06:04:21 --> UTF-8 Support Enabled
INFO - 2018-05-08 06:04:21 --> Utf8 Class Initialized
INFO - 2018-05-08 06:04:21 --> URI Class Initialized
INFO - 2018-05-08 06:04:21 --> Router Class Initialized
INFO - 2018-05-08 06:04:21 --> Output Class Initialized
INFO - 2018-05-08 06:04:21 --> Security Class Initialized
DEBUG - 2018-05-08 06:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 06:04:21 --> Input Class Initialized
INFO - 2018-05-08 06:04:21 --> Language Class Initialized
INFO - 2018-05-08 06:04:21 --> Language Class Initialized
INFO - 2018-05-08 06:04:21 --> Config Class Initialized
INFO - 2018-05-08 06:04:21 --> Loader Class Initialized
INFO - 2018-05-08 11:34:21 --> Helper loaded: url_helper
INFO - 2018-05-08 11:34:21 --> Helper loaded: notification_helper
INFO - 2018-05-08 11:34:21 --> Helper loaded: settings_helper
INFO - 2018-05-08 11:34:21 --> Helper loaded: permission_helper
INFO - 2018-05-08 11:34:21 --> Helper loaded: users_helper
INFO - 2018-05-08 11:34:21 --> Database Driver Class Initialized
DEBUG - 2018-05-08 11:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 11:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 11:34:21 --> Helper loaded: form_helper
INFO - 2018-05-08 11:34:21 --> Form Validation Class Initialized
INFO - 2018-05-08 11:34:21 --> Controller Class Initialized
INFO - 2018-05-08 11:34:21 --> Model Class Initialized
INFO - 2018-05-08 11:34:21 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 11:34:21 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 11:34:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 11:34:21 --> Model Class Initialized
INFO - 2018-05-08 11:34:21 --> Model Class Initialized
INFO - 2018-05-08 11:34:21 --> Model Class Initialized
INFO - 2018-05-08 11:34:21 --> Model Class Initialized
INFO - 2018-05-08 11:34:21 --> Model Class Initialized
INFO - 2018-05-08 11:34:21 --> Model Class Initialized
INFO - 2018-05-08 11:34:21 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 11:34:21 --> Model Class Initialized
INFO - 2018-05-08 11:34:21 --> Final output sent to browser
DEBUG - 2018-05-08 11:34:21 --> Total execution time: 0.1900
INFO - 2018-05-08 06:04:31 --> Config Class Initialized
INFO - 2018-05-08 06:04:31 --> Hooks Class Initialized
INFO - 2018-05-08 06:04:31 --> Config Class Initialized
INFO - 2018-05-08 06:04:31 --> Hooks Class Initialized
DEBUG - 2018-05-08 06:04:31 --> UTF-8 Support Enabled
INFO - 2018-05-08 06:04:31 --> Utf8 Class Initialized
DEBUG - 2018-05-08 06:04:31 --> UTF-8 Support Enabled
INFO - 2018-05-08 06:04:31 --> Utf8 Class Initialized
INFO - 2018-05-08 06:04:31 --> URI Class Initialized
INFO - 2018-05-08 06:04:31 --> URI Class Initialized
INFO - 2018-05-08 06:04:31 --> Router Class Initialized
INFO - 2018-05-08 06:04:31 --> Router Class Initialized
INFO - 2018-05-08 06:04:31 --> Output Class Initialized
INFO - 2018-05-08 06:04:31 --> Output Class Initialized
INFO - 2018-05-08 06:04:31 --> Security Class Initialized
INFO - 2018-05-08 06:04:31 --> Security Class Initialized
DEBUG - 2018-05-08 06:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-08 06:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 06:04:31 --> Input Class Initialized
INFO - 2018-05-08 06:04:31 --> Input Class Initialized
INFO - 2018-05-08 06:04:31 --> Language Class Initialized
INFO - 2018-05-08 06:04:31 --> Language Class Initialized
INFO - 2018-05-08 06:04:32 --> Language Class Initialized
INFO - 2018-05-08 06:04:32 --> Config Class Initialized
INFO - 2018-05-08 06:04:32 --> Loader Class Initialized
INFO - 2018-05-08 11:34:32 --> Helper loaded: url_helper
INFO - 2018-05-08 11:34:32 --> Helper loaded: notification_helper
INFO - 2018-05-08 06:04:32 --> Language Class Initialized
INFO - 2018-05-08 06:04:32 --> Config Class Initialized
INFO - 2018-05-08 06:04:32 --> Loader Class Initialized
INFO - 2018-05-08 11:34:32 --> Helper loaded: settings_helper
INFO - 2018-05-08 11:34:32 --> Helper loaded: permission_helper
INFO - 2018-05-08 11:34:32 --> Helper loaded: users_helper
INFO - 2018-05-08 11:34:32 --> Helper loaded: url_helper
INFO - 2018-05-08 11:34:32 --> Helper loaded: notification_helper
INFO - 2018-05-08 11:34:32 --> Helper loaded: settings_helper
INFO - 2018-05-08 11:34:32 --> Helper loaded: permission_helper
INFO - 2018-05-08 11:34:32 --> Helper loaded: users_helper
INFO - 2018-05-08 11:34:32 --> Database Driver Class Initialized
INFO - 2018-05-08 11:34:32 --> Database Driver Class Initialized
DEBUG - 2018-05-08 11:34:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 11:34:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-05-08 11:34:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 11:34:32 --> Helper loaded: form_helper
INFO - 2018-05-08 11:34:32 --> Form Validation Class Initialized
INFO - 2018-05-08 11:34:32 --> Controller Class Initialized
INFO - 2018-05-08 11:34:32 --> Model Class Initialized
INFO - 2018-05-08 11:34:32 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 11:34:32 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 11:34:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 11:34:32 --> Model Class Initialized
INFO - 2018-05-08 11:34:32 --> Model Class Initialized
INFO - 2018-05-08 11:34:32 --> Model Class Initialized
INFO - 2018-05-08 11:34:32 --> Model Class Initialized
INFO - 2018-05-08 11:34:32 --> Model Class Initialized
INFO - 2018-05-08 11:34:32 --> Model Class Initialized
INFO - 2018-05-08 11:34:32 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 11:34:32 --> Final output sent to browser
DEBUG - 2018-05-08 11:34:32 --> Total execution time: 0.1313
INFO - 2018-05-08 11:34:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 11:34:32 --> Helper loaded: form_helper
INFO - 2018-05-08 11:34:32 --> Form Validation Class Initialized
INFO - 2018-05-08 11:34:32 --> Controller Class Initialized
INFO - 2018-05-08 11:34:32 --> Model Class Initialized
INFO - 2018-05-08 11:34:32 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 11:34:32 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 11:34:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 11:34:32 --> Model Class Initialized
INFO - 2018-05-08 11:34:32 --> Model Class Initialized
INFO - 2018-05-08 11:34:32 --> Model Class Initialized
INFO - 2018-05-08 11:34:32 --> Model Class Initialized
INFO - 2018-05-08 11:34:32 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 11:34:32 --> Final output sent to browser
DEBUG - 2018-05-08 11:34:32 --> Total execution time: 0.1776
INFO - 2018-05-08 06:04:34 --> Config Class Initialized
INFO - 2018-05-08 06:04:34 --> Hooks Class Initialized
DEBUG - 2018-05-08 06:04:34 --> UTF-8 Support Enabled
INFO - 2018-05-08 06:04:34 --> Utf8 Class Initialized
INFO - 2018-05-08 06:04:34 --> URI Class Initialized
INFO - 2018-05-08 06:04:34 --> Router Class Initialized
INFO - 2018-05-08 06:04:34 --> Output Class Initialized
INFO - 2018-05-08 06:04:34 --> Security Class Initialized
DEBUG - 2018-05-08 06:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 06:04:34 --> Input Class Initialized
INFO - 2018-05-08 06:04:34 --> Language Class Initialized
INFO - 2018-05-08 06:04:34 --> Language Class Initialized
INFO - 2018-05-08 06:04:34 --> Config Class Initialized
INFO - 2018-05-08 06:04:34 --> Loader Class Initialized
INFO - 2018-05-08 11:34:34 --> Helper loaded: url_helper
INFO - 2018-05-08 11:34:34 --> Helper loaded: notification_helper
INFO - 2018-05-08 11:34:34 --> Helper loaded: settings_helper
INFO - 2018-05-08 11:34:34 --> Helper loaded: permission_helper
INFO - 2018-05-08 11:34:34 --> Helper loaded: users_helper
INFO - 2018-05-08 11:34:34 --> Database Driver Class Initialized
DEBUG - 2018-05-08 11:34:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 11:34:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 11:34:34 --> Helper loaded: form_helper
INFO - 2018-05-08 11:34:34 --> Form Validation Class Initialized
INFO - 2018-05-08 11:34:34 --> Controller Class Initialized
INFO - 2018-05-08 11:34:34 --> Model Class Initialized
INFO - 2018-05-08 11:34:34 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 11:34:34 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 11:34:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 11:34:34 --> Model Class Initialized
INFO - 2018-05-08 11:34:34 --> Model Class Initialized
INFO - 2018-05-08 11:34:34 --> Model Class Initialized
INFO - 2018-05-08 11:34:34 --> Model Class Initialized
INFO - 2018-05-08 11:34:34 --> Model Class Initialized
INFO - 2018-05-08 11:34:34 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 11:34:34 --> Model Class Initialized
INFO - 2018-05-08 11:34:34 --> Final output sent to browser
DEBUG - 2018-05-08 11:34:34 --> Total execution time: 0.1531
INFO - 2018-05-08 06:04:35 --> Config Class Initialized
INFO - 2018-05-08 06:04:35 --> Hooks Class Initialized
DEBUG - 2018-05-08 06:04:35 --> UTF-8 Support Enabled
INFO - 2018-05-08 06:04:35 --> Utf8 Class Initialized
INFO - 2018-05-08 06:04:35 --> URI Class Initialized
INFO - 2018-05-08 06:04:35 --> Router Class Initialized
INFO - 2018-05-08 06:04:35 --> Output Class Initialized
INFO - 2018-05-08 06:04:35 --> Security Class Initialized
DEBUG - 2018-05-08 06:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 06:04:35 --> Input Class Initialized
INFO - 2018-05-08 06:04:35 --> Language Class Initialized
INFO - 2018-05-08 06:04:35 --> Language Class Initialized
INFO - 2018-05-08 06:04:35 --> Config Class Initialized
INFO - 2018-05-08 06:04:35 --> Loader Class Initialized
INFO - 2018-05-08 11:34:35 --> Helper loaded: url_helper
INFO - 2018-05-08 11:34:35 --> Helper loaded: notification_helper
INFO - 2018-05-08 11:34:35 --> Helper loaded: settings_helper
INFO - 2018-05-08 11:34:35 --> Helper loaded: permission_helper
INFO - 2018-05-08 11:34:35 --> Helper loaded: users_helper
INFO - 2018-05-08 11:34:35 --> Database Driver Class Initialized
DEBUG - 2018-05-08 11:34:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 11:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 11:34:35 --> Helper loaded: form_helper
INFO - 2018-05-08 11:34:35 --> Form Validation Class Initialized
INFO - 2018-05-08 11:34:35 --> Controller Class Initialized
INFO - 2018-05-08 11:34:35 --> Model Class Initialized
INFO - 2018-05-08 11:34:35 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 11:34:35 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 11:34:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 11:34:35 --> Model Class Initialized
INFO - 2018-05-08 11:34:35 --> Model Class Initialized
INFO - 2018-05-08 11:34:35 --> Model Class Initialized
INFO - 2018-05-08 11:34:35 --> Model Class Initialized
INFO - 2018-05-08 11:34:35 --> Model Class Initialized
INFO - 2018-05-08 11:34:35 --> Model Class Initialized
INFO - 2018-05-08 11:34:35 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 11:34:35 --> Final output sent to browser
DEBUG - 2018-05-08 11:34:35 --> Total execution time: 0.1316
INFO - 2018-05-08 06:09:56 --> Config Class Initialized
INFO - 2018-05-08 06:09:56 --> Hooks Class Initialized
DEBUG - 2018-05-08 06:09:56 --> UTF-8 Support Enabled
INFO - 2018-05-08 06:09:56 --> Utf8 Class Initialized
INFO - 2018-05-08 06:09:56 --> URI Class Initialized
INFO - 2018-05-08 06:09:56 --> Router Class Initialized
INFO - 2018-05-08 06:09:56 --> Output Class Initialized
INFO - 2018-05-08 06:09:56 --> Security Class Initialized
DEBUG - 2018-05-08 06:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 06:09:56 --> Input Class Initialized
INFO - 2018-05-08 06:09:56 --> Language Class Initialized
INFO - 2018-05-08 06:09:56 --> Language Class Initialized
INFO - 2018-05-08 06:09:56 --> Config Class Initialized
INFO - 2018-05-08 06:09:56 --> Loader Class Initialized
INFO - 2018-05-08 11:39:56 --> Helper loaded: url_helper
INFO - 2018-05-08 11:39:56 --> Helper loaded: notification_helper
INFO - 2018-05-08 11:39:56 --> Helper loaded: settings_helper
INFO - 2018-05-08 11:39:56 --> Helper loaded: permission_helper
INFO - 2018-05-08 11:39:56 --> Helper loaded: users_helper
INFO - 2018-05-08 11:39:56 --> Database Driver Class Initialized
DEBUG - 2018-05-08 11:39:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 11:39:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 11:39:56 --> Helper loaded: form_helper
INFO - 2018-05-08 11:39:56 --> Form Validation Class Initialized
INFO - 2018-05-08 11:39:56 --> Controller Class Initialized
INFO - 2018-05-08 11:39:56 --> Model Class Initialized
INFO - 2018-05-08 11:39:56 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 11:39:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 11:39:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 11:39:56 --> Model Class Initialized
INFO - 2018-05-08 11:39:56 --> Model Class Initialized
INFO - 2018-05-08 11:39:56 --> Model Class Initialized
INFO - 2018-05-08 11:39:56 --> Model Class Initialized
INFO - 2018-05-08 11:39:56 --> Model Class Initialized
INFO - 2018-05-08 11:39:56 --> Model Class Initialized
INFO - 2018-05-08 11:39:56 --> Model Class Initialized
INFO - 2018-05-08 11:39:56 --> Model Class Initialized
INFO - 2018-05-08 11:39:56 --> Model Class Initialized
INFO - 2018-05-08 11:39:56 --> Model Class Initialized
INFO - 2018-05-08 11:39:56 --> Model Class Initialized
INFO - 2018-05-08 11:39:56 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 11:39:56 --> Model Class Initialized
INFO - 2018-05-08 06:09:56 --> Config Class Initialized
INFO - 2018-05-08 06:09:56 --> Hooks Class Initialized
DEBUG - 2018-05-08 06:09:56 --> UTF-8 Support Enabled
INFO - 2018-05-08 06:09:56 --> Utf8 Class Initialized
INFO - 2018-05-08 06:09:56 --> URI Class Initialized
INFO - 2018-05-08 06:09:56 --> Router Class Initialized
INFO - 2018-05-08 06:09:56 --> Output Class Initialized
INFO - 2018-05-08 06:09:56 --> Security Class Initialized
DEBUG - 2018-05-08 06:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 06:09:56 --> Input Class Initialized
INFO - 2018-05-08 06:09:56 --> Language Class Initialized
INFO - 2018-05-08 11:39:56 --> Final output sent to browser
DEBUG - 2018-05-08 11:39:56 --> Total execution time: 0.1981
INFO - 2018-05-08 06:09:56 --> Language Class Initialized
INFO - 2018-05-08 06:09:56 --> Config Class Initialized
INFO - 2018-05-08 06:09:56 --> Loader Class Initialized
INFO - 2018-05-08 11:39:56 --> Helper loaded: url_helper
INFO - 2018-05-08 11:39:56 --> Helper loaded: notification_helper
INFO - 2018-05-08 11:39:56 --> Helper loaded: settings_helper
INFO - 2018-05-08 11:39:56 --> Helper loaded: permission_helper
INFO - 2018-05-08 11:39:56 --> Helper loaded: users_helper
INFO - 2018-05-08 11:39:56 --> Database Driver Class Initialized
DEBUG - 2018-05-08 11:39:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 11:39:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 11:39:56 --> Helper loaded: form_helper
INFO - 2018-05-08 11:39:56 --> Form Validation Class Initialized
INFO - 2018-05-08 11:39:56 --> Controller Class Initialized
INFO - 2018-05-08 11:39:56 --> Model Class Initialized
INFO - 2018-05-08 11:39:56 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 11:39:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 11:39:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 11:39:56 --> Model Class Initialized
INFO - 2018-05-08 11:39:56 --> Model Class Initialized
INFO - 2018-05-08 11:39:56 --> Model Class Initialized
INFO - 2018-05-08 11:39:56 --> Model Class Initialized
INFO - 2018-05-08 11:39:56 --> Model Class Initialized
INFO - 2018-05-08 11:39:56 --> Model Class Initialized
INFO - 2018-05-08 11:39:56 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 11:39:56 --> Model Class Initialized
INFO - 2018-05-08 11:39:56 --> Final output sent to browser
DEBUG - 2018-05-08 11:39:56 --> Total execution time: 0.1369
INFO - 2018-05-08 06:10:28 --> Config Class Initialized
INFO - 2018-05-08 06:10:28 --> Hooks Class Initialized
DEBUG - 2018-05-08 06:10:28 --> UTF-8 Support Enabled
INFO - 2018-05-08 06:10:28 --> Utf8 Class Initialized
INFO - 2018-05-08 06:10:29 --> URI Class Initialized
INFO - 2018-05-08 06:10:29 --> Router Class Initialized
INFO - 2018-05-08 06:10:29 --> Output Class Initialized
INFO - 2018-05-08 06:10:29 --> Security Class Initialized
INFO - 2018-05-08 06:10:29 --> Config Class Initialized
INFO - 2018-05-08 06:10:29 --> Hooks Class Initialized
DEBUG - 2018-05-08 06:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 06:10:29 --> Input Class Initialized
INFO - 2018-05-08 06:10:29 --> Language Class Initialized
DEBUG - 2018-05-08 06:10:29 --> UTF-8 Support Enabled
INFO - 2018-05-08 06:10:29 --> Utf8 Class Initialized
INFO - 2018-05-08 06:10:29 --> URI Class Initialized
INFO - 2018-05-08 06:10:29 --> Router Class Initialized
INFO - 2018-05-08 06:10:29 --> Output Class Initialized
INFO - 2018-05-08 06:10:29 --> Language Class Initialized
INFO - 2018-05-08 06:10:29 --> Config Class Initialized
INFO - 2018-05-08 06:10:29 --> Loader Class Initialized
INFO - 2018-05-08 06:10:29 --> Security Class Initialized
INFO - 2018-05-08 11:40:29 --> Helper loaded: url_helper
DEBUG - 2018-05-08 06:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 06:10:29 --> Input Class Initialized
INFO - 2018-05-08 11:40:29 --> Helper loaded: notification_helper
INFO - 2018-05-08 11:40:29 --> Helper loaded: settings_helper
INFO - 2018-05-08 11:40:29 --> Helper loaded: permission_helper
INFO - 2018-05-08 11:40:29 --> Helper loaded: users_helper
INFO - 2018-05-08 06:10:29 --> Language Class Initialized
INFO - 2018-05-08 11:40:29 --> Database Driver Class Initialized
INFO - 2018-05-08 06:10:29 --> Language Class Initialized
INFO - 2018-05-08 06:10:29 --> Config Class Initialized
INFO - 2018-05-08 06:10:29 --> Loader Class Initialized
DEBUG - 2018-05-08 11:40:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 11:40:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 11:40:29 --> Helper loaded: url_helper
INFO - 2018-05-08 11:40:29 --> Helper loaded: notification_helper
INFO - 2018-05-08 11:40:29 --> Helper loaded: settings_helper
INFO - 2018-05-08 11:40:29 --> Helper loaded: permission_helper
INFO - 2018-05-08 11:40:29 --> Helper loaded: users_helper
INFO - 2018-05-08 11:40:29 --> Helper loaded: form_helper
INFO - 2018-05-08 11:40:29 --> Form Validation Class Initialized
INFO - 2018-05-08 11:40:29 --> Controller Class Initialized
INFO - 2018-05-08 11:40:29 --> Model Class Initialized
INFO - 2018-05-08 11:40:29 --> Helper loaded: inflector_helper
INFO - 2018-05-08 11:40:29 --> Database Driver Class Initialized
DEBUG - 2018-05-08 11:40:29 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 11:40:29 --> Language file loaded: language/english/rest_controller_lang.php
DEBUG - 2018-05-08 11:40:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 11:40:29 --> Model Class Initialized
INFO - 2018-05-08 11:40:29 --> Model Class Initialized
INFO - 2018-05-08 11:40:29 --> Model Class Initialized
INFO - 2018-05-08 11:40:29 --> Model Class Initialized
INFO - 2018-05-08 11:40:29 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 11:40:29 --> Final output sent to browser
DEBUG - 2018-05-08 11:40:29 --> Total execution time: 0.1364
INFO - 2018-05-08 11:40:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 11:40:29 --> Helper loaded: form_helper
INFO - 2018-05-08 11:40:29 --> Form Validation Class Initialized
INFO - 2018-05-08 11:40:29 --> Controller Class Initialized
INFO - 2018-05-08 11:40:29 --> Model Class Initialized
INFO - 2018-05-08 11:40:29 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 11:40:29 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 11:40:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 11:40:29 --> Model Class Initialized
INFO - 2018-05-08 11:40:29 --> Model Class Initialized
INFO - 2018-05-08 11:40:29 --> Model Class Initialized
INFO - 2018-05-08 11:40:29 --> Model Class Initialized
INFO - 2018-05-08 11:40:29 --> Model Class Initialized
INFO - 2018-05-08 11:40:29 --> Model Class Initialized
INFO - 2018-05-08 11:40:29 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 11:40:29 --> Final output sent to browser
DEBUG - 2018-05-08 11:40:29 --> Total execution time: 0.1509
INFO - 2018-05-08 06:10:30 --> Config Class Initialized
INFO - 2018-05-08 06:10:30 --> Hooks Class Initialized
DEBUG - 2018-05-08 06:10:30 --> UTF-8 Support Enabled
INFO - 2018-05-08 06:10:30 --> Utf8 Class Initialized
INFO - 2018-05-08 06:10:30 --> URI Class Initialized
INFO - 2018-05-08 06:10:30 --> Router Class Initialized
INFO - 2018-05-08 06:10:30 --> Output Class Initialized
INFO - 2018-05-08 06:10:30 --> Security Class Initialized
DEBUG - 2018-05-08 06:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 06:10:30 --> Input Class Initialized
INFO - 2018-05-08 06:10:30 --> Language Class Initialized
INFO - 2018-05-08 06:10:30 --> Language Class Initialized
INFO - 2018-05-08 06:10:30 --> Config Class Initialized
INFO - 2018-05-08 06:10:30 --> Loader Class Initialized
INFO - 2018-05-08 11:40:30 --> Helper loaded: url_helper
INFO - 2018-05-08 11:40:30 --> Helper loaded: notification_helper
INFO - 2018-05-08 11:40:30 --> Helper loaded: settings_helper
INFO - 2018-05-08 11:40:30 --> Helper loaded: permission_helper
INFO - 2018-05-08 11:40:30 --> Helper loaded: users_helper
INFO - 2018-05-08 11:40:31 --> Database Driver Class Initialized
DEBUG - 2018-05-08 11:40:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 11:40:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 11:40:31 --> Helper loaded: form_helper
INFO - 2018-05-08 11:40:31 --> Form Validation Class Initialized
INFO - 2018-05-08 11:40:31 --> Controller Class Initialized
INFO - 2018-05-08 11:40:31 --> Model Class Initialized
INFO - 2018-05-08 11:40:31 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 11:40:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 11:40:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 11:40:31 --> Model Class Initialized
INFO - 2018-05-08 11:40:31 --> Model Class Initialized
INFO - 2018-05-08 11:40:31 --> Model Class Initialized
INFO - 2018-05-08 11:40:31 --> Model Class Initialized
INFO - 2018-05-08 11:40:31 --> Model Class Initialized
INFO - 2018-05-08 11:40:31 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 11:40:31 --> Model Class Initialized
INFO - 2018-05-08 11:40:31 --> Final output sent to browser
DEBUG - 2018-05-08 11:40:31 --> Total execution time: 0.1713
INFO - 2018-05-08 06:10:31 --> Config Class Initialized
INFO - 2018-05-08 06:10:31 --> Hooks Class Initialized
DEBUG - 2018-05-08 06:10:31 --> UTF-8 Support Enabled
INFO - 2018-05-08 06:10:31 --> Utf8 Class Initialized
INFO - 2018-05-08 06:10:31 --> URI Class Initialized
INFO - 2018-05-08 06:10:31 --> Router Class Initialized
INFO - 2018-05-08 06:10:31 --> Output Class Initialized
INFO - 2018-05-08 06:10:31 --> Security Class Initialized
DEBUG - 2018-05-08 06:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 06:10:31 --> Input Class Initialized
INFO - 2018-05-08 06:10:31 --> Language Class Initialized
INFO - 2018-05-08 06:10:31 --> Language Class Initialized
INFO - 2018-05-08 06:10:31 --> Config Class Initialized
INFO - 2018-05-08 06:10:31 --> Loader Class Initialized
INFO - 2018-05-08 11:40:31 --> Helper loaded: url_helper
INFO - 2018-05-08 11:40:31 --> Helper loaded: notification_helper
INFO - 2018-05-08 11:40:31 --> Helper loaded: settings_helper
INFO - 2018-05-08 11:40:31 --> Helper loaded: permission_helper
INFO - 2018-05-08 11:40:31 --> Helper loaded: users_helper
INFO - 2018-05-08 11:40:31 --> Database Driver Class Initialized
DEBUG - 2018-05-08 11:40:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 11:40:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 11:40:31 --> Helper loaded: form_helper
INFO - 2018-05-08 11:40:31 --> Form Validation Class Initialized
INFO - 2018-05-08 11:40:31 --> Controller Class Initialized
INFO - 2018-05-08 11:40:31 --> Model Class Initialized
INFO - 2018-05-08 11:40:31 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 11:40:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 11:40:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 11:40:31 --> Model Class Initialized
INFO - 2018-05-08 11:40:31 --> Model Class Initialized
INFO - 2018-05-08 11:40:31 --> Model Class Initialized
INFO - 2018-05-08 11:40:31 --> Model Class Initialized
INFO - 2018-05-08 11:40:31 --> Model Class Initialized
INFO - 2018-05-08 11:40:31 --> Model Class Initialized
INFO - 2018-05-08 11:40:31 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 11:40:31 --> Final output sent to browser
DEBUG - 2018-05-08 11:40:31 --> Total execution time: 0.2579
INFO - 2018-05-08 06:57:50 --> Config Class Initialized
INFO - 2018-05-08 06:57:50 --> Hooks Class Initialized
DEBUG - 2018-05-08 06:57:50 --> UTF-8 Support Enabled
INFO - 2018-05-08 06:57:50 --> Utf8 Class Initialized
INFO - 2018-05-08 06:57:50 --> URI Class Initialized
INFO - 2018-05-08 06:57:50 --> Router Class Initialized
INFO - 2018-05-08 06:57:50 --> Output Class Initialized
INFO - 2018-05-08 06:57:50 --> Security Class Initialized
DEBUG - 2018-05-08 06:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 06:57:50 --> Input Class Initialized
INFO - 2018-05-08 06:57:50 --> Language Class Initialized
INFO - 2018-05-08 06:57:50 --> Language Class Initialized
INFO - 2018-05-08 06:57:50 --> Config Class Initialized
INFO - 2018-05-08 06:57:50 --> Loader Class Initialized
INFO - 2018-05-08 12:27:50 --> Helper loaded: url_helper
INFO - 2018-05-08 12:27:50 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:27:50 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:27:50 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:27:50 --> Helper loaded: users_helper
INFO - 2018-05-08 12:27:50 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:27:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:27:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:27:50 --> Helper loaded: form_helper
INFO - 2018-05-08 12:27:50 --> Form Validation Class Initialized
INFO - 2018-05-08 12:27:50 --> Controller Class Initialized
INFO - 2018-05-08 12:27:50 --> Model Class Initialized
INFO - 2018-05-08 12:27:50 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:27:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:27:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:27:50 --> Model Class Initialized
INFO - 2018-05-08 12:27:50 --> Model Class Initialized
INFO - 2018-05-08 12:27:50 --> Model Class Initialized
INFO - 2018-05-08 12:27:50 --> Model Class Initialized
INFO - 2018-05-08 12:27:50 --> Model Class Initialized
INFO - 2018-05-08 12:27:50 --> Model Class Initialized
INFO - 2018-05-08 12:27:50 --> Model Class Initialized
INFO - 2018-05-08 12:27:50 --> Model Class Initialized
INFO - 2018-05-08 12:27:50 --> Model Class Initialized
INFO - 2018-05-08 12:27:50 --> Model Class Initialized
INFO - 2018-05-08 12:27:50 --> Model Class Initialized
INFO - 2018-05-08 12:27:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:27:50 --> Model Class Initialized
INFO - 2018-05-08 12:27:50 --> Final output sent to browser
DEBUG - 2018-05-08 12:27:50 --> Total execution time: 0.1339
INFO - 2018-05-08 06:57:51 --> Config Class Initialized
INFO - 2018-05-08 06:57:51 --> Hooks Class Initialized
DEBUG - 2018-05-08 06:57:51 --> UTF-8 Support Enabled
INFO - 2018-05-08 06:57:51 --> Utf8 Class Initialized
INFO - 2018-05-08 06:57:51 --> URI Class Initialized
INFO - 2018-05-08 06:57:51 --> Router Class Initialized
INFO - 2018-05-08 06:57:51 --> Output Class Initialized
INFO - 2018-05-08 06:57:51 --> Security Class Initialized
DEBUG - 2018-05-08 06:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 06:57:51 --> Input Class Initialized
INFO - 2018-05-08 06:57:51 --> Language Class Initialized
INFO - 2018-05-08 06:57:51 --> Language Class Initialized
INFO - 2018-05-08 06:57:51 --> Config Class Initialized
INFO - 2018-05-08 06:57:51 --> Loader Class Initialized
INFO - 2018-05-08 12:27:51 --> Helper loaded: url_helper
INFO - 2018-05-08 12:27:51 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:27:51 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:27:51 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:27:51 --> Helper loaded: users_helper
INFO - 2018-05-08 12:27:51 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:27:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:27:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:27:51 --> Helper loaded: form_helper
INFO - 2018-05-08 12:27:51 --> Form Validation Class Initialized
INFO - 2018-05-08 12:27:51 --> Controller Class Initialized
INFO - 2018-05-08 12:27:51 --> Model Class Initialized
INFO - 2018-05-08 12:27:51 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:27:51 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:27:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:27:51 --> Model Class Initialized
INFO - 2018-05-08 12:27:51 --> Model Class Initialized
INFO - 2018-05-08 12:27:51 --> Model Class Initialized
INFO - 2018-05-08 12:27:51 --> Model Class Initialized
INFO - 2018-05-08 12:27:51 --> Model Class Initialized
INFO - 2018-05-08 12:27:51 --> Model Class Initialized
INFO - 2018-05-08 12:27:51 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:27:51 --> Model Class Initialized
INFO - 2018-05-08 12:27:51 --> Final output sent to browser
DEBUG - 2018-05-08 12:27:51 --> Total execution time: 0.1106
INFO - 2018-05-08 06:57:59 --> Config Class Initialized
INFO - 2018-05-08 06:57:59 --> Hooks Class Initialized
DEBUG - 2018-05-08 06:57:59 --> UTF-8 Support Enabled
INFO - 2018-05-08 06:57:59 --> Utf8 Class Initialized
INFO - 2018-05-08 06:57:59 --> URI Class Initialized
INFO - 2018-05-08 06:57:59 --> Router Class Initialized
INFO - 2018-05-08 06:57:59 --> Output Class Initialized
INFO - 2018-05-08 06:57:59 --> Config Class Initialized
INFO - 2018-05-08 06:57:59 --> Hooks Class Initialized
INFO - 2018-05-08 06:57:59 --> Security Class Initialized
DEBUG - 2018-05-08 06:57:59 --> UTF-8 Support Enabled
INFO - 2018-05-08 06:57:59 --> Utf8 Class Initialized
INFO - 2018-05-08 06:57:59 --> URI Class Initialized
DEBUG - 2018-05-08 06:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 06:57:59 --> Input Class Initialized
INFO - 2018-05-08 06:57:59 --> Language Class Initialized
INFO - 2018-05-08 06:57:59 --> Router Class Initialized
INFO - 2018-05-08 06:57:59 --> Output Class Initialized
INFO - 2018-05-08 06:57:59 --> Security Class Initialized
DEBUG - 2018-05-08 06:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 06:57:59 --> Input Class Initialized
INFO - 2018-05-08 06:57:59 --> Language Class Initialized
INFO - 2018-05-08 06:57:59 --> Language Class Initialized
INFO - 2018-05-08 06:57:59 --> Config Class Initialized
INFO - 2018-05-08 06:57:59 --> Loader Class Initialized
INFO - 2018-05-08 12:27:59 --> Helper loaded: url_helper
INFO - 2018-05-08 12:27:59 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:27:59 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:27:59 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:27:59 --> Helper loaded: users_helper
INFO - 2018-05-08 06:57:59 --> Language Class Initialized
INFO - 2018-05-08 06:57:59 --> Config Class Initialized
INFO - 2018-05-08 06:57:59 --> Loader Class Initialized
INFO - 2018-05-08 12:27:59 --> Database Driver Class Initialized
INFO - 2018-05-08 12:27:59 --> Helper loaded: url_helper
INFO - 2018-05-08 12:27:59 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:27:59 --> Helper loaded: settings_helper
DEBUG - 2018-05-08 12:27:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:27:59 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:27:59 --> Helper loaded: users_helper
INFO - 2018-05-08 12:27:59 --> Helper loaded: form_helper
INFO - 2018-05-08 12:27:59 --> Form Validation Class Initialized
INFO - 2018-05-08 12:27:59 --> Controller Class Initialized
INFO - 2018-05-08 12:27:59 --> Model Class Initialized
INFO - 2018-05-08 12:27:59 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:27:59 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:27:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:27:59 --> Model Class Initialized
INFO - 2018-05-08 12:27:59 --> Model Class Initialized
INFO - 2018-05-08 12:27:59 --> Model Class Initialized
INFO - 2018-05-08 12:27:59 --> Model Class Initialized
INFO - 2018-05-08 12:27:59 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:27:59 --> Final output sent to browser
DEBUG - 2018-05-08 12:27:59 --> Total execution time: 0.1573
INFO - 2018-05-08 12:27:59 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:27:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:27:59 --> Helper loaded: form_helper
INFO - 2018-05-08 12:27:59 --> Form Validation Class Initialized
INFO - 2018-05-08 12:27:59 --> Controller Class Initialized
INFO - 2018-05-08 12:27:59 --> Model Class Initialized
INFO - 2018-05-08 12:27:59 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:27:59 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:27:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:27:59 --> Model Class Initialized
INFO - 2018-05-08 12:27:59 --> Model Class Initialized
INFO - 2018-05-08 12:27:59 --> Model Class Initialized
INFO - 2018-05-08 12:27:59 --> Model Class Initialized
INFO - 2018-05-08 12:27:59 --> Model Class Initialized
INFO - 2018-05-08 12:27:59 --> Model Class Initialized
INFO - 2018-05-08 12:27:59 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:27:59 --> Final output sent to browser
DEBUG - 2018-05-08 12:27:59 --> Total execution time: 0.1797
INFO - 2018-05-08 06:58:01 --> Config Class Initialized
INFO - 2018-05-08 06:58:01 --> Hooks Class Initialized
DEBUG - 2018-05-08 06:58:01 --> UTF-8 Support Enabled
INFO - 2018-05-08 06:58:01 --> Utf8 Class Initialized
INFO - 2018-05-08 06:58:01 --> URI Class Initialized
INFO - 2018-05-08 06:58:01 --> Router Class Initialized
INFO - 2018-05-08 06:58:01 --> Output Class Initialized
INFO - 2018-05-08 06:58:01 --> Security Class Initialized
DEBUG - 2018-05-08 06:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 06:58:01 --> Input Class Initialized
INFO - 2018-05-08 06:58:01 --> Language Class Initialized
INFO - 2018-05-08 06:58:01 --> Language Class Initialized
INFO - 2018-05-08 06:58:01 --> Config Class Initialized
INFO - 2018-05-08 06:58:01 --> Loader Class Initialized
INFO - 2018-05-08 12:28:01 --> Helper loaded: url_helper
INFO - 2018-05-08 12:28:01 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:28:01 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:28:01 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:28:01 --> Helper loaded: users_helper
INFO - 2018-05-08 12:28:01 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:28:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:28:01 --> Helper loaded: form_helper
INFO - 2018-05-08 12:28:01 --> Form Validation Class Initialized
INFO - 2018-05-08 12:28:01 --> Controller Class Initialized
INFO - 2018-05-08 12:28:01 --> Model Class Initialized
INFO - 2018-05-08 12:28:01 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:28:01 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:28:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:28:01 --> Model Class Initialized
INFO - 2018-05-08 12:28:01 --> Model Class Initialized
INFO - 2018-05-08 12:28:01 --> Model Class Initialized
INFO - 2018-05-08 12:28:01 --> Model Class Initialized
INFO - 2018-05-08 12:28:01 --> Model Class Initialized
INFO - 2018-05-08 12:28:01 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:28:01 --> Model Class Initialized
INFO - 2018-05-08 12:28:01 --> Final output sent to browser
DEBUG - 2018-05-08 12:28:01 --> Total execution time: 0.1114
INFO - 2018-05-08 06:58:01 --> Config Class Initialized
INFO - 2018-05-08 06:58:01 --> Hooks Class Initialized
DEBUG - 2018-05-08 06:58:01 --> UTF-8 Support Enabled
INFO - 2018-05-08 06:58:01 --> Utf8 Class Initialized
INFO - 2018-05-08 06:58:01 --> URI Class Initialized
INFO - 2018-05-08 06:58:01 --> Router Class Initialized
INFO - 2018-05-08 06:58:01 --> Output Class Initialized
INFO - 2018-05-08 06:58:01 --> Security Class Initialized
DEBUG - 2018-05-08 06:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 06:58:01 --> Input Class Initialized
INFO - 2018-05-08 06:58:01 --> Language Class Initialized
INFO - 2018-05-08 06:58:01 --> Language Class Initialized
INFO - 2018-05-08 06:58:01 --> Config Class Initialized
INFO - 2018-05-08 06:58:01 --> Loader Class Initialized
INFO - 2018-05-08 12:28:01 --> Helper loaded: url_helper
INFO - 2018-05-08 12:28:01 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:28:01 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:28:01 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:28:01 --> Helper loaded: users_helper
INFO - 2018-05-08 12:28:01 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:28:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:28:01 --> Helper loaded: form_helper
INFO - 2018-05-08 12:28:01 --> Form Validation Class Initialized
INFO - 2018-05-08 12:28:01 --> Controller Class Initialized
INFO - 2018-05-08 12:28:01 --> Model Class Initialized
INFO - 2018-05-08 12:28:01 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:28:01 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:28:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:28:01 --> Model Class Initialized
INFO - 2018-05-08 12:28:01 --> Model Class Initialized
INFO - 2018-05-08 12:28:01 --> Model Class Initialized
INFO - 2018-05-08 12:28:01 --> Model Class Initialized
INFO - 2018-05-08 12:28:01 --> Model Class Initialized
INFO - 2018-05-08 12:28:01 --> Model Class Initialized
INFO - 2018-05-08 12:28:01 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:28:01 --> Final output sent to browser
DEBUG - 2018-05-08 12:28:01 --> Total execution time: 0.1232
INFO - 2018-05-08 07:01:55 --> Config Class Initialized
INFO - 2018-05-08 07:01:55 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:01:55 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:01:55 --> Utf8 Class Initialized
INFO - 2018-05-08 07:01:55 --> URI Class Initialized
INFO - 2018-05-08 07:01:55 --> Router Class Initialized
INFO - 2018-05-08 07:01:55 --> Output Class Initialized
INFO - 2018-05-08 07:01:55 --> Security Class Initialized
DEBUG - 2018-05-08 07:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:01:55 --> Input Class Initialized
INFO - 2018-05-08 07:01:55 --> Language Class Initialized
INFO - 2018-05-08 07:01:55 --> Language Class Initialized
INFO - 2018-05-08 07:01:55 --> Config Class Initialized
INFO - 2018-05-08 07:01:55 --> Loader Class Initialized
INFO - 2018-05-08 12:31:55 --> Helper loaded: url_helper
INFO - 2018-05-08 12:31:55 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:31:55 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:31:55 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:31:55 --> Helper loaded: users_helper
INFO - 2018-05-08 12:31:55 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:31:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:31:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:31:55 --> Helper loaded: form_helper
INFO - 2018-05-08 12:31:55 --> Form Validation Class Initialized
INFO - 2018-05-08 12:31:55 --> Controller Class Initialized
INFO - 2018-05-08 07:01:55 --> Config Class Initialized
INFO - 2018-05-08 07:01:55 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:01:55 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:01:55 --> Utf8 Class Initialized
INFO - 2018-05-08 07:01:55 --> URI Class Initialized
INFO - 2018-05-08 07:01:55 --> Router Class Initialized
INFO - 2018-05-08 12:31:55 --> Model Class Initialized
INFO - 2018-05-08 12:31:55 --> Helper loaded: inflector_helper
INFO - 2018-05-08 07:01:55 --> Output Class Initialized
DEBUG - 2018-05-08 12:31:55 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:31:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:31:55 --> Model Class Initialized
INFO - 2018-05-08 12:31:55 --> Model Class Initialized
INFO - 2018-05-08 12:31:55 --> Model Class Initialized
INFO - 2018-05-08 12:31:55 --> Model Class Initialized
INFO - 2018-05-08 07:01:55 --> Security Class Initialized
INFO - 2018-05-08 12:31:55 --> Model Class Initialized
INFO - 2018-05-08 12:31:55 --> Model Class Initialized
INFO - 2018-05-08 12:31:55 --> Model Class Initialized
INFO - 2018-05-08 12:31:55 --> Model Class Initialized
INFO - 2018-05-08 12:31:55 --> Model Class Initialized
INFO - 2018-05-08 12:31:55 --> Model Class Initialized
DEBUG - 2018-05-08 07:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:01:55 --> Input Class Initialized
INFO - 2018-05-08 07:01:55 --> Language Class Initialized
INFO - 2018-05-08 12:31:55 --> Model Class Initialized
INFO - 2018-05-08 12:31:55 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:31:55 --> Model Class Initialized
INFO - 2018-05-08 12:31:55 --> Final output sent to browser
DEBUG - 2018-05-08 12:31:55 --> Total execution time: 0.1422
INFO - 2018-05-08 07:01:55 --> Language Class Initialized
INFO - 2018-05-08 07:01:55 --> Config Class Initialized
INFO - 2018-05-08 07:01:55 --> Loader Class Initialized
INFO - 2018-05-08 12:31:55 --> Helper loaded: url_helper
INFO - 2018-05-08 12:31:55 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:31:55 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:31:55 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:31:55 --> Helper loaded: users_helper
INFO - 2018-05-08 12:31:55 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:31:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:31:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:31:55 --> Helper loaded: form_helper
INFO - 2018-05-08 12:31:55 --> Form Validation Class Initialized
INFO - 2018-05-08 12:31:55 --> Controller Class Initialized
INFO - 2018-05-08 12:31:55 --> Model Class Initialized
INFO - 2018-05-08 12:31:55 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:31:55 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:31:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:31:55 --> Model Class Initialized
INFO - 2018-05-08 12:31:55 --> Model Class Initialized
INFO - 2018-05-08 12:31:55 --> Model Class Initialized
INFO - 2018-05-08 12:31:55 --> Model Class Initialized
INFO - 2018-05-08 12:31:55 --> Model Class Initialized
INFO - 2018-05-08 12:31:55 --> Model Class Initialized
INFO - 2018-05-08 12:31:55 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:31:55 --> Model Class Initialized
INFO - 2018-05-08 12:31:55 --> Final output sent to browser
DEBUG - 2018-05-08 12:31:55 --> Total execution time: 0.2077
INFO - 2018-05-08 07:01:58 --> Config Class Initialized
INFO - 2018-05-08 07:01:58 --> Hooks Class Initialized
INFO - 2018-05-08 07:01:58 --> Config Class Initialized
INFO - 2018-05-08 07:01:58 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:01:58 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:01:58 --> Utf8 Class Initialized
INFO - 2018-05-08 07:01:58 --> URI Class Initialized
DEBUG - 2018-05-08 07:01:58 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:01:58 --> Utf8 Class Initialized
INFO - 2018-05-08 07:01:58 --> URI Class Initialized
INFO - 2018-05-08 07:01:58 --> Router Class Initialized
INFO - 2018-05-08 07:01:58 --> Output Class Initialized
INFO - 2018-05-08 07:01:58 --> Router Class Initialized
INFO - 2018-05-08 07:01:58 --> Security Class Initialized
INFO - 2018-05-08 07:01:58 --> Output Class Initialized
DEBUG - 2018-05-08 07:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:01:58 --> Input Class Initialized
INFO - 2018-05-08 07:01:58 --> Language Class Initialized
INFO - 2018-05-08 07:01:58 --> Security Class Initialized
DEBUG - 2018-05-08 07:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:01:58 --> Input Class Initialized
INFO - 2018-05-08 07:01:58 --> Language Class Initialized
INFO - 2018-05-08 07:01:58 --> Language Class Initialized
INFO - 2018-05-08 07:01:58 --> Config Class Initialized
INFO - 2018-05-08 07:01:58 --> Loader Class Initialized
INFO - 2018-05-08 12:31:58 --> Helper loaded: url_helper
INFO - 2018-05-08 12:31:58 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:31:58 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:31:58 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:31:58 --> Helper loaded: users_helper
INFO - 2018-05-08 07:01:58 --> Language Class Initialized
INFO - 2018-05-08 07:01:58 --> Config Class Initialized
INFO - 2018-05-08 07:01:58 --> Loader Class Initialized
INFO - 2018-05-08 12:31:58 --> Helper loaded: url_helper
INFO - 2018-05-08 12:31:58 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:31:58 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:31:58 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:31:58 --> Helper loaded: users_helper
INFO - 2018-05-08 12:31:58 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:31:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:31:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:31:58 --> Helper loaded: form_helper
INFO - 2018-05-08 12:31:58 --> Form Validation Class Initialized
INFO - 2018-05-08 12:31:58 --> Controller Class Initialized
INFO - 2018-05-08 12:31:58 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:31:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:31:58 --> Model Class Initialized
INFO - 2018-05-08 12:31:58 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:31:58 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:31:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:31:58 --> Model Class Initialized
INFO - 2018-05-08 12:31:58 --> Model Class Initialized
INFO - 2018-05-08 12:31:58 --> Model Class Initialized
INFO - 2018-05-08 12:31:58 --> Model Class Initialized
INFO - 2018-05-08 12:31:58 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:31:58 --> Final output sent to browser
DEBUG - 2018-05-08 12:31:58 --> Total execution time: 0.1116
INFO - 2018-05-08 12:31:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:31:58 --> Helper loaded: form_helper
INFO - 2018-05-08 12:31:58 --> Form Validation Class Initialized
INFO - 2018-05-08 12:31:58 --> Controller Class Initialized
INFO - 2018-05-08 12:31:58 --> Model Class Initialized
INFO - 2018-05-08 12:31:58 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:31:58 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:31:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:31:58 --> Model Class Initialized
INFO - 2018-05-08 12:31:58 --> Model Class Initialized
INFO - 2018-05-08 12:31:58 --> Model Class Initialized
INFO - 2018-05-08 12:31:58 --> Model Class Initialized
INFO - 2018-05-08 12:31:58 --> Model Class Initialized
INFO - 2018-05-08 12:31:58 --> Model Class Initialized
INFO - 2018-05-08 12:31:58 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:31:58 --> Final output sent to browser
DEBUG - 2018-05-08 12:31:58 --> Total execution time: 0.2060
INFO - 2018-05-08 07:01:59 --> Config Class Initialized
INFO - 2018-05-08 07:01:59 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:01:59 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:01:59 --> Utf8 Class Initialized
INFO - 2018-05-08 07:01:59 --> URI Class Initialized
INFO - 2018-05-08 07:01:59 --> Router Class Initialized
INFO - 2018-05-08 07:01:59 --> Output Class Initialized
INFO - 2018-05-08 07:01:59 --> Security Class Initialized
DEBUG - 2018-05-08 07:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:02:00 --> Input Class Initialized
INFO - 2018-05-08 07:02:00 --> Language Class Initialized
INFO - 2018-05-08 07:02:00 --> Language Class Initialized
INFO - 2018-05-08 07:02:00 --> Config Class Initialized
INFO - 2018-05-08 07:02:00 --> Loader Class Initialized
INFO - 2018-05-08 12:32:00 --> Helper loaded: url_helper
INFO - 2018-05-08 12:32:00 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:32:00 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:32:00 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:32:00 --> Helper loaded: users_helper
INFO - 2018-05-08 12:32:00 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:32:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:32:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:32:00 --> Helper loaded: form_helper
INFO - 2018-05-08 12:32:00 --> Form Validation Class Initialized
INFO - 2018-05-08 12:32:00 --> Controller Class Initialized
INFO - 2018-05-08 12:32:00 --> Model Class Initialized
INFO - 2018-05-08 12:32:00 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:32:00 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:32:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:32:00 --> Model Class Initialized
INFO - 2018-05-08 12:32:00 --> Model Class Initialized
INFO - 2018-05-08 12:32:00 --> Model Class Initialized
INFO - 2018-05-08 12:32:00 --> Model Class Initialized
INFO - 2018-05-08 12:32:00 --> Model Class Initialized
INFO - 2018-05-08 12:32:00 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:32:00 --> Model Class Initialized
INFO - 2018-05-08 12:32:00 --> Final output sent to browser
DEBUG - 2018-05-08 12:32:00 --> Total execution time: 0.1601
INFO - 2018-05-08 07:02:00 --> Config Class Initialized
INFO - 2018-05-08 07:02:00 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:02:00 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:02:00 --> Utf8 Class Initialized
INFO - 2018-05-08 07:02:00 --> URI Class Initialized
INFO - 2018-05-08 07:02:00 --> Router Class Initialized
INFO - 2018-05-08 07:02:00 --> Output Class Initialized
INFO - 2018-05-08 07:02:00 --> Security Class Initialized
DEBUG - 2018-05-08 07:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:02:00 --> Input Class Initialized
INFO - 2018-05-08 07:02:00 --> Language Class Initialized
INFO - 2018-05-08 07:02:00 --> Language Class Initialized
INFO - 2018-05-08 07:02:00 --> Config Class Initialized
INFO - 2018-05-08 07:02:00 --> Loader Class Initialized
INFO - 2018-05-08 12:32:00 --> Helper loaded: url_helper
INFO - 2018-05-08 12:32:00 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:32:00 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:32:00 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:32:00 --> Helper loaded: users_helper
INFO - 2018-05-08 12:32:00 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:32:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:32:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:32:00 --> Helper loaded: form_helper
INFO - 2018-05-08 12:32:00 --> Form Validation Class Initialized
INFO - 2018-05-08 12:32:00 --> Controller Class Initialized
INFO - 2018-05-08 12:32:00 --> Model Class Initialized
INFO - 2018-05-08 12:32:00 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:32:00 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:32:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:32:00 --> Model Class Initialized
INFO - 2018-05-08 12:32:00 --> Model Class Initialized
INFO - 2018-05-08 12:32:00 --> Model Class Initialized
INFO - 2018-05-08 12:32:00 --> Model Class Initialized
INFO - 2018-05-08 12:32:00 --> Model Class Initialized
INFO - 2018-05-08 12:32:00 --> Model Class Initialized
INFO - 2018-05-08 12:32:00 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:32:00 --> Final output sent to browser
DEBUG - 2018-05-08 12:32:00 --> Total execution time: 0.1622
INFO - 2018-05-08 07:03:08 --> Config Class Initialized
INFO - 2018-05-08 07:03:08 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:03:08 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:03:08 --> Utf8 Class Initialized
INFO - 2018-05-08 07:03:08 --> URI Class Initialized
INFO - 2018-05-08 07:03:08 --> Router Class Initialized
INFO - 2018-05-08 07:03:08 --> Output Class Initialized
INFO - 2018-05-08 07:03:08 --> Security Class Initialized
DEBUG - 2018-05-08 07:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:03:08 --> Input Class Initialized
INFO - 2018-05-08 07:03:08 --> Language Class Initialized
INFO - 2018-05-08 07:03:08 --> Language Class Initialized
INFO - 2018-05-08 07:03:08 --> Config Class Initialized
INFO - 2018-05-08 07:03:08 --> Loader Class Initialized
INFO - 2018-05-08 12:33:08 --> Helper loaded: url_helper
INFO - 2018-05-08 12:33:08 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:33:08 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:33:08 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:33:08 --> Helper loaded: users_helper
INFO - 2018-05-08 12:33:08 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:33:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:33:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:33:08 --> Helper loaded: form_helper
INFO - 2018-05-08 12:33:08 --> Form Validation Class Initialized
INFO - 2018-05-08 12:33:08 --> Controller Class Initialized
INFO - 2018-05-08 12:33:08 --> Model Class Initialized
INFO - 2018-05-08 12:33:08 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:33:08 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:33:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:33:08 --> Model Class Initialized
INFO - 2018-05-08 12:33:08 --> Model Class Initialized
INFO - 2018-05-08 12:33:08 --> Model Class Initialized
INFO - 2018-05-08 12:33:08 --> Model Class Initialized
INFO - 2018-05-08 12:33:08 --> Model Class Initialized
INFO - 2018-05-08 12:33:08 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:33:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-05-08 12:33:08 --> Final output sent to browser
DEBUG - 2018-05-08 12:33:08 --> Total execution time: 0.1688
INFO - 2018-05-08 07:03:54 --> Config Class Initialized
INFO - 2018-05-08 07:03:54 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:03:54 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:03:54 --> Utf8 Class Initialized
INFO - 2018-05-08 07:03:54 --> URI Class Initialized
INFO - 2018-05-08 07:03:54 --> Router Class Initialized
INFO - 2018-05-08 07:03:54 --> Output Class Initialized
INFO - 2018-05-08 07:03:54 --> Security Class Initialized
DEBUG - 2018-05-08 07:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:03:54 --> Input Class Initialized
INFO - 2018-05-08 07:03:54 --> Language Class Initialized
INFO - 2018-05-08 07:03:54 --> Language Class Initialized
INFO - 2018-05-08 07:03:54 --> Config Class Initialized
INFO - 2018-05-08 07:03:54 --> Loader Class Initialized
INFO - 2018-05-08 12:33:54 --> Helper loaded: url_helper
INFO - 2018-05-08 12:33:54 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:33:54 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:33:54 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:33:54 --> Helper loaded: users_helper
INFO - 2018-05-08 12:33:54 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:33:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:33:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:33:54 --> Helper loaded: form_helper
INFO - 2018-05-08 12:33:54 --> Form Validation Class Initialized
INFO - 2018-05-08 12:33:54 --> Controller Class Initialized
INFO - 2018-05-08 12:33:54 --> Model Class Initialized
INFO - 2018-05-08 12:33:54 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:33:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:33:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:33:54 --> Model Class Initialized
INFO - 2018-05-08 12:33:54 --> Model Class Initialized
INFO - 2018-05-08 12:33:54 --> Model Class Initialized
INFO - 2018-05-08 12:33:54 --> Model Class Initialized
INFO - 2018-05-08 12:33:54 --> Model Class Initialized
INFO - 2018-05-08 12:33:54 --> Model Class Initialized
INFO - 2018-05-08 12:33:54 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:33:54 --> Final output sent to browser
DEBUG - 2018-05-08 12:33:54 --> Total execution time: 0.1179
INFO - 2018-05-08 07:03:56 --> Config Class Initialized
INFO - 2018-05-08 07:03:56 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:03:56 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:03:56 --> Utf8 Class Initialized
INFO - 2018-05-08 07:03:56 --> URI Class Initialized
INFO - 2018-05-08 07:03:56 --> Router Class Initialized
INFO - 2018-05-08 07:03:56 --> Output Class Initialized
INFO - 2018-05-08 07:03:56 --> Security Class Initialized
DEBUG - 2018-05-08 07:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:03:56 --> Input Class Initialized
INFO - 2018-05-08 07:03:56 --> Language Class Initialized
INFO - 2018-05-08 07:03:56 --> Language Class Initialized
INFO - 2018-05-08 07:03:56 --> Config Class Initialized
INFO - 2018-05-08 07:03:56 --> Loader Class Initialized
INFO - 2018-05-08 12:33:56 --> Helper loaded: url_helper
INFO - 2018-05-08 12:33:56 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:33:56 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:33:56 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:33:56 --> Helper loaded: users_helper
INFO - 2018-05-08 12:33:56 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:33:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:33:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:33:56 --> Helper loaded: form_helper
INFO - 2018-05-08 12:33:56 --> Form Validation Class Initialized
INFO - 2018-05-08 12:33:56 --> Controller Class Initialized
INFO - 2018-05-08 12:33:56 --> Model Class Initialized
INFO - 2018-05-08 12:33:56 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:33:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:33:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:33:56 --> Model Class Initialized
INFO - 2018-05-08 12:33:56 --> Model Class Initialized
INFO - 2018-05-08 12:33:56 --> Model Class Initialized
INFO - 2018-05-08 12:33:56 --> Model Class Initialized
INFO - 2018-05-08 12:33:56 --> Model Class Initialized
INFO - 2018-05-08 12:33:56 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:33:56 --> Model Class Initialized
INFO - 2018-05-08 12:33:56 --> Final output sent to browser
DEBUG - 2018-05-08 12:33:56 --> Total execution time: 0.1319
INFO - 2018-05-08 07:03:57 --> Config Class Initialized
INFO - 2018-05-08 07:03:57 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:03:57 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:03:57 --> Utf8 Class Initialized
INFO - 2018-05-08 07:03:57 --> URI Class Initialized
INFO - 2018-05-08 07:03:57 --> Router Class Initialized
INFO - 2018-05-08 07:03:57 --> Output Class Initialized
INFO - 2018-05-08 07:03:57 --> Security Class Initialized
DEBUG - 2018-05-08 07:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:03:57 --> Input Class Initialized
INFO - 2018-05-08 07:03:57 --> Language Class Initialized
INFO - 2018-05-08 07:03:57 --> Language Class Initialized
INFO - 2018-05-08 07:03:57 --> Config Class Initialized
INFO - 2018-05-08 07:03:57 --> Loader Class Initialized
INFO - 2018-05-08 12:33:57 --> Helper loaded: url_helper
INFO - 2018-05-08 12:33:57 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:33:57 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:33:57 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:33:57 --> Helper loaded: users_helper
INFO - 2018-05-08 12:33:57 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:33:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:33:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:33:57 --> Helper loaded: form_helper
INFO - 2018-05-08 12:33:57 --> Form Validation Class Initialized
INFO - 2018-05-08 12:33:57 --> Controller Class Initialized
INFO - 2018-05-08 12:33:57 --> Model Class Initialized
INFO - 2018-05-08 12:33:57 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:33:57 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:33:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:33:57 --> Model Class Initialized
INFO - 2018-05-08 12:33:57 --> Model Class Initialized
INFO - 2018-05-08 12:33:57 --> Model Class Initialized
INFO - 2018-05-08 12:33:57 --> Model Class Initialized
INFO - 2018-05-08 12:33:57 --> Model Class Initialized
INFO - 2018-05-08 12:33:57 --> Model Class Initialized
INFO - 2018-05-08 12:33:57 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:33:57 --> Final output sent to browser
DEBUG - 2018-05-08 12:33:57 --> Total execution time: 0.1278
INFO - 2018-05-08 07:04:43 --> Config Class Initialized
INFO - 2018-05-08 07:04:43 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:04:43 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:04:43 --> Utf8 Class Initialized
INFO - 2018-05-08 07:04:43 --> URI Class Initialized
INFO - 2018-05-08 07:04:43 --> Router Class Initialized
INFO - 2018-05-08 07:04:43 --> Output Class Initialized
INFO - 2018-05-08 07:04:43 --> Security Class Initialized
DEBUG - 2018-05-08 07:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:04:43 --> Input Class Initialized
INFO - 2018-05-08 07:04:43 --> Language Class Initialized
INFO - 2018-05-08 07:04:43 --> Language Class Initialized
INFO - 2018-05-08 07:04:43 --> Config Class Initialized
INFO - 2018-05-08 07:04:43 --> Loader Class Initialized
INFO - 2018-05-08 12:34:43 --> Helper loaded: url_helper
INFO - 2018-05-08 12:34:43 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:34:43 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:34:43 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:34:43 --> Helper loaded: users_helper
INFO - 2018-05-08 12:34:43 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:34:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:34:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:34:43 --> Helper loaded: form_helper
INFO - 2018-05-08 12:34:43 --> Form Validation Class Initialized
INFO - 2018-05-08 12:34:43 --> Controller Class Initialized
INFO - 2018-05-08 12:34:43 --> Model Class Initialized
INFO - 2018-05-08 12:34:43 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:34:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:34:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:34:43 --> Model Class Initialized
INFO - 2018-05-08 12:34:43 --> Model Class Initialized
INFO - 2018-05-08 12:34:43 --> Model Class Initialized
INFO - 2018-05-08 12:34:43 --> Model Class Initialized
INFO - 2018-05-08 12:34:43 --> Model Class Initialized
INFO - 2018-05-08 12:34:43 --> Model Class Initialized
INFO - 2018-05-08 12:34:43 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:34:43 --> Final output sent to browser
DEBUG - 2018-05-08 12:34:43 --> Total execution time: 0.1182
INFO - 2018-05-08 07:04:47 --> Config Class Initialized
INFO - 2018-05-08 07:04:47 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:04:47 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:04:47 --> Utf8 Class Initialized
INFO - 2018-05-08 07:04:47 --> URI Class Initialized
INFO - 2018-05-08 07:04:47 --> Router Class Initialized
INFO - 2018-05-08 07:04:47 --> Output Class Initialized
INFO - 2018-05-08 07:04:47 --> Security Class Initialized
DEBUG - 2018-05-08 07:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:04:47 --> Input Class Initialized
INFO - 2018-05-08 07:04:47 --> Language Class Initialized
INFO - 2018-05-08 07:04:47 --> Language Class Initialized
INFO - 2018-05-08 07:04:47 --> Config Class Initialized
INFO - 2018-05-08 07:04:47 --> Loader Class Initialized
INFO - 2018-05-08 12:34:47 --> Helper loaded: url_helper
INFO - 2018-05-08 12:34:47 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:34:47 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:34:47 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:34:47 --> Helper loaded: users_helper
INFO - 2018-05-08 12:34:47 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:34:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:34:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:34:47 --> Helper loaded: form_helper
INFO - 2018-05-08 12:34:47 --> Form Validation Class Initialized
INFO - 2018-05-08 12:34:47 --> Controller Class Initialized
INFO - 2018-05-08 12:34:47 --> Model Class Initialized
INFO - 2018-05-08 12:34:47 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:34:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:34:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:34:47 --> Model Class Initialized
INFO - 2018-05-08 12:34:47 --> Model Class Initialized
INFO - 2018-05-08 12:34:47 --> Model Class Initialized
INFO - 2018-05-08 12:34:47 --> Model Class Initialized
INFO - 2018-05-08 12:34:47 --> Model Class Initialized
INFO - 2018-05-08 12:34:47 --> Model Class Initialized
INFO - 2018-05-08 12:34:47 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:34:47 --> Final output sent to browser
DEBUG - 2018-05-08 12:34:47 --> Total execution time: 0.1055
INFO - 2018-05-08 07:04:51 --> Config Class Initialized
INFO - 2018-05-08 07:04:51 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:04:51 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:04:51 --> Utf8 Class Initialized
INFO - 2018-05-08 07:04:51 --> URI Class Initialized
INFO - 2018-05-08 07:04:51 --> Router Class Initialized
INFO - 2018-05-08 07:04:51 --> Output Class Initialized
INFO - 2018-05-08 07:04:51 --> Security Class Initialized
DEBUG - 2018-05-08 07:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:04:51 --> Input Class Initialized
INFO - 2018-05-08 07:04:51 --> Language Class Initialized
INFO - 2018-05-08 07:04:51 --> Language Class Initialized
INFO - 2018-05-08 07:04:51 --> Config Class Initialized
INFO - 2018-05-08 07:04:51 --> Loader Class Initialized
INFO - 2018-05-08 12:34:51 --> Helper loaded: url_helper
INFO - 2018-05-08 12:34:51 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:34:51 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:34:51 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:34:51 --> Helper loaded: users_helper
INFO - 2018-05-08 12:34:51 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:34:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:34:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:34:51 --> Helper loaded: form_helper
INFO - 2018-05-08 12:34:51 --> Form Validation Class Initialized
INFO - 2018-05-08 12:34:51 --> Controller Class Initialized
INFO - 2018-05-08 12:34:51 --> Model Class Initialized
INFO - 2018-05-08 12:34:51 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:34:51 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:34:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:34:51 --> Model Class Initialized
INFO - 2018-05-08 12:34:51 --> Model Class Initialized
INFO - 2018-05-08 12:34:51 --> Model Class Initialized
INFO - 2018-05-08 12:34:51 --> Model Class Initialized
INFO - 2018-05-08 12:34:51 --> Model Class Initialized
INFO - 2018-05-08 12:34:51 --> Model Class Initialized
INFO - 2018-05-08 12:34:51 --> Model Class Initialized
INFO - 2018-05-08 12:34:51 --> Model Class Initialized
INFO - 2018-05-08 12:34:51 --> Model Class Initialized
INFO - 2018-05-08 12:34:51 --> Model Class Initialized
INFO - 2018-05-08 12:34:51 --> Model Class Initialized
INFO - 2018-05-08 12:34:51 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:34:51 --> Model Class Initialized
INFO - 2018-05-08 12:34:51 --> Final output sent to browser
DEBUG - 2018-05-08 12:34:51 --> Total execution time: 0.1331
INFO - 2018-05-08 07:04:52 --> Config Class Initialized
INFO - 2018-05-08 07:04:52 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:04:52 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:04:52 --> Utf8 Class Initialized
INFO - 2018-05-08 07:04:52 --> URI Class Initialized
INFO - 2018-05-08 07:04:52 --> Router Class Initialized
INFO - 2018-05-08 07:04:52 --> Output Class Initialized
INFO - 2018-05-08 07:04:52 --> Security Class Initialized
DEBUG - 2018-05-08 07:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:04:52 --> Input Class Initialized
INFO - 2018-05-08 07:04:52 --> Language Class Initialized
INFO - 2018-05-08 07:04:52 --> Language Class Initialized
INFO - 2018-05-08 07:04:52 --> Config Class Initialized
INFO - 2018-05-08 07:04:52 --> Loader Class Initialized
INFO - 2018-05-08 12:34:52 --> Helper loaded: url_helper
INFO - 2018-05-08 12:34:52 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:34:52 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:34:52 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:34:52 --> Helper loaded: users_helper
INFO - 2018-05-08 12:34:52 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:34:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:34:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:34:52 --> Helper loaded: form_helper
INFO - 2018-05-08 12:34:52 --> Form Validation Class Initialized
INFO - 2018-05-08 12:34:52 --> Controller Class Initialized
INFO - 2018-05-08 12:34:52 --> Model Class Initialized
INFO - 2018-05-08 12:34:52 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:34:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:34:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:34:52 --> Model Class Initialized
INFO - 2018-05-08 12:34:52 --> Model Class Initialized
INFO - 2018-05-08 12:34:52 --> Model Class Initialized
INFO - 2018-05-08 12:34:52 --> Model Class Initialized
INFO - 2018-05-08 12:34:52 --> Model Class Initialized
INFO - 2018-05-08 12:34:52 --> Model Class Initialized
INFO - 2018-05-08 07:04:53 --> Config Class Initialized
INFO - 2018-05-08 07:04:53 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:04:53 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:04:53 --> Utf8 Class Initialized
INFO - 2018-05-08 07:04:53 --> URI Class Initialized
INFO - 2018-05-08 07:04:53 --> Config Class Initialized
INFO - 2018-05-08 07:04:53 --> Hooks Class Initialized
INFO - 2018-05-08 07:04:53 --> Router Class Initialized
DEBUG - 2018-05-08 07:04:53 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:04:53 --> Utf8 Class Initialized
INFO - 2018-05-08 07:04:53 --> Output Class Initialized
INFO - 2018-05-08 07:04:53 --> URI Class Initialized
INFO - 2018-05-08 07:04:53 --> Security Class Initialized
INFO - 2018-05-08 07:04:53 --> Router Class Initialized
DEBUG - 2018-05-08 07:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:04:53 --> Input Class Initialized
INFO - 2018-05-08 07:04:53 --> Language Class Initialized
INFO - 2018-05-08 07:04:53 --> Output Class Initialized
INFO - 2018-05-08 07:04:53 --> Security Class Initialized
INFO - 2018-05-08 07:04:53 --> Config Class Initialized
INFO - 2018-05-08 07:04:53 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:04:53 --> Input Class Initialized
DEBUG - 2018-05-08 07:04:53 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:04:53 --> Utf8 Class Initialized
INFO - 2018-05-08 07:04:53 --> Language Class Initialized
INFO - 2018-05-08 07:04:53 --> URI Class Initialized
INFO - 2018-05-08 07:04:53 --> Router Class Initialized
INFO - 2018-05-08 07:04:53 --> Output Class Initialized
INFO - 2018-05-08 07:04:53 --> Language Class Initialized
INFO - 2018-05-08 07:04:53 --> Security Class Initialized
INFO - 2018-05-08 07:04:53 --> Config Class Initialized
INFO - 2018-05-08 07:04:53 --> Loader Class Initialized
DEBUG - 2018-05-08 07:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:04:53 --> Input Class Initialized
INFO - 2018-05-08 07:04:53 --> Language Class Initialized
INFO - 2018-05-08 12:34:53 --> Helper loaded: url_helper
INFO - 2018-05-08 12:34:53 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:34:53 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:34:53 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:34:53 --> Helper loaded: users_helper
INFO - 2018-05-08 07:04:53 --> Language Class Initialized
INFO - 2018-05-08 07:04:53 --> Config Class Initialized
INFO - 2018-05-08 07:04:53 --> Loader Class Initialized
INFO - 2018-05-08 12:34:53 --> Helper loaded: url_helper
INFO - 2018-05-08 12:34:53 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:34:53 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:34:53 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:34:53 --> Helper loaded: users_helper
INFO - 2018-05-08 07:04:53 --> Language Class Initialized
INFO - 2018-05-08 07:04:53 --> Config Class Initialized
INFO - 2018-05-08 07:04:53 --> Loader Class Initialized
INFO - 2018-05-08 12:34:53 --> Helper loaded: url_helper
INFO - 2018-05-08 12:34:53 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:34:53 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:34:53 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:34:53 --> Helper loaded: users_helper
INFO - 2018-05-08 12:34:53 --> Database Driver Class Initialized
INFO - 2018-05-08 12:34:53 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:34:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:34:53 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:34:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-05-08 12:34:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-05-08 12:34:53 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/FilterOption.php 79
INFO - 2018-05-08 12:34:53 --> Final output sent to browser
DEBUG - 2018-05-08 12:34:53 --> Total execution time: 0.3557
INFO - 2018-05-08 12:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:34:53 --> Helper loaded: form_helper
INFO - 2018-05-08 12:34:53 --> Form Validation Class Initialized
INFO - 2018-05-08 12:34:53 --> Controller Class Initialized
INFO - 2018-05-08 12:34:53 --> Model Class Initialized
INFO - 2018-05-08 12:34:53 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:34:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:34:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:34:53 --> Model Class Initialized
INFO - 2018-05-08 12:34:53 --> Model Class Initialized
INFO - 2018-05-08 12:34:53 --> Model Class Initialized
INFO - 2018-05-08 12:34:53 --> Model Class Initialized
INFO - 2018-05-08 12:34:53 --> Model Class Initialized
INFO - 2018-05-08 12:34:53 --> Model Class Initialized
ERROR - 2018-05-08 12:34:53 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/FilterOption.php 147
ERROR - 2018-05-08 12:34:53 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/FilterOption.php 189
ERROR - 2018-05-08 12:34:53 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/FilterOption.php 227
INFO - 2018-05-08 12:34:53 --> Final output sent to browser
DEBUG - 2018-05-08 12:34:53 --> Total execution time: 0.1466
INFO - 2018-05-08 12:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:34:53 --> Helper loaded: form_helper
INFO - 2018-05-08 12:34:53 --> Form Validation Class Initialized
INFO - 2018-05-08 12:34:53 --> Controller Class Initialized
INFO - 2018-05-08 12:34:53 --> Model Class Initialized
INFO - 2018-05-08 12:34:53 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:34:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:34:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:34:53 --> Model Class Initialized
INFO - 2018-05-08 12:34:53 --> Model Class Initialized
INFO - 2018-05-08 12:34:53 --> Model Class Initialized
INFO - 2018-05-08 12:34:53 --> Model Class Initialized
INFO - 2018-05-08 12:34:53 --> Model Class Initialized
INFO - 2018-05-08 12:34:53 --> Model Class Initialized
ERROR - 2018-05-08 12:34:53 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/FilterOption.php 289
INFO - 2018-05-08 12:34:53 --> Final output sent to browser
DEBUG - 2018-05-08 12:34:53 --> Total execution time: 0.1970
INFO - 2018-05-08 12:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:34:53 --> Helper loaded: form_helper
INFO - 2018-05-08 12:34:53 --> Form Validation Class Initialized
INFO - 2018-05-08 12:34:53 --> Controller Class Initialized
INFO - 2018-05-08 12:34:53 --> Model Class Initialized
INFO - 2018-05-08 12:34:53 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:34:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:34:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:34:53 --> Model Class Initialized
INFO - 2018-05-08 12:34:53 --> Model Class Initialized
INFO - 2018-05-08 12:34:53 --> Model Class Initialized
INFO - 2018-05-08 12:34:53 --> Model Class Initialized
INFO - 2018-05-08 12:34:53 --> Model Class Initialized
INFO - 2018-05-08 12:34:53 --> Model Class Initialized
ERROR - 2018-05-08 12:34:53 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/FilterOption.php 349
ERROR - 2018-05-08 12:34:53 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/FilterOption.php 389
ERROR - 2018-05-08 12:34:53 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/FilterOption.php 427
INFO - 2018-05-08 12:34:53 --> Final output sent to browser
DEBUG - 2018-05-08 12:34:53 --> Total execution time: 0.2177
INFO - 2018-05-08 07:04:53 --> Config Class Initialized
INFO - 2018-05-08 07:04:53 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:04:53 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:04:53 --> Utf8 Class Initialized
INFO - 2018-05-08 07:04:53 --> URI Class Initialized
INFO - 2018-05-08 07:04:53 --> Router Class Initialized
INFO - 2018-05-08 07:04:53 --> Output Class Initialized
INFO - 2018-05-08 07:04:53 --> Security Class Initialized
DEBUG - 2018-05-08 07:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:04:53 --> Input Class Initialized
INFO - 2018-05-08 07:04:53 --> Language Class Initialized
INFO - 2018-05-08 07:04:53 --> Language Class Initialized
INFO - 2018-05-08 07:04:53 --> Config Class Initialized
INFO - 2018-05-08 07:04:53 --> Loader Class Initialized
INFO - 2018-05-08 12:34:53 --> Helper loaded: url_helper
INFO - 2018-05-08 12:34:53 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:34:53 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:34:53 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:34:53 --> Helper loaded: users_helper
INFO - 2018-05-08 12:34:53 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:34:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:34:53 --> Helper loaded: form_helper
INFO - 2018-05-08 12:34:53 --> Form Validation Class Initialized
INFO - 2018-05-08 12:34:53 --> Controller Class Initialized
INFO - 2018-05-08 12:34:53 --> Model Class Initialized
INFO - 2018-05-08 12:34:53 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:34:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:34:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:34:53 --> Model Class Initialized
INFO - 2018-05-08 12:34:53 --> Model Class Initialized
INFO - 2018-05-08 12:34:53 --> Model Class Initialized
INFO - 2018-05-08 12:34:53 --> Model Class Initialized
INFO - 2018-05-08 12:34:53 --> Model Class Initialized
INFO - 2018-05-08 12:34:53 --> Model Class Initialized
ERROR - 2018-05-08 12:34:53 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/FilterOption.php 625
ERROR - 2018-05-08 12:34:53 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/FilterOption.php 625
INFO - 2018-05-08 12:34:53 --> Final output sent to browser
DEBUG - 2018-05-08 12:34:53 --> Total execution time: 0.1111
INFO - 2018-05-08 07:12:01 --> Config Class Initialized
INFO - 2018-05-08 07:12:01 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:12:01 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:12:01 --> Utf8 Class Initialized
INFO - 2018-05-08 07:12:01 --> Config Class Initialized
INFO - 2018-05-08 07:12:01 --> Hooks Class Initialized
INFO - 2018-05-08 07:12:01 --> URI Class Initialized
DEBUG - 2018-05-08 07:12:01 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:12:01 --> Utf8 Class Initialized
INFO - 2018-05-08 07:12:01 --> URI Class Initialized
INFO - 2018-05-08 07:12:01 --> Router Class Initialized
INFO - 2018-05-08 07:12:01 --> Router Class Initialized
INFO - 2018-05-08 07:12:01 --> Output Class Initialized
INFO - 2018-05-08 07:12:01 --> Security Class Initialized
INFO - 2018-05-08 07:12:01 --> Output Class Initialized
INFO - 2018-05-08 07:12:01 --> Config Class Initialized
INFO - 2018-05-08 07:12:01 --> Hooks Class Initialized
INFO - 2018-05-08 07:12:01 --> Security Class Initialized
DEBUG - 2018-05-08 07:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:12:01 --> Input Class Initialized
INFO - 2018-05-08 07:12:01 --> Language Class Initialized
DEBUG - 2018-05-08 07:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:12:01 --> Input Class Initialized
INFO - 2018-05-08 07:12:01 --> Language Class Initialized
DEBUG - 2018-05-08 07:12:01 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:12:01 --> Utf8 Class Initialized
INFO - 2018-05-08 07:12:01 --> URI Class Initialized
INFO - 2018-05-08 07:12:01 --> Router Class Initialized
INFO - 2018-05-08 07:12:01 --> Output Class Initialized
INFO - 2018-05-08 07:12:01 --> Language Class Initialized
INFO - 2018-05-08 07:12:01 --> Config Class Initialized
INFO - 2018-05-08 07:12:01 --> Loader Class Initialized
INFO - 2018-05-08 07:12:01 --> Security Class Initialized
INFO - 2018-05-08 07:12:01 --> Language Class Initialized
INFO - 2018-05-08 07:12:01 --> Config Class Initialized
INFO - 2018-05-08 07:12:01 --> Loader Class Initialized
INFO - 2018-05-08 12:42:01 --> Helper loaded: url_helper
INFO - 2018-05-08 12:42:01 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:42:01 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:42:01 --> Helper loaded: url_helper
INFO - 2018-05-08 12:42:01 --> Helper loaded: permission_helper
DEBUG - 2018-05-08 07:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:12:01 --> Input Class Initialized
INFO - 2018-05-08 12:42:01 --> Helper loaded: users_helper
INFO - 2018-05-08 12:42:01 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:42:01 --> Helper loaded: settings_helper
INFO - 2018-05-08 07:12:01 --> Language Class Initialized
INFO - 2018-05-08 12:42:01 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:42:01 --> Helper loaded: users_helper
INFO - 2018-05-08 12:42:01 --> Database Driver Class Initialized
INFO - 2018-05-08 12:42:01 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:42:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:42:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-05-08 12:42:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:42:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:42:01 --> Helper loaded: form_helper
INFO - 2018-05-08 12:42:01 --> Form Validation Class Initialized
INFO - 2018-05-08 12:42:01 --> Controller Class Initialized
INFO - 2018-05-08 12:42:01 --> Helper loaded: form_helper
INFO - 2018-05-08 12:42:01 --> Form Validation Class Initialized
INFO - 2018-05-08 12:42:01 --> Controller Class Initialized
INFO - 2018-05-08 07:12:01 --> Language Class Initialized
INFO - 2018-05-08 07:12:01 --> Config Class Initialized
INFO - 2018-05-08 07:12:01 --> Loader Class Initialized
INFO - 2018-05-08 12:42:01 --> Model Class Initialized
INFO - 2018-05-08 12:42:01 --> Helper loaded: inflector_helper
INFO - 2018-05-08 12:42:01 --> Helper loaded: url_helper
INFO - 2018-05-08 12:42:01 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:42:01 --> Model Class Initialized
INFO - 2018-05-08 12:42:01 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:42:01 --> Helper loaded: inflector_helper
INFO - 2018-05-08 12:42:01 --> Helper loaded: permission_helper
DEBUG - 2018-05-08 12:42:01 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:42:01 --> Helper loaded: users_helper
DEBUG - 2018-05-08 12:42:01 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:42:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:42:01 --> Model Class Initialized
INFO - 2018-05-08 12:42:01 --> Model Class Initialized
INFO - 2018-05-08 12:42:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:42:01 --> Model Class Initialized
INFO - 2018-05-08 12:42:01 --> Model Class Initialized
INFO - 2018-05-08 12:42:01 --> Model Class Initialized
INFO - 2018-05-08 12:42:01 --> Model Class Initialized
INFO - 2018-05-08 12:42:01 --> Model Class Initialized
INFO - 2018-05-08 12:42:01 --> Model Class Initialized
INFO - 2018-05-08 12:42:01 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:42:01 --> Model Class Initialized
INFO - 2018-05-08 12:42:01 --> Model Class Initialized
INFO - 2018-05-08 12:42:01 --> Model Class Initialized
INFO - 2018-05-08 12:42:01 --> Model Class Initialized
INFO - 2018-05-08 12:42:01 --> Model Class Initialized
INFO - 2018-05-08 12:42:01 --> Model Class Initialized
INFO - 2018-05-08 12:42:01 --> Model Class Initialized
INFO - 2018-05-08 12:42:01 --> Model Class Initialized
INFO - 2018-05-08 12:42:01 --> Model Class Initialized
INFO - 2018-05-08 12:42:01 --> Final output sent to browser
DEBUG - 2018-05-08 12:42:01 --> Total execution time: 0.1098
INFO - 2018-05-08 12:42:01 --> Model Class Initialized
INFO - 2018-05-08 12:42:01 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:42:01 --> Model Class Initialized
INFO - 2018-05-08 12:42:01 --> Database Driver Class Initialized
INFO - 2018-05-08 12:42:01 --> Final output sent to browser
DEBUG - 2018-05-08 12:42:01 --> Total execution time: 0.1234
DEBUG - 2018-05-08 12:42:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:42:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:42:01 --> Helper loaded: form_helper
INFO - 2018-05-08 12:42:01 --> Form Validation Class Initialized
INFO - 2018-05-08 12:42:01 --> Controller Class Initialized
INFO - 2018-05-08 12:42:01 --> Model Class Initialized
INFO - 2018-05-08 12:42:01 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:42:01 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:42:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:42:01 --> Model Class Initialized
INFO - 2018-05-08 12:42:01 --> Model Class Initialized
INFO - 2018-05-08 12:42:01 --> Model Class Initialized
INFO - 2018-05-08 12:42:01 --> Model Class Initialized
INFO - 2018-05-08 12:42:01 --> Model Class Initialized
INFO - 2018-05-08 12:42:01 --> Model Class Initialized
INFO - 2018-05-08 12:42:01 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:42:01 --> Final output sent to browser
DEBUG - 2018-05-08 12:42:01 --> Total execution time: 0.2041
INFO - 2018-05-08 07:12:05 --> Config Class Initialized
INFO - 2018-05-08 07:12:05 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:12:05 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:12:05 --> Utf8 Class Initialized
INFO - 2018-05-08 07:12:05 --> URI Class Initialized
INFO - 2018-05-08 07:12:05 --> Router Class Initialized
INFO - 2018-05-08 07:12:05 --> Output Class Initialized
INFO - 2018-05-08 07:12:05 --> Security Class Initialized
DEBUG - 2018-05-08 07:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:12:05 --> Input Class Initialized
INFO - 2018-05-08 07:12:05 --> Language Class Initialized
INFO - 2018-05-08 07:12:05 --> Language Class Initialized
INFO - 2018-05-08 07:12:05 --> Config Class Initialized
INFO - 2018-05-08 07:12:05 --> Loader Class Initialized
INFO - 2018-05-08 12:42:05 --> Helper loaded: url_helper
INFO - 2018-05-08 12:42:05 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:42:05 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:42:05 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:42:05 --> Helper loaded: users_helper
INFO - 2018-05-08 12:42:05 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:42:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:42:05 --> Helper loaded: form_helper
INFO - 2018-05-08 12:42:05 --> Form Validation Class Initialized
INFO - 2018-05-08 12:42:05 --> Controller Class Initialized
INFO - 2018-05-08 12:42:05 --> Model Class Initialized
INFO - 2018-05-08 12:42:05 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:42:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:42:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:42:05 --> Model Class Initialized
INFO - 2018-05-08 12:42:05 --> Model Class Initialized
INFO - 2018-05-08 12:42:05 --> Model Class Initialized
INFO - 2018-05-08 12:42:05 --> Model Class Initialized
INFO - 2018-05-08 12:42:05 --> Model Class Initialized
INFO - 2018-05-08 12:42:05 --> Model Class Initialized
INFO - 2018-05-08 12:42:05 --> Model Class Initialized
INFO - 2018-05-08 12:42:05 --> Model Class Initialized
INFO - 2018-05-08 12:42:05 --> Model Class Initialized
INFO - 2018-05-08 12:42:05 --> Model Class Initialized
INFO - 2018-05-08 12:42:05 --> Model Class Initialized
INFO - 2018-05-08 12:42:05 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:42:05 --> Model Class Initialized
INFO - 2018-05-08 12:42:05 --> Final output sent to browser
DEBUG - 2018-05-08 12:42:05 --> Total execution time: 0.1307
INFO - 2018-05-08 07:12:07 --> Config Class Initialized
INFO - 2018-05-08 07:12:07 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:12:07 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:12:07 --> Utf8 Class Initialized
INFO - 2018-05-08 07:12:07 --> URI Class Initialized
INFO - 2018-05-08 07:12:07 --> Router Class Initialized
INFO - 2018-05-08 07:12:07 --> Output Class Initialized
INFO - 2018-05-08 07:12:07 --> Security Class Initialized
DEBUG - 2018-05-08 07:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:12:07 --> Input Class Initialized
INFO - 2018-05-08 07:12:07 --> Language Class Initialized
INFO - 2018-05-08 07:12:07 --> Language Class Initialized
INFO - 2018-05-08 07:12:07 --> Config Class Initialized
INFO - 2018-05-08 07:12:07 --> Loader Class Initialized
INFO - 2018-05-08 12:42:07 --> Helper loaded: url_helper
INFO - 2018-05-08 12:42:07 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:42:07 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:42:07 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:42:07 --> Helper loaded: users_helper
INFO - 2018-05-08 12:42:07 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:42:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:42:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:42:07 --> Helper loaded: form_helper
INFO - 2018-05-08 12:42:07 --> Form Validation Class Initialized
INFO - 2018-05-08 12:42:07 --> Controller Class Initialized
INFO - 2018-05-08 12:42:07 --> Model Class Initialized
INFO - 2018-05-08 12:42:07 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:42:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:42:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:42:07 --> Model Class Initialized
INFO - 2018-05-08 12:42:07 --> Model Class Initialized
INFO - 2018-05-08 12:42:07 --> Model Class Initialized
INFO - 2018-05-08 12:42:07 --> Model Class Initialized
INFO - 2018-05-08 12:42:07 --> Final output sent to browser
DEBUG - 2018-05-08 12:42:07 --> Total execution time: 0.2008
INFO - 2018-05-08 07:12:09 --> Config Class Initialized
INFO - 2018-05-08 07:12:09 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:12:09 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:12:09 --> Utf8 Class Initialized
INFO - 2018-05-08 07:12:09 --> URI Class Initialized
INFO - 2018-05-08 07:12:09 --> Router Class Initialized
INFO - 2018-05-08 07:12:09 --> Output Class Initialized
INFO - 2018-05-08 07:12:09 --> Security Class Initialized
DEBUG - 2018-05-08 07:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:12:09 --> Input Class Initialized
INFO - 2018-05-08 07:12:09 --> Language Class Initialized
INFO - 2018-05-08 07:12:09 --> Language Class Initialized
INFO - 2018-05-08 07:12:09 --> Config Class Initialized
INFO - 2018-05-08 07:12:09 --> Loader Class Initialized
INFO - 2018-05-08 12:42:09 --> Helper loaded: url_helper
INFO - 2018-05-08 12:42:09 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:42:09 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:42:09 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:42:09 --> Helper loaded: users_helper
INFO - 2018-05-08 12:42:09 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:42:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:42:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:42:09 --> Helper loaded: form_helper
INFO - 2018-05-08 12:42:09 --> Form Validation Class Initialized
INFO - 2018-05-08 12:42:09 --> Controller Class Initialized
INFO - 2018-05-08 12:42:09 --> Model Class Initialized
INFO - 2018-05-08 12:42:09 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:42:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:42:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:42:09 --> Model Class Initialized
INFO - 2018-05-08 12:42:09 --> Model Class Initialized
INFO - 2018-05-08 12:42:09 --> Model Class Initialized
INFO - 2018-05-08 12:42:09 --> Model Class Initialized
INFO - 2018-05-08 12:42:09 --> Final output sent to browser
DEBUG - 2018-05-08 12:42:09 --> Total execution time: 0.2407
INFO - 2018-05-08 07:12:14 --> Config Class Initialized
INFO - 2018-05-08 07:12:14 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:12:14 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:12:14 --> Utf8 Class Initialized
INFO - 2018-05-08 07:12:14 --> URI Class Initialized
INFO - 2018-05-08 07:12:14 --> Router Class Initialized
INFO - 2018-05-08 07:12:14 --> Output Class Initialized
INFO - 2018-05-08 07:12:14 --> Security Class Initialized
DEBUG - 2018-05-08 07:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:12:14 --> Input Class Initialized
INFO - 2018-05-08 07:12:14 --> Language Class Initialized
INFO - 2018-05-08 07:12:14 --> Language Class Initialized
INFO - 2018-05-08 07:12:14 --> Config Class Initialized
INFO - 2018-05-08 07:12:14 --> Loader Class Initialized
INFO - 2018-05-08 12:42:14 --> Helper loaded: url_helper
INFO - 2018-05-08 12:42:14 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:42:14 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:42:14 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:42:14 --> Helper loaded: users_helper
INFO - 2018-05-08 12:42:14 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:42:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:42:14 --> Helper loaded: form_helper
INFO - 2018-05-08 12:42:14 --> Form Validation Class Initialized
INFO - 2018-05-08 12:42:14 --> Controller Class Initialized
INFO - 2018-05-08 12:42:14 --> Model Class Initialized
INFO - 2018-05-08 12:42:14 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:42:14 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:42:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:42:14 --> Model Class Initialized
INFO - 2018-05-08 12:42:14 --> Model Class Initialized
INFO - 2018-05-08 12:42:14 --> Model Class Initialized
INFO - 2018-05-08 12:42:14 --> Model Class Initialized
INFO - 2018-05-08 12:42:14 --> Final output sent to browser
DEBUG - 2018-05-08 12:42:14 --> Total execution time: 0.1382
INFO - 2018-05-08 07:12:18 --> Config Class Initialized
INFO - 2018-05-08 07:12:18 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:12:18 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:12:18 --> Utf8 Class Initialized
INFO - 2018-05-08 07:12:18 --> URI Class Initialized
INFO - 2018-05-08 07:12:18 --> Router Class Initialized
INFO - 2018-05-08 07:12:18 --> Output Class Initialized
INFO - 2018-05-08 07:12:18 --> Security Class Initialized
DEBUG - 2018-05-08 07:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:12:18 --> Input Class Initialized
INFO - 2018-05-08 07:12:18 --> Language Class Initialized
INFO - 2018-05-08 07:12:18 --> Language Class Initialized
INFO - 2018-05-08 07:12:18 --> Config Class Initialized
INFO - 2018-05-08 07:12:18 --> Loader Class Initialized
INFO - 2018-05-08 12:42:18 --> Helper loaded: url_helper
INFO - 2018-05-08 12:42:18 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:42:18 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:42:18 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:42:18 --> Helper loaded: users_helper
INFO - 2018-05-08 12:42:18 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:42:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:42:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:42:18 --> Helper loaded: form_helper
INFO - 2018-05-08 12:42:18 --> Form Validation Class Initialized
INFO - 2018-05-08 12:42:18 --> Controller Class Initialized
INFO - 2018-05-08 12:42:18 --> Model Class Initialized
INFO - 2018-05-08 12:42:18 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:42:18 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:42:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:42:18 --> Model Class Initialized
INFO - 2018-05-08 12:42:18 --> Model Class Initialized
INFO - 2018-05-08 12:42:18 --> Model Class Initialized
INFO - 2018-05-08 12:42:18 --> Model Class Initialized
INFO - 2018-05-08 12:42:18 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:42:18 --> Final output sent to browser
DEBUG - 2018-05-08 12:42:18 --> Total execution time: 0.1297
INFO - 2018-05-08 07:12:18 --> Config Class Initialized
INFO - 2018-05-08 07:12:18 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:12:18 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:12:18 --> Utf8 Class Initialized
INFO - 2018-05-08 07:12:18 --> URI Class Initialized
INFO - 2018-05-08 07:12:18 --> Router Class Initialized
INFO - 2018-05-08 07:12:18 --> Output Class Initialized
INFO - 2018-05-08 07:12:18 --> Security Class Initialized
DEBUG - 2018-05-08 07:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:12:18 --> Input Class Initialized
INFO - 2018-05-08 07:12:18 --> Language Class Initialized
INFO - 2018-05-08 07:12:18 --> Language Class Initialized
INFO - 2018-05-08 07:12:18 --> Config Class Initialized
INFO - 2018-05-08 07:12:18 --> Loader Class Initialized
INFO - 2018-05-08 12:42:18 --> Helper loaded: url_helper
INFO - 2018-05-08 12:42:18 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:42:18 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:42:18 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:42:18 --> Helper loaded: users_helper
INFO - 2018-05-08 12:42:18 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:42:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:42:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:42:18 --> Helper loaded: form_helper
INFO - 2018-05-08 12:42:18 --> Form Validation Class Initialized
INFO - 2018-05-08 12:42:18 --> Controller Class Initialized
INFO - 2018-05-08 12:42:18 --> Model Class Initialized
INFO - 2018-05-08 12:42:18 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:42:18 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:42:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:42:18 --> Model Class Initialized
INFO - 2018-05-08 12:42:18 --> Model Class Initialized
INFO - 2018-05-08 12:42:18 --> Model Class Initialized
INFO - 2018-05-08 12:42:18 --> Model Class Initialized
INFO - 2018-05-08 12:42:18 --> Model Class Initialized
INFO - 2018-05-08 12:42:18 --> Model Class Initialized
INFO - 2018-05-08 12:42:18 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:42:18 --> Final output sent to browser
DEBUG - 2018-05-08 12:42:18 --> Total execution time: 0.1080
INFO - 2018-05-08 07:12:34 --> Config Class Initialized
INFO - 2018-05-08 07:12:34 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:12:34 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:12:34 --> Utf8 Class Initialized
INFO - 2018-05-08 07:12:34 --> URI Class Initialized
INFO - 2018-05-08 07:12:34 --> Router Class Initialized
INFO - 2018-05-08 07:12:34 --> Output Class Initialized
INFO - 2018-05-08 07:12:34 --> Security Class Initialized
DEBUG - 2018-05-08 07:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:12:34 --> Input Class Initialized
INFO - 2018-05-08 07:12:34 --> Language Class Initialized
INFO - 2018-05-08 07:12:34 --> Language Class Initialized
INFO - 2018-05-08 07:12:34 --> Config Class Initialized
INFO - 2018-05-08 07:12:34 --> Loader Class Initialized
INFO - 2018-05-08 12:42:34 --> Helper loaded: url_helper
INFO - 2018-05-08 12:42:34 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:42:34 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:42:34 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:42:34 --> Helper loaded: users_helper
INFO - 2018-05-08 12:42:34 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:42:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:42:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:42:34 --> Helper loaded: form_helper
INFO - 2018-05-08 12:42:34 --> Form Validation Class Initialized
INFO - 2018-05-08 12:42:34 --> Controller Class Initialized
INFO - 2018-05-08 12:42:34 --> Model Class Initialized
INFO - 2018-05-08 12:42:34 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:42:34 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:42:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:42:34 --> Model Class Initialized
INFO - 2018-05-08 12:42:34 --> Model Class Initialized
INFO - 2018-05-08 12:42:34 --> Model Class Initialized
INFO - 2018-05-08 12:42:34 --> Model Class Initialized
INFO - 2018-05-08 12:42:34 --> Model Class Initialized
INFO - 2018-05-08 12:42:34 --> Model Class Initialized
INFO - 2018-05-08 12:42:34 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:42:34 --> Final output sent to browser
DEBUG - 2018-05-08 12:42:34 --> Total execution time: 0.1154
INFO - 2018-05-08 07:12:44 --> Config Class Initialized
INFO - 2018-05-08 07:12:44 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:12:44 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:12:44 --> Utf8 Class Initialized
INFO - 2018-05-08 07:12:44 --> URI Class Initialized
INFO - 2018-05-08 07:12:44 --> Router Class Initialized
INFO - 2018-05-08 07:12:44 --> Output Class Initialized
INFO - 2018-05-08 07:12:44 --> Security Class Initialized
DEBUG - 2018-05-08 07:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:12:44 --> Input Class Initialized
INFO - 2018-05-08 07:12:44 --> Language Class Initialized
INFO - 2018-05-08 07:12:44 --> Language Class Initialized
INFO - 2018-05-08 07:12:44 --> Config Class Initialized
INFO - 2018-05-08 07:12:44 --> Loader Class Initialized
INFO - 2018-05-08 12:42:44 --> Helper loaded: url_helper
INFO - 2018-05-08 12:42:44 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:42:44 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:42:44 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:42:44 --> Helper loaded: users_helper
INFO - 2018-05-08 12:42:44 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:42:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:42:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:42:44 --> Helper loaded: form_helper
INFO - 2018-05-08 12:42:44 --> Form Validation Class Initialized
INFO - 2018-05-08 12:42:44 --> Controller Class Initialized
INFO - 2018-05-08 12:42:44 --> Model Class Initialized
INFO - 2018-05-08 12:42:44 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:42:44 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:42:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:42:44 --> Model Class Initialized
INFO - 2018-05-08 12:42:44 --> Model Class Initialized
INFO - 2018-05-08 12:42:44 --> Model Class Initialized
INFO - 2018-05-08 12:42:44 --> Model Class Initialized
INFO - 2018-05-08 12:42:44 --> Model Class Initialized
INFO - 2018-05-08 12:42:44 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:42:44 --> Model Class Initialized
INFO - 2018-05-08 12:42:44 --> Final output sent to browser
DEBUG - 2018-05-08 12:42:44 --> Total execution time: 0.1223
INFO - 2018-05-08 07:12:44 --> Config Class Initialized
INFO - 2018-05-08 07:12:44 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:12:44 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:12:44 --> Utf8 Class Initialized
INFO - 2018-05-08 07:12:44 --> URI Class Initialized
INFO - 2018-05-08 07:12:44 --> Router Class Initialized
INFO - 2018-05-08 07:12:44 --> Output Class Initialized
INFO - 2018-05-08 07:12:44 --> Security Class Initialized
DEBUG - 2018-05-08 07:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:12:44 --> Input Class Initialized
INFO - 2018-05-08 07:12:44 --> Language Class Initialized
INFO - 2018-05-08 07:12:44 --> Language Class Initialized
INFO - 2018-05-08 07:12:44 --> Config Class Initialized
INFO - 2018-05-08 07:12:44 --> Loader Class Initialized
INFO - 2018-05-08 12:42:44 --> Helper loaded: url_helper
INFO - 2018-05-08 12:42:44 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:42:44 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:42:44 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:42:44 --> Helper loaded: users_helper
INFO - 2018-05-08 12:42:44 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:42:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:42:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:42:44 --> Helper loaded: form_helper
INFO - 2018-05-08 12:42:44 --> Form Validation Class Initialized
INFO - 2018-05-08 12:42:44 --> Controller Class Initialized
INFO - 2018-05-08 12:42:44 --> Model Class Initialized
INFO - 2018-05-08 12:42:44 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:42:44 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:42:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:42:44 --> Model Class Initialized
INFO - 2018-05-08 12:42:44 --> Model Class Initialized
INFO - 2018-05-08 12:42:44 --> Model Class Initialized
INFO - 2018-05-08 12:42:44 --> Model Class Initialized
INFO - 2018-05-08 12:42:44 --> Model Class Initialized
INFO - 2018-05-08 12:42:44 --> Model Class Initialized
INFO - 2018-05-08 12:42:44 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:42:44 --> Final output sent to browser
DEBUG - 2018-05-08 12:42:44 --> Total execution time: 0.1160
INFO - 2018-05-08 07:12:59 --> Config Class Initialized
INFO - 2018-05-08 07:12:59 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:12:59 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:12:59 --> Utf8 Class Initialized
INFO - 2018-05-08 07:12:59 --> URI Class Initialized
INFO - 2018-05-08 07:12:59 --> Router Class Initialized
INFO - 2018-05-08 07:12:59 --> Output Class Initialized
INFO - 2018-05-08 07:12:59 --> Security Class Initialized
DEBUG - 2018-05-08 07:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:12:59 --> Input Class Initialized
INFO - 2018-05-08 07:12:59 --> Language Class Initialized
INFO - 2018-05-08 07:12:59 --> Language Class Initialized
INFO - 2018-05-08 07:12:59 --> Config Class Initialized
INFO - 2018-05-08 07:12:59 --> Loader Class Initialized
INFO - 2018-05-08 12:42:59 --> Helper loaded: url_helper
INFO - 2018-05-08 12:42:59 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:42:59 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:42:59 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:42:59 --> Helper loaded: users_helper
INFO - 2018-05-08 12:42:59 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:42:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:42:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:42:59 --> Helper loaded: form_helper
INFO - 2018-05-08 12:42:59 --> Form Validation Class Initialized
INFO - 2018-05-08 12:42:59 --> Controller Class Initialized
INFO - 2018-05-08 12:42:59 --> Model Class Initialized
INFO - 2018-05-08 12:42:59 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:42:59 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:42:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:42:59 --> Model Class Initialized
INFO - 2018-05-08 12:42:59 --> Model Class Initialized
INFO - 2018-05-08 12:42:59 --> Model Class Initialized
INFO - 2018-05-08 12:42:59 --> Model Class Initialized
INFO - 2018-05-08 12:42:59 --> Model Class Initialized
INFO - 2018-05-08 12:42:59 --> Model Class Initialized
INFO - 2018-05-08 12:42:59 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:42:59 --> Final output sent to browser
DEBUG - 2018-05-08 12:42:59 --> Total execution time: 0.1176
INFO - 2018-05-08 07:13:08 --> Config Class Initialized
INFO - 2018-05-08 07:13:08 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:13:08 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:13:08 --> Utf8 Class Initialized
INFO - 2018-05-08 07:13:08 --> URI Class Initialized
INFO - 2018-05-08 07:13:08 --> Router Class Initialized
INFO - 2018-05-08 07:13:08 --> Output Class Initialized
INFO - 2018-05-08 07:13:08 --> Security Class Initialized
DEBUG - 2018-05-08 07:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:13:08 --> Input Class Initialized
INFO - 2018-05-08 07:13:08 --> Language Class Initialized
INFO - 2018-05-08 07:13:08 --> Language Class Initialized
INFO - 2018-05-08 07:13:08 --> Config Class Initialized
INFO - 2018-05-08 07:13:08 --> Loader Class Initialized
INFO - 2018-05-08 12:43:08 --> Helper loaded: url_helper
INFO - 2018-05-08 12:43:08 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:43:08 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:43:08 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:43:08 --> Helper loaded: users_helper
INFO - 2018-05-08 12:43:08 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:43:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:43:08 --> Helper loaded: form_helper
INFO - 2018-05-08 12:43:08 --> Form Validation Class Initialized
INFO - 2018-05-08 12:43:08 --> Controller Class Initialized
INFO - 2018-05-08 12:43:08 --> Model Class Initialized
INFO - 2018-05-08 12:43:08 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:43:08 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:43:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:43:08 --> Model Class Initialized
INFO - 2018-05-08 12:43:08 --> Model Class Initialized
INFO - 2018-05-08 12:43:08 --> Model Class Initialized
INFO - 2018-05-08 12:43:08 --> Model Class Initialized
INFO - 2018-05-08 12:43:08 --> Final output sent to browser
DEBUG - 2018-05-08 12:43:08 --> Total execution time: 0.1143
INFO - 2018-05-08 07:13:09 --> Config Class Initialized
INFO - 2018-05-08 07:13:09 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:13:09 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:13:09 --> Utf8 Class Initialized
INFO - 2018-05-08 07:13:09 --> URI Class Initialized
INFO - 2018-05-08 07:13:09 --> Router Class Initialized
INFO - 2018-05-08 07:13:09 --> Output Class Initialized
INFO - 2018-05-08 07:13:09 --> Security Class Initialized
DEBUG - 2018-05-08 07:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:13:09 --> Input Class Initialized
INFO - 2018-05-08 07:13:09 --> Language Class Initialized
INFO - 2018-05-08 07:13:09 --> Language Class Initialized
INFO - 2018-05-08 07:13:09 --> Config Class Initialized
INFO - 2018-05-08 07:13:09 --> Loader Class Initialized
INFO - 2018-05-08 12:43:09 --> Helper loaded: url_helper
INFO - 2018-05-08 12:43:09 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:43:09 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:43:09 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:43:09 --> Helper loaded: users_helper
INFO - 2018-05-08 12:43:09 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:43:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:43:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:43:09 --> Helper loaded: form_helper
INFO - 2018-05-08 12:43:09 --> Form Validation Class Initialized
INFO - 2018-05-08 12:43:09 --> Controller Class Initialized
INFO - 2018-05-08 12:43:09 --> Model Class Initialized
INFO - 2018-05-08 12:43:09 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:43:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:43:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:43:09 --> Model Class Initialized
INFO - 2018-05-08 12:43:09 --> Model Class Initialized
INFO - 2018-05-08 12:43:09 --> Model Class Initialized
INFO - 2018-05-08 12:43:09 --> Model Class Initialized
INFO - 2018-05-08 12:43:09 --> Final output sent to browser
DEBUG - 2018-05-08 12:43:09 --> Total execution time: 0.1177
INFO - 2018-05-08 07:13:10 --> Config Class Initialized
INFO - 2018-05-08 07:13:10 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:13:10 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:13:10 --> Utf8 Class Initialized
INFO - 2018-05-08 07:13:10 --> URI Class Initialized
INFO - 2018-05-08 07:13:10 --> Router Class Initialized
INFO - 2018-05-08 07:13:10 --> Output Class Initialized
INFO - 2018-05-08 07:13:10 --> Security Class Initialized
DEBUG - 2018-05-08 07:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:13:10 --> Input Class Initialized
INFO - 2018-05-08 07:13:10 --> Language Class Initialized
INFO - 2018-05-08 07:13:10 --> Language Class Initialized
INFO - 2018-05-08 07:13:10 --> Config Class Initialized
INFO - 2018-05-08 07:13:10 --> Loader Class Initialized
INFO - 2018-05-08 12:43:10 --> Helper loaded: url_helper
INFO - 2018-05-08 12:43:10 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:43:10 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:43:10 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:43:10 --> Helper loaded: users_helper
INFO - 2018-05-08 12:43:10 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:43:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:43:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:43:10 --> Helper loaded: form_helper
INFO - 2018-05-08 12:43:10 --> Form Validation Class Initialized
INFO - 2018-05-08 12:43:10 --> Controller Class Initialized
INFO - 2018-05-08 12:43:10 --> Model Class Initialized
INFO - 2018-05-08 12:43:10 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:43:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:43:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:43:10 --> Model Class Initialized
INFO - 2018-05-08 12:43:10 --> Model Class Initialized
INFO - 2018-05-08 12:43:10 --> Model Class Initialized
INFO - 2018-05-08 12:43:10 --> Model Class Initialized
INFO - 2018-05-08 12:43:10 --> Final output sent to browser
DEBUG - 2018-05-08 12:43:10 --> Total execution time: 0.1240
INFO - 2018-05-08 07:13:11 --> Config Class Initialized
INFO - 2018-05-08 07:13:11 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:13:11 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:13:11 --> Utf8 Class Initialized
INFO - 2018-05-08 07:13:11 --> URI Class Initialized
INFO - 2018-05-08 07:13:11 --> Router Class Initialized
INFO - 2018-05-08 07:13:11 --> Output Class Initialized
INFO - 2018-05-08 07:13:11 --> Security Class Initialized
DEBUG - 2018-05-08 07:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:13:11 --> Input Class Initialized
INFO - 2018-05-08 07:13:11 --> Language Class Initialized
INFO - 2018-05-08 07:13:11 --> Language Class Initialized
INFO - 2018-05-08 07:13:11 --> Config Class Initialized
INFO - 2018-05-08 07:13:11 --> Loader Class Initialized
INFO - 2018-05-08 12:43:11 --> Helper loaded: url_helper
INFO - 2018-05-08 12:43:11 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:43:11 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:43:11 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:43:11 --> Helper loaded: users_helper
INFO - 2018-05-08 12:43:11 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:43:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:43:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:43:11 --> Helper loaded: form_helper
INFO - 2018-05-08 12:43:11 --> Form Validation Class Initialized
INFO - 2018-05-08 12:43:11 --> Controller Class Initialized
INFO - 2018-05-08 12:43:11 --> Model Class Initialized
INFO - 2018-05-08 12:43:11 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:43:11 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:43:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:43:11 --> Model Class Initialized
INFO - 2018-05-08 12:43:11 --> Model Class Initialized
INFO - 2018-05-08 12:43:11 --> Model Class Initialized
INFO - 2018-05-08 12:43:11 --> Model Class Initialized
INFO - 2018-05-08 12:43:11 --> Final output sent to browser
DEBUG - 2018-05-08 12:43:11 --> Total execution time: 0.0985
INFO - 2018-05-08 07:13:12 --> Config Class Initialized
INFO - 2018-05-08 07:13:12 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:13:12 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:13:12 --> Utf8 Class Initialized
INFO - 2018-05-08 07:13:12 --> URI Class Initialized
INFO - 2018-05-08 07:13:12 --> Router Class Initialized
INFO - 2018-05-08 07:13:12 --> Output Class Initialized
INFO - 2018-05-08 07:13:12 --> Security Class Initialized
DEBUG - 2018-05-08 07:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:13:12 --> Input Class Initialized
INFO - 2018-05-08 07:13:12 --> Language Class Initialized
INFO - 2018-05-08 07:13:12 --> Language Class Initialized
INFO - 2018-05-08 07:13:12 --> Config Class Initialized
INFO - 2018-05-08 07:13:12 --> Loader Class Initialized
INFO - 2018-05-08 12:43:12 --> Helper loaded: url_helper
INFO - 2018-05-08 12:43:12 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:43:12 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:43:12 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:43:12 --> Helper loaded: users_helper
INFO - 2018-05-08 12:43:12 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:43:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:43:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:43:12 --> Helper loaded: form_helper
INFO - 2018-05-08 12:43:12 --> Form Validation Class Initialized
INFO - 2018-05-08 12:43:12 --> Controller Class Initialized
INFO - 2018-05-08 12:43:12 --> Model Class Initialized
INFO - 2018-05-08 12:43:12 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:43:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:43:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:43:12 --> Model Class Initialized
INFO - 2018-05-08 12:43:12 --> Model Class Initialized
INFO - 2018-05-08 12:43:12 --> Model Class Initialized
INFO - 2018-05-08 12:43:12 --> Model Class Initialized
INFO - 2018-05-08 12:43:12 --> Final output sent to browser
DEBUG - 2018-05-08 12:43:12 --> Total execution time: 0.1640
INFO - 2018-05-08 07:13:13 --> Config Class Initialized
INFO - 2018-05-08 07:13:13 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:13:13 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:13:13 --> Utf8 Class Initialized
INFO - 2018-05-08 07:13:13 --> URI Class Initialized
INFO - 2018-05-08 07:13:13 --> Router Class Initialized
INFO - 2018-05-08 07:13:13 --> Output Class Initialized
INFO - 2018-05-08 07:13:13 --> Security Class Initialized
DEBUG - 2018-05-08 07:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:13:13 --> Input Class Initialized
INFO - 2018-05-08 07:13:13 --> Language Class Initialized
INFO - 2018-05-08 07:13:13 --> Language Class Initialized
INFO - 2018-05-08 07:13:13 --> Config Class Initialized
INFO - 2018-05-08 07:13:13 --> Loader Class Initialized
INFO - 2018-05-08 12:43:13 --> Helper loaded: url_helper
INFO - 2018-05-08 12:43:13 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:43:13 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:43:13 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:43:13 --> Helper loaded: users_helper
INFO - 2018-05-08 12:43:13 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:43:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:43:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:43:13 --> Helper loaded: form_helper
INFO - 2018-05-08 12:43:13 --> Form Validation Class Initialized
INFO - 2018-05-08 12:43:13 --> Controller Class Initialized
INFO - 2018-05-08 12:43:13 --> Model Class Initialized
INFO - 2018-05-08 12:43:13 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:43:13 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:43:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:43:13 --> Model Class Initialized
INFO - 2018-05-08 12:43:14 --> Model Class Initialized
INFO - 2018-05-08 12:43:14 --> Model Class Initialized
INFO - 2018-05-08 12:43:14 --> Model Class Initialized
INFO - 2018-05-08 12:43:14 --> Final output sent to browser
DEBUG - 2018-05-08 12:43:14 --> Total execution time: 0.1074
INFO - 2018-05-08 07:13:15 --> Config Class Initialized
INFO - 2018-05-08 07:13:15 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:13:15 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:13:15 --> Utf8 Class Initialized
INFO - 2018-05-08 07:13:15 --> URI Class Initialized
INFO - 2018-05-08 07:13:15 --> Router Class Initialized
INFO - 2018-05-08 07:13:15 --> Output Class Initialized
INFO - 2018-05-08 07:13:15 --> Security Class Initialized
DEBUG - 2018-05-08 07:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:13:15 --> Input Class Initialized
INFO - 2018-05-08 07:13:15 --> Language Class Initialized
INFO - 2018-05-08 07:13:15 --> Language Class Initialized
INFO - 2018-05-08 07:13:15 --> Config Class Initialized
INFO - 2018-05-08 07:13:15 --> Loader Class Initialized
INFO - 2018-05-08 12:43:15 --> Helper loaded: url_helper
INFO - 2018-05-08 12:43:15 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:43:15 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:43:15 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:43:15 --> Helper loaded: users_helper
INFO - 2018-05-08 12:43:15 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:43:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:43:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:43:15 --> Helper loaded: form_helper
INFO - 2018-05-08 12:43:15 --> Form Validation Class Initialized
INFO - 2018-05-08 12:43:15 --> Controller Class Initialized
INFO - 2018-05-08 12:43:15 --> Model Class Initialized
INFO - 2018-05-08 12:43:15 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:43:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:43:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:43:15 --> Model Class Initialized
INFO - 2018-05-08 12:43:15 --> Model Class Initialized
INFO - 2018-05-08 12:43:15 --> Model Class Initialized
INFO - 2018-05-08 12:43:15 --> Model Class Initialized
INFO - 2018-05-08 12:43:15 --> Final output sent to browser
DEBUG - 2018-05-08 12:43:15 --> Total execution time: 0.1401
INFO - 2018-05-08 07:13:16 --> Config Class Initialized
INFO - 2018-05-08 07:13:16 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:13:16 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:13:16 --> Utf8 Class Initialized
INFO - 2018-05-08 07:13:16 --> URI Class Initialized
INFO - 2018-05-08 07:13:16 --> Router Class Initialized
INFO - 2018-05-08 07:13:16 --> Output Class Initialized
INFO - 2018-05-08 07:13:16 --> Security Class Initialized
DEBUG - 2018-05-08 07:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:13:16 --> Input Class Initialized
INFO - 2018-05-08 07:13:16 --> Language Class Initialized
INFO - 2018-05-08 07:13:16 --> Language Class Initialized
INFO - 2018-05-08 07:13:16 --> Config Class Initialized
INFO - 2018-05-08 07:13:16 --> Loader Class Initialized
INFO - 2018-05-08 12:43:16 --> Helper loaded: url_helper
INFO - 2018-05-08 12:43:16 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:43:16 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:43:16 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:43:16 --> Helper loaded: users_helper
INFO - 2018-05-08 12:43:16 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:43:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:43:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:43:16 --> Helper loaded: form_helper
INFO - 2018-05-08 12:43:16 --> Form Validation Class Initialized
INFO - 2018-05-08 12:43:16 --> Controller Class Initialized
INFO - 2018-05-08 12:43:16 --> Model Class Initialized
INFO - 2018-05-08 12:43:16 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:43:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:43:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:43:16 --> Model Class Initialized
INFO - 2018-05-08 12:43:16 --> Model Class Initialized
INFO - 2018-05-08 12:43:16 --> Model Class Initialized
INFO - 2018-05-08 12:43:16 --> Model Class Initialized
INFO - 2018-05-08 12:43:16 --> Final output sent to browser
DEBUG - 2018-05-08 12:43:16 --> Total execution time: 0.1289
INFO - 2018-05-08 07:13:22 --> Config Class Initialized
INFO - 2018-05-08 07:13:22 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:13:22 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:13:22 --> Utf8 Class Initialized
INFO - 2018-05-08 07:13:22 --> URI Class Initialized
INFO - 2018-05-08 07:13:22 --> Router Class Initialized
INFO - 2018-05-08 07:13:22 --> Output Class Initialized
INFO - 2018-05-08 07:13:22 --> Security Class Initialized
DEBUG - 2018-05-08 07:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:13:22 --> Input Class Initialized
INFO - 2018-05-08 07:13:22 --> Language Class Initialized
INFO - 2018-05-08 07:13:22 --> Language Class Initialized
INFO - 2018-05-08 07:13:22 --> Config Class Initialized
INFO - 2018-05-08 07:13:22 --> Loader Class Initialized
INFO - 2018-05-08 12:43:22 --> Helper loaded: url_helper
INFO - 2018-05-08 12:43:22 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:43:22 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:43:22 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:43:22 --> Helper loaded: users_helper
INFO - 2018-05-08 12:43:22 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:43:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:43:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:43:22 --> Helper loaded: form_helper
INFO - 2018-05-08 12:43:22 --> Form Validation Class Initialized
INFO - 2018-05-08 12:43:22 --> Controller Class Initialized
INFO - 2018-05-08 12:43:23 --> Model Class Initialized
INFO - 2018-05-08 12:43:23 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:43:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:43:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:43:23 --> Model Class Initialized
INFO - 2018-05-08 12:43:23 --> Model Class Initialized
INFO - 2018-05-08 12:43:23 --> Model Class Initialized
INFO - 2018-05-08 12:43:23 --> Model Class Initialized
INFO - 2018-05-08 12:43:23 --> Model Class Initialized
INFO - 2018-05-08 12:43:23 --> Model Class Initialized
INFO - 2018-05-08 12:43:23 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-05-08 12:43:23 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 800
INFO - 2018-05-08 12:43:23 --> Final output sent to browser
DEBUG - 2018-05-08 12:43:23 --> Total execution time: 0.1167
INFO - 2018-05-08 07:13:42 --> Config Class Initialized
INFO - 2018-05-08 07:13:42 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:13:42 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:13:42 --> Utf8 Class Initialized
INFO - 2018-05-08 07:13:42 --> URI Class Initialized
INFO - 2018-05-08 07:13:42 --> Router Class Initialized
INFO - 2018-05-08 07:13:42 --> Output Class Initialized
INFO - 2018-05-08 07:13:42 --> Security Class Initialized
DEBUG - 2018-05-08 07:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:13:42 --> Input Class Initialized
INFO - 2018-05-08 07:13:42 --> Language Class Initialized
INFO - 2018-05-08 07:13:42 --> Language Class Initialized
INFO - 2018-05-08 07:13:42 --> Config Class Initialized
INFO - 2018-05-08 07:13:42 --> Loader Class Initialized
INFO - 2018-05-08 12:43:42 --> Helper loaded: url_helper
INFO - 2018-05-08 12:43:42 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:43:42 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:43:42 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:43:42 --> Helper loaded: users_helper
INFO - 2018-05-08 12:43:42 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:43:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:43:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:43:42 --> Helper loaded: form_helper
INFO - 2018-05-08 12:43:42 --> Form Validation Class Initialized
INFO - 2018-05-08 12:43:42 --> Controller Class Initialized
INFO - 2018-05-08 12:43:42 --> Model Class Initialized
INFO - 2018-05-08 12:43:42 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:43:42 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:43:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:43:42 --> Model Class Initialized
INFO - 2018-05-08 12:43:42 --> Model Class Initialized
INFO - 2018-05-08 12:43:42 --> Model Class Initialized
INFO - 2018-05-08 12:43:42 --> Model Class Initialized
INFO - 2018-05-08 12:43:42 --> Model Class Initialized
INFO - 2018-05-08 12:43:42 --> Model Class Initialized
INFO - 2018-05-08 12:43:42 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-05-08 12:43:42 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 800
INFO - 2018-05-08 12:43:42 --> Final output sent to browser
DEBUG - 2018-05-08 12:43:42 --> Total execution time: 0.1293
INFO - 2018-05-08 07:14:01 --> Config Class Initialized
INFO - 2018-05-08 07:14:01 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:14:01 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:14:01 --> Utf8 Class Initialized
INFO - 2018-05-08 07:14:01 --> URI Class Initialized
INFO - 2018-05-08 07:14:01 --> Router Class Initialized
INFO - 2018-05-08 07:14:01 --> Output Class Initialized
INFO - 2018-05-08 07:14:01 --> Security Class Initialized
DEBUG - 2018-05-08 07:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:14:01 --> Input Class Initialized
INFO - 2018-05-08 07:14:01 --> Language Class Initialized
INFO - 2018-05-08 07:14:01 --> Language Class Initialized
INFO - 2018-05-08 07:14:01 --> Config Class Initialized
INFO - 2018-05-08 07:14:01 --> Loader Class Initialized
INFO - 2018-05-08 12:44:01 --> Helper loaded: url_helper
INFO - 2018-05-08 12:44:01 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:44:01 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:44:01 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:44:01 --> Helper loaded: users_helper
INFO - 2018-05-08 12:44:01 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:44:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:44:01 --> Helper loaded: form_helper
INFO - 2018-05-08 12:44:01 --> Form Validation Class Initialized
INFO - 2018-05-08 12:44:01 --> Controller Class Initialized
INFO - 2018-05-08 12:44:01 --> Model Class Initialized
INFO - 2018-05-08 12:44:01 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:44:01 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:44:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:44:01 --> Model Class Initialized
INFO - 2018-05-08 12:44:01 --> Model Class Initialized
INFO - 2018-05-08 12:44:01 --> Model Class Initialized
INFO - 2018-05-08 12:44:01 --> Model Class Initialized
INFO - 2018-05-08 12:44:01 --> Model Class Initialized
INFO - 2018-05-08 12:44:01 --> Model Class Initialized
INFO - 2018-05-08 12:44:01 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:44:01 --> Model Class Initialized
INFO - 2018-05-08 12:44:01 --> Final output sent to browser
DEBUG - 2018-05-08 12:44:01 --> Total execution time: 0.1454
INFO - 2018-05-08 07:14:12 --> Config Class Initialized
INFO - 2018-05-08 07:14:12 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:14:12 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:14:12 --> Utf8 Class Initialized
INFO - 2018-05-08 07:14:12 --> URI Class Initialized
INFO - 2018-05-08 07:14:12 --> Router Class Initialized
INFO - 2018-05-08 07:14:12 --> Output Class Initialized
INFO - 2018-05-08 07:14:12 --> Security Class Initialized
DEBUG - 2018-05-08 07:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:14:12 --> Input Class Initialized
INFO - 2018-05-08 07:14:12 --> Language Class Initialized
INFO - 2018-05-08 07:14:12 --> Language Class Initialized
INFO - 2018-05-08 07:14:12 --> Config Class Initialized
INFO - 2018-05-08 07:14:12 --> Loader Class Initialized
INFO - 2018-05-08 12:44:12 --> Helper loaded: url_helper
INFO - 2018-05-08 12:44:12 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:44:12 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:44:12 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:44:12 --> Helper loaded: users_helper
INFO - 2018-05-08 12:44:12 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:44:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:44:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:44:12 --> Helper loaded: form_helper
INFO - 2018-05-08 12:44:12 --> Form Validation Class Initialized
INFO - 2018-05-08 12:44:12 --> Controller Class Initialized
INFO - 2018-05-08 12:44:12 --> Model Class Initialized
INFO - 2018-05-08 12:44:12 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:44:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:44:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:44:12 --> Model Class Initialized
INFO - 2018-05-08 12:44:12 --> Model Class Initialized
INFO - 2018-05-08 12:44:12 --> Model Class Initialized
INFO - 2018-05-08 12:44:12 --> Model Class Initialized
INFO - 2018-05-08 12:44:12 --> Model Class Initialized
INFO - 2018-05-08 12:44:12 --> Model Class Initialized
INFO - 2018-05-08 12:44:12 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:44:12 --> Model Class Initialized
INFO - 2018-05-08 12:44:12 --> Model Class Initialized
INFO - 2018-05-08 12:44:12 --> Model Class Initialized
INFO - 2018-05-08 12:44:12 --> Final output sent to browser
DEBUG - 2018-05-08 12:44:12 --> Total execution time: 0.2471
INFO - 2018-05-08 07:14:15 --> Config Class Initialized
INFO - 2018-05-08 07:14:15 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:14:15 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:14:15 --> Utf8 Class Initialized
INFO - 2018-05-08 07:14:15 --> URI Class Initialized
INFO - 2018-05-08 07:14:15 --> Router Class Initialized
INFO - 2018-05-08 07:14:15 --> Output Class Initialized
INFO - 2018-05-08 07:14:15 --> Security Class Initialized
DEBUG - 2018-05-08 07:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:14:15 --> Input Class Initialized
INFO - 2018-05-08 07:14:15 --> Language Class Initialized
INFO - 2018-05-08 07:14:15 --> Language Class Initialized
INFO - 2018-05-08 07:14:15 --> Config Class Initialized
INFO - 2018-05-08 07:14:15 --> Loader Class Initialized
INFO - 2018-05-08 12:44:15 --> Helper loaded: url_helper
INFO - 2018-05-08 12:44:15 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:44:15 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:44:15 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:44:15 --> Helper loaded: users_helper
INFO - 2018-05-08 12:44:15 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:44:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:44:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:44:15 --> Helper loaded: form_helper
INFO - 2018-05-08 12:44:15 --> Form Validation Class Initialized
INFO - 2018-05-08 12:44:15 --> Controller Class Initialized
INFO - 2018-05-08 12:44:15 --> Model Class Initialized
INFO - 2018-05-08 12:44:15 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:44:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:44:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:44:15 --> Model Class Initialized
INFO - 2018-05-08 12:44:15 --> Model Class Initialized
INFO - 2018-05-08 12:44:15 --> Model Class Initialized
INFO - 2018-05-08 12:44:15 --> Model Class Initialized
INFO - 2018-05-08 12:44:15 --> Model Class Initialized
INFO - 2018-05-08 12:44:15 --> Model Class Initialized
INFO - 2018-05-08 12:44:15 --> Model Class Initialized
INFO - 2018-05-08 12:44:15 --> Model Class Initialized
INFO - 2018-05-08 12:44:15 --> Model Class Initialized
INFO - 2018-05-08 12:44:15 --> Model Class Initialized
INFO - 2018-05-08 12:44:15 --> Model Class Initialized
INFO - 2018-05-08 12:44:15 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:44:15 --> Model Class Initialized
INFO - 2018-05-08 12:44:15 --> Final output sent to browser
DEBUG - 2018-05-08 12:44:15 --> Total execution time: 0.1507
INFO - 2018-05-08 07:14:22 --> Config Class Initialized
INFO - 2018-05-08 07:14:22 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:14:22 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:14:22 --> Utf8 Class Initialized
INFO - 2018-05-08 07:14:22 --> URI Class Initialized
INFO - 2018-05-08 07:14:22 --> Router Class Initialized
INFO - 2018-05-08 07:14:22 --> Output Class Initialized
INFO - 2018-05-08 07:14:22 --> Security Class Initialized
DEBUG - 2018-05-08 07:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:14:22 --> Input Class Initialized
INFO - 2018-05-08 07:14:22 --> Language Class Initialized
INFO - 2018-05-08 07:14:22 --> Language Class Initialized
INFO - 2018-05-08 07:14:22 --> Config Class Initialized
INFO - 2018-05-08 07:14:22 --> Loader Class Initialized
INFO - 2018-05-08 12:44:22 --> Helper loaded: url_helper
INFO - 2018-05-08 12:44:22 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:44:22 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:44:22 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:44:22 --> Helper loaded: users_helper
INFO - 2018-05-08 12:44:22 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:44:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:44:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:44:22 --> Helper loaded: form_helper
INFO - 2018-05-08 12:44:22 --> Form Validation Class Initialized
INFO - 2018-05-08 12:44:22 --> Controller Class Initialized
INFO - 2018-05-08 12:44:22 --> Model Class Initialized
INFO - 2018-05-08 12:44:22 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:44:22 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:44:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:44:22 --> Model Class Initialized
INFO - 2018-05-08 12:44:22 --> Model Class Initialized
INFO - 2018-05-08 12:44:22 --> Model Class Initialized
INFO - 2018-05-08 12:44:22 --> Model Class Initialized
INFO - 2018-05-08 12:44:22 --> Model Class Initialized
INFO - 2018-05-08 12:44:22 --> Model Class Initialized
INFO - 2018-05-08 12:44:22 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:44:22 --> Model Class Initialized
INFO - 2018-05-08 12:44:22 --> Model Class Initialized
INFO - 2018-05-08 12:44:22 --> Model Class Initialized
INFO - 2018-05-08 12:44:22 --> Final output sent to browser
DEBUG - 2018-05-08 12:44:22 --> Total execution time: 0.2812
INFO - 2018-05-08 07:14:23 --> Config Class Initialized
INFO - 2018-05-08 07:14:23 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:14:23 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:14:23 --> Utf8 Class Initialized
INFO - 2018-05-08 07:14:23 --> URI Class Initialized
INFO - 2018-05-08 07:14:23 --> Router Class Initialized
INFO - 2018-05-08 07:14:23 --> Output Class Initialized
INFO - 2018-05-08 07:14:23 --> Security Class Initialized
DEBUG - 2018-05-08 07:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:14:23 --> Input Class Initialized
INFO - 2018-05-08 07:14:23 --> Language Class Initialized
INFO - 2018-05-08 07:14:24 --> Language Class Initialized
INFO - 2018-05-08 07:14:24 --> Config Class Initialized
INFO - 2018-05-08 07:14:24 --> Loader Class Initialized
INFO - 2018-05-08 12:44:24 --> Helper loaded: url_helper
INFO - 2018-05-08 12:44:24 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:44:24 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:44:24 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:44:24 --> Helper loaded: users_helper
INFO - 2018-05-08 12:44:24 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:44:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:44:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:44:24 --> Helper loaded: form_helper
INFO - 2018-05-08 12:44:24 --> Form Validation Class Initialized
INFO - 2018-05-08 12:44:24 --> Controller Class Initialized
INFO - 2018-05-08 12:44:24 --> Model Class Initialized
INFO - 2018-05-08 12:44:24 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:44:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:44:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:44:24 --> Model Class Initialized
INFO - 2018-05-08 12:44:24 --> Model Class Initialized
INFO - 2018-05-08 12:44:24 --> Model Class Initialized
INFO - 2018-05-08 12:44:24 --> Model Class Initialized
INFO - 2018-05-08 12:44:24 --> Model Class Initialized
INFO - 2018-05-08 12:44:24 --> Model Class Initialized
INFO - 2018-05-08 12:44:24 --> Model Class Initialized
INFO - 2018-05-08 12:44:24 --> Model Class Initialized
INFO - 2018-05-08 12:44:24 --> Model Class Initialized
INFO - 2018-05-08 12:44:24 --> Model Class Initialized
INFO - 2018-05-08 12:44:24 --> Model Class Initialized
INFO - 2018-05-08 12:44:24 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:44:24 --> Model Class Initialized
INFO - 2018-05-08 12:44:24 --> Final output sent to browser
DEBUG - 2018-05-08 12:44:24 --> Total execution time: 0.1426
INFO - 2018-05-08 07:14:26 --> Config Class Initialized
INFO - 2018-05-08 07:14:26 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:14:26 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:14:26 --> Utf8 Class Initialized
INFO - 2018-05-08 07:14:26 --> URI Class Initialized
INFO - 2018-05-08 07:14:26 --> Router Class Initialized
INFO - 2018-05-08 07:14:26 --> Output Class Initialized
INFO - 2018-05-08 07:14:26 --> Security Class Initialized
DEBUG - 2018-05-08 07:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:14:26 --> Input Class Initialized
INFO - 2018-05-08 07:14:26 --> Language Class Initialized
INFO - 2018-05-08 07:14:26 --> Language Class Initialized
INFO - 2018-05-08 07:14:26 --> Config Class Initialized
INFO - 2018-05-08 07:14:26 --> Loader Class Initialized
INFO - 2018-05-08 12:44:26 --> Helper loaded: url_helper
INFO - 2018-05-08 12:44:26 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:44:26 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:44:26 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:44:26 --> Helper loaded: users_helper
INFO - 2018-05-08 12:44:26 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:44:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:44:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:44:26 --> Helper loaded: form_helper
INFO - 2018-05-08 12:44:26 --> Form Validation Class Initialized
INFO - 2018-05-08 12:44:26 --> Controller Class Initialized
INFO - 2018-05-08 12:44:26 --> Model Class Initialized
INFO - 2018-05-08 12:44:26 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:44:26 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:44:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:44:26 --> Model Class Initialized
INFO - 2018-05-08 12:44:26 --> Model Class Initialized
INFO - 2018-05-08 12:44:26 --> Model Class Initialized
INFO - 2018-05-08 12:44:26 --> Model Class Initialized
INFO - 2018-05-08 12:44:26 --> Model Class Initialized
INFO - 2018-05-08 12:44:26 --> Model Class Initialized
INFO - 2018-05-08 12:44:26 --> Model Class Initialized
INFO - 2018-05-08 12:44:26 --> Model Class Initialized
INFO - 2018-05-08 12:44:26 --> Model Class Initialized
INFO - 2018-05-08 12:44:26 --> Model Class Initialized
INFO - 2018-05-08 12:44:26 --> Model Class Initialized
INFO - 2018-05-08 12:44:26 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:44:26 --> Model Class Initialized
INFO - 2018-05-08 12:44:26 --> Final output sent to browser
DEBUG - 2018-05-08 12:44:26 --> Total execution time: 0.1400
INFO - 2018-05-08 07:14:29 --> Config Class Initialized
INFO - 2018-05-08 07:14:29 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:14:29 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:14:29 --> Utf8 Class Initialized
INFO - 2018-05-08 07:14:29 --> URI Class Initialized
INFO - 2018-05-08 07:14:29 --> Router Class Initialized
INFO - 2018-05-08 07:14:29 --> Output Class Initialized
INFO - 2018-05-08 07:14:29 --> Security Class Initialized
DEBUG - 2018-05-08 07:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:14:29 --> Input Class Initialized
INFO - 2018-05-08 07:14:29 --> Language Class Initialized
INFO - 2018-05-08 07:14:29 --> Language Class Initialized
INFO - 2018-05-08 07:14:29 --> Config Class Initialized
INFO - 2018-05-08 07:14:29 --> Loader Class Initialized
INFO - 2018-05-08 12:44:29 --> Helper loaded: url_helper
INFO - 2018-05-08 12:44:29 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:44:29 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:44:29 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:44:29 --> Helper loaded: users_helper
INFO - 2018-05-08 12:44:29 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:44:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:44:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:44:29 --> Helper loaded: form_helper
INFO - 2018-05-08 12:44:29 --> Form Validation Class Initialized
INFO - 2018-05-08 12:44:29 --> Controller Class Initialized
INFO - 2018-05-08 12:44:29 --> Model Class Initialized
INFO - 2018-05-08 12:44:29 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:44:29 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:44:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:44:29 --> Model Class Initialized
INFO - 2018-05-08 12:44:29 --> Model Class Initialized
INFO - 2018-05-08 12:44:29 --> Model Class Initialized
INFO - 2018-05-08 12:44:29 --> Model Class Initialized
INFO - 2018-05-08 12:44:29 --> Model Class Initialized
INFO - 2018-05-08 12:44:29 --> Model Class Initialized
INFO - 2018-05-08 12:44:29 --> Model Class Initialized
INFO - 2018-05-08 12:44:29 --> Model Class Initialized
INFO - 2018-05-08 12:44:29 --> Model Class Initialized
INFO - 2018-05-08 12:44:29 --> Model Class Initialized
INFO - 2018-05-08 12:44:29 --> Model Class Initialized
INFO - 2018-05-08 12:44:29 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:44:29 --> Model Class Initialized
INFO - 2018-05-08 12:44:29 --> Final output sent to browser
DEBUG - 2018-05-08 12:44:29 --> Total execution time: 0.1166
INFO - 2018-05-08 07:14:38 --> Config Class Initialized
INFO - 2018-05-08 07:14:38 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:14:38 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:14:38 --> Utf8 Class Initialized
INFO - 2018-05-08 07:14:38 --> URI Class Initialized
INFO - 2018-05-08 07:14:38 --> Router Class Initialized
INFO - 2018-05-08 07:14:38 --> Output Class Initialized
INFO - 2018-05-08 07:14:38 --> Security Class Initialized
DEBUG - 2018-05-08 07:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:14:38 --> Input Class Initialized
INFO - 2018-05-08 07:14:38 --> Language Class Initialized
INFO - 2018-05-08 07:14:38 --> Language Class Initialized
INFO - 2018-05-08 07:14:38 --> Config Class Initialized
INFO - 2018-05-08 07:14:38 --> Loader Class Initialized
INFO - 2018-05-08 12:44:38 --> Helper loaded: url_helper
INFO - 2018-05-08 12:44:38 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:44:38 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:44:38 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:44:38 --> Helper loaded: users_helper
INFO - 2018-05-08 12:44:38 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:44:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:44:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:44:38 --> Helper loaded: form_helper
INFO - 2018-05-08 12:44:38 --> Form Validation Class Initialized
INFO - 2018-05-08 12:44:38 --> Controller Class Initialized
INFO - 2018-05-08 12:44:39 --> Model Class Initialized
INFO - 2018-05-08 12:44:39 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:44:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:44:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:44:39 --> Model Class Initialized
INFO - 2018-05-08 12:44:39 --> Model Class Initialized
INFO - 2018-05-08 12:44:39 --> Model Class Initialized
INFO - 2018-05-08 12:44:39 --> Model Class Initialized
INFO - 2018-05-08 12:44:39 --> Model Class Initialized
INFO - 2018-05-08 12:44:39 --> Model Class Initialized
INFO - 2018-05-08 12:44:39 --> Model Class Initialized
INFO - 2018-05-08 12:44:39 --> Model Class Initialized
INFO - 2018-05-08 12:44:39 --> Model Class Initialized
INFO - 2018-05-08 12:44:39 --> Model Class Initialized
INFO - 2018-05-08 12:44:39 --> Model Class Initialized
INFO - 2018-05-08 12:44:39 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:44:39 --> Model Class Initialized
INFO - 2018-05-08 12:44:39 --> Final output sent to browser
DEBUG - 2018-05-08 12:44:39 --> Total execution time: 0.1990
INFO - 2018-05-08 07:14:40 --> Config Class Initialized
INFO - 2018-05-08 07:14:40 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:14:40 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:14:40 --> Utf8 Class Initialized
INFO - 2018-05-08 07:14:40 --> URI Class Initialized
INFO - 2018-05-08 07:14:40 --> Router Class Initialized
INFO - 2018-05-08 07:14:40 --> Output Class Initialized
INFO - 2018-05-08 07:14:40 --> Security Class Initialized
DEBUG - 2018-05-08 07:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:14:40 --> Input Class Initialized
INFO - 2018-05-08 07:14:40 --> Language Class Initialized
INFO - 2018-05-08 07:14:40 --> Language Class Initialized
INFO - 2018-05-08 07:14:40 --> Config Class Initialized
INFO - 2018-05-08 07:14:40 --> Loader Class Initialized
INFO - 2018-05-08 12:44:40 --> Helper loaded: url_helper
INFO - 2018-05-08 12:44:40 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:44:40 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:44:40 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:44:40 --> Helper loaded: users_helper
INFO - 2018-05-08 12:44:40 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:44:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:44:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:44:40 --> Helper loaded: form_helper
INFO - 2018-05-08 12:44:40 --> Form Validation Class Initialized
INFO - 2018-05-08 12:44:40 --> Controller Class Initialized
INFO - 2018-05-08 12:44:40 --> Model Class Initialized
INFO - 2018-05-08 12:44:40 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:44:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:44:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:44:40 --> Model Class Initialized
INFO - 2018-05-08 12:44:40 --> Model Class Initialized
INFO - 2018-05-08 12:44:40 --> Model Class Initialized
INFO - 2018-05-08 12:44:40 --> Model Class Initialized
INFO - 2018-05-08 12:44:40 --> Model Class Initialized
INFO - 2018-05-08 12:44:40 --> Model Class Initialized
INFO - 2018-05-08 12:44:40 --> Model Class Initialized
INFO - 2018-05-08 12:44:40 --> Model Class Initialized
INFO - 2018-05-08 12:44:40 --> Model Class Initialized
INFO - 2018-05-08 12:44:40 --> Model Class Initialized
INFO - 2018-05-08 12:44:40 --> Model Class Initialized
INFO - 2018-05-08 12:44:40 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:44:40 --> Final output sent to browser
DEBUG - 2018-05-08 12:44:40 --> Total execution time: 0.1209
INFO - 2018-05-08 07:14:41 --> Config Class Initialized
INFO - 2018-05-08 07:14:41 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:14:41 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:14:41 --> Utf8 Class Initialized
INFO - 2018-05-08 07:14:41 --> URI Class Initialized
INFO - 2018-05-08 07:14:41 --> Router Class Initialized
INFO - 2018-05-08 07:14:41 --> Output Class Initialized
INFO - 2018-05-08 07:14:41 --> Security Class Initialized
DEBUG - 2018-05-08 07:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:14:41 --> Input Class Initialized
INFO - 2018-05-08 07:14:41 --> Language Class Initialized
INFO - 2018-05-08 07:14:41 --> Language Class Initialized
INFO - 2018-05-08 07:14:41 --> Config Class Initialized
INFO - 2018-05-08 07:14:41 --> Loader Class Initialized
INFO - 2018-05-08 12:44:41 --> Helper loaded: url_helper
INFO - 2018-05-08 12:44:41 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:44:41 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:44:41 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:44:41 --> Helper loaded: users_helper
INFO - 2018-05-08 12:44:41 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:44:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:44:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:44:41 --> Helper loaded: form_helper
INFO - 2018-05-08 12:44:41 --> Form Validation Class Initialized
INFO - 2018-05-08 12:44:41 --> Controller Class Initialized
INFO - 2018-05-08 12:44:41 --> Model Class Initialized
INFO - 2018-05-08 12:44:41 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:44:41 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:44:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:44:41 --> Model Class Initialized
INFO - 2018-05-08 12:44:41 --> Model Class Initialized
INFO - 2018-05-08 12:44:41 --> Model Class Initialized
INFO - 2018-05-08 12:44:41 --> Model Class Initialized
INFO - 2018-05-08 12:44:41 --> Model Class Initialized
INFO - 2018-05-08 12:44:41 --> Model Class Initialized
INFO - 2018-05-08 12:44:41 --> Model Class Initialized
INFO - 2018-05-08 12:44:41 --> Model Class Initialized
INFO - 2018-05-08 12:44:41 --> Model Class Initialized
INFO - 2018-05-08 12:44:41 --> Model Class Initialized
INFO - 2018-05-08 12:44:41 --> Model Class Initialized
INFO - 2018-05-08 12:44:41 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:44:41 --> Final output sent to browser
DEBUG - 2018-05-08 12:44:41 --> Total execution time: 0.1411
INFO - 2018-05-08 07:14:42 --> Config Class Initialized
INFO - 2018-05-08 07:14:42 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:14:42 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:14:42 --> Utf8 Class Initialized
INFO - 2018-05-08 07:14:42 --> URI Class Initialized
INFO - 2018-05-08 07:14:42 --> Router Class Initialized
INFO - 2018-05-08 07:14:42 --> Output Class Initialized
INFO - 2018-05-08 07:14:42 --> Security Class Initialized
DEBUG - 2018-05-08 07:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:14:42 --> Input Class Initialized
INFO - 2018-05-08 07:14:42 --> Language Class Initialized
INFO - 2018-05-08 07:14:42 --> Language Class Initialized
INFO - 2018-05-08 07:14:42 --> Config Class Initialized
INFO - 2018-05-08 07:14:42 --> Loader Class Initialized
INFO - 2018-05-08 12:44:42 --> Helper loaded: url_helper
INFO - 2018-05-08 12:44:42 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:44:42 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:44:42 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:44:42 --> Helper loaded: users_helper
INFO - 2018-05-08 12:44:42 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:44:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:44:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:44:42 --> Helper loaded: form_helper
INFO - 2018-05-08 12:44:42 --> Form Validation Class Initialized
INFO - 2018-05-08 12:44:42 --> Controller Class Initialized
INFO - 2018-05-08 12:44:42 --> Model Class Initialized
INFO - 2018-05-08 12:44:42 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:44:42 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:44:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:44:42 --> Model Class Initialized
INFO - 2018-05-08 12:44:42 --> Model Class Initialized
INFO - 2018-05-08 12:44:42 --> Model Class Initialized
INFO - 2018-05-08 12:44:42 --> Model Class Initialized
INFO - 2018-05-08 12:44:42 --> Model Class Initialized
INFO - 2018-05-08 12:44:42 --> Model Class Initialized
INFO - 2018-05-08 12:44:42 --> Model Class Initialized
INFO - 2018-05-08 12:44:42 --> Model Class Initialized
INFO - 2018-05-08 12:44:42 --> Model Class Initialized
INFO - 2018-05-08 12:44:42 --> Model Class Initialized
INFO - 2018-05-08 12:44:42 --> Model Class Initialized
INFO - 2018-05-08 12:44:42 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:44:42 --> Final output sent to browser
DEBUG - 2018-05-08 12:44:42 --> Total execution time: 0.1178
INFO - 2018-05-08 07:14:45 --> Config Class Initialized
INFO - 2018-05-08 07:14:45 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:14:45 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:14:45 --> Utf8 Class Initialized
INFO - 2018-05-08 07:14:45 --> URI Class Initialized
INFO - 2018-05-08 07:14:45 --> Router Class Initialized
INFO - 2018-05-08 07:14:45 --> Output Class Initialized
INFO - 2018-05-08 07:14:45 --> Security Class Initialized
DEBUG - 2018-05-08 07:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:14:45 --> Input Class Initialized
INFO - 2018-05-08 07:14:45 --> Language Class Initialized
INFO - 2018-05-08 07:14:45 --> Language Class Initialized
INFO - 2018-05-08 07:14:45 --> Config Class Initialized
INFO - 2018-05-08 07:14:45 --> Loader Class Initialized
INFO - 2018-05-08 12:44:45 --> Helper loaded: url_helper
INFO - 2018-05-08 12:44:45 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:44:45 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:44:45 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:44:45 --> Helper loaded: users_helper
INFO - 2018-05-08 12:44:45 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:44:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:44:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:44:45 --> Helper loaded: form_helper
INFO - 2018-05-08 12:44:45 --> Form Validation Class Initialized
INFO - 2018-05-08 12:44:45 --> Controller Class Initialized
INFO - 2018-05-08 12:44:45 --> Model Class Initialized
INFO - 2018-05-08 12:44:45 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:44:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:44:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:44:45 --> Model Class Initialized
INFO - 2018-05-08 12:44:45 --> Model Class Initialized
INFO - 2018-05-08 12:44:45 --> Model Class Initialized
INFO - 2018-05-08 12:44:45 --> Model Class Initialized
INFO - 2018-05-08 12:44:45 --> Final output sent to browser
DEBUG - 2018-05-08 12:44:45 --> Total execution time: 0.1238
INFO - 2018-05-08 07:14:47 --> Config Class Initialized
INFO - 2018-05-08 07:14:47 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:14:47 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:14:47 --> Utf8 Class Initialized
INFO - 2018-05-08 07:14:47 --> URI Class Initialized
INFO - 2018-05-08 07:14:47 --> Router Class Initialized
INFO - 2018-05-08 07:14:47 --> Output Class Initialized
INFO - 2018-05-08 07:14:47 --> Security Class Initialized
DEBUG - 2018-05-08 07:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:14:47 --> Input Class Initialized
INFO - 2018-05-08 07:14:47 --> Language Class Initialized
INFO - 2018-05-08 07:14:47 --> Language Class Initialized
INFO - 2018-05-08 07:14:47 --> Config Class Initialized
INFO - 2018-05-08 07:14:47 --> Loader Class Initialized
INFO - 2018-05-08 12:44:47 --> Helper loaded: url_helper
INFO - 2018-05-08 12:44:47 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:44:47 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:44:47 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:44:47 --> Helper loaded: users_helper
INFO - 2018-05-08 12:44:47 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:44:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:44:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:44:47 --> Helper loaded: form_helper
INFO - 2018-05-08 12:44:47 --> Form Validation Class Initialized
INFO - 2018-05-08 12:44:47 --> Controller Class Initialized
INFO - 2018-05-08 12:44:47 --> Model Class Initialized
INFO - 2018-05-08 12:44:47 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:44:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:44:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:44:47 --> Model Class Initialized
INFO - 2018-05-08 12:44:47 --> Model Class Initialized
INFO - 2018-05-08 12:44:47 --> Model Class Initialized
INFO - 2018-05-08 12:44:47 --> Model Class Initialized
INFO - 2018-05-08 12:44:47 --> Final output sent to browser
DEBUG - 2018-05-08 12:44:47 --> Total execution time: 0.1290
INFO - 2018-05-08 07:14:49 --> Config Class Initialized
INFO - 2018-05-08 07:14:49 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:14:49 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:14:49 --> Utf8 Class Initialized
INFO - 2018-05-08 07:14:49 --> URI Class Initialized
INFO - 2018-05-08 07:14:49 --> Router Class Initialized
INFO - 2018-05-08 07:14:49 --> Output Class Initialized
INFO - 2018-05-08 07:14:49 --> Security Class Initialized
DEBUG - 2018-05-08 07:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:14:49 --> Input Class Initialized
INFO - 2018-05-08 07:14:49 --> Language Class Initialized
INFO - 2018-05-08 07:14:49 --> Language Class Initialized
INFO - 2018-05-08 07:14:49 --> Config Class Initialized
INFO - 2018-05-08 07:14:49 --> Loader Class Initialized
INFO - 2018-05-08 12:44:49 --> Helper loaded: url_helper
INFO - 2018-05-08 12:44:49 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:44:49 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:44:49 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:44:49 --> Helper loaded: users_helper
INFO - 2018-05-08 12:44:49 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:44:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:44:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:44:49 --> Helper loaded: form_helper
INFO - 2018-05-08 12:44:49 --> Form Validation Class Initialized
INFO - 2018-05-08 12:44:49 --> Controller Class Initialized
INFO - 2018-05-08 12:44:49 --> Model Class Initialized
INFO - 2018-05-08 12:44:49 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:44:49 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:44:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:44:49 --> Model Class Initialized
INFO - 2018-05-08 12:44:49 --> Model Class Initialized
INFO - 2018-05-08 12:44:49 --> Model Class Initialized
INFO - 2018-05-08 12:44:49 --> Model Class Initialized
INFO - 2018-05-08 12:44:49 --> Model Class Initialized
INFO - 2018-05-08 12:44:49 --> Model Class Initialized
INFO - 2018-05-08 12:44:49 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:44:49 --> Final output sent to browser
DEBUG - 2018-05-08 12:44:49 --> Total execution time: 0.1287
INFO - 2018-05-08 07:14:52 --> Config Class Initialized
INFO - 2018-05-08 07:14:52 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:14:52 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:14:52 --> Utf8 Class Initialized
INFO - 2018-05-08 07:14:52 --> URI Class Initialized
INFO - 2018-05-08 07:14:52 --> Router Class Initialized
INFO - 2018-05-08 07:14:52 --> Output Class Initialized
INFO - 2018-05-08 07:14:52 --> Security Class Initialized
DEBUG - 2018-05-08 07:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:14:52 --> Input Class Initialized
INFO - 2018-05-08 07:14:52 --> Language Class Initialized
INFO - 2018-05-08 07:14:52 --> Language Class Initialized
INFO - 2018-05-08 07:14:52 --> Config Class Initialized
INFO - 2018-05-08 07:14:52 --> Loader Class Initialized
INFO - 2018-05-08 12:44:52 --> Helper loaded: url_helper
INFO - 2018-05-08 12:44:52 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:44:52 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:44:52 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:44:52 --> Helper loaded: users_helper
INFO - 2018-05-08 12:44:52 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:44:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:44:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:44:52 --> Helper loaded: form_helper
INFO - 2018-05-08 12:44:52 --> Form Validation Class Initialized
INFO - 2018-05-08 12:44:52 --> Controller Class Initialized
INFO - 2018-05-08 12:44:52 --> Model Class Initialized
INFO - 2018-05-08 12:44:52 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:44:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:44:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:44:52 --> Model Class Initialized
INFO - 2018-05-08 12:44:52 --> Model Class Initialized
INFO - 2018-05-08 12:44:52 --> Model Class Initialized
INFO - 2018-05-08 12:44:52 --> Model Class Initialized
INFO - 2018-05-08 12:44:52 --> Model Class Initialized
INFO - 2018-05-08 12:44:52 --> Model Class Initialized
INFO - 2018-05-08 12:44:52 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:44:52 --> Final output sent to browser
DEBUG - 2018-05-08 12:44:52 --> Total execution time: 0.0913
INFO - 2018-05-08 07:14:53 --> Config Class Initialized
INFO - 2018-05-08 07:14:53 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:14:53 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:14:53 --> Utf8 Class Initialized
INFO - 2018-05-08 07:14:53 --> URI Class Initialized
INFO - 2018-05-08 07:14:53 --> Router Class Initialized
INFO - 2018-05-08 07:14:53 --> Output Class Initialized
INFO - 2018-05-08 07:14:53 --> Security Class Initialized
DEBUG - 2018-05-08 07:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:14:53 --> Input Class Initialized
INFO - 2018-05-08 07:14:53 --> Language Class Initialized
INFO - 2018-05-08 07:14:53 --> Language Class Initialized
INFO - 2018-05-08 07:14:53 --> Config Class Initialized
INFO - 2018-05-08 07:14:53 --> Loader Class Initialized
INFO - 2018-05-08 12:44:53 --> Helper loaded: url_helper
INFO - 2018-05-08 12:44:53 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:44:53 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:44:53 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:44:53 --> Helper loaded: users_helper
INFO - 2018-05-08 12:44:53 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:44:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:44:53 --> Helper loaded: form_helper
INFO - 2018-05-08 12:44:53 --> Form Validation Class Initialized
INFO - 2018-05-08 12:44:53 --> Controller Class Initialized
INFO - 2018-05-08 12:44:53 --> Model Class Initialized
INFO - 2018-05-08 12:44:53 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:44:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:44:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:44:53 --> Model Class Initialized
INFO - 2018-05-08 12:44:53 --> Model Class Initialized
INFO - 2018-05-08 12:44:53 --> Model Class Initialized
INFO - 2018-05-08 12:44:53 --> Model Class Initialized
INFO - 2018-05-08 12:44:53 --> Model Class Initialized
INFO - 2018-05-08 12:44:53 --> Model Class Initialized
INFO - 2018-05-08 12:44:53 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:44:53 --> Final output sent to browser
DEBUG - 2018-05-08 12:44:53 --> Total execution time: 0.1348
INFO - 2018-05-08 07:19:08 --> Config Class Initialized
INFO - 2018-05-08 07:19:08 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:19:08 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:19:08 --> Utf8 Class Initialized
INFO - 2018-05-08 07:19:08 --> URI Class Initialized
INFO - 2018-05-08 07:19:08 --> Router Class Initialized
INFO - 2018-05-08 07:19:08 --> Output Class Initialized
INFO - 2018-05-08 07:19:08 --> Security Class Initialized
DEBUG - 2018-05-08 07:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:19:08 --> Input Class Initialized
INFO - 2018-05-08 07:19:08 --> Language Class Initialized
INFO - 2018-05-08 07:19:08 --> Language Class Initialized
INFO - 2018-05-08 07:19:08 --> Config Class Initialized
INFO - 2018-05-08 07:19:08 --> Loader Class Initialized
INFO - 2018-05-08 12:49:08 --> Helper loaded: url_helper
INFO - 2018-05-08 12:49:08 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:49:08 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:49:08 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:49:08 --> Helper loaded: users_helper
INFO - 2018-05-08 12:49:08 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:49:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:49:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:49:08 --> Helper loaded: form_helper
INFO - 2018-05-08 12:49:08 --> Form Validation Class Initialized
INFO - 2018-05-08 12:49:08 --> Controller Class Initialized
INFO - 2018-05-08 12:49:09 --> Model Class Initialized
INFO - 2018-05-08 12:49:09 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:49:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:49:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:49:09 --> Model Class Initialized
INFO - 2018-05-08 12:49:09 --> Model Class Initialized
INFO - 2018-05-08 12:49:09 --> Model Class Initialized
INFO - 2018-05-08 12:49:09 --> Model Class Initialized
INFO - 2018-05-08 12:49:09 --> Model Class Initialized
INFO - 2018-05-08 12:49:09 --> Model Class Initialized
INFO - 2018-05-08 12:49:09 --> Model Class Initialized
INFO - 2018-05-08 12:49:09 --> Model Class Initialized
INFO - 2018-05-08 12:49:09 --> Model Class Initialized
INFO - 2018-05-08 12:49:09 --> Model Class Initialized
INFO - 2018-05-08 12:49:09 --> Model Class Initialized
INFO - 2018-05-08 12:49:09 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:49:09 --> Model Class Initialized
INFO - 2018-05-08 12:49:09 --> Final output sent to browser
DEBUG - 2018-05-08 12:49:09 --> Total execution time: 0.1661
INFO - 2018-05-08 07:19:09 --> Config Class Initialized
INFO - 2018-05-08 07:19:09 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:19:09 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:19:09 --> Utf8 Class Initialized
INFO - 2018-05-08 07:19:09 --> URI Class Initialized
INFO - 2018-05-08 07:19:09 --> Router Class Initialized
INFO - 2018-05-08 07:19:09 --> Output Class Initialized
INFO - 2018-05-08 07:19:09 --> Security Class Initialized
DEBUG - 2018-05-08 07:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:19:09 --> Input Class Initialized
INFO - 2018-05-08 07:19:09 --> Language Class Initialized
INFO - 2018-05-08 07:19:09 --> Language Class Initialized
INFO - 2018-05-08 07:19:09 --> Config Class Initialized
INFO - 2018-05-08 07:19:09 --> Loader Class Initialized
INFO - 2018-05-08 12:49:09 --> Helper loaded: url_helper
INFO - 2018-05-08 12:49:09 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:49:09 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:49:09 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:49:09 --> Helper loaded: users_helper
INFO - 2018-05-08 12:49:09 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:49:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:49:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:49:09 --> Helper loaded: form_helper
INFO - 2018-05-08 12:49:09 --> Form Validation Class Initialized
INFO - 2018-05-08 12:49:09 --> Controller Class Initialized
INFO - 2018-05-08 12:49:09 --> Model Class Initialized
INFO - 2018-05-08 12:49:09 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:49:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:49:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:49:09 --> Model Class Initialized
INFO - 2018-05-08 12:49:09 --> Model Class Initialized
INFO - 2018-05-08 12:49:09 --> Model Class Initialized
INFO - 2018-05-08 12:49:09 --> Model Class Initialized
INFO - 2018-05-08 12:49:09 --> Model Class Initialized
INFO - 2018-05-08 12:49:09 --> Model Class Initialized
INFO - 2018-05-08 12:49:09 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:49:09 --> Model Class Initialized
INFO - 2018-05-08 12:49:09 --> Final output sent to browser
DEBUG - 2018-05-08 12:49:09 --> Total execution time: 0.1398
INFO - 2018-05-08 07:19:14 --> Config Class Initialized
INFO - 2018-05-08 07:19:14 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:19:14 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:19:14 --> Utf8 Class Initialized
INFO - 2018-05-08 07:19:14 --> URI Class Initialized
INFO - 2018-05-08 07:19:14 --> Router Class Initialized
INFO - 2018-05-08 07:19:14 --> Output Class Initialized
INFO - 2018-05-08 07:19:14 --> Security Class Initialized
DEBUG - 2018-05-08 07:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:19:14 --> Input Class Initialized
INFO - 2018-05-08 07:19:14 --> Language Class Initialized
INFO - 2018-05-08 07:19:14 --> Language Class Initialized
INFO - 2018-05-08 07:19:14 --> Config Class Initialized
INFO - 2018-05-08 07:19:14 --> Loader Class Initialized
INFO - 2018-05-08 12:49:14 --> Helper loaded: url_helper
INFO - 2018-05-08 12:49:14 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:49:14 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:49:14 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:49:14 --> Helper loaded: users_helper
INFO - 2018-05-08 12:49:14 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:49:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:49:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:49:14 --> Helper loaded: form_helper
INFO - 2018-05-08 12:49:14 --> Form Validation Class Initialized
INFO - 2018-05-08 12:49:14 --> Controller Class Initialized
INFO - 2018-05-08 12:49:14 --> Model Class Initialized
INFO - 2018-05-08 12:49:14 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:49:14 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:49:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:49:14 --> Model Class Initialized
INFO - 2018-05-08 12:49:14 --> Model Class Initialized
INFO - 2018-05-08 12:49:14 --> Model Class Initialized
INFO - 2018-05-08 12:49:14 --> Model Class Initialized
INFO - 2018-05-08 12:49:14 --> Model Class Initialized
INFO - 2018-05-08 12:49:14 --> Model Class Initialized
INFO - 2018-05-08 12:49:14 --> Model Class Initialized
INFO - 2018-05-08 12:49:14 --> Model Class Initialized
INFO - 2018-05-08 12:49:14 --> Model Class Initialized
INFO - 2018-05-08 12:49:14 --> Model Class Initialized
INFO - 2018-05-08 12:49:14 --> Model Class Initialized
INFO - 2018-05-08 12:49:14 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:49:14 --> Model Class Initialized
INFO - 2018-05-08 12:49:14 --> Final output sent to browser
DEBUG - 2018-05-08 12:49:14 --> Total execution time: 0.1503
INFO - 2018-05-08 07:19:21 --> Config Class Initialized
INFO - 2018-05-08 07:19:21 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:19:21 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:19:21 --> Utf8 Class Initialized
INFO - 2018-05-08 07:19:21 --> URI Class Initialized
INFO - 2018-05-08 07:19:21 --> Router Class Initialized
INFO - 2018-05-08 07:19:21 --> Output Class Initialized
INFO - 2018-05-08 07:19:21 --> Security Class Initialized
DEBUG - 2018-05-08 07:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:19:21 --> Input Class Initialized
INFO - 2018-05-08 07:19:21 --> Language Class Initialized
INFO - 2018-05-08 07:19:21 --> Language Class Initialized
INFO - 2018-05-08 07:19:21 --> Config Class Initialized
INFO - 2018-05-08 07:19:21 --> Loader Class Initialized
INFO - 2018-05-08 12:49:21 --> Helper loaded: url_helper
INFO - 2018-05-08 12:49:21 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:49:21 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:49:21 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:49:21 --> Helper loaded: users_helper
INFO - 2018-05-08 12:49:21 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:49:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:49:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:49:21 --> Helper loaded: form_helper
INFO - 2018-05-08 12:49:21 --> Form Validation Class Initialized
INFO - 2018-05-08 12:49:21 --> Controller Class Initialized
INFO - 2018-05-08 12:49:21 --> Model Class Initialized
INFO - 2018-05-08 12:49:21 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:49:21 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:49:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:49:21 --> Model Class Initialized
INFO - 2018-05-08 12:49:21 --> Model Class Initialized
INFO - 2018-05-08 12:49:21 --> Model Class Initialized
INFO - 2018-05-08 12:49:21 --> Model Class Initialized
INFO - 2018-05-08 12:49:21 --> Model Class Initialized
INFO - 2018-05-08 12:49:21 --> Model Class Initialized
INFO - 2018-05-08 12:49:21 --> Model Class Initialized
INFO - 2018-05-08 12:49:21 --> Model Class Initialized
INFO - 2018-05-08 12:49:21 --> Model Class Initialized
INFO - 2018-05-08 12:49:21 --> Model Class Initialized
INFO - 2018-05-08 12:49:21 --> Model Class Initialized
INFO - 2018-05-08 12:49:21 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:49:21 --> Model Class Initialized
INFO - 2018-05-08 12:49:21 --> Final output sent to browser
DEBUG - 2018-05-08 12:49:21 --> Total execution time: 0.1714
INFO - 2018-05-08 07:19:23 --> Config Class Initialized
INFO - 2018-05-08 07:19:23 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:19:23 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:19:23 --> Utf8 Class Initialized
INFO - 2018-05-08 07:19:23 --> URI Class Initialized
INFO - 2018-05-08 07:19:23 --> Router Class Initialized
INFO - 2018-05-08 07:19:23 --> Output Class Initialized
INFO - 2018-05-08 07:19:23 --> Security Class Initialized
DEBUG - 2018-05-08 07:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:19:23 --> Input Class Initialized
INFO - 2018-05-08 07:19:23 --> Language Class Initialized
INFO - 2018-05-08 07:19:23 --> Language Class Initialized
INFO - 2018-05-08 07:19:23 --> Config Class Initialized
INFO - 2018-05-08 07:19:23 --> Loader Class Initialized
INFO - 2018-05-08 12:49:23 --> Helper loaded: url_helper
INFO - 2018-05-08 12:49:23 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:49:23 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:49:23 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:49:23 --> Helper loaded: users_helper
INFO - 2018-05-08 12:49:23 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:49:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:49:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:49:23 --> Helper loaded: form_helper
INFO - 2018-05-08 12:49:23 --> Form Validation Class Initialized
INFO - 2018-05-08 12:49:23 --> Controller Class Initialized
INFO - 2018-05-08 12:49:23 --> Model Class Initialized
INFO - 2018-05-08 12:49:23 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:49:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:49:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:49:23 --> Model Class Initialized
INFO - 2018-05-08 12:49:23 --> Model Class Initialized
INFO - 2018-05-08 12:49:23 --> Model Class Initialized
INFO - 2018-05-08 12:49:23 --> Model Class Initialized
INFO - 2018-05-08 12:49:23 --> Model Class Initialized
INFO - 2018-05-08 12:49:23 --> Model Class Initialized
INFO - 2018-05-08 12:49:23 --> Model Class Initialized
INFO - 2018-05-08 12:49:23 --> Model Class Initialized
INFO - 2018-05-08 12:49:23 --> Model Class Initialized
INFO - 2018-05-08 12:49:23 --> Model Class Initialized
INFO - 2018-05-08 12:49:23 --> Model Class Initialized
INFO - 2018-05-08 12:49:23 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:49:23 --> Final output sent to browser
DEBUG - 2018-05-08 12:49:23 --> Total execution time: 0.1581
INFO - 2018-05-08 07:19:24 --> Config Class Initialized
INFO - 2018-05-08 07:19:24 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:19:24 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:19:24 --> Utf8 Class Initialized
INFO - 2018-05-08 07:19:24 --> URI Class Initialized
INFO - 2018-05-08 07:19:24 --> Router Class Initialized
INFO - 2018-05-08 07:19:24 --> Output Class Initialized
INFO - 2018-05-08 07:19:24 --> Security Class Initialized
DEBUG - 2018-05-08 07:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:19:24 --> Input Class Initialized
INFO - 2018-05-08 07:19:24 --> Language Class Initialized
INFO - 2018-05-08 07:19:24 --> Language Class Initialized
INFO - 2018-05-08 07:19:24 --> Config Class Initialized
INFO - 2018-05-08 07:19:24 --> Loader Class Initialized
INFO - 2018-05-08 12:49:24 --> Helper loaded: url_helper
INFO - 2018-05-08 12:49:24 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:49:24 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:49:24 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:49:24 --> Helper loaded: users_helper
INFO - 2018-05-08 12:49:25 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:49:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:49:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:49:25 --> Helper loaded: form_helper
INFO - 2018-05-08 12:49:25 --> Form Validation Class Initialized
INFO - 2018-05-08 12:49:25 --> Controller Class Initialized
INFO - 2018-05-08 12:49:25 --> Model Class Initialized
INFO - 2018-05-08 12:49:25 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:49:25 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:49:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:49:25 --> Model Class Initialized
INFO - 2018-05-08 12:49:25 --> Model Class Initialized
INFO - 2018-05-08 12:49:25 --> Model Class Initialized
INFO - 2018-05-08 12:49:25 --> Model Class Initialized
INFO - 2018-05-08 12:49:25 --> Model Class Initialized
INFO - 2018-05-08 12:49:25 --> Model Class Initialized
INFO - 2018-05-08 12:49:25 --> Model Class Initialized
INFO - 2018-05-08 12:49:25 --> Model Class Initialized
INFO - 2018-05-08 12:49:25 --> Model Class Initialized
INFO - 2018-05-08 12:49:25 --> Model Class Initialized
INFO - 2018-05-08 12:49:25 --> Model Class Initialized
INFO - 2018-05-08 12:49:25 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:49:25 --> Final output sent to browser
DEBUG - 2018-05-08 12:49:25 --> Total execution time: 0.1252
INFO - 2018-05-08 07:19:26 --> Config Class Initialized
INFO - 2018-05-08 07:19:26 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:19:26 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:19:26 --> Utf8 Class Initialized
INFO - 2018-05-08 07:19:26 --> URI Class Initialized
INFO - 2018-05-08 07:19:26 --> Router Class Initialized
INFO - 2018-05-08 07:19:26 --> Output Class Initialized
INFO - 2018-05-08 07:19:26 --> Security Class Initialized
DEBUG - 2018-05-08 07:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:19:26 --> Input Class Initialized
INFO - 2018-05-08 07:19:26 --> Language Class Initialized
INFO - 2018-05-08 07:19:26 --> Language Class Initialized
INFO - 2018-05-08 07:19:26 --> Config Class Initialized
INFO - 2018-05-08 07:19:26 --> Loader Class Initialized
INFO - 2018-05-08 12:49:26 --> Helper loaded: url_helper
INFO - 2018-05-08 12:49:26 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:49:26 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:49:26 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:49:26 --> Helper loaded: users_helper
INFO - 2018-05-08 12:49:26 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:49:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:49:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:49:26 --> Helper loaded: form_helper
INFO - 2018-05-08 12:49:26 --> Form Validation Class Initialized
INFO - 2018-05-08 12:49:26 --> Controller Class Initialized
INFO - 2018-05-08 12:49:26 --> Model Class Initialized
INFO - 2018-05-08 12:49:26 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:49:26 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:49:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:49:26 --> Model Class Initialized
INFO - 2018-05-08 12:49:26 --> Model Class Initialized
INFO - 2018-05-08 12:49:26 --> Model Class Initialized
INFO - 2018-05-08 12:49:26 --> Model Class Initialized
INFO - 2018-05-08 12:49:26 --> Model Class Initialized
INFO - 2018-05-08 12:49:26 --> Model Class Initialized
INFO - 2018-05-08 12:49:26 --> Model Class Initialized
INFO - 2018-05-08 12:49:26 --> Model Class Initialized
INFO - 2018-05-08 12:49:26 --> Model Class Initialized
INFO - 2018-05-08 12:49:26 --> Model Class Initialized
INFO - 2018-05-08 12:49:26 --> Model Class Initialized
INFO - 2018-05-08 12:49:26 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:49:26 --> Final output sent to browser
DEBUG - 2018-05-08 12:49:26 --> Total execution time: 0.1183
INFO - 2018-05-08 07:19:28 --> Config Class Initialized
INFO - 2018-05-08 07:19:28 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:19:28 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:19:28 --> Utf8 Class Initialized
INFO - 2018-05-08 07:19:28 --> URI Class Initialized
INFO - 2018-05-08 07:19:28 --> Router Class Initialized
INFO - 2018-05-08 07:19:28 --> Output Class Initialized
INFO - 2018-05-08 07:19:28 --> Security Class Initialized
DEBUG - 2018-05-08 07:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:19:28 --> Input Class Initialized
INFO - 2018-05-08 07:19:28 --> Language Class Initialized
INFO - 2018-05-08 07:19:28 --> Language Class Initialized
INFO - 2018-05-08 07:19:28 --> Config Class Initialized
INFO - 2018-05-08 07:19:28 --> Loader Class Initialized
INFO - 2018-05-08 12:49:28 --> Helper loaded: url_helper
INFO - 2018-05-08 12:49:28 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:49:28 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:49:28 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:49:28 --> Helper loaded: users_helper
INFO - 2018-05-08 12:49:28 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:49:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:49:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:49:28 --> Helper loaded: form_helper
INFO - 2018-05-08 12:49:28 --> Form Validation Class Initialized
INFO - 2018-05-08 12:49:28 --> Controller Class Initialized
INFO - 2018-05-08 12:49:28 --> Model Class Initialized
INFO - 2018-05-08 12:49:28 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:49:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:49:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:49:28 --> Model Class Initialized
INFO - 2018-05-08 12:49:28 --> Model Class Initialized
INFO - 2018-05-08 12:49:28 --> Model Class Initialized
INFO - 2018-05-08 12:49:28 --> Model Class Initialized
INFO - 2018-05-08 12:49:28 --> Model Class Initialized
INFO - 2018-05-08 12:49:28 --> Model Class Initialized
ERROR - 2018-05-08 12:49:28 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/FilterOption.php 79
INFO - 2018-05-08 12:49:28 --> Final output sent to browser
DEBUG - 2018-05-08 12:49:28 --> Total execution time: 0.1052
INFO - 2018-05-08 07:19:28 --> Config Class Initialized
INFO - 2018-05-08 07:19:28 --> Hooks Class Initialized
INFO - 2018-05-08 07:19:28 --> Config Class Initialized
DEBUG - 2018-05-08 07:19:28 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:19:28 --> Utf8 Class Initialized
INFO - 2018-05-08 07:19:28 --> Hooks Class Initialized
INFO - 2018-05-08 07:19:28 --> URI Class Initialized
DEBUG - 2018-05-08 07:19:29 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:19:29 --> Utf8 Class Initialized
INFO - 2018-05-08 07:19:29 --> Router Class Initialized
INFO - 2018-05-08 07:19:29 --> URI Class Initialized
INFO - 2018-05-08 07:19:29 --> Output Class Initialized
INFO - 2018-05-08 07:19:29 --> Config Class Initialized
INFO - 2018-05-08 07:19:29 --> Hooks Class Initialized
INFO - 2018-05-08 07:19:29 --> Security Class Initialized
DEBUG - 2018-05-08 07:19:29 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:19:29 --> Utf8 Class Initialized
DEBUG - 2018-05-08 07:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:19:29 --> Input Class Initialized
INFO - 2018-05-08 07:19:29 --> Language Class Initialized
INFO - 2018-05-08 07:19:29 --> URI Class Initialized
INFO - 2018-05-08 07:19:29 --> Router Class Initialized
INFO - 2018-05-08 07:19:29 --> Output Class Initialized
INFO - 2018-05-08 07:19:29 --> Router Class Initialized
INFO - 2018-05-08 07:19:29 --> Security Class Initialized
INFO - 2018-05-08 07:19:29 --> Output Class Initialized
INFO - 2018-05-08 07:19:29 --> Security Class Initialized
DEBUG - 2018-05-08 07:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:19:29 --> Input Class Initialized
DEBUG - 2018-05-08 07:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:19:29 --> Input Class Initialized
INFO - 2018-05-08 07:19:29 --> Language Class Initialized
INFO - 2018-05-08 07:19:29 --> Language Class Initialized
INFO - 2018-05-08 07:19:29 --> Language Class Initialized
INFO - 2018-05-08 07:19:29 --> Config Class Initialized
INFO - 2018-05-08 07:19:29 --> Loader Class Initialized
INFO - 2018-05-08 12:49:29 --> Helper loaded: url_helper
INFO - 2018-05-08 12:49:29 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:49:29 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:49:29 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:49:29 --> Helper loaded: users_helper
INFO - 2018-05-08 07:19:29 --> Language Class Initialized
INFO - 2018-05-08 07:19:29 --> Config Class Initialized
INFO - 2018-05-08 07:19:29 --> Loader Class Initialized
INFO - 2018-05-08 12:49:29 --> Helper loaded: url_helper
INFO - 2018-05-08 12:49:29 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:49:29 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:49:29 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:49:29 --> Helper loaded: users_helper
INFO - 2018-05-08 07:19:29 --> Language Class Initialized
INFO - 2018-05-08 07:19:29 --> Config Class Initialized
INFO - 2018-05-08 07:19:29 --> Loader Class Initialized
INFO - 2018-05-08 12:49:29 --> Helper loaded: url_helper
INFO - 2018-05-08 12:49:29 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:49:29 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:49:29 --> Database Driver Class Initialized
INFO - 2018-05-08 12:49:29 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:49:29 --> Helper loaded: users_helper
INFO - 2018-05-08 12:49:29 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:49:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:49:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-05-08 12:49:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:49:29 --> Database Driver Class Initialized
INFO - 2018-05-08 12:49:29 --> Helper loaded: form_helper
INFO - 2018-05-08 12:49:29 --> Form Validation Class Initialized
INFO - 2018-05-08 12:49:29 --> Controller Class Initialized
INFO - 2018-05-08 12:49:29 --> Model Class Initialized
DEBUG - 2018-05-08 12:49:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:49:29 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:49:29 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:49:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:49:29 --> Model Class Initialized
INFO - 2018-05-08 12:49:29 --> Model Class Initialized
INFO - 2018-05-08 12:49:29 --> Model Class Initialized
INFO - 2018-05-08 12:49:29 --> Model Class Initialized
INFO - 2018-05-08 12:49:29 --> Model Class Initialized
INFO - 2018-05-08 12:49:29 --> Model Class Initialized
ERROR - 2018-05-08 12:49:29 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/FilterOption.php 349
ERROR - 2018-05-08 12:49:29 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/FilterOption.php 389
ERROR - 2018-05-08 12:49:29 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/FilterOption.php 427
INFO - 2018-05-08 12:49:29 --> Final output sent to browser
DEBUG - 2018-05-08 12:49:29 --> Total execution time: 0.1030
INFO - 2018-05-08 12:49:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:49:29 --> Helper loaded: form_helper
INFO - 2018-05-08 12:49:29 --> Form Validation Class Initialized
INFO - 2018-05-08 12:49:29 --> Controller Class Initialized
INFO - 2018-05-08 07:19:29 --> Config Class Initialized
INFO - 2018-05-08 07:19:29 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:19:29 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:19:29 --> Utf8 Class Initialized
INFO - 2018-05-08 07:19:29 --> URI Class Initialized
INFO - 2018-05-08 12:49:29 --> Model Class Initialized
INFO - 2018-05-08 12:49:29 --> Helper loaded: inflector_helper
INFO - 2018-05-08 07:19:29 --> Router Class Initialized
INFO - 2018-05-08 07:19:29 --> Output Class Initialized
DEBUG - 2018-05-08 12:49:29 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 07:19:29 --> Security Class Initialized
INFO - 2018-05-08 12:49:29 --> Language file loaded: language/english/rest_controller_lang.php
DEBUG - 2018-05-08 07:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:19:29 --> Input Class Initialized
INFO - 2018-05-08 07:19:29 --> Language Class Initialized
INFO - 2018-05-08 12:49:29 --> Model Class Initialized
INFO - 2018-05-08 12:49:29 --> Model Class Initialized
INFO - 2018-05-08 12:49:29 --> Model Class Initialized
INFO - 2018-05-08 12:49:29 --> Model Class Initialized
INFO - 2018-05-08 12:49:29 --> Model Class Initialized
INFO - 2018-05-08 12:49:29 --> Model Class Initialized
ERROR - 2018-05-08 12:49:29 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/FilterOption.php 289
INFO - 2018-05-08 12:49:29 --> Final output sent to browser
DEBUG - 2018-05-08 12:49:29 --> Total execution time: 0.1769
INFO - 2018-05-08 12:49:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 07:19:29 --> Language Class Initialized
INFO - 2018-05-08 07:19:29 --> Config Class Initialized
INFO - 2018-05-08 07:19:29 --> Loader Class Initialized
INFO - 2018-05-08 12:49:29 --> Helper loaded: form_helper
INFO - 2018-05-08 12:49:29 --> Form Validation Class Initialized
INFO - 2018-05-08 12:49:29 --> Controller Class Initialized
INFO - 2018-05-08 12:49:29 --> Helper loaded: url_helper
INFO - 2018-05-08 12:49:29 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:49:29 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:49:29 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:49:29 --> Helper loaded: users_helper
INFO - 2018-05-08 12:49:29 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:49:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:49:29 --> Model Class Initialized
INFO - 2018-05-08 12:49:29 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:49:29 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:49:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:49:29 --> Model Class Initialized
INFO - 2018-05-08 12:49:29 --> Model Class Initialized
INFO - 2018-05-08 12:49:29 --> Model Class Initialized
INFO - 2018-05-08 12:49:29 --> Model Class Initialized
INFO - 2018-05-08 12:49:29 --> Model Class Initialized
INFO - 2018-05-08 12:49:29 --> Model Class Initialized
ERROR - 2018-05-08 12:49:29 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/FilterOption.php 147
ERROR - 2018-05-08 12:49:29 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/FilterOption.php 189
ERROR - 2018-05-08 12:49:29 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/FilterOption.php 227
INFO - 2018-05-08 12:49:29 --> Final output sent to browser
DEBUG - 2018-05-08 12:49:29 --> Total execution time: 0.2319
INFO - 2018-05-08 12:49:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:49:29 --> Helper loaded: form_helper
INFO - 2018-05-08 12:49:29 --> Form Validation Class Initialized
INFO - 2018-05-08 12:49:29 --> Controller Class Initialized
INFO - 2018-05-08 12:49:29 --> Model Class Initialized
INFO - 2018-05-08 12:49:29 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:49:29 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:49:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:49:29 --> Model Class Initialized
INFO - 2018-05-08 12:49:29 --> Model Class Initialized
INFO - 2018-05-08 12:49:29 --> Model Class Initialized
INFO - 2018-05-08 12:49:29 --> Model Class Initialized
INFO - 2018-05-08 12:49:29 --> Model Class Initialized
INFO - 2018-05-08 12:49:29 --> Model Class Initialized
ERROR - 2018-05-08 12:49:29 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/FilterOption.php 625
ERROR - 2018-05-08 12:49:29 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/FilterOption.php 625
INFO - 2018-05-08 12:49:29 --> Final output sent to browser
DEBUG - 2018-05-08 12:49:29 --> Total execution time: 0.1318
INFO - 2018-05-08 07:19:32 --> Config Class Initialized
INFO - 2018-05-08 07:19:32 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:19:32 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:19:32 --> Utf8 Class Initialized
INFO - 2018-05-08 07:19:32 --> URI Class Initialized
INFO - 2018-05-08 07:19:32 --> Router Class Initialized
INFO - 2018-05-08 07:19:32 --> Output Class Initialized
INFO - 2018-05-08 07:19:32 --> Security Class Initialized
DEBUG - 2018-05-08 07:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:19:32 --> Input Class Initialized
INFO - 2018-05-08 07:19:32 --> Language Class Initialized
INFO - 2018-05-08 07:19:32 --> Language Class Initialized
INFO - 2018-05-08 07:19:32 --> Config Class Initialized
INFO - 2018-05-08 07:19:32 --> Loader Class Initialized
INFO - 2018-05-08 12:49:32 --> Helper loaded: url_helper
INFO - 2018-05-08 12:49:32 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:49:32 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:49:32 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:49:32 --> Helper loaded: users_helper
INFO - 2018-05-08 12:49:32 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:49:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:49:32 --> Helper loaded: form_helper
INFO - 2018-05-08 12:49:32 --> Form Validation Class Initialized
INFO - 2018-05-08 12:49:32 --> Controller Class Initialized
INFO - 2018-05-08 12:49:32 --> Model Class Initialized
INFO - 2018-05-08 12:49:32 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:49:32 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:49:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:49:32 --> Model Class Initialized
INFO - 2018-05-08 12:49:32 --> Model Class Initialized
INFO - 2018-05-08 12:49:32 --> Model Class Initialized
INFO - 2018-05-08 12:49:32 --> Model Class Initialized
INFO - 2018-05-08 12:49:32 --> Final output sent to browser
DEBUG - 2018-05-08 12:49:32 --> Total execution time: 0.1002
INFO - 2018-05-08 07:19:33 --> Config Class Initialized
INFO - 2018-05-08 07:19:33 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:19:33 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:19:33 --> Utf8 Class Initialized
INFO - 2018-05-08 07:19:33 --> URI Class Initialized
INFO - 2018-05-08 07:19:33 --> Router Class Initialized
INFO - 2018-05-08 07:19:33 --> Output Class Initialized
INFO - 2018-05-08 07:19:33 --> Security Class Initialized
DEBUG - 2018-05-08 07:19:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:19:33 --> Input Class Initialized
INFO - 2018-05-08 07:19:33 --> Language Class Initialized
INFO - 2018-05-08 07:19:33 --> Language Class Initialized
INFO - 2018-05-08 07:19:33 --> Config Class Initialized
INFO - 2018-05-08 07:19:33 --> Loader Class Initialized
INFO - 2018-05-08 12:49:33 --> Helper loaded: url_helper
INFO - 2018-05-08 12:49:33 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:49:33 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:49:33 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:49:33 --> Helper loaded: users_helper
INFO - 2018-05-08 12:49:33 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:49:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:49:33 --> Helper loaded: form_helper
INFO - 2018-05-08 12:49:33 --> Form Validation Class Initialized
INFO - 2018-05-08 12:49:33 --> Controller Class Initialized
INFO - 2018-05-08 12:49:33 --> Model Class Initialized
INFO - 2018-05-08 12:49:33 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:49:33 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:49:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:49:33 --> Model Class Initialized
INFO - 2018-05-08 12:49:33 --> Model Class Initialized
INFO - 2018-05-08 12:49:33 --> Model Class Initialized
INFO - 2018-05-08 12:49:33 --> Model Class Initialized
INFO - 2018-05-08 12:49:33 --> Final output sent to browser
DEBUG - 2018-05-08 12:49:33 --> Total execution time: 0.0992
INFO - 2018-05-08 07:19:40 --> Config Class Initialized
INFO - 2018-05-08 07:19:40 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:19:40 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:19:40 --> Utf8 Class Initialized
INFO - 2018-05-08 07:19:40 --> URI Class Initialized
INFO - 2018-05-08 07:19:40 --> Router Class Initialized
INFO - 2018-05-08 07:19:40 --> Output Class Initialized
INFO - 2018-05-08 07:19:40 --> Security Class Initialized
DEBUG - 2018-05-08 07:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:19:40 --> Input Class Initialized
INFO - 2018-05-08 07:19:40 --> Language Class Initialized
INFO - 2018-05-08 07:19:40 --> Language Class Initialized
INFO - 2018-05-08 07:19:40 --> Config Class Initialized
INFO - 2018-05-08 07:19:40 --> Loader Class Initialized
INFO - 2018-05-08 12:49:40 --> Helper loaded: url_helper
INFO - 2018-05-08 12:49:40 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:49:40 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:49:40 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:49:40 --> Helper loaded: users_helper
INFO - 2018-05-08 12:49:40 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:49:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:49:40 --> Helper loaded: form_helper
INFO - 2018-05-08 12:49:40 --> Form Validation Class Initialized
INFO - 2018-05-08 12:49:40 --> Controller Class Initialized
INFO - 2018-05-08 12:49:40 --> Model Class Initialized
INFO - 2018-05-08 12:49:40 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:49:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:49:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:49:40 --> Model Class Initialized
INFO - 2018-05-08 12:49:40 --> Model Class Initialized
INFO - 2018-05-08 12:49:40 --> Model Class Initialized
INFO - 2018-05-08 12:49:40 --> Model Class Initialized
INFO - 2018-05-08 12:49:40 --> Final output sent to browser
DEBUG - 2018-05-08 12:49:40 --> Total execution time: 0.0962
INFO - 2018-05-08 07:19:43 --> Config Class Initialized
INFO - 2018-05-08 07:19:43 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:19:43 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:19:43 --> Utf8 Class Initialized
INFO - 2018-05-08 07:19:43 --> URI Class Initialized
INFO - 2018-05-08 07:19:43 --> Router Class Initialized
INFO - 2018-05-08 07:19:43 --> Output Class Initialized
INFO - 2018-05-08 07:19:43 --> Security Class Initialized
DEBUG - 2018-05-08 07:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:19:43 --> Input Class Initialized
INFO - 2018-05-08 07:19:43 --> Language Class Initialized
INFO - 2018-05-08 07:19:43 --> Language Class Initialized
INFO - 2018-05-08 07:19:43 --> Config Class Initialized
INFO - 2018-05-08 07:19:43 --> Loader Class Initialized
INFO - 2018-05-08 12:49:43 --> Helper loaded: url_helper
INFO - 2018-05-08 12:49:43 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:49:43 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:49:43 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:49:43 --> Helper loaded: users_helper
INFO - 2018-05-08 12:49:43 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:49:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:49:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:49:43 --> Helper loaded: form_helper
INFO - 2018-05-08 12:49:43 --> Form Validation Class Initialized
INFO - 2018-05-08 12:49:43 --> Controller Class Initialized
INFO - 2018-05-08 12:49:43 --> Model Class Initialized
INFO - 2018-05-08 12:49:43 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:49:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:49:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:49:43 --> Model Class Initialized
INFO - 2018-05-08 12:49:43 --> Model Class Initialized
INFO - 2018-05-08 12:49:43 --> Model Class Initialized
INFO - 2018-05-08 12:49:43 --> Model Class Initialized
INFO - 2018-05-08 12:49:43 --> Final output sent to browser
DEBUG - 2018-05-08 12:49:43 --> Total execution time: 0.1821
INFO - 2018-05-08 07:19:51 --> Config Class Initialized
INFO - 2018-05-08 07:19:51 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:19:51 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:19:51 --> Utf8 Class Initialized
INFO - 2018-05-08 07:19:51 --> URI Class Initialized
INFO - 2018-05-08 07:19:51 --> Config Class Initialized
INFO - 2018-05-08 07:19:51 --> Hooks Class Initialized
INFO - 2018-05-08 07:19:51 --> Router Class Initialized
DEBUG - 2018-05-08 07:19:51 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:19:51 --> Utf8 Class Initialized
INFO - 2018-05-08 07:19:51 --> Output Class Initialized
INFO - 2018-05-08 07:19:51 --> URI Class Initialized
INFO - 2018-05-08 07:19:51 --> Security Class Initialized
DEBUG - 2018-05-08 07:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:19:51 --> Router Class Initialized
INFO - 2018-05-08 07:19:51 --> Input Class Initialized
INFO - 2018-05-08 07:19:51 --> Language Class Initialized
INFO - 2018-05-08 07:19:51 --> Output Class Initialized
INFO - 2018-05-08 07:19:51 --> Security Class Initialized
DEBUG - 2018-05-08 07:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:19:51 --> Input Class Initialized
INFO - 2018-05-08 07:19:51 --> Language Class Initialized
INFO - 2018-05-08 07:19:51 --> Language Class Initialized
INFO - 2018-05-08 07:19:51 --> Config Class Initialized
INFO - 2018-05-08 07:19:51 --> Loader Class Initialized
INFO - 2018-05-08 12:49:51 --> Helper loaded: url_helper
INFO - 2018-05-08 12:49:51 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:49:51 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:49:51 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:49:51 --> Helper loaded: users_helper
INFO - 2018-05-08 12:49:51 --> Database Driver Class Initialized
INFO - 2018-05-08 07:19:51 --> Language Class Initialized
INFO - 2018-05-08 07:19:51 --> Config Class Initialized
INFO - 2018-05-08 07:19:51 --> Loader Class Initialized
INFO - 2018-05-08 12:49:51 --> Helper loaded: url_helper
INFO - 2018-05-08 12:49:51 --> Helper loaded: notification_helper
DEBUG - 2018-05-08 12:49:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:49:51 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:49:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:49:51 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:49:51 --> Helper loaded: users_helper
INFO - 2018-05-08 12:49:51 --> Helper loaded: form_helper
INFO - 2018-05-08 12:49:51 --> Form Validation Class Initialized
INFO - 2018-05-08 12:49:51 --> Controller Class Initialized
INFO - 2018-05-08 12:49:51 --> Model Class Initialized
INFO - 2018-05-08 12:49:52 --> Helper loaded: inflector_helper
INFO - 2018-05-08 12:49:52 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:49:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:49:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:49:52 --> Model Class Initialized
INFO - 2018-05-08 12:49:52 --> Model Class Initialized
INFO - 2018-05-08 12:49:52 --> Model Class Initialized
INFO - 2018-05-08 12:49:52 --> Model Class Initialized
INFO - 2018-05-08 12:49:52 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-05-08 12:49:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:49:52 --> Final output sent to browser
DEBUG - 2018-05-08 12:49:52 --> Total execution time: 0.1108
INFO - 2018-05-08 12:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:49:52 --> Helper loaded: form_helper
INFO - 2018-05-08 12:49:52 --> Form Validation Class Initialized
INFO - 2018-05-08 12:49:52 --> Controller Class Initialized
INFO - 2018-05-08 12:49:52 --> Model Class Initialized
INFO - 2018-05-08 12:49:52 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:49:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:49:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:49:52 --> Model Class Initialized
INFO - 2018-05-08 12:49:52 --> Model Class Initialized
INFO - 2018-05-08 12:49:52 --> Model Class Initialized
INFO - 2018-05-08 12:49:52 --> Model Class Initialized
INFO - 2018-05-08 12:49:52 --> Model Class Initialized
INFO - 2018-05-08 12:49:52 --> Model Class Initialized
INFO - 2018-05-08 12:49:52 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:49:52 --> Final output sent to browser
DEBUG - 2018-05-08 12:49:52 --> Total execution time: 0.1566
INFO - 2018-05-08 07:20:06 --> Config Class Initialized
INFO - 2018-05-08 07:20:06 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:20:06 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:20:06 --> Utf8 Class Initialized
INFO - 2018-05-08 07:20:06 --> URI Class Initialized
INFO - 2018-05-08 07:20:06 --> Router Class Initialized
INFO - 2018-05-08 07:20:06 --> Output Class Initialized
INFO - 2018-05-08 07:20:06 --> Security Class Initialized
DEBUG - 2018-05-08 07:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:20:06 --> Input Class Initialized
INFO - 2018-05-08 07:20:06 --> Language Class Initialized
INFO - 2018-05-08 07:20:06 --> Language Class Initialized
INFO - 2018-05-08 07:20:06 --> Config Class Initialized
INFO - 2018-05-08 07:20:06 --> Loader Class Initialized
INFO - 2018-05-08 12:50:06 --> Helper loaded: url_helper
INFO - 2018-05-08 12:50:06 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:50:06 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:50:06 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:50:06 --> Helper loaded: users_helper
INFO - 2018-05-08 12:50:06 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:50:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:50:06 --> Helper loaded: form_helper
INFO - 2018-05-08 12:50:06 --> Form Validation Class Initialized
INFO - 2018-05-08 12:50:06 --> Controller Class Initialized
INFO - 2018-05-08 12:50:06 --> Model Class Initialized
INFO - 2018-05-08 12:50:06 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:50:06 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:50:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:50:06 --> Model Class Initialized
INFO - 2018-05-08 12:50:06 --> Model Class Initialized
INFO - 2018-05-08 12:50:06 --> Model Class Initialized
INFO - 2018-05-08 12:50:06 --> Model Class Initialized
INFO - 2018-05-08 12:50:06 --> Model Class Initialized
INFO - 2018-05-08 12:50:06 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:50:06 --> Model Class Initialized
INFO - 2018-05-08 12:50:06 --> Final output sent to browser
DEBUG - 2018-05-08 12:50:06 --> Total execution time: 0.1148
INFO - 2018-05-08 07:20:07 --> Config Class Initialized
INFO - 2018-05-08 07:20:07 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:20:07 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:20:07 --> Utf8 Class Initialized
INFO - 2018-05-08 07:20:07 --> URI Class Initialized
INFO - 2018-05-08 07:20:07 --> Router Class Initialized
INFO - 2018-05-08 07:20:07 --> Output Class Initialized
INFO - 2018-05-08 07:20:07 --> Security Class Initialized
DEBUG - 2018-05-08 07:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:20:07 --> Input Class Initialized
INFO - 2018-05-08 07:20:07 --> Language Class Initialized
INFO - 2018-05-08 07:20:07 --> Language Class Initialized
INFO - 2018-05-08 07:20:07 --> Config Class Initialized
INFO - 2018-05-08 07:20:07 --> Loader Class Initialized
INFO - 2018-05-08 12:50:07 --> Helper loaded: url_helper
INFO - 2018-05-08 12:50:07 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:50:07 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:50:07 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:50:07 --> Helper loaded: users_helper
INFO - 2018-05-08 12:50:07 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:50:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:50:07 --> Helper loaded: form_helper
INFO - 2018-05-08 12:50:07 --> Form Validation Class Initialized
INFO - 2018-05-08 12:50:07 --> Controller Class Initialized
INFO - 2018-05-08 12:50:07 --> Model Class Initialized
INFO - 2018-05-08 12:50:07 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:50:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:50:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:50:07 --> Model Class Initialized
INFO - 2018-05-08 12:50:07 --> Model Class Initialized
INFO - 2018-05-08 12:50:07 --> Model Class Initialized
INFO - 2018-05-08 12:50:07 --> Model Class Initialized
INFO - 2018-05-08 12:50:07 --> Model Class Initialized
INFO - 2018-05-08 12:50:07 --> Model Class Initialized
INFO - 2018-05-08 12:50:07 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:50:07 --> Final output sent to browser
DEBUG - 2018-05-08 12:50:07 --> Total execution time: 0.1164
INFO - 2018-05-08 07:20:34 --> Config Class Initialized
INFO - 2018-05-08 07:20:34 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:20:34 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:20:34 --> Utf8 Class Initialized
INFO - 2018-05-08 07:20:34 --> URI Class Initialized
INFO - 2018-05-08 07:20:34 --> Router Class Initialized
INFO - 2018-05-08 07:20:34 --> Output Class Initialized
INFO - 2018-05-08 07:20:34 --> Security Class Initialized
DEBUG - 2018-05-08 07:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:20:34 --> Input Class Initialized
INFO - 2018-05-08 07:20:34 --> Language Class Initialized
INFO - 2018-05-08 07:20:34 --> Language Class Initialized
INFO - 2018-05-08 07:20:34 --> Config Class Initialized
INFO - 2018-05-08 07:20:34 --> Loader Class Initialized
INFO - 2018-05-08 12:50:34 --> Helper loaded: url_helper
INFO - 2018-05-08 12:50:34 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:50:34 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:50:34 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:50:34 --> Helper loaded: users_helper
INFO - 2018-05-08 12:50:34 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:50:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:50:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:50:34 --> Helper loaded: form_helper
INFO - 2018-05-08 12:50:34 --> Form Validation Class Initialized
INFO - 2018-05-08 12:50:34 --> Controller Class Initialized
INFO - 2018-05-08 12:50:34 --> Model Class Initialized
INFO - 2018-05-08 12:50:34 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:50:35 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:50:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:50:35 --> Model Class Initialized
INFO - 2018-05-08 12:50:35 --> Model Class Initialized
INFO - 2018-05-08 12:50:35 --> Model Class Initialized
INFO - 2018-05-08 12:50:35 --> Model Class Initialized
INFO - 2018-05-08 12:50:35 --> Model Class Initialized
INFO - 2018-05-08 12:50:35 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:50:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-05-08 12:50:35 --> Final output sent to browser
DEBUG - 2018-05-08 12:50:35 --> Total execution time: 0.1367
INFO - 2018-05-08 07:20:37 --> Config Class Initialized
INFO - 2018-05-08 07:20:37 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:20:37 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:20:37 --> Utf8 Class Initialized
INFO - 2018-05-08 07:20:37 --> URI Class Initialized
INFO - 2018-05-08 07:20:37 --> Router Class Initialized
INFO - 2018-05-08 07:20:37 --> Output Class Initialized
INFO - 2018-05-08 07:20:37 --> Security Class Initialized
DEBUG - 2018-05-08 07:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:20:37 --> Input Class Initialized
INFO - 2018-05-08 07:20:37 --> Language Class Initialized
INFO - 2018-05-08 07:20:37 --> Language Class Initialized
INFO - 2018-05-08 07:20:37 --> Config Class Initialized
INFO - 2018-05-08 07:20:37 --> Loader Class Initialized
INFO - 2018-05-08 12:50:37 --> Helper loaded: url_helper
INFO - 2018-05-08 12:50:37 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:50:37 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:50:37 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:50:37 --> Helper loaded: users_helper
INFO - 2018-05-08 12:50:37 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:50:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:50:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:50:37 --> Helper loaded: form_helper
INFO - 2018-05-08 12:50:37 --> Form Validation Class Initialized
INFO - 2018-05-08 12:50:37 --> Controller Class Initialized
INFO - 2018-05-08 12:50:37 --> Model Class Initialized
INFO - 2018-05-08 12:50:37 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:50:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:50:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:50:37 --> Model Class Initialized
INFO - 2018-05-08 12:50:37 --> Model Class Initialized
INFO - 2018-05-08 12:50:37 --> Model Class Initialized
INFO - 2018-05-08 12:50:37 --> Model Class Initialized
INFO - 2018-05-08 12:50:37 --> Model Class Initialized
INFO - 2018-05-08 12:50:37 --> Model Class Initialized
INFO - 2018-05-08 12:50:37 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:50:37 --> Final output sent to browser
DEBUG - 2018-05-08 12:50:37 --> Total execution time: 0.1355
INFO - 2018-05-08 07:20:43 --> Config Class Initialized
INFO - 2018-05-08 07:20:43 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:20:43 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:20:43 --> Utf8 Class Initialized
INFO - 2018-05-08 07:20:43 --> URI Class Initialized
INFO - 2018-05-08 07:20:43 --> Router Class Initialized
INFO - 2018-05-08 07:20:43 --> Output Class Initialized
INFO - 2018-05-08 07:20:43 --> Security Class Initialized
DEBUG - 2018-05-08 07:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:20:43 --> Input Class Initialized
INFO - 2018-05-08 07:20:43 --> Language Class Initialized
INFO - 2018-05-08 07:20:43 --> Language Class Initialized
INFO - 2018-05-08 07:20:43 --> Config Class Initialized
INFO - 2018-05-08 07:20:43 --> Loader Class Initialized
INFO - 2018-05-08 12:50:43 --> Helper loaded: url_helper
INFO - 2018-05-08 12:50:43 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:50:43 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:50:43 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:50:43 --> Helper loaded: users_helper
INFO - 2018-05-08 12:50:43 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:50:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:50:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:50:43 --> Helper loaded: form_helper
INFO - 2018-05-08 12:50:43 --> Form Validation Class Initialized
INFO - 2018-05-08 12:50:43 --> Controller Class Initialized
INFO - 2018-05-08 12:50:43 --> Model Class Initialized
INFO - 2018-05-08 12:50:43 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:50:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:50:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:50:43 --> Model Class Initialized
INFO - 2018-05-08 12:50:43 --> Model Class Initialized
INFO - 2018-05-08 12:50:43 --> Model Class Initialized
INFO - 2018-05-08 12:50:43 --> Model Class Initialized
INFO - 2018-05-08 12:50:43 --> Model Class Initialized
INFO - 2018-05-08 12:50:43 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:50:43 --> Model Class Initialized
INFO - 2018-05-08 12:50:43 --> Final output sent to browser
DEBUG - 2018-05-08 12:50:43 --> Total execution time: 0.0981
INFO - 2018-05-08 07:20:44 --> Config Class Initialized
INFO - 2018-05-08 07:20:44 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:20:44 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:20:44 --> Utf8 Class Initialized
INFO - 2018-05-08 07:20:44 --> URI Class Initialized
INFO - 2018-05-08 07:20:44 --> Router Class Initialized
INFO - 2018-05-08 07:20:44 --> Output Class Initialized
INFO - 2018-05-08 07:20:44 --> Security Class Initialized
DEBUG - 2018-05-08 07:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:20:44 --> Input Class Initialized
INFO - 2018-05-08 07:20:44 --> Language Class Initialized
INFO - 2018-05-08 07:20:44 --> Language Class Initialized
INFO - 2018-05-08 07:20:44 --> Config Class Initialized
INFO - 2018-05-08 07:20:44 --> Loader Class Initialized
INFO - 2018-05-08 12:50:44 --> Helper loaded: url_helper
INFO - 2018-05-08 12:50:44 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:50:44 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:50:44 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:50:44 --> Helper loaded: users_helper
INFO - 2018-05-08 12:50:44 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:50:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:50:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:50:44 --> Helper loaded: form_helper
INFO - 2018-05-08 12:50:44 --> Form Validation Class Initialized
INFO - 2018-05-08 12:50:44 --> Controller Class Initialized
INFO - 2018-05-08 12:50:44 --> Model Class Initialized
INFO - 2018-05-08 12:50:44 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:50:44 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:50:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:50:44 --> Model Class Initialized
INFO - 2018-05-08 12:50:44 --> Model Class Initialized
INFO - 2018-05-08 12:50:44 --> Model Class Initialized
INFO - 2018-05-08 12:50:44 --> Model Class Initialized
INFO - 2018-05-08 12:50:44 --> Model Class Initialized
INFO - 2018-05-08 12:50:44 --> Model Class Initialized
INFO - 2018-05-08 12:50:44 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:50:44 --> Final output sent to browser
DEBUG - 2018-05-08 12:50:44 --> Total execution time: 0.1080
INFO - 2018-05-08 07:20:51 --> Config Class Initialized
INFO - 2018-05-08 07:20:51 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:20:51 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:20:51 --> Utf8 Class Initialized
INFO - 2018-05-08 07:20:51 --> URI Class Initialized
INFO - 2018-05-08 07:20:51 --> Router Class Initialized
INFO - 2018-05-08 07:20:51 --> Output Class Initialized
INFO - 2018-05-08 07:20:52 --> Security Class Initialized
DEBUG - 2018-05-08 07:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:20:52 --> Input Class Initialized
INFO - 2018-05-08 07:20:52 --> Language Class Initialized
INFO - 2018-05-08 07:20:52 --> Language Class Initialized
INFO - 2018-05-08 07:20:52 --> Config Class Initialized
INFO - 2018-05-08 07:20:52 --> Loader Class Initialized
INFO - 2018-05-08 12:50:52 --> Helper loaded: url_helper
INFO - 2018-05-08 12:50:52 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:50:52 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:50:52 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:50:52 --> Helper loaded: users_helper
INFO - 2018-05-08 12:50:52 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:50:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:50:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:50:52 --> Helper loaded: form_helper
INFO - 2018-05-08 12:50:52 --> Form Validation Class Initialized
INFO - 2018-05-08 12:50:52 --> Controller Class Initialized
INFO - 2018-05-08 12:50:52 --> Model Class Initialized
INFO - 2018-05-08 12:50:52 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:50:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:50:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:50:52 --> Model Class Initialized
INFO - 2018-05-08 12:50:52 --> Model Class Initialized
INFO - 2018-05-08 12:50:52 --> Model Class Initialized
INFO - 2018-05-08 12:50:52 --> Model Class Initialized
INFO - 2018-05-08 12:50:52 --> Model Class Initialized
INFO - 2018-05-08 12:50:52 --> Model Class Initialized
INFO - 2018-05-08 12:50:52 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:50:52 --> Final output sent to browser
DEBUG - 2018-05-08 12:50:52 --> Total execution time: 0.1151
INFO - 2018-05-08 07:21:01 --> Config Class Initialized
INFO - 2018-05-08 07:21:01 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:21:01 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:21:01 --> Utf8 Class Initialized
INFO - 2018-05-08 07:21:01 --> URI Class Initialized
INFO - 2018-05-08 07:21:01 --> Router Class Initialized
INFO - 2018-05-08 07:21:01 --> Output Class Initialized
INFO - 2018-05-08 07:21:01 --> Security Class Initialized
DEBUG - 2018-05-08 07:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:21:01 --> Input Class Initialized
INFO - 2018-05-08 07:21:01 --> Language Class Initialized
INFO - 2018-05-08 07:21:01 --> Language Class Initialized
INFO - 2018-05-08 07:21:01 --> Config Class Initialized
INFO - 2018-05-08 07:21:01 --> Loader Class Initialized
INFO - 2018-05-08 12:51:01 --> Helper loaded: url_helper
INFO - 2018-05-08 12:51:01 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:51:01 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:51:01 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:51:01 --> Helper loaded: users_helper
INFO - 2018-05-08 12:51:01 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:51:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:51:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:51:01 --> Helper loaded: form_helper
INFO - 2018-05-08 12:51:01 --> Form Validation Class Initialized
INFO - 2018-05-08 12:51:01 --> Controller Class Initialized
INFO - 2018-05-08 12:51:01 --> Model Class Initialized
INFO - 2018-05-08 12:51:01 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:51:01 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:51:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:51:01 --> Model Class Initialized
INFO - 2018-05-08 12:51:01 --> Model Class Initialized
INFO - 2018-05-08 12:51:01 --> Model Class Initialized
INFO - 2018-05-08 12:51:01 --> Model Class Initialized
INFO - 2018-05-08 12:51:01 --> Model Class Initialized
INFO - 2018-05-08 12:51:01 --> Model Class Initialized
INFO - 2018-05-08 12:51:01 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:51:01 --> Model Class Initialized
INFO - 2018-05-08 12:51:01 --> Final output sent to browser
DEBUG - 2018-05-08 12:51:01 --> Total execution time: 0.1432
INFO - 2018-05-08 07:21:04 --> Config Class Initialized
INFO - 2018-05-08 07:21:04 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:21:04 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:21:04 --> Utf8 Class Initialized
INFO - 2018-05-08 07:21:04 --> URI Class Initialized
INFO - 2018-05-08 07:21:04 --> Router Class Initialized
INFO - 2018-05-08 07:21:04 --> Output Class Initialized
INFO - 2018-05-08 07:21:04 --> Security Class Initialized
DEBUG - 2018-05-08 07:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:21:04 --> Input Class Initialized
INFO - 2018-05-08 07:21:04 --> Language Class Initialized
INFO - 2018-05-08 07:21:05 --> Language Class Initialized
INFO - 2018-05-08 07:21:05 --> Config Class Initialized
INFO - 2018-05-08 07:21:05 --> Loader Class Initialized
INFO - 2018-05-08 12:51:05 --> Helper loaded: url_helper
INFO - 2018-05-08 12:51:05 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:51:05 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:51:05 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:51:05 --> Helper loaded: users_helper
INFO - 2018-05-08 12:51:05 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:51:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:51:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:51:05 --> Helper loaded: form_helper
INFO - 2018-05-08 12:51:05 --> Form Validation Class Initialized
INFO - 2018-05-08 12:51:05 --> Controller Class Initialized
INFO - 2018-05-08 12:51:05 --> Model Class Initialized
INFO - 2018-05-08 12:51:05 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:51:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:51:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:51:05 --> Model Class Initialized
INFO - 2018-05-08 12:51:05 --> Model Class Initialized
INFO - 2018-05-08 12:51:05 --> Model Class Initialized
INFO - 2018-05-08 12:51:05 --> Model Class Initialized
INFO - 2018-05-08 12:51:05 --> Model Class Initialized
INFO - 2018-05-08 12:51:05 --> Model Class Initialized
INFO - 2018-05-08 12:51:05 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:51:05 --> Final output sent to browser
DEBUG - 2018-05-08 12:51:05 --> Total execution time: 0.1527
INFO - 2018-05-08 07:21:07 --> Config Class Initialized
INFO - 2018-05-08 07:21:07 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:21:07 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:21:07 --> Utf8 Class Initialized
INFO - 2018-05-08 07:21:07 --> URI Class Initialized
INFO - 2018-05-08 07:21:07 --> Router Class Initialized
INFO - 2018-05-08 07:21:07 --> Output Class Initialized
INFO - 2018-05-08 07:21:07 --> Security Class Initialized
DEBUG - 2018-05-08 07:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:21:07 --> Input Class Initialized
INFO - 2018-05-08 07:21:07 --> Language Class Initialized
INFO - 2018-05-08 07:21:07 --> Language Class Initialized
INFO - 2018-05-08 07:21:07 --> Config Class Initialized
INFO - 2018-05-08 07:21:07 --> Loader Class Initialized
INFO - 2018-05-08 12:51:07 --> Helper loaded: url_helper
INFO - 2018-05-08 12:51:07 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:51:07 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:51:07 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:51:07 --> Helper loaded: users_helper
INFO - 2018-05-08 12:51:07 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:51:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:51:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:51:07 --> Helper loaded: form_helper
INFO - 2018-05-08 12:51:07 --> Form Validation Class Initialized
INFO - 2018-05-08 12:51:07 --> Controller Class Initialized
INFO - 2018-05-08 12:51:07 --> Model Class Initialized
INFO - 2018-05-08 12:51:07 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:51:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:51:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:51:07 --> Model Class Initialized
INFO - 2018-05-08 12:51:07 --> Model Class Initialized
INFO - 2018-05-08 12:51:07 --> Model Class Initialized
INFO - 2018-05-08 12:51:07 --> Model Class Initialized
INFO - 2018-05-08 12:51:07 --> Final output sent to browser
DEBUG - 2018-05-08 12:51:07 --> Total execution time: 0.1264
INFO - 2018-05-08 07:21:09 --> Config Class Initialized
INFO - 2018-05-08 07:21:09 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:21:09 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:21:09 --> Utf8 Class Initialized
INFO - 2018-05-08 07:21:09 --> URI Class Initialized
INFO - 2018-05-08 07:21:09 --> Router Class Initialized
INFO - 2018-05-08 07:21:09 --> Output Class Initialized
INFO - 2018-05-08 07:21:09 --> Security Class Initialized
DEBUG - 2018-05-08 07:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:21:09 --> Input Class Initialized
INFO - 2018-05-08 07:21:09 --> Language Class Initialized
INFO - 2018-05-08 07:21:09 --> Language Class Initialized
INFO - 2018-05-08 07:21:09 --> Config Class Initialized
INFO - 2018-05-08 07:21:09 --> Loader Class Initialized
INFO - 2018-05-08 12:51:09 --> Helper loaded: url_helper
INFO - 2018-05-08 12:51:09 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:51:09 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:51:09 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:51:09 --> Helper loaded: users_helper
INFO - 2018-05-08 12:51:09 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:51:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:51:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:51:09 --> Helper loaded: form_helper
INFO - 2018-05-08 12:51:09 --> Form Validation Class Initialized
INFO - 2018-05-08 12:51:09 --> Controller Class Initialized
INFO - 2018-05-08 12:51:09 --> Model Class Initialized
INFO - 2018-05-08 12:51:09 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:51:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:51:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:51:09 --> Model Class Initialized
INFO - 2018-05-08 12:51:09 --> Model Class Initialized
INFO - 2018-05-08 12:51:09 --> Model Class Initialized
INFO - 2018-05-08 12:51:09 --> Model Class Initialized
INFO - 2018-05-08 12:51:09 --> Final output sent to browser
DEBUG - 2018-05-08 12:51:09 --> Total execution time: 0.0985
INFO - 2018-05-08 07:21:10 --> Config Class Initialized
INFO - 2018-05-08 07:21:10 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:21:10 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:21:10 --> Utf8 Class Initialized
INFO - 2018-05-08 07:21:10 --> URI Class Initialized
INFO - 2018-05-08 07:21:10 --> Router Class Initialized
INFO - 2018-05-08 07:21:10 --> Output Class Initialized
INFO - 2018-05-08 07:21:10 --> Security Class Initialized
DEBUG - 2018-05-08 07:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:21:10 --> Input Class Initialized
INFO - 2018-05-08 07:21:10 --> Language Class Initialized
INFO - 2018-05-08 07:21:10 --> Language Class Initialized
INFO - 2018-05-08 07:21:10 --> Config Class Initialized
INFO - 2018-05-08 07:21:10 --> Loader Class Initialized
INFO - 2018-05-08 12:51:10 --> Helper loaded: url_helper
INFO - 2018-05-08 12:51:10 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:51:10 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:51:10 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:51:10 --> Helper loaded: users_helper
INFO - 2018-05-08 12:51:10 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:51:10 --> Helper loaded: form_helper
INFO - 2018-05-08 12:51:10 --> Form Validation Class Initialized
INFO - 2018-05-08 12:51:10 --> Controller Class Initialized
INFO - 2018-05-08 12:51:10 --> Model Class Initialized
INFO - 2018-05-08 12:51:10 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:51:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:51:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:51:10 --> Model Class Initialized
INFO - 2018-05-08 12:51:10 --> Model Class Initialized
INFO - 2018-05-08 12:51:10 --> Model Class Initialized
INFO - 2018-05-08 12:51:10 --> Model Class Initialized
INFO - 2018-05-08 12:51:10 --> Final output sent to browser
DEBUG - 2018-05-08 12:51:10 --> Total execution time: 0.1001
INFO - 2018-05-08 07:21:15 --> Config Class Initialized
INFO - 2018-05-08 07:21:15 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:21:15 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:21:15 --> Utf8 Class Initialized
INFO - 2018-05-08 07:21:15 --> URI Class Initialized
INFO - 2018-05-08 07:21:15 --> Router Class Initialized
INFO - 2018-05-08 07:21:15 --> Output Class Initialized
INFO - 2018-05-08 07:21:15 --> Security Class Initialized
DEBUG - 2018-05-08 07:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:21:15 --> Input Class Initialized
INFO - 2018-05-08 07:21:15 --> Language Class Initialized
INFO - 2018-05-08 07:21:15 --> Language Class Initialized
INFO - 2018-05-08 07:21:15 --> Config Class Initialized
INFO - 2018-05-08 07:21:15 --> Loader Class Initialized
INFO - 2018-05-08 12:51:15 --> Helper loaded: url_helper
INFO - 2018-05-08 12:51:15 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:51:15 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:51:15 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:51:15 --> Helper loaded: users_helper
INFO - 2018-05-08 12:51:15 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:51:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:51:15 --> Helper loaded: form_helper
INFO - 2018-05-08 12:51:15 --> Form Validation Class Initialized
INFO - 2018-05-08 12:51:15 --> Controller Class Initialized
INFO - 2018-05-08 12:51:15 --> Model Class Initialized
INFO - 2018-05-08 12:51:15 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:51:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:51:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:51:15 --> Model Class Initialized
INFO - 2018-05-08 12:51:15 --> Model Class Initialized
INFO - 2018-05-08 12:51:15 --> Model Class Initialized
INFO - 2018-05-08 12:51:15 --> Model Class Initialized
INFO - 2018-05-08 12:51:15 --> Model Class Initialized
INFO - 2018-05-08 12:51:15 --> Model Class Initialized
INFO - 2018-05-08 12:51:15 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:51:15 --> Model Class Initialized
INFO - 2018-05-08 12:51:15 --> Model Class Initialized
INFO - 2018-05-08 12:51:15 --> Final output sent to browser
DEBUG - 2018-05-08 12:51:15 --> Total execution time: 0.1232
INFO - 2018-05-08 07:21:16 --> Config Class Initialized
INFO - 2018-05-08 07:21:16 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:21:16 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:21:16 --> Utf8 Class Initialized
INFO - 2018-05-08 07:21:16 --> URI Class Initialized
INFO - 2018-05-08 07:21:16 --> Router Class Initialized
INFO - 2018-05-08 07:21:16 --> Output Class Initialized
INFO - 2018-05-08 07:21:16 --> Security Class Initialized
DEBUG - 2018-05-08 07:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:21:16 --> Input Class Initialized
INFO - 2018-05-08 07:21:16 --> Language Class Initialized
INFO - 2018-05-08 07:21:16 --> Language Class Initialized
INFO - 2018-05-08 07:21:16 --> Config Class Initialized
INFO - 2018-05-08 07:21:16 --> Loader Class Initialized
INFO - 2018-05-08 12:51:16 --> Helper loaded: url_helper
INFO - 2018-05-08 12:51:16 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:51:16 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:51:16 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:51:16 --> Helper loaded: users_helper
INFO - 2018-05-08 12:51:16 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:51:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:51:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:51:16 --> Helper loaded: form_helper
INFO - 2018-05-08 12:51:16 --> Form Validation Class Initialized
INFO - 2018-05-08 12:51:16 --> Controller Class Initialized
INFO - 2018-05-08 12:51:16 --> Model Class Initialized
INFO - 2018-05-08 12:51:16 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:51:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:51:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:51:16 --> Model Class Initialized
INFO - 2018-05-08 12:51:16 --> Model Class Initialized
INFO - 2018-05-08 12:51:16 --> Model Class Initialized
INFO - 2018-05-08 12:51:16 --> Model Class Initialized
INFO - 2018-05-08 12:51:16 --> Model Class Initialized
INFO - 2018-05-08 12:51:16 --> Model Class Initialized
INFO - 2018-05-08 12:51:16 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:51:16 --> Model Class Initialized
INFO - 2018-05-08 12:51:16 --> Model Class Initialized
INFO - 2018-05-08 12:51:16 --> Model Class Initialized
INFO - 2018-05-08 12:51:16 --> Final output sent to browser
DEBUG - 2018-05-08 12:51:16 --> Total execution time: 0.2468
INFO - 2018-05-08 07:21:17 --> Config Class Initialized
INFO - 2018-05-08 07:21:17 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:21:17 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:21:17 --> Utf8 Class Initialized
INFO - 2018-05-08 07:21:17 --> URI Class Initialized
INFO - 2018-05-08 07:21:17 --> Router Class Initialized
INFO - 2018-05-08 07:21:17 --> Output Class Initialized
INFO - 2018-05-08 07:21:17 --> Security Class Initialized
DEBUG - 2018-05-08 07:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:21:17 --> Input Class Initialized
INFO - 2018-05-08 07:21:17 --> Language Class Initialized
INFO - 2018-05-08 07:21:17 --> Language Class Initialized
INFO - 2018-05-08 07:21:17 --> Config Class Initialized
INFO - 2018-05-08 07:21:17 --> Loader Class Initialized
INFO - 2018-05-08 12:51:17 --> Helper loaded: url_helper
INFO - 2018-05-08 12:51:17 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:51:17 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:51:17 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:51:17 --> Helper loaded: users_helper
INFO - 2018-05-08 12:51:17 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:51:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:51:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:51:17 --> Helper loaded: form_helper
INFO - 2018-05-08 12:51:17 --> Form Validation Class Initialized
INFO - 2018-05-08 12:51:17 --> Controller Class Initialized
INFO - 2018-05-08 12:51:17 --> Model Class Initialized
INFO - 2018-05-08 12:51:17 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:51:17 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:51:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:51:17 --> Model Class Initialized
INFO - 2018-05-08 12:51:17 --> Model Class Initialized
INFO - 2018-05-08 12:51:17 --> Model Class Initialized
INFO - 2018-05-08 12:51:17 --> Model Class Initialized
INFO - 2018-05-08 12:51:17 --> Model Class Initialized
INFO - 2018-05-08 12:51:17 --> Model Class Initialized
INFO - 2018-05-08 12:51:17 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:51:17 --> Model Class Initialized
INFO - 2018-05-08 12:51:17 --> Model Class Initialized
INFO - 2018-05-08 12:51:17 --> Model Class Initialized
INFO - 2018-05-08 12:51:17 --> Final output sent to browser
DEBUG - 2018-05-08 12:51:17 --> Total execution time: 0.2204
INFO - 2018-05-08 07:21:19 --> Config Class Initialized
INFO - 2018-05-08 07:21:19 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:21:19 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:21:19 --> Utf8 Class Initialized
INFO - 2018-05-08 07:21:19 --> URI Class Initialized
INFO - 2018-05-08 07:21:19 --> Router Class Initialized
INFO - 2018-05-08 07:21:19 --> Output Class Initialized
INFO - 2018-05-08 07:21:19 --> Security Class Initialized
DEBUG - 2018-05-08 07:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:21:19 --> Input Class Initialized
INFO - 2018-05-08 07:21:19 --> Language Class Initialized
INFO - 2018-05-08 07:21:19 --> Language Class Initialized
INFO - 2018-05-08 07:21:19 --> Config Class Initialized
INFO - 2018-05-08 07:21:19 --> Loader Class Initialized
INFO - 2018-05-08 12:51:19 --> Helper loaded: url_helper
INFO - 2018-05-08 12:51:19 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:51:19 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:51:19 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:51:19 --> Helper loaded: users_helper
INFO - 2018-05-08 12:51:19 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:51:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:51:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:51:19 --> Helper loaded: form_helper
INFO - 2018-05-08 12:51:19 --> Form Validation Class Initialized
INFO - 2018-05-08 12:51:19 --> Controller Class Initialized
INFO - 2018-05-08 12:51:19 --> Model Class Initialized
INFO - 2018-05-08 12:51:19 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:51:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:51:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:51:19 --> Model Class Initialized
INFO - 2018-05-08 12:51:19 --> Model Class Initialized
INFO - 2018-05-08 12:51:19 --> Model Class Initialized
INFO - 2018-05-08 12:51:19 --> Model Class Initialized
INFO - 2018-05-08 12:51:19 --> Model Class Initialized
INFO - 2018-05-08 12:51:19 --> Model Class Initialized
INFO - 2018-05-08 12:51:19 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:51:19 --> Model Class Initialized
INFO - 2018-05-08 12:51:19 --> Model Class Initialized
INFO - 2018-05-08 12:51:19 --> Final output sent to browser
DEBUG - 2018-05-08 12:51:19 --> Total execution time: 0.1737
INFO - 2018-05-08 07:21:25 --> Config Class Initialized
INFO - 2018-05-08 07:21:25 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:21:25 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:21:25 --> Utf8 Class Initialized
INFO - 2018-05-08 07:21:25 --> URI Class Initialized
INFO - 2018-05-08 07:21:25 --> Router Class Initialized
INFO - 2018-05-08 07:21:25 --> Output Class Initialized
INFO - 2018-05-08 07:21:25 --> Security Class Initialized
DEBUG - 2018-05-08 07:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:21:25 --> Input Class Initialized
INFO - 2018-05-08 07:21:25 --> Language Class Initialized
INFO - 2018-05-08 07:21:25 --> Language Class Initialized
INFO - 2018-05-08 07:21:25 --> Config Class Initialized
INFO - 2018-05-08 07:21:25 --> Loader Class Initialized
INFO - 2018-05-08 12:51:25 --> Helper loaded: url_helper
INFO - 2018-05-08 12:51:25 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:51:25 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:51:25 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:51:25 --> Helper loaded: users_helper
INFO - 2018-05-08 12:51:25 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:51:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:51:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:51:25 --> Helper loaded: form_helper
INFO - 2018-05-08 12:51:25 --> Form Validation Class Initialized
INFO - 2018-05-08 12:51:25 --> Controller Class Initialized
INFO - 2018-05-08 12:51:25 --> Model Class Initialized
INFO - 2018-05-08 12:51:25 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:51:25 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:51:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:51:25 --> Model Class Initialized
INFO - 2018-05-08 12:51:25 --> Model Class Initialized
INFO - 2018-05-08 12:51:25 --> Model Class Initialized
INFO - 2018-05-08 12:51:25 --> Model Class Initialized
INFO - 2018-05-08 12:51:25 --> Final output sent to browser
DEBUG - 2018-05-08 12:51:25 --> Total execution time: 0.1309
INFO - 2018-05-08 07:21:26 --> Config Class Initialized
INFO - 2018-05-08 07:21:26 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:21:26 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:21:26 --> Utf8 Class Initialized
INFO - 2018-05-08 07:21:26 --> URI Class Initialized
INFO - 2018-05-08 07:21:26 --> Router Class Initialized
INFO - 2018-05-08 07:21:26 --> Output Class Initialized
INFO - 2018-05-08 07:21:26 --> Security Class Initialized
DEBUG - 2018-05-08 07:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:21:26 --> Input Class Initialized
INFO - 2018-05-08 07:21:26 --> Language Class Initialized
INFO - 2018-05-08 07:21:26 --> Language Class Initialized
INFO - 2018-05-08 07:21:26 --> Config Class Initialized
INFO - 2018-05-08 07:21:26 --> Loader Class Initialized
INFO - 2018-05-08 12:51:26 --> Helper loaded: url_helper
INFO - 2018-05-08 12:51:26 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:51:26 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:51:26 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:51:26 --> Helper loaded: users_helper
INFO - 2018-05-08 12:51:26 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:51:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:51:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:51:27 --> Helper loaded: form_helper
INFO - 2018-05-08 12:51:27 --> Form Validation Class Initialized
INFO - 2018-05-08 12:51:27 --> Controller Class Initialized
INFO - 2018-05-08 12:51:27 --> Model Class Initialized
INFO - 2018-05-08 12:51:27 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:51:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:51:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:51:27 --> Model Class Initialized
INFO - 2018-05-08 12:51:27 --> Model Class Initialized
INFO - 2018-05-08 12:51:27 --> Model Class Initialized
INFO - 2018-05-08 12:51:27 --> Model Class Initialized
INFO - 2018-05-08 12:51:27 --> Final output sent to browser
DEBUG - 2018-05-08 12:51:27 --> Total execution time: 0.1099
INFO - 2018-05-08 07:21:27 --> Config Class Initialized
INFO - 2018-05-08 07:21:27 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:21:27 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:21:27 --> Utf8 Class Initialized
INFO - 2018-05-08 07:21:27 --> URI Class Initialized
INFO - 2018-05-08 07:21:27 --> Router Class Initialized
INFO - 2018-05-08 07:21:27 --> Output Class Initialized
INFO - 2018-05-08 07:21:27 --> Security Class Initialized
DEBUG - 2018-05-08 07:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:21:27 --> Input Class Initialized
INFO - 2018-05-08 07:21:27 --> Language Class Initialized
INFO - 2018-05-08 07:21:27 --> Language Class Initialized
INFO - 2018-05-08 07:21:27 --> Config Class Initialized
INFO - 2018-05-08 07:21:27 --> Loader Class Initialized
INFO - 2018-05-08 12:51:27 --> Helper loaded: url_helper
INFO - 2018-05-08 12:51:27 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:51:27 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:51:27 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:51:27 --> Helper loaded: users_helper
INFO - 2018-05-08 12:51:27 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:51:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:51:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:51:27 --> Helper loaded: form_helper
INFO - 2018-05-08 12:51:27 --> Form Validation Class Initialized
INFO - 2018-05-08 12:51:27 --> Controller Class Initialized
INFO - 2018-05-08 12:51:27 --> Model Class Initialized
INFO - 2018-05-08 12:51:27 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:51:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:51:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:51:28 --> Model Class Initialized
INFO - 2018-05-08 12:51:28 --> Model Class Initialized
INFO - 2018-05-08 12:51:28 --> Model Class Initialized
INFO - 2018-05-08 12:51:28 --> Model Class Initialized
INFO - 2018-05-08 12:51:28 --> Final output sent to browser
DEBUG - 2018-05-08 12:51:28 --> Total execution time: 0.1162
INFO - 2018-05-08 07:24:39 --> Config Class Initialized
INFO - 2018-05-08 07:24:39 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:24:39 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:24:39 --> Utf8 Class Initialized
INFO - 2018-05-08 07:24:39 --> URI Class Initialized
INFO - 2018-05-08 07:24:39 --> Router Class Initialized
INFO - 2018-05-08 07:24:39 --> Output Class Initialized
INFO - 2018-05-08 07:24:39 --> Security Class Initialized
DEBUG - 2018-05-08 07:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:24:39 --> Input Class Initialized
INFO - 2018-05-08 07:24:39 --> Language Class Initialized
INFO - 2018-05-08 07:24:39 --> Language Class Initialized
INFO - 2018-05-08 07:24:39 --> Config Class Initialized
INFO - 2018-05-08 07:24:39 --> Loader Class Initialized
INFO - 2018-05-08 12:54:39 --> Helper loaded: url_helper
INFO - 2018-05-08 12:54:39 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:54:39 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:54:39 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:54:39 --> Helper loaded: users_helper
INFO - 2018-05-08 12:54:39 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:54:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:54:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:54:39 --> Helper loaded: form_helper
INFO - 2018-05-08 12:54:39 --> Form Validation Class Initialized
INFO - 2018-05-08 12:54:39 --> Controller Class Initialized
INFO - 2018-05-08 12:54:39 --> Model Class Initialized
INFO - 2018-05-08 12:54:39 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:54:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:54:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:54:39 --> Model Class Initialized
INFO - 2018-05-08 12:54:39 --> Model Class Initialized
INFO - 2018-05-08 12:54:39 --> Model Class Initialized
INFO - 2018-05-08 12:54:39 --> Model Class Initialized
INFO - 2018-05-08 12:54:39 --> Model Class Initialized
INFO - 2018-05-08 12:54:39 --> Model Class Initialized
INFO - 2018-05-08 12:54:39 --> Model Class Initialized
INFO - 2018-05-08 12:54:39 --> Model Class Initialized
INFO - 2018-05-08 12:54:39 --> Model Class Initialized
INFO - 2018-05-08 12:54:39 --> Model Class Initialized
INFO - 2018-05-08 12:54:39 --> Model Class Initialized
INFO - 2018-05-08 12:54:39 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:54:39 --> Model Class Initialized
INFO - 2018-05-08 12:54:39 --> Final output sent to browser
DEBUG - 2018-05-08 12:54:39 --> Total execution time: 0.1318
INFO - 2018-05-08 07:24:39 --> Config Class Initialized
INFO - 2018-05-08 07:24:39 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:24:39 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:24:39 --> Utf8 Class Initialized
INFO - 2018-05-08 07:24:39 --> URI Class Initialized
INFO - 2018-05-08 07:24:39 --> Router Class Initialized
INFO - 2018-05-08 07:24:39 --> Output Class Initialized
INFO - 2018-05-08 07:24:39 --> Security Class Initialized
DEBUG - 2018-05-08 07:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:24:39 --> Input Class Initialized
INFO - 2018-05-08 07:24:39 --> Language Class Initialized
INFO - 2018-05-08 07:24:39 --> Language Class Initialized
INFO - 2018-05-08 07:24:39 --> Config Class Initialized
INFO - 2018-05-08 07:24:39 --> Loader Class Initialized
INFO - 2018-05-08 12:54:39 --> Helper loaded: url_helper
INFO - 2018-05-08 12:54:39 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:54:39 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:54:39 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:54:39 --> Helper loaded: users_helper
INFO - 2018-05-08 12:54:39 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:54:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:54:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:54:39 --> Helper loaded: form_helper
INFO - 2018-05-08 12:54:39 --> Form Validation Class Initialized
INFO - 2018-05-08 12:54:39 --> Controller Class Initialized
INFO - 2018-05-08 12:54:39 --> Model Class Initialized
INFO - 2018-05-08 12:54:39 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:54:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:54:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:54:39 --> Model Class Initialized
INFO - 2018-05-08 12:54:39 --> Model Class Initialized
INFO - 2018-05-08 12:54:39 --> Model Class Initialized
INFO - 2018-05-08 12:54:39 --> Model Class Initialized
INFO - 2018-05-08 12:54:40 --> Model Class Initialized
INFO - 2018-05-08 12:54:40 --> Model Class Initialized
INFO - 2018-05-08 12:54:40 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:54:40 --> Model Class Initialized
INFO - 2018-05-08 12:54:40 --> Final output sent to browser
DEBUG - 2018-05-08 12:54:40 --> Total execution time: 0.1097
INFO - 2018-05-08 07:24:44 --> Config Class Initialized
INFO - 2018-05-08 07:24:44 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:24:44 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:24:44 --> Utf8 Class Initialized
INFO - 2018-05-08 07:24:44 --> URI Class Initialized
INFO - 2018-05-08 07:24:44 --> Router Class Initialized
INFO - 2018-05-08 07:24:44 --> Output Class Initialized
INFO - 2018-05-08 07:24:44 --> Security Class Initialized
DEBUG - 2018-05-08 07:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:24:44 --> Input Class Initialized
INFO - 2018-05-08 07:24:44 --> Language Class Initialized
INFO - 2018-05-08 07:24:44 --> Language Class Initialized
INFO - 2018-05-08 07:24:44 --> Config Class Initialized
INFO - 2018-05-08 07:24:44 --> Loader Class Initialized
INFO - 2018-05-08 12:54:44 --> Helper loaded: url_helper
INFO - 2018-05-08 12:54:44 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:54:44 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:54:44 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:54:44 --> Helper loaded: users_helper
INFO - 2018-05-08 12:54:44 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:54:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:54:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:54:44 --> Helper loaded: form_helper
INFO - 2018-05-08 12:54:44 --> Form Validation Class Initialized
INFO - 2018-05-08 12:54:44 --> Controller Class Initialized
INFO - 2018-05-08 12:54:44 --> Model Class Initialized
INFO - 2018-05-08 12:54:44 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:54:44 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:54:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:54:44 --> Model Class Initialized
INFO - 2018-05-08 12:54:44 --> Model Class Initialized
INFO - 2018-05-08 12:54:44 --> Model Class Initialized
INFO - 2018-05-08 12:54:44 --> Model Class Initialized
INFO - 2018-05-08 12:54:44 --> Model Class Initialized
INFO - 2018-05-08 12:54:44 --> Model Class Initialized
INFO - 2018-05-08 12:54:44 --> Model Class Initialized
INFO - 2018-05-08 12:54:44 --> Model Class Initialized
INFO - 2018-05-08 12:54:44 --> Model Class Initialized
INFO - 2018-05-08 12:54:44 --> Model Class Initialized
INFO - 2018-05-08 12:54:44 --> Model Class Initialized
INFO - 2018-05-08 12:54:44 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:54:44 --> Model Class Initialized
INFO - 2018-05-08 12:54:44 --> Final output sent to browser
DEBUG - 2018-05-08 12:54:44 --> Total execution time: 0.1406
INFO - 2018-05-08 07:24:47 --> Config Class Initialized
INFO - 2018-05-08 07:24:47 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:24:47 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:24:47 --> Utf8 Class Initialized
INFO - 2018-05-08 07:24:47 --> URI Class Initialized
INFO - 2018-05-08 07:24:47 --> Router Class Initialized
INFO - 2018-05-08 07:24:47 --> Output Class Initialized
INFO - 2018-05-08 07:24:47 --> Security Class Initialized
DEBUG - 2018-05-08 07:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:24:47 --> Input Class Initialized
INFO - 2018-05-08 07:24:47 --> Language Class Initialized
INFO - 2018-05-08 07:24:47 --> Language Class Initialized
INFO - 2018-05-08 07:24:47 --> Config Class Initialized
INFO - 2018-05-08 07:24:47 --> Loader Class Initialized
INFO - 2018-05-08 12:54:47 --> Helper loaded: url_helper
INFO - 2018-05-08 12:54:47 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:54:47 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:54:47 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:54:47 --> Helper loaded: users_helper
INFO - 2018-05-08 12:54:47 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:54:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:54:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:54:47 --> Helper loaded: form_helper
INFO - 2018-05-08 12:54:47 --> Form Validation Class Initialized
INFO - 2018-05-08 12:54:47 --> Controller Class Initialized
INFO - 2018-05-08 12:54:47 --> Model Class Initialized
INFO - 2018-05-08 12:54:47 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:54:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:54:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:54:47 --> Model Class Initialized
INFO - 2018-05-08 12:54:47 --> Model Class Initialized
INFO - 2018-05-08 12:54:47 --> Model Class Initialized
INFO - 2018-05-08 12:54:47 --> Model Class Initialized
INFO - 2018-05-08 12:54:47 --> Model Class Initialized
INFO - 2018-05-08 12:54:47 --> Model Class Initialized
INFO - 2018-05-08 12:54:47 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:54:47 --> Model Class Initialized
INFO - 2018-05-08 12:54:47 --> Model Class Initialized
INFO - 2018-05-08 12:54:47 --> Model Class Initialized
INFO - 2018-05-08 12:54:47 --> Final output sent to browser
DEBUG - 2018-05-08 12:54:47 --> Total execution time: 0.3517
INFO - 2018-05-08 07:24:52 --> Config Class Initialized
INFO - 2018-05-08 07:24:52 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:24:52 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:24:52 --> Utf8 Class Initialized
INFO - 2018-05-08 07:24:52 --> URI Class Initialized
INFO - 2018-05-08 07:24:52 --> Router Class Initialized
INFO - 2018-05-08 07:24:52 --> Output Class Initialized
INFO - 2018-05-08 07:24:52 --> Security Class Initialized
DEBUG - 2018-05-08 07:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:24:52 --> Input Class Initialized
INFO - 2018-05-08 07:24:52 --> Language Class Initialized
INFO - 2018-05-08 07:24:52 --> Language Class Initialized
INFO - 2018-05-08 07:24:52 --> Config Class Initialized
INFO - 2018-05-08 07:24:52 --> Loader Class Initialized
INFO - 2018-05-08 12:54:52 --> Helper loaded: url_helper
INFO - 2018-05-08 12:54:52 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:54:52 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:54:52 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:54:52 --> Helper loaded: users_helper
INFO - 2018-05-08 12:54:52 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:54:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:54:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:54:52 --> Helper loaded: form_helper
INFO - 2018-05-08 12:54:52 --> Form Validation Class Initialized
INFO - 2018-05-08 12:54:52 --> Controller Class Initialized
INFO - 2018-05-08 12:54:52 --> Model Class Initialized
INFO - 2018-05-08 12:54:52 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:54:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:54:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:54:52 --> Model Class Initialized
INFO - 2018-05-08 12:54:52 --> Model Class Initialized
INFO - 2018-05-08 12:54:52 --> Model Class Initialized
INFO - 2018-05-08 12:54:52 --> Model Class Initialized
INFO - 2018-05-08 12:54:52 --> Model Class Initialized
INFO - 2018-05-08 12:54:52 --> Model Class Initialized
INFO - 2018-05-08 12:54:52 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:54:52 --> Model Class Initialized
INFO - 2018-05-08 12:54:52 --> Model Class Initialized
INFO - 2018-05-08 12:54:52 --> Model Class Initialized
INFO - 2018-05-08 12:54:52 --> Final output sent to browser
DEBUG - 2018-05-08 12:54:52 --> Total execution time: 0.2392
INFO - 2018-05-08 07:24:53 --> Config Class Initialized
INFO - 2018-05-08 07:24:53 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:24:53 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:24:53 --> Utf8 Class Initialized
INFO - 2018-05-08 07:24:53 --> URI Class Initialized
INFO - 2018-05-08 07:24:53 --> Router Class Initialized
INFO - 2018-05-08 07:24:53 --> Output Class Initialized
INFO - 2018-05-08 07:24:53 --> Security Class Initialized
DEBUG - 2018-05-08 07:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:24:53 --> Input Class Initialized
INFO - 2018-05-08 07:24:53 --> Language Class Initialized
INFO - 2018-05-08 07:24:53 --> Language Class Initialized
INFO - 2018-05-08 07:24:53 --> Config Class Initialized
INFO - 2018-05-08 07:24:53 --> Loader Class Initialized
INFO - 2018-05-08 12:54:53 --> Helper loaded: url_helper
INFO - 2018-05-08 12:54:53 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:54:53 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:54:53 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:54:53 --> Helper loaded: users_helper
INFO - 2018-05-08 12:54:53 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:54:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:54:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:54:53 --> Helper loaded: form_helper
INFO - 2018-05-08 12:54:53 --> Form Validation Class Initialized
INFO - 2018-05-08 12:54:53 --> Controller Class Initialized
INFO - 2018-05-08 12:54:53 --> Model Class Initialized
INFO - 2018-05-08 12:54:53 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:54:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:54:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:54:53 --> Model Class Initialized
INFO - 2018-05-08 12:54:53 --> Model Class Initialized
INFO - 2018-05-08 12:54:53 --> Model Class Initialized
INFO - 2018-05-08 12:54:53 --> Model Class Initialized
INFO - 2018-05-08 12:54:53 --> Model Class Initialized
INFO - 2018-05-08 12:54:53 --> Model Class Initialized
INFO - 2018-05-08 12:54:53 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:54:53 --> Model Class Initialized
INFO - 2018-05-08 12:54:53 --> Model Class Initialized
INFO - 2018-05-08 12:54:53 --> Model Class Initialized
INFO - 2018-05-08 12:54:53 --> Final output sent to browser
DEBUG - 2018-05-08 12:54:53 --> Total execution time: 0.3572
INFO - 2018-05-08 07:24:55 --> Config Class Initialized
INFO - 2018-05-08 07:24:55 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:24:55 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:24:55 --> Utf8 Class Initialized
INFO - 2018-05-08 07:24:55 --> URI Class Initialized
INFO - 2018-05-08 07:24:55 --> Router Class Initialized
INFO - 2018-05-08 07:24:55 --> Output Class Initialized
INFO - 2018-05-08 07:24:55 --> Security Class Initialized
DEBUG - 2018-05-08 07:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:24:55 --> Input Class Initialized
INFO - 2018-05-08 07:24:55 --> Language Class Initialized
INFO - 2018-05-08 07:24:55 --> Language Class Initialized
INFO - 2018-05-08 07:24:55 --> Config Class Initialized
INFO - 2018-05-08 07:24:55 --> Loader Class Initialized
INFO - 2018-05-08 12:54:55 --> Helper loaded: url_helper
INFO - 2018-05-08 12:54:55 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:54:55 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:54:55 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:54:55 --> Helper loaded: users_helper
INFO - 2018-05-08 12:54:55 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:54:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:54:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:54:55 --> Helper loaded: form_helper
INFO - 2018-05-08 12:54:55 --> Form Validation Class Initialized
INFO - 2018-05-08 12:54:55 --> Controller Class Initialized
INFO - 2018-05-08 12:54:55 --> Model Class Initialized
INFO - 2018-05-08 12:54:55 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:54:55 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:54:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:54:55 --> Model Class Initialized
INFO - 2018-05-08 12:54:55 --> Model Class Initialized
INFO - 2018-05-08 12:54:55 --> Model Class Initialized
INFO - 2018-05-08 12:54:55 --> Model Class Initialized
INFO - 2018-05-08 12:54:55 --> Model Class Initialized
INFO - 2018-05-08 12:54:55 --> Model Class Initialized
INFO - 2018-05-08 12:54:55 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:54:55 --> Model Class Initialized
INFO - 2018-05-08 12:54:55 --> Model Class Initialized
INFO - 2018-05-08 12:54:55 --> Model Class Initialized
INFO - 2018-05-08 12:54:55 --> Final output sent to browser
DEBUG - 2018-05-08 12:54:55 --> Total execution time: 0.1217
INFO - 2018-05-08 07:24:56 --> Config Class Initialized
INFO - 2018-05-08 07:24:56 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:24:56 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:24:56 --> Utf8 Class Initialized
INFO - 2018-05-08 07:24:56 --> URI Class Initialized
INFO - 2018-05-08 07:24:56 --> Router Class Initialized
INFO - 2018-05-08 07:24:56 --> Output Class Initialized
INFO - 2018-05-08 07:24:56 --> Security Class Initialized
DEBUG - 2018-05-08 07:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:24:56 --> Input Class Initialized
INFO - 2018-05-08 07:24:56 --> Language Class Initialized
INFO - 2018-05-08 07:24:56 --> Language Class Initialized
INFO - 2018-05-08 07:24:56 --> Config Class Initialized
INFO - 2018-05-08 07:24:56 --> Loader Class Initialized
INFO - 2018-05-08 12:54:56 --> Helper loaded: url_helper
INFO - 2018-05-08 12:54:56 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:54:56 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:54:56 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:54:56 --> Helper loaded: users_helper
INFO - 2018-05-08 12:54:56 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:54:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:54:56 --> Helper loaded: form_helper
INFO - 2018-05-08 12:54:56 --> Form Validation Class Initialized
INFO - 2018-05-08 12:54:56 --> Controller Class Initialized
INFO - 2018-05-08 12:54:56 --> Model Class Initialized
INFO - 2018-05-08 12:54:56 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:54:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:54:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:54:56 --> Model Class Initialized
INFO - 2018-05-08 12:54:56 --> Model Class Initialized
INFO - 2018-05-08 12:54:56 --> Model Class Initialized
INFO - 2018-05-08 12:54:56 --> Model Class Initialized
INFO - 2018-05-08 12:54:56 --> Model Class Initialized
INFO - 2018-05-08 12:54:56 --> Model Class Initialized
INFO - 2018-05-08 12:54:56 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:54:56 --> Model Class Initialized
INFO - 2018-05-08 12:54:56 --> Model Class Initialized
INFO - 2018-05-08 12:54:56 --> Model Class Initialized
INFO - 2018-05-08 12:54:56 --> Final output sent to browser
DEBUG - 2018-05-08 12:54:56 --> Total execution time: 0.1175
INFO - 2018-05-08 07:24:57 --> Config Class Initialized
INFO - 2018-05-08 07:24:57 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:24:57 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:24:57 --> Utf8 Class Initialized
INFO - 2018-05-08 07:24:57 --> URI Class Initialized
INFO - 2018-05-08 07:24:57 --> Router Class Initialized
INFO - 2018-05-08 07:24:57 --> Output Class Initialized
INFO - 2018-05-08 07:24:57 --> Security Class Initialized
DEBUG - 2018-05-08 07:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:24:57 --> Input Class Initialized
INFO - 2018-05-08 07:24:57 --> Language Class Initialized
INFO - 2018-05-08 07:24:57 --> Language Class Initialized
INFO - 2018-05-08 07:24:57 --> Config Class Initialized
INFO - 2018-05-08 07:24:57 --> Loader Class Initialized
INFO - 2018-05-08 12:54:57 --> Helper loaded: url_helper
INFO - 2018-05-08 12:54:57 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:54:57 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:54:57 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:54:57 --> Helper loaded: users_helper
INFO - 2018-05-08 12:54:57 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:54:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:54:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:54:57 --> Helper loaded: form_helper
INFO - 2018-05-08 12:54:57 --> Form Validation Class Initialized
INFO - 2018-05-08 12:54:57 --> Controller Class Initialized
INFO - 2018-05-08 12:54:57 --> Model Class Initialized
INFO - 2018-05-08 12:54:57 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:54:57 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:54:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:54:57 --> Model Class Initialized
INFO - 2018-05-08 12:54:57 --> Model Class Initialized
INFO - 2018-05-08 12:54:57 --> Model Class Initialized
INFO - 2018-05-08 12:54:57 --> Model Class Initialized
INFO - 2018-05-08 12:54:57 --> Model Class Initialized
INFO - 2018-05-08 12:54:57 --> Model Class Initialized
INFO - 2018-05-08 12:54:57 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:54:57 --> Model Class Initialized
INFO - 2018-05-08 12:54:57 --> Model Class Initialized
INFO - 2018-05-08 12:54:57 --> Model Class Initialized
INFO - 2018-05-08 12:54:57 --> Final output sent to browser
DEBUG - 2018-05-08 12:54:57 --> Total execution time: 0.1720
INFO - 2018-05-08 07:24:59 --> Config Class Initialized
INFO - 2018-05-08 07:24:59 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:24:59 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:24:59 --> Utf8 Class Initialized
INFO - 2018-05-08 07:24:59 --> URI Class Initialized
INFO - 2018-05-08 07:24:59 --> Router Class Initialized
INFO - 2018-05-08 07:24:59 --> Output Class Initialized
INFO - 2018-05-08 07:24:59 --> Security Class Initialized
DEBUG - 2018-05-08 07:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:24:59 --> Input Class Initialized
INFO - 2018-05-08 07:24:59 --> Language Class Initialized
INFO - 2018-05-08 07:24:59 --> Language Class Initialized
INFO - 2018-05-08 07:24:59 --> Config Class Initialized
INFO - 2018-05-08 07:24:59 --> Loader Class Initialized
INFO - 2018-05-08 12:54:59 --> Helper loaded: url_helper
INFO - 2018-05-08 12:54:59 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:54:59 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:54:59 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:54:59 --> Helper loaded: users_helper
INFO - 2018-05-08 12:54:59 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:54:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:54:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:54:59 --> Helper loaded: form_helper
INFO - 2018-05-08 12:54:59 --> Form Validation Class Initialized
INFO - 2018-05-08 12:54:59 --> Controller Class Initialized
INFO - 2018-05-08 12:54:59 --> Model Class Initialized
INFO - 2018-05-08 12:54:59 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:54:59 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:54:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:54:59 --> Model Class Initialized
INFO - 2018-05-08 12:54:59 --> Model Class Initialized
INFO - 2018-05-08 12:54:59 --> Model Class Initialized
INFO - 2018-05-08 12:54:59 --> Model Class Initialized
INFO - 2018-05-08 12:54:59 --> Model Class Initialized
INFO - 2018-05-08 12:54:59 --> Model Class Initialized
INFO - 2018-05-08 12:54:59 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:54:59 --> Model Class Initialized
INFO - 2018-05-08 12:54:59 --> Model Class Initialized
INFO - 2018-05-08 12:54:59 --> Model Class Initialized
INFO - 2018-05-08 12:54:59 --> Final output sent to browser
DEBUG - 2018-05-08 12:54:59 --> Total execution time: 0.2913
INFO - 2018-05-08 07:25:00 --> Config Class Initialized
INFO - 2018-05-08 07:25:00 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:25:00 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:25:00 --> Utf8 Class Initialized
INFO - 2018-05-08 07:25:00 --> URI Class Initialized
INFO - 2018-05-08 07:25:00 --> Router Class Initialized
INFO - 2018-05-08 07:25:00 --> Output Class Initialized
INFO - 2018-05-08 07:25:00 --> Security Class Initialized
DEBUG - 2018-05-08 07:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:25:00 --> Input Class Initialized
INFO - 2018-05-08 07:25:00 --> Language Class Initialized
INFO - 2018-05-08 07:25:00 --> Language Class Initialized
INFO - 2018-05-08 07:25:00 --> Config Class Initialized
INFO - 2018-05-08 07:25:00 --> Loader Class Initialized
INFO - 2018-05-08 12:55:00 --> Helper loaded: url_helper
INFO - 2018-05-08 12:55:00 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:55:00 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:55:00 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:55:00 --> Helper loaded: users_helper
INFO - 2018-05-08 12:55:00 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:55:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:55:00 --> Helper loaded: form_helper
INFO - 2018-05-08 12:55:00 --> Form Validation Class Initialized
INFO - 2018-05-08 12:55:00 --> Controller Class Initialized
INFO - 2018-05-08 12:55:00 --> Model Class Initialized
INFO - 2018-05-08 12:55:00 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:55:00 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:55:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:55:00 --> Model Class Initialized
INFO - 2018-05-08 12:55:00 --> Model Class Initialized
INFO - 2018-05-08 12:55:00 --> Model Class Initialized
INFO - 2018-05-08 12:55:00 --> Model Class Initialized
INFO - 2018-05-08 12:55:00 --> Model Class Initialized
INFO - 2018-05-08 12:55:00 --> Model Class Initialized
INFO - 2018-05-08 12:55:00 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:55:00 --> Model Class Initialized
INFO - 2018-05-08 12:55:00 --> Model Class Initialized
INFO - 2018-05-08 12:55:00 --> Model Class Initialized
INFO - 2018-05-08 12:55:00 --> Final output sent to browser
DEBUG - 2018-05-08 12:55:00 --> Total execution time: 0.3024
INFO - 2018-05-08 07:25:02 --> Config Class Initialized
INFO - 2018-05-08 07:25:02 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:25:02 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:25:02 --> Utf8 Class Initialized
INFO - 2018-05-08 07:25:02 --> URI Class Initialized
INFO - 2018-05-08 07:25:02 --> Router Class Initialized
INFO - 2018-05-08 07:25:02 --> Output Class Initialized
INFO - 2018-05-08 07:25:02 --> Security Class Initialized
DEBUG - 2018-05-08 07:25:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:25:02 --> Input Class Initialized
INFO - 2018-05-08 07:25:02 --> Language Class Initialized
INFO - 2018-05-08 07:25:02 --> Language Class Initialized
INFO - 2018-05-08 07:25:02 --> Config Class Initialized
INFO - 2018-05-08 07:25:02 --> Loader Class Initialized
INFO - 2018-05-08 12:55:02 --> Helper loaded: url_helper
INFO - 2018-05-08 12:55:02 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:55:02 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:55:02 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:55:02 --> Helper loaded: users_helper
INFO - 2018-05-08 12:55:02 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:55:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:55:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:55:02 --> Helper loaded: form_helper
INFO - 2018-05-08 12:55:02 --> Form Validation Class Initialized
INFO - 2018-05-08 12:55:02 --> Controller Class Initialized
INFO - 2018-05-08 12:55:02 --> Model Class Initialized
INFO - 2018-05-08 12:55:02 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:55:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:55:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:55:02 --> Model Class Initialized
INFO - 2018-05-08 12:55:02 --> Model Class Initialized
INFO - 2018-05-08 12:55:02 --> Model Class Initialized
INFO - 2018-05-08 12:55:02 --> Model Class Initialized
INFO - 2018-05-08 12:55:02 --> Model Class Initialized
INFO - 2018-05-08 12:55:02 --> Model Class Initialized
INFO - 2018-05-08 12:55:02 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:55:02 --> Model Class Initialized
INFO - 2018-05-08 12:55:02 --> Model Class Initialized
INFO - 2018-05-08 12:55:02 --> Final output sent to browser
DEBUG - 2018-05-08 12:55:02 --> Total execution time: 0.1577
INFO - 2018-05-08 07:25:03 --> Config Class Initialized
INFO - 2018-05-08 07:25:03 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:25:03 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:25:03 --> Utf8 Class Initialized
INFO - 2018-05-08 07:25:03 --> URI Class Initialized
INFO - 2018-05-08 07:25:03 --> Router Class Initialized
INFO - 2018-05-08 07:25:03 --> Output Class Initialized
INFO - 2018-05-08 07:25:03 --> Security Class Initialized
DEBUG - 2018-05-08 07:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:25:03 --> Input Class Initialized
INFO - 2018-05-08 07:25:03 --> Language Class Initialized
INFO - 2018-05-08 07:25:03 --> Language Class Initialized
INFO - 2018-05-08 07:25:03 --> Config Class Initialized
INFO - 2018-05-08 07:25:03 --> Loader Class Initialized
INFO - 2018-05-08 12:55:03 --> Helper loaded: url_helper
INFO - 2018-05-08 12:55:03 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:55:03 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:55:03 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:55:03 --> Helper loaded: users_helper
INFO - 2018-05-08 12:55:03 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:55:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:55:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:55:03 --> Helper loaded: form_helper
INFO - 2018-05-08 12:55:03 --> Form Validation Class Initialized
INFO - 2018-05-08 12:55:03 --> Controller Class Initialized
INFO - 2018-05-08 12:55:03 --> Model Class Initialized
INFO - 2018-05-08 12:55:03 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:55:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:55:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:55:03 --> Model Class Initialized
INFO - 2018-05-08 12:55:03 --> Model Class Initialized
INFO - 2018-05-08 12:55:03 --> Model Class Initialized
INFO - 2018-05-08 12:55:03 --> Model Class Initialized
INFO - 2018-05-08 12:55:03 --> Model Class Initialized
INFO - 2018-05-08 12:55:03 --> Model Class Initialized
INFO - 2018-05-08 12:55:03 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:55:03 --> Model Class Initialized
INFO - 2018-05-08 12:55:03 --> Model Class Initialized
INFO - 2018-05-08 12:55:03 --> Final output sent to browser
DEBUG - 2018-05-08 12:55:03 --> Total execution time: 0.1184
INFO - 2018-05-08 07:25:06 --> Config Class Initialized
INFO - 2018-05-08 07:25:06 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:25:06 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:25:06 --> Utf8 Class Initialized
INFO - 2018-05-08 07:25:06 --> URI Class Initialized
INFO - 2018-05-08 07:25:06 --> Router Class Initialized
INFO - 2018-05-08 07:25:06 --> Output Class Initialized
INFO - 2018-05-08 07:25:06 --> Security Class Initialized
DEBUG - 2018-05-08 07:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:25:06 --> Input Class Initialized
INFO - 2018-05-08 07:25:06 --> Language Class Initialized
INFO - 2018-05-08 07:25:06 --> Language Class Initialized
INFO - 2018-05-08 07:25:06 --> Config Class Initialized
INFO - 2018-05-08 07:25:06 --> Loader Class Initialized
INFO - 2018-05-08 12:55:06 --> Helper loaded: url_helper
INFO - 2018-05-08 12:55:06 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:55:06 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:55:06 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:55:06 --> Helper loaded: users_helper
INFO - 2018-05-08 12:55:06 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:55:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:55:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:55:06 --> Helper loaded: form_helper
INFO - 2018-05-08 12:55:06 --> Form Validation Class Initialized
INFO - 2018-05-08 12:55:06 --> Controller Class Initialized
INFO - 2018-05-08 12:55:06 --> Model Class Initialized
INFO - 2018-05-08 12:55:06 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:55:06 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:55:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:55:06 --> Model Class Initialized
INFO - 2018-05-08 12:55:06 --> Model Class Initialized
INFO - 2018-05-08 12:55:06 --> Model Class Initialized
INFO - 2018-05-08 12:55:06 --> Model Class Initialized
INFO - 2018-05-08 12:55:06 --> Model Class Initialized
INFO - 2018-05-08 12:55:06 --> Model Class Initialized
INFO - 2018-05-08 12:55:06 --> Model Class Initialized
INFO - 2018-05-08 12:55:06 --> Model Class Initialized
INFO - 2018-05-08 12:55:06 --> Model Class Initialized
INFO - 2018-05-08 12:55:06 --> Model Class Initialized
INFO - 2018-05-08 12:55:06 --> Model Class Initialized
INFO - 2018-05-08 12:55:06 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:55:06 --> Model Class Initialized
INFO - 2018-05-08 12:55:06 --> Final output sent to browser
DEBUG - 2018-05-08 12:55:06 --> Total execution time: 0.1187
INFO - 2018-05-08 07:25:09 --> Config Class Initialized
INFO - 2018-05-08 07:25:09 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:25:09 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:25:09 --> Utf8 Class Initialized
INFO - 2018-05-08 07:25:09 --> URI Class Initialized
INFO - 2018-05-08 07:25:09 --> Router Class Initialized
INFO - 2018-05-08 07:25:09 --> Output Class Initialized
INFO - 2018-05-08 07:25:09 --> Security Class Initialized
DEBUG - 2018-05-08 07:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:25:09 --> Input Class Initialized
INFO - 2018-05-08 07:25:09 --> Language Class Initialized
INFO - 2018-05-08 07:25:09 --> Language Class Initialized
INFO - 2018-05-08 07:25:09 --> Config Class Initialized
INFO - 2018-05-08 07:25:09 --> Loader Class Initialized
INFO - 2018-05-08 12:55:09 --> Helper loaded: url_helper
INFO - 2018-05-08 12:55:09 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:55:09 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:55:09 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:55:09 --> Helper loaded: users_helper
INFO - 2018-05-08 12:55:09 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:55:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:55:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:55:09 --> Helper loaded: form_helper
INFO - 2018-05-08 12:55:09 --> Form Validation Class Initialized
INFO - 2018-05-08 12:55:09 --> Controller Class Initialized
INFO - 2018-05-08 12:55:09 --> Model Class Initialized
INFO - 2018-05-08 12:55:09 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:55:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:55:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:55:09 --> Model Class Initialized
INFO - 2018-05-08 12:55:09 --> Model Class Initialized
INFO - 2018-05-08 12:55:09 --> Model Class Initialized
INFO - 2018-05-08 12:55:09 --> Model Class Initialized
INFO - 2018-05-08 12:55:09 --> Model Class Initialized
INFO - 2018-05-08 12:55:09 --> Model Class Initialized
INFO - 2018-05-08 12:55:09 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:55:09 --> Model Class Initialized
INFO - 2018-05-08 12:55:09 --> Model Class Initialized
INFO - 2018-05-08 12:55:09 --> Model Class Initialized
INFO - 2018-05-08 12:55:09 --> Final output sent to browser
DEBUG - 2018-05-08 12:55:09 --> Total execution time: 0.3266
INFO - 2018-05-08 07:25:23 --> Config Class Initialized
INFO - 2018-05-08 07:25:23 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:25:23 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:25:23 --> Utf8 Class Initialized
INFO - 2018-05-08 07:25:23 --> URI Class Initialized
INFO - 2018-05-08 07:25:23 --> Router Class Initialized
INFO - 2018-05-08 07:25:23 --> Output Class Initialized
INFO - 2018-05-08 07:25:23 --> Security Class Initialized
DEBUG - 2018-05-08 07:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:25:23 --> Input Class Initialized
INFO - 2018-05-08 07:25:23 --> Language Class Initialized
INFO - 2018-05-08 07:25:23 --> Language Class Initialized
INFO - 2018-05-08 07:25:23 --> Config Class Initialized
INFO - 2018-05-08 07:25:23 --> Loader Class Initialized
INFO - 2018-05-08 12:55:23 --> Helper loaded: url_helper
INFO - 2018-05-08 12:55:23 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:55:23 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:55:23 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:55:23 --> Helper loaded: users_helper
INFO - 2018-05-08 12:55:23 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:55:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:55:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:55:23 --> Helper loaded: form_helper
INFO - 2018-05-08 12:55:23 --> Form Validation Class Initialized
INFO - 2018-05-08 12:55:23 --> Controller Class Initialized
INFO - 2018-05-08 12:55:23 --> Model Class Initialized
INFO - 2018-05-08 12:55:23 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:55:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:55:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:55:23 --> Model Class Initialized
INFO - 2018-05-08 12:55:23 --> Model Class Initialized
INFO - 2018-05-08 12:55:23 --> Model Class Initialized
INFO - 2018-05-08 12:55:23 --> Model Class Initialized
INFO - 2018-05-08 12:55:23 --> Model Class Initialized
INFO - 2018-05-08 12:55:23 --> Model Class Initialized
INFO - 2018-05-08 12:55:23 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:55:23 --> Model Class Initialized
INFO - 2018-05-08 12:55:23 --> Model Class Initialized
INFO - 2018-05-08 12:55:23 --> Final output sent to browser
DEBUG - 2018-05-08 12:55:23 --> Total execution time: 0.1187
INFO - 2018-05-08 07:25:24 --> Config Class Initialized
INFO - 2018-05-08 07:25:24 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:25:24 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:25:24 --> Utf8 Class Initialized
INFO - 2018-05-08 07:25:24 --> URI Class Initialized
INFO - 2018-05-08 07:25:24 --> Router Class Initialized
INFO - 2018-05-08 07:25:24 --> Output Class Initialized
INFO - 2018-05-08 07:25:24 --> Security Class Initialized
DEBUG - 2018-05-08 07:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:25:24 --> Input Class Initialized
INFO - 2018-05-08 07:25:24 --> Language Class Initialized
INFO - 2018-05-08 07:25:24 --> Language Class Initialized
INFO - 2018-05-08 07:25:24 --> Config Class Initialized
INFO - 2018-05-08 07:25:24 --> Loader Class Initialized
INFO - 2018-05-08 12:55:24 --> Helper loaded: url_helper
INFO - 2018-05-08 12:55:24 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:55:24 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:55:24 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:55:24 --> Helper loaded: users_helper
INFO - 2018-05-08 12:55:24 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:55:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:55:24 --> Helper loaded: form_helper
INFO - 2018-05-08 12:55:24 --> Form Validation Class Initialized
INFO - 2018-05-08 12:55:24 --> Controller Class Initialized
INFO - 2018-05-08 12:55:24 --> Model Class Initialized
INFO - 2018-05-08 12:55:24 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:55:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:55:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:55:24 --> Model Class Initialized
INFO - 2018-05-08 12:55:24 --> Model Class Initialized
INFO - 2018-05-08 12:55:24 --> Model Class Initialized
INFO - 2018-05-08 12:55:24 --> Model Class Initialized
INFO - 2018-05-08 12:55:24 --> Model Class Initialized
INFO - 2018-05-08 12:55:24 --> Model Class Initialized
INFO - 2018-05-08 12:55:24 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:55:24 --> Model Class Initialized
INFO - 2018-05-08 12:55:24 --> Model Class Initialized
INFO - 2018-05-08 12:55:24 --> Final output sent to browser
DEBUG - 2018-05-08 12:55:24 --> Total execution time: 0.1081
INFO - 2018-05-08 07:25:26 --> Config Class Initialized
INFO - 2018-05-08 07:25:26 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:25:26 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:25:26 --> Utf8 Class Initialized
INFO - 2018-05-08 07:25:26 --> URI Class Initialized
INFO - 2018-05-08 07:25:26 --> Router Class Initialized
INFO - 2018-05-08 07:25:26 --> Output Class Initialized
INFO - 2018-05-08 07:25:26 --> Security Class Initialized
DEBUG - 2018-05-08 07:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:25:26 --> Input Class Initialized
INFO - 2018-05-08 07:25:26 --> Language Class Initialized
INFO - 2018-05-08 07:25:26 --> Language Class Initialized
INFO - 2018-05-08 07:25:26 --> Config Class Initialized
INFO - 2018-05-08 07:25:26 --> Loader Class Initialized
INFO - 2018-05-08 12:55:26 --> Helper loaded: url_helper
INFO - 2018-05-08 12:55:26 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:55:26 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:55:26 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:55:26 --> Helper loaded: users_helper
INFO - 2018-05-08 12:55:26 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:55:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:55:26 --> Helper loaded: form_helper
INFO - 2018-05-08 12:55:26 --> Form Validation Class Initialized
INFO - 2018-05-08 12:55:26 --> Controller Class Initialized
INFO - 2018-05-08 12:55:26 --> Model Class Initialized
INFO - 2018-05-08 12:55:26 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:55:26 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:55:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:55:26 --> Model Class Initialized
INFO - 2018-05-08 12:55:26 --> Model Class Initialized
INFO - 2018-05-08 12:55:26 --> Model Class Initialized
INFO - 2018-05-08 12:55:26 --> Model Class Initialized
INFO - 2018-05-08 12:55:26 --> Model Class Initialized
INFO - 2018-05-08 12:55:26 --> Model Class Initialized
INFO - 2018-05-08 12:55:26 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:55:26 --> Model Class Initialized
INFO - 2018-05-08 12:55:26 --> Model Class Initialized
INFO - 2018-05-08 12:55:26 --> Final output sent to browser
DEBUG - 2018-05-08 12:55:26 --> Total execution time: 0.1187
INFO - 2018-05-08 07:25:27 --> Config Class Initialized
INFO - 2018-05-08 07:25:27 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:25:27 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:25:27 --> Utf8 Class Initialized
INFO - 2018-05-08 07:25:27 --> URI Class Initialized
INFO - 2018-05-08 07:25:27 --> Router Class Initialized
INFO - 2018-05-08 07:25:27 --> Output Class Initialized
INFO - 2018-05-08 07:25:27 --> Security Class Initialized
DEBUG - 2018-05-08 07:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:25:27 --> Input Class Initialized
INFO - 2018-05-08 07:25:27 --> Language Class Initialized
INFO - 2018-05-08 07:25:27 --> Language Class Initialized
INFO - 2018-05-08 07:25:27 --> Config Class Initialized
INFO - 2018-05-08 07:25:27 --> Loader Class Initialized
INFO - 2018-05-08 12:55:27 --> Helper loaded: url_helper
INFO - 2018-05-08 12:55:27 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:55:27 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:55:27 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:55:27 --> Helper loaded: users_helper
INFO - 2018-05-08 12:55:27 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:55:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:55:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:55:27 --> Helper loaded: form_helper
INFO - 2018-05-08 12:55:27 --> Form Validation Class Initialized
INFO - 2018-05-08 12:55:27 --> Controller Class Initialized
INFO - 2018-05-08 12:55:27 --> Model Class Initialized
INFO - 2018-05-08 12:55:27 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:55:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:55:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:55:28 --> Model Class Initialized
INFO - 2018-05-08 12:55:28 --> Model Class Initialized
INFO - 2018-05-08 12:55:28 --> Model Class Initialized
INFO - 2018-05-08 12:55:28 --> Model Class Initialized
INFO - 2018-05-08 12:55:28 --> Model Class Initialized
INFO - 2018-05-08 12:55:28 --> Model Class Initialized
INFO - 2018-05-08 12:55:28 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:55:28 --> Model Class Initialized
INFO - 2018-05-08 12:55:28 --> Model Class Initialized
INFO - 2018-05-08 12:55:28 --> Final output sent to browser
DEBUG - 2018-05-08 12:55:28 --> Total execution time: 0.1171
INFO - 2018-05-08 07:25:29 --> Config Class Initialized
INFO - 2018-05-08 07:25:29 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:25:29 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:25:29 --> Utf8 Class Initialized
INFO - 2018-05-08 07:25:29 --> URI Class Initialized
INFO - 2018-05-08 07:25:29 --> Router Class Initialized
INFO - 2018-05-08 07:25:29 --> Output Class Initialized
INFO - 2018-05-08 07:25:29 --> Security Class Initialized
DEBUG - 2018-05-08 07:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:25:29 --> Input Class Initialized
INFO - 2018-05-08 07:25:29 --> Language Class Initialized
INFO - 2018-05-08 07:25:29 --> Language Class Initialized
INFO - 2018-05-08 07:25:29 --> Config Class Initialized
INFO - 2018-05-08 07:25:29 --> Loader Class Initialized
INFO - 2018-05-08 12:55:29 --> Helper loaded: url_helper
INFO - 2018-05-08 12:55:29 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:55:29 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:55:29 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:55:29 --> Helper loaded: users_helper
INFO - 2018-05-08 12:55:29 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:55:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:55:29 --> Helper loaded: form_helper
INFO - 2018-05-08 12:55:29 --> Form Validation Class Initialized
INFO - 2018-05-08 12:55:29 --> Controller Class Initialized
INFO - 2018-05-08 12:55:29 --> Model Class Initialized
INFO - 2018-05-08 12:55:29 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:55:29 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:55:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:55:29 --> Model Class Initialized
INFO - 2018-05-08 12:55:29 --> Model Class Initialized
INFO - 2018-05-08 12:55:29 --> Model Class Initialized
INFO - 2018-05-08 12:55:29 --> Model Class Initialized
INFO - 2018-05-08 12:55:29 --> Model Class Initialized
INFO - 2018-05-08 12:55:29 --> Model Class Initialized
INFO - 2018-05-08 12:55:29 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:55:29 --> Model Class Initialized
INFO - 2018-05-08 12:55:29 --> Model Class Initialized
INFO - 2018-05-08 12:55:29 --> Final output sent to browser
DEBUG - 2018-05-08 12:55:29 --> Total execution time: 0.1414
INFO - 2018-05-08 07:25:31 --> Config Class Initialized
INFO - 2018-05-08 07:25:31 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:25:31 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:25:31 --> Utf8 Class Initialized
INFO - 2018-05-08 07:25:31 --> URI Class Initialized
INFO - 2018-05-08 07:25:31 --> Router Class Initialized
INFO - 2018-05-08 07:25:31 --> Output Class Initialized
INFO - 2018-05-08 07:25:31 --> Security Class Initialized
DEBUG - 2018-05-08 07:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:25:31 --> Input Class Initialized
INFO - 2018-05-08 07:25:31 --> Language Class Initialized
INFO - 2018-05-08 07:25:31 --> Language Class Initialized
INFO - 2018-05-08 07:25:31 --> Config Class Initialized
INFO - 2018-05-08 07:25:31 --> Loader Class Initialized
INFO - 2018-05-08 12:55:31 --> Helper loaded: url_helper
INFO - 2018-05-08 12:55:31 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:55:31 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:55:31 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:55:31 --> Helper loaded: users_helper
INFO - 2018-05-08 12:55:31 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:55:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:55:31 --> Helper loaded: form_helper
INFO - 2018-05-08 12:55:31 --> Form Validation Class Initialized
INFO - 2018-05-08 12:55:31 --> Controller Class Initialized
INFO - 2018-05-08 12:55:31 --> Model Class Initialized
INFO - 2018-05-08 12:55:31 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:55:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:55:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:55:31 --> Model Class Initialized
INFO - 2018-05-08 12:55:31 --> Model Class Initialized
INFO - 2018-05-08 12:55:31 --> Model Class Initialized
INFO - 2018-05-08 12:55:31 --> Model Class Initialized
INFO - 2018-05-08 12:55:31 --> Model Class Initialized
INFO - 2018-05-08 12:55:31 --> Model Class Initialized
INFO - 2018-05-08 12:55:31 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:55:31 --> Model Class Initialized
INFO - 2018-05-08 12:55:31 --> Model Class Initialized
INFO - 2018-05-08 12:55:31 --> Model Class Initialized
INFO - 2018-05-08 12:55:31 --> Final output sent to browser
DEBUG - 2018-05-08 12:55:31 --> Total execution time: 0.3768
INFO - 2018-05-08 07:25:39 --> Config Class Initialized
INFO - 2018-05-08 07:25:39 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:25:39 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:25:39 --> Utf8 Class Initialized
INFO - 2018-05-08 07:25:39 --> URI Class Initialized
INFO - 2018-05-08 07:25:39 --> Router Class Initialized
INFO - 2018-05-08 07:25:39 --> Output Class Initialized
INFO - 2018-05-08 07:25:39 --> Security Class Initialized
DEBUG - 2018-05-08 07:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:25:39 --> Input Class Initialized
INFO - 2018-05-08 07:25:39 --> Language Class Initialized
INFO - 2018-05-08 07:25:39 --> Language Class Initialized
INFO - 2018-05-08 07:25:39 --> Config Class Initialized
INFO - 2018-05-08 07:25:39 --> Loader Class Initialized
INFO - 2018-05-08 12:55:39 --> Helper loaded: url_helper
INFO - 2018-05-08 12:55:39 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:55:39 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:55:39 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:55:39 --> Helper loaded: users_helper
INFO - 2018-05-08 12:55:39 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:55:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:55:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:55:39 --> Helper loaded: form_helper
INFO - 2018-05-08 12:55:39 --> Form Validation Class Initialized
INFO - 2018-05-08 12:55:39 --> Controller Class Initialized
INFO - 2018-05-08 12:55:39 --> Model Class Initialized
INFO - 2018-05-08 12:55:39 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:55:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:55:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:55:39 --> Model Class Initialized
INFO - 2018-05-08 12:55:39 --> Model Class Initialized
INFO - 2018-05-08 12:55:39 --> Model Class Initialized
INFO - 2018-05-08 12:55:39 --> Model Class Initialized
INFO - 2018-05-08 12:55:39 --> Model Class Initialized
INFO - 2018-05-08 12:55:39 --> Model Class Initialized
INFO - 2018-05-08 12:55:39 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:55:39 --> Model Class Initialized
INFO - 2018-05-08 12:55:39 --> Model Class Initialized
INFO - 2018-05-08 12:55:39 --> Final output sent to browser
DEBUG - 2018-05-08 12:55:39 --> Total execution time: 0.0981
INFO - 2018-05-08 07:25:40 --> Config Class Initialized
INFO - 2018-05-08 07:25:40 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:25:40 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:25:40 --> Utf8 Class Initialized
INFO - 2018-05-08 07:25:40 --> URI Class Initialized
INFO - 2018-05-08 07:25:40 --> Router Class Initialized
INFO - 2018-05-08 07:25:40 --> Output Class Initialized
INFO - 2018-05-08 07:25:40 --> Security Class Initialized
DEBUG - 2018-05-08 07:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:25:40 --> Input Class Initialized
INFO - 2018-05-08 07:25:40 --> Language Class Initialized
INFO - 2018-05-08 07:25:40 --> Language Class Initialized
INFO - 2018-05-08 07:25:40 --> Config Class Initialized
INFO - 2018-05-08 07:25:40 --> Loader Class Initialized
INFO - 2018-05-08 12:55:40 --> Helper loaded: url_helper
INFO - 2018-05-08 12:55:40 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:55:40 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:55:40 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:55:40 --> Helper loaded: users_helper
INFO - 2018-05-08 12:55:40 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:55:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:55:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:55:40 --> Helper loaded: form_helper
INFO - 2018-05-08 12:55:40 --> Form Validation Class Initialized
INFO - 2018-05-08 12:55:40 --> Controller Class Initialized
INFO - 2018-05-08 12:55:40 --> Model Class Initialized
INFO - 2018-05-08 12:55:40 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:55:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:55:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:55:40 --> Model Class Initialized
INFO - 2018-05-08 12:55:40 --> Model Class Initialized
INFO - 2018-05-08 12:55:40 --> Model Class Initialized
INFO - 2018-05-08 12:55:40 --> Model Class Initialized
INFO - 2018-05-08 12:55:40 --> Model Class Initialized
INFO - 2018-05-08 12:55:40 --> Model Class Initialized
INFO - 2018-05-08 12:55:40 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:55:40 --> Model Class Initialized
INFO - 2018-05-08 12:55:40 --> Model Class Initialized
INFO - 2018-05-08 12:55:40 --> Final output sent to browser
DEBUG - 2018-05-08 12:55:40 --> Total execution time: 0.1087
INFO - 2018-05-08 07:25:41 --> Config Class Initialized
INFO - 2018-05-08 07:25:41 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:25:41 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:25:41 --> Utf8 Class Initialized
INFO - 2018-05-08 07:25:41 --> URI Class Initialized
INFO - 2018-05-08 07:25:41 --> Router Class Initialized
INFO - 2018-05-08 07:25:41 --> Output Class Initialized
INFO - 2018-05-08 07:25:41 --> Security Class Initialized
DEBUG - 2018-05-08 07:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:25:41 --> Input Class Initialized
INFO - 2018-05-08 07:25:41 --> Language Class Initialized
INFO - 2018-05-08 07:25:41 --> Language Class Initialized
INFO - 2018-05-08 07:25:41 --> Config Class Initialized
INFO - 2018-05-08 07:25:41 --> Loader Class Initialized
INFO - 2018-05-08 12:55:41 --> Helper loaded: url_helper
INFO - 2018-05-08 12:55:41 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:55:41 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:55:41 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:55:41 --> Helper loaded: users_helper
INFO - 2018-05-08 12:55:41 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:55:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:55:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:55:41 --> Helper loaded: form_helper
INFO - 2018-05-08 12:55:41 --> Form Validation Class Initialized
INFO - 2018-05-08 12:55:41 --> Controller Class Initialized
INFO - 2018-05-08 12:55:41 --> Model Class Initialized
INFO - 2018-05-08 12:55:41 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:55:41 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:55:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:55:41 --> Model Class Initialized
INFO - 2018-05-08 12:55:41 --> Model Class Initialized
INFO - 2018-05-08 12:55:41 --> Model Class Initialized
INFO - 2018-05-08 12:55:41 --> Model Class Initialized
INFO - 2018-05-08 12:55:41 --> Model Class Initialized
INFO - 2018-05-08 12:55:41 --> Model Class Initialized
INFO - 2018-05-08 12:55:41 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:55:41 --> Model Class Initialized
INFO - 2018-05-08 12:55:41 --> Model Class Initialized
INFO - 2018-05-08 12:55:41 --> Final output sent to browser
DEBUG - 2018-05-08 12:55:41 --> Total execution time: 0.1036
INFO - 2018-05-08 07:25:43 --> Config Class Initialized
INFO - 2018-05-08 07:25:43 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:25:43 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:25:43 --> Utf8 Class Initialized
INFO - 2018-05-08 07:25:43 --> URI Class Initialized
INFO - 2018-05-08 07:25:43 --> Router Class Initialized
INFO - 2018-05-08 07:25:43 --> Output Class Initialized
INFO - 2018-05-08 07:25:43 --> Security Class Initialized
DEBUG - 2018-05-08 07:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:25:43 --> Input Class Initialized
INFO - 2018-05-08 07:25:43 --> Language Class Initialized
INFO - 2018-05-08 07:25:43 --> Language Class Initialized
INFO - 2018-05-08 07:25:43 --> Config Class Initialized
INFO - 2018-05-08 07:25:43 --> Loader Class Initialized
INFO - 2018-05-08 12:55:43 --> Helper loaded: url_helper
INFO - 2018-05-08 12:55:43 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:55:43 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:55:43 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:55:43 --> Helper loaded: users_helper
INFO - 2018-05-08 12:55:43 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:55:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:55:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:55:43 --> Helper loaded: form_helper
INFO - 2018-05-08 12:55:43 --> Form Validation Class Initialized
INFO - 2018-05-08 12:55:43 --> Controller Class Initialized
INFO - 2018-05-08 12:55:43 --> Model Class Initialized
INFO - 2018-05-08 12:55:43 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:55:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:55:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:55:43 --> Model Class Initialized
INFO - 2018-05-08 12:55:43 --> Model Class Initialized
INFO - 2018-05-08 12:55:43 --> Model Class Initialized
INFO - 2018-05-08 12:55:43 --> Model Class Initialized
INFO - 2018-05-08 12:55:43 --> Model Class Initialized
INFO - 2018-05-08 12:55:43 --> Model Class Initialized
INFO - 2018-05-08 12:55:43 --> Model Class Initialized
INFO - 2018-05-08 12:55:43 --> Model Class Initialized
INFO - 2018-05-08 12:55:43 --> Model Class Initialized
INFO - 2018-05-08 12:55:43 --> Model Class Initialized
INFO - 2018-05-08 12:55:43 --> Model Class Initialized
INFO - 2018-05-08 12:55:43 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:55:43 --> Model Class Initialized
INFO - 2018-05-08 12:55:43 --> Final output sent to browser
DEBUG - 2018-05-08 12:55:43 --> Total execution time: 0.1483
INFO - 2018-05-08 07:26:00 --> Config Class Initialized
INFO - 2018-05-08 07:26:00 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:26:00 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:26:00 --> Utf8 Class Initialized
INFO - 2018-05-08 07:26:00 --> URI Class Initialized
INFO - 2018-05-08 07:26:00 --> Router Class Initialized
INFO - 2018-05-08 07:26:01 --> Output Class Initialized
INFO - 2018-05-08 07:26:01 --> Security Class Initialized
DEBUG - 2018-05-08 07:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:26:01 --> Input Class Initialized
INFO - 2018-05-08 07:26:01 --> Language Class Initialized
INFO - 2018-05-08 07:26:01 --> Language Class Initialized
INFO - 2018-05-08 07:26:01 --> Config Class Initialized
INFO - 2018-05-08 07:26:01 --> Loader Class Initialized
INFO - 2018-05-08 12:56:01 --> Helper loaded: url_helper
INFO - 2018-05-08 12:56:01 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:56:01 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:56:01 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:56:01 --> Helper loaded: users_helper
INFO - 2018-05-08 12:56:01 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:56:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:56:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:56:01 --> Helper loaded: form_helper
INFO - 2018-05-08 12:56:01 --> Form Validation Class Initialized
INFO - 2018-05-08 12:56:01 --> Controller Class Initialized
INFO - 2018-05-08 12:56:01 --> Model Class Initialized
INFO - 2018-05-08 12:56:01 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:56:01 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:56:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:56:01 --> Model Class Initialized
INFO - 2018-05-08 12:56:01 --> Model Class Initialized
INFO - 2018-05-08 12:56:01 --> Model Class Initialized
INFO - 2018-05-08 12:56:01 --> Model Class Initialized
INFO - 2018-05-08 12:56:01 --> Model Class Initialized
INFO - 2018-05-08 12:56:01 --> Model Class Initialized
INFO - 2018-05-08 12:56:01 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:56:01 --> Model Class Initialized
INFO - 2018-05-08 12:56:01 --> Model Class Initialized
INFO - 2018-05-08 12:56:01 --> Final output sent to browser
DEBUG - 2018-05-08 12:56:01 --> Total execution time: 0.1152
INFO - 2018-05-08 07:26:01 --> Config Class Initialized
INFO - 2018-05-08 07:26:01 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:26:01 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:26:01 --> Utf8 Class Initialized
INFO - 2018-05-08 07:26:01 --> URI Class Initialized
INFO - 2018-05-08 07:26:01 --> Router Class Initialized
INFO - 2018-05-08 07:26:01 --> Output Class Initialized
INFO - 2018-05-08 07:26:01 --> Security Class Initialized
DEBUG - 2018-05-08 07:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:26:01 --> Input Class Initialized
INFO - 2018-05-08 07:26:01 --> Language Class Initialized
INFO - 2018-05-08 07:26:01 --> Language Class Initialized
INFO - 2018-05-08 07:26:01 --> Config Class Initialized
INFO - 2018-05-08 07:26:01 --> Loader Class Initialized
INFO - 2018-05-08 12:56:02 --> Helper loaded: url_helper
INFO - 2018-05-08 12:56:02 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:56:02 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:56:02 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:56:02 --> Helper loaded: users_helper
INFO - 2018-05-08 12:56:02 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:56:02 --> Helper loaded: form_helper
INFO - 2018-05-08 12:56:02 --> Form Validation Class Initialized
INFO - 2018-05-08 12:56:02 --> Controller Class Initialized
INFO - 2018-05-08 12:56:02 --> Model Class Initialized
INFO - 2018-05-08 12:56:02 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:56:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:56:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:56:02 --> Model Class Initialized
INFO - 2018-05-08 12:56:02 --> Model Class Initialized
INFO - 2018-05-08 12:56:02 --> Model Class Initialized
INFO - 2018-05-08 12:56:02 --> Model Class Initialized
INFO - 2018-05-08 12:56:02 --> Model Class Initialized
INFO - 2018-05-08 12:56:02 --> Model Class Initialized
INFO - 2018-05-08 12:56:02 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:56:02 --> Model Class Initialized
INFO - 2018-05-08 12:56:02 --> Model Class Initialized
INFO - 2018-05-08 12:56:02 --> Final output sent to browser
DEBUG - 2018-05-08 12:56:02 --> Total execution time: 0.1687
INFO - 2018-05-08 07:26:03 --> Config Class Initialized
INFO - 2018-05-08 07:26:03 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:26:03 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:26:03 --> Utf8 Class Initialized
INFO - 2018-05-08 07:26:03 --> URI Class Initialized
INFO - 2018-05-08 07:26:03 --> Router Class Initialized
INFO - 2018-05-08 07:26:03 --> Output Class Initialized
INFO - 2018-05-08 07:26:03 --> Security Class Initialized
DEBUG - 2018-05-08 07:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:26:03 --> Input Class Initialized
INFO - 2018-05-08 07:26:03 --> Language Class Initialized
INFO - 2018-05-08 07:26:03 --> Language Class Initialized
INFO - 2018-05-08 07:26:03 --> Config Class Initialized
INFO - 2018-05-08 07:26:03 --> Loader Class Initialized
INFO - 2018-05-08 12:56:03 --> Helper loaded: url_helper
INFO - 2018-05-08 12:56:03 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:56:03 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:56:03 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:56:03 --> Helper loaded: users_helper
INFO - 2018-05-08 12:56:03 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:56:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:56:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:56:03 --> Helper loaded: form_helper
INFO - 2018-05-08 12:56:03 --> Form Validation Class Initialized
INFO - 2018-05-08 12:56:03 --> Controller Class Initialized
INFO - 2018-05-08 12:56:03 --> Model Class Initialized
INFO - 2018-05-08 12:56:03 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:56:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:56:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:56:03 --> Model Class Initialized
INFO - 2018-05-08 12:56:03 --> Model Class Initialized
INFO - 2018-05-08 12:56:03 --> Model Class Initialized
INFO - 2018-05-08 12:56:03 --> Model Class Initialized
INFO - 2018-05-08 12:56:03 --> Model Class Initialized
INFO - 2018-05-08 12:56:03 --> Model Class Initialized
INFO - 2018-05-08 12:56:03 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:56:03 --> Model Class Initialized
INFO - 2018-05-08 12:56:03 --> Model Class Initialized
INFO - 2018-05-08 12:56:03 --> Final output sent to browser
DEBUG - 2018-05-08 12:56:03 --> Total execution time: 0.1263
INFO - 2018-05-08 07:26:04 --> Config Class Initialized
INFO - 2018-05-08 07:26:04 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:26:04 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:26:04 --> Utf8 Class Initialized
INFO - 2018-05-08 07:26:04 --> URI Class Initialized
INFO - 2018-05-08 07:26:04 --> Router Class Initialized
INFO - 2018-05-08 07:26:04 --> Output Class Initialized
INFO - 2018-05-08 07:26:04 --> Security Class Initialized
DEBUG - 2018-05-08 07:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:26:04 --> Input Class Initialized
INFO - 2018-05-08 07:26:04 --> Language Class Initialized
INFO - 2018-05-08 07:26:04 --> Language Class Initialized
INFO - 2018-05-08 07:26:04 --> Config Class Initialized
INFO - 2018-05-08 07:26:04 --> Loader Class Initialized
INFO - 2018-05-08 12:56:04 --> Helper loaded: url_helper
INFO - 2018-05-08 12:56:04 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:56:04 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:56:04 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:56:04 --> Helper loaded: users_helper
INFO - 2018-05-08 12:56:04 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:56:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:56:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:56:04 --> Helper loaded: form_helper
INFO - 2018-05-08 12:56:04 --> Form Validation Class Initialized
INFO - 2018-05-08 12:56:04 --> Controller Class Initialized
INFO - 2018-05-08 12:56:04 --> Model Class Initialized
INFO - 2018-05-08 12:56:04 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:56:04 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:56:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:56:04 --> Model Class Initialized
INFO - 2018-05-08 12:56:04 --> Model Class Initialized
INFO - 2018-05-08 12:56:04 --> Model Class Initialized
INFO - 2018-05-08 12:56:04 --> Model Class Initialized
INFO - 2018-05-08 12:56:04 --> Model Class Initialized
INFO - 2018-05-08 12:56:04 --> Model Class Initialized
INFO - 2018-05-08 12:56:04 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:56:04 --> Model Class Initialized
INFO - 2018-05-08 12:56:04 --> Model Class Initialized
INFO - 2018-05-08 12:56:04 --> Final output sent to browser
DEBUG - 2018-05-08 12:56:04 --> Total execution time: 0.1415
INFO - 2018-05-08 07:26:05 --> Config Class Initialized
INFO - 2018-05-08 07:26:05 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:26:05 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:26:05 --> Utf8 Class Initialized
INFO - 2018-05-08 07:26:05 --> URI Class Initialized
INFO - 2018-05-08 07:26:05 --> Router Class Initialized
INFO - 2018-05-08 07:26:05 --> Output Class Initialized
INFO - 2018-05-08 07:26:05 --> Security Class Initialized
DEBUG - 2018-05-08 07:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:26:05 --> Input Class Initialized
INFO - 2018-05-08 07:26:05 --> Language Class Initialized
INFO - 2018-05-08 07:26:05 --> Language Class Initialized
INFO - 2018-05-08 07:26:05 --> Config Class Initialized
INFO - 2018-05-08 07:26:05 --> Loader Class Initialized
INFO - 2018-05-08 12:56:05 --> Helper loaded: url_helper
INFO - 2018-05-08 12:56:05 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:56:05 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:56:05 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:56:05 --> Helper loaded: users_helper
INFO - 2018-05-08 12:56:05 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:56:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:56:05 --> Helper loaded: form_helper
INFO - 2018-05-08 12:56:05 --> Form Validation Class Initialized
INFO - 2018-05-08 12:56:05 --> Controller Class Initialized
INFO - 2018-05-08 12:56:05 --> Model Class Initialized
INFO - 2018-05-08 12:56:05 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:56:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:56:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:56:05 --> Model Class Initialized
INFO - 2018-05-08 12:56:05 --> Model Class Initialized
INFO - 2018-05-08 12:56:05 --> Model Class Initialized
INFO - 2018-05-08 12:56:05 --> Model Class Initialized
INFO - 2018-05-08 12:56:05 --> Model Class Initialized
INFO - 2018-05-08 12:56:05 --> Model Class Initialized
INFO - 2018-05-08 12:56:05 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:56:05 --> Model Class Initialized
INFO - 2018-05-08 12:56:05 --> Model Class Initialized
INFO - 2018-05-08 12:56:05 --> Final output sent to browser
DEBUG - 2018-05-08 12:56:05 --> Total execution time: 0.1391
INFO - 2018-05-08 07:26:06 --> Config Class Initialized
INFO - 2018-05-08 07:26:06 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:26:06 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:26:06 --> Utf8 Class Initialized
INFO - 2018-05-08 07:26:06 --> URI Class Initialized
INFO - 2018-05-08 07:26:06 --> Router Class Initialized
INFO - 2018-05-08 07:26:06 --> Output Class Initialized
INFO - 2018-05-08 07:26:06 --> Security Class Initialized
DEBUG - 2018-05-08 07:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:26:06 --> Input Class Initialized
INFO - 2018-05-08 07:26:06 --> Language Class Initialized
INFO - 2018-05-08 07:26:06 --> Language Class Initialized
INFO - 2018-05-08 07:26:06 --> Config Class Initialized
INFO - 2018-05-08 07:26:06 --> Loader Class Initialized
INFO - 2018-05-08 12:56:06 --> Helper loaded: url_helper
INFO - 2018-05-08 12:56:06 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:56:06 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:56:06 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:56:06 --> Helper loaded: users_helper
INFO - 2018-05-08 12:56:06 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:56:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:56:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:56:06 --> Helper loaded: form_helper
INFO - 2018-05-08 12:56:06 --> Form Validation Class Initialized
INFO - 2018-05-08 12:56:06 --> Controller Class Initialized
INFO - 2018-05-08 12:56:06 --> Model Class Initialized
INFO - 2018-05-08 12:56:06 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:56:06 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:56:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:56:06 --> Model Class Initialized
INFO - 2018-05-08 12:56:06 --> Model Class Initialized
INFO - 2018-05-08 12:56:06 --> Model Class Initialized
INFO - 2018-05-08 12:56:06 --> Model Class Initialized
INFO - 2018-05-08 12:56:06 --> Model Class Initialized
INFO - 2018-05-08 12:56:06 --> Model Class Initialized
INFO - 2018-05-08 12:56:06 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:56:06 --> Model Class Initialized
INFO - 2018-05-08 12:56:06 --> Model Class Initialized
INFO - 2018-05-08 12:56:06 --> Final output sent to browser
DEBUG - 2018-05-08 12:56:06 --> Total execution time: 0.1183
INFO - 2018-05-08 07:26:08 --> Config Class Initialized
INFO - 2018-05-08 07:26:08 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:26:08 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:26:08 --> Utf8 Class Initialized
INFO - 2018-05-08 07:26:08 --> URI Class Initialized
INFO - 2018-05-08 07:26:08 --> Router Class Initialized
INFO - 2018-05-08 07:26:08 --> Output Class Initialized
INFO - 2018-05-08 07:26:08 --> Security Class Initialized
DEBUG - 2018-05-08 07:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:26:08 --> Input Class Initialized
INFO - 2018-05-08 07:26:08 --> Language Class Initialized
INFO - 2018-05-08 07:26:08 --> Language Class Initialized
INFO - 2018-05-08 07:26:08 --> Config Class Initialized
INFO - 2018-05-08 07:26:08 --> Loader Class Initialized
INFO - 2018-05-08 12:56:08 --> Helper loaded: url_helper
INFO - 2018-05-08 12:56:08 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:56:08 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:56:08 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:56:08 --> Helper loaded: users_helper
INFO - 2018-05-08 12:56:09 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:56:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:56:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:56:09 --> Helper loaded: form_helper
INFO - 2018-05-08 12:56:09 --> Form Validation Class Initialized
INFO - 2018-05-08 12:56:09 --> Controller Class Initialized
INFO - 2018-05-08 12:56:09 --> Model Class Initialized
INFO - 2018-05-08 12:56:09 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:56:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:56:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:56:09 --> Model Class Initialized
INFO - 2018-05-08 12:56:09 --> Model Class Initialized
INFO - 2018-05-08 12:56:09 --> Model Class Initialized
INFO - 2018-05-08 12:56:09 --> Model Class Initialized
INFO - 2018-05-08 12:56:09 --> Model Class Initialized
INFO - 2018-05-08 12:56:09 --> Model Class Initialized
INFO - 2018-05-08 12:56:09 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:56:09 --> Model Class Initialized
INFO - 2018-05-08 12:56:09 --> Model Class Initialized
INFO - 2018-05-08 12:56:09 --> Final output sent to browser
DEBUG - 2018-05-08 12:56:09 --> Total execution time: 0.1585
INFO - 2018-05-08 07:26:10 --> Config Class Initialized
INFO - 2018-05-08 07:26:10 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:26:10 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:26:10 --> Utf8 Class Initialized
INFO - 2018-05-08 07:26:10 --> URI Class Initialized
INFO - 2018-05-08 07:26:10 --> Router Class Initialized
INFO - 2018-05-08 07:26:10 --> Output Class Initialized
INFO - 2018-05-08 07:26:10 --> Security Class Initialized
DEBUG - 2018-05-08 07:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:26:10 --> Input Class Initialized
INFO - 2018-05-08 07:26:10 --> Language Class Initialized
INFO - 2018-05-08 07:26:10 --> Language Class Initialized
INFO - 2018-05-08 07:26:10 --> Config Class Initialized
INFO - 2018-05-08 07:26:10 --> Loader Class Initialized
INFO - 2018-05-08 12:56:10 --> Helper loaded: url_helper
INFO - 2018-05-08 12:56:10 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:56:10 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:56:10 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:56:10 --> Helper loaded: users_helper
INFO - 2018-05-08 12:56:10 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:56:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:56:10 --> Helper loaded: form_helper
INFO - 2018-05-08 12:56:10 --> Form Validation Class Initialized
INFO - 2018-05-08 12:56:10 --> Controller Class Initialized
INFO - 2018-05-08 12:56:10 --> Model Class Initialized
INFO - 2018-05-08 12:56:10 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:56:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:56:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:56:10 --> Model Class Initialized
INFO - 2018-05-08 12:56:10 --> Model Class Initialized
INFO - 2018-05-08 12:56:10 --> Model Class Initialized
INFO - 2018-05-08 12:56:10 --> Model Class Initialized
INFO - 2018-05-08 12:56:10 --> Model Class Initialized
INFO - 2018-05-08 12:56:10 --> Model Class Initialized
INFO - 2018-05-08 12:56:10 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:56:10 --> Model Class Initialized
INFO - 2018-05-08 12:56:10 --> Model Class Initialized
INFO - 2018-05-08 12:56:10 --> Model Class Initialized
INFO - 2018-05-08 12:56:10 --> Final output sent to browser
DEBUG - 2018-05-08 12:56:10 --> Total execution time: 0.2391
INFO - 2018-05-08 07:26:13 --> Config Class Initialized
INFO - 2018-05-08 07:26:13 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:26:13 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:26:13 --> Utf8 Class Initialized
INFO - 2018-05-08 07:26:13 --> URI Class Initialized
INFO - 2018-05-08 07:26:13 --> Router Class Initialized
INFO - 2018-05-08 07:26:13 --> Output Class Initialized
INFO - 2018-05-08 07:26:13 --> Security Class Initialized
DEBUG - 2018-05-08 07:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:26:13 --> Input Class Initialized
INFO - 2018-05-08 07:26:13 --> Language Class Initialized
INFO - 2018-05-08 07:26:13 --> Language Class Initialized
INFO - 2018-05-08 07:26:13 --> Config Class Initialized
INFO - 2018-05-08 07:26:13 --> Loader Class Initialized
INFO - 2018-05-08 12:56:13 --> Helper loaded: url_helper
INFO - 2018-05-08 12:56:13 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:56:13 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:56:13 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:56:13 --> Helper loaded: users_helper
INFO - 2018-05-08 12:56:13 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:56:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:56:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:56:13 --> Helper loaded: form_helper
INFO - 2018-05-08 12:56:13 --> Form Validation Class Initialized
INFO - 2018-05-08 12:56:13 --> Controller Class Initialized
INFO - 2018-05-08 12:56:13 --> Model Class Initialized
INFO - 2018-05-08 12:56:13 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:56:13 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:56:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:56:13 --> Model Class Initialized
INFO - 2018-05-08 12:56:13 --> Model Class Initialized
INFO - 2018-05-08 12:56:13 --> Model Class Initialized
INFO - 2018-05-08 12:56:13 --> Model Class Initialized
INFO - 2018-05-08 12:56:13 --> Model Class Initialized
INFO - 2018-05-08 12:56:13 --> Model Class Initialized
INFO - 2018-05-08 12:56:13 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:56:13 --> Model Class Initialized
INFO - 2018-05-08 12:56:13 --> Model Class Initialized
INFO - 2018-05-08 12:56:13 --> Final output sent to browser
DEBUG - 2018-05-08 12:56:13 --> Total execution time: 0.1348
INFO - 2018-05-08 07:26:14 --> Config Class Initialized
INFO - 2018-05-08 07:26:14 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:26:14 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:26:14 --> Utf8 Class Initialized
INFO - 2018-05-08 07:26:14 --> URI Class Initialized
INFO - 2018-05-08 07:26:14 --> Router Class Initialized
INFO - 2018-05-08 07:26:14 --> Output Class Initialized
INFO - 2018-05-08 07:26:14 --> Security Class Initialized
DEBUG - 2018-05-08 07:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:26:14 --> Input Class Initialized
INFO - 2018-05-08 07:26:14 --> Language Class Initialized
INFO - 2018-05-08 07:26:14 --> Language Class Initialized
INFO - 2018-05-08 07:26:14 --> Config Class Initialized
INFO - 2018-05-08 07:26:14 --> Loader Class Initialized
INFO - 2018-05-08 12:56:14 --> Helper loaded: url_helper
INFO - 2018-05-08 12:56:14 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:56:14 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:56:14 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:56:14 --> Helper loaded: users_helper
INFO - 2018-05-08 12:56:14 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:56:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:56:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:56:14 --> Helper loaded: form_helper
INFO - 2018-05-08 12:56:14 --> Form Validation Class Initialized
INFO - 2018-05-08 12:56:14 --> Controller Class Initialized
INFO - 2018-05-08 12:56:14 --> Model Class Initialized
INFO - 2018-05-08 12:56:14 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:56:14 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:56:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:56:14 --> Model Class Initialized
INFO - 2018-05-08 12:56:14 --> Model Class Initialized
INFO - 2018-05-08 12:56:14 --> Model Class Initialized
INFO - 2018-05-08 12:56:14 --> Model Class Initialized
INFO - 2018-05-08 12:56:14 --> Model Class Initialized
INFO - 2018-05-08 12:56:14 --> Model Class Initialized
INFO - 2018-05-08 12:56:14 --> Model Class Initialized
INFO - 2018-05-08 12:56:14 --> Model Class Initialized
INFO - 2018-05-08 12:56:14 --> Model Class Initialized
INFO - 2018-05-08 12:56:14 --> Model Class Initialized
INFO - 2018-05-08 12:56:14 --> Model Class Initialized
INFO - 2018-05-08 12:56:14 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:56:14 --> Model Class Initialized
INFO - 2018-05-08 12:56:14 --> Final output sent to browser
DEBUG - 2018-05-08 12:56:14 --> Total execution time: 0.1665
INFO - 2018-05-08 07:26:19 --> Config Class Initialized
INFO - 2018-05-08 07:26:19 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:26:19 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:26:19 --> Utf8 Class Initialized
INFO - 2018-05-08 07:26:19 --> URI Class Initialized
INFO - 2018-05-08 07:26:19 --> Router Class Initialized
INFO - 2018-05-08 07:26:19 --> Output Class Initialized
INFO - 2018-05-08 07:26:19 --> Security Class Initialized
DEBUG - 2018-05-08 07:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:26:19 --> Input Class Initialized
INFO - 2018-05-08 07:26:19 --> Language Class Initialized
INFO - 2018-05-08 07:26:19 --> Language Class Initialized
INFO - 2018-05-08 07:26:19 --> Config Class Initialized
INFO - 2018-05-08 07:26:19 --> Loader Class Initialized
INFO - 2018-05-08 12:56:19 --> Helper loaded: url_helper
INFO - 2018-05-08 12:56:19 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:56:19 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:56:19 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:56:19 --> Helper loaded: users_helper
INFO - 2018-05-08 12:56:19 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:56:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:56:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:56:19 --> Helper loaded: form_helper
INFO - 2018-05-08 12:56:19 --> Form Validation Class Initialized
INFO - 2018-05-08 12:56:19 --> Controller Class Initialized
INFO - 2018-05-08 12:56:20 --> Model Class Initialized
INFO - 2018-05-08 12:56:20 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:56:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:56:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:56:20 --> Model Class Initialized
INFO - 2018-05-08 12:56:20 --> Model Class Initialized
INFO - 2018-05-08 12:56:20 --> Model Class Initialized
INFO - 2018-05-08 12:56:20 --> Model Class Initialized
INFO - 2018-05-08 12:56:20 --> Model Class Initialized
INFO - 2018-05-08 12:56:20 --> Model Class Initialized
INFO - 2018-05-08 12:56:20 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:56:20 --> Model Class Initialized
INFO - 2018-05-08 12:56:20 --> Model Class Initialized
INFO - 2018-05-08 12:56:20 --> Final output sent to browser
DEBUG - 2018-05-08 12:56:20 --> Total execution time: 0.1201
INFO - 2018-05-08 07:26:21 --> Config Class Initialized
INFO - 2018-05-08 07:26:21 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:26:21 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:26:21 --> Utf8 Class Initialized
INFO - 2018-05-08 07:26:21 --> URI Class Initialized
INFO - 2018-05-08 07:26:21 --> Router Class Initialized
INFO - 2018-05-08 07:26:21 --> Output Class Initialized
INFO - 2018-05-08 07:26:21 --> Security Class Initialized
DEBUG - 2018-05-08 07:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:26:21 --> Input Class Initialized
INFO - 2018-05-08 07:26:21 --> Language Class Initialized
INFO - 2018-05-08 07:26:21 --> Language Class Initialized
INFO - 2018-05-08 07:26:21 --> Config Class Initialized
INFO - 2018-05-08 07:26:21 --> Loader Class Initialized
INFO - 2018-05-08 12:56:21 --> Helper loaded: url_helper
INFO - 2018-05-08 12:56:21 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:56:21 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:56:21 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:56:21 --> Helper loaded: users_helper
INFO - 2018-05-08 12:56:21 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:56:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:56:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:56:21 --> Helper loaded: form_helper
INFO - 2018-05-08 12:56:21 --> Form Validation Class Initialized
INFO - 2018-05-08 12:56:21 --> Controller Class Initialized
INFO - 2018-05-08 12:56:21 --> Model Class Initialized
INFO - 2018-05-08 12:56:21 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:56:21 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:56:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:56:21 --> Model Class Initialized
INFO - 2018-05-08 12:56:21 --> Model Class Initialized
INFO - 2018-05-08 12:56:21 --> Model Class Initialized
INFO - 2018-05-08 12:56:21 --> Model Class Initialized
INFO - 2018-05-08 12:56:21 --> Model Class Initialized
INFO - 2018-05-08 12:56:21 --> Model Class Initialized
INFO - 2018-05-08 12:56:21 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:56:21 --> Model Class Initialized
INFO - 2018-05-08 12:56:21 --> Model Class Initialized
INFO - 2018-05-08 12:56:21 --> Final output sent to browser
DEBUG - 2018-05-08 12:56:21 --> Total execution time: 0.1213
INFO - 2018-05-08 07:26:22 --> Config Class Initialized
INFO - 2018-05-08 07:26:22 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:26:22 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:26:22 --> Utf8 Class Initialized
INFO - 2018-05-08 07:26:22 --> URI Class Initialized
INFO - 2018-05-08 07:26:22 --> Router Class Initialized
INFO - 2018-05-08 07:26:22 --> Output Class Initialized
INFO - 2018-05-08 07:26:22 --> Security Class Initialized
DEBUG - 2018-05-08 07:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:26:22 --> Input Class Initialized
INFO - 2018-05-08 07:26:22 --> Language Class Initialized
INFO - 2018-05-08 07:26:22 --> Language Class Initialized
INFO - 2018-05-08 07:26:22 --> Config Class Initialized
INFO - 2018-05-08 07:26:22 --> Loader Class Initialized
INFO - 2018-05-08 12:56:22 --> Helper loaded: url_helper
INFO - 2018-05-08 12:56:22 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:56:22 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:56:22 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:56:22 --> Helper loaded: users_helper
INFO - 2018-05-08 12:56:22 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:56:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:56:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:56:22 --> Helper loaded: form_helper
INFO - 2018-05-08 12:56:22 --> Form Validation Class Initialized
INFO - 2018-05-08 12:56:22 --> Controller Class Initialized
INFO - 2018-05-08 12:56:22 --> Model Class Initialized
INFO - 2018-05-08 12:56:22 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:56:22 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:56:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:56:22 --> Model Class Initialized
INFO - 2018-05-08 12:56:22 --> Model Class Initialized
INFO - 2018-05-08 12:56:22 --> Model Class Initialized
INFO - 2018-05-08 12:56:22 --> Model Class Initialized
INFO - 2018-05-08 12:56:22 --> Model Class Initialized
INFO - 2018-05-08 12:56:22 --> Model Class Initialized
INFO - 2018-05-08 12:56:22 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:56:22 --> Model Class Initialized
INFO - 2018-05-08 12:56:22 --> Model Class Initialized
INFO - 2018-05-08 12:56:22 --> Final output sent to browser
DEBUG - 2018-05-08 12:56:22 --> Total execution time: 0.0823
INFO - 2018-05-08 07:26:23 --> Config Class Initialized
INFO - 2018-05-08 07:26:23 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:26:23 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:26:23 --> Utf8 Class Initialized
INFO - 2018-05-08 07:26:23 --> URI Class Initialized
INFO - 2018-05-08 07:26:23 --> Router Class Initialized
INFO - 2018-05-08 07:26:23 --> Output Class Initialized
INFO - 2018-05-08 07:26:23 --> Security Class Initialized
DEBUG - 2018-05-08 07:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:26:23 --> Input Class Initialized
INFO - 2018-05-08 07:26:23 --> Language Class Initialized
INFO - 2018-05-08 07:26:23 --> Language Class Initialized
INFO - 2018-05-08 07:26:23 --> Config Class Initialized
INFO - 2018-05-08 07:26:23 --> Loader Class Initialized
INFO - 2018-05-08 12:56:23 --> Helper loaded: url_helper
INFO - 2018-05-08 12:56:23 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:56:23 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:56:23 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:56:23 --> Helper loaded: users_helper
INFO - 2018-05-08 12:56:23 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:56:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:56:23 --> Helper loaded: form_helper
INFO - 2018-05-08 12:56:23 --> Form Validation Class Initialized
INFO - 2018-05-08 12:56:23 --> Controller Class Initialized
INFO - 2018-05-08 12:56:23 --> Model Class Initialized
INFO - 2018-05-08 12:56:23 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:56:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:56:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:56:23 --> Model Class Initialized
INFO - 2018-05-08 12:56:23 --> Model Class Initialized
INFO - 2018-05-08 12:56:23 --> Model Class Initialized
INFO - 2018-05-08 12:56:23 --> Model Class Initialized
INFO - 2018-05-08 12:56:23 --> Model Class Initialized
INFO - 2018-05-08 12:56:23 --> Model Class Initialized
INFO - 2018-05-08 12:56:23 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:56:23 --> Model Class Initialized
INFO - 2018-05-08 12:56:23 --> Model Class Initialized
INFO - 2018-05-08 12:56:23 --> Final output sent to browser
DEBUG - 2018-05-08 12:56:23 --> Total execution time: 0.1274
INFO - 2018-05-08 07:26:27 --> Config Class Initialized
INFO - 2018-05-08 07:26:27 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:26:27 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:26:27 --> Utf8 Class Initialized
INFO - 2018-05-08 07:26:27 --> URI Class Initialized
INFO - 2018-05-08 07:26:27 --> Router Class Initialized
INFO - 2018-05-08 07:26:27 --> Output Class Initialized
INFO - 2018-05-08 07:26:27 --> Security Class Initialized
DEBUG - 2018-05-08 07:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:26:27 --> Input Class Initialized
INFO - 2018-05-08 07:26:27 --> Language Class Initialized
INFO - 2018-05-08 07:26:27 --> Language Class Initialized
INFO - 2018-05-08 07:26:27 --> Config Class Initialized
INFO - 2018-05-08 07:26:27 --> Loader Class Initialized
INFO - 2018-05-08 12:56:27 --> Helper loaded: url_helper
INFO - 2018-05-08 12:56:27 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:56:27 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:56:27 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:56:27 --> Helper loaded: users_helper
INFO - 2018-05-08 12:56:27 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:56:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:56:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:56:27 --> Helper loaded: form_helper
INFO - 2018-05-08 12:56:27 --> Form Validation Class Initialized
INFO - 2018-05-08 12:56:27 --> Controller Class Initialized
INFO - 2018-05-08 12:56:27 --> Model Class Initialized
INFO - 2018-05-08 12:56:27 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:56:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:56:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:56:27 --> Model Class Initialized
INFO - 2018-05-08 12:56:27 --> Model Class Initialized
INFO - 2018-05-08 12:56:27 --> Model Class Initialized
INFO - 2018-05-08 12:56:27 --> Model Class Initialized
INFO - 2018-05-08 12:56:27 --> Model Class Initialized
INFO - 2018-05-08 12:56:27 --> Model Class Initialized
INFO - 2018-05-08 12:56:27 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:56:27 --> Model Class Initialized
INFO - 2018-05-08 12:56:27 --> Model Class Initialized
INFO - 2018-05-08 12:56:27 --> Final output sent to browser
DEBUG - 2018-05-08 12:56:27 --> Total execution time: 0.1421
INFO - 2018-05-08 07:26:27 --> Config Class Initialized
INFO - 2018-05-08 07:26:27 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:26:27 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:26:27 --> Utf8 Class Initialized
INFO - 2018-05-08 07:26:27 --> URI Class Initialized
INFO - 2018-05-08 07:26:27 --> Router Class Initialized
INFO - 2018-05-08 07:26:27 --> Output Class Initialized
INFO - 2018-05-08 07:26:27 --> Security Class Initialized
DEBUG - 2018-05-08 07:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:26:27 --> Input Class Initialized
INFO - 2018-05-08 07:26:27 --> Language Class Initialized
INFO - 2018-05-08 07:26:28 --> Language Class Initialized
INFO - 2018-05-08 07:26:28 --> Config Class Initialized
INFO - 2018-05-08 07:26:28 --> Loader Class Initialized
INFO - 2018-05-08 12:56:28 --> Helper loaded: url_helper
INFO - 2018-05-08 12:56:28 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:56:28 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:56:28 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:56:28 --> Helper loaded: users_helper
INFO - 2018-05-08 12:56:28 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:56:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:56:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:56:28 --> Helper loaded: form_helper
INFO - 2018-05-08 12:56:28 --> Form Validation Class Initialized
INFO - 2018-05-08 12:56:28 --> Controller Class Initialized
INFO - 2018-05-08 12:56:28 --> Model Class Initialized
INFO - 2018-05-08 12:56:28 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:56:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:56:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:56:28 --> Model Class Initialized
INFO - 2018-05-08 12:56:28 --> Model Class Initialized
INFO - 2018-05-08 12:56:28 --> Model Class Initialized
INFO - 2018-05-08 12:56:28 --> Model Class Initialized
INFO - 2018-05-08 12:56:28 --> Model Class Initialized
INFO - 2018-05-08 12:56:28 --> Model Class Initialized
INFO - 2018-05-08 12:56:28 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:56:28 --> Model Class Initialized
INFO - 2018-05-08 12:56:28 --> Model Class Initialized
INFO - 2018-05-08 12:56:28 --> Final output sent to browser
DEBUG - 2018-05-08 12:56:28 --> Total execution time: 0.1762
INFO - 2018-05-08 07:26:29 --> Config Class Initialized
INFO - 2018-05-08 07:26:29 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:26:29 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:26:29 --> Utf8 Class Initialized
INFO - 2018-05-08 07:26:29 --> URI Class Initialized
INFO - 2018-05-08 07:26:29 --> Router Class Initialized
INFO - 2018-05-08 07:26:29 --> Output Class Initialized
INFO - 2018-05-08 07:26:29 --> Security Class Initialized
DEBUG - 2018-05-08 07:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:26:29 --> Input Class Initialized
INFO - 2018-05-08 07:26:29 --> Language Class Initialized
INFO - 2018-05-08 07:26:29 --> Language Class Initialized
INFO - 2018-05-08 07:26:29 --> Config Class Initialized
INFO - 2018-05-08 07:26:29 --> Loader Class Initialized
INFO - 2018-05-08 12:56:29 --> Helper loaded: url_helper
INFO - 2018-05-08 12:56:29 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:56:29 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:56:29 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:56:29 --> Helper loaded: users_helper
INFO - 2018-05-08 12:56:29 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:56:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:56:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:56:29 --> Helper loaded: form_helper
INFO - 2018-05-08 12:56:29 --> Form Validation Class Initialized
INFO - 2018-05-08 12:56:29 --> Controller Class Initialized
INFO - 2018-05-08 12:56:29 --> Model Class Initialized
INFO - 2018-05-08 12:56:29 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:56:29 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:56:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:56:29 --> Model Class Initialized
INFO - 2018-05-08 12:56:29 --> Model Class Initialized
INFO - 2018-05-08 12:56:29 --> Model Class Initialized
INFO - 2018-05-08 12:56:29 --> Model Class Initialized
INFO - 2018-05-08 12:56:29 --> Model Class Initialized
INFO - 2018-05-08 12:56:29 --> Model Class Initialized
INFO - 2018-05-08 12:56:29 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:56:29 --> Model Class Initialized
INFO - 2018-05-08 12:56:29 --> Model Class Initialized
INFO - 2018-05-08 12:56:29 --> Final output sent to browser
DEBUG - 2018-05-08 12:56:29 --> Total execution time: 0.1353
INFO - 2018-05-08 07:26:30 --> Config Class Initialized
INFO - 2018-05-08 07:26:30 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:26:30 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:26:30 --> Utf8 Class Initialized
INFO - 2018-05-08 07:26:30 --> URI Class Initialized
INFO - 2018-05-08 07:26:30 --> Router Class Initialized
INFO - 2018-05-08 07:26:30 --> Output Class Initialized
INFO - 2018-05-08 07:26:30 --> Security Class Initialized
DEBUG - 2018-05-08 07:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:26:30 --> Input Class Initialized
INFO - 2018-05-08 07:26:30 --> Language Class Initialized
INFO - 2018-05-08 07:26:30 --> Language Class Initialized
INFO - 2018-05-08 07:26:30 --> Config Class Initialized
INFO - 2018-05-08 07:26:30 --> Loader Class Initialized
INFO - 2018-05-08 12:56:30 --> Helper loaded: url_helper
INFO - 2018-05-08 12:56:30 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:56:30 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:56:30 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:56:30 --> Helper loaded: users_helper
INFO - 2018-05-08 12:56:30 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:56:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:56:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:56:30 --> Helper loaded: form_helper
INFO - 2018-05-08 12:56:30 --> Form Validation Class Initialized
INFO - 2018-05-08 12:56:30 --> Controller Class Initialized
INFO - 2018-05-08 12:56:30 --> Model Class Initialized
INFO - 2018-05-08 12:56:30 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:56:30 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:56:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:56:30 --> Model Class Initialized
INFO - 2018-05-08 12:56:30 --> Model Class Initialized
INFO - 2018-05-08 12:56:30 --> Model Class Initialized
INFO - 2018-05-08 12:56:30 --> Model Class Initialized
INFO - 2018-05-08 12:56:30 --> Model Class Initialized
INFO - 2018-05-08 12:56:30 --> Model Class Initialized
INFO - 2018-05-08 12:56:30 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:56:30 --> Model Class Initialized
INFO - 2018-05-08 12:56:30 --> Model Class Initialized
INFO - 2018-05-08 12:56:30 --> Final output sent to browser
DEBUG - 2018-05-08 12:56:30 --> Total execution time: 0.1439
INFO - 2018-05-08 07:26:31 --> Config Class Initialized
INFO - 2018-05-08 07:26:31 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:26:31 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:26:31 --> Utf8 Class Initialized
INFO - 2018-05-08 07:26:31 --> URI Class Initialized
INFO - 2018-05-08 07:26:31 --> Router Class Initialized
INFO - 2018-05-08 07:26:31 --> Output Class Initialized
INFO - 2018-05-08 07:26:31 --> Security Class Initialized
DEBUG - 2018-05-08 07:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:26:31 --> Input Class Initialized
INFO - 2018-05-08 07:26:31 --> Language Class Initialized
INFO - 2018-05-08 07:26:31 --> Language Class Initialized
INFO - 2018-05-08 07:26:31 --> Config Class Initialized
INFO - 2018-05-08 07:26:31 --> Loader Class Initialized
INFO - 2018-05-08 12:56:31 --> Helper loaded: url_helper
INFO - 2018-05-08 12:56:31 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:56:31 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:56:31 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:56:31 --> Helper loaded: users_helper
INFO - 2018-05-08 12:56:31 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:56:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:56:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:56:31 --> Helper loaded: form_helper
INFO - 2018-05-08 12:56:31 --> Form Validation Class Initialized
INFO - 2018-05-08 12:56:31 --> Controller Class Initialized
INFO - 2018-05-08 12:56:31 --> Model Class Initialized
INFO - 2018-05-08 12:56:31 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:56:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:56:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:56:31 --> Model Class Initialized
INFO - 2018-05-08 12:56:31 --> Model Class Initialized
INFO - 2018-05-08 12:56:31 --> Model Class Initialized
INFO - 2018-05-08 12:56:31 --> Model Class Initialized
INFO - 2018-05-08 12:56:31 --> Model Class Initialized
INFO - 2018-05-08 12:56:31 --> Model Class Initialized
INFO - 2018-05-08 12:56:31 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:56:31 --> Model Class Initialized
INFO - 2018-05-08 12:56:31 --> Model Class Initialized
INFO - 2018-05-08 12:56:31 --> Final output sent to browser
DEBUG - 2018-05-08 12:56:31 --> Total execution time: 0.1123
INFO - 2018-05-08 07:26:32 --> Config Class Initialized
INFO - 2018-05-08 07:26:32 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:26:32 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:26:32 --> Utf8 Class Initialized
INFO - 2018-05-08 07:26:32 --> URI Class Initialized
INFO - 2018-05-08 07:26:32 --> Router Class Initialized
INFO - 2018-05-08 07:26:32 --> Output Class Initialized
INFO - 2018-05-08 07:26:32 --> Security Class Initialized
DEBUG - 2018-05-08 07:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:26:32 --> Input Class Initialized
INFO - 2018-05-08 07:26:32 --> Language Class Initialized
INFO - 2018-05-08 07:26:32 --> Language Class Initialized
INFO - 2018-05-08 07:26:32 --> Config Class Initialized
INFO - 2018-05-08 07:26:32 --> Loader Class Initialized
INFO - 2018-05-08 12:56:32 --> Helper loaded: url_helper
INFO - 2018-05-08 12:56:32 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:56:32 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:56:32 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:56:32 --> Helper loaded: users_helper
INFO - 2018-05-08 12:56:32 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:56:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:56:32 --> Helper loaded: form_helper
INFO - 2018-05-08 12:56:32 --> Form Validation Class Initialized
INFO - 2018-05-08 12:56:32 --> Controller Class Initialized
INFO - 2018-05-08 12:56:32 --> Model Class Initialized
INFO - 2018-05-08 12:56:32 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:56:32 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:56:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:56:32 --> Model Class Initialized
INFO - 2018-05-08 12:56:32 --> Model Class Initialized
INFO - 2018-05-08 12:56:32 --> Model Class Initialized
INFO - 2018-05-08 12:56:32 --> Model Class Initialized
INFO - 2018-05-08 12:56:32 --> Model Class Initialized
INFO - 2018-05-08 12:56:32 --> Model Class Initialized
INFO - 2018-05-08 12:56:32 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:56:32 --> Model Class Initialized
INFO - 2018-05-08 12:56:32 --> Model Class Initialized
INFO - 2018-05-08 12:56:32 --> Final output sent to browser
DEBUG - 2018-05-08 12:56:32 --> Total execution time: 0.1184
INFO - 2018-05-08 07:26:34 --> Config Class Initialized
INFO - 2018-05-08 07:26:34 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:26:34 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:26:34 --> Utf8 Class Initialized
INFO - 2018-05-08 07:26:34 --> URI Class Initialized
INFO - 2018-05-08 07:26:34 --> Router Class Initialized
INFO - 2018-05-08 07:26:34 --> Output Class Initialized
INFO - 2018-05-08 07:26:34 --> Security Class Initialized
DEBUG - 2018-05-08 07:26:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:26:34 --> Input Class Initialized
INFO - 2018-05-08 07:26:34 --> Language Class Initialized
INFO - 2018-05-08 07:26:34 --> Language Class Initialized
INFO - 2018-05-08 07:26:34 --> Config Class Initialized
INFO - 2018-05-08 07:26:34 --> Loader Class Initialized
INFO - 2018-05-08 12:56:34 --> Helper loaded: url_helper
INFO - 2018-05-08 12:56:34 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:56:34 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:56:34 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:56:34 --> Helper loaded: users_helper
INFO - 2018-05-08 12:56:34 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:56:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:56:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:56:34 --> Helper loaded: form_helper
INFO - 2018-05-08 12:56:34 --> Form Validation Class Initialized
INFO - 2018-05-08 12:56:34 --> Controller Class Initialized
INFO - 2018-05-08 12:56:34 --> Model Class Initialized
INFO - 2018-05-08 12:56:34 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:56:34 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:56:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:56:34 --> Model Class Initialized
INFO - 2018-05-08 12:56:34 --> Model Class Initialized
INFO - 2018-05-08 12:56:34 --> Model Class Initialized
INFO - 2018-05-08 12:56:34 --> Model Class Initialized
INFO - 2018-05-08 12:56:34 --> Model Class Initialized
INFO - 2018-05-08 12:56:34 --> Model Class Initialized
INFO - 2018-05-08 12:56:34 --> Model Class Initialized
INFO - 2018-05-08 12:56:34 --> Model Class Initialized
INFO - 2018-05-08 12:56:34 --> Model Class Initialized
INFO - 2018-05-08 12:56:34 --> Model Class Initialized
INFO - 2018-05-08 12:56:34 --> Model Class Initialized
INFO - 2018-05-08 12:56:34 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:56:34 --> Model Class Initialized
INFO - 2018-05-08 12:56:34 --> Final output sent to browser
DEBUG - 2018-05-08 12:56:34 --> Total execution time: 0.1946
INFO - 2018-05-08 07:26:36 --> Config Class Initialized
INFO - 2018-05-08 07:26:36 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:26:36 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:26:36 --> Utf8 Class Initialized
INFO - 2018-05-08 07:26:36 --> URI Class Initialized
INFO - 2018-05-08 07:26:36 --> Router Class Initialized
INFO - 2018-05-08 07:26:36 --> Output Class Initialized
INFO - 2018-05-08 07:26:36 --> Security Class Initialized
DEBUG - 2018-05-08 07:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:26:36 --> Input Class Initialized
INFO - 2018-05-08 07:26:36 --> Language Class Initialized
INFO - 2018-05-08 07:26:36 --> Language Class Initialized
INFO - 2018-05-08 07:26:36 --> Config Class Initialized
INFO - 2018-05-08 07:26:36 --> Loader Class Initialized
INFO - 2018-05-08 12:56:36 --> Helper loaded: url_helper
INFO - 2018-05-08 12:56:36 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:56:36 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:56:36 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:56:36 --> Helper loaded: users_helper
INFO - 2018-05-08 12:56:36 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:56:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:56:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:56:36 --> Helper loaded: form_helper
INFO - 2018-05-08 12:56:36 --> Form Validation Class Initialized
INFO - 2018-05-08 12:56:36 --> Controller Class Initialized
INFO - 2018-05-08 12:56:36 --> Model Class Initialized
INFO - 2018-05-08 12:56:36 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:56:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:56:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:56:37 --> Model Class Initialized
INFO - 2018-05-08 12:56:37 --> Model Class Initialized
INFO - 2018-05-08 12:56:37 --> Model Class Initialized
INFO - 2018-05-08 12:56:37 --> Model Class Initialized
INFO - 2018-05-08 12:56:37 --> Model Class Initialized
INFO - 2018-05-08 12:56:37 --> Model Class Initialized
INFO - 2018-05-08 12:56:37 --> Model Class Initialized
INFO - 2018-05-08 12:56:37 --> Model Class Initialized
INFO - 2018-05-08 12:56:37 --> Model Class Initialized
INFO - 2018-05-08 12:56:37 --> Model Class Initialized
INFO - 2018-05-08 12:56:37 --> Model Class Initialized
INFO - 2018-05-08 12:56:37 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:56:37 --> Model Class Initialized
INFO - 2018-05-08 12:56:37 --> Final output sent to browser
DEBUG - 2018-05-08 12:56:37 --> Total execution time: 0.1509
INFO - 2018-05-08 07:26:37 --> Config Class Initialized
INFO - 2018-05-08 07:26:37 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:26:37 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:26:37 --> Utf8 Class Initialized
INFO - 2018-05-08 07:26:37 --> URI Class Initialized
INFO - 2018-05-08 07:26:37 --> Router Class Initialized
INFO - 2018-05-08 07:26:37 --> Output Class Initialized
INFO - 2018-05-08 07:26:37 --> Security Class Initialized
DEBUG - 2018-05-08 07:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:26:37 --> Input Class Initialized
INFO - 2018-05-08 07:26:37 --> Language Class Initialized
INFO - 2018-05-08 07:26:37 --> Language Class Initialized
INFO - 2018-05-08 07:26:37 --> Config Class Initialized
INFO - 2018-05-08 07:26:37 --> Loader Class Initialized
INFO - 2018-05-08 12:56:37 --> Helper loaded: url_helper
INFO - 2018-05-08 12:56:37 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:56:37 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:56:37 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:56:37 --> Helper loaded: users_helper
INFO - 2018-05-08 12:56:38 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:56:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:56:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:56:38 --> Helper loaded: form_helper
INFO - 2018-05-08 12:56:38 --> Form Validation Class Initialized
INFO - 2018-05-08 12:56:38 --> Controller Class Initialized
INFO - 2018-05-08 12:56:38 --> Model Class Initialized
INFO - 2018-05-08 12:56:38 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:56:38 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:56:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:56:38 --> Model Class Initialized
INFO - 2018-05-08 12:56:38 --> Model Class Initialized
INFO - 2018-05-08 12:56:38 --> Model Class Initialized
INFO - 2018-05-08 12:56:38 --> Model Class Initialized
INFO - 2018-05-08 12:56:38 --> Final output sent to browser
DEBUG - 2018-05-08 12:56:38 --> Total execution time: 0.1730
INFO - 2018-05-08 07:26:40 --> Config Class Initialized
INFO - 2018-05-08 07:26:40 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:26:40 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:26:40 --> Utf8 Class Initialized
INFO - 2018-05-08 07:26:40 --> URI Class Initialized
INFO - 2018-05-08 07:26:40 --> Router Class Initialized
INFO - 2018-05-08 07:26:40 --> Output Class Initialized
INFO - 2018-05-08 07:26:40 --> Security Class Initialized
DEBUG - 2018-05-08 07:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:26:40 --> Input Class Initialized
INFO - 2018-05-08 07:26:40 --> Language Class Initialized
INFO - 2018-05-08 07:26:40 --> Language Class Initialized
INFO - 2018-05-08 07:26:40 --> Config Class Initialized
INFO - 2018-05-08 07:26:40 --> Loader Class Initialized
INFO - 2018-05-08 12:56:40 --> Helper loaded: url_helper
INFO - 2018-05-08 12:56:40 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:56:40 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:56:40 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:56:40 --> Helper loaded: users_helper
INFO - 2018-05-08 12:56:40 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:56:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:56:40 --> Helper loaded: form_helper
INFO - 2018-05-08 12:56:40 --> Form Validation Class Initialized
INFO - 2018-05-08 12:56:40 --> Controller Class Initialized
INFO - 2018-05-08 12:56:40 --> Model Class Initialized
INFO - 2018-05-08 12:56:40 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:56:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:56:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:56:40 --> Model Class Initialized
INFO - 2018-05-08 12:56:40 --> Model Class Initialized
INFO - 2018-05-08 12:56:40 --> Model Class Initialized
INFO - 2018-05-08 12:56:40 --> Model Class Initialized
INFO - 2018-05-08 12:56:40 --> Final output sent to browser
DEBUG - 2018-05-08 12:56:40 --> Total execution time: 0.1079
INFO - 2018-05-08 07:26:42 --> Config Class Initialized
INFO - 2018-05-08 07:26:42 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:26:42 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:26:42 --> Utf8 Class Initialized
INFO - 2018-05-08 07:26:42 --> URI Class Initialized
INFO - 2018-05-08 07:26:42 --> Router Class Initialized
INFO - 2018-05-08 07:26:42 --> Output Class Initialized
INFO - 2018-05-08 07:26:42 --> Security Class Initialized
DEBUG - 2018-05-08 07:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:26:42 --> Input Class Initialized
INFO - 2018-05-08 07:26:42 --> Language Class Initialized
INFO - 2018-05-08 07:26:42 --> Language Class Initialized
INFO - 2018-05-08 07:26:42 --> Config Class Initialized
INFO - 2018-05-08 07:26:42 --> Loader Class Initialized
INFO - 2018-05-08 12:56:42 --> Helper loaded: url_helper
INFO - 2018-05-08 12:56:42 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:56:42 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:56:42 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:56:42 --> Helper loaded: users_helper
INFO - 2018-05-08 12:56:42 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:56:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:56:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:56:42 --> Helper loaded: form_helper
INFO - 2018-05-08 12:56:42 --> Form Validation Class Initialized
INFO - 2018-05-08 12:56:42 --> Controller Class Initialized
INFO - 2018-05-08 12:56:42 --> Model Class Initialized
INFO - 2018-05-08 12:56:42 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:56:42 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:56:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:56:42 --> Model Class Initialized
INFO - 2018-05-08 12:56:42 --> Model Class Initialized
INFO - 2018-05-08 12:56:42 --> Model Class Initialized
INFO - 2018-05-08 12:56:42 --> Model Class Initialized
INFO - 2018-05-08 12:56:42 --> Final output sent to browser
DEBUG - 2018-05-08 12:56:42 --> Total execution time: 0.1306
INFO - 2018-05-08 07:26:43 --> Config Class Initialized
INFO - 2018-05-08 07:26:43 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:26:43 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:26:43 --> Utf8 Class Initialized
INFO - 2018-05-08 07:26:43 --> URI Class Initialized
INFO - 2018-05-08 07:26:43 --> Router Class Initialized
INFO - 2018-05-08 07:26:43 --> Output Class Initialized
INFO - 2018-05-08 07:26:43 --> Security Class Initialized
DEBUG - 2018-05-08 07:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:26:43 --> Input Class Initialized
INFO - 2018-05-08 07:26:43 --> Language Class Initialized
INFO - 2018-05-08 07:26:43 --> Language Class Initialized
INFO - 2018-05-08 07:26:43 --> Config Class Initialized
INFO - 2018-05-08 07:26:43 --> Loader Class Initialized
INFO - 2018-05-08 12:56:43 --> Helper loaded: url_helper
INFO - 2018-05-08 12:56:43 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:56:43 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:56:43 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:56:43 --> Helper loaded: users_helper
INFO - 2018-05-08 12:56:43 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:56:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:56:43 --> Helper loaded: form_helper
INFO - 2018-05-08 12:56:43 --> Form Validation Class Initialized
INFO - 2018-05-08 12:56:43 --> Controller Class Initialized
INFO - 2018-05-08 12:56:43 --> Model Class Initialized
INFO - 2018-05-08 12:56:43 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:56:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:56:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:56:43 --> Model Class Initialized
INFO - 2018-05-08 12:56:43 --> Model Class Initialized
INFO - 2018-05-08 12:56:43 --> Model Class Initialized
INFO - 2018-05-08 12:56:43 --> Model Class Initialized
INFO - 2018-05-08 12:56:43 --> Final output sent to browser
DEBUG - 2018-05-08 12:56:43 --> Total execution time: 0.1311
INFO - 2018-05-08 07:26:44 --> Config Class Initialized
INFO - 2018-05-08 07:26:44 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:26:44 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:26:44 --> Utf8 Class Initialized
INFO - 2018-05-08 07:26:44 --> URI Class Initialized
INFO - 2018-05-08 07:26:44 --> Router Class Initialized
INFO - 2018-05-08 07:26:44 --> Output Class Initialized
INFO - 2018-05-08 07:26:44 --> Security Class Initialized
DEBUG - 2018-05-08 07:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:26:44 --> Input Class Initialized
INFO - 2018-05-08 07:26:44 --> Language Class Initialized
INFO - 2018-05-08 07:26:44 --> Language Class Initialized
INFO - 2018-05-08 07:26:44 --> Config Class Initialized
INFO - 2018-05-08 07:26:44 --> Loader Class Initialized
INFO - 2018-05-08 12:56:44 --> Helper loaded: url_helper
INFO - 2018-05-08 12:56:44 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:56:44 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:56:44 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:56:44 --> Helper loaded: users_helper
INFO - 2018-05-08 12:56:44 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:56:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:56:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:56:44 --> Helper loaded: form_helper
INFO - 2018-05-08 12:56:44 --> Form Validation Class Initialized
INFO - 2018-05-08 12:56:44 --> Controller Class Initialized
INFO - 2018-05-08 12:56:44 --> Model Class Initialized
INFO - 2018-05-08 12:56:44 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:56:44 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:56:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:56:44 --> Model Class Initialized
INFO - 2018-05-08 12:56:44 --> Model Class Initialized
INFO - 2018-05-08 12:56:44 --> Model Class Initialized
INFO - 2018-05-08 12:56:44 --> Model Class Initialized
INFO - 2018-05-08 12:56:44 --> Final output sent to browser
DEBUG - 2018-05-08 12:56:44 --> Total execution time: 0.1039
INFO - 2018-05-08 07:26:45 --> Config Class Initialized
INFO - 2018-05-08 07:26:45 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:26:45 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:26:45 --> Utf8 Class Initialized
INFO - 2018-05-08 07:26:45 --> URI Class Initialized
INFO - 2018-05-08 07:26:45 --> Router Class Initialized
INFO - 2018-05-08 07:26:45 --> Output Class Initialized
INFO - 2018-05-08 07:26:45 --> Security Class Initialized
DEBUG - 2018-05-08 07:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:26:45 --> Input Class Initialized
INFO - 2018-05-08 07:26:45 --> Language Class Initialized
INFO - 2018-05-08 07:26:45 --> Language Class Initialized
INFO - 2018-05-08 07:26:45 --> Config Class Initialized
INFO - 2018-05-08 07:26:45 --> Loader Class Initialized
INFO - 2018-05-08 12:56:45 --> Helper loaded: url_helper
INFO - 2018-05-08 12:56:45 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:56:45 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:56:45 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:56:45 --> Helper loaded: users_helper
INFO - 2018-05-08 12:56:45 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:56:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:56:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:56:45 --> Helper loaded: form_helper
INFO - 2018-05-08 12:56:45 --> Form Validation Class Initialized
INFO - 2018-05-08 12:56:45 --> Controller Class Initialized
INFO - 2018-05-08 12:56:45 --> Model Class Initialized
INFO - 2018-05-08 12:56:45 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:56:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:56:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:56:45 --> Model Class Initialized
INFO - 2018-05-08 12:56:45 --> Model Class Initialized
INFO - 2018-05-08 12:56:45 --> Model Class Initialized
INFO - 2018-05-08 12:56:45 --> Model Class Initialized
INFO - 2018-05-08 12:56:45 --> Final output sent to browser
DEBUG - 2018-05-08 12:56:45 --> Total execution time: 0.1078
INFO - 2018-05-08 07:27:07 --> Config Class Initialized
INFO - 2018-05-08 07:27:07 --> Hooks Class Initialized
INFO - 2018-05-08 07:27:07 --> Config Class Initialized
INFO - 2018-05-08 07:27:07 --> Hooks Class Initialized
INFO - 2018-05-08 07:27:07 --> Config Class Initialized
INFO - 2018-05-08 07:27:07 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:27:07 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:27:07 --> Utf8 Class Initialized
DEBUG - 2018-05-08 07:27:07 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:27:07 --> Utf8 Class Initialized
DEBUG - 2018-05-08 07:27:07 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:27:07 --> Utf8 Class Initialized
INFO - 2018-05-08 07:27:07 --> URI Class Initialized
INFO - 2018-05-08 07:27:07 --> URI Class Initialized
INFO - 2018-05-08 07:27:07 --> URI Class Initialized
INFO - 2018-05-08 07:27:07 --> Router Class Initialized
INFO - 2018-05-08 07:27:07 --> Router Class Initialized
INFO - 2018-05-08 07:27:07 --> Router Class Initialized
INFO - 2018-05-08 07:27:07 --> Output Class Initialized
INFO - 2018-05-08 07:27:07 --> Output Class Initialized
INFO - 2018-05-08 07:27:07 --> Output Class Initialized
INFO - 2018-05-08 07:27:07 --> Security Class Initialized
INFO - 2018-05-08 07:27:07 --> Security Class Initialized
DEBUG - 2018-05-08 07:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:27:07 --> Input Class Initialized
INFO - 2018-05-08 07:27:07 --> Language Class Initialized
INFO - 2018-05-08 07:27:07 --> Security Class Initialized
DEBUG - 2018-05-08 07:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:27:07 --> Input Class Initialized
INFO - 2018-05-08 07:27:07 --> Language Class Initialized
DEBUG - 2018-05-08 07:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:27:07 --> Input Class Initialized
INFO - 2018-05-08 07:27:07 --> Language Class Initialized
INFO - 2018-05-08 07:27:07 --> Language Class Initialized
INFO - 2018-05-08 07:27:07 --> Config Class Initialized
INFO - 2018-05-08 07:27:07 --> Loader Class Initialized
INFO - 2018-05-08 12:57:07 --> Helper loaded: url_helper
INFO - 2018-05-08 12:57:07 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:57:07 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:57:07 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:57:07 --> Helper loaded: users_helper
INFO - 2018-05-08 07:27:07 --> Language Class Initialized
INFO - 2018-05-08 07:27:07 --> Config Class Initialized
INFO - 2018-05-08 07:27:07 --> Loader Class Initialized
INFO - 2018-05-08 12:57:07 --> Helper loaded: url_helper
INFO - 2018-05-08 12:57:07 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:57:07 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:57:07 --> Helper loaded: permission_helper
INFO - 2018-05-08 07:27:07 --> Language Class Initialized
INFO - 2018-05-08 12:57:07 --> Helper loaded: users_helper
INFO - 2018-05-08 07:27:07 --> Config Class Initialized
INFO - 2018-05-08 07:27:07 --> Loader Class Initialized
INFO - 2018-05-08 12:57:07 --> Helper loaded: url_helper
INFO - 2018-05-08 12:57:07 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:57:07 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:57:07 --> Database Driver Class Initialized
INFO - 2018-05-08 12:57:07 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:57:07 --> Helper loaded: users_helper
DEBUG - 2018-05-08 12:57:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:57:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:57:07 --> Database Driver Class Initialized
INFO - 2018-05-08 12:57:07 --> Helper loaded: form_helper
INFO - 2018-05-08 12:57:07 --> Form Validation Class Initialized
INFO - 2018-05-08 12:57:07 --> Controller Class Initialized
DEBUG - 2018-05-08 12:57:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:57:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:57:07 --> Database Driver Class Initialized
INFO - 2018-05-08 12:57:07 --> Model Class Initialized
INFO - 2018-05-08 12:57:07 --> Helper loaded: inflector_helper
INFO - 2018-05-08 12:57:07 --> Helper loaded: form_helper
DEBUG - 2018-05-08 12:57:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-05-08 12:57:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:57:07 --> Form Validation Class Initialized
INFO - 2018-05-08 12:57:07 --> Controller Class Initialized
INFO - 2018-05-08 12:57:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:57:07 --> Model Class Initialized
INFO - 2018-05-08 12:57:07 --> Model Class Initialized
INFO - 2018-05-08 12:57:07 --> Model Class Initialized
INFO - 2018-05-08 12:57:07 --> Model Class Initialized
INFO - 2018-05-08 12:57:07 --> Model Class Initialized
INFO - 2018-05-08 12:57:07 --> Model Class Initialized
INFO - 2018-05-08 12:57:07 --> Model Class Initialized
INFO - 2018-05-08 12:57:07 --> Model Class Initialized
INFO - 2018-05-08 12:57:07 --> Model Class Initialized
INFO - 2018-05-08 12:57:07 --> Model Class Initialized
INFO - 2018-05-08 12:57:07 --> Model Class Initialized
INFO - 2018-05-08 12:57:07 --> Model Class Initialized
INFO - 2018-05-08 12:57:07 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:57:07 --> Helper loaded: inflector_helper
INFO - 2018-05-08 12:57:07 --> Model Class Initialized
DEBUG - 2018-05-08 12:57:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:57:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:57:07 --> Model Class Initialized
INFO - 2018-05-08 12:57:07 --> Model Class Initialized
INFO - 2018-05-08 12:57:07 --> Final output sent to browser
DEBUG - 2018-05-08 12:57:07 --> Total execution time: 0.1113
INFO - 2018-05-08 12:57:07 --> Model Class Initialized
INFO - 2018-05-08 12:57:07 --> Model Class Initialized
INFO - 2018-05-08 12:57:07 --> Model Class Initialized
INFO - 2018-05-08 12:57:07 --> Model Class Initialized
INFO - 2018-05-08 12:57:07 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:57:07 --> Final output sent to browser
DEBUG - 2018-05-08 12:57:07 --> Total execution time: 0.1165
INFO - 2018-05-08 12:57:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:57:07 --> Helper loaded: form_helper
INFO - 2018-05-08 12:57:07 --> Form Validation Class Initialized
INFO - 2018-05-08 12:57:07 --> Controller Class Initialized
INFO - 2018-05-08 12:57:07 --> Model Class Initialized
INFO - 2018-05-08 12:57:07 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:57:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:57:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:57:07 --> Model Class Initialized
INFO - 2018-05-08 12:57:07 --> Model Class Initialized
INFO - 2018-05-08 12:57:07 --> Model Class Initialized
INFO - 2018-05-08 12:57:07 --> Model Class Initialized
INFO - 2018-05-08 12:57:07 --> Model Class Initialized
INFO - 2018-05-08 12:57:07 --> Model Class Initialized
INFO - 2018-05-08 12:57:07 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:57:07 --> Model Class Initialized
INFO - 2018-05-08 12:57:07 --> Final output sent to browser
DEBUG - 2018-05-08 12:57:07 --> Total execution time: 0.1750
INFO - 2018-05-08 07:27:10 --> Config Class Initialized
INFO - 2018-05-08 07:27:10 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:27:10 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:27:10 --> Utf8 Class Initialized
INFO - 2018-05-08 07:27:10 --> URI Class Initialized
INFO - 2018-05-08 07:27:10 --> Router Class Initialized
INFO - 2018-05-08 07:27:10 --> Output Class Initialized
INFO - 2018-05-08 07:27:10 --> Security Class Initialized
DEBUG - 2018-05-08 07:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:27:10 --> Input Class Initialized
INFO - 2018-05-08 07:27:10 --> Language Class Initialized
INFO - 2018-05-08 07:27:10 --> Language Class Initialized
INFO - 2018-05-08 07:27:10 --> Config Class Initialized
INFO - 2018-05-08 07:27:10 --> Loader Class Initialized
INFO - 2018-05-08 12:57:10 --> Helper loaded: url_helper
INFO - 2018-05-08 12:57:10 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:57:10 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:57:10 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:57:10 --> Helper loaded: users_helper
INFO - 2018-05-08 12:57:10 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:57:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:57:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:57:10 --> Helper loaded: form_helper
INFO - 2018-05-08 12:57:10 --> Form Validation Class Initialized
INFO - 2018-05-08 12:57:10 --> Controller Class Initialized
INFO - 2018-05-08 12:57:10 --> Model Class Initialized
INFO - 2018-05-08 12:57:10 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:57:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:57:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:57:10 --> Model Class Initialized
INFO - 2018-05-08 12:57:10 --> Model Class Initialized
INFO - 2018-05-08 12:57:10 --> Model Class Initialized
INFO - 2018-05-08 12:57:10 --> Model Class Initialized
INFO - 2018-05-08 12:57:10 --> Final output sent to browser
DEBUG - 2018-05-08 12:57:10 --> Total execution time: 0.1019
INFO - 2018-05-08 07:27:13 --> Config Class Initialized
INFO - 2018-05-08 07:27:13 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:27:13 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:27:13 --> Utf8 Class Initialized
INFO - 2018-05-08 07:27:13 --> URI Class Initialized
INFO - 2018-05-08 07:27:13 --> Router Class Initialized
INFO - 2018-05-08 07:27:13 --> Output Class Initialized
INFO - 2018-05-08 07:27:13 --> Security Class Initialized
DEBUG - 2018-05-08 07:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:27:13 --> Input Class Initialized
INFO - 2018-05-08 07:27:13 --> Language Class Initialized
INFO - 2018-05-08 07:27:13 --> Language Class Initialized
INFO - 2018-05-08 07:27:13 --> Config Class Initialized
INFO - 2018-05-08 07:27:13 --> Loader Class Initialized
INFO - 2018-05-08 12:57:13 --> Helper loaded: url_helper
INFO - 2018-05-08 12:57:13 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:57:13 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:57:13 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:57:13 --> Helper loaded: users_helper
INFO - 2018-05-08 12:57:13 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:57:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:57:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:57:13 --> Helper loaded: form_helper
INFO - 2018-05-08 12:57:13 --> Form Validation Class Initialized
INFO - 2018-05-08 12:57:13 --> Controller Class Initialized
INFO - 2018-05-08 12:57:13 --> Model Class Initialized
INFO - 2018-05-08 12:57:13 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:57:13 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:57:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:57:13 --> Model Class Initialized
INFO - 2018-05-08 12:57:13 --> Model Class Initialized
INFO - 2018-05-08 12:57:13 --> Model Class Initialized
INFO - 2018-05-08 12:57:13 --> Model Class Initialized
INFO - 2018-05-08 12:57:13 --> Model Class Initialized
INFO - 2018-05-08 12:57:13 --> Model Class Initialized
INFO - 2018-05-08 12:57:13 --> Model Class Initialized
INFO - 2018-05-08 12:57:13 --> Model Class Initialized
INFO - 2018-05-08 12:57:13 --> Model Class Initialized
INFO - 2018-05-08 12:57:13 --> Model Class Initialized
INFO - 2018-05-08 12:57:13 --> Model Class Initialized
INFO - 2018-05-08 12:57:13 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:57:13 --> Model Class Initialized
INFO - 2018-05-08 12:57:13 --> Final output sent to browser
DEBUG - 2018-05-08 12:57:13 --> Total execution time: 0.1271
INFO - 2018-05-08 07:27:15 --> Config Class Initialized
INFO - 2018-05-08 07:27:15 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:27:15 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:27:15 --> Utf8 Class Initialized
INFO - 2018-05-08 07:27:15 --> URI Class Initialized
INFO - 2018-05-08 07:27:15 --> Router Class Initialized
INFO - 2018-05-08 07:27:15 --> Output Class Initialized
INFO - 2018-05-08 07:27:15 --> Security Class Initialized
DEBUG - 2018-05-08 07:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:27:15 --> Input Class Initialized
INFO - 2018-05-08 07:27:15 --> Language Class Initialized
INFO - 2018-05-08 07:27:15 --> Language Class Initialized
INFO - 2018-05-08 07:27:15 --> Config Class Initialized
INFO - 2018-05-08 07:27:15 --> Loader Class Initialized
INFO - 2018-05-08 12:57:15 --> Helper loaded: url_helper
INFO - 2018-05-08 12:57:15 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:57:15 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:57:15 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:57:15 --> Helper loaded: users_helper
INFO - 2018-05-08 12:57:15 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:57:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:57:15 --> Helper loaded: form_helper
INFO - 2018-05-08 12:57:15 --> Form Validation Class Initialized
INFO - 2018-05-08 12:57:15 --> Controller Class Initialized
INFO - 2018-05-08 12:57:15 --> Model Class Initialized
INFO - 2018-05-08 12:57:15 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:57:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:57:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:57:15 --> Model Class Initialized
INFO - 2018-05-08 12:57:15 --> Model Class Initialized
INFO - 2018-05-08 12:57:15 --> Model Class Initialized
INFO - 2018-05-08 12:57:15 --> Model Class Initialized
INFO - 2018-05-08 12:57:15 --> Model Class Initialized
INFO - 2018-05-08 12:57:15 --> Model Class Initialized
INFO - 2018-05-08 12:57:15 --> Model Class Initialized
INFO - 2018-05-08 12:57:15 --> Model Class Initialized
INFO - 2018-05-08 12:57:15 --> Model Class Initialized
INFO - 2018-05-08 12:57:15 --> Model Class Initialized
INFO - 2018-05-08 12:57:15 --> Model Class Initialized
INFO - 2018-05-08 12:57:15 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:57:15 --> Model Class Initialized
INFO - 2018-05-08 12:57:15 --> Final output sent to browser
DEBUG - 2018-05-08 12:57:15 --> Total execution time: 0.1173
INFO - 2018-05-08 07:27:17 --> Config Class Initialized
INFO - 2018-05-08 07:27:17 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:27:17 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:27:17 --> Utf8 Class Initialized
INFO - 2018-05-08 07:27:17 --> URI Class Initialized
INFO - 2018-05-08 07:27:17 --> Router Class Initialized
INFO - 2018-05-08 07:27:17 --> Output Class Initialized
INFO - 2018-05-08 07:27:17 --> Security Class Initialized
DEBUG - 2018-05-08 07:27:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:27:17 --> Input Class Initialized
INFO - 2018-05-08 07:27:17 --> Language Class Initialized
INFO - 2018-05-08 07:27:17 --> Language Class Initialized
INFO - 2018-05-08 07:27:17 --> Config Class Initialized
INFO - 2018-05-08 07:27:17 --> Loader Class Initialized
INFO - 2018-05-08 12:57:17 --> Helper loaded: url_helper
INFO - 2018-05-08 12:57:17 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:57:17 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:57:17 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:57:17 --> Helper loaded: users_helper
INFO - 2018-05-08 12:57:17 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:57:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:57:17 --> Helper loaded: form_helper
INFO - 2018-05-08 12:57:17 --> Form Validation Class Initialized
INFO - 2018-05-08 12:57:17 --> Controller Class Initialized
INFO - 2018-05-08 12:57:17 --> Model Class Initialized
INFO - 2018-05-08 12:57:17 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:57:17 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:57:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:57:17 --> Model Class Initialized
INFO - 2018-05-08 12:57:17 --> Model Class Initialized
INFO - 2018-05-08 12:57:17 --> Model Class Initialized
INFO - 2018-05-08 12:57:17 --> Model Class Initialized
INFO - 2018-05-08 12:57:17 --> Model Class Initialized
INFO - 2018-05-08 12:57:17 --> Model Class Initialized
INFO - 2018-05-08 12:57:17 --> Model Class Initialized
INFO - 2018-05-08 12:57:17 --> Model Class Initialized
INFO - 2018-05-08 12:57:17 --> Model Class Initialized
INFO - 2018-05-08 12:57:17 --> Model Class Initialized
INFO - 2018-05-08 12:57:17 --> Model Class Initialized
INFO - 2018-05-08 12:57:17 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:57:17 --> Model Class Initialized
INFO - 2018-05-08 12:57:17 --> Final output sent to browser
DEBUG - 2018-05-08 12:57:17 --> Total execution time: 0.1163
INFO - 2018-05-08 07:27:18 --> Config Class Initialized
INFO - 2018-05-08 07:27:18 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:27:18 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:27:18 --> Utf8 Class Initialized
INFO - 2018-05-08 07:27:18 --> URI Class Initialized
INFO - 2018-05-08 07:27:18 --> Router Class Initialized
INFO - 2018-05-08 07:27:18 --> Output Class Initialized
INFO - 2018-05-08 07:27:18 --> Security Class Initialized
DEBUG - 2018-05-08 07:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:27:18 --> Input Class Initialized
INFO - 2018-05-08 07:27:18 --> Language Class Initialized
INFO - 2018-05-08 07:27:18 --> Language Class Initialized
INFO - 2018-05-08 07:27:18 --> Config Class Initialized
INFO - 2018-05-08 07:27:18 --> Loader Class Initialized
INFO - 2018-05-08 12:57:18 --> Helper loaded: url_helper
INFO - 2018-05-08 12:57:18 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:57:18 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:57:18 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:57:18 --> Helper loaded: users_helper
INFO - 2018-05-08 12:57:18 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:57:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:57:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:57:18 --> Helper loaded: form_helper
INFO - 2018-05-08 12:57:18 --> Form Validation Class Initialized
INFO - 2018-05-08 12:57:18 --> Controller Class Initialized
INFO - 2018-05-08 12:57:18 --> Model Class Initialized
INFO - 2018-05-08 12:57:18 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:57:18 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:57:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:57:18 --> Model Class Initialized
INFO - 2018-05-08 12:57:18 --> Model Class Initialized
INFO - 2018-05-08 12:57:18 --> Model Class Initialized
INFO - 2018-05-08 12:57:18 --> Model Class Initialized
INFO - 2018-05-08 12:57:18 --> Model Class Initialized
INFO - 2018-05-08 12:57:18 --> Model Class Initialized
INFO - 2018-05-08 12:57:18 --> Model Class Initialized
INFO - 2018-05-08 12:57:18 --> Model Class Initialized
INFO - 2018-05-08 12:57:18 --> Model Class Initialized
INFO - 2018-05-08 12:57:18 --> Model Class Initialized
INFO - 2018-05-08 12:57:18 --> Model Class Initialized
INFO - 2018-05-08 12:57:18 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:57:18 --> Final output sent to browser
DEBUG - 2018-05-08 12:57:18 --> Total execution time: 0.1365
INFO - 2018-05-08 07:27:19 --> Config Class Initialized
INFO - 2018-05-08 07:27:19 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:27:19 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:27:19 --> Utf8 Class Initialized
INFO - 2018-05-08 07:27:19 --> URI Class Initialized
INFO - 2018-05-08 07:27:19 --> Router Class Initialized
INFO - 2018-05-08 07:27:19 --> Output Class Initialized
INFO - 2018-05-08 07:27:19 --> Security Class Initialized
DEBUG - 2018-05-08 07:27:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:27:19 --> Input Class Initialized
INFO - 2018-05-08 07:27:19 --> Language Class Initialized
INFO - 2018-05-08 07:27:19 --> Language Class Initialized
INFO - 2018-05-08 07:27:19 --> Config Class Initialized
INFO - 2018-05-08 07:27:19 --> Loader Class Initialized
INFO - 2018-05-08 12:57:19 --> Helper loaded: url_helper
INFO - 2018-05-08 12:57:19 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:57:19 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:57:19 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:57:19 --> Helper loaded: users_helper
INFO - 2018-05-08 12:57:19 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:57:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:57:19 --> Helper loaded: form_helper
INFO - 2018-05-08 12:57:19 --> Form Validation Class Initialized
INFO - 2018-05-08 12:57:19 --> Controller Class Initialized
INFO - 2018-05-08 12:57:19 --> Model Class Initialized
INFO - 2018-05-08 12:57:19 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:57:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:57:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:57:19 --> Model Class Initialized
INFO - 2018-05-08 12:57:19 --> Model Class Initialized
INFO - 2018-05-08 12:57:19 --> Model Class Initialized
INFO - 2018-05-08 12:57:19 --> Model Class Initialized
INFO - 2018-05-08 12:57:19 --> Model Class Initialized
INFO - 2018-05-08 12:57:19 --> Model Class Initialized
INFO - 2018-05-08 12:57:19 --> Model Class Initialized
INFO - 2018-05-08 12:57:19 --> Model Class Initialized
INFO - 2018-05-08 12:57:19 --> Model Class Initialized
INFO - 2018-05-08 12:57:19 --> Model Class Initialized
INFO - 2018-05-08 12:57:19 --> Model Class Initialized
INFO - 2018-05-08 12:57:19 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:57:19 --> Final output sent to browser
DEBUG - 2018-05-08 12:57:19 --> Total execution time: 0.2282
INFO - 2018-05-08 07:27:20 --> Config Class Initialized
INFO - 2018-05-08 07:27:20 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:27:20 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:27:20 --> Utf8 Class Initialized
INFO - 2018-05-08 07:27:20 --> URI Class Initialized
INFO - 2018-05-08 07:27:20 --> Router Class Initialized
INFO - 2018-05-08 07:27:20 --> Output Class Initialized
INFO - 2018-05-08 07:27:20 --> Security Class Initialized
DEBUG - 2018-05-08 07:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:27:20 --> Input Class Initialized
INFO - 2018-05-08 07:27:20 --> Language Class Initialized
INFO - 2018-05-08 07:27:20 --> Language Class Initialized
INFO - 2018-05-08 07:27:20 --> Config Class Initialized
INFO - 2018-05-08 07:27:20 --> Loader Class Initialized
INFO - 2018-05-08 12:57:20 --> Helper loaded: url_helper
INFO - 2018-05-08 12:57:20 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:57:20 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:57:20 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:57:20 --> Helper loaded: users_helper
INFO - 2018-05-08 12:57:20 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:57:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:57:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:57:20 --> Helper loaded: form_helper
INFO - 2018-05-08 12:57:20 --> Form Validation Class Initialized
INFO - 2018-05-08 12:57:20 --> Controller Class Initialized
INFO - 2018-05-08 12:57:20 --> Model Class Initialized
INFO - 2018-05-08 12:57:20 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:57:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:57:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:57:20 --> Model Class Initialized
INFO - 2018-05-08 12:57:20 --> Model Class Initialized
INFO - 2018-05-08 12:57:20 --> Model Class Initialized
INFO - 2018-05-08 12:57:20 --> Model Class Initialized
INFO - 2018-05-08 12:57:20 --> Model Class Initialized
INFO - 2018-05-08 12:57:20 --> Model Class Initialized
INFO - 2018-05-08 12:57:20 --> Model Class Initialized
INFO - 2018-05-08 12:57:20 --> Model Class Initialized
INFO - 2018-05-08 12:57:20 --> Model Class Initialized
INFO - 2018-05-08 12:57:20 --> Model Class Initialized
INFO - 2018-05-08 12:57:20 --> Model Class Initialized
INFO - 2018-05-08 12:57:20 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:57:20 --> Final output sent to browser
DEBUG - 2018-05-08 12:57:20 --> Total execution time: 0.1169
INFO - 2018-05-08 07:27:22 --> Config Class Initialized
INFO - 2018-05-08 07:27:22 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:27:22 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:27:22 --> Utf8 Class Initialized
INFO - 2018-05-08 07:27:22 --> URI Class Initialized
INFO - 2018-05-08 07:27:22 --> Router Class Initialized
INFO - 2018-05-08 07:27:22 --> Output Class Initialized
INFO - 2018-05-08 07:27:22 --> Security Class Initialized
DEBUG - 2018-05-08 07:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:27:22 --> Input Class Initialized
INFO - 2018-05-08 07:27:22 --> Language Class Initialized
INFO - 2018-05-08 07:27:23 --> Language Class Initialized
INFO - 2018-05-08 07:27:23 --> Config Class Initialized
INFO - 2018-05-08 07:27:23 --> Loader Class Initialized
INFO - 2018-05-08 12:57:23 --> Helper loaded: url_helper
INFO - 2018-05-08 12:57:23 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:57:23 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:57:23 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:57:23 --> Helper loaded: users_helper
INFO - 2018-05-08 12:57:23 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:57:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:57:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:57:23 --> Helper loaded: form_helper
INFO - 2018-05-08 12:57:23 --> Form Validation Class Initialized
INFO - 2018-05-08 12:57:23 --> Controller Class Initialized
INFO - 2018-05-08 12:57:23 --> Model Class Initialized
INFO - 2018-05-08 12:57:23 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:57:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:57:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:57:23 --> Model Class Initialized
INFO - 2018-05-08 12:57:23 --> Model Class Initialized
INFO - 2018-05-08 12:57:23 --> Model Class Initialized
INFO - 2018-05-08 12:57:23 --> Model Class Initialized
INFO - 2018-05-08 12:57:23 --> Model Class Initialized
INFO - 2018-05-08 12:57:23 --> Model Class Initialized
INFO - 2018-05-08 12:57:23 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:57:23 --> Final output sent to browser
DEBUG - 2018-05-08 12:57:23 --> Total execution time: 0.1049
INFO - 2018-05-08 07:27:23 --> Config Class Initialized
INFO - 2018-05-08 07:27:23 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:27:23 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:27:23 --> Utf8 Class Initialized
INFO - 2018-05-08 07:27:23 --> URI Class Initialized
INFO - 2018-05-08 07:27:23 --> Router Class Initialized
INFO - 2018-05-08 07:27:23 --> Output Class Initialized
INFO - 2018-05-08 07:27:23 --> Security Class Initialized
DEBUG - 2018-05-08 07:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:27:23 --> Input Class Initialized
INFO - 2018-05-08 07:27:23 --> Language Class Initialized
INFO - 2018-05-08 07:27:23 --> Language Class Initialized
INFO - 2018-05-08 07:27:23 --> Config Class Initialized
INFO - 2018-05-08 07:27:23 --> Loader Class Initialized
INFO - 2018-05-08 12:57:23 --> Helper loaded: url_helper
INFO - 2018-05-08 12:57:23 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:57:23 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:57:23 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:57:23 --> Helper loaded: users_helper
INFO - 2018-05-08 12:57:23 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:57:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:57:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:57:23 --> Helper loaded: form_helper
INFO - 2018-05-08 12:57:23 --> Form Validation Class Initialized
INFO - 2018-05-08 12:57:23 --> Controller Class Initialized
INFO - 2018-05-08 12:57:23 --> Model Class Initialized
INFO - 2018-05-08 12:57:23 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:57:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:57:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:57:23 --> Model Class Initialized
INFO - 2018-05-08 12:57:23 --> Model Class Initialized
INFO - 2018-05-08 12:57:23 --> Model Class Initialized
INFO - 2018-05-08 12:57:23 --> Model Class Initialized
INFO - 2018-05-08 12:57:23 --> Model Class Initialized
INFO - 2018-05-08 12:57:23 --> Model Class Initialized
INFO - 2018-05-08 12:57:23 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 12:57:23 --> Final output sent to browser
DEBUG - 2018-05-08 12:57:23 --> Total execution time: 0.1276
INFO - 2018-05-08 07:27:31 --> Config Class Initialized
INFO - 2018-05-08 07:27:31 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:27:31 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:27:31 --> Utf8 Class Initialized
INFO - 2018-05-08 07:27:31 --> URI Class Initialized
INFO - 2018-05-08 07:27:31 --> Router Class Initialized
INFO - 2018-05-08 07:27:31 --> Output Class Initialized
INFO - 2018-05-08 07:27:31 --> Security Class Initialized
DEBUG - 2018-05-08 07:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:27:31 --> Input Class Initialized
INFO - 2018-05-08 07:27:31 --> Language Class Initialized
INFO - 2018-05-08 07:27:31 --> Language Class Initialized
INFO - 2018-05-08 07:27:31 --> Config Class Initialized
INFO - 2018-05-08 07:27:31 --> Loader Class Initialized
INFO - 2018-05-08 12:57:31 --> Helper loaded: url_helper
INFO - 2018-05-08 12:57:31 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:57:31 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:57:31 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:57:31 --> Helper loaded: users_helper
INFO - 2018-05-08 12:57:31 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:57:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:57:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:57:31 --> Helper loaded: form_helper
INFO - 2018-05-08 12:57:31 --> Form Validation Class Initialized
INFO - 2018-05-08 12:57:31 --> Controller Class Initialized
INFO - 2018-05-08 12:57:31 --> Model Class Initialized
INFO - 2018-05-08 12:57:31 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:57:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:57:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:57:31 --> Model Class Initialized
INFO - 2018-05-08 12:57:31 --> Model Class Initialized
INFO - 2018-05-08 12:57:31 --> Model Class Initialized
INFO - 2018-05-08 12:57:31 --> Model Class Initialized
INFO - 2018-05-08 12:57:31 --> Model Class Initialized
INFO - 2018-05-08 12:57:31 --> Model Class Initialized
INFO - 2018-05-08 12:57:31 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-05-08 12:57:31 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 800
ERROR - 2018-05-08 12:57:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 810
INFO - 2018-05-08 12:57:31 --> Final output sent to browser
DEBUG - 2018-05-08 12:57:31 --> Total execution time: 0.1201
INFO - 2018-05-08 07:28:03 --> Config Class Initialized
INFO - 2018-05-08 07:28:03 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:28:03 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:28:03 --> Utf8 Class Initialized
INFO - 2018-05-08 07:28:03 --> URI Class Initialized
INFO - 2018-05-08 07:28:03 --> Router Class Initialized
INFO - 2018-05-08 07:28:03 --> Output Class Initialized
INFO - 2018-05-08 07:28:03 --> Security Class Initialized
DEBUG - 2018-05-08 07:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:28:03 --> Input Class Initialized
INFO - 2018-05-08 07:28:03 --> Language Class Initialized
INFO - 2018-05-08 07:28:03 --> Language Class Initialized
INFO - 2018-05-08 07:28:03 --> Config Class Initialized
INFO - 2018-05-08 07:28:03 --> Loader Class Initialized
INFO - 2018-05-08 12:58:03 --> Helper loaded: url_helper
INFO - 2018-05-08 12:58:03 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:58:03 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:58:03 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:58:03 --> Helper loaded: users_helper
INFO - 2018-05-08 12:58:03 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:58:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:58:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:58:03 --> Helper loaded: form_helper
INFO - 2018-05-08 12:58:03 --> Form Validation Class Initialized
INFO - 2018-05-08 12:58:03 --> Controller Class Initialized
INFO - 2018-05-08 12:58:03 --> Model Class Initialized
INFO - 2018-05-08 12:58:03 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:58:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:58:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:58:03 --> Model Class Initialized
INFO - 2018-05-08 12:58:03 --> Model Class Initialized
INFO - 2018-05-08 12:58:03 --> Model Class Initialized
INFO - 2018-05-08 12:58:03 --> Model Class Initialized
INFO - 2018-05-08 12:58:03 --> Model Class Initialized
INFO - 2018-05-08 12:58:03 --> Model Class Initialized
INFO - 2018-05-08 12:58:03 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-05-08 12:58:03 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 800
INFO - 2018-05-08 12:58:03 --> Final output sent to browser
DEBUG - 2018-05-08 12:58:03 --> Total execution time: 0.1716
INFO - 2018-05-08 07:28:18 --> Config Class Initialized
INFO - 2018-05-08 07:28:18 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:28:18 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:28:18 --> Utf8 Class Initialized
INFO - 2018-05-08 07:28:18 --> URI Class Initialized
INFO - 2018-05-08 07:28:18 --> Router Class Initialized
INFO - 2018-05-08 07:28:18 --> Output Class Initialized
INFO - 2018-05-08 07:28:18 --> Security Class Initialized
DEBUG - 2018-05-08 07:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:28:18 --> Input Class Initialized
INFO - 2018-05-08 07:28:18 --> Language Class Initialized
INFO - 2018-05-08 07:28:18 --> Language Class Initialized
INFO - 2018-05-08 07:28:18 --> Config Class Initialized
INFO - 2018-05-08 07:28:18 --> Loader Class Initialized
INFO - 2018-05-08 12:58:18 --> Helper loaded: url_helper
INFO - 2018-05-08 12:58:18 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:58:18 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:58:18 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:58:18 --> Helper loaded: users_helper
INFO - 2018-05-08 12:58:18 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:58:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:58:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:58:18 --> Helper loaded: form_helper
INFO - 2018-05-08 12:58:18 --> Form Validation Class Initialized
INFO - 2018-05-08 12:58:18 --> Controller Class Initialized
INFO - 2018-05-08 12:58:18 --> Model Class Initialized
INFO - 2018-05-08 12:58:18 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:58:18 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:58:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:58:18 --> Model Class Initialized
INFO - 2018-05-08 12:58:18 --> Model Class Initialized
INFO - 2018-05-08 12:58:18 --> Model Class Initialized
INFO - 2018-05-08 12:58:18 --> Model Class Initialized
INFO - 2018-05-08 12:58:18 --> Final output sent to browser
DEBUG - 2018-05-08 12:58:18 --> Total execution time: 0.1148
INFO - 2018-05-08 07:28:19 --> Config Class Initialized
INFO - 2018-05-08 07:28:19 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:28:19 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:28:19 --> Utf8 Class Initialized
INFO - 2018-05-08 07:28:19 --> URI Class Initialized
INFO - 2018-05-08 07:28:19 --> Router Class Initialized
INFO - 2018-05-08 07:28:19 --> Output Class Initialized
INFO - 2018-05-08 07:28:19 --> Security Class Initialized
DEBUG - 2018-05-08 07:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:28:19 --> Input Class Initialized
INFO - 2018-05-08 07:28:19 --> Language Class Initialized
INFO - 2018-05-08 07:28:19 --> Language Class Initialized
INFO - 2018-05-08 07:28:19 --> Config Class Initialized
INFO - 2018-05-08 07:28:19 --> Loader Class Initialized
INFO - 2018-05-08 12:58:19 --> Helper loaded: url_helper
INFO - 2018-05-08 12:58:19 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:58:19 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:58:19 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:58:19 --> Helper loaded: users_helper
INFO - 2018-05-08 12:58:19 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:58:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:58:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:58:19 --> Helper loaded: form_helper
INFO - 2018-05-08 12:58:19 --> Form Validation Class Initialized
INFO - 2018-05-08 12:58:19 --> Controller Class Initialized
INFO - 2018-05-08 12:58:19 --> Model Class Initialized
INFO - 2018-05-08 12:58:19 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:58:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:58:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:58:19 --> Model Class Initialized
INFO - 2018-05-08 12:58:19 --> Model Class Initialized
INFO - 2018-05-08 12:58:19 --> Model Class Initialized
INFO - 2018-05-08 12:58:19 --> Model Class Initialized
INFO - 2018-05-08 12:58:19 --> Final output sent to browser
DEBUG - 2018-05-08 12:58:19 --> Total execution time: 0.1190
INFO - 2018-05-08 07:28:20 --> Config Class Initialized
INFO - 2018-05-08 07:28:20 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:28:20 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:28:20 --> Utf8 Class Initialized
INFO - 2018-05-08 07:28:20 --> URI Class Initialized
INFO - 2018-05-08 07:28:20 --> Router Class Initialized
INFO - 2018-05-08 07:28:20 --> Output Class Initialized
INFO - 2018-05-08 07:28:20 --> Security Class Initialized
DEBUG - 2018-05-08 07:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:28:20 --> Input Class Initialized
INFO - 2018-05-08 07:28:20 --> Language Class Initialized
INFO - 2018-05-08 07:28:20 --> Language Class Initialized
INFO - 2018-05-08 07:28:20 --> Config Class Initialized
INFO - 2018-05-08 07:28:20 --> Loader Class Initialized
INFO - 2018-05-08 12:58:20 --> Helper loaded: url_helper
INFO - 2018-05-08 12:58:20 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:58:20 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:58:20 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:58:20 --> Helper loaded: users_helper
INFO - 2018-05-08 12:58:20 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:58:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:58:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:58:20 --> Helper loaded: form_helper
INFO - 2018-05-08 12:58:20 --> Form Validation Class Initialized
INFO - 2018-05-08 12:58:20 --> Controller Class Initialized
INFO - 2018-05-08 12:58:20 --> Model Class Initialized
INFO - 2018-05-08 12:58:20 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:58:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:58:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:58:20 --> Model Class Initialized
INFO - 2018-05-08 12:58:20 --> Model Class Initialized
INFO - 2018-05-08 12:58:20 --> Model Class Initialized
INFO - 2018-05-08 12:58:20 --> Model Class Initialized
INFO - 2018-05-08 12:58:20 --> Final output sent to browser
DEBUG - 2018-05-08 12:58:20 --> Total execution time: 0.1188
INFO - 2018-05-08 07:28:21 --> Config Class Initialized
INFO - 2018-05-08 07:28:21 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:28:21 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:28:21 --> Utf8 Class Initialized
INFO - 2018-05-08 07:28:21 --> URI Class Initialized
INFO - 2018-05-08 07:28:21 --> Router Class Initialized
INFO - 2018-05-08 07:28:21 --> Output Class Initialized
INFO - 2018-05-08 07:28:21 --> Security Class Initialized
DEBUG - 2018-05-08 07:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:28:21 --> Input Class Initialized
INFO - 2018-05-08 07:28:21 --> Language Class Initialized
INFO - 2018-05-08 07:28:21 --> Language Class Initialized
INFO - 2018-05-08 07:28:21 --> Config Class Initialized
INFO - 2018-05-08 07:28:21 --> Loader Class Initialized
INFO - 2018-05-08 12:58:21 --> Helper loaded: url_helper
INFO - 2018-05-08 12:58:21 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:58:21 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:58:21 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:58:21 --> Helper loaded: users_helper
INFO - 2018-05-08 12:58:22 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:58:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:58:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:58:22 --> Helper loaded: form_helper
INFO - 2018-05-08 12:58:22 --> Form Validation Class Initialized
INFO - 2018-05-08 12:58:22 --> Controller Class Initialized
INFO - 2018-05-08 12:58:22 --> Model Class Initialized
INFO - 2018-05-08 12:58:22 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:58:22 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:58:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:58:22 --> Model Class Initialized
INFO - 2018-05-08 12:58:22 --> Model Class Initialized
INFO - 2018-05-08 12:58:22 --> Model Class Initialized
INFO - 2018-05-08 12:58:22 --> Model Class Initialized
INFO - 2018-05-08 12:58:22 --> Final output sent to browser
DEBUG - 2018-05-08 12:58:22 --> Total execution time: 0.1033
INFO - 2018-05-08 07:28:23 --> Config Class Initialized
INFO - 2018-05-08 07:28:23 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:28:23 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:28:23 --> Utf8 Class Initialized
INFO - 2018-05-08 07:28:23 --> URI Class Initialized
INFO - 2018-05-08 07:28:23 --> Router Class Initialized
INFO - 2018-05-08 07:28:23 --> Output Class Initialized
INFO - 2018-05-08 07:28:23 --> Security Class Initialized
DEBUG - 2018-05-08 07:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:28:23 --> Input Class Initialized
INFO - 2018-05-08 07:28:23 --> Language Class Initialized
INFO - 2018-05-08 07:28:23 --> Language Class Initialized
INFO - 2018-05-08 07:28:23 --> Config Class Initialized
INFO - 2018-05-08 07:28:23 --> Loader Class Initialized
INFO - 2018-05-08 12:58:23 --> Helper loaded: url_helper
INFO - 2018-05-08 12:58:23 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:58:23 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:58:23 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:58:23 --> Helper loaded: users_helper
INFO - 2018-05-08 12:58:23 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:58:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:58:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:58:23 --> Helper loaded: form_helper
INFO - 2018-05-08 12:58:23 --> Form Validation Class Initialized
INFO - 2018-05-08 12:58:23 --> Controller Class Initialized
INFO - 2018-05-08 12:58:23 --> Model Class Initialized
INFO - 2018-05-08 12:58:23 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:58:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:58:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:58:23 --> Model Class Initialized
INFO - 2018-05-08 12:58:23 --> Model Class Initialized
INFO - 2018-05-08 12:58:23 --> Model Class Initialized
INFO - 2018-05-08 12:58:23 --> Model Class Initialized
INFO - 2018-05-08 12:58:23 --> Final output sent to browser
DEBUG - 2018-05-08 12:58:23 --> Total execution time: 0.1107
INFO - 2018-05-08 07:28:24 --> Config Class Initialized
INFO - 2018-05-08 07:28:24 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:28:24 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:28:24 --> Utf8 Class Initialized
INFO - 2018-05-08 07:28:24 --> URI Class Initialized
INFO - 2018-05-08 07:28:24 --> Router Class Initialized
INFO - 2018-05-08 07:28:24 --> Output Class Initialized
INFO - 2018-05-08 07:28:24 --> Security Class Initialized
DEBUG - 2018-05-08 07:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:28:24 --> Input Class Initialized
INFO - 2018-05-08 07:28:24 --> Language Class Initialized
INFO - 2018-05-08 07:28:24 --> Language Class Initialized
INFO - 2018-05-08 07:28:24 --> Config Class Initialized
INFO - 2018-05-08 07:28:24 --> Loader Class Initialized
INFO - 2018-05-08 12:58:24 --> Helper loaded: url_helper
INFO - 2018-05-08 12:58:24 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:58:24 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:58:24 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:58:24 --> Helper loaded: users_helper
INFO - 2018-05-08 12:58:24 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:58:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:58:24 --> Helper loaded: form_helper
INFO - 2018-05-08 12:58:24 --> Form Validation Class Initialized
INFO - 2018-05-08 12:58:24 --> Controller Class Initialized
INFO - 2018-05-08 12:58:24 --> Model Class Initialized
INFO - 2018-05-08 12:58:24 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:58:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:58:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:58:24 --> Model Class Initialized
INFO - 2018-05-08 12:58:24 --> Model Class Initialized
INFO - 2018-05-08 12:58:24 --> Model Class Initialized
INFO - 2018-05-08 12:58:24 --> Model Class Initialized
INFO - 2018-05-08 12:58:24 --> Final output sent to browser
DEBUG - 2018-05-08 12:58:24 --> Total execution time: 0.1042
INFO - 2018-05-08 07:28:25 --> Config Class Initialized
INFO - 2018-05-08 07:28:25 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:28:25 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:28:25 --> Utf8 Class Initialized
INFO - 2018-05-08 07:28:25 --> URI Class Initialized
INFO - 2018-05-08 07:28:25 --> Router Class Initialized
INFO - 2018-05-08 07:28:25 --> Output Class Initialized
INFO - 2018-05-08 07:28:25 --> Security Class Initialized
DEBUG - 2018-05-08 07:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:28:25 --> Input Class Initialized
INFO - 2018-05-08 07:28:25 --> Language Class Initialized
INFO - 2018-05-08 07:28:25 --> Language Class Initialized
INFO - 2018-05-08 07:28:25 --> Config Class Initialized
INFO - 2018-05-08 07:28:25 --> Loader Class Initialized
INFO - 2018-05-08 12:58:25 --> Helper loaded: url_helper
INFO - 2018-05-08 12:58:25 --> Helper loaded: notification_helper
INFO - 2018-05-08 12:58:25 --> Helper loaded: settings_helper
INFO - 2018-05-08 12:58:25 --> Helper loaded: permission_helper
INFO - 2018-05-08 12:58:25 --> Helper loaded: users_helper
INFO - 2018-05-08 12:58:25 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:58:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 12:58:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 12:58:25 --> Helper loaded: form_helper
INFO - 2018-05-08 12:58:25 --> Form Validation Class Initialized
INFO - 2018-05-08 12:58:25 --> Controller Class Initialized
INFO - 2018-05-08 12:58:25 --> Model Class Initialized
INFO - 2018-05-08 12:58:25 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 12:58:25 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 12:58:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:58:25 --> Model Class Initialized
INFO - 2018-05-08 12:58:25 --> Model Class Initialized
INFO - 2018-05-08 12:58:25 --> Model Class Initialized
INFO - 2018-05-08 12:58:25 --> Model Class Initialized
INFO - 2018-05-08 12:58:25 --> Final output sent to browser
DEBUG - 2018-05-08 12:58:25 --> Total execution time: 0.1092
INFO - 2018-05-08 07:30:47 --> Config Class Initialized
INFO - 2018-05-08 07:30:47 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:30:47 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:30:47 --> Utf8 Class Initialized
INFO - 2018-05-08 07:30:47 --> URI Class Initialized
INFO - 2018-05-08 07:30:47 --> Router Class Initialized
INFO - 2018-05-08 07:30:47 --> Output Class Initialized
INFO - 2018-05-08 07:30:47 --> Security Class Initialized
DEBUG - 2018-05-08 07:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:30:47 --> Input Class Initialized
INFO - 2018-05-08 07:30:47 --> Language Class Initialized
INFO - 2018-05-08 07:30:47 --> Language Class Initialized
INFO - 2018-05-08 07:30:47 --> Config Class Initialized
INFO - 2018-05-08 07:30:47 --> Loader Class Initialized
INFO - 2018-05-08 13:00:47 --> Helper loaded: url_helper
INFO - 2018-05-08 13:00:47 --> Helper loaded: notification_helper
INFO - 2018-05-08 13:00:47 --> Helper loaded: settings_helper
INFO - 2018-05-08 13:00:47 --> Helper loaded: permission_helper
INFO - 2018-05-08 13:00:47 --> Helper loaded: users_helper
INFO - 2018-05-08 13:00:47 --> Database Driver Class Initialized
DEBUG - 2018-05-08 13:00:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 13:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 13:00:47 --> Helper loaded: form_helper
INFO - 2018-05-08 13:00:47 --> Form Validation Class Initialized
INFO - 2018-05-08 13:00:47 --> Controller Class Initialized
INFO - 2018-05-08 13:00:47 --> Model Class Initialized
INFO - 2018-05-08 13:00:47 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 13:00:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 13:00:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 13:00:47 --> Model Class Initialized
INFO - 2018-05-08 13:00:47 --> Model Class Initialized
INFO - 2018-05-08 13:00:47 --> Model Class Initialized
INFO - 2018-05-08 13:00:47 --> Model Class Initialized
INFO - 2018-05-08 13:00:47 --> Model Class Initialized
INFO - 2018-05-08 13:00:47 --> Model Class Initialized
INFO - 2018-05-08 13:00:47 --> Model Class Initialized
INFO - 2018-05-08 13:00:47 --> Model Class Initialized
INFO - 2018-05-08 13:00:47 --> Model Class Initialized
INFO - 2018-05-08 13:00:47 --> Model Class Initialized
INFO - 2018-05-08 13:00:47 --> Model Class Initialized
INFO - 2018-05-08 13:00:47 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 13:00:47 --> Model Class Initialized
INFO - 2018-05-08 13:00:47 --> Final output sent to browser
DEBUG - 2018-05-08 13:00:47 --> Total execution time: 0.1199
INFO - 2018-05-08 07:30:48 --> Config Class Initialized
INFO - 2018-05-08 07:30:48 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:30:48 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:30:48 --> Utf8 Class Initialized
INFO - 2018-05-08 07:30:48 --> URI Class Initialized
INFO - 2018-05-08 07:30:48 --> Router Class Initialized
INFO - 2018-05-08 07:30:48 --> Output Class Initialized
INFO - 2018-05-08 07:30:48 --> Security Class Initialized
DEBUG - 2018-05-08 07:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:30:48 --> Input Class Initialized
INFO - 2018-05-08 07:30:48 --> Language Class Initialized
INFO - 2018-05-08 07:30:48 --> Language Class Initialized
INFO - 2018-05-08 07:30:48 --> Config Class Initialized
INFO - 2018-05-08 07:30:48 --> Loader Class Initialized
INFO - 2018-05-08 13:00:48 --> Helper loaded: url_helper
INFO - 2018-05-08 13:00:48 --> Helper loaded: notification_helper
INFO - 2018-05-08 13:00:48 --> Helper loaded: settings_helper
INFO - 2018-05-08 13:00:48 --> Helper loaded: permission_helper
INFO - 2018-05-08 13:00:48 --> Helper loaded: users_helper
INFO - 2018-05-08 13:00:48 --> Database Driver Class Initialized
DEBUG - 2018-05-08 13:00:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 13:00:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 13:00:48 --> Helper loaded: form_helper
INFO - 2018-05-08 13:00:48 --> Form Validation Class Initialized
INFO - 2018-05-08 13:00:48 --> Controller Class Initialized
INFO - 2018-05-08 13:00:48 --> Model Class Initialized
INFO - 2018-05-08 13:00:48 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 13:00:48 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 13:00:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 13:00:48 --> Model Class Initialized
INFO - 2018-05-08 13:00:48 --> Model Class Initialized
INFO - 2018-05-08 13:00:48 --> Model Class Initialized
INFO - 2018-05-08 13:00:48 --> Model Class Initialized
INFO - 2018-05-08 13:00:48 --> Model Class Initialized
INFO - 2018-05-08 13:00:48 --> Model Class Initialized
INFO - 2018-05-08 13:00:48 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 13:00:48 --> Model Class Initialized
INFO - 2018-05-08 13:00:48 --> Final output sent to browser
DEBUG - 2018-05-08 13:00:48 --> Total execution time: 0.1196
INFO - 2018-05-08 07:30:50 --> Config Class Initialized
INFO - 2018-05-08 07:30:50 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:30:50 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:30:50 --> Utf8 Class Initialized
INFO - 2018-05-08 07:30:50 --> URI Class Initialized
INFO - 2018-05-08 07:30:50 --> Router Class Initialized
INFO - 2018-05-08 07:30:50 --> Output Class Initialized
INFO - 2018-05-08 07:30:50 --> Security Class Initialized
DEBUG - 2018-05-08 07:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:30:50 --> Input Class Initialized
INFO - 2018-05-08 07:30:50 --> Language Class Initialized
INFO - 2018-05-08 07:30:50 --> Language Class Initialized
INFO - 2018-05-08 07:30:50 --> Config Class Initialized
INFO - 2018-05-08 07:30:50 --> Loader Class Initialized
INFO - 2018-05-08 13:00:50 --> Helper loaded: url_helper
INFO - 2018-05-08 13:00:50 --> Helper loaded: notification_helper
INFO - 2018-05-08 13:00:50 --> Helper loaded: settings_helper
INFO - 2018-05-08 13:00:50 --> Helper loaded: permission_helper
INFO - 2018-05-08 13:00:50 --> Helper loaded: users_helper
INFO - 2018-05-08 13:00:50 --> Database Driver Class Initialized
DEBUG - 2018-05-08 13:00:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 13:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 13:00:50 --> Helper loaded: form_helper
INFO - 2018-05-08 13:00:50 --> Form Validation Class Initialized
INFO - 2018-05-08 13:00:50 --> Controller Class Initialized
INFO - 2018-05-08 13:00:50 --> Model Class Initialized
INFO - 2018-05-08 13:00:50 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 13:00:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 13:00:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 13:00:50 --> Model Class Initialized
INFO - 2018-05-08 13:00:50 --> Model Class Initialized
INFO - 2018-05-08 13:00:50 --> Model Class Initialized
INFO - 2018-05-08 13:00:50 --> Model Class Initialized
INFO - 2018-05-08 13:00:50 --> Final output sent to browser
DEBUG - 2018-05-08 13:00:50 --> Total execution time: 0.1240
INFO - 2018-05-08 07:30:53 --> Config Class Initialized
INFO - 2018-05-08 07:30:53 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:30:53 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:30:53 --> Utf8 Class Initialized
INFO - 2018-05-08 07:30:53 --> URI Class Initialized
INFO - 2018-05-08 07:30:53 --> Router Class Initialized
INFO - 2018-05-08 07:30:53 --> Output Class Initialized
INFO - 2018-05-08 07:30:53 --> Security Class Initialized
DEBUG - 2018-05-08 07:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:30:53 --> Input Class Initialized
INFO - 2018-05-08 07:30:53 --> Language Class Initialized
INFO - 2018-05-08 07:30:53 --> Language Class Initialized
INFO - 2018-05-08 07:30:53 --> Config Class Initialized
INFO - 2018-05-08 07:30:53 --> Loader Class Initialized
INFO - 2018-05-08 13:00:53 --> Helper loaded: url_helper
INFO - 2018-05-08 13:00:53 --> Helper loaded: notification_helper
INFO - 2018-05-08 13:00:53 --> Helper loaded: settings_helper
INFO - 2018-05-08 13:00:53 --> Helper loaded: permission_helper
INFO - 2018-05-08 13:00:53 --> Helper loaded: users_helper
INFO - 2018-05-08 13:00:53 --> Database Driver Class Initialized
DEBUG - 2018-05-08 13:00:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 13:00:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 13:00:53 --> Helper loaded: form_helper
INFO - 2018-05-08 13:00:53 --> Form Validation Class Initialized
INFO - 2018-05-08 13:00:53 --> Controller Class Initialized
INFO - 2018-05-08 13:00:53 --> Model Class Initialized
INFO - 2018-05-08 13:00:53 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 13:00:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 13:00:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 13:00:53 --> Model Class Initialized
INFO - 2018-05-08 13:00:53 --> Model Class Initialized
INFO - 2018-05-08 13:00:53 --> Model Class Initialized
INFO - 2018-05-08 13:00:53 --> Model Class Initialized
INFO - 2018-05-08 13:00:53 --> Final output sent to browser
DEBUG - 2018-05-08 13:00:53 --> Total execution time: 0.1012
INFO - 2018-05-08 07:30:55 --> Config Class Initialized
INFO - 2018-05-08 07:30:55 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:30:55 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:30:55 --> Utf8 Class Initialized
INFO - 2018-05-08 07:30:55 --> URI Class Initialized
INFO - 2018-05-08 07:30:55 --> Router Class Initialized
INFO - 2018-05-08 07:30:55 --> Output Class Initialized
INFO - 2018-05-08 07:30:55 --> Security Class Initialized
DEBUG - 2018-05-08 07:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:30:55 --> Input Class Initialized
INFO - 2018-05-08 07:30:55 --> Language Class Initialized
INFO - 2018-05-08 07:30:55 --> Language Class Initialized
INFO - 2018-05-08 07:30:55 --> Config Class Initialized
INFO - 2018-05-08 07:30:55 --> Loader Class Initialized
INFO - 2018-05-08 13:00:55 --> Helper loaded: url_helper
INFO - 2018-05-08 13:00:55 --> Helper loaded: notification_helper
INFO - 2018-05-08 13:00:55 --> Helper loaded: settings_helper
INFO - 2018-05-08 13:00:55 --> Helper loaded: permission_helper
INFO - 2018-05-08 13:00:55 --> Helper loaded: users_helper
INFO - 2018-05-08 13:00:55 --> Database Driver Class Initialized
DEBUG - 2018-05-08 13:00:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 13:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 13:00:55 --> Helper loaded: form_helper
INFO - 2018-05-08 13:00:55 --> Form Validation Class Initialized
INFO - 2018-05-08 13:00:55 --> Controller Class Initialized
INFO - 2018-05-08 13:00:55 --> Model Class Initialized
INFO - 2018-05-08 13:00:55 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 13:00:55 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 13:00:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 13:00:55 --> Model Class Initialized
INFO - 2018-05-08 13:00:55 --> Model Class Initialized
INFO - 2018-05-08 13:00:55 --> Model Class Initialized
INFO - 2018-05-08 13:00:55 --> Model Class Initialized
INFO - 2018-05-08 13:00:55 --> Final output sent to browser
DEBUG - 2018-05-08 13:00:55 --> Total execution time: 0.1055
INFO - 2018-05-08 07:31:02 --> Config Class Initialized
INFO - 2018-05-08 07:31:02 --> Hooks Class Initialized
DEBUG - 2018-05-08 07:31:02 --> UTF-8 Support Enabled
INFO - 2018-05-08 07:31:02 --> Utf8 Class Initialized
INFO - 2018-05-08 07:31:02 --> URI Class Initialized
INFO - 2018-05-08 07:31:02 --> Router Class Initialized
INFO - 2018-05-08 07:31:02 --> Output Class Initialized
INFO - 2018-05-08 07:31:02 --> Security Class Initialized
DEBUG - 2018-05-08 07:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 07:31:02 --> Input Class Initialized
INFO - 2018-05-08 07:31:02 --> Language Class Initialized
INFO - 2018-05-08 07:31:02 --> Language Class Initialized
INFO - 2018-05-08 07:31:02 --> Config Class Initialized
INFO - 2018-05-08 07:31:02 --> Loader Class Initialized
INFO - 2018-05-08 13:01:02 --> Helper loaded: url_helper
INFO - 2018-05-08 13:01:02 --> Helper loaded: notification_helper
INFO - 2018-05-08 13:01:02 --> Helper loaded: settings_helper
INFO - 2018-05-08 13:01:02 --> Helper loaded: permission_helper
INFO - 2018-05-08 13:01:02 --> Helper loaded: users_helper
INFO - 2018-05-08 13:01:02 --> Database Driver Class Initialized
DEBUG - 2018-05-08 13:01:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 13:01:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 13:01:02 --> Helper loaded: form_helper
INFO - 2018-05-08 13:01:02 --> Form Validation Class Initialized
INFO - 2018-05-08 13:01:02 --> Controller Class Initialized
INFO - 2018-05-08 13:01:02 --> Model Class Initialized
INFO - 2018-05-08 13:01:02 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 13:01:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 13:01:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 13:01:02 --> Model Class Initialized
INFO - 2018-05-08 13:01:02 --> Model Class Initialized
INFO - 2018-05-08 13:01:02 --> Model Class Initialized
INFO - 2018-05-08 13:01:02 --> Model Class Initialized
INFO - 2018-05-08 13:01:02 --> Model Class Initialized
INFO - 2018-05-08 13:01:02 --> Model Class Initialized
INFO - 2018-05-08 13:01:02 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 13:01:02 --> Final output sent to browser
DEBUG - 2018-05-08 13:01:02 --> Total execution time: 0.2008
INFO - 2018-05-08 08:22:08 --> Config Class Initialized
INFO - 2018-05-08 08:22:08 --> Hooks Class Initialized
DEBUG - 2018-05-08 08:22:08 --> UTF-8 Support Enabled
INFO - 2018-05-08 08:22:08 --> Utf8 Class Initialized
INFO - 2018-05-08 08:22:08 --> URI Class Initialized
INFO - 2018-05-08 08:22:08 --> Router Class Initialized
INFO - 2018-05-08 08:22:08 --> Output Class Initialized
INFO - 2018-05-08 08:22:08 --> Security Class Initialized
DEBUG - 2018-05-08 08:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 08:22:08 --> Input Class Initialized
INFO - 2018-05-08 08:22:08 --> Language Class Initialized
INFO - 2018-05-08 08:22:08 --> Language Class Initialized
INFO - 2018-05-08 08:22:08 --> Config Class Initialized
INFO - 2018-05-08 08:22:08 --> Loader Class Initialized
INFO - 2018-05-08 13:52:08 --> Helper loaded: url_helper
INFO - 2018-05-08 13:52:08 --> Helper loaded: notification_helper
INFO - 2018-05-08 13:52:08 --> Helper loaded: settings_helper
INFO - 2018-05-08 13:52:08 --> Helper loaded: permission_helper
INFO - 2018-05-08 13:52:08 --> Helper loaded: users_helper
INFO - 2018-05-08 13:52:08 --> Database Driver Class Initialized
DEBUG - 2018-05-08 13:52:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 13:52:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 13:52:08 --> Helper loaded: form_helper
INFO - 2018-05-08 13:52:08 --> Form Validation Class Initialized
INFO - 2018-05-08 13:52:08 --> Controller Class Initialized
INFO - 2018-05-08 13:52:08 --> Model Class Initialized
INFO - 2018-05-08 13:52:08 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 13:52:08 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 13:52:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 13:52:08 --> Model Class Initialized
INFO - 2018-05-08 13:52:08 --> Model Class Initialized
INFO - 2018-05-08 13:52:08 --> Model Class Initialized
INFO - 2018-05-08 13:52:08 --> Model Class Initialized
INFO - 2018-05-08 13:52:08 --> Model Class Initialized
INFO - 2018-05-08 13:52:08 --> Model Class Initialized
INFO - 2018-05-08 13:52:08 --> Model Class Initialized
INFO - 2018-05-08 13:52:08 --> Model Class Initialized
INFO - 2018-05-08 13:52:08 --> Model Class Initialized
INFO - 2018-05-08 13:52:08 --> Model Class Initialized
INFO - 2018-05-08 13:52:08 --> Model Class Initialized
INFO - 2018-05-08 13:52:08 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 13:52:08 --> Model Class Initialized
INFO - 2018-05-08 13:52:08 --> Final output sent to browser
DEBUG - 2018-05-08 13:52:08 --> Total execution time: 0.1822
INFO - 2018-05-08 08:22:08 --> Config Class Initialized
INFO - 2018-05-08 08:22:08 --> Hooks Class Initialized
DEBUG - 2018-05-08 08:22:08 --> UTF-8 Support Enabled
INFO - 2018-05-08 08:22:08 --> Utf8 Class Initialized
INFO - 2018-05-08 08:22:08 --> URI Class Initialized
INFO - 2018-05-08 08:22:08 --> Router Class Initialized
INFO - 2018-05-08 08:22:08 --> Output Class Initialized
INFO - 2018-05-08 08:22:08 --> Security Class Initialized
DEBUG - 2018-05-08 08:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 08:22:08 --> Input Class Initialized
INFO - 2018-05-08 08:22:08 --> Language Class Initialized
INFO - 2018-05-08 08:22:08 --> Language Class Initialized
INFO - 2018-05-08 08:22:08 --> Config Class Initialized
INFO - 2018-05-08 08:22:08 --> Loader Class Initialized
INFO - 2018-05-08 13:52:08 --> Helper loaded: url_helper
INFO - 2018-05-08 13:52:08 --> Helper loaded: notification_helper
INFO - 2018-05-08 13:52:08 --> Helper loaded: settings_helper
INFO - 2018-05-08 13:52:08 --> Helper loaded: permission_helper
INFO - 2018-05-08 13:52:08 --> Helper loaded: users_helper
INFO - 2018-05-08 13:52:08 --> Database Driver Class Initialized
DEBUG - 2018-05-08 13:52:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 13:52:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 13:52:08 --> Helper loaded: form_helper
INFO - 2018-05-08 13:52:08 --> Form Validation Class Initialized
INFO - 2018-05-08 13:52:08 --> Controller Class Initialized
INFO - 2018-05-08 13:52:08 --> Model Class Initialized
INFO - 2018-05-08 13:52:08 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 13:52:08 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 13:52:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 13:52:08 --> Model Class Initialized
INFO - 2018-05-08 13:52:08 --> Model Class Initialized
INFO - 2018-05-08 13:52:08 --> Model Class Initialized
INFO - 2018-05-08 13:52:08 --> Model Class Initialized
INFO - 2018-05-08 13:52:08 --> Model Class Initialized
INFO - 2018-05-08 13:52:08 --> Model Class Initialized
INFO - 2018-05-08 13:52:08 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 13:52:08 --> Model Class Initialized
INFO - 2018-05-08 13:52:08 --> Final output sent to browser
DEBUG - 2018-05-08 13:52:08 --> Total execution time: 0.1410
INFO - 2018-05-08 08:24:39 --> Config Class Initialized
INFO - 2018-05-08 08:24:39 --> Hooks Class Initialized
DEBUG - 2018-05-08 08:24:39 --> UTF-8 Support Enabled
INFO - 2018-05-08 08:24:39 --> Utf8 Class Initialized
INFO - 2018-05-08 08:24:39 --> URI Class Initialized
INFO - 2018-05-08 08:24:39 --> Router Class Initialized
INFO - 2018-05-08 08:24:39 --> Output Class Initialized
INFO - 2018-05-08 08:24:39 --> Security Class Initialized
DEBUG - 2018-05-08 08:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 08:24:39 --> Input Class Initialized
INFO - 2018-05-08 08:24:39 --> Language Class Initialized
INFO - 2018-05-08 08:24:39 --> Language Class Initialized
INFO - 2018-05-08 08:24:39 --> Config Class Initialized
INFO - 2018-05-08 08:24:39 --> Loader Class Initialized
INFO - 2018-05-08 13:54:39 --> Helper loaded: url_helper
INFO - 2018-05-08 13:54:39 --> Helper loaded: notification_helper
INFO - 2018-05-08 13:54:39 --> Helper loaded: settings_helper
INFO - 2018-05-08 13:54:39 --> Helper loaded: permission_helper
INFO - 2018-05-08 13:54:39 --> Helper loaded: users_helper
INFO - 2018-05-08 13:54:39 --> Database Driver Class Initialized
DEBUG - 2018-05-08 13:54:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 13:54:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 13:54:39 --> Helper loaded: form_helper
INFO - 2018-05-08 13:54:39 --> Form Validation Class Initialized
INFO - 2018-05-08 13:54:39 --> Controller Class Initialized
INFO - 2018-05-08 13:54:39 --> Model Class Initialized
INFO - 2018-05-08 13:54:39 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 13:54:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 13:54:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 13:54:39 --> Model Class Initialized
INFO - 2018-05-08 13:54:39 --> Model Class Initialized
INFO - 2018-05-08 13:54:39 --> Model Class Initialized
INFO - 2018-05-08 13:54:39 --> Model Class Initialized
INFO - 2018-05-08 13:54:39 --> Model Class Initialized
INFO - 2018-05-08 13:54:39 --> Model Class Initialized
INFO - 2018-05-08 13:54:39 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 13:54:39 --> Final output sent to browser
DEBUG - 2018-05-08 13:54:39 --> Total execution time: 0.1344
INFO - 2018-05-08 08:24:39 --> Config Class Initialized
INFO - 2018-05-08 08:24:39 --> Hooks Class Initialized
DEBUG - 2018-05-08 08:24:39 --> UTF-8 Support Enabled
INFO - 2018-05-08 08:24:39 --> Utf8 Class Initialized
INFO - 2018-05-08 08:24:39 --> URI Class Initialized
INFO - 2018-05-08 08:24:39 --> Router Class Initialized
INFO - 2018-05-08 08:24:39 --> Output Class Initialized
INFO - 2018-05-08 08:24:39 --> Security Class Initialized
DEBUG - 2018-05-08 08:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 08:24:39 --> Input Class Initialized
INFO - 2018-05-08 08:24:39 --> Language Class Initialized
INFO - 2018-05-08 08:24:39 --> Language Class Initialized
INFO - 2018-05-08 08:24:39 --> Config Class Initialized
INFO - 2018-05-08 08:24:39 --> Loader Class Initialized
INFO - 2018-05-08 13:54:39 --> Helper loaded: url_helper
INFO - 2018-05-08 13:54:39 --> Helper loaded: notification_helper
INFO - 2018-05-08 13:54:39 --> Helper loaded: settings_helper
INFO - 2018-05-08 13:54:39 --> Helper loaded: permission_helper
INFO - 2018-05-08 13:54:39 --> Helper loaded: users_helper
INFO - 2018-05-08 13:54:39 --> Database Driver Class Initialized
DEBUG - 2018-05-08 13:54:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 13:54:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 13:54:40 --> Helper loaded: form_helper
INFO - 2018-05-08 13:54:40 --> Form Validation Class Initialized
INFO - 2018-05-08 13:54:40 --> Controller Class Initialized
INFO - 2018-05-08 13:54:40 --> Model Class Initialized
INFO - 2018-05-08 13:54:40 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 13:54:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 13:54:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 13:54:40 --> Model Class Initialized
INFO - 2018-05-08 13:54:40 --> Model Class Initialized
INFO - 2018-05-08 13:54:40 --> Model Class Initialized
INFO - 2018-05-08 13:54:40 --> Model Class Initialized
INFO - 2018-05-08 13:54:40 --> Model Class Initialized
INFO - 2018-05-08 13:54:40 --> Model Class Initialized
INFO - 2018-05-08 13:54:40 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 13:54:40 --> Final output sent to browser
DEBUG - 2018-05-08 13:54:40 --> Total execution time: 0.1173
INFO - 2018-05-08 08:37:05 --> Config Class Initialized
INFO - 2018-05-08 08:37:05 --> Hooks Class Initialized
DEBUG - 2018-05-08 08:37:05 --> UTF-8 Support Enabled
INFO - 2018-05-08 08:37:05 --> Utf8 Class Initialized
INFO - 2018-05-08 08:37:05 --> URI Class Initialized
INFO - 2018-05-08 08:37:05 --> Router Class Initialized
INFO - 2018-05-08 08:37:05 --> Output Class Initialized
INFO - 2018-05-08 08:37:05 --> Security Class Initialized
DEBUG - 2018-05-08 08:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 08:37:05 --> Input Class Initialized
INFO - 2018-05-08 08:37:05 --> Language Class Initialized
INFO - 2018-05-08 08:37:05 --> Language Class Initialized
INFO - 2018-05-08 08:37:05 --> Config Class Initialized
INFO - 2018-05-08 08:37:05 --> Loader Class Initialized
INFO - 2018-05-08 14:07:05 --> Helper loaded: url_helper
INFO - 2018-05-08 14:07:05 --> Helper loaded: notification_helper
INFO - 2018-05-08 14:07:05 --> Helper loaded: settings_helper
INFO - 2018-05-08 14:07:05 --> Helper loaded: permission_helper
INFO - 2018-05-08 14:07:05 --> Helper loaded: users_helper
INFO - 2018-05-08 14:07:05 --> Database Driver Class Initialized
DEBUG - 2018-05-08 14:07:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 14:07:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 14:07:05 --> Helper loaded: form_helper
INFO - 2018-05-08 14:07:05 --> Form Validation Class Initialized
INFO - 2018-05-08 14:07:05 --> Controller Class Initialized
INFO - 2018-05-08 14:07:05 --> Model Class Initialized
INFO - 2018-05-08 14:07:05 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 14:07:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 14:07:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 14:07:05 --> Model Class Initialized
INFO - 2018-05-08 14:07:05 --> Model Class Initialized
INFO - 2018-05-08 14:07:05 --> Model Class Initialized
INFO - 2018-05-08 14:07:05 --> Model Class Initialized
INFO - 2018-05-08 14:07:05 --> Model Class Initialized
INFO - 2018-05-08 14:07:05 --> Model Class Initialized
INFO - 2018-05-08 14:07:05 --> Model Class Initialized
INFO - 2018-05-08 14:07:05 --> Model Class Initialized
INFO - 2018-05-08 14:07:05 --> Model Class Initialized
INFO - 2018-05-08 14:07:05 --> Model Class Initialized
INFO - 2018-05-08 14:07:05 --> Model Class Initialized
INFO - 2018-05-08 14:07:05 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 14:07:05 --> Model Class Initialized
INFO - 2018-05-08 14:07:05 --> Final output sent to browser
DEBUG - 2018-05-08 14:07:05 --> Total execution time: 0.1222
INFO - 2018-05-08 08:37:05 --> Config Class Initialized
INFO - 2018-05-08 08:37:05 --> Hooks Class Initialized
DEBUG - 2018-05-08 08:37:05 --> UTF-8 Support Enabled
INFO - 2018-05-08 08:37:05 --> Utf8 Class Initialized
INFO - 2018-05-08 08:37:05 --> URI Class Initialized
INFO - 2018-05-08 08:37:05 --> Router Class Initialized
INFO - 2018-05-08 08:37:05 --> Output Class Initialized
INFO - 2018-05-08 08:37:05 --> Security Class Initialized
DEBUG - 2018-05-08 08:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 08:37:05 --> Input Class Initialized
INFO - 2018-05-08 08:37:05 --> Language Class Initialized
INFO - 2018-05-08 08:37:05 --> Language Class Initialized
INFO - 2018-05-08 08:37:05 --> Config Class Initialized
INFO - 2018-05-08 08:37:05 --> Loader Class Initialized
INFO - 2018-05-08 14:07:05 --> Helper loaded: url_helper
INFO - 2018-05-08 14:07:05 --> Helper loaded: notification_helper
INFO - 2018-05-08 14:07:05 --> Helper loaded: settings_helper
INFO - 2018-05-08 14:07:05 --> Helper loaded: permission_helper
INFO - 2018-05-08 14:07:05 --> Helper loaded: users_helper
INFO - 2018-05-08 14:07:05 --> Database Driver Class Initialized
DEBUG - 2018-05-08 14:07:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 14:07:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 14:07:05 --> Helper loaded: form_helper
INFO - 2018-05-08 14:07:05 --> Form Validation Class Initialized
INFO - 2018-05-08 14:07:05 --> Controller Class Initialized
INFO - 2018-05-08 14:07:05 --> Model Class Initialized
INFO - 2018-05-08 14:07:05 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 14:07:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 14:07:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 14:07:05 --> Model Class Initialized
INFO - 2018-05-08 14:07:05 --> Model Class Initialized
INFO - 2018-05-08 14:07:05 --> Model Class Initialized
INFO - 2018-05-08 14:07:05 --> Model Class Initialized
INFO - 2018-05-08 14:07:05 --> Model Class Initialized
INFO - 2018-05-08 14:07:05 --> Model Class Initialized
INFO - 2018-05-08 14:07:05 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 14:07:05 --> Model Class Initialized
INFO - 2018-05-08 14:07:05 --> Final output sent to browser
DEBUG - 2018-05-08 14:07:05 --> Total execution time: 0.1209
INFO - 2018-05-08 08:53:37 --> Config Class Initialized
INFO - 2018-05-08 08:53:37 --> Hooks Class Initialized
DEBUG - 2018-05-08 08:53:37 --> UTF-8 Support Enabled
INFO - 2018-05-08 08:53:37 --> Utf8 Class Initialized
INFO - 2018-05-08 08:53:37 --> URI Class Initialized
INFO - 2018-05-08 08:53:37 --> Router Class Initialized
INFO - 2018-05-08 08:53:37 --> Output Class Initialized
INFO - 2018-05-08 08:53:37 --> Security Class Initialized
DEBUG - 2018-05-08 08:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 08:53:37 --> Input Class Initialized
INFO - 2018-05-08 08:53:37 --> Language Class Initialized
INFO - 2018-05-08 08:53:37 --> Config Class Initialized
INFO - 2018-05-08 08:53:37 --> Hooks Class Initialized
DEBUG - 2018-05-08 08:53:37 --> UTF-8 Support Enabled
INFO - 2018-05-08 08:53:37 --> Utf8 Class Initialized
INFO - 2018-05-08 08:53:37 --> URI Class Initialized
INFO - 2018-05-08 08:53:37 --> Router Class Initialized
INFO - 2018-05-08 08:53:37 --> Language Class Initialized
INFO - 2018-05-08 08:53:37 --> Output Class Initialized
INFO - 2018-05-08 08:53:37 --> Config Class Initialized
INFO - 2018-05-08 08:53:37 --> Loader Class Initialized
INFO - 2018-05-08 14:23:37 --> Helper loaded: url_helper
INFO - 2018-05-08 08:53:37 --> Security Class Initialized
INFO - 2018-05-08 14:23:37 --> Helper loaded: notification_helper
INFO - 2018-05-08 14:23:37 --> Helper loaded: settings_helper
INFO - 2018-05-08 14:23:37 --> Helper loaded: permission_helper
INFO - 2018-05-08 14:23:37 --> Helper loaded: users_helper
DEBUG - 2018-05-08 08:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 08:53:37 --> Input Class Initialized
INFO - 2018-05-08 08:53:37 --> Language Class Initialized
INFO - 2018-05-08 14:23:37 --> Database Driver Class Initialized
DEBUG - 2018-05-08 14:23:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 14:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 08:53:37 --> Language Class Initialized
INFO - 2018-05-08 08:53:37 --> Config Class Initialized
INFO - 2018-05-08 08:53:37 --> Loader Class Initialized
INFO - 2018-05-08 14:23:37 --> Helper loaded: url_helper
INFO - 2018-05-08 14:23:37 --> Helper loaded: notification_helper
INFO - 2018-05-08 14:23:37 --> Helper loaded: form_helper
INFO - 2018-05-08 14:23:37 --> Form Validation Class Initialized
INFO - 2018-05-08 14:23:37 --> Controller Class Initialized
INFO - 2018-05-08 14:23:37 --> Helper loaded: settings_helper
INFO - 2018-05-08 14:23:37 --> Helper loaded: permission_helper
INFO - 2018-05-08 14:23:37 --> Helper loaded: users_helper
INFO - 2018-05-08 14:23:37 --> Model Class Initialized
INFO - 2018-05-08 14:23:37 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 14:23:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 14:23:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 14:23:37 --> Model Class Initialized
INFO - 2018-05-08 14:23:37 --> Model Class Initialized
INFO - 2018-05-08 14:23:37 --> Model Class Initialized
INFO - 2018-05-08 14:23:37 --> Model Class Initialized
INFO - 2018-05-08 14:23:37 --> Model Class Initialized
INFO - 2018-05-08 14:23:37 --> Model Class Initialized
INFO - 2018-05-08 14:23:37 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 14:23:37 --> Model Class Initialized
INFO - 2018-05-08 14:23:37 --> Final output sent to browser
DEBUG - 2018-05-08 14:23:37 --> Total execution time: 0.1262
INFO - 2018-05-08 14:23:37 --> Database Driver Class Initialized
DEBUG - 2018-05-08 14:23:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 14:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 14:23:37 --> Helper loaded: form_helper
INFO - 2018-05-08 14:23:37 --> Form Validation Class Initialized
INFO - 2018-05-08 14:23:37 --> Controller Class Initialized
INFO - 2018-05-08 14:23:37 --> Model Class Initialized
INFO - 2018-05-08 14:23:37 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 14:23:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 14:23:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 14:23:37 --> Model Class Initialized
INFO - 2018-05-08 14:23:37 --> Model Class Initialized
INFO - 2018-05-08 14:23:37 --> Model Class Initialized
INFO - 2018-05-08 14:23:37 --> Model Class Initialized
INFO - 2018-05-08 14:23:37 --> Model Class Initialized
INFO - 2018-05-08 14:23:37 --> Model Class Initialized
INFO - 2018-05-08 14:23:37 --> Model Class Initialized
INFO - 2018-05-08 14:23:37 --> Model Class Initialized
INFO - 2018-05-08 14:23:37 --> Model Class Initialized
INFO - 2018-05-08 14:23:37 --> Model Class Initialized
INFO - 2018-05-08 14:23:37 --> Model Class Initialized
INFO - 2018-05-08 14:23:37 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 14:23:37 --> Model Class Initialized
INFO - 2018-05-08 14:23:37 --> Final output sent to browser
DEBUG - 2018-05-08 14:23:37 --> Total execution time: 0.1879
INFO - 2018-05-08 09:03:51 --> Config Class Initialized
INFO - 2018-05-08 09:03:51 --> Hooks Class Initialized
DEBUG - 2018-05-08 09:03:51 --> UTF-8 Support Enabled
INFO - 2018-05-08 09:03:51 --> Utf8 Class Initialized
INFO - 2018-05-08 09:03:51 --> URI Class Initialized
INFO - 2018-05-08 09:03:51 --> Router Class Initialized
INFO - 2018-05-08 09:03:51 --> Output Class Initialized
INFO - 2018-05-08 09:03:51 --> Security Class Initialized
DEBUG - 2018-05-08 09:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 09:03:51 --> Input Class Initialized
INFO - 2018-05-08 09:03:51 --> Language Class Initialized
INFO - 2018-05-08 09:03:51 --> Language Class Initialized
INFO - 2018-05-08 09:03:51 --> Config Class Initialized
INFO - 2018-05-08 09:03:51 --> Loader Class Initialized
INFO - 2018-05-08 14:33:51 --> Helper loaded: url_helper
INFO - 2018-05-08 14:33:51 --> Helper loaded: notification_helper
INFO - 2018-05-08 14:33:51 --> Helper loaded: settings_helper
INFO - 2018-05-08 14:33:51 --> Helper loaded: permission_helper
INFO - 2018-05-08 14:33:51 --> Helper loaded: users_helper
INFO - 2018-05-08 14:33:51 --> Database Driver Class Initialized
DEBUG - 2018-05-08 14:33:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 14:33:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 14:33:51 --> Helper loaded: form_helper
INFO - 2018-05-08 14:33:51 --> Form Validation Class Initialized
INFO - 2018-05-08 14:33:51 --> Controller Class Initialized
INFO - 2018-05-08 14:33:51 --> Model Class Initialized
INFO - 2018-05-08 14:33:51 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 14:33:51 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 14:33:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 14:33:51 --> Model Class Initialized
INFO - 2018-05-08 14:33:51 --> Model Class Initialized
INFO - 2018-05-08 14:33:51 --> Model Class Initialized
INFO - 2018-05-08 14:33:51 --> Model Class Initialized
INFO - 2018-05-08 14:33:51 --> Model Class Initialized
INFO - 2018-05-08 14:33:51 --> Model Class Initialized
INFO - 2018-05-08 14:33:51 --> Model Class Initialized
INFO - 2018-05-08 14:33:51 --> Model Class Initialized
INFO - 2018-05-08 14:33:51 --> Model Class Initialized
INFO - 2018-05-08 14:33:51 --> Model Class Initialized
INFO - 2018-05-08 14:33:51 --> Model Class Initialized
INFO - 2018-05-08 14:33:51 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 14:33:51 --> Model Class Initialized
INFO - 2018-05-08 14:33:51 --> Final output sent to browser
DEBUG - 2018-05-08 14:33:51 --> Total execution time: 0.1398
INFO - 2018-05-08 09:03:51 --> Config Class Initialized
INFO - 2018-05-08 09:03:51 --> Hooks Class Initialized
DEBUG - 2018-05-08 09:03:51 --> UTF-8 Support Enabled
INFO - 2018-05-08 09:03:51 --> Utf8 Class Initialized
INFO - 2018-05-08 09:03:51 --> URI Class Initialized
INFO - 2018-05-08 09:03:51 --> Router Class Initialized
INFO - 2018-05-08 09:03:51 --> Output Class Initialized
INFO - 2018-05-08 09:03:51 --> Security Class Initialized
DEBUG - 2018-05-08 09:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 09:03:51 --> Input Class Initialized
INFO - 2018-05-08 09:03:51 --> Language Class Initialized
INFO - 2018-05-08 09:03:51 --> Language Class Initialized
INFO - 2018-05-08 09:03:51 --> Config Class Initialized
INFO - 2018-05-08 09:03:51 --> Loader Class Initialized
INFO - 2018-05-08 14:33:51 --> Helper loaded: url_helper
INFO - 2018-05-08 14:33:51 --> Helper loaded: notification_helper
INFO - 2018-05-08 14:33:51 --> Helper loaded: settings_helper
INFO - 2018-05-08 14:33:51 --> Helper loaded: permission_helper
INFO - 2018-05-08 14:33:51 --> Helper loaded: users_helper
INFO - 2018-05-08 14:33:51 --> Database Driver Class Initialized
DEBUG - 2018-05-08 14:33:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 14:33:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 14:33:51 --> Helper loaded: form_helper
INFO - 2018-05-08 14:33:51 --> Form Validation Class Initialized
INFO - 2018-05-08 14:33:51 --> Controller Class Initialized
INFO - 2018-05-08 14:33:51 --> Model Class Initialized
INFO - 2018-05-08 14:33:51 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 14:33:51 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 14:33:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 14:33:51 --> Model Class Initialized
INFO - 2018-05-08 14:33:51 --> Model Class Initialized
INFO - 2018-05-08 14:33:51 --> Model Class Initialized
INFO - 2018-05-08 14:33:51 --> Model Class Initialized
INFO - 2018-05-08 14:33:51 --> Model Class Initialized
INFO - 2018-05-08 14:33:51 --> Model Class Initialized
INFO - 2018-05-08 14:33:51 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 14:33:51 --> Model Class Initialized
INFO - 2018-05-08 14:33:51 --> Final output sent to browser
DEBUG - 2018-05-08 14:33:51 --> Total execution time: 0.1073
INFO - 2018-05-08 09:32:56 --> Config Class Initialized
INFO - 2018-05-08 09:32:56 --> Hooks Class Initialized
INFO - 2018-05-08 09:32:56 --> Config Class Initialized
INFO - 2018-05-08 09:32:56 --> Hooks Class Initialized
DEBUG - 2018-05-08 09:32:56 --> UTF-8 Support Enabled
INFO - 2018-05-08 09:32:56 --> Utf8 Class Initialized
DEBUG - 2018-05-08 09:32:56 --> UTF-8 Support Enabled
INFO - 2018-05-08 09:32:56 --> Utf8 Class Initialized
INFO - 2018-05-08 09:32:56 --> URI Class Initialized
INFO - 2018-05-08 09:32:56 --> URI Class Initialized
INFO - 2018-05-08 09:32:56 --> Router Class Initialized
INFO - 2018-05-08 09:32:56 --> Router Class Initialized
INFO - 2018-05-08 09:32:56 --> Output Class Initialized
INFO - 2018-05-08 09:32:56 --> Output Class Initialized
INFO - 2018-05-08 09:32:56 --> Security Class Initialized
DEBUG - 2018-05-08 09:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 09:32:56 --> Input Class Initialized
INFO - 2018-05-08 09:32:56 --> Security Class Initialized
INFO - 2018-05-08 09:32:56 --> Language Class Initialized
DEBUG - 2018-05-08 09:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 09:32:56 --> Input Class Initialized
INFO - 2018-05-08 09:32:56 --> Language Class Initialized
INFO - 2018-05-08 09:32:56 --> Config Class Initialized
INFO - 2018-05-08 09:32:56 --> Hooks Class Initialized
DEBUG - 2018-05-08 09:32:56 --> UTF-8 Support Enabled
INFO - 2018-05-08 09:32:56 --> Utf8 Class Initialized
INFO - 2018-05-08 09:32:56 --> URI Class Initialized
INFO - 2018-05-08 09:32:56 --> Language Class Initialized
INFO - 2018-05-08 09:32:56 --> Config Class Initialized
INFO - 2018-05-08 09:32:56 --> Loader Class Initialized
INFO - 2018-05-08 15:02:56 --> Helper loaded: url_helper
INFO - 2018-05-08 15:02:56 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:02:56 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:02:56 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:02:56 --> Helper loaded: users_helper
INFO - 2018-05-08 09:32:56 --> Language Class Initialized
INFO - 2018-05-08 09:32:56 --> Config Class Initialized
INFO - 2018-05-08 09:32:56 --> Loader Class Initialized
INFO - 2018-05-08 09:32:56 --> Router Class Initialized
INFO - 2018-05-08 15:02:56 --> Helper loaded: url_helper
INFO - 2018-05-08 15:02:56 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:02:56 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:02:56 --> Helper loaded: permission_helper
INFO - 2018-05-08 09:32:56 --> Output Class Initialized
INFO - 2018-05-08 15:02:56 --> Helper loaded: users_helper
INFO - 2018-05-08 09:32:56 --> Security Class Initialized
INFO - 2018-05-08 15:02:56 --> Database Driver Class Initialized
DEBUG - 2018-05-08 09:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 09:32:56 --> Input Class Initialized
INFO - 2018-05-08 09:32:56 --> Language Class Initialized
DEBUG - 2018-05-08 15:02:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:02:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:02:56 --> Database Driver Class Initialized
INFO - 2018-05-08 15:02:56 --> Helper loaded: form_helper
INFO - 2018-05-08 15:02:56 --> Form Validation Class Initialized
INFO - 2018-05-08 15:02:56 --> Controller Class Initialized
DEBUG - 2018-05-08 15:02:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:02:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:02:56 --> Helper loaded: form_helper
INFO - 2018-05-08 15:02:56 --> Form Validation Class Initialized
INFO - 2018-05-08 15:02:56 --> Model Class Initialized
INFO - 2018-05-08 15:02:56 --> Controller Class Initialized
INFO - 2018-05-08 15:02:56 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 15:02:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:02:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:02:56 --> Model Class Initialized
INFO - 2018-05-08 15:02:56 --> Model Class Initialized
INFO - 2018-05-08 15:02:56 --> Model Class Initialized
INFO - 2018-05-08 15:02:56 --> Model Class Initialized
INFO - 2018-05-08 15:02:56 --> Model Class Initialized
INFO - 2018-05-08 15:02:56 --> Model Class Initialized
INFO - 2018-05-08 15:02:56 --> Model Class Initialized
INFO - 2018-05-08 15:02:56 --> Model Class Initialized
INFO - 2018-05-08 15:02:56 --> Model Class Initialized
INFO - 2018-05-08 09:32:56 --> Language Class Initialized
INFO - 2018-05-08 09:32:56 --> Config Class Initialized
INFO - 2018-05-08 15:02:56 --> Model Class Initialized
INFO - 2018-05-08 09:32:56 --> Loader Class Initialized
INFO - 2018-05-08 15:02:56 --> Model Class Initialized
INFO - 2018-05-08 15:02:56 --> Helper loaded: inflector_helper
INFO - 2018-05-08 15:02:56 --> Model Class Initialized
INFO - 2018-05-08 15:02:56 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 15:02:56 --> Model Class Initialized
INFO - 2018-05-08 15:02:56 --> Helper loaded: url_helper
DEBUG - 2018-05-08 15:02:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:02:56 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:02:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:02:56 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:02:56 --> Final output sent to browser
DEBUG - 2018-05-08 15:02:56 --> Total execution time: 0.1560
INFO - 2018-05-08 15:02:56 --> Model Class Initialized
INFO - 2018-05-08 15:02:56 --> Model Class Initialized
INFO - 2018-05-08 15:02:56 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:02:56 --> Helper loaded: users_helper
INFO - 2018-05-08 15:02:56 --> Model Class Initialized
INFO - 2018-05-08 15:02:56 --> Model Class Initialized
INFO - 2018-05-08 15:02:56 --> Model Class Initialized
INFO - 2018-05-08 15:02:56 --> Model Class Initialized
INFO - 2018-05-08 15:02:56 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 15:02:56 --> Model Class Initialized
INFO - 2018-05-08 15:02:56 --> Final output sent to browser
DEBUG - 2018-05-08 15:02:56 --> Total execution time: 0.1724
INFO - 2018-05-08 15:02:56 --> Database Driver Class Initialized
DEBUG - 2018-05-08 15:02:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:02:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:02:57 --> Helper loaded: form_helper
INFO - 2018-05-08 15:02:57 --> Form Validation Class Initialized
INFO - 2018-05-08 15:02:57 --> Controller Class Initialized
INFO - 2018-05-08 15:02:57 --> Model Class Initialized
INFO - 2018-05-08 15:02:57 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 15:02:57 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:02:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:02:57 --> Model Class Initialized
INFO - 2018-05-08 15:02:57 --> Model Class Initialized
INFO - 2018-05-08 15:02:57 --> Model Class Initialized
INFO - 2018-05-08 15:02:57 --> Model Class Initialized
INFO - 2018-05-08 15:02:57 --> Model Class Initialized
INFO - 2018-05-08 15:02:57 --> Model Class Initialized
INFO - 2018-05-08 15:02:57 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 15:02:57 --> Final output sent to browser
DEBUG - 2018-05-08 15:02:57 --> Total execution time: 0.2224
INFO - 2018-05-08 09:32:58 --> Config Class Initialized
INFO - 2018-05-08 09:32:58 --> Hooks Class Initialized
DEBUG - 2018-05-08 09:32:58 --> UTF-8 Support Enabled
INFO - 2018-05-08 09:32:58 --> Utf8 Class Initialized
INFO - 2018-05-08 09:32:58 --> URI Class Initialized
INFO - 2018-05-08 09:32:58 --> Router Class Initialized
INFO - 2018-05-08 09:32:58 --> Output Class Initialized
INFO - 2018-05-08 09:32:58 --> Security Class Initialized
DEBUG - 2018-05-08 09:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 09:32:58 --> Input Class Initialized
INFO - 2018-05-08 09:32:58 --> Language Class Initialized
INFO - 2018-05-08 09:32:58 --> Language Class Initialized
INFO - 2018-05-08 09:32:58 --> Config Class Initialized
INFO - 2018-05-08 09:32:58 --> Loader Class Initialized
INFO - 2018-05-08 15:02:58 --> Helper loaded: url_helper
INFO - 2018-05-08 15:02:58 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:02:58 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:02:58 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:02:58 --> Helper loaded: users_helper
INFO - 2018-05-08 15:02:58 --> Database Driver Class Initialized
DEBUG - 2018-05-08 15:02:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:02:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:02:58 --> Helper loaded: form_helper
INFO - 2018-05-08 15:02:58 --> Form Validation Class Initialized
INFO - 2018-05-08 15:02:58 --> Controller Class Initialized
INFO - 2018-05-08 15:02:58 --> Model Class Initialized
INFO - 2018-05-08 15:02:58 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 15:02:58 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:02:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:02:58 --> Model Class Initialized
INFO - 2018-05-08 15:02:58 --> Model Class Initialized
INFO - 2018-05-08 15:02:58 --> Model Class Initialized
INFO - 2018-05-08 15:02:58 --> Model Class Initialized
INFO - 2018-05-08 15:02:58 --> Model Class Initialized
INFO - 2018-05-08 15:02:58 --> Model Class Initialized
INFO - 2018-05-08 15:02:58 --> Model Class Initialized
INFO - 2018-05-08 15:02:58 --> Model Class Initialized
INFO - 2018-05-08 15:02:58 --> Model Class Initialized
INFO - 2018-05-08 15:02:58 --> Model Class Initialized
INFO - 2018-05-08 15:02:58 --> Model Class Initialized
INFO - 2018-05-08 15:02:58 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 15:02:58 --> Model Class Initialized
INFO - 2018-05-08 15:02:59 --> Final output sent to browser
DEBUG - 2018-05-08 15:02:59 --> Total execution time: 0.1204
INFO - 2018-05-08 09:33:08 --> Config Class Initialized
INFO - 2018-05-08 09:33:08 --> Hooks Class Initialized
DEBUG - 2018-05-08 09:33:08 --> UTF-8 Support Enabled
INFO - 2018-05-08 09:33:08 --> Utf8 Class Initialized
INFO - 2018-05-08 09:33:08 --> URI Class Initialized
INFO - 2018-05-08 09:33:08 --> Router Class Initialized
INFO - 2018-05-08 09:33:08 --> Output Class Initialized
INFO - 2018-05-08 09:33:08 --> Security Class Initialized
DEBUG - 2018-05-08 09:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 09:33:08 --> Input Class Initialized
INFO - 2018-05-08 09:33:08 --> Language Class Initialized
INFO - 2018-05-08 09:33:08 --> Language Class Initialized
INFO - 2018-05-08 09:33:08 --> Config Class Initialized
INFO - 2018-05-08 09:33:08 --> Loader Class Initialized
INFO - 2018-05-08 15:03:08 --> Helper loaded: url_helper
INFO - 2018-05-08 15:03:08 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:03:08 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:03:08 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:03:08 --> Helper loaded: users_helper
INFO - 2018-05-08 15:03:08 --> Database Driver Class Initialized
DEBUG - 2018-05-08 15:03:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:03:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:03:08 --> Helper loaded: form_helper
INFO - 2018-05-08 15:03:08 --> Form Validation Class Initialized
INFO - 2018-05-08 15:03:08 --> Controller Class Initialized
INFO - 2018-05-08 15:03:08 --> Model Class Initialized
INFO - 2018-05-08 15:03:08 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 15:03:08 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:03:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:03:08 --> Model Class Initialized
INFO - 2018-05-08 15:03:08 --> Model Class Initialized
INFO - 2018-05-08 15:03:08 --> Model Class Initialized
INFO - 2018-05-08 15:03:08 --> Model Class Initialized
INFO - 2018-05-08 15:03:08 --> Final output sent to browser
DEBUG - 2018-05-08 15:03:08 --> Total execution time: 0.1562
INFO - 2018-05-08 09:33:09 --> Config Class Initialized
INFO - 2018-05-08 09:33:09 --> Hooks Class Initialized
DEBUG - 2018-05-08 09:33:09 --> UTF-8 Support Enabled
INFO - 2018-05-08 09:33:09 --> Utf8 Class Initialized
INFO - 2018-05-08 09:33:09 --> URI Class Initialized
INFO - 2018-05-08 09:33:10 --> Router Class Initialized
INFO - 2018-05-08 09:33:10 --> Output Class Initialized
INFO - 2018-05-08 09:33:10 --> Security Class Initialized
DEBUG - 2018-05-08 09:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 09:33:10 --> Input Class Initialized
INFO - 2018-05-08 09:33:10 --> Language Class Initialized
INFO - 2018-05-08 09:33:10 --> Language Class Initialized
INFO - 2018-05-08 09:33:10 --> Config Class Initialized
INFO - 2018-05-08 09:33:10 --> Loader Class Initialized
INFO - 2018-05-08 15:03:10 --> Helper loaded: url_helper
INFO - 2018-05-08 15:03:10 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:03:10 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:03:10 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:03:10 --> Helper loaded: users_helper
INFO - 2018-05-08 15:03:10 --> Database Driver Class Initialized
DEBUG - 2018-05-08 15:03:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:03:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:03:10 --> Helper loaded: form_helper
INFO - 2018-05-08 15:03:10 --> Form Validation Class Initialized
INFO - 2018-05-08 15:03:10 --> Controller Class Initialized
INFO - 2018-05-08 15:03:10 --> Model Class Initialized
INFO - 2018-05-08 15:03:10 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 15:03:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:03:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:03:10 --> Model Class Initialized
INFO - 2018-05-08 15:03:10 --> Model Class Initialized
INFO - 2018-05-08 15:03:10 --> Model Class Initialized
INFO - 2018-05-08 15:03:10 --> Model Class Initialized
INFO - 2018-05-08 15:03:10 --> Model Class Initialized
INFO - 2018-05-08 15:03:10 --> Model Class Initialized
INFO - 2018-05-08 15:03:10 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-05-08 15:03:10 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 800
ERROR - 2018-05-08 15:03:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 810
INFO - 2018-05-08 15:03:10 --> Final output sent to browser
DEBUG - 2018-05-08 15:03:10 --> Total execution time: 0.1271
INFO - 2018-05-08 09:33:31 --> Config Class Initialized
INFO - 2018-05-08 09:33:31 --> Hooks Class Initialized
DEBUG - 2018-05-08 09:33:32 --> UTF-8 Support Enabled
INFO - 2018-05-08 09:33:32 --> Utf8 Class Initialized
INFO - 2018-05-08 09:33:32 --> URI Class Initialized
INFO - 2018-05-08 09:33:32 --> Router Class Initialized
INFO - 2018-05-08 09:33:32 --> Output Class Initialized
INFO - 2018-05-08 09:33:32 --> Security Class Initialized
DEBUG - 2018-05-08 09:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 09:33:32 --> Input Class Initialized
INFO - 2018-05-08 09:33:32 --> Language Class Initialized
INFO - 2018-05-08 09:33:32 --> Language Class Initialized
INFO - 2018-05-08 09:33:32 --> Config Class Initialized
INFO - 2018-05-08 09:33:32 --> Loader Class Initialized
INFO - 2018-05-08 15:03:32 --> Helper loaded: url_helper
INFO - 2018-05-08 15:03:32 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:03:32 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:03:32 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:03:32 --> Helper loaded: users_helper
INFO - 2018-05-08 15:03:32 --> Database Driver Class Initialized
DEBUG - 2018-05-08 15:03:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:03:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:03:32 --> Helper loaded: form_helper
INFO - 2018-05-08 15:03:32 --> Form Validation Class Initialized
INFO - 2018-05-08 15:03:32 --> Controller Class Initialized
INFO - 2018-05-08 15:03:32 --> Model Class Initialized
INFO - 2018-05-08 15:03:32 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 15:03:32 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:03:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:03:32 --> Model Class Initialized
INFO - 2018-05-08 15:03:32 --> Model Class Initialized
INFO - 2018-05-08 15:03:32 --> Model Class Initialized
INFO - 2018-05-08 15:03:32 --> Model Class Initialized
INFO - 2018-05-08 15:03:32 --> Model Class Initialized
INFO - 2018-05-08 15:03:32 --> Model Class Initialized
INFO - 2018-05-08 15:03:32 --> Model Class Initialized
INFO - 2018-05-08 15:03:32 --> Model Class Initialized
INFO - 2018-05-08 15:03:32 --> Model Class Initialized
INFO - 2018-05-08 15:03:32 --> Model Class Initialized
INFO - 2018-05-08 15:03:32 --> Model Class Initialized
INFO - 2018-05-08 15:03:32 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 15:03:32 --> Model Class Initialized
INFO - 2018-05-08 15:03:32 --> Final output sent to browser
DEBUG - 2018-05-08 15:03:32 --> Total execution time: 0.1266
INFO - 2018-05-08 09:33:37 --> Config Class Initialized
INFO - 2018-05-08 09:33:37 --> Hooks Class Initialized
DEBUG - 2018-05-08 09:33:37 --> UTF-8 Support Enabled
INFO - 2018-05-08 09:33:37 --> Utf8 Class Initialized
INFO - 2018-05-08 09:33:37 --> URI Class Initialized
INFO - 2018-05-08 09:33:37 --> Router Class Initialized
INFO - 2018-05-08 09:33:37 --> Output Class Initialized
INFO - 2018-05-08 09:33:37 --> Security Class Initialized
DEBUG - 2018-05-08 09:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 09:33:37 --> Input Class Initialized
INFO - 2018-05-08 09:33:37 --> Language Class Initialized
INFO - 2018-05-08 09:33:37 --> Language Class Initialized
INFO - 2018-05-08 09:33:37 --> Config Class Initialized
INFO - 2018-05-08 09:33:37 --> Loader Class Initialized
INFO - 2018-05-08 15:03:37 --> Helper loaded: url_helper
INFO - 2018-05-08 15:03:37 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:03:37 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:03:37 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:03:37 --> Helper loaded: users_helper
INFO - 2018-05-08 15:03:37 --> Database Driver Class Initialized
DEBUG - 2018-05-08 15:03:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:03:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:03:37 --> Helper loaded: form_helper
INFO - 2018-05-08 15:03:37 --> Form Validation Class Initialized
INFO - 2018-05-08 15:03:37 --> Controller Class Initialized
INFO - 2018-05-08 15:03:37 --> Model Class Initialized
INFO - 2018-05-08 15:03:37 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 15:03:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:03:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:03:37 --> Model Class Initialized
INFO - 2018-05-08 15:03:37 --> Model Class Initialized
INFO - 2018-05-08 15:03:37 --> Model Class Initialized
INFO - 2018-05-08 15:03:37 --> Model Class Initialized
INFO - 2018-05-08 15:03:37 --> Model Class Initialized
INFO - 2018-05-08 15:03:37 --> Model Class Initialized
INFO - 2018-05-08 15:03:37 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-05-08 15:03:37 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 800
INFO - 2018-05-08 15:03:37 --> Final output sent to browser
DEBUG - 2018-05-08 15:03:37 --> Total execution time: 0.1122
INFO - 2018-05-08 09:33:41 --> Config Class Initialized
INFO - 2018-05-08 09:33:41 --> Hooks Class Initialized
DEBUG - 2018-05-08 09:33:41 --> UTF-8 Support Enabled
INFO - 2018-05-08 09:33:41 --> Utf8 Class Initialized
INFO - 2018-05-08 09:33:41 --> URI Class Initialized
INFO - 2018-05-08 09:33:41 --> Router Class Initialized
INFO - 2018-05-08 09:33:41 --> Output Class Initialized
INFO - 2018-05-08 09:33:41 --> Security Class Initialized
DEBUG - 2018-05-08 09:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 09:33:41 --> Input Class Initialized
INFO - 2018-05-08 09:33:41 --> Language Class Initialized
INFO - 2018-05-08 09:33:41 --> Language Class Initialized
INFO - 2018-05-08 09:33:41 --> Config Class Initialized
INFO - 2018-05-08 09:33:41 --> Loader Class Initialized
INFO - 2018-05-08 15:03:41 --> Helper loaded: url_helper
INFO - 2018-05-08 15:03:41 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:03:41 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:03:41 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:03:41 --> Helper loaded: users_helper
INFO - 2018-05-08 15:03:41 --> Database Driver Class Initialized
DEBUG - 2018-05-08 15:03:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:03:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:03:41 --> Helper loaded: form_helper
INFO - 2018-05-08 15:03:41 --> Form Validation Class Initialized
INFO - 2018-05-08 15:03:41 --> Controller Class Initialized
INFO - 2018-05-08 15:03:41 --> Model Class Initialized
INFO - 2018-05-08 15:03:41 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 15:03:41 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:03:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:03:41 --> Model Class Initialized
INFO - 2018-05-08 15:03:41 --> Model Class Initialized
INFO - 2018-05-08 15:03:41 --> Model Class Initialized
INFO - 2018-05-08 15:03:41 --> Model Class Initialized
INFO - 2018-05-08 15:03:41 --> Model Class Initialized
INFO - 2018-05-08 15:03:41 --> Model Class Initialized
INFO - 2018-05-08 15:03:41 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-05-08 15:03:41 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 800
INFO - 2018-05-08 15:03:41 --> Final output sent to browser
DEBUG - 2018-05-08 15:03:41 --> Total execution time: 0.1160
INFO - 2018-05-08 09:35:28 --> Config Class Initialized
INFO - 2018-05-08 09:35:28 --> Hooks Class Initialized
DEBUG - 2018-05-08 09:35:28 --> UTF-8 Support Enabled
INFO - 2018-05-08 09:35:28 --> Utf8 Class Initialized
INFO - 2018-05-08 09:35:28 --> URI Class Initialized
INFO - 2018-05-08 09:35:28 --> Router Class Initialized
INFO - 2018-05-08 09:35:28 --> Output Class Initialized
INFO - 2018-05-08 09:35:28 --> Security Class Initialized
DEBUG - 2018-05-08 09:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 09:35:28 --> Input Class Initialized
INFO - 2018-05-08 09:35:28 --> Language Class Initialized
INFO - 2018-05-08 09:35:28 --> Language Class Initialized
INFO - 2018-05-08 09:35:28 --> Config Class Initialized
INFO - 2018-05-08 09:35:28 --> Loader Class Initialized
INFO - 2018-05-08 15:05:28 --> Helper loaded: url_helper
INFO - 2018-05-08 15:05:28 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:05:28 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:05:28 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:05:28 --> Helper loaded: users_helper
INFO - 2018-05-08 15:05:28 --> Database Driver Class Initialized
DEBUG - 2018-05-08 15:05:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:05:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:05:29 --> Helper loaded: form_helper
INFO - 2018-05-08 15:05:29 --> Form Validation Class Initialized
INFO - 2018-05-08 15:05:29 --> Controller Class Initialized
INFO - 2018-05-08 15:05:29 --> Model Class Initialized
INFO - 2018-05-08 15:05:29 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 15:05:29 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:05:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:05:29 --> Model Class Initialized
INFO - 2018-05-08 15:05:29 --> Model Class Initialized
INFO - 2018-05-08 15:05:29 --> Model Class Initialized
INFO - 2018-05-08 15:05:29 --> Model Class Initialized
INFO - 2018-05-08 15:05:29 --> Model Class Initialized
INFO - 2018-05-08 15:05:29 --> Model Class Initialized
INFO - 2018-05-08 15:05:29 --> Model Class Initialized
INFO - 2018-05-08 15:05:29 --> Model Class Initialized
INFO - 2018-05-08 15:05:29 --> Model Class Initialized
INFO - 2018-05-08 15:05:29 --> Model Class Initialized
INFO - 2018-05-08 15:05:29 --> Model Class Initialized
INFO - 2018-05-08 15:05:29 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 15:05:29 --> Model Class Initialized
INFO - 2018-05-08 15:05:29 --> Final output sent to browser
DEBUG - 2018-05-08 15:05:29 --> Total execution time: 0.0996
INFO - 2018-05-08 09:38:04 --> Config Class Initialized
INFO - 2018-05-08 09:38:04 --> Hooks Class Initialized
DEBUG - 2018-05-08 09:38:04 --> UTF-8 Support Enabled
INFO - 2018-05-08 09:38:04 --> Utf8 Class Initialized
INFO - 2018-05-08 09:38:04 --> URI Class Initialized
INFO - 2018-05-08 09:38:04 --> Router Class Initialized
INFO - 2018-05-08 09:38:04 --> Output Class Initialized
INFO - 2018-05-08 09:38:04 --> Security Class Initialized
DEBUG - 2018-05-08 09:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 09:38:04 --> Input Class Initialized
INFO - 2018-05-08 09:38:04 --> Language Class Initialized
INFO - 2018-05-08 09:38:04 --> Language Class Initialized
INFO - 2018-05-08 09:38:04 --> Config Class Initialized
INFO - 2018-05-08 09:38:04 --> Loader Class Initialized
INFO - 2018-05-08 15:08:04 --> Helper loaded: url_helper
INFO - 2018-05-08 15:08:04 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:08:04 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:08:04 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:08:04 --> Helper loaded: users_helper
INFO - 2018-05-08 15:08:04 --> Database Driver Class Initialized
DEBUG - 2018-05-08 15:08:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:08:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:08:04 --> Helper loaded: form_helper
INFO - 2018-05-08 15:08:04 --> Form Validation Class Initialized
INFO - 2018-05-08 15:08:04 --> Controller Class Initialized
INFO - 2018-05-08 15:08:04 --> Model Class Initialized
INFO - 2018-05-08 15:08:04 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 15:08:04 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:08:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:08:04 --> Model Class Initialized
INFO - 2018-05-08 15:08:04 --> Model Class Initialized
INFO - 2018-05-08 15:08:04 --> Model Class Initialized
INFO - 2018-05-08 15:08:04 --> Model Class Initialized
INFO - 2018-05-08 15:08:04 --> Model Class Initialized
INFO - 2018-05-08 15:08:04 --> Model Class Initialized
INFO - 2018-05-08 15:08:04 --> Model Class Initialized
INFO - 2018-05-08 15:08:04 --> Model Class Initialized
INFO - 2018-05-08 15:08:04 --> Model Class Initialized
INFO - 2018-05-08 15:08:04 --> Model Class Initialized
INFO - 2018-05-08 15:08:04 --> Model Class Initialized
INFO - 2018-05-08 15:08:04 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 15:08:04 --> Model Class Initialized
INFO - 2018-05-08 15:08:04 --> Final output sent to browser
DEBUG - 2018-05-08 15:08:04 --> Total execution time: 0.1375
INFO - 2018-05-08 09:38:08 --> Config Class Initialized
INFO - 2018-05-08 09:38:08 --> Hooks Class Initialized
DEBUG - 2018-05-08 09:38:08 --> UTF-8 Support Enabled
INFO - 2018-05-08 09:38:08 --> Utf8 Class Initialized
INFO - 2018-05-08 09:38:08 --> URI Class Initialized
INFO - 2018-05-08 09:38:08 --> Router Class Initialized
INFO - 2018-05-08 09:38:08 --> Output Class Initialized
INFO - 2018-05-08 09:38:08 --> Security Class Initialized
DEBUG - 2018-05-08 09:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 09:38:08 --> Input Class Initialized
INFO - 2018-05-08 09:38:08 --> Language Class Initialized
INFO - 2018-05-08 09:38:08 --> Language Class Initialized
INFO - 2018-05-08 09:38:08 --> Config Class Initialized
INFO - 2018-05-08 09:38:08 --> Loader Class Initialized
INFO - 2018-05-08 15:08:08 --> Helper loaded: url_helper
INFO - 2018-05-08 15:08:08 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:08:08 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:08:08 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:08:08 --> Helper loaded: users_helper
INFO - 2018-05-08 15:08:08 --> Database Driver Class Initialized
DEBUG - 2018-05-08 15:08:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:08:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:08:08 --> Helper loaded: form_helper
INFO - 2018-05-08 15:08:08 --> Form Validation Class Initialized
INFO - 2018-05-08 15:08:08 --> Controller Class Initialized
INFO - 2018-05-08 15:08:08 --> Model Class Initialized
INFO - 2018-05-08 15:08:08 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 15:08:08 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:08:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:08:08 --> Model Class Initialized
INFO - 2018-05-08 15:08:08 --> Model Class Initialized
INFO - 2018-05-08 15:08:08 --> Model Class Initialized
INFO - 2018-05-08 15:08:08 --> Model Class Initialized
INFO - 2018-05-08 15:08:08 --> Model Class Initialized
INFO - 2018-05-08 15:08:08 --> Model Class Initialized
INFO - 2018-05-08 15:08:08 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 15:08:08 --> Model Class Initialized
INFO - 2018-05-08 15:08:08 --> Final output sent to browser
DEBUG - 2018-05-08 15:08:08 --> Total execution time: 0.1123
INFO - 2018-05-08 09:38:23 --> Config Class Initialized
INFO - 2018-05-08 09:38:23 --> Hooks Class Initialized
DEBUG - 2018-05-08 09:38:23 --> UTF-8 Support Enabled
INFO - 2018-05-08 09:38:23 --> Utf8 Class Initialized
INFO - 2018-05-08 09:38:23 --> URI Class Initialized
INFO - 2018-05-08 09:38:23 --> Router Class Initialized
INFO - 2018-05-08 09:38:23 --> Output Class Initialized
INFO - 2018-05-08 09:38:23 --> Security Class Initialized
DEBUG - 2018-05-08 09:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 09:38:23 --> Input Class Initialized
INFO - 2018-05-08 09:38:23 --> Language Class Initialized
INFO - 2018-05-08 09:38:23 --> Language Class Initialized
INFO - 2018-05-08 09:38:23 --> Config Class Initialized
INFO - 2018-05-08 09:38:23 --> Loader Class Initialized
INFO - 2018-05-08 15:08:23 --> Helper loaded: url_helper
INFO - 2018-05-08 15:08:23 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:08:23 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:08:23 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:08:23 --> Helper loaded: users_helper
INFO - 2018-05-08 15:08:23 --> Database Driver Class Initialized
DEBUG - 2018-05-08 15:08:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:08:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:08:23 --> Helper loaded: form_helper
INFO - 2018-05-08 15:08:23 --> Form Validation Class Initialized
INFO - 2018-05-08 15:08:23 --> Controller Class Initialized
INFO - 2018-05-08 15:08:23 --> Model Class Initialized
INFO - 2018-05-08 15:08:23 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 15:08:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:08:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:08:23 --> Model Class Initialized
INFO - 2018-05-08 15:08:23 --> Model Class Initialized
INFO - 2018-05-08 15:08:23 --> Model Class Initialized
INFO - 2018-05-08 15:08:23 --> Model Class Initialized
INFO - 2018-05-08 15:08:23 --> Final output sent to browser
DEBUG - 2018-05-08 15:08:23 --> Total execution time: 0.1787
INFO - 2018-05-08 09:38:33 --> Config Class Initialized
INFO - 2018-05-08 09:38:33 --> Hooks Class Initialized
DEBUG - 2018-05-08 09:38:33 --> UTF-8 Support Enabled
INFO - 2018-05-08 09:38:33 --> Utf8 Class Initialized
INFO - 2018-05-08 09:38:33 --> URI Class Initialized
INFO - 2018-05-08 09:38:33 --> Router Class Initialized
INFO - 2018-05-08 09:38:33 --> Output Class Initialized
INFO - 2018-05-08 09:38:33 --> Security Class Initialized
DEBUG - 2018-05-08 09:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 09:38:33 --> Input Class Initialized
INFO - 2018-05-08 09:38:33 --> Language Class Initialized
INFO - 2018-05-08 09:38:33 --> Language Class Initialized
INFO - 2018-05-08 09:38:33 --> Config Class Initialized
INFO - 2018-05-08 09:38:33 --> Loader Class Initialized
INFO - 2018-05-08 15:08:33 --> Helper loaded: url_helper
INFO - 2018-05-08 15:08:33 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:08:33 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:08:33 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:08:33 --> Helper loaded: users_helper
INFO - 2018-05-08 15:08:33 --> Database Driver Class Initialized
DEBUG - 2018-05-08 15:08:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:08:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:08:33 --> Helper loaded: form_helper
INFO - 2018-05-08 15:08:33 --> Form Validation Class Initialized
INFO - 2018-05-08 15:08:33 --> Controller Class Initialized
INFO - 2018-05-08 15:08:33 --> Model Class Initialized
INFO - 2018-05-08 15:08:33 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 15:08:33 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:08:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:08:33 --> Model Class Initialized
INFO - 2018-05-08 15:08:33 --> Model Class Initialized
INFO - 2018-05-08 15:08:33 --> Model Class Initialized
INFO - 2018-05-08 15:08:33 --> Model Class Initialized
INFO - 2018-05-08 15:08:33 --> Final output sent to browser
DEBUG - 2018-05-08 15:08:33 --> Total execution time: 0.1018
INFO - 2018-05-08 09:38:44 --> Config Class Initialized
INFO - 2018-05-08 09:38:44 --> Hooks Class Initialized
DEBUG - 2018-05-08 09:38:44 --> UTF-8 Support Enabled
INFO - 2018-05-08 09:38:44 --> Utf8 Class Initialized
INFO - 2018-05-08 09:38:44 --> URI Class Initialized
INFO - 2018-05-08 09:38:44 --> Router Class Initialized
INFO - 2018-05-08 09:38:44 --> Output Class Initialized
INFO - 2018-05-08 09:38:44 --> Security Class Initialized
DEBUG - 2018-05-08 09:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 09:38:44 --> Input Class Initialized
INFO - 2018-05-08 09:38:44 --> Language Class Initialized
INFO - 2018-05-08 09:38:44 --> Language Class Initialized
INFO - 2018-05-08 09:38:44 --> Config Class Initialized
INFO - 2018-05-08 09:38:44 --> Loader Class Initialized
INFO - 2018-05-08 15:08:44 --> Helper loaded: url_helper
INFO - 2018-05-08 15:08:44 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:08:44 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:08:44 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:08:44 --> Helper loaded: users_helper
INFO - 2018-05-08 15:08:44 --> Database Driver Class Initialized
DEBUG - 2018-05-08 15:08:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:08:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:08:44 --> Helper loaded: form_helper
INFO - 2018-05-08 15:08:44 --> Form Validation Class Initialized
INFO - 2018-05-08 15:08:44 --> Controller Class Initialized
INFO - 2018-05-08 15:08:44 --> Model Class Initialized
INFO - 2018-05-08 15:08:44 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 15:08:44 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:08:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:08:44 --> Model Class Initialized
INFO - 2018-05-08 15:08:44 --> Model Class Initialized
INFO - 2018-05-08 15:08:44 --> Model Class Initialized
INFO - 2018-05-08 15:08:44 --> Model Class Initialized
INFO - 2018-05-08 15:08:44 --> Model Class Initialized
INFO - 2018-05-08 15:08:44 --> Model Class Initialized
INFO - 2018-05-08 15:08:44 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-05-08 15:08:44 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 800
INFO - 2018-05-08 15:08:44 --> Final output sent to browser
DEBUG - 2018-05-08 15:08:44 --> Total execution time: 0.1406
INFO - 2018-05-08 09:38:55 --> Config Class Initialized
INFO - 2018-05-08 09:38:55 --> Hooks Class Initialized
DEBUG - 2018-05-08 09:38:55 --> UTF-8 Support Enabled
INFO - 2018-05-08 09:38:55 --> Utf8 Class Initialized
INFO - 2018-05-08 09:38:55 --> URI Class Initialized
INFO - 2018-05-08 09:38:55 --> Router Class Initialized
INFO - 2018-05-08 09:38:55 --> Output Class Initialized
INFO - 2018-05-08 09:38:55 --> Security Class Initialized
DEBUG - 2018-05-08 09:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 09:38:55 --> Input Class Initialized
INFO - 2018-05-08 09:38:55 --> Language Class Initialized
INFO - 2018-05-08 09:38:55 --> Language Class Initialized
INFO - 2018-05-08 09:38:55 --> Config Class Initialized
INFO - 2018-05-08 09:38:55 --> Loader Class Initialized
INFO - 2018-05-08 15:08:55 --> Helper loaded: url_helper
INFO - 2018-05-08 15:08:55 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:08:55 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:08:55 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:08:55 --> Helper loaded: users_helper
INFO - 2018-05-08 15:08:55 --> Database Driver Class Initialized
DEBUG - 2018-05-08 15:08:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:08:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:08:55 --> Helper loaded: form_helper
INFO - 2018-05-08 15:08:55 --> Form Validation Class Initialized
INFO - 2018-05-08 15:08:55 --> Controller Class Initialized
INFO - 2018-05-08 15:08:55 --> Model Class Initialized
INFO - 2018-05-08 15:08:55 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 15:08:55 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:08:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:08:55 --> Model Class Initialized
INFO - 2018-05-08 15:08:55 --> Model Class Initialized
INFO - 2018-05-08 15:08:55 --> Model Class Initialized
INFO - 2018-05-08 15:08:55 --> Model Class Initialized
INFO - 2018-05-08 15:08:55 --> Model Class Initialized
INFO - 2018-05-08 15:08:55 --> Model Class Initialized
INFO - 2018-05-08 15:08:55 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 15:08:55 --> Final output sent to browser
DEBUG - 2018-05-08 15:08:55 --> Total execution time: 0.1257
INFO - 2018-05-08 09:39:21 --> Config Class Initialized
INFO - 2018-05-08 09:39:21 --> Hooks Class Initialized
DEBUG - 2018-05-08 09:39:21 --> UTF-8 Support Enabled
INFO - 2018-05-08 09:39:21 --> Utf8 Class Initialized
INFO - 2018-05-08 09:39:21 --> URI Class Initialized
INFO - 2018-05-08 09:39:21 --> Router Class Initialized
INFO - 2018-05-08 09:39:21 --> Output Class Initialized
INFO - 2018-05-08 09:39:21 --> Security Class Initialized
DEBUG - 2018-05-08 09:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 09:39:21 --> Input Class Initialized
INFO - 2018-05-08 09:39:21 --> Language Class Initialized
INFO - 2018-05-08 09:39:21 --> Language Class Initialized
INFO - 2018-05-08 09:39:21 --> Config Class Initialized
INFO - 2018-05-08 09:39:21 --> Loader Class Initialized
INFO - 2018-05-08 15:09:21 --> Helper loaded: url_helper
INFO - 2018-05-08 15:09:21 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:09:21 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:09:21 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:09:21 --> Helper loaded: users_helper
INFO - 2018-05-08 15:09:21 --> Database Driver Class Initialized
DEBUG - 2018-05-08 15:09:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:09:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:09:21 --> Helper loaded: form_helper
INFO - 2018-05-08 15:09:21 --> Form Validation Class Initialized
INFO - 2018-05-08 15:09:21 --> Controller Class Initialized
INFO - 2018-05-08 15:09:21 --> Model Class Initialized
INFO - 2018-05-08 15:09:21 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 15:09:21 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:09:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:09:21 --> Model Class Initialized
INFO - 2018-05-08 15:09:21 --> Model Class Initialized
INFO - 2018-05-08 15:09:21 --> Model Class Initialized
INFO - 2018-05-08 15:09:21 --> Model Class Initialized
INFO - 2018-05-08 15:09:21 --> Model Class Initialized
INFO - 2018-05-08 15:09:21 --> Model Class Initialized
INFO - 2018-05-08 15:09:21 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 15:09:21 --> Final output sent to browser
DEBUG - 2018-05-08 15:09:21 --> Total execution time: 0.1573
INFO - 2018-05-08 09:47:24 --> Config Class Initialized
INFO - 2018-05-08 09:47:24 --> Hooks Class Initialized
DEBUG - 2018-05-08 09:47:24 --> UTF-8 Support Enabled
INFO - 2018-05-08 09:47:24 --> Utf8 Class Initialized
INFO - 2018-05-08 09:47:24 --> URI Class Initialized
INFO - 2018-05-08 09:47:24 --> Router Class Initialized
INFO - 2018-05-08 09:47:24 --> Output Class Initialized
INFO - 2018-05-08 09:47:24 --> Security Class Initialized
DEBUG - 2018-05-08 09:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 09:47:24 --> Input Class Initialized
INFO - 2018-05-08 09:47:24 --> Config Class Initialized
INFO - 2018-05-08 09:47:24 --> Hooks Class Initialized
INFO - 2018-05-08 09:47:24 --> Language Class Initialized
DEBUG - 2018-05-08 09:47:24 --> UTF-8 Support Enabled
INFO - 2018-05-08 09:47:24 --> Utf8 Class Initialized
INFO - 2018-05-08 09:47:24 --> URI Class Initialized
INFO - 2018-05-08 09:47:24 --> Router Class Initialized
INFO - 2018-05-08 09:47:24 --> Output Class Initialized
INFO - 2018-05-08 09:47:24 --> Config Class Initialized
INFO - 2018-05-08 09:47:24 --> Hooks Class Initialized
INFO - 2018-05-08 09:47:24 --> Security Class Initialized
DEBUG - 2018-05-08 09:47:24 --> UTF-8 Support Enabled
INFO - 2018-05-08 09:47:24 --> Utf8 Class Initialized
DEBUG - 2018-05-08 09:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 09:47:24 --> Input Class Initialized
INFO - 2018-05-08 09:47:24 --> Language Class Initialized
INFO - 2018-05-08 09:47:24 --> URI Class Initialized
INFO - 2018-05-08 09:47:24 --> Config Class Initialized
INFO - 2018-05-08 09:47:24 --> Hooks Class Initialized
DEBUG - 2018-05-08 09:47:24 --> UTF-8 Support Enabled
INFO - 2018-05-08 09:47:24 --> Utf8 Class Initialized
INFO - 2018-05-08 09:47:24 --> URI Class Initialized
INFO - 2018-05-08 09:47:24 --> Router Class Initialized
INFO - 2018-05-08 09:47:24 --> Router Class Initialized
INFO - 2018-05-08 09:47:24 --> Output Class Initialized
INFO - 2018-05-08 09:47:24 --> Output Class Initialized
INFO - 2018-05-08 09:47:24 --> Security Class Initialized
DEBUG - 2018-05-08 09:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 09:47:25 --> Input Class Initialized
INFO - 2018-05-08 09:47:25 --> Language Class Initialized
INFO - 2018-05-08 09:47:25 --> Config Class Initialized
INFO - 2018-05-08 09:47:25 --> Loader Class Initialized
INFO - 2018-05-08 09:47:25 --> Security Class Initialized
INFO - 2018-05-08 09:47:25 --> Language Class Initialized
INFO - 2018-05-08 09:47:25 --> Config Class Initialized
INFO - 2018-05-08 09:47:25 --> Hooks Class Initialized
DEBUG - 2018-05-08 09:47:25 --> UTF-8 Support Enabled
INFO - 2018-05-08 09:47:25 --> Utf8 Class Initialized
DEBUG - 2018-05-08 09:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 09:47:25 --> Input Class Initialized
INFO - 2018-05-08 09:47:25 --> Language Class Initialized
INFO - 2018-05-08 09:47:25 --> URI Class Initialized
INFO - 2018-05-08 09:47:25 --> Language Class Initialized
INFO - 2018-05-08 09:47:25 --> Config Class Initialized
INFO - 2018-05-08 09:47:25 --> Loader Class Initialized
INFO - 2018-05-08 09:47:25 --> Router Class Initialized
INFO - 2018-05-08 15:17:25 --> Helper loaded: url_helper
INFO - 2018-05-08 15:17:25 --> Helper loaded: url_helper
INFO - 2018-05-08 15:17:25 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:17:25 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:17:25 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:17:25 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:17:25 --> Helper loaded: permission_helper
INFO - 2018-05-08 09:47:25 --> Language Class Initialized
INFO - 2018-05-08 09:47:25 --> Config Class Initialized
INFO - 2018-05-08 09:47:25 --> Loader Class Initialized
INFO - 2018-05-08 15:17:25 --> Helper loaded: permission_helper
INFO - 2018-05-08 09:47:25 --> Output Class Initialized
INFO - 2018-05-08 15:17:25 --> Helper loaded: url_helper
INFO - 2018-05-08 15:17:25 --> Helper loaded: users_helper
INFO - 2018-05-08 15:17:25 --> Helper loaded: users_helper
INFO - 2018-05-08 15:17:25 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:17:25 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:17:25 --> Helper loaded: permission_helper
INFO - 2018-05-08 09:47:25 --> Security Class Initialized
INFO - 2018-05-08 15:17:25 --> Helper loaded: users_helper
DEBUG - 2018-05-08 09:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 09:47:25 --> Input Class Initialized
INFO - 2018-05-08 09:47:25 --> Language Class Initialized
INFO - 2018-05-08 15:17:25 --> Database Driver Class Initialized
INFO - 2018-05-08 09:47:25 --> Language Class Initialized
INFO - 2018-05-08 09:47:25 --> Config Class Initialized
INFO - 2018-05-08 09:47:25 --> Language Class Initialized
INFO - 2018-05-08 09:47:25 --> Loader Class Initialized
INFO - 2018-05-08 09:47:25 --> Config Class Initialized
INFO - 2018-05-08 09:47:25 --> Loader Class Initialized
INFO - 2018-05-08 15:17:25 --> Database Driver Class Initialized
DEBUG - 2018-05-08 15:17:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:17:25 --> Helper loaded: url_helper
INFO - 2018-05-08 15:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:17:25 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:17:25 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:17:25 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:17:25 --> Helper loaded: url_helper
INFO - 2018-05-08 15:17:25 --> Helper loaded: users_helper
INFO - 2018-05-08 15:17:25 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:17:25 --> Helper loaded: settings_helper
DEBUG - 2018-05-08 15:17:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:17:25 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:17:25 --> Helper loaded: users_helper
INFO - 2018-05-08 15:17:25 --> Database Driver Class Initialized
INFO - 2018-05-08 15:17:25 --> Helper loaded: form_helper
INFO - 2018-05-08 15:17:25 --> Form Validation Class Initialized
INFO - 2018-05-08 15:17:25 --> Controller Class Initialized
INFO - 2018-05-08 15:17:25 --> Database Driver Class Initialized
DEBUG - 2018-05-08 15:17:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:17:25 --> Helper loaded: form_helper
INFO - 2018-05-08 15:17:25 --> Form Validation Class Initialized
INFO - 2018-05-08 15:17:25 --> Controller Class Initialized
INFO - 2018-05-08 15:17:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-05-08 15:17:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:17:25 --> Helper loaded: form_helper
INFO - 2018-05-08 15:17:25 --> Form Validation Class Initialized
INFO - 2018-05-08 15:17:25 --> Controller Class Initialized
INFO - 2018-05-08 15:17:25 --> Model Class Initialized
INFO - 2018-05-08 15:17:25 --> Helper loaded: inflector_helper
INFO - 2018-05-08 15:17:25 --> Helper loaded: form_helper
INFO - 2018-05-08 15:17:25 --> Form Validation Class Initialized
INFO - 2018-05-08 15:17:25 --> Controller Class Initialized
INFO - 2018-05-08 15:17:25 --> Model Class Initialized
INFO - 2018-05-08 15:17:25 --> Database Driver Class Initialized
DEBUG - 2018-05-08 15:17:25 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:17:25 --> Model Class Initialized
INFO - 2018-05-08 15:17:25 --> Helper loaded: inflector_helper
INFO - 2018-05-08 15:17:25 --> Helper loaded: inflector_helper
INFO - 2018-05-08 15:17:25 --> Model Class Initialized
DEBUG - 2018-05-08 15:17:25 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:17:25 --> Language file loaded: language/english/rest_controller_lang.php
DEBUG - 2018-05-08 15:17:25 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:17:25 --> Helper loaded: inflector_helper
INFO - 2018-05-08 15:17:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:17:25 --> Language file loaded: language/english/rest_controller_lang.php
DEBUG - 2018-05-08 15:17:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:17:25 --> Model Class Initialized
INFO - 2018-05-08 15:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:17:25 --> Model Class Initialized
INFO - 2018-05-08 15:17:25 --> Model Class Initialized
INFO - 2018-05-08 15:17:25 --> Model Class Initialized
INFO - 2018-05-08 15:17:25 --> Model Class Initialized
INFO - 2018-05-08 15:17:25 --> Model Class Initialized
INFO - 2018-05-08 15:17:25 --> Model Class Initialized
INFO - 2018-05-08 15:17:25 --> Model Class Initialized
INFO - 2018-05-08 15:17:25 --> Model Class Initialized
INFO - 2018-05-08 15:17:25 --> Model Class Initialized
INFO - 2018-05-08 15:17:25 --> Model Class Initialized
INFO - 2018-05-08 15:17:25 --> Model Class Initialized
INFO - 2018-05-08 15:17:25 --> Model Class Initialized
INFO - 2018-05-08 15:17:25 --> Model Class Initialized
INFO - 2018-05-08 15:17:25 --> Model Class Initialized
INFO - 2018-05-08 15:17:25 --> Model Class Initialized
INFO - 2018-05-08 15:17:25 --> Model Class Initialized
INFO - 2018-05-08 15:17:25 --> Model Class Initialized
INFO - 2018-05-08 15:17:25 --> Model Class Initialized
INFO - 2018-05-08 15:17:25 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 15:17:25 --> Model Class Initialized
DEBUG - 2018-05-08 15:17:25 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:17:25 --> Helper loaded: form_helper
INFO - 2018-05-08 15:17:25 --> Form Validation Class Initialized
INFO - 2018-05-08 15:17:25 --> Controller Class Initialized
INFO - 2018-05-08 15:17:25 --> Model Class Initialized
INFO - 2018-05-08 15:17:25 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 15:17:25 --> Model Class Initialized
INFO - 2018-05-08 15:17:25 --> Model Class Initialized
INFO - 2018-05-08 15:17:25 --> Model Class Initialized
INFO - 2018-05-08 15:17:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:17:25 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 15:17:25 --> Model Class Initialized
INFO - 2018-05-08 15:17:25 --> Model Class Initialized
INFO - 2018-05-08 15:17:25 --> Model Class Initialized
INFO - 2018-05-08 15:17:25 --> Final output sent to browser
DEBUG - 2018-05-08 15:17:25 --> Total execution time: 0.1406
INFO - 2018-05-08 15:17:25 --> Model Class Initialized
INFO - 2018-05-08 15:17:25 --> Model Class Initialized
INFO - 2018-05-08 15:17:25 --> Final output sent to browser
DEBUG - 2018-05-08 15:17:25 --> Total execution time: 0.1821
INFO - 2018-05-08 15:17:25 --> Model Class Initialized
INFO - 2018-05-08 15:17:25 --> Model Class Initialized
INFO - 2018-05-08 15:17:25 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 15:17:25 --> Model Class Initialized
INFO - 2018-05-08 15:17:25 --> Helper loaded: inflector_helper
INFO - 2018-05-08 15:17:25 --> Final output sent to browser
DEBUG - 2018-05-08 15:17:25 --> Total execution time: 0.1268
INFO - 2018-05-08 15:17:25 --> Model Class Initialized
DEBUG - 2018-05-08 15:17:25 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:17:25 --> Final output sent to browser
DEBUG - 2018-05-08 15:17:25 --> Total execution time: 0.2142
INFO - 2018-05-08 15:17:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:17:25 --> Model Class Initialized
INFO - 2018-05-08 15:17:25 --> Model Class Initialized
INFO - 2018-05-08 15:17:25 --> Model Class Initialized
INFO - 2018-05-08 15:17:25 --> Model Class Initialized
INFO - 2018-05-08 15:17:25 --> Model Class Initialized
INFO - 2018-05-08 15:17:25 --> Model Class Initialized
INFO - 2018-05-08 15:17:25 --> Model Class Initialized
INFO - 2018-05-08 15:17:25 --> Model Class Initialized
INFO - 2018-05-08 15:17:25 --> Model Class Initialized
INFO - 2018-05-08 15:17:25 --> Model Class Initialized
INFO - 2018-05-08 15:17:25 --> Model Class Initialized
INFO - 2018-05-08 15:17:25 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 15:17:25 --> Model Class Initialized
INFO - 2018-05-08 15:17:25 --> Final output sent to browser
DEBUG - 2018-05-08 15:17:25 --> Total execution time: 0.1880
INFO - 2018-05-08 09:47:27 --> Config Class Initialized
INFO - 2018-05-08 09:47:27 --> Hooks Class Initialized
DEBUG - 2018-05-08 09:47:27 --> UTF-8 Support Enabled
INFO - 2018-05-08 09:47:27 --> Utf8 Class Initialized
INFO - 2018-05-08 09:47:27 --> URI Class Initialized
INFO - 2018-05-08 09:47:27 --> Router Class Initialized
INFO - 2018-05-08 09:47:27 --> Output Class Initialized
INFO - 2018-05-08 09:47:27 --> Security Class Initialized
DEBUG - 2018-05-08 09:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 09:47:27 --> Input Class Initialized
INFO - 2018-05-08 09:47:27 --> Language Class Initialized
INFO - 2018-05-08 09:47:27 --> Language Class Initialized
INFO - 2018-05-08 09:47:27 --> Config Class Initialized
INFO - 2018-05-08 09:47:27 --> Loader Class Initialized
INFO - 2018-05-08 15:17:27 --> Helper loaded: url_helper
INFO - 2018-05-08 15:17:27 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:17:27 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:17:27 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:17:27 --> Helper loaded: users_helper
INFO - 2018-05-08 09:47:27 --> Config Class Initialized
INFO - 2018-05-08 09:47:27 --> Hooks Class Initialized
DEBUG - 2018-05-08 09:47:27 --> UTF-8 Support Enabled
INFO - 2018-05-08 09:47:27 --> Utf8 Class Initialized
INFO - 2018-05-08 15:17:27 --> Database Driver Class Initialized
INFO - 2018-05-08 09:47:27 --> URI Class Initialized
DEBUG - 2018-05-08 15:17:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:17:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 09:47:27 --> Router Class Initialized
INFO - 2018-05-08 09:47:27 --> Output Class Initialized
INFO - 2018-05-08 15:17:27 --> Helper loaded: form_helper
INFO - 2018-05-08 15:17:27 --> Form Validation Class Initialized
INFO - 2018-05-08 09:47:27 --> Security Class Initialized
INFO - 2018-05-08 15:17:27 --> Controller Class Initialized
DEBUG - 2018-05-08 09:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 09:47:27 --> Input Class Initialized
INFO - 2018-05-08 09:47:27 --> Language Class Initialized
INFO - 2018-05-08 15:17:27 --> Model Class Initialized
INFO - 2018-05-08 15:17:27 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 15:17:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:17:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:17:27 --> Model Class Initialized
INFO - 2018-05-08 15:17:27 --> Model Class Initialized
INFO - 2018-05-08 15:17:27 --> Model Class Initialized
INFO - 2018-05-08 15:17:27 --> Model Class Initialized
INFO - 2018-05-08 15:17:27 --> Model Class Initialized
INFO - 2018-05-08 15:17:27 --> Model Class Initialized
INFO - 2018-05-08 15:17:27 --> Model Class Initialized
INFO - 2018-05-08 15:17:27 --> Model Class Initialized
INFO - 2018-05-08 15:17:27 --> Model Class Initialized
INFO - 2018-05-08 15:17:27 --> Model Class Initialized
INFO - 2018-05-08 15:17:27 --> Model Class Initialized
INFO - 2018-05-08 15:17:27 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 15:17:27 --> Model Class Initialized
INFO - 2018-05-08 09:47:27 --> Language Class Initialized
INFO - 2018-05-08 09:47:27 --> Config Class Initialized
INFO - 2018-05-08 09:47:27 --> Loader Class Initialized
INFO - 2018-05-08 15:17:27 --> Helper loaded: url_helper
INFO - 2018-05-08 15:17:27 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:17:27 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:17:27 --> Final output sent to browser
DEBUG - 2018-05-08 15:17:27 --> Total execution time: 0.1227
INFO - 2018-05-08 15:17:27 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:17:27 --> Helper loaded: users_helper
INFO - 2018-05-08 15:17:27 --> Database Driver Class Initialized
DEBUG - 2018-05-08 15:17:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:17:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:17:27 --> Helper loaded: form_helper
INFO - 2018-05-08 15:17:27 --> Form Validation Class Initialized
INFO - 2018-05-08 15:17:27 --> Controller Class Initialized
INFO - 2018-05-08 15:17:27 --> Model Class Initialized
INFO - 2018-05-08 15:17:27 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 15:17:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:17:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:17:27 --> Model Class Initialized
INFO - 2018-05-08 15:17:27 --> Model Class Initialized
INFO - 2018-05-08 15:17:27 --> Model Class Initialized
INFO - 2018-05-08 15:17:27 --> Model Class Initialized
INFO - 2018-05-08 15:17:27 --> Model Class Initialized
INFO - 2018-05-08 15:17:27 --> Model Class Initialized
INFO - 2018-05-08 15:17:27 --> Model Class Initialized
INFO - 2018-05-08 15:17:27 --> Model Class Initialized
INFO - 2018-05-08 15:17:27 --> Model Class Initialized
INFO - 2018-05-08 15:17:27 --> Model Class Initialized
INFO - 2018-05-08 15:17:27 --> Model Class Initialized
INFO - 2018-05-08 15:17:27 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 15:17:27 --> Final output sent to browser
DEBUG - 2018-05-08 15:17:27 --> Total execution time: 0.1429
INFO - 2018-05-08 09:47:29 --> Config Class Initialized
INFO - 2018-05-08 09:47:29 --> Hooks Class Initialized
DEBUG - 2018-05-08 09:47:29 --> UTF-8 Support Enabled
INFO - 2018-05-08 09:47:29 --> Utf8 Class Initialized
INFO - 2018-05-08 09:47:29 --> URI Class Initialized
INFO - 2018-05-08 09:47:29 --> Router Class Initialized
INFO - 2018-05-08 09:47:29 --> Output Class Initialized
INFO - 2018-05-08 09:47:29 --> Security Class Initialized
DEBUG - 2018-05-08 09:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 09:47:29 --> Input Class Initialized
INFO - 2018-05-08 09:47:29 --> Language Class Initialized
INFO - 2018-05-08 09:47:29 --> Language Class Initialized
INFO - 2018-05-08 09:47:29 --> Config Class Initialized
INFO - 2018-05-08 09:47:29 --> Loader Class Initialized
INFO - 2018-05-08 15:17:29 --> Helper loaded: url_helper
INFO - 2018-05-08 15:17:29 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:17:29 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:17:29 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:17:29 --> Helper loaded: users_helper
INFO - 2018-05-08 15:17:29 --> Database Driver Class Initialized
DEBUG - 2018-05-08 15:17:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:17:29 --> Helper loaded: form_helper
INFO - 2018-05-08 15:17:29 --> Form Validation Class Initialized
INFO - 2018-05-08 15:17:29 --> Controller Class Initialized
INFO - 2018-05-08 15:17:29 --> Model Class Initialized
INFO - 2018-05-08 15:17:29 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 15:17:29 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:17:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:17:29 --> Model Class Initialized
INFO - 2018-05-08 15:17:29 --> Model Class Initialized
INFO - 2018-05-08 15:17:29 --> Model Class Initialized
INFO - 2018-05-08 15:17:29 --> Model Class Initialized
INFO - 2018-05-08 15:17:29 --> Final output sent to browser
DEBUG - 2018-05-08 15:17:29 --> Total execution time: 0.1189
INFO - 2018-05-08 09:47:30 --> Config Class Initialized
INFO - 2018-05-08 09:47:30 --> Hooks Class Initialized
DEBUG - 2018-05-08 09:47:30 --> UTF-8 Support Enabled
INFO - 2018-05-08 09:47:30 --> Utf8 Class Initialized
INFO - 2018-05-08 09:47:30 --> URI Class Initialized
INFO - 2018-05-08 09:47:30 --> Router Class Initialized
INFO - 2018-05-08 09:47:30 --> Output Class Initialized
INFO - 2018-05-08 09:47:30 --> Security Class Initialized
DEBUG - 2018-05-08 09:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 09:47:30 --> Input Class Initialized
INFO - 2018-05-08 09:47:30 --> Language Class Initialized
INFO - 2018-05-08 09:47:30 --> Language Class Initialized
INFO - 2018-05-08 09:47:30 --> Config Class Initialized
INFO - 2018-05-08 09:47:30 --> Loader Class Initialized
INFO - 2018-05-08 15:17:30 --> Helper loaded: url_helper
INFO - 2018-05-08 15:17:30 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:17:30 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:17:30 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:17:30 --> Helper loaded: users_helper
INFO - 2018-05-08 15:17:30 --> Database Driver Class Initialized
DEBUG - 2018-05-08 15:17:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:17:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:17:30 --> Helper loaded: form_helper
INFO - 2018-05-08 15:17:30 --> Form Validation Class Initialized
INFO - 2018-05-08 15:17:30 --> Controller Class Initialized
INFO - 2018-05-08 15:17:30 --> Model Class Initialized
INFO - 2018-05-08 15:17:30 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 15:17:30 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:17:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:17:30 --> Model Class Initialized
INFO - 2018-05-08 15:17:30 --> Model Class Initialized
INFO - 2018-05-08 15:17:30 --> Model Class Initialized
INFO - 2018-05-08 15:17:30 --> Model Class Initialized
INFO - 2018-05-08 15:17:30 --> Final output sent to browser
DEBUG - 2018-05-08 15:17:30 --> Total execution time: 0.1096
INFO - 2018-05-08 09:47:30 --> Config Class Initialized
INFO - 2018-05-08 09:47:30 --> Hooks Class Initialized
DEBUG - 2018-05-08 09:47:30 --> UTF-8 Support Enabled
INFO - 2018-05-08 09:47:30 --> Utf8 Class Initialized
INFO - 2018-05-08 09:47:30 --> URI Class Initialized
INFO - 2018-05-08 09:47:30 --> Router Class Initialized
INFO - 2018-05-08 09:47:30 --> Output Class Initialized
INFO - 2018-05-08 09:47:30 --> Security Class Initialized
DEBUG - 2018-05-08 09:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 09:47:30 --> Input Class Initialized
INFO - 2018-05-08 09:47:30 --> Language Class Initialized
INFO - 2018-05-08 09:47:30 --> Language Class Initialized
INFO - 2018-05-08 09:47:30 --> Config Class Initialized
INFO - 2018-05-08 09:47:30 --> Loader Class Initialized
INFO - 2018-05-08 15:17:30 --> Helper loaded: url_helper
INFO - 2018-05-08 15:17:30 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:17:30 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:17:30 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:17:30 --> Helper loaded: users_helper
INFO - 2018-05-08 15:17:31 --> Database Driver Class Initialized
DEBUG - 2018-05-08 15:17:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:17:31 --> Helper loaded: form_helper
INFO - 2018-05-08 15:17:31 --> Form Validation Class Initialized
INFO - 2018-05-08 15:17:31 --> Controller Class Initialized
INFO - 2018-05-08 15:17:31 --> Model Class Initialized
INFO - 2018-05-08 15:17:31 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 15:17:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:17:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:17:31 --> Model Class Initialized
INFO - 2018-05-08 15:17:31 --> Model Class Initialized
INFO - 2018-05-08 15:17:31 --> Model Class Initialized
INFO - 2018-05-08 15:17:31 --> Model Class Initialized
INFO - 2018-05-08 15:17:31 --> Final output sent to browser
DEBUG - 2018-05-08 15:17:31 --> Total execution time: 0.1017
INFO - 2018-05-08 09:47:33 --> Config Class Initialized
INFO - 2018-05-08 09:47:33 --> Hooks Class Initialized
DEBUG - 2018-05-08 09:47:34 --> UTF-8 Support Enabled
INFO - 2018-05-08 09:47:34 --> Utf8 Class Initialized
INFO - 2018-05-08 09:47:34 --> URI Class Initialized
INFO - 2018-05-08 09:47:34 --> Router Class Initialized
INFO - 2018-05-08 09:47:34 --> Output Class Initialized
INFO - 2018-05-08 09:47:34 --> Security Class Initialized
DEBUG - 2018-05-08 09:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 09:47:34 --> Input Class Initialized
INFO - 2018-05-08 09:47:34 --> Language Class Initialized
INFO - 2018-05-08 09:47:34 --> Language Class Initialized
INFO - 2018-05-08 09:47:34 --> Config Class Initialized
INFO - 2018-05-08 09:47:34 --> Loader Class Initialized
INFO - 2018-05-08 15:17:34 --> Helper loaded: url_helper
INFO - 2018-05-08 15:17:34 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:17:34 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:17:34 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:17:34 --> Helper loaded: users_helper
INFO - 2018-05-08 15:17:34 --> Database Driver Class Initialized
DEBUG - 2018-05-08 15:17:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:17:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:17:34 --> Helper loaded: form_helper
INFO - 2018-05-08 15:17:34 --> Form Validation Class Initialized
INFO - 2018-05-08 15:17:34 --> Controller Class Initialized
INFO - 2018-05-08 15:17:34 --> Model Class Initialized
INFO - 2018-05-08 15:17:34 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 15:17:34 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:17:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:17:34 --> Model Class Initialized
INFO - 2018-05-08 15:17:34 --> Model Class Initialized
INFO - 2018-05-08 15:17:34 --> Model Class Initialized
INFO - 2018-05-08 15:17:34 --> Model Class Initialized
INFO - 2018-05-08 15:17:34 --> Model Class Initialized
INFO - 2018-05-08 15:17:34 --> Model Class Initialized
INFO - 2018-05-08 15:17:34 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-05-08 15:17:34 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 800
ERROR - 2018-05-08 15:17:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 810
INFO - 2018-05-08 15:17:34 --> Final output sent to browser
DEBUG - 2018-05-08 15:17:34 --> Total execution time: 0.1336
INFO - 2018-05-08 09:47:37 --> Config Class Initialized
INFO - 2018-05-08 09:47:37 --> Hooks Class Initialized
DEBUG - 2018-05-08 09:47:37 --> UTF-8 Support Enabled
INFO - 2018-05-08 09:47:37 --> Utf8 Class Initialized
INFO - 2018-05-08 09:47:37 --> URI Class Initialized
INFO - 2018-05-08 09:47:37 --> Router Class Initialized
INFO - 2018-05-08 09:47:37 --> Output Class Initialized
INFO - 2018-05-08 09:47:37 --> Security Class Initialized
DEBUG - 2018-05-08 09:47:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 09:47:37 --> Input Class Initialized
INFO - 2018-05-08 09:47:37 --> Language Class Initialized
INFO - 2018-05-08 09:47:37 --> Language Class Initialized
INFO - 2018-05-08 09:47:37 --> Config Class Initialized
INFO - 2018-05-08 09:47:37 --> Loader Class Initialized
INFO - 2018-05-08 09:47:37 --> Config Class Initialized
INFO - 2018-05-08 09:47:37 --> Hooks Class Initialized
INFO - 2018-05-08 15:17:37 --> Helper loaded: url_helper
INFO - 2018-05-08 15:17:37 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:17:37 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:17:37 --> Helper loaded: permission_helper
DEBUG - 2018-05-08 09:47:37 --> UTF-8 Support Enabled
INFO - 2018-05-08 09:47:37 --> Utf8 Class Initialized
INFO - 2018-05-08 15:17:37 --> Helper loaded: users_helper
INFO - 2018-05-08 09:47:37 --> URI Class Initialized
INFO - 2018-05-08 09:47:37 --> Router Class Initialized
INFO - 2018-05-08 09:47:37 --> Output Class Initialized
INFO - 2018-05-08 15:17:37 --> Database Driver Class Initialized
INFO - 2018-05-08 09:47:37 --> Security Class Initialized
DEBUG - 2018-05-08 09:47:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 09:47:37 --> Input Class Initialized
DEBUG - 2018-05-08 15:17:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:17:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 09:47:37 --> Language Class Initialized
INFO - 2018-05-08 15:17:37 --> Helper loaded: form_helper
INFO - 2018-05-08 15:17:37 --> Form Validation Class Initialized
INFO - 2018-05-08 15:17:37 --> Controller Class Initialized
INFO - 2018-05-08 15:17:37 --> Model Class Initialized
INFO - 2018-05-08 15:17:37 --> Helper loaded: inflector_helper
INFO - 2018-05-08 09:47:37 --> Language Class Initialized
INFO - 2018-05-08 09:47:37 --> Config Class Initialized
INFO - 2018-05-08 09:47:37 --> Loader Class Initialized
DEBUG - 2018-05-08 15:17:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:17:37 --> Helper loaded: url_helper
INFO - 2018-05-08 15:17:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:17:37 --> Model Class Initialized
INFO - 2018-05-08 15:17:37 --> Model Class Initialized
INFO - 2018-05-08 15:17:37 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:17:37 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:17:37 --> Model Class Initialized
INFO - 2018-05-08 15:17:37 --> Model Class Initialized
INFO - 2018-05-08 15:17:37 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:17:37 --> Helper loaded: users_helper
INFO - 2018-05-08 15:17:37 --> Final output sent to browser
DEBUG - 2018-05-08 15:17:37 --> Total execution time: 0.1008
INFO - 2018-05-08 15:17:37 --> Database Driver Class Initialized
DEBUG - 2018-05-08 15:17:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:17:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:17:37 --> Helper loaded: form_helper
INFO - 2018-05-08 15:17:37 --> Form Validation Class Initialized
INFO - 2018-05-08 15:17:37 --> Controller Class Initialized
INFO - 2018-05-08 15:17:37 --> Model Class Initialized
INFO - 2018-05-08 15:17:37 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 15:17:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:17:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:17:37 --> Model Class Initialized
INFO - 2018-05-08 15:17:37 --> Model Class Initialized
INFO - 2018-05-08 15:17:37 --> Model Class Initialized
INFO - 2018-05-08 15:17:37 --> Model Class Initialized
INFO - 2018-05-08 15:17:37 --> Final output sent to browser
DEBUG - 2018-05-08 15:17:37 --> Total execution time: 0.1242
INFO - 2018-05-08 09:47:39 --> Config Class Initialized
INFO - 2018-05-08 09:47:39 --> Hooks Class Initialized
DEBUG - 2018-05-08 09:47:39 --> UTF-8 Support Enabled
INFO - 2018-05-08 09:47:39 --> Utf8 Class Initialized
INFO - 2018-05-08 09:47:39 --> URI Class Initialized
INFO - 2018-05-08 09:47:39 --> Router Class Initialized
INFO - 2018-05-08 09:47:39 --> Output Class Initialized
INFO - 2018-05-08 09:47:39 --> Security Class Initialized
DEBUG - 2018-05-08 09:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 09:47:39 --> Input Class Initialized
INFO - 2018-05-08 09:47:39 --> Language Class Initialized
INFO - 2018-05-08 09:47:39 --> Language Class Initialized
INFO - 2018-05-08 09:47:39 --> Config Class Initialized
INFO - 2018-05-08 09:47:39 --> Loader Class Initialized
INFO - 2018-05-08 15:17:39 --> Helper loaded: url_helper
INFO - 2018-05-08 15:17:39 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:17:39 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:17:39 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:17:39 --> Helper loaded: users_helper
INFO - 2018-05-08 15:17:39 --> Database Driver Class Initialized
DEBUG - 2018-05-08 15:17:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:17:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:17:39 --> Helper loaded: form_helper
INFO - 2018-05-08 15:17:39 --> Form Validation Class Initialized
INFO - 2018-05-08 15:17:39 --> Controller Class Initialized
INFO - 2018-05-08 15:17:39 --> Model Class Initialized
INFO - 2018-05-08 15:17:39 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 15:17:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:17:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:17:39 --> Model Class Initialized
INFO - 2018-05-08 15:17:39 --> Model Class Initialized
INFO - 2018-05-08 15:17:39 --> Model Class Initialized
INFO - 2018-05-08 15:17:39 --> Model Class Initialized
INFO - 2018-05-08 15:17:39 --> Model Class Initialized
INFO - 2018-05-08 15:17:39 --> Model Class Initialized
INFO - 2018-05-08 15:17:39 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-05-08 15:17:39 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 800
ERROR - 2018-05-08 15:17:39 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 810
INFO - 2018-05-08 15:17:39 --> Final output sent to browser
DEBUG - 2018-05-08 15:17:39 --> Total execution time: 0.1233
INFO - 2018-05-08 09:47:41 --> Config Class Initialized
INFO - 2018-05-08 09:47:41 --> Hooks Class Initialized
DEBUG - 2018-05-08 09:47:41 --> UTF-8 Support Enabled
INFO - 2018-05-08 09:47:41 --> Utf8 Class Initialized
INFO - 2018-05-08 09:47:41 --> URI Class Initialized
INFO - 2018-05-08 09:47:41 --> Router Class Initialized
INFO - 2018-05-08 09:47:41 --> Output Class Initialized
INFO - 2018-05-08 09:47:41 --> Security Class Initialized
DEBUG - 2018-05-08 09:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 09:47:41 --> Input Class Initialized
INFO - 2018-05-08 09:47:41 --> Language Class Initialized
INFO - 2018-05-08 09:47:41 --> Config Class Initialized
INFO - 2018-05-08 09:47:41 --> Hooks Class Initialized
DEBUG - 2018-05-08 09:47:41 --> UTF-8 Support Enabled
INFO - 2018-05-08 09:47:41 --> Utf8 Class Initialized
INFO - 2018-05-08 09:47:41 --> URI Class Initialized
INFO - 2018-05-08 09:47:41 --> Language Class Initialized
INFO - 2018-05-08 09:47:41 --> Config Class Initialized
INFO - 2018-05-08 09:47:41 --> Loader Class Initialized
INFO - 2018-05-08 15:17:41 --> Helper loaded: url_helper
INFO - 2018-05-08 09:47:41 --> Router Class Initialized
INFO - 2018-05-08 15:17:41 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:17:41 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:17:41 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:17:41 --> Helper loaded: users_helper
INFO - 2018-05-08 09:47:41 --> Output Class Initialized
INFO - 2018-05-08 09:47:41 --> Security Class Initialized
DEBUG - 2018-05-08 09:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 09:47:41 --> Input Class Initialized
INFO - 2018-05-08 09:47:41 --> Language Class Initialized
INFO - 2018-05-08 15:17:41 --> Database Driver Class Initialized
INFO - 2018-05-08 09:47:41 --> Language Class Initialized
INFO - 2018-05-08 09:47:41 --> Config Class Initialized
INFO - 2018-05-08 09:47:41 --> Loader Class Initialized
INFO - 2018-05-08 15:17:41 --> Helper loaded: url_helper
INFO - 2018-05-08 15:17:41 --> Helper loaded: notification_helper
DEBUG - 2018-05-08 15:17:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:17:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:17:41 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:17:41 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:17:41 --> Helper loaded: users_helper
INFO - 2018-05-08 15:17:41 --> Database Driver Class Initialized
INFO - 2018-05-08 15:17:41 --> Helper loaded: form_helper
INFO - 2018-05-08 15:17:41 --> Form Validation Class Initialized
INFO - 2018-05-08 15:17:41 --> Controller Class Initialized
DEBUG - 2018-05-08 15:17:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:17:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:17:41 --> Helper loaded: form_helper
INFO - 2018-05-08 15:17:41 --> Form Validation Class Initialized
INFO - 2018-05-08 15:17:41 --> Controller Class Initialized
INFO - 2018-05-08 15:17:41 --> Model Class Initialized
INFO - 2018-05-08 15:17:41 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 15:17:41 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:17:41 --> Model Class Initialized
INFO - 2018-05-08 15:17:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:17:41 --> Helper loaded: inflector_helper
INFO - 2018-05-08 15:17:41 --> Model Class Initialized
INFO - 2018-05-08 15:17:41 --> Model Class Initialized
INFO - 2018-05-08 15:17:41 --> Model Class Initialized
INFO - 2018-05-08 15:17:41 --> Model Class Initialized
DEBUG - 2018-05-08 15:17:41 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:17:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:17:41 --> Model Class Initialized
INFO - 2018-05-08 15:17:41 --> Model Class Initialized
INFO - 2018-05-08 15:17:41 --> Final output sent to browser
DEBUG - 2018-05-08 15:17:41 --> Total execution time: 0.1228
INFO - 2018-05-08 15:17:41 --> Model Class Initialized
INFO - 2018-05-08 15:17:41 --> Model Class Initialized
INFO - 2018-05-08 15:17:41 --> Final output sent to browser
DEBUG - 2018-05-08 15:17:41 --> Total execution time: 0.1073
INFO - 2018-05-08 09:47:42 --> Config Class Initialized
INFO - 2018-05-08 09:47:42 --> Hooks Class Initialized
DEBUG - 2018-05-08 09:47:42 --> UTF-8 Support Enabled
INFO - 2018-05-08 09:47:42 --> Utf8 Class Initialized
INFO - 2018-05-08 09:47:42 --> URI Class Initialized
INFO - 2018-05-08 09:47:42 --> Router Class Initialized
INFO - 2018-05-08 09:47:42 --> Output Class Initialized
INFO - 2018-05-08 09:47:42 --> Security Class Initialized
DEBUG - 2018-05-08 09:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 09:47:42 --> Input Class Initialized
INFO - 2018-05-08 09:47:42 --> Language Class Initialized
INFO - 2018-05-08 09:47:42 --> Language Class Initialized
INFO - 2018-05-08 09:47:42 --> Config Class Initialized
INFO - 2018-05-08 09:47:42 --> Loader Class Initialized
INFO - 2018-05-08 15:17:42 --> Helper loaded: url_helper
INFO - 2018-05-08 15:17:42 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:17:42 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:17:42 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:17:42 --> Helper loaded: users_helper
INFO - 2018-05-08 15:17:42 --> Database Driver Class Initialized
DEBUG - 2018-05-08 15:17:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:17:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:17:42 --> Helper loaded: form_helper
INFO - 2018-05-08 15:17:42 --> Form Validation Class Initialized
INFO - 2018-05-08 15:17:42 --> Controller Class Initialized
INFO - 2018-05-08 15:17:42 --> Model Class Initialized
INFO - 2018-05-08 15:17:42 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 15:17:42 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:17:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:17:42 --> Model Class Initialized
INFO - 2018-05-08 15:17:42 --> Model Class Initialized
INFO - 2018-05-08 15:17:42 --> Model Class Initialized
INFO - 2018-05-08 15:17:42 --> Model Class Initialized
INFO - 2018-05-08 15:17:42 --> Model Class Initialized
INFO - 2018-05-08 15:17:42 --> Model Class Initialized
INFO - 2018-05-08 15:17:42 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-05-08 15:17:42 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 800
ERROR - 2018-05-08 15:17:42 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 810
INFO - 2018-05-08 15:17:42 --> Final output sent to browser
DEBUG - 2018-05-08 15:17:42 --> Total execution time: 0.1155
INFO - 2018-05-08 09:47:44 --> Config Class Initialized
INFO - 2018-05-08 09:47:44 --> Hooks Class Initialized
DEBUG - 2018-05-08 09:47:44 --> UTF-8 Support Enabled
INFO - 2018-05-08 09:47:44 --> Utf8 Class Initialized
INFO - 2018-05-08 09:47:44 --> URI Class Initialized
INFO - 2018-05-08 09:47:44 --> Config Class Initialized
INFO - 2018-05-08 09:47:44 --> Hooks Class Initialized
INFO - 2018-05-08 09:47:44 --> Router Class Initialized
DEBUG - 2018-05-08 09:47:44 --> UTF-8 Support Enabled
INFO - 2018-05-08 09:47:44 --> Utf8 Class Initialized
INFO - 2018-05-08 09:47:45 --> URI Class Initialized
INFO - 2018-05-08 09:47:45 --> Output Class Initialized
INFO - 2018-05-08 09:47:45 --> Security Class Initialized
INFO - 2018-05-08 09:47:45 --> Router Class Initialized
DEBUG - 2018-05-08 09:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 09:47:45 --> Input Class Initialized
INFO - 2018-05-08 09:47:45 --> Language Class Initialized
INFO - 2018-05-08 09:47:45 --> Output Class Initialized
INFO - 2018-05-08 09:47:45 --> Security Class Initialized
DEBUG - 2018-05-08 09:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 09:47:45 --> Input Class Initialized
INFO - 2018-05-08 09:47:45 --> Language Class Initialized
INFO - 2018-05-08 09:47:45 --> Language Class Initialized
INFO - 2018-05-08 09:47:45 --> Config Class Initialized
INFO - 2018-05-08 09:47:45 --> Loader Class Initialized
INFO - 2018-05-08 15:17:45 --> Helper loaded: url_helper
INFO - 2018-05-08 15:17:45 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:17:45 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:17:45 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:17:45 --> Helper loaded: users_helper
INFO - 2018-05-08 09:47:45 --> Language Class Initialized
INFO - 2018-05-08 09:47:45 --> Config Class Initialized
INFO - 2018-05-08 09:47:45 --> Loader Class Initialized
INFO - 2018-05-08 15:17:45 --> Helper loaded: url_helper
INFO - 2018-05-08 15:17:45 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:17:45 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:17:45 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:17:45 --> Helper loaded: users_helper
INFO - 2018-05-08 15:17:45 --> Database Driver Class Initialized
DEBUG - 2018-05-08 15:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:17:45 --> Database Driver Class Initialized
DEBUG - 2018-05-08 15:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:17:45 --> Helper loaded: form_helper
INFO - 2018-05-08 15:17:45 --> Form Validation Class Initialized
INFO - 2018-05-08 15:17:45 --> Controller Class Initialized
INFO - 2018-05-08 15:17:45 --> Helper loaded: form_helper
INFO - 2018-05-08 15:17:45 --> Form Validation Class Initialized
INFO - 2018-05-08 15:17:45 --> Controller Class Initialized
INFO - 2018-05-08 15:17:45 --> Model Class Initialized
INFO - 2018-05-08 15:17:45 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 15:17:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:17:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:17:45 --> Model Class Initialized
INFO - 2018-05-08 15:17:45 --> Model Class Initialized
INFO - 2018-05-08 15:17:45 --> Model Class Initialized
INFO - 2018-05-08 15:17:45 --> Helper loaded: inflector_helper
INFO - 2018-05-08 15:17:45 --> Model Class Initialized
INFO - 2018-05-08 15:17:45 --> Model Class Initialized
DEBUG - 2018-05-08 15:17:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:17:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:17:45 --> Final output sent to browser
DEBUG - 2018-05-08 15:17:45 --> Total execution time: 0.0987
INFO - 2018-05-08 15:17:45 --> Model Class Initialized
INFO - 2018-05-08 15:17:45 --> Model Class Initialized
INFO - 2018-05-08 15:17:45 --> Model Class Initialized
INFO - 2018-05-08 15:17:45 --> Model Class Initialized
INFO - 2018-05-08 15:17:45 --> Final output sent to browser
DEBUG - 2018-05-08 15:17:45 --> Total execution time: 0.1001
INFO - 2018-05-08 09:47:47 --> Config Class Initialized
INFO - 2018-05-08 09:47:47 --> Hooks Class Initialized
DEBUG - 2018-05-08 09:47:47 --> UTF-8 Support Enabled
INFO - 2018-05-08 09:47:47 --> Utf8 Class Initialized
INFO - 2018-05-08 09:47:47 --> URI Class Initialized
INFO - 2018-05-08 09:47:47 --> Config Class Initialized
INFO - 2018-05-08 09:47:47 --> Hooks Class Initialized
INFO - 2018-05-08 09:47:47 --> Router Class Initialized
DEBUG - 2018-05-08 09:47:47 --> UTF-8 Support Enabled
INFO - 2018-05-08 09:47:47 --> Utf8 Class Initialized
INFO - 2018-05-08 09:47:47 --> Output Class Initialized
INFO - 2018-05-08 09:47:47 --> URI Class Initialized
INFO - 2018-05-08 09:47:47 --> Security Class Initialized
INFO - 2018-05-08 09:47:47 --> Router Class Initialized
DEBUG - 2018-05-08 09:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 09:47:47 --> Input Class Initialized
INFO - 2018-05-08 09:47:47 --> Language Class Initialized
INFO - 2018-05-08 09:47:47 --> Output Class Initialized
INFO - 2018-05-08 09:47:47 --> Security Class Initialized
INFO - 2018-05-08 09:47:47 --> Config Class Initialized
INFO - 2018-05-08 09:47:47 --> Hooks Class Initialized
DEBUG - 2018-05-08 09:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 09:47:47 --> Input Class Initialized
INFO - 2018-05-08 09:47:47 --> Language Class Initialized
DEBUG - 2018-05-08 09:47:47 --> UTF-8 Support Enabled
INFO - 2018-05-08 09:47:47 --> Utf8 Class Initialized
INFO - 2018-05-08 09:47:47 --> URI Class Initialized
INFO - 2018-05-08 09:47:47 --> Router Class Initialized
INFO - 2018-05-08 09:47:47 --> Language Class Initialized
INFO - 2018-05-08 09:47:47 --> Config Class Initialized
INFO - 2018-05-08 09:47:47 --> Loader Class Initialized
INFO - 2018-05-08 15:17:47 --> Helper loaded: url_helper
INFO - 2018-05-08 09:47:47 --> Language Class Initialized
INFO - 2018-05-08 09:47:47 --> Config Class Initialized
INFO - 2018-05-08 09:47:47 --> Loader Class Initialized
INFO - 2018-05-08 15:17:47 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:17:47 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:17:47 --> Helper loaded: permission_helper
INFO - 2018-05-08 09:47:47 --> Output Class Initialized
INFO - 2018-05-08 15:17:47 --> Helper loaded: url_helper
INFO - 2018-05-08 15:17:47 --> Helper loaded: users_helper
INFO - 2018-05-08 15:17:47 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:17:47 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:17:47 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:17:47 --> Helper loaded: users_helper
INFO - 2018-05-08 09:47:47 --> Security Class Initialized
DEBUG - 2018-05-08 09:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 09:47:47 --> Input Class Initialized
INFO - 2018-05-08 09:47:47 --> Language Class Initialized
INFO - 2018-05-08 15:17:47 --> Database Driver Class Initialized
INFO - 2018-05-08 15:17:47 --> Database Driver Class Initialized
DEBUG - 2018-05-08 15:17:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:17:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-05-08 15:17:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:17:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:17:47 --> Helper loaded: form_helper
INFO - 2018-05-08 15:17:47 --> Form Validation Class Initialized
INFO - 2018-05-08 15:17:47 --> Controller Class Initialized
INFO - 2018-05-08 15:17:47 --> Helper loaded: form_helper
INFO - 2018-05-08 15:17:47 --> Form Validation Class Initialized
INFO - 2018-05-08 15:17:47 --> Controller Class Initialized
INFO - 2018-05-08 15:17:47 --> Model Class Initialized
INFO - 2018-05-08 15:17:47 --> Helper loaded: inflector_helper
INFO - 2018-05-08 15:17:47 --> Model Class Initialized
INFO - 2018-05-08 15:17:47 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 15:17:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 09:47:47 --> Language Class Initialized
INFO - 2018-05-08 09:47:47 --> Config Class Initialized
INFO - 2018-05-08 09:47:47 --> Loader Class Initialized
INFO - 2018-05-08 15:17:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:17:47 --> Model Class Initialized
DEBUG - 2018-05-08 15:17:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:17:47 --> Model Class Initialized
INFO - 2018-05-08 15:17:47 --> Model Class Initialized
INFO - 2018-05-08 15:17:47 --> Model Class Initialized
INFO - 2018-05-08 15:17:47 --> Helper loaded: url_helper
INFO - 2018-05-08 15:17:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:17:47 --> Model Class Initialized
INFO - 2018-05-08 15:17:47 --> Model Class Initialized
INFO - 2018-05-08 15:17:47 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 15:17:47 --> Model Class Initialized
INFO - 2018-05-08 15:17:47 --> Model Class Initialized
INFO - 2018-05-08 15:17:47 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:17:47 --> Model Class Initialized
INFO - 2018-05-08 15:17:47 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:17:47 --> Model Class Initialized
INFO - 2018-05-08 15:17:47 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 15:17:47 --> Final output sent to browser
DEBUG - 2018-05-08 15:17:47 --> Total execution time: 0.1026
INFO - 2018-05-08 15:17:47 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:17:47 --> Helper loaded: users_helper
INFO - 2018-05-08 15:17:47 --> Database Driver Class Initialized
INFO - 2018-05-08 15:17:47 --> Final output sent to browser
DEBUG - 2018-05-08 15:17:47 --> Total execution time: 0.1156
DEBUG - 2018-05-08 15:17:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:17:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:17:47 --> Helper loaded: form_helper
INFO - 2018-05-08 15:17:47 --> Form Validation Class Initialized
INFO - 2018-05-08 15:17:47 --> Controller Class Initialized
INFO - 2018-05-08 15:17:47 --> Model Class Initialized
INFO - 2018-05-08 15:17:47 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 15:17:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:17:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:17:47 --> Model Class Initialized
INFO - 2018-05-08 15:17:47 --> Model Class Initialized
INFO - 2018-05-08 15:17:47 --> Model Class Initialized
INFO - 2018-05-08 15:17:47 --> Model Class Initialized
INFO - 2018-05-08 15:17:47 --> Model Class Initialized
INFO - 2018-05-08 15:17:47 --> Model Class Initialized
INFO - 2018-05-08 15:17:47 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 15:17:47 --> Final output sent to browser
DEBUG - 2018-05-08 15:17:47 --> Total execution time: 0.1350
INFO - 2018-05-08 09:47:51 --> Config Class Initialized
INFO - 2018-05-08 09:47:51 --> Hooks Class Initialized
DEBUG - 2018-05-08 09:47:51 --> UTF-8 Support Enabled
INFO - 2018-05-08 09:47:51 --> Utf8 Class Initialized
INFO - 2018-05-08 09:47:51 --> URI Class Initialized
INFO - 2018-05-08 09:47:51 --> Router Class Initialized
INFO - 2018-05-08 09:47:51 --> Output Class Initialized
INFO - 2018-05-08 09:47:51 --> Security Class Initialized
DEBUG - 2018-05-08 09:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 09:47:51 --> Input Class Initialized
INFO - 2018-05-08 09:47:51 --> Config Class Initialized
INFO - 2018-05-08 09:47:51 --> Hooks Class Initialized
INFO - 2018-05-08 09:47:51 --> Language Class Initialized
DEBUG - 2018-05-08 09:47:51 --> UTF-8 Support Enabled
INFO - 2018-05-08 09:47:51 --> Utf8 Class Initialized
INFO - 2018-05-08 09:47:51 --> URI Class Initialized
INFO - 2018-05-08 09:47:51 --> Router Class Initialized
INFO - 2018-05-08 09:47:51 --> Output Class Initialized
INFO - 2018-05-08 09:47:51 --> Language Class Initialized
INFO - 2018-05-08 09:47:51 --> Config Class Initialized
INFO - 2018-05-08 09:47:51 --> Loader Class Initialized
INFO - 2018-05-08 09:47:51 --> Security Class Initialized
INFO - 2018-05-08 15:17:51 --> Helper loaded: url_helper
INFO - 2018-05-08 15:17:51 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:17:51 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:17:51 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:17:51 --> Helper loaded: users_helper
DEBUG - 2018-05-08 09:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 09:47:51 --> Input Class Initialized
INFO - 2018-05-08 09:47:51 --> Language Class Initialized
INFO - 2018-05-08 15:17:51 --> Database Driver Class Initialized
DEBUG - 2018-05-08 15:17:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 09:47:51 --> Language Class Initialized
INFO - 2018-05-08 09:47:51 --> Config Class Initialized
INFO - 2018-05-08 09:47:51 --> Loader Class Initialized
INFO - 2018-05-08 15:17:51 --> Helper loaded: form_helper
INFO - 2018-05-08 15:17:51 --> Form Validation Class Initialized
INFO - 2018-05-08 15:17:51 --> Controller Class Initialized
INFO - 2018-05-08 15:17:51 --> Helper loaded: url_helper
INFO - 2018-05-08 15:17:51 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:17:51 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:17:51 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:17:51 --> Helper loaded: users_helper
INFO - 2018-05-08 15:17:51 --> Model Class Initialized
INFO - 2018-05-08 15:17:51 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 15:17:51 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:17:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:17:51 --> Model Class Initialized
INFO - 2018-05-08 15:17:51 --> Model Class Initialized
INFO - 2018-05-08 15:17:51 --> Model Class Initialized
INFO - 2018-05-08 15:17:51 --> Model Class Initialized
INFO - 2018-05-08 15:17:51 --> Model Class Initialized
INFO - 2018-05-08 15:17:51 --> Model Class Initialized
INFO - 2018-05-08 15:17:51 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 15:17:51 --> Final output sent to browser
DEBUG - 2018-05-08 15:17:51 --> Total execution time: 0.1049
INFO - 2018-05-08 15:17:51 --> Database Driver Class Initialized
DEBUG - 2018-05-08 15:17:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:17:51 --> Helper loaded: form_helper
INFO - 2018-05-08 15:17:51 --> Form Validation Class Initialized
INFO - 2018-05-08 15:17:51 --> Controller Class Initialized
INFO - 2018-05-08 15:17:51 --> Model Class Initialized
INFO - 2018-05-08 15:17:51 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 15:17:51 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:17:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:17:51 --> Model Class Initialized
INFO - 2018-05-08 15:17:51 --> Model Class Initialized
INFO - 2018-05-08 15:17:51 --> Model Class Initialized
INFO - 2018-05-08 15:17:51 --> Model Class Initialized
INFO - 2018-05-08 15:17:51 --> Model Class Initialized
INFO - 2018-05-08 15:17:51 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 15:17:51 --> Model Class Initialized
INFO - 2018-05-08 15:17:51 --> Final output sent to browser
DEBUG - 2018-05-08 15:17:51 --> Total execution time: 0.1362
INFO - 2018-05-08 09:48:12 --> Config Class Initialized
INFO - 2018-05-08 09:48:12 --> Hooks Class Initialized
DEBUG - 2018-05-08 09:48:12 --> UTF-8 Support Enabled
INFO - 2018-05-08 09:48:12 --> Utf8 Class Initialized
INFO - 2018-05-08 09:48:12 --> URI Class Initialized
INFO - 2018-05-08 09:48:12 --> Router Class Initialized
INFO - 2018-05-08 09:48:12 --> Output Class Initialized
INFO - 2018-05-08 09:48:12 --> Security Class Initialized
DEBUG - 2018-05-08 09:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 09:48:12 --> Input Class Initialized
INFO - 2018-05-08 09:48:12 --> Language Class Initialized
INFO - 2018-05-08 09:48:12 --> Language Class Initialized
INFO - 2018-05-08 09:48:12 --> Config Class Initialized
INFO - 2018-05-08 09:48:12 --> Loader Class Initialized
INFO - 2018-05-08 15:18:12 --> Helper loaded: url_helper
INFO - 2018-05-08 15:18:12 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:18:12 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:18:12 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:18:12 --> Helper loaded: users_helper
INFO - 2018-05-08 15:18:12 --> Database Driver Class Initialized
DEBUG - 2018-05-08 15:18:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 09:48:12 --> Config Class Initialized
INFO - 2018-05-08 09:48:12 --> Hooks Class Initialized
DEBUG - 2018-05-08 09:48:12 --> UTF-8 Support Enabled
INFO - 2018-05-08 09:48:12 --> Utf8 Class Initialized
INFO - 2018-05-08 09:48:12 --> URI Class Initialized
INFO - 2018-05-08 15:18:12 --> Helper loaded: form_helper
INFO - 2018-05-08 15:18:12 --> Form Validation Class Initialized
INFO - 2018-05-08 15:18:12 --> Controller Class Initialized
INFO - 2018-05-08 09:48:12 --> Config Class Initialized
INFO - 2018-05-08 09:48:12 --> Hooks Class Initialized
DEBUG - 2018-05-08 09:48:12 --> UTF-8 Support Enabled
INFO - 2018-05-08 09:48:12 --> Utf8 Class Initialized
INFO - 2018-05-08 09:48:12 --> Router Class Initialized
INFO - 2018-05-08 09:48:12 --> URI Class Initialized
INFO - 2018-05-08 09:48:12 --> Output Class Initialized
INFO - 2018-05-08 15:18:12 --> Model Class Initialized
INFO - 2018-05-08 09:48:12 --> Security Class Initialized
INFO - 2018-05-08 15:18:12 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 09:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 09:48:12 --> Input Class Initialized
INFO - 2018-05-08 09:48:12 --> Language Class Initialized
INFO - 2018-05-08 09:48:12 --> Router Class Initialized
DEBUG - 2018-05-08 15:18:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:18:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 09:48:12 --> Output Class Initialized
INFO - 2018-05-08 15:18:12 --> Model Class Initialized
INFO - 2018-05-08 15:18:12 --> Model Class Initialized
INFO - 2018-05-08 15:18:12 --> Model Class Initialized
INFO - 2018-05-08 09:48:12 --> Security Class Initialized
INFO - 2018-05-08 15:18:12 --> Model Class Initialized
INFO - 2018-05-08 15:18:12 --> Model Class Initialized
INFO - 2018-05-08 15:18:12 --> Model Class Initialized
INFO - 2018-05-08 15:18:12 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-05-08 09:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 09:48:12 --> Input Class Initialized
INFO - 2018-05-08 09:48:12 --> Language Class Initialized
INFO - 2018-05-08 15:18:12 --> Final output sent to browser
DEBUG - 2018-05-08 15:18:12 --> Total execution time: 0.1135
INFO - 2018-05-08 09:48:12 --> Language Class Initialized
INFO - 2018-05-08 09:48:12 --> Config Class Initialized
INFO - 2018-05-08 09:48:12 --> Loader Class Initialized
INFO - 2018-05-08 15:18:12 --> Helper loaded: url_helper
INFO - 2018-05-08 15:18:12 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:18:12 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:18:12 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:18:12 --> Helper loaded: users_helper
INFO - 2018-05-08 09:48:12 --> Language Class Initialized
INFO - 2018-05-08 09:48:12 --> Config Class Initialized
INFO - 2018-05-08 09:48:12 --> Loader Class Initialized
INFO - 2018-05-08 15:18:12 --> Helper loaded: url_helper
INFO - 2018-05-08 15:18:12 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:18:12 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:18:12 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:18:12 --> Helper loaded: users_helper
INFO - 2018-05-08 15:18:12 --> Database Driver Class Initialized
DEBUG - 2018-05-08 15:18:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:18:12 --> Helper loaded: form_helper
INFO - 2018-05-08 15:18:12 --> Form Validation Class Initialized
INFO - 2018-05-08 15:18:12 --> Controller Class Initialized
INFO - 2018-05-08 15:18:12 --> Database Driver Class Initialized
INFO - 2018-05-08 15:18:12 --> Model Class Initialized
INFO - 2018-05-08 15:18:12 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 15:18:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:18:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:18:12 --> Model Class Initialized
INFO - 2018-05-08 15:18:12 --> Model Class Initialized
INFO - 2018-05-08 15:18:12 --> Model Class Initialized
INFO - 2018-05-08 15:18:12 --> Model Class Initialized
INFO - 2018-05-08 15:18:12 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-05-08 15:18:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:18:12 --> Final output sent to browser
DEBUG - 2018-05-08 15:18:12 --> Total execution time: 0.1189
INFO - 2018-05-08 15:18:12 --> Helper loaded: form_helper
INFO - 2018-05-08 15:18:12 --> Form Validation Class Initialized
INFO - 2018-05-08 15:18:12 --> Controller Class Initialized
INFO - 2018-05-08 15:18:12 --> Model Class Initialized
INFO - 2018-05-08 15:18:12 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 15:18:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:18:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:18:12 --> Model Class Initialized
INFO - 2018-05-08 15:18:12 --> Model Class Initialized
INFO - 2018-05-08 15:18:12 --> Model Class Initialized
INFO - 2018-05-08 15:18:12 --> Model Class Initialized
INFO - 2018-05-08 15:18:12 --> Model Class Initialized
INFO - 2018-05-08 15:18:12 --> Model Class Initialized
INFO - 2018-05-08 15:18:12 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 15:18:12 --> Final output sent to browser
DEBUG - 2018-05-08 15:18:12 --> Total execution time: 0.1734
INFO - 2018-05-08 09:48:13 --> Config Class Initialized
INFO - 2018-05-08 09:48:13 --> Hooks Class Initialized
DEBUG - 2018-05-08 09:48:13 --> UTF-8 Support Enabled
INFO - 2018-05-08 09:48:13 --> Utf8 Class Initialized
INFO - 2018-05-08 09:48:13 --> URI Class Initialized
INFO - 2018-05-08 09:48:13 --> Router Class Initialized
INFO - 2018-05-08 09:48:13 --> Output Class Initialized
INFO - 2018-05-08 09:48:13 --> Security Class Initialized
DEBUG - 2018-05-08 09:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 09:48:13 --> Input Class Initialized
INFO - 2018-05-08 09:48:13 --> Language Class Initialized
INFO - 2018-05-08 09:48:13 --> Language Class Initialized
INFO - 2018-05-08 09:48:13 --> Config Class Initialized
INFO - 2018-05-08 09:48:13 --> Loader Class Initialized
INFO - 2018-05-08 15:18:13 --> Helper loaded: url_helper
INFO - 2018-05-08 15:18:13 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:18:13 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:18:13 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:18:13 --> Helper loaded: users_helper
INFO - 2018-05-08 15:18:13 --> Database Driver Class Initialized
DEBUG - 2018-05-08 15:18:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:18:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:18:13 --> Helper loaded: form_helper
INFO - 2018-05-08 15:18:13 --> Form Validation Class Initialized
INFO - 2018-05-08 15:18:13 --> Controller Class Initialized
INFO - 2018-05-08 15:18:13 --> Model Class Initialized
INFO - 2018-05-08 15:18:13 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 15:18:13 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:18:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:18:13 --> Model Class Initialized
INFO - 2018-05-08 15:18:13 --> Model Class Initialized
INFO - 2018-05-08 15:18:13 --> Model Class Initialized
INFO - 2018-05-08 15:18:13 --> Model Class Initialized
INFO - 2018-05-08 15:18:13 --> Final output sent to browser
DEBUG - 2018-05-08 15:18:13 --> Total execution time: 0.1135
INFO - 2018-05-08 09:48:15 --> Config Class Initialized
INFO - 2018-05-08 09:48:15 --> Hooks Class Initialized
DEBUG - 2018-05-08 09:48:15 --> UTF-8 Support Enabled
INFO - 2018-05-08 09:48:15 --> Utf8 Class Initialized
INFO - 2018-05-08 09:48:15 --> URI Class Initialized
INFO - 2018-05-08 09:48:15 --> Router Class Initialized
INFO - 2018-05-08 09:48:15 --> Output Class Initialized
INFO - 2018-05-08 09:48:15 --> Security Class Initialized
DEBUG - 2018-05-08 09:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 09:48:15 --> Input Class Initialized
INFO - 2018-05-08 09:48:15 --> Language Class Initialized
INFO - 2018-05-08 09:48:15 --> Language Class Initialized
INFO - 2018-05-08 09:48:15 --> Config Class Initialized
INFO - 2018-05-08 09:48:15 --> Loader Class Initialized
INFO - 2018-05-08 15:18:15 --> Helper loaded: url_helper
INFO - 2018-05-08 15:18:15 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:18:15 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:18:15 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:18:15 --> Helper loaded: users_helper
INFO - 2018-05-08 15:18:15 --> Database Driver Class Initialized
DEBUG - 2018-05-08 15:18:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:18:15 --> Helper loaded: form_helper
INFO - 2018-05-08 15:18:15 --> Form Validation Class Initialized
INFO - 2018-05-08 15:18:15 --> Controller Class Initialized
INFO - 2018-05-08 15:18:15 --> Model Class Initialized
INFO - 2018-05-08 15:18:15 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 15:18:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:18:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:18:15 --> Model Class Initialized
INFO - 2018-05-08 15:18:15 --> Model Class Initialized
INFO - 2018-05-08 15:18:15 --> Final output sent to browser
DEBUG - 2018-05-08 15:18:15 --> Total execution time: 0.0971
INFO - 2018-05-08 09:48:19 --> Config Class Initialized
INFO - 2018-05-08 09:48:19 --> Hooks Class Initialized
DEBUG - 2018-05-08 09:48:19 --> UTF-8 Support Enabled
INFO - 2018-05-08 09:48:19 --> Utf8 Class Initialized
INFO - 2018-05-08 09:48:19 --> URI Class Initialized
INFO - 2018-05-08 09:48:19 --> Router Class Initialized
INFO - 2018-05-08 09:48:19 --> Output Class Initialized
INFO - 2018-05-08 09:48:19 --> Security Class Initialized
DEBUG - 2018-05-08 09:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 09:48:19 --> Input Class Initialized
INFO - 2018-05-08 09:48:19 --> Language Class Initialized
INFO - 2018-05-08 09:48:19 --> Language Class Initialized
INFO - 2018-05-08 09:48:19 --> Config Class Initialized
INFO - 2018-05-08 09:48:19 --> Loader Class Initialized
INFO - 2018-05-08 15:18:19 --> Helper loaded: url_helper
INFO - 2018-05-08 15:18:19 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:18:19 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:18:19 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:18:19 --> Helper loaded: users_helper
INFO - 2018-05-08 15:18:19 --> Database Driver Class Initialized
DEBUG - 2018-05-08 15:18:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:18:19 --> Helper loaded: form_helper
INFO - 2018-05-08 15:18:19 --> Form Validation Class Initialized
INFO - 2018-05-08 15:18:19 --> Controller Class Initialized
INFO - 2018-05-08 15:18:19 --> Model Class Initialized
INFO - 2018-05-08 15:18:19 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 15:18:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:18:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:18:19 --> Model Class Initialized
INFO - 2018-05-08 15:18:19 --> Model Class Initialized
INFO - 2018-05-08 15:18:19 --> Model Class Initialized
INFO - 2018-05-08 15:18:19 --> Model Class Initialized
INFO - 2018-05-08 15:18:19 --> Model Class Initialized
INFO - 2018-05-08 15:18:19 --> Model Class Initialized
INFO - 2018-05-08 15:18:19 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-05-08 15:18:19 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 800
ERROR - 2018-05-08 15:18:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 810
INFO - 2018-05-08 15:18:19 --> Final output sent to browser
DEBUG - 2018-05-08 15:18:19 --> Total execution time: 0.1216
INFO - 2018-05-08 09:48:26 --> Config Class Initialized
INFO - 2018-05-08 09:48:26 --> Hooks Class Initialized
DEBUG - 2018-05-08 09:48:26 --> UTF-8 Support Enabled
INFO - 2018-05-08 09:48:26 --> Utf8 Class Initialized
INFO - 2018-05-08 09:48:26 --> URI Class Initialized
INFO - 2018-05-08 09:48:26 --> Router Class Initialized
INFO - 2018-05-08 09:48:26 --> Output Class Initialized
INFO - 2018-05-08 09:48:26 --> Security Class Initialized
DEBUG - 2018-05-08 09:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 09:48:26 --> Input Class Initialized
INFO - 2018-05-08 09:48:26 --> Language Class Initialized
INFO - 2018-05-08 09:48:26 --> Config Class Initialized
INFO - 2018-05-08 09:48:26 --> Hooks Class Initialized
DEBUG - 2018-05-08 09:48:26 --> UTF-8 Support Enabled
INFO - 2018-05-08 09:48:26 --> Utf8 Class Initialized
INFO - 2018-05-08 09:48:26 --> URI Class Initialized
INFO - 2018-05-08 09:48:26 --> Router Class Initialized
INFO - 2018-05-08 09:48:26 --> Language Class Initialized
INFO - 2018-05-08 09:48:26 --> Config Class Initialized
INFO - 2018-05-08 09:48:26 --> Loader Class Initialized
INFO - 2018-05-08 09:48:26 --> Output Class Initialized
INFO - 2018-05-08 09:48:26 --> Security Class Initialized
INFO - 2018-05-08 15:18:26 --> Helper loaded: url_helper
INFO - 2018-05-08 15:18:26 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:18:26 --> Helper loaded: settings_helper
DEBUG - 2018-05-08 09:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 09:48:26 --> Input Class Initialized
INFO - 2018-05-08 15:18:26 --> Helper loaded: permission_helper
INFO - 2018-05-08 09:48:26 --> Language Class Initialized
INFO - 2018-05-08 15:18:26 --> Helper loaded: users_helper
INFO - 2018-05-08 09:48:26 --> Language Class Initialized
INFO - 2018-05-08 09:48:26 --> Config Class Initialized
INFO - 2018-05-08 09:48:26 --> Loader Class Initialized
INFO - 2018-05-08 15:18:26 --> Database Driver Class Initialized
INFO - 2018-05-08 15:18:26 --> Helper loaded: url_helper
INFO - 2018-05-08 15:18:26 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:18:26 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:18:26 --> Helper loaded: permission_helper
DEBUG - 2018-05-08 15:18:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:18:26 --> Helper loaded: users_helper
INFO - 2018-05-08 15:18:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:18:26 --> Helper loaded: form_helper
INFO - 2018-05-08 15:18:26 --> Form Validation Class Initialized
INFO - 2018-05-08 15:18:26 --> Controller Class Initialized
INFO - 2018-05-08 15:18:26 --> Database Driver Class Initialized
INFO - 2018-05-08 15:18:26 --> Model Class Initialized
INFO - 2018-05-08 15:18:26 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 15:18:26 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:18:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:18:26 --> Model Class Initialized
INFO - 2018-05-08 15:18:26 --> Model Class Initialized
DEBUG - 2018-05-08 15:18:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:18:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:18:26 --> Model Class Initialized
INFO - 2018-05-08 15:18:26 --> Model Class Initialized
INFO - 2018-05-08 15:18:26 --> Model Class Initialized
INFO - 2018-05-08 15:18:26 --> Model Class Initialized
INFO - 2018-05-08 15:18:26 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 15:18:26 --> Final output sent to browser
DEBUG - 2018-05-08 15:18:26 --> Total execution time: 0.1086
INFO - 2018-05-08 09:48:26 --> Config Class Initialized
INFO - 2018-05-08 09:48:26 --> Hooks Class Initialized
INFO - 2018-05-08 15:18:26 --> Helper loaded: form_helper
INFO - 2018-05-08 15:18:26 --> Form Validation Class Initialized
INFO - 2018-05-08 15:18:26 --> Controller Class Initialized
DEBUG - 2018-05-08 09:48:26 --> UTF-8 Support Enabled
INFO - 2018-05-08 09:48:26 --> Utf8 Class Initialized
INFO - 2018-05-08 09:48:26 --> URI Class Initialized
INFO - 2018-05-08 15:18:26 --> Model Class Initialized
INFO - 2018-05-08 09:48:26 --> Router Class Initialized
INFO - 2018-05-08 15:18:26 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 15:18:26 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 09:48:26 --> Output Class Initialized
INFO - 2018-05-08 15:18:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:18:26 --> Model Class Initialized
INFO - 2018-05-08 15:18:26 --> Model Class Initialized
INFO - 2018-05-08 09:48:26 --> Security Class Initialized
INFO - 2018-05-08 15:18:26 --> Model Class Initialized
INFO - 2018-05-08 15:18:26 --> Model Class Initialized
INFO - 2018-05-08 15:18:26 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-05-08 09:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 09:48:26 --> Input Class Initialized
INFO - 2018-05-08 15:18:26 --> Final output sent to browser
DEBUG - 2018-05-08 15:18:26 --> Total execution time: 0.1213
INFO - 2018-05-08 09:48:26 --> Language Class Initialized
INFO - 2018-05-08 09:48:26 --> Language Class Initialized
INFO - 2018-05-08 09:48:26 --> Config Class Initialized
INFO - 2018-05-08 09:48:26 --> Loader Class Initialized
INFO - 2018-05-08 15:18:26 --> Helper loaded: url_helper
INFO - 2018-05-08 15:18:26 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:18:26 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:18:26 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:18:26 --> Helper loaded: users_helper
INFO - 2018-05-08 15:18:26 --> Database Driver Class Initialized
DEBUG - 2018-05-08 15:18:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:18:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:18:26 --> Helper loaded: form_helper
INFO - 2018-05-08 15:18:26 --> Form Validation Class Initialized
INFO - 2018-05-08 15:18:26 --> Controller Class Initialized
INFO - 2018-05-08 15:18:26 --> Model Class Initialized
INFO - 2018-05-08 15:18:26 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 15:18:26 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:18:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:18:26 --> Model Class Initialized
INFO - 2018-05-08 15:18:26 --> Model Class Initialized
INFO - 2018-05-08 15:18:26 --> Model Class Initialized
INFO - 2018-05-08 15:18:26 --> Model Class Initialized
INFO - 2018-05-08 15:18:26 --> Model Class Initialized
INFO - 2018-05-08 15:18:26 --> Model Class Initialized
INFO - 2018-05-08 15:18:26 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 15:18:26 --> Final output sent to browser
DEBUG - 2018-05-08 15:18:26 --> Total execution time: 0.1591
INFO - 2018-05-08 09:48:27 --> Config Class Initialized
INFO - 2018-05-08 09:48:27 --> Hooks Class Initialized
DEBUG - 2018-05-08 09:48:27 --> UTF-8 Support Enabled
INFO - 2018-05-08 09:48:27 --> Utf8 Class Initialized
INFO - 2018-05-08 09:48:27 --> URI Class Initialized
INFO - 2018-05-08 09:48:27 --> Config Class Initialized
INFO - 2018-05-08 09:48:27 --> Hooks Class Initialized
DEBUG - 2018-05-08 09:48:27 --> UTF-8 Support Enabled
INFO - 2018-05-08 09:48:27 --> Utf8 Class Initialized
INFO - 2018-05-08 09:48:27 --> Router Class Initialized
INFO - 2018-05-08 09:48:27 --> URI Class Initialized
INFO - 2018-05-08 09:48:27 --> Output Class Initialized
INFO - 2018-05-08 09:48:27 --> Security Class Initialized
INFO - 2018-05-08 09:48:27 --> Router Class Initialized
DEBUG - 2018-05-08 09:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 09:48:27 --> Input Class Initialized
INFO - 2018-05-08 09:48:27 --> Output Class Initialized
INFO - 2018-05-08 09:48:27 --> Language Class Initialized
INFO - 2018-05-08 09:48:27 --> Security Class Initialized
DEBUG - 2018-05-08 09:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 09:48:27 --> Input Class Initialized
INFO - 2018-05-08 09:48:27 --> Language Class Initialized
INFO - 2018-05-08 09:48:27 --> Language Class Initialized
INFO - 2018-05-08 09:48:27 --> Config Class Initialized
INFO - 2018-05-08 09:48:27 --> Loader Class Initialized
INFO - 2018-05-08 15:18:27 --> Helper loaded: url_helper
INFO - 2018-05-08 15:18:27 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:18:27 --> Helper loaded: settings_helper
INFO - 2018-05-08 09:48:27 --> Language Class Initialized
INFO - 2018-05-08 09:48:27 --> Config Class Initialized
INFO - 2018-05-08 09:48:27 --> Loader Class Initialized
INFO - 2018-05-08 15:18:27 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:18:27 --> Helper loaded: users_helper
INFO - 2018-05-08 15:18:27 --> Helper loaded: url_helper
INFO - 2018-05-08 15:18:27 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:18:27 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:18:27 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:18:27 --> Helper loaded: users_helper
INFO - 2018-05-08 15:18:27 --> Database Driver Class Initialized
INFO - 2018-05-08 15:18:27 --> Database Driver Class Initialized
DEBUG - 2018-05-08 15:18:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:18:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-05-08 15:18:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:18:27 --> Helper loaded: form_helper
INFO - 2018-05-08 15:18:27 --> Form Validation Class Initialized
INFO - 2018-05-08 15:18:27 --> Controller Class Initialized
INFO - 2018-05-08 15:18:27 --> Helper loaded: form_helper
INFO - 2018-05-08 15:18:27 --> Form Validation Class Initialized
INFO - 2018-05-08 15:18:27 --> Controller Class Initialized
INFO - 2018-05-08 15:18:27 --> Model Class Initialized
INFO - 2018-05-08 15:18:27 --> Helper loaded: inflector_helper
INFO - 2018-05-08 15:18:27 --> Model Class Initialized
INFO - 2018-05-08 15:18:27 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 15:18:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:18:27 --> Language file loaded: language/english/rest_controller_lang.php
DEBUG - 2018-05-08 15:18:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:18:27 --> Model Class Initialized
INFO - 2018-05-08 15:18:27 --> Model Class Initialized
INFO - 2018-05-08 15:18:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:18:27 --> Model Class Initialized
INFO - 2018-05-08 15:18:27 --> Model Class Initialized
INFO - 2018-05-08 15:18:27 --> Model Class Initialized
INFO - 2018-05-08 15:18:27 --> Model Class Initialized
INFO - 2018-05-08 15:18:27 --> Model Class Initialized
INFO - 2018-05-08 15:18:27 --> Model Class Initialized
INFO - 2018-05-08 15:18:27 --> Model Class Initialized
INFO - 2018-05-08 15:18:27 --> Model Class Initialized
INFO - 2018-05-08 15:18:27 --> Model Class Initialized
INFO - 2018-05-08 15:18:27 --> Model Class Initialized
INFO - 2018-05-08 15:18:27 --> Model Class Initialized
INFO - 2018-05-08 15:18:27 --> Model Class Initialized
INFO - 2018-05-08 15:18:27 --> Model Class Initialized
INFO - 2018-05-08 15:18:27 --> Model Class Initialized
INFO - 2018-05-08 15:18:27 --> Model Class Initialized
INFO - 2018-05-08 15:18:27 --> Model Class Initialized
INFO - 2018-05-08 15:18:27 --> Model Class Initialized
INFO - 2018-05-08 15:18:27 --> Model Class Initialized
INFO - 2018-05-08 15:18:27 --> Model Class Initialized
INFO - 2018-05-08 15:18:27 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 15:18:27 --> Model Class Initialized
INFO - 2018-05-08 15:18:27 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 15:18:27 --> Model Class Initialized
INFO - 2018-05-08 15:18:27 --> Final output sent to browser
DEBUG - 2018-05-08 15:18:27 --> Total execution time: 0.1170
INFO - 2018-05-08 15:18:28 --> Final output sent to browser
DEBUG - 2018-05-08 15:18:28 --> Total execution time: 0.1134
INFO - 2018-05-08 09:48:30 --> Config Class Initialized
INFO - 2018-05-08 09:48:30 --> Hooks Class Initialized
DEBUG - 2018-05-08 09:48:30 --> UTF-8 Support Enabled
INFO - 2018-05-08 09:48:30 --> Utf8 Class Initialized
INFO - 2018-05-08 09:48:30 --> URI Class Initialized
INFO - 2018-05-08 09:48:30 --> Router Class Initialized
INFO - 2018-05-08 09:48:30 --> Output Class Initialized
INFO - 2018-05-08 09:48:30 --> Security Class Initialized
DEBUG - 2018-05-08 09:48:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 09:48:30 --> Input Class Initialized
INFO - 2018-05-08 09:48:30 --> Language Class Initialized
INFO - 2018-05-08 09:48:30 --> Config Class Initialized
INFO - 2018-05-08 09:48:30 --> Hooks Class Initialized
DEBUG - 2018-05-08 09:48:30 --> UTF-8 Support Enabled
INFO - 2018-05-08 09:48:30 --> Utf8 Class Initialized
INFO - 2018-05-08 09:48:30 --> URI Class Initialized
INFO - 2018-05-08 09:48:30 --> Router Class Initialized
INFO - 2018-05-08 09:48:30 --> Language Class Initialized
INFO - 2018-05-08 09:48:30 --> Config Class Initialized
INFO - 2018-05-08 09:48:30 --> Loader Class Initialized
INFO - 2018-05-08 15:18:30 --> Helper loaded: url_helper
INFO - 2018-05-08 09:48:30 --> Output Class Initialized
INFO - 2018-05-08 15:18:30 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:18:30 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:18:30 --> Helper loaded: permission_helper
INFO - 2018-05-08 09:48:30 --> Security Class Initialized
INFO - 2018-05-08 15:18:30 --> Helper loaded: users_helper
DEBUG - 2018-05-08 09:48:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 09:48:30 --> Input Class Initialized
INFO - 2018-05-08 09:48:30 --> Language Class Initialized
INFO - 2018-05-08 15:18:30 --> Database Driver Class Initialized
DEBUG - 2018-05-08 15:18:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:18:30 --> Helper loaded: form_helper
INFO - 2018-05-08 15:18:30 --> Form Validation Class Initialized
INFO - 2018-05-08 15:18:30 --> Controller Class Initialized
INFO - 2018-05-08 09:48:30 --> Language Class Initialized
INFO - 2018-05-08 09:48:30 --> Config Class Initialized
INFO - 2018-05-08 09:48:30 --> Loader Class Initialized
INFO - 2018-05-08 15:18:30 --> Helper loaded: url_helper
INFO - 2018-05-08 15:18:30 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:18:30 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:18:30 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:18:30 --> Helper loaded: users_helper
INFO - 2018-05-08 15:18:30 --> Model Class Initialized
INFO - 2018-05-08 15:18:30 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 15:18:30 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:18:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:18:30 --> Model Class Initialized
INFO - 2018-05-08 15:18:30 --> Model Class Initialized
INFO - 2018-05-08 15:18:30 --> Model Class Initialized
INFO - 2018-05-08 15:18:30 --> Model Class Initialized
INFO - 2018-05-08 15:18:30 --> Model Class Initialized
INFO - 2018-05-08 15:18:30 --> Model Class Initialized
INFO - 2018-05-08 15:18:30 --> Model Class Initialized
INFO - 2018-05-08 15:18:30 --> Model Class Initialized
INFO - 2018-05-08 15:18:30 --> Model Class Initialized
INFO - 2018-05-08 15:18:30 --> Model Class Initialized
INFO - 2018-05-08 15:18:30 --> Model Class Initialized
INFO - 2018-05-08 15:18:30 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 15:18:30 --> Model Class Initialized
INFO - 2018-05-08 15:18:30 --> Database Driver Class Initialized
DEBUG - 2018-05-08 15:18:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:18:30 --> Final output sent to browser
DEBUG - 2018-05-08 15:18:30 --> Total execution time: 0.1205
INFO - 2018-05-08 15:18:30 --> Helper loaded: form_helper
INFO - 2018-05-08 15:18:30 --> Form Validation Class Initialized
INFO - 2018-05-08 15:18:30 --> Controller Class Initialized
INFO - 2018-05-08 15:18:30 --> Model Class Initialized
INFO - 2018-05-08 15:18:30 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 15:18:30 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:18:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:18:30 --> Model Class Initialized
INFO - 2018-05-08 15:18:30 --> Model Class Initialized
INFO - 2018-05-08 15:18:30 --> Model Class Initialized
INFO - 2018-05-08 15:18:30 --> Model Class Initialized
INFO - 2018-05-08 15:18:30 --> Model Class Initialized
INFO - 2018-05-08 15:18:30 --> Model Class Initialized
INFO - 2018-05-08 15:18:30 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 15:18:30 --> Model Class Initialized
INFO - 2018-05-08 15:18:30 --> Final output sent to browser
DEBUG - 2018-05-08 15:18:30 --> Total execution time: 0.1359
INFO - 2018-05-08 09:48:31 --> Config Class Initialized
INFO - 2018-05-08 09:48:31 --> Hooks Class Initialized
INFO - 2018-05-08 09:48:31 --> Config Class Initialized
INFO - 2018-05-08 09:48:31 --> Hooks Class Initialized
DEBUG - 2018-05-08 09:48:31 --> UTF-8 Support Enabled
INFO - 2018-05-08 09:48:31 --> Utf8 Class Initialized
DEBUG - 2018-05-08 09:48:31 --> UTF-8 Support Enabled
INFO - 2018-05-08 09:48:31 --> Utf8 Class Initialized
INFO - 2018-05-08 09:48:31 --> URI Class Initialized
INFO - 2018-05-08 09:48:31 --> URI Class Initialized
INFO - 2018-05-08 09:48:31 --> Router Class Initialized
INFO - 2018-05-08 09:48:31 --> Router Class Initialized
INFO - 2018-05-08 09:48:31 --> Output Class Initialized
INFO - 2018-05-08 09:48:31 --> Output Class Initialized
INFO - 2018-05-08 09:48:31 --> Security Class Initialized
INFO - 2018-05-08 09:48:31 --> Security Class Initialized
DEBUG - 2018-05-08 09:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 09:48:31 --> Input Class Initialized
DEBUG - 2018-05-08 09:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 09:48:31 --> Input Class Initialized
INFO - 2018-05-08 09:48:31 --> Language Class Initialized
INFO - 2018-05-08 09:48:31 --> Language Class Initialized
INFO - 2018-05-08 09:48:31 --> Language Class Initialized
INFO - 2018-05-08 09:48:31 --> Config Class Initialized
INFO - 2018-05-08 09:48:31 --> Loader Class Initialized
INFO - 2018-05-08 15:18:31 --> Helper loaded: url_helper
INFO - 2018-05-08 09:48:31 --> Language Class Initialized
INFO - 2018-05-08 09:48:31 --> Config Class Initialized
INFO - 2018-05-08 09:48:31 --> Loader Class Initialized
INFO - 2018-05-08 15:18:31 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:18:31 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:18:31 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:18:31 --> Helper loaded: users_helper
INFO - 2018-05-08 15:18:31 --> Helper loaded: url_helper
INFO - 2018-05-08 15:18:31 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:18:31 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:18:31 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:18:31 --> Helper loaded: users_helper
INFO - 2018-05-08 15:18:31 --> Database Driver Class Initialized
DEBUG - 2018-05-08 15:18:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:18:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:18:31 --> Database Driver Class Initialized
DEBUG - 2018-05-08 15:18:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:18:31 --> Helper loaded: form_helper
INFO - 2018-05-08 15:18:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:18:31 --> Form Validation Class Initialized
INFO - 2018-05-08 15:18:31 --> Controller Class Initialized
INFO - 2018-05-08 15:18:31 --> Helper loaded: form_helper
INFO - 2018-05-08 15:18:31 --> Form Validation Class Initialized
INFO - 2018-05-08 15:18:31 --> Controller Class Initialized
INFO - 2018-05-08 15:18:31 --> Model Class Initialized
INFO - 2018-05-08 15:18:31 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 15:18:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:18:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:18:31 --> Model Class Initialized
INFO - 2018-05-08 15:18:31 --> Model Class Initialized
INFO - 2018-05-08 15:18:31 --> Model Class Initialized
INFO - 2018-05-08 15:18:31 --> Helper loaded: inflector_helper
INFO - 2018-05-08 15:18:31 --> Model Class Initialized
INFO - 2018-05-08 15:18:31 --> Model Class Initialized
DEBUG - 2018-05-08 15:18:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:18:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:18:31 --> Final output sent to browser
DEBUG - 2018-05-08 15:18:31 --> Total execution time: 0.1327
INFO - 2018-05-08 15:18:31 --> Model Class Initialized
INFO - 2018-05-08 15:18:31 --> Model Class Initialized
INFO - 2018-05-08 15:18:31 --> Model Class Initialized
INFO - 2018-05-08 15:18:31 --> Model Class Initialized
INFO - 2018-05-08 15:18:31 --> Final output sent to browser
DEBUG - 2018-05-08 15:18:31 --> Total execution time: 0.1395
INFO - 2018-05-08 09:48:34 --> Config Class Initialized
INFO - 2018-05-08 09:48:34 --> Hooks Class Initialized
DEBUG - 2018-05-08 09:48:34 --> UTF-8 Support Enabled
INFO - 2018-05-08 09:48:34 --> Utf8 Class Initialized
INFO - 2018-05-08 09:48:34 --> URI Class Initialized
INFO - 2018-05-08 09:48:34 --> Router Class Initialized
INFO - 2018-05-08 09:48:34 --> Output Class Initialized
INFO - 2018-05-08 09:48:34 --> Security Class Initialized
DEBUG - 2018-05-08 09:48:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 09:48:34 --> Input Class Initialized
INFO - 2018-05-08 09:48:34 --> Language Class Initialized
INFO - 2018-05-08 09:48:34 --> Language Class Initialized
INFO - 2018-05-08 09:48:34 --> Config Class Initialized
INFO - 2018-05-08 09:48:34 --> Loader Class Initialized
INFO - 2018-05-08 15:18:34 --> Helper loaded: url_helper
INFO - 2018-05-08 15:18:34 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:18:34 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:18:34 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:18:34 --> Helper loaded: users_helper
INFO - 2018-05-08 15:18:34 --> Database Driver Class Initialized
DEBUG - 2018-05-08 15:18:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:18:34 --> Helper loaded: form_helper
INFO - 2018-05-08 15:18:34 --> Form Validation Class Initialized
INFO - 2018-05-08 15:18:34 --> Controller Class Initialized
INFO - 2018-05-08 15:18:34 --> Model Class Initialized
INFO - 2018-05-08 15:18:34 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 15:18:34 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:18:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:18:34 --> Model Class Initialized
INFO - 2018-05-08 15:18:34 --> Model Class Initialized
INFO - 2018-05-08 15:18:34 --> Model Class Initialized
INFO - 2018-05-08 15:18:34 --> Model Class Initialized
INFO - 2018-05-08 15:18:34 --> Model Class Initialized
INFO - 2018-05-08 15:18:34 --> Model Class Initialized
INFO - 2018-05-08 15:18:34 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-05-08 15:18:34 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 800
ERROR - 2018-05-08 15:18:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 810
INFO - 2018-05-08 15:18:34 --> Final output sent to browser
DEBUG - 2018-05-08 15:18:34 --> Total execution time: 0.1094
INFO - 2018-05-08 09:48:41 --> Config Class Initialized
INFO - 2018-05-08 09:48:41 --> Hooks Class Initialized
DEBUG - 2018-05-08 09:48:41 --> UTF-8 Support Enabled
INFO - 2018-05-08 09:48:41 --> Utf8 Class Initialized
INFO - 2018-05-08 09:48:41 --> Config Class Initialized
INFO - 2018-05-08 09:48:41 --> Hooks Class Initialized
INFO - 2018-05-08 09:48:41 --> URI Class Initialized
DEBUG - 2018-05-08 09:48:41 --> UTF-8 Support Enabled
INFO - 2018-05-08 09:48:41 --> Utf8 Class Initialized
INFO - 2018-05-08 09:48:41 --> Router Class Initialized
INFO - 2018-05-08 09:48:41 --> URI Class Initialized
INFO - 2018-05-08 09:48:41 --> Output Class Initialized
INFO - 2018-05-08 09:48:41 --> Security Class Initialized
INFO - 2018-05-08 09:48:41 --> Router Class Initialized
DEBUG - 2018-05-08 09:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 09:48:41 --> Input Class Initialized
INFO - 2018-05-08 09:48:41 --> Language Class Initialized
INFO - 2018-05-08 09:48:41 --> Output Class Initialized
INFO - 2018-05-08 09:48:41 --> Security Class Initialized
DEBUG - 2018-05-08 09:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 09:48:41 --> Input Class Initialized
INFO - 2018-05-08 09:48:41 --> Language Class Initialized
INFO - 2018-05-08 09:48:41 --> Language Class Initialized
INFO - 2018-05-08 09:48:41 --> Config Class Initialized
INFO - 2018-05-08 09:48:41 --> Loader Class Initialized
INFO - 2018-05-08 15:18:41 --> Helper loaded: url_helper
INFO - 2018-05-08 15:18:41 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:18:41 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:18:41 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:18:41 --> Helper loaded: users_helper
INFO - 2018-05-08 09:48:41 --> Language Class Initialized
INFO - 2018-05-08 09:48:41 --> Config Class Initialized
INFO - 2018-05-08 09:48:41 --> Loader Class Initialized
INFO - 2018-05-08 15:18:41 --> Helper loaded: url_helper
INFO - 2018-05-08 15:18:41 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:18:41 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:18:41 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:18:41 --> Helper loaded: users_helper
INFO - 2018-05-08 15:18:41 --> Database Driver Class Initialized
DEBUG - 2018-05-08 15:18:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:18:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:18:41 --> Helper loaded: form_helper
INFO - 2018-05-08 15:18:41 --> Form Validation Class Initialized
INFO - 2018-05-08 15:18:41 --> Controller Class Initialized
INFO - 2018-05-08 15:18:41 --> Database Driver Class Initialized
INFO - 2018-05-08 15:18:41 --> Model Class Initialized
INFO - 2018-05-08 15:18:41 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 15:18:41 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:18:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:18:41 --> Model Class Initialized
INFO - 2018-05-08 15:18:41 --> Model Class Initialized
INFO - 2018-05-08 15:18:41 --> Model Class Initialized
INFO - 2018-05-08 15:18:41 --> Model Class Initialized
DEBUG - 2018-05-08 15:18:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:18:41 --> Final output sent to browser
DEBUG - 2018-05-08 15:18:41 --> Total execution time: 0.0995
INFO - 2018-05-08 15:18:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:18:41 --> Helper loaded: form_helper
INFO - 2018-05-08 15:18:41 --> Form Validation Class Initialized
INFO - 2018-05-08 15:18:41 --> Controller Class Initialized
INFO - 2018-05-08 15:18:41 --> Model Class Initialized
INFO - 2018-05-08 15:18:41 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 15:18:41 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:18:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:18:41 --> Model Class Initialized
INFO - 2018-05-08 15:18:41 --> Model Class Initialized
INFO - 2018-05-08 15:18:41 --> Model Class Initialized
INFO - 2018-05-08 15:18:41 --> Model Class Initialized
INFO - 2018-05-08 15:18:41 --> Final output sent to browser
DEBUG - 2018-05-08 15:18:41 --> Total execution time: 0.1316
INFO - 2018-05-08 09:48:43 --> Config Class Initialized
INFO - 2018-05-08 09:48:43 --> Hooks Class Initialized
DEBUG - 2018-05-08 09:48:43 --> UTF-8 Support Enabled
INFO - 2018-05-08 09:48:43 --> Utf8 Class Initialized
INFO - 2018-05-08 09:48:43 --> URI Class Initialized
INFO - 2018-05-08 09:48:43 --> Router Class Initialized
INFO - 2018-05-08 09:48:43 --> Config Class Initialized
INFO - 2018-05-08 09:48:43 --> Hooks Class Initialized
INFO - 2018-05-08 09:48:43 --> Output Class Initialized
DEBUG - 2018-05-08 09:48:43 --> UTF-8 Support Enabled
INFO - 2018-05-08 09:48:43 --> Utf8 Class Initialized
INFO - 2018-05-08 09:48:43 --> Security Class Initialized
INFO - 2018-05-08 09:48:43 --> URI Class Initialized
DEBUG - 2018-05-08 09:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 09:48:43 --> Input Class Initialized
INFO - 2018-05-08 09:48:43 --> Language Class Initialized
INFO - 2018-05-08 09:48:43 --> Router Class Initialized
INFO - 2018-05-08 09:48:43 --> Output Class Initialized
INFO - 2018-05-08 09:48:43 --> Security Class Initialized
DEBUG - 2018-05-08 09:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 09:48:43 --> Input Class Initialized
INFO - 2018-05-08 09:48:43 --> Language Class Initialized
INFO - 2018-05-08 09:48:43 --> Language Class Initialized
INFO - 2018-05-08 09:48:43 --> Config Class Initialized
INFO - 2018-05-08 09:48:43 --> Loader Class Initialized
INFO - 2018-05-08 15:18:43 --> Helper loaded: url_helper
INFO - 2018-05-08 15:18:43 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:18:43 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:18:43 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:18:43 --> Helper loaded: users_helper
INFO - 2018-05-08 09:48:43 --> Language Class Initialized
INFO - 2018-05-08 09:48:43 --> Config Class Initialized
INFO - 2018-05-08 09:48:43 --> Loader Class Initialized
INFO - 2018-05-08 15:18:43 --> Helper loaded: url_helper
INFO - 2018-05-08 15:18:43 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:18:43 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:18:43 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:18:43 --> Helper loaded: users_helper
INFO - 2018-05-08 15:18:43 --> Database Driver Class Initialized
DEBUG - 2018-05-08 15:18:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:18:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:18:43 --> Database Driver Class Initialized
INFO - 2018-05-08 15:18:43 --> Helper loaded: form_helper
INFO - 2018-05-08 15:18:43 --> Form Validation Class Initialized
INFO - 2018-05-08 15:18:43 --> Controller Class Initialized
DEBUG - 2018-05-08 15:18:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:18:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:18:43 --> Helper loaded: form_helper
INFO - 2018-05-08 15:18:43 --> Form Validation Class Initialized
INFO - 2018-05-08 15:18:43 --> Controller Class Initialized
INFO - 2018-05-08 15:18:43 --> Model Class Initialized
INFO - 2018-05-08 15:18:43 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 15:18:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:18:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:18:43 --> Model Class Initialized
INFO - 2018-05-08 15:18:43 --> Helper loaded: inflector_helper
INFO - 2018-05-08 15:18:43 --> Model Class Initialized
INFO - 2018-05-08 15:18:43 --> Model Class Initialized
INFO - 2018-05-08 15:18:43 --> Model Class Initialized
INFO - 2018-05-08 15:18:43 --> Model Class Initialized
INFO - 2018-05-08 15:18:43 --> Model Class Initialized
INFO - 2018-05-08 15:18:43 --> Model Class Initialized
INFO - 2018-05-08 15:18:43 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-05-08 15:18:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:18:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:18:43 --> Final output sent to browser
DEBUG - 2018-05-08 15:18:43 --> Total execution time: 0.1109
INFO - 2018-05-08 15:18:43 --> Model Class Initialized
INFO - 2018-05-08 15:18:43 --> Model Class Initialized
INFO - 2018-05-08 15:18:43 --> Model Class Initialized
INFO - 2018-05-08 15:18:43 --> Model Class Initialized
INFO - 2018-05-08 15:18:43 --> Model Class Initialized
INFO - 2018-05-08 15:18:43 --> Model Class Initialized
INFO - 2018-05-08 15:18:43 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 15:18:43 --> Final output sent to browser
DEBUG - 2018-05-08 15:18:43 --> Total execution time: 0.1047
INFO - 2018-05-08 09:48:43 --> Config Class Initialized
INFO - 2018-05-08 09:48:43 --> Hooks Class Initialized
DEBUG - 2018-05-08 09:48:43 --> UTF-8 Support Enabled
INFO - 2018-05-08 09:48:43 --> Utf8 Class Initialized
INFO - 2018-05-08 09:48:43 --> URI Class Initialized
INFO - 2018-05-08 09:48:43 --> Router Class Initialized
INFO - 2018-05-08 09:48:43 --> Output Class Initialized
INFO - 2018-05-08 09:48:43 --> Security Class Initialized
DEBUG - 2018-05-08 09:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 09:48:43 --> Input Class Initialized
INFO - 2018-05-08 09:48:43 --> Language Class Initialized
INFO - 2018-05-08 09:48:43 --> Language Class Initialized
INFO - 2018-05-08 09:48:43 --> Config Class Initialized
INFO - 2018-05-08 09:48:43 --> Loader Class Initialized
INFO - 2018-05-08 15:18:43 --> Helper loaded: url_helper
INFO - 2018-05-08 15:18:43 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:18:43 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:18:43 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:18:43 --> Helper loaded: users_helper
INFO - 2018-05-08 15:18:43 --> Database Driver Class Initialized
DEBUG - 2018-05-08 15:18:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:18:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:18:43 --> Helper loaded: form_helper
INFO - 2018-05-08 15:18:43 --> Form Validation Class Initialized
INFO - 2018-05-08 15:18:43 --> Controller Class Initialized
INFO - 2018-05-08 15:18:43 --> Model Class Initialized
INFO - 2018-05-08 15:18:43 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 15:18:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:18:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:18:43 --> Model Class Initialized
INFO - 2018-05-08 15:18:43 --> Model Class Initialized
INFO - 2018-05-08 15:18:43 --> Model Class Initialized
INFO - 2018-05-08 15:18:43 --> Model Class Initialized
INFO - 2018-05-08 15:18:43 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 15:18:43 --> Final output sent to browser
DEBUG - 2018-05-08 15:18:43 --> Total execution time: 0.1052
INFO - 2018-05-08 09:48:47 --> Config Class Initialized
INFO - 2018-05-08 09:48:47 --> Hooks Class Initialized
DEBUG - 2018-05-08 09:48:47 --> UTF-8 Support Enabled
INFO - 2018-05-08 09:48:47 --> Utf8 Class Initialized
INFO - 2018-05-08 09:48:47 --> URI Class Initialized
INFO - 2018-05-08 09:48:47 --> Router Class Initialized
INFO - 2018-05-08 09:48:47 --> Output Class Initialized
INFO - 2018-05-08 09:48:47 --> Security Class Initialized
DEBUG - 2018-05-08 09:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 09:48:47 --> Input Class Initialized
INFO - 2018-05-08 09:48:47 --> Language Class Initialized
INFO - 2018-05-08 09:48:47 --> Config Class Initialized
INFO - 2018-05-08 09:48:47 --> Hooks Class Initialized
DEBUG - 2018-05-08 09:48:47 --> UTF-8 Support Enabled
INFO - 2018-05-08 09:48:47 --> Utf8 Class Initialized
INFO - 2018-05-08 09:48:47 --> URI Class Initialized
INFO - 2018-05-08 09:48:47 --> Router Class Initialized
INFO - 2018-05-08 09:48:47 --> Language Class Initialized
INFO - 2018-05-08 09:48:47 --> Config Class Initialized
INFO - 2018-05-08 09:48:47 --> Loader Class Initialized
INFO - 2018-05-08 09:48:47 --> Output Class Initialized
INFO - 2018-05-08 15:18:47 --> Helper loaded: url_helper
INFO - 2018-05-08 15:18:47 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:18:47 --> Helper loaded: settings_helper
INFO - 2018-05-08 09:48:47 --> Security Class Initialized
INFO - 2018-05-08 15:18:47 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:18:47 --> Helper loaded: users_helper
DEBUG - 2018-05-08 09:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 09:48:47 --> Input Class Initialized
INFO - 2018-05-08 09:48:47 --> Language Class Initialized
INFO - 2018-05-08 15:18:47 --> Database Driver Class Initialized
INFO - 2018-05-08 09:48:47 --> Language Class Initialized
INFO - 2018-05-08 09:48:47 --> Config Class Initialized
INFO - 2018-05-08 09:48:47 --> Loader Class Initialized
DEBUG - 2018-05-08 15:18:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:18:47 --> Helper loaded: url_helper
INFO - 2018-05-08 15:18:47 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:18:47 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:18:47 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:18:47 --> Helper loaded: users_helper
INFO - 2018-05-08 15:18:47 --> Helper loaded: form_helper
INFO - 2018-05-08 15:18:47 --> Form Validation Class Initialized
INFO - 2018-05-08 15:18:47 --> Controller Class Initialized
INFO - 2018-05-08 15:18:47 --> Model Class Initialized
INFO - 2018-05-08 15:18:47 --> Helper loaded: inflector_helper
INFO - 2018-05-08 15:18:47 --> Database Driver Class Initialized
DEBUG - 2018-05-08 15:18:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:18:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:18:47 --> Model Class Initialized
INFO - 2018-05-08 15:18:47 --> Model Class Initialized
DEBUG - 2018-05-08 15:18:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:18:47 --> Model Class Initialized
INFO - 2018-05-08 15:18:47 --> Model Class Initialized
INFO - 2018-05-08 15:18:47 --> Final output sent to browser
DEBUG - 2018-05-08 15:18:47 --> Total execution time: 0.0987
INFO - 2018-05-08 15:18:47 --> Helper loaded: form_helper
INFO - 2018-05-08 15:18:47 --> Form Validation Class Initialized
INFO - 2018-05-08 15:18:47 --> Controller Class Initialized
INFO - 2018-05-08 15:18:47 --> Model Class Initialized
INFO - 2018-05-08 15:18:47 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 15:18:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:18:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:18:47 --> Model Class Initialized
INFO - 2018-05-08 15:18:47 --> Model Class Initialized
INFO - 2018-05-08 15:18:47 --> Model Class Initialized
INFO - 2018-05-08 15:18:47 --> Model Class Initialized
INFO - 2018-05-08 15:18:47 --> Final output sent to browser
DEBUG - 2018-05-08 15:18:47 --> Total execution time: 0.1056
INFO - 2018-05-08 09:48:50 --> Config Class Initialized
INFO - 2018-05-08 09:48:50 --> Hooks Class Initialized
DEBUG - 2018-05-08 09:48:50 --> UTF-8 Support Enabled
INFO - 2018-05-08 09:48:50 --> Utf8 Class Initialized
INFO - 2018-05-08 09:48:50 --> URI Class Initialized
INFO - 2018-05-08 09:48:50 --> Router Class Initialized
INFO - 2018-05-08 09:48:50 --> Output Class Initialized
INFO - 2018-05-08 09:48:50 --> Security Class Initialized
DEBUG - 2018-05-08 09:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 09:48:50 --> Input Class Initialized
INFO - 2018-05-08 09:48:50 --> Language Class Initialized
INFO - 2018-05-08 09:48:50 --> Config Class Initialized
INFO - 2018-05-08 09:48:50 --> Hooks Class Initialized
DEBUG - 2018-05-08 09:48:50 --> UTF-8 Support Enabled
INFO - 2018-05-08 09:48:50 --> Utf8 Class Initialized
INFO - 2018-05-08 09:48:50 --> URI Class Initialized
INFO - 2018-05-08 09:48:50 --> Router Class Initialized
INFO - 2018-05-08 09:48:50 --> Language Class Initialized
INFO - 2018-05-08 09:48:50 --> Config Class Initialized
INFO - 2018-05-08 09:48:50 --> Loader Class Initialized
INFO - 2018-05-08 09:48:50 --> Output Class Initialized
INFO - 2018-05-08 15:18:50 --> Helper loaded: url_helper
INFO - 2018-05-08 15:18:50 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:18:50 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:18:50 --> Helper loaded: permission_helper
INFO - 2018-05-08 09:48:50 --> Security Class Initialized
INFO - 2018-05-08 15:18:50 --> Helper loaded: users_helper
DEBUG - 2018-05-08 09:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 09:48:50 --> Input Class Initialized
INFO - 2018-05-08 09:48:50 --> Language Class Initialized
INFO - 2018-05-08 15:18:50 --> Database Driver Class Initialized
DEBUG - 2018-05-08 15:18:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:18:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 09:48:50 --> Language Class Initialized
INFO - 2018-05-08 09:48:50 --> Config Class Initialized
INFO - 2018-05-08 09:48:50 --> Loader Class Initialized
INFO - 2018-05-08 15:18:50 --> Helper loaded: url_helper
INFO - 2018-05-08 15:18:50 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:18:50 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:18:50 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:18:50 --> Helper loaded: form_helper
INFO - 2018-05-08 15:18:50 --> Form Validation Class Initialized
INFO - 2018-05-08 15:18:50 --> Controller Class Initialized
INFO - 2018-05-08 15:18:50 --> Helper loaded: users_helper
INFO - 2018-05-08 15:18:50 --> Model Class Initialized
INFO - 2018-05-08 15:18:50 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 15:18:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:18:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:18:50 --> Database Driver Class Initialized
INFO - 2018-05-08 15:18:50 --> Model Class Initialized
INFO - 2018-05-08 15:18:50 --> Model Class Initialized
INFO - 2018-05-08 15:18:50 --> Model Class Initialized
INFO - 2018-05-08 15:18:50 --> Model Class Initialized
INFO - 2018-05-08 15:18:50 --> Model Class Initialized
INFO - 2018-05-08 15:18:50 --> Model Class Initialized
INFO - 2018-05-08 15:18:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 15:18:50 --> Final output sent to browser
DEBUG - 2018-05-08 15:18:50 --> Total execution time: 0.1160
DEBUG - 2018-05-08 15:18:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:18:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:18:50 --> Helper loaded: form_helper
INFO - 2018-05-08 15:18:50 --> Form Validation Class Initialized
INFO - 2018-05-08 15:18:50 --> Controller Class Initialized
INFO - 2018-05-08 15:18:50 --> Model Class Initialized
INFO - 2018-05-08 15:18:50 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 15:18:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:18:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:18:50 --> Model Class Initialized
INFO - 2018-05-08 15:18:50 --> Model Class Initialized
INFO - 2018-05-08 15:18:50 --> Model Class Initialized
INFO - 2018-05-08 15:18:50 --> Model Class Initialized
INFO - 2018-05-08 15:18:50 --> Model Class Initialized
INFO - 2018-05-08 15:18:50 --> Model Class Initialized
INFO - 2018-05-08 15:18:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 15:18:50 --> Final output sent to browser
DEBUG - 2018-05-08 15:18:50 --> Total execution time: 0.1298
INFO - 2018-05-08 09:48:50 --> Config Class Initialized
INFO - 2018-05-08 09:48:50 --> Hooks Class Initialized
DEBUG - 2018-05-08 09:48:50 --> UTF-8 Support Enabled
INFO - 2018-05-08 09:48:50 --> Utf8 Class Initialized
INFO - 2018-05-08 09:48:50 --> URI Class Initialized
INFO - 2018-05-08 09:48:50 --> Router Class Initialized
INFO - 2018-05-08 09:48:50 --> Output Class Initialized
INFO - 2018-05-08 09:48:50 --> Security Class Initialized
DEBUG - 2018-05-08 09:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 09:48:50 --> Input Class Initialized
INFO - 2018-05-08 09:48:50 --> Language Class Initialized
INFO - 2018-05-08 09:48:50 --> Language Class Initialized
INFO - 2018-05-08 09:48:50 --> Config Class Initialized
INFO - 2018-05-08 09:48:50 --> Loader Class Initialized
INFO - 2018-05-08 15:18:50 --> Helper loaded: url_helper
INFO - 2018-05-08 15:18:50 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:18:50 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:18:50 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:18:50 --> Helper loaded: users_helper
INFO - 2018-05-08 15:18:50 --> Database Driver Class Initialized
DEBUG - 2018-05-08 15:18:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:18:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:18:50 --> Helper loaded: form_helper
INFO - 2018-05-08 15:18:50 --> Form Validation Class Initialized
INFO - 2018-05-08 15:18:50 --> Controller Class Initialized
INFO - 2018-05-08 15:18:50 --> Model Class Initialized
INFO - 2018-05-08 15:18:50 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 15:18:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:18:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:18:50 --> Model Class Initialized
INFO - 2018-05-08 15:18:50 --> Model Class Initialized
INFO - 2018-05-08 15:18:50 --> Model Class Initialized
INFO - 2018-05-08 15:18:50 --> Model Class Initialized
INFO - 2018-05-08 15:18:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 15:18:50 --> Final output sent to browser
DEBUG - 2018-05-08 15:18:50 --> Total execution time: 0.1086
INFO - 2018-05-08 10:23:03 --> Config Class Initialized
INFO - 2018-05-08 10:23:03 --> Hooks Class Initialized
INFO - 2018-05-08 10:23:03 --> Config Class Initialized
INFO - 2018-05-08 10:23:03 --> Hooks Class Initialized
DEBUG - 2018-05-08 10:23:03 --> UTF-8 Support Enabled
INFO - 2018-05-08 10:23:03 --> Utf8 Class Initialized
DEBUG - 2018-05-08 10:23:03 --> UTF-8 Support Enabled
INFO - 2018-05-08 10:23:03 --> Utf8 Class Initialized
INFO - 2018-05-08 10:23:03 --> URI Class Initialized
INFO - 2018-05-08 10:23:03 --> URI Class Initialized
INFO - 2018-05-08 10:23:03 --> Router Class Initialized
INFO - 2018-05-08 10:23:03 --> Output Class Initialized
INFO - 2018-05-08 10:23:03 --> Security Class Initialized
INFO - 2018-05-08 10:23:03 --> Router Class Initialized
INFO - 2018-05-08 10:23:03 --> Config Class Initialized
INFO - 2018-05-08 10:23:03 --> Hooks Class Initialized
DEBUG - 2018-05-08 10:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 10:23:03 --> Input Class Initialized
INFO - 2018-05-08 10:23:03 --> Language Class Initialized
INFO - 2018-05-08 10:23:03 --> Output Class Initialized
DEBUG - 2018-05-08 10:23:03 --> UTF-8 Support Enabled
INFO - 2018-05-08 10:23:03 --> Utf8 Class Initialized
INFO - 2018-05-08 10:23:03 --> Security Class Initialized
INFO - 2018-05-08 10:23:03 --> URI Class Initialized
DEBUG - 2018-05-08 10:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 10:23:03 --> Input Class Initialized
INFO - 2018-05-08 10:23:03 --> Language Class Initialized
INFO - 2018-05-08 10:23:03 --> Router Class Initialized
INFO - 2018-05-08 10:23:03 --> Output Class Initialized
INFO - 2018-05-08 10:23:03 --> Language Class Initialized
INFO - 2018-05-08 10:23:03 --> Config Class Initialized
INFO - 2018-05-08 10:23:03 --> Loader Class Initialized
INFO - 2018-05-08 10:23:03 --> Security Class Initialized
INFO - 2018-05-08 15:53:03 --> Helper loaded: url_helper
INFO - 2018-05-08 15:53:03 --> Helper loaded: notification_helper
DEBUG - 2018-05-08 10:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 10:23:03 --> Input Class Initialized
INFO - 2018-05-08 15:53:03 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:53:03 --> Helper loaded: permission_helper
INFO - 2018-05-08 10:23:03 --> Language Class Initialized
INFO - 2018-05-08 15:53:03 --> Helper loaded: users_helper
INFO - 2018-05-08 10:23:03 --> Config Class Initialized
INFO - 2018-05-08 10:23:03 --> Hooks Class Initialized
INFO - 2018-05-08 10:23:03 --> Language Class Initialized
INFO - 2018-05-08 10:23:03 --> Config Class Initialized
INFO - 2018-05-08 10:23:03 --> Loader Class Initialized
DEBUG - 2018-05-08 10:23:03 --> UTF-8 Support Enabled
INFO - 2018-05-08 10:23:03 --> Utf8 Class Initialized
INFO - 2018-05-08 15:53:03 --> Helper loaded: url_helper
INFO - 2018-05-08 15:53:03 --> Helper loaded: notification_helper
INFO - 2018-05-08 10:23:03 --> URI Class Initialized
INFO - 2018-05-08 15:53:03 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:53:03 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:53:03 --> Helper loaded: users_helper
INFO - 2018-05-08 15:53:03 --> Database Driver Class Initialized
INFO - 2018-05-08 10:23:03 --> Router Class Initialized
DEBUG - 2018-05-08 15:53:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:53:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 10:23:03 --> Output Class Initialized
INFO - 2018-05-08 10:23:03 --> Language Class Initialized
INFO - 2018-05-08 10:23:03 --> Config Class Initialized
INFO - 2018-05-08 10:23:03 --> Loader Class Initialized
INFO - 2018-05-08 15:53:03 --> Helper loaded: url_helper
INFO - 2018-05-08 15:53:03 --> Helper loaded: form_helper
INFO - 2018-05-08 15:53:03 --> Form Validation Class Initialized
INFO - 2018-05-08 15:53:03 --> Controller Class Initialized
INFO - 2018-05-08 15:53:03 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:53:03 --> Helper loaded: settings_helper
INFO - 2018-05-08 10:23:03 --> Security Class Initialized
INFO - 2018-05-08 15:53:03 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:53:03 --> Helper loaded: users_helper
INFO - 2018-05-08 15:53:03 --> Database Driver Class Initialized
INFO - 2018-05-08 10:23:03 --> Config Class Initialized
INFO - 2018-05-08 10:23:03 --> Hooks Class Initialized
DEBUG - 2018-05-08 10:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 10:23:03 --> Input Class Initialized
INFO - 2018-05-08 15:53:03 --> Model Class Initialized
INFO - 2018-05-08 10:23:03 --> Language Class Initialized
INFO - 2018-05-08 15:53:03 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 15:53:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:53:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:53:03 --> Model Class Initialized
INFO - 2018-05-08 15:53:03 --> Model Class Initialized
INFO - 2018-05-08 15:53:03 --> Model Class Initialized
INFO - 2018-05-08 15:53:03 --> Model Class Initialized
INFO - 2018-05-08 15:53:03 --> Model Class Initialized
INFO - 2018-05-08 15:53:03 --> Model Class Initialized
INFO - 2018-05-08 15:53:03 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-05-08 10:23:03 --> UTF-8 Support Enabled
INFO - 2018-05-08 10:23:03 --> Utf8 Class Initialized
INFO - 2018-05-08 15:53:03 --> Model Class Initialized
DEBUG - 2018-05-08 15:53:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:53:03 --> Final output sent to browser
DEBUG - 2018-05-08 15:53:03 --> Total execution time: 0.1073
INFO - 2018-05-08 15:53:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:53:03 --> Database Driver Class Initialized
INFO - 2018-05-08 10:23:03 --> URI Class Initialized
DEBUG - 2018-05-08 15:53:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:53:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 10:23:03 --> Router Class Initialized
INFO - 2018-05-08 15:53:03 --> Helper loaded: form_helper
INFO - 2018-05-08 15:53:03 --> Form Validation Class Initialized
INFO - 2018-05-08 15:53:03 --> Controller Class Initialized
INFO - 2018-05-08 10:23:03 --> Output Class Initialized
INFO - 2018-05-08 10:23:03 --> Security Class Initialized
INFO - 2018-05-08 15:53:03 --> Model Class Initialized
INFO - 2018-05-08 15:53:03 --> Helper loaded: inflector_helper
INFO - 2018-05-08 10:23:03 --> Language Class Initialized
INFO - 2018-05-08 10:23:03 --> Config Class Initialized
INFO - 2018-05-08 10:23:03 --> Loader Class Initialized
DEBUG - 2018-05-08 10:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 10:23:03 --> Input Class Initialized
DEBUG - 2018-05-08 15:53:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 10:23:03 --> Language Class Initialized
INFO - 2018-05-08 15:53:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:53:03 --> Helper loaded: url_helper
INFO - 2018-05-08 15:53:03 --> Model Class Initialized
INFO - 2018-05-08 15:53:03 --> Helper loaded: form_helper
INFO - 2018-05-08 15:53:03 --> Form Validation Class Initialized
INFO - 2018-05-08 15:53:03 --> Model Class Initialized
INFO - 2018-05-08 15:53:03 --> Controller Class Initialized
INFO - 2018-05-08 15:53:03 --> Model Class Initialized
INFO - 2018-05-08 15:53:03 --> Model Class Initialized
INFO - 2018-05-08 15:53:03 --> Model Class Initialized
INFO - 2018-05-08 15:53:03 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:53:03 --> Model Class Initialized
INFO - 2018-05-08 15:53:03 --> Model Class Initialized
INFO - 2018-05-08 15:53:03 --> Model Class Initialized
INFO - 2018-05-08 15:53:03 --> Model Class Initialized
INFO - 2018-05-08 15:53:03 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:53:03 --> Model Class Initialized
INFO - 2018-05-08 15:53:03 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:53:03 --> Model Class Initialized
INFO - 2018-05-08 15:53:03 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 15:53:03 --> Helper loaded: users_helper
INFO - 2018-05-08 15:53:03 --> Model Class Initialized
INFO - 2018-05-08 15:53:03 --> Final output sent to browser
DEBUG - 2018-05-08 15:53:03 --> Total execution time: 0.1504
INFO - 2018-05-08 10:23:03 --> Language Class Initialized
INFO - 2018-05-08 10:23:03 --> Config Class Initialized
INFO - 2018-05-08 10:23:03 --> Loader Class Initialized
INFO - 2018-05-08 15:53:03 --> Helper loaded: url_helper
INFO - 2018-05-08 15:53:03 --> Model Class Initialized
INFO - 2018-05-08 15:53:03 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:53:03 --> Helper loaded: inflector_helper
INFO - 2018-05-08 15:53:03 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:53:03 --> Database Driver Class Initialized
DEBUG - 2018-05-08 15:53:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:53:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:53:03 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:53:03 --> Model Class Initialized
INFO - 2018-05-08 15:53:03 --> Model Class Initialized
INFO - 2018-05-08 15:53:03 --> Helper loaded: users_helper
INFO - 2018-05-08 15:53:03 --> Model Class Initialized
INFO - 2018-05-08 15:53:03 --> Model Class Initialized
INFO - 2018-05-08 15:53:03 --> Model Class Initialized
INFO - 2018-05-08 15:53:03 --> Model Class Initialized
INFO - 2018-05-08 15:53:03 --> Model Class Initialized
INFO - 2018-05-08 15:53:03 --> Model Class Initialized
INFO - 2018-05-08 15:53:03 --> Model Class Initialized
INFO - 2018-05-08 15:53:03 --> Model Class Initialized
DEBUG - 2018-05-08 15:53:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:53:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:53:03 --> Model Class Initialized
INFO - 2018-05-08 15:53:03 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 15:53:03 --> Model Class Initialized
INFO - 2018-05-08 15:53:03 --> Final output sent to browser
DEBUG - 2018-05-08 15:53:03 --> Total execution time: 0.2040
INFO - 2018-05-08 15:53:03 --> Helper loaded: form_helper
INFO - 2018-05-08 15:53:03 --> Form Validation Class Initialized
INFO - 2018-05-08 15:53:03 --> Controller Class Initialized
INFO - 2018-05-08 15:53:03 --> Database Driver Class Initialized
INFO - 2018-05-08 15:53:03 --> Model Class Initialized
DEBUG - 2018-05-08 15:53:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:53:03 --> Helper loaded: inflector_helper
INFO - 2018-05-08 15:53:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-05-08 15:53:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:53:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:53:03 --> Helper loaded: form_helper
INFO - 2018-05-08 15:53:03 --> Form Validation Class Initialized
INFO - 2018-05-08 15:53:03 --> Controller Class Initialized
INFO - 2018-05-08 15:53:03 --> Model Class Initialized
INFO - 2018-05-08 15:53:03 --> Model Class Initialized
INFO - 2018-05-08 15:53:03 --> Model Class Initialized
INFO - 2018-05-08 15:53:03 --> Model Class Initialized
INFO - 2018-05-08 15:53:03 --> Model Class Initialized
INFO - 2018-05-08 15:53:03 --> Model Class Initialized
INFO - 2018-05-08 15:53:03 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 15:53:03 --> Model Class Initialized
INFO - 2018-05-08 15:53:03 --> Helper loaded: inflector_helper
INFO - 2018-05-08 15:53:04 --> Final output sent to browser
DEBUG - 2018-05-08 15:53:04 --> Total execution time: 0.2129
DEBUG - 2018-05-08 15:53:04 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:53:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:53:04 --> Model Class Initialized
INFO - 2018-05-08 15:53:04 --> Model Class Initialized
INFO - 2018-05-08 15:53:04 --> Model Class Initialized
INFO - 2018-05-08 15:53:04 --> Model Class Initialized
INFO - 2018-05-08 15:53:04 --> Model Class Initialized
INFO - 2018-05-08 15:53:04 --> Model Class Initialized
INFO - 2018-05-08 15:53:04 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 15:53:04 --> Model Class Initialized
INFO - 2018-05-08 15:53:04 --> Final output sent to browser
DEBUG - 2018-05-08 15:53:04 --> Total execution time: 0.2204
INFO - 2018-05-08 10:23:05 --> Config Class Initialized
INFO - 2018-05-08 10:23:05 --> Hooks Class Initialized
DEBUG - 2018-05-08 10:23:05 --> UTF-8 Support Enabled
INFO - 2018-05-08 10:23:05 --> Utf8 Class Initialized
INFO - 2018-05-08 10:23:05 --> Config Class Initialized
INFO - 2018-05-08 10:23:05 --> Hooks Class Initialized
DEBUG - 2018-05-08 10:23:05 --> UTF-8 Support Enabled
INFO - 2018-05-08 10:23:05 --> Utf8 Class Initialized
INFO - 2018-05-08 10:23:05 --> URI Class Initialized
INFO - 2018-05-08 10:23:05 --> URI Class Initialized
INFO - 2018-05-08 10:23:05 --> Router Class Initialized
INFO - 2018-05-08 10:23:05 --> Router Class Initialized
INFO - 2018-05-08 10:23:05 --> Output Class Initialized
INFO - 2018-05-08 10:23:05 --> Security Class Initialized
DEBUG - 2018-05-08 10:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 10:23:05 --> Input Class Initialized
INFO - 2018-05-08 10:23:05 --> Language Class Initialized
INFO - 2018-05-08 10:23:05 --> Output Class Initialized
INFO - 2018-05-08 10:23:05 --> Config Class Initialized
INFO - 2018-05-08 10:23:05 --> Hooks Class Initialized
INFO - 2018-05-08 10:23:05 --> Security Class Initialized
DEBUG - 2018-05-08 10:23:05 --> UTF-8 Support Enabled
INFO - 2018-05-08 10:23:05 --> Utf8 Class Initialized
INFO - 2018-05-08 10:23:05 --> Language Class Initialized
INFO - 2018-05-08 10:23:05 --> Config Class Initialized
INFO - 2018-05-08 10:23:05 --> Loader Class Initialized
INFO - 2018-05-08 15:53:05 --> Helper loaded: url_helper
INFO - 2018-05-08 10:23:05 --> URI Class Initialized
INFO - 2018-05-08 15:53:05 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:53:05 --> Helper loaded: settings_helper
DEBUG - 2018-05-08 10:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 10:23:05 --> Input Class Initialized
INFO - 2018-05-08 15:53:05 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:53:05 --> Helper loaded: users_helper
INFO - 2018-05-08 10:23:05 --> Language Class Initialized
INFO - 2018-05-08 10:23:05 --> Router Class Initialized
INFO - 2018-05-08 10:23:05 --> Output Class Initialized
INFO - 2018-05-08 10:23:05 --> Security Class Initialized
INFO - 2018-05-08 15:53:05 --> Database Driver Class Initialized
DEBUG - 2018-05-08 10:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 10:23:05 --> Input Class Initialized
INFO - 2018-05-08 10:23:05 --> Language Class Initialized
DEBUG - 2018-05-08 15:53:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:53:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:53:05 --> Helper loaded: form_helper
INFO - 2018-05-08 15:53:05 --> Form Validation Class Initialized
INFO - 2018-05-08 15:53:05 --> Controller Class Initialized
INFO - 2018-05-08 15:53:05 --> Model Class Initialized
INFO - 2018-05-08 15:53:05 --> Helper loaded: inflector_helper
INFO - 2018-05-08 10:23:05 --> Language Class Initialized
INFO - 2018-05-08 10:23:05 --> Config Class Initialized
INFO - 2018-05-08 10:23:05 --> Loader Class Initialized
DEBUG - 2018-05-08 15:53:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:53:05 --> Helper loaded: url_helper
INFO - 2018-05-08 15:53:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:53:05 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:53:05 --> Model Class Initialized
INFO - 2018-05-08 15:53:05 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:53:05 --> Model Class Initialized
INFO - 2018-05-08 15:53:05 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:53:05 --> Model Class Initialized
INFO - 2018-05-08 15:53:05 --> Model Class Initialized
INFO - 2018-05-08 15:53:05 --> Model Class Initialized
INFO - 2018-05-08 15:53:05 --> Model Class Initialized
INFO - 2018-05-08 15:53:05 --> Helper loaded: users_helper
INFO - 2018-05-08 15:53:05 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 15:53:05 --> Final output sent to browser
DEBUG - 2018-05-08 15:53:05 --> Total execution time: 0.1025
INFO - 2018-05-08 10:23:05 --> Language Class Initialized
INFO - 2018-05-08 10:23:05 --> Config Class Initialized
INFO - 2018-05-08 10:23:05 --> Loader Class Initialized
INFO - 2018-05-08 15:53:05 --> Database Driver Class Initialized
INFO - 2018-05-08 15:53:05 --> Helper loaded: url_helper
INFO - 2018-05-08 15:53:05 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:53:05 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:53:05 --> Helper loaded: permission_helper
DEBUG - 2018-05-08 15:53:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:53:05 --> Helper loaded: users_helper
INFO - 2018-05-08 15:53:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:53:05 --> Helper loaded: form_helper
INFO - 2018-05-08 15:53:05 --> Form Validation Class Initialized
INFO - 2018-05-08 15:53:05 --> Controller Class Initialized
INFO - 2018-05-08 15:53:05 --> Model Class Initialized
INFO - 2018-05-08 15:53:05 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 15:53:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:53:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:53:05 --> Model Class Initialized
INFO - 2018-05-08 15:53:05 --> Model Class Initialized
INFO - 2018-05-08 15:53:05 --> Model Class Initialized
INFO - 2018-05-08 15:53:05 --> Model Class Initialized
INFO - 2018-05-08 15:53:05 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 15:53:05 --> Final output sent to browser
DEBUG - 2018-05-08 15:53:05 --> Total execution time: 0.1418
INFO - 2018-05-08 15:53:05 --> Database Driver Class Initialized
DEBUG - 2018-05-08 15:53:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:53:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:53:05 --> Helper loaded: form_helper
INFO - 2018-05-08 15:53:05 --> Form Validation Class Initialized
INFO - 2018-05-08 15:53:05 --> Controller Class Initialized
INFO - 2018-05-08 15:53:05 --> Model Class Initialized
INFO - 2018-05-08 15:53:05 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 15:53:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:53:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:53:05 --> Model Class Initialized
INFO - 2018-05-08 15:53:05 --> Model Class Initialized
INFO - 2018-05-08 15:53:05 --> Model Class Initialized
INFO - 2018-05-08 15:53:05 --> Model Class Initialized
INFO - 2018-05-08 15:53:05 --> Model Class Initialized
INFO - 2018-05-08 15:53:05 --> Model Class Initialized
INFO - 2018-05-08 15:53:05 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 15:53:05 --> Final output sent to browser
DEBUG - 2018-05-08 15:53:05 --> Total execution time: 0.2391
INFO - 2018-05-08 10:23:18 --> Config Class Initialized
INFO - 2018-05-08 10:23:18 --> Hooks Class Initialized
DEBUG - 2018-05-08 10:23:18 --> UTF-8 Support Enabled
INFO - 2018-05-08 10:23:18 --> Utf8 Class Initialized
INFO - 2018-05-08 10:23:18 --> URI Class Initialized
INFO - 2018-05-08 10:23:18 --> Router Class Initialized
INFO - 2018-05-08 10:23:18 --> Output Class Initialized
INFO - 2018-05-08 10:23:18 --> Security Class Initialized
DEBUG - 2018-05-08 10:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 10:23:18 --> Input Class Initialized
INFO - 2018-05-08 10:23:18 --> Config Class Initialized
INFO - 2018-05-08 10:23:18 --> Hooks Class Initialized
INFO - 2018-05-08 10:23:18 --> Language Class Initialized
DEBUG - 2018-05-08 10:23:18 --> UTF-8 Support Enabled
INFO - 2018-05-08 10:23:18 --> Utf8 Class Initialized
INFO - 2018-05-08 10:23:18 --> URI Class Initialized
INFO - 2018-05-08 10:23:18 --> Language Class Initialized
INFO - 2018-05-08 10:23:18 --> Config Class Initialized
INFO - 2018-05-08 10:23:18 --> Loader Class Initialized
INFO - 2018-05-08 10:23:18 --> Router Class Initialized
INFO - 2018-05-08 15:53:18 --> Helper loaded: url_helper
INFO - 2018-05-08 15:53:18 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:53:18 --> Helper loaded: settings_helper
INFO - 2018-05-08 10:23:18 --> Output Class Initialized
INFO - 2018-05-08 15:53:18 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:53:18 --> Helper loaded: users_helper
INFO - 2018-05-08 10:23:18 --> Security Class Initialized
DEBUG - 2018-05-08 10:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 10:23:18 --> Input Class Initialized
INFO - 2018-05-08 10:23:18 --> Language Class Initialized
INFO - 2018-05-08 15:53:18 --> Database Driver Class Initialized
DEBUG - 2018-05-08 15:53:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:53:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 10:23:18 --> Language Class Initialized
INFO - 2018-05-08 10:23:18 --> Config Class Initialized
INFO - 2018-05-08 10:23:18 --> Loader Class Initialized
INFO - 2018-05-08 15:53:18 --> Helper loaded: form_helper
INFO - 2018-05-08 15:53:18 --> Form Validation Class Initialized
INFO - 2018-05-08 15:53:18 --> Controller Class Initialized
INFO - 2018-05-08 15:53:18 --> Helper loaded: url_helper
INFO - 2018-05-08 15:53:18 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:53:18 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:53:18 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:53:18 --> Helper loaded: users_helper
INFO - 2018-05-08 15:53:18 --> Model Class Initialized
INFO - 2018-05-08 15:53:18 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 15:53:18 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:53:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:53:18 --> Model Class Initialized
INFO - 2018-05-08 15:53:18 --> Model Class Initialized
INFO - 2018-05-08 15:53:18 --> Model Class Initialized
INFO - 2018-05-08 15:53:18 --> Model Class Initialized
INFO - 2018-05-08 15:53:18 --> Final output sent to browser
DEBUG - 2018-05-08 15:53:18 --> Total execution time: 0.1039
INFO - 2018-05-08 15:53:18 --> Database Driver Class Initialized
DEBUG - 2018-05-08 15:53:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:53:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:53:18 --> Helper loaded: form_helper
INFO - 2018-05-08 15:53:18 --> Form Validation Class Initialized
INFO - 2018-05-08 15:53:18 --> Controller Class Initialized
INFO - 2018-05-08 15:53:18 --> Model Class Initialized
INFO - 2018-05-08 15:53:18 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 15:53:18 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:53:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:53:18 --> Model Class Initialized
INFO - 2018-05-08 15:53:18 --> Model Class Initialized
INFO - 2018-05-08 15:53:18 --> Model Class Initialized
INFO - 2018-05-08 15:53:18 --> Model Class Initialized
INFO - 2018-05-08 15:53:18 --> Final output sent to browser
DEBUG - 2018-05-08 15:53:18 --> Total execution time: 0.1344
INFO - 2018-05-08 10:23:20 --> Config Class Initialized
INFO - 2018-05-08 10:23:20 --> Hooks Class Initialized
DEBUG - 2018-05-08 10:23:20 --> UTF-8 Support Enabled
INFO - 2018-05-08 10:23:20 --> Utf8 Class Initialized
INFO - 2018-05-08 10:23:20 --> URI Class Initialized
INFO - 2018-05-08 10:23:20 --> Router Class Initialized
INFO - 2018-05-08 10:23:20 --> Output Class Initialized
INFO - 2018-05-08 10:23:20 --> Security Class Initialized
DEBUG - 2018-05-08 10:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 10:23:20 --> Input Class Initialized
INFO - 2018-05-08 10:23:20 --> Language Class Initialized
INFO - 2018-05-08 10:23:20 --> Language Class Initialized
INFO - 2018-05-08 10:23:20 --> Config Class Initialized
INFO - 2018-05-08 10:23:20 --> Loader Class Initialized
INFO - 2018-05-08 15:53:20 --> Helper loaded: url_helper
INFO - 2018-05-08 15:53:20 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:53:20 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:53:20 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:53:20 --> Helper loaded: users_helper
INFO - 2018-05-08 15:53:20 --> Database Driver Class Initialized
DEBUG - 2018-05-08 15:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:53:20 --> Helper loaded: form_helper
INFO - 2018-05-08 15:53:20 --> Form Validation Class Initialized
INFO - 2018-05-08 15:53:20 --> Controller Class Initialized
INFO - 2018-05-08 15:53:20 --> Model Class Initialized
INFO - 2018-05-08 15:53:20 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 15:53:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:53:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:53:20 --> Model Class Initialized
INFO - 2018-05-08 15:53:20 --> Model Class Initialized
INFO - 2018-05-08 15:53:20 --> Model Class Initialized
INFO - 2018-05-08 15:53:20 --> Model Class Initialized
INFO - 2018-05-08 15:53:20 --> Model Class Initialized
INFO - 2018-05-08 15:53:20 --> Model Class Initialized
INFO - 2018-05-08 15:53:20 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-05-08 15:53:20 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 800
ERROR - 2018-05-08 15:53:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 810
INFO - 2018-05-08 15:53:20 --> Final output sent to browser
DEBUG - 2018-05-08 15:53:20 --> Total execution time: 0.1436
INFO - 2018-05-08 10:25:54 --> Config Class Initialized
INFO - 2018-05-08 10:25:54 --> Hooks Class Initialized
DEBUG - 2018-05-08 10:25:54 --> UTF-8 Support Enabled
INFO - 2018-05-08 10:25:54 --> Utf8 Class Initialized
INFO - 2018-05-08 10:25:54 --> URI Class Initialized
INFO - 2018-05-08 10:25:54 --> Router Class Initialized
INFO - 2018-05-08 10:25:54 --> Output Class Initialized
INFO - 2018-05-08 10:25:54 --> Security Class Initialized
DEBUG - 2018-05-08 10:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 10:25:54 --> Input Class Initialized
INFO - 2018-05-08 10:25:54 --> Language Class Initialized
INFO - 2018-05-08 10:25:54 --> Language Class Initialized
INFO - 2018-05-08 10:25:54 --> Config Class Initialized
INFO - 2018-05-08 10:25:54 --> Loader Class Initialized
INFO - 2018-05-08 15:55:54 --> Helper loaded: url_helper
INFO - 2018-05-08 15:55:54 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:55:54 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:55:54 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:55:54 --> Helper loaded: users_helper
INFO - 2018-05-08 15:55:54 --> Database Driver Class Initialized
DEBUG - 2018-05-08 15:55:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:55:54 --> Helper loaded: form_helper
INFO - 2018-05-08 15:55:54 --> Form Validation Class Initialized
INFO - 2018-05-08 15:55:54 --> Controller Class Initialized
INFO - 2018-05-08 15:55:54 --> Model Class Initialized
INFO - 2018-05-08 15:55:54 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 15:55:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:55:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:55:54 --> Model Class Initialized
INFO - 2018-05-08 15:55:54 --> Model Class Initialized
INFO - 2018-05-08 15:55:54 --> Model Class Initialized
INFO - 2018-05-08 15:55:54 --> Model Class Initialized
INFO - 2018-05-08 15:55:54 --> Model Class Initialized
INFO - 2018-05-08 15:55:54 --> Model Class Initialized
INFO - 2018-05-08 15:55:54 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 15:55:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-05-08 15:55:54 --> Final output sent to browser
DEBUG - 2018-05-08 15:55:54 --> Total execution time: 0.1255
INFO - 2018-05-08 10:25:54 --> Config Class Initialized
INFO - 2018-05-08 10:25:54 --> Hooks Class Initialized
DEBUG - 2018-05-08 10:25:54 --> UTF-8 Support Enabled
INFO - 2018-05-08 10:25:54 --> Utf8 Class Initialized
INFO - 2018-05-08 10:25:54 --> URI Class Initialized
INFO - 2018-05-08 10:25:54 --> Router Class Initialized
INFO - 2018-05-08 10:25:54 --> Output Class Initialized
INFO - 2018-05-08 10:25:54 --> Security Class Initialized
DEBUG - 2018-05-08 10:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 10:25:54 --> Input Class Initialized
INFO - 2018-05-08 10:25:54 --> Language Class Initialized
INFO - 2018-05-08 10:25:55 --> Language Class Initialized
INFO - 2018-05-08 10:25:55 --> Config Class Initialized
INFO - 2018-05-08 10:25:55 --> Loader Class Initialized
INFO - 2018-05-08 15:55:55 --> Helper loaded: url_helper
INFO - 2018-05-08 15:55:55 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:55:55 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:55:55 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:55:55 --> Helper loaded: users_helper
INFO - 2018-05-08 15:55:55 --> Database Driver Class Initialized
DEBUG - 2018-05-08 15:55:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:55:55 --> Helper loaded: form_helper
INFO - 2018-05-08 15:55:55 --> Form Validation Class Initialized
INFO - 2018-05-08 15:55:55 --> Controller Class Initialized
INFO - 2018-05-08 15:55:55 --> Model Class Initialized
INFO - 2018-05-08 15:55:55 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 15:55:55 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:55:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:55:55 --> Model Class Initialized
INFO - 2018-05-08 15:55:55 --> Model Class Initialized
INFO - 2018-05-08 15:55:55 --> Model Class Initialized
INFO - 2018-05-08 15:55:55 --> Model Class Initialized
INFO - 2018-05-08 15:55:55 --> Model Class Initialized
INFO - 2018-05-08 15:55:55 --> Model Class Initialized
INFO - 2018-05-08 15:55:55 --> Model Class Initialized
INFO - 2018-05-08 15:55:55 --> Model Class Initialized
INFO - 2018-05-08 15:55:55 --> Model Class Initialized
INFO - 2018-05-08 15:55:55 --> Model Class Initialized
INFO - 2018-05-08 15:55:55 --> Model Class Initialized
INFO - 2018-05-08 15:55:55 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 15:55:55 --> Model Class Initialized
INFO - 2018-05-08 15:55:55 --> Final output sent to browser
DEBUG - 2018-05-08 15:55:55 --> Total execution time: 0.1571
INFO - 2018-05-08 10:26:55 --> Config Class Initialized
INFO - 2018-05-08 10:26:55 --> Hooks Class Initialized
DEBUG - 2018-05-08 10:26:55 --> UTF-8 Support Enabled
INFO - 2018-05-08 10:26:55 --> Utf8 Class Initialized
INFO - 2018-05-08 10:26:55 --> URI Class Initialized
INFO - 2018-05-08 10:26:55 --> Router Class Initialized
INFO - 2018-05-08 10:26:55 --> Output Class Initialized
INFO - 2018-05-08 10:26:55 --> Security Class Initialized
DEBUG - 2018-05-08 10:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 10:26:55 --> Input Class Initialized
INFO - 2018-05-08 10:26:55 --> Language Class Initialized
INFO - 2018-05-08 10:26:55 --> Language Class Initialized
INFO - 2018-05-08 10:26:55 --> Config Class Initialized
INFO - 2018-05-08 10:26:55 --> Loader Class Initialized
INFO - 2018-05-08 15:56:55 --> Helper loaded: url_helper
INFO - 2018-05-08 15:56:55 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:56:55 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:56:55 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:56:55 --> Helper loaded: users_helper
INFO - 2018-05-08 15:56:55 --> Database Driver Class Initialized
DEBUG - 2018-05-08 15:56:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:56:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:56:55 --> Helper loaded: form_helper
INFO - 2018-05-08 15:56:55 --> Form Validation Class Initialized
INFO - 2018-05-08 15:56:55 --> Controller Class Initialized
INFO - 2018-05-08 15:56:55 --> Model Class Initialized
INFO - 2018-05-08 15:56:55 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 15:56:55 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:56:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:56:55 --> Model Class Initialized
INFO - 2018-05-08 15:56:55 --> Model Class Initialized
INFO - 2018-05-08 15:56:55 --> Model Class Initialized
INFO - 2018-05-08 15:56:55 --> Model Class Initialized
INFO - 2018-05-08 15:56:55 --> Model Class Initialized
INFO - 2018-05-08 15:56:55 --> Model Class Initialized
INFO - 2018-05-08 15:56:55 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 15:56:55 --> Final output sent to browser
DEBUG - 2018-05-08 15:56:55 --> Total execution time: 0.1083
INFO - 2018-05-08 10:26:56 --> Config Class Initialized
INFO - 2018-05-08 10:26:56 --> Hooks Class Initialized
DEBUG - 2018-05-08 10:26:56 --> UTF-8 Support Enabled
INFO - 2018-05-08 10:26:56 --> Utf8 Class Initialized
INFO - 2018-05-08 10:26:56 --> URI Class Initialized
INFO - 2018-05-08 10:26:56 --> Router Class Initialized
INFO - 2018-05-08 10:26:56 --> Output Class Initialized
INFO - 2018-05-08 10:26:56 --> Security Class Initialized
DEBUG - 2018-05-08 10:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 10:26:56 --> Input Class Initialized
INFO - 2018-05-08 10:26:56 --> Language Class Initialized
INFO - 2018-05-08 10:26:56 --> Language Class Initialized
INFO - 2018-05-08 10:26:56 --> Config Class Initialized
INFO - 2018-05-08 10:26:56 --> Loader Class Initialized
INFO - 2018-05-08 15:56:56 --> Helper loaded: url_helper
INFO - 2018-05-08 15:56:56 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:56:56 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:56:56 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:56:56 --> Helper loaded: users_helper
INFO - 2018-05-08 15:56:56 --> Database Driver Class Initialized
DEBUG - 2018-05-08 15:56:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:56:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:56:57 --> Helper loaded: form_helper
INFO - 2018-05-08 15:56:57 --> Form Validation Class Initialized
INFO - 2018-05-08 15:56:57 --> Controller Class Initialized
INFO - 2018-05-08 15:56:57 --> Model Class Initialized
INFO - 2018-05-08 15:56:57 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 15:56:57 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:56:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:56:57 --> Model Class Initialized
INFO - 2018-05-08 15:56:57 --> Model Class Initialized
INFO - 2018-05-08 15:56:57 --> Model Class Initialized
INFO - 2018-05-08 15:56:57 --> Model Class Initialized
INFO - 2018-05-08 15:56:57 --> Model Class Initialized
INFO - 2018-05-08 15:56:57 --> Model Class Initialized
INFO - 2018-05-08 15:56:57 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 15:56:57 --> Model Class Initialized
INFO - 2018-05-08 15:56:57 --> Final output sent to browser
DEBUG - 2018-05-08 15:56:57 --> Total execution time: 0.1344
INFO - 2018-05-08 10:26:57 --> Config Class Initialized
INFO - 2018-05-08 10:26:57 --> Hooks Class Initialized
DEBUG - 2018-05-08 10:26:57 --> UTF-8 Support Enabled
INFO - 2018-05-08 10:26:57 --> Utf8 Class Initialized
INFO - 2018-05-08 10:26:57 --> URI Class Initialized
INFO - 2018-05-08 10:26:57 --> Router Class Initialized
INFO - 2018-05-08 10:26:57 --> Output Class Initialized
INFO - 2018-05-08 10:26:57 --> Security Class Initialized
DEBUG - 2018-05-08 10:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 10:26:57 --> Input Class Initialized
INFO - 2018-05-08 10:26:57 --> Language Class Initialized
INFO - 2018-05-08 10:26:57 --> Language Class Initialized
INFO - 2018-05-08 10:26:57 --> Config Class Initialized
INFO - 2018-05-08 10:26:57 --> Loader Class Initialized
INFO - 2018-05-08 15:56:57 --> Helper loaded: url_helper
INFO - 2018-05-08 15:56:57 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:56:57 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:56:57 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:56:57 --> Helper loaded: users_helper
INFO - 2018-05-08 15:56:57 --> Database Driver Class Initialized
DEBUG - 2018-05-08 15:56:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:56:57 --> Helper loaded: form_helper
INFO - 2018-05-08 15:56:57 --> Form Validation Class Initialized
INFO - 2018-05-08 15:56:57 --> Controller Class Initialized
INFO - 2018-05-08 15:56:57 --> Model Class Initialized
INFO - 2018-05-08 15:56:57 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 15:56:57 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:56:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:56:57 --> Model Class Initialized
INFO - 2018-05-08 15:56:57 --> Model Class Initialized
INFO - 2018-05-08 15:56:57 --> Model Class Initialized
INFO - 2018-05-08 15:56:57 --> Model Class Initialized
INFO - 2018-05-08 15:56:57 --> Model Class Initialized
INFO - 2018-05-08 15:56:57 --> Model Class Initialized
INFO - 2018-05-08 15:56:57 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 15:56:57 --> Final output sent to browser
DEBUG - 2018-05-08 15:56:57 --> Total execution time: 0.1302
INFO - 2018-05-08 10:26:58 --> Config Class Initialized
INFO - 2018-05-08 10:26:58 --> Hooks Class Initialized
DEBUG - 2018-05-08 10:26:58 --> UTF-8 Support Enabled
INFO - 2018-05-08 10:26:58 --> Utf8 Class Initialized
INFO - 2018-05-08 10:26:58 --> URI Class Initialized
INFO - 2018-05-08 10:26:58 --> Router Class Initialized
INFO - 2018-05-08 10:26:58 --> Output Class Initialized
INFO - 2018-05-08 10:26:58 --> Security Class Initialized
DEBUG - 2018-05-08 10:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 10:26:58 --> Input Class Initialized
INFO - 2018-05-08 10:26:58 --> Language Class Initialized
INFO - 2018-05-08 10:26:58 --> Language Class Initialized
INFO - 2018-05-08 10:26:58 --> Config Class Initialized
INFO - 2018-05-08 10:26:58 --> Loader Class Initialized
INFO - 2018-05-08 15:56:58 --> Helper loaded: url_helper
INFO - 2018-05-08 15:56:58 --> Helper loaded: notification_helper
INFO - 2018-05-08 15:56:58 --> Helper loaded: settings_helper
INFO - 2018-05-08 15:56:58 --> Helper loaded: permission_helper
INFO - 2018-05-08 15:56:58 --> Helper loaded: users_helper
INFO - 2018-05-08 15:56:58 --> Database Driver Class Initialized
DEBUG - 2018-05-08 15:56:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 15:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 15:56:58 --> Helper loaded: form_helper
INFO - 2018-05-08 15:56:58 --> Form Validation Class Initialized
INFO - 2018-05-08 15:56:58 --> Controller Class Initialized
INFO - 2018-05-08 15:56:58 --> Model Class Initialized
INFO - 2018-05-08 15:56:58 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 15:56:58 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 15:56:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 15:56:58 --> Model Class Initialized
INFO - 2018-05-08 15:56:58 --> Model Class Initialized
INFO - 2018-05-08 15:56:58 --> Model Class Initialized
INFO - 2018-05-08 15:56:58 --> Model Class Initialized
INFO - 2018-05-08 15:56:58 --> Model Class Initialized
INFO - 2018-05-08 15:56:58 --> Model Class Initialized
INFO - 2018-05-08 15:56:58 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 15:56:58 --> Final output sent to browser
DEBUG - 2018-05-08 15:56:58 --> Total execution time: 0.1104
INFO - 2018-05-08 11:29:58 --> Config Class Initialized
INFO - 2018-05-08 11:29:58 --> Hooks Class Initialized
DEBUG - 2018-05-08 11:29:58 --> UTF-8 Support Enabled
INFO - 2018-05-08 11:29:58 --> Utf8 Class Initialized
INFO - 2018-05-08 11:29:58 --> URI Class Initialized
INFO - 2018-05-08 11:29:58 --> Router Class Initialized
INFO - 2018-05-08 11:29:58 --> Output Class Initialized
INFO - 2018-05-08 11:29:58 --> Security Class Initialized
DEBUG - 2018-05-08 11:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 11:29:58 --> Input Class Initialized
INFO - 2018-05-08 11:29:58 --> Language Class Initialized
INFO - 2018-05-08 11:29:58 --> Language Class Initialized
INFO - 2018-05-08 11:29:58 --> Config Class Initialized
INFO - 2018-05-08 11:29:58 --> Loader Class Initialized
INFO - 2018-05-08 16:59:58 --> Helper loaded: url_helper
INFO - 2018-05-08 16:59:58 --> Helper loaded: notification_helper
INFO - 2018-05-08 16:59:58 --> Helper loaded: settings_helper
INFO - 2018-05-08 16:59:58 --> Helper loaded: permission_helper
INFO - 2018-05-08 16:59:58 --> Helper loaded: users_helper
INFO - 2018-05-08 16:59:58 --> Database Driver Class Initialized
DEBUG - 2018-05-08 16:59:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 16:59:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 16:59:58 --> Helper loaded: form_helper
INFO - 2018-05-08 16:59:58 --> Form Validation Class Initialized
INFO - 2018-05-08 16:59:58 --> Controller Class Initialized
INFO - 2018-05-08 16:59:58 --> Model Class Initialized
INFO - 2018-05-08 16:59:58 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 16:59:58 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 16:59:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 16:59:58 --> Model Class Initialized
INFO - 2018-05-08 16:59:58 --> Model Class Initialized
INFO - 2018-05-08 16:59:58 --> Model Class Initialized
INFO - 2018-05-08 16:59:58 --> Model Class Initialized
INFO - 2018-05-08 16:59:58 --> Model Class Initialized
INFO - 2018-05-08 16:59:58 --> Model Class Initialized
INFO - 2018-05-08 16:59:58 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 16:59:58 --> Model Class Initialized
INFO - 2018-05-08 16:59:58 --> Final output sent to browser
DEBUG - 2018-05-08 16:59:58 --> Total execution time: 0.1106
INFO - 2018-05-08 11:29:58 --> Config Class Initialized
INFO - 2018-05-08 11:29:58 --> Hooks Class Initialized
DEBUG - 2018-05-08 11:29:58 --> UTF-8 Support Enabled
INFO - 2018-05-08 11:29:58 --> Utf8 Class Initialized
INFO - 2018-05-08 11:29:58 --> URI Class Initialized
INFO - 2018-05-08 11:29:58 --> Router Class Initialized
INFO - 2018-05-08 11:29:58 --> Output Class Initialized
INFO - 2018-05-08 11:29:58 --> Security Class Initialized
DEBUG - 2018-05-08 11:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 11:29:58 --> Input Class Initialized
INFO - 2018-05-08 11:29:58 --> Language Class Initialized
INFO - 2018-05-08 11:29:59 --> Language Class Initialized
INFO - 2018-05-08 11:29:59 --> Config Class Initialized
INFO - 2018-05-08 11:29:59 --> Loader Class Initialized
INFO - 2018-05-08 16:59:59 --> Helper loaded: url_helper
INFO - 2018-05-08 16:59:59 --> Helper loaded: notification_helper
INFO - 2018-05-08 16:59:59 --> Helper loaded: settings_helper
INFO - 2018-05-08 16:59:59 --> Helper loaded: permission_helper
INFO - 2018-05-08 16:59:59 --> Helper loaded: users_helper
INFO - 2018-05-08 16:59:59 --> Database Driver Class Initialized
DEBUG - 2018-05-08 16:59:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 16:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 16:59:59 --> Helper loaded: form_helper
INFO - 2018-05-08 16:59:59 --> Form Validation Class Initialized
INFO - 2018-05-08 16:59:59 --> Controller Class Initialized
INFO - 2018-05-08 16:59:59 --> Model Class Initialized
INFO - 2018-05-08 16:59:59 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 16:59:59 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 16:59:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 16:59:59 --> Model Class Initialized
INFO - 2018-05-08 16:59:59 --> Model Class Initialized
INFO - 2018-05-08 16:59:59 --> Model Class Initialized
INFO - 2018-05-08 16:59:59 --> Model Class Initialized
INFO - 2018-05-08 16:59:59 --> Model Class Initialized
INFO - 2018-05-08 16:59:59 --> Model Class Initialized
INFO - 2018-05-08 16:59:59 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 16:59:59 --> Final output sent to browser
DEBUG - 2018-05-08 16:59:59 --> Total execution time: 0.1065
INFO - 2018-05-08 11:29:59 --> Config Class Initialized
INFO - 2018-05-08 11:29:59 --> Hooks Class Initialized
DEBUG - 2018-05-08 11:29:59 --> UTF-8 Support Enabled
INFO - 2018-05-08 11:29:59 --> Utf8 Class Initialized
INFO - 2018-05-08 11:29:59 --> URI Class Initialized
INFO - 2018-05-08 11:29:59 --> Router Class Initialized
INFO - 2018-05-08 11:29:59 --> Output Class Initialized
INFO - 2018-05-08 11:29:59 --> Security Class Initialized
DEBUG - 2018-05-08 11:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 11:29:59 --> Input Class Initialized
INFO - 2018-05-08 11:29:59 --> Language Class Initialized
INFO - 2018-05-08 11:29:59 --> Language Class Initialized
INFO - 2018-05-08 11:29:59 --> Config Class Initialized
INFO - 2018-05-08 11:29:59 --> Loader Class Initialized
INFO - 2018-05-08 16:59:59 --> Helper loaded: url_helper
INFO - 2018-05-08 16:59:59 --> Helper loaded: notification_helper
INFO - 2018-05-08 16:59:59 --> Helper loaded: settings_helper
INFO - 2018-05-08 16:59:59 --> Helper loaded: permission_helper
INFO - 2018-05-08 16:59:59 --> Helper loaded: users_helper
INFO - 2018-05-08 16:59:59 --> Database Driver Class Initialized
DEBUG - 2018-05-08 16:59:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 16:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 16:59:59 --> Helper loaded: form_helper
INFO - 2018-05-08 16:59:59 --> Form Validation Class Initialized
INFO - 2018-05-08 16:59:59 --> Controller Class Initialized
INFO - 2018-05-08 16:59:59 --> Model Class Initialized
INFO - 2018-05-08 16:59:59 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 16:59:59 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 16:59:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 16:59:59 --> Model Class Initialized
INFO - 2018-05-08 16:59:59 --> Model Class Initialized
INFO - 2018-05-08 16:59:59 --> Model Class Initialized
INFO - 2018-05-08 16:59:59 --> Model Class Initialized
INFO - 2018-05-08 16:59:59 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 16:59:59 --> Final output sent to browser
DEBUG - 2018-05-08 16:59:59 --> Total execution time: 0.0999
INFO - 2018-05-08 11:29:59 --> Config Class Initialized
INFO - 2018-05-08 11:29:59 --> Hooks Class Initialized
DEBUG - 2018-05-08 11:29:59 --> UTF-8 Support Enabled
INFO - 2018-05-08 11:29:59 --> Utf8 Class Initialized
INFO - 2018-05-08 11:29:59 --> URI Class Initialized
INFO - 2018-05-08 11:29:59 --> Router Class Initialized
INFO - 2018-05-08 11:29:59 --> Output Class Initialized
INFO - 2018-05-08 11:29:59 --> Security Class Initialized
DEBUG - 2018-05-08 11:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 11:29:59 --> Input Class Initialized
INFO - 2018-05-08 11:29:59 --> Language Class Initialized
INFO - 2018-05-08 11:29:59 --> Language Class Initialized
INFO - 2018-05-08 11:29:59 --> Config Class Initialized
INFO - 2018-05-08 11:29:59 --> Loader Class Initialized
INFO - 2018-05-08 16:59:59 --> Helper loaded: url_helper
INFO - 2018-05-08 16:59:59 --> Helper loaded: notification_helper
INFO - 2018-05-08 16:59:59 --> Helper loaded: settings_helper
INFO - 2018-05-08 16:59:59 --> Helper loaded: permission_helper
INFO - 2018-05-08 16:59:59 --> Helper loaded: users_helper
INFO - 2018-05-08 16:59:59 --> Database Driver Class Initialized
DEBUG - 2018-05-08 16:59:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 16:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 16:59:59 --> Helper loaded: form_helper
INFO - 2018-05-08 16:59:59 --> Form Validation Class Initialized
INFO - 2018-05-08 16:59:59 --> Controller Class Initialized
INFO - 2018-05-08 16:59:59 --> Model Class Initialized
INFO - 2018-05-08 16:59:59 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 16:59:59 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 16:59:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 16:59:59 --> Model Class Initialized
INFO - 2018-05-08 16:59:59 --> Model Class Initialized
INFO - 2018-05-08 16:59:59 --> Model Class Initialized
INFO - 2018-05-08 16:59:59 --> Model Class Initialized
INFO - 2018-05-08 16:59:59 --> Model Class Initialized
INFO - 2018-05-08 16:59:59 --> Model Class Initialized
INFO - 2018-05-08 16:59:59 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 16:59:59 --> Final output sent to browser
DEBUG - 2018-05-08 16:59:59 --> Total execution time: 0.1039
INFO - 2018-05-08 11:30:14 --> Config Class Initialized
INFO - 2018-05-08 11:30:14 --> Hooks Class Initialized
DEBUG - 2018-05-08 11:30:14 --> UTF-8 Support Enabled
INFO - 2018-05-08 11:30:14 --> Utf8 Class Initialized
INFO - 2018-05-08 11:30:14 --> URI Class Initialized
INFO - 2018-05-08 11:30:14 --> Router Class Initialized
INFO - 2018-05-08 11:30:14 --> Output Class Initialized
INFO - 2018-05-08 11:30:14 --> Security Class Initialized
DEBUG - 2018-05-08 11:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 11:30:14 --> Input Class Initialized
INFO - 2018-05-08 11:30:14 --> Language Class Initialized
INFO - 2018-05-08 11:30:14 --> Language Class Initialized
INFO - 2018-05-08 11:30:14 --> Config Class Initialized
INFO - 2018-05-08 11:30:14 --> Loader Class Initialized
INFO - 2018-05-08 17:00:14 --> Helper loaded: url_helper
INFO - 2018-05-08 17:00:14 --> Helper loaded: notification_helper
INFO - 2018-05-08 17:00:14 --> Helper loaded: settings_helper
INFO - 2018-05-08 17:00:14 --> Helper loaded: permission_helper
INFO - 2018-05-08 17:00:14 --> Helper loaded: users_helper
INFO - 2018-05-08 17:00:14 --> Database Driver Class Initialized
DEBUG - 2018-05-08 17:00:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 17:00:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 17:00:14 --> Helper loaded: form_helper
INFO - 2018-05-08 17:00:14 --> Form Validation Class Initialized
INFO - 2018-05-08 17:00:14 --> Controller Class Initialized
INFO - 2018-05-08 17:00:14 --> Model Class Initialized
INFO - 2018-05-08 17:00:14 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 17:00:14 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 17:00:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 17:00:14 --> Model Class Initialized
INFO - 2018-05-08 17:00:14 --> Model Class Initialized
INFO - 2018-05-08 17:00:14 --> Model Class Initialized
INFO - 2018-05-08 17:00:14 --> Model Class Initialized
INFO - 2018-05-08 17:00:14 --> Model Class Initialized
INFO - 2018-05-08 17:00:14 --> Model Class Initialized
INFO - 2018-05-08 17:00:14 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 17:00:14 --> Final output sent to browser
DEBUG - 2018-05-08 17:00:14 --> Total execution time: 0.1131
INFO - 2018-05-08 11:30:40 --> Config Class Initialized
INFO - 2018-05-08 11:30:40 --> Hooks Class Initialized
DEBUG - 2018-05-08 11:30:40 --> UTF-8 Support Enabled
INFO - 2018-05-08 11:30:40 --> Utf8 Class Initialized
INFO - 2018-05-08 11:30:40 --> URI Class Initialized
INFO - 2018-05-08 11:30:40 --> Router Class Initialized
INFO - 2018-05-08 11:30:40 --> Output Class Initialized
INFO - 2018-05-08 11:30:40 --> Security Class Initialized
DEBUG - 2018-05-08 11:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 11:30:40 --> Input Class Initialized
INFO - 2018-05-08 11:30:40 --> Language Class Initialized
INFO - 2018-05-08 11:30:40 --> Language Class Initialized
INFO - 2018-05-08 11:30:40 --> Config Class Initialized
INFO - 2018-05-08 11:30:40 --> Loader Class Initialized
INFO - 2018-05-08 17:00:40 --> Helper loaded: url_helper
INFO - 2018-05-08 17:00:40 --> Helper loaded: notification_helper
INFO - 2018-05-08 17:00:40 --> Helper loaded: settings_helper
INFO - 2018-05-08 17:00:40 --> Helper loaded: permission_helper
INFO - 2018-05-08 17:00:40 --> Helper loaded: users_helper
INFO - 2018-05-08 17:00:40 --> Database Driver Class Initialized
DEBUG - 2018-05-08 17:00:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 17:00:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 17:00:40 --> Helper loaded: form_helper
INFO - 2018-05-08 17:00:40 --> Form Validation Class Initialized
INFO - 2018-05-08 17:00:40 --> Controller Class Initialized
INFO - 2018-05-08 17:00:40 --> Model Class Initialized
INFO - 2018-05-08 17:00:40 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 17:00:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 17:00:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 17:00:40 --> Model Class Initialized
INFO - 2018-05-08 17:00:40 --> Model Class Initialized
INFO - 2018-05-08 17:00:40 --> Model Class Initialized
INFO - 2018-05-08 17:00:40 --> Model Class Initialized
INFO - 2018-05-08 17:00:40 --> Model Class Initialized
INFO - 2018-05-08 17:00:40 --> Model Class Initialized
INFO - 2018-05-08 17:00:40 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 17:00:40 --> Final output sent to browser
DEBUG - 2018-05-08 17:00:40 --> Total execution time: 0.1231
INFO - 2018-05-08 11:30:40 --> Config Class Initialized
INFO - 2018-05-08 11:30:40 --> Hooks Class Initialized
DEBUG - 2018-05-08 11:30:40 --> UTF-8 Support Enabled
INFO - 2018-05-08 11:30:40 --> Utf8 Class Initialized
INFO - 2018-05-08 11:30:40 --> URI Class Initialized
INFO - 2018-05-08 11:30:40 --> Router Class Initialized
INFO - 2018-05-08 11:30:40 --> Output Class Initialized
INFO - 2018-05-08 11:30:40 --> Security Class Initialized
DEBUG - 2018-05-08 11:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 11:30:40 --> Input Class Initialized
INFO - 2018-05-08 11:30:40 --> Language Class Initialized
INFO - 2018-05-08 11:30:40 --> Language Class Initialized
INFO - 2018-05-08 11:30:40 --> Config Class Initialized
INFO - 2018-05-08 11:30:40 --> Loader Class Initialized
INFO - 2018-05-08 17:00:40 --> Helper loaded: url_helper
INFO - 2018-05-08 17:00:40 --> Helper loaded: notification_helper
INFO - 2018-05-08 17:00:40 --> Helper loaded: settings_helper
INFO - 2018-05-08 17:00:40 --> Helper loaded: permission_helper
INFO - 2018-05-08 17:00:40 --> Helper loaded: users_helper
INFO - 2018-05-08 17:00:40 --> Database Driver Class Initialized
DEBUG - 2018-05-08 17:00:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 17:00:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 17:00:40 --> Helper loaded: form_helper
INFO - 2018-05-08 17:00:40 --> Form Validation Class Initialized
INFO - 2018-05-08 17:00:40 --> Controller Class Initialized
INFO - 2018-05-08 17:00:41 --> Model Class Initialized
INFO - 2018-05-08 17:00:41 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 17:00:41 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 17:00:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 17:00:41 --> Model Class Initialized
INFO - 2018-05-08 17:00:41 --> Model Class Initialized
INFO - 2018-05-08 17:00:41 --> Model Class Initialized
INFO - 2018-05-08 17:00:41 --> Model Class Initialized
INFO - 2018-05-08 17:00:41 --> Model Class Initialized
INFO - 2018-05-08 17:00:41 --> Model Class Initialized
INFO - 2018-05-08 17:00:41 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 17:00:41 --> Final output sent to browser
DEBUG - 2018-05-08 17:00:41 --> Total execution time: 0.1174
INFO - 2018-05-08 11:30:42 --> Config Class Initialized
INFO - 2018-05-08 11:30:42 --> Hooks Class Initialized
DEBUG - 2018-05-08 11:30:42 --> UTF-8 Support Enabled
INFO - 2018-05-08 11:30:42 --> Utf8 Class Initialized
INFO - 2018-05-08 11:30:42 --> URI Class Initialized
INFO - 2018-05-08 11:30:42 --> Router Class Initialized
INFO - 2018-05-08 11:30:42 --> Output Class Initialized
INFO - 2018-05-08 11:30:42 --> Security Class Initialized
DEBUG - 2018-05-08 11:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 11:30:42 --> Input Class Initialized
INFO - 2018-05-08 11:30:42 --> Language Class Initialized
INFO - 2018-05-08 11:30:43 --> Language Class Initialized
INFO - 2018-05-08 11:30:43 --> Config Class Initialized
INFO - 2018-05-08 11:30:43 --> Loader Class Initialized
INFO - 2018-05-08 17:00:43 --> Helper loaded: url_helper
INFO - 2018-05-08 17:00:43 --> Helper loaded: notification_helper
INFO - 2018-05-08 17:00:43 --> Helper loaded: settings_helper
INFO - 2018-05-08 17:00:43 --> Helper loaded: permission_helper
INFO - 2018-05-08 17:00:43 --> Helper loaded: users_helper
INFO - 2018-05-08 17:00:43 --> Database Driver Class Initialized
DEBUG - 2018-05-08 17:00:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 17:00:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 17:00:43 --> Helper loaded: form_helper
INFO - 2018-05-08 17:00:43 --> Form Validation Class Initialized
INFO - 2018-05-08 17:00:43 --> Controller Class Initialized
INFO - 2018-05-08 17:00:43 --> Model Class Initialized
INFO - 2018-05-08 17:00:43 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 17:00:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 17:00:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 17:00:43 --> Model Class Initialized
INFO - 2018-05-08 17:00:43 --> Model Class Initialized
INFO - 2018-05-08 17:00:43 --> Model Class Initialized
INFO - 2018-05-08 17:00:43 --> Model Class Initialized
INFO - 2018-05-08 17:00:43 --> Model Class Initialized
INFO - 2018-05-08 17:00:43 --> Model Class Initialized
INFO - 2018-05-08 17:00:43 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 17:00:43 --> Final output sent to browser
DEBUG - 2018-05-08 17:00:43 --> Total execution time: 0.1168
INFO - 2018-05-08 11:51:34 --> Config Class Initialized
INFO - 2018-05-08 11:51:34 --> Hooks Class Initialized
DEBUG - 2018-05-08 11:51:34 --> UTF-8 Support Enabled
INFO - 2018-05-08 11:51:34 --> Utf8 Class Initialized
INFO - 2018-05-08 11:51:34 --> URI Class Initialized
INFO - 2018-05-08 11:51:34 --> Router Class Initialized
INFO - 2018-05-08 11:51:34 --> Output Class Initialized
INFO - 2018-05-08 11:51:34 --> Security Class Initialized
DEBUG - 2018-05-08 11:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 11:51:34 --> Input Class Initialized
INFO - 2018-05-08 11:51:34 --> Language Class Initialized
INFO - 2018-05-08 11:51:34 --> Language Class Initialized
INFO - 2018-05-08 11:51:34 --> Config Class Initialized
INFO - 2018-05-08 11:51:34 --> Loader Class Initialized
INFO - 2018-05-08 17:21:34 --> Helper loaded: url_helper
INFO - 2018-05-08 17:21:34 --> Helper loaded: notification_helper
INFO - 2018-05-08 17:21:34 --> Helper loaded: settings_helper
INFO - 2018-05-08 17:21:34 --> Helper loaded: permission_helper
INFO - 2018-05-08 17:21:34 --> Helper loaded: users_helper
INFO - 2018-05-08 17:21:34 --> Database Driver Class Initialized
DEBUG - 2018-05-08 17:21:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 17:21:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 17:21:34 --> Helper loaded: form_helper
INFO - 2018-05-08 17:21:34 --> Form Validation Class Initialized
INFO - 2018-05-08 17:21:34 --> Controller Class Initialized
INFO - 2018-05-08 17:21:34 --> Model Class Initialized
INFO - 2018-05-08 17:21:34 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 17:21:34 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 17:21:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 17:21:34 --> Model Class Initialized
INFO - 2018-05-08 17:21:34 --> Model Class Initialized
INFO - 2018-05-08 17:21:34 --> Model Class Initialized
INFO - 2018-05-08 17:21:34 --> Model Class Initialized
INFO - 2018-05-08 17:21:34 --> Model Class Initialized
INFO - 2018-05-08 17:21:34 --> Model Class Initialized
INFO - 2018-05-08 17:21:34 --> Model Class Initialized
INFO - 2018-05-08 17:21:34 --> Model Class Initialized
INFO - 2018-05-08 17:21:34 --> Model Class Initialized
INFO - 2018-05-08 17:21:34 --> Model Class Initialized
INFO - 2018-05-08 17:21:34 --> Model Class Initialized
INFO - 2018-05-08 17:21:34 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 17:21:34 --> Model Class Initialized
INFO - 2018-05-08 17:21:34 --> Final output sent to browser
DEBUG - 2018-05-08 17:21:34 --> Total execution time: 0.1306
INFO - 2018-05-08 11:51:35 --> Config Class Initialized
INFO - 2018-05-08 11:51:35 --> Hooks Class Initialized
DEBUG - 2018-05-08 11:51:35 --> UTF-8 Support Enabled
INFO - 2018-05-08 11:51:35 --> Utf8 Class Initialized
INFO - 2018-05-08 11:51:35 --> URI Class Initialized
INFO - 2018-05-08 11:51:35 --> Router Class Initialized
INFO - 2018-05-08 11:51:35 --> Output Class Initialized
INFO - 2018-05-08 11:51:35 --> Security Class Initialized
DEBUG - 2018-05-08 11:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 11:51:35 --> Input Class Initialized
INFO - 2018-05-08 11:51:35 --> Language Class Initialized
INFO - 2018-05-08 11:51:35 --> Language Class Initialized
INFO - 2018-05-08 11:51:35 --> Config Class Initialized
INFO - 2018-05-08 11:51:35 --> Loader Class Initialized
INFO - 2018-05-08 17:21:35 --> Helper loaded: url_helper
INFO - 2018-05-08 17:21:35 --> Helper loaded: notification_helper
INFO - 2018-05-08 17:21:35 --> Helper loaded: settings_helper
INFO - 2018-05-08 17:21:35 --> Helper loaded: permission_helper
INFO - 2018-05-08 17:21:35 --> Helper loaded: users_helper
INFO - 2018-05-08 17:21:35 --> Database Driver Class Initialized
DEBUG - 2018-05-08 17:21:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 17:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 17:21:35 --> Helper loaded: form_helper
INFO - 2018-05-08 17:21:35 --> Form Validation Class Initialized
INFO - 2018-05-08 17:21:35 --> Controller Class Initialized
INFO - 2018-05-08 17:21:35 --> Model Class Initialized
INFO - 2018-05-08 17:21:35 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 17:21:35 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 17:21:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 17:21:35 --> Model Class Initialized
INFO - 2018-05-08 17:21:35 --> Model Class Initialized
INFO - 2018-05-08 17:21:35 --> Model Class Initialized
INFO - 2018-05-08 17:21:35 --> Model Class Initialized
INFO - 2018-05-08 17:21:35 --> Model Class Initialized
INFO - 2018-05-08 17:21:35 --> Model Class Initialized
INFO - 2018-05-08 17:21:35 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 17:21:35 --> Model Class Initialized
INFO - 2018-05-08 17:21:35 --> Final output sent to browser
DEBUG - 2018-05-08 17:21:35 --> Total execution time: 0.1124
INFO - 2018-05-08 11:51:44 --> Config Class Initialized
INFO - 2018-05-08 11:51:44 --> Hooks Class Initialized
DEBUG - 2018-05-08 11:51:44 --> UTF-8 Support Enabled
INFO - 2018-05-08 11:51:44 --> Utf8 Class Initialized
INFO - 2018-05-08 11:51:44 --> URI Class Initialized
INFO - 2018-05-08 11:51:44 --> Router Class Initialized
INFO - 2018-05-08 11:51:44 --> Output Class Initialized
INFO - 2018-05-08 11:51:44 --> Security Class Initialized
DEBUG - 2018-05-08 11:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 11:51:44 --> Input Class Initialized
INFO - 2018-05-08 11:51:44 --> Language Class Initialized
INFO - 2018-05-08 11:51:44 --> Language Class Initialized
INFO - 2018-05-08 11:51:44 --> Config Class Initialized
INFO - 2018-05-08 11:51:44 --> Loader Class Initialized
INFO - 2018-05-08 17:21:44 --> Helper loaded: url_helper
INFO - 2018-05-08 17:21:44 --> Helper loaded: notification_helper
INFO - 2018-05-08 17:21:44 --> Helper loaded: settings_helper
INFO - 2018-05-08 17:21:44 --> Helper loaded: permission_helper
INFO - 2018-05-08 17:21:44 --> Helper loaded: users_helper
INFO - 2018-05-08 11:51:44 --> Config Class Initialized
INFO - 2018-05-08 11:51:44 --> Hooks Class Initialized
DEBUG - 2018-05-08 11:51:44 --> UTF-8 Support Enabled
INFO - 2018-05-08 11:51:44 --> Utf8 Class Initialized
INFO - 2018-05-08 11:51:44 --> URI Class Initialized
INFO - 2018-05-08 11:51:44 --> Router Class Initialized
INFO - 2018-05-08 11:51:44 --> Output Class Initialized
INFO - 2018-05-08 17:21:44 --> Database Driver Class Initialized
INFO - 2018-05-08 11:51:44 --> Security Class Initialized
DEBUG - 2018-05-08 17:21:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-05-08 11:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 11:51:44 --> Input Class Initialized
INFO - 2018-05-08 17:21:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 11:51:44 --> Language Class Initialized
INFO - 2018-05-08 17:21:44 --> Helper loaded: form_helper
INFO - 2018-05-08 17:21:44 --> Form Validation Class Initialized
INFO - 2018-05-08 17:21:44 --> Controller Class Initialized
INFO - 2018-05-08 17:21:44 --> Model Class Initialized
INFO - 2018-05-08 17:21:44 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 17:21:44 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 11:51:44 --> Language Class Initialized
INFO - 2018-05-08 11:51:44 --> Config Class Initialized
INFO - 2018-05-08 11:51:44 --> Loader Class Initialized
INFO - 2018-05-08 17:21:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 17:21:44 --> Model Class Initialized
INFO - 2018-05-08 17:21:44 --> Model Class Initialized
INFO - 2018-05-08 17:21:44 --> Helper loaded: url_helper
INFO - 2018-05-08 17:21:44 --> Helper loaded: notification_helper
INFO - 2018-05-08 17:21:44 --> Model Class Initialized
INFO - 2018-05-08 17:21:44 --> Helper loaded: settings_helper
INFO - 2018-05-08 17:21:44 --> Model Class Initialized
INFO - 2018-05-08 17:21:44 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 17:21:44 --> Helper loaded: permission_helper
INFO - 2018-05-08 17:21:44 --> Helper loaded: users_helper
INFO - 2018-05-08 17:21:44 --> Final output sent to browser
DEBUG - 2018-05-08 17:21:44 --> Total execution time: 0.0990
INFO - 2018-05-08 17:21:44 --> Database Driver Class Initialized
DEBUG - 2018-05-08 17:21:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 17:21:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 17:21:44 --> Helper loaded: form_helper
INFO - 2018-05-08 17:21:44 --> Form Validation Class Initialized
INFO - 2018-05-08 17:21:44 --> Controller Class Initialized
INFO - 2018-05-08 17:21:44 --> Model Class Initialized
INFO - 2018-05-08 17:21:44 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 17:21:44 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 17:21:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 17:21:44 --> Model Class Initialized
INFO - 2018-05-08 17:21:44 --> Model Class Initialized
INFO - 2018-05-08 17:21:44 --> Model Class Initialized
INFO - 2018-05-08 17:21:44 --> Model Class Initialized
INFO - 2018-05-08 17:21:44 --> Model Class Initialized
INFO - 2018-05-08 17:21:44 --> Model Class Initialized
INFO - 2018-05-08 17:21:44 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 17:21:44 --> Final output sent to browser
DEBUG - 2018-05-08 17:21:44 --> Total execution time: 0.0984
INFO - 2018-05-08 11:51:57 --> Config Class Initialized
INFO - 2018-05-08 11:51:57 --> Hooks Class Initialized
DEBUG - 2018-05-08 11:51:57 --> UTF-8 Support Enabled
INFO - 2018-05-08 11:51:57 --> Utf8 Class Initialized
INFO - 2018-05-08 11:51:57 --> URI Class Initialized
INFO - 2018-05-08 11:51:57 --> Router Class Initialized
INFO - 2018-05-08 11:51:57 --> Output Class Initialized
INFO - 2018-05-08 11:51:57 --> Security Class Initialized
DEBUG - 2018-05-08 11:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 11:51:57 --> Input Class Initialized
INFO - 2018-05-08 11:51:57 --> Language Class Initialized
INFO - 2018-05-08 11:51:57 --> Language Class Initialized
INFO - 2018-05-08 11:51:57 --> Config Class Initialized
INFO - 2018-05-08 11:51:57 --> Loader Class Initialized
INFO - 2018-05-08 17:21:57 --> Helper loaded: url_helper
INFO - 2018-05-08 17:21:57 --> Helper loaded: notification_helper
INFO - 2018-05-08 17:21:57 --> Helper loaded: settings_helper
INFO - 2018-05-08 17:21:57 --> Helper loaded: permission_helper
INFO - 2018-05-08 17:21:57 --> Helper loaded: users_helper
INFO - 2018-05-08 17:21:57 --> Database Driver Class Initialized
DEBUG - 2018-05-08 17:21:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 17:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 17:21:57 --> Helper loaded: form_helper
INFO - 2018-05-08 17:21:57 --> Form Validation Class Initialized
INFO - 2018-05-08 17:21:57 --> Controller Class Initialized
INFO - 2018-05-08 17:21:57 --> Model Class Initialized
INFO - 2018-05-08 17:21:57 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 17:21:57 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 17:21:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 17:21:57 --> Model Class Initialized
INFO - 2018-05-08 17:21:57 --> Model Class Initialized
INFO - 2018-05-08 17:21:57 --> Model Class Initialized
INFO - 2018-05-08 17:21:57 --> Model Class Initialized
INFO - 2018-05-08 17:21:57 --> Model Class Initialized
INFO - 2018-05-08 17:21:57 --> Model Class Initialized
INFO - 2018-05-08 17:21:57 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 17:21:57 --> Final output sent to browser
DEBUG - 2018-05-08 17:21:57 --> Total execution time: 0.1122
INFO - 2018-05-08 11:51:59 --> Config Class Initialized
INFO - 2018-05-08 11:51:59 --> Hooks Class Initialized
DEBUG - 2018-05-08 11:51:59 --> UTF-8 Support Enabled
INFO - 2018-05-08 11:51:59 --> Utf8 Class Initialized
INFO - 2018-05-08 11:52:00 --> URI Class Initialized
INFO - 2018-05-08 11:52:00 --> Router Class Initialized
INFO - 2018-05-08 11:52:00 --> Output Class Initialized
INFO - 2018-05-08 11:52:00 --> Security Class Initialized
DEBUG - 2018-05-08 11:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 11:52:00 --> Input Class Initialized
INFO - 2018-05-08 11:52:00 --> Language Class Initialized
INFO - 2018-05-08 11:52:00 --> Language Class Initialized
INFO - 2018-05-08 11:52:00 --> Config Class Initialized
INFO - 2018-05-08 11:52:00 --> Loader Class Initialized
INFO - 2018-05-08 17:22:00 --> Helper loaded: url_helper
INFO - 2018-05-08 17:22:00 --> Helper loaded: notification_helper
INFO - 2018-05-08 17:22:00 --> Helper loaded: settings_helper
INFO - 2018-05-08 17:22:00 --> Helper loaded: permission_helper
INFO - 2018-05-08 17:22:00 --> Helper loaded: users_helper
INFO - 2018-05-08 17:22:00 --> Database Driver Class Initialized
DEBUG - 2018-05-08 17:22:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 17:22:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 17:22:00 --> Helper loaded: form_helper
INFO - 2018-05-08 17:22:00 --> Form Validation Class Initialized
INFO - 2018-05-08 17:22:00 --> Controller Class Initialized
INFO - 2018-05-08 17:22:00 --> Model Class Initialized
INFO - 2018-05-08 17:22:00 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 17:22:00 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 17:22:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 17:22:00 --> Model Class Initialized
INFO - 2018-05-08 17:22:00 --> Model Class Initialized
INFO - 2018-05-08 17:22:00 --> Model Class Initialized
INFO - 2018-05-08 17:22:00 --> Model Class Initialized
INFO - 2018-05-08 17:22:00 --> Model Class Initialized
INFO - 2018-05-08 17:22:00 --> Model Class Initialized
INFO - 2018-05-08 17:22:00 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 17:22:00 --> Final output sent to browser
DEBUG - 2018-05-08 17:22:00 --> Total execution time: 0.1077
INFO - 2018-05-08 11:52:02 --> Config Class Initialized
INFO - 2018-05-08 11:52:02 --> Hooks Class Initialized
DEBUG - 2018-05-08 11:52:02 --> UTF-8 Support Enabled
INFO - 2018-05-08 11:52:02 --> Utf8 Class Initialized
INFO - 2018-05-08 11:52:02 --> URI Class Initialized
INFO - 2018-05-08 11:52:02 --> Router Class Initialized
INFO - 2018-05-08 11:52:02 --> Output Class Initialized
INFO - 2018-05-08 11:52:02 --> Security Class Initialized
DEBUG - 2018-05-08 11:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 11:52:02 --> Input Class Initialized
INFO - 2018-05-08 11:52:02 --> Language Class Initialized
INFO - 2018-05-08 11:52:02 --> Language Class Initialized
INFO - 2018-05-08 11:52:02 --> Config Class Initialized
INFO - 2018-05-08 11:52:02 --> Loader Class Initialized
INFO - 2018-05-08 17:22:02 --> Helper loaded: url_helper
INFO - 2018-05-08 17:22:02 --> Helper loaded: notification_helper
INFO - 2018-05-08 17:22:02 --> Helper loaded: settings_helper
INFO - 2018-05-08 17:22:02 --> Helper loaded: permission_helper
INFO - 2018-05-08 17:22:02 --> Helper loaded: users_helper
INFO - 2018-05-08 17:22:02 --> Database Driver Class Initialized
DEBUG - 2018-05-08 17:22:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 17:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 17:22:02 --> Helper loaded: form_helper
INFO - 2018-05-08 17:22:02 --> Form Validation Class Initialized
INFO - 2018-05-08 17:22:02 --> Controller Class Initialized
INFO - 2018-05-08 17:22:02 --> Model Class Initialized
INFO - 2018-05-08 17:22:02 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 17:22:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 17:22:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 17:22:02 --> Model Class Initialized
INFO - 2018-05-08 17:22:02 --> Model Class Initialized
INFO - 2018-05-08 17:22:02 --> Model Class Initialized
INFO - 2018-05-08 17:22:02 --> Model Class Initialized
INFO - 2018-05-08 17:22:02 --> Model Class Initialized
INFO - 2018-05-08 17:22:02 --> Model Class Initialized
INFO - 2018-05-08 17:22:02 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 17:22:02 --> Final output sent to browser
DEBUG - 2018-05-08 17:22:02 --> Total execution time: 0.1066
INFO - 2018-05-08 11:52:19 --> Config Class Initialized
INFO - 2018-05-08 11:52:19 --> Hooks Class Initialized
DEBUG - 2018-05-08 11:52:19 --> UTF-8 Support Enabled
INFO - 2018-05-08 11:52:19 --> Utf8 Class Initialized
INFO - 2018-05-08 11:52:19 --> URI Class Initialized
INFO - 2018-05-08 11:52:19 --> Router Class Initialized
INFO - 2018-05-08 11:52:19 --> Output Class Initialized
INFO - 2018-05-08 11:52:19 --> Security Class Initialized
DEBUG - 2018-05-08 11:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 11:52:19 --> Input Class Initialized
INFO - 2018-05-08 11:52:19 --> Language Class Initialized
INFO - 2018-05-08 11:52:19 --> Language Class Initialized
INFO - 2018-05-08 11:52:19 --> Config Class Initialized
INFO - 2018-05-08 11:52:19 --> Loader Class Initialized
INFO - 2018-05-08 17:22:19 --> Helper loaded: url_helper
INFO - 2018-05-08 17:22:19 --> Helper loaded: notification_helper
INFO - 2018-05-08 17:22:19 --> Helper loaded: settings_helper
INFO - 2018-05-08 17:22:19 --> Helper loaded: permission_helper
INFO - 2018-05-08 17:22:19 --> Helper loaded: users_helper
INFO - 2018-05-08 17:22:19 --> Database Driver Class Initialized
DEBUG - 2018-05-08 17:22:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 17:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 17:22:20 --> Helper loaded: form_helper
INFO - 2018-05-08 17:22:20 --> Form Validation Class Initialized
INFO - 2018-05-08 17:22:20 --> Controller Class Initialized
INFO - 2018-05-08 17:22:20 --> Model Class Initialized
INFO - 2018-05-08 17:22:20 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 17:22:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 17:22:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 17:22:20 --> Model Class Initialized
INFO - 2018-05-08 17:22:20 --> Model Class Initialized
INFO - 2018-05-08 17:22:20 --> Model Class Initialized
INFO - 2018-05-08 17:22:20 --> Model Class Initialized
INFO - 2018-05-08 17:22:20 --> Model Class Initialized
INFO - 2018-05-08 17:22:20 --> Model Class Initialized
INFO - 2018-05-08 17:22:20 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 17:22:20 --> Final output sent to browser
DEBUG - 2018-05-08 17:22:20 --> Total execution time: 0.1077
INFO - 2018-05-08 12:18:47 --> Config Class Initialized
INFO - 2018-05-08 12:18:47 --> Hooks Class Initialized
DEBUG - 2018-05-08 12:18:47 --> UTF-8 Support Enabled
INFO - 2018-05-08 12:18:47 --> Utf8 Class Initialized
INFO - 2018-05-08 12:18:47 --> URI Class Initialized
INFO - 2018-05-08 12:18:47 --> Router Class Initialized
INFO - 2018-05-08 12:18:47 --> Output Class Initialized
INFO - 2018-05-08 12:18:47 --> Security Class Initialized
DEBUG - 2018-05-08 12:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 12:18:47 --> Input Class Initialized
INFO - 2018-05-08 12:18:47 --> Language Class Initialized
INFO - 2018-05-08 12:18:47 --> Language Class Initialized
INFO - 2018-05-08 12:18:47 --> Config Class Initialized
INFO - 2018-05-08 12:18:47 --> Loader Class Initialized
INFO - 2018-05-08 17:48:47 --> Helper loaded: url_helper
INFO - 2018-05-08 17:48:47 --> Helper loaded: notification_helper
INFO - 2018-05-08 17:48:47 --> Helper loaded: settings_helper
INFO - 2018-05-08 17:48:47 --> Helper loaded: permission_helper
INFO - 2018-05-08 17:48:47 --> Helper loaded: users_helper
INFO - 2018-05-08 17:48:47 --> Database Driver Class Initialized
DEBUG - 2018-05-08 17:48:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 17:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 17:48:47 --> Helper loaded: form_helper
INFO - 2018-05-08 17:48:47 --> Form Validation Class Initialized
INFO - 2018-05-08 17:48:47 --> Controller Class Initialized
INFO - 2018-05-08 17:48:47 --> Model Class Initialized
INFO - 2018-05-08 17:48:47 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 17:48:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 17:48:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 17:48:47 --> Model Class Initialized
INFO - 2018-05-08 17:48:47 --> Model Class Initialized
INFO - 2018-05-08 17:48:47 --> Model Class Initialized
INFO - 2018-05-08 17:48:47 --> Model Class Initialized
INFO - 2018-05-08 17:48:47 --> Model Class Initialized
INFO - 2018-05-08 17:48:47 --> Model Class Initialized
INFO - 2018-05-08 17:48:47 --> Model Class Initialized
INFO - 2018-05-08 17:48:47 --> Model Class Initialized
INFO - 2018-05-08 17:48:47 --> Model Class Initialized
INFO - 2018-05-08 17:48:47 --> Model Class Initialized
INFO - 2018-05-08 17:48:47 --> Model Class Initialized
INFO - 2018-05-08 17:48:47 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 17:48:47 --> Model Class Initialized
INFO - 2018-05-08 17:48:47 --> Final output sent to browser
DEBUG - 2018-05-08 17:48:47 --> Total execution time: 0.1186
INFO - 2018-05-08 12:18:47 --> Config Class Initialized
INFO - 2018-05-08 12:18:47 --> Hooks Class Initialized
DEBUG - 2018-05-08 12:18:47 --> UTF-8 Support Enabled
INFO - 2018-05-08 12:18:47 --> Utf8 Class Initialized
INFO - 2018-05-08 12:18:47 --> URI Class Initialized
INFO - 2018-05-08 12:18:47 --> Router Class Initialized
INFO - 2018-05-08 12:18:47 --> Output Class Initialized
INFO - 2018-05-08 12:18:47 --> Security Class Initialized
DEBUG - 2018-05-08 12:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 12:18:47 --> Input Class Initialized
INFO - 2018-05-08 12:18:47 --> Language Class Initialized
INFO - 2018-05-08 12:18:47 --> Language Class Initialized
INFO - 2018-05-08 12:18:47 --> Config Class Initialized
INFO - 2018-05-08 12:18:47 --> Loader Class Initialized
INFO - 2018-05-08 17:48:47 --> Helper loaded: url_helper
INFO - 2018-05-08 17:48:47 --> Helper loaded: notification_helper
INFO - 2018-05-08 17:48:47 --> Helper loaded: settings_helper
INFO - 2018-05-08 17:48:47 --> Helper loaded: permission_helper
INFO - 2018-05-08 17:48:47 --> Helper loaded: users_helper
INFO - 2018-05-08 17:48:47 --> Database Driver Class Initialized
DEBUG - 2018-05-08 17:48:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 17:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 17:48:47 --> Helper loaded: form_helper
INFO - 2018-05-08 17:48:47 --> Form Validation Class Initialized
INFO - 2018-05-08 17:48:47 --> Controller Class Initialized
INFO - 2018-05-08 17:48:47 --> Model Class Initialized
INFO - 2018-05-08 17:48:47 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 17:48:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 17:48:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 17:48:47 --> Model Class Initialized
INFO - 2018-05-08 17:48:47 --> Model Class Initialized
INFO - 2018-05-08 17:48:47 --> Model Class Initialized
INFO - 2018-05-08 17:48:47 --> Model Class Initialized
INFO - 2018-05-08 17:48:47 --> Model Class Initialized
INFO - 2018-05-08 17:48:47 --> Model Class Initialized
INFO - 2018-05-08 17:48:47 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 17:48:47 --> Model Class Initialized
INFO - 2018-05-08 17:48:47 --> Final output sent to browser
DEBUG - 2018-05-08 17:48:47 --> Total execution time: 0.1547
INFO - 2018-05-08 12:19:05 --> Config Class Initialized
INFO - 2018-05-08 12:19:05 --> Hooks Class Initialized
DEBUG - 2018-05-08 12:19:05 --> UTF-8 Support Enabled
INFO - 2018-05-08 12:19:05 --> Utf8 Class Initialized
INFO - 2018-05-08 12:19:05 --> URI Class Initialized
INFO - 2018-05-08 12:19:05 --> Router Class Initialized
INFO - 2018-05-08 12:19:05 --> Output Class Initialized
INFO - 2018-05-08 12:19:05 --> Security Class Initialized
DEBUG - 2018-05-08 12:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 12:19:05 --> Input Class Initialized
INFO - 2018-05-08 12:19:05 --> Language Class Initialized
INFO - 2018-05-08 12:19:05 --> Config Class Initialized
INFO - 2018-05-08 12:19:05 --> Hooks Class Initialized
INFO - 2018-05-08 12:19:05 --> Language Class Initialized
INFO - 2018-05-08 12:19:05 --> Config Class Initialized
INFO - 2018-05-08 12:19:05 --> Loader Class Initialized
DEBUG - 2018-05-08 12:19:05 --> UTF-8 Support Enabled
INFO - 2018-05-08 12:19:05 --> Utf8 Class Initialized
INFO - 2018-05-08 17:49:05 --> Helper loaded: url_helper
INFO - 2018-05-08 12:19:05 --> URI Class Initialized
INFO - 2018-05-08 17:49:05 --> Helper loaded: notification_helper
INFO - 2018-05-08 17:49:05 --> Helper loaded: settings_helper
INFO - 2018-05-08 17:49:05 --> Helper loaded: permission_helper
INFO - 2018-05-08 17:49:05 --> Helper loaded: users_helper
INFO - 2018-05-08 12:19:05 --> Router Class Initialized
INFO - 2018-05-08 12:19:05 --> Output Class Initialized
INFO - 2018-05-08 12:19:05 --> Security Class Initialized
INFO - 2018-05-08 17:49:05 --> Database Driver Class Initialized
DEBUG - 2018-05-08 12:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 12:19:05 --> Input Class Initialized
INFO - 2018-05-08 12:19:05 --> Language Class Initialized
DEBUG - 2018-05-08 17:49:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 17:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 17:49:05 --> Helper loaded: form_helper
INFO - 2018-05-08 17:49:05 --> Form Validation Class Initialized
INFO - 2018-05-08 17:49:05 --> Controller Class Initialized
INFO - 2018-05-08 17:49:05 --> Model Class Initialized
INFO - 2018-05-08 17:49:05 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 17:49:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 17:49:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 12:19:05 --> Language Class Initialized
INFO - 2018-05-08 12:19:05 --> Config Class Initialized
INFO - 2018-05-08 12:19:05 --> Loader Class Initialized
INFO - 2018-05-08 17:49:05 --> Model Class Initialized
INFO - 2018-05-08 17:49:05 --> Model Class Initialized
INFO - 2018-05-08 17:49:05 --> Model Class Initialized
INFO - 2018-05-08 17:49:05 --> Model Class Initialized
INFO - 2018-05-08 17:49:05 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 17:49:05 --> Helper loaded: url_helper
INFO - 2018-05-08 17:49:05 --> Helper loaded: notification_helper
INFO - 2018-05-08 17:49:05 --> Helper loaded: settings_helper
INFO - 2018-05-08 17:49:05 --> Helper loaded: permission_helper
INFO - 2018-05-08 17:49:05 --> Final output sent to browser
DEBUG - 2018-05-08 17:49:05 --> Total execution time: 0.0996
INFO - 2018-05-08 17:49:05 --> Helper loaded: users_helper
INFO - 2018-05-08 17:49:05 --> Database Driver Class Initialized
DEBUG - 2018-05-08 17:49:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 17:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 17:49:05 --> Helper loaded: form_helper
INFO - 2018-05-08 17:49:05 --> Form Validation Class Initialized
INFO - 2018-05-08 17:49:05 --> Controller Class Initialized
INFO - 2018-05-08 17:49:05 --> Model Class Initialized
INFO - 2018-05-08 17:49:05 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 17:49:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 17:49:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 17:49:05 --> Model Class Initialized
INFO - 2018-05-08 17:49:05 --> Model Class Initialized
INFO - 2018-05-08 17:49:05 --> Model Class Initialized
INFO - 2018-05-08 17:49:05 --> Model Class Initialized
INFO - 2018-05-08 17:49:05 --> Model Class Initialized
INFO - 2018-05-08 17:49:05 --> Model Class Initialized
INFO - 2018-05-08 17:49:05 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 17:49:05 --> Final output sent to browser
DEBUG - 2018-05-08 17:49:05 --> Total execution time: 0.1262
INFO - 2018-05-08 12:29:14 --> Config Class Initialized
INFO - 2018-05-08 12:29:14 --> Hooks Class Initialized
DEBUG - 2018-05-08 12:29:14 --> UTF-8 Support Enabled
INFO - 2018-05-08 12:29:14 --> Utf8 Class Initialized
INFO - 2018-05-08 12:29:14 --> URI Class Initialized
INFO - 2018-05-08 12:29:14 --> Router Class Initialized
INFO - 2018-05-08 12:29:14 --> Output Class Initialized
INFO - 2018-05-08 12:29:14 --> Security Class Initialized
DEBUG - 2018-05-08 12:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 12:29:14 --> Input Class Initialized
INFO - 2018-05-08 12:29:14 --> Language Class Initialized
INFO - 2018-05-08 12:29:15 --> Language Class Initialized
INFO - 2018-05-08 12:29:15 --> Config Class Initialized
INFO - 2018-05-08 12:29:15 --> Loader Class Initialized
INFO - 2018-05-08 17:59:15 --> Helper loaded: url_helper
INFO - 2018-05-08 17:59:15 --> Helper loaded: notification_helper
INFO - 2018-05-08 17:59:15 --> Helper loaded: settings_helper
INFO - 2018-05-08 17:59:15 --> Helper loaded: permission_helper
INFO - 2018-05-08 17:59:15 --> Helper loaded: users_helper
INFO - 2018-05-08 17:59:15 --> Database Driver Class Initialized
DEBUG - 2018-05-08 17:59:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 17:59:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 17:59:15 --> Helper loaded: form_helper
INFO - 2018-05-08 17:59:15 --> Form Validation Class Initialized
INFO - 2018-05-08 17:59:15 --> Controller Class Initialized
INFO - 2018-05-08 17:59:15 --> Model Class Initialized
INFO - 2018-05-08 17:59:15 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 17:59:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 17:59:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 17:59:15 --> Model Class Initialized
INFO - 2018-05-08 17:59:15 --> Model Class Initialized
INFO - 2018-05-08 17:59:15 --> Model Class Initialized
INFO - 2018-05-08 17:59:15 --> Model Class Initialized
INFO - 2018-05-08 17:59:15 --> Model Class Initialized
INFO - 2018-05-08 17:59:15 --> Model Class Initialized
INFO - 2018-05-08 17:59:15 --> Model Class Initialized
INFO - 2018-05-08 17:59:15 --> Model Class Initialized
INFO - 2018-05-08 17:59:15 --> Model Class Initialized
INFO - 2018-05-08 17:59:15 --> Model Class Initialized
INFO - 2018-05-08 17:59:15 --> Model Class Initialized
INFO - 2018-05-08 17:59:15 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 17:59:15 --> Model Class Initialized
INFO - 2018-05-08 17:59:15 --> Final output sent to browser
DEBUG - 2018-05-08 17:59:15 --> Total execution time: 0.2020
INFO - 2018-05-08 12:29:15 --> Config Class Initialized
INFO - 2018-05-08 12:29:15 --> Hooks Class Initialized
DEBUG - 2018-05-08 12:29:15 --> UTF-8 Support Enabled
INFO - 2018-05-08 12:29:15 --> Utf8 Class Initialized
INFO - 2018-05-08 12:29:15 --> URI Class Initialized
INFO - 2018-05-08 12:29:15 --> Router Class Initialized
INFO - 2018-05-08 12:29:15 --> Output Class Initialized
INFO - 2018-05-08 12:29:15 --> Security Class Initialized
DEBUG - 2018-05-08 12:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 12:29:15 --> Input Class Initialized
INFO - 2018-05-08 12:29:15 --> Language Class Initialized
INFO - 2018-05-08 12:29:15 --> Language Class Initialized
INFO - 2018-05-08 12:29:15 --> Config Class Initialized
INFO - 2018-05-08 12:29:15 --> Loader Class Initialized
INFO - 2018-05-08 17:59:15 --> Helper loaded: url_helper
INFO - 2018-05-08 17:59:15 --> Helper loaded: notification_helper
INFO - 2018-05-08 17:59:15 --> Helper loaded: settings_helper
INFO - 2018-05-08 17:59:15 --> Helper loaded: permission_helper
INFO - 2018-05-08 17:59:15 --> Helper loaded: users_helper
INFO - 2018-05-08 17:59:15 --> Database Driver Class Initialized
DEBUG - 2018-05-08 17:59:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 17:59:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 17:59:15 --> Helper loaded: form_helper
INFO - 2018-05-08 17:59:15 --> Form Validation Class Initialized
INFO - 2018-05-08 17:59:15 --> Controller Class Initialized
INFO - 2018-05-08 17:59:15 --> Model Class Initialized
INFO - 2018-05-08 17:59:15 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 17:59:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 17:59:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 17:59:15 --> Model Class Initialized
INFO - 2018-05-08 17:59:15 --> Model Class Initialized
INFO - 2018-05-08 17:59:15 --> Model Class Initialized
INFO - 2018-05-08 17:59:15 --> Model Class Initialized
INFO - 2018-05-08 17:59:15 --> Model Class Initialized
INFO - 2018-05-08 17:59:15 --> Model Class Initialized
INFO - 2018-05-08 17:59:15 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 17:59:15 --> Model Class Initialized
INFO - 2018-05-08 17:59:15 --> Final output sent to browser
DEBUG - 2018-05-08 17:59:15 --> Total execution time: 0.1151
INFO - 2018-05-08 12:29:27 --> Config Class Initialized
INFO - 2018-05-08 12:29:27 --> Hooks Class Initialized
DEBUG - 2018-05-08 12:29:27 --> UTF-8 Support Enabled
INFO - 2018-05-08 12:29:27 --> Utf8 Class Initialized
INFO - 2018-05-08 12:29:27 --> URI Class Initialized
INFO - 2018-05-08 12:29:27 --> Router Class Initialized
INFO - 2018-05-08 12:29:27 --> Output Class Initialized
INFO - 2018-05-08 12:29:27 --> Config Class Initialized
INFO - 2018-05-08 12:29:27 --> Hooks Class Initialized
INFO - 2018-05-08 12:29:27 --> Security Class Initialized
DEBUG - 2018-05-08 12:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 12:29:28 --> Input Class Initialized
DEBUG - 2018-05-08 12:29:28 --> UTF-8 Support Enabled
INFO - 2018-05-08 12:29:28 --> Utf8 Class Initialized
INFO - 2018-05-08 12:29:28 --> Language Class Initialized
INFO - 2018-05-08 12:29:28 --> URI Class Initialized
INFO - 2018-05-08 12:29:28 --> Router Class Initialized
INFO - 2018-05-08 12:29:28 --> Output Class Initialized
INFO - 2018-05-08 12:29:28 --> Security Class Initialized
DEBUG - 2018-05-08 12:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 12:29:28 --> Input Class Initialized
INFO - 2018-05-08 12:29:28 --> Language Class Initialized
INFO - 2018-05-08 12:29:28 --> Language Class Initialized
INFO - 2018-05-08 12:29:28 --> Config Class Initialized
INFO - 2018-05-08 12:29:28 --> Loader Class Initialized
INFO - 2018-05-08 17:59:28 --> Helper loaded: url_helper
INFO - 2018-05-08 17:59:28 --> Helper loaded: notification_helper
INFO - 2018-05-08 17:59:28 --> Helper loaded: settings_helper
INFO - 2018-05-08 17:59:28 --> Helper loaded: permission_helper
INFO - 2018-05-08 17:59:28 --> Helper loaded: users_helper
INFO - 2018-05-08 12:29:28 --> Language Class Initialized
INFO - 2018-05-08 12:29:28 --> Config Class Initialized
INFO - 2018-05-08 12:29:28 --> Loader Class Initialized
INFO - 2018-05-08 17:59:28 --> Database Driver Class Initialized
INFO - 2018-05-08 17:59:28 --> Helper loaded: url_helper
INFO - 2018-05-08 17:59:28 --> Helper loaded: notification_helper
INFO - 2018-05-08 17:59:28 --> Helper loaded: settings_helper
INFO - 2018-05-08 17:59:28 --> Helper loaded: permission_helper
INFO - 2018-05-08 17:59:28 --> Helper loaded: users_helper
DEBUG - 2018-05-08 17:59:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 17:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 17:59:28 --> Helper loaded: form_helper
INFO - 2018-05-08 17:59:28 --> Form Validation Class Initialized
INFO - 2018-05-08 17:59:28 --> Controller Class Initialized
INFO - 2018-05-08 17:59:28 --> Database Driver Class Initialized
INFO - 2018-05-08 17:59:28 --> Model Class Initialized
DEBUG - 2018-05-08 17:59:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 17:59:28 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 17:59:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 17:59:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 17:59:28 --> Model Class Initialized
INFO - 2018-05-08 17:59:28 --> Model Class Initialized
INFO - 2018-05-08 17:59:28 --> Model Class Initialized
INFO - 2018-05-08 17:59:28 --> Model Class Initialized
INFO - 2018-05-08 17:59:28 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 17:59:28 --> Final output sent to browser
DEBUG - 2018-05-08 17:59:28 --> Total execution time: 0.1033
INFO - 2018-05-08 17:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 17:59:28 --> Helper loaded: form_helper
INFO - 2018-05-08 17:59:28 --> Form Validation Class Initialized
INFO - 2018-05-08 17:59:28 --> Controller Class Initialized
INFO - 2018-05-08 17:59:28 --> Model Class Initialized
INFO - 2018-05-08 17:59:28 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 17:59:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 17:59:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 17:59:28 --> Model Class Initialized
INFO - 2018-05-08 17:59:28 --> Model Class Initialized
INFO - 2018-05-08 17:59:28 --> Model Class Initialized
INFO - 2018-05-08 17:59:28 --> Model Class Initialized
INFO - 2018-05-08 17:59:28 --> Model Class Initialized
INFO - 2018-05-08 17:59:28 --> Model Class Initialized
INFO - 2018-05-08 17:59:28 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-08 17:59:28 --> Final output sent to browser
DEBUG - 2018-05-08 17:59:28 --> Total execution time: 0.1398
INFO - 2018-05-08 12:29:47 --> Config Class Initialized
INFO - 2018-05-08 12:29:47 --> Hooks Class Initialized
DEBUG - 2018-05-08 12:29:47 --> UTF-8 Support Enabled
INFO - 2018-05-08 12:29:47 --> Utf8 Class Initialized
INFO - 2018-05-08 12:29:47 --> URI Class Initialized
INFO - 2018-05-08 12:29:47 --> Router Class Initialized
INFO - 2018-05-08 12:29:47 --> Output Class Initialized
INFO - 2018-05-08 12:29:47 --> Security Class Initialized
DEBUG - 2018-05-08 12:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 12:29:47 --> Input Class Initialized
INFO - 2018-05-08 12:29:47 --> Language Class Initialized
INFO - 2018-05-08 12:29:47 --> Language Class Initialized
INFO - 2018-05-08 12:29:47 --> Config Class Initialized
INFO - 2018-05-08 12:29:47 --> Loader Class Initialized
INFO - 2018-05-08 17:59:47 --> Helper loaded: url_helper
INFO - 2018-05-08 17:59:47 --> Helper loaded: notification_helper
INFO - 2018-05-08 17:59:47 --> Helper loaded: settings_helper
INFO - 2018-05-08 17:59:47 --> Helper loaded: permission_helper
INFO - 2018-05-08 17:59:47 --> Helper loaded: users_helper
INFO - 2018-05-08 17:59:47 --> Database Driver Class Initialized
DEBUG - 2018-05-08 17:59:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 17:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 17:59:47 --> Helper loaded: form_helper
INFO - 2018-05-08 17:59:47 --> Form Validation Class Initialized
INFO - 2018-05-08 17:59:47 --> Controller Class Initialized
INFO - 2018-05-08 17:59:47 --> Model Class Initialized
INFO - 2018-05-08 17:59:47 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 17:59:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 17:59:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 17:59:47 --> Model Class Initialized
INFO - 2018-05-08 17:59:47 --> Model Class Initialized
INFO - 2018-05-08 17:59:47 --> Model Class Initialized
INFO - 2018-05-08 17:59:47 --> Model Class Initialized
INFO - 2018-05-08 17:59:47 --> Final output sent to browser
DEBUG - 2018-05-08 17:59:47 --> Total execution time: 0.1033
INFO - 2018-05-08 12:29:54 --> Config Class Initialized
INFO - 2018-05-08 12:29:54 --> Hooks Class Initialized
DEBUG - 2018-05-08 12:29:54 --> UTF-8 Support Enabled
INFO - 2018-05-08 12:29:54 --> Utf8 Class Initialized
INFO - 2018-05-08 12:29:54 --> URI Class Initialized
INFO - 2018-05-08 12:29:54 --> Router Class Initialized
INFO - 2018-05-08 12:29:54 --> Output Class Initialized
INFO - 2018-05-08 12:29:54 --> Security Class Initialized
DEBUG - 2018-05-08 12:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 12:29:54 --> Input Class Initialized
INFO - 2018-05-08 12:29:54 --> Language Class Initialized
INFO - 2018-05-08 12:29:54 --> Language Class Initialized
INFO - 2018-05-08 12:29:54 --> Config Class Initialized
INFO - 2018-05-08 12:29:54 --> Loader Class Initialized
INFO - 2018-05-08 17:59:54 --> Helper loaded: url_helper
INFO - 2018-05-08 17:59:54 --> Helper loaded: notification_helper
INFO - 2018-05-08 17:59:54 --> Helper loaded: settings_helper
INFO - 2018-05-08 17:59:54 --> Helper loaded: permission_helper
INFO - 2018-05-08 17:59:54 --> Helper loaded: users_helper
INFO - 2018-05-08 17:59:54 --> Database Driver Class Initialized
DEBUG - 2018-05-08 17:59:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-08 17:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 17:59:54 --> Helper loaded: form_helper
INFO - 2018-05-08 17:59:54 --> Form Validation Class Initialized
INFO - 2018-05-08 17:59:54 --> Controller Class Initialized
INFO - 2018-05-08 17:59:54 --> Model Class Initialized
INFO - 2018-05-08 17:59:54 --> Helper loaded: inflector_helper
DEBUG - 2018-05-08 17:59:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-08 17:59:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-08 17:59:54 --> Model Class Initialized
INFO - 2018-05-08 17:59:54 --> Model Class Initialized
INFO - 2018-05-08 17:59:54 --> Model Class Initialized
INFO - 2018-05-08 17:59:54 --> Model Class Initialized
INFO - 2018-05-08 17:59:54 --> Model Class Initialized
INFO - 2018-05-08 17:59:54 --> Model Class Initialized
INFO - 2018-05-08 17:59:54 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-05-08 17:59:54 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 800
INFO - 2018-05-08 17:59:54 --> Final output sent to browser
DEBUG - 2018-05-08 17:59:54 --> Total execution time: 0.1267
