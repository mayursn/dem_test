<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-03-02 10:23:42 --> Config Class Initialized
INFO - 2018-03-02 10:23:42 --> Hooks Class Initialized
DEBUG - 2018-03-02 10:23:42 --> UTF-8 Support Enabled
INFO - 2018-03-02 10:23:42 --> Utf8 Class Initialized
INFO - 2018-03-02 10:23:42 --> URI Class Initialized
INFO - 2018-03-02 10:23:43 --> Router Class Initialized
INFO - 2018-03-02 10:23:43 --> Output Class Initialized
INFO - 2018-03-02 10:23:43 --> Config Class Initialized
INFO - 2018-03-02 10:23:43 --> Hooks Class Initialized
INFO - 2018-03-02 10:23:43 --> Security Class Initialized
DEBUG - 2018-03-02 10:23:43 --> UTF-8 Support Enabled
INFO - 2018-03-02 10:23:43 --> Utf8 Class Initialized
INFO - 2018-03-02 10:23:43 --> URI Class Initialized
DEBUG - 2018-03-02 10:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-02 10:23:43 --> Input Class Initialized
INFO - 2018-03-02 10:23:43 --> Router Class Initialized
INFO - 2018-03-02 10:23:43 --> Language Class Initialized
INFO - 2018-03-02 10:23:43 --> Output Class Initialized
INFO - 2018-03-02 10:23:43 --> Security Class Initialized
DEBUG - 2018-03-02 10:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-02 10:23:43 --> Input Class Initialized
INFO - 2018-03-02 10:23:44 --> Language Class Initialized
INFO - 2018-03-02 10:23:44 --> Language Class Initialized
INFO - 2018-03-02 10:23:44 --> Config Class Initialized
INFO - 2018-03-02 10:23:44 --> Loader Class Initialized
INFO - 2018-03-02 15:53:44 --> Helper loaded: url_helper
INFO - 2018-03-02 15:53:44 --> Helper loaded: notification_helper
INFO - 2018-03-02 15:53:44 --> Helper loaded: settings_helper
INFO - 2018-03-02 15:53:44 --> Helper loaded: permission_helper
INFO - 2018-03-02 15:53:44 --> Helper loaded: users_helper
INFO - 2018-03-02 15:53:44 --> Database Driver Class Initialized
DEBUG - 2018-03-02 15:53:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-02 15:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-02 15:53:44 --> Helper loaded: form_helper
INFO - 2018-03-02 15:53:44 --> Form Validation Class Initialized
INFO - 2018-03-02 15:53:44 --> Controller Class Initialized
INFO - 2018-03-02 15:53:44 --> Model Class Initialized
INFO - 2018-03-02 15:53:44 --> Helper loaded: inflector_helper
DEBUG - 2018-03-02 15:53:44 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-02 15:53:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-02 15:53:44 --> Model Class Initialized
INFO - 2018-03-02 15:53:44 --> Model Class Initialized
INFO - 2018-03-02 15:53:44 --> Model Class Initialized
INFO - 2018-03-02 15:53:44 --> Model Class Initialized
INFO - 2018-03-02 15:53:44 --> Model Class Initialized
INFO - 2018-03-02 15:53:44 --> Model Class Initialized
INFO - 2018-03-02 15:53:44 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-02 15:53:44 --> Final output sent to browser
DEBUG - 2018-03-02 15:53:44 --> Total execution time: 1.1031
INFO - 2018-03-02 10:23:45 --> Language Class Initialized
INFO - 2018-03-02 10:23:45 --> Config Class Initialized
INFO - 2018-03-02 10:23:45 --> Loader Class Initialized
INFO - 2018-03-02 15:53:45 --> Helper loaded: url_helper
INFO - 2018-03-02 15:53:45 --> Helper loaded: notification_helper
INFO - 2018-03-02 15:53:45 --> Helper loaded: settings_helper
INFO - 2018-03-02 15:53:45 --> Helper loaded: permission_helper
INFO - 2018-03-02 15:53:45 --> Helper loaded: users_helper
INFO - 2018-03-02 10:23:45 --> Config Class Initialized
INFO - 2018-03-02 10:23:45 --> Hooks Class Initialized
DEBUG - 2018-03-02 10:23:45 --> UTF-8 Support Enabled
INFO - 2018-03-02 10:23:45 --> Utf8 Class Initialized
INFO - 2018-03-02 10:23:45 --> URI Class Initialized
INFO - 2018-03-02 10:23:45 --> Router Class Initialized
INFO - 2018-03-02 10:23:45 --> Output Class Initialized
INFO - 2018-03-02 10:23:45 --> Security Class Initialized
DEBUG - 2018-03-02 10:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-02 10:23:45 --> Input Class Initialized
INFO - 2018-03-02 10:23:45 --> Language Class Initialized
INFO - 2018-03-02 10:23:46 --> Language Class Initialized
INFO - 2018-03-02 10:23:46 --> Config Class Initialized
INFO - 2018-03-02 10:23:46 --> Loader Class Initialized
INFO - 2018-03-02 15:53:46 --> Helper loaded: url_helper
INFO - 2018-03-02 15:53:46 --> Helper loaded: notification_helper
INFO - 2018-03-02 15:53:46 --> Helper loaded: settings_helper
INFO - 2018-03-02 15:53:46 --> Helper loaded: permission_helper
INFO - 2018-03-02 15:53:46 --> Helper loaded: users_helper
INFO - 2018-03-02 15:53:46 --> Database Driver Class Initialized
DEBUG - 2018-03-02 15:53:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-02 15:53:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-02 15:53:46 --> Helper loaded: form_helper
INFO - 2018-03-02 15:53:46 --> Form Validation Class Initialized
INFO - 2018-03-02 15:53:46 --> Controller Class Initialized
INFO - 2018-03-02 15:53:46 --> Model Class Initialized
INFO - 2018-03-02 15:53:46 --> Database Driver Class Initialized
INFO - 2018-03-02 15:53:46 --> Helper loaded: inflector_helper
DEBUG - 2018-03-02 15:53:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-02 15:53:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-02 15:53:46 --> Model Class Initialized
INFO - 2018-03-02 15:53:46 --> Model Class Initialized
INFO - 2018-03-02 15:53:46 --> Model Class Initialized
INFO - 2018-03-02 15:53:46 --> Model Class Initialized
INFO - 2018-03-02 15:53:46 --> Model Class Initialized
INFO - 2018-03-02 15:53:46 --> Model Class Initialized
INFO - 2018-03-02 15:53:46 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-02 15:53:46 --> Final output sent to browser
DEBUG - 2018-03-02 15:53:46 --> Total execution time: 0.5989
INFO - 2018-03-02 10:23:46 --> Config Class Initialized
INFO - 2018-03-02 10:23:46 --> Hooks Class Initialized
DEBUG - 2018-03-02 10:23:46 --> UTF-8 Support Enabled
INFO - 2018-03-02 10:23:46 --> Utf8 Class Initialized
INFO - 2018-03-02 10:23:46 --> URI Class Initialized
INFO - 2018-03-02 10:23:46 --> Config Class Initialized
INFO - 2018-03-02 10:23:46 --> Hooks Class Initialized
INFO - 2018-03-02 10:23:46 --> Router Class Initialized
INFO - 2018-03-02 10:23:46 --> Output Class Initialized
DEBUG - 2018-03-02 10:23:46 --> UTF-8 Support Enabled
INFO - 2018-03-02 10:23:46 --> Utf8 Class Initialized
INFO - 2018-03-02 10:23:46 --> Security Class Initialized
DEBUG - 2018-03-02 10:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-02 10:23:46 --> Input Class Initialized
INFO - 2018-03-02 10:23:46 --> Language Class Initialized
INFO - 2018-03-02 10:23:46 --> URI Class Initialized
INFO - 2018-03-02 10:23:46 --> Config Class Initialized
INFO - 2018-03-02 10:23:46 --> Hooks Class Initialized
INFO - 2018-03-02 10:23:46 --> Language Class Initialized
INFO - 2018-03-02 10:23:46 --> Config Class Initialized
INFO - 2018-03-02 10:23:46 --> Loader Class Initialized
INFO - 2018-03-02 15:53:46 --> Helper loaded: url_helper
DEBUG - 2018-03-02 10:23:46 --> UTF-8 Support Enabled
INFO - 2018-03-02 10:23:46 --> Utf8 Class Initialized
INFO - 2018-03-02 10:23:46 --> Router Class Initialized
INFO - 2018-03-02 15:53:46 --> Helper loaded: notification_helper
INFO - 2018-03-02 15:53:46 --> Helper loaded: settings_helper
INFO - 2018-03-02 10:23:46 --> URI Class Initialized
INFO - 2018-03-02 15:53:46 --> Helper loaded: permission_helper
INFO - 2018-03-02 15:53:46 --> Helper loaded: users_helper
INFO - 2018-03-02 10:23:46 --> Output Class Initialized
INFO - 2018-03-02 10:23:46 --> Router Class Initialized
INFO - 2018-03-02 10:23:46 --> Security Class Initialized
DEBUG - 2018-03-02 10:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-02 10:23:46 --> Input Class Initialized
INFO - 2018-03-02 10:23:46 --> Output Class Initialized
INFO - 2018-03-02 10:23:46 --> Language Class Initialized
INFO - 2018-03-02 10:23:46 --> Security Class Initialized
DEBUG - 2018-03-02 15:53:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-02 10:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-02 10:23:46 --> Input Class Initialized
INFO - 2018-03-02 10:23:46 --> Language Class Initialized
INFO - 2018-03-02 15:53:46 --> Database Driver Class Initialized
INFO - 2018-03-02 15:53:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-03-02 15:53:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-02 15:53:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-02 10:23:46 --> Language Class Initialized
INFO - 2018-03-02 10:23:46 --> Config Class Initialized
INFO - 2018-03-02 10:23:46 --> Loader Class Initialized
INFO - 2018-03-02 15:53:46 --> Helper loaded: url_helper
INFO - 2018-03-02 15:53:46 --> Helper loaded: notification_helper
INFO - 2018-03-02 15:53:46 --> Helper loaded: settings_helper
INFO - 2018-03-02 15:53:46 --> Helper loaded: permission_helper
INFO - 2018-03-02 10:23:46 --> Language Class Initialized
INFO - 2018-03-02 10:23:46 --> Config Class Initialized
INFO - 2018-03-02 10:23:46 --> Loader Class Initialized
INFO - 2018-03-02 15:53:46 --> Helper loaded: form_helper
INFO - 2018-03-02 15:53:46 --> Form Validation Class Initialized
INFO - 2018-03-02 15:53:46 --> Controller Class Initialized
INFO - 2018-03-02 15:53:46 --> Helper loaded: users_helper
INFO - 2018-03-02 15:53:46 --> Helper loaded: url_helper
INFO - 2018-03-02 15:53:46 --> Helper loaded: notification_helper
INFO - 2018-03-02 15:53:46 --> Helper loaded: settings_helper
INFO - 2018-03-02 15:53:46 --> Helper loaded: permission_helper
INFO - 2018-03-02 15:53:46 --> Helper loaded: users_helper
INFO - 2018-03-02 15:53:46 --> Model Class Initialized
INFO - 2018-03-02 15:53:46 --> Helper loaded: inflector_helper
DEBUG - 2018-03-02 15:53:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-02 15:53:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-02 15:53:46 --> Model Class Initialized
INFO - 2018-03-02 15:53:46 --> Model Class Initialized
INFO - 2018-03-02 15:53:46 --> Database Driver Class Initialized
INFO - 2018-03-02 15:53:46 --> Model Class Initialized
INFO - 2018-03-02 15:53:46 --> Model Class Initialized
INFO - 2018-03-02 15:53:46 --> Model Class Initialized
INFO - 2018-03-02 15:53:46 --> Model Class Initialized
INFO - 2018-03-02 15:53:46 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-03-02 15:53:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-02 15:53:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-02 15:53:46 --> Model Class Initialized
INFO - 2018-03-02 15:53:46 --> Database Driver Class Initialized
INFO - 2018-03-02 15:53:46 --> Final output sent to browser
DEBUG - 2018-03-02 15:53:46 --> Total execution time: 0.4687
DEBUG - 2018-03-02 15:53:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-02 15:53:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-02 15:53:47 --> Helper loaded: form_helper
INFO - 2018-03-02 15:53:47 --> Form Validation Class Initialized
INFO - 2018-03-02 15:53:47 --> Controller Class Initialized
INFO - 2018-03-02 15:53:47 --> Helper loaded: form_helper
INFO - 2018-03-02 15:53:47 --> Form Validation Class Initialized
INFO - 2018-03-02 15:53:47 --> Controller Class Initialized
INFO - 2018-03-02 15:53:47 --> Model Class Initialized
INFO - 2018-03-02 15:53:47 --> Helper loaded: inflector_helper
DEBUG - 2018-03-02 15:53:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-02 15:53:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-02 15:53:47 --> Model Class Initialized
INFO - 2018-03-02 15:53:47 --> Helper loaded: inflector_helper
INFO - 2018-03-02 15:53:47 --> Model Class Initialized
INFO - 2018-03-02 15:53:47 --> Model Class Initialized
DEBUG - 2018-03-02 15:53:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-02 15:53:47 --> Model Class Initialized
INFO - 2018-03-02 15:53:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-02 15:53:47 --> Model Class Initialized
INFO - 2018-03-02 15:53:47 --> Model Class Initialized
INFO - 2018-03-02 15:53:47 --> Model Class Initialized
INFO - 2018-03-02 15:53:47 --> Model Class Initialized
INFO - 2018-03-02 15:53:47 --> Model Class Initialized
INFO - 2018-03-02 15:53:47 --> Model Class Initialized
INFO - 2018-03-02 15:53:47 --> Model Class Initialized
INFO - 2018-03-02 15:53:47 --> Model Class Initialized
INFO - 2018-03-02 15:53:47 --> Model Class Initialized
INFO - 2018-03-02 15:53:47 --> Model Class Initialized
INFO - 2018-03-02 15:53:47 --> Model Class Initialized
INFO - 2018-03-02 15:53:47 --> Model Class Initialized
INFO - 2018-03-02 15:53:47 --> Model Class Initialized
INFO - 2018-03-02 15:53:47 --> Model Class Initialized
INFO - 2018-03-02 15:53:47 --> Model Class Initialized
INFO - 2018-03-02 15:53:47 --> Model Class Initialized
INFO - 2018-03-02 15:53:47 --> Model Class Initialized
INFO - 2018-03-02 15:53:47 --> Model Class Initialized
INFO - 2018-03-02 15:53:47 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-02 15:53:47 --> Model Class Initialized
INFO - 2018-03-02 15:53:47 --> Model Class Initialized
INFO - 2018-03-02 15:53:47 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-02 15:53:47 --> Model Class Initialized
INFO - 2018-03-02 15:53:47 --> Final output sent to browser
DEBUG - 2018-03-02 15:53:47 --> Total execution time: 0.6499
INFO - 2018-03-02 15:53:47 --> Final output sent to browser
DEBUG - 2018-03-02 15:53:47 --> Total execution time: 0.7238
INFO - 2018-03-02 15:53:47 --> Helper loaded: form_helper
INFO - 2018-03-02 15:53:47 --> Form Validation Class Initialized
INFO - 2018-03-02 15:53:47 --> Controller Class Initialized
INFO - 2018-03-02 15:53:47 --> Model Class Initialized
INFO - 2018-03-02 15:53:47 --> Helper loaded: inflector_helper
DEBUG - 2018-03-02 15:53:48 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-02 15:53:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-02 15:53:48 --> Model Class Initialized
INFO - 2018-03-02 15:53:48 --> Model Class Initialized
INFO - 2018-03-02 15:53:48 --> Model Class Initialized
INFO - 2018-03-02 15:53:48 --> Model Class Initialized
INFO - 2018-03-02 15:53:48 --> Model Class Initialized
INFO - 2018-03-02 15:53:48 --> Model Class Initialized
INFO - 2018-03-02 15:53:48 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-02 15:53:48 --> Final output sent to browser
DEBUG - 2018-03-02 15:53:48 --> Total execution time: 6.3998
INFO - 2018-03-02 10:23:48 --> Config Class Initialized
INFO - 2018-03-02 10:23:48 --> Hooks Class Initialized
DEBUG - 2018-03-02 10:23:48 --> UTF-8 Support Enabled
INFO - 2018-03-02 10:23:48 --> Utf8 Class Initialized
INFO - 2018-03-02 10:23:48 --> Config Class Initialized
INFO - 2018-03-02 10:23:48 --> Hooks Class Initialized
DEBUG - 2018-03-02 10:23:48 --> UTF-8 Support Enabled
INFO - 2018-03-02 10:23:48 --> Utf8 Class Initialized
INFO - 2018-03-02 10:23:48 --> URI Class Initialized
INFO - 2018-03-02 10:23:48 --> Router Class Initialized
INFO - 2018-03-02 10:23:48 --> Output Class Initialized
INFO - 2018-03-02 10:23:49 --> URI Class Initialized
INFO - 2018-03-02 10:23:49 --> Security Class Initialized
DEBUG - 2018-03-02 10:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-02 10:23:49 --> Input Class Initialized
INFO - 2018-03-02 10:23:49 --> Language Class Initialized
INFO - 2018-03-02 10:23:49 --> Router Class Initialized
INFO - 2018-03-02 10:23:49 --> Language Class Initialized
INFO - 2018-03-02 10:23:49 --> Config Class Initialized
INFO - 2018-03-02 10:23:49 --> Loader Class Initialized
INFO - 2018-03-02 15:53:49 --> Helper loaded: url_helper
INFO - 2018-03-02 15:53:49 --> Helper loaded: notification_helper
INFO - 2018-03-02 15:53:49 --> Helper loaded: settings_helper
INFO - 2018-03-02 15:53:49 --> Helper loaded: permission_helper
INFO - 2018-03-02 15:53:49 --> Helper loaded: users_helper
INFO - 2018-03-02 10:23:49 --> Output Class Initialized
INFO - 2018-03-02 15:53:49 --> Database Driver Class Initialized
DEBUG - 2018-03-02 15:53:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-02 15:53:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-02 10:23:49 --> Security Class Initialized
INFO - 2018-03-02 15:53:49 --> Helper loaded: form_helper
INFO - 2018-03-02 15:53:49 --> Form Validation Class Initialized
INFO - 2018-03-02 15:53:49 --> Controller Class Initialized
INFO - 2018-03-02 15:53:49 --> Model Class Initialized
INFO - 2018-03-02 15:53:49 --> Helper loaded: inflector_helper
DEBUG - 2018-03-02 10:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-02 10:23:49 --> Input Class Initialized
DEBUG - 2018-03-02 15:53:49 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-02 15:53:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-02 15:53:49 --> Model Class Initialized
INFO - 2018-03-02 15:53:49 --> Model Class Initialized
INFO - 2018-03-02 15:53:49 --> Model Class Initialized
INFO - 2018-03-02 15:53:49 --> Model Class Initialized
INFO - 2018-03-02 15:53:49 --> Model Class Initialized
INFO - 2018-03-02 15:53:49 --> Model Class Initialized
INFO - 2018-03-02 15:53:49 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-02 10:23:49 --> Language Class Initialized
INFO - 2018-03-02 15:53:49 --> Model Class Initialized
INFO - 2018-03-02 15:53:49 --> Final output sent to browser
DEBUG - 2018-03-02 15:53:49 --> Total execution time: 0.3370
INFO - 2018-03-02 10:23:49 --> Language Class Initialized
INFO - 2018-03-02 10:23:49 --> Config Class Initialized
INFO - 2018-03-02 10:23:49 --> Loader Class Initialized
INFO - 2018-03-02 15:53:49 --> Helper loaded: url_helper
INFO - 2018-03-02 15:53:49 --> Helper loaded: notification_helper
INFO - 2018-03-02 15:53:49 --> Helper loaded: settings_helper
INFO - 2018-03-02 15:53:49 --> Helper loaded: permission_helper
INFO - 2018-03-02 15:53:49 --> Helper loaded: users_helper
INFO - 2018-03-02 15:53:49 --> Database Driver Class Initialized
DEBUG - 2018-03-02 15:53:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-02 15:53:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-02 15:53:49 --> Helper loaded: form_helper
INFO - 2018-03-02 15:53:49 --> Form Validation Class Initialized
INFO - 2018-03-02 15:53:49 --> Controller Class Initialized
INFO - 2018-03-02 15:53:49 --> Model Class Initialized
INFO - 2018-03-02 15:53:49 --> Helper loaded: inflector_helper
DEBUG - 2018-03-02 15:53:49 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-02 15:53:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-02 15:53:49 --> Model Class Initialized
INFO - 2018-03-02 15:53:49 --> Model Class Initialized
INFO - 2018-03-02 15:53:50 --> Model Class Initialized
INFO - 2018-03-02 15:53:50 --> Model Class Initialized
INFO - 2018-03-02 15:53:50 --> Model Class Initialized
INFO - 2018-03-02 15:53:50 --> Model Class Initialized
INFO - 2018-03-02 15:53:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-02 15:53:50 --> Model Class Initialized
INFO - 2018-03-02 15:53:50 --> Final output sent to browser
DEBUG - 2018-03-02 15:53:50 --> Total execution time: 1.9227
INFO - 2018-03-02 10:23:53 --> Config Class Initialized
INFO - 2018-03-02 10:23:53 --> Hooks Class Initialized
DEBUG - 2018-03-02 10:23:53 --> UTF-8 Support Enabled
INFO - 2018-03-02 10:23:53 --> Utf8 Class Initialized
INFO - 2018-03-02 10:23:53 --> URI Class Initialized
INFO - 2018-03-02 10:23:53 --> Router Class Initialized
INFO - 2018-03-02 10:23:53 --> Output Class Initialized
INFO - 2018-03-02 10:23:53 --> Security Class Initialized
DEBUG - 2018-03-02 10:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-02 10:23:53 --> Input Class Initialized
INFO - 2018-03-02 10:23:53 --> Language Class Initialized
INFO - 2018-03-02 10:23:53 --> Language Class Initialized
INFO - 2018-03-02 10:23:53 --> Config Class Initialized
INFO - 2018-03-02 10:23:53 --> Loader Class Initialized
INFO - 2018-03-02 15:53:53 --> Helper loaded: url_helper
INFO - 2018-03-02 15:53:53 --> Helper loaded: notification_helper
INFO - 2018-03-02 15:53:53 --> Helper loaded: settings_helper
INFO - 2018-03-02 15:53:53 --> Helper loaded: permission_helper
INFO - 2018-03-02 15:53:53 --> Helper loaded: users_helper
INFO - 2018-03-02 15:53:53 --> Database Driver Class Initialized
DEBUG - 2018-03-02 15:53:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-02 15:53:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-02 15:53:53 --> Helper loaded: form_helper
INFO - 2018-03-02 15:53:53 --> Form Validation Class Initialized
INFO - 2018-03-02 15:53:53 --> Controller Class Initialized
INFO - 2018-03-02 15:53:53 --> Model Class Initialized
INFO - 2018-03-02 15:53:53 --> Helper loaded: inflector_helper
DEBUG - 2018-03-02 15:53:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-02 15:53:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-02 15:53:53 --> Model Class Initialized
INFO - 2018-03-02 15:53:53 --> Model Class Initialized
INFO - 2018-03-02 15:53:53 --> Model Class Initialized
INFO - 2018-03-02 15:53:53 --> Model Class Initialized
INFO - 2018-03-02 15:53:53 --> Final output sent to browser
DEBUG - 2018-03-02 15:53:53 --> Total execution time: 0.3447
INFO - 2018-03-02 10:23:55 --> Config Class Initialized
INFO - 2018-03-02 10:23:55 --> Hooks Class Initialized
DEBUG - 2018-03-02 10:23:55 --> UTF-8 Support Enabled
INFO - 2018-03-02 10:23:55 --> Utf8 Class Initialized
INFO - 2018-03-02 10:23:55 --> URI Class Initialized
INFO - 2018-03-02 10:23:55 --> Router Class Initialized
INFO - 2018-03-02 10:23:55 --> Output Class Initialized
INFO - 2018-03-02 10:23:55 --> Security Class Initialized
DEBUG - 2018-03-02 10:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-02 10:23:55 --> Input Class Initialized
INFO - 2018-03-02 10:23:55 --> Language Class Initialized
INFO - 2018-03-02 10:23:56 --> Language Class Initialized
INFO - 2018-03-02 10:23:56 --> Config Class Initialized
INFO - 2018-03-02 10:23:56 --> Loader Class Initialized
INFO - 2018-03-02 15:53:56 --> Helper loaded: url_helper
INFO - 2018-03-02 15:53:56 --> Helper loaded: notification_helper
INFO - 2018-03-02 15:53:56 --> Helper loaded: settings_helper
INFO - 2018-03-02 15:53:56 --> Helper loaded: permission_helper
INFO - 2018-03-02 10:23:56 --> Config Class Initialized
INFO - 2018-03-02 10:23:56 --> Hooks Class Initialized
DEBUG - 2018-03-02 10:23:56 --> UTF-8 Support Enabled
INFO - 2018-03-02 10:23:56 --> Utf8 Class Initialized
INFO - 2018-03-02 10:23:56 --> URI Class Initialized
INFO - 2018-03-02 15:53:56 --> Helper loaded: users_helper
INFO - 2018-03-02 10:23:56 --> Router Class Initialized
INFO - 2018-03-02 10:23:56 --> Output Class Initialized
INFO - 2018-03-02 10:23:56 --> Security Class Initialized
DEBUG - 2018-03-02 10:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-02 10:23:56 --> Input Class Initialized
INFO - 2018-03-02 10:23:56 --> Language Class Initialized
INFO - 2018-03-02 10:23:56 --> Language Class Initialized
INFO - 2018-03-02 10:23:56 --> Config Class Initialized
INFO - 2018-03-02 10:23:56 --> Loader Class Initialized
INFO - 2018-03-02 15:53:56 --> Helper loaded: url_helper
INFO - 2018-03-02 15:53:56 --> Helper loaded: notification_helper
INFO - 2018-03-02 15:53:56 --> Helper loaded: settings_helper
INFO - 2018-03-02 15:53:56 --> Helper loaded: permission_helper
INFO - 2018-03-02 15:53:56 --> Helper loaded: users_helper
INFO - 2018-03-02 15:53:56 --> Database Driver Class Initialized
DEBUG - 2018-03-02 15:53:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-02 15:53:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-02 15:53:56 --> Helper loaded: form_helper
INFO - 2018-03-02 15:53:56 --> Form Validation Class Initialized
INFO - 2018-03-02 15:53:56 --> Controller Class Initialized
INFO - 2018-03-02 15:53:56 --> Model Class Initialized
INFO - 2018-03-02 15:53:56 --> Helper loaded: inflector_helper
DEBUG - 2018-03-02 15:53:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-02 15:53:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-02 15:53:56 --> Model Class Initialized
INFO - 2018-03-02 15:53:56 --> Model Class Initialized
INFO - 2018-03-02 15:53:56 --> Model Class Initialized
INFO - 2018-03-02 15:53:56 --> Model Class Initialized
INFO - 2018-03-02 15:53:56 --> Final output sent to browser
DEBUG - 2018-03-02 15:53:56 --> Total execution time: 0.2556
INFO - 2018-03-02 15:53:56 --> Database Driver Class Initialized
DEBUG - 2018-03-02 15:53:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-02 15:53:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-02 15:53:57 --> Helper loaded: form_helper
INFO - 2018-03-02 15:53:57 --> Form Validation Class Initialized
INFO - 2018-03-02 15:53:57 --> Controller Class Initialized
INFO - 2018-03-02 15:53:58 --> Model Class Initialized
INFO - 2018-03-02 15:53:58 --> Helper loaded: inflector_helper
DEBUG - 2018-03-02 15:53:58 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-02 15:53:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-02 15:53:58 --> Model Class Initialized
INFO - 2018-03-02 15:53:58 --> Model Class Initialized
INFO - 2018-03-02 15:53:58 --> Model Class Initialized
INFO - 2018-03-02 15:53:58 --> Model Class Initialized
INFO - 2018-03-02 15:53:58 --> Final output sent to browser
DEBUG - 2018-03-02 15:53:58 --> Total execution time: 3.6665
INFO - 2018-03-02 10:24:04 --> Config Class Initialized
INFO - 2018-03-02 10:24:04 --> Hooks Class Initialized
DEBUG - 2018-03-02 10:24:04 --> UTF-8 Support Enabled
INFO - 2018-03-02 10:24:04 --> Utf8 Class Initialized
INFO - 2018-03-02 10:24:04 --> URI Class Initialized
INFO - 2018-03-02 10:24:04 --> Router Class Initialized
INFO - 2018-03-02 10:24:04 --> Output Class Initialized
INFO - 2018-03-02 10:24:04 --> Security Class Initialized
DEBUG - 2018-03-02 10:24:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-02 10:24:04 --> Input Class Initialized
INFO - 2018-03-02 10:24:04 --> Language Class Initialized
INFO - 2018-03-02 10:24:04 --> Language Class Initialized
INFO - 2018-03-02 10:24:04 --> Config Class Initialized
INFO - 2018-03-02 10:24:04 --> Loader Class Initialized
INFO - 2018-03-02 15:54:04 --> Helper loaded: url_helper
INFO - 2018-03-02 15:54:04 --> Helper loaded: notification_helper
INFO - 2018-03-02 15:54:04 --> Helper loaded: settings_helper
INFO - 2018-03-02 15:54:04 --> Helper loaded: permission_helper
INFO - 2018-03-02 15:54:04 --> Helper loaded: users_helper
INFO - 2018-03-02 15:54:04 --> Database Driver Class Initialized
DEBUG - 2018-03-02 15:54:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-02 15:54:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-02 15:54:04 --> Helper loaded: form_helper
INFO - 2018-03-02 15:54:04 --> Form Validation Class Initialized
INFO - 2018-03-02 15:54:04 --> Controller Class Initialized
INFO - 2018-03-02 15:54:04 --> Model Class Initialized
INFO - 2018-03-02 15:54:04 --> Helper loaded: inflector_helper
DEBUG - 2018-03-02 15:54:04 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-02 15:54:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-02 15:54:04 --> Model Class Initialized
INFO - 2018-03-02 15:54:04 --> Model Class Initialized
INFO - 2018-03-02 15:54:04 --> Model Class Initialized
INFO - 2018-03-02 15:54:04 --> Model Class Initialized
INFO - 2018-03-02 15:54:04 --> Model Class Initialized
INFO - 2018-03-02 15:54:04 --> Model Class Initialized
INFO - 2018-03-02 15:54:04 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-02 15:54:04 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-02 15:54:04 --> Final output sent to browser
DEBUG - 2018-03-02 15:54:04 --> Total execution time: 0.1237
INFO - 2018-03-02 10:24:04 --> Config Class Initialized
INFO - 2018-03-02 10:24:04 --> Hooks Class Initialized
DEBUG - 2018-03-02 10:24:05 --> UTF-8 Support Enabled
INFO - 2018-03-02 10:24:05 --> Utf8 Class Initialized
INFO - 2018-03-02 10:24:05 --> URI Class Initialized
INFO - 2018-03-02 10:24:05 --> Router Class Initialized
INFO - 2018-03-02 10:24:05 --> Output Class Initialized
INFO - 2018-03-02 10:24:05 --> Security Class Initialized
DEBUG - 2018-03-02 10:24:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-02 10:24:05 --> Input Class Initialized
INFO - 2018-03-02 10:24:06 --> Language Class Initialized
INFO - 2018-03-02 10:24:07 --> Language Class Initialized
INFO - 2018-03-02 10:24:07 --> Config Class Initialized
INFO - 2018-03-02 10:24:07 --> Loader Class Initialized
INFO - 2018-03-02 15:54:07 --> Helper loaded: url_helper
INFO - 2018-03-02 15:54:07 --> Helper loaded: notification_helper
INFO - 2018-03-02 15:54:07 --> Helper loaded: settings_helper
INFO - 2018-03-02 15:54:07 --> Helper loaded: permission_helper
INFO - 2018-03-02 15:54:07 --> Helper loaded: users_helper
INFO - 2018-03-02 15:54:07 --> Database Driver Class Initialized
DEBUG - 2018-03-02 15:54:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-02 15:54:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-02 15:54:07 --> Helper loaded: form_helper
INFO - 2018-03-02 15:54:07 --> Form Validation Class Initialized
INFO - 2018-03-02 15:54:07 --> Controller Class Initialized
INFO - 2018-03-02 15:54:07 --> Model Class Initialized
INFO - 2018-03-02 15:54:07 --> Helper loaded: inflector_helper
DEBUG - 2018-03-02 15:54:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-02 15:54:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-02 15:54:07 --> Model Class Initialized
INFO - 2018-03-02 15:54:07 --> Model Class Initialized
INFO - 2018-03-02 15:54:07 --> Model Class Initialized
INFO - 2018-03-02 15:54:07 --> Model Class Initialized
INFO - 2018-03-02 15:54:07 --> Model Class Initialized
INFO - 2018-03-02 15:54:07 --> Model Class Initialized
INFO - 2018-03-02 15:54:07 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-02 15:54:07 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-02 15:54:07 --> Final output sent to browser
DEBUG - 2018-03-02 15:54:07 --> Total execution time: 3.4832
