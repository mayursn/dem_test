<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-03-31 06:06:18 --> Config Class Initialized
INFO - 2018-03-31 06:06:18 --> Hooks Class Initialized
DEBUG - 2018-03-31 06:06:18 --> UTF-8 Support Enabled
INFO - 2018-03-31 06:06:18 --> Utf8 Class Initialized
INFO - 2018-03-31 06:06:18 --> URI Class Initialized
INFO - 2018-03-31 06:06:18 --> Router Class Initialized
INFO - 2018-03-31 06:06:18 --> Output Class Initialized
INFO - 2018-03-31 06:06:18 --> Security Class Initialized
DEBUG - 2018-03-31 06:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 06:06:18 --> Input Class Initialized
INFO - 2018-03-31 06:06:18 --> Language Class Initialized
INFO - 2018-03-31 06:06:18 --> Language Class Initialized
INFO - 2018-03-31 06:06:18 --> Config Class Initialized
INFO - 2018-03-31 06:06:18 --> Loader Class Initialized
INFO - 2018-03-31 11:36:18 --> Helper loaded: url_helper
INFO - 2018-03-31 11:36:18 --> Helper loaded: notification_helper
INFO - 2018-03-31 11:36:18 --> Helper loaded: settings_helper
INFO - 2018-03-31 11:36:18 --> Helper loaded: permission_helper
INFO - 2018-03-31 11:36:18 --> Helper loaded: users_helper
INFO - 2018-03-31 11:36:18 --> Database Driver Class Initialized
DEBUG - 2018-03-31 11:36:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 11:36:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 11:36:18 --> Helper loaded: form_helper
INFO - 2018-03-31 11:36:18 --> Form Validation Class Initialized
INFO - 2018-03-31 11:36:18 --> Controller Class Initialized
INFO - 2018-03-31 11:36:18 --> Model Class Initialized
INFO - 2018-03-31 11:36:18 --> Helper loaded: inflector_helper
DEBUG - 2018-03-31 11:36:18 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-31 11:36:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-31 11:36:18 --> Model Class Initialized
INFO - 2018-03-31 11:36:18 --> Model Class Initialized
INFO - 2018-03-31 11:36:18 --> Model Class Initialized
INFO - 2018-03-31 11:36:18 --> Model Class Initialized
INFO - 2018-03-31 11:36:18 --> Model Class Initialized
INFO - 2018-03-31 11:36:18 --> Model Class Initialized
INFO - 2018-03-31 11:36:18 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-31 11:36:18 --> Model Class Initialized
INFO - 2018-03-31 11:36:18 --> Final output sent to browser
DEBUG - 2018-03-31 11:36:18 --> Total execution time: 0.1329
INFO - 2018-03-31 06:06:18 --> Config Class Initialized
INFO - 2018-03-31 06:06:18 --> Hooks Class Initialized
DEBUG - 2018-03-31 06:06:18 --> UTF-8 Support Enabled
INFO - 2018-03-31 06:06:18 --> Utf8 Class Initialized
INFO - 2018-03-31 06:06:18 --> Config Class Initialized
INFO - 2018-03-31 06:06:18 --> Hooks Class Initialized
DEBUG - 2018-03-31 06:06:18 --> UTF-8 Support Enabled
INFO - 2018-03-31 06:06:18 --> Utf8 Class Initialized
INFO - 2018-03-31 06:06:18 --> URI Class Initialized
INFO - 2018-03-31 06:06:18 --> Router Class Initialized
INFO - 2018-03-31 06:06:18 --> URI Class Initialized
INFO - 2018-03-31 06:06:18 --> Output Class Initialized
INFO - 2018-03-31 06:06:18 --> Security Class Initialized
DEBUG - 2018-03-31 06:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 06:06:18 --> Input Class Initialized
INFO - 2018-03-31 06:06:18 --> Language Class Initialized
INFO - 2018-03-31 06:06:18 --> Router Class Initialized
INFO - 2018-03-31 06:06:18 --> Output Class Initialized
INFO - 2018-03-31 06:06:18 --> Config Class Initialized
INFO - 2018-03-31 06:06:18 --> Hooks Class Initialized
INFO - 2018-03-31 06:06:18 --> Language Class Initialized
INFO - 2018-03-31 06:06:18 --> Config Class Initialized
INFO - 2018-03-31 06:06:18 --> Loader Class Initialized
INFO - 2018-03-31 11:36:18 --> Helper loaded: url_helper
INFO - 2018-03-31 11:36:18 --> Helper loaded: notification_helper
INFO - 2018-03-31 06:06:18 --> Security Class Initialized
INFO - 2018-03-31 11:36:18 --> Helper loaded: settings_helper
INFO - 2018-03-31 11:36:18 --> Helper loaded: permission_helper
DEBUG - 2018-03-31 06:06:18 --> UTF-8 Support Enabled
INFO - 2018-03-31 06:06:18 --> Utf8 Class Initialized
INFO - 2018-03-31 11:36:18 --> Helper loaded: users_helper
DEBUG - 2018-03-31 06:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 06:06:18 --> Input Class Initialized
INFO - 2018-03-31 06:06:18 --> URI Class Initialized
INFO - 2018-03-31 06:06:18 --> Language Class Initialized
INFO - 2018-03-31 11:36:18 --> Database Driver Class Initialized
INFO - 2018-03-31 06:06:18 --> Config Class Initialized
INFO - 2018-03-31 06:06:18 --> Hooks Class Initialized
DEBUG - 2018-03-31 11:36:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 11:36:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 06:06:18 --> Router Class Initialized
INFO - 2018-03-31 11:36:18 --> Helper loaded: form_helper
INFO - 2018-03-31 11:36:18 --> Form Validation Class Initialized
INFO - 2018-03-31 11:36:18 --> Controller Class Initialized
DEBUG - 2018-03-31 06:06:18 --> UTF-8 Support Enabled
INFO - 2018-03-31 06:06:18 --> Utf8 Class Initialized
INFO - 2018-03-31 06:06:18 --> Output Class Initialized
INFO - 2018-03-31 06:06:18 --> URI Class Initialized
INFO - 2018-03-31 11:36:18 --> Model Class Initialized
INFO - 2018-03-31 11:36:18 --> Helper loaded: inflector_helper
INFO - 2018-03-31 06:06:18 --> Security Class Initialized
DEBUG - 2018-03-31 11:36:18 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-31 11:36:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-31 11:36:18 --> Model Class Initialized
INFO - 2018-03-31 11:36:18 --> Model Class Initialized
INFO - 2018-03-31 11:36:18 --> Model Class Initialized
INFO - 2018-03-31 11:36:18 --> Model Class Initialized
INFO - 2018-03-31 11:36:18 --> Model Class Initialized
INFO - 2018-03-31 11:36:18 --> Model Class Initialized
INFO - 2018-03-31 11:36:18 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-31 06:06:18 --> Router Class Initialized
DEBUG - 2018-03-31 06:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 06:06:18 --> Input Class Initialized
INFO - 2018-03-31 11:36:18 --> Model Class Initialized
INFO - 2018-03-31 11:36:18 --> Final output sent to browser
DEBUG - 2018-03-31 11:36:18 --> Total execution time: 0.1096
INFO - 2018-03-31 06:06:18 --> Language Class Initialized
INFO - 2018-03-31 06:06:18 --> Output Class Initialized
INFO - 2018-03-31 06:06:18 --> Language Class Initialized
INFO - 2018-03-31 06:06:18 --> Config Class Initialized
INFO - 2018-03-31 06:06:18 --> Loader Class Initialized
INFO - 2018-03-31 06:06:18 --> Security Class Initialized
INFO - 2018-03-31 11:36:19 --> Helper loaded: url_helper
DEBUG - 2018-03-31 06:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 06:06:19 --> Input Class Initialized
INFO - 2018-03-31 06:06:19 --> Language Class Initialized
INFO - 2018-03-31 11:36:19 --> Helper loaded: notification_helper
INFO - 2018-03-31 06:06:19 --> Language Class Initialized
INFO - 2018-03-31 06:06:19 --> Config Class Initialized
INFO - 2018-03-31 06:06:19 --> Loader Class Initialized
INFO - 2018-03-31 11:36:19 --> Helper loaded: url_helper
INFO - 2018-03-31 11:36:19 --> Helper loaded: notification_helper
INFO - 2018-03-31 11:36:19 --> Helper loaded: settings_helper
INFO - 2018-03-31 11:36:19 --> Helper loaded: settings_helper
INFO - 2018-03-31 11:36:19 --> Helper loaded: permission_helper
INFO - 2018-03-31 11:36:19 --> Helper loaded: permission_helper
INFO - 2018-03-31 11:36:19 --> Helper loaded: users_helper
INFO - 2018-03-31 11:36:19 --> Helper loaded: users_helper
INFO - 2018-03-31 06:06:19 --> Language Class Initialized
INFO - 2018-03-31 06:06:19 --> Config Class Initialized
INFO - 2018-03-31 06:06:19 --> Loader Class Initialized
INFO - 2018-03-31 11:36:19 --> Helper loaded: url_helper
INFO - 2018-03-31 11:36:19 --> Helper loaded: notification_helper
INFO - 2018-03-31 11:36:19 --> Helper loaded: settings_helper
INFO - 2018-03-31 11:36:19 --> Helper loaded: permission_helper
INFO - 2018-03-31 11:36:19 --> Helper loaded: users_helper
INFO - 2018-03-31 11:36:19 --> Database Driver Class Initialized
DEBUG - 2018-03-31 11:36:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 11:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 11:36:19 --> Helper loaded: form_helper
INFO - 2018-03-31 11:36:19 --> Form Validation Class Initialized
INFO - 2018-03-31 11:36:19 --> Controller Class Initialized
INFO - 2018-03-31 11:36:19 --> Model Class Initialized
INFO - 2018-03-31 11:36:19 --> Helper loaded: inflector_helper
DEBUG - 2018-03-31 11:36:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-31 11:36:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-31 11:36:19 --> Model Class Initialized
INFO - 2018-03-31 11:36:19 --> Model Class Initialized
INFO - 2018-03-31 11:36:19 --> Model Class Initialized
INFO - 2018-03-31 11:36:19 --> Model Class Initialized
INFO - 2018-03-31 11:36:19 --> Model Class Initialized
INFO - 2018-03-31 11:36:19 --> Model Class Initialized
INFO - 2018-03-31 11:36:19 --> Model Class Initialized
INFO - 2018-03-31 11:36:19 --> Model Class Initialized
INFO - 2018-03-31 11:36:19 --> Model Class Initialized
INFO - 2018-03-31 11:36:19 --> Model Class Initialized
INFO - 2018-03-31 11:36:19 --> Model Class Initialized
INFO - 2018-03-31 11:36:19 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-31 11:36:19 --> Model Class Initialized
INFO - 2018-03-31 11:36:19 --> Final output sent to browser
DEBUG - 2018-03-31 11:36:19 --> Total execution time: 0.8663
INFO - 2018-03-31 11:36:19 --> Database Driver Class Initialized
DEBUG - 2018-03-31 11:36:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 11:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 11:36:19 --> Helper loaded: form_helper
INFO - 2018-03-31 11:36:19 --> Form Validation Class Initialized
INFO - 2018-03-31 11:36:19 --> Controller Class Initialized
INFO - 2018-03-31 11:36:19 --> Model Class Initialized
INFO - 2018-03-31 11:36:19 --> Helper loaded: inflector_helper
DEBUG - 2018-03-31 11:36:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-31 11:36:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-31 11:36:19 --> Model Class Initialized
INFO - 2018-03-31 11:36:19 --> Model Class Initialized
INFO - 2018-03-31 11:36:19 --> Model Class Initialized
INFO - 2018-03-31 11:36:19 --> Model Class Initialized
INFO - 2018-03-31 11:36:19 --> Model Class Initialized
INFO - 2018-03-31 11:36:19 --> Model Class Initialized
INFO - 2018-03-31 11:36:19 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-31 11:36:19 --> Final output sent to browser
DEBUG - 2018-03-31 11:36:19 --> Total execution time: 1.0214
INFO - 2018-03-31 11:36:20 --> Database Driver Class Initialized
DEBUG - 2018-03-31 11:36:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 11:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 11:36:20 --> Helper loaded: form_helper
INFO - 2018-03-31 11:36:20 --> Form Validation Class Initialized
INFO - 2018-03-31 11:36:20 --> Controller Class Initialized
INFO - 2018-03-31 11:36:20 --> Model Class Initialized
INFO - 2018-03-31 11:36:20 --> Helper loaded: inflector_helper
DEBUG - 2018-03-31 11:36:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-31 11:36:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-31 11:36:20 --> Model Class Initialized
INFO - 2018-03-31 11:36:20 --> Model Class Initialized
INFO - 2018-03-31 11:36:20 --> Model Class Initialized
INFO - 2018-03-31 11:36:20 --> Model Class Initialized
INFO - 2018-03-31 11:36:20 --> Model Class Initialized
INFO - 2018-03-31 11:36:20 --> Model Class Initialized
INFO - 2018-03-31 11:36:20 --> Model Class Initialized
INFO - 2018-03-31 11:36:20 --> Model Class Initialized
INFO - 2018-03-31 11:36:20 --> Model Class Initialized
INFO - 2018-03-31 11:36:20 --> Model Class Initialized
INFO - 2018-03-31 11:36:20 --> Model Class Initialized
INFO - 2018-03-31 11:36:20 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-31 11:36:20 --> Model Class Initialized
INFO - 2018-03-31 11:36:20 --> Final output sent to browser
DEBUG - 2018-03-31 11:36:20 --> Total execution time: 1.5277
INFO - 2018-03-31 06:06:21 --> Config Class Initialized
INFO - 2018-03-31 06:06:21 --> Hooks Class Initialized
DEBUG - 2018-03-31 06:06:21 --> UTF-8 Support Enabled
INFO - 2018-03-31 06:06:21 --> Utf8 Class Initialized
INFO - 2018-03-31 06:06:21 --> URI Class Initialized
INFO - 2018-03-31 06:06:21 --> Router Class Initialized
INFO - 2018-03-31 06:06:21 --> Output Class Initialized
INFO - 2018-03-31 06:06:21 --> Security Class Initialized
DEBUG - 2018-03-31 06:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 06:06:21 --> Input Class Initialized
INFO - 2018-03-31 06:06:21 --> Language Class Initialized
INFO - 2018-03-31 06:06:22 --> Language Class Initialized
INFO - 2018-03-31 06:06:22 --> Config Class Initialized
INFO - 2018-03-31 06:06:22 --> Loader Class Initialized
INFO - 2018-03-31 11:36:22 --> Helper loaded: url_helper
INFO - 2018-03-31 11:36:22 --> Helper loaded: notification_helper
INFO - 2018-03-31 11:36:22 --> Helper loaded: settings_helper
INFO - 2018-03-31 11:36:22 --> Helper loaded: permission_helper
INFO - 2018-03-31 11:36:22 --> Helper loaded: users_helper
INFO - 2018-03-31 11:36:22 --> Database Driver Class Initialized
DEBUG - 2018-03-31 11:36:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 11:36:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 11:36:22 --> Helper loaded: form_helper
INFO - 2018-03-31 11:36:22 --> Form Validation Class Initialized
INFO - 2018-03-31 11:36:22 --> Controller Class Initialized
INFO - 2018-03-31 11:36:23 --> Model Class Initialized
INFO - 2018-03-31 11:36:23 --> Helper loaded: inflector_helper
DEBUG - 2018-03-31 11:36:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-31 11:36:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-31 11:36:23 --> Model Class Initialized
INFO - 2018-03-31 11:36:23 --> Model Class Initialized
INFO - 2018-03-31 11:36:23 --> Model Class Initialized
INFO - 2018-03-31 11:36:23 --> Model Class Initialized
INFO - 2018-03-31 11:36:23 --> Model Class Initialized
INFO - 2018-03-31 11:36:23 --> Model Class Initialized
INFO - 2018-03-31 11:36:23 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-31 11:36:23 --> Final output sent to browser
DEBUG - 2018-03-31 11:36:23 --> Total execution time: 1.4011
INFO - 2018-03-31 06:06:23 --> Config Class Initialized
INFO - 2018-03-31 06:06:23 --> Hooks Class Initialized
DEBUG - 2018-03-31 06:06:23 --> UTF-8 Support Enabled
INFO - 2018-03-31 06:06:23 --> Utf8 Class Initialized
INFO - 2018-03-31 06:06:23 --> URI Class Initialized
INFO - 2018-03-31 06:06:23 --> Router Class Initialized
INFO - 2018-03-31 06:06:23 --> Output Class Initialized
INFO - 2018-03-31 06:06:23 --> Security Class Initialized
DEBUG - 2018-03-31 06:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 06:06:23 --> Input Class Initialized
INFO - 2018-03-31 06:06:23 --> Language Class Initialized
INFO - 2018-03-31 06:06:23 --> Language Class Initialized
INFO - 2018-03-31 06:06:23 --> Config Class Initialized
INFO - 2018-03-31 06:06:23 --> Loader Class Initialized
INFO - 2018-03-31 11:36:23 --> Helper loaded: url_helper
INFO - 2018-03-31 11:36:23 --> Helper loaded: notification_helper
INFO - 2018-03-31 11:36:23 --> Helper loaded: settings_helper
INFO - 2018-03-31 06:06:23 --> Config Class Initialized
INFO - 2018-03-31 06:06:23 --> Hooks Class Initialized
INFO - 2018-03-31 11:36:23 --> Helper loaded: permission_helper
INFO - 2018-03-31 11:36:23 --> Helper loaded: users_helper
DEBUG - 2018-03-31 06:06:23 --> UTF-8 Support Enabled
INFO - 2018-03-31 06:06:23 --> Utf8 Class Initialized
INFO - 2018-03-31 06:06:23 --> URI Class Initialized
INFO - 2018-03-31 06:06:23 --> Router Class Initialized
INFO - 2018-03-31 06:06:23 --> Output Class Initialized
INFO - 2018-03-31 06:06:23 --> Security Class Initialized
INFO - 2018-03-31 11:36:23 --> Database Driver Class Initialized
DEBUG - 2018-03-31 06:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 06:06:23 --> Input Class Initialized
INFO - 2018-03-31 06:06:23 --> Language Class Initialized
DEBUG - 2018-03-31 11:36:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 11:36:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 11:36:23 --> Helper loaded: form_helper
INFO - 2018-03-31 11:36:23 --> Form Validation Class Initialized
INFO - 2018-03-31 11:36:23 --> Controller Class Initialized
INFO - 2018-03-31 06:06:23 --> Language Class Initialized
INFO - 2018-03-31 06:06:23 --> Config Class Initialized
INFO - 2018-03-31 06:06:23 --> Loader Class Initialized
INFO - 2018-03-31 11:36:23 --> Model Class Initialized
INFO - 2018-03-31 11:36:23 --> Helper loaded: url_helper
INFO - 2018-03-31 11:36:23 --> Helper loaded: inflector_helper
INFO - 2018-03-31 11:36:23 --> Helper loaded: notification_helper
INFO - 2018-03-31 11:36:23 --> Helper loaded: settings_helper
INFO - 2018-03-31 11:36:23 --> Helper loaded: permission_helper
INFO - 2018-03-31 11:36:23 --> Helper loaded: users_helper
DEBUG - 2018-03-31 11:36:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-31 11:36:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-31 11:36:23 --> Model Class Initialized
INFO - 2018-03-31 11:36:23 --> Model Class Initialized
INFO - 2018-03-31 11:36:23 --> Model Class Initialized
INFO - 2018-03-31 11:36:23 --> Model Class Initialized
INFO - 2018-03-31 11:36:23 --> Model Class Initialized
INFO - 2018-03-31 11:36:23 --> Model Class Initialized
INFO - 2018-03-31 11:36:23 --> Model Class Initialized
INFO - 2018-03-31 11:36:23 --> Model Class Initialized
INFO - 2018-03-31 11:36:23 --> Model Class Initialized
INFO - 2018-03-31 11:36:23 --> Model Class Initialized
INFO - 2018-03-31 11:36:23 --> Model Class Initialized
INFO - 2018-03-31 11:36:23 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-31 11:36:23 --> Database Driver Class Initialized
INFO - 2018-03-31 11:36:23 --> Final output sent to browser
DEBUG - 2018-03-31 11:36:23 --> Total execution time: 0.2601
DEBUG - 2018-03-31 11:36:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 11:36:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 11:36:23 --> Helper loaded: form_helper
INFO - 2018-03-31 11:36:23 --> Form Validation Class Initialized
INFO - 2018-03-31 11:36:23 --> Controller Class Initialized
INFO - 2018-03-31 11:36:23 --> Model Class Initialized
INFO - 2018-03-31 11:36:24 --> Helper loaded: inflector_helper
DEBUG - 2018-03-31 11:36:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-31 11:36:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-31 11:36:24 --> Model Class Initialized
INFO - 2018-03-31 11:36:24 --> Model Class Initialized
INFO - 2018-03-31 11:36:24 --> Model Class Initialized
INFO - 2018-03-31 11:36:24 --> Model Class Initialized
INFO - 2018-03-31 11:36:24 --> Model Class Initialized
INFO - 2018-03-31 11:36:24 --> Model Class Initialized
INFO - 2018-03-31 11:36:24 --> Model Class Initialized
INFO - 2018-03-31 11:36:24 --> Model Class Initialized
INFO - 2018-03-31 11:36:24 --> Model Class Initialized
INFO - 2018-03-31 11:36:24 --> Model Class Initialized
INFO - 2018-03-31 11:36:24 --> Model Class Initialized
INFO - 2018-03-31 11:36:24 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-31 11:36:24 --> Model Class Initialized
INFO - 2018-03-31 11:36:24 --> Final output sent to browser
DEBUG - 2018-03-31 11:36:24 --> Total execution time: 0.5407
INFO - 2018-03-31 06:06:37 --> Config Class Initialized
INFO - 2018-03-31 06:06:37 --> Hooks Class Initialized
DEBUG - 2018-03-31 06:06:37 --> UTF-8 Support Enabled
INFO - 2018-03-31 06:06:37 --> Utf8 Class Initialized
INFO - 2018-03-31 06:06:37 --> URI Class Initialized
INFO - 2018-03-31 06:06:37 --> Router Class Initialized
INFO - 2018-03-31 06:06:37 --> Output Class Initialized
INFO - 2018-03-31 06:06:37 --> Security Class Initialized
DEBUG - 2018-03-31 06:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 06:06:37 --> Input Class Initialized
INFO - 2018-03-31 06:06:37 --> Language Class Initialized
INFO - 2018-03-31 06:06:37 --> Config Class Initialized
INFO - 2018-03-31 06:06:37 --> Hooks Class Initialized
DEBUG - 2018-03-31 06:06:37 --> UTF-8 Support Enabled
INFO - 2018-03-31 06:06:37 --> Utf8 Class Initialized
INFO - 2018-03-31 06:06:37 --> URI Class Initialized
INFO - 2018-03-31 06:06:37 --> Router Class Initialized
INFO - 2018-03-31 06:06:37 --> Output Class Initialized
INFO - 2018-03-31 06:06:37 --> Language Class Initialized
INFO - 2018-03-31 06:06:37 --> Config Class Initialized
INFO - 2018-03-31 06:06:37 --> Security Class Initialized
INFO - 2018-03-31 06:06:37 --> Loader Class Initialized
INFO - 2018-03-31 11:36:37 --> Helper loaded: url_helper
DEBUG - 2018-03-31 06:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 06:06:37 --> Input Class Initialized
INFO - 2018-03-31 11:36:37 --> Helper loaded: notification_helper
INFO - 2018-03-31 06:06:37 --> Language Class Initialized
INFO - 2018-03-31 11:36:37 --> Helper loaded: settings_helper
INFO - 2018-03-31 11:36:37 --> Helper loaded: permission_helper
INFO - 2018-03-31 11:36:37 --> Helper loaded: users_helper
INFO - 2018-03-31 11:36:37 --> Database Driver Class Initialized
INFO - 2018-03-31 06:06:37 --> Language Class Initialized
INFO - 2018-03-31 06:06:37 --> Config Class Initialized
INFO - 2018-03-31 06:06:37 --> Loader Class Initialized
INFO - 2018-03-31 11:36:37 --> Helper loaded: url_helper
INFO - 2018-03-31 11:36:37 --> Helper loaded: notification_helper
DEBUG - 2018-03-31 11:36:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 11:36:37 --> Helper loaded: settings_helper
INFO - 2018-03-31 11:36:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 11:36:37 --> Helper loaded: permission_helper
INFO - 2018-03-31 11:36:37 --> Helper loaded: users_helper
INFO - 2018-03-31 11:36:37 --> Helper loaded: form_helper
INFO - 2018-03-31 11:36:37 --> Form Validation Class Initialized
INFO - 2018-03-31 11:36:37 --> Controller Class Initialized
INFO - 2018-03-31 11:36:37 --> Database Driver Class Initialized
INFO - 2018-03-31 11:36:37 --> Model Class Initialized
INFO - 2018-03-31 11:36:37 --> Helper loaded: inflector_helper
DEBUG - 2018-03-31 11:36:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 11:36:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-03-31 11:36:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-31 11:36:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-31 11:36:37 --> Model Class Initialized
INFO - 2018-03-31 11:36:37 --> Model Class Initialized
INFO - 2018-03-31 11:36:37 --> Model Class Initialized
INFO - 2018-03-31 11:36:37 --> Model Class Initialized
INFO - 2018-03-31 11:36:37 --> Model Class Initialized
INFO - 2018-03-31 11:36:37 --> Model Class Initialized
INFO - 2018-03-31 11:36:37 --> Model Class Initialized
INFO - 2018-03-31 11:36:37 --> Helper loaded: form_helper
INFO - 2018-03-31 11:36:37 --> Form Validation Class Initialized
INFO - 2018-03-31 11:36:37 --> Controller Class Initialized
INFO - 2018-03-31 11:36:37 --> Model Class Initialized
INFO - 2018-03-31 11:36:37 --> Model Class Initialized
INFO - 2018-03-31 11:36:37 --> Model Class Initialized
INFO - 2018-03-31 11:36:37 --> Model Class Initialized
INFO - 2018-03-31 11:36:37 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-31 11:36:37 --> Final output sent to browser
DEBUG - 2018-03-31 11:36:37 --> Total execution time: 0.4330
INFO - 2018-03-31 11:36:37 --> Model Class Initialized
INFO - 2018-03-31 11:36:37 --> Helper loaded: inflector_helper
DEBUG - 2018-03-31 11:36:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-31 11:36:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-31 11:36:37 --> Model Class Initialized
INFO - 2018-03-31 11:36:37 --> Model Class Initialized
INFO - 2018-03-31 11:36:37 --> Model Class Initialized
INFO - 2018-03-31 11:36:37 --> Model Class Initialized
INFO - 2018-03-31 11:36:37 --> Model Class Initialized
INFO - 2018-03-31 11:36:37 --> Model Class Initialized
INFO - 2018-03-31 11:36:37 --> Model Class Initialized
INFO - 2018-03-31 11:36:37 --> Model Class Initialized
INFO - 2018-03-31 11:36:37 --> Model Class Initialized
INFO - 2018-03-31 11:36:37 --> Model Class Initialized
INFO - 2018-03-31 11:36:37 --> Model Class Initialized
INFO - 2018-03-31 11:36:37 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-31 11:36:37 --> Model Class Initialized
INFO - 2018-03-31 11:36:37 --> Final output sent to browser
DEBUG - 2018-03-31 11:36:37 --> Total execution time: 0.4177
INFO - 2018-03-31 06:06:38 --> Config Class Initialized
INFO - 2018-03-31 06:06:38 --> Hooks Class Initialized
DEBUG - 2018-03-31 06:06:38 --> UTF-8 Support Enabled
INFO - 2018-03-31 06:06:38 --> Utf8 Class Initialized
INFO - 2018-03-31 06:06:38 --> URI Class Initialized
INFO - 2018-03-31 06:06:38 --> Router Class Initialized
INFO - 2018-03-31 06:06:38 --> Output Class Initialized
INFO - 2018-03-31 06:06:38 --> Security Class Initialized
DEBUG - 2018-03-31 06:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 06:06:38 --> Input Class Initialized
INFO - 2018-03-31 06:06:38 --> Language Class Initialized
INFO - 2018-03-31 06:06:38 --> Language Class Initialized
INFO - 2018-03-31 06:06:38 --> Config Class Initialized
INFO - 2018-03-31 06:06:38 --> Loader Class Initialized
INFO - 2018-03-31 11:36:38 --> Helper loaded: url_helper
INFO - 2018-03-31 11:36:38 --> Helper loaded: notification_helper
INFO - 2018-03-31 11:36:38 --> Helper loaded: settings_helper
INFO - 2018-03-31 11:36:38 --> Helper loaded: permission_helper
INFO - 2018-03-31 11:36:38 --> Helper loaded: users_helper
INFO - 2018-03-31 11:36:38 --> Database Driver Class Initialized
DEBUG - 2018-03-31 11:36:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 11:36:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 11:36:38 --> Helper loaded: form_helper
INFO - 2018-03-31 11:36:38 --> Form Validation Class Initialized
INFO - 2018-03-31 11:36:38 --> Controller Class Initialized
INFO - 2018-03-31 11:36:38 --> Model Class Initialized
INFO - 2018-03-31 11:36:38 --> Helper loaded: inflector_helper
DEBUG - 2018-03-31 11:36:38 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-31 11:36:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-31 11:36:38 --> Model Class Initialized
INFO - 2018-03-31 11:36:38 --> Model Class Initialized
INFO - 2018-03-31 11:36:38 --> Model Class Initialized
INFO - 2018-03-31 11:36:38 --> Model Class Initialized
INFO - 2018-03-31 11:36:38 --> Final output sent to browser
DEBUG - 2018-03-31 11:36:38 --> Total execution time: 0.2223
INFO - 2018-03-31 06:06:40 --> Config Class Initialized
INFO - 2018-03-31 06:06:40 --> Hooks Class Initialized
INFO - 2018-03-31 06:06:40 --> Config Class Initialized
INFO - 2018-03-31 06:06:40 --> Hooks Class Initialized
DEBUG - 2018-03-31 06:06:40 --> UTF-8 Support Enabled
INFO - 2018-03-31 06:06:40 --> Utf8 Class Initialized
INFO - 2018-03-31 06:06:40 --> URI Class Initialized
DEBUG - 2018-03-31 06:06:40 --> UTF-8 Support Enabled
INFO - 2018-03-31 06:06:40 --> Utf8 Class Initialized
INFO - 2018-03-31 06:06:40 --> Router Class Initialized
INFO - 2018-03-31 06:06:40 --> URI Class Initialized
INFO - 2018-03-31 06:06:40 --> Router Class Initialized
INFO - 2018-03-31 06:06:40 --> Output Class Initialized
INFO - 2018-03-31 06:06:40 --> Security Class Initialized
INFO - 2018-03-31 06:06:40 --> Output Class Initialized
DEBUG - 2018-03-31 06:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 06:06:40 --> Input Class Initialized
INFO - 2018-03-31 06:06:40 --> Security Class Initialized
INFO - 2018-03-31 06:06:40 --> Language Class Initialized
DEBUG - 2018-03-31 06:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 06:06:40 --> Input Class Initialized
INFO - 2018-03-31 06:06:40 --> Language Class Initialized
INFO - 2018-03-31 06:06:40 --> Language Class Initialized
INFO - 2018-03-31 06:06:40 --> Config Class Initialized
INFO - 2018-03-31 06:06:40 --> Loader Class Initialized
INFO - 2018-03-31 11:36:40 --> Helper loaded: url_helper
INFO - 2018-03-31 06:06:40 --> Language Class Initialized
INFO - 2018-03-31 06:06:40 --> Config Class Initialized
INFO - 2018-03-31 06:06:40 --> Loader Class Initialized
INFO - 2018-03-31 11:36:40 --> Helper loaded: notification_helper
INFO - 2018-03-31 11:36:40 --> Helper loaded: settings_helper
INFO - 2018-03-31 11:36:40 --> Helper loaded: permission_helper
INFO - 2018-03-31 11:36:40 --> Helper loaded: url_helper
INFO - 2018-03-31 11:36:40 --> Helper loaded: users_helper
INFO - 2018-03-31 11:36:40 --> Helper loaded: notification_helper
INFO - 2018-03-31 11:36:40 --> Helper loaded: settings_helper
INFO - 2018-03-31 11:36:40 --> Helper loaded: permission_helper
INFO - 2018-03-31 11:36:40 --> Helper loaded: users_helper
INFO - 2018-03-31 11:36:40 --> Database Driver Class Initialized
INFO - 2018-03-31 11:36:40 --> Database Driver Class Initialized
DEBUG - 2018-03-31 11:36:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 11:36:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-03-31 11:36:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 11:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 11:36:40 --> Helper loaded: form_helper
INFO - 2018-03-31 11:36:40 --> Form Validation Class Initialized
INFO - 2018-03-31 11:36:40 --> Controller Class Initialized
INFO - 2018-03-31 11:36:40 --> Helper loaded: form_helper
INFO - 2018-03-31 11:36:40 --> Form Validation Class Initialized
INFO - 2018-03-31 11:36:40 --> Controller Class Initialized
INFO - 2018-03-31 11:36:40 --> Model Class Initialized
INFO - 2018-03-31 11:36:40 --> Helper loaded: inflector_helper
DEBUG - 2018-03-31 11:36:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-31 11:36:40 --> Model Class Initialized
INFO - 2018-03-31 11:36:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-31 11:36:40 --> Helper loaded: inflector_helper
INFO - 2018-03-31 11:36:40 --> Model Class Initialized
INFO - 2018-03-31 11:36:40 --> Model Class Initialized
INFO - 2018-03-31 11:36:40 --> Model Class Initialized
INFO - 2018-03-31 11:36:40 --> Model Class Initialized
DEBUG - 2018-03-31 11:36:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-31 11:36:40 --> Final output sent to browser
DEBUG - 2018-03-31 11:36:40 --> Total execution time: 0.2150
INFO - 2018-03-31 11:36:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-31 11:36:40 --> Model Class Initialized
INFO - 2018-03-31 11:36:40 --> Model Class Initialized
INFO - 2018-03-31 11:36:40 --> Model Class Initialized
INFO - 2018-03-31 11:36:40 --> Model Class Initialized
INFO - 2018-03-31 11:36:40 --> Final output sent to browser
DEBUG - 2018-03-31 11:36:40 --> Total execution time: 0.2357
INFO - 2018-03-31 06:06:44 --> Config Class Initialized
INFO - 2018-03-31 06:06:44 --> Hooks Class Initialized
DEBUG - 2018-03-31 06:06:44 --> UTF-8 Support Enabled
INFO - 2018-03-31 06:06:44 --> Utf8 Class Initialized
INFO - 2018-03-31 06:06:44 --> URI Class Initialized
INFO - 2018-03-31 06:06:44 --> Router Class Initialized
INFO - 2018-03-31 06:06:44 --> Config Class Initialized
INFO - 2018-03-31 06:06:44 --> Hooks Class Initialized
INFO - 2018-03-31 06:06:44 --> Output Class Initialized
DEBUG - 2018-03-31 06:06:44 --> UTF-8 Support Enabled
INFO - 2018-03-31 06:06:44 --> Utf8 Class Initialized
INFO - 2018-03-31 06:06:44 --> Security Class Initialized
DEBUG - 2018-03-31 06:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 06:06:44 --> Input Class Initialized
INFO - 2018-03-31 06:06:44 --> URI Class Initialized
INFO - 2018-03-31 06:06:44 --> Language Class Initialized
INFO - 2018-03-31 06:06:44 --> Router Class Initialized
INFO - 2018-03-31 06:06:44 --> Output Class Initialized
INFO - 2018-03-31 06:06:44 --> Config Class Initialized
INFO - 2018-03-31 06:06:44 --> Hooks Class Initialized
INFO - 2018-03-31 06:06:44 --> Security Class Initialized
DEBUG - 2018-03-31 06:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 06:06:44 --> Input Class Initialized
DEBUG - 2018-03-31 06:06:44 --> UTF-8 Support Enabled
INFO - 2018-03-31 06:06:44 --> Utf8 Class Initialized
INFO - 2018-03-31 06:06:44 --> Language Class Initialized
INFO - 2018-03-31 06:06:44 --> URI Class Initialized
INFO - 2018-03-31 06:06:44 --> Router Class Initialized
INFO - 2018-03-31 06:06:44 --> Output Class Initialized
INFO - 2018-03-31 06:06:44 --> Security Class Initialized
DEBUG - 2018-03-31 06:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 06:06:44 --> Input Class Initialized
INFO - 2018-03-31 06:06:44 --> Language Class Initialized
INFO - 2018-03-31 06:06:44 --> Config Class Initialized
INFO - 2018-03-31 06:06:44 --> Language Class Initialized
INFO - 2018-03-31 06:06:44 --> Loader Class Initialized
INFO - 2018-03-31 11:36:44 --> Helper loaded: url_helper
INFO - 2018-03-31 11:36:44 --> Helper loaded: notification_helper
INFO - 2018-03-31 11:36:44 --> Helper loaded: settings_helper
INFO - 2018-03-31 06:06:44 --> Language Class Initialized
INFO - 2018-03-31 06:06:44 --> Config Class Initialized
INFO - 2018-03-31 06:06:44 --> Loader Class Initialized
INFO - 2018-03-31 11:36:44 --> Helper loaded: permission_helper
INFO - 2018-03-31 11:36:44 --> Helper loaded: users_helper
INFO - 2018-03-31 11:36:44 --> Helper loaded: url_helper
INFO - 2018-03-31 11:36:44 --> Helper loaded: notification_helper
INFO - 2018-03-31 11:36:44 --> Helper loaded: settings_helper
INFO - 2018-03-31 11:36:44 --> Helper loaded: permission_helper
INFO - 2018-03-31 11:36:44 --> Helper loaded: users_helper
INFO - 2018-03-31 06:06:44 --> Language Class Initialized
INFO - 2018-03-31 06:06:44 --> Config Class Initialized
INFO - 2018-03-31 06:06:44 --> Loader Class Initialized
INFO - 2018-03-31 11:36:44 --> Database Driver Class Initialized
INFO - 2018-03-31 11:36:44 --> Helper loaded: url_helper
INFO - 2018-03-31 11:36:44 --> Helper loaded: notification_helper
INFO - 2018-03-31 11:36:44 --> Helper loaded: settings_helper
INFO - 2018-03-31 11:36:44 --> Helper loaded: permission_helper
DEBUG - 2018-03-31 11:36:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 11:36:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 11:36:44 --> Helper loaded: users_helper
INFO - 2018-03-31 11:36:44 --> Helper loaded: form_helper
INFO - 2018-03-31 11:36:44 --> Form Validation Class Initialized
INFO - 2018-03-31 11:36:44 --> Controller Class Initialized
INFO - 2018-03-31 11:36:44 --> Database Driver Class Initialized
INFO - 2018-03-31 11:36:44 --> Model Class Initialized
INFO - 2018-03-31 11:36:44 --> Helper loaded: inflector_helper
INFO - 2018-03-31 11:36:44 --> Database Driver Class Initialized
DEBUG - 2018-03-31 11:36:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 11:36:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-03-31 11:36:44 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-03-31 11:36:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 11:36:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 11:36:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-31 11:36:44 --> Model Class Initialized
INFO - 2018-03-31 11:36:44 --> Model Class Initialized
INFO - 2018-03-31 11:36:44 --> Model Class Initialized
INFO - 2018-03-31 11:36:44 --> Model Class Initialized
INFO - 2018-03-31 11:36:44 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-31 11:36:44 --> Helper loaded: form_helper
INFO - 2018-03-31 11:36:44 --> Form Validation Class Initialized
INFO - 2018-03-31 11:36:44 --> Final output sent to browser
INFO - 2018-03-31 11:36:44 --> Controller Class Initialized
DEBUG - 2018-03-31 11:36:44 --> Total execution time: 0.4542
INFO - 2018-03-31 11:36:44 --> Model Class Initialized
INFO - 2018-03-31 11:36:44 --> Helper loaded: inflector_helper
DEBUG - 2018-03-31 11:36:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-31 11:36:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-31 11:36:45 --> Helper loaded: form_helper
INFO - 2018-03-31 11:36:45 --> Form Validation Class Initialized
INFO - 2018-03-31 11:36:45 --> Controller Class Initialized
INFO - 2018-03-31 11:36:45 --> Model Class Initialized
INFO - 2018-03-31 11:36:45 --> Model Class Initialized
INFO - 2018-03-31 11:36:45 --> Model Class Initialized
INFO - 2018-03-31 11:36:45 --> Model Class Initialized
INFO - 2018-03-31 11:36:45 --> Model Class Initialized
INFO - 2018-03-31 11:36:45 --> Model Class Initialized
INFO - 2018-03-31 11:36:45 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-31 11:36:45 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-03-31 11:36:45 --> Final output sent to browser
DEBUG - 2018-03-31 11:36:45 --> Total execution time: 0.8762
INFO - 2018-03-31 11:36:45 --> Model Class Initialized
INFO - 2018-03-31 11:36:45 --> Helper loaded: inflector_helper
DEBUG - 2018-03-31 11:36:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-31 11:36:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-31 11:36:45 --> Model Class Initialized
INFO - 2018-03-31 11:36:45 --> Model Class Initialized
INFO - 2018-03-31 11:36:45 --> Model Class Initialized
INFO - 2018-03-31 11:36:45 --> Model Class Initialized
INFO - 2018-03-31 11:36:45 --> Model Class Initialized
INFO - 2018-03-31 11:36:45 --> Model Class Initialized
INFO - 2018-03-31 11:36:45 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-31 11:36:45 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-03-31 11:36:45 --> Final output sent to browser
DEBUG - 2018-03-31 11:36:45 --> Total execution time: 0.9467
INFO - 2018-03-31 06:06:50 --> Config Class Initialized
INFO - 2018-03-31 06:06:50 --> Hooks Class Initialized
INFO - 2018-03-31 06:06:50 --> Config Class Initialized
INFO - 2018-03-31 06:06:50 --> Hooks Class Initialized
DEBUG - 2018-03-31 06:06:50 --> UTF-8 Support Enabled
INFO - 2018-03-31 06:06:50 --> Utf8 Class Initialized
DEBUG - 2018-03-31 06:06:50 --> UTF-8 Support Enabled
INFO - 2018-03-31 06:06:50 --> Utf8 Class Initialized
INFO - 2018-03-31 06:06:50 --> URI Class Initialized
INFO - 2018-03-31 06:06:50 --> URI Class Initialized
INFO - 2018-03-31 06:06:50 --> Router Class Initialized
INFO - 2018-03-31 06:06:50 --> Router Class Initialized
INFO - 2018-03-31 06:06:50 --> Output Class Initialized
INFO - 2018-03-31 06:06:50 --> Output Class Initialized
INFO - 2018-03-31 06:06:50 --> Security Class Initialized
INFO - 2018-03-31 06:06:50 --> Security Class Initialized
DEBUG - 2018-03-31 06:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 06:06:50 --> Input Class Initialized
DEBUG - 2018-03-31 06:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 06:06:50 --> Input Class Initialized
INFO - 2018-03-31 06:06:50 --> Language Class Initialized
INFO - 2018-03-31 06:06:50 --> Language Class Initialized
INFO - 2018-03-31 06:06:50 --> Language Class Initialized
INFO - 2018-03-31 06:06:50 --> Config Class Initialized
INFO - 2018-03-31 06:06:50 --> Loader Class Initialized
INFO - 2018-03-31 11:36:50 --> Helper loaded: url_helper
INFO - 2018-03-31 06:06:50 --> Language Class Initialized
INFO - 2018-03-31 06:06:50 --> Config Class Initialized
INFO - 2018-03-31 06:06:50 --> Loader Class Initialized
INFO - 2018-03-31 11:36:50 --> Helper loaded: notification_helper
INFO - 2018-03-31 11:36:50 --> Helper loaded: settings_helper
INFO - 2018-03-31 11:36:50 --> Helper loaded: permission_helper
INFO - 2018-03-31 11:36:50 --> Helper loaded: url_helper
INFO - 2018-03-31 11:36:50 --> Helper loaded: users_helper
INFO - 2018-03-31 11:36:50 --> Helper loaded: notification_helper
INFO - 2018-03-31 11:36:50 --> Helper loaded: settings_helper
INFO - 2018-03-31 11:36:50 --> Helper loaded: permission_helper
INFO - 2018-03-31 11:36:50 --> Helper loaded: users_helper
INFO - 2018-03-31 11:36:50 --> Database Driver Class Initialized
INFO - 2018-03-31 11:36:50 --> Database Driver Class Initialized
DEBUG - 2018-03-31 11:36:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 11:36:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-03-31 11:36:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 11:36:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 11:36:50 --> Helper loaded: form_helper
INFO - 2018-03-31 11:36:50 --> Form Validation Class Initialized
INFO - 2018-03-31 11:36:50 --> Controller Class Initialized
INFO - 2018-03-31 11:36:50 --> Model Class Initialized
INFO - 2018-03-31 11:36:50 --> Helper loaded: inflector_helper
INFO - 2018-03-31 11:36:50 --> Helper loaded: form_helper
INFO - 2018-03-31 11:36:50 --> Form Validation Class Initialized
INFO - 2018-03-31 11:36:50 --> Controller Class Initialized
DEBUG - 2018-03-31 11:36:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-31 11:36:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-31 11:36:50 --> Model Class Initialized
INFO - 2018-03-31 11:36:50 --> Model Class Initialized
INFO - 2018-03-31 11:36:50 --> Model Class Initialized
INFO - 2018-03-31 11:36:50 --> Model Class Initialized
INFO - 2018-03-31 11:36:50 --> Model Class Initialized
INFO - 2018-03-31 11:36:50 --> Model Class Initialized
INFO - 2018-03-31 11:36:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-31 11:36:50 --> Model Class Initialized
INFO - 2018-03-31 11:36:50 --> Final output sent to browser
DEBUG - 2018-03-31 11:36:50 --> Total execution time: 0.6815
INFO - 2018-03-31 11:36:50 --> Model Class Initialized
INFO - 2018-03-31 11:36:50 --> Helper loaded: inflector_helper
DEBUG - 2018-03-31 11:36:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-31 11:36:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-31 11:36:50 --> Model Class Initialized
INFO - 2018-03-31 11:36:50 --> Model Class Initialized
INFO - 2018-03-31 11:36:50 --> Model Class Initialized
INFO - 2018-03-31 11:36:50 --> Model Class Initialized
INFO - 2018-03-31 11:36:50 --> Model Class Initialized
INFO - 2018-03-31 11:36:50 --> Model Class Initialized
INFO - 2018-03-31 11:36:50 --> Model Class Initialized
INFO - 2018-03-31 11:36:50 --> Model Class Initialized
INFO - 2018-03-31 11:36:50 --> Model Class Initialized
INFO - 2018-03-31 11:36:50 --> Model Class Initialized
INFO - 2018-03-31 11:36:50 --> Model Class Initialized
INFO - 2018-03-31 11:36:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-31 11:36:51 --> Model Class Initialized
INFO - 2018-03-31 11:36:51 --> Final output sent to browser
DEBUG - 2018-03-31 11:36:51 --> Total execution time: 0.9574
INFO - 2018-03-31 06:06:54 --> Config Class Initialized
INFO - 2018-03-31 06:06:54 --> Hooks Class Initialized
DEBUG - 2018-03-31 06:06:54 --> UTF-8 Support Enabled
INFO - 2018-03-31 06:06:54 --> Utf8 Class Initialized
INFO - 2018-03-31 06:06:54 --> URI Class Initialized
INFO - 2018-03-31 06:06:54 --> Router Class Initialized
INFO - 2018-03-31 06:06:54 --> Output Class Initialized
INFO - 2018-03-31 06:06:54 --> Security Class Initialized
DEBUG - 2018-03-31 06:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 06:06:54 --> Input Class Initialized
INFO - 2018-03-31 06:06:54 --> Language Class Initialized
INFO - 2018-03-31 06:06:54 --> Language Class Initialized
INFO - 2018-03-31 06:06:54 --> Config Class Initialized
INFO - 2018-03-31 06:06:54 --> Loader Class Initialized
INFO - 2018-03-31 11:36:54 --> Helper loaded: url_helper
INFO - 2018-03-31 11:36:54 --> Helper loaded: notification_helper
INFO - 2018-03-31 11:36:54 --> Helper loaded: settings_helper
INFO - 2018-03-31 11:36:54 --> Helper loaded: permission_helper
INFO - 2018-03-31 11:36:54 --> Helper loaded: users_helper
INFO - 2018-03-31 11:36:54 --> Database Driver Class Initialized
DEBUG - 2018-03-31 11:36:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 11:36:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 11:36:54 --> Helper loaded: form_helper
INFO - 2018-03-31 11:36:54 --> Form Validation Class Initialized
INFO - 2018-03-31 11:36:54 --> Controller Class Initialized
INFO - 2018-03-31 11:36:54 --> Model Class Initialized
INFO - 2018-03-31 11:36:54 --> Helper loaded: inflector_helper
DEBUG - 2018-03-31 11:36:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-31 11:36:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-31 11:36:54 --> Model Class Initialized
INFO - 2018-03-31 11:36:54 --> Model Class Initialized
INFO - 2018-03-31 11:36:54 --> Model Class Initialized
INFO - 2018-03-31 11:36:54 --> Model Class Initialized
INFO - 2018-03-31 11:36:54 --> Model Class Initialized
INFO - 2018-03-31 11:36:54 --> Model Class Initialized
INFO - 2018-03-31 11:36:54 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-31 11:36:54 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-31 11:36:54 --> Final output sent to browser
DEBUG - 2018-03-31 11:36:54 --> Total execution time: 0.1246
INFO - 2018-03-31 11:11:33 --> Config Class Initialized
INFO - 2018-03-31 11:11:33 --> Hooks Class Initialized
DEBUG - 2018-03-31 11:11:33 --> UTF-8 Support Enabled
INFO - 2018-03-31 11:11:33 --> Utf8 Class Initialized
INFO - 2018-03-31 11:11:33 --> URI Class Initialized
DEBUG - 2018-03-31 11:11:33 --> No URI present. Default controller set.
INFO - 2018-03-31 11:11:33 --> Router Class Initialized
INFO - 2018-03-31 11:11:33 --> Output Class Initialized
INFO - 2018-03-31 11:11:33 --> Security Class Initialized
DEBUG - 2018-03-31 11:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 11:11:33 --> Input Class Initialized
INFO - 2018-03-31 11:11:33 --> Language Class Initialized
INFO - 2018-03-31 11:11:33 --> Language Class Initialized
INFO - 2018-03-31 11:11:33 --> Config Class Initialized
INFO - 2018-03-31 11:11:33 --> Loader Class Initialized
INFO - 2018-03-31 16:41:33 --> Helper loaded: url_helper
INFO - 2018-03-31 16:41:33 --> Helper loaded: notification_helper
INFO - 2018-03-31 16:41:33 --> Helper loaded: settings_helper
INFO - 2018-03-31 16:41:33 --> Helper loaded: permission_helper
INFO - 2018-03-31 16:41:33 --> Helper loaded: users_helper
INFO - 2018-03-31 16:41:33 --> Database Driver Class Initialized
DEBUG - 2018-03-31 16:41:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-31 16:41:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 16:41:33 --> Helper loaded: form_helper
INFO - 2018-03-31 16:41:33 --> Form Validation Class Initialized
INFO - 2018-03-31 16:41:33 --> Controller Class Initialized
INFO - 2018-03-31 16:41:33 --> Model Class Initialized
INFO - 2018-03-31 16:41:33 --> Helper loaded: inflector_helper
INFO - 2018-03-31 16:41:33 --> Model Class Initialized
DEBUG - 2018-03-31 16:41:33 --> File loaded: /home/pr01004/public_html/application/views/login.php
INFO - 2018-03-31 16:41:33 --> Final output sent to browser
DEBUG - 2018-03-31 16:41:33 --> Total execution time: 0.1115
