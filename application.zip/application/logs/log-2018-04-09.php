<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-04-09 11:55:15 --> Config Class Initialized
INFO - 2018-04-09 11:55:15 --> Hooks Class Initialized
DEBUG - 2018-04-09 11:55:15 --> UTF-8 Support Enabled
INFO - 2018-04-09 11:55:15 --> Utf8 Class Initialized
INFO - 2018-04-09 11:55:15 --> URI Class Initialized
INFO - 2018-04-09 11:55:15 --> Router Class Initialized
INFO - 2018-04-09 11:55:15 --> Output Class Initialized
INFO - 2018-04-09 11:55:15 --> Security Class Initialized
DEBUG - 2018-04-09 11:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 11:55:15 --> Input Class Initialized
INFO - 2018-04-09 11:55:15 --> Language Class Initialized
INFO - 2018-04-09 11:55:15 --> Language Class Initialized
INFO - 2018-04-09 11:55:15 --> Config Class Initialized
INFO - 2018-04-09 11:55:15 --> Loader Class Initialized
INFO - 2018-04-09 17:25:15 --> Helper loaded: url_helper
INFO - 2018-04-09 17:25:15 --> Helper loaded: notification_helper
INFO - 2018-04-09 17:25:15 --> Helper loaded: settings_helper
INFO - 2018-04-09 17:25:15 --> Helper loaded: permission_helper
INFO - 2018-04-09 17:25:15 --> Helper loaded: users_helper
INFO - 2018-04-09 17:25:16 --> Database Driver Class Initialized
DEBUG - 2018-04-09 17:25:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 17:25:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 17:25:16 --> Helper loaded: form_helper
INFO - 2018-04-09 17:25:16 --> Form Validation Class Initialized
INFO - 2018-04-09 17:25:16 --> Controller Class Initialized
INFO - 2018-04-09 17:25:16 --> Model Class Initialized
INFO - 2018-04-09 17:25:16 --> Helper loaded: inflector_helper
DEBUG - 2018-04-09 17:25:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-09 17:25:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-09 17:25:16 --> Model Class Initialized
INFO - 2018-04-09 17:25:16 --> Model Class Initialized
INFO - 2018-04-09 17:25:16 --> Model Class Initialized
INFO - 2018-04-09 17:25:16 --> Model Class Initialized
INFO - 2018-04-09 17:25:16 --> Model Class Initialized
INFO - 2018-04-09 17:25:16 --> Model Class Initialized
INFO - 2018-04-09 17:25:16 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-09 17:25:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-09 17:25:16 --> Final output sent to browser
DEBUG - 2018-04-09 17:25:16 --> Total execution time: 0.3258
INFO - 2018-04-09 11:55:16 --> Config Class Initialized
INFO - 2018-04-09 11:55:16 --> Hooks Class Initialized
DEBUG - 2018-04-09 11:55:16 --> UTF-8 Support Enabled
INFO - 2018-04-09 11:55:16 --> Utf8 Class Initialized
INFO - 2018-04-09 11:55:16 --> URI Class Initialized
INFO - 2018-04-09 11:55:16 --> Router Class Initialized
INFO - 2018-04-09 11:55:16 --> Output Class Initialized
INFO - 2018-04-09 11:55:16 --> Security Class Initialized
DEBUG - 2018-04-09 11:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 11:55:16 --> Input Class Initialized
INFO - 2018-04-09 11:55:16 --> Language Class Initialized
INFO - 2018-04-09 11:55:16 --> Language Class Initialized
INFO - 2018-04-09 11:55:16 --> Config Class Initialized
INFO - 2018-04-09 11:55:16 --> Loader Class Initialized
INFO - 2018-04-09 17:25:16 --> Helper loaded: url_helper
INFO - 2018-04-09 17:25:16 --> Helper loaded: notification_helper
INFO - 2018-04-09 17:25:16 --> Helper loaded: settings_helper
INFO - 2018-04-09 17:25:16 --> Helper loaded: permission_helper
INFO - 2018-04-09 17:25:16 --> Helper loaded: users_helper
INFO - 2018-04-09 17:25:16 --> Database Driver Class Initialized
DEBUG - 2018-04-09 17:25:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 17:25:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 17:25:16 --> Helper loaded: form_helper
INFO - 2018-04-09 17:25:16 --> Form Validation Class Initialized
INFO - 2018-04-09 17:25:16 --> Controller Class Initialized
INFO - 2018-04-09 17:25:16 --> Model Class Initialized
INFO - 2018-04-09 17:25:16 --> Helper loaded: inflector_helper
DEBUG - 2018-04-09 17:25:17 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-09 17:25:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-09 17:25:17 --> Model Class Initialized
INFO - 2018-04-09 17:25:17 --> Model Class Initialized
INFO - 2018-04-09 17:25:17 --> Model Class Initialized
INFO - 2018-04-09 17:25:17 --> Model Class Initialized
INFO - 2018-04-09 17:25:17 --> Model Class Initialized
INFO - 2018-04-09 17:25:17 --> Model Class Initialized
INFO - 2018-04-09 17:25:17 --> Model Class Initialized
INFO - 2018-04-09 17:25:17 --> Model Class Initialized
INFO - 2018-04-09 17:25:17 --> Model Class Initialized
INFO - 2018-04-09 17:25:17 --> Model Class Initialized
INFO - 2018-04-09 17:25:17 --> Model Class Initialized
INFO - 2018-04-09 17:25:17 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-09 17:25:17 --> Model Class Initialized
INFO - 2018-04-09 17:25:17 --> Final output sent to browser
DEBUG - 2018-04-09 17:25:17 --> Total execution time: 0.2748
INFO - 2018-04-09 11:55:17 --> Config Class Initialized
INFO - 2018-04-09 11:55:17 --> Hooks Class Initialized
DEBUG - 2018-04-09 11:55:17 --> UTF-8 Support Enabled
INFO - 2018-04-09 11:55:17 --> Utf8 Class Initialized
INFO - 2018-04-09 11:55:17 --> URI Class Initialized
INFO - 2018-04-09 11:55:17 --> Router Class Initialized
INFO - 2018-04-09 11:55:17 --> Output Class Initialized
INFO - 2018-04-09 11:55:17 --> Security Class Initialized
DEBUG - 2018-04-09 11:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 11:55:17 --> Input Class Initialized
INFO - 2018-04-09 11:55:17 --> Language Class Initialized
INFO - 2018-04-09 11:55:17 --> Language Class Initialized
INFO - 2018-04-09 11:55:17 --> Config Class Initialized
INFO - 2018-04-09 11:55:17 --> Loader Class Initialized
INFO - 2018-04-09 17:25:17 --> Helper loaded: url_helper
INFO - 2018-04-09 17:25:17 --> Helper loaded: notification_helper
INFO - 2018-04-09 17:25:17 --> Helper loaded: settings_helper
INFO - 2018-04-09 17:25:17 --> Helper loaded: permission_helper
INFO - 2018-04-09 17:25:17 --> Helper loaded: users_helper
INFO - 2018-04-09 17:25:17 --> Database Driver Class Initialized
DEBUG - 2018-04-09 17:25:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 17:25:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 17:25:17 --> Helper loaded: form_helper
INFO - 2018-04-09 17:25:17 --> Form Validation Class Initialized
INFO - 2018-04-09 17:25:17 --> Controller Class Initialized
INFO - 2018-04-09 17:25:17 --> Model Class Initialized
INFO - 2018-04-09 17:25:17 --> Helper loaded: inflector_helper
DEBUG - 2018-04-09 17:25:17 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-09 17:25:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-09 17:25:17 --> Model Class Initialized
INFO - 2018-04-09 17:25:17 --> Model Class Initialized
INFO - 2018-04-09 17:25:17 --> Model Class Initialized
INFO - 2018-04-09 17:25:17 --> Model Class Initialized
INFO - 2018-04-09 17:25:17 --> Model Class Initialized
INFO - 2018-04-09 17:25:17 --> Model Class Initialized
INFO - 2018-04-09 17:25:17 --> Model Class Initialized
INFO - 2018-04-09 17:25:17 --> Model Class Initialized
INFO - 2018-04-09 17:25:17 --> Model Class Initialized
INFO - 2018-04-09 17:25:17 --> Model Class Initialized
INFO - 2018-04-09 17:25:17 --> Model Class Initialized
INFO - 2018-04-09 17:25:17 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-09 17:25:17 --> Model Class Initialized
INFO - 2018-04-09 17:25:17 --> Final output sent to browser
DEBUG - 2018-04-09 17:25:17 --> Total execution time: 0.1048
INFO - 2018-04-09 11:55:19 --> Config Class Initialized
INFO - 2018-04-09 11:55:19 --> Hooks Class Initialized
DEBUG - 2018-04-09 11:55:19 --> UTF-8 Support Enabled
INFO - 2018-04-09 11:55:19 --> Utf8 Class Initialized
INFO - 2018-04-09 11:55:19 --> URI Class Initialized
INFO - 2018-04-09 11:55:19 --> Router Class Initialized
INFO - 2018-04-09 11:55:19 --> Output Class Initialized
INFO - 2018-04-09 11:55:19 --> Security Class Initialized
DEBUG - 2018-04-09 11:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 11:55:19 --> Input Class Initialized
INFO - 2018-04-09 11:55:19 --> Language Class Initialized
INFO - 2018-04-09 11:55:19 --> Language Class Initialized
INFO - 2018-04-09 11:55:19 --> Config Class Initialized
INFO - 2018-04-09 11:55:19 --> Loader Class Initialized
INFO - 2018-04-09 17:25:19 --> Helper loaded: url_helper
INFO - 2018-04-09 17:25:19 --> Helper loaded: notification_helper
INFO - 2018-04-09 17:25:19 --> Helper loaded: settings_helper
INFO - 2018-04-09 17:25:19 --> Helper loaded: permission_helper
INFO - 2018-04-09 17:25:19 --> Helper loaded: users_helper
INFO - 2018-04-09 17:25:19 --> Database Driver Class Initialized
DEBUG - 2018-04-09 17:25:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 17:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 11:55:19 --> Config Class Initialized
INFO - 2018-04-09 11:55:19 --> Hooks Class Initialized
INFO - 2018-04-09 17:25:19 --> Helper loaded: form_helper
INFO - 2018-04-09 17:25:19 --> Form Validation Class Initialized
INFO - 2018-04-09 17:25:19 --> Controller Class Initialized
DEBUG - 2018-04-09 11:55:19 --> UTF-8 Support Enabled
INFO - 2018-04-09 11:55:19 --> Utf8 Class Initialized
INFO - 2018-04-09 11:55:19 --> URI Class Initialized
INFO - 2018-04-09 11:55:19 --> Router Class Initialized
INFO - 2018-04-09 17:25:19 --> Model Class Initialized
INFO - 2018-04-09 17:25:19 --> Helper loaded: inflector_helper
INFO - 2018-04-09 11:55:19 --> Output Class Initialized
DEBUG - 2018-04-09 17:25:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-09 11:55:19 --> Security Class Initialized
INFO - 2018-04-09 17:25:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-09 17:25:19 --> Model Class Initialized
INFO - 2018-04-09 17:25:19 --> Model Class Initialized
DEBUG - 2018-04-09 11:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 11:55:19 --> Input Class Initialized
INFO - 2018-04-09 17:25:19 --> Model Class Initialized
INFO - 2018-04-09 17:25:19 --> Model Class Initialized
INFO - 2018-04-09 17:25:19 --> Model Class Initialized
INFO - 2018-04-09 11:55:19 --> Language Class Initialized
INFO - 2018-04-09 17:25:19 --> Model Class Initialized
INFO - 2018-04-09 17:25:19 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-09 17:25:19 --> Final output sent to browser
DEBUG - 2018-04-09 17:25:19 --> Total execution time: 0.1170
INFO - 2018-04-09 11:55:19 --> Language Class Initialized
INFO - 2018-04-09 11:55:19 --> Config Class Initialized
INFO - 2018-04-09 11:55:19 --> Loader Class Initialized
INFO - 2018-04-09 17:25:19 --> Helper loaded: url_helper
INFO - 2018-04-09 17:25:19 --> Helper loaded: notification_helper
INFO - 2018-04-09 17:25:19 --> Helper loaded: settings_helper
INFO - 2018-04-09 17:25:19 --> Helper loaded: permission_helper
INFO - 2018-04-09 17:25:19 --> Helper loaded: users_helper
INFO - 2018-04-09 17:25:19 --> Database Driver Class Initialized
DEBUG - 2018-04-09 17:25:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 17:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 17:25:19 --> Helper loaded: form_helper
INFO - 2018-04-09 17:25:19 --> Form Validation Class Initialized
INFO - 2018-04-09 17:25:19 --> Controller Class Initialized
INFO - 2018-04-09 17:25:19 --> Model Class Initialized
INFO - 2018-04-09 17:25:19 --> Helper loaded: inflector_helper
DEBUG - 2018-04-09 17:25:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-09 17:25:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-09 17:25:19 --> Model Class Initialized
INFO - 2018-04-09 17:25:19 --> Model Class Initialized
INFO - 2018-04-09 17:25:19 --> Model Class Initialized
INFO - 2018-04-09 17:25:19 --> Model Class Initialized
INFO - 2018-04-09 17:25:19 --> Model Class Initialized
INFO - 2018-04-09 17:25:19 --> Model Class Initialized
INFO - 2018-04-09 17:25:19 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-09 17:25:19 --> Final output sent to browser
DEBUG - 2018-04-09 17:25:19 --> Total execution time: 0.1183
INFO - 2018-04-09 11:55:19 --> Config Class Initialized
INFO - 2018-04-09 11:55:19 --> Hooks Class Initialized
DEBUG - 2018-04-09 11:55:19 --> UTF-8 Support Enabled
INFO - 2018-04-09 11:55:19 --> Utf8 Class Initialized
INFO - 2018-04-09 11:55:19 --> URI Class Initialized
INFO - 2018-04-09 11:55:19 --> Router Class Initialized
INFO - 2018-04-09 11:55:19 --> Output Class Initialized
INFO - 2018-04-09 11:55:19 --> Security Class Initialized
DEBUG - 2018-04-09 11:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 11:55:19 --> Input Class Initialized
INFO - 2018-04-09 11:55:19 --> Language Class Initialized
INFO - 2018-04-09 11:55:19 --> Language Class Initialized
INFO - 2018-04-09 11:55:19 --> Config Class Initialized
INFO - 2018-04-09 11:55:19 --> Loader Class Initialized
INFO - 2018-04-09 17:25:19 --> Helper loaded: url_helper
INFO - 2018-04-09 17:25:19 --> Helper loaded: notification_helper
INFO - 2018-04-09 17:25:19 --> Helper loaded: settings_helper
INFO - 2018-04-09 17:25:19 --> Helper loaded: permission_helper
INFO - 2018-04-09 17:25:19 --> Helper loaded: users_helper
INFO - 2018-04-09 17:25:19 --> Database Driver Class Initialized
DEBUG - 2018-04-09 17:25:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 17:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 17:25:19 --> Helper loaded: form_helper
INFO - 2018-04-09 17:25:19 --> Form Validation Class Initialized
INFO - 2018-04-09 17:25:19 --> Controller Class Initialized
INFO - 2018-04-09 17:25:19 --> Model Class Initialized
INFO - 2018-04-09 17:25:19 --> Helper loaded: inflector_helper
DEBUG - 2018-04-09 17:25:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-09 17:25:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-09 17:25:19 --> Model Class Initialized
INFO - 2018-04-09 17:25:19 --> Model Class Initialized
INFO - 2018-04-09 17:25:19 --> Model Class Initialized
INFO - 2018-04-09 17:25:20 --> Model Class Initialized
INFO - 2018-04-09 17:25:20 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-09 17:25:20 --> Final output sent to browser
DEBUG - 2018-04-09 17:25:20 --> Total execution time: 0.1291
INFO - 2018-04-09 11:55:21 --> Config Class Initialized
INFO - 2018-04-09 11:55:21 --> Hooks Class Initialized
DEBUG - 2018-04-09 11:55:21 --> UTF-8 Support Enabled
INFO - 2018-04-09 11:55:21 --> Utf8 Class Initialized
INFO - 2018-04-09 11:55:21 --> URI Class Initialized
INFO - 2018-04-09 11:55:21 --> Router Class Initialized
INFO - 2018-04-09 11:55:21 --> Output Class Initialized
INFO - 2018-04-09 11:55:21 --> Security Class Initialized
DEBUG - 2018-04-09 11:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 11:55:21 --> Input Class Initialized
INFO - 2018-04-09 11:55:21 --> Language Class Initialized
INFO - 2018-04-09 11:55:21 --> Language Class Initialized
INFO - 2018-04-09 11:55:21 --> Config Class Initialized
INFO - 2018-04-09 11:55:21 --> Loader Class Initialized
INFO - 2018-04-09 17:25:21 --> Helper loaded: url_helper
INFO - 2018-04-09 17:25:21 --> Helper loaded: notification_helper
INFO - 2018-04-09 17:25:21 --> Helper loaded: settings_helper
INFO - 2018-04-09 17:25:21 --> Helper loaded: permission_helper
INFO - 2018-04-09 17:25:21 --> Helper loaded: users_helper
INFO - 2018-04-09 17:25:21 --> Database Driver Class Initialized
DEBUG - 2018-04-09 17:25:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 17:25:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 17:25:21 --> Helper loaded: form_helper
INFO - 2018-04-09 17:25:21 --> Form Validation Class Initialized
INFO - 2018-04-09 17:25:21 --> Controller Class Initialized
INFO - 2018-04-09 17:25:21 --> Model Class Initialized
INFO - 2018-04-09 17:25:21 --> Helper loaded: inflector_helper
DEBUG - 2018-04-09 17:25:21 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-09 17:25:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-09 17:25:21 --> Model Class Initialized
INFO - 2018-04-09 17:25:21 --> Model Class Initialized
INFO - 2018-04-09 17:25:21 --> Model Class Initialized
INFO - 2018-04-09 17:25:21 --> Model Class Initialized
INFO - 2018-04-09 17:25:21 --> Model Class Initialized
INFO - 2018-04-09 17:25:21 --> Model Class Initialized
INFO - 2018-04-09 17:25:21 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-09 17:25:21 --> Final output sent to browser
DEBUG - 2018-04-09 17:25:21 --> Total execution time: 0.1092
INFO - 2018-04-09 11:55:28 --> Config Class Initialized
INFO - 2018-04-09 11:55:28 --> Hooks Class Initialized
DEBUG - 2018-04-09 11:55:28 --> UTF-8 Support Enabled
INFO - 2018-04-09 11:55:28 --> Utf8 Class Initialized
INFO - 2018-04-09 11:55:28 --> URI Class Initialized
INFO - 2018-04-09 11:55:28 --> Router Class Initialized
INFO - 2018-04-09 11:55:28 --> Output Class Initialized
INFO - 2018-04-09 11:55:28 --> Security Class Initialized
DEBUG - 2018-04-09 11:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 11:55:28 --> Input Class Initialized
INFO - 2018-04-09 11:55:28 --> Language Class Initialized
INFO - 2018-04-09 11:55:28 --> Language Class Initialized
INFO - 2018-04-09 11:55:28 --> Config Class Initialized
INFO - 2018-04-09 11:55:28 --> Loader Class Initialized
INFO - 2018-04-09 17:25:28 --> Helper loaded: url_helper
INFO - 2018-04-09 17:25:28 --> Helper loaded: notification_helper
INFO - 2018-04-09 17:25:28 --> Helper loaded: settings_helper
INFO - 2018-04-09 17:25:28 --> Helper loaded: permission_helper
INFO - 2018-04-09 17:25:28 --> Helper loaded: users_helper
INFO - 2018-04-09 17:25:28 --> Database Driver Class Initialized
DEBUG - 2018-04-09 17:25:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 17:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 17:25:28 --> Helper loaded: form_helper
INFO - 2018-04-09 17:25:28 --> Form Validation Class Initialized
INFO - 2018-04-09 17:25:28 --> Controller Class Initialized
INFO - 2018-04-09 17:25:28 --> Model Class Initialized
INFO - 2018-04-09 17:25:28 --> Helper loaded: inflector_helper
DEBUG - 2018-04-09 17:25:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-09 17:25:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-09 17:25:28 --> Model Class Initialized
INFO - 2018-04-09 17:25:28 --> Model Class Initialized
INFO - 2018-04-09 17:25:28 --> Final output sent to browser
DEBUG - 2018-04-09 17:25:28 --> Total execution time: 0.1267
INFO - 2018-04-09 11:55:31 --> Config Class Initialized
INFO - 2018-04-09 11:55:31 --> Hooks Class Initialized
DEBUG - 2018-04-09 11:55:31 --> UTF-8 Support Enabled
INFO - 2018-04-09 11:55:31 --> Utf8 Class Initialized
INFO - 2018-04-09 11:55:31 --> URI Class Initialized
INFO - 2018-04-09 11:55:31 --> Router Class Initialized
INFO - 2018-04-09 11:55:31 --> Output Class Initialized
INFO - 2018-04-09 11:55:31 --> Security Class Initialized
DEBUG - 2018-04-09 11:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 11:55:31 --> Input Class Initialized
INFO - 2018-04-09 11:55:31 --> Language Class Initialized
INFO - 2018-04-09 11:55:31 --> Language Class Initialized
INFO - 2018-04-09 11:55:31 --> Config Class Initialized
INFO - 2018-04-09 11:55:31 --> Loader Class Initialized
INFO - 2018-04-09 17:25:31 --> Helper loaded: url_helper
INFO - 2018-04-09 17:25:31 --> Helper loaded: notification_helper
INFO - 2018-04-09 17:25:31 --> Helper loaded: settings_helper
INFO - 2018-04-09 17:25:31 --> Helper loaded: permission_helper
INFO - 2018-04-09 17:25:31 --> Helper loaded: users_helper
INFO - 2018-04-09 17:25:31 --> Database Driver Class Initialized
DEBUG - 2018-04-09 17:25:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 17:25:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 17:25:31 --> Helper loaded: form_helper
INFO - 2018-04-09 17:25:31 --> Form Validation Class Initialized
INFO - 2018-04-09 17:25:31 --> Controller Class Initialized
INFO - 2018-04-09 17:25:31 --> Model Class Initialized
INFO - 2018-04-09 17:25:31 --> Helper loaded: inflector_helper
DEBUG - 2018-04-09 17:25:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-09 17:25:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-09 17:25:31 --> Model Class Initialized
INFO - 2018-04-09 17:25:31 --> Model Class Initialized
INFO - 2018-04-09 17:25:31 --> Model Class Initialized
INFO - 2018-04-09 17:25:31 --> Model Class Initialized
INFO - 2018-04-09 17:25:31 --> Model Class Initialized
INFO - 2018-04-09 17:25:31 --> Model Class Initialized
INFO - 2018-04-09 17:25:31 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-09 17:25:31 --> Final output sent to browser
DEBUG - 2018-04-09 17:25:31 --> Total execution time: 0.1142
