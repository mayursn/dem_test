<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-02-02 07:19:04 --> Config Class Initialized
INFO - 2018-02-02 07:19:04 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:19:04 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:19:04 --> Utf8 Class Initialized
INFO - 2018-02-02 07:19:04 --> URI Class Initialized
DEBUG - 2018-02-02 07:19:04 --> No URI present. Default controller set.
INFO - 2018-02-02 07:19:04 --> Router Class Initialized
INFO - 2018-02-02 07:19:04 --> Output Class Initialized
INFO - 2018-02-02 07:19:04 --> Security Class Initialized
DEBUG - 2018-02-02 07:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:19:04 --> Input Class Initialized
INFO - 2018-02-02 07:19:04 --> Language Class Initialized
INFO - 2018-02-02 07:19:04 --> Language Class Initialized
INFO - 2018-02-02 07:19:04 --> Config Class Initialized
INFO - 2018-02-02 07:19:04 --> Loader Class Initialized
INFO - 2018-02-02 12:49:04 --> Helper loaded: url_helper
INFO - 2018-02-02 12:49:04 --> Helper loaded: notification_helper
INFO - 2018-02-02 12:49:04 --> Helper loaded: settings_helper
INFO - 2018-02-02 12:49:04 --> Helper loaded: permission_helper
INFO - 2018-02-02 12:49:04 --> Helper loaded: users_helper
INFO - 2018-02-02 12:49:04 --> Database Driver Class Initialized
DEBUG - 2018-02-02 12:49:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 12:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 12:49:04 --> Helper loaded: form_helper
INFO - 2018-02-02 12:49:04 --> Form Validation Class Initialized
INFO - 2018-02-02 12:49:04 --> Controller Class Initialized
INFO - 2018-02-02 12:49:04 --> Model Class Initialized
INFO - 2018-02-02 12:49:04 --> Helper loaded: inflector_helper
INFO - 2018-02-02 12:49:04 --> Model Class Initialized
DEBUG - 2018-02-02 12:49:04 --> File loaded: /home/pr01004/public_html/application/views/login.php
INFO - 2018-02-02 12:49:04 --> Final output sent to browser
DEBUG - 2018-02-02 12:49:04 --> Total execution time: 0.0740
INFO - 2018-02-02 07:19:14 --> Config Class Initialized
INFO - 2018-02-02 07:19:14 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:19:14 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:19:14 --> Utf8 Class Initialized
INFO - 2018-02-02 07:19:14 --> URI Class Initialized
INFO - 2018-02-02 07:19:14 --> Router Class Initialized
INFO - 2018-02-02 07:19:14 --> Output Class Initialized
INFO - 2018-02-02 07:19:14 --> Security Class Initialized
DEBUG - 2018-02-02 07:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:19:14 --> Input Class Initialized
INFO - 2018-02-02 07:19:14 --> Language Class Initialized
INFO - 2018-02-02 07:19:14 --> Language Class Initialized
INFO - 2018-02-02 07:19:14 --> Config Class Initialized
INFO - 2018-02-02 07:19:14 --> Loader Class Initialized
INFO - 2018-02-02 12:49:14 --> Helper loaded: url_helper
INFO - 2018-02-02 12:49:14 --> Helper loaded: notification_helper
INFO - 2018-02-02 12:49:14 --> Helper loaded: settings_helper
INFO - 2018-02-02 12:49:14 --> Helper loaded: permission_helper
INFO - 2018-02-02 12:49:14 --> Helper loaded: users_helper
INFO - 2018-02-02 12:49:14 --> Database Driver Class Initialized
DEBUG - 2018-02-02 12:49:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 12:49:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 12:49:14 --> Helper loaded: form_helper
INFO - 2018-02-02 12:49:14 --> Form Validation Class Initialized
INFO - 2018-02-02 12:49:14 --> Controller Class Initialized
INFO - 2018-02-02 12:49:14 --> Model Class Initialized
INFO - 2018-02-02 12:49:14 --> Helper loaded: inflector_helper
INFO - 2018-02-02 12:49:14 --> Model Class Initialized
INFO - 2018-02-02 12:49:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-02 07:19:14 --> Config Class Initialized
INFO - 2018-02-02 07:19:14 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:19:14 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:19:14 --> Utf8 Class Initialized
INFO - 2018-02-02 07:19:14 --> URI Class Initialized
INFO - 2018-02-02 07:19:14 --> Router Class Initialized
INFO - 2018-02-02 07:19:14 --> Output Class Initialized
INFO - 2018-02-02 07:19:14 --> Security Class Initialized
DEBUG - 2018-02-02 07:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:19:14 --> Input Class Initialized
INFO - 2018-02-02 07:19:14 --> Language Class Initialized
INFO - 2018-02-02 07:19:14 --> Language Class Initialized
INFO - 2018-02-02 07:19:14 --> Config Class Initialized
INFO - 2018-02-02 07:19:14 --> Loader Class Initialized
INFO - 2018-02-02 12:49:14 --> Helper loaded: url_helper
INFO - 2018-02-02 12:49:14 --> Helper loaded: notification_helper
INFO - 2018-02-02 12:49:14 --> Helper loaded: settings_helper
INFO - 2018-02-02 12:49:14 --> Helper loaded: permission_helper
INFO - 2018-02-02 12:49:14 --> Helper loaded: users_helper
INFO - 2018-02-02 12:49:14 --> Database Driver Class Initialized
DEBUG - 2018-02-02 12:49:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 12:49:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 12:49:14 --> Helper loaded: form_helper
INFO - 2018-02-02 12:49:14 --> Form Validation Class Initialized
INFO - 2018-02-02 12:49:14 --> Controller Class Initialized
INFO - 2018-02-02 12:49:14 --> Model Class Initialized
INFO - 2018-02-02 12:49:14 --> Helper loaded: inflector_helper
INFO - 2018-02-02 12:49:14 --> Model Class Initialized
INFO - 2018-02-02 12:49:14 --> Model Class Initialized
INFO - 2018-02-02 12:49:14 --> Model Class Initialized
INFO - 2018-02-02 12:49:14 --> Model Class Initialized
INFO - 2018-02-02 12:49:14 --> Model Class Initialized
DEBUG - 2018-02-02 12:49:15 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-02-02 12:49:15 --> File loaded: /home/pr01004/public_html/application/views/admin/dashboard.php
DEBUG - 2018-02-02 12:49:15 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-02-02 12:49:15 --> Final output sent to browser
DEBUG - 2018-02-02 12:49:15 --> Total execution time: 0.1127
INFO - 2018-02-02 07:19:15 --> Config Class Initialized
INFO - 2018-02-02 07:19:15 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:19:15 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:19:15 --> Utf8 Class Initialized
INFO - 2018-02-02 07:19:15 --> URI Class Initialized
INFO - 2018-02-02 07:19:15 --> Router Class Initialized
INFO - 2018-02-02 07:19:15 --> Output Class Initialized
INFO - 2018-02-02 07:19:15 --> Security Class Initialized
DEBUG - 2018-02-02 07:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:19:15 --> Input Class Initialized
INFO - 2018-02-02 07:19:15 --> Language Class Initialized
INFO - 2018-02-02 07:19:15 --> Language Class Initialized
INFO - 2018-02-02 07:19:15 --> Config Class Initialized
INFO - 2018-02-02 07:19:15 --> Loader Class Initialized
INFO - 2018-02-02 12:49:15 --> Helper loaded: url_helper
INFO - 2018-02-02 12:49:15 --> Helper loaded: notification_helper
INFO - 2018-02-02 12:49:15 --> Helper loaded: settings_helper
INFO - 2018-02-02 12:49:15 --> Helper loaded: permission_helper
INFO - 2018-02-02 12:49:15 --> Helper loaded: users_helper
INFO - 2018-02-02 12:49:15 --> Database Driver Class Initialized
DEBUG - 2018-02-02 12:49:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 12:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 12:49:15 --> Helper loaded: form_helper
INFO - 2018-02-02 12:49:15 --> Form Validation Class Initialized
INFO - 2018-02-02 12:49:15 --> Controller Class Initialized
DEBUG - 2018-02-02 12:49:15 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-02-02 12:49:15 --> Final output sent to browser
DEBUG - 2018-02-02 12:49:15 --> Total execution time: 0.0948
INFO - 2018-02-02 07:19:22 --> Config Class Initialized
INFO - 2018-02-02 07:19:22 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:19:22 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:19:22 --> Utf8 Class Initialized
INFO - 2018-02-02 07:19:22 --> URI Class Initialized
INFO - 2018-02-02 07:19:22 --> Router Class Initialized
INFO - 2018-02-02 07:19:22 --> Output Class Initialized
INFO - 2018-02-02 07:19:22 --> Security Class Initialized
DEBUG - 2018-02-02 07:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:19:22 --> Input Class Initialized
INFO - 2018-02-02 07:19:22 --> Language Class Initialized
INFO - 2018-02-02 07:19:22 --> Language Class Initialized
INFO - 2018-02-02 07:19:22 --> Config Class Initialized
INFO - 2018-02-02 07:19:22 --> Loader Class Initialized
INFO - 2018-02-02 12:49:22 --> Helper loaded: url_helper
INFO - 2018-02-02 12:49:22 --> Helper loaded: notification_helper
INFO - 2018-02-02 12:49:22 --> Helper loaded: settings_helper
INFO - 2018-02-02 12:49:22 --> Helper loaded: permission_helper
INFO - 2018-02-02 12:49:22 --> Helper loaded: users_helper
INFO - 2018-02-02 12:49:22 --> Database Driver Class Initialized
DEBUG - 2018-02-02 12:49:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 12:49:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 12:49:22 --> Helper loaded: form_helper
INFO - 2018-02-02 12:49:22 --> Form Validation Class Initialized
INFO - 2018-02-02 12:49:22 --> Controller Class Initialized
INFO - 2018-02-02 12:49:22 --> Model Class Initialized
INFO - 2018-02-02 12:49:22 --> Helper loaded: inflector_helper
INFO - 2018-02-02 12:49:22 --> Model Class Initialized
INFO - 2018-02-02 12:49:22 --> Model Class Initialized
INFO - 2018-02-02 12:49:22 --> Model Class Initialized
DEBUG - 2018-02-02 12:49:22 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-02-02 12:49:22 --> File loaded: /home/pr01004/public_html/application/views/admin/notifications.php
DEBUG - 2018-02-02 12:49:22 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-02-02 12:49:22 --> Final output sent to browser
DEBUG - 2018-02-02 12:49:22 --> Total execution time: 0.0664
INFO - 2018-02-02 07:19:31 --> Config Class Initialized
INFO - 2018-02-02 07:19:31 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:19:31 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:19:31 --> Utf8 Class Initialized
INFO - 2018-02-02 07:19:31 --> URI Class Initialized
INFO - 2018-02-02 07:19:31 --> Router Class Initialized
INFO - 2018-02-02 07:19:31 --> Output Class Initialized
INFO - 2018-02-02 07:19:31 --> Security Class Initialized
DEBUG - 2018-02-02 07:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:19:31 --> Input Class Initialized
INFO - 2018-02-02 07:19:31 --> Language Class Initialized
INFO - 2018-02-02 07:19:31 --> Language Class Initialized
INFO - 2018-02-02 07:19:31 --> Config Class Initialized
INFO - 2018-02-02 07:19:31 --> Loader Class Initialized
INFO - 2018-02-02 12:49:31 --> Helper loaded: url_helper
INFO - 2018-02-02 12:49:31 --> Helper loaded: notification_helper
INFO - 2018-02-02 12:49:31 --> Helper loaded: settings_helper
INFO - 2018-02-02 12:49:31 --> Helper loaded: permission_helper
INFO - 2018-02-02 12:49:31 --> Helper loaded: users_helper
INFO - 2018-02-02 12:49:31 --> Database Driver Class Initialized
DEBUG - 2018-02-02 12:49:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 12:49:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 12:49:31 --> Helper loaded: form_helper
INFO - 2018-02-02 12:49:31 --> Form Validation Class Initialized
INFO - 2018-02-02 12:49:31 --> Controller Class Initialized
INFO - 2018-02-02 12:49:31 --> Model Class Initialized
INFO - 2018-02-02 12:49:31 --> Helper loaded: inflector_helper
INFO - 2018-02-02 12:49:31 --> Model Class Initialized
INFO - 2018-02-02 12:49:31 --> Model Class Initialized
INFO - 2018-02-02 12:49:31 --> Model Class Initialized
ERROR - 2018-02-02 12:49:33 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-02 12:49:33 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-02 12:49:33 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-02 12:49:33 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-02 12:49:33 --> Severity: Warning --> pack(): Type H: illegal hex digit k /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-02 12:49:33 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-02 12:49:33 --> Severity: Warning --> pack(): Type H: illegal hex digit j /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-02 12:49:33 --> Severity: Warning --> pack(): Type H: illegal hex digit l /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-02 12:49:33 --> Severity: Warning --> pack(): Type H: illegal hex digit k /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-02 12:49:33 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-02 12:49:33 --> Severity: Warning --> pack(): Type H: illegal hex digit l /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-02 12:49:33 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-02 12:49:33 --> Severity: Warning --> pack(): Type H: illegal hex digit k /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-02 12:49:33 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-02 12:49:33 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-02 12:49:33 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-02 12:49:33 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-02 12:49:33 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-02 12:49:33 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-02 12:49:33 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-02 12:49:33 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-02 12:49:33 --> Severity: Warning --> pack(): Type H: illegal hex digit k /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-02 12:49:33 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-02 12:49:33 --> Severity: Warning --> pack(): Type H: illegal hex digit j /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-02 12:49:33 --> Severity: Warning --> pack(): Type H: illegal hex digit l /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-02 12:49:33 --> Severity: Warning --> pack(): Type H: illegal hex digit k /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-02 12:49:33 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-02 12:49:33 --> Severity: Warning --> pack(): Type H: illegal hex digit l /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-02 12:49:33 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-02 12:49:33 --> Severity: Warning --> pack(): Type H: illegal hex digit k /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-02 12:49:33 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-02 12:49:33 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-02 12:49:33 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-02 12:49:33 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-02 12:49:33 --> Severity: Warning --> pack(): Type H: illegal hex digit s /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-02 12:49:33 --> Severity: Warning --> pack(): Type H: illegal hex digit s /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-02 12:49:33 --> Severity: Warning --> pack(): Type H: illegal hex digit s /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-02 12:49:33 --> Severity: Warning --> pack(): Type H: illegal hex digit s /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-02 12:49:33 --> Severity: Warning --> pack(): Type H: illegal hex digit s /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-02 12:49:33 --> Severity: Warning --> pack(): Type H: illegal hex digit s /home/pr01004/public_html/application/controllers/Notification.php 156
INFO - 2018-02-02 07:19:33 --> Config Class Initialized
INFO - 2018-02-02 07:19:33 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:19:33 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:19:33 --> Utf8 Class Initialized
INFO - 2018-02-02 07:19:33 --> URI Class Initialized
INFO - 2018-02-02 07:19:33 --> Router Class Initialized
INFO - 2018-02-02 07:19:33 --> Output Class Initialized
INFO - 2018-02-02 07:19:33 --> Security Class Initialized
DEBUG - 2018-02-02 07:19:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:19:33 --> Input Class Initialized
INFO - 2018-02-02 07:19:33 --> Language Class Initialized
INFO - 2018-02-02 07:19:33 --> Language Class Initialized
INFO - 2018-02-02 07:19:33 --> Config Class Initialized
INFO - 2018-02-02 07:19:33 --> Loader Class Initialized
INFO - 2018-02-02 12:49:33 --> Helper loaded: url_helper
INFO - 2018-02-02 12:49:33 --> Helper loaded: notification_helper
INFO - 2018-02-02 12:49:33 --> Helper loaded: settings_helper
INFO - 2018-02-02 12:49:33 --> Helper loaded: permission_helper
INFO - 2018-02-02 12:49:33 --> Helper loaded: users_helper
INFO - 2018-02-02 12:49:33 --> Database Driver Class Initialized
DEBUG - 2018-02-02 12:49:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 12:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 12:49:33 --> Helper loaded: form_helper
INFO - 2018-02-02 12:49:33 --> Form Validation Class Initialized
INFO - 2018-02-02 12:49:33 --> Controller Class Initialized
INFO - 2018-02-02 12:49:33 --> Model Class Initialized
INFO - 2018-02-02 12:49:33 --> Helper loaded: inflector_helper
INFO - 2018-02-02 12:49:33 --> Model Class Initialized
INFO - 2018-02-02 12:49:33 --> Model Class Initialized
INFO - 2018-02-02 12:49:33 --> Model Class Initialized
DEBUG - 2018-02-02 12:49:33 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-02-02 12:49:33 --> File loaded: /home/pr01004/public_html/application/views/admin/notifications.php
DEBUG - 2018-02-02 12:49:33 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-02-02 12:49:33 --> Final output sent to browser
DEBUG - 2018-02-02 12:49:33 --> Total execution time: 0.0905
INFO - 2018-02-02 07:20:47 --> Config Class Initialized
INFO - 2018-02-02 07:20:47 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:20:47 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:20:47 --> Utf8 Class Initialized
INFO - 2018-02-02 07:20:47 --> Config Class Initialized
INFO - 2018-02-02 07:20:47 --> Hooks Class Initialized
INFO - 2018-02-02 07:20:47 --> URI Class Initialized
DEBUG - 2018-02-02 07:20:47 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:20:47 --> Utf8 Class Initialized
INFO - 2018-02-02 07:20:47 --> Router Class Initialized
INFO - 2018-02-02 07:20:47 --> URI Class Initialized
INFO - 2018-02-02 07:20:47 --> Output Class Initialized
INFO - 2018-02-02 07:20:47 --> Config Class Initialized
INFO - 2018-02-02 07:20:47 --> Hooks Class Initialized
INFO - 2018-02-02 07:20:47 --> Router Class Initialized
INFO - 2018-02-02 07:20:47 --> Security Class Initialized
DEBUG - 2018-02-02 07:20:47 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:20:47 --> Utf8 Class Initialized
DEBUG - 2018-02-02 07:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:20:47 --> Input Class Initialized
INFO - 2018-02-02 07:20:47 --> Output Class Initialized
INFO - 2018-02-02 07:20:47 --> URI Class Initialized
INFO - 2018-02-02 07:20:47 --> Language Class Initialized
INFO - 2018-02-02 07:20:47 --> Security Class Initialized
INFO - 2018-02-02 07:20:47 --> Router Class Initialized
DEBUG - 2018-02-02 07:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:20:47 --> Input Class Initialized
INFO - 2018-02-02 07:20:47 --> Language Class Initialized
INFO - 2018-02-02 07:20:47 --> Output Class Initialized
INFO - 2018-02-02 07:20:47 --> Security Class Initialized
INFO - 2018-02-02 07:20:47 --> Config Class Initialized
INFO - 2018-02-02 07:20:47 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:20:47 --> Input Class Initialized
INFO - 2018-02-02 07:20:47 --> Language Class Initialized
DEBUG - 2018-02-02 07:20:47 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:20:47 --> Utf8 Class Initialized
INFO - 2018-02-02 07:20:47 --> Language Class Initialized
INFO - 2018-02-02 07:20:47 --> Config Class Initialized
INFO - 2018-02-02 07:20:47 --> Loader Class Initialized
INFO - 2018-02-02 07:20:47 --> URI Class Initialized
INFO - 2018-02-02 12:50:47 --> Helper loaded: url_helper
INFO - 2018-02-02 12:50:47 --> Helper loaded: notification_helper
INFO - 2018-02-02 12:50:47 --> Helper loaded: settings_helper
INFO - 2018-02-02 12:50:47 --> Helper loaded: permission_helper
INFO - 2018-02-02 07:20:47 --> Router Class Initialized
INFO - 2018-02-02 12:50:47 --> Helper loaded: users_helper
INFO - 2018-02-02 07:20:47 --> Output Class Initialized
INFO - 2018-02-02 07:20:47 --> Language Class Initialized
INFO - 2018-02-02 07:20:47 --> Config Class Initialized
INFO - 2018-02-02 07:20:47 --> Loader Class Initialized
INFO - 2018-02-02 07:20:47 --> Security Class Initialized
INFO - 2018-02-02 12:50:47 --> Helper loaded: url_helper
INFO - 2018-02-02 12:50:47 --> Helper loaded: notification_helper
INFO - 2018-02-02 12:50:47 --> Helper loaded: settings_helper
DEBUG - 2018-02-02 07:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:20:47 --> Input Class Initialized
INFO - 2018-02-02 12:50:47 --> Helper loaded: permission_helper
INFO - 2018-02-02 12:50:47 --> Helper loaded: users_helper
INFO - 2018-02-02 07:20:47 --> Language Class Initialized
INFO - 2018-02-02 07:20:47 --> Language Class Initialized
INFO - 2018-02-02 07:20:47 --> Config Class Initialized
INFO - 2018-02-02 07:20:47 --> Loader Class Initialized
INFO - 2018-02-02 12:50:47 --> Helper loaded: url_helper
INFO - 2018-02-02 12:50:47 --> Helper loaded: notification_helper
INFO - 2018-02-02 12:50:47 --> Helper loaded: settings_helper
INFO - 2018-02-02 12:50:47 --> Database Driver Class Initialized
INFO - 2018-02-02 12:50:47 --> Helper loaded: permission_helper
INFO - 2018-02-02 12:50:47 --> Helper loaded: users_helper
DEBUG - 2018-02-02 12:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 12:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 07:20:47 --> Config Class Initialized
INFO - 2018-02-02 07:20:47 --> Hooks Class Initialized
INFO - 2018-02-02 12:50:47 --> Database Driver Class Initialized
DEBUG - 2018-02-02 07:20:47 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:20:47 --> Utf8 Class Initialized
INFO - 2018-02-02 07:20:47 --> URI Class Initialized
INFO - 2018-02-02 12:50:47 --> Helper loaded: form_helper
INFO - 2018-02-02 12:50:47 --> Form Validation Class Initialized
INFO - 2018-02-02 12:50:47 --> Controller Class Initialized
DEBUG - 2018-02-02 12:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 12:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 07:20:47 --> Router Class Initialized
INFO - 2018-02-02 07:20:47 --> Language Class Initialized
INFO - 2018-02-02 07:20:47 --> Config Class Initialized
INFO - 2018-02-02 07:20:47 --> Loader Class Initialized
INFO - 2018-02-02 12:50:47 --> Database Driver Class Initialized
INFO - 2018-02-02 12:50:47 --> Helper loaded: url_helper
INFO - 2018-02-02 07:20:47 --> Output Class Initialized
INFO - 2018-02-02 12:50:47 --> Helper loaded: notification_helper
INFO - 2018-02-02 12:50:47 --> Helper loaded: settings_helper
INFO - 2018-02-02 12:50:47 --> Helper loaded: permission_helper
DEBUG - 2018-02-02 12:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 07:20:47 --> Security Class Initialized
INFO - 2018-02-02 12:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 12:50:47 --> Helper loaded: users_helper
INFO - 2018-02-02 12:50:47 --> Helper loaded: form_helper
INFO - 2018-02-02 12:50:47 --> Form Validation Class Initialized
INFO - 2018-02-02 12:50:47 --> Controller Class Initialized
INFO - 2018-02-02 12:50:47 --> Model Class Initialized
INFO - 2018-02-02 12:50:47 --> Helper loaded: inflector_helper
DEBUG - 2018-02-02 07:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:20:47 --> Input Class Initialized
INFO - 2018-02-02 07:20:47 --> Language Class Initialized
DEBUG - 2018-02-02 12:50:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-02 12:50:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-02 12:50:47 --> Helper loaded: form_helper
INFO - 2018-02-02 12:50:47 --> Form Validation Class Initialized
INFO - 2018-02-02 12:50:47 --> Controller Class Initialized
INFO - 2018-02-02 12:50:47 --> Model Class Initialized
INFO - 2018-02-02 12:50:47 --> Model Class Initialized
INFO - 2018-02-02 12:50:47 --> Model Class Initialized
INFO - 2018-02-02 12:50:47 --> Model Class Initialized
INFO - 2018-02-02 12:50:47 --> Helper loaded: inflector_helper
INFO - 2018-02-02 12:50:47 --> Model Class Initialized
INFO - 2018-02-02 12:50:47 --> Model Class Initialized
INFO - 2018-02-02 12:50:47 --> Model Class Initialized
INFO - 2018-02-02 12:50:47 --> Model Class Initialized
INFO - 2018-02-02 12:50:47 --> Model Class Initialized
INFO - 2018-02-02 12:50:47 --> Model Class Initialized
INFO - 2018-02-02 12:50:47 --> Model Class Initialized
DEBUG - 2018-02-02 12:50:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-02 12:50:47 --> Database Driver Class Initialized
INFO - 2018-02-02 12:50:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-02 12:50:47 --> Model Class Initialized
INFO - 2018-02-02 12:50:47 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-02 12:50:47 --> Model Class Initialized
INFO - 2018-02-02 12:50:47 --> Model Class Initialized
INFO - 2018-02-02 12:50:47 --> Model Class Initialized
INFO - 2018-02-02 12:50:47 --> Model Class Initialized
INFO - 2018-02-02 12:50:47 --> Model Class Initialized
INFO - 2018-02-02 12:50:47 --> Model Class Initialized
INFO - 2018-02-02 12:50:47 --> Model Class Initialized
INFO - 2018-02-02 12:50:47 --> Model Class Initialized
INFO - 2018-02-02 12:50:47 --> Helper loaded: inflector_helper
INFO - 2018-02-02 12:50:47 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-02-02 12:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 12:50:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-02 12:50:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-02 12:50:47 --> Final output sent to browser
DEBUG - 2018-02-02 12:50:47 --> Total execution time: 0.1079
INFO - 2018-02-02 07:20:47 --> Language Class Initialized
INFO - 2018-02-02 07:20:47 --> Config Class Initialized
INFO - 2018-02-02 07:20:47 --> Loader Class Initialized
INFO - 2018-02-02 12:50:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-02 12:50:47 --> Model Class Initialized
INFO - 2018-02-02 12:50:47 --> Model Class Initialized
INFO - 2018-02-02 12:50:47 --> Helper loaded: url_helper
INFO - 2018-02-02 12:50:47 --> Model Class Initialized
INFO - 2018-02-02 12:50:47 --> Helper loaded: notification_helper
INFO - 2018-02-02 12:50:47 --> Model Class Initialized
INFO - 2018-02-02 12:50:47 --> Model Class Initialized
INFO - 2018-02-02 12:50:47 --> Helper loaded: settings_helper
INFO - 2018-02-02 12:50:47 --> Model Class Initialized
INFO - 2018-02-02 12:50:47 --> Model Class Initialized
INFO - 2018-02-02 12:50:47 --> Helper loaded: permission_helper
INFO - 2018-02-02 12:50:47 --> Helper loaded: form_helper
INFO - 2018-02-02 12:50:47 --> Form Validation Class Initialized
INFO - 2018-02-02 12:50:47 --> Model Class Initialized
INFO - 2018-02-02 12:50:47 --> Controller Class Initialized
INFO - 2018-02-02 12:50:47 --> Model Class Initialized
INFO - 2018-02-02 12:50:47 --> Helper loaded: users_helper
INFO - 2018-02-02 12:50:47 --> Model Class Initialized
INFO - 2018-02-02 12:50:47 --> Model Class Initialized
INFO - 2018-02-02 12:50:47 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-02 12:50:47 --> Model Class Initialized
INFO - 2018-02-02 12:50:47 --> Model Class Initialized
INFO - 2018-02-02 12:50:47 --> Helper loaded: inflector_helper
DEBUG - 2018-02-02 12:50:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-02 12:50:47 --> Database Driver Class Initialized
INFO - 2018-02-02 12:50:47 --> Final output sent to browser
DEBUG - 2018-02-02 12:50:47 --> Total execution time: 0.1366
INFO - 2018-02-02 12:50:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-02 12:50:47 --> Model Class Initialized
INFO - 2018-02-02 12:50:47 --> Model Class Initialized
INFO - 2018-02-02 12:50:47 --> Model Class Initialized
INFO - 2018-02-02 12:50:47 --> Model Class Initialized
INFO - 2018-02-02 12:50:47 --> Model Class Initialized
INFO - 2018-02-02 12:50:47 --> Model Class Initialized
INFO - 2018-02-02 12:50:47 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-02-02 12:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 12:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 12:50:47 --> Model Class Initialized
INFO - 2018-02-02 12:50:47 --> Final output sent to browser
DEBUG - 2018-02-02 12:50:47 --> Total execution time: 0.1136
INFO - 2018-02-02 12:50:47 --> Helper loaded: form_helper
INFO - 2018-02-02 12:50:47 --> Form Validation Class Initialized
INFO - 2018-02-02 12:50:47 --> Controller Class Initialized
INFO - 2018-02-02 12:50:47 --> Final output sent to browser
DEBUG - 2018-02-02 12:50:47 --> Total execution time: 0.1410
INFO - 2018-02-02 12:50:47 --> Model Class Initialized
INFO - 2018-02-02 12:50:47 --> Helper loaded: inflector_helper
DEBUG - 2018-02-02 12:50:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-02 12:50:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-02 12:50:47 --> Model Class Initialized
INFO - 2018-02-02 12:50:47 --> Model Class Initialized
INFO - 2018-02-02 12:50:47 --> Model Class Initialized
INFO - 2018-02-02 12:50:47 --> Model Class Initialized
INFO - 2018-02-02 12:50:47 --> Model Class Initialized
INFO - 2018-02-02 12:50:47 --> Model Class Initialized
INFO - 2018-02-02 12:50:47 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-02 12:50:47 --> Model Class Initialized
INFO - 2018-02-02 12:50:47 --> Final output sent to browser
DEBUG - 2018-02-02 12:50:47 --> Total execution time: 0.1187
INFO - 2018-02-02 07:20:50 --> Config Class Initialized
INFO - 2018-02-02 07:20:50 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:20:50 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:20:50 --> Utf8 Class Initialized
INFO - 2018-02-02 07:20:50 --> URI Class Initialized
INFO - 2018-02-02 07:20:50 --> Router Class Initialized
INFO - 2018-02-02 07:20:50 --> Config Class Initialized
INFO - 2018-02-02 07:20:50 --> Hooks Class Initialized
INFO - 2018-02-02 07:20:50 --> Output Class Initialized
INFO - 2018-02-02 07:20:50 --> Security Class Initialized
DEBUG - 2018-02-02 07:20:50 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:20:50 --> Utf8 Class Initialized
INFO - 2018-02-02 07:20:50 --> URI Class Initialized
DEBUG - 2018-02-02 07:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:20:50 --> Input Class Initialized
INFO - 2018-02-02 07:20:50 --> Language Class Initialized
INFO - 2018-02-02 07:20:50 --> Router Class Initialized
INFO - 2018-02-02 07:20:50 --> Output Class Initialized
INFO - 2018-02-02 07:20:50 --> Security Class Initialized
DEBUG - 2018-02-02 07:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:20:50 --> Input Class Initialized
INFO - 2018-02-02 07:20:50 --> Language Class Initialized
INFO - 2018-02-02 07:20:50 --> Language Class Initialized
INFO - 2018-02-02 07:20:50 --> Config Class Initialized
INFO - 2018-02-02 07:20:50 --> Loader Class Initialized
INFO - 2018-02-02 12:50:50 --> Helper loaded: url_helper
INFO - 2018-02-02 12:50:50 --> Helper loaded: notification_helper
INFO - 2018-02-02 12:50:50 --> Helper loaded: settings_helper
INFO - 2018-02-02 12:50:50 --> Helper loaded: permission_helper
INFO - 2018-02-02 12:50:50 --> Helper loaded: users_helper
INFO - 2018-02-02 07:20:50 --> Language Class Initialized
INFO - 2018-02-02 07:20:50 --> Config Class Initialized
INFO - 2018-02-02 07:20:50 --> Loader Class Initialized
INFO - 2018-02-02 12:50:50 --> Helper loaded: url_helper
INFO - 2018-02-02 12:50:50 --> Helper loaded: notification_helper
INFO - 2018-02-02 12:50:50 --> Helper loaded: settings_helper
INFO - 2018-02-02 12:50:50 --> Helper loaded: permission_helper
INFO - 2018-02-02 12:50:50 --> Helper loaded: users_helper
INFO - 2018-02-02 12:50:50 --> Database Driver Class Initialized
DEBUG - 2018-02-02 12:50:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 12:50:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 12:50:50 --> Database Driver Class Initialized
INFO - 2018-02-02 12:50:50 --> Helper loaded: form_helper
INFO - 2018-02-02 12:50:50 --> Form Validation Class Initialized
INFO - 2018-02-02 12:50:50 --> Controller Class Initialized
DEBUG - 2018-02-02 12:50:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 12:50:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 12:50:50 --> Model Class Initialized
INFO - 2018-02-02 12:50:50 --> Helper loaded: inflector_helper
INFO - 2018-02-02 12:50:50 --> Helper loaded: form_helper
INFO - 2018-02-02 12:50:50 --> Form Validation Class Initialized
INFO - 2018-02-02 12:50:50 --> Controller Class Initialized
DEBUG - 2018-02-02 12:50:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-02 12:50:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-02 12:50:50 --> Model Class Initialized
INFO - 2018-02-02 12:50:50 --> Model Class Initialized
INFO - 2018-02-02 12:50:50 --> Model Class Initialized
INFO - 2018-02-02 12:50:50 --> Model Class Initialized
INFO - 2018-02-02 12:50:50 --> Model Class Initialized
INFO - 2018-02-02 12:50:50 --> Model Class Initialized
INFO - 2018-02-02 12:50:50 --> Model Class Initialized
INFO - 2018-02-02 12:50:50 --> Model Class Initialized
INFO - 2018-02-02 12:50:50 --> Model Class Initialized
INFO - 2018-02-02 12:50:50 --> Model Class Initialized
INFO - 2018-02-02 12:50:50 --> Model Class Initialized
INFO - 2018-02-02 12:50:50 --> Model Class Initialized
INFO - 2018-02-02 12:50:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-02 12:50:50 --> Helper loaded: inflector_helper
DEBUG - 2018-02-02 12:50:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-02 12:50:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-02 12:50:50 --> Model Class Initialized
INFO - 2018-02-02 12:50:50 --> Model Class Initialized
INFO - 2018-02-02 12:50:50 --> Model Class Initialized
INFO - 2018-02-02 12:50:50 --> Model Class Initialized
INFO - 2018-02-02 12:50:50 --> Model Class Initialized
INFO - 2018-02-02 12:50:50 --> Model Class Initialized
INFO - 2018-02-02 12:50:50 --> Model Class Initialized
INFO - 2018-02-02 12:50:50 --> Model Class Initialized
INFO - 2018-02-02 12:50:50 --> Model Class Initialized
INFO - 2018-02-02 12:50:50 --> Final output sent to browser
DEBUG - 2018-02-02 12:50:50 --> Total execution time: 0.1164
INFO - 2018-02-02 12:50:50 --> Model Class Initialized
INFO - 2018-02-02 12:50:50 --> Model Class Initialized
INFO - 2018-02-02 12:50:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-02 12:50:50 --> Model Class Initialized
INFO - 2018-02-02 12:50:50 --> Final output sent to browser
DEBUG - 2018-02-02 12:50:50 --> Total execution time: 0.1376
INFO - 2018-02-02 07:20:52 --> Config Class Initialized
INFO - 2018-02-02 07:20:52 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:20:52 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:20:52 --> Utf8 Class Initialized
INFO - 2018-02-02 07:20:52 --> Config Class Initialized
INFO - 2018-02-02 07:20:52 --> Hooks Class Initialized
INFO - 2018-02-02 07:20:52 --> URI Class Initialized
DEBUG - 2018-02-02 07:20:52 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:20:52 --> Utf8 Class Initialized
INFO - 2018-02-02 07:20:52 --> Config Class Initialized
INFO - 2018-02-02 07:20:52 --> Hooks Class Initialized
INFO - 2018-02-02 07:20:52 --> URI Class Initialized
INFO - 2018-02-02 07:20:52 --> Router Class Initialized
DEBUG - 2018-02-02 07:20:52 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:20:52 --> Utf8 Class Initialized
INFO - 2018-02-02 07:20:52 --> URI Class Initialized
INFO - 2018-02-02 07:20:52 --> Output Class Initialized
INFO - 2018-02-02 07:20:52 --> Router Class Initialized
INFO - 2018-02-02 07:20:52 --> Security Class Initialized
INFO - 2018-02-02 07:20:52 --> Router Class Initialized
INFO - 2018-02-02 07:20:52 --> Output Class Initialized
DEBUG - 2018-02-02 07:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:20:52 --> Input Class Initialized
INFO - 2018-02-02 07:20:52 --> Security Class Initialized
INFO - 2018-02-02 07:20:52 --> Output Class Initialized
INFO - 2018-02-02 07:20:52 --> Language Class Initialized
INFO - 2018-02-02 07:20:52 --> Security Class Initialized
DEBUG - 2018-02-02 07:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:20:52 --> Input Class Initialized
INFO - 2018-02-02 07:20:52 --> Language Class Initialized
DEBUG - 2018-02-02 07:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:20:52 --> Input Class Initialized
INFO - 2018-02-02 07:20:52 --> Language Class Initialized
INFO - 2018-02-02 07:20:52 --> Language Class Initialized
INFO - 2018-02-02 07:20:52 --> Config Class Initialized
INFO - 2018-02-02 07:20:52 --> Loader Class Initialized
INFO - 2018-02-02 07:20:52 --> Language Class Initialized
INFO - 2018-02-02 07:20:52 --> Config Class Initialized
INFO - 2018-02-02 07:20:52 --> Loader Class Initialized
INFO - 2018-02-02 12:50:52 --> Helper loaded: url_helper
INFO - 2018-02-02 12:50:52 --> Helper loaded: notification_helper
INFO - 2018-02-02 12:50:52 --> Helper loaded: settings_helper
INFO - 2018-02-02 12:50:52 --> Helper loaded: url_helper
INFO - 2018-02-02 12:50:52 --> Helper loaded: permission_helper
INFO - 2018-02-02 12:50:52 --> Helper loaded: notification_helper
INFO - 2018-02-02 12:50:52 --> Helper loaded: users_helper
INFO - 2018-02-02 07:20:52 --> Language Class Initialized
INFO - 2018-02-02 07:20:52 --> Config Class Initialized
INFO - 2018-02-02 07:20:52 --> Loader Class Initialized
INFO - 2018-02-02 12:50:52 --> Helper loaded: settings_helper
INFO - 2018-02-02 12:50:52 --> Helper loaded: permission_helper
INFO - 2018-02-02 12:50:52 --> Helper loaded: users_helper
INFO - 2018-02-02 12:50:52 --> Helper loaded: url_helper
INFO - 2018-02-02 12:50:52 --> Helper loaded: notification_helper
INFO - 2018-02-02 12:50:52 --> Helper loaded: settings_helper
INFO - 2018-02-02 12:50:52 --> Helper loaded: permission_helper
INFO - 2018-02-02 12:50:52 --> Helper loaded: users_helper
INFO - 2018-02-02 12:50:52 --> Database Driver Class Initialized
INFO - 2018-02-02 12:50:52 --> Database Driver Class Initialized
DEBUG - 2018-02-02 12:50:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 12:50:52 --> Database Driver Class Initialized
INFO - 2018-02-02 12:50:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-02 12:50:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 12:50:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-02 12:50:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 12:50:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 12:50:52 --> Helper loaded: form_helper
INFO - 2018-02-02 12:50:52 --> Form Validation Class Initialized
INFO - 2018-02-02 12:50:52 --> Controller Class Initialized
INFO - 2018-02-02 12:50:52 --> Helper loaded: form_helper
INFO - 2018-02-02 12:50:52 --> Form Validation Class Initialized
INFO - 2018-02-02 12:50:52 --> Controller Class Initialized
INFO - 2018-02-02 12:50:52 --> Helper loaded: form_helper
INFO - 2018-02-02 12:50:52 --> Form Validation Class Initialized
INFO - 2018-02-02 12:50:52 --> Controller Class Initialized
INFO - 2018-02-02 12:50:52 --> Model Class Initialized
INFO - 2018-02-02 12:50:52 --> Helper loaded: inflector_helper
INFO - 2018-02-02 12:50:52 --> Model Class Initialized
DEBUG - 2018-02-02 12:50:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-02 12:50:52 --> Model Class Initialized
INFO - 2018-02-02 12:50:52 --> Helper loaded: inflector_helper
INFO - 2018-02-02 12:50:52 --> Helper loaded: inflector_helper
INFO - 2018-02-02 12:50:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-02 12:50:52 --> Model Class Initialized
INFO - 2018-02-02 12:50:52 --> Model Class Initialized
INFO - 2018-02-02 12:50:52 --> Model Class Initialized
DEBUG - 2018-02-02 12:50:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-02 12:50:52 --> Model Class Initialized
DEBUG - 2018-02-02 12:50:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-02 12:50:52 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-02 12:50:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-02 12:50:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-02 12:50:52 --> Model Class Initialized
INFO - 2018-02-02 12:50:52 --> Model Class Initialized
INFO - 2018-02-02 12:50:52 --> Model Class Initialized
INFO - 2018-02-02 12:50:52 --> Model Class Initialized
INFO - 2018-02-02 12:50:52 --> Model Class Initialized
INFO - 2018-02-02 12:50:52 --> Model Class Initialized
INFO - 2018-02-02 12:50:52 --> Model Class Initialized
INFO - 2018-02-02 12:50:52 --> Model Class Initialized
INFO - 2018-02-02 12:50:52 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-02 12:50:52 --> Model Class Initialized
INFO - 2018-02-02 12:50:52 --> Model Class Initialized
INFO - 2018-02-02 12:50:52 --> Model Class Initialized
INFO - 2018-02-02 12:50:52 --> Model Class Initialized
INFO - 2018-02-02 12:50:52 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-02-02 12:50:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1410
INFO - 2018-02-02 12:50:52 --> Final output sent to browser
DEBUG - 2018-02-02 12:50:52 --> Total execution time: 0.1152
INFO - 2018-02-02 12:50:52 --> Final output sent to browser
DEBUG - 2018-02-02 12:50:52 --> Total execution time: 0.1113
ERROR - 2018-02-02 12:50:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 553
INFO - 2018-02-02 12:50:52 --> Final output sent to browser
DEBUG - 2018-02-02 12:50:52 --> Total execution time: 0.1226
INFO - 2018-02-02 07:20:53 --> Config Class Initialized
INFO - 2018-02-02 07:20:53 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:20:53 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:20:53 --> Utf8 Class Initialized
INFO - 2018-02-02 07:20:53 --> URI Class Initialized
INFO - 2018-02-02 07:20:53 --> Router Class Initialized
INFO - 2018-02-02 07:20:53 --> Output Class Initialized
INFO - 2018-02-02 07:20:53 --> Security Class Initialized
DEBUG - 2018-02-02 07:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:20:53 --> Input Class Initialized
INFO - 2018-02-02 07:20:53 --> Language Class Initialized
INFO - 2018-02-02 07:20:53 --> Language Class Initialized
INFO - 2018-02-02 07:20:53 --> Config Class Initialized
INFO - 2018-02-02 07:20:53 --> Loader Class Initialized
INFO - 2018-02-02 12:50:53 --> Helper loaded: url_helper
INFO - 2018-02-02 12:50:53 --> Helper loaded: notification_helper
INFO - 2018-02-02 12:50:53 --> Helper loaded: settings_helper
INFO - 2018-02-02 07:20:53 --> Config Class Initialized
INFO - 2018-02-02 07:20:53 --> Hooks Class Initialized
INFO - 2018-02-02 12:50:53 --> Helper loaded: permission_helper
INFO - 2018-02-02 12:50:53 --> Helper loaded: users_helper
DEBUG - 2018-02-02 07:20:53 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:20:53 --> Utf8 Class Initialized
INFO - 2018-02-02 07:20:53 --> URI Class Initialized
INFO - 2018-02-02 07:20:53 --> Router Class Initialized
INFO - 2018-02-02 07:20:53 --> Output Class Initialized
INFO - 2018-02-02 07:20:53 --> Security Class Initialized
INFO - 2018-02-02 12:50:53 --> Database Driver Class Initialized
DEBUG - 2018-02-02 07:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:20:53 --> Input Class Initialized
INFO - 2018-02-02 07:20:53 --> Language Class Initialized
DEBUG - 2018-02-02 12:50:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 12:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 12:50:53 --> Helper loaded: form_helper
INFO - 2018-02-02 12:50:53 --> Form Validation Class Initialized
INFO - 2018-02-02 12:50:53 --> Controller Class Initialized
INFO - 2018-02-02 07:20:53 --> Language Class Initialized
INFO - 2018-02-02 07:20:53 --> Config Class Initialized
INFO - 2018-02-02 07:20:53 --> Loader Class Initialized
INFO - 2018-02-02 12:50:53 --> Model Class Initialized
INFO - 2018-02-02 12:50:53 --> Helper loaded: url_helper
INFO - 2018-02-02 12:50:53 --> Helper loaded: inflector_helper
INFO - 2018-02-02 12:50:53 --> Helper loaded: notification_helper
INFO - 2018-02-02 12:50:53 --> Helper loaded: settings_helper
INFO - 2018-02-02 12:50:53 --> Helper loaded: permission_helper
INFO - 2018-02-02 12:50:53 --> Helper loaded: users_helper
DEBUG - 2018-02-02 12:50:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-02 12:50:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-02 12:50:53 --> Model Class Initialized
INFO - 2018-02-02 12:50:53 --> Model Class Initialized
INFO - 2018-02-02 12:50:53 --> Model Class Initialized
INFO - 2018-02-02 12:50:53 --> Model Class Initialized
INFO - 2018-02-02 12:50:53 --> Model Class Initialized
INFO - 2018-02-02 12:50:53 --> Model Class Initialized
INFO - 2018-02-02 12:50:53 --> Model Class Initialized
INFO - 2018-02-02 12:50:53 --> Model Class Initialized
INFO - 2018-02-02 12:50:53 --> Model Class Initialized
INFO - 2018-02-02 12:50:53 --> Model Class Initialized
INFO - 2018-02-02 12:50:53 --> Model Class Initialized
INFO - 2018-02-02 12:50:53 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-02 12:50:53 --> Model Class Initialized
INFO - 2018-02-02 12:50:53 --> Database Driver Class Initialized
DEBUG - 2018-02-02 12:50:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 12:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 12:50:53 --> Helper loaded: form_helper
INFO - 2018-02-02 12:50:53 --> Form Validation Class Initialized
INFO - 2018-02-02 12:50:53 --> Controller Class Initialized
INFO - 2018-02-02 12:50:53 --> Final output sent to browser
DEBUG - 2018-02-02 12:50:53 --> Total execution time: 0.1438
INFO - 2018-02-02 12:50:53 --> Model Class Initialized
INFO - 2018-02-02 12:50:53 --> Helper loaded: inflector_helper
DEBUG - 2018-02-02 12:50:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-02 12:50:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-02 12:50:53 --> Model Class Initialized
INFO - 2018-02-02 12:50:53 --> Model Class Initialized
INFO - 2018-02-02 12:50:53 --> Model Class Initialized
INFO - 2018-02-02 12:50:53 --> Model Class Initialized
INFO - 2018-02-02 12:50:53 --> Model Class Initialized
INFO - 2018-02-02 12:50:53 --> Model Class Initialized
INFO - 2018-02-02 12:50:53 --> Model Class Initialized
INFO - 2018-02-02 12:50:53 --> Model Class Initialized
INFO - 2018-02-02 12:50:53 --> Model Class Initialized
INFO - 2018-02-02 12:50:53 --> Model Class Initialized
INFO - 2018-02-02 12:50:53 --> Model Class Initialized
INFO - 2018-02-02 12:50:53 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-02 12:50:53 --> Final output sent to browser
DEBUG - 2018-02-02 12:50:53 --> Total execution time: 0.1288
INFO - 2018-02-02 07:21:08 --> Config Class Initialized
INFO - 2018-02-02 07:21:08 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:21:08 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:21:08 --> Utf8 Class Initialized
INFO - 2018-02-02 07:21:08 --> URI Class Initialized
INFO - 2018-02-02 07:21:08 --> Router Class Initialized
INFO - 2018-02-02 07:21:08 --> Output Class Initialized
INFO - 2018-02-02 07:21:08 --> Security Class Initialized
DEBUG - 2018-02-02 07:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:21:08 --> Input Class Initialized
INFO - 2018-02-02 07:21:08 --> Language Class Initialized
INFO - 2018-02-02 07:21:08 --> Language Class Initialized
INFO - 2018-02-02 07:21:08 --> Config Class Initialized
INFO - 2018-02-02 07:21:08 --> Loader Class Initialized
INFO - 2018-02-02 12:51:08 --> Helper loaded: url_helper
INFO - 2018-02-02 12:51:08 --> Helper loaded: notification_helper
INFO - 2018-02-02 12:51:08 --> Helper loaded: settings_helper
INFO - 2018-02-02 12:51:08 --> Helper loaded: permission_helper
INFO - 2018-02-02 12:51:08 --> Helper loaded: users_helper
INFO - 2018-02-02 12:51:08 --> Database Driver Class Initialized
DEBUG - 2018-02-02 12:51:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 12:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 12:51:08 --> Helper loaded: form_helper
INFO - 2018-02-02 12:51:08 --> Form Validation Class Initialized
INFO - 2018-02-02 12:51:08 --> Controller Class Initialized
INFO - 2018-02-02 12:51:08 --> Model Class Initialized
INFO - 2018-02-02 12:51:08 --> Helper loaded: inflector_helper
DEBUG - 2018-02-02 12:51:08 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-02 12:51:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-02 12:51:08 --> Model Class Initialized
INFO - 2018-02-02 12:51:08 --> Model Class Initialized
INFO - 2018-02-02 12:51:08 --> Model Class Initialized
INFO - 2018-02-02 12:51:08 --> Model Class Initialized
INFO - 2018-02-02 12:51:08 --> Model Class Initialized
INFO - 2018-02-02 12:51:08 --> Model Class Initialized
INFO - 2018-02-02 12:51:08 --> Model Class Initialized
INFO - 2018-02-02 12:51:08 --> Model Class Initialized
INFO - 2018-02-02 12:51:08 --> Model Class Initialized
INFO - 2018-02-02 12:51:08 --> Model Class Initialized
INFO - 2018-02-02 12:51:08 --> Model Class Initialized
INFO - 2018-02-02 12:51:08 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-02 12:51:08 --> Final output sent to browser
DEBUG - 2018-02-02 12:51:08 --> Total execution time: 0.1268
INFO - 2018-02-02 07:21:12 --> Config Class Initialized
INFO - 2018-02-02 07:21:12 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:21:12 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:21:12 --> Utf8 Class Initialized
INFO - 2018-02-02 07:21:12 --> URI Class Initialized
INFO - 2018-02-02 07:21:12 --> Router Class Initialized
INFO - 2018-02-02 07:21:12 --> Output Class Initialized
INFO - 2018-02-02 07:21:12 --> Security Class Initialized
DEBUG - 2018-02-02 07:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:21:12 --> Input Class Initialized
INFO - 2018-02-02 07:21:12 --> Language Class Initialized
INFO - 2018-02-02 07:21:12 --> Language Class Initialized
INFO - 2018-02-02 07:21:12 --> Config Class Initialized
INFO - 2018-02-02 07:21:12 --> Loader Class Initialized
INFO - 2018-02-02 12:51:12 --> Helper loaded: url_helper
INFO - 2018-02-02 12:51:12 --> Helper loaded: notification_helper
INFO - 2018-02-02 12:51:12 --> Helper loaded: settings_helper
INFO - 2018-02-02 12:51:12 --> Helper loaded: permission_helper
INFO - 2018-02-02 12:51:12 --> Helper loaded: users_helper
INFO - 2018-02-02 12:51:12 --> Database Driver Class Initialized
DEBUG - 2018-02-02 12:51:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 12:51:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 12:51:12 --> Helper loaded: form_helper
INFO - 2018-02-02 12:51:12 --> Form Validation Class Initialized
INFO - 2018-02-02 12:51:12 --> Controller Class Initialized
INFO - 2018-02-02 12:51:12 --> Model Class Initialized
INFO - 2018-02-02 12:51:12 --> Helper loaded: inflector_helper
DEBUG - 2018-02-02 12:51:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-02 12:51:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-02 12:51:12 --> Model Class Initialized
INFO - 2018-02-02 12:51:12 --> Model Class Initialized
INFO - 2018-02-02 12:51:12 --> Model Class Initialized
INFO - 2018-02-02 12:51:12 --> Model Class Initialized
INFO - 2018-02-02 12:51:12 --> Model Class Initialized
INFO - 2018-02-02 12:51:12 --> Model Class Initialized
INFO - 2018-02-02 12:51:12 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-02-02 12:51:12 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 771
INFO - 2018-02-02 12:51:12 --> Final output sent to browser
DEBUG - 2018-02-02 12:51:12 --> Total execution time: 0.1050
INFO - 2018-02-02 07:21:14 --> Config Class Initialized
INFO - 2018-02-02 07:21:14 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:21:14 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:21:14 --> Utf8 Class Initialized
INFO - 2018-02-02 07:21:14 --> URI Class Initialized
INFO - 2018-02-02 07:21:14 --> Config Class Initialized
INFO - 2018-02-02 07:21:14 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:21:14 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:21:14 --> Utf8 Class Initialized
INFO - 2018-02-02 07:21:14 --> Router Class Initialized
INFO - 2018-02-02 07:21:14 --> URI Class Initialized
INFO - 2018-02-02 07:21:14 --> Output Class Initialized
INFO - 2018-02-02 07:21:14 --> Security Class Initialized
INFO - 2018-02-02 07:21:14 --> Router Class Initialized
DEBUG - 2018-02-02 07:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:21:14 --> Input Class Initialized
INFO - 2018-02-02 07:21:14 --> Language Class Initialized
INFO - 2018-02-02 07:21:14 --> Output Class Initialized
INFO - 2018-02-02 07:21:14 --> Security Class Initialized
DEBUG - 2018-02-02 07:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:21:14 --> Input Class Initialized
INFO - 2018-02-02 07:21:14 --> Language Class Initialized
INFO - 2018-02-02 07:21:14 --> Language Class Initialized
INFO - 2018-02-02 07:21:14 --> Config Class Initialized
INFO - 2018-02-02 07:21:14 --> Loader Class Initialized
INFO - 2018-02-02 12:51:14 --> Helper loaded: url_helper
INFO - 2018-02-02 12:51:14 --> Helper loaded: notification_helper
INFO - 2018-02-02 12:51:14 --> Helper loaded: settings_helper
INFO - 2018-02-02 12:51:14 --> Helper loaded: permission_helper
INFO - 2018-02-02 12:51:14 --> Helper loaded: users_helper
INFO - 2018-02-02 07:21:14 --> Language Class Initialized
INFO - 2018-02-02 07:21:14 --> Config Class Initialized
INFO - 2018-02-02 07:21:14 --> Loader Class Initialized
INFO - 2018-02-02 12:51:14 --> Helper loaded: url_helper
INFO - 2018-02-02 12:51:14 --> Helper loaded: notification_helper
INFO - 2018-02-02 12:51:14 --> Helper loaded: settings_helper
INFO - 2018-02-02 12:51:14 --> Helper loaded: permission_helper
INFO - 2018-02-02 12:51:14 --> Helper loaded: users_helper
INFO - 2018-02-02 12:51:14 --> Database Driver Class Initialized
INFO - 2018-02-02 07:21:14 --> Config Class Initialized
INFO - 2018-02-02 07:21:14 --> Hooks Class Initialized
DEBUG - 2018-02-02 12:51:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 12:51:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-02 07:21:14 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:21:14 --> Utf8 Class Initialized
INFO - 2018-02-02 07:21:14 --> URI Class Initialized
INFO - 2018-02-02 12:51:14 --> Helper loaded: form_helper
INFO - 2018-02-02 12:51:14 --> Form Validation Class Initialized
INFO - 2018-02-02 12:51:14 --> Controller Class Initialized
INFO - 2018-02-02 12:51:14 --> Database Driver Class Initialized
INFO - 2018-02-02 07:21:14 --> Router Class Initialized
INFO - 2018-02-02 07:21:14 --> Output Class Initialized
INFO - 2018-02-02 12:51:14 --> Model Class Initialized
INFO - 2018-02-02 12:51:14 --> Helper loaded: inflector_helper
DEBUG - 2018-02-02 12:51:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 12:51:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-02 12:51:14 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-02 07:21:14 --> Security Class Initialized
INFO - 2018-02-02 12:51:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-02 12:51:14 --> Model Class Initialized
INFO - 2018-02-02 12:51:14 --> Model Class Initialized
DEBUG - 2018-02-02 07:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:21:14 --> Input Class Initialized
INFO - 2018-02-02 12:51:14 --> Model Class Initialized
INFO - 2018-02-02 07:21:14 --> Language Class Initialized
INFO - 2018-02-02 12:51:14 --> Helper loaded: form_helper
INFO - 2018-02-02 12:51:14 --> Model Class Initialized
INFO - 2018-02-02 12:51:14 --> Form Validation Class Initialized
INFO - 2018-02-02 12:51:14 --> Controller Class Initialized
INFO - 2018-02-02 12:51:14 --> Model Class Initialized
INFO - 2018-02-02 12:51:14 --> Model Class Initialized
INFO - 2018-02-02 12:51:14 --> Model Class Initialized
INFO - 2018-02-02 12:51:14 --> Model Class Initialized
INFO - 2018-02-02 12:51:14 --> Model Class Initialized
INFO - 2018-02-02 12:51:14 --> Model Class Initialized
INFO - 2018-02-02 12:51:14 --> Model Class Initialized
INFO - 2018-02-02 12:51:14 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-02 12:51:14 --> Model Class Initialized
INFO - 2018-02-02 12:51:14 --> Helper loaded: inflector_helper
DEBUG - 2018-02-02 12:51:14 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-02 12:51:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-02 12:51:14 --> Model Class Initialized
INFO - 2018-02-02 12:51:14 --> Model Class Initialized
INFO - 2018-02-02 07:21:14 --> Language Class Initialized
INFO - 2018-02-02 07:21:14 --> Config Class Initialized
INFO - 2018-02-02 07:21:14 --> Loader Class Initialized
INFO - 2018-02-02 12:51:14 --> Model Class Initialized
INFO - 2018-02-02 12:51:14 --> Model Class Initialized
INFO - 2018-02-02 12:51:14 --> Model Class Initialized
INFO - 2018-02-02 12:51:14 --> Model Class Initialized
INFO - 2018-02-02 12:51:14 --> Helper loaded: url_helper
INFO - 2018-02-02 12:51:14 --> Model Class Initialized
INFO - 2018-02-02 12:51:14 --> Model Class Initialized
INFO - 2018-02-02 12:51:14 --> Helper loaded: notification_helper
INFO - 2018-02-02 12:51:14 --> Model Class Initialized
INFO - 2018-02-02 12:51:14 --> Model Class Initialized
INFO - 2018-02-02 12:51:14 --> Helper loaded: settings_helper
INFO - 2018-02-02 12:51:14 --> Final output sent to browser
DEBUG - 2018-02-02 12:51:14 --> Total execution time: 0.1131
INFO - 2018-02-02 12:51:14 --> Helper loaded: permission_helper
INFO - 2018-02-02 12:51:14 --> Helper loaded: users_helper
INFO - 2018-02-02 12:51:14 --> Model Class Initialized
INFO - 2018-02-02 12:51:14 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-02 12:51:14 --> Model Class Initialized
INFO - 2018-02-02 12:51:14 --> Database Driver Class Initialized
DEBUG - 2018-02-02 12:51:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 12:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 12:51:14 --> Helper loaded: form_helper
INFO - 2018-02-02 12:51:14 --> Form Validation Class Initialized
INFO - 2018-02-02 12:51:14 --> Controller Class Initialized
INFO - 2018-02-02 12:51:14 --> Final output sent to browser
DEBUG - 2018-02-02 12:51:14 --> Total execution time: 0.1459
INFO - 2018-02-02 12:51:14 --> Model Class Initialized
INFO - 2018-02-02 12:51:14 --> Helper loaded: inflector_helper
DEBUG - 2018-02-02 12:51:14 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-02 12:51:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-02 12:51:14 --> Model Class Initialized
INFO - 2018-02-02 12:51:14 --> Model Class Initialized
INFO - 2018-02-02 12:51:14 --> Model Class Initialized
INFO - 2018-02-02 12:51:14 --> Model Class Initialized
INFO - 2018-02-02 12:51:14 --> Model Class Initialized
INFO - 2018-02-02 12:51:14 --> Model Class Initialized
INFO - 2018-02-02 12:51:14 --> Model Class Initialized
INFO - 2018-02-02 12:51:14 --> Model Class Initialized
INFO - 2018-02-02 12:51:14 --> Model Class Initialized
INFO - 2018-02-02 12:51:14 --> Model Class Initialized
INFO - 2018-02-02 12:51:14 --> Model Class Initialized
INFO - 2018-02-02 12:51:14 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-02 12:51:14 --> Final output sent to browser
DEBUG - 2018-02-02 12:51:14 --> Total execution time: 0.1267
INFO - 2018-02-02 07:21:15 --> Config Class Initialized
INFO - 2018-02-02 07:21:15 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:21:15 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:21:15 --> Utf8 Class Initialized
INFO - 2018-02-02 07:21:15 --> URI Class Initialized
INFO - 2018-02-02 07:21:15 --> Router Class Initialized
INFO - 2018-02-02 07:21:15 --> Output Class Initialized
INFO - 2018-02-02 07:21:15 --> Security Class Initialized
DEBUG - 2018-02-02 07:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:21:15 --> Input Class Initialized
INFO - 2018-02-02 07:21:15 --> Language Class Initialized
INFO - 2018-02-02 07:21:15 --> Language Class Initialized
INFO - 2018-02-02 07:21:15 --> Config Class Initialized
INFO - 2018-02-02 07:21:15 --> Loader Class Initialized
INFO - 2018-02-02 12:51:15 --> Helper loaded: url_helper
INFO - 2018-02-02 12:51:15 --> Helper loaded: notification_helper
INFO - 2018-02-02 12:51:15 --> Helper loaded: settings_helper
INFO - 2018-02-02 12:51:15 --> Helper loaded: permission_helper
INFO - 2018-02-02 12:51:15 --> Helper loaded: users_helper
INFO - 2018-02-02 12:51:15 --> Database Driver Class Initialized
DEBUG - 2018-02-02 12:51:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 12:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 12:51:15 --> Helper loaded: form_helper
INFO - 2018-02-02 12:51:15 --> Form Validation Class Initialized
INFO - 2018-02-02 12:51:15 --> Controller Class Initialized
INFO - 2018-02-02 12:51:15 --> Model Class Initialized
INFO - 2018-02-02 12:51:15 --> Helper loaded: inflector_helper
DEBUG - 2018-02-02 12:51:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-02 12:51:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-02 12:51:15 --> Model Class Initialized
INFO - 2018-02-02 12:51:15 --> Model Class Initialized
INFO - 2018-02-02 12:51:15 --> Model Class Initialized
INFO - 2018-02-02 12:51:15 --> Model Class Initialized
INFO - 2018-02-02 12:51:15 --> Model Class Initialized
INFO - 2018-02-02 12:51:15 --> Model Class Initialized
INFO - 2018-02-02 12:51:15 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-02 12:51:15 --> Final output sent to browser
DEBUG - 2018-02-02 12:51:15 --> Total execution time: 0.1054
INFO - 2018-02-02 07:55:27 --> Config Class Initialized
INFO - 2018-02-02 07:55:27 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:55:27 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:55:27 --> Utf8 Class Initialized
INFO - 2018-02-02 07:55:27 --> URI Class Initialized
INFO - 2018-02-02 07:55:27 --> Router Class Initialized
INFO - 2018-02-02 07:55:27 --> Output Class Initialized
INFO - 2018-02-02 07:55:27 --> Security Class Initialized
DEBUG - 2018-02-02 07:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:55:27 --> Input Class Initialized
INFO - 2018-02-02 07:55:27 --> Language Class Initialized
INFO - 2018-02-02 07:55:27 --> Language Class Initialized
INFO - 2018-02-02 07:55:27 --> Config Class Initialized
INFO - 2018-02-02 07:55:27 --> Loader Class Initialized
INFO - 2018-02-02 13:25:27 --> Helper loaded: url_helper
INFO - 2018-02-02 13:25:27 --> Helper loaded: notification_helper
INFO - 2018-02-02 13:25:27 --> Helper loaded: settings_helper
INFO - 2018-02-02 13:25:27 --> Helper loaded: permission_helper
INFO - 2018-02-02 13:25:27 --> Helper loaded: users_helper
INFO - 2018-02-02 07:55:27 --> Config Class Initialized
INFO - 2018-02-02 07:55:27 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:55:27 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:55:27 --> Utf8 Class Initialized
INFO - 2018-02-02 07:55:27 --> URI Class Initialized
INFO - 2018-02-02 07:55:27 --> Router Class Initialized
INFO - 2018-02-02 07:55:27 --> Output Class Initialized
INFO - 2018-02-02 13:25:27 --> Database Driver Class Initialized
INFO - 2018-02-02 07:55:27 --> Security Class Initialized
DEBUG - 2018-02-02 07:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:55:27 --> Input Class Initialized
INFO - 2018-02-02 07:55:27 --> Language Class Initialized
DEBUG - 2018-02-02 13:25:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 13:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 07:55:27 --> Config Class Initialized
INFO - 2018-02-02 07:55:27 --> Hooks Class Initialized
INFO - 2018-02-02 13:25:27 --> Helper loaded: form_helper
INFO - 2018-02-02 13:25:27 --> Form Validation Class Initialized
INFO - 2018-02-02 13:25:27 --> Controller Class Initialized
DEBUG - 2018-02-02 07:55:27 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:55:27 --> Utf8 Class Initialized
INFO - 2018-02-02 07:55:27 --> URI Class Initialized
INFO - 2018-02-02 07:55:27 --> Router Class Initialized
INFO - 2018-02-02 07:55:27 --> Language Class Initialized
INFO - 2018-02-02 07:55:27 --> Config Class Initialized
INFO - 2018-02-02 07:55:27 --> Loader Class Initialized
INFO - 2018-02-02 13:25:27 --> Model Class Initialized
INFO - 2018-02-02 07:55:27 --> Output Class Initialized
INFO - 2018-02-02 13:25:27 --> Helper loaded: inflector_helper
INFO - 2018-02-02 13:25:27 --> Helper loaded: url_helper
INFO - 2018-02-02 13:25:27 --> Helper loaded: notification_helper
INFO - 2018-02-02 07:55:27 --> Security Class Initialized
INFO - 2018-02-02 13:25:27 --> Helper loaded: settings_helper
DEBUG - 2018-02-02 13:25:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-02 13:25:27 --> Helper loaded: permission_helper
INFO - 2018-02-02 13:25:27 --> Helper loaded: users_helper
DEBUG - 2018-02-02 07:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:55:27 --> Input Class Initialized
INFO - 2018-02-02 13:25:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-02 07:55:27 --> Language Class Initialized
INFO - 2018-02-02 13:25:27 --> Model Class Initialized
INFO - 2018-02-02 07:55:27 --> Config Class Initialized
INFO - 2018-02-02 07:55:27 --> Hooks Class Initialized
INFO - 2018-02-02 07:55:27 --> Config Class Initialized
INFO - 2018-02-02 13:25:27 --> Model Class Initialized
INFO - 2018-02-02 07:55:27 --> Hooks Class Initialized
INFO - 2018-02-02 13:25:27 --> Model Class Initialized
INFO - 2018-02-02 13:25:27 --> Model Class Initialized
INFO - 2018-02-02 13:25:27 --> Model Class Initialized
INFO - 2018-02-02 13:25:27 --> Model Class Initialized
INFO - 2018-02-02 13:25:27 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-02-02 07:55:27 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:55:27 --> Utf8 Class Initialized
DEBUG - 2018-02-02 07:55:27 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:55:27 --> Utf8 Class Initialized
INFO - 2018-02-02 07:55:27 --> URI Class Initialized
INFO - 2018-02-02 07:55:27 --> URI Class Initialized
INFO - 2018-02-02 13:25:27 --> Final output sent to browser
DEBUG - 2018-02-02 13:25:27 --> Total execution time: 0.1137
INFO - 2018-02-02 07:55:27 --> Router Class Initialized
INFO - 2018-02-02 07:55:27 --> Router Class Initialized
INFO - 2018-02-02 13:25:27 --> Database Driver Class Initialized
INFO - 2018-02-02 07:55:27 --> Output Class Initialized
INFO - 2018-02-02 07:55:27 --> Output Class Initialized
INFO - 2018-02-02 07:55:27 --> Security Class Initialized
INFO - 2018-02-02 07:55:27 --> Security Class Initialized
DEBUG - 2018-02-02 13:25:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 13:25:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-02 07:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:55:27 --> Input Class Initialized
DEBUG - 2018-02-02 07:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:55:27 --> Input Class Initialized
INFO - 2018-02-02 07:55:27 --> Language Class Initialized
INFO - 2018-02-02 07:55:27 --> Config Class Initialized
INFO - 2018-02-02 07:55:27 --> Loader Class Initialized
INFO - 2018-02-02 07:55:27 --> Language Class Initialized
INFO - 2018-02-02 07:55:27 --> Language Class Initialized
INFO - 2018-02-02 13:25:27 --> Helper loaded: url_helper
INFO - 2018-02-02 13:25:27 --> Helper loaded: notification_helper
INFO - 2018-02-02 13:25:27 --> Helper loaded: form_helper
INFO - 2018-02-02 13:25:27 --> Form Validation Class Initialized
INFO - 2018-02-02 13:25:27 --> Controller Class Initialized
INFO - 2018-02-02 13:25:27 --> Helper loaded: settings_helper
INFO - 2018-02-02 13:25:27 --> Helper loaded: permission_helper
INFO - 2018-02-02 13:25:27 --> Helper loaded: users_helper
INFO - 2018-02-02 13:25:27 --> Model Class Initialized
INFO - 2018-02-02 13:25:27 --> Helper loaded: inflector_helper
DEBUG - 2018-02-02 13:25:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-02 13:25:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-02 13:25:27 --> Model Class Initialized
INFO - 2018-02-02 07:55:27 --> Language Class Initialized
INFO - 2018-02-02 13:25:27 --> Model Class Initialized
INFO - 2018-02-02 07:55:27 --> Config Class Initialized
INFO - 2018-02-02 07:55:27 --> Loader Class Initialized
INFO - 2018-02-02 13:25:27 --> Model Class Initialized
INFO - 2018-02-02 13:25:27 --> Database Driver Class Initialized
INFO - 2018-02-02 13:25:27 --> Model Class Initialized
INFO - 2018-02-02 13:25:27 --> Model Class Initialized
INFO - 2018-02-02 13:25:27 --> Helper loaded: url_helper
INFO - 2018-02-02 13:25:27 --> Model Class Initialized
INFO - 2018-02-02 13:25:27 --> Model Class Initialized
INFO - 2018-02-02 07:55:27 --> Language Class Initialized
INFO - 2018-02-02 07:55:27 --> Config Class Initialized
INFO - 2018-02-02 07:55:27 --> Loader Class Initialized
INFO - 2018-02-02 13:25:27 --> Model Class Initialized
INFO - 2018-02-02 13:25:27 --> Helper loaded: notification_helper
INFO - 2018-02-02 13:25:27 --> Model Class Initialized
INFO - 2018-02-02 13:25:27 --> Model Class Initialized
INFO - 2018-02-02 13:25:27 --> Helper loaded: settings_helper
INFO - 2018-02-02 13:25:27 --> Helper loaded: permission_helper
INFO - 2018-02-02 13:25:27 --> Helper loaded: users_helper
INFO - 2018-02-02 13:25:27 --> Helper loaded: url_helper
DEBUG - 2018-02-02 13:25:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 13:25:27 --> Helper loaded: notification_helper
INFO - 2018-02-02 13:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 13:25:27 --> Model Class Initialized
INFO - 2018-02-02 13:25:27 --> Helper loaded: settings_helper
INFO - 2018-02-02 13:25:27 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-02 13:25:27 --> Model Class Initialized
INFO - 2018-02-02 13:25:27 --> Helper loaded: permission_helper
INFO - 2018-02-02 13:25:27 --> Helper loaded: users_helper
INFO - 2018-02-02 13:25:27 --> Helper loaded: form_helper
INFO - 2018-02-02 13:25:27 --> Form Validation Class Initialized
INFO - 2018-02-02 13:25:27 --> Controller Class Initialized
INFO - 2018-02-02 13:25:27 --> Final output sent to browser
DEBUG - 2018-02-02 13:25:27 --> Total execution time: 0.1061
INFO - 2018-02-02 13:25:27 --> Database Driver Class Initialized
INFO - 2018-02-02 13:25:27 --> Database Driver Class Initialized
INFO - 2018-02-02 13:25:27 --> Model Class Initialized
INFO - 2018-02-02 13:25:27 --> Helper loaded: inflector_helper
DEBUG - 2018-02-02 13:25:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 13:25:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-02 13:25:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-02-02 13:25:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 13:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 13:25:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-02 13:25:27 --> Model Class Initialized
INFO - 2018-02-02 13:25:27 --> Model Class Initialized
INFO - 2018-02-02 13:25:27 --> Model Class Initialized
INFO - 2018-02-02 13:25:27 --> Model Class Initialized
INFO - 2018-02-02 13:25:27 --> Model Class Initialized
INFO - 2018-02-02 13:25:27 --> Model Class Initialized
INFO - 2018-02-02 13:25:27 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-02 13:25:27 --> Helper loaded: form_helper
INFO - 2018-02-02 13:25:27 --> Form Validation Class Initialized
INFO - 2018-02-02 13:25:27 --> Controller Class Initialized
INFO - 2018-02-02 13:25:27 --> Helper loaded: form_helper
INFO - 2018-02-02 13:25:27 --> Form Validation Class Initialized
INFO - 2018-02-02 13:25:27 --> Controller Class Initialized
INFO - 2018-02-02 13:25:27 --> Model Class Initialized
INFO - 2018-02-02 13:25:27 --> Final output sent to browser
DEBUG - 2018-02-02 13:25:27 --> Total execution time: 0.1116
INFO - 2018-02-02 13:25:27 --> Model Class Initialized
INFO - 2018-02-02 13:25:27 --> Helper loaded: inflector_helper
INFO - 2018-02-02 13:25:27 --> Model Class Initialized
INFO - 2018-02-02 13:25:27 --> Helper loaded: inflector_helper
DEBUG - 2018-02-02 13:25:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-02-02 13:25:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-02 13:25:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-02 13:25:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-02 13:25:27 --> Model Class Initialized
INFO - 2018-02-02 13:25:27 --> Model Class Initialized
INFO - 2018-02-02 13:25:27 --> Model Class Initialized
INFO - 2018-02-02 13:25:27 --> Model Class Initialized
INFO - 2018-02-02 13:25:27 --> Model Class Initialized
INFO - 2018-02-02 13:25:27 --> Model Class Initialized
INFO - 2018-02-02 13:25:27 --> Model Class Initialized
INFO - 2018-02-02 13:25:27 --> Model Class Initialized
INFO - 2018-02-02 13:25:27 --> Model Class Initialized
INFO - 2018-02-02 13:25:27 --> Model Class Initialized
INFO - 2018-02-02 13:25:27 --> Model Class Initialized
INFO - 2018-02-02 13:25:27 --> Model Class Initialized
INFO - 2018-02-02 13:25:27 --> Model Class Initialized
INFO - 2018-02-02 13:25:27 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-02 13:25:27 --> Model Class Initialized
INFO - 2018-02-02 13:25:27 --> Model Class Initialized
INFO - 2018-02-02 13:25:27 --> Model Class Initialized
INFO - 2018-02-02 13:25:27 --> Model Class Initialized
INFO - 2018-02-02 13:25:27 --> Final output sent to browser
DEBUG - 2018-02-02 13:25:27 --> Total execution time: 0.1124
INFO - 2018-02-02 13:25:27 --> Model Class Initialized
INFO - 2018-02-02 13:25:27 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-02 13:25:27 --> Model Class Initialized
INFO - 2018-02-02 13:25:27 --> Final output sent to browser
DEBUG - 2018-02-02 13:25:27 --> Total execution time: 0.1224
INFO - 2018-02-02 07:55:32 --> Config Class Initialized
INFO - 2018-02-02 07:55:32 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:55:32 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:55:32 --> Utf8 Class Initialized
INFO - 2018-02-02 07:55:32 --> URI Class Initialized
INFO - 2018-02-02 07:55:32 --> Router Class Initialized
INFO - 2018-02-02 07:55:32 --> Output Class Initialized
INFO - 2018-02-02 07:55:32 --> Security Class Initialized
DEBUG - 2018-02-02 07:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:55:32 --> Input Class Initialized
INFO - 2018-02-02 07:55:32 --> Language Class Initialized
INFO - 2018-02-02 07:55:32 --> Language Class Initialized
INFO - 2018-02-02 07:55:32 --> Config Class Initialized
INFO - 2018-02-02 07:55:32 --> Loader Class Initialized
INFO - 2018-02-02 13:25:32 --> Helper loaded: url_helper
INFO - 2018-02-02 13:25:32 --> Helper loaded: notification_helper
INFO - 2018-02-02 13:25:32 --> Helper loaded: settings_helper
INFO - 2018-02-02 13:25:32 --> Helper loaded: permission_helper
INFO - 2018-02-02 13:25:32 --> Helper loaded: users_helper
INFO - 2018-02-02 13:25:32 --> Database Driver Class Initialized
DEBUG - 2018-02-02 13:25:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 13:25:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 13:25:32 --> Helper loaded: form_helper
INFO - 2018-02-02 13:25:32 --> Form Validation Class Initialized
INFO - 2018-02-02 13:25:32 --> Controller Class Initialized
INFO - 2018-02-02 13:25:32 --> Model Class Initialized
INFO - 2018-02-02 13:25:32 --> Helper loaded: inflector_helper
DEBUG - 2018-02-02 13:25:32 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-02 13:25:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-02 13:25:32 --> Model Class Initialized
INFO - 2018-02-02 13:25:32 --> Model Class Initialized
INFO - 2018-02-02 13:25:32 --> Model Class Initialized
INFO - 2018-02-02 13:25:32 --> Model Class Initialized
INFO - 2018-02-02 13:25:32 --> Model Class Initialized
INFO - 2018-02-02 13:25:32 --> Model Class Initialized
INFO - 2018-02-02 13:25:32 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-02 13:25:32 --> Final output sent to browser
DEBUG - 2018-02-02 13:25:32 --> Total execution time: 0.1237
INFO - 2018-02-02 08:58:59 --> Config Class Initialized
INFO - 2018-02-02 08:58:59 --> Hooks Class Initialized
DEBUG - 2018-02-02 08:58:59 --> UTF-8 Support Enabled
INFO - 2018-02-02 08:58:59 --> Utf8 Class Initialized
INFO - 2018-02-02 08:58:59 --> URI Class Initialized
DEBUG - 2018-02-02 08:58:59 --> No URI present. Default controller set.
INFO - 2018-02-02 08:58:59 --> Router Class Initialized
INFO - 2018-02-02 08:58:59 --> Output Class Initialized
INFO - 2018-02-02 08:58:59 --> Security Class Initialized
DEBUG - 2018-02-02 08:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 08:58:59 --> Input Class Initialized
INFO - 2018-02-02 08:58:59 --> Language Class Initialized
INFO - 2018-02-02 08:58:59 --> Language Class Initialized
INFO - 2018-02-02 08:58:59 --> Config Class Initialized
INFO - 2018-02-02 08:58:59 --> Loader Class Initialized
INFO - 2018-02-02 14:28:59 --> Helper loaded: url_helper
INFO - 2018-02-02 14:28:59 --> Helper loaded: notification_helper
INFO - 2018-02-02 14:28:59 --> Helper loaded: settings_helper
INFO - 2018-02-02 14:28:59 --> Helper loaded: permission_helper
INFO - 2018-02-02 14:28:59 --> Helper loaded: users_helper
INFO - 2018-02-02 14:28:59 --> Database Driver Class Initialized
DEBUG - 2018-02-02 14:28:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 14:28:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 14:28:59 --> Helper loaded: form_helper
INFO - 2018-02-02 14:28:59 --> Form Validation Class Initialized
INFO - 2018-02-02 14:28:59 --> Controller Class Initialized
INFO - 2018-02-02 14:28:59 --> Model Class Initialized
INFO - 2018-02-02 14:28:59 --> Helper loaded: inflector_helper
INFO - 2018-02-02 14:28:59 --> Model Class Initialized
DEBUG - 2018-02-02 14:28:59 --> File loaded: /home/pr01004/public_html/application/views/login.php
INFO - 2018-02-02 14:28:59 --> Final output sent to browser
DEBUG - 2018-02-02 14:28:59 --> Total execution time: 0.0888
INFO - 2018-02-02 12:34:22 --> Config Class Initialized
INFO - 2018-02-02 12:34:22 --> Hooks Class Initialized
DEBUG - 2018-02-02 12:34:22 --> UTF-8 Support Enabled
INFO - 2018-02-02 12:34:22 --> Utf8 Class Initialized
INFO - 2018-02-02 12:34:22 --> URI Class Initialized
INFO - 2018-02-02 12:34:22 --> Router Class Initialized
INFO - 2018-02-02 12:34:22 --> Output Class Initialized
INFO - 2018-02-02 12:34:22 --> Security Class Initialized
DEBUG - 2018-02-02 12:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 12:34:22 --> Input Class Initialized
INFO - 2018-02-02 12:34:22 --> Language Class Initialized
INFO - 2018-02-02 12:34:22 --> Language Class Initialized
INFO - 2018-02-02 12:34:22 --> Config Class Initialized
INFO - 2018-02-02 12:34:22 --> Loader Class Initialized
INFO - 2018-02-02 18:04:22 --> Helper loaded: url_helper
INFO - 2018-02-02 18:04:22 --> Helper loaded: notification_helper
INFO - 2018-02-02 18:04:22 --> Helper loaded: settings_helper
INFO - 2018-02-02 18:04:22 --> Helper loaded: permission_helper
INFO - 2018-02-02 18:04:22 --> Helper loaded: users_helper
INFO - 2018-02-02 18:04:22 --> Database Driver Class Initialized
DEBUG - 2018-02-02 18:04:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 18:04:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 18:04:22 --> Helper loaded: form_helper
INFO - 2018-02-02 18:04:22 --> Form Validation Class Initialized
INFO - 2018-02-02 18:04:22 --> Controller Class Initialized
DEBUG - 2018-02-02 18:04:22 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-02-02 18:04:22 --> Final output sent to browser
DEBUG - 2018-02-02 18:04:22 --> Total execution time: 0.0729
INFO - 2018-02-02 12:34:34 --> Config Class Initialized
INFO - 2018-02-02 12:34:34 --> Hooks Class Initialized
DEBUG - 2018-02-02 12:34:34 --> UTF-8 Support Enabled
INFO - 2018-02-02 12:34:34 --> Utf8 Class Initialized
INFO - 2018-02-02 12:34:34 --> URI Class Initialized
INFO - 2018-02-02 12:34:34 --> Router Class Initialized
INFO - 2018-02-02 12:34:34 --> Output Class Initialized
INFO - 2018-02-02 12:34:34 --> Security Class Initialized
DEBUG - 2018-02-02 12:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 12:34:34 --> Input Class Initialized
INFO - 2018-02-02 12:34:34 --> Language Class Initialized
INFO - 2018-02-02 12:34:34 --> Language Class Initialized
INFO - 2018-02-02 12:34:34 --> Config Class Initialized
INFO - 2018-02-02 12:34:34 --> Loader Class Initialized
INFO - 2018-02-02 18:04:34 --> Helper loaded: url_helper
INFO - 2018-02-02 18:04:34 --> Helper loaded: notification_helper
INFO - 2018-02-02 18:04:34 --> Helper loaded: settings_helper
INFO - 2018-02-02 18:04:34 --> Helper loaded: permission_helper
INFO - 2018-02-02 18:04:34 --> Helper loaded: users_helper
INFO - 2018-02-02 18:04:34 --> Database Driver Class Initialized
DEBUG - 2018-02-02 18:04:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 18:04:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 18:04:34 --> Helper loaded: form_helper
INFO - 2018-02-02 18:04:34 --> Form Validation Class Initialized
INFO - 2018-02-02 18:04:34 --> Controller Class Initialized
DEBUG - 2018-02-02 18:04:34 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-02-02 18:04:34 --> Final output sent to browser
DEBUG - 2018-02-02 18:04:34 --> Total execution time: 0.0713
INFO - 2018-02-02 12:34:39 --> Config Class Initialized
INFO - 2018-02-02 12:34:39 --> Hooks Class Initialized
DEBUG - 2018-02-02 12:34:39 --> UTF-8 Support Enabled
INFO - 2018-02-02 12:34:39 --> Utf8 Class Initialized
INFO - 2018-02-02 12:34:39 --> URI Class Initialized
INFO - 2018-02-02 12:34:39 --> Router Class Initialized
INFO - 2018-02-02 12:34:39 --> Output Class Initialized
INFO - 2018-02-02 12:34:39 --> Security Class Initialized
DEBUG - 2018-02-02 12:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 12:34:39 --> Input Class Initialized
INFO - 2018-02-02 12:34:39 --> Language Class Initialized
INFO - 2018-02-02 12:34:39 --> Language Class Initialized
INFO - 2018-02-02 12:34:39 --> Config Class Initialized
INFO - 2018-02-02 12:34:39 --> Loader Class Initialized
INFO - 2018-02-02 18:04:39 --> Helper loaded: url_helper
INFO - 2018-02-02 18:04:39 --> Helper loaded: notification_helper
INFO - 2018-02-02 18:04:39 --> Helper loaded: settings_helper
INFO - 2018-02-02 18:04:39 --> Helper loaded: permission_helper
INFO - 2018-02-02 18:04:39 --> Helper loaded: users_helper
INFO - 2018-02-02 18:04:39 --> Database Driver Class Initialized
DEBUG - 2018-02-02 18:04:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 18:04:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 18:04:39 --> Helper loaded: form_helper
INFO - 2018-02-02 18:04:39 --> Form Validation Class Initialized
INFO - 2018-02-02 18:04:39 --> Controller Class Initialized
DEBUG - 2018-02-02 18:04:39 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-02-02 18:04:39 --> Final output sent to browser
DEBUG - 2018-02-02 18:04:39 --> Total execution time: 0.0795
INFO - 2018-02-02 12:34:51 --> Config Class Initialized
INFO - 2018-02-02 12:34:51 --> Hooks Class Initialized
DEBUG - 2018-02-02 12:34:51 --> UTF-8 Support Enabled
INFO - 2018-02-02 12:34:51 --> Utf8 Class Initialized
INFO - 2018-02-02 12:34:51 --> URI Class Initialized
INFO - 2018-02-02 12:34:51 --> Router Class Initialized
INFO - 2018-02-02 12:34:51 --> Output Class Initialized
INFO - 2018-02-02 12:34:51 --> Security Class Initialized
DEBUG - 2018-02-02 12:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 12:34:51 --> Input Class Initialized
INFO - 2018-02-02 12:34:51 --> Language Class Initialized
INFO - 2018-02-02 12:34:51 --> Language Class Initialized
INFO - 2018-02-02 12:34:51 --> Config Class Initialized
INFO - 2018-02-02 12:34:51 --> Loader Class Initialized
INFO - 2018-02-02 18:04:51 --> Helper loaded: url_helper
INFO - 2018-02-02 18:04:51 --> Helper loaded: notification_helper
INFO - 2018-02-02 18:04:51 --> Helper loaded: settings_helper
INFO - 2018-02-02 18:04:51 --> Helper loaded: permission_helper
INFO - 2018-02-02 18:04:51 --> Helper loaded: users_helper
INFO - 2018-02-02 18:04:51 --> Database Driver Class Initialized
DEBUG - 2018-02-02 18:04:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 18:04:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 18:04:51 --> Helper loaded: form_helper
INFO - 2018-02-02 18:04:51 --> Form Validation Class Initialized
INFO - 2018-02-02 18:04:51 --> Controller Class Initialized
DEBUG - 2018-02-02 18:04:51 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-02-02 18:04:51 --> Final output sent to browser
DEBUG - 2018-02-02 18:04:51 --> Total execution time: 0.0747
INFO - 2018-02-02 12:37:14 --> Config Class Initialized
INFO - 2018-02-02 12:37:14 --> Hooks Class Initialized
DEBUG - 2018-02-02 12:37:14 --> UTF-8 Support Enabled
INFO - 2018-02-02 12:37:14 --> Utf8 Class Initialized
INFO - 2018-02-02 12:37:14 --> URI Class Initialized
INFO - 2018-02-02 12:37:14 --> Router Class Initialized
INFO - 2018-02-02 12:37:14 --> Output Class Initialized
INFO - 2018-02-02 12:37:14 --> Security Class Initialized
DEBUG - 2018-02-02 12:37:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 12:37:14 --> Input Class Initialized
INFO - 2018-02-02 12:37:14 --> Language Class Initialized
INFO - 2018-02-02 12:37:14 --> Language Class Initialized
INFO - 2018-02-02 12:37:14 --> Config Class Initialized
INFO - 2018-02-02 12:37:14 --> Loader Class Initialized
INFO - 2018-02-02 18:07:14 --> Helper loaded: url_helper
INFO - 2018-02-02 18:07:14 --> Helper loaded: notification_helper
INFO - 2018-02-02 18:07:14 --> Helper loaded: settings_helper
INFO - 2018-02-02 18:07:14 --> Helper loaded: permission_helper
INFO - 2018-02-02 18:07:14 --> Helper loaded: users_helper
INFO - 2018-02-02 18:07:14 --> Database Driver Class Initialized
DEBUG - 2018-02-02 18:07:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 18:07:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 18:07:14 --> Helper loaded: form_helper
INFO - 2018-02-02 18:07:14 --> Form Validation Class Initialized
INFO - 2018-02-02 18:07:14 --> Controller Class Initialized
DEBUG - 2018-02-02 18:07:14 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-02-02 18:07:14 --> Final output sent to browser
DEBUG - 2018-02-02 18:07:14 --> Total execution time: 0.0625
INFO - 2018-02-02 12:37:16 --> Config Class Initialized
INFO - 2018-02-02 12:37:16 --> Hooks Class Initialized
DEBUG - 2018-02-02 12:37:16 --> UTF-8 Support Enabled
INFO - 2018-02-02 12:37:16 --> Utf8 Class Initialized
INFO - 2018-02-02 12:37:16 --> URI Class Initialized
INFO - 2018-02-02 12:37:16 --> Router Class Initialized
INFO - 2018-02-02 12:37:16 --> Output Class Initialized
INFO - 2018-02-02 12:37:16 --> Security Class Initialized
DEBUG - 2018-02-02 12:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 12:37:16 --> Input Class Initialized
INFO - 2018-02-02 12:37:16 --> Language Class Initialized
INFO - 2018-02-02 12:37:16 --> Language Class Initialized
INFO - 2018-02-02 12:37:16 --> Config Class Initialized
INFO - 2018-02-02 12:37:16 --> Loader Class Initialized
INFO - 2018-02-02 18:07:16 --> Helper loaded: url_helper
INFO - 2018-02-02 18:07:16 --> Helper loaded: notification_helper
INFO - 2018-02-02 18:07:16 --> Helper loaded: settings_helper
INFO - 2018-02-02 18:07:16 --> Helper loaded: permission_helper
INFO - 2018-02-02 18:07:16 --> Helper loaded: users_helper
INFO - 2018-02-02 18:07:16 --> Database Driver Class Initialized
DEBUG - 2018-02-02 18:07:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 18:07:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 18:07:16 --> Helper loaded: form_helper
INFO - 2018-02-02 18:07:16 --> Form Validation Class Initialized
INFO - 2018-02-02 18:07:16 --> Controller Class Initialized
DEBUG - 2018-02-02 18:07:16 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-02-02 18:07:16 --> Final output sent to browser
DEBUG - 2018-02-02 18:07:16 --> Total execution time: 0.0715
INFO - 2018-02-02 12:37:26 --> Config Class Initialized
INFO - 2018-02-02 12:37:26 --> Hooks Class Initialized
DEBUG - 2018-02-02 12:37:26 --> UTF-8 Support Enabled
INFO - 2018-02-02 12:37:26 --> Utf8 Class Initialized
INFO - 2018-02-02 12:37:26 --> URI Class Initialized
INFO - 2018-02-02 12:37:26 --> Router Class Initialized
INFO - 2018-02-02 12:37:26 --> Output Class Initialized
INFO - 2018-02-02 12:37:26 --> Security Class Initialized
DEBUG - 2018-02-02 12:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 12:37:26 --> Input Class Initialized
INFO - 2018-02-02 12:37:26 --> Language Class Initialized
INFO - 2018-02-02 12:37:26 --> Language Class Initialized
INFO - 2018-02-02 12:37:26 --> Config Class Initialized
INFO - 2018-02-02 12:37:26 --> Loader Class Initialized
INFO - 2018-02-02 18:07:26 --> Helper loaded: url_helper
INFO - 2018-02-02 18:07:26 --> Helper loaded: notification_helper
INFO - 2018-02-02 18:07:26 --> Helper loaded: settings_helper
INFO - 2018-02-02 18:07:26 --> Helper loaded: permission_helper
INFO - 2018-02-02 18:07:26 --> Helper loaded: users_helper
INFO - 2018-02-02 18:07:26 --> Database Driver Class Initialized
DEBUG - 2018-02-02 18:07:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 18:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 18:07:26 --> Helper loaded: form_helper
INFO - 2018-02-02 18:07:26 --> Form Validation Class Initialized
INFO - 2018-02-02 18:07:26 --> Controller Class Initialized
DEBUG - 2018-02-02 18:07:26 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-02-02 18:07:26 --> Final output sent to browser
DEBUG - 2018-02-02 18:07:26 --> Total execution time: 0.0761
INFO - 2018-02-02 12:38:23 --> Config Class Initialized
INFO - 2018-02-02 12:38:23 --> Hooks Class Initialized
DEBUG - 2018-02-02 12:38:23 --> UTF-8 Support Enabled
INFO - 2018-02-02 12:38:23 --> Utf8 Class Initialized
INFO - 2018-02-02 12:38:23 --> URI Class Initialized
INFO - 2018-02-02 12:38:23 --> Router Class Initialized
INFO - 2018-02-02 12:38:23 --> Output Class Initialized
INFO - 2018-02-02 12:38:23 --> Security Class Initialized
DEBUG - 2018-02-02 12:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 12:38:23 --> Input Class Initialized
INFO - 2018-02-02 12:38:23 --> Language Class Initialized
INFO - 2018-02-02 12:38:23 --> Language Class Initialized
INFO - 2018-02-02 12:38:23 --> Config Class Initialized
INFO - 2018-02-02 12:38:23 --> Loader Class Initialized
INFO - 2018-02-02 18:08:23 --> Helper loaded: url_helper
INFO - 2018-02-02 18:08:23 --> Helper loaded: notification_helper
INFO - 2018-02-02 18:08:23 --> Helper loaded: settings_helper
INFO - 2018-02-02 18:08:23 --> Helper loaded: permission_helper
INFO - 2018-02-02 18:08:23 --> Helper loaded: users_helper
INFO - 2018-02-02 18:08:23 --> Database Driver Class Initialized
DEBUG - 2018-02-02 18:08:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 18:08:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 18:08:23 --> Helper loaded: form_helper
INFO - 2018-02-02 18:08:23 --> Form Validation Class Initialized
INFO - 2018-02-02 18:08:23 --> Controller Class Initialized
DEBUG - 2018-02-02 18:08:23 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-02-02 18:08:23 --> Final output sent to browser
DEBUG - 2018-02-02 18:08:23 --> Total execution time: 0.0795
INFO - 2018-02-02 12:38:39 --> Config Class Initialized
INFO - 2018-02-02 12:38:39 --> Hooks Class Initialized
DEBUG - 2018-02-02 12:38:39 --> UTF-8 Support Enabled
INFO - 2018-02-02 12:38:39 --> Utf8 Class Initialized
INFO - 2018-02-02 12:38:39 --> URI Class Initialized
INFO - 2018-02-02 12:38:39 --> Router Class Initialized
INFO - 2018-02-02 12:38:39 --> Output Class Initialized
INFO - 2018-02-02 12:38:39 --> Security Class Initialized
DEBUG - 2018-02-02 12:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 12:38:39 --> Input Class Initialized
INFO - 2018-02-02 12:38:39 --> Language Class Initialized
INFO - 2018-02-02 12:38:39 --> Language Class Initialized
INFO - 2018-02-02 12:38:39 --> Config Class Initialized
INFO - 2018-02-02 12:38:39 --> Loader Class Initialized
INFO - 2018-02-02 18:08:39 --> Helper loaded: url_helper
INFO - 2018-02-02 18:08:39 --> Helper loaded: notification_helper
INFO - 2018-02-02 18:08:39 --> Helper loaded: settings_helper
INFO - 2018-02-02 18:08:39 --> Helper loaded: permission_helper
INFO - 2018-02-02 18:08:39 --> Helper loaded: users_helper
INFO - 2018-02-02 18:08:39 --> Database Driver Class Initialized
DEBUG - 2018-02-02 18:08:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 18:08:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 18:08:39 --> Helper loaded: form_helper
INFO - 2018-02-02 18:08:39 --> Form Validation Class Initialized
INFO - 2018-02-02 18:08:39 --> Controller Class Initialized
DEBUG - 2018-02-02 18:08:39 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-02-02 18:08:39 --> Final output sent to browser
DEBUG - 2018-02-02 18:08:39 --> Total execution time: 0.0750
INFO - 2018-02-02 13:10:41 --> Config Class Initialized
INFO - 2018-02-02 13:10:41 --> Hooks Class Initialized
DEBUG - 2018-02-02 13:10:41 --> UTF-8 Support Enabled
INFO - 2018-02-02 13:10:41 --> Utf8 Class Initialized
INFO - 2018-02-02 13:10:41 --> URI Class Initialized
INFO - 2018-02-02 13:10:41 --> Router Class Initialized
INFO - 2018-02-02 13:10:41 --> Output Class Initialized
INFO - 2018-02-02 13:10:41 --> Security Class Initialized
DEBUG - 2018-02-02 13:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 13:10:41 --> Input Class Initialized
INFO - 2018-02-02 13:10:41 --> Language Class Initialized
INFO - 2018-02-02 13:10:41 --> Language Class Initialized
INFO - 2018-02-02 13:10:41 --> Config Class Initialized
INFO - 2018-02-02 13:10:41 --> Loader Class Initialized
INFO - 2018-02-02 18:40:41 --> Helper loaded: url_helper
INFO - 2018-02-02 18:40:41 --> Helper loaded: notification_helper
INFO - 2018-02-02 18:40:41 --> Helper loaded: settings_helper
INFO - 2018-02-02 18:40:41 --> Helper loaded: permission_helper
INFO - 2018-02-02 18:40:41 --> Helper loaded: users_helper
INFO - 2018-02-02 18:40:41 --> Database Driver Class Initialized
DEBUG - 2018-02-02 18:40:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 18:40:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 18:40:41 --> Helper loaded: form_helper
INFO - 2018-02-02 18:40:41 --> Form Validation Class Initialized
INFO - 2018-02-02 18:40:41 --> Controller Class Initialized
DEBUG - 2018-02-02 18:40:41 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-02-02 18:40:41 --> Final output sent to browser
DEBUG - 2018-02-02 18:40:41 --> Total execution time: 0.0692
