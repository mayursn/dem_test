<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-04-26 12:05:59 --> Config Class Initialized
INFO - 2018-04-26 12:05:59 --> Hooks Class Initialized
DEBUG - 2018-04-26 12:05:59 --> UTF-8 Support Enabled
INFO - 2018-04-26 12:05:59 --> Utf8 Class Initialized
INFO - 2018-04-26 12:05:59 --> URI Class Initialized
DEBUG - 2018-04-26 12:05:59 --> No URI present. Default controller set.
INFO - 2018-04-26 12:05:59 --> Router Class Initialized
INFO - 2018-04-26 12:05:59 --> Output Class Initialized
INFO - 2018-04-26 12:05:59 --> Security Class Initialized
DEBUG - 2018-04-26 12:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-26 12:05:59 --> Input Class Initialized
INFO - 2018-04-26 12:05:59 --> Language Class Initialized
INFO - 2018-04-26 12:05:59 --> Language Class Initialized
INFO - 2018-04-26 12:05:59 --> Config Class Initialized
INFO - 2018-04-26 12:05:59 --> Loader Class Initialized
INFO - 2018-04-26 17:35:59 --> Helper loaded: url_helper
INFO - 2018-04-26 17:35:59 --> Helper loaded: notification_helper
INFO - 2018-04-26 17:35:59 --> Helper loaded: settings_helper
INFO - 2018-04-26 17:35:59 --> Helper loaded: permission_helper
INFO - 2018-04-26 17:35:59 --> Helper loaded: users_helper
INFO - 2018-04-26 17:35:59 --> Database Driver Class Initialized
DEBUG - 2018-04-26 17:35:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-26 17:35:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-26 17:35:59 --> Helper loaded: form_helper
INFO - 2018-04-26 17:35:59 --> Form Validation Class Initialized
INFO - 2018-04-26 17:35:59 --> Controller Class Initialized
INFO - 2018-04-26 17:35:59 --> Model Class Initialized
INFO - 2018-04-26 17:35:59 --> Helper loaded: inflector_helper
INFO - 2018-04-26 17:35:59 --> Model Class Initialized
DEBUG - 2018-04-26 17:35:59 --> File loaded: /home/pr01004/public_html/application/views/login.php
INFO - 2018-04-26 17:35:59 --> Final output sent to browser
DEBUG - 2018-04-26 17:35:59 --> Total execution time: 0.2226
INFO - 2018-04-26 12:06:01 --> Config Class Initialized
INFO - 2018-04-26 12:06:01 --> Hooks Class Initialized
DEBUG - 2018-04-26 12:06:01 --> UTF-8 Support Enabled
INFO - 2018-04-26 12:06:01 --> Utf8 Class Initialized
INFO - 2018-04-26 12:06:01 --> URI Class Initialized
INFO - 2018-04-26 12:06:01 --> Router Class Initialized
INFO - 2018-04-26 12:06:01 --> Output Class Initialized
INFO - 2018-04-26 12:06:01 --> Security Class Initialized
DEBUG - 2018-04-26 12:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-26 12:06:01 --> Input Class Initialized
INFO - 2018-04-26 12:06:01 --> Language Class Initialized
INFO - 2018-04-26 12:06:01 --> Language Class Initialized
INFO - 2018-04-26 12:06:01 --> Config Class Initialized
INFO - 2018-04-26 12:06:01 --> Loader Class Initialized
INFO - 2018-04-26 17:36:01 --> Helper loaded: url_helper
INFO - 2018-04-26 17:36:01 --> Helper loaded: notification_helper
INFO - 2018-04-26 17:36:01 --> Helper loaded: settings_helper
INFO - 2018-04-26 17:36:01 --> Helper loaded: permission_helper
INFO - 2018-04-26 17:36:01 --> Helper loaded: users_helper
INFO - 2018-04-26 17:36:01 --> Database Driver Class Initialized
DEBUG - 2018-04-26 17:36:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-26 17:36:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-26 17:36:01 --> Helper loaded: form_helper
INFO - 2018-04-26 17:36:01 --> Form Validation Class Initialized
INFO - 2018-04-26 17:36:01 --> Controller Class Initialized
DEBUG - 2018-04-26 17:36:01 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-04-26 17:36:01 --> Final output sent to browser
DEBUG - 2018-04-26 17:36:01 --> Total execution time: 0.0797
INFO - 2018-04-26 12:06:08 --> Config Class Initialized
INFO - 2018-04-26 12:06:08 --> Hooks Class Initialized
DEBUG - 2018-04-26 12:06:08 --> UTF-8 Support Enabled
INFO - 2018-04-26 12:06:08 --> Utf8 Class Initialized
INFO - 2018-04-26 12:06:08 --> URI Class Initialized
INFO - 2018-04-26 12:06:08 --> Router Class Initialized
INFO - 2018-04-26 12:06:08 --> Output Class Initialized
INFO - 2018-04-26 12:06:08 --> Security Class Initialized
DEBUG - 2018-04-26 12:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-26 12:06:08 --> Input Class Initialized
INFO - 2018-04-26 12:06:08 --> Language Class Initialized
INFO - 2018-04-26 12:06:08 --> Language Class Initialized
INFO - 2018-04-26 12:06:08 --> Config Class Initialized
INFO - 2018-04-26 12:06:08 --> Loader Class Initialized
INFO - 2018-04-26 17:36:08 --> Helper loaded: url_helper
INFO - 2018-04-26 17:36:08 --> Helper loaded: notification_helper
INFO - 2018-04-26 17:36:08 --> Helper loaded: settings_helper
INFO - 2018-04-26 17:36:08 --> Helper loaded: permission_helper
INFO - 2018-04-26 17:36:08 --> Helper loaded: users_helper
INFO - 2018-04-26 17:36:08 --> Database Driver Class Initialized
DEBUG - 2018-04-26 17:36:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-26 17:36:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-26 17:36:08 --> Helper loaded: form_helper
INFO - 2018-04-26 17:36:08 --> Form Validation Class Initialized
INFO - 2018-04-26 17:36:08 --> Controller Class Initialized
INFO - 2018-04-26 17:36:08 --> Model Class Initialized
INFO - 2018-04-26 17:36:08 --> Helper loaded: inflector_helper
INFO - 2018-04-26 17:36:08 --> Model Class Initialized
INFO - 2018-04-26 17:36:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-26 12:06:09 --> Config Class Initialized
INFO - 2018-04-26 12:06:09 --> Hooks Class Initialized
DEBUG - 2018-04-26 12:06:09 --> UTF-8 Support Enabled
INFO - 2018-04-26 12:06:09 --> Utf8 Class Initialized
INFO - 2018-04-26 12:06:09 --> URI Class Initialized
INFO - 2018-04-26 12:06:09 --> Router Class Initialized
INFO - 2018-04-26 12:06:09 --> Output Class Initialized
INFO - 2018-04-26 12:06:09 --> Security Class Initialized
DEBUG - 2018-04-26 12:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-26 12:06:09 --> Input Class Initialized
INFO - 2018-04-26 12:06:09 --> Language Class Initialized
INFO - 2018-04-26 12:06:09 --> Language Class Initialized
INFO - 2018-04-26 12:06:09 --> Config Class Initialized
INFO - 2018-04-26 12:06:09 --> Loader Class Initialized
INFO - 2018-04-26 17:36:09 --> Helper loaded: url_helper
INFO - 2018-04-26 17:36:09 --> Helper loaded: notification_helper
INFO - 2018-04-26 17:36:09 --> Helper loaded: settings_helper
INFO - 2018-04-26 17:36:09 --> Helper loaded: permission_helper
INFO - 2018-04-26 17:36:09 --> Helper loaded: users_helper
INFO - 2018-04-26 17:36:09 --> Database Driver Class Initialized
DEBUG - 2018-04-26 17:36:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-26 17:36:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-26 17:36:09 --> Helper loaded: form_helper
INFO - 2018-04-26 17:36:09 --> Form Validation Class Initialized
INFO - 2018-04-26 17:36:09 --> Controller Class Initialized
DEBUG - 2018-04-26 17:36:09 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-04-26 17:36:09 --> Final output sent to browser
DEBUG - 2018-04-26 17:36:09 --> Total execution time: 0.0740
INFO - 2018-04-26 12:06:09 --> Config Class Initialized
INFO - 2018-04-26 12:06:09 --> Hooks Class Initialized
DEBUG - 2018-04-26 12:06:09 --> UTF-8 Support Enabled
INFO - 2018-04-26 12:06:09 --> Utf8 Class Initialized
INFO - 2018-04-26 12:06:09 --> URI Class Initialized
INFO - 2018-04-26 12:06:09 --> Router Class Initialized
INFO - 2018-04-26 12:06:09 --> Output Class Initialized
INFO - 2018-04-26 12:06:09 --> Security Class Initialized
DEBUG - 2018-04-26 12:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-26 12:06:09 --> Input Class Initialized
INFO - 2018-04-26 12:06:09 --> Language Class Initialized
INFO - 2018-04-26 12:06:09 --> Language Class Initialized
INFO - 2018-04-26 12:06:09 --> Config Class Initialized
INFO - 2018-04-26 12:06:09 --> Loader Class Initialized
INFO - 2018-04-26 17:36:09 --> Helper loaded: url_helper
INFO - 2018-04-26 17:36:09 --> Helper loaded: notification_helper
INFO - 2018-04-26 17:36:09 --> Helper loaded: settings_helper
INFO - 2018-04-26 17:36:09 --> Helper loaded: permission_helper
INFO - 2018-04-26 17:36:09 --> Helper loaded: users_helper
INFO - 2018-04-26 17:36:09 --> Database Driver Class Initialized
DEBUG - 2018-04-26 17:36:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-26 17:36:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-26 17:36:09 --> Helper loaded: form_helper
INFO - 2018-04-26 17:36:09 --> Form Validation Class Initialized
INFO - 2018-04-26 17:36:09 --> Controller Class Initialized
INFO - 2018-04-26 17:36:09 --> Model Class Initialized
INFO - 2018-04-26 17:36:09 --> Helper loaded: inflector_helper
INFO - 2018-04-26 17:36:09 --> Model Class Initialized
INFO - 2018-04-26 17:36:09 --> Model Class Initialized
INFO - 2018-04-26 17:36:09 --> Model Class Initialized
INFO - 2018-04-26 17:36:09 --> Model Class Initialized
INFO - 2018-04-26 17:36:09 --> Model Class Initialized
DEBUG - 2018-04-26 17:36:09 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-04-26 17:36:09 --> File loaded: /home/pr01004/public_html/application/views/admin/dashboard.php
DEBUG - 2018-04-26 17:36:09 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-04-26 17:36:09 --> Final output sent to browser
DEBUG - 2018-04-26 17:36:09 --> Total execution time: 0.1411
INFO - 2018-04-26 12:06:09 --> Config Class Initialized
INFO - 2018-04-26 12:06:09 --> Hooks Class Initialized
DEBUG - 2018-04-26 12:06:09 --> UTF-8 Support Enabled
INFO - 2018-04-26 12:06:09 --> Utf8 Class Initialized
INFO - 2018-04-26 12:06:09 --> URI Class Initialized
INFO - 2018-04-26 12:06:10 --> Router Class Initialized
INFO - 2018-04-26 12:06:10 --> Output Class Initialized
INFO - 2018-04-26 12:06:10 --> Security Class Initialized
DEBUG - 2018-04-26 12:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-26 12:06:10 --> Input Class Initialized
INFO - 2018-04-26 12:06:10 --> Language Class Initialized
INFO - 2018-04-26 12:06:10 --> Language Class Initialized
INFO - 2018-04-26 12:06:10 --> Config Class Initialized
INFO - 2018-04-26 12:06:10 --> Loader Class Initialized
INFO - 2018-04-26 17:36:10 --> Helper loaded: url_helper
INFO - 2018-04-26 17:36:10 --> Helper loaded: notification_helper
INFO - 2018-04-26 17:36:10 --> Helper loaded: settings_helper
INFO - 2018-04-26 17:36:10 --> Helper loaded: permission_helper
INFO - 2018-04-26 17:36:10 --> Helper loaded: users_helper
INFO - 2018-04-26 17:36:10 --> Database Driver Class Initialized
DEBUG - 2018-04-26 17:36:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-26 17:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-26 17:36:10 --> Helper loaded: form_helper
INFO - 2018-04-26 17:36:10 --> Form Validation Class Initialized
INFO - 2018-04-26 17:36:10 --> Controller Class Initialized
DEBUG - 2018-04-26 17:36:10 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-04-26 17:36:10 --> Final output sent to browser
DEBUG - 2018-04-26 17:36:10 --> Total execution time: 0.0699
INFO - 2018-04-26 12:06:39 --> Config Class Initialized
INFO - 2018-04-26 12:06:39 --> Hooks Class Initialized
DEBUG - 2018-04-26 12:06:39 --> UTF-8 Support Enabled
INFO - 2018-04-26 12:06:39 --> Utf8 Class Initialized
INFO - 2018-04-26 12:06:39 --> URI Class Initialized
INFO - 2018-04-26 12:06:39 --> Router Class Initialized
INFO - 2018-04-26 12:06:39 --> Output Class Initialized
INFO - 2018-04-26 12:06:39 --> Security Class Initialized
DEBUG - 2018-04-26 12:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-26 12:06:39 --> Input Class Initialized
INFO - 2018-04-26 12:06:39 --> Language Class Initialized
INFO - 2018-04-26 12:06:39 --> Language Class Initialized
INFO - 2018-04-26 12:06:39 --> Config Class Initialized
INFO - 2018-04-26 12:06:39 --> Loader Class Initialized
INFO - 2018-04-26 17:36:39 --> Helper loaded: url_helper
INFO - 2018-04-26 17:36:39 --> Helper loaded: notification_helper
INFO - 2018-04-26 17:36:39 --> Helper loaded: settings_helper
INFO - 2018-04-26 17:36:39 --> Helper loaded: permission_helper
INFO - 2018-04-26 17:36:39 --> Helper loaded: users_helper
INFO - 2018-04-26 17:36:39 --> Database Driver Class Initialized
DEBUG - 2018-04-26 17:36:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-26 17:36:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-26 17:36:39 --> Helper loaded: form_helper
INFO - 2018-04-26 17:36:39 --> Form Validation Class Initialized
INFO - 2018-04-26 17:36:39 --> Controller Class Initialized
INFO - 2018-04-26 17:36:39 --> Model Class Initialized
INFO - 2018-04-26 17:36:39 --> Helper loaded: inflector_helper
INFO - 2018-04-26 17:36:39 --> Model Class Initialized
INFO - 2018-04-26 17:36:39 --> Model Class Initialized
INFO - 2018-04-26 17:36:39 --> Model Class Initialized
DEBUG - 2018-04-26 17:36:39 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-04-26 17:36:39 --> File loaded: /home/pr01004/public_html/application/views/admin/adminlist.php
DEBUG - 2018-04-26 17:36:39 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-04-26 17:36:39 --> Final output sent to browser
DEBUG - 2018-04-26 17:36:39 --> Total execution time: 0.0946
INFO - 2018-04-26 12:06:40 --> Config Class Initialized
INFO - 2018-04-26 12:06:40 --> Hooks Class Initialized
DEBUG - 2018-04-26 12:06:40 --> UTF-8 Support Enabled
INFO - 2018-04-26 12:06:40 --> Utf8 Class Initialized
INFO - 2018-04-26 12:06:40 --> URI Class Initialized
INFO - 2018-04-26 12:06:40 --> Router Class Initialized
INFO - 2018-04-26 12:06:40 --> Output Class Initialized
INFO - 2018-04-26 12:06:40 --> Security Class Initialized
DEBUG - 2018-04-26 12:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-26 12:06:40 --> Input Class Initialized
INFO - 2018-04-26 12:06:40 --> Language Class Initialized
INFO - 2018-04-26 12:06:40 --> Language Class Initialized
INFO - 2018-04-26 12:06:40 --> Config Class Initialized
INFO - 2018-04-26 12:06:40 --> Loader Class Initialized
INFO - 2018-04-26 17:36:40 --> Helper loaded: url_helper
INFO - 2018-04-26 17:36:40 --> Helper loaded: notification_helper
INFO - 2018-04-26 17:36:40 --> Helper loaded: settings_helper
INFO - 2018-04-26 17:36:40 --> Helper loaded: permission_helper
INFO - 2018-04-26 17:36:40 --> Helper loaded: users_helper
INFO - 2018-04-26 17:36:40 --> Database Driver Class Initialized
DEBUG - 2018-04-26 17:36:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-26 17:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-26 17:36:40 --> Helper loaded: form_helper
INFO - 2018-04-26 17:36:40 --> Form Validation Class Initialized
INFO - 2018-04-26 17:36:40 --> Controller Class Initialized
DEBUG - 2018-04-26 17:36:40 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-04-26 17:36:40 --> Final output sent to browser
DEBUG - 2018-04-26 17:36:40 --> Total execution time: 0.0679
INFO - 2018-04-26 12:06:45 --> Config Class Initialized
INFO - 2018-04-26 12:06:45 --> Hooks Class Initialized
DEBUG - 2018-04-26 12:06:45 --> UTF-8 Support Enabled
INFO - 2018-04-26 12:06:45 --> Utf8 Class Initialized
INFO - 2018-04-26 12:06:45 --> URI Class Initialized
INFO - 2018-04-26 12:06:45 --> Router Class Initialized
INFO - 2018-04-26 12:06:45 --> Output Class Initialized
INFO - 2018-04-26 12:06:45 --> Security Class Initialized
DEBUG - 2018-04-26 12:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-26 12:06:45 --> Input Class Initialized
INFO - 2018-04-26 12:06:45 --> Language Class Initialized
INFO - 2018-04-26 12:06:45 --> Language Class Initialized
INFO - 2018-04-26 12:06:45 --> Config Class Initialized
INFO - 2018-04-26 12:06:45 --> Loader Class Initialized
INFO - 2018-04-26 17:36:45 --> Helper loaded: url_helper
INFO - 2018-04-26 17:36:45 --> Helper loaded: notification_helper
INFO - 2018-04-26 17:36:45 --> Helper loaded: settings_helper
INFO - 2018-04-26 17:36:45 --> Helper loaded: permission_helper
INFO - 2018-04-26 17:36:45 --> Helper loaded: users_helper
INFO - 2018-04-26 17:36:45 --> Database Driver Class Initialized
DEBUG - 2018-04-26 17:36:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-26 17:36:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-26 17:36:45 --> Helper loaded: form_helper
INFO - 2018-04-26 17:36:45 --> Form Validation Class Initialized
INFO - 2018-04-26 17:36:45 --> Controller Class Initialized
INFO - 2018-04-26 17:36:45 --> Model Class Initialized
INFO - 2018-04-26 17:36:45 --> Helper loaded: inflector_helper
INFO - 2018-04-26 17:36:45 --> Model Class Initialized
INFO - 2018-04-26 17:36:45 --> Model Class Initialized
INFO - 2018-04-26 17:36:45 --> Model Class Initialized
INFO - 2018-04-26 17:36:45 --> Model Class Initialized
DEBUG - 2018-04-26 17:36:45 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-04-26 17:36:45 --> File loaded: /home/pr01004/public_html/application/views/admin/permission.php
DEBUG - 2018-04-26 17:36:45 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-04-26 17:36:45 --> Final output sent to browser
DEBUG - 2018-04-26 17:36:45 --> Total execution time: 0.2034
INFO - 2018-04-26 12:06:46 --> Config Class Initialized
INFO - 2018-04-26 12:06:46 --> Hooks Class Initialized
DEBUG - 2018-04-26 12:06:46 --> UTF-8 Support Enabled
INFO - 2018-04-26 12:06:46 --> Utf8 Class Initialized
INFO - 2018-04-26 12:06:46 --> URI Class Initialized
INFO - 2018-04-26 12:06:46 --> Router Class Initialized
INFO - 2018-04-26 12:06:46 --> Output Class Initialized
INFO - 2018-04-26 12:06:46 --> Security Class Initialized
DEBUG - 2018-04-26 12:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-26 12:06:46 --> Input Class Initialized
INFO - 2018-04-26 12:06:46 --> Language Class Initialized
INFO - 2018-04-26 12:06:46 --> Language Class Initialized
INFO - 2018-04-26 12:06:46 --> Config Class Initialized
INFO - 2018-04-26 12:06:46 --> Loader Class Initialized
INFO - 2018-04-26 17:36:46 --> Helper loaded: url_helper
INFO - 2018-04-26 17:36:46 --> Helper loaded: notification_helper
INFO - 2018-04-26 17:36:46 --> Helper loaded: settings_helper
INFO - 2018-04-26 17:36:46 --> Helper loaded: permission_helper
INFO - 2018-04-26 17:36:46 --> Helper loaded: users_helper
INFO - 2018-04-26 17:36:46 --> Database Driver Class Initialized
DEBUG - 2018-04-26 17:36:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-26 17:36:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-26 17:36:46 --> Helper loaded: form_helper
INFO - 2018-04-26 17:36:46 --> Form Validation Class Initialized
INFO - 2018-04-26 17:36:46 --> Controller Class Initialized
DEBUG - 2018-04-26 17:36:46 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-04-26 17:36:46 --> Final output sent to browser
DEBUG - 2018-04-26 17:36:46 --> Total execution time: 0.1496
INFO - 2018-04-26 12:06:49 --> Config Class Initialized
INFO - 2018-04-26 12:06:49 --> Hooks Class Initialized
DEBUG - 2018-04-26 12:06:49 --> UTF-8 Support Enabled
INFO - 2018-04-26 12:06:49 --> Utf8 Class Initialized
INFO - 2018-04-26 12:06:49 --> URI Class Initialized
INFO - 2018-04-26 12:06:49 --> Router Class Initialized
INFO - 2018-04-26 12:06:49 --> Output Class Initialized
INFO - 2018-04-26 12:06:49 --> Security Class Initialized
DEBUG - 2018-04-26 12:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-26 12:06:49 --> Input Class Initialized
INFO - 2018-04-26 12:06:49 --> Language Class Initialized
INFO - 2018-04-26 12:06:49 --> Language Class Initialized
INFO - 2018-04-26 12:06:49 --> Config Class Initialized
INFO - 2018-04-26 12:06:49 --> Loader Class Initialized
INFO - 2018-04-26 17:36:49 --> Helper loaded: url_helper
INFO - 2018-04-26 17:36:49 --> Helper loaded: notification_helper
INFO - 2018-04-26 17:36:49 --> Helper loaded: settings_helper
INFO - 2018-04-26 17:36:49 --> Helper loaded: permission_helper
INFO - 2018-04-26 17:36:49 --> Helper loaded: users_helper
INFO - 2018-04-26 17:36:49 --> Database Driver Class Initialized
DEBUG - 2018-04-26 17:36:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-26 17:36:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-26 17:36:49 --> Helper loaded: form_helper
INFO - 2018-04-26 17:36:49 --> Form Validation Class Initialized
INFO - 2018-04-26 17:36:49 --> Controller Class Initialized
INFO - 2018-04-26 17:36:49 --> Model Class Initialized
INFO - 2018-04-26 17:36:49 --> Helper loaded: inflector_helper
INFO - 2018-04-26 17:36:49 --> Model Class Initialized
INFO - 2018-04-26 17:36:49 --> Model Class Initialized
INFO - 2018-04-26 17:36:49 --> Model Class Initialized
INFO - 2018-04-26 17:36:49 --> Model Class Initialized
DEBUG - 2018-04-26 17:36:49 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-04-26 17:36:49 --> File loaded: /home/pr01004/public_html/application/views/admin/permission.php
DEBUG - 2018-04-26 17:36:49 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-04-26 17:36:49 --> Final output sent to browser
DEBUG - 2018-04-26 17:36:49 --> Total execution time: 0.1741
INFO - 2018-04-26 12:06:49 --> Config Class Initialized
INFO - 2018-04-26 12:06:49 --> Hooks Class Initialized
DEBUG - 2018-04-26 12:06:49 --> UTF-8 Support Enabled
INFO - 2018-04-26 12:06:49 --> Utf8 Class Initialized
INFO - 2018-04-26 12:06:49 --> URI Class Initialized
INFO - 2018-04-26 12:06:49 --> Router Class Initialized
INFO - 2018-04-26 12:06:49 --> Output Class Initialized
INFO - 2018-04-26 12:06:49 --> Security Class Initialized
DEBUG - 2018-04-26 12:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-26 12:06:49 --> Input Class Initialized
INFO - 2018-04-26 12:06:49 --> Language Class Initialized
INFO - 2018-04-26 12:06:50 --> Language Class Initialized
INFO - 2018-04-26 12:06:50 --> Config Class Initialized
INFO - 2018-04-26 12:06:50 --> Loader Class Initialized
INFO - 2018-04-26 17:36:50 --> Helper loaded: url_helper
INFO - 2018-04-26 17:36:50 --> Helper loaded: notification_helper
INFO - 2018-04-26 17:36:50 --> Helper loaded: settings_helper
INFO - 2018-04-26 17:36:50 --> Helper loaded: permission_helper
INFO - 2018-04-26 17:36:50 --> Helper loaded: users_helper
INFO - 2018-04-26 17:36:50 --> Database Driver Class Initialized
DEBUG - 2018-04-26 17:36:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-26 17:36:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-26 17:36:50 --> Helper loaded: form_helper
INFO - 2018-04-26 17:36:50 --> Form Validation Class Initialized
INFO - 2018-04-26 17:36:50 --> Controller Class Initialized
DEBUG - 2018-04-26 17:36:50 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-04-26 17:36:50 --> Final output sent to browser
DEBUG - 2018-04-26 17:36:50 --> Total execution time: 0.0772
INFO - 2018-04-26 12:06:55 --> Config Class Initialized
INFO - 2018-04-26 12:06:55 --> Hooks Class Initialized
DEBUG - 2018-04-26 12:06:55 --> UTF-8 Support Enabled
INFO - 2018-04-26 12:06:55 --> Utf8 Class Initialized
INFO - 2018-04-26 12:06:55 --> URI Class Initialized
INFO - 2018-04-26 12:06:55 --> Router Class Initialized
INFO - 2018-04-26 12:06:55 --> Output Class Initialized
INFO - 2018-04-26 12:06:55 --> Security Class Initialized
DEBUG - 2018-04-26 12:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-26 12:06:55 --> Input Class Initialized
INFO - 2018-04-26 12:06:55 --> Language Class Initialized
INFO - 2018-04-26 12:06:55 --> Language Class Initialized
INFO - 2018-04-26 12:06:55 --> Config Class Initialized
INFO - 2018-04-26 12:06:55 --> Loader Class Initialized
INFO - 2018-04-26 17:36:55 --> Helper loaded: url_helper
INFO - 2018-04-26 17:36:55 --> Helper loaded: notification_helper
INFO - 2018-04-26 17:36:55 --> Helper loaded: settings_helper
INFO - 2018-04-26 17:36:55 --> Helper loaded: permission_helper
INFO - 2018-04-26 17:36:55 --> Helper loaded: users_helper
INFO - 2018-04-26 17:36:55 --> Database Driver Class Initialized
DEBUG - 2018-04-26 17:36:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-26 17:36:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-26 17:36:55 --> Helper loaded: form_helper
INFO - 2018-04-26 17:36:55 --> Form Validation Class Initialized
INFO - 2018-04-26 17:36:55 --> Controller Class Initialized
INFO - 2018-04-26 17:36:55 --> Model Class Initialized
INFO - 2018-04-26 17:36:55 --> Helper loaded: inflector_helper
INFO - 2018-04-26 17:36:55 --> Model Class Initialized
INFO - 2018-04-26 17:36:55 --> Model Class Initialized
INFO - 2018-04-26 17:36:55 --> Model Class Initialized
INFO - 2018-04-26 17:36:55 --> Model Class Initialized
INFO - 2018-04-26 12:06:55 --> Config Class Initialized
INFO - 2018-04-26 12:06:55 --> Hooks Class Initialized
DEBUG - 2018-04-26 12:06:55 --> UTF-8 Support Enabled
INFO - 2018-04-26 12:06:55 --> Utf8 Class Initialized
INFO - 2018-04-26 12:06:55 --> URI Class Initialized
INFO - 2018-04-26 12:06:55 --> Router Class Initialized
INFO - 2018-04-26 12:06:55 --> Output Class Initialized
INFO - 2018-04-26 12:06:55 --> Security Class Initialized
DEBUG - 2018-04-26 12:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-26 12:06:55 --> Input Class Initialized
INFO - 2018-04-26 12:06:55 --> Language Class Initialized
INFO - 2018-04-26 12:06:55 --> Language Class Initialized
INFO - 2018-04-26 12:06:55 --> Config Class Initialized
INFO - 2018-04-26 12:06:55 --> Loader Class Initialized
INFO - 2018-04-26 17:36:55 --> Helper loaded: url_helper
INFO - 2018-04-26 17:36:55 --> Helper loaded: notification_helper
INFO - 2018-04-26 17:36:55 --> Helper loaded: settings_helper
INFO - 2018-04-26 17:36:55 --> Helper loaded: permission_helper
INFO - 2018-04-26 17:36:55 --> Helper loaded: users_helper
INFO - 2018-04-26 17:36:55 --> Database Driver Class Initialized
DEBUG - 2018-04-26 17:36:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-26 17:36:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-26 17:36:55 --> Helper loaded: form_helper
INFO - 2018-04-26 17:36:55 --> Form Validation Class Initialized
INFO - 2018-04-26 17:36:55 --> Controller Class Initialized
INFO - 2018-04-26 17:36:55 --> Model Class Initialized
INFO - 2018-04-26 17:36:55 --> Helper loaded: inflector_helper
INFO - 2018-04-26 17:36:55 --> Model Class Initialized
INFO - 2018-04-26 17:36:55 --> Model Class Initialized
INFO - 2018-04-26 17:36:55 --> Model Class Initialized
INFO - 2018-04-26 17:36:55 --> Model Class Initialized
DEBUG - 2018-04-26 17:36:55 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-04-26 17:36:55 --> File loaded: /home/pr01004/public_html/application/views/admin/permission.php
DEBUG - 2018-04-26 17:36:55 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-04-26 17:36:55 --> Final output sent to browser
DEBUG - 2018-04-26 17:36:55 --> Total execution time: 0.1029
INFO - 2018-04-26 12:08:09 --> Config Class Initialized
INFO - 2018-04-26 12:08:09 --> Hooks Class Initialized
DEBUG - 2018-04-26 12:08:09 --> UTF-8 Support Enabled
INFO - 2018-04-26 12:08:09 --> Utf8 Class Initialized
INFO - 2018-04-26 12:08:09 --> URI Class Initialized
INFO - 2018-04-26 12:08:09 --> Router Class Initialized
INFO - 2018-04-26 12:08:09 --> Output Class Initialized
INFO - 2018-04-26 12:08:09 --> Security Class Initialized
DEBUG - 2018-04-26 12:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-26 12:08:09 --> Input Class Initialized
INFO - 2018-04-26 12:08:09 --> Language Class Initialized
INFO - 2018-04-26 12:08:09 --> Language Class Initialized
INFO - 2018-04-26 12:08:09 --> Config Class Initialized
INFO - 2018-04-26 12:08:09 --> Loader Class Initialized
INFO - 2018-04-26 17:38:09 --> Helper loaded: url_helper
INFO - 2018-04-26 17:38:09 --> Helper loaded: notification_helper
INFO - 2018-04-26 17:38:09 --> Helper loaded: settings_helper
INFO - 2018-04-26 17:38:09 --> Helper loaded: permission_helper
INFO - 2018-04-26 17:38:09 --> Helper loaded: users_helper
INFO - 2018-04-26 17:38:09 --> Database Driver Class Initialized
DEBUG - 2018-04-26 17:38:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-26 17:38:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-26 17:38:09 --> Helper loaded: form_helper
INFO - 2018-04-26 17:38:09 --> Form Validation Class Initialized
INFO - 2018-04-26 17:38:09 --> Controller Class Initialized
INFO - 2018-04-26 17:38:09 --> Model Class Initialized
INFO - 2018-04-26 17:38:09 --> Helper loaded: inflector_helper
INFO - 2018-04-26 17:38:09 --> Model Class Initialized
INFO - 2018-04-26 17:38:09 --> Model Class Initialized
DEBUG - 2018-04-26 17:38:09 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-04-26 17:38:09 --> File loaded: /home/pr01004/public_html/application/views/credits/index.php
DEBUG - 2018-04-26 17:38:09 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-04-26 17:38:09 --> Final output sent to browser
DEBUG - 2018-04-26 17:38:09 --> Total execution time: 0.1128
INFO - 2018-04-26 12:08:50 --> Config Class Initialized
INFO - 2018-04-26 12:08:50 --> Hooks Class Initialized
DEBUG - 2018-04-26 12:08:50 --> UTF-8 Support Enabled
INFO - 2018-04-26 12:08:50 --> Utf8 Class Initialized
INFO - 2018-04-26 12:08:50 --> URI Class Initialized
INFO - 2018-04-26 12:08:50 --> Router Class Initialized
INFO - 2018-04-26 12:08:50 --> Output Class Initialized
INFO - 2018-04-26 12:08:50 --> Security Class Initialized
DEBUG - 2018-04-26 12:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-26 12:08:50 --> Input Class Initialized
INFO - 2018-04-26 12:08:50 --> Language Class Initialized
INFO - 2018-04-26 12:08:50 --> Language Class Initialized
INFO - 2018-04-26 12:08:50 --> Config Class Initialized
INFO - 2018-04-26 12:08:50 --> Loader Class Initialized
INFO - 2018-04-26 17:38:50 --> Helper loaded: url_helper
INFO - 2018-04-26 17:38:50 --> Helper loaded: notification_helper
INFO - 2018-04-26 17:38:50 --> Helper loaded: settings_helper
INFO - 2018-04-26 17:38:50 --> Helper loaded: permission_helper
INFO - 2018-04-26 17:38:50 --> Helper loaded: users_helper
INFO - 2018-04-26 17:38:50 --> Database Driver Class Initialized
DEBUG - 2018-04-26 17:38:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-26 17:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-26 17:38:50 --> Helper loaded: form_helper
INFO - 2018-04-26 17:38:50 --> Form Validation Class Initialized
INFO - 2018-04-26 17:38:50 --> Controller Class Initialized
INFO - 2018-04-26 17:38:50 --> Model Class Initialized
INFO - 2018-04-26 17:38:50 --> Helper loaded: inflector_helper
INFO - 2018-04-26 17:38:50 --> Model Class Initialized
INFO - 2018-04-26 17:38:50 --> Model Class Initialized
DEBUG - 2018-04-26 17:38:50 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-04-26 17:38:50 --> File loaded: /home/pr01004/public_html/application/views/credits/index.php
DEBUG - 2018-04-26 17:38:50 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-04-26 17:38:50 --> Final output sent to browser
DEBUG - 2018-04-26 17:38:50 --> Total execution time: 0.0916
INFO - 2018-04-26 12:09:57 --> Config Class Initialized
INFO - 2018-04-26 12:09:57 --> Hooks Class Initialized
DEBUG - 2018-04-26 12:09:57 --> UTF-8 Support Enabled
INFO - 2018-04-26 12:09:57 --> Utf8 Class Initialized
INFO - 2018-04-26 12:09:57 --> URI Class Initialized
INFO - 2018-04-26 12:09:57 --> Router Class Initialized
INFO - 2018-04-26 12:09:57 --> Output Class Initialized
INFO - 2018-04-26 12:09:57 --> Security Class Initialized
DEBUG - 2018-04-26 12:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-26 12:09:57 --> Input Class Initialized
INFO - 2018-04-26 12:09:57 --> Language Class Initialized
INFO - 2018-04-26 12:09:57 --> Language Class Initialized
INFO - 2018-04-26 12:09:57 --> Config Class Initialized
INFO - 2018-04-26 12:09:57 --> Loader Class Initialized
INFO - 2018-04-26 17:39:57 --> Helper loaded: url_helper
INFO - 2018-04-26 17:39:57 --> Helper loaded: notification_helper
INFO - 2018-04-26 17:39:57 --> Helper loaded: settings_helper
INFO - 2018-04-26 17:39:57 --> Helper loaded: permission_helper
INFO - 2018-04-26 17:39:57 --> Helper loaded: users_helper
INFO - 2018-04-26 17:39:57 --> Database Driver Class Initialized
DEBUG - 2018-04-26 17:39:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-26 17:39:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-26 17:39:57 --> Helper loaded: form_helper
INFO - 2018-04-26 17:39:57 --> Form Validation Class Initialized
INFO - 2018-04-26 17:39:57 --> Controller Class Initialized
INFO - 2018-04-26 17:39:57 --> Model Class Initialized
INFO - 2018-04-26 17:39:57 --> Helper loaded: inflector_helper
INFO - 2018-04-26 17:39:57 --> Model Class Initialized
INFO - 2018-04-26 17:39:57 --> Model Class Initialized
DEBUG - 2018-04-26 17:39:57 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-04-26 17:39:57 --> File loaded: /home/pr01004/public_html/application/views/credits/create.php
DEBUG - 2018-04-26 17:39:57 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-04-26 17:39:57 --> Final output sent to browser
DEBUG - 2018-04-26 17:39:57 --> Total execution time: 0.1805
INFO - 2018-04-26 12:10:06 --> Config Class Initialized
INFO - 2018-04-26 12:10:06 --> Hooks Class Initialized
DEBUG - 2018-04-26 12:10:06 --> UTF-8 Support Enabled
INFO - 2018-04-26 12:10:06 --> Utf8 Class Initialized
INFO - 2018-04-26 12:10:06 --> URI Class Initialized
INFO - 2018-04-26 12:10:06 --> Router Class Initialized
INFO - 2018-04-26 12:10:06 --> Output Class Initialized
INFO - 2018-04-26 12:10:06 --> Security Class Initialized
DEBUG - 2018-04-26 12:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-26 12:10:06 --> Input Class Initialized
INFO - 2018-04-26 12:10:06 --> Language Class Initialized
INFO - 2018-04-26 12:10:06 --> Language Class Initialized
INFO - 2018-04-26 12:10:06 --> Config Class Initialized
INFO - 2018-04-26 12:10:06 --> Loader Class Initialized
INFO - 2018-04-26 17:40:06 --> Helper loaded: url_helper
INFO - 2018-04-26 17:40:06 --> Helper loaded: notification_helper
INFO - 2018-04-26 17:40:06 --> Helper loaded: settings_helper
INFO - 2018-04-26 17:40:06 --> Helper loaded: permission_helper
INFO - 2018-04-26 17:40:06 --> Helper loaded: users_helper
INFO - 2018-04-26 17:40:06 --> Database Driver Class Initialized
DEBUG - 2018-04-26 17:40:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-26 17:40:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-26 17:40:06 --> Helper loaded: form_helper
INFO - 2018-04-26 17:40:06 --> Form Validation Class Initialized
INFO - 2018-04-26 17:40:06 --> Controller Class Initialized
INFO - 2018-04-26 17:40:06 --> Model Class Initialized
INFO - 2018-04-26 17:40:06 --> Helper loaded: inflector_helper
INFO - 2018-04-26 17:40:06 --> Model Class Initialized
INFO - 2018-04-26 17:40:06 --> Model Class Initialized
INFO - 2018-04-26 12:10:06 --> Config Class Initialized
INFO - 2018-04-26 12:10:06 --> Hooks Class Initialized
DEBUG - 2018-04-26 12:10:06 --> UTF-8 Support Enabled
INFO - 2018-04-26 12:10:06 --> Utf8 Class Initialized
INFO - 2018-04-26 12:10:06 --> URI Class Initialized
INFO - 2018-04-26 12:10:06 --> Router Class Initialized
INFO - 2018-04-26 12:10:06 --> Output Class Initialized
INFO - 2018-04-26 12:10:06 --> Security Class Initialized
DEBUG - 2018-04-26 12:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-26 12:10:06 --> Input Class Initialized
INFO - 2018-04-26 12:10:06 --> Language Class Initialized
INFO - 2018-04-26 12:10:06 --> Language Class Initialized
INFO - 2018-04-26 12:10:06 --> Config Class Initialized
INFO - 2018-04-26 12:10:06 --> Loader Class Initialized
INFO - 2018-04-26 17:40:06 --> Helper loaded: url_helper
INFO - 2018-04-26 17:40:06 --> Helper loaded: notification_helper
INFO - 2018-04-26 17:40:06 --> Helper loaded: settings_helper
INFO - 2018-04-26 17:40:06 --> Helper loaded: permission_helper
INFO - 2018-04-26 17:40:06 --> Helper loaded: users_helper
INFO - 2018-04-26 17:40:06 --> Database Driver Class Initialized
DEBUG - 2018-04-26 17:40:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-26 17:40:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-26 17:40:06 --> Helper loaded: form_helper
INFO - 2018-04-26 17:40:06 --> Form Validation Class Initialized
INFO - 2018-04-26 17:40:06 --> Controller Class Initialized
INFO - 2018-04-26 17:40:06 --> Model Class Initialized
INFO - 2018-04-26 17:40:06 --> Helper loaded: inflector_helper
INFO - 2018-04-26 17:40:06 --> Model Class Initialized
INFO - 2018-04-26 17:40:06 --> Model Class Initialized
DEBUG - 2018-04-26 17:40:06 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-04-26 17:40:06 --> File loaded: /home/pr01004/public_html/application/views/credits/index.php
DEBUG - 2018-04-26 17:40:06 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-04-26 17:40:06 --> Final output sent to browser
DEBUG - 2018-04-26 17:40:06 --> Total execution time: 0.0964
INFO - 2018-04-26 12:10:09 --> Config Class Initialized
INFO - 2018-04-26 12:10:09 --> Hooks Class Initialized
DEBUG - 2018-04-26 12:10:09 --> UTF-8 Support Enabled
INFO - 2018-04-26 12:10:09 --> Utf8 Class Initialized
INFO - 2018-04-26 12:10:09 --> URI Class Initialized
INFO - 2018-04-26 12:10:09 --> Router Class Initialized
INFO - 2018-04-26 12:10:09 --> Output Class Initialized
INFO - 2018-04-26 12:10:09 --> Security Class Initialized
DEBUG - 2018-04-26 12:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-26 12:10:09 --> Input Class Initialized
INFO - 2018-04-26 12:10:09 --> Language Class Initialized
INFO - 2018-04-26 12:10:09 --> Language Class Initialized
INFO - 2018-04-26 12:10:09 --> Config Class Initialized
INFO - 2018-04-26 12:10:09 --> Loader Class Initialized
INFO - 2018-04-26 17:40:09 --> Helper loaded: url_helper
INFO - 2018-04-26 17:40:09 --> Helper loaded: notification_helper
INFO - 2018-04-26 17:40:09 --> Helper loaded: settings_helper
INFO - 2018-04-26 17:40:09 --> Helper loaded: permission_helper
INFO - 2018-04-26 17:40:09 --> Helper loaded: users_helper
INFO - 2018-04-26 17:40:09 --> Database Driver Class Initialized
DEBUG - 2018-04-26 17:40:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-26 17:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-26 17:40:09 --> Helper loaded: form_helper
INFO - 2018-04-26 17:40:09 --> Form Validation Class Initialized
INFO - 2018-04-26 17:40:09 --> Controller Class Initialized
INFO - 2018-04-26 17:40:09 --> Model Class Initialized
INFO - 2018-04-26 17:40:09 --> Helper loaded: inflector_helper
INFO - 2018-04-26 17:40:09 --> Model Class Initialized
INFO - 2018-04-26 17:40:09 --> Model Class Initialized
DEBUG - 2018-04-26 17:40:09 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-04-26 17:40:09 --> File loaded: /home/pr01004/public_html/application/views/credits/edit.php
DEBUG - 2018-04-26 17:40:09 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-04-26 17:40:09 --> Final output sent to browser
DEBUG - 2018-04-26 17:40:09 --> Total execution time: 0.0852
INFO - 2018-04-26 12:10:11 --> Config Class Initialized
INFO - 2018-04-26 12:10:11 --> Hooks Class Initialized
DEBUG - 2018-04-26 12:10:11 --> UTF-8 Support Enabled
INFO - 2018-04-26 12:10:11 --> Utf8 Class Initialized
INFO - 2018-04-26 12:10:11 --> URI Class Initialized
INFO - 2018-04-26 12:10:11 --> Router Class Initialized
INFO - 2018-04-26 12:10:11 --> Output Class Initialized
INFO - 2018-04-26 12:10:11 --> Security Class Initialized
DEBUG - 2018-04-26 12:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-26 12:10:11 --> Input Class Initialized
INFO - 2018-04-26 12:10:11 --> Language Class Initialized
INFO - 2018-04-26 12:10:11 --> Language Class Initialized
INFO - 2018-04-26 12:10:11 --> Config Class Initialized
INFO - 2018-04-26 12:10:11 --> Loader Class Initialized
INFO - 2018-04-26 17:40:11 --> Helper loaded: url_helper
INFO - 2018-04-26 17:40:11 --> Helper loaded: notification_helper
INFO - 2018-04-26 17:40:11 --> Helper loaded: settings_helper
INFO - 2018-04-26 17:40:11 --> Helper loaded: permission_helper
INFO - 2018-04-26 17:40:11 --> Helper loaded: users_helper
INFO - 2018-04-26 17:40:12 --> Database Driver Class Initialized
DEBUG - 2018-04-26 17:40:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-26 17:40:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-26 17:40:12 --> Helper loaded: form_helper
INFO - 2018-04-26 17:40:12 --> Form Validation Class Initialized
INFO - 2018-04-26 17:40:12 --> Controller Class Initialized
INFO - 2018-04-26 17:40:12 --> Model Class Initialized
INFO - 2018-04-26 17:40:12 --> Helper loaded: inflector_helper
INFO - 2018-04-26 17:40:12 --> Model Class Initialized
INFO - 2018-04-26 17:40:12 --> Model Class Initialized
INFO - 2018-04-26 12:10:12 --> Config Class Initialized
INFO - 2018-04-26 12:10:12 --> Hooks Class Initialized
DEBUG - 2018-04-26 12:10:12 --> UTF-8 Support Enabled
INFO - 2018-04-26 12:10:12 --> Utf8 Class Initialized
INFO - 2018-04-26 12:10:12 --> URI Class Initialized
INFO - 2018-04-26 12:10:12 --> Router Class Initialized
INFO - 2018-04-26 12:10:12 --> Output Class Initialized
INFO - 2018-04-26 12:10:12 --> Security Class Initialized
DEBUG - 2018-04-26 12:10:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-26 12:10:12 --> Input Class Initialized
INFO - 2018-04-26 12:10:12 --> Language Class Initialized
INFO - 2018-04-26 12:10:12 --> Language Class Initialized
INFO - 2018-04-26 12:10:12 --> Config Class Initialized
INFO - 2018-04-26 12:10:12 --> Loader Class Initialized
INFO - 2018-04-26 17:40:12 --> Helper loaded: url_helper
INFO - 2018-04-26 17:40:12 --> Helper loaded: notification_helper
INFO - 2018-04-26 17:40:12 --> Helper loaded: settings_helper
INFO - 2018-04-26 17:40:12 --> Helper loaded: permission_helper
INFO - 2018-04-26 17:40:12 --> Helper loaded: users_helper
INFO - 2018-04-26 17:40:12 --> Database Driver Class Initialized
DEBUG - 2018-04-26 17:40:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-26 17:40:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-26 17:40:12 --> Helper loaded: form_helper
INFO - 2018-04-26 17:40:12 --> Form Validation Class Initialized
INFO - 2018-04-26 17:40:12 --> Controller Class Initialized
INFO - 2018-04-26 17:40:12 --> Model Class Initialized
INFO - 2018-04-26 17:40:12 --> Helper loaded: inflector_helper
INFO - 2018-04-26 17:40:12 --> Model Class Initialized
INFO - 2018-04-26 17:40:12 --> Model Class Initialized
DEBUG - 2018-04-26 17:40:12 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-04-26 17:40:12 --> File loaded: /home/pr01004/public_html/application/views/credits/index.php
DEBUG - 2018-04-26 17:40:12 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-04-26 17:40:12 --> Final output sent to browser
DEBUG - 2018-04-26 17:40:12 --> Total execution time: 0.3092
INFO - 2018-04-26 12:10:20 --> Config Class Initialized
INFO - 2018-04-26 12:10:20 --> Hooks Class Initialized
DEBUG - 2018-04-26 12:10:20 --> UTF-8 Support Enabled
INFO - 2018-04-26 12:10:20 --> Utf8 Class Initialized
INFO - 2018-04-26 12:10:20 --> URI Class Initialized
INFO - 2018-04-26 12:10:20 --> Router Class Initialized
INFO - 2018-04-26 12:10:20 --> Output Class Initialized
INFO - 2018-04-26 12:10:20 --> Security Class Initialized
DEBUG - 2018-04-26 12:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-26 12:10:20 --> Input Class Initialized
INFO - 2018-04-26 12:10:20 --> Language Class Initialized
INFO - 2018-04-26 12:10:21 --> Language Class Initialized
INFO - 2018-04-26 12:10:21 --> Config Class Initialized
INFO - 2018-04-26 12:10:21 --> Loader Class Initialized
INFO - 2018-04-26 17:40:21 --> Helper loaded: url_helper
INFO - 2018-04-26 17:40:21 --> Helper loaded: notification_helper
INFO - 2018-04-26 17:40:21 --> Helper loaded: settings_helper
INFO - 2018-04-26 17:40:21 --> Helper loaded: permission_helper
INFO - 2018-04-26 17:40:21 --> Helper loaded: users_helper
INFO - 2018-04-26 17:40:21 --> Database Driver Class Initialized
DEBUG - 2018-04-26 17:40:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-26 17:40:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-26 17:40:21 --> Helper loaded: form_helper
INFO - 2018-04-26 17:40:21 --> Form Validation Class Initialized
INFO - 2018-04-26 17:40:21 --> Controller Class Initialized
INFO - 2018-04-26 17:40:21 --> Model Class Initialized
INFO - 2018-04-26 17:40:21 --> Helper loaded: inflector_helper
INFO - 2018-04-26 17:40:21 --> Model Class Initialized
INFO - 2018-04-26 17:40:21 --> Model Class Initialized
INFO - 2018-04-26 12:10:21 --> Config Class Initialized
INFO - 2018-04-26 12:10:21 --> Hooks Class Initialized
DEBUG - 2018-04-26 12:10:21 --> UTF-8 Support Enabled
INFO - 2018-04-26 12:10:21 --> Utf8 Class Initialized
INFO - 2018-04-26 12:10:21 --> URI Class Initialized
INFO - 2018-04-26 12:10:21 --> Router Class Initialized
INFO - 2018-04-26 12:10:21 --> Output Class Initialized
INFO - 2018-04-26 12:10:21 --> Security Class Initialized
DEBUG - 2018-04-26 12:10:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-26 12:10:21 --> Input Class Initialized
INFO - 2018-04-26 12:10:21 --> Language Class Initialized
INFO - 2018-04-26 12:10:21 --> Language Class Initialized
INFO - 2018-04-26 12:10:21 --> Config Class Initialized
INFO - 2018-04-26 12:10:21 --> Loader Class Initialized
INFO - 2018-04-26 17:40:21 --> Helper loaded: url_helper
INFO - 2018-04-26 17:40:21 --> Helper loaded: notification_helper
INFO - 2018-04-26 17:40:21 --> Helper loaded: settings_helper
INFO - 2018-04-26 17:40:21 --> Helper loaded: permission_helper
INFO - 2018-04-26 17:40:21 --> Helper loaded: users_helper
INFO - 2018-04-26 17:40:21 --> Database Driver Class Initialized
DEBUG - 2018-04-26 17:40:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-26 17:40:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-26 17:40:21 --> Helper loaded: form_helper
INFO - 2018-04-26 17:40:21 --> Form Validation Class Initialized
INFO - 2018-04-26 17:40:21 --> Controller Class Initialized
INFO - 2018-04-26 17:40:21 --> Model Class Initialized
INFO - 2018-04-26 17:40:21 --> Helper loaded: inflector_helper
INFO - 2018-04-26 17:40:21 --> Model Class Initialized
INFO - 2018-04-26 17:40:21 --> Model Class Initialized
DEBUG - 2018-04-26 17:40:21 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-04-26 17:40:21 --> File loaded: /home/pr01004/public_html/application/views/credits/index.php
DEBUG - 2018-04-26 17:40:21 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-04-26 17:40:21 --> Final output sent to browser
DEBUG - 2018-04-26 17:40:21 --> Total execution time: 0.1044
INFO - 2018-04-26 13:05:54 --> Config Class Initialized
INFO - 2018-04-26 13:05:54 --> Hooks Class Initialized
DEBUG - 2018-04-26 13:05:54 --> UTF-8 Support Enabled
INFO - 2018-04-26 13:05:54 --> Utf8 Class Initialized
INFO - 2018-04-26 13:05:54 --> URI Class Initialized
INFO - 2018-04-26 13:05:54 --> Router Class Initialized
INFO - 2018-04-26 13:05:54 --> Output Class Initialized
INFO - 2018-04-26 13:05:54 --> Security Class Initialized
DEBUG - 2018-04-26 13:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-26 13:05:54 --> Input Class Initialized
INFO - 2018-04-26 13:05:54 --> Language Class Initialized
INFO - 2018-04-26 13:05:54 --> Language Class Initialized
INFO - 2018-04-26 13:05:54 --> Config Class Initialized
INFO - 2018-04-26 13:05:54 --> Loader Class Initialized
INFO - 2018-04-26 18:35:54 --> Helper loaded: url_helper
INFO - 2018-04-26 18:35:54 --> Helper loaded: notification_helper
INFO - 2018-04-26 18:35:54 --> Helper loaded: settings_helper
INFO - 2018-04-26 18:35:54 --> Helper loaded: permission_helper
INFO - 2018-04-26 18:35:54 --> Helper loaded: users_helper
INFO - 2018-04-26 18:35:54 --> Database Driver Class Initialized
DEBUG - 2018-04-26 18:35:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-26 18:35:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-26 18:35:54 --> Helper loaded: form_helper
INFO - 2018-04-26 18:35:54 --> Form Validation Class Initialized
INFO - 2018-04-26 18:35:54 --> Controller Class Initialized
INFO - 2018-04-26 18:35:54 --> Model Class Initialized
INFO - 2018-04-26 18:35:54 --> Helper loaded: inflector_helper
DEBUG - 2018-04-26 18:35:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-26 18:35:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-26 18:35:54 --> Model Class Initialized
INFO - 2018-04-26 18:35:54 --> Model Class Initialized
INFO - 2018-04-26 18:35:54 --> Model Class Initialized
INFO - 2018-04-26 18:35:54 --> Model Class Initialized
INFO - 2018-04-26 18:35:54 --> Model Class Initialized
INFO - 2018-04-26 18:35:54 --> Model Class Initialized
INFO - 2018-04-26 18:35:54 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-26 18:35:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-26 18:35:54 --> Upload Class Initialized
INFO - 2018-04-26 18:35:54 --> Final output sent to browser
DEBUG - 2018-04-26 18:35:54 --> Total execution time: 0.1962
INFO - 2018-04-26 13:35:02 --> Config Class Initialized
INFO - 2018-04-26 13:35:02 --> Hooks Class Initialized
DEBUG - 2018-04-26 13:35:02 --> UTF-8 Support Enabled
INFO - 2018-04-26 13:35:02 --> Utf8 Class Initialized
INFO - 2018-04-26 13:35:02 --> URI Class Initialized
INFO - 2018-04-26 13:35:02 --> Router Class Initialized
INFO - 2018-04-26 13:35:02 --> Output Class Initialized
INFO - 2018-04-26 13:35:02 --> Security Class Initialized
DEBUG - 2018-04-26 13:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-26 13:35:02 --> Input Class Initialized
INFO - 2018-04-26 13:35:02 --> Language Class Initialized
INFO - 2018-04-26 13:35:02 --> Language Class Initialized
INFO - 2018-04-26 13:35:02 --> Config Class Initialized
INFO - 2018-04-26 13:35:02 --> Loader Class Initialized
INFO - 2018-04-26 19:05:02 --> Helper loaded: url_helper
INFO - 2018-04-26 19:05:02 --> Helper loaded: notification_helper
INFO - 2018-04-26 19:05:02 --> Helper loaded: settings_helper
INFO - 2018-04-26 19:05:02 --> Helper loaded: permission_helper
INFO - 2018-04-26 19:05:02 --> Helper loaded: users_helper
INFO - 2018-04-26 19:05:02 --> Database Driver Class Initialized
DEBUG - 2018-04-26 19:05:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-26 19:05:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-26 19:05:02 --> Helper loaded: form_helper
INFO - 2018-04-26 19:05:02 --> Form Validation Class Initialized
INFO - 2018-04-26 19:05:02 --> Controller Class Initialized
INFO - 2018-04-26 19:05:02 --> Model Class Initialized
INFO - 2018-04-26 19:05:02 --> Helper loaded: inflector_helper
DEBUG - 2018-04-26 19:05:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-26 19:05:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-26 19:05:02 --> Model Class Initialized
INFO - 2018-04-26 19:05:02 --> Model Class Initialized
INFO - 2018-04-26 19:05:02 --> Model Class Initialized
INFO - 2018-04-26 19:05:02 --> Model Class Initialized
INFO - 2018-04-26 19:05:02 --> Model Class Initialized
INFO - 2018-04-26 19:05:02 --> Model Class Initialized
INFO - 2018-04-26 19:05:02 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-26 19:05:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-26 19:05:02 --> Upload Class Initialized
INFO - 2018-04-26 19:05:02 --> Final output sent to browser
DEBUG - 2018-04-26 19:05:02 --> Total execution time: 0.1220
INFO - 2018-04-26 13:35:06 --> Config Class Initialized
INFO - 2018-04-26 13:35:06 --> Hooks Class Initialized
DEBUG - 2018-04-26 13:35:06 --> UTF-8 Support Enabled
INFO - 2018-04-26 13:35:06 --> Utf8 Class Initialized
INFO - 2018-04-26 13:35:06 --> URI Class Initialized
INFO - 2018-04-26 13:35:06 --> Router Class Initialized
INFO - 2018-04-26 13:35:06 --> Output Class Initialized
INFO - 2018-04-26 13:35:06 --> Security Class Initialized
DEBUG - 2018-04-26 13:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-26 13:35:06 --> Input Class Initialized
INFO - 2018-04-26 13:35:06 --> Language Class Initialized
INFO - 2018-04-26 13:35:06 --> Language Class Initialized
INFO - 2018-04-26 13:35:06 --> Config Class Initialized
INFO - 2018-04-26 13:35:06 --> Loader Class Initialized
INFO - 2018-04-26 19:05:06 --> Helper loaded: url_helper
INFO - 2018-04-26 19:05:06 --> Helper loaded: notification_helper
INFO - 2018-04-26 19:05:06 --> Helper loaded: settings_helper
INFO - 2018-04-26 19:05:06 --> Helper loaded: permission_helper
INFO - 2018-04-26 19:05:06 --> Helper loaded: users_helper
INFO - 2018-04-26 19:05:06 --> Database Driver Class Initialized
DEBUG - 2018-04-26 19:05:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-26 19:05:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-26 19:05:06 --> Helper loaded: form_helper
INFO - 2018-04-26 19:05:06 --> Form Validation Class Initialized
INFO - 2018-04-26 19:05:06 --> Controller Class Initialized
INFO - 2018-04-26 19:05:06 --> Model Class Initialized
INFO - 2018-04-26 19:05:06 --> Helper loaded: inflector_helper
DEBUG - 2018-04-26 19:05:06 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-26 19:05:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-26 19:05:06 --> Model Class Initialized
INFO - 2018-04-26 19:05:06 --> Model Class Initialized
INFO - 2018-04-26 19:05:06 --> Model Class Initialized
INFO - 2018-04-26 19:05:06 --> Model Class Initialized
INFO - 2018-04-26 19:05:06 --> Model Class Initialized
INFO - 2018-04-26 19:05:06 --> Model Class Initialized
INFO - 2018-04-26 19:05:06 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-26 19:05:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-26 19:05:06 --> Model Class Initialized
INFO - 2018-04-26 19:05:06 --> Email Class Initialized
INFO - 2018-04-26 19:05:06 --> Language file loaded: language/english/email_lang.php
INFO - 2018-04-26 19:05:08 --> Final output sent to browser
DEBUG - 2018-04-26 19:05:08 --> Total execution time: 2.5586
INFO - 2018-04-26 14:02:05 --> Config Class Initialized
INFO - 2018-04-26 14:02:05 --> Hooks Class Initialized
DEBUG - 2018-04-26 14:02:05 --> UTF-8 Support Enabled
INFO - 2018-04-26 14:02:05 --> Utf8 Class Initialized
INFO - 2018-04-26 14:02:05 --> URI Class Initialized
INFO - 2018-04-26 14:02:05 --> Router Class Initialized
INFO - 2018-04-26 14:02:05 --> Output Class Initialized
INFO - 2018-04-26 14:02:05 --> Security Class Initialized
DEBUG - 2018-04-26 14:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-26 14:02:05 --> Input Class Initialized
INFO - 2018-04-26 14:02:05 --> Language Class Initialized
INFO - 2018-04-26 14:02:05 --> Config Class Initialized
INFO - 2018-04-26 14:02:05 --> Hooks Class Initialized
INFO - 2018-04-26 14:02:05 --> Language Class Initialized
INFO - 2018-04-26 14:02:05 --> Config Class Initialized
INFO - 2018-04-26 14:02:05 --> Loader Class Initialized
INFO - 2018-04-26 19:32:05 --> Helper loaded: url_helper
DEBUG - 2018-04-26 14:02:05 --> UTF-8 Support Enabled
INFO - 2018-04-26 14:02:05 --> Utf8 Class Initialized
INFO - 2018-04-26 19:32:05 --> Helper loaded: notification_helper
INFO - 2018-04-26 19:32:05 --> Helper loaded: settings_helper
INFO - 2018-04-26 19:32:05 --> Helper loaded: permission_helper
INFO - 2018-04-26 19:32:05 --> Helper loaded: users_helper
INFO - 2018-04-26 14:02:05 --> URI Class Initialized
INFO - 2018-04-26 14:02:05 --> Router Class Initialized
INFO - 2018-04-26 19:32:05 --> Database Driver Class Initialized
INFO - 2018-04-26 14:02:05 --> Output Class Initialized
DEBUG - 2018-04-26 19:32:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-26 19:32:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-26 14:02:05 --> Security Class Initialized
DEBUG - 2018-04-26 14:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-26 14:02:05 --> Input Class Initialized
INFO - 2018-04-26 19:32:05 --> Helper loaded: form_helper
INFO - 2018-04-26 19:32:05 --> Form Validation Class Initialized
INFO - 2018-04-26 19:32:05 --> Controller Class Initialized
INFO - 2018-04-26 14:02:05 --> Language Class Initialized
INFO - 2018-04-26 14:02:05 --> Config Class Initialized
INFO - 2018-04-26 14:02:05 --> Hooks Class Initialized
INFO - 2018-04-26 14:02:05 --> Config Class Initialized
INFO - 2018-04-26 14:02:05 --> Hooks Class Initialized
INFO - 2018-04-26 19:32:05 --> Model Class Initialized
INFO - 2018-04-26 19:32:05 --> Helper loaded: inflector_helper
DEBUG - 2018-04-26 19:32:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-26 19:32:05 --> Language file loaded: language/english/rest_controller_lang.php
DEBUG - 2018-04-26 14:02:05 --> UTF-8 Support Enabled
INFO - 2018-04-26 14:02:05 --> Utf8 Class Initialized
INFO - 2018-04-26 19:32:05 --> Model Class Initialized
INFO - 2018-04-26 19:32:05 --> Model Class Initialized
INFO - 2018-04-26 19:32:05 --> Model Class Initialized
INFO - 2018-04-26 19:32:05 --> Model Class Initialized
INFO - 2018-04-26 19:32:05 --> Model Class Initialized
INFO - 2018-04-26 19:32:05 --> Model Class Initialized
INFO - 2018-04-26 19:32:05 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-26 14:02:05 --> URI Class Initialized
DEBUG - 2018-04-26 14:02:05 --> UTF-8 Support Enabled
INFO - 2018-04-26 14:02:05 --> Utf8 Class Initialized
INFO - 2018-04-26 19:32:05 --> Model Class Initialized
INFO - 2018-04-26 14:02:05 --> URI Class Initialized
INFO - 2018-04-26 14:02:05 --> Router Class Initialized
INFO - 2018-04-26 19:32:05 --> Final output sent to browser
DEBUG - 2018-04-26 19:32:05 --> Total execution time: 0.1244
INFO - 2018-04-26 14:02:05 --> Output Class Initialized
INFO - 2018-04-26 14:02:05 --> Language Class Initialized
INFO - 2018-04-26 14:02:05 --> Config Class Initialized
INFO - 2018-04-26 14:02:05 --> Loader Class Initialized
INFO - 2018-04-26 14:02:05 --> Security Class Initialized
INFO - 2018-04-26 14:02:05 --> Router Class Initialized
INFO - 2018-04-26 19:32:05 --> Helper loaded: url_helper
DEBUG - 2018-04-26 14:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-26 14:02:05 --> Input Class Initialized
INFO - 2018-04-26 19:32:05 --> Helper loaded: notification_helper
INFO - 2018-04-26 14:02:05 --> Language Class Initialized
INFO - 2018-04-26 19:32:05 --> Helper loaded: settings_helper
INFO - 2018-04-26 19:32:05 --> Helper loaded: permission_helper
INFO - 2018-04-26 14:02:05 --> Output Class Initialized
INFO - 2018-04-26 19:32:05 --> Helper loaded: users_helper
INFO - 2018-04-26 14:02:05 --> Security Class Initialized
DEBUG - 2018-04-26 14:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-26 14:02:05 --> Input Class Initialized
INFO - 2018-04-26 14:02:05 --> Language Class Initialized
INFO - 2018-04-26 19:32:05 --> Database Driver Class Initialized
INFO - 2018-04-26 14:02:05 --> Language Class Initialized
INFO - 2018-04-26 14:02:05 --> Config Class Initialized
INFO - 2018-04-26 14:02:05 --> Loader Class Initialized
DEBUG - 2018-04-26 19:32:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-26 19:32:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-26 19:32:05 --> Helper loaded: url_helper
INFO - 2018-04-26 19:32:05 --> Helper loaded: notification_helper
INFO - 2018-04-26 19:32:05 --> Helper loaded: settings_helper
INFO - 2018-04-26 19:32:05 --> Helper loaded: permission_helper
INFO - 2018-04-26 19:32:05 --> Helper loaded: users_helper
INFO - 2018-04-26 19:32:05 --> Helper loaded: form_helper
INFO - 2018-04-26 19:32:05 --> Form Validation Class Initialized
INFO - 2018-04-26 19:32:05 --> Controller Class Initialized
INFO - 2018-04-26 19:32:05 --> Model Class Initialized
INFO - 2018-04-26 19:32:05 --> Database Driver Class Initialized
INFO - 2018-04-26 19:32:05 --> Helper loaded: inflector_helper
DEBUG - 2018-04-26 19:32:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-04-26 19:32:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-26 19:32:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-26 19:32:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-26 19:32:05 --> Model Class Initialized
INFO - 2018-04-26 19:32:05 --> Model Class Initialized
INFO - 2018-04-26 19:32:05 --> Model Class Initialized
INFO - 2018-04-26 19:32:05 --> Model Class Initialized
INFO - 2018-04-26 19:32:05 --> Model Class Initialized
INFO - 2018-04-26 19:32:05 --> Model Class Initialized
INFO - 2018-04-26 19:32:05 --> Model Class Initialized
INFO - 2018-04-26 19:32:05 --> Model Class Initialized
INFO - 2018-04-26 19:32:05 --> Model Class Initialized
INFO - 2018-04-26 19:32:05 --> Model Class Initialized
INFO - 2018-04-26 19:32:05 --> Helper loaded: form_helper
INFO - 2018-04-26 19:32:05 --> Form Validation Class Initialized
INFO - 2018-04-26 19:32:05 --> Controller Class Initialized
INFO - 2018-04-26 19:32:05 --> Model Class Initialized
INFO - 2018-04-26 19:32:05 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-26 19:32:05 --> Model Class Initialized
INFO - 2018-04-26 14:02:05 --> Language Class Initialized
INFO - 2018-04-26 14:02:05 --> Config Class Initialized
INFO - 2018-04-26 14:02:05 --> Loader Class Initialized
INFO - 2018-04-26 19:32:05 --> Model Class Initialized
INFO - 2018-04-26 19:32:05 --> Helper loaded: inflector_helper
INFO - 2018-04-26 19:32:05 --> Helper loaded: url_helper
DEBUG - 2018-04-26 19:32:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-26 19:32:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-26 19:32:05 --> Helper loaded: notification_helper
INFO - 2018-04-26 19:32:05 --> Model Class Initialized
INFO - 2018-04-26 19:32:05 --> Model Class Initialized
INFO - 2018-04-26 19:32:05 --> Model Class Initialized
INFO - 2018-04-26 19:32:05 --> Helper loaded: settings_helper
INFO - 2018-04-26 19:32:05 --> Model Class Initialized
INFO - 2018-04-26 19:32:05 --> Model Class Initialized
INFO - 2018-04-26 19:32:05 --> Model Class Initialized
INFO - 2018-04-26 19:32:05 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-26 19:32:05 --> Helper loaded: permission_helper
INFO - 2018-04-26 19:32:05 --> Final output sent to browser
DEBUG - 2018-04-26 19:32:05 --> Total execution time: 0.1680
INFO - 2018-04-26 19:32:05 --> Helper loaded: users_helper
INFO - 2018-04-26 19:32:05 --> Final output sent to browser
DEBUG - 2018-04-26 19:32:05 --> Total execution time: 0.2600
INFO - 2018-04-26 19:32:05 --> Database Driver Class Initialized
DEBUG - 2018-04-26 19:32:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-26 19:32:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-26 19:32:05 --> Helper loaded: form_helper
INFO - 2018-04-26 19:32:05 --> Form Validation Class Initialized
INFO - 2018-04-26 19:32:05 --> Controller Class Initialized
INFO - 2018-04-26 19:32:05 --> Model Class Initialized
INFO - 2018-04-26 19:32:05 --> Helper loaded: inflector_helper
DEBUG - 2018-04-26 19:32:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-26 19:32:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-26 19:32:05 --> Model Class Initialized
INFO - 2018-04-26 19:32:05 --> Model Class Initialized
INFO - 2018-04-26 19:32:05 --> Model Class Initialized
INFO - 2018-04-26 19:32:05 --> Model Class Initialized
INFO - 2018-04-26 19:32:05 --> Model Class Initialized
INFO - 2018-04-26 19:32:05 --> Model Class Initialized
INFO - 2018-04-26 19:32:05 --> Model Class Initialized
INFO - 2018-04-26 19:32:05 --> Model Class Initialized
INFO - 2018-04-26 19:32:05 --> Model Class Initialized
INFO - 2018-04-26 19:32:05 --> Model Class Initialized
INFO - 2018-04-26 19:32:05 --> Model Class Initialized
INFO - 2018-04-26 19:32:05 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-26 19:32:05 --> Model Class Initialized
INFO - 2018-04-26 19:32:05 --> Final output sent to browser
DEBUG - 2018-04-26 19:32:05 --> Total execution time: 0.3070
INFO - 2018-04-26 14:02:34 --> Config Class Initialized
INFO - 2018-04-26 14:02:34 --> Hooks Class Initialized
DEBUG - 2018-04-26 14:02:34 --> UTF-8 Support Enabled
INFO - 2018-04-26 14:02:34 --> Utf8 Class Initialized
INFO - 2018-04-26 14:02:34 --> URI Class Initialized
INFO - 2018-04-26 14:02:34 --> Router Class Initialized
INFO - 2018-04-26 14:02:34 --> Output Class Initialized
INFO - 2018-04-26 14:02:34 --> Security Class Initialized
DEBUG - 2018-04-26 14:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-26 14:02:34 --> Input Class Initialized
INFO - 2018-04-26 14:02:34 --> Language Class Initialized
INFO - 2018-04-26 14:02:34 --> Config Class Initialized
INFO - 2018-04-26 14:02:34 --> Hooks Class Initialized
INFO - 2018-04-26 14:02:34 --> Language Class Initialized
INFO - 2018-04-26 14:02:34 --> Config Class Initialized
INFO - 2018-04-26 14:02:34 --> Loader Class Initialized
INFO - 2018-04-26 19:32:34 --> Helper loaded: url_helper
DEBUG - 2018-04-26 14:02:34 --> UTF-8 Support Enabled
INFO - 2018-04-26 14:02:34 --> Utf8 Class Initialized
INFO - 2018-04-26 19:32:34 --> Helper loaded: notification_helper
INFO - 2018-04-26 19:32:34 --> Helper loaded: settings_helper
INFO - 2018-04-26 19:32:34 --> Helper loaded: permission_helper
INFO - 2018-04-26 19:32:34 --> Helper loaded: users_helper
INFO - 2018-04-26 14:02:34 --> URI Class Initialized
INFO - 2018-04-26 14:02:34 --> Router Class Initialized
INFO - 2018-04-26 14:02:34 --> Output Class Initialized
INFO - 2018-04-26 14:02:34 --> Security Class Initialized
INFO - 2018-04-26 19:32:34 --> Database Driver Class Initialized
DEBUG - 2018-04-26 14:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-26 14:02:34 --> Input Class Initialized
INFO - 2018-04-26 14:02:34 --> Language Class Initialized
DEBUG - 2018-04-26 19:32:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-26 19:32:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-26 19:32:34 --> Helper loaded: form_helper
INFO - 2018-04-26 19:32:34 --> Form Validation Class Initialized
INFO - 2018-04-26 19:32:34 --> Controller Class Initialized
INFO - 2018-04-26 19:32:34 --> Model Class Initialized
INFO - 2018-04-26 19:32:34 --> Helper loaded: inflector_helper
DEBUG - 2018-04-26 19:32:34 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-26 19:32:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-26 19:32:34 --> Model Class Initialized
INFO - 2018-04-26 19:32:34 --> Model Class Initialized
INFO - 2018-04-26 19:32:34 --> Model Class Initialized
INFO - 2018-04-26 19:32:34 --> Model Class Initialized
INFO - 2018-04-26 19:32:34 --> Model Class Initialized
INFO - 2018-04-26 19:32:34 --> Model Class Initialized
INFO - 2018-04-26 19:32:34 --> Model Class Initialized
INFO - 2018-04-26 19:32:34 --> Model Class Initialized
INFO - 2018-04-26 19:32:34 --> Model Class Initialized
INFO - 2018-04-26 19:32:34 --> Model Class Initialized
INFO - 2018-04-26 19:32:34 --> Model Class Initialized
INFO - 2018-04-26 19:32:34 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-26 19:32:34 --> Model Class Initialized
INFO - 2018-04-26 19:32:34 --> Final output sent to browser
DEBUG - 2018-04-26 19:32:34 --> Total execution time: 0.0985
INFO - 2018-04-26 14:02:34 --> Language Class Initialized
INFO - 2018-04-26 14:02:34 --> Config Class Initialized
INFO - 2018-04-26 14:02:34 --> Loader Class Initialized
INFO - 2018-04-26 19:32:34 --> Helper loaded: url_helper
INFO - 2018-04-26 19:32:34 --> Helper loaded: notification_helper
INFO - 2018-04-26 19:32:34 --> Helper loaded: settings_helper
INFO - 2018-04-26 19:32:34 --> Helper loaded: permission_helper
INFO - 2018-04-26 19:32:34 --> Helper loaded: users_helper
INFO - 2018-04-26 19:32:34 --> Database Driver Class Initialized
DEBUG - 2018-04-26 19:32:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-26 19:32:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-26 19:32:34 --> Helper loaded: form_helper
INFO - 2018-04-26 19:32:34 --> Form Validation Class Initialized
INFO - 2018-04-26 19:32:34 --> Controller Class Initialized
INFO - 2018-04-26 19:32:34 --> Model Class Initialized
INFO - 2018-04-26 19:32:34 --> Helper loaded: inflector_helper
DEBUG - 2018-04-26 19:32:34 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-26 19:32:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-26 19:32:34 --> Model Class Initialized
INFO - 2018-04-26 19:32:34 --> Model Class Initialized
INFO - 2018-04-26 19:32:34 --> Model Class Initialized
INFO - 2018-04-26 19:32:34 --> Model Class Initialized
INFO - 2018-04-26 19:32:34 --> Model Class Initialized
INFO - 2018-04-26 19:32:34 --> Model Class Initialized
INFO - 2018-04-26 19:32:34 --> Model Class Initialized
INFO - 2018-04-26 19:32:34 --> Model Class Initialized
INFO - 2018-04-26 19:32:34 --> Model Class Initialized
INFO - 2018-04-26 19:32:34 --> Model Class Initialized
INFO - 2018-04-26 19:32:34 --> Model Class Initialized
INFO - 2018-04-26 19:32:34 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-26 19:32:34 --> Final output sent to browser
DEBUG - 2018-04-26 19:32:34 --> Total execution time: 0.2078
INFO - 2018-04-26 14:02:43 --> Config Class Initialized
INFO - 2018-04-26 14:02:43 --> Hooks Class Initialized
DEBUG - 2018-04-26 14:02:43 --> UTF-8 Support Enabled
INFO - 2018-04-26 14:02:43 --> Utf8 Class Initialized
INFO - 2018-04-26 14:02:43 --> URI Class Initialized
INFO - 2018-04-26 14:02:43 --> Router Class Initialized
INFO - 2018-04-26 14:02:43 --> Output Class Initialized
INFO - 2018-04-26 14:02:43 --> Security Class Initialized
DEBUG - 2018-04-26 14:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-26 14:02:43 --> Input Class Initialized
INFO - 2018-04-26 14:02:43 --> Language Class Initialized
INFO - 2018-04-26 14:02:43 --> Language Class Initialized
INFO - 2018-04-26 14:02:43 --> Config Class Initialized
INFO - 2018-04-26 14:02:43 --> Loader Class Initialized
INFO - 2018-04-26 19:32:43 --> Helper loaded: url_helper
INFO - 2018-04-26 19:32:43 --> Helper loaded: notification_helper
INFO - 2018-04-26 19:32:43 --> Helper loaded: settings_helper
INFO - 2018-04-26 19:32:43 --> Helper loaded: permission_helper
INFO - 2018-04-26 19:32:43 --> Helper loaded: users_helper
INFO - 2018-04-26 19:32:43 --> Database Driver Class Initialized
DEBUG - 2018-04-26 19:32:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-26 19:32:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-26 19:32:43 --> Helper loaded: form_helper
INFO - 2018-04-26 19:32:43 --> Form Validation Class Initialized
INFO - 2018-04-26 19:32:43 --> Controller Class Initialized
INFO - 2018-04-26 19:32:43 --> Model Class Initialized
INFO - 2018-04-26 19:32:43 --> Helper loaded: inflector_helper
DEBUG - 2018-04-26 19:32:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-26 19:32:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-26 19:32:43 --> Model Class Initialized
INFO - 2018-04-26 19:32:43 --> Model Class Initialized
INFO - 2018-04-26 19:32:43 --> Model Class Initialized
INFO - 2018-04-26 19:32:43 --> Model Class Initialized
INFO - 2018-04-26 19:32:43 --> Model Class Initialized
INFO - 2018-04-26 19:32:43 --> Model Class Initialized
INFO - 2018-04-26 19:32:43 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-04-26 19:32:43 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 800
INFO - 2018-04-26 19:32:43 --> Final output sent to browser
DEBUG - 2018-04-26 19:32:43 --> Total execution time: 0.2701
INFO - 2018-04-26 14:02:50 --> Config Class Initialized
INFO - 2018-04-26 14:02:50 --> Hooks Class Initialized
DEBUG - 2018-04-26 14:02:50 --> UTF-8 Support Enabled
INFO - 2018-04-26 14:02:50 --> Utf8 Class Initialized
INFO - 2018-04-26 14:02:50 --> URI Class Initialized
INFO - 2018-04-26 14:02:50 --> Router Class Initialized
INFO - 2018-04-26 14:02:50 --> Output Class Initialized
INFO - 2018-04-26 14:02:50 --> Security Class Initialized
DEBUG - 2018-04-26 14:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-26 14:02:50 --> Input Class Initialized
INFO - 2018-04-26 14:02:50 --> Language Class Initialized
INFO - 2018-04-26 14:02:50 --> Language Class Initialized
INFO - 2018-04-26 14:02:50 --> Config Class Initialized
INFO - 2018-04-26 14:02:50 --> Loader Class Initialized
INFO - 2018-04-26 19:32:50 --> Helper loaded: url_helper
INFO - 2018-04-26 19:32:50 --> Helper loaded: notification_helper
INFO - 2018-04-26 19:32:50 --> Helper loaded: settings_helper
INFO - 2018-04-26 19:32:50 --> Helper loaded: permission_helper
INFO - 2018-04-26 19:32:50 --> Helper loaded: users_helper
INFO - 2018-04-26 19:32:50 --> Database Driver Class Initialized
DEBUG - 2018-04-26 19:32:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-26 19:32:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-26 14:02:50 --> Config Class Initialized
INFO - 2018-04-26 14:02:50 --> Hooks Class Initialized
INFO - 2018-04-26 19:32:50 --> Helper loaded: form_helper
INFO - 2018-04-26 19:32:50 --> Form Validation Class Initialized
INFO - 2018-04-26 19:32:50 --> Controller Class Initialized
DEBUG - 2018-04-26 14:02:50 --> UTF-8 Support Enabled
INFO - 2018-04-26 14:02:50 --> Utf8 Class Initialized
INFO - 2018-04-26 14:02:50 --> URI Class Initialized
INFO - 2018-04-26 19:32:50 --> Model Class Initialized
INFO - 2018-04-26 19:32:50 --> Helper loaded: inflector_helper
DEBUG - 2018-04-26 19:32:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-26 19:32:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-26 19:32:50 --> Model Class Initialized
INFO - 2018-04-26 19:32:50 --> Model Class Initialized
INFO - 2018-04-26 14:02:50 --> Router Class Initialized
INFO - 2018-04-26 19:32:50 --> Model Class Initialized
INFO - 2018-04-26 19:32:50 --> Model Class Initialized
INFO - 2018-04-26 19:32:50 --> Model Class Initialized
INFO - 2018-04-26 19:32:50 --> Model Class Initialized
INFO - 2018-04-26 19:32:50 --> Model Class Initialized
INFO - 2018-04-26 19:32:50 --> Model Class Initialized
INFO - 2018-04-26 19:32:50 --> Model Class Initialized
INFO - 2018-04-26 19:32:50 --> Model Class Initialized
INFO - 2018-04-26 14:02:50 --> Output Class Initialized
INFO - 2018-04-26 19:32:50 --> Model Class Initialized
INFO - 2018-04-26 19:32:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-26 19:32:50 --> Model Class Initialized
INFO - 2018-04-26 14:02:50 --> Security Class Initialized
DEBUG - 2018-04-26 14:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-26 14:02:50 --> Input Class Initialized
INFO - 2018-04-26 14:02:50 --> Language Class Initialized
INFO - 2018-04-26 19:32:50 --> Final output sent to browser
DEBUG - 2018-04-26 19:32:50 --> Total execution time: 0.1418
INFO - 2018-04-26 14:02:50 --> Language Class Initialized
INFO - 2018-04-26 14:02:50 --> Config Class Initialized
INFO - 2018-04-26 14:02:50 --> Loader Class Initialized
INFO - 2018-04-26 19:32:50 --> Helper loaded: url_helper
INFO - 2018-04-26 19:32:50 --> Helper loaded: notification_helper
INFO - 2018-04-26 19:32:50 --> Helper loaded: settings_helper
INFO - 2018-04-26 19:32:50 --> Helper loaded: permission_helper
INFO - 2018-04-26 19:32:50 --> Helper loaded: users_helper
INFO - 2018-04-26 19:32:50 --> Database Driver Class Initialized
DEBUG - 2018-04-26 19:32:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-26 19:32:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-26 19:32:50 --> Helper loaded: form_helper
INFO - 2018-04-26 19:32:50 --> Form Validation Class Initialized
INFO - 2018-04-26 19:32:50 --> Controller Class Initialized
INFO - 2018-04-26 19:32:50 --> Model Class Initialized
INFO - 2018-04-26 19:32:50 --> Helper loaded: inflector_helper
DEBUG - 2018-04-26 19:32:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-26 19:32:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-26 19:32:50 --> Model Class Initialized
INFO - 2018-04-26 19:32:50 --> Model Class Initialized
INFO - 2018-04-26 19:32:50 --> Model Class Initialized
INFO - 2018-04-26 19:32:50 --> Model Class Initialized
INFO - 2018-04-26 19:32:50 --> Model Class Initialized
INFO - 2018-04-26 19:32:50 --> Model Class Initialized
INFO - 2018-04-26 19:32:50 --> Model Class Initialized
INFO - 2018-04-26 19:32:50 --> Model Class Initialized
INFO - 2018-04-26 19:32:50 --> Model Class Initialized
INFO - 2018-04-26 19:32:50 --> Model Class Initialized
INFO - 2018-04-26 19:32:50 --> Model Class Initialized
INFO - 2018-04-26 19:32:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-26 19:32:50 --> Final output sent to browser
DEBUG - 2018-04-26 19:32:50 --> Total execution time: 0.2500
INFO - 2018-04-26 14:02:52 --> Config Class Initialized
INFO - 2018-04-26 14:02:52 --> Hooks Class Initialized
DEBUG - 2018-04-26 14:02:52 --> UTF-8 Support Enabled
INFO - 2018-04-26 14:02:52 --> Utf8 Class Initialized
INFO - 2018-04-26 14:02:52 --> URI Class Initialized
INFO - 2018-04-26 14:02:52 --> Router Class Initialized
INFO - 2018-04-26 14:02:52 --> Output Class Initialized
INFO - 2018-04-26 14:02:52 --> Security Class Initialized
DEBUG - 2018-04-26 14:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-26 14:02:52 --> Input Class Initialized
INFO - 2018-04-26 14:02:52 --> Language Class Initialized
INFO - 2018-04-26 14:02:52 --> Language Class Initialized
INFO - 2018-04-26 14:02:52 --> Config Class Initialized
INFO - 2018-04-26 14:02:52 --> Loader Class Initialized
INFO - 2018-04-26 19:32:52 --> Helper loaded: url_helper
INFO - 2018-04-26 19:32:52 --> Helper loaded: notification_helper
INFO - 2018-04-26 19:32:52 --> Helper loaded: settings_helper
INFO - 2018-04-26 19:32:52 --> Helper loaded: permission_helper
INFO - 2018-04-26 19:32:52 --> Helper loaded: users_helper
INFO - 2018-04-26 14:02:52 --> Config Class Initialized
INFO - 2018-04-26 14:02:52 --> Hooks Class Initialized
DEBUG - 2018-04-26 14:02:52 --> UTF-8 Support Enabled
INFO - 2018-04-26 14:02:52 --> Utf8 Class Initialized
INFO - 2018-04-26 14:02:52 --> URI Class Initialized
INFO - 2018-04-26 19:32:52 --> Database Driver Class Initialized
INFO - 2018-04-26 14:02:52 --> Router Class Initialized
INFO - 2018-04-26 14:02:52 --> Output Class Initialized
DEBUG - 2018-04-26 19:32:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-26 19:32:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-26 14:02:52 --> Security Class Initialized
DEBUG - 2018-04-26 14:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-26 14:02:52 --> Input Class Initialized
INFO - 2018-04-26 14:02:52 --> Language Class Initialized
INFO - 2018-04-26 19:32:52 --> Helper loaded: form_helper
INFO - 2018-04-26 19:32:52 --> Form Validation Class Initialized
INFO - 2018-04-26 19:32:52 --> Controller Class Initialized
INFO - 2018-04-26 19:32:52 --> Model Class Initialized
INFO - 2018-04-26 19:32:52 --> Helper loaded: inflector_helper
DEBUG - 2018-04-26 19:32:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-26 19:32:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-26 14:02:52 --> Language Class Initialized
INFO - 2018-04-26 14:02:52 --> Config Class Initialized
INFO - 2018-04-26 14:02:52 --> Loader Class Initialized
INFO - 2018-04-26 19:32:52 --> Model Class Initialized
INFO - 2018-04-26 19:32:52 --> Model Class Initialized
INFO - 2018-04-26 19:32:52 --> Model Class Initialized
INFO - 2018-04-26 19:32:52 --> Model Class Initialized
INFO - 2018-04-26 19:32:52 --> Helper loaded: url_helper
INFO - 2018-04-26 19:32:52 --> Model Class Initialized
INFO - 2018-04-26 19:32:52 --> Model Class Initialized
INFO - 2018-04-26 19:32:52 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-26 19:32:52 --> Helper loaded: notification_helper
INFO - 2018-04-26 19:32:52 --> Helper loaded: settings_helper
INFO - 2018-04-26 19:32:52 --> Helper loaded: permission_helper
INFO - 2018-04-26 19:32:52 --> Final output sent to browser
DEBUG - 2018-04-26 19:32:52 --> Total execution time: 0.1092
INFO - 2018-04-26 19:32:52 --> Helper loaded: users_helper
INFO - 2018-04-26 19:32:52 --> Database Driver Class Initialized
DEBUG - 2018-04-26 19:32:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-26 19:32:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-26 19:32:52 --> Helper loaded: form_helper
INFO - 2018-04-26 19:32:52 --> Form Validation Class Initialized
INFO - 2018-04-26 19:32:52 --> Controller Class Initialized
INFO - 2018-04-26 19:32:52 --> Model Class Initialized
INFO - 2018-04-26 19:32:52 --> Helper loaded: inflector_helper
DEBUG - 2018-04-26 19:32:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-26 19:32:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-26 19:32:52 --> Model Class Initialized
INFO - 2018-04-26 19:32:52 --> Model Class Initialized
INFO - 2018-04-26 19:32:52 --> Model Class Initialized
INFO - 2018-04-26 19:32:52 --> Model Class Initialized
INFO - 2018-04-26 19:32:52 --> Model Class Initialized
INFO - 2018-04-26 19:32:52 --> Model Class Initialized
INFO - 2018-04-26 19:32:52 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-26 19:32:52 --> Final output sent to browser
DEBUG - 2018-04-26 19:32:52 --> Total execution time: 0.1136
INFO - 2018-04-26 14:02:52 --> Config Class Initialized
INFO - 2018-04-26 14:02:52 --> Hooks Class Initialized
DEBUG - 2018-04-26 14:02:52 --> UTF-8 Support Enabled
INFO - 2018-04-26 14:02:52 --> Utf8 Class Initialized
INFO - 2018-04-26 14:02:52 --> URI Class Initialized
INFO - 2018-04-26 14:02:52 --> Router Class Initialized
INFO - 2018-04-26 14:02:52 --> Output Class Initialized
INFO - 2018-04-26 14:02:52 --> Security Class Initialized
DEBUG - 2018-04-26 14:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-26 14:02:52 --> Input Class Initialized
INFO - 2018-04-26 14:02:52 --> Language Class Initialized
INFO - 2018-04-26 14:02:52 --> Language Class Initialized
INFO - 2018-04-26 14:02:52 --> Config Class Initialized
INFO - 2018-04-26 14:02:52 --> Loader Class Initialized
INFO - 2018-04-26 19:32:52 --> Helper loaded: url_helper
INFO - 2018-04-26 19:32:52 --> Helper loaded: notification_helper
INFO - 2018-04-26 19:32:52 --> Helper loaded: settings_helper
INFO - 2018-04-26 19:32:52 --> Helper loaded: permission_helper
INFO - 2018-04-26 19:32:52 --> Helper loaded: users_helper
INFO - 2018-04-26 19:32:52 --> Database Driver Class Initialized
DEBUG - 2018-04-26 19:32:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-26 19:32:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-26 19:32:52 --> Helper loaded: form_helper
INFO - 2018-04-26 19:32:52 --> Form Validation Class Initialized
INFO - 2018-04-26 19:32:52 --> Controller Class Initialized
INFO - 2018-04-26 19:32:52 --> Model Class Initialized
INFO - 2018-04-26 19:32:52 --> Helper loaded: inflector_helper
DEBUG - 2018-04-26 19:32:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-26 19:32:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-26 19:32:52 --> Model Class Initialized
INFO - 2018-04-26 19:32:52 --> Model Class Initialized
INFO - 2018-04-26 19:32:52 --> Model Class Initialized
INFO - 2018-04-26 19:32:52 --> Model Class Initialized
INFO - 2018-04-26 19:32:52 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-26 19:32:52 --> Final output sent to browser
DEBUG - 2018-04-26 19:32:52 --> Total execution time: 0.1004
INFO - 2018-04-26 14:20:17 --> Config Class Initialized
INFO - 2018-04-26 14:20:17 --> Hooks Class Initialized
DEBUG - 2018-04-26 14:20:17 --> UTF-8 Support Enabled
INFO - 2018-04-26 14:20:17 --> Utf8 Class Initialized
INFO - 2018-04-26 14:20:17 --> URI Class Initialized
DEBUG - 2018-04-26 14:20:17 --> No URI present. Default controller set.
INFO - 2018-04-26 14:20:17 --> Router Class Initialized
INFO - 2018-04-26 14:20:17 --> Output Class Initialized
INFO - 2018-04-26 14:20:17 --> Security Class Initialized
DEBUG - 2018-04-26 14:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-26 14:20:17 --> Input Class Initialized
INFO - 2018-04-26 14:20:17 --> Language Class Initialized
INFO - 2018-04-26 14:20:17 --> Language Class Initialized
INFO - 2018-04-26 14:20:17 --> Config Class Initialized
INFO - 2018-04-26 14:20:17 --> Loader Class Initialized
INFO - 2018-04-26 19:50:17 --> Helper loaded: url_helper
INFO - 2018-04-26 19:50:17 --> Helper loaded: notification_helper
INFO - 2018-04-26 19:50:17 --> Helper loaded: settings_helper
INFO - 2018-04-26 19:50:17 --> Helper loaded: permission_helper
INFO - 2018-04-26 19:50:17 --> Helper loaded: users_helper
INFO - 2018-04-26 19:50:17 --> Database Driver Class Initialized
DEBUG - 2018-04-26 19:50:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-26 19:50:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-26 19:50:17 --> Helper loaded: form_helper
INFO - 2018-04-26 19:50:17 --> Form Validation Class Initialized
INFO - 2018-04-26 19:50:17 --> Controller Class Initialized
INFO - 2018-04-26 19:50:17 --> Model Class Initialized
INFO - 2018-04-26 19:50:17 --> Helper loaded: inflector_helper
INFO - 2018-04-26 19:50:17 --> Model Class Initialized
DEBUG - 2018-04-26 19:50:17 --> File loaded: /home/pr01004/public_html/application/views/login.php
INFO - 2018-04-26 19:50:17 --> Final output sent to browser
DEBUG - 2018-04-26 19:50:17 --> Total execution time: 0.1881
INFO - 2018-04-26 14:20:26 --> Config Class Initialized
INFO - 2018-04-26 14:20:26 --> Hooks Class Initialized
DEBUG - 2018-04-26 14:20:26 --> UTF-8 Support Enabled
INFO - 2018-04-26 14:20:26 --> Utf8 Class Initialized
INFO - 2018-04-26 14:20:26 --> URI Class Initialized
INFO - 2018-04-26 14:20:26 --> Router Class Initialized
INFO - 2018-04-26 14:20:26 --> Output Class Initialized
INFO - 2018-04-26 14:20:26 --> Security Class Initialized
DEBUG - 2018-04-26 14:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-26 14:20:26 --> Input Class Initialized
INFO - 2018-04-26 14:20:26 --> Language Class Initialized
INFO - 2018-04-26 14:20:26 --> Language Class Initialized
INFO - 2018-04-26 14:20:26 --> Config Class Initialized
INFO - 2018-04-26 14:20:26 --> Loader Class Initialized
INFO - 2018-04-26 19:50:26 --> Helper loaded: url_helper
INFO - 2018-04-26 19:50:26 --> Helper loaded: notification_helper
INFO - 2018-04-26 19:50:26 --> Helper loaded: settings_helper
INFO - 2018-04-26 19:50:26 --> Helper loaded: permission_helper
INFO - 2018-04-26 19:50:26 --> Helper loaded: users_helper
INFO - 2018-04-26 19:50:26 --> Database Driver Class Initialized
DEBUG - 2018-04-26 19:50:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-26 19:50:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-26 19:50:26 --> Helper loaded: form_helper
INFO - 2018-04-26 19:50:26 --> Form Validation Class Initialized
INFO - 2018-04-26 19:50:26 --> Controller Class Initialized
INFO - 2018-04-26 19:50:26 --> Model Class Initialized
INFO - 2018-04-26 19:50:26 --> Helper loaded: inflector_helper
INFO - 2018-04-26 19:50:26 --> Model Class Initialized
INFO - 2018-04-26 19:50:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-26 14:20:27 --> Config Class Initialized
INFO - 2018-04-26 14:20:27 --> Hooks Class Initialized
DEBUG - 2018-04-26 14:20:27 --> UTF-8 Support Enabled
INFO - 2018-04-26 14:20:27 --> Utf8 Class Initialized
INFO - 2018-04-26 14:20:27 --> URI Class Initialized
INFO - 2018-04-26 14:20:27 --> Router Class Initialized
INFO - 2018-04-26 14:20:27 --> Output Class Initialized
INFO - 2018-04-26 14:20:27 --> Security Class Initialized
DEBUG - 2018-04-26 14:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-26 14:20:27 --> Input Class Initialized
INFO - 2018-04-26 14:20:27 --> Language Class Initialized
INFO - 2018-04-26 14:20:27 --> Language Class Initialized
INFO - 2018-04-26 14:20:27 --> Config Class Initialized
INFO - 2018-04-26 14:20:27 --> Loader Class Initialized
INFO - 2018-04-26 19:50:27 --> Helper loaded: url_helper
INFO - 2018-04-26 19:50:27 --> Helper loaded: notification_helper
INFO - 2018-04-26 19:50:27 --> Helper loaded: settings_helper
INFO - 2018-04-26 19:50:27 --> Helper loaded: permission_helper
INFO - 2018-04-26 19:50:27 --> Helper loaded: users_helper
INFO - 2018-04-26 19:50:27 --> Database Driver Class Initialized
DEBUG - 2018-04-26 19:50:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-26 19:50:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-26 19:50:27 --> Helper loaded: form_helper
INFO - 2018-04-26 19:50:27 --> Form Validation Class Initialized
INFO - 2018-04-26 19:50:27 --> Controller Class Initialized
INFO - 2018-04-26 19:50:27 --> Model Class Initialized
INFO - 2018-04-26 19:50:27 --> Helper loaded: inflector_helper
INFO - 2018-04-26 19:50:27 --> Model Class Initialized
INFO - 2018-04-26 19:50:27 --> Model Class Initialized
INFO - 2018-04-26 19:50:27 --> Model Class Initialized
INFO - 2018-04-26 19:50:27 --> Model Class Initialized
INFO - 2018-04-26 19:50:27 --> Model Class Initialized
DEBUG - 2018-04-26 19:50:27 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-04-26 19:50:27 --> File loaded: /home/pr01004/public_html/application/views/admin/dashboard.php
DEBUG - 2018-04-26 19:50:27 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-04-26 19:50:27 --> Final output sent to browser
DEBUG - 2018-04-26 19:50:27 --> Total execution time: 0.1072
INFO - 2018-04-26 14:20:27 --> Config Class Initialized
INFO - 2018-04-26 14:20:27 --> Hooks Class Initialized
DEBUG - 2018-04-26 14:20:27 --> UTF-8 Support Enabled
INFO - 2018-04-26 14:20:27 --> Utf8 Class Initialized
INFO - 2018-04-26 14:20:27 --> URI Class Initialized
INFO - 2018-04-26 14:20:27 --> Router Class Initialized
INFO - 2018-04-26 14:20:27 --> Output Class Initialized
INFO - 2018-04-26 14:20:27 --> Security Class Initialized
DEBUG - 2018-04-26 14:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-26 14:20:27 --> Input Class Initialized
INFO - 2018-04-26 14:20:27 --> Language Class Initialized
INFO - 2018-04-26 14:20:27 --> Language Class Initialized
INFO - 2018-04-26 14:20:27 --> Config Class Initialized
INFO - 2018-04-26 14:20:27 --> Loader Class Initialized
INFO - 2018-04-26 19:50:27 --> Helper loaded: url_helper
INFO - 2018-04-26 19:50:27 --> Helper loaded: notification_helper
INFO - 2018-04-26 19:50:27 --> Helper loaded: settings_helper
INFO - 2018-04-26 19:50:27 --> Helper loaded: permission_helper
INFO - 2018-04-26 19:50:27 --> Helper loaded: users_helper
INFO - 2018-04-26 19:50:27 --> Database Driver Class Initialized
DEBUG - 2018-04-26 19:50:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-26 19:50:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-26 19:50:27 --> Helper loaded: form_helper
INFO - 2018-04-26 19:50:27 --> Form Validation Class Initialized
INFO - 2018-04-26 19:50:27 --> Controller Class Initialized
DEBUG - 2018-04-26 19:50:27 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-04-26 19:50:27 --> Final output sent to browser
DEBUG - 2018-04-26 19:50:27 --> Total execution time: 0.0695
INFO - 2018-04-26 14:20:32 --> Config Class Initialized
INFO - 2018-04-26 14:20:32 --> Hooks Class Initialized
DEBUG - 2018-04-26 14:20:32 --> UTF-8 Support Enabled
INFO - 2018-04-26 14:20:32 --> Utf8 Class Initialized
INFO - 2018-04-26 14:20:32 --> URI Class Initialized
INFO - 2018-04-26 14:20:32 --> Router Class Initialized
INFO - 2018-04-26 14:20:32 --> Output Class Initialized
INFO - 2018-04-26 14:20:32 --> Security Class Initialized
DEBUG - 2018-04-26 14:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-26 14:20:32 --> Input Class Initialized
INFO - 2018-04-26 14:20:32 --> Language Class Initialized
INFO - 2018-04-26 14:20:32 --> Language Class Initialized
INFO - 2018-04-26 14:20:32 --> Config Class Initialized
INFO - 2018-04-26 14:20:32 --> Loader Class Initialized
INFO - 2018-04-26 19:50:32 --> Helper loaded: url_helper
INFO - 2018-04-26 19:50:32 --> Helper loaded: notification_helper
INFO - 2018-04-26 19:50:32 --> Helper loaded: settings_helper
INFO - 2018-04-26 19:50:32 --> Helper loaded: permission_helper
INFO - 2018-04-26 19:50:32 --> Helper loaded: users_helper
INFO - 2018-04-26 19:50:32 --> Database Driver Class Initialized
DEBUG - 2018-04-26 19:50:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-26 19:50:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-26 19:50:32 --> Helper loaded: form_helper
INFO - 2018-04-26 19:50:32 --> Form Validation Class Initialized
INFO - 2018-04-26 19:50:32 --> Controller Class Initialized
INFO - 2018-04-26 19:50:32 --> Model Class Initialized
INFO - 2018-04-26 19:50:32 --> Helper loaded: inflector_helper
INFO - 2018-04-26 19:50:32 --> Model Class Initialized
INFO - 2018-04-26 19:50:32 --> Model Class Initialized
DEBUG - 2018-04-26 19:50:32 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-04-26 19:50:32 --> File loaded: /home/pr01004/public_html/application/views/credits/index.php
DEBUG - 2018-04-26 19:50:32 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-04-26 19:50:32 --> Final output sent to browser
DEBUG - 2018-04-26 19:50:32 --> Total execution time: 0.0833
INFO - 2018-04-26 14:20:34 --> Config Class Initialized
INFO - 2018-04-26 14:20:34 --> Hooks Class Initialized
DEBUG - 2018-04-26 14:20:34 --> UTF-8 Support Enabled
INFO - 2018-04-26 14:20:34 --> Utf8 Class Initialized
INFO - 2018-04-26 14:20:34 --> URI Class Initialized
INFO - 2018-04-26 14:20:34 --> Router Class Initialized
INFO - 2018-04-26 14:20:34 --> Output Class Initialized
INFO - 2018-04-26 14:20:34 --> Security Class Initialized
DEBUG - 2018-04-26 14:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-26 14:20:34 --> Input Class Initialized
INFO - 2018-04-26 14:20:34 --> Language Class Initialized
INFO - 2018-04-26 14:20:34 --> Language Class Initialized
INFO - 2018-04-26 14:20:34 --> Config Class Initialized
INFO - 2018-04-26 14:20:34 --> Loader Class Initialized
INFO - 2018-04-26 19:50:34 --> Helper loaded: url_helper
INFO - 2018-04-26 19:50:34 --> Helper loaded: notification_helper
INFO - 2018-04-26 19:50:34 --> Helper loaded: settings_helper
INFO - 2018-04-26 19:50:34 --> Helper loaded: permission_helper
INFO - 2018-04-26 19:50:34 --> Helper loaded: users_helper
INFO - 2018-04-26 19:50:34 --> Database Driver Class Initialized
DEBUG - 2018-04-26 19:50:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-26 19:50:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-26 19:50:34 --> Helper loaded: form_helper
INFO - 2018-04-26 19:50:34 --> Form Validation Class Initialized
INFO - 2018-04-26 19:50:34 --> Controller Class Initialized
INFO - 2018-04-26 19:50:34 --> Model Class Initialized
INFO - 2018-04-26 19:50:34 --> Helper loaded: inflector_helper
INFO - 2018-04-26 19:50:34 --> Model Class Initialized
INFO - 2018-04-26 19:50:34 --> Model Class Initialized
DEBUG - 2018-04-26 19:50:34 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-04-26 19:50:34 --> File loaded: /home/pr01004/public_html/application/views/credits/edit.php
DEBUG - 2018-04-26 19:50:34 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-04-26 19:50:34 --> Final output sent to browser
DEBUG - 2018-04-26 19:50:34 --> Total execution time: 0.1621
INFO - 2018-04-26 14:20:36 --> Config Class Initialized
INFO - 2018-04-26 14:20:36 --> Hooks Class Initialized
DEBUG - 2018-04-26 14:20:36 --> UTF-8 Support Enabled
INFO - 2018-04-26 14:20:36 --> Utf8 Class Initialized
INFO - 2018-04-26 14:20:36 --> URI Class Initialized
INFO - 2018-04-26 14:20:36 --> Router Class Initialized
INFO - 2018-04-26 14:20:36 --> Output Class Initialized
INFO - 2018-04-26 14:20:36 --> Security Class Initialized
DEBUG - 2018-04-26 14:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-26 14:20:36 --> Input Class Initialized
INFO - 2018-04-26 14:20:36 --> Language Class Initialized
INFO - 2018-04-26 14:20:36 --> Language Class Initialized
INFO - 2018-04-26 14:20:36 --> Config Class Initialized
INFO - 2018-04-26 14:20:36 --> Loader Class Initialized
INFO - 2018-04-26 19:50:36 --> Helper loaded: url_helper
INFO - 2018-04-26 19:50:36 --> Helper loaded: notification_helper
INFO - 2018-04-26 19:50:36 --> Helper loaded: settings_helper
INFO - 2018-04-26 19:50:36 --> Helper loaded: permission_helper
INFO - 2018-04-26 19:50:36 --> Helper loaded: users_helper
INFO - 2018-04-26 19:50:36 --> Database Driver Class Initialized
DEBUG - 2018-04-26 19:50:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-26 19:50:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-26 19:50:36 --> Helper loaded: form_helper
INFO - 2018-04-26 19:50:36 --> Form Validation Class Initialized
INFO - 2018-04-26 19:50:36 --> Controller Class Initialized
INFO - 2018-04-26 19:50:36 --> Model Class Initialized
INFO - 2018-04-26 19:50:36 --> Helper loaded: inflector_helper
INFO - 2018-04-26 19:50:36 --> Model Class Initialized
INFO - 2018-04-26 19:50:36 --> Model Class Initialized
INFO - 2018-04-26 14:20:36 --> Config Class Initialized
INFO - 2018-04-26 14:20:36 --> Hooks Class Initialized
DEBUG - 2018-04-26 14:20:36 --> UTF-8 Support Enabled
INFO - 2018-04-26 14:20:36 --> Utf8 Class Initialized
INFO - 2018-04-26 14:20:36 --> URI Class Initialized
INFO - 2018-04-26 14:20:36 --> Router Class Initialized
INFO - 2018-04-26 14:20:36 --> Output Class Initialized
INFO - 2018-04-26 14:20:36 --> Security Class Initialized
DEBUG - 2018-04-26 14:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-26 14:20:36 --> Input Class Initialized
INFO - 2018-04-26 14:20:36 --> Language Class Initialized
INFO - 2018-04-26 14:20:36 --> Language Class Initialized
INFO - 2018-04-26 14:20:36 --> Config Class Initialized
INFO - 2018-04-26 14:20:36 --> Loader Class Initialized
INFO - 2018-04-26 19:50:36 --> Helper loaded: url_helper
INFO - 2018-04-26 19:50:36 --> Helper loaded: notification_helper
INFO - 2018-04-26 19:50:36 --> Helper loaded: settings_helper
INFO - 2018-04-26 19:50:36 --> Helper loaded: permission_helper
INFO - 2018-04-26 19:50:36 --> Helper loaded: users_helper
INFO - 2018-04-26 19:50:36 --> Database Driver Class Initialized
DEBUG - 2018-04-26 19:50:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-26 19:50:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-26 19:50:36 --> Helper loaded: form_helper
INFO - 2018-04-26 19:50:36 --> Form Validation Class Initialized
INFO - 2018-04-26 19:50:36 --> Controller Class Initialized
INFO - 2018-04-26 19:50:36 --> Model Class Initialized
INFO - 2018-04-26 19:50:36 --> Helper loaded: inflector_helper
INFO - 2018-04-26 19:50:36 --> Model Class Initialized
INFO - 2018-04-26 19:50:36 --> Model Class Initialized
DEBUG - 2018-04-26 19:50:36 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-04-26 19:50:36 --> File loaded: /home/pr01004/public_html/application/views/credits/index.php
DEBUG - 2018-04-26 19:50:36 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-04-26 19:50:36 --> Final output sent to browser
DEBUG - 2018-04-26 19:50:36 --> Total execution time: 0.0995
INFO - 2018-04-26 14:20:38 --> Config Class Initialized
INFO - 2018-04-26 14:20:38 --> Hooks Class Initialized
DEBUG - 2018-04-26 14:20:38 --> UTF-8 Support Enabled
INFO - 2018-04-26 14:20:38 --> Utf8 Class Initialized
INFO - 2018-04-26 14:20:38 --> URI Class Initialized
INFO - 2018-04-26 14:20:38 --> Router Class Initialized
INFO - 2018-04-26 14:20:38 --> Output Class Initialized
INFO - 2018-04-26 14:20:38 --> Security Class Initialized
DEBUG - 2018-04-26 14:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-26 14:20:38 --> Input Class Initialized
INFO - 2018-04-26 14:20:38 --> Language Class Initialized
INFO - 2018-04-26 14:20:38 --> Language Class Initialized
INFO - 2018-04-26 14:20:38 --> Config Class Initialized
INFO - 2018-04-26 14:20:38 --> Loader Class Initialized
INFO - 2018-04-26 19:50:38 --> Helper loaded: url_helper
INFO - 2018-04-26 19:50:38 --> Helper loaded: notification_helper
INFO - 2018-04-26 19:50:38 --> Helper loaded: settings_helper
INFO - 2018-04-26 19:50:38 --> Helper loaded: permission_helper
INFO - 2018-04-26 19:50:38 --> Helper loaded: users_helper
INFO - 2018-04-26 19:50:38 --> Database Driver Class Initialized
DEBUG - 2018-04-26 19:50:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-26 19:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-26 19:50:38 --> Helper loaded: form_helper
INFO - 2018-04-26 19:50:38 --> Form Validation Class Initialized
INFO - 2018-04-26 19:50:38 --> Controller Class Initialized
INFO - 2018-04-26 19:50:38 --> Model Class Initialized
INFO - 2018-04-26 19:50:38 --> Helper loaded: inflector_helper
INFO - 2018-04-26 19:50:38 --> Model Class Initialized
INFO - 2018-04-26 19:50:38 --> Model Class Initialized
DEBUG - 2018-04-26 19:50:38 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-04-26 19:50:38 --> File loaded: /home/pr01004/public_html/application/views/credits/edit.php
DEBUG - 2018-04-26 19:50:38 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-04-26 19:50:38 --> Final output sent to browser
DEBUG - 2018-04-26 19:50:38 --> Total execution time: 0.1550
INFO - 2018-04-26 14:20:40 --> Config Class Initialized
INFO - 2018-04-26 14:20:40 --> Hooks Class Initialized
DEBUG - 2018-04-26 14:20:40 --> UTF-8 Support Enabled
INFO - 2018-04-26 14:20:40 --> Utf8 Class Initialized
INFO - 2018-04-26 14:20:40 --> URI Class Initialized
INFO - 2018-04-26 14:20:40 --> Router Class Initialized
INFO - 2018-04-26 14:20:40 --> Output Class Initialized
INFO - 2018-04-26 14:20:40 --> Security Class Initialized
DEBUG - 2018-04-26 14:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-26 14:20:40 --> Input Class Initialized
INFO - 2018-04-26 14:20:40 --> Language Class Initialized
INFO - 2018-04-26 14:20:40 --> Language Class Initialized
INFO - 2018-04-26 14:20:40 --> Config Class Initialized
INFO - 2018-04-26 14:20:40 --> Loader Class Initialized
INFO - 2018-04-26 19:50:40 --> Helper loaded: url_helper
INFO - 2018-04-26 19:50:40 --> Helper loaded: notification_helper
INFO - 2018-04-26 19:50:40 --> Helper loaded: settings_helper
INFO - 2018-04-26 19:50:40 --> Helper loaded: permission_helper
INFO - 2018-04-26 19:50:40 --> Helper loaded: users_helper
INFO - 2018-04-26 19:50:40 --> Database Driver Class Initialized
DEBUG - 2018-04-26 19:50:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-26 19:50:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-26 19:50:40 --> Helper loaded: form_helper
INFO - 2018-04-26 19:50:40 --> Form Validation Class Initialized
INFO - 2018-04-26 19:50:40 --> Controller Class Initialized
INFO - 2018-04-26 19:50:40 --> Model Class Initialized
INFO - 2018-04-26 19:50:40 --> Helper loaded: inflector_helper
INFO - 2018-04-26 19:50:40 --> Model Class Initialized
INFO - 2018-04-26 19:50:40 --> Model Class Initialized
DEBUG - 2018-04-26 19:50:40 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-04-26 19:50:40 --> File loaded: /home/pr01004/public_html/application/views/credits/index.php
DEBUG - 2018-04-26 19:50:40 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-04-26 19:50:40 --> Final output sent to browser
DEBUG - 2018-04-26 19:50:40 --> Total execution time: 0.0968
INFO - 2018-04-26 14:20:47 --> Config Class Initialized
INFO - 2018-04-26 14:20:47 --> Hooks Class Initialized
DEBUG - 2018-04-26 14:20:47 --> UTF-8 Support Enabled
INFO - 2018-04-26 14:20:47 --> Utf8 Class Initialized
INFO - 2018-04-26 14:20:47 --> URI Class Initialized
INFO - 2018-04-26 14:20:47 --> Router Class Initialized
INFO - 2018-04-26 14:20:47 --> Output Class Initialized
INFO - 2018-04-26 14:20:47 --> Security Class Initialized
DEBUG - 2018-04-26 14:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-26 14:20:47 --> Input Class Initialized
INFO - 2018-04-26 14:20:47 --> Language Class Initialized
INFO - 2018-04-26 14:20:47 --> Language Class Initialized
INFO - 2018-04-26 14:20:47 --> Config Class Initialized
INFO - 2018-04-26 14:20:47 --> Loader Class Initialized
INFO - 2018-04-26 19:50:47 --> Helper loaded: url_helper
INFO - 2018-04-26 19:50:47 --> Helper loaded: notification_helper
INFO - 2018-04-26 19:50:47 --> Helper loaded: settings_helper
INFO - 2018-04-26 19:50:47 --> Helper loaded: permission_helper
INFO - 2018-04-26 19:50:47 --> Helper loaded: users_helper
INFO - 2018-04-26 19:50:47 --> Database Driver Class Initialized
DEBUG - 2018-04-26 19:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-26 19:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-26 19:50:47 --> Helper loaded: form_helper
INFO - 2018-04-26 19:50:47 --> Form Validation Class Initialized
INFO - 2018-04-26 19:50:47 --> Controller Class Initialized
INFO - 2018-04-26 19:50:47 --> Model Class Initialized
INFO - 2018-04-26 19:50:47 --> Helper loaded: inflector_helper
INFO - 2018-04-26 19:50:47 --> Model Class Initialized
INFO - 2018-04-26 19:50:47 --> Model Class Initialized
DEBUG - 2018-04-26 19:50:47 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-04-26 19:50:47 --> File loaded: /home/pr01004/public_html/application/views/credits/create.php
DEBUG - 2018-04-26 19:50:47 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-04-26 19:50:47 --> Final output sent to browser
DEBUG - 2018-04-26 19:50:47 --> Total execution time: 0.0840
