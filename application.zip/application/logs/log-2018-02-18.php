<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-02-18 11:59:28 --> Config Class Initialized
INFO - 2018-02-18 11:59:28 --> Hooks Class Initialized
INFO - 2018-02-18 11:59:28 --> Config Class Initialized
INFO - 2018-02-18 11:59:28 --> Hooks Class Initialized
INFO - 2018-02-18 11:59:28 --> Config Class Initialized
INFO - 2018-02-18 11:59:28 --> Hooks Class Initialized
INFO - 2018-02-18 11:59:28 --> Config Class Initialized
INFO - 2018-02-18 11:59:28 --> Hooks Class Initialized
INFO - 2018-02-18 11:59:28 --> Config Class Initialized
INFO - 2018-02-18 11:59:28 --> Hooks Class Initialized
DEBUG - 2018-02-18 11:59:28 --> UTF-8 Support Enabled
INFO - 2018-02-18 11:59:28 --> Utf8 Class Initialized
DEBUG - 2018-02-18 11:59:28 --> UTF-8 Support Enabled
INFO - 2018-02-18 11:59:28 --> Utf8 Class Initialized
DEBUG - 2018-02-18 11:59:28 --> UTF-8 Support Enabled
DEBUG - 2018-02-18 11:59:28 --> UTF-8 Support Enabled
DEBUG - 2018-02-18 11:59:28 --> UTF-8 Support Enabled
INFO - 2018-02-18 11:59:28 --> Utf8 Class Initialized
INFO - 2018-02-18 11:59:28 --> Utf8 Class Initialized
INFO - 2018-02-18 11:59:28 --> Utf8 Class Initialized
INFO - 2018-02-18 11:59:28 --> URI Class Initialized
INFO - 2018-02-18 11:59:28 --> URI Class Initialized
INFO - 2018-02-18 11:59:28 --> URI Class Initialized
INFO - 2018-02-18 11:59:28 --> URI Class Initialized
INFO - 2018-02-18 11:59:28 --> URI Class Initialized
INFO - 2018-02-18 11:59:28 --> Router Class Initialized
INFO - 2018-02-18 11:59:28 --> Router Class Initialized
INFO - 2018-02-18 11:59:28 --> Output Class Initialized
INFO - 2018-02-18 11:59:28 --> Router Class Initialized
INFO - 2018-02-18 11:59:28 --> Router Class Initialized
INFO - 2018-02-18 11:59:28 --> Router Class Initialized
INFO - 2018-02-18 11:59:28 --> Output Class Initialized
INFO - 2018-02-18 11:59:28 --> Security Class Initialized
INFO - 2018-02-18 11:59:28 --> Output Class Initialized
DEBUG - 2018-02-18 11:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 11:59:28 --> Input Class Initialized
INFO - 2018-02-18 11:59:28 --> Security Class Initialized
INFO - 2018-02-18 11:59:28 --> Output Class Initialized
INFO - 2018-02-18 11:59:28 --> Output Class Initialized
INFO - 2018-02-18 11:59:28 --> Language Class Initialized
INFO - 2018-02-18 11:59:28 --> Security Class Initialized
INFO - 2018-02-18 11:59:28 --> Security Class Initialized
INFO - 2018-02-18 11:59:28 --> Security Class Initialized
DEBUG - 2018-02-18 11:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 11:59:28 --> Input Class Initialized
INFO - 2018-02-18 11:59:28 --> Language Class Initialized
DEBUG - 2018-02-18 11:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 11:59:28 --> Input Class Initialized
DEBUG - 2018-02-18 11:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 11:59:28 --> Input Class Initialized
DEBUG - 2018-02-18 11:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 11:59:28 --> Input Class Initialized
INFO - 2018-02-18 11:59:28 --> Language Class Initialized
INFO - 2018-02-18 11:59:28 --> Language Class Initialized
INFO - 2018-02-18 11:59:28 --> Language Class Initialized
INFO - 2018-02-18 11:59:28 --> Language Class Initialized
INFO - 2018-02-18 11:59:28 --> Config Class Initialized
INFO - 2018-02-18 11:59:28 --> Loader Class Initialized
INFO - 2018-02-18 11:59:28 --> Language Class Initialized
INFO - 2018-02-18 11:59:28 --> Config Class Initialized
INFO - 2018-02-18 11:59:28 --> Loader Class Initialized
INFO - 2018-02-18 11:59:28 --> Language Class Initialized
INFO - 2018-02-18 11:59:28 --> Config Class Initialized
INFO - 2018-02-18 11:59:28 --> Loader Class Initialized
INFO - 2018-02-18 11:59:28 --> Language Class Initialized
INFO - 2018-02-18 11:59:28 --> Config Class Initialized
INFO - 2018-02-18 11:59:28 --> Loader Class Initialized
INFO - 2018-02-18 17:29:28 --> Helper loaded: url_helper
INFO - 2018-02-18 17:29:28 --> Helper loaded: url_helper
INFO - 2018-02-18 17:29:28 --> Helper loaded: url_helper
INFO - 2018-02-18 17:29:28 --> Helper loaded: url_helper
INFO - 2018-02-18 11:59:28 --> Language Class Initialized
INFO - 2018-02-18 11:59:28 --> Config Class Initialized
INFO - 2018-02-18 11:59:28 --> Loader Class Initialized
INFO - 2018-02-18 17:29:28 --> Helper loaded: notification_helper
INFO - 2018-02-18 17:29:28 --> Helper loaded: notification_helper
INFO - 2018-02-18 17:29:28 --> Helper loaded: notification_helper
INFO - 2018-02-18 17:29:28 --> Helper loaded: settings_helper
INFO - 2018-02-18 17:29:28 --> Helper loaded: settings_helper
INFO - 2018-02-18 17:29:28 --> Helper loaded: permission_helper
INFO - 2018-02-18 17:29:28 --> Helper loaded: permission_helper
INFO - 2018-02-18 17:29:28 --> Helper loaded: settings_helper
INFO - 2018-02-18 17:29:28 --> Helper loaded: permission_helper
INFO - 2018-02-18 17:29:28 --> Helper loaded: notification_helper
INFO - 2018-02-18 17:29:28 --> Helper loaded: settings_helper
INFO - 2018-02-18 17:29:28 --> Helper loaded: url_helper
INFO - 2018-02-18 17:29:28 --> Helper loaded: permission_helper
INFO - 2018-02-18 17:29:28 --> Helper loaded: notification_helper
INFO - 2018-02-18 17:29:28 --> Helper loaded: users_helper
INFO - 2018-02-18 17:29:28 --> Helper loaded: users_helper
INFO - 2018-02-18 17:29:29 --> Helper loaded: users_helper
INFO - 2018-02-18 17:29:29 --> Helper loaded: settings_helper
INFO - 2018-02-18 17:29:29 --> Helper loaded: users_helper
INFO - 2018-02-18 17:29:29 --> Helper loaded: permission_helper
INFO - 2018-02-18 17:29:29 --> Helper loaded: users_helper
INFO - 2018-02-18 17:29:29 --> Database Driver Class Initialized
INFO - 2018-02-18 17:29:29 --> Database Driver Class Initialized
INFO - 2018-02-18 17:29:29 --> Database Driver Class Initialized
INFO - 2018-02-18 17:29:29 --> Database Driver Class Initialized
INFO - 2018-02-18 17:29:29 --> Database Driver Class Initialized
DEBUG - 2018-02-18 17:29:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 17:29:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-18 17:29:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 17:29:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-18 17:29:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 17:29:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-18 17:29:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 17:29:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-18 17:29:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 17:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 17:29:29 --> Helper loaded: form_helper
INFO - 2018-02-18 17:29:29 --> Form Validation Class Initialized
INFO - 2018-02-18 17:29:29 --> Controller Class Initialized
INFO - 2018-02-18 17:29:29 --> Helper loaded: form_helper
INFO - 2018-02-18 17:29:29 --> Form Validation Class Initialized
INFO - 2018-02-18 17:29:29 --> Controller Class Initialized
INFO - 2018-02-18 17:29:29 --> Helper loaded: form_helper
INFO - 2018-02-18 17:29:29 --> Form Validation Class Initialized
INFO - 2018-02-18 17:29:29 --> Controller Class Initialized
INFO - 2018-02-18 17:29:29 --> Helper loaded: form_helper
INFO - 2018-02-18 17:29:29 --> Form Validation Class Initialized
INFO - 2018-02-18 17:29:29 --> Controller Class Initialized
INFO - 2018-02-18 17:29:29 --> Helper loaded: form_helper
INFO - 2018-02-18 17:29:29 --> Form Validation Class Initialized
INFO - 2018-02-18 17:29:29 --> Controller Class Initialized
INFO - 2018-02-18 17:29:29 --> Model Class Initialized
INFO - 2018-02-18 17:29:29 --> Model Class Initialized
INFO - 2018-02-18 17:29:29 --> Model Class Initialized
INFO - 2018-02-18 17:29:29 --> Model Class Initialized
INFO - 2018-02-18 17:29:29 --> Model Class Initialized
INFO - 2018-02-18 17:29:29 --> Helper loaded: inflector_helper
INFO - 2018-02-18 17:29:29 --> Helper loaded: inflector_helper
INFO - 2018-02-18 17:29:29 --> Helper loaded: inflector_helper
INFO - 2018-02-18 17:29:29 --> Helper loaded: inflector_helper
INFO - 2018-02-18 17:29:29 --> Helper loaded: inflector_helper
DEBUG - 2018-02-18 17:29:29 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-02-18 17:29:29 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-02-18 17:29:29 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-02-18 17:29:29 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-02-18 17:29:29 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-18 17:29:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-18 17:29:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-18 17:29:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-18 17:29:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-18 17:29:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-18 17:29:29 --> Model Class Initialized
INFO - 2018-02-18 17:29:29 --> Model Class Initialized
INFO - 2018-02-18 17:29:29 --> Model Class Initialized
INFO - 2018-02-18 17:29:29 --> Model Class Initialized
INFO - 2018-02-18 17:29:29 --> Model Class Initialized
INFO - 2018-02-18 17:29:29 --> Model Class Initialized
INFO - 2018-02-18 17:29:29 --> Model Class Initialized
INFO - 2018-02-18 17:29:29 --> Model Class Initialized
INFO - 2018-02-18 17:29:29 --> Model Class Initialized
INFO - 2018-02-18 17:29:29 --> Model Class Initialized
INFO - 2018-02-18 17:29:29 --> Model Class Initialized
INFO - 2018-02-18 17:29:29 --> Model Class Initialized
INFO - 2018-02-18 17:29:29 --> Model Class Initialized
INFO - 2018-02-18 17:29:29 --> Model Class Initialized
INFO - 2018-02-18 17:29:29 --> Model Class Initialized
INFO - 2018-02-18 17:29:29 --> Model Class Initialized
INFO - 2018-02-18 17:29:29 --> Model Class Initialized
INFO - 2018-02-18 17:29:29 --> Model Class Initialized
INFO - 2018-02-18 17:29:29 --> Model Class Initialized
INFO - 2018-02-18 17:29:29 --> Model Class Initialized
INFO - 2018-02-18 17:29:29 --> Model Class Initialized
INFO - 2018-02-18 17:29:29 --> Model Class Initialized
INFO - 2018-02-18 17:29:29 --> Model Class Initialized
INFO - 2018-02-18 17:29:29 --> Model Class Initialized
INFO - 2018-02-18 17:29:29 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-18 17:29:29 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-18 17:29:29 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-18 17:29:29 --> Model Class Initialized
INFO - 2018-02-18 17:29:29 --> Model Class Initialized
INFO - 2018-02-18 17:29:29 --> Model Class Initialized
INFO - 2018-02-18 17:29:29 --> Model Class Initialized
INFO - 2018-02-18 17:29:29 --> Model Class Initialized
INFO - 2018-02-18 17:29:29 --> Model Class Initialized
INFO - 2018-02-18 17:29:29 --> Model Class Initialized
INFO - 2018-02-18 17:29:29 --> Model Class Initialized
INFO - 2018-02-18 17:29:29 --> Model Class Initialized
INFO - 2018-02-18 17:29:29 --> Model Class Initialized
INFO - 2018-02-18 17:29:29 --> Model Class Initialized
INFO - 2018-02-18 17:29:29 --> Model Class Initialized
INFO - 2018-02-18 17:29:29 --> Model Class Initialized
INFO - 2018-02-18 17:29:29 --> Model Class Initialized
INFO - 2018-02-18 17:29:29 --> Final output sent to browser
DEBUG - 2018-02-18 17:29:29 --> Total execution time: 0.3788
INFO - 2018-02-18 17:29:29 --> Model Class Initialized
INFO - 2018-02-18 17:29:29 --> Model Class Initialized
INFO - 2018-02-18 17:29:29 --> Final output sent to browser
DEBUG - 2018-02-18 17:29:29 --> Total execution time: 0.3891
INFO - 2018-02-18 17:29:29 --> Final output sent to browser
DEBUG - 2018-02-18 17:29:29 --> Total execution time: 0.3892
INFO - 2018-02-18 17:29:29 --> Model Class Initialized
INFO - 2018-02-18 17:29:29 --> Model Class Initialized
INFO - 2018-02-18 17:29:29 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-18 17:29:29 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-18 17:29:29 --> Model Class Initialized
INFO - 2018-02-18 17:29:29 --> Model Class Initialized
INFO - 2018-02-18 17:29:29 --> Final output sent to browser
DEBUG - 2018-02-18 17:29:29 --> Total execution time: 0.4229
INFO - 2018-02-18 17:29:29 --> Final output sent to browser
DEBUG - 2018-02-18 17:29:29 --> Total execution time: 0.4244
