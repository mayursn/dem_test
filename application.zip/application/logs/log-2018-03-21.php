<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-03-21 05:33:46 --> Config Class Initialized
INFO - 2018-03-21 05:33:46 --> Hooks Class Initialized
DEBUG - 2018-03-21 05:33:46 --> UTF-8 Support Enabled
INFO - 2018-03-21 05:33:46 --> Utf8 Class Initialized
INFO - 2018-03-21 05:33:46 --> URI Class Initialized
INFO - 2018-03-21 05:33:46 --> Router Class Initialized
INFO - 2018-03-21 05:33:46 --> Output Class Initialized
INFO - 2018-03-21 05:33:46 --> Security Class Initialized
INFO - 2018-03-21 05:33:46 --> Config Class Initialized
INFO - 2018-03-21 05:33:46 --> Hooks Class Initialized
DEBUG - 2018-03-21 05:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 05:33:46 --> Input Class Initialized
INFO - 2018-03-21 05:33:46 --> Language Class Initialized
DEBUG - 2018-03-21 05:33:46 --> UTF-8 Support Enabled
INFO - 2018-03-21 05:33:46 --> Utf8 Class Initialized
INFO - 2018-03-21 05:33:46 --> URI Class Initialized
INFO - 2018-03-21 05:33:46 --> Router Class Initialized
INFO - 2018-03-21 05:33:46 --> Output Class Initialized
INFO - 2018-03-21 05:33:46 --> Security Class Initialized
DEBUG - 2018-03-21 05:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 05:33:46 --> Input Class Initialized
INFO - 2018-03-21 05:33:46 --> Language Class Initialized
INFO - 2018-03-21 05:33:46 --> Language Class Initialized
INFO - 2018-03-21 05:33:46 --> Config Class Initialized
INFO - 2018-03-21 05:33:46 --> Loader Class Initialized
INFO - 2018-03-21 11:03:46 --> Helper loaded: url_helper
INFO - 2018-03-21 11:03:46 --> Helper loaded: notification_helper
INFO - 2018-03-21 11:03:46 --> Helper loaded: settings_helper
INFO - 2018-03-21 11:03:46 --> Helper loaded: permission_helper
INFO - 2018-03-21 11:03:46 --> Helper loaded: users_helper
INFO - 2018-03-21 05:33:46 --> Language Class Initialized
INFO - 2018-03-21 05:33:46 --> Config Class Initialized
INFO - 2018-03-21 05:33:46 --> Loader Class Initialized
INFO - 2018-03-21 11:03:46 --> Database Driver Class Initialized
INFO - 2018-03-21 11:03:46 --> Helper loaded: url_helper
INFO - 2018-03-21 11:03:46 --> Helper loaded: notification_helper
INFO - 2018-03-21 11:03:46 --> Helper loaded: settings_helper
INFO - 2018-03-21 11:03:46 --> Helper loaded: permission_helper
INFO - 2018-03-21 11:03:46 --> Helper loaded: users_helper
DEBUG - 2018-03-21 11:03:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 11:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 11:03:46 --> Helper loaded: form_helper
INFO - 2018-03-21 11:03:46 --> Form Validation Class Initialized
INFO - 2018-03-21 11:03:46 --> Controller Class Initialized
INFO - 2018-03-21 11:03:46 --> Database Driver Class Initialized
INFO - 2018-03-21 05:33:46 --> Config Class Initialized
INFO - 2018-03-21 05:33:46 --> Hooks Class Initialized
INFO - 2018-03-21 11:03:46 --> Model Class Initialized
DEBUG - 2018-03-21 11:03:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 11:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 11:03:46 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 05:33:46 --> UTF-8 Support Enabled
INFO - 2018-03-21 05:33:46 --> Utf8 Class Initialized
INFO - 2018-03-21 05:33:46 --> URI Class Initialized
INFO - 2018-03-21 11:03:46 --> Helper loaded: form_helper
INFO - 2018-03-21 11:03:46 --> Form Validation Class Initialized
INFO - 2018-03-21 11:03:46 --> Controller Class Initialized
INFO - 2018-03-21 05:33:46 --> Router Class Initialized
INFO - 2018-03-21 05:33:46 --> Config Class Initialized
INFO - 2018-03-21 05:33:46 --> Hooks Class Initialized
DEBUG - 2018-03-21 11:03:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 11:03:46 --> Model Class Initialized
INFO - 2018-03-21 11:03:46 --> Helper loaded: inflector_helper
INFO - 2018-03-21 05:33:46 --> Output Class Initialized
INFO - 2018-03-21 11:03:46 --> Language file loaded: language/english/rest_controller_lang.php
DEBUG - 2018-03-21 11:03:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 11:03:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 11:03:46 --> Model Class Initialized
INFO - 2018-03-21 11:03:46 --> Model Class Initialized
INFO - 2018-03-21 11:03:46 --> Model Class Initialized
INFO - 2018-03-21 11:03:46 --> Model Class Initialized
INFO - 2018-03-21 11:03:46 --> Model Class Initialized
INFO - 2018-03-21 11:03:46 --> Model Class Initialized
INFO - 2018-03-21 11:03:46 --> Model Class Initialized
INFO - 2018-03-21 11:03:46 --> Model Class Initialized
DEBUG - 2018-03-21 05:33:46 --> UTF-8 Support Enabled
INFO - 2018-03-21 11:03:46 --> Model Class Initialized
INFO - 2018-03-21 11:03:46 --> Model Class Initialized
INFO - 2018-03-21 05:33:46 --> Utf8 Class Initialized
INFO - 2018-03-21 11:03:46 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-21 11:03:46 --> Model Class Initialized
INFO - 2018-03-21 11:03:46 --> Model Class Initialized
INFO - 2018-03-21 11:03:46 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-21 11:03:46 --> Model Class Initialized
INFO - 2018-03-21 05:33:46 --> Security Class Initialized
INFO - 2018-03-21 11:03:46 --> Final output sent to browser
DEBUG - 2018-03-21 11:03:46 --> Total execution time: 0.2175
INFO - 2018-03-21 05:33:46 --> URI Class Initialized
INFO - 2018-03-21 11:03:46 --> Final output sent to browser
DEBUG - 2018-03-21 11:03:46 --> Total execution time: 0.2567
DEBUG - 2018-03-21 05:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 05:33:46 --> Input Class Initialized
INFO - 2018-03-21 05:33:46 --> Language Class Initialized
INFO - 2018-03-21 05:33:46 --> Router Class Initialized
INFO - 2018-03-21 05:33:46 --> Output Class Initialized
INFO - 2018-03-21 05:33:46 --> Security Class Initialized
DEBUG - 2018-03-21 05:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 05:33:46 --> Input Class Initialized
INFO - 2018-03-21 05:33:46 --> Language Class Initialized
INFO - 2018-03-21 05:33:46 --> Language Class Initialized
INFO - 2018-03-21 05:33:46 --> Config Class Initialized
INFO - 2018-03-21 05:33:46 --> Loader Class Initialized
INFO - 2018-03-21 11:03:46 --> Helper loaded: url_helper
INFO - 2018-03-21 11:03:46 --> Helper loaded: notification_helper
INFO - 2018-03-21 11:03:46 --> Helper loaded: settings_helper
INFO - 2018-03-21 11:03:46 --> Helper loaded: permission_helper
INFO - 2018-03-21 11:03:46 --> Helper loaded: users_helper
INFO - 2018-03-21 05:33:46 --> Language Class Initialized
INFO - 2018-03-21 05:33:46 --> Config Class Initialized
INFO - 2018-03-21 05:33:46 --> Loader Class Initialized
INFO - 2018-03-21 11:03:46 --> Helper loaded: url_helper
INFO - 2018-03-21 11:03:46 --> Helper loaded: notification_helper
INFO - 2018-03-21 11:03:46 --> Helper loaded: settings_helper
INFO - 2018-03-21 11:03:46 --> Helper loaded: permission_helper
INFO - 2018-03-21 11:03:46 --> Helper loaded: users_helper
INFO - 2018-03-21 11:03:46 --> Database Driver Class Initialized
DEBUG - 2018-03-21 11:03:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 11:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 11:03:46 --> Helper loaded: form_helper
INFO - 2018-03-21 11:03:46 --> Form Validation Class Initialized
INFO - 2018-03-21 11:03:46 --> Controller Class Initialized
INFO - 2018-03-21 11:03:46 --> Model Class Initialized
INFO - 2018-03-21 11:03:46 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 11:03:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 11:03:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 11:03:46 --> Model Class Initialized
INFO - 2018-03-21 11:03:46 --> Model Class Initialized
INFO - 2018-03-21 11:03:46 --> Database Driver Class Initialized
DEBUG - 2018-03-21 11:03:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 11:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 11:03:46 --> Model Class Initialized
INFO - 2018-03-21 11:03:46 --> Model Class Initialized
INFO - 2018-03-21 11:03:46 --> Model Class Initialized
INFO - 2018-03-21 11:03:46 --> Model Class Initialized
INFO - 2018-03-21 11:03:46 --> Model Class Initialized
INFO - 2018-03-21 11:03:46 --> Model Class Initialized
INFO - 2018-03-21 11:03:46 --> Model Class Initialized
INFO - 2018-03-21 11:03:46 --> Model Class Initialized
INFO - 2018-03-21 11:03:46 --> Helper loaded: form_helper
INFO - 2018-03-21 11:03:46 --> Form Validation Class Initialized
INFO - 2018-03-21 11:03:46 --> Controller Class Initialized
INFO - 2018-03-21 11:03:46 --> Model Class Initialized
INFO - 2018-03-21 11:03:46 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 11:03:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 11:03:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 11:03:46 --> Model Class Initialized
INFO - 2018-03-21 11:03:46 --> Model Class Initialized
INFO - 2018-03-21 11:03:46 --> Model Class Initialized
INFO - 2018-03-21 11:03:46 --> Model Class Initialized
INFO - 2018-03-21 11:03:46 --> Model Class Initialized
INFO - 2018-03-21 11:03:46 --> Model Class Initialized
INFO - 2018-03-21 11:03:46 --> Model Class Initialized
INFO - 2018-03-21 11:03:46 --> Model Class Initialized
INFO - 2018-03-21 11:03:46 --> Model Class Initialized
INFO - 2018-03-21 11:03:46 --> Model Class Initialized
INFO - 2018-03-21 11:03:46 --> Model Class Initialized
INFO - 2018-03-21 11:03:46 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-21 11:03:46 --> Model Class Initialized
INFO - 2018-03-21 11:03:46 --> Final output sent to browser
DEBUG - 2018-03-21 11:03:46 --> Total execution time: 0.3433
INFO - 2018-03-21 11:03:46 --> Model Class Initialized
INFO - 2018-03-21 11:03:46 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-21 11:03:46 --> Model Class Initialized
INFO - 2018-03-21 11:03:46 --> Final output sent to browser
DEBUG - 2018-03-21 11:03:46 --> Total execution time: 0.4296
INFO - 2018-03-21 05:33:48 --> Config Class Initialized
INFO - 2018-03-21 05:33:48 --> Hooks Class Initialized
DEBUG - 2018-03-21 05:33:48 --> UTF-8 Support Enabled
INFO - 2018-03-21 05:33:48 --> Utf8 Class Initialized
INFO - 2018-03-21 05:33:48 --> URI Class Initialized
INFO - 2018-03-21 05:33:48 --> Router Class Initialized
INFO - 2018-03-21 05:33:48 --> Config Class Initialized
INFO - 2018-03-21 05:33:48 --> Hooks Class Initialized
INFO - 2018-03-21 05:33:48 --> Config Class Initialized
INFO - 2018-03-21 05:33:48 --> Hooks Class Initialized
DEBUG - 2018-03-21 05:33:48 --> UTF-8 Support Enabled
INFO - 2018-03-21 05:33:48 --> Utf8 Class Initialized
DEBUG - 2018-03-21 05:33:48 --> UTF-8 Support Enabled
INFO - 2018-03-21 05:33:48 --> Utf8 Class Initialized
INFO - 2018-03-21 05:33:48 --> URI Class Initialized
INFO - 2018-03-21 05:33:48 --> URI Class Initialized
INFO - 2018-03-21 05:33:48 --> Router Class Initialized
INFO - 2018-03-21 05:33:48 --> Router Class Initialized
INFO - 2018-03-21 05:33:48 --> Output Class Initialized
INFO - 2018-03-21 05:33:48 --> Security Class Initialized
DEBUG - 2018-03-21 05:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 05:33:48 --> Input Class Initialized
INFO - 2018-03-21 05:33:48 --> Language Class Initialized
INFO - 2018-03-21 05:33:48 --> Output Class Initialized
INFO - 2018-03-21 05:33:48 --> Security Class Initialized
DEBUG - 2018-03-21 05:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 05:33:48 --> Input Class Initialized
INFO - 2018-03-21 05:33:48 --> Output Class Initialized
INFO - 2018-03-21 05:33:48 --> Language Class Initialized
INFO - 2018-03-21 05:33:48 --> Security Class Initialized
INFO - 2018-03-21 05:33:49 --> Language Class Initialized
INFO - 2018-03-21 05:33:49 --> Config Class Initialized
INFO - 2018-03-21 05:33:49 --> Loader Class Initialized
INFO - 2018-03-21 11:03:49 --> Helper loaded: url_helper
INFO - 2018-03-21 11:03:49 --> Helper loaded: notification_helper
INFO - 2018-03-21 11:03:49 --> Helper loaded: settings_helper
INFO - 2018-03-21 11:03:49 --> Helper loaded: permission_helper
INFO - 2018-03-21 11:03:49 --> Helper loaded: users_helper
INFO - 2018-03-21 05:33:49 --> Language Class Initialized
INFO - 2018-03-21 05:33:49 --> Config Class Initialized
INFO - 2018-03-21 05:33:49 --> Loader Class Initialized
INFO - 2018-03-21 11:03:49 --> Helper loaded: url_helper
INFO - 2018-03-21 11:03:49 --> Helper loaded: notification_helper
INFO - 2018-03-21 11:03:49 --> Helper loaded: settings_helper
INFO - 2018-03-21 11:03:49 --> Helper loaded: permission_helper
INFO - 2018-03-21 11:03:49 --> Helper loaded: users_helper
INFO - 2018-03-21 11:03:49 --> Database Driver Class Initialized
DEBUG - 2018-03-21 11:03:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 11:03:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 11:03:49 --> Helper loaded: form_helper
INFO - 2018-03-21 11:03:49 --> Form Validation Class Initialized
INFO - 2018-03-21 11:03:49 --> Controller Class Initialized
INFO - 2018-03-21 11:03:49 --> Model Class Initialized
INFO - 2018-03-21 11:03:49 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 11:03:49 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 11:03:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 11:03:49 --> Database Driver Class Initialized
INFO - 2018-03-21 11:03:49 --> Model Class Initialized
INFO - 2018-03-21 11:03:49 --> Model Class Initialized
INFO - 2018-03-21 11:03:49 --> Model Class Initialized
INFO - 2018-03-21 11:03:49 --> Model Class Initialized
INFO - 2018-03-21 11:03:49 --> Model Class Initialized
INFO - 2018-03-21 11:03:49 --> Model Class Initialized
INFO - 2018-03-21 11:03:49 --> Model Class Initialized
INFO - 2018-03-21 11:03:49 --> Model Class Initialized
INFO - 2018-03-21 11:03:49 --> Model Class Initialized
INFO - 2018-03-21 11:03:49 --> Model Class Initialized
INFO - 2018-03-21 11:03:49 --> Model Class Initialized
INFO - 2018-03-21 11:03:49 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-03-21 11:03:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 11:03:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 11:03:49 --> Helper loaded: form_helper
INFO - 2018-03-21 11:03:49 --> Form Validation Class Initialized
INFO - 2018-03-21 11:03:49 --> Controller Class Initialized
DEBUG - 2018-03-21 05:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 05:33:49 --> Input Class Initialized
INFO - 2018-03-21 11:03:49 --> Model Class Initialized
INFO - 2018-03-21 11:03:49 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 11:03:49 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 11:03:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 11:03:49 --> Model Class Initialized
INFO - 2018-03-21 11:03:49 --> Model Class Initialized
INFO - 2018-03-21 05:33:49 --> Language Class Initialized
INFO - 2018-03-21 11:03:49 --> Model Class Initialized
INFO - 2018-03-21 11:03:49 --> Model Class Initialized
INFO - 2018-03-21 11:03:49 --> Model Class Initialized
INFO - 2018-03-21 11:03:49 --> Model Class Initialized
INFO - 2018-03-21 11:03:49 --> Model Class Initialized
INFO - 2018-03-21 11:03:49 --> Model Class Initialized
INFO - 2018-03-21 11:03:49 --> Model Class Initialized
INFO - 2018-03-21 11:03:49 --> Model Class Initialized
INFO - 2018-03-21 11:03:49 --> Final output sent to browser
DEBUG - 2018-03-21 11:03:49 --> Total execution time: 0.3942
INFO - 2018-03-21 11:03:49 --> Model Class Initialized
INFO - 2018-03-21 11:03:49 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-21 11:03:49 --> Model Class Initialized
INFO - 2018-03-21 11:03:49 --> Final output sent to browser
DEBUG - 2018-03-21 11:03:49 --> Total execution time: 0.5289
INFO - 2018-03-21 05:33:49 --> Language Class Initialized
INFO - 2018-03-21 05:33:49 --> Config Class Initialized
INFO - 2018-03-21 05:33:49 --> Loader Class Initialized
INFO - 2018-03-21 11:03:49 --> Helper loaded: url_helper
INFO - 2018-03-21 11:03:49 --> Helper loaded: notification_helper
INFO - 2018-03-21 11:03:49 --> Helper loaded: settings_helper
INFO - 2018-03-21 11:03:49 --> Helper loaded: permission_helper
INFO - 2018-03-21 11:03:49 --> Helper loaded: users_helper
INFO - 2018-03-21 11:03:50 --> Database Driver Class Initialized
INFO - 2018-03-21 05:33:50 --> Config Class Initialized
INFO - 2018-03-21 05:33:50 --> Hooks Class Initialized
DEBUG - 2018-03-21 05:33:50 --> UTF-8 Support Enabled
INFO - 2018-03-21 05:33:50 --> Utf8 Class Initialized
DEBUG - 2018-03-21 11:03:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 11:03:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 05:33:50 --> URI Class Initialized
INFO - 2018-03-21 05:33:50 --> Router Class Initialized
INFO - 2018-03-21 05:33:50 --> Config Class Initialized
INFO - 2018-03-21 05:33:50 --> Hooks Class Initialized
DEBUG - 2018-03-21 05:33:50 --> UTF-8 Support Enabled
INFO - 2018-03-21 05:33:50 --> Utf8 Class Initialized
INFO - 2018-03-21 05:33:50 --> URI Class Initialized
INFO - 2018-03-21 05:33:50 --> Router Class Initialized
INFO - 2018-03-21 05:33:50 --> Output Class Initialized
INFO - 2018-03-21 05:33:50 --> Security Class Initialized
DEBUG - 2018-03-21 05:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 05:33:50 --> Input Class Initialized
INFO - 2018-03-21 05:33:50 --> Language Class Initialized
INFO - 2018-03-21 05:33:50 --> Language Class Initialized
INFO - 2018-03-21 05:33:50 --> Config Class Initialized
INFO - 2018-03-21 05:33:50 --> Loader Class Initialized
INFO - 2018-03-21 11:03:50 --> Helper loaded: url_helper
INFO - 2018-03-21 11:03:50 --> Helper loaded: notification_helper
INFO - 2018-03-21 11:03:50 --> Helper loaded: settings_helper
INFO - 2018-03-21 11:03:50 --> Helper loaded: permission_helper
INFO - 2018-03-21 11:03:50 --> Helper loaded: users_helper
INFO - 2018-03-21 11:03:50 --> Helper loaded: form_helper
INFO - 2018-03-21 11:03:50 --> Database Driver Class Initialized
INFO - 2018-03-21 11:03:50 --> Form Validation Class Initialized
INFO - 2018-03-21 11:03:50 --> Controller Class Initialized
DEBUG - 2018-03-21 11:03:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 11:03:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 11:03:50 --> Helper loaded: form_helper
INFO - 2018-03-21 11:03:50 --> Form Validation Class Initialized
INFO - 2018-03-21 11:03:50 --> Controller Class Initialized
INFO - 2018-03-21 11:03:50 --> Model Class Initialized
INFO - 2018-03-21 11:03:50 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 11:03:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 11:03:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 05:33:50 --> Output Class Initialized
INFO - 2018-03-21 11:03:50 --> Model Class Initialized
INFO - 2018-03-21 11:03:50 --> Model Class Initialized
INFO - 2018-03-21 05:33:50 --> Security Class Initialized
INFO - 2018-03-21 11:03:50 --> Model Class Initialized
INFO - 2018-03-21 11:03:50 --> Model Class Initialized
INFO - 2018-03-21 11:03:50 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-03-21 05:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 05:33:51 --> Input Class Initialized
INFO - 2018-03-21 05:33:51 --> Language Class Initialized
INFO - 2018-03-21 11:03:51 --> Final output sent to browser
DEBUG - 2018-03-21 11:03:51 --> Total execution time: 0.5783
INFO - 2018-03-21 11:03:51 --> Model Class Initialized
INFO - 2018-03-21 11:03:51 --> Helper loaded: inflector_helper
INFO - 2018-03-21 05:33:51 --> Config Class Initialized
INFO - 2018-03-21 05:33:51 --> Hooks Class Initialized
DEBUG - 2018-03-21 05:33:51 --> UTF-8 Support Enabled
INFO - 2018-03-21 05:33:51 --> Utf8 Class Initialized
INFO - 2018-03-21 05:33:51 --> URI Class Initialized
DEBUG - 2018-03-21 11:03:51 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 05:33:51 --> Router Class Initialized
INFO - 2018-03-21 11:03:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 11:03:52 --> Model Class Initialized
INFO - 2018-03-21 05:33:52 --> Output Class Initialized
INFO - 2018-03-21 11:03:52 --> Model Class Initialized
INFO - 2018-03-21 11:03:52 --> Model Class Initialized
INFO - 2018-03-21 11:03:52 --> Model Class Initialized
INFO - 2018-03-21 05:33:52 --> Security Class Initialized
INFO - 2018-03-21 11:03:52 --> Model Class Initialized
INFO - 2018-03-21 11:03:52 --> Model Class Initialized
INFO - 2018-03-21 11:03:52 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-03-21 05:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 05:33:52 --> Input Class Initialized
INFO - 2018-03-21 05:33:52 --> Language Class Initialized
INFO - 2018-03-21 11:03:52 --> Model Class Initialized
INFO - 2018-03-21 11:03:52 --> Final output sent to browser
DEBUG - 2018-03-21 11:03:52 --> Total execution time: 4.2195
INFO - 2018-03-21 05:33:52 --> Language Class Initialized
INFO - 2018-03-21 05:33:52 --> Config Class Initialized
INFO - 2018-03-21 05:33:52 --> Loader Class Initialized
INFO - 2018-03-21 05:33:52 --> Config Class Initialized
INFO - 2018-03-21 05:33:52 --> Hooks Class Initialized
INFO - 2018-03-21 11:03:52 --> Helper loaded: url_helper
INFO - 2018-03-21 11:03:52 --> Helper loaded: notification_helper
INFO - 2018-03-21 11:03:52 --> Helper loaded: settings_helper
INFO - 2018-03-21 11:03:52 --> Helper loaded: permission_helper
INFO - 2018-03-21 11:03:52 --> Helper loaded: users_helper
DEBUG - 2018-03-21 05:33:52 --> UTF-8 Support Enabled
INFO - 2018-03-21 05:33:52 --> Utf8 Class Initialized
INFO - 2018-03-21 05:33:52 --> URI Class Initialized
INFO - 2018-03-21 05:33:53 --> Router Class Initialized
INFO - 2018-03-21 05:33:53 --> Config Class Initialized
INFO - 2018-03-21 05:33:53 --> Hooks Class Initialized
INFO - 2018-03-21 05:33:53 --> Output Class Initialized
DEBUG - 2018-03-21 05:33:53 --> UTF-8 Support Enabled
INFO - 2018-03-21 05:33:53 --> Utf8 Class Initialized
INFO - 2018-03-21 05:33:53 --> Language Class Initialized
INFO - 2018-03-21 05:33:53 --> Config Class Initialized
INFO - 2018-03-21 05:33:53 --> Loader Class Initialized
INFO - 2018-03-21 05:33:53 --> Security Class Initialized
INFO - 2018-03-21 05:33:53 --> URI Class Initialized
DEBUG - 2018-03-21 05:33:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 05:33:53 --> Input Class Initialized
INFO - 2018-03-21 05:33:53 --> Language Class Initialized
INFO - 2018-03-21 11:03:53 --> Database Driver Class Initialized
INFO - 2018-03-21 11:03:53 --> Helper loaded: url_helper
INFO - 2018-03-21 11:03:53 --> Helper loaded: notification_helper
INFO - 2018-03-21 11:03:53 --> Helper loaded: settings_helper
INFO - 2018-03-21 11:03:53 --> Helper loaded: permission_helper
INFO - 2018-03-21 05:33:53 --> Router Class Initialized
INFO - 2018-03-21 11:03:53 --> Helper loaded: users_helper
DEBUG - 2018-03-21 11:03:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 11:03:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 05:33:53 --> Output Class Initialized
INFO - 2018-03-21 05:33:53 --> Config Class Initialized
INFO - 2018-03-21 05:33:53 --> Hooks Class Initialized
DEBUG - 2018-03-21 05:33:53 --> UTF-8 Support Enabled
INFO - 2018-03-21 05:33:53 --> Utf8 Class Initialized
INFO - 2018-03-21 05:33:53 --> URI Class Initialized
INFO - 2018-03-21 05:33:53 --> Router Class Initialized
INFO - 2018-03-21 05:33:53 --> Output Class Initialized
INFO - 2018-03-21 05:33:53 --> Security Class Initialized
DEBUG - 2018-03-21 05:33:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 05:33:53 --> Input Class Initialized
INFO - 2018-03-21 05:33:53 --> Language Class Initialized
INFO - 2018-03-21 05:33:53 --> Language Class Initialized
INFO - 2018-03-21 05:33:53 --> Config Class Initialized
INFO - 2018-03-21 05:33:53 --> Loader Class Initialized
INFO - 2018-03-21 11:03:53 --> Helper loaded: url_helper
INFO - 2018-03-21 11:03:53 --> Helper loaded: notification_helper
INFO - 2018-03-21 11:03:53 --> Helper loaded: settings_helper
INFO - 2018-03-21 11:03:53 --> Helper loaded: permission_helper
INFO - 2018-03-21 11:03:53 --> Helper loaded: users_helper
INFO - 2018-03-21 05:33:53 --> Security Class Initialized
INFO - 2018-03-21 11:03:53 --> Database Driver Class Initialized
DEBUG - 2018-03-21 11:03:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 11:03:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 11:03:53 --> Helper loaded: form_helper
INFO - 2018-03-21 11:03:53 --> Form Validation Class Initialized
INFO - 2018-03-21 11:03:53 --> Controller Class Initialized
INFO - 2018-03-21 11:03:53 --> Model Class Initialized
INFO - 2018-03-21 11:03:53 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 11:03:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 11:03:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 11:03:53 --> Model Class Initialized
INFO - 2018-03-21 11:03:53 --> Model Class Initialized
INFO - 2018-03-21 11:03:53 --> Model Class Initialized
INFO - 2018-03-21 11:03:53 --> Model Class Initialized
INFO - 2018-03-21 11:03:53 --> Model Class Initialized
INFO - 2018-03-21 11:03:53 --> Model Class Initialized
INFO - 2018-03-21 11:03:53 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-21 11:03:53 --> Final output sent to browser
DEBUG - 2018-03-21 11:03:53 --> Total execution time: 0.1057
DEBUG - 2018-03-21 05:33:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 05:33:53 --> Input Class Initialized
INFO - 2018-03-21 05:33:53 --> Language Class Initialized
INFO - 2018-03-21 11:03:53 --> Helper loaded: form_helper
INFO - 2018-03-21 11:03:53 --> Form Validation Class Initialized
INFO - 2018-03-21 11:03:53 --> Controller Class Initialized
INFO - 2018-03-21 11:03:54 --> Database Driver Class Initialized
INFO - 2018-03-21 05:33:54 --> Language Class Initialized
INFO - 2018-03-21 05:33:54 --> Config Class Initialized
INFO - 2018-03-21 05:33:54 --> Loader Class Initialized
DEBUG - 2018-03-21 11:03:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 11:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 11:03:54 --> Model Class Initialized
INFO - 2018-03-21 11:03:54 --> Helper loaded: form_helper
INFO - 2018-03-21 11:03:54 --> Form Validation Class Initialized
INFO - 2018-03-21 11:03:54 --> Controller Class Initialized
INFO - 2018-03-21 11:03:54 --> Helper loaded: inflector_helper
INFO - 2018-03-21 11:03:54 --> Helper loaded: url_helper
INFO - 2018-03-21 11:03:54 --> Model Class Initialized
INFO - 2018-03-21 11:03:54 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 11:03:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 11:03:54 --> Helper loaded: notification_helper
INFO - 2018-03-21 11:03:54 --> Helper loaded: settings_helper
DEBUG - 2018-03-21 11:03:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 11:03:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 11:03:54 --> Helper loaded: permission_helper
INFO - 2018-03-21 11:03:54 --> Helper loaded: users_helper
INFO - 2018-03-21 11:03:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 11:03:54 --> Model Class Initialized
INFO - 2018-03-21 11:03:54 --> Model Class Initialized
INFO - 2018-03-21 11:03:54 --> Model Class Initialized
INFO - 2018-03-21 11:03:54 --> Model Class Initialized
INFO - 2018-03-21 11:03:54 --> Model Class Initialized
INFO - 2018-03-21 11:03:54 --> Model Class Initialized
INFO - 2018-03-21 11:03:54 --> Model Class Initialized
INFO - 2018-03-21 11:03:54 --> Model Class Initialized
INFO - 2018-03-21 11:03:54 --> Model Class Initialized
INFO - 2018-03-21 11:03:54 --> Model Class Initialized
INFO - 2018-03-21 11:03:54 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-21 11:03:54 --> Model Class Initialized
INFO - 2018-03-21 11:03:54 --> Model Class Initialized
INFO - 2018-03-21 11:03:54 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-21 05:33:54 --> Language Class Initialized
INFO - 2018-03-21 05:33:54 --> Config Class Initialized
INFO - 2018-03-21 05:33:54 --> Loader Class Initialized
INFO - 2018-03-21 11:03:54 --> Database Driver Class Initialized
DEBUG - 2018-03-21 11:03:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 11:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 11:03:54 --> Helper loaded: form_helper
INFO - 2018-03-21 11:03:54 --> Form Validation Class Initialized
INFO - 2018-03-21 11:03:54 --> Controller Class Initialized
INFO - 2018-03-21 11:03:54 --> Model Class Initialized
INFO - 2018-03-21 11:03:54 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 11:03:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 11:03:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 11:03:54 --> Model Class Initialized
INFO - 2018-03-21 11:03:54 --> Model Class Initialized
INFO - 2018-03-21 11:03:54 --> Model Class Initialized
INFO - 2018-03-21 11:03:54 --> Model Class Initialized
INFO - 2018-03-21 11:03:54 --> Model Class Initialized
INFO - 2018-03-21 11:03:54 --> Model Class Initialized
INFO - 2018-03-21 11:03:54 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-21 11:03:54 --> Final output sent to browser
DEBUG - 2018-03-21 11:03:54 --> Total execution time: 2.5907
INFO - 2018-03-21 11:03:54 --> Model Class Initialized
INFO - 2018-03-21 11:03:54 --> Final output sent to browser
DEBUG - 2018-03-21 11:03:54 --> Total execution time: 5.0089
INFO - 2018-03-21 11:03:54 --> Final output sent to browser
DEBUG - 2018-03-21 11:03:54 --> Total execution time: 3.4743
INFO - 2018-03-21 11:03:54 --> Helper loaded: url_helper
INFO - 2018-03-21 11:03:54 --> Helper loaded: notification_helper
INFO - 2018-03-21 11:03:54 --> Helper loaded: settings_helper
INFO - 2018-03-21 11:03:54 --> Helper loaded: permission_helper
INFO - 2018-03-21 11:03:55 --> Helper loaded: users_helper
INFO - 2018-03-21 11:03:55 --> Database Driver Class Initialized
DEBUG - 2018-03-21 11:03:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 11:03:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 11:03:55 --> Helper loaded: form_helper
INFO - 2018-03-21 11:03:55 --> Form Validation Class Initialized
INFO - 2018-03-21 11:03:55 --> Controller Class Initialized
INFO - 2018-03-21 11:03:55 --> Model Class Initialized
INFO - 2018-03-21 11:03:55 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 11:03:55 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 11:03:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 11:03:56 --> Model Class Initialized
INFO - 2018-03-21 11:03:56 --> Model Class Initialized
INFO - 2018-03-21 11:03:56 --> Model Class Initialized
INFO - 2018-03-21 11:03:56 --> Model Class Initialized
INFO - 2018-03-21 11:03:56 --> Model Class Initialized
INFO - 2018-03-21 11:03:56 --> Model Class Initialized
INFO - 2018-03-21 11:03:56 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-21 11:03:56 --> Final output sent to browser
DEBUG - 2018-03-21 11:03:56 --> Total execution time: 2.8803
INFO - 2018-03-21 05:34:00 --> Config Class Initialized
INFO - 2018-03-21 05:34:00 --> Hooks Class Initialized
DEBUG - 2018-03-21 05:34:00 --> UTF-8 Support Enabled
INFO - 2018-03-21 05:34:00 --> Utf8 Class Initialized
INFO - 2018-03-21 05:34:00 --> URI Class Initialized
INFO - 2018-03-21 05:34:00 --> Router Class Initialized
INFO - 2018-03-21 05:34:00 --> Output Class Initialized
INFO - 2018-03-21 05:34:00 --> Security Class Initialized
DEBUG - 2018-03-21 05:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 05:34:00 --> Input Class Initialized
INFO - 2018-03-21 05:34:00 --> Language Class Initialized
INFO - 2018-03-21 05:34:00 --> Language Class Initialized
INFO - 2018-03-21 05:34:00 --> Config Class Initialized
INFO - 2018-03-21 05:34:00 --> Loader Class Initialized
INFO - 2018-03-21 11:04:00 --> Helper loaded: url_helper
INFO - 2018-03-21 11:04:00 --> Helper loaded: notification_helper
INFO - 2018-03-21 11:04:00 --> Helper loaded: settings_helper
INFO - 2018-03-21 11:04:00 --> Helper loaded: permission_helper
INFO - 2018-03-21 11:04:00 --> Helper loaded: users_helper
INFO - 2018-03-21 11:04:00 --> Database Driver Class Initialized
DEBUG - 2018-03-21 11:04:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 11:04:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 11:04:00 --> Helper loaded: form_helper
INFO - 2018-03-21 11:04:00 --> Form Validation Class Initialized
INFO - 2018-03-21 11:04:00 --> Controller Class Initialized
INFO - 2018-03-21 11:04:00 --> Model Class Initialized
INFO - 2018-03-21 11:04:00 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 11:04:00 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 11:04:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 11:04:00 --> Model Class Initialized
INFO - 2018-03-21 11:04:00 --> Model Class Initialized
INFO - 2018-03-21 11:04:00 --> Model Class Initialized
INFO - 2018-03-21 11:04:00 --> Model Class Initialized
INFO - 2018-03-21 11:04:00 --> Model Class Initialized
INFO - 2018-03-21 11:04:00 --> Model Class Initialized
INFO - 2018-03-21 11:04:00 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-21 11:04:00 --> Final output sent to browser
DEBUG - 2018-03-21 11:04:00 --> Total execution time: 0.1165
INFO - 2018-03-21 05:34:00 --> Config Class Initialized
INFO - 2018-03-21 05:34:00 --> Hooks Class Initialized
DEBUG - 2018-03-21 05:34:00 --> UTF-8 Support Enabled
INFO - 2018-03-21 05:34:00 --> Utf8 Class Initialized
INFO - 2018-03-21 05:34:00 --> URI Class Initialized
INFO - 2018-03-21 05:34:00 --> Router Class Initialized
INFO - 2018-03-21 05:34:00 --> Output Class Initialized
INFO - 2018-03-21 05:34:00 --> Security Class Initialized
DEBUG - 2018-03-21 05:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 05:34:01 --> Input Class Initialized
INFO - 2018-03-21 05:34:01 --> Language Class Initialized
INFO - 2018-03-21 05:34:01 --> Language Class Initialized
INFO - 2018-03-21 05:34:01 --> Config Class Initialized
INFO - 2018-03-21 05:34:01 --> Loader Class Initialized
INFO - 2018-03-21 11:04:01 --> Helper loaded: url_helper
INFO - 2018-03-21 11:04:01 --> Helper loaded: notification_helper
INFO - 2018-03-21 11:04:01 --> Helper loaded: settings_helper
INFO - 2018-03-21 11:04:01 --> Helper loaded: permission_helper
INFO - 2018-03-21 11:04:01 --> Helper loaded: users_helper
INFO - 2018-03-21 11:04:01 --> Database Driver Class Initialized
DEBUG - 2018-03-21 11:04:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 11:04:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 11:04:01 --> Helper loaded: form_helper
INFO - 2018-03-21 11:04:01 --> Form Validation Class Initialized
INFO - 2018-03-21 11:04:01 --> Controller Class Initialized
INFO - 2018-03-21 11:04:01 --> Model Class Initialized
INFO - 2018-03-21 11:04:01 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 11:04:01 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 11:04:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 11:04:01 --> Model Class Initialized
INFO - 2018-03-21 11:04:01 --> Model Class Initialized
INFO - 2018-03-21 11:04:01 --> Model Class Initialized
INFO - 2018-03-21 11:04:01 --> Model Class Initialized
INFO - 2018-03-21 11:04:01 --> Model Class Initialized
INFO - 2018-03-21 11:04:01 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-21 11:04:01 --> Model Class Initialized
INFO - 2018-03-21 11:04:01 --> Final output sent to browser
DEBUG - 2018-03-21 11:04:01 --> Total execution time: 0.8480
INFO - 2018-03-21 05:34:42 --> Config Class Initialized
INFO - 2018-03-21 05:34:42 --> Hooks Class Initialized
DEBUG - 2018-03-21 05:34:42 --> UTF-8 Support Enabled
INFO - 2018-03-21 05:34:42 --> Utf8 Class Initialized
INFO - 2018-03-21 05:34:42 --> URI Class Initialized
INFO - 2018-03-21 05:34:42 --> Router Class Initialized
INFO - 2018-03-21 05:34:42 --> Output Class Initialized
INFO - 2018-03-21 05:34:42 --> Security Class Initialized
DEBUG - 2018-03-21 05:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 05:34:43 --> Input Class Initialized
INFO - 2018-03-21 05:34:43 --> Language Class Initialized
INFO - 2018-03-21 05:34:43 --> Language Class Initialized
INFO - 2018-03-21 05:34:43 --> Config Class Initialized
INFO - 2018-03-21 05:34:43 --> Loader Class Initialized
INFO - 2018-03-21 11:04:44 --> Helper loaded: url_helper
INFO - 2018-03-21 11:04:44 --> Helper loaded: notification_helper
INFO - 2018-03-21 11:04:44 --> Helper loaded: settings_helper
INFO - 2018-03-21 11:04:44 --> Helper loaded: permission_helper
INFO - 2018-03-21 11:04:44 --> Helper loaded: users_helper
INFO - 2018-03-21 11:04:44 --> Database Driver Class Initialized
DEBUG - 2018-03-21 11:04:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 11:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 11:04:44 --> Helper loaded: form_helper
INFO - 2018-03-21 11:04:44 --> Form Validation Class Initialized
INFO - 2018-03-21 11:04:44 --> Controller Class Initialized
INFO - 2018-03-21 11:04:44 --> Model Class Initialized
INFO - 2018-03-21 11:04:44 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 11:04:44 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 11:04:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 11:04:44 --> Model Class Initialized
INFO - 2018-03-21 11:04:44 --> Model Class Initialized
INFO - 2018-03-21 11:04:44 --> Model Class Initialized
INFO - 2018-03-21 11:04:44 --> Model Class Initialized
INFO - 2018-03-21 11:04:44 --> Model Class Initialized
INFO - 2018-03-21 11:04:44 --> Model Class Initialized
INFO - 2018-03-21 11:04:44 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-21 11:04:44 --> Upload Class Initialized
INFO - 2018-03-21 11:04:44 --> Final output sent to browser
DEBUG - 2018-03-21 11:04:44 --> Total execution time: 2.7791
INFO - 2018-03-21 05:34:46 --> Config Class Initialized
INFO - 2018-03-21 05:34:46 --> Hooks Class Initialized
DEBUG - 2018-03-21 05:34:46 --> UTF-8 Support Enabled
INFO - 2018-03-21 05:34:46 --> Utf8 Class Initialized
INFO - 2018-03-21 05:34:46 --> URI Class Initialized
INFO - 2018-03-21 05:34:46 --> Router Class Initialized
INFO - 2018-03-21 05:34:46 --> Output Class Initialized
INFO - 2018-03-21 05:34:46 --> Security Class Initialized
DEBUG - 2018-03-21 05:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 05:34:46 --> Input Class Initialized
INFO - 2018-03-21 05:34:46 --> Language Class Initialized
INFO - 2018-03-21 05:34:46 --> Language Class Initialized
INFO - 2018-03-21 05:34:46 --> Config Class Initialized
INFO - 2018-03-21 05:34:46 --> Loader Class Initialized
INFO - 2018-03-21 11:04:46 --> Helper loaded: url_helper
INFO - 2018-03-21 11:04:46 --> Helper loaded: notification_helper
INFO - 2018-03-21 11:04:46 --> Helper loaded: settings_helper
INFO - 2018-03-21 11:04:46 --> Helper loaded: permission_helper
INFO - 2018-03-21 11:04:46 --> Helper loaded: users_helper
INFO - 2018-03-21 11:04:46 --> Database Driver Class Initialized
DEBUG - 2018-03-21 11:04:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 11:04:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 11:04:46 --> Helper loaded: form_helper
INFO - 2018-03-21 11:04:46 --> Form Validation Class Initialized
INFO - 2018-03-21 11:04:46 --> Controller Class Initialized
INFO - 2018-03-21 11:04:46 --> Model Class Initialized
INFO - 2018-03-21 11:04:46 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 11:04:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 11:04:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 11:04:46 --> Model Class Initialized
INFO - 2018-03-21 11:04:46 --> Model Class Initialized
INFO - 2018-03-21 11:04:46 --> Model Class Initialized
INFO - 2018-03-21 11:04:46 --> Model Class Initialized
INFO - 2018-03-21 11:04:46 --> Model Class Initialized
INFO - 2018-03-21 11:04:46 --> Model Class Initialized
INFO - 2018-03-21 11:04:46 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-21 11:04:46 --> Final output sent to browser
DEBUG - 2018-03-21 11:04:46 --> Total execution time: 0.2117
INFO - 2018-03-21 05:34:48 --> Config Class Initialized
INFO - 2018-03-21 05:34:48 --> Hooks Class Initialized
DEBUG - 2018-03-21 05:34:48 --> UTF-8 Support Enabled
INFO - 2018-03-21 05:34:48 --> Utf8 Class Initialized
INFO - 2018-03-21 05:34:48 --> URI Class Initialized
INFO - 2018-03-21 05:34:48 --> Router Class Initialized
INFO - 2018-03-21 05:34:48 --> Output Class Initialized
INFO - 2018-03-21 05:34:48 --> Security Class Initialized
DEBUG - 2018-03-21 05:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 05:34:48 --> Input Class Initialized
INFO - 2018-03-21 05:34:48 --> Language Class Initialized
INFO - 2018-03-21 05:34:48 --> Language Class Initialized
INFO - 2018-03-21 05:34:48 --> Config Class Initialized
INFO - 2018-03-21 05:34:48 --> Loader Class Initialized
INFO - 2018-03-21 11:04:48 --> Helper loaded: url_helper
INFO - 2018-03-21 11:04:48 --> Helper loaded: notification_helper
INFO - 2018-03-21 11:04:48 --> Helper loaded: settings_helper
INFO - 2018-03-21 11:04:48 --> Helper loaded: permission_helper
INFO - 2018-03-21 11:04:48 --> Helper loaded: users_helper
INFO - 2018-03-21 11:04:48 --> Database Driver Class Initialized
DEBUG - 2018-03-21 11:04:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 11:04:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 11:04:49 --> Helper loaded: form_helper
INFO - 2018-03-21 11:04:49 --> Form Validation Class Initialized
INFO - 2018-03-21 11:04:49 --> Controller Class Initialized
INFO - 2018-03-21 11:04:49 --> Model Class Initialized
INFO - 2018-03-21 11:04:49 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 11:04:49 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 11:04:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 11:04:49 --> Model Class Initialized
INFO - 2018-03-21 11:04:49 --> Model Class Initialized
INFO - 2018-03-21 11:04:49 --> Model Class Initialized
INFO - 2018-03-21 11:04:49 --> Model Class Initialized
INFO - 2018-03-21 11:04:49 --> Model Class Initialized
INFO - 2018-03-21 11:04:49 --> Model Class Initialized
INFO - 2018-03-21 11:04:49 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-21 11:04:49 --> Final output sent to browser
DEBUG - 2018-03-21 11:04:49 --> Total execution time: 0.3276
INFO - 2018-03-21 05:34:49 --> Config Class Initialized
INFO - 2018-03-21 05:34:49 --> Hooks Class Initialized
INFO - 2018-03-21 05:34:49 --> Config Class Initialized
INFO - 2018-03-21 05:34:49 --> Hooks Class Initialized
DEBUG - 2018-03-21 05:34:49 --> UTF-8 Support Enabled
INFO - 2018-03-21 05:34:49 --> Utf8 Class Initialized
INFO - 2018-03-21 05:34:49 --> URI Class Initialized
DEBUG - 2018-03-21 05:34:49 --> UTF-8 Support Enabled
INFO - 2018-03-21 05:34:49 --> Utf8 Class Initialized
INFO - 2018-03-21 05:34:49 --> URI Class Initialized
INFO - 2018-03-21 05:34:49 --> Router Class Initialized
INFO - 2018-03-21 05:34:49 --> Router Class Initialized
INFO - 2018-03-21 05:34:49 --> Output Class Initialized
INFO - 2018-03-21 05:34:49 --> Output Class Initialized
INFO - 2018-03-21 05:34:49 --> Security Class Initialized
DEBUG - 2018-03-21 05:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 05:34:49 --> Input Class Initialized
INFO - 2018-03-21 05:34:49 --> Security Class Initialized
INFO - 2018-03-21 05:34:49 --> Language Class Initialized
DEBUG - 2018-03-21 05:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 05:34:49 --> Input Class Initialized
INFO - 2018-03-21 05:34:49 --> Language Class Initialized
INFO - 2018-03-21 05:34:49 --> Language Class Initialized
INFO - 2018-03-21 05:34:49 --> Config Class Initialized
INFO - 2018-03-21 05:34:49 --> Loader Class Initialized
INFO - 2018-03-21 11:04:49 --> Helper loaded: url_helper
INFO - 2018-03-21 05:34:49 --> Language Class Initialized
INFO - 2018-03-21 05:34:49 --> Config Class Initialized
INFO - 2018-03-21 05:34:49 --> Loader Class Initialized
INFO - 2018-03-21 11:04:49 --> Helper loaded: notification_helper
INFO - 2018-03-21 11:04:49 --> Helper loaded: settings_helper
INFO - 2018-03-21 11:04:49 --> Helper loaded: permission_helper
INFO - 2018-03-21 11:04:49 --> Helper loaded: url_helper
INFO - 2018-03-21 11:04:49 --> Helper loaded: users_helper
INFO - 2018-03-21 11:04:49 --> Helper loaded: notification_helper
INFO - 2018-03-21 11:04:49 --> Helper loaded: settings_helper
INFO - 2018-03-21 11:04:49 --> Helper loaded: permission_helper
INFO - 2018-03-21 11:04:49 --> Helper loaded: users_helper
INFO - 2018-03-21 11:04:49 --> Database Driver Class Initialized
INFO - 2018-03-21 11:04:49 --> Database Driver Class Initialized
DEBUG - 2018-03-21 11:04:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 11:04:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-03-21 11:04:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 11:04:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 11:04:49 --> Helper loaded: form_helper
INFO - 2018-03-21 11:04:49 --> Form Validation Class Initialized
INFO - 2018-03-21 11:04:49 --> Controller Class Initialized
INFO - 2018-03-21 11:04:49 --> Helper loaded: form_helper
INFO - 2018-03-21 11:04:49 --> Form Validation Class Initialized
INFO - 2018-03-21 11:04:49 --> Controller Class Initialized
INFO - 2018-03-21 11:04:49 --> Model Class Initialized
INFO - 2018-03-21 11:04:49 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 11:04:49 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 11:04:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 11:04:49 --> Model Class Initialized
INFO - 2018-03-21 11:04:49 --> Model Class Initialized
INFO - 2018-03-21 11:04:49 --> Model Class Initialized
INFO - 2018-03-21 11:04:49 --> Helper loaded: inflector_helper
INFO - 2018-03-21 11:04:49 --> Model Class Initialized
INFO - 2018-03-21 11:04:49 --> Model Class Initialized
INFO - 2018-03-21 11:04:49 --> Model Class Initialized
INFO - 2018-03-21 11:04:49 --> Model Class Initialized
INFO - 2018-03-21 11:04:49 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-21 11:04:49 --> Final output sent to browser
DEBUG - 2018-03-21 11:04:49 --> Total execution time: 0.4926
DEBUG - 2018-03-21 11:04:49 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 11:04:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 11:04:49 --> Model Class Initialized
INFO - 2018-03-21 11:04:49 --> Model Class Initialized
INFO - 2018-03-21 11:04:50 --> Model Class Initialized
INFO - 2018-03-21 11:04:50 --> Model Class Initialized
INFO - 2018-03-21 11:04:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-21 11:04:50 --> Final output sent to browser
DEBUG - 2018-03-21 11:04:50 --> Total execution time: 0.5492
INFO - 2018-03-21 05:35:08 --> Config Class Initialized
INFO - 2018-03-21 05:35:08 --> Hooks Class Initialized
DEBUG - 2018-03-21 05:35:08 --> UTF-8 Support Enabled
INFO - 2018-03-21 05:35:08 --> Utf8 Class Initialized
INFO - 2018-03-21 05:35:08 --> URI Class Initialized
INFO - 2018-03-21 05:35:08 --> Router Class Initialized
INFO - 2018-03-21 05:35:08 --> Output Class Initialized
INFO - 2018-03-21 05:35:08 --> Security Class Initialized
DEBUG - 2018-03-21 05:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 05:35:08 --> Input Class Initialized
INFO - 2018-03-21 05:35:08 --> Language Class Initialized
INFO - 2018-03-21 05:35:08 --> Language Class Initialized
INFO - 2018-03-21 05:35:08 --> Config Class Initialized
INFO - 2018-03-21 05:35:08 --> Loader Class Initialized
INFO - 2018-03-21 11:05:09 --> Helper loaded: url_helper
INFO - 2018-03-21 11:05:09 --> Helper loaded: notification_helper
INFO - 2018-03-21 11:05:09 --> Helper loaded: settings_helper
INFO - 2018-03-21 11:05:09 --> Helper loaded: permission_helper
INFO - 2018-03-21 11:05:09 --> Helper loaded: users_helper
INFO - 2018-03-21 11:05:09 --> Database Driver Class Initialized
DEBUG - 2018-03-21 11:05:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 11:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 11:05:09 --> Helper loaded: form_helper
INFO - 2018-03-21 11:05:09 --> Form Validation Class Initialized
INFO - 2018-03-21 11:05:09 --> Controller Class Initialized
INFO - 2018-03-21 11:05:09 --> Model Class Initialized
INFO - 2018-03-21 11:05:09 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 11:05:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 11:05:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 11:05:09 --> Model Class Initialized
INFO - 2018-03-21 11:05:09 --> Model Class Initialized
INFO - 2018-03-21 11:05:09 --> Model Class Initialized
INFO - 2018-03-21 11:05:09 --> Model Class Initialized
INFO - 2018-03-21 11:05:09 --> Model Class Initialized
INFO - 2018-03-21 11:05:09 --> Model Class Initialized
INFO - 2018-03-21 11:05:09 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-21 11:05:09 --> Final output sent to browser
DEBUG - 2018-03-21 11:05:09 --> Total execution time: 1.2814
INFO - 2018-03-21 08:38:52 --> Config Class Initialized
INFO - 2018-03-21 08:38:52 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:38:52 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:38:52 --> Utf8 Class Initialized
INFO - 2018-03-21 08:38:52 --> URI Class Initialized
INFO - 2018-03-21 08:38:52 --> Router Class Initialized
INFO - 2018-03-21 08:38:52 --> Output Class Initialized
INFO - 2018-03-21 08:38:52 --> Security Class Initialized
DEBUG - 2018-03-21 08:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:38:52 --> Input Class Initialized
INFO - 2018-03-21 08:38:52 --> Language Class Initialized
INFO - 2018-03-21 08:38:52 --> Language Class Initialized
INFO - 2018-03-21 08:38:52 --> Config Class Initialized
INFO - 2018-03-21 08:38:52 --> Loader Class Initialized
INFO - 2018-03-21 14:08:52 --> Helper loaded: url_helper
INFO - 2018-03-21 14:08:52 --> Helper loaded: notification_helper
INFO - 2018-03-21 14:08:52 --> Helper loaded: settings_helper
INFO - 2018-03-21 14:08:52 --> Helper loaded: permission_helper
INFO - 2018-03-21 14:08:52 --> Helper loaded: users_helper
INFO - 2018-03-21 14:08:52 --> Database Driver Class Initialized
DEBUG - 2018-03-21 14:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 14:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 14:08:52 --> Helper loaded: form_helper
INFO - 2018-03-21 14:08:52 --> Form Validation Class Initialized
INFO - 2018-03-21 14:08:52 --> Controller Class Initialized
DEBUG - 2018-03-21 14:08:52 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-03-21 14:08:52 --> Final output sent to browser
DEBUG - 2018-03-21 14:08:52 --> Total execution time: 0.1408
INFO - 2018-03-21 08:40:59 --> Config Class Initialized
INFO - 2018-03-21 08:40:59 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:40:59 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:40:59 --> Utf8 Class Initialized
INFO - 2018-03-21 08:40:59 --> URI Class Initialized
INFO - 2018-03-21 08:40:59 --> Router Class Initialized
INFO - 2018-03-21 08:40:59 --> Output Class Initialized
INFO - 2018-03-21 08:40:59 --> Security Class Initialized
DEBUG - 2018-03-21 08:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:40:59 --> Input Class Initialized
INFO - 2018-03-21 08:40:59 --> Language Class Initialized
INFO - 2018-03-21 08:40:59 --> Language Class Initialized
INFO - 2018-03-21 08:40:59 --> Config Class Initialized
INFO - 2018-03-21 08:40:59 --> Loader Class Initialized
INFO - 2018-03-21 14:10:59 --> Helper loaded: url_helper
INFO - 2018-03-21 14:10:59 --> Helper loaded: notification_helper
INFO - 2018-03-21 14:10:59 --> Helper loaded: settings_helper
INFO - 2018-03-21 14:10:59 --> Helper loaded: permission_helper
INFO - 2018-03-21 14:10:59 --> Helper loaded: users_helper
INFO - 2018-03-21 14:10:59 --> Database Driver Class Initialized
DEBUG - 2018-03-21 14:10:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 14:10:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 14:10:59 --> Helper loaded: form_helper
INFO - 2018-03-21 14:10:59 --> Form Validation Class Initialized
INFO - 2018-03-21 14:10:59 --> Controller Class Initialized
INFO - 2018-03-21 14:10:59 --> Model Class Initialized
INFO - 2018-03-21 14:10:59 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 14:10:59 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 14:10:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 14:10:59 --> Model Class Initialized
INFO - 2018-03-21 14:10:59 --> Model Class Initialized
INFO - 2018-03-21 14:10:59 --> Model Class Initialized
INFO - 2018-03-21 14:10:59 --> Model Class Initialized
INFO - 2018-03-21 14:10:59 --> Model Class Initialized
INFO - 2018-03-21 14:10:59 --> Model Class Initialized
INFO - 2018-03-21 14:10:59 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-21 14:10:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-21 14:10:59 --> Final output sent to browser
DEBUG - 2018-03-21 14:10:59 --> Total execution time: 0.2451
INFO - 2018-03-21 08:43:45 --> Config Class Initialized
INFO - 2018-03-21 08:43:45 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:43:45 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:43:45 --> Utf8 Class Initialized
INFO - 2018-03-21 08:43:45 --> URI Class Initialized
INFO - 2018-03-21 08:43:45 --> Router Class Initialized
INFO - 2018-03-21 08:43:45 --> Output Class Initialized
INFO - 2018-03-21 08:43:45 --> Security Class Initialized
DEBUG - 2018-03-21 08:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:43:45 --> Input Class Initialized
INFO - 2018-03-21 08:43:45 --> Language Class Initialized
INFO - 2018-03-21 08:43:45 --> Language Class Initialized
INFO - 2018-03-21 08:43:45 --> Config Class Initialized
INFO - 2018-03-21 08:43:45 --> Loader Class Initialized
INFO - 2018-03-21 14:13:45 --> Helper loaded: url_helper
INFO - 2018-03-21 14:13:45 --> Helper loaded: notification_helper
INFO - 2018-03-21 14:13:45 --> Helper loaded: settings_helper
INFO - 2018-03-21 14:13:45 --> Helper loaded: permission_helper
INFO - 2018-03-21 14:13:45 --> Helper loaded: users_helper
INFO - 2018-03-21 14:13:46 --> Database Driver Class Initialized
DEBUG - 2018-03-21 14:13:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 14:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 14:13:46 --> Helper loaded: form_helper
INFO - 2018-03-21 14:13:46 --> Form Validation Class Initialized
INFO - 2018-03-21 14:13:46 --> Controller Class Initialized
INFO - 2018-03-21 14:13:46 --> Model Class Initialized
INFO - 2018-03-21 14:13:46 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 14:13:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 14:13:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 14:13:46 --> Model Class Initialized
INFO - 2018-03-21 14:13:46 --> Model Class Initialized
INFO - 2018-03-21 14:13:46 --> Model Class Initialized
INFO - 2018-03-21 14:13:46 --> Model Class Initialized
INFO - 2018-03-21 14:13:46 --> Model Class Initialized
INFO - 2018-03-21 14:13:46 --> Model Class Initialized
INFO - 2018-03-21 14:13:46 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-21 14:13:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-21 14:13:46 --> Final output sent to browser
DEBUG - 2018-03-21 14:13:46 --> Total execution time: 1.4152
INFO - 2018-03-21 11:54:31 --> Config Class Initialized
INFO - 2018-03-21 11:54:31 --> Hooks Class Initialized
DEBUG - 2018-03-21 11:54:31 --> UTF-8 Support Enabled
INFO - 2018-03-21 11:54:31 --> Utf8 Class Initialized
INFO - 2018-03-21 11:54:31 --> URI Class Initialized
INFO - 2018-03-21 11:54:31 --> Router Class Initialized
INFO - 2018-03-21 11:54:32 --> Output Class Initialized
INFO - 2018-03-21 11:54:32 --> Security Class Initialized
DEBUG - 2018-03-21 11:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 11:54:32 --> Input Class Initialized
INFO - 2018-03-21 11:54:32 --> Language Class Initialized
INFO - 2018-03-21 11:54:33 --> Language Class Initialized
INFO - 2018-03-21 11:54:33 --> Config Class Initialized
INFO - 2018-03-21 11:54:33 --> Loader Class Initialized
INFO - 2018-03-21 17:24:33 --> Helper loaded: url_helper
INFO - 2018-03-21 17:24:33 --> Helper loaded: notification_helper
INFO - 2018-03-21 17:24:33 --> Helper loaded: settings_helper
INFO - 2018-03-21 17:24:33 --> Helper loaded: permission_helper
INFO - 2018-03-21 17:24:33 --> Helper loaded: users_helper
INFO - 2018-03-21 17:24:33 --> Database Driver Class Initialized
DEBUG - 2018-03-21 17:24:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 17:24:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 17:24:34 --> Helper loaded: form_helper
INFO - 2018-03-21 17:24:34 --> Form Validation Class Initialized
INFO - 2018-03-21 17:24:34 --> Controller Class Initialized
INFO - 2018-03-21 17:24:34 --> Model Class Initialized
INFO - 2018-03-21 17:24:34 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 17:24:34 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 17:24:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 17:24:34 --> Model Class Initialized
INFO - 2018-03-21 17:24:34 --> Model Class Initialized
INFO - 2018-03-21 17:24:34 --> Model Class Initialized
INFO - 2018-03-21 17:24:34 --> Model Class Initialized
INFO - 2018-03-21 17:24:34 --> Model Class Initialized
INFO - 2018-03-21 17:24:34 --> Model Class Initialized
INFO - 2018-03-21 17:24:34 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-21 17:24:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-21 17:24:34 --> Final output sent to browser
DEBUG - 2018-03-21 17:24:34 --> Total execution time: 3.1607
INFO - 2018-03-21 12:01:32 --> Config Class Initialized
INFO - 2018-03-21 12:01:32 --> Hooks Class Initialized
DEBUG - 2018-03-21 12:01:32 --> UTF-8 Support Enabled
INFO - 2018-03-21 12:01:32 --> Utf8 Class Initialized
INFO - 2018-03-21 12:01:32 --> URI Class Initialized
INFO - 2018-03-21 12:01:32 --> Router Class Initialized
INFO - 2018-03-21 12:01:32 --> Output Class Initialized
INFO - 2018-03-21 12:01:32 --> Security Class Initialized
DEBUG - 2018-03-21 12:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 12:01:32 --> Input Class Initialized
INFO - 2018-03-21 12:01:32 --> Language Class Initialized
INFO - 2018-03-21 12:01:32 --> Language Class Initialized
INFO - 2018-03-21 12:01:32 --> Config Class Initialized
INFO - 2018-03-21 12:01:32 --> Loader Class Initialized
INFO - 2018-03-21 17:31:32 --> Helper loaded: url_helper
INFO - 2018-03-21 17:31:32 --> Helper loaded: notification_helper
INFO - 2018-03-21 17:31:32 --> Helper loaded: settings_helper
INFO - 2018-03-21 17:31:32 --> Helper loaded: permission_helper
INFO - 2018-03-21 17:31:32 --> Helper loaded: users_helper
INFO - 2018-03-21 17:31:32 --> Database Driver Class Initialized
DEBUG - 2018-03-21 17:31:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 17:31:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 17:31:32 --> Helper loaded: form_helper
INFO - 2018-03-21 17:31:32 --> Form Validation Class Initialized
INFO - 2018-03-21 17:31:32 --> Controller Class Initialized
INFO - 2018-03-21 17:31:32 --> Model Class Initialized
INFO - 2018-03-21 17:31:32 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 17:31:32 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 17:31:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 17:31:32 --> Model Class Initialized
INFO - 2018-03-21 17:31:32 --> Model Class Initialized
INFO - 2018-03-21 17:31:32 --> Model Class Initialized
INFO - 2018-03-21 17:31:32 --> Model Class Initialized
INFO - 2018-03-21 17:31:32 --> Model Class Initialized
INFO - 2018-03-21 17:31:32 --> Model Class Initialized
INFO - 2018-03-21 17:31:32 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-21 17:31:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-21 17:31:32 --> Final output sent to browser
DEBUG - 2018-03-21 17:31:32 --> Total execution time: 0.1914
INFO - 2018-03-21 12:01:34 --> Config Class Initialized
INFO - 2018-03-21 12:01:34 --> Hooks Class Initialized
DEBUG - 2018-03-21 12:01:34 --> UTF-8 Support Enabled
INFO - 2018-03-21 12:01:34 --> Utf8 Class Initialized
INFO - 2018-03-21 12:01:34 --> URI Class Initialized
INFO - 2018-03-21 12:01:34 --> Router Class Initialized
INFO - 2018-03-21 12:01:34 --> Output Class Initialized
INFO - 2018-03-21 12:01:35 --> Security Class Initialized
DEBUG - 2018-03-21 12:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 12:01:35 --> Input Class Initialized
INFO - 2018-03-21 12:01:35 --> Language Class Initialized
INFO - 2018-03-21 12:01:35 --> Language Class Initialized
INFO - 2018-03-21 12:01:35 --> Config Class Initialized
INFO - 2018-03-21 12:01:35 --> Loader Class Initialized
INFO - 2018-03-21 17:31:35 --> Helper loaded: url_helper
INFO - 2018-03-21 12:01:35 --> Config Class Initialized
INFO - 2018-03-21 12:01:35 --> Hooks Class Initialized
DEBUG - 2018-03-21 12:01:35 --> UTF-8 Support Enabled
INFO - 2018-03-21 12:01:35 --> Utf8 Class Initialized
INFO - 2018-03-21 12:01:35 --> URI Class Initialized
INFO - 2018-03-21 17:31:35 --> Helper loaded: notification_helper
INFO - 2018-03-21 12:01:35 --> Router Class Initialized
INFO - 2018-03-21 12:01:35 --> Output Class Initialized
INFO - 2018-03-21 12:01:35 --> Security Class Initialized
INFO - 2018-03-21 17:31:35 --> Helper loaded: settings_helper
DEBUG - 2018-03-21 12:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 12:01:35 --> Input Class Initialized
INFO - 2018-03-21 12:01:35 --> Language Class Initialized
INFO - 2018-03-21 17:31:36 --> Helper loaded: permission_helper
INFO - 2018-03-21 17:31:36 --> Helper loaded: users_helper
INFO - 2018-03-21 12:01:36 --> Language Class Initialized
INFO - 2018-03-21 12:01:36 --> Config Class Initialized
INFO - 2018-03-21 12:01:36 --> Loader Class Initialized
INFO - 2018-03-21 17:31:36 --> Helper loaded: url_helper
INFO - 2018-03-21 17:31:36 --> Helper loaded: notification_helper
INFO - 2018-03-21 17:31:36 --> Helper loaded: settings_helper
INFO - 2018-03-21 17:31:36 --> Helper loaded: permission_helper
INFO - 2018-03-21 17:31:36 --> Helper loaded: users_helper
INFO - 2018-03-21 17:31:36 --> Database Driver Class Initialized
DEBUG - 2018-03-21 17:31:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 17:31:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 17:31:36 --> Helper loaded: form_helper
INFO - 2018-03-21 17:31:36 --> Form Validation Class Initialized
INFO - 2018-03-21 17:31:36 --> Controller Class Initialized
INFO - 2018-03-21 17:31:36 --> Model Class Initialized
INFO - 2018-03-21 17:31:36 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 17:31:36 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 17:31:36 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 17:31:36 --> Model Class Initialized
INFO - 2018-03-21 17:31:36 --> Model Class Initialized
INFO - 2018-03-21 17:31:36 --> Model Class Initialized
INFO - 2018-03-21 17:31:36 --> Model Class Initialized
INFO - 2018-03-21 17:31:36 --> Model Class Initialized
INFO - 2018-03-21 17:31:36 --> Model Class Initialized
INFO - 2018-03-21 17:31:36 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-21 17:31:36 --> Final output sent to browser
DEBUG - 2018-03-21 17:31:36 --> Total execution time: 0.2159
INFO - 2018-03-21 17:31:36 --> Database Driver Class Initialized
DEBUG - 2018-03-21 17:31:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 17:31:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 17:31:36 --> Helper loaded: form_helper
INFO - 2018-03-21 17:31:36 --> Form Validation Class Initialized
INFO - 2018-03-21 17:31:36 --> Controller Class Initialized
INFO - 2018-03-21 17:31:36 --> Model Class Initialized
INFO - 2018-03-21 17:31:36 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 17:31:36 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 17:31:36 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 17:31:36 --> Model Class Initialized
INFO - 2018-03-21 17:31:36 --> Model Class Initialized
INFO - 2018-03-21 17:31:36 --> Model Class Initialized
INFO - 2018-03-21 17:31:36 --> Model Class Initialized
INFO - 2018-03-21 17:31:36 --> Model Class Initialized
INFO - 2018-03-21 17:31:36 --> Model Class Initialized
INFO - 2018-03-21 17:31:36 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-21 17:31:36 --> Final output sent to browser
DEBUG - 2018-03-21 17:31:36 --> Total execution time: 2.3937
INFO - 2018-03-21 12:04:54 --> Config Class Initialized
INFO - 2018-03-21 12:04:54 --> Hooks Class Initialized
DEBUG - 2018-03-21 12:04:54 --> UTF-8 Support Enabled
INFO - 2018-03-21 12:04:54 --> Utf8 Class Initialized
INFO - 2018-03-21 12:04:54 --> URI Class Initialized
INFO - 2018-03-21 12:04:54 --> Router Class Initialized
INFO - 2018-03-21 12:04:54 --> Output Class Initialized
INFO - 2018-03-21 12:04:54 --> Security Class Initialized
DEBUG - 2018-03-21 12:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 12:04:54 --> Input Class Initialized
INFO - 2018-03-21 12:04:54 --> Language Class Initialized
INFO - 2018-03-21 12:04:54 --> Language Class Initialized
INFO - 2018-03-21 12:04:54 --> Config Class Initialized
INFO - 2018-03-21 12:04:54 --> Loader Class Initialized
INFO - 2018-03-21 17:34:54 --> Helper loaded: url_helper
INFO - 2018-03-21 17:34:54 --> Helper loaded: notification_helper
INFO - 2018-03-21 17:34:54 --> Helper loaded: settings_helper
INFO - 2018-03-21 17:34:54 --> Helper loaded: permission_helper
INFO - 2018-03-21 17:34:54 --> Helper loaded: users_helper
INFO - 2018-03-21 17:34:54 --> Database Driver Class Initialized
DEBUG - 2018-03-21 17:34:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 17:34:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 17:34:54 --> Helper loaded: form_helper
INFO - 2018-03-21 17:34:54 --> Form Validation Class Initialized
INFO - 2018-03-21 17:34:54 --> Controller Class Initialized
INFO - 2018-03-21 17:34:54 --> Model Class Initialized
INFO - 2018-03-21 17:34:54 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 17:34:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 17:34:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 17:34:54 --> Model Class Initialized
INFO - 2018-03-21 17:34:54 --> Model Class Initialized
INFO - 2018-03-21 17:34:54 --> Model Class Initialized
INFO - 2018-03-21 17:34:54 --> Model Class Initialized
INFO - 2018-03-21 17:34:54 --> Model Class Initialized
INFO - 2018-03-21 17:34:54 --> Model Class Initialized
INFO - 2018-03-21 17:34:54 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-21 17:34:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-21 17:34:54 --> Final output sent to browser
DEBUG - 2018-03-21 17:34:54 --> Total execution time: 0.2375
INFO - 2018-03-21 12:04:54 --> Config Class Initialized
INFO - 2018-03-21 12:04:54 --> Hooks Class Initialized
DEBUG - 2018-03-21 12:04:54 --> UTF-8 Support Enabled
INFO - 2018-03-21 12:04:54 --> Utf8 Class Initialized
INFO - 2018-03-21 12:04:54 --> URI Class Initialized
INFO - 2018-03-21 12:04:54 --> Router Class Initialized
INFO - 2018-03-21 12:04:54 --> Output Class Initialized
INFO - 2018-03-21 12:04:54 --> Security Class Initialized
DEBUG - 2018-03-21 12:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 12:04:54 --> Input Class Initialized
INFO - 2018-03-21 12:04:54 --> Language Class Initialized
INFO - 2018-03-21 12:04:55 --> Language Class Initialized
INFO - 2018-03-21 12:04:55 --> Config Class Initialized
INFO - 2018-03-21 12:04:55 --> Loader Class Initialized
INFO - 2018-03-21 17:34:55 --> Helper loaded: url_helper
INFO - 2018-03-21 17:34:55 --> Helper loaded: notification_helper
INFO - 2018-03-21 17:34:55 --> Helper loaded: settings_helper
INFO - 2018-03-21 17:34:55 --> Helper loaded: permission_helper
INFO - 2018-03-21 17:34:55 --> Helper loaded: users_helper
INFO - 2018-03-21 17:34:55 --> Database Driver Class Initialized
DEBUG - 2018-03-21 17:34:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 17:34:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 17:34:55 --> Helper loaded: form_helper
INFO - 2018-03-21 17:34:55 --> Form Validation Class Initialized
INFO - 2018-03-21 17:34:55 --> Controller Class Initialized
INFO - 2018-03-21 17:34:55 --> Model Class Initialized
INFO - 2018-03-21 17:34:55 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 17:34:55 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 17:34:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 17:34:55 --> Model Class Initialized
INFO - 2018-03-21 17:34:55 --> Model Class Initialized
INFO - 2018-03-21 17:34:55 --> Model Class Initialized
INFO - 2018-03-21 17:34:55 --> Model Class Initialized
INFO - 2018-03-21 17:34:55 --> Model Class Initialized
INFO - 2018-03-21 17:34:55 --> Model Class Initialized
INFO - 2018-03-21 17:34:55 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-21 17:34:55 --> Final output sent to browser
DEBUG - 2018-03-21 17:34:55 --> Total execution time: 0.1160
INFO - 2018-03-21 12:06:32 --> Config Class Initialized
INFO - 2018-03-21 12:06:32 --> Hooks Class Initialized
DEBUG - 2018-03-21 12:06:32 --> UTF-8 Support Enabled
INFO - 2018-03-21 12:06:32 --> Utf8 Class Initialized
INFO - 2018-03-21 12:06:32 --> URI Class Initialized
INFO - 2018-03-21 12:06:32 --> Router Class Initialized
INFO - 2018-03-21 12:06:33 --> Output Class Initialized
INFO - 2018-03-21 12:06:33 --> Security Class Initialized
DEBUG - 2018-03-21 12:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 12:06:33 --> Input Class Initialized
INFO - 2018-03-21 12:06:33 --> Language Class Initialized
INFO - 2018-03-21 12:06:33 --> Language Class Initialized
INFO - 2018-03-21 12:06:33 --> Config Class Initialized
INFO - 2018-03-21 12:06:33 --> Loader Class Initialized
INFO - 2018-03-21 17:36:33 --> Helper loaded: url_helper
INFO - 2018-03-21 17:36:33 --> Helper loaded: notification_helper
INFO - 2018-03-21 17:36:33 --> Helper loaded: settings_helper
INFO - 2018-03-21 17:36:33 --> Helper loaded: permission_helper
INFO - 2018-03-21 17:36:33 --> Helper loaded: users_helper
INFO - 2018-03-21 17:36:33 --> Database Driver Class Initialized
DEBUG - 2018-03-21 17:36:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 17:36:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 17:36:33 --> Helper loaded: form_helper
INFO - 2018-03-21 17:36:33 --> Form Validation Class Initialized
INFO - 2018-03-21 17:36:33 --> Controller Class Initialized
INFO - 2018-03-21 17:36:33 --> Model Class Initialized
INFO - 2018-03-21 17:36:33 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 17:36:33 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 17:36:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 17:36:33 --> Model Class Initialized
INFO - 2018-03-21 17:36:33 --> Model Class Initialized
INFO - 2018-03-21 17:36:34 --> Final output sent to browser
DEBUG - 2018-03-21 17:36:34 --> Total execution time: 1.2055
INFO - 2018-03-21 12:06:36 --> Config Class Initialized
INFO - 2018-03-21 12:06:36 --> Hooks Class Initialized
DEBUG - 2018-03-21 12:06:36 --> UTF-8 Support Enabled
INFO - 2018-03-21 12:06:36 --> Utf8 Class Initialized
INFO - 2018-03-21 12:06:36 --> URI Class Initialized
INFO - 2018-03-21 12:06:36 --> Router Class Initialized
INFO - 2018-03-21 12:06:36 --> Output Class Initialized
INFO - 2018-03-21 12:06:36 --> Security Class Initialized
DEBUG - 2018-03-21 12:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 12:06:36 --> Input Class Initialized
INFO - 2018-03-21 12:06:36 --> Language Class Initialized
INFO - 2018-03-21 12:06:36 --> Language Class Initialized
INFO - 2018-03-21 12:06:36 --> Config Class Initialized
INFO - 2018-03-21 12:06:36 --> Loader Class Initialized
INFO - 2018-03-21 17:36:36 --> Helper loaded: url_helper
INFO - 2018-03-21 17:36:36 --> Helper loaded: notification_helper
INFO - 2018-03-21 17:36:36 --> Helper loaded: settings_helper
INFO - 2018-03-21 17:36:36 --> Helper loaded: permission_helper
INFO - 2018-03-21 17:36:36 --> Helper loaded: users_helper
INFO - 2018-03-21 17:36:36 --> Database Driver Class Initialized
DEBUG - 2018-03-21 17:36:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 17:36:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 17:36:36 --> Helper loaded: form_helper
INFO - 2018-03-21 17:36:36 --> Form Validation Class Initialized
INFO - 2018-03-21 17:36:36 --> Controller Class Initialized
INFO - 2018-03-21 17:36:36 --> Model Class Initialized
INFO - 2018-03-21 17:36:36 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 17:36:36 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 17:36:36 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 17:36:36 --> Model Class Initialized
INFO - 2018-03-21 17:36:36 --> Model Class Initialized
INFO - 2018-03-21 17:36:36 --> Model Class Initialized
INFO - 2018-03-21 17:36:36 --> Model Class Initialized
INFO - 2018-03-21 17:36:36 --> Model Class Initialized
INFO - 2018-03-21 17:36:36 --> Model Class Initialized
INFO - 2018-03-21 17:36:36 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-21 17:36:36 --> Final output sent to browser
DEBUG - 2018-03-21 17:36:36 --> Total execution time: 0.1244
INFO - 2018-03-21 12:06:38 --> Config Class Initialized
INFO - 2018-03-21 12:06:38 --> Hooks Class Initialized
DEBUG - 2018-03-21 12:06:38 --> UTF-8 Support Enabled
INFO - 2018-03-21 12:06:38 --> Utf8 Class Initialized
INFO - 2018-03-21 12:06:38 --> URI Class Initialized
INFO - 2018-03-21 12:06:38 --> Router Class Initialized
INFO - 2018-03-21 12:06:38 --> Output Class Initialized
INFO - 2018-03-21 12:06:38 --> Security Class Initialized
DEBUG - 2018-03-21 12:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 12:06:39 --> Input Class Initialized
INFO - 2018-03-21 12:06:39 --> Language Class Initialized
INFO - 2018-03-21 12:06:39 --> Language Class Initialized
INFO - 2018-03-21 12:06:39 --> Config Class Initialized
INFO - 2018-03-21 12:06:39 --> Loader Class Initialized
INFO - 2018-03-21 17:36:39 --> Helper loaded: url_helper
INFO - 2018-03-21 17:36:39 --> Helper loaded: notification_helper
INFO - 2018-03-21 17:36:39 --> Helper loaded: settings_helper
INFO - 2018-03-21 17:36:39 --> Helper loaded: permission_helper
INFO - 2018-03-21 17:36:39 --> Helper loaded: users_helper
INFO - 2018-03-21 17:36:40 --> Database Driver Class Initialized
DEBUG - 2018-03-21 17:36:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 17:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 17:36:40 --> Helper loaded: form_helper
INFO - 2018-03-21 17:36:40 --> Form Validation Class Initialized
INFO - 2018-03-21 17:36:40 --> Controller Class Initialized
INFO - 2018-03-21 17:36:40 --> Model Class Initialized
INFO - 2018-03-21 17:36:40 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 17:36:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 17:36:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 17:36:40 --> Model Class Initialized
INFO - 2018-03-21 17:36:40 --> Model Class Initialized
INFO - 2018-03-21 17:36:40 --> Model Class Initialized
INFO - 2018-03-21 17:36:40 --> Model Class Initialized
INFO - 2018-03-21 17:36:40 --> Model Class Initialized
INFO - 2018-03-21 17:36:40 --> Model Class Initialized
INFO - 2018-03-21 17:36:40 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-21 17:36:40 --> Final output sent to browser
DEBUG - 2018-03-21 17:36:40 --> Total execution time: 2.0584
INFO - 2018-03-21 12:06:40 --> Config Class Initialized
INFO - 2018-03-21 12:06:40 --> Hooks Class Initialized
DEBUG - 2018-03-21 12:06:40 --> UTF-8 Support Enabled
INFO - 2018-03-21 12:06:40 --> Utf8 Class Initialized
INFO - 2018-03-21 12:06:40 --> URI Class Initialized
INFO - 2018-03-21 12:06:40 --> Router Class Initialized
INFO - 2018-03-21 12:06:40 --> Output Class Initialized
INFO - 2018-03-21 12:06:40 --> Security Class Initialized
DEBUG - 2018-03-21 12:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 12:06:40 --> Input Class Initialized
INFO - 2018-03-21 12:06:40 --> Language Class Initialized
INFO - 2018-03-21 12:06:40 --> Language Class Initialized
INFO - 2018-03-21 12:06:40 --> Config Class Initialized
INFO - 2018-03-21 12:06:40 --> Loader Class Initialized
INFO - 2018-03-21 17:36:40 --> Helper loaded: url_helper
INFO - 2018-03-21 17:36:40 --> Helper loaded: notification_helper
INFO - 2018-03-21 17:36:40 --> Helper loaded: settings_helper
INFO - 2018-03-21 17:36:40 --> Helper loaded: permission_helper
INFO - 2018-03-21 17:36:40 --> Helper loaded: users_helper
INFO - 2018-03-21 17:36:40 --> Database Driver Class Initialized
DEBUG - 2018-03-21 17:36:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 17:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 17:36:40 --> Helper loaded: form_helper
INFO - 2018-03-21 17:36:40 --> Form Validation Class Initialized
INFO - 2018-03-21 17:36:40 --> Controller Class Initialized
INFO - 2018-03-21 17:36:40 --> Model Class Initialized
INFO - 2018-03-21 17:36:40 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 17:36:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 17:36:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 17:36:40 --> Model Class Initialized
INFO - 2018-03-21 17:36:40 --> Model Class Initialized
INFO - 2018-03-21 17:36:40 --> Model Class Initialized
INFO - 2018-03-21 17:36:40 --> Model Class Initialized
INFO - 2018-03-21 17:36:40 --> Model Class Initialized
INFO - 2018-03-21 17:36:40 --> Model Class Initialized
INFO - 2018-03-21 17:36:40 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-21 17:36:40 --> Final output sent to browser
DEBUG - 2018-03-21 17:36:40 --> Total execution time: 0.1102
INFO - 2018-03-21 12:06:56 --> Config Class Initialized
INFO - 2018-03-21 12:06:56 --> Hooks Class Initialized
DEBUG - 2018-03-21 12:06:56 --> UTF-8 Support Enabled
INFO - 2018-03-21 12:06:56 --> Utf8 Class Initialized
INFO - 2018-03-21 12:06:56 --> URI Class Initialized
INFO - 2018-03-21 12:06:56 --> Router Class Initialized
INFO - 2018-03-21 12:06:56 --> Output Class Initialized
INFO - 2018-03-21 12:06:56 --> Security Class Initialized
DEBUG - 2018-03-21 12:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 12:06:56 --> Input Class Initialized
INFO - 2018-03-21 12:06:56 --> Language Class Initialized
INFO - 2018-03-21 12:06:57 --> Language Class Initialized
INFO - 2018-03-21 12:06:57 --> Config Class Initialized
INFO - 2018-03-21 12:06:57 --> Loader Class Initialized
INFO - 2018-03-21 17:36:57 --> Helper loaded: url_helper
INFO - 2018-03-21 17:36:57 --> Helper loaded: notification_helper
INFO - 2018-03-21 17:36:57 --> Helper loaded: settings_helper
INFO - 2018-03-21 17:36:57 --> Helper loaded: permission_helper
INFO - 2018-03-21 17:36:57 --> Helper loaded: users_helper
INFO - 2018-03-21 17:36:57 --> Database Driver Class Initialized
DEBUG - 2018-03-21 17:36:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 17:36:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 17:36:57 --> Helper loaded: form_helper
INFO - 2018-03-21 17:36:57 --> Form Validation Class Initialized
INFO - 2018-03-21 17:36:57 --> Controller Class Initialized
INFO - 2018-03-21 17:36:57 --> Model Class Initialized
INFO - 2018-03-21 17:36:57 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 17:36:57 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 17:36:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 17:36:57 --> Model Class Initialized
INFO - 2018-03-21 17:36:57 --> Model Class Initialized
INFO - 2018-03-21 17:36:57 --> Model Class Initialized
INFO - 2018-03-21 17:36:57 --> Model Class Initialized
INFO - 2018-03-21 17:36:57 --> Model Class Initialized
INFO - 2018-03-21 17:36:57 --> Model Class Initialized
INFO - 2018-03-21 17:36:57 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-21 17:36:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-21 17:36:57 --> Final output sent to browser
DEBUG - 2018-03-21 17:36:57 --> Total execution time: 0.2473
INFO - 2018-03-21 12:06:57 --> Config Class Initialized
INFO - 2018-03-21 12:06:57 --> Hooks Class Initialized
DEBUG - 2018-03-21 12:06:57 --> UTF-8 Support Enabled
INFO - 2018-03-21 12:06:57 --> Utf8 Class Initialized
INFO - 2018-03-21 12:06:57 --> URI Class Initialized
INFO - 2018-03-21 12:06:57 --> Router Class Initialized
INFO - 2018-03-21 12:06:57 --> Output Class Initialized
INFO - 2018-03-21 12:06:57 --> Security Class Initialized
DEBUG - 2018-03-21 12:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 12:06:57 --> Input Class Initialized
INFO - 2018-03-21 12:06:57 --> Language Class Initialized
INFO - 2018-03-21 12:06:58 --> Language Class Initialized
INFO - 2018-03-21 12:06:58 --> Config Class Initialized
INFO - 2018-03-21 12:06:58 --> Loader Class Initialized
INFO - 2018-03-21 17:36:58 --> Helper loaded: url_helper
INFO - 2018-03-21 17:36:58 --> Helper loaded: notification_helper
INFO - 2018-03-21 17:36:58 --> Helper loaded: settings_helper
INFO - 2018-03-21 17:36:58 --> Helper loaded: permission_helper
INFO - 2018-03-21 17:36:58 --> Helper loaded: users_helper
INFO - 2018-03-21 17:36:58 --> Database Driver Class Initialized
DEBUG - 2018-03-21 17:36:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 17:36:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 12:06:58 --> Config Class Initialized
INFO - 2018-03-21 12:06:58 --> Hooks Class Initialized
DEBUG - 2018-03-21 12:06:58 --> UTF-8 Support Enabled
INFO - 2018-03-21 12:06:58 --> Utf8 Class Initialized
INFO - 2018-03-21 12:06:58 --> URI Class Initialized
INFO - 2018-03-21 17:36:58 --> Helper loaded: form_helper
INFO - 2018-03-21 17:36:58 --> Form Validation Class Initialized
INFO - 2018-03-21 17:36:58 --> Controller Class Initialized
INFO - 2018-03-21 12:06:58 --> Router Class Initialized
INFO - 2018-03-21 12:06:58 --> Output Class Initialized
INFO - 2018-03-21 12:06:58 --> Security Class Initialized
INFO - 2018-03-21 17:36:58 --> Model Class Initialized
INFO - 2018-03-21 17:36:58 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 12:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 12:06:58 --> Input Class Initialized
INFO - 2018-03-21 12:06:58 --> Language Class Initialized
DEBUG - 2018-03-21 17:36:58 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 17:36:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 17:36:58 --> Model Class Initialized
INFO - 2018-03-21 12:06:58 --> Config Class Initialized
INFO - 2018-03-21 12:06:58 --> Hooks Class Initialized
INFO - 2018-03-21 17:36:58 --> Model Class Initialized
INFO - 2018-03-21 17:36:58 --> Model Class Initialized
INFO - 2018-03-21 17:36:58 --> Model Class Initialized
DEBUG - 2018-03-21 12:06:58 --> UTF-8 Support Enabled
INFO - 2018-03-21 12:06:58 --> Utf8 Class Initialized
INFO - 2018-03-21 17:36:58 --> Model Class Initialized
INFO - 2018-03-21 17:36:58 --> Model Class Initialized
INFO - 2018-03-21 17:36:58 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-21 12:06:58 --> URI Class Initialized
INFO - 2018-03-21 17:36:58 --> Final output sent to browser
DEBUG - 2018-03-21 17:36:58 --> Total execution time: 0.5685
INFO - 2018-03-21 12:06:58 --> Router Class Initialized
INFO - 2018-03-21 12:06:58 --> Output Class Initialized
INFO - 2018-03-21 12:06:58 --> Security Class Initialized
INFO - 2018-03-21 12:06:58 --> Language Class Initialized
INFO - 2018-03-21 12:06:58 --> Config Class Initialized
INFO - 2018-03-21 12:06:58 --> Loader Class Initialized
INFO - 2018-03-21 17:36:58 --> Helper loaded: url_helper
DEBUG - 2018-03-21 12:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 12:06:58 --> Input Class Initialized
INFO - 2018-03-21 12:06:58 --> Language Class Initialized
INFO - 2018-03-21 17:36:58 --> Helper loaded: notification_helper
INFO - 2018-03-21 17:36:58 --> Helper loaded: settings_helper
INFO - 2018-03-21 17:36:58 --> Helper loaded: permission_helper
INFO - 2018-03-21 17:36:58 --> Helper loaded: users_helper
INFO - 2018-03-21 17:36:58 --> Database Driver Class Initialized
DEBUG - 2018-03-21 17:36:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 17:36:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 12:06:58 --> Language Class Initialized
INFO - 2018-03-21 12:06:58 --> Config Class Initialized
INFO - 2018-03-21 12:06:58 --> Loader Class Initialized
INFO - 2018-03-21 17:36:58 --> Helper loaded: form_helper
INFO - 2018-03-21 17:36:58 --> Form Validation Class Initialized
INFO - 2018-03-21 17:36:58 --> Controller Class Initialized
INFO - 2018-03-21 17:36:58 --> Helper loaded: url_helper
INFO - 2018-03-21 17:36:58 --> Helper loaded: notification_helper
INFO - 2018-03-21 17:36:58 --> Helper loaded: settings_helper
INFO - 2018-03-21 17:36:58 --> Helper loaded: permission_helper
INFO - 2018-03-21 17:36:58 --> Helper loaded: users_helper
INFO - 2018-03-21 17:36:58 --> Model Class Initialized
INFO - 2018-03-21 17:36:58 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 17:36:58 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 17:36:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 17:36:58 --> Model Class Initialized
INFO - 2018-03-21 17:36:58 --> Model Class Initialized
INFO - 2018-03-21 17:36:58 --> Model Class Initialized
INFO - 2018-03-21 17:36:58 --> Model Class Initialized
INFO - 2018-03-21 17:36:58 --> Model Class Initialized
INFO - 2018-03-21 17:36:58 --> Model Class Initialized
INFO - 2018-03-21 17:36:58 --> Model Class Initialized
INFO - 2018-03-21 17:36:58 --> Model Class Initialized
INFO - 2018-03-21 17:36:58 --> Model Class Initialized
INFO - 2018-03-21 17:36:58 --> Model Class Initialized
INFO - 2018-03-21 17:36:58 --> Model Class Initialized
INFO - 2018-03-21 17:36:58 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-21 17:36:58 --> Model Class Initialized
INFO - 2018-03-21 17:36:58 --> Database Driver Class Initialized
INFO - 2018-03-21 17:36:58 --> Final output sent to browser
DEBUG - 2018-03-21 17:36:58 --> Total execution time: 0.5534
DEBUG - 2018-03-21 17:36:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 17:36:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 17:36:58 --> Helper loaded: form_helper
INFO - 2018-03-21 17:36:58 --> Form Validation Class Initialized
INFO - 2018-03-21 17:36:58 --> Controller Class Initialized
INFO - 2018-03-21 17:36:58 --> Model Class Initialized
INFO - 2018-03-21 17:36:58 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 17:36:58 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 17:36:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 17:36:58 --> Model Class Initialized
INFO - 2018-03-21 17:36:58 --> Model Class Initialized
INFO - 2018-03-21 17:36:58 --> Model Class Initialized
INFO - 2018-03-21 17:36:58 --> Model Class Initialized
INFO - 2018-03-21 17:36:58 --> Model Class Initialized
INFO - 2018-03-21 17:36:58 --> Model Class Initialized
INFO - 2018-03-21 17:36:58 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-21 17:36:58 --> Model Class Initialized
INFO - 2018-03-21 17:36:58 --> Final output sent to browser
DEBUG - 2018-03-21 17:36:58 --> Total execution time: 0.6002
INFO - 2018-03-21 12:06:59 --> Config Class Initialized
INFO - 2018-03-21 12:06:59 --> Hooks Class Initialized
DEBUG - 2018-03-21 12:06:59 --> UTF-8 Support Enabled
INFO - 2018-03-21 12:06:59 --> Utf8 Class Initialized
INFO - 2018-03-21 12:06:59 --> URI Class Initialized
INFO - 2018-03-21 12:06:59 --> Router Class Initialized
INFO - 2018-03-21 12:07:00 --> Output Class Initialized
INFO - 2018-03-21 12:07:00 --> Security Class Initialized
DEBUG - 2018-03-21 12:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 12:07:00 --> Input Class Initialized
INFO - 2018-03-21 12:07:00 --> Language Class Initialized
INFO - 2018-03-21 12:07:00 --> Config Class Initialized
INFO - 2018-03-21 12:07:00 --> Hooks Class Initialized
INFO - 2018-03-21 12:07:00 --> Config Class Initialized
INFO - 2018-03-21 12:07:00 --> Hooks Class Initialized
DEBUG - 2018-03-21 12:07:00 --> UTF-8 Support Enabled
INFO - 2018-03-21 12:07:00 --> Utf8 Class Initialized
INFO - 2018-03-21 12:07:00 --> URI Class Initialized
INFO - 2018-03-21 12:07:00 --> Router Class Initialized
INFO - 2018-03-21 12:07:00 --> Output Class Initialized
INFO - 2018-03-21 12:07:00 --> Security Class Initialized
DEBUG - 2018-03-21 12:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 12:07:00 --> Input Class Initialized
INFO - 2018-03-21 12:07:00 --> Language Class Initialized
INFO - 2018-03-21 12:07:00 --> Language Class Initialized
INFO - 2018-03-21 12:07:00 --> Config Class Initialized
INFO - 2018-03-21 12:07:00 --> Loader Class Initialized
INFO - 2018-03-21 17:37:00 --> Helper loaded: url_helper
INFO - 2018-03-21 17:37:00 --> Helper loaded: notification_helper
INFO - 2018-03-21 17:37:00 --> Helper loaded: settings_helper
INFO - 2018-03-21 17:37:00 --> Helper loaded: permission_helper
INFO - 2018-03-21 17:37:00 --> Helper loaded: users_helper
INFO - 2018-03-21 17:37:00 --> Database Driver Class Initialized
DEBUG - 2018-03-21 12:07:00 --> UTF-8 Support Enabled
DEBUG - 2018-03-21 17:37:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 17:37:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 12:07:00 --> Utf8 Class Initialized
INFO - 2018-03-21 17:37:00 --> Helper loaded: form_helper
INFO - 2018-03-21 17:37:00 --> Form Validation Class Initialized
INFO - 2018-03-21 17:37:00 --> Controller Class Initialized
INFO - 2018-03-21 17:37:00 --> Model Class Initialized
INFO - 2018-03-21 17:37:00 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 17:37:00 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 17:37:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 17:37:00 --> Model Class Initialized
INFO - 2018-03-21 17:37:00 --> Model Class Initialized
INFO - 2018-03-21 17:37:00 --> Model Class Initialized
INFO - 2018-03-21 17:37:00 --> Model Class Initialized
INFO - 2018-03-21 17:37:00 --> Model Class Initialized
INFO - 2018-03-21 12:07:00 --> URI Class Initialized
INFO - 2018-03-21 17:37:00 --> Model Class Initialized
INFO - 2018-03-21 17:37:00 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-21 17:37:01 --> Model Class Initialized
INFO - 2018-03-21 17:37:01 --> Final output sent to browser
DEBUG - 2018-03-21 17:37:01 --> Total execution time: 0.4610
INFO - 2018-03-21 12:07:01 --> Router Class Initialized
INFO - 2018-03-21 12:07:01 --> Output Class Initialized
INFO - 2018-03-21 12:07:01 --> Language Class Initialized
INFO - 2018-03-21 12:07:01 --> Config Class Initialized
INFO - 2018-03-21 12:07:01 --> Loader Class Initialized
INFO - 2018-03-21 12:07:01 --> Security Class Initialized
INFO - 2018-03-21 17:37:01 --> Helper loaded: url_helper
INFO - 2018-03-21 17:37:01 --> Helper loaded: notification_helper
DEBUG - 2018-03-21 12:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 17:37:01 --> Helper loaded: settings_helper
INFO - 2018-03-21 12:07:01 --> Input Class Initialized
INFO - 2018-03-21 17:37:01 --> Helper loaded: permission_helper
INFO - 2018-03-21 12:07:01 --> Language Class Initialized
INFO - 2018-03-21 17:37:01 --> Helper loaded: users_helper
INFO - 2018-03-21 12:07:02 --> Language Class Initialized
INFO - 2018-03-21 12:07:02 --> Config Class Initialized
INFO - 2018-03-21 12:07:02 --> Loader Class Initialized
INFO - 2018-03-21 17:37:02 --> Helper loaded: url_helper
INFO - 2018-03-21 17:37:02 --> Helper loaded: notification_helper
INFO - 2018-03-21 17:37:02 --> Helper loaded: settings_helper
INFO - 2018-03-21 17:37:02 --> Helper loaded: permission_helper
INFO - 2018-03-21 17:37:02 --> Helper loaded: users_helper
INFO - 2018-03-21 17:37:02 --> Database Driver Class Initialized
DEBUG - 2018-03-21 17:37:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 17:37:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 17:37:02 --> Helper loaded: form_helper
INFO - 2018-03-21 17:37:02 --> Form Validation Class Initialized
INFO - 2018-03-21 17:37:02 --> Controller Class Initialized
INFO - 2018-03-21 17:37:02 --> Model Class Initialized
INFO - 2018-03-21 17:37:02 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 17:37:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 17:37:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 17:37:02 --> Model Class Initialized
INFO - 2018-03-21 17:37:02 --> Model Class Initialized
INFO - 2018-03-21 17:37:02 --> Model Class Initialized
INFO - 2018-03-21 17:37:02 --> Model Class Initialized
INFO - 2018-03-21 17:37:02 --> Model Class Initialized
INFO - 2018-03-21 17:37:02 --> Model Class Initialized
INFO - 2018-03-21 17:37:02 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-21 17:37:02 --> Model Class Initialized
INFO - 2018-03-21 17:37:02 --> Final output sent to browser
DEBUG - 2018-03-21 17:37:02 --> Total execution time: 3.6086
INFO - 2018-03-21 17:37:03 --> Database Driver Class Initialized
DEBUG - 2018-03-21 17:37:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 12:07:03 --> Config Class Initialized
INFO - 2018-03-21 12:07:03 --> Hooks Class Initialized
INFO - 2018-03-21 17:37:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-03-21 12:07:03 --> UTF-8 Support Enabled
INFO - 2018-03-21 12:07:03 --> Utf8 Class Initialized
INFO - 2018-03-21 12:07:03 --> URI Class Initialized
INFO - 2018-03-21 12:07:03 --> Router Class Initialized
INFO - 2018-03-21 12:07:03 --> Output Class Initialized
INFO - 2018-03-21 12:07:03 --> Security Class Initialized
DEBUG - 2018-03-21 12:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 12:07:03 --> Input Class Initialized
INFO - 2018-03-21 12:07:03 --> Language Class Initialized
INFO - 2018-03-21 17:37:03 --> Helper loaded: form_helper
INFO - 2018-03-21 17:37:03 --> Form Validation Class Initialized
INFO - 2018-03-21 17:37:03 --> Controller Class Initialized
INFO - 2018-03-21 12:07:03 --> Language Class Initialized
INFO - 2018-03-21 12:07:03 --> Config Class Initialized
INFO - 2018-03-21 12:07:03 --> Loader Class Initialized
INFO - 2018-03-21 17:37:03 --> Helper loaded: url_helper
INFO - 2018-03-21 17:37:03 --> Helper loaded: notification_helper
INFO - 2018-03-21 17:37:03 --> Helper loaded: settings_helper
INFO - 2018-03-21 17:37:03 --> Helper loaded: permission_helper
INFO - 2018-03-21 17:37:03 --> Helper loaded: users_helper
INFO - 2018-03-21 17:37:03 --> Database Driver Class Initialized
DEBUG - 2018-03-21 17:37:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 17:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 17:37:03 --> Helper loaded: form_helper
INFO - 2018-03-21 17:37:03 --> Form Validation Class Initialized
INFO - 2018-03-21 17:37:03 --> Controller Class Initialized
INFO - 2018-03-21 17:37:03 --> Model Class Initialized
INFO - 2018-03-21 17:37:03 --> Helper loaded: inflector_helper
INFO - 2018-03-21 17:37:03 --> Model Class Initialized
INFO - 2018-03-21 17:37:03 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 17:37:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 17:37:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 17:37:03 --> Model Class Initialized
INFO - 2018-03-21 17:37:03 --> Model Class Initialized
INFO - 2018-03-21 17:37:03 --> Model Class Initialized
INFO - 2018-03-21 17:37:03 --> Model Class Initialized
DEBUG - 2018-03-21 17:37:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 17:37:03 --> Model Class Initialized
INFO - 2018-03-21 17:37:03 --> Model Class Initialized
INFO - 2018-03-21 17:37:03 --> Model Class Initialized
INFO - 2018-03-21 17:37:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 17:37:03 --> Model Class Initialized
INFO - 2018-03-21 17:37:03 --> Model Class Initialized
INFO - 2018-03-21 17:37:03 --> Model Class Initialized
INFO - 2018-03-21 17:37:03 --> Model Class Initialized
INFO - 2018-03-21 17:37:03 --> Model Class Initialized
INFO - 2018-03-21 17:37:03 --> Model Class Initialized
INFO - 2018-03-21 17:37:03 --> Model Class Initialized
INFO - 2018-03-21 17:37:03 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-21 17:37:03 --> Model Class Initialized
INFO - 2018-03-21 17:37:03 --> Model Class Initialized
INFO - 2018-03-21 17:37:03 --> Model Class Initialized
INFO - 2018-03-21 17:37:03 --> Model Class Initialized
INFO - 2018-03-21 17:37:03 --> Model Class Initialized
INFO - 2018-03-21 17:37:03 --> Model Class Initialized
INFO - 2018-03-21 17:37:03 --> Model Class Initialized
INFO - 2018-03-21 17:37:03 --> Model Class Initialized
INFO - 2018-03-21 17:37:03 --> Final output sent to browser
DEBUG - 2018-03-21 17:37:03 --> Total execution time: 0.4380
INFO - 2018-03-21 17:37:03 --> Model Class Initialized
INFO - 2018-03-21 17:37:03 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-21 17:37:03 --> Model Class Initialized
INFO - 2018-03-21 17:37:03 --> Final output sent to browser
DEBUG - 2018-03-21 17:37:03 --> Total execution time: 3.5742
INFO - 2018-03-21 12:07:08 --> Config Class Initialized
INFO - 2018-03-21 12:07:08 --> Hooks Class Initialized
DEBUG - 2018-03-21 12:07:08 --> UTF-8 Support Enabled
INFO - 2018-03-21 12:07:08 --> Utf8 Class Initialized
INFO - 2018-03-21 12:07:08 --> URI Class Initialized
INFO - 2018-03-21 12:07:08 --> Router Class Initialized
INFO - 2018-03-21 12:07:08 --> Output Class Initialized
INFO - 2018-03-21 12:07:08 --> Security Class Initialized
DEBUG - 2018-03-21 12:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 12:07:08 --> Input Class Initialized
INFO - 2018-03-21 12:07:08 --> Language Class Initialized
INFO - 2018-03-21 12:07:09 --> Language Class Initialized
INFO - 2018-03-21 12:07:09 --> Config Class Initialized
INFO - 2018-03-21 12:07:09 --> Loader Class Initialized
INFO - 2018-03-21 17:37:09 --> Helper loaded: url_helper
INFO - 2018-03-21 17:37:09 --> Helper loaded: notification_helper
INFO - 2018-03-21 17:37:09 --> Helper loaded: settings_helper
INFO - 2018-03-21 17:37:09 --> Helper loaded: permission_helper
INFO - 2018-03-21 17:37:09 --> Helper loaded: users_helper
INFO - 2018-03-21 17:37:09 --> Database Driver Class Initialized
DEBUG - 2018-03-21 17:37:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 17:37:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 17:37:09 --> Helper loaded: form_helper
INFO - 2018-03-21 17:37:09 --> Form Validation Class Initialized
INFO - 2018-03-21 17:37:09 --> Controller Class Initialized
INFO - 2018-03-21 17:37:09 --> Model Class Initialized
INFO - 2018-03-21 17:37:09 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 17:37:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 17:37:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 17:37:10 --> Model Class Initialized
INFO - 2018-03-21 17:37:10 --> Model Class Initialized
INFO - 2018-03-21 17:37:10 --> Model Class Initialized
INFO - 2018-03-21 17:37:10 --> Model Class Initialized
INFO - 2018-03-21 17:37:10 --> Model Class Initialized
INFO - 2018-03-21 17:37:10 --> Model Class Initialized
INFO - 2018-03-21 17:37:10 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-21 17:37:10 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
ERROR - 2018-03-21 17:37:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 784
INFO - 2018-03-21 17:37:10 --> Final output sent to browser
DEBUG - 2018-03-21 17:37:10 --> Total execution time: 1.5665
INFO - 2018-03-21 12:07:12 --> Config Class Initialized
INFO - 2018-03-21 12:07:12 --> Hooks Class Initialized
DEBUG - 2018-03-21 12:07:12 --> UTF-8 Support Enabled
INFO - 2018-03-21 12:07:12 --> Utf8 Class Initialized
INFO - 2018-03-21 12:07:12 --> URI Class Initialized
INFO - 2018-03-21 12:07:12 --> Router Class Initialized
INFO - 2018-03-21 12:07:12 --> Output Class Initialized
INFO - 2018-03-21 12:07:12 --> Security Class Initialized
DEBUG - 2018-03-21 12:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 12:07:12 --> Input Class Initialized
INFO - 2018-03-21 12:07:12 --> Language Class Initialized
INFO - 2018-03-21 12:07:12 --> Config Class Initialized
INFO - 2018-03-21 12:07:12 --> Hooks Class Initialized
INFO - 2018-03-21 12:07:12 --> Language Class Initialized
INFO - 2018-03-21 12:07:12 --> Config Class Initialized
INFO - 2018-03-21 12:07:12 --> Loader Class Initialized
DEBUG - 2018-03-21 12:07:12 --> UTF-8 Support Enabled
INFO - 2018-03-21 12:07:12 --> Utf8 Class Initialized
INFO - 2018-03-21 17:37:12 --> Helper loaded: url_helper
INFO - 2018-03-21 17:37:12 --> Helper loaded: notification_helper
INFO - 2018-03-21 17:37:12 --> Helper loaded: settings_helper
INFO - 2018-03-21 17:37:12 --> Helper loaded: permission_helper
INFO - 2018-03-21 12:07:12 --> URI Class Initialized
INFO - 2018-03-21 17:37:12 --> Helper loaded: users_helper
INFO - 2018-03-21 12:07:13 --> Router Class Initialized
INFO - 2018-03-21 12:07:13 --> Output Class Initialized
INFO - 2018-03-21 12:07:13 --> Security Class Initialized
DEBUG - 2018-03-21 12:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 12:07:13 --> Input Class Initialized
INFO - 2018-03-21 12:07:13 --> Language Class Initialized
INFO - 2018-03-21 17:37:14 --> Database Driver Class Initialized
DEBUG - 2018-03-21 17:37:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 17:37:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 17:37:14 --> Helper loaded: form_helper
INFO - 2018-03-21 17:37:14 --> Form Validation Class Initialized
INFO - 2018-03-21 17:37:14 --> Controller Class Initialized
INFO - 2018-03-21 17:37:14 --> Model Class Initialized
INFO - 2018-03-21 17:37:14 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 17:37:14 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 17:37:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 17:37:14 --> Model Class Initialized
INFO - 2018-03-21 17:37:14 --> Model Class Initialized
INFO - 2018-03-21 17:37:14 --> Model Class Initialized
INFO - 2018-03-21 17:37:14 --> Model Class Initialized
INFO - 2018-03-21 17:37:14 --> Model Class Initialized
INFO - 2018-03-21 17:37:14 --> Model Class Initialized
INFO - 2018-03-21 17:37:14 --> Model Class Initialized
INFO - 2018-03-21 17:37:14 --> Model Class Initialized
INFO - 2018-03-21 17:37:14 --> Model Class Initialized
INFO - 2018-03-21 17:37:14 --> Model Class Initialized
INFO - 2018-03-21 12:07:14 --> Language Class Initialized
INFO - 2018-03-21 12:07:14 --> Config Class Initialized
INFO - 2018-03-21 12:07:14 --> Loader Class Initialized
INFO - 2018-03-21 17:37:14 --> Model Class Initialized
INFO - 2018-03-21 17:37:14 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-21 17:37:14 --> Model Class Initialized
INFO - 2018-03-21 17:37:14 --> Helper loaded: url_helper
INFO - 2018-03-21 17:37:14 --> Helper loaded: notification_helper
INFO - 2018-03-21 17:37:15 --> Helper loaded: settings_helper
INFO - 2018-03-21 17:37:15 --> Helper loaded: permission_helper
INFO - 2018-03-21 17:37:15 --> Helper loaded: users_helper
INFO - 2018-03-21 17:37:15 --> Final output sent to browser
DEBUG - 2018-03-21 17:37:15 --> Total execution time: 2.9924
INFO - 2018-03-21 17:37:15 --> Database Driver Class Initialized
DEBUG - 2018-03-21 17:37:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 17:37:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 17:37:15 --> Helper loaded: form_helper
INFO - 2018-03-21 17:37:15 --> Form Validation Class Initialized
INFO - 2018-03-21 17:37:15 --> Controller Class Initialized
INFO - 2018-03-21 17:37:15 --> Model Class Initialized
INFO - 2018-03-21 17:37:15 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 17:37:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 17:37:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 17:37:15 --> Model Class Initialized
INFO - 2018-03-21 17:37:15 --> Model Class Initialized
INFO - 2018-03-21 17:37:15 --> Model Class Initialized
INFO - 2018-03-21 17:37:15 --> Model Class Initialized
INFO - 2018-03-21 17:37:15 --> Model Class Initialized
INFO - 2018-03-21 17:37:15 --> Model Class Initialized
INFO - 2018-03-21 17:37:15 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-21 17:37:15 --> Model Class Initialized
INFO - 2018-03-21 17:37:15 --> Final output sent to browser
DEBUG - 2018-03-21 17:37:15 --> Total execution time: 2.6913
INFO - 2018-03-21 12:07:15 --> Config Class Initialized
INFO - 2018-03-21 12:07:15 --> Hooks Class Initialized
DEBUG - 2018-03-21 12:07:15 --> UTF-8 Support Enabled
INFO - 2018-03-21 12:07:15 --> Utf8 Class Initialized
INFO - 2018-03-21 12:07:15 --> URI Class Initialized
INFO - 2018-03-21 12:07:15 --> Router Class Initialized
INFO - 2018-03-21 12:07:15 --> Output Class Initialized
INFO - 2018-03-21 12:07:15 --> Security Class Initialized
DEBUG - 2018-03-21 12:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 12:07:15 --> Input Class Initialized
INFO - 2018-03-21 12:07:15 --> Language Class Initialized
INFO - 2018-03-21 12:07:15 --> Language Class Initialized
INFO - 2018-03-21 12:07:15 --> Config Class Initialized
INFO - 2018-03-21 12:07:15 --> Loader Class Initialized
INFO - 2018-03-21 17:37:15 --> Helper loaded: url_helper
INFO - 2018-03-21 17:37:15 --> Helper loaded: notification_helper
INFO - 2018-03-21 17:37:15 --> Helper loaded: settings_helper
INFO - 2018-03-21 17:37:15 --> Helper loaded: permission_helper
INFO - 2018-03-21 17:37:15 --> Helper loaded: users_helper
INFO - 2018-03-21 17:37:15 --> Database Driver Class Initialized
DEBUG - 2018-03-21 17:37:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 17:37:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 17:37:15 --> Helper loaded: form_helper
INFO - 2018-03-21 17:37:15 --> Form Validation Class Initialized
INFO - 2018-03-21 17:37:15 --> Controller Class Initialized
INFO - 2018-03-21 17:37:15 --> Model Class Initialized
INFO - 2018-03-21 17:37:15 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 17:37:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 17:37:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 17:37:15 --> Model Class Initialized
INFO - 2018-03-21 17:37:15 --> Model Class Initialized
INFO - 2018-03-21 17:37:15 --> Model Class Initialized
INFO - 2018-03-21 17:37:15 --> Model Class Initialized
INFO - 2018-03-21 17:37:15 --> Model Class Initialized
INFO - 2018-03-21 17:37:15 --> Model Class Initialized
INFO - 2018-03-21 17:37:15 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-21 17:37:15 --> Model Class Initialized
INFO - 2018-03-21 17:37:15 --> Final output sent to browser
DEBUG - 2018-03-21 17:37:15 --> Total execution time: 0.2063
INFO - 2018-03-21 12:07:20 --> Config Class Initialized
INFO - 2018-03-21 12:07:20 --> Hooks Class Initialized
DEBUG - 2018-03-21 12:07:20 --> UTF-8 Support Enabled
INFO - 2018-03-21 12:07:20 --> Utf8 Class Initialized
INFO - 2018-03-21 12:07:20 --> URI Class Initialized
INFO - 2018-03-21 12:07:20 --> Router Class Initialized
INFO - 2018-03-21 12:07:20 --> Output Class Initialized
INFO - 2018-03-21 12:07:20 --> Security Class Initialized
DEBUG - 2018-03-21 12:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 12:07:20 --> Input Class Initialized
INFO - 2018-03-21 12:07:20 --> Language Class Initialized
INFO - 2018-03-21 12:07:20 --> Language Class Initialized
INFO - 2018-03-21 12:07:20 --> Config Class Initialized
INFO - 2018-03-21 12:07:20 --> Loader Class Initialized
INFO - 2018-03-21 17:37:20 --> Helper loaded: url_helper
INFO - 2018-03-21 17:37:20 --> Helper loaded: notification_helper
INFO - 2018-03-21 17:37:20 --> Helper loaded: settings_helper
INFO - 2018-03-21 17:37:20 --> Helper loaded: permission_helper
INFO - 2018-03-21 17:37:20 --> Helper loaded: users_helper
INFO - 2018-03-21 17:37:20 --> Database Driver Class Initialized
DEBUG - 2018-03-21 17:37:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 17:37:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 17:37:20 --> Helper loaded: form_helper
INFO - 2018-03-21 17:37:20 --> Form Validation Class Initialized
INFO - 2018-03-21 17:37:20 --> Controller Class Initialized
INFO - 2018-03-21 17:37:20 --> Model Class Initialized
INFO - 2018-03-21 17:37:20 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 17:37:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 17:37:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 17:37:20 --> Model Class Initialized
INFO - 2018-03-21 17:37:20 --> Model Class Initialized
INFO - 2018-03-21 17:37:20 --> Model Class Initialized
INFO - 2018-03-21 17:37:20 --> Model Class Initialized
INFO - 2018-03-21 17:37:20 --> Model Class Initialized
INFO - 2018-03-21 17:37:20 --> Model Class Initialized
INFO - 2018-03-21 17:37:20 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-21 17:37:20 --> Model Class Initialized
INFO - 2018-03-21 17:37:20 --> Model Class Initialized
INFO - 2018-03-21 17:37:21 --> Final output sent to browser
DEBUG - 2018-03-21 17:37:21 --> Total execution time: 1.0313
INFO - 2018-03-21 12:07:23 --> Config Class Initialized
INFO - 2018-03-21 12:07:23 --> Hooks Class Initialized
DEBUG - 2018-03-21 12:07:23 --> UTF-8 Support Enabled
INFO - 2018-03-21 12:07:23 --> Utf8 Class Initialized
INFO - 2018-03-21 12:07:23 --> URI Class Initialized
INFO - 2018-03-21 12:07:23 --> Router Class Initialized
INFO - 2018-03-21 12:07:23 --> Output Class Initialized
INFO - 2018-03-21 12:07:23 --> Security Class Initialized
DEBUG - 2018-03-21 12:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 12:07:23 --> Input Class Initialized
INFO - 2018-03-21 12:07:23 --> Language Class Initialized
INFO - 2018-03-21 12:07:24 --> Language Class Initialized
INFO - 2018-03-21 12:07:24 --> Config Class Initialized
INFO - 2018-03-21 12:07:24 --> Loader Class Initialized
INFO - 2018-03-21 17:37:24 --> Helper loaded: url_helper
INFO - 2018-03-21 17:37:24 --> Helper loaded: notification_helper
INFO - 2018-03-21 17:37:24 --> Helper loaded: settings_helper
INFO - 2018-03-21 17:37:24 --> Helper loaded: permission_helper
INFO - 2018-03-21 17:37:24 --> Helper loaded: users_helper
INFO - 2018-03-21 17:37:24 --> Database Driver Class Initialized
DEBUG - 2018-03-21 17:37:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 17:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 17:37:24 --> Helper loaded: form_helper
INFO - 2018-03-21 17:37:24 --> Form Validation Class Initialized
INFO - 2018-03-21 17:37:24 --> Controller Class Initialized
INFO - 2018-03-21 17:37:24 --> Model Class Initialized
INFO - 2018-03-21 17:37:24 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 17:37:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 17:37:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 17:37:24 --> Model Class Initialized
INFO - 2018-03-21 17:37:24 --> Model Class Initialized
INFO - 2018-03-21 17:37:24 --> Model Class Initialized
INFO - 2018-03-21 17:37:24 --> Model Class Initialized
INFO - 2018-03-21 17:37:24 --> Model Class Initialized
INFO - 2018-03-21 17:37:24 --> Model Class Initialized
INFO - 2018-03-21 17:37:24 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-21 17:37:24 --> Model Class Initialized
INFO - 2018-03-21 17:37:24 --> Model Class Initialized
INFO - 2018-03-21 17:37:24 --> Final output sent to browser
DEBUG - 2018-03-21 17:37:24 --> Total execution time: 0.5499
INFO - 2018-03-21 12:07:27 --> Config Class Initialized
INFO - 2018-03-21 12:07:27 --> Hooks Class Initialized
DEBUG - 2018-03-21 12:07:27 --> UTF-8 Support Enabled
INFO - 2018-03-21 12:07:27 --> Utf8 Class Initialized
INFO - 2018-03-21 12:07:27 --> URI Class Initialized
INFO - 2018-03-21 12:07:27 --> Router Class Initialized
INFO - 2018-03-21 12:07:27 --> Output Class Initialized
INFO - 2018-03-21 12:07:27 --> Security Class Initialized
DEBUG - 2018-03-21 12:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 12:07:27 --> Input Class Initialized
INFO - 2018-03-21 12:07:27 --> Language Class Initialized
INFO - 2018-03-21 12:07:28 --> Language Class Initialized
INFO - 2018-03-21 12:07:28 --> Config Class Initialized
INFO - 2018-03-21 12:07:28 --> Loader Class Initialized
INFO - 2018-03-21 17:37:28 --> Helper loaded: url_helper
INFO - 2018-03-21 17:37:28 --> Helper loaded: notification_helper
INFO - 2018-03-21 17:37:28 --> Helper loaded: settings_helper
INFO - 2018-03-21 17:37:28 --> Helper loaded: permission_helper
INFO - 2018-03-21 17:37:28 --> Helper loaded: users_helper
INFO - 2018-03-21 17:37:28 --> Database Driver Class Initialized
DEBUG - 2018-03-21 17:37:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 17:37:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 17:37:28 --> Helper loaded: form_helper
INFO - 2018-03-21 17:37:28 --> Form Validation Class Initialized
INFO - 2018-03-21 17:37:28 --> Controller Class Initialized
INFO - 2018-03-21 17:37:28 --> Model Class Initialized
INFO - 2018-03-21 17:37:28 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 17:37:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 17:37:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 17:37:28 --> Model Class Initialized
INFO - 2018-03-21 17:37:28 --> Model Class Initialized
INFO - 2018-03-21 17:37:28 --> Model Class Initialized
INFO - 2018-03-21 17:37:28 --> Model Class Initialized
INFO - 2018-03-21 17:37:28 --> Model Class Initialized
INFO - 2018-03-21 17:37:28 --> Model Class Initialized
INFO - 2018-03-21 17:37:28 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-21 17:37:28 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-21 17:37:28 --> Final output sent to browser
DEBUG - 2018-03-21 17:37:28 --> Total execution time: 0.3282
INFO - 2018-03-21 12:07:31 --> Config Class Initialized
INFO - 2018-03-21 12:07:31 --> Hooks Class Initialized
DEBUG - 2018-03-21 12:07:31 --> UTF-8 Support Enabled
INFO - 2018-03-21 12:07:31 --> Utf8 Class Initialized
INFO - 2018-03-21 12:07:31 --> URI Class Initialized
INFO - 2018-03-21 12:07:31 --> Router Class Initialized
INFO - 2018-03-21 12:07:31 --> Output Class Initialized
INFO - 2018-03-21 12:07:31 --> Security Class Initialized
DEBUG - 2018-03-21 12:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 12:07:31 --> Input Class Initialized
INFO - 2018-03-21 12:07:31 --> Language Class Initialized
INFO - 2018-03-21 12:07:31 --> Language Class Initialized
INFO - 2018-03-21 12:07:31 --> Config Class Initialized
INFO - 2018-03-21 12:07:31 --> Loader Class Initialized
INFO - 2018-03-21 17:37:31 --> Helper loaded: url_helper
INFO - 2018-03-21 17:37:31 --> Helper loaded: notification_helper
INFO - 2018-03-21 17:37:31 --> Helper loaded: settings_helper
INFO - 2018-03-21 17:37:31 --> Helper loaded: permission_helper
INFO - 2018-03-21 17:37:31 --> Helper loaded: users_helper
INFO - 2018-03-21 17:37:31 --> Database Driver Class Initialized
DEBUG - 2018-03-21 17:37:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 17:37:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 17:37:31 --> Helper loaded: form_helper
INFO - 2018-03-21 17:37:31 --> Form Validation Class Initialized
INFO - 2018-03-21 17:37:31 --> Controller Class Initialized
INFO - 2018-03-21 17:37:31 --> Model Class Initialized
INFO - 2018-03-21 17:37:31 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 17:37:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 17:37:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 17:37:31 --> Model Class Initialized
INFO - 2018-03-21 17:37:31 --> Model Class Initialized
INFO - 2018-03-21 17:37:31 --> Model Class Initialized
INFO - 2018-03-21 17:37:31 --> Model Class Initialized
INFO - 2018-03-21 17:37:31 --> Model Class Initialized
INFO - 2018-03-21 17:37:31 --> Model Class Initialized
INFO - 2018-03-21 17:37:31 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-21 17:37:31 --> Model Class Initialized
INFO - 2018-03-21 17:37:31 --> Final output sent to browser
DEBUG - 2018-03-21 17:37:31 --> Total execution time: 0.2775
INFO - 2018-03-21 12:07:31 --> Config Class Initialized
INFO - 2018-03-21 12:07:31 --> Hooks Class Initialized
DEBUG - 2018-03-21 12:07:31 --> UTF-8 Support Enabled
INFO - 2018-03-21 12:07:31 --> Utf8 Class Initialized
INFO - 2018-03-21 12:07:31 --> URI Class Initialized
INFO - 2018-03-21 12:07:31 --> Router Class Initialized
INFO - 2018-03-21 12:07:31 --> Output Class Initialized
INFO - 2018-03-21 12:07:31 --> Security Class Initialized
DEBUG - 2018-03-21 12:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 12:07:31 --> Input Class Initialized
INFO - 2018-03-21 12:07:31 --> Language Class Initialized
INFO - 2018-03-21 12:07:31 --> Language Class Initialized
INFO - 2018-03-21 12:07:31 --> Config Class Initialized
INFO - 2018-03-21 12:07:31 --> Loader Class Initialized
INFO - 2018-03-21 17:37:31 --> Helper loaded: url_helper
INFO - 2018-03-21 17:37:31 --> Helper loaded: notification_helper
INFO - 2018-03-21 17:37:31 --> Helper loaded: settings_helper
INFO - 2018-03-21 17:37:31 --> Helper loaded: permission_helper
INFO - 2018-03-21 17:37:31 --> Helper loaded: users_helper
INFO - 2018-03-21 17:37:31 --> Database Driver Class Initialized
DEBUG - 2018-03-21 17:37:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 17:37:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 17:37:31 --> Helper loaded: form_helper
INFO - 2018-03-21 17:37:31 --> Form Validation Class Initialized
INFO - 2018-03-21 17:37:31 --> Controller Class Initialized
INFO - 2018-03-21 17:37:31 --> Model Class Initialized
INFO - 2018-03-21 17:37:31 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 17:37:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 17:37:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 17:37:31 --> Model Class Initialized
INFO - 2018-03-21 17:37:31 --> Model Class Initialized
INFO - 2018-03-21 17:37:31 --> Model Class Initialized
INFO - 2018-03-21 17:37:31 --> Model Class Initialized
INFO - 2018-03-21 17:37:31 --> Model Class Initialized
INFO - 2018-03-21 17:37:31 --> Model Class Initialized
INFO - 2018-03-21 17:37:31 --> Model Class Initialized
INFO - 2018-03-21 17:37:31 --> Model Class Initialized
INFO - 2018-03-21 17:37:31 --> Model Class Initialized
INFO - 2018-03-21 17:37:31 --> Model Class Initialized
INFO - 2018-03-21 17:37:31 --> Model Class Initialized
INFO - 2018-03-21 17:37:31 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-21 17:37:31 --> Model Class Initialized
INFO - 2018-03-21 17:37:31 --> Final output sent to browser
DEBUG - 2018-03-21 17:37:31 --> Total execution time: 0.3489
INFO - 2018-03-21 12:07:33 --> Config Class Initialized
INFO - 2018-03-21 12:07:33 --> Hooks Class Initialized
DEBUG - 2018-03-21 12:07:33 --> UTF-8 Support Enabled
INFO - 2018-03-21 12:07:33 --> Utf8 Class Initialized
INFO - 2018-03-21 12:07:33 --> URI Class Initialized
INFO - 2018-03-21 12:07:33 --> Router Class Initialized
INFO - 2018-03-21 12:07:33 --> Output Class Initialized
INFO - 2018-03-21 12:07:33 --> Security Class Initialized
DEBUG - 2018-03-21 12:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 12:07:33 --> Input Class Initialized
INFO - 2018-03-21 12:07:33 --> Language Class Initialized
INFO - 2018-03-21 12:07:33 --> Language Class Initialized
INFO - 2018-03-21 12:07:33 --> Config Class Initialized
INFO - 2018-03-21 12:07:33 --> Loader Class Initialized
INFO - 2018-03-21 17:37:33 --> Helper loaded: url_helper
INFO - 2018-03-21 17:37:33 --> Helper loaded: notification_helper
INFO - 2018-03-21 17:37:33 --> Helper loaded: settings_helper
INFO - 2018-03-21 17:37:33 --> Helper loaded: permission_helper
INFO - 2018-03-21 17:37:33 --> Helper loaded: users_helper
INFO - 2018-03-21 17:37:33 --> Database Driver Class Initialized
DEBUG - 2018-03-21 17:37:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 17:37:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 17:37:33 --> Helper loaded: form_helper
INFO - 2018-03-21 17:37:33 --> Form Validation Class Initialized
INFO - 2018-03-21 17:37:33 --> Controller Class Initialized
INFO - 2018-03-21 17:37:33 --> Model Class Initialized
INFO - 2018-03-21 17:37:33 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 17:37:33 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 17:37:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 17:37:33 --> Model Class Initialized
INFO - 2018-03-21 17:37:33 --> Model Class Initialized
INFO - 2018-03-21 17:37:33 --> Model Class Initialized
INFO - 2018-03-21 17:37:33 --> Model Class Initialized
INFO - 2018-03-21 17:37:33 --> Model Class Initialized
INFO - 2018-03-21 17:37:33 --> Model Class Initialized
INFO - 2018-03-21 17:37:33 --> Model Class Initialized
INFO - 2018-03-21 17:37:33 --> Model Class Initialized
INFO - 2018-03-21 17:37:33 --> Model Class Initialized
INFO - 2018-03-21 17:37:33 --> Model Class Initialized
INFO - 2018-03-21 17:37:33 --> Model Class Initialized
INFO - 2018-03-21 17:37:33 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-21 17:37:33 --> Model Class Initialized
INFO - 2018-03-21 17:37:33 --> Final output sent to browser
DEBUG - 2018-03-21 17:37:33 --> Total execution time: 0.2649
INFO - 2018-03-21 12:07:34 --> Config Class Initialized
INFO - 2018-03-21 12:07:34 --> Hooks Class Initialized
DEBUG - 2018-03-21 12:07:34 --> UTF-8 Support Enabled
INFO - 2018-03-21 12:07:34 --> Utf8 Class Initialized
INFO - 2018-03-21 12:07:34 --> URI Class Initialized
INFO - 2018-03-21 12:07:34 --> Router Class Initialized
INFO - 2018-03-21 12:07:34 --> Output Class Initialized
INFO - 2018-03-21 12:07:34 --> Security Class Initialized
DEBUG - 2018-03-21 12:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 12:07:34 --> Input Class Initialized
INFO - 2018-03-21 12:07:34 --> Language Class Initialized
INFO - 2018-03-21 12:07:34 --> Language Class Initialized
INFO - 2018-03-21 12:07:34 --> Config Class Initialized
INFO - 2018-03-21 12:07:34 --> Loader Class Initialized
INFO - 2018-03-21 17:37:34 --> Helper loaded: url_helper
INFO - 2018-03-21 17:37:34 --> Helper loaded: notification_helper
INFO - 2018-03-21 17:37:34 --> Helper loaded: settings_helper
INFO - 2018-03-21 17:37:34 --> Helper loaded: permission_helper
INFO - 2018-03-21 17:37:34 --> Helper loaded: users_helper
INFO - 2018-03-21 17:37:35 --> Database Driver Class Initialized
DEBUG - 2018-03-21 17:37:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 17:37:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 17:37:35 --> Helper loaded: form_helper
INFO - 2018-03-21 17:37:35 --> Form Validation Class Initialized
INFO - 2018-03-21 17:37:35 --> Controller Class Initialized
INFO - 2018-03-21 17:37:35 --> Model Class Initialized
INFO - 2018-03-21 17:37:35 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 17:37:35 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 17:37:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 17:37:35 --> Model Class Initialized
INFO - 2018-03-21 17:37:35 --> Model Class Initialized
INFO - 2018-03-21 17:37:35 --> Model Class Initialized
INFO - 2018-03-21 17:37:35 --> Model Class Initialized
INFO - 2018-03-21 17:37:35 --> Model Class Initialized
INFO - 2018-03-21 17:37:35 --> Model Class Initialized
INFO - 2018-03-21 17:37:35 --> Model Class Initialized
INFO - 2018-03-21 17:37:35 --> Model Class Initialized
INFO - 2018-03-21 17:37:35 --> Model Class Initialized
INFO - 2018-03-21 17:37:35 --> Model Class Initialized
INFO - 2018-03-21 17:37:35 --> Model Class Initialized
INFO - 2018-03-21 17:37:35 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-21 17:37:35 --> Final output sent to browser
DEBUG - 2018-03-21 17:37:35 --> Total execution time: 1.2607
INFO - 2018-03-21 12:07:35 --> Config Class Initialized
INFO - 2018-03-21 12:07:35 --> Hooks Class Initialized
DEBUG - 2018-03-21 12:07:36 --> UTF-8 Support Enabled
INFO - 2018-03-21 12:07:36 --> Utf8 Class Initialized
INFO - 2018-03-21 12:07:36 --> URI Class Initialized
INFO - 2018-03-21 12:07:36 --> Router Class Initialized
INFO - 2018-03-21 12:07:36 --> Output Class Initialized
INFO - 2018-03-21 12:07:36 --> Security Class Initialized
DEBUG - 2018-03-21 12:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 12:07:36 --> Input Class Initialized
INFO - 2018-03-21 12:07:36 --> Language Class Initialized
INFO - 2018-03-21 12:07:36 --> Language Class Initialized
INFO - 2018-03-21 12:07:36 --> Config Class Initialized
INFO - 2018-03-21 12:07:36 --> Loader Class Initialized
INFO - 2018-03-21 17:37:36 --> Helper loaded: url_helper
INFO - 2018-03-21 17:37:36 --> Helper loaded: notification_helper
INFO - 2018-03-21 17:37:36 --> Helper loaded: settings_helper
INFO - 2018-03-21 17:37:36 --> Helper loaded: permission_helper
INFO - 2018-03-21 17:37:36 --> Helper loaded: users_helper
INFO - 2018-03-21 17:37:36 --> Database Driver Class Initialized
DEBUG - 2018-03-21 17:37:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 17:37:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 17:37:36 --> Helper loaded: form_helper
INFO - 2018-03-21 17:37:36 --> Form Validation Class Initialized
INFO - 2018-03-21 17:37:36 --> Controller Class Initialized
INFO - 2018-03-21 17:37:36 --> Model Class Initialized
INFO - 2018-03-21 17:37:36 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 17:37:36 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 17:37:36 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 17:37:36 --> Model Class Initialized
INFO - 2018-03-21 17:37:36 --> Model Class Initialized
INFO - 2018-03-21 17:37:36 --> Model Class Initialized
INFO - 2018-03-21 17:37:36 --> Model Class Initialized
INFO - 2018-03-21 17:37:36 --> Model Class Initialized
INFO - 2018-03-21 17:37:36 --> Model Class Initialized
INFO - 2018-03-21 17:37:36 --> Model Class Initialized
INFO - 2018-03-21 17:37:36 --> Model Class Initialized
INFO - 2018-03-21 17:37:36 --> Model Class Initialized
INFO - 2018-03-21 17:37:36 --> Model Class Initialized
INFO - 2018-03-21 17:37:36 --> Model Class Initialized
INFO - 2018-03-21 17:37:36 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-21 17:37:36 --> Final output sent to browser
DEBUG - 2018-03-21 17:37:36 --> Total execution time: 0.2620
INFO - 2018-03-21 12:07:37 --> Config Class Initialized
INFO - 2018-03-21 12:07:37 --> Hooks Class Initialized
DEBUG - 2018-03-21 12:07:37 --> UTF-8 Support Enabled
INFO - 2018-03-21 12:07:37 --> Utf8 Class Initialized
INFO - 2018-03-21 12:07:37 --> URI Class Initialized
INFO - 2018-03-21 12:07:37 --> Router Class Initialized
INFO - 2018-03-21 12:07:37 --> Output Class Initialized
INFO - 2018-03-21 12:07:37 --> Security Class Initialized
DEBUG - 2018-03-21 12:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 12:07:37 --> Input Class Initialized
INFO - 2018-03-21 12:07:37 --> Language Class Initialized
INFO - 2018-03-21 12:07:37 --> Language Class Initialized
INFO - 2018-03-21 12:07:37 --> Config Class Initialized
INFO - 2018-03-21 12:07:37 --> Loader Class Initialized
INFO - 2018-03-21 17:37:37 --> Helper loaded: url_helper
INFO - 2018-03-21 17:37:37 --> Helper loaded: notification_helper
INFO - 2018-03-21 17:37:37 --> Helper loaded: settings_helper
INFO - 2018-03-21 17:37:37 --> Helper loaded: permission_helper
INFO - 2018-03-21 17:37:37 --> Helper loaded: users_helper
INFO - 2018-03-21 17:37:37 --> Database Driver Class Initialized
DEBUG - 2018-03-21 17:37:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 17:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 17:37:37 --> Helper loaded: form_helper
INFO - 2018-03-21 17:37:37 --> Form Validation Class Initialized
INFO - 2018-03-21 17:37:37 --> Controller Class Initialized
INFO - 2018-03-21 17:37:37 --> Model Class Initialized
INFO - 2018-03-21 17:37:37 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 17:37:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 17:37:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 17:37:37 --> Model Class Initialized
INFO - 2018-03-21 17:37:37 --> Model Class Initialized
INFO - 2018-03-21 17:37:37 --> Model Class Initialized
INFO - 2018-03-21 17:37:37 --> Model Class Initialized
INFO - 2018-03-21 17:37:37 --> Model Class Initialized
INFO - 2018-03-21 17:37:37 --> Model Class Initialized
INFO - 2018-03-21 17:37:37 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-21 17:37:37 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-03-21 17:37:37 --> Final output sent to browser
DEBUG - 2018-03-21 17:37:37 --> Total execution time: 0.1810
INFO - 2018-03-21 12:07:38 --> Config Class Initialized
INFO - 2018-03-21 12:07:38 --> Hooks Class Initialized
DEBUG - 2018-03-21 12:07:38 --> UTF-8 Support Enabled
INFO - 2018-03-21 12:07:38 --> Utf8 Class Initialized
INFO - 2018-03-21 12:07:38 --> URI Class Initialized
INFO - 2018-03-21 12:07:38 --> Router Class Initialized
INFO - 2018-03-21 12:07:38 --> Output Class Initialized
INFO - 2018-03-21 12:07:38 --> Security Class Initialized
DEBUG - 2018-03-21 12:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 12:07:38 --> Input Class Initialized
INFO - 2018-03-21 12:07:38 --> Language Class Initialized
INFO - 2018-03-21 12:07:38 --> Language Class Initialized
INFO - 2018-03-21 12:07:38 --> Config Class Initialized
INFO - 2018-03-21 12:07:38 --> Loader Class Initialized
INFO - 2018-03-21 17:37:38 --> Helper loaded: url_helper
INFO - 2018-03-21 17:37:38 --> Helper loaded: notification_helper
INFO - 2018-03-21 17:37:38 --> Helper loaded: settings_helper
INFO - 2018-03-21 17:37:38 --> Helper loaded: permission_helper
INFO - 2018-03-21 17:37:38 --> Helper loaded: users_helper
INFO - 2018-03-21 17:37:38 --> Database Driver Class Initialized
DEBUG - 2018-03-21 17:37:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 17:37:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 12:07:38 --> Config Class Initialized
INFO - 2018-03-21 12:07:38 --> Hooks Class Initialized
DEBUG - 2018-03-21 12:07:38 --> UTF-8 Support Enabled
INFO - 2018-03-21 12:07:38 --> Utf8 Class Initialized
INFO - 2018-03-21 17:37:38 --> Helper loaded: form_helper
INFO - 2018-03-21 17:37:38 --> Form Validation Class Initialized
INFO - 2018-03-21 17:37:38 --> Controller Class Initialized
INFO - 2018-03-21 12:07:38 --> URI Class Initialized
INFO - 2018-03-21 12:07:38 --> Router Class Initialized
INFO - 2018-03-21 12:07:38 --> Output Class Initialized
INFO - 2018-03-21 17:37:38 --> Model Class Initialized
INFO - 2018-03-21 17:37:38 --> Helper loaded: inflector_helper
INFO - 2018-03-21 12:07:38 --> Security Class Initialized
DEBUG - 2018-03-21 17:37:38 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-03-21 12:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 12:07:38 --> Input Class Initialized
INFO - 2018-03-21 17:37:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 12:07:38 --> Language Class Initialized
INFO - 2018-03-21 17:37:38 --> Model Class Initialized
INFO - 2018-03-21 17:37:38 --> Model Class Initialized
INFO - 2018-03-21 17:37:38 --> Model Class Initialized
INFO - 2018-03-21 17:37:38 --> Model Class Initialized
INFO - 2018-03-21 17:37:38 --> Model Class Initialized
INFO - 2018-03-21 17:37:38 --> Model Class Initialized
INFO - 2018-03-21 17:37:38 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-21 17:37:38 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-03-21 17:37:38 --> Final output sent to browser
DEBUG - 2018-03-21 17:37:38 --> Total execution time: 0.2400
INFO - 2018-03-21 12:07:38 --> Language Class Initialized
INFO - 2018-03-21 12:07:38 --> Config Class Initialized
INFO - 2018-03-21 12:07:38 --> Loader Class Initialized
INFO - 2018-03-21 17:37:38 --> Helper loaded: url_helper
INFO - 2018-03-21 17:37:38 --> Helper loaded: notification_helper
INFO - 2018-03-21 17:37:38 --> Helper loaded: settings_helper
INFO - 2018-03-21 17:37:38 --> Helper loaded: permission_helper
INFO - 2018-03-21 17:37:38 --> Helper loaded: users_helper
INFO - 2018-03-21 17:37:38 --> Database Driver Class Initialized
DEBUG - 2018-03-21 17:37:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 17:37:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 17:37:38 --> Helper loaded: form_helper
INFO - 2018-03-21 17:37:38 --> Form Validation Class Initialized
INFO - 2018-03-21 17:37:38 --> Controller Class Initialized
INFO - 2018-03-21 17:37:38 --> Model Class Initialized
INFO - 2018-03-21 17:37:38 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 17:37:38 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 17:37:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 17:37:38 --> Model Class Initialized
INFO - 2018-03-21 17:37:38 --> Model Class Initialized
INFO - 2018-03-21 17:37:38 --> Model Class Initialized
INFO - 2018-03-21 17:37:38 --> Model Class Initialized
INFO - 2018-03-21 17:37:38 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-21 17:37:38 --> Final output sent to browser
DEBUG - 2018-03-21 17:37:38 --> Total execution time: 0.2721
INFO - 2018-03-21 12:07:39 --> Config Class Initialized
INFO - 2018-03-21 12:07:39 --> Hooks Class Initialized
DEBUG - 2018-03-21 12:07:39 --> UTF-8 Support Enabled
INFO - 2018-03-21 12:07:39 --> Utf8 Class Initialized
INFO - 2018-03-21 12:07:39 --> URI Class Initialized
INFO - 2018-03-21 12:07:39 --> Router Class Initialized
INFO - 2018-03-21 12:07:39 --> Output Class Initialized
INFO - 2018-03-21 12:07:39 --> Security Class Initialized
DEBUG - 2018-03-21 12:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 12:07:39 --> Input Class Initialized
INFO - 2018-03-21 12:07:39 --> Language Class Initialized
INFO - 2018-03-21 12:07:39 --> Language Class Initialized
INFO - 2018-03-21 12:07:39 --> Config Class Initialized
INFO - 2018-03-21 12:07:39 --> Loader Class Initialized
INFO - 2018-03-21 12:07:39 --> Config Class Initialized
INFO - 2018-03-21 12:07:39 --> Hooks Class Initialized
INFO - 2018-03-21 17:37:39 --> Helper loaded: url_helper
INFO - 2018-03-21 17:37:39 --> Helper loaded: notification_helper
DEBUG - 2018-03-21 12:07:39 --> UTF-8 Support Enabled
INFO - 2018-03-21 12:07:39 --> Utf8 Class Initialized
INFO - 2018-03-21 17:37:39 --> Helper loaded: settings_helper
INFO - 2018-03-21 17:37:39 --> Helper loaded: permission_helper
INFO - 2018-03-21 17:37:39 --> Helper loaded: users_helper
INFO - 2018-03-21 12:07:39 --> URI Class Initialized
INFO - 2018-03-21 12:07:39 --> Router Class Initialized
INFO - 2018-03-21 12:07:39 --> Output Class Initialized
INFO - 2018-03-21 12:07:39 --> Security Class Initialized
DEBUG - 2018-03-21 12:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 12:07:39 --> Input Class Initialized
INFO - 2018-03-21 12:07:39 --> Language Class Initialized
INFO - 2018-03-21 17:37:39 --> Database Driver Class Initialized
DEBUG - 2018-03-21 17:37:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 17:37:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 17:37:39 --> Helper loaded: form_helper
INFO - 2018-03-21 17:37:39 --> Form Validation Class Initialized
INFO - 2018-03-21 17:37:39 --> Controller Class Initialized
INFO - 2018-03-21 12:07:39 --> Language Class Initialized
INFO - 2018-03-21 12:07:39 --> Config Class Initialized
INFO - 2018-03-21 12:07:39 --> Loader Class Initialized
INFO - 2018-03-21 17:37:39 --> Helper loaded: url_helper
INFO - 2018-03-21 17:37:39 --> Helper loaded: notification_helper
INFO - 2018-03-21 17:37:39 --> Helper loaded: settings_helper
INFO - 2018-03-21 17:37:39 --> Helper loaded: permission_helper
INFO - 2018-03-21 17:37:39 --> Helper loaded: users_helper
INFO - 2018-03-21 17:37:39 --> Model Class Initialized
INFO - 2018-03-21 17:37:39 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 17:37:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 17:37:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 17:37:40 --> Model Class Initialized
INFO - 2018-03-21 17:37:40 --> Model Class Initialized
INFO - 2018-03-21 17:37:40 --> Model Class Initialized
INFO - 2018-03-21 17:37:40 --> Model Class Initialized
INFO - 2018-03-21 17:37:40 --> Model Class Initialized
INFO - 2018-03-21 17:37:40 --> Model Class Initialized
INFO - 2018-03-21 17:37:40 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-21 17:37:40 --> Database Driver Class Initialized
ERROR - 2018-03-21 17:37:40 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-03-21 17:37:40 --> Final output sent to browser
DEBUG - 2018-03-21 17:37:40 --> Total execution time: 0.2748
DEBUG - 2018-03-21 17:37:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 17:37:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 17:37:40 --> Helper loaded: form_helper
INFO - 2018-03-21 17:37:40 --> Form Validation Class Initialized
INFO - 2018-03-21 17:37:40 --> Controller Class Initialized
INFO - 2018-03-21 17:37:40 --> Model Class Initialized
INFO - 2018-03-21 17:37:40 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 17:37:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 17:37:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 17:37:40 --> Model Class Initialized
INFO - 2018-03-21 17:37:40 --> Model Class Initialized
INFO - 2018-03-21 17:37:40 --> Model Class Initialized
INFO - 2018-03-21 17:37:40 --> Model Class Initialized
INFO - 2018-03-21 17:37:40 --> Model Class Initialized
INFO - 2018-03-21 17:37:40 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-21 17:37:40 --> Model Class Initialized
INFO - 2018-03-21 17:37:40 --> Final output sent to browser
DEBUG - 2018-03-21 17:37:40 --> Total execution time: 0.2228
INFO - 2018-03-21 12:07:52 --> Config Class Initialized
INFO - 2018-03-21 12:07:52 --> Hooks Class Initialized
DEBUG - 2018-03-21 12:07:52 --> UTF-8 Support Enabled
INFO - 2018-03-21 12:07:52 --> Utf8 Class Initialized
INFO - 2018-03-21 12:07:52 --> URI Class Initialized
INFO - 2018-03-21 12:07:52 --> Router Class Initialized
INFO - 2018-03-21 12:07:52 --> Output Class Initialized
INFO - 2018-03-21 12:07:52 --> Security Class Initialized
DEBUG - 2018-03-21 12:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 12:07:52 --> Input Class Initialized
INFO - 2018-03-21 12:07:52 --> Language Class Initialized
INFO - 2018-03-21 12:07:52 --> Language Class Initialized
INFO - 2018-03-21 12:07:52 --> Config Class Initialized
INFO - 2018-03-21 12:07:52 --> Loader Class Initialized
INFO - 2018-03-21 17:37:52 --> Helper loaded: url_helper
INFO - 2018-03-21 17:37:52 --> Helper loaded: notification_helper
INFO - 2018-03-21 17:37:52 --> Helper loaded: settings_helper
INFO - 2018-03-21 17:37:52 --> Helper loaded: permission_helper
INFO - 2018-03-21 17:37:52 --> Helper loaded: users_helper
INFO - 2018-03-21 17:37:52 --> Database Driver Class Initialized
DEBUG - 2018-03-21 17:37:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 17:37:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 17:37:52 --> Helper loaded: form_helper
INFO - 2018-03-21 17:37:52 --> Form Validation Class Initialized
INFO - 2018-03-21 17:37:52 --> Controller Class Initialized
INFO - 2018-03-21 17:37:52 --> Model Class Initialized
INFO - 2018-03-21 17:37:52 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 17:37:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 17:37:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 17:37:52 --> Model Class Initialized
INFO - 2018-03-21 17:37:52 --> Model Class Initialized
INFO - 2018-03-21 17:37:52 --> Model Class Initialized
INFO - 2018-03-21 17:37:52 --> Model Class Initialized
INFO - 2018-03-21 17:37:52 --> Model Class Initialized
INFO - 2018-03-21 17:37:52 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-21 17:37:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-21 17:37:52 --> Final output sent to browser
DEBUG - 2018-03-21 17:37:52 --> Total execution time: 0.1135
INFO - 2018-03-21 12:07:53 --> Config Class Initialized
INFO - 2018-03-21 12:07:53 --> Hooks Class Initialized
DEBUG - 2018-03-21 12:07:53 --> UTF-8 Support Enabled
INFO - 2018-03-21 12:07:53 --> Utf8 Class Initialized
INFO - 2018-03-21 12:07:53 --> URI Class Initialized
INFO - 2018-03-21 12:07:53 --> Router Class Initialized
INFO - 2018-03-21 12:07:53 --> Output Class Initialized
INFO - 2018-03-21 12:07:53 --> Security Class Initialized
DEBUG - 2018-03-21 12:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 12:07:53 --> Input Class Initialized
INFO - 2018-03-21 12:07:53 --> Language Class Initialized
INFO - 2018-03-21 12:07:53 --> Language Class Initialized
INFO - 2018-03-21 12:07:53 --> Config Class Initialized
INFO - 2018-03-21 12:07:53 --> Loader Class Initialized
INFO - 2018-03-21 17:37:53 --> Helper loaded: url_helper
INFO - 2018-03-21 17:37:53 --> Helper loaded: notification_helper
INFO - 2018-03-21 17:37:53 --> Helper loaded: settings_helper
INFO - 2018-03-21 17:37:53 --> Helper loaded: permission_helper
INFO - 2018-03-21 17:37:53 --> Helper loaded: users_helper
INFO - 2018-03-21 17:37:53 --> Database Driver Class Initialized
DEBUG - 2018-03-21 17:37:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 17:37:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 17:37:53 --> Helper loaded: form_helper
INFO - 2018-03-21 17:37:53 --> Form Validation Class Initialized
INFO - 2018-03-21 17:37:53 --> Controller Class Initialized
INFO - 2018-03-21 17:37:53 --> Model Class Initialized
INFO - 2018-03-21 17:37:53 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 17:37:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 17:37:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 17:37:53 --> Model Class Initialized
INFO - 2018-03-21 17:37:53 --> Model Class Initialized
INFO - 2018-03-21 17:37:53 --> Model Class Initialized
INFO - 2018-03-21 17:37:53 --> Model Class Initialized
INFO - 2018-03-21 17:37:53 --> Model Class Initialized
INFO - 2018-03-21 17:37:53 --> Model Class Initialized
INFO - 2018-03-21 17:37:53 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-21 17:37:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-03-21 17:37:53 --> Final output sent to browser
DEBUG - 2018-03-21 17:37:54 --> Total execution time: 0.2633
INFO - 2018-03-21 12:07:54 --> Config Class Initialized
INFO - 2018-03-21 12:07:54 --> Hooks Class Initialized
DEBUG - 2018-03-21 12:07:54 --> UTF-8 Support Enabled
INFO - 2018-03-21 12:07:54 --> Utf8 Class Initialized
INFO - 2018-03-21 12:07:54 --> URI Class Initialized
INFO - 2018-03-21 12:07:54 --> Router Class Initialized
INFO - 2018-03-21 12:07:54 --> Config Class Initialized
INFO - 2018-03-21 12:07:54 --> Hooks Class Initialized
DEBUG - 2018-03-21 12:07:54 --> UTF-8 Support Enabled
INFO - 2018-03-21 12:07:54 --> Utf8 Class Initialized
INFO - 2018-03-21 12:07:54 --> URI Class Initialized
INFO - 2018-03-21 12:07:54 --> Output Class Initialized
INFO - 2018-03-21 12:07:54 --> Router Class Initialized
INFO - 2018-03-21 12:07:54 --> Output Class Initialized
INFO - 2018-03-21 12:07:54 --> Security Class Initialized
DEBUG - 2018-03-21 12:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 12:07:54 --> Input Class Initialized
INFO - 2018-03-21 12:07:54 --> Language Class Initialized
INFO - 2018-03-21 12:07:54 --> Security Class Initialized
INFO - 2018-03-21 12:07:54 --> Language Class Initialized
INFO - 2018-03-21 12:07:54 --> Config Class Initialized
INFO - 2018-03-21 12:07:54 --> Loader Class Initialized
INFO - 2018-03-21 17:37:54 --> Helper loaded: url_helper
INFO - 2018-03-21 17:37:54 --> Helper loaded: notification_helper
INFO - 2018-03-21 17:37:54 --> Helper loaded: settings_helper
INFO - 2018-03-21 17:37:54 --> Helper loaded: permission_helper
INFO - 2018-03-21 17:37:54 --> Helper loaded: users_helper
INFO - 2018-03-21 17:37:54 --> Database Driver Class Initialized
DEBUG - 2018-03-21 17:37:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 17:37:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 17:37:54 --> Helper loaded: form_helper
INFO - 2018-03-21 17:37:54 --> Form Validation Class Initialized
INFO - 2018-03-21 17:37:54 --> Controller Class Initialized
INFO - 2018-03-21 17:37:55 --> Model Class Initialized
INFO - 2018-03-21 17:37:55 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 17:37:55 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 17:37:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 17:37:55 --> Model Class Initialized
INFO - 2018-03-21 17:37:55 --> Model Class Initialized
INFO - 2018-03-21 17:37:55 --> Model Class Initialized
INFO - 2018-03-21 17:37:55 --> Model Class Initialized
INFO - 2018-03-21 17:37:55 --> Model Class Initialized
INFO - 2018-03-21 17:37:55 --> Model Class Initialized
INFO - 2018-03-21 17:37:55 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-21 17:37:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-03-21 17:37:55 --> Final output sent to browser
DEBUG - 2018-03-21 17:37:55 --> Total execution time: 0.3472
DEBUG - 2018-03-21 12:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 12:07:55 --> Input Class Initialized
INFO - 2018-03-21 12:07:55 --> Language Class Initialized
INFO - 2018-03-21 12:07:55 --> Language Class Initialized
INFO - 2018-03-21 12:07:55 --> Config Class Initialized
INFO - 2018-03-21 12:07:55 --> Loader Class Initialized
INFO - 2018-03-21 17:37:55 --> Helper loaded: url_helper
INFO - 2018-03-21 17:37:55 --> Helper loaded: notification_helper
INFO - 2018-03-21 17:37:55 --> Helper loaded: settings_helper
INFO - 2018-03-21 17:37:55 --> Helper loaded: permission_helper
INFO - 2018-03-21 17:37:55 --> Helper loaded: users_helper
INFO - 2018-03-21 17:37:56 --> Database Driver Class Initialized
DEBUG - 2018-03-21 17:37:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 17:37:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 17:37:56 --> Helper loaded: form_helper
INFO - 2018-03-21 17:37:56 --> Form Validation Class Initialized
INFO - 2018-03-21 17:37:56 --> Controller Class Initialized
INFO - 2018-03-21 17:37:56 --> Model Class Initialized
INFO - 2018-03-21 17:37:56 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 17:37:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 17:37:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 17:37:56 --> Model Class Initialized
INFO - 2018-03-21 17:37:56 --> Model Class Initialized
INFO - 2018-03-21 17:37:56 --> Model Class Initialized
INFO - 2018-03-21 17:37:56 --> Model Class Initialized
INFO - 2018-03-21 17:37:56 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-21 17:37:56 --> Final output sent to browser
DEBUG - 2018-03-21 17:37:56 --> Total execution time: 1.6615
INFO - 2018-03-21 12:07:57 --> Config Class Initialized
INFO - 2018-03-21 12:07:57 --> Hooks Class Initialized
DEBUG - 2018-03-21 12:07:57 --> UTF-8 Support Enabled
INFO - 2018-03-21 12:07:57 --> Utf8 Class Initialized
INFO - 2018-03-21 12:07:57 --> URI Class Initialized
INFO - 2018-03-21 12:07:57 --> Router Class Initialized
INFO - 2018-03-21 12:07:57 --> Output Class Initialized
INFO - 2018-03-21 12:07:57 --> Security Class Initialized
DEBUG - 2018-03-21 12:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 12:07:57 --> Input Class Initialized
INFO - 2018-03-21 12:07:57 --> Language Class Initialized
INFO - 2018-03-21 12:07:58 --> Language Class Initialized
INFO - 2018-03-21 12:07:58 --> Config Class Initialized
INFO - 2018-03-21 12:07:58 --> Loader Class Initialized
INFO - 2018-03-21 12:07:58 --> Config Class Initialized
INFO - 2018-03-21 12:07:58 --> Hooks Class Initialized
INFO - 2018-03-21 17:37:58 --> Helper loaded: url_helper
INFO - 2018-03-21 17:37:58 --> Helper loaded: notification_helper
INFO - 2018-03-21 17:37:58 --> Helper loaded: settings_helper
DEBUG - 2018-03-21 12:07:58 --> UTF-8 Support Enabled
INFO - 2018-03-21 12:07:58 --> Utf8 Class Initialized
INFO - 2018-03-21 17:37:58 --> Helper loaded: permission_helper
INFO - 2018-03-21 17:37:58 --> Helper loaded: users_helper
INFO - 2018-03-21 12:07:58 --> URI Class Initialized
INFO - 2018-03-21 17:37:58 --> Database Driver Class Initialized
INFO - 2018-03-21 12:07:58 --> Router Class Initialized
DEBUG - 2018-03-21 17:37:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 17:37:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 17:37:58 --> Helper loaded: form_helper
INFO - 2018-03-21 17:37:58 --> Form Validation Class Initialized
INFO - 2018-03-21 17:37:58 --> Controller Class Initialized
INFO - 2018-03-21 17:37:58 --> Model Class Initialized
INFO - 2018-03-21 17:37:58 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 17:37:58 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 17:37:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 17:37:58 --> Model Class Initialized
INFO - 2018-03-21 17:37:58 --> Model Class Initialized
INFO - 2018-03-21 12:07:58 --> Output Class Initialized
INFO - 2018-03-21 17:37:58 --> Model Class Initialized
INFO - 2018-03-21 17:37:58 --> Model Class Initialized
INFO - 2018-03-21 17:37:58 --> Model Class Initialized
INFO - 2018-03-21 17:37:58 --> Model Class Initialized
INFO - 2018-03-21 17:37:58 --> Model Class Initialized
INFO - 2018-03-21 17:37:58 --> Model Class Initialized
INFO - 2018-03-21 17:37:58 --> Model Class Initialized
INFO - 2018-03-21 17:37:58 --> Model Class Initialized
INFO - 2018-03-21 17:37:58 --> Model Class Initialized
INFO - 2018-03-21 17:37:58 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-21 17:37:58 --> Model Class Initialized
INFO - 2018-03-21 17:37:58 --> Final output sent to browser
DEBUG - 2018-03-21 17:37:58 --> Total execution time: 1.4239
INFO - 2018-03-21 12:07:58 --> Security Class Initialized
DEBUG - 2018-03-21 12:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 12:07:58 --> Input Class Initialized
INFO - 2018-03-21 12:07:58 --> Language Class Initialized
INFO - 2018-03-21 12:07:59 --> Config Class Initialized
INFO - 2018-03-21 12:07:59 --> Hooks Class Initialized
DEBUG - 2018-03-21 12:07:59 --> UTF-8 Support Enabled
INFO - 2018-03-21 12:07:59 --> Utf8 Class Initialized
INFO - 2018-03-21 12:07:59 --> URI Class Initialized
INFO - 2018-03-21 12:07:59 --> Router Class Initialized
INFO - 2018-03-21 12:07:59 --> Output Class Initialized
INFO - 2018-03-21 12:07:59 --> Security Class Initialized
DEBUG - 2018-03-21 12:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 12:07:59 --> Input Class Initialized
INFO - 2018-03-21 12:07:59 --> Language Class Initialized
INFO - 2018-03-21 12:07:59 --> Language Class Initialized
INFO - 2018-03-21 12:07:59 --> Config Class Initialized
INFO - 2018-03-21 12:07:59 --> Loader Class Initialized
INFO - 2018-03-21 17:37:59 --> Helper loaded: url_helper
INFO - 2018-03-21 12:07:59 --> Language Class Initialized
INFO - 2018-03-21 12:07:59 --> Config Class Initialized
INFO - 2018-03-21 12:07:59 --> Loader Class Initialized
INFO - 2018-03-21 17:37:59 --> Helper loaded: notification_helper
INFO - 2018-03-21 17:37:59 --> Helper loaded: settings_helper
INFO - 2018-03-21 17:37:59 --> Helper loaded: permission_helper
INFO - 2018-03-21 17:37:59 --> Helper loaded: users_helper
INFO - 2018-03-21 17:37:59 --> Helper loaded: url_helper
INFO - 2018-03-21 17:37:59 --> Helper loaded: notification_helper
INFO - 2018-03-21 17:37:59 --> Helper loaded: settings_helper
INFO - 2018-03-21 17:37:59 --> Helper loaded: permission_helper
INFO - 2018-03-21 17:37:59 --> Helper loaded: users_helper
INFO - 2018-03-21 17:37:59 --> Database Driver Class Initialized
DEBUG - 2018-03-21 17:38:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 17:38:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 17:38:00 --> Database Driver Class Initialized
DEBUG - 2018-03-21 17:38:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 17:38:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 17:38:00 --> Helper loaded: form_helper
INFO - 2018-03-21 17:38:00 --> Form Validation Class Initialized
INFO - 2018-03-21 17:38:00 --> Controller Class Initialized
INFO - 2018-03-21 17:38:00 --> Helper loaded: form_helper
INFO - 2018-03-21 17:38:00 --> Form Validation Class Initialized
INFO - 2018-03-21 17:38:00 --> Controller Class Initialized
INFO - 2018-03-21 17:38:00 --> Model Class Initialized
INFO - 2018-03-21 17:38:00 --> Helper loaded: inflector_helper
INFO - 2018-03-21 17:38:00 --> Model Class Initialized
INFO - 2018-03-21 17:38:00 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 17:38:00 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 17:38:00 --> Language file loaded: language/english/rest_controller_lang.php
DEBUG - 2018-03-21 17:38:00 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 17:38:00 --> Model Class Initialized
INFO - 2018-03-21 17:38:00 --> Model Class Initialized
INFO - 2018-03-21 17:38:00 --> Model Class Initialized
INFO - 2018-03-21 17:38:00 --> Model Class Initialized
INFO - 2018-03-21 17:38:00 --> Model Class Initialized
INFO - 2018-03-21 17:38:00 --> Model Class Initialized
INFO - 2018-03-21 17:38:00 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-21 17:38:00 --> Model Class Initialized
INFO - 2018-03-21 17:38:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 17:38:00 --> Final output sent to browser
DEBUG - 2018-03-21 17:38:00 --> Total execution time: 1.7794
INFO - 2018-03-21 17:38:00 --> Model Class Initialized
INFO - 2018-03-21 17:38:00 --> Model Class Initialized
INFO - 2018-03-21 17:38:00 --> Model Class Initialized
INFO - 2018-03-21 17:38:01 --> Model Class Initialized
INFO - 2018-03-21 17:38:01 --> Model Class Initialized
INFO - 2018-03-21 17:38:01 --> Model Class Initialized
INFO - 2018-03-21 17:38:01 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-21 17:38:01 --> Model Class Initialized
INFO - 2018-03-21 17:38:01 --> Final output sent to browser
DEBUG - 2018-03-21 17:38:01 --> Total execution time: 3.0252
INFO - 2018-03-21 12:08:02 --> Config Class Initialized
INFO - 2018-03-21 12:08:02 --> Hooks Class Initialized
DEBUG - 2018-03-21 12:08:02 --> UTF-8 Support Enabled
INFO - 2018-03-21 12:08:02 --> Utf8 Class Initialized
INFO - 2018-03-21 12:08:02 --> URI Class Initialized
INFO - 2018-03-21 12:08:02 --> Router Class Initialized
INFO - 2018-03-21 12:08:02 --> Output Class Initialized
INFO - 2018-03-21 12:08:02 --> Security Class Initialized
DEBUG - 2018-03-21 12:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 12:08:02 --> Input Class Initialized
INFO - 2018-03-21 12:08:02 --> Language Class Initialized
INFO - 2018-03-21 12:08:02 --> Config Class Initialized
INFO - 2018-03-21 12:08:02 --> Hooks Class Initialized
DEBUG - 2018-03-21 12:08:02 --> UTF-8 Support Enabled
INFO - 2018-03-21 12:08:02 --> Utf8 Class Initialized
INFO - 2018-03-21 12:08:02 --> URI Class Initialized
INFO - 2018-03-21 12:08:02 --> Router Class Initialized
INFO - 2018-03-21 12:08:02 --> Output Class Initialized
INFO - 2018-03-21 12:08:02 --> Security Class Initialized
DEBUG - 2018-03-21 12:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 12:08:02 --> Input Class Initialized
INFO - 2018-03-21 12:08:02 --> Language Class Initialized
INFO - 2018-03-21 12:08:02 --> Language Class Initialized
INFO - 2018-03-21 12:08:02 --> Config Class Initialized
INFO - 2018-03-21 12:08:02 --> Loader Class Initialized
INFO - 2018-03-21 17:38:02 --> Helper loaded: url_helper
INFO - 2018-03-21 17:38:02 --> Helper loaded: notification_helper
INFO - 2018-03-21 17:38:02 --> Helper loaded: settings_helper
INFO - 2018-03-21 17:38:02 --> Helper loaded: permission_helper
INFO - 2018-03-21 17:38:02 --> Helper loaded: users_helper
INFO - 2018-03-21 12:08:02 --> Language Class Initialized
INFO - 2018-03-21 12:08:02 --> Config Class Initialized
INFO - 2018-03-21 12:08:02 --> Loader Class Initialized
INFO - 2018-03-21 17:38:02 --> Database Driver Class Initialized
INFO - 2018-03-21 17:38:02 --> Helper loaded: url_helper
DEBUG - 2018-03-21 17:38:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 17:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 17:38:02 --> Helper loaded: notification_helper
INFO - 2018-03-21 17:38:02 --> Helper loaded: settings_helper
INFO - 2018-03-21 17:38:02 --> Helper loaded: permission_helper
INFO - 2018-03-21 17:38:02 --> Helper loaded: users_helper
INFO - 2018-03-21 17:38:02 --> Helper loaded: form_helper
INFO - 2018-03-21 17:38:02 --> Form Validation Class Initialized
INFO - 2018-03-21 17:38:02 --> Controller Class Initialized
INFO - 2018-03-21 17:38:02 --> Model Class Initialized
INFO - 2018-03-21 17:38:02 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 17:38:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 17:38:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 17:38:02 --> Model Class Initialized
INFO - 2018-03-21 17:38:02 --> Model Class Initialized
INFO - 2018-03-21 17:38:02 --> Model Class Initialized
INFO - 2018-03-21 17:38:02 --> Model Class Initialized
INFO - 2018-03-21 17:38:02 --> Model Class Initialized
INFO - 2018-03-21 17:38:02 --> Model Class Initialized
INFO - 2018-03-21 17:38:02 --> Model Class Initialized
INFO - 2018-03-21 17:38:02 --> Model Class Initialized
INFO - 2018-03-21 17:38:02 --> Model Class Initialized
INFO - 2018-03-21 17:38:02 --> Model Class Initialized
INFO - 2018-03-21 17:38:02 --> Model Class Initialized
INFO - 2018-03-21 17:38:02 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-21 17:38:02 --> Model Class Initialized
INFO - 2018-03-21 17:38:02 --> Final output sent to browser
DEBUG - 2018-03-21 17:38:02 --> Total execution time: 0.0813
INFO - 2018-03-21 17:38:02 --> Database Driver Class Initialized
DEBUG - 2018-03-21 17:38:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 17:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 17:38:02 --> Helper loaded: form_helper
INFO - 2018-03-21 17:38:02 --> Form Validation Class Initialized
INFO - 2018-03-21 17:38:02 --> Controller Class Initialized
INFO - 2018-03-21 17:38:02 --> Model Class Initialized
INFO - 2018-03-21 17:38:02 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 17:38:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 17:38:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 17:38:02 --> Model Class Initialized
INFO - 2018-03-21 17:38:02 --> Model Class Initialized
INFO - 2018-03-21 17:38:02 --> Model Class Initialized
INFO - 2018-03-21 17:38:02 --> Model Class Initialized
INFO - 2018-03-21 17:38:02 --> Model Class Initialized
INFO - 2018-03-21 17:38:02 --> Model Class Initialized
INFO - 2018-03-21 17:38:02 --> Model Class Initialized
INFO - 2018-03-21 17:38:02 --> Model Class Initialized
INFO - 2018-03-21 17:38:02 --> Model Class Initialized
INFO - 2018-03-21 17:38:02 --> Model Class Initialized
INFO - 2018-03-21 17:38:02 --> Model Class Initialized
INFO - 2018-03-21 17:38:02 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-21 17:38:02 --> Final output sent to browser
DEBUG - 2018-03-21 17:38:02 --> Total execution time: 0.2012
INFO - 2018-03-21 12:08:04 --> Config Class Initialized
INFO - 2018-03-21 12:08:04 --> Hooks Class Initialized
DEBUG - 2018-03-21 12:08:04 --> UTF-8 Support Enabled
INFO - 2018-03-21 12:08:04 --> Utf8 Class Initialized
INFO - 2018-03-21 12:08:04 --> URI Class Initialized
INFO - 2018-03-21 12:08:04 --> Router Class Initialized
INFO - 2018-03-21 12:08:04 --> Output Class Initialized
INFO - 2018-03-21 12:08:04 --> Security Class Initialized
DEBUG - 2018-03-21 12:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 12:08:04 --> Input Class Initialized
INFO - 2018-03-21 12:08:04 --> Language Class Initialized
INFO - 2018-03-21 12:08:04 --> Language Class Initialized
INFO - 2018-03-21 12:08:04 --> Config Class Initialized
INFO - 2018-03-21 12:08:04 --> Loader Class Initialized
INFO - 2018-03-21 17:38:04 --> Helper loaded: url_helper
INFO - 2018-03-21 17:38:04 --> Helper loaded: notification_helper
INFO - 2018-03-21 17:38:04 --> Helper loaded: settings_helper
INFO - 2018-03-21 17:38:04 --> Helper loaded: permission_helper
INFO - 2018-03-21 17:38:04 --> Helper loaded: users_helper
INFO - 2018-03-21 17:38:04 --> Database Driver Class Initialized
DEBUG - 2018-03-21 17:38:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 17:38:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 17:38:04 --> Helper loaded: form_helper
INFO - 2018-03-21 17:38:04 --> Form Validation Class Initialized
INFO - 2018-03-21 17:38:04 --> Controller Class Initialized
INFO - 2018-03-21 17:38:04 --> Model Class Initialized
INFO - 2018-03-21 17:38:04 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 17:38:04 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 17:38:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 17:38:04 --> Model Class Initialized
INFO - 2018-03-21 17:38:04 --> Model Class Initialized
INFO - 2018-03-21 17:38:04 --> Model Class Initialized
INFO - 2018-03-21 17:38:04 --> Model Class Initialized
INFO - 2018-03-21 17:38:04 --> Model Class Initialized
INFO - 2018-03-21 17:38:04 --> Model Class Initialized
INFO - 2018-03-21 17:38:04 --> Model Class Initialized
INFO - 2018-03-21 17:38:04 --> Model Class Initialized
INFO - 2018-03-21 17:38:04 --> Model Class Initialized
INFO - 2018-03-21 17:38:04 --> Model Class Initialized
INFO - 2018-03-21 17:38:04 --> Model Class Initialized
INFO - 2018-03-21 17:38:04 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-21 17:38:04 --> Final output sent to browser
DEBUG - 2018-03-21 17:38:04 --> Total execution time: 0.2109
INFO - 2018-03-21 12:08:07 --> Config Class Initialized
INFO - 2018-03-21 12:08:07 --> Hooks Class Initialized
DEBUG - 2018-03-21 12:08:07 --> UTF-8 Support Enabled
INFO - 2018-03-21 12:08:07 --> Utf8 Class Initialized
INFO - 2018-03-21 12:08:07 --> URI Class Initialized
INFO - 2018-03-21 12:08:07 --> Router Class Initialized
INFO - 2018-03-21 12:08:07 --> Config Class Initialized
INFO - 2018-03-21 12:08:07 --> Hooks Class Initialized
DEBUG - 2018-03-21 12:08:08 --> UTF-8 Support Enabled
INFO - 2018-03-21 12:08:08 --> Utf8 Class Initialized
INFO - 2018-03-21 12:08:08 --> URI Class Initialized
INFO - 2018-03-21 12:08:08 --> Output Class Initialized
INFO - 2018-03-21 12:08:08 --> Router Class Initialized
INFO - 2018-03-21 12:08:08 --> Output Class Initialized
INFO - 2018-03-21 12:08:08 --> Security Class Initialized
DEBUG - 2018-03-21 12:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 12:08:08 --> Input Class Initialized
INFO - 2018-03-21 12:08:08 --> Language Class Initialized
INFO - 2018-03-21 12:08:08 --> Security Class Initialized
INFO - 2018-03-21 12:08:08 --> Language Class Initialized
INFO - 2018-03-21 12:08:08 --> Config Class Initialized
INFO - 2018-03-21 12:08:08 --> Loader Class Initialized
INFO - 2018-03-21 17:38:08 --> Helper loaded: url_helper
INFO - 2018-03-21 17:38:08 --> Helper loaded: notification_helper
INFO - 2018-03-21 17:38:08 --> Helper loaded: settings_helper
INFO - 2018-03-21 17:38:08 --> Helper loaded: permission_helper
INFO - 2018-03-21 17:38:08 --> Helper loaded: users_helper
INFO - 2018-03-21 17:38:08 --> Database Driver Class Initialized
DEBUG - 2018-03-21 17:38:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 17:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 17:38:08 --> Helper loaded: form_helper
INFO - 2018-03-21 17:38:08 --> Form Validation Class Initialized
INFO - 2018-03-21 17:38:08 --> Controller Class Initialized
INFO - 2018-03-21 17:38:08 --> Model Class Initialized
INFO - 2018-03-21 17:38:08 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 17:38:08 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-03-21 12:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 12:08:08 --> Input Class Initialized
INFO - 2018-03-21 17:38:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 17:38:08 --> Model Class Initialized
INFO - 2018-03-21 17:38:08 --> Model Class Initialized
INFO - 2018-03-21 17:38:08 --> Model Class Initialized
INFO - 2018-03-21 17:38:08 --> Model Class Initialized
INFO - 2018-03-21 17:38:08 --> Model Class Initialized
INFO - 2018-03-21 17:38:08 --> Model Class Initialized
INFO - 2018-03-21 17:38:08 --> Model Class Initialized
INFO - 2018-03-21 17:38:08 --> Model Class Initialized
INFO - 2018-03-21 17:38:08 --> Model Class Initialized
INFO - 2018-03-21 17:38:08 --> Model Class Initialized
INFO - 2018-03-21 17:38:08 --> Model Class Initialized
INFO - 2018-03-21 17:38:08 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-21 17:38:08 --> Model Class Initialized
INFO - 2018-03-21 17:38:08 --> Final output sent to browser
DEBUG - 2018-03-21 17:38:08 --> Total execution time: 0.4071
INFO - 2018-03-21 12:08:08 --> Language Class Initialized
INFO - 2018-03-21 12:08:08 --> Language Class Initialized
INFO - 2018-03-21 12:08:08 --> Config Class Initialized
INFO - 2018-03-21 12:08:08 --> Loader Class Initialized
INFO - 2018-03-21 17:38:08 --> Helper loaded: url_helper
INFO - 2018-03-21 17:38:08 --> Helper loaded: notification_helper
INFO - 2018-03-21 17:38:08 --> Helper loaded: settings_helper
INFO - 2018-03-21 17:38:08 --> Helper loaded: permission_helper
INFO - 2018-03-21 17:38:08 --> Helper loaded: users_helper
INFO - 2018-03-21 17:38:08 --> Database Driver Class Initialized
DEBUG - 2018-03-21 17:38:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 17:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 17:38:08 --> Helper loaded: form_helper
INFO - 2018-03-21 17:38:08 --> Form Validation Class Initialized
INFO - 2018-03-21 17:38:08 --> Controller Class Initialized
INFO - 2018-03-21 17:38:08 --> Model Class Initialized
INFO - 2018-03-21 17:38:08 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 17:38:08 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 17:38:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 17:38:08 --> Model Class Initialized
INFO - 2018-03-21 17:38:08 --> Model Class Initialized
INFO - 2018-03-21 17:38:08 --> Model Class Initialized
INFO - 2018-03-21 17:38:08 --> Model Class Initialized
INFO - 2018-03-21 17:38:08 --> Model Class Initialized
INFO - 2018-03-21 17:38:08 --> Model Class Initialized
INFO - 2018-03-21 17:38:08 --> Model Class Initialized
INFO - 2018-03-21 17:38:08 --> Model Class Initialized
INFO - 2018-03-21 17:38:08 --> Model Class Initialized
INFO - 2018-03-21 17:38:08 --> Model Class Initialized
INFO - 2018-03-21 17:38:08 --> Model Class Initialized
INFO - 2018-03-21 17:38:08 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-21 17:38:08 --> Model Class Initialized
INFO - 2018-03-21 17:38:08 --> Final output sent to browser
DEBUG - 2018-03-21 17:38:08 --> Total execution time: 1.4345
INFO - 2018-03-21 12:08:11 --> Config Class Initialized
INFO - 2018-03-21 12:08:11 --> Hooks Class Initialized
DEBUG - 2018-03-21 12:08:11 --> UTF-8 Support Enabled
INFO - 2018-03-21 12:08:11 --> Utf8 Class Initialized
INFO - 2018-03-21 12:08:11 --> URI Class Initialized
INFO - 2018-03-21 12:08:11 --> Router Class Initialized
INFO - 2018-03-21 12:08:11 --> Output Class Initialized
INFO - 2018-03-21 12:08:11 --> Security Class Initialized
DEBUG - 2018-03-21 12:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 12:08:12 --> Input Class Initialized
INFO - 2018-03-21 12:08:12 --> Language Class Initialized
INFO - 2018-03-21 12:08:12 --> Language Class Initialized
INFO - 2018-03-21 12:08:12 --> Config Class Initialized
INFO - 2018-03-21 12:08:12 --> Loader Class Initialized
INFO - 2018-03-21 17:38:13 --> Helper loaded: url_helper
INFO - 2018-03-21 17:38:13 --> Helper loaded: notification_helper
INFO - 2018-03-21 17:38:13 --> Helper loaded: settings_helper
INFO - 2018-03-21 17:38:13 --> Helper loaded: permission_helper
INFO - 2018-03-21 17:38:13 --> Helper loaded: users_helper
INFO - 2018-03-21 17:38:13 --> Database Driver Class Initialized
DEBUG - 2018-03-21 17:38:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 17:38:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 17:38:13 --> Helper loaded: form_helper
INFO - 2018-03-21 17:38:13 --> Form Validation Class Initialized
INFO - 2018-03-21 17:38:13 --> Controller Class Initialized
INFO - 2018-03-21 17:38:13 --> Model Class Initialized
INFO - 2018-03-21 17:38:13 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 17:38:13 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 17:38:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 17:38:13 --> Model Class Initialized
INFO - 2018-03-21 17:38:13 --> Model Class Initialized
INFO - 2018-03-21 17:38:13 --> Model Class Initialized
INFO - 2018-03-21 17:38:13 --> Model Class Initialized
INFO - 2018-03-21 17:38:13 --> Model Class Initialized
INFO - 2018-03-21 17:38:13 --> Model Class Initialized
INFO - 2018-03-21 17:38:13 --> Model Class Initialized
INFO - 2018-03-21 17:38:13 --> Model Class Initialized
INFO - 2018-03-21 17:38:13 --> Model Class Initialized
INFO - 2018-03-21 17:38:13 --> Model Class Initialized
INFO - 2018-03-21 17:38:13 --> Model Class Initialized
INFO - 2018-03-21 17:38:13 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-21 17:38:13 --> Final output sent to browser
DEBUG - 2018-03-21 17:38:13 --> Total execution time: 2.2050
INFO - 2018-03-21 12:08:14 --> Config Class Initialized
INFO - 2018-03-21 12:08:14 --> Hooks Class Initialized
DEBUG - 2018-03-21 12:08:14 --> UTF-8 Support Enabled
INFO - 2018-03-21 12:08:14 --> Utf8 Class Initialized
INFO - 2018-03-21 12:08:14 --> URI Class Initialized
INFO - 2018-03-21 12:08:15 --> Router Class Initialized
INFO - 2018-03-21 12:08:15 --> Output Class Initialized
INFO - 2018-03-21 12:08:15 --> Security Class Initialized
DEBUG - 2018-03-21 12:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 12:08:15 --> Input Class Initialized
INFO - 2018-03-21 12:08:15 --> Language Class Initialized
INFO - 2018-03-21 12:08:15 --> Language Class Initialized
INFO - 2018-03-21 12:08:15 --> Config Class Initialized
INFO - 2018-03-21 12:08:15 --> Loader Class Initialized
INFO - 2018-03-21 17:38:15 --> Helper loaded: url_helper
INFO - 2018-03-21 17:38:15 --> Helper loaded: notification_helper
INFO - 2018-03-21 17:38:15 --> Helper loaded: settings_helper
INFO - 2018-03-21 17:38:15 --> Helper loaded: permission_helper
INFO - 2018-03-21 17:38:15 --> Helper loaded: users_helper
INFO - 2018-03-21 17:38:15 --> Database Driver Class Initialized
DEBUG - 2018-03-21 17:38:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 17:38:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 17:38:15 --> Helper loaded: form_helper
INFO - 2018-03-21 17:38:15 --> Form Validation Class Initialized
INFO - 2018-03-21 17:38:15 --> Controller Class Initialized
INFO - 2018-03-21 17:38:15 --> Model Class Initialized
INFO - 2018-03-21 17:38:15 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 17:38:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 17:38:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 17:38:15 --> Model Class Initialized
INFO - 2018-03-21 17:38:15 --> Model Class Initialized
INFO - 2018-03-21 17:38:15 --> Model Class Initialized
INFO - 2018-03-21 17:38:15 --> Model Class Initialized
INFO - 2018-03-21 17:38:15 --> Model Class Initialized
INFO - 2018-03-21 17:38:15 --> Model Class Initialized
INFO - 2018-03-21 17:38:15 --> Model Class Initialized
INFO - 2018-03-21 17:38:15 --> Model Class Initialized
INFO - 2018-03-21 17:38:15 --> Model Class Initialized
INFO - 2018-03-21 17:38:15 --> Model Class Initialized
INFO - 2018-03-21 17:38:15 --> Model Class Initialized
INFO - 2018-03-21 17:38:15 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-21 17:38:15 --> Final output sent to browser
DEBUG - 2018-03-21 17:38:15 --> Total execution time: 1.2079
INFO - 2018-03-21 12:08:20 --> Config Class Initialized
INFO - 2018-03-21 12:08:20 --> Hooks Class Initialized
DEBUG - 2018-03-21 12:08:20 --> UTF-8 Support Enabled
INFO - 2018-03-21 12:08:20 --> Utf8 Class Initialized
INFO - 2018-03-21 12:08:20 --> URI Class Initialized
INFO - 2018-03-21 12:08:20 --> Router Class Initialized
INFO - 2018-03-21 12:08:20 --> Output Class Initialized
INFO - 2018-03-21 12:08:20 --> Security Class Initialized
DEBUG - 2018-03-21 12:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 12:08:20 --> Input Class Initialized
INFO - 2018-03-21 12:08:20 --> Language Class Initialized
INFO - 2018-03-21 12:08:20 --> Language Class Initialized
INFO - 2018-03-21 12:08:20 --> Config Class Initialized
INFO - 2018-03-21 12:08:20 --> Loader Class Initialized
INFO - 2018-03-21 17:38:20 --> Helper loaded: url_helper
INFO - 2018-03-21 17:38:20 --> Helper loaded: notification_helper
INFO - 2018-03-21 17:38:20 --> Helper loaded: settings_helper
INFO - 2018-03-21 17:38:20 --> Helper loaded: permission_helper
INFO - 2018-03-21 17:38:20 --> Helper loaded: users_helper
INFO - 2018-03-21 17:38:20 --> Database Driver Class Initialized
DEBUG - 2018-03-21 17:38:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 17:38:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 17:38:20 --> Helper loaded: form_helper
INFO - 2018-03-21 17:38:20 --> Form Validation Class Initialized
INFO - 2018-03-21 17:38:20 --> Controller Class Initialized
INFO - 2018-03-21 17:38:20 --> Model Class Initialized
INFO - 2018-03-21 17:38:20 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 17:38:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 17:38:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 17:38:20 --> Model Class Initialized
INFO - 2018-03-21 17:38:20 --> Model Class Initialized
INFO - 2018-03-21 17:38:20 --> Model Class Initialized
INFO - 2018-03-21 17:38:20 --> Model Class Initialized
INFO - 2018-03-21 17:38:20 --> Model Class Initialized
INFO - 2018-03-21 17:38:20 --> Model Class Initialized
INFO - 2018-03-21 17:38:20 --> Model Class Initialized
INFO - 2018-03-21 17:38:20 --> Model Class Initialized
INFO - 2018-03-21 17:38:20 --> Model Class Initialized
INFO - 2018-03-21 17:38:20 --> Model Class Initialized
INFO - 2018-03-21 17:38:20 --> Model Class Initialized
INFO - 2018-03-21 17:38:20 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-21 17:38:20 --> Final output sent to browser
DEBUG - 2018-03-21 17:38:20 --> Total execution time: 0.3642
INFO - 2018-03-21 12:08:22 --> Config Class Initialized
INFO - 2018-03-21 12:08:22 --> Hooks Class Initialized
DEBUG - 2018-03-21 12:08:22 --> UTF-8 Support Enabled
INFO - 2018-03-21 12:08:22 --> Utf8 Class Initialized
INFO - 2018-03-21 12:08:22 --> URI Class Initialized
INFO - 2018-03-21 12:08:22 --> Config Class Initialized
INFO - 2018-03-21 12:08:22 --> Hooks Class Initialized
DEBUG - 2018-03-21 12:08:22 --> UTF-8 Support Enabled
INFO - 2018-03-21 12:08:22 --> Utf8 Class Initialized
INFO - 2018-03-21 12:08:22 --> URI Class Initialized
INFO - 2018-03-21 12:08:22 --> Router Class Initialized
INFO - 2018-03-21 12:08:22 --> Router Class Initialized
INFO - 2018-03-21 12:08:22 --> Output Class Initialized
INFO - 2018-03-21 12:08:22 --> Output Class Initialized
INFO - 2018-03-21 12:08:22 --> Security Class Initialized
INFO - 2018-03-21 12:08:22 --> Security Class Initialized
DEBUG - 2018-03-21 12:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 12:08:22 --> Input Class Initialized
INFO - 2018-03-21 12:08:22 --> Language Class Initialized
DEBUG - 2018-03-21 12:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 12:08:22 --> Input Class Initialized
INFO - 2018-03-21 12:08:22 --> Language Class Initialized
INFO - 2018-03-21 12:08:22 --> Language Class Initialized
INFO - 2018-03-21 12:08:22 --> Config Class Initialized
INFO - 2018-03-21 12:08:22 --> Loader Class Initialized
INFO - 2018-03-21 17:38:22 --> Helper loaded: url_helper
INFO - 2018-03-21 12:08:22 --> Language Class Initialized
INFO - 2018-03-21 12:08:22 --> Config Class Initialized
INFO - 2018-03-21 12:08:22 --> Loader Class Initialized
INFO - 2018-03-21 17:38:22 --> Helper loaded: notification_helper
INFO - 2018-03-21 17:38:22 --> Helper loaded: settings_helper
INFO - 2018-03-21 17:38:22 --> Helper loaded: permission_helper
INFO - 2018-03-21 17:38:22 --> Helper loaded: url_helper
INFO - 2018-03-21 17:38:22 --> Helper loaded: users_helper
INFO - 2018-03-21 17:38:22 --> Helper loaded: notification_helper
INFO - 2018-03-21 17:38:22 --> Helper loaded: settings_helper
INFO - 2018-03-21 17:38:22 --> Helper loaded: permission_helper
INFO - 2018-03-21 17:38:22 --> Helper loaded: users_helper
INFO - 2018-03-21 17:38:22 --> Database Driver Class Initialized
DEBUG - 2018-03-21 17:38:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 17:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 17:38:22 --> Helper loaded: form_helper
INFO - 2018-03-21 17:38:22 --> Form Validation Class Initialized
INFO - 2018-03-21 17:38:22 --> Controller Class Initialized
INFO - 2018-03-21 17:38:22 --> Model Class Initialized
INFO - 2018-03-21 17:38:22 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 17:38:22 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 17:38:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 17:38:22 --> Model Class Initialized
INFO - 2018-03-21 17:38:22 --> Model Class Initialized
INFO - 2018-03-21 17:38:22 --> Model Class Initialized
INFO - 2018-03-21 17:38:22 --> Model Class Initialized
INFO - 2018-03-21 17:38:22 --> Model Class Initialized
INFO - 2018-03-21 17:38:22 --> Model Class Initialized
INFO - 2018-03-21 17:38:22 --> Model Class Initialized
INFO - 2018-03-21 17:38:22 --> Model Class Initialized
INFO - 2018-03-21 17:38:22 --> Model Class Initialized
INFO - 2018-03-21 17:38:22 --> Model Class Initialized
INFO - 2018-03-21 17:38:22 --> Model Class Initialized
INFO - 2018-03-21 17:38:22 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-21 17:38:22 --> Model Class Initialized
INFO - 2018-03-21 17:38:22 --> Final output sent to browser
DEBUG - 2018-03-21 17:38:22 --> Total execution time: 0.4147
INFO - 2018-03-21 17:38:22 --> Database Driver Class Initialized
DEBUG - 2018-03-21 17:38:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 17:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 17:38:22 --> Helper loaded: form_helper
INFO - 2018-03-21 17:38:22 --> Form Validation Class Initialized
INFO - 2018-03-21 17:38:22 --> Controller Class Initialized
INFO - 2018-03-21 17:38:22 --> Model Class Initialized
INFO - 2018-03-21 17:38:22 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 17:38:22 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 17:38:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 17:38:22 --> Model Class Initialized
INFO - 2018-03-21 17:38:22 --> Model Class Initialized
INFO - 2018-03-21 17:38:22 --> Model Class Initialized
INFO - 2018-03-21 17:38:22 --> Model Class Initialized
INFO - 2018-03-21 17:38:22 --> Model Class Initialized
INFO - 2018-03-21 17:38:22 --> Model Class Initialized
INFO - 2018-03-21 17:38:22 --> Model Class Initialized
INFO - 2018-03-21 17:38:22 --> Model Class Initialized
INFO - 2018-03-21 17:38:22 --> Model Class Initialized
INFO - 2018-03-21 17:38:22 --> Model Class Initialized
INFO - 2018-03-21 17:38:22 --> Model Class Initialized
INFO - 2018-03-21 17:38:22 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-21 17:38:22 --> Model Class Initialized
INFO - 2018-03-21 17:38:22 --> Final output sent to browser
DEBUG - 2018-03-21 17:38:22 --> Total execution time: 0.6798
INFO - 2018-03-21 12:08:26 --> Config Class Initialized
INFO - 2018-03-21 12:08:26 --> Hooks Class Initialized
DEBUG - 2018-03-21 12:08:26 --> UTF-8 Support Enabled
INFO - 2018-03-21 12:08:26 --> Utf8 Class Initialized
INFO - 2018-03-21 12:08:26 --> URI Class Initialized
INFO - 2018-03-21 12:08:26 --> Config Class Initialized
INFO - 2018-03-21 12:08:26 --> Hooks Class Initialized
DEBUG - 2018-03-21 12:08:26 --> UTF-8 Support Enabled
INFO - 2018-03-21 12:08:26 --> Utf8 Class Initialized
INFO - 2018-03-21 12:08:26 --> URI Class Initialized
INFO - 2018-03-21 12:08:26 --> Router Class Initialized
INFO - 2018-03-21 12:08:26 --> Router Class Initialized
INFO - 2018-03-21 12:08:26 --> Output Class Initialized
INFO - 2018-03-21 12:08:26 --> Security Class Initialized
DEBUG - 2018-03-21 12:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 12:08:26 --> Input Class Initialized
INFO - 2018-03-21 12:08:26 --> Language Class Initialized
INFO - 2018-03-21 12:08:26 --> Output Class Initialized
INFO - 2018-03-21 12:08:26 --> Language Class Initialized
INFO - 2018-03-21 12:08:26 --> Config Class Initialized
INFO - 2018-03-21 12:08:26 --> Loader Class Initialized
INFO - 2018-03-21 17:38:26 --> Helper loaded: url_helper
INFO - 2018-03-21 17:38:26 --> Helper loaded: notification_helper
INFO - 2018-03-21 17:38:26 --> Helper loaded: settings_helper
INFO - 2018-03-21 17:38:26 --> Helper loaded: permission_helper
INFO - 2018-03-21 17:38:26 --> Helper loaded: users_helper
INFO - 2018-03-21 12:08:26 --> Security Class Initialized
DEBUG - 2018-03-21 12:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 12:08:26 --> Input Class Initialized
INFO - 2018-03-21 12:08:26 --> Language Class Initialized
INFO - 2018-03-21 17:38:26 --> Database Driver Class Initialized
DEBUG - 2018-03-21 17:38:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 17:38:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 17:38:26 --> Helper loaded: form_helper
INFO - 2018-03-21 17:38:26 --> Form Validation Class Initialized
INFO - 2018-03-21 17:38:26 --> Controller Class Initialized
INFO - 2018-03-21 17:38:26 --> Model Class Initialized
INFO - 2018-03-21 17:38:26 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 17:38:26 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 17:38:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 17:38:26 --> Model Class Initialized
INFO - 2018-03-21 17:38:26 --> Model Class Initialized
INFO - 2018-03-21 17:38:26 --> Model Class Initialized
INFO - 2018-03-21 17:38:26 --> Model Class Initialized
INFO - 2018-03-21 17:38:26 --> Model Class Initialized
INFO - 2018-03-21 17:38:26 --> Model Class Initialized
INFO - 2018-03-21 17:38:26 --> Model Class Initialized
INFO - 2018-03-21 17:38:26 --> Model Class Initialized
INFO - 2018-03-21 17:38:26 --> Model Class Initialized
INFO - 2018-03-21 17:38:26 --> Model Class Initialized
INFO - 2018-03-21 17:38:26 --> Model Class Initialized
INFO - 2018-03-21 17:38:26 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-21 17:38:26 --> Model Class Initialized
INFO - 2018-03-21 17:38:26 --> Final output sent to browser
DEBUG - 2018-03-21 17:38:26 --> Total execution time: 0.6687
INFO - 2018-03-21 12:08:27 --> Language Class Initialized
INFO - 2018-03-21 12:08:27 --> Config Class Initialized
INFO - 2018-03-21 12:08:27 --> Loader Class Initialized
INFO - 2018-03-21 17:38:27 --> Helper loaded: url_helper
INFO - 2018-03-21 17:38:27 --> Helper loaded: notification_helper
INFO - 2018-03-21 17:38:27 --> Helper loaded: settings_helper
INFO - 2018-03-21 17:38:27 --> Helper loaded: permission_helper
INFO - 2018-03-21 17:38:27 --> Helper loaded: users_helper
INFO - 2018-03-21 17:38:28 --> Database Driver Class Initialized
DEBUG - 2018-03-21 17:38:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 17:38:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 17:38:28 --> Helper loaded: form_helper
INFO - 2018-03-21 17:38:28 --> Form Validation Class Initialized
INFO - 2018-03-21 17:38:28 --> Controller Class Initialized
INFO - 2018-03-21 17:38:28 --> Model Class Initialized
INFO - 2018-03-21 17:38:28 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 17:38:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 17:38:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 17:38:28 --> Model Class Initialized
INFO - 2018-03-21 17:38:28 --> Model Class Initialized
INFO - 2018-03-21 17:38:28 --> Model Class Initialized
INFO - 2018-03-21 17:38:28 --> Model Class Initialized
INFO - 2018-03-21 17:38:28 --> Model Class Initialized
INFO - 2018-03-21 17:38:28 --> Model Class Initialized
INFO - 2018-03-21 17:38:28 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-21 17:38:28 --> Model Class Initialized
INFO - 2018-03-21 17:38:28 --> Final output sent to browser
DEBUG - 2018-03-21 17:38:28 --> Total execution time: 2.3530
INFO - 2018-03-21 12:08:29 --> Config Class Initialized
INFO - 2018-03-21 12:08:29 --> Hooks Class Initialized
DEBUG - 2018-03-21 12:08:29 --> UTF-8 Support Enabled
INFO - 2018-03-21 12:08:29 --> Utf8 Class Initialized
INFO - 2018-03-21 12:08:29 --> URI Class Initialized
INFO - 2018-03-21 12:08:30 --> Router Class Initialized
INFO - 2018-03-21 12:08:30 --> Output Class Initialized
INFO - 2018-03-21 12:08:30 --> Security Class Initialized
DEBUG - 2018-03-21 12:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 12:08:30 --> Input Class Initialized
INFO - 2018-03-21 12:08:30 --> Language Class Initialized
INFO - 2018-03-21 12:08:30 --> Language Class Initialized
INFO - 2018-03-21 12:08:30 --> Config Class Initialized
INFO - 2018-03-21 12:08:30 --> Loader Class Initialized
INFO - 2018-03-21 17:38:30 --> Helper loaded: url_helper
INFO - 2018-03-21 17:38:30 --> Helper loaded: notification_helper
INFO - 2018-03-21 17:38:30 --> Helper loaded: settings_helper
INFO - 2018-03-21 17:38:30 --> Helper loaded: permission_helper
INFO - 2018-03-21 17:38:30 --> Helper loaded: users_helper
INFO - 2018-03-21 17:38:30 --> Database Driver Class Initialized
DEBUG - 2018-03-21 17:38:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 17:38:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 17:38:30 --> Helper loaded: form_helper
INFO - 2018-03-21 17:38:30 --> Form Validation Class Initialized
INFO - 2018-03-21 17:38:30 --> Controller Class Initialized
INFO - 2018-03-21 17:38:30 --> Model Class Initialized
INFO - 2018-03-21 17:38:30 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 17:38:30 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 17:38:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 17:38:30 --> Model Class Initialized
INFO - 2018-03-21 17:38:30 --> Model Class Initialized
INFO - 2018-03-21 17:38:30 --> Model Class Initialized
INFO - 2018-03-21 17:38:30 --> Model Class Initialized
INFO - 2018-03-21 17:38:30 --> Model Class Initialized
INFO - 2018-03-21 17:38:30 --> Model Class Initialized
INFO - 2018-03-21 17:38:30 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-21 17:38:30 --> Model Class Initialized
INFO - 2018-03-21 17:38:30 --> Final output sent to browser
DEBUG - 2018-03-21 17:38:30 --> Total execution time: 1.2473
INFO - 2018-03-21 12:11:46 --> Config Class Initialized
INFO - 2018-03-21 12:11:46 --> Hooks Class Initialized
DEBUG - 2018-03-21 12:11:46 --> UTF-8 Support Enabled
INFO - 2018-03-21 12:11:46 --> Utf8 Class Initialized
INFO - 2018-03-21 12:11:46 --> URI Class Initialized
INFO - 2018-03-21 12:11:46 --> Router Class Initialized
INFO - 2018-03-21 12:11:46 --> Output Class Initialized
INFO - 2018-03-21 12:11:46 --> Security Class Initialized
DEBUG - 2018-03-21 12:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 12:11:46 --> Input Class Initialized
INFO - 2018-03-21 12:11:46 --> Language Class Initialized
INFO - 2018-03-21 12:11:46 --> Language Class Initialized
INFO - 2018-03-21 12:11:46 --> Config Class Initialized
INFO - 2018-03-21 12:11:46 --> Loader Class Initialized
INFO - 2018-03-21 17:41:46 --> Helper loaded: url_helper
INFO - 2018-03-21 17:41:46 --> Helper loaded: notification_helper
INFO - 2018-03-21 17:41:46 --> Helper loaded: settings_helper
INFO - 2018-03-21 17:41:46 --> Helper loaded: permission_helper
INFO - 2018-03-21 17:41:46 --> Helper loaded: users_helper
INFO - 2018-03-21 17:41:46 --> Database Driver Class Initialized
DEBUG - 2018-03-21 17:41:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 17:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 17:41:47 --> Helper loaded: form_helper
INFO - 2018-03-21 17:41:47 --> Form Validation Class Initialized
INFO - 2018-03-21 17:41:47 --> Controller Class Initialized
INFO - 2018-03-21 17:41:47 --> Model Class Initialized
INFO - 2018-03-21 17:41:47 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 17:41:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 17:41:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 17:41:47 --> Model Class Initialized
INFO - 2018-03-21 17:41:47 --> Model Class Initialized
INFO - 2018-03-21 17:41:47 --> Model Class Initialized
INFO - 2018-03-21 17:41:47 --> Model Class Initialized
INFO - 2018-03-21 17:41:47 --> Model Class Initialized
INFO - 2018-03-21 17:41:47 --> Model Class Initialized
INFO - 2018-03-21 17:41:47 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-21 17:41:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-21 17:41:47 --> Final output sent to browser
DEBUG - 2018-03-21 17:41:47 --> Total execution time: 0.7056
INFO - 2018-03-21 12:11:47 --> Config Class Initialized
INFO - 2018-03-21 12:11:47 --> Hooks Class Initialized
DEBUG - 2018-03-21 12:11:47 --> UTF-8 Support Enabled
INFO - 2018-03-21 12:11:47 --> Utf8 Class Initialized
INFO - 2018-03-21 12:11:47 --> URI Class Initialized
INFO - 2018-03-21 12:11:47 --> Router Class Initialized
INFO - 2018-03-21 12:11:47 --> Output Class Initialized
INFO - 2018-03-21 12:11:47 --> Security Class Initialized
DEBUG - 2018-03-21 12:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 12:11:47 --> Input Class Initialized
INFO - 2018-03-21 12:11:47 --> Language Class Initialized
INFO - 2018-03-21 12:11:47 --> Language Class Initialized
INFO - 2018-03-21 12:11:47 --> Config Class Initialized
INFO - 2018-03-21 12:11:47 --> Loader Class Initialized
INFO - 2018-03-21 17:41:47 --> Helper loaded: url_helper
INFO - 2018-03-21 17:41:47 --> Helper loaded: notification_helper
INFO - 2018-03-21 17:41:47 --> Helper loaded: settings_helper
INFO - 2018-03-21 17:41:47 --> Helper loaded: permission_helper
INFO - 2018-03-21 17:41:47 --> Helper loaded: users_helper
INFO - 2018-03-21 17:41:47 --> Database Driver Class Initialized
DEBUG - 2018-03-21 17:41:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 17:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 17:41:47 --> Helper loaded: form_helper
INFO - 2018-03-21 17:41:47 --> Form Validation Class Initialized
INFO - 2018-03-21 17:41:47 --> Controller Class Initialized
INFO - 2018-03-21 17:41:47 --> Model Class Initialized
INFO - 2018-03-21 17:41:47 --> Helper loaded: inflector_helper
DEBUG - 2018-03-21 17:41:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-21 17:41:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-21 17:41:47 --> Model Class Initialized
INFO - 2018-03-21 17:41:47 --> Model Class Initialized
INFO - 2018-03-21 17:41:47 --> Model Class Initialized
INFO - 2018-03-21 17:41:47 --> Model Class Initialized
INFO - 2018-03-21 17:41:47 --> Model Class Initialized
INFO - 2018-03-21 17:41:47 --> Model Class Initialized
INFO - 2018-03-21 17:41:47 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-21 17:41:47 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
ERROR - 2018-03-21 17:41:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 784
INFO - 2018-03-21 17:41:47 --> Final output sent to browser
DEBUG - 2018-03-21 17:41:47 --> Total execution time: 0.1817
