<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-05-20 00:00:02 --> Helper loaded: url_helper
INFO - 2018-05-20 00:00:02 --> Helper loaded: notification_helper
INFO - 2018-05-20 00:00:02 --> Helper loaded: settings_helper
INFO - 2018-05-20 00:00:02 --> Helper loaded: permission_helper
INFO - 2018-05-20 00:00:02 --> Helper loaded: users_helper
INFO - 2018-05-20 00:00:02 --> Database Driver Class Initialized
DEBUG - 2018-05-20 00:00:02 --> Session: Initialization under CLI aborted.
INFO - 2018-05-20 00:00:02 --> Helper loaded: form_helper
INFO - 2018-05-20 00:00:02 --> Form Validation Class Initialized
INFO - 2018-05-20 00:00:02 --> Controller Class Initialized
INFO - 2018-05-20 00:00:02 --> Model Class Initialized
INFO - 2018-05-20 00:00:02 --> Helper loaded: inflector_helper
DEBUG - 2018-05-20 00:00:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-20 00:00:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-20 00:00:02 --> Model Class Initialized
INFO - 2018-05-20 00:00:02 --> Model Class Initialized
INFO - 2018-05-20 00:00:02 --> Model Class Initialized
INFO - 2018-05-20 00:00:02 --> Model Class Initialized
INFO - 2018-05-20 00:00:02 --> Model Class Initialized
INFO - 2018-05-20 00:00:02 --> Model Class Initialized
INFO - 2018-05-20 00:00:02 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-20 00:00:02 --> Model Class Initialized
INFO - 2018-05-20 00:00:02 --> Final output sent to browser
DEBUG - 2018-05-20 00:00:02 --> Total execution time: 0.1126
INFO - 2018-05-20 00:00:02 --> Helper loaded: url_helper
INFO - 2018-05-20 00:00:02 --> Helper loaded: notification_helper
INFO - 2018-05-20 00:00:02 --> Helper loaded: settings_helper
INFO - 2018-05-20 00:00:02 --> Helper loaded: permission_helper
INFO - 2018-05-20 00:00:02 --> Helper loaded: users_helper
INFO - 2018-05-20 00:00:02 --> Database Driver Class Initialized
DEBUG - 2018-05-20 00:00:02 --> Session: Initialization under CLI aborted.
INFO - 2018-05-20 00:00:02 --> Helper loaded: form_helper
INFO - 2018-05-20 00:00:02 --> Form Validation Class Initialized
INFO - 2018-05-20 00:00:02 --> Controller Class Initialized
INFO - 2018-05-20 00:00:02 --> Model Class Initialized
INFO - 2018-05-20 00:00:02 --> Helper loaded: inflector_helper
DEBUG - 2018-05-20 00:00:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-20 00:00:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-20 00:00:02 --> Model Class Initialized
INFO - 2018-05-20 00:00:02 --> Model Class Initialized
INFO - 2018-05-20 00:00:02 --> Model Class Initialized
INFO - 2018-05-20 00:00:02 --> Model Class Initialized
INFO - 2018-05-20 00:00:02 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-20 00:00:02 --> Model Class Initialized
ERROR - 2018-05-20 00:00:02 --> Query error: Unknown column 'premium_end_date' in 'where clause' - Invalid query: UPDATE `users` SET `premium_status` = '0'
WHERE `premium_trial_used` = '1'
AND `premium_status` = '1'
AND `premium_end_date` <= '2018-05-20'
INFO - 2018-05-20 00:00:02 --> Final output sent to browser
DEBUG - 2018-05-20 00:00:02 --> Total execution time: 0.1531
INFO - 2018-05-20 18:30:01 --> Config Class Initialized
INFO - 2018-05-20 18:30:01 --> Hooks Class Initialized
INFO - 2018-05-20 18:30:01 --> Config Class Initialized
INFO - 2018-05-20 18:30:01 --> Hooks Class Initialized
DEBUG - 2018-05-20 18:30:01 --> UTF-8 Support Enabled
INFO - 2018-05-20 18:30:01 --> Utf8 Class Initialized
DEBUG - 2018-05-20 18:30:01 --> UTF-8 Support Enabled
INFO - 2018-05-20 18:30:01 --> Utf8 Class Initialized
INFO - 2018-05-20 18:30:01 --> URI Class Initialized
INFO - 2018-05-20 18:30:01 --> URI Class Initialized
INFO - 2018-05-20 18:30:01 --> Router Class Initialized
INFO - 2018-05-20 18:30:01 --> Router Class Initialized
INFO - 2018-05-20 18:30:01 --> Output Class Initialized
INFO - 2018-05-20 18:30:01 --> Output Class Initialized
INFO - 2018-05-20 18:30:01 --> Security Class Initialized
DEBUG - 2018-05-20 18:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-20 18:30:01 --> Input Class Initialized
INFO - 2018-05-20 18:30:01 --> Security Class Initialized
DEBUG - 2018-05-20 18:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-20 18:30:01 --> Input Class Initialized
INFO - 2018-05-20 18:30:01 --> Language Class Initialized
INFO - 2018-05-20 18:30:01 --> Language Class Initialized
INFO - 2018-05-20 18:30:01 --> Language Class Initialized
INFO - 2018-05-20 18:30:01 --> Config Class Initialized
INFO - 2018-05-20 18:30:01 --> Loader Class Initialized
INFO - 2018-05-20 18:30:01 --> Language Class Initialized
INFO - 2018-05-20 18:30:01 --> Config Class Initialized
INFO - 2018-05-20 18:30:01 --> Loader Class Initialized
