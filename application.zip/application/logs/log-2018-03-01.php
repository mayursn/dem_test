<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-03-01 05:08:53 --> Config Class Initialized
INFO - 2018-03-01 05:08:53 --> Hooks Class Initialized
DEBUG - 2018-03-01 05:08:53 --> UTF-8 Support Enabled
INFO - 2018-03-01 05:08:53 --> Utf8 Class Initialized
INFO - 2018-03-01 05:08:53 --> URI Class Initialized
INFO - 2018-03-01 05:08:53 --> Config Class Initialized
INFO - 2018-03-01 05:08:53 --> Hooks Class Initialized
INFO - 2018-03-01 05:08:53 --> Router Class Initialized
INFO - 2018-03-01 05:08:53 --> Config Class Initialized
INFO - 2018-03-01 05:08:53 --> Hooks Class Initialized
DEBUG - 2018-03-01 05:08:53 --> UTF-8 Support Enabled
INFO - 2018-03-01 05:08:53 --> Utf8 Class Initialized
INFO - 2018-03-01 05:08:53 --> Output Class Initialized
DEBUG - 2018-03-01 05:08:53 --> UTF-8 Support Enabled
INFO - 2018-03-01 05:08:53 --> Utf8 Class Initialized
INFO - 2018-03-01 05:08:53 --> URI Class Initialized
INFO - 2018-03-01 05:08:53 --> URI Class Initialized
INFO - 2018-03-01 05:08:53 --> Security Class Initialized
DEBUG - 2018-03-01 05:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-01 05:08:53 --> Input Class Initialized
INFO - 2018-03-01 05:08:53 --> Router Class Initialized
INFO - 2018-03-01 05:08:53 --> Router Class Initialized
INFO - 2018-03-01 05:08:53 --> Language Class Initialized
INFO - 2018-03-01 05:08:53 --> Config Class Initialized
INFO - 2018-03-01 05:08:53 --> Hooks Class Initialized
INFO - 2018-03-01 05:08:53 --> Output Class Initialized
INFO - 2018-03-01 05:08:53 --> Output Class Initialized
DEBUG - 2018-03-01 05:08:53 --> UTF-8 Support Enabled
INFO - 2018-03-01 05:08:53 --> Utf8 Class Initialized
INFO - 2018-03-01 05:08:53 --> Security Class Initialized
INFO - 2018-03-01 05:08:53 --> Security Class Initialized
INFO - 2018-03-01 05:08:53 --> URI Class Initialized
DEBUG - 2018-03-01 05:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-01 05:08:53 --> Input Class Initialized
DEBUG - 2018-03-01 05:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-01 05:08:53 --> Input Class Initialized
INFO - 2018-03-01 05:08:53 --> Language Class Initialized
INFO - 2018-03-01 05:08:53 --> Language Class Initialized
INFO - 2018-03-01 05:08:53 --> Router Class Initialized
INFO - 2018-03-01 05:08:53 --> Output Class Initialized
INFO - 2018-03-01 05:08:53 --> Security Class Initialized
INFO - 2018-03-01 05:08:53 --> Language Class Initialized
INFO - 2018-03-01 05:08:53 --> Config Class Initialized
INFO - 2018-03-01 05:08:53 --> Loader Class Initialized
DEBUG - 2018-03-01 05:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-01 05:08:53 --> Input Class Initialized
INFO - 2018-03-01 10:38:53 --> Helper loaded: url_helper
INFO - 2018-03-01 05:08:53 --> Language Class Initialized
INFO - 2018-03-01 10:38:53 --> Helper loaded: notification_helper
INFO - 2018-03-01 10:38:53 --> Helper loaded: settings_helper
INFO - 2018-03-01 10:38:53 --> Helper loaded: permission_helper
INFO - 2018-03-01 10:38:53 --> Helper loaded: users_helper
INFO - 2018-03-01 05:08:53 --> Language Class Initialized
INFO - 2018-03-01 05:08:53 --> Config Class Initialized
INFO - 2018-03-01 05:08:53 --> Loader Class Initialized
INFO - 2018-03-01 05:08:53 --> Language Class Initialized
INFO - 2018-03-01 05:08:53 --> Config Class Initialized
INFO - 2018-03-01 05:08:53 --> Loader Class Initialized
INFO - 2018-03-01 10:38:53 --> Helper loaded: url_helper
INFO - 2018-03-01 10:38:53 --> Helper loaded: url_helper
INFO - 2018-03-01 10:38:53 --> Helper loaded: notification_helper
INFO - 2018-03-01 10:38:53 --> Helper loaded: settings_helper
INFO - 2018-03-01 10:38:53 --> Helper loaded: notification_helper
INFO - 2018-03-01 10:38:53 --> Helper loaded: permission_helper
INFO - 2018-03-01 10:38:53 --> Helper loaded: settings_helper
INFO - 2018-03-01 05:08:53 --> Config Class Initialized
INFO - 2018-03-01 05:08:53 --> Hooks Class Initialized
INFO - 2018-03-01 10:38:53 --> Helper loaded: users_helper
INFO - 2018-03-01 10:38:53 --> Helper loaded: permission_helper
INFO - 2018-03-01 10:38:53 --> Helper loaded: users_helper
INFO - 2018-03-01 10:38:53 --> Database Driver Class Initialized
DEBUG - 2018-03-01 05:08:53 --> UTF-8 Support Enabled
INFO - 2018-03-01 05:08:53 --> Language Class Initialized
INFO - 2018-03-01 05:08:53 --> Config Class Initialized
INFO - 2018-03-01 05:08:53 --> Utf8 Class Initialized
INFO - 2018-03-01 05:08:53 --> Loader Class Initialized
DEBUG - 2018-03-01 10:38:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-01 10:38:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-01 05:08:53 --> URI Class Initialized
INFO - 2018-03-01 10:38:53 --> Helper loaded: url_helper
INFO - 2018-03-01 10:38:53 --> Helper loaded: notification_helper
INFO - 2018-03-01 10:38:53 --> Helper loaded: settings_helper
INFO - 2018-03-01 10:38:53 --> Helper loaded: permission_helper
INFO - 2018-03-01 05:08:53 --> Router Class Initialized
INFO - 2018-03-01 10:38:53 --> Helper loaded: users_helper
INFO - 2018-03-01 10:38:53 --> Database Driver Class Initialized
INFO - 2018-03-01 05:08:53 --> Output Class Initialized
INFO - 2018-03-01 10:38:53 --> Helper loaded: form_helper
INFO - 2018-03-01 10:38:53 --> Form Validation Class Initialized
INFO - 2018-03-01 10:38:53 --> Controller Class Initialized
INFO - 2018-03-01 05:08:53 --> Security Class Initialized
DEBUG - 2018-03-01 10:38:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-01 05:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-01 05:08:53 --> Input Class Initialized
INFO - 2018-03-01 10:38:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-01 05:08:53 --> Language Class Initialized
INFO - 2018-03-01 10:38:53 --> Model Class Initialized
INFO - 2018-03-01 10:38:53 --> Helper loaded: inflector_helper
INFO - 2018-03-01 10:38:53 --> Database Driver Class Initialized
INFO - 2018-03-01 10:38:53 --> Helper loaded: form_helper
INFO - 2018-03-01 10:38:53 --> Form Validation Class Initialized
INFO - 2018-03-01 10:38:53 --> Controller Class Initialized
DEBUG - 2018-03-01 10:38:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-01 10:38:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-01 10:38:53 --> Database Driver Class Initialized
INFO - 2018-03-01 10:38:53 --> Model Class Initialized
INFO - 2018-03-01 10:38:53 --> Model Class Initialized
INFO - 2018-03-01 10:38:53 --> Model Class Initialized
INFO - 2018-03-01 10:38:53 --> Model Class Initialized
DEBUG - 2018-03-01 10:38:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-01 10:38:53 --> Model Class Initialized
INFO - 2018-03-01 10:38:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-01 10:38:53 --> Model Class Initialized
INFO - 2018-03-01 10:38:53 --> Model Class Initialized
INFO - 2018-03-01 10:38:53 --> Model Class Initialized
INFO - 2018-03-01 10:38:53 --> Model Class Initialized
INFO - 2018-03-01 10:38:53 --> Model Class Initialized
DEBUG - 2018-03-01 10:38:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-01 10:38:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-01 10:38:53 --> Model Class Initialized
INFO - 2018-03-01 10:38:53 --> Helper loaded: inflector_helper
INFO - 2018-03-01 10:38:53 --> Model Class Initialized
INFO - 2018-03-01 10:38:53 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-01 10:38:53 --> Model Class Initialized
INFO - 2018-03-01 05:08:53 --> Language Class Initialized
INFO - 2018-03-01 05:08:53 --> Config Class Initialized
INFO - 2018-03-01 05:08:53 --> Loader Class Initialized
DEBUG - 2018-03-01 10:38:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-01 10:38:53 --> Helper loaded: form_helper
INFO - 2018-03-01 10:38:53 --> Form Validation Class Initialized
INFO - 2018-03-01 10:38:53 --> Controller Class Initialized
INFO - 2018-03-01 10:38:53 --> Helper loaded: url_helper
INFO - 2018-03-01 10:38:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-01 10:38:53 --> Helper loaded: notification_helper
INFO - 2018-03-01 10:38:53 --> Helper loaded: settings_helper
INFO - 2018-03-01 10:38:53 --> Helper loaded: form_helper
INFO - 2018-03-01 10:38:53 --> Form Validation Class Initialized
INFO - 2018-03-01 10:38:53 --> Controller Class Initialized
INFO - 2018-03-01 10:38:53 --> Model Class Initialized
INFO - 2018-03-01 10:38:53 --> Helper loaded: permission_helper
INFO - 2018-03-01 10:38:53 --> Model Class Initialized
INFO - 2018-03-01 10:38:53 --> Helper loaded: users_helper
INFO - 2018-03-01 10:38:53 --> Model Class Initialized
INFO - 2018-03-01 10:38:53 --> Model Class Initialized
INFO - 2018-03-01 10:38:53 --> Model Class Initialized
INFO - 2018-03-01 10:38:53 --> Model Class Initialized
INFO - 2018-03-01 10:38:53 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-01 10:38:53 --> Model Class Initialized
INFO - 2018-03-01 10:38:53 --> Model Class Initialized
INFO - 2018-03-01 10:38:53 --> Helper loaded: inflector_helper
INFO - 2018-03-01 10:38:53 --> Final output sent to browser
DEBUG - 2018-03-01 10:38:53 --> Total execution time: 0.1116
INFO - 2018-03-01 10:38:53 --> Model Class Initialized
INFO - 2018-03-01 10:38:53 --> Helper loaded: inflector_helper
DEBUG - 2018-03-01 10:38:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-01 10:38:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-01 10:38:53 --> Model Class Initialized
DEBUG - 2018-03-01 10:38:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-01 10:38:53 --> Model Class Initialized
INFO - 2018-03-01 10:38:53 --> Database Driver Class Initialized
INFO - 2018-03-01 10:38:53 --> Model Class Initialized
INFO - 2018-03-01 10:38:53 --> Model Class Initialized
INFO - 2018-03-01 10:38:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-01 10:38:53 --> Model Class Initialized
INFO - 2018-03-01 10:38:53 --> Model Class Initialized
INFO - 2018-03-01 10:38:53 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-01 10:38:53 --> Model Class Initialized
INFO - 2018-03-01 10:38:53 --> Model Class Initialized
INFO - 2018-03-01 10:38:53 --> Model Class Initialized
INFO - 2018-03-01 10:38:53 --> Model Class Initialized
INFO - 2018-03-01 10:38:53 --> Model Class Initialized
INFO - 2018-03-01 10:38:53 --> Model Class Initialized
DEBUG - 2018-03-01 10:38:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-01 10:38:53 --> Model Class Initialized
INFO - 2018-03-01 10:38:53 --> Final output sent to browser
DEBUG - 2018-03-01 10:38:53 --> Total execution time: 0.1154
INFO - 2018-03-01 10:38:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-01 10:38:53 --> Model Class Initialized
INFO - 2018-03-01 10:38:53 --> Model Class Initialized
INFO - 2018-03-01 10:38:53 --> Model Class Initialized
INFO - 2018-03-01 10:38:53 --> Model Class Initialized
INFO - 2018-03-01 10:38:53 --> Model Class Initialized
INFO - 2018-03-01 10:38:53 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-01 10:38:53 --> Model Class Initialized
INFO - 2018-03-01 10:38:53 --> Final output sent to browser
DEBUG - 2018-03-01 10:38:53 --> Total execution time: 0.1427
INFO - 2018-03-01 10:38:53 --> Helper loaded: form_helper
INFO - 2018-03-01 10:38:53 --> Form Validation Class Initialized
INFO - 2018-03-01 10:38:53 --> Controller Class Initialized
INFO - 2018-03-01 10:38:53 --> Model Class Initialized
INFO - 2018-03-01 10:38:53 --> Helper loaded: inflector_helper
INFO - 2018-03-01 10:38:53 --> Final output sent to browser
DEBUG - 2018-03-01 10:38:53 --> Total execution time: 0.1467
DEBUG - 2018-03-01 10:38:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-01 10:38:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-01 10:38:53 --> Model Class Initialized
INFO - 2018-03-01 10:38:53 --> Model Class Initialized
INFO - 2018-03-01 10:38:53 --> Model Class Initialized
INFO - 2018-03-01 10:38:53 --> Model Class Initialized
INFO - 2018-03-01 10:38:53 --> Model Class Initialized
INFO - 2018-03-01 10:38:53 --> Model Class Initialized
INFO - 2018-03-01 10:38:53 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-01 10:38:53 --> Final output sent to browser
DEBUG - 2018-03-01 10:38:53 --> Total execution time: 0.1241
INFO - 2018-03-01 05:41:30 --> Config Class Initialized
INFO - 2018-03-01 05:41:30 --> Config Class Initialized
INFO - 2018-03-01 05:41:30 --> Hooks Class Initialized
INFO - 2018-03-01 05:41:30 --> Hooks Class Initialized
DEBUG - 2018-03-01 05:41:30 --> UTF-8 Support Enabled
DEBUG - 2018-03-01 05:41:30 --> UTF-8 Support Enabled
INFO - 2018-03-01 05:41:30 --> Utf8 Class Initialized
INFO - 2018-03-01 05:41:30 --> Utf8 Class Initialized
INFO - 2018-03-01 05:41:30 --> URI Class Initialized
INFO - 2018-03-01 05:41:30 --> URI Class Initialized
INFO - 2018-03-01 05:41:30 --> Router Class Initialized
INFO - 2018-03-01 05:41:30 --> Router Class Initialized
INFO - 2018-03-01 05:41:30 --> Output Class Initialized
INFO - 2018-03-01 05:41:30 --> Output Class Initialized
INFO - 2018-03-01 05:41:30 --> Security Class Initialized
INFO - 2018-03-01 05:41:30 --> Security Class Initialized
DEBUG - 2018-03-01 05:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-01 05:41:30 --> Input Class Initialized
DEBUG - 2018-03-01 05:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-01 05:41:30 --> Input Class Initialized
INFO - 2018-03-01 05:41:30 --> Language Class Initialized
INFO - 2018-03-01 05:41:30 --> Language Class Initialized
INFO - 2018-03-01 05:41:30 --> Language Class Initialized
INFO - 2018-03-01 05:41:30 --> Config Class Initialized
INFO - 2018-03-01 05:41:30 --> Loader Class Initialized
INFO - 2018-03-01 11:11:30 --> Helper loaded: url_helper
INFO - 2018-03-01 11:11:30 --> Helper loaded: notification_helper
INFO - 2018-03-01 05:41:30 --> Language Class Initialized
INFO - 2018-03-01 05:41:30 --> Config Class Initialized
INFO - 2018-03-01 05:41:30 --> Loader Class Initialized
INFO - 2018-03-01 11:11:30 --> Helper loaded: settings_helper
INFO - 2018-03-01 11:11:30 --> Helper loaded: permission_helper
INFO - 2018-03-01 11:11:30 --> Helper loaded: users_helper
INFO - 2018-03-01 11:11:30 --> Helper loaded: url_helper
INFO - 2018-03-01 11:11:30 --> Helper loaded: notification_helper
INFO - 2018-03-01 11:11:30 --> Helper loaded: settings_helper
INFO - 2018-03-01 11:11:30 --> Helper loaded: permission_helper
INFO - 2018-03-01 11:11:30 --> Helper loaded: users_helper
INFO - 2018-03-01 11:11:30 --> Database Driver Class Initialized
INFO - 2018-03-01 11:11:30 --> Database Driver Class Initialized
DEBUG - 2018-03-01 11:11:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-01 11:11:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-03-01 11:11:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-01 11:11:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-01 11:11:30 --> Helper loaded: form_helper
INFO - 2018-03-01 11:11:30 --> Form Validation Class Initialized
INFO - 2018-03-01 11:11:30 --> Controller Class Initialized
INFO - 2018-03-01 11:11:30 --> Helper loaded: form_helper
INFO - 2018-03-01 11:11:30 --> Form Validation Class Initialized
INFO - 2018-03-01 11:11:30 --> Controller Class Initialized
INFO - 2018-03-01 11:11:30 --> Model Class Initialized
INFO - 2018-03-01 11:11:30 --> Helper loaded: inflector_helper
DEBUG - 2018-03-01 11:11:30 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-01 11:11:30 --> Model Class Initialized
INFO - 2018-03-01 11:11:30 --> Helper loaded: inflector_helper
INFO - 2018-03-01 11:11:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-01 11:11:30 --> Model Class Initialized
INFO - 2018-03-01 11:11:30 --> Model Class Initialized
INFO - 2018-03-01 11:11:30 --> Model Class Initialized
INFO - 2018-03-01 11:11:30 --> Model Class Initialized
DEBUG - 2018-03-01 11:11:30 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-01 11:11:30 --> Model Class Initialized
INFO - 2018-03-01 11:11:30 --> Model Class Initialized
INFO - 2018-03-01 11:11:30 --> Model Class Initialized
INFO - 2018-03-01 11:11:30 --> Model Class Initialized
INFO - 2018-03-01 11:11:30 --> Model Class Initialized
INFO - 2018-03-01 11:11:30 --> Model Class Initialized
INFO - 2018-03-01 11:11:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-01 11:11:30 --> Model Class Initialized
INFO - 2018-03-01 11:11:30 --> Model Class Initialized
INFO - 2018-03-01 11:11:30 --> Model Class Initialized
INFO - 2018-03-01 11:11:30 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-01 11:11:30 --> Model Class Initialized
INFO - 2018-03-01 11:11:30 --> Model Class Initialized
INFO - 2018-03-01 11:11:30 --> Model Class Initialized
INFO - 2018-03-01 11:11:30 --> Model Class Initialized
INFO - 2018-03-01 11:11:30 --> Model Class Initialized
INFO - 2018-03-01 11:11:30 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-01 11:11:30 --> Model Class Initialized
INFO - 2018-03-01 11:11:30 --> Final output sent to browser
DEBUG - 2018-03-01 11:11:30 --> Total execution time: 0.1142
INFO - 2018-03-01 11:11:30 --> Final output sent to browser
DEBUG - 2018-03-01 11:11:30 --> Total execution time: 0.1322
INFO - 2018-03-01 05:41:47 --> Config Class Initialized
INFO - 2018-03-01 05:41:47 --> Config Class Initialized
INFO - 2018-03-01 05:41:47 --> Hooks Class Initialized
INFO - 2018-03-01 05:41:47 --> Hooks Class Initialized
DEBUG - 2018-03-01 05:41:47 --> UTF-8 Support Enabled
DEBUG - 2018-03-01 05:41:47 --> UTF-8 Support Enabled
INFO - 2018-03-01 05:41:47 --> Utf8 Class Initialized
INFO - 2018-03-01 05:41:47 --> Utf8 Class Initialized
INFO - 2018-03-01 05:41:47 --> URI Class Initialized
INFO - 2018-03-01 05:41:47 --> URI Class Initialized
INFO - 2018-03-01 05:41:47 --> Router Class Initialized
INFO - 2018-03-01 05:41:47 --> Router Class Initialized
INFO - 2018-03-01 05:41:47 --> Output Class Initialized
INFO - 2018-03-01 05:41:47 --> Output Class Initialized
INFO - 2018-03-01 05:41:47 --> Security Class Initialized
INFO - 2018-03-01 05:41:47 --> Security Class Initialized
DEBUG - 2018-03-01 05:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-01 05:41:47 --> Input Class Initialized
DEBUG - 2018-03-01 05:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-01 05:41:47 --> Input Class Initialized
INFO - 2018-03-01 05:41:47 --> Language Class Initialized
INFO - 2018-03-01 05:41:47 --> Language Class Initialized
INFO - 2018-03-01 05:41:47 --> Language Class Initialized
INFO - 2018-03-01 05:41:47 --> Config Class Initialized
INFO - 2018-03-01 05:41:47 --> Loader Class Initialized
INFO - 2018-03-01 11:11:47 --> Helper loaded: url_helper
INFO - 2018-03-01 11:11:47 --> Helper loaded: notification_helper
INFO - 2018-03-01 11:11:47 --> Helper loaded: settings_helper
INFO - 2018-03-01 11:11:47 --> Helper loaded: permission_helper
INFO - 2018-03-01 05:41:47 --> Language Class Initialized
INFO - 2018-03-01 05:41:47 --> Config Class Initialized
INFO - 2018-03-01 05:41:47 --> Loader Class Initialized
INFO - 2018-03-01 11:11:47 --> Helper loaded: users_helper
INFO - 2018-03-01 11:11:47 --> Helper loaded: url_helper
INFO - 2018-03-01 11:11:47 --> Helper loaded: notification_helper
INFO - 2018-03-01 11:11:47 --> Helper loaded: settings_helper
INFO - 2018-03-01 11:11:47 --> Helper loaded: permission_helper
INFO - 2018-03-01 11:11:47 --> Helper loaded: users_helper
INFO - 2018-03-01 11:11:47 --> Database Driver Class Initialized
DEBUG - 2018-03-01 11:11:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-01 11:11:47 --> Database Driver Class Initialized
INFO - 2018-03-01 11:11:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-01 11:11:47 --> Helper loaded: form_helper
INFO - 2018-03-01 11:11:47 --> Form Validation Class Initialized
INFO - 2018-03-01 11:11:47 --> Controller Class Initialized
DEBUG - 2018-03-01 11:11:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-01 11:11:47 --> Model Class Initialized
INFO - 2018-03-01 11:11:47 --> Helper loaded: inflector_helper
DEBUG - 2018-03-01 11:11:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-01 11:11:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-01 11:11:47 --> Model Class Initialized
INFO - 2018-03-01 11:11:47 --> Model Class Initialized
INFO - 2018-03-01 11:11:47 --> Model Class Initialized
INFO - 2018-03-01 11:11:47 --> Model Class Initialized
INFO - 2018-03-01 11:11:47 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-01 11:11:47 --> Final output sent to browser
DEBUG - 2018-03-01 11:11:47 --> Total execution time: 0.1835
INFO - 2018-03-01 11:11:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-01 11:11:47 --> Helper loaded: form_helper
INFO - 2018-03-01 11:11:47 --> Form Validation Class Initialized
INFO - 2018-03-01 11:11:47 --> Controller Class Initialized
INFO - 2018-03-01 11:11:47 --> Model Class Initialized
INFO - 2018-03-01 11:11:47 --> Helper loaded: inflector_helper
DEBUG - 2018-03-01 11:11:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-01 11:11:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-01 11:11:47 --> Model Class Initialized
INFO - 2018-03-01 11:11:47 --> Model Class Initialized
INFO - 2018-03-01 11:11:47 --> Model Class Initialized
INFO - 2018-03-01 11:11:47 --> Model Class Initialized
INFO - 2018-03-01 11:11:47 --> Model Class Initialized
INFO - 2018-03-01 11:11:47 --> Model Class Initialized
INFO - 2018-03-01 11:11:47 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-01 11:11:47 --> Final output sent to browser
DEBUG - 2018-03-01 11:11:47 --> Total execution time: 0.2199
INFO - 2018-03-01 05:51:27 --> Config Class Initialized
INFO - 2018-03-01 05:51:27 --> Hooks Class Initialized
DEBUG - 2018-03-01 05:51:27 --> UTF-8 Support Enabled
INFO - 2018-03-01 05:51:27 --> Utf8 Class Initialized
INFO - 2018-03-01 05:51:27 --> URI Class Initialized
INFO - 2018-03-01 05:51:27 --> Router Class Initialized
INFO - 2018-03-01 05:51:27 --> Output Class Initialized
INFO - 2018-03-01 05:51:27 --> Security Class Initialized
DEBUG - 2018-03-01 05:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-01 05:51:27 --> Input Class Initialized
INFO - 2018-03-01 05:51:27 --> Language Class Initialized
INFO - 2018-03-01 05:51:27 --> Language Class Initialized
INFO - 2018-03-01 05:51:27 --> Config Class Initialized
INFO - 2018-03-01 05:51:27 --> Loader Class Initialized
INFO - 2018-03-01 11:21:27 --> Helper loaded: url_helper
INFO - 2018-03-01 11:21:27 --> Helper loaded: notification_helper
INFO - 2018-03-01 11:21:27 --> Helper loaded: settings_helper
INFO - 2018-03-01 11:21:27 --> Helper loaded: permission_helper
INFO - 2018-03-01 11:21:27 --> Helper loaded: users_helper
INFO - 2018-03-01 11:21:27 --> Database Driver Class Initialized
DEBUG - 2018-03-01 11:21:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-01 11:21:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-01 11:21:27 --> Helper loaded: form_helper
INFO - 2018-03-01 11:21:27 --> Form Validation Class Initialized
INFO - 2018-03-01 11:21:27 --> Controller Class Initialized
INFO - 2018-03-01 11:21:27 --> Model Class Initialized
INFO - 2018-03-01 11:21:27 --> Helper loaded: inflector_helper
DEBUG - 2018-03-01 11:21:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-01 11:21:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-01 11:21:27 --> Model Class Initialized
INFO - 2018-03-01 11:21:27 --> Model Class Initialized
INFO - 2018-03-01 11:21:27 --> Model Class Initialized
INFO - 2018-03-01 11:21:27 --> Model Class Initialized
INFO - 2018-03-01 11:21:27 --> Model Class Initialized
INFO - 2018-03-01 11:21:27 --> Model Class Initialized
INFO - 2018-03-01 11:21:27 --> Model Class Initialized
INFO - 2018-03-01 11:21:27 --> Model Class Initialized
INFO - 2018-03-01 11:21:27 --> Model Class Initialized
INFO - 2018-03-01 11:21:27 --> Model Class Initialized
INFO - 2018-03-01 11:21:27 --> Model Class Initialized
INFO - 2018-03-01 11:21:27 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-01 11:21:27 --> Model Class Initialized
INFO - 2018-03-01 11:21:27 --> Final output sent to browser
DEBUG - 2018-03-01 11:21:27 --> Total execution time: 0.1170
INFO - 2018-03-01 05:51:28 --> Config Class Initialized
INFO - 2018-03-01 05:51:28 --> Hooks Class Initialized
DEBUG - 2018-03-01 05:51:28 --> UTF-8 Support Enabled
INFO - 2018-03-01 05:51:28 --> Utf8 Class Initialized
INFO - 2018-03-01 05:51:28 --> URI Class Initialized
INFO - 2018-03-01 05:51:28 --> Router Class Initialized
INFO - 2018-03-01 05:51:28 --> Output Class Initialized
INFO - 2018-03-01 05:51:28 --> Security Class Initialized
DEBUG - 2018-03-01 05:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-01 05:51:28 --> Input Class Initialized
INFO - 2018-03-01 05:51:28 --> Language Class Initialized
INFO - 2018-03-01 05:51:28 --> Language Class Initialized
INFO - 2018-03-01 05:51:28 --> Config Class Initialized
INFO - 2018-03-01 05:51:28 --> Loader Class Initialized
INFO - 2018-03-01 11:21:28 --> Helper loaded: url_helper
INFO - 2018-03-01 11:21:28 --> Helper loaded: notification_helper
INFO - 2018-03-01 11:21:28 --> Helper loaded: settings_helper
INFO - 2018-03-01 11:21:28 --> Helper loaded: permission_helper
INFO - 2018-03-01 11:21:28 --> Helper loaded: users_helper
INFO - 2018-03-01 11:21:28 --> Database Driver Class Initialized
DEBUG - 2018-03-01 11:21:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-01 11:21:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-01 11:21:28 --> Helper loaded: form_helper
INFO - 2018-03-01 11:21:28 --> Form Validation Class Initialized
INFO - 2018-03-01 11:21:28 --> Controller Class Initialized
INFO - 2018-03-01 11:21:28 --> Model Class Initialized
INFO - 2018-03-01 11:21:28 --> Helper loaded: inflector_helper
DEBUG - 2018-03-01 11:21:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-01 11:21:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-01 11:21:28 --> Model Class Initialized
INFO - 2018-03-01 11:21:28 --> Model Class Initialized
INFO - 2018-03-01 11:21:28 --> Model Class Initialized
INFO - 2018-03-01 11:21:28 --> Model Class Initialized
INFO - 2018-03-01 11:21:28 --> Model Class Initialized
INFO - 2018-03-01 11:21:28 --> Model Class Initialized
INFO - 2018-03-01 11:21:28 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-01 11:21:28 --> Model Class Initialized
INFO - 2018-03-01 11:21:28 --> Final output sent to browser
DEBUG - 2018-03-01 11:21:28 --> Total execution time: 0.0973
INFO - 2018-03-01 05:51:56 --> Config Class Initialized
INFO - 2018-03-01 05:51:56 --> Hooks Class Initialized
DEBUG - 2018-03-01 05:51:56 --> UTF-8 Support Enabled
INFO - 2018-03-01 05:51:56 --> Utf8 Class Initialized
INFO - 2018-03-01 05:51:56 --> URI Class Initialized
INFO - 2018-03-01 05:51:56 --> Router Class Initialized
INFO - 2018-03-01 05:51:56 --> Output Class Initialized
INFO - 2018-03-01 05:51:56 --> Config Class Initialized
INFO - 2018-03-01 05:51:56 --> Hooks Class Initialized
INFO - 2018-03-01 05:51:56 --> Security Class Initialized
DEBUG - 2018-03-01 05:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-01 05:51:56 --> Input Class Initialized
DEBUG - 2018-03-01 05:51:56 --> UTF-8 Support Enabled
INFO - 2018-03-01 05:51:56 --> Utf8 Class Initialized
INFO - 2018-03-01 05:51:56 --> Language Class Initialized
INFO - 2018-03-01 05:51:56 --> URI Class Initialized
INFO - 2018-03-01 05:51:56 --> Router Class Initialized
INFO - 2018-03-01 05:51:56 --> Output Class Initialized
INFO - 2018-03-01 05:51:56 --> Security Class Initialized
DEBUG - 2018-03-01 05:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-01 05:51:56 --> Input Class Initialized
INFO - 2018-03-01 05:51:56 --> Language Class Initialized
INFO - 2018-03-01 05:51:56 --> Language Class Initialized
INFO - 2018-03-01 05:51:56 --> Config Class Initialized
INFO - 2018-03-01 05:51:56 --> Loader Class Initialized
INFO - 2018-03-01 11:21:56 --> Helper loaded: url_helper
INFO - 2018-03-01 11:21:56 --> Helper loaded: notification_helper
INFO - 2018-03-01 11:21:56 --> Helper loaded: settings_helper
INFO - 2018-03-01 11:21:56 --> Helper loaded: permission_helper
INFO - 2018-03-01 05:51:56 --> Language Class Initialized
INFO - 2018-03-01 05:51:56 --> Config Class Initialized
INFO - 2018-03-01 05:51:56 --> Loader Class Initialized
INFO - 2018-03-01 11:21:56 --> Helper loaded: users_helper
INFO - 2018-03-01 11:21:56 --> Helper loaded: url_helper
INFO - 2018-03-01 11:21:56 --> Helper loaded: notification_helper
INFO - 2018-03-01 11:21:56 --> Helper loaded: settings_helper
INFO - 2018-03-01 11:21:56 --> Helper loaded: permission_helper
INFO - 2018-03-01 11:21:56 --> Helper loaded: users_helper
INFO - 2018-03-01 11:21:56 --> Database Driver Class Initialized
DEBUG - 2018-03-01 11:21:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-01 11:21:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-01 11:21:56 --> Helper loaded: form_helper
INFO - 2018-03-01 11:21:56 --> Form Validation Class Initialized
INFO - 2018-03-01 11:21:56 --> Controller Class Initialized
INFO - 2018-03-01 11:21:56 --> Model Class Initialized
INFO - 2018-03-01 11:21:56 --> Helper loaded: inflector_helper
DEBUG - 2018-03-01 11:21:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-01 11:21:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-01 11:21:56 --> Model Class Initialized
INFO - 2018-03-01 11:21:56 --> Model Class Initialized
INFO - 2018-03-01 11:21:56 --> Model Class Initialized
INFO - 2018-03-01 11:21:56 --> Model Class Initialized
INFO - 2018-03-01 11:21:56 --> Model Class Initialized
INFO - 2018-03-01 11:21:56 --> Model Class Initialized
INFO - 2018-03-01 11:21:56 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-01 11:21:56 --> Database Driver Class Initialized
INFO - 2018-03-01 11:21:56 --> Final output sent to browser
DEBUG - 2018-03-01 11:21:56 --> Total execution time: 0.1056
DEBUG - 2018-03-01 11:21:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-01 11:21:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-01 11:21:56 --> Helper loaded: form_helper
INFO - 2018-03-01 11:21:56 --> Form Validation Class Initialized
INFO - 2018-03-01 11:21:56 --> Controller Class Initialized
INFO - 2018-03-01 11:21:56 --> Model Class Initialized
INFO - 2018-03-01 11:21:56 --> Helper loaded: inflector_helper
DEBUG - 2018-03-01 11:21:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-01 11:21:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-01 11:21:56 --> Model Class Initialized
INFO - 2018-03-01 11:21:56 --> Model Class Initialized
INFO - 2018-03-01 11:21:56 --> Model Class Initialized
INFO - 2018-03-01 11:21:56 --> Model Class Initialized
INFO - 2018-03-01 11:21:56 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-01 11:21:56 --> Final output sent to browser
DEBUG - 2018-03-01 11:21:56 --> Total execution time: 0.1998
INFO - 2018-03-01 05:53:53 --> Config Class Initialized
INFO - 2018-03-01 05:53:53 --> Hooks Class Initialized
DEBUG - 2018-03-01 05:53:53 --> UTF-8 Support Enabled
INFO - 2018-03-01 05:53:53 --> Utf8 Class Initialized
INFO - 2018-03-01 05:53:53 --> URI Class Initialized
INFO - 2018-03-01 05:53:53 --> Router Class Initialized
INFO - 2018-03-01 05:53:53 --> Output Class Initialized
INFO - 2018-03-01 05:53:53 --> Security Class Initialized
DEBUG - 2018-03-01 05:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-01 05:53:53 --> Input Class Initialized
INFO - 2018-03-01 05:53:53 --> Language Class Initialized
INFO - 2018-03-01 05:53:53 --> Language Class Initialized
INFO - 2018-03-01 05:53:53 --> Config Class Initialized
INFO - 2018-03-01 05:53:53 --> Loader Class Initialized
INFO - 2018-03-01 11:23:53 --> Helper loaded: url_helper
INFO - 2018-03-01 11:23:53 --> Helper loaded: notification_helper
INFO - 2018-03-01 11:23:53 --> Helper loaded: settings_helper
INFO - 2018-03-01 11:23:53 --> Helper loaded: permission_helper
INFO - 2018-03-01 11:23:53 --> Helper loaded: users_helper
INFO - 2018-03-01 11:23:53 --> Database Driver Class Initialized
DEBUG - 2018-03-01 11:23:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-01 11:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-01 11:23:53 --> Helper loaded: form_helper
INFO - 2018-03-01 11:23:53 --> Form Validation Class Initialized
INFO - 2018-03-01 11:23:53 --> Controller Class Initialized
INFO - 2018-03-01 11:23:53 --> Model Class Initialized
INFO - 2018-03-01 11:23:53 --> Helper loaded: inflector_helper
DEBUG - 2018-03-01 11:23:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-01 11:23:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-01 11:23:53 --> Model Class Initialized
INFO - 2018-03-01 11:23:53 --> Model Class Initialized
INFO - 2018-03-01 11:23:53 --> Model Class Initialized
INFO - 2018-03-01 11:23:53 --> Model Class Initialized
INFO - 2018-03-01 11:23:53 --> Model Class Initialized
INFO - 2018-03-01 11:23:53 --> Model Class Initialized
INFO - 2018-03-01 11:23:53 --> Model Class Initialized
INFO - 2018-03-01 11:23:53 --> Model Class Initialized
INFO - 2018-03-01 11:23:53 --> Model Class Initialized
INFO - 2018-03-01 11:23:53 --> Model Class Initialized
INFO - 2018-03-01 11:23:53 --> Model Class Initialized
INFO - 2018-03-01 11:23:53 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-01 11:23:53 --> Model Class Initialized
INFO - 2018-03-01 11:23:53 --> Final output sent to browser
DEBUG - 2018-03-01 11:23:53 --> Total execution time: 0.1368
INFO - 2018-03-01 05:53:53 --> Config Class Initialized
INFO - 2018-03-01 05:53:53 --> Hooks Class Initialized
DEBUG - 2018-03-01 05:53:53 --> UTF-8 Support Enabled
INFO - 2018-03-01 05:53:53 --> Utf8 Class Initialized
INFO - 2018-03-01 05:53:53 --> URI Class Initialized
INFO - 2018-03-01 05:53:53 --> Router Class Initialized
INFO - 2018-03-01 05:53:53 --> Output Class Initialized
INFO - 2018-03-01 05:53:53 --> Security Class Initialized
DEBUG - 2018-03-01 05:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-01 05:53:53 --> Input Class Initialized
INFO - 2018-03-01 05:53:53 --> Language Class Initialized
INFO - 2018-03-01 05:53:54 --> Language Class Initialized
INFO - 2018-03-01 05:53:54 --> Config Class Initialized
INFO - 2018-03-01 05:53:54 --> Loader Class Initialized
INFO - 2018-03-01 11:23:54 --> Helper loaded: url_helper
INFO - 2018-03-01 11:23:54 --> Helper loaded: notification_helper
INFO - 2018-03-01 11:23:54 --> Helper loaded: settings_helper
INFO - 2018-03-01 11:23:54 --> Helper loaded: permission_helper
INFO - 2018-03-01 11:23:54 --> Helper loaded: users_helper
INFO - 2018-03-01 11:23:54 --> Database Driver Class Initialized
DEBUG - 2018-03-01 11:23:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-01 11:23:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-01 11:23:54 --> Helper loaded: form_helper
INFO - 2018-03-01 11:23:54 --> Form Validation Class Initialized
INFO - 2018-03-01 11:23:54 --> Controller Class Initialized
INFO - 2018-03-01 11:23:54 --> Model Class Initialized
INFO - 2018-03-01 11:23:54 --> Helper loaded: inflector_helper
DEBUG - 2018-03-01 11:23:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-01 11:23:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-01 11:23:54 --> Model Class Initialized
INFO - 2018-03-01 11:23:54 --> Model Class Initialized
INFO - 2018-03-01 11:23:54 --> Model Class Initialized
INFO - 2018-03-01 11:23:54 --> Model Class Initialized
INFO - 2018-03-01 11:23:54 --> Model Class Initialized
INFO - 2018-03-01 11:23:54 --> Model Class Initialized
INFO - 2018-03-01 11:23:54 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-01 11:23:54 --> Model Class Initialized
INFO - 2018-03-01 11:23:54 --> Final output sent to browser
DEBUG - 2018-03-01 11:23:54 --> Total execution time: 0.1625
INFO - 2018-03-01 05:53:56 --> Config Class Initialized
INFO - 2018-03-01 05:53:56 --> Hooks Class Initialized
INFO - 2018-03-01 05:53:56 --> Config Class Initialized
INFO - 2018-03-01 05:53:56 --> Hooks Class Initialized
DEBUG - 2018-03-01 05:53:56 --> UTF-8 Support Enabled
INFO - 2018-03-01 05:53:56 --> Utf8 Class Initialized
DEBUG - 2018-03-01 05:53:56 --> UTF-8 Support Enabled
INFO - 2018-03-01 05:53:56 --> Utf8 Class Initialized
INFO - 2018-03-01 05:53:56 --> URI Class Initialized
INFO - 2018-03-01 05:53:56 --> URI Class Initialized
INFO - 2018-03-01 05:53:56 --> Router Class Initialized
INFO - 2018-03-01 05:53:56 --> Router Class Initialized
INFO - 2018-03-01 05:53:56 --> Output Class Initialized
INFO - 2018-03-01 05:53:56 --> Output Class Initialized
INFO - 2018-03-01 05:53:56 --> Security Class Initialized
INFO - 2018-03-01 05:53:56 --> Security Class Initialized
DEBUG - 2018-03-01 05:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-01 05:53:56 --> Input Class Initialized
DEBUG - 2018-03-01 05:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-01 05:53:56 --> Input Class Initialized
INFO - 2018-03-01 05:53:56 --> Language Class Initialized
INFO - 2018-03-01 05:53:56 --> Language Class Initialized
INFO - 2018-03-01 05:53:56 --> Language Class Initialized
INFO - 2018-03-01 05:53:56 --> Config Class Initialized
INFO - 2018-03-01 05:53:56 --> Loader Class Initialized
INFO - 2018-03-01 11:23:56 --> Helper loaded: url_helper
INFO - 2018-03-01 11:23:56 --> Helper loaded: notification_helper
INFO - 2018-03-01 11:23:56 --> Helper loaded: settings_helper
INFO - 2018-03-01 11:23:56 --> Helper loaded: permission_helper
INFO - 2018-03-01 11:23:56 --> Helper loaded: users_helper
INFO - 2018-03-01 05:53:56 --> Language Class Initialized
INFO - 2018-03-01 05:53:56 --> Config Class Initialized
INFO - 2018-03-01 05:53:56 --> Loader Class Initialized
INFO - 2018-03-01 11:23:56 --> Helper loaded: url_helper
INFO - 2018-03-01 11:23:56 --> Helper loaded: notification_helper
INFO - 2018-03-01 11:23:56 --> Helper loaded: settings_helper
INFO - 2018-03-01 11:23:56 --> Helper loaded: permission_helper
INFO - 2018-03-01 11:23:56 --> Helper loaded: users_helper
INFO - 2018-03-01 11:23:56 --> Database Driver Class Initialized
INFO - 2018-03-01 11:23:56 --> Database Driver Class Initialized
DEBUG - 2018-03-01 11:23:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-01 11:23:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-03-01 11:23:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-01 11:23:56 --> Helper loaded: form_helper
INFO - 2018-03-01 11:23:56 --> Form Validation Class Initialized
INFO - 2018-03-01 11:23:56 --> Controller Class Initialized
INFO - 2018-03-01 11:23:56 --> Model Class Initialized
INFO - 2018-03-01 11:23:56 --> Helper loaded: inflector_helper
DEBUG - 2018-03-01 11:23:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-01 11:23:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-01 11:23:56 --> Model Class Initialized
INFO - 2018-03-01 11:23:56 --> Model Class Initialized
INFO - 2018-03-01 11:23:56 --> Model Class Initialized
INFO - 2018-03-01 11:23:56 --> Model Class Initialized
INFO - 2018-03-01 11:23:56 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-01 11:23:56 --> Final output sent to browser
DEBUG - 2018-03-01 11:23:56 --> Total execution time: 0.1118
INFO - 2018-03-01 11:23:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-01 11:23:56 --> Helper loaded: form_helper
INFO - 2018-03-01 11:23:56 --> Form Validation Class Initialized
INFO - 2018-03-01 11:23:56 --> Controller Class Initialized
INFO - 2018-03-01 11:23:56 --> Model Class Initialized
INFO - 2018-03-01 11:23:56 --> Helper loaded: inflector_helper
DEBUG - 2018-03-01 11:23:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-01 11:23:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-01 11:23:56 --> Model Class Initialized
INFO - 2018-03-01 11:23:56 --> Model Class Initialized
INFO - 2018-03-01 11:23:56 --> Model Class Initialized
INFO - 2018-03-01 11:23:56 --> Model Class Initialized
INFO - 2018-03-01 11:23:56 --> Model Class Initialized
INFO - 2018-03-01 11:23:56 --> Model Class Initialized
INFO - 2018-03-01 11:23:56 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-01 11:23:56 --> Final output sent to browser
DEBUG - 2018-03-01 11:23:56 --> Total execution time: 0.1435
INFO - 2018-03-01 05:56:08 --> Config Class Initialized
INFO - 2018-03-01 05:56:08 --> Hooks Class Initialized
DEBUG - 2018-03-01 05:56:08 --> UTF-8 Support Enabled
INFO - 2018-03-01 05:56:08 --> Utf8 Class Initialized
INFO - 2018-03-01 05:56:08 --> URI Class Initialized
INFO - 2018-03-01 05:56:08 --> Router Class Initialized
INFO - 2018-03-01 05:56:08 --> Output Class Initialized
INFO - 2018-03-01 05:56:08 --> Config Class Initialized
INFO - 2018-03-01 05:56:08 --> Hooks Class Initialized
INFO - 2018-03-01 05:56:08 --> Security Class Initialized
DEBUG - 2018-03-01 05:56:08 --> UTF-8 Support Enabled
INFO - 2018-03-01 05:56:08 --> Utf8 Class Initialized
DEBUG - 2018-03-01 05:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-01 05:56:08 --> Input Class Initialized
INFO - 2018-03-01 05:56:08 --> Language Class Initialized
INFO - 2018-03-01 05:56:08 --> URI Class Initialized
INFO - 2018-03-01 05:56:08 --> Router Class Initialized
INFO - 2018-03-01 05:56:08 --> Output Class Initialized
INFO - 2018-03-01 05:56:08 --> Security Class Initialized
DEBUG - 2018-03-01 05:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-01 05:56:08 --> Input Class Initialized
INFO - 2018-03-01 05:56:08 --> Language Class Initialized
INFO - 2018-03-01 05:56:08 --> Language Class Initialized
INFO - 2018-03-01 05:56:08 --> Config Class Initialized
INFO - 2018-03-01 05:56:08 --> Loader Class Initialized
INFO - 2018-03-01 11:26:08 --> Helper loaded: url_helper
INFO - 2018-03-01 11:26:08 --> Helper loaded: notification_helper
INFO - 2018-03-01 11:26:08 --> Helper loaded: settings_helper
INFO - 2018-03-01 11:26:08 --> Helper loaded: permission_helper
INFO - 2018-03-01 11:26:08 --> Helper loaded: users_helper
INFO - 2018-03-01 05:56:08 --> Language Class Initialized
INFO - 2018-03-01 05:56:08 --> Config Class Initialized
INFO - 2018-03-01 05:56:08 --> Loader Class Initialized
INFO - 2018-03-01 11:26:08 --> Helper loaded: url_helper
INFO - 2018-03-01 11:26:08 --> Helper loaded: notification_helper
INFO - 2018-03-01 11:26:08 --> Helper loaded: settings_helper
INFO - 2018-03-01 11:26:08 --> Helper loaded: permission_helper
INFO - 2018-03-01 11:26:08 --> Helper loaded: users_helper
INFO - 2018-03-01 11:26:08 --> Database Driver Class Initialized
DEBUG - 2018-03-01 11:26:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-01 11:26:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-01 11:26:08 --> Database Driver Class Initialized
INFO - 2018-03-01 11:26:08 --> Helper loaded: form_helper
INFO - 2018-03-01 11:26:08 --> Form Validation Class Initialized
INFO - 2018-03-01 11:26:08 --> Controller Class Initialized
DEBUG - 2018-03-01 11:26:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-01 11:26:08 --> Model Class Initialized
INFO - 2018-03-01 11:26:08 --> Helper loaded: inflector_helper
DEBUG - 2018-03-01 11:26:08 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-01 11:26:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-01 11:26:08 --> Model Class Initialized
INFO - 2018-03-01 11:26:08 --> Model Class Initialized
INFO - 2018-03-01 11:26:08 --> Model Class Initialized
INFO - 2018-03-01 11:26:08 --> Model Class Initialized
INFO - 2018-03-01 11:26:08 --> Model Class Initialized
INFO - 2018-03-01 11:26:08 --> Model Class Initialized
INFO - 2018-03-01 11:26:08 --> Model Class Initialized
INFO - 2018-03-01 11:26:08 --> Model Class Initialized
INFO - 2018-03-01 11:26:08 --> Model Class Initialized
INFO - 2018-03-01 11:26:08 --> Model Class Initialized
INFO - 2018-03-01 11:26:08 --> Model Class Initialized
INFO - 2018-03-01 11:26:08 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-01 11:26:08 --> Model Class Initialized
INFO - 2018-03-01 11:26:08 --> Final output sent to browser
DEBUG - 2018-03-01 11:26:08 --> Total execution time: 0.1422
INFO - 2018-03-01 11:26:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-01 11:26:08 --> Helper loaded: form_helper
INFO - 2018-03-01 11:26:08 --> Form Validation Class Initialized
INFO - 2018-03-01 11:26:08 --> Controller Class Initialized
INFO - 2018-03-01 11:26:08 --> Model Class Initialized
INFO - 2018-03-01 11:26:08 --> Helper loaded: inflector_helper
DEBUG - 2018-03-01 11:26:08 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-01 11:26:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-01 11:26:08 --> Model Class Initialized
INFO - 2018-03-01 11:26:08 --> Model Class Initialized
INFO - 2018-03-01 11:26:08 --> Model Class Initialized
INFO - 2018-03-01 11:26:08 --> Model Class Initialized
INFO - 2018-03-01 11:26:08 --> Model Class Initialized
INFO - 2018-03-01 11:26:08 --> Model Class Initialized
INFO - 2018-03-01 11:26:08 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-01 11:26:08 --> Model Class Initialized
INFO - 2018-03-01 11:26:08 --> Final output sent to browser
DEBUG - 2018-03-01 11:26:08 --> Total execution time: 0.1662
INFO - 2018-03-01 05:56:50 --> Config Class Initialized
INFO - 2018-03-01 05:56:50 --> Hooks Class Initialized
DEBUG - 2018-03-01 05:56:50 --> UTF-8 Support Enabled
INFO - 2018-03-01 05:56:50 --> Utf8 Class Initialized
INFO - 2018-03-01 05:56:50 --> Config Class Initialized
INFO - 2018-03-01 05:56:50 --> Hooks Class Initialized
INFO - 2018-03-01 05:56:50 --> URI Class Initialized
DEBUG - 2018-03-01 05:56:50 --> UTF-8 Support Enabled
INFO - 2018-03-01 05:56:50 --> Utf8 Class Initialized
INFO - 2018-03-01 05:56:50 --> Router Class Initialized
INFO - 2018-03-01 05:56:50 --> URI Class Initialized
INFO - 2018-03-01 05:56:50 --> Output Class Initialized
INFO - 2018-03-01 05:56:50 --> Router Class Initialized
INFO - 2018-03-01 05:56:50 --> Security Class Initialized
INFO - 2018-03-01 05:56:50 --> Output Class Initialized
DEBUG - 2018-03-01 05:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-01 05:56:50 --> Input Class Initialized
INFO - 2018-03-01 05:56:50 --> Language Class Initialized
INFO - 2018-03-01 05:56:50 --> Security Class Initialized
DEBUG - 2018-03-01 05:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-01 05:56:50 --> Input Class Initialized
INFO - 2018-03-01 05:56:50 --> Language Class Initialized
INFO - 2018-03-01 05:56:50 --> Language Class Initialized
INFO - 2018-03-01 05:56:50 --> Config Class Initialized
INFO - 2018-03-01 05:56:50 --> Loader Class Initialized
INFO - 2018-03-01 11:26:50 --> Helper loaded: url_helper
INFO - 2018-03-01 11:26:50 --> Helper loaded: notification_helper
INFO - 2018-03-01 11:26:50 --> Helper loaded: settings_helper
INFO - 2018-03-01 11:26:50 --> Helper loaded: permission_helper
INFO - 2018-03-01 11:26:50 --> Helper loaded: users_helper
INFO - 2018-03-01 05:56:50 --> Language Class Initialized
INFO - 2018-03-01 05:56:50 --> Config Class Initialized
INFO - 2018-03-01 05:56:50 --> Loader Class Initialized
INFO - 2018-03-01 11:26:50 --> Helper loaded: url_helper
INFO - 2018-03-01 11:26:50 --> Helper loaded: notification_helper
INFO - 2018-03-01 11:26:50 --> Helper loaded: settings_helper
INFO - 2018-03-01 11:26:50 --> Helper loaded: permission_helper
INFO - 2018-03-01 11:26:50 --> Helper loaded: users_helper
INFO - 2018-03-01 11:26:50 --> Database Driver Class Initialized
DEBUG - 2018-03-01 11:26:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-01 11:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-01 11:26:50 --> Database Driver Class Initialized
INFO - 2018-03-01 11:26:50 --> Helper loaded: form_helper
INFO - 2018-03-01 11:26:50 --> Form Validation Class Initialized
INFO - 2018-03-01 11:26:50 --> Controller Class Initialized
DEBUG - 2018-03-01 11:26:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-01 11:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-01 11:26:50 --> Model Class Initialized
INFO - 2018-03-01 11:26:50 --> Helper loaded: inflector_helper
INFO - 2018-03-01 11:26:50 --> Helper loaded: form_helper
INFO - 2018-03-01 11:26:50 --> Form Validation Class Initialized
INFO - 2018-03-01 11:26:50 --> Controller Class Initialized
DEBUG - 2018-03-01 11:26:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-01 11:26:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-01 11:26:50 --> Model Class Initialized
INFO - 2018-03-01 11:26:50 --> Model Class Initialized
INFO - 2018-03-01 11:26:50 --> Model Class Initialized
INFO - 2018-03-01 11:26:50 --> Model Class Initialized
INFO - 2018-03-01 11:26:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-01 11:26:50 --> Final output sent to browser
DEBUG - 2018-03-01 11:26:50 --> Total execution time: 0.1051
INFO - 2018-03-01 11:26:50 --> Model Class Initialized
INFO - 2018-03-01 11:26:50 --> Helper loaded: inflector_helper
DEBUG - 2018-03-01 11:26:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-01 11:26:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-01 11:26:50 --> Model Class Initialized
INFO - 2018-03-01 11:26:50 --> Model Class Initialized
INFO - 2018-03-01 11:26:50 --> Model Class Initialized
INFO - 2018-03-01 11:26:50 --> Model Class Initialized
INFO - 2018-03-01 11:26:50 --> Model Class Initialized
INFO - 2018-03-01 11:26:50 --> Model Class Initialized
INFO - 2018-03-01 11:26:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-01 11:26:50 --> Final output sent to browser
DEBUG - 2018-03-01 11:26:50 --> Total execution time: 0.1103
INFO - 2018-03-01 05:57:03 --> Config Class Initialized
INFO - 2018-03-01 05:57:03 --> Hooks Class Initialized
DEBUG - 2018-03-01 05:57:03 --> UTF-8 Support Enabled
INFO - 2018-03-01 05:57:03 --> Utf8 Class Initialized
INFO - 2018-03-01 05:57:03 --> URI Class Initialized
INFO - 2018-03-01 05:57:03 --> Router Class Initialized
INFO - 2018-03-01 05:57:03 --> Output Class Initialized
INFO - 2018-03-01 05:57:03 --> Security Class Initialized
DEBUG - 2018-03-01 05:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-01 05:57:03 --> Input Class Initialized
INFO - 2018-03-01 05:57:03 --> Language Class Initialized
INFO - 2018-03-01 05:57:03 --> Language Class Initialized
INFO - 2018-03-01 05:57:03 --> Config Class Initialized
INFO - 2018-03-01 05:57:03 --> Loader Class Initialized
INFO - 2018-03-01 11:27:03 --> Helper loaded: url_helper
INFO - 2018-03-01 11:27:03 --> Helper loaded: notification_helper
INFO - 2018-03-01 11:27:03 --> Helper loaded: settings_helper
INFO - 2018-03-01 11:27:03 --> Helper loaded: permission_helper
INFO - 2018-03-01 11:27:03 --> Helper loaded: users_helper
INFO - 2018-03-01 11:27:03 --> Database Driver Class Initialized
DEBUG - 2018-03-01 11:27:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-01 11:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-01 11:27:03 --> Helper loaded: form_helper
INFO - 2018-03-01 11:27:03 --> Form Validation Class Initialized
INFO - 2018-03-01 11:27:03 --> Controller Class Initialized
INFO - 2018-03-01 11:27:03 --> Model Class Initialized
INFO - 2018-03-01 11:27:03 --> Helper loaded: inflector_helper
DEBUG - 2018-03-01 11:27:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-01 11:27:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-01 11:27:03 --> Model Class Initialized
INFO - 2018-03-01 11:27:03 --> Model Class Initialized
INFO - 2018-03-01 11:27:03 --> Model Class Initialized
INFO - 2018-03-01 11:27:03 --> Model Class Initialized
INFO - 2018-03-01 11:27:03 --> Model Class Initialized
INFO - 2018-03-01 11:27:03 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-01 11:27:03 --> Model Class Initialized
INFO - 2018-03-01 11:27:03 --> Final output sent to browser
DEBUG - 2018-03-01 11:27:03 --> Total execution time: 0.1170
INFO - 2018-03-01 05:57:04 --> Config Class Initialized
INFO - 2018-03-01 05:57:04 --> Hooks Class Initialized
DEBUG - 2018-03-01 05:57:04 --> UTF-8 Support Enabled
INFO - 2018-03-01 05:57:04 --> Utf8 Class Initialized
INFO - 2018-03-01 05:57:04 --> URI Class Initialized
INFO - 2018-03-01 05:57:04 --> Router Class Initialized
INFO - 2018-03-01 05:57:04 --> Output Class Initialized
INFO - 2018-03-01 05:57:04 --> Security Class Initialized
DEBUG - 2018-03-01 05:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-01 05:57:04 --> Input Class Initialized
INFO - 2018-03-01 05:57:04 --> Language Class Initialized
INFO - 2018-03-01 05:57:04 --> Language Class Initialized
INFO - 2018-03-01 05:57:04 --> Config Class Initialized
INFO - 2018-03-01 05:57:04 --> Loader Class Initialized
INFO - 2018-03-01 11:27:04 --> Helper loaded: url_helper
INFO - 2018-03-01 11:27:04 --> Helper loaded: notification_helper
INFO - 2018-03-01 11:27:04 --> Helper loaded: settings_helper
INFO - 2018-03-01 11:27:04 --> Helper loaded: permission_helper
INFO - 2018-03-01 11:27:04 --> Helper loaded: users_helper
INFO - 2018-03-01 11:27:04 --> Database Driver Class Initialized
DEBUG - 2018-03-01 11:27:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-01 11:27:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-01 11:27:04 --> Helper loaded: form_helper
INFO - 2018-03-01 11:27:04 --> Form Validation Class Initialized
INFO - 2018-03-01 11:27:04 --> Controller Class Initialized
INFO - 2018-03-01 11:27:04 --> Model Class Initialized
INFO - 2018-03-01 11:27:04 --> Helper loaded: inflector_helper
DEBUG - 2018-03-01 11:27:04 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-01 11:27:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-01 11:27:04 --> Model Class Initialized
INFO - 2018-03-01 11:27:04 --> Model Class Initialized
INFO - 2018-03-01 11:27:04 --> Model Class Initialized
INFO - 2018-03-01 11:27:04 --> Model Class Initialized
INFO - 2018-03-01 11:27:04 --> Model Class Initialized
INFO - 2018-03-01 11:27:04 --> Model Class Initialized
INFO - 2018-03-01 11:27:04 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-01 11:27:04 --> Final output sent to browser
DEBUG - 2018-03-01 11:27:04 --> Total execution time: 0.1192
INFO - 2018-03-01 05:59:18 --> Config Class Initialized
INFO - 2018-03-01 05:59:18 --> Hooks Class Initialized
DEBUG - 2018-03-01 05:59:18 --> UTF-8 Support Enabled
INFO - 2018-03-01 05:59:18 --> Utf8 Class Initialized
INFO - 2018-03-01 05:59:18 --> URI Class Initialized
INFO - 2018-03-01 05:59:18 --> Router Class Initialized
INFO - 2018-03-01 05:59:18 --> Output Class Initialized
INFO - 2018-03-01 05:59:18 --> Security Class Initialized
DEBUG - 2018-03-01 05:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-01 05:59:18 --> Input Class Initialized
INFO - 2018-03-01 05:59:18 --> Language Class Initialized
INFO - 2018-03-01 05:59:18 --> Language Class Initialized
INFO - 2018-03-01 05:59:18 --> Config Class Initialized
INFO - 2018-03-01 05:59:18 --> Loader Class Initialized
INFO - 2018-03-01 11:29:18 --> Helper loaded: url_helper
INFO - 2018-03-01 11:29:18 --> Helper loaded: notification_helper
INFO - 2018-03-01 11:29:18 --> Helper loaded: settings_helper
INFO - 2018-03-01 11:29:18 --> Helper loaded: permission_helper
INFO - 2018-03-01 11:29:18 --> Helper loaded: users_helper
INFO - 2018-03-01 11:29:18 --> Database Driver Class Initialized
DEBUG - 2018-03-01 11:29:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-01 11:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-01 11:29:18 --> Helper loaded: form_helper
INFO - 2018-03-01 11:29:18 --> Form Validation Class Initialized
INFO - 2018-03-01 11:29:18 --> Controller Class Initialized
INFO - 2018-03-01 11:29:18 --> Model Class Initialized
INFO - 2018-03-01 11:29:18 --> Helper loaded: inflector_helper
DEBUG - 2018-03-01 11:29:18 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-01 11:29:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-01 11:29:18 --> Model Class Initialized
INFO - 2018-03-01 11:29:18 --> Model Class Initialized
INFO - 2018-03-01 11:29:18 --> Model Class Initialized
INFO - 2018-03-01 11:29:18 --> Model Class Initialized
INFO - 2018-03-01 11:29:18 --> Model Class Initialized
INFO - 2018-03-01 11:29:18 --> Model Class Initialized
INFO - 2018-03-01 11:29:18 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-01 11:29:18 --> Upload Class Initialized
INFO - 2018-03-01 11:29:18 --> Final output sent to browser
DEBUG - 2018-03-01 11:29:18 --> Total execution time: 0.1146
INFO - 2018-03-01 05:59:19 --> Config Class Initialized
INFO - 2018-03-01 05:59:19 --> Hooks Class Initialized
DEBUG - 2018-03-01 05:59:19 --> UTF-8 Support Enabled
INFO - 2018-03-01 05:59:19 --> Utf8 Class Initialized
INFO - 2018-03-01 05:59:19 --> URI Class Initialized
INFO - 2018-03-01 05:59:19 --> Router Class Initialized
INFO - 2018-03-01 05:59:19 --> Output Class Initialized
INFO - 2018-03-01 05:59:19 --> Security Class Initialized
DEBUG - 2018-03-01 05:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-01 05:59:19 --> Input Class Initialized
INFO - 2018-03-01 05:59:19 --> Language Class Initialized
INFO - 2018-03-01 05:59:19 --> Language Class Initialized
INFO - 2018-03-01 05:59:19 --> Config Class Initialized
INFO - 2018-03-01 05:59:19 --> Loader Class Initialized
INFO - 2018-03-01 11:29:19 --> Helper loaded: url_helper
INFO - 2018-03-01 11:29:19 --> Helper loaded: notification_helper
INFO - 2018-03-01 11:29:19 --> Helper loaded: settings_helper
INFO - 2018-03-01 11:29:19 --> Helper loaded: permission_helper
INFO - 2018-03-01 11:29:19 --> Helper loaded: users_helper
INFO - 2018-03-01 11:29:19 --> Database Driver Class Initialized
DEBUG - 2018-03-01 11:29:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-01 11:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-01 11:29:19 --> Helper loaded: form_helper
INFO - 2018-03-01 11:29:19 --> Form Validation Class Initialized
INFO - 2018-03-01 11:29:19 --> Controller Class Initialized
INFO - 2018-03-01 11:29:19 --> Model Class Initialized
INFO - 2018-03-01 11:29:19 --> Helper loaded: inflector_helper
DEBUG - 2018-03-01 11:29:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-01 11:29:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-01 11:29:19 --> Model Class Initialized
INFO - 2018-03-01 11:29:19 --> Model Class Initialized
INFO - 2018-03-01 11:29:19 --> Model Class Initialized
INFO - 2018-03-01 11:29:19 --> Model Class Initialized
INFO - 2018-03-01 11:29:19 --> Model Class Initialized
INFO - 2018-03-01 11:29:19 --> Model Class Initialized
INFO - 2018-03-01 11:29:19 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-01 11:29:19 --> Final output sent to browser
DEBUG - 2018-03-01 11:29:19 --> Total execution time: 0.1144
INFO - 2018-03-01 05:59:22 --> Config Class Initialized
INFO - 2018-03-01 05:59:22 --> Hooks Class Initialized
DEBUG - 2018-03-01 05:59:22 --> UTF-8 Support Enabled
INFO - 2018-03-01 05:59:22 --> Utf8 Class Initialized
INFO - 2018-03-01 05:59:22 --> URI Class Initialized
INFO - 2018-03-01 05:59:22 --> Router Class Initialized
INFO - 2018-03-01 05:59:22 --> Output Class Initialized
INFO - 2018-03-01 05:59:22 --> Security Class Initialized
DEBUG - 2018-03-01 05:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-01 05:59:22 --> Input Class Initialized
INFO - 2018-03-01 05:59:22 --> Language Class Initialized
INFO - 2018-03-01 05:59:22 --> Language Class Initialized
INFO - 2018-03-01 05:59:22 --> Config Class Initialized
INFO - 2018-03-01 05:59:22 --> Loader Class Initialized
INFO - 2018-03-01 11:29:22 --> Helper loaded: url_helper
INFO - 2018-03-01 11:29:22 --> Helper loaded: notification_helper
INFO - 2018-03-01 11:29:22 --> Helper loaded: settings_helper
INFO - 2018-03-01 11:29:22 --> Helper loaded: permission_helper
INFO - 2018-03-01 11:29:22 --> Helper loaded: users_helper
INFO - 2018-03-01 11:29:22 --> Database Driver Class Initialized
DEBUG - 2018-03-01 11:29:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-01 11:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-01 11:29:22 --> Helper loaded: form_helper
INFO - 2018-03-01 11:29:22 --> Form Validation Class Initialized
INFO - 2018-03-01 11:29:22 --> Controller Class Initialized
INFO - 2018-03-01 11:29:22 --> Model Class Initialized
INFO - 2018-03-01 11:29:22 --> Helper loaded: inflector_helper
DEBUG - 2018-03-01 11:29:22 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-01 11:29:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-01 11:29:22 --> Model Class Initialized
INFO - 2018-03-01 11:29:22 --> Model Class Initialized
INFO - 2018-03-01 11:29:22 --> Model Class Initialized
INFO - 2018-03-01 11:29:22 --> Model Class Initialized
INFO - 2018-03-01 11:29:22 --> Model Class Initialized
INFO - 2018-03-01 11:29:22 --> Model Class Initialized
INFO - 2018-03-01 11:29:22 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-01 11:29:22 --> Final output sent to browser
DEBUG - 2018-03-01 11:29:22 --> Total execution time: 0.0874
INFO - 2018-03-01 06:24:42 --> Config Class Initialized
INFO - 2018-03-01 06:24:42 --> Hooks Class Initialized
DEBUG - 2018-03-01 06:24:42 --> UTF-8 Support Enabled
INFO - 2018-03-01 06:24:42 --> Utf8 Class Initialized
INFO - 2018-03-01 06:24:42 --> URI Class Initialized
INFO - 2018-03-01 06:24:42 --> Router Class Initialized
INFO - 2018-03-01 06:24:42 --> Output Class Initialized
INFO - 2018-03-01 06:24:42 --> Security Class Initialized
DEBUG - 2018-03-01 06:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-01 06:24:42 --> Input Class Initialized
INFO - 2018-03-01 06:24:42 --> Language Class Initialized
INFO - 2018-03-01 06:24:42 --> Language Class Initialized
INFO - 2018-03-01 06:24:42 --> Config Class Initialized
INFO - 2018-03-01 06:24:42 --> Loader Class Initialized
INFO - 2018-03-01 11:54:42 --> Helper loaded: url_helper
INFO - 2018-03-01 11:54:42 --> Helper loaded: notification_helper
INFO - 2018-03-01 11:54:42 --> Helper loaded: settings_helper
INFO - 2018-03-01 11:54:42 --> Helper loaded: permission_helper
INFO - 2018-03-01 11:54:42 --> Helper loaded: users_helper
INFO - 2018-03-01 11:54:42 --> Database Driver Class Initialized
DEBUG - 2018-03-01 11:54:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-01 11:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-01 11:54:42 --> Helper loaded: form_helper
INFO - 2018-03-01 11:54:42 --> Form Validation Class Initialized
INFO - 2018-03-01 11:54:42 --> Controller Class Initialized
INFO - 2018-03-01 11:54:42 --> Model Class Initialized
INFO - 2018-03-01 11:54:42 --> Helper loaded: inflector_helper
DEBUG - 2018-03-01 11:54:42 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-01 11:54:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-01 11:54:42 --> Model Class Initialized
INFO - 2018-03-01 11:54:42 --> Model Class Initialized
INFO - 2018-03-01 11:54:42 --> Model Class Initialized
INFO - 2018-03-01 11:54:42 --> Model Class Initialized
INFO - 2018-03-01 11:54:42 --> Model Class Initialized
INFO - 2018-03-01 11:54:42 --> Model Class Initialized
INFO - 2018-03-01 11:54:42 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-01 11:54:42 --> Model Class Initialized
INFO - 2018-03-01 11:54:42 --> Final output sent to browser
DEBUG - 2018-03-01 11:54:42 --> Total execution time: 0.1205
INFO - 2018-03-01 06:24:46 --> Config Class Initialized
INFO - 2018-03-01 06:24:46 --> Hooks Class Initialized
DEBUG - 2018-03-01 06:24:46 --> UTF-8 Support Enabled
INFO - 2018-03-01 06:24:46 --> Utf8 Class Initialized
INFO - 2018-03-01 06:24:46 --> URI Class Initialized
INFO - 2018-03-01 06:24:46 --> Router Class Initialized
INFO - 2018-03-01 06:24:46 --> Output Class Initialized
INFO - 2018-03-01 06:24:46 --> Security Class Initialized
DEBUG - 2018-03-01 06:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-01 06:24:46 --> Input Class Initialized
INFO - 2018-03-01 06:24:46 --> Language Class Initialized
INFO - 2018-03-01 06:24:46 --> Language Class Initialized
INFO - 2018-03-01 06:24:46 --> Config Class Initialized
INFO - 2018-03-01 06:24:46 --> Loader Class Initialized
INFO - 2018-03-01 11:54:46 --> Helper loaded: url_helper
INFO - 2018-03-01 11:54:46 --> Helper loaded: notification_helper
INFO - 2018-03-01 11:54:46 --> Helper loaded: settings_helper
INFO - 2018-03-01 11:54:46 --> Helper loaded: permission_helper
INFO - 2018-03-01 11:54:46 --> Helper loaded: users_helper
INFO - 2018-03-01 11:54:46 --> Database Driver Class Initialized
DEBUG - 2018-03-01 11:54:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-01 11:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-01 11:54:46 --> Helper loaded: form_helper
INFO - 2018-03-01 11:54:46 --> Form Validation Class Initialized
INFO - 2018-03-01 11:54:46 --> Controller Class Initialized
INFO - 2018-03-01 11:54:46 --> Model Class Initialized
INFO - 2018-03-01 11:54:46 --> Helper loaded: inflector_helper
DEBUG - 2018-03-01 11:54:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-01 11:54:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-01 11:54:46 --> Model Class Initialized
INFO - 2018-03-01 11:54:46 --> Model Class Initialized
INFO - 2018-03-01 11:54:46 --> Model Class Initialized
INFO - 2018-03-01 11:54:46 --> Model Class Initialized
INFO - 2018-03-01 11:54:46 --> Model Class Initialized
INFO - 2018-03-01 11:54:46 --> Model Class Initialized
INFO - 2018-03-01 11:54:46 --> Model Class Initialized
INFO - 2018-03-01 11:54:46 --> Model Class Initialized
INFO - 2018-03-01 11:54:46 --> Model Class Initialized
INFO - 2018-03-01 11:54:46 --> Model Class Initialized
INFO - 2018-03-01 11:54:46 --> Model Class Initialized
INFO - 2018-03-01 11:54:46 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-01 11:54:46 --> Model Class Initialized
INFO - 2018-03-01 11:54:46 --> Final output sent to browser
DEBUG - 2018-03-01 11:54:46 --> Total execution time: 0.1287
INFO - 2018-03-01 06:25:07 --> Config Class Initialized
INFO - 2018-03-01 06:25:07 --> Hooks Class Initialized
DEBUG - 2018-03-01 06:25:07 --> UTF-8 Support Enabled
INFO - 2018-03-01 06:25:07 --> Utf8 Class Initialized
INFO - 2018-03-01 06:25:07 --> URI Class Initialized
INFO - 2018-03-01 06:25:07 --> Router Class Initialized
INFO - 2018-03-01 06:25:07 --> Output Class Initialized
INFO - 2018-03-01 06:25:07 --> Config Class Initialized
INFO - 2018-03-01 06:25:07 --> Hooks Class Initialized
INFO - 2018-03-01 06:25:07 --> Security Class Initialized
DEBUG - 2018-03-01 06:25:07 --> UTF-8 Support Enabled
INFO - 2018-03-01 06:25:07 --> Utf8 Class Initialized
DEBUG - 2018-03-01 06:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-01 06:25:07 --> Input Class Initialized
INFO - 2018-03-01 06:25:07 --> Language Class Initialized
INFO - 2018-03-01 06:25:07 --> URI Class Initialized
INFO - 2018-03-01 06:25:07 --> Router Class Initialized
INFO - 2018-03-01 06:25:07 --> Output Class Initialized
INFO - 2018-03-01 06:25:07 --> Language Class Initialized
INFO - 2018-03-01 06:25:07 --> Config Class Initialized
INFO - 2018-03-01 06:25:07 --> Loader Class Initialized
INFO - 2018-03-01 06:25:07 --> Security Class Initialized
INFO - 2018-03-01 11:55:07 --> Helper loaded: url_helper
INFO - 2018-03-01 11:55:07 --> Helper loaded: notification_helper
INFO - 2018-03-01 11:55:07 --> Helper loaded: settings_helper
INFO - 2018-03-01 11:55:07 --> Helper loaded: permission_helper
INFO - 2018-03-01 11:55:07 --> Helper loaded: users_helper
DEBUG - 2018-03-01 06:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-01 06:25:07 --> Input Class Initialized
INFO - 2018-03-01 06:25:07 --> Language Class Initialized
INFO - 2018-03-01 11:55:07 --> Database Driver Class Initialized
DEBUG - 2018-03-01 11:55:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-01 11:55:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-01 11:55:07 --> Helper loaded: form_helper
INFO - 2018-03-01 11:55:07 --> Form Validation Class Initialized
INFO - 2018-03-01 11:55:07 --> Controller Class Initialized
INFO - 2018-03-01 06:25:07 --> Language Class Initialized
INFO - 2018-03-01 06:25:07 --> Config Class Initialized
INFO - 2018-03-01 06:25:07 --> Loader Class Initialized
INFO - 2018-03-01 11:55:07 --> Model Class Initialized
INFO - 2018-03-01 11:55:07 --> Helper loaded: inflector_helper
INFO - 2018-03-01 11:55:07 --> Helper loaded: url_helper
DEBUG - 2018-03-01 11:55:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-01 11:55:07 --> Helper loaded: notification_helper
INFO - 2018-03-01 11:55:07 --> Helper loaded: settings_helper
INFO - 2018-03-01 11:55:07 --> Helper loaded: permission_helper
INFO - 2018-03-01 11:55:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-01 11:55:07 --> Helper loaded: users_helper
INFO - 2018-03-01 11:55:07 --> Model Class Initialized
INFO - 2018-03-01 11:55:07 --> Model Class Initialized
INFO - 2018-03-01 11:55:07 --> Model Class Initialized
INFO - 2018-03-01 11:55:07 --> Model Class Initialized
INFO - 2018-03-01 11:55:07 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-01 11:55:07 --> Final output sent to browser
DEBUG - 2018-03-01 11:55:07 --> Total execution time: 0.1009
INFO - 2018-03-01 11:55:07 --> Database Driver Class Initialized
DEBUG - 2018-03-01 11:55:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-01 11:55:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-01 11:55:07 --> Helper loaded: form_helper
INFO - 2018-03-01 11:55:07 --> Form Validation Class Initialized
INFO - 2018-03-01 11:55:07 --> Controller Class Initialized
INFO - 2018-03-01 11:55:07 --> Model Class Initialized
INFO - 2018-03-01 11:55:07 --> Helper loaded: inflector_helper
DEBUG - 2018-03-01 11:55:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-01 11:55:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-01 11:55:07 --> Model Class Initialized
INFO - 2018-03-01 11:55:07 --> Model Class Initialized
INFO - 2018-03-01 11:55:07 --> Model Class Initialized
INFO - 2018-03-01 11:55:07 --> Model Class Initialized
INFO - 2018-03-01 11:55:07 --> Model Class Initialized
INFO - 2018-03-01 11:55:07 --> Model Class Initialized
INFO - 2018-03-01 11:55:07 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-01 11:55:07 --> Final output sent to browser
DEBUG - 2018-03-01 11:55:07 --> Total execution time: 0.1435
INFO - 2018-03-01 06:47:29 --> Config Class Initialized
INFO - 2018-03-01 06:47:29 --> Hooks Class Initialized
DEBUG - 2018-03-01 06:47:29 --> UTF-8 Support Enabled
INFO - 2018-03-01 06:47:29 --> Utf8 Class Initialized
INFO - 2018-03-01 06:47:29 --> URI Class Initialized
INFO - 2018-03-01 06:47:29 --> Router Class Initialized
INFO - 2018-03-01 06:47:29 --> Output Class Initialized
INFO - 2018-03-01 06:47:29 --> Security Class Initialized
DEBUG - 2018-03-01 06:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-01 06:47:29 --> Input Class Initialized
INFO - 2018-03-01 06:47:29 --> Language Class Initialized
INFO - 2018-03-01 06:47:29 --> Language Class Initialized
INFO - 2018-03-01 06:47:29 --> Config Class Initialized
INFO - 2018-03-01 06:47:29 --> Loader Class Initialized
INFO - 2018-03-01 12:17:29 --> Helper loaded: url_helper
INFO - 2018-03-01 12:17:29 --> Helper loaded: notification_helper
INFO - 2018-03-01 12:17:29 --> Helper loaded: settings_helper
INFO - 2018-03-01 12:17:29 --> Helper loaded: permission_helper
INFO - 2018-03-01 12:17:29 --> Helper loaded: users_helper
INFO - 2018-03-01 12:17:29 --> Database Driver Class Initialized
DEBUG - 2018-03-01 12:17:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-01 12:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-01 12:17:29 --> Helper loaded: form_helper
INFO - 2018-03-01 12:17:29 --> Form Validation Class Initialized
INFO - 2018-03-01 12:17:29 --> Controller Class Initialized
INFO - 2018-03-01 12:17:29 --> Model Class Initialized
INFO - 2018-03-01 12:17:29 --> Helper loaded: inflector_helper
DEBUG - 2018-03-01 12:17:29 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-01 12:17:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-01 12:17:29 --> Model Class Initialized
INFO - 2018-03-01 12:17:29 --> Model Class Initialized
INFO - 2018-03-01 12:17:29 --> Model Class Initialized
INFO - 2018-03-01 12:17:29 --> Model Class Initialized
INFO - 2018-03-01 12:17:29 --> Model Class Initialized
INFO - 2018-03-01 12:17:29 --> Model Class Initialized
INFO - 2018-03-01 12:17:29 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-01 12:17:29 --> Final output sent to browser
DEBUG - 2018-03-01 12:17:29 --> Total execution time: 0.1147
INFO - 2018-03-01 06:48:08 --> Config Class Initialized
INFO - 2018-03-01 06:48:08 --> Hooks Class Initialized
DEBUG - 2018-03-01 06:48:08 --> UTF-8 Support Enabled
INFO - 2018-03-01 06:48:08 --> Utf8 Class Initialized
INFO - 2018-03-01 06:48:08 --> URI Class Initialized
INFO - 2018-03-01 06:48:08 --> Router Class Initialized
INFO - 2018-03-01 06:48:08 --> Output Class Initialized
INFO - 2018-03-01 06:48:08 --> Security Class Initialized
DEBUG - 2018-03-01 06:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-01 06:48:08 --> Input Class Initialized
INFO - 2018-03-01 06:48:08 --> Language Class Initialized
INFO - 2018-03-01 06:48:08 --> Language Class Initialized
INFO - 2018-03-01 06:48:08 --> Config Class Initialized
INFO - 2018-03-01 06:48:08 --> Loader Class Initialized
INFO - 2018-03-01 12:18:08 --> Helper loaded: url_helper
INFO - 2018-03-01 12:18:08 --> Helper loaded: notification_helper
INFO - 2018-03-01 12:18:08 --> Helper loaded: settings_helper
INFO - 2018-03-01 12:18:08 --> Helper loaded: permission_helper
INFO - 2018-03-01 12:18:08 --> Helper loaded: users_helper
INFO - 2018-03-01 12:18:08 --> Database Driver Class Initialized
DEBUG - 2018-03-01 12:18:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-01 12:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-01 12:18:08 --> Helper loaded: form_helper
INFO - 2018-03-01 12:18:08 --> Form Validation Class Initialized
INFO - 2018-03-01 12:18:08 --> Controller Class Initialized
INFO - 2018-03-01 12:18:08 --> Model Class Initialized
INFO - 2018-03-01 12:18:08 --> Helper loaded: inflector_helper
DEBUG - 2018-03-01 12:18:08 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-01 12:18:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-01 12:18:08 --> Model Class Initialized
INFO - 2018-03-01 12:18:08 --> Model Class Initialized
INFO - 2018-03-01 12:18:08 --> Model Class Initialized
INFO - 2018-03-01 12:18:08 --> Model Class Initialized
INFO - 2018-03-01 12:18:08 --> Model Class Initialized
INFO - 2018-03-01 12:18:08 --> Model Class Initialized
INFO - 2018-03-01 12:18:08 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-01 12:18:08 --> Final output sent to browser
DEBUG - 2018-03-01 12:18:08 --> Total execution time: 0.1135
