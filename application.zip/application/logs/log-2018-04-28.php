<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-04-28 07:25:37 --> Config Class Initialized
INFO - 2018-04-28 07:25:37 --> Hooks Class Initialized
DEBUG - 2018-04-28 07:25:37 --> UTF-8 Support Enabled
INFO - 2018-04-28 07:25:37 --> Utf8 Class Initialized
INFO - 2018-04-28 07:25:37 --> URI Class Initialized
INFO - 2018-04-28 07:25:37 --> Router Class Initialized
INFO - 2018-04-28 07:25:37 --> Output Class Initialized
INFO - 2018-04-28 07:25:37 --> Security Class Initialized
DEBUG - 2018-04-28 07:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-28 07:25:37 --> Input Class Initialized
INFO - 2018-04-28 07:25:37 --> Language Class Initialized
INFO - 2018-04-28 07:25:38 --> Language Class Initialized
INFO - 2018-04-28 07:25:38 --> Config Class Initialized
INFO - 2018-04-28 07:25:38 --> Loader Class Initialized
INFO - 2018-04-28 12:55:38 --> Helper loaded: url_helper
INFO - 2018-04-28 12:55:38 --> Helper loaded: notification_helper
INFO - 2018-04-28 12:55:38 --> Helper loaded: settings_helper
INFO - 2018-04-28 12:55:38 --> Helper loaded: permission_helper
INFO - 2018-04-28 12:55:38 --> Helper loaded: users_helper
INFO - 2018-04-28 12:55:38 --> Database Driver Class Initialized
DEBUG - 2018-04-28 12:55:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-28 12:55:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-28 12:55:38 --> Helper loaded: form_helper
INFO - 2018-04-28 12:55:38 --> Form Validation Class Initialized
INFO - 2018-04-28 12:55:38 --> Controller Class Initialized
INFO - 2018-04-28 12:55:38 --> Model Class Initialized
INFO - 2018-04-28 12:55:38 --> Helper loaded: inflector_helper
DEBUG - 2018-04-28 12:55:38 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-28 12:55:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-28 12:55:38 --> Model Class Initialized
INFO - 2018-04-28 12:55:38 --> Model Class Initialized
INFO - 2018-04-28 12:55:38 --> Model Class Initialized
INFO - 2018-04-28 12:55:38 --> Model Class Initialized
INFO - 2018-04-28 12:55:38 --> Model Class Initialized
INFO - 2018-04-28 12:55:38 --> Model Class Initialized
INFO - 2018-04-28 12:55:38 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-28 12:55:38 --> Final output sent to browser
DEBUG - 2018-04-28 12:55:38 --> Total execution time: 0.5969
INFO - 2018-04-28 07:25:39 --> Config Class Initialized
INFO - 2018-04-28 07:25:39 --> Hooks Class Initialized
DEBUG - 2018-04-28 07:25:39 --> UTF-8 Support Enabled
INFO - 2018-04-28 07:25:39 --> Utf8 Class Initialized
INFO - 2018-04-28 07:25:39 --> URI Class Initialized
INFO - 2018-04-28 07:25:39 --> Router Class Initialized
INFO - 2018-04-28 07:25:39 --> Output Class Initialized
INFO - 2018-04-28 07:25:39 --> Security Class Initialized
DEBUG - 2018-04-28 07:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-28 07:25:39 --> Input Class Initialized
INFO - 2018-04-28 07:25:39 --> Language Class Initialized
INFO - 2018-04-28 07:25:39 --> Language Class Initialized
INFO - 2018-04-28 07:25:39 --> Config Class Initialized
INFO - 2018-04-28 07:25:39 --> Loader Class Initialized
INFO - 2018-04-28 12:55:39 --> Helper loaded: url_helper
INFO - 2018-04-28 12:55:39 --> Helper loaded: notification_helper
INFO - 2018-04-28 12:55:39 --> Helper loaded: settings_helper
INFO - 2018-04-28 12:55:39 --> Helper loaded: permission_helper
INFO - 2018-04-28 12:55:39 --> Helper loaded: users_helper
INFO - 2018-04-28 12:55:39 --> Database Driver Class Initialized
DEBUG - 2018-04-28 12:55:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-28 12:55:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-28 12:55:39 --> Helper loaded: form_helper
INFO - 2018-04-28 12:55:39 --> Form Validation Class Initialized
INFO - 2018-04-28 12:55:39 --> Controller Class Initialized
INFO - 2018-04-28 12:55:39 --> Model Class Initialized
INFO - 2018-04-28 12:55:39 --> Helper loaded: inflector_helper
DEBUG - 2018-04-28 12:55:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-28 12:55:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-28 12:55:39 --> Model Class Initialized
INFO - 2018-04-28 12:55:39 --> Model Class Initialized
INFO - 2018-04-28 12:55:39 --> Model Class Initialized
INFO - 2018-04-28 12:55:39 --> Model Class Initialized
INFO - 2018-04-28 12:55:39 --> Model Class Initialized
INFO - 2018-04-28 12:55:39 --> Model Class Initialized
INFO - 2018-04-28 12:55:39 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-28 12:55:39 --> Final output sent to browser
DEBUG - 2018-04-28 12:55:39 --> Total execution time: 0.2893
INFO - 2018-04-28 07:25:39 --> Config Class Initialized
INFO - 2018-04-28 07:25:39 --> Hooks Class Initialized
DEBUG - 2018-04-28 07:25:39 --> UTF-8 Support Enabled
INFO - 2018-04-28 07:25:39 --> Utf8 Class Initialized
INFO - 2018-04-28 07:25:39 --> URI Class Initialized
INFO - 2018-04-28 07:25:39 --> Router Class Initialized
INFO - 2018-04-28 07:25:39 --> Output Class Initialized
INFO - 2018-04-28 07:25:39 --> Security Class Initialized
DEBUG - 2018-04-28 07:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-28 07:25:39 --> Input Class Initialized
INFO - 2018-04-28 07:25:39 --> Language Class Initialized
INFO - 2018-04-28 07:25:39 --> Config Class Initialized
INFO - 2018-04-28 07:25:39 --> Hooks Class Initialized
INFO - 2018-04-28 07:25:39 --> Config Class Initialized
INFO - 2018-04-28 07:25:39 --> Hooks Class Initialized
DEBUG - 2018-04-28 07:25:39 --> UTF-8 Support Enabled
INFO - 2018-04-28 07:25:39 --> Utf8 Class Initialized
DEBUG - 2018-04-28 07:25:39 --> UTF-8 Support Enabled
INFO - 2018-04-28 07:25:39 --> Utf8 Class Initialized
INFO - 2018-04-28 07:25:39 --> URI Class Initialized
INFO - 2018-04-28 07:25:39 --> URI Class Initialized
INFO - 2018-04-28 07:25:39 --> Language Class Initialized
INFO - 2018-04-28 07:25:39 --> Config Class Initialized
INFO - 2018-04-28 07:25:39 --> Loader Class Initialized
INFO - 2018-04-28 07:25:39 --> Config Class Initialized
INFO - 2018-04-28 07:25:39 --> Hooks Class Initialized
INFO - 2018-04-28 12:55:39 --> Helper loaded: url_helper
INFO - 2018-04-28 12:55:39 --> Helper loaded: notification_helper
INFO - 2018-04-28 07:25:39 --> Router Class Initialized
INFO - 2018-04-28 12:55:39 --> Helper loaded: settings_helper
INFO - 2018-04-28 12:55:39 --> Helper loaded: permission_helper
INFO - 2018-04-28 12:55:39 --> Helper loaded: users_helper
DEBUG - 2018-04-28 07:25:39 --> UTF-8 Support Enabled
INFO - 2018-04-28 07:25:39 --> Utf8 Class Initialized
INFO - 2018-04-28 07:25:39 --> Output Class Initialized
INFO - 2018-04-28 07:25:39 --> URI Class Initialized
INFO - 2018-04-28 07:25:39 --> Router Class Initialized
INFO - 2018-04-28 07:25:39 --> Security Class Initialized
DEBUG - 2018-04-28 07:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-28 07:25:39 --> Input Class Initialized
INFO - 2018-04-28 07:25:39 --> Router Class Initialized
INFO - 2018-04-28 07:25:39 --> Language Class Initialized
INFO - 2018-04-28 07:25:39 --> Output Class Initialized
INFO - 2018-04-28 12:55:39 --> Database Driver Class Initialized
INFO - 2018-04-28 07:25:39 --> Output Class Initialized
DEBUG - 2018-04-28 12:55:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-28 12:55:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-28 07:25:39 --> Security Class Initialized
INFO - 2018-04-28 07:25:39 --> Security Class Initialized
DEBUG - 2018-04-28 07:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-28 07:25:39 --> Input Class Initialized
INFO - 2018-04-28 12:55:39 --> Helper loaded: form_helper
INFO - 2018-04-28 12:55:39 --> Form Validation Class Initialized
DEBUG - 2018-04-28 07:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-28 12:55:39 --> Controller Class Initialized
INFO - 2018-04-28 07:25:39 --> Input Class Initialized
INFO - 2018-04-28 07:25:39 --> Language Class Initialized
INFO - 2018-04-28 07:25:39 --> Language Class Initialized
INFO - 2018-04-28 12:55:39 --> Model Class Initialized
INFO - 2018-04-28 12:55:39 --> Helper loaded: inflector_helper
INFO - 2018-04-28 07:25:39 --> Language Class Initialized
INFO - 2018-04-28 07:25:39 --> Config Class Initialized
INFO - 2018-04-28 07:25:39 --> Loader Class Initialized
DEBUG - 2018-04-28 12:55:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-28 12:55:39 --> Helper loaded: url_helper
INFO - 2018-04-28 12:55:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-28 12:55:39 --> Model Class Initialized
INFO - 2018-04-28 12:55:39 --> Model Class Initialized
INFO - 2018-04-28 12:55:39 --> Helper loaded: notification_helper
INFO - 2018-04-28 12:55:39 --> Model Class Initialized
INFO - 2018-04-28 12:55:39 --> Model Class Initialized
INFO - 2018-04-28 12:55:39 --> Helper loaded: settings_helper
INFO - 2018-04-28 12:55:39 --> Model Class Initialized
INFO - 2018-04-28 12:55:39 --> Model Class Initialized
INFO - 2018-04-28 12:55:39 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-28 12:55:39 --> Helper loaded: permission_helper
INFO - 2018-04-28 12:55:39 --> Helper loaded: users_helper
INFO - 2018-04-28 12:55:39 --> Model Class Initialized
INFO - 2018-04-28 12:55:39 --> Final output sent to browser
DEBUG - 2018-04-28 12:55:39 --> Total execution time: 0.2333
INFO - 2018-04-28 07:25:39 --> Language Class Initialized
INFO - 2018-04-28 07:25:39 --> Config Class Initialized
INFO - 2018-04-28 07:25:39 --> Loader Class Initialized
INFO - 2018-04-28 12:55:39 --> Helper loaded: url_helper
INFO - 2018-04-28 12:55:39 --> Helper loaded: notification_helper
INFO - 2018-04-28 12:55:39 --> Helper loaded: settings_helper
INFO - 2018-04-28 12:55:39 --> Helper loaded: permission_helper
INFO - 2018-04-28 12:55:39 --> Helper loaded: users_helper
INFO - 2018-04-28 12:55:39 --> Database Driver Class Initialized
DEBUG - 2018-04-28 12:55:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-28 12:55:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-28 12:55:39 --> Helper loaded: form_helper
INFO - 2018-04-28 12:55:39 --> Form Validation Class Initialized
INFO - 2018-04-28 12:55:39 --> Controller Class Initialized
INFO - 2018-04-28 07:25:39 --> Language Class Initialized
INFO - 2018-04-28 07:25:39 --> Config Class Initialized
INFO - 2018-04-28 07:25:39 --> Loader Class Initialized
INFO - 2018-04-28 12:55:39 --> Model Class Initialized
INFO - 2018-04-28 12:55:39 --> Helper loaded: inflector_helper
DEBUG - 2018-04-28 12:55:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-28 12:55:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-28 12:55:39 --> Model Class Initialized
INFO - 2018-04-28 12:55:39 --> Model Class Initialized
INFO - 2018-04-28 12:55:39 --> Helper loaded: url_helper
INFO - 2018-04-28 12:55:39 --> Model Class Initialized
INFO - 2018-04-28 12:55:39 --> Model Class Initialized
INFO - 2018-04-28 12:55:39 --> Model Class Initialized
INFO - 2018-04-28 12:55:39 --> Model Class Initialized
INFO - 2018-04-28 12:55:39 --> Model Class Initialized
INFO - 2018-04-28 12:55:39 --> Model Class Initialized
INFO - 2018-04-28 12:55:39 --> Model Class Initialized
INFO - 2018-04-28 12:55:39 --> Model Class Initialized
INFO - 2018-04-28 12:55:39 --> Helper loaded: notification_helper
INFO - 2018-04-28 12:55:39 --> Model Class Initialized
INFO - 2018-04-28 12:55:39 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-28 12:55:39 --> Helper loaded: settings_helper
INFO - 2018-04-28 12:55:39 --> Model Class Initialized
INFO - 2018-04-28 12:55:39 --> Helper loaded: permission_helper
INFO - 2018-04-28 12:55:39 --> Helper loaded: users_helper
INFO - 2018-04-28 12:55:39 --> Database Driver Class Initialized
DEBUG - 2018-04-28 12:55:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-28 12:55:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-28 12:55:40 --> Helper loaded: form_helper
INFO - 2018-04-28 12:55:40 --> Form Validation Class Initialized
INFO - 2018-04-28 12:55:40 --> Controller Class Initialized
INFO - 2018-04-28 12:55:40 --> Final output sent to browser
DEBUG - 2018-04-28 12:55:40 --> Total execution time: 0.2815
INFO - 2018-04-28 12:55:40 --> Model Class Initialized
INFO - 2018-04-28 12:55:40 --> Helper loaded: inflector_helper
DEBUG - 2018-04-28 12:55:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-28 12:55:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-28 12:55:40 --> Model Class Initialized
INFO - 2018-04-28 12:55:40 --> Model Class Initialized
INFO - 2018-04-28 12:55:40 --> Model Class Initialized
INFO - 2018-04-28 12:55:40 --> Model Class Initialized
INFO - 2018-04-28 12:55:40 --> Model Class Initialized
INFO - 2018-04-28 12:55:40 --> Model Class Initialized
INFO - 2018-04-28 12:55:40 --> Model Class Initialized
INFO - 2018-04-28 12:55:40 --> Model Class Initialized
INFO - 2018-04-28 12:55:40 --> Model Class Initialized
INFO - 2018-04-28 12:55:40 --> Model Class Initialized
INFO - 2018-04-28 12:55:40 --> Model Class Initialized
INFO - 2018-04-28 12:55:40 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-28 12:55:40 --> Model Class Initialized
INFO - 2018-04-28 12:55:40 --> Database Driver Class Initialized
DEBUG - 2018-04-28 12:55:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-28 12:55:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-28 12:55:40 --> Final output sent to browser
DEBUG - 2018-04-28 12:55:40 --> Total execution time: 0.3253
INFO - 2018-04-28 12:55:40 --> Helper loaded: form_helper
INFO - 2018-04-28 12:55:40 --> Form Validation Class Initialized
INFO - 2018-04-28 12:55:40 --> Controller Class Initialized
INFO - 2018-04-28 12:55:40 --> Model Class Initialized
INFO - 2018-04-28 12:55:40 --> Helper loaded: inflector_helper
DEBUG - 2018-04-28 12:55:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-28 12:55:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-28 12:55:40 --> Model Class Initialized
INFO - 2018-04-28 12:55:40 --> Model Class Initialized
INFO - 2018-04-28 12:55:40 --> Model Class Initialized
INFO - 2018-04-28 12:55:40 --> Model Class Initialized
INFO - 2018-04-28 12:55:40 --> Model Class Initialized
INFO - 2018-04-28 12:55:40 --> Model Class Initialized
INFO - 2018-04-28 12:55:40 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-28 12:55:40 --> Model Class Initialized
INFO - 2018-04-28 12:55:40 --> Final output sent to browser
DEBUG - 2018-04-28 12:55:40 --> Total execution time: 0.5305
INFO - 2018-04-28 07:25:42 --> Config Class Initialized
INFO - 2018-04-28 07:25:42 --> Hooks Class Initialized
DEBUG - 2018-04-28 07:25:42 --> UTF-8 Support Enabled
INFO - 2018-04-28 07:25:42 --> Utf8 Class Initialized
INFO - 2018-04-28 07:25:42 --> URI Class Initialized
INFO - 2018-04-28 07:25:42 --> Config Class Initialized
INFO - 2018-04-28 07:25:42 --> Hooks Class Initialized
DEBUG - 2018-04-28 07:25:42 --> UTF-8 Support Enabled
INFO - 2018-04-28 07:25:42 --> Utf8 Class Initialized
INFO - 2018-04-28 07:25:42 --> Router Class Initialized
INFO - 2018-04-28 07:25:42 --> URI Class Initialized
INFO - 2018-04-28 07:25:42 --> Output Class Initialized
INFO - 2018-04-28 07:25:42 --> Router Class Initialized
INFO - 2018-04-28 07:25:42 --> Security Class Initialized
DEBUG - 2018-04-28 07:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-28 07:25:42 --> Input Class Initialized
INFO - 2018-04-28 07:25:42 --> Output Class Initialized
INFO - 2018-04-28 07:25:42 --> Language Class Initialized
INFO - 2018-04-28 07:25:42 --> Security Class Initialized
DEBUG - 2018-04-28 07:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-28 07:25:42 --> Input Class Initialized
INFO - 2018-04-28 07:25:42 --> Language Class Initialized
INFO - 2018-04-28 07:25:42 --> Language Class Initialized
INFO - 2018-04-28 07:25:42 --> Config Class Initialized
INFO - 2018-04-28 07:25:42 --> Loader Class Initialized
INFO - 2018-04-28 12:55:42 --> Helper loaded: url_helper
INFO - 2018-04-28 12:55:42 --> Helper loaded: notification_helper
INFO - 2018-04-28 12:55:42 --> Helper loaded: settings_helper
INFO - 2018-04-28 12:55:42 --> Helper loaded: permission_helper
INFO - 2018-04-28 07:25:42 --> Language Class Initialized
INFO - 2018-04-28 07:25:42 --> Config Class Initialized
INFO - 2018-04-28 07:25:42 --> Loader Class Initialized
INFO - 2018-04-28 12:55:42 --> Helper loaded: users_helper
INFO - 2018-04-28 12:55:42 --> Helper loaded: url_helper
INFO - 2018-04-28 12:55:42 --> Helper loaded: notification_helper
INFO - 2018-04-28 12:55:42 --> Helper loaded: settings_helper
INFO - 2018-04-28 12:55:42 --> Helper loaded: permission_helper
INFO - 2018-04-28 12:55:42 --> Helper loaded: users_helper
INFO - 2018-04-28 12:55:42 --> Database Driver Class Initialized
DEBUG - 2018-04-28 12:55:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-28 12:55:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-28 12:55:42 --> Database Driver Class Initialized
DEBUG - 2018-04-28 12:55:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-28 12:55:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-28 12:55:43 --> Helper loaded: form_helper
INFO - 2018-04-28 12:55:43 --> Form Validation Class Initialized
INFO - 2018-04-28 12:55:43 --> Controller Class Initialized
INFO - 2018-04-28 12:55:43 --> Helper loaded: form_helper
INFO - 2018-04-28 12:55:43 --> Form Validation Class Initialized
INFO - 2018-04-28 12:55:43 --> Controller Class Initialized
INFO - 2018-04-28 12:55:43 --> Model Class Initialized
INFO - 2018-04-28 12:55:43 --> Helper loaded: inflector_helper
DEBUG - 2018-04-28 12:55:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-28 12:55:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-28 12:55:43 --> Model Class Initialized
INFO - 2018-04-28 12:55:43 --> Helper loaded: inflector_helper
INFO - 2018-04-28 12:55:43 --> Model Class Initialized
INFO - 2018-04-28 12:55:43 --> Model Class Initialized
INFO - 2018-04-28 12:55:43 --> Model Class Initialized
INFO - 2018-04-28 12:55:43 --> Model Class Initialized
INFO - 2018-04-28 12:55:43 --> Model Class Initialized
DEBUG - 2018-04-28 12:55:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-28 12:55:43 --> Model Class Initialized
INFO - 2018-04-28 12:55:43 --> Model Class Initialized
INFO - 2018-04-28 12:55:43 --> Model Class Initialized
INFO - 2018-04-28 12:55:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-28 12:55:43 --> Model Class Initialized
INFO - 2018-04-28 12:55:43 --> Model Class Initialized
INFO - 2018-04-28 12:55:43 --> Model Class Initialized
INFO - 2018-04-28 12:55:43 --> Model Class Initialized
INFO - 2018-04-28 12:55:43 --> Model Class Initialized
INFO - 2018-04-28 12:55:43 --> Model Class Initialized
INFO - 2018-04-28 12:55:43 --> Model Class Initialized
INFO - 2018-04-28 12:55:43 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-28 12:55:43 --> Model Class Initialized
INFO - 2018-04-28 12:55:43 --> Model Class Initialized
INFO - 2018-04-28 12:55:43 --> Model Class Initialized
INFO - 2018-04-28 12:55:43 --> Model Class Initialized
INFO - 2018-04-28 12:55:43 --> Model Class Initialized
INFO - 2018-04-28 12:55:43 --> Model Class Initialized
INFO - 2018-04-28 12:55:43 --> Model Class Initialized
INFO - 2018-04-28 12:55:43 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-28 12:55:43 --> Model Class Initialized
INFO - 2018-04-28 12:55:43 --> Final output sent to browser
DEBUG - 2018-04-28 12:55:43 --> Total execution time: 0.2661
INFO - 2018-04-28 12:55:43 --> Final output sent to browser
DEBUG - 2018-04-28 12:55:43 --> Total execution time: 0.2951
INFO - 2018-04-28 07:25:44 --> Config Class Initialized
INFO - 2018-04-28 07:25:44 --> Hooks Class Initialized
DEBUG - 2018-04-28 07:25:44 --> UTF-8 Support Enabled
INFO - 2018-04-28 07:25:44 --> Utf8 Class Initialized
INFO - 2018-04-28 07:25:44 --> URI Class Initialized
INFO - 2018-04-28 07:25:44 --> Router Class Initialized
INFO - 2018-04-28 07:25:44 --> Output Class Initialized
INFO - 2018-04-28 07:25:44 --> Security Class Initialized
DEBUG - 2018-04-28 07:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-28 07:25:44 --> Input Class Initialized
INFO - 2018-04-28 07:25:44 --> Language Class Initialized
INFO - 2018-04-28 07:25:44 --> Language Class Initialized
INFO - 2018-04-28 07:25:44 --> Config Class Initialized
INFO - 2018-04-28 07:25:44 --> Loader Class Initialized
INFO - 2018-04-28 12:55:44 --> Helper loaded: url_helper
INFO - 2018-04-28 12:55:44 --> Helper loaded: notification_helper
INFO - 2018-04-28 12:55:44 --> Helper loaded: settings_helper
INFO - 2018-04-28 12:55:44 --> Helper loaded: permission_helper
INFO - 2018-04-28 12:55:44 --> Helper loaded: users_helper
INFO - 2018-04-28 12:55:44 --> Database Driver Class Initialized
DEBUG - 2018-04-28 12:55:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-28 12:55:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-28 12:55:44 --> Helper loaded: form_helper
INFO - 2018-04-28 12:55:44 --> Form Validation Class Initialized
INFO - 2018-04-28 12:55:44 --> Controller Class Initialized
INFO - 2018-04-28 12:55:44 --> Model Class Initialized
INFO - 2018-04-28 12:55:44 --> Helper loaded: inflector_helper
DEBUG - 2018-04-28 12:55:44 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-28 12:55:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-28 12:55:44 --> Model Class Initialized
INFO - 2018-04-28 12:55:44 --> Model Class Initialized
INFO - 2018-04-28 12:55:44 --> Model Class Initialized
INFO - 2018-04-28 12:55:44 --> Model Class Initialized
INFO - 2018-04-28 12:55:44 --> Final output sent to browser
DEBUG - 2018-04-28 12:55:44 --> Total execution time: 0.3427
INFO - 2018-04-28 07:25:46 --> Config Class Initialized
INFO - 2018-04-28 07:25:46 --> Hooks Class Initialized
DEBUG - 2018-04-28 07:25:46 --> UTF-8 Support Enabled
INFO - 2018-04-28 07:25:46 --> Utf8 Class Initialized
INFO - 2018-04-28 07:25:46 --> URI Class Initialized
INFO - 2018-04-28 07:25:46 --> Router Class Initialized
INFO - 2018-04-28 07:25:46 --> Output Class Initialized
INFO - 2018-04-28 07:25:46 --> Security Class Initialized
DEBUG - 2018-04-28 07:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-28 07:25:46 --> Input Class Initialized
INFO - 2018-04-28 07:25:46 --> Language Class Initialized
INFO - 2018-04-28 07:25:46 --> Language Class Initialized
INFO - 2018-04-28 07:25:46 --> Config Class Initialized
INFO - 2018-04-28 07:25:46 --> Loader Class Initialized
INFO - 2018-04-28 12:55:46 --> Helper loaded: url_helper
INFO - 2018-04-28 12:55:46 --> Helper loaded: notification_helper
INFO - 2018-04-28 12:55:46 --> Helper loaded: settings_helper
INFO - 2018-04-28 12:55:46 --> Helper loaded: permission_helper
INFO - 2018-04-28 12:55:46 --> Helper loaded: users_helper
INFO - 2018-04-28 07:25:46 --> Config Class Initialized
INFO - 2018-04-28 07:25:46 --> Hooks Class Initialized
DEBUG - 2018-04-28 07:25:46 --> UTF-8 Support Enabled
INFO - 2018-04-28 07:25:46 --> Utf8 Class Initialized
INFO - 2018-04-28 07:25:46 --> URI Class Initialized
INFO - 2018-04-28 12:55:46 --> Database Driver Class Initialized
DEBUG - 2018-04-28 12:55:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-28 12:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-28 07:25:46 --> Router Class Initialized
INFO - 2018-04-28 07:25:46 --> Output Class Initialized
INFO - 2018-04-28 12:55:46 --> Helper loaded: form_helper
INFO - 2018-04-28 12:55:46 --> Form Validation Class Initialized
INFO - 2018-04-28 12:55:46 --> Controller Class Initialized
INFO - 2018-04-28 07:25:46 --> Security Class Initialized
DEBUG - 2018-04-28 07:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-28 07:25:46 --> Input Class Initialized
INFO - 2018-04-28 07:25:46 --> Language Class Initialized
INFO - 2018-04-28 12:55:46 --> Model Class Initialized
INFO - 2018-04-28 12:55:46 --> Helper loaded: inflector_helper
DEBUG - 2018-04-28 12:55:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-28 12:55:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-28 12:55:46 --> Model Class Initialized
INFO - 2018-04-28 12:55:46 --> Model Class Initialized
INFO - 2018-04-28 12:55:46 --> Model Class Initialized
INFO - 2018-04-28 12:55:46 --> Model Class Initialized
INFO - 2018-04-28 12:55:46 --> Final output sent to browser
DEBUG - 2018-04-28 12:55:46 --> Total execution time: 0.2171
INFO - 2018-04-28 07:25:46 --> Language Class Initialized
INFO - 2018-04-28 07:25:46 --> Config Class Initialized
INFO - 2018-04-28 07:25:46 --> Loader Class Initialized
INFO - 2018-04-28 12:55:46 --> Helper loaded: url_helper
INFO - 2018-04-28 12:55:46 --> Helper loaded: notification_helper
INFO - 2018-04-28 12:55:46 --> Helper loaded: settings_helper
INFO - 2018-04-28 12:55:46 --> Helper loaded: permission_helper
INFO - 2018-04-28 12:55:46 --> Helper loaded: users_helper
INFO - 2018-04-28 12:55:46 --> Database Driver Class Initialized
DEBUG - 2018-04-28 12:55:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-28 12:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-28 12:55:46 --> Helper loaded: form_helper
INFO - 2018-04-28 12:55:46 --> Form Validation Class Initialized
INFO - 2018-04-28 12:55:46 --> Controller Class Initialized
INFO - 2018-04-28 12:55:46 --> Model Class Initialized
INFO - 2018-04-28 12:55:46 --> Helper loaded: inflector_helper
DEBUG - 2018-04-28 12:55:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-28 12:55:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-28 12:55:46 --> Model Class Initialized
INFO - 2018-04-28 12:55:46 --> Model Class Initialized
INFO - 2018-04-28 12:55:46 --> Model Class Initialized
INFO - 2018-04-28 12:55:46 --> Model Class Initialized
INFO - 2018-04-28 12:55:46 --> Final output sent to browser
DEBUG - 2018-04-28 12:55:46 --> Total execution time: 0.2519
INFO - 2018-04-28 07:25:47 --> Config Class Initialized
INFO - 2018-04-28 07:25:47 --> Hooks Class Initialized
DEBUG - 2018-04-28 07:25:47 --> UTF-8 Support Enabled
INFO - 2018-04-28 07:25:47 --> Utf8 Class Initialized
INFO - 2018-04-28 07:25:47 --> URI Class Initialized
INFO - 2018-04-28 07:25:47 --> Config Class Initialized
INFO - 2018-04-28 07:25:47 --> Hooks Class Initialized
INFO - 2018-04-28 07:25:47 --> Router Class Initialized
DEBUG - 2018-04-28 07:25:47 --> UTF-8 Support Enabled
INFO - 2018-04-28 07:25:47 --> Utf8 Class Initialized
INFO - 2018-04-28 07:25:47 --> URI Class Initialized
INFO - 2018-04-28 07:25:47 --> Output Class Initialized
INFO - 2018-04-28 07:25:47 --> Security Class Initialized
INFO - 2018-04-28 07:25:47 --> Router Class Initialized
DEBUG - 2018-04-28 07:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-28 07:25:47 --> Input Class Initialized
INFO - 2018-04-28 07:25:47 --> Language Class Initialized
INFO - 2018-04-28 07:25:47 --> Output Class Initialized
INFO - 2018-04-28 07:25:47 --> Security Class Initialized
DEBUG - 2018-04-28 07:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-28 07:25:47 --> Input Class Initialized
INFO - 2018-04-28 07:25:47 --> Language Class Initialized
INFO - 2018-04-28 07:25:47 --> Language Class Initialized
INFO - 2018-04-28 07:25:47 --> Config Class Initialized
INFO - 2018-04-28 07:25:47 --> Loader Class Initialized
INFO - 2018-04-28 12:55:47 --> Helper loaded: url_helper
INFO - 2018-04-28 12:55:47 --> Helper loaded: notification_helper
INFO - 2018-04-28 12:55:47 --> Helper loaded: settings_helper
INFO - 2018-04-28 12:55:47 --> Helper loaded: permission_helper
INFO - 2018-04-28 12:55:47 --> Helper loaded: users_helper
INFO - 2018-04-28 12:55:47 --> Database Driver Class Initialized
DEBUG - 2018-04-28 12:55:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-28 12:55:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-28 12:55:47 --> Helper loaded: form_helper
INFO - 2018-04-28 12:55:47 --> Form Validation Class Initialized
INFO - 2018-04-28 12:55:47 --> Controller Class Initialized
INFO - 2018-04-28 07:25:47 --> Language Class Initialized
INFO - 2018-04-28 07:25:47 --> Config Class Initialized
INFO - 2018-04-28 07:25:47 --> Loader Class Initialized
INFO - 2018-04-28 12:55:47 --> Helper loaded: url_helper
INFO - 2018-04-28 12:55:47 --> Helper loaded: notification_helper
INFO - 2018-04-28 12:55:47 --> Helper loaded: settings_helper
INFO - 2018-04-28 12:55:47 --> Helper loaded: permission_helper
INFO - 2018-04-28 12:55:47 --> Helper loaded: users_helper
INFO - 2018-04-28 12:55:47 --> Model Class Initialized
INFO - 2018-04-28 12:55:47 --> Helper loaded: inflector_helper
DEBUG - 2018-04-28 12:55:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-28 12:55:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-28 07:25:47 --> Config Class Initialized
INFO - 2018-04-28 07:25:47 --> Hooks Class Initialized
INFO - 2018-04-28 12:55:47 --> Model Class Initialized
INFO - 2018-04-28 12:55:47 --> Model Class Initialized
INFO - 2018-04-28 12:55:47 --> Model Class Initialized
INFO - 2018-04-28 12:55:47 --> Model Class Initialized
INFO - 2018-04-28 12:55:47 --> Model Class Initialized
INFO - 2018-04-28 12:55:47 --> Model Class Initialized
INFO - 2018-04-28 12:55:47 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-28 12:55:47 --> Database Driver Class Initialized
INFO - 2018-04-28 12:55:47 --> Final output sent to browser
DEBUG - 2018-04-28 12:55:47 --> Total execution time: 0.3169
DEBUG - 2018-04-28 07:25:47 --> UTF-8 Support Enabled
INFO - 2018-04-28 07:25:47 --> Utf8 Class Initialized
DEBUG - 2018-04-28 12:55:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-28 12:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-28 07:25:48 --> URI Class Initialized
INFO - 2018-04-28 07:25:48 --> Router Class Initialized
INFO - 2018-04-28 12:55:48 --> Helper loaded: form_helper
INFO - 2018-04-28 12:55:48 --> Form Validation Class Initialized
INFO - 2018-04-28 12:55:48 --> Controller Class Initialized
INFO - 2018-04-28 07:25:48 --> Output Class Initialized
INFO - 2018-04-28 12:55:48 --> Model Class Initialized
INFO - 2018-04-28 12:55:48 --> Helper loaded: inflector_helper
INFO - 2018-04-28 07:25:48 --> Security Class Initialized
DEBUG - 2018-04-28 12:55:48 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-28 12:55:48 --> Language file loaded: language/english/rest_controller_lang.php
DEBUG - 2018-04-28 07:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-28 07:25:48 --> Input Class Initialized
INFO - 2018-04-28 12:55:48 --> Model Class Initialized
INFO - 2018-04-28 12:55:48 --> Model Class Initialized
INFO - 2018-04-28 12:55:48 --> Model Class Initialized
INFO - 2018-04-28 12:55:48 --> Model Class Initialized
INFO - 2018-04-28 07:25:48 --> Language Class Initialized
INFO - 2018-04-28 12:55:48 --> Model Class Initialized
INFO - 2018-04-28 12:55:48 --> Model Class Initialized
INFO - 2018-04-28 12:55:48 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-28 12:55:48 --> Final output sent to browser
DEBUG - 2018-04-28 12:55:48 --> Total execution time: 0.3486
INFO - 2018-04-28 07:25:48 --> Language Class Initialized
INFO - 2018-04-28 07:25:48 --> Config Class Initialized
INFO - 2018-04-28 07:25:48 --> Loader Class Initialized
INFO - 2018-04-28 12:55:48 --> Helper loaded: url_helper
INFO - 2018-04-28 12:55:48 --> Helper loaded: notification_helper
INFO - 2018-04-28 12:55:48 --> Helper loaded: settings_helper
INFO - 2018-04-28 12:55:48 --> Helper loaded: permission_helper
INFO - 2018-04-28 12:55:48 --> Helper loaded: users_helper
INFO - 2018-04-28 12:55:48 --> Database Driver Class Initialized
DEBUG - 2018-04-28 12:55:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-28 12:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-28 12:55:48 --> Helper loaded: form_helper
INFO - 2018-04-28 12:55:48 --> Form Validation Class Initialized
INFO - 2018-04-28 12:55:48 --> Controller Class Initialized
INFO - 2018-04-28 12:55:48 --> Model Class Initialized
INFO - 2018-04-28 12:55:48 --> Helper loaded: inflector_helper
DEBUG - 2018-04-28 12:55:48 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-28 12:55:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-28 12:55:48 --> Model Class Initialized
INFO - 2018-04-28 12:55:48 --> Model Class Initialized
INFO - 2018-04-28 12:55:48 --> Model Class Initialized
INFO - 2018-04-28 12:55:48 --> Model Class Initialized
INFO - 2018-04-28 12:55:48 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-28 12:55:48 --> Final output sent to browser
DEBUG - 2018-04-28 12:55:48 --> Total execution time: 0.2359
INFO - 2018-04-28 07:25:48 --> Config Class Initialized
INFO - 2018-04-28 07:25:48 --> Hooks Class Initialized
DEBUG - 2018-04-28 07:25:48 --> UTF-8 Support Enabled
INFO - 2018-04-28 07:25:48 --> Utf8 Class Initialized
INFO - 2018-04-28 07:25:48 --> URI Class Initialized
INFO - 2018-04-28 07:25:48 --> Router Class Initialized
INFO - 2018-04-28 07:25:48 --> Output Class Initialized
INFO - 2018-04-28 07:25:48 --> Security Class Initialized
DEBUG - 2018-04-28 07:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-28 07:25:48 --> Input Class Initialized
INFO - 2018-04-28 07:25:48 --> Language Class Initialized
INFO - 2018-04-28 07:25:49 --> Language Class Initialized
INFO - 2018-04-28 07:25:49 --> Config Class Initialized
INFO - 2018-04-28 07:25:49 --> Loader Class Initialized
INFO - 2018-04-28 12:55:49 --> Helper loaded: url_helper
INFO - 2018-04-28 12:55:49 --> Helper loaded: notification_helper
INFO - 2018-04-28 12:55:49 --> Helper loaded: settings_helper
INFO - 2018-04-28 12:55:49 --> Helper loaded: permission_helper
INFO - 2018-04-28 12:55:49 --> Helper loaded: users_helper
INFO - 2018-04-28 07:25:49 --> Config Class Initialized
INFO - 2018-04-28 07:25:49 --> Hooks Class Initialized
DEBUG - 2018-04-28 07:25:49 --> UTF-8 Support Enabled
INFO - 2018-04-28 07:25:49 --> Utf8 Class Initialized
INFO - 2018-04-28 07:25:49 --> URI Class Initialized
INFO - 2018-04-28 07:25:49 --> Router Class Initialized
INFO - 2018-04-28 07:25:49 --> Output Class Initialized
INFO - 2018-04-28 12:55:49 --> Database Driver Class Initialized
INFO - 2018-04-28 07:25:49 --> Security Class Initialized
DEBUG - 2018-04-28 12:55:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-28 12:55:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-04-28 07:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-28 07:25:49 --> Input Class Initialized
INFO - 2018-04-28 07:25:49 --> Language Class Initialized
INFO - 2018-04-28 12:55:49 --> Helper loaded: form_helper
INFO - 2018-04-28 12:55:49 --> Form Validation Class Initialized
INFO - 2018-04-28 12:55:49 --> Controller Class Initialized
INFO - 2018-04-28 07:25:49 --> Language Class Initialized
INFO - 2018-04-28 07:25:49 --> Config Class Initialized
INFO - 2018-04-28 07:25:49 --> Loader Class Initialized
INFO - 2018-04-28 12:55:49 --> Helper loaded: url_helper
INFO - 2018-04-28 12:55:49 --> Helper loaded: notification_helper
INFO - 2018-04-28 12:55:49 --> Helper loaded: settings_helper
INFO - 2018-04-28 12:55:49 --> Helper loaded: permission_helper
INFO - 2018-04-28 12:55:49 --> Helper loaded: users_helper
INFO - 2018-04-28 12:55:49 --> Database Driver Class Initialized
DEBUG - 2018-04-28 12:55:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-28 12:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-28 12:55:49 --> Helper loaded: form_helper
INFO - 2018-04-28 12:55:49 --> Form Validation Class Initialized
INFO - 2018-04-28 12:55:49 --> Controller Class Initialized
INFO - 2018-04-28 12:55:49 --> Model Class Initialized
INFO - 2018-04-28 12:55:49 --> Model Class Initialized
INFO - 2018-04-28 12:55:49 --> Helper loaded: inflector_helper
DEBUG - 2018-04-28 12:55:49 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-28 12:55:49 --> Helper loaded: inflector_helper
INFO - 2018-04-28 12:55:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-28 12:55:49 --> Model Class Initialized
INFO - 2018-04-28 12:55:49 --> Model Class Initialized
DEBUG - 2018-04-28 12:55:49 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-28 12:55:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-28 12:55:49 --> Model Class Initialized
INFO - 2018-04-28 12:55:49 --> Model Class Initialized
INFO - 2018-04-28 12:55:49 --> Model Class Initialized
INFO - 2018-04-28 12:55:49 --> Model Class Initialized
INFO - 2018-04-28 12:55:49 --> Model Class Initialized
INFO - 2018-04-28 12:55:49 --> Model Class Initialized
INFO - 2018-04-28 12:55:49 --> Final output sent to browser
DEBUG - 2018-04-28 12:55:49 --> Total execution time: 0.1541
INFO - 2018-04-28 12:55:49 --> Final output sent to browser
DEBUG - 2018-04-28 12:55:49 --> Total execution time: 0.2675
