<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-05-19 00:00:02 --> Helper loaded: url_helper
INFO - 2018-05-19 00:00:02 --> Helper loaded: notification_helper
INFO - 2018-05-19 00:00:02 --> Helper loaded: settings_helper
INFO - 2018-05-19 00:00:02 --> Helper loaded: permission_helper
INFO - 2018-05-19 00:00:02 --> Helper loaded: users_helper
INFO - 2018-05-19 00:00:02 --> Database Driver Class Initialized
DEBUG - 2018-05-19 00:00:02 --> Session: Initialization under CLI aborted.
INFO - 2018-05-19 00:00:02 --> Helper loaded: form_helper
INFO - 2018-05-19 00:00:02 --> Form Validation Class Initialized
INFO - 2018-05-19 00:00:02 --> Controller Class Initialized
INFO - 2018-05-19 00:00:02 --> Model Class Initialized
INFO - 2018-05-19 00:00:02 --> Helper loaded: inflector_helper
DEBUG - 2018-05-19 00:00:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-19 00:00:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-19 00:00:02 --> Model Class Initialized
INFO - 2018-05-19 00:00:02 --> Model Class Initialized
INFO - 2018-05-19 00:00:02 --> Model Class Initialized
INFO - 2018-05-19 00:00:02 --> Model Class Initialized
INFO - 2018-05-19 00:00:02 --> Model Class Initialized
INFO - 2018-05-19 00:00:02 --> Model Class Initialized
INFO - 2018-05-19 00:00:02 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-19 00:00:02 --> Model Class Initialized
INFO - 2018-05-19 00:00:02 --> Final output sent to browser
DEBUG - 2018-05-19 00:00:02 --> Total execution time: 0.1568
INFO - 2018-05-19 00:00:02 --> Helper loaded: url_helper
INFO - 2018-05-19 00:00:02 --> Helper loaded: notification_helper
INFO - 2018-05-19 00:00:02 --> Helper loaded: settings_helper
INFO - 2018-05-19 00:00:02 --> Helper loaded: permission_helper
INFO - 2018-05-19 00:00:02 --> Helper loaded: users_helper
INFO - 2018-05-19 00:00:02 --> Database Driver Class Initialized
DEBUG - 2018-05-19 00:00:02 --> Session: Initialization under CLI aborted.
INFO - 2018-05-19 00:00:02 --> Helper loaded: form_helper
INFO - 2018-05-19 00:00:02 --> Form Validation Class Initialized
INFO - 2018-05-19 00:00:02 --> Controller Class Initialized
INFO - 2018-05-19 00:00:02 --> Model Class Initialized
INFO - 2018-05-19 00:00:02 --> Helper loaded: inflector_helper
DEBUG - 2018-05-19 00:00:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-19 00:00:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-19 00:00:02 --> Model Class Initialized
INFO - 2018-05-19 00:00:02 --> Model Class Initialized
INFO - 2018-05-19 00:00:02 --> Model Class Initialized
INFO - 2018-05-19 00:00:02 --> Model Class Initialized
INFO - 2018-05-19 00:00:02 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-19 00:00:02 --> Model Class Initialized
ERROR - 2018-05-19 00:00:02 --> Query error: Unknown column 'premium_end_date' in 'where clause' - Invalid query: UPDATE `users` SET `premium_status` = '0'
WHERE `premium_trial_used` = '1'
AND `premium_status` = '1'
AND `premium_end_date` <= '2018-05-19'
INFO - 2018-05-19 00:00:02 --> Final output sent to browser
DEBUG - 2018-05-19 00:00:02 --> Total execution time: 0.0943
INFO - 2018-05-19 06:38:52 --> Config Class Initialized
INFO - 2018-05-19 06:38:52 --> Hooks Class Initialized
INFO - 2018-05-19 06:38:52 --> Config Class Initialized
INFO - 2018-05-19 06:38:52 --> Hooks Class Initialized
INFO - 2018-05-19 06:38:52 --> Config Class Initialized
INFO - 2018-05-19 06:38:52 --> Hooks Class Initialized
INFO - 2018-05-19 06:38:52 --> Config Class Initialized
INFO - 2018-05-19 06:38:52 --> Hooks Class Initialized
INFO - 2018-05-19 06:38:52 --> Config Class Initialized
INFO - 2018-05-19 06:38:52 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:38:52 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:38:52 --> Utf8 Class Initialized
DEBUG - 2018-05-19 06:38:52 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:38:52 --> Utf8 Class Initialized
DEBUG - 2018-05-19 06:38:52 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:38:52 --> Utf8 Class Initialized
DEBUG - 2018-05-19 06:38:52 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:38:52 --> Utf8 Class Initialized
DEBUG - 2018-05-19 06:38:52 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:38:52 --> Utf8 Class Initialized
INFO - 2018-05-19 06:38:52 --> URI Class Initialized
INFO - 2018-05-19 06:38:52 --> URI Class Initialized
INFO - 2018-05-19 06:38:52 --> URI Class Initialized
INFO - 2018-05-19 06:38:52 --> URI Class Initialized
INFO - 2018-05-19 06:38:52 --> URI Class Initialized
INFO - 2018-05-19 06:38:52 --> Router Class Initialized
INFO - 2018-05-19 06:38:52 --> Router Class Initialized
INFO - 2018-05-19 06:38:52 --> Router Class Initialized
INFO - 2018-05-19 06:38:52 --> Router Class Initialized
INFO - 2018-05-19 06:38:52 --> Router Class Initialized
INFO - 2018-05-19 06:38:52 --> Output Class Initialized
INFO - 2018-05-19 06:38:52 --> Output Class Initialized
INFO - 2018-05-19 06:38:52 --> Output Class Initialized
INFO - 2018-05-19 06:38:52 --> Output Class Initialized
INFO - 2018-05-19 06:38:52 --> Output Class Initialized
INFO - 2018-05-19 06:38:52 --> Security Class Initialized
DEBUG - 2018-05-19 06:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:38:52 --> Input Class Initialized
INFO - 2018-05-19 06:38:52 --> Language Class Initialized
INFO - 2018-05-19 06:38:52 --> Security Class Initialized
INFO - 2018-05-19 06:38:52 --> Security Class Initialized
INFO - 2018-05-19 06:38:52 --> Security Class Initialized
INFO - 2018-05-19 06:38:52 --> Security Class Initialized
DEBUG - 2018-05-19 06:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:38:52 --> Input Class Initialized
DEBUG - 2018-05-19 06:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:38:52 --> Input Class Initialized
DEBUG - 2018-05-19 06:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-19 06:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:38:52 --> Input Class Initialized
INFO - 2018-05-19 06:38:52 --> Language Class Initialized
INFO - 2018-05-19 06:38:52 --> Input Class Initialized
INFO - 2018-05-19 06:38:52 --> Language Class Initialized
INFO - 2018-05-19 06:38:52 --> Language Class Initialized
INFO - 2018-05-19 06:38:52 --> Language Class Initialized
INFO - 2018-05-19 06:38:52 --> Language Class Initialized
INFO - 2018-05-19 06:38:52 --> Config Class Initialized
INFO - 2018-05-19 06:38:52 --> Loader Class Initialized
INFO - 2018-05-19 12:08:52 --> Helper loaded: url_helper
INFO - 2018-05-19 12:08:52 --> Helper loaded: notification_helper
INFO - 2018-05-19 12:08:52 --> Helper loaded: settings_helper
INFO - 2018-05-19 12:08:52 --> Helper loaded: permission_helper
INFO - 2018-05-19 12:08:52 --> Helper loaded: users_helper
INFO - 2018-05-19 06:38:52 --> Language Class Initialized
INFO - 2018-05-19 06:38:52 --> Config Class Initialized
INFO - 2018-05-19 06:38:52 --> Loader Class Initialized
INFO - 2018-05-19 12:08:52 --> Helper loaded: url_helper
INFO - 2018-05-19 12:08:52 --> Helper loaded: notification_helper
INFO - 2018-05-19 12:08:52 --> Helper loaded: settings_helper
INFO - 2018-05-19 12:08:52 --> Helper loaded: permission_helper
INFO - 2018-05-19 12:08:52 --> Helper loaded: users_helper
INFO - 2018-05-19 06:38:52 --> Language Class Initialized
INFO - 2018-05-19 06:38:52 --> Config Class Initialized
INFO - 2018-05-19 06:38:52 --> Loader Class Initialized
INFO - 2018-05-19 06:38:52 --> Language Class Initialized
INFO - 2018-05-19 06:38:52 --> Config Class Initialized
INFO - 2018-05-19 06:38:52 --> Loader Class Initialized
INFO - 2018-05-19 12:08:52 --> Helper loaded: url_helper
INFO - 2018-05-19 12:08:52 --> Helper loaded: url_helper
INFO - 2018-05-19 06:38:52 --> Language Class Initialized
INFO - 2018-05-19 06:38:52 --> Config Class Initialized
INFO - 2018-05-19 06:38:52 --> Loader Class Initialized
INFO - 2018-05-19 12:08:52 --> Helper loaded: notification_helper
INFO - 2018-05-19 12:08:52 --> Helper loaded: notification_helper
INFO - 2018-05-19 12:08:52 --> Helper loaded: settings_helper
INFO - 2018-05-19 12:08:52 --> Helper loaded: settings_helper
INFO - 2018-05-19 12:08:52 --> Helper loaded: permission_helper
INFO - 2018-05-19 12:08:52 --> Helper loaded: permission_helper
INFO - 2018-05-19 12:08:52 --> Helper loaded: url_helper
INFO - 2018-05-19 12:08:52 --> Helper loaded: users_helper
INFO - 2018-05-19 12:08:52 --> Helper loaded: users_helper
INFO - 2018-05-19 12:08:52 --> Helper loaded: notification_helper
INFO - 2018-05-19 12:08:52 --> Helper loaded: settings_helper
INFO - 2018-05-19 12:08:52 --> Helper loaded: permission_helper
INFO - 2018-05-19 12:08:52 --> Helper loaded: users_helper
INFO - 2018-05-19 12:08:52 --> Database Driver Class Initialized
INFO - 2018-05-19 12:08:52 --> Database Driver Class Initialized
INFO - 2018-05-19 12:08:52 --> Database Driver Class Initialized
INFO - 2018-05-19 12:08:52 --> Database Driver Class Initialized
DEBUG - 2018-05-19 12:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 12:08:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-05-19 12:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 12:08:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-05-19 12:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 12:08:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-05-19 12:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 12:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 12:08:52 --> Database Driver Class Initialized
DEBUG - 2018-05-19 12:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 12:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 12:08:52 --> Helper loaded: form_helper
INFO - 2018-05-19 12:08:52 --> Form Validation Class Initialized
INFO - 2018-05-19 12:08:52 --> Controller Class Initialized
INFO - 2018-05-19 12:08:52 --> Helper loaded: form_helper
INFO - 2018-05-19 12:08:52 --> Form Validation Class Initialized
INFO - 2018-05-19 12:08:52 --> Controller Class Initialized
INFO - 2018-05-19 12:08:52 --> Helper loaded: form_helper
INFO - 2018-05-19 12:08:52 --> Form Validation Class Initialized
INFO - 2018-05-19 12:08:52 --> Controller Class Initialized
INFO - 2018-05-19 12:08:52 --> Helper loaded: form_helper
INFO - 2018-05-19 12:08:52 --> Form Validation Class Initialized
INFO - 2018-05-19 12:08:52 --> Controller Class Initialized
INFO - 2018-05-19 12:08:52 --> Helper loaded: form_helper
INFO - 2018-05-19 12:08:52 --> Form Validation Class Initialized
INFO - 2018-05-19 12:08:52 --> Controller Class Initialized
INFO - 2018-05-19 12:08:52 --> Model Class Initialized
INFO - 2018-05-19 12:08:52 --> Model Class Initialized
INFO - 2018-05-19 12:08:52 --> Model Class Initialized
INFO - 2018-05-19 12:08:52 --> Model Class Initialized
INFO - 2018-05-19 12:08:52 --> Model Class Initialized
INFO - 2018-05-19 12:08:52 --> Helper loaded: inflector_helper
INFO - 2018-05-19 12:08:52 --> Helper loaded: inflector_helper
INFO - 2018-05-19 12:08:52 --> Helper loaded: inflector_helper
INFO - 2018-05-19 12:08:52 --> Helper loaded: inflector_helper
INFO - 2018-05-19 12:08:52 --> Helper loaded: inflector_helper
DEBUG - 2018-05-19 12:08:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-05-19 12:08:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-05-19 12:08:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-05-19 12:08:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-19 12:08:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-19 12:08:52 --> Language file loaded: language/english/rest_controller_lang.php
DEBUG - 2018-05-19 12:08:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-19 12:08:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-19 12:08:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-19 12:08:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-19 12:08:52 --> Model Class Initialized
INFO - 2018-05-19 12:08:52 --> Model Class Initialized
INFO - 2018-05-19 12:08:52 --> Model Class Initialized
INFO - 2018-05-19 12:08:52 --> Model Class Initialized
INFO - 2018-05-19 12:08:52 --> Model Class Initialized
INFO - 2018-05-19 12:08:52 --> Model Class Initialized
INFO - 2018-05-19 12:08:52 --> Model Class Initialized
INFO - 2018-05-19 12:08:52 --> Model Class Initialized
INFO - 2018-05-19 12:08:52 --> Model Class Initialized
INFO - 2018-05-19 12:08:52 --> Model Class Initialized
INFO - 2018-05-19 12:08:52 --> Model Class Initialized
INFO - 2018-05-19 12:08:52 --> Model Class Initialized
INFO - 2018-05-19 12:08:52 --> Model Class Initialized
INFO - 2018-05-19 12:08:52 --> Model Class Initialized
INFO - 2018-05-19 12:08:52 --> Model Class Initialized
INFO - 2018-05-19 12:08:52 --> Model Class Initialized
INFO - 2018-05-19 12:08:52 --> Model Class Initialized
INFO - 2018-05-19 12:08:52 --> Model Class Initialized
INFO - 2018-05-19 12:08:52 --> Model Class Initialized
INFO - 2018-05-19 12:08:52 --> Model Class Initialized
INFO - 2018-05-19 12:08:52 --> Model Class Initialized
INFO - 2018-05-19 12:08:52 --> Model Class Initialized
INFO - 2018-05-19 12:08:52 --> Model Class Initialized
INFO - 2018-05-19 12:08:52 --> Model Class Initialized
INFO - 2018-05-19 12:08:52 --> Model Class Initialized
INFO - 2018-05-19 12:08:52 --> Model Class Initialized
INFO - 2018-05-19 12:08:52 --> Model Class Initialized
INFO - 2018-05-19 12:08:52 --> Model Class Initialized
INFO - 2018-05-19 12:08:52 --> Model Class Initialized
INFO - 2018-05-19 12:08:52 --> Model Class Initialized
INFO - 2018-05-19 12:08:52 --> Model Class Initialized
INFO - 2018-05-19 12:08:52 --> Model Class Initialized
INFO - 2018-05-19 12:08:52 --> Model Class Initialized
INFO - 2018-05-19 12:08:52 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-19 12:08:52 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-19 12:08:52 --> Model Class Initialized
INFO - 2018-05-19 12:08:52 --> Model Class Initialized
INFO - 2018-05-19 12:08:52 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-19 12:08:52 --> Model Class Initialized
INFO - 2018-05-19 12:08:52 --> Model Class Initialized
INFO - 2018-05-19 12:08:52 --> Model Class Initialized
INFO - 2018-05-19 12:08:52 --> Model Class Initialized
INFO - 2018-05-19 12:08:52 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-19 12:08:52 --> Model Class Initialized
INFO - 2018-05-19 12:08:52 --> Model Class Initialized
INFO - 2018-05-19 12:08:52 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-19 12:08:52 --> Model Class Initialized
INFO - 2018-05-19 12:08:52 --> Model Class Initialized
INFO - 2018-05-19 12:08:52 --> Model Class Initialized
INFO - 2018-05-19 12:08:52 --> Final output sent to browser
DEBUG - 2018-05-19 12:08:52 --> Total execution time: 0.5268
INFO - 2018-05-19 12:08:52 --> Final output sent to browser
DEBUG - 2018-05-19 12:08:52 --> Total execution time: 0.5280
INFO - 2018-05-19 12:08:52 --> Final output sent to browser
DEBUG - 2018-05-19 12:08:52 --> Total execution time: 0.5315
INFO - 2018-05-19 12:08:52 --> Final output sent to browser
DEBUG - 2018-05-19 12:08:52 --> Total execution time: 0.7005
INFO - 2018-05-19 12:08:52 --> Final output sent to browser
DEBUG - 2018-05-19 12:08:52 --> Total execution time: 0.7110
INFO - 2018-05-19 06:38:59 --> Config Class Initialized
INFO - 2018-05-19 06:38:59 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:38:59 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:38:59 --> Utf8 Class Initialized
INFO - 2018-05-19 06:38:59 --> URI Class Initialized
INFO - 2018-05-19 06:38:59 --> Router Class Initialized
INFO - 2018-05-19 06:38:59 --> Output Class Initialized
INFO - 2018-05-19 06:38:59 --> Security Class Initialized
DEBUG - 2018-05-19 06:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:38:59 --> Input Class Initialized
INFO - 2018-05-19 06:38:59 --> Language Class Initialized
INFO - 2018-05-19 06:38:59 --> Language Class Initialized
INFO - 2018-05-19 06:38:59 --> Config Class Initialized
INFO - 2018-05-19 06:38:59 --> Loader Class Initialized
INFO - 2018-05-19 12:08:59 --> Helper loaded: url_helper
INFO - 2018-05-19 12:08:59 --> Helper loaded: notification_helper
INFO - 2018-05-19 12:08:59 --> Helper loaded: settings_helper
INFO - 2018-05-19 12:08:59 --> Helper loaded: permission_helper
INFO - 2018-05-19 12:08:59 --> Helper loaded: users_helper
INFO - 2018-05-19 12:08:59 --> Database Driver Class Initialized
INFO - 2018-05-19 06:38:59 --> Config Class Initialized
INFO - 2018-05-19 06:38:59 --> Hooks Class Initialized
DEBUG - 2018-05-19 12:08:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 12:08:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-05-19 06:38:59 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:38:59 --> Utf8 Class Initialized
INFO - 2018-05-19 06:38:59 --> URI Class Initialized
INFO - 2018-05-19 06:38:59 --> Router Class Initialized
INFO - 2018-05-19 12:08:59 --> Helper loaded: form_helper
INFO - 2018-05-19 12:08:59 --> Form Validation Class Initialized
INFO - 2018-05-19 12:08:59 --> Controller Class Initialized
INFO - 2018-05-19 06:38:59 --> Output Class Initialized
INFO - 2018-05-19 06:38:59 --> Security Class Initialized
DEBUG - 2018-05-19 06:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:38:59 --> Input Class Initialized
INFO - 2018-05-19 06:38:59 --> Language Class Initialized
INFO - 2018-05-19 12:08:59 --> Model Class Initialized
INFO - 2018-05-19 12:08:59 --> Helper loaded: inflector_helper
DEBUG - 2018-05-19 12:08:59 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-19 12:08:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-19 12:08:59 --> Model Class Initialized
INFO - 2018-05-19 12:08:59 --> Model Class Initialized
INFO - 2018-05-19 12:08:59 --> Model Class Initialized
INFO - 2018-05-19 12:08:59 --> Model Class Initialized
INFO - 2018-05-19 12:08:59 --> Model Class Initialized
INFO - 2018-05-19 12:08:59 --> Model Class Initialized
INFO - 2018-05-19 12:08:59 --> Model Class Initialized
INFO - 2018-05-19 12:08:59 --> Model Class Initialized
INFO - 2018-05-19 12:08:59 --> Model Class Initialized
INFO - 2018-05-19 12:08:59 --> Model Class Initialized
INFO - 2018-05-19 12:08:59 --> Model Class Initialized
INFO - 2018-05-19 12:08:59 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-19 12:08:59 --> Model Class Initialized
INFO - 2018-05-19 06:38:59 --> Language Class Initialized
INFO - 2018-05-19 06:38:59 --> Config Class Initialized
INFO - 2018-05-19 06:38:59 --> Loader Class Initialized
INFO - 2018-05-19 12:08:59 --> Helper loaded: url_helper
INFO - 2018-05-19 12:08:59 --> Helper loaded: notification_helper
INFO - 2018-05-19 12:08:59 --> Helper loaded: settings_helper
INFO - 2018-05-19 12:08:59 --> Helper loaded: permission_helper
INFO - 2018-05-19 12:08:59 --> Helper loaded: users_helper
INFO - 2018-05-19 12:08:59 --> Final output sent to browser
DEBUG - 2018-05-19 12:08:59 --> Total execution time: 0.1251
INFO - 2018-05-19 12:08:59 --> Database Driver Class Initialized
DEBUG - 2018-05-19 12:08:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 12:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 12:08:59 --> Helper loaded: form_helper
INFO - 2018-05-19 12:08:59 --> Form Validation Class Initialized
INFO - 2018-05-19 12:08:59 --> Controller Class Initialized
INFO - 2018-05-19 12:08:59 --> Model Class Initialized
INFO - 2018-05-19 12:08:59 --> Helper loaded: inflector_helper
DEBUG - 2018-05-19 12:08:59 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-19 12:08:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-19 12:08:59 --> Model Class Initialized
INFO - 2018-05-19 12:08:59 --> Model Class Initialized
INFO - 2018-05-19 12:08:59 --> Model Class Initialized
INFO - 2018-05-19 12:08:59 --> Model Class Initialized
INFO - 2018-05-19 12:08:59 --> Model Class Initialized
INFO - 2018-05-19 12:08:59 --> Model Class Initialized
INFO - 2018-05-19 12:08:59 --> Model Class Initialized
INFO - 2018-05-19 12:08:59 --> Model Class Initialized
INFO - 2018-05-19 12:08:59 --> Model Class Initialized
INFO - 2018-05-19 12:08:59 --> Model Class Initialized
INFO - 2018-05-19 12:08:59 --> Model Class Initialized
INFO - 2018-05-19 12:08:59 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-19 12:08:59 --> Final output sent to browser
DEBUG - 2018-05-19 12:08:59 --> Total execution time: 0.1419
INFO - 2018-05-19 06:39:04 --> Config Class Initialized
INFO - 2018-05-19 06:39:04 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:39:04 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:39:04 --> Utf8 Class Initialized
INFO - 2018-05-19 06:39:04 --> URI Class Initialized
INFO - 2018-05-19 06:39:04 --> Router Class Initialized
INFO - 2018-05-19 06:39:04 --> Output Class Initialized
INFO - 2018-05-19 06:39:04 --> Security Class Initialized
DEBUG - 2018-05-19 06:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:39:04 --> Input Class Initialized
INFO - 2018-05-19 06:39:04 --> Language Class Initialized
INFO - 2018-05-19 06:39:04 --> Language Class Initialized
INFO - 2018-05-19 06:39:04 --> Config Class Initialized
INFO - 2018-05-19 06:39:04 --> Loader Class Initialized
INFO - 2018-05-19 12:09:04 --> Helper loaded: url_helper
INFO - 2018-05-19 12:09:04 --> Helper loaded: notification_helper
INFO - 2018-05-19 12:09:04 --> Helper loaded: settings_helper
INFO - 2018-05-19 12:09:04 --> Helper loaded: permission_helper
INFO - 2018-05-19 12:09:04 --> Helper loaded: users_helper
INFO - 2018-05-19 12:09:04 --> Database Driver Class Initialized
DEBUG - 2018-05-19 12:09:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 12:09:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 12:09:04 --> Helper loaded: form_helper
INFO - 2018-05-19 12:09:04 --> Form Validation Class Initialized
INFO - 2018-05-19 12:09:04 --> Controller Class Initialized
INFO - 2018-05-19 12:09:04 --> Model Class Initialized
INFO - 2018-05-19 12:09:04 --> Helper loaded: inflector_helper
DEBUG - 2018-05-19 12:09:04 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-19 12:09:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-19 12:09:04 --> Model Class Initialized
INFO - 2018-05-19 12:09:04 --> Model Class Initialized
INFO - 2018-05-19 12:09:04 --> Model Class Initialized
INFO - 2018-05-19 12:09:04 --> Model Class Initialized
INFO - 2018-05-19 12:09:04 --> Model Class Initialized
INFO - 2018-05-19 12:09:04 --> Model Class Initialized
INFO - 2018-05-19 12:09:04 --> Model Class Initialized
INFO - 2018-05-19 12:09:04 --> Model Class Initialized
INFO - 2018-05-19 12:09:04 --> Model Class Initialized
INFO - 2018-05-19 12:09:04 --> Model Class Initialized
INFO - 2018-05-19 12:09:04 --> Model Class Initialized
INFO - 2018-05-19 12:09:04 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-19 12:09:04 --> Final output sent to browser
DEBUG - 2018-05-19 12:09:04 --> Total execution time: 0.1365
INFO - 2018-05-19 06:39:09 --> Config Class Initialized
INFO - 2018-05-19 06:39:09 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:39:09 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:39:09 --> Utf8 Class Initialized
INFO - 2018-05-19 06:39:09 --> URI Class Initialized
INFO - 2018-05-19 06:39:09 --> Router Class Initialized
INFO - 2018-05-19 06:39:09 --> Output Class Initialized
INFO - 2018-05-19 06:39:09 --> Security Class Initialized
DEBUG - 2018-05-19 06:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:39:09 --> Input Class Initialized
INFO - 2018-05-19 06:39:09 --> Language Class Initialized
INFO - 2018-05-19 06:39:09 --> Language Class Initialized
INFO - 2018-05-19 06:39:09 --> Config Class Initialized
INFO - 2018-05-19 06:39:09 --> Loader Class Initialized
INFO - 2018-05-19 12:09:09 --> Helper loaded: url_helper
INFO - 2018-05-19 12:09:09 --> Helper loaded: notification_helper
INFO - 2018-05-19 12:09:09 --> Helper loaded: settings_helper
INFO - 2018-05-19 12:09:09 --> Helper loaded: permission_helper
INFO - 2018-05-19 12:09:09 --> Helper loaded: users_helper
INFO - 2018-05-19 12:09:09 --> Database Driver Class Initialized
DEBUG - 2018-05-19 12:09:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 12:09:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 12:09:09 --> Helper loaded: form_helper
INFO - 2018-05-19 12:09:09 --> Form Validation Class Initialized
INFO - 2018-05-19 12:09:09 --> Controller Class Initialized
INFO - 2018-05-19 12:09:09 --> Model Class Initialized
INFO - 2018-05-19 12:09:09 --> Helper loaded: inflector_helper
DEBUG - 2018-05-19 12:09:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-19 12:09:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-19 12:09:09 --> Model Class Initialized
INFO - 2018-05-19 12:09:09 --> Model Class Initialized
INFO - 2018-05-19 12:09:09 --> Model Class Initialized
INFO - 2018-05-19 12:09:09 --> Model Class Initialized
INFO - 2018-05-19 12:09:09 --> Model Class Initialized
INFO - 2018-05-19 12:09:09 --> Model Class Initialized
INFO - 2018-05-19 12:09:09 --> Model Class Initialized
INFO - 2018-05-19 12:09:09 --> Model Class Initialized
INFO - 2018-05-19 12:09:09 --> Model Class Initialized
INFO - 2018-05-19 12:09:09 --> Model Class Initialized
INFO - 2018-05-19 12:09:09 --> Model Class Initialized
INFO - 2018-05-19 12:09:09 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-19 12:09:09 --> Model Class Initialized
INFO - 2018-05-19 12:09:09 --> Final output sent to browser
DEBUG - 2018-05-19 12:09:09 --> Total execution time: 0.1610
INFO - 2018-05-19 06:39:13 --> Config Class Initialized
INFO - 2018-05-19 06:39:13 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:39:13 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:39:13 --> Utf8 Class Initialized
INFO - 2018-05-19 06:39:13 --> URI Class Initialized
INFO - 2018-05-19 06:39:13 --> Router Class Initialized
INFO - 2018-05-19 06:39:13 --> Output Class Initialized
INFO - 2018-05-19 06:39:13 --> Security Class Initialized
DEBUG - 2018-05-19 06:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:39:13 --> Input Class Initialized
INFO - 2018-05-19 06:39:13 --> Language Class Initialized
INFO - 2018-05-19 06:39:13 --> Language Class Initialized
INFO - 2018-05-19 06:39:13 --> Config Class Initialized
INFO - 2018-05-19 06:39:13 --> Loader Class Initialized
INFO - 2018-05-19 12:09:13 --> Helper loaded: url_helper
INFO - 2018-05-19 12:09:13 --> Helper loaded: notification_helper
INFO - 2018-05-19 12:09:13 --> Helper loaded: settings_helper
INFO - 2018-05-19 12:09:13 --> Helper loaded: permission_helper
INFO - 2018-05-19 12:09:13 --> Helper loaded: users_helper
INFO - 2018-05-19 12:09:13 --> Database Driver Class Initialized
DEBUG - 2018-05-19 12:09:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 12:09:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 12:09:13 --> Helper loaded: form_helper
INFO - 2018-05-19 12:09:13 --> Form Validation Class Initialized
INFO - 2018-05-19 12:09:13 --> Controller Class Initialized
INFO - 2018-05-19 12:09:13 --> Model Class Initialized
INFO - 2018-05-19 12:09:13 --> Helper loaded: inflector_helper
DEBUG - 2018-05-19 12:09:13 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-19 12:09:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-19 12:09:13 --> Model Class Initialized
INFO - 2018-05-19 12:09:13 --> Model Class Initialized
INFO - 2018-05-19 12:09:13 --> Model Class Initialized
INFO - 2018-05-19 12:09:13 --> Model Class Initialized
INFO - 2018-05-19 12:09:13 --> Model Class Initialized
INFO - 2018-05-19 12:09:13 --> Model Class Initialized
INFO - 2018-05-19 12:09:13 --> Model Class Initialized
INFO - 2018-05-19 12:09:13 --> Model Class Initialized
INFO - 2018-05-19 12:09:13 --> Model Class Initialized
INFO - 2018-05-19 12:09:13 --> Model Class Initialized
INFO - 2018-05-19 12:09:13 --> Model Class Initialized
INFO - 2018-05-19 12:09:13 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-19 12:09:13 --> Final output sent to browser
DEBUG - 2018-05-19 12:09:13 --> Total execution time: 0.0909
INFO - 2018-05-19 06:39:18 --> Config Class Initialized
INFO - 2018-05-19 06:39:18 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:39:18 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:39:18 --> Utf8 Class Initialized
INFO - 2018-05-19 06:39:18 --> URI Class Initialized
INFO - 2018-05-19 06:39:18 --> Router Class Initialized
INFO - 2018-05-19 06:39:18 --> Output Class Initialized
INFO - 2018-05-19 06:39:18 --> Security Class Initialized
DEBUG - 2018-05-19 06:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:39:18 --> Input Class Initialized
INFO - 2018-05-19 06:39:18 --> Language Class Initialized
INFO - 2018-05-19 06:39:18 --> Language Class Initialized
INFO - 2018-05-19 06:39:18 --> Config Class Initialized
INFO - 2018-05-19 06:39:18 --> Loader Class Initialized
INFO - 2018-05-19 12:09:18 --> Helper loaded: url_helper
INFO - 2018-05-19 12:09:18 --> Helper loaded: notification_helper
INFO - 2018-05-19 12:09:18 --> Helper loaded: settings_helper
INFO - 2018-05-19 12:09:18 --> Helper loaded: permission_helper
INFO - 2018-05-19 12:09:18 --> Helper loaded: users_helper
INFO - 2018-05-19 12:09:18 --> Database Driver Class Initialized
DEBUG - 2018-05-19 12:09:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 12:09:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 12:09:18 --> Helper loaded: form_helper
INFO - 2018-05-19 12:09:18 --> Form Validation Class Initialized
INFO - 2018-05-19 12:09:18 --> Controller Class Initialized
INFO - 2018-05-19 12:09:18 --> Model Class Initialized
INFO - 2018-05-19 12:09:18 --> Helper loaded: inflector_helper
DEBUG - 2018-05-19 12:09:18 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-19 12:09:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-19 12:09:18 --> Model Class Initialized
INFO - 2018-05-19 12:09:18 --> Model Class Initialized
INFO - 2018-05-19 12:09:18 --> Model Class Initialized
INFO - 2018-05-19 12:09:18 --> Model Class Initialized
INFO - 2018-05-19 12:09:18 --> Model Class Initialized
INFO - 2018-05-19 12:09:18 --> Model Class Initialized
INFO - 2018-05-19 12:09:18 --> Model Class Initialized
INFO - 2018-05-19 12:09:18 --> Model Class Initialized
INFO - 2018-05-19 12:09:18 --> Model Class Initialized
INFO - 2018-05-19 12:09:18 --> Model Class Initialized
INFO - 2018-05-19 12:09:18 --> Model Class Initialized
INFO - 2018-05-19 12:09:18 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-19 12:09:18 --> Final output sent to browser
DEBUG - 2018-05-19 12:09:18 --> Total execution time: 0.1233
INFO - 2018-05-19 06:39:21 --> Config Class Initialized
INFO - 2018-05-19 06:39:21 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:39:21 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:39:21 --> Utf8 Class Initialized
INFO - 2018-05-19 06:39:21 --> URI Class Initialized
INFO - 2018-05-19 06:39:21 --> Router Class Initialized
INFO - 2018-05-19 06:39:21 --> Output Class Initialized
INFO - 2018-05-19 06:39:21 --> Security Class Initialized
DEBUG - 2018-05-19 06:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:39:21 --> Input Class Initialized
INFO - 2018-05-19 06:39:21 --> Language Class Initialized
INFO - 2018-05-19 06:39:21 --> Language Class Initialized
INFO - 2018-05-19 06:39:21 --> Config Class Initialized
INFO - 2018-05-19 06:39:21 --> Loader Class Initialized
INFO - 2018-05-19 12:09:21 --> Helper loaded: url_helper
INFO - 2018-05-19 12:09:21 --> Helper loaded: notification_helper
INFO - 2018-05-19 12:09:21 --> Helper loaded: settings_helper
INFO - 2018-05-19 12:09:21 --> Helper loaded: permission_helper
INFO - 2018-05-19 12:09:21 --> Helper loaded: users_helper
INFO - 2018-05-19 12:09:21 --> Database Driver Class Initialized
DEBUG - 2018-05-19 12:09:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 12:09:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 12:09:21 --> Helper loaded: form_helper
INFO - 2018-05-19 12:09:21 --> Form Validation Class Initialized
INFO - 2018-05-19 12:09:21 --> Controller Class Initialized
INFO - 2018-05-19 12:09:21 --> Model Class Initialized
INFO - 2018-05-19 12:09:21 --> Helper loaded: inflector_helper
DEBUG - 2018-05-19 12:09:21 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-19 12:09:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-19 12:09:21 --> Model Class Initialized
INFO - 2018-05-19 12:09:21 --> Model Class Initialized
INFO - 2018-05-19 12:09:21 --> Model Class Initialized
INFO - 2018-05-19 12:09:21 --> Model Class Initialized
INFO - 2018-05-19 12:09:21 --> Model Class Initialized
INFO - 2018-05-19 12:09:21 --> Model Class Initialized
ERROR - 2018-05-19 12:09:21 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/FilterOption.php 79
INFO - 2018-05-19 12:09:21 --> Final output sent to browser
DEBUG - 2018-05-19 12:09:21 --> Total execution time: 0.2049
INFO - 2018-05-19 06:39:23 --> Config Class Initialized
INFO - 2018-05-19 06:39:23 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:39:23 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:39:23 --> Utf8 Class Initialized
INFO - 2018-05-19 06:39:23 --> URI Class Initialized
INFO - 2018-05-19 06:39:23 --> Router Class Initialized
INFO - 2018-05-19 06:39:23 --> Output Class Initialized
INFO - 2018-05-19 06:39:23 --> Security Class Initialized
DEBUG - 2018-05-19 06:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:39:23 --> Input Class Initialized
INFO - 2018-05-19 06:39:23 --> Language Class Initialized
INFO - 2018-05-19 06:39:23 --> Language Class Initialized
INFO - 2018-05-19 06:39:23 --> Config Class Initialized
INFO - 2018-05-19 06:39:23 --> Loader Class Initialized
INFO - 2018-05-19 12:09:23 --> Helper loaded: url_helper
INFO - 2018-05-19 12:09:23 --> Helper loaded: notification_helper
INFO - 2018-05-19 12:09:23 --> Helper loaded: settings_helper
INFO - 2018-05-19 12:09:23 --> Helper loaded: permission_helper
INFO - 2018-05-19 12:09:23 --> Helper loaded: users_helper
INFO - 2018-05-19 12:09:23 --> Database Driver Class Initialized
DEBUG - 2018-05-19 12:09:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 12:09:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 12:09:23 --> Helper loaded: form_helper
INFO - 2018-05-19 12:09:23 --> Form Validation Class Initialized
INFO - 2018-05-19 12:09:23 --> Controller Class Initialized
INFO - 2018-05-19 12:09:23 --> Model Class Initialized
INFO - 2018-05-19 12:09:23 --> Helper loaded: inflector_helper
DEBUG - 2018-05-19 12:09:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-19 12:09:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-19 12:09:23 --> Model Class Initialized
INFO - 2018-05-19 12:09:23 --> Model Class Initialized
INFO - 2018-05-19 12:09:23 --> Model Class Initialized
INFO - 2018-05-19 12:09:23 --> Model Class Initialized
INFO - 2018-05-19 12:09:23 --> Model Class Initialized
INFO - 2018-05-19 12:09:23 --> Model Class Initialized
ERROR - 2018-05-19 12:09:23 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/FilterOption.php 79
INFO - 2018-05-19 12:09:23 --> Final output sent to browser
DEBUG - 2018-05-19 12:09:23 --> Total execution time: 0.1179
INFO - 2018-05-19 06:39:45 --> Config Class Initialized
INFO - 2018-05-19 06:39:45 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:39:45 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:39:45 --> Utf8 Class Initialized
INFO - 2018-05-19 06:39:45 --> URI Class Initialized
INFO - 2018-05-19 06:39:45 --> Router Class Initialized
INFO - 2018-05-19 06:39:45 --> Output Class Initialized
INFO - 2018-05-19 06:39:45 --> Security Class Initialized
DEBUG - 2018-05-19 06:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:39:45 --> Input Class Initialized
INFO - 2018-05-19 06:39:45 --> Language Class Initialized
INFO - 2018-05-19 06:39:45 --> Language Class Initialized
INFO - 2018-05-19 06:39:45 --> Config Class Initialized
INFO - 2018-05-19 06:39:45 --> Loader Class Initialized
INFO - 2018-05-19 12:09:45 --> Helper loaded: url_helper
INFO - 2018-05-19 12:09:45 --> Helper loaded: notification_helper
INFO - 2018-05-19 12:09:45 --> Helper loaded: settings_helper
INFO - 2018-05-19 12:09:45 --> Helper loaded: permission_helper
INFO - 2018-05-19 12:09:45 --> Helper loaded: users_helper
INFO - 2018-05-19 12:09:45 --> Database Driver Class Initialized
DEBUG - 2018-05-19 12:09:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 12:09:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 12:09:45 --> Helper loaded: form_helper
INFO - 2018-05-19 12:09:45 --> Form Validation Class Initialized
INFO - 2018-05-19 12:09:45 --> Controller Class Initialized
INFO - 2018-05-19 12:09:45 --> Model Class Initialized
INFO - 2018-05-19 12:09:45 --> Helper loaded: inflector_helper
DEBUG - 2018-05-19 12:09:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-19 12:09:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-19 12:09:45 --> Model Class Initialized
INFO - 2018-05-19 12:09:45 --> Model Class Initialized
INFO - 2018-05-19 12:09:45 --> Model Class Initialized
INFO - 2018-05-19 12:09:45 --> Model Class Initialized
INFO - 2018-05-19 12:09:45 --> Model Class Initialized
INFO - 2018-05-19 12:09:45 --> Model Class Initialized
ERROR - 2018-05-19 12:09:45 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/FilterOption.php 79
INFO - 2018-05-19 12:09:45 --> Final output sent to browser
DEBUG - 2018-05-19 12:09:45 --> Total execution time: 0.1121
INFO - 2018-05-19 06:40:06 --> Config Class Initialized
INFO - 2018-05-19 06:40:06 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:40:06 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:40:06 --> Utf8 Class Initialized
INFO - 2018-05-19 06:40:06 --> URI Class Initialized
INFO - 2018-05-19 06:40:06 --> Router Class Initialized
INFO - 2018-05-19 06:40:06 --> Output Class Initialized
INFO - 2018-05-19 06:40:06 --> Security Class Initialized
DEBUG - 2018-05-19 06:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:40:06 --> Input Class Initialized
INFO - 2018-05-19 06:40:06 --> Language Class Initialized
INFO - 2018-05-19 06:40:06 --> Language Class Initialized
INFO - 2018-05-19 06:40:06 --> Config Class Initialized
INFO - 2018-05-19 06:40:06 --> Loader Class Initialized
INFO - 2018-05-19 12:10:06 --> Helper loaded: url_helper
INFO - 2018-05-19 12:10:06 --> Helper loaded: notification_helper
INFO - 2018-05-19 12:10:06 --> Helper loaded: settings_helper
INFO - 2018-05-19 12:10:06 --> Helper loaded: permission_helper
INFO - 2018-05-19 12:10:06 --> Helper loaded: users_helper
INFO - 2018-05-19 12:10:06 --> Database Driver Class Initialized
DEBUG - 2018-05-19 12:10:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 12:10:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 12:10:06 --> Helper loaded: form_helper
INFO - 2018-05-19 12:10:06 --> Form Validation Class Initialized
INFO - 2018-05-19 12:10:06 --> Controller Class Initialized
INFO - 2018-05-19 12:10:06 --> Model Class Initialized
INFO - 2018-05-19 12:10:06 --> Helper loaded: inflector_helper
DEBUG - 2018-05-19 12:10:06 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-19 12:10:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-19 12:10:06 --> Model Class Initialized
INFO - 2018-05-19 12:10:06 --> Model Class Initialized
INFO - 2018-05-19 12:10:06 --> Model Class Initialized
INFO - 2018-05-19 12:10:06 --> Model Class Initialized
INFO - 2018-05-19 12:10:06 --> Model Class Initialized
INFO - 2018-05-19 12:10:06 --> Final output sent to browser
DEBUG - 2018-05-19 12:10:06 --> Total execution time: 0.0965
INFO - 2018-05-19 06:40:07 --> Config Class Initialized
INFO - 2018-05-19 06:40:07 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:40:07 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:40:07 --> Utf8 Class Initialized
INFO - 2018-05-19 06:40:07 --> URI Class Initialized
INFO - 2018-05-19 06:40:07 --> Router Class Initialized
INFO - 2018-05-19 06:40:07 --> Output Class Initialized
INFO - 2018-05-19 06:40:07 --> Security Class Initialized
DEBUG - 2018-05-19 06:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:40:07 --> Input Class Initialized
INFO - 2018-05-19 06:40:07 --> Language Class Initialized
INFO - 2018-05-19 06:40:08 --> Language Class Initialized
INFO - 2018-05-19 06:40:08 --> Config Class Initialized
INFO - 2018-05-19 06:40:08 --> Loader Class Initialized
INFO - 2018-05-19 12:10:08 --> Helper loaded: url_helper
INFO - 2018-05-19 12:10:08 --> Helper loaded: notification_helper
INFO - 2018-05-19 12:10:08 --> Helper loaded: settings_helper
INFO - 2018-05-19 12:10:08 --> Helper loaded: permission_helper
INFO - 2018-05-19 12:10:08 --> Helper loaded: users_helper
INFO - 2018-05-19 12:10:08 --> Database Driver Class Initialized
DEBUG - 2018-05-19 12:10:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 12:10:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 12:10:08 --> Helper loaded: form_helper
INFO - 2018-05-19 12:10:08 --> Form Validation Class Initialized
INFO - 2018-05-19 12:10:08 --> Controller Class Initialized
INFO - 2018-05-19 12:10:08 --> Model Class Initialized
INFO - 2018-05-19 12:10:08 --> Helper loaded: inflector_helper
DEBUG - 2018-05-19 12:10:08 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-19 12:10:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-19 12:10:08 --> Model Class Initialized
INFO - 2018-05-19 12:10:08 --> Model Class Initialized
INFO - 2018-05-19 12:10:08 --> Model Class Initialized
INFO - 2018-05-19 12:10:08 --> Model Class Initialized
INFO - 2018-05-19 12:10:08 --> Model Class Initialized
INFO - 2018-05-19 12:10:08 --> Model Class Initialized
INFO - 2018-05-19 12:10:08 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-05-19 12:10:08 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 794
ERROR - 2018-05-19 12:10:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 804
INFO - 2018-05-19 12:10:08 --> Final output sent to browser
DEBUG - 2018-05-19 12:10:08 --> Total execution time: 0.1732
INFO - 2018-05-19 06:40:09 --> Config Class Initialized
INFO - 2018-05-19 06:40:09 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:40:09 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:40:09 --> Utf8 Class Initialized
INFO - 2018-05-19 06:40:09 --> URI Class Initialized
INFO - 2018-05-19 06:40:09 --> Router Class Initialized
INFO - 2018-05-19 06:40:09 --> Output Class Initialized
INFO - 2018-05-19 06:40:09 --> Security Class Initialized
DEBUG - 2018-05-19 06:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:40:09 --> Input Class Initialized
INFO - 2018-05-19 06:40:09 --> Language Class Initialized
INFO - 2018-05-19 06:40:09 --> Language Class Initialized
INFO - 2018-05-19 06:40:09 --> Config Class Initialized
INFO - 2018-05-19 06:40:09 --> Loader Class Initialized
INFO - 2018-05-19 12:10:09 --> Helper loaded: url_helper
INFO - 2018-05-19 12:10:09 --> Helper loaded: notification_helper
INFO - 2018-05-19 12:10:09 --> Helper loaded: settings_helper
INFO - 2018-05-19 12:10:09 --> Helper loaded: permission_helper
INFO - 2018-05-19 12:10:09 --> Helper loaded: users_helper
INFO - 2018-05-19 12:10:09 --> Database Driver Class Initialized
DEBUG - 2018-05-19 12:10:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 12:10:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 12:10:09 --> Helper loaded: form_helper
INFO - 2018-05-19 12:10:09 --> Form Validation Class Initialized
INFO - 2018-05-19 12:10:09 --> Controller Class Initialized
INFO - 2018-05-19 12:10:09 --> Model Class Initialized
INFO - 2018-05-19 12:10:09 --> Helper loaded: inflector_helper
DEBUG - 2018-05-19 12:10:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-19 12:10:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-19 12:10:09 --> Model Class Initialized
INFO - 2018-05-19 12:10:09 --> Model Class Initialized
INFO - 2018-05-19 12:10:09 --> Model Class Initialized
INFO - 2018-05-19 12:10:09 --> Model Class Initialized
INFO - 2018-05-19 12:10:09 --> Model Class Initialized
INFO - 2018-05-19 12:10:09 --> Model Class Initialized
INFO - 2018-05-19 12:10:09 --> Model Class Initialized
INFO - 2018-05-19 12:10:09 --> Model Class Initialized
INFO - 2018-05-19 12:10:09 --> Model Class Initialized
INFO - 2018-05-19 12:10:09 --> Model Class Initialized
INFO - 2018-05-19 12:10:09 --> Model Class Initialized
INFO - 2018-05-19 12:10:09 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-19 12:10:09 --> Model Class Initialized
INFO - 2018-05-19 12:10:09 --> Final output sent to browser
DEBUG - 2018-05-19 12:10:09 --> Total execution time: 0.1490
INFO - 2018-05-19 06:40:10 --> Config Class Initialized
INFO - 2018-05-19 06:40:10 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:40:10 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:40:10 --> Utf8 Class Initialized
INFO - 2018-05-19 06:40:10 --> URI Class Initialized
INFO - 2018-05-19 06:40:10 --> Router Class Initialized
INFO - 2018-05-19 06:40:10 --> Output Class Initialized
INFO - 2018-05-19 06:40:10 --> Config Class Initialized
INFO - 2018-05-19 06:40:10 --> Hooks Class Initialized
INFO - 2018-05-19 06:40:10 --> Security Class Initialized
DEBUG - 2018-05-19 06:40:10 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:40:10 --> Utf8 Class Initialized
DEBUG - 2018-05-19 06:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:40:10 --> Input Class Initialized
INFO - 2018-05-19 06:40:10 --> Language Class Initialized
INFO - 2018-05-19 06:40:10 --> URI Class Initialized
INFO - 2018-05-19 06:40:10 --> Router Class Initialized
INFO - 2018-05-19 06:40:10 --> Output Class Initialized
INFO - 2018-05-19 06:40:10 --> Security Class Initialized
DEBUG - 2018-05-19 06:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:40:10 --> Input Class Initialized
INFO - 2018-05-19 06:40:10 --> Language Class Initialized
INFO - 2018-05-19 06:40:10 --> Config Class Initialized
INFO - 2018-05-19 06:40:10 --> Loader Class Initialized
INFO - 2018-05-19 06:40:10 --> Language Class Initialized
INFO - 2018-05-19 12:10:10 --> Helper loaded: url_helper
INFO - 2018-05-19 12:10:10 --> Helper loaded: notification_helper
INFO - 2018-05-19 12:10:10 --> Helper loaded: settings_helper
INFO - 2018-05-19 12:10:10 --> Helper loaded: permission_helper
INFO - 2018-05-19 12:10:10 --> Helper loaded: users_helper
INFO - 2018-05-19 12:10:10 --> Database Driver Class Initialized
INFO - 2018-05-19 06:40:10 --> Language Class Initialized
INFO - 2018-05-19 06:40:10 --> Config Class Initialized
INFO - 2018-05-19 06:40:10 --> Loader Class Initialized
DEBUG - 2018-05-19 12:10:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 12:10:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 12:10:10 --> Helper loaded: url_helper
INFO - 2018-05-19 12:10:10 --> Helper loaded: notification_helper
INFO - 2018-05-19 12:10:10 --> Helper loaded: settings_helper
INFO - 2018-05-19 12:10:10 --> Helper loaded: permission_helper
INFO - 2018-05-19 12:10:10 --> Helper loaded: form_helper
INFO - 2018-05-19 12:10:10 --> Form Validation Class Initialized
INFO - 2018-05-19 12:10:10 --> Controller Class Initialized
INFO - 2018-05-19 12:10:10 --> Helper loaded: users_helper
INFO - 2018-05-19 12:10:10 --> Model Class Initialized
INFO - 2018-05-19 12:10:10 --> Helper loaded: inflector_helper
DEBUG - 2018-05-19 12:10:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-19 12:10:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-19 12:10:10 --> Model Class Initialized
INFO - 2018-05-19 12:10:10 --> Model Class Initialized
INFO - 2018-05-19 12:10:10 --> Model Class Initialized
INFO - 2018-05-19 12:10:10 --> Model Class Initialized
INFO - 2018-05-19 12:10:10 --> Model Class Initialized
INFO - 2018-05-19 12:10:10 --> Model Class Initialized
INFO - 2018-05-19 12:10:10 --> Model Class Initialized
INFO - 2018-05-19 12:10:10 --> Model Class Initialized
INFO - 2018-05-19 12:10:10 --> Model Class Initialized
INFO - 2018-05-19 12:10:10 --> Model Class Initialized
INFO - 2018-05-19 12:10:10 --> Model Class Initialized
INFO - 2018-05-19 12:10:10 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-19 12:10:10 --> Database Driver Class Initialized
INFO - 2018-05-19 12:10:10 --> Final output sent to browser
DEBUG - 2018-05-19 12:10:10 --> Total execution time: 0.2003
DEBUG - 2018-05-19 12:10:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 12:10:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 12:10:10 --> Helper loaded: form_helper
INFO - 2018-05-19 12:10:10 --> Form Validation Class Initialized
INFO - 2018-05-19 12:10:10 --> Controller Class Initialized
INFO - 2018-05-19 12:10:10 --> Model Class Initialized
INFO - 2018-05-19 12:10:10 --> Helper loaded: inflector_helper
DEBUG - 2018-05-19 12:10:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-19 12:10:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-19 12:10:10 --> Model Class Initialized
INFO - 2018-05-19 12:10:10 --> Model Class Initialized
INFO - 2018-05-19 12:10:10 --> Model Class Initialized
INFO - 2018-05-19 12:10:10 --> Model Class Initialized
INFO - 2018-05-19 12:10:10 --> Model Class Initialized
INFO - 2018-05-19 12:10:10 --> Model Class Initialized
INFO - 2018-05-19 12:10:10 --> Model Class Initialized
INFO - 2018-05-19 12:10:10 --> Model Class Initialized
INFO - 2018-05-19 12:10:10 --> Model Class Initialized
INFO - 2018-05-19 12:10:10 --> Model Class Initialized
INFO - 2018-05-19 12:10:10 --> Model Class Initialized
INFO - 2018-05-19 12:10:10 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-19 12:10:10 --> Final output sent to browser
DEBUG - 2018-05-19 12:10:10 --> Total execution time: 0.2524
INFO - 2018-05-19 18:30:02 --> Config Class Initialized
INFO - 2018-05-19 18:30:02 --> Hooks Class Initialized
DEBUG - 2018-05-19 18:30:02 --> UTF-8 Support Enabled
INFO - 2018-05-19 18:30:02 --> Utf8 Class Initialized
INFO - 2018-05-19 18:30:02 --> URI Class Initialized
INFO - 2018-05-19 18:30:02 --> Router Class Initialized
INFO - 2018-05-19 18:30:02 --> Output Class Initialized
INFO - 2018-05-19 18:30:02 --> Security Class Initialized
DEBUG - 2018-05-19 18:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 18:30:02 --> Input Class Initialized
INFO - 2018-05-19 18:30:02 --> Language Class Initialized
INFO - 2018-05-19 18:30:02 --> Language Class Initialized
INFO - 2018-05-19 18:30:02 --> Config Class Initialized
INFO - 2018-05-19 18:30:02 --> Loader Class Initialized
INFO - 2018-05-19 18:30:02 --> Config Class Initialized
INFO - 2018-05-19 18:30:02 --> Hooks Class Initialized
DEBUG - 2018-05-19 18:30:02 --> UTF-8 Support Enabled
INFO - 2018-05-19 18:30:02 --> Utf8 Class Initialized
INFO - 2018-05-19 18:30:02 --> URI Class Initialized
INFO - 2018-05-19 18:30:02 --> Router Class Initialized
INFO - 2018-05-19 18:30:02 --> Output Class Initialized
INFO - 2018-05-19 18:30:02 --> Security Class Initialized
DEBUG - 2018-05-19 18:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 18:30:02 --> Input Class Initialized
INFO - 2018-05-19 18:30:02 --> Language Class Initialized
INFO - 2018-05-19 18:30:02 --> Language Class Initialized
INFO - 2018-05-19 18:30:02 --> Config Class Initialized
INFO - 2018-05-19 18:30:02 --> Loader Class Initialized
