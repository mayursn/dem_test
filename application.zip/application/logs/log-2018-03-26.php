<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-03-26 05:43:55 --> Config Class Initialized
INFO - 2018-03-26 05:43:55 --> Hooks Class Initialized
INFO - 2018-03-26 05:43:55 --> Config Class Initialized
INFO - 2018-03-26 05:43:55 --> Config Class Initialized
INFO - 2018-03-26 05:43:55 --> Hooks Class Initialized
INFO - 2018-03-26 05:43:55 --> Hooks Class Initialized
INFO - 2018-03-26 05:43:55 --> Config Class Initialized
INFO - 2018-03-26 05:43:55 --> Hooks Class Initialized
DEBUG - 2018-03-26 05:43:56 --> UTF-8 Support Enabled
INFO - 2018-03-26 05:43:56 --> Utf8 Class Initialized
DEBUG - 2018-03-26 05:43:56 --> UTF-8 Support Enabled
INFO - 2018-03-26 05:43:56 --> Utf8 Class Initialized
DEBUG - 2018-03-26 05:43:56 --> UTF-8 Support Enabled
INFO - 2018-03-26 05:43:56 --> Utf8 Class Initialized
DEBUG - 2018-03-26 05:43:56 --> UTF-8 Support Enabled
INFO - 2018-03-26 05:43:56 --> Utf8 Class Initialized
INFO - 2018-03-26 05:43:56 --> URI Class Initialized
INFO - 2018-03-26 05:43:56 --> URI Class Initialized
INFO - 2018-03-26 05:43:56 --> URI Class Initialized
INFO - 2018-03-26 05:43:56 --> URI Class Initialized
INFO - 2018-03-26 05:43:56 --> Router Class Initialized
INFO - 2018-03-26 05:43:56 --> Router Class Initialized
INFO - 2018-03-26 05:43:56 --> Router Class Initialized
INFO - 2018-03-26 05:43:56 --> Router Class Initialized
INFO - 2018-03-26 05:43:56 --> Output Class Initialized
INFO - 2018-03-26 05:43:56 --> Output Class Initialized
INFO - 2018-03-26 05:43:56 --> Output Class Initialized
INFO - 2018-03-26 05:43:56 --> Security Class Initialized
INFO - 2018-03-26 05:43:56 --> Security Class Initialized
INFO - 2018-03-26 05:43:56 --> Security Class Initialized
DEBUG - 2018-03-26 05:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 05:43:56 --> Input Class Initialized
DEBUG - 2018-03-26 05:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 05:43:56 --> Input Class Initialized
INFO - 2018-03-26 05:43:56 --> Output Class Initialized
INFO - 2018-03-26 05:43:56 --> Language Class Initialized
DEBUG - 2018-03-26 05:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 05:43:56 --> Input Class Initialized
INFO - 2018-03-26 05:43:56 --> Language Class Initialized
INFO - 2018-03-26 05:43:56 --> Language Class Initialized
INFO - 2018-03-26 05:43:56 --> Security Class Initialized
DEBUG - 2018-03-26 05:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 05:43:56 --> Input Class Initialized
INFO - 2018-03-26 05:43:56 --> Language Class Initialized
INFO - 2018-03-26 05:43:56 --> Language Class Initialized
INFO - 2018-03-26 05:43:56 --> Config Class Initialized
INFO - 2018-03-26 05:43:56 --> Loader Class Initialized
INFO - 2018-03-26 05:43:56 --> Language Class Initialized
INFO - 2018-03-26 05:43:56 --> Config Class Initialized
INFO - 2018-03-26 05:43:56 --> Loader Class Initialized
INFO - 2018-03-26 11:13:56 --> Helper loaded: url_helper
INFO - 2018-03-26 05:43:56 --> Language Class Initialized
INFO - 2018-03-26 05:43:56 --> Config Class Initialized
INFO - 2018-03-26 05:43:56 --> Loader Class Initialized
INFO - 2018-03-26 11:13:56 --> Helper loaded: notification_helper
INFO - 2018-03-26 11:13:56 --> Helper loaded: settings_helper
INFO - 2018-03-26 11:13:56 --> Helper loaded: url_helper
INFO - 2018-03-26 11:13:56 --> Helper loaded: permission_helper
INFO - 2018-03-26 11:13:56 --> Helper loaded: url_helper
INFO - 2018-03-26 11:13:56 --> Helper loaded: notification_helper
INFO - 2018-03-26 11:13:56 --> Helper loaded: users_helper
INFO - 2018-03-26 11:13:56 --> Helper loaded: settings_helper
INFO - 2018-03-26 05:43:56 --> Language Class Initialized
INFO - 2018-03-26 05:43:56 --> Config Class Initialized
INFO - 2018-03-26 05:43:56 --> Loader Class Initialized
INFO - 2018-03-26 11:13:56 --> Helper loaded: notification_helper
INFO - 2018-03-26 11:13:56 --> Helper loaded: permission_helper
INFO - 2018-03-26 11:13:56 --> Helper loaded: settings_helper
INFO - 2018-03-26 11:13:56 --> Helper loaded: users_helper
INFO - 2018-03-26 11:13:56 --> Helper loaded: permission_helper
INFO - 2018-03-26 11:13:56 --> Helper loaded: users_helper
INFO - 2018-03-26 11:13:56 --> Helper loaded: url_helper
INFO - 2018-03-26 11:13:56 --> Helper loaded: notification_helper
INFO - 2018-03-26 11:13:56 --> Helper loaded: settings_helper
INFO - 2018-03-26 11:13:56 --> Helper loaded: permission_helper
INFO - 2018-03-26 11:13:56 --> Helper loaded: users_helper
INFO - 2018-03-26 11:13:56 --> Database Driver Class Initialized
INFO - 2018-03-26 11:13:56 --> Database Driver Class Initialized
INFO - 2018-03-26 05:43:56 --> Config Class Initialized
INFO - 2018-03-26 05:43:56 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:13:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:13:56 --> Database Driver Class Initialized
INFO - 2018-03-26 11:13:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:13:56 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:13:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:13:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-03-26 05:43:56 --> UTF-8 Support Enabled
INFO - 2018-03-26 05:43:56 --> Utf8 Class Initialized
DEBUG - 2018-03-26 11:13:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:13:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-03-26 11:13:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:13:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:13:56 --> Helper loaded: form_helper
INFO - 2018-03-26 11:13:56 --> Form Validation Class Initialized
INFO - 2018-03-26 11:13:56 --> Controller Class Initialized
INFO - 2018-03-26 05:43:56 --> URI Class Initialized
INFO - 2018-03-26 05:43:56 --> Router Class Initialized
INFO - 2018-03-26 11:13:56 --> Helper loaded: form_helper
INFO - 2018-03-26 11:13:56 --> Form Validation Class Initialized
INFO - 2018-03-26 11:13:56 --> Controller Class Initialized
INFO - 2018-03-26 11:13:56 --> Helper loaded: form_helper
INFO - 2018-03-26 11:13:56 --> Helper loaded: form_helper
INFO - 2018-03-26 11:13:56 --> Form Validation Class Initialized
INFO - 2018-03-26 11:13:56 --> Form Validation Class Initialized
INFO - 2018-03-26 11:13:56 --> Controller Class Initialized
INFO - 2018-03-26 11:13:56 --> Controller Class Initialized
INFO - 2018-03-26 05:43:56 --> Output Class Initialized
INFO - 2018-03-26 05:43:56 --> Security Class Initialized
DEBUG - 2018-03-26 05:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 05:43:56 --> Input Class Initialized
INFO - 2018-03-26 05:43:56 --> Language Class Initialized
INFO - 2018-03-26 11:13:56 --> Model Class Initialized
INFO - 2018-03-26 11:13:56 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 11:13:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 11:13:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 11:13:56 --> Model Class Initialized
INFO - 2018-03-26 11:13:56 --> Model Class Initialized
INFO - 2018-03-26 11:13:56 --> Model Class Initialized
INFO - 2018-03-26 11:13:56 --> Model Class Initialized
INFO - 2018-03-26 11:13:56 --> Model Class Initialized
INFO - 2018-03-26 11:13:56 --> Model Class Initialized
INFO - 2018-03-26 11:13:56 --> Model Class Initialized
INFO - 2018-03-26 11:13:56 --> Model Class Initialized
INFO - 2018-03-26 11:13:56 --> Model Class Initialized
INFO - 2018-03-26 11:13:56 --> Model Class Initialized
INFO - 2018-03-26 11:13:56 --> Helper loaded: inflector_helper
INFO - 2018-03-26 11:13:56 --> Model Class Initialized
DEBUG - 2018-03-26 11:13:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 11:13:56 --> Model Class Initialized
INFO - 2018-03-26 11:13:56 --> Helper loaded: inflector_helper
INFO - 2018-03-26 11:13:56 --> Model Class Initialized
INFO - 2018-03-26 11:13:56 --> Helper loaded: inflector_helper
INFO - 2018-03-26 11:13:56 --> Model Class Initialized
INFO - 2018-03-26 11:13:56 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 11:13:56 --> Model Class Initialized
DEBUG - 2018-03-26 11:13:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 05:43:56 --> Language Class Initialized
INFO - 2018-03-26 05:43:56 --> Config Class Initialized
INFO - 2018-03-26 05:43:56 --> Loader Class Initialized
INFO - 2018-03-26 11:13:56 --> Helper loaded: url_helper
INFO - 2018-03-26 11:13:56 --> Helper loaded: notification_helper
INFO - 2018-03-26 11:13:56 --> Helper loaded: settings_helper
INFO - 2018-03-26 11:13:56 --> Helper loaded: permission_helper
INFO - 2018-03-26 11:13:56 --> Language file loaded: language/english/rest_controller_lang.php
DEBUG - 2018-03-26 11:13:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 11:13:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 11:13:56 --> Model Class Initialized
INFO - 2018-03-26 11:13:56 --> Model Class Initialized
INFO - 2018-03-26 11:13:56 --> Helper loaded: users_helper
INFO - 2018-03-26 11:13:56 --> Model Class Initialized
INFO - 2018-03-26 11:13:56 --> Model Class Initialized
INFO - 2018-03-26 11:13:56 --> Model Class Initialized
INFO - 2018-03-26 11:13:56 --> Model Class Initialized
INFO - 2018-03-26 11:13:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 11:13:56 --> Model Class Initialized
INFO - 2018-03-26 11:13:56 --> Model Class Initialized
INFO - 2018-03-26 11:13:56 --> Final output sent to browser
DEBUG - 2018-03-26 11:13:56 --> Total execution time: 0.9883
INFO - 2018-03-26 11:13:56 --> Model Class Initialized
INFO - 2018-03-26 11:13:56 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 11:13:56 --> Model Class Initialized
INFO - 2018-03-26 11:13:56 --> Model Class Initialized
INFO - 2018-03-26 11:13:56 --> Model Class Initialized
INFO - 2018-03-26 11:13:56 --> Model Class Initialized
INFO - 2018-03-26 11:13:56 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 11:13:57 --> Model Class Initialized
INFO - 2018-03-26 11:13:57 --> Database Driver Class Initialized
INFO - 2018-03-26 11:13:57 --> Model Class Initialized
INFO - 2018-03-26 11:13:57 --> Final output sent to browser
DEBUG - 2018-03-26 11:13:57 --> Total execution time: 1.0795
INFO - 2018-03-26 11:13:57 --> Model Class Initialized
INFO - 2018-03-26 11:13:57 --> Model Class Initialized
INFO - 2018-03-26 11:13:57 --> Final output sent to browser
DEBUG - 2018-03-26 11:13:57 --> Total execution time: 1.1212
INFO - 2018-03-26 11:13:57 --> Model Class Initialized
DEBUG - 2018-03-26 11:13:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:13:57 --> Model Class Initialized
INFO - 2018-03-26 11:13:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:13:57 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 11:13:57 --> Helper loaded: form_helper
INFO - 2018-03-26 11:13:57 --> Form Validation Class Initialized
INFO - 2018-03-26 11:13:57 --> Controller Class Initialized
INFO - 2018-03-26 11:13:57 --> Model Class Initialized
INFO - 2018-03-26 11:13:57 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 11:13:57 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 11:13:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 11:13:57 --> Model Class Initialized
INFO - 2018-03-26 11:13:57 --> Model Class Initialized
INFO - 2018-03-26 11:13:57 --> Model Class Initialized
INFO - 2018-03-26 11:13:57 --> Model Class Initialized
INFO - 2018-03-26 11:13:57 --> Model Class Initialized
INFO - 2018-03-26 11:13:57 --> Model Class Initialized
INFO - 2018-03-26 11:13:57 --> Model Class Initialized
INFO - 2018-03-26 11:13:57 --> Model Class Initialized
INFO - 2018-03-26 11:13:57 --> Model Class Initialized
INFO - 2018-03-26 11:13:57 --> Model Class Initialized
INFO - 2018-03-26 11:13:57 --> Model Class Initialized
INFO - 2018-03-26 11:13:57 --> Model Class Initialized
INFO - 2018-03-26 11:13:57 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 11:13:57 --> Model Class Initialized
INFO - 2018-03-26 11:13:57 --> Final output sent to browser
DEBUG - 2018-03-26 11:13:57 --> Total execution time: 1.2243
INFO - 2018-03-26 11:13:57 --> Final output sent to browser
DEBUG - 2018-03-26 11:13:57 --> Total execution time: 0.8882
INFO - 2018-03-26 05:43:58 --> Config Class Initialized
INFO - 2018-03-26 05:43:58 --> Hooks Class Initialized
DEBUG - 2018-03-26 05:43:58 --> UTF-8 Support Enabled
INFO - 2018-03-26 05:43:58 --> Utf8 Class Initialized
INFO - 2018-03-26 05:43:58 --> URI Class Initialized
INFO - 2018-03-26 05:43:58 --> Router Class Initialized
INFO - 2018-03-26 05:43:58 --> Output Class Initialized
INFO - 2018-03-26 05:43:58 --> Security Class Initialized
DEBUG - 2018-03-26 05:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 05:43:58 --> Input Class Initialized
INFO - 2018-03-26 05:43:58 --> Language Class Initialized
INFO - 2018-03-26 05:43:58 --> Language Class Initialized
INFO - 2018-03-26 05:43:58 --> Config Class Initialized
INFO - 2018-03-26 05:43:58 --> Loader Class Initialized
INFO - 2018-03-26 11:13:59 --> Helper loaded: url_helper
INFO - 2018-03-26 11:13:59 --> Helper loaded: notification_helper
INFO - 2018-03-26 11:13:59 --> Helper loaded: settings_helper
INFO - 2018-03-26 11:13:59 --> Helper loaded: permission_helper
INFO - 2018-03-26 11:13:59 --> Helper loaded: users_helper
INFO - 2018-03-26 05:44:00 --> Config Class Initialized
INFO - 2018-03-26 05:44:00 --> Hooks Class Initialized
INFO - 2018-03-26 11:14:00 --> Database Driver Class Initialized
DEBUG - 2018-03-26 05:44:00 --> UTF-8 Support Enabled
INFO - 2018-03-26 05:44:00 --> Utf8 Class Initialized
INFO - 2018-03-26 05:44:00 --> URI Class Initialized
DEBUG - 2018-03-26 11:14:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 05:44:00 --> Router Class Initialized
INFO - 2018-03-26 11:14:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:14:00 --> Helper loaded: form_helper
INFO - 2018-03-26 11:14:00 --> Form Validation Class Initialized
INFO - 2018-03-26 11:14:00 --> Controller Class Initialized
INFO - 2018-03-26 05:44:00 --> Output Class Initialized
INFO - 2018-03-26 11:14:00 --> Model Class Initialized
INFO - 2018-03-26 11:14:00 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 11:14:00 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 11:14:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 11:14:00 --> Model Class Initialized
INFO - 2018-03-26 11:14:00 --> Model Class Initialized
INFO - 2018-03-26 11:14:00 --> Model Class Initialized
INFO - 2018-03-26 11:14:00 --> Model Class Initialized
INFO - 2018-03-26 11:14:00 --> Model Class Initialized
INFO - 2018-03-26 11:14:00 --> Model Class Initialized
INFO - 2018-03-26 11:14:00 --> Model Class Initialized
INFO - 2018-03-26 11:14:00 --> Model Class Initialized
INFO - 2018-03-26 11:14:00 --> Model Class Initialized
INFO - 2018-03-26 11:14:00 --> Model Class Initialized
INFO - 2018-03-26 11:14:00 --> Model Class Initialized
INFO - 2018-03-26 11:14:00 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 05:44:00 --> Security Class Initialized
INFO - 2018-03-26 11:14:00 --> Final output sent to browser
DEBUG - 2018-03-26 11:14:00 --> Total execution time: 2.1951
DEBUG - 2018-03-26 05:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 05:44:00 --> Input Class Initialized
INFO - 2018-03-26 05:44:00 --> Language Class Initialized
INFO - 2018-03-26 05:44:00 --> Config Class Initialized
INFO - 2018-03-26 05:44:00 --> Hooks Class Initialized
DEBUG - 2018-03-26 05:44:00 --> UTF-8 Support Enabled
INFO - 2018-03-26 05:44:00 --> Utf8 Class Initialized
INFO - 2018-03-26 05:44:00 --> URI Class Initialized
INFO - 2018-03-26 05:44:00 --> Router Class Initialized
INFO - 2018-03-26 05:44:00 --> Output Class Initialized
INFO - 2018-03-26 05:44:00 --> Security Class Initialized
DEBUG - 2018-03-26 05:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 05:44:00 --> Input Class Initialized
INFO - 2018-03-26 05:44:00 --> Language Class Initialized
INFO - 2018-03-26 05:44:00 --> Language Class Initialized
INFO - 2018-03-26 05:44:00 --> Config Class Initialized
INFO - 2018-03-26 05:44:00 --> Loader Class Initialized
INFO - 2018-03-26 11:14:00 --> Helper loaded: url_helper
INFO - 2018-03-26 11:14:00 --> Helper loaded: notification_helper
INFO - 2018-03-26 11:14:00 --> Helper loaded: settings_helper
INFO - 2018-03-26 11:14:00 --> Helper loaded: permission_helper
INFO - 2018-03-26 11:14:00 --> Helper loaded: users_helper
INFO - 2018-03-26 11:14:00 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:14:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:14:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:14:00 --> Helper loaded: form_helper
INFO - 2018-03-26 11:14:00 --> Form Validation Class Initialized
INFO - 2018-03-26 11:14:00 --> Controller Class Initialized
INFO - 2018-03-26 11:14:00 --> Model Class Initialized
INFO - 2018-03-26 11:14:00 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 11:14:00 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 11:14:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 11:14:00 --> Model Class Initialized
INFO - 2018-03-26 11:14:01 --> Model Class Initialized
INFO - 2018-03-26 11:14:01 --> Model Class Initialized
INFO - 2018-03-26 11:14:01 --> Model Class Initialized
INFO - 2018-03-26 11:14:01 --> Model Class Initialized
INFO - 2018-03-26 11:14:01 --> Model Class Initialized
INFO - 2018-03-26 11:14:01 --> Model Class Initialized
INFO - 2018-03-26 11:14:01 --> Model Class Initialized
INFO - 2018-03-26 11:14:01 --> Model Class Initialized
INFO - 2018-03-26 11:14:01 --> Model Class Initialized
INFO - 2018-03-26 11:14:01 --> Model Class Initialized
INFO - 2018-03-26 11:14:01 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 11:14:01 --> Model Class Initialized
INFO - 2018-03-26 11:14:01 --> Final output sent to browser
DEBUG - 2018-03-26 11:14:01 --> Total execution time: 0.1176
INFO - 2018-03-26 05:44:01 --> Language Class Initialized
INFO - 2018-03-26 05:44:01 --> Config Class Initialized
INFO - 2018-03-26 05:44:01 --> Loader Class Initialized
INFO - 2018-03-26 11:14:01 --> Helper loaded: url_helper
INFO - 2018-03-26 11:14:01 --> Helper loaded: notification_helper
INFO - 2018-03-26 11:14:01 --> Helper loaded: settings_helper
INFO - 2018-03-26 11:14:01 --> Helper loaded: permission_helper
INFO - 2018-03-26 11:14:01 --> Helper loaded: users_helper
INFO - 2018-03-26 11:14:01 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:14:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:14:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:14:01 --> Helper loaded: form_helper
INFO - 2018-03-26 11:14:01 --> Form Validation Class Initialized
INFO - 2018-03-26 11:14:01 --> Controller Class Initialized
INFO - 2018-03-26 11:14:01 --> Model Class Initialized
INFO - 2018-03-26 11:14:01 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 11:14:01 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 11:14:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 11:14:02 --> Model Class Initialized
INFO - 2018-03-26 11:14:02 --> Model Class Initialized
INFO - 2018-03-26 11:14:02 --> Model Class Initialized
INFO - 2018-03-26 11:14:02 --> Model Class Initialized
INFO - 2018-03-26 11:14:02 --> Model Class Initialized
INFO - 2018-03-26 11:14:02 --> Model Class Initialized
INFO - 2018-03-26 11:14:02 --> Model Class Initialized
INFO - 2018-03-26 11:14:02 --> Model Class Initialized
INFO - 2018-03-26 11:14:02 --> Model Class Initialized
INFO - 2018-03-26 11:14:02 --> Model Class Initialized
INFO - 2018-03-26 11:14:02 --> Model Class Initialized
INFO - 2018-03-26 11:14:02 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 11:14:02 --> Model Class Initialized
INFO - 2018-03-26 11:14:02 --> Final output sent to browser
DEBUG - 2018-03-26 11:14:02 --> Total execution time: 2.7829
INFO - 2018-03-26 05:44:02 --> Config Class Initialized
INFO - 2018-03-26 05:44:02 --> Hooks Class Initialized
DEBUG - 2018-03-26 05:44:02 --> UTF-8 Support Enabled
INFO - 2018-03-26 05:44:02 --> Utf8 Class Initialized
INFO - 2018-03-26 05:44:02 --> URI Class Initialized
INFO - 2018-03-26 05:44:03 --> Router Class Initialized
INFO - 2018-03-26 05:44:03 --> Output Class Initialized
INFO - 2018-03-26 05:44:03 --> Security Class Initialized
DEBUG - 2018-03-26 05:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 05:44:03 --> Input Class Initialized
INFO - 2018-03-26 05:44:04 --> Language Class Initialized
INFO - 2018-03-26 05:44:05 --> Language Class Initialized
INFO - 2018-03-26 05:44:05 --> Config Class Initialized
INFO - 2018-03-26 05:44:05 --> Loader Class Initialized
INFO - 2018-03-26 11:14:05 --> Helper loaded: url_helper
INFO - 2018-03-26 11:14:05 --> Helper loaded: notification_helper
INFO - 2018-03-26 11:14:05 --> Helper loaded: settings_helper
INFO - 2018-03-26 11:14:05 --> Helper loaded: permission_helper
INFO - 2018-03-26 11:14:05 --> Helper loaded: users_helper
INFO - 2018-03-26 11:14:06 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:14:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:14:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:14:07 --> Helper loaded: form_helper
INFO - 2018-03-26 11:14:07 --> Form Validation Class Initialized
INFO - 2018-03-26 11:14:07 --> Controller Class Initialized
INFO - 2018-03-26 11:14:07 --> Model Class Initialized
INFO - 2018-03-26 11:14:07 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 11:14:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 11:14:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 11:14:07 --> Model Class Initialized
INFO - 2018-03-26 11:14:07 --> Model Class Initialized
INFO - 2018-03-26 11:14:08 --> Model Class Initialized
INFO - 2018-03-26 11:14:08 --> Model Class Initialized
INFO - 2018-03-26 11:14:08 --> Model Class Initialized
INFO - 2018-03-26 11:14:08 --> Model Class Initialized
INFO - 2018-03-26 11:14:08 --> Model Class Initialized
INFO - 2018-03-26 11:14:08 --> Model Class Initialized
INFO - 2018-03-26 11:14:08 --> Model Class Initialized
INFO - 2018-03-26 11:14:08 --> Model Class Initialized
INFO - 2018-03-26 05:44:08 --> Config Class Initialized
INFO - 2018-03-26 05:44:08 --> Hooks Class Initialized
DEBUG - 2018-03-26 05:44:08 --> UTF-8 Support Enabled
INFO - 2018-03-26 05:44:08 --> Utf8 Class Initialized
INFO - 2018-03-26 05:44:08 --> URI Class Initialized
INFO - 2018-03-26 05:44:08 --> Router Class Initialized
INFO - 2018-03-26 05:44:08 --> Output Class Initialized
INFO - 2018-03-26 05:44:08 --> Security Class Initialized
DEBUG - 2018-03-26 05:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 05:44:08 --> Input Class Initialized
INFO - 2018-03-26 05:44:08 --> Language Class Initialized
INFO - 2018-03-26 11:14:08 --> Model Class Initialized
INFO - 2018-03-26 05:44:08 --> Language Class Initialized
INFO - 2018-03-26 05:44:08 --> Config Class Initialized
INFO - 2018-03-26 05:44:08 --> Loader Class Initialized
INFO - 2018-03-26 11:14:08 --> Helper loaded: url_helper
INFO - 2018-03-26 11:14:08 --> Helper loaded: notification_helper
INFO - 2018-03-26 11:14:08 --> Helper loaded: settings_helper
INFO - 2018-03-26 11:14:08 --> Helper loaded: permission_helper
INFO - 2018-03-26 11:14:08 --> Helper loaded: users_helper
INFO - 2018-03-26 11:14:08 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 11:14:08 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:14:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:14:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:14:08 --> Helper loaded: form_helper
INFO - 2018-03-26 11:14:08 --> Form Validation Class Initialized
INFO - 2018-03-26 11:14:08 --> Controller Class Initialized
INFO - 2018-03-26 11:14:08 --> Model Class Initialized
INFO - 2018-03-26 11:14:08 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 11:14:08 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 11:14:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 11:14:08 --> Model Class Initialized
INFO - 2018-03-26 11:14:08 --> Model Class Initialized
INFO - 2018-03-26 11:14:08 --> Model Class Initialized
INFO - 2018-03-26 11:14:08 --> Model Class Initialized
INFO - 2018-03-26 11:14:08 --> Model Class Initialized
INFO - 2018-03-26 11:14:08 --> Model Class Initialized
INFO - 2018-03-26 11:14:08 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-26 11:14:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-03-26 11:14:08 --> Final output sent to browser
DEBUG - 2018-03-26 11:14:08 --> Total execution time: 0.1732
INFO - 2018-03-26 11:14:08 --> Final output sent to browser
DEBUG - 2018-03-26 11:14:08 --> Total execution time: 6.4098
INFO - 2018-03-26 05:44:08 --> Config Class Initialized
INFO - 2018-03-26 05:44:08 --> Hooks Class Initialized
DEBUG - 2018-03-26 05:44:08 --> UTF-8 Support Enabled
INFO - 2018-03-26 05:44:08 --> Utf8 Class Initialized
INFO - 2018-03-26 05:44:09 --> URI Class Initialized
INFO - 2018-03-26 05:44:09 --> Router Class Initialized
INFO - 2018-03-26 05:44:09 --> Output Class Initialized
INFO - 2018-03-26 05:44:09 --> Security Class Initialized
DEBUG - 2018-03-26 05:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 05:44:09 --> Input Class Initialized
INFO - 2018-03-26 05:44:09 --> Language Class Initialized
INFO - 2018-03-26 05:44:09 --> Config Class Initialized
INFO - 2018-03-26 05:44:09 --> Hooks Class Initialized
DEBUG - 2018-03-26 05:44:09 --> UTF-8 Support Enabled
INFO - 2018-03-26 05:44:09 --> Utf8 Class Initialized
INFO - 2018-03-26 05:44:09 --> URI Class Initialized
INFO - 2018-03-26 05:44:09 --> Router Class Initialized
INFO - 2018-03-26 05:44:09 --> Config Class Initialized
INFO - 2018-03-26 05:44:09 --> Hooks Class Initialized
DEBUG - 2018-03-26 05:44:09 --> UTF-8 Support Enabled
INFO - 2018-03-26 05:44:09 --> Utf8 Class Initialized
INFO - 2018-03-26 05:44:09 --> URI Class Initialized
INFO - 2018-03-26 05:44:09 --> Router Class Initialized
INFO - 2018-03-26 05:44:09 --> Output Class Initialized
INFO - 2018-03-26 05:44:09 --> Security Class Initialized
DEBUG - 2018-03-26 05:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 05:44:09 --> Input Class Initialized
INFO - 2018-03-26 05:44:09 --> Language Class Initialized
INFO - 2018-03-26 05:44:09 --> Language Class Initialized
INFO - 2018-03-26 05:44:09 --> Config Class Initialized
INFO - 2018-03-26 05:44:09 --> Loader Class Initialized
INFO - 2018-03-26 11:14:09 --> Helper loaded: url_helper
INFO - 2018-03-26 11:14:09 --> Helper loaded: notification_helper
INFO - 2018-03-26 11:14:09 --> Helper loaded: settings_helper
INFO - 2018-03-26 11:14:09 --> Helper loaded: permission_helper
INFO - 2018-03-26 11:14:09 --> Helper loaded: users_helper
INFO - 2018-03-26 05:44:09 --> Output Class Initialized
INFO - 2018-03-26 05:44:10 --> Security Class Initialized
INFO - 2018-03-26 05:44:10 --> Language Class Initialized
INFO - 2018-03-26 05:44:10 --> Config Class Initialized
INFO - 2018-03-26 05:44:10 --> Loader Class Initialized
INFO - 2018-03-26 11:14:10 --> Helper loaded: url_helper
INFO - 2018-03-26 11:14:10 --> Helper loaded: notification_helper
INFO - 2018-03-26 11:14:10 --> Helper loaded: settings_helper
INFO - 2018-03-26 11:14:10 --> Helper loaded: permission_helper
INFO - 2018-03-26 11:14:10 --> Helper loaded: users_helper
INFO - 2018-03-26 11:14:10 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:14:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:14:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:14:10 --> Helper loaded: form_helper
INFO - 2018-03-26 11:14:10 --> Form Validation Class Initialized
INFO - 2018-03-26 11:14:10 --> Controller Class Initialized
INFO - 2018-03-26 11:14:10 --> Database Driver Class Initialized
INFO - 2018-03-26 11:14:10 --> Model Class Initialized
INFO - 2018-03-26 11:14:10 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 11:14:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 11:14:10 --> Language file loaded: language/english/rest_controller_lang.php
DEBUG - 2018-03-26 11:14:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:14:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:14:10 --> Model Class Initialized
INFO - 2018-03-26 11:14:10 --> Helper loaded: form_helper
INFO - 2018-03-26 11:14:10 --> Form Validation Class Initialized
INFO - 2018-03-26 11:14:10 --> Controller Class Initialized
INFO - 2018-03-26 11:14:10 --> Model Class Initialized
INFO - 2018-03-26 11:14:10 --> Model Class Initialized
INFO - 2018-03-26 11:14:10 --> Model Class Initialized
INFO - 2018-03-26 11:14:10 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 11:14:10 --> Model Class Initialized
INFO - 2018-03-26 11:14:10 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 05:44:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-26 11:14:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 05:44:10 --> Input Class Initialized
INFO - 2018-03-26 11:14:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 11:14:10 --> Model Class Initialized
INFO - 2018-03-26 11:14:10 --> Model Class Initialized
INFO - 2018-03-26 11:14:10 --> Final output sent to browser
DEBUG - 2018-03-26 11:14:10 --> Total execution time: 0.3062
INFO - 2018-03-26 11:14:10 --> Model Class Initialized
INFO - 2018-03-26 11:14:10 --> Model Class Initialized
INFO - 2018-03-26 11:14:10 --> Model Class Initialized
INFO - 2018-03-26 11:14:10 --> Model Class Initialized
INFO - 2018-03-26 11:14:10 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-26 11:14:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-03-26 11:14:10 --> Final output sent to browser
DEBUG - 2018-03-26 11:14:10 --> Total execution time: 1.6600
INFO - 2018-03-26 05:44:10 --> Language Class Initialized
INFO - 2018-03-26 05:44:10 --> Config Class Initialized
INFO - 2018-03-26 05:44:10 --> Hooks Class Initialized
DEBUG - 2018-03-26 05:44:10 --> UTF-8 Support Enabled
INFO - 2018-03-26 05:44:10 --> Utf8 Class Initialized
INFO - 2018-03-26 05:44:10 --> URI Class Initialized
INFO - 2018-03-26 05:44:10 --> Router Class Initialized
INFO - 2018-03-26 05:44:10 --> Output Class Initialized
INFO - 2018-03-26 05:44:10 --> Security Class Initialized
DEBUG - 2018-03-26 05:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 05:44:10 --> Input Class Initialized
INFO - 2018-03-26 05:44:10 --> Language Class Initialized
INFO - 2018-03-26 05:44:10 --> Language Class Initialized
INFO - 2018-03-26 05:44:10 --> Config Class Initialized
INFO - 2018-03-26 05:44:10 --> Loader Class Initialized
INFO - 2018-03-26 11:14:10 --> Helper loaded: url_helper
INFO - 2018-03-26 11:14:10 --> Helper loaded: notification_helper
INFO - 2018-03-26 11:14:10 --> Helper loaded: settings_helper
INFO - 2018-03-26 11:14:10 --> Helper loaded: permission_helper
INFO - 2018-03-26 11:14:10 --> Helper loaded: users_helper
INFO - 2018-03-26 11:14:10 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:14:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:14:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:14:10 --> Helper loaded: form_helper
INFO - 2018-03-26 11:14:10 --> Form Validation Class Initialized
INFO - 2018-03-26 11:14:10 --> Controller Class Initialized
INFO - 2018-03-26 11:14:10 --> Model Class Initialized
INFO - 2018-03-26 11:14:10 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 11:14:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 11:14:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 11:14:10 --> Model Class Initialized
INFO - 2018-03-26 11:14:10 --> Model Class Initialized
INFO - 2018-03-26 11:14:10 --> Model Class Initialized
INFO - 2018-03-26 11:14:10 --> Model Class Initialized
INFO - 2018-03-26 11:14:10 --> Model Class Initialized
INFO - 2018-03-26 11:14:10 --> Model Class Initialized
INFO - 2018-03-26 11:14:10 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-26 11:14:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-03-26 11:14:10 --> Final output sent to browser
DEBUG - 2018-03-26 11:14:10 --> Total execution time: 0.1308
INFO - 2018-03-26 05:44:11 --> Language Class Initialized
INFO - 2018-03-26 05:44:11 --> Config Class Initialized
INFO - 2018-03-26 05:44:11 --> Loader Class Initialized
INFO - 2018-03-26 11:14:11 --> Helper loaded: url_helper
INFO - 2018-03-26 11:14:11 --> Helper loaded: notification_helper
INFO - 2018-03-26 11:14:11 --> Helper loaded: settings_helper
INFO - 2018-03-26 11:14:11 --> Helper loaded: permission_helper
INFO - 2018-03-26 11:14:11 --> Helper loaded: users_helper
INFO - 2018-03-26 11:14:11 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:14:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:14:12 --> Helper loaded: form_helper
INFO - 2018-03-26 11:14:12 --> Form Validation Class Initialized
INFO - 2018-03-26 11:14:12 --> Controller Class Initialized
INFO - 2018-03-26 11:14:12 --> Model Class Initialized
INFO - 2018-03-26 11:14:12 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 11:14:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 11:14:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 11:14:12 --> Model Class Initialized
INFO - 2018-03-26 11:14:12 --> Model Class Initialized
INFO - 2018-03-26 11:14:12 --> Model Class Initialized
INFO - 2018-03-26 11:14:12 --> Model Class Initialized
INFO - 2018-03-26 11:14:12 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 11:14:12 --> Final output sent to browser
DEBUG - 2018-03-26 11:14:12 --> Total execution time: 3.8064
INFO - 2018-03-26 08:26:27 --> Config Class Initialized
INFO - 2018-03-26 08:26:27 --> Hooks Class Initialized
DEBUG - 2018-03-26 08:26:27 --> UTF-8 Support Enabled
INFO - 2018-03-26 08:26:27 --> Utf8 Class Initialized
INFO - 2018-03-26 08:26:27 --> URI Class Initialized
INFO - 2018-03-26 08:26:27 --> Router Class Initialized
INFO - 2018-03-26 08:26:27 --> Output Class Initialized
INFO - 2018-03-26 08:26:27 --> Security Class Initialized
DEBUG - 2018-03-26 08:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 08:26:27 --> Input Class Initialized
INFO - 2018-03-26 08:26:27 --> Language Class Initialized
INFO - 2018-03-26 08:26:27 --> Language Class Initialized
INFO - 2018-03-26 08:26:27 --> Config Class Initialized
INFO - 2018-03-26 08:26:27 --> Loader Class Initialized
INFO - 2018-03-26 13:56:27 --> Helper loaded: url_helper
INFO - 2018-03-26 13:56:27 --> Helper loaded: notification_helper
INFO - 2018-03-26 13:56:27 --> Helper loaded: settings_helper
INFO - 2018-03-26 13:56:27 --> Helper loaded: permission_helper
INFO - 2018-03-26 13:56:27 --> Helper loaded: users_helper
INFO - 2018-03-26 13:56:27 --> Database Driver Class Initialized
DEBUG - 2018-03-26 13:56:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 13:56:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 13:56:27 --> Helper loaded: form_helper
INFO - 2018-03-26 13:56:27 --> Form Validation Class Initialized
INFO - 2018-03-26 13:56:27 --> Controller Class Initialized
INFO - 2018-03-26 13:56:27 --> Model Class Initialized
INFO - 2018-03-26 13:56:27 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 13:56:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 13:56:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 13:56:27 --> Model Class Initialized
INFO - 2018-03-26 13:56:27 --> Model Class Initialized
INFO - 2018-03-26 13:56:27 --> Model Class Initialized
INFO - 2018-03-26 13:56:27 --> Model Class Initialized
INFO - 2018-03-26 13:56:27 --> Model Class Initialized
INFO - 2018-03-26 13:56:27 --> Model Class Initialized
INFO - 2018-03-26 13:56:27 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 13:56:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-26 13:56:27 --> Final output sent to browser
DEBUG - 2018-03-26 13:56:27 --> Total execution time: 0.3875
INFO - 2018-03-26 08:29:12 --> Config Class Initialized
INFO - 2018-03-26 08:29:12 --> Hooks Class Initialized
DEBUG - 2018-03-26 08:29:12 --> UTF-8 Support Enabled
INFO - 2018-03-26 08:29:12 --> Utf8 Class Initialized
INFO - 2018-03-26 08:29:12 --> URI Class Initialized
INFO - 2018-03-26 08:29:12 --> Router Class Initialized
INFO - 2018-03-26 08:29:12 --> Output Class Initialized
INFO - 2018-03-26 08:29:12 --> Security Class Initialized
DEBUG - 2018-03-26 08:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 08:29:12 --> Input Class Initialized
INFO - 2018-03-26 08:29:12 --> Language Class Initialized
INFO - 2018-03-26 08:29:12 --> Language Class Initialized
INFO - 2018-03-26 08:29:12 --> Config Class Initialized
INFO - 2018-03-26 08:29:12 --> Loader Class Initialized
INFO - 2018-03-26 13:59:12 --> Helper loaded: url_helper
INFO - 2018-03-26 13:59:12 --> Helper loaded: notification_helper
INFO - 2018-03-26 13:59:12 --> Helper loaded: settings_helper
INFO - 2018-03-26 13:59:12 --> Helper loaded: permission_helper
INFO - 2018-03-26 13:59:12 --> Helper loaded: users_helper
INFO - 2018-03-26 13:59:12 --> Database Driver Class Initialized
DEBUG - 2018-03-26 13:59:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 13:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 13:59:12 --> Helper loaded: form_helper
INFO - 2018-03-26 13:59:12 --> Form Validation Class Initialized
INFO - 2018-03-26 13:59:12 --> Controller Class Initialized
INFO - 2018-03-26 13:59:12 --> Model Class Initialized
INFO - 2018-03-26 13:59:12 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 13:59:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 13:59:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 13:59:12 --> Model Class Initialized
INFO - 2018-03-26 13:59:12 --> Model Class Initialized
INFO - 2018-03-26 13:59:12 --> Model Class Initialized
INFO - 2018-03-26 13:59:12 --> Model Class Initialized
INFO - 2018-03-26 13:59:12 --> Model Class Initialized
INFO - 2018-03-26 13:59:12 --> Model Class Initialized
INFO - 2018-03-26 13:59:12 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 13:59:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-26 13:59:12 --> Final output sent to browser
DEBUG - 2018-03-26 13:59:12 --> Total execution time: 0.2697
INFO - 2018-03-26 08:29:14 --> Config Class Initialized
INFO - 2018-03-26 08:29:14 --> Hooks Class Initialized
DEBUG - 2018-03-26 08:29:14 --> UTF-8 Support Enabled
INFO - 2018-03-26 08:29:14 --> Utf8 Class Initialized
INFO - 2018-03-26 08:29:15 --> URI Class Initialized
INFO - 2018-03-26 08:29:15 --> Router Class Initialized
INFO - 2018-03-26 08:29:15 --> Output Class Initialized
INFO - 2018-03-26 08:29:15 --> Security Class Initialized
DEBUG - 2018-03-26 08:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 08:29:15 --> Input Class Initialized
INFO - 2018-03-26 08:29:15 --> Language Class Initialized
INFO - 2018-03-26 08:29:16 --> Config Class Initialized
INFO - 2018-03-26 08:29:16 --> Hooks Class Initialized
DEBUG - 2018-03-26 08:29:16 --> UTF-8 Support Enabled
INFO - 2018-03-26 08:29:16 --> Utf8 Class Initialized
INFO - 2018-03-26 08:29:16 --> URI Class Initialized
INFO - 2018-03-26 08:29:16 --> Router Class Initialized
INFO - 2018-03-26 08:29:16 --> Output Class Initialized
INFO - 2018-03-26 08:29:16 --> Security Class Initialized
DEBUG - 2018-03-26 08:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 08:29:16 --> Input Class Initialized
INFO - 2018-03-26 08:29:16 --> Language Class Initialized
INFO - 2018-03-26 08:29:16 --> Language Class Initialized
INFO - 2018-03-26 08:29:16 --> Config Class Initialized
INFO - 2018-03-26 08:29:16 --> Loader Class Initialized
INFO - 2018-03-26 13:59:16 --> Helper loaded: url_helper
INFO - 2018-03-26 13:59:16 --> Helper loaded: notification_helper
INFO - 2018-03-26 13:59:16 --> Helper loaded: settings_helper
INFO - 2018-03-26 13:59:16 --> Helper loaded: permission_helper
INFO - 2018-03-26 13:59:16 --> Helper loaded: users_helper
INFO - 2018-03-26 08:29:16 --> Language Class Initialized
INFO - 2018-03-26 08:29:16 --> Config Class Initialized
INFO - 2018-03-26 08:29:16 --> Loader Class Initialized
INFO - 2018-03-26 13:59:16 --> Helper loaded: url_helper
INFO - 2018-03-26 13:59:16 --> Database Driver Class Initialized
INFO - 2018-03-26 13:59:16 --> Helper loaded: notification_helper
INFO - 2018-03-26 13:59:16 --> Helper loaded: settings_helper
DEBUG - 2018-03-26 13:59:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 13:59:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 13:59:16 --> Helper loaded: permission_helper
INFO - 2018-03-26 13:59:16 --> Helper loaded: form_helper
INFO - 2018-03-26 13:59:16 --> Form Validation Class Initialized
INFO - 2018-03-26 13:59:16 --> Controller Class Initialized
INFO - 2018-03-26 13:59:16 --> Helper loaded: users_helper
INFO - 2018-03-26 13:59:16 --> Model Class Initialized
INFO - 2018-03-26 13:59:16 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 13:59:17 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 13:59:17 --> Database Driver Class Initialized
INFO - 2018-03-26 13:59:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 13:59:17 --> Model Class Initialized
INFO - 2018-03-26 13:59:17 --> Model Class Initialized
INFO - 2018-03-26 13:59:17 --> Model Class Initialized
INFO - 2018-03-26 13:59:17 --> Model Class Initialized
DEBUG - 2018-03-26 13:59:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 13:59:17 --> Model Class Initialized
INFO - 2018-03-26 13:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 13:59:17 --> Model Class Initialized
INFO - 2018-03-26 13:59:17 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-26 13:59:17 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
ERROR - 2018-03-26 13:59:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 784
INFO - 2018-03-26 13:59:17 --> Final output sent to browser
DEBUG - 2018-03-26 13:59:17 --> Total execution time: 1.5309
INFO - 2018-03-26 13:59:17 --> Helper loaded: form_helper
INFO - 2018-03-26 13:59:17 --> Form Validation Class Initialized
INFO - 2018-03-26 13:59:17 --> Controller Class Initialized
INFO - 2018-03-26 13:59:18 --> Model Class Initialized
INFO - 2018-03-26 13:59:18 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 13:59:18 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 13:59:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 13:59:18 --> Model Class Initialized
INFO - 2018-03-26 13:59:18 --> Model Class Initialized
INFO - 2018-03-26 13:59:18 --> Model Class Initialized
INFO - 2018-03-26 13:59:18 --> Model Class Initialized
INFO - 2018-03-26 13:59:18 --> Model Class Initialized
INFO - 2018-03-26 13:59:18 --> Model Class Initialized
INFO - 2018-03-26 13:59:18 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-26 13:59:18 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
ERROR - 2018-03-26 13:59:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 784
INFO - 2018-03-26 13:59:18 --> Final output sent to browser
DEBUG - 2018-03-26 13:59:18 --> Total execution time: 4.0812
INFO - 2018-03-26 08:29:28 --> Config Class Initialized
INFO - 2018-03-26 08:29:28 --> Hooks Class Initialized
DEBUG - 2018-03-26 08:29:28 --> UTF-8 Support Enabled
INFO - 2018-03-26 08:29:28 --> Utf8 Class Initialized
INFO - 2018-03-26 08:29:28 --> URI Class Initialized
INFO - 2018-03-26 08:29:28 --> Router Class Initialized
INFO - 2018-03-26 08:29:28 --> Output Class Initialized
INFO - 2018-03-26 08:29:28 --> Security Class Initialized
DEBUG - 2018-03-26 08:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 08:29:28 --> Input Class Initialized
INFO - 2018-03-26 08:29:28 --> Language Class Initialized
INFO - 2018-03-26 08:29:28 --> Language Class Initialized
INFO - 2018-03-26 08:29:28 --> Config Class Initialized
INFO - 2018-03-26 08:29:28 --> Loader Class Initialized
INFO - 2018-03-26 13:59:28 --> Helper loaded: url_helper
INFO - 2018-03-26 13:59:28 --> Helper loaded: notification_helper
INFO - 2018-03-26 13:59:28 --> Helper loaded: settings_helper
INFO - 2018-03-26 13:59:28 --> Helper loaded: permission_helper
INFO - 2018-03-26 13:59:28 --> Helper loaded: users_helper
INFO - 2018-03-26 13:59:28 --> Database Driver Class Initialized
DEBUG - 2018-03-26 13:59:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 13:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 13:59:29 --> Helper loaded: form_helper
INFO - 2018-03-26 13:59:29 --> Form Validation Class Initialized
INFO - 2018-03-26 13:59:29 --> Controller Class Initialized
INFO - 2018-03-26 13:59:29 --> Model Class Initialized
INFO - 2018-03-26 13:59:29 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 13:59:30 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 13:59:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 13:59:30 --> Model Class Initialized
INFO - 2018-03-26 13:59:30 --> Model Class Initialized
INFO - 2018-03-26 13:59:30 --> Model Class Initialized
INFO - 2018-03-26 13:59:30 --> Model Class Initialized
INFO - 2018-03-26 13:59:30 --> Model Class Initialized
INFO - 2018-03-26 13:59:30 --> Model Class Initialized
INFO - 2018-03-26 13:59:30 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 13:59:30 --> Model Class Initialized
INFO - 2018-03-26 13:59:30 --> Model Class Initialized
INFO - 2018-03-26 13:59:30 --> Final output sent to browser
DEBUG - 2018-03-26 13:59:30 --> Total execution time: 2.1999
INFO - 2018-03-26 08:29:31 --> Config Class Initialized
INFO - 2018-03-26 08:29:31 --> Hooks Class Initialized
DEBUG - 2018-03-26 08:29:31 --> UTF-8 Support Enabled
INFO - 2018-03-26 08:29:31 --> Utf8 Class Initialized
INFO - 2018-03-26 08:29:31 --> URI Class Initialized
INFO - 2018-03-26 08:29:31 --> Router Class Initialized
INFO - 2018-03-26 08:29:31 --> Output Class Initialized
INFO - 2018-03-26 08:29:31 --> Security Class Initialized
DEBUG - 2018-03-26 08:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 08:29:31 --> Input Class Initialized
INFO - 2018-03-26 08:29:31 --> Language Class Initialized
INFO - 2018-03-26 08:29:31 --> Language Class Initialized
INFO - 2018-03-26 08:29:31 --> Config Class Initialized
INFO - 2018-03-26 08:29:31 --> Loader Class Initialized
INFO - 2018-03-26 13:59:31 --> Helper loaded: url_helper
INFO - 2018-03-26 13:59:31 --> Helper loaded: notification_helper
INFO - 2018-03-26 13:59:31 --> Helper loaded: settings_helper
INFO - 2018-03-26 13:59:31 --> Helper loaded: permission_helper
INFO - 2018-03-26 13:59:31 --> Helper loaded: users_helper
INFO - 2018-03-26 13:59:31 --> Database Driver Class Initialized
DEBUG - 2018-03-26 13:59:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 13:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 13:59:31 --> Helper loaded: form_helper
INFO - 2018-03-26 13:59:31 --> Form Validation Class Initialized
INFO - 2018-03-26 13:59:31 --> Controller Class Initialized
INFO - 2018-03-26 13:59:31 --> Model Class Initialized
INFO - 2018-03-26 13:59:31 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 13:59:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 13:59:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 13:59:31 --> Model Class Initialized
INFO - 2018-03-26 13:59:31 --> Model Class Initialized
INFO - 2018-03-26 13:59:31 --> Model Class Initialized
INFO - 2018-03-26 13:59:31 --> Model Class Initialized
INFO - 2018-03-26 13:59:31 --> Model Class Initialized
INFO - 2018-03-26 13:59:31 --> Model Class Initialized
INFO - 2018-03-26 13:59:31 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 13:59:31 --> Model Class Initialized
INFO - 2018-03-26 13:59:31 --> Model Class Initialized
INFO - 2018-03-26 13:59:31 --> Final output sent to browser
DEBUG - 2018-03-26 13:59:31 --> Total execution time: 0.4219
INFO - 2018-03-26 08:29:41 --> Config Class Initialized
INFO - 2018-03-26 08:29:41 --> Hooks Class Initialized
DEBUG - 2018-03-26 08:29:41 --> UTF-8 Support Enabled
INFO - 2018-03-26 08:29:41 --> Utf8 Class Initialized
INFO - 2018-03-26 08:29:41 --> URI Class Initialized
INFO - 2018-03-26 08:29:41 --> Router Class Initialized
INFO - 2018-03-26 08:29:41 --> Output Class Initialized
INFO - 2018-03-26 08:29:41 --> Security Class Initialized
DEBUG - 2018-03-26 08:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 08:29:41 --> Input Class Initialized
INFO - 2018-03-26 08:29:41 --> Language Class Initialized
INFO - 2018-03-26 08:29:41 --> Language Class Initialized
INFO - 2018-03-26 08:29:41 --> Config Class Initialized
INFO - 2018-03-26 08:29:41 --> Loader Class Initialized
INFO - 2018-03-26 13:59:41 --> Helper loaded: url_helper
INFO - 2018-03-26 13:59:41 --> Helper loaded: notification_helper
INFO - 2018-03-26 13:59:41 --> Helper loaded: settings_helper
INFO - 2018-03-26 13:59:41 --> Helper loaded: permission_helper
INFO - 2018-03-26 13:59:41 --> Helper loaded: users_helper
INFO - 2018-03-26 13:59:41 --> Database Driver Class Initialized
DEBUG - 2018-03-26 13:59:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 13:59:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 13:59:41 --> Helper loaded: form_helper
INFO - 2018-03-26 13:59:41 --> Form Validation Class Initialized
INFO - 2018-03-26 13:59:41 --> Controller Class Initialized
INFO - 2018-03-26 13:59:41 --> Model Class Initialized
INFO - 2018-03-26 13:59:41 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 13:59:41 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 13:59:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 13:59:41 --> Model Class Initialized
INFO - 2018-03-26 13:59:41 --> Model Class Initialized
INFO - 2018-03-26 13:59:41 --> Model Class Initialized
INFO - 2018-03-26 13:59:41 --> Model Class Initialized
INFO - 2018-03-26 13:59:41 --> Model Class Initialized
INFO - 2018-03-26 13:59:41 --> Model Class Initialized
INFO - 2018-03-26 13:59:41 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 13:59:41 --> Model Class Initialized
INFO - 2018-03-26 13:59:41 --> Model Class Initialized
INFO - 2018-03-26 13:59:41 --> Final output sent to browser
DEBUG - 2018-03-26 13:59:41 --> Total execution time: 0.4704
INFO - 2018-03-26 08:29:42 --> Config Class Initialized
INFO - 2018-03-26 08:29:42 --> Hooks Class Initialized
DEBUG - 2018-03-26 08:29:42 --> UTF-8 Support Enabled
INFO - 2018-03-26 08:29:42 --> Utf8 Class Initialized
INFO - 2018-03-26 08:29:42 --> URI Class Initialized
INFO - 2018-03-26 08:29:42 --> Router Class Initialized
INFO - 2018-03-26 08:29:43 --> Output Class Initialized
INFO - 2018-03-26 08:29:43 --> Security Class Initialized
DEBUG - 2018-03-26 08:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 08:29:43 --> Input Class Initialized
INFO - 2018-03-26 08:29:43 --> Language Class Initialized
INFO - 2018-03-26 08:29:43 --> Language Class Initialized
INFO - 2018-03-26 08:29:43 --> Config Class Initialized
INFO - 2018-03-26 08:29:43 --> Loader Class Initialized
INFO - 2018-03-26 13:59:43 --> Helper loaded: url_helper
INFO - 2018-03-26 13:59:43 --> Helper loaded: notification_helper
INFO - 2018-03-26 13:59:43 --> Helper loaded: settings_helper
INFO - 2018-03-26 13:59:43 --> Helper loaded: permission_helper
INFO - 2018-03-26 13:59:43 --> Helper loaded: users_helper
INFO - 2018-03-26 13:59:43 --> Database Driver Class Initialized
DEBUG - 2018-03-26 13:59:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 13:59:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 13:59:43 --> Helper loaded: form_helper
INFO - 2018-03-26 13:59:43 --> Form Validation Class Initialized
INFO - 2018-03-26 13:59:43 --> Controller Class Initialized
INFO - 2018-03-26 13:59:43 --> Model Class Initialized
INFO - 2018-03-26 13:59:43 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 13:59:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 13:59:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 13:59:43 --> Model Class Initialized
INFO - 2018-03-26 13:59:43 --> Model Class Initialized
INFO - 2018-03-26 13:59:43 --> Model Class Initialized
INFO - 2018-03-26 13:59:43 --> Model Class Initialized
INFO - 2018-03-26 13:59:43 --> Model Class Initialized
INFO - 2018-03-26 13:59:43 --> Model Class Initialized
INFO - 2018-03-26 13:59:43 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 13:59:43 --> Model Class Initialized
INFO - 2018-03-26 13:59:43 --> Model Class Initialized
INFO - 2018-03-26 13:59:43 --> Final output sent to browser
DEBUG - 2018-03-26 13:59:43 --> Total execution time: 1.4188
INFO - 2018-03-26 08:29:45 --> Config Class Initialized
INFO - 2018-03-26 08:29:45 --> Hooks Class Initialized
DEBUG - 2018-03-26 08:29:45 --> UTF-8 Support Enabled
INFO - 2018-03-26 08:29:45 --> Utf8 Class Initialized
INFO - 2018-03-26 08:29:45 --> URI Class Initialized
INFO - 2018-03-26 08:29:45 --> Router Class Initialized
INFO - 2018-03-26 08:29:45 --> Output Class Initialized
INFO - 2018-03-26 08:29:46 --> Security Class Initialized
DEBUG - 2018-03-26 08:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 08:29:46 --> Input Class Initialized
INFO - 2018-03-26 08:29:46 --> Language Class Initialized
INFO - 2018-03-26 08:29:47 --> Language Class Initialized
INFO - 2018-03-26 08:29:47 --> Config Class Initialized
INFO - 2018-03-26 08:29:47 --> Loader Class Initialized
INFO - 2018-03-26 13:59:47 --> Helper loaded: url_helper
INFO - 2018-03-26 13:59:47 --> Helper loaded: notification_helper
INFO - 2018-03-26 13:59:47 --> Helper loaded: settings_helper
INFO - 2018-03-26 13:59:47 --> Helper loaded: permission_helper
INFO - 2018-03-26 13:59:47 --> Helper loaded: users_helper
INFO - 2018-03-26 13:59:48 --> Database Driver Class Initialized
DEBUG - 2018-03-26 13:59:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 13:59:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 13:59:48 --> Helper loaded: form_helper
INFO - 2018-03-26 13:59:48 --> Form Validation Class Initialized
INFO - 2018-03-26 13:59:48 --> Controller Class Initialized
INFO - 2018-03-26 13:59:48 --> Model Class Initialized
INFO - 2018-03-26 13:59:48 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 13:59:48 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 13:59:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 13:59:48 --> Model Class Initialized
INFO - 2018-03-26 13:59:48 --> Model Class Initialized
INFO - 2018-03-26 13:59:48 --> Model Class Initialized
INFO - 2018-03-26 13:59:48 --> Model Class Initialized
INFO - 2018-03-26 13:59:48 --> Model Class Initialized
INFO - 2018-03-26 13:59:48 --> Model Class Initialized
INFO - 2018-03-26 13:59:48 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 13:59:48 --> Model Class Initialized
INFO - 2018-03-26 13:59:48 --> Model Class Initialized
INFO - 2018-03-26 13:59:48 --> Final output sent to browser
DEBUG - 2018-03-26 13:59:48 --> Total execution time: 2.7743
INFO - 2018-03-26 08:34:17 --> Config Class Initialized
INFO - 2018-03-26 08:34:17 --> Hooks Class Initialized
DEBUG - 2018-03-26 08:34:17 --> UTF-8 Support Enabled
INFO - 2018-03-26 08:34:17 --> Utf8 Class Initialized
INFO - 2018-03-26 08:34:17 --> URI Class Initialized
INFO - 2018-03-26 08:34:17 --> Router Class Initialized
INFO - 2018-03-26 08:34:17 --> Output Class Initialized
INFO - 2018-03-26 08:34:18 --> Security Class Initialized
DEBUG - 2018-03-26 08:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 08:34:18 --> Input Class Initialized
INFO - 2018-03-26 08:34:18 --> Language Class Initialized
INFO - 2018-03-26 08:34:18 --> Language Class Initialized
INFO - 2018-03-26 08:34:18 --> Config Class Initialized
INFO - 2018-03-26 08:34:18 --> Loader Class Initialized
INFO - 2018-03-26 14:04:19 --> Helper loaded: url_helper
INFO - 2018-03-26 14:04:19 --> Helper loaded: notification_helper
INFO - 2018-03-26 14:04:19 --> Helper loaded: settings_helper
INFO - 2018-03-26 14:04:19 --> Helper loaded: permission_helper
INFO - 2018-03-26 14:04:19 --> Helper loaded: users_helper
INFO - 2018-03-26 14:04:19 --> Database Driver Class Initialized
DEBUG - 2018-03-26 14:04:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 14:04:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 14:04:20 --> Helper loaded: form_helper
INFO - 2018-03-26 14:04:20 --> Form Validation Class Initialized
INFO - 2018-03-26 14:04:20 --> Controller Class Initialized
INFO - 2018-03-26 14:04:20 --> Model Class Initialized
INFO - 2018-03-26 14:04:20 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 14:04:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 14:04:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 14:04:20 --> Model Class Initialized
INFO - 2018-03-26 14:04:20 --> Model Class Initialized
INFO - 2018-03-26 14:04:21 --> Model Class Initialized
INFO - 2018-03-26 14:04:21 --> Model Class Initialized
INFO - 2018-03-26 14:04:21 --> Model Class Initialized
INFO - 2018-03-26 14:04:21 --> Model Class Initialized
INFO - 2018-03-26 14:04:21 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 14:04:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-26 14:04:21 --> Final output sent to browser
DEBUG - 2018-03-26 14:04:21 --> Total execution time: 3.7399
INFO - 2018-03-26 08:34:22 --> Config Class Initialized
INFO - 2018-03-26 08:34:22 --> Hooks Class Initialized
DEBUG - 2018-03-26 08:34:22 --> UTF-8 Support Enabled
INFO - 2018-03-26 08:34:22 --> Utf8 Class Initialized
INFO - 2018-03-26 08:34:22 --> URI Class Initialized
INFO - 2018-03-26 08:34:22 --> Router Class Initialized
INFO - 2018-03-26 08:34:22 --> Output Class Initialized
INFO - 2018-03-26 08:34:22 --> Security Class Initialized
DEBUG - 2018-03-26 08:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 08:34:22 --> Input Class Initialized
INFO - 2018-03-26 08:34:22 --> Language Class Initialized
INFO - 2018-03-26 08:34:23 --> Language Class Initialized
INFO - 2018-03-26 08:34:23 --> Config Class Initialized
INFO - 2018-03-26 08:34:23 --> Loader Class Initialized
INFO - 2018-03-26 14:04:23 --> Helper loaded: url_helper
INFO - 2018-03-26 14:04:23 --> Helper loaded: notification_helper
INFO - 2018-03-26 14:04:23 --> Helper loaded: settings_helper
INFO - 2018-03-26 14:04:23 --> Helper loaded: permission_helper
INFO - 2018-03-26 14:04:23 --> Helper loaded: users_helper
INFO - 2018-03-26 14:04:23 --> Database Driver Class Initialized
DEBUG - 2018-03-26 14:04:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 14:04:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 14:04:23 --> Helper loaded: form_helper
INFO - 2018-03-26 14:04:23 --> Form Validation Class Initialized
INFO - 2018-03-26 14:04:23 --> Controller Class Initialized
INFO - 2018-03-26 14:04:24 --> Model Class Initialized
INFO - 2018-03-26 14:04:24 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 14:04:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 14:04:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 14:04:24 --> Model Class Initialized
INFO - 2018-03-26 14:04:24 --> Model Class Initialized
INFO - 2018-03-26 14:04:24 --> Model Class Initialized
INFO - 2018-03-26 14:04:24 --> Model Class Initialized
INFO - 2018-03-26 14:04:24 --> Model Class Initialized
INFO - 2018-03-26 14:04:24 --> Model Class Initialized
INFO - 2018-03-26 14:04:24 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 14:04:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-26 14:04:24 --> Final output sent to browser
DEBUG - 2018-03-26 14:04:24 --> Total execution time: 1.4894
INFO - 2018-03-26 08:38:11 --> Config Class Initialized
INFO - 2018-03-26 08:38:11 --> Hooks Class Initialized
DEBUG - 2018-03-26 08:38:11 --> UTF-8 Support Enabled
INFO - 2018-03-26 08:38:11 --> Utf8 Class Initialized
INFO - 2018-03-26 08:38:11 --> URI Class Initialized
INFO - 2018-03-26 08:38:11 --> Router Class Initialized
INFO - 2018-03-26 08:38:11 --> Output Class Initialized
INFO - 2018-03-26 08:38:11 --> Security Class Initialized
DEBUG - 2018-03-26 08:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 08:38:11 --> Input Class Initialized
INFO - 2018-03-26 08:38:11 --> Language Class Initialized
INFO - 2018-03-26 08:38:11 --> Language Class Initialized
INFO - 2018-03-26 08:38:11 --> Config Class Initialized
INFO - 2018-03-26 08:38:11 --> Loader Class Initialized
INFO - 2018-03-26 14:08:12 --> Helper loaded: url_helper
INFO - 2018-03-26 14:08:12 --> Helper loaded: notification_helper
INFO - 2018-03-26 14:08:12 --> Helper loaded: settings_helper
INFO - 2018-03-26 14:08:12 --> Helper loaded: permission_helper
INFO - 2018-03-26 14:08:12 --> Helper loaded: users_helper
INFO - 2018-03-26 14:08:12 --> Database Driver Class Initialized
DEBUG - 2018-03-26 14:08:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 14:08:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 14:08:12 --> Helper loaded: form_helper
INFO - 2018-03-26 14:08:12 --> Form Validation Class Initialized
INFO - 2018-03-26 14:08:12 --> Controller Class Initialized
INFO - 2018-03-26 14:08:12 --> Model Class Initialized
INFO - 2018-03-26 14:08:12 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 14:08:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 14:08:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 14:08:12 --> Model Class Initialized
INFO - 2018-03-26 14:08:12 --> Model Class Initialized
INFO - 2018-03-26 14:08:12 --> Model Class Initialized
INFO - 2018-03-26 14:08:12 --> Model Class Initialized
INFO - 2018-03-26 14:08:12 --> Model Class Initialized
INFO - 2018-03-26 14:08:12 --> Model Class Initialized
INFO - 2018-03-26 14:08:12 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 14:08:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-26 14:08:12 --> Final output sent to browser
DEBUG - 2018-03-26 14:08:12 --> Total execution time: 0.4724
INFO - 2018-03-26 08:45:31 --> Config Class Initialized
INFO - 2018-03-26 08:45:31 --> Hooks Class Initialized
DEBUG - 2018-03-26 08:45:31 --> UTF-8 Support Enabled
INFO - 2018-03-26 08:45:31 --> Utf8 Class Initialized
INFO - 2018-03-26 08:45:31 --> URI Class Initialized
INFO - 2018-03-26 08:45:31 --> Router Class Initialized
INFO - 2018-03-26 08:45:31 --> Output Class Initialized
INFO - 2018-03-26 08:45:31 --> Security Class Initialized
DEBUG - 2018-03-26 08:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 08:45:31 --> Input Class Initialized
INFO - 2018-03-26 08:45:31 --> Language Class Initialized
INFO - 2018-03-26 08:45:32 --> Language Class Initialized
INFO - 2018-03-26 08:45:32 --> Config Class Initialized
INFO - 2018-03-26 08:45:32 --> Loader Class Initialized
INFO - 2018-03-26 14:15:32 --> Helper loaded: url_helper
INFO - 2018-03-26 14:15:32 --> Helper loaded: notification_helper
INFO - 2018-03-26 14:15:32 --> Helper loaded: settings_helper
INFO - 2018-03-26 14:15:32 --> Helper loaded: permission_helper
INFO - 2018-03-26 14:15:32 --> Helper loaded: users_helper
INFO - 2018-03-26 14:15:32 --> Database Driver Class Initialized
DEBUG - 2018-03-26 14:15:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 14:15:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 14:15:32 --> Helper loaded: form_helper
INFO - 2018-03-26 14:15:32 --> Form Validation Class Initialized
INFO - 2018-03-26 14:15:32 --> Controller Class Initialized
INFO - 2018-03-26 14:15:32 --> Model Class Initialized
INFO - 2018-03-26 14:15:32 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 14:15:32 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 14:15:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 14:15:32 --> Model Class Initialized
INFO - 2018-03-26 14:15:32 --> Model Class Initialized
INFO - 2018-03-26 14:15:32 --> Model Class Initialized
INFO - 2018-03-26 14:15:32 --> Model Class Initialized
INFO - 2018-03-26 14:15:32 --> Model Class Initialized
INFO - 2018-03-26 14:15:32 --> Model Class Initialized
INFO - 2018-03-26 14:15:32 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 14:15:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-26 14:15:32 --> Final output sent to browser
DEBUG - 2018-03-26 14:15:32 --> Total execution time: 0.2672
INFO - 2018-03-26 08:48:28 --> Config Class Initialized
INFO - 2018-03-26 08:48:28 --> Hooks Class Initialized
DEBUG - 2018-03-26 08:48:28 --> UTF-8 Support Enabled
INFO - 2018-03-26 08:48:28 --> Utf8 Class Initialized
INFO - 2018-03-26 08:48:28 --> URI Class Initialized
INFO - 2018-03-26 08:48:28 --> Router Class Initialized
INFO - 2018-03-26 08:48:28 --> Output Class Initialized
INFO - 2018-03-26 08:48:28 --> Security Class Initialized
DEBUG - 2018-03-26 08:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 08:48:28 --> Input Class Initialized
INFO - 2018-03-26 08:48:28 --> Language Class Initialized
INFO - 2018-03-26 08:48:28 --> Language Class Initialized
INFO - 2018-03-26 08:48:28 --> Config Class Initialized
INFO - 2018-03-26 08:48:28 --> Loader Class Initialized
INFO - 2018-03-26 14:18:28 --> Helper loaded: url_helper
INFO - 2018-03-26 14:18:28 --> Helper loaded: notification_helper
INFO - 2018-03-26 14:18:28 --> Helper loaded: settings_helper
INFO - 2018-03-26 14:18:28 --> Helper loaded: permission_helper
INFO - 2018-03-26 14:18:28 --> Helper loaded: users_helper
INFO - 2018-03-26 14:18:28 --> Database Driver Class Initialized
DEBUG - 2018-03-26 14:18:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 14:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 14:18:28 --> Helper loaded: form_helper
INFO - 2018-03-26 14:18:28 --> Form Validation Class Initialized
INFO - 2018-03-26 14:18:28 --> Controller Class Initialized
INFO - 2018-03-26 14:18:28 --> Model Class Initialized
INFO - 2018-03-26 14:18:28 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 14:18:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 14:18:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 14:18:28 --> Model Class Initialized
INFO - 2018-03-26 14:18:28 --> Model Class Initialized
INFO - 2018-03-26 14:18:28 --> Model Class Initialized
INFO - 2018-03-26 14:18:28 --> Model Class Initialized
INFO - 2018-03-26 14:18:28 --> Model Class Initialized
INFO - 2018-03-26 14:18:28 --> Model Class Initialized
INFO - 2018-03-26 14:18:28 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 14:18:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-26 14:18:28 --> Final output sent to browser
DEBUG - 2018-03-26 14:18:28 --> Total execution time: 0.1243
INFO - 2018-03-26 08:51:16 --> Config Class Initialized
INFO - 2018-03-26 08:51:16 --> Hooks Class Initialized
DEBUG - 2018-03-26 08:51:16 --> UTF-8 Support Enabled
INFO - 2018-03-26 08:51:16 --> Utf8 Class Initialized
INFO - 2018-03-26 08:51:16 --> URI Class Initialized
INFO - 2018-03-26 08:51:16 --> Router Class Initialized
INFO - 2018-03-26 08:51:16 --> Output Class Initialized
INFO - 2018-03-26 08:51:16 --> Security Class Initialized
DEBUG - 2018-03-26 08:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 08:51:16 --> Input Class Initialized
INFO - 2018-03-26 08:51:16 --> Language Class Initialized
INFO - 2018-03-26 08:51:16 --> Language Class Initialized
INFO - 2018-03-26 08:51:16 --> Config Class Initialized
INFO - 2018-03-26 08:51:16 --> Loader Class Initialized
INFO - 2018-03-26 14:21:16 --> Helper loaded: url_helper
INFO - 2018-03-26 14:21:16 --> Helper loaded: notification_helper
INFO - 2018-03-26 14:21:16 --> Helper loaded: settings_helper
INFO - 2018-03-26 14:21:16 --> Helper loaded: permission_helper
INFO - 2018-03-26 14:21:16 --> Helper loaded: users_helper
INFO - 2018-03-26 14:21:16 --> Database Driver Class Initialized
DEBUG - 2018-03-26 14:21:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 14:21:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 14:21:16 --> Helper loaded: form_helper
INFO - 2018-03-26 14:21:16 --> Form Validation Class Initialized
INFO - 2018-03-26 14:21:16 --> Controller Class Initialized
INFO - 2018-03-26 14:21:16 --> Model Class Initialized
INFO - 2018-03-26 14:21:16 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 14:21:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 14:21:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 14:21:16 --> Model Class Initialized
INFO - 2018-03-26 14:21:16 --> Model Class Initialized
INFO - 2018-03-26 14:21:16 --> Model Class Initialized
INFO - 2018-03-26 14:21:16 --> Model Class Initialized
INFO - 2018-03-26 14:21:16 --> Model Class Initialized
INFO - 2018-03-26 14:21:16 --> Model Class Initialized
INFO - 2018-03-26 14:21:16 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 14:21:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-26 14:21:16 --> Final output sent to browser
DEBUG - 2018-03-26 14:21:16 --> Total execution time: 0.0986
INFO - 2018-03-26 08:58:41 --> Config Class Initialized
INFO - 2018-03-26 08:58:41 --> Hooks Class Initialized
DEBUG - 2018-03-26 08:58:41 --> UTF-8 Support Enabled
INFO - 2018-03-26 08:58:41 --> Utf8 Class Initialized
INFO - 2018-03-26 08:58:41 --> URI Class Initialized
INFO - 2018-03-26 08:58:41 --> Router Class Initialized
INFO - 2018-03-26 08:58:41 --> Output Class Initialized
INFO - 2018-03-26 08:58:41 --> Security Class Initialized
DEBUG - 2018-03-26 08:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 08:58:41 --> Input Class Initialized
INFO - 2018-03-26 08:58:41 --> Language Class Initialized
INFO - 2018-03-26 08:58:41 --> Language Class Initialized
INFO - 2018-03-26 08:58:41 --> Config Class Initialized
INFO - 2018-03-26 08:58:41 --> Loader Class Initialized
INFO - 2018-03-26 14:28:41 --> Helper loaded: url_helper
INFO - 2018-03-26 14:28:41 --> Helper loaded: notification_helper
INFO - 2018-03-26 14:28:41 --> Helper loaded: settings_helper
INFO - 2018-03-26 14:28:41 --> Helper loaded: permission_helper
INFO - 2018-03-26 14:28:41 --> Helper loaded: users_helper
INFO - 2018-03-26 14:28:41 --> Database Driver Class Initialized
DEBUG - 2018-03-26 14:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 14:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 14:28:41 --> Helper loaded: form_helper
INFO - 2018-03-26 14:28:41 --> Form Validation Class Initialized
INFO - 2018-03-26 14:28:41 --> Controller Class Initialized
INFO - 2018-03-26 14:28:41 --> Model Class Initialized
INFO - 2018-03-26 14:28:41 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 14:28:41 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 14:28:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 14:28:41 --> Model Class Initialized
INFO - 2018-03-26 14:28:41 --> Model Class Initialized
INFO - 2018-03-26 14:28:41 --> Model Class Initialized
INFO - 2018-03-26 14:28:41 --> Model Class Initialized
INFO - 2018-03-26 14:28:41 --> Model Class Initialized
INFO - 2018-03-26 14:28:41 --> Model Class Initialized
INFO - 2018-03-26 14:28:41 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 14:28:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-26 14:28:41 --> Final output sent to browser
DEBUG - 2018-03-26 14:28:41 --> Total execution time: 0.2513
INFO - 2018-03-26 09:13:30 --> Config Class Initialized
INFO - 2018-03-26 09:13:30 --> Hooks Class Initialized
DEBUG - 2018-03-26 09:13:30 --> UTF-8 Support Enabled
INFO - 2018-03-26 09:13:30 --> Utf8 Class Initialized
INFO - 2018-03-26 09:13:30 --> URI Class Initialized
INFO - 2018-03-26 09:13:30 --> Router Class Initialized
INFO - 2018-03-26 09:13:30 --> Output Class Initialized
INFO - 2018-03-26 09:13:30 --> Security Class Initialized
DEBUG - 2018-03-26 09:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 09:13:30 --> Input Class Initialized
INFO - 2018-03-26 09:13:30 --> Language Class Initialized
INFO - 2018-03-26 09:13:30 --> Language Class Initialized
INFO - 2018-03-26 09:13:30 --> Config Class Initialized
INFO - 2018-03-26 09:13:30 --> Loader Class Initialized
INFO - 2018-03-26 14:43:30 --> Helper loaded: url_helper
INFO - 2018-03-26 14:43:30 --> Helper loaded: notification_helper
INFO - 2018-03-26 14:43:30 --> Helper loaded: settings_helper
INFO - 2018-03-26 14:43:30 --> Helper loaded: permission_helper
INFO - 2018-03-26 14:43:30 --> Helper loaded: users_helper
INFO - 2018-03-26 14:43:31 --> Database Driver Class Initialized
DEBUG - 2018-03-26 14:43:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 14:43:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 14:43:31 --> Helper loaded: form_helper
INFO - 2018-03-26 14:43:31 --> Form Validation Class Initialized
INFO - 2018-03-26 14:43:31 --> Controller Class Initialized
INFO - 2018-03-26 14:43:31 --> Model Class Initialized
INFO - 2018-03-26 14:43:31 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 14:43:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 14:43:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 14:43:31 --> Model Class Initialized
INFO - 2018-03-26 14:43:31 --> Model Class Initialized
INFO - 2018-03-26 14:43:31 --> Model Class Initialized
INFO - 2018-03-26 14:43:31 --> Model Class Initialized
INFO - 2018-03-26 14:43:31 --> Model Class Initialized
INFO - 2018-03-26 14:43:31 --> Model Class Initialized
INFO - 2018-03-26 14:43:31 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 14:43:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-26 14:43:31 --> Final output sent to browser
DEBUG - 2018-03-26 14:43:31 --> Total execution time: 0.3935
INFO - 2018-03-26 09:13:32 --> Config Class Initialized
INFO - 2018-03-26 09:13:32 --> Hooks Class Initialized
DEBUG - 2018-03-26 09:13:32 --> UTF-8 Support Enabled
INFO - 2018-03-26 09:13:32 --> Utf8 Class Initialized
INFO - 2018-03-26 09:13:32 --> URI Class Initialized
INFO - 2018-03-26 09:13:32 --> Router Class Initialized
INFO - 2018-03-26 09:13:32 --> Output Class Initialized
INFO - 2018-03-26 09:13:32 --> Security Class Initialized
DEBUG - 2018-03-26 09:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 09:13:32 --> Input Class Initialized
INFO - 2018-03-26 09:13:32 --> Language Class Initialized
INFO - 2018-03-26 09:13:32 --> Language Class Initialized
INFO - 2018-03-26 09:13:32 --> Config Class Initialized
INFO - 2018-03-26 09:13:32 --> Loader Class Initialized
INFO - 2018-03-26 14:43:32 --> Helper loaded: url_helper
INFO - 2018-03-26 14:43:32 --> Helper loaded: notification_helper
INFO - 2018-03-26 14:43:32 --> Helper loaded: settings_helper
INFO - 2018-03-26 14:43:32 --> Helper loaded: permission_helper
INFO - 2018-03-26 14:43:32 --> Helper loaded: users_helper
INFO - 2018-03-26 14:43:33 --> Database Driver Class Initialized
DEBUG - 2018-03-26 14:43:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 14:43:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 14:43:33 --> Helper loaded: form_helper
INFO - 2018-03-26 14:43:33 --> Form Validation Class Initialized
INFO - 2018-03-26 14:43:33 --> Controller Class Initialized
INFO - 2018-03-26 14:43:33 --> Model Class Initialized
INFO - 2018-03-26 14:43:33 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 14:43:33 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 14:43:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 14:43:33 --> Model Class Initialized
INFO - 2018-03-26 14:43:33 --> Model Class Initialized
INFO - 2018-03-26 14:43:33 --> Model Class Initialized
INFO - 2018-03-26 14:43:33 --> Model Class Initialized
INFO - 2018-03-26 14:43:33 --> Model Class Initialized
INFO - 2018-03-26 14:43:33 --> Model Class Initialized
INFO - 2018-03-26 14:43:33 --> Model Class Initialized
INFO - 2018-03-26 09:13:33 --> Config Class Initialized
INFO - 2018-03-26 14:43:33 --> Model Class Initialized
INFO - 2018-03-26 14:43:33 --> Model Class Initialized
INFO - 2018-03-26 14:43:33 --> Model Class Initialized
INFO - 2018-03-26 09:13:33 --> Hooks Class Initialized
INFO - 2018-03-26 14:43:33 --> Model Class Initialized
INFO - 2018-03-26 14:43:33 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 14:43:33 --> Model Class Initialized
INFO - 2018-03-26 14:43:33 --> Final output sent to browser
DEBUG - 2018-03-26 14:43:33 --> Total execution time: 0.6820
DEBUG - 2018-03-26 09:13:33 --> UTF-8 Support Enabled
INFO - 2018-03-26 09:13:33 --> Utf8 Class Initialized
INFO - 2018-03-26 09:13:33 --> URI Class Initialized
INFO - 2018-03-26 09:13:33 --> Router Class Initialized
INFO - 2018-03-26 09:13:33 --> Output Class Initialized
INFO - 2018-03-26 09:13:33 --> Security Class Initialized
DEBUG - 2018-03-26 09:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 09:13:33 --> Input Class Initialized
INFO - 2018-03-26 09:13:33 --> Language Class Initialized
INFO - 2018-03-26 09:13:33 --> Language Class Initialized
INFO - 2018-03-26 09:13:33 --> Config Class Initialized
INFO - 2018-03-26 09:13:33 --> Loader Class Initialized
INFO - 2018-03-26 14:43:33 --> Helper loaded: url_helper
INFO - 2018-03-26 14:43:33 --> Helper loaded: notification_helper
INFO - 2018-03-26 14:43:33 --> Helper loaded: settings_helper
INFO - 2018-03-26 14:43:33 --> Helper loaded: permission_helper
INFO - 2018-03-26 14:43:33 --> Helper loaded: users_helper
INFO - 2018-03-26 14:43:34 --> Database Driver Class Initialized
DEBUG - 2018-03-26 14:43:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 14:43:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 09:13:34 --> Config Class Initialized
INFO - 2018-03-26 09:13:34 --> Hooks Class Initialized
DEBUG - 2018-03-26 09:13:34 --> UTF-8 Support Enabled
INFO - 2018-03-26 09:13:34 --> Utf8 Class Initialized
INFO - 2018-03-26 09:13:34 --> URI Class Initialized
INFO - 2018-03-26 09:13:34 --> Router Class Initialized
INFO - 2018-03-26 09:13:34 --> Output Class Initialized
INFO - 2018-03-26 09:13:34 --> Security Class Initialized
DEBUG - 2018-03-26 09:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 09:13:34 --> Input Class Initialized
INFO - 2018-03-26 09:13:34 --> Language Class Initialized
INFO - 2018-03-26 09:13:34 --> Language Class Initialized
INFO - 2018-03-26 09:13:34 --> Config Class Initialized
INFO - 2018-03-26 09:13:34 --> Loader Class Initialized
INFO - 2018-03-26 14:43:34 --> Helper loaded: url_helper
INFO - 2018-03-26 14:43:34 --> Helper loaded: notification_helper
INFO - 2018-03-26 14:43:34 --> Helper loaded: settings_helper
INFO - 2018-03-26 14:43:34 --> Helper loaded: permission_helper
INFO - 2018-03-26 14:43:34 --> Helper loaded: users_helper
INFO - 2018-03-26 14:43:34 --> Database Driver Class Initialized
DEBUG - 2018-03-26 14:43:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 14:43:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 14:43:34 --> Helper loaded: form_helper
INFO - 2018-03-26 14:43:34 --> Form Validation Class Initialized
INFO - 2018-03-26 14:43:34 --> Controller Class Initialized
INFO - 2018-03-26 14:43:34 --> Model Class Initialized
INFO - 2018-03-26 14:43:34 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 14:43:34 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 14:43:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 14:43:34 --> Model Class Initialized
INFO - 2018-03-26 14:43:34 --> Model Class Initialized
INFO - 2018-03-26 14:43:34 --> Model Class Initialized
INFO - 2018-03-26 14:43:34 --> Model Class Initialized
INFO - 2018-03-26 14:43:34 --> Model Class Initialized
INFO - 2018-03-26 14:43:34 --> Model Class Initialized
INFO - 2018-03-26 14:43:34 --> Model Class Initialized
INFO - 2018-03-26 14:43:34 --> Model Class Initialized
INFO - 2018-03-26 14:43:34 --> Model Class Initialized
INFO - 2018-03-26 14:43:34 --> Model Class Initialized
INFO - 2018-03-26 14:43:34 --> Model Class Initialized
INFO - 2018-03-26 14:43:34 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 14:43:34 --> Model Class Initialized
INFO - 2018-03-26 14:43:34 --> Final output sent to browser
DEBUG - 2018-03-26 14:43:34 --> Total execution time: 0.2063
INFO - 2018-03-26 14:43:34 --> Helper loaded: form_helper
INFO - 2018-03-26 14:43:34 --> Form Validation Class Initialized
INFO - 2018-03-26 14:43:34 --> Controller Class Initialized
INFO - 2018-03-26 14:43:35 --> Model Class Initialized
INFO - 2018-03-26 14:43:35 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 14:43:35 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 14:43:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 14:43:35 --> Model Class Initialized
INFO - 2018-03-26 14:43:35 --> Model Class Initialized
INFO - 2018-03-26 14:43:35 --> Model Class Initialized
INFO - 2018-03-26 14:43:35 --> Model Class Initialized
INFO - 2018-03-26 14:43:35 --> Model Class Initialized
INFO - 2018-03-26 14:43:35 --> Model Class Initialized
INFO - 2018-03-26 14:43:35 --> Model Class Initialized
INFO - 2018-03-26 14:43:35 --> Model Class Initialized
INFO - 2018-03-26 14:43:35 --> Model Class Initialized
INFO - 2018-03-26 14:43:35 --> Model Class Initialized
INFO - 2018-03-26 14:43:35 --> Model Class Initialized
INFO - 2018-03-26 14:43:35 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 14:43:35 --> Model Class Initialized
INFO - 2018-03-26 14:43:35 --> Final output sent to browser
DEBUG - 2018-03-26 14:43:35 --> Total execution time: 2.6106
INFO - 2018-03-26 09:21:54 --> Config Class Initialized
INFO - 2018-03-26 09:21:54 --> Hooks Class Initialized
DEBUG - 2018-03-26 09:21:55 --> UTF-8 Support Enabled
INFO - 2018-03-26 09:21:55 --> Utf8 Class Initialized
INFO - 2018-03-26 09:21:55 --> URI Class Initialized
INFO - 2018-03-26 09:21:55 --> Router Class Initialized
INFO - 2018-03-26 09:21:55 --> Output Class Initialized
INFO - 2018-03-26 09:21:55 --> Security Class Initialized
DEBUG - 2018-03-26 09:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 09:21:55 --> Input Class Initialized
INFO - 2018-03-26 09:21:55 --> Language Class Initialized
INFO - 2018-03-26 09:21:56 --> Language Class Initialized
INFO - 2018-03-26 09:21:56 --> Config Class Initialized
INFO - 2018-03-26 09:21:56 --> Loader Class Initialized
INFO - 2018-03-26 14:51:56 --> Helper loaded: url_helper
INFO - 2018-03-26 14:51:56 --> Helper loaded: notification_helper
INFO - 2018-03-26 14:51:57 --> Helper loaded: settings_helper
INFO - 2018-03-26 14:51:57 --> Helper loaded: permission_helper
INFO - 2018-03-26 14:51:57 --> Helper loaded: users_helper
INFO - 2018-03-26 14:51:57 --> Database Driver Class Initialized
DEBUG - 2018-03-26 14:51:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 14:51:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 09:21:58 --> Config Class Initialized
INFO - 2018-03-26 09:21:58 --> Hooks Class Initialized
DEBUG - 2018-03-26 09:21:58 --> UTF-8 Support Enabled
INFO - 2018-03-26 09:21:58 --> Utf8 Class Initialized
INFO - 2018-03-26 09:21:58 --> URI Class Initialized
INFO - 2018-03-26 09:21:58 --> Router Class Initialized
INFO - 2018-03-26 09:21:58 --> Output Class Initialized
INFO - 2018-03-26 09:21:58 --> Security Class Initialized
DEBUG - 2018-03-26 09:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 09:21:58 --> Input Class Initialized
INFO - 2018-03-26 09:21:58 --> Language Class Initialized
INFO - 2018-03-26 09:21:58 --> Language Class Initialized
INFO - 2018-03-26 09:21:58 --> Config Class Initialized
INFO - 2018-03-26 09:21:58 --> Loader Class Initialized
INFO - 2018-03-26 14:51:58 --> Helper loaded: url_helper
INFO - 2018-03-26 14:51:58 --> Helper loaded: notification_helper
INFO - 2018-03-26 14:51:58 --> Helper loaded: settings_helper
INFO - 2018-03-26 14:51:58 --> Helper loaded: permission_helper
INFO - 2018-03-26 14:51:58 --> Helper loaded: users_helper
INFO - 2018-03-26 14:51:58 --> Helper loaded: form_helper
INFO - 2018-03-26 14:51:58 --> Form Validation Class Initialized
INFO - 2018-03-26 14:51:58 --> Controller Class Initialized
INFO - 2018-03-26 14:51:58 --> Database Driver Class Initialized
DEBUG - 2018-03-26 14:51:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 14:51:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 14:51:58 --> Helper loaded: form_helper
INFO - 2018-03-26 14:51:58 --> Form Validation Class Initialized
INFO - 2018-03-26 14:51:58 --> Controller Class Initialized
INFO - 2018-03-26 14:51:58 --> Model Class Initialized
INFO - 2018-03-26 14:51:58 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 14:51:58 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 14:51:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 14:51:58 --> Model Class Initialized
INFO - 2018-03-26 14:51:58 --> Model Class Initialized
INFO - 2018-03-26 14:51:58 --> Model Class Initialized
INFO - 2018-03-26 14:51:58 --> Model Class Initialized
INFO - 2018-03-26 14:51:58 --> Model Class Initialized
INFO - 2018-03-26 14:51:58 --> Model Class Initialized
INFO - 2018-03-26 14:51:58 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 14:51:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-26 14:51:58 --> Final output sent to browser
DEBUG - 2018-03-26 14:51:58 --> Total execution time: 0.2416
INFO - 2018-03-26 14:51:59 --> Model Class Initialized
INFO - 2018-03-26 14:51:59 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 14:51:59 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 09:21:59 --> Config Class Initialized
INFO - 2018-03-26 09:21:59 --> Hooks Class Initialized
INFO - 2018-03-26 14:51:59 --> Language file loaded: language/english/rest_controller_lang.php
DEBUG - 2018-03-26 09:21:59 --> UTF-8 Support Enabled
INFO - 2018-03-26 09:21:59 --> Utf8 Class Initialized
INFO - 2018-03-26 09:21:59 --> URI Class Initialized
INFO - 2018-03-26 09:21:59 --> Router Class Initialized
INFO - 2018-03-26 09:21:59 --> Output Class Initialized
INFO - 2018-03-26 09:21:59 --> Security Class Initialized
DEBUG - 2018-03-26 09:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 09:21:59 --> Input Class Initialized
INFO - 2018-03-26 09:21:59 --> Language Class Initialized
INFO - 2018-03-26 09:21:59 --> Language Class Initialized
INFO - 2018-03-26 09:21:59 --> Config Class Initialized
INFO - 2018-03-26 09:21:59 --> Loader Class Initialized
INFO - 2018-03-26 14:51:59 --> Helper loaded: url_helper
INFO - 2018-03-26 14:51:59 --> Helper loaded: notification_helper
INFO - 2018-03-26 14:51:59 --> Helper loaded: settings_helper
INFO - 2018-03-26 14:51:59 --> Helper loaded: permission_helper
INFO - 2018-03-26 14:51:59 --> Helper loaded: users_helper
INFO - 2018-03-26 14:51:59 --> Model Class Initialized
INFO - 2018-03-26 14:51:59 --> Database Driver Class Initialized
INFO - 2018-03-26 14:51:59 --> Model Class Initialized
DEBUG - 2018-03-26 14:51:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 14:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 14:51:59 --> Helper loaded: form_helper
INFO - 2018-03-26 14:51:59 --> Form Validation Class Initialized
INFO - 2018-03-26 14:51:59 --> Controller Class Initialized
INFO - 2018-03-26 14:51:59 --> Model Class Initialized
INFO - 2018-03-26 14:51:59 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 14:51:59 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 14:51:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 14:51:59 --> Model Class Initialized
INFO - 2018-03-26 14:51:59 --> Model Class Initialized
INFO - 2018-03-26 14:51:59 --> Model Class Initialized
INFO - 2018-03-26 14:51:59 --> Model Class Initialized
INFO - 2018-03-26 14:51:59 --> Model Class Initialized
INFO - 2018-03-26 14:51:59 --> Model Class Initialized
INFO - 2018-03-26 14:51:59 --> Model Class Initialized
INFO - 2018-03-26 14:51:59 --> Model Class Initialized
INFO - 2018-03-26 14:51:59 --> Model Class Initialized
INFO - 2018-03-26 14:51:59 --> Model Class Initialized
INFO - 2018-03-26 14:51:59 --> Model Class Initialized
INFO - 2018-03-26 14:51:59 --> Model Class Initialized
INFO - 2018-03-26 14:51:59 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 14:51:59 --> Model Class Initialized
INFO - 2018-03-26 14:51:59 --> Final output sent to browser
DEBUG - 2018-03-26 14:51:59 --> Total execution time: 0.1630
INFO - 2018-03-26 14:51:59 --> Model Class Initialized
INFO - 2018-03-26 14:51:59 --> Model Class Initialized
INFO - 2018-03-26 14:51:59 --> Model Class Initialized
INFO - 2018-03-26 14:51:59 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 14:51:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-26 14:51:59 --> Final output sent to browser
DEBUG - 2018-03-26 14:51:59 --> Total execution time: 5.3422
INFO - 2018-03-26 09:22:00 --> Config Class Initialized
INFO - 2018-03-26 09:22:00 --> Hooks Class Initialized
DEBUG - 2018-03-26 09:22:00 --> UTF-8 Support Enabled
INFO - 2018-03-26 09:22:00 --> Utf8 Class Initialized
INFO - 2018-03-26 09:22:00 --> URI Class Initialized
INFO - 2018-03-26 09:22:00 --> Router Class Initialized
INFO - 2018-03-26 09:22:00 --> Output Class Initialized
INFO - 2018-03-26 09:22:00 --> Security Class Initialized
DEBUG - 2018-03-26 09:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 09:22:00 --> Input Class Initialized
INFO - 2018-03-26 09:22:00 --> Language Class Initialized
INFO - 2018-03-26 09:22:01 --> Language Class Initialized
INFO - 2018-03-26 09:22:01 --> Config Class Initialized
INFO - 2018-03-26 09:22:01 --> Loader Class Initialized
INFO - 2018-03-26 14:52:01 --> Helper loaded: url_helper
INFO - 2018-03-26 14:52:01 --> Helper loaded: notification_helper
INFO - 2018-03-26 14:52:01 --> Helper loaded: settings_helper
INFO - 2018-03-26 14:52:01 --> Helper loaded: permission_helper
INFO - 2018-03-26 14:52:01 --> Helper loaded: users_helper
INFO - 2018-03-26 14:52:01 --> Database Driver Class Initialized
DEBUG - 2018-03-26 14:52:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 14:52:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 14:52:01 --> Helper loaded: form_helper
INFO - 2018-03-26 14:52:01 --> Form Validation Class Initialized
INFO - 2018-03-26 14:52:01 --> Controller Class Initialized
INFO - 2018-03-26 14:52:01 --> Model Class Initialized
INFO - 2018-03-26 14:52:01 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 14:52:01 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 14:52:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 14:52:01 --> Model Class Initialized
INFO - 2018-03-26 14:52:01 --> Model Class Initialized
INFO - 2018-03-26 14:52:01 --> Model Class Initialized
INFO - 2018-03-26 14:52:01 --> Model Class Initialized
INFO - 2018-03-26 14:52:01 --> Model Class Initialized
INFO - 2018-03-26 14:52:01 --> Model Class Initialized
INFO - 2018-03-26 14:52:01 --> Model Class Initialized
INFO - 2018-03-26 14:52:01 --> Model Class Initialized
INFO - 2018-03-26 14:52:01 --> Model Class Initialized
INFO - 2018-03-26 14:52:01 --> Model Class Initialized
INFO - 2018-03-26 14:52:01 --> Model Class Initialized
INFO - 2018-03-26 14:52:01 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 14:52:01 --> Model Class Initialized
INFO - 2018-03-26 14:52:01 --> Final output sent to browser
DEBUG - 2018-03-26 14:52:01 --> Total execution time: 0.6746
INFO - 2018-03-26 09:24:58 --> Config Class Initialized
INFO - 2018-03-26 09:24:58 --> Hooks Class Initialized
DEBUG - 2018-03-26 09:24:58 --> UTF-8 Support Enabled
INFO - 2018-03-26 09:24:58 --> Utf8 Class Initialized
INFO - 2018-03-26 09:24:58 --> URI Class Initialized
INFO - 2018-03-26 09:24:58 --> Router Class Initialized
INFO - 2018-03-26 09:24:58 --> Output Class Initialized
INFO - 2018-03-26 09:24:58 --> Security Class Initialized
DEBUG - 2018-03-26 09:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 09:24:58 --> Input Class Initialized
INFO - 2018-03-26 09:24:58 --> Language Class Initialized
INFO - 2018-03-26 09:24:58 --> Language Class Initialized
INFO - 2018-03-26 09:24:58 --> Config Class Initialized
INFO - 2018-03-26 09:24:58 --> Loader Class Initialized
INFO - 2018-03-26 14:54:58 --> Helper loaded: url_helper
INFO - 2018-03-26 14:54:58 --> Helper loaded: notification_helper
INFO - 2018-03-26 14:54:58 --> Helper loaded: settings_helper
INFO - 2018-03-26 14:54:58 --> Helper loaded: permission_helper
INFO - 2018-03-26 14:54:58 --> Helper loaded: users_helper
INFO - 2018-03-26 14:54:58 --> Database Driver Class Initialized
DEBUG - 2018-03-26 14:54:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 14:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 14:54:58 --> Helper loaded: form_helper
INFO - 2018-03-26 14:54:58 --> Form Validation Class Initialized
INFO - 2018-03-26 14:54:58 --> Controller Class Initialized
INFO - 2018-03-26 14:54:58 --> Model Class Initialized
INFO - 2018-03-26 14:54:58 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 14:54:58 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 14:54:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 14:54:58 --> Model Class Initialized
INFO - 2018-03-26 14:54:58 --> Model Class Initialized
INFO - 2018-03-26 14:54:58 --> Model Class Initialized
INFO - 2018-03-26 14:54:58 --> Model Class Initialized
INFO - 2018-03-26 14:54:58 --> Model Class Initialized
INFO - 2018-03-26 14:54:58 --> Model Class Initialized
INFO - 2018-03-26 14:54:58 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 14:54:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-26 14:54:58 --> Final output sent to browser
DEBUG - 2018-03-26 14:54:58 --> Total execution time: 0.2148
INFO - 2018-03-26 09:24:59 --> Config Class Initialized
INFO - 2018-03-26 09:24:59 --> Hooks Class Initialized
DEBUG - 2018-03-26 09:24:59 --> UTF-8 Support Enabled
INFO - 2018-03-26 09:24:59 --> Utf8 Class Initialized
INFO - 2018-03-26 09:24:59 --> URI Class Initialized
INFO - 2018-03-26 09:24:59 --> Router Class Initialized
INFO - 2018-03-26 09:24:59 --> Output Class Initialized
INFO - 2018-03-26 09:24:59 --> Security Class Initialized
DEBUG - 2018-03-26 09:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 09:24:59 --> Input Class Initialized
INFO - 2018-03-26 09:24:59 --> Language Class Initialized
INFO - 2018-03-26 09:24:59 --> Language Class Initialized
INFO - 2018-03-26 09:24:59 --> Config Class Initialized
INFO - 2018-03-26 09:24:59 --> Loader Class Initialized
INFO - 2018-03-26 14:54:59 --> Helper loaded: url_helper
INFO - 2018-03-26 14:54:59 --> Helper loaded: notification_helper
INFO - 2018-03-26 14:54:59 --> Helper loaded: settings_helper
INFO - 2018-03-26 14:54:59 --> Helper loaded: permission_helper
INFO - 2018-03-26 14:54:59 --> Helper loaded: users_helper
INFO - 2018-03-26 14:54:59 --> Database Driver Class Initialized
DEBUG - 2018-03-26 14:54:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 14:54:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 14:54:59 --> Helper loaded: form_helper
INFO - 2018-03-26 14:54:59 --> Form Validation Class Initialized
INFO - 2018-03-26 14:54:59 --> Controller Class Initialized
INFO - 2018-03-26 14:54:59 --> Model Class Initialized
INFO - 2018-03-26 14:54:59 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 14:54:59 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 14:54:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 14:54:59 --> Model Class Initialized
INFO - 2018-03-26 14:54:59 --> Model Class Initialized
INFO - 2018-03-26 14:54:59 --> Model Class Initialized
INFO - 2018-03-26 14:54:59 --> Model Class Initialized
INFO - 2018-03-26 14:54:59 --> Model Class Initialized
INFO - 2018-03-26 14:54:59 --> Model Class Initialized
INFO - 2018-03-26 14:54:59 --> Model Class Initialized
INFO - 2018-03-26 14:54:59 --> Model Class Initialized
INFO - 2018-03-26 14:54:59 --> Model Class Initialized
INFO - 2018-03-26 14:54:59 --> Model Class Initialized
INFO - 2018-03-26 14:54:59 --> Model Class Initialized
INFO - 2018-03-26 14:54:59 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 14:54:59 --> Model Class Initialized
INFO - 2018-03-26 09:24:59 --> Config Class Initialized
INFO - 2018-03-26 09:24:59 --> Hooks Class Initialized
DEBUG - 2018-03-26 09:24:59 --> UTF-8 Support Enabled
INFO - 2018-03-26 09:24:59 --> Utf8 Class Initialized
INFO - 2018-03-26 09:24:59 --> URI Class Initialized
INFO - 2018-03-26 09:24:59 --> Router Class Initialized
INFO - 2018-03-26 09:24:59 --> Output Class Initialized
INFO - 2018-03-26 09:24:59 --> Security Class Initialized
DEBUG - 2018-03-26 09:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 09:24:59 --> Input Class Initialized
INFO - 2018-03-26 14:54:59 --> Final output sent to browser
DEBUG - 2018-03-26 14:54:59 --> Total execution time: 0.3840
INFO - 2018-03-26 09:24:59 --> Language Class Initialized
INFO - 2018-03-26 09:25:00 --> Language Class Initialized
INFO - 2018-03-26 09:25:00 --> Config Class Initialized
INFO - 2018-03-26 09:25:00 --> Loader Class Initialized
INFO - 2018-03-26 14:55:00 --> Helper loaded: url_helper
INFO - 2018-03-26 14:55:00 --> Helper loaded: notification_helper
INFO - 2018-03-26 14:55:00 --> Helper loaded: settings_helper
INFO - 2018-03-26 14:55:00 --> Helper loaded: permission_helper
INFO - 2018-03-26 14:55:00 --> Helper loaded: users_helper
INFO - 2018-03-26 14:55:00 --> Database Driver Class Initialized
DEBUG - 2018-03-26 14:55:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 14:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 14:55:00 --> Helper loaded: form_helper
INFO - 2018-03-26 14:55:00 --> Form Validation Class Initialized
INFO - 2018-03-26 14:55:00 --> Controller Class Initialized
INFO - 2018-03-26 14:55:00 --> Model Class Initialized
INFO - 2018-03-26 14:55:00 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 14:55:00 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 14:55:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 14:55:00 --> Model Class Initialized
INFO - 2018-03-26 14:55:00 --> Model Class Initialized
INFO - 2018-03-26 14:55:00 --> Model Class Initialized
INFO - 2018-03-26 14:55:00 --> Model Class Initialized
INFO - 2018-03-26 14:55:00 --> Model Class Initialized
INFO - 2018-03-26 14:55:00 --> Model Class Initialized
INFO - 2018-03-26 14:55:00 --> Model Class Initialized
INFO - 2018-03-26 14:55:00 --> Model Class Initialized
INFO - 2018-03-26 14:55:00 --> Model Class Initialized
INFO - 2018-03-26 14:55:00 --> Model Class Initialized
INFO - 2018-03-26 14:55:00 --> Model Class Initialized
INFO - 2018-03-26 14:55:00 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 14:55:00 --> Model Class Initialized
INFO - 2018-03-26 14:55:00 --> Final output sent to browser
DEBUG - 2018-03-26 14:55:00 --> Total execution time: 0.9938
INFO - 2018-03-26 09:27:02 --> Config Class Initialized
INFO - 2018-03-26 09:27:02 --> Hooks Class Initialized
DEBUG - 2018-03-26 09:27:02 --> UTF-8 Support Enabled
INFO - 2018-03-26 09:27:02 --> Utf8 Class Initialized
INFO - 2018-03-26 09:27:02 --> URI Class Initialized
INFO - 2018-03-26 09:27:02 --> Router Class Initialized
INFO - 2018-03-26 09:27:02 --> Output Class Initialized
INFO - 2018-03-26 09:27:02 --> Security Class Initialized
DEBUG - 2018-03-26 09:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 09:27:02 --> Input Class Initialized
INFO - 2018-03-26 09:27:02 --> Language Class Initialized
INFO - 2018-03-26 09:27:02 --> Language Class Initialized
INFO - 2018-03-26 09:27:02 --> Config Class Initialized
INFO - 2018-03-26 09:27:02 --> Loader Class Initialized
INFO - 2018-03-26 14:57:02 --> Helper loaded: url_helper
INFO - 2018-03-26 14:57:02 --> Helper loaded: notification_helper
INFO - 2018-03-26 14:57:02 --> Helper loaded: settings_helper
INFO - 2018-03-26 14:57:02 --> Helper loaded: permission_helper
INFO - 2018-03-26 14:57:02 --> Helper loaded: users_helper
INFO - 2018-03-26 14:57:02 --> Database Driver Class Initialized
DEBUG - 2018-03-26 14:57:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 14:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 14:57:02 --> Helper loaded: form_helper
INFO - 2018-03-26 14:57:02 --> Form Validation Class Initialized
INFO - 2018-03-26 14:57:02 --> Controller Class Initialized
INFO - 2018-03-26 14:57:02 --> Model Class Initialized
INFO - 2018-03-26 14:57:02 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 14:57:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 14:57:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 14:57:02 --> Model Class Initialized
INFO - 2018-03-26 14:57:02 --> Model Class Initialized
INFO - 2018-03-26 14:57:02 --> Model Class Initialized
INFO - 2018-03-26 14:57:02 --> Model Class Initialized
INFO - 2018-03-26 14:57:02 --> Model Class Initialized
INFO - 2018-03-26 14:57:02 --> Model Class Initialized
INFO - 2018-03-26 14:57:02 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 14:57:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-26 14:57:02 --> Final output sent to browser
DEBUG - 2018-03-26 14:57:02 --> Total execution time: 0.1157
INFO - 2018-03-26 09:27:03 --> Config Class Initialized
INFO - 2018-03-26 09:27:03 --> Hooks Class Initialized
DEBUG - 2018-03-26 09:27:03 --> UTF-8 Support Enabled
INFO - 2018-03-26 09:27:03 --> Utf8 Class Initialized
INFO - 2018-03-26 09:27:03 --> URI Class Initialized
INFO - 2018-03-26 09:27:03 --> Router Class Initialized
INFO - 2018-03-26 09:27:03 --> Output Class Initialized
INFO - 2018-03-26 09:27:03 --> Security Class Initialized
DEBUG - 2018-03-26 09:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 09:27:03 --> Input Class Initialized
INFO - 2018-03-26 09:27:03 --> Language Class Initialized
INFO - 2018-03-26 09:27:03 --> Language Class Initialized
INFO - 2018-03-26 09:27:03 --> Config Class Initialized
INFO - 2018-03-26 09:27:03 --> Loader Class Initialized
INFO - 2018-03-26 14:57:03 --> Helper loaded: url_helper
INFO - 2018-03-26 14:57:03 --> Helper loaded: notification_helper
INFO - 2018-03-26 14:57:03 --> Helper loaded: settings_helper
INFO - 2018-03-26 14:57:03 --> Helper loaded: permission_helper
INFO - 2018-03-26 14:57:03 --> Helper loaded: users_helper
INFO - 2018-03-26 14:57:03 --> Database Driver Class Initialized
DEBUG - 2018-03-26 14:57:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 14:57:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 14:57:03 --> Helper loaded: form_helper
INFO - 2018-03-26 14:57:03 --> Form Validation Class Initialized
INFO - 2018-03-26 14:57:03 --> Controller Class Initialized
INFO - 2018-03-26 14:57:03 --> Model Class Initialized
INFO - 2018-03-26 14:57:03 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 14:57:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 14:57:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 14:57:03 --> Model Class Initialized
INFO - 2018-03-26 14:57:03 --> Model Class Initialized
INFO - 2018-03-26 14:57:03 --> Model Class Initialized
INFO - 2018-03-26 14:57:03 --> Model Class Initialized
INFO - 2018-03-26 14:57:03 --> Model Class Initialized
INFO - 2018-03-26 14:57:03 --> Model Class Initialized
INFO - 2018-03-26 14:57:03 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 14:57:03 --> Final output sent to browser
DEBUG - 2018-03-26 14:57:03 --> Total execution time: 0.2485
INFO - 2018-03-26 09:28:34 --> Config Class Initialized
INFO - 2018-03-26 09:28:34 --> Hooks Class Initialized
DEBUG - 2018-03-26 09:28:34 --> UTF-8 Support Enabled
INFO - 2018-03-26 09:28:34 --> Utf8 Class Initialized
INFO - 2018-03-26 09:28:34 --> URI Class Initialized
INFO - 2018-03-26 09:28:34 --> Router Class Initialized
INFO - 2018-03-26 09:28:34 --> Output Class Initialized
INFO - 2018-03-26 09:28:34 --> Security Class Initialized
DEBUG - 2018-03-26 09:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 09:28:34 --> Input Class Initialized
INFO - 2018-03-26 09:28:34 --> Language Class Initialized
INFO - 2018-03-26 09:28:35 --> Language Class Initialized
INFO - 2018-03-26 09:28:35 --> Config Class Initialized
INFO - 2018-03-26 09:28:35 --> Loader Class Initialized
INFO - 2018-03-26 14:58:35 --> Helper loaded: url_helper
INFO - 2018-03-26 14:58:35 --> Helper loaded: notification_helper
INFO - 2018-03-26 14:58:35 --> Helper loaded: settings_helper
INFO - 2018-03-26 14:58:35 --> Helper loaded: permission_helper
INFO - 2018-03-26 14:58:35 --> Helper loaded: users_helper
INFO - 2018-03-26 14:58:36 --> Database Driver Class Initialized
DEBUG - 2018-03-26 14:58:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 14:58:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 14:58:36 --> Helper loaded: form_helper
INFO - 2018-03-26 14:58:36 --> Form Validation Class Initialized
INFO - 2018-03-26 14:58:36 --> Controller Class Initialized
INFO - 2018-03-26 14:58:36 --> Model Class Initialized
INFO - 2018-03-26 14:58:36 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 14:58:36 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 14:58:36 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 14:58:36 --> Model Class Initialized
INFO - 2018-03-26 14:58:36 --> Model Class Initialized
INFO - 2018-03-26 14:58:36 --> Model Class Initialized
INFO - 2018-03-26 14:58:36 --> Model Class Initialized
INFO - 2018-03-26 14:58:36 --> Model Class Initialized
INFO - 2018-03-26 14:58:36 --> Model Class Initialized
INFO - 2018-03-26 14:58:36 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 14:58:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-26 14:58:36 --> Final output sent to browser
DEBUG - 2018-03-26 14:58:36 --> Total execution time: 2.1065
INFO - 2018-03-26 09:28:36 --> Config Class Initialized
INFO - 2018-03-26 09:28:36 --> Hooks Class Initialized
DEBUG - 2018-03-26 09:28:36 --> UTF-8 Support Enabled
INFO - 2018-03-26 09:28:36 --> Utf8 Class Initialized
INFO - 2018-03-26 09:28:36 --> URI Class Initialized
INFO - 2018-03-26 09:28:36 --> Router Class Initialized
INFO - 2018-03-26 09:28:36 --> Output Class Initialized
INFO - 2018-03-26 09:28:36 --> Security Class Initialized
DEBUG - 2018-03-26 09:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 09:28:36 --> Input Class Initialized
INFO - 2018-03-26 09:28:36 --> Language Class Initialized
INFO - 2018-03-26 09:28:36 --> Language Class Initialized
INFO - 2018-03-26 09:28:36 --> Config Class Initialized
INFO - 2018-03-26 09:28:36 --> Loader Class Initialized
INFO - 2018-03-26 14:58:36 --> Helper loaded: url_helper
INFO - 2018-03-26 14:58:36 --> Helper loaded: notification_helper
INFO - 2018-03-26 14:58:36 --> Helper loaded: settings_helper
INFO - 2018-03-26 14:58:36 --> Helper loaded: permission_helper
INFO - 2018-03-26 14:58:36 --> Helper loaded: users_helper
INFO - 2018-03-26 14:58:36 --> Database Driver Class Initialized
DEBUG - 2018-03-26 14:58:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 14:58:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 14:58:36 --> Helper loaded: form_helper
INFO - 2018-03-26 14:58:36 --> Form Validation Class Initialized
INFO - 2018-03-26 14:58:36 --> Controller Class Initialized
INFO - 2018-03-26 14:58:37 --> Model Class Initialized
INFO - 2018-03-26 14:58:37 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 14:58:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 14:58:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 14:58:37 --> Model Class Initialized
INFO - 2018-03-26 14:58:37 --> Model Class Initialized
INFO - 2018-03-26 14:58:37 --> Model Class Initialized
INFO - 2018-03-26 14:58:37 --> Model Class Initialized
INFO - 2018-03-26 14:58:37 --> Model Class Initialized
INFO - 2018-03-26 14:58:37 --> Model Class Initialized
INFO - 2018-03-26 14:58:37 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-26 14:58:37 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
ERROR - 2018-03-26 14:58:37 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 784
INFO - 2018-03-26 14:58:37 --> Final output sent to browser
DEBUG - 2018-03-26 14:58:37 --> Total execution time: 0.3414
INFO - 2018-03-26 09:29:09 --> Config Class Initialized
INFO - 2018-03-26 09:29:09 --> Hooks Class Initialized
INFO - 2018-03-26 09:29:09 --> Config Class Initialized
INFO - 2018-03-26 09:29:09 --> Hooks Class Initialized
DEBUG - 2018-03-26 09:29:09 --> UTF-8 Support Enabled
INFO - 2018-03-26 09:29:09 --> Utf8 Class Initialized
DEBUG - 2018-03-26 09:29:09 --> UTF-8 Support Enabled
INFO - 2018-03-26 09:29:09 --> Utf8 Class Initialized
INFO - 2018-03-26 09:29:09 --> URI Class Initialized
INFO - 2018-03-26 09:29:09 --> URI Class Initialized
INFO - 2018-03-26 09:29:09 --> Router Class Initialized
INFO - 2018-03-26 09:29:09 --> Router Class Initialized
INFO - 2018-03-26 09:29:09 --> Output Class Initialized
INFO - 2018-03-26 09:29:09 --> Output Class Initialized
INFO - 2018-03-26 09:29:09 --> Security Class Initialized
INFO - 2018-03-26 09:29:09 --> Security Class Initialized
DEBUG - 2018-03-26 09:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 09:29:09 --> Input Class Initialized
INFO - 2018-03-26 09:29:09 --> Language Class Initialized
DEBUG - 2018-03-26 09:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 09:29:09 --> Input Class Initialized
INFO - 2018-03-26 09:29:09 --> Config Class Initialized
INFO - 2018-03-26 09:29:09 --> Config Class Initialized
INFO - 2018-03-26 09:29:09 --> Hooks Class Initialized
INFO - 2018-03-26 09:29:09 --> Hooks Class Initialized
INFO - 2018-03-26 09:29:09 --> Language Class Initialized
DEBUG - 2018-03-26 09:29:09 --> UTF-8 Support Enabled
INFO - 2018-03-26 09:29:09 --> Utf8 Class Initialized
DEBUG - 2018-03-26 09:29:09 --> UTF-8 Support Enabled
INFO - 2018-03-26 09:29:09 --> Utf8 Class Initialized
INFO - 2018-03-26 09:29:09 --> URI Class Initialized
INFO - 2018-03-26 09:29:09 --> URI Class Initialized
INFO - 2018-03-26 09:29:09 --> Router Class Initialized
INFO - 2018-03-26 09:29:09 --> Router Class Initialized
INFO - 2018-03-26 09:29:09 --> Output Class Initialized
INFO - 2018-03-26 09:29:09 --> Output Class Initialized
INFO - 2018-03-26 09:29:09 --> Security Class Initialized
INFO - 2018-03-26 09:29:09 --> Security Class Initialized
DEBUG - 2018-03-26 09:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 09:29:09 --> Input Class Initialized
DEBUG - 2018-03-26 09:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 09:29:09 --> Input Class Initialized
INFO - 2018-03-26 09:29:09 --> Language Class Initialized
INFO - 2018-03-26 09:29:09 --> Config Class Initialized
INFO - 2018-03-26 09:29:09 --> Loader Class Initialized
INFO - 2018-03-26 09:29:09 --> Language Class Initialized
INFO - 2018-03-26 09:29:09 --> Language Class Initialized
INFO - 2018-03-26 09:29:09 --> Language Class Initialized
INFO - 2018-03-26 09:29:09 --> Config Class Initialized
INFO - 2018-03-26 09:29:09 --> Loader Class Initialized
INFO - 2018-03-26 14:59:09 --> Helper loaded: url_helper
INFO - 2018-03-26 14:59:09 --> Helper loaded: url_helper
INFO - 2018-03-26 14:59:09 --> Helper loaded: notification_helper
INFO - 2018-03-26 14:59:09 --> Helper loaded: settings_helper
INFO - 2018-03-26 14:59:09 --> Helper loaded: notification_helper
INFO - 2018-03-26 14:59:09 --> Helper loaded: settings_helper
INFO - 2018-03-26 14:59:09 --> Helper loaded: permission_helper
INFO - 2018-03-26 14:59:09 --> Helper loaded: users_helper
INFO - 2018-03-26 14:59:09 --> Helper loaded: permission_helper
INFO - 2018-03-26 14:59:09 --> Helper loaded: users_helper
INFO - 2018-03-26 09:29:09 --> Language Class Initialized
INFO - 2018-03-26 09:29:09 --> Config Class Initialized
INFO - 2018-03-26 09:29:09 --> Loader Class Initialized
INFO - 2018-03-26 14:59:09 --> Helper loaded: url_helper
INFO - 2018-03-26 14:59:09 --> Helper loaded: notification_helper
INFO - 2018-03-26 14:59:09 --> Helper loaded: settings_helper
INFO - 2018-03-26 14:59:09 --> Database Driver Class Initialized
INFO - 2018-03-26 14:59:09 --> Helper loaded: permission_helper
INFO - 2018-03-26 09:29:09 --> Language Class Initialized
INFO - 2018-03-26 14:59:09 --> Database Driver Class Initialized
INFO - 2018-03-26 09:29:09 --> Config Class Initialized
INFO - 2018-03-26 09:29:09 --> Loader Class Initialized
INFO - 2018-03-26 14:59:09 --> Helper loaded: users_helper
INFO - 2018-03-26 14:59:09 --> Helper loaded: url_helper
INFO - 2018-03-26 14:59:09 --> Helper loaded: notification_helper
INFO - 2018-03-26 14:59:09 --> Helper loaded: settings_helper
DEBUG - 2018-03-26 14:59:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 14:59:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 14:59:09 --> Helper loaded: permission_helper
DEBUG - 2018-03-26 14:59:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 14:59:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 14:59:09 --> Helper loaded: users_helper
INFO - 2018-03-26 14:59:09 --> Helper loaded: form_helper
INFO - 2018-03-26 14:59:09 --> Form Validation Class Initialized
INFO - 2018-03-26 14:59:09 --> Controller Class Initialized
INFO - 2018-03-26 14:59:09 --> Helper loaded: form_helper
INFO - 2018-03-26 14:59:09 --> Form Validation Class Initialized
INFO - 2018-03-26 14:59:09 --> Controller Class Initialized
INFO - 2018-03-26 14:59:09 --> Database Driver Class Initialized
DEBUG - 2018-03-26 14:59:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 14:59:09 --> Database Driver Class Initialized
INFO - 2018-03-26 14:59:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 14:59:09 --> Model Class Initialized
INFO - 2018-03-26 14:59:09 --> Model Class Initialized
INFO - 2018-03-26 14:59:09 --> Helper loaded: inflector_helper
INFO - 2018-03-26 14:59:09 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 14:59:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-26 14:59:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 14:59:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-03-26 14:59:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 14:59:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 14:59:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 14:59:09 --> Helper loaded: form_helper
INFO - 2018-03-26 14:59:09 --> Form Validation Class Initialized
INFO - 2018-03-26 14:59:09 --> Controller Class Initialized
INFO - 2018-03-26 14:59:09 --> Model Class Initialized
INFO - 2018-03-26 14:59:09 --> Model Class Initialized
INFO - 2018-03-26 14:59:09 --> Model Class Initialized
INFO - 2018-03-26 14:59:09 --> Model Class Initialized
INFO - 2018-03-26 14:59:09 --> Model Class Initialized
INFO - 2018-03-26 14:59:09 --> Model Class Initialized
INFO - 2018-03-26 14:59:09 --> Model Class Initialized
INFO - 2018-03-26 14:59:09 --> Model Class Initialized
INFO - 2018-03-26 14:59:09 --> Model Class Initialized
INFO - 2018-03-26 14:59:09 --> Model Class Initialized
INFO - 2018-03-26 14:59:09 --> Model Class Initialized
INFO - 2018-03-26 14:59:09 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 14:59:09 --> Model Class Initialized
INFO - 2018-03-26 14:59:09 --> Model Class Initialized
INFO - 2018-03-26 14:59:09 --> Model Class Initialized
INFO - 2018-03-26 14:59:09 --> Model Class Initialized
INFO - 2018-03-26 14:59:09 --> Model Class Initialized
INFO - 2018-03-26 14:59:09 --> Model Class Initialized
INFO - 2018-03-26 14:59:09 --> Final output sent to browser
DEBUG - 2018-03-26 14:59:09 --> Total execution time: 0.3506
INFO - 2018-03-26 14:59:09 --> Helper loaded: form_helper
INFO - 2018-03-26 14:59:09 --> Form Validation Class Initialized
INFO - 2018-03-26 14:59:09 --> Controller Class Initialized
INFO - 2018-03-26 14:59:09 --> Model Class Initialized
INFO - 2018-03-26 14:59:09 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 14:59:09 --> Model Class Initialized
INFO - 2018-03-26 14:59:09 --> Model Class Initialized
INFO - 2018-03-26 14:59:09 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 14:59:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 14:59:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 14:59:09 --> Model Class Initialized
INFO - 2018-03-26 14:59:09 --> Model Class Initialized
INFO - 2018-03-26 14:59:09 --> Model Class Initialized
INFO - 2018-03-26 14:59:09 --> Model Class Initialized
INFO - 2018-03-26 14:59:09 --> Model Class Initialized
INFO - 2018-03-26 14:59:09 --> Model Class Initialized
INFO - 2018-03-26 14:59:09 --> Model Class Initialized
INFO - 2018-03-26 14:59:09 --> Model Class Initialized
INFO - 2018-03-26 14:59:09 --> Model Class Initialized
INFO - 2018-03-26 14:59:09 --> Model Class Initialized
INFO - 2018-03-26 14:59:09 --> Model Class Initialized
INFO - 2018-03-26 14:59:09 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 14:59:09 --> Model Class Initialized
INFO - 2018-03-26 14:59:09 --> Model Class Initialized
INFO - 2018-03-26 14:59:09 --> Final output sent to browser
DEBUG - 2018-03-26 14:59:09 --> Total execution time: 0.4179
INFO - 2018-03-26 14:59:09 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 14:59:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 14:59:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 14:59:09 --> Model Class Initialized
INFO - 2018-03-26 14:59:09 --> Model Class Initialized
INFO - 2018-03-26 14:59:10 --> Model Class Initialized
INFO - 2018-03-26 14:59:10 --> Model Class Initialized
INFO - 2018-03-26 14:59:10 --> Model Class Initialized
INFO - 2018-03-26 14:59:10 --> Model Class Initialized
INFO - 2018-03-26 14:59:10 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 14:59:10 --> Final output sent to browser
DEBUG - 2018-03-26 14:59:10 --> Total execution time: 0.3936
INFO - 2018-03-26 14:59:10 --> Final output sent to browser
DEBUG - 2018-03-26 14:59:10 --> Total execution time: 0.4505
INFO - 2018-03-26 09:29:10 --> Config Class Initialized
INFO - 2018-03-26 09:29:10 --> Hooks Class Initialized
DEBUG - 2018-03-26 09:29:10 --> UTF-8 Support Enabled
INFO - 2018-03-26 09:29:10 --> Utf8 Class Initialized
INFO - 2018-03-26 09:29:10 --> URI Class Initialized
INFO - 2018-03-26 09:29:10 --> Router Class Initialized
INFO - 2018-03-26 09:29:10 --> Output Class Initialized
INFO - 2018-03-26 09:29:10 --> Security Class Initialized
DEBUG - 2018-03-26 09:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 09:29:11 --> Input Class Initialized
INFO - 2018-03-26 09:29:11 --> Language Class Initialized
INFO - 2018-03-26 09:29:11 --> Language Class Initialized
INFO - 2018-03-26 09:29:11 --> Config Class Initialized
INFO - 2018-03-26 09:29:11 --> Loader Class Initialized
INFO - 2018-03-26 14:59:11 --> Helper loaded: url_helper
INFO - 2018-03-26 14:59:11 --> Helper loaded: notification_helper
INFO - 2018-03-26 14:59:11 --> Helper loaded: settings_helper
INFO - 2018-03-26 14:59:11 --> Helper loaded: permission_helper
INFO - 2018-03-26 14:59:11 --> Helper loaded: users_helper
INFO - 2018-03-26 14:59:12 --> Database Driver Class Initialized
DEBUG - 2018-03-26 14:59:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 14:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 14:59:12 --> Helper loaded: form_helper
INFO - 2018-03-26 14:59:12 --> Form Validation Class Initialized
INFO - 2018-03-26 14:59:12 --> Controller Class Initialized
INFO - 2018-03-26 14:59:12 --> Model Class Initialized
INFO - 2018-03-26 14:59:12 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 14:59:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 14:59:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 14:59:12 --> Model Class Initialized
INFO - 2018-03-26 14:59:12 --> Model Class Initialized
INFO - 2018-03-26 14:59:12 --> Model Class Initialized
INFO - 2018-03-26 14:59:12 --> Model Class Initialized
INFO - 2018-03-26 14:59:12 --> Model Class Initialized
INFO - 2018-03-26 14:59:12 --> Model Class Initialized
INFO - 2018-03-26 14:59:12 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 14:59:12 --> Model Class Initialized
INFO - 2018-03-26 14:59:12 --> Final output sent to browser
DEBUG - 2018-03-26 14:59:12 --> Total execution time: 1.8529
INFO - 2018-03-26 09:29:12 --> Config Class Initialized
INFO - 2018-03-26 09:29:12 --> Hooks Class Initialized
DEBUG - 2018-03-26 09:29:12 --> UTF-8 Support Enabled
INFO - 2018-03-26 09:29:12 --> Utf8 Class Initialized
INFO - 2018-03-26 09:29:12 --> URI Class Initialized
INFO - 2018-03-26 09:29:12 --> Router Class Initialized
INFO - 2018-03-26 09:29:12 --> Output Class Initialized
INFO - 2018-03-26 09:29:13 --> Security Class Initialized
DEBUG - 2018-03-26 09:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 09:29:13 --> Input Class Initialized
INFO - 2018-03-26 09:29:13 --> Language Class Initialized
INFO - 2018-03-26 09:29:13 --> Language Class Initialized
INFO - 2018-03-26 09:29:13 --> Config Class Initialized
INFO - 2018-03-26 09:29:13 --> Loader Class Initialized
INFO - 2018-03-26 14:59:13 --> Helper loaded: url_helper
INFO - 2018-03-26 14:59:13 --> Helper loaded: notification_helper
INFO - 2018-03-26 14:59:13 --> Helper loaded: settings_helper
INFO - 2018-03-26 14:59:13 --> Helper loaded: permission_helper
INFO - 2018-03-26 14:59:13 --> Helper loaded: users_helper
INFO - 2018-03-26 14:59:14 --> Database Driver Class Initialized
DEBUG - 2018-03-26 14:59:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 14:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 14:59:14 --> Helper loaded: form_helper
INFO - 2018-03-26 14:59:14 --> Form Validation Class Initialized
INFO - 2018-03-26 14:59:14 --> Controller Class Initialized
INFO - 2018-03-26 14:59:14 --> Model Class Initialized
INFO - 2018-03-26 14:59:14 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 14:59:14 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 14:59:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 14:59:14 --> Model Class Initialized
INFO - 2018-03-26 14:59:14 --> Model Class Initialized
INFO - 2018-03-26 14:59:14 --> Model Class Initialized
INFO - 2018-03-26 14:59:14 --> Model Class Initialized
INFO - 2018-03-26 14:59:14 --> Model Class Initialized
INFO - 2018-03-26 14:59:14 --> Model Class Initialized
INFO - 2018-03-26 14:59:14 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 14:59:14 --> Model Class Initialized
INFO - 2018-03-26 14:59:14 --> Final output sent to browser
DEBUG - 2018-03-26 14:59:14 --> Total execution time: 2.0062
INFO - 2018-03-26 09:29:18 --> Config Class Initialized
INFO - 2018-03-26 09:29:18 --> Hooks Class Initialized
DEBUG - 2018-03-26 09:29:18 --> UTF-8 Support Enabled
INFO - 2018-03-26 09:29:18 --> Utf8 Class Initialized
INFO - 2018-03-26 09:29:18 --> URI Class Initialized
INFO - 2018-03-26 09:29:18 --> Router Class Initialized
INFO - 2018-03-26 09:29:18 --> Output Class Initialized
INFO - 2018-03-26 09:29:19 --> Security Class Initialized
DEBUG - 2018-03-26 09:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 09:29:19 --> Input Class Initialized
INFO - 2018-03-26 09:29:19 --> Language Class Initialized
INFO - 2018-03-26 09:29:19 --> Language Class Initialized
INFO - 2018-03-26 09:29:19 --> Config Class Initialized
INFO - 2018-03-26 09:29:19 --> Loader Class Initialized
INFO - 2018-03-26 14:59:19 --> Helper loaded: url_helper
INFO - 2018-03-26 14:59:19 --> Helper loaded: notification_helper
INFO - 2018-03-26 14:59:19 --> Helper loaded: settings_helper
INFO - 2018-03-26 14:59:19 --> Helper loaded: permission_helper
INFO - 2018-03-26 14:59:19 --> Helper loaded: users_helper
INFO - 2018-03-26 14:59:19 --> Database Driver Class Initialized
DEBUG - 2018-03-26 14:59:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 14:59:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 14:59:19 --> Helper loaded: form_helper
INFO - 2018-03-26 14:59:19 --> Form Validation Class Initialized
INFO - 2018-03-26 14:59:19 --> Controller Class Initialized
INFO - 2018-03-26 14:59:20 --> Model Class Initialized
INFO - 2018-03-26 14:59:20 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 14:59:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 14:59:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 14:59:20 --> Model Class Initialized
INFO - 2018-03-26 14:59:20 --> Model Class Initialized
INFO - 2018-03-26 14:59:20 --> Model Class Initialized
INFO - 2018-03-26 14:59:20 --> Model Class Initialized
INFO - 2018-03-26 14:59:20 --> Model Class Initialized
INFO - 2018-03-26 14:59:20 --> Model Class Initialized
INFO - 2018-03-26 14:59:20 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-26 14:59:20 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-26 14:59:20 --> Final output sent to browser
DEBUG - 2018-03-26 14:59:20 --> Total execution time: 2.2699
INFO - 2018-03-26 09:29:21 --> Config Class Initialized
INFO - 2018-03-26 09:29:21 --> Hooks Class Initialized
DEBUG - 2018-03-26 09:29:21 --> UTF-8 Support Enabled
INFO - 2018-03-26 09:29:21 --> Utf8 Class Initialized
INFO - 2018-03-26 09:29:21 --> URI Class Initialized
INFO - 2018-03-26 09:29:21 --> Router Class Initialized
INFO - 2018-03-26 09:29:21 --> Output Class Initialized
INFO - 2018-03-26 09:29:21 --> Security Class Initialized
DEBUG - 2018-03-26 09:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 09:29:21 --> Input Class Initialized
INFO - 2018-03-26 09:29:21 --> Language Class Initialized
INFO - 2018-03-26 09:29:21 --> Language Class Initialized
INFO - 2018-03-26 09:29:21 --> Config Class Initialized
INFO - 2018-03-26 09:29:21 --> Loader Class Initialized
INFO - 2018-03-26 14:59:21 --> Helper loaded: url_helper
INFO - 2018-03-26 14:59:21 --> Helper loaded: notification_helper
INFO - 2018-03-26 14:59:21 --> Helper loaded: settings_helper
INFO - 2018-03-26 14:59:21 --> Helper loaded: permission_helper
INFO - 2018-03-26 14:59:21 --> Helper loaded: users_helper
INFO - 2018-03-26 14:59:21 --> Database Driver Class Initialized
DEBUG - 2018-03-26 14:59:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 14:59:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 14:59:21 --> Helper loaded: form_helper
INFO - 2018-03-26 14:59:21 --> Form Validation Class Initialized
INFO - 2018-03-26 14:59:21 --> Controller Class Initialized
INFO - 2018-03-26 14:59:21 --> Model Class Initialized
INFO - 2018-03-26 14:59:21 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 14:59:21 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 14:59:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 14:59:21 --> Model Class Initialized
INFO - 2018-03-26 14:59:21 --> Model Class Initialized
INFO - 2018-03-26 14:59:21 --> Model Class Initialized
INFO - 2018-03-26 14:59:21 --> Model Class Initialized
INFO - 2018-03-26 14:59:21 --> Model Class Initialized
INFO - 2018-03-26 14:59:21 --> Model Class Initialized
INFO - 2018-03-26 14:59:21 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-26 14:59:21 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-26 14:59:21 --> Final output sent to browser
DEBUG - 2018-03-26 14:59:21 --> Total execution time: 0.2508
INFO - 2018-03-26 09:29:25 --> Config Class Initialized
INFO - 2018-03-26 09:29:25 --> Hooks Class Initialized
DEBUG - 2018-03-26 09:29:25 --> UTF-8 Support Enabled
INFO - 2018-03-26 09:29:25 --> Utf8 Class Initialized
INFO - 2018-03-26 09:29:25 --> URI Class Initialized
INFO - 2018-03-26 09:29:25 --> Router Class Initialized
INFO - 2018-03-26 09:29:25 --> Output Class Initialized
INFO - 2018-03-26 09:29:25 --> Security Class Initialized
DEBUG - 2018-03-26 09:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 09:29:25 --> Input Class Initialized
INFO - 2018-03-26 09:29:25 --> Language Class Initialized
INFO - 2018-03-26 09:29:26 --> Language Class Initialized
INFO - 2018-03-26 09:29:26 --> Config Class Initialized
INFO - 2018-03-26 09:29:26 --> Loader Class Initialized
INFO - 2018-03-26 14:59:26 --> Helper loaded: url_helper
INFO - 2018-03-26 14:59:26 --> Helper loaded: notification_helper
INFO - 2018-03-26 14:59:26 --> Helper loaded: settings_helper
INFO - 2018-03-26 14:59:26 --> Helper loaded: permission_helper
INFO - 2018-03-26 14:59:26 --> Helper loaded: users_helper
INFO - 2018-03-26 14:59:27 --> Database Driver Class Initialized
DEBUG - 2018-03-26 14:59:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 14:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 14:59:27 --> Helper loaded: form_helper
INFO - 2018-03-26 14:59:27 --> Form Validation Class Initialized
INFO - 2018-03-26 14:59:27 --> Controller Class Initialized
INFO - 2018-03-26 14:59:27 --> Model Class Initialized
INFO - 2018-03-26 14:59:27 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 14:59:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 14:59:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 14:59:27 --> Model Class Initialized
INFO - 2018-03-26 14:59:27 --> Model Class Initialized
INFO - 2018-03-26 14:59:27 --> Model Class Initialized
INFO - 2018-03-26 14:59:27 --> Model Class Initialized
INFO - 2018-03-26 14:59:27 --> Model Class Initialized
INFO - 2018-03-26 14:59:27 --> Model Class Initialized
INFO - 2018-03-26 14:59:27 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 14:59:27 --> Model Class Initialized
INFO - 2018-03-26 14:59:27 --> Final output sent to browser
DEBUG - 2018-03-26 14:59:27 --> Total execution time: 1.7410
INFO - 2018-03-26 09:29:28 --> Config Class Initialized
INFO - 2018-03-26 09:29:28 --> Hooks Class Initialized
DEBUG - 2018-03-26 09:29:28 --> UTF-8 Support Enabled
INFO - 2018-03-26 09:29:28 --> Utf8 Class Initialized
INFO - 2018-03-26 09:29:28 --> URI Class Initialized
INFO - 2018-03-26 09:29:29 --> Router Class Initialized
INFO - 2018-03-26 09:29:29 --> Output Class Initialized
INFO - 2018-03-26 09:29:29 --> Security Class Initialized
DEBUG - 2018-03-26 09:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 09:29:29 --> Input Class Initialized
INFO - 2018-03-26 09:29:29 --> Language Class Initialized
INFO - 2018-03-26 09:29:30 --> Language Class Initialized
INFO - 2018-03-26 09:29:30 --> Config Class Initialized
INFO - 2018-03-26 09:29:30 --> Loader Class Initialized
INFO - 2018-03-26 14:59:30 --> Helper loaded: url_helper
INFO - 2018-03-26 14:59:30 --> Helper loaded: notification_helper
INFO - 2018-03-26 14:59:30 --> Helper loaded: settings_helper
INFO - 2018-03-26 14:59:30 --> Helper loaded: permission_helper
INFO - 2018-03-26 14:59:30 --> Helper loaded: users_helper
INFO - 2018-03-26 14:59:30 --> Database Driver Class Initialized
DEBUG - 2018-03-26 14:59:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 14:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 14:59:30 --> Helper loaded: form_helper
INFO - 2018-03-26 14:59:30 --> Form Validation Class Initialized
INFO - 2018-03-26 14:59:30 --> Controller Class Initialized
INFO - 2018-03-26 14:59:30 --> Model Class Initialized
INFO - 2018-03-26 14:59:30 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 14:59:30 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 14:59:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 14:59:30 --> Model Class Initialized
INFO - 2018-03-26 14:59:30 --> Model Class Initialized
INFO - 2018-03-26 14:59:30 --> Model Class Initialized
INFO - 2018-03-26 14:59:30 --> Model Class Initialized
INFO - 2018-03-26 14:59:30 --> Model Class Initialized
INFO - 2018-03-26 14:59:30 --> Model Class Initialized
INFO - 2018-03-26 14:59:30 --> Model Class Initialized
INFO - 2018-03-26 14:59:30 --> Model Class Initialized
INFO - 2018-03-26 14:59:30 --> Model Class Initialized
INFO - 2018-03-26 14:59:30 --> Model Class Initialized
INFO - 2018-03-26 14:59:30 --> Model Class Initialized
INFO - 2018-03-26 14:59:30 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 14:59:30 --> Model Class Initialized
INFO - 2018-03-26 14:59:30 --> Final output sent to browser
DEBUG - 2018-03-26 14:59:30 --> Total execution time: 2.7768
INFO - 2018-03-26 09:29:31 --> Config Class Initialized
INFO - 2018-03-26 09:29:31 --> Hooks Class Initialized
DEBUG - 2018-03-26 09:29:31 --> UTF-8 Support Enabled
INFO - 2018-03-26 09:29:31 --> Utf8 Class Initialized
INFO - 2018-03-26 09:29:31 --> URI Class Initialized
INFO - 2018-03-26 09:29:31 --> Router Class Initialized
INFO - 2018-03-26 09:29:31 --> Output Class Initialized
INFO - 2018-03-26 09:29:31 --> Security Class Initialized
DEBUG - 2018-03-26 09:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 09:29:31 --> Input Class Initialized
INFO - 2018-03-26 09:29:31 --> Language Class Initialized
INFO - 2018-03-26 09:29:31 --> Language Class Initialized
INFO - 2018-03-26 09:29:31 --> Config Class Initialized
INFO - 2018-03-26 09:29:31 --> Loader Class Initialized
INFO - 2018-03-26 14:59:31 --> Helper loaded: url_helper
INFO - 2018-03-26 14:59:31 --> Helper loaded: notification_helper
INFO - 2018-03-26 14:59:31 --> Helper loaded: settings_helper
INFO - 2018-03-26 14:59:31 --> Helper loaded: permission_helper
INFO - 2018-03-26 14:59:31 --> Helper loaded: users_helper
INFO - 2018-03-26 14:59:31 --> Database Driver Class Initialized
DEBUG - 2018-03-26 14:59:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 14:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 14:59:31 --> Helper loaded: form_helper
INFO - 2018-03-26 14:59:31 --> Form Validation Class Initialized
INFO - 2018-03-26 14:59:31 --> Controller Class Initialized
INFO - 2018-03-26 14:59:31 --> Model Class Initialized
INFO - 2018-03-26 14:59:31 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 14:59:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 14:59:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 14:59:31 --> Model Class Initialized
INFO - 2018-03-26 14:59:31 --> Model Class Initialized
INFO - 2018-03-26 14:59:31 --> Model Class Initialized
INFO - 2018-03-26 14:59:31 --> Model Class Initialized
INFO - 2018-03-26 14:59:31 --> Model Class Initialized
INFO - 2018-03-26 14:59:31 --> Model Class Initialized
INFO - 2018-03-26 14:59:31 --> Model Class Initialized
INFO - 2018-03-26 14:59:31 --> Model Class Initialized
INFO - 2018-03-26 14:59:31 --> Model Class Initialized
INFO - 2018-03-26 14:59:31 --> Model Class Initialized
INFO - 2018-03-26 14:59:31 --> Model Class Initialized
INFO - 2018-03-26 14:59:31 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 14:59:31 --> Model Class Initialized
INFO - 2018-03-26 14:59:31 --> Final output sent to browser
DEBUG - 2018-03-26 14:59:31 --> Total execution time: 0.2071
INFO - 2018-03-26 09:29:33 --> Config Class Initialized
INFO - 2018-03-26 09:29:33 --> Hooks Class Initialized
DEBUG - 2018-03-26 09:29:33 --> UTF-8 Support Enabled
INFO - 2018-03-26 09:29:33 --> Utf8 Class Initialized
INFO - 2018-03-26 09:29:33 --> URI Class Initialized
INFO - 2018-03-26 09:29:33 --> Router Class Initialized
INFO - 2018-03-26 09:29:33 --> Output Class Initialized
INFO - 2018-03-26 09:29:33 --> Security Class Initialized
DEBUG - 2018-03-26 09:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 09:29:33 --> Input Class Initialized
INFO - 2018-03-26 09:29:33 --> Config Class Initialized
INFO - 2018-03-26 09:29:33 --> Hooks Class Initialized
INFO - 2018-03-26 09:29:33 --> Language Class Initialized
DEBUG - 2018-03-26 09:29:33 --> UTF-8 Support Enabled
INFO - 2018-03-26 09:29:33 --> Utf8 Class Initialized
INFO - 2018-03-26 09:29:33 --> URI Class Initialized
INFO - 2018-03-26 09:29:33 --> Router Class Initialized
INFO - 2018-03-26 09:29:33 --> Output Class Initialized
INFO - 2018-03-26 09:29:33 --> Security Class Initialized
DEBUG - 2018-03-26 09:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 09:29:33 --> Input Class Initialized
INFO - 2018-03-26 09:29:33 --> Language Class Initialized
INFO - 2018-03-26 09:29:33 --> Language Class Initialized
INFO - 2018-03-26 09:29:33 --> Config Class Initialized
INFO - 2018-03-26 09:29:33 --> Loader Class Initialized
INFO - 2018-03-26 14:59:33 --> Helper loaded: url_helper
INFO - 2018-03-26 14:59:33 --> Helper loaded: notification_helper
INFO - 2018-03-26 14:59:33 --> Helper loaded: settings_helper
INFO - 2018-03-26 14:59:33 --> Helper loaded: permission_helper
INFO - 2018-03-26 14:59:33 --> Helper loaded: users_helper
INFO - 2018-03-26 14:59:33 --> Database Driver Class Initialized
DEBUG - 2018-03-26 14:59:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 14:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 14:59:33 --> Helper loaded: form_helper
INFO - 2018-03-26 14:59:33 --> Form Validation Class Initialized
INFO - 2018-03-26 14:59:33 --> Controller Class Initialized
INFO - 2018-03-26 14:59:33 --> Model Class Initialized
INFO - 2018-03-26 14:59:33 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 14:59:33 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 14:59:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 14:59:33 --> Model Class Initialized
INFO - 2018-03-26 14:59:33 --> Model Class Initialized
INFO - 2018-03-26 14:59:33 --> Model Class Initialized
INFO - 2018-03-26 14:59:33 --> Model Class Initialized
INFO - 2018-03-26 14:59:33 --> Model Class Initialized
INFO - 2018-03-26 14:59:33 --> Model Class Initialized
INFO - 2018-03-26 14:59:33 --> Model Class Initialized
INFO - 2018-03-26 14:59:33 --> Model Class Initialized
INFO - 2018-03-26 14:59:33 --> Model Class Initialized
INFO - 2018-03-26 14:59:33 --> Model Class Initialized
INFO - 2018-03-26 14:59:33 --> Model Class Initialized
INFO - 2018-03-26 14:59:33 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 14:59:33 --> Final output sent to browser
DEBUG - 2018-03-26 14:59:33 --> Total execution time: 0.1000
INFO - 2018-03-26 09:29:33 --> Language Class Initialized
INFO - 2018-03-26 09:29:33 --> Config Class Initialized
INFO - 2018-03-26 09:29:33 --> Loader Class Initialized
INFO - 2018-03-26 14:59:33 --> Helper loaded: url_helper
INFO - 2018-03-26 14:59:33 --> Helper loaded: notification_helper
INFO - 2018-03-26 14:59:33 --> Helper loaded: settings_helper
INFO - 2018-03-26 14:59:33 --> Helper loaded: permission_helper
INFO - 2018-03-26 14:59:33 --> Helper loaded: users_helper
INFO - 2018-03-26 14:59:34 --> Database Driver Class Initialized
DEBUG - 2018-03-26 14:59:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 14:59:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 14:59:34 --> Helper loaded: form_helper
INFO - 2018-03-26 14:59:34 --> Form Validation Class Initialized
INFO - 2018-03-26 14:59:34 --> Controller Class Initialized
INFO - 2018-03-26 14:59:34 --> Model Class Initialized
INFO - 2018-03-26 14:59:34 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 14:59:34 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 14:59:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 14:59:34 --> Model Class Initialized
INFO - 2018-03-26 14:59:34 --> Model Class Initialized
INFO - 2018-03-26 14:59:34 --> Model Class Initialized
INFO - 2018-03-26 14:59:34 --> Model Class Initialized
INFO - 2018-03-26 14:59:34 --> Model Class Initialized
INFO - 2018-03-26 14:59:34 --> Model Class Initialized
INFO - 2018-03-26 14:59:34 --> Model Class Initialized
INFO - 2018-03-26 14:59:34 --> Model Class Initialized
INFO - 2018-03-26 14:59:34 --> Model Class Initialized
INFO - 2018-03-26 14:59:34 --> Model Class Initialized
INFO - 2018-03-26 14:59:34 --> Model Class Initialized
INFO - 2018-03-26 14:59:34 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 14:59:34 --> Model Class Initialized
INFO - 2018-03-26 14:59:34 --> Final output sent to browser
DEBUG - 2018-03-26 14:59:34 --> Total execution time: 0.7923
INFO - 2018-03-26 09:29:36 --> Config Class Initialized
INFO - 2018-03-26 09:29:36 --> Hooks Class Initialized
DEBUG - 2018-03-26 09:29:36 --> UTF-8 Support Enabled
INFO - 2018-03-26 09:29:36 --> Utf8 Class Initialized
INFO - 2018-03-26 09:29:36 --> URI Class Initialized
INFO - 2018-03-26 09:29:36 --> Router Class Initialized
INFO - 2018-03-26 09:29:36 --> Output Class Initialized
INFO - 2018-03-26 09:29:36 --> Security Class Initialized
DEBUG - 2018-03-26 09:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 09:29:36 --> Input Class Initialized
INFO - 2018-03-26 09:29:36 --> Language Class Initialized
INFO - 2018-03-26 09:29:36 --> Config Class Initialized
INFO - 2018-03-26 09:29:36 --> Hooks Class Initialized
DEBUG - 2018-03-26 09:29:36 --> UTF-8 Support Enabled
INFO - 2018-03-26 09:29:36 --> Utf8 Class Initialized
INFO - 2018-03-26 09:29:36 --> Language Class Initialized
INFO - 2018-03-26 09:29:36 --> Config Class Initialized
INFO - 2018-03-26 09:29:36 --> Loader Class Initialized
INFO - 2018-03-26 09:29:36 --> URI Class Initialized
INFO - 2018-03-26 14:59:36 --> Helper loaded: url_helper
INFO - 2018-03-26 14:59:36 --> Helper loaded: notification_helper
INFO - 2018-03-26 09:29:36 --> Router Class Initialized
INFO - 2018-03-26 14:59:36 --> Helper loaded: settings_helper
INFO - 2018-03-26 14:59:36 --> Helper loaded: permission_helper
INFO - 2018-03-26 14:59:36 --> Helper loaded: users_helper
INFO - 2018-03-26 09:29:36 --> Output Class Initialized
INFO - 2018-03-26 09:29:36 --> Security Class Initialized
DEBUG - 2018-03-26 09:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 09:29:36 --> Input Class Initialized
INFO - 2018-03-26 09:29:36 --> Language Class Initialized
INFO - 2018-03-26 09:29:36 --> Language Class Initialized
INFO - 2018-03-26 09:29:36 --> Config Class Initialized
INFO - 2018-03-26 09:29:36 --> Loader Class Initialized
INFO - 2018-03-26 14:59:36 --> Helper loaded: url_helper
INFO - 2018-03-26 14:59:36 --> Helper loaded: notification_helper
INFO - 2018-03-26 14:59:36 --> Helper loaded: settings_helper
INFO - 2018-03-26 14:59:36 --> Helper loaded: permission_helper
INFO - 2018-03-26 14:59:36 --> Helper loaded: users_helper
INFO - 2018-03-26 14:59:36 --> Database Driver Class Initialized
DEBUG - 2018-03-26 14:59:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 14:59:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 14:59:36 --> Helper loaded: form_helper
INFO - 2018-03-26 14:59:36 --> Form Validation Class Initialized
INFO - 2018-03-26 14:59:36 --> Controller Class Initialized
INFO - 2018-03-26 14:59:36 --> Database Driver Class Initialized
INFO - 2018-03-26 14:59:36 --> Model Class Initialized
INFO - 2018-03-26 14:59:36 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 14:59:36 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 14:59:36 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 14:59:36 --> Model Class Initialized
DEBUG - 2018-03-26 14:59:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 14:59:36 --> Model Class Initialized
INFO - 2018-03-26 14:59:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 14:59:36 --> Model Class Initialized
INFO - 2018-03-26 14:59:36 --> Model Class Initialized
INFO - 2018-03-26 14:59:36 --> Model Class Initialized
INFO - 2018-03-26 14:59:36 --> Model Class Initialized
INFO - 2018-03-26 14:59:36 --> Model Class Initialized
INFO - 2018-03-26 14:59:36 --> Model Class Initialized
INFO - 2018-03-26 14:59:36 --> Model Class Initialized
INFO - 2018-03-26 14:59:36 --> Model Class Initialized
INFO - 2018-03-26 14:59:36 --> Model Class Initialized
INFO - 2018-03-26 14:59:36 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 14:59:36 --> Helper loaded: form_helper
INFO - 2018-03-26 14:59:36 --> Form Validation Class Initialized
INFO - 2018-03-26 14:59:36 --> Controller Class Initialized
INFO - 2018-03-26 14:59:36 --> Final output sent to browser
DEBUG - 2018-03-26 14:59:36 --> Total execution time: 0.3067
INFO - 2018-03-26 14:59:36 --> Model Class Initialized
INFO - 2018-03-26 14:59:36 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 14:59:36 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 14:59:36 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 14:59:36 --> Model Class Initialized
INFO - 2018-03-26 14:59:36 --> Model Class Initialized
INFO - 2018-03-26 14:59:36 --> Model Class Initialized
INFO - 2018-03-26 14:59:36 --> Model Class Initialized
INFO - 2018-03-26 14:59:36 --> Model Class Initialized
INFO - 2018-03-26 14:59:36 --> Model Class Initialized
INFO - 2018-03-26 14:59:36 --> Model Class Initialized
INFO - 2018-03-26 14:59:36 --> Model Class Initialized
INFO - 2018-03-26 14:59:36 --> Model Class Initialized
INFO - 2018-03-26 14:59:36 --> Model Class Initialized
INFO - 2018-03-26 14:59:36 --> Model Class Initialized
INFO - 2018-03-26 14:59:36 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 14:59:36 --> Model Class Initialized
INFO - 2018-03-26 14:59:36 --> Final output sent to browser
DEBUG - 2018-03-26 14:59:36 --> Total execution time: 0.2712
INFO - 2018-03-26 09:29:39 --> Config Class Initialized
INFO - 2018-03-26 09:29:39 --> Hooks Class Initialized
DEBUG - 2018-03-26 09:29:39 --> UTF-8 Support Enabled
INFO - 2018-03-26 09:29:39 --> Utf8 Class Initialized
INFO - 2018-03-26 09:29:39 --> URI Class Initialized
INFO - 2018-03-26 09:29:39 --> Router Class Initialized
INFO - 2018-03-26 09:29:39 --> Output Class Initialized
INFO - 2018-03-26 09:29:39 --> Security Class Initialized
DEBUG - 2018-03-26 09:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 09:29:39 --> Input Class Initialized
INFO - 2018-03-26 09:29:39 --> Language Class Initialized
INFO - 2018-03-26 09:29:39 --> Language Class Initialized
INFO - 2018-03-26 09:29:39 --> Config Class Initialized
INFO - 2018-03-26 09:29:39 --> Loader Class Initialized
INFO - 2018-03-26 14:59:39 --> Helper loaded: url_helper
INFO - 2018-03-26 14:59:39 --> Helper loaded: notification_helper
INFO - 2018-03-26 14:59:39 --> Helper loaded: settings_helper
INFO - 2018-03-26 14:59:39 --> Helper loaded: permission_helper
INFO - 2018-03-26 14:59:39 --> Helper loaded: users_helper
INFO - 2018-03-26 14:59:39 --> Database Driver Class Initialized
DEBUG - 2018-03-26 14:59:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 14:59:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 14:59:39 --> Helper loaded: form_helper
INFO - 2018-03-26 14:59:39 --> Form Validation Class Initialized
INFO - 2018-03-26 14:59:39 --> Controller Class Initialized
INFO - 2018-03-26 14:59:39 --> Model Class Initialized
INFO - 2018-03-26 14:59:39 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 14:59:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 14:59:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 14:59:39 --> Model Class Initialized
INFO - 2018-03-26 14:59:39 --> Model Class Initialized
INFO - 2018-03-26 14:59:39 --> Model Class Initialized
INFO - 2018-03-26 14:59:39 --> Model Class Initialized
INFO - 2018-03-26 14:59:39 --> Model Class Initialized
INFO - 2018-03-26 14:59:39 --> Model Class Initialized
INFO - 2018-03-26 14:59:39 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-26 14:59:39 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-26 14:59:39 --> Final output sent to browser
DEBUG - 2018-03-26 14:59:39 --> Total execution time: 0.1648
INFO - 2018-03-26 09:29:41 --> Config Class Initialized
INFO - 2018-03-26 09:29:41 --> Hooks Class Initialized
DEBUG - 2018-03-26 09:29:41 --> UTF-8 Support Enabled
INFO - 2018-03-26 09:29:41 --> Utf8 Class Initialized
INFO - 2018-03-26 09:29:41 --> URI Class Initialized
INFO - 2018-03-26 09:29:42 --> Router Class Initialized
INFO - 2018-03-26 09:29:42 --> Output Class Initialized
INFO - 2018-03-26 09:29:42 --> Security Class Initialized
DEBUG - 2018-03-26 09:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 09:29:42 --> Input Class Initialized
INFO - 2018-03-26 09:29:42 --> Language Class Initialized
INFO - 2018-03-26 09:29:42 --> Language Class Initialized
INFO - 2018-03-26 09:29:42 --> Config Class Initialized
INFO - 2018-03-26 09:29:42 --> Loader Class Initialized
INFO - 2018-03-26 14:59:42 --> Helper loaded: url_helper
INFO - 2018-03-26 14:59:42 --> Helper loaded: notification_helper
INFO - 2018-03-26 14:59:42 --> Helper loaded: settings_helper
INFO - 2018-03-26 14:59:42 --> Helper loaded: permission_helper
INFO - 2018-03-26 14:59:42 --> Helper loaded: users_helper
INFO - 2018-03-26 09:29:42 --> Config Class Initialized
INFO - 2018-03-26 09:29:42 --> Hooks Class Initialized
DEBUG - 2018-03-26 09:29:42 --> UTF-8 Support Enabled
INFO - 2018-03-26 09:29:42 --> Utf8 Class Initialized
INFO - 2018-03-26 09:29:42 --> URI Class Initialized
INFO - 2018-03-26 09:29:42 --> Router Class Initialized
INFO - 2018-03-26 09:29:42 --> Output Class Initialized
INFO - 2018-03-26 09:29:42 --> Security Class Initialized
DEBUG - 2018-03-26 09:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 09:29:42 --> Input Class Initialized
INFO - 2018-03-26 09:29:42 --> Language Class Initialized
INFO - 2018-03-26 09:29:42 --> Config Class Initialized
INFO - 2018-03-26 09:29:42 --> Hooks Class Initialized
INFO - 2018-03-26 14:59:42 --> Database Driver Class Initialized
DEBUG - 2018-03-26 09:29:42 --> UTF-8 Support Enabled
INFO - 2018-03-26 09:29:42 --> Utf8 Class Initialized
DEBUG - 2018-03-26 14:59:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 14:59:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 09:29:42 --> URI Class Initialized
INFO - 2018-03-26 14:59:42 --> Helper loaded: form_helper
INFO - 2018-03-26 14:59:42 --> Form Validation Class Initialized
INFO - 2018-03-26 14:59:42 --> Controller Class Initialized
INFO - 2018-03-26 14:59:42 --> Model Class Initialized
INFO - 2018-03-26 14:59:42 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 14:59:42 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 14:59:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 09:29:42 --> Router Class Initialized
INFO - 2018-03-26 14:59:42 --> Model Class Initialized
INFO - 2018-03-26 14:59:42 --> Model Class Initialized
INFO - 2018-03-26 14:59:42 --> Model Class Initialized
INFO - 2018-03-26 14:59:42 --> Model Class Initialized
INFO - 2018-03-26 14:59:42 --> Model Class Initialized
INFO - 2018-03-26 14:59:42 --> Model Class Initialized
INFO - 2018-03-26 14:59:42 --> Model Class Initialized
INFO - 2018-03-26 14:59:42 --> Model Class Initialized
INFO - 2018-03-26 14:59:42 --> Model Class Initialized
INFO - 2018-03-26 14:59:42 --> Model Class Initialized
INFO - 2018-03-26 14:59:42 --> Model Class Initialized
INFO - 2018-03-26 14:59:42 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 14:59:42 --> Final output sent to browser
DEBUG - 2018-03-26 14:59:42 --> Total execution time: 0.6516
INFO - 2018-03-26 09:29:42 --> Output Class Initialized
INFO - 2018-03-26 09:29:42 --> Security Class Initialized
DEBUG - 2018-03-26 09:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 09:29:42 --> Input Class Initialized
INFO - 2018-03-26 09:29:42 --> Language Class Initialized
INFO - 2018-03-26 09:29:42 --> Language Class Initialized
INFO - 2018-03-26 09:29:42 --> Config Class Initialized
INFO - 2018-03-26 09:29:42 --> Loader Class Initialized
INFO - 2018-03-26 14:59:42 --> Helper loaded: url_helper
INFO - 2018-03-26 14:59:42 --> Helper loaded: notification_helper
INFO - 2018-03-26 14:59:42 --> Helper loaded: settings_helper
INFO - 2018-03-26 14:59:42 --> Helper loaded: permission_helper
INFO - 2018-03-26 14:59:42 --> Helper loaded: users_helper
INFO - 2018-03-26 09:29:42 --> Language Class Initialized
INFO - 2018-03-26 09:29:42 --> Config Class Initialized
INFO - 2018-03-26 09:29:42 --> Loader Class Initialized
INFO - 2018-03-26 14:59:43 --> Helper loaded: url_helper
INFO - 2018-03-26 14:59:43 --> Database Driver Class Initialized
DEBUG - 2018-03-26 14:59:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 14:59:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 14:59:43 --> Helper loaded: form_helper
INFO - 2018-03-26 14:59:43 --> Form Validation Class Initialized
INFO - 2018-03-26 14:59:43 --> Controller Class Initialized
INFO - 2018-03-26 14:59:43 --> Model Class Initialized
INFO - 2018-03-26 14:59:43 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 14:59:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 14:59:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 14:59:43 --> Model Class Initialized
INFO - 2018-03-26 14:59:43 --> Model Class Initialized
INFO - 2018-03-26 14:59:43 --> Model Class Initialized
INFO - 2018-03-26 14:59:43 --> Model Class Initialized
INFO - 2018-03-26 14:59:43 --> Model Class Initialized
INFO - 2018-03-26 14:59:43 --> Model Class Initialized
INFO - 2018-03-26 14:59:43 --> Model Class Initialized
INFO - 2018-03-26 14:59:43 --> Model Class Initialized
INFO - 2018-03-26 14:59:43 --> Model Class Initialized
INFO - 2018-03-26 14:59:43 --> Model Class Initialized
INFO - 2018-03-26 14:59:43 --> Model Class Initialized
INFO - 2018-03-26 14:59:43 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 14:59:43 --> Model Class Initialized
INFO - 2018-03-26 14:59:43 --> Helper loaded: notification_helper
INFO - 2018-03-26 14:59:43 --> Final output sent to browser
DEBUG - 2018-03-26 14:59:43 --> Total execution time: 0.8058
INFO - 2018-03-26 14:59:43 --> Helper loaded: settings_helper
INFO - 2018-03-26 14:59:43 --> Helper loaded: permission_helper
INFO - 2018-03-26 14:59:43 --> Helper loaded: users_helper
INFO - 2018-03-26 14:59:43 --> Database Driver Class Initialized
DEBUG - 2018-03-26 14:59:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 14:59:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 14:59:43 --> Helper loaded: form_helper
INFO - 2018-03-26 14:59:43 --> Form Validation Class Initialized
INFO - 2018-03-26 14:59:43 --> Controller Class Initialized
INFO - 2018-03-26 14:59:44 --> Model Class Initialized
INFO - 2018-03-26 14:59:44 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 14:59:44 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 14:59:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 14:59:44 --> Model Class Initialized
INFO - 2018-03-26 14:59:44 --> Model Class Initialized
INFO - 2018-03-26 14:59:45 --> Model Class Initialized
INFO - 2018-03-26 14:59:45 --> Model Class Initialized
INFO - 2018-03-26 14:59:45 --> Model Class Initialized
INFO - 2018-03-26 14:59:45 --> Model Class Initialized
INFO - 2018-03-26 14:59:45 --> Model Class Initialized
INFO - 2018-03-26 14:59:45 --> Model Class Initialized
INFO - 2018-03-26 14:59:45 --> Model Class Initialized
INFO - 2018-03-26 14:59:45 --> Model Class Initialized
INFO - 2018-03-26 09:29:45 --> Config Class Initialized
INFO - 2018-03-26 09:29:45 --> Hooks Class Initialized
DEBUG - 2018-03-26 09:29:45 --> UTF-8 Support Enabled
INFO - 2018-03-26 09:29:45 --> Utf8 Class Initialized
INFO - 2018-03-26 09:29:45 --> URI Class Initialized
INFO - 2018-03-26 09:29:45 --> Router Class Initialized
INFO - 2018-03-26 09:29:45 --> Output Class Initialized
INFO - 2018-03-26 14:59:45 --> Model Class Initialized
INFO - 2018-03-26 14:59:45 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 09:29:45 --> Security Class Initialized
DEBUG - 2018-03-26 09:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 09:29:45 --> Input Class Initialized
INFO - 2018-03-26 09:29:45 --> Language Class Initialized
INFO - 2018-03-26 09:29:45 --> Language Class Initialized
INFO - 2018-03-26 09:29:45 --> Config Class Initialized
INFO - 2018-03-26 09:29:45 --> Loader Class Initialized
INFO - 2018-03-26 14:59:45 --> Helper loaded: url_helper
INFO - 2018-03-26 14:59:46 --> Helper loaded: notification_helper
INFO - 2018-03-26 14:59:46 --> Helper loaded: settings_helper
INFO - 2018-03-26 14:59:46 --> Helper loaded: permission_helper
INFO - 2018-03-26 14:59:46 --> Helper loaded: users_helper
INFO - 2018-03-26 14:59:46 --> Database Driver Class Initialized
DEBUG - 2018-03-26 14:59:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 14:59:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 14:59:46 --> Final output sent to browser
DEBUG - 2018-03-26 14:59:46 --> Total execution time: 4.1201
INFO - 2018-03-26 14:59:46 --> Helper loaded: form_helper
INFO - 2018-03-26 14:59:46 --> Form Validation Class Initialized
INFO - 2018-03-26 14:59:46 --> Controller Class Initialized
INFO - 2018-03-26 14:59:46 --> Model Class Initialized
INFO - 2018-03-26 14:59:46 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 14:59:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 14:59:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 14:59:46 --> Model Class Initialized
INFO - 2018-03-26 14:59:46 --> Model Class Initialized
INFO - 2018-03-26 14:59:46 --> Model Class Initialized
INFO - 2018-03-26 14:59:46 --> Model Class Initialized
INFO - 2018-03-26 14:59:46 --> Model Class Initialized
INFO - 2018-03-26 14:59:46 --> Model Class Initialized
INFO - 2018-03-26 14:59:46 --> Model Class Initialized
INFO - 2018-03-26 14:59:46 --> Model Class Initialized
INFO - 2018-03-26 14:59:46 --> Model Class Initialized
INFO - 2018-03-26 14:59:46 --> Model Class Initialized
INFO - 2018-03-26 14:59:46 --> Model Class Initialized
INFO - 2018-03-26 14:59:46 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 14:59:46 --> Final output sent to browser
DEBUG - 2018-03-26 14:59:46 --> Total execution time: 1.7164
INFO - 2018-03-26 09:29:51 --> Config Class Initialized
INFO - 2018-03-26 09:29:51 --> Hooks Class Initialized
DEBUG - 2018-03-26 09:29:51 --> UTF-8 Support Enabled
INFO - 2018-03-26 09:29:51 --> Utf8 Class Initialized
INFO - 2018-03-26 09:29:51 --> URI Class Initialized
INFO - 2018-03-26 09:29:51 --> Config Class Initialized
INFO - 2018-03-26 09:29:51 --> Hooks Class Initialized
DEBUG - 2018-03-26 09:29:51 --> UTF-8 Support Enabled
INFO - 2018-03-26 09:29:51 --> Utf8 Class Initialized
INFO - 2018-03-26 09:29:51 --> URI Class Initialized
INFO - 2018-03-26 09:29:51 --> Router Class Initialized
INFO - 2018-03-26 09:29:51 --> Output Class Initialized
INFO - 2018-03-26 09:29:51 --> Security Class Initialized
INFO - 2018-03-26 09:29:51 --> Router Class Initialized
DEBUG - 2018-03-26 09:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 09:29:51 --> Input Class Initialized
INFO - 2018-03-26 09:29:51 --> Language Class Initialized
INFO - 2018-03-26 09:29:52 --> Output Class Initialized
INFO - 2018-03-26 09:29:52 --> Language Class Initialized
INFO - 2018-03-26 09:29:52 --> Config Class Initialized
INFO - 2018-03-26 09:29:52 --> Loader Class Initialized
INFO - 2018-03-26 14:59:52 --> Helper loaded: url_helper
INFO - 2018-03-26 14:59:52 --> Helper loaded: notification_helper
INFO - 2018-03-26 14:59:52 --> Helper loaded: settings_helper
INFO - 2018-03-26 09:29:52 --> Security Class Initialized
INFO - 2018-03-26 14:59:52 --> Helper loaded: permission_helper
INFO - 2018-03-26 14:59:52 --> Helper loaded: users_helper
INFO - 2018-03-26 14:59:52 --> Database Driver Class Initialized
DEBUG - 2018-03-26 09:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 09:29:52 --> Input Class Initialized
DEBUG - 2018-03-26 14:59:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 14:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 09:29:52 --> Language Class Initialized
INFO - 2018-03-26 14:59:52 --> Helper loaded: form_helper
INFO - 2018-03-26 14:59:52 --> Form Validation Class Initialized
INFO - 2018-03-26 14:59:52 --> Controller Class Initialized
INFO - 2018-03-26 14:59:52 --> Model Class Initialized
INFO - 2018-03-26 14:59:52 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 14:59:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 14:59:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 14:59:52 --> Model Class Initialized
INFO - 2018-03-26 14:59:52 --> Model Class Initialized
INFO - 2018-03-26 14:59:52 --> Model Class Initialized
INFO - 2018-03-26 14:59:52 --> Model Class Initialized
INFO - 2018-03-26 14:59:52 --> Model Class Initialized
INFO - 2018-03-26 14:59:52 --> Model Class Initialized
INFO - 2018-03-26 14:59:52 --> Model Class Initialized
INFO - 2018-03-26 14:59:52 --> Model Class Initialized
INFO - 2018-03-26 14:59:52 --> Model Class Initialized
INFO - 2018-03-26 14:59:52 --> Model Class Initialized
INFO - 2018-03-26 14:59:52 --> Model Class Initialized
INFO - 2018-03-26 14:59:52 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 14:59:52 --> Final output sent to browser
DEBUG - 2018-03-26 14:59:52 --> Total execution time: 0.7391
INFO - 2018-03-26 09:29:53 --> Language Class Initialized
INFO - 2018-03-26 09:29:53 --> Config Class Initialized
INFO - 2018-03-26 09:29:53 --> Loader Class Initialized
INFO - 2018-03-26 14:59:53 --> Helper loaded: url_helper
INFO - 2018-03-26 14:59:53 --> Helper loaded: notification_helper
INFO - 2018-03-26 14:59:53 --> Helper loaded: settings_helper
INFO - 2018-03-26 14:59:53 --> Helper loaded: permission_helper
INFO - 2018-03-26 14:59:53 --> Helper loaded: users_helper
INFO - 2018-03-26 14:59:54 --> Database Driver Class Initialized
DEBUG - 2018-03-26 14:59:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 14:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 09:29:54 --> Config Class Initialized
INFO - 2018-03-26 09:29:54 --> Hooks Class Initialized
DEBUG - 2018-03-26 09:29:54 --> UTF-8 Support Enabled
INFO - 2018-03-26 09:29:54 --> Utf8 Class Initialized
INFO - 2018-03-26 09:29:54 --> URI Class Initialized
INFO - 2018-03-26 09:29:54 --> Router Class Initialized
INFO - 2018-03-26 09:29:54 --> Output Class Initialized
INFO - 2018-03-26 09:29:54 --> Security Class Initialized
DEBUG - 2018-03-26 09:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 09:29:54 --> Input Class Initialized
INFO - 2018-03-26 09:29:54 --> Language Class Initialized
INFO - 2018-03-26 09:29:54 --> Config Class Initialized
INFO - 2018-03-26 09:29:54 --> Hooks Class Initialized
DEBUG - 2018-03-26 09:29:54 --> UTF-8 Support Enabled
INFO - 2018-03-26 09:29:54 --> Utf8 Class Initialized
INFO - 2018-03-26 14:59:54 --> Helper loaded: form_helper
INFO - 2018-03-26 14:59:54 --> Form Validation Class Initialized
INFO - 2018-03-26 14:59:54 --> Controller Class Initialized
INFO - 2018-03-26 09:29:54 --> URI Class Initialized
INFO - 2018-03-26 09:29:54 --> Router Class Initialized
INFO - 2018-03-26 09:29:54 --> Language Class Initialized
INFO - 2018-03-26 09:29:54 --> Config Class Initialized
INFO - 2018-03-26 09:29:54 --> Loader Class Initialized
INFO - 2018-03-26 09:29:54 --> Output Class Initialized
INFO - 2018-03-26 09:29:54 --> Security Class Initialized
DEBUG - 2018-03-26 09:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 09:29:54 --> Input Class Initialized
INFO - 2018-03-26 09:29:54 --> Config Class Initialized
INFO - 2018-03-26 09:29:54 --> Hooks Class Initialized
INFO - 2018-03-26 09:29:54 --> Language Class Initialized
DEBUG - 2018-03-26 09:29:54 --> UTF-8 Support Enabled
INFO - 2018-03-26 09:29:54 --> Utf8 Class Initialized
INFO - 2018-03-26 09:29:54 --> URI Class Initialized
INFO - 2018-03-26 09:29:54 --> Router Class Initialized
INFO - 2018-03-26 14:59:54 --> Helper loaded: url_helper
INFO - 2018-03-26 09:29:54 --> Output Class Initialized
INFO - 2018-03-26 09:29:54 --> Security Class Initialized
DEBUG - 2018-03-26 09:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 14:59:54 --> Helper loaded: notification_helper
INFO - 2018-03-26 09:29:54 --> Input Class Initialized
INFO - 2018-03-26 14:59:54 --> Helper loaded: settings_helper
INFO - 2018-03-26 09:29:54 --> Language Class Initialized
INFO - 2018-03-26 14:59:54 --> Helper loaded: permission_helper
INFO - 2018-03-26 14:59:54 --> Helper loaded: users_helper
INFO - 2018-03-26 09:29:54 --> Language Class Initialized
INFO - 2018-03-26 09:29:54 --> Config Class Initialized
INFO - 2018-03-26 09:29:54 --> Loader Class Initialized
INFO - 2018-03-26 14:59:54 --> Helper loaded: url_helper
INFO - 2018-03-26 14:59:54 --> Helper loaded: notification_helper
INFO - 2018-03-26 14:59:54 --> Helper loaded: settings_helper
INFO - 2018-03-26 14:59:54 --> Helper loaded: permission_helper
INFO - 2018-03-26 14:59:54 --> Helper loaded: users_helper
INFO - 2018-03-26 14:59:54 --> Database Driver Class Initialized
INFO - 2018-03-26 09:29:54 --> Language Class Initialized
INFO - 2018-03-26 09:29:54 --> Config Class Initialized
INFO - 2018-03-26 09:29:54 --> Loader Class Initialized
INFO - 2018-03-26 14:59:54 --> Helper loaded: url_helper
INFO - 2018-03-26 14:59:54 --> Helper loaded: notification_helper
DEBUG - 2018-03-26 14:59:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 14:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 14:59:54 --> Helper loaded: settings_helper
INFO - 2018-03-26 14:59:54 --> Helper loaded: permission_helper
INFO - 2018-03-26 14:59:54 --> Helper loaded: users_helper
INFO - 2018-03-26 14:59:54 --> Database Driver Class Initialized
INFO - 2018-03-26 14:59:54 --> Helper loaded: form_helper
INFO - 2018-03-26 14:59:54 --> Form Validation Class Initialized
INFO - 2018-03-26 14:59:54 --> Controller Class Initialized
DEBUG - 2018-03-26 14:59:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 14:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 14:59:54 --> Database Driver Class Initialized
INFO - 2018-03-26 14:59:54 --> Model Class Initialized
INFO - 2018-03-26 14:59:54 --> Helper loaded: form_helper
INFO - 2018-03-26 14:59:54 --> Form Validation Class Initialized
INFO - 2018-03-26 14:59:54 --> Controller Class Initialized
INFO - 2018-03-26 14:59:54 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 14:59:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 14:59:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-03-26 14:59:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 14:59:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 14:59:54 --> Model Class Initialized
INFO - 2018-03-26 14:59:54 --> Model Class Initialized
INFO - 2018-03-26 14:59:54 --> Helper loaded: form_helper
INFO - 2018-03-26 14:59:54 --> Form Validation Class Initialized
INFO - 2018-03-26 14:59:54 --> Controller Class Initialized
INFO - 2018-03-26 14:59:54 --> Model Class Initialized
INFO - 2018-03-26 14:59:54 --> Model Class Initialized
INFO - 2018-03-26 14:59:54 --> Model Class Initialized
INFO - 2018-03-26 14:59:54 --> Model Class Initialized
INFO - 2018-03-26 14:59:54 --> Model Class Initialized
INFO - 2018-03-26 14:59:54 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 14:59:54 --> Helper loaded: inflector_helper
ERROR - 2018-03-26 14:59:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-03-26 14:59:54 --> Final output sent to browser
DEBUG - 2018-03-26 14:59:54 --> Total execution time: 0.3935
DEBUG - 2018-03-26 14:59:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 14:59:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 14:59:54 --> Model Class Initialized
INFO - 2018-03-26 14:59:54 --> Model Class Initialized
INFO - 2018-03-26 14:59:54 --> Model Class Initialized
INFO - 2018-03-26 14:59:54 --> Model Class Initialized
INFO - 2018-03-26 14:59:54 --> Model Class Initialized
INFO - 2018-03-26 14:59:54 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 14:59:54 --> Helper loaded: inflector_helper
INFO - 2018-03-26 14:59:54 --> Final output sent to browser
DEBUG - 2018-03-26 14:59:54 --> Total execution time: 0.2352
DEBUG - 2018-03-26 14:59:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 14:59:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 14:59:54 --> Model Class Initialized
INFO - 2018-03-26 14:59:54 --> Model Class Initialized
INFO - 2018-03-26 14:59:54 --> Model Class Initialized
INFO - 2018-03-26 14:59:54 --> Model Class Initialized
INFO - 2018-03-26 14:59:54 --> Model Class Initialized
INFO - 2018-03-26 14:59:54 --> Model Class Initialized
INFO - 2018-03-26 14:59:54 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-26 14:59:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-03-26 14:59:54 --> Final output sent to browser
DEBUG - 2018-03-26 14:59:54 --> Total execution time: 0.1994
INFO - 2018-03-26 14:59:55 --> Model Class Initialized
INFO - 2018-03-26 14:59:55 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 14:59:55 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 14:59:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 14:59:55 --> Model Class Initialized
INFO - 2018-03-26 14:59:55 --> Model Class Initialized
INFO - 2018-03-26 14:59:55 --> Model Class Initialized
INFO - 2018-03-26 14:59:55 --> Model Class Initialized
INFO - 2018-03-26 14:59:55 --> Model Class Initialized
INFO - 2018-03-26 14:59:55 --> Model Class Initialized
INFO - 2018-03-26 14:59:55 --> Model Class Initialized
INFO - 2018-03-26 14:59:55 --> Model Class Initialized
INFO - 2018-03-26 14:59:55 --> Model Class Initialized
INFO - 2018-03-26 14:59:55 --> Model Class Initialized
INFO - 2018-03-26 14:59:55 --> Model Class Initialized
INFO - 2018-03-26 14:59:55 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 14:59:56 --> Final output sent to browser
DEBUG - 2018-03-26 14:59:56 --> Total execution time: 5.2782
INFO - 2018-03-26 09:41:34 --> Config Class Initialized
INFO - 2018-03-26 09:41:34 --> Hooks Class Initialized
DEBUG - 2018-03-26 09:41:34 --> UTF-8 Support Enabled
INFO - 2018-03-26 09:41:34 --> Utf8 Class Initialized
INFO - 2018-03-26 09:41:34 --> URI Class Initialized
INFO - 2018-03-26 09:41:35 --> Router Class Initialized
INFO - 2018-03-26 09:41:35 --> Output Class Initialized
INFO - 2018-03-26 09:41:35 --> Security Class Initialized
DEBUG - 2018-03-26 09:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 09:41:35 --> Input Class Initialized
INFO - 2018-03-26 09:41:35 --> Language Class Initialized
INFO - 2018-03-26 09:41:35 --> Language Class Initialized
INFO - 2018-03-26 09:41:35 --> Config Class Initialized
INFO - 2018-03-26 09:41:35 --> Loader Class Initialized
INFO - 2018-03-26 15:11:35 --> Helper loaded: url_helper
INFO - 2018-03-26 15:11:35 --> Helper loaded: notification_helper
INFO - 2018-03-26 15:11:35 --> Helper loaded: settings_helper
INFO - 2018-03-26 15:11:35 --> Helper loaded: permission_helper
INFO - 2018-03-26 15:11:35 --> Helper loaded: users_helper
INFO - 2018-03-26 15:11:35 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:11:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:11:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:11:36 --> Helper loaded: form_helper
INFO - 2018-03-26 15:11:36 --> Form Validation Class Initialized
INFO - 2018-03-26 15:11:36 --> Controller Class Initialized
INFO - 2018-03-26 15:11:37 --> Model Class Initialized
INFO - 2018-03-26 15:11:37 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 15:11:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 15:11:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 15:11:37 --> Model Class Initialized
INFO - 2018-03-26 15:11:37 --> Model Class Initialized
INFO - 2018-03-26 15:11:37 --> Model Class Initialized
INFO - 2018-03-26 15:11:37 --> Model Class Initialized
INFO - 2018-03-26 15:11:37 --> Model Class Initialized
INFO - 2018-03-26 15:11:37 --> Model Class Initialized
INFO - 2018-03-26 15:11:37 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 15:11:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-26 15:11:37 --> Final output sent to browser
DEBUG - 2018-03-26 15:11:37 --> Total execution time: 2.5240
INFO - 2018-03-26 09:41:38 --> Config Class Initialized
INFO - 2018-03-26 09:41:38 --> Hooks Class Initialized
DEBUG - 2018-03-26 09:41:38 --> UTF-8 Support Enabled
INFO - 2018-03-26 09:41:38 --> Utf8 Class Initialized
INFO - 2018-03-26 09:41:38 --> URI Class Initialized
INFO - 2018-03-26 09:41:38 --> Router Class Initialized
INFO - 2018-03-26 09:41:38 --> Output Class Initialized
INFO - 2018-03-26 09:41:38 --> Security Class Initialized
DEBUG - 2018-03-26 09:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 09:41:38 --> Input Class Initialized
INFO - 2018-03-26 09:41:38 --> Language Class Initialized
INFO - 2018-03-26 09:41:38 --> Language Class Initialized
INFO - 2018-03-26 09:41:38 --> Config Class Initialized
INFO - 2018-03-26 09:41:38 --> Loader Class Initialized
INFO - 2018-03-26 15:11:38 --> Helper loaded: url_helper
INFO - 2018-03-26 15:11:38 --> Helper loaded: notification_helper
INFO - 2018-03-26 15:11:38 --> Helper loaded: settings_helper
INFO - 2018-03-26 15:11:38 --> Helper loaded: permission_helper
INFO - 2018-03-26 15:11:38 --> Helper loaded: users_helper
INFO - 2018-03-26 15:11:38 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:11:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:11:38 --> Helper loaded: form_helper
INFO - 2018-03-26 15:11:38 --> Form Validation Class Initialized
INFO - 2018-03-26 15:11:38 --> Controller Class Initialized
INFO - 2018-03-26 15:11:38 --> Model Class Initialized
INFO - 2018-03-26 15:11:38 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 15:11:38 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 15:11:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 15:11:38 --> Model Class Initialized
INFO - 2018-03-26 15:11:38 --> Model Class Initialized
INFO - 2018-03-26 15:11:38 --> Model Class Initialized
INFO - 2018-03-26 15:11:38 --> Model Class Initialized
INFO - 2018-03-26 15:11:38 --> Model Class Initialized
INFO - 2018-03-26 15:11:38 --> Model Class Initialized
INFO - 2018-03-26 15:11:38 --> Model Class Initialized
INFO - 2018-03-26 15:11:38 --> Model Class Initialized
INFO - 2018-03-26 15:11:38 --> Model Class Initialized
INFO - 2018-03-26 15:11:38 --> Model Class Initialized
INFO - 2018-03-26 15:11:38 --> Model Class Initialized
INFO - 2018-03-26 15:11:38 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 15:11:38 --> Model Class Initialized
INFO - 2018-03-26 15:11:38 --> Final output sent to browser
DEBUG - 2018-03-26 15:11:38 --> Total execution time: 0.1232
INFO - 2018-03-26 09:42:16 --> Config Class Initialized
INFO - 2018-03-26 09:42:16 --> Hooks Class Initialized
DEBUG - 2018-03-26 09:42:16 --> UTF-8 Support Enabled
INFO - 2018-03-26 09:42:16 --> Utf8 Class Initialized
INFO - 2018-03-26 09:42:16 --> URI Class Initialized
INFO - 2018-03-26 09:42:16 --> Router Class Initialized
INFO - 2018-03-26 09:42:16 --> Output Class Initialized
INFO - 2018-03-26 09:42:16 --> Security Class Initialized
DEBUG - 2018-03-26 09:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 09:42:16 --> Input Class Initialized
INFO - 2018-03-26 09:42:16 --> Language Class Initialized
INFO - 2018-03-26 09:42:16 --> Language Class Initialized
INFO - 2018-03-26 09:42:16 --> Config Class Initialized
INFO - 2018-03-26 09:42:16 --> Loader Class Initialized
INFO - 2018-03-26 15:12:16 --> Helper loaded: url_helper
INFO - 2018-03-26 15:12:16 --> Helper loaded: notification_helper
INFO - 2018-03-26 15:12:16 --> Helper loaded: settings_helper
INFO - 2018-03-26 15:12:16 --> Helper loaded: permission_helper
INFO - 2018-03-26 15:12:16 --> Helper loaded: users_helper
INFO - 2018-03-26 15:12:16 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:12:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:12:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:12:16 --> Helper loaded: form_helper
INFO - 2018-03-26 15:12:16 --> Form Validation Class Initialized
INFO - 2018-03-26 15:12:16 --> Controller Class Initialized
INFO - 2018-03-26 15:12:16 --> Model Class Initialized
INFO - 2018-03-26 15:12:16 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 15:12:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 15:12:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 15:12:16 --> Model Class Initialized
INFO - 2018-03-26 15:12:16 --> Model Class Initialized
INFO - 2018-03-26 15:12:16 --> Model Class Initialized
INFO - 2018-03-26 15:12:16 --> Model Class Initialized
INFO - 2018-03-26 15:12:16 --> Model Class Initialized
INFO - 2018-03-26 15:12:16 --> Model Class Initialized
INFO - 2018-03-26 15:12:16 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 15:12:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-26 15:12:16 --> Final output sent to browser
DEBUG - 2018-03-26 15:12:16 --> Total execution time: 0.9292
INFO - 2018-03-26 09:42:17 --> Config Class Initialized
INFO - 2018-03-26 09:42:17 --> Hooks Class Initialized
DEBUG - 2018-03-26 09:42:17 --> UTF-8 Support Enabled
INFO - 2018-03-26 09:42:17 --> Utf8 Class Initialized
INFO - 2018-03-26 09:42:17 --> URI Class Initialized
INFO - 2018-03-26 09:42:17 --> Router Class Initialized
INFO - 2018-03-26 09:42:17 --> Output Class Initialized
INFO - 2018-03-26 09:42:17 --> Security Class Initialized
DEBUG - 2018-03-26 09:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 09:42:17 --> Input Class Initialized
INFO - 2018-03-26 09:42:17 --> Language Class Initialized
INFO - 2018-03-26 09:42:18 --> Language Class Initialized
INFO - 2018-03-26 09:42:18 --> Config Class Initialized
INFO - 2018-03-26 09:42:18 --> Loader Class Initialized
INFO - 2018-03-26 15:12:18 --> Helper loaded: url_helper
INFO - 2018-03-26 15:12:18 --> Helper loaded: notification_helper
INFO - 2018-03-26 15:12:18 --> Helper loaded: settings_helper
INFO - 2018-03-26 15:12:18 --> Helper loaded: permission_helper
INFO - 2018-03-26 15:12:18 --> Helper loaded: users_helper
INFO - 2018-03-26 15:12:18 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:12:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:12:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:12:18 --> Helper loaded: form_helper
INFO - 2018-03-26 15:12:18 --> Form Validation Class Initialized
INFO - 2018-03-26 15:12:18 --> Controller Class Initialized
INFO - 2018-03-26 15:12:18 --> Model Class Initialized
INFO - 2018-03-26 15:12:18 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 15:12:18 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 15:12:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 15:12:18 --> Model Class Initialized
INFO - 2018-03-26 15:12:18 --> Model Class Initialized
INFO - 2018-03-26 15:12:18 --> Model Class Initialized
INFO - 2018-03-26 15:12:18 --> Model Class Initialized
INFO - 2018-03-26 15:12:18 --> Model Class Initialized
INFO - 2018-03-26 15:12:18 --> Model Class Initialized
INFO - 2018-03-26 15:12:18 --> Model Class Initialized
INFO - 2018-03-26 15:12:18 --> Model Class Initialized
INFO - 2018-03-26 15:12:18 --> Model Class Initialized
INFO - 2018-03-26 15:12:18 --> Model Class Initialized
INFO - 2018-03-26 15:12:18 --> Model Class Initialized
INFO - 2018-03-26 15:12:18 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 15:12:18 --> Model Class Initialized
INFO - 2018-03-26 15:12:18 --> Final output sent to browser
DEBUG - 2018-03-26 15:12:18 --> Total execution time: 0.3630
INFO - 2018-03-26 09:45:58 --> Config Class Initialized
INFO - 2018-03-26 09:45:58 --> Hooks Class Initialized
DEBUG - 2018-03-26 09:45:58 --> UTF-8 Support Enabled
INFO - 2018-03-26 09:45:58 --> Utf8 Class Initialized
INFO - 2018-03-26 09:45:58 --> URI Class Initialized
INFO - 2018-03-26 09:45:59 --> Router Class Initialized
INFO - 2018-03-26 09:45:59 --> Output Class Initialized
INFO - 2018-03-26 09:45:59 --> Security Class Initialized
DEBUG - 2018-03-26 09:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 09:45:59 --> Input Class Initialized
INFO - 2018-03-26 09:45:59 --> Language Class Initialized
INFO - 2018-03-26 09:45:59 --> Language Class Initialized
INFO - 2018-03-26 09:45:59 --> Config Class Initialized
INFO - 2018-03-26 09:45:59 --> Loader Class Initialized
INFO - 2018-03-26 15:15:59 --> Helper loaded: url_helper
INFO - 2018-03-26 15:15:59 --> Helper loaded: notification_helper
INFO - 2018-03-26 15:15:59 --> Helper loaded: settings_helper
INFO - 2018-03-26 15:15:59 --> Helper loaded: permission_helper
INFO - 2018-03-26 15:15:59 --> Helper loaded: users_helper
INFO - 2018-03-26 15:15:59 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:15:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:15:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:15:59 --> Helper loaded: form_helper
INFO - 2018-03-26 15:15:59 --> Form Validation Class Initialized
INFO - 2018-03-26 15:15:59 --> Controller Class Initialized
INFO - 2018-03-26 15:15:59 --> Model Class Initialized
INFO - 2018-03-26 15:15:59 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 15:15:59 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 15:15:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 15:15:59 --> Model Class Initialized
INFO - 2018-03-26 15:15:59 --> Model Class Initialized
INFO - 2018-03-26 15:15:59 --> Model Class Initialized
INFO - 2018-03-26 15:15:59 --> Model Class Initialized
INFO - 2018-03-26 15:15:59 --> Model Class Initialized
INFO - 2018-03-26 15:15:59 --> Model Class Initialized
INFO - 2018-03-26 15:15:59 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 15:15:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-26 15:15:59 --> Final output sent to browser
DEBUG - 2018-03-26 15:15:59 --> Total execution time: 0.9233
INFO - 2018-03-26 09:46:01 --> Config Class Initialized
INFO - 2018-03-26 09:46:01 --> Hooks Class Initialized
DEBUG - 2018-03-26 09:46:01 --> UTF-8 Support Enabled
INFO - 2018-03-26 09:46:01 --> Utf8 Class Initialized
INFO - 2018-03-26 09:46:01 --> URI Class Initialized
INFO - 2018-03-26 09:46:01 --> Router Class Initialized
INFO - 2018-03-26 09:46:01 --> Output Class Initialized
INFO - 2018-03-26 09:46:01 --> Security Class Initialized
DEBUG - 2018-03-26 09:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 09:46:01 --> Input Class Initialized
INFO - 2018-03-26 09:46:01 --> Language Class Initialized
INFO - 2018-03-26 09:46:01 --> Language Class Initialized
INFO - 2018-03-26 09:46:01 --> Config Class Initialized
INFO - 2018-03-26 09:46:01 --> Loader Class Initialized
INFO - 2018-03-26 15:16:01 --> Helper loaded: url_helper
INFO - 2018-03-26 15:16:01 --> Helper loaded: notification_helper
INFO - 2018-03-26 15:16:01 --> Helper loaded: settings_helper
INFO - 2018-03-26 15:16:01 --> Helper loaded: permission_helper
INFO - 2018-03-26 15:16:01 --> Helper loaded: users_helper
INFO - 2018-03-26 15:16:01 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:16:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:16:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:16:01 --> Helper loaded: form_helper
INFO - 2018-03-26 15:16:01 --> Form Validation Class Initialized
INFO - 2018-03-26 15:16:01 --> Controller Class Initialized
INFO - 2018-03-26 15:16:01 --> Model Class Initialized
INFO - 2018-03-26 15:16:01 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 15:16:01 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 15:16:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 15:16:01 --> Model Class Initialized
INFO - 2018-03-26 15:16:01 --> Model Class Initialized
INFO - 2018-03-26 15:16:01 --> Model Class Initialized
INFO - 2018-03-26 15:16:01 --> Model Class Initialized
INFO - 2018-03-26 15:16:01 --> Model Class Initialized
INFO - 2018-03-26 15:16:01 --> Model Class Initialized
INFO - 2018-03-26 15:16:01 --> Model Class Initialized
INFO - 2018-03-26 15:16:01 --> Model Class Initialized
INFO - 2018-03-26 15:16:01 --> Model Class Initialized
INFO - 2018-03-26 15:16:01 --> Model Class Initialized
INFO - 2018-03-26 15:16:01 --> Model Class Initialized
INFO - 2018-03-26 15:16:01 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 15:16:01 --> Model Class Initialized
INFO - 2018-03-26 15:16:01 --> Final output sent to browser
DEBUG - 2018-03-26 15:16:01 --> Total execution time: 0.2954
INFO - 2018-03-26 09:46:01 --> Config Class Initialized
INFO - 2018-03-26 09:46:01 --> Hooks Class Initialized
DEBUG - 2018-03-26 09:46:01 --> UTF-8 Support Enabled
INFO - 2018-03-26 09:46:01 --> Utf8 Class Initialized
INFO - 2018-03-26 09:46:01 --> URI Class Initialized
INFO - 2018-03-26 09:46:01 --> Router Class Initialized
INFO - 2018-03-26 09:46:01 --> Output Class Initialized
INFO - 2018-03-26 09:46:01 --> Security Class Initialized
DEBUG - 2018-03-26 09:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 09:46:01 --> Input Class Initialized
INFO - 2018-03-26 09:46:01 --> Language Class Initialized
INFO - 2018-03-26 09:46:01 --> Language Class Initialized
INFO - 2018-03-26 09:46:01 --> Config Class Initialized
INFO - 2018-03-26 09:46:01 --> Loader Class Initialized
INFO - 2018-03-26 15:16:01 --> Helper loaded: url_helper
INFO - 2018-03-26 15:16:01 --> Helper loaded: notification_helper
INFO - 2018-03-26 15:16:01 --> Helper loaded: settings_helper
INFO - 2018-03-26 15:16:01 --> Helper loaded: permission_helper
INFO - 2018-03-26 15:16:01 --> Helper loaded: users_helper
INFO - 2018-03-26 15:16:01 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:16:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:16:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:16:01 --> Helper loaded: form_helper
INFO - 2018-03-26 15:16:01 --> Form Validation Class Initialized
INFO - 2018-03-26 15:16:01 --> Controller Class Initialized
INFO - 2018-03-26 15:16:01 --> Model Class Initialized
INFO - 2018-03-26 15:16:01 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 15:16:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 15:16:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 15:16:02 --> Model Class Initialized
INFO - 2018-03-26 15:16:02 --> Model Class Initialized
INFO - 2018-03-26 15:16:02 --> Model Class Initialized
INFO - 2018-03-26 15:16:02 --> Model Class Initialized
INFO - 2018-03-26 15:16:02 --> Model Class Initialized
INFO - 2018-03-26 15:16:02 --> Model Class Initialized
INFO - 2018-03-26 15:16:02 --> Model Class Initialized
INFO - 2018-03-26 15:16:02 --> Model Class Initialized
INFO - 2018-03-26 15:16:02 --> Model Class Initialized
INFO - 2018-03-26 15:16:02 --> Model Class Initialized
INFO - 2018-03-26 15:16:02 --> Model Class Initialized
INFO - 2018-03-26 15:16:02 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 15:16:02 --> Model Class Initialized
INFO - 2018-03-26 15:16:02 --> Final output sent to browser
DEBUG - 2018-03-26 15:16:02 --> Total execution time: 1.1104
INFO - 2018-03-26 09:49:35 --> Config Class Initialized
INFO - 2018-03-26 09:49:35 --> Hooks Class Initialized
DEBUG - 2018-03-26 09:49:35 --> UTF-8 Support Enabled
INFO - 2018-03-26 09:49:35 --> Utf8 Class Initialized
INFO - 2018-03-26 09:49:35 --> URI Class Initialized
INFO - 2018-03-26 09:49:35 --> Router Class Initialized
INFO - 2018-03-26 09:49:35 --> Output Class Initialized
INFO - 2018-03-26 09:49:35 --> Security Class Initialized
DEBUG - 2018-03-26 09:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 09:49:35 --> Input Class Initialized
INFO - 2018-03-26 09:49:35 --> Language Class Initialized
INFO - 2018-03-26 09:49:35 --> Language Class Initialized
INFO - 2018-03-26 09:49:35 --> Config Class Initialized
INFO - 2018-03-26 09:49:35 --> Loader Class Initialized
INFO - 2018-03-26 15:19:35 --> Helper loaded: url_helper
INFO - 2018-03-26 15:19:35 --> Helper loaded: notification_helper
INFO - 2018-03-26 15:19:35 --> Helper loaded: settings_helper
INFO - 2018-03-26 15:19:35 --> Helper loaded: permission_helper
INFO - 2018-03-26 15:19:35 --> Helper loaded: users_helper
INFO - 2018-03-26 15:19:35 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:19:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:19:35 --> Helper loaded: form_helper
INFO - 2018-03-26 15:19:35 --> Form Validation Class Initialized
INFO - 2018-03-26 15:19:35 --> Controller Class Initialized
INFO - 2018-03-26 15:19:35 --> Model Class Initialized
INFO - 2018-03-26 15:19:35 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 15:19:35 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 15:19:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 15:19:35 --> Model Class Initialized
INFO - 2018-03-26 15:19:35 --> Model Class Initialized
INFO - 2018-03-26 15:19:35 --> Model Class Initialized
INFO - 2018-03-26 15:19:35 --> Model Class Initialized
INFO - 2018-03-26 15:19:35 --> Model Class Initialized
INFO - 2018-03-26 15:19:35 --> Model Class Initialized
INFO - 2018-03-26 15:19:35 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 15:19:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-26 15:19:35 --> Final output sent to browser
DEBUG - 2018-03-26 15:19:35 --> Total execution time: 0.1121
INFO - 2018-03-26 09:49:36 --> Config Class Initialized
INFO - 2018-03-26 09:49:36 --> Hooks Class Initialized
DEBUG - 2018-03-26 09:49:36 --> UTF-8 Support Enabled
INFO - 2018-03-26 09:49:36 --> Utf8 Class Initialized
INFO - 2018-03-26 09:49:36 --> URI Class Initialized
INFO - 2018-03-26 09:49:36 --> Router Class Initialized
INFO - 2018-03-26 09:49:36 --> Output Class Initialized
INFO - 2018-03-26 09:49:36 --> Security Class Initialized
DEBUG - 2018-03-26 09:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 09:49:36 --> Input Class Initialized
INFO - 2018-03-26 09:49:36 --> Language Class Initialized
INFO - 2018-03-26 09:49:36 --> Language Class Initialized
INFO - 2018-03-26 09:49:36 --> Config Class Initialized
INFO - 2018-03-26 09:49:36 --> Loader Class Initialized
INFO - 2018-03-26 15:19:36 --> Helper loaded: url_helper
INFO - 2018-03-26 15:19:36 --> Helper loaded: notification_helper
INFO - 2018-03-26 15:19:36 --> Helper loaded: settings_helper
INFO - 2018-03-26 15:19:36 --> Helper loaded: permission_helper
INFO - 2018-03-26 15:19:36 --> Helper loaded: users_helper
INFO - 2018-03-26 15:19:36 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:19:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:19:36 --> Helper loaded: form_helper
INFO - 2018-03-26 15:19:36 --> Form Validation Class Initialized
INFO - 2018-03-26 15:19:36 --> Controller Class Initialized
INFO - 2018-03-26 15:19:36 --> Model Class Initialized
INFO - 2018-03-26 15:19:36 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 15:19:36 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 15:19:36 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 15:19:36 --> Model Class Initialized
INFO - 2018-03-26 15:19:36 --> Model Class Initialized
INFO - 2018-03-26 15:19:36 --> Model Class Initialized
INFO - 2018-03-26 15:19:36 --> Model Class Initialized
INFO - 2018-03-26 15:19:36 --> Model Class Initialized
INFO - 2018-03-26 15:19:36 --> Model Class Initialized
INFO - 2018-03-26 15:19:36 --> Model Class Initialized
INFO - 2018-03-26 15:19:36 --> Model Class Initialized
INFO - 2018-03-26 15:19:36 --> Model Class Initialized
INFO - 2018-03-26 15:19:36 --> Model Class Initialized
INFO - 2018-03-26 15:19:36 --> Model Class Initialized
INFO - 2018-03-26 15:19:36 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 15:19:36 --> Model Class Initialized
INFO - 2018-03-26 15:19:36 --> Final output sent to browser
DEBUG - 2018-03-26 15:19:36 --> Total execution time: 0.1323
INFO - 2018-03-26 09:55:08 --> Config Class Initialized
INFO - 2018-03-26 09:55:08 --> Hooks Class Initialized
DEBUG - 2018-03-26 09:55:08 --> UTF-8 Support Enabled
INFO - 2018-03-26 09:55:08 --> Utf8 Class Initialized
INFO - 2018-03-26 09:55:08 --> URI Class Initialized
INFO - 2018-03-26 09:55:08 --> Router Class Initialized
INFO - 2018-03-26 09:55:08 --> Output Class Initialized
INFO - 2018-03-26 09:55:08 --> Security Class Initialized
DEBUG - 2018-03-26 09:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 09:55:08 --> Input Class Initialized
INFO - 2018-03-26 09:55:08 --> Language Class Initialized
INFO - 2018-03-26 09:55:08 --> Language Class Initialized
INFO - 2018-03-26 09:55:08 --> Config Class Initialized
INFO - 2018-03-26 09:55:08 --> Loader Class Initialized
INFO - 2018-03-26 15:25:08 --> Helper loaded: url_helper
INFO - 2018-03-26 15:25:08 --> Helper loaded: notification_helper
INFO - 2018-03-26 15:25:08 --> Helper loaded: settings_helper
INFO - 2018-03-26 15:25:08 --> Helper loaded: permission_helper
INFO - 2018-03-26 15:25:08 --> Helper loaded: users_helper
INFO - 2018-03-26 15:25:08 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:25:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:25:08 --> Helper loaded: form_helper
INFO - 2018-03-26 15:25:08 --> Form Validation Class Initialized
INFO - 2018-03-26 15:25:08 --> Controller Class Initialized
INFO - 2018-03-26 15:25:08 --> Model Class Initialized
INFO - 2018-03-26 15:25:08 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 15:25:08 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 15:25:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 15:25:08 --> Model Class Initialized
INFO - 2018-03-26 15:25:08 --> Model Class Initialized
INFO - 2018-03-26 15:25:08 --> Model Class Initialized
INFO - 2018-03-26 15:25:08 --> Model Class Initialized
INFO - 2018-03-26 15:25:08 --> Model Class Initialized
INFO - 2018-03-26 15:25:08 --> Model Class Initialized
INFO - 2018-03-26 15:25:08 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 15:25:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-26 15:25:08 --> Final output sent to browser
DEBUG - 2018-03-26 15:25:08 --> Total execution time: 0.1088
INFO - 2018-03-26 09:55:23 --> Config Class Initialized
INFO - 2018-03-26 09:55:23 --> Hooks Class Initialized
DEBUG - 2018-03-26 09:55:23 --> UTF-8 Support Enabled
INFO - 2018-03-26 09:55:23 --> Utf8 Class Initialized
INFO - 2018-03-26 09:55:23 --> URI Class Initialized
INFO - 2018-03-26 09:55:23 --> Router Class Initialized
INFO - 2018-03-26 09:55:23 --> Output Class Initialized
INFO - 2018-03-26 09:55:23 --> Security Class Initialized
DEBUG - 2018-03-26 09:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 09:55:23 --> Input Class Initialized
INFO - 2018-03-26 09:55:23 --> Language Class Initialized
INFO - 2018-03-26 09:55:23 --> Language Class Initialized
INFO - 2018-03-26 09:55:23 --> Config Class Initialized
INFO - 2018-03-26 09:55:23 --> Loader Class Initialized
INFO - 2018-03-26 15:25:23 --> Helper loaded: url_helper
INFO - 2018-03-26 15:25:23 --> Helper loaded: notification_helper
INFO - 2018-03-26 15:25:23 --> Helper loaded: settings_helper
INFO - 2018-03-26 15:25:23 --> Helper loaded: permission_helper
INFO - 2018-03-26 15:25:23 --> Helper loaded: users_helper
INFO - 2018-03-26 15:25:23 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:25:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:25:24 --> Helper loaded: form_helper
INFO - 2018-03-26 15:25:24 --> Form Validation Class Initialized
INFO - 2018-03-26 15:25:24 --> Controller Class Initialized
INFO - 2018-03-26 15:25:24 --> Model Class Initialized
INFO - 2018-03-26 15:25:24 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 15:25:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 15:25:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 15:25:24 --> Model Class Initialized
INFO - 2018-03-26 15:25:24 --> Model Class Initialized
INFO - 2018-03-26 15:25:24 --> Model Class Initialized
INFO - 2018-03-26 15:25:24 --> Model Class Initialized
INFO - 2018-03-26 15:25:24 --> Model Class Initialized
INFO - 2018-03-26 15:25:24 --> Model Class Initialized
INFO - 2018-03-26 15:25:24 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 15:25:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-26 15:25:24 --> Final output sent to browser
DEBUG - 2018-03-26 15:25:24 --> Total execution time: 0.9935
INFO - 2018-03-26 09:55:25 --> Config Class Initialized
INFO - 2018-03-26 09:55:25 --> Hooks Class Initialized
DEBUG - 2018-03-26 09:55:25 --> UTF-8 Support Enabled
INFO - 2018-03-26 09:55:25 --> Utf8 Class Initialized
INFO - 2018-03-26 09:55:25 --> URI Class Initialized
INFO - 2018-03-26 09:55:25 --> Router Class Initialized
INFO - 2018-03-26 09:55:25 --> Output Class Initialized
INFO - 2018-03-26 09:55:25 --> Security Class Initialized
DEBUG - 2018-03-26 09:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 09:55:25 --> Input Class Initialized
INFO - 2018-03-26 09:55:25 --> Language Class Initialized
INFO - 2018-03-26 09:55:25 --> Language Class Initialized
INFO - 2018-03-26 09:55:25 --> Config Class Initialized
INFO - 2018-03-26 09:55:25 --> Loader Class Initialized
INFO - 2018-03-26 15:25:25 --> Helper loaded: url_helper
INFO - 2018-03-26 15:25:25 --> Helper loaded: notification_helper
INFO - 2018-03-26 15:25:25 --> Helper loaded: settings_helper
INFO - 2018-03-26 15:25:25 --> Helper loaded: permission_helper
INFO - 2018-03-26 15:25:25 --> Helper loaded: users_helper
INFO - 2018-03-26 15:25:25 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:25:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:25:25 --> Helper loaded: form_helper
INFO - 2018-03-26 15:25:25 --> Form Validation Class Initialized
INFO - 2018-03-26 15:25:25 --> Controller Class Initialized
INFO - 2018-03-26 15:25:25 --> Model Class Initialized
INFO - 2018-03-26 15:25:25 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 15:25:25 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 15:25:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 15:25:25 --> Model Class Initialized
INFO - 2018-03-26 15:25:25 --> Model Class Initialized
INFO - 2018-03-26 15:25:25 --> Model Class Initialized
INFO - 2018-03-26 15:25:25 --> Model Class Initialized
INFO - 2018-03-26 15:25:25 --> Model Class Initialized
INFO - 2018-03-26 15:25:25 --> Model Class Initialized
INFO - 2018-03-26 15:25:25 --> Model Class Initialized
INFO - 2018-03-26 15:25:25 --> Model Class Initialized
INFO - 2018-03-26 15:25:25 --> Model Class Initialized
INFO - 2018-03-26 15:25:25 --> Model Class Initialized
INFO - 2018-03-26 15:25:25 --> Model Class Initialized
INFO - 2018-03-26 15:25:25 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 15:25:25 --> Model Class Initialized
INFO - 2018-03-26 15:25:25 --> Final output sent to browser
DEBUG - 2018-03-26 15:25:25 --> Total execution time: 0.1175
INFO - 2018-03-26 09:55:25 --> Config Class Initialized
INFO - 2018-03-26 09:55:25 --> Hooks Class Initialized
DEBUG - 2018-03-26 09:55:25 --> UTF-8 Support Enabled
INFO - 2018-03-26 09:55:25 --> Utf8 Class Initialized
INFO - 2018-03-26 09:55:25 --> URI Class Initialized
INFO - 2018-03-26 09:55:26 --> Router Class Initialized
INFO - 2018-03-26 09:55:26 --> Output Class Initialized
INFO - 2018-03-26 09:55:26 --> Security Class Initialized
DEBUG - 2018-03-26 09:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 09:55:26 --> Input Class Initialized
INFO - 2018-03-26 09:55:26 --> Language Class Initialized
INFO - 2018-03-26 09:55:26 --> Language Class Initialized
INFO - 2018-03-26 09:55:26 --> Config Class Initialized
INFO - 2018-03-26 09:55:26 --> Loader Class Initialized
INFO - 2018-03-26 15:25:26 --> Helper loaded: url_helper
INFO - 2018-03-26 15:25:26 --> Helper loaded: notification_helper
INFO - 2018-03-26 15:25:26 --> Helper loaded: settings_helper
INFO - 2018-03-26 15:25:26 --> Helper loaded: permission_helper
INFO - 2018-03-26 15:25:26 --> Helper loaded: users_helper
INFO - 2018-03-26 15:25:26 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:25:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:25:26 --> Helper loaded: form_helper
INFO - 2018-03-26 15:25:26 --> Form Validation Class Initialized
INFO - 2018-03-26 15:25:26 --> Controller Class Initialized
INFO - 2018-03-26 15:25:26 --> Model Class Initialized
INFO - 2018-03-26 15:25:26 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 15:25:26 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 15:25:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 15:25:26 --> Model Class Initialized
INFO - 2018-03-26 15:25:26 --> Model Class Initialized
INFO - 2018-03-26 15:25:26 --> Model Class Initialized
INFO - 2018-03-26 15:25:26 --> Model Class Initialized
INFO - 2018-03-26 15:25:26 --> Model Class Initialized
INFO - 2018-03-26 15:25:26 --> Model Class Initialized
INFO - 2018-03-26 15:25:26 --> Model Class Initialized
INFO - 2018-03-26 15:25:26 --> Model Class Initialized
INFO - 2018-03-26 15:25:26 --> Model Class Initialized
INFO - 2018-03-26 15:25:26 --> Model Class Initialized
INFO - 2018-03-26 15:25:26 --> Model Class Initialized
INFO - 2018-03-26 15:25:26 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 15:25:26 --> Model Class Initialized
INFO - 2018-03-26 15:25:26 --> Final output sent to browser
DEBUG - 2018-03-26 15:25:26 --> Total execution time: 0.2089
INFO - 2018-03-26 09:57:43 --> Config Class Initialized
INFO - 2018-03-26 09:57:43 --> Hooks Class Initialized
DEBUG - 2018-03-26 09:57:43 --> UTF-8 Support Enabled
INFO - 2018-03-26 09:57:43 --> Utf8 Class Initialized
INFO - 2018-03-26 09:57:43 --> URI Class Initialized
INFO - 2018-03-26 09:57:43 --> Router Class Initialized
INFO - 2018-03-26 09:57:43 --> Output Class Initialized
INFO - 2018-03-26 09:57:43 --> Security Class Initialized
DEBUG - 2018-03-26 09:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 09:57:43 --> Input Class Initialized
INFO - 2018-03-26 09:57:43 --> Language Class Initialized
INFO - 2018-03-26 09:57:43 --> Language Class Initialized
INFO - 2018-03-26 09:57:43 --> Config Class Initialized
INFO - 2018-03-26 09:57:43 --> Loader Class Initialized
INFO - 2018-03-26 15:27:43 --> Helper loaded: url_helper
INFO - 2018-03-26 15:27:43 --> Helper loaded: notification_helper
INFO - 2018-03-26 15:27:43 --> Helper loaded: settings_helper
INFO - 2018-03-26 15:27:43 --> Helper loaded: permission_helper
INFO - 2018-03-26 15:27:43 --> Helper loaded: users_helper
INFO - 2018-03-26 15:27:43 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:27:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:27:43 --> Helper loaded: form_helper
INFO - 2018-03-26 15:27:43 --> Form Validation Class Initialized
INFO - 2018-03-26 15:27:43 --> Controller Class Initialized
INFO - 2018-03-26 15:27:43 --> Model Class Initialized
INFO - 2018-03-26 15:27:43 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 15:27:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 15:27:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 15:27:43 --> Model Class Initialized
INFO - 2018-03-26 15:27:43 --> Model Class Initialized
INFO - 2018-03-26 15:27:43 --> Model Class Initialized
INFO - 2018-03-26 15:27:43 --> Model Class Initialized
INFO - 2018-03-26 15:27:43 --> Model Class Initialized
INFO - 2018-03-26 15:27:43 --> Model Class Initialized
INFO - 2018-03-26 15:27:43 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 15:27:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-26 15:27:43 --> Final output sent to browser
DEBUG - 2018-03-26 15:27:43 --> Total execution time: 0.1265
INFO - 2018-03-26 09:57:45 --> Config Class Initialized
INFO - 2018-03-26 09:57:45 --> Hooks Class Initialized
INFO - 2018-03-26 09:57:45 --> Config Class Initialized
INFO - 2018-03-26 09:57:45 --> Hooks Class Initialized
DEBUG - 2018-03-26 09:57:45 --> UTF-8 Support Enabled
INFO - 2018-03-26 09:57:45 --> Utf8 Class Initialized
DEBUG - 2018-03-26 09:57:45 --> UTF-8 Support Enabled
INFO - 2018-03-26 09:57:45 --> Utf8 Class Initialized
INFO - 2018-03-26 09:57:45 --> URI Class Initialized
INFO - 2018-03-26 09:57:45 --> URI Class Initialized
INFO - 2018-03-26 09:57:45 --> Router Class Initialized
INFO - 2018-03-26 09:57:45 --> Output Class Initialized
INFO - 2018-03-26 09:57:45 --> Router Class Initialized
INFO - 2018-03-26 09:57:45 --> Security Class Initialized
INFO - 2018-03-26 09:57:45 --> Output Class Initialized
INFO - 2018-03-26 09:57:45 --> Security Class Initialized
DEBUG - 2018-03-26 09:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 09:57:45 --> Input Class Initialized
DEBUG - 2018-03-26 09:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 09:57:45 --> Input Class Initialized
INFO - 2018-03-26 09:57:45 --> Language Class Initialized
INFO - 2018-03-26 09:57:45 --> Language Class Initialized
INFO - 2018-03-26 09:57:45 --> Language Class Initialized
INFO - 2018-03-26 09:57:45 --> Config Class Initialized
INFO - 2018-03-26 09:57:45 --> Loader Class Initialized
INFO - 2018-03-26 15:27:45 --> Helper loaded: url_helper
INFO - 2018-03-26 15:27:45 --> Helper loaded: notification_helper
INFO - 2018-03-26 15:27:45 --> Helper loaded: settings_helper
INFO - 2018-03-26 15:27:45 --> Helper loaded: permission_helper
INFO - 2018-03-26 15:27:45 --> Helper loaded: users_helper
INFO - 2018-03-26 15:27:45 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:27:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:27:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:27:45 --> Helper loaded: form_helper
INFO - 2018-03-26 15:27:45 --> Form Validation Class Initialized
INFO - 2018-03-26 15:27:45 --> Controller Class Initialized
INFO - 2018-03-26 15:27:45 --> Model Class Initialized
INFO - 2018-03-26 15:27:45 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 15:27:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 15:27:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 15:27:45 --> Model Class Initialized
INFO - 2018-03-26 15:27:45 --> Model Class Initialized
INFO - 2018-03-26 15:27:45 --> Model Class Initialized
INFO - 2018-03-26 15:27:45 --> Model Class Initialized
INFO - 2018-03-26 15:27:45 --> Model Class Initialized
INFO - 2018-03-26 15:27:45 --> Model Class Initialized
INFO - 2018-03-26 15:27:45 --> Model Class Initialized
INFO - 2018-03-26 15:27:45 --> Model Class Initialized
INFO - 2018-03-26 15:27:45 --> Model Class Initialized
INFO - 2018-03-26 15:27:45 --> Model Class Initialized
INFO - 2018-03-26 15:27:45 --> Model Class Initialized
INFO - 2018-03-26 15:27:45 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 15:27:45 --> Model Class Initialized
INFO - 2018-03-26 09:57:45 --> Language Class Initialized
INFO - 2018-03-26 09:57:45 --> Config Class Initialized
INFO - 2018-03-26 09:57:45 --> Loader Class Initialized
INFO - 2018-03-26 15:27:45 --> Final output sent to browser
DEBUG - 2018-03-26 15:27:45 --> Total execution time: 0.9366
INFO - 2018-03-26 15:27:45 --> Helper loaded: url_helper
INFO - 2018-03-26 15:27:46 --> Helper loaded: notification_helper
INFO - 2018-03-26 15:27:46 --> Helper loaded: settings_helper
INFO - 2018-03-26 15:27:46 --> Helper loaded: permission_helper
INFO - 2018-03-26 15:27:46 --> Helper loaded: users_helper
INFO - 2018-03-26 15:27:47 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:27:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:27:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:27:47 --> Helper loaded: form_helper
INFO - 2018-03-26 15:27:47 --> Form Validation Class Initialized
INFO - 2018-03-26 15:27:47 --> Controller Class Initialized
INFO - 2018-03-26 15:27:47 --> Model Class Initialized
INFO - 2018-03-26 15:27:47 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 15:27:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 15:27:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 15:27:47 --> Model Class Initialized
INFO - 2018-03-26 15:27:47 --> Model Class Initialized
INFO - 2018-03-26 15:27:47 --> Model Class Initialized
INFO - 2018-03-26 15:27:47 --> Model Class Initialized
INFO - 2018-03-26 15:27:47 --> Model Class Initialized
INFO - 2018-03-26 15:27:47 --> Model Class Initialized
INFO - 2018-03-26 15:27:47 --> Model Class Initialized
INFO - 2018-03-26 15:27:47 --> Model Class Initialized
INFO - 2018-03-26 15:27:47 --> Model Class Initialized
INFO - 2018-03-26 15:27:47 --> Model Class Initialized
INFO - 2018-03-26 15:27:47 --> Model Class Initialized
INFO - 2018-03-26 15:27:47 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 15:27:47 --> Model Class Initialized
INFO - 2018-03-26 15:27:47 --> Final output sent to browser
DEBUG - 2018-03-26 15:27:47 --> Total execution time: 2.1359
INFO - 2018-03-26 09:57:48 --> Config Class Initialized
INFO - 2018-03-26 09:57:48 --> Hooks Class Initialized
DEBUG - 2018-03-26 09:57:48 --> UTF-8 Support Enabled
INFO - 2018-03-26 09:57:48 --> Utf8 Class Initialized
INFO - 2018-03-26 09:57:48 --> URI Class Initialized
INFO - 2018-03-26 09:57:48 --> Router Class Initialized
INFO - 2018-03-26 09:57:48 --> Output Class Initialized
INFO - 2018-03-26 09:57:48 --> Security Class Initialized
DEBUG - 2018-03-26 09:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 09:57:48 --> Input Class Initialized
INFO - 2018-03-26 09:57:48 --> Language Class Initialized
INFO - 2018-03-26 09:57:49 --> Language Class Initialized
INFO - 2018-03-26 09:57:49 --> Config Class Initialized
INFO - 2018-03-26 09:57:49 --> Loader Class Initialized
INFO - 2018-03-26 15:27:49 --> Helper loaded: url_helper
INFO - 2018-03-26 15:27:49 --> Helper loaded: notification_helper
INFO - 2018-03-26 15:27:49 --> Helper loaded: settings_helper
INFO - 2018-03-26 15:27:49 --> Helper loaded: permission_helper
INFO - 2018-03-26 15:27:49 --> Helper loaded: users_helper
INFO - 2018-03-26 15:27:49 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:27:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:27:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:27:50 --> Helper loaded: form_helper
INFO - 2018-03-26 15:27:50 --> Form Validation Class Initialized
INFO - 2018-03-26 15:27:50 --> Controller Class Initialized
INFO - 2018-03-26 15:27:50 --> Model Class Initialized
INFO - 2018-03-26 15:27:50 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 15:27:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 15:27:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 15:27:50 --> Model Class Initialized
INFO - 2018-03-26 15:27:50 --> Model Class Initialized
INFO - 2018-03-26 15:27:50 --> Model Class Initialized
INFO - 2018-03-26 15:27:50 --> Model Class Initialized
INFO - 2018-03-26 15:27:50 --> Model Class Initialized
INFO - 2018-03-26 15:27:50 --> Model Class Initialized
INFO - 2018-03-26 15:27:50 --> Model Class Initialized
INFO - 2018-03-26 15:27:50 --> Model Class Initialized
INFO - 2018-03-26 15:27:50 --> Model Class Initialized
INFO - 2018-03-26 15:27:50 --> Model Class Initialized
INFO - 2018-03-26 15:27:50 --> Model Class Initialized
INFO - 2018-03-26 15:27:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 15:27:50 --> Model Class Initialized
INFO - 2018-03-26 15:27:50 --> Final output sent to browser
DEBUG - 2018-03-26 15:27:50 --> Total execution time: 1.8183
INFO - 2018-03-26 09:57:53 --> Config Class Initialized
INFO - 2018-03-26 09:57:53 --> Hooks Class Initialized
DEBUG - 2018-03-26 09:57:53 --> UTF-8 Support Enabled
INFO - 2018-03-26 09:57:53 --> Utf8 Class Initialized
INFO - 2018-03-26 09:57:53 --> URI Class Initialized
INFO - 2018-03-26 09:57:53 --> Router Class Initialized
INFO - 2018-03-26 09:57:53 --> Output Class Initialized
INFO - 2018-03-26 09:57:53 --> Security Class Initialized
DEBUG - 2018-03-26 09:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 09:57:53 --> Input Class Initialized
INFO - 2018-03-26 09:57:53 --> Language Class Initialized
INFO - 2018-03-26 09:57:53 --> Language Class Initialized
INFO - 2018-03-26 09:57:53 --> Config Class Initialized
INFO - 2018-03-26 09:57:53 --> Loader Class Initialized
INFO - 2018-03-26 15:27:53 --> Helper loaded: url_helper
INFO - 2018-03-26 15:27:53 --> Helper loaded: notification_helper
INFO - 2018-03-26 15:27:53 --> Helper loaded: settings_helper
INFO - 2018-03-26 15:27:53 --> Helper loaded: permission_helper
INFO - 2018-03-26 15:27:53 --> Helper loaded: users_helper
INFO - 2018-03-26 15:27:53 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:27:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:27:53 --> Helper loaded: form_helper
INFO - 2018-03-26 15:27:53 --> Form Validation Class Initialized
INFO - 2018-03-26 15:27:53 --> Controller Class Initialized
INFO - 2018-03-26 15:27:53 --> Model Class Initialized
INFO - 2018-03-26 15:27:53 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 15:27:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 15:27:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 15:27:53 --> Model Class Initialized
INFO - 2018-03-26 15:27:53 --> Model Class Initialized
INFO - 2018-03-26 15:27:53 --> Model Class Initialized
INFO - 2018-03-26 15:27:53 --> Model Class Initialized
INFO - 2018-03-26 15:27:53 --> Model Class Initialized
INFO - 2018-03-26 15:27:53 --> Model Class Initialized
INFO - 2018-03-26 15:27:53 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-26 15:27:53 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
ERROR - 2018-03-26 15:27:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 784
INFO - 2018-03-26 15:27:53 --> Final output sent to browser
DEBUG - 2018-03-26 15:27:53 --> Total execution time: 0.2472
INFO - 2018-03-26 09:57:58 --> Config Class Initialized
INFO - 2018-03-26 09:57:58 --> Hooks Class Initialized
DEBUG - 2018-03-26 09:57:58 --> UTF-8 Support Enabled
INFO - 2018-03-26 09:57:58 --> Utf8 Class Initialized
INFO - 2018-03-26 09:57:58 --> URI Class Initialized
INFO - 2018-03-26 09:57:58 --> Router Class Initialized
INFO - 2018-03-26 09:57:58 --> Output Class Initialized
INFO - 2018-03-26 09:57:58 --> Security Class Initialized
DEBUG - 2018-03-26 09:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 09:57:58 --> Input Class Initialized
INFO - 2018-03-26 09:57:58 --> Language Class Initialized
INFO - 2018-03-26 09:57:58 --> Language Class Initialized
INFO - 2018-03-26 09:57:58 --> Config Class Initialized
INFO - 2018-03-26 09:57:58 --> Loader Class Initialized
INFO - 2018-03-26 15:27:58 --> Helper loaded: url_helper
INFO - 2018-03-26 15:27:58 --> Helper loaded: notification_helper
INFO - 2018-03-26 15:27:58 --> Helper loaded: settings_helper
INFO - 2018-03-26 15:27:58 --> Helper loaded: permission_helper
INFO - 2018-03-26 15:27:58 --> Helper loaded: users_helper
INFO - 2018-03-26 15:27:58 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:27:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:27:58 --> Helper loaded: form_helper
INFO - 2018-03-26 15:27:58 --> Form Validation Class Initialized
INFO - 2018-03-26 15:27:58 --> Controller Class Initialized
INFO - 2018-03-26 15:27:58 --> Model Class Initialized
INFO - 2018-03-26 15:27:58 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 15:27:58 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 15:27:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 15:27:58 --> Model Class Initialized
INFO - 2018-03-26 15:27:58 --> Model Class Initialized
INFO - 2018-03-26 15:27:58 --> Model Class Initialized
INFO - 2018-03-26 15:27:58 --> Model Class Initialized
INFO - 2018-03-26 15:27:58 --> Model Class Initialized
INFO - 2018-03-26 15:27:58 --> Model Class Initialized
INFO - 2018-03-26 15:27:58 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-26 15:27:58 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
ERROR - 2018-03-26 15:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 784
INFO - 2018-03-26 15:27:58 --> Final output sent to browser
DEBUG - 2018-03-26 15:27:58 --> Total execution time: 0.1155
INFO - 2018-03-26 09:58:06 --> Config Class Initialized
INFO - 2018-03-26 09:58:06 --> Hooks Class Initialized
DEBUG - 2018-03-26 09:58:06 --> UTF-8 Support Enabled
INFO - 2018-03-26 09:58:06 --> Utf8 Class Initialized
INFO - 2018-03-26 09:58:06 --> URI Class Initialized
INFO - 2018-03-26 09:58:06 --> Router Class Initialized
INFO - 2018-03-26 09:58:06 --> Output Class Initialized
INFO - 2018-03-26 09:58:06 --> Security Class Initialized
DEBUG - 2018-03-26 09:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 09:58:06 --> Input Class Initialized
INFO - 2018-03-26 09:58:06 --> Language Class Initialized
INFO - 2018-03-26 09:58:06 --> Language Class Initialized
INFO - 2018-03-26 09:58:06 --> Config Class Initialized
INFO - 2018-03-26 09:58:06 --> Loader Class Initialized
INFO - 2018-03-26 15:28:06 --> Helper loaded: url_helper
INFO - 2018-03-26 15:28:06 --> Helper loaded: notification_helper
INFO - 2018-03-26 15:28:06 --> Helper loaded: settings_helper
INFO - 2018-03-26 15:28:06 --> Helper loaded: permission_helper
INFO - 2018-03-26 15:28:06 --> Helper loaded: users_helper
INFO - 2018-03-26 15:28:06 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:28:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:28:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:28:06 --> Helper loaded: form_helper
INFO - 2018-03-26 15:28:06 --> Form Validation Class Initialized
INFO - 2018-03-26 15:28:06 --> Controller Class Initialized
INFO - 2018-03-26 15:28:06 --> Model Class Initialized
INFO - 2018-03-26 15:28:06 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 15:28:06 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 15:28:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 15:28:06 --> Model Class Initialized
INFO - 2018-03-26 15:28:06 --> Model Class Initialized
INFO - 2018-03-26 15:28:06 --> Model Class Initialized
INFO - 2018-03-26 15:28:06 --> Model Class Initialized
INFO - 2018-03-26 15:28:06 --> Model Class Initialized
INFO - 2018-03-26 15:28:06 --> Model Class Initialized
INFO - 2018-03-26 15:28:06 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-26 15:28:06 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
ERROR - 2018-03-26 15:28:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 784
INFO - 2018-03-26 15:28:06 --> Final output sent to browser
DEBUG - 2018-03-26 15:28:06 --> Total execution time: 0.8894
INFO - 2018-03-26 10:03:40 --> Config Class Initialized
INFO - 2018-03-26 10:03:40 --> Hooks Class Initialized
DEBUG - 2018-03-26 10:03:40 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:03:40 --> Utf8 Class Initialized
INFO - 2018-03-26 10:03:40 --> URI Class Initialized
INFO - 2018-03-26 10:03:40 --> Router Class Initialized
INFO - 2018-03-26 10:03:40 --> Output Class Initialized
INFO - 2018-03-26 10:03:40 --> Security Class Initialized
DEBUG - 2018-03-26 10:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:03:40 --> Input Class Initialized
INFO - 2018-03-26 10:03:40 --> Language Class Initialized
INFO - 2018-03-26 10:03:40 --> Language Class Initialized
INFO - 2018-03-26 10:03:40 --> Config Class Initialized
INFO - 2018-03-26 10:03:40 --> Loader Class Initialized
INFO - 2018-03-26 15:33:40 --> Helper loaded: url_helper
INFO - 2018-03-26 15:33:40 --> Helper loaded: notification_helper
INFO - 2018-03-26 15:33:40 --> Helper loaded: settings_helper
INFO - 2018-03-26 15:33:40 --> Helper loaded: permission_helper
INFO - 2018-03-26 15:33:40 --> Helper loaded: users_helper
INFO - 2018-03-26 15:33:40 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:33:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:33:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:33:40 --> Helper loaded: form_helper
INFO - 2018-03-26 15:33:40 --> Form Validation Class Initialized
INFO - 2018-03-26 15:33:40 --> Controller Class Initialized
INFO - 2018-03-26 15:33:40 --> Model Class Initialized
INFO - 2018-03-26 15:33:40 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 15:33:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 15:33:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 15:33:40 --> Model Class Initialized
INFO - 2018-03-26 15:33:40 --> Model Class Initialized
INFO - 2018-03-26 15:33:40 --> Model Class Initialized
INFO - 2018-03-26 15:33:40 --> Model Class Initialized
INFO - 2018-03-26 15:33:40 --> Model Class Initialized
INFO - 2018-03-26 15:33:40 --> Model Class Initialized
INFO - 2018-03-26 15:33:40 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 15:33:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-26 15:33:40 --> Final output sent to browser
DEBUG - 2018-03-26 15:33:40 --> Total execution time: 0.1154
INFO - 2018-03-26 10:03:41 --> Config Class Initialized
INFO - 2018-03-26 10:03:41 --> Hooks Class Initialized
DEBUG - 2018-03-26 10:03:41 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:03:41 --> Utf8 Class Initialized
INFO - 2018-03-26 10:03:41 --> URI Class Initialized
INFO - 2018-03-26 10:03:41 --> Router Class Initialized
INFO - 2018-03-26 10:03:41 --> Output Class Initialized
INFO - 2018-03-26 10:03:41 --> Security Class Initialized
DEBUG - 2018-03-26 10:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:03:41 --> Input Class Initialized
INFO - 2018-03-26 10:03:41 --> Language Class Initialized
INFO - 2018-03-26 10:03:41 --> Language Class Initialized
INFO - 2018-03-26 10:03:41 --> Config Class Initialized
INFO - 2018-03-26 10:03:41 --> Loader Class Initialized
INFO - 2018-03-26 15:33:41 --> Helper loaded: url_helper
INFO - 2018-03-26 15:33:41 --> Helper loaded: notification_helper
INFO - 2018-03-26 15:33:41 --> Helper loaded: settings_helper
INFO - 2018-03-26 15:33:41 --> Helper loaded: permission_helper
INFO - 2018-03-26 15:33:41 --> Helper loaded: users_helper
INFO - 2018-03-26 15:33:41 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:33:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:33:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:33:42 --> Helper loaded: form_helper
INFO - 2018-03-26 15:33:42 --> Form Validation Class Initialized
INFO - 2018-03-26 15:33:42 --> Controller Class Initialized
INFO - 2018-03-26 15:33:42 --> Model Class Initialized
INFO - 2018-03-26 15:33:42 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 15:33:42 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 15:33:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 15:33:42 --> Model Class Initialized
INFO - 2018-03-26 15:33:42 --> Model Class Initialized
INFO - 2018-03-26 15:33:42 --> Model Class Initialized
INFO - 2018-03-26 15:33:42 --> Model Class Initialized
INFO - 2018-03-26 15:33:42 --> Model Class Initialized
INFO - 2018-03-26 15:33:42 --> Model Class Initialized
INFO - 2018-03-26 15:33:42 --> Model Class Initialized
INFO - 2018-03-26 15:33:42 --> Model Class Initialized
INFO - 2018-03-26 15:33:42 --> Model Class Initialized
INFO - 2018-03-26 15:33:42 --> Model Class Initialized
INFO - 2018-03-26 15:33:42 --> Model Class Initialized
INFO - 2018-03-26 15:33:42 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 15:33:42 --> Model Class Initialized
INFO - 2018-03-26 15:33:42 --> Final output sent to browser
DEBUG - 2018-03-26 15:33:42 --> Total execution time: 0.2660
INFO - 2018-03-26 10:03:43 --> Config Class Initialized
INFO - 2018-03-26 10:03:43 --> Hooks Class Initialized
DEBUG - 2018-03-26 10:03:43 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:03:43 --> Utf8 Class Initialized
INFO - 2018-03-26 10:03:43 --> URI Class Initialized
INFO - 2018-03-26 10:03:43 --> Router Class Initialized
INFO - 2018-03-26 10:03:43 --> Output Class Initialized
INFO - 2018-03-26 10:03:43 --> Security Class Initialized
DEBUG - 2018-03-26 10:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:03:43 --> Input Class Initialized
INFO - 2018-03-26 10:03:43 --> Language Class Initialized
INFO - 2018-03-26 10:03:44 --> Language Class Initialized
INFO - 2018-03-26 10:03:44 --> Config Class Initialized
INFO - 2018-03-26 10:03:44 --> Loader Class Initialized
INFO - 2018-03-26 15:33:44 --> Helper loaded: url_helper
INFO - 2018-03-26 15:33:44 --> Helper loaded: notification_helper
INFO - 2018-03-26 15:33:44 --> Helper loaded: settings_helper
INFO - 2018-03-26 15:33:44 --> Helper loaded: permission_helper
INFO - 2018-03-26 15:33:44 --> Helper loaded: users_helper
INFO - 2018-03-26 15:33:44 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:33:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:33:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:33:44 --> Helper loaded: form_helper
INFO - 2018-03-26 15:33:44 --> Form Validation Class Initialized
INFO - 2018-03-26 15:33:44 --> Controller Class Initialized
INFO - 2018-03-26 15:33:44 --> Model Class Initialized
INFO - 2018-03-26 15:33:44 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 15:33:44 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 15:33:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 15:33:44 --> Model Class Initialized
INFO - 2018-03-26 15:33:44 --> Model Class Initialized
INFO - 2018-03-26 15:33:44 --> Model Class Initialized
INFO - 2018-03-26 15:33:44 --> Model Class Initialized
INFO - 2018-03-26 15:33:44 --> Model Class Initialized
INFO - 2018-03-26 15:33:44 --> Model Class Initialized
INFO - 2018-03-26 15:33:44 --> Model Class Initialized
INFO - 2018-03-26 15:33:44 --> Model Class Initialized
INFO - 2018-03-26 15:33:44 --> Model Class Initialized
INFO - 2018-03-26 15:33:44 --> Model Class Initialized
INFO - 2018-03-26 15:33:44 --> Model Class Initialized
INFO - 2018-03-26 15:33:44 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 15:33:44 --> Model Class Initialized
INFO - 2018-03-26 15:33:44 --> Final output sent to browser
DEBUG - 2018-03-26 15:33:44 --> Total execution time: 0.1312
INFO - 2018-03-26 10:03:44 --> Config Class Initialized
INFO - 2018-03-26 10:03:44 --> Hooks Class Initialized
DEBUG - 2018-03-26 10:03:44 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:03:44 --> Utf8 Class Initialized
INFO - 2018-03-26 10:03:44 --> URI Class Initialized
INFO - 2018-03-26 10:03:44 --> Router Class Initialized
INFO - 2018-03-26 10:03:45 --> Output Class Initialized
INFO - 2018-03-26 10:03:45 --> Security Class Initialized
DEBUG - 2018-03-26 10:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:03:45 --> Input Class Initialized
INFO - 2018-03-26 10:03:45 --> Language Class Initialized
INFO - 2018-03-26 10:03:46 --> Language Class Initialized
INFO - 2018-03-26 10:03:46 --> Config Class Initialized
INFO - 2018-03-26 10:03:46 --> Loader Class Initialized
INFO - 2018-03-26 15:33:46 --> Helper loaded: url_helper
INFO - 2018-03-26 15:33:46 --> Helper loaded: notification_helper
INFO - 2018-03-26 15:33:46 --> Helper loaded: settings_helper
INFO - 2018-03-26 15:33:46 --> Helper loaded: permission_helper
INFO - 2018-03-26 15:33:46 --> Helper loaded: users_helper
INFO - 2018-03-26 15:33:46 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:33:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:33:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:33:46 --> Helper loaded: form_helper
INFO - 2018-03-26 15:33:46 --> Form Validation Class Initialized
INFO - 2018-03-26 15:33:46 --> Controller Class Initialized
INFO - 2018-03-26 15:33:46 --> Model Class Initialized
INFO - 2018-03-26 15:33:46 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 15:33:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 15:33:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 15:33:46 --> Model Class Initialized
INFO - 2018-03-26 15:33:46 --> Model Class Initialized
INFO - 2018-03-26 15:33:46 --> Model Class Initialized
INFO - 2018-03-26 15:33:46 --> Model Class Initialized
INFO - 2018-03-26 15:33:46 --> Model Class Initialized
INFO - 2018-03-26 15:33:46 --> Model Class Initialized
INFO - 2018-03-26 15:33:46 --> Model Class Initialized
INFO - 2018-03-26 15:33:46 --> Model Class Initialized
INFO - 2018-03-26 15:33:46 --> Model Class Initialized
INFO - 2018-03-26 15:33:46 --> Model Class Initialized
INFO - 2018-03-26 15:33:46 --> Model Class Initialized
INFO - 2018-03-26 15:33:46 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 15:33:46 --> Model Class Initialized
INFO - 2018-03-26 15:33:46 --> Final output sent to browser
DEBUG - 2018-03-26 15:33:46 --> Total execution time: 2.7971
INFO - 2018-03-26 10:06:11 --> Config Class Initialized
INFO - 2018-03-26 10:06:11 --> Hooks Class Initialized
DEBUG - 2018-03-26 10:06:11 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:06:11 --> Utf8 Class Initialized
INFO - 2018-03-26 10:06:11 --> URI Class Initialized
INFO - 2018-03-26 10:06:11 --> Router Class Initialized
INFO - 2018-03-26 10:06:11 --> Output Class Initialized
INFO - 2018-03-26 10:06:11 --> Security Class Initialized
DEBUG - 2018-03-26 10:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:06:11 --> Input Class Initialized
INFO - 2018-03-26 10:06:11 --> Language Class Initialized
INFO - 2018-03-26 10:06:12 --> Language Class Initialized
INFO - 2018-03-26 10:06:12 --> Config Class Initialized
INFO - 2018-03-26 10:06:12 --> Loader Class Initialized
INFO - 2018-03-26 15:36:12 --> Helper loaded: url_helper
INFO - 2018-03-26 15:36:12 --> Helper loaded: notification_helper
INFO - 2018-03-26 15:36:12 --> Helper loaded: settings_helper
INFO - 2018-03-26 15:36:12 --> Helper loaded: permission_helper
INFO - 2018-03-26 15:36:12 --> Helper loaded: users_helper
INFO - 2018-03-26 15:36:12 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:36:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:36:12 --> Helper loaded: form_helper
INFO - 2018-03-26 15:36:12 --> Form Validation Class Initialized
INFO - 2018-03-26 15:36:12 --> Controller Class Initialized
INFO - 2018-03-26 15:36:12 --> Model Class Initialized
INFO - 2018-03-26 15:36:12 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 15:36:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 15:36:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 15:36:12 --> Model Class Initialized
INFO - 2018-03-26 15:36:12 --> Model Class Initialized
INFO - 2018-03-26 15:36:12 --> Model Class Initialized
INFO - 2018-03-26 15:36:12 --> Model Class Initialized
INFO - 2018-03-26 15:36:12 --> Model Class Initialized
INFO - 2018-03-26 15:36:12 --> Model Class Initialized
INFO - 2018-03-26 15:36:12 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 15:36:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-26 15:36:12 --> Final output sent to browser
DEBUG - 2018-03-26 15:36:12 --> Total execution time: 0.5663
INFO - 2018-03-26 10:06:13 --> Config Class Initialized
INFO - 2018-03-26 10:06:13 --> Hooks Class Initialized
DEBUG - 2018-03-26 10:06:13 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:06:13 --> Utf8 Class Initialized
INFO - 2018-03-26 10:06:13 --> URI Class Initialized
INFO - 2018-03-26 10:06:13 --> Router Class Initialized
INFO - 2018-03-26 10:06:13 --> Output Class Initialized
INFO - 2018-03-26 10:06:13 --> Security Class Initialized
DEBUG - 2018-03-26 10:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:06:13 --> Input Class Initialized
INFO - 2018-03-26 10:06:13 --> Language Class Initialized
INFO - 2018-03-26 10:06:13 --> Language Class Initialized
INFO - 2018-03-26 10:06:13 --> Config Class Initialized
INFO - 2018-03-26 10:06:13 --> Loader Class Initialized
INFO - 2018-03-26 15:36:13 --> Helper loaded: url_helper
INFO - 2018-03-26 15:36:13 --> Helper loaded: notification_helper
INFO - 2018-03-26 15:36:13 --> Helper loaded: settings_helper
INFO - 2018-03-26 15:36:13 --> Helper loaded: permission_helper
INFO - 2018-03-26 15:36:13 --> Helper loaded: users_helper
INFO - 2018-03-26 15:36:13 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:36:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:36:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:36:13 --> Helper loaded: form_helper
INFO - 2018-03-26 15:36:13 --> Form Validation Class Initialized
INFO - 2018-03-26 15:36:13 --> Controller Class Initialized
INFO - 2018-03-26 15:36:13 --> Model Class Initialized
INFO - 2018-03-26 15:36:13 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 15:36:13 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 15:36:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 15:36:13 --> Model Class Initialized
INFO - 2018-03-26 15:36:13 --> Model Class Initialized
INFO - 2018-03-26 15:36:13 --> Model Class Initialized
INFO - 2018-03-26 15:36:13 --> Model Class Initialized
INFO - 2018-03-26 15:36:13 --> Model Class Initialized
INFO - 2018-03-26 15:36:13 --> Model Class Initialized
INFO - 2018-03-26 15:36:13 --> Model Class Initialized
INFO - 2018-03-26 15:36:13 --> Model Class Initialized
INFO - 2018-03-26 15:36:13 --> Model Class Initialized
INFO - 2018-03-26 15:36:13 --> Model Class Initialized
INFO - 2018-03-26 15:36:13 --> Model Class Initialized
INFO - 2018-03-26 15:36:13 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 15:36:13 --> Model Class Initialized
INFO - 2018-03-26 15:36:13 --> Final output sent to browser
DEBUG - 2018-03-26 15:36:13 --> Total execution time: 0.1180
INFO - 2018-03-26 10:06:13 --> Config Class Initialized
INFO - 2018-03-26 10:06:13 --> Hooks Class Initialized
DEBUG - 2018-03-26 10:06:13 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:06:13 --> Utf8 Class Initialized
INFO - 2018-03-26 10:06:13 --> URI Class Initialized
INFO - 2018-03-26 10:06:13 --> Router Class Initialized
INFO - 2018-03-26 10:06:13 --> Output Class Initialized
INFO - 2018-03-26 10:06:13 --> Security Class Initialized
DEBUG - 2018-03-26 10:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:06:13 --> Input Class Initialized
INFO - 2018-03-26 10:06:13 --> Language Class Initialized
INFO - 2018-03-26 10:06:13 --> Language Class Initialized
INFO - 2018-03-26 10:06:13 --> Config Class Initialized
INFO - 2018-03-26 10:06:13 --> Loader Class Initialized
INFO - 2018-03-26 15:36:13 --> Helper loaded: url_helper
INFO - 2018-03-26 15:36:13 --> Helper loaded: notification_helper
INFO - 2018-03-26 15:36:13 --> Helper loaded: settings_helper
INFO - 2018-03-26 15:36:13 --> Helper loaded: permission_helper
INFO - 2018-03-26 15:36:13 --> Helper loaded: users_helper
INFO - 2018-03-26 15:36:13 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:36:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:36:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:36:13 --> Helper loaded: form_helper
INFO - 2018-03-26 15:36:13 --> Form Validation Class Initialized
INFO - 2018-03-26 15:36:13 --> Controller Class Initialized
INFO - 2018-03-26 15:36:13 --> Model Class Initialized
INFO - 2018-03-26 15:36:13 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 15:36:13 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 15:36:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 15:36:13 --> Model Class Initialized
INFO - 2018-03-26 15:36:13 --> Model Class Initialized
INFO - 2018-03-26 15:36:13 --> Model Class Initialized
INFO - 2018-03-26 15:36:13 --> Model Class Initialized
INFO - 2018-03-26 15:36:13 --> Model Class Initialized
INFO - 2018-03-26 15:36:13 --> Model Class Initialized
INFO - 2018-03-26 15:36:13 --> Model Class Initialized
INFO - 2018-03-26 15:36:13 --> Model Class Initialized
INFO - 2018-03-26 15:36:13 --> Model Class Initialized
INFO - 2018-03-26 15:36:13 --> Model Class Initialized
INFO - 2018-03-26 15:36:13 --> Model Class Initialized
INFO - 2018-03-26 15:36:13 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 15:36:13 --> Model Class Initialized
INFO - 2018-03-26 15:36:13 --> Final output sent to browser
DEBUG - 2018-03-26 15:36:13 --> Total execution time: 0.0992
INFO - 2018-03-26 10:06:15 --> Config Class Initialized
INFO - 2018-03-26 10:06:15 --> Hooks Class Initialized
DEBUG - 2018-03-26 10:06:15 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:06:15 --> Utf8 Class Initialized
INFO - 2018-03-26 10:06:15 --> URI Class Initialized
INFO - 2018-03-26 10:06:15 --> Router Class Initialized
INFO - 2018-03-26 10:06:15 --> Output Class Initialized
INFO - 2018-03-26 10:06:15 --> Security Class Initialized
DEBUG - 2018-03-26 10:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:06:15 --> Input Class Initialized
INFO - 2018-03-26 10:06:15 --> Language Class Initialized
INFO - 2018-03-26 10:06:15 --> Language Class Initialized
INFO - 2018-03-26 10:06:15 --> Config Class Initialized
INFO - 2018-03-26 10:06:15 --> Loader Class Initialized
INFO - 2018-03-26 15:36:15 --> Helper loaded: url_helper
INFO - 2018-03-26 15:36:15 --> Helper loaded: notification_helper
INFO - 2018-03-26 15:36:15 --> Helper loaded: settings_helper
INFO - 2018-03-26 15:36:15 --> Helper loaded: permission_helper
INFO - 2018-03-26 15:36:15 --> Helper loaded: users_helper
INFO - 2018-03-26 15:36:15 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:36:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:36:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:36:15 --> Helper loaded: form_helper
INFO - 2018-03-26 15:36:15 --> Form Validation Class Initialized
INFO - 2018-03-26 15:36:15 --> Controller Class Initialized
INFO - 2018-03-26 15:36:15 --> Model Class Initialized
INFO - 2018-03-26 15:36:15 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 15:36:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 15:36:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 15:36:15 --> Model Class Initialized
INFO - 2018-03-26 15:36:15 --> Model Class Initialized
INFO - 2018-03-26 15:36:15 --> Model Class Initialized
INFO - 2018-03-26 15:36:15 --> Model Class Initialized
INFO - 2018-03-26 15:36:15 --> Model Class Initialized
INFO - 2018-03-26 15:36:15 --> Model Class Initialized
INFO - 2018-03-26 15:36:15 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-26 15:36:15 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-26 15:36:15 --> Final output sent to browser
DEBUG - 2018-03-26 15:36:15 --> Total execution time: 0.2485
INFO - 2018-03-26 10:06:25 --> Config Class Initialized
INFO - 2018-03-26 10:06:25 --> Hooks Class Initialized
DEBUG - 2018-03-26 10:06:25 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:06:25 --> Utf8 Class Initialized
INFO - 2018-03-26 10:06:25 --> URI Class Initialized
INFO - 2018-03-26 10:06:25 --> Router Class Initialized
INFO - 2018-03-26 10:06:25 --> Output Class Initialized
INFO - 2018-03-26 10:06:26 --> Security Class Initialized
DEBUG - 2018-03-26 10:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:06:26 --> Input Class Initialized
INFO - 2018-03-26 10:06:26 --> Language Class Initialized
INFO - 2018-03-26 10:06:26 --> Language Class Initialized
INFO - 2018-03-26 10:06:26 --> Config Class Initialized
INFO - 2018-03-26 10:06:26 --> Loader Class Initialized
INFO - 2018-03-26 15:36:27 --> Helper loaded: url_helper
INFO - 2018-03-26 15:36:27 --> Helper loaded: notification_helper
INFO - 2018-03-26 15:36:27 --> Helper loaded: settings_helper
INFO - 2018-03-26 15:36:27 --> Helper loaded: permission_helper
INFO - 2018-03-26 15:36:27 --> Helper loaded: users_helper
INFO - 2018-03-26 15:36:27 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:36:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:36:27 --> Helper loaded: form_helper
INFO - 2018-03-26 15:36:27 --> Form Validation Class Initialized
INFO - 2018-03-26 15:36:27 --> Controller Class Initialized
INFO - 2018-03-26 15:36:27 --> Model Class Initialized
INFO - 2018-03-26 15:36:27 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 15:36:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 15:36:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 15:36:28 --> Model Class Initialized
INFO - 2018-03-26 15:36:28 --> Model Class Initialized
INFO - 2018-03-26 15:36:28 --> Model Class Initialized
INFO - 2018-03-26 15:36:28 --> Model Class Initialized
INFO - 2018-03-26 15:36:28 --> Model Class Initialized
INFO - 2018-03-26 15:36:28 --> Model Class Initialized
INFO - 2018-03-26 15:36:28 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-26 15:36:28 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-26 15:36:28 --> Final output sent to browser
DEBUG - 2018-03-26 15:36:28 --> Total execution time: 2.6926
INFO - 2018-03-26 10:09:04 --> Config Class Initialized
INFO - 2018-03-26 10:09:04 --> Hooks Class Initialized
DEBUG - 2018-03-26 10:09:04 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:09:04 --> Utf8 Class Initialized
INFO - 2018-03-26 10:09:04 --> URI Class Initialized
INFO - 2018-03-26 10:09:04 --> Router Class Initialized
INFO - 2018-03-26 10:09:04 --> Output Class Initialized
INFO - 2018-03-26 10:09:04 --> Security Class Initialized
DEBUG - 2018-03-26 10:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:09:04 --> Input Class Initialized
INFO - 2018-03-26 10:09:04 --> Language Class Initialized
INFO - 2018-03-26 10:09:04 --> Language Class Initialized
INFO - 2018-03-26 10:09:04 --> Config Class Initialized
INFO - 2018-03-26 10:09:04 --> Loader Class Initialized
INFO - 2018-03-26 15:39:04 --> Helper loaded: url_helper
INFO - 2018-03-26 15:39:04 --> Helper loaded: notification_helper
INFO - 2018-03-26 15:39:04 --> Helper loaded: settings_helper
INFO - 2018-03-26 15:39:04 --> Helper loaded: permission_helper
INFO - 2018-03-26 15:39:04 --> Helper loaded: users_helper
INFO - 2018-03-26 15:39:04 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:39:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:39:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:39:04 --> Helper loaded: form_helper
INFO - 2018-03-26 15:39:04 --> Form Validation Class Initialized
INFO - 2018-03-26 15:39:04 --> Controller Class Initialized
INFO - 2018-03-26 15:39:04 --> Model Class Initialized
INFO - 2018-03-26 15:39:04 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 15:39:04 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 15:39:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 15:39:04 --> Model Class Initialized
INFO - 2018-03-26 15:39:04 --> Model Class Initialized
INFO - 2018-03-26 15:39:04 --> Model Class Initialized
INFO - 2018-03-26 15:39:04 --> Model Class Initialized
INFO - 2018-03-26 15:39:04 --> Model Class Initialized
INFO - 2018-03-26 15:39:04 --> Model Class Initialized
INFO - 2018-03-26 15:39:04 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 15:39:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-26 15:39:04 --> Final output sent to browser
DEBUG - 2018-03-26 15:39:04 --> Total execution time: 0.5611
INFO - 2018-03-26 10:09:06 --> Config Class Initialized
INFO - 2018-03-26 10:09:06 --> Hooks Class Initialized
DEBUG - 2018-03-26 10:09:06 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:09:06 --> Utf8 Class Initialized
INFO - 2018-03-26 10:09:06 --> URI Class Initialized
INFO - 2018-03-26 10:09:06 --> Router Class Initialized
INFO - 2018-03-26 10:09:06 --> Output Class Initialized
INFO - 2018-03-26 10:09:06 --> Security Class Initialized
DEBUG - 2018-03-26 10:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:09:06 --> Input Class Initialized
INFO - 2018-03-26 10:09:06 --> Language Class Initialized
INFO - 2018-03-26 10:09:06 --> Config Class Initialized
INFO - 2018-03-26 10:09:06 --> Hooks Class Initialized
DEBUG - 2018-03-26 10:09:06 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:09:06 --> Utf8 Class Initialized
INFO - 2018-03-26 10:09:06 --> URI Class Initialized
INFO - 2018-03-26 10:09:07 --> Router Class Initialized
INFO - 2018-03-26 10:09:07 --> Output Class Initialized
INFO - 2018-03-26 10:09:07 --> Security Class Initialized
DEBUG - 2018-03-26 10:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:09:07 --> Input Class Initialized
INFO - 2018-03-26 10:09:07 --> Language Class Initialized
INFO - 2018-03-26 10:09:07 --> Config Class Initialized
INFO - 2018-03-26 10:09:07 --> Loader Class Initialized
INFO - 2018-03-26 10:09:07 --> Language Class Initialized
INFO - 2018-03-26 15:39:07 --> Helper loaded: url_helper
INFO - 2018-03-26 15:39:07 --> Helper loaded: notification_helper
INFO - 2018-03-26 15:39:07 --> Helper loaded: settings_helper
INFO - 2018-03-26 15:39:07 --> Helper loaded: permission_helper
INFO - 2018-03-26 15:39:07 --> Helper loaded: users_helper
INFO - 2018-03-26 10:09:08 --> Language Class Initialized
INFO - 2018-03-26 10:09:08 --> Config Class Initialized
INFO - 2018-03-26 10:09:08 --> Loader Class Initialized
INFO - 2018-03-26 10:09:08 --> Config Class Initialized
INFO - 2018-03-26 10:09:08 --> Hooks Class Initialized
DEBUG - 2018-03-26 10:09:08 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:09:08 --> Utf8 Class Initialized
INFO - 2018-03-26 10:09:08 --> URI Class Initialized
INFO - 2018-03-26 10:09:08 --> Router Class Initialized
INFO - 2018-03-26 10:09:08 --> Output Class Initialized
INFO - 2018-03-26 10:09:08 --> Security Class Initialized
DEBUG - 2018-03-26 10:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:09:08 --> Input Class Initialized
INFO - 2018-03-26 10:09:08 --> Language Class Initialized
INFO - 2018-03-26 10:09:08 --> Language Class Initialized
INFO - 2018-03-26 10:09:08 --> Config Class Initialized
INFO - 2018-03-26 10:09:08 --> Loader Class Initialized
INFO - 2018-03-26 15:39:08 --> Helper loaded: url_helper
INFO - 2018-03-26 15:39:08 --> Helper loaded: notification_helper
INFO - 2018-03-26 15:39:08 --> Helper loaded: settings_helper
INFO - 2018-03-26 15:39:08 --> Helper loaded: permission_helper
INFO - 2018-03-26 15:39:08 --> Helper loaded: users_helper
INFO - 2018-03-26 15:39:08 --> Database Driver Class Initialized
INFO - 2018-03-26 15:39:08 --> Helper loaded: url_helper
DEBUG - 2018-03-26 15:39:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:39:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:39:08 --> Database Driver Class Initialized
INFO - 2018-03-26 15:39:08 --> Helper loaded: notification_helper
INFO - 2018-03-26 15:39:08 --> Helper loaded: form_helper
INFO - 2018-03-26 15:39:08 --> Form Validation Class Initialized
INFO - 2018-03-26 15:39:08 --> Controller Class Initialized
DEBUG - 2018-03-26 15:39:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:39:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:39:08 --> Model Class Initialized
INFO - 2018-03-26 15:39:08 --> Helper loaded: inflector_helper
INFO - 2018-03-26 15:39:08 --> Helper loaded: form_helper
INFO - 2018-03-26 15:39:08 --> Form Validation Class Initialized
INFO - 2018-03-26 15:39:08 --> Controller Class Initialized
INFO - 2018-03-26 15:39:08 --> Helper loaded: settings_helper
DEBUG - 2018-03-26 15:39:08 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 15:39:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 15:39:08 --> Model Class Initialized
INFO - 2018-03-26 15:39:08 --> Model Class Initialized
INFO - 2018-03-26 15:39:08 --> Helper loaded: inflector_helper
INFO - 2018-03-26 15:39:08 --> Model Class Initialized
INFO - 2018-03-26 15:39:08 --> Model Class Initialized
INFO - 2018-03-26 15:39:08 --> Model Class Initialized
INFO - 2018-03-26 15:39:08 --> Model Class Initialized
DEBUG - 2018-03-26 15:39:08 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 15:39:08 --> Model Class Initialized
INFO - 2018-03-26 15:39:08 --> Model Class Initialized
INFO - 2018-03-26 15:39:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 15:39:08 --> Model Class Initialized
INFO - 2018-03-26 15:39:08 --> Model Class Initialized
INFO - 2018-03-26 15:39:08 --> Model Class Initialized
INFO - 2018-03-26 15:39:08 --> Model Class Initialized
INFO - 2018-03-26 15:39:08 --> Model Class Initialized
INFO - 2018-03-26 15:39:08 --> Helper loaded: permission_helper
INFO - 2018-03-26 15:39:08 --> Model Class Initialized
INFO - 2018-03-26 15:39:08 --> Model Class Initialized
INFO - 2018-03-26 15:39:08 --> Model Class Initialized
INFO - 2018-03-26 15:39:08 --> Model Class Initialized
INFO - 2018-03-26 15:39:08 --> Model Class Initialized
INFO - 2018-03-26 15:39:08 --> Model Class Initialized
INFO - 2018-03-26 15:39:08 --> Model Class Initialized
INFO - 2018-03-26 15:39:08 --> Model Class Initialized
INFO - 2018-03-26 15:39:08 --> Model Class Initialized
INFO - 2018-03-26 15:39:08 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 15:39:08 --> Model Class Initialized
INFO - 2018-03-26 15:39:08 --> Model Class Initialized
INFO - 2018-03-26 15:39:08 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 15:39:08 --> Model Class Initialized
INFO - 2018-03-26 15:39:08 --> Final output sent to browser
DEBUG - 2018-03-26 15:39:08 --> Total execution time: 0.3420
INFO - 2018-03-26 15:39:08 --> Final output sent to browser
DEBUG - 2018-03-26 15:39:08 --> Total execution time: 2.0540
INFO - 2018-03-26 15:39:08 --> Helper loaded: users_helper
INFO - 2018-03-26 15:39:09 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:39:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:39:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:39:09 --> Helper loaded: form_helper
INFO - 2018-03-26 15:39:09 --> Form Validation Class Initialized
INFO - 2018-03-26 15:39:09 --> Controller Class Initialized
INFO - 2018-03-26 15:39:09 --> Model Class Initialized
INFO - 2018-03-26 15:39:09 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 15:39:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 15:39:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 15:39:09 --> Model Class Initialized
INFO - 2018-03-26 15:39:09 --> Model Class Initialized
INFO - 2018-03-26 15:39:09 --> Model Class Initialized
INFO - 2018-03-26 15:39:09 --> Model Class Initialized
INFO - 2018-03-26 15:39:09 --> Model Class Initialized
INFO - 2018-03-26 15:39:09 --> Model Class Initialized
INFO - 2018-03-26 15:39:09 --> Model Class Initialized
INFO - 2018-03-26 15:39:09 --> Model Class Initialized
INFO - 2018-03-26 15:39:09 --> Model Class Initialized
INFO - 2018-03-26 15:39:09 --> Model Class Initialized
INFO - 2018-03-26 15:39:09 --> Model Class Initialized
INFO - 2018-03-26 15:39:09 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 15:39:09 --> Model Class Initialized
INFO - 2018-03-26 15:39:09 --> Final output sent to browser
DEBUG - 2018-03-26 15:39:09 --> Total execution time: 2.6612
INFO - 2018-03-26 10:09:11 --> Config Class Initialized
INFO - 2018-03-26 10:09:11 --> Hooks Class Initialized
DEBUG - 2018-03-26 10:09:11 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:09:11 --> Utf8 Class Initialized
INFO - 2018-03-26 10:09:11 --> URI Class Initialized
INFO - 2018-03-26 10:09:11 --> Router Class Initialized
INFO - 2018-03-26 10:09:11 --> Output Class Initialized
INFO - 2018-03-26 10:09:11 --> Security Class Initialized
DEBUG - 2018-03-26 10:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:09:11 --> Input Class Initialized
INFO - 2018-03-26 10:09:11 --> Language Class Initialized
INFO - 2018-03-26 10:09:11 --> Language Class Initialized
INFO - 2018-03-26 10:09:11 --> Config Class Initialized
INFO - 2018-03-26 10:09:11 --> Loader Class Initialized
INFO - 2018-03-26 15:39:11 --> Helper loaded: url_helper
INFO - 2018-03-26 15:39:11 --> Helper loaded: notification_helper
INFO - 2018-03-26 15:39:11 --> Helper loaded: settings_helper
INFO - 2018-03-26 15:39:11 --> Helper loaded: permission_helper
INFO - 2018-03-26 15:39:11 --> Helper loaded: users_helper
INFO - 2018-03-26 15:39:12 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:39:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:39:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:39:12 --> Helper loaded: form_helper
INFO - 2018-03-26 15:39:12 --> Form Validation Class Initialized
INFO - 2018-03-26 15:39:12 --> Controller Class Initialized
INFO - 2018-03-26 15:39:12 --> Model Class Initialized
INFO - 2018-03-26 15:39:12 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 15:39:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 15:39:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 15:39:12 --> Model Class Initialized
INFO - 2018-03-26 15:39:12 --> Model Class Initialized
INFO - 2018-03-26 15:39:12 --> Model Class Initialized
INFO - 2018-03-26 15:39:12 --> Model Class Initialized
INFO - 2018-03-26 15:39:12 --> Model Class Initialized
INFO - 2018-03-26 15:39:12 --> Model Class Initialized
INFO - 2018-03-26 15:39:12 --> Model Class Initialized
INFO - 2018-03-26 15:39:12 --> Model Class Initialized
INFO - 2018-03-26 15:39:12 --> Model Class Initialized
INFO - 2018-03-26 15:39:12 --> Model Class Initialized
INFO - 2018-03-26 15:39:12 --> Model Class Initialized
INFO - 2018-03-26 15:39:12 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 15:39:12 --> Model Class Initialized
INFO - 2018-03-26 15:39:12 --> Final output sent to browser
DEBUG - 2018-03-26 15:39:12 --> Total execution time: 0.8415
INFO - 2018-03-26 10:09:15 --> Config Class Initialized
INFO - 2018-03-26 10:09:15 --> Hooks Class Initialized
DEBUG - 2018-03-26 10:09:15 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:09:15 --> Utf8 Class Initialized
INFO - 2018-03-26 10:09:15 --> URI Class Initialized
INFO - 2018-03-26 10:09:15 --> Router Class Initialized
INFO - 2018-03-26 10:09:15 --> Output Class Initialized
INFO - 2018-03-26 10:09:15 --> Security Class Initialized
DEBUG - 2018-03-26 10:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:09:15 --> Input Class Initialized
INFO - 2018-03-26 10:09:15 --> Language Class Initialized
INFO - 2018-03-26 10:09:15 --> Language Class Initialized
INFO - 2018-03-26 10:09:15 --> Config Class Initialized
INFO - 2018-03-26 10:09:15 --> Loader Class Initialized
INFO - 2018-03-26 15:39:15 --> Helper loaded: url_helper
INFO - 2018-03-26 15:39:15 --> Helper loaded: notification_helper
INFO - 2018-03-26 15:39:15 --> Helper loaded: settings_helper
INFO - 2018-03-26 15:39:15 --> Helper loaded: permission_helper
INFO - 2018-03-26 15:39:15 --> Helper loaded: users_helper
INFO - 2018-03-26 15:39:15 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:39:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:39:15 --> Helper loaded: form_helper
INFO - 2018-03-26 15:39:15 --> Form Validation Class Initialized
INFO - 2018-03-26 15:39:15 --> Controller Class Initialized
INFO - 2018-03-26 15:39:15 --> Model Class Initialized
INFO - 2018-03-26 15:39:15 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 15:39:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 15:39:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 15:39:15 --> Model Class Initialized
INFO - 2018-03-26 15:39:15 --> Model Class Initialized
INFO - 2018-03-26 15:39:15 --> Model Class Initialized
INFO - 2018-03-26 15:39:15 --> Model Class Initialized
INFO - 2018-03-26 15:39:15 --> Model Class Initialized
INFO - 2018-03-26 15:39:15 --> Model Class Initialized
INFO - 2018-03-26 15:39:15 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-26 15:39:15 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
ERROR - 2018-03-26 15:39:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 784
INFO - 2018-03-26 15:39:15 --> Final output sent to browser
DEBUG - 2018-03-26 15:39:15 --> Total execution time: 0.2498
INFO - 2018-03-26 10:11:39 --> Config Class Initialized
INFO - 2018-03-26 10:11:39 --> Hooks Class Initialized
DEBUG - 2018-03-26 10:11:39 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:11:39 --> Utf8 Class Initialized
INFO - 2018-03-26 10:11:39 --> URI Class Initialized
INFO - 2018-03-26 10:11:39 --> Router Class Initialized
INFO - 2018-03-26 10:11:39 --> Output Class Initialized
INFO - 2018-03-26 10:11:39 --> Security Class Initialized
DEBUG - 2018-03-26 10:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:11:39 --> Input Class Initialized
INFO - 2018-03-26 10:11:39 --> Language Class Initialized
INFO - 2018-03-26 10:11:39 --> Language Class Initialized
INFO - 2018-03-26 10:11:39 --> Config Class Initialized
INFO - 2018-03-26 10:11:39 --> Loader Class Initialized
INFO - 2018-03-26 15:41:39 --> Helper loaded: url_helper
INFO - 2018-03-26 15:41:39 --> Helper loaded: notification_helper
INFO - 2018-03-26 15:41:39 --> Helper loaded: settings_helper
INFO - 2018-03-26 15:41:39 --> Helper loaded: permission_helper
INFO - 2018-03-26 15:41:39 --> Helper loaded: users_helper
INFO - 2018-03-26 15:41:39 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:41:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:41:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:41:40 --> Helper loaded: form_helper
INFO - 2018-03-26 15:41:40 --> Form Validation Class Initialized
INFO - 2018-03-26 15:41:40 --> Controller Class Initialized
INFO - 2018-03-26 15:41:40 --> Model Class Initialized
INFO - 2018-03-26 15:41:40 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 15:41:41 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 15:41:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 15:41:41 --> Model Class Initialized
INFO - 2018-03-26 15:41:41 --> Model Class Initialized
INFO - 2018-03-26 15:41:41 --> Model Class Initialized
INFO - 2018-03-26 15:41:41 --> Model Class Initialized
INFO - 2018-03-26 15:41:41 --> Model Class Initialized
INFO - 2018-03-26 15:41:41 --> Model Class Initialized
INFO - 2018-03-26 15:41:41 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 15:41:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-26 15:41:41 --> Final output sent to browser
DEBUG - 2018-03-26 15:41:41 --> Total execution time: 2.0932
INFO - 2018-03-26 10:11:42 --> Config Class Initialized
INFO - 2018-03-26 10:11:42 --> Hooks Class Initialized
DEBUG - 2018-03-26 10:11:42 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:11:42 --> Utf8 Class Initialized
INFO - 2018-03-26 10:11:42 --> URI Class Initialized
INFO - 2018-03-26 10:11:42 --> Router Class Initialized
INFO - 2018-03-26 10:11:42 --> Output Class Initialized
INFO - 2018-03-26 10:11:42 --> Security Class Initialized
DEBUG - 2018-03-26 10:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:11:42 --> Input Class Initialized
INFO - 2018-03-26 10:11:42 --> Language Class Initialized
INFO - 2018-03-26 10:11:42 --> Language Class Initialized
INFO - 2018-03-26 10:11:42 --> Config Class Initialized
INFO - 2018-03-26 10:11:42 --> Loader Class Initialized
INFO - 2018-03-26 15:41:42 --> Helper loaded: url_helper
INFO - 2018-03-26 15:41:42 --> Helper loaded: notification_helper
INFO - 2018-03-26 15:41:42 --> Helper loaded: settings_helper
INFO - 2018-03-26 15:41:42 --> Helper loaded: permission_helper
INFO - 2018-03-26 15:41:42 --> Helper loaded: users_helper
INFO - 2018-03-26 15:41:42 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:41:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:41:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:41:42 --> Helper loaded: form_helper
INFO - 2018-03-26 15:41:42 --> Form Validation Class Initialized
INFO - 2018-03-26 15:41:42 --> Controller Class Initialized
INFO - 2018-03-26 15:41:42 --> Model Class Initialized
INFO - 2018-03-26 15:41:42 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 15:41:42 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 15:41:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 15:41:42 --> Model Class Initialized
INFO - 2018-03-26 15:41:42 --> Model Class Initialized
INFO - 2018-03-26 15:41:42 --> Model Class Initialized
INFO - 2018-03-26 15:41:42 --> Model Class Initialized
INFO - 2018-03-26 15:41:42 --> Model Class Initialized
INFO - 2018-03-26 15:41:42 --> Model Class Initialized
INFO - 2018-03-26 15:41:42 --> Model Class Initialized
INFO - 2018-03-26 15:41:42 --> Model Class Initialized
INFO - 2018-03-26 15:41:42 --> Model Class Initialized
INFO - 2018-03-26 15:41:42 --> Model Class Initialized
INFO - 2018-03-26 15:41:42 --> Model Class Initialized
INFO - 2018-03-26 15:41:42 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 15:41:42 --> Model Class Initialized
INFO - 2018-03-26 15:41:42 --> Final output sent to browser
DEBUG - 2018-03-26 15:41:42 --> Total execution time: 0.1199
INFO - 2018-03-26 10:11:42 --> Config Class Initialized
INFO - 2018-03-26 10:11:42 --> Hooks Class Initialized
DEBUG - 2018-03-26 10:11:42 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:11:42 --> Utf8 Class Initialized
INFO - 2018-03-26 10:11:42 --> URI Class Initialized
INFO - 2018-03-26 10:11:42 --> Router Class Initialized
INFO - 2018-03-26 10:11:42 --> Output Class Initialized
INFO - 2018-03-26 10:11:42 --> Security Class Initialized
DEBUG - 2018-03-26 10:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:11:42 --> Input Class Initialized
INFO - 2018-03-26 10:11:42 --> Language Class Initialized
INFO - 2018-03-26 10:11:42 --> Language Class Initialized
INFO - 2018-03-26 10:11:42 --> Config Class Initialized
INFO - 2018-03-26 10:11:42 --> Loader Class Initialized
INFO - 2018-03-26 15:41:42 --> Helper loaded: url_helper
INFO - 2018-03-26 15:41:42 --> Helper loaded: notification_helper
INFO - 2018-03-26 15:41:42 --> Helper loaded: settings_helper
INFO - 2018-03-26 15:41:42 --> Helper loaded: permission_helper
INFO - 2018-03-26 15:41:42 --> Helper loaded: users_helper
INFO - 2018-03-26 15:41:42 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:41:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:41:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:41:42 --> Helper loaded: form_helper
INFO - 2018-03-26 15:41:42 --> Form Validation Class Initialized
INFO - 2018-03-26 15:41:42 --> Controller Class Initialized
INFO - 2018-03-26 15:41:42 --> Model Class Initialized
INFO - 2018-03-26 15:41:42 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 15:41:42 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 15:41:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 15:41:42 --> Model Class Initialized
INFO - 2018-03-26 15:41:42 --> Model Class Initialized
INFO - 2018-03-26 15:41:42 --> Model Class Initialized
INFO - 2018-03-26 15:41:42 --> Model Class Initialized
INFO - 2018-03-26 15:41:42 --> Model Class Initialized
INFO - 2018-03-26 15:41:42 --> Model Class Initialized
INFO - 2018-03-26 15:41:42 --> Model Class Initialized
INFO - 2018-03-26 15:41:42 --> Model Class Initialized
INFO - 2018-03-26 15:41:42 --> Model Class Initialized
INFO - 2018-03-26 15:41:42 --> Model Class Initialized
INFO - 2018-03-26 15:41:42 --> Model Class Initialized
INFO - 2018-03-26 15:41:42 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 15:41:42 --> Model Class Initialized
INFO - 2018-03-26 15:41:42 --> Final output sent to browser
DEBUG - 2018-03-26 15:41:42 --> Total execution time: 0.2475
INFO - 2018-03-26 10:11:44 --> Config Class Initialized
INFO - 2018-03-26 10:11:44 --> Hooks Class Initialized
DEBUG - 2018-03-26 10:11:44 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:11:44 --> Utf8 Class Initialized
INFO - 2018-03-26 10:11:44 --> URI Class Initialized
INFO - 2018-03-26 10:11:44 --> Router Class Initialized
INFO - 2018-03-26 10:11:44 --> Output Class Initialized
INFO - 2018-03-26 10:11:44 --> Security Class Initialized
DEBUG - 2018-03-26 10:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:11:44 --> Input Class Initialized
INFO - 2018-03-26 10:11:44 --> Language Class Initialized
INFO - 2018-03-26 10:11:45 --> Language Class Initialized
INFO - 2018-03-26 10:11:45 --> Config Class Initialized
INFO - 2018-03-26 10:11:45 --> Loader Class Initialized
INFO - 2018-03-26 15:41:45 --> Helper loaded: url_helper
INFO - 2018-03-26 15:41:45 --> Helper loaded: notification_helper
INFO - 2018-03-26 15:41:45 --> Helper loaded: settings_helper
INFO - 2018-03-26 15:41:45 --> Helper loaded: permission_helper
INFO - 2018-03-26 15:41:45 --> Helper loaded: users_helper
INFO - 2018-03-26 15:41:46 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:41:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:41:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:41:46 --> Helper loaded: form_helper
INFO - 2018-03-26 15:41:46 --> Form Validation Class Initialized
INFO - 2018-03-26 15:41:46 --> Controller Class Initialized
INFO - 2018-03-26 15:41:46 --> Model Class Initialized
INFO - 2018-03-26 15:41:46 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 15:41:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 15:41:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 15:41:46 --> Model Class Initialized
INFO - 2018-03-26 15:41:46 --> Model Class Initialized
INFO - 2018-03-26 15:41:46 --> Model Class Initialized
INFO - 2018-03-26 15:41:46 --> Model Class Initialized
INFO - 2018-03-26 15:41:46 --> Model Class Initialized
INFO - 2018-03-26 15:41:46 --> Model Class Initialized
INFO - 2018-03-26 15:41:46 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-26 15:41:46 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
ERROR - 2018-03-26 15:41:46 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 784
INFO - 2018-03-26 15:41:46 --> Final output sent to browser
DEBUG - 2018-03-26 15:41:46 --> Total execution time: 2.0450
INFO - 2018-03-26 10:11:47 --> Config Class Initialized
INFO - 2018-03-26 10:11:47 --> Hooks Class Initialized
DEBUG - 2018-03-26 10:11:47 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:11:47 --> Utf8 Class Initialized
INFO - 2018-03-26 10:11:47 --> URI Class Initialized
INFO - 2018-03-26 10:11:47 --> Router Class Initialized
INFO - 2018-03-26 10:11:47 --> Output Class Initialized
INFO - 2018-03-26 10:11:47 --> Security Class Initialized
DEBUG - 2018-03-26 10:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:11:47 --> Input Class Initialized
INFO - 2018-03-26 10:11:47 --> Language Class Initialized
INFO - 2018-03-26 10:11:47 --> Language Class Initialized
INFO - 2018-03-26 10:11:47 --> Config Class Initialized
INFO - 2018-03-26 10:11:47 --> Loader Class Initialized
INFO - 2018-03-26 15:41:47 --> Helper loaded: url_helper
INFO - 2018-03-26 15:41:47 --> Helper loaded: notification_helper
INFO - 2018-03-26 15:41:47 --> Helper loaded: settings_helper
INFO - 2018-03-26 15:41:47 --> Helper loaded: permission_helper
INFO - 2018-03-26 15:41:47 --> Helper loaded: users_helper
INFO - 2018-03-26 15:41:47 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:41:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:41:47 --> Helper loaded: form_helper
INFO - 2018-03-26 15:41:47 --> Form Validation Class Initialized
INFO - 2018-03-26 15:41:47 --> Controller Class Initialized
INFO - 2018-03-26 15:41:47 --> Model Class Initialized
INFO - 2018-03-26 15:41:47 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 15:41:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 15:41:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 15:41:47 --> Model Class Initialized
INFO - 2018-03-26 15:41:47 --> Model Class Initialized
INFO - 2018-03-26 15:41:47 --> Model Class Initialized
INFO - 2018-03-26 15:41:47 --> Model Class Initialized
INFO - 2018-03-26 15:41:47 --> Model Class Initialized
INFO - 2018-03-26 15:41:47 --> Model Class Initialized
INFO - 2018-03-26 15:41:47 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-26 15:41:47 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
ERROR - 2018-03-26 15:41:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 784
INFO - 2018-03-26 15:41:47 --> Final output sent to browser
DEBUG - 2018-03-26 15:41:47 --> Total execution time: 0.2599
INFO - 2018-03-26 10:13:55 --> Config Class Initialized
INFO - 2018-03-26 10:13:55 --> Hooks Class Initialized
DEBUG - 2018-03-26 10:13:55 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:13:55 --> Utf8 Class Initialized
INFO - 2018-03-26 10:13:55 --> URI Class Initialized
INFO - 2018-03-26 10:13:55 --> Router Class Initialized
INFO - 2018-03-26 10:13:55 --> Output Class Initialized
INFO - 2018-03-26 10:13:55 --> Security Class Initialized
DEBUG - 2018-03-26 10:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:13:55 --> Input Class Initialized
INFO - 2018-03-26 10:13:55 --> Language Class Initialized
INFO - 2018-03-26 10:13:55 --> Language Class Initialized
INFO - 2018-03-26 10:13:55 --> Config Class Initialized
INFO - 2018-03-26 10:13:55 --> Loader Class Initialized
INFO - 2018-03-26 15:43:55 --> Helper loaded: url_helper
INFO - 2018-03-26 15:43:55 --> Helper loaded: notification_helper
INFO - 2018-03-26 15:43:55 --> Helper loaded: settings_helper
INFO - 2018-03-26 15:43:55 --> Helper loaded: permission_helper
INFO - 2018-03-26 15:43:55 --> Helper loaded: users_helper
INFO - 2018-03-26 15:43:55 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:43:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:43:55 --> Helper loaded: form_helper
INFO - 2018-03-26 15:43:55 --> Form Validation Class Initialized
INFO - 2018-03-26 15:43:55 --> Controller Class Initialized
INFO - 2018-03-26 15:43:55 --> Model Class Initialized
INFO - 2018-03-26 15:43:55 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 15:43:55 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 15:43:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 15:43:55 --> Model Class Initialized
INFO - 2018-03-26 15:43:55 --> Model Class Initialized
INFO - 2018-03-26 15:43:55 --> Model Class Initialized
INFO - 2018-03-26 15:43:55 --> Model Class Initialized
INFO - 2018-03-26 15:43:55 --> Model Class Initialized
INFO - 2018-03-26 15:43:55 --> Model Class Initialized
INFO - 2018-03-26 15:43:55 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 15:43:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-26 15:43:55 --> Final output sent to browser
DEBUG - 2018-03-26 15:43:55 --> Total execution time: 0.3644
INFO - 2018-03-26 10:13:56 --> Config Class Initialized
INFO - 2018-03-26 10:13:56 --> Hooks Class Initialized
DEBUG - 2018-03-26 10:13:56 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:13:56 --> Utf8 Class Initialized
INFO - 2018-03-26 10:13:56 --> URI Class Initialized
INFO - 2018-03-26 10:13:56 --> Router Class Initialized
INFO - 2018-03-26 10:13:56 --> Output Class Initialized
INFO - 2018-03-26 10:13:56 --> Security Class Initialized
DEBUG - 2018-03-26 10:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:13:56 --> Input Class Initialized
INFO - 2018-03-26 10:13:56 --> Language Class Initialized
INFO - 2018-03-26 10:13:56 --> Language Class Initialized
INFO - 2018-03-26 10:13:56 --> Config Class Initialized
INFO - 2018-03-26 10:13:56 --> Loader Class Initialized
INFO - 2018-03-26 15:43:56 --> Helper loaded: url_helper
INFO - 2018-03-26 15:43:56 --> Helper loaded: notification_helper
INFO - 2018-03-26 15:43:56 --> Helper loaded: settings_helper
INFO - 2018-03-26 15:43:56 --> Helper loaded: permission_helper
INFO - 2018-03-26 15:43:56 --> Helper loaded: users_helper
INFO - 2018-03-26 15:43:57 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:43:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:43:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:43:57 --> Helper loaded: form_helper
INFO - 2018-03-26 15:43:57 --> Form Validation Class Initialized
INFO - 2018-03-26 15:43:57 --> Controller Class Initialized
INFO - 2018-03-26 15:43:57 --> Model Class Initialized
INFO - 2018-03-26 15:43:57 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 15:43:57 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 15:43:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 15:43:57 --> Model Class Initialized
INFO - 2018-03-26 15:43:57 --> Model Class Initialized
INFO - 2018-03-26 15:43:57 --> Model Class Initialized
INFO - 2018-03-26 15:43:57 --> Model Class Initialized
INFO - 2018-03-26 15:43:57 --> Model Class Initialized
INFO - 2018-03-26 15:43:57 --> Model Class Initialized
INFO - 2018-03-26 15:43:57 --> Model Class Initialized
INFO - 2018-03-26 15:43:57 --> Model Class Initialized
INFO - 2018-03-26 15:43:57 --> Model Class Initialized
INFO - 2018-03-26 15:43:57 --> Model Class Initialized
INFO - 2018-03-26 15:43:57 --> Model Class Initialized
INFO - 2018-03-26 15:43:57 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 15:43:57 --> Model Class Initialized
INFO - 2018-03-26 15:43:57 --> Final output sent to browser
DEBUG - 2018-03-26 15:43:57 --> Total execution time: 0.5917
INFO - 2018-03-26 10:13:57 --> Config Class Initialized
INFO - 2018-03-26 10:13:57 --> Hooks Class Initialized
DEBUG - 2018-03-26 10:13:57 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:13:57 --> Utf8 Class Initialized
INFO - 2018-03-26 10:13:57 --> URI Class Initialized
INFO - 2018-03-26 10:13:57 --> Router Class Initialized
INFO - 2018-03-26 10:13:57 --> Output Class Initialized
INFO - 2018-03-26 10:13:57 --> Security Class Initialized
DEBUG - 2018-03-26 10:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:13:57 --> Input Class Initialized
INFO - 2018-03-26 10:13:57 --> Language Class Initialized
INFO - 2018-03-26 10:13:57 --> Language Class Initialized
INFO - 2018-03-26 10:13:57 --> Config Class Initialized
INFO - 2018-03-26 10:13:57 --> Loader Class Initialized
INFO - 2018-03-26 15:43:57 --> Helper loaded: url_helper
INFO - 2018-03-26 15:43:57 --> Helper loaded: notification_helper
INFO - 2018-03-26 15:43:57 --> Helper loaded: settings_helper
INFO - 2018-03-26 15:43:57 --> Helper loaded: permission_helper
INFO - 2018-03-26 15:43:57 --> Helper loaded: users_helper
INFO - 2018-03-26 15:43:57 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:43:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:43:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:43:57 --> Helper loaded: form_helper
INFO - 2018-03-26 15:43:57 --> Form Validation Class Initialized
INFO - 2018-03-26 15:43:57 --> Controller Class Initialized
INFO - 2018-03-26 15:43:57 --> Model Class Initialized
INFO - 2018-03-26 15:43:57 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 15:43:57 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 15:43:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 15:43:57 --> Model Class Initialized
INFO - 2018-03-26 15:43:57 --> Model Class Initialized
INFO - 2018-03-26 15:43:57 --> Model Class Initialized
INFO - 2018-03-26 15:43:57 --> Model Class Initialized
INFO - 2018-03-26 15:43:57 --> Model Class Initialized
INFO - 2018-03-26 15:43:57 --> Model Class Initialized
INFO - 2018-03-26 15:43:57 --> Model Class Initialized
INFO - 2018-03-26 15:43:57 --> Model Class Initialized
INFO - 2018-03-26 15:43:57 --> Model Class Initialized
INFO - 2018-03-26 15:43:57 --> Model Class Initialized
INFO - 2018-03-26 15:43:57 --> Model Class Initialized
INFO - 2018-03-26 15:43:57 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 15:43:58 --> Model Class Initialized
INFO - 2018-03-26 15:43:58 --> Final output sent to browser
DEBUG - 2018-03-26 15:43:58 --> Total execution time: 0.6054
INFO - 2018-03-26 10:14:00 --> Config Class Initialized
INFO - 2018-03-26 10:14:00 --> Hooks Class Initialized
DEBUG - 2018-03-26 10:14:00 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:14:00 --> Utf8 Class Initialized
INFO - 2018-03-26 10:14:00 --> URI Class Initialized
INFO - 2018-03-26 10:14:01 --> Router Class Initialized
INFO - 2018-03-26 10:14:01 --> Output Class Initialized
INFO - 2018-03-26 10:14:01 --> Security Class Initialized
DEBUG - 2018-03-26 10:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:14:01 --> Input Class Initialized
INFO - 2018-03-26 10:14:01 --> Language Class Initialized
INFO - 2018-03-26 10:14:02 --> Config Class Initialized
INFO - 2018-03-26 10:14:02 --> Hooks Class Initialized
DEBUG - 2018-03-26 10:14:02 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:14:02 --> Utf8 Class Initialized
INFO - 2018-03-26 10:14:02 --> URI Class Initialized
INFO - 2018-03-26 10:14:02 --> Router Class Initialized
INFO - 2018-03-26 10:14:02 --> Output Class Initialized
INFO - 2018-03-26 10:14:02 --> Security Class Initialized
DEBUG - 2018-03-26 10:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:14:02 --> Input Class Initialized
INFO - 2018-03-26 10:14:02 --> Language Class Initialized
INFO - 2018-03-26 10:14:02 --> Language Class Initialized
INFO - 2018-03-26 10:14:02 --> Config Class Initialized
INFO - 2018-03-26 10:14:02 --> Loader Class Initialized
INFO - 2018-03-26 15:44:02 --> Helper loaded: url_helper
INFO - 2018-03-26 15:44:02 --> Helper loaded: notification_helper
INFO - 2018-03-26 15:44:02 --> Helper loaded: settings_helper
INFO - 2018-03-26 15:44:02 --> Helper loaded: permission_helper
INFO - 2018-03-26 15:44:02 --> Helper loaded: users_helper
INFO - 2018-03-26 15:44:02 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:44:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:44:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:44:02 --> Helper loaded: form_helper
INFO - 2018-03-26 15:44:02 --> Form Validation Class Initialized
INFO - 2018-03-26 15:44:02 --> Controller Class Initialized
INFO - 2018-03-26 15:44:02 --> Model Class Initialized
INFO - 2018-03-26 15:44:02 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 15:44:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 15:44:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 15:44:02 --> Model Class Initialized
INFO - 2018-03-26 15:44:02 --> Model Class Initialized
INFO - 2018-03-26 15:44:02 --> Model Class Initialized
INFO - 2018-03-26 15:44:02 --> Model Class Initialized
INFO - 2018-03-26 15:44:02 --> Model Class Initialized
INFO - 2018-03-26 15:44:02 --> Model Class Initialized
INFO - 2018-03-26 15:44:02 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-26 15:44:02 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-26 15:44:02 --> Final output sent to browser
DEBUG - 2018-03-26 15:44:02 --> Total execution time: 0.0946
INFO - 2018-03-26 10:14:03 --> Language Class Initialized
INFO - 2018-03-26 10:14:03 --> Config Class Initialized
INFO - 2018-03-26 10:14:03 --> Loader Class Initialized
INFO - 2018-03-26 15:44:03 --> Helper loaded: url_helper
INFO - 2018-03-26 15:44:03 --> Helper loaded: notification_helper
INFO - 2018-03-26 15:44:03 --> Helper loaded: settings_helper
INFO - 2018-03-26 15:44:03 --> Helper loaded: permission_helper
INFO - 2018-03-26 15:44:03 --> Helper loaded: users_helper
INFO - 2018-03-26 15:44:04 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:44:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:44:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:44:05 --> Helper loaded: form_helper
INFO - 2018-03-26 15:44:05 --> Form Validation Class Initialized
INFO - 2018-03-26 15:44:05 --> Controller Class Initialized
INFO - 2018-03-26 15:44:05 --> Model Class Initialized
INFO - 2018-03-26 15:44:05 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 15:44:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 15:44:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 15:44:05 --> Model Class Initialized
INFO - 2018-03-26 15:44:05 --> Model Class Initialized
INFO - 2018-03-26 15:44:05 --> Model Class Initialized
INFO - 2018-03-26 15:44:05 --> Model Class Initialized
INFO - 2018-03-26 15:44:05 --> Model Class Initialized
INFO - 2018-03-26 15:44:05 --> Model Class Initialized
INFO - 2018-03-26 15:44:05 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-26 15:44:05 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-26 15:44:05 --> Final output sent to browser
DEBUG - 2018-03-26 15:44:05 --> Total execution time: 5.4426
INFO - 2018-03-26 10:15:20 --> Config Class Initialized
INFO - 2018-03-26 10:15:20 --> Hooks Class Initialized
DEBUG - 2018-03-26 10:15:20 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:15:20 --> Utf8 Class Initialized
INFO - 2018-03-26 10:15:20 --> URI Class Initialized
INFO - 2018-03-26 10:15:20 --> Router Class Initialized
INFO - 2018-03-26 10:15:20 --> Output Class Initialized
INFO - 2018-03-26 10:15:20 --> Security Class Initialized
DEBUG - 2018-03-26 10:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:15:20 --> Input Class Initialized
INFO - 2018-03-26 10:15:20 --> Language Class Initialized
INFO - 2018-03-26 10:15:20 --> Language Class Initialized
INFO - 2018-03-26 10:15:20 --> Config Class Initialized
INFO - 2018-03-26 10:15:20 --> Loader Class Initialized
INFO - 2018-03-26 15:45:20 --> Helper loaded: url_helper
INFO - 2018-03-26 15:45:20 --> Helper loaded: notification_helper
INFO - 2018-03-26 15:45:20 --> Helper loaded: settings_helper
INFO - 2018-03-26 15:45:20 --> Helper loaded: permission_helper
INFO - 2018-03-26 15:45:20 --> Helper loaded: users_helper
INFO - 2018-03-26 15:45:20 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:45:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:45:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:45:20 --> Helper loaded: form_helper
INFO - 2018-03-26 15:45:20 --> Form Validation Class Initialized
INFO - 2018-03-26 15:45:20 --> Controller Class Initialized
INFO - 2018-03-26 15:45:20 --> Model Class Initialized
INFO - 2018-03-26 15:45:20 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 15:45:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 15:45:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 15:45:20 --> Model Class Initialized
INFO - 2018-03-26 15:45:20 --> Model Class Initialized
INFO - 2018-03-26 15:45:20 --> Model Class Initialized
INFO - 2018-03-26 15:45:20 --> Model Class Initialized
INFO - 2018-03-26 15:45:20 --> Model Class Initialized
INFO - 2018-03-26 15:45:20 --> Model Class Initialized
INFO - 2018-03-26 15:45:20 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-26 15:45:20 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-26 15:45:20 --> Final output sent to browser
DEBUG - 2018-03-26 15:45:20 --> Total execution time: 0.4401
INFO - 2018-03-26 10:24:46 --> Config Class Initialized
INFO - 2018-03-26 10:24:46 --> Hooks Class Initialized
DEBUG - 2018-03-26 10:24:46 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:24:46 --> Utf8 Class Initialized
INFO - 2018-03-26 10:24:46 --> URI Class Initialized
INFO - 2018-03-26 10:24:46 --> Router Class Initialized
INFO - 2018-03-26 10:24:46 --> Output Class Initialized
INFO - 2018-03-26 10:24:46 --> Security Class Initialized
DEBUG - 2018-03-26 10:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:24:46 --> Input Class Initialized
INFO - 2018-03-26 10:24:46 --> Language Class Initialized
INFO - 2018-03-26 10:24:46 --> Language Class Initialized
INFO - 2018-03-26 10:24:46 --> Config Class Initialized
INFO - 2018-03-26 10:24:46 --> Loader Class Initialized
INFO - 2018-03-26 15:54:46 --> Helper loaded: url_helper
INFO - 2018-03-26 15:54:46 --> Helper loaded: notification_helper
INFO - 2018-03-26 15:54:46 --> Helper loaded: settings_helper
INFO - 2018-03-26 15:54:46 --> Helper loaded: permission_helper
INFO - 2018-03-26 15:54:46 --> Helper loaded: users_helper
INFO - 2018-03-26 15:54:46 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:54:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:54:46 --> Helper loaded: form_helper
INFO - 2018-03-26 15:54:46 --> Form Validation Class Initialized
INFO - 2018-03-26 15:54:46 --> Controller Class Initialized
INFO - 2018-03-26 15:54:46 --> Model Class Initialized
INFO - 2018-03-26 15:54:46 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 15:54:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 15:54:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 15:54:46 --> Model Class Initialized
INFO - 2018-03-26 15:54:46 --> Model Class Initialized
INFO - 2018-03-26 15:54:46 --> Model Class Initialized
INFO - 2018-03-26 15:54:46 --> Model Class Initialized
INFO - 2018-03-26 15:54:46 --> Model Class Initialized
INFO - 2018-03-26 15:54:46 --> Model Class Initialized
INFO - 2018-03-26 15:54:46 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 15:54:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-26 15:54:46 --> Final output sent to browser
DEBUG - 2018-03-26 15:54:46 --> Total execution time: 0.1988
INFO - 2018-03-26 10:24:47 --> Config Class Initialized
INFO - 2018-03-26 10:24:47 --> Hooks Class Initialized
DEBUG - 2018-03-26 10:24:47 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:24:47 --> Utf8 Class Initialized
INFO - 2018-03-26 10:24:47 --> URI Class Initialized
INFO - 2018-03-26 10:24:47 --> Router Class Initialized
INFO - 2018-03-26 10:24:47 --> Output Class Initialized
INFO - 2018-03-26 10:24:47 --> Security Class Initialized
DEBUG - 2018-03-26 10:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:24:47 --> Input Class Initialized
INFO - 2018-03-26 10:24:47 --> Language Class Initialized
INFO - 2018-03-26 10:24:47 --> Language Class Initialized
INFO - 2018-03-26 10:24:47 --> Config Class Initialized
INFO - 2018-03-26 10:24:47 --> Loader Class Initialized
INFO - 2018-03-26 15:54:47 --> Helper loaded: url_helper
INFO - 2018-03-26 15:54:47 --> Helper loaded: notification_helper
INFO - 2018-03-26 15:54:47 --> Helper loaded: settings_helper
INFO - 2018-03-26 15:54:47 --> Helper loaded: permission_helper
INFO - 2018-03-26 15:54:47 --> Helper loaded: users_helper
INFO - 2018-03-26 15:54:47 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:54:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:54:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:54:47 --> Helper loaded: form_helper
INFO - 2018-03-26 15:54:47 --> Form Validation Class Initialized
INFO - 2018-03-26 15:54:47 --> Controller Class Initialized
INFO - 2018-03-26 15:54:47 --> Model Class Initialized
INFO - 2018-03-26 15:54:47 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 15:54:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 15:54:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 15:54:47 --> Model Class Initialized
INFO - 2018-03-26 15:54:47 --> Model Class Initialized
INFO - 2018-03-26 15:54:47 --> Model Class Initialized
INFO - 2018-03-26 15:54:47 --> Model Class Initialized
INFO - 2018-03-26 15:54:47 --> Model Class Initialized
INFO - 2018-03-26 15:54:47 --> Model Class Initialized
INFO - 2018-03-26 15:54:47 --> Model Class Initialized
INFO - 2018-03-26 15:54:47 --> Model Class Initialized
INFO - 2018-03-26 15:54:47 --> Model Class Initialized
INFO - 2018-03-26 15:54:47 --> Model Class Initialized
INFO - 2018-03-26 15:54:47 --> Model Class Initialized
INFO - 2018-03-26 15:54:47 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 15:54:47 --> Model Class Initialized
INFO - 2018-03-26 15:54:47 --> Final output sent to browser
DEBUG - 2018-03-26 15:54:47 --> Total execution time: 0.1146
INFO - 2018-03-26 10:24:50 --> Config Class Initialized
INFO - 2018-03-26 10:24:50 --> Hooks Class Initialized
DEBUG - 2018-03-26 10:24:50 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:24:50 --> Utf8 Class Initialized
INFO - 2018-03-26 10:24:50 --> URI Class Initialized
INFO - 2018-03-26 10:24:50 --> Router Class Initialized
INFO - 2018-03-26 10:24:50 --> Output Class Initialized
INFO - 2018-03-26 10:24:50 --> Security Class Initialized
DEBUG - 2018-03-26 10:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:24:50 --> Input Class Initialized
INFO - 2018-03-26 10:24:50 --> Language Class Initialized
INFO - 2018-03-26 10:24:50 --> Language Class Initialized
INFO - 2018-03-26 10:24:50 --> Config Class Initialized
INFO - 2018-03-26 10:24:50 --> Loader Class Initialized
INFO - 2018-03-26 15:54:50 --> Helper loaded: url_helper
INFO - 2018-03-26 15:54:50 --> Helper loaded: notification_helper
INFO - 2018-03-26 15:54:50 --> Helper loaded: settings_helper
INFO - 2018-03-26 15:54:50 --> Helper loaded: permission_helper
INFO - 2018-03-26 15:54:50 --> Helper loaded: users_helper
INFO - 2018-03-26 15:54:50 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:54:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:54:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:54:50 --> Helper loaded: form_helper
INFO - 2018-03-26 15:54:50 --> Form Validation Class Initialized
INFO - 2018-03-26 15:54:50 --> Controller Class Initialized
INFO - 2018-03-26 15:54:50 --> Model Class Initialized
INFO - 2018-03-26 15:54:50 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 15:54:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 15:54:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 15:54:50 --> Model Class Initialized
INFO - 2018-03-26 15:54:50 --> Model Class Initialized
INFO - 2018-03-26 15:54:50 --> Model Class Initialized
INFO - 2018-03-26 15:54:50 --> Model Class Initialized
INFO - 2018-03-26 15:54:50 --> Model Class Initialized
INFO - 2018-03-26 15:54:50 --> Model Class Initialized
INFO - 2018-03-26 15:54:50 --> Model Class Initialized
INFO - 2018-03-26 15:54:50 --> Model Class Initialized
INFO - 2018-03-26 15:54:50 --> Model Class Initialized
INFO - 2018-03-26 15:54:50 --> Model Class Initialized
INFO - 2018-03-26 15:54:50 --> Model Class Initialized
INFO - 2018-03-26 15:54:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 15:54:50 --> Model Class Initialized
INFO - 2018-03-26 15:54:50 --> Final output sent to browser
DEBUG - 2018-03-26 15:54:50 --> Total execution time: 0.1615
INFO - 2018-03-26 10:24:50 --> Config Class Initialized
INFO - 2018-03-26 10:24:50 --> Hooks Class Initialized
DEBUG - 2018-03-26 10:24:51 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:24:51 --> Utf8 Class Initialized
INFO - 2018-03-26 10:24:51 --> URI Class Initialized
INFO - 2018-03-26 10:24:51 --> Router Class Initialized
INFO - 2018-03-26 10:24:51 --> Output Class Initialized
INFO - 2018-03-26 10:24:51 --> Security Class Initialized
DEBUG - 2018-03-26 10:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:24:51 --> Input Class Initialized
INFO - 2018-03-26 10:24:51 --> Language Class Initialized
INFO - 2018-03-26 10:24:52 --> Language Class Initialized
INFO - 2018-03-26 10:24:52 --> Config Class Initialized
INFO - 2018-03-26 10:24:52 --> Loader Class Initialized
INFO - 2018-03-26 15:54:52 --> Helper loaded: url_helper
INFO - 2018-03-26 15:54:52 --> Helper loaded: notification_helper
INFO - 2018-03-26 15:54:52 --> Helper loaded: settings_helper
INFO - 2018-03-26 15:54:52 --> Helper loaded: permission_helper
INFO - 2018-03-26 15:54:52 --> Helper loaded: users_helper
INFO - 2018-03-26 10:24:52 --> Config Class Initialized
INFO - 2018-03-26 10:24:52 --> Hooks Class Initialized
DEBUG - 2018-03-26 10:24:52 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:24:52 --> Utf8 Class Initialized
INFO - 2018-03-26 15:54:52 --> Database Driver Class Initialized
INFO - 2018-03-26 10:24:52 --> URI Class Initialized
DEBUG - 2018-03-26 15:54:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:54:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:54:52 --> Helper loaded: form_helper
INFO - 2018-03-26 15:54:52 --> Form Validation Class Initialized
INFO - 2018-03-26 15:54:52 --> Controller Class Initialized
INFO - 2018-03-26 15:54:52 --> Model Class Initialized
INFO - 2018-03-26 15:54:52 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 15:54:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 15:54:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 15:54:52 --> Model Class Initialized
INFO - 2018-03-26 15:54:52 --> Model Class Initialized
INFO - 2018-03-26 15:54:52 --> Model Class Initialized
INFO - 2018-03-26 15:54:52 --> Model Class Initialized
INFO - 2018-03-26 15:54:52 --> Model Class Initialized
INFO - 2018-03-26 15:54:52 --> Model Class Initialized
INFO - 2018-03-26 15:54:52 --> Model Class Initialized
INFO - 2018-03-26 15:54:52 --> Model Class Initialized
INFO - 2018-03-26 15:54:52 --> Model Class Initialized
INFO - 2018-03-26 15:54:52 --> Model Class Initialized
INFO - 2018-03-26 15:54:52 --> Model Class Initialized
INFO - 2018-03-26 15:54:52 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 15:54:52 --> Model Class Initialized
INFO - 2018-03-26 10:24:52 --> Router Class Initialized
INFO - 2018-03-26 15:54:52 --> Final output sent to browser
DEBUG - 2018-03-26 15:54:52 --> Total execution time: 2.3972
INFO - 2018-03-26 10:24:52 --> Output Class Initialized
INFO - 2018-03-26 10:24:52 --> Security Class Initialized
DEBUG - 2018-03-26 10:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:24:52 --> Input Class Initialized
INFO - 2018-03-26 10:24:52 --> Language Class Initialized
INFO - 2018-03-26 10:24:53 --> Language Class Initialized
INFO - 2018-03-26 10:24:53 --> Config Class Initialized
INFO - 2018-03-26 10:24:53 --> Loader Class Initialized
INFO - 2018-03-26 15:54:53 --> Helper loaded: url_helper
INFO - 2018-03-26 15:54:53 --> Helper loaded: notification_helper
INFO - 2018-03-26 15:54:53 --> Helper loaded: settings_helper
INFO - 2018-03-26 15:54:53 --> Helper loaded: permission_helper
INFO - 2018-03-26 15:54:53 --> Helper loaded: users_helper
INFO - 2018-03-26 15:54:53 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:54:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:54:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:54:53 --> Helper loaded: form_helper
INFO - 2018-03-26 15:54:53 --> Form Validation Class Initialized
INFO - 2018-03-26 15:54:53 --> Controller Class Initialized
INFO - 2018-03-26 15:54:53 --> Model Class Initialized
INFO - 2018-03-26 15:54:53 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 15:54:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 15:54:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 15:54:53 --> Model Class Initialized
INFO - 2018-03-26 15:54:53 --> Model Class Initialized
INFO - 2018-03-26 15:54:53 --> Model Class Initialized
INFO - 2018-03-26 15:54:53 --> Model Class Initialized
INFO - 2018-03-26 15:54:53 --> Model Class Initialized
INFO - 2018-03-26 15:54:53 --> Model Class Initialized
INFO - 2018-03-26 15:54:53 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-26 15:54:53 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-26 15:54:53 --> Final output sent to browser
DEBUG - 2018-03-26 15:54:53 --> Total execution time: 0.4672
INFO - 2018-03-26 10:25:00 --> Config Class Initialized
INFO - 2018-03-26 10:25:00 --> Hooks Class Initialized
DEBUG - 2018-03-26 10:25:00 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:25:00 --> Utf8 Class Initialized
INFO - 2018-03-26 10:25:00 --> URI Class Initialized
INFO - 2018-03-26 10:25:00 --> Router Class Initialized
INFO - 2018-03-26 10:25:00 --> Output Class Initialized
INFO - 2018-03-26 10:25:00 --> Security Class Initialized
DEBUG - 2018-03-26 10:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:25:00 --> Input Class Initialized
INFO - 2018-03-26 10:25:00 --> Language Class Initialized
INFO - 2018-03-26 10:25:00 --> Language Class Initialized
INFO - 2018-03-26 10:25:00 --> Config Class Initialized
INFO - 2018-03-26 10:25:00 --> Loader Class Initialized
INFO - 2018-03-26 15:55:00 --> Helper loaded: url_helper
INFO - 2018-03-26 15:55:00 --> Helper loaded: notification_helper
INFO - 2018-03-26 15:55:00 --> Helper loaded: settings_helper
INFO - 2018-03-26 15:55:00 --> Helper loaded: permission_helper
INFO - 2018-03-26 15:55:00 --> Helper loaded: users_helper
INFO - 2018-03-26 15:55:00 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:55:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:55:00 --> Helper loaded: form_helper
INFO - 2018-03-26 15:55:00 --> Form Validation Class Initialized
INFO - 2018-03-26 15:55:00 --> Controller Class Initialized
INFO - 2018-03-26 15:55:00 --> Model Class Initialized
INFO - 2018-03-26 15:55:00 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 15:55:00 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 15:55:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 15:55:00 --> Model Class Initialized
INFO - 2018-03-26 15:55:00 --> Model Class Initialized
INFO - 2018-03-26 15:55:00 --> Model Class Initialized
INFO - 2018-03-26 15:55:00 --> Model Class Initialized
INFO - 2018-03-26 15:55:00 --> Model Class Initialized
INFO - 2018-03-26 15:55:00 --> Model Class Initialized
INFO - 2018-03-26 15:55:00 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-26 15:55:00 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-26 15:55:00 --> Final output sent to browser
DEBUG - 2018-03-26 15:55:00 --> Total execution time: 0.1828
INFO - 2018-03-26 10:38:08 --> Config Class Initialized
INFO - 2018-03-26 10:38:08 --> Hooks Class Initialized
DEBUG - 2018-03-26 10:38:08 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:38:08 --> Utf8 Class Initialized
INFO - 2018-03-26 10:38:08 --> URI Class Initialized
INFO - 2018-03-26 10:38:08 --> Router Class Initialized
INFO - 2018-03-26 10:38:08 --> Output Class Initialized
INFO - 2018-03-26 10:38:08 --> Security Class Initialized
DEBUG - 2018-03-26 10:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:38:08 --> Input Class Initialized
INFO - 2018-03-26 10:38:08 --> Language Class Initialized
INFO - 2018-03-26 10:38:09 --> Language Class Initialized
INFO - 2018-03-26 10:38:09 --> Config Class Initialized
INFO - 2018-03-26 10:38:09 --> Loader Class Initialized
INFO - 2018-03-26 16:08:09 --> Helper loaded: url_helper
INFO - 2018-03-26 16:08:09 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:08:09 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:08:09 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:08:09 --> Helper loaded: users_helper
INFO - 2018-03-26 16:08:09 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:08:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:08:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:08:09 --> Helper loaded: form_helper
INFO - 2018-03-26 16:08:09 --> Form Validation Class Initialized
INFO - 2018-03-26 16:08:09 --> Controller Class Initialized
INFO - 2018-03-26 16:08:09 --> Model Class Initialized
INFO - 2018-03-26 16:08:09 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:08:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:08:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:08:09 --> Model Class Initialized
INFO - 2018-03-26 16:08:09 --> Model Class Initialized
INFO - 2018-03-26 16:08:09 --> Model Class Initialized
INFO - 2018-03-26 16:08:09 --> Model Class Initialized
INFO - 2018-03-26 16:08:09 --> Model Class Initialized
INFO - 2018-03-26 16:08:09 --> Model Class Initialized
INFO - 2018-03-26 16:08:09 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:08:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-26 16:08:09 --> Final output sent to browser
DEBUG - 2018-03-26 16:08:09 --> Total execution time: 1.0249
INFO - 2018-03-26 10:38:10 --> Config Class Initialized
INFO - 2018-03-26 10:38:10 --> Hooks Class Initialized
DEBUG - 2018-03-26 10:38:10 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:38:10 --> Utf8 Class Initialized
INFO - 2018-03-26 10:38:10 --> URI Class Initialized
INFO - 2018-03-26 10:38:10 --> Router Class Initialized
INFO - 2018-03-26 10:38:10 --> Config Class Initialized
INFO - 2018-03-26 10:38:10 --> Hooks Class Initialized
INFO - 2018-03-26 10:38:10 --> Output Class Initialized
DEBUG - 2018-03-26 10:38:10 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:38:10 --> Utf8 Class Initialized
INFO - 2018-03-26 10:38:10 --> Security Class Initialized
INFO - 2018-03-26 10:38:10 --> URI Class Initialized
DEBUG - 2018-03-26 10:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:38:10 --> Input Class Initialized
INFO - 2018-03-26 10:38:10 --> Router Class Initialized
INFO - 2018-03-26 10:38:10 --> Language Class Initialized
INFO - 2018-03-26 10:38:10 --> Output Class Initialized
INFO - 2018-03-26 10:38:10 --> Security Class Initialized
DEBUG - 2018-03-26 10:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:38:10 --> Input Class Initialized
INFO - 2018-03-26 10:38:10 --> Language Class Initialized
INFO - 2018-03-26 10:38:10 --> Language Class Initialized
INFO - 2018-03-26 10:38:10 --> Config Class Initialized
INFO - 2018-03-26 10:38:10 --> Loader Class Initialized
INFO - 2018-03-26 16:08:10 --> Helper loaded: url_helper
INFO - 2018-03-26 16:08:10 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:08:10 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:08:10 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:08:10 --> Helper loaded: users_helper
INFO - 2018-03-26 16:08:10 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:08:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:08:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 10:38:10 --> Language Class Initialized
INFO - 2018-03-26 10:38:10 --> Config Class Initialized
INFO - 2018-03-26 10:38:10 --> Loader Class Initialized
INFO - 2018-03-26 16:08:10 --> Helper loaded: form_helper
INFO - 2018-03-26 16:08:10 --> Form Validation Class Initialized
INFO - 2018-03-26 16:08:10 --> Controller Class Initialized
INFO - 2018-03-26 16:08:10 --> Helper loaded: url_helper
INFO - 2018-03-26 16:08:10 --> Model Class Initialized
INFO - 2018-03-26 16:08:10 --> Helper loaded: inflector_helper
INFO - 2018-03-26 16:08:10 --> Helper loaded: notification_helper
DEBUG - 2018-03-26 16:08:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:08:10 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:08:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:08:10 --> Model Class Initialized
INFO - 2018-03-26 16:08:10 --> Model Class Initialized
INFO - 2018-03-26 16:08:10 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:08:10 --> Model Class Initialized
INFO - 2018-03-26 16:08:10 --> Model Class Initialized
INFO - 2018-03-26 16:08:10 --> Model Class Initialized
INFO - 2018-03-26 16:08:10 --> Model Class Initialized
INFO - 2018-03-26 16:08:10 --> Model Class Initialized
INFO - 2018-03-26 16:08:10 --> Model Class Initialized
INFO - 2018-03-26 16:08:10 --> Model Class Initialized
INFO - 2018-03-26 16:08:10 --> Model Class Initialized
INFO - 2018-03-26 16:08:10 --> Helper loaded: users_helper
INFO - 2018-03-26 16:08:10 --> Model Class Initialized
INFO - 2018-03-26 16:08:10 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:08:10 --> Model Class Initialized
INFO - 2018-03-26 16:08:10 --> Final output sent to browser
DEBUG - 2018-03-26 16:08:10 --> Total execution time: 0.1488
INFO - 2018-03-26 16:08:10 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:08:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:08:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:08:11 --> Helper loaded: form_helper
INFO - 2018-03-26 16:08:11 --> Form Validation Class Initialized
INFO - 2018-03-26 16:08:11 --> Controller Class Initialized
INFO - 2018-03-26 16:08:11 --> Model Class Initialized
INFO - 2018-03-26 16:08:11 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:08:11 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:08:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:08:11 --> Model Class Initialized
INFO - 2018-03-26 16:08:11 --> Model Class Initialized
INFO - 2018-03-26 16:08:11 --> Model Class Initialized
INFO - 2018-03-26 16:08:11 --> Model Class Initialized
INFO - 2018-03-26 16:08:12 --> Model Class Initialized
INFO - 2018-03-26 16:08:12 --> Model Class Initialized
INFO - 2018-03-26 16:08:12 --> Model Class Initialized
INFO - 2018-03-26 16:08:12 --> Model Class Initialized
INFO - 2018-03-26 16:08:12 --> Model Class Initialized
INFO - 2018-03-26 16:08:12 --> Model Class Initialized
INFO - 2018-03-26 16:08:12 --> Model Class Initialized
INFO - 2018-03-26 16:08:12 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:08:12 --> Model Class Initialized
INFO - 2018-03-26 16:08:12 --> Final output sent to browser
DEBUG - 2018-03-26 16:08:12 --> Total execution time: 1.9454
INFO - 2018-03-26 10:38:12 --> Config Class Initialized
INFO - 2018-03-26 10:38:12 --> Hooks Class Initialized
DEBUG - 2018-03-26 10:38:12 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:38:12 --> Utf8 Class Initialized
INFO - 2018-03-26 10:38:12 --> URI Class Initialized
INFO - 2018-03-26 10:38:12 --> Router Class Initialized
INFO - 2018-03-26 10:38:12 --> Output Class Initialized
INFO - 2018-03-26 10:38:12 --> Security Class Initialized
DEBUG - 2018-03-26 10:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:38:12 --> Input Class Initialized
INFO - 2018-03-26 10:38:12 --> Language Class Initialized
INFO - 2018-03-26 10:38:12 --> Language Class Initialized
INFO - 2018-03-26 10:38:12 --> Config Class Initialized
INFO - 2018-03-26 10:38:12 --> Loader Class Initialized
INFO - 2018-03-26 16:08:12 --> Helper loaded: url_helper
INFO - 2018-03-26 16:08:12 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:08:12 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:08:12 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:08:12 --> Helper loaded: users_helper
INFO - 2018-03-26 16:08:13 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:08:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:08:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:08:13 --> Helper loaded: form_helper
INFO - 2018-03-26 16:08:13 --> Form Validation Class Initialized
INFO - 2018-03-26 16:08:13 --> Controller Class Initialized
INFO - 2018-03-26 16:08:13 --> Model Class Initialized
INFO - 2018-03-26 16:08:13 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:08:13 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:08:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:08:13 --> Model Class Initialized
INFO - 2018-03-26 16:08:13 --> Model Class Initialized
INFO - 2018-03-26 16:08:13 --> Model Class Initialized
INFO - 2018-03-26 16:08:13 --> Model Class Initialized
INFO - 2018-03-26 16:08:13 --> Model Class Initialized
INFO - 2018-03-26 16:08:13 --> Model Class Initialized
INFO - 2018-03-26 16:08:13 --> Model Class Initialized
INFO - 2018-03-26 16:08:13 --> Model Class Initialized
INFO - 2018-03-26 16:08:13 --> Model Class Initialized
INFO - 2018-03-26 16:08:13 --> Model Class Initialized
INFO - 2018-03-26 16:08:13 --> Model Class Initialized
INFO - 2018-03-26 16:08:13 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:08:13 --> Model Class Initialized
INFO - 2018-03-26 16:08:13 --> Final output sent to browser
DEBUG - 2018-03-26 16:08:13 --> Total execution time: 0.3104
INFO - 2018-03-26 10:38:15 --> Config Class Initialized
INFO - 2018-03-26 10:38:15 --> Hooks Class Initialized
DEBUG - 2018-03-26 10:38:15 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:38:15 --> Utf8 Class Initialized
INFO - 2018-03-26 10:38:15 --> URI Class Initialized
INFO - 2018-03-26 10:38:15 --> Router Class Initialized
INFO - 2018-03-26 10:38:15 --> Output Class Initialized
INFO - 2018-03-26 10:38:15 --> Security Class Initialized
DEBUG - 2018-03-26 10:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:38:15 --> Input Class Initialized
INFO - 2018-03-26 10:38:15 --> Language Class Initialized
INFO - 2018-03-26 10:38:15 --> Language Class Initialized
INFO - 2018-03-26 10:38:15 --> Config Class Initialized
INFO - 2018-03-26 10:38:15 --> Loader Class Initialized
INFO - 2018-03-26 16:08:15 --> Helper loaded: url_helper
INFO - 2018-03-26 16:08:15 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:08:15 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:08:15 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:08:15 --> Helper loaded: users_helper
INFO - 2018-03-26 16:08:15 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:08:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:08:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:08:16 --> Helper loaded: form_helper
INFO - 2018-03-26 16:08:16 --> Form Validation Class Initialized
INFO - 2018-03-26 16:08:16 --> Controller Class Initialized
INFO - 2018-03-26 16:08:16 --> Model Class Initialized
INFO - 2018-03-26 16:08:16 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:08:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:08:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:08:16 --> Model Class Initialized
INFO - 2018-03-26 16:08:16 --> Model Class Initialized
INFO - 2018-03-26 16:08:16 --> Model Class Initialized
INFO - 2018-03-26 16:08:16 --> Model Class Initialized
INFO - 2018-03-26 16:08:16 --> Model Class Initialized
INFO - 2018-03-26 16:08:16 --> Model Class Initialized
INFO - 2018-03-26 16:08:16 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-26 16:08:16 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-26 16:08:17 --> Final output sent to browser
DEBUG - 2018-03-26 16:08:17 --> Total execution time: 1.8401
INFO - 2018-03-26 10:38:18 --> Config Class Initialized
INFO - 2018-03-26 10:38:18 --> Hooks Class Initialized
DEBUG - 2018-03-26 10:38:18 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:38:18 --> Utf8 Class Initialized
INFO - 2018-03-26 10:38:18 --> URI Class Initialized
INFO - 2018-03-26 10:38:19 --> Router Class Initialized
INFO - 2018-03-26 10:38:19 --> Output Class Initialized
INFO - 2018-03-26 10:38:19 --> Security Class Initialized
DEBUG - 2018-03-26 10:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:38:19 --> Input Class Initialized
INFO - 2018-03-26 10:38:19 --> Language Class Initialized
INFO - 2018-03-26 10:38:19 --> Language Class Initialized
INFO - 2018-03-26 10:38:19 --> Config Class Initialized
INFO - 2018-03-26 10:38:19 --> Loader Class Initialized
INFO - 2018-03-26 16:08:19 --> Helper loaded: url_helper
INFO - 2018-03-26 16:08:19 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:08:19 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:08:19 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:08:19 --> Helper loaded: users_helper
INFO - 2018-03-26 16:08:19 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:08:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:08:20 --> Helper loaded: form_helper
INFO - 2018-03-26 16:08:20 --> Form Validation Class Initialized
INFO - 2018-03-26 16:08:20 --> Controller Class Initialized
INFO - 2018-03-26 16:08:20 --> Model Class Initialized
INFO - 2018-03-26 16:08:20 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:08:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:08:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:08:20 --> Model Class Initialized
INFO - 2018-03-26 16:08:20 --> Model Class Initialized
INFO - 2018-03-26 16:08:20 --> Model Class Initialized
INFO - 2018-03-26 16:08:20 --> Model Class Initialized
INFO - 2018-03-26 16:08:20 --> Model Class Initialized
INFO - 2018-03-26 16:08:20 --> Model Class Initialized
INFO - 2018-03-26 16:08:20 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-26 16:08:20 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-26 16:08:20 --> Final output sent to browser
DEBUG - 2018-03-26 16:08:20 --> Total execution time: 1.5957
INFO - 2018-03-26 10:38:21 --> Config Class Initialized
INFO - 2018-03-26 10:38:21 --> Hooks Class Initialized
DEBUG - 2018-03-26 10:38:21 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:38:21 --> Utf8 Class Initialized
INFO - 2018-03-26 10:38:21 --> URI Class Initialized
INFO - 2018-03-26 10:38:21 --> Router Class Initialized
INFO - 2018-03-26 10:38:21 --> Config Class Initialized
INFO - 2018-03-26 10:38:21 --> Hooks Class Initialized
INFO - 2018-03-26 10:38:21 --> Output Class Initialized
INFO - 2018-03-26 10:38:21 --> Security Class Initialized
DEBUG - 2018-03-26 10:38:21 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:38:21 --> Utf8 Class Initialized
INFO - 2018-03-26 10:38:21 --> Config Class Initialized
INFO - 2018-03-26 10:38:21 --> Hooks Class Initialized
INFO - 2018-03-26 10:38:21 --> URI Class Initialized
DEBUG - 2018-03-26 10:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:38:21 --> Input Class Initialized
INFO - 2018-03-26 10:38:21 --> Language Class Initialized
DEBUG - 2018-03-26 10:38:21 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:38:21 --> Utf8 Class Initialized
INFO - 2018-03-26 10:38:21 --> Router Class Initialized
INFO - 2018-03-26 10:38:21 --> URI Class Initialized
INFO - 2018-03-26 10:38:21 --> Output Class Initialized
INFO - 2018-03-26 10:38:21 --> Router Class Initialized
INFO - 2018-03-26 10:38:21 --> Security Class Initialized
INFO - 2018-03-26 10:38:22 --> Output Class Initialized
DEBUG - 2018-03-26 10:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:38:22 --> Input Class Initialized
INFO - 2018-03-26 10:38:22 --> Language Class Initialized
INFO - 2018-03-26 10:38:22 --> Security Class Initialized
INFO - 2018-03-26 10:38:22 --> Language Class Initialized
INFO - 2018-03-26 10:38:22 --> Config Class Initialized
INFO - 2018-03-26 10:38:22 --> Loader Class Initialized
INFO - 2018-03-26 16:08:22 --> Helper loaded: url_helper
INFO - 2018-03-26 16:08:22 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:08:22 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:08:22 --> Helper loaded: permission_helper
DEBUG - 2018-03-26 10:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:38:22 --> Input Class Initialized
INFO - 2018-03-26 16:08:22 --> Helper loaded: users_helper
INFO - 2018-03-26 10:38:22 --> Language Class Initialized
INFO - 2018-03-26 16:08:22 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:08:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:08:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:08:22 --> Helper loaded: form_helper
INFO - 2018-03-26 16:08:22 --> Form Validation Class Initialized
INFO - 2018-03-26 16:08:22 --> Controller Class Initialized
INFO - 2018-03-26 16:08:22 --> Model Class Initialized
INFO - 2018-03-26 16:08:22 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:08:22 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:08:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 10:38:22 --> Language Class Initialized
INFO - 2018-03-26 10:38:22 --> Config Class Initialized
INFO - 2018-03-26 16:08:22 --> Model Class Initialized
INFO - 2018-03-26 10:38:22 --> Loader Class Initialized
INFO - 2018-03-26 16:08:22 --> Model Class Initialized
INFO - 2018-03-26 16:08:22 --> Model Class Initialized
INFO - 2018-03-26 16:08:22 --> Model Class Initialized
INFO - 2018-03-26 16:08:22 --> Model Class Initialized
INFO - 2018-03-26 16:08:22 --> Model Class Initialized
INFO - 2018-03-26 16:08:22 --> Model Class Initialized
INFO - 2018-03-26 16:08:22 --> Model Class Initialized
INFO - 2018-03-26 16:08:22 --> Model Class Initialized
INFO - 2018-03-26 16:08:22 --> Model Class Initialized
INFO - 2018-03-26 16:08:22 --> Model Class Initialized
INFO - 2018-03-26 16:08:22 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:08:22 --> Model Class Initialized
INFO - 2018-03-26 16:08:22 --> Helper loaded: url_helper
INFO - 2018-03-26 16:08:22 --> Final output sent to browser
DEBUG - 2018-03-26 16:08:22 --> Total execution time: 0.3616
INFO - 2018-03-26 16:08:22 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:08:22 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:08:22 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:08:22 --> Helper loaded: users_helper
INFO - 2018-03-26 10:38:22 --> Language Class Initialized
INFO - 2018-03-26 10:38:22 --> Config Class Initialized
INFO - 2018-03-26 10:38:22 --> Loader Class Initialized
INFO - 2018-03-26 16:08:22 --> Helper loaded: url_helper
INFO - 2018-03-26 16:08:22 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:08:22 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:08:22 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:08:22 --> Helper loaded: users_helper
INFO - 2018-03-26 16:08:22 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:08:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:08:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:08:22 --> Helper loaded: form_helper
INFO - 2018-03-26 16:08:22 --> Form Validation Class Initialized
INFO - 2018-03-26 16:08:22 --> Controller Class Initialized
INFO - 2018-03-26 16:08:22 --> Model Class Initialized
INFO - 2018-03-26 16:08:22 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:08:22 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:08:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:08:22 --> Model Class Initialized
INFO - 2018-03-26 16:08:22 --> Model Class Initialized
INFO - 2018-03-26 16:08:22 --> Model Class Initialized
INFO - 2018-03-26 16:08:22 --> Model Class Initialized
INFO - 2018-03-26 16:08:22 --> Model Class Initialized
INFO - 2018-03-26 16:08:22 --> Model Class Initialized
INFO - 2018-03-26 16:08:22 --> Model Class Initialized
INFO - 2018-03-26 16:08:22 --> Model Class Initialized
INFO - 2018-03-26 16:08:22 --> Model Class Initialized
INFO - 2018-03-26 16:08:22 --> Model Class Initialized
INFO - 2018-03-26 16:08:22 --> Model Class Initialized
INFO - 2018-03-26 16:08:22 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:08:22 --> Model Class Initialized
INFO - 2018-03-26 16:08:22 --> Final output sent to browser
DEBUG - 2018-03-26 16:08:22 --> Total execution time: 0.9308
INFO - 2018-03-26 16:08:22 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:08:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:08:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:08:22 --> Helper loaded: form_helper
INFO - 2018-03-26 16:08:22 --> Form Validation Class Initialized
INFO - 2018-03-26 16:08:22 --> Controller Class Initialized
INFO - 2018-03-26 16:08:22 --> Model Class Initialized
INFO - 2018-03-26 16:08:22 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:08:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:08:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:08:23 --> Model Class Initialized
INFO - 2018-03-26 16:08:23 --> Model Class Initialized
INFO - 2018-03-26 16:08:23 --> Model Class Initialized
INFO - 2018-03-26 16:08:23 --> Model Class Initialized
INFO - 2018-03-26 16:08:23 --> Model Class Initialized
INFO - 2018-03-26 16:08:23 --> Model Class Initialized
INFO - 2018-03-26 16:08:23 --> Model Class Initialized
INFO - 2018-03-26 16:08:23 --> Model Class Initialized
INFO - 2018-03-26 16:08:23 --> Model Class Initialized
INFO - 2018-03-26 16:08:23 --> Model Class Initialized
INFO - 2018-03-26 16:08:23 --> Model Class Initialized
INFO - 2018-03-26 16:08:23 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:08:23 --> Model Class Initialized
INFO - 2018-03-26 16:08:23 --> Final output sent to browser
DEBUG - 2018-03-26 16:08:23 --> Total execution time: 1.3897
INFO - 2018-03-26 10:38:24 --> Config Class Initialized
INFO - 2018-03-26 10:38:24 --> Hooks Class Initialized
DEBUG - 2018-03-26 10:38:24 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:38:24 --> Utf8 Class Initialized
INFO - 2018-03-26 10:38:24 --> URI Class Initialized
INFO - 2018-03-26 10:38:24 --> Router Class Initialized
INFO - 2018-03-26 10:38:24 --> Output Class Initialized
INFO - 2018-03-26 10:38:24 --> Security Class Initialized
DEBUG - 2018-03-26 10:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:38:24 --> Input Class Initialized
INFO - 2018-03-26 10:38:24 --> Language Class Initialized
INFO - 2018-03-26 10:38:25 --> Language Class Initialized
INFO - 2018-03-26 10:38:25 --> Config Class Initialized
INFO - 2018-03-26 10:38:25 --> Loader Class Initialized
INFO - 2018-03-26 16:08:25 --> Helper loaded: url_helper
INFO - 2018-03-26 16:08:25 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:08:25 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:08:25 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:08:25 --> Helper loaded: users_helper
INFO - 2018-03-26 16:08:25 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:08:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:08:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:08:25 --> Helper loaded: form_helper
INFO - 2018-03-26 16:08:25 --> Form Validation Class Initialized
INFO - 2018-03-26 16:08:25 --> Controller Class Initialized
INFO - 2018-03-26 16:08:25 --> Model Class Initialized
INFO - 2018-03-26 16:08:25 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:08:25 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:08:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:08:25 --> Model Class Initialized
INFO - 2018-03-26 16:08:25 --> Model Class Initialized
INFO - 2018-03-26 16:08:25 --> Model Class Initialized
INFO - 2018-03-26 16:08:25 --> Model Class Initialized
INFO - 2018-03-26 16:08:25 --> Model Class Initialized
INFO - 2018-03-26 16:08:25 --> Model Class Initialized
INFO - 2018-03-26 16:08:25 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-26 16:08:25 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-26 16:08:25 --> Final output sent to browser
DEBUG - 2018-03-26 16:08:25 --> Total execution time: 0.2537
INFO - 2018-03-26 10:38:27 --> Config Class Initialized
INFO - 2018-03-26 10:38:27 --> Hooks Class Initialized
DEBUG - 2018-03-26 10:38:27 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:38:27 --> Utf8 Class Initialized
INFO - 2018-03-26 10:38:27 --> URI Class Initialized
INFO - 2018-03-26 10:38:27 --> Config Class Initialized
INFO - 2018-03-26 10:38:27 --> Hooks Class Initialized
INFO - 2018-03-26 10:38:27 --> Router Class Initialized
INFO - 2018-03-26 10:38:27 --> Output Class Initialized
DEBUG - 2018-03-26 10:38:27 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:38:27 --> Security Class Initialized
INFO - 2018-03-26 10:38:27 --> Utf8 Class Initialized
INFO - 2018-03-26 10:38:27 --> URI Class Initialized
DEBUG - 2018-03-26 10:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:38:27 --> Input Class Initialized
INFO - 2018-03-26 10:38:27 --> Language Class Initialized
INFO - 2018-03-26 10:38:27 --> Router Class Initialized
INFO - 2018-03-26 10:38:27 --> Output Class Initialized
INFO - 2018-03-26 10:38:27 --> Security Class Initialized
DEBUG - 2018-03-26 10:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:38:27 --> Input Class Initialized
INFO - 2018-03-26 10:38:27 --> Language Class Initialized
INFO - 2018-03-26 10:38:28 --> Language Class Initialized
INFO - 2018-03-26 10:38:28 --> Config Class Initialized
INFO - 2018-03-26 10:38:28 --> Loader Class Initialized
INFO - 2018-03-26 16:08:28 --> Helper loaded: url_helper
INFO - 2018-03-26 10:38:28 --> Config Class Initialized
INFO - 2018-03-26 10:38:28 --> Hooks Class Initialized
INFO - 2018-03-26 16:08:28 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:08:28 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:08:28 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:08:28 --> Helper loaded: users_helper
DEBUG - 2018-03-26 10:38:28 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:38:28 --> Utf8 Class Initialized
INFO - 2018-03-26 10:38:28 --> Language Class Initialized
INFO - 2018-03-26 10:38:28 --> Config Class Initialized
INFO - 2018-03-26 10:38:28 --> Loader Class Initialized
INFO - 2018-03-26 16:08:28 --> Database Driver Class Initialized
INFO - 2018-03-26 10:38:28 --> URI Class Initialized
DEBUG - 2018-03-26 16:08:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:08:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:08:28 --> Helper loaded: form_helper
INFO - 2018-03-26 16:08:28 --> Form Validation Class Initialized
INFO - 2018-03-26 16:08:28 --> Controller Class Initialized
INFO - 2018-03-26 16:08:28 --> Model Class Initialized
INFO - 2018-03-26 16:08:28 --> Helper loaded: inflector_helper
INFO - 2018-03-26 16:08:28 --> Helper loaded: url_helper
DEBUG - 2018-03-26 16:08:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:08:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:08:28 --> Model Class Initialized
INFO - 2018-03-26 16:08:28 --> Model Class Initialized
INFO - 2018-03-26 16:08:28 --> Model Class Initialized
INFO - 2018-03-26 16:08:28 --> Model Class Initialized
INFO - 2018-03-26 16:08:28 --> Model Class Initialized
INFO - 2018-03-26 16:08:28 --> Model Class Initialized
INFO - 2018-03-26 16:08:28 --> Model Class Initialized
INFO - 2018-03-26 16:08:28 --> Model Class Initialized
INFO - 2018-03-26 16:08:28 --> Model Class Initialized
INFO - 2018-03-26 16:08:28 --> Helper loaded: notification_helper
INFO - 2018-03-26 10:38:28 --> Router Class Initialized
INFO - 2018-03-26 16:08:28 --> Model Class Initialized
INFO - 2018-03-26 16:08:28 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:08:28 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:08:28 --> Helper loaded: users_helper
INFO - 2018-03-26 10:38:28 --> Output Class Initialized
INFO - 2018-03-26 16:08:28 --> Model Class Initialized
INFO - 2018-03-26 16:08:28 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:08:28 --> Model Class Initialized
INFO - 2018-03-26 16:08:28 --> Final output sent to browser
DEBUG - 2018-03-26 16:08:28 --> Total execution time: 2.0032
INFO - 2018-03-26 10:38:28 --> Security Class Initialized
DEBUG - 2018-03-26 10:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:38:29 --> Input Class Initialized
INFO - 2018-03-26 10:38:29 --> Language Class Initialized
INFO - 2018-03-26 16:08:29 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:08:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:08:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:08:29 --> Helper loaded: form_helper
INFO - 2018-03-26 16:08:29 --> Form Validation Class Initialized
INFO - 2018-03-26 16:08:29 --> Controller Class Initialized
INFO - 2018-03-26 16:08:29 --> Model Class Initialized
INFO - 2018-03-26 16:08:29 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:08:29 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:08:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:08:29 --> Model Class Initialized
INFO - 2018-03-26 16:08:29 --> Model Class Initialized
INFO - 2018-03-26 16:08:29 --> Model Class Initialized
INFO - 2018-03-26 16:08:29 --> Model Class Initialized
INFO - 2018-03-26 16:08:29 --> Model Class Initialized
INFO - 2018-03-26 16:08:29 --> Model Class Initialized
INFO - 2018-03-26 16:08:29 --> Model Class Initialized
INFO - 2018-03-26 16:08:29 --> Model Class Initialized
INFO - 2018-03-26 16:08:29 --> Model Class Initialized
INFO - 2018-03-26 16:08:29 --> Model Class Initialized
INFO - 2018-03-26 16:08:29 --> Model Class Initialized
INFO - 2018-03-26 16:08:29 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:08:29 --> Model Class Initialized
INFO - 2018-03-26 16:08:29 --> Final output sent to browser
DEBUG - 2018-03-26 16:08:29 --> Total execution time: 2.3065
INFO - 2018-03-26 10:38:29 --> Config Class Initialized
INFO - 2018-03-26 10:38:29 --> Hooks Class Initialized
INFO - 2018-03-26 10:38:29 --> Language Class Initialized
INFO - 2018-03-26 10:38:29 --> Config Class Initialized
INFO - 2018-03-26 10:38:29 --> Loader Class Initialized
INFO - 2018-03-26 16:08:30 --> Helper loaded: url_helper
DEBUG - 2018-03-26 10:38:30 --> UTF-8 Support Enabled
INFO - 2018-03-26 16:08:30 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:08:30 --> Helper loaded: settings_helper
INFO - 2018-03-26 10:38:30 --> Utf8 Class Initialized
INFO - 2018-03-26 16:08:30 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:08:30 --> Helper loaded: users_helper
INFO - 2018-03-26 10:38:30 --> URI Class Initialized
INFO - 2018-03-26 10:38:30 --> Router Class Initialized
INFO - 2018-03-26 10:38:30 --> Output Class Initialized
INFO - 2018-03-26 10:38:30 --> Config Class Initialized
INFO - 2018-03-26 10:38:30 --> Hooks Class Initialized
INFO - 2018-03-26 10:38:30 --> Security Class Initialized
DEBUG - 2018-03-26 10:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:38:30 --> Input Class Initialized
DEBUG - 2018-03-26 10:38:30 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:38:30 --> Utf8 Class Initialized
INFO - 2018-03-26 10:38:30 --> Language Class Initialized
INFO - 2018-03-26 10:38:30 --> URI Class Initialized
INFO - 2018-03-26 10:38:30 --> Config Class Initialized
INFO - 2018-03-26 10:38:30 --> Hooks Class Initialized
INFO - 2018-03-26 16:08:30 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:08:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-26 10:38:31 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:38:31 --> Utf8 Class Initialized
INFO - 2018-03-26 16:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 10:38:31 --> URI Class Initialized
INFO - 2018-03-26 10:38:31 --> Router Class Initialized
INFO - 2018-03-26 16:08:31 --> Helper loaded: form_helper
INFO - 2018-03-26 16:08:31 --> Form Validation Class Initialized
INFO - 2018-03-26 16:08:31 --> Controller Class Initialized
INFO - 2018-03-26 10:38:31 --> Router Class Initialized
INFO - 2018-03-26 10:38:31 --> Output Class Initialized
INFO - 2018-03-26 10:38:31 --> Security Class Initialized
DEBUG - 2018-03-26 10:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:38:31 --> Input Class Initialized
INFO - 2018-03-26 16:08:31 --> Model Class Initialized
INFO - 2018-03-26 16:08:31 --> Helper loaded: inflector_helper
INFO - 2018-03-26 10:38:31 --> Language Class Initialized
DEBUG - 2018-03-26 16:08:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 10:38:31 --> Output Class Initialized
INFO - 2018-03-26 16:08:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:08:31 --> Model Class Initialized
INFO - 2018-03-26 16:08:31 --> Model Class Initialized
INFO - 2018-03-26 16:08:31 --> Model Class Initialized
INFO - 2018-03-26 16:08:31 --> Model Class Initialized
INFO - 2018-03-26 16:08:31 --> Model Class Initialized
INFO - 2018-03-26 16:08:31 --> Model Class Initialized
INFO - 2018-03-26 16:08:31 --> Model Class Initialized
INFO - 2018-03-26 16:08:31 --> Model Class Initialized
INFO - 2018-03-26 16:08:31 --> Model Class Initialized
INFO - 2018-03-26 16:08:31 --> Model Class Initialized
INFO - 2018-03-26 10:38:31 --> Security Class Initialized
INFO - 2018-03-26 16:08:31 --> Model Class Initialized
INFO - 2018-03-26 16:08:31 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:08:31 --> Model Class Initialized
INFO - 2018-03-26 16:08:31 --> Final output sent to browser
DEBUG - 2018-03-26 16:08:31 --> Total execution time: 3.5911
INFO - 2018-03-26 10:38:31 --> Language Class Initialized
INFO - 2018-03-26 10:38:31 --> Config Class Initialized
INFO - 2018-03-26 10:38:31 --> Loader Class Initialized
INFO - 2018-03-26 16:08:31 --> Helper loaded: url_helper
INFO - 2018-03-26 16:08:31 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:08:31 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:08:31 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:08:31 --> Helper loaded: users_helper
DEBUG - 2018-03-26 10:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:38:31 --> Input Class Initialized
INFO - 2018-03-26 10:38:31 --> Language Class Initialized
INFO - 2018-03-26 10:38:31 --> Language Class Initialized
INFO - 2018-03-26 10:38:31 --> Config Class Initialized
INFO - 2018-03-26 10:38:31 --> Loader Class Initialized
INFO - 2018-03-26 16:08:31 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:08:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:08:31 --> Helper loaded: url_helper
INFO - 2018-03-26 16:08:31 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:08:32 --> Helper loaded: form_helper
INFO - 2018-03-26 16:08:32 --> Form Validation Class Initialized
INFO - 2018-03-26 16:08:32 --> Controller Class Initialized
INFO - 2018-03-26 16:08:32 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:08:32 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:08:32 --> Model Class Initialized
INFO - 2018-03-26 16:08:32 --> Helper loaded: inflector_helper
INFO - 2018-03-26 16:08:32 --> Helper loaded: users_helper
DEBUG - 2018-03-26 16:08:32 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:08:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:08:32 --> Model Class Initialized
INFO - 2018-03-26 16:08:32 --> Model Class Initialized
INFO - 2018-03-26 16:08:32 --> Model Class Initialized
INFO - 2018-03-26 16:08:32 --> Model Class Initialized
INFO - 2018-03-26 16:08:32 --> Model Class Initialized
INFO - 2018-03-26 16:08:32 --> Model Class Initialized
INFO - 2018-03-26 16:08:32 --> Model Class Initialized
INFO - 2018-03-26 16:08:32 --> Model Class Initialized
INFO - 2018-03-26 16:08:32 --> Model Class Initialized
INFO - 2018-03-26 16:08:32 --> Model Class Initialized
INFO - 2018-03-26 16:08:32 --> Model Class Initialized
INFO - 2018-03-26 16:08:32 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:08:32 --> Model Class Initialized
INFO - 2018-03-26 16:08:32 --> Final output sent to browser
DEBUG - 2018-03-26 16:08:32 --> Total execution time: 1.4142
INFO - 2018-03-26 10:38:32 --> Language Class Initialized
INFO - 2018-03-26 10:38:32 --> Config Class Initialized
INFO - 2018-03-26 10:38:32 --> Loader Class Initialized
INFO - 2018-03-26 16:08:32 --> Helper loaded: url_helper
INFO - 2018-03-26 16:08:32 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:08:32 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:08:32 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:08:32 --> Helper loaded: users_helper
INFO - 2018-03-26 16:08:32 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:08:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:08:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:08:32 --> Helper loaded: form_helper
INFO - 2018-03-26 16:08:32 --> Form Validation Class Initialized
INFO - 2018-03-26 16:08:32 --> Controller Class Initialized
INFO - 2018-03-26 16:08:32 --> Model Class Initialized
INFO - 2018-03-26 16:08:32 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:08:32 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:08:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:08:32 --> Model Class Initialized
INFO - 2018-03-26 16:08:32 --> Model Class Initialized
INFO - 2018-03-26 16:08:32 --> Model Class Initialized
INFO - 2018-03-26 16:08:32 --> Model Class Initialized
INFO - 2018-03-26 16:08:32 --> Model Class Initialized
INFO - 2018-03-26 16:08:32 --> Model Class Initialized
INFO - 2018-03-26 16:08:32 --> Model Class Initialized
INFO - 2018-03-26 16:08:32 --> Model Class Initialized
INFO - 2018-03-26 16:08:32 --> Model Class Initialized
INFO - 2018-03-26 16:08:32 --> Model Class Initialized
INFO - 2018-03-26 16:08:32 --> Model Class Initialized
INFO - 2018-03-26 16:08:32 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:08:32 --> Model Class Initialized
INFO - 2018-03-26 16:08:32 --> Final output sent to browser
DEBUG - 2018-03-26 16:08:32 --> Total execution time: 3.2131
INFO - 2018-03-26 16:08:33 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:08:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:08:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:08:33 --> Helper loaded: form_helper
INFO - 2018-03-26 16:08:33 --> Form Validation Class Initialized
INFO - 2018-03-26 16:08:33 --> Controller Class Initialized
INFO - 2018-03-26 16:08:33 --> Model Class Initialized
INFO - 2018-03-26 16:08:33 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:08:33 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:08:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:08:33 --> Model Class Initialized
INFO - 2018-03-26 16:08:33 --> Model Class Initialized
INFO - 2018-03-26 16:08:33 --> Model Class Initialized
INFO - 2018-03-26 16:08:33 --> Model Class Initialized
INFO - 2018-03-26 16:08:33 --> Model Class Initialized
INFO - 2018-03-26 16:08:33 --> Model Class Initialized
INFO - 2018-03-26 16:08:33 --> Model Class Initialized
INFO - 2018-03-26 16:08:33 --> Model Class Initialized
INFO - 2018-03-26 16:08:33 --> Model Class Initialized
INFO - 2018-03-26 16:08:33 --> Model Class Initialized
INFO - 2018-03-26 16:08:33 --> Model Class Initialized
INFO - 2018-03-26 16:08:33 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:08:33 --> Model Class Initialized
INFO - 2018-03-26 16:08:33 --> Final output sent to browser
DEBUG - 2018-03-26 16:08:33 --> Total execution time: 2.6890
INFO - 2018-03-26 10:38:36 --> Config Class Initialized
INFO - 2018-03-26 10:38:36 --> Hooks Class Initialized
DEBUG - 2018-03-26 10:38:36 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:38:36 --> Utf8 Class Initialized
INFO - 2018-03-26 10:38:36 --> URI Class Initialized
INFO - 2018-03-26 10:38:36 --> Router Class Initialized
INFO - 2018-03-26 10:38:36 --> Output Class Initialized
INFO - 2018-03-26 10:38:36 --> Security Class Initialized
DEBUG - 2018-03-26 10:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:38:36 --> Input Class Initialized
INFO - 2018-03-26 10:38:36 --> Language Class Initialized
INFO - 2018-03-26 10:38:36 --> Language Class Initialized
INFO - 2018-03-26 10:38:36 --> Config Class Initialized
INFO - 2018-03-26 10:38:36 --> Loader Class Initialized
INFO - 2018-03-26 16:08:36 --> Helper loaded: url_helper
INFO - 2018-03-26 16:08:36 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:08:36 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:08:36 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:08:36 --> Helper loaded: users_helper
INFO - 2018-03-26 16:08:36 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:08:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:08:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:08:36 --> Helper loaded: form_helper
INFO - 2018-03-26 16:08:36 --> Form Validation Class Initialized
INFO - 2018-03-26 16:08:36 --> Controller Class Initialized
INFO - 2018-03-26 16:08:36 --> Model Class Initialized
INFO - 2018-03-26 16:08:36 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:08:36 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:08:36 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:08:36 --> Model Class Initialized
INFO - 2018-03-26 16:08:36 --> Model Class Initialized
INFO - 2018-03-26 16:08:36 --> Model Class Initialized
INFO - 2018-03-26 16:08:36 --> Model Class Initialized
INFO - 2018-03-26 16:08:36 --> Model Class Initialized
INFO - 2018-03-26 16:08:36 --> Model Class Initialized
INFO - 2018-03-26 16:08:37 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-26 16:08:37 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-26 10:38:37 --> Config Class Initialized
INFO - 2018-03-26 10:38:37 --> Hooks Class Initialized
DEBUG - 2018-03-26 10:38:37 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:38:37 --> Utf8 Class Initialized
INFO - 2018-03-26 10:38:37 --> URI Class Initialized
INFO - 2018-03-26 10:38:37 --> Router Class Initialized
INFO - 2018-03-26 10:38:37 --> Output Class Initialized
INFO - 2018-03-26 10:38:37 --> Security Class Initialized
DEBUG - 2018-03-26 10:38:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:38:37 --> Input Class Initialized
INFO - 2018-03-26 10:38:37 --> Language Class Initialized
INFO - 2018-03-26 16:08:37 --> Final output sent to browser
DEBUG - 2018-03-26 16:08:37 --> Total execution time: 1.1200
INFO - 2018-03-26 10:38:37 --> Language Class Initialized
INFO - 2018-03-26 10:38:37 --> Config Class Initialized
INFO - 2018-03-26 10:38:37 --> Loader Class Initialized
INFO - 2018-03-26 16:08:37 --> Helper loaded: url_helper
INFO - 2018-03-26 16:08:37 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:08:37 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:08:37 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:08:37 --> Helper loaded: users_helper
INFO - 2018-03-26 16:08:37 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:08:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:08:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:08:37 --> Helper loaded: form_helper
INFO - 2018-03-26 16:08:37 --> Form Validation Class Initialized
INFO - 2018-03-26 16:08:37 --> Controller Class Initialized
INFO - 2018-03-26 16:08:37 --> Model Class Initialized
INFO - 2018-03-26 16:08:37 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:08:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:08:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:08:37 --> Model Class Initialized
INFO - 2018-03-26 16:08:37 --> Model Class Initialized
INFO - 2018-03-26 16:08:37 --> Model Class Initialized
INFO - 2018-03-26 16:08:37 --> Model Class Initialized
INFO - 2018-03-26 16:08:37 --> Model Class Initialized
INFO - 2018-03-26 16:08:37 --> Model Class Initialized
INFO - 2018-03-26 16:08:37 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-26 16:08:37 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-26 16:08:37 --> Final output sent to browser
DEBUG - 2018-03-26 16:08:37 --> Total execution time: 0.5530
INFO - 2018-03-26 10:38:39 --> Config Class Initialized
INFO - 2018-03-26 10:38:39 --> Hooks Class Initialized
DEBUG - 2018-03-26 10:38:39 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:38:39 --> Utf8 Class Initialized
INFO - 2018-03-26 10:38:39 --> URI Class Initialized
INFO - 2018-03-26 10:38:39 --> Router Class Initialized
INFO - 2018-03-26 10:38:39 --> Output Class Initialized
INFO - 2018-03-26 10:38:39 --> Security Class Initialized
DEBUG - 2018-03-26 10:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:38:39 --> Input Class Initialized
INFO - 2018-03-26 10:38:39 --> Language Class Initialized
INFO - 2018-03-26 10:38:39 --> Language Class Initialized
INFO - 2018-03-26 10:38:39 --> Config Class Initialized
INFO - 2018-03-26 10:38:39 --> Loader Class Initialized
INFO - 2018-03-26 16:08:39 --> Helper loaded: url_helper
INFO - 2018-03-26 16:08:39 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:08:39 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:08:39 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:08:39 --> Helper loaded: users_helper
INFO - 2018-03-26 16:08:40 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:08:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:08:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:08:40 --> Helper loaded: form_helper
INFO - 2018-03-26 16:08:40 --> Form Validation Class Initialized
INFO - 2018-03-26 16:08:40 --> Controller Class Initialized
INFO - 2018-03-26 16:08:40 --> Model Class Initialized
INFO - 2018-03-26 16:08:40 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:08:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:08:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:08:40 --> Model Class Initialized
INFO - 2018-03-26 16:08:40 --> Model Class Initialized
INFO - 2018-03-26 16:08:40 --> Model Class Initialized
INFO - 2018-03-26 16:08:40 --> Model Class Initialized
INFO - 2018-03-26 16:08:40 --> Model Class Initialized
INFO - 2018-03-26 16:08:40 --> Model Class Initialized
INFO - 2018-03-26 16:08:40 --> Model Class Initialized
INFO - 2018-03-26 16:08:40 --> Model Class Initialized
INFO - 2018-03-26 16:08:40 --> Model Class Initialized
INFO - 2018-03-26 16:08:40 --> Model Class Initialized
INFO - 2018-03-26 16:08:40 --> Model Class Initialized
INFO - 2018-03-26 16:08:40 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:08:40 --> Model Class Initialized
INFO - 2018-03-26 16:08:40 --> Final output sent to browser
DEBUG - 2018-03-26 16:08:40 --> Total execution time: 0.8274
INFO - 2018-03-26 10:38:40 --> Config Class Initialized
INFO - 2018-03-26 10:38:40 --> Hooks Class Initialized
DEBUG - 2018-03-26 10:38:40 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:38:40 --> Utf8 Class Initialized
INFO - 2018-03-26 10:38:40 --> URI Class Initialized
INFO - 2018-03-26 10:38:40 --> Router Class Initialized
INFO - 2018-03-26 10:38:40 --> Config Class Initialized
INFO - 2018-03-26 10:38:40 --> Hooks Class Initialized
INFO - 2018-03-26 10:38:40 --> Output Class Initialized
INFO - 2018-03-26 10:38:40 --> Security Class Initialized
DEBUG - 2018-03-26 10:38:40 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:38:40 --> Utf8 Class Initialized
INFO - 2018-03-26 10:38:40 --> URI Class Initialized
DEBUG - 2018-03-26 10:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:38:40 --> Input Class Initialized
INFO - 2018-03-26 10:38:40 --> Language Class Initialized
INFO - 2018-03-26 10:38:40 --> Router Class Initialized
INFO - 2018-03-26 10:38:41 --> Output Class Initialized
INFO - 2018-03-26 10:38:41 --> Security Class Initialized
DEBUG - 2018-03-26 10:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:38:41 --> Input Class Initialized
INFO - 2018-03-26 10:38:41 --> Language Class Initialized
INFO - 2018-03-26 10:38:41 --> Language Class Initialized
INFO - 2018-03-26 10:38:41 --> Config Class Initialized
INFO - 2018-03-26 10:38:41 --> Loader Class Initialized
INFO - 2018-03-26 16:08:41 --> Helper loaded: url_helper
INFO - 2018-03-26 10:38:41 --> Config Class Initialized
INFO - 2018-03-26 10:38:41 --> Hooks Class Initialized
INFO - 2018-03-26 16:08:41 --> Helper loaded: notification_helper
DEBUG - 2018-03-26 10:38:41 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:38:41 --> Utf8 Class Initialized
INFO - 2018-03-26 10:38:41 --> URI Class Initialized
INFO - 2018-03-26 10:38:41 --> Config Class Initialized
INFO - 2018-03-26 10:38:41 --> Hooks Class Initialized
INFO - 2018-03-26 16:08:41 --> Helper loaded: settings_helper
DEBUG - 2018-03-26 10:38:41 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:38:41 --> Utf8 Class Initialized
INFO - 2018-03-26 16:08:41 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:08:41 --> Helper loaded: users_helper
INFO - 2018-03-26 10:38:41 --> URI Class Initialized
INFO - 2018-03-26 10:38:41 --> Router Class Initialized
INFO - 2018-03-26 10:38:41 --> Router Class Initialized
INFO - 2018-03-26 10:38:41 --> Output Class Initialized
INFO - 2018-03-26 10:38:41 --> Output Class Initialized
INFO - 2018-03-26 10:38:41 --> Security Class Initialized
DEBUG - 2018-03-26 10:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:38:42 --> Input Class Initialized
INFO - 2018-03-26 10:38:42 --> Language Class Initialized
INFO - 2018-03-26 10:38:42 --> Security Class Initialized
INFO - 2018-03-26 16:08:42 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:08:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:08:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-03-26 10:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:38:42 --> Input Class Initialized
INFO - 2018-03-26 10:38:42 --> Language Class Initialized
INFO - 2018-03-26 16:08:42 --> Helper loaded: form_helper
INFO - 2018-03-26 16:08:42 --> Form Validation Class Initialized
INFO - 2018-03-26 16:08:42 --> Controller Class Initialized
INFO - 2018-03-26 10:38:42 --> Language Class Initialized
INFO - 2018-03-26 10:38:42 --> Config Class Initialized
INFO - 2018-03-26 10:38:42 --> Loader Class Initialized
INFO - 2018-03-26 16:08:42 --> Helper loaded: url_helper
INFO - 2018-03-26 16:08:42 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:08:42 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:08:42 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:08:42 --> Helper loaded: users_helper
INFO - 2018-03-26 16:08:42 --> Model Class Initialized
INFO - 2018-03-26 16:08:42 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:08:42 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:08:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:08:42 --> Model Class Initialized
INFO - 2018-03-26 16:08:42 --> Model Class Initialized
INFO - 2018-03-26 16:08:42 --> Model Class Initialized
INFO - 2018-03-26 16:08:42 --> Model Class Initialized
INFO - 2018-03-26 16:08:42 --> Model Class Initialized
INFO - 2018-03-26 16:08:42 --> Model Class Initialized
INFO - 2018-03-26 16:08:42 --> Model Class Initialized
INFO - 2018-03-26 16:08:42 --> Model Class Initialized
INFO - 2018-03-26 16:08:42 --> Model Class Initialized
INFO - 2018-03-26 16:08:42 --> Model Class Initialized
INFO - 2018-03-26 16:08:42 --> Database Driver Class Initialized
INFO - 2018-03-26 16:08:42 --> Model Class Initialized
INFO - 2018-03-26 16:08:42 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:08:42 --> Model Class Initialized
DEBUG - 2018-03-26 16:08:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:08:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:08:42 --> Helper loaded: form_helper
INFO - 2018-03-26 16:08:42 --> Form Validation Class Initialized
INFO - 2018-03-26 16:08:42 --> Controller Class Initialized
INFO - 2018-03-26 16:08:42 --> Model Class Initialized
INFO - 2018-03-26 16:08:42 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:08:42 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:08:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:08:42 --> Model Class Initialized
INFO - 2018-03-26 16:08:42 --> Model Class Initialized
INFO - 2018-03-26 16:08:42 --> Model Class Initialized
INFO - 2018-03-26 16:08:42 --> Model Class Initialized
INFO - 2018-03-26 16:08:42 --> Model Class Initialized
INFO - 2018-03-26 16:08:42 --> Model Class Initialized
INFO - 2018-03-26 16:08:42 --> Model Class Initialized
INFO - 2018-03-26 16:08:42 --> Model Class Initialized
INFO - 2018-03-26 16:08:42 --> Model Class Initialized
INFO - 2018-03-26 16:08:42 --> Model Class Initialized
INFO - 2018-03-26 16:08:42 --> Model Class Initialized
INFO - 2018-03-26 16:08:42 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:08:42 --> Model Class Initialized
INFO - 2018-03-26 16:08:42 --> Final output sent to browser
DEBUG - 2018-03-26 16:08:42 --> Total execution time: 0.1780
INFO - 2018-03-26 10:38:42 --> Language Class Initialized
INFO - 2018-03-26 10:38:42 --> Config Class Initialized
INFO - 2018-03-26 10:38:42 --> Loader Class Initialized
INFO - 2018-03-26 16:08:42 --> Helper loaded: url_helper
INFO - 2018-03-26 16:08:42 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:08:42 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:08:42 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:08:42 --> Helper loaded: users_helper
INFO - 2018-03-26 16:08:42 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:08:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:08:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:08:42 --> Helper loaded: form_helper
INFO - 2018-03-26 16:08:42 --> Form Validation Class Initialized
INFO - 2018-03-26 16:08:42 --> Controller Class Initialized
INFO - 2018-03-26 16:08:42 --> Model Class Initialized
INFO - 2018-03-26 16:08:42 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:08:42 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:08:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:08:42 --> Model Class Initialized
INFO - 2018-03-26 16:08:42 --> Model Class Initialized
INFO - 2018-03-26 16:08:42 --> Model Class Initialized
INFO - 2018-03-26 16:08:42 --> Model Class Initialized
INFO - 2018-03-26 16:08:42 --> Model Class Initialized
INFO - 2018-03-26 16:08:42 --> Model Class Initialized
INFO - 2018-03-26 16:08:42 --> Model Class Initialized
INFO - 2018-03-26 16:08:42 --> Model Class Initialized
INFO - 2018-03-26 16:08:42 --> Model Class Initialized
INFO - 2018-03-26 16:08:42 --> Model Class Initialized
INFO - 2018-03-26 16:08:42 --> Model Class Initialized
INFO - 2018-03-26 16:08:42 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:08:42 --> Model Class Initialized
INFO - 2018-03-26 16:08:42 --> Final output sent to browser
DEBUG - 2018-03-26 16:08:42 --> Total execution time: 0.4004
INFO - 2018-03-26 16:08:42 --> Final output sent to browser
DEBUG - 2018-03-26 16:08:42 --> Total execution time: 2.2034
INFO - 2018-03-26 10:38:42 --> Language Class Initialized
INFO - 2018-03-26 10:38:42 --> Config Class Initialized
INFO - 2018-03-26 10:38:42 --> Loader Class Initialized
INFO - 2018-03-26 16:08:42 --> Helper loaded: url_helper
INFO - 2018-03-26 16:08:42 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:08:42 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:08:42 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:08:42 --> Helper loaded: users_helper
INFO - 2018-03-26 16:08:44 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:08:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:08:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:08:44 --> Helper loaded: form_helper
INFO - 2018-03-26 16:08:44 --> Form Validation Class Initialized
INFO - 2018-03-26 16:08:44 --> Controller Class Initialized
INFO - 2018-03-26 16:08:44 --> Model Class Initialized
INFO - 2018-03-26 16:08:44 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:08:44 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:08:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:08:44 --> Model Class Initialized
INFO - 2018-03-26 16:08:44 --> Model Class Initialized
INFO - 2018-03-26 16:08:44 --> Model Class Initialized
INFO - 2018-03-26 16:08:44 --> Model Class Initialized
INFO - 2018-03-26 16:08:44 --> Model Class Initialized
INFO - 2018-03-26 16:08:44 --> Model Class Initialized
INFO - 2018-03-26 16:08:44 --> Model Class Initialized
INFO - 2018-03-26 16:08:44 --> Model Class Initialized
INFO - 2018-03-26 16:08:44 --> Model Class Initialized
INFO - 2018-03-26 16:08:44 --> Model Class Initialized
INFO - 2018-03-26 16:08:44 --> Model Class Initialized
INFO - 2018-03-26 16:08:44 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:08:44 --> Model Class Initialized
INFO - 2018-03-26 16:08:44 --> Final output sent to browser
DEBUG - 2018-03-26 16:08:44 --> Total execution time: 3.7054
INFO - 2018-03-26 10:40:36 --> Config Class Initialized
INFO - 2018-03-26 10:40:36 --> Hooks Class Initialized
DEBUG - 2018-03-26 10:40:36 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:40:36 --> Utf8 Class Initialized
INFO - 2018-03-26 10:40:36 --> URI Class Initialized
INFO - 2018-03-26 10:40:36 --> Router Class Initialized
INFO - 2018-03-26 10:40:36 --> Output Class Initialized
INFO - 2018-03-26 10:40:36 --> Security Class Initialized
DEBUG - 2018-03-26 10:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:40:36 --> Input Class Initialized
INFO - 2018-03-26 10:40:36 --> Language Class Initialized
INFO - 2018-03-26 10:40:36 --> Language Class Initialized
INFO - 2018-03-26 10:40:36 --> Config Class Initialized
INFO - 2018-03-26 10:40:36 --> Loader Class Initialized
INFO - 2018-03-26 16:10:36 --> Helper loaded: url_helper
INFO - 2018-03-26 16:10:36 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:10:36 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:10:36 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:10:36 --> Helper loaded: users_helper
INFO - 2018-03-26 16:10:36 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:10:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:10:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:10:36 --> Helper loaded: form_helper
INFO - 2018-03-26 16:10:36 --> Form Validation Class Initialized
INFO - 2018-03-26 16:10:36 --> Controller Class Initialized
INFO - 2018-03-26 16:10:36 --> Model Class Initialized
INFO - 2018-03-26 16:10:36 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:10:36 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:10:36 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:10:36 --> Model Class Initialized
INFO - 2018-03-26 16:10:36 --> Model Class Initialized
INFO - 2018-03-26 16:10:36 --> Model Class Initialized
INFO - 2018-03-26 16:10:36 --> Model Class Initialized
INFO - 2018-03-26 16:10:36 --> Model Class Initialized
INFO - 2018-03-26 16:10:36 --> Model Class Initialized
INFO - 2018-03-26 16:10:36 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:10:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-26 16:10:36 --> Final output sent to browser
DEBUG - 2018-03-26 16:10:36 --> Total execution time: 0.2480
INFO - 2018-03-26 10:40:37 --> Config Class Initialized
INFO - 2018-03-26 10:40:37 --> Hooks Class Initialized
DEBUG - 2018-03-26 10:40:37 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:40:37 --> Utf8 Class Initialized
INFO - 2018-03-26 10:40:37 --> URI Class Initialized
INFO - 2018-03-26 10:40:37 --> Router Class Initialized
INFO - 2018-03-26 10:40:37 --> Output Class Initialized
INFO - 2018-03-26 10:40:37 --> Security Class Initialized
INFO - 2018-03-26 10:40:37 --> Config Class Initialized
INFO - 2018-03-26 10:40:37 --> Hooks Class Initialized
DEBUG - 2018-03-26 10:40:37 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:40:37 --> Utf8 Class Initialized
INFO - 2018-03-26 10:40:37 --> URI Class Initialized
DEBUG - 2018-03-26 10:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:40:37 --> Input Class Initialized
INFO - 2018-03-26 10:40:37 --> Router Class Initialized
INFO - 2018-03-26 10:40:37 --> Language Class Initialized
INFO - 2018-03-26 10:40:37 --> Output Class Initialized
INFO - 2018-03-26 10:40:37 --> Security Class Initialized
DEBUG - 2018-03-26 10:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:40:37 --> Input Class Initialized
INFO - 2018-03-26 10:40:37 --> Language Class Initialized
INFO - 2018-03-26 10:40:38 --> Language Class Initialized
INFO - 2018-03-26 10:40:38 --> Config Class Initialized
INFO - 2018-03-26 10:40:38 --> Loader Class Initialized
INFO - 2018-03-26 16:10:38 --> Helper loaded: url_helper
INFO - 2018-03-26 16:10:38 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:10:38 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:10:38 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:10:38 --> Helper loaded: users_helper
INFO - 2018-03-26 16:10:38 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:10:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:10:38 --> Helper loaded: form_helper
INFO - 2018-03-26 16:10:38 --> Form Validation Class Initialized
INFO - 2018-03-26 16:10:38 --> Controller Class Initialized
INFO - 2018-03-26 16:10:38 --> Model Class Initialized
INFO - 2018-03-26 16:10:38 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:10:38 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:10:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:10:38 --> Model Class Initialized
INFO - 2018-03-26 16:10:38 --> Model Class Initialized
INFO - 2018-03-26 16:10:38 --> Model Class Initialized
INFO - 2018-03-26 16:10:38 --> Model Class Initialized
INFO - 2018-03-26 16:10:38 --> Model Class Initialized
INFO - 2018-03-26 16:10:38 --> Model Class Initialized
INFO - 2018-03-26 16:10:38 --> Model Class Initialized
INFO - 2018-03-26 16:10:38 --> Model Class Initialized
INFO - 2018-03-26 16:10:38 --> Model Class Initialized
INFO - 2018-03-26 16:10:38 --> Model Class Initialized
INFO - 2018-03-26 16:10:38 --> Model Class Initialized
INFO - 2018-03-26 16:10:38 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:10:38 --> Model Class Initialized
INFO - 2018-03-26 16:10:38 --> Final output sent to browser
DEBUG - 2018-03-26 16:10:38 --> Total execution time: 0.2000
INFO - 2018-03-26 10:40:38 --> Language Class Initialized
INFO - 2018-03-26 10:40:38 --> Config Class Initialized
INFO - 2018-03-26 10:40:38 --> Loader Class Initialized
INFO - 2018-03-26 16:10:38 --> Helper loaded: url_helper
INFO - 2018-03-26 16:10:38 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:10:38 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:10:38 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:10:38 --> Helper loaded: users_helper
INFO - 2018-03-26 16:10:38 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:10:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:10:38 --> Helper loaded: form_helper
INFO - 2018-03-26 16:10:38 --> Form Validation Class Initialized
INFO - 2018-03-26 16:10:38 --> Controller Class Initialized
INFO - 2018-03-26 16:10:38 --> Model Class Initialized
INFO - 2018-03-26 16:10:38 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:10:38 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:10:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:10:38 --> Model Class Initialized
INFO - 2018-03-26 16:10:38 --> Model Class Initialized
INFO - 2018-03-26 16:10:38 --> Model Class Initialized
INFO - 2018-03-26 16:10:38 --> Model Class Initialized
INFO - 2018-03-26 16:10:38 --> Model Class Initialized
INFO - 2018-03-26 16:10:38 --> Model Class Initialized
INFO - 2018-03-26 16:10:38 --> Model Class Initialized
INFO - 2018-03-26 16:10:38 --> Model Class Initialized
INFO - 2018-03-26 16:10:38 --> Model Class Initialized
INFO - 2018-03-26 16:10:38 --> Model Class Initialized
INFO - 2018-03-26 16:10:38 --> Model Class Initialized
INFO - 2018-03-26 16:10:38 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:10:38 --> Model Class Initialized
INFO - 2018-03-26 16:10:38 --> Final output sent to browser
DEBUG - 2018-03-26 16:10:38 --> Total execution time: 0.7649
INFO - 2018-03-26 10:40:40 --> Config Class Initialized
INFO - 2018-03-26 10:40:40 --> Hooks Class Initialized
DEBUG - 2018-03-26 10:40:40 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:40:40 --> Utf8 Class Initialized
INFO - 2018-03-26 10:40:40 --> URI Class Initialized
INFO - 2018-03-26 10:40:40 --> Router Class Initialized
INFO - 2018-03-26 10:40:40 --> Output Class Initialized
INFO - 2018-03-26 10:40:40 --> Security Class Initialized
DEBUG - 2018-03-26 10:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:40:40 --> Input Class Initialized
INFO - 2018-03-26 10:40:40 --> Language Class Initialized
INFO - 2018-03-26 10:40:40 --> Language Class Initialized
INFO - 2018-03-26 10:40:40 --> Config Class Initialized
INFO - 2018-03-26 10:40:40 --> Loader Class Initialized
INFO - 2018-03-26 16:10:40 --> Helper loaded: url_helper
INFO - 2018-03-26 16:10:40 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:10:40 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:10:40 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:10:40 --> Helper loaded: users_helper
INFO - 2018-03-26 16:10:40 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:10:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:10:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:10:40 --> Helper loaded: form_helper
INFO - 2018-03-26 16:10:40 --> Form Validation Class Initialized
INFO - 2018-03-26 16:10:40 --> Controller Class Initialized
INFO - 2018-03-26 16:10:40 --> Model Class Initialized
INFO - 2018-03-26 16:10:40 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:10:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:10:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:10:40 --> Model Class Initialized
INFO - 2018-03-26 16:10:40 --> Model Class Initialized
INFO - 2018-03-26 16:10:40 --> Model Class Initialized
INFO - 2018-03-26 16:10:40 --> Model Class Initialized
INFO - 2018-03-26 16:10:40 --> Model Class Initialized
INFO - 2018-03-26 16:10:40 --> Model Class Initialized
INFO - 2018-03-26 16:10:40 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-26 16:10:40 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-26 16:10:40 --> Final output sent to browser
DEBUG - 2018-03-26 16:10:40 --> Total execution time: 0.1677
INFO - 2018-03-26 10:43:11 --> Config Class Initialized
INFO - 2018-03-26 10:43:11 --> Hooks Class Initialized
DEBUG - 2018-03-26 10:43:11 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:43:11 --> Utf8 Class Initialized
INFO - 2018-03-26 10:43:11 --> URI Class Initialized
INFO - 2018-03-26 10:43:11 --> Router Class Initialized
INFO - 2018-03-26 10:43:11 --> Output Class Initialized
INFO - 2018-03-26 10:43:11 --> Security Class Initialized
DEBUG - 2018-03-26 10:43:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:43:11 --> Input Class Initialized
INFO - 2018-03-26 10:43:11 --> Language Class Initialized
INFO - 2018-03-26 10:43:11 --> Language Class Initialized
INFO - 2018-03-26 10:43:11 --> Config Class Initialized
INFO - 2018-03-26 10:43:11 --> Loader Class Initialized
INFO - 2018-03-26 16:13:11 --> Helper loaded: url_helper
INFO - 2018-03-26 16:13:11 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:13:11 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:13:11 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:13:11 --> Helper loaded: users_helper
INFO - 2018-03-26 16:13:11 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:13:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:13:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:13:11 --> Helper loaded: form_helper
INFO - 2018-03-26 16:13:11 --> Form Validation Class Initialized
INFO - 2018-03-26 16:13:11 --> Controller Class Initialized
INFO - 2018-03-26 16:13:11 --> Model Class Initialized
INFO - 2018-03-26 16:13:11 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:13:11 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:13:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:13:11 --> Model Class Initialized
INFO - 2018-03-26 16:13:11 --> Model Class Initialized
INFO - 2018-03-26 16:13:11 --> Model Class Initialized
INFO - 2018-03-26 16:13:11 --> Model Class Initialized
INFO - 2018-03-26 16:13:11 --> Model Class Initialized
INFO - 2018-03-26 16:13:11 --> Model Class Initialized
INFO - 2018-03-26 16:13:11 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-26 16:13:11 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-26 16:13:11 --> Final output sent to browser
DEBUG - 2018-03-26 16:13:11 --> Total execution time: 0.2788
INFO - 2018-03-26 10:43:14 --> Config Class Initialized
INFO - 2018-03-26 10:43:14 --> Hooks Class Initialized
DEBUG - 2018-03-26 10:43:14 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:43:14 --> Utf8 Class Initialized
INFO - 2018-03-26 10:43:15 --> URI Class Initialized
INFO - 2018-03-26 10:43:15 --> Router Class Initialized
INFO - 2018-03-26 10:43:15 --> Output Class Initialized
INFO - 2018-03-26 10:43:15 --> Security Class Initialized
DEBUG - 2018-03-26 10:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:43:15 --> Input Class Initialized
INFO - 2018-03-26 10:43:15 --> Language Class Initialized
INFO - 2018-03-26 10:43:16 --> Language Class Initialized
INFO - 2018-03-26 10:43:16 --> Config Class Initialized
INFO - 2018-03-26 10:43:16 --> Loader Class Initialized
INFO - 2018-03-26 16:13:16 --> Helper loaded: url_helper
INFO - 2018-03-26 16:13:16 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:13:16 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:13:16 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:13:16 --> Helper loaded: users_helper
INFO - 2018-03-26 16:13:16 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:13:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:13:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:13:16 --> Helper loaded: form_helper
INFO - 2018-03-26 16:13:16 --> Form Validation Class Initialized
INFO - 2018-03-26 16:13:16 --> Controller Class Initialized
INFO - 2018-03-26 16:13:16 --> Model Class Initialized
INFO - 2018-03-26 16:13:16 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:13:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:13:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:13:16 --> Model Class Initialized
INFO - 2018-03-26 16:13:16 --> Model Class Initialized
INFO - 2018-03-26 16:13:16 --> Model Class Initialized
INFO - 2018-03-26 16:13:16 --> Model Class Initialized
INFO - 2018-03-26 16:13:16 --> Model Class Initialized
INFO - 2018-03-26 16:13:16 --> Model Class Initialized
INFO - 2018-03-26 16:13:16 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-26 16:13:16 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-26 16:13:16 --> Final output sent to browser
DEBUG - 2018-03-26 16:13:16 --> Total execution time: 1.9750
INFO - 2018-03-26 10:43:17 --> Config Class Initialized
INFO - 2018-03-26 10:43:17 --> Hooks Class Initialized
DEBUG - 2018-03-26 10:43:17 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:43:17 --> Utf8 Class Initialized
INFO - 2018-03-26 10:43:17 --> URI Class Initialized
INFO - 2018-03-26 10:43:17 --> Router Class Initialized
INFO - 2018-03-26 10:43:17 --> Output Class Initialized
INFO - 2018-03-26 10:43:17 --> Security Class Initialized
DEBUG - 2018-03-26 10:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:43:17 --> Input Class Initialized
INFO - 2018-03-26 10:43:17 --> Language Class Initialized
INFO - 2018-03-26 10:43:17 --> Language Class Initialized
INFO - 2018-03-26 10:43:17 --> Config Class Initialized
INFO - 2018-03-26 10:43:17 --> Loader Class Initialized
INFO - 2018-03-26 16:13:17 --> Helper loaded: url_helper
INFO - 2018-03-26 16:13:17 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:13:17 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:13:17 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:13:17 --> Helper loaded: users_helper
INFO - 2018-03-26 16:13:17 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:13:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:13:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:13:17 --> Helper loaded: form_helper
INFO - 2018-03-26 16:13:17 --> Form Validation Class Initialized
INFO - 2018-03-26 16:13:17 --> Controller Class Initialized
INFO - 2018-03-26 16:13:18 --> Model Class Initialized
INFO - 2018-03-26 16:13:18 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:13:18 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:13:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:13:18 --> Model Class Initialized
INFO - 2018-03-26 16:13:18 --> Model Class Initialized
INFO - 2018-03-26 16:13:18 --> Model Class Initialized
INFO - 2018-03-26 16:13:18 --> Model Class Initialized
INFO - 2018-03-26 16:13:18 --> Model Class Initialized
INFO - 2018-03-26 16:13:18 --> Model Class Initialized
INFO - 2018-03-26 16:13:18 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-26 16:13:18 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-26 16:13:18 --> Final output sent to browser
DEBUG - 2018-03-26 16:13:18 --> Total execution time: 1.2467
INFO - 2018-03-26 11:04:24 --> Config Class Initialized
INFO - 2018-03-26 11:04:24 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:04:24 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:04:24 --> Utf8 Class Initialized
INFO - 2018-03-26 11:04:24 --> URI Class Initialized
INFO - 2018-03-26 11:04:24 --> Router Class Initialized
INFO - 2018-03-26 11:04:24 --> Output Class Initialized
INFO - 2018-03-26 11:04:24 --> Security Class Initialized
DEBUG - 2018-03-26 11:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:04:24 --> Input Class Initialized
INFO - 2018-03-26 11:04:24 --> Language Class Initialized
INFO - 2018-03-26 11:04:24 --> Language Class Initialized
INFO - 2018-03-26 11:04:24 --> Config Class Initialized
INFO - 2018-03-26 11:04:24 --> Loader Class Initialized
INFO - 2018-03-26 16:34:24 --> Helper loaded: url_helper
INFO - 2018-03-26 16:34:24 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:34:24 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:34:24 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:34:24 --> Helper loaded: users_helper
INFO - 2018-03-26 16:34:24 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:34:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:34:24 --> Helper loaded: form_helper
INFO - 2018-03-26 16:34:24 --> Form Validation Class Initialized
INFO - 2018-03-26 16:34:24 --> Controller Class Initialized
INFO - 2018-03-26 16:34:24 --> Model Class Initialized
INFO - 2018-03-26 16:34:24 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:34:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:34:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:34:24 --> Model Class Initialized
INFO - 2018-03-26 16:34:24 --> Model Class Initialized
INFO - 2018-03-26 16:34:24 --> Model Class Initialized
INFO - 2018-03-26 16:34:24 --> Model Class Initialized
INFO - 2018-03-26 16:34:24 --> Model Class Initialized
INFO - 2018-03-26 16:34:24 --> Model Class Initialized
INFO - 2018-03-26 16:34:24 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:34:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-26 16:34:24 --> Final output sent to browser
DEBUG - 2018-03-26 16:34:24 --> Total execution time: 0.1981
INFO - 2018-03-26 11:04:26 --> Config Class Initialized
INFO - 2018-03-26 11:04:26 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:04:26 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:04:26 --> Utf8 Class Initialized
INFO - 2018-03-26 11:04:26 --> URI Class Initialized
INFO - 2018-03-26 11:04:27 --> Router Class Initialized
INFO - 2018-03-26 11:04:27 --> Output Class Initialized
INFO - 2018-03-26 11:04:27 --> Security Class Initialized
DEBUG - 2018-03-26 11:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:04:27 --> Input Class Initialized
INFO - 2018-03-26 11:04:27 --> Language Class Initialized
INFO - 2018-03-26 11:04:27 --> Config Class Initialized
INFO - 2018-03-26 11:04:27 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:04:27 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:04:27 --> Utf8 Class Initialized
INFO - 2018-03-26 11:04:28 --> URI Class Initialized
INFO - 2018-03-26 11:04:28 --> Language Class Initialized
INFO - 2018-03-26 11:04:28 --> Config Class Initialized
INFO - 2018-03-26 11:04:28 --> Loader Class Initialized
INFO - 2018-03-26 16:34:28 --> Helper loaded: url_helper
INFO - 2018-03-26 11:04:28 --> Router Class Initialized
INFO - 2018-03-26 16:34:28 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:34:28 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:34:28 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:34:28 --> Helper loaded: users_helper
INFO - 2018-03-26 11:04:28 --> Output Class Initialized
INFO - 2018-03-26 11:04:28 --> Security Class Initialized
INFO - 2018-03-26 11:04:28 --> Config Class Initialized
INFO - 2018-03-26 11:04:28 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:04:28 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:04:28 --> Utf8 Class Initialized
INFO - 2018-03-26 11:04:28 --> URI Class Initialized
INFO - 2018-03-26 11:04:28 --> Router Class Initialized
INFO - 2018-03-26 11:04:28 --> Output Class Initialized
INFO - 2018-03-26 11:04:28 --> Security Class Initialized
DEBUG - 2018-03-26 11:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:04:28 --> Input Class Initialized
INFO - 2018-03-26 11:04:28 --> Language Class Initialized
DEBUG - 2018-03-26 11:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:04:28 --> Input Class Initialized
INFO - 2018-03-26 11:04:28 --> Language Class Initialized
INFO - 2018-03-26 11:04:28 --> Language Class Initialized
INFO - 2018-03-26 11:04:28 --> Config Class Initialized
INFO - 2018-03-26 11:04:28 --> Loader Class Initialized
INFO - 2018-03-26 16:34:28 --> Helper loaded: url_helper
INFO - 2018-03-26 16:34:28 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:34:28 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:34:28 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:34:28 --> Helper loaded: users_helper
INFO - 2018-03-26 16:34:28 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:34:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:34:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:34:28 --> Helper loaded: form_helper
INFO - 2018-03-26 16:34:28 --> Form Validation Class Initialized
INFO - 2018-03-26 16:34:28 --> Controller Class Initialized
INFO - 2018-03-26 16:34:28 --> Model Class Initialized
INFO - 2018-03-26 16:34:28 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:34:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:34:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:34:28 --> Model Class Initialized
INFO - 2018-03-26 16:34:28 --> Model Class Initialized
INFO - 2018-03-26 16:34:28 --> Model Class Initialized
INFO - 2018-03-26 16:34:28 --> Model Class Initialized
INFO - 2018-03-26 16:34:28 --> Model Class Initialized
INFO - 2018-03-26 16:34:28 --> Model Class Initialized
INFO - 2018-03-26 16:34:28 --> Model Class Initialized
INFO - 2018-03-26 16:34:28 --> Model Class Initialized
INFO - 2018-03-26 16:34:28 --> Model Class Initialized
INFO - 2018-03-26 16:34:28 --> Model Class Initialized
INFO - 2018-03-26 16:34:28 --> Model Class Initialized
INFO - 2018-03-26 16:34:28 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:34:28 --> Model Class Initialized
INFO - 2018-03-26 16:34:28 --> Database Driver Class Initialized
INFO - 2018-03-26 16:34:28 --> Final output sent to browser
DEBUG - 2018-03-26 16:34:28 --> Total execution time: 0.1614
INFO - 2018-03-26 11:04:29 --> Config Class Initialized
INFO - 2018-03-26 11:04:29 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:04:29 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:04:29 --> Utf8 Class Initialized
INFO - 2018-03-26 11:04:29 --> URI Class Initialized
INFO - 2018-03-26 11:04:29 --> Router Class Initialized
INFO - 2018-03-26 11:04:29 --> Output Class Initialized
INFO - 2018-03-26 11:04:29 --> Security Class Initialized
DEBUG - 2018-03-26 11:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:04:29 --> Input Class Initialized
DEBUG - 2018-03-26 16:34:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:04:29 --> Language Class Initialized
INFO - 2018-03-26 16:34:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:04:29 --> Language Class Initialized
INFO - 2018-03-26 11:04:29 --> Config Class Initialized
INFO - 2018-03-26 11:04:29 --> Loader Class Initialized
INFO - 2018-03-26 16:34:29 --> Helper loaded: url_helper
INFO - 2018-03-26 16:34:29 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:34:29 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:34:29 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:34:29 --> Helper loaded: users_helper
INFO - 2018-03-26 16:34:29 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:34:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:34:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:34:29 --> Helper loaded: form_helper
INFO - 2018-03-26 16:34:29 --> Form Validation Class Initialized
INFO - 2018-03-26 16:34:29 --> Controller Class Initialized
INFO - 2018-03-26 16:34:29 --> Model Class Initialized
INFO - 2018-03-26 16:34:29 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:34:29 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:34:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:34:29 --> Model Class Initialized
INFO - 2018-03-26 16:34:29 --> Model Class Initialized
INFO - 2018-03-26 16:34:29 --> Model Class Initialized
INFO - 2018-03-26 16:34:29 --> Model Class Initialized
INFO - 2018-03-26 16:34:29 --> Model Class Initialized
INFO - 2018-03-26 16:34:29 --> Model Class Initialized
INFO - 2018-03-26 16:34:29 --> Model Class Initialized
INFO - 2018-03-26 16:34:29 --> Model Class Initialized
INFO - 2018-03-26 16:34:29 --> Model Class Initialized
INFO - 2018-03-26 16:34:29 --> Model Class Initialized
INFO - 2018-03-26 16:34:29 --> Model Class Initialized
INFO - 2018-03-26 16:34:29 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:34:29 --> Model Class Initialized
INFO - 2018-03-26 16:34:29 --> Final output sent to browser
DEBUG - 2018-03-26 16:34:29 --> Total execution time: 0.1350
INFO - 2018-03-26 16:34:29 --> Helper loaded: form_helper
INFO - 2018-03-26 16:34:29 --> Form Validation Class Initialized
INFO - 2018-03-26 16:34:29 --> Controller Class Initialized
INFO - 2018-03-26 11:04:29 --> Language Class Initialized
INFO - 2018-03-26 11:04:29 --> Config Class Initialized
INFO - 2018-03-26 11:04:29 --> Loader Class Initialized
INFO - 2018-03-26 16:34:29 --> Model Class Initialized
INFO - 2018-03-26 16:34:29 --> Helper loaded: inflector_helper
INFO - 2018-03-26 16:34:29 --> Helper loaded: url_helper
INFO - 2018-03-26 16:34:29 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:34:29 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:34:29 --> Helper loaded: permission_helper
DEBUG - 2018-03-26 16:34:29 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:34:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:34:29 --> Helper loaded: users_helper
INFO - 2018-03-26 16:34:29 --> Model Class Initialized
INFO - 2018-03-26 16:34:29 --> Model Class Initialized
INFO - 2018-03-26 16:34:29 --> Model Class Initialized
INFO - 2018-03-26 16:34:29 --> Model Class Initialized
INFO - 2018-03-26 16:34:29 --> Model Class Initialized
INFO - 2018-03-26 16:34:29 --> Model Class Initialized
INFO - 2018-03-26 16:34:29 --> Model Class Initialized
INFO - 2018-03-26 16:34:29 --> Model Class Initialized
INFO - 2018-03-26 16:34:29 --> Model Class Initialized
INFO - 2018-03-26 16:34:29 --> Model Class Initialized
INFO - 2018-03-26 16:34:30 --> Model Class Initialized
INFO - 2018-03-26 16:34:30 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:34:30 --> Model Class Initialized
INFO - 2018-03-26 16:34:30 --> Final output sent to browser
DEBUG - 2018-03-26 16:34:30 --> Total execution time: 3.8195
INFO - 2018-03-26 16:34:30 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:34:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:34:30 --> Helper loaded: form_helper
INFO - 2018-03-26 16:34:30 --> Form Validation Class Initialized
INFO - 2018-03-26 16:34:30 --> Controller Class Initialized
INFO - 2018-03-26 11:04:30 --> Config Class Initialized
INFO - 2018-03-26 11:04:30 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:04:30 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:04:30 --> Utf8 Class Initialized
INFO - 2018-03-26 11:04:31 --> URI Class Initialized
INFO - 2018-03-26 11:04:31 --> Router Class Initialized
INFO - 2018-03-26 11:04:31 --> Output Class Initialized
INFO - 2018-03-26 11:04:31 --> Security Class Initialized
DEBUG - 2018-03-26 11:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:04:31 --> Input Class Initialized
INFO - 2018-03-26 11:04:31 --> Language Class Initialized
INFO - 2018-03-26 16:34:31 --> Model Class Initialized
INFO - 2018-03-26 16:34:31 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:34:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 11:04:31 --> Language Class Initialized
INFO - 2018-03-26 11:04:31 --> Config Class Initialized
INFO - 2018-03-26 11:04:31 --> Loader Class Initialized
INFO - 2018-03-26 16:34:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:34:31 --> Model Class Initialized
INFO - 2018-03-26 16:34:31 --> Model Class Initialized
INFO - 2018-03-26 16:34:31 --> Model Class Initialized
INFO - 2018-03-26 16:34:31 --> Model Class Initialized
INFO - 2018-03-26 16:34:31 --> Model Class Initialized
INFO - 2018-03-26 16:34:31 --> Model Class Initialized
INFO - 2018-03-26 16:34:31 --> Model Class Initialized
INFO - 2018-03-26 16:34:31 --> Helper loaded: url_helper
INFO - 2018-03-26 16:34:31 --> Model Class Initialized
INFO - 2018-03-26 16:34:31 --> Model Class Initialized
INFO - 2018-03-26 16:34:31 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:34:31 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:34:31 --> Model Class Initialized
INFO - 2018-03-26 16:34:31 --> Model Class Initialized
INFO - 2018-03-26 16:34:31 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:34:31 --> Model Class Initialized
INFO - 2018-03-26 16:34:31 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:34:31 --> Helper loaded: users_helper
INFO - 2018-03-26 16:34:31 --> Final output sent to browser
DEBUG - 2018-03-26 16:34:31 --> Total execution time: 3.9610
INFO - 2018-03-26 16:34:31 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:34:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:34:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:34:31 --> Helper loaded: form_helper
INFO - 2018-03-26 16:34:31 --> Form Validation Class Initialized
INFO - 2018-03-26 16:34:31 --> Controller Class Initialized
INFO - 2018-03-26 16:34:31 --> Model Class Initialized
INFO - 2018-03-26 16:34:31 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:34:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:34:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:34:31 --> Model Class Initialized
INFO - 2018-03-26 16:34:31 --> Model Class Initialized
INFO - 2018-03-26 16:34:31 --> Model Class Initialized
INFO - 2018-03-26 16:34:31 --> Model Class Initialized
INFO - 2018-03-26 16:34:31 --> Model Class Initialized
INFO - 2018-03-26 16:34:31 --> Model Class Initialized
INFO - 2018-03-26 16:34:31 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:34:31 --> Final output sent to browser
DEBUG - 2018-03-26 16:34:31 --> Total execution time: 0.9854
INFO - 2018-03-26 11:06:28 --> Config Class Initialized
INFO - 2018-03-26 11:06:28 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:06:28 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:06:28 --> Utf8 Class Initialized
INFO - 2018-03-26 11:06:28 --> URI Class Initialized
INFO - 2018-03-26 11:06:28 --> Router Class Initialized
INFO - 2018-03-26 11:06:28 --> Output Class Initialized
INFO - 2018-03-26 11:06:28 --> Security Class Initialized
DEBUG - 2018-03-26 11:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:06:28 --> Input Class Initialized
INFO - 2018-03-26 11:06:28 --> Language Class Initialized
INFO - 2018-03-26 11:06:28 --> Language Class Initialized
INFO - 2018-03-26 11:06:28 --> Config Class Initialized
INFO - 2018-03-26 11:06:28 --> Loader Class Initialized
INFO - 2018-03-26 16:36:28 --> Helper loaded: url_helper
INFO - 2018-03-26 16:36:28 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:36:28 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:36:28 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:36:28 --> Helper loaded: users_helper
INFO - 2018-03-26 16:36:28 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:36:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:36:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:36:28 --> Helper loaded: form_helper
INFO - 2018-03-26 16:36:28 --> Form Validation Class Initialized
INFO - 2018-03-26 16:36:28 --> Controller Class Initialized
INFO - 2018-03-26 16:36:28 --> Model Class Initialized
INFO - 2018-03-26 16:36:28 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:36:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:36:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:36:28 --> Model Class Initialized
INFO - 2018-03-26 16:36:28 --> Model Class Initialized
INFO - 2018-03-26 16:36:28 --> Model Class Initialized
INFO - 2018-03-26 16:36:28 --> Model Class Initialized
INFO - 2018-03-26 16:36:28 --> Model Class Initialized
INFO - 2018-03-26 16:36:28 --> Model Class Initialized
INFO - 2018-03-26 16:36:28 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:36:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-26 16:36:28 --> Final output sent to browser
DEBUG - 2018-03-26 16:36:28 --> Total execution time: 0.1763
INFO - 2018-03-26 11:06:30 --> Config Class Initialized
INFO - 2018-03-26 11:06:30 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:06:30 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:06:30 --> Utf8 Class Initialized
INFO - 2018-03-26 11:06:30 --> URI Class Initialized
INFO - 2018-03-26 11:06:30 --> Router Class Initialized
INFO - 2018-03-26 11:06:30 --> Output Class Initialized
INFO - 2018-03-26 11:06:30 --> Security Class Initialized
DEBUG - 2018-03-26 11:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:06:30 --> Input Class Initialized
INFO - 2018-03-26 11:06:30 --> Language Class Initialized
INFO - 2018-03-26 11:06:30 --> Language Class Initialized
INFO - 2018-03-26 11:06:30 --> Config Class Initialized
INFO - 2018-03-26 11:06:30 --> Loader Class Initialized
INFO - 2018-03-26 16:36:30 --> Helper loaded: url_helper
INFO - 2018-03-26 16:36:30 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:36:30 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:36:30 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:36:30 --> Helper loaded: users_helper
INFO - 2018-03-26 16:36:30 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:36:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:36:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:36:30 --> Helper loaded: form_helper
INFO - 2018-03-26 16:36:30 --> Form Validation Class Initialized
INFO - 2018-03-26 16:36:30 --> Controller Class Initialized
INFO - 2018-03-26 16:36:30 --> Model Class Initialized
INFO - 2018-03-26 16:36:30 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:36:30 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:36:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:36:30 --> Model Class Initialized
INFO - 2018-03-26 16:36:30 --> Model Class Initialized
INFO - 2018-03-26 16:36:30 --> Model Class Initialized
INFO - 2018-03-26 16:36:30 --> Model Class Initialized
INFO - 2018-03-26 16:36:30 --> Model Class Initialized
INFO - 2018-03-26 16:36:30 --> Model Class Initialized
INFO - 2018-03-26 16:36:30 --> Model Class Initialized
INFO - 2018-03-26 16:36:30 --> Model Class Initialized
INFO - 2018-03-26 16:36:30 --> Model Class Initialized
INFO - 2018-03-26 16:36:30 --> Model Class Initialized
INFO - 2018-03-26 16:36:30 --> Model Class Initialized
INFO - 2018-03-26 16:36:30 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:36:30 --> Model Class Initialized
INFO - 2018-03-26 16:36:30 --> Final output sent to browser
DEBUG - 2018-03-26 16:36:30 --> Total execution time: 0.2716
INFO - 2018-03-26 11:06:30 --> Config Class Initialized
INFO - 2018-03-26 11:06:30 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:06:31 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:06:31 --> Utf8 Class Initialized
INFO - 2018-03-26 11:06:31 --> URI Class Initialized
INFO - 2018-03-26 11:06:31 --> Router Class Initialized
INFO - 2018-03-26 11:06:31 --> Output Class Initialized
INFO - 2018-03-26 11:06:31 --> Security Class Initialized
DEBUG - 2018-03-26 11:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:06:31 --> Input Class Initialized
INFO - 2018-03-26 11:06:31 --> Language Class Initialized
INFO - 2018-03-26 11:06:32 --> Language Class Initialized
INFO - 2018-03-26 11:06:32 --> Config Class Initialized
INFO - 2018-03-26 11:06:32 --> Loader Class Initialized
INFO - 2018-03-26 16:36:32 --> Helper loaded: url_helper
INFO - 2018-03-26 16:36:32 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:36:32 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:36:32 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:36:32 --> Helper loaded: users_helper
INFO - 2018-03-26 16:36:32 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:36:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:36:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:36:33 --> Helper loaded: form_helper
INFO - 2018-03-26 16:36:33 --> Form Validation Class Initialized
INFO - 2018-03-26 16:36:33 --> Controller Class Initialized
INFO - 2018-03-26 16:36:33 --> Model Class Initialized
INFO - 2018-03-26 16:36:33 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:36:33 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:36:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:36:33 --> Model Class Initialized
INFO - 2018-03-26 16:36:33 --> Model Class Initialized
INFO - 2018-03-26 16:36:33 --> Model Class Initialized
INFO - 2018-03-26 16:36:33 --> Model Class Initialized
INFO - 2018-03-26 16:36:33 --> Model Class Initialized
INFO - 2018-03-26 16:36:33 --> Model Class Initialized
INFO - 2018-03-26 16:36:33 --> Model Class Initialized
INFO - 2018-03-26 16:36:33 --> Model Class Initialized
INFO - 2018-03-26 11:06:33 --> Config Class Initialized
INFO - 2018-03-26 11:06:33 --> Hooks Class Initialized
INFO - 2018-03-26 16:36:33 --> Model Class Initialized
INFO - 2018-03-26 16:36:33 --> Model Class Initialized
INFO - 2018-03-26 16:36:33 --> Model Class Initialized
INFO - 2018-03-26 16:36:33 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:36:33 --> Model Class Initialized
DEBUG - 2018-03-26 11:06:33 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:06:33 --> Utf8 Class Initialized
INFO - 2018-03-26 16:36:33 --> Final output sent to browser
DEBUG - 2018-03-26 16:36:33 --> Total execution time: 2.8197
INFO - 2018-03-26 11:06:33 --> URI Class Initialized
INFO - 2018-03-26 11:06:33 --> Router Class Initialized
INFO - 2018-03-26 11:06:33 --> Output Class Initialized
INFO - 2018-03-26 11:06:34 --> Security Class Initialized
DEBUG - 2018-03-26 11:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:06:34 --> Input Class Initialized
INFO - 2018-03-26 11:06:34 --> Language Class Initialized
INFO - 2018-03-26 11:06:35 --> Language Class Initialized
INFO - 2018-03-26 11:06:35 --> Config Class Initialized
INFO - 2018-03-26 11:06:35 --> Loader Class Initialized
INFO - 2018-03-26 16:36:35 --> Helper loaded: url_helper
INFO - 2018-03-26 16:36:35 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:36:35 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:36:35 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:36:35 --> Helper loaded: users_helper
INFO - 2018-03-26 16:36:36 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:36:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:36:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:36:36 --> Helper loaded: form_helper
INFO - 2018-03-26 16:36:36 --> Form Validation Class Initialized
INFO - 2018-03-26 16:36:36 --> Controller Class Initialized
INFO - 2018-03-26 16:36:36 --> Model Class Initialized
INFO - 2018-03-26 16:36:36 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:36:36 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:36:36 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:36:36 --> Model Class Initialized
INFO - 2018-03-26 16:36:36 --> Model Class Initialized
INFO - 2018-03-26 16:36:36 --> Model Class Initialized
INFO - 2018-03-26 16:36:36 --> Model Class Initialized
INFO - 2018-03-26 16:36:36 --> Model Class Initialized
INFO - 2018-03-26 16:36:36 --> Model Class Initialized
INFO - 2018-03-26 16:36:36 --> Model Class Initialized
INFO - 2018-03-26 16:36:36 --> Model Class Initialized
INFO - 2018-03-26 16:36:36 --> Model Class Initialized
INFO - 2018-03-26 16:36:36 --> Model Class Initialized
INFO - 2018-03-26 16:36:36 --> Model Class Initialized
INFO - 2018-03-26 16:36:36 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:36:36 --> Model Class Initialized
INFO - 2018-03-26 16:36:36 --> Final output sent to browser
DEBUG - 2018-03-26 16:36:36 --> Total execution time: 3.1043
INFO - 2018-03-26 11:06:40 --> Config Class Initialized
INFO - 2018-03-26 11:06:40 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:06:40 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:06:40 --> Utf8 Class Initialized
INFO - 2018-03-26 11:06:40 --> URI Class Initialized
INFO - 2018-03-26 11:06:40 --> Router Class Initialized
INFO - 2018-03-26 11:06:40 --> Output Class Initialized
INFO - 2018-03-26 11:06:40 --> Security Class Initialized
DEBUG - 2018-03-26 11:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:06:40 --> Input Class Initialized
INFO - 2018-03-26 11:06:40 --> Language Class Initialized
INFO - 2018-03-26 11:06:40 --> Language Class Initialized
INFO - 2018-03-26 11:06:40 --> Config Class Initialized
INFO - 2018-03-26 11:06:40 --> Loader Class Initialized
INFO - 2018-03-26 16:36:40 --> Helper loaded: url_helper
INFO - 2018-03-26 16:36:40 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:36:40 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:36:40 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:36:40 --> Helper loaded: users_helper
INFO - 2018-03-26 16:36:40 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:36:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:36:40 --> Helper loaded: form_helper
INFO - 2018-03-26 16:36:40 --> Form Validation Class Initialized
INFO - 2018-03-26 16:36:40 --> Controller Class Initialized
INFO - 2018-03-26 16:36:40 --> Model Class Initialized
INFO - 2018-03-26 16:36:40 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:36:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:36:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:36:40 --> Model Class Initialized
INFO - 2018-03-26 16:36:40 --> Model Class Initialized
INFO - 2018-03-26 16:36:40 --> Model Class Initialized
INFO - 2018-03-26 16:36:40 --> Model Class Initialized
INFO - 2018-03-26 16:36:40 --> Model Class Initialized
INFO - 2018-03-26 16:36:40 --> Model Class Initialized
INFO - 2018-03-26 16:36:40 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-26 16:36:40 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-26 16:36:40 --> Final output sent to browser
DEBUG - 2018-03-26 16:36:40 --> Total execution time: 0.0995
INFO - 2018-03-26 11:06:43 --> Config Class Initialized
INFO - 2018-03-26 11:06:43 --> Hooks Class Initialized
INFO - 2018-03-26 11:06:43 --> Config Class Initialized
INFO - 2018-03-26 11:06:43 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:06:43 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:06:43 --> Utf8 Class Initialized
INFO - 2018-03-26 11:06:43 --> Config Class Initialized
INFO - 2018-03-26 11:06:43 --> Hooks Class Initialized
INFO - 2018-03-26 11:06:43 --> URI Class Initialized
DEBUG - 2018-03-26 11:06:43 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:06:43 --> Utf8 Class Initialized
DEBUG - 2018-03-26 11:06:43 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:06:43 --> Utf8 Class Initialized
INFO - 2018-03-26 11:06:44 --> URI Class Initialized
INFO - 2018-03-26 11:06:44 --> Router Class Initialized
INFO - 2018-03-26 11:06:44 --> URI Class Initialized
INFO - 2018-03-26 11:06:44 --> Router Class Initialized
INFO - 2018-03-26 11:06:44 --> Output Class Initialized
INFO - 2018-03-26 11:06:44 --> Router Class Initialized
INFO - 2018-03-26 11:06:44 --> Output Class Initialized
INFO - 2018-03-26 11:06:44 --> Security Class Initialized
INFO - 2018-03-26 11:06:44 --> Output Class Initialized
INFO - 2018-03-26 11:06:44 --> Security Class Initialized
DEBUG - 2018-03-26 11:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:06:44 --> Input Class Initialized
INFO - 2018-03-26 11:06:44 --> Security Class Initialized
INFO - 2018-03-26 11:06:44 --> Language Class Initialized
DEBUG - 2018-03-26 11:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:06:44 --> Input Class Initialized
INFO - 2018-03-26 11:06:44 --> Language Class Initialized
DEBUG - 2018-03-26 11:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:06:44 --> Input Class Initialized
INFO - 2018-03-26 11:06:44 --> Language Class Initialized
INFO - 2018-03-26 11:06:44 --> Language Class Initialized
INFO - 2018-03-26 11:06:44 --> Config Class Initialized
INFO - 2018-03-26 11:06:44 --> Loader Class Initialized
INFO - 2018-03-26 16:36:44 --> Helper loaded: url_helper
INFO - 2018-03-26 16:36:44 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:36:44 --> Helper loaded: settings_helper
INFO - 2018-03-26 11:06:44 --> Config Class Initialized
INFO - 2018-03-26 11:06:44 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:06:44 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:06:44 --> Utf8 Class Initialized
INFO - 2018-03-26 11:06:44 --> URI Class Initialized
INFO - 2018-03-26 11:06:44 --> Router Class Initialized
INFO - 2018-03-26 11:06:44 --> Output Class Initialized
INFO - 2018-03-26 11:06:44 --> Security Class Initialized
INFO - 2018-03-26 11:06:44 --> Language Class Initialized
DEBUG - 2018-03-26 11:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:06:44 --> Input Class Initialized
INFO - 2018-03-26 11:06:44 --> Language Class Initialized
INFO - 2018-03-26 11:06:44 --> Config Class Initialized
INFO - 2018-03-26 16:36:44 --> Helper loaded: permission_helper
INFO - 2018-03-26 11:06:44 --> Config Class Initialized
INFO - 2018-03-26 11:06:44 --> Loader Class Initialized
INFO - 2018-03-26 11:06:44 --> Hooks Class Initialized
INFO - 2018-03-26 11:06:44 --> Language Class Initialized
INFO - 2018-03-26 11:06:44 --> Config Class Initialized
INFO - 2018-03-26 11:06:44 --> Loader Class Initialized
DEBUG - 2018-03-26 11:06:44 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:06:44 --> Utf8 Class Initialized
INFO - 2018-03-26 16:36:44 --> Helper loaded: url_helper
INFO - 2018-03-26 16:36:44 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:36:44 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:36:44 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:36:44 --> Helper loaded: users_helper
INFO - 2018-03-26 11:06:44 --> URI Class Initialized
INFO - 2018-03-26 16:36:44 --> Database Driver Class Initialized
INFO - 2018-03-26 11:06:44 --> Router Class Initialized
DEBUG - 2018-03-26 16:36:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:36:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:06:44 --> Output Class Initialized
INFO - 2018-03-26 16:36:44 --> Helper loaded: form_helper
INFO - 2018-03-26 16:36:44 --> Form Validation Class Initialized
INFO - 2018-03-26 16:36:44 --> Controller Class Initialized
INFO - 2018-03-26 16:36:44 --> Helper loaded: url_helper
INFO - 2018-03-26 16:36:44 --> Helper loaded: notification_helper
INFO - 2018-03-26 11:06:44 --> Security Class Initialized
DEBUG - 2018-03-26 11:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:06:44 --> Input Class Initialized
INFO - 2018-03-26 11:06:44 --> Config Class Initialized
INFO - 2018-03-26 11:06:44 --> Hooks Class Initialized
INFO - 2018-03-26 16:36:44 --> Model Class Initialized
INFO - 2018-03-26 16:36:44 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:36:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-03-26 11:06:45 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:06:45 --> Utf8 Class Initialized
INFO - 2018-03-26 16:36:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 11:06:45 --> Language Class Initialized
INFO - 2018-03-26 16:36:45 --> Model Class Initialized
INFO - 2018-03-26 16:36:45 --> Model Class Initialized
INFO - 2018-03-26 16:36:45 --> Helper loaded: users_helper
INFO - 2018-03-26 16:36:45 --> Model Class Initialized
INFO - 2018-03-26 11:06:45 --> URI Class Initialized
INFO - 2018-03-26 11:06:45 --> Router Class Initialized
INFO - 2018-03-26 11:06:45 --> Output Class Initialized
INFO - 2018-03-26 11:06:45 --> Security Class Initialized
INFO - 2018-03-26 16:36:45 --> Model Class Initialized
INFO - 2018-03-26 16:36:45 --> Model Class Initialized
DEBUG - 2018-03-26 11:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:06:45 --> Input Class Initialized
INFO - 2018-03-26 11:06:45 --> Language Class Initialized
INFO - 2018-03-26 11:06:45 --> Language Class Initialized
INFO - 2018-03-26 11:06:45 --> Config Class Initialized
INFO - 2018-03-26 11:06:45 --> Loader Class Initialized
INFO - 2018-03-26 16:36:45 --> Helper loaded: url_helper
INFO - 2018-03-26 16:36:45 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:36:45 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:36:45 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:36:45 --> Helper loaded: users_helper
INFO - 2018-03-26 16:36:45 --> Model Class Initialized
INFO - 2018-03-26 16:36:45 --> Model Class Initialized
INFO - 2018-03-26 11:06:45 --> Language Class Initialized
INFO - 2018-03-26 11:06:45 --> Config Class Initialized
INFO - 2018-03-26 11:06:45 --> Loader Class Initialized
INFO - 2018-03-26 16:36:45 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:36:45 --> Helper loaded: url_helper
INFO - 2018-03-26 16:36:45 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:36:45 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:36:45 --> Database Driver Class Initialized
INFO - 2018-03-26 16:36:45 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:36:45 --> Helper loaded: users_helper
DEBUG - 2018-03-26 16:36:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:36:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:36:45 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:36:45 --> Model Class Initialized
INFO - 2018-03-26 16:36:45 --> Model Class Initialized
INFO - 2018-03-26 16:36:45 --> Model Class Initialized
INFO - 2018-03-26 16:36:45 --> Helper loaded: users_helper
INFO - 2018-03-26 16:36:45 --> Helper loaded: form_helper
INFO - 2018-03-26 16:36:45 --> Form Validation Class Initialized
INFO - 2018-03-26 16:36:45 --> Controller Class Initialized
INFO - 2018-03-26 16:36:45 --> Database Driver Class Initialized
INFO - 2018-03-26 11:06:45 --> Language Class Initialized
INFO - 2018-03-26 11:06:45 --> Config Class Initialized
INFO - 2018-03-26 11:06:45 --> Loader Class Initialized
DEBUG - 2018-03-26 16:36:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:36:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:36:45 --> Helper loaded: form_helper
INFO - 2018-03-26 16:36:45 --> Form Validation Class Initialized
INFO - 2018-03-26 16:36:45 --> Controller Class Initialized
INFO - 2018-03-26 16:36:45 --> Model Class Initialized
INFO - 2018-03-26 16:36:45 --> Helper loaded: inflector_helper
INFO - 2018-03-26 16:36:45 --> Model Class Initialized
INFO - 2018-03-26 16:36:45 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:36:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:36:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:36:45 --> Model Class Initialized
INFO - 2018-03-26 16:36:45 --> Model Class Initialized
INFO - 2018-03-26 16:36:45 --> Model Class Initialized
INFO - 2018-03-26 16:36:45 --> Model Class Initialized
INFO - 2018-03-26 16:36:45 --> Model Class Initialized
INFO - 2018-03-26 16:36:45 --> Model Class Initialized
INFO - 2018-03-26 16:36:45 --> Model Class Initialized
INFO - 2018-03-26 16:36:45 --> Model Class Initialized
INFO - 2018-03-26 16:36:45 --> Model Class Initialized
INFO - 2018-03-26 16:36:45 --> Model Class Initialized
INFO - 2018-03-26 16:36:45 --> Model Class Initialized
INFO - 2018-03-26 16:36:45 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:36:45 --> Model Class Initialized
DEBUG - 2018-03-26 16:36:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:36:45 --> Final output sent to browser
DEBUG - 2018-03-26 16:36:45 --> Total execution time: 0.3352
INFO - 2018-03-26 16:36:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:36:45 --> Model Class Initialized
INFO - 2018-03-26 16:36:45 --> Model Class Initialized
INFO - 2018-03-26 16:36:45 --> Model Class Initialized
INFO - 2018-03-26 16:36:45 --> Model Class Initialized
INFO - 2018-03-26 16:36:45 --> Model Class Initialized
INFO - 2018-03-26 16:36:45 --> Model Class Initialized
INFO - 2018-03-26 16:36:45 --> Model Class Initialized
INFO - 2018-03-26 16:36:45 --> Model Class Initialized
INFO - 2018-03-26 16:36:45 --> Model Class Initialized
INFO - 2018-03-26 16:36:45 --> Model Class Initialized
INFO - 2018-03-26 16:36:45 --> Model Class Initialized
INFO - 2018-03-26 16:36:45 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:36:45 --> Model Class Initialized
INFO - 2018-03-26 16:36:45 --> Final output sent to browser
DEBUG - 2018-03-26 16:36:45 --> Total execution time: 0.4599
INFO - 2018-03-26 16:36:45 --> Helper loaded: url_helper
INFO - 2018-03-26 16:36:45 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:36:45 --> Model Class Initialized
INFO - 2018-03-26 16:36:45 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:36:45 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:36:45 --> Model Class Initialized
INFO - 2018-03-26 16:36:45 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:36:45 --> Helper loaded: users_helper
INFO - 2018-03-26 16:36:45 --> Final output sent to browser
DEBUG - 2018-03-26 16:36:45 --> Total execution time: 0.9356
INFO - 2018-03-26 16:36:46 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:36:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:36:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:36:46 --> Helper loaded: form_helper
INFO - 2018-03-26 16:36:46 --> Form Validation Class Initialized
INFO - 2018-03-26 16:36:46 --> Controller Class Initialized
INFO - 2018-03-26 16:36:46 --> Model Class Initialized
INFO - 2018-03-26 16:36:46 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:36:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:36:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:36:46 --> Model Class Initialized
INFO - 2018-03-26 16:36:46 --> Model Class Initialized
INFO - 2018-03-26 16:36:46 --> Model Class Initialized
INFO - 2018-03-26 16:36:46 --> Model Class Initialized
INFO - 2018-03-26 16:36:46 --> Model Class Initialized
INFO - 2018-03-26 16:36:46 --> Model Class Initialized
INFO - 2018-03-26 16:36:46 --> Model Class Initialized
INFO - 2018-03-26 16:36:46 --> Model Class Initialized
INFO - 2018-03-26 16:36:46 --> Model Class Initialized
INFO - 2018-03-26 16:36:46 --> Model Class Initialized
INFO - 2018-03-26 16:36:46 --> Model Class Initialized
INFO - 2018-03-26 16:36:46 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:36:46 --> Model Class Initialized
INFO - 2018-03-26 16:36:46 --> Final output sent to browser
DEBUG - 2018-03-26 16:36:46 --> Total execution time: 2.7624
INFO - 2018-03-26 16:36:46 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:36:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:36:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:36:46 --> Helper loaded: form_helper
INFO - 2018-03-26 16:36:46 --> Form Validation Class Initialized
INFO - 2018-03-26 16:36:46 --> Controller Class Initialized
INFO - 2018-03-26 16:36:46 --> Model Class Initialized
INFO - 2018-03-26 16:36:46 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:36:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:36:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:36:46 --> Model Class Initialized
INFO - 2018-03-26 16:36:46 --> Model Class Initialized
INFO - 2018-03-26 16:36:46 --> Model Class Initialized
INFO - 2018-03-26 16:36:46 --> Model Class Initialized
INFO - 2018-03-26 16:36:46 --> Model Class Initialized
INFO - 2018-03-26 16:36:46 --> Model Class Initialized
INFO - 2018-03-26 16:36:46 --> Model Class Initialized
INFO - 2018-03-26 16:36:46 --> Model Class Initialized
INFO - 2018-03-26 16:36:46 --> Model Class Initialized
INFO - 2018-03-26 16:36:46 --> Model Class Initialized
INFO - 2018-03-26 16:36:46 --> Model Class Initialized
INFO - 2018-03-26 16:36:46 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:36:46 --> Model Class Initialized
INFO - 2018-03-26 16:36:46 --> Final output sent to browser
DEBUG - 2018-03-26 16:36:46 --> Total execution time: 3.0987
INFO - 2018-03-26 16:36:46 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:36:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:36:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:36:46 --> Helper loaded: form_helper
INFO - 2018-03-26 16:36:46 --> Form Validation Class Initialized
INFO - 2018-03-26 16:36:46 --> Controller Class Initialized
INFO - 2018-03-26 16:36:46 --> Model Class Initialized
INFO - 2018-03-26 16:36:46 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:36:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:36:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:36:47 --> Model Class Initialized
INFO - 2018-03-26 16:36:47 --> Model Class Initialized
INFO - 2018-03-26 16:36:47 --> Model Class Initialized
INFO - 2018-03-26 16:36:47 --> Model Class Initialized
INFO - 2018-03-26 16:36:47 --> Model Class Initialized
INFO - 2018-03-26 16:36:47 --> Model Class Initialized
INFO - 2018-03-26 16:36:47 --> Model Class Initialized
INFO - 2018-03-26 16:36:47 --> Model Class Initialized
INFO - 2018-03-26 16:36:47 --> Model Class Initialized
INFO - 2018-03-26 16:36:47 --> Model Class Initialized
INFO - 2018-03-26 16:36:47 --> Model Class Initialized
INFO - 2018-03-26 16:36:47 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:36:47 --> Model Class Initialized
INFO - 2018-03-26 16:36:47 --> Final output sent to browser
DEBUG - 2018-03-26 16:36:47 --> Total execution time: 4.2995
INFO - 2018-03-26 11:09:44 --> Config Class Initialized
INFO - 2018-03-26 11:09:44 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:09:44 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:09:44 --> Utf8 Class Initialized
INFO - 2018-03-26 11:09:44 --> URI Class Initialized
INFO - 2018-03-26 11:09:45 --> Router Class Initialized
INFO - 2018-03-26 11:09:45 --> Output Class Initialized
INFO - 2018-03-26 11:09:45 --> Security Class Initialized
DEBUG - 2018-03-26 11:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:09:45 --> Input Class Initialized
INFO - 2018-03-26 11:09:45 --> Language Class Initialized
INFO - 2018-03-26 11:09:45 --> Language Class Initialized
INFO - 2018-03-26 11:09:45 --> Config Class Initialized
INFO - 2018-03-26 11:09:45 --> Loader Class Initialized
INFO - 2018-03-26 16:39:45 --> Helper loaded: url_helper
INFO - 2018-03-26 16:39:45 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:39:45 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:39:45 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:39:45 --> Helper loaded: users_helper
INFO - 2018-03-26 16:39:45 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:39:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:39:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:39:45 --> Helper loaded: form_helper
INFO - 2018-03-26 16:39:45 --> Form Validation Class Initialized
INFO - 2018-03-26 16:39:45 --> Controller Class Initialized
INFO - 2018-03-26 16:39:45 --> Model Class Initialized
INFO - 2018-03-26 16:39:45 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:39:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:39:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:39:45 --> Model Class Initialized
INFO - 2018-03-26 16:39:45 --> Model Class Initialized
INFO - 2018-03-26 16:39:46 --> Model Class Initialized
INFO - 2018-03-26 16:39:46 --> Model Class Initialized
INFO - 2018-03-26 16:39:46 --> Model Class Initialized
INFO - 2018-03-26 16:39:46 --> Model Class Initialized
INFO - 2018-03-26 16:39:46 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:39:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-26 16:39:46 --> Final output sent to browser
DEBUG - 2018-03-26 16:39:46 --> Total execution time: 1.5501
INFO - 2018-03-26 11:09:47 --> Config Class Initialized
INFO - 2018-03-26 11:09:47 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:09:47 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:09:47 --> Utf8 Class Initialized
INFO - 2018-03-26 11:09:47 --> URI Class Initialized
INFO - 2018-03-26 11:09:47 --> Router Class Initialized
INFO - 2018-03-26 11:09:47 --> Output Class Initialized
INFO - 2018-03-26 11:09:47 --> Security Class Initialized
DEBUG - 2018-03-26 11:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:09:47 --> Input Class Initialized
INFO - 2018-03-26 11:09:47 --> Language Class Initialized
INFO - 2018-03-26 11:09:47 --> Language Class Initialized
INFO - 2018-03-26 11:09:47 --> Config Class Initialized
INFO - 2018-03-26 11:09:47 --> Loader Class Initialized
INFO - 2018-03-26 16:39:47 --> Helper loaded: url_helper
INFO - 2018-03-26 16:39:47 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:39:47 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:39:47 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:39:47 --> Helper loaded: users_helper
INFO - 2018-03-26 11:09:48 --> Config Class Initialized
INFO - 2018-03-26 11:09:48 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:09:48 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:09:48 --> Utf8 Class Initialized
INFO - 2018-03-26 11:09:48 --> URI Class Initialized
INFO - 2018-03-26 11:09:48 --> Router Class Initialized
INFO - 2018-03-26 16:39:48 --> Database Driver Class Initialized
INFO - 2018-03-26 11:09:48 --> Output Class Initialized
DEBUG - 2018-03-26 16:39:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:39:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:09:49 --> Security Class Initialized
DEBUG - 2018-03-26 11:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:09:49 --> Input Class Initialized
INFO - 2018-03-26 11:09:49 --> Language Class Initialized
INFO - 2018-03-26 16:39:49 --> Helper loaded: form_helper
INFO - 2018-03-26 16:39:49 --> Form Validation Class Initialized
INFO - 2018-03-26 16:39:49 --> Controller Class Initialized
INFO - 2018-03-26 16:39:50 --> Model Class Initialized
INFO - 2018-03-26 11:09:50 --> Config Class Initialized
INFO - 2018-03-26 11:09:50 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:09:50 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:09:50 --> Utf8 Class Initialized
INFO - 2018-03-26 11:09:50 --> URI Class Initialized
INFO - 2018-03-26 11:09:50 --> Router Class Initialized
INFO - 2018-03-26 11:09:50 --> Output Class Initialized
INFO - 2018-03-26 11:09:50 --> Security Class Initialized
DEBUG - 2018-03-26 11:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:09:50 --> Input Class Initialized
INFO - 2018-03-26 11:09:50 --> Language Class Initialized
INFO - 2018-03-26 16:39:50 --> Helper loaded: inflector_helper
INFO - 2018-03-26 11:09:50 --> Language Class Initialized
INFO - 2018-03-26 11:09:50 --> Config Class Initialized
INFO - 2018-03-26 11:09:50 --> Loader Class Initialized
INFO - 2018-03-26 16:39:50 --> Helper loaded: url_helper
INFO - 2018-03-26 16:39:50 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:39:50 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:39:50 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:39:50 --> Helper loaded: users_helper
DEBUG - 2018-03-26 16:39:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:39:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:39:50 --> Model Class Initialized
INFO - 2018-03-26 16:39:50 --> Model Class Initialized
INFO - 2018-03-26 16:39:50 --> Model Class Initialized
INFO - 2018-03-26 16:39:50 --> Model Class Initialized
INFO - 2018-03-26 16:39:50 --> Model Class Initialized
INFO - 2018-03-26 16:39:50 --> Model Class Initialized
INFO - 2018-03-26 16:39:50 --> Model Class Initialized
INFO - 2018-03-26 16:39:50 --> Model Class Initialized
INFO - 2018-03-26 16:39:50 --> Model Class Initialized
INFO - 2018-03-26 16:39:50 --> Model Class Initialized
INFO - 2018-03-26 16:39:50 --> Model Class Initialized
INFO - 2018-03-26 16:39:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:39:50 --> Model Class Initialized
INFO - 2018-03-26 16:39:50 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:39:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:39:50 --> Final output sent to browser
DEBUG - 2018-03-26 16:39:50 --> Total execution time: 3.0400
INFO - 2018-03-26 16:39:50 --> Helper loaded: form_helper
INFO - 2018-03-26 16:39:50 --> Form Validation Class Initialized
INFO - 2018-03-26 16:39:50 --> Controller Class Initialized
INFO - 2018-03-26 16:39:50 --> Model Class Initialized
INFO - 2018-03-26 16:39:50 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:39:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:39:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:39:50 --> Model Class Initialized
INFO - 2018-03-26 16:39:50 --> Model Class Initialized
INFO - 2018-03-26 16:39:50 --> Model Class Initialized
INFO - 2018-03-26 16:39:50 --> Model Class Initialized
INFO - 2018-03-26 16:39:50 --> Model Class Initialized
INFO - 2018-03-26 16:39:50 --> Model Class Initialized
INFO - 2018-03-26 16:39:50 --> Model Class Initialized
INFO - 2018-03-26 16:39:50 --> Model Class Initialized
INFO - 2018-03-26 16:39:50 --> Model Class Initialized
INFO - 2018-03-26 16:39:50 --> Model Class Initialized
INFO - 2018-03-26 16:39:50 --> Model Class Initialized
INFO - 2018-03-26 16:39:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:39:50 --> Model Class Initialized
INFO - 2018-03-26 16:39:50 --> Final output sent to browser
DEBUG - 2018-03-26 16:39:50 --> Total execution time: 0.1291
INFO - 2018-03-26 11:09:50 --> Language Class Initialized
INFO - 2018-03-26 11:09:50 --> Config Class Initialized
INFO - 2018-03-26 11:09:50 --> Loader Class Initialized
INFO - 2018-03-26 16:39:50 --> Helper loaded: url_helper
INFO - 2018-03-26 16:39:50 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:39:50 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:39:50 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:39:50 --> Helper loaded: users_helper
INFO - 2018-03-26 11:09:50 --> Config Class Initialized
INFO - 2018-03-26 11:09:50 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:09:50 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:09:50 --> Utf8 Class Initialized
INFO - 2018-03-26 11:09:50 --> URI Class Initialized
INFO - 2018-03-26 11:09:51 --> Router Class Initialized
INFO - 2018-03-26 11:09:51 --> Output Class Initialized
INFO - 2018-03-26 11:09:51 --> Security Class Initialized
DEBUG - 2018-03-26 11:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:09:51 --> Input Class Initialized
INFO - 2018-03-26 11:09:51 --> Language Class Initialized
INFO - 2018-03-26 16:39:51 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:39:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:39:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:09:51 --> Language Class Initialized
INFO - 2018-03-26 11:09:51 --> Config Class Initialized
INFO - 2018-03-26 11:09:51 --> Loader Class Initialized
INFO - 2018-03-26 16:39:51 --> Helper loaded: form_helper
INFO - 2018-03-26 16:39:51 --> Form Validation Class Initialized
INFO - 2018-03-26 16:39:51 --> Controller Class Initialized
INFO - 2018-03-26 16:39:51 --> Helper loaded: url_helper
INFO - 2018-03-26 16:39:51 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:39:51 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:39:51 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:39:52 --> Helper loaded: users_helper
INFO - 2018-03-26 16:39:52 --> Model Class Initialized
INFO - 2018-03-26 16:39:52 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:39:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:39:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:39:52 --> Model Class Initialized
INFO - 2018-03-26 16:39:52 --> Model Class Initialized
INFO - 2018-03-26 16:39:52 --> Model Class Initialized
INFO - 2018-03-26 16:39:52 --> Model Class Initialized
INFO - 2018-03-26 16:39:52 --> Model Class Initialized
INFO - 2018-03-26 16:39:52 --> Model Class Initialized
INFO - 2018-03-26 16:39:52 --> Model Class Initialized
INFO - 2018-03-26 16:39:52 --> Model Class Initialized
INFO - 2018-03-26 16:39:52 --> Model Class Initialized
INFO - 2018-03-26 16:39:52 --> Model Class Initialized
INFO - 2018-03-26 16:39:52 --> Model Class Initialized
INFO - 2018-03-26 16:39:52 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:39:52 --> Database Driver Class Initialized
INFO - 2018-03-26 16:39:52 --> Model Class Initialized
INFO - 2018-03-26 16:39:52 --> Final output sent to browser
DEBUG - 2018-03-26 16:39:52 --> Total execution time: 4.8215
DEBUG - 2018-03-26 16:39:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:39:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:39:52 --> Helper loaded: form_helper
INFO - 2018-03-26 16:39:52 --> Form Validation Class Initialized
INFO - 2018-03-26 16:39:52 --> Controller Class Initialized
INFO - 2018-03-26 16:39:53 --> Model Class Initialized
INFO - 2018-03-26 16:39:53 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:39:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:39:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:39:53 --> Model Class Initialized
INFO - 2018-03-26 16:39:53 --> Model Class Initialized
INFO - 2018-03-26 16:39:53 --> Model Class Initialized
INFO - 2018-03-26 16:39:53 --> Model Class Initialized
INFO - 2018-03-26 16:39:53 --> Model Class Initialized
INFO - 2018-03-26 16:39:53 --> Model Class Initialized
INFO - 2018-03-26 16:39:53 --> Model Class Initialized
INFO - 2018-03-26 16:39:53 --> Model Class Initialized
INFO - 2018-03-26 16:39:53 --> Model Class Initialized
INFO - 2018-03-26 16:39:53 --> Model Class Initialized
INFO - 2018-03-26 16:39:53 --> Model Class Initialized
INFO - 2018-03-26 16:39:53 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:39:53 --> Model Class Initialized
INFO - 2018-03-26 16:39:53 --> Final output sent to browser
DEBUG - 2018-03-26 16:39:53 --> Total execution time: 3.1368
INFO - 2018-03-26 11:10:07 --> Config Class Initialized
INFO - 2018-03-26 11:10:07 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:10:07 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:10:07 --> Utf8 Class Initialized
INFO - 2018-03-26 11:10:07 --> Config Class Initialized
INFO - 2018-03-26 11:10:07 --> Hooks Class Initialized
INFO - 2018-03-26 11:10:07 --> URI Class Initialized
DEBUG - 2018-03-26 11:10:07 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:10:07 --> Utf8 Class Initialized
INFO - 2018-03-26 11:10:07 --> URI Class Initialized
INFO - 2018-03-26 11:10:07 --> Config Class Initialized
INFO - 2018-03-26 11:10:07 --> Hooks Class Initialized
INFO - 2018-03-26 11:10:07 --> Router Class Initialized
INFO - 2018-03-26 11:10:07 --> Config Class Initialized
INFO - 2018-03-26 11:10:07 --> Hooks Class Initialized
INFO - 2018-03-26 11:10:07 --> Config Class Initialized
INFO - 2018-03-26 11:10:07 --> Hooks Class Initialized
INFO - 2018-03-26 11:10:07 --> Output Class Initialized
DEBUG - 2018-03-26 11:10:07 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:10:07 --> Utf8 Class Initialized
INFO - 2018-03-26 11:10:07 --> Router Class Initialized
DEBUG - 2018-03-26 11:10:07 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:10:07 --> Utf8 Class Initialized
INFO - 2018-03-26 11:10:07 --> URI Class Initialized
INFO - 2018-03-26 11:10:07 --> Security Class Initialized
DEBUG - 2018-03-26 11:10:07 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:10:07 --> Utf8 Class Initialized
INFO - 2018-03-26 11:10:07 --> URI Class Initialized
INFO - 2018-03-26 11:10:08 --> URI Class Initialized
INFO - 2018-03-26 11:10:08 --> Output Class Initialized
DEBUG - 2018-03-26 11:10:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:10:08 --> Input Class Initialized
INFO - 2018-03-26 11:10:08 --> Router Class Initialized
INFO - 2018-03-26 11:10:08 --> Language Class Initialized
INFO - 2018-03-26 11:10:08 --> Router Class Initialized
INFO - 2018-03-26 11:10:08 --> Security Class Initialized
INFO - 2018-03-26 11:10:08 --> Router Class Initialized
INFO - 2018-03-26 11:10:08 --> Output Class Initialized
INFO - 2018-03-26 11:10:08 --> Output Class Initialized
DEBUG - 2018-03-26 11:10:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:10:08 --> Input Class Initialized
INFO - 2018-03-26 11:10:08 --> Security Class Initialized
INFO - 2018-03-26 11:10:08 --> Output Class Initialized
INFO - 2018-03-26 11:10:08 --> Language Class Initialized
INFO - 2018-03-26 11:10:08 --> Security Class Initialized
DEBUG - 2018-03-26 11:10:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:10:08 --> Input Class Initialized
INFO - 2018-03-26 11:10:08 --> Language Class Initialized
INFO - 2018-03-26 11:10:08 --> Security Class Initialized
DEBUG - 2018-03-26 11:10:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:10:08 --> Input Class Initialized
INFO - 2018-03-26 11:10:08 --> Language Class Initialized
DEBUG - 2018-03-26 11:10:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:10:08 --> Input Class Initialized
INFO - 2018-03-26 11:10:08 --> Language Class Initialized
INFO - 2018-03-26 11:10:08 --> Language Class Initialized
INFO - 2018-03-26 11:10:08 --> Config Class Initialized
INFO - 2018-03-26 11:10:08 --> Loader Class Initialized
INFO - 2018-03-26 16:40:09 --> Helper loaded: url_helper
INFO - 2018-03-26 16:40:09 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:40:09 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:40:09 --> Helper loaded: permission_helper
INFO - 2018-03-26 11:10:09 --> Language Class Initialized
INFO - 2018-03-26 11:10:09 --> Config Class Initialized
INFO - 2018-03-26 16:40:09 --> Helper loaded: users_helper
INFO - 2018-03-26 11:10:09 --> Loader Class Initialized
INFO - 2018-03-26 11:10:09 --> Language Class Initialized
INFO - 2018-03-26 16:40:09 --> Helper loaded: url_helper
INFO - 2018-03-26 11:10:09 --> Config Class Initialized
INFO - 2018-03-26 11:10:09 --> Loader Class Initialized
INFO - 2018-03-26 16:40:09 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:40:09 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:40:09 --> Helper loaded: url_helper
INFO - 2018-03-26 16:40:09 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:40:09 --> Helper loaded: users_helper
INFO - 2018-03-26 16:40:09 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:40:09 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:40:09 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:40:09 --> Helper loaded: users_helper
INFO - 2018-03-26 11:10:09 --> Language Class Initialized
INFO - 2018-03-26 11:10:09 --> Config Class Initialized
INFO - 2018-03-26 11:10:09 --> Loader Class Initialized
INFO - 2018-03-26 11:10:09 --> Language Class Initialized
INFO - 2018-03-26 11:10:09 --> Config Class Initialized
INFO - 2018-03-26 11:10:09 --> Loader Class Initialized
INFO - 2018-03-26 16:40:09 --> Database Driver Class Initialized
INFO - 2018-03-26 16:40:09 --> Database Driver Class Initialized
INFO - 2018-03-26 16:40:09 --> Helper loaded: url_helper
INFO - 2018-03-26 11:10:09 --> Config Class Initialized
INFO - 2018-03-26 11:10:09 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:10:09 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:10:09 --> Utf8 Class Initialized
INFO - 2018-03-26 11:10:09 --> URI Class Initialized
INFO - 2018-03-26 11:10:09 --> Router Class Initialized
INFO - 2018-03-26 16:40:09 --> Helper loaded: notification_helper
INFO - 2018-03-26 11:10:09 --> Output Class Initialized
INFO - 2018-03-26 16:40:09 --> Helper loaded: settings_helper
INFO - 2018-03-26 11:10:09 --> Security Class Initialized
DEBUG - 2018-03-26 16:40:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-26 11:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:10:09 --> Input Class Initialized
INFO - 2018-03-26 16:40:09 --> Helper loaded: url_helper
INFO - 2018-03-26 11:10:09 --> Language Class Initialized
INFO - 2018-03-26 16:40:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-03-26 16:40:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:40:09 --> Database Driver Class Initialized
INFO - 2018-03-26 16:40:09 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:40:09 --> Helper loaded: permission_helper
INFO - 2018-03-26 11:10:09 --> Config Class Initialized
INFO - 2018-03-26 11:10:09 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:10:09 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:10:09 --> Utf8 Class Initialized
INFO - 2018-03-26 16:40:09 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:40:09 --> Helper loaded: users_helper
INFO - 2018-03-26 11:10:09 --> URI Class Initialized
INFO - 2018-03-26 16:40:09 --> Helper loaded: permission_helper
INFO - 2018-03-26 11:10:10 --> Router Class Initialized
INFO - 2018-03-26 16:40:10 --> Helper loaded: users_helper
INFO - 2018-03-26 11:10:10 --> Output Class Initialized
INFO - 2018-03-26 11:10:10 --> Security Class Initialized
DEBUG - 2018-03-26 11:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:10:10 --> Input Class Initialized
INFO - 2018-03-26 11:10:10 --> Language Class Initialized
INFO - 2018-03-26 11:10:10 --> Config Class Initialized
INFO - 2018-03-26 11:10:10 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:10:10 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:10:10 --> Utf8 Class Initialized
INFO - 2018-03-26 11:10:10 --> URI Class Initialized
DEBUG - 2018-03-26 16:40:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:40:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:40:10 --> Helper loaded: form_helper
INFO - 2018-03-26 16:40:10 --> Form Validation Class Initialized
INFO - 2018-03-26 16:40:10 --> Helper loaded: form_helper
INFO - 2018-03-26 16:40:10 --> Form Validation Class Initialized
INFO - 2018-03-26 16:40:10 --> Controller Class Initialized
INFO - 2018-03-26 11:10:10 --> Router Class Initialized
INFO - 2018-03-26 16:40:10 --> Model Class Initialized
INFO - 2018-03-26 16:40:10 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:40:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:40:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:40:10 --> Model Class Initialized
INFO - 2018-03-26 16:40:10 --> Model Class Initialized
INFO - 2018-03-26 16:40:10 --> Model Class Initialized
INFO - 2018-03-26 16:40:10 --> Model Class Initialized
INFO - 2018-03-26 16:40:10 --> Model Class Initialized
INFO - 2018-03-26 16:40:10 --> Model Class Initialized
INFO - 2018-03-26 16:40:10 --> Model Class Initialized
INFO - 2018-03-26 11:10:10 --> Output Class Initialized
INFO - 2018-03-26 16:40:10 --> Model Class Initialized
INFO - 2018-03-26 16:40:10 --> Model Class Initialized
INFO - 2018-03-26 16:40:10 --> Model Class Initialized
INFO - 2018-03-26 16:40:10 --> Model Class Initialized
INFO - 2018-03-26 16:40:10 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:40:10 --> Model Class Initialized
INFO - 2018-03-26 16:40:10 --> Controller Class Initialized
INFO - 2018-03-26 11:10:10 --> Security Class Initialized
INFO - 2018-03-26 16:40:10 --> Final output sent to browser
DEBUG - 2018-03-26 16:40:10 --> Total execution time: 3.0446
INFO - 2018-03-26 11:10:10 --> Language Class Initialized
INFO - 2018-03-26 11:10:10 --> Config Class Initialized
INFO - 2018-03-26 11:10:10 --> Loader Class Initialized
DEBUG - 2018-03-26 11:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:10:10 --> Input Class Initialized
INFO - 2018-03-26 11:10:10 --> Language Class Initialized
INFO - 2018-03-26 16:40:10 --> Database Driver Class Initialized
INFO - 2018-03-26 16:40:10 --> Helper loaded: url_helper
INFO - 2018-03-26 16:40:10 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:40:10 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:40:10 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:40:10 --> Helper loaded: users_helper
INFO - 2018-03-26 11:10:10 --> Language Class Initialized
INFO - 2018-03-26 11:10:10 --> Config Class Initialized
INFO - 2018-03-26 11:10:10 --> Loader Class Initialized
INFO - 2018-03-26 16:40:10 --> Helper loaded: url_helper
INFO - 2018-03-26 16:40:10 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:40:10 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:40:10 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:40:10 --> Helper loaded: users_helper
DEBUG - 2018-03-26 16:40:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:40:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:40:10 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:40:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:40:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:40:10 --> Helper loaded: form_helper
INFO - 2018-03-26 16:40:10 --> Form Validation Class Initialized
INFO - 2018-03-26 16:40:10 --> Controller Class Initialized
INFO - 2018-03-26 16:40:10 --> Database Driver Class Initialized
INFO - 2018-03-26 16:40:10 --> Model Class Initialized
INFO - 2018-03-26 16:40:10 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:40:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:40:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:40:10 --> Model Class Initialized
INFO - 2018-03-26 16:40:10 --> Model Class Initialized
INFO - 2018-03-26 16:40:10 --> Model Class Initialized
INFO - 2018-03-26 16:40:10 --> Model Class Initialized
INFO - 2018-03-26 16:40:10 --> Model Class Initialized
INFO - 2018-03-26 16:40:10 --> Model Class Initialized
INFO - 2018-03-26 16:40:10 --> Model Class Initialized
INFO - 2018-03-26 16:40:10 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-03-26 16:40:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:40:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:40:10 --> Model Class Initialized
INFO - 2018-03-26 16:40:10 --> Final output sent to browser
DEBUG - 2018-03-26 16:40:10 --> Total execution time: 0.2115
INFO - 2018-03-26 16:40:10 --> Helper loaded: inflector_helper
INFO - 2018-03-26 16:40:10 --> Helper loaded: form_helper
INFO - 2018-03-26 16:40:10 --> Form Validation Class Initialized
DEBUG - 2018-03-26 16:40:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:40:10 --> Controller Class Initialized
INFO - 2018-03-26 16:40:10 --> Helper loaded: form_helper
INFO - 2018-03-26 16:40:10 --> Form Validation Class Initialized
INFO - 2018-03-26 16:40:10 --> Controller Class Initialized
INFO - 2018-03-26 16:40:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:40:10 --> Model Class Initialized
INFO - 2018-03-26 16:40:10 --> Model Class Initialized
INFO - 2018-03-26 16:40:10 --> Model Class Initialized
INFO - 2018-03-26 16:40:10 --> Model Class Initialized
INFO - 2018-03-26 16:40:10 --> Model Class Initialized
INFO - 2018-03-26 16:40:10 --> Model Class Initialized
INFO - 2018-03-26 16:40:10 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:40:10 --> Final output sent to browser
DEBUG - 2018-03-26 16:40:10 --> Total execution time: 3.0258
INFO - 2018-03-26 16:40:10 --> Model Class Initialized
INFO - 2018-03-26 16:40:10 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:40:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:40:10 --> Helper loaded: form_helper
INFO - 2018-03-26 16:40:10 --> Form Validation Class Initialized
INFO - 2018-03-26 16:40:10 --> Controller Class Initialized
INFO - 2018-03-26 16:40:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:40:10 --> Model Class Initialized
INFO - 2018-03-26 16:40:10 --> Model Class Initialized
INFO - 2018-03-26 16:40:10 --> Model Class Initialized
INFO - 2018-03-26 16:40:10 --> Model Class Initialized
INFO - 2018-03-26 16:40:10 --> Model Class Initialized
INFO - 2018-03-26 16:40:10 --> Model Class Initialized
INFO - 2018-03-26 16:40:10 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:40:10 --> Final output sent to browser
DEBUG - 2018-03-26 16:40:10 --> Total execution time: 0.5050
INFO - 2018-03-26 16:40:10 --> Model Class Initialized
INFO - 2018-03-26 16:40:10 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:40:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:40:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:40:10 --> Model Class Initialized
INFO - 2018-03-26 16:40:10 --> Model Class Initialized
INFO - 2018-03-26 16:40:10 --> Model Class Initialized
INFO - 2018-03-26 16:40:10 --> Model Class Initialized
INFO - 2018-03-26 16:40:10 --> Model Class Initialized
INFO - 2018-03-26 16:40:10 --> Model Class Initialized
INFO - 2018-03-26 16:40:10 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:40:10 --> Model Class Initialized
INFO - 2018-03-26 16:40:10 --> Model Class Initialized
INFO - 2018-03-26 16:40:10 --> Final output sent to browser
DEBUG - 2018-03-26 16:40:10 --> Total execution time: 3.2988
INFO - 2018-03-26 16:40:10 --> Helper loaded: inflector_helper
INFO - 2018-03-26 11:10:10 --> Language Class Initialized
INFO - 2018-03-26 11:10:10 --> Config Class Initialized
INFO - 2018-03-26 11:10:10 --> Loader Class Initialized
DEBUG - 2018-03-26 16:40:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:40:10 --> Helper loaded: url_helper
INFO - 2018-03-26 16:40:10 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:40:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:40:11 --> Database Driver Class Initialized
INFO - 2018-03-26 16:40:11 --> Helper loaded: settings_helper
DEBUG - 2018-03-26 16:40:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:40:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:40:11 --> Helper loaded: form_helper
INFO - 2018-03-26 16:40:11 --> Form Validation Class Initialized
INFO - 2018-03-26 16:40:11 --> Controller Class Initialized
INFO - 2018-03-26 16:40:11 --> Model Class Initialized
INFO - 2018-03-26 16:40:11 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:40:11 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:40:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:40:11 --> Model Class Initialized
INFO - 2018-03-26 16:40:11 --> Model Class Initialized
INFO - 2018-03-26 16:40:11 --> Model Class Initialized
INFO - 2018-03-26 16:40:11 --> Model Class Initialized
INFO - 2018-03-26 16:40:11 --> Model Class Initialized
INFO - 2018-03-26 16:40:11 --> Model Class Initialized
INFO - 2018-03-26 16:40:11 --> Model Class Initialized
INFO - 2018-03-26 16:40:11 --> Model Class Initialized
INFO - 2018-03-26 16:40:11 --> Model Class Initialized
INFO - 2018-03-26 16:40:11 --> Model Class Initialized
INFO - 2018-03-26 16:40:11 --> Model Class Initialized
INFO - 2018-03-26 16:40:11 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:40:11 --> Model Class Initialized
INFO - 2018-03-26 16:40:11 --> Final output sent to browser
DEBUG - 2018-03-26 16:40:11 --> Total execution time: 3.5432
INFO - 2018-03-26 16:40:11 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:40:11 --> Model Class Initialized
INFO - 2018-03-26 16:40:11 --> Helper loaded: users_helper
INFO - 2018-03-26 16:40:11 --> Model Class Initialized
INFO - 2018-03-26 16:40:11 --> Model Class Initialized
INFO - 2018-03-26 16:40:11 --> Model Class Initialized
INFO - 2018-03-26 16:40:11 --> Model Class Initialized
INFO - 2018-03-26 16:40:11 --> Model Class Initialized
INFO - 2018-03-26 16:40:11 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:40:11 --> Model Class Initialized
INFO - 2018-03-26 16:40:11 --> Final output sent to browser
DEBUG - 2018-03-26 16:40:11 --> Total execution time: 4.0490
INFO - 2018-03-26 11:10:11 --> Config Class Initialized
INFO - 2018-03-26 11:10:11 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:10:11 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:10:11 --> Utf8 Class Initialized
INFO - 2018-03-26 11:10:11 --> URI Class Initialized
INFO - 2018-03-26 11:10:11 --> Router Class Initialized
INFO - 2018-03-26 11:10:11 --> Output Class Initialized
INFO - 2018-03-26 11:10:11 --> Security Class Initialized
DEBUG - 2018-03-26 11:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:10:11 --> Input Class Initialized
INFO - 2018-03-26 11:10:11 --> Language Class Initialized
INFO - 2018-03-26 11:10:11 --> Language Class Initialized
INFO - 2018-03-26 11:10:11 --> Config Class Initialized
INFO - 2018-03-26 11:10:11 --> Loader Class Initialized
INFO - 2018-03-26 16:40:11 --> Helper loaded: url_helper
INFO - 2018-03-26 16:40:11 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:40:11 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:40:11 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:40:11 --> Helper loaded: users_helper
INFO - 2018-03-26 16:40:11 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:40:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:40:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:40:11 --> Helper loaded: form_helper
INFO - 2018-03-26 16:40:11 --> Form Validation Class Initialized
INFO - 2018-03-26 16:40:11 --> Controller Class Initialized
INFO - 2018-03-26 16:40:11 --> Model Class Initialized
INFO - 2018-03-26 16:40:11 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:40:11 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:40:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:40:12 --> Model Class Initialized
INFO - 2018-03-26 16:40:12 --> Model Class Initialized
INFO - 2018-03-26 16:40:12 --> Model Class Initialized
INFO - 2018-03-26 16:40:12 --> Model Class Initialized
INFO - 2018-03-26 16:40:12 --> Model Class Initialized
INFO - 2018-03-26 16:40:12 --> Model Class Initialized
INFO - 2018-03-26 16:40:12 --> Model Class Initialized
INFO - 2018-03-26 16:40:12 --> Model Class Initialized
INFO - 2018-03-26 16:40:12 --> Model Class Initialized
INFO - 2018-03-26 16:40:12 --> Model Class Initialized
INFO - 2018-03-26 16:40:12 --> Model Class Initialized
INFO - 2018-03-26 16:40:12 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:40:12 --> Model Class Initialized
INFO - 2018-03-26 16:40:12 --> Database Driver Class Initialized
INFO - 2018-03-26 16:40:12 --> Final output sent to browser
DEBUG - 2018-03-26 16:40:12 --> Total execution time: 0.4346
DEBUG - 2018-03-26 16:40:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:40:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:40:12 --> Helper loaded: form_helper
INFO - 2018-03-26 16:40:12 --> Form Validation Class Initialized
INFO - 2018-03-26 16:40:12 --> Controller Class Initialized
INFO - 2018-03-26 16:40:12 --> Model Class Initialized
INFO - 2018-03-26 16:40:12 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:40:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:40:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:40:12 --> Model Class Initialized
INFO - 2018-03-26 16:40:12 --> Model Class Initialized
INFO - 2018-03-26 16:40:12 --> Model Class Initialized
INFO - 2018-03-26 16:40:12 --> Model Class Initialized
INFO - 2018-03-26 16:40:12 --> Model Class Initialized
INFO - 2018-03-26 16:40:12 --> Model Class Initialized
INFO - 2018-03-26 16:40:12 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:40:12 --> Model Class Initialized
INFO - 2018-03-26 16:40:12 --> Final output sent to browser
DEBUG - 2018-03-26 16:40:12 --> Total execution time: 2.5480
INFO - 2018-03-26 11:10:31 --> Config Class Initialized
INFO - 2018-03-26 11:10:31 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:10:31 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:10:31 --> Utf8 Class Initialized
INFO - 2018-03-26 11:10:31 --> URI Class Initialized
INFO - 2018-03-26 11:10:31 --> Router Class Initialized
INFO - 2018-03-26 11:10:31 --> Output Class Initialized
INFO - 2018-03-26 11:10:31 --> Security Class Initialized
DEBUG - 2018-03-26 11:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:10:31 --> Input Class Initialized
INFO - 2018-03-26 11:10:32 --> Language Class Initialized
INFO - 2018-03-26 11:10:32 --> Language Class Initialized
INFO - 2018-03-26 11:10:32 --> Config Class Initialized
INFO - 2018-03-26 11:10:32 --> Loader Class Initialized
INFO - 2018-03-26 16:40:32 --> Helper loaded: url_helper
INFO - 2018-03-26 16:40:32 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:40:32 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:40:32 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:40:32 --> Helper loaded: users_helper
INFO - 2018-03-26 16:40:33 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:40:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:40:33 --> Helper loaded: form_helper
INFO - 2018-03-26 16:40:33 --> Form Validation Class Initialized
INFO - 2018-03-26 16:40:33 --> Controller Class Initialized
INFO - 2018-03-26 16:40:33 --> Model Class Initialized
INFO - 2018-03-26 16:40:33 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:40:33 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:40:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:40:33 --> Model Class Initialized
INFO - 2018-03-26 16:40:34 --> Model Class Initialized
INFO - 2018-03-26 16:40:34 --> Model Class Initialized
INFO - 2018-03-26 16:40:34 --> Model Class Initialized
INFO - 2018-03-26 16:40:34 --> Model Class Initialized
INFO - 2018-03-26 16:40:34 --> Model Class Initialized
INFO - 2018-03-26 16:40:34 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:40:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-26 16:40:34 --> Final output sent to browser
DEBUG - 2018-03-26 16:40:34 --> Total execution time: 3.0693
INFO - 2018-03-26 11:10:35 --> Config Class Initialized
INFO - 2018-03-26 11:10:35 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:10:35 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:10:35 --> Utf8 Class Initialized
INFO - 2018-03-26 11:10:35 --> URI Class Initialized
INFO - 2018-03-26 11:10:35 --> Router Class Initialized
INFO - 2018-03-26 11:10:35 --> Output Class Initialized
INFO - 2018-03-26 11:10:35 --> Security Class Initialized
DEBUG - 2018-03-26 11:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:10:35 --> Input Class Initialized
INFO - 2018-03-26 11:10:35 --> Language Class Initialized
INFO - 2018-03-26 11:10:35 --> Language Class Initialized
INFO - 2018-03-26 11:10:35 --> Config Class Initialized
INFO - 2018-03-26 11:10:35 --> Loader Class Initialized
INFO - 2018-03-26 16:40:35 --> Helper loaded: url_helper
INFO - 2018-03-26 16:40:35 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:40:35 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:40:35 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:40:35 --> Helper loaded: users_helper
INFO - 2018-03-26 16:40:35 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:40:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:40:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:40:35 --> Helper loaded: form_helper
INFO - 2018-03-26 16:40:35 --> Form Validation Class Initialized
INFO - 2018-03-26 16:40:35 --> Controller Class Initialized
INFO - 2018-03-26 16:40:35 --> Model Class Initialized
INFO - 2018-03-26 16:40:35 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:40:35 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:40:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:40:35 --> Model Class Initialized
INFO - 2018-03-26 16:40:35 --> Model Class Initialized
INFO - 2018-03-26 16:40:35 --> Model Class Initialized
INFO - 2018-03-26 16:40:35 --> Model Class Initialized
INFO - 2018-03-26 16:40:35 --> Model Class Initialized
INFO - 2018-03-26 16:40:35 --> Model Class Initialized
INFO - 2018-03-26 16:40:35 --> Model Class Initialized
INFO - 2018-03-26 16:40:35 --> Model Class Initialized
INFO - 2018-03-26 16:40:35 --> Model Class Initialized
INFO - 2018-03-26 16:40:35 --> Model Class Initialized
INFO - 2018-03-26 16:40:35 --> Model Class Initialized
INFO - 2018-03-26 16:40:35 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:40:35 --> Model Class Initialized
INFO - 2018-03-26 16:40:35 --> Final output sent to browser
DEBUG - 2018-03-26 16:40:35 --> Total execution time: 0.1020
INFO - 2018-03-26 11:10:37 --> Config Class Initialized
INFO - 2018-03-26 11:10:37 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:10:37 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:10:37 --> Utf8 Class Initialized
INFO - 2018-03-26 11:10:37 --> URI Class Initialized
INFO - 2018-03-26 11:10:37 --> Router Class Initialized
INFO - 2018-03-26 11:10:38 --> Output Class Initialized
INFO - 2018-03-26 11:10:38 --> Security Class Initialized
DEBUG - 2018-03-26 11:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:10:38 --> Input Class Initialized
INFO - 2018-03-26 11:10:38 --> Language Class Initialized
INFO - 2018-03-26 11:10:38 --> Language Class Initialized
INFO - 2018-03-26 11:10:38 --> Config Class Initialized
INFO - 2018-03-26 11:10:38 --> Loader Class Initialized
INFO - 2018-03-26 16:40:38 --> Helper loaded: url_helper
INFO - 2018-03-26 16:40:38 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:40:38 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:40:38 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:40:39 --> Helper loaded: users_helper
INFO - 2018-03-26 11:10:39 --> Config Class Initialized
INFO - 2018-03-26 11:10:39 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:10:39 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:10:39 --> Utf8 Class Initialized
INFO - 2018-03-26 11:10:39 --> URI Class Initialized
INFO - 2018-03-26 11:10:39 --> Router Class Initialized
INFO - 2018-03-26 11:10:39 --> Output Class Initialized
INFO - 2018-03-26 11:10:39 --> Security Class Initialized
DEBUG - 2018-03-26 11:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:10:39 --> Input Class Initialized
INFO - 2018-03-26 11:10:39 --> Language Class Initialized
INFO - 2018-03-26 11:10:39 --> Language Class Initialized
INFO - 2018-03-26 11:10:39 --> Config Class Initialized
INFO - 2018-03-26 11:10:39 --> Loader Class Initialized
INFO - 2018-03-26 16:40:39 --> Helper loaded: url_helper
INFO - 2018-03-26 16:40:39 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:40:39 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:40:39 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:40:39 --> Helper loaded: users_helper
INFO - 2018-03-26 16:40:39 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:40:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:40:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:40:39 --> Helper loaded: form_helper
INFO - 2018-03-26 16:40:39 --> Form Validation Class Initialized
INFO - 2018-03-26 16:40:39 --> Controller Class Initialized
INFO - 2018-03-26 16:40:39 --> Model Class Initialized
INFO - 2018-03-26 16:40:39 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:40:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:40:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:40:39 --> Model Class Initialized
INFO - 2018-03-26 16:40:39 --> Model Class Initialized
INFO - 2018-03-26 16:40:39 --> Model Class Initialized
INFO - 2018-03-26 16:40:39 --> Model Class Initialized
INFO - 2018-03-26 16:40:39 --> Model Class Initialized
INFO - 2018-03-26 16:40:39 --> Model Class Initialized
INFO - 2018-03-26 16:40:39 --> Model Class Initialized
INFO - 2018-03-26 16:40:39 --> Model Class Initialized
INFO - 2018-03-26 16:40:39 --> Model Class Initialized
INFO - 2018-03-26 16:40:39 --> Model Class Initialized
INFO - 2018-03-26 16:40:39 --> Model Class Initialized
INFO - 2018-03-26 16:40:39 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:40:39 --> Model Class Initialized
INFO - 2018-03-26 16:40:39 --> Database Driver Class Initialized
INFO - 2018-03-26 16:40:39 --> Final output sent to browser
DEBUG - 2018-03-26 16:40:39 --> Total execution time: 0.6056
DEBUG - 2018-03-26 16:40:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:40:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:40:39 --> Helper loaded: form_helper
INFO - 2018-03-26 16:40:39 --> Form Validation Class Initialized
INFO - 2018-03-26 16:40:39 --> Controller Class Initialized
INFO - 2018-03-26 16:40:39 --> Model Class Initialized
INFO - 2018-03-26 16:40:39 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:40:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:40:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:40:39 --> Model Class Initialized
INFO - 2018-03-26 16:40:39 --> Model Class Initialized
INFO - 2018-03-26 16:40:39 --> Model Class Initialized
INFO - 2018-03-26 16:40:39 --> Model Class Initialized
INFO - 2018-03-26 16:40:39 --> Model Class Initialized
INFO - 2018-03-26 16:40:39 --> Model Class Initialized
INFO - 2018-03-26 16:40:39 --> Model Class Initialized
INFO - 2018-03-26 16:40:39 --> Model Class Initialized
INFO - 2018-03-26 16:40:39 --> Model Class Initialized
INFO - 2018-03-26 16:40:39 --> Model Class Initialized
INFO - 2018-03-26 16:40:39 --> Model Class Initialized
INFO - 2018-03-26 16:40:39 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:40:39 --> Model Class Initialized
INFO - 2018-03-26 16:40:39 --> Final output sent to browser
DEBUG - 2018-03-26 16:40:39 --> Total execution time: 2.2100
INFO - 2018-03-26 11:10:41 --> Config Class Initialized
INFO - 2018-03-26 11:10:41 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:10:41 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:10:41 --> Utf8 Class Initialized
INFO - 2018-03-26 11:10:41 --> URI Class Initialized
INFO - 2018-03-26 11:10:41 --> Router Class Initialized
INFO - 2018-03-26 11:10:41 --> Output Class Initialized
INFO - 2018-03-26 11:10:41 --> Security Class Initialized
DEBUG - 2018-03-26 11:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:10:41 --> Input Class Initialized
INFO - 2018-03-26 11:10:41 --> Language Class Initialized
INFO - 2018-03-26 11:10:41 --> Language Class Initialized
INFO - 2018-03-26 11:10:41 --> Config Class Initialized
INFO - 2018-03-26 11:10:41 --> Loader Class Initialized
INFO - 2018-03-26 16:40:42 --> Helper loaded: url_helper
INFO - 2018-03-26 16:40:42 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:40:42 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:40:42 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:40:42 --> Helper loaded: users_helper
INFO - 2018-03-26 16:40:42 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:40:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:40:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:40:42 --> Helper loaded: form_helper
INFO - 2018-03-26 16:40:42 --> Form Validation Class Initialized
INFO - 2018-03-26 16:40:42 --> Controller Class Initialized
INFO - 2018-03-26 16:40:42 --> Model Class Initialized
INFO - 2018-03-26 16:40:42 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:40:42 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:40:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:40:42 --> Model Class Initialized
INFO - 2018-03-26 16:40:42 --> Model Class Initialized
INFO - 2018-03-26 16:40:42 --> Model Class Initialized
INFO - 2018-03-26 16:40:42 --> Model Class Initialized
INFO - 2018-03-26 16:40:42 --> Model Class Initialized
INFO - 2018-03-26 16:40:42 --> Model Class Initialized
INFO - 2018-03-26 16:40:42 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-26 16:40:42 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-26 16:40:42 --> Final output sent to browser
DEBUG - 2018-03-26 16:40:42 --> Total execution time: 0.2983
INFO - 2018-03-26 11:10:43 --> Config Class Initialized
INFO - 2018-03-26 11:10:43 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:10:43 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:10:43 --> Utf8 Class Initialized
INFO - 2018-03-26 11:10:43 --> URI Class Initialized
INFO - 2018-03-26 11:10:43 --> Config Class Initialized
INFO - 2018-03-26 11:10:43 --> Hooks Class Initialized
INFO - 2018-03-26 11:10:43 --> Router Class Initialized
DEBUG - 2018-03-26 11:10:43 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:10:43 --> Utf8 Class Initialized
INFO - 2018-03-26 11:10:43 --> Output Class Initialized
INFO - 2018-03-26 11:10:43 --> URI Class Initialized
INFO - 2018-03-26 11:10:43 --> Security Class Initialized
DEBUG - 2018-03-26 11:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:10:43 --> Input Class Initialized
INFO - 2018-03-26 11:10:43 --> Language Class Initialized
INFO - 2018-03-26 11:10:43 --> Router Class Initialized
INFO - 2018-03-26 11:10:43 --> Config Class Initialized
INFO - 2018-03-26 11:10:43 --> Hooks Class Initialized
INFO - 2018-03-26 11:10:43 --> Output Class Initialized
INFO - 2018-03-26 11:10:43 --> Security Class Initialized
DEBUG - 2018-03-26 11:10:43 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:10:43 --> Utf8 Class Initialized
INFO - 2018-03-26 11:10:43 --> URI Class Initialized
DEBUG - 2018-03-26 11:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:10:43 --> Input Class Initialized
INFO - 2018-03-26 11:10:43 --> Language Class Initialized
INFO - 2018-03-26 11:10:43 --> Language Class Initialized
INFO - 2018-03-26 11:10:43 --> Config Class Initialized
INFO - 2018-03-26 11:10:43 --> Loader Class Initialized
INFO - 2018-03-26 16:40:43 --> Helper loaded: url_helper
INFO - 2018-03-26 11:10:43 --> Router Class Initialized
INFO - 2018-03-26 16:40:43 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:40:43 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:40:43 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:40:43 --> Helper loaded: users_helper
INFO - 2018-03-26 11:10:43 --> Output Class Initialized
INFO - 2018-03-26 11:10:43 --> Security Class Initialized
DEBUG - 2018-03-26 11:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:10:43 --> Input Class Initialized
INFO - 2018-03-26 11:10:43 --> Language Class Initialized
INFO - 2018-03-26 16:40:43 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:40:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:40:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:10:43 --> Language Class Initialized
INFO - 2018-03-26 11:10:43 --> Config Class Initialized
INFO - 2018-03-26 11:10:43 --> Loader Class Initialized
INFO - 2018-03-26 16:40:43 --> Helper loaded: form_helper
INFO - 2018-03-26 16:40:43 --> Form Validation Class Initialized
INFO - 2018-03-26 16:40:43 --> Controller Class Initialized
INFO - 2018-03-26 16:40:43 --> Helper loaded: url_helper
INFO - 2018-03-26 16:40:44 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:40:44 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:40:44 --> Model Class Initialized
INFO - 2018-03-26 16:40:44 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:40:44 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:40:44 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:40:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:40:44 --> Helper loaded: users_helper
INFO - 2018-03-26 16:40:44 --> Model Class Initialized
INFO - 2018-03-26 16:40:44 --> Model Class Initialized
INFO - 2018-03-26 16:40:44 --> Model Class Initialized
INFO - 2018-03-26 16:40:44 --> Model Class Initialized
INFO - 2018-03-26 16:40:44 --> Model Class Initialized
INFO - 2018-03-26 16:40:44 --> Model Class Initialized
INFO - 2018-03-26 16:40:44 --> Model Class Initialized
INFO - 2018-03-26 16:40:44 --> Model Class Initialized
INFO - 2018-03-26 16:40:44 --> Model Class Initialized
INFO - 2018-03-26 16:40:44 --> Model Class Initialized
INFO - 2018-03-26 16:40:44 --> Model Class Initialized
INFO - 2018-03-26 16:40:44 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:40:44 --> Model Class Initialized
INFO - 2018-03-26 16:40:44 --> Final output sent to browser
DEBUG - 2018-03-26 16:40:44 --> Total execution time: 0.2084
INFO - 2018-03-26 11:10:44 --> Language Class Initialized
INFO - 2018-03-26 11:10:44 --> Config Class Initialized
INFO - 2018-03-26 11:10:44 --> Loader Class Initialized
INFO - 2018-03-26 16:40:44 --> Helper loaded: url_helper
INFO - 2018-03-26 16:40:44 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:40:44 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:40:44 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:40:44 --> Helper loaded: users_helper
INFO - 2018-03-26 16:40:44 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:40:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:40:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:40:44 --> Database Driver Class Initialized
INFO - 2018-03-26 16:40:44 --> Helper loaded: form_helper
INFO - 2018-03-26 16:40:44 --> Form Validation Class Initialized
INFO - 2018-03-26 16:40:44 --> Controller Class Initialized
DEBUG - 2018-03-26 16:40:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:40:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:40:44 --> Model Class Initialized
INFO - 2018-03-26 16:40:44 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:40:44 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:40:44 --> Helper loaded: form_helper
INFO - 2018-03-26 16:40:44 --> Form Validation Class Initialized
INFO - 2018-03-26 16:40:44 --> Controller Class Initialized
INFO - 2018-03-26 16:40:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:40:44 --> Model Class Initialized
INFO - 2018-03-26 16:40:44 --> Model Class Initialized
INFO - 2018-03-26 16:40:44 --> Model Class Initialized
INFO - 2018-03-26 16:40:44 --> Model Class Initialized
INFO - 2018-03-26 16:40:44 --> Model Class Initialized
INFO - 2018-03-26 16:40:44 --> Model Class Initialized
INFO - 2018-03-26 16:40:44 --> Model Class Initialized
INFO - 2018-03-26 16:40:44 --> Model Class Initialized
INFO - 2018-03-26 16:40:44 --> Model Class Initialized
INFO - 2018-03-26 16:40:44 --> Model Class Initialized
INFO - 2018-03-26 16:40:44 --> Model Class Initialized
INFO - 2018-03-26 16:40:44 --> Helper loaded: inflector_helper
INFO - 2018-03-26 16:40:44 --> Model Class Initialized
INFO - 2018-03-26 16:40:44 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:40:44 --> Model Class Initialized
DEBUG - 2018-03-26 16:40:44 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:40:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:40:44 --> Final output sent to browser
DEBUG - 2018-03-26 16:40:44 --> Total execution time: 0.3979
INFO - 2018-03-26 16:40:44 --> Model Class Initialized
INFO - 2018-03-26 16:40:44 --> Model Class Initialized
INFO - 2018-03-26 16:40:44 --> Model Class Initialized
INFO - 2018-03-26 16:40:44 --> Model Class Initialized
INFO - 2018-03-26 16:40:44 --> Model Class Initialized
INFO - 2018-03-26 16:40:44 --> Model Class Initialized
INFO - 2018-03-26 16:40:44 --> Model Class Initialized
INFO - 2018-03-26 16:40:44 --> Model Class Initialized
INFO - 2018-03-26 16:40:44 --> Model Class Initialized
INFO - 2018-03-26 16:40:44 --> Model Class Initialized
INFO - 2018-03-26 16:40:44 --> Model Class Initialized
INFO - 2018-03-26 16:40:44 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:40:44 --> Model Class Initialized
INFO - 2018-03-26 16:40:44 --> Final output sent to browser
DEBUG - 2018-03-26 16:40:44 --> Total execution time: 0.4089
INFO - 2018-03-26 11:10:47 --> Config Class Initialized
INFO - 2018-03-26 11:10:48 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:10:48 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:10:48 --> Utf8 Class Initialized
INFO - 2018-03-26 11:10:48 --> URI Class Initialized
INFO - 2018-03-26 11:10:48 --> Router Class Initialized
INFO - 2018-03-26 11:10:48 --> Output Class Initialized
INFO - 2018-03-26 11:10:48 --> Security Class Initialized
DEBUG - 2018-03-26 11:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:10:48 --> Input Class Initialized
INFO - 2018-03-26 11:10:48 --> Language Class Initialized
INFO - 2018-03-26 11:10:49 --> Language Class Initialized
INFO - 2018-03-26 11:10:49 --> Config Class Initialized
INFO - 2018-03-26 11:10:49 --> Loader Class Initialized
INFO - 2018-03-26 16:40:49 --> Helper loaded: url_helper
INFO - 2018-03-26 16:40:49 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:40:49 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:40:49 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:40:49 --> Helper loaded: users_helper
INFO - 2018-03-26 16:40:49 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:40:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:40:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:40:49 --> Helper loaded: form_helper
INFO - 2018-03-26 16:40:49 --> Form Validation Class Initialized
INFO - 2018-03-26 16:40:49 --> Controller Class Initialized
INFO - 2018-03-26 16:40:49 --> Model Class Initialized
INFO - 2018-03-26 16:40:49 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:40:49 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:40:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:40:49 --> Model Class Initialized
INFO - 2018-03-26 16:40:49 --> Model Class Initialized
INFO - 2018-03-26 16:40:49 --> Model Class Initialized
INFO - 2018-03-26 16:40:49 --> Model Class Initialized
INFO - 2018-03-26 16:40:49 --> Model Class Initialized
INFO - 2018-03-26 16:40:49 --> Model Class Initialized
INFO - 2018-03-26 16:40:49 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-26 16:40:49 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-26 16:40:49 --> Final output sent to browser
DEBUG - 2018-03-26 16:40:49 --> Total execution time: 1.9547
INFO - 2018-03-26 11:10:50 --> Config Class Initialized
INFO - 2018-03-26 11:10:50 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:10:50 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:10:50 --> Utf8 Class Initialized
INFO - 2018-03-26 11:10:50 --> URI Class Initialized
INFO - 2018-03-26 11:10:50 --> Router Class Initialized
INFO - 2018-03-26 11:10:51 --> Output Class Initialized
INFO - 2018-03-26 11:10:51 --> Security Class Initialized
DEBUG - 2018-03-26 11:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:10:51 --> Input Class Initialized
INFO - 2018-03-26 11:10:51 --> Config Class Initialized
INFO - 2018-03-26 11:10:51 --> Hooks Class Initialized
INFO - 2018-03-26 11:10:51 --> Language Class Initialized
DEBUG - 2018-03-26 11:10:51 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:10:51 --> Utf8 Class Initialized
INFO - 2018-03-26 11:10:51 --> URI Class Initialized
INFO - 2018-03-26 11:10:51 --> Router Class Initialized
INFO - 2018-03-26 11:10:51 --> Output Class Initialized
INFO - 2018-03-26 11:10:51 --> Security Class Initialized
DEBUG - 2018-03-26 11:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:10:51 --> Input Class Initialized
INFO - 2018-03-26 11:10:51 --> Language Class Initialized
INFO - 2018-03-26 11:10:51 --> Language Class Initialized
INFO - 2018-03-26 11:10:51 --> Config Class Initialized
INFO - 2018-03-26 11:10:51 --> Loader Class Initialized
INFO - 2018-03-26 16:40:51 --> Helper loaded: url_helper
INFO - 2018-03-26 16:40:51 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:40:51 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:40:51 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:40:51 --> Helper loaded: users_helper
INFO - 2018-03-26 16:40:51 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:40:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:40:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:40:51 --> Helper loaded: form_helper
INFO - 2018-03-26 16:40:51 --> Form Validation Class Initialized
INFO - 2018-03-26 16:40:51 --> Controller Class Initialized
INFO - 2018-03-26 16:40:51 --> Model Class Initialized
INFO - 2018-03-26 16:40:51 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:40:51 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:40:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:40:51 --> Model Class Initialized
INFO - 2018-03-26 16:40:51 --> Model Class Initialized
INFO - 2018-03-26 16:40:51 --> Model Class Initialized
INFO - 2018-03-26 16:40:51 --> Model Class Initialized
INFO - 2018-03-26 16:40:51 --> Model Class Initialized
INFO - 2018-03-26 16:40:51 --> Model Class Initialized
INFO - 2018-03-26 16:40:51 --> Model Class Initialized
INFO - 2018-03-26 16:40:51 --> Model Class Initialized
INFO - 2018-03-26 16:40:51 --> Model Class Initialized
INFO - 2018-03-26 16:40:51 --> Model Class Initialized
INFO - 2018-03-26 16:40:51 --> Model Class Initialized
INFO - 2018-03-26 16:40:51 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:40:51 --> Model Class Initialized
INFO - 2018-03-26 16:40:51 --> Final output sent to browser
DEBUG - 2018-03-26 16:40:51 --> Total execution time: 0.2668
INFO - 2018-03-26 11:10:51 --> Language Class Initialized
INFO - 2018-03-26 11:10:51 --> Config Class Initialized
INFO - 2018-03-26 11:10:51 --> Loader Class Initialized
INFO - 2018-03-26 16:40:51 --> Helper loaded: url_helper
INFO - 2018-03-26 16:40:51 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:40:51 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:40:51 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:40:51 --> Helper loaded: users_helper
INFO - 2018-03-26 16:40:52 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:40:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:40:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:40:52 --> Helper loaded: form_helper
INFO - 2018-03-26 16:40:52 --> Form Validation Class Initialized
INFO - 2018-03-26 16:40:52 --> Controller Class Initialized
INFO - 2018-03-26 16:40:52 --> Model Class Initialized
INFO - 2018-03-26 16:40:52 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:40:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:40:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:40:52 --> Model Class Initialized
INFO - 2018-03-26 16:40:52 --> Model Class Initialized
INFO - 2018-03-26 16:40:52 --> Model Class Initialized
INFO - 2018-03-26 16:40:52 --> Model Class Initialized
INFO - 2018-03-26 16:40:52 --> Model Class Initialized
INFO - 2018-03-26 16:40:52 --> Model Class Initialized
INFO - 2018-03-26 16:40:52 --> Model Class Initialized
INFO - 2018-03-26 16:40:52 --> Model Class Initialized
INFO - 2018-03-26 16:40:52 --> Model Class Initialized
INFO - 2018-03-26 16:40:52 --> Model Class Initialized
INFO - 2018-03-26 16:40:52 --> Model Class Initialized
INFO - 2018-03-26 16:40:52 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:40:52 --> Model Class Initialized
INFO - 2018-03-26 16:40:52 --> Final output sent to browser
DEBUG - 2018-03-26 16:40:52 --> Total execution time: 1.2748
INFO - 2018-03-26 11:10:52 --> Config Class Initialized
INFO - 2018-03-26 11:10:52 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:10:52 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:10:52 --> Utf8 Class Initialized
INFO - 2018-03-26 11:10:52 --> URI Class Initialized
INFO - 2018-03-26 11:10:52 --> Router Class Initialized
INFO - 2018-03-26 11:10:52 --> Output Class Initialized
INFO - 2018-03-26 11:10:52 --> Security Class Initialized
DEBUG - 2018-03-26 11:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:10:52 --> Input Class Initialized
INFO - 2018-03-26 11:10:52 --> Language Class Initialized
INFO - 2018-03-26 11:10:53 --> Language Class Initialized
INFO - 2018-03-26 11:10:53 --> Config Class Initialized
INFO - 2018-03-26 11:10:53 --> Loader Class Initialized
INFO - 2018-03-26 16:40:53 --> Helper loaded: url_helper
INFO - 2018-03-26 16:40:53 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:40:53 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:40:53 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:40:53 --> Helper loaded: users_helper
INFO - 2018-03-26 16:40:53 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:40:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:40:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:40:53 --> Helper loaded: form_helper
INFO - 2018-03-26 16:40:53 --> Form Validation Class Initialized
INFO - 2018-03-26 16:40:53 --> Controller Class Initialized
INFO - 2018-03-26 16:40:54 --> Model Class Initialized
INFO - 2018-03-26 16:40:54 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:40:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:40:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:40:54 --> Model Class Initialized
INFO - 2018-03-26 16:40:54 --> Model Class Initialized
INFO - 2018-03-26 16:40:54 --> Model Class Initialized
INFO - 2018-03-26 16:40:54 --> Model Class Initialized
INFO - 2018-03-26 16:40:54 --> Model Class Initialized
INFO - 2018-03-26 16:40:54 --> Model Class Initialized
INFO - 2018-03-26 16:40:54 --> Model Class Initialized
INFO - 2018-03-26 16:40:54 --> Model Class Initialized
INFO - 2018-03-26 16:40:54 --> Model Class Initialized
INFO - 2018-03-26 16:40:54 --> Model Class Initialized
INFO - 2018-03-26 16:40:54 --> Model Class Initialized
INFO - 2018-03-26 16:40:54 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:40:54 --> Model Class Initialized
INFO - 2018-03-26 16:40:54 --> Final output sent to browser
DEBUG - 2018-03-26 16:40:54 --> Total execution time: 2.1194
INFO - 2018-03-26 11:10:54 --> Config Class Initialized
INFO - 2018-03-26 11:10:54 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:10:54 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:10:54 --> Utf8 Class Initialized
INFO - 2018-03-26 11:10:54 --> URI Class Initialized
INFO - 2018-03-26 11:10:55 --> Router Class Initialized
INFO - 2018-03-26 11:10:55 --> Output Class Initialized
INFO - 2018-03-26 11:10:55 --> Security Class Initialized
DEBUG - 2018-03-26 11:10:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:10:55 --> Input Class Initialized
INFO - 2018-03-26 11:10:55 --> Language Class Initialized
INFO - 2018-03-26 11:10:56 --> Language Class Initialized
INFO - 2018-03-26 11:10:56 --> Config Class Initialized
INFO - 2018-03-26 11:10:56 --> Loader Class Initialized
INFO - 2018-03-26 16:40:56 --> Helper loaded: url_helper
INFO - 2018-03-26 16:40:56 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:40:56 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:40:56 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:40:56 --> Helper loaded: users_helper
INFO - 2018-03-26 16:40:57 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:40:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:40:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:40:57 --> Helper loaded: form_helper
INFO - 2018-03-26 16:40:57 --> Form Validation Class Initialized
INFO - 2018-03-26 16:40:57 --> Controller Class Initialized
INFO - 2018-03-26 16:40:57 --> Model Class Initialized
INFO - 2018-03-26 16:40:57 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:40:57 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:40:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:40:57 --> Model Class Initialized
INFO - 2018-03-26 16:40:57 --> Model Class Initialized
INFO - 2018-03-26 16:40:57 --> Model Class Initialized
INFO - 2018-03-26 16:40:57 --> Model Class Initialized
INFO - 2018-03-26 16:40:57 --> Model Class Initialized
INFO - 2018-03-26 16:40:57 --> Model Class Initialized
INFO - 2018-03-26 16:40:57 --> Model Class Initialized
INFO - 2018-03-26 16:40:57 --> Model Class Initialized
INFO - 2018-03-26 16:40:57 --> Model Class Initialized
INFO - 2018-03-26 16:40:57 --> Model Class Initialized
INFO - 2018-03-26 16:40:57 --> Model Class Initialized
INFO - 2018-03-26 16:40:57 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:40:57 --> Model Class Initialized
INFO - 2018-03-26 16:40:57 --> Final output sent to browser
DEBUG - 2018-03-26 16:40:57 --> Total execution time: 3.1224
INFO - 2018-03-26 11:11:10 --> Config Class Initialized
INFO - 2018-03-26 11:11:10 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:11:10 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:11:10 --> Utf8 Class Initialized
INFO - 2018-03-26 11:11:10 --> URI Class Initialized
INFO - 2018-03-26 11:11:10 --> Router Class Initialized
INFO - 2018-03-26 11:11:11 --> Output Class Initialized
INFO - 2018-03-26 11:11:11 --> Security Class Initialized
DEBUG - 2018-03-26 11:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:11:11 --> Input Class Initialized
INFO - 2018-03-26 11:11:11 --> Language Class Initialized
INFO - 2018-03-26 11:11:12 --> Language Class Initialized
INFO - 2018-03-26 11:11:12 --> Config Class Initialized
INFO - 2018-03-26 11:11:12 --> Loader Class Initialized
INFO - 2018-03-26 16:41:12 --> Helper loaded: url_helper
INFO - 2018-03-26 16:41:12 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:41:12 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:41:12 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:41:12 --> Helper loaded: users_helper
INFO - 2018-03-26 16:41:13 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:41:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:41:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:41:13 --> Helper loaded: form_helper
INFO - 2018-03-26 16:41:13 --> Form Validation Class Initialized
INFO - 2018-03-26 16:41:13 --> Controller Class Initialized
INFO - 2018-03-26 16:41:13 --> Model Class Initialized
INFO - 2018-03-26 16:41:13 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:41:13 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:41:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:41:13 --> Model Class Initialized
INFO - 2018-03-26 16:41:13 --> Model Class Initialized
INFO - 2018-03-26 16:41:13 --> Model Class Initialized
INFO - 2018-03-26 16:41:13 --> Model Class Initialized
INFO - 2018-03-26 16:41:13 --> Model Class Initialized
INFO - 2018-03-26 16:41:13 --> Model Class Initialized
INFO - 2018-03-26 16:41:13 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-26 16:41:13 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-26 16:41:13 --> Final output sent to browser
DEBUG - 2018-03-26 16:41:13 --> Total execution time: 3.6305
INFO - 2018-03-26 11:11:14 --> Config Class Initialized
INFO - 2018-03-26 11:11:14 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:11:14 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:11:14 --> Utf8 Class Initialized
INFO - 2018-03-26 11:11:14 --> URI Class Initialized
INFO - 2018-03-26 11:11:14 --> Router Class Initialized
INFO - 2018-03-26 11:11:14 --> Output Class Initialized
INFO - 2018-03-26 11:11:14 --> Security Class Initialized
DEBUG - 2018-03-26 11:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:11:14 --> Input Class Initialized
INFO - 2018-03-26 11:11:14 --> Language Class Initialized
INFO - 2018-03-26 11:11:14 --> Language Class Initialized
INFO - 2018-03-26 11:11:14 --> Config Class Initialized
INFO - 2018-03-26 11:11:14 --> Loader Class Initialized
INFO - 2018-03-26 16:41:14 --> Helper loaded: url_helper
INFO - 2018-03-26 16:41:14 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:41:14 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:41:14 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:41:14 --> Helper loaded: users_helper
INFO - 2018-03-26 16:41:14 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:41:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:41:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:41:14 --> Helper loaded: form_helper
INFO - 2018-03-26 16:41:14 --> Form Validation Class Initialized
INFO - 2018-03-26 16:41:14 --> Controller Class Initialized
INFO - 2018-03-26 16:41:14 --> Model Class Initialized
INFO - 2018-03-26 16:41:14 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:41:14 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:41:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:41:14 --> Model Class Initialized
INFO - 2018-03-26 16:41:14 --> Model Class Initialized
INFO - 2018-03-26 16:41:14 --> Model Class Initialized
INFO - 2018-03-26 16:41:14 --> Model Class Initialized
INFO - 2018-03-26 16:41:14 --> Model Class Initialized
INFO - 2018-03-26 16:41:14 --> Model Class Initialized
INFO - 2018-03-26 16:41:14 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-26 16:41:14 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-26 16:41:14 --> Final output sent to browser
DEBUG - 2018-03-26 16:41:14 --> Total execution time: 0.6596
INFO - 2018-03-26 11:11:18 --> Config Class Initialized
INFO - 2018-03-26 11:11:18 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:11:18 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:11:18 --> Utf8 Class Initialized
INFO - 2018-03-26 11:11:18 --> URI Class Initialized
INFO - 2018-03-26 11:11:18 --> Router Class Initialized
INFO - 2018-03-26 11:11:18 --> Output Class Initialized
INFO - 2018-03-26 11:11:18 --> Security Class Initialized
DEBUG - 2018-03-26 11:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:11:18 --> Input Class Initialized
INFO - 2018-03-26 11:11:18 --> Language Class Initialized
INFO - 2018-03-26 11:11:19 --> Language Class Initialized
INFO - 2018-03-26 11:11:19 --> Config Class Initialized
INFO - 2018-03-26 11:11:19 --> Loader Class Initialized
INFO - 2018-03-26 16:41:19 --> Helper loaded: url_helper
INFO - 2018-03-26 11:11:19 --> Config Class Initialized
INFO - 2018-03-26 11:11:19 --> Hooks Class Initialized
INFO - 2018-03-26 16:41:19 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:41:19 --> Helper loaded: settings_helper
INFO - 2018-03-26 11:11:19 --> Config Class Initialized
INFO - 2018-03-26 11:11:19 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:11:19 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:11:19 --> Utf8 Class Initialized
INFO - 2018-03-26 16:41:19 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:41:19 --> Helper loaded: users_helper
INFO - 2018-03-26 11:11:19 --> URI Class Initialized
DEBUG - 2018-03-26 11:11:19 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:11:19 --> Utf8 Class Initialized
INFO - 2018-03-26 11:11:19 --> Router Class Initialized
INFO - 2018-03-26 11:11:19 --> Output Class Initialized
INFO - 2018-03-26 11:11:19 --> Security Class Initialized
DEBUG - 2018-03-26 11:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:11:19 --> Input Class Initialized
INFO - 2018-03-26 11:11:19 --> Language Class Initialized
INFO - 2018-03-26 11:11:19 --> Config Class Initialized
INFO - 2018-03-26 11:11:19 --> Hooks Class Initialized
INFO - 2018-03-26 11:11:19 --> URI Class Initialized
INFO - 2018-03-26 11:11:19 --> Config Class Initialized
INFO - 2018-03-26 11:11:19 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:11:19 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:11:19 --> Utf8 Class Initialized
INFO - 2018-03-26 11:11:19 --> Router Class Initialized
INFO - 2018-03-26 11:11:19 --> URI Class Initialized
INFO - 2018-03-26 11:11:19 --> Output Class Initialized
INFO - 2018-03-26 11:11:19 --> Language Class Initialized
INFO - 2018-03-26 11:11:19 --> Config Class Initialized
INFO - 2018-03-26 11:11:19 --> Loader Class Initialized
INFO - 2018-03-26 11:11:19 --> Router Class Initialized
DEBUG - 2018-03-26 11:11:19 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:11:19 --> Utf8 Class Initialized
INFO - 2018-03-26 16:41:19 --> Helper loaded: url_helper
INFO - 2018-03-26 11:11:19 --> Security Class Initialized
INFO - 2018-03-26 16:41:19 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:41:19 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:41:19 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:41:19 --> Helper loaded: users_helper
INFO - 2018-03-26 11:11:19 --> URI Class Initialized
INFO - 2018-03-26 11:11:19 --> Router Class Initialized
INFO - 2018-03-26 11:11:19 --> Output Class Initialized
DEBUG - 2018-03-26 11:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:11:19 --> Input Class Initialized
INFO - 2018-03-26 11:11:19 --> Language Class Initialized
INFO - 2018-03-26 16:41:19 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:41:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:41:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:11:20 --> Security Class Initialized
INFO - 2018-03-26 11:11:20 --> Output Class Initialized
INFO - 2018-03-26 16:41:20 --> Helper loaded: form_helper
INFO - 2018-03-26 16:41:20 --> Form Validation Class Initialized
INFO - 2018-03-26 16:41:20 --> Controller Class Initialized
INFO - 2018-03-26 16:41:20 --> Model Class Initialized
INFO - 2018-03-26 16:41:20 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:41:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:41:20 --> Language file loaded: language/english/rest_controller_lang.php
DEBUG - 2018-03-26 11:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:11:20 --> Input Class Initialized
INFO - 2018-03-26 16:41:20 --> Model Class Initialized
INFO - 2018-03-26 16:41:20 --> Model Class Initialized
INFO - 2018-03-26 16:41:20 --> Model Class Initialized
INFO - 2018-03-26 16:41:20 --> Model Class Initialized
INFO - 2018-03-26 16:41:20 --> Model Class Initialized
INFO - 2018-03-26 16:41:20 --> Model Class Initialized
INFO - 2018-03-26 16:41:20 --> Model Class Initialized
INFO - 2018-03-26 16:41:20 --> Model Class Initialized
INFO - 2018-03-26 16:41:20 --> Model Class Initialized
INFO - 2018-03-26 16:41:20 --> Model Class Initialized
INFO - 2018-03-26 16:41:20 --> Model Class Initialized
INFO - 2018-03-26 16:41:20 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:41:20 --> Model Class Initialized
INFO - 2018-03-26 11:11:20 --> Language Class Initialized
INFO - 2018-03-26 16:41:20 --> Final output sent to browser
DEBUG - 2018-03-26 16:41:20 --> Total execution time: 0.5676
INFO - 2018-03-26 11:11:20 --> Security Class Initialized
DEBUG - 2018-03-26 11:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:11:20 --> Input Class Initialized
INFO - 2018-03-26 11:11:20 --> Language Class Initialized
INFO - 2018-03-26 16:41:20 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:41:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:41:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:41:20 --> Helper loaded: form_helper
INFO - 2018-03-26 16:41:20 --> Form Validation Class Initialized
INFO - 2018-03-26 16:41:20 --> Controller Class Initialized
INFO - 2018-03-26 16:41:20 --> Model Class Initialized
INFO - 2018-03-26 16:41:20 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:41:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:41:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:41:20 --> Model Class Initialized
INFO - 2018-03-26 16:41:20 --> Model Class Initialized
INFO - 2018-03-26 16:41:20 --> Model Class Initialized
INFO - 2018-03-26 16:41:20 --> Model Class Initialized
INFO - 2018-03-26 16:41:20 --> Model Class Initialized
INFO - 2018-03-26 16:41:20 --> Model Class Initialized
INFO - 2018-03-26 16:41:20 --> Model Class Initialized
INFO - 2018-03-26 16:41:20 --> Model Class Initialized
INFO - 2018-03-26 16:41:20 --> Model Class Initialized
INFO - 2018-03-26 16:41:20 --> Model Class Initialized
INFO - 2018-03-26 16:41:20 --> Model Class Initialized
INFO - 2018-03-26 16:41:20 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:41:20 --> Model Class Initialized
INFO - 2018-03-26 16:41:20 --> Final output sent to browser
DEBUG - 2018-03-26 16:41:20 --> Total execution time: 2.3035
INFO - 2018-03-26 11:11:20 --> Language Class Initialized
INFO - 2018-03-26 11:11:20 --> Config Class Initialized
INFO - 2018-03-26 11:11:20 --> Loader Class Initialized
INFO - 2018-03-26 16:41:20 --> Helper loaded: url_helper
INFO - 2018-03-26 11:11:20 --> Config Class Initialized
INFO - 2018-03-26 11:11:20 --> Hooks Class Initialized
INFO - 2018-03-26 11:11:20 --> Language Class Initialized
INFO - 2018-03-26 11:11:20 --> Config Class Initialized
INFO - 2018-03-26 11:11:20 --> Loader Class Initialized
DEBUG - 2018-03-26 11:11:20 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:11:20 --> Utf8 Class Initialized
INFO - 2018-03-26 16:41:20 --> Helper loaded: notification_helper
INFO - 2018-03-26 11:11:20 --> URI Class Initialized
INFO - 2018-03-26 16:41:20 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:41:20 --> Helper loaded: url_helper
INFO - 2018-03-26 16:41:20 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:41:20 --> Helper loaded: users_helper
INFO - 2018-03-26 16:41:20 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:41:20 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:41:20 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:41:20 --> Helper loaded: users_helper
INFO - 2018-03-26 16:41:20 --> Database Driver Class Initialized
INFO - 2018-03-26 11:11:20 --> Router Class Initialized
DEBUG - 2018-03-26 16:41:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:41:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:41:20 --> Database Driver Class Initialized
INFO - 2018-03-26 16:41:20 --> Helper loaded: form_helper
INFO - 2018-03-26 16:41:20 --> Form Validation Class Initialized
INFO - 2018-03-26 16:41:20 --> Controller Class Initialized
DEBUG - 2018-03-26 16:41:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:41:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:41:20 --> Helper loaded: form_helper
INFO - 2018-03-26 16:41:20 --> Form Validation Class Initialized
INFO - 2018-03-26 16:41:20 --> Controller Class Initialized
INFO - 2018-03-26 16:41:20 --> Model Class Initialized
INFO - 2018-03-26 16:41:20 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:41:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:41:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 11:11:20 --> Output Class Initialized
INFO - 2018-03-26 16:41:21 --> Model Class Initialized
INFO - 2018-03-26 16:41:21 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:41:21 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:41:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:41:21 --> Model Class Initialized
INFO - 2018-03-26 16:41:21 --> Model Class Initialized
INFO - 2018-03-26 16:41:21 --> Model Class Initialized
INFO - 2018-03-26 16:41:21 --> Model Class Initialized
INFO - 2018-03-26 16:41:21 --> Model Class Initialized
INFO - 2018-03-26 16:41:21 --> Model Class Initialized
INFO - 2018-03-26 16:41:21 --> Model Class Initialized
INFO - 2018-03-26 16:41:21 --> Model Class Initialized
INFO - 2018-03-26 16:41:21 --> Model Class Initialized
INFO - 2018-03-26 16:41:21 --> Model Class Initialized
INFO - 2018-03-26 16:41:21 --> Model Class Initialized
INFO - 2018-03-26 16:41:21 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:41:21 --> Model Class Initialized
INFO - 2018-03-26 16:41:21 --> Final output sent to browser
DEBUG - 2018-03-26 16:41:21 --> Total execution time: 1.6170
INFO - 2018-03-26 16:41:21 --> Model Class Initialized
INFO - 2018-03-26 16:41:21 --> Model Class Initialized
INFO - 2018-03-26 11:11:21 --> Security Class Initialized
INFO - 2018-03-26 16:41:21 --> Model Class Initialized
INFO - 2018-03-26 16:41:21 --> Model Class Initialized
INFO - 2018-03-26 16:41:21 --> Model Class Initialized
INFO - 2018-03-26 16:41:21 --> Model Class Initialized
INFO - 2018-03-26 16:41:21 --> Model Class Initialized
INFO - 2018-03-26 16:41:21 --> Model Class Initialized
INFO - 2018-03-26 16:41:21 --> Model Class Initialized
INFO - 2018-03-26 16:41:21 --> Model Class Initialized
INFO - 2018-03-26 11:11:21 --> Language Class Initialized
INFO - 2018-03-26 11:11:21 --> Config Class Initialized
INFO - 2018-03-26 11:11:21 --> Loader Class Initialized
INFO - 2018-03-26 16:41:21 --> Model Class Initialized
INFO - 2018-03-26 16:41:21 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:41:21 --> Model Class Initialized
DEBUG - 2018-03-26 11:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:11:21 --> Input Class Initialized
INFO - 2018-03-26 11:11:21 --> Language Class Initialized
INFO - 2018-03-26 16:41:21 --> Final output sent to browser
DEBUG - 2018-03-26 16:41:21 --> Total execution time: 2.1652
INFO - 2018-03-26 16:41:21 --> Helper loaded: url_helper
INFO - 2018-03-26 16:41:21 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:41:21 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:41:21 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:41:21 --> Helper loaded: users_helper
INFO - 2018-03-26 11:11:21 --> Language Class Initialized
INFO - 2018-03-26 11:11:21 --> Config Class Initialized
INFO - 2018-03-26 11:11:21 --> Loader Class Initialized
INFO - 2018-03-26 16:41:21 --> Helper loaded: url_helper
INFO - 2018-03-26 16:41:21 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:41:21 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:41:21 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:41:21 --> Helper loaded: users_helper
INFO - 2018-03-26 16:41:21 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:41:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:41:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:41:21 --> Database Driver Class Initialized
INFO - 2018-03-26 16:41:21 --> Helper loaded: form_helper
INFO - 2018-03-26 16:41:21 --> Form Validation Class Initialized
INFO - 2018-03-26 16:41:21 --> Controller Class Initialized
INFO - 2018-03-26 16:41:21 --> Model Class Initialized
INFO - 2018-03-26 16:41:21 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:41:21 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:41:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:41:21 --> Model Class Initialized
INFO - 2018-03-26 16:41:21 --> Model Class Initialized
INFO - 2018-03-26 16:41:21 --> Model Class Initialized
INFO - 2018-03-26 16:41:21 --> Model Class Initialized
INFO - 2018-03-26 16:41:21 --> Model Class Initialized
INFO - 2018-03-26 16:41:21 --> Model Class Initialized
INFO - 2018-03-26 16:41:21 --> Model Class Initialized
INFO - 2018-03-26 16:41:21 --> Model Class Initialized
INFO - 2018-03-26 16:41:21 --> Model Class Initialized
INFO - 2018-03-26 16:41:21 --> Model Class Initialized
INFO - 2018-03-26 16:41:21 --> Model Class Initialized
INFO - 2018-03-26 16:41:21 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:41:21 --> Model Class Initialized
INFO - 2018-03-26 16:41:21 --> Final output sent to browser
DEBUG - 2018-03-26 16:41:21 --> Total execution time: 1.3542
DEBUG - 2018-03-26 16:41:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:41:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:41:22 --> Helper loaded: form_helper
INFO - 2018-03-26 16:41:22 --> Form Validation Class Initialized
INFO - 2018-03-26 16:41:22 --> Controller Class Initialized
INFO - 2018-03-26 16:41:23 --> Model Class Initialized
INFO - 2018-03-26 16:41:23 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:41:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:41:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:41:24 --> Model Class Initialized
INFO - 2018-03-26 16:41:24 --> Model Class Initialized
INFO - 2018-03-26 16:41:24 --> Model Class Initialized
INFO - 2018-03-26 16:41:24 --> Model Class Initialized
INFO - 2018-03-26 16:41:24 --> Model Class Initialized
INFO - 2018-03-26 16:41:24 --> Model Class Initialized
INFO - 2018-03-26 16:41:24 --> Model Class Initialized
INFO - 2018-03-26 16:41:24 --> Model Class Initialized
INFO - 2018-03-26 16:41:24 --> Model Class Initialized
INFO - 2018-03-26 16:41:24 --> Model Class Initialized
INFO - 2018-03-26 16:41:25 --> Model Class Initialized
INFO - 2018-03-26 16:41:25 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:41:25 --> Model Class Initialized
INFO - 2018-03-26 16:41:25 --> Final output sent to browser
DEBUG - 2018-03-26 16:41:25 --> Total execution time: 5.6369
INFO - 2018-03-26 11:13:53 --> Config Class Initialized
INFO - 2018-03-26 11:13:53 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:13:53 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:13:53 --> Utf8 Class Initialized
INFO - 2018-03-26 11:13:53 --> URI Class Initialized
INFO - 2018-03-26 11:13:53 --> Router Class Initialized
INFO - 2018-03-26 11:13:53 --> Output Class Initialized
INFO - 2018-03-26 11:13:53 --> Security Class Initialized
DEBUG - 2018-03-26 11:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:13:53 --> Input Class Initialized
INFO - 2018-03-26 11:13:53 --> Language Class Initialized
INFO - 2018-03-26 11:13:53 --> Language Class Initialized
INFO - 2018-03-26 11:13:53 --> Config Class Initialized
INFO - 2018-03-26 11:13:53 --> Loader Class Initialized
INFO - 2018-03-26 16:43:53 --> Helper loaded: url_helper
INFO - 2018-03-26 16:43:53 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:43:53 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:43:53 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:43:53 --> Helper loaded: users_helper
INFO - 2018-03-26 16:43:53 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:43:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:43:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:43:53 --> Helper loaded: form_helper
INFO - 2018-03-26 16:43:53 --> Form Validation Class Initialized
INFO - 2018-03-26 16:43:53 --> Controller Class Initialized
INFO - 2018-03-26 16:43:53 --> Model Class Initialized
INFO - 2018-03-26 16:43:53 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:43:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:43:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:43:53 --> Model Class Initialized
INFO - 2018-03-26 16:43:53 --> Model Class Initialized
INFO - 2018-03-26 16:43:53 --> Model Class Initialized
INFO - 2018-03-26 16:43:53 --> Model Class Initialized
INFO - 2018-03-26 16:43:53 --> Model Class Initialized
INFO - 2018-03-26 16:43:53 --> Model Class Initialized
INFO - 2018-03-26 16:43:53 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:43:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-26 16:43:53 --> Final output sent to browser
DEBUG - 2018-03-26 16:43:53 --> Total execution time: 0.1090
INFO - 2018-03-26 11:13:56 --> Config Class Initialized
INFO - 2018-03-26 11:13:56 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:13:56 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:13:56 --> Utf8 Class Initialized
INFO - 2018-03-26 11:13:56 --> URI Class Initialized
INFO - 2018-03-26 11:13:56 --> Router Class Initialized
INFO - 2018-03-26 11:13:56 --> Output Class Initialized
INFO - 2018-03-26 11:13:56 --> Security Class Initialized
DEBUG - 2018-03-26 11:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:13:56 --> Input Class Initialized
INFO - 2018-03-26 11:13:56 --> Language Class Initialized
INFO - 2018-03-26 11:13:56 --> Language Class Initialized
INFO - 2018-03-26 11:13:56 --> Config Class Initialized
INFO - 2018-03-26 11:13:56 --> Loader Class Initialized
INFO - 2018-03-26 16:43:56 --> Helper loaded: url_helper
INFO - 2018-03-26 16:43:56 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:43:56 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:43:56 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:43:56 --> Helper loaded: users_helper
INFO - 2018-03-26 16:43:56 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:43:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:43:56 --> Helper loaded: form_helper
INFO - 2018-03-26 16:43:56 --> Form Validation Class Initialized
INFO - 2018-03-26 16:43:56 --> Controller Class Initialized
INFO - 2018-03-26 16:43:56 --> Model Class Initialized
INFO - 2018-03-26 16:43:56 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:43:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:43:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:43:56 --> Model Class Initialized
INFO - 2018-03-26 16:43:56 --> Model Class Initialized
INFO - 2018-03-26 16:43:56 --> Model Class Initialized
INFO - 2018-03-26 16:43:56 --> Model Class Initialized
INFO - 2018-03-26 16:43:56 --> Model Class Initialized
INFO - 2018-03-26 16:43:56 --> Model Class Initialized
INFO - 2018-03-26 16:43:56 --> Model Class Initialized
INFO - 2018-03-26 16:43:56 --> Model Class Initialized
INFO - 2018-03-26 16:43:56 --> Model Class Initialized
INFO - 2018-03-26 16:43:56 --> Model Class Initialized
INFO - 2018-03-26 16:43:56 --> Model Class Initialized
INFO - 2018-03-26 16:43:56 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:43:56 --> Model Class Initialized
INFO - 2018-03-26 16:43:56 --> Final output sent to browser
DEBUG - 2018-03-26 16:43:56 --> Total execution time: 0.1309
INFO - 2018-03-26 11:13:57 --> Config Class Initialized
INFO - 2018-03-26 11:13:57 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:13:57 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:13:57 --> Utf8 Class Initialized
INFO - 2018-03-26 11:13:58 --> URI Class Initialized
INFO - 2018-03-26 11:13:58 --> Config Class Initialized
INFO - 2018-03-26 11:13:58 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:13:58 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:13:58 --> Utf8 Class Initialized
INFO - 2018-03-26 11:13:58 --> URI Class Initialized
INFO - 2018-03-26 11:13:58 --> Router Class Initialized
INFO - 2018-03-26 11:13:58 --> Router Class Initialized
INFO - 2018-03-26 11:13:58 --> Output Class Initialized
INFO - 2018-03-26 11:13:58 --> Output Class Initialized
INFO - 2018-03-26 11:13:58 --> Security Class Initialized
INFO - 2018-03-26 11:13:58 --> Security Class Initialized
DEBUG - 2018-03-26 11:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:13:58 --> Input Class Initialized
INFO - 2018-03-26 11:13:58 --> Language Class Initialized
DEBUG - 2018-03-26 11:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:13:58 --> Input Class Initialized
INFO - 2018-03-26 11:13:58 --> Language Class Initialized
INFO - 2018-03-26 11:13:59 --> Language Class Initialized
INFO - 2018-03-26 11:13:59 --> Config Class Initialized
INFO - 2018-03-26 11:13:59 --> Loader Class Initialized
INFO - 2018-03-26 16:43:59 --> Helper loaded: url_helper
INFO - 2018-03-26 16:43:59 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:43:59 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:43:59 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:43:59 --> Helper loaded: users_helper
INFO - 2018-03-26 16:43:59 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:43:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:43:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:14:00 --> Language Class Initialized
INFO - 2018-03-26 11:14:00 --> Config Class Initialized
INFO - 2018-03-26 11:14:00 --> Loader Class Initialized
INFO - 2018-03-26 16:44:00 --> Helper loaded: url_helper
INFO - 2018-03-26 16:44:00 --> Helper loaded: form_helper
INFO - 2018-03-26 16:44:00 --> Form Validation Class Initialized
INFO - 2018-03-26 16:44:00 --> Controller Class Initialized
INFO - 2018-03-26 16:44:00 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:44:00 --> Model Class Initialized
INFO - 2018-03-26 16:44:00 --> Helper loaded: inflector_helper
INFO - 2018-03-26 16:44:00 --> Helper loaded: settings_helper
DEBUG - 2018-03-26 16:44:00 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:44:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:44:00 --> Model Class Initialized
INFO - 2018-03-26 16:44:00 --> Model Class Initialized
INFO - 2018-03-26 16:44:00 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:44:00 --> Model Class Initialized
INFO - 2018-03-26 16:44:00 --> Model Class Initialized
INFO - 2018-03-26 16:44:00 --> Model Class Initialized
INFO - 2018-03-26 16:44:00 --> Model Class Initialized
INFO - 2018-03-26 16:44:00 --> Model Class Initialized
INFO - 2018-03-26 16:44:00 --> Helper loaded: users_helper
INFO - 2018-03-26 16:44:00 --> Model Class Initialized
INFO - 2018-03-26 16:44:00 --> Model Class Initialized
INFO - 2018-03-26 16:44:00 --> Model Class Initialized
INFO - 2018-03-26 16:44:00 --> Model Class Initialized
INFO - 2018-03-26 16:44:00 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:44:00 --> Model Class Initialized
INFO - 2018-03-26 16:44:00 --> Final output sent to browser
DEBUG - 2018-03-26 16:44:00 --> Total execution time: 2.6863
INFO - 2018-03-26 16:44:02 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:44:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:44:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:44:03 --> Helper loaded: form_helper
INFO - 2018-03-26 16:44:03 --> Form Validation Class Initialized
INFO - 2018-03-26 16:44:03 --> Controller Class Initialized
INFO - 2018-03-26 16:44:05 --> Model Class Initialized
INFO - 2018-03-26 16:44:05 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:44:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:44:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:44:05 --> Model Class Initialized
INFO - 2018-03-26 16:44:05 --> Model Class Initialized
INFO - 2018-03-26 16:44:06 --> Model Class Initialized
INFO - 2018-03-26 16:44:06 --> Model Class Initialized
INFO - 2018-03-26 16:44:06 --> Model Class Initialized
INFO - 2018-03-26 16:44:06 --> Model Class Initialized
INFO - 2018-03-26 16:44:06 --> Model Class Initialized
INFO - 2018-03-26 16:44:06 --> Model Class Initialized
INFO - 2018-03-26 16:44:06 --> Model Class Initialized
INFO - 2018-03-26 16:44:06 --> Model Class Initialized
INFO - 2018-03-26 16:44:06 --> Model Class Initialized
INFO - 2018-03-26 16:44:06 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:44:06 --> Model Class Initialized
INFO - 2018-03-26 16:44:06 --> Final output sent to browser
DEBUG - 2018-03-26 16:44:06 --> Total execution time: 9.5249
INFO - 2018-03-26 11:19:04 --> Config Class Initialized
INFO - 2018-03-26 11:19:04 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:19:04 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:19:04 --> Utf8 Class Initialized
INFO - 2018-03-26 11:19:04 --> URI Class Initialized
INFO - 2018-03-26 11:19:04 --> Router Class Initialized
INFO - 2018-03-26 11:19:04 --> Output Class Initialized
INFO - 2018-03-26 11:19:04 --> Security Class Initialized
DEBUG - 2018-03-26 11:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:19:04 --> Input Class Initialized
INFO - 2018-03-26 11:19:04 --> Language Class Initialized
INFO - 2018-03-26 11:19:04 --> Language Class Initialized
INFO - 2018-03-26 11:19:04 --> Config Class Initialized
INFO - 2018-03-26 11:19:04 --> Loader Class Initialized
INFO - 2018-03-26 16:49:04 --> Helper loaded: url_helper
INFO - 2018-03-26 16:49:04 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:49:04 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:49:04 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:49:04 --> Helper loaded: users_helper
INFO - 2018-03-26 16:49:04 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:49:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:49:04 --> Helper loaded: form_helper
INFO - 2018-03-26 16:49:04 --> Form Validation Class Initialized
INFO - 2018-03-26 16:49:04 --> Controller Class Initialized
INFO - 2018-03-26 16:49:04 --> Model Class Initialized
INFO - 2018-03-26 16:49:04 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:49:04 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:49:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:49:04 --> Model Class Initialized
INFO - 2018-03-26 16:49:04 --> Model Class Initialized
INFO - 2018-03-26 16:49:04 --> Model Class Initialized
INFO - 2018-03-26 16:49:04 --> Model Class Initialized
INFO - 2018-03-26 16:49:04 --> Model Class Initialized
INFO - 2018-03-26 16:49:04 --> Model Class Initialized
INFO - 2018-03-26 16:49:04 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:49:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-26 16:49:04 --> Final output sent to browser
DEBUG - 2018-03-26 16:49:04 --> Total execution time: 0.2150
INFO - 2018-03-26 11:19:05 --> Config Class Initialized
INFO - 2018-03-26 11:19:05 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:19:05 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:19:05 --> Utf8 Class Initialized
INFO - 2018-03-26 11:19:05 --> URI Class Initialized
INFO - 2018-03-26 11:19:05 --> Router Class Initialized
INFO - 2018-03-26 11:19:05 --> Output Class Initialized
INFO - 2018-03-26 11:19:05 --> Security Class Initialized
DEBUG - 2018-03-26 11:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:19:05 --> Input Class Initialized
INFO - 2018-03-26 11:19:05 --> Language Class Initialized
INFO - 2018-03-26 11:19:05 --> Language Class Initialized
INFO - 2018-03-26 11:19:05 --> Config Class Initialized
INFO - 2018-03-26 11:19:05 --> Loader Class Initialized
INFO - 2018-03-26 16:49:05 --> Helper loaded: url_helper
INFO - 2018-03-26 16:49:05 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:49:05 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:49:05 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:49:05 --> Helper loaded: users_helper
INFO - 2018-03-26 16:49:05 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:49:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:49:05 --> Helper loaded: form_helper
INFO - 2018-03-26 16:49:05 --> Form Validation Class Initialized
INFO - 2018-03-26 16:49:05 --> Controller Class Initialized
INFO - 2018-03-26 16:49:05 --> Model Class Initialized
INFO - 2018-03-26 16:49:05 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:49:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:49:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:49:05 --> Model Class Initialized
INFO - 2018-03-26 16:49:05 --> Model Class Initialized
INFO - 2018-03-26 16:49:05 --> Model Class Initialized
INFO - 2018-03-26 16:49:05 --> Model Class Initialized
INFO - 2018-03-26 16:49:05 --> Model Class Initialized
INFO - 2018-03-26 16:49:05 --> Model Class Initialized
INFO - 2018-03-26 16:49:05 --> Model Class Initialized
INFO - 2018-03-26 16:49:05 --> Model Class Initialized
INFO - 2018-03-26 16:49:05 --> Model Class Initialized
INFO - 2018-03-26 16:49:05 --> Model Class Initialized
INFO - 2018-03-26 16:49:05 --> Model Class Initialized
INFO - 2018-03-26 16:49:05 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:49:05 --> Model Class Initialized
INFO - 2018-03-26 16:49:05 --> Final output sent to browser
DEBUG - 2018-03-26 16:49:05 --> Total execution time: 0.2353
INFO - 2018-03-26 11:19:07 --> Config Class Initialized
INFO - 2018-03-26 11:19:07 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:19:07 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:19:07 --> Utf8 Class Initialized
INFO - 2018-03-26 11:19:07 --> URI Class Initialized
INFO - 2018-03-26 11:19:07 --> Router Class Initialized
INFO - 2018-03-26 11:19:07 --> Output Class Initialized
INFO - 2018-03-26 11:19:07 --> Security Class Initialized
DEBUG - 2018-03-26 11:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:19:07 --> Input Class Initialized
INFO - 2018-03-26 11:19:07 --> Language Class Initialized
INFO - 2018-03-26 11:19:07 --> Language Class Initialized
INFO - 2018-03-26 11:19:07 --> Config Class Initialized
INFO - 2018-03-26 11:19:07 --> Loader Class Initialized
INFO - 2018-03-26 16:49:07 --> Helper loaded: url_helper
INFO - 2018-03-26 16:49:07 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:49:07 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:49:07 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:49:07 --> Helper loaded: users_helper
INFO - 2018-03-26 16:49:07 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:49:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:49:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:49:07 --> Helper loaded: form_helper
INFO - 2018-03-26 16:49:07 --> Form Validation Class Initialized
INFO - 2018-03-26 16:49:07 --> Controller Class Initialized
INFO - 2018-03-26 16:49:07 --> Model Class Initialized
INFO - 2018-03-26 16:49:07 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:49:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:49:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:49:07 --> Model Class Initialized
INFO - 2018-03-26 16:49:07 --> Model Class Initialized
INFO - 2018-03-26 16:49:07 --> Model Class Initialized
INFO - 2018-03-26 16:49:07 --> Model Class Initialized
INFO - 2018-03-26 16:49:07 --> Model Class Initialized
INFO - 2018-03-26 16:49:07 --> Model Class Initialized
INFO - 2018-03-26 16:49:07 --> Model Class Initialized
INFO - 2018-03-26 16:49:07 --> Model Class Initialized
INFO - 2018-03-26 16:49:07 --> Model Class Initialized
INFO - 2018-03-26 16:49:07 --> Model Class Initialized
INFO - 2018-03-26 16:49:07 --> Model Class Initialized
INFO - 2018-03-26 16:49:07 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:49:07 --> Model Class Initialized
INFO - 2018-03-26 16:49:07 --> Final output sent to browser
DEBUG - 2018-03-26 16:49:07 --> Total execution time: 0.9565
INFO - 2018-03-26 11:19:08 --> Config Class Initialized
INFO - 2018-03-26 11:19:08 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:19:08 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:19:08 --> Utf8 Class Initialized
INFO - 2018-03-26 11:19:08 --> URI Class Initialized
INFO - 2018-03-26 11:19:08 --> Router Class Initialized
INFO - 2018-03-26 11:19:08 --> Output Class Initialized
INFO - 2018-03-26 11:19:08 --> Security Class Initialized
DEBUG - 2018-03-26 11:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:19:08 --> Input Class Initialized
INFO - 2018-03-26 11:19:08 --> Language Class Initialized
INFO - 2018-03-26 11:19:08 --> Language Class Initialized
INFO - 2018-03-26 11:19:08 --> Config Class Initialized
INFO - 2018-03-26 11:19:08 --> Loader Class Initialized
INFO - 2018-03-26 16:49:08 --> Helper loaded: url_helper
INFO - 2018-03-26 16:49:08 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:49:08 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:49:08 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:49:08 --> Helper loaded: users_helper
INFO - 2018-03-26 16:49:08 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:49:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:49:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:49:08 --> Helper loaded: form_helper
INFO - 2018-03-26 16:49:08 --> Form Validation Class Initialized
INFO - 2018-03-26 16:49:08 --> Controller Class Initialized
INFO - 2018-03-26 16:49:08 --> Model Class Initialized
INFO - 2018-03-26 16:49:08 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:49:08 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:49:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:49:08 --> Model Class Initialized
INFO - 2018-03-26 16:49:08 --> Model Class Initialized
INFO - 2018-03-26 16:49:08 --> Model Class Initialized
INFO - 2018-03-26 16:49:08 --> Model Class Initialized
INFO - 2018-03-26 16:49:08 --> Model Class Initialized
INFO - 2018-03-26 16:49:08 --> Model Class Initialized
INFO - 2018-03-26 16:49:08 --> Model Class Initialized
INFO - 2018-03-26 16:49:08 --> Model Class Initialized
INFO - 2018-03-26 16:49:08 --> Model Class Initialized
INFO - 2018-03-26 16:49:08 --> Model Class Initialized
INFO - 2018-03-26 16:49:08 --> Model Class Initialized
INFO - 2018-03-26 16:49:08 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 16:49:08 --> Model Class Initialized
INFO - 2018-03-26 16:49:08 --> Final output sent to browser
DEBUG - 2018-03-26 16:49:08 --> Total execution time: 0.4183
INFO - 2018-03-26 11:19:11 --> Config Class Initialized
INFO - 2018-03-26 11:19:11 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:19:11 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:19:11 --> Utf8 Class Initialized
INFO - 2018-03-26 11:19:11 --> URI Class Initialized
INFO - 2018-03-26 11:19:11 --> Router Class Initialized
INFO - 2018-03-26 11:19:11 --> Output Class Initialized
INFO - 2018-03-26 11:19:11 --> Security Class Initialized
DEBUG - 2018-03-26 11:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:19:11 --> Input Class Initialized
INFO - 2018-03-26 11:19:11 --> Language Class Initialized
INFO - 2018-03-26 11:19:12 --> Language Class Initialized
INFO - 2018-03-26 11:19:12 --> Config Class Initialized
INFO - 2018-03-26 11:19:12 --> Loader Class Initialized
INFO - 2018-03-26 16:49:12 --> Helper loaded: url_helper
INFO - 2018-03-26 16:49:12 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:49:12 --> Helper loaded: settings_helper
INFO - 2018-03-26 11:19:12 --> Config Class Initialized
INFO - 2018-03-26 11:19:12 --> Hooks Class Initialized
INFO - 2018-03-26 16:49:12 --> Helper loaded: permission_helper
DEBUG - 2018-03-26 11:19:12 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:19:12 --> Utf8 Class Initialized
INFO - 2018-03-26 11:19:12 --> URI Class Initialized
INFO - 2018-03-26 11:19:13 --> Router Class Initialized
INFO - 2018-03-26 11:19:13 --> Output Class Initialized
INFO - 2018-03-26 11:19:13 --> Security Class Initialized
INFO - 2018-03-26 16:49:13 --> Helper loaded: users_helper
DEBUG - 2018-03-26 11:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:19:13 --> Input Class Initialized
INFO - 2018-03-26 11:19:13 --> Language Class Initialized
INFO - 2018-03-26 16:49:13 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:49:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:49:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:49:13 --> Helper loaded: form_helper
INFO - 2018-03-26 16:49:13 --> Form Validation Class Initialized
INFO - 2018-03-26 16:49:13 --> Controller Class Initialized
INFO - 2018-03-26 16:49:13 --> Model Class Initialized
INFO - 2018-03-26 16:49:13 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:49:13 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:49:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:49:13 --> Model Class Initialized
INFO - 2018-03-26 16:49:13 --> Model Class Initialized
INFO - 2018-03-26 16:49:13 --> Model Class Initialized
INFO - 2018-03-26 16:49:13 --> Model Class Initialized
INFO - 2018-03-26 16:49:13 --> Model Class Initialized
INFO - 2018-03-26 16:49:13 --> Model Class Initialized
INFO - 2018-03-26 16:49:13 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-26 16:49:13 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-26 16:49:13 --> Final output sent to browser
DEBUG - 2018-03-26 16:49:13 --> Total execution time: 2.7416
INFO - 2018-03-26 11:19:14 --> Language Class Initialized
INFO - 2018-03-26 11:19:14 --> Config Class Initialized
INFO - 2018-03-26 11:19:14 --> Loader Class Initialized
INFO - 2018-03-26 16:49:14 --> Helper loaded: url_helper
INFO - 2018-03-26 16:49:14 --> Helper loaded: notification_helper
INFO - 2018-03-26 16:49:14 --> Helper loaded: settings_helper
INFO - 2018-03-26 16:49:14 --> Helper loaded: permission_helper
INFO - 2018-03-26 16:49:14 --> Helper loaded: users_helper
INFO - 2018-03-26 16:49:15 --> Database Driver Class Initialized
DEBUG - 2018-03-26 16:49:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 16:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 16:49:15 --> Helper loaded: form_helper
INFO - 2018-03-26 16:49:15 --> Form Validation Class Initialized
INFO - 2018-03-26 16:49:15 --> Controller Class Initialized
INFO - 2018-03-26 16:49:15 --> Model Class Initialized
INFO - 2018-03-26 16:49:15 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 16:49:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 16:49:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 16:49:15 --> Model Class Initialized
INFO - 2018-03-26 16:49:15 --> Model Class Initialized
INFO - 2018-03-26 16:49:15 --> Model Class Initialized
INFO - 2018-03-26 16:49:15 --> Model Class Initialized
INFO - 2018-03-26 16:49:15 --> Model Class Initialized
INFO - 2018-03-26 16:49:15 --> Model Class Initialized
INFO - 2018-03-26 16:49:15 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-26 16:49:15 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-26 16:49:15 --> Final output sent to browser
DEBUG - 2018-03-26 16:49:15 --> Total execution time: 2.7738
INFO - 2018-03-26 13:16:02 --> Config Class Initialized
INFO - 2018-03-26 13:16:02 --> Hooks Class Initialized
DEBUG - 2018-03-26 13:16:02 --> UTF-8 Support Enabled
INFO - 2018-03-26 13:16:02 --> Utf8 Class Initialized
INFO - 2018-03-26 13:16:02 --> URI Class Initialized
INFO - 2018-03-26 13:16:02 --> Router Class Initialized
INFO - 2018-03-26 13:16:02 --> Output Class Initialized
INFO - 2018-03-26 13:16:02 --> Security Class Initialized
DEBUG - 2018-03-26 13:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 13:16:02 --> Input Class Initialized
INFO - 2018-03-26 13:16:02 --> Language Class Initialized
INFO - 2018-03-26 13:16:03 --> Language Class Initialized
INFO - 2018-03-26 13:16:03 --> Config Class Initialized
INFO - 2018-03-26 13:16:03 --> Loader Class Initialized
INFO - 2018-03-26 18:46:03 --> Helper loaded: url_helper
INFO - 2018-03-26 18:46:03 --> Helper loaded: notification_helper
INFO - 2018-03-26 18:46:03 --> Helper loaded: settings_helper
INFO - 2018-03-26 18:46:03 --> Helper loaded: permission_helper
INFO - 2018-03-26 18:46:03 --> Helper loaded: users_helper
INFO - 2018-03-26 18:46:03 --> Database Driver Class Initialized
DEBUG - 2018-03-26 18:46:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 18:46:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 18:46:03 --> Helper loaded: form_helper
INFO - 2018-03-26 18:46:03 --> Form Validation Class Initialized
INFO - 2018-03-26 18:46:03 --> Controller Class Initialized
INFO - 2018-03-26 18:46:03 --> Model Class Initialized
INFO - 2018-03-26 18:46:03 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 18:46:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 18:46:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 18:46:03 --> Model Class Initialized
INFO - 2018-03-26 18:46:03 --> Model Class Initialized
INFO - 2018-03-26 18:46:03 --> Model Class Initialized
INFO - 2018-03-26 18:46:03 --> Model Class Initialized
INFO - 2018-03-26 18:46:03 --> Model Class Initialized
INFO - 2018-03-26 18:46:03 --> Model Class Initialized
INFO - 2018-03-26 18:46:03 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 18:46:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-26 18:46:03 --> Final output sent to browser
DEBUG - 2018-03-26 18:46:03 --> Total execution time: 0.2997
INFO - 2018-03-26 13:16:05 --> Config Class Initialized
INFO - 2018-03-26 13:16:05 --> Hooks Class Initialized
DEBUG - 2018-03-26 13:16:05 --> UTF-8 Support Enabled
INFO - 2018-03-26 13:16:05 --> Utf8 Class Initialized
INFO - 2018-03-26 13:16:05 --> URI Class Initialized
INFO - 2018-03-26 13:16:05 --> Config Class Initialized
INFO - 2018-03-26 13:16:05 --> Hooks Class Initialized
DEBUG - 2018-03-26 13:16:05 --> UTF-8 Support Enabled
INFO - 2018-03-26 13:16:05 --> Utf8 Class Initialized
INFO - 2018-03-26 13:16:05 --> Router Class Initialized
INFO - 2018-03-26 13:16:05 --> URI Class Initialized
INFO - 2018-03-26 13:16:05 --> Router Class Initialized
INFO - 2018-03-26 13:16:05 --> Output Class Initialized
INFO - 2018-03-26 13:16:05 --> Security Class Initialized
DEBUG - 2018-03-26 13:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 13:16:05 --> Input Class Initialized
INFO - 2018-03-26 13:16:05 --> Language Class Initialized
INFO - 2018-03-26 13:16:05 --> Language Class Initialized
INFO - 2018-03-26 13:16:05 --> Config Class Initialized
INFO - 2018-03-26 13:16:05 --> Loader Class Initialized
INFO - 2018-03-26 18:46:05 --> Helper loaded: url_helper
INFO - 2018-03-26 18:46:05 --> Helper loaded: notification_helper
INFO - 2018-03-26 18:46:05 --> Helper loaded: settings_helper
INFO - 2018-03-26 18:46:05 --> Helper loaded: permission_helper
INFO - 2018-03-26 18:46:05 --> Helper loaded: users_helper
INFO - 2018-03-26 18:46:05 --> Database Driver Class Initialized
INFO - 2018-03-26 13:16:06 --> Output Class Initialized
DEBUG - 2018-03-26 18:46:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 18:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 18:46:06 --> Helper loaded: form_helper
INFO - 2018-03-26 18:46:06 --> Form Validation Class Initialized
INFO - 2018-03-26 18:46:06 --> Controller Class Initialized
INFO - 2018-03-26 18:46:06 --> Model Class Initialized
INFO - 2018-03-26 18:46:06 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 18:46:06 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 18:46:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 18:46:06 --> Model Class Initialized
INFO - 2018-03-26 18:46:06 --> Model Class Initialized
INFO - 2018-03-26 13:16:06 --> Security Class Initialized
INFO - 2018-03-26 18:46:06 --> Model Class Initialized
INFO - 2018-03-26 18:46:06 --> Model Class Initialized
DEBUG - 2018-03-26 13:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 13:16:06 --> Input Class Initialized
INFO - 2018-03-26 18:46:06 --> Model Class Initialized
INFO - 2018-03-26 13:16:06 --> Language Class Initialized
INFO - 2018-03-26 18:46:06 --> Model Class Initialized
INFO - 2018-03-26 18:46:06 --> Model Class Initialized
INFO - 2018-03-26 13:16:06 --> Language Class Initialized
INFO - 2018-03-26 13:16:06 --> Config Class Initialized
INFO - 2018-03-26 13:16:06 --> Loader Class Initialized
INFO - 2018-03-26 18:46:06 --> Helper loaded: url_helper
INFO - 2018-03-26 18:46:06 --> Helper loaded: notification_helper
INFO - 2018-03-26 18:46:06 --> Helper loaded: settings_helper
INFO - 2018-03-26 18:46:06 --> Helper loaded: permission_helper
INFO - 2018-03-26 18:46:06 --> Helper loaded: users_helper
INFO - 2018-03-26 18:46:06 --> Model Class Initialized
INFO - 2018-03-26 18:46:06 --> Model Class Initialized
INFO - 2018-03-26 18:46:06 --> Model Class Initialized
INFO - 2018-03-26 18:46:07 --> Model Class Initialized
INFO - 2018-03-26 18:46:07 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 18:46:07 --> Model Class Initialized
INFO - 2018-03-26 18:46:07 --> Final output sent to browser
DEBUG - 2018-03-26 18:46:07 --> Total execution time: 1.3802
INFO - 2018-03-26 13:16:07 --> Config Class Initialized
INFO - 2018-03-26 13:16:07 --> Hooks Class Initialized
DEBUG - 2018-03-26 13:16:07 --> UTF-8 Support Enabled
INFO - 2018-03-26 13:16:07 --> Utf8 Class Initialized
INFO - 2018-03-26 13:16:07 --> URI Class Initialized
INFO - 2018-03-26 13:16:07 --> Router Class Initialized
INFO - 2018-03-26 13:16:07 --> Output Class Initialized
INFO - 2018-03-26 13:16:07 --> Security Class Initialized
DEBUG - 2018-03-26 13:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 13:16:07 --> Input Class Initialized
INFO - 2018-03-26 13:16:07 --> Language Class Initialized
INFO - 2018-03-26 13:16:07 --> Language Class Initialized
INFO - 2018-03-26 13:16:07 --> Config Class Initialized
INFO - 2018-03-26 13:16:07 --> Loader Class Initialized
INFO - 2018-03-26 18:46:07 --> Helper loaded: url_helper
INFO - 2018-03-26 18:46:07 --> Helper loaded: notification_helper
INFO - 2018-03-26 18:46:07 --> Helper loaded: settings_helper
INFO - 2018-03-26 18:46:07 --> Helper loaded: permission_helper
INFO - 2018-03-26 18:46:07 --> Helper loaded: users_helper
INFO - 2018-03-26 18:46:07 --> Database Driver Class Initialized
DEBUG - 2018-03-26 18:46:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 18:46:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 18:46:07 --> Helper loaded: form_helper
INFO - 2018-03-26 18:46:07 --> Form Validation Class Initialized
INFO - 2018-03-26 18:46:07 --> Controller Class Initialized
INFO - 2018-03-26 18:46:07 --> Model Class Initialized
INFO - 2018-03-26 18:46:07 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 18:46:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 18:46:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 18:46:07 --> Model Class Initialized
INFO - 2018-03-26 18:46:07 --> Model Class Initialized
INFO - 2018-03-26 18:46:07 --> Model Class Initialized
INFO - 2018-03-26 18:46:07 --> Model Class Initialized
INFO - 2018-03-26 18:46:07 --> Model Class Initialized
INFO - 2018-03-26 18:46:07 --> Model Class Initialized
INFO - 2018-03-26 18:46:07 --> Model Class Initialized
INFO - 2018-03-26 18:46:07 --> Model Class Initialized
INFO - 2018-03-26 18:46:07 --> Model Class Initialized
INFO - 2018-03-26 18:46:07 --> Model Class Initialized
INFO - 2018-03-26 18:46:07 --> Model Class Initialized
INFO - 2018-03-26 18:46:07 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 18:46:07 --> Model Class Initialized
INFO - 2018-03-26 18:46:07 --> Final output sent to browser
DEBUG - 2018-03-26 18:46:07 --> Total execution time: 0.1091
INFO - 2018-03-26 18:46:07 --> Database Driver Class Initialized
DEBUG - 2018-03-26 18:46:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 18:46:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 18:46:07 --> Helper loaded: form_helper
INFO - 2018-03-26 18:46:07 --> Form Validation Class Initialized
INFO - 2018-03-26 18:46:07 --> Controller Class Initialized
INFO - 2018-03-26 18:46:07 --> Model Class Initialized
INFO - 2018-03-26 18:46:07 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 18:46:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 18:46:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 18:46:07 --> Model Class Initialized
INFO - 2018-03-26 18:46:07 --> Model Class Initialized
INFO - 2018-03-26 18:46:07 --> Model Class Initialized
INFO - 2018-03-26 18:46:07 --> Model Class Initialized
INFO - 2018-03-26 18:46:07 --> Model Class Initialized
INFO - 2018-03-26 18:46:07 --> Model Class Initialized
INFO - 2018-03-26 18:46:07 --> Model Class Initialized
INFO - 2018-03-26 18:46:07 --> Model Class Initialized
INFO - 2018-03-26 18:46:07 --> Model Class Initialized
INFO - 2018-03-26 18:46:07 --> Model Class Initialized
INFO - 2018-03-26 18:46:07 --> Model Class Initialized
INFO - 2018-03-26 18:46:07 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 18:46:07 --> Model Class Initialized
INFO - 2018-03-26 18:46:07 --> Final output sent to browser
DEBUG - 2018-03-26 18:46:07 --> Total execution time: 2.6927
INFO - 2018-03-26 13:16:07 --> Config Class Initialized
INFO - 2018-03-26 13:16:07 --> Hooks Class Initialized
DEBUG - 2018-03-26 13:16:07 --> UTF-8 Support Enabled
INFO - 2018-03-26 13:16:07 --> Utf8 Class Initialized
INFO - 2018-03-26 13:16:07 --> URI Class Initialized
INFO - 2018-03-26 13:16:07 --> Router Class Initialized
INFO - 2018-03-26 13:16:07 --> Output Class Initialized
INFO - 2018-03-26 13:16:07 --> Security Class Initialized
DEBUG - 2018-03-26 13:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 13:16:07 --> Input Class Initialized
INFO - 2018-03-26 13:16:07 --> Language Class Initialized
INFO - 2018-03-26 13:16:07 --> Language Class Initialized
INFO - 2018-03-26 13:16:07 --> Config Class Initialized
INFO - 2018-03-26 13:16:07 --> Loader Class Initialized
INFO - 2018-03-26 18:46:07 --> Helper loaded: url_helper
INFO - 2018-03-26 18:46:07 --> Helper loaded: notification_helper
INFO - 2018-03-26 18:46:07 --> Helper loaded: settings_helper
INFO - 2018-03-26 18:46:07 --> Helper loaded: permission_helper
INFO - 2018-03-26 18:46:07 --> Helper loaded: users_helper
INFO - 2018-03-26 18:46:07 --> Database Driver Class Initialized
DEBUG - 2018-03-26 18:46:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 18:46:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 18:46:07 --> Helper loaded: form_helper
INFO - 2018-03-26 18:46:07 --> Form Validation Class Initialized
INFO - 2018-03-26 18:46:07 --> Controller Class Initialized
INFO - 2018-03-26 18:46:08 --> Model Class Initialized
INFO - 2018-03-26 18:46:08 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 18:46:08 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 18:46:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 18:46:08 --> Model Class Initialized
INFO - 2018-03-26 18:46:08 --> Model Class Initialized
INFO - 2018-03-26 18:46:08 --> Model Class Initialized
INFO - 2018-03-26 18:46:08 --> Model Class Initialized
INFO - 2018-03-26 18:46:08 --> Model Class Initialized
INFO - 2018-03-26 18:46:08 --> Model Class Initialized
INFO - 2018-03-26 18:46:08 --> Model Class Initialized
INFO - 2018-03-26 18:46:08 --> Model Class Initialized
INFO - 2018-03-26 18:46:08 --> Model Class Initialized
INFO - 2018-03-26 18:46:08 --> Model Class Initialized
INFO - 2018-03-26 18:46:08 --> Model Class Initialized
INFO - 2018-03-26 18:46:08 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 18:46:08 --> Model Class Initialized
INFO - 2018-03-26 18:46:08 --> Final output sent to browser
DEBUG - 2018-03-26 18:46:08 --> Total execution time: 0.5924
INFO - 2018-03-26 13:16:50 --> Config Class Initialized
INFO - 2018-03-26 13:16:50 --> Hooks Class Initialized
DEBUG - 2018-03-26 13:16:51 --> UTF-8 Support Enabled
INFO - 2018-03-26 13:16:51 --> Utf8 Class Initialized
INFO - 2018-03-26 13:16:51 --> URI Class Initialized
INFO - 2018-03-26 13:16:51 --> Router Class Initialized
INFO - 2018-03-26 13:16:51 --> Output Class Initialized
INFO - 2018-03-26 13:16:51 --> Security Class Initialized
DEBUG - 2018-03-26 13:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 13:16:51 --> Input Class Initialized
INFO - 2018-03-26 13:16:51 --> Language Class Initialized
INFO - 2018-03-26 13:16:52 --> Config Class Initialized
INFO - 2018-03-26 13:16:52 --> Hooks Class Initialized
DEBUG - 2018-03-26 13:16:52 --> UTF-8 Support Enabled
INFO - 2018-03-26 13:16:52 --> Utf8 Class Initialized
INFO - 2018-03-26 13:16:52 --> URI Class Initialized
INFO - 2018-03-26 13:16:52 --> Router Class Initialized
INFO - 2018-03-26 13:16:52 --> Output Class Initialized
INFO - 2018-03-26 13:16:52 --> Security Class Initialized
DEBUG - 2018-03-26 13:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 13:16:52 --> Input Class Initialized
INFO - 2018-03-26 13:16:52 --> Language Class Initialized
INFO - 2018-03-26 13:16:52 --> Language Class Initialized
INFO - 2018-03-26 13:16:52 --> Config Class Initialized
INFO - 2018-03-26 13:16:52 --> Loader Class Initialized
INFO - 2018-03-26 18:46:52 --> Helper loaded: url_helper
INFO - 2018-03-26 18:46:52 --> Helper loaded: notification_helper
INFO - 2018-03-26 18:46:52 --> Helper loaded: settings_helper
INFO - 2018-03-26 18:46:52 --> Helper loaded: permission_helper
INFO - 2018-03-26 18:46:52 --> Helper loaded: users_helper
INFO - 2018-03-26 18:46:52 --> Database Driver Class Initialized
DEBUG - 2018-03-26 18:46:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 18:46:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 18:46:52 --> Helper loaded: form_helper
INFO - 2018-03-26 18:46:52 --> Form Validation Class Initialized
INFO - 2018-03-26 18:46:52 --> Controller Class Initialized
INFO - 2018-03-26 18:46:52 --> Model Class Initialized
INFO - 2018-03-26 18:46:52 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 18:46:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 18:46:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 18:46:52 --> Model Class Initialized
INFO - 2018-03-26 18:46:52 --> Model Class Initialized
INFO - 2018-03-26 18:46:52 --> Model Class Initialized
INFO - 2018-03-26 18:46:52 --> Model Class Initialized
INFO - 2018-03-26 18:46:52 --> Model Class Initialized
INFO - 2018-03-26 18:46:52 --> Model Class Initialized
INFO - 2018-03-26 18:46:52 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-26 18:46:52 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-26 18:46:53 --> Final output sent to browser
DEBUG - 2018-03-26 18:46:53 --> Total execution time: 0.4426
INFO - 2018-03-26 13:16:53 --> Language Class Initialized
INFO - 2018-03-26 13:16:53 --> Config Class Initialized
INFO - 2018-03-26 13:16:53 --> Loader Class Initialized
INFO - 2018-03-26 18:46:53 --> Helper loaded: url_helper
INFO - 2018-03-26 18:46:53 --> Helper loaded: notification_helper
INFO - 2018-03-26 18:46:53 --> Helper loaded: settings_helper
INFO - 2018-03-26 18:46:53 --> Helper loaded: permission_helper
INFO - 2018-03-26 18:46:53 --> Helper loaded: users_helper
INFO - 2018-03-26 18:46:54 --> Database Driver Class Initialized
DEBUG - 2018-03-26 18:46:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 18:46:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 18:46:54 --> Helper loaded: form_helper
INFO - 2018-03-26 18:46:54 --> Form Validation Class Initialized
INFO - 2018-03-26 18:46:54 --> Controller Class Initialized
INFO - 2018-03-26 18:46:54 --> Model Class Initialized
INFO - 2018-03-26 18:46:54 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 18:46:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 18:46:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 18:46:54 --> Model Class Initialized
INFO - 2018-03-26 18:46:54 --> Model Class Initialized
INFO - 2018-03-26 18:46:54 --> Model Class Initialized
INFO - 2018-03-26 18:46:54 --> Model Class Initialized
INFO - 2018-03-26 18:46:54 --> Model Class Initialized
INFO - 2018-03-26 18:46:54 --> Model Class Initialized
INFO - 2018-03-26 18:46:54 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-26 18:46:54 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-26 18:46:54 --> Final output sent to browser
DEBUG - 2018-03-26 18:46:54 --> Total execution time: 4.6059
INFO - 2018-03-26 13:22:45 --> Config Class Initialized
INFO - 2018-03-26 13:22:45 --> Hooks Class Initialized
DEBUG - 2018-03-26 13:22:45 --> UTF-8 Support Enabled
INFO - 2018-03-26 13:22:45 --> Utf8 Class Initialized
INFO - 2018-03-26 13:22:45 --> URI Class Initialized
INFO - 2018-03-26 13:22:45 --> Router Class Initialized
INFO - 2018-03-26 13:22:45 --> Output Class Initialized
INFO - 2018-03-26 13:22:45 --> Security Class Initialized
DEBUG - 2018-03-26 13:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 13:22:45 --> Input Class Initialized
INFO - 2018-03-26 13:22:45 --> Language Class Initialized
INFO - 2018-03-26 13:22:46 --> Language Class Initialized
INFO - 2018-03-26 13:22:46 --> Config Class Initialized
INFO - 2018-03-26 13:22:46 --> Loader Class Initialized
INFO - 2018-03-26 18:52:46 --> Helper loaded: url_helper
INFO - 2018-03-26 18:52:46 --> Helper loaded: notification_helper
INFO - 2018-03-26 18:52:46 --> Helper loaded: settings_helper
INFO - 2018-03-26 18:52:46 --> Helper loaded: permission_helper
INFO - 2018-03-26 18:52:46 --> Helper loaded: users_helper
INFO - 2018-03-26 18:52:47 --> Database Driver Class Initialized
DEBUG - 2018-03-26 18:52:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 18:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 18:52:47 --> Helper loaded: form_helper
INFO - 2018-03-26 18:52:47 --> Form Validation Class Initialized
INFO - 2018-03-26 18:52:47 --> Controller Class Initialized
INFO - 2018-03-26 18:52:48 --> Model Class Initialized
INFO - 2018-03-26 18:52:48 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 18:52:48 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 18:52:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 18:52:48 --> Model Class Initialized
INFO - 2018-03-26 18:52:48 --> Model Class Initialized
INFO - 2018-03-26 18:52:48 --> Model Class Initialized
INFO - 2018-03-26 18:52:48 --> Model Class Initialized
INFO - 2018-03-26 18:52:48 --> Model Class Initialized
INFO - 2018-03-26 18:52:48 --> Model Class Initialized
INFO - 2018-03-26 18:52:48 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 18:52:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-26 18:52:48 --> Final output sent to browser
DEBUG - 2018-03-26 18:52:48 --> Total execution time: 3.7620
INFO - 2018-03-26 13:22:49 --> Config Class Initialized
INFO - 2018-03-26 13:22:49 --> Hooks Class Initialized
DEBUG - 2018-03-26 13:22:49 --> UTF-8 Support Enabled
INFO - 2018-03-26 13:22:49 --> Utf8 Class Initialized
INFO - 2018-03-26 13:22:49 --> URI Class Initialized
INFO - 2018-03-26 13:22:49 --> Router Class Initialized
INFO - 2018-03-26 13:22:49 --> Output Class Initialized
INFO - 2018-03-26 13:22:49 --> Security Class Initialized
DEBUG - 2018-03-26 13:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 13:22:49 --> Input Class Initialized
INFO - 2018-03-26 13:22:49 --> Language Class Initialized
INFO - 2018-03-26 13:22:49 --> Language Class Initialized
INFO - 2018-03-26 13:22:49 --> Config Class Initialized
INFO - 2018-03-26 13:22:49 --> Loader Class Initialized
INFO - 2018-03-26 18:52:49 --> Helper loaded: url_helper
INFO - 2018-03-26 18:52:49 --> Helper loaded: notification_helper
INFO - 2018-03-26 18:52:49 --> Helper loaded: settings_helper
INFO - 2018-03-26 18:52:49 --> Helper loaded: permission_helper
INFO - 2018-03-26 18:52:49 --> Helper loaded: users_helper
INFO - 2018-03-26 13:22:49 --> Config Class Initialized
INFO - 2018-03-26 13:22:49 --> Hooks Class Initialized
INFO - 2018-03-26 18:52:49 --> Database Driver Class Initialized
DEBUG - 2018-03-26 13:22:49 --> UTF-8 Support Enabled
INFO - 2018-03-26 13:22:49 --> Utf8 Class Initialized
DEBUG - 2018-03-26 18:52:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 13:22:49 --> URI Class Initialized
INFO - 2018-03-26 18:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 18:52:50 --> Helper loaded: form_helper
INFO - 2018-03-26 18:52:50 --> Form Validation Class Initialized
INFO - 2018-03-26 18:52:50 --> Controller Class Initialized
INFO - 2018-03-26 13:22:50 --> Router Class Initialized
INFO - 2018-03-26 18:52:50 --> Model Class Initialized
INFO - 2018-03-26 18:52:50 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 18:52:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 13:22:50 --> Output Class Initialized
INFO - 2018-03-26 18:52:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 18:52:50 --> Model Class Initialized
INFO - 2018-03-26 18:52:50 --> Model Class Initialized
INFO - 2018-03-26 18:52:50 --> Model Class Initialized
INFO - 2018-03-26 18:52:50 --> Model Class Initialized
INFO - 2018-03-26 18:52:50 --> Model Class Initialized
INFO - 2018-03-26 18:52:50 --> Model Class Initialized
INFO - 2018-03-26 18:52:50 --> Model Class Initialized
INFO - 2018-03-26 18:52:50 --> Model Class Initialized
INFO - 2018-03-26 18:52:50 --> Model Class Initialized
INFO - 2018-03-26 18:52:50 --> Model Class Initialized
INFO - 2018-03-26 13:22:50 --> Security Class Initialized
INFO - 2018-03-26 18:52:50 --> Model Class Initialized
INFO - 2018-03-26 18:52:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 18:52:50 --> Model Class Initialized
DEBUG - 2018-03-26 13:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 18:52:50 --> Final output sent to browser
DEBUG - 2018-03-26 18:52:50 --> Total execution time: 0.3700
INFO - 2018-03-26 13:22:50 --> Input Class Initialized
INFO - 2018-03-26 13:22:50 --> Language Class Initialized
INFO - 2018-03-26 13:22:50 --> Language Class Initialized
INFO - 2018-03-26 13:22:50 --> Config Class Initialized
INFO - 2018-03-26 13:22:50 --> Loader Class Initialized
INFO - 2018-03-26 18:52:50 --> Helper loaded: url_helper
INFO - 2018-03-26 18:52:50 --> Helper loaded: notification_helper
INFO - 2018-03-26 18:52:50 --> Helper loaded: settings_helper
INFO - 2018-03-26 18:52:50 --> Helper loaded: permission_helper
INFO - 2018-03-26 18:52:50 --> Helper loaded: users_helper
INFO - 2018-03-26 18:52:50 --> Database Driver Class Initialized
DEBUG - 2018-03-26 18:52:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 18:52:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 18:52:50 --> Helper loaded: form_helper
INFO - 2018-03-26 18:52:50 --> Form Validation Class Initialized
INFO - 2018-03-26 18:52:50 --> Controller Class Initialized
INFO - 2018-03-26 18:52:50 --> Model Class Initialized
INFO - 2018-03-26 18:52:50 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 18:52:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 18:52:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 18:52:50 --> Model Class Initialized
INFO - 2018-03-26 18:52:50 --> Model Class Initialized
INFO - 2018-03-26 18:52:50 --> Model Class Initialized
INFO - 2018-03-26 18:52:50 --> Model Class Initialized
INFO - 2018-03-26 18:52:50 --> Model Class Initialized
INFO - 2018-03-26 18:52:50 --> Model Class Initialized
INFO - 2018-03-26 18:52:50 --> Model Class Initialized
INFO - 2018-03-26 18:52:50 --> Model Class Initialized
INFO - 2018-03-26 18:52:50 --> Model Class Initialized
INFO - 2018-03-26 18:52:50 --> Model Class Initialized
INFO - 2018-03-26 18:52:50 --> Model Class Initialized
INFO - 2018-03-26 18:52:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 18:52:50 --> Model Class Initialized
INFO - 2018-03-26 18:52:50 --> Final output sent to browser
DEBUG - 2018-03-26 18:52:50 --> Total execution time: 0.3598
INFO - 2018-03-26 13:25:45 --> Config Class Initialized
INFO - 2018-03-26 13:25:45 --> Hooks Class Initialized
DEBUG - 2018-03-26 13:25:45 --> UTF-8 Support Enabled
INFO - 2018-03-26 13:25:45 --> Utf8 Class Initialized
INFO - 2018-03-26 13:25:45 --> URI Class Initialized
INFO - 2018-03-26 13:25:45 --> Router Class Initialized
INFO - 2018-03-26 13:25:45 --> Output Class Initialized
INFO - 2018-03-26 13:25:45 --> Security Class Initialized
DEBUG - 2018-03-26 13:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 13:25:45 --> Input Class Initialized
INFO - 2018-03-26 13:25:45 --> Language Class Initialized
INFO - 2018-03-26 13:25:45 --> Language Class Initialized
INFO - 2018-03-26 13:25:45 --> Config Class Initialized
INFO - 2018-03-26 13:25:45 --> Loader Class Initialized
INFO - 2018-03-26 18:55:45 --> Helper loaded: url_helper
INFO - 2018-03-26 18:55:45 --> Helper loaded: notification_helper
INFO - 2018-03-26 18:55:45 --> Helper loaded: settings_helper
INFO - 2018-03-26 18:55:45 --> Helper loaded: permission_helper
INFO - 2018-03-26 18:55:45 --> Helper loaded: users_helper
INFO - 2018-03-26 18:55:45 --> Database Driver Class Initialized
DEBUG - 2018-03-26 18:55:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 18:55:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 18:55:45 --> Helper loaded: form_helper
INFO - 2018-03-26 18:55:45 --> Form Validation Class Initialized
INFO - 2018-03-26 18:55:45 --> Controller Class Initialized
INFO - 2018-03-26 18:55:45 --> Model Class Initialized
INFO - 2018-03-26 18:55:45 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 18:55:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 18:55:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 18:55:45 --> Model Class Initialized
INFO - 2018-03-26 18:55:45 --> Model Class Initialized
INFO - 2018-03-26 18:55:45 --> Model Class Initialized
INFO - 2018-03-26 18:55:45 --> Model Class Initialized
INFO - 2018-03-26 18:55:45 --> Model Class Initialized
INFO - 2018-03-26 18:55:45 --> Model Class Initialized
INFO - 2018-03-26 18:55:45 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 18:55:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-26 18:55:45 --> Final output sent to browser
DEBUG - 2018-03-26 18:55:45 --> Total execution time: 0.1173
INFO - 2018-03-26 13:25:46 --> Config Class Initialized
INFO - 2018-03-26 13:25:46 --> Hooks Class Initialized
DEBUG - 2018-03-26 13:25:46 --> UTF-8 Support Enabled
INFO - 2018-03-26 13:25:46 --> Utf8 Class Initialized
INFO - 2018-03-26 13:25:46 --> Config Class Initialized
INFO - 2018-03-26 13:25:46 --> Hooks Class Initialized
DEBUG - 2018-03-26 13:25:46 --> UTF-8 Support Enabled
INFO - 2018-03-26 13:25:46 --> Utf8 Class Initialized
INFO - 2018-03-26 13:25:46 --> URI Class Initialized
INFO - 2018-03-26 13:25:46 --> URI Class Initialized
INFO - 2018-03-26 13:25:47 --> Router Class Initialized
INFO - 2018-03-26 13:25:47 --> Router Class Initialized
INFO - 2018-03-26 13:25:47 --> Output Class Initialized
INFO - 2018-03-26 13:25:47 --> Output Class Initialized
INFO - 2018-03-26 13:25:47 --> Security Class Initialized
INFO - 2018-03-26 13:25:47 --> Security Class Initialized
DEBUG - 2018-03-26 13:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 13:25:47 --> Input Class Initialized
INFO - 2018-03-26 13:25:47 --> Language Class Initialized
DEBUG - 2018-03-26 13:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 13:25:47 --> Input Class Initialized
INFO - 2018-03-26 13:25:47 --> Language Class Initialized
INFO - 2018-03-26 13:25:47 --> Language Class Initialized
INFO - 2018-03-26 13:25:47 --> Config Class Initialized
INFO - 2018-03-26 13:25:47 --> Loader Class Initialized
INFO - 2018-03-26 18:55:47 --> Helper loaded: url_helper
INFO - 2018-03-26 18:55:47 --> Helper loaded: notification_helper
INFO - 2018-03-26 18:55:47 --> Helper loaded: settings_helper
INFO - 2018-03-26 18:55:47 --> Helper loaded: permission_helper
INFO - 2018-03-26 18:55:47 --> Helper loaded: users_helper
INFO - 2018-03-26 13:25:47 --> Language Class Initialized
INFO - 2018-03-26 13:25:47 --> Config Class Initialized
INFO - 2018-03-26 13:25:47 --> Loader Class Initialized
INFO - 2018-03-26 18:55:48 --> Helper loaded: url_helper
INFO - 2018-03-26 18:55:48 --> Helper loaded: notification_helper
INFO - 2018-03-26 18:55:48 --> Helper loaded: settings_helper
INFO - 2018-03-26 18:55:48 --> Database Driver Class Initialized
DEBUG - 2018-03-26 18:55:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 18:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 18:55:48 --> Helper loaded: permission_helper
INFO - 2018-03-26 18:55:48 --> Helper loaded: form_helper
INFO - 2018-03-26 18:55:48 --> Form Validation Class Initialized
INFO - 2018-03-26 18:55:48 --> Controller Class Initialized
INFO - 2018-03-26 18:55:48 --> Model Class Initialized
INFO - 2018-03-26 18:55:48 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 18:55:48 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 18:55:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 18:55:48 --> Model Class Initialized
INFO - 2018-03-26 18:55:48 --> Model Class Initialized
INFO - 2018-03-26 18:55:48 --> Helper loaded: users_helper
INFO - 2018-03-26 18:55:48 --> Model Class Initialized
INFO - 2018-03-26 18:55:48 --> Model Class Initialized
INFO - 2018-03-26 18:55:48 --> Model Class Initialized
INFO - 2018-03-26 18:55:48 --> Model Class Initialized
INFO - 2018-03-26 18:55:48 --> Model Class Initialized
INFO - 2018-03-26 18:55:48 --> Model Class Initialized
INFO - 2018-03-26 18:55:48 --> Model Class Initialized
INFO - 2018-03-26 18:55:48 --> Model Class Initialized
INFO - 2018-03-26 18:55:48 --> Model Class Initialized
INFO - 2018-03-26 18:55:48 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 18:55:48 --> Model Class Initialized
INFO - 2018-03-26 18:55:48 --> Final output sent to browser
DEBUG - 2018-03-26 18:55:48 --> Total execution time: 1.4879
INFO - 2018-03-26 18:55:49 --> Database Driver Class Initialized
DEBUG - 2018-03-26 18:55:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 18:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 18:55:49 --> Helper loaded: form_helper
INFO - 2018-03-26 18:55:49 --> Form Validation Class Initialized
INFO - 2018-03-26 18:55:49 --> Controller Class Initialized
INFO - 2018-03-26 18:55:49 --> Model Class Initialized
INFO - 2018-03-26 18:55:49 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 18:55:49 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 18:55:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 18:55:49 --> Model Class Initialized
INFO - 2018-03-26 18:55:49 --> Model Class Initialized
INFO - 2018-03-26 18:55:49 --> Model Class Initialized
INFO - 2018-03-26 18:55:49 --> Model Class Initialized
INFO - 2018-03-26 18:55:49 --> Model Class Initialized
INFO - 2018-03-26 18:55:49 --> Model Class Initialized
INFO - 2018-03-26 18:55:49 --> Model Class Initialized
INFO - 2018-03-26 18:55:49 --> Model Class Initialized
INFO - 2018-03-26 18:55:49 --> Model Class Initialized
INFO - 2018-03-26 18:55:49 --> Model Class Initialized
INFO - 2018-03-26 18:55:49 --> Model Class Initialized
INFO - 2018-03-26 18:55:49 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 18:55:49 --> Model Class Initialized
INFO - 2018-03-26 18:55:49 --> Final output sent to browser
DEBUG - 2018-03-26 18:55:49 --> Total execution time: 2.7015
INFO - 2018-03-26 13:25:49 --> Config Class Initialized
INFO - 2018-03-26 13:25:49 --> Hooks Class Initialized
DEBUG - 2018-03-26 13:25:49 --> UTF-8 Support Enabled
INFO - 2018-03-26 13:25:49 --> Utf8 Class Initialized
INFO - 2018-03-26 13:25:49 --> URI Class Initialized
INFO - 2018-03-26 13:25:49 --> Router Class Initialized
INFO - 2018-03-26 13:25:49 --> Output Class Initialized
INFO - 2018-03-26 13:25:49 --> Security Class Initialized
DEBUG - 2018-03-26 13:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 13:25:49 --> Input Class Initialized
INFO - 2018-03-26 13:25:49 --> Language Class Initialized
INFO - 2018-03-26 13:25:49 --> Language Class Initialized
INFO - 2018-03-26 13:25:49 --> Config Class Initialized
INFO - 2018-03-26 13:25:49 --> Loader Class Initialized
INFO - 2018-03-26 18:55:49 --> Helper loaded: url_helper
INFO - 2018-03-26 18:55:49 --> Helper loaded: notification_helper
INFO - 2018-03-26 18:55:49 --> Helper loaded: settings_helper
INFO - 2018-03-26 18:55:49 --> Helper loaded: permission_helper
INFO - 2018-03-26 18:55:49 --> Helper loaded: users_helper
INFO - 2018-03-26 18:55:49 --> Database Driver Class Initialized
DEBUG - 2018-03-26 18:55:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 18:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 18:55:49 --> Helper loaded: form_helper
INFO - 2018-03-26 18:55:49 --> Form Validation Class Initialized
INFO - 2018-03-26 18:55:49 --> Controller Class Initialized
INFO - 2018-03-26 18:55:49 --> Model Class Initialized
INFO - 2018-03-26 18:55:49 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 18:55:49 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 18:55:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 18:55:49 --> Model Class Initialized
INFO - 2018-03-26 18:55:49 --> Model Class Initialized
INFO - 2018-03-26 18:55:49 --> Model Class Initialized
INFO - 2018-03-26 18:55:49 --> Model Class Initialized
INFO - 2018-03-26 18:55:49 --> Model Class Initialized
INFO - 2018-03-26 18:55:49 --> Model Class Initialized
INFO - 2018-03-26 18:55:49 --> Model Class Initialized
INFO - 2018-03-26 18:55:49 --> Model Class Initialized
INFO - 2018-03-26 18:55:49 --> Model Class Initialized
INFO - 2018-03-26 18:55:49 --> Model Class Initialized
INFO - 2018-03-26 18:55:49 --> Model Class Initialized
INFO - 2018-03-26 18:55:49 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 18:55:49 --> Model Class Initialized
INFO - 2018-03-26 18:55:49 --> Final output sent to browser
DEBUG - 2018-03-26 18:55:49 --> Total execution time: 0.4112
INFO - 2018-03-26 13:28:05 --> Config Class Initialized
INFO - 2018-03-26 13:28:05 --> Hooks Class Initialized
DEBUG - 2018-03-26 13:28:05 --> UTF-8 Support Enabled
INFO - 2018-03-26 13:28:05 --> Utf8 Class Initialized
INFO - 2018-03-26 13:28:05 --> URI Class Initialized
INFO - 2018-03-26 13:28:05 --> Router Class Initialized
INFO - 2018-03-26 13:28:05 --> Output Class Initialized
INFO - 2018-03-26 13:28:05 --> Security Class Initialized
DEBUG - 2018-03-26 13:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 13:28:05 --> Input Class Initialized
INFO - 2018-03-26 13:28:05 --> Language Class Initialized
INFO - 2018-03-26 13:28:06 --> Language Class Initialized
INFO - 2018-03-26 13:28:06 --> Config Class Initialized
INFO - 2018-03-26 13:28:06 --> Loader Class Initialized
INFO - 2018-03-26 18:58:06 --> Helper loaded: url_helper
INFO - 2018-03-26 18:58:06 --> Helper loaded: notification_helper
INFO - 2018-03-26 18:58:06 --> Helper loaded: settings_helper
INFO - 2018-03-26 18:58:06 --> Helper loaded: permission_helper
INFO - 2018-03-26 18:58:06 --> Helper loaded: users_helper
INFO - 2018-03-26 18:58:07 --> Database Driver Class Initialized
DEBUG - 2018-03-26 18:58:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 18:58:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 18:58:07 --> Helper loaded: form_helper
INFO - 2018-03-26 18:58:07 --> Form Validation Class Initialized
INFO - 2018-03-26 18:58:07 --> Controller Class Initialized
INFO - 2018-03-26 18:58:07 --> Model Class Initialized
INFO - 2018-03-26 18:58:07 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 18:58:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 18:58:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 18:58:07 --> Model Class Initialized
INFO - 2018-03-26 18:58:07 --> Model Class Initialized
INFO - 2018-03-26 18:58:07 --> Model Class Initialized
INFO - 2018-03-26 18:58:07 --> Model Class Initialized
INFO - 2018-03-26 18:58:07 --> Model Class Initialized
INFO - 2018-03-26 18:58:07 --> Model Class Initialized
INFO - 2018-03-26 18:58:07 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 18:58:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-26 18:58:07 --> Final output sent to browser
DEBUG - 2018-03-26 18:58:07 --> Total execution time: 2.6371
INFO - 2018-03-26 13:28:08 --> Config Class Initialized
INFO - 2018-03-26 13:28:08 --> Hooks Class Initialized
DEBUG - 2018-03-26 13:28:08 --> UTF-8 Support Enabled
INFO - 2018-03-26 13:28:08 --> Utf8 Class Initialized
INFO - 2018-03-26 13:28:08 --> URI Class Initialized
INFO - 2018-03-26 13:28:08 --> Router Class Initialized
INFO - 2018-03-26 13:28:08 --> Output Class Initialized
INFO - 2018-03-26 13:28:08 --> Security Class Initialized
DEBUG - 2018-03-26 13:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 13:28:08 --> Input Class Initialized
INFO - 2018-03-26 13:28:08 --> Language Class Initialized
INFO - 2018-03-26 13:28:08 --> Language Class Initialized
INFO - 2018-03-26 13:28:08 --> Config Class Initialized
INFO - 2018-03-26 13:28:08 --> Loader Class Initialized
INFO - 2018-03-26 18:58:08 --> Helper loaded: url_helper
INFO - 2018-03-26 18:58:08 --> Helper loaded: notification_helper
INFO - 2018-03-26 18:58:08 --> Helper loaded: settings_helper
INFO - 2018-03-26 18:58:08 --> Helper loaded: permission_helper
INFO - 2018-03-26 18:58:08 --> Helper loaded: users_helper
INFO - 2018-03-26 18:58:08 --> Database Driver Class Initialized
DEBUG - 2018-03-26 18:58:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 18:58:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 18:58:08 --> Helper loaded: form_helper
INFO - 2018-03-26 18:58:08 --> Form Validation Class Initialized
INFO - 2018-03-26 18:58:08 --> Controller Class Initialized
INFO - 2018-03-26 18:58:08 --> Model Class Initialized
INFO - 2018-03-26 18:58:08 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 18:58:08 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 18:58:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 18:58:08 --> Model Class Initialized
INFO - 2018-03-26 18:58:08 --> Model Class Initialized
INFO - 2018-03-26 18:58:08 --> Model Class Initialized
INFO - 2018-03-26 18:58:08 --> Model Class Initialized
INFO - 2018-03-26 18:58:08 --> Model Class Initialized
INFO - 2018-03-26 18:58:08 --> Model Class Initialized
INFO - 2018-03-26 18:58:08 --> Model Class Initialized
INFO - 2018-03-26 18:58:08 --> Model Class Initialized
INFO - 2018-03-26 18:58:08 --> Model Class Initialized
INFO - 2018-03-26 18:58:08 --> Model Class Initialized
INFO - 2018-03-26 18:58:08 --> Model Class Initialized
INFO - 2018-03-26 18:58:08 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 18:58:08 --> Model Class Initialized
INFO - 2018-03-26 18:58:08 --> Final output sent to browser
DEBUG - 2018-03-26 18:58:08 --> Total execution time: 0.1350
INFO - 2018-03-26 13:28:10 --> Config Class Initialized
INFO - 2018-03-26 13:28:10 --> Hooks Class Initialized
DEBUG - 2018-03-26 13:28:10 --> UTF-8 Support Enabled
INFO - 2018-03-26 13:28:10 --> Utf8 Class Initialized
INFO - 2018-03-26 13:28:10 --> URI Class Initialized
INFO - 2018-03-26 13:28:11 --> Router Class Initialized
INFO - 2018-03-26 13:28:11 --> Output Class Initialized
INFO - 2018-03-26 13:28:11 --> Security Class Initialized
DEBUG - 2018-03-26 13:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 13:28:11 --> Input Class Initialized
INFO - 2018-03-26 13:28:11 --> Language Class Initialized
INFO - 2018-03-26 13:28:11 --> Config Class Initialized
INFO - 2018-03-26 13:28:11 --> Hooks Class Initialized
DEBUG - 2018-03-26 13:28:11 --> UTF-8 Support Enabled
INFO - 2018-03-26 13:28:11 --> Utf8 Class Initialized
INFO - 2018-03-26 13:28:11 --> URI Class Initialized
INFO - 2018-03-26 13:28:11 --> Router Class Initialized
INFO - 2018-03-26 13:28:11 --> Output Class Initialized
INFO - 2018-03-26 13:28:11 --> Security Class Initialized
DEBUG - 2018-03-26 13:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 13:28:11 --> Input Class Initialized
INFO - 2018-03-26 13:28:11 --> Language Class Initialized
INFO - 2018-03-26 13:28:11 --> Language Class Initialized
INFO - 2018-03-26 13:28:11 --> Config Class Initialized
INFO - 2018-03-26 13:28:11 --> Loader Class Initialized
INFO - 2018-03-26 18:58:11 --> Helper loaded: url_helper
INFO - 2018-03-26 18:58:11 --> Helper loaded: notification_helper
INFO - 2018-03-26 18:58:11 --> Helper loaded: settings_helper
INFO - 2018-03-26 18:58:11 --> Helper loaded: permission_helper
INFO - 2018-03-26 18:58:11 --> Helper loaded: users_helper
INFO - 2018-03-26 18:58:11 --> Database Driver Class Initialized
DEBUG - 2018-03-26 18:58:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 18:58:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 18:58:11 --> Helper loaded: form_helper
INFO - 2018-03-26 18:58:11 --> Form Validation Class Initialized
INFO - 2018-03-26 18:58:11 --> Controller Class Initialized
INFO - 2018-03-26 18:58:11 --> Model Class Initialized
INFO - 2018-03-26 18:58:11 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 18:58:11 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 18:58:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 18:58:11 --> Model Class Initialized
INFO - 2018-03-26 18:58:11 --> Model Class Initialized
INFO - 2018-03-26 18:58:11 --> Model Class Initialized
INFO - 2018-03-26 18:58:11 --> Model Class Initialized
INFO - 2018-03-26 18:58:11 --> Model Class Initialized
INFO - 2018-03-26 18:58:11 --> Model Class Initialized
INFO - 2018-03-26 18:58:11 --> Model Class Initialized
INFO - 2018-03-26 18:58:11 --> Model Class Initialized
INFO - 2018-03-26 18:58:11 --> Model Class Initialized
INFO - 2018-03-26 18:58:11 --> Model Class Initialized
INFO - 2018-03-26 18:58:11 --> Model Class Initialized
INFO - 2018-03-26 18:58:11 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 18:58:11 --> Model Class Initialized
INFO - 2018-03-26 18:58:11 --> Final output sent to browser
DEBUG - 2018-03-26 18:58:11 --> Total execution time: 0.1764
INFO - 2018-03-26 13:28:12 --> Language Class Initialized
INFO - 2018-03-26 13:28:12 --> Config Class Initialized
INFO - 2018-03-26 13:28:12 --> Loader Class Initialized
INFO - 2018-03-26 18:58:12 --> Helper loaded: url_helper
INFO - 2018-03-26 18:58:12 --> Helper loaded: notification_helper
INFO - 2018-03-26 18:58:12 --> Helper loaded: settings_helper
INFO - 2018-03-26 18:58:12 --> Helper loaded: permission_helper
INFO - 2018-03-26 18:58:12 --> Helper loaded: users_helper
INFO - 2018-03-26 18:58:12 --> Database Driver Class Initialized
DEBUG - 2018-03-26 18:58:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 18:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 18:58:12 --> Helper loaded: form_helper
INFO - 2018-03-26 18:58:12 --> Form Validation Class Initialized
INFO - 2018-03-26 18:58:12 --> Controller Class Initialized
INFO - 2018-03-26 18:58:12 --> Model Class Initialized
INFO - 2018-03-26 18:58:12 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 18:58:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 18:58:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 18:58:12 --> Model Class Initialized
INFO - 2018-03-26 18:58:12 --> Model Class Initialized
INFO - 2018-03-26 18:58:12 --> Model Class Initialized
INFO - 2018-03-26 18:58:12 --> Model Class Initialized
INFO - 2018-03-26 18:58:12 --> Model Class Initialized
INFO - 2018-03-26 18:58:12 --> Model Class Initialized
INFO - 2018-03-26 18:58:12 --> Model Class Initialized
INFO - 2018-03-26 18:58:12 --> Model Class Initialized
INFO - 2018-03-26 18:58:12 --> Model Class Initialized
INFO - 2018-03-26 18:58:12 --> Model Class Initialized
INFO - 2018-03-26 18:58:12 --> Model Class Initialized
INFO - 2018-03-26 18:58:12 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 18:58:12 --> Model Class Initialized
INFO - 2018-03-26 18:58:12 --> Final output sent to browser
DEBUG - 2018-03-26 18:58:12 --> Total execution time: 2.4980
INFO - 2018-03-26 13:30:18 --> Config Class Initialized
INFO - 2018-03-26 13:30:18 --> Hooks Class Initialized
DEBUG - 2018-03-26 13:30:18 --> UTF-8 Support Enabled
INFO - 2018-03-26 13:30:18 --> Utf8 Class Initialized
INFO - 2018-03-26 13:30:18 --> URI Class Initialized
INFO - 2018-03-26 13:30:18 --> Router Class Initialized
INFO - 2018-03-26 13:30:18 --> Output Class Initialized
INFO - 2018-03-26 13:30:18 --> Security Class Initialized
DEBUG - 2018-03-26 13:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 13:30:18 --> Input Class Initialized
INFO - 2018-03-26 13:30:18 --> Language Class Initialized
INFO - 2018-03-26 13:30:19 --> Language Class Initialized
INFO - 2018-03-26 13:30:19 --> Config Class Initialized
INFO - 2018-03-26 13:30:19 --> Loader Class Initialized
INFO - 2018-03-26 19:00:19 --> Helper loaded: url_helper
INFO - 2018-03-26 19:00:19 --> Helper loaded: notification_helper
INFO - 2018-03-26 19:00:19 --> Helper loaded: settings_helper
INFO - 2018-03-26 19:00:19 --> Helper loaded: permission_helper
INFO - 2018-03-26 19:00:19 --> Helper loaded: users_helper
INFO - 2018-03-26 19:00:19 --> Database Driver Class Initialized
DEBUG - 2018-03-26 19:00:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 19:00:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 19:00:19 --> Helper loaded: form_helper
INFO - 2018-03-26 19:00:19 --> Form Validation Class Initialized
INFO - 2018-03-26 19:00:19 --> Controller Class Initialized
INFO - 2018-03-26 19:00:19 --> Model Class Initialized
INFO - 2018-03-26 19:00:19 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 19:00:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 19:00:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 19:00:19 --> Model Class Initialized
INFO - 2018-03-26 19:00:19 --> Model Class Initialized
INFO - 2018-03-26 19:00:19 --> Model Class Initialized
INFO - 2018-03-26 19:00:19 --> Model Class Initialized
INFO - 2018-03-26 19:00:19 --> Model Class Initialized
INFO - 2018-03-26 19:00:19 --> Model Class Initialized
INFO - 2018-03-26 19:00:19 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 19:00:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-26 19:00:19 --> Final output sent to browser
DEBUG - 2018-03-26 19:00:19 --> Total execution time: 0.7241
INFO - 2018-03-26 13:30:20 --> Config Class Initialized
INFO - 2018-03-26 13:30:20 --> Hooks Class Initialized
DEBUG - 2018-03-26 13:30:20 --> UTF-8 Support Enabled
INFO - 2018-03-26 13:30:20 --> Utf8 Class Initialized
INFO - 2018-03-26 13:30:20 --> URI Class Initialized
INFO - 2018-03-26 13:30:20 --> Router Class Initialized
INFO - 2018-03-26 13:30:20 --> Output Class Initialized
INFO - 2018-03-26 13:30:20 --> Security Class Initialized
DEBUG - 2018-03-26 13:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 13:30:20 --> Input Class Initialized
INFO - 2018-03-26 13:30:20 --> Language Class Initialized
INFO - 2018-03-26 13:30:20 --> Language Class Initialized
INFO - 2018-03-26 13:30:20 --> Config Class Initialized
INFO - 2018-03-26 13:30:20 --> Loader Class Initialized
INFO - 2018-03-26 19:00:20 --> Helper loaded: url_helper
INFO - 2018-03-26 19:00:20 --> Helper loaded: notification_helper
INFO - 2018-03-26 19:00:20 --> Helper loaded: settings_helper
INFO - 2018-03-26 19:00:20 --> Helper loaded: permission_helper
INFO - 2018-03-26 19:00:20 --> Helper loaded: users_helper
INFO - 2018-03-26 19:00:20 --> Database Driver Class Initialized
DEBUG - 2018-03-26 19:00:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 19:00:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 19:00:20 --> Helper loaded: form_helper
INFO - 2018-03-26 19:00:20 --> Form Validation Class Initialized
INFO - 2018-03-26 19:00:20 --> Controller Class Initialized
INFO - 2018-03-26 19:00:20 --> Model Class Initialized
INFO - 2018-03-26 19:00:20 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 19:00:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 19:00:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 19:00:20 --> Model Class Initialized
INFO - 2018-03-26 19:00:20 --> Model Class Initialized
INFO - 2018-03-26 19:00:20 --> Model Class Initialized
INFO - 2018-03-26 19:00:20 --> Model Class Initialized
INFO - 2018-03-26 19:00:20 --> Model Class Initialized
INFO - 2018-03-26 19:00:20 --> Model Class Initialized
INFO - 2018-03-26 19:00:20 --> Model Class Initialized
INFO - 2018-03-26 19:00:20 --> Model Class Initialized
INFO - 2018-03-26 19:00:20 --> Model Class Initialized
INFO - 2018-03-26 19:00:20 --> Model Class Initialized
INFO - 2018-03-26 19:00:20 --> Model Class Initialized
INFO - 2018-03-26 19:00:20 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 19:00:20 --> Model Class Initialized
INFO - 2018-03-26 19:00:20 --> Final output sent to browser
DEBUG - 2018-03-26 19:00:20 --> Total execution time: 0.1783
INFO - 2018-03-26 13:30:20 --> Config Class Initialized
INFO - 2018-03-26 13:30:20 --> Hooks Class Initialized
DEBUG - 2018-03-26 13:30:20 --> UTF-8 Support Enabled
INFO - 2018-03-26 13:30:20 --> Utf8 Class Initialized
INFO - 2018-03-26 13:30:20 --> URI Class Initialized
INFO - 2018-03-26 13:30:20 --> Router Class Initialized
INFO - 2018-03-26 13:30:20 --> Output Class Initialized
INFO - 2018-03-26 13:30:20 --> Security Class Initialized
DEBUG - 2018-03-26 13:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 13:30:20 --> Input Class Initialized
INFO - 2018-03-26 13:30:20 --> Language Class Initialized
INFO - 2018-03-26 13:30:20 --> Language Class Initialized
INFO - 2018-03-26 13:30:20 --> Config Class Initialized
INFO - 2018-03-26 13:30:20 --> Loader Class Initialized
INFO - 2018-03-26 19:00:20 --> Helper loaded: url_helper
INFO - 2018-03-26 19:00:20 --> Helper loaded: notification_helper
INFO - 2018-03-26 19:00:20 --> Helper loaded: settings_helper
INFO - 2018-03-26 19:00:20 --> Helper loaded: permission_helper
INFO - 2018-03-26 19:00:20 --> Helper loaded: users_helper
INFO - 2018-03-26 19:00:20 --> Database Driver Class Initialized
DEBUG - 2018-03-26 19:00:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 19:00:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 19:00:21 --> Helper loaded: form_helper
INFO - 2018-03-26 19:00:21 --> Form Validation Class Initialized
INFO - 2018-03-26 19:00:21 --> Controller Class Initialized
INFO - 2018-03-26 19:00:21 --> Model Class Initialized
INFO - 2018-03-26 19:00:21 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 19:00:21 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 19:00:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 19:00:21 --> Model Class Initialized
INFO - 2018-03-26 19:00:21 --> Model Class Initialized
INFO - 2018-03-26 19:00:21 --> Model Class Initialized
INFO - 2018-03-26 19:00:21 --> Model Class Initialized
INFO - 2018-03-26 19:00:21 --> Model Class Initialized
INFO - 2018-03-26 19:00:21 --> Model Class Initialized
INFO - 2018-03-26 19:00:21 --> Model Class Initialized
INFO - 2018-03-26 19:00:21 --> Model Class Initialized
INFO - 2018-03-26 19:00:21 --> Model Class Initialized
INFO - 2018-03-26 19:00:21 --> Model Class Initialized
INFO - 2018-03-26 19:00:21 --> Model Class Initialized
INFO - 2018-03-26 19:00:21 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 19:00:21 --> Model Class Initialized
INFO - 2018-03-26 19:00:21 --> Final output sent to browser
DEBUG - 2018-03-26 19:00:21 --> Total execution time: 0.6577
INFO - 2018-03-26 13:32:38 --> Config Class Initialized
INFO - 2018-03-26 13:32:38 --> Hooks Class Initialized
DEBUG - 2018-03-26 13:32:38 --> UTF-8 Support Enabled
INFO - 2018-03-26 13:32:38 --> Utf8 Class Initialized
INFO - 2018-03-26 13:32:38 --> URI Class Initialized
INFO - 2018-03-26 13:32:38 --> Router Class Initialized
INFO - 2018-03-26 13:32:38 --> Output Class Initialized
INFO - 2018-03-26 13:32:38 --> Security Class Initialized
DEBUG - 2018-03-26 13:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 13:32:38 --> Input Class Initialized
INFO - 2018-03-26 13:32:38 --> Language Class Initialized
INFO - 2018-03-26 13:32:38 --> Language Class Initialized
INFO - 2018-03-26 13:32:38 --> Config Class Initialized
INFO - 2018-03-26 13:32:38 --> Loader Class Initialized
INFO - 2018-03-26 19:02:38 --> Helper loaded: url_helper
INFO - 2018-03-26 19:02:38 --> Helper loaded: notification_helper
INFO - 2018-03-26 19:02:38 --> Helper loaded: settings_helper
INFO - 2018-03-26 19:02:38 --> Helper loaded: permission_helper
INFO - 2018-03-26 19:02:38 --> Helper loaded: users_helper
INFO - 2018-03-26 19:02:39 --> Database Driver Class Initialized
DEBUG - 2018-03-26 19:02:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 19:02:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 19:02:39 --> Helper loaded: form_helper
INFO - 2018-03-26 19:02:39 --> Form Validation Class Initialized
INFO - 2018-03-26 19:02:39 --> Controller Class Initialized
INFO - 2018-03-26 19:02:39 --> Model Class Initialized
INFO - 2018-03-26 19:02:39 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 19:02:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 19:02:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 19:02:39 --> Model Class Initialized
INFO - 2018-03-26 19:02:39 --> Model Class Initialized
INFO - 2018-03-26 19:02:39 --> Model Class Initialized
INFO - 2018-03-26 19:02:39 --> Model Class Initialized
INFO - 2018-03-26 19:02:39 --> Model Class Initialized
INFO - 2018-03-26 19:02:39 --> Model Class Initialized
INFO - 2018-03-26 19:02:39 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 19:02:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-26 19:02:39 --> Final output sent to browser
DEBUG - 2018-03-26 19:02:39 --> Total execution time: 0.9899
INFO - 2018-03-26 13:32:40 --> Config Class Initialized
INFO - 2018-03-26 13:32:40 --> Hooks Class Initialized
DEBUG - 2018-03-26 13:32:40 --> UTF-8 Support Enabled
INFO - 2018-03-26 13:32:40 --> Utf8 Class Initialized
INFO - 2018-03-26 13:32:40 --> URI Class Initialized
INFO - 2018-03-26 13:32:40 --> Router Class Initialized
INFO - 2018-03-26 13:32:40 --> Output Class Initialized
INFO - 2018-03-26 13:32:40 --> Security Class Initialized
DEBUG - 2018-03-26 13:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 13:32:40 --> Input Class Initialized
INFO - 2018-03-26 13:32:40 --> Language Class Initialized
INFO - 2018-03-26 13:32:40 --> Language Class Initialized
INFO - 2018-03-26 13:32:40 --> Config Class Initialized
INFO - 2018-03-26 13:32:40 --> Loader Class Initialized
INFO - 2018-03-26 19:02:40 --> Helper loaded: url_helper
INFO - 2018-03-26 19:02:40 --> Helper loaded: notification_helper
INFO - 2018-03-26 19:02:40 --> Helper loaded: settings_helper
INFO - 2018-03-26 19:02:40 --> Helper loaded: permission_helper
INFO - 2018-03-26 19:02:40 --> Helper loaded: users_helper
INFO - 2018-03-26 19:02:40 --> Database Driver Class Initialized
DEBUG - 2018-03-26 19:02:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 19:02:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 19:02:40 --> Helper loaded: form_helper
INFO - 2018-03-26 19:02:40 --> Form Validation Class Initialized
INFO - 2018-03-26 19:02:40 --> Controller Class Initialized
INFO - 2018-03-26 19:02:40 --> Model Class Initialized
INFO - 2018-03-26 19:02:40 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 19:02:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 19:02:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 19:02:40 --> Model Class Initialized
INFO - 2018-03-26 19:02:40 --> Model Class Initialized
INFO - 2018-03-26 19:02:40 --> Model Class Initialized
INFO - 2018-03-26 19:02:40 --> Model Class Initialized
INFO - 2018-03-26 19:02:40 --> Model Class Initialized
INFO - 2018-03-26 19:02:40 --> Model Class Initialized
INFO - 2018-03-26 19:02:40 --> Model Class Initialized
INFO - 2018-03-26 19:02:40 --> Model Class Initialized
INFO - 2018-03-26 19:02:40 --> Model Class Initialized
INFO - 2018-03-26 19:02:40 --> Model Class Initialized
INFO - 2018-03-26 19:02:40 --> Model Class Initialized
INFO - 2018-03-26 19:02:40 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 19:02:40 --> Model Class Initialized
INFO - 2018-03-26 19:02:40 --> Final output sent to browser
DEBUG - 2018-03-26 19:02:40 --> Total execution time: 0.2046
INFO - 2018-03-26 13:32:40 --> Config Class Initialized
INFO - 2018-03-26 13:32:40 --> Hooks Class Initialized
DEBUG - 2018-03-26 13:32:40 --> UTF-8 Support Enabled
INFO - 2018-03-26 13:32:40 --> Utf8 Class Initialized
INFO - 2018-03-26 13:32:40 --> URI Class Initialized
INFO - 2018-03-26 13:32:40 --> Router Class Initialized
INFO - 2018-03-26 13:32:40 --> Output Class Initialized
INFO - 2018-03-26 13:32:40 --> Security Class Initialized
DEBUG - 2018-03-26 13:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 13:32:40 --> Input Class Initialized
INFO - 2018-03-26 13:32:40 --> Language Class Initialized
INFO - 2018-03-26 13:32:40 --> Language Class Initialized
INFO - 2018-03-26 13:32:40 --> Config Class Initialized
INFO - 2018-03-26 13:32:40 --> Loader Class Initialized
INFO - 2018-03-26 19:02:40 --> Helper loaded: url_helper
INFO - 2018-03-26 19:02:40 --> Helper loaded: notification_helper
INFO - 2018-03-26 19:02:40 --> Helper loaded: settings_helper
INFO - 2018-03-26 19:02:40 --> Helper loaded: permission_helper
INFO - 2018-03-26 19:02:40 --> Helper loaded: users_helper
INFO - 2018-03-26 19:02:40 --> Database Driver Class Initialized
DEBUG - 2018-03-26 19:02:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 19:02:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 19:02:40 --> Helper loaded: form_helper
INFO - 2018-03-26 19:02:40 --> Form Validation Class Initialized
INFO - 2018-03-26 19:02:40 --> Controller Class Initialized
INFO - 2018-03-26 19:02:40 --> Model Class Initialized
INFO - 2018-03-26 19:02:40 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 19:02:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 19:02:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 19:02:40 --> Model Class Initialized
INFO - 2018-03-26 19:02:40 --> Model Class Initialized
INFO - 2018-03-26 19:02:40 --> Model Class Initialized
INFO - 2018-03-26 19:02:40 --> Model Class Initialized
INFO - 2018-03-26 19:02:40 --> Model Class Initialized
INFO - 2018-03-26 19:02:40 --> Model Class Initialized
INFO - 2018-03-26 19:02:40 --> Model Class Initialized
INFO - 2018-03-26 19:02:40 --> Model Class Initialized
INFO - 2018-03-26 19:02:40 --> Model Class Initialized
INFO - 2018-03-26 19:02:40 --> Model Class Initialized
INFO - 2018-03-26 19:02:40 --> Model Class Initialized
INFO - 2018-03-26 19:02:40 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 19:02:40 --> Model Class Initialized
INFO - 2018-03-26 19:02:40 --> Final output sent to browser
DEBUG - 2018-03-26 19:02:40 --> Total execution time: 0.2402
INFO - 2018-03-26 13:36:35 --> Config Class Initialized
INFO - 2018-03-26 13:36:35 --> Hooks Class Initialized
DEBUG - 2018-03-26 13:36:35 --> UTF-8 Support Enabled
INFO - 2018-03-26 13:36:35 --> Utf8 Class Initialized
INFO - 2018-03-26 13:36:36 --> URI Class Initialized
INFO - 2018-03-26 13:36:36 --> Router Class Initialized
INFO - 2018-03-26 13:36:36 --> Output Class Initialized
INFO - 2018-03-26 13:36:36 --> Security Class Initialized
DEBUG - 2018-03-26 13:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 13:36:36 --> Input Class Initialized
INFO - 2018-03-26 13:36:36 --> Language Class Initialized
INFO - 2018-03-26 13:36:37 --> Language Class Initialized
INFO - 2018-03-26 13:36:37 --> Config Class Initialized
INFO - 2018-03-26 13:36:37 --> Loader Class Initialized
INFO - 2018-03-26 19:06:37 --> Helper loaded: url_helper
INFO - 2018-03-26 19:06:37 --> Helper loaded: notification_helper
INFO - 2018-03-26 19:06:37 --> Helper loaded: settings_helper
INFO - 2018-03-26 19:06:37 --> Helper loaded: permission_helper
INFO - 2018-03-26 19:06:37 --> Helper loaded: users_helper
INFO - 2018-03-26 19:06:37 --> Database Driver Class Initialized
DEBUG - 2018-03-26 19:06:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 19:06:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 19:06:38 --> Helper loaded: form_helper
INFO - 2018-03-26 19:06:38 --> Form Validation Class Initialized
INFO - 2018-03-26 19:06:38 --> Controller Class Initialized
INFO - 2018-03-26 19:06:38 --> Model Class Initialized
INFO - 2018-03-26 19:06:38 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 19:06:38 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 19:06:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 19:06:38 --> Model Class Initialized
INFO - 2018-03-26 19:06:38 --> Model Class Initialized
INFO - 2018-03-26 19:06:38 --> Model Class Initialized
INFO - 2018-03-26 19:06:38 --> Model Class Initialized
INFO - 2018-03-26 19:06:38 --> Model Class Initialized
INFO - 2018-03-26 19:06:38 --> Model Class Initialized
INFO - 2018-03-26 19:06:38 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 19:06:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-26 19:06:38 --> Final output sent to browser
DEBUG - 2018-03-26 19:06:38 --> Total execution time: 2.8363
INFO - 2018-03-26 13:36:39 --> Config Class Initialized
INFO - 2018-03-26 13:36:39 --> Hooks Class Initialized
DEBUG - 2018-03-26 13:36:39 --> UTF-8 Support Enabled
INFO - 2018-03-26 13:36:39 --> Utf8 Class Initialized
INFO - 2018-03-26 13:36:39 --> URI Class Initialized
INFO - 2018-03-26 13:36:39 --> Router Class Initialized
INFO - 2018-03-26 13:36:39 --> Output Class Initialized
INFO - 2018-03-26 13:36:39 --> Security Class Initialized
DEBUG - 2018-03-26 13:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 13:36:39 --> Input Class Initialized
INFO - 2018-03-26 13:36:39 --> Language Class Initialized
INFO - 2018-03-26 13:36:39 --> Language Class Initialized
INFO - 2018-03-26 13:36:39 --> Config Class Initialized
INFO - 2018-03-26 13:36:39 --> Loader Class Initialized
INFO - 2018-03-26 19:06:39 --> Helper loaded: url_helper
INFO - 2018-03-26 19:06:39 --> Helper loaded: notification_helper
INFO - 2018-03-26 19:06:39 --> Helper loaded: settings_helper
INFO - 2018-03-26 19:06:39 --> Helper loaded: permission_helper
INFO - 2018-03-26 19:06:39 --> Helper loaded: users_helper
INFO - 2018-03-26 19:06:39 --> Database Driver Class Initialized
DEBUG - 2018-03-26 19:06:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 19:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 19:06:39 --> Helper loaded: form_helper
INFO - 2018-03-26 19:06:39 --> Form Validation Class Initialized
INFO - 2018-03-26 19:06:39 --> Controller Class Initialized
INFO - 2018-03-26 19:06:39 --> Model Class Initialized
INFO - 2018-03-26 19:06:39 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 19:06:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 19:06:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 19:06:39 --> Model Class Initialized
INFO - 2018-03-26 19:06:39 --> Model Class Initialized
INFO - 2018-03-26 19:06:39 --> Model Class Initialized
INFO - 2018-03-26 19:06:39 --> Model Class Initialized
INFO - 2018-03-26 19:06:39 --> Model Class Initialized
INFO - 2018-03-26 19:06:39 --> Model Class Initialized
INFO - 2018-03-26 19:06:39 --> Model Class Initialized
INFO - 2018-03-26 19:06:39 --> Model Class Initialized
INFO - 2018-03-26 19:06:39 --> Model Class Initialized
INFO - 2018-03-26 19:06:39 --> Model Class Initialized
INFO - 2018-03-26 19:06:39 --> Model Class Initialized
INFO - 2018-03-26 19:06:39 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 19:06:39 --> Model Class Initialized
INFO - 2018-03-26 19:06:39 --> Final output sent to browser
DEBUG - 2018-03-26 19:06:39 --> Total execution time: 0.2091
INFO - 2018-03-26 13:36:41 --> Config Class Initialized
INFO - 2018-03-26 13:36:41 --> Hooks Class Initialized
DEBUG - 2018-03-26 13:36:41 --> UTF-8 Support Enabled
INFO - 2018-03-26 13:36:41 --> Utf8 Class Initialized
INFO - 2018-03-26 13:36:41 --> URI Class Initialized
INFO - 2018-03-26 13:36:41 --> Router Class Initialized
INFO - 2018-03-26 13:36:41 --> Output Class Initialized
INFO - 2018-03-26 13:36:42 --> Security Class Initialized
DEBUG - 2018-03-26 13:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 13:36:42 --> Input Class Initialized
INFO - 2018-03-26 13:36:42 --> Language Class Initialized
INFO - 2018-03-26 13:36:42 --> Language Class Initialized
INFO - 2018-03-26 13:36:42 --> Config Class Initialized
INFO - 2018-03-26 13:36:42 --> Loader Class Initialized
INFO - 2018-03-26 19:06:42 --> Helper loaded: url_helper
INFO - 2018-03-26 19:06:42 --> Helper loaded: notification_helper
INFO - 2018-03-26 19:06:42 --> Helper loaded: settings_helper
INFO - 2018-03-26 19:06:42 --> Helper loaded: permission_helper
INFO - 2018-03-26 19:06:42 --> Helper loaded: users_helper
INFO - 2018-03-26 19:06:43 --> Database Driver Class Initialized
DEBUG - 2018-03-26 19:06:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 19:06:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 19:06:44 --> Helper loaded: form_helper
INFO - 2018-03-26 19:06:44 --> Form Validation Class Initialized
INFO - 2018-03-26 19:06:44 --> Controller Class Initialized
INFO - 2018-03-26 13:36:44 --> Config Class Initialized
INFO - 2018-03-26 13:36:44 --> Hooks Class Initialized
INFO - 2018-03-26 19:06:44 --> Model Class Initialized
INFO - 2018-03-26 19:06:44 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 13:36:44 --> UTF-8 Support Enabled
INFO - 2018-03-26 13:36:44 --> Utf8 Class Initialized
INFO - 2018-03-26 13:36:44 --> URI Class Initialized
INFO - 2018-03-26 13:36:44 --> Router Class Initialized
DEBUG - 2018-03-26 19:06:44 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 19:06:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 13:36:44 --> Output Class Initialized
INFO - 2018-03-26 13:36:44 --> Security Class Initialized
INFO - 2018-03-26 19:06:44 --> Model Class Initialized
INFO - 2018-03-26 19:06:44 --> Model Class Initialized
DEBUG - 2018-03-26 13:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 13:36:44 --> Input Class Initialized
INFO - 2018-03-26 13:36:44 --> Language Class Initialized
INFO - 2018-03-26 19:06:44 --> Model Class Initialized
INFO - 2018-03-26 19:06:44 --> Model Class Initialized
INFO - 2018-03-26 19:06:44 --> Model Class Initialized
INFO - 2018-03-26 19:06:44 --> Model Class Initialized
INFO - 2018-03-26 19:06:45 --> Model Class Initialized
INFO - 2018-03-26 19:06:45 --> Model Class Initialized
INFO - 2018-03-26 19:06:45 --> Model Class Initialized
INFO - 2018-03-26 19:06:45 --> Model Class Initialized
INFO - 2018-03-26 13:36:45 --> Language Class Initialized
INFO - 2018-03-26 13:36:45 --> Config Class Initialized
INFO - 2018-03-26 13:36:45 --> Loader Class Initialized
INFO - 2018-03-26 19:06:45 --> Model Class Initialized
INFO - 2018-03-26 19:06:45 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 19:06:45 --> Model Class Initialized
INFO - 2018-03-26 19:06:45 --> Helper loaded: url_helper
INFO - 2018-03-26 19:06:45 --> Helper loaded: notification_helper
INFO - 2018-03-26 19:06:45 --> Helper loaded: settings_helper
INFO - 2018-03-26 19:06:45 --> Helper loaded: permission_helper
INFO - 2018-03-26 19:06:45 --> Helper loaded: users_helper
INFO - 2018-03-26 19:06:45 --> Final output sent to browser
DEBUG - 2018-03-26 19:06:45 --> Total execution time: 4.3832
INFO - 2018-03-26 19:06:46 --> Database Driver Class Initialized
DEBUG - 2018-03-26 19:06:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 19:06:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 19:06:46 --> Helper loaded: form_helper
INFO - 2018-03-26 19:06:46 --> Form Validation Class Initialized
INFO - 2018-03-26 19:06:46 --> Controller Class Initialized
INFO - 2018-03-26 19:06:46 --> Model Class Initialized
INFO - 2018-03-26 19:06:46 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 19:06:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 19:06:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 19:06:46 --> Model Class Initialized
INFO - 2018-03-26 19:06:46 --> Model Class Initialized
INFO - 2018-03-26 19:06:46 --> Model Class Initialized
INFO - 2018-03-26 19:06:46 --> Model Class Initialized
INFO - 2018-03-26 19:06:46 --> Model Class Initialized
INFO - 2018-03-26 19:06:46 --> Model Class Initialized
INFO - 2018-03-26 19:06:46 --> Model Class Initialized
INFO - 2018-03-26 19:06:46 --> Model Class Initialized
INFO - 2018-03-26 19:06:46 --> Model Class Initialized
INFO - 2018-03-26 19:06:46 --> Model Class Initialized
INFO - 2018-03-26 19:06:46 --> Model Class Initialized
INFO - 2018-03-26 19:06:46 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 19:06:46 --> Model Class Initialized
INFO - 2018-03-26 19:06:46 --> Final output sent to browser
DEBUG - 2018-03-26 19:06:46 --> Total execution time: 2.3952
INFO - 2018-03-26 13:39:28 --> Config Class Initialized
INFO - 2018-03-26 13:39:28 --> Hooks Class Initialized
DEBUG - 2018-03-26 13:39:28 --> UTF-8 Support Enabled
INFO - 2018-03-26 13:39:28 --> Utf8 Class Initialized
INFO - 2018-03-26 13:39:28 --> URI Class Initialized
INFO - 2018-03-26 13:39:28 --> Router Class Initialized
INFO - 2018-03-26 13:39:28 --> Output Class Initialized
INFO - 2018-03-26 13:39:28 --> Security Class Initialized
DEBUG - 2018-03-26 13:39:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 13:39:28 --> Input Class Initialized
INFO - 2018-03-26 13:39:28 --> Language Class Initialized
INFO - 2018-03-26 13:39:28 --> Language Class Initialized
INFO - 2018-03-26 13:39:28 --> Config Class Initialized
INFO - 2018-03-26 13:39:28 --> Loader Class Initialized
INFO - 2018-03-26 19:09:28 --> Helper loaded: url_helper
INFO - 2018-03-26 19:09:28 --> Helper loaded: notification_helper
INFO - 2018-03-26 19:09:28 --> Helper loaded: settings_helper
INFO - 2018-03-26 19:09:28 --> Helper loaded: permission_helper
INFO - 2018-03-26 19:09:28 --> Helper loaded: users_helper
INFO - 2018-03-26 19:09:28 --> Database Driver Class Initialized
DEBUG - 2018-03-26 19:09:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 19:09:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 19:09:28 --> Helper loaded: form_helper
INFO - 2018-03-26 19:09:28 --> Form Validation Class Initialized
INFO - 2018-03-26 19:09:28 --> Controller Class Initialized
INFO - 2018-03-26 19:09:28 --> Model Class Initialized
INFO - 2018-03-26 19:09:28 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 19:09:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 19:09:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 19:09:28 --> Model Class Initialized
INFO - 2018-03-26 19:09:28 --> Model Class Initialized
INFO - 2018-03-26 19:09:28 --> Model Class Initialized
INFO - 2018-03-26 19:09:28 --> Model Class Initialized
INFO - 2018-03-26 19:09:28 --> Model Class Initialized
INFO - 2018-03-26 19:09:28 --> Model Class Initialized
INFO - 2018-03-26 19:09:28 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 19:09:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-26 19:09:28 --> Final output sent to browser
DEBUG - 2018-03-26 19:09:28 --> Total execution time: 0.1250
INFO - 2018-03-26 13:39:29 --> Config Class Initialized
INFO - 2018-03-26 13:39:29 --> Hooks Class Initialized
DEBUG - 2018-03-26 13:39:29 --> UTF-8 Support Enabled
INFO - 2018-03-26 13:39:29 --> Utf8 Class Initialized
INFO - 2018-03-26 13:39:29 --> URI Class Initialized
INFO - 2018-03-26 13:39:29 --> Router Class Initialized
INFO - 2018-03-26 13:39:29 --> Output Class Initialized
INFO - 2018-03-26 13:39:30 --> Security Class Initialized
DEBUG - 2018-03-26 13:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 13:39:30 --> Input Class Initialized
INFO - 2018-03-26 13:39:30 --> Language Class Initialized
INFO - 2018-03-26 13:39:30 --> Language Class Initialized
INFO - 2018-03-26 13:39:30 --> Config Class Initialized
INFO - 2018-03-26 13:39:30 --> Loader Class Initialized
INFO - 2018-03-26 19:09:30 --> Helper loaded: url_helper
INFO - 2018-03-26 19:09:30 --> Helper loaded: notification_helper
INFO - 2018-03-26 19:09:30 --> Helper loaded: settings_helper
INFO - 2018-03-26 19:09:30 --> Helper loaded: permission_helper
INFO - 2018-03-26 19:09:30 --> Helper loaded: users_helper
INFO - 2018-03-26 19:09:30 --> Database Driver Class Initialized
DEBUG - 2018-03-26 19:09:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 19:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 19:09:30 --> Helper loaded: form_helper
INFO - 2018-03-26 19:09:30 --> Form Validation Class Initialized
INFO - 2018-03-26 19:09:30 --> Controller Class Initialized
INFO - 2018-03-26 19:09:30 --> Model Class Initialized
INFO - 2018-03-26 19:09:30 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 19:09:30 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 19:09:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 19:09:30 --> Model Class Initialized
INFO - 2018-03-26 19:09:30 --> Model Class Initialized
INFO - 2018-03-26 19:09:30 --> Model Class Initialized
INFO - 2018-03-26 19:09:30 --> Model Class Initialized
INFO - 2018-03-26 19:09:30 --> Model Class Initialized
INFO - 2018-03-26 19:09:30 --> Model Class Initialized
INFO - 2018-03-26 19:09:30 --> Model Class Initialized
INFO - 2018-03-26 19:09:30 --> Model Class Initialized
INFO - 2018-03-26 19:09:30 --> Model Class Initialized
INFO - 2018-03-26 19:09:30 --> Model Class Initialized
INFO - 2018-03-26 19:09:30 --> Model Class Initialized
INFO - 2018-03-26 19:09:30 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 19:09:30 --> Model Class Initialized
INFO - 2018-03-26 19:09:30 --> Final output sent to browser
DEBUG - 2018-03-26 19:09:30 --> Total execution time: 0.5496
INFO - 2018-03-26 13:39:31 --> Config Class Initialized
INFO - 2018-03-26 13:39:31 --> Hooks Class Initialized
DEBUG - 2018-03-26 13:39:31 --> UTF-8 Support Enabled
INFO - 2018-03-26 13:39:31 --> Utf8 Class Initialized
INFO - 2018-03-26 13:39:31 --> URI Class Initialized
INFO - 2018-03-26 13:39:31 --> Router Class Initialized
INFO - 2018-03-26 13:39:31 --> Output Class Initialized
INFO - 2018-03-26 13:39:31 --> Security Class Initialized
DEBUG - 2018-03-26 13:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 13:39:31 --> Input Class Initialized
INFO - 2018-03-26 13:39:31 --> Language Class Initialized
INFO - 2018-03-26 13:39:31 --> Language Class Initialized
INFO - 2018-03-26 13:39:31 --> Config Class Initialized
INFO - 2018-03-26 13:39:31 --> Loader Class Initialized
INFO - 2018-03-26 19:09:31 --> Helper loaded: url_helper
INFO - 2018-03-26 19:09:31 --> Helper loaded: notification_helper
INFO - 2018-03-26 19:09:31 --> Helper loaded: settings_helper
INFO - 2018-03-26 19:09:31 --> Helper loaded: permission_helper
INFO - 2018-03-26 19:09:31 --> Helper loaded: users_helper
INFO - 2018-03-26 19:09:32 --> Database Driver Class Initialized
DEBUG - 2018-03-26 19:09:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 19:09:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 19:09:32 --> Helper loaded: form_helper
INFO - 2018-03-26 19:09:32 --> Form Validation Class Initialized
INFO - 2018-03-26 19:09:32 --> Controller Class Initialized
INFO - 2018-03-26 13:39:32 --> Config Class Initialized
INFO - 2018-03-26 13:39:32 --> Hooks Class Initialized
DEBUG - 2018-03-26 13:39:32 --> UTF-8 Support Enabled
INFO - 2018-03-26 13:39:32 --> Utf8 Class Initialized
INFO - 2018-03-26 13:39:32 --> URI Class Initialized
INFO - 2018-03-26 13:39:32 --> Router Class Initialized
INFO - 2018-03-26 13:39:32 --> Output Class Initialized
INFO - 2018-03-26 13:39:32 --> Security Class Initialized
DEBUG - 2018-03-26 13:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 13:39:32 --> Input Class Initialized
INFO - 2018-03-26 13:39:32 --> Language Class Initialized
INFO - 2018-03-26 13:39:33 --> Language Class Initialized
INFO - 2018-03-26 13:39:33 --> Config Class Initialized
INFO - 2018-03-26 13:39:33 --> Loader Class Initialized
INFO - 2018-03-26 19:09:33 --> Helper loaded: url_helper
INFO - 2018-03-26 19:09:33 --> Helper loaded: notification_helper
INFO - 2018-03-26 19:09:33 --> Helper loaded: settings_helper
INFO - 2018-03-26 19:09:33 --> Helper loaded: permission_helper
INFO - 2018-03-26 19:09:33 --> Helper loaded: users_helper
INFO - 2018-03-26 19:09:33 --> Database Driver Class Initialized
DEBUG - 2018-03-26 19:09:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 19:09:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 19:09:33 --> Helper loaded: form_helper
INFO - 2018-03-26 19:09:33 --> Form Validation Class Initialized
INFO - 2018-03-26 19:09:33 --> Controller Class Initialized
INFO - 2018-03-26 19:09:33 --> Model Class Initialized
INFO - 2018-03-26 19:09:33 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 19:09:33 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 19:09:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 19:09:33 --> Model Class Initialized
INFO - 2018-03-26 19:09:33 --> Model Class Initialized
INFO - 2018-03-26 19:09:33 --> Model Class Initialized
INFO - 2018-03-26 19:09:33 --> Model Class Initialized
INFO - 2018-03-26 19:09:33 --> Model Class Initialized
INFO - 2018-03-26 19:09:33 --> Model Class Initialized
INFO - 2018-03-26 19:09:33 --> Model Class Initialized
INFO - 2018-03-26 19:09:33 --> Model Class Initialized
INFO - 2018-03-26 19:09:33 --> Model Class Initialized
INFO - 2018-03-26 19:09:33 --> Model Class Initialized
INFO - 2018-03-26 19:09:33 --> Model Class Initialized
INFO - 2018-03-26 19:09:33 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 19:09:33 --> Model Class Initialized
INFO - 2018-03-26 19:09:33 --> Final output sent to browser
DEBUG - 2018-03-26 19:09:33 --> Total execution time: 0.3730
INFO - 2018-03-26 19:09:33 --> Model Class Initialized
INFO - 2018-03-26 19:09:33 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 19:09:33 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 19:09:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 19:09:33 --> Model Class Initialized
INFO - 2018-03-26 19:09:33 --> Model Class Initialized
INFO - 2018-03-26 19:09:33 --> Model Class Initialized
INFO - 2018-03-26 19:09:33 --> Model Class Initialized
INFO - 2018-03-26 19:09:33 --> Model Class Initialized
INFO - 2018-03-26 19:09:33 --> Model Class Initialized
INFO - 2018-03-26 19:09:33 --> Model Class Initialized
INFO - 2018-03-26 19:09:33 --> Model Class Initialized
INFO - 2018-03-26 19:09:33 --> Model Class Initialized
INFO - 2018-03-26 19:09:33 --> Model Class Initialized
INFO - 2018-03-26 19:09:33 --> Model Class Initialized
INFO - 2018-03-26 19:09:33 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 19:09:33 --> Model Class Initialized
INFO - 2018-03-26 19:09:34 --> Final output sent to browser
DEBUG - 2018-03-26 19:09:34 --> Total execution time: 3.5598
INFO - 2018-03-26 13:45:00 --> Config Class Initialized
INFO - 2018-03-26 13:45:00 --> Hooks Class Initialized
DEBUG - 2018-03-26 13:45:00 --> UTF-8 Support Enabled
INFO - 2018-03-26 13:45:00 --> Utf8 Class Initialized
INFO - 2018-03-26 13:45:00 --> URI Class Initialized
INFO - 2018-03-26 13:45:00 --> Router Class Initialized
INFO - 2018-03-26 13:45:00 --> Output Class Initialized
INFO - 2018-03-26 13:45:00 --> Security Class Initialized
DEBUG - 2018-03-26 13:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 13:45:00 --> Input Class Initialized
INFO - 2018-03-26 13:45:00 --> Language Class Initialized
INFO - 2018-03-26 13:45:01 --> Language Class Initialized
INFO - 2018-03-26 13:45:01 --> Config Class Initialized
INFO - 2018-03-26 13:45:01 --> Loader Class Initialized
INFO - 2018-03-26 19:15:01 --> Helper loaded: url_helper
INFO - 2018-03-26 19:15:01 --> Helper loaded: notification_helper
INFO - 2018-03-26 19:15:01 --> Helper loaded: settings_helper
INFO - 2018-03-26 19:15:01 --> Helper loaded: permission_helper
INFO - 2018-03-26 19:15:01 --> Helper loaded: users_helper
INFO - 2018-03-26 19:15:02 --> Database Driver Class Initialized
DEBUG - 2018-03-26 19:15:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 19:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 19:15:02 --> Helper loaded: form_helper
INFO - 2018-03-26 19:15:02 --> Form Validation Class Initialized
INFO - 2018-03-26 19:15:02 --> Controller Class Initialized
INFO - 2018-03-26 19:15:02 --> Model Class Initialized
INFO - 2018-03-26 19:15:02 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 19:15:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 19:15:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 19:15:03 --> Model Class Initialized
INFO - 2018-03-26 19:15:03 --> Model Class Initialized
INFO - 2018-03-26 19:15:03 --> Model Class Initialized
INFO - 2018-03-26 19:15:03 --> Model Class Initialized
INFO - 2018-03-26 19:15:03 --> Model Class Initialized
INFO - 2018-03-26 19:15:03 --> Model Class Initialized
INFO - 2018-03-26 19:15:03 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 19:15:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-26 19:15:03 --> Final output sent to browser
DEBUG - 2018-03-26 19:15:03 --> Total execution time: 2.6126
INFO - 2018-03-26 13:45:03 --> Config Class Initialized
INFO - 2018-03-26 13:45:03 --> Hooks Class Initialized
DEBUG - 2018-03-26 13:45:03 --> UTF-8 Support Enabled
INFO - 2018-03-26 13:45:03 --> Utf8 Class Initialized
INFO - 2018-03-26 13:45:03 --> URI Class Initialized
INFO - 2018-03-26 13:45:03 --> Router Class Initialized
INFO - 2018-03-26 13:45:03 --> Output Class Initialized
INFO - 2018-03-26 13:45:03 --> Security Class Initialized
DEBUG - 2018-03-26 13:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 13:45:03 --> Input Class Initialized
INFO - 2018-03-26 13:45:03 --> Language Class Initialized
INFO - 2018-03-26 13:45:03 --> Language Class Initialized
INFO - 2018-03-26 13:45:03 --> Config Class Initialized
INFO - 2018-03-26 13:45:03 --> Loader Class Initialized
INFO - 2018-03-26 19:15:03 --> Helper loaded: url_helper
INFO - 2018-03-26 19:15:03 --> Helper loaded: notification_helper
INFO - 2018-03-26 19:15:03 --> Helper loaded: settings_helper
INFO - 2018-03-26 19:15:03 --> Helper loaded: permission_helper
INFO - 2018-03-26 19:15:03 --> Helper loaded: users_helper
INFO - 2018-03-26 19:15:03 --> Database Driver Class Initialized
DEBUG - 2018-03-26 19:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 19:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 19:15:03 --> Helper loaded: form_helper
INFO - 2018-03-26 19:15:03 --> Form Validation Class Initialized
INFO - 2018-03-26 19:15:03 --> Controller Class Initialized
INFO - 2018-03-26 19:15:03 --> Model Class Initialized
INFO - 2018-03-26 19:15:03 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 19:15:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 19:15:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 19:15:03 --> Model Class Initialized
INFO - 2018-03-26 19:15:03 --> Model Class Initialized
INFO - 2018-03-26 19:15:03 --> Model Class Initialized
INFO - 2018-03-26 19:15:03 --> Model Class Initialized
INFO - 2018-03-26 19:15:03 --> Model Class Initialized
INFO - 2018-03-26 19:15:03 --> Model Class Initialized
INFO - 2018-03-26 19:15:03 --> Model Class Initialized
INFO - 2018-03-26 19:15:03 --> Model Class Initialized
INFO - 2018-03-26 19:15:03 --> Model Class Initialized
INFO - 2018-03-26 19:15:03 --> Model Class Initialized
INFO - 2018-03-26 19:15:03 --> Model Class Initialized
INFO - 2018-03-26 19:15:03 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 19:15:03 --> Model Class Initialized
INFO - 2018-03-26 19:15:03 --> Final output sent to browser
DEBUG - 2018-03-26 19:15:03 --> Total execution time: 0.0979
INFO - 2018-03-26 13:45:04 --> Config Class Initialized
INFO - 2018-03-26 13:45:04 --> Hooks Class Initialized
DEBUG - 2018-03-26 13:45:04 --> UTF-8 Support Enabled
INFO - 2018-03-26 13:45:04 --> Utf8 Class Initialized
INFO - 2018-03-26 13:45:04 --> URI Class Initialized
INFO - 2018-03-26 13:45:04 --> Router Class Initialized
INFO - 2018-03-26 13:45:04 --> Output Class Initialized
INFO - 2018-03-26 13:45:04 --> Security Class Initialized
DEBUG - 2018-03-26 13:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 13:45:04 --> Input Class Initialized
INFO - 2018-03-26 13:45:04 --> Language Class Initialized
INFO - 2018-03-26 13:45:04 --> Language Class Initialized
INFO - 2018-03-26 13:45:04 --> Config Class Initialized
INFO - 2018-03-26 13:45:04 --> Loader Class Initialized
INFO - 2018-03-26 19:15:04 --> Helper loaded: url_helper
INFO - 2018-03-26 19:15:04 --> Helper loaded: notification_helper
INFO - 2018-03-26 19:15:04 --> Helper loaded: settings_helper
INFO - 2018-03-26 19:15:04 --> Helper loaded: permission_helper
INFO - 2018-03-26 19:15:04 --> Helper loaded: users_helper
INFO - 2018-03-26 19:15:05 --> Database Driver Class Initialized
DEBUG - 2018-03-26 19:15:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 19:15:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 19:15:05 --> Helper loaded: form_helper
INFO - 2018-03-26 19:15:05 --> Form Validation Class Initialized
INFO - 2018-03-26 19:15:05 --> Controller Class Initialized
INFO - 2018-03-26 19:15:05 --> Model Class Initialized
INFO - 2018-03-26 19:15:05 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 19:15:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 19:15:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 19:15:05 --> Model Class Initialized
INFO - 2018-03-26 19:15:05 --> Model Class Initialized
INFO - 2018-03-26 19:15:05 --> Model Class Initialized
INFO - 2018-03-26 19:15:05 --> Model Class Initialized
INFO - 2018-03-26 19:15:05 --> Model Class Initialized
INFO - 2018-03-26 19:15:05 --> Model Class Initialized
INFO - 2018-03-26 19:15:05 --> Model Class Initialized
INFO - 2018-03-26 19:15:05 --> Model Class Initialized
INFO - 2018-03-26 19:15:05 --> Model Class Initialized
INFO - 2018-03-26 19:15:05 --> Model Class Initialized
INFO - 2018-03-26 19:15:05 --> Model Class Initialized
INFO - 2018-03-26 19:15:05 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 19:15:05 --> Model Class Initialized
INFO - 2018-03-26 19:15:05 --> Final output sent to browser
DEBUG - 2018-03-26 19:15:05 --> Total execution time: 0.4577
INFO - 2018-03-26 13:49:05 --> Config Class Initialized
INFO - 2018-03-26 13:49:05 --> Hooks Class Initialized
DEBUG - 2018-03-26 13:49:05 --> UTF-8 Support Enabled
INFO - 2018-03-26 13:49:05 --> Utf8 Class Initialized
INFO - 2018-03-26 13:49:05 --> URI Class Initialized
INFO - 2018-03-26 13:49:05 --> Router Class Initialized
INFO - 2018-03-26 13:49:05 --> Output Class Initialized
INFO - 2018-03-26 13:49:05 --> Security Class Initialized
DEBUG - 2018-03-26 13:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 13:49:05 --> Input Class Initialized
INFO - 2018-03-26 13:49:05 --> Language Class Initialized
INFO - 2018-03-26 13:49:05 --> Language Class Initialized
INFO - 2018-03-26 13:49:05 --> Config Class Initialized
INFO - 2018-03-26 13:49:05 --> Loader Class Initialized
INFO - 2018-03-26 19:19:05 --> Helper loaded: url_helper
INFO - 2018-03-26 19:19:05 --> Helper loaded: notification_helper
INFO - 2018-03-26 19:19:05 --> Helper loaded: settings_helper
INFO - 2018-03-26 19:19:05 --> Helper loaded: permission_helper
INFO - 2018-03-26 19:19:05 --> Helper loaded: users_helper
INFO - 2018-03-26 19:19:05 --> Database Driver Class Initialized
DEBUG - 2018-03-26 19:19:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 19:19:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 19:19:05 --> Helper loaded: form_helper
INFO - 2018-03-26 19:19:05 --> Form Validation Class Initialized
INFO - 2018-03-26 19:19:05 --> Controller Class Initialized
INFO - 2018-03-26 19:19:05 --> Model Class Initialized
INFO - 2018-03-26 19:19:05 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 19:19:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 19:19:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 19:19:05 --> Model Class Initialized
INFO - 2018-03-26 19:19:05 --> Model Class Initialized
INFO - 2018-03-26 19:19:05 --> Model Class Initialized
INFO - 2018-03-26 19:19:05 --> Model Class Initialized
INFO - 2018-03-26 19:19:05 --> Model Class Initialized
INFO - 2018-03-26 19:19:05 --> Model Class Initialized
INFO - 2018-03-26 19:19:05 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 19:19:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-26 19:19:05 --> Final output sent to browser
DEBUG - 2018-03-26 19:19:05 --> Total execution time: 0.5300
INFO - 2018-03-26 13:49:07 --> Config Class Initialized
INFO - 2018-03-26 13:49:07 --> Hooks Class Initialized
DEBUG - 2018-03-26 13:49:08 --> UTF-8 Support Enabled
INFO - 2018-03-26 13:49:08 --> Utf8 Class Initialized
INFO - 2018-03-26 13:49:08 --> URI Class Initialized
INFO - 2018-03-26 13:49:08 --> Router Class Initialized
INFO - 2018-03-26 13:49:08 --> Output Class Initialized
INFO - 2018-03-26 13:49:08 --> Security Class Initialized
DEBUG - 2018-03-26 13:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 13:49:08 --> Input Class Initialized
INFO - 2018-03-26 13:49:09 --> Language Class Initialized
INFO - 2018-03-26 13:49:09 --> Config Class Initialized
INFO - 2018-03-26 13:49:09 --> Hooks Class Initialized
DEBUG - 2018-03-26 13:49:09 --> UTF-8 Support Enabled
INFO - 2018-03-26 13:49:09 --> Utf8 Class Initialized
INFO - 2018-03-26 13:49:09 --> URI Class Initialized
INFO - 2018-03-26 13:49:09 --> Router Class Initialized
INFO - 2018-03-26 13:49:09 --> Output Class Initialized
INFO - 2018-03-26 13:49:09 --> Security Class Initialized
DEBUG - 2018-03-26 13:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 13:49:09 --> Input Class Initialized
INFO - 2018-03-26 13:49:09 --> Language Class Initialized
INFO - 2018-03-26 13:49:09 --> Config Class Initialized
INFO - 2018-03-26 13:49:09 --> Hooks Class Initialized
DEBUG - 2018-03-26 13:49:09 --> UTF-8 Support Enabled
INFO - 2018-03-26 13:49:09 --> Utf8 Class Initialized
INFO - 2018-03-26 13:49:09 --> URI Class Initialized
INFO - 2018-03-26 13:49:09 --> Router Class Initialized
INFO - 2018-03-26 13:49:09 --> Output Class Initialized
INFO - 2018-03-26 13:49:09 --> Security Class Initialized
DEBUG - 2018-03-26 13:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 13:49:09 --> Input Class Initialized
INFO - 2018-03-26 13:49:09 --> Language Class Initialized
INFO - 2018-03-26 13:49:09 --> Language Class Initialized
INFO - 2018-03-26 13:49:09 --> Config Class Initialized
INFO - 2018-03-26 13:49:09 --> Loader Class Initialized
INFO - 2018-03-26 19:19:09 --> Helper loaded: url_helper
INFO - 2018-03-26 19:19:09 --> Helper loaded: notification_helper
INFO - 2018-03-26 19:19:09 --> Helper loaded: settings_helper
INFO - 2018-03-26 19:19:09 --> Helper loaded: permission_helper
INFO - 2018-03-26 19:19:09 --> Helper loaded: users_helper
INFO - 2018-03-26 19:19:09 --> Database Driver Class Initialized
DEBUG - 2018-03-26 19:19:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 19:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 19:19:09 --> Helper loaded: form_helper
INFO - 2018-03-26 19:19:09 --> Form Validation Class Initialized
INFO - 2018-03-26 19:19:09 --> Controller Class Initialized
INFO - 2018-03-26 19:19:09 --> Model Class Initialized
INFO - 2018-03-26 19:19:09 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 19:19:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 19:19:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 19:19:09 --> Model Class Initialized
INFO - 2018-03-26 19:19:09 --> Model Class Initialized
INFO - 2018-03-26 19:19:09 --> Model Class Initialized
INFO - 2018-03-26 19:19:09 --> Model Class Initialized
INFO - 2018-03-26 19:19:09 --> Model Class Initialized
INFO - 2018-03-26 19:19:09 --> Model Class Initialized
INFO - 2018-03-26 19:19:09 --> Model Class Initialized
INFO - 2018-03-26 19:19:09 --> Model Class Initialized
INFO - 2018-03-26 19:19:09 --> Model Class Initialized
INFO - 2018-03-26 19:19:09 --> Model Class Initialized
INFO - 2018-03-26 19:19:09 --> Model Class Initialized
INFO - 2018-03-26 19:19:09 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 19:19:09 --> Model Class Initialized
INFO - 2018-03-26 19:19:09 --> Final output sent to browser
DEBUG - 2018-03-26 19:19:09 --> Total execution time: 0.1170
INFO - 2018-03-26 13:49:09 --> Language Class Initialized
INFO - 2018-03-26 13:49:09 --> Config Class Initialized
INFO - 2018-03-26 13:49:09 --> Loader Class Initialized
INFO - 2018-03-26 19:19:10 --> Helper loaded: url_helper
INFO - 2018-03-26 19:19:10 --> Helper loaded: notification_helper
INFO - 2018-03-26 19:19:10 --> Helper loaded: settings_helper
INFO - 2018-03-26 19:19:10 --> Helper loaded: permission_helper
INFO - 2018-03-26 19:19:10 --> Helper loaded: users_helper
INFO - 2018-03-26 13:49:10 --> Language Class Initialized
INFO - 2018-03-26 13:49:10 --> Config Class Initialized
INFO - 2018-03-26 13:49:10 --> Loader Class Initialized
INFO - 2018-03-26 19:19:10 --> Helper loaded: url_helper
INFO - 2018-03-26 19:19:11 --> Helper loaded: notification_helper
INFO - 2018-03-26 19:19:11 --> Helper loaded: settings_helper
INFO - 2018-03-26 19:19:11 --> Database Driver Class Initialized
INFO - 2018-03-26 19:19:11 --> Helper loaded: permission_helper
DEBUG - 2018-03-26 19:19:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 19:19:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 19:19:11 --> Helper loaded: users_helper
INFO - 2018-03-26 19:19:11 --> Helper loaded: form_helper
INFO - 2018-03-26 19:19:11 --> Form Validation Class Initialized
INFO - 2018-03-26 19:19:11 --> Controller Class Initialized
INFO - 2018-03-26 19:19:11 --> Model Class Initialized
INFO - 2018-03-26 19:19:11 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 19:19:11 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 19:19:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 19:19:11 --> Model Class Initialized
INFO - 2018-03-26 19:19:11 --> Model Class Initialized
INFO - 2018-03-26 19:19:11 --> Model Class Initialized
INFO - 2018-03-26 19:19:11 --> Model Class Initialized
INFO - 2018-03-26 19:19:11 --> Model Class Initialized
INFO - 2018-03-26 19:19:11 --> Model Class Initialized
INFO - 2018-03-26 19:19:11 --> Model Class Initialized
INFO - 2018-03-26 19:19:11 --> Model Class Initialized
INFO - 2018-03-26 19:19:11 --> Model Class Initialized
INFO - 2018-03-26 19:19:11 --> Model Class Initialized
INFO - 2018-03-26 19:19:11 --> Model Class Initialized
INFO - 2018-03-26 19:19:11 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 19:19:11 --> Model Class Initialized
INFO - 2018-03-26 19:19:11 --> Final output sent to browser
DEBUG - 2018-03-26 19:19:11 --> Total execution time: 4.3187
INFO - 2018-03-26 19:19:11 --> Database Driver Class Initialized
DEBUG - 2018-03-26 19:19:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 19:19:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 19:19:11 --> Helper loaded: form_helper
INFO - 2018-03-26 19:19:11 --> Form Validation Class Initialized
INFO - 2018-03-26 19:19:11 --> Controller Class Initialized
INFO - 2018-03-26 19:19:11 --> Model Class Initialized
INFO - 2018-03-26 19:19:11 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 19:19:11 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 19:19:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 19:19:11 --> Model Class Initialized
INFO - 2018-03-26 19:19:11 --> Model Class Initialized
INFO - 2018-03-26 19:19:11 --> Model Class Initialized
INFO - 2018-03-26 19:19:11 --> Model Class Initialized
INFO - 2018-03-26 19:19:11 --> Model Class Initialized
INFO - 2018-03-26 19:19:11 --> Model Class Initialized
INFO - 2018-03-26 19:19:11 --> Model Class Initialized
INFO - 2018-03-26 19:19:11 --> Model Class Initialized
INFO - 2018-03-26 19:19:11 --> Model Class Initialized
INFO - 2018-03-26 19:19:11 --> Model Class Initialized
INFO - 2018-03-26 19:19:11 --> Model Class Initialized
INFO - 2018-03-26 19:19:11 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 19:19:11 --> Model Class Initialized
INFO - 2018-03-26 19:19:11 --> Final output sent to browser
DEBUG - 2018-03-26 19:19:11 --> Total execution time: 2.6540
INFO - 2018-03-26 13:49:11 --> Config Class Initialized
INFO - 2018-03-26 13:49:11 --> Hooks Class Initialized
DEBUG - 2018-03-26 13:49:11 --> UTF-8 Support Enabled
INFO - 2018-03-26 13:49:11 --> Utf8 Class Initialized
INFO - 2018-03-26 13:49:11 --> URI Class Initialized
INFO - 2018-03-26 13:49:11 --> Router Class Initialized
INFO - 2018-03-26 13:49:11 --> Output Class Initialized
INFO - 2018-03-26 13:49:11 --> Security Class Initialized
DEBUG - 2018-03-26 13:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 13:49:12 --> Input Class Initialized
INFO - 2018-03-26 13:49:12 --> Language Class Initialized
INFO - 2018-03-26 13:49:12 --> Language Class Initialized
INFO - 2018-03-26 13:49:12 --> Config Class Initialized
INFO - 2018-03-26 13:49:12 --> Loader Class Initialized
INFO - 2018-03-26 19:19:12 --> Helper loaded: url_helper
INFO - 2018-03-26 19:19:12 --> Helper loaded: notification_helper
INFO - 2018-03-26 19:19:12 --> Helper loaded: settings_helper
INFO - 2018-03-26 19:19:12 --> Helper loaded: permission_helper
INFO - 2018-03-26 19:19:12 --> Helper loaded: users_helper
INFO - 2018-03-26 19:19:12 --> Database Driver Class Initialized
DEBUG - 2018-03-26 19:19:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 19:19:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 19:19:13 --> Helper loaded: form_helper
INFO - 2018-03-26 19:19:13 --> Form Validation Class Initialized
INFO - 2018-03-26 19:19:13 --> Controller Class Initialized
INFO - 2018-03-26 19:19:13 --> Model Class Initialized
INFO - 2018-03-26 19:19:13 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 19:19:14 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 19:19:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 19:19:14 --> Model Class Initialized
INFO - 2018-03-26 19:19:14 --> Model Class Initialized
INFO - 2018-03-26 19:19:14 --> Model Class Initialized
INFO - 2018-03-26 19:19:14 --> Model Class Initialized
INFO - 2018-03-26 19:19:14 --> Model Class Initialized
INFO - 2018-03-26 19:19:14 --> Model Class Initialized
INFO - 2018-03-26 19:19:14 --> Model Class Initialized
INFO - 2018-03-26 19:19:14 --> Model Class Initialized
INFO - 2018-03-26 19:19:14 --> Model Class Initialized
INFO - 2018-03-26 19:19:14 --> Model Class Initialized
INFO - 2018-03-26 19:19:14 --> Model Class Initialized
INFO - 2018-03-26 19:19:14 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 19:19:14 --> Model Class Initialized
INFO - 2018-03-26 19:19:14 --> Final output sent to browser
DEBUG - 2018-03-26 19:19:14 --> Total execution time: 2.8829
INFO - 2018-03-26 13:49:42 --> Config Class Initialized
INFO - 2018-03-26 13:49:42 --> Hooks Class Initialized
DEBUG - 2018-03-26 13:49:42 --> UTF-8 Support Enabled
INFO - 2018-03-26 13:49:42 --> Utf8 Class Initialized
INFO - 2018-03-26 13:49:42 --> URI Class Initialized
INFO - 2018-03-26 13:49:43 --> Router Class Initialized
INFO - 2018-03-26 13:49:43 --> Output Class Initialized
INFO - 2018-03-26 13:49:43 --> Security Class Initialized
DEBUG - 2018-03-26 13:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 13:49:43 --> Input Class Initialized
INFO - 2018-03-26 13:49:43 --> Language Class Initialized
INFO - 2018-03-26 13:49:44 --> Language Class Initialized
INFO - 2018-03-26 13:49:44 --> Config Class Initialized
INFO - 2018-03-26 13:49:44 --> Loader Class Initialized
INFO - 2018-03-26 19:19:44 --> Helper loaded: url_helper
INFO - 2018-03-26 19:19:44 --> Helper loaded: notification_helper
INFO - 2018-03-26 19:19:44 --> Helper loaded: settings_helper
INFO - 2018-03-26 19:19:44 --> Helper loaded: permission_helper
INFO - 2018-03-26 19:19:44 --> Helper loaded: users_helper
INFO - 2018-03-26 19:19:44 --> Database Driver Class Initialized
DEBUG - 2018-03-26 19:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 19:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 19:19:45 --> Helper loaded: form_helper
INFO - 2018-03-26 19:19:45 --> Form Validation Class Initialized
INFO - 2018-03-26 19:19:45 --> Controller Class Initialized
INFO - 2018-03-26 19:19:45 --> Model Class Initialized
INFO - 2018-03-26 19:19:45 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 19:19:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 19:19:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 19:19:45 --> Model Class Initialized
INFO - 2018-03-26 19:19:46 --> Model Class Initialized
INFO - 2018-03-26 19:19:46 --> Model Class Initialized
INFO - 2018-03-26 19:19:46 --> Model Class Initialized
INFO - 2018-03-26 19:19:46 --> Model Class Initialized
INFO - 2018-03-26 19:19:46 --> Model Class Initialized
INFO - 2018-03-26 19:19:46 --> Model Class Initialized
INFO - 2018-03-26 19:19:46 --> Model Class Initialized
INFO - 2018-03-26 19:19:46 --> Model Class Initialized
INFO - 2018-03-26 19:19:46 --> Model Class Initialized
INFO - 2018-03-26 13:49:46 --> Config Class Initialized
INFO - 2018-03-26 13:49:46 --> Hooks Class Initialized
DEBUG - 2018-03-26 13:49:46 --> UTF-8 Support Enabled
INFO - 2018-03-26 13:49:46 --> Utf8 Class Initialized
INFO - 2018-03-26 13:49:46 --> URI Class Initialized
INFO - 2018-03-26 13:49:46 --> Router Class Initialized
INFO - 2018-03-26 13:49:46 --> Output Class Initialized
INFO - 2018-03-26 13:49:46 --> Security Class Initialized
DEBUG - 2018-03-26 13:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 13:49:46 --> Input Class Initialized
INFO - 2018-03-26 13:49:46 --> Language Class Initialized
INFO - 2018-03-26 13:49:46 --> Language Class Initialized
INFO - 2018-03-26 13:49:46 --> Config Class Initialized
INFO - 2018-03-26 13:49:46 --> Loader Class Initialized
INFO - 2018-03-26 19:19:46 --> Helper loaded: url_helper
INFO - 2018-03-26 19:19:46 --> Helper loaded: notification_helper
INFO - 2018-03-26 19:19:46 --> Helper loaded: settings_helper
INFO - 2018-03-26 19:19:46 --> Helper loaded: permission_helper
INFO - 2018-03-26 19:19:46 --> Helper loaded: users_helper
INFO - 2018-03-26 19:19:46 --> Database Driver Class Initialized
DEBUG - 2018-03-26 19:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 19:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 19:19:46 --> Helper loaded: form_helper
INFO - 2018-03-26 19:19:46 --> Form Validation Class Initialized
INFO - 2018-03-26 19:19:46 --> Controller Class Initialized
INFO - 2018-03-26 19:19:46 --> Model Class Initialized
INFO - 2018-03-26 19:19:46 --> Helper loaded: inflector_helper
INFO - 2018-03-26 19:19:46 --> Model Class Initialized
DEBUG - 2018-03-26 19:19:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 19:19:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 19:19:46 --> Model Class Initialized
INFO - 2018-03-26 19:19:46 --> Model Class Initialized
INFO - 2018-03-26 19:19:46 --> Model Class Initialized
INFO - 2018-03-26 19:19:46 --> Model Class Initialized
INFO - 2018-03-26 19:19:46 --> Model Class Initialized
INFO - 2018-03-26 19:19:46 --> Model Class Initialized
INFO - 2018-03-26 19:19:46 --> Model Class Initialized
INFO - 2018-03-26 19:19:46 --> Model Class Initialized
INFO - 2018-03-26 19:19:46 --> Model Class Initialized
INFO - 2018-03-26 19:19:46 --> Model Class Initialized
INFO - 2018-03-26 19:19:46 --> Model Class Initialized
INFO - 2018-03-26 19:19:46 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 19:19:46 --> Model Class Initialized
INFO - 2018-03-26 19:19:46 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 19:19:46 --> Final output sent to browser
DEBUG - 2018-03-26 19:19:46 --> Total execution time: 0.1176
INFO - 2018-03-26 19:19:46 --> Model Class Initialized
INFO - 2018-03-26 19:19:46 --> Final output sent to browser
DEBUG - 2018-03-26 19:19:46 --> Total execution time: 3.8637
INFO - 2018-03-26 13:52:04 --> Config Class Initialized
INFO - 2018-03-26 13:52:04 --> Hooks Class Initialized
DEBUG - 2018-03-26 13:52:04 --> UTF-8 Support Enabled
INFO - 2018-03-26 13:52:04 --> Utf8 Class Initialized
INFO - 2018-03-26 13:52:04 --> URI Class Initialized
INFO - 2018-03-26 13:52:04 --> Router Class Initialized
INFO - 2018-03-26 13:52:04 --> Output Class Initialized
INFO - 2018-03-26 13:52:04 --> Security Class Initialized
DEBUG - 2018-03-26 13:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 13:52:04 --> Input Class Initialized
INFO - 2018-03-26 13:52:04 --> Language Class Initialized
INFO - 2018-03-26 13:52:04 --> Language Class Initialized
INFO - 2018-03-26 13:52:04 --> Config Class Initialized
INFO - 2018-03-26 13:52:04 --> Loader Class Initialized
INFO - 2018-03-26 19:22:04 --> Helper loaded: url_helper
INFO - 2018-03-26 19:22:04 --> Helper loaded: notification_helper
INFO - 2018-03-26 19:22:04 --> Helper loaded: settings_helper
INFO - 2018-03-26 19:22:04 --> Helper loaded: permission_helper
INFO - 2018-03-26 19:22:04 --> Helper loaded: users_helper
INFO - 2018-03-26 19:22:04 --> Database Driver Class Initialized
DEBUG - 2018-03-26 19:22:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 19:22:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 19:22:05 --> Helper loaded: form_helper
INFO - 2018-03-26 19:22:05 --> Form Validation Class Initialized
INFO - 2018-03-26 19:22:05 --> Controller Class Initialized
INFO - 2018-03-26 19:22:05 --> Model Class Initialized
INFO - 2018-03-26 19:22:05 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 19:22:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 19:22:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 19:22:05 --> Model Class Initialized
INFO - 2018-03-26 19:22:05 --> Model Class Initialized
INFO - 2018-03-26 19:22:05 --> Model Class Initialized
INFO - 2018-03-26 19:22:05 --> Model Class Initialized
INFO - 2018-03-26 19:22:05 --> Model Class Initialized
INFO - 2018-03-26 19:22:05 --> Model Class Initialized
INFO - 2018-03-26 19:22:05 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 19:22:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-26 19:22:05 --> Final output sent to browser
DEBUG - 2018-03-26 19:22:05 --> Total execution time: 0.8931
INFO - 2018-03-26 13:52:06 --> Config Class Initialized
INFO - 2018-03-26 13:52:06 --> Hooks Class Initialized
DEBUG - 2018-03-26 13:52:06 --> UTF-8 Support Enabled
INFO - 2018-03-26 13:52:06 --> Utf8 Class Initialized
INFO - 2018-03-26 13:52:06 --> URI Class Initialized
INFO - 2018-03-26 13:52:06 --> Router Class Initialized
INFO - 2018-03-26 13:52:06 --> Output Class Initialized
INFO - 2018-03-26 13:52:06 --> Security Class Initialized
DEBUG - 2018-03-26 13:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 13:52:06 --> Input Class Initialized
INFO - 2018-03-26 13:52:06 --> Language Class Initialized
INFO - 2018-03-26 13:52:06 --> Language Class Initialized
INFO - 2018-03-26 13:52:06 --> Config Class Initialized
INFO - 2018-03-26 13:52:06 --> Loader Class Initialized
INFO - 2018-03-26 19:22:06 --> Helper loaded: url_helper
INFO - 2018-03-26 19:22:06 --> Helper loaded: notification_helper
INFO - 2018-03-26 19:22:06 --> Helper loaded: settings_helper
INFO - 2018-03-26 19:22:06 --> Helper loaded: permission_helper
INFO - 2018-03-26 19:22:06 --> Helper loaded: users_helper
INFO - 2018-03-26 19:22:06 --> Database Driver Class Initialized
DEBUG - 2018-03-26 19:22:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 19:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 19:22:06 --> Helper loaded: form_helper
INFO - 2018-03-26 19:22:06 --> Form Validation Class Initialized
INFO - 2018-03-26 19:22:06 --> Controller Class Initialized
INFO - 2018-03-26 19:22:06 --> Model Class Initialized
INFO - 2018-03-26 19:22:06 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 19:22:06 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 19:22:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 19:22:06 --> Model Class Initialized
INFO - 2018-03-26 19:22:06 --> Model Class Initialized
INFO - 2018-03-26 19:22:06 --> Model Class Initialized
INFO - 2018-03-26 19:22:06 --> Model Class Initialized
INFO - 2018-03-26 19:22:06 --> Model Class Initialized
INFO - 2018-03-26 19:22:06 --> Model Class Initialized
INFO - 2018-03-26 19:22:06 --> Model Class Initialized
INFO - 2018-03-26 19:22:06 --> Model Class Initialized
INFO - 2018-03-26 19:22:06 --> Model Class Initialized
INFO - 2018-03-26 19:22:06 --> Model Class Initialized
INFO - 2018-03-26 19:22:06 --> Model Class Initialized
INFO - 2018-03-26 19:22:06 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 19:22:06 --> Model Class Initialized
INFO - 2018-03-26 19:22:06 --> Final output sent to browser
DEBUG - 2018-03-26 19:22:06 --> Total execution time: 0.4041
INFO - 2018-03-26 13:52:08 --> Config Class Initialized
INFO - 2018-03-26 13:52:08 --> Hooks Class Initialized
DEBUG - 2018-03-26 13:52:08 --> UTF-8 Support Enabled
INFO - 2018-03-26 13:52:08 --> Utf8 Class Initialized
INFO - 2018-03-26 13:52:09 --> URI Class Initialized
INFO - 2018-03-26 13:52:09 --> Router Class Initialized
INFO - 2018-03-26 13:52:09 --> Output Class Initialized
INFO - 2018-03-26 13:52:09 --> Security Class Initialized
DEBUG - 2018-03-26 13:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 13:52:09 --> Input Class Initialized
INFO - 2018-03-26 13:52:09 --> Language Class Initialized
INFO - 2018-03-26 13:52:10 --> Config Class Initialized
INFO - 2018-03-26 13:52:10 --> Hooks Class Initialized
DEBUG - 2018-03-26 13:52:10 --> UTF-8 Support Enabled
INFO - 2018-03-26 13:52:10 --> Utf8 Class Initialized
INFO - 2018-03-26 13:52:10 --> URI Class Initialized
INFO - 2018-03-26 13:52:10 --> Router Class Initialized
INFO - 2018-03-26 13:52:10 --> Output Class Initialized
INFO - 2018-03-26 13:52:10 --> Security Class Initialized
DEBUG - 2018-03-26 13:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 13:52:10 --> Input Class Initialized
INFO - 2018-03-26 13:52:10 --> Language Class Initialized
INFO - 2018-03-26 13:52:10 --> Language Class Initialized
INFO - 2018-03-26 13:52:10 --> Config Class Initialized
INFO - 2018-03-26 13:52:10 --> Loader Class Initialized
INFO - 2018-03-26 19:22:10 --> Helper loaded: url_helper
INFO - 2018-03-26 19:22:10 --> Helper loaded: notification_helper
INFO - 2018-03-26 19:22:10 --> Helper loaded: settings_helper
INFO - 2018-03-26 19:22:10 --> Helper loaded: permission_helper
INFO - 2018-03-26 19:22:10 --> Helper loaded: users_helper
INFO - 2018-03-26 19:22:10 --> Database Driver Class Initialized
DEBUG - 2018-03-26 19:22:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 19:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 19:22:10 --> Helper loaded: form_helper
INFO - 2018-03-26 19:22:10 --> Form Validation Class Initialized
INFO - 2018-03-26 19:22:10 --> Controller Class Initialized
INFO - 2018-03-26 19:22:10 --> Model Class Initialized
INFO - 2018-03-26 19:22:10 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 19:22:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 19:22:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 19:22:10 --> Model Class Initialized
INFO - 2018-03-26 19:22:10 --> Model Class Initialized
INFO - 2018-03-26 19:22:10 --> Model Class Initialized
INFO - 2018-03-26 19:22:10 --> Model Class Initialized
INFO - 2018-03-26 19:22:10 --> Model Class Initialized
INFO - 2018-03-26 19:22:10 --> Model Class Initialized
INFO - 2018-03-26 19:22:10 --> Model Class Initialized
INFO - 2018-03-26 19:22:10 --> Model Class Initialized
INFO - 2018-03-26 19:22:10 --> Model Class Initialized
INFO - 2018-03-26 19:22:10 --> Model Class Initialized
INFO - 2018-03-26 19:22:10 --> Model Class Initialized
INFO - 2018-03-26 19:22:10 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 19:22:10 --> Model Class Initialized
INFO - 2018-03-26 19:22:10 --> Final output sent to browser
DEBUG - 2018-03-26 19:22:10 --> Total execution time: 0.3016
INFO - 2018-03-26 13:52:10 --> Language Class Initialized
INFO - 2018-03-26 13:52:10 --> Config Class Initialized
INFO - 2018-03-26 13:52:10 --> Loader Class Initialized
INFO - 2018-03-26 19:22:10 --> Helper loaded: url_helper
INFO - 2018-03-26 19:22:10 --> Helper loaded: notification_helper
INFO - 2018-03-26 19:22:10 --> Helper loaded: settings_helper
INFO - 2018-03-26 19:22:10 --> Helper loaded: permission_helper
INFO - 2018-03-26 19:22:10 --> Helper loaded: users_helper
INFO - 2018-03-26 19:22:11 --> Database Driver Class Initialized
DEBUG - 2018-03-26 19:22:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 19:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 19:22:11 --> Helper loaded: form_helper
INFO - 2018-03-26 19:22:11 --> Form Validation Class Initialized
INFO - 2018-03-26 19:22:11 --> Controller Class Initialized
INFO - 2018-03-26 19:22:12 --> Model Class Initialized
INFO - 2018-03-26 19:22:12 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 19:22:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 19:22:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 19:22:12 --> Model Class Initialized
INFO - 2018-03-26 19:22:12 --> Model Class Initialized
INFO - 2018-03-26 19:22:12 --> Model Class Initialized
INFO - 2018-03-26 19:22:12 --> Model Class Initialized
INFO - 2018-03-26 19:22:12 --> Model Class Initialized
INFO - 2018-03-26 19:22:12 --> Model Class Initialized
INFO - 2018-03-26 19:22:12 --> Model Class Initialized
INFO - 2018-03-26 19:22:12 --> Model Class Initialized
INFO - 2018-03-26 19:22:12 --> Model Class Initialized
INFO - 2018-03-26 19:22:12 --> Model Class Initialized
INFO - 2018-03-26 19:22:12 --> Model Class Initialized
INFO - 2018-03-26 19:22:12 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 19:22:12 --> Model Class Initialized
INFO - 2018-03-26 19:22:12 --> Final output sent to browser
DEBUG - 2018-03-26 19:22:12 --> Total execution time: 3.6402
INFO - 2018-03-26 13:52:49 --> Config Class Initialized
INFO - 2018-03-26 13:52:49 --> Hooks Class Initialized
DEBUG - 2018-03-26 13:52:49 --> UTF-8 Support Enabled
INFO - 2018-03-26 13:52:49 --> Utf8 Class Initialized
INFO - 2018-03-26 13:52:49 --> URI Class Initialized
INFO - 2018-03-26 13:52:50 --> Router Class Initialized
INFO - 2018-03-26 13:52:50 --> Output Class Initialized
INFO - 2018-03-26 13:52:50 --> Security Class Initialized
DEBUG - 2018-03-26 13:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 13:52:50 --> Input Class Initialized
INFO - 2018-03-26 13:52:50 --> Language Class Initialized
INFO - 2018-03-26 13:52:50 --> Config Class Initialized
INFO - 2018-03-26 13:52:50 --> Hooks Class Initialized
DEBUG - 2018-03-26 13:52:50 --> UTF-8 Support Enabled
INFO - 2018-03-26 13:52:50 --> Utf8 Class Initialized
INFO - 2018-03-26 13:52:50 --> URI Class Initialized
INFO - 2018-03-26 13:52:50 --> Router Class Initialized
INFO - 2018-03-26 13:52:50 --> Output Class Initialized
INFO - 2018-03-26 13:52:50 --> Security Class Initialized
DEBUG - 2018-03-26 13:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 13:52:50 --> Input Class Initialized
INFO - 2018-03-26 13:52:50 --> Language Class Initialized
INFO - 2018-03-26 13:52:50 --> Language Class Initialized
INFO - 2018-03-26 13:52:50 --> Config Class Initialized
INFO - 2018-03-26 13:52:50 --> Loader Class Initialized
INFO - 2018-03-26 13:52:50 --> Language Class Initialized
INFO - 2018-03-26 13:52:50 --> Config Class Initialized
INFO - 2018-03-26 19:22:50 --> Helper loaded: url_helper
INFO - 2018-03-26 13:52:50 --> Loader Class Initialized
INFO - 2018-03-26 19:22:50 --> Helper loaded: notification_helper
INFO - 2018-03-26 19:22:50 --> Helper loaded: settings_helper
INFO - 2018-03-26 19:22:50 --> Helper loaded: permission_helper
INFO - 2018-03-26 19:22:51 --> Helper loaded: url_helper
INFO - 2018-03-26 19:22:51 --> Helper loaded: users_helper
INFO - 2018-03-26 19:22:51 --> Helper loaded: notification_helper
INFO - 2018-03-26 19:22:51 --> Helper loaded: settings_helper
INFO - 2018-03-26 19:22:51 --> Helper loaded: permission_helper
INFO - 2018-03-26 19:22:51 --> Helper loaded: users_helper
INFO - 2018-03-26 19:22:51 --> Database Driver Class Initialized
DEBUG - 2018-03-26 19:22:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 19:22:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 19:22:51 --> Helper loaded: form_helper
INFO - 2018-03-26 19:22:51 --> Form Validation Class Initialized
INFO - 2018-03-26 19:22:51 --> Controller Class Initialized
INFO - 2018-03-26 19:22:51 --> Model Class Initialized
INFO - 2018-03-26 19:22:51 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 19:22:51 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 19:22:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 19:22:51 --> Model Class Initialized
INFO - 2018-03-26 19:22:51 --> Model Class Initialized
INFO - 2018-03-26 19:22:51 --> Model Class Initialized
INFO - 2018-03-26 19:22:51 --> Model Class Initialized
INFO - 2018-03-26 19:22:51 --> Model Class Initialized
INFO - 2018-03-26 19:22:51 --> Model Class Initialized
INFO - 2018-03-26 19:22:51 --> Model Class Initialized
INFO - 2018-03-26 19:22:51 --> Model Class Initialized
INFO - 2018-03-26 19:22:51 --> Model Class Initialized
INFO - 2018-03-26 19:22:51 --> Model Class Initialized
INFO - 2018-03-26 19:22:51 --> Model Class Initialized
INFO - 2018-03-26 19:22:51 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 19:22:51 --> Model Class Initialized
INFO - 2018-03-26 19:22:51 --> Final output sent to browser
DEBUG - 2018-03-26 19:22:51 --> Total execution time: 2.6450
INFO - 2018-03-26 19:22:52 --> Database Driver Class Initialized
DEBUG - 2018-03-26 19:22:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 19:22:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 19:22:52 --> Helper loaded: form_helper
INFO - 2018-03-26 19:22:52 --> Form Validation Class Initialized
INFO - 2018-03-26 19:22:52 --> Controller Class Initialized
INFO - 2018-03-26 19:22:52 --> Model Class Initialized
INFO - 2018-03-26 19:22:52 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 19:22:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 19:22:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 19:22:52 --> Model Class Initialized
INFO - 2018-03-26 19:22:52 --> Model Class Initialized
INFO - 2018-03-26 19:22:52 --> Model Class Initialized
INFO - 2018-03-26 19:22:52 --> Model Class Initialized
INFO - 2018-03-26 19:22:52 --> Model Class Initialized
INFO - 2018-03-26 19:22:52 --> Model Class Initialized
INFO - 2018-03-26 19:22:52 --> Model Class Initialized
INFO - 2018-03-26 19:22:52 --> Model Class Initialized
INFO - 2018-03-26 19:22:52 --> Model Class Initialized
INFO - 2018-03-26 19:22:52 --> Model Class Initialized
INFO - 2018-03-26 19:22:52 --> Model Class Initialized
INFO - 2018-03-26 19:22:52 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-26 19:22:52 --> Model Class Initialized
INFO - 2018-03-26 19:22:52 --> Final output sent to browser
DEBUG - 2018-03-26 19:22:52 --> Total execution time: 1.4324
INFO - 2018-03-26 13:53:05 --> Config Class Initialized
INFO - 2018-03-26 13:53:05 --> Hooks Class Initialized
DEBUG - 2018-03-26 13:53:05 --> UTF-8 Support Enabled
INFO - 2018-03-26 13:53:05 --> Utf8 Class Initialized
INFO - 2018-03-26 13:53:05 --> URI Class Initialized
INFO - 2018-03-26 13:53:05 --> Router Class Initialized
INFO - 2018-03-26 13:53:05 --> Output Class Initialized
INFO - 2018-03-26 13:53:05 --> Security Class Initialized
DEBUG - 2018-03-26 13:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 13:53:05 --> Input Class Initialized
INFO - 2018-03-26 13:53:06 --> Language Class Initialized
INFO - 2018-03-26 13:53:06 --> Language Class Initialized
INFO - 2018-03-26 13:53:06 --> Config Class Initialized
INFO - 2018-03-26 13:53:06 --> Loader Class Initialized
INFO - 2018-03-26 19:23:06 --> Helper loaded: url_helper
INFO - 2018-03-26 19:23:06 --> Helper loaded: notification_helper
INFO - 2018-03-26 19:23:06 --> Helper loaded: settings_helper
INFO - 2018-03-26 19:23:06 --> Helper loaded: permission_helper
INFO - 2018-03-26 19:23:06 --> Helper loaded: users_helper
INFO - 2018-03-26 19:23:07 --> Database Driver Class Initialized
DEBUG - 2018-03-26 19:23:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 19:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 19:23:07 --> Helper loaded: form_helper
INFO - 2018-03-26 19:23:07 --> Form Validation Class Initialized
INFO - 2018-03-26 19:23:07 --> Controller Class Initialized
INFO - 2018-03-26 19:23:07 --> Model Class Initialized
INFO - 2018-03-26 19:23:07 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 19:23:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 19:23:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 19:23:07 --> Model Class Initialized
INFO - 2018-03-26 19:23:07 --> Model Class Initialized
INFO - 2018-03-26 19:23:07 --> Model Class Initialized
INFO - 2018-03-26 19:23:07 --> Model Class Initialized
INFO - 2018-03-26 19:23:07 --> Model Class Initialized
INFO - 2018-03-26 19:23:07 --> Model Class Initialized
INFO - 2018-03-26 19:23:07 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-26 19:23:07 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-26 19:23:07 --> Final output sent to browser
DEBUG - 2018-03-26 19:23:07 --> Total execution time: 2.1002
INFO - 2018-03-26 13:53:08 --> Config Class Initialized
INFO - 2018-03-26 13:53:08 --> Hooks Class Initialized
DEBUG - 2018-03-26 13:53:08 --> UTF-8 Support Enabled
INFO - 2018-03-26 13:53:08 --> Utf8 Class Initialized
INFO - 2018-03-26 13:53:08 --> URI Class Initialized
INFO - 2018-03-26 13:53:08 --> Router Class Initialized
INFO - 2018-03-26 13:53:08 --> Output Class Initialized
INFO - 2018-03-26 13:53:08 --> Security Class Initialized
DEBUG - 2018-03-26 13:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 13:53:08 --> Input Class Initialized
INFO - 2018-03-26 13:53:08 --> Language Class Initialized
INFO - 2018-03-26 13:53:08 --> Language Class Initialized
INFO - 2018-03-26 13:53:08 --> Config Class Initialized
INFO - 2018-03-26 13:53:08 --> Loader Class Initialized
INFO - 2018-03-26 19:23:08 --> Helper loaded: url_helper
INFO - 2018-03-26 19:23:08 --> Helper loaded: notification_helper
INFO - 2018-03-26 19:23:08 --> Helper loaded: settings_helper
INFO - 2018-03-26 19:23:08 --> Helper loaded: permission_helper
INFO - 2018-03-26 19:23:08 --> Helper loaded: users_helper
INFO - 2018-03-26 19:23:08 --> Database Driver Class Initialized
DEBUG - 2018-03-26 19:23:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 19:23:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 19:23:08 --> Helper loaded: form_helper
INFO - 2018-03-26 19:23:08 --> Form Validation Class Initialized
INFO - 2018-03-26 19:23:08 --> Controller Class Initialized
INFO - 2018-03-26 19:23:08 --> Model Class Initialized
INFO - 2018-03-26 19:23:08 --> Helper loaded: inflector_helper
DEBUG - 2018-03-26 19:23:08 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-26 19:23:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-26 19:23:08 --> Model Class Initialized
INFO - 2018-03-26 19:23:08 --> Model Class Initialized
INFO - 2018-03-26 19:23:08 --> Model Class Initialized
INFO - 2018-03-26 19:23:08 --> Model Class Initialized
INFO - 2018-03-26 19:23:08 --> Model Class Initialized
INFO - 2018-03-26 19:23:08 --> Model Class Initialized
INFO - 2018-03-26 19:23:08 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-26 19:23:08 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-26 19:23:08 --> Final output sent to browser
DEBUG - 2018-03-26 19:23:08 --> Total execution time: 0.1131
