<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-03-19 09:02:48 --> Config Class Initialized
INFO - 2018-03-19 09:02:48 --> Hooks Class Initialized
DEBUG - 2018-03-19 09:02:48 --> UTF-8 Support Enabled
INFO - 2018-03-19 09:02:48 --> Utf8 Class Initialized
INFO - 2018-03-19 09:02:48 --> URI Class Initialized
INFO - 2018-03-19 09:02:48 --> Router Class Initialized
INFO - 2018-03-19 09:02:48 --> Output Class Initialized
INFO - 2018-03-19 09:02:48 --> Security Class Initialized
DEBUG - 2018-03-19 09:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 09:02:48 --> Input Class Initialized
INFO - 2018-03-19 09:02:48 --> Language Class Initialized
INFO - 2018-03-19 09:02:49 --> Config Class Initialized
INFO - 2018-03-19 09:02:49 --> Hooks Class Initialized
DEBUG - 2018-03-19 09:02:49 --> UTF-8 Support Enabled
INFO - 2018-03-19 09:02:49 --> Utf8 Class Initialized
INFO - 2018-03-19 09:02:49 --> Language Class Initialized
INFO - 2018-03-19 09:02:49 --> Config Class Initialized
INFO - 2018-03-19 09:02:49 --> Loader Class Initialized
INFO - 2018-03-19 14:32:49 --> Helper loaded: url_helper
INFO - 2018-03-19 14:32:49 --> Helper loaded: notification_helper
INFO - 2018-03-19 14:32:49 --> Helper loaded: settings_helper
INFO - 2018-03-19 14:32:49 --> Helper loaded: permission_helper
INFO - 2018-03-19 14:32:49 --> Helper loaded: users_helper
INFO - 2018-03-19 09:02:49 --> URI Class Initialized
INFO - 2018-03-19 09:02:49 --> Config Class Initialized
INFO - 2018-03-19 14:32:49 --> Database Driver Class Initialized
INFO - 2018-03-19 09:02:49 --> Hooks Class Initialized
DEBUG - 2018-03-19 14:32:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-19 09:02:49 --> UTF-8 Support Enabled
INFO - 2018-03-19 09:02:49 --> Utf8 Class Initialized
INFO - 2018-03-19 14:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-19 14:32:49 --> Helper loaded: form_helper
INFO - 2018-03-19 14:32:49 --> Form Validation Class Initialized
INFO - 2018-03-19 14:32:49 --> Controller Class Initialized
INFO - 2018-03-19 14:32:49 --> Model Class Initialized
INFO - 2018-03-19 14:32:49 --> Helper loaded: inflector_helper
DEBUG - 2018-03-19 14:32:49 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-19 09:02:49 --> Router Class Initialized
INFO - 2018-03-19 09:02:49 --> URI Class Initialized
INFO - 2018-03-19 14:32:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-19 14:32:50 --> Model Class Initialized
INFO - 2018-03-19 14:32:50 --> Model Class Initialized
INFO - 2018-03-19 09:02:50 --> Output Class Initialized
INFO - 2018-03-19 14:32:50 --> Model Class Initialized
INFO - 2018-03-19 14:32:50 --> Model Class Initialized
INFO - 2018-03-19 14:32:50 --> Model Class Initialized
INFO - 2018-03-19 14:32:50 --> Model Class Initialized
INFO - 2018-03-19 14:32:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-19 14:32:50 --> Final output sent to browser
DEBUG - 2018-03-19 14:32:50 --> Total execution time: 1.8199
INFO - 2018-03-19 09:02:50 --> Security Class Initialized
INFO - 2018-03-19 09:02:50 --> Router Class Initialized
DEBUG - 2018-03-19 09:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 09:02:50 --> Input Class Initialized
INFO - 2018-03-19 09:02:50 --> Language Class Initialized
INFO - 2018-03-19 09:02:50 --> Output Class Initialized
INFO - 2018-03-19 09:02:50 --> Security Class Initialized
DEBUG - 2018-03-19 09:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 09:02:50 --> Input Class Initialized
INFO - 2018-03-19 09:02:50 --> Language Class Initialized
INFO - 2018-03-19 09:02:50 --> Language Class Initialized
INFO - 2018-03-19 09:02:50 --> Config Class Initialized
INFO - 2018-03-19 09:02:50 --> Loader Class Initialized
INFO - 2018-03-19 14:32:50 --> Helper loaded: url_helper
INFO - 2018-03-19 09:02:50 --> Language Class Initialized
INFO - 2018-03-19 09:02:50 --> Config Class Initialized
INFO - 2018-03-19 09:02:50 --> Loader Class Initialized
INFO - 2018-03-19 14:32:50 --> Helper loaded: url_helper
INFO - 2018-03-19 14:32:50 --> Helper loaded: notification_helper
INFO - 2018-03-19 14:32:50 --> Helper loaded: settings_helper
INFO - 2018-03-19 14:32:50 --> Helper loaded: notification_helper
INFO - 2018-03-19 14:32:51 --> Helper loaded: settings_helper
INFO - 2018-03-19 14:32:51 --> Helper loaded: permission_helper
INFO - 2018-03-19 14:32:51 --> Helper loaded: permission_helper
INFO - 2018-03-19 14:32:51 --> Helper loaded: users_helper
INFO - 2018-03-19 14:32:51 --> Helper loaded: users_helper
INFO - 2018-03-19 14:32:51 --> Database Driver Class Initialized
INFO - 2018-03-19 14:32:51 --> Database Driver Class Initialized
DEBUG - 2018-03-19 14:32:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-19 14:32:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-19 14:32:51 --> Helper loaded: form_helper
INFO - 2018-03-19 14:32:51 --> Form Validation Class Initialized
INFO - 2018-03-19 14:32:51 --> Controller Class Initialized
DEBUG - 2018-03-19 14:32:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-19 14:32:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-19 14:32:51 --> Model Class Initialized
INFO - 2018-03-19 14:32:51 --> Helper loaded: inflector_helper
DEBUG - 2018-03-19 14:32:51 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-19 14:32:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-19 14:32:51 --> Model Class Initialized
INFO - 2018-03-19 14:32:51 --> Model Class Initialized
INFO - 2018-03-19 14:32:51 --> Model Class Initialized
INFO - 2018-03-19 14:32:51 --> Model Class Initialized
INFO - 2018-03-19 14:32:51 --> Model Class Initialized
INFO - 2018-03-19 14:32:51 --> Model Class Initialized
INFO - 2018-03-19 14:32:51 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-19 14:32:52 --> Helper loaded: form_helper
INFO - 2018-03-19 14:32:52 --> Form Validation Class Initialized
INFO - 2018-03-19 14:32:52 --> Controller Class Initialized
INFO - 2018-03-19 14:32:52 --> Model Class Initialized
INFO - 2018-03-19 14:32:52 --> Final output sent to browser
DEBUG - 2018-03-19 14:32:52 --> Total execution time: 2.7780
INFO - 2018-03-19 14:32:52 --> Model Class Initialized
INFO - 2018-03-19 14:32:52 --> Helper loaded: inflector_helper
DEBUG - 2018-03-19 14:32:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-19 14:32:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-19 14:32:52 --> Model Class Initialized
INFO - 2018-03-19 14:32:52 --> Model Class Initialized
INFO - 2018-03-19 14:32:52 --> Model Class Initialized
INFO - 2018-03-19 14:32:52 --> Model Class Initialized
INFO - 2018-03-19 14:32:52 --> Model Class Initialized
INFO - 2018-03-19 14:32:52 --> Model Class Initialized
INFO - 2018-03-19 14:32:52 --> Model Class Initialized
INFO - 2018-03-19 14:32:52 --> Model Class Initialized
INFO - 2018-03-19 14:32:52 --> Model Class Initialized
INFO - 2018-03-19 14:32:52 --> Model Class Initialized
INFO - 2018-03-19 14:32:52 --> Model Class Initialized
INFO - 2018-03-19 14:32:52 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-19 14:32:52 --> Model Class Initialized
INFO - 2018-03-19 14:32:53 --> Final output sent to browser
DEBUG - 2018-03-19 14:32:53 --> Total execution time: 4.3764
INFO - 2018-03-19 09:02:55 --> Config Class Initialized
INFO - 2018-03-19 09:02:55 --> Hooks Class Initialized
DEBUG - 2018-03-19 09:02:55 --> UTF-8 Support Enabled
INFO - 2018-03-19 09:02:55 --> Utf8 Class Initialized
INFO - 2018-03-19 09:02:55 --> URI Class Initialized
INFO - 2018-03-19 09:02:55 --> Router Class Initialized
INFO - 2018-03-19 09:02:55 --> Output Class Initialized
INFO - 2018-03-19 09:02:55 --> Config Class Initialized
INFO - 2018-03-19 09:02:55 --> Hooks Class Initialized
INFO - 2018-03-19 09:02:55 --> Security Class Initialized
DEBUG - 2018-03-19 09:02:55 --> UTF-8 Support Enabled
INFO - 2018-03-19 09:02:55 --> Utf8 Class Initialized
DEBUG - 2018-03-19 09:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 09:02:55 --> Input Class Initialized
INFO - 2018-03-19 09:02:55 --> URI Class Initialized
INFO - 2018-03-19 09:02:55 --> Language Class Initialized
INFO - 2018-03-19 09:02:55 --> Router Class Initialized
INFO - 2018-03-19 09:02:55 --> Output Class Initialized
INFO - 2018-03-19 09:02:55 --> Security Class Initialized
DEBUG - 2018-03-19 09:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 09:02:55 --> Input Class Initialized
INFO - 2018-03-19 09:02:55 --> Language Class Initialized
INFO - 2018-03-19 09:02:55 --> Language Class Initialized
INFO - 2018-03-19 09:02:55 --> Config Class Initialized
INFO - 2018-03-19 09:02:55 --> Loader Class Initialized
INFO - 2018-03-19 14:32:55 --> Helper loaded: url_helper
INFO - 2018-03-19 14:32:55 --> Helper loaded: notification_helper
INFO - 2018-03-19 14:32:55 --> Helper loaded: settings_helper
INFO - 2018-03-19 14:32:55 --> Helper loaded: permission_helper
INFO - 2018-03-19 14:32:55 --> Helper loaded: users_helper
INFO - 2018-03-19 09:02:55 --> Language Class Initialized
INFO - 2018-03-19 09:02:55 --> Config Class Initialized
INFO - 2018-03-19 09:02:55 --> Loader Class Initialized
INFO - 2018-03-19 14:32:55 --> Helper loaded: url_helper
INFO - 2018-03-19 14:32:55 --> Helper loaded: notification_helper
INFO - 2018-03-19 14:32:55 --> Helper loaded: settings_helper
INFO - 2018-03-19 14:32:55 --> Helper loaded: permission_helper
INFO - 2018-03-19 14:32:55 --> Helper loaded: users_helper
INFO - 2018-03-19 14:32:55 --> Database Driver Class Initialized
DEBUG - 2018-03-19 14:32:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-19 14:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-19 14:32:56 --> Database Driver Class Initialized
DEBUG - 2018-03-19 14:32:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-19 14:32:56 --> Helper loaded: form_helper
INFO - 2018-03-19 14:32:56 --> Form Validation Class Initialized
INFO - 2018-03-19 14:32:56 --> Controller Class Initialized
INFO - 2018-03-19 14:32:56 --> Model Class Initialized
INFO - 2018-03-19 14:32:56 --> Helper loaded: inflector_helper
DEBUG - 2018-03-19 14:32:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-19 14:32:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-19 14:32:56 --> Model Class Initialized
INFO - 2018-03-19 14:32:56 --> Model Class Initialized
INFO - 2018-03-19 14:32:56 --> Model Class Initialized
INFO - 2018-03-19 14:32:56 --> Model Class Initialized
INFO - 2018-03-19 14:32:56 --> Model Class Initialized
INFO - 2018-03-19 14:32:56 --> Model Class Initialized
INFO - 2018-03-19 14:32:56 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-19 14:32:56 --> Final output sent to browser
DEBUG - 2018-03-19 14:32:56 --> Total execution time: 0.4008
INFO - 2018-03-19 14:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-19 14:32:56 --> Helper loaded: form_helper
INFO - 2018-03-19 14:32:56 --> Form Validation Class Initialized
INFO - 2018-03-19 14:32:56 --> Controller Class Initialized
INFO - 2018-03-19 14:32:56 --> Model Class Initialized
INFO - 2018-03-19 14:32:56 --> Helper loaded: inflector_helper
DEBUG - 2018-03-19 14:32:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-19 14:32:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-19 14:32:56 --> Model Class Initialized
INFO - 2018-03-19 14:32:56 --> Model Class Initialized
INFO - 2018-03-19 14:32:56 --> Model Class Initialized
INFO - 2018-03-19 14:32:56 --> Model Class Initialized
INFO - 2018-03-19 14:32:56 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-19 14:32:56 --> Final output sent to browser
DEBUG - 2018-03-19 14:32:56 --> Total execution time: 0.6834
INFO - 2018-03-19 09:02:59 --> Config Class Initialized
INFO - 2018-03-19 09:02:59 --> Hooks Class Initialized
DEBUG - 2018-03-19 09:02:59 --> UTF-8 Support Enabled
INFO - 2018-03-19 09:02:59 --> Utf8 Class Initialized
INFO - 2018-03-19 09:02:59 --> URI Class Initialized
INFO - 2018-03-19 09:02:59 --> Router Class Initialized
INFO - 2018-03-19 09:02:59 --> Output Class Initialized
INFO - 2018-03-19 09:02:59 --> Security Class Initialized
DEBUG - 2018-03-19 09:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 09:02:59 --> Input Class Initialized
INFO - 2018-03-19 09:02:59 --> Language Class Initialized
INFO - 2018-03-19 09:02:59 --> Language Class Initialized
INFO - 2018-03-19 09:02:59 --> Config Class Initialized
INFO - 2018-03-19 09:02:59 --> Loader Class Initialized
INFO - 2018-03-19 14:32:59 --> Helper loaded: url_helper
INFO - 2018-03-19 14:32:59 --> Helper loaded: notification_helper
INFO - 2018-03-19 14:32:59 --> Helper loaded: settings_helper
INFO - 2018-03-19 14:32:59 --> Helper loaded: permission_helper
INFO - 2018-03-19 14:32:59 --> Helper loaded: users_helper
INFO - 2018-03-19 14:32:59 --> Database Driver Class Initialized
DEBUG - 2018-03-19 14:32:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-19 14:32:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-19 14:32:59 --> Helper loaded: form_helper
INFO - 2018-03-19 14:32:59 --> Form Validation Class Initialized
INFO - 2018-03-19 14:32:59 --> Controller Class Initialized
INFO - 2018-03-19 14:32:59 --> Model Class Initialized
INFO - 2018-03-19 14:32:59 --> Helper loaded: inflector_helper
DEBUG - 2018-03-19 14:32:59 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-19 14:32:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-19 14:32:59 --> Model Class Initialized
INFO - 2018-03-19 14:32:59 --> Model Class Initialized
INFO - 2018-03-19 14:32:59 --> Model Class Initialized
INFO - 2018-03-19 14:32:59 --> Model Class Initialized
INFO - 2018-03-19 14:32:59 --> Model Class Initialized
INFO - 2018-03-19 14:32:59 --> Model Class Initialized
INFO - 2018-03-19 14:32:59 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-19 14:32:59 --> Final output sent to browser
DEBUG - 2018-03-19 14:32:59 --> Total execution time: 0.1438
INFO - 2018-03-19 09:18:37 --> Config Class Initialized
INFO - 2018-03-19 09:18:37 --> Hooks Class Initialized
DEBUG - 2018-03-19 09:18:37 --> UTF-8 Support Enabled
INFO - 2018-03-19 09:18:37 --> Utf8 Class Initialized
INFO - 2018-03-19 09:18:37 --> URI Class Initialized
INFO - 2018-03-19 09:18:38 --> Router Class Initialized
INFO - 2018-03-19 09:18:38 --> Output Class Initialized
INFO - 2018-03-19 09:18:38 --> Security Class Initialized
DEBUG - 2018-03-19 09:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 09:18:38 --> Input Class Initialized
INFO - 2018-03-19 09:18:38 --> Language Class Initialized
INFO - 2018-03-19 09:18:39 --> Language Class Initialized
INFO - 2018-03-19 09:18:39 --> Config Class Initialized
INFO - 2018-03-19 09:18:39 --> Loader Class Initialized
INFO - 2018-03-19 14:48:39 --> Helper loaded: url_helper
INFO - 2018-03-19 14:48:39 --> Helper loaded: notification_helper
INFO - 2018-03-19 14:48:39 --> Helper loaded: settings_helper
INFO - 2018-03-19 14:48:39 --> Helper loaded: permission_helper
INFO - 2018-03-19 14:48:39 --> Helper loaded: users_helper
INFO - 2018-03-19 14:48:40 --> Database Driver Class Initialized
DEBUG - 2018-03-19 14:48:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-19 14:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-19 14:48:40 --> Helper loaded: form_helper
INFO - 2018-03-19 14:48:40 --> Form Validation Class Initialized
INFO - 2018-03-19 14:48:40 --> Controller Class Initialized
INFO - 2018-03-19 14:48:40 --> Model Class Initialized
INFO - 2018-03-19 14:48:40 --> Helper loaded: inflector_helper
DEBUG - 2018-03-19 14:48:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-19 14:48:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-19 14:48:40 --> Model Class Initialized
INFO - 2018-03-19 14:48:40 --> Model Class Initialized
INFO - 2018-03-19 14:48:40 --> Model Class Initialized
INFO - 2018-03-19 14:48:40 --> Model Class Initialized
INFO - 2018-03-19 14:48:40 --> Model Class Initialized
INFO - 2018-03-19 14:48:40 --> Model Class Initialized
INFO - 2018-03-19 14:48:40 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-19 14:48:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-19 14:48:40 --> Final output sent to browser
DEBUG - 2018-03-19 14:48:40 --> Total execution time: 3.2851
INFO - 2018-03-19 09:19:39 --> Config Class Initialized
INFO - 2018-03-19 09:19:39 --> Hooks Class Initialized
DEBUG - 2018-03-19 09:19:39 --> UTF-8 Support Enabled
INFO - 2018-03-19 09:19:39 --> Utf8 Class Initialized
INFO - 2018-03-19 09:19:39 --> URI Class Initialized
INFO - 2018-03-19 09:19:39 --> Router Class Initialized
INFO - 2018-03-19 09:19:39 --> Output Class Initialized
INFO - 2018-03-19 09:19:40 --> Security Class Initialized
DEBUG - 2018-03-19 09:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 09:19:40 --> Input Class Initialized
INFO - 2018-03-19 09:19:40 --> Language Class Initialized
INFO - 2018-03-19 09:19:40 --> Language Class Initialized
INFO - 2018-03-19 09:19:40 --> Config Class Initialized
INFO - 2018-03-19 09:19:40 --> Loader Class Initialized
INFO - 2018-03-19 14:49:40 --> Helper loaded: url_helper
INFO - 2018-03-19 14:49:40 --> Helper loaded: notification_helper
INFO - 2018-03-19 14:49:40 --> Helper loaded: settings_helper
INFO - 2018-03-19 14:49:40 --> Helper loaded: permission_helper
INFO - 2018-03-19 14:49:40 --> Helper loaded: users_helper
INFO - 2018-03-19 14:49:41 --> Database Driver Class Initialized
DEBUG - 2018-03-19 14:49:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-19 14:49:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-19 14:49:41 --> Helper loaded: form_helper
INFO - 2018-03-19 14:49:41 --> Form Validation Class Initialized
INFO - 2018-03-19 14:49:41 --> Controller Class Initialized
INFO - 2018-03-19 14:49:41 --> Model Class Initialized
INFO - 2018-03-19 14:49:41 --> Helper loaded: inflector_helper
DEBUG - 2018-03-19 14:49:41 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-19 14:49:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-19 14:49:41 --> Model Class Initialized
INFO - 2018-03-19 14:49:41 --> Model Class Initialized
INFO - 2018-03-19 14:49:41 --> Model Class Initialized
INFO - 2018-03-19 14:49:41 --> Model Class Initialized
INFO - 2018-03-19 14:49:41 --> Model Class Initialized
INFO - 2018-03-19 14:49:41 --> Model Class Initialized
INFO - 2018-03-19 14:49:41 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-19 14:49:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-19 14:49:41 --> Final output sent to browser
DEBUG - 2018-03-19 14:49:41 --> Total execution time: 2.9693
INFO - 2018-03-19 09:19:44 --> Config Class Initialized
INFO - 2018-03-19 09:19:44 --> Hooks Class Initialized
DEBUG - 2018-03-19 09:19:44 --> UTF-8 Support Enabled
INFO - 2018-03-19 09:19:44 --> Utf8 Class Initialized
INFO - 2018-03-19 09:19:44 --> URI Class Initialized
INFO - 2018-03-19 09:19:45 --> Router Class Initialized
INFO - 2018-03-19 09:19:45 --> Output Class Initialized
INFO - 2018-03-19 09:19:45 --> Security Class Initialized
DEBUG - 2018-03-19 09:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 09:19:45 --> Input Class Initialized
INFO - 2018-03-19 09:19:45 --> Language Class Initialized
INFO - 2018-03-19 09:19:46 --> Language Class Initialized
INFO - 2018-03-19 09:19:46 --> Config Class Initialized
INFO - 2018-03-19 09:19:46 --> Loader Class Initialized
INFO - 2018-03-19 14:49:47 --> Helper loaded: url_helper
INFO - 2018-03-19 14:49:47 --> Helper loaded: notification_helper
INFO - 2018-03-19 14:49:47 --> Helper loaded: settings_helper
INFO - 2018-03-19 14:49:47 --> Helper loaded: permission_helper
INFO - 2018-03-19 14:49:47 --> Helper loaded: users_helper
INFO - 2018-03-19 14:49:47 --> Database Driver Class Initialized
DEBUG - 2018-03-19 14:49:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-19 14:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-19 14:49:48 --> Helper loaded: form_helper
INFO - 2018-03-19 14:49:48 --> Form Validation Class Initialized
INFO - 2018-03-19 14:49:48 --> Controller Class Initialized
INFO - 2018-03-19 14:49:49 --> Model Class Initialized
INFO - 2018-03-19 14:49:49 --> Helper loaded: inflector_helper
DEBUG - 2018-03-19 14:49:49 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-19 14:49:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-19 14:49:49 --> Model Class Initialized
INFO - 2018-03-19 14:49:49 --> Model Class Initialized
INFO - 2018-03-19 14:49:49 --> Model Class Initialized
INFO - 2018-03-19 14:49:49 --> Model Class Initialized
INFO - 2018-03-19 14:49:49 --> Model Class Initialized
INFO - 2018-03-19 14:49:49 --> Model Class Initialized
INFO - 2018-03-19 14:49:49 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-19 14:49:49 --> Final output sent to browser
DEBUG - 2018-03-19 14:49:49 --> Total execution time: 4.8876
INFO - 2018-03-19 09:29:27 --> Config Class Initialized
INFO - 2018-03-19 09:29:27 --> Hooks Class Initialized
INFO - 2018-03-19 09:29:27 --> Config Class Initialized
INFO - 2018-03-19 09:29:27 --> Hooks Class Initialized
DEBUG - 2018-03-19 09:29:27 --> UTF-8 Support Enabled
INFO - 2018-03-19 09:29:27 --> Utf8 Class Initialized
DEBUG - 2018-03-19 09:29:27 --> UTF-8 Support Enabled
INFO - 2018-03-19 09:29:27 --> Utf8 Class Initialized
INFO - 2018-03-19 09:29:27 --> URI Class Initialized
INFO - 2018-03-19 09:29:27 --> URI Class Initialized
INFO - 2018-03-19 09:29:27 --> Router Class Initialized
INFO - 2018-03-19 09:29:27 --> Router Class Initialized
INFO - 2018-03-19 09:29:27 --> Config Class Initialized
INFO - 2018-03-19 09:29:27 --> Hooks Class Initialized
INFO - 2018-03-19 09:29:27 --> Output Class Initialized
INFO - 2018-03-19 09:29:27 --> Output Class Initialized
INFO - 2018-03-19 09:29:27 --> Security Class Initialized
DEBUG - 2018-03-19 09:29:27 --> UTF-8 Support Enabled
INFO - 2018-03-19 09:29:27 --> Utf8 Class Initialized
INFO - 2018-03-19 09:29:27 --> Security Class Initialized
INFO - 2018-03-19 09:29:27 --> URI Class Initialized
DEBUG - 2018-03-19 09:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 09:29:27 --> Input Class Initialized
INFO - 2018-03-19 09:29:27 --> Language Class Initialized
DEBUG - 2018-03-19 09:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 09:29:27 --> Input Class Initialized
INFO - 2018-03-19 09:29:27 --> Language Class Initialized
INFO - 2018-03-19 09:29:27 --> Config Class Initialized
INFO - 2018-03-19 09:29:27 --> Hooks Class Initialized
INFO - 2018-03-19 09:29:27 --> Router Class Initialized
DEBUG - 2018-03-19 09:29:27 --> UTF-8 Support Enabled
INFO - 2018-03-19 09:29:27 --> Utf8 Class Initialized
INFO - 2018-03-19 09:29:27 --> Output Class Initialized
INFO - 2018-03-19 09:29:27 --> Security Class Initialized
DEBUG - 2018-03-19 09:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 09:29:27 --> Input Class Initialized
INFO - 2018-03-19 09:29:27 --> Language Class Initialized
INFO - 2018-03-19 09:29:27 --> Language Class Initialized
INFO - 2018-03-19 09:29:27 --> Config Class Initialized
INFO - 2018-03-19 09:29:27 --> Loader Class Initialized
INFO - 2018-03-19 09:29:27 --> Language Class Initialized
INFO - 2018-03-19 09:29:27 --> Config Class Initialized
INFO - 2018-03-19 09:29:27 --> Loader Class Initialized
INFO - 2018-03-19 09:29:27 --> URI Class Initialized
INFO - 2018-03-19 14:59:27 --> Helper loaded: url_helper
INFO - 2018-03-19 14:59:27 --> Helper loaded: url_helper
INFO - 2018-03-19 14:59:27 --> Helper loaded: notification_helper
INFO - 2018-03-19 14:59:27 --> Helper loaded: settings_helper
INFO - 2018-03-19 14:59:27 --> Helper loaded: notification_helper
INFO - 2018-03-19 14:59:27 --> Helper loaded: settings_helper
INFO - 2018-03-19 14:59:27 --> Helper loaded: permission_helper
INFO - 2018-03-19 14:59:27 --> Helper loaded: permission_helper
INFO - 2018-03-19 14:59:27 --> Helper loaded: users_helper
INFO - 2018-03-19 14:59:27 --> Helper loaded: users_helper
INFO - 2018-03-19 09:29:27 --> Config Class Initialized
INFO - 2018-03-19 09:29:27 --> Hooks Class Initialized
DEBUG - 2018-03-19 09:29:27 --> UTF-8 Support Enabled
INFO - 2018-03-19 09:29:27 --> Utf8 Class Initialized
INFO - 2018-03-19 09:29:27 --> Language Class Initialized
INFO - 2018-03-19 09:29:27 --> Config Class Initialized
INFO - 2018-03-19 09:29:27 --> Loader Class Initialized
INFO - 2018-03-19 14:59:27 --> Helper loaded: url_helper
INFO - 2018-03-19 09:29:27 --> Router Class Initialized
INFO - 2018-03-19 14:59:27 --> Helper loaded: notification_helper
INFO - 2018-03-19 14:59:27 --> Helper loaded: settings_helper
INFO - 2018-03-19 14:59:27 --> Helper loaded: permission_helper
INFO - 2018-03-19 14:59:27 --> Helper loaded: users_helper
INFO - 2018-03-19 14:59:27 --> Database Driver Class Initialized
INFO - 2018-03-19 14:59:27 --> Database Driver Class Initialized
INFO - 2018-03-19 09:29:27 --> Output Class Initialized
DEBUG - 2018-03-19 14:59:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-19 14:59:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-19 14:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-19 14:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-19 09:29:27 --> URI Class Initialized
INFO - 2018-03-19 09:29:27 --> Security Class Initialized
INFO - 2018-03-19 14:59:27 --> Helper loaded: form_helper
INFO - 2018-03-19 14:59:27 --> Form Validation Class Initialized
INFO - 2018-03-19 14:59:27 --> Controller Class Initialized
INFO - 2018-03-19 14:59:27 --> Database Driver Class Initialized
INFO - 2018-03-19 09:29:27 --> Router Class Initialized
DEBUG - 2018-03-19 14:59:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-19 14:59:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-03-19 09:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 09:29:27 --> Input Class Initialized
INFO - 2018-03-19 09:29:27 --> Language Class Initialized
INFO - 2018-03-19 14:59:27 --> Helper loaded: form_helper
INFO - 2018-03-19 14:59:27 --> Form Validation Class Initialized
INFO - 2018-03-19 14:59:27 --> Controller Class Initialized
INFO - 2018-03-19 14:59:27 --> Model Class Initialized
INFO - 2018-03-19 14:59:27 --> Helper loaded: inflector_helper
DEBUG - 2018-03-19 14:59:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-19 09:29:27 --> Output Class Initialized
INFO - 2018-03-19 14:59:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-19 14:59:27 --> Model Class Initialized
INFO - 2018-03-19 14:59:27 --> Model Class Initialized
INFO - 2018-03-19 14:59:27 --> Model Class Initialized
INFO - 2018-03-19 14:59:27 --> Model Class Initialized
INFO - 2018-03-19 14:59:27 --> Model Class Initialized
INFO - 2018-03-19 14:59:27 --> Model Class Initialized
INFO - 2018-03-19 14:59:27 --> Model Class Initialized
INFO - 2018-03-19 14:59:27 --> Model Class Initialized
INFO - 2018-03-19 14:59:27 --> Model Class Initialized
INFO - 2018-03-19 14:59:27 --> Model Class Initialized
INFO - 2018-03-19 14:59:27 --> Helper loaded: form_helper
INFO - 2018-03-19 14:59:27 --> Model Class Initialized
INFO - 2018-03-19 14:59:27 --> Form Validation Class Initialized
INFO - 2018-03-19 14:59:27 --> Controller Class Initialized
INFO - 2018-03-19 14:59:27 --> Helper loaded: inflector_helper
INFO - 2018-03-19 09:29:27 --> Security Class Initialized
INFO - 2018-03-19 14:59:27 --> Model Class Initialized
INFO - 2018-03-19 14:59:27 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-19 14:59:27 --> Model Class Initialized
DEBUG - 2018-03-19 14:59:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-03-19 09:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 09:29:27 --> Input Class Initialized
INFO - 2018-03-19 14:59:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-19 14:59:27 --> Model Class Initialized
INFO - 2018-03-19 14:59:27 --> Helper loaded: inflector_helper
INFO - 2018-03-19 14:59:27 --> Model Class Initialized
INFO - 2018-03-19 14:59:27 --> Model Class Initialized
INFO - 2018-03-19 14:59:27 --> Model Class Initialized
INFO - 2018-03-19 14:59:27 --> Model Class Initialized
INFO - 2018-03-19 09:29:27 --> Language Class Initialized
INFO - 2018-03-19 14:59:27 --> Model Class Initialized
INFO - 2018-03-19 14:59:27 --> Model Class Initialized
INFO - 2018-03-19 14:59:27 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-03-19 14:59:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-19 14:59:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-19 14:59:27 --> Model Class Initialized
INFO - 2018-03-19 14:59:27 --> Model Class Initialized
INFO - 2018-03-19 14:59:27 --> Model Class Initialized
INFO - 2018-03-19 14:59:27 --> Final output sent to browser
DEBUG - 2018-03-19 14:59:27 --> Total execution time: 0.1517
INFO - 2018-03-19 14:59:27 --> Model Class Initialized
INFO - 2018-03-19 14:59:27 --> Model Class Initialized
INFO - 2018-03-19 14:59:27 --> Model Class Initialized
INFO - 2018-03-19 14:59:27 --> Model Class Initialized
INFO - 2018-03-19 14:59:27 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-19 14:59:27 --> Final output sent to browser
DEBUG - 2018-03-19 14:59:27 --> Total execution time: 0.1313
INFO - 2018-03-19 09:29:27 --> Language Class Initialized
INFO - 2018-03-19 09:29:27 --> Config Class Initialized
INFO - 2018-03-19 09:29:27 --> Loader Class Initialized
INFO - 2018-03-19 09:29:27 --> Language Class Initialized
INFO - 2018-03-19 09:29:27 --> Config Class Initialized
INFO - 2018-03-19 09:29:27 --> Loader Class Initialized
INFO - 2018-03-19 14:59:27 --> Helper loaded: url_helper
INFO - 2018-03-19 14:59:27 --> Helper loaded: notification_helper
INFO - 2018-03-19 14:59:27 --> Helper loaded: settings_helper
INFO - 2018-03-19 14:59:27 --> Helper loaded: url_helper
INFO - 2018-03-19 14:59:27 --> Helper loaded: permission_helper
INFO - 2018-03-19 14:59:27 --> Helper loaded: notification_helper
INFO - 2018-03-19 14:59:27 --> Helper loaded: settings_helper
INFO - 2018-03-19 14:59:27 --> Helper loaded: users_helper
INFO - 2018-03-19 14:59:27 --> Helper loaded: permission_helper
INFO - 2018-03-19 14:59:27 --> Helper loaded: users_helper
INFO - 2018-03-19 14:59:27 --> Database Driver Class Initialized
DEBUG - 2018-03-19 14:59:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-19 14:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-19 14:59:27 --> Helper loaded: form_helper
INFO - 2018-03-19 14:59:27 --> Form Validation Class Initialized
INFO - 2018-03-19 14:59:27 --> Controller Class Initialized
INFO - 2018-03-19 14:59:27 --> Database Driver Class Initialized
DEBUG - 2018-03-19 14:59:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-19 14:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-19 14:59:27 --> Model Class Initialized
INFO - 2018-03-19 14:59:27 --> Helper loaded: inflector_helper
INFO - 2018-03-19 14:59:27 --> Helper loaded: form_helper
INFO - 2018-03-19 14:59:27 --> Form Validation Class Initialized
INFO - 2018-03-19 14:59:27 --> Controller Class Initialized
INFO - 2018-03-19 14:59:27 --> Model Class Initialized
INFO - 2018-03-19 14:59:27 --> Helper loaded: inflector_helper
DEBUG - 2018-03-19 14:59:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-19 14:59:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-19 14:59:27 --> Model Class Initialized
INFO - 2018-03-19 14:59:27 --> Model Class Initialized
INFO - 2018-03-19 14:59:27 --> Model Class Initialized
INFO - 2018-03-19 14:59:27 --> Model Class Initialized
INFO - 2018-03-19 14:59:27 --> Model Class Initialized
INFO - 2018-03-19 14:59:27 --> Model Class Initialized
INFO - 2018-03-19 14:59:27 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-19 14:59:27 --> Model Class Initialized
INFO - 2018-03-19 14:59:27 --> Final output sent to browser
DEBUG - 2018-03-19 14:59:27 --> Total execution time: 0.2619
DEBUG - 2018-03-19 14:59:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-19 14:59:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-19 14:59:27 --> Model Class Initialized
INFO - 2018-03-19 14:59:27 --> Model Class Initialized
INFO - 2018-03-19 14:59:27 --> Final output sent to browser
DEBUG - 2018-03-19 14:59:27 --> Total execution time: 0.3179
INFO - 2018-03-19 14:59:27 --> Model Class Initialized
INFO - 2018-03-19 14:59:27 --> Model Class Initialized
INFO - 2018-03-19 14:59:27 --> Model Class Initialized
INFO - 2018-03-19 14:59:27 --> Model Class Initialized
INFO - 2018-03-19 14:59:27 --> Model Class Initialized
INFO - 2018-03-19 14:59:27 --> Model Class Initialized
INFO - 2018-03-19 14:59:27 --> Model Class Initialized
INFO - 2018-03-19 14:59:27 --> Model Class Initialized
INFO - 2018-03-19 14:59:27 --> Model Class Initialized
INFO - 2018-03-19 14:59:27 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-19 14:59:27 --> Model Class Initialized
INFO - 2018-03-19 14:59:27 --> Final output sent to browser
DEBUG - 2018-03-19 14:59:27 --> Total execution time: 0.3254
INFO - 2018-03-19 09:29:29 --> Config Class Initialized
INFO - 2018-03-19 09:29:29 --> Hooks Class Initialized
INFO - 2018-03-19 09:29:29 --> Config Class Initialized
INFO - 2018-03-19 09:29:29 --> Hooks Class Initialized
DEBUG - 2018-03-19 09:29:29 --> UTF-8 Support Enabled
INFO - 2018-03-19 09:29:29 --> Utf8 Class Initialized
INFO - 2018-03-19 09:29:29 --> URI Class Initialized
DEBUG - 2018-03-19 09:29:29 --> UTF-8 Support Enabled
INFO - 2018-03-19 09:29:29 --> Utf8 Class Initialized
INFO - 2018-03-19 09:29:29 --> URI Class Initialized
INFO - 2018-03-19 09:29:29 --> Router Class Initialized
INFO - 2018-03-19 09:29:29 --> Output Class Initialized
INFO - 2018-03-19 09:29:29 --> Router Class Initialized
INFO - 2018-03-19 09:29:29 --> Security Class Initialized
INFO - 2018-03-19 09:29:29 --> Config Class Initialized
INFO - 2018-03-19 09:29:29 --> Hooks Class Initialized
INFO - 2018-03-19 09:29:29 --> Output Class Initialized
DEBUG - 2018-03-19 09:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 09:29:29 --> Input Class Initialized
INFO - 2018-03-19 09:29:29 --> Language Class Initialized
INFO - 2018-03-19 09:29:29 --> Security Class Initialized
DEBUG - 2018-03-19 09:29:29 --> UTF-8 Support Enabled
INFO - 2018-03-19 09:29:29 --> Utf8 Class Initialized
DEBUG - 2018-03-19 09:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 09:29:30 --> Input Class Initialized
INFO - 2018-03-19 09:29:30 --> Language Class Initialized
INFO - 2018-03-19 09:29:30 --> URI Class Initialized
INFO - 2018-03-19 09:29:30 --> Router Class Initialized
INFO - 2018-03-19 09:29:30 --> Output Class Initialized
INFO - 2018-03-19 09:29:30 --> Security Class Initialized
DEBUG - 2018-03-19 09:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 09:29:30 --> Input Class Initialized
INFO - 2018-03-19 09:29:30 --> Language Class Initialized
INFO - 2018-03-19 09:29:30 --> Language Class Initialized
INFO - 2018-03-19 09:29:30 --> Config Class Initialized
INFO - 2018-03-19 09:29:30 --> Loader Class Initialized
INFO - 2018-03-19 09:29:30 --> Language Class Initialized
INFO - 2018-03-19 09:29:30 --> Config Class Initialized
INFO - 2018-03-19 09:29:30 --> Loader Class Initialized
INFO - 2018-03-19 14:59:30 --> Helper loaded: url_helper
INFO - 2018-03-19 14:59:30 --> Helper loaded: notification_helper
INFO - 2018-03-19 14:59:30 --> Helper loaded: settings_helper
INFO - 2018-03-19 14:59:30 --> Helper loaded: permission_helper
INFO - 2018-03-19 14:59:30 --> Helper loaded: users_helper
INFO - 2018-03-19 14:59:30 --> Database Driver Class Initialized
DEBUG - 2018-03-19 14:59:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-19 14:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-19 14:59:30 --> Helper loaded: form_helper
INFO - 2018-03-19 14:59:30 --> Form Validation Class Initialized
INFO - 2018-03-19 14:59:30 --> Controller Class Initialized
INFO - 2018-03-19 14:59:30 --> Model Class Initialized
INFO - 2018-03-19 14:59:30 --> Helper loaded: inflector_helper
DEBUG - 2018-03-19 14:59:30 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-19 14:59:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-19 14:59:30 --> Model Class Initialized
INFO - 2018-03-19 14:59:30 --> Model Class Initialized
INFO - 2018-03-19 14:59:30 --> Model Class Initialized
INFO - 2018-03-19 14:59:30 --> Model Class Initialized
INFO - 2018-03-19 14:59:30 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-19 14:59:30 --> Final output sent to browser
DEBUG - 2018-03-19 14:59:30 --> Total execution time: 1.1280
INFO - 2018-03-19 14:59:30 --> Helper loaded: url_helper
INFO - 2018-03-19 14:59:30 --> Helper loaded: notification_helper
INFO - 2018-03-19 14:59:30 --> Helper loaded: settings_helper
INFO - 2018-03-19 14:59:30 --> Helper loaded: permission_helper
INFO - 2018-03-19 14:59:30 --> Helper loaded: users_helper
INFO - 2018-03-19 09:29:30 --> Language Class Initialized
INFO - 2018-03-19 09:29:30 --> Config Class Initialized
INFO - 2018-03-19 09:29:30 --> Loader Class Initialized
INFO - 2018-03-19 14:59:31 --> Helper loaded: url_helper
INFO - 2018-03-19 14:59:31 --> Helper loaded: notification_helper
INFO - 2018-03-19 14:59:31 --> Helper loaded: settings_helper
INFO - 2018-03-19 14:59:31 --> Helper loaded: permission_helper
INFO - 2018-03-19 14:59:31 --> Helper loaded: users_helper
INFO - 2018-03-19 14:59:31 --> Database Driver Class Initialized
DEBUG - 2018-03-19 14:59:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-19 14:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-19 14:59:31 --> Helper loaded: form_helper
INFO - 2018-03-19 14:59:31 --> Form Validation Class Initialized
INFO - 2018-03-19 14:59:31 --> Controller Class Initialized
INFO - 2018-03-19 14:59:31 --> Model Class Initialized
INFO - 2018-03-19 14:59:31 --> Helper loaded: inflector_helper
DEBUG - 2018-03-19 14:59:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-19 14:59:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-19 14:59:31 --> Model Class Initialized
INFO - 2018-03-19 14:59:31 --> Model Class Initialized
INFO - 2018-03-19 14:59:31 --> Model Class Initialized
INFO - 2018-03-19 14:59:31 --> Model Class Initialized
INFO - 2018-03-19 14:59:31 --> Model Class Initialized
INFO - 2018-03-19 14:59:31 --> Model Class Initialized
INFO - 2018-03-19 14:59:31 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-19 14:59:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-03-19 14:59:31 --> Final output sent to browser
DEBUG - 2018-03-19 14:59:31 --> Total execution time: 2.2559
INFO - 2018-03-19 09:29:31 --> Config Class Initialized
INFO - 2018-03-19 09:29:31 --> Hooks Class Initialized
DEBUG - 2018-03-19 09:29:31 --> UTF-8 Support Enabled
INFO - 2018-03-19 09:29:31 --> Utf8 Class Initialized
INFO - 2018-03-19 09:29:31 --> URI Class Initialized
INFO - 2018-03-19 09:29:31 --> Router Class Initialized
INFO - 2018-03-19 09:29:31 --> Output Class Initialized
INFO - 2018-03-19 09:29:31 --> Security Class Initialized
DEBUG - 2018-03-19 09:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 09:29:31 --> Input Class Initialized
INFO - 2018-03-19 09:29:31 --> Language Class Initialized
INFO - 2018-03-19 09:29:31 --> Language Class Initialized
INFO - 2018-03-19 09:29:31 --> Config Class Initialized
INFO - 2018-03-19 09:29:31 --> Loader Class Initialized
INFO - 2018-03-19 14:59:31 --> Helper loaded: url_helper
INFO - 2018-03-19 14:59:31 --> Helper loaded: notification_helper
INFO - 2018-03-19 14:59:31 --> Helper loaded: settings_helper
INFO - 2018-03-19 14:59:31 --> Helper loaded: permission_helper
INFO - 2018-03-19 14:59:31 --> Helper loaded: users_helper
INFO - 2018-03-19 09:29:31 --> Config Class Initialized
INFO - 2018-03-19 09:29:31 --> Hooks Class Initialized
INFO - 2018-03-19 14:59:31 --> Database Driver Class Initialized
DEBUG - 2018-03-19 09:29:31 --> UTF-8 Support Enabled
INFO - 2018-03-19 09:29:31 --> Utf8 Class Initialized
INFO - 2018-03-19 09:29:31 --> URI Class Initialized
DEBUG - 2018-03-19 14:59:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-19 14:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-19 09:29:31 --> Router Class Initialized
INFO - 2018-03-19 09:29:31 --> Output Class Initialized
INFO - 2018-03-19 09:29:31 --> Security Class Initialized
INFO - 2018-03-19 14:59:31 --> Helper loaded: form_helper
INFO - 2018-03-19 14:59:31 --> Form Validation Class Initialized
INFO - 2018-03-19 14:59:31 --> Controller Class Initialized
DEBUG - 2018-03-19 09:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 09:29:31 --> Input Class Initialized
INFO - 2018-03-19 09:29:31 --> Language Class Initialized
INFO - 2018-03-19 14:59:31 --> Model Class Initialized
INFO - 2018-03-19 14:59:31 --> Helper loaded: inflector_helper
DEBUG - 2018-03-19 14:59:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-19 14:59:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-19 14:59:31 --> Model Class Initialized
INFO - 2018-03-19 14:59:31 --> Model Class Initialized
INFO - 2018-03-19 14:59:31 --> Model Class Initialized
INFO - 2018-03-19 14:59:31 --> Model Class Initialized
INFO - 2018-03-19 14:59:31 --> Model Class Initialized
INFO - 2018-03-19 14:59:31 --> Model Class Initialized
INFO - 2018-03-19 14:59:31 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-19 14:59:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-03-19 14:59:31 --> Final output sent to browser
DEBUG - 2018-03-19 14:59:31 --> Total execution time: 0.2880
INFO - 2018-03-19 09:29:31 --> Language Class Initialized
INFO - 2018-03-19 09:29:31 --> Config Class Initialized
INFO - 2018-03-19 09:29:31 --> Loader Class Initialized
INFO - 2018-03-19 14:59:31 --> Helper loaded: url_helper
INFO - 2018-03-19 14:59:31 --> Helper loaded: notification_helper
INFO - 2018-03-19 14:59:31 --> Helper loaded: settings_helper
INFO - 2018-03-19 14:59:31 --> Helper loaded: permission_helper
INFO - 2018-03-19 14:59:31 --> Helper loaded: users_helper
INFO - 2018-03-19 14:59:31 --> Database Driver Class Initialized
DEBUG - 2018-03-19 14:59:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-19 14:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-19 14:59:31 --> Helper loaded: form_helper
INFO - 2018-03-19 14:59:31 --> Form Validation Class Initialized
INFO - 2018-03-19 14:59:31 --> Controller Class Initialized
INFO - 2018-03-19 14:59:31 --> Database Driver Class Initialized
DEBUG - 2018-03-19 14:59:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-19 14:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-19 14:59:31 --> Model Class Initialized
INFO - 2018-03-19 14:59:31 --> Helper loaded: inflector_helper
DEBUG - 2018-03-19 14:59:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-19 14:59:31 --> Helper loaded: form_helper
INFO - 2018-03-19 14:59:31 --> Form Validation Class Initialized
INFO - 2018-03-19 14:59:31 --> Controller Class Initialized
INFO - 2018-03-19 14:59:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-19 14:59:31 --> Model Class Initialized
INFO - 2018-03-19 14:59:31 --> Model Class Initialized
INFO - 2018-03-19 14:59:31 --> Model Class Initialized
INFO - 2018-03-19 14:59:31 --> Model Class Initialized
INFO - 2018-03-19 14:59:31 --> Model Class Initialized
INFO - 2018-03-19 14:59:31 --> Model Class Initialized
INFO - 2018-03-19 14:59:31 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-19 14:59:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-03-19 14:59:31 --> Final output sent to browser
DEBUG - 2018-03-19 14:59:31 --> Total execution time: 0.2013
INFO - 2018-03-19 14:59:31 --> Model Class Initialized
INFO - 2018-03-19 14:59:31 --> Helper loaded: inflector_helper
DEBUG - 2018-03-19 14:59:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-19 14:59:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-19 14:59:31 --> Model Class Initialized
INFO - 2018-03-19 14:59:31 --> Model Class Initialized
INFO - 2018-03-19 14:59:31 --> Model Class Initialized
INFO - 2018-03-19 14:59:31 --> Model Class Initialized
INFO - 2018-03-19 14:59:31 --> Model Class Initialized
INFO - 2018-03-19 14:59:31 --> Model Class Initialized
INFO - 2018-03-19 14:59:31 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-19 14:59:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-03-19 14:59:31 --> Final output sent to browser
DEBUG - 2018-03-19 14:59:31 --> Total execution time: 2.7683
INFO - 2018-03-19 09:29:34 --> Config Class Initialized
INFO - 2018-03-19 09:29:34 --> Hooks Class Initialized
DEBUG - 2018-03-19 09:29:34 --> UTF-8 Support Enabled
INFO - 2018-03-19 09:29:34 --> Utf8 Class Initialized
INFO - 2018-03-19 09:29:34 --> URI Class Initialized
INFO - 2018-03-19 09:29:34 --> Router Class Initialized
INFO - 2018-03-19 09:29:34 --> Output Class Initialized
INFO - 2018-03-19 09:29:34 --> Security Class Initialized
DEBUG - 2018-03-19 09:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 09:29:34 --> Input Class Initialized
INFO - 2018-03-19 09:29:34 --> Language Class Initialized
INFO - 2018-03-19 09:29:34 --> Language Class Initialized
INFO - 2018-03-19 09:29:34 --> Config Class Initialized
INFO - 2018-03-19 09:29:34 --> Loader Class Initialized
INFO - 2018-03-19 14:59:34 --> Helper loaded: url_helper
INFO - 2018-03-19 14:59:34 --> Helper loaded: notification_helper
INFO - 2018-03-19 14:59:34 --> Helper loaded: settings_helper
INFO - 2018-03-19 14:59:34 --> Helper loaded: permission_helper
INFO - 2018-03-19 14:59:34 --> Helper loaded: users_helper
INFO - 2018-03-19 14:59:34 --> Database Driver Class Initialized
DEBUG - 2018-03-19 14:59:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-19 14:59:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-19 14:59:34 --> Helper loaded: form_helper
INFO - 2018-03-19 14:59:34 --> Form Validation Class Initialized
INFO - 2018-03-19 14:59:34 --> Controller Class Initialized
INFO - 2018-03-19 14:59:34 --> Model Class Initialized
INFO - 2018-03-19 14:59:34 --> Helper loaded: inflector_helper
DEBUG - 2018-03-19 14:59:34 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-19 09:29:34 --> Config Class Initialized
INFO - 2018-03-19 09:29:34 --> Hooks Class Initialized
DEBUG - 2018-03-19 09:29:34 --> UTF-8 Support Enabled
INFO - 2018-03-19 09:29:34 --> Utf8 Class Initialized
INFO - 2018-03-19 09:29:34 --> URI Class Initialized
INFO - 2018-03-19 09:29:34 --> Router Class Initialized
INFO - 2018-03-19 09:29:34 --> Output Class Initialized
INFO - 2018-03-19 14:59:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-19 09:29:34 --> Security Class Initialized
DEBUG - 2018-03-19 09:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 09:29:34 --> Input Class Initialized
INFO - 2018-03-19 09:29:34 --> Language Class Initialized
INFO - 2018-03-19 09:29:34 --> Language Class Initialized
INFO - 2018-03-19 09:29:34 --> Config Class Initialized
INFO - 2018-03-19 09:29:34 --> Loader Class Initialized
INFO - 2018-03-19 14:59:34 --> Helper loaded: url_helper
INFO - 2018-03-19 14:59:34 --> Helper loaded: notification_helper
INFO - 2018-03-19 14:59:34 --> Helper loaded: settings_helper
INFO - 2018-03-19 14:59:34 --> Helper loaded: permission_helper
INFO - 2018-03-19 14:59:34 --> Helper loaded: users_helper
INFO - 2018-03-19 14:59:34 --> Model Class Initialized
INFO - 2018-03-19 14:59:34 --> Model Class Initialized
INFO - 2018-03-19 14:59:34 --> Model Class Initialized
INFO - 2018-03-19 14:59:34 --> Database Driver Class Initialized
INFO - 2018-03-19 14:59:34 --> Model Class Initialized
DEBUG - 2018-03-19 14:59:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-19 14:59:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-19 14:59:34 --> Model Class Initialized
INFO - 2018-03-19 14:59:34 --> Model Class Initialized
INFO - 2018-03-19 14:59:34 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-19 14:59:34 --> Helper loaded: form_helper
INFO - 2018-03-19 14:59:34 --> Form Validation Class Initialized
INFO - 2018-03-19 14:59:34 --> Controller Class Initialized
INFO - 2018-03-19 14:59:34 --> Model Class Initialized
INFO - 2018-03-19 14:59:34 --> Helper loaded: inflector_helper
DEBUG - 2018-03-19 14:59:34 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-19 14:59:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-19 14:59:34 --> Model Class Initialized
INFO - 2018-03-19 14:59:34 --> Model Class Initialized
INFO - 2018-03-19 14:59:34 --> Model Class Initialized
INFO - 2018-03-19 14:59:34 --> Model Class Initialized
INFO - 2018-03-19 14:59:34 --> Model Class Initialized
INFO - 2018-03-19 14:59:34 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-19 14:59:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-03-19 14:59:34 --> Model Class Initialized
INFO - 2018-03-19 14:59:34 --> Final output sent to browser
DEBUG - 2018-03-19 14:59:34 --> Total execution time: 0.5091
INFO - 2018-03-19 14:59:34 --> Final output sent to browser
DEBUG - 2018-03-19 14:59:34 --> Total execution time: 0.3230
INFO - 2018-03-19 09:33:04 --> Config Class Initialized
INFO - 2018-03-19 09:33:04 --> Hooks Class Initialized
DEBUG - 2018-03-19 09:33:04 --> UTF-8 Support Enabled
INFO - 2018-03-19 09:33:04 --> Utf8 Class Initialized
INFO - 2018-03-19 09:33:04 --> URI Class Initialized
INFO - 2018-03-19 09:33:04 --> Config Class Initialized
INFO - 2018-03-19 09:33:04 --> Hooks Class Initialized
INFO - 2018-03-19 09:33:04 --> Router Class Initialized
DEBUG - 2018-03-19 09:33:04 --> UTF-8 Support Enabled
INFO - 2018-03-19 09:33:04 --> Utf8 Class Initialized
INFO - 2018-03-19 09:33:04 --> Output Class Initialized
INFO - 2018-03-19 09:33:04 --> URI Class Initialized
INFO - 2018-03-19 09:33:04 --> Security Class Initialized
DEBUG - 2018-03-19 09:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 09:33:04 --> Input Class Initialized
INFO - 2018-03-19 09:33:04 --> Router Class Initialized
INFO - 2018-03-19 09:33:04 --> Language Class Initialized
INFO - 2018-03-19 09:33:04 --> Output Class Initialized
INFO - 2018-03-19 09:33:04 --> Security Class Initialized
DEBUG - 2018-03-19 09:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 09:33:04 --> Input Class Initialized
INFO - 2018-03-19 09:33:04 --> Language Class Initialized
INFO - 2018-03-19 09:33:05 --> Language Class Initialized
INFO - 2018-03-19 09:33:05 --> Config Class Initialized
INFO - 2018-03-19 09:33:05 --> Loader Class Initialized
INFO - 2018-03-19 15:03:05 --> Helper loaded: url_helper
INFO - 2018-03-19 15:03:05 --> Helper loaded: notification_helper
INFO - 2018-03-19 15:03:05 --> Helper loaded: settings_helper
INFO - 2018-03-19 15:03:05 --> Helper loaded: permission_helper
INFO - 2018-03-19 15:03:05 --> Helper loaded: users_helper
INFO - 2018-03-19 09:33:05 --> Language Class Initialized
INFO - 2018-03-19 09:33:05 --> Config Class Initialized
INFO - 2018-03-19 09:33:05 --> Loader Class Initialized
INFO - 2018-03-19 15:03:05 --> Helper loaded: url_helper
INFO - 2018-03-19 15:03:05 --> Helper loaded: notification_helper
INFO - 2018-03-19 15:03:05 --> Helper loaded: settings_helper
INFO - 2018-03-19 15:03:05 --> Helper loaded: permission_helper
INFO - 2018-03-19 15:03:05 --> Helper loaded: users_helper
INFO - 2018-03-19 15:03:05 --> Database Driver Class Initialized
DEBUG - 2018-03-19 15:03:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-19 15:03:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-19 15:03:05 --> Helper loaded: form_helper
INFO - 2018-03-19 15:03:05 --> Form Validation Class Initialized
INFO - 2018-03-19 15:03:05 --> Controller Class Initialized
INFO - 2018-03-19 15:03:05 --> Database Driver Class Initialized
INFO - 2018-03-19 15:03:05 --> Model Class Initialized
DEBUG - 2018-03-19 15:03:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-19 15:03:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-19 15:03:05 --> Helper loaded: inflector_helper
DEBUG - 2018-03-19 15:03:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-19 15:03:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-19 15:03:05 --> Model Class Initialized
INFO - 2018-03-19 15:03:05 --> Model Class Initialized
INFO - 2018-03-19 15:03:05 --> Model Class Initialized
INFO - 2018-03-19 15:03:05 --> Helper loaded: form_helper
INFO - 2018-03-19 15:03:05 --> Form Validation Class Initialized
INFO - 2018-03-19 15:03:05 --> Controller Class Initialized
INFO - 2018-03-19 15:03:05 --> Model Class Initialized
INFO - 2018-03-19 15:03:05 --> Model Class Initialized
INFO - 2018-03-19 15:03:05 --> Model Class Initialized
INFO - 2018-03-19 15:03:05 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-19 15:03:05 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-03-19 15:03:05 --> Final output sent to browser
DEBUG - 2018-03-19 15:03:05 --> Total execution time: 0.2848
INFO - 2018-03-19 15:03:05 --> Model Class Initialized
INFO - 2018-03-19 15:03:05 --> Helper loaded: inflector_helper
DEBUG - 2018-03-19 15:03:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-19 15:03:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-19 15:03:05 --> Model Class Initialized
INFO - 2018-03-19 15:03:05 --> Model Class Initialized
INFO - 2018-03-19 15:03:05 --> Model Class Initialized
INFO - 2018-03-19 15:03:05 --> Model Class Initialized
INFO - 2018-03-19 15:03:05 --> Model Class Initialized
INFO - 2018-03-19 15:03:05 --> Model Class Initialized
INFO - 2018-03-19 15:03:05 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-19 15:03:05 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-03-19 15:03:05 --> Final output sent to browser
DEBUG - 2018-03-19 15:03:05 --> Total execution time: 0.2978
INFO - 2018-03-19 09:33:05 --> Config Class Initialized
INFO - 2018-03-19 09:33:05 --> Hooks Class Initialized
DEBUG - 2018-03-19 09:33:05 --> UTF-8 Support Enabled
INFO - 2018-03-19 09:33:05 --> Utf8 Class Initialized
INFO - 2018-03-19 09:33:05 --> URI Class Initialized
INFO - 2018-03-19 09:33:05 --> Router Class Initialized
INFO - 2018-03-19 09:33:05 --> Output Class Initialized
INFO - 2018-03-19 09:33:05 --> Security Class Initialized
DEBUG - 2018-03-19 09:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 09:33:05 --> Input Class Initialized
INFO - 2018-03-19 09:33:06 --> Language Class Initialized
INFO - 2018-03-19 09:33:06 --> Language Class Initialized
INFO - 2018-03-19 09:33:06 --> Config Class Initialized
INFO - 2018-03-19 09:33:06 --> Loader Class Initialized
INFO - 2018-03-19 15:03:06 --> Helper loaded: url_helper
INFO - 2018-03-19 15:03:07 --> Helper loaded: notification_helper
INFO - 2018-03-19 15:03:07 --> Helper loaded: settings_helper
INFO - 2018-03-19 15:03:07 --> Helper loaded: permission_helper
INFO - 2018-03-19 15:03:07 --> Helper loaded: users_helper
INFO - 2018-03-19 15:03:07 --> Database Driver Class Initialized
INFO - 2018-03-19 09:33:07 --> Config Class Initialized
INFO - 2018-03-19 09:33:07 --> Hooks Class Initialized
DEBUG - 2018-03-19 09:33:07 --> UTF-8 Support Enabled
INFO - 2018-03-19 09:33:07 --> Utf8 Class Initialized
INFO - 2018-03-19 09:33:07 --> URI Class Initialized
INFO - 2018-03-19 09:33:07 --> Router Class Initialized
INFO - 2018-03-19 09:33:07 --> Output Class Initialized
INFO - 2018-03-19 09:33:07 --> Security Class Initialized
DEBUG - 2018-03-19 09:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 09:33:07 --> Input Class Initialized
INFO - 2018-03-19 09:33:07 --> Language Class Initialized
INFO - 2018-03-19 09:33:07 --> Language Class Initialized
INFO - 2018-03-19 09:33:07 --> Config Class Initialized
INFO - 2018-03-19 09:33:07 --> Loader Class Initialized
INFO - 2018-03-19 15:03:07 --> Helper loaded: url_helper
INFO - 2018-03-19 15:03:07 --> Helper loaded: notification_helper
INFO - 2018-03-19 15:03:07 --> Helper loaded: settings_helper
INFO - 2018-03-19 15:03:07 --> Helper loaded: permission_helper
INFO - 2018-03-19 15:03:07 --> Helper loaded: users_helper
INFO - 2018-03-19 15:03:07 --> Database Driver Class Initialized
DEBUG - 2018-03-19 15:03:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-19 15:03:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-03-19 15:03:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-19 15:03:07 --> Helper loaded: form_helper
INFO - 2018-03-19 15:03:07 --> Form Validation Class Initialized
INFO - 2018-03-19 15:03:07 --> Controller Class Initialized
INFO - 2018-03-19 15:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-19 15:03:07 --> Model Class Initialized
INFO - 2018-03-19 15:03:07 --> Helper loaded: inflector_helper
DEBUG - 2018-03-19 15:03:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-19 15:03:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-19 15:03:07 --> Model Class Initialized
INFO - 2018-03-19 15:03:07 --> Model Class Initialized
INFO - 2018-03-19 15:03:07 --> Model Class Initialized
INFO - 2018-03-19 15:03:07 --> Model Class Initialized
INFO - 2018-03-19 15:03:07 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-19 15:03:07 --> Final output sent to browser
DEBUG - 2018-03-19 15:03:07 --> Total execution time: 0.2277
INFO - 2018-03-19 15:03:08 --> Helper loaded: form_helper
INFO - 2018-03-19 15:03:08 --> Form Validation Class Initialized
INFO - 2018-03-19 15:03:08 --> Controller Class Initialized
INFO - 2018-03-19 15:03:08 --> Model Class Initialized
INFO - 2018-03-19 15:03:08 --> Helper loaded: inflector_helper
DEBUG - 2018-03-19 15:03:08 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-19 15:03:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-19 15:03:09 --> Model Class Initialized
INFO - 2018-03-19 15:03:09 --> Model Class Initialized
INFO - 2018-03-19 15:03:09 --> Model Class Initialized
INFO - 2018-03-19 15:03:09 --> Model Class Initialized
INFO - 2018-03-19 15:03:09 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-19 15:03:09 --> Final output sent to browser
DEBUG - 2018-03-19 15:03:09 --> Total execution time: 3.8443
INFO - 2018-03-19 09:47:42 --> Config Class Initialized
INFO - 2018-03-19 09:47:42 --> Hooks Class Initialized
DEBUG - 2018-03-19 09:47:42 --> UTF-8 Support Enabled
INFO - 2018-03-19 09:47:42 --> Utf8 Class Initialized
INFO - 2018-03-19 09:47:42 --> URI Class Initialized
DEBUG - 2018-03-19 09:47:42 --> No URI present. Default controller set.
INFO - 2018-03-19 09:47:42 --> Router Class Initialized
INFO - 2018-03-19 09:47:42 --> Output Class Initialized
INFO - 2018-03-19 09:47:42 --> Security Class Initialized
DEBUG - 2018-03-19 09:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 09:47:42 --> Input Class Initialized
INFO - 2018-03-19 09:47:42 --> Language Class Initialized
INFO - 2018-03-19 09:47:42 --> Language Class Initialized
INFO - 2018-03-19 09:47:42 --> Config Class Initialized
INFO - 2018-03-19 09:47:42 --> Loader Class Initialized
INFO - 2018-03-19 15:17:42 --> Helper loaded: url_helper
INFO - 2018-03-19 15:17:42 --> Helper loaded: notification_helper
INFO - 2018-03-19 15:17:42 --> Helper loaded: settings_helper
INFO - 2018-03-19 15:17:42 --> Helper loaded: permission_helper
INFO - 2018-03-19 15:17:42 --> Helper loaded: users_helper
INFO - 2018-03-19 15:17:42 --> Database Driver Class Initialized
DEBUG - 2018-03-19 15:17:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-19 15:17:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-19 15:17:43 --> Helper loaded: form_helper
INFO - 2018-03-19 15:17:43 --> Form Validation Class Initialized
INFO - 2018-03-19 15:17:43 --> Controller Class Initialized
INFO - 2018-03-19 15:17:43 --> Model Class Initialized
INFO - 2018-03-19 15:17:43 --> Helper loaded: inflector_helper
INFO - 2018-03-19 15:17:43 --> Model Class Initialized
DEBUG - 2018-03-19 15:17:43 --> File loaded: /home/pr01004/public_html/application/views/login.php
INFO - 2018-03-19 15:17:43 --> Final output sent to browser
DEBUG - 2018-03-19 15:17:43 --> Total execution time: 0.2174
INFO - 2018-03-19 09:48:07 --> Config Class Initialized
INFO - 2018-03-19 09:48:07 --> Hooks Class Initialized
DEBUG - 2018-03-19 09:48:07 --> UTF-8 Support Enabled
INFO - 2018-03-19 09:48:07 --> Utf8 Class Initialized
INFO - 2018-03-19 09:48:07 --> URI Class Initialized
INFO - 2018-03-19 09:48:07 --> Router Class Initialized
INFO - 2018-03-19 09:48:07 --> Output Class Initialized
INFO - 2018-03-19 09:48:07 --> Security Class Initialized
DEBUG - 2018-03-19 09:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 09:48:07 --> Input Class Initialized
INFO - 2018-03-19 09:48:07 --> Language Class Initialized
INFO - 2018-03-19 09:48:07 --> Language Class Initialized
INFO - 2018-03-19 09:48:08 --> Config Class Initialized
INFO - 2018-03-19 09:48:08 --> Loader Class Initialized
INFO - 2018-03-19 15:18:08 --> Helper loaded: url_helper
INFO - 2018-03-19 15:18:08 --> Helper loaded: notification_helper
INFO - 2018-03-19 15:18:08 --> Helper loaded: settings_helper
INFO - 2018-03-19 15:18:08 --> Helper loaded: permission_helper
INFO - 2018-03-19 15:18:08 --> Helper loaded: users_helper
INFO - 2018-03-19 15:18:08 --> Database Driver Class Initialized
DEBUG - 2018-03-19 15:18:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-19 15:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-19 15:18:08 --> Helper loaded: form_helper
INFO - 2018-03-19 15:18:08 --> Form Validation Class Initialized
INFO - 2018-03-19 15:18:08 --> Controller Class Initialized
INFO - 2018-03-19 15:18:08 --> Model Class Initialized
INFO - 2018-03-19 15:18:08 --> Helper loaded: inflector_helper
INFO - 2018-03-19 15:18:08 --> Model Class Initialized
INFO - 2018-03-19 15:18:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-19 09:48:09 --> Config Class Initialized
INFO - 2018-03-19 09:48:09 --> Hooks Class Initialized
DEBUG - 2018-03-19 09:48:09 --> UTF-8 Support Enabled
INFO - 2018-03-19 09:48:09 --> Utf8 Class Initialized
INFO - 2018-03-19 09:48:09 --> URI Class Initialized
INFO - 2018-03-19 09:48:09 --> Router Class Initialized
INFO - 2018-03-19 09:48:09 --> Output Class Initialized
INFO - 2018-03-19 09:48:09 --> Security Class Initialized
DEBUG - 2018-03-19 09:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 09:48:09 --> Input Class Initialized
INFO - 2018-03-19 09:48:09 --> Language Class Initialized
INFO - 2018-03-19 09:48:09 --> Language Class Initialized
INFO - 2018-03-19 09:48:09 --> Config Class Initialized
INFO - 2018-03-19 09:48:09 --> Loader Class Initialized
INFO - 2018-03-19 15:18:09 --> Helper loaded: url_helper
INFO - 2018-03-19 15:18:09 --> Helper loaded: notification_helper
INFO - 2018-03-19 15:18:09 --> Helper loaded: settings_helper
INFO - 2018-03-19 15:18:09 --> Helper loaded: permission_helper
INFO - 2018-03-19 15:18:09 --> Helper loaded: users_helper
INFO - 2018-03-19 09:48:09 --> Config Class Initialized
INFO - 2018-03-19 09:48:09 --> Hooks Class Initialized
DEBUG - 2018-03-19 09:48:09 --> UTF-8 Support Enabled
INFO - 2018-03-19 09:48:09 --> Utf8 Class Initialized
INFO - 2018-03-19 09:48:09 --> URI Class Initialized
INFO - 2018-03-19 09:48:09 --> Router Class Initialized
INFO - 2018-03-19 15:18:09 --> Database Driver Class Initialized
INFO - 2018-03-19 09:48:09 --> Output Class Initialized
DEBUG - 2018-03-19 15:18:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-19 15:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-19 09:48:09 --> Security Class Initialized
DEBUG - 2018-03-19 09:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 09:48:09 --> Input Class Initialized
INFO - 2018-03-19 09:48:09 --> Language Class Initialized
INFO - 2018-03-19 15:18:09 --> Helper loaded: form_helper
INFO - 2018-03-19 15:18:09 --> Form Validation Class Initialized
INFO - 2018-03-19 15:18:09 --> Controller Class Initialized
DEBUG - 2018-03-19 15:18:09 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-03-19 15:18:09 --> Final output sent to browser
DEBUG - 2018-03-19 15:18:09 --> Total execution time: 0.2669
INFO - 2018-03-19 09:48:09 --> Language Class Initialized
INFO - 2018-03-19 09:48:09 --> Config Class Initialized
INFO - 2018-03-19 09:48:09 --> Loader Class Initialized
INFO - 2018-03-19 15:18:09 --> Helper loaded: url_helper
INFO - 2018-03-19 15:18:09 --> Helper loaded: notification_helper
INFO - 2018-03-19 15:18:09 --> Helper loaded: settings_helper
INFO - 2018-03-19 15:18:09 --> Helper loaded: permission_helper
INFO - 2018-03-19 15:18:09 --> Helper loaded: users_helper
INFO - 2018-03-19 15:18:09 --> Database Driver Class Initialized
DEBUG - 2018-03-19 15:18:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-19 15:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-19 15:18:09 --> Helper loaded: form_helper
INFO - 2018-03-19 15:18:09 --> Form Validation Class Initialized
INFO - 2018-03-19 15:18:09 --> Controller Class Initialized
INFO - 2018-03-19 15:18:10 --> Model Class Initialized
INFO - 2018-03-19 15:18:10 --> Helper loaded: inflector_helper
INFO - 2018-03-19 15:18:10 --> Model Class Initialized
INFO - 2018-03-19 15:18:10 --> Model Class Initialized
INFO - 2018-03-19 15:18:10 --> Model Class Initialized
INFO - 2018-03-19 15:18:10 --> Model Class Initialized
INFO - 2018-03-19 15:18:10 --> Model Class Initialized
DEBUG - 2018-03-19 15:18:10 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-03-19 15:18:10 --> File loaded: /home/pr01004/public_html/application/views/admin/dashboard.php
DEBUG - 2018-03-19 15:18:10 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-03-19 15:18:10 --> Final output sent to browser
DEBUG - 2018-03-19 15:18:10 --> Total execution time: 0.9594
INFO - 2018-03-19 09:48:19 --> Config Class Initialized
INFO - 2018-03-19 09:48:19 --> Hooks Class Initialized
DEBUG - 2018-03-19 09:48:19 --> UTF-8 Support Enabled
INFO - 2018-03-19 09:48:19 --> Utf8 Class Initialized
INFO - 2018-03-19 09:48:19 --> URI Class Initialized
INFO - 2018-03-19 09:48:19 --> Router Class Initialized
INFO - 2018-03-19 09:48:19 --> Output Class Initialized
INFO - 2018-03-19 09:48:19 --> Security Class Initialized
DEBUG - 2018-03-19 09:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 09:48:19 --> Input Class Initialized
INFO - 2018-03-19 09:48:19 --> Language Class Initialized
INFO - 2018-03-19 09:48:19 --> Language Class Initialized
INFO - 2018-03-19 09:48:19 --> Config Class Initialized
INFO - 2018-03-19 09:48:19 --> Loader Class Initialized
INFO - 2018-03-19 15:18:19 --> Helper loaded: url_helper
INFO - 2018-03-19 15:18:19 --> Helper loaded: notification_helper
INFO - 2018-03-19 15:18:19 --> Helper loaded: settings_helper
INFO - 2018-03-19 15:18:19 --> Helper loaded: permission_helper
INFO - 2018-03-19 15:18:19 --> Helper loaded: users_helper
INFO - 2018-03-19 15:18:19 --> Database Driver Class Initialized
DEBUG - 2018-03-19 15:18:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-19 15:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-19 15:18:19 --> Helper loaded: form_helper
INFO - 2018-03-19 15:18:19 --> Form Validation Class Initialized
INFO - 2018-03-19 15:18:19 --> Controller Class Initialized
INFO - 2018-03-19 15:18:19 --> Model Class Initialized
INFO - 2018-03-19 15:18:19 --> Helper loaded: inflector_helper
INFO - 2018-03-19 15:18:19 --> Model Class Initialized
INFO - 2018-03-19 15:18:19 --> Model Class Initialized
INFO - 2018-03-19 15:18:19 --> Model Class Initialized
DEBUG - 2018-03-19 15:18:19 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-03-19 15:18:19 --> File loaded: /home/pr01004/public_html/application/views/preference/index.php
DEBUG - 2018-03-19 15:18:19 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-03-19 15:18:19 --> Final output sent to browser
DEBUG - 2018-03-19 15:18:19 --> Total execution time: 0.1366
INFO - 2018-03-19 13:59:07 --> Config Class Initialized
INFO - 2018-03-19 13:59:07 --> Hooks Class Initialized
DEBUG - 2018-03-19 13:59:07 --> UTF-8 Support Enabled
INFO - 2018-03-19 13:59:07 --> Utf8 Class Initialized
INFO - 2018-03-19 13:59:07 --> URI Class Initialized
INFO - 2018-03-19 13:59:07 --> Router Class Initialized
INFO - 2018-03-19 13:59:07 --> Output Class Initialized
INFO - 2018-03-19 13:59:07 --> Security Class Initialized
DEBUG - 2018-03-19 13:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 13:59:07 --> Input Class Initialized
INFO - 2018-03-19 13:59:07 --> Language Class Initialized
INFO - 2018-03-19 13:59:07 --> Config Class Initialized
INFO - 2018-03-19 13:59:07 --> Hooks Class Initialized
DEBUG - 2018-03-19 13:59:07 --> UTF-8 Support Enabled
INFO - 2018-03-19 13:59:07 --> Utf8 Class Initialized
INFO - 2018-03-19 13:59:07 --> URI Class Initialized
INFO - 2018-03-19 13:59:07 --> Language Class Initialized
INFO - 2018-03-19 13:59:07 --> Config Class Initialized
INFO - 2018-03-19 13:59:07 --> Loader Class Initialized
INFO - 2018-03-19 19:29:07 --> Helper loaded: url_helper
INFO - 2018-03-19 19:29:07 --> Helper loaded: notification_helper
INFO - 2018-03-19 13:59:07 --> Router Class Initialized
INFO - 2018-03-19 19:29:07 --> Helper loaded: settings_helper
INFO - 2018-03-19 19:29:07 --> Helper loaded: permission_helper
INFO - 2018-03-19 19:29:07 --> Helper loaded: users_helper
INFO - 2018-03-19 13:59:07 --> Output Class Initialized
INFO - 2018-03-19 13:59:07 --> Security Class Initialized
INFO - 2018-03-19 19:29:07 --> Database Driver Class Initialized
DEBUG - 2018-03-19 13:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 13:59:07 --> Input Class Initialized
INFO - 2018-03-19 13:59:07 --> Language Class Initialized
DEBUG - 2018-03-19 19:29:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-19 19:29:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-19 19:29:07 --> Helper loaded: form_helper
INFO - 2018-03-19 19:29:07 --> Form Validation Class Initialized
INFO - 2018-03-19 19:29:07 --> Controller Class Initialized
INFO - 2018-03-19 19:29:07 --> Model Class Initialized
INFO - 2018-03-19 19:29:07 --> Helper loaded: inflector_helper
DEBUG - 2018-03-19 19:29:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-19 19:29:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-19 19:29:07 --> Model Class Initialized
INFO - 2018-03-19 19:29:07 --> Model Class Initialized
INFO - 2018-03-19 19:29:07 --> Model Class Initialized
INFO - 2018-03-19 19:29:07 --> Model Class Initialized
INFO - 2018-03-19 19:29:07 --> Model Class Initialized
INFO - 2018-03-19 19:29:07 --> Model Class Initialized
INFO - 2018-03-19 19:29:07 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-19 13:59:07 --> Language Class Initialized
INFO - 2018-03-19 13:59:07 --> Config Class Initialized
INFO - 2018-03-19 13:59:07 --> Loader Class Initialized
INFO - 2018-03-19 19:29:07 --> Final output sent to browser
DEBUG - 2018-03-19 19:29:07 --> Total execution time: 0.1164
INFO - 2018-03-19 19:29:07 --> Helper loaded: url_helper
INFO - 2018-03-19 19:29:07 --> Helper loaded: notification_helper
INFO - 2018-03-19 19:29:07 --> Helper loaded: settings_helper
INFO - 2018-03-19 19:29:07 --> Helper loaded: permission_helper
INFO - 2018-03-19 19:29:07 --> Helper loaded: users_helper
INFO - 2018-03-19 19:29:07 --> Database Driver Class Initialized
DEBUG - 2018-03-19 19:29:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-19 19:29:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-19 19:29:08 --> Helper loaded: form_helper
INFO - 2018-03-19 19:29:08 --> Form Validation Class Initialized
INFO - 2018-03-19 19:29:08 --> Controller Class Initialized
INFO - 2018-03-19 19:29:08 --> Model Class Initialized
INFO - 2018-03-19 19:29:08 --> Helper loaded: inflector_helper
DEBUG - 2018-03-19 19:29:08 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-19 19:29:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-19 19:29:08 --> Model Class Initialized
INFO - 2018-03-19 19:29:08 --> Model Class Initialized
INFO - 2018-03-19 19:29:08 --> Model Class Initialized
INFO - 2018-03-19 19:29:08 --> Model Class Initialized
INFO - 2018-03-19 19:29:08 --> Model Class Initialized
INFO - 2018-03-19 19:29:08 --> Model Class Initialized
INFO - 2018-03-19 19:29:08 --> Model Class Initialized
INFO - 2018-03-19 19:29:08 --> Model Class Initialized
INFO - 2018-03-19 19:29:08 --> Model Class Initialized
INFO - 2018-03-19 19:29:08 --> Model Class Initialized
INFO - 2018-03-19 19:29:08 --> Model Class Initialized
INFO - 2018-03-19 19:29:08 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-19 19:29:08 --> Model Class Initialized
INFO - 2018-03-19 19:29:08 --> Final output sent to browser
DEBUG - 2018-03-19 19:29:08 --> Total execution time: 0.2512
INFO - 2018-03-19 13:59:08 --> Config Class Initialized
INFO - 2018-03-19 13:59:08 --> Hooks Class Initialized
DEBUG - 2018-03-19 13:59:08 --> UTF-8 Support Enabled
INFO - 2018-03-19 13:59:08 --> Utf8 Class Initialized
INFO - 2018-03-19 13:59:08 --> URI Class Initialized
INFO - 2018-03-19 13:59:08 --> Router Class Initialized
INFO - 2018-03-19 13:59:08 --> Output Class Initialized
INFO - 2018-03-19 13:59:08 --> Security Class Initialized
DEBUG - 2018-03-19 13:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 13:59:08 --> Input Class Initialized
INFO - 2018-03-19 13:59:08 --> Language Class Initialized
INFO - 2018-03-19 13:59:08 --> Language Class Initialized
INFO - 2018-03-19 13:59:08 --> Config Class Initialized
INFO - 2018-03-19 13:59:08 --> Loader Class Initialized
INFO - 2018-03-19 19:29:08 --> Helper loaded: url_helper
INFO - 2018-03-19 19:29:08 --> Helper loaded: notification_helper
INFO - 2018-03-19 19:29:08 --> Helper loaded: settings_helper
INFO - 2018-03-19 19:29:08 --> Helper loaded: permission_helper
INFO - 2018-03-19 19:29:08 --> Helper loaded: users_helper
INFO - 2018-03-19 19:29:08 --> Database Driver Class Initialized
DEBUG - 2018-03-19 19:29:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-19 19:29:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-19 19:29:08 --> Helper loaded: form_helper
INFO - 2018-03-19 19:29:08 --> Form Validation Class Initialized
INFO - 2018-03-19 19:29:08 --> Controller Class Initialized
INFO - 2018-03-19 19:29:08 --> Model Class Initialized
INFO - 2018-03-19 19:29:08 --> Helper loaded: inflector_helper
DEBUG - 2018-03-19 19:29:08 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-19 19:29:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-19 19:29:08 --> Model Class Initialized
INFO - 2018-03-19 19:29:08 --> Model Class Initialized
INFO - 2018-03-19 19:29:08 --> Model Class Initialized
INFO - 2018-03-19 19:29:08 --> Model Class Initialized
INFO - 2018-03-19 19:29:08 --> Model Class Initialized
INFO - 2018-03-19 19:29:08 --> Model Class Initialized
INFO - 2018-03-19 19:29:08 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-19 19:29:08 --> Model Class Initialized
INFO - 2018-03-19 19:29:08 --> Final output sent to browser
DEBUG - 2018-03-19 19:29:08 --> Total execution time: 0.5993
INFO - 2018-03-19 13:59:23 --> Config Class Initialized
INFO - 2018-03-19 13:59:23 --> Hooks Class Initialized
DEBUG - 2018-03-19 13:59:23 --> UTF-8 Support Enabled
INFO - 2018-03-19 13:59:23 --> Utf8 Class Initialized
INFO - 2018-03-19 13:59:23 --> URI Class Initialized
INFO - 2018-03-19 13:59:23 --> Router Class Initialized
INFO - 2018-03-19 13:59:23 --> Output Class Initialized
INFO - 2018-03-19 13:59:23 --> Security Class Initialized
DEBUG - 2018-03-19 13:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 13:59:23 --> Input Class Initialized
INFO - 2018-03-19 13:59:23 --> Language Class Initialized
INFO - 2018-03-19 13:59:23 --> Language Class Initialized
INFO - 2018-03-19 13:59:23 --> Config Class Initialized
INFO - 2018-03-19 13:59:23 --> Loader Class Initialized
INFO - 2018-03-19 19:29:23 --> Helper loaded: url_helper
INFO - 2018-03-19 19:29:23 --> Helper loaded: notification_helper
INFO - 2018-03-19 19:29:23 --> Helper loaded: settings_helper
INFO - 2018-03-19 19:29:23 --> Helper loaded: permission_helper
INFO - 2018-03-19 19:29:24 --> Helper loaded: users_helper
INFO - 2018-03-19 19:29:24 --> Database Driver Class Initialized
DEBUG - 2018-03-19 19:29:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-19 19:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-19 19:29:24 --> Helper loaded: form_helper
INFO - 2018-03-19 19:29:24 --> Form Validation Class Initialized
INFO - 2018-03-19 19:29:24 --> Controller Class Initialized
INFO - 2018-03-19 19:29:24 --> Model Class Initialized
INFO - 2018-03-19 19:29:24 --> Helper loaded: inflector_helper
DEBUG - 2018-03-19 19:29:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-19 19:29:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-19 19:29:24 --> Model Class Initialized
INFO - 2018-03-19 19:29:24 --> Model Class Initialized
INFO - 2018-03-19 19:29:24 --> Model Class Initialized
INFO - 2018-03-19 19:29:24 --> Model Class Initialized
INFO - 2018-03-19 19:29:24 --> Model Class Initialized
INFO - 2018-03-19 19:29:24 --> Model Class Initialized
INFO - 2018-03-19 19:29:24 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-19 19:29:24 --> Model Class Initialized
INFO - 2018-03-19 19:29:24 --> Model Class Initialized
INFO - 2018-03-19 19:29:24 --> Final output sent to browser
DEBUG - 2018-03-19 19:29:24 --> Total execution time: 0.4558
INFO - 2018-03-19 13:59:25 --> Config Class Initialized
INFO - 2018-03-19 13:59:25 --> Hooks Class Initialized
DEBUG - 2018-03-19 13:59:25 --> UTF-8 Support Enabled
INFO - 2018-03-19 13:59:25 --> Utf8 Class Initialized
INFO - 2018-03-19 13:59:25 --> URI Class Initialized
INFO - 2018-03-19 13:59:25 --> Router Class Initialized
INFO - 2018-03-19 13:59:25 --> Output Class Initialized
INFO - 2018-03-19 13:59:25 --> Security Class Initialized
DEBUG - 2018-03-19 13:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 13:59:25 --> Input Class Initialized
INFO - 2018-03-19 13:59:25 --> Language Class Initialized
INFO - 2018-03-19 13:59:25 --> Language Class Initialized
INFO - 2018-03-19 13:59:25 --> Config Class Initialized
INFO - 2018-03-19 13:59:25 --> Loader Class Initialized
INFO - 2018-03-19 19:29:25 --> Helper loaded: url_helper
INFO - 2018-03-19 19:29:25 --> Helper loaded: notification_helper
INFO - 2018-03-19 19:29:25 --> Helper loaded: settings_helper
INFO - 2018-03-19 19:29:25 --> Helper loaded: permission_helper
INFO - 2018-03-19 19:29:25 --> Helper loaded: users_helper
INFO - 2018-03-19 19:29:25 --> Database Driver Class Initialized
DEBUG - 2018-03-19 19:29:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-19 19:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-19 19:29:25 --> Helper loaded: form_helper
INFO - 2018-03-19 19:29:25 --> Form Validation Class Initialized
INFO - 2018-03-19 19:29:25 --> Controller Class Initialized
INFO - 2018-03-19 19:29:25 --> Model Class Initialized
INFO - 2018-03-19 19:29:25 --> Helper loaded: inflector_helper
DEBUG - 2018-03-19 19:29:25 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-19 19:29:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-19 19:29:25 --> Model Class Initialized
INFO - 2018-03-19 19:29:25 --> Model Class Initialized
INFO - 2018-03-19 19:29:25 --> Model Class Initialized
INFO - 2018-03-19 19:29:25 --> Model Class Initialized
INFO - 2018-03-19 19:29:25 --> Model Class Initialized
INFO - 2018-03-19 19:29:25 --> Model Class Initialized
INFO - 2018-03-19 19:29:25 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-19 19:29:25 --> Model Class Initialized
INFO - 2018-03-19 19:29:25 --> Model Class Initialized
INFO - 2018-03-19 19:29:25 --> Model Class Initialized
INFO - 2018-03-19 19:29:26 --> Final output sent to browser
DEBUG - 2018-03-19 19:29:26 --> Total execution time: 0.4759
INFO - 2018-03-19 13:59:27 --> Config Class Initialized
INFO - 2018-03-19 13:59:27 --> Hooks Class Initialized
DEBUG - 2018-03-19 13:59:27 --> UTF-8 Support Enabled
INFO - 2018-03-19 13:59:27 --> Utf8 Class Initialized
INFO - 2018-03-19 13:59:27 --> URI Class Initialized
INFO - 2018-03-19 13:59:27 --> Router Class Initialized
INFO - 2018-03-19 13:59:27 --> Output Class Initialized
INFO - 2018-03-19 13:59:27 --> Security Class Initialized
DEBUG - 2018-03-19 13:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 13:59:27 --> Input Class Initialized
INFO - 2018-03-19 13:59:27 --> Language Class Initialized
INFO - 2018-03-19 13:59:27 --> Language Class Initialized
INFO - 2018-03-19 13:59:27 --> Config Class Initialized
INFO - 2018-03-19 13:59:27 --> Loader Class Initialized
INFO - 2018-03-19 19:29:27 --> Helper loaded: url_helper
INFO - 2018-03-19 19:29:27 --> Helper loaded: notification_helper
INFO - 2018-03-19 19:29:27 --> Helper loaded: settings_helper
INFO - 2018-03-19 19:29:27 --> Helper loaded: permission_helper
INFO - 2018-03-19 19:29:27 --> Helper loaded: users_helper
INFO - 2018-03-19 19:29:27 --> Database Driver Class Initialized
DEBUG - 2018-03-19 19:29:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-19 19:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-19 19:29:27 --> Helper loaded: form_helper
INFO - 2018-03-19 19:29:27 --> Form Validation Class Initialized
INFO - 2018-03-19 19:29:27 --> Controller Class Initialized
INFO - 2018-03-19 19:29:27 --> Model Class Initialized
INFO - 2018-03-19 19:29:27 --> Helper loaded: inflector_helper
DEBUG - 2018-03-19 19:29:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-19 19:29:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-19 19:29:27 --> Model Class Initialized
INFO - 2018-03-19 19:29:27 --> Model Class Initialized
INFO - 2018-03-19 19:29:27 --> Model Class Initialized
INFO - 2018-03-19 19:29:27 --> Model Class Initialized
INFO - 2018-03-19 19:29:27 --> Model Class Initialized
INFO - 2018-03-19 19:29:27 --> Model Class Initialized
INFO - 2018-03-19 19:29:27 --> Model Class Initialized
INFO - 2018-03-19 19:29:27 --> Model Class Initialized
INFO - 2018-03-19 19:29:27 --> Model Class Initialized
INFO - 2018-03-19 19:29:27 --> Model Class Initialized
INFO - 2018-03-19 19:29:27 --> Model Class Initialized
INFO - 2018-03-19 19:29:27 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-19 19:29:27 --> Model Class Initialized
INFO - 2018-03-19 19:29:27 --> Final output sent to browser
DEBUG - 2018-03-19 19:29:27 --> Total execution time: 0.2624
INFO - 2018-03-19 13:59:31 --> Config Class Initialized
INFO - 2018-03-19 13:59:31 --> Hooks Class Initialized
DEBUG - 2018-03-19 13:59:31 --> UTF-8 Support Enabled
INFO - 2018-03-19 13:59:31 --> Utf8 Class Initialized
INFO - 2018-03-19 13:59:31 --> URI Class Initialized
INFO - 2018-03-19 13:59:31 --> Router Class Initialized
INFO - 2018-03-19 13:59:31 --> Output Class Initialized
INFO - 2018-03-19 13:59:31 --> Security Class Initialized
DEBUG - 2018-03-19 13:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 13:59:31 --> Input Class Initialized
INFO - 2018-03-19 13:59:31 --> Language Class Initialized
INFO - 2018-03-19 13:59:31 --> Language Class Initialized
INFO - 2018-03-19 13:59:31 --> Config Class Initialized
INFO - 2018-03-19 13:59:31 --> Loader Class Initialized
INFO - 2018-03-19 19:29:31 --> Helper loaded: url_helper
INFO - 2018-03-19 19:29:31 --> Helper loaded: notification_helper
INFO - 2018-03-19 19:29:31 --> Helper loaded: settings_helper
INFO - 2018-03-19 19:29:31 --> Helper loaded: permission_helper
INFO - 2018-03-19 19:29:31 --> Helper loaded: users_helper
INFO - 2018-03-19 19:29:31 --> Database Driver Class Initialized
DEBUG - 2018-03-19 19:29:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-19 19:29:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-19 19:29:31 --> Helper loaded: form_helper
INFO - 2018-03-19 19:29:31 --> Form Validation Class Initialized
INFO - 2018-03-19 19:29:31 --> Controller Class Initialized
INFO - 2018-03-19 19:29:31 --> Model Class Initialized
INFO - 2018-03-19 19:29:31 --> Helper loaded: inflector_helper
DEBUG - 2018-03-19 19:29:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-19 19:29:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-19 19:29:31 --> Model Class Initialized
INFO - 2018-03-19 19:29:31 --> Model Class Initialized
INFO - 2018-03-19 19:29:31 --> Model Class Initialized
INFO - 2018-03-19 19:29:31 --> Model Class Initialized
INFO - 2018-03-19 19:29:31 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-19 19:29:31 --> Final output sent to browser
DEBUG - 2018-03-19 19:29:31 --> Total execution time: 0.0784
INFO - 2018-03-19 13:59:32 --> Config Class Initialized
INFO - 2018-03-19 13:59:32 --> Hooks Class Initialized
DEBUG - 2018-03-19 13:59:32 --> UTF-8 Support Enabled
INFO - 2018-03-19 13:59:32 --> Utf8 Class Initialized
INFO - 2018-03-19 13:59:32 --> URI Class Initialized
INFO - 2018-03-19 13:59:32 --> Router Class Initialized
INFO - 2018-03-19 13:59:32 --> Output Class Initialized
INFO - 2018-03-19 13:59:32 --> Security Class Initialized
DEBUG - 2018-03-19 13:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 13:59:32 --> Input Class Initialized
INFO - 2018-03-19 13:59:32 --> Language Class Initialized
INFO - 2018-03-19 13:59:32 --> Language Class Initialized
INFO - 2018-03-19 13:59:32 --> Config Class Initialized
INFO - 2018-03-19 13:59:32 --> Loader Class Initialized
INFO - 2018-03-19 19:29:32 --> Helper loaded: url_helper
INFO - 2018-03-19 19:29:32 --> Helper loaded: notification_helper
INFO - 2018-03-19 19:29:32 --> Helper loaded: settings_helper
INFO - 2018-03-19 19:29:32 --> Helper loaded: permission_helper
INFO - 2018-03-19 19:29:32 --> Helper loaded: users_helper
INFO - 2018-03-19 19:29:32 --> Database Driver Class Initialized
DEBUG - 2018-03-19 19:29:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-19 19:29:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-19 19:29:32 --> Helper loaded: form_helper
INFO - 2018-03-19 19:29:32 --> Form Validation Class Initialized
INFO - 2018-03-19 19:29:32 --> Controller Class Initialized
INFO - 2018-03-19 19:29:32 --> Model Class Initialized
INFO - 2018-03-19 19:29:32 --> Helper loaded: inflector_helper
DEBUG - 2018-03-19 19:29:32 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-19 19:29:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-19 19:29:32 --> Model Class Initialized
INFO - 2018-03-19 19:29:32 --> Model Class Initialized
INFO - 2018-03-19 19:29:32 --> Model Class Initialized
INFO - 2018-03-19 19:29:32 --> Model Class Initialized
INFO - 2018-03-19 19:29:32 --> Model Class Initialized
INFO - 2018-03-19 19:29:32 --> Model Class Initialized
INFO - 2018-03-19 19:29:32 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-19 19:29:32 --> Final output sent to browser
DEBUG - 2018-03-19 19:29:32 --> Total execution time: 0.7587
INFO - 2018-03-19 13:59:33 --> Config Class Initialized
INFO - 2018-03-19 13:59:33 --> Hooks Class Initialized
DEBUG - 2018-03-19 13:59:33 --> UTF-8 Support Enabled
INFO - 2018-03-19 13:59:33 --> Utf8 Class Initialized
INFO - 2018-03-19 13:59:33 --> URI Class Initialized
INFO - 2018-03-19 13:59:33 --> Router Class Initialized
INFO - 2018-03-19 13:59:33 --> Output Class Initialized
INFO - 2018-03-19 13:59:33 --> Security Class Initialized
DEBUG - 2018-03-19 13:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 13:59:33 --> Input Class Initialized
INFO - 2018-03-19 13:59:33 --> Language Class Initialized
INFO - 2018-03-19 13:59:33 --> Language Class Initialized
INFO - 2018-03-19 13:59:33 --> Config Class Initialized
INFO - 2018-03-19 13:59:33 --> Loader Class Initialized
INFO - 2018-03-19 19:29:33 --> Helper loaded: url_helper
INFO - 2018-03-19 19:29:33 --> Helper loaded: notification_helper
INFO - 2018-03-19 19:29:33 --> Helper loaded: settings_helper
INFO - 2018-03-19 19:29:33 --> Helper loaded: permission_helper
INFO - 2018-03-19 19:29:33 --> Helper loaded: users_helper
INFO - 2018-03-19 19:29:33 --> Database Driver Class Initialized
DEBUG - 2018-03-19 19:29:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-19 19:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-19 19:29:33 --> Helper loaded: form_helper
INFO - 2018-03-19 19:29:33 --> Form Validation Class Initialized
INFO - 2018-03-19 19:29:33 --> Controller Class Initialized
INFO - 2018-03-19 19:29:33 --> Model Class Initialized
INFO - 2018-03-19 19:29:33 --> Helper loaded: inflector_helper
DEBUG - 2018-03-19 19:29:33 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-19 19:29:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-19 19:29:33 --> Model Class Initialized
INFO - 2018-03-19 19:29:33 --> Model Class Initialized
INFO - 2018-03-19 19:29:33 --> Model Class Initialized
INFO - 2018-03-19 19:29:33 --> Model Class Initialized
INFO - 2018-03-19 19:29:33 --> Final output sent to browser
DEBUG - 2018-03-19 19:29:33 --> Total execution time: 0.1974
INFO - 2018-03-19 13:59:34 --> Config Class Initialized
INFO - 2018-03-19 13:59:34 --> Hooks Class Initialized
DEBUG - 2018-03-19 13:59:34 --> UTF-8 Support Enabled
INFO - 2018-03-19 13:59:34 --> Utf8 Class Initialized
INFO - 2018-03-19 13:59:34 --> URI Class Initialized
INFO - 2018-03-19 13:59:34 --> Router Class Initialized
INFO - 2018-03-19 13:59:34 --> Output Class Initialized
INFO - 2018-03-19 13:59:34 --> Security Class Initialized
DEBUG - 2018-03-19 13:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 13:59:34 --> Input Class Initialized
INFO - 2018-03-19 13:59:34 --> Language Class Initialized
INFO - 2018-03-19 13:59:34 --> Language Class Initialized
INFO - 2018-03-19 13:59:34 --> Config Class Initialized
INFO - 2018-03-19 13:59:34 --> Loader Class Initialized
INFO - 2018-03-19 19:29:34 --> Helper loaded: url_helper
INFO - 2018-03-19 19:29:34 --> Helper loaded: notification_helper
INFO - 2018-03-19 19:29:34 --> Helper loaded: settings_helper
INFO - 2018-03-19 19:29:34 --> Helper loaded: permission_helper
INFO - 2018-03-19 19:29:34 --> Helper loaded: users_helper
INFO - 2018-03-19 19:29:34 --> Database Driver Class Initialized
DEBUG - 2018-03-19 19:29:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-19 19:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-19 19:29:35 --> Helper loaded: form_helper
INFO - 2018-03-19 19:29:35 --> Form Validation Class Initialized
INFO - 2018-03-19 19:29:35 --> Controller Class Initialized
INFO - 2018-03-19 19:29:35 --> Model Class Initialized
INFO - 2018-03-19 19:29:35 --> Helper loaded: inflector_helper
DEBUG - 2018-03-19 19:29:35 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-19 19:29:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-19 19:29:35 --> Model Class Initialized
INFO - 2018-03-19 19:29:35 --> Model Class Initialized
INFO - 2018-03-19 19:29:35 --> Model Class Initialized
INFO - 2018-03-19 19:29:35 --> Model Class Initialized
INFO - 2018-03-19 19:29:35 --> Model Class Initialized
INFO - 2018-03-19 19:29:35 --> Model Class Initialized
INFO - 2018-03-19 19:29:35 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-19 19:29:35 --> Final output sent to browser
DEBUG - 2018-03-19 19:29:35 --> Total execution time: 0.2388
INFO - 2018-03-19 14:00:02 --> Config Class Initialized
INFO - 2018-03-19 14:00:02 --> Hooks Class Initialized
DEBUG - 2018-03-19 14:00:02 --> UTF-8 Support Enabled
INFO - 2018-03-19 14:00:02 --> Utf8 Class Initialized
INFO - 2018-03-19 14:00:02 --> URI Class Initialized
INFO - 2018-03-19 14:00:02 --> Router Class Initialized
INFO - 2018-03-19 14:00:02 --> Output Class Initialized
INFO - 2018-03-19 14:00:02 --> Security Class Initialized
DEBUG - 2018-03-19 14:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 14:00:02 --> Input Class Initialized
INFO - 2018-03-19 14:00:02 --> Language Class Initialized
INFO - 2018-03-19 14:00:02 --> Language Class Initialized
INFO - 2018-03-19 14:00:02 --> Config Class Initialized
INFO - 2018-03-19 14:00:02 --> Loader Class Initialized
INFO - 2018-03-19 19:30:02 --> Helper loaded: url_helper
INFO - 2018-03-19 19:30:02 --> Helper loaded: notification_helper
INFO - 2018-03-19 19:30:02 --> Helper loaded: settings_helper
INFO - 2018-03-19 19:30:02 --> Helper loaded: permission_helper
INFO - 2018-03-19 19:30:02 --> Helper loaded: users_helper
INFO - 2018-03-19 19:30:02 --> Database Driver Class Initialized
DEBUG - 2018-03-19 19:30:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-19 19:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-19 19:30:02 --> Helper loaded: form_helper
INFO - 2018-03-19 19:30:02 --> Form Validation Class Initialized
INFO - 2018-03-19 19:30:02 --> Controller Class Initialized
INFO - 2018-03-19 19:30:02 --> Model Class Initialized
INFO - 2018-03-19 19:30:02 --> Helper loaded: inflector_helper
DEBUG - 2018-03-19 19:30:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-19 19:30:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-19 19:30:02 --> Model Class Initialized
INFO - 2018-03-19 19:30:02 --> Model Class Initialized
INFO - 2018-03-19 19:30:02 --> Model Class Initialized
INFO - 2018-03-19 19:30:02 --> Model Class Initialized
INFO - 2018-03-19 19:30:02 --> Final output sent to browser
DEBUG - 2018-03-19 19:30:02 --> Total execution time: 0.0977
INFO - 2018-03-19 14:00:03 --> Config Class Initialized
INFO - 2018-03-19 14:00:03 --> Hooks Class Initialized
DEBUG - 2018-03-19 14:00:03 --> UTF-8 Support Enabled
INFO - 2018-03-19 14:00:03 --> Utf8 Class Initialized
INFO - 2018-03-19 14:00:03 --> URI Class Initialized
INFO - 2018-03-19 14:00:03 --> Router Class Initialized
INFO - 2018-03-19 14:00:03 --> Output Class Initialized
INFO - 2018-03-19 14:00:03 --> Security Class Initialized
DEBUG - 2018-03-19 14:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 14:00:03 --> Input Class Initialized
INFO - 2018-03-19 14:00:03 --> Language Class Initialized
INFO - 2018-03-19 14:00:03 --> Language Class Initialized
INFO - 2018-03-19 14:00:03 --> Config Class Initialized
INFO - 2018-03-19 14:00:03 --> Loader Class Initialized
INFO - 2018-03-19 19:30:03 --> Helper loaded: url_helper
INFO - 2018-03-19 19:30:03 --> Helper loaded: notification_helper
INFO - 2018-03-19 19:30:03 --> Helper loaded: settings_helper
INFO - 2018-03-19 19:30:03 --> Helper loaded: permission_helper
INFO - 2018-03-19 19:30:03 --> Helper loaded: users_helper
INFO - 2018-03-19 19:30:03 --> Database Driver Class Initialized
DEBUG - 2018-03-19 19:30:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-19 19:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-19 19:30:03 --> Helper loaded: form_helper
INFO - 2018-03-19 19:30:03 --> Form Validation Class Initialized
INFO - 2018-03-19 19:30:03 --> Controller Class Initialized
INFO - 2018-03-19 19:30:03 --> Model Class Initialized
INFO - 2018-03-19 19:30:03 --> Helper loaded: inflector_helper
DEBUG - 2018-03-19 19:30:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-19 19:30:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-19 19:30:03 --> Model Class Initialized
INFO - 2018-03-19 19:30:03 --> Model Class Initialized
INFO - 2018-03-19 19:30:03 --> Model Class Initialized
INFO - 2018-03-19 19:30:03 --> Model Class Initialized
INFO - 2018-03-19 19:30:03 --> Final output sent to browser
DEBUG - 2018-03-19 19:30:03 --> Total execution time: 0.3943
INFO - 2018-03-19 14:00:24 --> Config Class Initialized
INFO - 2018-03-19 14:00:24 --> Hooks Class Initialized
DEBUG - 2018-03-19 14:00:24 --> UTF-8 Support Enabled
INFO - 2018-03-19 14:00:24 --> Utf8 Class Initialized
INFO - 2018-03-19 14:00:24 --> URI Class Initialized
INFO - 2018-03-19 14:00:24 --> Router Class Initialized
INFO - 2018-03-19 14:00:24 --> Output Class Initialized
INFO - 2018-03-19 14:00:24 --> Security Class Initialized
DEBUG - 2018-03-19 14:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-19 14:00:24 --> Input Class Initialized
INFO - 2018-03-19 14:00:24 --> Language Class Initialized
INFO - 2018-03-19 14:00:24 --> Language Class Initialized
INFO - 2018-03-19 14:00:24 --> Config Class Initialized
INFO - 2018-03-19 14:00:24 --> Loader Class Initialized
INFO - 2018-03-19 19:30:24 --> Helper loaded: url_helper
INFO - 2018-03-19 19:30:24 --> Helper loaded: notification_helper
INFO - 2018-03-19 19:30:24 --> Helper loaded: settings_helper
INFO - 2018-03-19 19:30:24 --> Helper loaded: permission_helper
INFO - 2018-03-19 19:30:24 --> Helper loaded: users_helper
INFO - 2018-03-19 19:30:24 --> Database Driver Class Initialized
DEBUG - 2018-03-19 19:30:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-19 19:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-19 19:30:24 --> Helper loaded: form_helper
INFO - 2018-03-19 19:30:24 --> Form Validation Class Initialized
INFO - 2018-03-19 19:30:24 --> Controller Class Initialized
INFO - 2018-03-19 19:30:24 --> Model Class Initialized
INFO - 2018-03-19 19:30:24 --> Helper loaded: inflector_helper
DEBUG - 2018-03-19 19:30:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-19 19:30:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-19 19:30:24 --> Model Class Initialized
INFO - 2018-03-19 19:30:24 --> Model Class Initialized
INFO - 2018-03-19 19:30:24 --> Model Class Initialized
INFO - 2018-03-19 19:30:24 --> Model Class Initialized
INFO - 2018-03-19 19:30:24 --> Model Class Initialized
INFO - 2018-03-19 19:30:24 --> Model Class Initialized
INFO - 2018-03-19 19:30:24 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-19 19:30:24 --> Final output sent to browser
DEBUG - 2018-03-19 19:30:24 --> Total execution time: 0.1921
