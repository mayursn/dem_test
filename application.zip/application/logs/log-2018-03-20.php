<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-03-20 05:55:55 --> Config Class Initialized
INFO - 2018-03-20 05:55:55 --> Hooks Class Initialized
DEBUG - 2018-03-20 05:55:56 --> UTF-8 Support Enabled
INFO - 2018-03-20 05:55:56 --> Utf8 Class Initialized
INFO - 2018-03-20 05:55:56 --> URI Class Initialized
DEBUG - 2018-03-20 05:55:56 --> No URI present. Default controller set.
INFO - 2018-03-20 05:55:56 --> Router Class Initialized
INFO - 2018-03-20 05:55:56 --> Output Class Initialized
INFO - 2018-03-20 05:55:56 --> Security Class Initialized
DEBUG - 2018-03-20 05:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 05:55:56 --> Input Class Initialized
INFO - 2018-03-20 05:55:56 --> Language Class Initialized
INFO - 2018-03-20 05:55:56 --> Language Class Initialized
INFO - 2018-03-20 05:55:56 --> Config Class Initialized
INFO - 2018-03-20 05:55:56 --> Loader Class Initialized
INFO - 2018-03-20 11:25:56 --> Helper loaded: url_helper
INFO - 2018-03-20 11:25:56 --> Helper loaded: notification_helper
INFO - 2018-03-20 11:25:56 --> Helper loaded: settings_helper
INFO - 2018-03-20 11:25:56 --> Helper loaded: permission_helper
INFO - 2018-03-20 11:25:56 --> Helper loaded: users_helper
INFO - 2018-03-20 11:25:56 --> Database Driver Class Initialized
DEBUG - 2018-03-20 11:25:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 11:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 11:25:56 --> Helper loaded: form_helper
INFO - 2018-03-20 11:25:56 --> Form Validation Class Initialized
INFO - 2018-03-20 11:25:56 --> Controller Class Initialized
INFO - 2018-03-20 11:25:57 --> Model Class Initialized
INFO - 2018-03-20 11:25:57 --> Helper loaded: inflector_helper
INFO - 2018-03-20 11:25:57 --> Model Class Initialized
DEBUG - 2018-03-20 11:25:57 --> File loaded: /home/pr01004/public_html/application/views/login.php
INFO - 2018-03-20 11:25:57 --> Final output sent to browser
DEBUG - 2018-03-20 11:25:57 --> Total execution time: 1.1663
INFO - 2018-03-20 05:56:16 --> Config Class Initialized
INFO - 2018-03-20 05:56:16 --> Hooks Class Initialized
DEBUG - 2018-03-20 05:56:16 --> UTF-8 Support Enabled
INFO - 2018-03-20 05:56:16 --> Utf8 Class Initialized
INFO - 2018-03-20 05:56:16 --> URI Class Initialized
INFO - 2018-03-20 05:56:16 --> Router Class Initialized
INFO - 2018-03-20 05:56:16 --> Output Class Initialized
INFO - 2018-03-20 05:56:17 --> Security Class Initialized
DEBUG - 2018-03-20 05:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 05:56:17 --> Input Class Initialized
INFO - 2018-03-20 05:56:17 --> Language Class Initialized
INFO - 2018-03-20 05:56:17 --> Language Class Initialized
INFO - 2018-03-20 05:56:17 --> Config Class Initialized
INFO - 2018-03-20 05:56:17 --> Loader Class Initialized
INFO - 2018-03-20 11:26:17 --> Helper loaded: url_helper
INFO - 2018-03-20 11:26:17 --> Helper loaded: notification_helper
INFO - 2018-03-20 11:26:17 --> Helper loaded: settings_helper
INFO - 2018-03-20 11:26:17 --> Helper loaded: permission_helper
INFO - 2018-03-20 11:26:17 --> Helper loaded: users_helper
INFO - 2018-03-20 11:26:17 --> Database Driver Class Initialized
DEBUG - 2018-03-20 11:26:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 11:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 11:26:17 --> Helper loaded: form_helper
INFO - 2018-03-20 11:26:17 --> Form Validation Class Initialized
INFO - 2018-03-20 11:26:17 --> Controller Class Initialized
INFO - 2018-03-20 11:26:17 --> Model Class Initialized
INFO - 2018-03-20 11:26:17 --> Helper loaded: inflector_helper
INFO - 2018-03-20 11:26:17 --> Model Class Initialized
INFO - 2018-03-20 11:26:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-20 05:56:18 --> Config Class Initialized
INFO - 2018-03-20 05:56:18 --> Hooks Class Initialized
DEBUG - 2018-03-20 05:56:18 --> UTF-8 Support Enabled
INFO - 2018-03-20 05:56:18 --> Utf8 Class Initialized
INFO - 2018-03-20 05:56:18 --> URI Class Initialized
INFO - 2018-03-20 05:56:18 --> Router Class Initialized
INFO - 2018-03-20 05:56:19 --> Output Class Initialized
INFO - 2018-03-20 05:56:19 --> Security Class Initialized
DEBUG - 2018-03-20 05:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 05:56:19 --> Input Class Initialized
INFO - 2018-03-20 05:56:19 --> Language Class Initialized
INFO - 2018-03-20 05:56:19 --> Language Class Initialized
INFO - 2018-03-20 05:56:19 --> Config Class Initialized
INFO - 2018-03-20 05:56:19 --> Loader Class Initialized
INFO - 2018-03-20 11:26:19 --> Helper loaded: url_helper
INFO - 2018-03-20 11:26:19 --> Helper loaded: notification_helper
INFO - 2018-03-20 11:26:19 --> Helper loaded: settings_helper
INFO - 2018-03-20 11:26:19 --> Helper loaded: permission_helper
INFO - 2018-03-20 11:26:19 --> Helper loaded: users_helper
INFO - 2018-03-20 11:26:19 --> Database Driver Class Initialized
DEBUG - 2018-03-20 11:26:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 11:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 11:26:19 --> Helper loaded: form_helper
INFO - 2018-03-20 11:26:19 --> Form Validation Class Initialized
INFO - 2018-03-20 11:26:19 --> Controller Class Initialized
INFO - 2018-03-20 11:26:19 --> Model Class Initialized
INFO - 2018-03-20 11:26:19 --> Helper loaded: inflector_helper
INFO - 2018-03-20 11:26:19 --> Model Class Initialized
INFO - 2018-03-20 11:26:19 --> Model Class Initialized
INFO - 2018-03-20 11:26:19 --> Model Class Initialized
INFO - 2018-03-20 11:26:19 --> Model Class Initialized
INFO - 2018-03-20 11:26:19 --> Model Class Initialized
DEBUG - 2018-03-20 11:26:19 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-03-20 11:26:19 --> File loaded: /home/pr01004/public_html/application/views/admin/dashboard.php
DEBUG - 2018-03-20 11:26:19 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-03-20 11:26:19 --> Final output sent to browser
DEBUG - 2018-03-20 11:26:19 --> Total execution time: 0.5084
INFO - 2018-03-20 05:56:20 --> Config Class Initialized
INFO - 2018-03-20 05:56:20 --> Hooks Class Initialized
DEBUG - 2018-03-20 05:56:20 --> UTF-8 Support Enabled
INFO - 2018-03-20 05:56:20 --> Utf8 Class Initialized
INFO - 2018-03-20 05:56:20 --> URI Class Initialized
INFO - 2018-03-20 05:56:20 --> Router Class Initialized
INFO - 2018-03-20 05:56:20 --> Output Class Initialized
INFO - 2018-03-20 05:56:20 --> Security Class Initialized
DEBUG - 2018-03-20 05:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 05:56:20 --> Input Class Initialized
INFO - 2018-03-20 05:56:20 --> Language Class Initialized
INFO - 2018-03-20 05:56:21 --> Language Class Initialized
INFO - 2018-03-20 05:56:21 --> Config Class Initialized
INFO - 2018-03-20 05:56:21 --> Loader Class Initialized
INFO - 2018-03-20 11:26:21 --> Helper loaded: url_helper
INFO - 2018-03-20 11:26:21 --> Helper loaded: notification_helper
INFO - 2018-03-20 11:26:21 --> Helper loaded: settings_helper
INFO - 2018-03-20 11:26:21 --> Helper loaded: permission_helper
INFO - 2018-03-20 11:26:21 --> Helper loaded: users_helper
INFO - 2018-03-20 11:26:22 --> Database Driver Class Initialized
DEBUG - 2018-03-20 11:26:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 11:26:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 11:26:22 --> Helper loaded: form_helper
INFO - 2018-03-20 11:26:22 --> Form Validation Class Initialized
INFO - 2018-03-20 11:26:22 --> Controller Class Initialized
DEBUG - 2018-03-20 11:26:22 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-03-20 11:26:22 --> Final output sent to browser
DEBUG - 2018-03-20 11:26:22 --> Total execution time: 2.4530
INFO - 2018-03-20 05:56:38 --> Config Class Initialized
INFO - 2018-03-20 05:56:38 --> Hooks Class Initialized
DEBUG - 2018-03-20 05:56:38 --> UTF-8 Support Enabled
INFO - 2018-03-20 05:56:38 --> Utf8 Class Initialized
INFO - 2018-03-20 05:56:38 --> URI Class Initialized
INFO - 2018-03-20 05:56:38 --> Router Class Initialized
INFO - 2018-03-20 05:56:38 --> Output Class Initialized
INFO - 2018-03-20 05:56:38 --> Security Class Initialized
DEBUG - 2018-03-20 05:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 05:56:38 --> Input Class Initialized
INFO - 2018-03-20 05:56:38 --> Language Class Initialized
INFO - 2018-03-20 05:56:38 --> Language Class Initialized
INFO - 2018-03-20 05:56:38 --> Config Class Initialized
INFO - 2018-03-20 05:56:38 --> Loader Class Initialized
INFO - 2018-03-20 11:26:38 --> Helper loaded: url_helper
INFO - 2018-03-20 11:26:38 --> Helper loaded: notification_helper
INFO - 2018-03-20 11:26:38 --> Helper loaded: settings_helper
INFO - 2018-03-20 11:26:38 --> Helper loaded: permission_helper
INFO - 2018-03-20 11:26:38 --> Helper loaded: users_helper
INFO - 2018-03-20 11:26:39 --> Database Driver Class Initialized
DEBUG - 2018-03-20 11:26:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 11:26:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 11:26:39 --> Helper loaded: form_helper
INFO - 2018-03-20 11:26:39 --> Form Validation Class Initialized
INFO - 2018-03-20 11:26:39 --> Controller Class Initialized
INFO - 2018-03-20 11:26:39 --> Model Class Initialized
INFO - 2018-03-20 11:26:39 --> Helper loaded: inflector_helper
INFO - 2018-03-20 11:26:39 --> Model Class Initialized
INFO - 2018-03-20 11:26:39 --> Model Class Initialized
INFO - 2018-03-20 11:26:39 --> Model Class Initialized
DEBUG - 2018-03-20 11:26:39 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-03-20 11:26:39 --> File loaded: /home/pr01004/public_html/application/views/admin/adminlist.php
DEBUG - 2018-03-20 11:26:39 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-03-20 11:26:39 --> Final output sent to browser
DEBUG - 2018-03-20 11:26:39 --> Total execution time: 0.2543
INFO - 2018-03-20 05:56:49 --> Config Class Initialized
INFO - 2018-03-20 05:56:49 --> Hooks Class Initialized
DEBUG - 2018-03-20 05:56:50 --> UTF-8 Support Enabled
INFO - 2018-03-20 05:56:50 --> Utf8 Class Initialized
INFO - 2018-03-20 05:56:50 --> URI Class Initialized
INFO - 2018-03-20 05:56:50 --> Router Class Initialized
INFO - 2018-03-20 05:56:50 --> Output Class Initialized
INFO - 2018-03-20 05:56:50 --> Security Class Initialized
DEBUG - 2018-03-20 05:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 05:56:50 --> Input Class Initialized
INFO - 2018-03-20 05:56:50 --> Language Class Initialized
INFO - 2018-03-20 05:56:50 --> Language Class Initialized
INFO - 2018-03-20 05:56:50 --> Config Class Initialized
INFO - 2018-03-20 05:56:50 --> Loader Class Initialized
INFO - 2018-03-20 11:26:50 --> Helper loaded: url_helper
INFO - 2018-03-20 11:26:50 --> Helper loaded: notification_helper
INFO - 2018-03-20 11:26:50 --> Helper loaded: settings_helper
INFO - 2018-03-20 11:26:50 --> Helper loaded: permission_helper
INFO - 2018-03-20 11:26:50 --> Helper loaded: users_helper
INFO - 2018-03-20 11:26:50 --> Database Driver Class Initialized
DEBUG - 2018-03-20 11:26:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 11:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 11:26:50 --> Helper loaded: form_helper
INFO - 2018-03-20 11:26:50 --> Form Validation Class Initialized
INFO - 2018-03-20 11:26:50 --> Controller Class Initialized
INFO - 2018-03-20 11:26:50 --> Model Class Initialized
INFO - 2018-03-20 11:26:50 --> Helper loaded: inflector_helper
INFO - 2018-03-20 11:26:50 --> Model Class Initialized
INFO - 2018-03-20 11:26:50 --> Model Class Initialized
INFO - 2018-03-20 11:26:50 --> Model Class Initialized
INFO - 2018-03-20 11:26:50 --> Model Class Initialized
DEBUG - 2018-03-20 11:26:50 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-03-20 11:26:50 --> File loaded: /home/pr01004/public_html/application/views/admin/permission.php
DEBUG - 2018-03-20 11:26:50 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-03-20 11:26:50 --> Final output sent to browser
DEBUG - 2018-03-20 11:26:50 --> Total execution time: 0.4632
INFO - 2018-03-20 05:57:21 --> Config Class Initialized
INFO - 2018-03-20 05:57:21 --> Hooks Class Initialized
DEBUG - 2018-03-20 05:57:21 --> UTF-8 Support Enabled
INFO - 2018-03-20 05:57:21 --> Utf8 Class Initialized
INFO - 2018-03-20 05:57:21 --> URI Class Initialized
INFO - 2018-03-20 05:57:22 --> Router Class Initialized
INFO - 2018-03-20 05:57:22 --> Output Class Initialized
INFO - 2018-03-20 05:57:22 --> Security Class Initialized
DEBUG - 2018-03-20 05:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 05:57:22 --> Input Class Initialized
INFO - 2018-03-20 05:57:22 --> Language Class Initialized
INFO - 2018-03-20 05:57:23 --> Language Class Initialized
INFO - 2018-03-20 05:57:23 --> Config Class Initialized
INFO - 2018-03-20 05:57:23 --> Loader Class Initialized
INFO - 2018-03-20 11:27:23 --> Helper loaded: url_helper
INFO - 2018-03-20 11:27:23 --> Helper loaded: notification_helper
INFO - 2018-03-20 11:27:23 --> Helper loaded: settings_helper
INFO - 2018-03-20 11:27:23 --> Helper loaded: permission_helper
INFO - 2018-03-20 11:27:23 --> Helper loaded: users_helper
INFO - 2018-03-20 11:27:24 --> Database Driver Class Initialized
DEBUG - 2018-03-20 11:27:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 11:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 11:27:24 --> Helper loaded: form_helper
INFO - 2018-03-20 11:27:24 --> Form Validation Class Initialized
INFO - 2018-03-20 11:27:24 --> Controller Class Initialized
INFO - 2018-03-20 11:27:24 --> Model Class Initialized
INFO - 2018-03-20 11:27:24 --> Helper loaded: inflector_helper
INFO - 2018-03-20 11:27:24 --> Model Class Initialized
INFO - 2018-03-20 11:27:24 --> Model Class Initialized
INFO - 2018-03-20 11:27:24 --> Model Class Initialized
DEBUG - 2018-03-20 11:27:24 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-03-20 11:27:24 --> File loaded: /home/pr01004/public_html/application/views/admin/adminlist.php
DEBUG - 2018-03-20 11:27:24 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-03-20 11:27:24 --> Final output sent to browser
DEBUG - 2018-03-20 11:27:24 --> Total execution time: 3.0297
INFO - 2018-03-20 05:57:35 --> Config Class Initialized
INFO - 2018-03-20 05:57:35 --> Hooks Class Initialized
DEBUG - 2018-03-20 05:57:35 --> UTF-8 Support Enabled
INFO - 2018-03-20 05:57:35 --> Utf8 Class Initialized
INFO - 2018-03-20 05:57:35 --> URI Class Initialized
INFO - 2018-03-20 05:57:35 --> Router Class Initialized
INFO - 2018-03-20 05:57:35 --> Output Class Initialized
INFO - 2018-03-20 05:57:36 --> Security Class Initialized
DEBUG - 2018-03-20 05:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 05:57:36 --> Input Class Initialized
INFO - 2018-03-20 05:57:36 --> Language Class Initialized
INFO - 2018-03-20 05:57:36 --> Language Class Initialized
INFO - 2018-03-20 05:57:36 --> Config Class Initialized
INFO - 2018-03-20 05:57:36 --> Loader Class Initialized
INFO - 2018-03-20 11:27:36 --> Helper loaded: url_helper
INFO - 2018-03-20 11:27:36 --> Helper loaded: notification_helper
INFO - 2018-03-20 11:27:36 --> Helper loaded: settings_helper
INFO - 2018-03-20 11:27:36 --> Helper loaded: permission_helper
INFO - 2018-03-20 11:27:36 --> Helper loaded: users_helper
INFO - 2018-03-20 11:27:36 --> Database Driver Class Initialized
DEBUG - 2018-03-20 11:27:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 11:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 11:27:36 --> Helper loaded: form_helper
INFO - 2018-03-20 11:27:36 --> Form Validation Class Initialized
INFO - 2018-03-20 11:27:36 --> Controller Class Initialized
INFO - 2018-03-20 11:27:36 --> Model Class Initialized
INFO - 2018-03-20 11:27:36 --> Helper loaded: inflector_helper
INFO - 2018-03-20 11:27:37 --> Model Class Initialized
INFO - 2018-03-20 11:27:37 --> Model Class Initialized
DEBUG - 2018-03-20 11:27:37 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-03-20 11:27:37 --> File loaded: /home/pr01004/public_html/application/views/users/usersList.php
DEBUG - 2018-03-20 11:27:37 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-03-20 11:27:37 --> Final output sent to browser
DEBUG - 2018-03-20 11:27:37 --> Total execution time: 1.9122
INFO - 2018-03-20 05:57:38 --> Config Class Initialized
INFO - 2018-03-20 05:57:38 --> Hooks Class Initialized
DEBUG - 2018-03-20 05:57:38 --> UTF-8 Support Enabled
INFO - 2018-03-20 05:57:38 --> Utf8 Class Initialized
INFO - 2018-03-20 05:57:38 --> URI Class Initialized
INFO - 2018-03-20 05:57:38 --> Router Class Initialized
INFO - 2018-03-20 05:57:38 --> Output Class Initialized
INFO - 2018-03-20 05:57:38 --> Security Class Initialized
DEBUG - 2018-03-20 05:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 05:57:38 --> Input Class Initialized
INFO - 2018-03-20 05:57:38 --> Language Class Initialized
INFO - 2018-03-20 05:57:38 --> Language Class Initialized
INFO - 2018-03-20 05:57:38 --> Config Class Initialized
INFO - 2018-03-20 05:57:38 --> Loader Class Initialized
INFO - 2018-03-20 11:27:38 --> Helper loaded: url_helper
INFO - 2018-03-20 11:27:38 --> Helper loaded: notification_helper
INFO - 2018-03-20 11:27:38 --> Helper loaded: settings_helper
INFO - 2018-03-20 11:27:38 --> Helper loaded: permission_helper
INFO - 2018-03-20 11:27:38 --> Helper loaded: users_helper
INFO - 2018-03-20 11:27:39 --> Database Driver Class Initialized
DEBUG - 2018-03-20 11:27:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 11:27:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 11:27:39 --> Helper loaded: form_helper
INFO - 2018-03-20 11:27:39 --> Form Validation Class Initialized
INFO - 2018-03-20 11:27:39 --> Controller Class Initialized
INFO - 2018-03-20 11:27:39 --> Model Class Initialized
INFO - 2018-03-20 11:27:39 --> Helper loaded: inflector_helper
INFO - 2018-03-20 11:27:39 --> Model Class Initialized
INFO - 2018-03-20 11:27:39 --> Model Class Initialized
INFO - 2018-03-20 11:27:39 --> Model Class Initialized
INFO - 2018-03-20 11:27:39 --> Final output sent to browser
DEBUG - 2018-03-20 11:27:39 --> Total execution time: 0.2688
INFO - 2018-03-20 05:57:44 --> Config Class Initialized
INFO - 2018-03-20 05:57:44 --> Hooks Class Initialized
DEBUG - 2018-03-20 05:57:44 --> UTF-8 Support Enabled
INFO - 2018-03-20 05:57:44 --> Utf8 Class Initialized
INFO - 2018-03-20 05:57:44 --> URI Class Initialized
INFO - 2018-03-20 05:57:45 --> Router Class Initialized
INFO - 2018-03-20 05:57:45 --> Output Class Initialized
INFO - 2018-03-20 05:57:45 --> Security Class Initialized
DEBUG - 2018-03-20 05:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 05:57:45 --> Input Class Initialized
INFO - 2018-03-20 05:57:45 --> Language Class Initialized
INFO - 2018-03-20 05:57:46 --> Language Class Initialized
INFO - 2018-03-20 05:57:46 --> Config Class Initialized
INFO - 2018-03-20 05:57:46 --> Loader Class Initialized
INFO - 2018-03-20 11:27:46 --> Helper loaded: url_helper
INFO - 2018-03-20 11:27:46 --> Helper loaded: notification_helper
INFO - 2018-03-20 11:27:46 --> Helper loaded: settings_helper
INFO - 2018-03-20 11:27:46 --> Helper loaded: permission_helper
INFO - 2018-03-20 11:27:46 --> Helper loaded: users_helper
INFO - 2018-03-20 11:27:47 --> Database Driver Class Initialized
DEBUG - 2018-03-20 11:27:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 11:27:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 11:27:47 --> Helper loaded: form_helper
INFO - 2018-03-20 11:27:47 --> Form Validation Class Initialized
INFO - 2018-03-20 11:27:47 --> Controller Class Initialized
INFO - 2018-03-20 11:27:47 --> Model Class Initialized
INFO - 2018-03-20 11:27:47 --> Helper loaded: inflector_helper
INFO - 2018-03-20 11:27:47 --> Model Class Initialized
INFO - 2018-03-20 11:27:47 --> Model Class Initialized
INFO - 2018-03-20 11:27:47 --> Model Class Initialized
DEBUG - 2018-03-20 11:27:47 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-03-20 11:27:47 --> File loaded: /home/pr01004/public_html/application/views/users/user_details.php
DEBUG - 2018-03-20 11:27:47 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-03-20 11:27:47 --> Final output sent to browser
DEBUG - 2018-03-20 11:27:47 --> Total execution time: 3.3440
INFO - 2018-03-20 05:58:08 --> Config Class Initialized
INFO - 2018-03-20 05:58:08 --> Hooks Class Initialized
DEBUG - 2018-03-20 05:58:08 --> UTF-8 Support Enabled
INFO - 2018-03-20 05:58:08 --> Utf8 Class Initialized
INFO - 2018-03-20 05:58:08 --> URI Class Initialized
INFO - 2018-03-20 05:58:08 --> Router Class Initialized
INFO - 2018-03-20 05:58:08 --> Output Class Initialized
INFO - 2018-03-20 05:58:08 --> Security Class Initialized
DEBUG - 2018-03-20 05:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 05:58:08 --> Input Class Initialized
INFO - 2018-03-20 05:58:08 --> Language Class Initialized
INFO - 2018-03-20 05:58:08 --> Language Class Initialized
INFO - 2018-03-20 05:58:08 --> Config Class Initialized
INFO - 2018-03-20 05:58:08 --> Loader Class Initialized
INFO - 2018-03-20 11:28:08 --> Helper loaded: url_helper
INFO - 2018-03-20 11:28:08 --> Helper loaded: notification_helper
INFO - 2018-03-20 11:28:08 --> Helper loaded: settings_helper
INFO - 2018-03-20 11:28:08 --> Helper loaded: permission_helper
INFO - 2018-03-20 11:28:08 --> Helper loaded: users_helper
INFO - 2018-03-20 11:28:09 --> Database Driver Class Initialized
DEBUG - 2018-03-20 11:28:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 11:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 11:28:09 --> Helper loaded: form_helper
INFO - 2018-03-20 11:28:09 --> Form Validation Class Initialized
INFO - 2018-03-20 11:28:09 --> Controller Class Initialized
INFO - 2018-03-20 11:28:09 --> Model Class Initialized
INFO - 2018-03-20 11:28:09 --> Helper loaded: inflector_helper
INFO - 2018-03-20 11:28:09 --> Model Class Initialized
INFO - 2018-03-20 11:28:09 --> Model Class Initialized
DEBUG - 2018-03-20 11:28:09 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-03-20 11:28:09 --> File loaded: /home/pr01004/public_html/application/views/users/usersList.php
DEBUG - 2018-03-20 11:28:09 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-03-20 11:28:09 --> Final output sent to browser
DEBUG - 2018-03-20 11:28:09 --> Total execution time: 0.8333
INFO - 2018-03-20 05:58:11 --> Config Class Initialized
INFO - 2018-03-20 05:58:11 --> Hooks Class Initialized
DEBUG - 2018-03-20 05:58:11 --> UTF-8 Support Enabled
INFO - 2018-03-20 05:58:11 --> Utf8 Class Initialized
INFO - 2018-03-20 05:58:11 --> URI Class Initialized
INFO - 2018-03-20 05:58:11 --> Router Class Initialized
INFO - 2018-03-20 05:58:11 --> Output Class Initialized
INFO - 2018-03-20 05:58:11 --> Security Class Initialized
DEBUG - 2018-03-20 05:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 05:58:11 --> Input Class Initialized
INFO - 2018-03-20 05:58:11 --> Language Class Initialized
INFO - 2018-03-20 05:58:11 --> Language Class Initialized
INFO - 2018-03-20 05:58:11 --> Config Class Initialized
INFO - 2018-03-20 05:58:11 --> Loader Class Initialized
INFO - 2018-03-20 11:28:11 --> Helper loaded: url_helper
INFO - 2018-03-20 11:28:11 --> Helper loaded: notification_helper
INFO - 2018-03-20 11:28:11 --> Helper loaded: settings_helper
INFO - 2018-03-20 11:28:11 --> Helper loaded: permission_helper
INFO - 2018-03-20 11:28:11 --> Helper loaded: users_helper
INFO - 2018-03-20 11:28:11 --> Database Driver Class Initialized
DEBUG - 2018-03-20 11:28:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 11:28:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 11:28:11 --> Helper loaded: form_helper
INFO - 2018-03-20 11:28:11 --> Form Validation Class Initialized
INFO - 2018-03-20 11:28:11 --> Controller Class Initialized
INFO - 2018-03-20 11:28:11 --> Model Class Initialized
INFO - 2018-03-20 11:28:11 --> Helper loaded: inflector_helper
INFO - 2018-03-20 11:28:11 --> Model Class Initialized
INFO - 2018-03-20 11:28:11 --> Model Class Initialized
INFO - 2018-03-20 11:28:11 --> Model Class Initialized
INFO - 2018-03-20 11:28:11 --> Final output sent to browser
DEBUG - 2018-03-20 11:28:11 --> Total execution time: 0.2588
INFO - 2018-03-20 05:58:16 --> Config Class Initialized
INFO - 2018-03-20 05:58:16 --> Hooks Class Initialized
DEBUG - 2018-03-20 05:58:16 --> UTF-8 Support Enabled
INFO - 2018-03-20 05:58:16 --> Utf8 Class Initialized
INFO - 2018-03-20 05:58:16 --> URI Class Initialized
INFO - 2018-03-20 05:58:17 --> Router Class Initialized
INFO - 2018-03-20 05:58:17 --> Output Class Initialized
INFO - 2018-03-20 05:58:17 --> Security Class Initialized
DEBUG - 2018-03-20 05:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 05:58:17 --> Input Class Initialized
INFO - 2018-03-20 05:58:17 --> Language Class Initialized
INFO - 2018-03-20 05:58:17 --> Language Class Initialized
INFO - 2018-03-20 05:58:17 --> Config Class Initialized
INFO - 2018-03-20 05:58:17 --> Loader Class Initialized
INFO - 2018-03-20 11:28:17 --> Helper loaded: url_helper
INFO - 2018-03-20 11:28:17 --> Helper loaded: notification_helper
INFO - 2018-03-20 11:28:17 --> Helper loaded: settings_helper
INFO - 2018-03-20 11:28:17 --> Helper loaded: permission_helper
INFO - 2018-03-20 11:28:18 --> Helper loaded: users_helper
INFO - 2018-03-20 11:28:18 --> Database Driver Class Initialized
DEBUG - 2018-03-20 11:28:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 11:28:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 11:28:19 --> Helper loaded: form_helper
INFO - 2018-03-20 11:28:19 --> Form Validation Class Initialized
INFO - 2018-03-20 11:28:19 --> Controller Class Initialized
INFO - 2018-03-20 11:28:19 --> Model Class Initialized
INFO - 2018-03-20 11:28:19 --> Helper loaded: inflector_helper
INFO - 2018-03-20 11:28:19 --> Model Class Initialized
INFO - 2018-03-20 11:28:19 --> Model Class Initialized
INFO - 2018-03-20 11:28:19 --> Model Class Initialized
DEBUG - 2018-03-20 11:28:19 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
ERROR - 2018-03-20 11:28:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/pr01004/public_html/application/views/users/user_activity.php 26
DEBUG - 2018-03-20 11:28:19 --> File loaded: /home/pr01004/public_html/application/views/users/user_activity.php
DEBUG - 2018-03-20 11:28:19 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-03-20 11:28:19 --> Final output sent to browser
DEBUG - 2018-03-20 11:28:19 --> Total execution time: 3.1750
INFO - 2018-03-20 05:58:21 --> Config Class Initialized
INFO - 2018-03-20 05:58:21 --> Hooks Class Initialized
DEBUG - 2018-03-20 05:58:21 --> UTF-8 Support Enabled
INFO - 2018-03-20 05:58:21 --> Utf8 Class Initialized
INFO - 2018-03-20 05:58:21 --> URI Class Initialized
INFO - 2018-03-20 05:58:21 --> Router Class Initialized
INFO - 2018-03-20 05:58:21 --> Output Class Initialized
INFO - 2018-03-20 05:58:21 --> Security Class Initialized
DEBUG - 2018-03-20 05:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 05:58:21 --> Input Class Initialized
INFO - 2018-03-20 05:58:21 --> Language Class Initialized
INFO - 2018-03-20 05:58:21 --> Language Class Initialized
INFO - 2018-03-20 05:58:21 --> Config Class Initialized
INFO - 2018-03-20 05:58:21 --> Loader Class Initialized
INFO - 2018-03-20 11:28:21 --> Helper loaded: url_helper
INFO - 2018-03-20 11:28:21 --> Helper loaded: notification_helper
INFO - 2018-03-20 11:28:21 --> Helper loaded: settings_helper
INFO - 2018-03-20 11:28:21 --> Helper loaded: permission_helper
INFO - 2018-03-20 11:28:21 --> Helper loaded: users_helper
INFO - 2018-03-20 11:28:21 --> Database Driver Class Initialized
DEBUG - 2018-03-20 11:28:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 11:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 11:28:21 --> Helper loaded: form_helper
INFO - 2018-03-20 11:28:21 --> Form Validation Class Initialized
INFO - 2018-03-20 11:28:21 --> Controller Class Initialized
INFO - 2018-03-20 11:28:21 --> Model Class Initialized
INFO - 2018-03-20 11:28:21 --> Helper loaded: inflector_helper
INFO - 2018-03-20 11:28:21 --> Model Class Initialized
INFO - 2018-03-20 11:28:21 --> Model Class Initialized
INFO - 2018-03-20 11:28:21 --> Model Class Initialized
INFO - 2018-03-20 11:28:21 --> Final output sent to browser
DEBUG - 2018-03-20 11:28:21 --> Total execution time: 0.9082
INFO - 2018-03-20 05:58:36 --> Config Class Initialized
INFO - 2018-03-20 05:58:36 --> Hooks Class Initialized
DEBUG - 2018-03-20 05:58:36 --> UTF-8 Support Enabled
INFO - 2018-03-20 05:58:36 --> Utf8 Class Initialized
INFO - 2018-03-20 05:58:36 --> URI Class Initialized
INFO - 2018-03-20 05:58:36 --> Router Class Initialized
INFO - 2018-03-20 05:58:37 --> Output Class Initialized
INFO - 2018-03-20 05:58:37 --> Security Class Initialized
DEBUG - 2018-03-20 05:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 05:58:37 --> Input Class Initialized
INFO - 2018-03-20 05:58:37 --> Language Class Initialized
INFO - 2018-03-20 05:58:37 --> Language Class Initialized
INFO - 2018-03-20 05:58:37 --> Config Class Initialized
INFO - 2018-03-20 05:58:37 --> Loader Class Initialized
INFO - 2018-03-20 11:28:37 --> Helper loaded: url_helper
INFO - 2018-03-20 11:28:37 --> Helper loaded: notification_helper
INFO - 2018-03-20 11:28:37 --> Helper loaded: settings_helper
INFO - 2018-03-20 11:28:37 --> Helper loaded: permission_helper
INFO - 2018-03-20 11:28:37 --> Helper loaded: users_helper
INFO - 2018-03-20 11:28:37 --> Database Driver Class Initialized
DEBUG - 2018-03-20 11:28:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 11:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 11:28:37 --> Helper loaded: form_helper
INFO - 2018-03-20 11:28:37 --> Form Validation Class Initialized
INFO - 2018-03-20 11:28:37 --> Controller Class Initialized
INFO - 2018-03-20 11:28:37 --> Model Class Initialized
INFO - 2018-03-20 11:28:37 --> Helper loaded: inflector_helper
INFO - 2018-03-20 11:28:37 --> Model Class Initialized
INFO - 2018-03-20 11:28:37 --> Model Class Initialized
INFO - 2018-03-20 11:28:37 --> Model Class Initialized
DEBUG - 2018-03-20 11:28:37 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-03-20 11:28:37 --> File loaded: /home/pr01004/public_html/application/views/questions/question_list.php
DEBUG - 2018-03-20 11:28:37 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-03-20 11:28:37 --> Final output sent to browser
DEBUG - 2018-03-20 11:28:37 --> Total execution time: 1.2110
INFO - 2018-03-20 05:58:48 --> Config Class Initialized
INFO - 2018-03-20 05:58:48 --> Hooks Class Initialized
DEBUG - 2018-03-20 05:58:48 --> UTF-8 Support Enabled
INFO - 2018-03-20 05:58:48 --> Utf8 Class Initialized
INFO - 2018-03-20 05:58:48 --> URI Class Initialized
INFO - 2018-03-20 05:58:48 --> Router Class Initialized
INFO - 2018-03-20 05:58:48 --> Output Class Initialized
INFO - 2018-03-20 05:58:48 --> Security Class Initialized
DEBUG - 2018-03-20 05:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 05:58:48 --> Input Class Initialized
INFO - 2018-03-20 05:58:48 --> Language Class Initialized
INFO - 2018-03-20 05:58:48 --> Language Class Initialized
INFO - 2018-03-20 05:58:48 --> Config Class Initialized
INFO - 2018-03-20 05:58:48 --> Loader Class Initialized
INFO - 2018-03-20 11:28:48 --> Helper loaded: url_helper
INFO - 2018-03-20 11:28:48 --> Helper loaded: notification_helper
INFO - 2018-03-20 11:28:48 --> Helper loaded: settings_helper
INFO - 2018-03-20 11:28:48 --> Helper loaded: permission_helper
INFO - 2018-03-20 11:28:48 --> Helper loaded: users_helper
INFO - 2018-03-20 11:28:48 --> Database Driver Class Initialized
DEBUG - 2018-03-20 11:28:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 11:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 11:28:48 --> Helper loaded: form_helper
INFO - 2018-03-20 11:28:48 --> Form Validation Class Initialized
INFO - 2018-03-20 11:28:48 --> Controller Class Initialized
INFO - 2018-03-20 11:28:48 --> Model Class Initialized
INFO - 2018-03-20 11:28:48 --> Helper loaded: inflector_helper
INFO - 2018-03-20 11:28:48 --> Model Class Initialized
INFO - 2018-03-20 11:28:48 --> Model Class Initialized
INFO - 2018-03-20 11:28:48 --> Model Class Initialized
DEBUG - 2018-03-20 11:28:48 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-03-20 11:28:49 --> File loaded: /home/pr01004/public_html/application/views/admin/notifications.php
DEBUG - 2018-03-20 11:28:49 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-03-20 11:28:49 --> Final output sent to browser
DEBUG - 2018-03-20 11:28:49 --> Total execution time: 0.3786
INFO - 2018-03-20 05:58:52 --> Config Class Initialized
INFO - 2018-03-20 05:58:52 --> Hooks Class Initialized
DEBUG - 2018-03-20 05:58:52 --> UTF-8 Support Enabled
INFO - 2018-03-20 05:58:52 --> Utf8 Class Initialized
INFO - 2018-03-20 05:58:52 --> URI Class Initialized
INFO - 2018-03-20 05:58:53 --> Router Class Initialized
INFO - 2018-03-20 05:58:53 --> Output Class Initialized
INFO - 2018-03-20 05:58:53 --> Security Class Initialized
DEBUG - 2018-03-20 05:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 05:58:53 --> Input Class Initialized
INFO - 2018-03-20 05:58:53 --> Language Class Initialized
INFO - 2018-03-20 05:58:53 --> Language Class Initialized
INFO - 2018-03-20 05:58:53 --> Config Class Initialized
INFO - 2018-03-20 05:58:53 --> Loader Class Initialized
INFO - 2018-03-20 11:28:53 --> Helper loaded: url_helper
INFO - 2018-03-20 11:28:53 --> Helper loaded: notification_helper
INFO - 2018-03-20 11:28:53 --> Helper loaded: settings_helper
INFO - 2018-03-20 11:28:53 --> Helper loaded: permission_helper
INFO - 2018-03-20 11:28:53 --> Helper loaded: users_helper
INFO - 2018-03-20 11:28:53 --> Database Driver Class Initialized
DEBUG - 2018-03-20 11:28:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 11:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 11:28:53 --> Helper loaded: form_helper
INFO - 2018-03-20 11:28:53 --> Form Validation Class Initialized
INFO - 2018-03-20 11:28:53 --> Controller Class Initialized
INFO - 2018-03-20 11:28:54 --> Model Class Initialized
INFO - 2018-03-20 11:28:54 --> Helper loaded: inflector_helper
INFO - 2018-03-20 11:28:54 --> Model Class Initialized
INFO - 2018-03-20 11:28:54 --> Model Class Initialized
INFO - 2018-03-20 11:28:54 --> Model Class Initialized
DEBUG - 2018-03-20 11:28:54 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-03-20 11:28:54 --> File loaded: /home/pr01004/public_html/application/views/preference/index.php
DEBUG - 2018-03-20 11:28:54 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-03-20 11:28:54 --> Final output sent to browser
DEBUG - 2018-03-20 11:28:54 --> Total execution time: 1.6152
INFO - 2018-03-20 05:59:04 --> Config Class Initialized
INFO - 2018-03-20 05:59:04 --> Hooks Class Initialized
DEBUG - 2018-03-20 05:59:04 --> UTF-8 Support Enabled
INFO - 2018-03-20 05:59:04 --> Utf8 Class Initialized
INFO - 2018-03-20 05:59:04 --> URI Class Initialized
INFO - 2018-03-20 05:59:04 --> Router Class Initialized
INFO - 2018-03-20 05:59:04 --> Output Class Initialized
INFO - 2018-03-20 05:59:04 --> Security Class Initialized
DEBUG - 2018-03-20 05:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 05:59:04 --> Input Class Initialized
INFO - 2018-03-20 05:59:04 --> Language Class Initialized
INFO - 2018-03-20 05:59:04 --> Language Class Initialized
INFO - 2018-03-20 05:59:04 --> Config Class Initialized
INFO - 2018-03-20 05:59:04 --> Loader Class Initialized
INFO - 2018-03-20 11:29:04 --> Helper loaded: url_helper
INFO - 2018-03-20 11:29:04 --> Helper loaded: notification_helper
INFO - 2018-03-20 11:29:04 --> Helper loaded: settings_helper
INFO - 2018-03-20 11:29:04 --> Helper loaded: permission_helper
INFO - 2018-03-20 11:29:04 --> Helper loaded: users_helper
INFO - 2018-03-20 11:29:04 --> Database Driver Class Initialized
DEBUG - 2018-03-20 11:29:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 11:29:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 11:29:04 --> Helper loaded: form_helper
INFO - 2018-03-20 11:29:04 --> Form Validation Class Initialized
INFO - 2018-03-20 11:29:04 --> Controller Class Initialized
INFO - 2018-03-20 11:29:04 --> Model Class Initialized
INFO - 2018-03-20 11:29:04 --> Helper loaded: inflector_helper
INFO - 2018-03-20 11:29:04 --> Model Class Initialized
INFO - 2018-03-20 11:29:04 --> Model Class Initialized
INFO - 2018-03-20 11:29:04 --> Model Class Initialized
DEBUG - 2018-03-20 11:29:04 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-03-20 11:29:04 --> File loaded: /home/pr01004/public_html/application/views/preference/edit.php
DEBUG - 2018-03-20 11:29:04 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-03-20 11:29:04 --> Final output sent to browser
DEBUG - 2018-03-20 11:29:04 --> Total execution time: 0.1055
INFO - 2018-03-20 05:59:30 --> Config Class Initialized
INFO - 2018-03-20 05:59:30 --> Hooks Class Initialized
DEBUG - 2018-03-20 05:59:30 --> UTF-8 Support Enabled
INFO - 2018-03-20 05:59:30 --> Utf8 Class Initialized
INFO - 2018-03-20 05:59:30 --> URI Class Initialized
INFO - 2018-03-20 05:59:30 --> Router Class Initialized
INFO - 2018-03-20 05:59:30 --> Output Class Initialized
INFO - 2018-03-20 05:59:30 --> Security Class Initialized
DEBUG - 2018-03-20 05:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 05:59:30 --> Input Class Initialized
INFO - 2018-03-20 05:59:30 --> Language Class Initialized
INFO - 2018-03-20 05:59:30 --> Language Class Initialized
INFO - 2018-03-20 05:59:30 --> Config Class Initialized
INFO - 2018-03-20 05:59:30 --> Loader Class Initialized
INFO - 2018-03-20 11:29:30 --> Helper loaded: url_helper
INFO - 2018-03-20 11:29:30 --> Helper loaded: notification_helper
INFO - 2018-03-20 11:29:30 --> Helper loaded: settings_helper
INFO - 2018-03-20 11:29:30 --> Helper loaded: permission_helper
INFO - 2018-03-20 11:29:30 --> Helper loaded: users_helper
INFO - 2018-03-20 11:29:30 --> Database Driver Class Initialized
DEBUG - 2018-03-20 11:29:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 11:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 11:29:30 --> Helper loaded: form_helper
INFO - 2018-03-20 11:29:30 --> Form Validation Class Initialized
INFO - 2018-03-20 11:29:30 --> Controller Class Initialized
INFO - 2018-03-20 11:29:30 --> Model Class Initialized
INFO - 2018-03-20 11:29:30 --> Helper loaded: inflector_helper
DEBUG - 2018-03-20 11:29:30 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 11:29:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 11:29:30 --> Model Class Initialized
INFO - 2018-03-20 11:29:30 --> Model Class Initialized
INFO - 2018-03-20 11:29:30 --> Model Class Initialized
INFO - 2018-03-20 11:29:30 --> Model Class Initialized
INFO - 2018-03-20 11:29:30 --> Model Class Initialized
INFO - 2018-03-20 11:29:30 --> Model Class Initialized
INFO - 2018-03-20 11:29:30 --> Model Class Initialized
INFO - 2018-03-20 11:29:30 --> Model Class Initialized
INFO - 2018-03-20 11:29:30 --> Model Class Initialized
INFO - 2018-03-20 11:29:30 --> Model Class Initialized
INFO - 2018-03-20 11:29:30 --> Model Class Initialized
INFO - 2018-03-20 11:29:30 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-20 11:29:30 --> Model Class Initialized
INFO - 2018-03-20 11:29:30 --> Final output sent to browser
DEBUG - 2018-03-20 11:29:30 --> Total execution time: 0.1441
INFO - 2018-03-20 05:59:30 --> Config Class Initialized
INFO - 2018-03-20 05:59:30 --> Hooks Class Initialized
DEBUG - 2018-03-20 05:59:30 --> UTF-8 Support Enabled
INFO - 2018-03-20 05:59:30 --> Utf8 Class Initialized
INFO - 2018-03-20 05:59:30 --> URI Class Initialized
INFO - 2018-03-20 05:59:30 --> Router Class Initialized
INFO - 2018-03-20 05:59:30 --> Output Class Initialized
INFO - 2018-03-20 05:59:30 --> Security Class Initialized
INFO - 2018-03-20 05:59:30 --> Config Class Initialized
INFO - 2018-03-20 05:59:30 --> Hooks Class Initialized
DEBUG - 2018-03-20 05:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 05:59:30 --> Input Class Initialized
INFO - 2018-03-20 05:59:30 --> Language Class Initialized
DEBUG - 2018-03-20 05:59:30 --> UTF-8 Support Enabled
INFO - 2018-03-20 05:59:30 --> Utf8 Class Initialized
INFO - 2018-03-20 05:59:30 --> URI Class Initialized
INFO - 2018-03-20 05:59:30 --> Router Class Initialized
INFO - 2018-03-20 05:59:30 --> Output Class Initialized
INFO - 2018-03-20 05:59:30 --> Security Class Initialized
DEBUG - 2018-03-20 05:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 05:59:30 --> Input Class Initialized
INFO - 2018-03-20 05:59:30 --> Language Class Initialized
INFO - 2018-03-20 05:59:30 --> Language Class Initialized
INFO - 2018-03-20 05:59:30 --> Config Class Initialized
INFO - 2018-03-20 05:59:30 --> Loader Class Initialized
INFO - 2018-03-20 11:29:30 --> Helper loaded: url_helper
INFO - 2018-03-20 11:29:30 --> Helper loaded: notification_helper
INFO - 2018-03-20 11:29:30 --> Helper loaded: settings_helper
INFO - 2018-03-20 11:29:30 --> Helper loaded: permission_helper
INFO - 2018-03-20 11:29:30 --> Helper loaded: users_helper
INFO - 2018-03-20 05:59:30 --> Language Class Initialized
INFO - 2018-03-20 05:59:30 --> Config Class Initialized
INFO - 2018-03-20 05:59:30 --> Loader Class Initialized
INFO - 2018-03-20 11:29:30 --> Helper loaded: url_helper
INFO - 2018-03-20 11:29:30 --> Helper loaded: notification_helper
INFO - 2018-03-20 11:29:30 --> Helper loaded: settings_helper
INFO - 2018-03-20 11:29:30 --> Helper loaded: permission_helper
INFO - 2018-03-20 11:29:30 --> Database Driver Class Initialized
INFO - 2018-03-20 11:29:30 --> Helper loaded: users_helper
INFO - 2018-03-20 05:59:30 --> Config Class Initialized
INFO - 2018-03-20 05:59:30 --> Hooks Class Initialized
DEBUG - 2018-03-20 05:59:30 --> UTF-8 Support Enabled
INFO - 2018-03-20 05:59:30 --> Utf8 Class Initialized
DEBUG - 2018-03-20 11:29:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 11:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 05:59:30 --> URI Class Initialized
INFO - 2018-03-20 05:59:30 --> Router Class Initialized
INFO - 2018-03-20 05:59:30 --> Output Class Initialized
INFO - 2018-03-20 05:59:30 --> Security Class Initialized
DEBUG - 2018-03-20 05:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 05:59:30 --> Input Class Initialized
INFO - 2018-03-20 05:59:30 --> Language Class Initialized
INFO - 2018-03-20 11:29:30 --> Helper loaded: form_helper
INFO - 2018-03-20 11:29:30 --> Form Validation Class Initialized
INFO - 2018-03-20 11:29:30 --> Controller Class Initialized
INFO - 2018-03-20 11:29:30 --> Database Driver Class Initialized
DEBUG - 2018-03-20 11:29:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 11:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 11:29:30 --> Helper loaded: form_helper
INFO - 2018-03-20 11:29:30 --> Form Validation Class Initialized
INFO - 2018-03-20 11:29:30 --> Controller Class Initialized
INFO - 2018-03-20 11:29:30 --> Model Class Initialized
INFO - 2018-03-20 11:29:30 --> Helper loaded: inflector_helper
DEBUG - 2018-03-20 11:29:30 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 11:29:30 --> Model Class Initialized
INFO - 2018-03-20 11:29:30 --> Helper loaded: inflector_helper
INFO - 2018-03-20 11:29:30 --> Language file loaded: language/english/rest_controller_lang.php
DEBUG - 2018-03-20 11:29:30 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 11:29:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 11:29:30 --> Model Class Initialized
INFO - 2018-03-20 11:29:30 --> Model Class Initialized
INFO - 2018-03-20 11:29:30 --> Model Class Initialized
INFO - 2018-03-20 11:29:30 --> Model Class Initialized
INFO - 2018-03-20 11:29:30 --> Model Class Initialized
INFO - 2018-03-20 11:29:30 --> Model Class Initialized
INFO - 2018-03-20 11:29:30 --> Model Class Initialized
INFO - 2018-03-20 11:29:30 --> Model Class Initialized
INFO - 2018-03-20 11:29:30 --> Model Class Initialized
INFO - 2018-03-20 11:29:30 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-20 11:29:30 --> Model Class Initialized
INFO - 2018-03-20 11:29:30 --> Model Class Initialized
INFO - 2018-03-20 11:29:30 --> Model Class Initialized
INFO - 2018-03-20 11:29:30 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-20 11:29:30 --> Model Class Initialized
INFO - 2018-03-20 11:29:30 --> Final output sent to browser
DEBUG - 2018-03-20 11:29:30 --> Total execution time: 0.2877
INFO - 2018-03-20 11:29:30 --> Final output sent to browser
DEBUG - 2018-03-20 11:29:30 --> Total execution time: 0.3643
INFO - 2018-03-20 05:59:30 --> Config Class Initialized
INFO - 2018-03-20 05:59:30 --> Hooks Class Initialized
DEBUG - 2018-03-20 05:59:30 --> UTF-8 Support Enabled
INFO - 2018-03-20 05:59:30 --> Utf8 Class Initialized
INFO - 2018-03-20 05:59:31 --> URI Class Initialized
INFO - 2018-03-20 05:59:31 --> Language Class Initialized
INFO - 2018-03-20 05:59:31 --> Config Class Initialized
INFO - 2018-03-20 05:59:31 --> Loader Class Initialized
INFO - 2018-03-20 05:59:31 --> Router Class Initialized
INFO - 2018-03-20 11:29:31 --> Helper loaded: url_helper
INFO - 2018-03-20 05:59:31 --> Output Class Initialized
INFO - 2018-03-20 11:29:31 --> Helper loaded: notification_helper
INFO - 2018-03-20 11:29:31 --> Helper loaded: settings_helper
INFO - 2018-03-20 11:29:31 --> Helper loaded: permission_helper
INFO - 2018-03-20 11:29:31 --> Helper loaded: users_helper
INFO - 2018-03-20 05:59:31 --> Security Class Initialized
DEBUG - 2018-03-20 05:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 05:59:31 --> Input Class Initialized
INFO - 2018-03-20 05:59:31 --> Language Class Initialized
INFO - 2018-03-20 11:29:31 --> Database Driver Class Initialized
DEBUG - 2018-03-20 11:29:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 11:29:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 11:29:31 --> Helper loaded: form_helper
INFO - 2018-03-20 11:29:31 --> Form Validation Class Initialized
INFO - 2018-03-20 11:29:31 --> Controller Class Initialized
INFO - 2018-03-20 11:29:31 --> Model Class Initialized
INFO - 2018-03-20 11:29:31 --> Helper loaded: inflector_helper
DEBUG - 2018-03-20 11:29:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 11:29:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 11:29:31 --> Model Class Initialized
INFO - 2018-03-20 11:29:31 --> Model Class Initialized
INFO - 2018-03-20 11:29:31 --> Model Class Initialized
INFO - 2018-03-20 11:29:31 --> Model Class Initialized
INFO - 2018-03-20 11:29:31 --> Model Class Initialized
INFO - 2018-03-20 11:29:31 --> Model Class Initialized
INFO - 2018-03-20 11:29:31 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-20 11:29:31 --> Model Class Initialized
INFO - 2018-03-20 11:29:31 --> Final output sent to browser
DEBUG - 2018-03-20 11:29:31 --> Total execution time: 1.5108
INFO - 2018-03-20 05:59:32 --> Language Class Initialized
INFO - 2018-03-20 05:59:32 --> Config Class Initialized
INFO - 2018-03-20 05:59:32 --> Loader Class Initialized
INFO - 2018-03-20 11:29:32 --> Helper loaded: url_helper
INFO - 2018-03-20 11:29:32 --> Helper loaded: notification_helper
INFO - 2018-03-20 11:29:32 --> Helper loaded: settings_helper
INFO - 2018-03-20 11:29:32 --> Helper loaded: permission_helper
INFO - 2018-03-20 11:29:32 --> Helper loaded: users_helper
INFO - 2018-03-20 11:29:33 --> Database Driver Class Initialized
DEBUG - 2018-03-20 11:29:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 11:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 11:29:33 --> Helper loaded: form_helper
INFO - 2018-03-20 11:29:33 --> Form Validation Class Initialized
INFO - 2018-03-20 11:29:33 --> Controller Class Initialized
INFO - 2018-03-20 11:29:33 --> Model Class Initialized
INFO - 2018-03-20 11:29:33 --> Helper loaded: inflector_helper
DEBUG - 2018-03-20 11:29:33 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 11:29:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 11:29:33 --> Model Class Initialized
INFO - 2018-03-20 11:29:33 --> Model Class Initialized
INFO - 2018-03-20 11:29:33 --> Model Class Initialized
INFO - 2018-03-20 11:29:33 --> Model Class Initialized
INFO - 2018-03-20 11:29:33 --> Model Class Initialized
INFO - 2018-03-20 11:29:33 --> Model Class Initialized
INFO - 2018-03-20 11:29:33 --> Model Class Initialized
INFO - 2018-03-20 11:29:33 --> Model Class Initialized
INFO - 2018-03-20 11:29:33 --> Model Class Initialized
INFO - 2018-03-20 11:29:33 --> Model Class Initialized
INFO - 2018-03-20 11:29:33 --> Model Class Initialized
INFO - 2018-03-20 11:29:33 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-20 11:29:33 --> Model Class Initialized
INFO - 2018-03-20 11:29:33 --> Final output sent to browser
DEBUG - 2018-03-20 11:29:33 --> Total execution time: 2.9000
INFO - 2018-03-20 05:59:34 --> Config Class Initialized
INFO - 2018-03-20 05:59:34 --> Hooks Class Initialized
DEBUG - 2018-03-20 05:59:35 --> UTF-8 Support Enabled
INFO - 2018-03-20 05:59:35 --> Utf8 Class Initialized
INFO - 2018-03-20 05:59:35 --> URI Class Initialized
INFO - 2018-03-20 05:59:35 --> Router Class Initialized
INFO - 2018-03-20 05:59:35 --> Output Class Initialized
INFO - 2018-03-20 05:59:35 --> Security Class Initialized
DEBUG - 2018-03-20 05:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 05:59:35 --> Input Class Initialized
INFO - 2018-03-20 05:59:35 --> Language Class Initialized
INFO - 2018-03-20 05:59:36 --> Language Class Initialized
INFO - 2018-03-20 05:59:36 --> Config Class Initialized
INFO - 2018-03-20 05:59:36 --> Loader Class Initialized
INFO - 2018-03-20 11:29:36 --> Helper loaded: url_helper
INFO - 2018-03-20 11:29:36 --> Helper loaded: notification_helper
INFO - 2018-03-20 11:29:36 --> Helper loaded: settings_helper
INFO - 2018-03-20 11:29:36 --> Helper loaded: permission_helper
INFO - 2018-03-20 11:29:36 --> Helper loaded: users_helper
INFO - 2018-03-20 11:29:37 --> Database Driver Class Initialized
DEBUG - 2018-03-20 11:29:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 11:29:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 11:29:37 --> Helper loaded: form_helper
INFO - 2018-03-20 11:29:37 --> Form Validation Class Initialized
INFO - 2018-03-20 11:29:37 --> Controller Class Initialized
INFO - 2018-03-20 11:29:37 --> Model Class Initialized
INFO - 2018-03-20 11:29:37 --> Helper loaded: inflector_helper
DEBUG - 2018-03-20 11:29:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 11:29:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 11:29:37 --> Model Class Initialized
INFO - 2018-03-20 11:29:37 --> Model Class Initialized
INFO - 2018-03-20 11:29:37 --> Model Class Initialized
INFO - 2018-03-20 11:29:37 --> Model Class Initialized
INFO - 2018-03-20 11:29:37 --> Model Class Initialized
INFO - 2018-03-20 11:29:37 --> Model Class Initialized
INFO - 2018-03-20 11:29:37 --> Model Class Initialized
INFO - 2018-03-20 11:29:37 --> Model Class Initialized
INFO - 2018-03-20 11:29:37 --> Model Class Initialized
INFO - 2018-03-20 11:29:37 --> Model Class Initialized
INFO - 2018-03-20 11:29:37 --> Model Class Initialized
INFO - 2018-03-20 11:29:37 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-20 11:29:37 --> Model Class Initialized
INFO - 2018-03-20 11:29:37 --> Final output sent to browser
DEBUG - 2018-03-20 11:29:37 --> Total execution time: 3.1780
INFO - 2018-03-20 06:00:04 --> Config Class Initialized
INFO - 2018-03-20 06:00:04 --> Hooks Class Initialized
DEBUG - 2018-03-20 06:00:04 --> UTF-8 Support Enabled
INFO - 2018-03-20 06:00:04 --> Utf8 Class Initialized
INFO - 2018-03-20 06:00:04 --> URI Class Initialized
INFO - 2018-03-20 06:00:04 --> Router Class Initialized
INFO - 2018-03-20 06:00:04 --> Output Class Initialized
INFO - 2018-03-20 06:00:04 --> Security Class Initialized
DEBUG - 2018-03-20 06:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 06:00:04 --> Input Class Initialized
INFO - 2018-03-20 06:00:04 --> Language Class Initialized
INFO - 2018-03-20 06:00:04 --> Language Class Initialized
INFO - 2018-03-20 06:00:04 --> Config Class Initialized
INFO - 2018-03-20 06:00:04 --> Loader Class Initialized
INFO - 2018-03-20 11:30:04 --> Helper loaded: url_helper
INFO - 2018-03-20 11:30:04 --> Helper loaded: notification_helper
INFO - 2018-03-20 11:30:04 --> Helper loaded: settings_helper
INFO - 2018-03-20 11:30:04 --> Helper loaded: permission_helper
INFO - 2018-03-20 11:30:04 --> Helper loaded: users_helper
INFO - 2018-03-20 11:30:04 --> Database Driver Class Initialized
DEBUG - 2018-03-20 11:30:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 11:30:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 11:30:04 --> Helper loaded: form_helper
INFO - 2018-03-20 11:30:04 --> Form Validation Class Initialized
INFO - 2018-03-20 11:30:04 --> Controller Class Initialized
INFO - 2018-03-20 11:30:04 --> Model Class Initialized
INFO - 2018-03-20 11:30:04 --> Helper loaded: inflector_helper
DEBUG - 2018-03-20 11:30:04 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 11:30:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 11:30:04 --> Model Class Initialized
INFO - 2018-03-20 11:30:04 --> Model Class Initialized
INFO - 2018-03-20 11:30:04 --> Model Class Initialized
INFO - 2018-03-20 11:30:04 --> Model Class Initialized
INFO - 2018-03-20 11:30:04 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-20 11:30:04 --> Final output sent to browser
DEBUG - 2018-03-20 11:30:04 --> Total execution time: 0.2211
INFO - 2018-03-20 06:00:05 --> Config Class Initialized
INFO - 2018-03-20 06:00:05 --> Hooks Class Initialized
DEBUG - 2018-03-20 06:00:05 --> UTF-8 Support Enabled
INFO - 2018-03-20 06:00:05 --> Utf8 Class Initialized
INFO - 2018-03-20 06:00:05 --> URI Class Initialized
INFO - 2018-03-20 06:00:05 --> Router Class Initialized
INFO - 2018-03-20 06:00:05 --> Output Class Initialized
INFO - 2018-03-20 06:00:05 --> Security Class Initialized
DEBUG - 2018-03-20 06:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 06:00:05 --> Input Class Initialized
INFO - 2018-03-20 06:00:05 --> Language Class Initialized
INFO - 2018-03-20 06:00:05 --> Language Class Initialized
INFO - 2018-03-20 06:00:05 --> Config Class Initialized
INFO - 2018-03-20 06:00:05 --> Loader Class Initialized
INFO - 2018-03-20 11:30:05 --> Helper loaded: url_helper
INFO - 2018-03-20 11:30:05 --> Helper loaded: notification_helper
INFO - 2018-03-20 11:30:05 --> Helper loaded: settings_helper
INFO - 2018-03-20 11:30:05 --> Helper loaded: permission_helper
INFO - 2018-03-20 11:30:05 --> Helper loaded: users_helper
INFO - 2018-03-20 11:30:05 --> Database Driver Class Initialized
DEBUG - 2018-03-20 11:30:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 11:30:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 11:30:05 --> Helper loaded: form_helper
INFO - 2018-03-20 11:30:05 --> Form Validation Class Initialized
INFO - 2018-03-20 11:30:05 --> Controller Class Initialized
INFO - 2018-03-20 11:30:05 --> Model Class Initialized
INFO - 2018-03-20 11:30:05 --> Helper loaded: inflector_helper
DEBUG - 2018-03-20 11:30:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 11:30:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 11:30:05 --> Model Class Initialized
INFO - 2018-03-20 11:30:05 --> Model Class Initialized
INFO - 2018-03-20 11:30:05 --> Model Class Initialized
INFO - 2018-03-20 11:30:05 --> Model Class Initialized
INFO - 2018-03-20 11:30:05 --> Model Class Initialized
INFO - 2018-03-20 11:30:05 --> Model Class Initialized
INFO - 2018-03-20 11:30:05 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-20 11:30:05 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-03-20 11:30:05 --> Final output sent to browser
DEBUG - 2018-03-20 11:30:05 --> Total execution time: 0.3422
INFO - 2018-03-20 06:00:05 --> Config Class Initialized
INFO - 2018-03-20 06:00:05 --> Hooks Class Initialized
DEBUG - 2018-03-20 06:00:05 --> UTF-8 Support Enabled
INFO - 2018-03-20 06:00:05 --> Utf8 Class Initialized
INFO - 2018-03-20 06:00:06 --> URI Class Initialized
INFO - 2018-03-20 06:00:06 --> Router Class Initialized
INFO - 2018-03-20 06:00:06 --> Output Class Initialized
INFO - 2018-03-20 06:00:06 --> Security Class Initialized
DEBUG - 2018-03-20 06:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 06:00:06 --> Input Class Initialized
INFO - 2018-03-20 06:00:06 --> Language Class Initialized
INFO - 2018-03-20 06:00:06 --> Config Class Initialized
INFO - 2018-03-20 06:00:06 --> Hooks Class Initialized
DEBUG - 2018-03-20 06:00:06 --> UTF-8 Support Enabled
INFO - 2018-03-20 06:00:06 --> Utf8 Class Initialized
INFO - 2018-03-20 06:00:06 --> URI Class Initialized
INFO - 2018-03-20 06:00:06 --> Router Class Initialized
INFO - 2018-03-20 06:00:06 --> Output Class Initialized
INFO - 2018-03-20 06:00:06 --> Security Class Initialized
DEBUG - 2018-03-20 06:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 06:00:06 --> Input Class Initialized
INFO - 2018-03-20 06:00:06 --> Language Class Initialized
INFO - 2018-03-20 06:00:07 --> Language Class Initialized
INFO - 2018-03-20 06:00:07 --> Config Class Initialized
INFO - 2018-03-20 06:00:07 --> Loader Class Initialized
INFO - 2018-03-20 11:30:07 --> Helper loaded: url_helper
INFO - 2018-03-20 11:30:07 --> Helper loaded: notification_helper
INFO - 2018-03-20 11:30:07 --> Helper loaded: settings_helper
INFO - 2018-03-20 11:30:07 --> Helper loaded: permission_helper
INFO - 2018-03-20 11:30:07 --> Helper loaded: users_helper
INFO - 2018-03-20 11:30:07 --> Database Driver Class Initialized
DEBUG - 2018-03-20 11:30:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 11:30:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 11:30:07 --> Helper loaded: form_helper
INFO - 2018-03-20 11:30:07 --> Form Validation Class Initialized
INFO - 2018-03-20 11:30:07 --> Controller Class Initialized
INFO - 2018-03-20 11:30:07 --> Model Class Initialized
INFO - 2018-03-20 11:30:07 --> Helper loaded: inflector_helper
DEBUG - 2018-03-20 11:30:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 11:30:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 11:30:07 --> Model Class Initialized
INFO - 2018-03-20 11:30:07 --> Model Class Initialized
INFO - 2018-03-20 11:30:07 --> Model Class Initialized
INFO - 2018-03-20 11:30:07 --> Model Class Initialized
INFO - 2018-03-20 11:30:07 --> Model Class Initialized
INFO - 2018-03-20 11:30:07 --> Model Class Initialized
INFO - 2018-03-20 11:30:07 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-20 11:30:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-03-20 11:30:07 --> Final output sent to browser
DEBUG - 2018-03-20 11:30:07 --> Total execution time: 0.1279
INFO - 2018-03-20 06:00:08 --> Language Class Initialized
INFO - 2018-03-20 06:00:08 --> Config Class Initialized
INFO - 2018-03-20 06:00:08 --> Loader Class Initialized
INFO - 2018-03-20 11:30:08 --> Helper loaded: url_helper
INFO - 2018-03-20 11:30:08 --> Helper loaded: notification_helper
INFO - 2018-03-20 11:30:08 --> Helper loaded: settings_helper
INFO - 2018-03-20 11:30:08 --> Helper loaded: permission_helper
INFO - 2018-03-20 11:30:08 --> Helper loaded: users_helper
INFO - 2018-03-20 11:30:09 --> Database Driver Class Initialized
DEBUG - 2018-03-20 11:30:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 11:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 11:30:09 --> Helper loaded: form_helper
INFO - 2018-03-20 11:30:09 --> Form Validation Class Initialized
INFO - 2018-03-20 11:30:09 --> Controller Class Initialized
INFO - 2018-03-20 11:30:09 --> Model Class Initialized
INFO - 2018-03-20 11:30:09 --> Helper loaded: inflector_helper
DEBUG - 2018-03-20 11:30:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 11:30:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 11:30:09 --> Model Class Initialized
INFO - 2018-03-20 11:30:09 --> Model Class Initialized
INFO - 2018-03-20 11:30:09 --> Model Class Initialized
INFO - 2018-03-20 11:30:09 --> Model Class Initialized
INFO - 2018-03-20 11:30:09 --> Model Class Initialized
INFO - 2018-03-20 11:30:09 --> Model Class Initialized
INFO - 2018-03-20 11:30:09 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-20 11:30:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-03-20 11:30:09 --> Final output sent to browser
DEBUG - 2018-03-20 11:30:09 --> Total execution time: 4.0796
INFO - 2018-03-20 06:00:45 --> Config Class Initialized
INFO - 2018-03-20 06:00:45 --> Hooks Class Initialized
DEBUG - 2018-03-20 06:00:45 --> UTF-8 Support Enabled
INFO - 2018-03-20 06:00:45 --> Utf8 Class Initialized
INFO - 2018-03-20 06:00:45 --> URI Class Initialized
INFO - 2018-03-20 06:00:45 --> Router Class Initialized
INFO - 2018-03-20 06:00:45 --> Output Class Initialized
INFO - 2018-03-20 06:00:45 --> Security Class Initialized
DEBUG - 2018-03-20 06:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 06:00:45 --> Input Class Initialized
INFO - 2018-03-20 06:00:45 --> Language Class Initialized
INFO - 2018-03-20 06:00:45 --> Language Class Initialized
INFO - 2018-03-20 06:00:45 --> Config Class Initialized
INFO - 2018-03-20 06:00:45 --> Loader Class Initialized
INFO - 2018-03-20 11:30:45 --> Helper loaded: url_helper
INFO - 2018-03-20 11:30:45 --> Helper loaded: notification_helper
INFO - 2018-03-20 11:30:45 --> Helper loaded: settings_helper
INFO - 2018-03-20 11:30:45 --> Helper loaded: permission_helper
INFO - 2018-03-20 11:30:45 --> Helper loaded: users_helper
INFO - 2018-03-20 11:30:45 --> Database Driver Class Initialized
DEBUG - 2018-03-20 11:30:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 11:30:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 11:30:45 --> Helper loaded: form_helper
INFO - 2018-03-20 11:30:45 --> Form Validation Class Initialized
INFO - 2018-03-20 11:30:45 --> Controller Class Initialized
INFO - 2018-03-20 11:30:45 --> Model Class Initialized
INFO - 2018-03-20 11:30:45 --> Helper loaded: inflector_helper
INFO - 2018-03-20 11:30:45 --> Model Class Initialized
INFO - 2018-03-20 11:30:45 --> Model Class Initialized
INFO - 2018-03-20 11:30:45 --> Model Class Initialized
DEBUG - 2018-03-20 11:30:45 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-03-20 11:30:45 --> File loaded: /home/pr01004/public_html/application/views/preference/index.php
DEBUG - 2018-03-20 11:30:45 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-03-20 11:30:45 --> Final output sent to browser
DEBUG - 2018-03-20 11:30:45 --> Total execution time: 0.2222
INFO - 2018-03-20 06:00:53 --> Config Class Initialized
INFO - 2018-03-20 06:00:53 --> Hooks Class Initialized
DEBUG - 2018-03-20 06:00:53 --> UTF-8 Support Enabled
INFO - 2018-03-20 06:00:53 --> Utf8 Class Initialized
INFO - 2018-03-20 06:00:53 --> URI Class Initialized
INFO - 2018-03-20 06:00:53 --> Router Class Initialized
INFO - 2018-03-20 06:00:53 --> Output Class Initialized
INFO - 2018-03-20 06:00:53 --> Config Class Initialized
INFO - 2018-03-20 06:00:53 --> Hooks Class Initialized
INFO - 2018-03-20 06:00:53 --> Security Class Initialized
DEBUG - 2018-03-20 06:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 06:00:53 --> Input Class Initialized
INFO - 2018-03-20 06:00:53 --> Language Class Initialized
DEBUG - 2018-03-20 06:00:53 --> UTF-8 Support Enabled
INFO - 2018-03-20 06:00:53 --> Utf8 Class Initialized
INFO - 2018-03-20 06:00:53 --> URI Class Initialized
INFO - 2018-03-20 06:00:53 --> Router Class Initialized
INFO - 2018-03-20 06:00:53 --> Output Class Initialized
INFO - 2018-03-20 06:00:53 --> Language Class Initialized
INFO - 2018-03-20 06:00:53 --> Config Class Initialized
INFO - 2018-03-20 06:00:53 --> Security Class Initialized
DEBUG - 2018-03-20 06:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 06:00:53 --> Input Class Initialized
INFO - 2018-03-20 06:00:53 --> Loader Class Initialized
INFO - 2018-03-20 06:00:53 --> Language Class Initialized
INFO - 2018-03-20 06:00:53 --> Language Class Initialized
INFO - 2018-03-20 06:00:53 --> Config Class Initialized
INFO - 2018-03-20 06:00:53 --> Loader Class Initialized
INFO - 2018-03-20 11:30:53 --> Helper loaded: url_helper
INFO - 2018-03-20 11:30:53 --> Helper loaded: notification_helper
INFO - 2018-03-20 11:30:53 --> Helper loaded: settings_helper
INFO - 2018-03-20 11:30:53 --> Helper loaded: permission_helper
INFO - 2018-03-20 11:30:53 --> Helper loaded: users_helper
INFO - 2018-03-20 11:30:53 --> Database Driver Class Initialized
DEBUG - 2018-03-20 11:30:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 11:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 11:30:53 --> Helper loaded: form_helper
INFO - 2018-03-20 11:30:53 --> Form Validation Class Initialized
INFO - 2018-03-20 11:30:53 --> Controller Class Initialized
INFO - 2018-03-20 11:30:53 --> Model Class Initialized
INFO - 2018-03-20 11:30:53 --> Helper loaded: inflector_helper
DEBUG - 2018-03-20 11:30:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 11:30:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 11:30:53 --> Model Class Initialized
INFO - 2018-03-20 11:30:53 --> Model Class Initialized
INFO - 2018-03-20 11:30:53 --> Model Class Initialized
INFO - 2018-03-20 11:30:53 --> Model Class Initialized
INFO - 2018-03-20 11:30:53 --> Model Class Initialized
INFO - 2018-03-20 11:30:53 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-20 11:30:53 --> Model Class Initialized
INFO - 2018-03-20 11:30:53 --> Final output sent to browser
DEBUG - 2018-03-20 11:30:53 --> Total execution time: 0.4552
INFO - 2018-03-20 11:30:53 --> Helper loaded: url_helper
INFO - 2018-03-20 11:30:53 --> Helper loaded: notification_helper
INFO - 2018-03-20 11:30:53 --> Helper loaded: settings_helper
INFO - 2018-03-20 11:30:53 --> Helper loaded: permission_helper
INFO - 2018-03-20 11:30:53 --> Helper loaded: users_helper
INFO - 2018-03-20 11:30:54 --> Database Driver Class Initialized
DEBUG - 2018-03-20 11:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 11:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 11:30:54 --> Helper loaded: form_helper
INFO - 2018-03-20 11:30:54 --> Form Validation Class Initialized
INFO - 2018-03-20 11:30:54 --> Controller Class Initialized
INFO - 2018-03-20 11:30:54 --> Model Class Initialized
INFO - 2018-03-20 11:30:54 --> Helper loaded: inflector_helper
DEBUG - 2018-03-20 11:30:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 11:30:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 11:30:54 --> Model Class Initialized
INFO - 2018-03-20 11:30:54 --> Model Class Initialized
INFO - 2018-03-20 11:30:54 --> Model Class Initialized
INFO - 2018-03-20 11:30:54 --> Model Class Initialized
INFO - 2018-03-20 11:30:54 --> Model Class Initialized
INFO - 2018-03-20 11:30:54 --> Model Class Initialized
INFO - 2018-03-20 11:30:54 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-20 11:30:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-03-20 11:30:54 --> Final output sent to browser
DEBUG - 2018-03-20 11:30:54 --> Total execution time: 1.7094
INFO - 2018-03-20 06:01:42 --> Config Class Initialized
INFO - 2018-03-20 06:01:42 --> Hooks Class Initialized
DEBUG - 2018-03-20 06:01:42 --> UTF-8 Support Enabled
INFO - 2018-03-20 06:01:42 --> Utf8 Class Initialized
INFO - 2018-03-20 06:01:42 --> URI Class Initialized
INFO - 2018-03-20 06:01:42 --> Router Class Initialized
INFO - 2018-03-20 06:01:42 --> Output Class Initialized
INFO - 2018-03-20 06:01:42 --> Security Class Initialized
DEBUG - 2018-03-20 06:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 06:01:42 --> Input Class Initialized
INFO - 2018-03-20 06:01:42 --> Language Class Initialized
INFO - 2018-03-20 06:01:42 --> Language Class Initialized
INFO - 2018-03-20 06:01:42 --> Config Class Initialized
INFO - 2018-03-20 06:01:42 --> Loader Class Initialized
INFO - 2018-03-20 11:31:42 --> Helper loaded: url_helper
INFO - 2018-03-20 11:31:42 --> Helper loaded: notification_helper
INFO - 2018-03-20 11:31:43 --> Helper loaded: settings_helper
INFO - 2018-03-20 11:31:43 --> Helper loaded: permission_helper
INFO - 2018-03-20 11:31:43 --> Helper loaded: users_helper
INFO - 2018-03-20 11:31:43 --> Database Driver Class Initialized
DEBUG - 2018-03-20 11:31:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 11:31:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 11:31:43 --> Helper loaded: form_helper
INFO - 2018-03-20 11:31:43 --> Form Validation Class Initialized
INFO - 2018-03-20 11:31:43 --> Controller Class Initialized
INFO - 2018-03-20 11:31:43 --> Model Class Initialized
INFO - 2018-03-20 11:31:43 --> Helper loaded: inflector_helper
INFO - 2018-03-20 11:31:43 --> Model Class Initialized
INFO - 2018-03-20 11:31:43 --> Model Class Initialized
INFO - 2018-03-20 11:31:43 --> Model Class Initialized
DEBUG - 2018-03-20 11:31:43 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-03-20 11:31:43 --> File loaded: /home/pr01004/public_html/application/views/preference/edit.php
DEBUG - 2018-03-20 11:31:43 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-03-20 11:31:43 --> Final output sent to browser
DEBUG - 2018-03-20 11:31:43 --> Total execution time: 1.6325
INFO - 2018-03-20 06:03:16 --> Config Class Initialized
INFO - 2018-03-20 06:03:16 --> Hooks Class Initialized
DEBUG - 2018-03-20 06:03:16 --> UTF-8 Support Enabled
INFO - 2018-03-20 06:03:16 --> Utf8 Class Initialized
INFO - 2018-03-20 06:03:16 --> URI Class Initialized
INFO - 2018-03-20 06:03:16 --> Router Class Initialized
INFO - 2018-03-20 06:03:16 --> Output Class Initialized
INFO - 2018-03-20 06:03:16 --> Security Class Initialized
DEBUG - 2018-03-20 06:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 06:03:16 --> Input Class Initialized
INFO - 2018-03-20 06:03:16 --> Language Class Initialized
INFO - 2018-03-20 06:03:16 --> Language Class Initialized
INFO - 2018-03-20 06:03:16 --> Config Class Initialized
INFO - 2018-03-20 06:03:16 --> Loader Class Initialized
INFO - 2018-03-20 11:33:16 --> Helper loaded: url_helper
INFO - 2018-03-20 11:33:16 --> Helper loaded: notification_helper
INFO - 2018-03-20 11:33:16 --> Helper loaded: settings_helper
INFO - 2018-03-20 11:33:16 --> Helper loaded: permission_helper
INFO - 2018-03-20 11:33:16 --> Helper loaded: users_helper
INFO - 2018-03-20 11:33:16 --> Database Driver Class Initialized
DEBUG - 2018-03-20 11:33:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 11:33:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 11:33:16 --> Helper loaded: form_helper
INFO - 2018-03-20 11:33:16 --> Form Validation Class Initialized
INFO - 2018-03-20 11:33:16 --> Controller Class Initialized
INFO - 2018-03-20 11:33:16 --> Model Class Initialized
INFO - 2018-03-20 11:33:16 --> Helper loaded: inflector_helper
INFO - 2018-03-20 11:33:16 --> Model Class Initialized
INFO - 2018-03-20 11:33:16 --> Model Class Initialized
INFO - 2018-03-20 11:33:16 --> Model Class Initialized
DEBUG - 2018-03-20 11:33:16 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-03-20 11:33:16 --> File loaded: /home/pr01004/public_html/application/views/preference/index.php
DEBUG - 2018-03-20 11:33:16 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-03-20 11:33:16 --> Final output sent to browser
DEBUG - 2018-03-20 11:33:16 --> Total execution time: 0.1663
INFO - 2018-03-20 06:03:22 --> Config Class Initialized
INFO - 2018-03-20 06:03:22 --> Hooks Class Initialized
DEBUG - 2018-03-20 06:03:22 --> UTF-8 Support Enabled
INFO - 2018-03-20 06:03:22 --> Utf8 Class Initialized
INFO - 2018-03-20 06:03:22 --> URI Class Initialized
INFO - 2018-03-20 06:03:22 --> Router Class Initialized
INFO - 2018-03-20 06:03:22 --> Output Class Initialized
INFO - 2018-03-20 06:03:22 --> Security Class Initialized
DEBUG - 2018-03-20 06:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 06:03:22 --> Input Class Initialized
INFO - 2018-03-20 06:03:22 --> Language Class Initialized
INFO - 2018-03-20 06:03:22 --> Language Class Initialized
INFO - 2018-03-20 06:03:22 --> Config Class Initialized
INFO - 2018-03-20 06:03:22 --> Loader Class Initialized
INFO - 2018-03-20 11:33:22 --> Helper loaded: url_helper
INFO - 2018-03-20 11:33:22 --> Helper loaded: notification_helper
INFO - 2018-03-20 11:33:22 --> Helper loaded: settings_helper
INFO - 2018-03-20 11:33:22 --> Helper loaded: permission_helper
INFO - 2018-03-20 11:33:22 --> Helper loaded: users_helper
INFO - 2018-03-20 11:33:22 --> Database Driver Class Initialized
DEBUG - 2018-03-20 11:33:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 11:33:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 11:33:22 --> Helper loaded: form_helper
INFO - 2018-03-20 11:33:22 --> Form Validation Class Initialized
INFO - 2018-03-20 11:33:22 --> Controller Class Initialized
INFO - 2018-03-20 11:33:22 --> Model Class Initialized
INFO - 2018-03-20 11:33:22 --> Helper loaded: inflector_helper
INFO - 2018-03-20 11:33:22 --> Model Class Initialized
INFO - 2018-03-20 11:33:22 --> Model Class Initialized
INFO - 2018-03-20 11:33:22 --> Model Class Initialized
DEBUG - 2018-03-20 11:33:22 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-03-20 11:33:22 --> File loaded: /home/pr01004/public_html/application/views/preference/edit.php
DEBUG - 2018-03-20 11:33:22 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-03-20 11:33:22 --> Final output sent to browser
DEBUG - 2018-03-20 11:33:22 --> Total execution time: 0.0938
INFO - 2018-03-20 06:04:03 --> Config Class Initialized
INFO - 2018-03-20 06:04:03 --> Hooks Class Initialized
DEBUG - 2018-03-20 06:04:03 --> UTF-8 Support Enabled
INFO - 2018-03-20 06:04:03 --> Utf8 Class Initialized
INFO - 2018-03-20 06:04:04 --> URI Class Initialized
INFO - 2018-03-20 06:04:04 --> Router Class Initialized
INFO - 2018-03-20 06:04:04 --> Output Class Initialized
INFO - 2018-03-20 06:04:04 --> Security Class Initialized
DEBUG - 2018-03-20 06:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 06:04:04 --> Input Class Initialized
INFO - 2018-03-20 06:04:04 --> Language Class Initialized
INFO - 2018-03-20 06:04:04 --> Language Class Initialized
INFO - 2018-03-20 06:04:04 --> Config Class Initialized
INFO - 2018-03-20 06:04:04 --> Loader Class Initialized
INFO - 2018-03-20 11:34:04 --> Helper loaded: url_helper
INFO - 2018-03-20 11:34:04 --> Helper loaded: notification_helper
INFO - 2018-03-20 11:34:04 --> Helper loaded: settings_helper
INFO - 2018-03-20 11:34:04 --> Helper loaded: permission_helper
INFO - 2018-03-20 11:34:04 --> Helper loaded: users_helper
INFO - 2018-03-20 11:34:05 --> Database Driver Class Initialized
DEBUG - 2018-03-20 11:34:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 11:34:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 11:34:05 --> Helper loaded: form_helper
INFO - 2018-03-20 11:34:05 --> Form Validation Class Initialized
INFO - 2018-03-20 11:34:05 --> Controller Class Initialized
INFO - 2018-03-20 11:34:05 --> Model Class Initialized
INFO - 2018-03-20 11:34:05 --> Helper loaded: inflector_helper
INFO - 2018-03-20 11:34:05 --> Model Class Initialized
INFO - 2018-03-20 11:34:05 --> Model Class Initialized
INFO - 2018-03-20 11:34:05 --> Model Class Initialized
DEBUG - 2018-03-20 11:34:05 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-03-20 11:34:05 --> File loaded: /home/pr01004/public_html/application/views/preference/index.php
DEBUG - 2018-03-20 11:34:05 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-03-20 11:34:05 --> Final output sent to browser
DEBUG - 2018-03-20 11:34:05 --> Total execution time: 1.9526
INFO - 2018-03-20 06:10:37 --> Config Class Initialized
INFO - 2018-03-20 06:10:37 --> Hooks Class Initialized
DEBUG - 2018-03-20 06:10:37 --> UTF-8 Support Enabled
INFO - 2018-03-20 06:10:37 --> Utf8 Class Initialized
INFO - 2018-03-20 06:10:37 --> URI Class Initialized
INFO - 2018-03-20 06:10:37 --> Router Class Initialized
INFO - 2018-03-20 06:10:37 --> Output Class Initialized
INFO - 2018-03-20 06:10:37 --> Security Class Initialized
DEBUG - 2018-03-20 06:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 06:10:37 --> Input Class Initialized
INFO - 2018-03-20 06:10:37 --> Language Class Initialized
INFO - 2018-03-20 06:10:37 --> Config Class Initialized
INFO - 2018-03-20 06:10:37 --> Hooks Class Initialized
DEBUG - 2018-03-20 06:10:37 --> UTF-8 Support Enabled
INFO - 2018-03-20 06:10:37 --> Utf8 Class Initialized
INFO - 2018-03-20 06:10:37 --> URI Class Initialized
INFO - 2018-03-20 06:10:37 --> Config Class Initialized
INFO - 2018-03-20 06:10:37 --> Hooks Class Initialized
INFO - 2018-03-20 06:10:37 --> Router Class Initialized
INFO - 2018-03-20 06:10:37 --> Output Class Initialized
INFO - 2018-03-20 06:10:37 --> Security Class Initialized
DEBUG - 2018-03-20 06:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 06:10:37 --> Input Class Initialized
INFO - 2018-03-20 06:10:37 --> Language Class Initialized
DEBUG - 2018-03-20 06:10:37 --> UTF-8 Support Enabled
INFO - 2018-03-20 06:10:37 --> Utf8 Class Initialized
INFO - 2018-03-20 06:10:37 --> URI Class Initialized
INFO - 2018-03-20 06:10:37 --> Language Class Initialized
INFO - 2018-03-20 06:10:37 --> Config Class Initialized
INFO - 2018-03-20 06:10:37 --> Loader Class Initialized
INFO - 2018-03-20 06:10:37 --> Router Class Initialized
INFO - 2018-03-20 11:40:37 --> Helper loaded: url_helper
INFO - 2018-03-20 11:40:37 --> Helper loaded: notification_helper
INFO - 2018-03-20 11:40:37 --> Helper loaded: settings_helper
INFO - 2018-03-20 11:40:37 --> Helper loaded: permission_helper
INFO - 2018-03-20 11:40:37 --> Helper loaded: users_helper
INFO - 2018-03-20 06:10:37 --> Config Class Initialized
INFO - 2018-03-20 06:10:37 --> Hooks Class Initialized
INFO - 2018-03-20 06:10:37 --> Output Class Initialized
DEBUG - 2018-03-20 06:10:37 --> UTF-8 Support Enabled
INFO - 2018-03-20 06:10:37 --> Security Class Initialized
INFO - 2018-03-20 06:10:37 --> Utf8 Class Initialized
INFO - 2018-03-20 11:40:37 --> Database Driver Class Initialized
INFO - 2018-03-20 06:10:37 --> URI Class Initialized
DEBUG - 2018-03-20 11:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 11:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 06:10:37 --> Router Class Initialized
INFO - 2018-03-20 11:40:37 --> Helper loaded: form_helper
INFO - 2018-03-20 11:40:37 --> Form Validation Class Initialized
INFO - 2018-03-20 11:40:37 --> Controller Class Initialized
DEBUG - 2018-03-20 06:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 06:10:37 --> Input Class Initialized
INFO - 2018-03-20 06:10:37 --> Output Class Initialized
INFO - 2018-03-20 06:10:37 --> Language Class Initialized
INFO - 2018-03-20 06:10:37 --> Language Class Initialized
INFO - 2018-03-20 06:10:37 --> Config Class Initialized
INFO - 2018-03-20 06:10:37 --> Loader Class Initialized
INFO - 2018-03-20 06:10:37 --> Security Class Initialized
INFO - 2018-03-20 11:40:37 --> Helper loaded: url_helper
INFO - 2018-03-20 11:40:37 --> Helper loaded: notification_helper
INFO - 2018-03-20 11:40:37 --> Model Class Initialized
DEBUG - 2018-03-20 06:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 06:10:37 --> Input Class Initialized
INFO - 2018-03-20 11:40:37 --> Helper loaded: settings_helper
INFO - 2018-03-20 11:40:37 --> Helper loaded: permission_helper
INFO - 2018-03-20 11:40:37 --> Helper loaded: inflector_helper
INFO - 2018-03-20 06:10:37 --> Language Class Initialized
INFO - 2018-03-20 11:40:37 --> Helper loaded: users_helper
DEBUG - 2018-03-20 11:40:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 11:40:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 11:40:37 --> Model Class Initialized
INFO - 2018-03-20 11:40:37 --> Model Class Initialized
INFO - 2018-03-20 11:40:37 --> Model Class Initialized
INFO - 2018-03-20 11:40:37 --> Model Class Initialized
INFO - 2018-03-20 11:40:37 --> Model Class Initialized
INFO - 2018-03-20 11:40:37 --> Model Class Initialized
INFO - 2018-03-20 11:40:37 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-20 11:40:37 --> Model Class Initialized
INFO - 2018-03-20 11:40:37 --> Final output sent to browser
DEBUG - 2018-03-20 11:40:37 --> Total execution time: 0.1334
INFO - 2018-03-20 11:40:37 --> Database Driver Class Initialized
INFO - 2018-03-20 06:10:37 --> Language Class Initialized
INFO - 2018-03-20 06:10:37 --> Config Class Initialized
INFO - 2018-03-20 06:10:37 --> Loader Class Initialized
DEBUG - 2018-03-20 11:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 11:40:37 --> Helper loaded: url_helper
INFO - 2018-03-20 11:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 11:40:37 --> Helper loaded: notification_helper
INFO - 2018-03-20 11:40:37 --> Helper loaded: settings_helper
INFO - 2018-03-20 11:40:37 --> Helper loaded: permission_helper
INFO - 2018-03-20 06:10:37 --> Language Class Initialized
INFO - 2018-03-20 06:10:37 --> Config Class Initialized
INFO - 2018-03-20 06:10:37 --> Loader Class Initialized
INFO - 2018-03-20 11:40:37 --> Helper loaded: users_helper
INFO - 2018-03-20 11:40:37 --> Helper loaded: url_helper
INFO - 2018-03-20 11:40:37 --> Helper loaded: notification_helper
INFO - 2018-03-20 11:40:37 --> Helper loaded: settings_helper
INFO - 2018-03-20 11:40:37 --> Helper loaded: permission_helper
INFO - 2018-03-20 11:40:37 --> Helper loaded: users_helper
INFO - 2018-03-20 11:40:37 --> Database Driver Class Initialized
DEBUG - 2018-03-20 11:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 11:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 11:40:37 --> Helper loaded: form_helper
INFO - 2018-03-20 11:40:37 --> Form Validation Class Initialized
INFO - 2018-03-20 11:40:37 --> Controller Class Initialized
INFO - 2018-03-20 11:40:37 --> Model Class Initialized
INFO - 2018-03-20 11:40:37 --> Helper loaded: inflector_helper
DEBUG - 2018-03-20 11:40:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 11:40:37 --> Helper loaded: form_helper
INFO - 2018-03-20 11:40:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 11:40:37 --> Form Validation Class Initialized
INFO - 2018-03-20 11:40:37 --> Model Class Initialized
INFO - 2018-03-20 11:40:37 --> Model Class Initialized
INFO - 2018-03-20 11:40:37 --> Controller Class Initialized
INFO - 2018-03-20 11:40:37 --> Model Class Initialized
INFO - 2018-03-20 11:40:37 --> Model Class Initialized
INFO - 2018-03-20 11:40:37 --> Model Class Initialized
INFO - 2018-03-20 11:40:37 --> Model Class Initialized
INFO - 2018-03-20 11:40:37 --> Model Class Initialized
INFO - 2018-03-20 11:40:37 --> Model Class Initialized
INFO - 2018-03-20 11:40:37 --> Model Class Initialized
INFO - 2018-03-20 11:40:37 --> Model Class Initialized
INFO - 2018-03-20 11:40:37 --> Model Class Initialized
INFO - 2018-03-20 11:40:37 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-20 11:40:37 --> Model Class Initialized
INFO - 2018-03-20 11:40:37 --> Database Driver Class Initialized
INFO - 2018-03-20 11:40:37 --> Final output sent to browser
DEBUG - 2018-03-20 11:40:37 --> Total execution time: 0.3713
DEBUG - 2018-03-20 11:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 11:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 06:10:38 --> Config Class Initialized
INFO - 2018-03-20 06:10:38 --> Hooks Class Initialized
INFO - 2018-03-20 11:40:38 --> Helper loaded: form_helper
INFO - 2018-03-20 11:40:38 --> Form Validation Class Initialized
INFO - 2018-03-20 11:40:38 --> Controller Class Initialized
INFO - 2018-03-20 11:40:38 --> Model Class Initialized
INFO - 2018-03-20 11:40:38 --> Helper loaded: inflector_helper
INFO - 2018-03-20 11:40:38 --> Model Class Initialized
DEBUG - 2018-03-20 11:40:38 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 11:40:38 --> Helper loaded: inflector_helper
DEBUG - 2018-03-20 06:10:38 --> UTF-8 Support Enabled
INFO - 2018-03-20 06:10:38 --> Utf8 Class Initialized
INFO - 2018-03-20 11:40:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 11:40:38 --> Model Class Initialized
INFO - 2018-03-20 11:40:38 --> Model Class Initialized
INFO - 2018-03-20 06:10:38 --> URI Class Initialized
INFO - 2018-03-20 11:40:38 --> Model Class Initialized
INFO - 2018-03-20 11:40:38 --> Model Class Initialized
INFO - 2018-03-20 11:40:38 --> Model Class Initialized
INFO - 2018-03-20 11:40:38 --> Model Class Initialized
INFO - 2018-03-20 11:40:38 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-03-20 11:40:38 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 11:40:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 11:40:38 --> Model Class Initialized
INFO - 2018-03-20 11:40:38 --> Model Class Initialized
INFO - 2018-03-20 11:40:38 --> Model Class Initialized
INFO - 2018-03-20 11:40:38 --> Model Class Initialized
INFO - 2018-03-20 11:40:38 --> Model Class Initialized
INFO - 2018-03-20 11:40:38 --> Model Class Initialized
INFO - 2018-03-20 11:40:38 --> Final output sent to browser
DEBUG - 2018-03-20 11:40:38 --> Total execution time: 0.5825
INFO - 2018-03-20 11:40:38 --> Model Class Initialized
INFO - 2018-03-20 11:40:38 --> Model Class Initialized
INFO - 2018-03-20 11:40:38 --> Model Class Initialized
INFO - 2018-03-20 11:40:38 --> Model Class Initialized
INFO - 2018-03-20 11:40:38 --> Model Class Initialized
INFO - 2018-03-20 11:40:38 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-20 11:40:38 --> Model Class Initialized
INFO - 2018-03-20 11:40:38 --> Final output sent to browser
DEBUG - 2018-03-20 11:40:38 --> Total execution time: 0.7189
INFO - 2018-03-20 06:10:38 --> Router Class Initialized
INFO - 2018-03-20 06:10:38 --> Output Class Initialized
INFO - 2018-03-20 06:10:38 --> Security Class Initialized
DEBUG - 2018-03-20 06:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 06:10:38 --> Input Class Initialized
INFO - 2018-03-20 06:10:38 --> Language Class Initialized
INFO - 2018-03-20 06:10:39 --> Language Class Initialized
INFO - 2018-03-20 06:10:39 --> Config Class Initialized
INFO - 2018-03-20 06:10:39 --> Loader Class Initialized
INFO - 2018-03-20 11:40:39 --> Helper loaded: url_helper
INFO - 2018-03-20 11:40:39 --> Helper loaded: notification_helper
INFO - 2018-03-20 11:40:39 --> Helper loaded: settings_helper
INFO - 2018-03-20 11:40:39 --> Helper loaded: permission_helper
INFO - 2018-03-20 11:40:39 --> Helper loaded: users_helper
INFO - 2018-03-20 06:10:40 --> Config Class Initialized
INFO - 2018-03-20 06:10:40 --> Hooks Class Initialized
DEBUG - 2018-03-20 06:10:40 --> UTF-8 Support Enabled
INFO - 2018-03-20 06:10:40 --> Utf8 Class Initialized
INFO - 2018-03-20 06:10:40 --> URI Class Initialized
INFO - 2018-03-20 06:10:40 --> Router Class Initialized
INFO - 2018-03-20 06:10:40 --> Output Class Initialized
INFO - 2018-03-20 06:10:40 --> Security Class Initialized
DEBUG - 2018-03-20 06:10:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 06:10:40 --> Input Class Initialized
INFO - 2018-03-20 06:10:40 --> Language Class Initialized
INFO - 2018-03-20 06:10:40 --> Language Class Initialized
INFO - 2018-03-20 06:10:40 --> Config Class Initialized
INFO - 2018-03-20 06:10:40 --> Loader Class Initialized
INFO - 2018-03-20 11:40:40 --> Helper loaded: url_helper
INFO - 2018-03-20 11:40:40 --> Helper loaded: notification_helper
INFO - 2018-03-20 11:40:40 --> Helper loaded: settings_helper
INFO - 2018-03-20 11:40:40 --> Helper loaded: permission_helper
INFO - 2018-03-20 11:40:40 --> Helper loaded: users_helper
INFO - 2018-03-20 11:40:40 --> Database Driver Class Initialized
DEBUG - 2018-03-20 11:40:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 11:40:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 11:40:40 --> Helper loaded: form_helper
INFO - 2018-03-20 11:40:40 --> Form Validation Class Initialized
INFO - 2018-03-20 11:40:40 --> Controller Class Initialized
INFO - 2018-03-20 11:40:40 --> Model Class Initialized
INFO - 2018-03-20 11:40:40 --> Helper loaded: inflector_helper
DEBUG - 2018-03-20 11:40:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 11:40:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 11:40:40 --> Model Class Initialized
INFO - 2018-03-20 11:40:40 --> Model Class Initialized
INFO - 2018-03-20 11:40:40 --> Model Class Initialized
INFO - 2018-03-20 11:40:40 --> Model Class Initialized
INFO - 2018-03-20 11:40:40 --> Model Class Initialized
INFO - 2018-03-20 11:40:40 --> Model Class Initialized
INFO - 2018-03-20 11:40:40 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-20 11:40:40 --> Model Class Initialized
INFO - 2018-03-20 11:40:40 --> Final output sent to browser
DEBUG - 2018-03-20 11:40:40 --> Total execution time: 0.1246
INFO - 2018-03-20 11:40:40 --> Database Driver Class Initialized
DEBUG - 2018-03-20 11:40:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 11:40:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 11:40:40 --> Helper loaded: form_helper
INFO - 2018-03-20 11:40:40 --> Form Validation Class Initialized
INFO - 2018-03-20 11:40:40 --> Controller Class Initialized
INFO - 2018-03-20 11:40:40 --> Model Class Initialized
INFO - 2018-03-20 11:40:40 --> Helper loaded: inflector_helper
DEBUG - 2018-03-20 11:40:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 11:40:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 11:40:40 --> Model Class Initialized
INFO - 2018-03-20 11:40:40 --> Model Class Initialized
INFO - 2018-03-20 11:40:40 --> Model Class Initialized
INFO - 2018-03-20 11:40:40 --> Model Class Initialized
INFO - 2018-03-20 11:40:40 --> Model Class Initialized
INFO - 2018-03-20 11:40:40 --> Model Class Initialized
INFO - 2018-03-20 11:40:40 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-20 11:40:40 --> Model Class Initialized
INFO - 2018-03-20 11:40:40 --> Final output sent to browser
DEBUG - 2018-03-20 11:40:40 --> Total execution time: 2.5949
INFO - 2018-03-20 06:10:42 --> Config Class Initialized
INFO - 2018-03-20 06:10:42 --> Hooks Class Initialized
DEBUG - 2018-03-20 06:10:42 --> UTF-8 Support Enabled
INFO - 2018-03-20 06:10:42 --> Utf8 Class Initialized
INFO - 2018-03-20 06:10:42 --> Config Class Initialized
INFO - 2018-03-20 06:10:42 --> Hooks Class Initialized
INFO - 2018-03-20 06:10:42 --> URI Class Initialized
INFO - 2018-03-20 06:10:42 --> Config Class Initialized
INFO - 2018-03-20 06:10:42 --> Hooks Class Initialized
DEBUG - 2018-03-20 06:10:42 --> UTF-8 Support Enabled
INFO - 2018-03-20 06:10:42 --> Utf8 Class Initialized
INFO - 2018-03-20 06:10:42 --> URI Class Initialized
DEBUG - 2018-03-20 06:10:42 --> UTF-8 Support Enabled
INFO - 2018-03-20 06:10:42 --> Utf8 Class Initialized
INFO - 2018-03-20 06:10:42 --> Router Class Initialized
INFO - 2018-03-20 06:10:42 --> URI Class Initialized
INFO - 2018-03-20 06:10:42 --> Router Class Initialized
INFO - 2018-03-20 06:10:42 --> Output Class Initialized
INFO - 2018-03-20 06:10:42 --> Security Class Initialized
INFO - 2018-03-20 06:10:42 --> Output Class Initialized
INFO - 2018-03-20 06:10:42 --> Router Class Initialized
DEBUG - 2018-03-20 06:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 06:10:42 --> Input Class Initialized
INFO - 2018-03-20 06:10:43 --> Language Class Initialized
INFO - 2018-03-20 06:10:43 --> Security Class Initialized
DEBUG - 2018-03-20 06:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 06:10:43 --> Input Class Initialized
INFO - 2018-03-20 06:10:43 --> Output Class Initialized
INFO - 2018-03-20 06:10:43 --> Language Class Initialized
INFO - 2018-03-20 06:10:43 --> Security Class Initialized
DEBUG - 2018-03-20 06:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 06:10:43 --> Input Class Initialized
INFO - 2018-03-20 06:10:43 --> Language Class Initialized
INFO - 2018-03-20 06:10:43 --> Language Class Initialized
INFO - 2018-03-20 06:10:43 --> Config Class Initialized
INFO - 2018-03-20 06:10:43 --> Loader Class Initialized
INFO - 2018-03-20 11:40:43 --> Helper loaded: url_helper
INFO - 2018-03-20 11:40:43 --> Helper loaded: notification_helper
INFO - 2018-03-20 11:40:43 --> Helper loaded: settings_helper
INFO - 2018-03-20 11:40:43 --> Helper loaded: permission_helper
INFO - 2018-03-20 11:40:44 --> Helper loaded: users_helper
INFO - 2018-03-20 06:10:44 --> Language Class Initialized
INFO - 2018-03-20 06:10:44 --> Config Class Initialized
INFO - 2018-03-20 06:10:44 --> Loader Class Initialized
INFO - 2018-03-20 11:40:44 --> Helper loaded: url_helper
INFO - 2018-03-20 11:40:44 --> Helper loaded: notification_helper
INFO - 2018-03-20 11:40:44 --> Helper loaded: settings_helper
INFO - 2018-03-20 11:40:44 --> Helper loaded: permission_helper
INFO - 2018-03-20 11:40:44 --> Helper loaded: users_helper
INFO - 2018-03-20 06:10:44 --> Language Class Initialized
INFO - 2018-03-20 06:10:44 --> Config Class Initialized
INFO - 2018-03-20 06:10:44 --> Loader Class Initialized
INFO - 2018-03-20 11:40:44 --> Helper loaded: url_helper
INFO - 2018-03-20 11:40:44 --> Helper loaded: notification_helper
INFO - 2018-03-20 11:40:44 --> Helper loaded: settings_helper
INFO - 2018-03-20 11:40:44 --> Helper loaded: permission_helper
INFO - 2018-03-20 11:40:44 --> Helper loaded: users_helper
INFO - 2018-03-20 11:40:44 --> Database Driver Class Initialized
DEBUG - 2018-03-20 11:40:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 11:40:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 11:40:44 --> Database Driver Class Initialized
DEBUG - 2018-03-20 11:40:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 11:40:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 11:40:44 --> Helper loaded: form_helper
INFO - 2018-03-20 11:40:44 --> Form Validation Class Initialized
INFO - 2018-03-20 11:40:44 --> Controller Class Initialized
INFO - 2018-03-20 11:40:44 --> Helper loaded: form_helper
INFO - 2018-03-20 11:40:44 --> Form Validation Class Initialized
INFO - 2018-03-20 11:40:44 --> Controller Class Initialized
INFO - 2018-03-20 11:40:44 --> Model Class Initialized
INFO - 2018-03-20 11:40:44 --> Helper loaded: inflector_helper
DEBUG - 2018-03-20 11:40:44 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 11:40:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 11:40:44 --> Model Class Initialized
INFO - 2018-03-20 11:40:44 --> Model Class Initialized
INFO - 2018-03-20 11:40:44 --> Model Class Initialized
INFO - 2018-03-20 11:40:44 --> Model Class Initialized
INFO - 2018-03-20 11:40:44 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-20 11:40:44 --> Final output sent to browser
DEBUG - 2018-03-20 11:40:44 --> Total execution time: 2.1509
INFO - 2018-03-20 11:40:44 --> Model Class Initialized
INFO - 2018-03-20 11:40:44 --> Helper loaded: inflector_helper
DEBUG - 2018-03-20 11:40:44 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 11:40:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 11:40:44 --> Model Class Initialized
INFO - 2018-03-20 11:40:44 --> Model Class Initialized
INFO - 2018-03-20 11:40:44 --> Model Class Initialized
INFO - 2018-03-20 11:40:44 --> Model Class Initialized
INFO - 2018-03-20 11:40:45 --> Model Class Initialized
INFO - 2018-03-20 06:10:45 --> Config Class Initialized
INFO - 2018-03-20 06:10:45 --> Hooks Class Initialized
DEBUG - 2018-03-20 06:10:45 --> UTF-8 Support Enabled
INFO - 2018-03-20 06:10:45 --> Utf8 Class Initialized
INFO - 2018-03-20 06:10:45 --> URI Class Initialized
INFO - 2018-03-20 11:40:45 --> Model Class Initialized
INFO - 2018-03-20 06:10:45 --> Router Class Initialized
INFO - 2018-03-20 06:10:45 --> Output Class Initialized
INFO - 2018-03-20 06:10:45 --> Security Class Initialized
INFO - 2018-03-20 11:40:45 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-03-20 06:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 06:10:45 --> Input Class Initialized
INFO - 2018-03-20 06:10:45 --> Language Class Initialized
INFO - 2018-03-20 06:10:45 --> Language Class Initialized
INFO - 2018-03-20 06:10:45 --> Config Class Initialized
INFO - 2018-03-20 06:10:45 --> Loader Class Initialized
INFO - 2018-03-20 11:40:45 --> Helper loaded: url_helper
INFO - 2018-03-20 11:40:45 --> Helper loaded: notification_helper
INFO - 2018-03-20 11:40:45 --> Helper loaded: settings_helper
INFO - 2018-03-20 11:40:45 --> Helper loaded: permission_helper
INFO - 2018-03-20 11:40:45 --> Helper loaded: users_helper
INFO - 2018-03-20 11:40:45 --> Database Driver Class Initialized
DEBUG - 2018-03-20 11:40:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 11:40:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 11:40:45 --> Database Driver Class Initialized
INFO - 2018-03-20 11:40:45 --> Helper loaded: form_helper
INFO - 2018-03-20 11:40:45 --> Form Validation Class Initialized
INFO - 2018-03-20 11:40:45 --> Controller Class Initialized
DEBUG - 2018-03-20 11:40:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 11:40:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 11:40:45 --> Model Class Initialized
INFO - 2018-03-20 11:40:45 --> Helper loaded: inflector_helper
INFO - 2018-03-20 11:40:45 --> Helper loaded: form_helper
INFO - 2018-03-20 11:40:45 --> Form Validation Class Initialized
INFO - 2018-03-20 11:40:45 --> Controller Class Initialized
DEBUG - 2018-03-20 11:40:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 11:40:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 11:40:45 --> Model Class Initialized
INFO - 2018-03-20 11:40:45 --> Model Class Initialized
INFO - 2018-03-20 11:40:45 --> Model Class Initialized
INFO - 2018-03-20 11:40:45 --> Model Class Initialized
INFO - 2018-03-20 11:40:45 --> Model Class Initialized
INFO - 2018-03-20 11:40:45 --> Model Class Initialized
INFO - 2018-03-20 11:40:45 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-20 11:40:45 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-03-20 11:40:45 --> Model Class Initialized
INFO - 2018-03-20 11:40:45 --> Final output sent to browser
INFO - 2018-03-20 11:40:45 --> Helper loaded: inflector_helper
DEBUG - 2018-03-20 11:40:45 --> Total execution time: 0.1602
DEBUG - 2018-03-20 11:40:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 11:40:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 11:40:45 --> Model Class Initialized
INFO - 2018-03-20 11:40:45 --> Model Class Initialized
INFO - 2018-03-20 11:40:45 --> Model Class Initialized
INFO - 2018-03-20 11:40:45 --> Model Class Initialized
INFO - 2018-03-20 11:40:45 --> Model Class Initialized
INFO - 2018-03-20 11:40:45 --> Model Class Initialized
INFO - 2018-03-20 11:40:45 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-20 11:40:45 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-03-20 11:40:45 --> Final output sent to browser
DEBUG - 2018-03-20 11:40:45 --> Total execution time: 2.4151
ERROR - 2018-03-20 11:40:45 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-03-20 11:40:45 --> Final output sent to browser
DEBUG - 2018-03-20 11:40:45 --> Total execution time: 2.4509
INFO - 2018-03-20 06:10:45 --> Config Class Initialized
INFO - 2018-03-20 06:10:45 --> Hooks Class Initialized
DEBUG - 2018-03-20 06:10:45 --> UTF-8 Support Enabled
INFO - 2018-03-20 06:10:45 --> Utf8 Class Initialized
INFO - 2018-03-20 06:10:45 --> URI Class Initialized
INFO - 2018-03-20 06:10:45 --> Router Class Initialized
INFO - 2018-03-20 06:10:45 --> Output Class Initialized
INFO - 2018-03-20 06:10:45 --> Security Class Initialized
DEBUG - 2018-03-20 06:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 06:10:45 --> Input Class Initialized
INFO - 2018-03-20 06:10:45 --> Language Class Initialized
INFO - 2018-03-20 06:10:45 --> Language Class Initialized
INFO - 2018-03-20 06:10:45 --> Config Class Initialized
INFO - 2018-03-20 06:10:45 --> Loader Class Initialized
INFO - 2018-03-20 11:40:45 --> Helper loaded: url_helper
INFO - 2018-03-20 11:40:45 --> Helper loaded: notification_helper
INFO - 2018-03-20 11:40:45 --> Helper loaded: settings_helper
INFO - 2018-03-20 11:40:45 --> Helper loaded: permission_helper
INFO - 2018-03-20 11:40:45 --> Helper loaded: users_helper
INFO - 2018-03-20 11:40:45 --> Database Driver Class Initialized
DEBUG - 2018-03-20 11:40:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 11:40:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 11:40:45 --> Helper loaded: form_helper
INFO - 2018-03-20 11:40:45 --> Form Validation Class Initialized
INFO - 2018-03-20 11:40:45 --> Controller Class Initialized
INFO - 2018-03-20 11:40:45 --> Model Class Initialized
INFO - 2018-03-20 11:40:45 --> Helper loaded: inflector_helper
DEBUG - 2018-03-20 11:40:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 11:40:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 11:40:45 --> Model Class Initialized
INFO - 2018-03-20 11:40:45 --> Model Class Initialized
INFO - 2018-03-20 11:40:45 --> Model Class Initialized
INFO - 2018-03-20 11:40:45 --> Model Class Initialized
INFO - 2018-03-20 11:40:45 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-20 11:40:45 --> Final output sent to browser
DEBUG - 2018-03-20 11:40:45 --> Total execution time: 0.1179
INFO - 2018-03-20 06:10:45 --> Config Class Initialized
INFO - 2018-03-20 06:10:45 --> Hooks Class Initialized
DEBUG - 2018-03-20 06:10:45 --> UTF-8 Support Enabled
INFO - 2018-03-20 06:10:45 --> Utf8 Class Initialized
INFO - 2018-03-20 06:10:45 --> URI Class Initialized
INFO - 2018-03-20 06:10:46 --> Router Class Initialized
INFO - 2018-03-20 06:10:46 --> Output Class Initialized
INFO - 2018-03-20 06:10:46 --> Security Class Initialized
DEBUG - 2018-03-20 06:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 06:10:46 --> Input Class Initialized
INFO - 2018-03-20 06:10:46 --> Language Class Initialized
INFO - 2018-03-20 06:10:46 --> Language Class Initialized
INFO - 2018-03-20 06:10:46 --> Config Class Initialized
INFO - 2018-03-20 06:10:46 --> Loader Class Initialized
INFO - 2018-03-20 11:40:46 --> Helper loaded: url_helper
INFO - 2018-03-20 11:40:46 --> Helper loaded: notification_helper
INFO - 2018-03-20 11:40:46 --> Helper loaded: settings_helper
INFO - 2018-03-20 11:40:46 --> Helper loaded: permission_helper
INFO - 2018-03-20 11:40:46 --> Helper loaded: users_helper
INFO - 2018-03-20 11:40:46 --> Database Driver Class Initialized
DEBUG - 2018-03-20 11:40:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 11:40:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 11:40:46 --> Helper loaded: form_helper
INFO - 2018-03-20 11:40:46 --> Form Validation Class Initialized
INFO - 2018-03-20 11:40:47 --> Controller Class Initialized
INFO - 2018-03-20 11:40:47 --> Model Class Initialized
INFO - 2018-03-20 11:40:47 --> Helper loaded: inflector_helper
DEBUG - 2018-03-20 11:40:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 11:40:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 11:40:47 --> Model Class Initialized
INFO - 2018-03-20 11:40:47 --> Model Class Initialized
INFO - 2018-03-20 11:40:47 --> Model Class Initialized
INFO - 2018-03-20 11:40:47 --> Model Class Initialized
INFO - 2018-03-20 11:40:47 --> Model Class Initialized
INFO - 2018-03-20 11:40:47 --> Model Class Initialized
INFO - 2018-03-20 11:40:47 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-20 11:40:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-03-20 11:40:47 --> Final output sent to browser
DEBUG - 2018-03-20 11:40:47 --> Total execution time: 1.9538
INFO - 2018-03-20 06:35:57 --> Config Class Initialized
INFO - 2018-03-20 06:35:57 --> Hooks Class Initialized
DEBUG - 2018-03-20 06:35:57 --> UTF-8 Support Enabled
INFO - 2018-03-20 06:35:57 --> Utf8 Class Initialized
INFO - 2018-03-20 06:35:57 --> URI Class Initialized
INFO - 2018-03-20 06:35:57 --> Router Class Initialized
INFO - 2018-03-20 06:35:57 --> Output Class Initialized
INFO - 2018-03-20 06:35:57 --> Security Class Initialized
DEBUG - 2018-03-20 06:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 06:35:57 --> Input Class Initialized
INFO - 2018-03-20 06:35:57 --> Language Class Initialized
INFO - 2018-03-20 06:35:57 --> Config Class Initialized
INFO - 2018-03-20 06:35:57 --> Hooks Class Initialized
INFO - 2018-03-20 06:35:57 --> Config Class Initialized
INFO - 2018-03-20 06:35:57 --> Hooks Class Initialized
INFO - 2018-03-20 06:35:57 --> Config Class Initialized
INFO - 2018-03-20 06:35:57 --> Hooks Class Initialized
DEBUG - 2018-03-20 06:35:57 --> UTF-8 Support Enabled
INFO - 2018-03-20 06:35:57 --> Utf8 Class Initialized
INFO - 2018-03-20 06:35:58 --> URI Class Initialized
DEBUG - 2018-03-20 06:35:58 --> UTF-8 Support Enabled
INFO - 2018-03-20 06:35:58 --> Utf8 Class Initialized
DEBUG - 2018-03-20 06:35:58 --> UTF-8 Support Enabled
INFO - 2018-03-20 06:35:58 --> Utf8 Class Initialized
INFO - 2018-03-20 06:35:58 --> URI Class Initialized
INFO - 2018-03-20 06:35:58 --> Router Class Initialized
INFO - 2018-03-20 06:35:58 --> Output Class Initialized
INFO - 2018-03-20 06:35:58 --> Security Class Initialized
DEBUG - 2018-03-20 06:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 06:35:58 --> Input Class Initialized
INFO - 2018-03-20 06:35:58 --> Language Class Initialized
INFO - 2018-03-20 06:35:58 --> URI Class Initialized
INFO - 2018-03-20 06:35:58 --> Language Class Initialized
INFO - 2018-03-20 06:35:58 --> Config Class Initialized
INFO - 2018-03-20 06:35:58 --> Loader Class Initialized
INFO - 2018-03-20 12:05:58 --> Helper loaded: url_helper
INFO - 2018-03-20 06:35:58 --> Language Class Initialized
INFO - 2018-03-20 12:05:58 --> Helper loaded: notification_helper
INFO - 2018-03-20 06:35:58 --> Config Class Initialized
INFO - 2018-03-20 06:35:58 --> Loader Class Initialized
INFO - 2018-03-20 12:05:58 --> Helper loaded: settings_helper
INFO - 2018-03-20 06:35:58 --> Router Class Initialized
INFO - 2018-03-20 12:05:58 --> Helper loaded: permission_helper
INFO - 2018-03-20 12:05:58 --> Helper loaded: users_helper
INFO - 2018-03-20 12:05:58 --> Database Driver Class Initialized
DEBUG - 2018-03-20 12:05:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 12:05:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 12:05:58 --> Helper loaded: form_helper
INFO - 2018-03-20 12:05:58 --> Form Validation Class Initialized
INFO - 2018-03-20 12:05:58 --> Controller Class Initialized
INFO - 2018-03-20 12:05:58 --> Model Class Initialized
INFO - 2018-03-20 12:05:58 --> Helper loaded: inflector_helper
DEBUG - 2018-03-20 12:05:58 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 12:05:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 12:05:58 --> Model Class Initialized
INFO - 2018-03-20 12:05:58 --> Model Class Initialized
INFO - 2018-03-20 12:05:58 --> Model Class Initialized
INFO - 2018-03-20 12:05:58 --> Model Class Initialized
INFO - 2018-03-20 12:05:58 --> Model Class Initialized
INFO - 2018-03-20 12:05:58 --> Model Class Initialized
INFO - 2018-03-20 12:05:58 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-20 12:05:58 --> Model Class Initialized
INFO - 2018-03-20 12:05:58 --> Final output sent to browser
DEBUG - 2018-03-20 12:05:58 --> Total execution time: 0.7308
INFO - 2018-03-20 12:05:58 --> Helper loaded: url_helper
INFO - 2018-03-20 06:35:58 --> Output Class Initialized
INFO - 2018-03-20 12:05:58 --> Helper loaded: notification_helper
INFO - 2018-03-20 06:35:58 --> Router Class Initialized
INFO - 2018-03-20 12:05:58 --> Helper loaded: settings_helper
INFO - 2018-03-20 12:05:58 --> Helper loaded: permission_helper
INFO - 2018-03-20 06:35:58 --> Security Class Initialized
INFO - 2018-03-20 12:05:58 --> Helper loaded: users_helper
INFO - 2018-03-20 06:35:58 --> Output Class Initialized
DEBUG - 2018-03-20 06:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 06:35:58 --> Input Class Initialized
INFO - 2018-03-20 06:35:58 --> Language Class Initialized
INFO - 2018-03-20 06:35:58 --> Security Class Initialized
DEBUG - 2018-03-20 06:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 06:35:58 --> Input Class Initialized
INFO - 2018-03-20 06:35:58 --> Language Class Initialized
INFO - 2018-03-20 12:05:59 --> Database Driver Class Initialized
DEBUG - 2018-03-20 12:05:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 12:05:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 06:35:59 --> Config Class Initialized
INFO - 2018-03-20 06:35:59 --> Hooks Class Initialized
INFO - 2018-03-20 06:35:59 --> Language Class Initialized
INFO - 2018-03-20 06:35:59 --> Config Class Initialized
INFO - 2018-03-20 06:35:59 --> Loader Class Initialized
INFO - 2018-03-20 12:05:59 --> Helper loaded: url_helper
INFO - 2018-03-20 12:05:59 --> Helper loaded: notification_helper
INFO - 2018-03-20 06:35:59 --> Language Class Initialized
INFO - 2018-03-20 06:35:59 --> Config Class Initialized
INFO - 2018-03-20 06:35:59 --> Loader Class Initialized
INFO - 2018-03-20 12:05:59 --> Helper loaded: url_helper
INFO - 2018-03-20 12:05:59 --> Helper loaded: notification_helper
INFO - 2018-03-20 12:05:59 --> Helper loaded: settings_helper
DEBUG - 2018-03-20 06:35:59 --> UTF-8 Support Enabled
INFO - 2018-03-20 06:35:59 --> Utf8 Class Initialized
INFO - 2018-03-20 06:35:59 --> URI Class Initialized
INFO - 2018-03-20 06:35:59 --> Router Class Initialized
INFO - 2018-03-20 06:35:59 --> Output Class Initialized
INFO - 2018-03-20 12:05:59 --> Helper loaded: form_helper
INFO - 2018-03-20 12:05:59 --> Form Validation Class Initialized
INFO - 2018-03-20 12:05:59 --> Controller Class Initialized
INFO - 2018-03-20 06:35:59 --> Security Class Initialized
INFO - 2018-03-20 12:05:59 --> Helper loaded: permission_helper
DEBUG - 2018-03-20 06:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 06:35:59 --> Input Class Initialized
INFO - 2018-03-20 06:35:59 --> Language Class Initialized
INFO - 2018-03-20 12:05:59 --> Helper loaded: users_helper
INFO - 2018-03-20 06:35:59 --> Language Class Initialized
INFO - 2018-03-20 06:35:59 --> Config Class Initialized
INFO - 2018-03-20 06:35:59 --> Loader Class Initialized
INFO - 2018-03-20 12:05:59 --> Helper loaded: url_helper
INFO - 2018-03-20 12:05:59 --> Helper loaded: notification_helper
INFO - 2018-03-20 12:05:59 --> Helper loaded: settings_helper
INFO - 2018-03-20 12:05:59 --> Helper loaded: permission_helper
INFO - 2018-03-20 12:05:59 --> Helper loaded: users_helper
INFO - 2018-03-20 12:05:59 --> Helper loaded: settings_helper
INFO - 2018-03-20 12:05:59 --> Database Driver Class Initialized
DEBUG - 2018-03-20 12:05:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 12:05:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 12:05:59 --> Helper loaded: form_helper
INFO - 2018-03-20 12:05:59 --> Form Validation Class Initialized
INFO - 2018-03-20 12:05:59 --> Controller Class Initialized
INFO - 2018-03-20 12:05:59 --> Model Class Initialized
INFO - 2018-03-20 12:05:59 --> Helper loaded: inflector_helper
DEBUG - 2018-03-20 12:05:59 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 12:05:59 --> Model Class Initialized
INFO - 2018-03-20 12:05:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 12:05:59 --> Model Class Initialized
INFO - 2018-03-20 12:05:59 --> Model Class Initialized
INFO - 2018-03-20 12:05:59 --> Model Class Initialized
INFO - 2018-03-20 12:05:59 --> Helper loaded: inflector_helper
INFO - 2018-03-20 12:05:59 --> Model Class Initialized
INFO - 2018-03-20 12:05:59 --> Model Class Initialized
INFO - 2018-03-20 12:05:59 --> Model Class Initialized
INFO - 2018-03-20 12:05:59 --> Model Class Initialized
INFO - 2018-03-20 12:05:59 --> Model Class Initialized
INFO - 2018-03-20 12:05:59 --> Model Class Initialized
INFO - 2018-03-20 12:05:59 --> Model Class Initialized
INFO - 2018-03-20 12:05:59 --> Model Class Initialized
INFO - 2018-03-20 12:05:59 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-20 12:05:59 --> Model Class Initialized
DEBUG - 2018-03-20 12:05:59 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 12:05:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 12:05:59 --> Helper loaded: permission_helper
INFO - 2018-03-20 12:05:59 --> Database Driver Class Initialized
INFO - 2018-03-20 12:05:59 --> Model Class Initialized
INFO - 2018-03-20 12:05:59 --> Model Class Initialized
DEBUG - 2018-03-20 12:05:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 12:05:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 12:05:59 --> Model Class Initialized
INFO - 2018-03-20 12:05:59 --> Final output sent to browser
DEBUG - 2018-03-20 12:05:59 --> Total execution time: 0.4933
INFO - 2018-03-20 12:05:59 --> Model Class Initialized
INFO - 2018-03-20 12:05:59 --> Model Class Initialized
INFO - 2018-03-20 12:05:59 --> Model Class Initialized
INFO - 2018-03-20 12:05:59 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-20 12:05:59 --> Helper loaded: form_helper
INFO - 2018-03-20 12:05:59 --> Form Validation Class Initialized
INFO - 2018-03-20 12:05:59 --> Controller Class Initialized
INFO - 2018-03-20 12:05:59 --> Model Class Initialized
INFO - 2018-03-20 12:05:59 --> Final output sent to browser
DEBUG - 2018-03-20 12:05:59 --> Total execution time: 2.0758
INFO - 2018-03-20 12:05:59 --> Model Class Initialized
INFO - 2018-03-20 12:05:59 --> Helper loaded: inflector_helper
DEBUG - 2018-03-20 12:05:59 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 12:05:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 12:05:59 --> Model Class Initialized
INFO - 2018-03-20 12:05:59 --> Model Class Initialized
INFO - 2018-03-20 12:05:59 --> Model Class Initialized
INFO - 2018-03-20 12:05:59 --> Model Class Initialized
INFO - 2018-03-20 12:05:59 --> Model Class Initialized
INFO - 2018-03-20 12:05:59 --> Model Class Initialized
INFO - 2018-03-20 12:05:59 --> Model Class Initialized
INFO - 2018-03-20 12:05:59 --> Model Class Initialized
INFO - 2018-03-20 12:05:59 --> Model Class Initialized
INFO - 2018-03-20 12:05:59 --> Model Class Initialized
INFO - 2018-03-20 12:05:59 --> Model Class Initialized
INFO - 2018-03-20 12:05:59 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-20 12:05:59 --> Model Class Initialized
INFO - 2018-03-20 12:05:59 --> Helper loaded: users_helper
INFO - 2018-03-20 12:05:59 --> Final output sent to browser
DEBUG - 2018-03-20 12:05:59 --> Total execution time: 1.9076
INFO - 2018-03-20 06:36:00 --> Config Class Initialized
INFO - 2018-03-20 06:36:00 --> Hooks Class Initialized
INFO - 2018-03-20 06:36:00 --> Config Class Initialized
INFO - 2018-03-20 06:36:00 --> Hooks Class Initialized
DEBUG - 2018-03-20 06:36:00 --> UTF-8 Support Enabled
INFO - 2018-03-20 06:36:00 --> Utf8 Class Initialized
DEBUG - 2018-03-20 06:36:00 --> UTF-8 Support Enabled
INFO - 2018-03-20 06:36:00 --> Utf8 Class Initialized
INFO - 2018-03-20 06:36:00 --> URI Class Initialized
INFO - 2018-03-20 06:36:00 --> URI Class Initialized
INFO - 2018-03-20 06:36:00 --> Router Class Initialized
INFO - 2018-03-20 06:36:00 --> Output Class Initialized
INFO - 2018-03-20 06:36:00 --> Router Class Initialized
INFO - 2018-03-20 06:36:00 --> Security Class Initialized
DEBUG - 2018-03-20 06:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 06:36:00 --> Input Class Initialized
INFO - 2018-03-20 06:36:00 --> Language Class Initialized
INFO - 2018-03-20 06:36:00 --> Output Class Initialized
INFO - 2018-03-20 06:36:00 --> Security Class Initialized
DEBUG - 2018-03-20 06:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 06:36:00 --> Input Class Initialized
INFO - 2018-03-20 06:36:00 --> Language Class Initialized
INFO - 2018-03-20 12:06:00 --> Database Driver Class Initialized
INFO - 2018-03-20 06:36:00 --> Language Class Initialized
INFO - 2018-03-20 06:36:00 --> Config Class Initialized
INFO - 2018-03-20 06:36:00 --> Loader Class Initialized
INFO - 2018-03-20 12:06:00 --> Helper loaded: url_helper
INFO - 2018-03-20 12:06:00 --> Helper loaded: notification_helper
INFO - 2018-03-20 12:06:00 --> Helper loaded: settings_helper
INFO - 2018-03-20 12:06:00 --> Helper loaded: permission_helper
INFO - 2018-03-20 12:06:00 --> Helper loaded: users_helper
DEBUG - 2018-03-20 12:06:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 12:06:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 12:06:00 --> Helper loaded: form_helper
INFO - 2018-03-20 12:06:00 --> Form Validation Class Initialized
INFO - 2018-03-20 12:06:00 --> Controller Class Initialized
INFO - 2018-03-20 12:06:00 --> Database Driver Class Initialized
INFO - 2018-03-20 12:06:00 --> Model Class Initialized
INFO - 2018-03-20 12:06:00 --> Helper loaded: inflector_helper
DEBUG - 2018-03-20 12:06:00 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 12:06:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 12:06:00 --> Model Class Initialized
INFO - 2018-03-20 12:06:00 --> Model Class Initialized
INFO - 2018-03-20 12:06:00 --> Model Class Initialized
INFO - 2018-03-20 12:06:00 --> Model Class Initialized
INFO - 2018-03-20 12:06:00 --> Model Class Initialized
INFO - 2018-03-20 12:06:00 --> Model Class Initialized
INFO - 2018-03-20 12:06:00 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-20 12:06:00 --> Final output sent to browser
DEBUG - 2018-03-20 12:06:00 --> Total execution time: 2.9686
DEBUG - 2018-03-20 12:06:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 12:06:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 06:36:00 --> Language Class Initialized
INFO - 2018-03-20 06:36:00 --> Config Class Initialized
INFO - 2018-03-20 06:36:00 --> Loader Class Initialized
INFO - 2018-03-20 12:06:00 --> Helper loaded: form_helper
INFO - 2018-03-20 12:06:00 --> Form Validation Class Initialized
INFO - 2018-03-20 12:06:00 --> Helper loaded: url_helper
INFO - 2018-03-20 12:06:00 --> Controller Class Initialized
INFO - 2018-03-20 12:06:00 --> Helper loaded: notification_helper
INFO - 2018-03-20 12:06:00 --> Helper loaded: settings_helper
INFO - 2018-03-20 12:06:00 --> Helper loaded: permission_helper
INFO - 2018-03-20 12:06:00 --> Helper loaded: users_helper
INFO - 2018-03-20 12:06:00 --> Model Class Initialized
INFO - 2018-03-20 12:06:00 --> Helper loaded: inflector_helper
DEBUG - 2018-03-20 12:06:00 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 12:06:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 12:06:00 --> Model Class Initialized
INFO - 2018-03-20 12:06:00 --> Model Class Initialized
INFO - 2018-03-20 12:06:00 --> Model Class Initialized
INFO - 2018-03-20 12:06:00 --> Model Class Initialized
INFO - 2018-03-20 12:06:00 --> Model Class Initialized
INFO - 2018-03-20 12:06:00 --> Model Class Initialized
INFO - 2018-03-20 12:06:00 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-20 12:06:00 --> Model Class Initialized
INFO - 2018-03-20 12:06:00 --> Final output sent to browser
DEBUG - 2018-03-20 12:06:00 --> Total execution time: 0.3428
INFO - 2018-03-20 12:06:00 --> Database Driver Class Initialized
DEBUG - 2018-03-20 12:06:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 12:06:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 12:06:00 --> Helper loaded: form_helper
INFO - 2018-03-20 12:06:00 --> Form Validation Class Initialized
INFO - 2018-03-20 12:06:00 --> Controller Class Initialized
INFO - 2018-03-20 12:06:00 --> Model Class Initialized
INFO - 2018-03-20 12:06:00 --> Helper loaded: inflector_helper
DEBUG - 2018-03-20 12:06:00 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 12:06:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 12:06:00 --> Model Class Initialized
INFO - 2018-03-20 12:06:00 --> Model Class Initialized
INFO - 2018-03-20 12:06:00 --> Model Class Initialized
INFO - 2018-03-20 12:06:00 --> Model Class Initialized
INFO - 2018-03-20 12:06:01 --> Model Class Initialized
INFO - 2018-03-20 12:06:01 --> Model Class Initialized
INFO - 2018-03-20 12:06:01 --> Model Class Initialized
INFO - 2018-03-20 12:06:01 --> Model Class Initialized
INFO - 2018-03-20 12:06:01 --> Model Class Initialized
INFO - 2018-03-20 12:06:01 --> Model Class Initialized
INFO - 2018-03-20 06:36:01 --> Config Class Initialized
INFO - 2018-03-20 06:36:01 --> Hooks Class Initialized
INFO - 2018-03-20 12:06:01 --> Model Class Initialized
INFO - 2018-03-20 12:06:01 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-20 12:06:01 --> Model Class Initialized
DEBUG - 2018-03-20 06:36:01 --> UTF-8 Support Enabled
INFO - 2018-03-20 06:36:01 --> Utf8 Class Initialized
INFO - 2018-03-20 06:36:01 --> URI Class Initialized
INFO - 2018-03-20 06:36:01 --> Router Class Initialized
INFO - 2018-03-20 06:36:02 --> Output Class Initialized
INFO - 2018-03-20 06:36:02 --> Config Class Initialized
INFO - 2018-03-20 06:36:02 --> Hooks Class Initialized
INFO - 2018-03-20 06:36:02 --> Security Class Initialized
DEBUG - 2018-03-20 06:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 06:36:02 --> Input Class Initialized
INFO - 2018-03-20 12:06:02 --> Final output sent to browser
DEBUG - 2018-03-20 12:06:02 --> Total execution time: 2.0302
DEBUG - 2018-03-20 06:36:02 --> UTF-8 Support Enabled
INFO - 2018-03-20 06:36:02 --> Utf8 Class Initialized
INFO - 2018-03-20 06:36:02 --> Language Class Initialized
INFO - 2018-03-20 06:36:02 --> URI Class Initialized
INFO - 2018-03-20 06:36:02 --> Router Class Initialized
INFO - 2018-03-20 06:36:03 --> Output Class Initialized
INFO - 2018-03-20 06:36:03 --> Security Class Initialized
DEBUG - 2018-03-20 06:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 06:36:03 --> Input Class Initialized
INFO - 2018-03-20 06:36:03 --> Language Class Initialized
INFO - 2018-03-20 06:36:04 --> Language Class Initialized
INFO - 2018-03-20 06:36:04 --> Config Class Initialized
INFO - 2018-03-20 06:36:04 --> Loader Class Initialized
INFO - 2018-03-20 12:06:04 --> Helper loaded: url_helper
INFO - 2018-03-20 12:06:04 --> Helper loaded: notification_helper
INFO - 2018-03-20 12:06:04 --> Helper loaded: settings_helper
INFO - 2018-03-20 12:06:04 --> Helper loaded: permission_helper
INFO - 2018-03-20 12:06:04 --> Helper loaded: users_helper
INFO - 2018-03-20 06:36:04 --> Language Class Initialized
INFO - 2018-03-20 06:36:04 --> Config Class Initialized
INFO - 2018-03-20 06:36:04 --> Loader Class Initialized
INFO - 2018-03-20 12:06:05 --> Helper loaded: url_helper
INFO - 2018-03-20 12:06:05 --> Helper loaded: notification_helper
INFO - 2018-03-20 12:06:05 --> Helper loaded: settings_helper
INFO - 2018-03-20 12:06:05 --> Helper loaded: permission_helper
INFO - 2018-03-20 12:06:05 --> Helper loaded: users_helper
INFO - 2018-03-20 12:06:05 --> Database Driver Class Initialized
DEBUG - 2018-03-20 12:06:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 12:06:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 12:06:05 --> Helper loaded: form_helper
INFO - 2018-03-20 12:06:05 --> Form Validation Class Initialized
INFO - 2018-03-20 12:06:05 --> Controller Class Initialized
INFO - 2018-03-20 12:06:05 --> Model Class Initialized
INFO - 2018-03-20 12:06:05 --> Helper loaded: inflector_helper
DEBUG - 2018-03-20 12:06:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 12:06:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 12:06:05 --> Model Class Initialized
INFO - 2018-03-20 12:06:05 --> Model Class Initialized
INFO - 2018-03-20 12:06:05 --> Model Class Initialized
INFO - 2018-03-20 12:06:05 --> Model Class Initialized
INFO - 2018-03-20 12:06:05 --> Model Class Initialized
INFO - 2018-03-20 12:06:05 --> Model Class Initialized
INFO - 2018-03-20 12:06:05 --> Model Class Initialized
INFO - 2018-03-20 12:06:05 --> Model Class Initialized
INFO - 2018-03-20 12:06:05 --> Model Class Initialized
INFO - 2018-03-20 12:06:05 --> Model Class Initialized
INFO - 2018-03-20 12:06:05 --> Model Class Initialized
INFO - 2018-03-20 12:06:05 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-20 12:06:05 --> Model Class Initialized
INFO - 2018-03-20 12:06:05 --> Final output sent to browser
DEBUG - 2018-03-20 12:06:05 --> Total execution time: 4.2983
INFO - 2018-03-20 12:06:06 --> Database Driver Class Initialized
DEBUG - 2018-03-20 12:06:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 12:06:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 12:06:06 --> Helper loaded: form_helper
INFO - 2018-03-20 12:06:06 --> Form Validation Class Initialized
INFO - 2018-03-20 12:06:06 --> Controller Class Initialized
INFO - 2018-03-20 12:06:06 --> Model Class Initialized
INFO - 2018-03-20 12:06:06 --> Helper loaded: inflector_helper
DEBUG - 2018-03-20 12:06:06 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 12:06:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 12:06:06 --> Model Class Initialized
INFO - 2018-03-20 12:06:06 --> Model Class Initialized
INFO - 2018-03-20 12:06:06 --> Model Class Initialized
INFO - 2018-03-20 12:06:06 --> Model Class Initialized
INFO - 2018-03-20 12:06:06 --> Model Class Initialized
INFO - 2018-03-20 12:06:06 --> Model Class Initialized
INFO - 2018-03-20 12:06:06 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-20 12:06:06 --> Final output sent to browser
DEBUG - 2018-03-20 12:06:06 --> Total execution time: 4.4057
INFO - 2018-03-20 06:36:13 --> Config Class Initialized
INFO - 2018-03-20 06:36:13 --> Hooks Class Initialized
DEBUG - 2018-03-20 06:36:13 --> UTF-8 Support Enabled
INFO - 2018-03-20 06:36:13 --> Utf8 Class Initialized
INFO - 2018-03-20 06:36:13 --> URI Class Initialized
INFO - 2018-03-20 06:36:13 --> Router Class Initialized
INFO - 2018-03-20 06:36:13 --> Output Class Initialized
INFO - 2018-03-20 06:36:13 --> Security Class Initialized
DEBUG - 2018-03-20 06:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 06:36:13 --> Input Class Initialized
INFO - 2018-03-20 06:36:13 --> Language Class Initialized
INFO - 2018-03-20 06:36:13 --> Language Class Initialized
INFO - 2018-03-20 06:36:13 --> Config Class Initialized
INFO - 2018-03-20 06:36:13 --> Loader Class Initialized
INFO - 2018-03-20 12:06:13 --> Helper loaded: url_helper
INFO - 2018-03-20 12:06:13 --> Helper loaded: notification_helper
INFO - 2018-03-20 12:06:13 --> Helper loaded: settings_helper
INFO - 2018-03-20 12:06:13 --> Helper loaded: permission_helper
INFO - 2018-03-20 12:06:13 --> Helper loaded: users_helper
INFO - 2018-03-20 12:06:13 --> Database Driver Class Initialized
DEBUG - 2018-03-20 12:06:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 12:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 12:06:13 --> Helper loaded: form_helper
INFO - 2018-03-20 12:06:13 --> Form Validation Class Initialized
INFO - 2018-03-20 12:06:13 --> Controller Class Initialized
INFO - 2018-03-20 12:06:13 --> Model Class Initialized
INFO - 2018-03-20 12:06:13 --> Helper loaded: inflector_helper
DEBUG - 2018-03-20 12:06:13 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 12:06:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 12:06:13 --> Model Class Initialized
INFO - 2018-03-20 12:06:13 --> Model Class Initialized
INFO - 2018-03-20 12:06:13 --> Model Class Initialized
INFO - 2018-03-20 12:06:13 --> Model Class Initialized
INFO - 2018-03-20 12:06:13 --> Model Class Initialized
INFO - 2018-03-20 12:06:13 --> Model Class Initialized
INFO - 2018-03-20 12:06:13 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-20 12:06:13 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-03-20 12:06:13 --> Final output sent to browser
DEBUG - 2018-03-20 12:06:13 --> Total execution time: 0.2371
INFO - 2018-03-20 06:36:14 --> Config Class Initialized
INFO - 2018-03-20 06:36:14 --> Hooks Class Initialized
DEBUG - 2018-03-20 06:36:14 --> UTF-8 Support Enabled
INFO - 2018-03-20 06:36:14 --> Utf8 Class Initialized
INFO - 2018-03-20 06:36:14 --> URI Class Initialized
INFO - 2018-03-20 06:36:14 --> Router Class Initialized
INFO - 2018-03-20 06:36:14 --> Output Class Initialized
INFO - 2018-03-20 06:36:14 --> Security Class Initialized
DEBUG - 2018-03-20 06:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 06:36:14 --> Input Class Initialized
INFO - 2018-03-20 06:36:14 --> Language Class Initialized
INFO - 2018-03-20 06:36:14 --> Config Class Initialized
INFO - 2018-03-20 06:36:14 --> Hooks Class Initialized
DEBUG - 2018-03-20 06:36:14 --> UTF-8 Support Enabled
INFO - 2018-03-20 06:36:14 --> Utf8 Class Initialized
INFO - 2018-03-20 06:36:14 --> URI Class Initialized
INFO - 2018-03-20 06:36:15 --> Router Class Initialized
INFO - 2018-03-20 06:36:15 --> Output Class Initialized
INFO - 2018-03-20 06:36:15 --> Language Class Initialized
INFO - 2018-03-20 06:36:15 --> Config Class Initialized
INFO - 2018-03-20 06:36:15 --> Loader Class Initialized
INFO - 2018-03-20 06:36:15 --> Security Class Initialized
INFO - 2018-03-20 12:06:15 --> Helper loaded: url_helper
INFO - 2018-03-20 12:06:15 --> Helper loaded: notification_helper
INFO - 2018-03-20 12:06:15 --> Helper loaded: settings_helper
DEBUG - 2018-03-20 06:36:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 06:36:15 --> Input Class Initialized
INFO - 2018-03-20 12:06:15 --> Helper loaded: permission_helper
INFO - 2018-03-20 06:36:15 --> Language Class Initialized
INFO - 2018-03-20 12:06:15 --> Helper loaded: users_helper
INFO - 2018-03-20 06:36:15 --> Language Class Initialized
INFO - 2018-03-20 06:36:15 --> Config Class Initialized
INFO - 2018-03-20 06:36:15 --> Loader Class Initialized
INFO - 2018-03-20 12:06:15 --> Database Driver Class Initialized
INFO - 2018-03-20 12:06:15 --> Helper loaded: url_helper
DEBUG - 2018-03-20 12:06:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 12:06:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 12:06:15 --> Helper loaded: notification_helper
INFO - 2018-03-20 12:06:15 --> Helper loaded: settings_helper
INFO - 2018-03-20 12:06:15 --> Helper loaded: form_helper
INFO - 2018-03-20 12:06:15 --> Form Validation Class Initialized
INFO - 2018-03-20 12:06:15 --> Controller Class Initialized
INFO - 2018-03-20 12:06:15 --> Helper loaded: permission_helper
INFO - 2018-03-20 12:06:15 --> Helper loaded: users_helper
INFO - 2018-03-20 12:06:15 --> Database Driver Class Initialized
DEBUG - 2018-03-20 12:06:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 12:06:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 12:06:15 --> Helper loaded: form_helper
INFO - 2018-03-20 12:06:15 --> Form Validation Class Initialized
INFO - 2018-03-20 12:06:15 --> Controller Class Initialized
INFO - 2018-03-20 12:06:15 --> Model Class Initialized
INFO - 2018-03-20 12:06:15 --> Helper loaded: inflector_helper
DEBUG - 2018-03-20 12:06:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 12:06:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 12:06:15 --> Model Class Initialized
INFO - 2018-03-20 12:06:15 --> Model Class Initialized
INFO - 2018-03-20 12:06:15 --> Model Class Initialized
INFO - 2018-03-20 12:06:15 --> Model Class Initialized
INFO - 2018-03-20 12:06:15 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-20 12:06:15 --> Final output sent to browser
DEBUG - 2018-03-20 12:06:15 --> Total execution time: 1.5619
INFO - 2018-03-20 12:06:16 --> Model Class Initialized
INFO - 2018-03-20 12:06:16 --> Helper loaded: inflector_helper
INFO - 2018-03-20 06:36:16 --> Config Class Initialized
INFO - 2018-03-20 06:36:16 --> Hooks Class Initialized
DEBUG - 2018-03-20 06:36:16 --> UTF-8 Support Enabled
INFO - 2018-03-20 06:36:16 --> Utf8 Class Initialized
INFO - 2018-03-20 06:36:16 --> URI Class Initialized
INFO - 2018-03-20 06:36:16 --> Router Class Initialized
INFO - 2018-03-20 06:36:16 --> Output Class Initialized
INFO - 2018-03-20 06:36:16 --> Security Class Initialized
DEBUG - 2018-03-20 06:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 06:36:16 --> Input Class Initialized
INFO - 2018-03-20 06:36:16 --> Language Class Initialized
DEBUG - 2018-03-20 12:06:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 06:36:16 --> Language Class Initialized
INFO - 2018-03-20 06:36:16 --> Config Class Initialized
INFO - 2018-03-20 06:36:16 --> Loader Class Initialized
INFO - 2018-03-20 12:06:16 --> Helper loaded: url_helper
INFO - 2018-03-20 12:06:16 --> Helper loaded: notification_helper
INFO - 2018-03-20 12:06:16 --> Helper loaded: settings_helper
INFO - 2018-03-20 12:06:16 --> Helper loaded: permission_helper
INFO - 2018-03-20 12:06:16 --> Helper loaded: users_helper
INFO - 2018-03-20 12:06:16 --> Database Driver Class Initialized
DEBUG - 2018-03-20 12:06:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 12:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 12:06:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 06:36:16 --> Config Class Initialized
INFO - 2018-03-20 06:36:16 --> Hooks Class Initialized
INFO - 2018-03-20 12:06:16 --> Helper loaded: form_helper
INFO - 2018-03-20 12:06:16 --> Form Validation Class Initialized
INFO - 2018-03-20 12:06:16 --> Controller Class Initialized
DEBUG - 2018-03-20 06:36:16 --> UTF-8 Support Enabled
INFO - 2018-03-20 06:36:16 --> Utf8 Class Initialized
INFO - 2018-03-20 12:06:16 --> Model Class Initialized
INFO - 2018-03-20 12:06:16 --> Helper loaded: inflector_helper
DEBUG - 2018-03-20 12:06:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 12:06:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 12:06:16 --> Model Class Initialized
INFO - 2018-03-20 12:06:16 --> Model Class Initialized
INFO - 2018-03-20 12:06:16 --> Model Class Initialized
INFO - 2018-03-20 12:06:16 --> Model Class Initialized
INFO - 2018-03-20 12:06:16 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-20 12:06:16 --> Final output sent to browser
DEBUG - 2018-03-20 12:06:16 --> Total execution time: 0.4473
INFO - 2018-03-20 06:36:16 --> URI Class Initialized
INFO - 2018-03-20 12:06:16 --> Model Class Initialized
INFO - 2018-03-20 12:06:16 --> Model Class Initialized
INFO - 2018-03-20 12:06:16 --> Model Class Initialized
INFO - 2018-03-20 12:06:16 --> Model Class Initialized
INFO - 2018-03-20 06:36:16 --> Router Class Initialized
INFO - 2018-03-20 12:06:17 --> Model Class Initialized
INFO - 2018-03-20 12:06:17 --> Model Class Initialized
INFO - 2018-03-20 06:36:17 --> Output Class Initialized
INFO - 2018-03-20 12:06:17 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-20 12:06:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-03-20 12:06:17 --> Final output sent to browser
DEBUG - 2018-03-20 12:06:17 --> Total execution time: 3.2811
INFO - 2018-03-20 06:36:17 --> Security Class Initialized
DEBUG - 2018-03-20 06:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 06:36:17 --> Input Class Initialized
INFO - 2018-03-20 06:36:17 --> Language Class Initialized
INFO - 2018-03-20 06:36:17 --> Language Class Initialized
INFO - 2018-03-20 06:36:17 --> Config Class Initialized
INFO - 2018-03-20 06:36:17 --> Loader Class Initialized
INFO - 2018-03-20 12:06:17 --> Helper loaded: url_helper
INFO - 2018-03-20 12:06:17 --> Helper loaded: notification_helper
INFO - 2018-03-20 12:06:17 --> Helper loaded: settings_helper
INFO - 2018-03-20 12:06:17 --> Helper loaded: permission_helper
INFO - 2018-03-20 12:06:17 --> Helper loaded: users_helper
INFO - 2018-03-20 12:06:17 --> Database Driver Class Initialized
DEBUG - 2018-03-20 12:06:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 12:06:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 12:06:18 --> Helper loaded: form_helper
INFO - 2018-03-20 12:06:18 --> Form Validation Class Initialized
INFO - 2018-03-20 12:06:18 --> Controller Class Initialized
INFO - 2018-03-20 12:06:18 --> Model Class Initialized
INFO - 2018-03-20 12:06:18 --> Helper loaded: inflector_helper
DEBUG - 2018-03-20 12:06:18 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 12:06:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 12:06:19 --> Model Class Initialized
INFO - 2018-03-20 12:06:19 --> Model Class Initialized
INFO - 2018-03-20 12:06:19 --> Model Class Initialized
INFO - 2018-03-20 12:06:19 --> Model Class Initialized
INFO - 2018-03-20 12:06:19 --> Model Class Initialized
INFO - 2018-03-20 12:06:19 --> Model Class Initialized
INFO - 2018-03-20 12:06:19 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-20 12:06:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-03-20 12:06:19 --> Final output sent to browser
DEBUG - 2018-03-20 12:06:19 --> Total execution time: 2.8433
INFO - 2018-03-20 06:36:21 --> Config Class Initialized
INFO - 2018-03-20 06:36:21 --> Hooks Class Initialized
DEBUG - 2018-03-20 06:36:21 --> UTF-8 Support Enabled
INFO - 2018-03-20 06:36:21 --> Utf8 Class Initialized
INFO - 2018-03-20 06:36:21 --> URI Class Initialized
INFO - 2018-03-20 06:36:21 --> Router Class Initialized
INFO - 2018-03-20 06:36:21 --> Output Class Initialized
INFO - 2018-03-20 06:36:21 --> Security Class Initialized
DEBUG - 2018-03-20 06:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 06:36:21 --> Input Class Initialized
INFO - 2018-03-20 06:36:21 --> Language Class Initialized
INFO - 2018-03-20 06:36:21 --> Language Class Initialized
INFO - 2018-03-20 06:36:21 --> Config Class Initialized
INFO - 2018-03-20 06:36:21 --> Loader Class Initialized
INFO - 2018-03-20 12:06:21 --> Helper loaded: url_helper
INFO - 2018-03-20 12:06:21 --> Helper loaded: notification_helper
INFO - 2018-03-20 12:06:21 --> Helper loaded: settings_helper
INFO - 2018-03-20 12:06:21 --> Helper loaded: permission_helper
INFO - 2018-03-20 12:06:21 --> Helper loaded: users_helper
INFO - 2018-03-20 12:06:21 --> Database Driver Class Initialized
DEBUG - 2018-03-20 12:06:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 12:06:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 12:06:21 --> Helper loaded: form_helper
INFO - 2018-03-20 12:06:21 --> Form Validation Class Initialized
INFO - 2018-03-20 12:06:21 --> Controller Class Initialized
INFO - 2018-03-20 06:36:21 --> Config Class Initialized
INFO - 2018-03-20 06:36:21 --> Hooks Class Initialized
DEBUG - 2018-03-20 06:36:21 --> UTF-8 Support Enabled
INFO - 2018-03-20 06:36:21 --> Utf8 Class Initialized
INFO - 2018-03-20 06:36:21 --> URI Class Initialized
INFO - 2018-03-20 06:36:21 --> Router Class Initialized
INFO - 2018-03-20 06:36:21 --> Output Class Initialized
INFO - 2018-03-20 12:06:21 --> Model Class Initialized
INFO - 2018-03-20 12:06:21 --> Helper loaded: inflector_helper
INFO - 2018-03-20 06:36:21 --> Security Class Initialized
DEBUG - 2018-03-20 06:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 06:36:21 --> Input Class Initialized
INFO - 2018-03-20 06:36:21 --> Language Class Initialized
DEBUG - 2018-03-20 12:06:21 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 12:06:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 12:06:21 --> Model Class Initialized
INFO - 2018-03-20 12:06:21 --> Model Class Initialized
INFO - 2018-03-20 12:06:21 --> Model Class Initialized
INFO - 2018-03-20 12:06:21 --> Model Class Initialized
INFO - 2018-03-20 12:06:21 --> Model Class Initialized
INFO - 2018-03-20 12:06:21 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-20 12:06:21 --> Model Class Initialized
INFO - 2018-03-20 06:36:21 --> Language Class Initialized
INFO - 2018-03-20 06:36:21 --> Config Class Initialized
INFO - 2018-03-20 06:36:21 --> Loader Class Initialized
INFO - 2018-03-20 12:06:21 --> Helper loaded: url_helper
INFO - 2018-03-20 12:06:21 --> Helper loaded: notification_helper
INFO - 2018-03-20 12:06:21 --> Helper loaded: settings_helper
INFO - 2018-03-20 12:06:21 --> Final output sent to browser
DEBUG - 2018-03-20 12:06:21 --> Total execution time: 0.1709
INFO - 2018-03-20 12:06:21 --> Helper loaded: permission_helper
INFO - 2018-03-20 12:06:21 --> Helper loaded: users_helper
INFO - 2018-03-20 12:06:21 --> Database Driver Class Initialized
DEBUG - 2018-03-20 12:06:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 12:06:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 12:06:21 --> Helper loaded: form_helper
INFO - 2018-03-20 12:06:21 --> Form Validation Class Initialized
INFO - 2018-03-20 12:06:21 --> Controller Class Initialized
INFO - 2018-03-20 12:06:21 --> Model Class Initialized
INFO - 2018-03-20 12:06:21 --> Helper loaded: inflector_helper
DEBUG - 2018-03-20 12:06:21 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 12:06:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 12:06:21 --> Model Class Initialized
INFO - 2018-03-20 12:06:21 --> Model Class Initialized
INFO - 2018-03-20 12:06:21 --> Model Class Initialized
INFO - 2018-03-20 12:06:21 --> Model Class Initialized
INFO - 2018-03-20 12:06:21 --> Model Class Initialized
INFO - 2018-03-20 12:06:21 --> Model Class Initialized
INFO - 2018-03-20 12:06:21 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-20 12:06:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-03-20 12:06:21 --> Final output sent to browser
DEBUG - 2018-03-20 12:06:21 --> Total execution time: 0.1080
INFO - 2018-03-20 06:38:25 --> Config Class Initialized
INFO - 2018-03-20 06:38:25 --> Hooks Class Initialized
DEBUG - 2018-03-20 06:38:25 --> UTF-8 Support Enabled
INFO - 2018-03-20 06:38:25 --> Utf8 Class Initialized
INFO - 2018-03-20 06:38:25 --> URI Class Initialized
INFO - 2018-03-20 06:38:25 --> Router Class Initialized
INFO - 2018-03-20 06:38:25 --> Output Class Initialized
INFO - 2018-03-20 06:38:25 --> Security Class Initialized
DEBUG - 2018-03-20 06:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 06:38:25 --> Input Class Initialized
INFO - 2018-03-20 06:38:25 --> Language Class Initialized
INFO - 2018-03-20 06:38:25 --> Language Class Initialized
INFO - 2018-03-20 06:38:25 --> Config Class Initialized
INFO - 2018-03-20 06:38:25 --> Loader Class Initialized
INFO - 2018-03-20 12:08:25 --> Helper loaded: url_helper
INFO - 2018-03-20 12:08:25 --> Helper loaded: notification_helper
INFO - 2018-03-20 12:08:25 --> Helper loaded: settings_helper
INFO - 2018-03-20 12:08:25 --> Helper loaded: permission_helper
INFO - 2018-03-20 12:08:25 --> Helper loaded: users_helper
INFO - 2018-03-20 12:08:25 --> Database Driver Class Initialized
DEBUG - 2018-03-20 12:08:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 12:08:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 12:08:25 --> Helper loaded: form_helper
INFO - 2018-03-20 12:08:25 --> Form Validation Class Initialized
INFO - 2018-03-20 12:08:25 --> Controller Class Initialized
INFO - 2018-03-20 12:08:25 --> Model Class Initialized
INFO - 2018-03-20 12:08:25 --> Helper loaded: inflector_helper
DEBUG - 2018-03-20 12:08:25 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 12:08:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 12:08:25 --> Model Class Initialized
INFO - 2018-03-20 12:08:25 --> Model Class Initialized
INFO - 2018-03-20 12:08:25 --> Model Class Initialized
INFO - 2018-03-20 12:08:25 --> Model Class Initialized
INFO - 2018-03-20 12:08:25 --> Model Class Initialized
INFO - 2018-03-20 12:08:25 --> Model Class Initialized
INFO - 2018-03-20 12:08:25 --> Model Class Initialized
INFO - 2018-03-20 12:08:25 --> Model Class Initialized
INFO - 2018-03-20 12:08:25 --> Model Class Initialized
INFO - 2018-03-20 12:08:25 --> Model Class Initialized
INFO - 2018-03-20 12:08:25 --> Model Class Initialized
INFO - 2018-03-20 12:08:25 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-20 12:08:25 --> Model Class Initialized
INFO - 2018-03-20 06:38:25 --> Config Class Initialized
INFO - 2018-03-20 06:38:25 --> Hooks Class Initialized
DEBUG - 2018-03-20 06:38:25 --> UTF-8 Support Enabled
INFO - 2018-03-20 06:38:25 --> Utf8 Class Initialized
INFO - 2018-03-20 06:38:25 --> URI Class Initialized
INFO - 2018-03-20 06:38:25 --> Router Class Initialized
INFO - 2018-03-20 06:38:25 --> Output Class Initialized
INFO - 2018-03-20 06:38:25 --> Security Class Initialized
DEBUG - 2018-03-20 06:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 06:38:25 --> Input Class Initialized
INFO - 2018-03-20 06:38:25 --> Language Class Initialized
INFO - 2018-03-20 06:38:25 --> Language Class Initialized
INFO - 2018-03-20 06:38:25 --> Config Class Initialized
INFO - 2018-03-20 06:38:25 --> Loader Class Initialized
INFO - 2018-03-20 12:08:25 --> Helper loaded: url_helper
INFO - 2018-03-20 12:08:25 --> Helper loaded: notification_helper
INFO - 2018-03-20 12:08:25 --> Helper loaded: settings_helper
INFO - 2018-03-20 12:08:25 --> Final output sent to browser
INFO - 2018-03-20 12:08:25 --> Helper loaded: permission_helper
DEBUG - 2018-03-20 12:08:25 --> Total execution time: 0.1616
INFO - 2018-03-20 12:08:25 --> Helper loaded: users_helper
INFO - 2018-03-20 12:08:25 --> Database Driver Class Initialized
DEBUG - 2018-03-20 12:08:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 12:08:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 12:08:25 --> Helper loaded: form_helper
INFO - 2018-03-20 12:08:25 --> Form Validation Class Initialized
INFO - 2018-03-20 12:08:25 --> Controller Class Initialized
INFO - 2018-03-20 12:08:25 --> Model Class Initialized
INFO - 2018-03-20 12:08:25 --> Helper loaded: inflector_helper
DEBUG - 2018-03-20 12:08:25 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 12:08:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 12:08:25 --> Model Class Initialized
INFO - 2018-03-20 12:08:25 --> Model Class Initialized
INFO - 2018-03-20 12:08:25 --> Model Class Initialized
INFO - 2018-03-20 12:08:25 --> Model Class Initialized
INFO - 2018-03-20 12:08:25 --> Model Class Initialized
INFO - 2018-03-20 12:08:25 --> Model Class Initialized
INFO - 2018-03-20 12:08:25 --> Model Class Initialized
INFO - 2018-03-20 12:08:25 --> Model Class Initialized
INFO - 2018-03-20 12:08:25 --> Model Class Initialized
INFO - 2018-03-20 12:08:25 --> Model Class Initialized
INFO - 2018-03-20 12:08:25 --> Model Class Initialized
INFO - 2018-03-20 12:08:25 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-20 12:08:25 --> Model Class Initialized
INFO - 2018-03-20 12:08:25 --> Final output sent to browser
DEBUG - 2018-03-20 12:08:25 --> Total execution time: 0.1324
INFO - 2018-03-20 06:38:25 --> Config Class Initialized
INFO - 2018-03-20 06:38:25 --> Hooks Class Initialized
INFO - 2018-03-20 06:38:25 --> Config Class Initialized
INFO - 2018-03-20 06:38:25 --> Hooks Class Initialized
DEBUG - 2018-03-20 06:38:25 --> UTF-8 Support Enabled
INFO - 2018-03-20 06:38:25 --> Utf8 Class Initialized
INFO - 2018-03-20 06:38:25 --> URI Class Initialized
INFO - 2018-03-20 06:38:25 --> Router Class Initialized
INFO - 2018-03-20 06:38:25 --> Output Class Initialized
INFO - 2018-03-20 06:38:25 --> Security Class Initialized
DEBUG - 2018-03-20 06:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 06:38:25 --> Input Class Initialized
INFO - 2018-03-20 06:38:25 --> Language Class Initialized
INFO - 2018-03-20 06:38:25 --> Language Class Initialized
INFO - 2018-03-20 06:38:25 --> Config Class Initialized
INFO - 2018-03-20 06:38:25 --> Loader Class Initialized
INFO - 2018-03-20 12:08:25 --> Helper loaded: url_helper
INFO - 2018-03-20 12:08:25 --> Helper loaded: notification_helper
INFO - 2018-03-20 12:08:25 --> Helper loaded: settings_helper
INFO - 2018-03-20 12:08:25 --> Helper loaded: permission_helper
INFO - 2018-03-20 12:08:25 --> Helper loaded: users_helper
INFO - 2018-03-20 12:08:25 --> Database Driver Class Initialized
DEBUG - 2018-03-20 12:08:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 12:08:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 12:08:25 --> Helper loaded: form_helper
INFO - 2018-03-20 12:08:25 --> Form Validation Class Initialized
INFO - 2018-03-20 12:08:25 --> Controller Class Initialized
INFO - 2018-03-20 12:08:25 --> Model Class Initialized
INFO - 2018-03-20 12:08:25 --> Helper loaded: inflector_helper
DEBUG - 2018-03-20 12:08:25 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-03-20 06:38:25 --> UTF-8 Support Enabled
INFO - 2018-03-20 12:08:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 06:38:25 --> Utf8 Class Initialized
INFO - 2018-03-20 12:08:26 --> Model Class Initialized
INFO - 2018-03-20 12:08:26 --> Model Class Initialized
INFO - 2018-03-20 12:08:26 --> Model Class Initialized
INFO - 2018-03-20 12:08:26 --> Model Class Initialized
INFO - 2018-03-20 12:08:26 --> Model Class Initialized
INFO - 2018-03-20 12:08:26 --> Model Class Initialized
INFO - 2018-03-20 12:08:26 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-20 12:08:26 --> Final output sent to browser
DEBUG - 2018-03-20 12:08:26 --> Total execution time: 0.1561
INFO - 2018-03-20 06:38:26 --> URI Class Initialized
INFO - 2018-03-20 06:38:26 --> Router Class Initialized
INFO - 2018-03-20 06:38:26 --> Config Class Initialized
INFO - 2018-03-20 06:38:26 --> Hooks Class Initialized
DEBUG - 2018-03-20 06:38:26 --> UTF-8 Support Enabled
INFO - 2018-03-20 06:38:26 --> Utf8 Class Initialized
INFO - 2018-03-20 06:38:26 --> URI Class Initialized
INFO - 2018-03-20 06:38:26 --> Output Class Initialized
INFO - 2018-03-20 06:38:26 --> Router Class Initialized
INFO - 2018-03-20 06:38:26 --> Output Class Initialized
INFO - 2018-03-20 06:38:26 --> Security Class Initialized
INFO - 2018-03-20 06:38:26 --> Security Class Initialized
DEBUG - 2018-03-20 06:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 06:38:26 --> Input Class Initialized
INFO - 2018-03-20 06:38:26 --> Language Class Initialized
DEBUG - 2018-03-20 06:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 06:38:26 --> Input Class Initialized
INFO - 2018-03-20 06:38:26 --> Language Class Initialized
INFO - 2018-03-20 06:38:26 --> Language Class Initialized
INFO - 2018-03-20 06:38:26 --> Config Class Initialized
INFO - 2018-03-20 06:38:26 --> Loader Class Initialized
INFO - 2018-03-20 12:08:26 --> Helper loaded: url_helper
INFO - 2018-03-20 12:08:26 --> Helper loaded: notification_helper
INFO - 2018-03-20 12:08:26 --> Helper loaded: settings_helper
INFO - 2018-03-20 12:08:26 --> Helper loaded: permission_helper
INFO - 2018-03-20 12:08:26 --> Helper loaded: users_helper
INFO - 2018-03-20 06:38:26 --> Language Class Initialized
INFO - 2018-03-20 06:38:26 --> Config Class Initialized
INFO - 2018-03-20 06:38:26 --> Loader Class Initialized
INFO - 2018-03-20 12:08:26 --> Helper loaded: url_helper
INFO - 2018-03-20 12:08:26 --> Helper loaded: notification_helper
INFO - 2018-03-20 12:08:26 --> Helper loaded: settings_helper
INFO - 2018-03-20 12:08:26 --> Helper loaded: permission_helper
INFO - 2018-03-20 12:08:26 --> Database Driver Class Initialized
DEBUG - 2018-03-20 12:08:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 12:08:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 12:08:26 --> Helper loaded: form_helper
INFO - 2018-03-20 12:08:26 --> Form Validation Class Initialized
INFO - 2018-03-20 12:08:26 --> Controller Class Initialized
INFO - 2018-03-20 12:08:26 --> Model Class Initialized
INFO - 2018-03-20 12:08:26 --> Helper loaded: inflector_helper
DEBUG - 2018-03-20 12:08:26 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 12:08:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 12:08:26 --> Model Class Initialized
INFO - 2018-03-20 12:08:26 --> Model Class Initialized
INFO - 2018-03-20 12:08:26 --> Model Class Initialized
INFO - 2018-03-20 12:08:26 --> Model Class Initialized
INFO - 2018-03-20 12:08:26 --> Model Class Initialized
INFO - 2018-03-20 12:08:26 --> Model Class Initialized
INFO - 2018-03-20 12:08:26 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-20 12:08:26 --> Model Class Initialized
INFO - 2018-03-20 12:08:26 --> Final output sent to browser
DEBUG - 2018-03-20 12:08:26 --> Total execution time: 0.7648
INFO - 2018-03-20 12:08:26 --> Helper loaded: users_helper
INFO - 2018-03-20 12:08:27 --> Database Driver Class Initialized
DEBUG - 2018-03-20 12:08:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 12:08:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 12:08:27 --> Helper loaded: form_helper
INFO - 2018-03-20 12:08:27 --> Form Validation Class Initialized
INFO - 2018-03-20 12:08:27 --> Controller Class Initialized
INFO - 2018-03-20 06:38:27 --> Config Class Initialized
INFO - 2018-03-20 06:38:27 --> Hooks Class Initialized
DEBUG - 2018-03-20 06:38:27 --> UTF-8 Support Enabled
INFO - 2018-03-20 06:38:27 --> Utf8 Class Initialized
INFO - 2018-03-20 06:38:27 --> URI Class Initialized
INFO - 2018-03-20 06:38:27 --> Router Class Initialized
INFO - 2018-03-20 06:38:27 --> Output Class Initialized
INFO - 2018-03-20 06:38:27 --> Security Class Initialized
DEBUG - 2018-03-20 06:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 06:38:27 --> Input Class Initialized
INFO - 2018-03-20 06:38:27 --> Language Class Initialized
INFO - 2018-03-20 06:38:27 --> Language Class Initialized
INFO - 2018-03-20 06:38:27 --> Config Class Initialized
INFO - 2018-03-20 06:38:27 --> Loader Class Initialized
INFO - 2018-03-20 12:08:27 --> Helper loaded: url_helper
INFO - 2018-03-20 12:08:28 --> Helper loaded: notification_helper
INFO - 2018-03-20 12:08:28 --> Helper loaded: settings_helper
INFO - 2018-03-20 12:08:28 --> Helper loaded: permission_helper
INFO - 2018-03-20 12:08:28 --> Helper loaded: users_helper
INFO - 2018-03-20 12:08:28 --> Database Driver Class Initialized
DEBUG - 2018-03-20 12:08:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 12:08:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 12:08:28 --> Helper loaded: form_helper
INFO - 2018-03-20 12:08:28 --> Form Validation Class Initialized
INFO - 2018-03-20 12:08:28 --> Controller Class Initialized
INFO - 2018-03-20 12:08:28 --> Model Class Initialized
INFO - 2018-03-20 12:08:28 --> Helper loaded: inflector_helper
DEBUG - 2018-03-20 12:08:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 12:08:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 12:08:28 --> Model Class Initialized
INFO - 2018-03-20 12:08:28 --> Model Class Initialized
INFO - 2018-03-20 12:08:28 --> Model Class Initialized
INFO - 2018-03-20 12:08:28 --> Model Class Initialized
INFO - 2018-03-20 12:08:28 --> Model Class Initialized
INFO - 2018-03-20 12:08:28 --> Model Class Initialized
INFO - 2018-03-20 12:08:28 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-20 12:08:28 --> Model Class Initialized
INFO - 2018-03-20 12:08:28 --> Helper loaded: inflector_helper
INFO - 2018-03-20 12:08:28 --> Model Class Initialized
INFO - 2018-03-20 12:08:28 --> Final output sent to browser
DEBUG - 2018-03-20 12:08:28 --> Total execution time: 0.3181
DEBUG - 2018-03-20 12:08:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 12:08:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 12:08:28 --> Model Class Initialized
INFO - 2018-03-20 12:08:28 --> Model Class Initialized
INFO - 2018-03-20 12:08:28 --> Model Class Initialized
INFO - 2018-03-20 12:08:28 --> Model Class Initialized
INFO - 2018-03-20 12:08:28 --> Model Class Initialized
INFO - 2018-03-20 12:08:28 --> Model Class Initialized
INFO - 2018-03-20 12:08:28 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-20 12:08:28 --> Model Class Initialized
INFO - 2018-03-20 12:08:28 --> Final output sent to browser
DEBUG - 2018-03-20 12:08:28 --> Total execution time: 2.8193
INFO - 2018-03-20 06:38:29 --> Config Class Initialized
INFO - 2018-03-20 06:38:29 --> Hooks Class Initialized
DEBUG - 2018-03-20 06:38:29 --> UTF-8 Support Enabled
INFO - 2018-03-20 06:38:29 --> Utf8 Class Initialized
INFO - 2018-03-20 06:38:29 --> URI Class Initialized
INFO - 2018-03-20 06:38:29 --> Router Class Initialized
INFO - 2018-03-20 06:38:29 --> Output Class Initialized
INFO - 2018-03-20 06:38:29 --> Security Class Initialized
DEBUG - 2018-03-20 06:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 06:38:29 --> Input Class Initialized
INFO - 2018-03-20 06:38:29 --> Language Class Initialized
INFO - 2018-03-20 06:38:30 --> Language Class Initialized
INFO - 2018-03-20 06:38:30 --> Config Class Initialized
INFO - 2018-03-20 06:38:30 --> Loader Class Initialized
INFO - 2018-03-20 12:08:30 --> Helper loaded: url_helper
INFO - 2018-03-20 12:08:30 --> Helper loaded: notification_helper
INFO - 2018-03-20 12:08:30 --> Helper loaded: settings_helper
INFO - 2018-03-20 12:08:30 --> Helper loaded: permission_helper
INFO - 2018-03-20 12:08:30 --> Helper loaded: users_helper
INFO - 2018-03-20 12:08:31 --> Database Driver Class Initialized
DEBUG - 2018-03-20 12:08:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 12:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 12:08:31 --> Helper loaded: form_helper
INFO - 2018-03-20 12:08:31 --> Form Validation Class Initialized
INFO - 2018-03-20 12:08:31 --> Controller Class Initialized
INFO - 2018-03-20 12:08:31 --> Model Class Initialized
INFO - 2018-03-20 12:08:31 --> Helper loaded: inflector_helper
DEBUG - 2018-03-20 12:08:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 12:08:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 12:08:31 --> Model Class Initialized
INFO - 2018-03-20 12:08:31 --> Model Class Initialized
INFO - 2018-03-20 12:08:31 --> Model Class Initialized
INFO - 2018-03-20 12:08:31 --> Model Class Initialized
INFO - 2018-03-20 12:08:31 --> Model Class Initialized
INFO - 2018-03-20 12:08:31 --> Model Class Initialized
INFO - 2018-03-20 12:08:31 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-20 12:08:31 --> Model Class Initialized
INFO - 2018-03-20 12:08:31 --> Final output sent to browser
DEBUG - 2018-03-20 12:08:31 --> Total execution time: 2.2072
INFO - 2018-03-20 06:38:47 --> Config Class Initialized
INFO - 2018-03-20 06:38:47 --> Hooks Class Initialized
DEBUG - 2018-03-20 06:38:47 --> UTF-8 Support Enabled
INFO - 2018-03-20 06:38:47 --> Utf8 Class Initialized
INFO - 2018-03-20 06:38:47 --> URI Class Initialized
INFO - 2018-03-20 06:38:47 --> Router Class Initialized
INFO - 2018-03-20 06:38:47 --> Output Class Initialized
INFO - 2018-03-20 06:38:47 --> Security Class Initialized
DEBUG - 2018-03-20 06:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 06:38:47 --> Input Class Initialized
INFO - 2018-03-20 06:38:47 --> Language Class Initialized
INFO - 2018-03-20 06:38:47 --> Config Class Initialized
INFO - 2018-03-20 06:38:47 --> Hooks Class Initialized
DEBUG - 2018-03-20 06:38:47 --> UTF-8 Support Enabled
INFO - 2018-03-20 06:38:47 --> Utf8 Class Initialized
INFO - 2018-03-20 06:38:47 --> URI Class Initialized
INFO - 2018-03-20 06:38:47 --> Language Class Initialized
INFO - 2018-03-20 06:38:47 --> Config Class Initialized
INFO - 2018-03-20 06:38:47 --> Loader Class Initialized
INFO - 2018-03-20 06:38:47 --> Router Class Initialized
INFO - 2018-03-20 12:08:47 --> Helper loaded: url_helper
INFO - 2018-03-20 12:08:47 --> Helper loaded: notification_helper
INFO - 2018-03-20 12:08:47 --> Helper loaded: settings_helper
INFO - 2018-03-20 12:08:47 --> Helper loaded: permission_helper
INFO - 2018-03-20 12:08:47 --> Helper loaded: users_helper
INFO - 2018-03-20 06:38:47 --> Output Class Initialized
INFO - 2018-03-20 06:38:48 --> Security Class Initialized
DEBUG - 2018-03-20 06:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 06:38:48 --> Input Class Initialized
INFO - 2018-03-20 06:38:48 --> Language Class Initialized
INFO - 2018-03-20 12:08:48 --> Database Driver Class Initialized
DEBUG - 2018-03-20 12:08:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 12:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 06:38:48 --> Config Class Initialized
INFO - 2018-03-20 06:38:48 --> Hooks Class Initialized
INFO - 2018-03-20 12:08:48 --> Helper loaded: form_helper
INFO - 2018-03-20 12:08:48 --> Form Validation Class Initialized
INFO - 2018-03-20 12:08:48 --> Controller Class Initialized
INFO - 2018-03-20 06:38:48 --> Language Class Initialized
INFO - 2018-03-20 06:38:48 --> Config Class Initialized
INFO - 2018-03-20 06:38:48 --> Loader Class Initialized
INFO - 2018-03-20 12:08:48 --> Helper loaded: url_helper
DEBUG - 2018-03-20 06:38:48 --> UTF-8 Support Enabled
INFO - 2018-03-20 06:38:48 --> Utf8 Class Initialized
INFO - 2018-03-20 12:08:48 --> Helper loaded: notification_helper
INFO - 2018-03-20 12:08:48 --> Helper loaded: settings_helper
INFO - 2018-03-20 06:38:48 --> URI Class Initialized
INFO - 2018-03-20 12:08:48 --> Helper loaded: permission_helper
INFO - 2018-03-20 12:08:48 --> Helper loaded: users_helper
INFO - 2018-03-20 12:08:48 --> Model Class Initialized
INFO - 2018-03-20 12:08:48 --> Helper loaded: inflector_helper
DEBUG - 2018-03-20 12:08:48 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 06:38:48 --> Router Class Initialized
INFO - 2018-03-20 12:08:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 12:08:48 --> Model Class Initialized
INFO - 2018-03-20 12:08:48 --> Model Class Initialized
INFO - 2018-03-20 12:08:48 --> Model Class Initialized
INFO - 2018-03-20 12:08:48 --> Model Class Initialized
INFO - 2018-03-20 12:08:48 --> Model Class Initialized
INFO - 2018-03-20 12:08:48 --> Model Class Initialized
INFO - 2018-03-20 12:08:48 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-20 12:08:48 --> Database Driver Class Initialized
ERROR - 2018-03-20 12:08:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-03-20 06:38:48 --> Output Class Initialized
INFO - 2018-03-20 12:08:48 --> Final output sent to browser
DEBUG - 2018-03-20 12:08:48 --> Total execution time: 0.2950
INFO - 2018-03-20 06:38:48 --> Security Class Initialized
DEBUG - 2018-03-20 12:08:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-20 06:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 06:38:48 --> Input Class Initialized
INFO - 2018-03-20 12:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 06:38:48 --> Language Class Initialized
INFO - 2018-03-20 12:08:48 --> Helper loaded: form_helper
INFO - 2018-03-20 12:08:48 --> Form Validation Class Initialized
INFO - 2018-03-20 12:08:48 --> Controller Class Initialized
INFO - 2018-03-20 12:08:48 --> Model Class Initialized
INFO - 2018-03-20 12:08:48 --> Helper loaded: inflector_helper
DEBUG - 2018-03-20 12:08:48 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 12:08:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 12:08:48 --> Model Class Initialized
INFO - 2018-03-20 12:08:48 --> Model Class Initialized
INFO - 2018-03-20 12:08:48 --> Model Class Initialized
INFO - 2018-03-20 12:08:48 --> Model Class Initialized
INFO - 2018-03-20 12:08:48 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-20 12:08:48 --> Final output sent to browser
DEBUG - 2018-03-20 12:08:48 --> Total execution time: 0.3686
INFO - 2018-03-20 06:38:48 --> Language Class Initialized
INFO - 2018-03-20 06:38:48 --> Config Class Initialized
INFO - 2018-03-20 06:38:48 --> Loader Class Initialized
INFO - 2018-03-20 12:08:48 --> Helper loaded: url_helper
INFO - 2018-03-20 12:08:48 --> Helper loaded: notification_helper
INFO - 2018-03-20 12:08:48 --> Helper loaded: settings_helper
INFO - 2018-03-20 12:08:48 --> Helper loaded: permission_helper
INFO - 2018-03-20 12:08:48 --> Helper loaded: users_helper
INFO - 2018-03-20 12:08:48 --> Database Driver Class Initialized
DEBUG - 2018-03-20 12:08:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 12:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 12:08:49 --> Helper loaded: form_helper
INFO - 2018-03-20 12:08:49 --> Form Validation Class Initialized
INFO - 2018-03-20 12:08:49 --> Controller Class Initialized
INFO - 2018-03-20 12:08:49 --> Model Class Initialized
INFO - 2018-03-20 12:08:49 --> Helper loaded: inflector_helper
DEBUG - 2018-03-20 12:08:49 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 12:08:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 12:08:49 --> Model Class Initialized
INFO - 2018-03-20 12:08:49 --> Model Class Initialized
INFO - 2018-03-20 12:08:49 --> Model Class Initialized
INFO - 2018-03-20 12:08:49 --> Model Class Initialized
INFO - 2018-03-20 12:08:49 --> Model Class Initialized
INFO - 2018-03-20 12:08:49 --> Model Class Initialized
INFO - 2018-03-20 12:08:49 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-20 12:08:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-03-20 12:08:49 --> Final output sent to browser
DEBUG - 2018-03-20 12:08:49 --> Total execution time: 1.8256
INFO - 2018-03-20 06:38:50 --> Config Class Initialized
INFO - 2018-03-20 06:38:50 --> Hooks Class Initialized
DEBUG - 2018-03-20 06:38:50 --> UTF-8 Support Enabled
INFO - 2018-03-20 06:38:50 --> Utf8 Class Initialized
INFO - 2018-03-20 06:38:50 --> URI Class Initialized
INFO - 2018-03-20 06:38:50 --> Router Class Initialized
INFO - 2018-03-20 06:38:50 --> Output Class Initialized
INFO - 2018-03-20 06:38:50 --> Security Class Initialized
DEBUG - 2018-03-20 06:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 06:38:50 --> Input Class Initialized
INFO - 2018-03-20 06:38:50 --> Language Class Initialized
INFO - 2018-03-20 06:38:50 --> Language Class Initialized
INFO - 2018-03-20 06:38:50 --> Config Class Initialized
INFO - 2018-03-20 06:38:50 --> Loader Class Initialized
INFO - 2018-03-20 12:08:50 --> Helper loaded: url_helper
INFO - 2018-03-20 12:08:50 --> Helper loaded: notification_helper
INFO - 2018-03-20 12:08:50 --> Helper loaded: settings_helper
INFO - 2018-03-20 12:08:50 --> Helper loaded: permission_helper
INFO - 2018-03-20 12:08:50 --> Helper loaded: users_helper
INFO - 2018-03-20 12:08:50 --> Database Driver Class Initialized
DEBUG - 2018-03-20 12:08:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 12:08:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 12:08:50 --> Helper loaded: form_helper
INFO - 2018-03-20 12:08:50 --> Form Validation Class Initialized
INFO - 2018-03-20 12:08:50 --> Controller Class Initialized
INFO - 2018-03-20 12:08:50 --> Model Class Initialized
INFO - 2018-03-20 12:08:50 --> Helper loaded: inflector_helper
DEBUG - 2018-03-20 12:08:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 12:08:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 12:08:50 --> Model Class Initialized
INFO - 2018-03-20 12:08:50 --> Model Class Initialized
INFO - 2018-03-20 12:08:50 --> Model Class Initialized
INFO - 2018-03-20 12:08:50 --> Model Class Initialized
INFO - 2018-03-20 12:08:50 --> Model Class Initialized
INFO - 2018-03-20 12:08:50 --> Model Class Initialized
INFO - 2018-03-20 12:08:50 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-20 12:08:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-03-20 12:08:50 --> Final output sent to browser
DEBUG - 2018-03-20 12:08:50 --> Total execution time: 0.1000
INFO - 2018-03-20 06:38:52 --> Config Class Initialized
INFO - 2018-03-20 06:38:52 --> Hooks Class Initialized
DEBUG - 2018-03-20 06:38:52 --> UTF-8 Support Enabled
INFO - 2018-03-20 06:38:52 --> Utf8 Class Initialized
INFO - 2018-03-20 06:38:52 --> URI Class Initialized
INFO - 2018-03-20 06:38:52 --> Router Class Initialized
INFO - 2018-03-20 06:38:52 --> Output Class Initialized
INFO - 2018-03-20 06:38:52 --> Security Class Initialized
DEBUG - 2018-03-20 06:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 06:38:52 --> Input Class Initialized
INFO - 2018-03-20 06:38:52 --> Language Class Initialized
INFO - 2018-03-20 06:38:52 --> Language Class Initialized
INFO - 2018-03-20 06:38:52 --> Config Class Initialized
INFO - 2018-03-20 06:38:52 --> Loader Class Initialized
INFO - 2018-03-20 12:08:52 --> Helper loaded: url_helper
INFO - 2018-03-20 12:08:52 --> Helper loaded: notification_helper
INFO - 2018-03-20 12:08:52 --> Helper loaded: settings_helper
INFO - 2018-03-20 12:08:52 --> Helper loaded: permission_helper
INFO - 2018-03-20 12:08:52 --> Helper loaded: users_helper
INFO - 2018-03-20 12:08:52 --> Database Driver Class Initialized
DEBUG - 2018-03-20 12:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 12:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 12:08:52 --> Helper loaded: form_helper
INFO - 2018-03-20 12:08:52 --> Form Validation Class Initialized
INFO - 2018-03-20 12:08:52 --> Controller Class Initialized
INFO - 2018-03-20 12:08:52 --> Model Class Initialized
INFO - 2018-03-20 12:08:52 --> Helper loaded: inflector_helper
DEBUG - 2018-03-20 12:08:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 12:08:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 12:08:52 --> Model Class Initialized
INFO - 2018-03-20 12:08:52 --> Model Class Initialized
INFO - 2018-03-20 12:08:52 --> Model Class Initialized
INFO - 2018-03-20 12:08:52 --> Model Class Initialized
INFO - 2018-03-20 12:08:52 --> Model Class Initialized
INFO - 2018-03-20 12:08:52 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-20 12:08:52 --> Model Class Initialized
INFO - 2018-03-20 12:08:52 --> Final output sent to browser
DEBUG - 2018-03-20 12:08:52 --> Total execution time: 0.1070
INFO - 2018-03-20 06:38:52 --> Config Class Initialized
INFO - 2018-03-20 06:38:52 --> Hooks Class Initialized
DEBUG - 2018-03-20 06:38:52 --> UTF-8 Support Enabled
INFO - 2018-03-20 06:38:52 --> Utf8 Class Initialized
INFO - 2018-03-20 06:38:52 --> URI Class Initialized
INFO - 2018-03-20 06:38:53 --> Router Class Initialized
INFO - 2018-03-20 06:38:53 --> Output Class Initialized
INFO - 2018-03-20 06:38:53 --> Security Class Initialized
DEBUG - 2018-03-20 06:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 06:38:53 --> Input Class Initialized
INFO - 2018-03-20 06:38:53 --> Language Class Initialized
INFO - 2018-03-20 06:38:54 --> Language Class Initialized
INFO - 2018-03-20 06:38:54 --> Config Class Initialized
INFO - 2018-03-20 06:38:54 --> Loader Class Initialized
INFO - 2018-03-20 12:08:54 --> Helper loaded: url_helper
INFO - 2018-03-20 12:08:54 --> Helper loaded: notification_helper
INFO - 2018-03-20 12:08:54 --> Helper loaded: settings_helper
INFO - 2018-03-20 12:08:54 --> Helper loaded: permission_helper
INFO - 2018-03-20 12:08:54 --> Helper loaded: users_helper
INFO - 2018-03-20 06:38:54 --> Config Class Initialized
INFO - 2018-03-20 06:38:54 --> Hooks Class Initialized
DEBUG - 2018-03-20 06:38:54 --> UTF-8 Support Enabled
INFO - 2018-03-20 06:38:54 --> Utf8 Class Initialized
INFO - 2018-03-20 06:38:54 --> URI Class Initialized
INFO - 2018-03-20 06:38:54 --> Router Class Initialized
INFO - 2018-03-20 06:38:54 --> Output Class Initialized
INFO - 2018-03-20 06:38:55 --> Security Class Initialized
DEBUG - 2018-03-20 06:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 06:38:55 --> Input Class Initialized
INFO - 2018-03-20 12:08:55 --> Database Driver Class Initialized
INFO - 2018-03-20 06:38:55 --> Language Class Initialized
DEBUG - 2018-03-20 12:08:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 12:08:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 12:08:55 --> Helper loaded: form_helper
INFO - 2018-03-20 12:08:55 --> Form Validation Class Initialized
INFO - 2018-03-20 12:08:55 --> Controller Class Initialized
INFO - 2018-03-20 06:38:56 --> Language Class Initialized
INFO - 2018-03-20 06:38:56 --> Config Class Initialized
INFO - 2018-03-20 06:38:56 --> Loader Class Initialized
INFO - 2018-03-20 12:08:56 --> Model Class Initialized
INFO - 2018-03-20 12:08:56 --> Helper loaded: inflector_helper
INFO - 2018-03-20 12:08:56 --> Helper loaded: url_helper
DEBUG - 2018-03-20 12:08:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 12:08:56 --> Helper loaded: notification_helper
INFO - 2018-03-20 12:08:56 --> Helper loaded: settings_helper
INFO - 2018-03-20 12:08:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 12:08:56 --> Helper loaded: permission_helper
INFO - 2018-03-20 12:08:56 --> Model Class Initialized
INFO - 2018-03-20 12:08:56 --> Model Class Initialized
INFO - 2018-03-20 12:08:56 --> Model Class Initialized
INFO - 2018-03-20 12:08:56 --> Model Class Initialized
INFO - 2018-03-20 12:08:56 --> Model Class Initialized
INFO - 2018-03-20 12:08:56 --> Model Class Initialized
INFO - 2018-03-20 12:08:56 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-20 12:08:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-03-20 12:08:56 --> Final output sent to browser
DEBUG - 2018-03-20 12:08:56 --> Total execution time: 3.5531
INFO - 2018-03-20 12:08:56 --> Helper loaded: users_helper
INFO - 2018-03-20 12:08:57 --> Database Driver Class Initialized
DEBUG - 2018-03-20 12:08:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 12:08:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 12:08:58 --> Helper loaded: form_helper
INFO - 2018-03-20 12:08:58 --> Form Validation Class Initialized
INFO - 2018-03-20 12:08:58 --> Controller Class Initialized
INFO - 2018-03-20 12:08:58 --> Model Class Initialized
INFO - 2018-03-20 12:08:58 --> Helper loaded: inflector_helper
DEBUG - 2018-03-20 12:08:58 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 12:08:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 12:08:59 --> Model Class Initialized
INFO - 2018-03-20 12:08:59 --> Model Class Initialized
INFO - 2018-03-20 12:08:59 --> Model Class Initialized
INFO - 2018-03-20 12:08:59 --> Model Class Initialized
INFO - 2018-03-20 12:08:59 --> Model Class Initialized
INFO - 2018-03-20 12:08:59 --> Model Class Initialized
INFO - 2018-03-20 12:08:59 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-20 12:08:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-03-20 12:08:59 --> Final output sent to browser
DEBUG - 2018-03-20 12:08:59 --> Total execution time: 4.8427
INFO - 2018-03-20 06:39:42 --> Config Class Initialized
INFO - 2018-03-20 06:39:42 --> Hooks Class Initialized
DEBUG - 2018-03-20 06:39:42 --> UTF-8 Support Enabled
INFO - 2018-03-20 06:39:42 --> Utf8 Class Initialized
INFO - 2018-03-20 06:39:42 --> URI Class Initialized
INFO - 2018-03-20 06:39:42 --> Router Class Initialized
INFO - 2018-03-20 06:39:42 --> Output Class Initialized
INFO - 2018-03-20 06:39:42 --> Security Class Initialized
DEBUG - 2018-03-20 06:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 06:39:42 --> Input Class Initialized
INFO - 2018-03-20 06:39:42 --> Language Class Initialized
INFO - 2018-03-20 06:39:42 --> Language Class Initialized
INFO - 2018-03-20 06:39:42 --> Config Class Initialized
INFO - 2018-03-20 06:39:42 --> Loader Class Initialized
INFO - 2018-03-20 12:09:42 --> Helper loaded: url_helper
INFO - 2018-03-20 12:09:42 --> Helper loaded: notification_helper
INFO - 2018-03-20 12:09:42 --> Helper loaded: settings_helper
INFO - 2018-03-20 12:09:42 --> Helper loaded: permission_helper
INFO - 2018-03-20 12:09:42 --> Helper loaded: users_helper
INFO - 2018-03-20 12:09:42 --> Database Driver Class Initialized
DEBUG - 2018-03-20 12:09:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 12:09:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 12:09:43 --> Helper loaded: form_helper
INFO - 2018-03-20 12:09:43 --> Form Validation Class Initialized
INFO - 2018-03-20 12:09:43 --> Controller Class Initialized
INFO - 2018-03-20 12:09:43 --> Model Class Initialized
INFO - 2018-03-20 12:09:43 --> Helper loaded: inflector_helper
DEBUG - 2018-03-20 12:09:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 12:09:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 12:09:43 --> Model Class Initialized
INFO - 2018-03-20 12:09:43 --> Model Class Initialized
INFO - 2018-03-20 12:09:43 --> Model Class Initialized
INFO - 2018-03-20 12:09:43 --> Model Class Initialized
INFO - 2018-03-20 12:09:43 --> Model Class Initialized
INFO - 2018-03-20 12:09:43 --> Model Class Initialized
INFO - 2018-03-20 12:09:43 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-20 12:09:43 --> Upload Class Initialized
INFO - 2018-03-20 12:09:43 --> Final output sent to browser
DEBUG - 2018-03-20 12:09:43 --> Total execution time: 1.1355
INFO - 2018-03-20 06:39:44 --> Config Class Initialized
INFO - 2018-03-20 06:39:44 --> Hooks Class Initialized
DEBUG - 2018-03-20 06:39:44 --> UTF-8 Support Enabled
INFO - 2018-03-20 06:39:44 --> Utf8 Class Initialized
INFO - 2018-03-20 06:39:44 --> URI Class Initialized
INFO - 2018-03-20 06:39:44 --> Router Class Initialized
INFO - 2018-03-20 06:39:44 --> Output Class Initialized
INFO - 2018-03-20 06:39:44 --> Security Class Initialized
DEBUG - 2018-03-20 06:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 06:39:44 --> Input Class Initialized
INFO - 2018-03-20 06:39:44 --> Language Class Initialized
INFO - 2018-03-20 06:39:44 --> Language Class Initialized
INFO - 2018-03-20 06:39:44 --> Config Class Initialized
INFO - 2018-03-20 06:39:44 --> Loader Class Initialized
INFO - 2018-03-20 12:09:44 --> Helper loaded: url_helper
INFO - 2018-03-20 12:09:44 --> Helper loaded: notification_helper
INFO - 2018-03-20 12:09:44 --> Helper loaded: settings_helper
INFO - 2018-03-20 12:09:44 --> Helper loaded: permission_helper
INFO - 2018-03-20 12:09:44 --> Helper loaded: users_helper
INFO - 2018-03-20 12:09:44 --> Database Driver Class Initialized
DEBUG - 2018-03-20 12:09:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 12:09:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 12:09:44 --> Helper loaded: form_helper
INFO - 2018-03-20 12:09:44 --> Form Validation Class Initialized
INFO - 2018-03-20 12:09:44 --> Controller Class Initialized
INFO - 2018-03-20 12:09:44 --> Model Class Initialized
INFO - 2018-03-20 12:09:44 --> Helper loaded: inflector_helper
DEBUG - 2018-03-20 12:09:44 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 12:09:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 12:09:44 --> Model Class Initialized
INFO - 2018-03-20 12:09:44 --> Model Class Initialized
INFO - 2018-03-20 12:09:44 --> Model Class Initialized
INFO - 2018-03-20 12:09:44 --> Model Class Initialized
INFO - 2018-03-20 12:09:44 --> Model Class Initialized
INFO - 2018-03-20 12:09:44 --> Model Class Initialized
INFO - 2018-03-20 12:09:44 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-20 12:09:44 --> Final output sent to browser
DEBUG - 2018-03-20 12:09:44 --> Total execution time: 0.2351
INFO - 2018-03-20 06:39:57 --> Config Class Initialized
INFO - 2018-03-20 06:39:57 --> Hooks Class Initialized
DEBUG - 2018-03-20 06:39:57 --> UTF-8 Support Enabled
INFO - 2018-03-20 06:39:57 --> Utf8 Class Initialized
INFO - 2018-03-20 06:39:57 --> URI Class Initialized
INFO - 2018-03-20 06:39:57 --> Router Class Initialized
INFO - 2018-03-20 06:39:58 --> Output Class Initialized
INFO - 2018-03-20 06:39:58 --> Security Class Initialized
DEBUG - 2018-03-20 06:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 06:39:58 --> Input Class Initialized
INFO - 2018-03-20 06:39:58 --> Language Class Initialized
INFO - 2018-03-20 06:39:59 --> Language Class Initialized
INFO - 2018-03-20 06:39:59 --> Config Class Initialized
INFO - 2018-03-20 06:39:59 --> Loader Class Initialized
INFO - 2018-03-20 12:09:59 --> Helper loaded: url_helper
INFO - 2018-03-20 12:09:59 --> Helper loaded: notification_helper
INFO - 2018-03-20 12:09:59 --> Helper loaded: settings_helper
INFO - 2018-03-20 12:10:00 --> Helper loaded: permission_helper
INFO - 2018-03-20 12:10:00 --> Helper loaded: users_helper
INFO - 2018-03-20 12:10:00 --> Database Driver Class Initialized
DEBUG - 2018-03-20 12:10:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 12:10:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 12:10:00 --> Helper loaded: form_helper
INFO - 2018-03-20 12:10:00 --> Form Validation Class Initialized
INFO - 2018-03-20 12:10:00 --> Controller Class Initialized
INFO - 2018-03-20 12:10:00 --> Model Class Initialized
INFO - 2018-03-20 12:10:00 --> Helper loaded: inflector_helper
DEBUG - 2018-03-20 12:10:00 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 12:10:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 12:10:00 --> Model Class Initialized
INFO - 2018-03-20 12:10:00 --> Model Class Initialized
INFO - 2018-03-20 12:10:00 --> Model Class Initialized
INFO - 2018-03-20 12:10:00 --> Model Class Initialized
INFO - 2018-03-20 12:10:00 --> Model Class Initialized
INFO - 2018-03-20 12:10:00 --> Model Class Initialized
INFO - 2018-03-20 12:10:00 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-20 12:10:00 --> Upload Class Initialized
INFO - 2018-03-20 12:10:00 --> Final output sent to browser
DEBUG - 2018-03-20 12:10:00 --> Total execution time: 3.1998
INFO - 2018-03-20 06:40:02 --> Config Class Initialized
INFO - 2018-03-20 06:40:02 --> Hooks Class Initialized
DEBUG - 2018-03-20 06:40:02 --> UTF-8 Support Enabled
INFO - 2018-03-20 06:40:02 --> Utf8 Class Initialized
INFO - 2018-03-20 06:40:02 --> URI Class Initialized
INFO - 2018-03-20 06:40:02 --> Router Class Initialized
INFO - 2018-03-20 06:40:02 --> Output Class Initialized
INFO - 2018-03-20 06:40:02 --> Security Class Initialized
DEBUG - 2018-03-20 06:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 06:40:02 --> Input Class Initialized
INFO - 2018-03-20 06:40:02 --> Language Class Initialized
INFO - 2018-03-20 06:40:02 --> Language Class Initialized
INFO - 2018-03-20 06:40:02 --> Config Class Initialized
INFO - 2018-03-20 06:40:02 --> Loader Class Initialized
INFO - 2018-03-20 12:10:02 --> Helper loaded: url_helper
INFO - 2018-03-20 12:10:02 --> Helper loaded: notification_helper
INFO - 2018-03-20 12:10:02 --> Helper loaded: settings_helper
INFO - 2018-03-20 12:10:02 --> Helper loaded: permission_helper
INFO - 2018-03-20 12:10:02 --> Helper loaded: users_helper
INFO - 2018-03-20 12:10:02 --> Database Driver Class Initialized
DEBUG - 2018-03-20 12:10:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 12:10:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 12:10:02 --> Helper loaded: form_helper
INFO - 2018-03-20 12:10:02 --> Form Validation Class Initialized
INFO - 2018-03-20 12:10:02 --> Controller Class Initialized
INFO - 2018-03-20 12:10:03 --> Model Class Initialized
INFO - 2018-03-20 12:10:03 --> Helper loaded: inflector_helper
DEBUG - 2018-03-20 12:10:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 12:10:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 12:10:03 --> Model Class Initialized
INFO - 2018-03-20 12:10:03 --> Model Class Initialized
INFO - 2018-03-20 12:10:03 --> Model Class Initialized
INFO - 2018-03-20 12:10:03 --> Model Class Initialized
INFO - 2018-03-20 12:10:03 --> Model Class Initialized
INFO - 2018-03-20 12:10:03 --> Model Class Initialized
INFO - 2018-03-20 12:10:03 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-20 12:10:03 --> Final output sent to browser
DEBUG - 2018-03-20 12:10:03 --> Total execution time: 0.9957
INFO - 2018-03-20 06:40:24 --> Config Class Initialized
INFO - 2018-03-20 06:40:24 --> Hooks Class Initialized
DEBUG - 2018-03-20 06:40:24 --> UTF-8 Support Enabled
INFO - 2018-03-20 06:40:24 --> Utf8 Class Initialized
INFO - 2018-03-20 06:40:24 --> URI Class Initialized
INFO - 2018-03-20 06:40:24 --> Router Class Initialized
INFO - 2018-03-20 06:40:24 --> Output Class Initialized
INFO - 2018-03-20 06:40:24 --> Security Class Initialized
DEBUG - 2018-03-20 06:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 06:40:24 --> Input Class Initialized
INFO - 2018-03-20 06:40:24 --> Language Class Initialized
INFO - 2018-03-20 06:40:24 --> Language Class Initialized
INFO - 2018-03-20 06:40:24 --> Config Class Initialized
INFO - 2018-03-20 06:40:24 --> Loader Class Initialized
INFO - 2018-03-20 12:10:24 --> Helper loaded: url_helper
INFO - 2018-03-20 12:10:24 --> Helper loaded: notification_helper
INFO - 2018-03-20 12:10:24 --> Helper loaded: settings_helper
INFO - 2018-03-20 12:10:24 --> Helper loaded: permission_helper
INFO - 2018-03-20 12:10:24 --> Helper loaded: users_helper
INFO - 2018-03-20 12:10:24 --> Database Driver Class Initialized
DEBUG - 2018-03-20 12:10:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 12:10:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 12:10:24 --> Helper loaded: form_helper
INFO - 2018-03-20 12:10:24 --> Form Validation Class Initialized
INFO - 2018-03-20 12:10:24 --> Controller Class Initialized
INFO - 2018-03-20 12:10:24 --> Model Class Initialized
INFO - 2018-03-20 12:10:24 --> Helper loaded: inflector_helper
DEBUG - 2018-03-20 12:10:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 12:10:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 12:10:24 --> Model Class Initialized
INFO - 2018-03-20 12:10:24 --> Model Class Initialized
INFO - 2018-03-20 12:10:24 --> Model Class Initialized
INFO - 2018-03-20 12:10:24 --> Model Class Initialized
INFO - 2018-03-20 12:10:24 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-20 12:10:24 --> Final output sent to browser
DEBUG - 2018-03-20 12:10:24 --> Total execution time: 0.1088
INFO - 2018-03-20 06:40:24 --> Config Class Initialized
INFO - 2018-03-20 06:40:24 --> Hooks Class Initialized
INFO - 2018-03-20 06:40:24 --> Config Class Initialized
INFO - 2018-03-20 06:40:24 --> Hooks Class Initialized
DEBUG - 2018-03-20 06:40:24 --> UTF-8 Support Enabled
INFO - 2018-03-20 06:40:24 --> Utf8 Class Initialized
INFO - 2018-03-20 06:40:24 --> URI Class Initialized
INFO - 2018-03-20 06:40:24 --> Router Class Initialized
INFO - 2018-03-20 06:40:24 --> Output Class Initialized
INFO - 2018-03-20 06:40:24 --> Security Class Initialized
DEBUG - 2018-03-20 06:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 06:40:24 --> Input Class Initialized
INFO - 2018-03-20 06:40:24 --> Language Class Initialized
INFO - 2018-03-20 06:40:24 --> Language Class Initialized
INFO - 2018-03-20 06:40:24 --> Config Class Initialized
INFO - 2018-03-20 06:40:24 --> Loader Class Initialized
INFO - 2018-03-20 12:10:24 --> Helper loaded: url_helper
INFO - 2018-03-20 12:10:24 --> Helper loaded: notification_helper
INFO - 2018-03-20 12:10:24 --> Helper loaded: settings_helper
INFO - 2018-03-20 12:10:24 --> Helper loaded: permission_helper
INFO - 2018-03-20 12:10:24 --> Helper loaded: users_helper
INFO - 2018-03-20 12:10:24 --> Database Driver Class Initialized
DEBUG - 2018-03-20 06:40:24 --> UTF-8 Support Enabled
DEBUG - 2018-03-20 12:10:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 12:10:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 06:40:24 --> Utf8 Class Initialized
INFO - 2018-03-20 12:10:24 --> Helper loaded: form_helper
INFO - 2018-03-20 12:10:24 --> Form Validation Class Initialized
INFO - 2018-03-20 12:10:24 --> Controller Class Initialized
INFO - 2018-03-20 12:10:24 --> Model Class Initialized
INFO - 2018-03-20 12:10:24 --> Helper loaded: inflector_helper
DEBUG - 2018-03-20 12:10:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 12:10:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 12:10:24 --> Model Class Initialized
INFO - 2018-03-20 12:10:24 --> Model Class Initialized
INFO - 2018-03-20 12:10:24 --> Model Class Initialized
INFO - 2018-03-20 12:10:24 --> Model Class Initialized
INFO - 2018-03-20 12:10:24 --> Model Class Initialized
INFO - 2018-03-20 12:10:24 --> Model Class Initialized
INFO - 2018-03-20 12:10:24 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-20 12:10:24 --> Final output sent to browser
DEBUG - 2018-03-20 12:10:24 --> Total execution time: 0.2838
INFO - 2018-03-20 06:40:24 --> URI Class Initialized
INFO - 2018-03-20 06:40:25 --> Router Class Initialized
INFO - 2018-03-20 06:40:25 --> Output Class Initialized
INFO - 2018-03-20 06:40:25 --> Security Class Initialized
DEBUG - 2018-03-20 06:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 06:40:25 --> Input Class Initialized
INFO - 2018-03-20 06:40:25 --> Language Class Initialized
INFO - 2018-03-20 06:40:26 --> Language Class Initialized
INFO - 2018-03-20 06:40:26 --> Config Class Initialized
INFO - 2018-03-20 06:40:26 --> Loader Class Initialized
INFO - 2018-03-20 12:10:26 --> Helper loaded: url_helper
INFO - 2018-03-20 12:10:26 --> Helper loaded: notification_helper
INFO - 2018-03-20 12:10:26 --> Helper loaded: settings_helper
INFO - 2018-03-20 12:10:26 --> Helper loaded: permission_helper
INFO - 2018-03-20 12:10:26 --> Helper loaded: users_helper
INFO - 2018-03-20 06:40:27 --> Config Class Initialized
INFO - 2018-03-20 06:40:27 --> Hooks Class Initialized
DEBUG - 2018-03-20 06:40:27 --> UTF-8 Support Enabled
INFO - 2018-03-20 06:40:27 --> Utf8 Class Initialized
INFO - 2018-03-20 06:40:27 --> URI Class Initialized
INFO - 2018-03-20 06:40:27 --> Router Class Initialized
INFO - 2018-03-20 06:40:27 --> Output Class Initialized
INFO - 2018-03-20 06:40:27 --> Security Class Initialized
DEBUG - 2018-03-20 06:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 06:40:27 --> Input Class Initialized
INFO - 2018-03-20 06:40:27 --> Language Class Initialized
INFO - 2018-03-20 12:10:27 --> Database Driver Class Initialized
INFO - 2018-03-20 06:40:27 --> Language Class Initialized
INFO - 2018-03-20 06:40:27 --> Config Class Initialized
INFO - 2018-03-20 06:40:27 --> Loader Class Initialized
DEBUG - 2018-03-20 12:10:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 12:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 12:10:27 --> Helper loaded: url_helper
INFO - 2018-03-20 12:10:27 --> Helper loaded: form_helper
INFO - 2018-03-20 12:10:27 --> Form Validation Class Initialized
INFO - 2018-03-20 12:10:27 --> Controller Class Initialized
INFO - 2018-03-20 12:10:27 --> Helper loaded: notification_helper
INFO - 2018-03-20 12:10:27 --> Helper loaded: settings_helper
INFO - 2018-03-20 12:10:27 --> Model Class Initialized
INFO - 2018-03-20 12:10:27 --> Helper loaded: inflector_helper
DEBUG - 2018-03-20 12:10:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 12:10:27 --> Helper loaded: permission_helper
INFO - 2018-03-20 12:10:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 12:10:27 --> Model Class Initialized
INFO - 2018-03-20 12:10:27 --> Model Class Initialized
INFO - 2018-03-20 12:10:27 --> Model Class Initialized
INFO - 2018-03-20 12:10:27 --> Model Class Initialized
INFO - 2018-03-20 12:10:27 --> Model Class Initialized
INFO - 2018-03-20 12:10:27 --> Model Class Initialized
INFO - 2018-03-20 12:10:27 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-20 12:10:27 --> Final output sent to browser
DEBUG - 2018-03-20 12:10:27 --> Total execution time: 3.4122
INFO - 2018-03-20 12:10:27 --> Helper loaded: users_helper
INFO - 2018-03-20 12:10:27 --> Database Driver Class Initialized
DEBUG - 2018-03-20 12:10:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 12:10:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 12:10:28 --> Helper loaded: form_helper
INFO - 2018-03-20 12:10:28 --> Form Validation Class Initialized
INFO - 2018-03-20 12:10:28 --> Controller Class Initialized
INFO - 2018-03-20 12:10:28 --> Model Class Initialized
INFO - 2018-03-20 12:10:28 --> Helper loaded: inflector_helper
DEBUG - 2018-03-20 12:10:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 12:10:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 12:10:28 --> Model Class Initialized
INFO - 2018-03-20 12:10:28 --> Model Class Initialized
INFO - 2018-03-20 12:10:28 --> Model Class Initialized
INFO - 2018-03-20 12:10:28 --> Model Class Initialized
INFO - 2018-03-20 12:10:28 --> Model Class Initialized
INFO - 2018-03-20 12:10:28 --> Model Class Initialized
INFO - 2018-03-20 12:10:28 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-20 12:10:28 --> Final output sent to browser
DEBUG - 2018-03-20 12:10:28 --> Total execution time: 1.2433
INFO - 2018-03-20 11:25:01 --> Config Class Initialized
INFO - 2018-03-20 11:25:01 --> Hooks Class Initialized
DEBUG - 2018-03-20 11:25:01 --> UTF-8 Support Enabled
INFO - 2018-03-20 11:25:01 --> Utf8 Class Initialized
INFO - 2018-03-20 11:25:01 --> URI Class Initialized
INFO - 2018-03-20 11:25:01 --> Router Class Initialized
INFO - 2018-03-20 11:25:01 --> Output Class Initialized
INFO - 2018-03-20 11:25:01 --> Security Class Initialized
DEBUG - 2018-03-20 11:25:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 11:25:01 --> Input Class Initialized
INFO - 2018-03-20 11:25:01 --> Language Class Initialized
INFO - 2018-03-20 11:25:01 --> Language Class Initialized
INFO - 2018-03-20 11:25:01 --> Config Class Initialized
INFO - 2018-03-20 11:25:01 --> Loader Class Initialized
INFO - 2018-03-20 16:55:01 --> Helper loaded: url_helper
INFO - 2018-03-20 16:55:01 --> Helper loaded: notification_helper
INFO - 2018-03-20 16:55:01 --> Helper loaded: settings_helper
INFO - 2018-03-20 16:55:01 --> Helper loaded: permission_helper
INFO - 2018-03-20 16:55:01 --> Helper loaded: users_helper
INFO - 2018-03-20 16:55:01 --> Database Driver Class Initialized
DEBUG - 2018-03-20 16:55:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 16:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 16:55:01 --> Helper loaded: form_helper
INFO - 2018-03-20 16:55:01 --> Form Validation Class Initialized
INFO - 2018-03-20 16:55:01 --> Controller Class Initialized
INFO - 2018-03-20 16:55:01 --> Model Class Initialized
INFO - 2018-03-20 16:55:01 --> Helper loaded: inflector_helper
DEBUG - 2018-03-20 16:55:01 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 16:55:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 16:55:01 --> Model Class Initialized
INFO - 2018-03-20 16:55:01 --> Model Class Initialized
INFO - 2018-03-20 16:55:01 --> Model Class Initialized
INFO - 2018-03-20 16:55:01 --> Model Class Initialized
INFO - 2018-03-20 16:55:01 --> Model Class Initialized
INFO - 2018-03-20 16:55:01 --> Model Class Initialized
INFO - 2018-03-20 16:55:01 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-20 16:55:01 --> Model Class Initialized
INFO - 2018-03-20 16:55:01 --> Final output sent to browser
DEBUG - 2018-03-20 16:55:01 --> Total execution time: 0.2481
INFO - 2018-03-20 11:25:02 --> Config Class Initialized
INFO - 2018-03-20 11:25:02 --> Hooks Class Initialized
DEBUG - 2018-03-20 11:25:02 --> UTF-8 Support Enabled
INFO - 2018-03-20 11:25:02 --> Utf8 Class Initialized
INFO - 2018-03-20 11:25:02 --> URI Class Initialized
INFO - 2018-03-20 11:25:03 --> Config Class Initialized
INFO - 2018-03-20 11:25:03 --> Hooks Class Initialized
INFO - 2018-03-20 11:25:03 --> Config Class Initialized
INFO - 2018-03-20 11:25:03 --> Hooks Class Initialized
DEBUG - 2018-03-20 11:25:03 --> UTF-8 Support Enabled
INFO - 2018-03-20 11:25:03 --> Utf8 Class Initialized
INFO - 2018-03-20 11:25:03 --> URI Class Initialized
INFO - 2018-03-20 11:25:03 --> Router Class Initialized
INFO - 2018-03-20 11:25:03 --> Output Class Initialized
INFO - 2018-03-20 11:25:03 --> Router Class Initialized
INFO - 2018-03-20 11:25:03 --> Security Class Initialized
DEBUG - 2018-03-20 11:25:03 --> UTF-8 Support Enabled
INFO - 2018-03-20 11:25:03 --> Utf8 Class Initialized
DEBUG - 2018-03-20 11:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 11:25:03 --> Input Class Initialized
INFO - 2018-03-20 11:25:03 --> Language Class Initialized
INFO - 2018-03-20 11:25:03 --> URI Class Initialized
INFO - 2018-03-20 11:25:03 --> Language Class Initialized
INFO - 2018-03-20 11:25:03 --> Config Class Initialized
INFO - 2018-03-20 11:25:03 --> Loader Class Initialized
INFO - 2018-03-20 16:55:03 --> Helper loaded: url_helper
INFO - 2018-03-20 16:55:03 --> Helper loaded: notification_helper
INFO - 2018-03-20 16:55:03 --> Helper loaded: settings_helper
INFO - 2018-03-20 16:55:03 --> Helper loaded: permission_helper
INFO - 2018-03-20 16:55:03 --> Helper loaded: users_helper
INFO - 2018-03-20 11:25:03 --> Router Class Initialized
INFO - 2018-03-20 16:55:03 --> Database Driver Class Initialized
DEBUG - 2018-03-20 16:55:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 16:55:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 16:55:03 --> Helper loaded: form_helper
INFO - 2018-03-20 16:55:03 --> Form Validation Class Initialized
INFO - 2018-03-20 16:55:03 --> Controller Class Initialized
INFO - 2018-03-20 11:25:03 --> Output Class Initialized
INFO - 2018-03-20 16:55:03 --> Model Class Initialized
INFO - 2018-03-20 16:55:03 --> Helper loaded: inflector_helper
DEBUG - 2018-03-20 16:55:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 16:55:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 16:55:03 --> Model Class Initialized
INFO - 2018-03-20 16:55:03 --> Model Class Initialized
INFO - 2018-03-20 16:55:03 --> Model Class Initialized
INFO - 2018-03-20 16:55:03 --> Model Class Initialized
INFO - 2018-03-20 16:55:03 --> Model Class Initialized
INFO - 2018-03-20 16:55:03 --> Model Class Initialized
INFO - 2018-03-20 16:55:03 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-20 16:55:03 --> Final output sent to browser
DEBUG - 2018-03-20 16:55:03 --> Total execution time: 0.6556
INFO - 2018-03-20 11:25:03 --> Output Class Initialized
INFO - 2018-03-20 11:25:03 --> Security Class Initialized
INFO - 2018-03-20 11:25:03 --> Security Class Initialized
DEBUG - 2018-03-20 11:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 11:25:03 --> Input Class Initialized
DEBUG - 2018-03-20 11:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 11:25:03 --> Input Class Initialized
INFO - 2018-03-20 11:25:03 --> Language Class Initialized
INFO - 2018-03-20 11:25:03 --> Language Class Initialized
INFO - 2018-03-20 11:25:04 --> Language Class Initialized
INFO - 2018-03-20 11:25:04 --> Config Class Initialized
INFO - 2018-03-20 11:25:04 --> Loader Class Initialized
INFO - 2018-03-20 16:55:04 --> Helper loaded: url_helper
INFO - 2018-03-20 16:55:04 --> Helper loaded: notification_helper
INFO - 2018-03-20 16:55:04 --> Helper loaded: settings_helper
INFO - 2018-03-20 16:55:04 --> Helper loaded: permission_helper
INFO - 2018-03-20 16:55:04 --> Helper loaded: users_helper
INFO - 2018-03-20 16:55:04 --> Database Driver Class Initialized
DEBUG - 2018-03-20 16:55:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 16:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 16:55:04 --> Helper loaded: form_helper
INFO - 2018-03-20 16:55:04 --> Form Validation Class Initialized
INFO - 2018-03-20 16:55:04 --> Controller Class Initialized
INFO - 2018-03-20 16:55:04 --> Model Class Initialized
INFO - 2018-03-20 16:55:04 --> Helper loaded: inflector_helper
DEBUG - 2018-03-20 16:55:04 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 16:55:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 16:55:04 --> Model Class Initialized
INFO - 2018-03-20 16:55:04 --> Model Class Initialized
INFO - 2018-03-20 16:55:04 --> Model Class Initialized
INFO - 2018-03-20 16:55:04 --> Model Class Initialized
INFO - 2018-03-20 16:55:04 --> Model Class Initialized
INFO - 2018-03-20 16:55:04 --> Model Class Initialized
INFO - 2018-03-20 16:55:04 --> Model Class Initialized
INFO - 2018-03-20 16:55:04 --> Model Class Initialized
INFO - 2018-03-20 16:55:04 --> Model Class Initialized
INFO - 2018-03-20 16:55:04 --> Model Class Initialized
INFO - 2018-03-20 16:55:04 --> Model Class Initialized
INFO - 2018-03-20 16:55:04 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-20 16:55:04 --> Model Class Initialized
INFO - 2018-03-20 16:55:04 --> Final output sent to browser
DEBUG - 2018-03-20 16:55:04 --> Total execution time: 1.9046
INFO - 2018-03-20 11:25:04 --> Language Class Initialized
INFO - 2018-03-20 11:25:04 --> Config Class Initialized
INFO - 2018-03-20 11:25:04 --> Loader Class Initialized
INFO - 2018-03-20 16:55:04 --> Helper loaded: url_helper
INFO - 2018-03-20 16:55:04 --> Helper loaded: notification_helper
INFO - 2018-03-20 16:55:04 --> Helper loaded: settings_helper
INFO - 2018-03-20 16:55:04 --> Helper loaded: permission_helper
INFO - 2018-03-20 16:55:04 --> Helper loaded: users_helper
INFO - 2018-03-20 16:55:05 --> Database Driver Class Initialized
DEBUG - 2018-03-20 16:55:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 16:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 16:55:05 --> Helper loaded: form_helper
INFO - 2018-03-20 16:55:05 --> Form Validation Class Initialized
INFO - 2018-03-20 16:55:05 --> Controller Class Initialized
INFO - 2018-03-20 16:55:05 --> Model Class Initialized
INFO - 2018-03-20 16:55:05 --> Helper loaded: inflector_helper
DEBUG - 2018-03-20 16:55:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 16:55:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 16:55:05 --> Model Class Initialized
INFO - 2018-03-20 16:55:05 --> Model Class Initialized
INFO - 2018-03-20 16:55:05 --> Model Class Initialized
INFO - 2018-03-20 16:55:05 --> Model Class Initialized
INFO - 2018-03-20 16:55:05 --> Model Class Initialized
INFO - 2018-03-20 16:55:05 --> Model Class Initialized
INFO - 2018-03-20 16:55:05 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-20 16:55:05 --> Final output sent to browser
DEBUG - 2018-03-20 16:55:05 --> Total execution time: 2.7058
INFO - 2018-03-20 14:01:36 --> Config Class Initialized
INFO - 2018-03-20 14:01:36 --> Hooks Class Initialized
DEBUG - 2018-03-20 14:01:36 --> UTF-8 Support Enabled
INFO - 2018-03-20 14:01:36 --> Utf8 Class Initialized
INFO - 2018-03-20 14:01:36 --> URI Class Initialized
INFO - 2018-03-20 14:01:36 --> Router Class Initialized
INFO - 2018-03-20 14:01:36 --> Output Class Initialized
INFO - 2018-03-20 14:01:36 --> Security Class Initialized
DEBUG - 2018-03-20 14:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 14:01:36 --> Input Class Initialized
INFO - 2018-03-20 14:01:36 --> Language Class Initialized
INFO - 2018-03-20 14:01:36 --> Config Class Initialized
INFO - 2018-03-20 14:01:36 --> Hooks Class Initialized
INFO - 2018-03-20 14:01:36 --> Language Class Initialized
INFO - 2018-03-20 14:01:36 --> Config Class Initialized
INFO - 2018-03-20 14:01:36 --> Loader Class Initialized
INFO - 2018-03-20 19:31:36 --> Helper loaded: url_helper
INFO - 2018-03-20 19:31:36 --> Helper loaded: notification_helper
INFO - 2018-03-20 19:31:36 --> Helper loaded: settings_helper
INFO - 2018-03-20 19:31:36 --> Helper loaded: permission_helper
INFO - 2018-03-20 19:31:36 --> Helper loaded: users_helper
DEBUG - 2018-03-20 14:01:36 --> UTF-8 Support Enabled
INFO - 2018-03-20 14:01:36 --> Utf8 Class Initialized
INFO - 2018-03-20 14:01:36 --> Config Class Initialized
INFO - 2018-03-20 14:01:36 --> Hooks Class Initialized
DEBUG - 2018-03-20 14:01:36 --> UTF-8 Support Enabled
INFO - 2018-03-20 14:01:36 --> Utf8 Class Initialized
INFO - 2018-03-20 14:01:36 --> URI Class Initialized
INFO - 2018-03-20 14:01:36 --> URI Class Initialized
INFO - 2018-03-20 14:01:36 --> Router Class Initialized
INFO - 2018-03-20 19:31:36 --> Database Driver Class Initialized
INFO - 2018-03-20 14:01:36 --> Output Class Initialized
INFO - 2018-03-20 14:01:36 --> Security Class Initialized
INFO - 2018-03-20 14:01:36 --> Router Class Initialized
DEBUG - 2018-03-20 19:31:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 19:31:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-03-20 14:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 14:01:36 --> Input Class Initialized
INFO - 2018-03-20 14:01:36 --> Language Class Initialized
INFO - 2018-03-20 14:01:36 --> Output Class Initialized
INFO - 2018-03-20 19:31:36 --> Helper loaded: form_helper
INFO - 2018-03-20 19:31:36 --> Form Validation Class Initialized
INFO - 2018-03-20 19:31:36 --> Controller Class Initialized
INFO - 2018-03-20 14:01:36 --> Security Class Initialized
DEBUG - 2018-03-20 14:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 14:01:36 --> Input Class Initialized
INFO - 2018-03-20 14:01:36 --> Language Class Initialized
INFO - 2018-03-20 14:01:36 --> Config Class Initialized
INFO - 2018-03-20 14:01:36 --> Hooks Class Initialized
INFO - 2018-03-20 19:31:36 --> Model Class Initialized
INFO - 2018-03-20 19:31:36 --> Helper loaded: inflector_helper
DEBUG - 2018-03-20 14:01:36 --> UTF-8 Support Enabled
INFO - 2018-03-20 14:01:36 --> Utf8 Class Initialized
INFO - 2018-03-20 14:01:36 --> Config Class Initialized
INFO - 2018-03-20 14:01:36 --> Hooks Class Initialized
INFO - 2018-03-20 14:01:36 --> URI Class Initialized
INFO - 2018-03-20 14:01:36 --> Language Class Initialized
INFO - 2018-03-20 14:01:36 --> Config Class Initialized
INFO - 2018-03-20 14:01:36 --> Loader Class Initialized
INFO - 2018-03-20 19:31:36 --> Helper loaded: url_helper
INFO - 2018-03-20 14:01:37 --> Router Class Initialized
DEBUG - 2018-03-20 19:31:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 19:31:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 19:31:37 --> Helper loaded: notification_helper
INFO - 2018-03-20 19:31:37 --> Helper loaded: settings_helper
INFO - 2018-03-20 19:31:37 --> Helper loaded: permission_helper
INFO - 2018-03-20 19:31:37 --> Helper loaded: users_helper
INFO - 2018-03-20 14:01:37 --> Output Class Initialized
INFO - 2018-03-20 19:31:37 --> Model Class Initialized
INFO - 2018-03-20 19:31:37 --> Model Class Initialized
INFO - 2018-03-20 14:01:37 --> Security Class Initialized
INFO - 2018-03-20 19:31:37 --> Model Class Initialized
INFO - 2018-03-20 19:31:37 --> Model Class Initialized
INFO - 2018-03-20 19:31:37 --> Model Class Initialized
INFO - 2018-03-20 19:31:37 --> Model Class Initialized
INFO - 2018-03-20 19:31:37 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-03-20 14:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 14:01:37 --> Input Class Initialized
INFO - 2018-03-20 19:31:37 --> Final output sent to browser
DEBUG - 2018-03-20 19:31:37 --> Total execution time: 0.6317
INFO - 2018-03-20 14:01:37 --> Language Class Initialized
DEBUG - 2018-03-20 14:01:37 --> UTF-8 Support Enabled
INFO - 2018-03-20 14:01:37 --> Utf8 Class Initialized
INFO - 2018-03-20 14:01:37 --> URI Class Initialized
INFO - 2018-03-20 14:01:37 --> Router Class Initialized
INFO - 2018-03-20 14:01:37 --> Output Class Initialized
INFO - 2018-03-20 14:01:37 --> Security Class Initialized
DEBUG - 2018-03-20 14:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 14:01:37 --> Input Class Initialized
INFO - 2018-03-20 14:01:37 --> Language Class Initialized
INFO - 2018-03-20 19:31:37 --> Database Driver Class Initialized
INFO - 2018-03-20 14:01:37 --> Language Class Initialized
INFO - 2018-03-20 14:01:37 --> Config Class Initialized
INFO - 2018-03-20 14:01:37 --> Loader Class Initialized
INFO - 2018-03-20 19:31:37 --> Helper loaded: url_helper
INFO - 2018-03-20 19:31:37 --> Helper loaded: notification_helper
INFO - 2018-03-20 19:31:37 --> Helper loaded: settings_helper
INFO - 2018-03-20 19:31:37 --> Helper loaded: permission_helper
INFO - 2018-03-20 19:31:37 --> Helper loaded: users_helper
INFO - 2018-03-20 19:31:37 --> Database Driver Class Initialized
DEBUG - 2018-03-20 19:31:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 19:31:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 19:31:37 --> Helper loaded: form_helper
INFO - 2018-03-20 19:31:37 --> Form Validation Class Initialized
INFO - 2018-03-20 19:31:37 --> Controller Class Initialized
DEBUG - 2018-03-20 19:31:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 19:31:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 19:31:37 --> Model Class Initialized
INFO - 2018-03-20 19:31:37 --> Helper loaded: inflector_helper
DEBUG - 2018-03-20 19:31:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 19:31:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 19:31:37 --> Model Class Initialized
INFO - 2018-03-20 19:31:37 --> Model Class Initialized
INFO - 2018-03-20 19:31:37 --> Model Class Initialized
INFO - 2018-03-20 19:31:37 --> Model Class Initialized
INFO - 2018-03-20 19:31:37 --> Model Class Initialized
INFO - 2018-03-20 19:31:37 --> Model Class Initialized
INFO - 2018-03-20 19:31:37 --> Model Class Initialized
INFO - 2018-03-20 19:31:37 --> Model Class Initialized
INFO - 2018-03-20 19:31:37 --> Model Class Initialized
INFO - 2018-03-20 19:31:37 --> Model Class Initialized
INFO - 2018-03-20 19:31:37 --> Model Class Initialized
INFO - 2018-03-20 19:31:37 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-20 19:31:37 --> Model Class Initialized
INFO - 2018-03-20 14:01:37 --> Language Class Initialized
INFO - 2018-03-20 14:01:37 --> Config Class Initialized
INFO - 2018-03-20 14:01:37 --> Loader Class Initialized
INFO - 2018-03-20 19:31:37 --> Final output sent to browser
DEBUG - 2018-03-20 19:31:37 --> Total execution time: 0.3955
INFO - 2018-03-20 19:31:37 --> Helper loaded: form_helper
INFO - 2018-03-20 19:31:37 --> Form Validation Class Initialized
INFO - 2018-03-20 19:31:37 --> Controller Class Initialized
INFO - 2018-03-20 19:31:37 --> Helper loaded: url_helper
INFO - 2018-03-20 19:31:37 --> Helper loaded: notification_helper
INFO - 2018-03-20 19:31:37 --> Helper loaded: settings_helper
INFO - 2018-03-20 19:31:37 --> Helper loaded: permission_helper
INFO - 2018-03-20 19:31:37 --> Helper loaded: users_helper
INFO - 2018-03-20 19:31:37 --> Model Class Initialized
INFO - 2018-03-20 19:31:37 --> Helper loaded: inflector_helper
DEBUG - 2018-03-20 19:31:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 19:31:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 19:31:37 --> Model Class Initialized
INFO - 2018-03-20 19:31:37 --> Model Class Initialized
INFO - 2018-03-20 19:31:37 --> Model Class Initialized
INFO - 2018-03-20 19:31:37 --> Model Class Initialized
INFO - 2018-03-20 19:31:37 --> Model Class Initialized
INFO - 2018-03-20 19:31:37 --> Model Class Initialized
INFO - 2018-03-20 19:31:37 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-20 19:31:37 --> Model Class Initialized
INFO - 2018-03-20 19:31:37 --> Final output sent to browser
DEBUG - 2018-03-20 19:31:37 --> Total execution time: 0.8184
INFO - 2018-03-20 19:31:37 --> Database Driver Class Initialized
DEBUG - 2018-03-20 19:31:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 19:31:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 19:31:37 --> Helper loaded: form_helper
INFO - 2018-03-20 19:31:37 --> Form Validation Class Initialized
INFO - 2018-03-20 19:31:37 --> Controller Class Initialized
INFO - 2018-03-20 19:31:37 --> Model Class Initialized
INFO - 2018-03-20 19:31:37 --> Helper loaded: inflector_helper
DEBUG - 2018-03-20 19:31:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 19:31:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 19:31:37 --> Model Class Initialized
INFO - 2018-03-20 19:31:37 --> Model Class Initialized
INFO - 2018-03-20 19:31:37 --> Model Class Initialized
INFO - 2018-03-20 19:31:37 --> Model Class Initialized
INFO - 2018-03-20 19:31:37 --> Model Class Initialized
INFO - 2018-03-20 19:31:37 --> Model Class Initialized
INFO - 2018-03-20 19:31:37 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-20 19:31:37 --> Model Class Initialized
INFO - 2018-03-20 19:31:37 --> Final output sent to browser
DEBUG - 2018-03-20 19:31:37 --> Total execution time: 0.8091
INFO - 2018-03-20 14:01:37 --> Language Class Initialized
INFO - 2018-03-20 14:01:37 --> Config Class Initialized
INFO - 2018-03-20 14:01:37 --> Loader Class Initialized
INFO - 2018-03-20 19:31:37 --> Helper loaded: url_helper
INFO - 2018-03-20 19:31:37 --> Helper loaded: notification_helper
INFO - 2018-03-20 19:31:37 --> Helper loaded: settings_helper
INFO - 2018-03-20 19:31:37 --> Helper loaded: permission_helper
INFO - 2018-03-20 19:31:37 --> Helper loaded: users_helper
INFO - 2018-03-20 19:31:37 --> Database Driver Class Initialized
DEBUG - 2018-03-20 19:31:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 19:31:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 19:31:37 --> Helper loaded: form_helper
INFO - 2018-03-20 19:31:37 --> Form Validation Class Initialized
INFO - 2018-03-20 19:31:37 --> Controller Class Initialized
INFO - 2018-03-20 19:31:38 --> Model Class Initialized
INFO - 2018-03-20 19:31:38 --> Helper loaded: inflector_helper
DEBUG - 2018-03-20 19:31:38 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 19:31:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 19:31:38 --> Model Class Initialized
INFO - 2018-03-20 19:31:38 --> Model Class Initialized
INFO - 2018-03-20 19:31:38 --> Model Class Initialized
INFO - 2018-03-20 19:31:38 --> Model Class Initialized
INFO - 2018-03-20 19:31:38 --> Model Class Initialized
INFO - 2018-03-20 19:31:38 --> Model Class Initialized
INFO - 2018-03-20 19:31:38 --> Model Class Initialized
INFO - 2018-03-20 19:31:38 --> Model Class Initialized
INFO - 2018-03-20 19:31:38 --> Model Class Initialized
INFO - 2018-03-20 19:31:38 --> Model Class Initialized
INFO - 2018-03-20 19:31:38 --> Model Class Initialized
INFO - 2018-03-20 19:31:38 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-20 19:31:38 --> Model Class Initialized
INFO - 2018-03-20 19:31:39 --> Final output sent to browser
DEBUG - 2018-03-20 19:31:39 --> Total execution time: 3.0521
INFO - 2018-03-20 14:01:39 --> Config Class Initialized
INFO - 2018-03-20 14:01:39 --> Hooks Class Initialized
DEBUG - 2018-03-20 14:01:39 --> UTF-8 Support Enabled
INFO - 2018-03-20 14:01:39 --> Utf8 Class Initialized
INFO - 2018-03-20 14:01:39 --> URI Class Initialized
INFO - 2018-03-20 14:01:39 --> Router Class Initialized
INFO - 2018-03-20 14:01:39 --> Output Class Initialized
INFO - 2018-03-20 14:01:39 --> Security Class Initialized
DEBUG - 2018-03-20 14:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 14:01:39 --> Input Class Initialized
INFO - 2018-03-20 14:01:39 --> Language Class Initialized
INFO - 2018-03-20 14:01:39 --> Language Class Initialized
INFO - 2018-03-20 14:01:39 --> Config Class Initialized
INFO - 2018-03-20 14:01:39 --> Loader Class Initialized
INFO - 2018-03-20 19:31:39 --> Helper loaded: url_helper
INFO - 2018-03-20 19:31:39 --> Helper loaded: notification_helper
INFO - 2018-03-20 19:31:39 --> Helper loaded: settings_helper
INFO - 2018-03-20 19:31:39 --> Helper loaded: permission_helper
INFO - 2018-03-20 19:31:39 --> Helper loaded: users_helper
INFO - 2018-03-20 19:31:39 --> Database Driver Class Initialized
DEBUG - 2018-03-20 19:31:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 19:31:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 19:31:40 --> Helper loaded: form_helper
INFO - 2018-03-20 19:31:40 --> Form Validation Class Initialized
INFO - 2018-03-20 19:31:40 --> Controller Class Initialized
INFO - 2018-03-20 19:31:40 --> Model Class Initialized
INFO - 2018-03-20 19:31:40 --> Helper loaded: inflector_helper
DEBUG - 2018-03-20 19:31:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 19:31:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 19:31:40 --> Model Class Initialized
INFO - 2018-03-20 19:31:40 --> Model Class Initialized
INFO - 2018-03-20 19:31:40 --> Model Class Initialized
INFO - 2018-03-20 19:31:40 --> Model Class Initialized
INFO - 2018-03-20 19:31:40 --> Model Class Initialized
INFO - 2018-03-20 19:31:40 --> Model Class Initialized
INFO - 2018-03-20 19:31:40 --> Model Class Initialized
INFO - 2018-03-20 19:31:40 --> Model Class Initialized
INFO - 2018-03-20 19:31:40 --> Model Class Initialized
INFO - 2018-03-20 19:31:40 --> Model Class Initialized
INFO - 2018-03-20 19:31:40 --> Model Class Initialized
INFO - 2018-03-20 19:31:40 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-20 19:31:40 --> Model Class Initialized
INFO - 2018-03-20 19:31:40 --> Final output sent to browser
DEBUG - 2018-03-20 19:31:40 --> Total execution time: 0.4444
INFO - 2018-03-20 14:01:44 --> Config Class Initialized
INFO - 2018-03-20 14:01:44 --> Hooks Class Initialized
DEBUG - 2018-03-20 14:01:44 --> UTF-8 Support Enabled
INFO - 2018-03-20 14:01:44 --> Utf8 Class Initialized
INFO - 2018-03-20 14:01:44 --> URI Class Initialized
INFO - 2018-03-20 14:01:44 --> Router Class Initialized
INFO - 2018-03-20 14:01:44 --> Output Class Initialized
INFO - 2018-03-20 14:01:44 --> Security Class Initialized
DEBUG - 2018-03-20 14:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 14:01:44 --> Input Class Initialized
INFO - 2018-03-20 14:01:44 --> Language Class Initialized
INFO - 2018-03-20 14:01:44 --> Language Class Initialized
INFO - 2018-03-20 14:01:44 --> Config Class Initialized
INFO - 2018-03-20 14:01:44 --> Loader Class Initialized
INFO - 2018-03-20 19:31:45 --> Helper loaded: url_helper
INFO - 2018-03-20 19:31:45 --> Helper loaded: notification_helper
INFO - 2018-03-20 19:31:45 --> Helper loaded: settings_helper
INFO - 2018-03-20 19:31:45 --> Helper loaded: permission_helper
INFO - 2018-03-20 19:31:45 --> Helper loaded: users_helper
INFO - 2018-03-20 19:31:45 --> Database Driver Class Initialized
DEBUG - 2018-03-20 19:31:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 19:31:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 19:31:45 --> Helper loaded: form_helper
INFO - 2018-03-20 19:31:45 --> Form Validation Class Initialized
INFO - 2018-03-20 19:31:45 --> Controller Class Initialized
INFO - 2018-03-20 19:31:45 --> Model Class Initialized
INFO - 2018-03-20 19:31:45 --> Helper loaded: inflector_helper
DEBUG - 2018-03-20 19:31:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 19:31:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 19:31:45 --> Model Class Initialized
INFO - 2018-03-20 19:31:45 --> Model Class Initialized
INFO - 2018-03-20 19:31:45 --> Model Class Initialized
INFO - 2018-03-20 19:31:45 --> Model Class Initialized
INFO - 2018-03-20 19:31:45 --> Model Class Initialized
INFO - 2018-03-20 19:31:45 --> Model Class Initialized
INFO - 2018-03-20 19:31:45 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-20 19:31:45 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-20 19:31:45 --> Final output sent to browser
DEBUG - 2018-03-20 19:31:45 --> Total execution time: 0.3282
INFO - 2018-03-20 14:01:49 --> Config Class Initialized
INFO - 2018-03-20 14:01:49 --> Hooks Class Initialized
DEBUG - 2018-03-20 14:01:49 --> UTF-8 Support Enabled
INFO - 2018-03-20 14:01:49 --> Utf8 Class Initialized
INFO - 2018-03-20 14:01:49 --> URI Class Initialized
INFO - 2018-03-20 14:01:49 --> Router Class Initialized
INFO - 2018-03-20 14:01:49 --> Output Class Initialized
INFO - 2018-03-20 14:01:49 --> Security Class Initialized
DEBUG - 2018-03-20 14:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 14:01:49 --> Input Class Initialized
INFO - 2018-03-20 14:01:49 --> Language Class Initialized
INFO - 2018-03-20 14:01:49 --> Language Class Initialized
INFO - 2018-03-20 14:01:49 --> Config Class Initialized
INFO - 2018-03-20 14:01:49 --> Loader Class Initialized
INFO - 2018-03-20 19:31:49 --> Helper loaded: url_helper
INFO - 2018-03-20 19:31:49 --> Helper loaded: notification_helper
INFO - 2018-03-20 19:31:49 --> Helper loaded: settings_helper
INFO - 2018-03-20 19:31:49 --> Helper loaded: permission_helper
INFO - 2018-03-20 19:31:49 --> Helper loaded: users_helper
INFO - 2018-03-20 19:31:50 --> Database Driver Class Initialized
DEBUG - 2018-03-20 19:31:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 19:31:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 19:31:51 --> Helper loaded: form_helper
INFO - 2018-03-20 19:31:51 --> Form Validation Class Initialized
INFO - 2018-03-20 19:31:51 --> Controller Class Initialized
INFO - 2018-03-20 19:31:51 --> Model Class Initialized
INFO - 2018-03-20 19:31:51 --> Helper loaded: inflector_helper
DEBUG - 2018-03-20 19:31:51 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-20 19:31:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-20 19:31:51 --> Model Class Initialized
INFO - 2018-03-20 19:31:51 --> Model Class Initialized
INFO - 2018-03-20 19:31:51 --> Model Class Initialized
INFO - 2018-03-20 19:31:51 --> Model Class Initialized
INFO - 2018-03-20 19:31:51 --> Model Class Initialized
INFO - 2018-03-20 19:31:51 --> Model Class Initialized
INFO - 2018-03-20 19:31:51 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-20 19:31:51 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-20 19:31:51 --> Final output sent to browser
DEBUG - 2018-03-20 19:31:51 --> Total execution time: 2.0918
