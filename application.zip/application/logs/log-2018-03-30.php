<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-03-30 09:14:31 --> Config Class Initialized
INFO - 2018-03-30 09:14:31 --> Hooks Class Initialized
DEBUG - 2018-03-30 09:14:31 --> UTF-8 Support Enabled
INFO - 2018-03-30 09:14:31 --> Utf8 Class Initialized
INFO - 2018-03-30 09:14:31 --> URI Class Initialized
INFO - 2018-03-30 09:14:31 --> Router Class Initialized
INFO - 2018-03-30 09:14:31 --> Output Class Initialized
INFO - 2018-03-30 09:14:31 --> Security Class Initialized
DEBUG - 2018-03-30 09:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 09:14:31 --> Input Class Initialized
INFO - 2018-03-30 09:14:31 --> Language Class Initialized
INFO - 2018-03-30 09:14:31 --> Language Class Initialized
INFO - 2018-03-30 09:14:31 --> Config Class Initialized
INFO - 2018-03-30 09:14:31 --> Loader Class Initialized
INFO - 2018-03-30 14:44:31 --> Helper loaded: url_helper
INFO - 2018-03-30 14:44:31 --> Helper loaded: notification_helper
INFO - 2018-03-30 14:44:31 --> Helper loaded: settings_helper
INFO - 2018-03-30 14:44:31 --> Helper loaded: permission_helper
INFO - 2018-03-30 14:44:31 --> Helper loaded: users_helper
INFO - 2018-03-30 14:44:31 --> Database Driver Class Initialized
DEBUG - 2018-03-30 14:44:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 14:44:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 14:44:32 --> Helper loaded: form_helper
INFO - 2018-03-30 14:44:32 --> Form Validation Class Initialized
INFO - 2018-03-30 14:44:32 --> Controller Class Initialized
INFO - 2018-03-30 14:44:32 --> Model Class Initialized
INFO - 2018-03-30 14:44:32 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 14:44:32 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 14:44:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 14:44:32 --> Model Class Initialized
INFO - 2018-03-30 14:44:32 --> Model Class Initialized
INFO - 2018-03-30 14:44:32 --> Model Class Initialized
INFO - 2018-03-30 14:44:32 --> Model Class Initialized
INFO - 2018-03-30 14:44:32 --> Model Class Initialized
INFO - 2018-03-30 14:44:32 --> Model Class Initialized
INFO - 2018-03-30 14:44:32 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-30 14:44:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-30 14:44:32 --> Final output sent to browser
DEBUG - 2018-03-30 14:44:32 --> Total execution time: 0.2541
INFO - 2018-03-30 09:14:33 --> Config Class Initialized
INFO - 2018-03-30 09:14:33 --> Hooks Class Initialized
DEBUG - 2018-03-30 09:14:33 --> UTF-8 Support Enabled
INFO - 2018-03-30 09:14:33 --> Utf8 Class Initialized
INFO - 2018-03-30 09:14:33 --> URI Class Initialized
INFO - 2018-03-30 09:14:33 --> Router Class Initialized
INFO - 2018-03-30 09:14:33 --> Output Class Initialized
INFO - 2018-03-30 09:14:33 --> Security Class Initialized
DEBUG - 2018-03-30 09:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 09:14:33 --> Input Class Initialized
INFO - 2018-03-30 09:14:33 --> Language Class Initialized
INFO - 2018-03-30 09:14:33 --> Language Class Initialized
INFO - 2018-03-30 09:14:33 --> Config Class Initialized
INFO - 2018-03-30 09:14:33 --> Loader Class Initialized
INFO - 2018-03-30 14:44:33 --> Helper loaded: url_helper
INFO - 2018-03-30 14:44:33 --> Helper loaded: notification_helper
INFO - 2018-03-30 14:44:33 --> Helper loaded: settings_helper
INFO - 2018-03-30 14:44:33 --> Helper loaded: permission_helper
INFO - 2018-03-30 14:44:33 --> Helper loaded: users_helper
INFO - 2018-03-30 14:44:33 --> Database Driver Class Initialized
DEBUG - 2018-03-30 14:44:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 14:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 14:44:33 --> Helper loaded: form_helper
INFO - 2018-03-30 14:44:33 --> Form Validation Class Initialized
INFO - 2018-03-30 14:44:33 --> Controller Class Initialized
INFO - 2018-03-30 14:44:33 --> Model Class Initialized
INFO - 2018-03-30 14:44:33 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 14:44:33 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 14:44:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 14:44:33 --> Model Class Initialized
INFO - 2018-03-30 14:44:33 --> Model Class Initialized
INFO - 2018-03-30 14:44:33 --> Model Class Initialized
INFO - 2018-03-30 14:44:33 --> Model Class Initialized
INFO - 2018-03-30 14:44:33 --> Model Class Initialized
INFO - 2018-03-30 14:44:33 --> Model Class Initialized
INFO - 2018-03-30 14:44:33 --> Model Class Initialized
INFO - 2018-03-30 14:44:33 --> Model Class Initialized
INFO - 2018-03-30 14:44:33 --> Model Class Initialized
INFO - 2018-03-30 14:44:33 --> Model Class Initialized
INFO - 2018-03-30 14:44:33 --> Model Class Initialized
INFO - 2018-03-30 14:44:33 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-30 14:44:33 --> Model Class Initialized
INFO - 2018-03-30 14:44:33 --> Final output sent to browser
DEBUG - 2018-03-30 14:44:33 --> Total execution time: 0.2585
INFO - 2018-03-30 09:14:33 --> Config Class Initialized
INFO - 2018-03-30 09:14:33 --> Hooks Class Initialized
DEBUG - 2018-03-30 09:14:33 --> UTF-8 Support Enabled
INFO - 2018-03-30 09:14:33 --> Utf8 Class Initialized
INFO - 2018-03-30 09:14:33 --> URI Class Initialized
INFO - 2018-03-30 09:14:33 --> Router Class Initialized
INFO - 2018-03-30 09:14:33 --> Output Class Initialized
INFO - 2018-03-30 09:14:33 --> Security Class Initialized
DEBUG - 2018-03-30 09:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 09:14:33 --> Input Class Initialized
INFO - 2018-03-30 09:14:33 --> Language Class Initialized
INFO - 2018-03-30 09:14:33 --> Language Class Initialized
INFO - 2018-03-30 09:14:33 --> Config Class Initialized
INFO - 2018-03-30 09:14:33 --> Loader Class Initialized
INFO - 2018-03-30 14:44:33 --> Helper loaded: url_helper
INFO - 2018-03-30 14:44:33 --> Helper loaded: notification_helper
INFO - 2018-03-30 14:44:33 --> Helper loaded: settings_helper
INFO - 2018-03-30 14:44:33 --> Helper loaded: permission_helper
INFO - 2018-03-30 14:44:33 --> Helper loaded: users_helper
INFO - 2018-03-30 14:44:33 --> Database Driver Class Initialized
DEBUG - 2018-03-30 14:44:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 14:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 14:44:33 --> Helper loaded: form_helper
INFO - 2018-03-30 14:44:33 --> Form Validation Class Initialized
INFO - 2018-03-30 14:44:33 --> Controller Class Initialized
INFO - 2018-03-30 14:44:33 --> Model Class Initialized
INFO - 2018-03-30 14:44:33 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 14:44:33 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 14:44:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 14:44:33 --> Model Class Initialized
INFO - 2018-03-30 14:44:33 --> Model Class Initialized
INFO - 2018-03-30 14:44:33 --> Model Class Initialized
INFO - 2018-03-30 14:44:33 --> Model Class Initialized
INFO - 2018-03-30 14:44:33 --> Model Class Initialized
INFO - 2018-03-30 14:44:33 --> Model Class Initialized
INFO - 2018-03-30 14:44:33 --> Model Class Initialized
INFO - 2018-03-30 14:44:33 --> Model Class Initialized
INFO - 2018-03-30 14:44:33 --> Model Class Initialized
INFO - 2018-03-30 14:44:33 --> Model Class Initialized
INFO - 2018-03-30 14:44:33 --> Model Class Initialized
INFO - 2018-03-30 14:44:33 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-30 14:44:33 --> Model Class Initialized
INFO - 2018-03-30 14:44:33 --> Final output sent to browser
DEBUG - 2018-03-30 14:44:33 --> Total execution time: 0.1943
INFO - 2018-03-30 09:14:45 --> Config Class Initialized
INFO - 2018-03-30 09:14:45 --> Hooks Class Initialized
DEBUG - 2018-03-30 09:14:45 --> UTF-8 Support Enabled
INFO - 2018-03-30 09:14:45 --> Utf8 Class Initialized
INFO - 2018-03-30 09:14:45 --> URI Class Initialized
INFO - 2018-03-30 09:14:45 --> Router Class Initialized
INFO - 2018-03-30 09:14:45 --> Output Class Initialized
INFO - 2018-03-30 09:14:45 --> Security Class Initialized
DEBUG - 2018-03-30 09:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 09:14:45 --> Input Class Initialized
INFO - 2018-03-30 09:14:45 --> Language Class Initialized
INFO - 2018-03-30 09:14:45 --> Language Class Initialized
INFO - 2018-03-30 09:14:45 --> Config Class Initialized
INFO - 2018-03-30 09:14:45 --> Loader Class Initialized
INFO - 2018-03-30 14:44:45 --> Helper loaded: url_helper
INFO - 2018-03-30 14:44:45 --> Helper loaded: notification_helper
INFO - 2018-03-30 14:44:45 --> Helper loaded: settings_helper
INFO - 2018-03-30 14:44:45 --> Helper loaded: permission_helper
INFO - 2018-03-30 14:44:45 --> Helper loaded: users_helper
INFO - 2018-03-30 14:44:45 --> Database Driver Class Initialized
DEBUG - 2018-03-30 14:44:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 14:44:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 14:44:45 --> Helper loaded: form_helper
INFO - 2018-03-30 14:44:45 --> Form Validation Class Initialized
INFO - 2018-03-30 14:44:45 --> Controller Class Initialized
INFO - 2018-03-30 09:14:45 --> Config Class Initialized
INFO - 2018-03-30 09:14:45 --> Hooks Class Initialized
DEBUG - 2018-03-30 09:14:45 --> UTF-8 Support Enabled
INFO - 2018-03-30 09:14:45 --> Utf8 Class Initialized
INFO - 2018-03-30 09:14:45 --> URI Class Initialized
INFO - 2018-03-30 09:14:45 --> Router Class Initialized
INFO - 2018-03-30 09:14:45 --> Output Class Initialized
INFO - 2018-03-30 09:14:45 --> Security Class Initialized
DEBUG - 2018-03-30 09:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 09:14:45 --> Input Class Initialized
INFO - 2018-03-30 09:14:45 --> Language Class Initialized
INFO - 2018-03-30 14:44:45 --> Model Class Initialized
INFO - 2018-03-30 14:44:45 --> Helper loaded: inflector_helper
INFO - 2018-03-30 09:14:45 --> Language Class Initialized
INFO - 2018-03-30 09:14:45 --> Config Class Initialized
INFO - 2018-03-30 09:14:45 --> Loader Class Initialized
INFO - 2018-03-30 14:44:45 --> Helper loaded: url_helper
INFO - 2018-03-30 14:44:45 --> Helper loaded: notification_helper
INFO - 2018-03-30 14:44:45 --> Helper loaded: settings_helper
INFO - 2018-03-30 14:44:45 --> Helper loaded: permission_helper
INFO - 2018-03-30 14:44:45 --> Helper loaded: users_helper
DEBUG - 2018-03-30 14:44:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 14:44:45 --> Database Driver Class Initialized
DEBUG - 2018-03-30 14:44:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 14:44:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 14:44:45 --> Helper loaded: form_helper
INFO - 2018-03-30 14:44:45 --> Form Validation Class Initialized
INFO - 2018-03-30 14:44:45 --> Controller Class Initialized
INFO - 2018-03-30 14:44:45 --> Model Class Initialized
INFO - 2018-03-30 14:44:45 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 14:44:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 14:44:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 14:44:45 --> Model Class Initialized
INFO - 2018-03-30 14:44:45 --> Model Class Initialized
INFO - 2018-03-30 14:44:45 --> Model Class Initialized
INFO - 2018-03-30 14:44:45 --> Model Class Initialized
INFO - 2018-03-30 14:44:45 --> Model Class Initialized
INFO - 2018-03-30 14:44:45 --> Model Class Initialized
INFO - 2018-03-30 14:44:45 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-30 14:44:45 --> Final output sent to browser
DEBUG - 2018-03-30 14:44:45 --> Total execution time: 0.1215
INFO - 2018-03-30 14:44:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 14:44:46 --> Model Class Initialized
INFO - 2018-03-30 14:44:46 --> Model Class Initialized
INFO - 2018-03-30 14:44:46 --> Model Class Initialized
INFO - 2018-03-30 14:44:46 --> Model Class Initialized
INFO - 2018-03-30 14:44:46 --> Model Class Initialized
INFO - 2018-03-30 14:44:46 --> Model Class Initialized
INFO - 2018-03-30 14:44:46 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-30 14:44:46 --> Final output sent to browser
DEBUG - 2018-03-30 14:44:46 --> Total execution time: 0.9593
INFO - 2018-03-30 09:14:50 --> Config Class Initialized
INFO - 2018-03-30 09:14:50 --> Hooks Class Initialized
DEBUG - 2018-03-30 09:14:50 --> UTF-8 Support Enabled
INFO - 2018-03-30 09:14:50 --> Utf8 Class Initialized
INFO - 2018-03-30 09:14:50 --> URI Class Initialized
INFO - 2018-03-30 09:14:50 --> Router Class Initialized
INFO - 2018-03-30 09:14:50 --> Output Class Initialized
INFO - 2018-03-30 09:14:50 --> Security Class Initialized
DEBUG - 2018-03-30 09:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 09:14:50 --> Input Class Initialized
INFO - 2018-03-30 09:14:50 --> Language Class Initialized
INFO - 2018-03-30 09:14:50 --> Language Class Initialized
INFO - 2018-03-30 09:14:50 --> Config Class Initialized
INFO - 2018-03-30 09:14:50 --> Loader Class Initialized
INFO - 2018-03-30 14:44:50 --> Helper loaded: url_helper
INFO - 2018-03-30 14:44:50 --> Helper loaded: notification_helper
INFO - 2018-03-30 14:44:50 --> Helper loaded: settings_helper
INFO - 2018-03-30 14:44:50 --> Helper loaded: permission_helper
INFO - 2018-03-30 14:44:50 --> Helper loaded: users_helper
INFO - 2018-03-30 14:44:50 --> Database Driver Class Initialized
DEBUG - 2018-03-30 14:44:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 14:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 14:44:50 --> Helper loaded: form_helper
INFO - 2018-03-30 14:44:50 --> Form Validation Class Initialized
INFO - 2018-03-30 14:44:50 --> Controller Class Initialized
INFO - 2018-03-30 14:44:50 --> Model Class Initialized
INFO - 2018-03-30 14:44:50 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 14:44:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 14:44:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 14:44:50 --> Model Class Initialized
INFO - 2018-03-30 14:44:50 --> Model Class Initialized
INFO - 2018-03-30 14:44:50 --> Final output sent to browser
DEBUG - 2018-03-30 14:44:50 --> Total execution time: 0.6441
INFO - 2018-03-30 09:14:53 --> Config Class Initialized
INFO - 2018-03-30 09:14:53 --> Hooks Class Initialized
DEBUG - 2018-03-30 09:14:53 --> UTF-8 Support Enabled
INFO - 2018-03-30 09:14:53 --> Utf8 Class Initialized
INFO - 2018-03-30 09:14:53 --> URI Class Initialized
INFO - 2018-03-30 09:14:53 --> Router Class Initialized
INFO - 2018-03-30 09:14:53 --> Output Class Initialized
INFO - 2018-03-30 09:14:53 --> Security Class Initialized
DEBUG - 2018-03-30 09:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 09:14:53 --> Input Class Initialized
INFO - 2018-03-30 09:14:53 --> Language Class Initialized
INFO - 2018-03-30 09:14:54 --> Language Class Initialized
INFO - 2018-03-30 09:14:54 --> Config Class Initialized
INFO - 2018-03-30 09:14:54 --> Loader Class Initialized
INFO - 2018-03-30 14:44:54 --> Helper loaded: url_helper
INFO - 2018-03-30 14:44:54 --> Helper loaded: notification_helper
INFO - 2018-03-30 14:44:54 --> Helper loaded: settings_helper
INFO - 2018-03-30 14:44:54 --> Helper loaded: permission_helper
INFO - 2018-03-30 14:44:54 --> Helper loaded: users_helper
INFO - 2018-03-30 14:44:54 --> Database Driver Class Initialized
DEBUG - 2018-03-30 14:44:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 14:44:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 14:44:54 --> Helper loaded: form_helper
INFO - 2018-03-30 14:44:54 --> Form Validation Class Initialized
INFO - 2018-03-30 14:44:54 --> Controller Class Initialized
INFO - 2018-03-30 14:44:54 --> Model Class Initialized
INFO - 2018-03-30 14:44:54 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 14:44:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 14:44:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 14:44:54 --> Model Class Initialized
INFO - 2018-03-30 14:44:54 --> Model Class Initialized
INFO - 2018-03-30 14:44:54 --> Model Class Initialized
INFO - 2018-03-30 14:44:54 --> Model Class Initialized
INFO - 2018-03-30 14:44:54 --> Model Class Initialized
INFO - 2018-03-30 14:44:54 --> Model Class Initialized
INFO - 2018-03-30 14:44:54 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-30 14:44:54 --> Final output sent to browser
DEBUG - 2018-03-30 14:44:54 --> Total execution time: 1.4480
INFO - 2018-03-30 09:14:59 --> Config Class Initialized
INFO - 2018-03-30 09:14:59 --> Hooks Class Initialized
DEBUG - 2018-03-30 09:14:59 --> UTF-8 Support Enabled
INFO - 2018-03-30 09:14:59 --> Utf8 Class Initialized
INFO - 2018-03-30 09:14:59 --> URI Class Initialized
INFO - 2018-03-30 09:14:59 --> Router Class Initialized
INFO - 2018-03-30 09:14:59 --> Output Class Initialized
INFO - 2018-03-30 09:14:59 --> Security Class Initialized
DEBUG - 2018-03-30 09:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 09:14:59 --> Input Class Initialized
INFO - 2018-03-30 09:14:59 --> Language Class Initialized
INFO - 2018-03-30 09:14:59 --> Language Class Initialized
INFO - 2018-03-30 09:14:59 --> Config Class Initialized
INFO - 2018-03-30 09:14:59 --> Loader Class Initialized
INFO - 2018-03-30 14:44:59 --> Helper loaded: url_helper
INFO - 2018-03-30 14:44:59 --> Helper loaded: notification_helper
INFO - 2018-03-30 14:44:59 --> Helper loaded: settings_helper
INFO - 2018-03-30 14:44:59 --> Helper loaded: permission_helper
INFO - 2018-03-30 14:44:59 --> Helper loaded: users_helper
INFO - 2018-03-30 14:44:59 --> Database Driver Class Initialized
DEBUG - 2018-03-30 14:44:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 14:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 14:44:59 --> Helper loaded: form_helper
INFO - 2018-03-30 14:44:59 --> Form Validation Class Initialized
INFO - 2018-03-30 14:44:59 --> Controller Class Initialized
INFO - 2018-03-30 14:44:59 --> Model Class Initialized
INFO - 2018-03-30 14:44:59 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 14:44:59 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 14:44:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 14:44:59 --> Model Class Initialized
INFO - 2018-03-30 14:44:59 --> Model Class Initialized
INFO - 2018-03-30 14:44:59 --> Final output sent to browser
DEBUG - 2018-03-30 14:44:59 --> Total execution time: 0.1123
INFO - 2018-03-30 09:15:43 --> Config Class Initialized
INFO - 2018-03-30 09:15:43 --> Hooks Class Initialized
DEBUG - 2018-03-30 09:15:43 --> UTF-8 Support Enabled
INFO - 2018-03-30 09:15:43 --> Utf8 Class Initialized
INFO - 2018-03-30 09:15:43 --> URI Class Initialized
INFO - 2018-03-30 09:15:43 --> Router Class Initialized
INFO - 2018-03-30 09:15:43 --> Output Class Initialized
INFO - 2018-03-30 09:15:43 --> Security Class Initialized
DEBUG - 2018-03-30 09:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 09:15:43 --> Input Class Initialized
INFO - 2018-03-30 09:15:43 --> Language Class Initialized
INFO - 2018-03-30 09:15:43 --> Language Class Initialized
INFO - 2018-03-30 09:15:43 --> Config Class Initialized
INFO - 2018-03-30 09:15:43 --> Loader Class Initialized
INFO - 2018-03-30 14:45:43 --> Helper loaded: url_helper
INFO - 2018-03-30 14:45:43 --> Helper loaded: notification_helper
INFO - 2018-03-30 14:45:43 --> Helper loaded: settings_helper
INFO - 2018-03-30 14:45:43 --> Helper loaded: permission_helper
INFO - 2018-03-30 14:45:43 --> Helper loaded: users_helper
INFO - 2018-03-30 14:45:43 --> Database Driver Class Initialized
DEBUG - 2018-03-30 14:45:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 14:45:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 14:45:43 --> Helper loaded: form_helper
INFO - 2018-03-30 14:45:43 --> Form Validation Class Initialized
INFO - 2018-03-30 14:45:43 --> Controller Class Initialized
INFO - 2018-03-30 14:45:43 --> Model Class Initialized
INFO - 2018-03-30 14:45:43 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 14:45:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 14:45:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 14:45:43 --> Model Class Initialized
INFO - 2018-03-30 14:45:43 --> Model Class Initialized
INFO - 2018-03-30 14:45:43 --> Final output sent to browser
DEBUG - 2018-03-30 14:45:43 --> Total execution time: 0.3743
INFO - 2018-03-30 09:15:49 --> Config Class Initialized
INFO - 2018-03-30 09:15:49 --> Hooks Class Initialized
DEBUG - 2018-03-30 09:15:49 --> UTF-8 Support Enabled
INFO - 2018-03-30 09:15:49 --> Utf8 Class Initialized
INFO - 2018-03-30 09:15:49 --> URI Class Initialized
INFO - 2018-03-30 09:15:49 --> Router Class Initialized
INFO - 2018-03-30 09:15:49 --> Output Class Initialized
INFO - 2018-03-30 09:15:49 --> Security Class Initialized
DEBUG - 2018-03-30 09:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 09:15:49 --> Input Class Initialized
INFO - 2018-03-30 09:15:49 --> Language Class Initialized
INFO - 2018-03-30 09:15:49 --> Language Class Initialized
INFO - 2018-03-30 09:15:49 --> Config Class Initialized
INFO - 2018-03-30 09:15:49 --> Loader Class Initialized
INFO - 2018-03-30 14:45:49 --> Helper loaded: url_helper
INFO - 2018-03-30 14:45:49 --> Helper loaded: notification_helper
INFO - 2018-03-30 14:45:49 --> Helper loaded: settings_helper
INFO - 2018-03-30 14:45:49 --> Helper loaded: permission_helper
INFO - 2018-03-30 14:45:49 --> Helper loaded: users_helper
INFO - 2018-03-30 14:45:49 --> Database Driver Class Initialized
DEBUG - 2018-03-30 14:45:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 14:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 14:45:49 --> Helper loaded: form_helper
INFO - 2018-03-30 14:45:49 --> Form Validation Class Initialized
INFO - 2018-03-30 14:45:49 --> Controller Class Initialized
INFO - 2018-03-30 14:45:49 --> Model Class Initialized
INFO - 2018-03-30 14:45:49 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 14:45:49 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 14:45:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 14:45:49 --> Model Class Initialized
INFO - 2018-03-30 14:45:49 --> Model Class Initialized
INFO - 2018-03-30 14:45:49 --> Final output sent to browser
DEBUG - 2018-03-30 14:45:49 --> Total execution time: 0.1899
INFO - 2018-03-30 09:15:54 --> Config Class Initialized
INFO - 2018-03-30 09:15:54 --> Hooks Class Initialized
DEBUG - 2018-03-30 09:15:55 --> UTF-8 Support Enabled
INFO - 2018-03-30 09:15:55 --> Utf8 Class Initialized
INFO - 2018-03-30 09:15:55 --> URI Class Initialized
INFO - 2018-03-30 09:15:55 --> Router Class Initialized
INFO - 2018-03-30 09:15:55 --> Output Class Initialized
INFO - 2018-03-30 09:15:55 --> Security Class Initialized
DEBUG - 2018-03-30 09:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 09:15:55 --> Input Class Initialized
INFO - 2018-03-30 09:15:55 --> Language Class Initialized
INFO - 2018-03-30 09:15:56 --> Config Class Initialized
INFO - 2018-03-30 09:15:56 --> Hooks Class Initialized
DEBUG - 2018-03-30 09:15:56 --> UTF-8 Support Enabled
INFO - 2018-03-30 09:15:56 --> Utf8 Class Initialized
INFO - 2018-03-30 09:15:56 --> URI Class Initialized
INFO - 2018-03-30 09:15:56 --> Router Class Initialized
INFO - 2018-03-30 09:15:56 --> Output Class Initialized
INFO - 2018-03-30 09:15:56 --> Security Class Initialized
DEBUG - 2018-03-30 09:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 09:15:56 --> Input Class Initialized
INFO - 2018-03-30 09:15:56 --> Language Class Initialized
INFO - 2018-03-30 09:15:56 --> Language Class Initialized
INFO - 2018-03-30 09:15:56 --> Config Class Initialized
INFO - 2018-03-30 09:15:56 --> Loader Class Initialized
INFO - 2018-03-30 14:45:56 --> Helper loaded: url_helper
INFO - 2018-03-30 14:45:56 --> Helper loaded: notification_helper
INFO - 2018-03-30 14:45:56 --> Helper loaded: settings_helper
INFO - 2018-03-30 14:45:56 --> Helper loaded: permission_helper
INFO - 2018-03-30 14:45:56 --> Helper loaded: users_helper
INFO - 2018-03-30 09:15:56 --> Language Class Initialized
INFO - 2018-03-30 09:15:56 --> Config Class Initialized
INFO - 2018-03-30 09:15:56 --> Loader Class Initialized
INFO - 2018-03-30 14:45:56 --> Database Driver Class Initialized
INFO - 2018-03-30 14:45:56 --> Helper loaded: url_helper
INFO - 2018-03-30 14:45:56 --> Helper loaded: notification_helper
INFO - 2018-03-30 14:45:56 --> Helper loaded: settings_helper
DEBUG - 2018-03-30 14:45:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 14:45:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 14:45:56 --> Helper loaded: permission_helper
INFO - 2018-03-30 14:45:56 --> Helper loaded: form_helper
INFO - 2018-03-30 14:45:56 --> Form Validation Class Initialized
INFO - 2018-03-30 14:45:56 --> Controller Class Initialized
INFO - 2018-03-30 14:45:56 --> Model Class Initialized
INFO - 2018-03-30 14:45:56 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 14:45:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 14:45:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 14:45:56 --> Helper loaded: users_helper
INFO - 2018-03-30 14:45:56 --> Model Class Initialized
INFO - 2018-03-30 14:45:56 --> Model Class Initialized
INFO - 2018-03-30 14:45:56 --> Final output sent to browser
DEBUG - 2018-03-30 14:45:56 --> Total execution time: 0.3879
INFO - 2018-03-30 14:45:57 --> Database Driver Class Initialized
DEBUG - 2018-03-30 14:45:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 14:45:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 14:45:57 --> Helper loaded: form_helper
INFO - 2018-03-30 14:45:57 --> Form Validation Class Initialized
INFO - 2018-03-30 14:45:57 --> Controller Class Initialized
INFO - 2018-03-30 14:45:57 --> Model Class Initialized
INFO - 2018-03-30 14:45:57 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 14:45:57 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 14:45:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 14:45:57 --> Model Class Initialized
INFO - 2018-03-30 14:45:57 --> Model Class Initialized
INFO - 2018-03-30 14:45:57 --> Final output sent to browser
DEBUG - 2018-03-30 14:45:57 --> Total execution time: 2.8578
INFO - 2018-03-30 09:16:05 --> Config Class Initialized
INFO - 2018-03-30 09:16:05 --> Hooks Class Initialized
DEBUG - 2018-03-30 09:16:05 --> UTF-8 Support Enabled
INFO - 2018-03-30 09:16:05 --> Utf8 Class Initialized
INFO - 2018-03-30 09:16:05 --> URI Class Initialized
INFO - 2018-03-30 09:16:05 --> Router Class Initialized
INFO - 2018-03-30 09:16:05 --> Output Class Initialized
INFO - 2018-03-30 09:16:05 --> Security Class Initialized
DEBUG - 2018-03-30 09:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 09:16:05 --> Input Class Initialized
INFO - 2018-03-30 09:16:05 --> Language Class Initialized
INFO - 2018-03-30 09:16:05 --> Language Class Initialized
INFO - 2018-03-30 09:16:05 --> Config Class Initialized
INFO - 2018-03-30 09:16:05 --> Loader Class Initialized
INFO - 2018-03-30 14:46:05 --> Helper loaded: url_helper
INFO - 2018-03-30 14:46:05 --> Helper loaded: notification_helper
INFO - 2018-03-30 14:46:05 --> Helper loaded: settings_helper
INFO - 2018-03-30 14:46:05 --> Helper loaded: permission_helper
INFO - 2018-03-30 14:46:05 --> Helper loaded: users_helper
INFO - 2018-03-30 14:46:05 --> Database Driver Class Initialized
DEBUG - 2018-03-30 14:46:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 14:46:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 14:46:05 --> Helper loaded: form_helper
INFO - 2018-03-30 14:46:05 --> Form Validation Class Initialized
INFO - 2018-03-30 14:46:05 --> Controller Class Initialized
INFO - 2018-03-30 14:46:05 --> Model Class Initialized
INFO - 2018-03-30 14:46:05 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 14:46:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 14:46:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 14:46:05 --> Model Class Initialized
INFO - 2018-03-30 14:46:05 --> Model Class Initialized
INFO - 2018-03-30 14:46:05 --> Final output sent to browser
DEBUG - 2018-03-30 14:46:05 --> Total execution time: 0.1051
INFO - 2018-03-30 09:16:18 --> Config Class Initialized
INFO - 2018-03-30 09:16:18 --> Hooks Class Initialized
DEBUG - 2018-03-30 09:16:18 --> UTF-8 Support Enabled
INFO - 2018-03-30 09:16:18 --> Utf8 Class Initialized
INFO - 2018-03-30 09:16:18 --> URI Class Initialized
INFO - 2018-03-30 09:16:18 --> Router Class Initialized
INFO - 2018-03-30 09:16:19 --> Output Class Initialized
INFO - 2018-03-30 09:16:19 --> Security Class Initialized
DEBUG - 2018-03-30 09:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 09:16:19 --> Input Class Initialized
INFO - 2018-03-30 09:16:19 --> Language Class Initialized
INFO - 2018-03-30 09:16:19 --> Config Class Initialized
INFO - 2018-03-30 09:16:19 --> Hooks Class Initialized
DEBUG - 2018-03-30 09:16:19 --> UTF-8 Support Enabled
INFO - 2018-03-30 09:16:19 --> Utf8 Class Initialized
INFO - 2018-03-30 09:16:19 --> URI Class Initialized
INFO - 2018-03-30 09:16:19 --> Router Class Initialized
INFO - 2018-03-30 09:16:19 --> Output Class Initialized
INFO - 2018-03-30 09:16:19 --> Security Class Initialized
DEBUG - 2018-03-30 09:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 09:16:19 --> Input Class Initialized
INFO - 2018-03-30 09:16:19 --> Language Class Initialized
INFO - 2018-03-30 09:16:19 --> Language Class Initialized
INFO - 2018-03-30 09:16:19 --> Config Class Initialized
INFO - 2018-03-30 09:16:19 --> Loader Class Initialized
INFO - 2018-03-30 14:46:19 --> Helper loaded: url_helper
INFO - 2018-03-30 14:46:19 --> Helper loaded: notification_helper
INFO - 2018-03-30 14:46:19 --> Helper loaded: settings_helper
INFO - 2018-03-30 14:46:19 --> Helper loaded: permission_helper
INFO - 2018-03-30 14:46:19 --> Helper loaded: users_helper
INFO - 2018-03-30 14:46:19 --> Database Driver Class Initialized
DEBUG - 2018-03-30 14:46:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 14:46:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 14:46:19 --> Helper loaded: form_helper
INFO - 2018-03-30 14:46:19 --> Form Validation Class Initialized
INFO - 2018-03-30 14:46:19 --> Controller Class Initialized
INFO - 2018-03-30 14:46:19 --> Model Class Initialized
INFO - 2018-03-30 14:46:19 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 14:46:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 14:46:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 14:46:19 --> Model Class Initialized
INFO - 2018-03-30 14:46:19 --> Model Class Initialized
INFO - 2018-03-30 14:46:19 --> Model Class Initialized
INFO - 2018-03-30 14:46:19 --> Model Class Initialized
INFO - 2018-03-30 14:46:19 --> Model Class Initialized
INFO - 2018-03-30 14:46:19 --> Model Class Initialized
INFO - 2018-03-30 14:46:19 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-30 14:46:19 --> Model Class Initialized
INFO - 2018-03-30 14:46:19 --> Final output sent to browser
DEBUG - 2018-03-30 14:46:19 --> Total execution time: 0.1117
INFO - 2018-03-30 09:16:20 --> Language Class Initialized
INFO - 2018-03-30 09:16:20 --> Config Class Initialized
INFO - 2018-03-30 09:16:20 --> Loader Class Initialized
INFO - 2018-03-30 14:46:20 --> Helper loaded: url_helper
INFO - 2018-03-30 14:46:20 --> Helper loaded: notification_helper
INFO - 2018-03-30 14:46:20 --> Helper loaded: settings_helper
INFO - 2018-03-30 14:46:20 --> Helper loaded: permission_helper
INFO - 2018-03-30 14:46:21 --> Helper loaded: users_helper
INFO - 2018-03-30 14:46:22 --> Database Driver Class Initialized
DEBUG - 2018-03-30 14:46:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 14:46:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 14:46:22 --> Helper loaded: form_helper
INFO - 2018-03-30 14:46:22 --> Form Validation Class Initialized
INFO - 2018-03-30 14:46:22 --> Controller Class Initialized
INFO - 2018-03-30 14:46:22 --> Model Class Initialized
INFO - 2018-03-30 14:46:22 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 14:46:22 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 14:46:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 14:46:22 --> Model Class Initialized
INFO - 2018-03-30 14:46:22 --> Model Class Initialized
INFO - 2018-03-30 14:46:22 --> Model Class Initialized
INFO - 2018-03-30 14:46:22 --> Model Class Initialized
INFO - 2018-03-30 14:46:22 --> Model Class Initialized
INFO - 2018-03-30 14:46:22 --> Model Class Initialized
INFO - 2018-03-30 14:46:22 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-30 14:46:22 --> Model Class Initialized
INFO - 2018-03-30 14:46:22 --> Final output sent to browser
DEBUG - 2018-03-30 14:46:22 --> Total execution time: 4.4421
INFO - 2018-03-30 09:25:47 --> Config Class Initialized
INFO - 2018-03-30 09:25:47 --> Hooks Class Initialized
DEBUG - 2018-03-30 09:25:47 --> UTF-8 Support Enabled
INFO - 2018-03-30 09:25:47 --> Utf8 Class Initialized
INFO - 2018-03-30 09:25:47 --> URI Class Initialized
INFO - 2018-03-30 09:25:47 --> Router Class Initialized
INFO - 2018-03-30 09:25:47 --> Output Class Initialized
INFO - 2018-03-30 09:25:47 --> Security Class Initialized
DEBUG - 2018-03-30 09:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 09:25:47 --> Input Class Initialized
INFO - 2018-03-30 09:25:47 --> Language Class Initialized
INFO - 2018-03-30 09:25:47 --> Language Class Initialized
INFO - 2018-03-30 09:25:47 --> Config Class Initialized
INFO - 2018-03-30 09:25:47 --> Loader Class Initialized
INFO - 2018-03-30 14:55:47 --> Helper loaded: url_helper
INFO - 2018-03-30 14:55:47 --> Helper loaded: notification_helper
INFO - 2018-03-30 14:55:47 --> Helper loaded: settings_helper
INFO - 2018-03-30 14:55:47 --> Helper loaded: permission_helper
INFO - 2018-03-30 14:55:47 --> Helper loaded: users_helper
INFO - 2018-03-30 14:55:47 --> Database Driver Class Initialized
DEBUG - 2018-03-30 14:55:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 14:55:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 14:55:47 --> Helper loaded: form_helper
INFO - 2018-03-30 14:55:47 --> Form Validation Class Initialized
INFO - 2018-03-30 14:55:47 --> Controller Class Initialized
INFO - 2018-03-30 14:55:47 --> Model Class Initialized
INFO - 2018-03-30 14:55:47 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 14:55:48 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 14:55:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 14:55:48 --> Model Class Initialized
INFO - 2018-03-30 14:55:48 --> Model Class Initialized
INFO - 2018-03-30 14:55:48 --> Model Class Initialized
INFO - 2018-03-30 14:55:48 --> Model Class Initialized
INFO - 2018-03-30 14:55:48 --> Model Class Initialized
INFO - 2018-03-30 14:55:48 --> Model Class Initialized
INFO - 2018-03-30 14:55:48 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-30 14:55:48 --> Model Class Initialized
INFO - 2018-03-30 14:55:48 --> Final output sent to browser
DEBUG - 2018-03-30 14:55:48 --> Total execution time: 0.6398
INFO - 2018-03-30 09:30:03 --> Config Class Initialized
INFO - 2018-03-30 09:30:03 --> Hooks Class Initialized
DEBUG - 2018-03-30 09:30:03 --> UTF-8 Support Enabled
INFO - 2018-03-30 09:30:03 --> Utf8 Class Initialized
INFO - 2018-03-30 09:30:03 --> URI Class Initialized
INFO - 2018-03-30 09:30:03 --> Router Class Initialized
INFO - 2018-03-30 09:30:03 --> Output Class Initialized
INFO - 2018-03-30 09:30:03 --> Security Class Initialized
DEBUG - 2018-03-30 09:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 09:30:03 --> Input Class Initialized
INFO - 2018-03-30 09:30:03 --> Language Class Initialized
INFO - 2018-03-30 09:30:03 --> Language Class Initialized
INFO - 2018-03-30 09:30:03 --> Config Class Initialized
INFO - 2018-03-30 09:30:03 --> Loader Class Initialized
INFO - 2018-03-30 15:00:03 --> Helper loaded: url_helper
INFO - 2018-03-30 15:00:03 --> Helper loaded: notification_helper
INFO - 2018-03-30 15:00:03 --> Helper loaded: settings_helper
INFO - 2018-03-30 15:00:03 --> Helper loaded: permission_helper
INFO - 2018-03-30 15:00:03 --> Helper loaded: users_helper
INFO - 2018-03-30 15:00:03 --> Database Driver Class Initialized
DEBUG - 2018-03-30 15:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 15:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 15:00:03 --> Helper loaded: form_helper
INFO - 2018-03-30 15:00:03 --> Form Validation Class Initialized
INFO - 2018-03-30 15:00:03 --> Controller Class Initialized
INFO - 2018-03-30 15:00:03 --> Model Class Initialized
INFO - 2018-03-30 15:00:03 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 15:00:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 15:00:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 15:00:03 --> Model Class Initialized
INFO - 2018-03-30 15:00:03 --> Model Class Initialized
INFO - 2018-03-30 15:00:03 --> Model Class Initialized
INFO - 2018-03-30 15:00:03 --> Model Class Initialized
INFO - 2018-03-30 15:00:03 --> Model Class Initialized
INFO - 2018-03-30 15:00:03 --> Model Class Initialized
INFO - 2018-03-30 15:00:03 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-30 15:00:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-30 15:00:03 --> Final output sent to browser
DEBUG - 2018-03-30 15:00:03 --> Total execution time: 0.1204
INFO - 2018-03-30 09:30:04 --> Config Class Initialized
INFO - 2018-03-30 09:30:04 --> Hooks Class Initialized
DEBUG - 2018-03-30 09:30:04 --> UTF-8 Support Enabled
INFO - 2018-03-30 09:30:04 --> Utf8 Class Initialized
INFO - 2018-03-30 09:30:04 --> URI Class Initialized
INFO - 2018-03-30 09:30:05 --> Router Class Initialized
INFO - 2018-03-30 09:30:05 --> Output Class Initialized
INFO - 2018-03-30 09:30:05 --> Security Class Initialized
DEBUG - 2018-03-30 09:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 09:30:05 --> Input Class Initialized
INFO - 2018-03-30 09:30:05 --> Language Class Initialized
INFO - 2018-03-30 09:30:05 --> Language Class Initialized
INFO - 2018-03-30 09:30:05 --> Config Class Initialized
INFO - 2018-03-30 09:30:05 --> Loader Class Initialized
INFO - 2018-03-30 15:00:05 --> Helper loaded: url_helper
INFO - 2018-03-30 15:00:05 --> Helper loaded: notification_helper
INFO - 2018-03-30 15:00:05 --> Helper loaded: settings_helper
INFO - 2018-03-30 15:00:05 --> Helper loaded: permission_helper
INFO - 2018-03-30 15:00:05 --> Helper loaded: users_helper
INFO - 2018-03-30 15:00:05 --> Database Driver Class Initialized
DEBUG - 2018-03-30 15:00:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 15:00:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 15:00:05 --> Helper loaded: form_helper
INFO - 2018-03-30 15:00:05 --> Form Validation Class Initialized
INFO - 2018-03-30 15:00:05 --> Controller Class Initialized
INFO - 2018-03-30 15:00:05 --> Model Class Initialized
INFO - 2018-03-30 15:00:05 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 15:00:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 15:00:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 15:00:05 --> Model Class Initialized
INFO - 2018-03-30 15:00:05 --> Model Class Initialized
INFO - 2018-03-30 15:00:05 --> Model Class Initialized
INFO - 2018-03-30 15:00:05 --> Model Class Initialized
INFO - 2018-03-30 15:00:05 --> Model Class Initialized
INFO - 2018-03-30 15:00:05 --> Model Class Initialized
INFO - 2018-03-30 15:00:05 --> Model Class Initialized
INFO - 2018-03-30 15:00:05 --> Model Class Initialized
INFO - 2018-03-30 15:00:05 --> Model Class Initialized
INFO - 2018-03-30 15:00:05 --> Model Class Initialized
INFO - 2018-03-30 15:00:05 --> Model Class Initialized
INFO - 2018-03-30 15:00:05 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-30 15:00:05 --> Model Class Initialized
INFO - 2018-03-30 15:00:05 --> Final output sent to browser
DEBUG - 2018-03-30 15:00:05 --> Total execution time: 0.8039
INFO - 2018-03-30 09:30:06 --> Config Class Initialized
INFO - 2018-03-30 09:30:06 --> Hooks Class Initialized
DEBUG - 2018-03-30 09:30:06 --> UTF-8 Support Enabled
INFO - 2018-03-30 09:30:06 --> Utf8 Class Initialized
INFO - 2018-03-30 09:30:06 --> URI Class Initialized
INFO - 2018-03-30 09:30:06 --> Router Class Initialized
INFO - 2018-03-30 09:30:07 --> Output Class Initialized
INFO - 2018-03-30 09:30:07 --> Security Class Initialized
DEBUG - 2018-03-30 09:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 09:30:07 --> Input Class Initialized
INFO - 2018-03-30 09:30:07 --> Language Class Initialized
INFO - 2018-03-30 09:30:07 --> Language Class Initialized
INFO - 2018-03-30 09:30:07 --> Config Class Initialized
INFO - 2018-03-30 09:30:07 --> Loader Class Initialized
INFO - 2018-03-30 15:00:08 --> Helper loaded: url_helper
INFO - 2018-03-30 15:00:08 --> Helper loaded: notification_helper
INFO - 2018-03-30 15:00:08 --> Helper loaded: settings_helper
INFO - 2018-03-30 15:00:08 --> Helper loaded: permission_helper
INFO - 2018-03-30 15:00:08 --> Helper loaded: users_helper
INFO - 2018-03-30 15:00:09 --> Database Driver Class Initialized
INFO - 2018-03-30 09:30:09 --> Config Class Initialized
INFO - 2018-03-30 09:30:09 --> Hooks Class Initialized
DEBUG - 2018-03-30 15:00:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 15:00:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-03-30 09:30:09 --> UTF-8 Support Enabled
INFO - 2018-03-30 09:30:09 --> Utf8 Class Initialized
INFO - 2018-03-30 09:30:09 --> URI Class Initialized
INFO - 2018-03-30 15:00:09 --> Helper loaded: form_helper
INFO - 2018-03-30 15:00:09 --> Form Validation Class Initialized
INFO - 2018-03-30 15:00:09 --> Controller Class Initialized
INFO - 2018-03-30 09:30:10 --> Router Class Initialized
INFO - 2018-03-30 09:30:10 --> Output Class Initialized
INFO - 2018-03-30 15:00:10 --> Model Class Initialized
INFO - 2018-03-30 15:00:10 --> Helper loaded: inflector_helper
INFO - 2018-03-30 09:30:10 --> Security Class Initialized
DEBUG - 2018-03-30 15:00:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-03-30 09:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 09:30:10 --> Input Class Initialized
INFO - 2018-03-30 15:00:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 09:30:10 --> Language Class Initialized
INFO - 2018-03-30 15:00:10 --> Model Class Initialized
INFO - 2018-03-30 15:00:10 --> Model Class Initialized
INFO - 2018-03-30 15:00:10 --> Model Class Initialized
INFO - 2018-03-30 15:00:10 --> Model Class Initialized
INFO - 2018-03-30 15:00:10 --> Model Class Initialized
INFO - 2018-03-30 15:00:10 --> Model Class Initialized
INFO - 2018-03-30 15:00:10 --> Model Class Initialized
INFO - 2018-03-30 15:00:10 --> Model Class Initialized
INFO - 2018-03-30 15:00:10 --> Model Class Initialized
INFO - 2018-03-30 15:00:10 --> Model Class Initialized
INFO - 2018-03-30 15:00:10 --> Model Class Initialized
INFO - 2018-03-30 15:00:10 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-30 15:00:10 --> Model Class Initialized
INFO - 2018-03-30 15:00:11 --> Final output sent to browser
DEBUG - 2018-03-30 15:00:11 --> Total execution time: 5.0622
INFO - 2018-03-30 09:30:11 --> Language Class Initialized
INFO - 2018-03-30 09:30:11 --> Config Class Initialized
INFO - 2018-03-30 09:30:11 --> Loader Class Initialized
INFO - 2018-03-30 15:00:11 --> Helper loaded: url_helper
INFO - 2018-03-30 15:00:11 --> Helper loaded: notification_helper
INFO - 2018-03-30 15:00:11 --> Helper loaded: settings_helper
INFO - 2018-03-30 15:00:11 --> Helper loaded: permission_helper
INFO - 2018-03-30 15:00:11 --> Helper loaded: users_helper
INFO - 2018-03-30 15:00:12 --> Database Driver Class Initialized
DEBUG - 2018-03-30 15:00:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 15:00:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 15:00:12 --> Helper loaded: form_helper
INFO - 2018-03-30 15:00:12 --> Form Validation Class Initialized
INFO - 2018-03-30 15:00:12 --> Controller Class Initialized
INFO - 2018-03-30 15:00:12 --> Model Class Initialized
INFO - 2018-03-30 15:00:12 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 15:00:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 15:00:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 15:00:13 --> Model Class Initialized
INFO - 2018-03-30 15:00:13 --> Model Class Initialized
INFO - 2018-03-30 15:00:13 --> Model Class Initialized
INFO - 2018-03-30 15:00:13 --> Model Class Initialized
INFO - 2018-03-30 15:00:13 --> Model Class Initialized
INFO - 2018-03-30 15:00:13 --> Model Class Initialized
INFO - 2018-03-30 15:00:13 --> Model Class Initialized
INFO - 2018-03-30 15:00:13 --> Model Class Initialized
INFO - 2018-03-30 15:00:13 --> Model Class Initialized
INFO - 2018-03-30 15:00:13 --> Model Class Initialized
INFO - 2018-03-30 15:00:13 --> Model Class Initialized
INFO - 2018-03-30 15:00:13 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-30 15:00:13 --> Model Class Initialized
INFO - 2018-03-30 15:00:13 --> Final output sent to browser
DEBUG - 2018-03-30 15:00:13 --> Total execution time: 4.2012
INFO - 2018-03-30 09:30:16 --> Config Class Initialized
INFO - 2018-03-30 09:30:16 --> Hooks Class Initialized
DEBUG - 2018-03-30 09:30:16 --> UTF-8 Support Enabled
INFO - 2018-03-30 09:30:16 --> Utf8 Class Initialized
INFO - 2018-03-30 09:30:16 --> URI Class Initialized
INFO - 2018-03-30 09:30:16 --> Router Class Initialized
INFO - 2018-03-30 09:30:16 --> Output Class Initialized
INFO - 2018-03-30 09:30:16 --> Security Class Initialized
DEBUG - 2018-03-30 09:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 09:30:16 --> Input Class Initialized
INFO - 2018-03-30 09:30:16 --> Language Class Initialized
INFO - 2018-03-30 09:30:16 --> Language Class Initialized
INFO - 2018-03-30 09:30:16 --> Config Class Initialized
INFO - 2018-03-30 09:30:16 --> Loader Class Initialized
INFO - 2018-03-30 15:00:16 --> Helper loaded: url_helper
INFO - 2018-03-30 15:00:16 --> Helper loaded: notification_helper
INFO - 2018-03-30 15:00:16 --> Helper loaded: settings_helper
INFO - 2018-03-30 15:00:16 --> Helper loaded: permission_helper
INFO - 2018-03-30 09:30:16 --> Config Class Initialized
INFO - 2018-03-30 09:30:16 --> Hooks Class Initialized
INFO - 2018-03-30 15:00:16 --> Helper loaded: users_helper
DEBUG - 2018-03-30 09:30:16 --> UTF-8 Support Enabled
INFO - 2018-03-30 09:30:16 --> Utf8 Class Initialized
INFO - 2018-03-30 09:30:16 --> URI Class Initialized
INFO - 2018-03-30 09:30:16 --> Router Class Initialized
INFO - 2018-03-30 09:30:16 --> Output Class Initialized
INFO - 2018-03-30 15:00:16 --> Database Driver Class Initialized
INFO - 2018-03-30 09:30:16 --> Security Class Initialized
DEBUG - 2018-03-30 09:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 09:30:16 --> Input Class Initialized
INFO - 2018-03-30 09:30:16 --> Language Class Initialized
DEBUG - 2018-03-30 15:00:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 15:00:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 09:30:16 --> Language Class Initialized
INFO - 2018-03-30 09:30:16 --> Config Class Initialized
INFO - 2018-03-30 09:30:16 --> Loader Class Initialized
INFO - 2018-03-30 15:00:16 --> Helper loaded: url_helper
INFO - 2018-03-30 15:00:16 --> Helper loaded: notification_helper
INFO - 2018-03-30 15:00:16 --> Helper loaded: settings_helper
INFO - 2018-03-30 15:00:16 --> Helper loaded: permission_helper
INFO - 2018-03-30 15:00:16 --> Helper loaded: users_helper
INFO - 2018-03-30 15:00:16 --> Database Driver Class Initialized
INFO - 2018-03-30 15:00:16 --> Helper loaded: form_helper
INFO - 2018-03-30 15:00:16 --> Form Validation Class Initialized
INFO - 2018-03-30 15:00:16 --> Controller Class Initialized
DEBUG - 2018-03-30 15:00:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 15:00:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 15:00:16 --> Model Class Initialized
INFO - 2018-03-30 15:00:16 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 15:00:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 15:00:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 15:00:16 --> Model Class Initialized
INFO - 2018-03-30 15:00:16 --> Model Class Initialized
INFO - 2018-03-30 15:00:16 --> Helper loaded: form_helper
INFO - 2018-03-30 15:00:16 --> Form Validation Class Initialized
INFO - 2018-03-30 15:00:16 --> Controller Class Initialized
INFO - 2018-03-30 15:00:16 --> Model Class Initialized
INFO - 2018-03-30 15:00:16 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 15:00:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 15:00:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 15:00:16 --> Model Class Initialized
INFO - 2018-03-30 15:00:16 --> Model Class Initialized
INFO - 2018-03-30 15:00:16 --> Model Class Initialized
INFO - 2018-03-30 15:00:16 --> Model Class Initialized
INFO - 2018-03-30 15:00:16 --> Model Class Initialized
INFO - 2018-03-30 15:00:16 --> Model Class Initialized
INFO - 2018-03-30 15:00:16 --> Model Class Initialized
INFO - 2018-03-30 15:00:16 --> Model Class Initialized
INFO - 2018-03-30 15:00:16 --> Model Class Initialized
INFO - 2018-03-30 15:00:16 --> Model Class Initialized
INFO - 2018-03-30 15:00:16 --> Model Class Initialized
INFO - 2018-03-30 15:00:16 --> Model Class Initialized
INFO - 2018-03-30 15:00:16 --> Model Class Initialized
INFO - 2018-03-30 15:00:16 --> Model Class Initialized
INFO - 2018-03-30 15:00:16 --> Model Class Initialized
INFO - 2018-03-30 15:00:16 --> Model Class Initialized
INFO - 2018-03-30 15:00:16 --> Model Class Initialized
INFO - 2018-03-30 15:00:16 --> Model Class Initialized
INFO - 2018-03-30 15:00:16 --> Model Class Initialized
INFO - 2018-03-30 15:00:16 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-30 15:00:16 --> Model Class Initialized
INFO - 2018-03-30 15:00:16 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-30 15:00:16 --> Model Class Initialized
INFO - 2018-03-30 15:00:16 --> Final output sent to browser
DEBUG - 2018-03-30 15:00:16 --> Total execution time: 0.2304
INFO - 2018-03-30 15:00:16 --> Final output sent to browser
DEBUG - 2018-03-30 15:00:16 --> Total execution time: 0.3322
INFO - 2018-03-30 09:30:20 --> Config Class Initialized
INFO - 2018-03-30 09:30:20 --> Hooks Class Initialized
DEBUG - 2018-03-30 09:30:20 --> UTF-8 Support Enabled
INFO - 2018-03-30 09:30:20 --> Utf8 Class Initialized
INFO - 2018-03-30 09:30:20 --> URI Class Initialized
INFO - 2018-03-30 09:30:20 --> Router Class Initialized
INFO - 2018-03-30 09:30:21 --> Output Class Initialized
INFO - 2018-03-30 09:30:21 --> Security Class Initialized
DEBUG - 2018-03-30 09:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 09:30:21 --> Input Class Initialized
INFO - 2018-03-30 09:30:21 --> Language Class Initialized
INFO - 2018-03-30 09:30:22 --> Config Class Initialized
INFO - 2018-03-30 09:30:22 --> Hooks Class Initialized
DEBUG - 2018-03-30 09:30:22 --> UTF-8 Support Enabled
INFO - 2018-03-30 09:30:22 --> Utf8 Class Initialized
INFO - 2018-03-30 09:30:22 --> Language Class Initialized
INFO - 2018-03-30 09:30:22 --> Config Class Initialized
INFO - 2018-03-30 09:30:22 --> Loader Class Initialized
INFO - 2018-03-30 09:30:22 --> URI Class Initialized
INFO - 2018-03-30 15:00:22 --> Helper loaded: url_helper
INFO - 2018-03-30 15:00:22 --> Helper loaded: notification_helper
INFO - 2018-03-30 15:00:22 --> Helper loaded: settings_helper
INFO - 2018-03-30 15:00:22 --> Helper loaded: permission_helper
INFO - 2018-03-30 15:00:22 --> Helper loaded: users_helper
INFO - 2018-03-30 09:30:22 --> Router Class Initialized
INFO - 2018-03-30 09:30:23 --> Output Class Initialized
INFO - 2018-03-30 09:30:23 --> Security Class Initialized
DEBUG - 2018-03-30 09:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 09:30:23 --> Input Class Initialized
INFO - 2018-03-30 09:30:23 --> Language Class Initialized
INFO - 2018-03-30 15:00:23 --> Database Driver Class Initialized
DEBUG - 2018-03-30 15:00:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 15:00:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 15:00:23 --> Helper loaded: form_helper
INFO - 2018-03-30 15:00:23 --> Form Validation Class Initialized
INFO - 2018-03-30 15:00:23 --> Controller Class Initialized
INFO - 2018-03-30 15:00:23 --> Model Class Initialized
INFO - 2018-03-30 15:00:23 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 15:00:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 15:00:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 15:00:23 --> Model Class Initialized
INFO - 2018-03-30 15:00:23 --> Model Class Initialized
INFO - 2018-03-30 15:00:23 --> Model Class Initialized
INFO - 2018-03-30 15:00:23 --> Model Class Initialized
INFO - 2018-03-30 15:00:23 --> Model Class Initialized
INFO - 2018-03-30 15:00:23 --> Model Class Initialized
INFO - 2018-03-30 15:00:23 --> Model Class Initialized
INFO - 2018-03-30 15:00:23 --> Model Class Initialized
INFO - 2018-03-30 15:00:23 --> Model Class Initialized
INFO - 2018-03-30 15:00:23 --> Model Class Initialized
INFO - 2018-03-30 15:00:23 --> Model Class Initialized
INFO - 2018-03-30 15:00:23 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-30 15:00:23 --> Model Class Initialized
INFO - 2018-03-30 15:00:23 --> Final output sent to browser
DEBUG - 2018-03-30 15:00:23 --> Total execution time: 3.5660
INFO - 2018-03-30 09:30:23 --> Language Class Initialized
INFO - 2018-03-30 09:30:23 --> Config Class Initialized
INFO - 2018-03-30 09:30:23 --> Loader Class Initialized
INFO - 2018-03-30 15:00:24 --> Helper loaded: url_helper
INFO - 2018-03-30 15:00:24 --> Helper loaded: notification_helper
INFO - 2018-03-30 15:00:24 --> Helper loaded: settings_helper
INFO - 2018-03-30 15:00:24 --> Helper loaded: permission_helper
INFO - 2018-03-30 15:00:24 --> Helper loaded: users_helper
INFO - 2018-03-30 15:00:24 --> Database Driver Class Initialized
DEBUG - 2018-03-30 15:00:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 15:00:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 15:00:24 --> Helper loaded: form_helper
INFO - 2018-03-30 15:00:24 --> Form Validation Class Initialized
INFO - 2018-03-30 15:00:24 --> Controller Class Initialized
INFO - 2018-03-30 15:00:24 --> Model Class Initialized
INFO - 2018-03-30 15:00:24 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 15:00:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 15:00:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 15:00:24 --> Model Class Initialized
INFO - 2018-03-30 15:00:24 --> Model Class Initialized
INFO - 2018-03-30 15:00:24 --> Model Class Initialized
INFO - 2018-03-30 15:00:24 --> Model Class Initialized
INFO - 2018-03-30 15:00:24 --> Model Class Initialized
INFO - 2018-03-30 15:00:24 --> Model Class Initialized
INFO - 2018-03-30 15:00:24 --> Model Class Initialized
INFO - 2018-03-30 15:00:24 --> Model Class Initialized
INFO - 2018-03-30 15:00:24 --> Model Class Initialized
INFO - 2018-03-30 15:00:24 --> Model Class Initialized
INFO - 2018-03-30 15:00:24 --> Model Class Initialized
INFO - 2018-03-30 15:00:24 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-30 15:00:24 --> Model Class Initialized
INFO - 2018-03-30 15:00:24 --> Final output sent to browser
DEBUG - 2018-03-30 15:00:24 --> Total execution time: 2.6776
INFO - 2018-03-30 09:30:27 --> Config Class Initialized
INFO - 2018-03-30 09:30:27 --> Hooks Class Initialized
DEBUG - 2018-03-30 09:30:27 --> UTF-8 Support Enabled
INFO - 2018-03-30 09:30:27 --> Utf8 Class Initialized
INFO - 2018-03-30 09:30:27 --> URI Class Initialized
INFO - 2018-03-30 09:30:27 --> Router Class Initialized
INFO - 2018-03-30 09:30:27 --> Output Class Initialized
INFO - 2018-03-30 09:30:27 --> Security Class Initialized
DEBUG - 2018-03-30 09:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 09:30:27 --> Input Class Initialized
INFO - 2018-03-30 09:30:27 --> Config Class Initialized
INFO - 2018-03-30 09:30:27 --> Hooks Class Initialized
INFO - 2018-03-30 09:30:27 --> Language Class Initialized
DEBUG - 2018-03-30 09:30:27 --> UTF-8 Support Enabled
INFO - 2018-03-30 09:30:27 --> Utf8 Class Initialized
INFO - 2018-03-30 09:30:27 --> URI Class Initialized
INFO - 2018-03-30 09:30:27 --> Router Class Initialized
INFO - 2018-03-30 09:30:27 --> Output Class Initialized
INFO - 2018-03-30 09:30:27 --> Security Class Initialized
DEBUG - 2018-03-30 09:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 09:30:27 --> Input Class Initialized
INFO - 2018-03-30 09:30:27 --> Language Class Initialized
INFO - 2018-03-30 09:30:27 --> Language Class Initialized
INFO - 2018-03-30 09:30:27 --> Config Class Initialized
INFO - 2018-03-30 09:30:27 --> Loader Class Initialized
INFO - 2018-03-30 09:30:27 --> Language Class Initialized
INFO - 2018-03-30 09:30:27 --> Config Class Initialized
INFO - 2018-03-30 09:30:27 --> Loader Class Initialized
INFO - 2018-03-30 15:00:27 --> Helper loaded: url_helper
INFO - 2018-03-30 15:00:27 --> Helper loaded: url_helper
INFO - 2018-03-30 15:00:27 --> Helper loaded: notification_helper
INFO - 2018-03-30 15:00:27 --> Helper loaded: notification_helper
INFO - 2018-03-30 15:00:27 --> Helper loaded: settings_helper
INFO - 2018-03-30 15:00:28 --> Helper loaded: permission_helper
INFO - 2018-03-30 15:00:28 --> Helper loaded: settings_helper
INFO - 2018-03-30 15:00:28 --> Helper loaded: users_helper
INFO - 2018-03-30 15:00:28 --> Helper loaded: permission_helper
INFO - 2018-03-30 15:00:28 --> Helper loaded: users_helper
INFO - 2018-03-30 15:00:28 --> Database Driver Class Initialized
DEBUG - 2018-03-30 15:00:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 15:00:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 15:00:28 --> Helper loaded: form_helper
INFO - 2018-03-30 15:00:28 --> Form Validation Class Initialized
INFO - 2018-03-30 15:00:28 --> Controller Class Initialized
INFO - 2018-03-30 15:00:28 --> Model Class Initialized
INFO - 2018-03-30 15:00:28 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 15:00:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 15:00:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 15:00:28 --> Model Class Initialized
INFO - 2018-03-30 15:00:28 --> Model Class Initialized
INFO - 2018-03-30 15:00:28 --> Model Class Initialized
INFO - 2018-03-30 15:00:28 --> Model Class Initialized
INFO - 2018-03-30 15:00:28 --> Model Class Initialized
INFO - 2018-03-30 15:00:28 --> Model Class Initialized
INFO - 2018-03-30 15:00:28 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-30 15:00:28 --> Final output sent to browser
DEBUG - 2018-03-30 15:00:28 --> Total execution time: 0.5972
INFO - 2018-03-30 15:00:28 --> Database Driver Class Initialized
DEBUG - 2018-03-30 15:00:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 15:00:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 15:00:28 --> Helper loaded: form_helper
INFO - 2018-03-30 15:00:28 --> Form Validation Class Initialized
INFO - 2018-03-30 15:00:28 --> Controller Class Initialized
INFO - 2018-03-30 15:00:28 --> Model Class Initialized
INFO - 2018-03-30 15:00:28 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 15:00:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 15:00:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 15:00:28 --> Model Class Initialized
INFO - 2018-03-30 15:00:28 --> Model Class Initialized
INFO - 2018-03-30 15:00:29 --> Model Class Initialized
INFO - 2018-03-30 15:00:29 --> Model Class Initialized
INFO - 2018-03-30 15:00:29 --> Model Class Initialized
INFO - 2018-03-30 15:00:29 --> Model Class Initialized
INFO - 2018-03-30 15:00:29 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-30 15:00:29 --> Final output sent to browser
DEBUG - 2018-03-30 15:00:29 --> Total execution time: 1.9878
INFO - 2018-03-30 09:30:29 --> Config Class Initialized
INFO - 2018-03-30 09:30:29 --> Hooks Class Initialized
DEBUG - 2018-03-30 09:30:29 --> UTF-8 Support Enabled
INFO - 2018-03-30 09:30:29 --> Utf8 Class Initialized
INFO - 2018-03-30 09:30:29 --> URI Class Initialized
INFO - 2018-03-30 09:30:29 --> Router Class Initialized
INFO - 2018-03-30 09:30:29 --> Output Class Initialized
INFO - 2018-03-30 09:30:29 --> Security Class Initialized
DEBUG - 2018-03-30 09:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 09:30:29 --> Input Class Initialized
INFO - 2018-03-30 09:30:29 --> Language Class Initialized
INFO - 2018-03-30 09:30:29 --> Language Class Initialized
INFO - 2018-03-30 09:30:29 --> Config Class Initialized
INFO - 2018-03-30 09:30:29 --> Loader Class Initialized
INFO - 2018-03-30 15:00:29 --> Helper loaded: url_helper
INFO - 2018-03-30 15:00:29 --> Helper loaded: notification_helper
INFO - 2018-03-30 15:00:29 --> Helper loaded: settings_helper
INFO - 2018-03-30 15:00:30 --> Helper loaded: permission_helper
INFO - 2018-03-30 15:00:30 --> Helper loaded: users_helper
INFO - 2018-03-30 15:00:30 --> Database Driver Class Initialized
DEBUG - 2018-03-30 15:00:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 15:00:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 15:00:30 --> Helper loaded: form_helper
INFO - 2018-03-30 15:00:30 --> Form Validation Class Initialized
INFO - 2018-03-30 15:00:30 --> Controller Class Initialized
INFO - 2018-03-30 15:00:30 --> Model Class Initialized
INFO - 2018-03-30 15:00:30 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 15:00:30 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 15:00:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 15:00:30 --> Model Class Initialized
INFO - 2018-03-30 15:00:30 --> Model Class Initialized
INFO - 2018-03-30 15:00:30 --> Model Class Initialized
INFO - 2018-03-30 15:00:30 --> Model Class Initialized
INFO - 2018-03-30 15:00:30 --> Model Class Initialized
INFO - 2018-03-30 15:00:30 --> Model Class Initialized
INFO - 2018-03-30 15:00:30 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-30 15:00:30 --> Final output sent to browser
DEBUG - 2018-03-30 15:00:30 --> Total execution time: 0.4693
INFO - 2018-03-30 09:30:37 --> Config Class Initialized
INFO - 2018-03-30 09:30:37 --> Hooks Class Initialized
DEBUG - 2018-03-30 09:30:37 --> UTF-8 Support Enabled
INFO - 2018-03-30 09:30:37 --> Utf8 Class Initialized
INFO - 2018-03-30 09:30:37 --> URI Class Initialized
INFO - 2018-03-30 09:30:37 --> Router Class Initialized
INFO - 2018-03-30 09:30:37 --> Output Class Initialized
INFO - 2018-03-30 09:30:37 --> Security Class Initialized
DEBUG - 2018-03-30 09:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 09:30:37 --> Input Class Initialized
INFO - 2018-03-30 09:30:37 --> Language Class Initialized
INFO - 2018-03-30 09:30:37 --> Language Class Initialized
INFO - 2018-03-30 09:30:37 --> Config Class Initialized
INFO - 2018-03-30 09:30:37 --> Loader Class Initialized
INFO - 2018-03-30 15:00:37 --> Helper loaded: url_helper
INFO - 2018-03-30 15:00:37 --> Helper loaded: notification_helper
INFO - 2018-03-30 15:00:37 --> Helper loaded: settings_helper
INFO - 2018-03-30 15:00:37 --> Helper loaded: permission_helper
INFO - 2018-03-30 15:00:37 --> Helper loaded: users_helper
INFO - 2018-03-30 15:00:37 --> Database Driver Class Initialized
DEBUG - 2018-03-30 15:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 15:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 15:00:37 --> Helper loaded: form_helper
INFO - 2018-03-30 15:00:37 --> Form Validation Class Initialized
INFO - 2018-03-30 15:00:37 --> Controller Class Initialized
INFO - 2018-03-30 15:00:37 --> Model Class Initialized
INFO - 2018-03-30 15:00:37 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 15:00:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 15:00:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 15:00:37 --> Model Class Initialized
INFO - 2018-03-30 15:00:37 --> Model Class Initialized
INFO - 2018-03-30 15:00:37 --> Final output sent to browser
DEBUG - 2018-03-30 15:00:37 --> Total execution time: 0.1613
INFO - 2018-03-30 09:30:45 --> Config Class Initialized
INFO - 2018-03-30 09:30:45 --> Hooks Class Initialized
DEBUG - 2018-03-30 09:30:45 --> UTF-8 Support Enabled
INFO - 2018-03-30 09:30:45 --> Utf8 Class Initialized
INFO - 2018-03-30 09:30:46 --> URI Class Initialized
INFO - 2018-03-30 09:30:46 --> Router Class Initialized
INFO - 2018-03-30 09:30:46 --> Output Class Initialized
INFO - 2018-03-30 09:30:46 --> Security Class Initialized
DEBUG - 2018-03-30 09:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 09:30:46 --> Input Class Initialized
INFO - 2018-03-30 09:30:46 --> Language Class Initialized
INFO - 2018-03-30 09:30:47 --> Language Class Initialized
INFO - 2018-03-30 09:30:47 --> Config Class Initialized
INFO - 2018-03-30 09:30:47 --> Loader Class Initialized
INFO - 2018-03-30 09:30:47 --> Config Class Initialized
INFO - 2018-03-30 09:30:47 --> Hooks Class Initialized
DEBUG - 2018-03-30 09:30:47 --> UTF-8 Support Enabled
INFO - 2018-03-30 09:30:47 --> Utf8 Class Initialized
INFO - 2018-03-30 09:30:47 --> URI Class Initialized
INFO - 2018-03-30 09:30:47 --> Router Class Initialized
INFO - 2018-03-30 09:30:47 --> Output Class Initialized
INFO - 2018-03-30 09:30:47 --> Security Class Initialized
INFO - 2018-03-30 15:00:47 --> Helper loaded: url_helper
DEBUG - 2018-03-30 09:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 09:30:47 --> Input Class Initialized
INFO - 2018-03-30 09:30:47 --> Language Class Initialized
INFO - 2018-03-30 15:00:47 --> Helper loaded: notification_helper
INFO - 2018-03-30 15:00:47 --> Helper loaded: settings_helper
INFO - 2018-03-30 15:00:47 --> Helper loaded: permission_helper
INFO - 2018-03-30 15:00:47 --> Helper loaded: users_helper
INFO - 2018-03-30 09:30:47 --> Language Class Initialized
INFO - 2018-03-30 09:30:47 --> Config Class Initialized
INFO - 2018-03-30 09:30:47 --> Loader Class Initialized
INFO - 2018-03-30 15:00:47 --> Helper loaded: url_helper
INFO - 2018-03-30 15:00:47 --> Helper loaded: notification_helper
INFO - 2018-03-30 15:00:47 --> Helper loaded: settings_helper
INFO - 2018-03-30 15:00:47 --> Helper loaded: permission_helper
INFO - 2018-03-30 15:00:47 --> Helper loaded: users_helper
INFO - 2018-03-30 15:00:47 --> Database Driver Class Initialized
DEBUG - 2018-03-30 15:00:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 15:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 15:00:47 --> Helper loaded: form_helper
INFO - 2018-03-30 15:00:47 --> Form Validation Class Initialized
INFO - 2018-03-30 15:00:47 --> Controller Class Initialized
INFO - 2018-03-30 15:00:47 --> Model Class Initialized
INFO - 2018-03-30 15:00:47 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 15:00:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 15:00:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 15:00:47 --> Model Class Initialized
INFO - 2018-03-30 15:00:47 --> Model Class Initialized
INFO - 2018-03-30 15:00:47 --> Model Class Initialized
INFO - 2018-03-30 15:00:47 --> Model Class Initialized
INFO - 2018-03-30 15:00:47 --> Model Class Initialized
INFO - 2018-03-30 15:00:47 --> Model Class Initialized
INFO - 2018-03-30 15:00:47 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-30 15:00:47 --> Model Class Initialized
INFO - 2018-03-30 15:00:47 --> Final output sent to browser
DEBUG - 2018-03-30 15:00:47 --> Total execution time: 0.5633
INFO - 2018-03-30 15:00:47 --> Database Driver Class Initialized
DEBUG - 2018-03-30 15:00:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 15:00:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 15:00:48 --> Helper loaded: form_helper
INFO - 2018-03-30 15:00:48 --> Form Validation Class Initialized
INFO - 2018-03-30 15:00:48 --> Controller Class Initialized
INFO - 2018-03-30 15:00:48 --> Model Class Initialized
INFO - 2018-03-30 15:00:48 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 15:00:48 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 15:00:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 15:00:48 --> Model Class Initialized
INFO - 2018-03-30 15:00:48 --> Model Class Initialized
INFO - 2018-03-30 15:00:48 --> Model Class Initialized
INFO - 2018-03-30 15:00:48 --> Model Class Initialized
INFO - 2018-03-30 15:00:48 --> Model Class Initialized
INFO - 2018-03-30 15:00:48 --> Model Class Initialized
INFO - 2018-03-30 15:00:48 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-30 15:00:48 --> Model Class Initialized
INFO - 2018-03-30 15:00:48 --> Final output sent to browser
DEBUG - 2018-03-30 15:00:48 --> Total execution time: 2.7889
INFO - 2018-03-30 09:30:51 --> Config Class Initialized
INFO - 2018-03-30 09:30:51 --> Hooks Class Initialized
DEBUG - 2018-03-30 09:30:51 --> UTF-8 Support Enabled
INFO - 2018-03-30 09:30:51 --> Utf8 Class Initialized
INFO - 2018-03-30 09:30:51 --> URI Class Initialized
INFO - 2018-03-30 09:30:51 --> Router Class Initialized
INFO - 2018-03-30 09:30:51 --> Output Class Initialized
INFO - 2018-03-30 09:30:52 --> Security Class Initialized
DEBUG - 2018-03-30 09:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 09:30:52 --> Input Class Initialized
INFO - 2018-03-30 09:30:52 --> Language Class Initialized
INFO - 2018-03-30 09:30:52 --> Language Class Initialized
INFO - 2018-03-30 09:30:52 --> Config Class Initialized
INFO - 2018-03-30 09:30:52 --> Loader Class Initialized
INFO - 2018-03-30 15:00:52 --> Helper loaded: url_helper
INFO - 2018-03-30 15:00:52 --> Helper loaded: notification_helper
INFO - 2018-03-30 15:00:52 --> Helper loaded: settings_helper
INFO - 2018-03-30 15:00:52 --> Helper loaded: permission_helper
INFO - 2018-03-30 15:00:52 --> Helper loaded: users_helper
INFO - 2018-03-30 15:00:52 --> Database Driver Class Initialized
DEBUG - 2018-03-30 15:00:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 15:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 15:00:52 --> Helper loaded: form_helper
INFO - 2018-03-30 15:00:52 --> Form Validation Class Initialized
INFO - 2018-03-30 15:00:52 --> Controller Class Initialized
INFO - 2018-03-30 15:00:52 --> Model Class Initialized
INFO - 2018-03-30 15:00:52 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 15:00:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 15:00:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 15:00:52 --> Model Class Initialized
INFO - 2018-03-30 15:00:52 --> Model Class Initialized
INFO - 2018-03-30 15:00:52 --> Model Class Initialized
INFO - 2018-03-30 15:00:52 --> Model Class Initialized
INFO - 2018-03-30 15:00:52 --> Model Class Initialized
INFO - 2018-03-30 15:00:52 --> Model Class Initialized
INFO - 2018-03-30 15:00:52 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-30 15:00:52 --> Model Class Initialized
INFO - 2018-03-30 15:00:52 --> Final output sent to browser
DEBUG - 2018-03-30 15:00:52 --> Total execution time: 0.5430
INFO - 2018-03-30 09:30:52 --> Config Class Initialized
INFO - 2018-03-30 09:30:52 --> Hooks Class Initialized
DEBUG - 2018-03-30 09:30:52 --> UTF-8 Support Enabled
INFO - 2018-03-30 09:30:52 --> Utf8 Class Initialized
INFO - 2018-03-30 09:30:52 --> URI Class Initialized
INFO - 2018-03-30 09:30:52 --> Router Class Initialized
INFO - 2018-03-30 09:30:52 --> Output Class Initialized
INFO - 2018-03-30 09:30:52 --> Security Class Initialized
DEBUG - 2018-03-30 09:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 09:30:52 --> Input Class Initialized
INFO - 2018-03-30 09:30:52 --> Language Class Initialized
INFO - 2018-03-30 09:30:52 --> Language Class Initialized
INFO - 2018-03-30 09:30:52 --> Config Class Initialized
INFO - 2018-03-30 09:30:52 --> Loader Class Initialized
INFO - 2018-03-30 15:00:53 --> Helper loaded: url_helper
INFO - 2018-03-30 15:00:53 --> Helper loaded: notification_helper
INFO - 2018-03-30 15:00:53 --> Helper loaded: settings_helper
INFO - 2018-03-30 15:00:53 --> Helper loaded: permission_helper
INFO - 2018-03-30 15:00:53 --> Helper loaded: users_helper
INFO - 2018-03-30 15:00:53 --> Database Driver Class Initialized
DEBUG - 2018-03-30 15:00:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 15:00:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 15:00:53 --> Helper loaded: form_helper
INFO - 2018-03-30 15:00:53 --> Form Validation Class Initialized
INFO - 2018-03-30 15:00:53 --> Controller Class Initialized
INFO - 2018-03-30 15:00:53 --> Model Class Initialized
INFO - 2018-03-30 15:00:53 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 15:00:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 15:00:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 15:00:53 --> Model Class Initialized
INFO - 2018-03-30 15:00:53 --> Model Class Initialized
INFO - 2018-03-30 15:00:53 --> Final output sent to browser
DEBUG - 2018-03-30 15:00:53 --> Total execution time: 0.1224
INFO - 2018-03-30 09:58:47 --> Config Class Initialized
INFO - 2018-03-30 09:58:47 --> Hooks Class Initialized
DEBUG - 2018-03-30 09:58:47 --> UTF-8 Support Enabled
INFO - 2018-03-30 09:58:47 --> Utf8 Class Initialized
INFO - 2018-03-30 09:58:48 --> URI Class Initialized
INFO - 2018-03-30 09:58:48 --> Router Class Initialized
INFO - 2018-03-30 09:58:48 --> Output Class Initialized
INFO - 2018-03-30 09:58:48 --> Security Class Initialized
DEBUG - 2018-03-30 09:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 09:58:48 --> Input Class Initialized
INFO - 2018-03-30 09:58:48 --> Language Class Initialized
INFO - 2018-03-30 09:58:48 --> Language Class Initialized
INFO - 2018-03-30 09:58:48 --> Config Class Initialized
INFO - 2018-03-30 09:58:48 --> Loader Class Initialized
INFO - 2018-03-30 15:28:48 --> Helper loaded: url_helper
INFO - 2018-03-30 15:28:48 --> Helper loaded: notification_helper
INFO - 2018-03-30 15:28:48 --> Helper loaded: settings_helper
INFO - 2018-03-30 15:28:48 --> Helper loaded: permission_helper
INFO - 2018-03-30 15:28:48 --> Helper loaded: users_helper
INFO - 2018-03-30 15:28:48 --> Database Driver Class Initialized
DEBUG - 2018-03-30 15:28:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 15:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 15:28:48 --> Helper loaded: form_helper
INFO - 2018-03-30 15:28:48 --> Form Validation Class Initialized
INFO - 2018-03-30 15:28:48 --> Controller Class Initialized
INFO - 2018-03-30 15:28:48 --> Model Class Initialized
INFO - 2018-03-30 15:28:48 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 15:28:48 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 15:28:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 15:28:48 --> Model Class Initialized
INFO - 2018-03-30 15:28:48 --> Model Class Initialized
INFO - 2018-03-30 15:28:48 --> Model Class Initialized
INFO - 2018-03-30 15:28:48 --> Model Class Initialized
INFO - 2018-03-30 15:28:48 --> Model Class Initialized
INFO - 2018-03-30 15:28:48 --> Model Class Initialized
INFO - 2018-03-30 15:28:48 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-30 15:28:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-30 15:28:48 --> Final output sent to browser
DEBUG - 2018-03-30 15:28:48 --> Total execution time: 1.1286
INFO - 2018-03-30 09:58:49 --> Config Class Initialized
INFO - 2018-03-30 09:58:49 --> Hooks Class Initialized
DEBUG - 2018-03-30 09:58:49 --> UTF-8 Support Enabled
INFO - 2018-03-30 09:58:49 --> Utf8 Class Initialized
INFO - 2018-03-30 09:58:49 --> URI Class Initialized
INFO - 2018-03-30 09:58:49 --> Router Class Initialized
INFO - 2018-03-30 09:58:49 --> Output Class Initialized
INFO - 2018-03-30 09:58:49 --> Security Class Initialized
DEBUG - 2018-03-30 09:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 09:58:49 --> Input Class Initialized
INFO - 2018-03-30 09:58:49 --> Language Class Initialized
INFO - 2018-03-30 09:58:50 --> Language Class Initialized
INFO - 2018-03-30 09:58:50 --> Config Class Initialized
INFO - 2018-03-30 09:58:50 --> Loader Class Initialized
INFO - 2018-03-30 15:28:50 --> Helper loaded: url_helper
INFO - 2018-03-30 15:28:50 --> Helper loaded: notification_helper
INFO - 2018-03-30 15:28:50 --> Helper loaded: settings_helper
INFO - 2018-03-30 15:28:50 --> Helper loaded: permission_helper
INFO - 2018-03-30 15:28:50 --> Helper loaded: users_helper
INFO - 2018-03-30 15:28:50 --> Database Driver Class Initialized
DEBUG - 2018-03-30 15:28:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 15:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 15:28:50 --> Helper loaded: form_helper
INFO - 2018-03-30 15:28:50 --> Form Validation Class Initialized
INFO - 2018-03-30 15:28:50 --> Controller Class Initialized
INFO - 2018-03-30 15:28:50 --> Model Class Initialized
INFO - 2018-03-30 15:28:50 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 15:28:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 15:28:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 15:28:50 --> Model Class Initialized
INFO - 2018-03-30 15:28:50 --> Model Class Initialized
INFO - 2018-03-30 15:28:50 --> Model Class Initialized
INFO - 2018-03-30 15:28:50 --> Model Class Initialized
INFO - 2018-03-30 15:28:50 --> Model Class Initialized
INFO - 2018-03-30 15:28:50 --> Model Class Initialized
INFO - 2018-03-30 15:28:50 --> Model Class Initialized
INFO - 2018-03-30 15:28:50 --> Model Class Initialized
INFO - 2018-03-30 15:28:50 --> Model Class Initialized
INFO - 2018-03-30 15:28:50 --> Model Class Initialized
INFO - 2018-03-30 15:28:50 --> Model Class Initialized
INFO - 2018-03-30 15:28:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-30 15:28:50 --> Model Class Initialized
INFO - 2018-03-30 15:28:50 --> Final output sent to browser
DEBUG - 2018-03-30 15:28:50 --> Total execution time: 0.9366
INFO - 2018-03-30 09:58:51 --> Config Class Initialized
INFO - 2018-03-30 09:58:51 --> Hooks Class Initialized
DEBUG - 2018-03-30 09:58:51 --> UTF-8 Support Enabled
INFO - 2018-03-30 09:58:51 --> Utf8 Class Initialized
INFO - 2018-03-30 09:58:51 --> URI Class Initialized
INFO - 2018-03-30 09:58:51 --> Router Class Initialized
INFO - 2018-03-30 09:58:51 --> Output Class Initialized
INFO - 2018-03-30 09:58:51 --> Security Class Initialized
DEBUG - 2018-03-30 09:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 09:58:51 --> Input Class Initialized
INFO - 2018-03-30 09:58:51 --> Language Class Initialized
INFO - 2018-03-30 09:58:52 --> Language Class Initialized
INFO - 2018-03-30 09:58:52 --> Config Class Initialized
INFO - 2018-03-30 09:58:52 --> Loader Class Initialized
INFO - 2018-03-30 15:28:52 --> Helper loaded: url_helper
INFO - 2018-03-30 15:28:52 --> Helper loaded: notification_helper
INFO - 2018-03-30 15:28:52 --> Helper loaded: settings_helper
INFO - 2018-03-30 15:28:52 --> Helper loaded: permission_helper
INFO - 2018-03-30 15:28:52 --> Helper loaded: users_helper
INFO - 2018-03-30 15:28:53 --> Database Driver Class Initialized
DEBUG - 2018-03-30 15:28:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 15:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 15:28:53 --> Helper loaded: form_helper
INFO - 2018-03-30 15:28:53 --> Form Validation Class Initialized
INFO - 2018-03-30 15:28:53 --> Controller Class Initialized
INFO - 2018-03-30 09:58:53 --> Config Class Initialized
INFO - 2018-03-30 09:58:53 --> Hooks Class Initialized
DEBUG - 2018-03-30 09:58:53 --> UTF-8 Support Enabled
INFO - 2018-03-30 09:58:53 --> Utf8 Class Initialized
INFO - 2018-03-30 09:58:53 --> URI Class Initialized
INFO - 2018-03-30 09:58:53 --> Router Class Initialized
INFO - 2018-03-30 15:28:53 --> Model Class Initialized
INFO - 2018-03-30 15:28:53 --> Helper loaded: inflector_helper
INFO - 2018-03-30 09:58:53 --> Output Class Initialized
DEBUG - 2018-03-30 15:28:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 09:58:53 --> Security Class Initialized
INFO - 2018-03-30 15:28:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 15:28:53 --> Model Class Initialized
INFO - 2018-03-30 15:28:53 --> Model Class Initialized
DEBUG - 2018-03-30 09:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 09:58:53 --> Input Class Initialized
INFO - 2018-03-30 15:28:53 --> Model Class Initialized
INFO - 2018-03-30 09:58:53 --> Language Class Initialized
INFO - 2018-03-30 15:28:53 --> Model Class Initialized
INFO - 2018-03-30 15:28:53 --> Model Class Initialized
INFO - 2018-03-30 15:28:53 --> Model Class Initialized
INFO - 2018-03-30 15:28:53 --> Model Class Initialized
INFO - 2018-03-30 15:28:53 --> Model Class Initialized
INFO - 2018-03-30 15:28:53 --> Model Class Initialized
INFO - 2018-03-30 15:28:53 --> Model Class Initialized
INFO - 2018-03-30 15:28:53 --> Model Class Initialized
INFO - 2018-03-30 15:28:53 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-30 15:28:53 --> Model Class Initialized
INFO - 2018-03-30 15:28:53 --> Final output sent to browser
DEBUG - 2018-03-30 15:28:53 --> Total execution time: 2.7191
INFO - 2018-03-30 09:58:53 --> Language Class Initialized
INFO - 2018-03-30 09:58:53 --> Config Class Initialized
INFO - 2018-03-30 09:58:53 --> Loader Class Initialized
INFO - 2018-03-30 15:28:53 --> Helper loaded: url_helper
INFO - 2018-03-30 15:28:53 --> Helper loaded: notification_helper
INFO - 2018-03-30 15:28:53 --> Helper loaded: settings_helper
INFO - 2018-03-30 15:28:53 --> Helper loaded: permission_helper
INFO - 2018-03-30 15:28:53 --> Helper loaded: users_helper
INFO - 2018-03-30 15:28:53 --> Database Driver Class Initialized
DEBUG - 2018-03-30 15:28:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 15:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 15:28:53 --> Helper loaded: form_helper
INFO - 2018-03-30 15:28:53 --> Form Validation Class Initialized
INFO - 2018-03-30 15:28:53 --> Controller Class Initialized
INFO - 2018-03-30 15:28:53 --> Model Class Initialized
INFO - 2018-03-30 15:28:53 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 15:28:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 15:28:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 15:28:53 --> Model Class Initialized
INFO - 2018-03-30 15:28:53 --> Model Class Initialized
INFO - 2018-03-30 15:28:53 --> Model Class Initialized
INFO - 2018-03-30 15:28:53 --> Model Class Initialized
INFO - 2018-03-30 15:28:53 --> Model Class Initialized
INFO - 2018-03-30 15:28:53 --> Model Class Initialized
INFO - 2018-03-30 15:28:53 --> Model Class Initialized
INFO - 2018-03-30 15:28:53 --> Model Class Initialized
INFO - 2018-03-30 15:28:53 --> Model Class Initialized
INFO - 2018-03-30 15:28:53 --> Model Class Initialized
INFO - 2018-03-30 15:28:53 --> Model Class Initialized
INFO - 2018-03-30 15:28:53 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-30 15:28:53 --> Model Class Initialized
INFO - 2018-03-30 15:28:53 --> Final output sent to browser
DEBUG - 2018-03-30 15:28:53 --> Total execution time: 0.6310
INFO - 2018-03-30 09:58:59 --> Config Class Initialized
INFO - 2018-03-30 09:58:59 --> Hooks Class Initialized
DEBUG - 2018-03-30 09:58:59 --> UTF-8 Support Enabled
INFO - 2018-03-30 09:58:59 --> Utf8 Class Initialized
INFO - 2018-03-30 09:58:59 --> URI Class Initialized
INFO - 2018-03-30 09:58:59 --> Router Class Initialized
INFO - 2018-03-30 09:58:59 --> Output Class Initialized
INFO - 2018-03-30 09:58:59 --> Security Class Initialized
DEBUG - 2018-03-30 09:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 09:58:59 --> Input Class Initialized
INFO - 2018-03-30 09:58:59 --> Language Class Initialized
INFO - 2018-03-30 09:58:59 --> Language Class Initialized
INFO - 2018-03-30 09:58:59 --> Config Class Initialized
INFO - 2018-03-30 09:58:59 --> Loader Class Initialized
INFO - 2018-03-30 15:28:59 --> Helper loaded: url_helper
INFO - 2018-03-30 15:28:59 --> Helper loaded: notification_helper
INFO - 2018-03-30 15:28:59 --> Helper loaded: settings_helper
INFO - 2018-03-30 15:28:59 --> Helper loaded: permission_helper
INFO - 2018-03-30 15:28:59 --> Helper loaded: users_helper
INFO - 2018-03-30 15:28:59 --> Database Driver Class Initialized
DEBUG - 2018-03-30 15:28:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 15:28:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 15:28:59 --> Helper loaded: form_helper
INFO - 2018-03-30 15:28:59 --> Form Validation Class Initialized
INFO - 2018-03-30 15:28:59 --> Controller Class Initialized
INFO - 2018-03-30 15:28:59 --> Model Class Initialized
INFO - 2018-03-30 15:28:59 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 15:28:59 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 15:28:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 15:28:59 --> Model Class Initialized
INFO - 2018-03-30 15:28:59 --> Model Class Initialized
INFO - 2018-03-30 15:28:59 --> Model Class Initialized
INFO - 2018-03-30 15:28:59 --> Model Class Initialized
INFO - 2018-03-30 15:28:59 --> Model Class Initialized
INFO - 2018-03-30 15:28:59 --> Model Class Initialized
INFO - 2018-03-30 15:28:59 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-30 15:28:59 --> Final output sent to browser
DEBUG - 2018-03-30 15:28:59 --> Total execution time: 0.5513
INFO - 2018-03-30 09:59:00 --> Config Class Initialized
INFO - 2018-03-30 09:59:00 --> Hooks Class Initialized
DEBUG - 2018-03-30 09:59:00 --> UTF-8 Support Enabled
INFO - 2018-03-30 09:59:00 --> Utf8 Class Initialized
INFO - 2018-03-30 09:59:01 --> URI Class Initialized
INFO - 2018-03-30 09:59:01 --> Router Class Initialized
INFO - 2018-03-30 09:59:01 --> Output Class Initialized
INFO - 2018-03-30 09:59:01 --> Security Class Initialized
DEBUG - 2018-03-30 09:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 09:59:01 --> Input Class Initialized
INFO - 2018-03-30 09:59:01 --> Language Class Initialized
INFO - 2018-03-30 09:59:01 --> Language Class Initialized
INFO - 2018-03-30 09:59:01 --> Config Class Initialized
INFO - 2018-03-30 09:59:01 --> Loader Class Initialized
INFO - 2018-03-30 15:29:01 --> Helper loaded: url_helper
INFO - 2018-03-30 15:29:01 --> Helper loaded: notification_helper
INFO - 2018-03-30 15:29:01 --> Helper loaded: settings_helper
INFO - 2018-03-30 15:29:01 --> Helper loaded: permission_helper
INFO - 2018-03-30 15:29:01 --> Helper loaded: users_helper
INFO - 2018-03-30 15:29:01 --> Database Driver Class Initialized
DEBUG - 2018-03-30 15:29:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 15:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 15:29:01 --> Helper loaded: form_helper
INFO - 2018-03-30 15:29:01 --> Form Validation Class Initialized
INFO - 2018-03-30 15:29:01 --> Controller Class Initialized
INFO - 2018-03-30 15:29:01 --> Model Class Initialized
INFO - 2018-03-30 15:29:01 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 15:29:01 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 15:29:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 15:29:01 --> Model Class Initialized
INFO - 2018-03-30 15:29:01 --> Model Class Initialized
INFO - 2018-03-30 15:29:01 --> Model Class Initialized
INFO - 2018-03-30 15:29:01 --> Model Class Initialized
INFO - 2018-03-30 15:29:01 --> Model Class Initialized
INFO - 2018-03-30 15:29:01 --> Model Class Initialized
INFO - 2018-03-30 15:29:01 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-30 15:29:01 --> Final output sent to browser
DEBUG - 2018-03-30 15:29:01 --> Total execution time: 1.2178
INFO - 2018-03-30 09:59:01 --> Config Class Initialized
INFO - 2018-03-30 09:59:01 --> Hooks Class Initialized
DEBUG - 2018-03-30 09:59:01 --> UTF-8 Support Enabled
INFO - 2018-03-30 09:59:01 --> Utf8 Class Initialized
INFO - 2018-03-30 09:59:01 --> URI Class Initialized
INFO - 2018-03-30 09:59:01 --> Router Class Initialized
INFO - 2018-03-30 09:59:01 --> Output Class Initialized
INFO - 2018-03-30 09:59:01 --> Security Class Initialized
DEBUG - 2018-03-30 09:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 09:59:01 --> Input Class Initialized
INFO - 2018-03-30 09:59:01 --> Language Class Initialized
INFO - 2018-03-30 09:59:01 --> Language Class Initialized
INFO - 2018-03-30 09:59:01 --> Config Class Initialized
INFO - 2018-03-30 09:59:01 --> Loader Class Initialized
INFO - 2018-03-30 15:29:01 --> Helper loaded: url_helper
INFO - 2018-03-30 15:29:01 --> Helper loaded: notification_helper
INFO - 2018-03-30 15:29:01 --> Helper loaded: settings_helper
INFO - 2018-03-30 15:29:01 --> Helper loaded: permission_helper
INFO - 2018-03-30 15:29:01 --> Helper loaded: users_helper
INFO - 2018-03-30 15:29:02 --> Database Driver Class Initialized
DEBUG - 2018-03-30 15:29:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 15:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 15:29:02 --> Helper loaded: form_helper
INFO - 2018-03-30 15:29:02 --> Form Validation Class Initialized
INFO - 2018-03-30 15:29:02 --> Controller Class Initialized
INFO - 2018-03-30 15:29:02 --> Model Class Initialized
INFO - 2018-03-30 15:29:02 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 15:29:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 15:29:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 15:29:02 --> Model Class Initialized
INFO - 2018-03-30 15:29:02 --> Model Class Initialized
INFO - 2018-03-30 15:29:02 --> Model Class Initialized
INFO - 2018-03-30 15:29:02 --> Model Class Initialized
INFO - 2018-03-30 15:29:02 --> Model Class Initialized
INFO - 2018-03-30 15:29:02 --> Model Class Initialized
INFO - 2018-03-30 15:29:02 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-30 15:29:02 --> Final output sent to browser
DEBUG - 2018-03-30 15:29:02 --> Total execution time: 0.6084
INFO - 2018-03-30 09:59:06 --> Config Class Initialized
INFO - 2018-03-30 09:59:06 --> Hooks Class Initialized
DEBUG - 2018-03-30 09:59:06 --> UTF-8 Support Enabled
INFO - 2018-03-30 09:59:06 --> Utf8 Class Initialized
INFO - 2018-03-30 09:59:06 --> URI Class Initialized
INFO - 2018-03-30 09:59:06 --> Router Class Initialized
INFO - 2018-03-30 09:59:07 --> Config Class Initialized
INFO - 2018-03-30 09:59:07 --> Hooks Class Initialized
DEBUG - 2018-03-30 09:59:07 --> UTF-8 Support Enabled
INFO - 2018-03-30 09:59:07 --> Utf8 Class Initialized
INFO - 2018-03-30 09:59:07 --> URI Class Initialized
INFO - 2018-03-30 09:59:07 --> Router Class Initialized
INFO - 2018-03-30 09:59:07 --> Output Class Initialized
INFO - 2018-03-30 09:59:07 --> Security Class Initialized
DEBUG - 2018-03-30 09:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 09:59:07 --> Input Class Initialized
INFO - 2018-03-30 09:59:07 --> Language Class Initialized
INFO - 2018-03-30 09:59:07 --> Language Class Initialized
INFO - 2018-03-30 09:59:07 --> Config Class Initialized
INFO - 2018-03-30 09:59:07 --> Loader Class Initialized
INFO - 2018-03-30 15:29:07 --> Helper loaded: url_helper
INFO - 2018-03-30 15:29:07 --> Helper loaded: notification_helper
INFO - 2018-03-30 15:29:07 --> Helper loaded: settings_helper
INFO - 2018-03-30 15:29:07 --> Helper loaded: permission_helper
INFO - 2018-03-30 15:29:07 --> Helper loaded: users_helper
INFO - 2018-03-30 09:59:07 --> Output Class Initialized
INFO - 2018-03-30 15:29:07 --> Database Driver Class Initialized
DEBUG - 2018-03-30 15:29:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 15:29:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 09:59:07 --> Security Class Initialized
INFO - 2018-03-30 15:29:07 --> Helper loaded: form_helper
INFO - 2018-03-30 15:29:07 --> Form Validation Class Initialized
INFO - 2018-03-30 15:29:07 --> Controller Class Initialized
INFO - 2018-03-30 15:29:07 --> Model Class Initialized
INFO - 2018-03-30 15:29:07 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 15:29:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 15:29:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 15:29:07 --> Model Class Initialized
INFO - 2018-03-30 15:29:07 --> Model Class Initialized
INFO - 2018-03-30 15:29:07 --> Final output sent to browser
DEBUG - 2018-03-30 15:29:07 --> Total execution time: 0.3933
DEBUG - 2018-03-30 09:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 09:59:07 --> Input Class Initialized
INFO - 2018-03-30 09:59:07 --> Language Class Initialized
INFO - 2018-03-30 09:59:08 --> Language Class Initialized
INFO - 2018-03-30 09:59:08 --> Config Class Initialized
INFO - 2018-03-30 09:59:08 --> Loader Class Initialized
INFO - 2018-03-30 15:29:08 --> Helper loaded: url_helper
INFO - 2018-03-30 15:29:08 --> Helper loaded: notification_helper
INFO - 2018-03-30 15:29:08 --> Helper loaded: settings_helper
INFO - 2018-03-30 15:29:08 --> Helper loaded: permission_helper
INFO - 2018-03-30 15:29:08 --> Helper loaded: users_helper
INFO - 2018-03-30 15:29:09 --> Database Driver Class Initialized
DEBUG - 2018-03-30 15:29:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 15:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 15:29:09 --> Helper loaded: form_helper
INFO - 2018-03-30 15:29:09 --> Form Validation Class Initialized
INFO - 2018-03-30 15:29:09 --> Controller Class Initialized
INFO - 2018-03-30 15:29:09 --> Model Class Initialized
INFO - 2018-03-30 15:29:09 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 15:29:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 15:29:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 15:29:09 --> Model Class Initialized
INFO - 2018-03-30 15:29:09 --> Model Class Initialized
INFO - 2018-03-30 15:29:09 --> Final output sent to browser
DEBUG - 2018-03-30 15:29:09 --> Total execution time: 3.9802
INFO - 2018-03-30 09:59:29 --> Config Class Initialized
INFO - 2018-03-30 09:59:29 --> Hooks Class Initialized
DEBUG - 2018-03-30 09:59:29 --> UTF-8 Support Enabled
INFO - 2018-03-30 09:59:29 --> Utf8 Class Initialized
INFO - 2018-03-30 09:59:29 --> URI Class Initialized
INFO - 2018-03-30 09:59:29 --> Router Class Initialized
INFO - 2018-03-30 09:59:29 --> Output Class Initialized
INFO - 2018-03-30 09:59:29 --> Security Class Initialized
DEBUG - 2018-03-30 09:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 09:59:29 --> Input Class Initialized
INFO - 2018-03-30 09:59:29 --> Language Class Initialized
INFO - 2018-03-30 09:59:29 --> Language Class Initialized
INFO - 2018-03-30 09:59:29 --> Config Class Initialized
INFO - 2018-03-30 09:59:29 --> Loader Class Initialized
INFO - 2018-03-30 15:29:29 --> Helper loaded: url_helper
INFO - 2018-03-30 15:29:29 --> Helper loaded: notification_helper
INFO - 2018-03-30 15:29:29 --> Helper loaded: settings_helper
INFO - 2018-03-30 15:29:29 --> Helper loaded: permission_helper
INFO - 2018-03-30 15:29:29 --> Helper loaded: users_helper
INFO - 2018-03-30 15:29:29 --> Database Driver Class Initialized
DEBUG - 2018-03-30 15:29:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 15:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 15:29:29 --> Helper loaded: form_helper
INFO - 2018-03-30 15:29:29 --> Form Validation Class Initialized
INFO - 2018-03-30 15:29:29 --> Controller Class Initialized
INFO - 2018-03-30 15:29:29 --> Model Class Initialized
INFO - 2018-03-30 15:29:29 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 15:29:29 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 15:29:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 15:29:29 --> Model Class Initialized
INFO - 2018-03-30 15:29:29 --> Model Class Initialized
INFO - 2018-03-30 15:29:29 --> Model Class Initialized
INFO - 2018-03-30 15:29:29 --> Model Class Initialized
INFO - 2018-03-30 15:29:29 --> Model Class Initialized
INFO - 2018-03-30 15:29:29 --> Model Class Initialized
INFO - 2018-03-30 15:29:29 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-30 15:29:29 --> Model Class Initialized
INFO - 2018-03-30 15:29:29 --> Final output sent to browser
DEBUG - 2018-03-30 15:29:29 --> Total execution time: 0.4045
INFO - 2018-03-30 09:59:52 --> Config Class Initialized
INFO - 2018-03-30 09:59:52 --> Hooks Class Initialized
DEBUG - 2018-03-30 09:59:52 --> UTF-8 Support Enabled
INFO - 2018-03-30 09:59:52 --> Utf8 Class Initialized
INFO - 2018-03-30 09:59:52 --> URI Class Initialized
INFO - 2018-03-30 09:59:52 --> Router Class Initialized
INFO - 2018-03-30 09:59:52 --> Output Class Initialized
INFO - 2018-03-30 09:59:52 --> Security Class Initialized
DEBUG - 2018-03-30 09:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 09:59:52 --> Input Class Initialized
INFO - 2018-03-30 09:59:52 --> Language Class Initialized
INFO - 2018-03-30 09:59:52 --> Language Class Initialized
INFO - 2018-03-30 09:59:52 --> Config Class Initialized
INFO - 2018-03-30 09:59:52 --> Loader Class Initialized
INFO - 2018-03-30 15:29:52 --> Helper loaded: url_helper
INFO - 2018-03-30 15:29:52 --> Helper loaded: notification_helper
INFO - 2018-03-30 15:29:52 --> Helper loaded: settings_helper
INFO - 2018-03-30 15:29:52 --> Helper loaded: permission_helper
INFO - 2018-03-30 15:29:52 --> Helper loaded: users_helper
INFO - 2018-03-30 15:29:52 --> Database Driver Class Initialized
DEBUG - 2018-03-30 15:29:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 15:29:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 15:29:52 --> Helper loaded: form_helper
INFO - 2018-03-30 15:29:52 --> Form Validation Class Initialized
INFO - 2018-03-30 15:29:52 --> Controller Class Initialized
INFO - 2018-03-30 15:29:52 --> Model Class Initialized
INFO - 2018-03-30 15:29:52 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 15:29:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 15:29:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 15:29:52 --> Model Class Initialized
INFO - 2018-03-30 15:29:52 --> Model Class Initialized
INFO - 2018-03-30 15:29:52 --> Model Class Initialized
INFO - 2018-03-30 15:29:52 --> Model Class Initialized
INFO - 2018-03-30 15:29:52 --> Model Class Initialized
INFO - 2018-03-30 15:29:52 --> Model Class Initialized
INFO - 2018-03-30 15:29:52 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-30 15:29:52 --> Model Class Initialized
INFO - 2018-03-30 15:29:52 --> Final output sent to browser
DEBUG - 2018-03-30 15:29:52 --> Total execution time: 0.3761
INFO - 2018-03-30 10:00:02 --> Config Class Initialized
INFO - 2018-03-30 10:00:02 --> Hooks Class Initialized
DEBUG - 2018-03-30 10:00:02 --> UTF-8 Support Enabled
INFO - 2018-03-30 10:00:02 --> Utf8 Class Initialized
INFO - 2018-03-30 10:00:02 --> URI Class Initialized
INFO - 2018-03-30 10:00:03 --> Router Class Initialized
INFO - 2018-03-30 10:00:03 --> Output Class Initialized
INFO - 2018-03-30 10:00:03 --> Security Class Initialized
DEBUG - 2018-03-30 10:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 10:00:04 --> Input Class Initialized
INFO - 2018-03-30 10:00:04 --> Language Class Initialized
INFO - 2018-03-30 10:00:04 --> Language Class Initialized
INFO - 2018-03-30 10:00:04 --> Config Class Initialized
INFO - 2018-03-30 10:00:04 --> Loader Class Initialized
INFO - 2018-03-30 15:30:05 --> Helper loaded: url_helper
INFO - 2018-03-30 15:30:05 --> Helper loaded: notification_helper
INFO - 2018-03-30 15:30:05 --> Helper loaded: settings_helper
INFO - 2018-03-30 15:30:05 --> Helper loaded: permission_helper
INFO - 2018-03-30 15:30:05 --> Helper loaded: users_helper
INFO - 2018-03-30 15:30:05 --> Database Driver Class Initialized
DEBUG - 2018-03-30 15:30:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 15:30:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 15:30:05 --> Helper loaded: form_helper
INFO - 2018-03-30 15:30:05 --> Form Validation Class Initialized
INFO - 2018-03-30 15:30:05 --> Controller Class Initialized
INFO - 2018-03-30 15:30:05 --> Model Class Initialized
INFO - 2018-03-30 15:30:05 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 15:30:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 15:30:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 15:30:05 --> Model Class Initialized
INFO - 2018-03-30 15:30:05 --> Model Class Initialized
INFO - 2018-03-30 15:30:05 --> Final output sent to browser
DEBUG - 2018-03-30 15:30:05 --> Total execution time: 4.0122
INFO - 2018-03-30 10:00:06 --> Config Class Initialized
INFO - 2018-03-30 10:00:06 --> Hooks Class Initialized
DEBUG - 2018-03-30 10:00:06 --> UTF-8 Support Enabled
INFO - 2018-03-30 10:00:06 --> Utf8 Class Initialized
INFO - 2018-03-30 10:00:06 --> URI Class Initialized
INFO - 2018-03-30 10:00:07 --> Router Class Initialized
INFO - 2018-03-30 10:00:07 --> Output Class Initialized
INFO - 2018-03-30 10:00:07 --> Security Class Initialized
DEBUG - 2018-03-30 10:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 10:00:07 --> Input Class Initialized
INFO - 2018-03-30 10:00:07 --> Language Class Initialized
INFO - 2018-03-30 10:00:08 --> Language Class Initialized
INFO - 2018-03-30 10:00:08 --> Config Class Initialized
INFO - 2018-03-30 10:00:08 --> Loader Class Initialized
INFO - 2018-03-30 15:30:08 --> Helper loaded: url_helper
INFO - 2018-03-30 15:30:08 --> Helper loaded: notification_helper
INFO - 2018-03-30 15:30:08 --> Helper loaded: settings_helper
INFO - 2018-03-30 15:30:08 --> Helper loaded: permission_helper
INFO - 2018-03-30 15:30:08 --> Helper loaded: users_helper
INFO - 2018-03-30 15:30:09 --> Database Driver Class Initialized
DEBUG - 2018-03-30 15:30:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 15:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 15:30:09 --> Helper loaded: form_helper
INFO - 2018-03-30 15:30:09 --> Form Validation Class Initialized
INFO - 2018-03-30 15:30:09 --> Controller Class Initialized
INFO - 2018-03-30 15:30:09 --> Model Class Initialized
INFO - 2018-03-30 15:30:09 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 15:30:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 15:30:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 15:30:09 --> Model Class Initialized
INFO - 2018-03-30 15:30:09 --> Model Class Initialized
INFO - 2018-03-30 15:30:09 --> Final output sent to browser
DEBUG - 2018-03-30 15:30:09 --> Total execution time: 2.8042
INFO - 2018-03-30 12:44:02 --> Config Class Initialized
INFO - 2018-03-30 12:44:02 --> Hooks Class Initialized
DEBUG - 2018-03-30 12:44:02 --> UTF-8 Support Enabled
INFO - 2018-03-30 12:44:02 --> Utf8 Class Initialized
INFO - 2018-03-30 12:44:02 --> URI Class Initialized
INFO - 2018-03-30 12:44:02 --> Router Class Initialized
INFO - 2018-03-30 12:44:02 --> Output Class Initialized
INFO - 2018-03-30 12:44:02 --> Security Class Initialized
DEBUG - 2018-03-30 12:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 12:44:02 --> Input Class Initialized
INFO - 2018-03-30 12:44:02 --> Language Class Initialized
INFO - 2018-03-30 12:44:02 --> Language Class Initialized
INFO - 2018-03-30 12:44:02 --> Config Class Initialized
INFO - 2018-03-30 12:44:02 --> Loader Class Initialized
INFO - 2018-03-30 18:14:03 --> Helper loaded: url_helper
INFO - 2018-03-30 18:14:03 --> Helper loaded: notification_helper
INFO - 2018-03-30 18:14:03 --> Helper loaded: settings_helper
INFO - 2018-03-30 18:14:03 --> Helper loaded: permission_helper
INFO - 2018-03-30 18:14:03 --> Helper loaded: users_helper
INFO - 2018-03-30 18:14:04 --> Database Driver Class Initialized
DEBUG - 2018-03-30 18:14:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 18:14:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 18:14:04 --> Helper loaded: form_helper
INFO - 2018-03-30 18:14:04 --> Form Validation Class Initialized
INFO - 2018-03-30 18:14:04 --> Controller Class Initialized
INFO - 2018-03-30 18:14:04 --> Model Class Initialized
INFO - 2018-03-30 18:14:04 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 18:14:04 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 18:14:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 18:14:04 --> Model Class Initialized
INFO - 2018-03-30 18:14:04 --> Model Class Initialized
INFO - 2018-03-30 18:14:04 --> Model Class Initialized
INFO - 2018-03-30 18:14:04 --> Model Class Initialized
INFO - 2018-03-30 18:14:04 --> Model Class Initialized
INFO - 2018-03-30 18:14:04 --> Model Class Initialized
INFO - 2018-03-30 18:14:04 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-30 18:14:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-30 18:14:04 --> Final output sent to browser
DEBUG - 2018-03-30 18:14:04 --> Total execution time: 1.8775
INFO - 2018-03-30 12:44:05 --> Config Class Initialized
INFO - 2018-03-30 12:44:05 --> Hooks Class Initialized
DEBUG - 2018-03-30 12:44:05 --> UTF-8 Support Enabled
INFO - 2018-03-30 12:44:05 --> Utf8 Class Initialized
INFO - 2018-03-30 12:44:05 --> URI Class Initialized
INFO - 2018-03-30 12:44:05 --> Router Class Initialized
INFO - 2018-03-30 12:44:05 --> Output Class Initialized
INFO - 2018-03-30 12:44:05 --> Security Class Initialized
DEBUG - 2018-03-30 12:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 12:44:05 --> Input Class Initialized
INFO - 2018-03-30 12:44:05 --> Language Class Initialized
INFO - 2018-03-30 12:44:05 --> Language Class Initialized
INFO - 2018-03-30 12:44:05 --> Config Class Initialized
INFO - 2018-03-30 12:44:05 --> Loader Class Initialized
INFO - 2018-03-30 18:14:05 --> Helper loaded: url_helper
INFO - 2018-03-30 18:14:05 --> Helper loaded: notification_helper
INFO - 2018-03-30 18:14:05 --> Helper loaded: settings_helper
INFO - 2018-03-30 18:14:05 --> Helper loaded: permission_helper
INFO - 2018-03-30 18:14:05 --> Helper loaded: users_helper
INFO - 2018-03-30 18:14:05 --> Database Driver Class Initialized
DEBUG - 2018-03-30 18:14:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 18:14:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 18:14:05 --> Helper loaded: form_helper
INFO - 2018-03-30 18:14:05 --> Form Validation Class Initialized
INFO - 2018-03-30 18:14:05 --> Controller Class Initialized
INFO - 2018-03-30 18:14:05 --> Model Class Initialized
INFO - 2018-03-30 18:14:05 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 18:14:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 18:14:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 18:14:05 --> Model Class Initialized
INFO - 2018-03-30 18:14:05 --> Model Class Initialized
INFO - 2018-03-30 18:14:05 --> Model Class Initialized
INFO - 2018-03-30 18:14:05 --> Model Class Initialized
INFO - 2018-03-30 18:14:05 --> Model Class Initialized
INFO - 2018-03-30 18:14:05 --> Model Class Initialized
INFO - 2018-03-30 18:14:05 --> Model Class Initialized
INFO - 2018-03-30 18:14:05 --> Model Class Initialized
INFO - 2018-03-30 18:14:05 --> Model Class Initialized
INFO - 2018-03-30 18:14:05 --> Model Class Initialized
INFO - 2018-03-30 18:14:05 --> Model Class Initialized
INFO - 2018-03-30 18:14:05 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-30 18:14:05 --> Model Class Initialized
INFO - 2018-03-30 18:14:05 --> Final output sent to browser
DEBUG - 2018-03-30 18:14:05 --> Total execution time: 0.1185
INFO - 2018-03-30 12:44:05 --> Config Class Initialized
INFO - 2018-03-30 12:44:05 --> Hooks Class Initialized
DEBUG - 2018-03-30 12:44:05 --> UTF-8 Support Enabled
INFO - 2018-03-30 12:44:05 --> Utf8 Class Initialized
INFO - 2018-03-30 12:44:05 --> URI Class Initialized
INFO - 2018-03-30 12:44:05 --> Router Class Initialized
INFO - 2018-03-30 12:44:05 --> Output Class Initialized
INFO - 2018-03-30 12:44:05 --> Security Class Initialized
DEBUG - 2018-03-30 12:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 12:44:05 --> Input Class Initialized
INFO - 2018-03-30 12:44:05 --> Language Class Initialized
INFO - 2018-03-30 12:44:05 --> Language Class Initialized
INFO - 2018-03-30 12:44:05 --> Config Class Initialized
INFO - 2018-03-30 12:44:05 --> Loader Class Initialized
INFO - 2018-03-30 18:14:05 --> Helper loaded: url_helper
INFO - 2018-03-30 18:14:05 --> Helper loaded: notification_helper
INFO - 2018-03-30 18:14:05 --> Helper loaded: settings_helper
INFO - 2018-03-30 18:14:05 --> Helper loaded: permission_helper
INFO - 2018-03-30 18:14:05 --> Helper loaded: users_helper
INFO - 2018-03-30 18:14:05 --> Database Driver Class Initialized
DEBUG - 2018-03-30 18:14:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 18:14:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 18:14:05 --> Helper loaded: form_helper
INFO - 2018-03-30 18:14:05 --> Form Validation Class Initialized
INFO - 2018-03-30 18:14:05 --> Controller Class Initialized
INFO - 2018-03-30 18:14:05 --> Model Class Initialized
INFO - 2018-03-30 18:14:05 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 18:14:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 18:14:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 18:14:05 --> Model Class Initialized
INFO - 2018-03-30 18:14:05 --> Model Class Initialized
INFO - 2018-03-30 18:14:05 --> Model Class Initialized
INFO - 2018-03-30 18:14:05 --> Model Class Initialized
INFO - 2018-03-30 18:14:05 --> Model Class Initialized
INFO - 2018-03-30 18:14:05 --> Model Class Initialized
INFO - 2018-03-30 18:14:05 --> Model Class Initialized
INFO - 2018-03-30 18:14:05 --> Model Class Initialized
INFO - 2018-03-30 18:14:05 --> Model Class Initialized
INFO - 2018-03-30 18:14:05 --> Model Class Initialized
INFO - 2018-03-30 18:14:05 --> Model Class Initialized
INFO - 2018-03-30 18:14:05 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-30 18:14:05 --> Model Class Initialized
INFO - 2018-03-30 18:14:05 --> Final output sent to browser
DEBUG - 2018-03-30 18:14:05 --> Total execution time: 0.2085
INFO - 2018-03-30 12:51:06 --> Config Class Initialized
INFO - 2018-03-30 12:51:06 --> Hooks Class Initialized
DEBUG - 2018-03-30 12:51:06 --> UTF-8 Support Enabled
INFO - 2018-03-30 12:51:06 --> Utf8 Class Initialized
INFO - 2018-03-30 12:51:06 --> URI Class Initialized
INFO - 2018-03-30 12:51:06 --> Router Class Initialized
INFO - 2018-03-30 12:51:06 --> Output Class Initialized
INFO - 2018-03-30 12:51:06 --> Security Class Initialized
DEBUG - 2018-03-30 12:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 12:51:06 --> Input Class Initialized
INFO - 2018-03-30 12:51:06 --> Language Class Initialized
INFO - 2018-03-30 12:51:06 --> Language Class Initialized
INFO - 2018-03-30 12:51:06 --> Config Class Initialized
INFO - 2018-03-30 12:51:06 --> Loader Class Initialized
INFO - 2018-03-30 18:21:06 --> Helper loaded: url_helper
INFO - 2018-03-30 18:21:06 --> Helper loaded: notification_helper
INFO - 2018-03-30 18:21:06 --> Helper loaded: settings_helper
INFO - 2018-03-30 18:21:06 --> Helper loaded: permission_helper
INFO - 2018-03-30 18:21:06 --> Helper loaded: users_helper
INFO - 2018-03-30 18:21:06 --> Database Driver Class Initialized
DEBUG - 2018-03-30 18:21:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 18:21:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 18:21:06 --> Helper loaded: form_helper
INFO - 2018-03-30 18:21:06 --> Form Validation Class Initialized
INFO - 2018-03-30 18:21:06 --> Controller Class Initialized
INFO - 2018-03-30 18:21:06 --> Model Class Initialized
INFO - 2018-03-30 18:21:06 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 18:21:06 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 18:21:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 18:21:06 --> Model Class Initialized
INFO - 2018-03-30 18:21:06 --> Model Class Initialized
INFO - 2018-03-30 18:21:06 --> Model Class Initialized
INFO - 2018-03-30 18:21:06 --> Model Class Initialized
INFO - 2018-03-30 18:21:06 --> Model Class Initialized
INFO - 2018-03-30 18:21:06 --> Model Class Initialized
INFO - 2018-03-30 18:21:06 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-30 18:21:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-30 18:21:07 --> Final output sent to browser
DEBUG - 2018-03-30 18:21:07 --> Total execution time: 0.3878
INFO - 2018-03-30 12:51:08 --> Config Class Initialized
INFO - 2018-03-30 12:51:08 --> Hooks Class Initialized
DEBUG - 2018-03-30 12:51:08 --> UTF-8 Support Enabled
INFO - 2018-03-30 12:51:08 --> Utf8 Class Initialized
INFO - 2018-03-30 12:51:08 --> URI Class Initialized
INFO - 2018-03-30 12:51:08 --> Router Class Initialized
INFO - 2018-03-30 12:51:08 --> Output Class Initialized
INFO - 2018-03-30 12:51:08 --> Security Class Initialized
DEBUG - 2018-03-30 12:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 12:51:08 --> Input Class Initialized
INFO - 2018-03-30 12:51:08 --> Language Class Initialized
INFO - 2018-03-30 12:51:08 --> Language Class Initialized
INFO - 2018-03-30 12:51:08 --> Config Class Initialized
INFO - 2018-03-30 12:51:08 --> Loader Class Initialized
INFO - 2018-03-30 18:21:08 --> Helper loaded: url_helper
INFO - 2018-03-30 18:21:08 --> Helper loaded: notification_helper
INFO - 2018-03-30 18:21:08 --> Helper loaded: settings_helper
INFO - 2018-03-30 18:21:08 --> Helper loaded: permission_helper
INFO - 2018-03-30 18:21:08 --> Helper loaded: users_helper
INFO - 2018-03-30 18:21:08 --> Database Driver Class Initialized
DEBUG - 2018-03-30 18:21:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 18:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 18:21:08 --> Helper loaded: form_helper
INFO - 2018-03-30 18:21:08 --> Form Validation Class Initialized
INFO - 2018-03-30 18:21:08 --> Controller Class Initialized
INFO - 2018-03-30 12:51:08 --> Config Class Initialized
INFO - 2018-03-30 12:51:08 --> Hooks Class Initialized
INFO - 2018-03-30 18:21:08 --> Model Class Initialized
INFO - 2018-03-30 18:21:08 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 18:21:08 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 18:21:08 --> Language file loaded: language/english/rest_controller_lang.php
DEBUG - 2018-03-30 12:51:08 --> UTF-8 Support Enabled
INFO - 2018-03-30 12:51:08 --> Utf8 Class Initialized
INFO - 2018-03-30 18:21:08 --> Model Class Initialized
INFO - 2018-03-30 18:21:08 --> Model Class Initialized
INFO - 2018-03-30 18:21:08 --> Model Class Initialized
INFO - 2018-03-30 18:21:08 --> Model Class Initialized
INFO - 2018-03-30 18:21:08 --> Model Class Initialized
INFO - 2018-03-30 18:21:08 --> Model Class Initialized
INFO - 2018-03-30 18:21:08 --> Model Class Initialized
INFO - 2018-03-30 12:51:08 --> URI Class Initialized
INFO - 2018-03-30 18:21:08 --> Model Class Initialized
INFO - 2018-03-30 18:21:08 --> Model Class Initialized
INFO - 2018-03-30 18:21:08 --> Model Class Initialized
INFO - 2018-03-30 18:21:08 --> Model Class Initialized
INFO - 2018-03-30 18:21:08 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-30 18:21:08 --> Model Class Initialized
INFO - 2018-03-30 12:51:08 --> Router Class Initialized
INFO - 2018-03-30 18:21:08 --> Final output sent to browser
DEBUG - 2018-03-30 18:21:08 --> Total execution time: 0.1202
INFO - 2018-03-30 12:51:08 --> Output Class Initialized
INFO - 2018-03-30 12:51:08 --> Security Class Initialized
DEBUG - 2018-03-30 12:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 12:51:08 --> Input Class Initialized
INFO - 2018-03-30 12:51:08 --> Language Class Initialized
INFO - 2018-03-30 12:51:08 --> Language Class Initialized
INFO - 2018-03-30 12:51:08 --> Config Class Initialized
INFO - 2018-03-30 12:51:08 --> Loader Class Initialized
INFO - 2018-03-30 18:21:08 --> Helper loaded: url_helper
INFO - 2018-03-30 18:21:08 --> Helper loaded: notification_helper
INFO - 2018-03-30 18:21:08 --> Helper loaded: settings_helper
INFO - 2018-03-30 18:21:08 --> Helper loaded: permission_helper
INFO - 2018-03-30 18:21:08 --> Helper loaded: users_helper
INFO - 2018-03-30 18:21:08 --> Database Driver Class Initialized
DEBUG - 2018-03-30 18:21:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 18:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 18:21:08 --> Helper loaded: form_helper
INFO - 2018-03-30 18:21:08 --> Form Validation Class Initialized
INFO - 2018-03-30 18:21:08 --> Controller Class Initialized
INFO - 2018-03-30 18:21:08 --> Model Class Initialized
INFO - 2018-03-30 18:21:08 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 18:21:08 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 18:21:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 18:21:08 --> Model Class Initialized
INFO - 2018-03-30 18:21:08 --> Model Class Initialized
INFO - 2018-03-30 18:21:08 --> Model Class Initialized
INFO - 2018-03-30 18:21:08 --> Model Class Initialized
INFO - 2018-03-30 18:21:08 --> Model Class Initialized
INFO - 2018-03-30 18:21:08 --> Model Class Initialized
INFO - 2018-03-30 18:21:08 --> Model Class Initialized
INFO - 2018-03-30 18:21:08 --> Model Class Initialized
INFO - 2018-03-30 18:21:08 --> Model Class Initialized
INFO - 2018-03-30 18:21:08 --> Model Class Initialized
INFO - 2018-03-30 18:21:08 --> Model Class Initialized
INFO - 2018-03-30 18:21:08 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-30 18:21:08 --> Model Class Initialized
INFO - 2018-03-30 18:21:08 --> Final output sent to browser
DEBUG - 2018-03-30 18:21:08 --> Total execution time: 0.1490
INFO - 2018-03-30 12:51:11 --> Config Class Initialized
INFO - 2018-03-30 12:51:11 --> Hooks Class Initialized
DEBUG - 2018-03-30 12:51:11 --> UTF-8 Support Enabled
INFO - 2018-03-30 12:51:11 --> Utf8 Class Initialized
INFO - 2018-03-30 12:51:11 --> URI Class Initialized
INFO - 2018-03-30 12:51:11 --> Router Class Initialized
INFO - 2018-03-30 12:51:11 --> Output Class Initialized
INFO - 2018-03-30 12:51:11 --> Security Class Initialized
DEBUG - 2018-03-30 12:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 12:51:11 --> Input Class Initialized
INFO - 2018-03-30 12:51:11 --> Language Class Initialized
INFO - 2018-03-30 12:51:11 --> Language Class Initialized
INFO - 2018-03-30 12:51:11 --> Config Class Initialized
INFO - 2018-03-30 12:51:11 --> Loader Class Initialized
INFO - 2018-03-30 18:21:11 --> Helper loaded: url_helper
INFO - 2018-03-30 18:21:11 --> Helper loaded: notification_helper
INFO - 2018-03-30 18:21:11 --> Helper loaded: settings_helper
INFO - 2018-03-30 18:21:11 --> Helper loaded: permission_helper
INFO - 2018-03-30 18:21:11 --> Helper loaded: users_helper
INFO - 2018-03-30 18:21:11 --> Database Driver Class Initialized
DEBUG - 2018-03-30 18:21:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 18:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 18:21:11 --> Helper loaded: form_helper
INFO - 2018-03-30 18:21:11 --> Form Validation Class Initialized
INFO - 2018-03-30 18:21:11 --> Controller Class Initialized
INFO - 2018-03-30 18:21:11 --> Model Class Initialized
INFO - 2018-03-30 18:21:11 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 18:21:11 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 18:21:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 18:21:11 --> Model Class Initialized
INFO - 2018-03-30 18:21:11 --> Model Class Initialized
INFO - 2018-03-30 18:21:11 --> Model Class Initialized
INFO - 2018-03-30 18:21:11 --> Model Class Initialized
INFO - 2018-03-30 18:21:11 --> Model Class Initialized
INFO - 2018-03-30 18:21:11 --> Model Class Initialized
INFO - 2018-03-30 18:21:11 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-30 18:21:11 --> Final output sent to browser
DEBUG - 2018-03-30 18:21:11 --> Total execution time: 0.1205
INFO - 2018-03-30 12:51:11 --> Config Class Initialized
INFO - 2018-03-30 12:51:11 --> Hooks Class Initialized
DEBUG - 2018-03-30 12:51:11 --> UTF-8 Support Enabled
INFO - 2018-03-30 12:51:11 --> Utf8 Class Initialized
INFO - 2018-03-30 12:51:11 --> URI Class Initialized
INFO - 2018-03-30 12:51:11 --> Router Class Initialized
INFO - 2018-03-30 12:51:11 --> Output Class Initialized
INFO - 2018-03-30 12:51:12 --> Security Class Initialized
DEBUG - 2018-03-30 12:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 12:51:12 --> Input Class Initialized
INFO - 2018-03-30 12:51:12 --> Language Class Initialized
INFO - 2018-03-30 12:51:13 --> Language Class Initialized
INFO - 2018-03-30 12:51:13 --> Config Class Initialized
INFO - 2018-03-30 12:51:13 --> Loader Class Initialized
INFO - 2018-03-30 18:21:13 --> Helper loaded: url_helper
INFO - 2018-03-30 18:21:13 --> Helper loaded: notification_helper
INFO - 2018-03-30 18:21:13 --> Helper loaded: settings_helper
INFO - 2018-03-30 18:21:13 --> Helper loaded: permission_helper
INFO - 2018-03-30 18:21:13 --> Helper loaded: users_helper
INFO - 2018-03-30 18:21:14 --> Database Driver Class Initialized
DEBUG - 2018-03-30 18:21:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 18:21:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 18:21:14 --> Helper loaded: form_helper
INFO - 2018-03-30 18:21:14 --> Form Validation Class Initialized
INFO - 2018-03-30 18:21:14 --> Controller Class Initialized
INFO - 2018-03-30 18:21:14 --> Model Class Initialized
INFO - 2018-03-30 18:21:14 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 18:21:14 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 18:21:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 18:21:14 --> Model Class Initialized
INFO - 2018-03-30 18:21:14 --> Model Class Initialized
INFO - 2018-03-30 18:21:14 --> Model Class Initialized
INFO - 2018-03-30 18:21:14 --> Model Class Initialized
INFO - 2018-03-30 18:21:14 --> Model Class Initialized
INFO - 2018-03-30 18:21:14 --> Model Class Initialized
INFO - 2018-03-30 18:21:14 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-30 18:21:14 --> Final output sent to browser
DEBUG - 2018-03-30 18:21:14 --> Total execution time: 2.4457
INFO - 2018-03-30 12:53:36 --> Config Class Initialized
INFO - 2018-03-30 12:53:36 --> Hooks Class Initialized
DEBUG - 2018-03-30 12:53:36 --> UTF-8 Support Enabled
INFO - 2018-03-30 12:53:36 --> Utf8 Class Initialized
INFO - 2018-03-30 12:53:36 --> URI Class Initialized
INFO - 2018-03-30 12:53:36 --> Router Class Initialized
INFO - 2018-03-30 12:53:36 --> Output Class Initialized
INFO - 2018-03-30 12:53:36 --> Security Class Initialized
DEBUG - 2018-03-30 12:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 12:53:36 --> Input Class Initialized
INFO - 2018-03-30 12:53:36 --> Language Class Initialized
INFO - 2018-03-30 12:53:36 --> Language Class Initialized
INFO - 2018-03-30 12:53:36 --> Config Class Initialized
INFO - 2018-03-30 12:53:36 --> Loader Class Initialized
INFO - 2018-03-30 18:23:36 --> Helper loaded: url_helper
INFO - 2018-03-30 18:23:36 --> Helper loaded: notification_helper
INFO - 2018-03-30 18:23:36 --> Helper loaded: settings_helper
INFO - 2018-03-30 18:23:36 --> Helper loaded: permission_helper
INFO - 2018-03-30 18:23:36 --> Helper loaded: users_helper
INFO - 2018-03-30 18:23:36 --> Database Driver Class Initialized
DEBUG - 2018-03-30 18:23:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 18:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 18:23:36 --> Helper loaded: form_helper
INFO - 2018-03-30 18:23:36 --> Form Validation Class Initialized
INFO - 2018-03-30 18:23:36 --> Controller Class Initialized
INFO - 2018-03-30 18:23:36 --> Model Class Initialized
INFO - 2018-03-30 18:23:36 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 18:23:36 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 18:23:36 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 18:23:36 --> Model Class Initialized
INFO - 2018-03-30 18:23:36 --> Model Class Initialized
INFO - 2018-03-30 18:23:36 --> Model Class Initialized
INFO - 2018-03-30 18:23:36 --> Model Class Initialized
INFO - 2018-03-30 18:23:36 --> Model Class Initialized
INFO - 2018-03-30 18:23:36 --> Model Class Initialized
INFO - 2018-03-30 18:23:36 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-30 18:23:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-30 18:23:36 --> Final output sent to browser
DEBUG - 2018-03-30 18:23:36 --> Total execution time: 0.2320
INFO - 2018-03-30 12:53:37 --> Config Class Initialized
INFO - 2018-03-30 12:53:37 --> Hooks Class Initialized
DEBUG - 2018-03-30 12:53:37 --> UTF-8 Support Enabled
INFO - 2018-03-30 12:53:37 --> Utf8 Class Initialized
INFO - 2018-03-30 12:53:37 --> URI Class Initialized
INFO - 2018-03-30 12:53:37 --> Router Class Initialized
INFO - 2018-03-30 12:53:37 --> Output Class Initialized
INFO - 2018-03-30 12:53:37 --> Security Class Initialized
DEBUG - 2018-03-30 12:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 12:53:37 --> Input Class Initialized
INFO - 2018-03-30 12:53:37 --> Language Class Initialized
INFO - 2018-03-30 12:53:37 --> Language Class Initialized
INFO - 2018-03-30 12:53:37 --> Config Class Initialized
INFO - 2018-03-30 12:53:37 --> Loader Class Initialized
INFO - 2018-03-30 18:23:37 --> Helper loaded: url_helper
INFO - 2018-03-30 18:23:37 --> Helper loaded: notification_helper
INFO - 2018-03-30 18:23:37 --> Helper loaded: settings_helper
INFO - 2018-03-30 18:23:37 --> Helper loaded: permission_helper
INFO - 2018-03-30 18:23:37 --> Helper loaded: users_helper
INFO - 2018-03-30 18:23:37 --> Database Driver Class Initialized
DEBUG - 2018-03-30 18:23:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 18:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 18:23:37 --> Helper loaded: form_helper
INFO - 2018-03-30 18:23:37 --> Form Validation Class Initialized
INFO - 2018-03-30 18:23:37 --> Controller Class Initialized
INFO - 2018-03-30 18:23:37 --> Model Class Initialized
INFO - 2018-03-30 18:23:37 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 18:23:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 18:23:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 18:23:37 --> Model Class Initialized
INFO - 2018-03-30 18:23:37 --> Model Class Initialized
INFO - 2018-03-30 18:23:37 --> Model Class Initialized
INFO - 2018-03-30 18:23:37 --> Model Class Initialized
INFO - 2018-03-30 18:23:37 --> Model Class Initialized
INFO - 2018-03-30 18:23:37 --> Model Class Initialized
INFO - 2018-03-30 18:23:37 --> Model Class Initialized
INFO - 2018-03-30 18:23:37 --> Model Class Initialized
INFO - 2018-03-30 18:23:37 --> Model Class Initialized
INFO - 2018-03-30 18:23:37 --> Model Class Initialized
INFO - 2018-03-30 18:23:37 --> Model Class Initialized
INFO - 2018-03-30 18:23:37 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-30 18:23:37 --> Model Class Initialized
INFO - 2018-03-30 18:23:37 --> Final output sent to browser
DEBUG - 2018-03-30 18:23:37 --> Total execution time: 0.1209
INFO - 2018-03-30 12:53:38 --> Config Class Initialized
INFO - 2018-03-30 12:53:38 --> Hooks Class Initialized
DEBUG - 2018-03-30 12:53:38 --> UTF-8 Support Enabled
INFO - 2018-03-30 12:53:38 --> Utf8 Class Initialized
INFO - 2018-03-30 12:53:39 --> URI Class Initialized
INFO - 2018-03-30 12:53:39 --> Router Class Initialized
INFO - 2018-03-30 12:53:39 --> Output Class Initialized
INFO - 2018-03-30 12:53:39 --> Security Class Initialized
DEBUG - 2018-03-30 12:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 12:53:39 --> Input Class Initialized
INFO - 2018-03-30 12:53:39 --> Language Class Initialized
INFO - 2018-03-30 12:53:39 --> Language Class Initialized
INFO - 2018-03-30 12:53:39 --> Config Class Initialized
INFO - 2018-03-30 12:53:39 --> Loader Class Initialized
INFO - 2018-03-30 18:23:39 --> Helper loaded: url_helper
INFO - 2018-03-30 18:23:39 --> Helper loaded: notification_helper
INFO - 2018-03-30 18:23:39 --> Helper loaded: settings_helper
INFO - 2018-03-30 18:23:39 --> Helper loaded: permission_helper
INFO - 2018-03-30 18:23:39 --> Helper loaded: users_helper
INFO - 2018-03-30 18:23:40 --> Database Driver Class Initialized
DEBUG - 2018-03-30 18:23:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 18:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 18:23:40 --> Helper loaded: form_helper
INFO - 2018-03-30 18:23:40 --> Form Validation Class Initialized
INFO - 2018-03-30 18:23:40 --> Controller Class Initialized
INFO - 2018-03-30 18:23:40 --> Model Class Initialized
INFO - 2018-03-30 18:23:40 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 18:23:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 18:23:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 18:23:40 --> Model Class Initialized
INFO - 2018-03-30 18:23:40 --> Model Class Initialized
INFO - 2018-03-30 18:23:40 --> Model Class Initialized
INFO - 2018-03-30 18:23:40 --> Model Class Initialized
INFO - 2018-03-30 18:23:40 --> Model Class Initialized
INFO - 2018-03-30 18:23:40 --> Model Class Initialized
INFO - 2018-03-30 18:23:40 --> Model Class Initialized
INFO - 2018-03-30 18:23:40 --> Model Class Initialized
INFO - 2018-03-30 18:23:40 --> Model Class Initialized
INFO - 2018-03-30 18:23:40 --> Model Class Initialized
INFO - 2018-03-30 18:23:40 --> Model Class Initialized
INFO - 2018-03-30 18:23:40 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-30 18:23:40 --> Model Class Initialized
INFO - 2018-03-30 18:23:40 --> Final output sent to browser
DEBUG - 2018-03-30 18:23:40 --> Total execution time: 1.6545
INFO - 2018-03-30 12:53:40 --> Config Class Initialized
INFO - 2018-03-30 12:53:40 --> Hooks Class Initialized
DEBUG - 2018-03-30 12:53:41 --> UTF-8 Support Enabled
INFO - 2018-03-30 12:53:41 --> Utf8 Class Initialized
INFO - 2018-03-30 12:53:41 --> URI Class Initialized
INFO - 2018-03-30 12:53:41 --> Router Class Initialized
INFO - 2018-03-30 12:53:41 --> Output Class Initialized
INFO - 2018-03-30 12:53:41 --> Security Class Initialized
DEBUG - 2018-03-30 12:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 12:53:41 --> Input Class Initialized
INFO - 2018-03-30 12:53:41 --> Language Class Initialized
INFO - 2018-03-30 12:53:41 --> Language Class Initialized
INFO - 2018-03-30 12:53:41 --> Config Class Initialized
INFO - 2018-03-30 12:53:41 --> Loader Class Initialized
INFO - 2018-03-30 18:23:41 --> Helper loaded: url_helper
INFO - 2018-03-30 18:23:41 --> Helper loaded: notification_helper
INFO - 2018-03-30 18:23:41 --> Helper loaded: settings_helper
INFO - 2018-03-30 18:23:41 --> Helper loaded: permission_helper
INFO - 2018-03-30 18:23:41 --> Helper loaded: users_helper
INFO - 2018-03-30 18:23:41 --> Database Driver Class Initialized
DEBUG - 2018-03-30 18:23:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 18:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 18:23:41 --> Helper loaded: form_helper
INFO - 2018-03-30 18:23:41 --> Form Validation Class Initialized
INFO - 2018-03-30 18:23:41 --> Controller Class Initialized
INFO - 2018-03-30 18:23:41 --> Model Class Initialized
INFO - 2018-03-30 18:23:41 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 18:23:41 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 18:23:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 18:23:41 --> Model Class Initialized
INFO - 2018-03-30 18:23:41 --> Model Class Initialized
INFO - 2018-03-30 18:23:41 --> Model Class Initialized
INFO - 2018-03-30 18:23:41 --> Model Class Initialized
INFO - 2018-03-30 18:23:41 --> Model Class Initialized
INFO - 2018-03-30 18:23:41 --> Model Class Initialized
INFO - 2018-03-30 18:23:41 --> Model Class Initialized
INFO - 2018-03-30 18:23:41 --> Model Class Initialized
INFO - 2018-03-30 18:23:41 --> Model Class Initialized
INFO - 2018-03-30 18:23:41 --> Model Class Initialized
INFO - 2018-03-30 18:23:41 --> Model Class Initialized
INFO - 2018-03-30 18:23:41 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-30 18:23:41 --> Model Class Initialized
INFO - 2018-03-30 18:23:41 --> Final output sent to browser
DEBUG - 2018-03-30 18:23:41 --> Total execution time: 0.5497
INFO - 2018-03-30 12:53:45 --> Config Class Initialized
INFO - 2018-03-30 12:53:45 --> Hooks Class Initialized
DEBUG - 2018-03-30 12:53:45 --> UTF-8 Support Enabled
INFO - 2018-03-30 12:53:45 --> Utf8 Class Initialized
INFO - 2018-03-30 12:53:45 --> URI Class Initialized
INFO - 2018-03-30 12:53:45 --> Router Class Initialized
INFO - 2018-03-30 12:53:46 --> Output Class Initialized
INFO - 2018-03-30 12:53:46 --> Security Class Initialized
DEBUG - 2018-03-30 12:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 12:53:46 --> Input Class Initialized
INFO - 2018-03-30 12:53:46 --> Language Class Initialized
INFO - 2018-03-30 12:53:47 --> Language Class Initialized
INFO - 2018-03-30 12:53:47 --> Config Class Initialized
INFO - 2018-03-30 12:53:47 --> Loader Class Initialized
INFO - 2018-03-30 18:23:47 --> Helper loaded: url_helper
INFO - 2018-03-30 18:23:47 --> Helper loaded: notification_helper
INFO - 2018-03-30 18:23:47 --> Helper loaded: settings_helper
INFO - 2018-03-30 18:23:47 --> Helper loaded: permission_helper
INFO - 2018-03-30 18:23:47 --> Helper loaded: users_helper
INFO - 2018-03-30 18:23:47 --> Database Driver Class Initialized
DEBUG - 2018-03-30 18:23:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 18:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 18:23:48 --> Helper loaded: form_helper
INFO - 2018-03-30 18:23:48 --> Form Validation Class Initialized
INFO - 2018-03-30 18:23:48 --> Controller Class Initialized
INFO - 2018-03-30 18:23:48 --> Model Class Initialized
INFO - 2018-03-30 18:23:48 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 18:23:48 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 18:23:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 18:23:48 --> Model Class Initialized
INFO - 2018-03-30 18:23:48 --> Model Class Initialized
INFO - 2018-03-30 18:23:48 --> Model Class Initialized
INFO - 2018-03-30 18:23:48 --> Model Class Initialized
INFO - 2018-03-30 18:23:48 --> Model Class Initialized
INFO - 2018-03-30 18:23:48 --> Model Class Initialized
INFO - 2018-03-30 18:23:48 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-30 18:23:48 --> Final output sent to browser
DEBUG - 2018-03-30 18:23:48 --> Total execution time: 2.9182
INFO - 2018-03-30 12:57:23 --> Config Class Initialized
INFO - 2018-03-30 12:57:23 --> Hooks Class Initialized
DEBUG - 2018-03-30 12:57:23 --> UTF-8 Support Enabled
INFO - 2018-03-30 12:57:23 --> Utf8 Class Initialized
INFO - 2018-03-30 12:57:23 --> URI Class Initialized
INFO - 2018-03-30 12:57:23 --> Router Class Initialized
INFO - 2018-03-30 12:57:23 --> Output Class Initialized
INFO - 2018-03-30 12:57:23 --> Security Class Initialized
DEBUG - 2018-03-30 12:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 12:57:23 --> Input Class Initialized
INFO - 2018-03-30 12:57:23 --> Language Class Initialized
INFO - 2018-03-30 12:57:24 --> Language Class Initialized
INFO - 2018-03-30 12:57:24 --> Config Class Initialized
INFO - 2018-03-30 12:57:24 --> Loader Class Initialized
INFO - 2018-03-30 18:27:24 --> Helper loaded: url_helper
INFO - 2018-03-30 18:27:24 --> Helper loaded: notification_helper
INFO - 2018-03-30 18:27:24 --> Helper loaded: settings_helper
INFO - 2018-03-30 18:27:24 --> Helper loaded: permission_helper
INFO - 2018-03-30 18:27:24 --> Helper loaded: users_helper
INFO - 2018-03-30 18:27:25 --> Database Driver Class Initialized
DEBUG - 2018-03-30 18:27:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 18:27:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 18:27:26 --> Helper loaded: form_helper
INFO - 2018-03-30 18:27:26 --> Form Validation Class Initialized
INFO - 2018-03-30 18:27:26 --> Controller Class Initialized
INFO - 2018-03-30 18:27:27 --> Model Class Initialized
INFO - 2018-03-30 18:27:27 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 18:27:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 18:27:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 18:27:27 --> Model Class Initialized
INFO - 2018-03-30 18:27:27 --> Model Class Initialized
INFO - 2018-03-30 18:27:27 --> Model Class Initialized
INFO - 2018-03-30 18:27:27 --> Model Class Initialized
INFO - 2018-03-30 18:27:27 --> Model Class Initialized
INFO - 2018-03-30 18:27:27 --> Model Class Initialized
INFO - 2018-03-30 18:27:27 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-30 18:27:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-30 18:27:27 --> Final output sent to browser
DEBUG - 2018-03-30 18:27:27 --> Total execution time: 4.4114
INFO - 2018-03-30 12:57:29 --> Config Class Initialized
INFO - 2018-03-30 12:57:29 --> Hooks Class Initialized
DEBUG - 2018-03-30 12:57:29 --> UTF-8 Support Enabled
INFO - 2018-03-30 12:57:29 --> Utf8 Class Initialized
INFO - 2018-03-30 12:57:29 --> URI Class Initialized
INFO - 2018-03-30 12:57:29 --> Router Class Initialized
INFO - 2018-03-30 12:57:29 --> Output Class Initialized
INFO - 2018-03-30 12:57:29 --> Security Class Initialized
DEBUG - 2018-03-30 12:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 12:57:29 --> Input Class Initialized
INFO - 2018-03-30 12:57:30 --> Language Class Initialized
INFO - 2018-03-30 12:57:30 --> Language Class Initialized
INFO - 2018-03-30 12:57:30 --> Config Class Initialized
INFO - 2018-03-30 12:57:30 --> Loader Class Initialized
INFO - 2018-03-30 18:27:30 --> Helper loaded: url_helper
INFO - 2018-03-30 18:27:30 --> Helper loaded: notification_helper
INFO - 2018-03-30 18:27:30 --> Helper loaded: settings_helper
INFO - 2018-03-30 18:27:30 --> Helper loaded: permission_helper
INFO - 2018-03-30 18:27:30 --> Helper loaded: users_helper
INFO - 2018-03-30 18:27:31 --> Database Driver Class Initialized
DEBUG - 2018-03-30 18:27:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 18:27:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 18:27:31 --> Helper loaded: form_helper
INFO - 2018-03-30 18:27:31 --> Form Validation Class Initialized
INFO - 2018-03-30 18:27:31 --> Controller Class Initialized
INFO - 2018-03-30 18:27:31 --> Model Class Initialized
INFO - 2018-03-30 18:27:31 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 18:27:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 18:27:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 18:27:31 --> Model Class Initialized
INFO - 2018-03-30 18:27:31 --> Model Class Initialized
INFO - 2018-03-30 18:27:31 --> Model Class Initialized
INFO - 2018-03-30 18:27:31 --> Model Class Initialized
INFO - 2018-03-30 18:27:31 --> Model Class Initialized
INFO - 2018-03-30 18:27:31 --> Model Class Initialized
INFO - 2018-03-30 18:27:31 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-30 18:27:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-30 18:27:31 --> Final output sent to browser
DEBUG - 2018-03-30 18:27:31 --> Total execution time: 2.4608
INFO - 2018-03-30 12:57:33 --> Config Class Initialized
INFO - 2018-03-30 12:57:33 --> Hooks Class Initialized
DEBUG - 2018-03-30 12:57:33 --> UTF-8 Support Enabled
INFO - 2018-03-30 12:57:33 --> Utf8 Class Initialized
INFO - 2018-03-30 12:57:33 --> URI Class Initialized
INFO - 2018-03-30 12:57:33 --> Router Class Initialized
INFO - 2018-03-30 12:57:33 --> Output Class Initialized
INFO - 2018-03-30 12:57:33 --> Security Class Initialized
DEBUG - 2018-03-30 12:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 12:57:33 --> Input Class Initialized
INFO - 2018-03-30 12:57:33 --> Language Class Initialized
INFO - 2018-03-30 12:57:33 --> Language Class Initialized
INFO - 2018-03-30 12:57:33 --> Config Class Initialized
INFO - 2018-03-30 12:57:33 --> Loader Class Initialized
INFO - 2018-03-30 18:27:33 --> Helper loaded: url_helper
INFO - 2018-03-30 18:27:33 --> Helper loaded: notification_helper
INFO - 2018-03-30 18:27:33 --> Helper loaded: settings_helper
INFO - 2018-03-30 18:27:33 --> Helper loaded: permission_helper
INFO - 2018-03-30 18:27:33 --> Helper loaded: users_helper
INFO - 2018-03-30 12:57:33 --> Config Class Initialized
INFO - 2018-03-30 12:57:33 --> Hooks Class Initialized
DEBUG - 2018-03-30 12:57:33 --> UTF-8 Support Enabled
INFO - 2018-03-30 12:57:33 --> Utf8 Class Initialized
INFO - 2018-03-30 12:57:33 --> URI Class Initialized
INFO - 2018-03-30 18:27:33 --> Database Driver Class Initialized
INFO - 2018-03-30 12:57:33 --> Router Class Initialized
INFO - 2018-03-30 12:57:33 --> Output Class Initialized
INFO - 2018-03-30 12:57:33 --> Security Class Initialized
DEBUG - 2018-03-30 18:27:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-30 12:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 12:57:33 --> Input Class Initialized
INFO - 2018-03-30 18:27:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 12:57:33 --> Language Class Initialized
INFO - 2018-03-30 12:57:33 --> Language Class Initialized
INFO - 2018-03-30 12:57:33 --> Config Class Initialized
INFO - 2018-03-30 12:57:33 --> Loader Class Initialized
INFO - 2018-03-30 18:27:33 --> Helper loaded: url_helper
INFO - 2018-03-30 18:27:33 --> Helper loaded: notification_helper
INFO - 2018-03-30 18:27:33 --> Helper loaded: settings_helper
INFO - 2018-03-30 18:27:33 --> Helper loaded: permission_helper
INFO - 2018-03-30 18:27:33 --> Helper loaded: users_helper
INFO - 2018-03-30 18:27:33 --> Helper loaded: form_helper
INFO - 2018-03-30 18:27:33 --> Form Validation Class Initialized
INFO - 2018-03-30 18:27:33 --> Controller Class Initialized
INFO - 2018-03-30 18:27:33 --> Database Driver Class Initialized
DEBUG - 2018-03-30 18:27:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 18:27:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 18:27:33 --> Helper loaded: form_helper
INFO - 2018-03-30 18:27:33 --> Form Validation Class Initialized
INFO - 2018-03-30 18:27:33 --> Controller Class Initialized
INFO - 2018-03-30 18:27:33 --> Model Class Initialized
INFO - 2018-03-30 18:27:33 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 18:27:33 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 18:27:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 18:27:33 --> Model Class Initialized
INFO - 2018-03-30 18:27:33 --> Model Class Initialized
INFO - 2018-03-30 18:27:33 --> Model Class Initialized
INFO - 2018-03-30 18:27:33 --> Model Class Initialized
INFO - 2018-03-30 18:27:33 --> Model Class Initialized
INFO - 2018-03-30 18:27:33 --> Model Class Initialized
INFO - 2018-03-30 18:27:33 --> Model Class Initialized
INFO - 2018-03-30 18:27:33 --> Model Class Initialized
INFO - 2018-03-30 18:27:33 --> Model Class Initialized
INFO - 2018-03-30 18:27:33 --> Model Class Initialized
INFO - 2018-03-30 18:27:33 --> Model Class Initialized
INFO - 2018-03-30 18:27:33 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-30 18:27:33 --> Model Class Initialized
INFO - 2018-03-30 18:27:33 --> Final output sent to browser
DEBUG - 2018-03-30 18:27:33 --> Total execution time: 0.1929
INFO - 2018-03-30 18:27:33 --> Model Class Initialized
INFO - 2018-03-30 18:27:33 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 18:27:33 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 18:27:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 18:27:33 --> Model Class Initialized
INFO - 2018-03-30 18:27:33 --> Model Class Initialized
INFO - 2018-03-30 18:27:33 --> Model Class Initialized
INFO - 2018-03-30 18:27:33 --> Model Class Initialized
INFO - 2018-03-30 18:27:33 --> Model Class Initialized
INFO - 2018-03-30 18:27:33 --> Model Class Initialized
INFO - 2018-03-30 18:27:33 --> Model Class Initialized
INFO - 2018-03-30 18:27:33 --> Model Class Initialized
INFO - 2018-03-30 18:27:33 --> Model Class Initialized
INFO - 2018-03-30 18:27:33 --> Model Class Initialized
INFO - 2018-03-30 18:27:33 --> Model Class Initialized
INFO - 2018-03-30 18:27:33 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-30 18:27:33 --> Model Class Initialized
INFO - 2018-03-30 18:27:34 --> Final output sent to browser
DEBUG - 2018-03-30 18:27:34 --> Total execution time: 0.8678
INFO - 2018-03-30 12:58:35 --> Config Class Initialized
INFO - 2018-03-30 12:58:35 --> Hooks Class Initialized
DEBUG - 2018-03-30 12:58:36 --> UTF-8 Support Enabled
INFO - 2018-03-30 12:58:36 --> Utf8 Class Initialized
INFO - 2018-03-30 12:58:36 --> URI Class Initialized
INFO - 2018-03-30 12:58:36 --> Router Class Initialized
INFO - 2018-03-30 12:58:36 --> Output Class Initialized
INFO - 2018-03-30 12:58:36 --> Security Class Initialized
DEBUG - 2018-03-30 12:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 12:58:36 --> Input Class Initialized
INFO - 2018-03-30 12:58:36 --> Language Class Initialized
INFO - 2018-03-30 12:58:36 --> Language Class Initialized
INFO - 2018-03-30 12:58:36 --> Config Class Initialized
INFO - 2018-03-30 12:58:36 --> Loader Class Initialized
INFO - 2018-03-30 18:28:36 --> Helper loaded: url_helper
INFO - 2018-03-30 18:28:36 --> Helper loaded: notification_helper
INFO - 2018-03-30 18:28:36 --> Helper loaded: settings_helper
INFO - 2018-03-30 18:28:36 --> Helper loaded: permission_helper
INFO - 2018-03-30 18:28:36 --> Helper loaded: users_helper
INFO - 2018-03-30 12:58:36 --> Config Class Initialized
INFO - 2018-03-30 12:58:36 --> Hooks Class Initialized
INFO - 2018-03-30 12:58:36 --> Config Class Initialized
INFO - 2018-03-30 12:58:36 --> Hooks Class Initialized
INFO - 2018-03-30 18:28:36 --> Database Driver Class Initialized
DEBUG - 2018-03-30 18:28:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 18:28:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-03-30 12:58:36 --> UTF-8 Support Enabled
INFO - 2018-03-30 12:58:36 --> Utf8 Class Initialized
INFO - 2018-03-30 18:28:36 --> Helper loaded: form_helper
INFO - 2018-03-30 18:28:36 --> Form Validation Class Initialized
INFO - 2018-03-30 18:28:36 --> Controller Class Initialized
INFO - 2018-03-30 18:28:36 --> Model Class Initialized
INFO - 2018-03-30 18:28:36 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 18:28:36 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 18:28:36 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 18:28:36 --> Model Class Initialized
INFO - 2018-03-30 18:28:36 --> Model Class Initialized
INFO - 2018-03-30 18:28:36 --> Model Class Initialized
INFO - 2018-03-30 18:28:36 --> Model Class Initialized
INFO - 2018-03-30 18:28:36 --> Model Class Initialized
INFO - 2018-03-30 18:28:36 --> Model Class Initialized
INFO - 2018-03-30 18:28:36 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-30 18:28:36 --> Final output sent to browser
DEBUG - 2018-03-30 18:28:36 --> Total execution time: 1.1140
INFO - 2018-03-30 12:58:36 --> URI Class Initialized
DEBUG - 2018-03-30 12:58:37 --> UTF-8 Support Enabled
INFO - 2018-03-30 12:58:37 --> Utf8 Class Initialized
INFO - 2018-03-30 12:58:37 --> Router Class Initialized
INFO - 2018-03-30 12:58:37 --> URI Class Initialized
INFO - 2018-03-30 12:58:37 --> Output Class Initialized
INFO - 2018-03-30 12:58:37 --> Router Class Initialized
INFO - 2018-03-30 12:58:37 --> Security Class Initialized
INFO - 2018-03-30 12:58:37 --> Output Class Initialized
INFO - 2018-03-30 12:58:37 --> Security Class Initialized
DEBUG - 2018-03-30 12:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 12:58:37 --> Input Class Initialized
INFO - 2018-03-30 12:58:37 --> Language Class Initialized
DEBUG - 2018-03-30 12:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 12:58:37 --> Input Class Initialized
INFO - 2018-03-30 12:58:37 --> Language Class Initialized
INFO - 2018-03-30 12:58:38 --> Config Class Initialized
INFO - 2018-03-30 12:58:38 --> Hooks Class Initialized
DEBUG - 2018-03-30 12:58:38 --> UTF-8 Support Enabled
INFO - 2018-03-30 12:58:38 --> Utf8 Class Initialized
INFO - 2018-03-30 12:58:38 --> URI Class Initialized
INFO - 2018-03-30 12:58:38 --> Language Class Initialized
INFO - 2018-03-30 12:58:38 --> Config Class Initialized
INFO - 2018-03-30 12:58:38 --> Loader Class Initialized
INFO - 2018-03-30 12:58:38 --> Router Class Initialized
INFO - 2018-03-30 18:28:38 --> Helper loaded: url_helper
INFO - 2018-03-30 18:28:38 --> Helper loaded: notification_helper
INFO - 2018-03-30 18:28:38 --> Helper loaded: settings_helper
INFO - 2018-03-30 18:28:38 --> Helper loaded: permission_helper
INFO - 2018-03-30 18:28:38 --> Helper loaded: users_helper
INFO - 2018-03-30 12:58:38 --> Output Class Initialized
INFO - 2018-03-30 12:58:38 --> Security Class Initialized
DEBUG - 2018-03-30 12:58:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 12:58:38 --> Input Class Initialized
INFO - 2018-03-30 12:58:38 --> Language Class Initialized
INFO - 2018-03-30 12:58:38 --> Language Class Initialized
INFO - 2018-03-30 12:58:38 --> Config Class Initialized
INFO - 2018-03-30 12:58:38 --> Loader Class Initialized
INFO - 2018-03-30 18:28:38 --> Database Driver Class Initialized
DEBUG - 2018-03-30 18:28:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 18:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 18:28:38 --> Helper loaded: form_helper
INFO - 2018-03-30 18:28:38 --> Form Validation Class Initialized
INFO - 2018-03-30 18:28:38 --> Controller Class Initialized
INFO - 2018-03-30 18:28:38 --> Helper loaded: url_helper
INFO - 2018-03-30 18:28:38 --> Model Class Initialized
INFO - 2018-03-30 18:28:38 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 18:28:38 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 18:28:38 --> Helper loaded: notification_helper
INFO - 2018-03-30 18:28:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 18:28:38 --> Model Class Initialized
INFO - 2018-03-30 18:28:38 --> Model Class Initialized
INFO - 2018-03-30 18:28:38 --> Model Class Initialized
INFO - 2018-03-30 18:28:38 --> Model Class Initialized
INFO - 2018-03-30 18:28:38 --> Model Class Initialized
INFO - 2018-03-30 18:28:38 --> Model Class Initialized
INFO - 2018-03-30 18:28:38 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-30 18:28:38 --> Helper loaded: settings_helper
INFO - 2018-03-30 18:28:38 --> Final output sent to browser
DEBUG - 2018-03-30 18:28:38 --> Total execution time: 1.8967
INFO - 2018-03-30 18:28:38 --> Helper loaded: permission_helper
INFO - 2018-03-30 18:28:38 --> Helper loaded: users_helper
INFO - 2018-03-30 12:58:38 --> Language Class Initialized
INFO - 2018-03-30 12:58:38 --> Config Class Initialized
INFO - 2018-03-30 12:58:38 --> Loader Class Initialized
INFO - 2018-03-30 18:28:38 --> Helper loaded: url_helper
INFO - 2018-03-30 18:28:38 --> Helper loaded: notification_helper
INFO - 2018-03-30 18:28:38 --> Helper loaded: settings_helper
INFO - 2018-03-30 18:28:38 --> Helper loaded: permission_helper
INFO - 2018-03-30 18:28:38 --> Helper loaded: users_helper
INFO - 2018-03-30 18:28:38 --> Database Driver Class Initialized
DEBUG - 2018-03-30 18:28:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 18:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 18:28:38 --> Helper loaded: form_helper
INFO - 2018-03-30 18:28:38 --> Form Validation Class Initialized
INFO - 2018-03-30 18:28:38 --> Controller Class Initialized
INFO - 2018-03-30 18:28:38 --> Model Class Initialized
INFO - 2018-03-30 18:28:38 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 18:28:38 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 18:28:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 18:28:38 --> Model Class Initialized
INFO - 2018-03-30 18:28:38 --> Model Class Initialized
INFO - 2018-03-30 18:28:38 --> Model Class Initialized
INFO - 2018-03-30 18:28:38 --> Model Class Initialized
INFO - 2018-03-30 18:28:38 --> Model Class Initialized
INFO - 2018-03-30 18:28:38 --> Model Class Initialized
INFO - 2018-03-30 18:28:38 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-30 18:28:38 --> Final output sent to browser
DEBUG - 2018-03-30 18:28:38 --> Total execution time: 0.7509
INFO - 2018-03-30 12:58:39 --> Config Class Initialized
INFO - 2018-03-30 12:58:39 --> Hooks Class Initialized
DEBUG - 2018-03-30 12:58:39 --> UTF-8 Support Enabled
INFO - 2018-03-30 12:58:39 --> Utf8 Class Initialized
INFO - 2018-03-30 12:58:39 --> URI Class Initialized
INFO - 2018-03-30 12:58:39 --> Router Class Initialized
INFO - 2018-03-30 12:58:39 --> Output Class Initialized
INFO - 2018-03-30 12:58:39 --> Security Class Initialized
DEBUG - 2018-03-30 12:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 12:58:39 --> Input Class Initialized
INFO - 2018-03-30 12:58:39 --> Language Class Initialized
INFO - 2018-03-30 18:28:39 --> Database Driver Class Initialized
DEBUG - 2018-03-30 18:28:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 18:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 12:58:39 --> Language Class Initialized
INFO - 2018-03-30 12:58:39 --> Config Class Initialized
INFO - 2018-03-30 12:58:39 --> Loader Class Initialized
INFO - 2018-03-30 18:28:39 --> Helper loaded: url_helper
INFO - 2018-03-30 18:28:39 --> Helper loaded: notification_helper
INFO - 2018-03-30 18:28:39 --> Helper loaded: settings_helper
INFO - 2018-03-30 18:28:39 --> Helper loaded: permission_helper
INFO - 2018-03-30 18:28:39 --> Helper loaded: users_helper
INFO - 2018-03-30 18:28:39 --> Helper loaded: form_helper
INFO - 2018-03-30 18:28:39 --> Form Validation Class Initialized
INFO - 2018-03-30 18:28:39 --> Controller Class Initialized
INFO - 2018-03-30 18:28:39 --> Database Driver Class Initialized
DEBUG - 2018-03-30 18:28:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 18:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 18:28:39 --> Helper loaded: form_helper
INFO - 2018-03-30 18:28:39 --> Form Validation Class Initialized
INFO - 2018-03-30 18:28:39 --> Controller Class Initialized
INFO - 2018-03-30 18:28:39 --> Model Class Initialized
INFO - 2018-03-30 18:28:39 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 18:28:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 18:28:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 18:28:39 --> Model Class Initialized
INFO - 2018-03-30 18:28:39 --> Model Class Initialized
INFO - 2018-03-30 18:28:39 --> Model Class Initialized
INFO - 2018-03-30 18:28:39 --> Model Class Initialized
INFO - 2018-03-30 18:28:39 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-30 18:28:39 --> Final output sent to browser
DEBUG - 2018-03-30 18:28:39 --> Total execution time: 0.8401
INFO - 2018-03-30 18:28:39 --> Model Class Initialized
INFO - 2018-03-30 18:28:39 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 18:28:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 18:28:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 18:28:40 --> Model Class Initialized
INFO - 2018-03-30 18:28:40 --> Model Class Initialized
INFO - 2018-03-30 18:28:40 --> Model Class Initialized
INFO - 2018-03-30 18:28:40 --> Model Class Initialized
INFO - 2018-03-30 18:28:40 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-30 18:28:40 --> Final output sent to browser
DEBUG - 2018-03-30 18:28:40 --> Total execution time: 4.0100
INFO - 2018-03-30 12:58:48 --> Config Class Initialized
INFO - 2018-03-30 12:58:48 --> Hooks Class Initialized
DEBUG - 2018-03-30 12:58:48 --> UTF-8 Support Enabled
INFO - 2018-03-30 12:58:48 --> Utf8 Class Initialized
INFO - 2018-03-30 12:58:48 --> URI Class Initialized
INFO - 2018-03-30 12:58:48 --> Router Class Initialized
INFO - 2018-03-30 12:58:48 --> Output Class Initialized
INFO - 2018-03-30 12:58:48 --> Security Class Initialized
DEBUG - 2018-03-30 12:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 12:58:48 --> Input Class Initialized
INFO - 2018-03-30 12:58:48 --> Language Class Initialized
INFO - 2018-03-30 12:58:48 --> Language Class Initialized
INFO - 2018-03-30 12:58:48 --> Config Class Initialized
INFO - 2018-03-30 12:58:48 --> Loader Class Initialized
INFO - 2018-03-30 18:28:48 --> Helper loaded: url_helper
INFO - 2018-03-30 18:28:48 --> Helper loaded: notification_helper
INFO - 2018-03-30 18:28:48 --> Helper loaded: settings_helper
INFO - 2018-03-30 18:28:48 --> Helper loaded: permission_helper
INFO - 2018-03-30 18:28:48 --> Helper loaded: users_helper
INFO - 2018-03-30 18:28:48 --> Database Driver Class Initialized
DEBUG - 2018-03-30 18:28:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 18:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 18:28:48 --> Helper loaded: form_helper
INFO - 2018-03-30 18:28:48 --> Form Validation Class Initialized
INFO - 2018-03-30 18:28:48 --> Controller Class Initialized
INFO - 2018-03-30 18:28:48 --> Model Class Initialized
INFO - 2018-03-30 18:28:48 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 18:28:48 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 18:28:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 18:28:48 --> Model Class Initialized
INFO - 2018-03-30 18:28:48 --> Model Class Initialized
INFO - 2018-03-30 18:28:48 --> Model Class Initialized
INFO - 2018-03-30 18:28:48 --> Model Class Initialized
INFO - 2018-03-30 18:28:48 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-30 18:28:48 --> Model Class Initialized
INFO - 2018-03-30 18:28:48 --> Final output sent to browser
DEBUG - 2018-03-30 18:28:48 --> Total execution time: 0.2593
INFO - 2018-03-30 12:58:49 --> Config Class Initialized
INFO - 2018-03-30 12:58:49 --> Hooks Class Initialized
DEBUG - 2018-03-30 12:58:49 --> UTF-8 Support Enabled
INFO - 2018-03-30 12:58:49 --> Utf8 Class Initialized
INFO - 2018-03-30 12:58:49 --> URI Class Initialized
INFO - 2018-03-30 12:58:49 --> Router Class Initialized
INFO - 2018-03-30 12:58:49 --> Output Class Initialized
INFO - 2018-03-30 12:58:49 --> Security Class Initialized
DEBUG - 2018-03-30 12:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 12:58:49 --> Input Class Initialized
INFO - 2018-03-30 12:58:49 --> Language Class Initialized
INFO - 2018-03-30 12:58:49 --> Language Class Initialized
INFO - 2018-03-30 12:58:49 --> Config Class Initialized
INFO - 2018-03-30 12:58:49 --> Loader Class Initialized
INFO - 2018-03-30 18:28:49 --> Helper loaded: url_helper
INFO - 2018-03-30 18:28:49 --> Helper loaded: notification_helper
INFO - 2018-03-30 18:28:49 --> Helper loaded: settings_helper
INFO - 2018-03-30 18:28:49 --> Helper loaded: permission_helper
INFO - 2018-03-30 18:28:49 --> Helper loaded: users_helper
INFO - 2018-03-30 18:28:50 --> Database Driver Class Initialized
DEBUG - 2018-03-30 18:28:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 18:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 18:28:50 --> Helper loaded: form_helper
INFO - 2018-03-30 18:28:50 --> Form Validation Class Initialized
INFO - 2018-03-30 18:28:50 --> Controller Class Initialized
INFO - 2018-03-30 18:28:50 --> Model Class Initialized
INFO - 2018-03-30 18:28:50 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 18:28:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 18:28:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 18:28:50 --> Model Class Initialized
INFO - 2018-03-30 18:28:50 --> Model Class Initialized
INFO - 2018-03-30 18:28:50 --> Model Class Initialized
INFO - 2018-03-30 18:28:50 --> Model Class Initialized
INFO - 2018-03-30 18:28:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-30 18:28:50 --> Final output sent to browser
DEBUG - 2018-03-30 18:28:50 --> Total execution time: 0.2128
INFO - 2018-03-30 12:58:53 --> Config Class Initialized
INFO - 2018-03-30 12:58:53 --> Hooks Class Initialized
DEBUG - 2018-03-30 12:58:53 --> UTF-8 Support Enabled
INFO - 2018-03-30 12:58:53 --> Utf8 Class Initialized
INFO - 2018-03-30 12:58:53 --> URI Class Initialized
INFO - 2018-03-30 12:58:53 --> Router Class Initialized
INFO - 2018-03-30 12:58:53 --> Output Class Initialized
INFO - 2018-03-30 12:58:53 --> Security Class Initialized
DEBUG - 2018-03-30 12:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 12:58:53 --> Input Class Initialized
INFO - 2018-03-30 12:58:53 --> Language Class Initialized
INFO - 2018-03-30 12:58:53 --> Language Class Initialized
INFO - 2018-03-30 12:58:53 --> Config Class Initialized
INFO - 2018-03-30 12:58:53 --> Loader Class Initialized
INFO - 2018-03-30 18:28:53 --> Helper loaded: url_helper
INFO - 2018-03-30 18:28:53 --> Helper loaded: notification_helper
INFO - 2018-03-30 18:28:53 --> Helper loaded: settings_helper
INFO - 2018-03-30 18:28:53 --> Helper loaded: permission_helper
INFO - 2018-03-30 18:28:53 --> Helper loaded: users_helper
INFO - 2018-03-30 18:28:53 --> Database Driver Class Initialized
DEBUG - 2018-03-30 18:28:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 18:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 18:28:53 --> Helper loaded: form_helper
INFO - 2018-03-30 18:28:53 --> Form Validation Class Initialized
INFO - 2018-03-30 18:28:53 --> Controller Class Initialized
INFO - 2018-03-30 18:28:53 --> Model Class Initialized
INFO - 2018-03-30 18:28:53 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 18:28:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 18:28:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 18:28:53 --> Model Class Initialized
INFO - 2018-03-30 18:28:53 --> Model Class Initialized
INFO - 2018-03-30 18:28:53 --> Model Class Initialized
INFO - 2018-03-30 18:28:53 --> Model Class Initialized
INFO - 2018-03-30 18:28:53 --> Final output sent to browser
DEBUG - 2018-03-30 18:28:53 --> Total execution time: 0.2108
INFO - 2018-03-30 12:58:54 --> Config Class Initialized
INFO - 2018-03-30 12:58:54 --> Hooks Class Initialized
INFO - 2018-03-30 12:58:54 --> Config Class Initialized
INFO - 2018-03-30 12:58:54 --> Hooks Class Initialized
DEBUG - 2018-03-30 12:58:54 --> UTF-8 Support Enabled
INFO - 2018-03-30 12:58:54 --> Utf8 Class Initialized
INFO - 2018-03-30 12:58:54 --> URI Class Initialized
DEBUG - 2018-03-30 12:58:54 --> UTF-8 Support Enabled
INFO - 2018-03-30 12:58:54 --> Utf8 Class Initialized
INFO - 2018-03-30 12:58:54 --> Router Class Initialized
INFO - 2018-03-30 12:58:54 --> Output Class Initialized
INFO - 2018-03-30 12:58:54 --> Security Class Initialized
DEBUG - 2018-03-30 12:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 12:58:54 --> Input Class Initialized
INFO - 2018-03-30 12:58:54 --> Language Class Initialized
INFO - 2018-03-30 12:58:54 --> URI Class Initialized
INFO - 2018-03-30 12:58:54 --> Language Class Initialized
INFO - 2018-03-30 12:58:54 --> Config Class Initialized
INFO - 2018-03-30 12:58:54 --> Loader Class Initialized
INFO - 2018-03-30 18:28:54 --> Helper loaded: url_helper
INFO - 2018-03-30 18:28:54 --> Helper loaded: notification_helper
INFO - 2018-03-30 18:28:54 --> Helper loaded: settings_helper
INFO - 2018-03-30 18:28:54 --> Helper loaded: permission_helper
INFO - 2018-03-30 18:28:54 --> Helper loaded: users_helper
INFO - 2018-03-30 18:28:54 --> Database Driver Class Initialized
DEBUG - 2018-03-30 18:28:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 18:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 12:58:54 --> Router Class Initialized
INFO - 2018-03-30 18:28:54 --> Helper loaded: form_helper
INFO - 2018-03-30 18:28:54 --> Form Validation Class Initialized
INFO - 2018-03-30 18:28:54 --> Controller Class Initialized
INFO - 2018-03-30 18:28:54 --> Model Class Initialized
INFO - 2018-03-30 18:28:54 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 18:28:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 18:28:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 18:28:54 --> Model Class Initialized
INFO - 2018-03-30 18:28:54 --> Model Class Initialized
INFO - 2018-03-30 18:28:54 --> Model Class Initialized
INFO - 2018-03-30 18:28:54 --> Model Class Initialized
INFO - 2018-03-30 18:28:54 --> Final output sent to browser
DEBUG - 2018-03-30 18:28:54 --> Total execution time: 0.1850
INFO - 2018-03-30 12:58:54 --> Output Class Initialized
INFO - 2018-03-30 12:58:54 --> Security Class Initialized
DEBUG - 2018-03-30 12:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 12:58:54 --> Input Class Initialized
INFO - 2018-03-30 12:58:54 --> Language Class Initialized
INFO - 2018-03-30 12:58:55 --> Language Class Initialized
INFO - 2018-03-30 12:58:55 --> Config Class Initialized
INFO - 2018-03-30 12:58:55 --> Loader Class Initialized
INFO - 2018-03-30 18:28:55 --> Helper loaded: url_helper
INFO - 2018-03-30 18:28:55 --> Helper loaded: notification_helper
INFO - 2018-03-30 18:28:55 --> Helper loaded: settings_helper
INFO - 2018-03-30 18:28:55 --> Helper loaded: permission_helper
INFO - 2018-03-30 18:28:55 --> Helper loaded: users_helper
INFO - 2018-03-30 18:28:55 --> Database Driver Class Initialized
DEBUG - 2018-03-30 18:28:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 18:28:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 18:28:55 --> Helper loaded: form_helper
INFO - 2018-03-30 18:28:55 --> Form Validation Class Initialized
INFO - 2018-03-30 18:28:55 --> Controller Class Initialized
INFO - 2018-03-30 18:28:55 --> Model Class Initialized
INFO - 2018-03-30 18:28:55 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 18:28:55 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 18:28:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 18:28:55 --> Model Class Initialized
INFO - 2018-03-30 18:28:55 --> Model Class Initialized
INFO - 2018-03-30 18:28:55 --> Model Class Initialized
INFO - 2018-03-30 18:28:55 --> Model Class Initialized
INFO - 2018-03-30 18:28:55 --> Final output sent to browser
DEBUG - 2018-03-30 18:28:55 --> Total execution time: 1.2771
INFO - 2018-03-30 12:58:58 --> Config Class Initialized
INFO - 2018-03-30 12:58:58 --> Hooks Class Initialized
DEBUG - 2018-03-30 12:58:58 --> UTF-8 Support Enabled
INFO - 2018-03-30 12:58:58 --> Utf8 Class Initialized
INFO - 2018-03-30 12:58:58 --> URI Class Initialized
INFO - 2018-03-30 12:58:58 --> Router Class Initialized
INFO - 2018-03-30 12:58:58 --> Output Class Initialized
INFO - 2018-03-30 12:58:58 --> Security Class Initialized
DEBUG - 2018-03-30 12:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 12:58:58 --> Input Class Initialized
INFO - 2018-03-30 12:58:58 --> Language Class Initialized
INFO - 2018-03-30 12:58:59 --> Language Class Initialized
INFO - 2018-03-30 12:58:59 --> Config Class Initialized
INFO - 2018-03-30 12:58:59 --> Loader Class Initialized
INFO - 2018-03-30 18:28:59 --> Helper loaded: url_helper
INFO - 2018-03-30 18:28:59 --> Helper loaded: notification_helper
INFO - 2018-03-30 18:28:59 --> Helper loaded: settings_helper
INFO - 2018-03-30 18:28:59 --> Helper loaded: permission_helper
INFO - 2018-03-30 18:28:59 --> Helper loaded: users_helper
INFO - 2018-03-30 18:29:00 --> Database Driver Class Initialized
DEBUG - 2018-03-30 18:29:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 18:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 18:29:00 --> Helper loaded: form_helper
INFO - 2018-03-30 18:29:00 --> Form Validation Class Initialized
INFO - 2018-03-30 18:29:00 --> Controller Class Initialized
INFO - 2018-03-30 18:29:00 --> Model Class Initialized
INFO - 2018-03-30 18:29:00 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 18:29:00 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 18:29:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 18:29:00 --> Model Class Initialized
INFO - 2018-03-30 18:29:00 --> Model Class Initialized
INFO - 2018-03-30 18:29:00 --> Model Class Initialized
INFO - 2018-03-30 18:29:00 --> Model Class Initialized
INFO - 2018-03-30 18:29:00 --> Final output sent to browser
DEBUG - 2018-03-30 18:29:00 --> Total execution time: 2.1793
INFO - 2018-03-30 12:59:00 --> Config Class Initialized
INFO - 2018-03-30 12:59:00 --> Hooks Class Initialized
DEBUG - 2018-03-30 12:59:00 --> UTF-8 Support Enabled
INFO - 2018-03-30 12:59:00 --> Utf8 Class Initialized
INFO - 2018-03-30 12:59:00 --> URI Class Initialized
INFO - 2018-03-30 12:59:00 --> Router Class Initialized
INFO - 2018-03-30 12:59:00 --> Output Class Initialized
INFO - 2018-03-30 12:59:00 --> Security Class Initialized
DEBUG - 2018-03-30 12:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 12:59:01 --> Input Class Initialized
INFO - 2018-03-30 12:59:01 --> Language Class Initialized
INFO - 2018-03-30 12:59:01 --> Language Class Initialized
INFO - 2018-03-30 12:59:01 --> Config Class Initialized
INFO - 2018-03-30 12:59:01 --> Loader Class Initialized
INFO - 2018-03-30 18:29:01 --> Helper loaded: url_helper
INFO - 2018-03-30 18:29:01 --> Helper loaded: notification_helper
INFO - 2018-03-30 18:29:01 --> Helper loaded: settings_helper
INFO - 2018-03-30 18:29:01 --> Helper loaded: permission_helper
INFO - 2018-03-30 18:29:01 --> Helper loaded: users_helper
INFO - 2018-03-30 18:29:01 --> Database Driver Class Initialized
DEBUG - 2018-03-30 18:29:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 18:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 18:29:01 --> Helper loaded: form_helper
INFO - 2018-03-30 18:29:01 --> Form Validation Class Initialized
INFO - 2018-03-30 18:29:01 --> Controller Class Initialized
INFO - 2018-03-30 18:29:01 --> Model Class Initialized
INFO - 2018-03-30 18:29:01 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 18:29:01 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 18:29:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 18:29:01 --> Model Class Initialized
INFO - 2018-03-30 18:29:01 --> Model Class Initialized
INFO - 2018-03-30 18:29:01 --> Model Class Initialized
INFO - 2018-03-30 18:29:01 --> Model Class Initialized
INFO - 2018-03-30 18:29:01 --> Final output sent to browser
DEBUG - 2018-03-30 18:29:01 --> Total execution time: 0.0957
INFO - 2018-03-30 12:59:03 --> Config Class Initialized
INFO - 2018-03-30 12:59:03 --> Hooks Class Initialized
DEBUG - 2018-03-30 12:59:03 --> UTF-8 Support Enabled
INFO - 2018-03-30 12:59:03 --> Utf8 Class Initialized
INFO - 2018-03-30 12:59:04 --> URI Class Initialized
INFO - 2018-03-30 12:59:04 --> Router Class Initialized
INFO - 2018-03-30 12:59:04 --> Output Class Initialized
INFO - 2018-03-30 12:59:04 --> Security Class Initialized
DEBUG - 2018-03-30 12:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 12:59:04 --> Input Class Initialized
INFO - 2018-03-30 12:59:04 --> Language Class Initialized
INFO - 2018-03-30 12:59:04 --> Language Class Initialized
INFO - 2018-03-30 12:59:04 --> Config Class Initialized
INFO - 2018-03-30 12:59:04 --> Loader Class Initialized
INFO - 2018-03-30 18:29:04 --> Helper loaded: url_helper
INFO - 2018-03-30 18:29:04 --> Helper loaded: notification_helper
INFO - 2018-03-30 18:29:04 --> Helper loaded: settings_helper
INFO - 2018-03-30 18:29:04 --> Helper loaded: permission_helper
INFO - 2018-03-30 18:29:04 --> Helper loaded: users_helper
INFO - 2018-03-30 18:29:04 --> Database Driver Class Initialized
DEBUG - 2018-03-30 18:29:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 18:29:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 18:29:04 --> Helper loaded: form_helper
INFO - 2018-03-30 18:29:04 --> Form Validation Class Initialized
INFO - 2018-03-30 18:29:04 --> Controller Class Initialized
INFO - 2018-03-30 18:29:04 --> Model Class Initialized
INFO - 2018-03-30 18:29:04 --> Helper loaded: inflector_helper
DEBUG - 2018-03-30 18:29:04 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-30 18:29:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-30 18:29:04 --> Model Class Initialized
INFO - 2018-03-30 18:29:04 --> Model Class Initialized
INFO - 2018-03-30 18:29:04 --> Model Class Initialized
INFO - 2018-03-30 18:29:04 --> Model Class Initialized
INFO - 2018-03-30 18:29:04 --> Final output sent to browser
DEBUG - 2018-03-30 18:29:04 --> Total execution time: 0.8457
