<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-03-14 09:17:23 --> Config Class Initialized
INFO - 2018-03-14 09:17:23 --> Hooks Class Initialized
DEBUG - 2018-03-14 09:17:23 --> UTF-8 Support Enabled
INFO - 2018-03-14 09:17:23 --> Utf8 Class Initialized
INFO - 2018-03-14 09:17:23 --> URI Class Initialized
INFO - 2018-03-14 09:17:23 --> Router Class Initialized
INFO - 2018-03-14 09:17:23 --> Output Class Initialized
INFO - 2018-03-14 09:17:23 --> Security Class Initialized
DEBUG - 2018-03-14 09:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-14 09:17:23 --> Input Class Initialized
INFO - 2018-03-14 09:17:24 --> Language Class Initialized
INFO - 2018-03-14 09:17:24 --> Language Class Initialized
INFO - 2018-03-14 09:17:24 --> Config Class Initialized
INFO - 2018-03-14 09:17:24 --> Loader Class Initialized
INFO - 2018-03-14 14:47:24 --> Helper loaded: url_helper
INFO - 2018-03-14 14:47:24 --> Helper loaded: notification_helper
INFO - 2018-03-14 14:47:24 --> Helper loaded: settings_helper
INFO - 2018-03-14 14:47:24 --> Helper loaded: permission_helper
INFO - 2018-03-14 14:47:24 --> Helper loaded: users_helper
INFO - 2018-03-14 14:47:24 --> Database Driver Class Initialized
DEBUG - 2018-03-14 14:47:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-14 14:47:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-14 14:47:24 --> Helper loaded: form_helper
INFO - 2018-03-14 14:47:24 --> Form Validation Class Initialized
INFO - 2018-03-14 14:47:24 --> Controller Class Initialized
INFO - 2018-03-14 14:47:24 --> Model Class Initialized
INFO - 2018-03-14 14:47:24 --> Helper loaded: inflector_helper
DEBUG - 2018-03-14 14:47:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-14 14:47:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-14 14:47:24 --> Model Class Initialized
INFO - 2018-03-14 14:47:24 --> Model Class Initialized
INFO - 2018-03-14 14:47:24 --> Model Class Initialized
INFO - 2018-03-14 14:47:24 --> Model Class Initialized
INFO - 2018-03-14 14:47:24 --> Model Class Initialized
INFO - 2018-03-14 14:47:24 --> Model Class Initialized
INFO - 2018-03-14 14:47:24 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-14 14:47:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-14 14:47:24 --> Final output sent to browser
DEBUG - 2018-03-14 14:47:24 --> Total execution time: 1.1324
INFO - 2018-03-14 09:17:25 --> Config Class Initialized
INFO - 2018-03-14 09:17:25 --> Hooks Class Initialized
DEBUG - 2018-03-14 09:17:25 --> UTF-8 Support Enabled
INFO - 2018-03-14 09:17:25 --> Utf8 Class Initialized
INFO - 2018-03-14 09:17:25 --> URI Class Initialized
INFO - 2018-03-14 09:17:25 --> Router Class Initialized
INFO - 2018-03-14 09:17:25 --> Output Class Initialized
INFO - 2018-03-14 09:17:25 --> Security Class Initialized
DEBUG - 2018-03-14 09:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-14 09:17:25 --> Input Class Initialized
INFO - 2018-03-14 09:17:25 --> Language Class Initialized
INFO - 2018-03-14 09:17:25 --> Language Class Initialized
INFO - 2018-03-14 09:17:25 --> Config Class Initialized
INFO - 2018-03-14 09:17:25 --> Loader Class Initialized
INFO - 2018-03-14 14:47:25 --> Helper loaded: url_helper
INFO - 2018-03-14 14:47:25 --> Helper loaded: notification_helper
INFO - 2018-03-14 14:47:25 --> Helper loaded: settings_helper
INFO - 2018-03-14 14:47:25 --> Helper loaded: permission_helper
INFO - 2018-03-14 14:47:25 --> Helper loaded: users_helper
INFO - 2018-03-14 14:47:26 --> Database Driver Class Initialized
DEBUG - 2018-03-14 14:47:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-14 14:47:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-14 14:47:26 --> Helper loaded: form_helper
INFO - 2018-03-14 14:47:26 --> Form Validation Class Initialized
INFO - 2018-03-14 14:47:26 --> Controller Class Initialized
INFO - 2018-03-14 14:47:26 --> Model Class Initialized
INFO - 2018-03-14 14:47:26 --> Helper loaded: inflector_helper
DEBUG - 2018-03-14 14:47:26 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-14 14:47:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-14 14:47:26 --> Model Class Initialized
INFO - 2018-03-14 14:47:26 --> Model Class Initialized
INFO - 2018-03-14 14:47:26 --> Model Class Initialized
INFO - 2018-03-14 14:47:26 --> Model Class Initialized
INFO - 2018-03-14 14:47:26 --> Model Class Initialized
INFO - 2018-03-14 14:47:26 --> Model Class Initialized
INFO - 2018-03-14 14:47:26 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-14 14:47:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-14 14:47:26 --> Final output sent to browser
DEBUG - 2018-03-14 14:47:26 --> Total execution time: 0.1089
