<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-04-27 05:29:33 --> Config Class Initialized
INFO - 2018-04-27 05:29:33 --> Hooks Class Initialized
DEBUG - 2018-04-27 05:29:33 --> UTF-8 Support Enabled
INFO - 2018-04-27 05:29:33 --> Utf8 Class Initialized
INFO - 2018-04-27 05:29:33 --> URI Class Initialized
DEBUG - 2018-04-27 05:29:33 --> No URI present. Default controller set.
INFO - 2018-04-27 05:29:33 --> Router Class Initialized
INFO - 2018-04-27 05:29:33 --> Output Class Initialized
INFO - 2018-04-27 05:29:33 --> Security Class Initialized
DEBUG - 2018-04-27 05:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-27 05:29:33 --> Input Class Initialized
INFO - 2018-04-27 05:29:33 --> Language Class Initialized
INFO - 2018-04-27 05:29:33 --> Language Class Initialized
INFO - 2018-04-27 05:29:33 --> Config Class Initialized
INFO - 2018-04-27 05:29:33 --> Loader Class Initialized
INFO - 2018-04-27 10:59:33 --> Helper loaded: url_helper
INFO - 2018-04-27 10:59:33 --> Helper loaded: notification_helper
INFO - 2018-04-27 10:59:33 --> Helper loaded: settings_helper
INFO - 2018-04-27 10:59:33 --> Helper loaded: permission_helper
INFO - 2018-04-27 10:59:33 --> Helper loaded: users_helper
INFO - 2018-04-27 10:59:33 --> Database Driver Class Initialized
DEBUG - 2018-04-27 10:59:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-27 10:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-27 10:59:33 --> Helper loaded: form_helper
INFO - 2018-04-27 10:59:33 --> Form Validation Class Initialized
INFO - 2018-04-27 10:59:33 --> Controller Class Initialized
INFO - 2018-04-27 10:59:33 --> Model Class Initialized
INFO - 2018-04-27 10:59:33 --> Helper loaded: inflector_helper
INFO - 2018-04-27 10:59:33 --> Model Class Initialized
DEBUG - 2018-04-27 10:59:33 --> File loaded: /home/pr01004/public_html/application/views/login.php
INFO - 2018-04-27 10:59:33 --> Final output sent to browser
DEBUG - 2018-04-27 10:59:33 --> Total execution time: 0.0857
INFO - 2018-04-27 06:31:05 --> Config Class Initialized
INFO - 2018-04-27 06:31:05 --> Hooks Class Initialized
DEBUG - 2018-04-27 06:31:05 --> UTF-8 Support Enabled
INFO - 2018-04-27 06:31:05 --> Utf8 Class Initialized
INFO - 2018-04-27 06:31:05 --> URI Class Initialized
INFO - 2018-04-27 06:31:06 --> Router Class Initialized
INFO - 2018-04-27 06:31:06 --> Output Class Initialized
INFO - 2018-04-27 06:31:06 --> Security Class Initialized
DEBUG - 2018-04-27 06:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-27 06:31:06 --> Input Class Initialized
INFO - 2018-04-27 06:31:06 --> Language Class Initialized
INFO - 2018-04-27 06:31:06 --> Language Class Initialized
INFO - 2018-04-27 06:31:06 --> Config Class Initialized
INFO - 2018-04-27 06:31:06 --> Loader Class Initialized
INFO - 2018-04-27 12:01:06 --> Helper loaded: url_helper
INFO - 2018-04-27 12:01:06 --> Helper loaded: notification_helper
INFO - 2018-04-27 12:01:06 --> Helper loaded: settings_helper
INFO - 2018-04-27 12:01:06 --> Helper loaded: permission_helper
INFO - 2018-04-27 12:01:06 --> Helper loaded: users_helper
INFO - 2018-04-27 12:01:06 --> Database Driver Class Initialized
DEBUG - 2018-04-27 12:01:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-27 12:01:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-27 12:01:06 --> Helper loaded: form_helper
INFO - 2018-04-27 12:01:06 --> Form Validation Class Initialized
INFO - 2018-04-27 12:01:06 --> Controller Class Initialized
INFO - 2018-04-27 12:01:06 --> Model Class Initialized
INFO - 2018-04-27 12:01:06 --> Helper loaded: inflector_helper
INFO - 2018-04-27 12:01:06 --> Model Class Initialized
INFO - 2018-04-27 12:01:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-27 06:31:06 --> Config Class Initialized
INFO - 2018-04-27 06:31:06 --> Hooks Class Initialized
DEBUG - 2018-04-27 06:31:06 --> UTF-8 Support Enabled
INFO - 2018-04-27 06:31:06 --> Utf8 Class Initialized
INFO - 2018-04-27 06:31:06 --> URI Class Initialized
INFO - 2018-04-27 06:31:06 --> Router Class Initialized
INFO - 2018-04-27 06:31:06 --> Output Class Initialized
INFO - 2018-04-27 06:31:06 --> Security Class Initialized
DEBUG - 2018-04-27 06:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-27 06:31:06 --> Input Class Initialized
INFO - 2018-04-27 06:31:06 --> Language Class Initialized
INFO - 2018-04-27 06:31:06 --> Language Class Initialized
INFO - 2018-04-27 06:31:06 --> Config Class Initialized
INFO - 2018-04-27 06:31:06 --> Loader Class Initialized
INFO - 2018-04-27 12:01:06 --> Helper loaded: url_helper
INFO - 2018-04-27 12:01:06 --> Helper loaded: notification_helper
INFO - 2018-04-27 12:01:06 --> Helper loaded: settings_helper
INFO - 2018-04-27 12:01:06 --> Helper loaded: permission_helper
INFO - 2018-04-27 12:01:06 --> Helper loaded: users_helper
INFO - 2018-04-27 12:01:06 --> Database Driver Class Initialized
DEBUG - 2018-04-27 12:01:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-27 12:01:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-27 12:01:06 --> Helper loaded: form_helper
INFO - 2018-04-27 12:01:06 --> Form Validation Class Initialized
INFO - 2018-04-27 12:01:06 --> Controller Class Initialized
DEBUG - 2018-04-27 12:01:06 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-04-27 12:01:06 --> Final output sent to browser
DEBUG - 2018-04-27 12:01:06 --> Total execution time: 0.0699
INFO - 2018-04-27 06:31:06 --> Config Class Initialized
INFO - 2018-04-27 06:31:06 --> Hooks Class Initialized
DEBUG - 2018-04-27 06:31:06 --> UTF-8 Support Enabled
INFO - 2018-04-27 06:31:06 --> Utf8 Class Initialized
INFO - 2018-04-27 06:31:06 --> URI Class Initialized
INFO - 2018-04-27 06:31:06 --> Router Class Initialized
INFO - 2018-04-27 06:31:06 --> Output Class Initialized
INFO - 2018-04-27 06:31:06 --> Security Class Initialized
DEBUG - 2018-04-27 06:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-27 06:31:06 --> Input Class Initialized
INFO - 2018-04-27 06:31:06 --> Language Class Initialized
INFO - 2018-04-27 06:31:06 --> Language Class Initialized
INFO - 2018-04-27 06:31:06 --> Config Class Initialized
INFO - 2018-04-27 06:31:06 --> Loader Class Initialized
INFO - 2018-04-27 12:01:06 --> Helper loaded: url_helper
INFO - 2018-04-27 12:01:06 --> Helper loaded: notification_helper
INFO - 2018-04-27 12:01:06 --> Helper loaded: settings_helper
INFO - 2018-04-27 12:01:06 --> Helper loaded: permission_helper
INFO - 2018-04-27 12:01:06 --> Helper loaded: users_helper
INFO - 2018-04-27 12:01:06 --> Database Driver Class Initialized
DEBUG - 2018-04-27 12:01:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-27 12:01:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-27 12:01:06 --> Helper loaded: form_helper
INFO - 2018-04-27 12:01:06 --> Form Validation Class Initialized
INFO - 2018-04-27 12:01:06 --> Controller Class Initialized
INFO - 2018-04-27 12:01:07 --> Model Class Initialized
INFO - 2018-04-27 12:01:07 --> Helper loaded: inflector_helper
INFO - 2018-04-27 12:01:07 --> Model Class Initialized
INFO - 2018-04-27 12:01:07 --> Model Class Initialized
INFO - 2018-04-27 12:01:07 --> Model Class Initialized
INFO - 2018-04-27 12:01:07 --> Model Class Initialized
INFO - 2018-04-27 12:01:07 --> Model Class Initialized
DEBUG - 2018-04-27 12:01:07 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-04-27 12:01:07 --> File loaded: /home/pr01004/public_html/application/views/admin/dashboard.php
DEBUG - 2018-04-27 12:01:07 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-04-27 12:01:07 --> Final output sent to browser
DEBUG - 2018-04-27 12:01:07 --> Total execution time: 0.3245
INFO - 2018-04-27 06:31:23 --> Config Class Initialized
INFO - 2018-04-27 06:31:23 --> Hooks Class Initialized
DEBUG - 2018-04-27 06:31:23 --> UTF-8 Support Enabled
INFO - 2018-04-27 06:31:23 --> Utf8 Class Initialized
INFO - 2018-04-27 06:31:23 --> URI Class Initialized
INFO - 2018-04-27 06:31:23 --> Router Class Initialized
INFO - 2018-04-27 06:31:23 --> Output Class Initialized
INFO - 2018-04-27 06:31:23 --> Security Class Initialized
DEBUG - 2018-04-27 06:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-27 06:31:23 --> Input Class Initialized
INFO - 2018-04-27 06:31:23 --> Language Class Initialized
INFO - 2018-04-27 06:31:23 --> Language Class Initialized
INFO - 2018-04-27 06:31:23 --> Config Class Initialized
INFO - 2018-04-27 06:31:23 --> Loader Class Initialized
INFO - 2018-04-27 12:01:23 --> Helper loaded: url_helper
INFO - 2018-04-27 12:01:23 --> Helper loaded: notification_helper
INFO - 2018-04-27 12:01:23 --> Helper loaded: settings_helper
INFO - 2018-04-27 12:01:23 --> Helper loaded: permission_helper
INFO - 2018-04-27 12:01:23 --> Helper loaded: users_helper
INFO - 2018-04-27 12:01:23 --> Database Driver Class Initialized
DEBUG - 2018-04-27 12:01:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-27 12:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-27 12:01:23 --> Helper loaded: form_helper
INFO - 2018-04-27 12:01:23 --> Form Validation Class Initialized
INFO - 2018-04-27 12:01:23 --> Controller Class Initialized
INFO - 2018-04-27 12:01:23 --> Model Class Initialized
INFO - 2018-04-27 12:01:23 --> Helper loaded: inflector_helper
INFO - 2018-04-27 12:01:23 --> Model Class Initialized
INFO - 2018-04-27 12:01:23 --> Model Class Initialized
INFO - 2018-04-27 12:01:23 --> Model Class Initialized
DEBUG - 2018-04-27 12:01:23 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-04-27 12:01:23 --> File loaded: /home/pr01004/public_html/application/views/admin/adminlist.php
DEBUG - 2018-04-27 12:01:23 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-04-27 12:01:23 --> Final output sent to browser
DEBUG - 2018-04-27 12:01:23 --> Total execution time: 0.1031
INFO - 2018-04-27 08:33:16 --> Config Class Initialized
INFO - 2018-04-27 08:33:16 --> Hooks Class Initialized
DEBUG - 2018-04-27 08:33:16 --> UTF-8 Support Enabled
INFO - 2018-04-27 08:33:16 --> Utf8 Class Initialized
INFO - 2018-04-27 08:33:16 --> Config Class Initialized
INFO - 2018-04-27 08:33:16 --> Hooks Class Initialized
INFO - 2018-04-27 08:33:16 --> URI Class Initialized
DEBUG - 2018-04-27 08:33:16 --> UTF-8 Support Enabled
INFO - 2018-04-27 08:33:16 --> Config Class Initialized
INFO - 2018-04-27 08:33:16 --> Hooks Class Initialized
INFO - 2018-04-27 08:33:16 --> Utf8 Class Initialized
INFO - 2018-04-27 08:33:16 --> URI Class Initialized
INFO - 2018-04-27 08:33:16 --> Router Class Initialized
DEBUG - 2018-04-27 08:33:16 --> UTF-8 Support Enabled
INFO - 2018-04-27 08:33:16 --> Utf8 Class Initialized
INFO - 2018-04-27 08:33:16 --> URI Class Initialized
INFO - 2018-04-27 08:33:16 --> Output Class Initialized
INFO - 2018-04-27 08:33:16 --> Router Class Initialized
INFO - 2018-04-27 08:33:16 --> Security Class Initialized
INFO - 2018-04-27 08:33:16 --> Router Class Initialized
INFO - 2018-04-27 08:33:16 --> Output Class Initialized
DEBUG - 2018-04-27 08:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-27 08:33:16 --> Input Class Initialized
INFO - 2018-04-27 08:33:16 --> Security Class Initialized
INFO - 2018-04-27 08:33:16 --> Language Class Initialized
INFO - 2018-04-27 08:33:16 --> Output Class Initialized
DEBUG - 2018-04-27 08:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-27 08:33:16 --> Input Class Initialized
INFO - 2018-04-27 08:33:16 --> Security Class Initialized
INFO - 2018-04-27 08:33:16 --> Language Class Initialized
DEBUG - 2018-04-27 08:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-27 08:33:16 --> Input Class Initialized
INFO - 2018-04-27 08:33:16 --> Language Class Initialized
INFO - 2018-04-27 08:33:16 --> Language Class Initialized
INFO - 2018-04-27 08:33:16 --> Config Class Initialized
INFO - 2018-04-27 08:33:16 --> Loader Class Initialized
INFO - 2018-04-27 08:33:17 --> Language Class Initialized
INFO - 2018-04-27 14:03:17 --> Helper loaded: url_helper
INFO - 2018-04-27 08:33:17 --> Config Class Initialized
INFO - 2018-04-27 08:33:17 --> Loader Class Initialized
INFO - 2018-04-27 08:33:17 --> Language Class Initialized
INFO - 2018-04-27 08:33:17 --> Config Class Initialized
INFO - 2018-04-27 08:33:17 --> Loader Class Initialized
INFO - 2018-04-27 14:03:17 --> Helper loaded: notification_helper
INFO - 2018-04-27 14:03:17 --> Helper loaded: settings_helper
INFO - 2018-04-27 14:03:17 --> Helper loaded: url_helper
INFO - 2018-04-27 14:03:17 --> Helper loaded: url_helper
INFO - 2018-04-27 14:03:17 --> Helper loaded: permission_helper
INFO - 2018-04-27 14:03:17 --> Helper loaded: notification_helper
INFO - 2018-04-27 14:03:17 --> Helper loaded: users_helper
INFO - 2018-04-27 14:03:17 --> Helper loaded: settings_helper
INFO - 2018-04-27 14:03:17 --> Helper loaded: notification_helper
INFO - 2018-04-27 14:03:17 --> Helper loaded: settings_helper
INFO - 2018-04-27 14:03:17 --> Helper loaded: permission_helper
INFO - 2018-04-27 14:03:17 --> Helper loaded: permission_helper
INFO - 2018-04-27 14:03:17 --> Helper loaded: users_helper
INFO - 2018-04-27 14:03:17 --> Helper loaded: users_helper
INFO - 2018-04-27 14:03:17 --> Database Driver Class Initialized
INFO - 2018-04-27 14:03:17 --> Database Driver Class Initialized
INFO - 2018-04-27 14:03:17 --> Database Driver Class Initialized
DEBUG - 2018-04-27 14:03:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-04-27 14:03:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-27 14:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-27 14:03:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-04-27 14:03:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-27 14:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-27 14:03:17 --> Helper loaded: form_helper
INFO - 2018-04-27 14:03:17 --> Form Validation Class Initialized
INFO - 2018-04-27 14:03:17 --> Controller Class Initialized
INFO - 2018-04-27 14:03:17 --> Helper loaded: form_helper
INFO - 2018-04-27 14:03:17 --> Form Validation Class Initialized
INFO - 2018-04-27 14:03:17 --> Controller Class Initialized
INFO - 2018-04-27 14:03:17 --> Helper loaded: form_helper
INFO - 2018-04-27 14:03:17 --> Form Validation Class Initialized
INFO - 2018-04-27 14:03:17 --> Controller Class Initialized
INFO - 2018-04-27 14:03:17 --> Model Class Initialized
INFO - 2018-04-27 14:03:17 --> Model Class Initialized
INFO - 2018-04-27 14:03:17 --> Model Class Initialized
INFO - 2018-04-27 14:03:17 --> Helper loaded: inflector_helper
INFO - 2018-04-27 14:03:17 --> Helper loaded: inflector_helper
INFO - 2018-04-27 14:03:17 --> Helper loaded: inflector_helper
DEBUG - 2018-04-27 14:03:17 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-04-27 14:03:17 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-04-27 14:03:17 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-27 14:03:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-27 14:03:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-27 14:03:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-27 14:03:17 --> Model Class Initialized
INFO - 2018-04-27 14:03:17 --> Model Class Initialized
INFO - 2018-04-27 14:03:17 --> Model Class Initialized
INFO - 2018-04-27 14:03:17 --> Model Class Initialized
INFO - 2018-04-27 14:03:17 --> Model Class Initialized
INFO - 2018-04-27 14:03:17 --> Model Class Initialized
INFO - 2018-04-27 14:03:17 --> Model Class Initialized
INFO - 2018-04-27 14:03:17 --> Model Class Initialized
INFO - 2018-04-27 14:03:17 --> Model Class Initialized
INFO - 2018-04-27 14:03:17 --> Model Class Initialized
INFO - 2018-04-27 14:03:17 --> Model Class Initialized
INFO - 2018-04-27 14:03:17 --> Model Class Initialized
INFO - 2018-04-27 14:03:17 --> Model Class Initialized
INFO - 2018-04-27 14:03:17 --> Model Class Initialized
INFO - 2018-04-27 14:03:17 --> Model Class Initialized
INFO - 2018-04-27 14:03:17 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-27 14:03:17 --> Model Class Initialized
INFO - 2018-04-27 14:03:17 --> Model Class Initialized
INFO - 2018-04-27 14:03:17 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-27 14:03:17 --> Model Class Initialized
INFO - 2018-04-27 14:03:17 --> Model Class Initialized
INFO - 2018-04-27 14:03:17 --> Model Class Initialized
INFO - 2018-04-27 14:03:17 --> Model Class Initialized
INFO - 2018-04-27 14:03:17 --> Model Class Initialized
INFO - 2018-04-27 14:03:17 --> Model Class Initialized
INFO - 2018-04-27 14:03:17 --> Final output sent to browser
DEBUG - 2018-04-27 14:03:17 --> Total execution time: 0.3341
INFO - 2018-04-27 14:03:17 --> Final output sent to browser
DEBUG - 2018-04-27 14:03:17 --> Total execution time: 0.3535
INFO - 2018-04-27 14:03:17 --> Model Class Initialized
INFO - 2018-04-27 14:03:17 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-27 14:03:17 --> Model Class Initialized
INFO - 2018-04-27 14:03:17 --> Final output sent to browser
DEBUG - 2018-04-27 14:03:17 --> Total execution time: 0.3489
INFO - 2018-04-27 08:33:18 --> Config Class Initialized
INFO - 2018-04-27 08:33:18 --> Hooks Class Initialized
DEBUG - 2018-04-27 08:33:18 --> UTF-8 Support Enabled
INFO - 2018-04-27 08:33:18 --> Utf8 Class Initialized
INFO - 2018-04-27 08:33:18 --> URI Class Initialized
INFO - 2018-04-27 08:33:18 --> Router Class Initialized
INFO - 2018-04-27 08:33:18 --> Output Class Initialized
INFO - 2018-04-27 08:33:18 --> Security Class Initialized
DEBUG - 2018-04-27 08:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-27 08:33:18 --> Input Class Initialized
INFO - 2018-04-27 08:33:18 --> Language Class Initialized
INFO - 2018-04-27 08:33:18 --> Language Class Initialized
INFO - 2018-04-27 08:33:18 --> Config Class Initialized
INFO - 2018-04-27 08:33:18 --> Loader Class Initialized
INFO - 2018-04-27 14:03:18 --> Helper loaded: url_helper
INFO - 2018-04-27 14:03:18 --> Helper loaded: notification_helper
INFO - 2018-04-27 14:03:18 --> Helper loaded: settings_helper
INFO - 2018-04-27 14:03:18 --> Helper loaded: permission_helper
INFO - 2018-04-27 14:03:18 --> Helper loaded: users_helper
INFO - 2018-04-27 14:03:18 --> Database Driver Class Initialized
DEBUG - 2018-04-27 14:03:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-27 14:03:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-27 14:03:18 --> Helper loaded: form_helper
INFO - 2018-04-27 14:03:18 --> Form Validation Class Initialized
INFO - 2018-04-27 14:03:18 --> Controller Class Initialized
INFO - 2018-04-27 14:03:18 --> Model Class Initialized
INFO - 2018-04-27 14:03:18 --> Helper loaded: inflector_helper
DEBUG - 2018-04-27 14:03:18 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-27 14:03:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-27 14:03:18 --> Model Class Initialized
INFO - 2018-04-27 14:03:18 --> Model Class Initialized
INFO - 2018-04-27 14:03:18 --> Model Class Initialized
INFO - 2018-04-27 14:03:18 --> Model Class Initialized
INFO - 2018-04-27 14:03:18 --> Model Class Initialized
INFO - 2018-04-27 14:03:18 --> Model Class Initialized
INFO - 2018-04-27 14:03:18 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-27 14:03:18 --> Final output sent to browser
DEBUG - 2018-04-27 14:03:18 --> Total execution time: 0.1189
INFO - 2018-04-27 08:33:18 --> Config Class Initialized
INFO - 2018-04-27 08:33:18 --> Hooks Class Initialized
DEBUG - 2018-04-27 08:33:18 --> UTF-8 Support Enabled
INFO - 2018-04-27 08:33:18 --> Utf8 Class Initialized
INFO - 2018-04-27 08:33:18 --> URI Class Initialized
INFO - 2018-04-27 08:33:18 --> Router Class Initialized
INFO - 2018-04-27 08:33:18 --> Output Class Initialized
INFO - 2018-04-27 08:33:18 --> Security Class Initialized
DEBUG - 2018-04-27 08:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-27 08:33:18 --> Input Class Initialized
INFO - 2018-04-27 08:33:18 --> Language Class Initialized
INFO - 2018-04-27 08:33:18 --> Language Class Initialized
INFO - 2018-04-27 08:33:18 --> Config Class Initialized
INFO - 2018-04-27 08:33:18 --> Loader Class Initialized
INFO - 2018-04-27 14:03:18 --> Helper loaded: url_helper
INFO - 2018-04-27 14:03:18 --> Helper loaded: notification_helper
INFO - 2018-04-27 14:03:18 --> Helper loaded: settings_helper
INFO - 2018-04-27 14:03:18 --> Helper loaded: permission_helper
INFO - 2018-04-27 14:03:18 --> Helper loaded: users_helper
INFO - 2018-04-27 14:03:18 --> Database Driver Class Initialized
DEBUG - 2018-04-27 14:03:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-27 14:03:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-27 14:03:18 --> Helper loaded: form_helper
INFO - 2018-04-27 14:03:18 --> Form Validation Class Initialized
INFO - 2018-04-27 14:03:18 --> Controller Class Initialized
INFO - 2018-04-27 14:03:18 --> Model Class Initialized
INFO - 2018-04-27 14:03:18 --> Helper loaded: inflector_helper
DEBUG - 2018-04-27 14:03:18 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-27 14:03:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-27 14:03:18 --> Model Class Initialized
INFO - 2018-04-27 14:03:18 --> Model Class Initialized
INFO - 2018-04-27 14:03:18 --> Model Class Initialized
INFO - 2018-04-27 14:03:18 --> Model Class Initialized
INFO - 2018-04-27 14:03:18 --> Model Class Initialized
INFO - 2018-04-27 14:03:18 --> Model Class Initialized
INFO - 2018-04-27 14:03:18 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-27 08:52:00 --> Config Class Initialized
INFO - 2018-04-27 08:52:00 --> Hooks Class Initialized
DEBUG - 2018-04-27 08:52:00 --> UTF-8 Support Enabled
INFO - 2018-04-27 08:52:00 --> Utf8 Class Initialized
INFO - 2018-04-27 08:52:00 --> URI Class Initialized
INFO - 2018-04-27 08:52:00 --> Router Class Initialized
INFO - 2018-04-27 08:52:00 --> Output Class Initialized
INFO - 2018-04-27 08:52:00 --> Security Class Initialized
DEBUG - 2018-04-27 08:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-27 08:52:00 --> Input Class Initialized
INFO - 2018-04-27 08:52:00 --> Language Class Initialized
INFO - 2018-04-27 08:52:00 --> Language Class Initialized
INFO - 2018-04-27 08:52:00 --> Config Class Initialized
INFO - 2018-04-27 08:52:00 --> Loader Class Initialized
INFO - 2018-04-27 14:22:00 --> Helper loaded: url_helper
INFO - 2018-04-27 14:22:00 --> Helper loaded: notification_helper
INFO - 2018-04-27 14:22:00 --> Helper loaded: settings_helper
INFO - 2018-04-27 14:22:00 --> Helper loaded: permission_helper
INFO - 2018-04-27 14:22:00 --> Helper loaded: users_helper
INFO - 2018-04-27 14:22:00 --> Database Driver Class Initialized
DEBUG - 2018-04-27 14:22:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-27 14:22:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-27 14:22:00 --> Helper loaded: form_helper
INFO - 2018-04-27 14:22:00 --> Form Validation Class Initialized
INFO - 2018-04-27 14:22:00 --> Controller Class Initialized
INFO - 2018-04-27 14:22:00 --> Model Class Initialized
INFO - 2018-04-27 14:22:00 --> Helper loaded: inflector_helper
INFO - 2018-04-27 14:22:00 --> Model Class Initialized
INFO - 2018-04-27 14:22:00 --> Model Class Initialized
INFO - 2018-04-27 08:52:00 --> Config Class Initialized
INFO - 2018-04-27 08:52:00 --> Hooks Class Initialized
DEBUG - 2018-04-27 08:52:00 --> UTF-8 Support Enabled
INFO - 2018-04-27 08:52:00 --> Utf8 Class Initialized
INFO - 2018-04-27 08:52:00 --> URI Class Initialized
DEBUG - 2018-04-27 08:52:00 --> No URI present. Default controller set.
INFO - 2018-04-27 08:52:00 --> Router Class Initialized
INFO - 2018-04-27 08:52:00 --> Output Class Initialized
INFO - 2018-04-27 08:52:00 --> Security Class Initialized
DEBUG - 2018-04-27 08:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-27 08:52:00 --> Input Class Initialized
INFO - 2018-04-27 08:52:00 --> Language Class Initialized
INFO - 2018-04-27 08:52:00 --> Language Class Initialized
INFO - 2018-04-27 08:52:00 --> Config Class Initialized
INFO - 2018-04-27 08:52:00 --> Loader Class Initialized
INFO - 2018-04-27 14:22:00 --> Helper loaded: url_helper
INFO - 2018-04-27 14:22:00 --> Helper loaded: notification_helper
INFO - 2018-04-27 14:22:00 --> Helper loaded: settings_helper
INFO - 2018-04-27 14:22:00 --> Helper loaded: permission_helper
INFO - 2018-04-27 14:22:00 --> Helper loaded: users_helper
INFO - 2018-04-27 14:22:00 --> Database Driver Class Initialized
DEBUG - 2018-04-27 14:22:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-27 14:22:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-27 14:22:00 --> Helper loaded: form_helper
INFO - 2018-04-27 14:22:00 --> Form Validation Class Initialized
INFO - 2018-04-27 14:22:00 --> Controller Class Initialized
INFO - 2018-04-27 14:22:00 --> Model Class Initialized
INFO - 2018-04-27 14:22:00 --> Helper loaded: inflector_helper
INFO - 2018-04-27 14:22:00 --> Model Class Initialized
DEBUG - 2018-04-27 14:22:00 --> File loaded: /home/pr01004/public_html/application/views/login.php
INFO - 2018-04-27 14:22:00 --> Final output sent to browser
DEBUG - 2018-04-27 14:22:00 --> Total execution time: 0.1964
INFO - 2018-04-27 08:52:10 --> Config Class Initialized
INFO - 2018-04-27 08:52:10 --> Hooks Class Initialized
DEBUG - 2018-04-27 08:52:10 --> UTF-8 Support Enabled
INFO - 2018-04-27 08:52:10 --> Utf8 Class Initialized
INFO - 2018-04-27 08:52:10 --> URI Class Initialized
INFO - 2018-04-27 08:52:10 --> Router Class Initialized
INFO - 2018-04-27 08:52:10 --> Output Class Initialized
INFO - 2018-04-27 08:52:10 --> Security Class Initialized
DEBUG - 2018-04-27 08:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-27 08:52:10 --> Input Class Initialized
INFO - 2018-04-27 08:52:10 --> Language Class Initialized
INFO - 2018-04-27 08:52:10 --> Language Class Initialized
INFO - 2018-04-27 08:52:10 --> Config Class Initialized
INFO - 2018-04-27 08:52:10 --> Loader Class Initialized
INFO - 2018-04-27 14:22:10 --> Helper loaded: url_helper
INFO - 2018-04-27 14:22:10 --> Helper loaded: notification_helper
INFO - 2018-04-27 14:22:10 --> Helper loaded: settings_helper
INFO - 2018-04-27 14:22:10 --> Helper loaded: permission_helper
INFO - 2018-04-27 14:22:10 --> Helper loaded: users_helper
INFO - 2018-04-27 14:22:10 --> Database Driver Class Initialized
DEBUG - 2018-04-27 14:22:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-27 14:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-27 14:22:10 --> Helper loaded: form_helper
INFO - 2018-04-27 14:22:10 --> Form Validation Class Initialized
INFO - 2018-04-27 14:22:10 --> Controller Class Initialized
INFO - 2018-04-27 14:22:10 --> Model Class Initialized
INFO - 2018-04-27 14:22:10 --> Helper loaded: inflector_helper
INFO - 2018-04-27 14:22:10 --> Model Class Initialized
INFO - 2018-04-27 14:22:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-27 08:52:11 --> Config Class Initialized
INFO - 2018-04-27 08:52:11 --> Hooks Class Initialized
DEBUG - 2018-04-27 08:52:11 --> UTF-8 Support Enabled
INFO - 2018-04-27 08:52:11 --> Utf8 Class Initialized
INFO - 2018-04-27 08:52:11 --> URI Class Initialized
INFO - 2018-04-27 08:52:11 --> Router Class Initialized
INFO - 2018-04-27 08:52:11 --> Output Class Initialized
INFO - 2018-04-27 08:52:11 --> Security Class Initialized
DEBUG - 2018-04-27 08:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-27 08:52:11 --> Input Class Initialized
INFO - 2018-04-27 08:52:11 --> Language Class Initialized
INFO - 2018-04-27 08:52:11 --> Language Class Initialized
INFO - 2018-04-27 08:52:11 --> Config Class Initialized
INFO - 2018-04-27 08:52:11 --> Loader Class Initialized
INFO - 2018-04-27 14:22:11 --> Helper loaded: url_helper
INFO - 2018-04-27 14:22:11 --> Helper loaded: notification_helper
INFO - 2018-04-27 14:22:11 --> Helper loaded: settings_helper
INFO - 2018-04-27 14:22:11 --> Helper loaded: permission_helper
INFO - 2018-04-27 14:22:11 --> Helper loaded: users_helper
INFO - 2018-04-27 14:22:11 --> Database Driver Class Initialized
DEBUG - 2018-04-27 14:22:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-27 14:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-27 14:22:11 --> Helper loaded: form_helper
INFO - 2018-04-27 14:22:11 --> Form Validation Class Initialized
INFO - 2018-04-27 14:22:11 --> Controller Class Initialized
INFO - 2018-04-27 14:22:11 --> Model Class Initialized
INFO - 2018-04-27 14:22:11 --> Helper loaded: inflector_helper
INFO - 2018-04-27 14:22:11 --> Model Class Initialized
INFO - 2018-04-27 14:22:11 --> Model Class Initialized
INFO - 2018-04-27 14:22:11 --> Model Class Initialized
INFO - 2018-04-27 14:22:11 --> Model Class Initialized
INFO - 2018-04-27 14:22:11 --> Model Class Initialized
DEBUG - 2018-04-27 14:22:11 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-04-27 14:22:11 --> File loaded: /home/pr01004/public_html/application/views/admin/dashboard.php
DEBUG - 2018-04-27 14:22:11 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-04-27 14:22:11 --> Final output sent to browser
DEBUG - 2018-04-27 14:22:11 --> Total execution time: 0.3875
