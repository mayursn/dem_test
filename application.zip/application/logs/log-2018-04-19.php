<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-04-19 05:54:33 --> Config Class Initialized
INFO - 2018-04-19 05:54:33 --> Hooks Class Initialized
DEBUG - 2018-04-19 05:54:33 --> UTF-8 Support Enabled
INFO - 2018-04-19 05:54:33 --> Utf8 Class Initialized
INFO - 2018-04-19 05:54:33 --> URI Class Initialized
INFO - 2018-04-19 05:54:33 --> Router Class Initialized
INFO - 2018-04-19 05:54:33 --> Output Class Initialized
INFO - 2018-04-19 05:54:33 --> Security Class Initialized
DEBUG - 2018-04-19 05:54:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 05:54:33 --> Input Class Initialized
INFO - 2018-04-19 05:54:33 --> Language Class Initialized
INFO - 2018-04-19 05:54:33 --> Language Class Initialized
INFO - 2018-04-19 05:54:33 --> Config Class Initialized
INFO - 2018-04-19 05:54:33 --> Loader Class Initialized
INFO - 2018-04-19 11:24:33 --> Helper loaded: url_helper
INFO - 2018-04-19 11:24:33 --> Helper loaded: notification_helper
INFO - 2018-04-19 11:24:33 --> Helper loaded: settings_helper
INFO - 2018-04-19 11:24:33 --> Helper loaded: permission_helper
INFO - 2018-04-19 11:24:33 --> Helper loaded: users_helper
INFO - 2018-04-19 11:24:33 --> Database Driver Class Initialized
DEBUG - 2018-04-19 11:24:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 11:24:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 11:24:33 --> Helper loaded: form_helper
INFO - 2018-04-19 11:24:33 --> Form Validation Class Initialized
INFO - 2018-04-19 11:24:33 --> Controller Class Initialized
INFO - 2018-04-19 11:24:33 --> Model Class Initialized
INFO - 2018-04-19 11:24:33 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 11:24:33 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 11:24:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 11:24:33 --> Model Class Initialized
INFO - 2018-04-19 11:24:33 --> Model Class Initialized
INFO - 2018-04-19 11:24:33 --> Model Class Initialized
INFO - 2018-04-19 11:24:33 --> Model Class Initialized
INFO - 2018-04-19 11:24:33 --> Model Class Initialized
INFO - 2018-04-19 05:54:33 --> Config Class Initialized
INFO - 2018-04-19 05:54:33 --> Hooks Class Initialized
INFO - 2018-04-19 11:24:33 --> Model Class Initialized
INFO - 2018-04-19 11:24:33 --> Model Class Initialized
INFO - 2018-04-19 11:24:33 --> Model Class Initialized
INFO - 2018-04-19 11:24:33 --> Model Class Initialized
INFO - 2018-04-19 11:24:33 --> Model Class Initialized
DEBUG - 2018-04-19 05:54:33 --> UTF-8 Support Enabled
INFO - 2018-04-19 05:54:33 --> Utf8 Class Initialized
INFO - 2018-04-19 05:54:33 --> URI Class Initialized
INFO - 2018-04-19 11:24:33 --> Model Class Initialized
INFO - 2018-04-19 11:24:33 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 11:24:33 --> Model Class Initialized
INFO - 2018-04-19 05:54:33 --> Router Class Initialized
INFO - 2018-04-19 05:54:33 --> Output Class Initialized
INFO - 2018-04-19 05:54:33 --> Security Class Initialized
DEBUG - 2018-04-19 05:54:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 05:54:33 --> Input Class Initialized
INFO - 2018-04-19 05:54:33 --> Language Class Initialized
INFO - 2018-04-19 11:24:33 --> Final output sent to browser
DEBUG - 2018-04-19 11:24:33 --> Total execution time: 0.1239
INFO - 2018-04-19 05:54:33 --> Language Class Initialized
INFO - 2018-04-19 05:54:33 --> Config Class Initialized
INFO - 2018-04-19 05:54:33 --> Loader Class Initialized
INFO - 2018-04-19 11:24:33 --> Helper loaded: url_helper
INFO - 2018-04-19 11:24:33 --> Helper loaded: notification_helper
INFO - 2018-04-19 11:24:33 --> Helper loaded: settings_helper
INFO - 2018-04-19 11:24:33 --> Helper loaded: permission_helper
INFO - 2018-04-19 11:24:33 --> Helper loaded: users_helper
INFO - 2018-04-19 11:24:33 --> Database Driver Class Initialized
DEBUG - 2018-04-19 11:24:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 11:24:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 11:24:33 --> Helper loaded: form_helper
INFO - 2018-04-19 11:24:33 --> Form Validation Class Initialized
INFO - 2018-04-19 11:24:33 --> Controller Class Initialized
INFO - 2018-04-19 11:24:33 --> Model Class Initialized
INFO - 2018-04-19 11:24:33 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 11:24:33 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 11:24:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 11:24:33 --> Model Class Initialized
INFO - 2018-04-19 11:24:33 --> Model Class Initialized
INFO - 2018-04-19 11:24:33 --> Model Class Initialized
INFO - 2018-04-19 11:24:33 --> Model Class Initialized
INFO - 2018-04-19 11:24:33 --> Model Class Initialized
INFO - 2018-04-19 11:24:33 --> Model Class Initialized
INFO - 2018-04-19 11:24:33 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 11:24:33 --> Model Class Initialized
INFO - 2018-04-19 11:24:33 --> Final output sent to browser
DEBUG - 2018-04-19 11:24:33 --> Total execution time: 0.1090
INFO - 2018-04-19 05:54:33 --> Config Class Initialized
INFO - 2018-04-19 05:54:33 --> Hooks Class Initialized
DEBUG - 2018-04-19 05:54:33 --> UTF-8 Support Enabled
INFO - 2018-04-19 05:54:33 --> Utf8 Class Initialized
INFO - 2018-04-19 05:54:33 --> URI Class Initialized
INFO - 2018-04-19 05:54:33 --> Router Class Initialized
INFO - 2018-04-19 05:54:33 --> Output Class Initialized
INFO - 2018-04-19 05:54:33 --> Config Class Initialized
INFO - 2018-04-19 05:54:33 --> Hooks Class Initialized
INFO - 2018-04-19 05:54:33 --> Security Class Initialized
DEBUG - 2018-04-19 05:54:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 05:54:33 --> Input Class Initialized
INFO - 2018-04-19 05:54:33 --> Language Class Initialized
DEBUG - 2018-04-19 05:54:33 --> UTF-8 Support Enabled
INFO - 2018-04-19 05:54:33 --> Utf8 Class Initialized
INFO - 2018-04-19 05:54:33 --> URI Class Initialized
INFO - 2018-04-19 05:54:33 --> Router Class Initialized
INFO - 2018-04-19 05:54:33 --> Output Class Initialized
INFO - 2018-04-19 05:54:33 --> Security Class Initialized
DEBUG - 2018-04-19 05:54:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 05:54:33 --> Input Class Initialized
INFO - 2018-04-19 05:54:33 --> Language Class Initialized
INFO - 2018-04-19 05:54:33 --> Language Class Initialized
INFO - 2018-04-19 05:54:33 --> Config Class Initialized
INFO - 2018-04-19 05:54:33 --> Loader Class Initialized
INFO - 2018-04-19 11:24:33 --> Helper loaded: url_helper
INFO - 2018-04-19 11:24:33 --> Helper loaded: notification_helper
INFO - 2018-04-19 11:24:33 --> Helper loaded: settings_helper
INFO - 2018-04-19 11:24:33 --> Helper loaded: permission_helper
INFO - 2018-04-19 11:24:33 --> Helper loaded: users_helper
INFO - 2018-04-19 05:54:33 --> Language Class Initialized
INFO - 2018-04-19 05:54:33 --> Config Class Initialized
INFO - 2018-04-19 05:54:33 --> Loader Class Initialized
INFO - 2018-04-19 11:24:33 --> Database Driver Class Initialized
INFO - 2018-04-19 11:24:33 --> Helper loaded: url_helper
INFO - 2018-04-19 11:24:33 --> Helper loaded: notification_helper
INFO - 2018-04-19 11:24:33 --> Helper loaded: settings_helper
INFO - 2018-04-19 11:24:33 --> Helper loaded: permission_helper
INFO - 2018-04-19 11:24:33 --> Helper loaded: users_helper
DEBUG - 2018-04-19 11:24:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 11:24:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 11:24:33 --> Helper loaded: form_helper
INFO - 2018-04-19 11:24:33 --> Form Validation Class Initialized
INFO - 2018-04-19 11:24:33 --> Controller Class Initialized
INFO - 2018-04-19 11:24:33 --> Database Driver Class Initialized
INFO - 2018-04-19 11:24:33 --> Model Class Initialized
INFO - 2018-04-19 11:24:33 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 11:24:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 11:24:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-04-19 11:24:33 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 11:24:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 11:24:33 --> Model Class Initialized
INFO - 2018-04-19 11:24:33 --> Model Class Initialized
INFO - 2018-04-19 11:24:33 --> Model Class Initialized
INFO - 2018-04-19 11:24:33 --> Model Class Initialized
INFO - 2018-04-19 11:24:33 --> Model Class Initialized
INFO - 2018-04-19 11:24:33 --> Model Class Initialized
INFO - 2018-04-19 11:24:33 --> Model Class Initialized
INFO - 2018-04-19 11:24:33 --> Model Class Initialized
INFO - 2018-04-19 11:24:33 --> Model Class Initialized
INFO - 2018-04-19 11:24:33 --> Model Class Initialized
INFO - 2018-04-19 11:24:33 --> Helper loaded: form_helper
INFO - 2018-04-19 11:24:33 --> Form Validation Class Initialized
INFO - 2018-04-19 11:24:33 --> Controller Class Initialized
INFO - 2018-04-19 11:24:33 --> Model Class Initialized
INFO - 2018-04-19 11:24:33 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 11:24:33 --> Model Class Initialized
INFO - 2018-04-19 11:24:33 --> Model Class Initialized
INFO - 2018-04-19 11:24:33 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 11:24:33 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 11:24:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 11:24:33 --> Model Class Initialized
INFO - 2018-04-19 11:24:33 --> Model Class Initialized
INFO - 2018-04-19 11:24:33 --> Model Class Initialized
INFO - 2018-04-19 11:24:33 --> Model Class Initialized
INFO - 2018-04-19 11:24:33 --> Model Class Initialized
INFO - 2018-04-19 11:24:33 --> Model Class Initialized
INFO - 2018-04-19 11:24:33 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 11:24:33 --> Final output sent to browser
DEBUG - 2018-04-19 11:24:33 --> Total execution time: 0.1090
INFO - 2018-04-19 11:24:33 --> Final output sent to browser
DEBUG - 2018-04-19 11:24:33 --> Total execution time: 0.1236
INFO - 2018-04-19 05:54:34 --> Config Class Initialized
INFO - 2018-04-19 05:54:34 --> Hooks Class Initialized
DEBUG - 2018-04-19 05:54:34 --> UTF-8 Support Enabled
INFO - 2018-04-19 05:54:34 --> Utf8 Class Initialized
INFO - 2018-04-19 05:54:34 --> URI Class Initialized
INFO - 2018-04-19 05:54:34 --> Router Class Initialized
INFO - 2018-04-19 05:54:34 --> Output Class Initialized
INFO - 2018-04-19 05:54:34 --> Security Class Initialized
DEBUG - 2018-04-19 05:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 05:54:34 --> Input Class Initialized
INFO - 2018-04-19 05:54:34 --> Language Class Initialized
INFO - 2018-04-19 05:54:34 --> Language Class Initialized
INFO - 2018-04-19 05:54:34 --> Config Class Initialized
INFO - 2018-04-19 05:54:34 --> Loader Class Initialized
INFO - 2018-04-19 11:24:34 --> Helper loaded: url_helper
INFO - 2018-04-19 11:24:34 --> Helper loaded: notification_helper
INFO - 2018-04-19 11:24:34 --> Helper loaded: settings_helper
INFO - 2018-04-19 11:24:34 --> Helper loaded: permission_helper
INFO - 2018-04-19 11:24:34 --> Helper loaded: users_helper
INFO - 2018-04-19 11:24:34 --> Database Driver Class Initialized
DEBUG - 2018-04-19 11:24:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 11:24:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 11:24:34 --> Helper loaded: form_helper
INFO - 2018-04-19 11:24:34 --> Form Validation Class Initialized
INFO - 2018-04-19 11:24:34 --> Controller Class Initialized
INFO - 2018-04-19 11:24:34 --> Model Class Initialized
INFO - 2018-04-19 11:24:34 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 11:24:34 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 11:24:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 11:24:34 --> Model Class Initialized
INFO - 2018-04-19 11:24:34 --> Model Class Initialized
INFO - 2018-04-19 11:24:34 --> Model Class Initialized
INFO - 2018-04-19 11:24:34 --> Model Class Initialized
INFO - 2018-04-19 11:24:34 --> Model Class Initialized
INFO - 2018-04-19 11:24:34 --> Model Class Initialized
INFO - 2018-04-19 11:24:34 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 11:24:34 --> Model Class Initialized
INFO - 2018-04-19 11:24:34 --> Final output sent to browser
DEBUG - 2018-04-19 11:24:34 --> Total execution time: 0.1085
INFO - 2018-04-19 05:57:39 --> Config Class Initialized
INFO - 2018-04-19 05:57:39 --> Hooks Class Initialized
DEBUG - 2018-04-19 05:57:39 --> UTF-8 Support Enabled
INFO - 2018-04-19 05:57:39 --> Utf8 Class Initialized
INFO - 2018-04-19 05:57:39 --> URI Class Initialized
INFO - 2018-04-19 05:57:39 --> Router Class Initialized
INFO - 2018-04-19 05:57:39 --> Config Class Initialized
INFO - 2018-04-19 05:57:39 --> Hooks Class Initialized
INFO - 2018-04-19 05:57:39 --> Output Class Initialized
DEBUG - 2018-04-19 05:57:39 --> UTF-8 Support Enabled
INFO - 2018-04-19 05:57:39 --> Utf8 Class Initialized
INFO - 2018-04-19 05:57:39 --> Security Class Initialized
INFO - 2018-04-19 05:57:39 --> URI Class Initialized
DEBUG - 2018-04-19 05:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 05:57:39 --> Input Class Initialized
INFO - 2018-04-19 05:57:39 --> Language Class Initialized
INFO - 2018-04-19 05:57:39 --> Router Class Initialized
INFO - 2018-04-19 05:57:39 --> Output Class Initialized
INFO - 2018-04-19 05:57:39 --> Security Class Initialized
DEBUG - 2018-04-19 05:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 05:57:39 --> Input Class Initialized
INFO - 2018-04-19 05:57:39 --> Language Class Initialized
INFO - 2018-04-19 05:57:39 --> Config Class Initialized
INFO - 2018-04-19 05:57:39 --> Hooks Class Initialized
INFO - 2018-04-19 05:57:39 --> Language Class Initialized
INFO - 2018-04-19 05:57:39 --> Config Class Initialized
INFO - 2018-04-19 05:57:39 --> Loader Class Initialized
INFO - 2018-04-19 11:27:39 --> Helper loaded: url_helper
INFO - 2018-04-19 11:27:39 --> Helper loaded: notification_helper
INFO - 2018-04-19 11:27:39 --> Helper loaded: settings_helper
INFO - 2018-04-19 11:27:39 --> Helper loaded: permission_helper
INFO - 2018-04-19 11:27:39 --> Helper loaded: users_helper
DEBUG - 2018-04-19 05:57:39 --> UTF-8 Support Enabled
INFO - 2018-04-19 05:57:39 --> Utf8 Class Initialized
INFO - 2018-04-19 05:57:39 --> Language Class Initialized
INFO - 2018-04-19 05:57:39 --> Config Class Initialized
INFO - 2018-04-19 05:57:39 --> Loader Class Initialized
INFO - 2018-04-19 11:27:39 --> Helper loaded: url_helper
INFO - 2018-04-19 11:27:39 --> Helper loaded: notification_helper
INFO - 2018-04-19 11:27:39 --> Helper loaded: settings_helper
INFO - 2018-04-19 11:27:39 --> Helper loaded: permission_helper
INFO - 2018-04-19 05:57:39 --> URI Class Initialized
INFO - 2018-04-19 11:27:39 --> Helper loaded: users_helper
INFO - 2018-04-19 11:27:39 --> Database Driver Class Initialized
DEBUG - 2018-04-19 11:27:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 11:27:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 11:27:39 --> Database Driver Class Initialized
INFO - 2018-04-19 11:27:39 --> Helper loaded: form_helper
INFO - 2018-04-19 11:27:39 --> Form Validation Class Initialized
INFO - 2018-04-19 11:27:39 --> Controller Class Initialized
INFO - 2018-04-19 05:57:39 --> Router Class Initialized
DEBUG - 2018-04-19 11:27:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 11:27:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 11:27:39 --> Model Class Initialized
INFO - 2018-04-19 11:27:39 --> Helper loaded: inflector_helper
INFO - 2018-04-19 11:27:39 --> Helper loaded: form_helper
INFO - 2018-04-19 11:27:39 --> Form Validation Class Initialized
INFO - 2018-04-19 11:27:39 --> Controller Class Initialized
DEBUG - 2018-04-19 11:27:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 11:27:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 11:27:39 --> Model Class Initialized
INFO - 2018-04-19 11:27:39 --> Model Class Initialized
INFO - 2018-04-19 05:57:39 --> Output Class Initialized
INFO - 2018-04-19 11:27:39 --> Model Class Initialized
INFO - 2018-04-19 11:27:39 --> Model Class Initialized
INFO - 2018-04-19 11:27:39 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 11:27:39 --> Model Class Initialized
INFO - 2018-04-19 11:27:39 --> Helper loaded: inflector_helper
INFO - 2018-04-19 11:27:39 --> Final output sent to browser
DEBUG - 2018-04-19 11:27:39 --> Total execution time: 0.1188
DEBUG - 2018-04-19 11:27:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 05:57:39 --> Security Class Initialized
INFO - 2018-04-19 11:27:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 11:27:39 --> Model Class Initialized
INFO - 2018-04-19 11:27:39 --> Model Class Initialized
INFO - 2018-04-19 11:27:39 --> Model Class Initialized
INFO - 2018-04-19 11:27:39 --> Model Class Initialized
INFO - 2018-04-19 11:27:39 --> Model Class Initialized
INFO - 2018-04-19 11:27:39 --> Model Class Initialized
INFO - 2018-04-19 11:27:39 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 11:27:39 --> Final output sent to browser
DEBUG - 2018-04-19 11:27:39 --> Total execution time: 0.1179
DEBUG - 2018-04-19 05:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 05:57:39 --> Input Class Initialized
INFO - 2018-04-19 05:57:39 --> Language Class Initialized
INFO - 2018-04-19 05:57:39 --> Language Class Initialized
INFO - 2018-04-19 05:57:39 --> Config Class Initialized
INFO - 2018-04-19 05:57:39 --> Loader Class Initialized
INFO - 2018-04-19 11:27:39 --> Helper loaded: url_helper
INFO - 2018-04-19 11:27:39 --> Helper loaded: notification_helper
INFO - 2018-04-19 11:27:39 --> Helper loaded: settings_helper
INFO - 2018-04-19 11:27:39 --> Helper loaded: permission_helper
INFO - 2018-04-19 11:27:39 --> Helper loaded: users_helper
INFO - 2018-04-19 11:27:39 --> Database Driver Class Initialized
DEBUG - 2018-04-19 11:27:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 11:27:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 11:27:39 --> Helper loaded: form_helper
INFO - 2018-04-19 11:27:39 --> Form Validation Class Initialized
INFO - 2018-04-19 11:27:39 --> Controller Class Initialized
INFO - 2018-04-19 11:27:39 --> Model Class Initialized
INFO - 2018-04-19 11:27:39 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 11:27:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 11:27:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 11:27:39 --> Model Class Initialized
INFO - 2018-04-19 11:27:39 --> Model Class Initialized
INFO - 2018-04-19 11:27:39 --> Model Class Initialized
INFO - 2018-04-19 11:27:39 --> Model Class Initialized
INFO - 2018-04-19 11:27:39 --> Model Class Initialized
INFO - 2018-04-19 11:27:39 --> Model Class Initialized
INFO - 2018-04-19 11:27:39 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 11:27:39 --> Final output sent to browser
DEBUG - 2018-04-19 11:27:39 --> Total execution time: 0.2316
INFO - 2018-04-19 05:57:40 --> Config Class Initialized
INFO - 2018-04-19 05:57:40 --> Hooks Class Initialized
INFO - 2018-04-19 05:57:40 --> Config Class Initialized
INFO - 2018-04-19 05:57:40 --> Hooks Class Initialized
DEBUG - 2018-04-19 05:57:40 --> UTF-8 Support Enabled
INFO - 2018-04-19 05:57:40 --> Utf8 Class Initialized
DEBUG - 2018-04-19 05:57:40 --> UTF-8 Support Enabled
INFO - 2018-04-19 05:57:40 --> Utf8 Class Initialized
INFO - 2018-04-19 05:57:40 --> URI Class Initialized
INFO - 2018-04-19 05:57:40 --> URI Class Initialized
INFO - 2018-04-19 05:57:40 --> Router Class Initialized
INFO - 2018-04-19 05:57:40 --> Router Class Initialized
INFO - 2018-04-19 05:57:40 --> Output Class Initialized
INFO - 2018-04-19 05:57:40 --> Output Class Initialized
INFO - 2018-04-19 05:57:40 --> Security Class Initialized
INFO - 2018-04-19 05:57:40 --> Security Class Initialized
DEBUG - 2018-04-19 05:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 05:57:40 --> Input Class Initialized
DEBUG - 2018-04-19 05:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 05:57:40 --> Input Class Initialized
INFO - 2018-04-19 05:57:40 --> Language Class Initialized
INFO - 2018-04-19 05:57:40 --> Language Class Initialized
INFO - 2018-04-19 05:57:40 --> Language Class Initialized
INFO - 2018-04-19 05:57:40 --> Config Class Initialized
INFO - 2018-04-19 05:57:40 --> Loader Class Initialized
INFO - 2018-04-19 11:27:40 --> Helper loaded: url_helper
INFO - 2018-04-19 11:27:40 --> Helper loaded: notification_helper
INFO - 2018-04-19 11:27:40 --> Helper loaded: settings_helper
INFO - 2018-04-19 11:27:40 --> Helper loaded: permission_helper
INFO - 2018-04-19 11:27:40 --> Helper loaded: users_helper
INFO - 2018-04-19 05:57:40 --> Language Class Initialized
INFO - 2018-04-19 05:57:40 --> Config Class Initialized
INFO - 2018-04-19 05:57:40 --> Loader Class Initialized
INFO - 2018-04-19 11:27:40 --> Helper loaded: url_helper
INFO - 2018-04-19 11:27:40 --> Helper loaded: notification_helper
INFO - 2018-04-19 11:27:40 --> Helper loaded: settings_helper
INFO - 2018-04-19 11:27:40 --> Helper loaded: permission_helper
INFO - 2018-04-19 11:27:40 --> Helper loaded: users_helper
INFO - 2018-04-19 11:27:40 --> Database Driver Class Initialized
DEBUG - 2018-04-19 11:27:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 11:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 11:27:40 --> Database Driver Class Initialized
INFO - 2018-04-19 11:27:40 --> Helper loaded: form_helper
INFO - 2018-04-19 11:27:40 --> Form Validation Class Initialized
INFO - 2018-04-19 11:27:40 --> Controller Class Initialized
DEBUG - 2018-04-19 11:27:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 11:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 11:27:40 --> Model Class Initialized
INFO - 2018-04-19 11:27:40 --> Helper loaded: inflector_helper
INFO - 2018-04-19 11:27:40 --> Helper loaded: form_helper
INFO - 2018-04-19 11:27:40 --> Form Validation Class Initialized
INFO - 2018-04-19 11:27:40 --> Controller Class Initialized
DEBUG - 2018-04-19 11:27:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 11:27:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 11:27:40 --> Model Class Initialized
INFO - 2018-04-19 11:27:40 --> Model Class Initialized
INFO - 2018-04-19 11:27:40 --> Model Class Initialized
INFO - 2018-04-19 11:27:40 --> Model Class Initialized
INFO - 2018-04-19 11:27:40 --> Model Class Initialized
INFO - 2018-04-19 11:27:40 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 11:27:40 --> Model Class Initialized
INFO - 2018-04-19 11:27:40 --> Model Class Initialized
INFO - 2018-04-19 11:27:40 --> Helper loaded: inflector_helper
INFO - 2018-04-19 11:27:40 --> Final output sent to browser
DEBUG - 2018-04-19 11:27:40 --> Total execution time: 0.1008
DEBUG - 2018-04-19 11:27:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 11:27:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 11:27:40 --> Model Class Initialized
INFO - 2018-04-19 11:27:40 --> Model Class Initialized
INFO - 2018-04-19 11:27:40 --> Model Class Initialized
INFO - 2018-04-19 11:27:40 --> Model Class Initialized
INFO - 2018-04-19 11:27:40 --> Model Class Initialized
INFO - 2018-04-19 11:27:40 --> Model Class Initialized
INFO - 2018-04-19 11:27:40 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 11:27:40 --> Final output sent to browser
DEBUG - 2018-04-19 11:27:40 --> Total execution time: 0.1120
INFO - 2018-04-19 05:58:15 --> Config Class Initialized
INFO - 2018-04-19 05:58:15 --> Hooks Class Initialized
DEBUG - 2018-04-19 05:58:15 --> UTF-8 Support Enabled
INFO - 2018-04-19 05:58:15 --> Utf8 Class Initialized
INFO - 2018-04-19 05:58:15 --> URI Class Initialized
INFO - 2018-04-19 05:58:15 --> Router Class Initialized
INFO - 2018-04-19 05:58:15 --> Output Class Initialized
INFO - 2018-04-19 05:58:15 --> Security Class Initialized
DEBUG - 2018-04-19 05:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 05:58:15 --> Input Class Initialized
INFO - 2018-04-19 05:58:15 --> Language Class Initialized
INFO - 2018-04-19 05:58:15 --> Language Class Initialized
INFO - 2018-04-19 05:58:15 --> Config Class Initialized
INFO - 2018-04-19 05:58:15 --> Loader Class Initialized
INFO - 2018-04-19 11:28:15 --> Helper loaded: url_helper
INFO - 2018-04-19 11:28:15 --> Helper loaded: notification_helper
INFO - 2018-04-19 11:28:15 --> Helper loaded: settings_helper
INFO - 2018-04-19 11:28:15 --> Helper loaded: permission_helper
INFO - 2018-04-19 11:28:15 --> Helper loaded: users_helper
INFO - 2018-04-19 11:28:15 --> Database Driver Class Initialized
DEBUG - 2018-04-19 11:28:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 11:28:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 11:28:15 --> Helper loaded: form_helper
INFO - 2018-04-19 11:28:15 --> Form Validation Class Initialized
INFO - 2018-04-19 11:28:15 --> Controller Class Initialized
INFO - 2018-04-19 11:28:15 --> Model Class Initialized
INFO - 2018-04-19 11:28:15 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 11:28:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 11:28:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 11:28:15 --> Model Class Initialized
INFO - 2018-04-19 11:28:15 --> Model Class Initialized
INFO - 2018-04-19 11:28:15 --> Model Class Initialized
INFO - 2018-04-19 11:28:15 --> Model Class Initialized
INFO - 2018-04-19 11:28:15 --> Model Class Initialized
INFO - 2018-04-19 11:28:15 --> Model Class Initialized
INFO - 2018-04-19 11:28:15 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 11:28:15 --> Final output sent to browser
DEBUG - 2018-04-19 11:28:15 --> Total execution time: 0.1051
INFO - 2018-04-19 05:58:15 --> Config Class Initialized
INFO - 2018-04-19 05:58:15 --> Hooks Class Initialized
DEBUG - 2018-04-19 05:58:15 --> UTF-8 Support Enabled
INFO - 2018-04-19 05:58:15 --> Utf8 Class Initialized
INFO - 2018-04-19 05:58:15 --> URI Class Initialized
INFO - 2018-04-19 05:58:15 --> Router Class Initialized
INFO - 2018-04-19 05:58:15 --> Output Class Initialized
INFO - 2018-04-19 05:58:15 --> Config Class Initialized
INFO - 2018-04-19 05:58:15 --> Hooks Class Initialized
INFO - 2018-04-19 05:58:15 --> Security Class Initialized
DEBUG - 2018-04-19 05:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 05:58:15 --> Input Class Initialized
DEBUG - 2018-04-19 05:58:15 --> UTF-8 Support Enabled
INFO - 2018-04-19 05:58:15 --> Utf8 Class Initialized
INFO - 2018-04-19 05:58:15 --> Language Class Initialized
INFO - 2018-04-19 05:58:15 --> URI Class Initialized
INFO - 2018-04-19 05:58:15 --> Router Class Initialized
INFO - 2018-04-19 05:58:15 --> Output Class Initialized
INFO - 2018-04-19 05:58:15 --> Security Class Initialized
DEBUG - 2018-04-19 05:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 05:58:15 --> Input Class Initialized
INFO - 2018-04-19 05:58:15 --> Language Class Initialized
INFO - 2018-04-19 05:58:15 --> Language Class Initialized
INFO - 2018-04-19 05:58:15 --> Config Class Initialized
INFO - 2018-04-19 05:58:15 --> Loader Class Initialized
INFO - 2018-04-19 11:28:15 --> Helper loaded: url_helper
INFO - 2018-04-19 11:28:15 --> Helper loaded: notification_helper
INFO - 2018-04-19 05:58:15 --> Language Class Initialized
INFO - 2018-04-19 05:58:15 --> Config Class Initialized
INFO - 2018-04-19 05:58:15 --> Loader Class Initialized
INFO - 2018-04-19 11:28:15 --> Helper loaded: settings_helper
INFO - 2018-04-19 11:28:15 --> Helper loaded: permission_helper
INFO - 2018-04-19 11:28:15 --> Helper loaded: users_helper
INFO - 2018-04-19 11:28:15 --> Helper loaded: url_helper
INFO - 2018-04-19 11:28:15 --> Helper loaded: notification_helper
INFO - 2018-04-19 11:28:15 --> Helper loaded: settings_helper
INFO - 2018-04-19 11:28:15 --> Helper loaded: permission_helper
INFO - 2018-04-19 11:28:15 --> Helper loaded: users_helper
INFO - 2018-04-19 05:58:15 --> Config Class Initialized
INFO - 2018-04-19 05:58:15 --> Hooks Class Initialized
DEBUG - 2018-04-19 05:58:15 --> UTF-8 Support Enabled
INFO - 2018-04-19 05:58:15 --> Utf8 Class Initialized
INFO - 2018-04-19 05:58:15 --> URI Class Initialized
INFO - 2018-04-19 11:28:15 --> Database Driver Class Initialized
INFO - 2018-04-19 05:58:15 --> Config Class Initialized
INFO - 2018-04-19 05:58:15 --> Hooks Class Initialized
INFO - 2018-04-19 05:58:15 --> Router Class Initialized
INFO - 2018-04-19 11:28:15 --> Database Driver Class Initialized
DEBUG - 2018-04-19 11:28:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 11:28:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-04-19 05:58:15 --> UTF-8 Support Enabled
INFO - 2018-04-19 05:58:15 --> Utf8 Class Initialized
INFO - 2018-04-19 05:58:15 --> Output Class Initialized
INFO - 2018-04-19 05:58:15 --> URI Class Initialized
INFO - 2018-04-19 05:58:15 --> Config Class Initialized
INFO - 2018-04-19 05:58:15 --> Security Class Initialized
INFO - 2018-04-19 05:58:15 --> Hooks Class Initialized
DEBUG - 2018-04-19 05:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 05:58:15 --> Input Class Initialized
INFO - 2018-04-19 05:58:15 --> Language Class Initialized
INFO - 2018-04-19 11:28:15 --> Helper loaded: form_helper
INFO - 2018-04-19 11:28:15 --> Form Validation Class Initialized
INFO - 2018-04-19 11:28:15 --> Controller Class Initialized
DEBUG - 2018-04-19 05:58:15 --> UTF-8 Support Enabled
INFO - 2018-04-19 05:58:15 --> Utf8 Class Initialized
INFO - 2018-04-19 05:58:15 --> Router Class Initialized
INFO - 2018-04-19 05:58:15 --> URI Class Initialized
INFO - 2018-04-19 05:58:15 --> Output Class Initialized
INFO - 2018-04-19 05:58:15 --> Router Class Initialized
INFO - 2018-04-19 05:58:15 --> Security Class Initialized
INFO - 2018-04-19 11:28:15 --> Model Class Initialized
INFO - 2018-04-19 05:58:15 --> Output Class Initialized
INFO - 2018-04-19 11:28:15 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 11:28:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-04-19 05:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 05:58:15 --> Input Class Initialized
INFO - 2018-04-19 05:58:15 --> Security Class Initialized
DEBUG - 2018-04-19 11:28:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 05:58:15 --> Language Class Initialized
INFO - 2018-04-19 11:28:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 11:28:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-04-19 05:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 05:58:15 --> Input Class Initialized
INFO - 2018-04-19 11:28:15 --> Model Class Initialized
INFO - 2018-04-19 11:28:15 --> Model Class Initialized
INFO - 2018-04-19 05:58:15 --> Language Class Initialized
INFO - 2018-04-19 11:28:15 --> Model Class Initialized
INFO - 2018-04-19 11:28:15 --> Model Class Initialized
INFO - 2018-04-19 11:28:15 --> Model Class Initialized
INFO - 2018-04-19 11:28:15 --> Model Class Initialized
INFO - 2018-04-19 05:58:15 --> Language Class Initialized
INFO - 2018-04-19 05:58:15 --> Config Class Initialized
INFO - 2018-04-19 11:28:15 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 05:58:15 --> Loader Class Initialized
INFO - 2018-04-19 11:28:15 --> Helper loaded: url_helper
INFO - 2018-04-19 11:28:15 --> Final output sent to browser
DEBUG - 2018-04-19 11:28:15 --> Total execution time: 0.1121
INFO - 2018-04-19 11:28:15 --> Helper loaded: notification_helper
INFO - 2018-04-19 11:28:15 --> Helper loaded: settings_helper
INFO - 2018-04-19 11:28:15 --> Helper loaded: permission_helper
INFO - 2018-04-19 11:28:15 --> Helper loaded: users_helper
INFO - 2018-04-19 05:58:15 --> Config Class Initialized
INFO - 2018-04-19 05:58:15 --> Hooks Class Initialized
DEBUG - 2018-04-19 05:58:15 --> UTF-8 Support Enabled
INFO - 2018-04-19 05:58:15 --> Utf8 Class Initialized
INFO - 2018-04-19 05:58:15 --> URI Class Initialized
INFO - 2018-04-19 05:58:15 --> Language Class Initialized
INFO - 2018-04-19 05:58:15 --> Config Class Initialized
INFO - 2018-04-19 05:58:15 --> Loader Class Initialized
INFO - 2018-04-19 11:28:15 --> Database Driver Class Initialized
INFO - 2018-04-19 11:28:15 --> Helper loaded: url_helper
INFO - 2018-04-19 05:58:15 --> Router Class Initialized
INFO - 2018-04-19 05:58:15 --> Config Class Initialized
INFO - 2018-04-19 05:58:15 --> Hooks Class Initialized
INFO - 2018-04-19 05:58:15 --> Language Class Initialized
INFO - 2018-04-19 05:58:15 --> Config Class Initialized
INFO - 2018-04-19 05:58:15 --> Loader Class Initialized
INFO - 2018-04-19 11:28:15 --> Helper loaded: notification_helper
INFO - 2018-04-19 11:28:15 --> Helper loaded: settings_helper
INFO - 2018-04-19 11:28:15 --> Helper loaded: permission_helper
DEBUG - 2018-04-19 11:28:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 05:58:15 --> Config Class Initialized
INFO - 2018-04-19 05:58:15 --> Hooks Class Initialized
INFO - 2018-04-19 11:28:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 11:28:15 --> Helper loaded: users_helper
INFO - 2018-04-19 05:58:15 --> Output Class Initialized
DEBUG - 2018-04-19 05:58:15 --> UTF-8 Support Enabled
INFO - 2018-04-19 05:58:15 --> Utf8 Class Initialized
INFO - 2018-04-19 11:28:15 --> Helper loaded: url_helper
INFO - 2018-04-19 11:28:15 --> Helper loaded: notification_helper
INFO - 2018-04-19 05:58:15 --> URI Class Initialized
INFO - 2018-04-19 11:28:15 --> Helper loaded: settings_helper
INFO - 2018-04-19 11:28:15 --> Helper loaded: form_helper
DEBUG - 2018-04-19 05:58:15 --> UTF-8 Support Enabled
INFO - 2018-04-19 05:58:15 --> Utf8 Class Initialized
INFO - 2018-04-19 11:28:15 --> Form Validation Class Initialized
INFO - 2018-04-19 05:58:15 --> Security Class Initialized
INFO - 2018-04-19 11:28:15 --> Controller Class Initialized
INFO - 2018-04-19 11:28:15 --> Helper loaded: permission_helper
INFO - 2018-04-19 11:28:15 --> Helper loaded: users_helper
INFO - 2018-04-19 05:58:15 --> URI Class Initialized
DEBUG - 2018-04-19 05:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 05:58:15 --> Input Class Initialized
INFO - 2018-04-19 05:58:15 --> Router Class Initialized
INFO - 2018-04-19 11:28:15 --> Helper loaded: form_helper
INFO - 2018-04-19 11:28:15 --> Form Validation Class Initialized
INFO - 2018-04-19 11:28:15 --> Controller Class Initialized
INFO - 2018-04-19 05:58:15 --> Language Class Initialized
INFO - 2018-04-19 05:58:15 --> Output Class Initialized
INFO - 2018-04-19 05:58:15 --> Router Class Initialized
INFO - 2018-04-19 05:58:15 --> Security Class Initialized
INFO - 2018-04-19 11:28:15 --> Model Class Initialized
INFO - 2018-04-19 11:28:15 --> Helper loaded: inflector_helper
INFO - 2018-04-19 05:58:15 --> Output Class Initialized
DEBUG - 2018-04-19 05:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 05:58:15 --> Input Class Initialized
INFO - 2018-04-19 05:58:15 --> Language Class Initialized
INFO - 2018-04-19 11:28:15 --> Model Class Initialized
INFO - 2018-04-19 11:28:15 --> Helper loaded: inflector_helper
INFO - 2018-04-19 11:28:15 --> Database Driver Class Initialized
INFO - 2018-04-19 05:58:15 --> Security Class Initialized
DEBUG - 2018-04-19 11:28:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 11:28:15 --> Language file loaded: language/english/rest_controller_lang.php
DEBUG - 2018-04-19 05:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 05:58:15 --> Input Class Initialized
DEBUG - 2018-04-19 11:28:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 11:28:15 --> Model Class Initialized
INFO - 2018-04-19 11:28:15 --> Model Class Initialized
INFO - 2018-04-19 05:58:15 --> Language Class Initialized
INFO - 2018-04-19 11:28:15 --> Model Class Initialized
INFO - 2018-04-19 11:28:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 11:28:15 --> Model Class Initialized
INFO - 2018-04-19 11:28:15 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 11:28:15 --> Model Class Initialized
INFO - 2018-04-19 11:28:15 --> Model Class Initialized
INFO - 2018-04-19 11:28:15 --> Database Driver Class Initialized
INFO - 2018-04-19 11:28:15 --> Model Class Initialized
INFO - 2018-04-19 11:28:15 --> Model Class Initialized
INFO - 2018-04-19 11:28:15 --> Model Class Initialized
INFO - 2018-04-19 11:28:15 --> Model Class Initialized
INFO - 2018-04-19 11:28:15 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 11:28:15 --> Final output sent to browser
DEBUG - 2018-04-19 11:28:15 --> Total execution time: 0.1507
INFO - 2018-04-19 11:28:15 --> Final output sent to browser
DEBUG - 2018-04-19 11:28:15 --> Total execution time: 0.1062
INFO - 2018-04-19 05:58:15 --> Language Class Initialized
INFO - 2018-04-19 05:58:15 --> Config Class Initialized
INFO - 2018-04-19 05:58:15 --> Loader Class Initialized
DEBUG - 2018-04-19 11:28:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 11:28:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 05:58:15 --> Language Class Initialized
INFO - 2018-04-19 05:58:15 --> Config Class Initialized
INFO - 2018-04-19 05:58:15 --> Loader Class Initialized
INFO - 2018-04-19 11:28:15 --> Helper loaded: url_helper
INFO - 2018-04-19 11:28:15 --> Helper loaded: url_helper
INFO - 2018-04-19 11:28:15 --> Helper loaded: notification_helper
INFO - 2018-04-19 11:28:15 --> Helper loaded: settings_helper
INFO - 2018-04-19 11:28:15 --> Helper loaded: notification_helper
DEBUG - 2018-04-19 11:28:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 11:28:15 --> Helper loaded: settings_helper
INFO - 2018-04-19 11:28:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 11:28:15 --> Helper loaded: permission_helper
INFO - 2018-04-19 11:28:15 --> Helper loaded: permission_helper
INFO - 2018-04-19 11:28:15 --> Helper loaded: users_helper
INFO - 2018-04-19 11:28:15 --> Helper loaded: users_helper
INFO - 2018-04-19 11:28:15 --> Helper loaded: form_helper
INFO - 2018-04-19 11:28:15 --> Form Validation Class Initialized
INFO - 2018-04-19 11:28:15 --> Controller Class Initialized
INFO - 2018-04-19 05:58:15 --> Language Class Initialized
INFO - 2018-04-19 05:58:15 --> Config Class Initialized
INFO - 2018-04-19 05:58:15 --> Loader Class Initialized
INFO - 2018-04-19 11:28:15 --> Helper loaded: url_helper
INFO - 2018-04-19 11:28:15 --> Helper loaded: notification_helper
INFO - 2018-04-19 11:28:15 --> Helper loaded: settings_helper
INFO - 2018-04-19 11:28:15 --> Helper loaded: permission_helper
INFO - 2018-04-19 11:28:15 --> Helper loaded: users_helper
INFO - 2018-04-19 11:28:15 --> Model Class Initialized
INFO - 2018-04-19 11:28:15 --> Helper loaded: form_helper
INFO - 2018-04-19 11:28:15 --> Form Validation Class Initialized
INFO - 2018-04-19 11:28:15 --> Controller Class Initialized
INFO - 2018-04-19 11:28:15 --> Helper loaded: inflector_helper
INFO - 2018-04-19 11:28:15 --> Database Driver Class Initialized
INFO - 2018-04-19 11:28:15 --> Database Driver Class Initialized
DEBUG - 2018-04-19 11:28:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 11:28:15 --> Language file loaded: language/english/rest_controller_lang.php
DEBUG - 2018-04-19 11:28:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 11:28:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 11:28:15 --> Model Class Initialized
INFO - 2018-04-19 11:28:15 --> Model Class Initialized
INFO - 2018-04-19 11:28:15 --> Model Class Initialized
INFO - 2018-04-19 11:28:15 --> Model Class Initialized
INFO - 2018-04-19 11:28:15 --> Model Class Initialized
INFO - 2018-04-19 11:28:15 --> Model Class Initialized
INFO - 2018-04-19 11:28:15 --> Model Class Initialized
INFO - 2018-04-19 11:28:15 --> Model Class Initialized
INFO - 2018-04-19 11:28:15 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 11:28:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 11:28:15 --> Model Class Initialized
INFO - 2018-04-19 11:28:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 11:28:15 --> Model Class Initialized
INFO - 2018-04-19 11:28:15 --> Model Class Initialized
INFO - 2018-04-19 11:28:15 --> Database Driver Class Initialized
INFO - 2018-04-19 11:28:15 --> Helper loaded: form_helper
INFO - 2018-04-19 11:28:15 --> Form Validation Class Initialized
DEBUG - 2018-04-19 11:28:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 11:28:15 --> Controller Class Initialized
INFO - 2018-04-19 11:28:15 --> Model Class Initialized
INFO - 2018-04-19 11:28:15 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 11:28:15 --> Model Class Initialized
INFO - 2018-04-19 11:28:15 --> Language file loaded: language/english/rest_controller_lang.php
DEBUG - 2018-04-19 11:28:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 11:28:15 --> Model Class Initialized
INFO - 2018-04-19 11:28:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 11:28:15 --> Model Class Initialized
INFO - 2018-04-19 11:28:15 --> Model Class Initialized
INFO - 2018-04-19 11:28:15 --> Model Class Initialized
INFO - 2018-04-19 11:28:15 --> Helper loaded: form_helper
INFO - 2018-04-19 11:28:15 --> Form Validation Class Initialized
INFO - 2018-04-19 11:28:15 --> Controller Class Initialized
INFO - 2018-04-19 11:28:15 --> Model Class Initialized
INFO - 2018-04-19 11:28:15 --> Model Class Initialized
INFO - 2018-04-19 11:28:15 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 11:28:15 --> Model Class Initialized
INFO - 2018-04-19 11:28:15 --> Model Class Initialized
INFO - 2018-04-19 11:28:15 --> Helper loaded: inflector_helper
INFO - 2018-04-19 11:28:15 --> Final output sent to browser
DEBUG - 2018-04-19 11:28:15 --> Total execution time: 0.1476
INFO - 2018-04-19 11:28:15 --> Helper loaded: form_helper
INFO - 2018-04-19 11:28:15 --> Form Validation Class Initialized
INFO - 2018-04-19 11:28:15 --> Controller Class Initialized
DEBUG - 2018-04-19 11:28:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 11:28:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 11:28:15 --> Model Class Initialized
INFO - 2018-04-19 11:28:15 --> Helper loaded: inflector_helper
INFO - 2018-04-19 11:28:15 --> Model Class Initialized
INFO - 2018-04-19 11:28:15 --> Model Class Initialized
INFO - 2018-04-19 11:28:15 --> Model Class Initialized
INFO - 2018-04-19 11:28:15 --> Model Class Initialized
INFO - 2018-04-19 11:28:15 --> Model Class Initialized
INFO - 2018-04-19 11:28:16 --> Model Class Initialized
DEBUG - 2018-04-19 11:28:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 11:28:16 --> Model Class Initialized
INFO - 2018-04-19 11:28:16 --> Model Class Initialized
INFO - 2018-04-19 11:28:16 --> Model Class Initialized
INFO - 2018-04-19 11:28:16 --> Final output sent to browser
DEBUG - 2018-04-19 11:28:16 --> Total execution time: 0.1481
INFO - 2018-04-19 11:28:16 --> Model Class Initialized
INFO - 2018-04-19 11:28:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 11:28:16 --> Model Class Initialized
INFO - 2018-04-19 11:28:16 --> Model Class Initialized
INFO - 2018-04-19 11:28:16 --> Model Class Initialized
INFO - 2018-04-19 11:28:16 --> Model Class Initialized
INFO - 2018-04-19 11:28:16 --> Helper loaded: inflector_helper
INFO - 2018-04-19 11:28:16 --> Model Class Initialized
INFO - 2018-04-19 11:28:16 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 11:28:16 --> Model Class Initialized
INFO - 2018-04-19 11:28:16 --> Model Class Initialized
INFO - 2018-04-19 11:28:16 --> Model Class Initialized
INFO - 2018-04-19 11:28:16 --> Model Class Initialized
INFO - 2018-04-19 11:28:16 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-04-19 11:28:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 11:28:16 --> Model Class Initialized
INFO - 2018-04-19 11:28:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 11:28:16 --> Final output sent to browser
DEBUG - 2018-04-19 11:28:16 --> Total execution time: 0.1230
INFO - 2018-04-19 11:28:16 --> Model Class Initialized
INFO - 2018-04-19 11:28:16 --> Model Class Initialized
INFO - 2018-04-19 11:28:16 --> Model Class Initialized
INFO - 2018-04-19 11:28:16 --> Model Class Initialized
INFO - 2018-04-19 11:28:16 --> Model Class Initialized
INFO - 2018-04-19 11:28:16 --> Model Class Initialized
INFO - 2018-04-19 11:28:16 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 11:28:16 --> Final output sent to browser
DEBUG - 2018-04-19 11:28:16 --> Total execution time: 0.1121
INFO - 2018-04-19 11:28:16 --> Final output sent to browser
DEBUG - 2018-04-19 11:28:16 --> Total execution time: 0.1212
INFO - 2018-04-19 05:58:16 --> Config Class Initialized
INFO - 2018-04-19 05:58:16 --> Hooks Class Initialized
DEBUG - 2018-04-19 05:58:16 --> UTF-8 Support Enabled
INFO - 2018-04-19 05:58:16 --> Utf8 Class Initialized
INFO - 2018-04-19 05:58:16 --> URI Class Initialized
INFO - 2018-04-19 05:58:16 --> Router Class Initialized
INFO - 2018-04-19 05:58:16 --> Output Class Initialized
INFO - 2018-04-19 05:58:16 --> Security Class Initialized
DEBUG - 2018-04-19 05:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 05:58:16 --> Input Class Initialized
INFO - 2018-04-19 05:58:16 --> Language Class Initialized
INFO - 2018-04-19 05:58:16 --> Language Class Initialized
INFO - 2018-04-19 05:58:16 --> Config Class Initialized
INFO - 2018-04-19 05:58:16 --> Loader Class Initialized
INFO - 2018-04-19 11:28:16 --> Helper loaded: url_helper
INFO - 2018-04-19 11:28:16 --> Helper loaded: notification_helper
INFO - 2018-04-19 11:28:16 --> Helper loaded: settings_helper
INFO - 2018-04-19 11:28:16 --> Helper loaded: permission_helper
INFO - 2018-04-19 11:28:16 --> Helper loaded: users_helper
INFO - 2018-04-19 11:28:16 --> Database Driver Class Initialized
DEBUG - 2018-04-19 11:28:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 11:28:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 11:28:16 --> Helper loaded: form_helper
INFO - 2018-04-19 11:28:16 --> Form Validation Class Initialized
INFO - 2018-04-19 11:28:16 --> Controller Class Initialized
INFO - 2018-04-19 05:58:16 --> Config Class Initialized
INFO - 2018-04-19 05:58:16 --> Hooks Class Initialized
DEBUG - 2018-04-19 05:58:16 --> UTF-8 Support Enabled
INFO - 2018-04-19 05:58:16 --> Utf8 Class Initialized
INFO - 2018-04-19 11:28:16 --> Model Class Initialized
INFO - 2018-04-19 05:58:16 --> URI Class Initialized
INFO - 2018-04-19 11:28:16 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 11:28:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 05:58:16 --> Router Class Initialized
INFO - 2018-04-19 11:28:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 05:58:16 --> Output Class Initialized
INFO - 2018-04-19 11:28:16 --> Model Class Initialized
INFO - 2018-04-19 11:28:16 --> Model Class Initialized
INFO - 2018-04-19 11:28:16 --> Model Class Initialized
INFO - 2018-04-19 11:28:16 --> Model Class Initialized
INFO - 2018-04-19 05:58:16 --> Security Class Initialized
INFO - 2018-04-19 11:28:16 --> Model Class Initialized
INFO - 2018-04-19 11:28:16 --> Model Class Initialized
INFO - 2018-04-19 11:28:16 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-04-19 05:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 05:58:16 --> Input Class Initialized
INFO - 2018-04-19 05:58:16 --> Language Class Initialized
INFO - 2018-04-19 11:28:16 --> Final output sent to browser
DEBUG - 2018-04-19 11:28:16 --> Total execution time: 0.1149
INFO - 2018-04-19 05:58:16 --> Language Class Initialized
INFO - 2018-04-19 05:58:16 --> Config Class Initialized
INFO - 2018-04-19 05:58:16 --> Loader Class Initialized
INFO - 2018-04-19 11:28:16 --> Helper loaded: url_helper
INFO - 2018-04-19 11:28:16 --> Helper loaded: notification_helper
INFO - 2018-04-19 11:28:16 --> Helper loaded: settings_helper
INFO - 2018-04-19 11:28:16 --> Helper loaded: permission_helper
INFO - 2018-04-19 11:28:16 --> Helper loaded: users_helper
INFO - 2018-04-19 11:28:16 --> Database Driver Class Initialized
DEBUG - 2018-04-19 11:28:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 11:28:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 11:28:16 --> Helper loaded: form_helper
INFO - 2018-04-19 11:28:16 --> Form Validation Class Initialized
INFO - 2018-04-19 11:28:16 --> Controller Class Initialized
INFO - 2018-04-19 11:28:16 --> Model Class Initialized
INFO - 2018-04-19 11:28:16 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 11:28:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 11:28:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 11:28:16 --> Model Class Initialized
INFO - 2018-04-19 11:28:16 --> Model Class Initialized
INFO - 2018-04-19 11:28:16 --> Model Class Initialized
INFO - 2018-04-19 11:28:16 --> Model Class Initialized
INFO - 2018-04-19 11:28:16 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 11:28:16 --> Final output sent to browser
DEBUG - 2018-04-19 11:28:16 --> Total execution time: 0.1013
INFO - 2018-04-19 05:58:18 --> Config Class Initialized
INFO - 2018-04-19 05:58:18 --> Hooks Class Initialized
DEBUG - 2018-04-19 05:58:18 --> UTF-8 Support Enabled
INFO - 2018-04-19 05:58:18 --> Utf8 Class Initialized
INFO - 2018-04-19 05:58:18 --> URI Class Initialized
INFO - 2018-04-19 05:58:18 --> Router Class Initialized
INFO - 2018-04-19 05:58:18 --> Output Class Initialized
INFO - 2018-04-19 05:58:18 --> Security Class Initialized
DEBUG - 2018-04-19 05:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 05:58:18 --> Input Class Initialized
INFO - 2018-04-19 05:58:18 --> Language Class Initialized
INFO - 2018-04-19 05:58:18 --> Language Class Initialized
INFO - 2018-04-19 05:58:18 --> Config Class Initialized
INFO - 2018-04-19 05:58:18 --> Loader Class Initialized
INFO - 2018-04-19 11:28:18 --> Helper loaded: url_helper
INFO - 2018-04-19 05:58:18 --> Config Class Initialized
INFO - 2018-04-19 05:58:18 --> Hooks Class Initialized
INFO - 2018-04-19 11:28:18 --> Helper loaded: notification_helper
INFO - 2018-04-19 11:28:18 --> Helper loaded: settings_helper
INFO - 2018-04-19 11:28:18 --> Helper loaded: permission_helper
DEBUG - 2018-04-19 05:58:18 --> UTF-8 Support Enabled
INFO - 2018-04-19 05:58:18 --> Utf8 Class Initialized
INFO - 2018-04-19 11:28:18 --> Helper loaded: users_helper
INFO - 2018-04-19 05:58:18 --> URI Class Initialized
INFO - 2018-04-19 05:58:18 --> Router Class Initialized
INFO - 2018-04-19 05:58:18 --> Output Class Initialized
INFO - 2018-04-19 05:58:18 --> Security Class Initialized
DEBUG - 2018-04-19 05:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 05:58:18 --> Input Class Initialized
INFO - 2018-04-19 05:58:18 --> Language Class Initialized
INFO - 2018-04-19 11:28:18 --> Database Driver Class Initialized
DEBUG - 2018-04-19 11:28:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 11:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 11:28:18 --> Helper loaded: form_helper
INFO - 2018-04-19 11:28:18 --> Form Validation Class Initialized
INFO - 2018-04-19 11:28:18 --> Controller Class Initialized
INFO - 2018-04-19 05:58:18 --> Language Class Initialized
INFO - 2018-04-19 05:58:18 --> Config Class Initialized
INFO - 2018-04-19 05:58:18 --> Loader Class Initialized
INFO - 2018-04-19 11:28:18 --> Helper loaded: url_helper
INFO - 2018-04-19 11:28:18 --> Model Class Initialized
INFO - 2018-04-19 11:28:18 --> Helper loaded: notification_helper
INFO - 2018-04-19 11:28:18 --> Helper loaded: inflector_helper
INFO - 2018-04-19 11:28:18 --> Helper loaded: settings_helper
INFO - 2018-04-19 11:28:18 --> Helper loaded: permission_helper
INFO - 2018-04-19 11:28:18 --> Helper loaded: users_helper
DEBUG - 2018-04-19 11:28:18 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 11:28:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 11:28:18 --> Model Class Initialized
INFO - 2018-04-19 11:28:18 --> Model Class Initialized
INFO - 2018-04-19 11:28:18 --> Model Class Initialized
INFO - 2018-04-19 11:28:18 --> Model Class Initialized
INFO - 2018-04-19 11:28:18 --> Model Class Initialized
INFO - 2018-04-19 11:28:18 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 11:28:18 --> Model Class Initialized
INFO - 2018-04-19 11:28:18 --> Final output sent to browser
DEBUG - 2018-04-19 11:28:18 --> Total execution time: 0.1085
INFO - 2018-04-19 11:28:18 --> Database Driver Class Initialized
DEBUG - 2018-04-19 11:28:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 11:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 11:28:18 --> Helper loaded: form_helper
INFO - 2018-04-19 11:28:18 --> Form Validation Class Initialized
INFO - 2018-04-19 11:28:18 --> Controller Class Initialized
INFO - 2018-04-19 11:28:18 --> Model Class Initialized
INFO - 2018-04-19 11:28:18 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 11:28:18 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 11:28:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 11:28:18 --> Model Class Initialized
INFO - 2018-04-19 11:28:18 --> Model Class Initialized
INFO - 2018-04-19 11:28:18 --> Model Class Initialized
INFO - 2018-04-19 11:28:18 --> Model Class Initialized
INFO - 2018-04-19 11:28:18 --> Model Class Initialized
INFO - 2018-04-19 11:28:18 --> Model Class Initialized
INFO - 2018-04-19 11:28:18 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 11:28:18 --> Final output sent to browser
DEBUG - 2018-04-19 11:28:18 --> Total execution time: 0.1108
INFO - 2018-04-19 06:05:05 --> Config Class Initialized
INFO - 2018-04-19 06:05:05 --> Hooks Class Initialized
INFO - 2018-04-19 06:05:05 --> Config Class Initialized
DEBUG - 2018-04-19 06:05:05 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:05:05 --> Hooks Class Initialized
INFO - 2018-04-19 06:05:05 --> Utf8 Class Initialized
INFO - 2018-04-19 06:05:05 --> URI Class Initialized
DEBUG - 2018-04-19 06:05:05 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:05:05 --> Utf8 Class Initialized
INFO - 2018-04-19 06:05:05 --> URI Class Initialized
INFO - 2018-04-19 06:05:05 --> Router Class Initialized
INFO - 2018-04-19 06:05:05 --> Output Class Initialized
INFO - 2018-04-19 06:05:05 --> Router Class Initialized
INFO - 2018-04-19 06:05:05 --> Security Class Initialized
INFO - 2018-04-19 06:05:05 --> Output Class Initialized
DEBUG - 2018-04-19 06:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:05:05 --> Input Class Initialized
INFO - 2018-04-19 06:05:05 --> Language Class Initialized
INFO - 2018-04-19 06:05:05 --> Security Class Initialized
INFO - 2018-04-19 06:05:05 --> Config Class Initialized
DEBUG - 2018-04-19 06:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:05:05 --> Input Class Initialized
INFO - 2018-04-19 06:05:05 --> Hooks Class Initialized
INFO - 2018-04-19 06:05:05 --> Language Class Initialized
DEBUG - 2018-04-19 06:05:05 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:05:05 --> Utf8 Class Initialized
INFO - 2018-04-19 06:05:05 --> URI Class Initialized
INFO - 2018-04-19 06:05:05 --> Router Class Initialized
INFO - 2018-04-19 06:05:05 --> Output Class Initialized
INFO - 2018-04-19 06:05:05 --> Language Class Initialized
INFO - 2018-04-19 06:05:05 --> Config Class Initialized
INFO - 2018-04-19 06:05:05 --> Loader Class Initialized
INFO - 2018-04-19 11:35:05 --> Helper loaded: url_helper
INFO - 2018-04-19 11:35:05 --> Helper loaded: notification_helper
INFO - 2018-04-19 11:35:05 --> Helper loaded: settings_helper
INFO - 2018-04-19 11:35:05 --> Helper loaded: permission_helper
INFO - 2018-04-19 06:05:05 --> Security Class Initialized
INFO - 2018-04-19 06:05:05 --> Config Class Initialized
INFO - 2018-04-19 06:05:05 --> Hooks Class Initialized
INFO - 2018-04-19 11:35:05 --> Helper loaded: users_helper
DEBUG - 2018-04-19 06:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:05:05 --> Input Class Initialized
INFO - 2018-04-19 06:05:05 --> Config Class Initialized
INFO - 2018-04-19 06:05:05 --> Hooks Class Initialized
DEBUG - 2018-04-19 06:05:05 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:05:05 --> Language Class Initialized
INFO - 2018-04-19 06:05:05 --> Utf8 Class Initialized
INFO - 2018-04-19 06:05:05 --> Config Class Initialized
INFO - 2018-04-19 06:05:05 --> Hooks Class Initialized
INFO - 2018-04-19 06:05:05 --> URI Class Initialized
DEBUG - 2018-04-19 06:05:05 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:05:05 --> Utf8 Class Initialized
INFO - 2018-04-19 06:05:05 --> URI Class Initialized
DEBUG - 2018-04-19 06:05:05 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:05:05 --> Utf8 Class Initialized
INFO - 2018-04-19 06:05:05 --> Router Class Initialized
INFO - 2018-04-19 06:05:05 --> URI Class Initialized
INFO - 2018-04-19 06:05:05 --> Router Class Initialized
INFO - 2018-04-19 06:05:05 --> Language Class Initialized
INFO - 2018-04-19 06:05:05 --> Config Class Initialized
INFO - 2018-04-19 06:05:05 --> Loader Class Initialized
INFO - 2018-04-19 06:05:05 --> Output Class Initialized
INFO - 2018-04-19 11:35:05 --> Helper loaded: url_helper
INFO - 2018-04-19 11:35:05 --> Database Driver Class Initialized
INFO - 2018-04-19 06:05:05 --> Output Class Initialized
INFO - 2018-04-19 11:35:05 --> Helper loaded: notification_helper
INFO - 2018-04-19 11:35:05 --> Helper loaded: settings_helper
INFO - 2018-04-19 06:05:05 --> Router Class Initialized
INFO - 2018-04-19 06:05:05 --> Security Class Initialized
INFO - 2018-04-19 11:35:05 --> Helper loaded: permission_helper
INFO - 2018-04-19 11:35:05 --> Helper loaded: users_helper
INFO - 2018-04-19 06:05:05 --> Security Class Initialized
INFO - 2018-04-19 06:05:05 --> Config Class Initialized
INFO - 2018-04-19 06:05:05 --> Hooks Class Initialized
DEBUG - 2018-04-19 06:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:05:05 --> Input Class Initialized
INFO - 2018-04-19 06:05:05 --> Output Class Initialized
DEBUG - 2018-04-19 11:35:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 06:05:05 --> Language Class Initialized
INFO - 2018-04-19 11:35:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-04-19 06:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:05:05 --> Input Class Initialized
INFO - 2018-04-19 06:05:05 --> Language Class Initialized
DEBUG - 2018-04-19 06:05:05 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:05:05 --> Utf8 Class Initialized
INFO - 2018-04-19 06:05:05 --> Security Class Initialized
INFO - 2018-04-19 06:05:05 --> URI Class Initialized
INFO - 2018-04-19 06:05:05 --> Language Class Initialized
INFO - 2018-04-19 06:05:05 --> Config Class Initialized
INFO - 2018-04-19 06:05:05 --> Loader Class Initialized
DEBUG - 2018-04-19 06:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:05:05 --> Input Class Initialized
INFO - 2018-04-19 11:35:05 --> Database Driver Class Initialized
INFO - 2018-04-19 11:35:05 --> Helper loaded: form_helper
INFO - 2018-04-19 11:35:05 --> Form Validation Class Initialized
INFO - 2018-04-19 11:35:05 --> Controller Class Initialized
INFO - 2018-04-19 06:05:05 --> Language Class Initialized
INFO - 2018-04-19 11:35:05 --> Helper loaded: url_helper
INFO - 2018-04-19 06:05:05 --> Router Class Initialized
DEBUG - 2018-04-19 11:35:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 11:35:05 --> Helper loaded: notification_helper
INFO - 2018-04-19 11:35:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 11:35:05 --> Helper loaded: settings_helper
INFO - 2018-04-19 11:35:05 --> Helper loaded: permission_helper
INFO - 2018-04-19 11:35:05 --> Helper loaded: users_helper
INFO - 2018-04-19 06:05:05 --> Output Class Initialized
INFO - 2018-04-19 06:05:05 --> Language Class Initialized
INFO - 2018-04-19 06:05:05 --> Config Class Initialized
INFO - 2018-04-19 06:05:05 --> Loader Class Initialized
INFO - 2018-04-19 11:35:05 --> Helper loaded: form_helper
INFO - 2018-04-19 11:35:05 --> Form Validation Class Initialized
INFO - 2018-04-19 11:35:05 --> Controller Class Initialized
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
INFO - 2018-04-19 11:35:05 --> Helper loaded: inflector_helper
INFO - 2018-04-19 06:05:05 --> Language Class Initialized
INFO - 2018-04-19 06:05:05 --> Config Class Initialized
INFO - 2018-04-19 06:05:05 --> Loader Class Initialized
INFO - 2018-04-19 11:35:05 --> Helper loaded: url_helper
INFO - 2018-04-19 06:05:05 --> Security Class Initialized
INFO - 2018-04-19 11:35:05 --> Helper loaded: notification_helper
INFO - 2018-04-19 11:35:05 --> Helper loaded: settings_helper
INFO - 2018-04-19 11:35:05 --> Helper loaded: permission_helper
INFO - 2018-04-19 11:35:05 --> Helper loaded: url_helper
DEBUG - 2018-04-19 06:05:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-19 11:35:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 06:05:05 --> Input Class Initialized
INFO - 2018-04-19 11:35:05 --> Helper loaded: users_helper
INFO - 2018-04-19 11:35:05 --> Helper loaded: notification_helper
INFO - 2018-04-19 06:05:05 --> Config Class Initialized
INFO - 2018-04-19 06:05:05 --> Hooks Class Initialized
INFO - 2018-04-19 11:35:05 --> Helper loaded: settings_helper
INFO - 2018-04-19 06:05:05 --> Language Class Initialized
INFO - 2018-04-19 11:35:05 --> Helper loaded: permission_helper
INFO - 2018-04-19 11:35:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 11:35:05 --> Helper loaded: users_helper
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
DEBUG - 2018-04-19 06:05:05 --> UTF-8 Support Enabled
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
INFO - 2018-04-19 06:05:05 --> Utf8 Class Initialized
INFO - 2018-04-19 11:35:05 --> Helper loaded: inflector_helper
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
INFO - 2018-04-19 11:35:05 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 06:05:05 --> URI Class Initialized
DEBUG - 2018-04-19 11:35:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 11:35:05 --> Database Driver Class Initialized
INFO - 2018-04-19 11:35:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 11:35:05 --> Final output sent to browser
DEBUG - 2018-04-19 11:35:05 --> Total execution time: 0.1021
INFO - 2018-04-19 06:05:05 --> Router Class Initialized
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
INFO - 2018-04-19 06:05:05 --> Language Class Initialized
INFO - 2018-04-19 06:05:05 --> Config Class Initialized
INFO - 2018-04-19 06:05:05 --> Loader Class Initialized
INFO - 2018-04-19 11:35:05 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 11:35:05 --> Database Driver Class Initialized
DEBUG - 2018-04-19 11:35:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 06:05:05 --> Output Class Initialized
INFO - 2018-04-19 11:35:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 11:35:05 --> Helper loaded: url_helper
INFO - 2018-04-19 11:35:05 --> Helper loaded: notification_helper
INFO - 2018-04-19 11:35:05 --> Database Driver Class Initialized
INFO - 2018-04-19 06:05:05 --> Security Class Initialized
INFO - 2018-04-19 11:35:05 --> Helper loaded: settings_helper
DEBUG - 2018-04-19 11:35:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 11:35:05 --> Helper loaded: permission_helper
INFO - 2018-04-19 11:35:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-04-19 06:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:05:05 --> Input Class Initialized
INFO - 2018-04-19 06:05:05 --> Language Class Initialized
INFO - 2018-04-19 11:35:05 --> Helper loaded: users_helper
DEBUG - 2018-04-19 11:35:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 11:35:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 11:35:05 --> Helper loaded: form_helper
INFO - 2018-04-19 11:35:05 --> Form Validation Class Initialized
INFO - 2018-04-19 11:35:05 --> Controller Class Initialized
INFO - 2018-04-19 11:35:05 --> Final output sent to browser
DEBUG - 2018-04-19 11:35:05 --> Total execution time: 0.1170
INFO - 2018-04-19 11:35:05 --> Helper loaded: form_helper
INFO - 2018-04-19 11:35:05 --> Form Validation Class Initialized
INFO - 2018-04-19 11:35:05 --> Controller Class Initialized
INFO - 2018-04-19 06:05:05 --> Language Class Initialized
INFO - 2018-04-19 06:05:05 --> Config Class Initialized
INFO - 2018-04-19 06:05:05 --> Loader Class Initialized
INFO - 2018-04-19 11:35:05 --> Helper loaded: url_helper
INFO - 2018-04-19 11:35:05 --> Helper loaded: notification_helper
INFO - 2018-04-19 11:35:05 --> Helper loaded: form_helper
INFO - 2018-04-19 11:35:05 --> Form Validation Class Initialized
INFO - 2018-04-19 11:35:05 --> Controller Class Initialized
INFO - 2018-04-19 11:35:05 --> Helper loaded: settings_helper
INFO - 2018-04-19 11:35:05 --> Helper loaded: permission_helper
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
INFO - 2018-04-19 11:35:05 --> Helper loaded: users_helper
INFO - 2018-04-19 11:35:05 --> Helper loaded: inflector_helper
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
INFO - 2018-04-19 11:35:05 --> Helper loaded: inflector_helper
INFO - 2018-04-19 11:35:05 --> Database Driver Class Initialized
INFO - 2018-04-19 06:05:05 --> Config Class Initialized
INFO - 2018-04-19 06:05:05 --> Hooks Class Initialized
DEBUG - 2018-04-19 11:35:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-04-19 11:35:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 06:05:05 --> Language Class Initialized
INFO - 2018-04-19 06:05:05 --> Config Class Initialized
INFO - 2018-04-19 06:05:05 --> Loader Class Initialized
INFO - 2018-04-19 11:35:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 11:35:05 --> Language file loaded: language/english/rest_controller_lang.php
DEBUG - 2018-04-19 06:05:05 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:05:05 --> Utf8 Class Initialized
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
INFO - 2018-04-19 11:35:05 --> Helper loaded: url_helper
INFO - 2018-04-19 06:05:05 --> URI Class Initialized
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
DEBUG - 2018-04-19 11:35:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
INFO - 2018-04-19 11:35:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 11:35:05 --> Helper loaded: notification_helper
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
INFO - 2018-04-19 11:35:05 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 11:35:05 --> Helper loaded: settings_helper
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
INFO - 2018-04-19 11:35:05 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 11:35:05 --> Helper loaded: permission_helper
INFO - 2018-04-19 11:35:05 --> Helper loaded: inflector_helper
INFO - 2018-04-19 11:35:05 --> Helper loaded: users_helper
INFO - 2018-04-19 06:05:05 --> Router Class Initialized
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
INFO - 2018-04-19 11:35:05 --> Final output sent to browser
DEBUG - 2018-04-19 11:35:05 --> Total execution time: 0.0961
DEBUG - 2018-04-19 11:35:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 11:35:05 --> Final output sent to browser
DEBUG - 2018-04-19 11:35:05 --> Total execution time: 0.1213
INFO - 2018-04-19 06:05:05 --> Output Class Initialized
INFO - 2018-04-19 11:35:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 11:35:05 --> Database Driver Class Initialized
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
INFO - 2018-04-19 11:35:05 --> Helper loaded: form_helper
INFO - 2018-04-19 11:35:05 --> Form Validation Class Initialized
INFO - 2018-04-19 11:35:05 --> Controller Class Initialized
INFO - 2018-04-19 06:05:05 --> Security Class Initialized
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
DEBUG - 2018-04-19 06:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:05:05 --> Input Class Initialized
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
INFO - 2018-04-19 06:05:05 --> Language Class Initialized
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
DEBUG - 2018-04-19 11:35:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 11:35:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
INFO - 2018-04-19 11:35:05 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
INFO - 2018-04-19 11:35:05 --> Database Driver Class Initialized
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
INFO - 2018-04-19 11:35:05 --> Helper loaded: inflector_helper
INFO - 2018-04-19 11:35:05 --> Helper loaded: form_helper
INFO - 2018-04-19 11:35:05 --> Form Validation Class Initialized
INFO - 2018-04-19 11:35:05 --> Controller Class Initialized
DEBUG - 2018-04-19 11:35:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-04-19 11:35:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 11:35:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 11:35:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
INFO - 2018-04-19 11:35:05 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 11:35:05 --> Final output sent to browser
DEBUG - 2018-04-19 11:35:05 --> Total execution time: 0.1245
INFO - 2018-04-19 06:05:05 --> Language Class Initialized
INFO - 2018-04-19 06:05:05 --> Config Class Initialized
INFO - 2018-04-19 06:05:05 --> Loader Class Initialized
INFO - 2018-04-19 11:35:05 --> Helper loaded: form_helper
INFO - 2018-04-19 11:35:05 --> Form Validation Class Initialized
INFO - 2018-04-19 11:35:05 --> Controller Class Initialized
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
INFO - 2018-04-19 11:35:05 --> Helper loaded: inflector_helper
INFO - 2018-04-19 11:35:05 --> Helper loaded: url_helper
INFO - 2018-04-19 11:35:05 --> Final output sent to browser
DEBUG - 2018-04-19 11:35:05 --> Total execution time: 0.1318
INFO - 2018-04-19 11:35:05 --> Helper loaded: notification_helper
INFO - 2018-04-19 11:35:05 --> Helper loaded: settings_helper
DEBUG - 2018-04-19 11:35:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 11:35:05 --> Helper loaded: permission_helper
INFO - 2018-04-19 11:35:05 --> Helper loaded: users_helper
INFO - 2018-04-19 11:35:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
INFO - 2018-04-19 11:35:05 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
INFO - 2018-04-19 11:35:05 --> Helper loaded: inflector_helper
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
DEBUG - 2018-04-19 11:35:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 11:35:05 --> Final output sent to browser
DEBUG - 2018-04-19 11:35:05 --> Total execution time: 0.1271
INFO - 2018-04-19 11:35:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
INFO - 2018-04-19 11:35:05 --> Database Driver Class Initialized
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
INFO - 2018-04-19 11:35:05 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
DEBUG - 2018-04-19 11:35:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 11:35:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 11:35:05 --> Helper loaded: form_helper
INFO - 2018-04-19 11:35:05 --> Form Validation Class Initialized
INFO - 2018-04-19 11:35:05 --> Controller Class Initialized
INFO - 2018-04-19 11:35:05 --> Final output sent to browser
DEBUG - 2018-04-19 11:35:05 --> Total execution time: 0.1272
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
INFO - 2018-04-19 11:35:05 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 11:35:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 11:35:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
INFO - 2018-04-19 11:35:05 --> Model Class Initialized
INFO - 2018-04-19 11:35:05 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 11:35:05 --> Final output sent to browser
DEBUG - 2018-04-19 11:35:05 --> Total execution time: 0.1023
INFO - 2018-04-19 06:05:06 --> Config Class Initialized
INFO - 2018-04-19 06:05:06 --> Hooks Class Initialized
DEBUG - 2018-04-19 06:05:06 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:05:06 --> Config Class Initialized
INFO - 2018-04-19 06:05:06 --> Utf8 Class Initialized
INFO - 2018-04-19 06:05:06 --> Hooks Class Initialized
INFO - 2018-04-19 06:05:06 --> URI Class Initialized
DEBUG - 2018-04-19 06:05:06 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:05:06 --> Utf8 Class Initialized
INFO - 2018-04-19 06:05:06 --> URI Class Initialized
INFO - 2018-04-19 06:05:06 --> Router Class Initialized
INFO - 2018-04-19 06:05:06 --> Output Class Initialized
INFO - 2018-04-19 06:05:06 --> Router Class Initialized
INFO - 2018-04-19 06:05:06 --> Security Class Initialized
INFO - 2018-04-19 06:05:06 --> Output Class Initialized
DEBUG - 2018-04-19 06:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:05:06 --> Input Class Initialized
INFO - 2018-04-19 06:05:06 --> Language Class Initialized
INFO - 2018-04-19 06:05:06 --> Security Class Initialized
DEBUG - 2018-04-19 06:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:05:06 --> Input Class Initialized
INFO - 2018-04-19 06:05:06 --> Language Class Initialized
INFO - 2018-04-19 06:05:06 --> Language Class Initialized
INFO - 2018-04-19 06:05:06 --> Config Class Initialized
INFO - 2018-04-19 06:05:06 --> Loader Class Initialized
INFO - 2018-04-19 06:05:06 --> Language Class Initialized
INFO - 2018-04-19 06:05:06 --> Config Class Initialized
INFO - 2018-04-19 06:05:06 --> Loader Class Initialized
INFO - 2018-04-19 11:35:06 --> Helper loaded: url_helper
INFO - 2018-04-19 11:35:06 --> Helper loaded: url_helper
INFO - 2018-04-19 11:35:06 --> Helper loaded: notification_helper
INFO - 2018-04-19 11:35:06 --> Helper loaded: settings_helper
INFO - 2018-04-19 11:35:06 --> Helper loaded: notification_helper
INFO - 2018-04-19 11:35:06 --> Helper loaded: settings_helper
INFO - 2018-04-19 11:35:06 --> Helper loaded: permission_helper
INFO - 2018-04-19 11:35:06 --> Helper loaded: permission_helper
INFO - 2018-04-19 11:35:06 --> Helper loaded: users_helper
INFO - 2018-04-19 11:35:06 --> Helper loaded: users_helper
INFO - 2018-04-19 11:35:06 --> Database Driver Class Initialized
INFO - 2018-04-19 11:35:06 --> Database Driver Class Initialized
DEBUG - 2018-04-19 11:35:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 11:35:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-04-19 11:35:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 11:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 11:35:06 --> Helper loaded: form_helper
INFO - 2018-04-19 11:35:06 --> Form Validation Class Initialized
INFO - 2018-04-19 11:35:06 --> Controller Class Initialized
INFO - 2018-04-19 11:35:06 --> Helper loaded: form_helper
INFO - 2018-04-19 11:35:06 --> Form Validation Class Initialized
INFO - 2018-04-19 11:35:06 --> Controller Class Initialized
INFO - 2018-04-19 11:35:06 --> Model Class Initialized
INFO - 2018-04-19 11:35:06 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 11:35:06 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 11:35:06 --> Model Class Initialized
INFO - 2018-04-19 11:35:06 --> Helper loaded: inflector_helper
INFO - 2018-04-19 11:35:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 11:35:06 --> Model Class Initialized
INFO - 2018-04-19 11:35:06 --> Model Class Initialized
INFO - 2018-04-19 11:35:06 --> Model Class Initialized
INFO - 2018-04-19 11:35:06 --> Model Class Initialized
DEBUG - 2018-04-19 11:35:06 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 11:35:06 --> Model Class Initialized
INFO - 2018-04-19 11:35:06 --> Model Class Initialized
INFO - 2018-04-19 11:35:06 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 11:35:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 11:35:06 --> Model Class Initialized
INFO - 2018-04-19 11:35:06 --> Model Class Initialized
INFO - 2018-04-19 11:35:06 --> Final output sent to browser
DEBUG - 2018-04-19 11:35:06 --> Total execution time: 0.1049
INFO - 2018-04-19 11:35:06 --> Model Class Initialized
INFO - 2018-04-19 11:35:06 --> Model Class Initialized
INFO - 2018-04-19 11:35:06 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 11:35:06 --> Final output sent to browser
DEBUG - 2018-04-19 11:35:06 --> Total execution time: 0.1080
INFO - 2018-04-19 06:05:20 --> Config Class Initialized
INFO - 2018-04-19 06:05:20 --> Hooks Class Initialized
INFO - 2018-04-19 06:05:20 --> Config Class Initialized
INFO - 2018-04-19 06:05:20 --> Hooks Class Initialized
DEBUG - 2018-04-19 06:05:20 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:05:20 --> Utf8 Class Initialized
DEBUG - 2018-04-19 06:05:20 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:05:20 --> Utf8 Class Initialized
INFO - 2018-04-19 06:05:20 --> URI Class Initialized
INFO - 2018-04-19 06:05:20 --> URI Class Initialized
INFO - 2018-04-19 06:05:20 --> Router Class Initialized
INFO - 2018-04-19 06:05:20 --> Router Class Initialized
INFO - 2018-04-19 06:05:20 --> Output Class Initialized
INFO - 2018-04-19 06:05:20 --> Output Class Initialized
INFO - 2018-04-19 06:05:20 --> Security Class Initialized
INFO - 2018-04-19 06:05:20 --> Security Class Initialized
DEBUG - 2018-04-19 06:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:05:20 --> Input Class Initialized
INFO - 2018-04-19 06:05:20 --> Language Class Initialized
DEBUG - 2018-04-19 06:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:05:20 --> Input Class Initialized
INFO - 2018-04-19 06:05:20 --> Language Class Initialized
INFO - 2018-04-19 06:05:20 --> Language Class Initialized
INFO - 2018-04-19 06:05:20 --> Config Class Initialized
INFO - 2018-04-19 06:05:20 --> Loader Class Initialized
INFO - 2018-04-19 11:35:20 --> Helper loaded: url_helper
INFO - 2018-04-19 11:35:20 --> Helper loaded: notification_helper
INFO - 2018-04-19 11:35:20 --> Helper loaded: settings_helper
INFO - 2018-04-19 11:35:20 --> Helper loaded: permission_helper
INFO - 2018-04-19 11:35:20 --> Helper loaded: users_helper
INFO - 2018-04-19 06:05:20 --> Language Class Initialized
INFO - 2018-04-19 06:05:20 --> Config Class Initialized
INFO - 2018-04-19 06:05:20 --> Loader Class Initialized
INFO - 2018-04-19 11:35:20 --> Helper loaded: url_helper
INFO - 2018-04-19 11:35:20 --> Helper loaded: notification_helper
INFO - 2018-04-19 11:35:20 --> Helper loaded: settings_helper
INFO - 2018-04-19 11:35:20 --> Helper loaded: permission_helper
INFO - 2018-04-19 11:35:20 --> Helper loaded: users_helper
INFO - 2018-04-19 11:35:20 --> Database Driver Class Initialized
DEBUG - 2018-04-19 11:35:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 11:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 11:35:20 --> Database Driver Class Initialized
INFO - 2018-04-19 11:35:20 --> Helper loaded: form_helper
INFO - 2018-04-19 11:35:20 --> Form Validation Class Initialized
INFO - 2018-04-19 11:35:20 --> Controller Class Initialized
DEBUG - 2018-04-19 11:35:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 11:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 11:35:20 --> Model Class Initialized
INFO - 2018-04-19 11:35:20 --> Helper loaded: inflector_helper
INFO - 2018-04-19 11:35:20 --> Helper loaded: form_helper
INFO - 2018-04-19 11:35:20 --> Form Validation Class Initialized
INFO - 2018-04-19 11:35:20 --> Controller Class Initialized
DEBUG - 2018-04-19 11:35:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 11:35:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 11:35:20 --> Model Class Initialized
INFO - 2018-04-19 11:35:20 --> Model Class Initialized
INFO - 2018-04-19 11:35:20 --> Model Class Initialized
INFO - 2018-04-19 11:35:20 --> Model Class Initialized
INFO - 2018-04-19 11:35:20 --> Model Class Initialized
INFO - 2018-04-19 11:35:20 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 11:35:20 --> Model Class Initialized
INFO - 2018-04-19 11:35:20 --> Model Class Initialized
INFO - 2018-04-19 11:35:20 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 11:35:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 11:35:20 --> Final output sent to browser
DEBUG - 2018-04-19 11:35:20 --> Total execution time: 0.1015
INFO - 2018-04-19 11:35:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 11:35:20 --> Model Class Initialized
INFO - 2018-04-19 11:35:20 --> Model Class Initialized
INFO - 2018-04-19 11:35:20 --> Model Class Initialized
INFO - 2018-04-19 11:35:20 --> Model Class Initialized
INFO - 2018-04-19 11:35:20 --> Model Class Initialized
INFO - 2018-04-19 11:35:20 --> Model Class Initialized
INFO - 2018-04-19 11:35:20 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 11:35:20 --> Final output sent to browser
DEBUG - 2018-04-19 11:35:20 --> Total execution time: 0.1107
INFO - 2018-04-19 06:06:35 --> Config Class Initialized
INFO - 2018-04-19 06:06:35 --> Hooks Class Initialized
INFO - 2018-04-19 06:06:35 --> Config Class Initialized
INFO - 2018-04-19 06:06:35 --> Hooks Class Initialized
DEBUG - 2018-04-19 06:06:35 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:06:35 --> Utf8 Class Initialized
DEBUG - 2018-04-19 06:06:35 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:06:35 --> Utf8 Class Initialized
INFO - 2018-04-19 06:06:35 --> Config Class Initialized
INFO - 2018-04-19 06:06:35 --> Hooks Class Initialized
INFO - 2018-04-19 06:06:35 --> URI Class Initialized
INFO - 2018-04-19 06:06:35 --> URI Class Initialized
DEBUG - 2018-04-19 06:06:35 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:06:35 --> Utf8 Class Initialized
INFO - 2018-04-19 06:06:35 --> Router Class Initialized
INFO - 2018-04-19 06:06:35 --> Router Class Initialized
INFO - 2018-04-19 06:06:35 --> URI Class Initialized
INFO - 2018-04-19 06:06:35 --> Output Class Initialized
INFO - 2018-04-19 06:06:35 --> Output Class Initialized
INFO - 2018-04-19 06:06:35 --> Router Class Initialized
INFO - 2018-04-19 06:06:35 --> Security Class Initialized
INFO - 2018-04-19 06:06:35 --> Security Class Initialized
DEBUG - 2018-04-19 06:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:06:35 --> Input Class Initialized
DEBUG - 2018-04-19 06:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:06:35 --> Input Class Initialized
INFO - 2018-04-19 06:06:35 --> Output Class Initialized
INFO - 2018-04-19 06:06:35 --> Language Class Initialized
INFO - 2018-04-19 06:06:35 --> Language Class Initialized
INFO - 2018-04-19 06:06:35 --> Security Class Initialized
INFO - 2018-04-19 06:06:35 --> Config Class Initialized
INFO - 2018-04-19 06:06:35 --> Hooks Class Initialized
INFO - 2018-04-19 06:06:35 --> Config Class Initialized
INFO - 2018-04-19 06:06:35 --> Hooks Class Initialized
DEBUG - 2018-04-19 06:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:06:35 --> Input Class Initialized
INFO - 2018-04-19 06:06:35 --> Language Class Initialized
DEBUG - 2018-04-19 06:06:35 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:06:35 --> Utf8 Class Initialized
DEBUG - 2018-04-19 06:06:35 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:06:35 --> Utf8 Class Initialized
INFO - 2018-04-19 06:06:35 --> URI Class Initialized
INFO - 2018-04-19 06:06:35 --> URI Class Initialized
INFO - 2018-04-19 06:06:35 --> Router Class Initialized
INFO - 2018-04-19 06:06:35 --> Router Class Initialized
INFO - 2018-04-19 06:06:35 --> Language Class Initialized
INFO - 2018-04-19 06:06:35 --> Config Class Initialized
INFO - 2018-04-19 06:06:35 --> Loader Class Initialized
INFO - 2018-04-19 11:36:35 --> Helper loaded: url_helper
INFO - 2018-04-19 06:06:35 --> Output Class Initialized
INFO - 2018-04-19 06:06:35 --> Output Class Initialized
INFO - 2018-04-19 11:36:35 --> Helper loaded: notification_helper
INFO - 2018-04-19 11:36:35 --> Helper loaded: settings_helper
INFO - 2018-04-19 11:36:35 --> Helper loaded: permission_helper
INFO - 2018-04-19 11:36:35 --> Helper loaded: users_helper
INFO - 2018-04-19 06:06:35 --> Security Class Initialized
INFO - 2018-04-19 06:06:35 --> Security Class Initialized
INFO - 2018-04-19 06:06:35 --> Language Class Initialized
INFO - 2018-04-19 06:06:35 --> Config Class Initialized
INFO - 2018-04-19 06:06:35 --> Loader Class Initialized
DEBUG - 2018-04-19 06:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:06:35 --> Input Class Initialized
DEBUG - 2018-04-19 06:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:06:35 --> Input Class Initialized
INFO - 2018-04-19 11:36:35 --> Helper loaded: url_helper
INFO - 2018-04-19 06:06:35 --> Language Class Initialized
INFO - 2018-04-19 06:06:35 --> Language Class Initialized
INFO - 2018-04-19 11:36:35 --> Helper loaded: notification_helper
INFO - 2018-04-19 06:06:35 --> Language Class Initialized
INFO - 2018-04-19 06:06:35 --> Config Class Initialized
INFO - 2018-04-19 06:06:35 --> Loader Class Initialized
INFO - 2018-04-19 11:36:35 --> Helper loaded: settings_helper
INFO - 2018-04-19 11:36:35 --> Helper loaded: permission_helper
INFO - 2018-04-19 11:36:35 --> Helper loaded: users_helper
INFO - 2018-04-19 11:36:35 --> Helper loaded: url_helper
INFO - 2018-04-19 11:36:35 --> Helper loaded: notification_helper
INFO - 2018-04-19 11:36:35 --> Helper loaded: settings_helper
INFO - 2018-04-19 11:36:35 --> Helper loaded: permission_helper
INFO - 2018-04-19 11:36:35 --> Helper loaded: users_helper
INFO - 2018-04-19 11:36:35 --> Database Driver Class Initialized
DEBUG - 2018-04-19 11:36:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 11:36:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 11:36:35 --> Database Driver Class Initialized
INFO - 2018-04-19 06:06:35 --> Language Class Initialized
INFO - 2018-04-19 06:06:35 --> Config Class Initialized
INFO - 2018-04-19 06:06:35 --> Loader Class Initialized
INFO - 2018-04-19 11:36:35 --> Helper loaded: form_helper
INFO - 2018-04-19 11:36:35 --> Form Validation Class Initialized
INFO - 2018-04-19 11:36:35 --> Controller Class Initialized
INFO - 2018-04-19 06:06:35 --> Language Class Initialized
INFO - 2018-04-19 06:06:35 --> Config Class Initialized
INFO - 2018-04-19 06:06:35 --> Loader Class Initialized
DEBUG - 2018-04-19 11:36:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 11:36:35 --> Database Driver Class Initialized
INFO - 2018-04-19 11:36:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 11:36:35 --> Helper loaded: url_helper
INFO - 2018-04-19 11:36:35 --> Helper loaded: notification_helper
INFO - 2018-04-19 11:36:35 --> Helper loaded: settings_helper
INFO - 2018-04-19 11:36:35 --> Helper loaded: url_helper
INFO - 2018-04-19 11:36:35 --> Helper loaded: permission_helper
INFO - 2018-04-19 11:36:35 --> Helper loaded: notification_helper
INFO - 2018-04-19 11:36:35 --> Helper loaded: users_helper
INFO - 2018-04-19 11:36:35 --> Helper loaded: settings_helper
INFO - 2018-04-19 11:36:35 --> Helper loaded: permission_helper
DEBUG - 2018-04-19 11:36:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 11:36:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 11:36:35 --> Helper loaded: users_helper
INFO - 2018-04-19 11:36:35 --> Model Class Initialized
INFO - 2018-04-19 11:36:35 --> Helper loaded: form_helper
INFO - 2018-04-19 11:36:35 --> Form Validation Class Initialized
INFO - 2018-04-19 11:36:35 --> Controller Class Initialized
INFO - 2018-04-19 11:36:35 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 11:36:35 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 11:36:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 11:36:35 --> Model Class Initialized
INFO - 2018-04-19 11:36:35 --> Model Class Initialized
INFO - 2018-04-19 11:36:35 --> Model Class Initialized
INFO - 2018-04-19 11:36:35 --> Helper loaded: form_helper
INFO - 2018-04-19 11:36:35 --> Form Validation Class Initialized
INFO - 2018-04-19 11:36:35 --> Controller Class Initialized
INFO - 2018-04-19 11:36:35 --> Model Class Initialized
INFO - 2018-04-19 11:36:35 --> Model Class Initialized
INFO - 2018-04-19 11:36:35 --> Model Class Initialized
INFO - 2018-04-19 11:36:35 --> Model Class Initialized
INFO - 2018-04-19 11:36:35 --> Model Class Initialized
INFO - 2018-04-19 11:36:35 --> Helper loaded: inflector_helper
INFO - 2018-04-19 11:36:35 --> Model Class Initialized
INFO - 2018-04-19 11:36:35 --> Model Class Initialized
INFO - 2018-04-19 11:36:35 --> Model Class Initialized
DEBUG - 2018-04-19 11:36:35 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 11:36:35 --> Model Class Initialized
INFO - 2018-04-19 11:36:35 --> Database Driver Class Initialized
INFO - 2018-04-19 11:36:35 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 11:36:35 --> Model Class Initialized
INFO - 2018-04-19 11:36:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 11:36:35 --> Database Driver Class Initialized
INFO - 2018-04-19 11:36:35 --> Model Class Initialized
INFO - 2018-04-19 11:36:35 --> Model Class Initialized
INFO - 2018-04-19 11:36:35 --> Model Class Initialized
INFO - 2018-04-19 11:36:35 --> Model Class Initialized
INFO - 2018-04-19 11:36:35 --> Model Class Initialized
INFO - 2018-04-19 11:36:35 --> Model Class Initialized
INFO - 2018-04-19 11:36:35 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 11:36:35 --> Model Class Initialized
DEBUG - 2018-04-19 11:36:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 11:36:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 11:36:35 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 11:36:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 11:36:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 11:36:35 --> Final output sent to browser
DEBUG - 2018-04-19 11:36:35 --> Total execution time: 0.1090
DEBUG - 2018-04-19 11:36:35 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 11:36:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 11:36:35 --> Model Class Initialized
INFO - 2018-04-19 11:36:35 --> Model Class Initialized
INFO - 2018-04-19 11:36:35 --> Model Class Initialized
INFO - 2018-04-19 11:36:35 --> Model Class Initialized
INFO - 2018-04-19 11:36:35 --> Model Class Initialized
INFO - 2018-04-19 11:36:35 --> Model Class Initialized
INFO - 2018-04-19 11:36:35 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 11:36:35 --> Final output sent to browser
DEBUG - 2018-04-19 11:36:35 --> Total execution time: 0.1177
INFO - 2018-04-19 11:36:35 --> Helper loaded: form_helper
INFO - 2018-04-19 11:36:35 --> Form Validation Class Initialized
INFO - 2018-04-19 11:36:35 --> Controller Class Initialized
INFO - 2018-04-19 11:36:35 --> Model Class Initialized
INFO - 2018-04-19 11:36:35 --> Helper loaded: form_helper
INFO - 2018-04-19 11:36:35 --> Form Validation Class Initialized
INFO - 2018-04-19 11:36:35 --> Controller Class Initialized
INFO - 2018-04-19 11:36:35 --> Final output sent to browser
DEBUG - 2018-04-19 11:36:35 --> Total execution time: 0.1177
INFO - 2018-04-19 11:36:35 --> Model Class Initialized
INFO - 2018-04-19 11:36:35 --> Helper loaded: inflector_helper
INFO - 2018-04-19 11:36:35 --> Model Class Initialized
INFO - 2018-04-19 11:36:35 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 11:36:35 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 11:36:35 --> Language file loaded: language/english/rest_controller_lang.php
DEBUG - 2018-04-19 11:36:35 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 11:36:35 --> Model Class Initialized
INFO - 2018-04-19 11:36:35 --> Model Class Initialized
INFO - 2018-04-19 11:36:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 11:36:35 --> Model Class Initialized
INFO - 2018-04-19 11:36:35 --> Model Class Initialized
INFO - 2018-04-19 11:36:35 --> Model Class Initialized
INFO - 2018-04-19 11:36:35 --> Model Class Initialized
INFO - 2018-04-19 11:36:35 --> Model Class Initialized
INFO - 2018-04-19 11:36:35 --> Model Class Initialized
INFO - 2018-04-19 11:36:35 --> Model Class Initialized
INFO - 2018-04-19 11:36:35 --> Model Class Initialized
INFO - 2018-04-19 11:36:35 --> Model Class Initialized
INFO - 2018-04-19 11:36:35 --> Model Class Initialized
INFO - 2018-04-19 11:36:35 --> Model Class Initialized
INFO - 2018-04-19 11:36:35 --> Model Class Initialized
INFO - 2018-04-19 11:36:35 --> Model Class Initialized
INFO - 2018-04-19 11:36:35 --> Model Class Initialized
INFO - 2018-04-19 11:36:35 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 11:36:35 --> Model Class Initialized
INFO - 2018-04-19 11:36:35 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 11:36:35 --> Model Class Initialized
INFO - 2018-04-19 11:36:35 --> Model Class Initialized
INFO - 2018-04-19 11:36:35 --> Final output sent to browser
DEBUG - 2018-04-19 11:36:35 --> Total execution time: 0.1251
INFO - 2018-04-19 11:36:35 --> Final output sent to browser
DEBUG - 2018-04-19 11:36:35 --> Total execution time: 0.1407
INFO - 2018-04-19 06:06:51 --> Config Class Initialized
INFO - 2018-04-19 06:06:51 --> Hooks Class Initialized
DEBUG - 2018-04-19 06:06:51 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:06:51 --> Utf8 Class Initialized
INFO - 2018-04-19 06:06:51 --> URI Class Initialized
INFO - 2018-04-19 06:06:51 --> Router Class Initialized
INFO - 2018-04-19 06:06:51 --> Output Class Initialized
INFO - 2018-04-19 06:06:51 --> Security Class Initialized
DEBUG - 2018-04-19 06:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:06:51 --> Input Class Initialized
INFO - 2018-04-19 06:06:51 --> Language Class Initialized
INFO - 2018-04-19 06:06:51 --> Language Class Initialized
INFO - 2018-04-19 06:06:51 --> Config Class Initialized
INFO - 2018-04-19 06:06:51 --> Loader Class Initialized
INFO - 2018-04-19 11:36:51 --> Helper loaded: url_helper
INFO - 2018-04-19 11:36:51 --> Helper loaded: notification_helper
INFO - 2018-04-19 11:36:51 --> Helper loaded: settings_helper
INFO - 2018-04-19 11:36:51 --> Helper loaded: permission_helper
INFO - 2018-04-19 11:36:51 --> Helper loaded: users_helper
INFO - 2018-04-19 06:06:51 --> Config Class Initialized
INFO - 2018-04-19 06:06:51 --> Hooks Class Initialized
DEBUG - 2018-04-19 06:06:51 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:06:51 --> Utf8 Class Initialized
INFO - 2018-04-19 06:06:51 --> URI Class Initialized
INFO - 2018-04-19 06:06:51 --> Router Class Initialized
INFO - 2018-04-19 06:06:51 --> Output Class Initialized
INFO - 2018-04-19 11:36:51 --> Database Driver Class Initialized
INFO - 2018-04-19 06:06:51 --> Security Class Initialized
DEBUG - 2018-04-19 06:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:06:51 --> Input Class Initialized
DEBUG - 2018-04-19 11:36:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 11:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 06:06:51 --> Language Class Initialized
INFO - 2018-04-19 11:36:51 --> Helper loaded: form_helper
INFO - 2018-04-19 11:36:51 --> Form Validation Class Initialized
INFO - 2018-04-19 11:36:51 --> Controller Class Initialized
INFO - 2018-04-19 06:06:51 --> Config Class Initialized
INFO - 2018-04-19 06:06:51 --> Hooks Class Initialized
DEBUG - 2018-04-19 06:06:51 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:06:51 --> Utf8 Class Initialized
INFO - 2018-04-19 11:36:51 --> Model Class Initialized
INFO - 2018-04-19 06:06:51 --> Language Class Initialized
INFO - 2018-04-19 06:06:51 --> Config Class Initialized
INFO - 2018-04-19 06:06:51 --> Loader Class Initialized
INFO - 2018-04-19 11:36:51 --> Helper loaded: inflector_helper
INFO - 2018-04-19 06:06:51 --> URI Class Initialized
INFO - 2018-04-19 11:36:51 --> Helper loaded: url_helper
DEBUG - 2018-04-19 11:36:51 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 11:36:51 --> Helper loaded: notification_helper
INFO - 2018-04-19 11:36:51 --> Helper loaded: settings_helper
INFO - 2018-04-19 06:06:51 --> Router Class Initialized
INFO - 2018-04-19 11:36:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 11:36:51 --> Helper loaded: permission_helper
INFO - 2018-04-19 11:36:51 --> Model Class Initialized
INFO - 2018-04-19 11:36:51 --> Helper loaded: users_helper
INFO - 2018-04-19 11:36:51 --> Model Class Initialized
INFO - 2018-04-19 11:36:51 --> Model Class Initialized
INFO - 2018-04-19 11:36:51 --> Model Class Initialized
INFO - 2018-04-19 11:36:51 --> Model Class Initialized
INFO - 2018-04-19 06:06:51 --> Output Class Initialized
INFO - 2018-04-19 11:36:51 --> Model Class Initialized
INFO - 2018-04-19 11:36:51 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 06:06:51 --> Security Class Initialized
INFO - 2018-04-19 11:36:51 --> Final output sent to browser
DEBUG - 2018-04-19 11:36:51 --> Total execution time: 0.1033
DEBUG - 2018-04-19 06:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:06:51 --> Input Class Initialized
INFO - 2018-04-19 06:06:51 --> Language Class Initialized
INFO - 2018-04-19 11:36:51 --> Database Driver Class Initialized
DEBUG - 2018-04-19 11:36:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 11:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 11:36:51 --> Helper loaded: form_helper
INFO - 2018-04-19 11:36:51 --> Form Validation Class Initialized
INFO - 2018-04-19 11:36:51 --> Controller Class Initialized
INFO - 2018-04-19 06:06:51 --> Language Class Initialized
INFO - 2018-04-19 06:06:51 --> Config Class Initialized
INFO - 2018-04-19 06:06:51 --> Loader Class Initialized
INFO - 2018-04-19 11:36:51 --> Model Class Initialized
INFO - 2018-04-19 11:36:51 --> Helper loaded: url_helper
INFO - 2018-04-19 11:36:51 --> Helper loaded: inflector_helper
INFO - 2018-04-19 11:36:51 --> Helper loaded: notification_helper
INFO - 2018-04-19 11:36:51 --> Helper loaded: settings_helper
INFO - 2018-04-19 11:36:51 --> Helper loaded: permission_helper
INFO - 2018-04-19 11:36:51 --> Helper loaded: users_helper
DEBUG - 2018-04-19 11:36:51 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 11:36:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 11:36:51 --> Model Class Initialized
INFO - 2018-04-19 11:36:51 --> Model Class Initialized
INFO - 2018-04-19 11:36:51 --> Model Class Initialized
INFO - 2018-04-19 11:36:51 --> Model Class Initialized
INFO - 2018-04-19 11:36:51 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 11:36:51 --> Final output sent to browser
DEBUG - 2018-04-19 11:36:51 --> Total execution time: 0.0990
INFO - 2018-04-19 11:36:51 --> Database Driver Class Initialized
DEBUG - 2018-04-19 11:36:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 11:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 11:36:51 --> Helper loaded: form_helper
INFO - 2018-04-19 11:36:51 --> Form Validation Class Initialized
INFO - 2018-04-19 11:36:51 --> Controller Class Initialized
INFO - 2018-04-19 11:36:51 --> Model Class Initialized
INFO - 2018-04-19 11:36:51 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 11:36:51 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 11:36:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 11:36:51 --> Model Class Initialized
INFO - 2018-04-19 11:36:51 --> Model Class Initialized
INFO - 2018-04-19 11:36:51 --> Model Class Initialized
INFO - 2018-04-19 11:36:51 --> Model Class Initialized
INFO - 2018-04-19 11:36:51 --> Model Class Initialized
INFO - 2018-04-19 11:36:51 --> Model Class Initialized
INFO - 2018-04-19 11:36:51 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 11:36:51 --> Final output sent to browser
DEBUG - 2018-04-19 11:36:51 --> Total execution time: 0.1058
INFO - 2018-04-19 06:06:54 --> Config Class Initialized
INFO - 2018-04-19 06:06:54 --> Hooks Class Initialized
DEBUG - 2018-04-19 06:06:54 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:06:54 --> Utf8 Class Initialized
INFO - 2018-04-19 06:06:54 --> URI Class Initialized
INFO - 2018-04-19 06:06:54 --> Router Class Initialized
INFO - 2018-04-19 06:06:54 --> Output Class Initialized
INFO - 2018-04-19 06:06:54 --> Security Class Initialized
DEBUG - 2018-04-19 06:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:06:54 --> Input Class Initialized
INFO - 2018-04-19 06:06:54 --> Language Class Initialized
INFO - 2018-04-19 06:06:54 --> Language Class Initialized
INFO - 2018-04-19 06:06:54 --> Config Class Initialized
INFO - 2018-04-19 06:06:54 --> Loader Class Initialized
INFO - 2018-04-19 11:36:54 --> Helper loaded: url_helper
INFO - 2018-04-19 11:36:54 --> Helper loaded: notification_helper
INFO - 2018-04-19 11:36:54 --> Helper loaded: settings_helper
INFO - 2018-04-19 11:36:54 --> Helper loaded: permission_helper
INFO - 2018-04-19 11:36:54 --> Helper loaded: users_helper
INFO - 2018-04-19 11:36:54 --> Database Driver Class Initialized
DEBUG - 2018-04-19 11:36:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 11:36:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 11:36:54 --> Helper loaded: form_helper
INFO - 2018-04-19 11:36:54 --> Form Validation Class Initialized
INFO - 2018-04-19 11:36:54 --> Controller Class Initialized
INFO - 2018-04-19 11:36:54 --> Model Class Initialized
INFO - 2018-04-19 11:36:54 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 11:36:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 11:36:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 11:36:54 --> Model Class Initialized
INFO - 2018-04-19 11:36:54 --> Model Class Initialized
INFO - 2018-04-19 11:36:54 --> Model Class Initialized
INFO - 2018-04-19 11:36:54 --> Model Class Initialized
INFO - 2018-04-19 11:36:54 --> Model Class Initialized
INFO - 2018-04-19 11:36:54 --> Model Class Initialized
INFO - 2018-04-19 11:36:54 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 11:36:54 --> Final output sent to browser
DEBUG - 2018-04-19 11:36:54 --> Total execution time: 0.1068
INFO - 2018-04-19 06:06:54 --> Config Class Initialized
INFO - 2018-04-19 06:06:54 --> Hooks Class Initialized
DEBUG - 2018-04-19 06:06:54 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:06:54 --> Utf8 Class Initialized
INFO - 2018-04-19 06:06:54 --> URI Class Initialized
INFO - 2018-04-19 06:06:54 --> Router Class Initialized
INFO - 2018-04-19 06:06:54 --> Output Class Initialized
INFO - 2018-04-19 06:06:54 --> Security Class Initialized
DEBUG - 2018-04-19 06:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:06:54 --> Input Class Initialized
INFO - 2018-04-19 06:06:54 --> Language Class Initialized
INFO - 2018-04-19 06:06:54 --> Language Class Initialized
INFO - 2018-04-19 06:06:54 --> Config Class Initialized
INFO - 2018-04-19 06:06:54 --> Loader Class Initialized
INFO - 2018-04-19 11:36:54 --> Helper loaded: url_helper
INFO - 2018-04-19 11:36:54 --> Helper loaded: notification_helper
INFO - 2018-04-19 11:36:54 --> Helper loaded: settings_helper
INFO - 2018-04-19 11:36:54 --> Helper loaded: permission_helper
INFO - 2018-04-19 11:36:54 --> Helper loaded: users_helper
INFO - 2018-04-19 11:36:54 --> Database Driver Class Initialized
DEBUG - 2018-04-19 11:36:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 11:36:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 11:36:54 --> Helper loaded: form_helper
INFO - 2018-04-19 11:36:54 --> Form Validation Class Initialized
INFO - 2018-04-19 11:36:54 --> Controller Class Initialized
INFO - 2018-04-19 11:36:54 --> Model Class Initialized
INFO - 2018-04-19 11:36:54 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 11:36:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 11:36:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 11:36:54 --> Model Class Initialized
INFO - 2018-04-19 11:36:54 --> Model Class Initialized
INFO - 2018-04-19 11:36:54 --> Model Class Initialized
INFO - 2018-04-19 11:36:54 --> Model Class Initialized
INFO - 2018-04-19 11:36:54 --> Model Class Initialized
INFO - 2018-04-19 11:36:54 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 11:36:54 --> Model Class Initialized
INFO - 2018-04-19 11:36:54 --> Final output sent to browser
DEBUG - 2018-04-19 11:36:54 --> Total execution time: 0.0730
INFO - 2018-04-19 06:07:23 --> Config Class Initialized
INFO - 2018-04-19 06:07:23 --> Hooks Class Initialized
DEBUG - 2018-04-19 06:07:23 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:07:23 --> Utf8 Class Initialized
INFO - 2018-04-19 06:07:23 --> URI Class Initialized
INFO - 2018-04-19 06:07:23 --> Router Class Initialized
INFO - 2018-04-19 06:07:23 --> Output Class Initialized
INFO - 2018-04-19 06:07:23 --> Security Class Initialized
DEBUG - 2018-04-19 06:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:07:23 --> Input Class Initialized
INFO - 2018-04-19 06:07:23 --> Language Class Initialized
INFO - 2018-04-19 06:07:23 --> Language Class Initialized
INFO - 2018-04-19 06:07:23 --> Config Class Initialized
INFO - 2018-04-19 06:07:23 --> Loader Class Initialized
INFO - 2018-04-19 11:37:23 --> Helper loaded: url_helper
INFO - 2018-04-19 11:37:23 --> Helper loaded: notification_helper
INFO - 2018-04-19 11:37:23 --> Helper loaded: settings_helper
INFO - 2018-04-19 11:37:23 --> Helper loaded: permission_helper
INFO - 2018-04-19 11:37:23 --> Helper loaded: users_helper
INFO - 2018-04-19 06:07:23 --> Config Class Initialized
INFO - 2018-04-19 06:07:23 --> Hooks Class Initialized
INFO - 2018-04-19 11:37:23 --> Database Driver Class Initialized
DEBUG - 2018-04-19 06:07:23 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:07:23 --> Utf8 Class Initialized
INFO - 2018-04-19 06:07:23 --> URI Class Initialized
DEBUG - 2018-04-19 11:37:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 11:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 06:07:23 --> Router Class Initialized
INFO - 2018-04-19 06:07:23 --> Output Class Initialized
INFO - 2018-04-19 06:07:23 --> Security Class Initialized
INFO - 2018-04-19 11:37:23 --> Helper loaded: form_helper
INFO - 2018-04-19 11:37:23 --> Form Validation Class Initialized
INFO - 2018-04-19 11:37:23 --> Controller Class Initialized
DEBUG - 2018-04-19 06:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:07:23 --> Input Class Initialized
INFO - 2018-04-19 06:07:23 --> Language Class Initialized
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 11:37:23 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 11:37:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 11:37:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 11:37:23 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 11:37:23 --> Final output sent to browser
DEBUG - 2018-04-19 11:37:23 --> Total execution time: 0.1096
INFO - 2018-04-19 06:07:23 --> Language Class Initialized
INFO - 2018-04-19 06:07:23 --> Config Class Initialized
INFO - 2018-04-19 06:07:23 --> Loader Class Initialized
INFO - 2018-04-19 11:37:23 --> Helper loaded: url_helper
INFO - 2018-04-19 11:37:23 --> Helper loaded: notification_helper
INFO - 2018-04-19 11:37:23 --> Helper loaded: settings_helper
INFO - 2018-04-19 11:37:23 --> Helper loaded: permission_helper
INFO - 2018-04-19 11:37:23 --> Helper loaded: users_helper
INFO - 2018-04-19 11:37:23 --> Database Driver Class Initialized
DEBUG - 2018-04-19 11:37:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 11:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 06:07:23 --> Config Class Initialized
INFO - 2018-04-19 06:07:23 --> Hooks Class Initialized
DEBUG - 2018-04-19 06:07:23 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:07:23 --> Utf8 Class Initialized
INFO - 2018-04-19 11:37:23 --> Helper loaded: form_helper
INFO - 2018-04-19 11:37:23 --> Form Validation Class Initialized
INFO - 2018-04-19 11:37:23 --> Controller Class Initialized
INFO - 2018-04-19 06:07:23 --> URI Class Initialized
INFO - 2018-04-19 06:07:23 --> Router Class Initialized
INFO - 2018-04-19 06:07:23 --> Config Class Initialized
INFO - 2018-04-19 06:07:23 --> Hooks Class Initialized
INFO - 2018-04-19 06:07:23 --> Config Class Initialized
INFO - 2018-04-19 06:07:23 --> Hooks Class Initialized
INFO - 2018-04-19 06:07:23 --> Output Class Initialized
DEBUG - 2018-04-19 06:07:23 --> UTF-8 Support Enabled
DEBUG - 2018-04-19 06:07:23 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:07:23 --> Utf8 Class Initialized
INFO - 2018-04-19 06:07:23 --> Utf8 Class Initialized
INFO - 2018-04-19 06:07:23 --> Security Class Initialized
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 11:37:23 --> Helper loaded: inflector_helper
INFO - 2018-04-19 06:07:23 --> URI Class Initialized
INFO - 2018-04-19 06:07:23 --> URI Class Initialized
DEBUG - 2018-04-19 06:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:07:23 --> Input Class Initialized
INFO - 2018-04-19 06:07:23 --> Language Class Initialized
DEBUG - 2018-04-19 11:37:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 06:07:23 --> Router Class Initialized
INFO - 2018-04-19 06:07:23 --> Router Class Initialized
INFO - 2018-04-19 11:37:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 06:07:23 --> Output Class Initialized
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 06:07:23 --> Config Class Initialized
INFO - 2018-04-19 06:07:23 --> Hooks Class Initialized
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 11:37:23 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 06:07:23 --> Output Class Initialized
INFO - 2018-04-19 06:07:23 --> Security Class Initialized
INFO - 2018-04-19 11:37:23 --> Final output sent to browser
DEBUG - 2018-04-19 11:37:23 --> Total execution time: 0.1145
DEBUG - 2018-04-19 06:07:23 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:07:23 --> Utf8 Class Initialized
INFO - 2018-04-19 06:07:23 --> Security Class Initialized
INFO - 2018-04-19 06:07:23 --> Config Class Initialized
INFO - 2018-04-19 06:07:23 --> Hooks Class Initialized
DEBUG - 2018-04-19 06:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:07:23 --> Input Class Initialized
INFO - 2018-04-19 06:07:23 --> URI Class Initialized
DEBUG - 2018-04-19 06:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:07:23 --> Input Class Initialized
INFO - 2018-04-19 06:07:23 --> Language Class Initialized
INFO - 2018-04-19 06:07:23 --> Language Class Initialized
DEBUG - 2018-04-19 06:07:23 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:07:23 --> Utf8 Class Initialized
INFO - 2018-04-19 06:07:23 --> Router Class Initialized
INFO - 2018-04-19 06:07:23 --> URI Class Initialized
INFO - 2018-04-19 06:07:23 --> Config Class Initialized
INFO - 2018-04-19 06:07:23 --> Hooks Class Initialized
INFO - 2018-04-19 06:07:23 --> Language Class Initialized
INFO - 2018-04-19 06:07:23 --> Config Class Initialized
INFO - 2018-04-19 06:07:23 --> Loader Class Initialized
INFO - 2018-04-19 06:07:23 --> Output Class Initialized
INFO - 2018-04-19 06:07:23 --> Router Class Initialized
DEBUG - 2018-04-19 06:07:23 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:07:23 --> Utf8 Class Initialized
INFO - 2018-04-19 06:07:23 --> Security Class Initialized
INFO - 2018-04-19 11:37:23 --> Helper loaded: url_helper
INFO - 2018-04-19 11:37:23 --> Helper loaded: notification_helper
INFO - 2018-04-19 11:37:23 --> Helper loaded: settings_helper
INFO - 2018-04-19 06:07:23 --> URI Class Initialized
DEBUG - 2018-04-19 06:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:07:23 --> Input Class Initialized
INFO - 2018-04-19 11:37:23 --> Helper loaded: permission_helper
INFO - 2018-04-19 06:07:23 --> Output Class Initialized
INFO - 2018-04-19 06:07:23 --> Language Class Initialized
INFO - 2018-04-19 11:37:23 --> Helper loaded: users_helper
INFO - 2018-04-19 06:07:23 --> Security Class Initialized
DEBUG - 2018-04-19 06:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:07:23 --> Input Class Initialized
INFO - 2018-04-19 06:07:23 --> Language Class Initialized
INFO - 2018-04-19 06:07:23 --> Router Class Initialized
INFO - 2018-04-19 06:07:23 --> Language Class Initialized
INFO - 2018-04-19 06:07:23 --> Config Class Initialized
INFO - 2018-04-19 06:07:23 --> Loader Class Initialized
INFO - 2018-04-19 11:37:23 --> Helper loaded: url_helper
INFO - 2018-04-19 06:07:23 --> Output Class Initialized
INFO - 2018-04-19 11:37:23 --> Helper loaded: notification_helper
INFO - 2018-04-19 11:37:23 --> Helper loaded: settings_helper
INFO - 2018-04-19 11:37:23 --> Helper loaded: permission_helper
INFO - 2018-04-19 06:07:23 --> Security Class Initialized
INFO - 2018-04-19 11:37:23 --> Helper loaded: users_helper
INFO - 2018-04-19 11:37:23 --> Database Driver Class Initialized
INFO - 2018-04-19 06:07:23 --> Language Class Initialized
INFO - 2018-04-19 06:07:23 --> Config Class Initialized
INFO - 2018-04-19 06:07:23 --> Loader Class Initialized
DEBUG - 2018-04-19 06:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:07:23 --> Input Class Initialized
INFO - 2018-04-19 06:07:23 --> Language Class Initialized
INFO - 2018-04-19 11:37:23 --> Helper loaded: url_helper
INFO - 2018-04-19 06:07:23 --> Language Class Initialized
INFO - 2018-04-19 11:37:23 --> Helper loaded: notification_helper
INFO - 2018-04-19 06:07:23 --> Config Class Initialized
INFO - 2018-04-19 06:07:23 --> Loader Class Initialized
INFO - 2018-04-19 11:37:23 --> Helper loaded: settings_helper
DEBUG - 2018-04-19 11:37:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 11:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 11:37:23 --> Helper loaded: permission_helper
INFO - 2018-04-19 11:37:23 --> Helper loaded: url_helper
INFO - 2018-04-19 11:37:23 --> Helper loaded: users_helper
INFO - 2018-04-19 11:37:23 --> Helper loaded: notification_helper
INFO - 2018-04-19 11:37:23 --> Helper loaded: settings_helper
INFO - 2018-04-19 11:37:23 --> Helper loaded: permission_helper
INFO - 2018-04-19 11:37:23 --> Helper loaded: users_helper
INFO - 2018-04-19 06:07:23 --> Language Class Initialized
INFO - 2018-04-19 06:07:23 --> Config Class Initialized
INFO - 2018-04-19 06:07:23 --> Loader Class Initialized
INFO - 2018-04-19 11:37:23 --> Helper loaded: url_helper
INFO - 2018-04-19 11:37:23 --> Helper loaded: form_helper
INFO - 2018-04-19 11:37:23 --> Form Validation Class Initialized
INFO - 2018-04-19 11:37:23 --> Controller Class Initialized
INFO - 2018-04-19 11:37:23 --> Helper loaded: notification_helper
INFO - 2018-04-19 11:37:23 --> Helper loaded: settings_helper
INFO - 2018-04-19 11:37:23 --> Database Driver Class Initialized
INFO - 2018-04-19 11:37:23 --> Helper loaded: permission_helper
INFO - 2018-04-19 11:37:23 --> Helper loaded: users_helper
INFO - 2018-04-19 06:07:23 --> Language Class Initialized
INFO - 2018-04-19 06:07:23 --> Config Class Initialized
INFO - 2018-04-19 06:07:23 --> Loader Class Initialized
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
DEBUG - 2018-04-19 11:37:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 11:37:23 --> Helper loaded: inflector_helper
INFO - 2018-04-19 11:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 11:37:23 --> Database Driver Class Initialized
INFO - 2018-04-19 11:37:23 --> Helper loaded: url_helper
INFO - 2018-04-19 11:37:23 --> Database Driver Class Initialized
INFO - 2018-04-19 11:37:23 --> Helper loaded: notification_helper
INFO - 2018-04-19 11:37:23 --> Helper loaded: settings_helper
INFO - 2018-04-19 11:37:23 --> Helper loaded: permission_helper
DEBUG - 2018-04-19 11:37:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 11:37:23 --> Helper loaded: users_helper
INFO - 2018-04-19 11:37:23 --> Language file loaded: language/english/rest_controller_lang.php
DEBUG - 2018-04-19 11:37:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 11:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
DEBUG - 2018-04-19 11:37:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 11:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 11:37:23 --> Database Driver Class Initialized
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 11:37:23 --> Helper loaded: form_helper
INFO - 2018-04-19 11:37:23 --> Form Validation Class Initialized
INFO - 2018-04-19 11:37:23 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 11:37:23 --> Controller Class Initialized
INFO - 2018-04-19 11:37:23 --> Final output sent to browser
DEBUG - 2018-04-19 11:37:23 --> Total execution time: 0.1099
DEBUG - 2018-04-19 11:37:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 11:37:23 --> Helper loaded: form_helper
INFO - 2018-04-19 11:37:23 --> Form Validation Class Initialized
INFO - 2018-04-19 11:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 11:37:23 --> Controller Class Initialized
INFO - 2018-04-19 11:37:23 --> Helper loaded: form_helper
INFO - 2018-04-19 11:37:23 --> Form Validation Class Initialized
INFO - 2018-04-19 11:37:23 --> Controller Class Initialized
INFO - 2018-04-19 11:37:23 --> Database Driver Class Initialized
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 11:37:23 --> Helper loaded: inflector_helper
INFO - 2018-04-19 11:37:23 --> Helper loaded: form_helper
INFO - 2018-04-19 11:37:23 --> Form Validation Class Initialized
DEBUG - 2018-04-19 11:37:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 11:37:23 --> Controller Class Initialized
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 06:07:23 --> Config Class Initialized
INFO - 2018-04-19 06:07:23 --> Hooks Class Initialized
INFO - 2018-04-19 11:37:23 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 11:37:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 11:37:23 --> Helper loaded: inflector_helper
INFO - 2018-04-19 11:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 11:37:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
DEBUG - 2018-04-19 11:37:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-04-19 11:37:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
DEBUG - 2018-04-19 06:07:23 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:07:23 --> Utf8 Class Initialized
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 11:37:23 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 11:37:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 11:37:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 06:07:23 --> URI Class Initialized
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 11:37:23 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 11:37:23 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 11:37:23 --> Final output sent to browser
DEBUG - 2018-04-19 11:37:23 --> Total execution time: 0.1236
INFO - 2018-04-19 11:37:23 --> Helper loaded: form_helper
INFO - 2018-04-19 11:37:23 --> Form Validation Class Initialized
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 11:37:23 --> Controller Class Initialized
INFO - 2018-04-19 11:37:23 --> Helper loaded: inflector_helper
INFO - 2018-04-19 06:07:23 --> Router Class Initialized
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 11:37:23 --> Final output sent to browser
DEBUG - 2018-04-19 11:37:23 --> Total execution time: 0.1288
INFO - 2018-04-19 11:37:23 --> Final output sent to browser
DEBUG - 2018-04-19 11:37:23 --> Total execution time: 0.1100
DEBUG - 2018-04-19 11:37:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 06:07:23 --> Output Class Initialized
INFO - 2018-04-19 11:37:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 06:07:23 --> Security Class Initialized
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
DEBUG - 2018-04-19 06:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:07:23 --> Input Class Initialized
INFO - 2018-04-19 11:37:23 --> Helper loaded: inflector_helper
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 06:07:23 --> Language Class Initialized
INFO - 2018-04-19 06:07:23 --> Config Class Initialized
INFO - 2018-04-19 06:07:23 --> Hooks Class Initialized
DEBUG - 2018-04-19 11:37:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 11:37:23 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 06:07:23 --> Config Class Initialized
INFO - 2018-04-19 06:07:23 --> Hooks Class Initialized
DEBUG - 2018-04-19 06:07:23 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:07:23 --> Utf8 Class Initialized
INFO - 2018-04-19 11:37:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 06:07:23 --> URI Class Initialized
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
DEBUG - 2018-04-19 06:07:23 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:07:23 --> Utf8 Class Initialized
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 06:07:23 --> Router Class Initialized
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 06:07:23 --> URI Class Initialized
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 06:07:23 --> Output Class Initialized
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 11:37:23 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 06:07:23 --> Router Class Initialized
INFO - 2018-04-19 06:07:23 --> Security Class Initialized
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 06:07:23 --> Language Class Initialized
INFO - 2018-04-19 06:07:23 --> Config Class Initialized
INFO - 2018-04-19 06:07:23 --> Loader Class Initialized
DEBUG - 2018-04-19 06:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:07:23 --> Input Class Initialized
INFO - 2018-04-19 06:07:23 --> Output Class Initialized
INFO - 2018-04-19 06:07:23 --> Language Class Initialized
INFO - 2018-04-19 11:37:23 --> Helper loaded: url_helper
INFO - 2018-04-19 11:37:23 --> Helper loaded: notification_helper
INFO - 2018-04-19 06:07:23 --> Security Class Initialized
INFO - 2018-04-19 11:37:23 --> Helper loaded: settings_helper
INFO - 2018-04-19 11:37:23 --> Helper loaded: permission_helper
INFO - 2018-04-19 11:37:23 --> Helper loaded: users_helper
DEBUG - 2018-04-19 06:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:07:23 --> Input Class Initialized
INFO - 2018-04-19 11:37:23 --> Final output sent to browser
DEBUG - 2018-04-19 11:37:23 --> Total execution time: 0.1388
INFO - 2018-04-19 06:07:23 --> Language Class Initialized
INFO - 2018-04-19 11:37:23 --> Final output sent to browser
DEBUG - 2018-04-19 11:37:23 --> Total execution time: 0.1411
INFO - 2018-04-19 06:07:23 --> Language Class Initialized
INFO - 2018-04-19 06:07:23 --> Config Class Initialized
INFO - 2018-04-19 06:07:23 --> Loader Class Initialized
INFO - 2018-04-19 11:37:23 --> Database Driver Class Initialized
INFO - 2018-04-19 11:37:23 --> Helper loaded: url_helper
INFO - 2018-04-19 11:37:23 --> Helper loaded: notification_helper
INFO - 2018-04-19 11:37:23 --> Helper loaded: settings_helper
INFO - 2018-04-19 11:37:23 --> Helper loaded: permission_helper
INFO - 2018-04-19 11:37:23 --> Helper loaded: users_helper
DEBUG - 2018-04-19 11:37:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 11:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 06:07:23 --> Language Class Initialized
INFO - 2018-04-19 06:07:23 --> Config Class Initialized
INFO - 2018-04-19 06:07:23 --> Loader Class Initialized
INFO - 2018-04-19 11:37:23 --> Helper loaded: url_helper
INFO - 2018-04-19 11:37:23 --> Helper loaded: notification_helper
INFO - 2018-04-19 11:37:23 --> Helper loaded: form_helper
INFO - 2018-04-19 11:37:23 --> Form Validation Class Initialized
INFO - 2018-04-19 11:37:23 --> Controller Class Initialized
INFO - 2018-04-19 11:37:23 --> Helper loaded: settings_helper
INFO - 2018-04-19 11:37:23 --> Helper loaded: permission_helper
INFO - 2018-04-19 11:37:23 --> Helper loaded: users_helper
INFO - 2018-04-19 11:37:23 --> Database Driver Class Initialized
DEBUG - 2018-04-19 11:37:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 11:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 11:37:23 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 11:37:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 11:37:23 --> Helper loaded: form_helper
INFO - 2018-04-19 11:37:23 --> Form Validation Class Initialized
INFO - 2018-04-19 11:37:23 --> Controller Class Initialized
INFO - 2018-04-19 11:37:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 11:37:23 --> Database Driver Class Initialized
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 11:37:23 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 11:37:23 --> Final output sent to browser
DEBUG - 2018-04-19 11:37:23 --> Total execution time: 0.1156
DEBUG - 2018-04-19 11:37:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 11:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 11:37:23 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 11:37:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 11:37:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 11:37:23 --> Helper loaded: form_helper
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 11:37:23 --> Form Validation Class Initialized
INFO - 2018-04-19 11:37:23 --> Controller Class Initialized
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 11:37:23 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 11:37:23 --> Final output sent to browser
DEBUG - 2018-04-19 11:37:23 --> Total execution time: 0.1038
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 11:37:23 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 11:37:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 11:37:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 11:37:23 --> Model Class Initialized
INFO - 2018-04-19 11:37:23 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 11:37:23 --> Final output sent to browser
DEBUG - 2018-04-19 11:37:23 --> Total execution time: 0.1200
INFO - 2018-04-19 06:10:14 --> Config Class Initialized
INFO - 2018-04-19 06:10:14 --> Hooks Class Initialized
DEBUG - 2018-04-19 06:10:14 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:10:14 --> Utf8 Class Initialized
INFO - 2018-04-19 06:10:14 --> URI Class Initialized
INFO - 2018-04-19 06:10:14 --> Router Class Initialized
INFO - 2018-04-19 06:10:14 --> Output Class Initialized
INFO - 2018-04-19 06:10:14 --> Security Class Initialized
INFO - 2018-04-19 06:10:14 --> Config Class Initialized
INFO - 2018-04-19 06:10:14 --> Hooks Class Initialized
DEBUG - 2018-04-19 06:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:10:14 --> Input Class Initialized
INFO - 2018-04-19 06:10:14 --> Language Class Initialized
INFO - 2018-04-19 06:10:14 --> Config Class Initialized
INFO - 2018-04-19 06:10:14 --> Hooks Class Initialized
DEBUG - 2018-04-19 06:10:14 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:10:14 --> Utf8 Class Initialized
DEBUG - 2018-04-19 06:10:14 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:10:14 --> Utf8 Class Initialized
INFO - 2018-04-19 06:10:14 --> URI Class Initialized
INFO - 2018-04-19 06:10:14 --> URI Class Initialized
INFO - 2018-04-19 06:10:14 --> Router Class Initialized
INFO - 2018-04-19 06:10:14 --> Output Class Initialized
INFO - 2018-04-19 06:10:14 --> Security Class Initialized
INFO - 2018-04-19 06:10:14 --> Language Class Initialized
INFO - 2018-04-19 06:10:14 --> Config Class Initialized
INFO - 2018-04-19 06:10:14 --> Loader Class Initialized
DEBUG - 2018-04-19 06:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:10:14 --> Input Class Initialized
INFO - 2018-04-19 11:40:14 --> Helper loaded: url_helper
INFO - 2018-04-19 06:10:14 --> Language Class Initialized
INFO - 2018-04-19 11:40:14 --> Helper loaded: notification_helper
INFO - 2018-04-19 11:40:14 --> Helper loaded: settings_helper
INFO - 2018-04-19 06:10:14 --> Router Class Initialized
INFO - 2018-04-19 11:40:14 --> Helper loaded: permission_helper
INFO - 2018-04-19 11:40:14 --> Helper loaded: users_helper
INFO - 2018-04-19 06:10:14 --> Output Class Initialized
INFO - 2018-04-19 06:10:14 --> Security Class Initialized
INFO - 2018-04-19 06:10:14 --> Config Class Initialized
INFO - 2018-04-19 06:10:14 --> Hooks Class Initialized
INFO - 2018-04-19 11:40:14 --> Database Driver Class Initialized
INFO - 2018-04-19 06:10:14 --> Config Class Initialized
INFO - 2018-04-19 06:10:14 --> Hooks Class Initialized
DEBUG - 2018-04-19 11:40:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 11:40:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-04-19 06:10:14 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:10:14 --> Utf8 Class Initialized
INFO - 2018-04-19 06:10:14 --> Language Class Initialized
INFO - 2018-04-19 06:10:14 --> Config Class Initialized
INFO - 2018-04-19 06:10:14 --> Loader Class Initialized
DEBUG - 2018-04-19 06:10:14 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:10:14 --> Utf8 Class Initialized
INFO - 2018-04-19 06:10:14 --> URI Class Initialized
DEBUG - 2018-04-19 06:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:10:14 --> Input Class Initialized
INFO - 2018-04-19 11:40:14 --> Helper loaded: url_helper
INFO - 2018-04-19 06:10:14 --> URI Class Initialized
INFO - 2018-04-19 11:40:14 --> Helper loaded: notification_helper
INFO - 2018-04-19 11:40:14 --> Helper loaded: form_helper
INFO - 2018-04-19 11:40:14 --> Form Validation Class Initialized
INFO - 2018-04-19 11:40:14 --> Controller Class Initialized
INFO - 2018-04-19 11:40:14 --> Helper loaded: settings_helper
INFO - 2018-04-19 11:40:14 --> Helper loaded: permission_helper
INFO - 2018-04-19 06:10:14 --> Language Class Initialized
INFO - 2018-04-19 11:40:14 --> Helper loaded: users_helper
INFO - 2018-04-19 06:10:14 --> Router Class Initialized
INFO - 2018-04-19 06:10:14 --> Router Class Initialized
INFO - 2018-04-19 11:40:14 --> Model Class Initialized
INFO - 2018-04-19 11:40:14 --> Helper loaded: inflector_helper
INFO - 2018-04-19 06:10:14 --> Output Class Initialized
INFO - 2018-04-19 06:10:14 --> Output Class Initialized
DEBUG - 2018-04-19 11:40:14 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 11:40:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 06:10:14 --> Security Class Initialized
INFO - 2018-04-19 06:10:14 --> Security Class Initialized
INFO - 2018-04-19 11:40:14 --> Model Class Initialized
INFO - 2018-04-19 11:40:14 --> Model Class Initialized
INFO - 2018-04-19 11:40:14 --> Model Class Initialized
INFO - 2018-04-19 11:40:14 --> Model Class Initialized
INFO - 2018-04-19 11:40:14 --> Model Class Initialized
INFO - 2018-04-19 11:40:14 --> Model Class Initialized
INFO - 2018-04-19 11:40:14 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-04-19 06:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:10:14 --> Input Class Initialized
DEBUG - 2018-04-19 06:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:10:14 --> Input Class Initialized
INFO - 2018-04-19 06:10:14 --> Language Class Initialized
INFO - 2018-04-19 06:10:14 --> Language Class Initialized
INFO - 2018-04-19 11:40:14 --> Final output sent to browser
DEBUG - 2018-04-19 11:40:14 --> Total execution time: 0.0900
INFO - 2018-04-19 11:40:14 --> Database Driver Class Initialized
DEBUG - 2018-04-19 11:40:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 11:40:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 11:40:14 --> Helper loaded: form_helper
INFO - 2018-04-19 11:40:14 --> Form Validation Class Initialized
INFO - 2018-04-19 11:40:14 --> Controller Class Initialized
INFO - 2018-04-19 06:10:14 --> Language Class Initialized
INFO - 2018-04-19 06:10:14 --> Config Class Initialized
INFO - 2018-04-19 06:10:14 --> Loader Class Initialized
INFO - 2018-04-19 11:40:14 --> Helper loaded: url_helper
INFO - 2018-04-19 11:40:14 --> Helper loaded: notification_helper
INFO - 2018-04-19 11:40:14 --> Helper loaded: settings_helper
INFO - 2018-04-19 11:40:14 --> Model Class Initialized
INFO - 2018-04-19 11:40:14 --> Helper loaded: permission_helper
INFO - 2018-04-19 11:40:14 --> Helper loaded: inflector_helper
INFO - 2018-04-19 11:40:14 --> Helper loaded: users_helper
INFO - 2018-04-19 06:10:14 --> Language Class Initialized
INFO - 2018-04-19 06:10:14 --> Config Class Initialized
INFO - 2018-04-19 06:10:14 --> Loader Class Initialized
DEBUG - 2018-04-19 11:40:14 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 11:40:14 --> Helper loaded: url_helper
INFO - 2018-04-19 11:40:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 11:40:14 --> Helper loaded: notification_helper
INFO - 2018-04-19 11:40:14 --> Helper loaded: settings_helper
INFO - 2018-04-19 11:40:14 --> Model Class Initialized
INFO - 2018-04-19 11:40:14 --> Helper loaded: permission_helper
INFO - 2018-04-19 11:40:14 --> Model Class Initialized
INFO - 2018-04-19 11:40:14 --> Helper loaded: users_helper
INFO - 2018-04-19 11:40:14 --> Model Class Initialized
INFO - 2018-04-19 11:40:14 --> Model Class Initialized
INFO - 2018-04-19 11:40:14 --> Model Class Initialized
INFO - 2018-04-19 11:40:14 --> Model Class Initialized
INFO - 2018-04-19 11:40:14 --> Model Class Initialized
INFO - 2018-04-19 11:40:14 --> Model Class Initialized
INFO - 2018-04-19 11:40:14 --> Model Class Initialized
INFO - 2018-04-19 11:40:14 --> Model Class Initialized
INFO - 2018-04-19 06:10:14 --> Language Class Initialized
INFO - 2018-04-19 06:10:14 --> Config Class Initialized
INFO - 2018-04-19 06:10:14 --> Loader Class Initialized
INFO - 2018-04-19 11:40:15 --> Model Class Initialized
INFO - 2018-04-19 11:40:15 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 11:40:15 --> Model Class Initialized
INFO - 2018-04-19 11:40:15 --> Helper loaded: url_helper
INFO - 2018-04-19 11:40:15 --> Database Driver Class Initialized
INFO - 2018-04-19 11:40:15 --> Helper loaded: notification_helper
INFO - 2018-04-19 11:40:15 --> Helper loaded: settings_helper
INFO - 2018-04-19 11:40:15 --> Helper loaded: permission_helper
INFO - 2018-04-19 11:40:15 --> Helper loaded: users_helper
DEBUG - 2018-04-19 11:40:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 11:40:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 11:40:15 --> Database Driver Class Initialized
INFO - 2018-04-19 11:40:15 --> Final output sent to browser
DEBUG - 2018-04-19 11:40:15 --> Total execution time: 0.1222
INFO - 2018-04-19 11:40:15 --> Helper loaded: form_helper
INFO - 2018-04-19 11:40:15 --> Form Validation Class Initialized
INFO - 2018-04-19 11:40:15 --> Controller Class Initialized
INFO - 2018-04-19 11:40:15 --> Database Driver Class Initialized
DEBUG - 2018-04-19 11:40:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 11:40:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 11:40:15 --> Model Class Initialized
INFO - 2018-04-19 11:40:15 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 11:40:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 11:40:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-04-19 11:40:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 11:40:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 11:40:15 --> Model Class Initialized
INFO - 2018-04-19 11:40:15 --> Model Class Initialized
INFO - 2018-04-19 11:40:15 --> Helper loaded: form_helper
INFO - 2018-04-19 11:40:15 --> Form Validation Class Initialized
INFO - 2018-04-19 11:40:15 --> Controller Class Initialized
INFO - 2018-04-19 11:40:15 --> Model Class Initialized
INFO - 2018-04-19 11:40:15 --> Model Class Initialized
INFO - 2018-04-19 11:40:15 --> Model Class Initialized
INFO - 2018-04-19 11:40:15 --> Model Class Initialized
INFO - 2018-04-19 11:40:15 --> Model Class Initialized
INFO - 2018-04-19 11:40:15 --> Model Class Initialized
INFO - 2018-04-19 11:40:15 --> Model Class Initialized
INFO - 2018-04-19 11:40:15 --> Model Class Initialized
INFO - 2018-04-19 11:40:15 --> Helper loaded: form_helper
INFO - 2018-04-19 11:40:15 --> Form Validation Class Initialized
INFO - 2018-04-19 11:40:15 --> Controller Class Initialized
INFO - 2018-04-19 11:40:15 --> Model Class Initialized
INFO - 2018-04-19 11:40:15 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 11:40:15 --> Model Class Initialized
INFO - 2018-04-19 11:40:15 --> Model Class Initialized
INFO - 2018-04-19 11:40:15 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 11:40:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 11:40:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 11:40:15 --> Model Class Initialized
INFO - 2018-04-19 11:40:15 --> Helper loaded: inflector_helper
INFO - 2018-04-19 11:40:15 --> Model Class Initialized
INFO - 2018-04-19 11:40:15 --> Model Class Initialized
INFO - 2018-04-19 11:40:15 --> Model Class Initialized
INFO - 2018-04-19 11:40:15 --> Model Class Initialized
INFO - 2018-04-19 11:40:15 --> Model Class Initialized
INFO - 2018-04-19 11:40:15 --> Model Class Initialized
INFO - 2018-04-19 11:40:15 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-04-19 11:40:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 11:40:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 11:40:15 --> Model Class Initialized
INFO - 2018-04-19 11:40:15 --> Final output sent to browser
DEBUG - 2018-04-19 11:40:15 --> Total execution time: 0.1382
INFO - 2018-04-19 11:40:15 --> Model Class Initialized
INFO - 2018-04-19 11:40:15 --> Model Class Initialized
INFO - 2018-04-19 11:40:15 --> Model Class Initialized
INFO - 2018-04-19 11:40:15 --> Model Class Initialized
INFO - 2018-04-19 11:40:15 --> Model Class Initialized
INFO - 2018-04-19 11:40:15 --> Model Class Initialized
INFO - 2018-04-19 11:40:15 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 11:40:15 --> Final output sent to browser
DEBUG - 2018-04-19 11:40:15 --> Total execution time: 0.1350
INFO - 2018-04-19 11:40:15 --> Model Class Initialized
INFO - 2018-04-19 11:40:15 --> Final output sent to browser
DEBUG - 2018-04-19 11:40:15 --> Total execution time: 0.1868
INFO - 2018-04-19 06:14:20 --> Config Class Initialized
INFO - 2018-04-19 06:14:20 --> Hooks Class Initialized
DEBUG - 2018-04-19 06:14:20 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:14:20 --> Utf8 Class Initialized
INFO - 2018-04-19 06:14:20 --> URI Class Initialized
INFO - 2018-04-19 06:14:20 --> Router Class Initialized
INFO - 2018-04-19 06:14:20 --> Output Class Initialized
INFO - 2018-04-19 06:14:20 --> Security Class Initialized
DEBUG - 2018-04-19 06:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:14:20 --> Input Class Initialized
INFO - 2018-04-19 06:14:20 --> Language Class Initialized
INFO - 2018-04-19 06:14:20 --> Language Class Initialized
INFO - 2018-04-19 06:14:20 --> Config Class Initialized
INFO - 2018-04-19 06:14:20 --> Loader Class Initialized
INFO - 2018-04-19 11:44:20 --> Helper loaded: url_helper
INFO - 2018-04-19 11:44:20 --> Helper loaded: notification_helper
INFO - 2018-04-19 11:44:20 --> Helper loaded: settings_helper
INFO - 2018-04-19 11:44:20 --> Helper loaded: permission_helper
INFO - 2018-04-19 11:44:20 --> Helper loaded: users_helper
INFO - 2018-04-19 11:44:20 --> Database Driver Class Initialized
DEBUG - 2018-04-19 11:44:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 11:44:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 11:44:20 --> Helper loaded: form_helper
INFO - 2018-04-19 11:44:20 --> Form Validation Class Initialized
INFO - 2018-04-19 11:44:20 --> Controller Class Initialized
INFO - 2018-04-19 11:44:20 --> Model Class Initialized
INFO - 2018-04-19 11:44:20 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 11:44:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 11:44:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 11:44:20 --> Model Class Initialized
INFO - 2018-04-19 11:44:20 --> Model Class Initialized
INFO - 2018-04-19 11:44:20 --> Model Class Initialized
INFO - 2018-04-19 11:44:20 --> Model Class Initialized
INFO - 2018-04-19 11:44:20 --> Model Class Initialized
INFO - 2018-04-19 11:44:20 --> Model Class Initialized
INFO - 2018-04-19 11:44:20 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 11:44:20 --> Final output sent to browser
DEBUG - 2018-04-19 11:44:20 --> Total execution time: 0.1183
INFO - 2018-04-19 06:14:20 --> Config Class Initialized
INFO - 2018-04-19 06:14:20 --> Hooks Class Initialized
DEBUG - 2018-04-19 06:14:20 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:14:20 --> Utf8 Class Initialized
INFO - 2018-04-19 06:14:20 --> URI Class Initialized
INFO - 2018-04-19 06:14:20 --> Router Class Initialized
INFO - 2018-04-19 06:14:20 --> Output Class Initialized
INFO - 2018-04-19 06:14:20 --> Security Class Initialized
DEBUG - 2018-04-19 06:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:14:20 --> Input Class Initialized
INFO - 2018-04-19 06:14:20 --> Language Class Initialized
INFO - 2018-04-19 06:14:20 --> Language Class Initialized
INFO - 2018-04-19 06:14:20 --> Config Class Initialized
INFO - 2018-04-19 06:14:20 --> Loader Class Initialized
INFO - 2018-04-19 11:44:20 --> Helper loaded: url_helper
INFO - 2018-04-19 11:44:20 --> Helper loaded: notification_helper
INFO - 2018-04-19 11:44:20 --> Helper loaded: settings_helper
INFO - 2018-04-19 11:44:20 --> Helper loaded: permission_helper
INFO - 2018-04-19 11:44:20 --> Helper loaded: users_helper
INFO - 2018-04-19 11:44:20 --> Database Driver Class Initialized
DEBUG - 2018-04-19 11:44:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 11:44:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 11:44:20 --> Helper loaded: form_helper
INFO - 2018-04-19 11:44:20 --> Form Validation Class Initialized
INFO - 2018-04-19 11:44:20 --> Controller Class Initialized
INFO - 2018-04-19 11:44:20 --> Model Class Initialized
INFO - 2018-04-19 11:44:20 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 11:44:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 11:44:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 11:44:20 --> Model Class Initialized
INFO - 2018-04-19 11:44:20 --> Model Class Initialized
INFO - 2018-04-19 11:44:20 --> Model Class Initialized
INFO - 2018-04-19 11:44:20 --> Model Class Initialized
INFO - 2018-04-19 11:44:20 --> Model Class Initialized
INFO - 2018-04-19 11:44:20 --> Model Class Initialized
INFO - 2018-04-19 11:44:20 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 11:44:20 --> Final output sent to browser
DEBUG - 2018-04-19 11:44:20 --> Total execution time: 0.1099
INFO - 2018-04-19 06:14:20 --> Config Class Initialized
INFO - 2018-04-19 06:14:20 --> Hooks Class Initialized
DEBUG - 2018-04-19 06:14:20 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:14:20 --> Utf8 Class Initialized
INFO - 2018-04-19 06:14:20 --> URI Class Initialized
INFO - 2018-04-19 06:14:20 --> Router Class Initialized
INFO - 2018-04-19 06:14:20 --> Output Class Initialized
INFO - 2018-04-19 06:14:20 --> Security Class Initialized
DEBUG - 2018-04-19 06:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:14:20 --> Input Class Initialized
INFO - 2018-04-19 06:14:20 --> Language Class Initialized
INFO - 2018-04-19 06:14:20 --> Language Class Initialized
INFO - 2018-04-19 06:14:20 --> Config Class Initialized
INFO - 2018-04-19 06:14:20 --> Loader Class Initialized
INFO - 2018-04-19 11:44:20 --> Helper loaded: url_helper
INFO - 2018-04-19 11:44:20 --> Helper loaded: notification_helper
INFO - 2018-04-19 11:44:20 --> Helper loaded: settings_helper
INFO - 2018-04-19 11:44:20 --> Helper loaded: permission_helper
INFO - 2018-04-19 11:44:20 --> Helper loaded: users_helper
INFO - 2018-04-19 11:44:20 --> Database Driver Class Initialized
DEBUG - 2018-04-19 11:44:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 11:44:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 11:44:20 --> Helper loaded: form_helper
INFO - 2018-04-19 11:44:20 --> Form Validation Class Initialized
INFO - 2018-04-19 11:44:20 --> Controller Class Initialized
INFO - 2018-04-19 11:44:20 --> Model Class Initialized
INFO - 2018-04-19 11:44:20 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 11:44:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 11:44:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 11:44:20 --> Model Class Initialized
INFO - 2018-04-19 11:44:20 --> Model Class Initialized
INFO - 2018-04-19 11:44:20 --> Model Class Initialized
INFO - 2018-04-19 11:44:20 --> Model Class Initialized
INFO - 2018-04-19 11:44:20 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 11:44:20 --> Final output sent to browser
DEBUG - 2018-04-19 11:44:20 --> Total execution time: 0.1329
INFO - 2018-04-19 06:14:22 --> Config Class Initialized
INFO - 2018-04-19 06:14:22 --> Hooks Class Initialized
DEBUG - 2018-04-19 06:14:22 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:14:22 --> Utf8 Class Initialized
INFO - 2018-04-19 06:14:22 --> URI Class Initialized
INFO - 2018-04-19 06:14:22 --> Router Class Initialized
INFO - 2018-04-19 06:14:22 --> Output Class Initialized
INFO - 2018-04-19 06:14:22 --> Security Class Initialized
DEBUG - 2018-04-19 06:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:14:22 --> Input Class Initialized
INFO - 2018-04-19 06:14:22 --> Language Class Initialized
INFO - 2018-04-19 06:14:22 --> Language Class Initialized
INFO - 2018-04-19 06:14:22 --> Config Class Initialized
INFO - 2018-04-19 06:14:22 --> Loader Class Initialized
INFO - 2018-04-19 11:44:22 --> Helper loaded: url_helper
INFO - 2018-04-19 11:44:22 --> Helper loaded: notification_helper
INFO - 2018-04-19 11:44:22 --> Helper loaded: settings_helper
INFO - 2018-04-19 11:44:22 --> Helper loaded: permission_helper
INFO - 2018-04-19 11:44:22 --> Helper loaded: users_helper
INFO - 2018-04-19 11:44:22 --> Database Driver Class Initialized
DEBUG - 2018-04-19 11:44:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 11:44:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 11:44:22 --> Helper loaded: form_helper
INFO - 2018-04-19 11:44:22 --> Form Validation Class Initialized
INFO - 2018-04-19 11:44:22 --> Controller Class Initialized
INFO - 2018-04-19 11:44:22 --> Model Class Initialized
INFO - 2018-04-19 11:44:22 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 11:44:22 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 11:44:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 11:44:22 --> Model Class Initialized
INFO - 2018-04-19 11:44:22 --> Model Class Initialized
INFO - 2018-04-19 11:44:22 --> Model Class Initialized
INFO - 2018-04-19 11:44:22 --> Model Class Initialized
INFO - 2018-04-19 11:44:22 --> Model Class Initialized
INFO - 2018-04-19 11:44:22 --> Model Class Initialized
INFO - 2018-04-19 11:44:22 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 11:44:22 --> Final output sent to browser
DEBUG - 2018-04-19 11:44:22 --> Total execution time: 0.1078
INFO - 2018-04-19 06:14:22 --> Config Class Initialized
INFO - 2018-04-19 06:14:22 --> Hooks Class Initialized
DEBUG - 2018-04-19 06:14:22 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:14:22 --> Utf8 Class Initialized
INFO - 2018-04-19 06:14:22 --> URI Class Initialized
INFO - 2018-04-19 06:14:22 --> Router Class Initialized
INFO - 2018-04-19 06:14:22 --> Output Class Initialized
INFO - 2018-04-19 06:14:22 --> Security Class Initialized
DEBUG - 2018-04-19 06:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:14:22 --> Input Class Initialized
INFO - 2018-04-19 06:14:22 --> Language Class Initialized
INFO - 2018-04-19 06:14:22 --> Language Class Initialized
INFO - 2018-04-19 06:14:22 --> Config Class Initialized
INFO - 2018-04-19 06:14:22 --> Loader Class Initialized
INFO - 2018-04-19 11:44:22 --> Helper loaded: url_helper
INFO - 2018-04-19 11:44:22 --> Helper loaded: notification_helper
INFO - 2018-04-19 11:44:22 --> Helper loaded: settings_helper
INFO - 2018-04-19 11:44:22 --> Helper loaded: permission_helper
INFO - 2018-04-19 11:44:22 --> Helper loaded: users_helper
INFO - 2018-04-19 11:44:22 --> Database Driver Class Initialized
DEBUG - 2018-04-19 11:44:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 11:44:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 11:44:22 --> Helper loaded: form_helper
INFO - 2018-04-19 11:44:22 --> Form Validation Class Initialized
INFO - 2018-04-19 11:44:22 --> Controller Class Initialized
INFO - 2018-04-19 11:44:22 --> Model Class Initialized
INFO - 2018-04-19 11:44:22 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 11:44:22 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 11:44:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 11:44:22 --> Model Class Initialized
INFO - 2018-04-19 11:44:22 --> Model Class Initialized
INFO - 2018-04-19 11:44:22 --> Model Class Initialized
INFO - 2018-04-19 11:44:22 --> Model Class Initialized
INFO - 2018-04-19 11:44:22 --> Model Class Initialized
INFO - 2018-04-19 11:44:22 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 11:44:22 --> Model Class Initialized
INFO - 2018-04-19 11:44:22 --> Final output sent to browser
DEBUG - 2018-04-19 11:44:22 --> Total execution time: 0.1057
INFO - 2018-04-19 06:29:50 --> Config Class Initialized
INFO - 2018-04-19 06:29:50 --> Hooks Class Initialized
DEBUG - 2018-04-19 06:29:50 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:29:50 --> Utf8 Class Initialized
INFO - 2018-04-19 06:29:50 --> URI Class Initialized
INFO - 2018-04-19 06:29:50 --> Router Class Initialized
INFO - 2018-04-19 06:29:50 --> Output Class Initialized
INFO - 2018-04-19 06:29:50 --> Config Class Initialized
INFO - 2018-04-19 06:29:50 --> Hooks Class Initialized
INFO - 2018-04-19 06:29:50 --> Security Class Initialized
DEBUG - 2018-04-19 06:29:50 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:29:50 --> Utf8 Class Initialized
DEBUG - 2018-04-19 06:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:29:50 --> Input Class Initialized
INFO - 2018-04-19 06:29:50 --> URI Class Initialized
INFO - 2018-04-19 06:29:50 --> Config Class Initialized
INFO - 2018-04-19 06:29:50 --> Language Class Initialized
INFO - 2018-04-19 06:29:50 --> Hooks Class Initialized
DEBUG - 2018-04-19 06:29:50 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:29:50 --> Utf8 Class Initialized
INFO - 2018-04-19 06:29:50 --> Router Class Initialized
INFO - 2018-04-19 06:29:50 --> URI Class Initialized
INFO - 2018-04-19 06:29:50 --> Output Class Initialized
INFO - 2018-04-19 06:29:50 --> Config Class Initialized
INFO - 2018-04-19 06:29:50 --> Hooks Class Initialized
INFO - 2018-04-19 06:29:50 --> Security Class Initialized
INFO - 2018-04-19 06:29:50 --> Config Class Initialized
INFO - 2018-04-19 06:29:50 --> Hooks Class Initialized
INFO - 2018-04-19 06:29:50 --> Router Class Initialized
DEBUG - 2018-04-19 06:29:50 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:29:50 --> Utf8 Class Initialized
DEBUG - 2018-04-19 06:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:29:50 --> Input Class Initialized
INFO - 2018-04-19 06:29:50 --> Output Class Initialized
DEBUG - 2018-04-19 06:29:50 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:29:50 --> Utf8 Class Initialized
INFO - 2018-04-19 06:29:50 --> Language Class Initialized
INFO - 2018-04-19 06:29:50 --> URI Class Initialized
INFO - 2018-04-19 06:29:50 --> URI Class Initialized
INFO - 2018-04-19 06:29:50 --> Security Class Initialized
INFO - 2018-04-19 06:29:50 --> Language Class Initialized
INFO - 2018-04-19 06:29:50 --> Router Class Initialized
INFO - 2018-04-19 06:29:50 --> Config Class Initialized
INFO - 2018-04-19 06:29:50 --> Loader Class Initialized
DEBUG - 2018-04-19 06:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:29:50 --> Input Class Initialized
INFO - 2018-04-19 06:29:50 --> Language Class Initialized
INFO - 2018-04-19 06:29:50 --> Router Class Initialized
INFO - 2018-04-19 11:59:50 --> Helper loaded: url_helper
INFO - 2018-04-19 06:29:50 --> Output Class Initialized
INFO - 2018-04-19 11:59:50 --> Helper loaded: notification_helper
INFO - 2018-04-19 11:59:50 --> Helper loaded: settings_helper
INFO - 2018-04-19 06:29:50 --> Output Class Initialized
INFO - 2018-04-19 11:59:50 --> Helper loaded: permission_helper
INFO - 2018-04-19 11:59:50 --> Helper loaded: users_helper
INFO - 2018-04-19 06:29:50 --> Security Class Initialized
INFO - 2018-04-19 06:29:50 --> Security Class Initialized
DEBUG - 2018-04-19 06:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:29:50 --> Input Class Initialized
INFO - 2018-04-19 06:29:50 --> Language Class Initialized
DEBUG - 2018-04-19 06:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:29:50 --> Input Class Initialized
INFO - 2018-04-19 06:29:50 --> Language Class Initialized
INFO - 2018-04-19 06:29:50 --> Language Class Initialized
INFO - 2018-04-19 06:29:50 --> Config Class Initialized
INFO - 2018-04-19 06:29:50 --> Loader Class Initialized
INFO - 2018-04-19 11:59:50 --> Helper loaded: url_helper
INFO - 2018-04-19 11:59:50 --> Helper loaded: notification_helper
INFO - 2018-04-19 11:59:50 --> Database Driver Class Initialized
INFO - 2018-04-19 11:59:50 --> Helper loaded: settings_helper
INFO - 2018-04-19 11:59:50 --> Helper loaded: permission_helper
INFO - 2018-04-19 06:29:50 --> Language Class Initialized
INFO - 2018-04-19 06:29:50 --> Config Class Initialized
INFO - 2018-04-19 06:29:50 --> Loader Class Initialized
INFO - 2018-04-19 11:59:50 --> Helper loaded: users_helper
INFO - 2018-04-19 11:59:50 --> Helper loaded: url_helper
DEBUG - 2018-04-19 11:59:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 11:59:50 --> Helper loaded: notification_helper
INFO - 2018-04-19 11:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 11:59:50 --> Helper loaded: settings_helper
INFO - 2018-04-19 11:59:50 --> Helper loaded: permission_helper
INFO - 2018-04-19 11:59:50 --> Helper loaded: users_helper
INFO - 2018-04-19 06:29:50 --> Language Class Initialized
INFO - 2018-04-19 06:29:50 --> Config Class Initialized
INFO - 2018-04-19 06:29:50 --> Loader Class Initialized
INFO - 2018-04-19 06:29:50 --> Language Class Initialized
INFO - 2018-04-19 11:59:50 --> Helper loaded: url_helper
INFO - 2018-04-19 06:29:50 --> Config Class Initialized
INFO - 2018-04-19 06:29:50 --> Loader Class Initialized
INFO - 2018-04-19 11:59:50 --> Helper loaded: notification_helper
INFO - 2018-04-19 11:59:50 --> Helper loaded: form_helper
INFO - 2018-04-19 11:59:50 --> Helper loaded: settings_helper
INFO - 2018-04-19 11:59:50 --> Form Validation Class Initialized
INFO - 2018-04-19 11:59:50 --> Controller Class Initialized
INFO - 2018-04-19 11:59:50 --> Helper loaded: permission_helper
INFO - 2018-04-19 11:59:50 --> Helper loaded: url_helper
INFO - 2018-04-19 11:59:50 --> Helper loaded: users_helper
INFO - 2018-04-19 11:59:51 --> Helper loaded: notification_helper
INFO - 2018-04-19 11:59:51 --> Helper loaded: settings_helper
INFO - 2018-04-19 11:59:51 --> Database Driver Class Initialized
INFO - 2018-04-19 11:59:51 --> Helper loaded: permission_helper
INFO - 2018-04-19 11:59:51 --> Helper loaded: users_helper
INFO - 2018-04-19 11:59:51 --> Database Driver Class Initialized
DEBUG - 2018-04-19 11:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 11:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 11:59:51 --> Model Class Initialized
INFO - 2018-04-19 11:59:51 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 11:59:51 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-04-19 11:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 11:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 11:59:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 11:59:51 --> Model Class Initialized
INFO - 2018-04-19 11:59:51 --> Helper loaded: form_helper
INFO - 2018-04-19 11:59:51 --> Form Validation Class Initialized
INFO - 2018-04-19 11:59:51 --> Controller Class Initialized
INFO - 2018-04-19 11:59:51 --> Model Class Initialized
INFO - 2018-04-19 11:59:51 --> Database Driver Class Initialized
INFO - 2018-04-19 11:59:51 --> Model Class Initialized
INFO - 2018-04-19 11:59:51 --> Model Class Initialized
INFO - 2018-04-19 11:59:51 --> Model Class Initialized
INFO - 2018-04-19 11:59:51 --> Model Class Initialized
INFO - 2018-04-19 11:59:51 --> Model Class Initialized
INFO - 2018-04-19 11:59:51 --> Model Class Initialized
INFO - 2018-04-19 11:59:51 --> Database Driver Class Initialized
INFO - 2018-04-19 11:59:51 --> Model Class Initialized
INFO - 2018-04-19 11:59:51 --> Model Class Initialized
INFO - 2018-04-19 11:59:51 --> Helper loaded: form_helper
INFO - 2018-04-19 11:59:51 --> Form Validation Class Initialized
INFO - 2018-04-19 11:59:51 --> Controller Class Initialized
DEBUG - 2018-04-19 11:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 11:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 11:59:51 --> Model Class Initialized
INFO - 2018-04-19 11:59:51 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 11:59:51 --> Model Class Initialized
DEBUG - 2018-04-19 11:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 11:59:51 --> Model Class Initialized
INFO - 2018-04-19 11:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 11:59:51 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 11:59:51 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 11:59:51 --> Helper loaded: form_helper
INFO - 2018-04-19 11:59:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 11:59:51 --> Form Validation Class Initialized
INFO - 2018-04-19 11:59:51 --> Controller Class Initialized
INFO - 2018-04-19 11:59:51 --> Model Class Initialized
INFO - 2018-04-19 11:59:51 --> Helper loaded: inflector_helper
INFO - 2018-04-19 11:59:51 --> Model Class Initialized
INFO - 2018-04-19 11:59:51 --> Model Class Initialized
INFO - 2018-04-19 11:59:51 --> Model Class Initialized
INFO - 2018-04-19 11:59:51 --> Model Class Initialized
INFO - 2018-04-19 11:59:51 --> Helper loaded: form_helper
INFO - 2018-04-19 11:59:51 --> Model Class Initialized
INFO - 2018-04-19 11:59:51 --> Form Validation Class Initialized
INFO - 2018-04-19 11:59:51 --> Controller Class Initialized
INFO - 2018-04-19 11:59:51 --> Model Class Initialized
INFO - 2018-04-19 11:59:51 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-04-19 11:59:51 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 11:59:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 11:59:51 --> Model Class Initialized
INFO - 2018-04-19 11:59:51 --> Final output sent to browser
DEBUG - 2018-04-19 11:59:51 --> Total execution time: 0.1034
INFO - 2018-04-19 11:59:51 --> Model Class Initialized
INFO - 2018-04-19 11:59:51 --> Model Class Initialized
INFO - 2018-04-19 11:59:51 --> Final output sent to browser
DEBUG - 2018-04-19 11:59:51 --> Total execution time: 0.1188
INFO - 2018-04-19 11:59:51 --> Model Class Initialized
INFO - 2018-04-19 11:59:51 --> Model Class Initialized
INFO - 2018-04-19 11:59:51 --> Model Class Initialized
INFO - 2018-04-19 11:59:51 --> Helper loaded: inflector_helper
INFO - 2018-04-19 11:59:51 --> Model Class Initialized
INFO - 2018-04-19 11:59:51 --> Model Class Initialized
INFO - 2018-04-19 11:59:51 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 11:59:51 --> Model Class Initialized
DEBUG - 2018-04-19 11:59:51 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 11:59:51 --> Helper loaded: inflector_helper
INFO - 2018-04-19 11:59:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 11:59:51 --> Model Class Initialized
INFO - 2018-04-19 11:59:51 --> Model Class Initialized
DEBUG - 2018-04-19 11:59:51 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 11:59:51 --> Model Class Initialized
INFO - 2018-04-19 11:59:51 --> Model Class Initialized
INFO - 2018-04-19 11:59:51 --> Model Class Initialized
INFO - 2018-04-19 11:59:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 11:59:51 --> Model Class Initialized
INFO - 2018-04-19 11:59:51 --> Final output sent to browser
DEBUG - 2018-04-19 11:59:51 --> Total execution time: 0.1101
INFO - 2018-04-19 11:59:51 --> Model Class Initialized
INFO - 2018-04-19 11:59:51 --> Model Class Initialized
INFO - 2018-04-19 11:59:51 --> Model Class Initialized
INFO - 2018-04-19 11:59:51 --> Model Class Initialized
INFO - 2018-04-19 11:59:51 --> Model Class Initialized
INFO - 2018-04-19 11:59:51 --> Model Class Initialized
INFO - 2018-04-19 11:59:51 --> Model Class Initialized
INFO - 2018-04-19 11:59:51 --> Model Class Initialized
INFO - 2018-04-19 11:59:51 --> Model Class Initialized
INFO - 2018-04-19 11:59:51 --> Model Class Initialized
INFO - 2018-04-19 11:59:51 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 11:59:51 --> Model Class Initialized
INFO - 2018-04-19 11:59:51 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 11:59:51 --> Model Class Initialized
INFO - 2018-04-19 11:59:51 --> Model Class Initialized
INFO - 2018-04-19 11:59:51 --> Final output sent to browser
DEBUG - 2018-04-19 11:59:51 --> Total execution time: 0.1114
INFO - 2018-04-19 11:59:51 --> Final output sent to browser
DEBUG - 2018-04-19 11:59:51 --> Total execution time: 0.1270
INFO - 2018-04-19 06:30:38 --> Config Class Initialized
INFO - 2018-04-19 06:30:38 --> Hooks Class Initialized
DEBUG - 2018-04-19 06:30:38 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:30:38 --> Utf8 Class Initialized
INFO - 2018-04-19 06:30:38 --> URI Class Initialized
INFO - 2018-04-19 06:30:38 --> Router Class Initialized
INFO - 2018-04-19 06:30:38 --> Output Class Initialized
INFO - 2018-04-19 06:30:38 --> Security Class Initialized
DEBUG - 2018-04-19 06:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:30:38 --> Input Class Initialized
INFO - 2018-04-19 06:30:38 --> Language Class Initialized
INFO - 2018-04-19 06:30:38 --> Config Class Initialized
INFO - 2018-04-19 06:30:38 --> Hooks Class Initialized
INFO - 2018-04-19 06:30:38 --> Config Class Initialized
INFO - 2018-04-19 06:30:38 --> Hooks Class Initialized
INFO - 2018-04-19 06:30:38 --> Language Class Initialized
DEBUG - 2018-04-19 06:30:38 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:30:38 --> Config Class Initialized
INFO - 2018-04-19 06:30:38 --> Utf8 Class Initialized
INFO - 2018-04-19 06:30:38 --> Loader Class Initialized
DEBUG - 2018-04-19 06:30:38 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:30:38 --> Utf8 Class Initialized
INFO - 2018-04-19 12:00:38 --> Helper loaded: url_helper
INFO - 2018-04-19 06:30:38 --> URI Class Initialized
INFO - 2018-04-19 12:00:38 --> Helper loaded: notification_helper
INFO - 2018-04-19 12:00:38 --> Helper loaded: settings_helper
INFO - 2018-04-19 06:30:38 --> URI Class Initialized
INFO - 2018-04-19 12:00:38 --> Helper loaded: permission_helper
INFO - 2018-04-19 12:00:38 --> Helper loaded: users_helper
INFO - 2018-04-19 06:30:38 --> Router Class Initialized
INFO - 2018-04-19 06:30:38 --> Output Class Initialized
INFO - 2018-04-19 06:30:38 --> Security Class Initialized
INFO - 2018-04-19 06:30:38 --> Router Class Initialized
DEBUG - 2018-04-19 06:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:30:38 --> Input Class Initialized
INFO - 2018-04-19 06:30:38 --> Language Class Initialized
INFO - 2018-04-19 12:00:38 --> Database Driver Class Initialized
INFO - 2018-04-19 06:30:38 --> Output Class Initialized
INFO - 2018-04-19 06:30:38 --> Security Class Initialized
DEBUG - 2018-04-19 12:00:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 12:00:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-04-19 06:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:30:38 --> Input Class Initialized
INFO - 2018-04-19 06:30:38 --> Language Class Initialized
INFO - 2018-04-19 12:00:38 --> Helper loaded: form_helper
INFO - 2018-04-19 12:00:38 --> Form Validation Class Initialized
INFO - 2018-04-19 12:00:38 --> Controller Class Initialized
INFO - 2018-04-19 06:30:38 --> Language Class Initialized
INFO - 2018-04-19 06:30:38 --> Config Class Initialized
INFO - 2018-04-19 06:30:38 --> Loader Class Initialized
INFO - 2018-04-19 12:00:38 --> Helper loaded: url_helper
INFO - 2018-04-19 12:00:38 --> Model Class Initialized
INFO - 2018-04-19 12:00:38 --> Helper loaded: inflector_helper
INFO - 2018-04-19 12:00:38 --> Helper loaded: notification_helper
INFO - 2018-04-19 12:00:38 --> Helper loaded: settings_helper
INFO - 2018-04-19 12:00:38 --> Helper loaded: permission_helper
INFO - 2018-04-19 12:00:38 --> Helper loaded: users_helper
DEBUG - 2018-04-19 12:00:38 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 12:00:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 12:00:38 --> Model Class Initialized
INFO - 2018-04-19 12:00:38 --> Model Class Initialized
INFO - 2018-04-19 12:00:38 --> Model Class Initialized
INFO - 2018-04-19 12:00:38 --> Model Class Initialized
INFO - 2018-04-19 12:00:38 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 12:00:38 --> Final output sent to browser
DEBUG - 2018-04-19 12:00:38 --> Total execution time: 0.0905
INFO - 2018-04-19 06:30:38 --> Language Class Initialized
INFO - 2018-04-19 06:30:38 --> Config Class Initialized
INFO - 2018-04-19 06:30:38 --> Loader Class Initialized
INFO - 2018-04-19 12:00:38 --> Database Driver Class Initialized
INFO - 2018-04-19 12:00:38 --> Helper loaded: url_helper
INFO - 2018-04-19 12:00:38 --> Helper loaded: notification_helper
INFO - 2018-04-19 12:00:38 --> Helper loaded: settings_helper
INFO - 2018-04-19 12:00:38 --> Helper loaded: permission_helper
INFO - 2018-04-19 12:00:38 --> Helper loaded: users_helper
DEBUG - 2018-04-19 12:00:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 12:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 12:00:38 --> Helper loaded: form_helper
INFO - 2018-04-19 12:00:38 --> Form Validation Class Initialized
INFO - 2018-04-19 12:00:38 --> Controller Class Initialized
INFO - 2018-04-19 12:00:38 --> Model Class Initialized
INFO - 2018-04-19 12:00:38 --> Database Driver Class Initialized
INFO - 2018-04-19 12:00:38 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 12:00:38 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 12:00:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 12:00:38 --> Model Class Initialized
INFO - 2018-04-19 12:00:38 --> Model Class Initialized
DEBUG - 2018-04-19 12:00:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 12:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 12:00:38 --> Model Class Initialized
INFO - 2018-04-19 12:00:38 --> Model Class Initialized
INFO - 2018-04-19 12:00:38 --> Model Class Initialized
INFO - 2018-04-19 12:00:38 --> Model Class Initialized
INFO - 2018-04-19 12:00:38 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 12:00:38 --> Final output sent to browser
DEBUG - 2018-04-19 12:00:38 --> Total execution time: 0.0971
INFO - 2018-04-19 12:00:38 --> Helper loaded: form_helper
INFO - 2018-04-19 12:00:38 --> Form Validation Class Initialized
INFO - 2018-04-19 12:00:38 --> Controller Class Initialized
INFO - 2018-04-19 12:00:38 --> Model Class Initialized
INFO - 2018-04-19 12:00:38 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 12:00:38 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 12:00:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 12:00:38 --> Model Class Initialized
INFO - 2018-04-19 12:00:38 --> Model Class Initialized
INFO - 2018-04-19 12:00:38 --> Model Class Initialized
INFO - 2018-04-19 12:00:38 --> Model Class Initialized
INFO - 2018-04-19 12:00:38 --> Model Class Initialized
INFO - 2018-04-19 12:00:38 --> Model Class Initialized
INFO - 2018-04-19 12:00:38 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 12:00:38 --> Final output sent to browser
DEBUG - 2018-04-19 12:00:38 --> Total execution time: 0.1304
INFO - 2018-04-19 06:30:39 --> Config Class Initialized
INFO - 2018-04-19 06:30:39 --> Hooks Class Initialized
DEBUG - 2018-04-19 06:30:39 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:30:39 --> Utf8 Class Initialized
INFO - 2018-04-19 06:30:39 --> URI Class Initialized
INFO - 2018-04-19 06:30:39 --> Config Class Initialized
INFO - 2018-04-19 06:30:39 --> Hooks Class Initialized
DEBUG - 2018-04-19 06:30:39 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:30:39 --> Utf8 Class Initialized
INFO - 2018-04-19 06:30:39 --> Router Class Initialized
INFO - 2018-04-19 06:30:39 --> URI Class Initialized
INFO - 2018-04-19 06:30:39 --> Output Class Initialized
INFO - 2018-04-19 06:30:39 --> Router Class Initialized
INFO - 2018-04-19 06:30:39 --> Security Class Initialized
INFO - 2018-04-19 06:30:39 --> Output Class Initialized
DEBUG - 2018-04-19 06:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:30:39 --> Input Class Initialized
INFO - 2018-04-19 06:30:39 --> Language Class Initialized
INFO - 2018-04-19 06:30:39 --> Security Class Initialized
DEBUG - 2018-04-19 06:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:30:39 --> Input Class Initialized
INFO - 2018-04-19 06:30:39 --> Language Class Initialized
INFO - 2018-04-19 06:30:39 --> Language Class Initialized
INFO - 2018-04-19 06:30:39 --> Config Class Initialized
INFO - 2018-04-19 06:30:39 --> Loader Class Initialized
INFO - 2018-04-19 12:00:39 --> Helper loaded: url_helper
INFO - 2018-04-19 12:00:39 --> Helper loaded: notification_helper
INFO - 2018-04-19 12:00:39 --> Helper loaded: settings_helper
INFO - 2018-04-19 12:00:39 --> Helper loaded: permission_helper
INFO - 2018-04-19 12:00:39 --> Helper loaded: users_helper
INFO - 2018-04-19 06:30:39 --> Language Class Initialized
INFO - 2018-04-19 06:30:39 --> Config Class Initialized
INFO - 2018-04-19 06:30:39 --> Loader Class Initialized
INFO - 2018-04-19 12:00:39 --> Helper loaded: url_helper
INFO - 2018-04-19 12:00:39 --> Helper loaded: notification_helper
INFO - 2018-04-19 12:00:39 --> Helper loaded: settings_helper
INFO - 2018-04-19 12:00:39 --> Helper loaded: permission_helper
INFO - 2018-04-19 12:00:39 --> Helper loaded: users_helper
INFO - 2018-04-19 12:00:39 --> Database Driver Class Initialized
DEBUG - 2018-04-19 12:00:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 12:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 12:00:39 --> Database Driver Class Initialized
INFO - 2018-04-19 12:00:39 --> Helper loaded: form_helper
INFO - 2018-04-19 12:00:39 --> Form Validation Class Initialized
INFO - 2018-04-19 12:00:39 --> Controller Class Initialized
DEBUG - 2018-04-19 12:00:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 12:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 12:00:39 --> Helper loaded: form_helper
INFO - 2018-04-19 12:00:39 --> Form Validation Class Initialized
INFO - 2018-04-19 12:00:39 --> Controller Class Initialized
INFO - 2018-04-19 12:00:39 --> Model Class Initialized
INFO - 2018-04-19 12:00:39 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 12:00:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 12:00:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 12:00:39 --> Model Class Initialized
INFO - 2018-04-19 12:00:39 --> Model Class Initialized
INFO - 2018-04-19 12:00:39 --> Model Class Initialized
INFO - 2018-04-19 12:00:39 --> Model Class Initialized
INFO - 2018-04-19 12:00:39 --> Model Class Initialized
INFO - 2018-04-19 12:00:39 --> Model Class Initialized
INFO - 2018-04-19 12:00:39 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 12:00:39 --> Helper loaded: inflector_helper
INFO - 2018-04-19 12:00:39 --> Model Class Initialized
DEBUG - 2018-04-19 12:00:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 12:00:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 12:00:40 --> Model Class Initialized
INFO - 2018-04-19 12:00:40 --> Model Class Initialized
INFO - 2018-04-19 12:00:40 --> Final output sent to browser
DEBUG - 2018-04-19 12:00:40 --> Total execution time: 0.1419
INFO - 2018-04-19 12:00:40 --> Model Class Initialized
INFO - 2018-04-19 12:00:40 --> Model Class Initialized
INFO - 2018-04-19 12:00:40 --> Model Class Initialized
INFO - 2018-04-19 12:00:40 --> Model Class Initialized
INFO - 2018-04-19 12:00:40 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 12:00:40 --> Final output sent to browser
DEBUG - 2018-04-19 12:00:40 --> Total execution time: 0.1365
INFO - 2018-04-19 06:30:53 --> Config Class Initialized
INFO - 2018-04-19 06:30:53 --> Hooks Class Initialized
DEBUG - 2018-04-19 06:30:53 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:30:53 --> Utf8 Class Initialized
INFO - 2018-04-19 06:30:53 --> URI Class Initialized
INFO - 2018-04-19 06:30:53 --> Router Class Initialized
INFO - 2018-04-19 06:30:53 --> Output Class Initialized
INFO - 2018-04-19 06:30:53 --> Security Class Initialized
DEBUG - 2018-04-19 06:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:30:53 --> Input Class Initialized
INFO - 2018-04-19 06:30:53 --> Language Class Initialized
INFO - 2018-04-19 06:30:53 --> Language Class Initialized
INFO - 2018-04-19 06:30:53 --> Config Class Initialized
INFO - 2018-04-19 06:30:53 --> Loader Class Initialized
INFO - 2018-04-19 12:00:53 --> Helper loaded: url_helper
INFO - 2018-04-19 12:00:53 --> Helper loaded: notification_helper
INFO - 2018-04-19 12:00:53 --> Helper loaded: settings_helper
INFO - 2018-04-19 12:00:53 --> Helper loaded: permission_helper
INFO - 2018-04-19 12:00:53 --> Helper loaded: users_helper
INFO - 2018-04-19 12:00:53 --> Database Driver Class Initialized
DEBUG - 2018-04-19 12:00:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 12:00:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 12:00:53 --> Helper loaded: form_helper
INFO - 2018-04-19 12:00:53 --> Form Validation Class Initialized
INFO - 2018-04-19 12:00:53 --> Controller Class Initialized
INFO - 2018-04-19 12:00:53 --> Model Class Initialized
INFO - 2018-04-19 12:00:53 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 12:00:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 12:00:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 12:00:53 --> Model Class Initialized
INFO - 2018-04-19 12:00:53 --> Model Class Initialized
INFO - 2018-04-19 12:00:53 --> Model Class Initialized
INFO - 2018-04-19 12:00:53 --> Model Class Initialized
INFO - 2018-04-19 12:00:53 --> Model Class Initialized
INFO - 2018-04-19 12:00:53 --> Model Class Initialized
INFO - 2018-04-19 12:00:53 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 12:00:53 --> Final output sent to browser
DEBUG - 2018-04-19 12:00:53 --> Total execution time: 0.1199
INFO - 2018-04-19 06:33:26 --> Config Class Initialized
INFO - 2018-04-19 06:33:26 --> Hooks Class Initialized
DEBUG - 2018-04-19 06:33:26 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:33:26 --> Utf8 Class Initialized
INFO - 2018-04-19 06:33:26 --> URI Class Initialized
INFO - 2018-04-19 06:33:26 --> Router Class Initialized
INFO - 2018-04-19 06:33:26 --> Output Class Initialized
INFO - 2018-04-19 06:33:26 --> Security Class Initialized
DEBUG - 2018-04-19 06:33:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:33:26 --> Input Class Initialized
INFO - 2018-04-19 06:33:26 --> Language Class Initialized
INFO - 2018-04-19 06:33:26 --> Config Class Initialized
INFO - 2018-04-19 06:33:26 --> Hooks Class Initialized
DEBUG - 2018-04-19 06:33:26 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:33:26 --> Utf8 Class Initialized
INFO - 2018-04-19 06:33:26 --> URI Class Initialized
INFO - 2018-04-19 06:33:26 --> Router Class Initialized
INFO - 2018-04-19 06:33:26 --> Output Class Initialized
INFO - 2018-04-19 06:33:26 --> Language Class Initialized
INFO - 2018-04-19 06:33:26 --> Config Class Initialized
INFO - 2018-04-19 06:33:26 --> Loader Class Initialized
INFO - 2018-04-19 12:03:26 --> Helper loaded: url_helper
INFO - 2018-04-19 06:33:26 --> Security Class Initialized
INFO - 2018-04-19 12:03:26 --> Helper loaded: notification_helper
INFO - 2018-04-19 12:03:26 --> Helper loaded: settings_helper
INFO - 2018-04-19 12:03:26 --> Helper loaded: permission_helper
INFO - 2018-04-19 12:03:26 --> Helper loaded: users_helper
DEBUG - 2018-04-19 06:33:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:33:26 --> Input Class Initialized
INFO - 2018-04-19 06:33:26 --> Language Class Initialized
INFO - 2018-04-19 12:03:26 --> Database Driver Class Initialized
DEBUG - 2018-04-19 12:03:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 12:03:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 06:33:26 --> Config Class Initialized
INFO - 2018-04-19 06:33:26 --> Hooks Class Initialized
INFO - 2018-04-19 06:33:26 --> Config Class Initialized
INFO - 2018-04-19 06:33:26 --> Hooks Class Initialized
DEBUG - 2018-04-19 06:33:26 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:33:26 --> Utf8 Class Initialized
INFO - 2018-04-19 06:33:26 --> Language Class Initialized
INFO - 2018-04-19 06:33:26 --> Config Class Initialized
INFO - 2018-04-19 06:33:26 --> Loader Class Initialized
INFO - 2018-04-19 12:03:26 --> Helper loaded: form_helper
INFO - 2018-04-19 12:03:26 --> Form Validation Class Initialized
INFO - 2018-04-19 12:03:26 --> Controller Class Initialized
INFO - 2018-04-19 06:33:26 --> URI Class Initialized
INFO - 2018-04-19 12:03:26 --> Helper loaded: url_helper
DEBUG - 2018-04-19 06:33:26 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:33:26 --> Utf8 Class Initialized
INFO - 2018-04-19 12:03:26 --> Helper loaded: notification_helper
INFO - 2018-04-19 12:03:26 --> Helper loaded: settings_helper
INFO - 2018-04-19 06:33:26 --> URI Class Initialized
INFO - 2018-04-19 12:03:26 --> Helper loaded: permission_helper
INFO - 2018-04-19 12:03:26 --> Helper loaded: users_helper
INFO - 2018-04-19 12:03:26 --> Model Class Initialized
INFO - 2018-04-19 12:03:26 --> Helper loaded: inflector_helper
INFO - 2018-04-19 06:33:26 --> Router Class Initialized
INFO - 2018-04-19 06:33:26 --> Router Class Initialized
DEBUG - 2018-04-19 12:03:26 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 06:33:26 --> Config Class Initialized
INFO - 2018-04-19 06:33:26 --> Hooks Class Initialized
INFO - 2018-04-19 12:03:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 12:03:26 --> Model Class Initialized
INFO - 2018-04-19 06:33:26 --> Output Class Initialized
INFO - 2018-04-19 12:03:26 --> Model Class Initialized
DEBUG - 2018-04-19 06:33:26 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:33:26 --> Utf8 Class Initialized
INFO - 2018-04-19 12:03:26 --> Model Class Initialized
INFO - 2018-04-19 12:03:26 --> Model Class Initialized
INFO - 2018-04-19 12:03:26 --> Model Class Initialized
INFO - 2018-04-19 12:03:26 --> Model Class Initialized
INFO - 2018-04-19 06:33:26 --> Output Class Initialized
INFO - 2018-04-19 12:03:26 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 06:33:26 --> Security Class Initialized
INFO - 2018-04-19 06:33:26 --> URI Class Initialized
DEBUG - 2018-04-19 06:33:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:33:26 --> Input Class Initialized
INFO - 2018-04-19 06:33:26 --> Security Class Initialized
INFO - 2018-04-19 06:33:26 --> Language Class Initialized
INFO - 2018-04-19 12:03:26 --> Final output sent to browser
DEBUG - 2018-04-19 12:03:26 --> Total execution time: 0.0893
INFO - 2018-04-19 06:33:26 --> Router Class Initialized
DEBUG - 2018-04-19 06:33:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:33:26 --> Input Class Initialized
INFO - 2018-04-19 06:33:26 --> Language Class Initialized
INFO - 2018-04-19 06:33:26 --> Output Class Initialized
INFO - 2018-04-19 12:03:26 --> Database Driver Class Initialized
INFO - 2018-04-19 06:33:26 --> Security Class Initialized
DEBUG - 2018-04-19 06:33:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:33:26 --> Input Class Initialized
DEBUG - 2018-04-19 12:03:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 06:33:26 --> Language Class Initialized
INFO - 2018-04-19 12:03:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 06:33:26 --> Language Class Initialized
INFO - 2018-04-19 06:33:26 --> Config Class Initialized
INFO - 2018-04-19 06:33:26 --> Loader Class Initialized
INFO - 2018-04-19 12:03:26 --> Helper loaded: url_helper
INFO - 2018-04-19 12:03:26 --> Helper loaded: notification_helper
INFO - 2018-04-19 12:03:26 --> Helper loaded: settings_helper
INFO - 2018-04-19 12:03:26 --> Helper loaded: permission_helper
INFO - 2018-04-19 12:03:26 --> Helper loaded: users_helper
INFO - 2018-04-19 06:33:26 --> Language Class Initialized
INFO - 2018-04-19 06:33:26 --> Config Class Initialized
INFO - 2018-04-19 06:33:26 --> Loader Class Initialized
INFO - 2018-04-19 12:03:26 --> Helper loaded: form_helper
INFO - 2018-04-19 12:03:26 --> Form Validation Class Initialized
INFO - 2018-04-19 12:03:26 --> Controller Class Initialized
INFO - 2018-04-19 12:03:26 --> Helper loaded: url_helper
INFO - 2018-04-19 12:03:26 --> Helper loaded: notification_helper
INFO - 2018-04-19 12:03:26 --> Helper loaded: settings_helper
INFO - 2018-04-19 12:03:26 --> Helper loaded: permission_helper
INFO - 2018-04-19 12:03:26 --> Helper loaded: users_helper
INFO - 2018-04-19 12:03:26 --> Database Driver Class Initialized
INFO - 2018-04-19 12:03:26 --> Model Class Initialized
INFO - 2018-04-19 12:03:26 --> Helper loaded: inflector_helper
INFO - 2018-04-19 06:33:26 --> Language Class Initialized
INFO - 2018-04-19 06:33:26 --> Config Class Initialized
INFO - 2018-04-19 06:33:26 --> Loader Class Initialized
DEBUG - 2018-04-19 12:03:26 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-04-19 12:03:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 12:03:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 12:03:26 --> Helper loaded: url_helper
INFO - 2018-04-19 12:03:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 12:03:26 --> Helper loaded: notification_helper
INFO - 2018-04-19 12:03:26 --> Helper loaded: settings_helper
INFO - 2018-04-19 12:03:26 --> Helper loaded: permission_helper
INFO - 2018-04-19 12:03:26 --> Model Class Initialized
INFO - 2018-04-19 12:03:26 --> Helper loaded: users_helper
INFO - 2018-04-19 12:03:26 --> Model Class Initialized
INFO - 2018-04-19 12:03:26 --> Database Driver Class Initialized
INFO - 2018-04-19 12:03:26 --> Model Class Initialized
INFO - 2018-04-19 12:03:26 --> Model Class Initialized
INFO - 2018-04-19 12:03:26 --> Model Class Initialized
INFO - 2018-04-19 12:03:26 --> Model Class Initialized
INFO - 2018-04-19 12:03:26 --> Model Class Initialized
INFO - 2018-04-19 12:03:26 --> Model Class Initialized
INFO - 2018-04-19 12:03:26 --> Model Class Initialized
INFO - 2018-04-19 12:03:26 --> Model Class Initialized
INFO - 2018-04-19 12:03:26 --> Helper loaded: form_helper
INFO - 2018-04-19 12:03:26 --> Form Validation Class Initialized
INFO - 2018-04-19 12:03:26 --> Controller Class Initialized
DEBUG - 2018-04-19 12:03:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 12:03:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 12:03:26 --> Model Class Initialized
INFO - 2018-04-19 12:03:26 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 12:03:26 --> Model Class Initialized
INFO - 2018-04-19 12:03:26 --> Database Driver Class Initialized
INFO - 2018-04-19 12:03:26 --> Helper loaded: form_helper
INFO - 2018-04-19 12:03:26 --> Form Validation Class Initialized
INFO - 2018-04-19 12:03:26 --> Controller Class Initialized
INFO - 2018-04-19 12:03:26 --> Model Class Initialized
INFO - 2018-04-19 12:03:26 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 12:03:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 12:03:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-04-19 12:03:26 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 12:03:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 12:03:26 --> Model Class Initialized
INFO - 2018-04-19 12:03:26 --> Model Class Initialized
INFO - 2018-04-19 12:03:26 --> Model Class Initialized
INFO - 2018-04-19 12:03:26 --> Helper loaded: inflector_helper
INFO - 2018-04-19 12:03:26 --> Helper loaded: form_helper
INFO - 2018-04-19 12:03:26 --> Form Validation Class Initialized
INFO - 2018-04-19 12:03:26 --> Controller Class Initialized
INFO - 2018-04-19 12:03:26 --> Model Class Initialized
INFO - 2018-04-19 12:03:26 --> Model Class Initialized
INFO - 2018-04-19 12:03:26 --> Model Class Initialized
INFO - 2018-04-19 12:03:26 --> Model Class Initialized
INFO - 2018-04-19 12:03:26 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-04-19 12:03:26 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 12:03:26 --> Final output sent to browser
DEBUG - 2018-04-19 12:03:26 --> Total execution time: 0.1374
INFO - 2018-04-19 12:03:26 --> Model Class Initialized
INFO - 2018-04-19 12:03:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 12:03:26 --> Model Class Initialized
INFO - 2018-04-19 12:03:26 --> Final output sent to browser
INFO - 2018-04-19 12:03:26 --> Model Class Initialized
DEBUG - 2018-04-19 12:03:26 --> Total execution time: 0.0946
INFO - 2018-04-19 12:03:26 --> Model Class Initialized
INFO - 2018-04-19 12:03:26 --> Model Class Initialized
INFO - 2018-04-19 12:03:26 --> Model Class Initialized
INFO - 2018-04-19 12:03:26 --> Helper loaded: inflector_helper
INFO - 2018-04-19 12:03:26 --> Model Class Initialized
INFO - 2018-04-19 12:03:26 --> Model Class Initialized
INFO - 2018-04-19 12:03:26 --> Model Class Initialized
INFO - 2018-04-19 12:03:26 --> Model Class Initialized
INFO - 2018-04-19 12:03:26 --> Model Class Initialized
INFO - 2018-04-19 12:03:26 --> Model Class Initialized
DEBUG - 2018-04-19 12:03:26 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 12:03:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 12:03:26 --> Model Class Initialized
INFO - 2018-04-19 12:03:26 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 12:03:26 --> Model Class Initialized
INFO - 2018-04-19 12:03:26 --> Model Class Initialized
INFO - 2018-04-19 12:03:26 --> Model Class Initialized
INFO - 2018-04-19 12:03:26 --> Model Class Initialized
INFO - 2018-04-19 12:03:26 --> Model Class Initialized
INFO - 2018-04-19 12:03:26 --> Model Class Initialized
INFO - 2018-04-19 12:03:26 --> Model Class Initialized
INFO - 2018-04-19 12:03:26 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 12:03:26 --> Model Class Initialized
INFO - 2018-04-19 12:03:26 --> Final output sent to browser
DEBUG - 2018-04-19 12:03:26 --> Total execution time: 0.0973
INFO - 2018-04-19 12:03:26 --> Final output sent to browser
DEBUG - 2018-04-19 12:03:26 --> Total execution time: 0.1278
INFO - 2018-04-19 06:33:37 --> Config Class Initialized
INFO - 2018-04-19 06:33:37 --> Hooks Class Initialized
INFO - 2018-04-19 06:33:37 --> Config Class Initialized
INFO - 2018-04-19 06:33:37 --> Hooks Class Initialized
DEBUG - 2018-04-19 06:33:37 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:33:37 --> Utf8 Class Initialized
INFO - 2018-04-19 06:33:37 --> URI Class Initialized
DEBUG - 2018-04-19 06:33:37 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:33:37 --> Utf8 Class Initialized
INFO - 2018-04-19 06:33:37 --> URI Class Initialized
INFO - 2018-04-19 06:33:37 --> Router Class Initialized
INFO - 2018-04-19 06:33:37 --> Router Class Initialized
INFO - 2018-04-19 06:33:37 --> Output Class Initialized
INFO - 2018-04-19 06:33:37 --> Output Class Initialized
INFO - 2018-04-19 06:33:37 --> Security Class Initialized
INFO - 2018-04-19 06:33:37 --> Security Class Initialized
DEBUG - 2018-04-19 06:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:33:37 --> Input Class Initialized
INFO - 2018-04-19 06:33:37 --> Language Class Initialized
DEBUG - 2018-04-19 06:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:33:37 --> Input Class Initialized
INFO - 2018-04-19 06:33:37 --> Language Class Initialized
INFO - 2018-04-19 06:33:37 --> Config Class Initialized
INFO - 2018-04-19 06:33:37 --> Hooks Class Initialized
DEBUG - 2018-04-19 06:33:37 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:33:37 --> Utf8 Class Initialized
INFO - 2018-04-19 06:33:37 --> URI Class Initialized
INFO - 2018-04-19 06:33:37 --> Router Class Initialized
INFO - 2018-04-19 06:33:37 --> Output Class Initialized
INFO - 2018-04-19 06:33:37 --> Language Class Initialized
INFO - 2018-04-19 06:33:37 --> Config Class Initialized
INFO - 2018-04-19 06:33:37 --> Loader Class Initialized
INFO - 2018-04-19 06:33:37 --> Security Class Initialized
INFO - 2018-04-19 12:03:37 --> Helper loaded: url_helper
INFO - 2018-04-19 12:03:37 --> Helper loaded: notification_helper
INFO - 2018-04-19 12:03:37 --> Helper loaded: settings_helper
DEBUG - 2018-04-19 06:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:33:37 --> Input Class Initialized
INFO - 2018-04-19 06:33:37 --> Language Class Initialized
INFO - 2018-04-19 06:33:37 --> Config Class Initialized
INFO - 2018-04-19 12:03:37 --> Helper loaded: permission_helper
INFO - 2018-04-19 06:33:37 --> Loader Class Initialized
INFO - 2018-04-19 06:33:37 --> Language Class Initialized
INFO - 2018-04-19 12:03:37 --> Helper loaded: users_helper
INFO - 2018-04-19 12:03:37 --> Helper loaded: url_helper
INFO - 2018-04-19 12:03:37 --> Helper loaded: notification_helper
INFO - 2018-04-19 12:03:37 --> Helper loaded: settings_helper
INFO - 2018-04-19 12:03:37 --> Helper loaded: permission_helper
INFO - 2018-04-19 12:03:37 --> Helper loaded: users_helper
INFO - 2018-04-19 12:03:37 --> Database Driver Class Initialized
INFO - 2018-04-19 12:03:37 --> Database Driver Class Initialized
INFO - 2018-04-19 06:33:37 --> Language Class Initialized
INFO - 2018-04-19 06:33:37 --> Config Class Initialized
INFO - 2018-04-19 06:33:37 --> Loader Class Initialized
DEBUG - 2018-04-19 12:03:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 12:03:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 12:03:37 --> Helper loaded: url_helper
INFO - 2018-04-19 12:03:37 --> Helper loaded: notification_helper
INFO - 2018-04-19 12:03:37 --> Helper loaded: settings_helper
INFO - 2018-04-19 12:03:37 --> Helper loaded: permission_helper
DEBUG - 2018-04-19 12:03:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 12:03:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 12:03:37 --> Helper loaded: users_helper
INFO - 2018-04-19 12:03:37 --> Helper loaded: form_helper
INFO - 2018-04-19 12:03:37 --> Form Validation Class Initialized
INFO - 2018-04-19 12:03:37 --> Controller Class Initialized
INFO - 2018-04-19 12:03:37 --> Helper loaded: form_helper
INFO - 2018-04-19 12:03:37 --> Form Validation Class Initialized
INFO - 2018-04-19 12:03:37 --> Controller Class Initialized
INFO - 2018-04-19 12:03:37 --> Database Driver Class Initialized
INFO - 2018-04-19 12:03:37 --> Model Class Initialized
INFO - 2018-04-19 12:03:37 --> Helper loaded: inflector_helper
INFO - 2018-04-19 12:03:37 --> Model Class Initialized
INFO - 2018-04-19 12:03:37 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 12:03:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-04-19 12:03:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 12:03:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 12:03:37 --> Language file loaded: language/english/rest_controller_lang.php
DEBUG - 2018-04-19 12:03:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 12:03:37 --> Model Class Initialized
INFO - 2018-04-19 12:03:37 --> Model Class Initialized
INFO - 2018-04-19 12:03:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 12:03:37 --> Model Class Initialized
INFO - 2018-04-19 12:03:37 --> Model Class Initialized
INFO - 2018-04-19 12:03:37 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 12:03:37 --> Model Class Initialized
INFO - 2018-04-19 12:03:37 --> Model Class Initialized
INFO - 2018-04-19 12:03:37 --> Model Class Initialized
INFO - 2018-04-19 12:03:37 --> Model Class Initialized
INFO - 2018-04-19 12:03:37 --> Model Class Initialized
INFO - 2018-04-19 12:03:37 --> Model Class Initialized
INFO - 2018-04-19 12:03:37 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 12:03:37 --> Final output sent to browser
DEBUG - 2018-04-19 12:03:37 --> Total execution time: 0.1035
INFO - 2018-04-19 12:03:37 --> Helper loaded: form_helper
INFO - 2018-04-19 12:03:37 --> Form Validation Class Initialized
INFO - 2018-04-19 12:03:37 --> Controller Class Initialized
INFO - 2018-04-19 12:03:37 --> Final output sent to browser
DEBUG - 2018-04-19 12:03:37 --> Total execution time: 0.1029
INFO - 2018-04-19 12:03:37 --> Model Class Initialized
INFO - 2018-04-19 12:03:37 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 12:03:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 12:03:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 12:03:37 --> Model Class Initialized
INFO - 2018-04-19 12:03:37 --> Model Class Initialized
INFO - 2018-04-19 12:03:37 --> Model Class Initialized
INFO - 2018-04-19 12:03:37 --> Model Class Initialized
INFO - 2018-04-19 12:03:37 --> Model Class Initialized
INFO - 2018-04-19 12:03:37 --> Model Class Initialized
INFO - 2018-04-19 12:03:37 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 12:03:37 --> Final output sent to browser
DEBUG - 2018-04-19 12:03:37 --> Total execution time: 0.1030
INFO - 2018-04-19 06:33:38 --> Config Class Initialized
INFO - 2018-04-19 06:33:38 --> Hooks Class Initialized
DEBUG - 2018-04-19 06:33:38 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:33:38 --> Utf8 Class Initialized
INFO - 2018-04-19 06:33:38 --> URI Class Initialized
INFO - 2018-04-19 06:33:38 --> Router Class Initialized
INFO - 2018-04-19 06:33:38 --> Config Class Initialized
INFO - 2018-04-19 06:33:38 --> Hooks Class Initialized
INFO - 2018-04-19 06:33:38 --> Output Class Initialized
INFO - 2018-04-19 06:33:38 --> Security Class Initialized
DEBUG - 2018-04-19 06:33:38 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:33:38 --> Utf8 Class Initialized
INFO - 2018-04-19 06:33:38 --> URI Class Initialized
DEBUG - 2018-04-19 06:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:33:38 --> Input Class Initialized
INFO - 2018-04-19 06:33:38 --> Language Class Initialized
INFO - 2018-04-19 06:33:38 --> Router Class Initialized
INFO - 2018-04-19 06:33:38 --> Output Class Initialized
INFO - 2018-04-19 06:33:38 --> Security Class Initialized
DEBUG - 2018-04-19 06:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:33:38 --> Input Class Initialized
INFO - 2018-04-19 06:33:38 --> Language Class Initialized
INFO - 2018-04-19 06:33:38 --> Language Class Initialized
INFO - 2018-04-19 06:33:38 --> Config Class Initialized
INFO - 2018-04-19 06:33:38 --> Loader Class Initialized
INFO - 2018-04-19 12:03:38 --> Helper loaded: url_helper
INFO - 2018-04-19 12:03:38 --> Helper loaded: notification_helper
INFO - 2018-04-19 12:03:38 --> Helper loaded: settings_helper
INFO - 2018-04-19 12:03:38 --> Helper loaded: permission_helper
INFO - 2018-04-19 12:03:38 --> Helper loaded: users_helper
INFO - 2018-04-19 06:33:38 --> Language Class Initialized
INFO - 2018-04-19 06:33:38 --> Config Class Initialized
INFO - 2018-04-19 06:33:38 --> Loader Class Initialized
INFO - 2018-04-19 12:03:38 --> Helper loaded: url_helper
INFO - 2018-04-19 12:03:38 --> Helper loaded: notification_helper
INFO - 2018-04-19 12:03:38 --> Database Driver Class Initialized
INFO - 2018-04-19 12:03:38 --> Helper loaded: settings_helper
INFO - 2018-04-19 12:03:38 --> Helper loaded: permission_helper
INFO - 2018-04-19 12:03:38 --> Helper loaded: users_helper
DEBUG - 2018-04-19 12:03:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 12:03:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 12:03:38 --> Database Driver Class Initialized
DEBUG - 2018-04-19 12:03:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 12:03:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 12:03:38 --> Helper loaded: form_helper
INFO - 2018-04-19 12:03:38 --> Form Validation Class Initialized
INFO - 2018-04-19 12:03:38 --> Controller Class Initialized
INFO - 2018-04-19 12:03:39 --> Helper loaded: form_helper
INFO - 2018-04-19 12:03:39 --> Form Validation Class Initialized
INFO - 2018-04-19 12:03:39 --> Controller Class Initialized
INFO - 2018-04-19 12:03:39 --> Model Class Initialized
INFO - 2018-04-19 12:03:39 --> Helper loaded: inflector_helper
INFO - 2018-04-19 12:03:39 --> Model Class Initialized
INFO - 2018-04-19 12:03:39 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 12:03:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-04-19 12:03:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 12:03:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 12:03:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 12:03:39 --> Model Class Initialized
INFO - 2018-04-19 12:03:39 --> Model Class Initialized
INFO - 2018-04-19 12:03:39 --> Model Class Initialized
INFO - 2018-04-19 12:03:39 --> Model Class Initialized
INFO - 2018-04-19 12:03:39 --> Model Class Initialized
INFO - 2018-04-19 12:03:39 --> Model Class Initialized
INFO - 2018-04-19 12:03:39 --> Model Class Initialized
INFO - 2018-04-19 12:03:39 --> Model Class Initialized
INFO - 2018-04-19 12:03:39 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 12:03:39 --> Model Class Initialized
INFO - 2018-04-19 12:03:39 --> Model Class Initialized
INFO - 2018-04-19 12:03:39 --> Model Class Initialized
INFO - 2018-04-19 12:03:39 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 12:03:39 --> Final output sent to browser
DEBUG - 2018-04-19 12:03:39 --> Total execution time: 0.0968
INFO - 2018-04-19 12:03:39 --> Model Class Initialized
INFO - 2018-04-19 12:03:39 --> Final output sent to browser
DEBUG - 2018-04-19 12:03:39 --> Total execution time: 0.1186
INFO - 2018-04-19 06:33:55 --> Config Class Initialized
INFO - 2018-04-19 06:33:55 --> Hooks Class Initialized
DEBUG - 2018-04-19 06:33:55 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:33:55 --> Utf8 Class Initialized
INFO - 2018-04-19 06:33:55 --> URI Class Initialized
INFO - 2018-04-19 06:33:55 --> Router Class Initialized
INFO - 2018-04-19 06:33:55 --> Output Class Initialized
INFO - 2018-04-19 06:33:55 --> Security Class Initialized
DEBUG - 2018-04-19 06:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:33:55 --> Input Class Initialized
INFO - 2018-04-19 06:33:55 --> Language Class Initialized
INFO - 2018-04-19 06:33:55 --> Language Class Initialized
INFO - 2018-04-19 06:33:55 --> Config Class Initialized
INFO - 2018-04-19 06:33:55 --> Loader Class Initialized
INFO - 2018-04-19 12:03:55 --> Helper loaded: url_helper
INFO - 2018-04-19 12:03:55 --> Helper loaded: notification_helper
INFO - 2018-04-19 12:03:55 --> Helper loaded: settings_helper
INFO - 2018-04-19 12:03:55 --> Helper loaded: permission_helper
INFO - 2018-04-19 12:03:55 --> Helper loaded: users_helper
INFO - 2018-04-19 12:03:55 --> Database Driver Class Initialized
DEBUG - 2018-04-19 12:03:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 12:03:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 12:03:55 --> Helper loaded: form_helper
INFO - 2018-04-19 12:03:55 --> Form Validation Class Initialized
INFO - 2018-04-19 12:03:55 --> Controller Class Initialized
INFO - 2018-04-19 12:03:55 --> Model Class Initialized
INFO - 2018-04-19 12:03:55 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 12:03:55 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 12:03:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 12:03:55 --> Model Class Initialized
INFO - 2018-04-19 12:03:55 --> Model Class Initialized
INFO - 2018-04-19 12:03:55 --> Model Class Initialized
INFO - 2018-04-19 12:03:55 --> Model Class Initialized
INFO - 2018-04-19 12:03:55 --> Model Class Initialized
INFO - 2018-04-19 12:03:55 --> Model Class Initialized
INFO - 2018-04-19 12:03:55 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 12:03:55 --> Upload Class Initialized
INFO - 2018-04-19 12:03:55 --> Final output sent to browser
DEBUG - 2018-04-19 12:03:55 --> Total execution time: 0.1288
INFO - 2018-04-19 06:33:56 --> Config Class Initialized
INFO - 2018-04-19 06:33:56 --> Hooks Class Initialized
DEBUG - 2018-04-19 06:33:56 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:33:56 --> Utf8 Class Initialized
INFO - 2018-04-19 06:33:56 --> URI Class Initialized
INFO - 2018-04-19 06:33:56 --> Router Class Initialized
INFO - 2018-04-19 06:33:56 --> Output Class Initialized
INFO - 2018-04-19 06:33:56 --> Security Class Initialized
DEBUG - 2018-04-19 06:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:33:56 --> Input Class Initialized
INFO - 2018-04-19 06:33:56 --> Language Class Initialized
INFO - 2018-04-19 06:33:56 --> Language Class Initialized
INFO - 2018-04-19 06:33:56 --> Config Class Initialized
INFO - 2018-04-19 06:33:56 --> Loader Class Initialized
INFO - 2018-04-19 12:03:56 --> Helper loaded: url_helper
INFO - 2018-04-19 12:03:56 --> Helper loaded: notification_helper
INFO - 2018-04-19 12:03:56 --> Helper loaded: settings_helper
INFO - 2018-04-19 12:03:56 --> Helper loaded: permission_helper
INFO - 2018-04-19 12:03:56 --> Helper loaded: users_helper
INFO - 2018-04-19 12:03:56 --> Database Driver Class Initialized
DEBUG - 2018-04-19 12:03:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 12:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 12:03:56 --> Helper loaded: form_helper
INFO - 2018-04-19 12:03:56 --> Form Validation Class Initialized
INFO - 2018-04-19 12:03:56 --> Controller Class Initialized
INFO - 2018-04-19 12:03:56 --> Model Class Initialized
INFO - 2018-04-19 12:03:56 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 12:03:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 12:03:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 12:03:56 --> Model Class Initialized
INFO - 2018-04-19 12:03:56 --> Model Class Initialized
INFO - 2018-04-19 12:03:56 --> Model Class Initialized
INFO - 2018-04-19 12:03:56 --> Model Class Initialized
INFO - 2018-04-19 12:03:56 --> Model Class Initialized
INFO - 2018-04-19 12:03:56 --> Model Class Initialized
INFO - 2018-04-19 12:03:56 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 12:03:56 --> Final output sent to browser
DEBUG - 2018-04-19 12:03:56 --> Total execution time: 0.1124
INFO - 2018-04-19 06:33:59 --> Config Class Initialized
INFO - 2018-04-19 06:33:59 --> Hooks Class Initialized
DEBUG - 2018-04-19 06:33:59 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:33:59 --> Utf8 Class Initialized
INFO - 2018-04-19 06:33:59 --> URI Class Initialized
INFO - 2018-04-19 06:33:59 --> Router Class Initialized
INFO - 2018-04-19 06:33:59 --> Output Class Initialized
INFO - 2018-04-19 06:33:59 --> Security Class Initialized
DEBUG - 2018-04-19 06:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:33:59 --> Input Class Initialized
INFO - 2018-04-19 06:33:59 --> Language Class Initialized
INFO - 2018-04-19 06:33:59 --> Language Class Initialized
INFO - 2018-04-19 06:33:59 --> Config Class Initialized
INFO - 2018-04-19 06:33:59 --> Loader Class Initialized
INFO - 2018-04-19 12:03:59 --> Helper loaded: url_helper
INFO - 2018-04-19 12:03:59 --> Helper loaded: notification_helper
INFO - 2018-04-19 12:03:59 --> Helper loaded: settings_helper
INFO - 2018-04-19 12:03:59 --> Helper loaded: permission_helper
INFO - 2018-04-19 12:03:59 --> Helper loaded: users_helper
INFO - 2018-04-19 12:03:59 --> Database Driver Class Initialized
DEBUG - 2018-04-19 12:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 12:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 12:03:59 --> Helper loaded: form_helper
INFO - 2018-04-19 12:03:59 --> Form Validation Class Initialized
INFO - 2018-04-19 12:03:59 --> Controller Class Initialized
INFO - 2018-04-19 12:03:59 --> Model Class Initialized
INFO - 2018-04-19 12:03:59 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 12:03:59 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 12:03:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 12:03:59 --> Model Class Initialized
INFO - 2018-04-19 12:03:59 --> Model Class Initialized
INFO - 2018-04-19 12:03:59 --> Model Class Initialized
INFO - 2018-04-19 12:03:59 --> Model Class Initialized
INFO - 2018-04-19 12:03:59 --> Model Class Initialized
INFO - 2018-04-19 12:03:59 --> Model Class Initialized
INFO - 2018-04-19 12:03:59 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 12:03:59 --> Final output sent to browser
DEBUG - 2018-04-19 12:03:59 --> Total execution time: 0.1107
INFO - 2018-04-19 06:33:59 --> Config Class Initialized
INFO - 2018-04-19 06:33:59 --> Hooks Class Initialized
DEBUG - 2018-04-19 06:33:59 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:33:59 --> Utf8 Class Initialized
INFO - 2018-04-19 06:33:59 --> URI Class Initialized
INFO - 2018-04-19 06:33:59 --> Router Class Initialized
INFO - 2018-04-19 06:33:59 --> Output Class Initialized
INFO - 2018-04-19 06:33:59 --> Security Class Initialized
DEBUG - 2018-04-19 06:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:33:59 --> Input Class Initialized
INFO - 2018-04-19 06:33:59 --> Language Class Initialized
INFO - 2018-04-19 06:33:59 --> Language Class Initialized
INFO - 2018-04-19 06:33:59 --> Config Class Initialized
INFO - 2018-04-19 06:33:59 --> Loader Class Initialized
INFO - 2018-04-19 06:33:59 --> Config Class Initialized
INFO - 2018-04-19 06:33:59 --> Hooks Class Initialized
INFO - 2018-04-19 12:03:59 --> Helper loaded: url_helper
INFO - 2018-04-19 12:03:59 --> Helper loaded: notification_helper
INFO - 2018-04-19 12:03:59 --> Helper loaded: settings_helper
INFO - 2018-04-19 12:03:59 --> Helper loaded: permission_helper
DEBUG - 2018-04-19 06:33:59 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:33:59 --> Utf8 Class Initialized
INFO - 2018-04-19 12:03:59 --> Helper loaded: users_helper
INFO - 2018-04-19 06:33:59 --> URI Class Initialized
INFO - 2018-04-19 06:33:59 --> Router Class Initialized
INFO - 2018-04-19 12:03:59 --> Database Driver Class Initialized
INFO - 2018-04-19 06:33:59 --> Output Class Initialized
DEBUG - 2018-04-19 12:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 12:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 06:33:59 --> Security Class Initialized
DEBUG - 2018-04-19 06:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:33:59 --> Input Class Initialized
INFO - 2018-04-19 06:33:59 --> Language Class Initialized
INFO - 2018-04-19 12:03:59 --> Helper loaded: form_helper
INFO - 2018-04-19 12:03:59 --> Form Validation Class Initialized
INFO - 2018-04-19 12:03:59 --> Controller Class Initialized
INFO - 2018-04-19 12:03:59 --> Model Class Initialized
INFO - 2018-04-19 12:03:59 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 12:03:59 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 12:03:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 12:03:59 --> Model Class Initialized
INFO - 2018-04-19 12:03:59 --> Model Class Initialized
INFO - 2018-04-19 12:03:59 --> Model Class Initialized
INFO - 2018-04-19 12:03:59 --> Model Class Initialized
INFO - 2018-04-19 12:03:59 --> Model Class Initialized
INFO - 2018-04-19 12:03:59 --> Model Class Initialized
INFO - 2018-04-19 12:03:59 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 06:33:59 --> Language Class Initialized
INFO - 2018-04-19 06:33:59 --> Config Class Initialized
INFO - 2018-04-19 06:33:59 --> Loader Class Initialized
INFO - 2018-04-19 12:03:59 --> Final output sent to browser
DEBUG - 2018-04-19 12:03:59 --> Total execution time: 0.1159
INFO - 2018-04-19 12:03:59 --> Helper loaded: url_helper
INFO - 2018-04-19 12:03:59 --> Helper loaded: notification_helper
INFO - 2018-04-19 12:03:59 --> Helper loaded: settings_helper
INFO - 2018-04-19 12:03:59 --> Helper loaded: permission_helper
INFO - 2018-04-19 12:03:59 --> Helper loaded: users_helper
INFO - 2018-04-19 12:03:59 --> Database Driver Class Initialized
DEBUG - 2018-04-19 12:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 12:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 12:03:59 --> Helper loaded: form_helper
INFO - 2018-04-19 12:03:59 --> Form Validation Class Initialized
INFO - 2018-04-19 12:03:59 --> Controller Class Initialized
INFO - 2018-04-19 12:03:59 --> Model Class Initialized
INFO - 2018-04-19 12:03:59 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 12:03:59 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 12:03:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 12:03:59 --> Model Class Initialized
INFO - 2018-04-19 12:03:59 --> Model Class Initialized
INFO - 2018-04-19 12:03:59 --> Model Class Initialized
INFO - 2018-04-19 12:03:59 --> Model Class Initialized
INFO - 2018-04-19 12:03:59 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 12:03:59 --> Final output sent to browser
DEBUG - 2018-04-19 12:03:59 --> Total execution time: 0.1629
INFO - 2018-04-19 06:34:00 --> Config Class Initialized
INFO - 2018-04-19 06:34:00 --> Hooks Class Initialized
DEBUG - 2018-04-19 06:34:00 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:34:00 --> Utf8 Class Initialized
INFO - 2018-04-19 06:34:00 --> URI Class Initialized
INFO - 2018-04-19 06:34:00 --> Config Class Initialized
INFO - 2018-04-19 06:34:00 --> Hooks Class Initialized
INFO - 2018-04-19 06:34:00 --> Router Class Initialized
DEBUG - 2018-04-19 06:34:00 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:34:00 --> Utf8 Class Initialized
INFO - 2018-04-19 06:34:00 --> Output Class Initialized
INFO - 2018-04-19 06:34:00 --> URI Class Initialized
INFO - 2018-04-19 06:34:00 --> Security Class Initialized
INFO - 2018-04-19 06:34:00 --> Router Class Initialized
DEBUG - 2018-04-19 06:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:34:00 --> Input Class Initialized
INFO - 2018-04-19 06:34:00 --> Language Class Initialized
INFO - 2018-04-19 06:34:00 --> Output Class Initialized
INFO - 2018-04-19 06:34:00 --> Security Class Initialized
DEBUG - 2018-04-19 06:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:34:00 --> Input Class Initialized
INFO - 2018-04-19 06:34:00 --> Language Class Initialized
INFO - 2018-04-19 06:34:01 --> Language Class Initialized
INFO - 2018-04-19 06:34:01 --> Config Class Initialized
INFO - 2018-04-19 06:34:01 --> Loader Class Initialized
INFO - 2018-04-19 12:04:01 --> Helper loaded: url_helper
INFO - 2018-04-19 12:04:01 --> Helper loaded: notification_helper
INFO - 2018-04-19 12:04:01 --> Helper loaded: settings_helper
INFO - 2018-04-19 12:04:01 --> Helper loaded: permission_helper
INFO - 2018-04-19 12:04:01 --> Helper loaded: users_helper
INFO - 2018-04-19 06:34:01 --> Language Class Initialized
INFO - 2018-04-19 06:34:01 --> Config Class Initialized
INFO - 2018-04-19 06:34:01 --> Loader Class Initialized
INFO - 2018-04-19 12:04:01 --> Helper loaded: url_helper
INFO - 2018-04-19 12:04:01 --> Database Driver Class Initialized
INFO - 2018-04-19 12:04:01 --> Helper loaded: notification_helper
INFO - 2018-04-19 12:04:01 --> Helper loaded: settings_helper
INFO - 2018-04-19 12:04:01 --> Helper loaded: permission_helper
INFO - 2018-04-19 12:04:01 --> Helper loaded: users_helper
DEBUG - 2018-04-19 12:04:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 12:04:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 12:04:01 --> Helper loaded: form_helper
INFO - 2018-04-19 12:04:01 --> Form Validation Class Initialized
INFO - 2018-04-19 12:04:01 --> Controller Class Initialized
INFO - 2018-04-19 12:04:01 --> Database Driver Class Initialized
DEBUG - 2018-04-19 12:04:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 12:04:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 12:04:01 --> Model Class Initialized
INFO - 2018-04-19 12:04:01 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 12:04:01 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 12:04:01 --> Helper loaded: form_helper
INFO - 2018-04-19 12:04:01 --> Form Validation Class Initialized
INFO - 2018-04-19 12:04:01 --> Controller Class Initialized
INFO - 2018-04-19 12:04:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 12:04:01 --> Model Class Initialized
INFO - 2018-04-19 12:04:01 --> Model Class Initialized
INFO - 2018-04-19 12:04:01 --> Model Class Initialized
INFO - 2018-04-19 12:04:01 --> Model Class Initialized
INFO - 2018-04-19 12:04:01 --> Model Class Initialized
INFO - 2018-04-19 12:04:01 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 12:04:01 --> Model Class Initialized
INFO - 2018-04-19 12:04:01 --> Model Class Initialized
INFO - 2018-04-19 12:04:01 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 12:04:01 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 12:04:01 --> Final output sent to browser
DEBUG - 2018-04-19 12:04:01 --> Total execution time: 0.1138
INFO - 2018-04-19 12:04:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 12:04:01 --> Model Class Initialized
INFO - 2018-04-19 12:04:01 --> Model Class Initialized
INFO - 2018-04-19 12:04:01 --> Model Class Initialized
INFO - 2018-04-19 12:04:01 --> Model Class Initialized
INFO - 2018-04-19 12:04:01 --> Model Class Initialized
INFO - 2018-04-19 12:04:01 --> Model Class Initialized
INFO - 2018-04-19 12:04:01 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 12:04:01 --> Final output sent to browser
DEBUG - 2018-04-19 12:04:01 --> Total execution time: 0.1140
INFO - 2018-04-19 06:34:02 --> Config Class Initialized
INFO - 2018-04-19 06:34:02 --> Hooks Class Initialized
DEBUG - 2018-04-19 06:34:02 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:34:02 --> Utf8 Class Initialized
INFO - 2018-04-19 06:34:02 --> URI Class Initialized
INFO - 2018-04-19 06:34:02 --> Router Class Initialized
INFO - 2018-04-19 06:34:02 --> Output Class Initialized
INFO - 2018-04-19 06:34:02 --> Security Class Initialized
DEBUG - 2018-04-19 06:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:34:02 --> Input Class Initialized
INFO - 2018-04-19 06:34:02 --> Language Class Initialized
INFO - 2018-04-19 06:34:02 --> Language Class Initialized
INFO - 2018-04-19 06:34:02 --> Config Class Initialized
INFO - 2018-04-19 06:34:02 --> Loader Class Initialized
INFO - 2018-04-19 12:04:02 --> Helper loaded: url_helper
INFO - 2018-04-19 12:04:02 --> Helper loaded: notification_helper
INFO - 2018-04-19 12:04:02 --> Helper loaded: settings_helper
INFO - 2018-04-19 12:04:02 --> Helper loaded: permission_helper
INFO - 2018-04-19 12:04:02 --> Helper loaded: users_helper
INFO - 2018-04-19 12:04:02 --> Database Driver Class Initialized
DEBUG - 2018-04-19 12:04:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 12:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 12:04:02 --> Helper loaded: form_helper
INFO - 2018-04-19 12:04:02 --> Form Validation Class Initialized
INFO - 2018-04-19 12:04:02 --> Controller Class Initialized
INFO - 2018-04-19 12:04:02 --> Model Class Initialized
INFO - 2018-04-19 12:04:02 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 12:04:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 12:04:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 12:04:02 --> Model Class Initialized
INFO - 2018-04-19 12:04:02 --> Model Class Initialized
INFO - 2018-04-19 12:04:02 --> Model Class Initialized
INFO - 2018-04-19 12:04:02 --> Model Class Initialized
INFO - 2018-04-19 12:04:02 --> Model Class Initialized
INFO - 2018-04-19 12:04:02 --> Model Class Initialized
INFO - 2018-04-19 12:04:02 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 12:04:02 --> Final output sent to browser
DEBUG - 2018-04-19 12:04:02 --> Total execution time: 0.1148
INFO - 2018-04-19 06:34:02 --> Config Class Initialized
INFO - 2018-04-19 06:34:02 --> Hooks Class Initialized
DEBUG - 2018-04-19 06:34:03 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:34:03 --> Utf8 Class Initialized
INFO - 2018-04-19 06:34:03 --> URI Class Initialized
INFO - 2018-04-19 06:34:03 --> Router Class Initialized
INFO - 2018-04-19 06:34:03 --> Output Class Initialized
INFO - 2018-04-19 06:34:03 --> Security Class Initialized
DEBUG - 2018-04-19 06:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:34:03 --> Input Class Initialized
INFO - 2018-04-19 06:34:03 --> Language Class Initialized
INFO - 2018-04-19 06:34:03 --> Language Class Initialized
INFO - 2018-04-19 06:34:03 --> Config Class Initialized
INFO - 2018-04-19 06:34:03 --> Loader Class Initialized
INFO - 2018-04-19 12:04:03 --> Helper loaded: url_helper
INFO - 2018-04-19 12:04:03 --> Helper loaded: notification_helper
INFO - 2018-04-19 12:04:03 --> Helper loaded: settings_helper
INFO - 2018-04-19 12:04:03 --> Helper loaded: permission_helper
INFO - 2018-04-19 12:04:03 --> Helper loaded: users_helper
INFO - 2018-04-19 12:04:03 --> Database Driver Class Initialized
DEBUG - 2018-04-19 12:04:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 12:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 12:04:03 --> Helper loaded: form_helper
INFO - 2018-04-19 12:04:03 --> Form Validation Class Initialized
INFO - 2018-04-19 12:04:03 --> Controller Class Initialized
INFO - 2018-04-19 12:04:03 --> Model Class Initialized
INFO - 2018-04-19 12:04:03 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 12:04:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 12:04:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 12:04:03 --> Model Class Initialized
INFO - 2018-04-19 12:04:03 --> Model Class Initialized
INFO - 2018-04-19 12:04:03 --> Model Class Initialized
INFO - 2018-04-19 12:04:03 --> Model Class Initialized
INFO - 2018-04-19 12:04:03 --> Model Class Initialized
INFO - 2018-04-19 12:04:03 --> Model Class Initialized
INFO - 2018-04-19 12:04:03 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 12:04:03 --> Final output sent to browser
DEBUG - 2018-04-19 12:04:03 --> Total execution time: 0.1159
INFO - 2018-04-19 06:34:13 --> Config Class Initialized
INFO - 2018-04-19 06:34:13 --> Hooks Class Initialized
DEBUG - 2018-04-19 06:34:13 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:34:13 --> Utf8 Class Initialized
INFO - 2018-04-19 06:34:13 --> URI Class Initialized
INFO - 2018-04-19 06:34:13 --> Router Class Initialized
INFO - 2018-04-19 06:34:13 --> Output Class Initialized
INFO - 2018-04-19 06:34:13 --> Security Class Initialized
DEBUG - 2018-04-19 06:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:34:13 --> Input Class Initialized
INFO - 2018-04-19 06:34:13 --> Language Class Initialized
INFO - 2018-04-19 06:34:13 --> Language Class Initialized
INFO - 2018-04-19 06:34:13 --> Config Class Initialized
INFO - 2018-04-19 06:34:13 --> Loader Class Initialized
INFO - 2018-04-19 12:04:13 --> Helper loaded: url_helper
INFO - 2018-04-19 12:04:13 --> Helper loaded: notification_helper
INFO - 2018-04-19 12:04:13 --> Helper loaded: settings_helper
INFO - 2018-04-19 12:04:13 --> Helper loaded: permission_helper
INFO - 2018-04-19 12:04:13 --> Helper loaded: users_helper
INFO - 2018-04-19 12:04:13 --> Database Driver Class Initialized
DEBUG - 2018-04-19 12:04:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 12:04:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 12:04:13 --> Helper loaded: form_helper
INFO - 2018-04-19 12:04:13 --> Form Validation Class Initialized
INFO - 2018-04-19 12:04:13 --> Controller Class Initialized
INFO - 2018-04-19 12:04:13 --> Model Class Initialized
INFO - 2018-04-19 12:04:13 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 12:04:13 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 12:04:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 12:04:13 --> Model Class Initialized
INFO - 2018-04-19 12:04:13 --> Model Class Initialized
INFO - 2018-04-19 12:04:13 --> Model Class Initialized
INFO - 2018-04-19 12:04:13 --> Model Class Initialized
INFO - 2018-04-19 12:04:13 --> Model Class Initialized
INFO - 2018-04-19 12:04:13 --> Model Class Initialized
INFO - 2018-04-19 12:04:13 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 12:04:13 --> Upload Class Initialized
INFO - 2018-04-19 12:04:13 --> Final output sent to browser
DEBUG - 2018-04-19 12:04:13 --> Total execution time: 0.1124
INFO - 2018-04-19 06:34:14 --> Config Class Initialized
INFO - 2018-04-19 06:34:14 --> Hooks Class Initialized
DEBUG - 2018-04-19 06:34:14 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:34:14 --> Utf8 Class Initialized
INFO - 2018-04-19 06:34:14 --> URI Class Initialized
INFO - 2018-04-19 06:34:14 --> Router Class Initialized
INFO - 2018-04-19 06:34:14 --> Output Class Initialized
INFO - 2018-04-19 06:34:14 --> Security Class Initialized
DEBUG - 2018-04-19 06:34:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:34:14 --> Input Class Initialized
INFO - 2018-04-19 06:34:14 --> Language Class Initialized
INFO - 2018-04-19 06:34:14 --> Language Class Initialized
INFO - 2018-04-19 06:34:14 --> Config Class Initialized
INFO - 2018-04-19 06:34:14 --> Loader Class Initialized
INFO - 2018-04-19 12:04:14 --> Helper loaded: url_helper
INFO - 2018-04-19 12:04:14 --> Helper loaded: notification_helper
INFO - 2018-04-19 12:04:14 --> Helper loaded: settings_helper
INFO - 2018-04-19 12:04:14 --> Helper loaded: permission_helper
INFO - 2018-04-19 12:04:14 --> Helper loaded: users_helper
INFO - 2018-04-19 12:04:14 --> Database Driver Class Initialized
DEBUG - 2018-04-19 12:04:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 12:04:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 12:04:14 --> Helper loaded: form_helper
INFO - 2018-04-19 12:04:14 --> Form Validation Class Initialized
INFO - 2018-04-19 12:04:14 --> Controller Class Initialized
INFO - 2018-04-19 12:04:14 --> Model Class Initialized
INFO - 2018-04-19 12:04:14 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 12:04:14 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 12:04:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 12:04:14 --> Model Class Initialized
INFO - 2018-04-19 12:04:14 --> Model Class Initialized
INFO - 2018-04-19 12:04:14 --> Model Class Initialized
INFO - 2018-04-19 12:04:14 --> Model Class Initialized
INFO - 2018-04-19 12:04:14 --> Model Class Initialized
INFO - 2018-04-19 12:04:14 --> Model Class Initialized
INFO - 2018-04-19 12:04:14 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 12:04:14 --> Final output sent to browser
DEBUG - 2018-04-19 12:04:14 --> Total execution time: 0.1175
INFO - 2018-04-19 06:34:16 --> Config Class Initialized
INFO - 2018-04-19 06:34:16 --> Hooks Class Initialized
DEBUG - 2018-04-19 06:34:16 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:34:16 --> Utf8 Class Initialized
INFO - 2018-04-19 06:34:16 --> URI Class Initialized
INFO - 2018-04-19 06:34:16 --> Router Class Initialized
INFO - 2018-04-19 06:34:16 --> Output Class Initialized
INFO - 2018-04-19 06:34:16 --> Security Class Initialized
DEBUG - 2018-04-19 06:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:34:16 --> Input Class Initialized
INFO - 2018-04-19 06:34:16 --> Language Class Initialized
INFO - 2018-04-19 06:34:16 --> Language Class Initialized
INFO - 2018-04-19 06:34:16 --> Config Class Initialized
INFO - 2018-04-19 06:34:16 --> Loader Class Initialized
INFO - 2018-04-19 12:04:16 --> Helper loaded: url_helper
INFO - 2018-04-19 12:04:16 --> Helper loaded: notification_helper
INFO - 2018-04-19 12:04:16 --> Helper loaded: settings_helper
INFO - 2018-04-19 12:04:16 --> Helper loaded: permission_helper
INFO - 2018-04-19 12:04:16 --> Helper loaded: users_helper
INFO - 2018-04-19 12:04:16 --> Database Driver Class Initialized
DEBUG - 2018-04-19 12:04:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 12:04:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 12:04:16 --> Helper loaded: form_helper
INFO - 2018-04-19 12:04:16 --> Form Validation Class Initialized
INFO - 2018-04-19 12:04:16 --> Controller Class Initialized
INFO - 2018-04-19 12:04:16 --> Model Class Initialized
INFO - 2018-04-19 12:04:16 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 12:04:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 12:04:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 12:04:16 --> Model Class Initialized
INFO - 2018-04-19 12:04:16 --> Model Class Initialized
INFO - 2018-04-19 12:04:16 --> Model Class Initialized
INFO - 2018-04-19 12:04:16 --> Model Class Initialized
INFO - 2018-04-19 12:04:16 --> Model Class Initialized
INFO - 2018-04-19 12:04:16 --> Model Class Initialized
INFO - 2018-04-19 12:04:16 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 12:04:16 --> Final output sent to browser
DEBUG - 2018-04-19 12:04:16 --> Total execution time: 0.1088
INFO - 2018-04-19 06:34:17 --> Config Class Initialized
INFO - 2018-04-19 06:34:17 --> Hooks Class Initialized
DEBUG - 2018-04-19 06:34:17 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:34:17 --> Utf8 Class Initialized
INFO - 2018-04-19 06:34:17 --> URI Class Initialized
INFO - 2018-04-19 06:34:17 --> Router Class Initialized
INFO - 2018-04-19 06:34:17 --> Output Class Initialized
INFO - 2018-04-19 06:34:17 --> Security Class Initialized
DEBUG - 2018-04-19 06:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:34:17 --> Input Class Initialized
INFO - 2018-04-19 06:34:17 --> Language Class Initialized
INFO - 2018-04-19 06:34:17 --> Language Class Initialized
INFO - 2018-04-19 06:34:17 --> Config Class Initialized
INFO - 2018-04-19 06:34:17 --> Loader Class Initialized
INFO - 2018-04-19 12:04:17 --> Helper loaded: url_helper
INFO - 2018-04-19 12:04:17 --> Helper loaded: notification_helper
INFO - 2018-04-19 12:04:17 --> Helper loaded: settings_helper
INFO - 2018-04-19 12:04:17 --> Helper loaded: permission_helper
INFO - 2018-04-19 12:04:17 --> Helper loaded: users_helper
INFO - 2018-04-19 12:04:17 --> Database Driver Class Initialized
DEBUG - 2018-04-19 12:04:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 12:04:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 12:04:17 --> Helper loaded: form_helper
INFO - 2018-04-19 12:04:17 --> Form Validation Class Initialized
INFO - 2018-04-19 12:04:17 --> Controller Class Initialized
INFO - 2018-04-19 12:04:17 --> Model Class Initialized
INFO - 2018-04-19 12:04:17 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 12:04:17 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 12:04:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 12:04:17 --> Model Class Initialized
INFO - 2018-04-19 12:04:17 --> Model Class Initialized
INFO - 2018-04-19 12:04:17 --> Model Class Initialized
INFO - 2018-04-19 12:04:17 --> Model Class Initialized
INFO - 2018-04-19 12:04:17 --> Model Class Initialized
INFO - 2018-04-19 12:04:17 --> Model Class Initialized
INFO - 2018-04-19 12:04:17 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 12:04:17 --> Final output sent to browser
DEBUG - 2018-04-19 12:04:17 --> Total execution time: 0.1059
INFO - 2018-04-19 06:34:18 --> Config Class Initialized
INFO - 2018-04-19 06:34:18 --> Hooks Class Initialized
DEBUG - 2018-04-19 06:34:18 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:34:18 --> Utf8 Class Initialized
INFO - 2018-04-19 06:34:18 --> URI Class Initialized
INFO - 2018-04-19 06:34:18 --> Router Class Initialized
INFO - 2018-04-19 06:34:18 --> Output Class Initialized
INFO - 2018-04-19 06:34:18 --> Security Class Initialized
DEBUG - 2018-04-19 06:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:34:18 --> Input Class Initialized
INFO - 2018-04-19 06:34:18 --> Language Class Initialized
INFO - 2018-04-19 06:34:18 --> Language Class Initialized
INFO - 2018-04-19 06:34:18 --> Config Class Initialized
INFO - 2018-04-19 06:34:18 --> Loader Class Initialized
INFO - 2018-04-19 12:04:18 --> Helper loaded: url_helper
INFO - 2018-04-19 12:04:18 --> Helper loaded: notification_helper
INFO - 2018-04-19 12:04:18 --> Helper loaded: settings_helper
INFO - 2018-04-19 12:04:18 --> Helper loaded: permission_helper
INFO - 2018-04-19 12:04:18 --> Helper loaded: users_helper
INFO - 2018-04-19 12:04:18 --> Database Driver Class Initialized
DEBUG - 2018-04-19 12:04:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 12:04:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 12:04:18 --> Helper loaded: form_helper
INFO - 2018-04-19 12:04:18 --> Form Validation Class Initialized
INFO - 2018-04-19 12:04:18 --> Controller Class Initialized
INFO - 2018-04-19 12:04:18 --> Model Class Initialized
INFO - 2018-04-19 12:04:18 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 12:04:18 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 12:04:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 12:04:18 --> Model Class Initialized
INFO - 2018-04-19 12:04:18 --> Model Class Initialized
INFO - 2018-04-19 12:04:18 --> Model Class Initialized
INFO - 2018-04-19 12:04:18 --> Model Class Initialized
INFO - 2018-04-19 12:04:18 --> Model Class Initialized
INFO - 2018-04-19 12:04:18 --> Model Class Initialized
INFO - 2018-04-19 12:04:18 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 12:04:18 --> Final output sent to browser
DEBUG - 2018-04-19 12:04:18 --> Total execution time: 0.1142
INFO - 2018-04-19 06:34:18 --> Config Class Initialized
INFO - 2018-04-19 06:34:18 --> Hooks Class Initialized
DEBUG - 2018-04-19 06:34:18 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:34:18 --> Utf8 Class Initialized
INFO - 2018-04-19 06:34:18 --> URI Class Initialized
INFO - 2018-04-19 06:34:18 --> Router Class Initialized
INFO - 2018-04-19 06:34:18 --> Output Class Initialized
INFO - 2018-04-19 06:34:18 --> Security Class Initialized
DEBUG - 2018-04-19 06:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:34:18 --> Input Class Initialized
INFO - 2018-04-19 06:34:18 --> Language Class Initialized
INFO - 2018-04-19 06:34:18 --> Config Class Initialized
INFO - 2018-04-19 06:34:18 --> Hooks Class Initialized
DEBUG - 2018-04-19 06:34:18 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:34:18 --> Utf8 Class Initialized
INFO - 2018-04-19 06:34:18 --> URI Class Initialized
INFO - 2018-04-19 06:34:18 --> Router Class Initialized
INFO - 2018-04-19 06:34:18 --> Language Class Initialized
INFO - 2018-04-19 06:34:18 --> Config Class Initialized
INFO - 2018-04-19 06:34:18 --> Loader Class Initialized
INFO - 2018-04-19 06:34:18 --> Output Class Initialized
INFO - 2018-04-19 12:04:18 --> Helper loaded: url_helper
INFO - 2018-04-19 12:04:18 --> Helper loaded: notification_helper
INFO - 2018-04-19 06:34:18 --> Security Class Initialized
INFO - 2018-04-19 12:04:18 --> Helper loaded: settings_helper
INFO - 2018-04-19 12:04:18 --> Helper loaded: permission_helper
INFO - 2018-04-19 12:04:18 --> Helper loaded: users_helper
DEBUG - 2018-04-19 06:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:34:18 --> Input Class Initialized
INFO - 2018-04-19 06:34:18 --> Language Class Initialized
INFO - 2018-04-19 12:04:18 --> Database Driver Class Initialized
DEBUG - 2018-04-19 12:04:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 12:04:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 06:34:18 --> Language Class Initialized
INFO - 2018-04-19 06:34:18 --> Config Class Initialized
INFO - 2018-04-19 06:34:18 --> Loader Class Initialized
INFO - 2018-04-19 12:04:18 --> Helper loaded: url_helper
INFO - 2018-04-19 12:04:18 --> Helper loaded: notification_helper
INFO - 2018-04-19 12:04:18 --> Helper loaded: settings_helper
INFO - 2018-04-19 12:04:18 --> Helper loaded: permission_helper
INFO - 2018-04-19 12:04:18 --> Helper loaded: users_helper
INFO - 2018-04-19 12:04:18 --> Helper loaded: form_helper
INFO - 2018-04-19 12:04:18 --> Form Validation Class Initialized
INFO - 2018-04-19 12:04:18 --> Controller Class Initialized
INFO - 2018-04-19 12:04:19 --> Model Class Initialized
INFO - 2018-04-19 12:04:19 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 12:04:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 12:04:19 --> Database Driver Class Initialized
INFO - 2018-04-19 12:04:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 12:04:19 --> Model Class Initialized
INFO - 2018-04-19 12:04:19 --> Model Class Initialized
INFO - 2018-04-19 12:04:19 --> Model Class Initialized
INFO - 2018-04-19 12:04:19 --> Model Class Initialized
INFO - 2018-04-19 12:04:19 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-04-19 12:04:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 12:04:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 12:04:19 --> Final output sent to browser
DEBUG - 2018-04-19 12:04:19 --> Total execution time: 0.1117
INFO - 2018-04-19 12:04:19 --> Helper loaded: form_helper
INFO - 2018-04-19 12:04:19 --> Form Validation Class Initialized
INFO - 2018-04-19 12:04:19 --> Controller Class Initialized
INFO - 2018-04-19 12:04:19 --> Model Class Initialized
INFO - 2018-04-19 12:04:19 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 12:04:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 12:04:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 12:04:19 --> Model Class Initialized
INFO - 2018-04-19 12:04:19 --> Model Class Initialized
INFO - 2018-04-19 12:04:19 --> Model Class Initialized
INFO - 2018-04-19 12:04:19 --> Model Class Initialized
INFO - 2018-04-19 12:04:19 --> Model Class Initialized
INFO - 2018-04-19 12:04:19 --> Model Class Initialized
INFO - 2018-04-19 12:04:19 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 12:04:19 --> Final output sent to browser
DEBUG - 2018-04-19 12:04:19 --> Total execution time: 0.1166
INFO - 2018-04-19 06:34:20 --> Config Class Initialized
INFO - 2018-04-19 06:34:20 --> Hooks Class Initialized
DEBUG - 2018-04-19 06:34:20 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:34:20 --> Utf8 Class Initialized
INFO - 2018-04-19 06:34:20 --> Config Class Initialized
INFO - 2018-04-19 06:34:20 --> Hooks Class Initialized
INFO - 2018-04-19 06:34:20 --> URI Class Initialized
DEBUG - 2018-04-19 06:34:20 --> UTF-8 Support Enabled
INFO - 2018-04-19 06:34:20 --> Utf8 Class Initialized
INFO - 2018-04-19 06:34:20 --> Router Class Initialized
INFO - 2018-04-19 06:34:20 --> URI Class Initialized
INFO - 2018-04-19 06:34:20 --> Output Class Initialized
INFO - 2018-04-19 06:34:20 --> Router Class Initialized
INFO - 2018-04-19 06:34:20 --> Security Class Initialized
INFO - 2018-04-19 06:34:20 --> Output Class Initialized
DEBUG - 2018-04-19 06:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:34:20 --> Input Class Initialized
INFO - 2018-04-19 06:34:20 --> Language Class Initialized
INFO - 2018-04-19 06:34:20 --> Security Class Initialized
DEBUG - 2018-04-19 06:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 06:34:20 --> Input Class Initialized
INFO - 2018-04-19 06:34:20 --> Language Class Initialized
INFO - 2018-04-19 06:34:20 --> Language Class Initialized
INFO - 2018-04-19 06:34:20 --> Config Class Initialized
INFO - 2018-04-19 06:34:20 --> Loader Class Initialized
INFO - 2018-04-19 06:34:20 --> Language Class Initialized
INFO - 2018-04-19 06:34:20 --> Config Class Initialized
INFO - 2018-04-19 06:34:20 --> Loader Class Initialized
INFO - 2018-04-19 12:04:20 --> Helper loaded: url_helper
INFO - 2018-04-19 12:04:20 --> Helper loaded: url_helper
INFO - 2018-04-19 12:04:20 --> Helper loaded: notification_helper
INFO - 2018-04-19 12:04:20 --> Helper loaded: settings_helper
INFO - 2018-04-19 12:04:20 --> Helper loaded: notification_helper
INFO - 2018-04-19 12:04:20 --> Helper loaded: permission_helper
INFO - 2018-04-19 12:04:20 --> Helper loaded: settings_helper
INFO - 2018-04-19 12:04:20 --> Helper loaded: users_helper
INFO - 2018-04-19 12:04:20 --> Helper loaded: permission_helper
INFO - 2018-04-19 12:04:20 --> Helper loaded: users_helper
INFO - 2018-04-19 12:04:20 --> Database Driver Class Initialized
INFO - 2018-04-19 12:04:20 --> Database Driver Class Initialized
DEBUG - 2018-04-19 12:04:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 12:04:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-04-19 12:04:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 12:04:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 12:04:20 --> Helper loaded: form_helper
INFO - 2018-04-19 12:04:20 --> Form Validation Class Initialized
INFO - 2018-04-19 12:04:20 --> Controller Class Initialized
INFO - 2018-04-19 12:04:20 --> Helper loaded: form_helper
INFO - 2018-04-19 12:04:20 --> Form Validation Class Initialized
INFO - 2018-04-19 12:04:20 --> Controller Class Initialized
INFO - 2018-04-19 12:04:20 --> Model Class Initialized
INFO - 2018-04-19 12:04:20 --> Helper loaded: inflector_helper
INFO - 2018-04-19 12:04:20 --> Model Class Initialized
INFO - 2018-04-19 12:04:20 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 12:04:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 12:04:20 --> Language file loaded: language/english/rest_controller_lang.php
DEBUG - 2018-04-19 12:04:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 12:04:20 --> Model Class Initialized
INFO - 2018-04-19 12:04:20 --> Model Class Initialized
INFO - 2018-04-19 12:04:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 12:04:20 --> Model Class Initialized
INFO - 2018-04-19 12:04:20 --> Model Class Initialized
INFO - 2018-04-19 12:04:20 --> Model Class Initialized
INFO - 2018-04-19 12:04:20 --> Model Class Initialized
INFO - 2018-04-19 12:04:20 --> Model Class Initialized
INFO - 2018-04-19 12:04:20 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 12:04:20 --> Model Class Initialized
INFO - 2018-04-19 12:04:20 --> Model Class Initialized
INFO - 2018-04-19 12:04:20 --> Model Class Initialized
INFO - 2018-04-19 12:04:20 --> Model Class Initialized
INFO - 2018-04-19 12:04:20 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 12:04:20 --> Final output sent to browser
DEBUG - 2018-04-19 12:04:20 --> Total execution time: 0.1033
INFO - 2018-04-19 12:04:20 --> Model Class Initialized
INFO - 2018-04-19 12:04:20 --> Final output sent to browser
DEBUG - 2018-04-19 12:04:20 --> Total execution time: 0.1073
INFO - 2018-04-19 07:16:07 --> Config Class Initialized
INFO - 2018-04-19 07:16:07 --> Hooks Class Initialized
DEBUG - 2018-04-19 07:16:07 --> UTF-8 Support Enabled
INFO - 2018-04-19 07:16:07 --> Utf8 Class Initialized
INFO - 2018-04-19 07:16:07 --> URI Class Initialized
INFO - 2018-04-19 07:16:07 --> Router Class Initialized
INFO - 2018-04-19 07:16:07 --> Output Class Initialized
INFO - 2018-04-19 07:16:07 --> Security Class Initialized
DEBUG - 2018-04-19 07:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 07:16:07 --> Input Class Initialized
INFO - 2018-04-19 07:16:07 --> Language Class Initialized
INFO - 2018-04-19 07:16:07 --> Config Class Initialized
INFO - 2018-04-19 07:16:07 --> Hooks Class Initialized
INFO - 2018-04-19 07:16:07 --> Config Class Initialized
INFO - 2018-04-19 07:16:07 --> Hooks Class Initialized
DEBUG - 2018-04-19 07:16:07 --> UTF-8 Support Enabled
INFO - 2018-04-19 07:16:07 --> Utf8 Class Initialized
DEBUG - 2018-04-19 07:16:07 --> UTF-8 Support Enabled
INFO - 2018-04-19 07:16:07 --> Utf8 Class Initialized
INFO - 2018-04-19 07:16:07 --> URI Class Initialized
INFO - 2018-04-19 07:16:07 --> URI Class Initialized
INFO - 2018-04-19 07:16:07 --> Router Class Initialized
INFO - 2018-04-19 07:16:07 --> Language Class Initialized
INFO - 2018-04-19 07:16:07 --> Config Class Initialized
INFO - 2018-04-19 07:16:07 --> Loader Class Initialized
INFO - 2018-04-19 07:16:07 --> Router Class Initialized
INFO - 2018-04-19 07:16:07 --> Output Class Initialized
INFO - 2018-04-19 12:46:07 --> Helper loaded: url_helper
INFO - 2018-04-19 07:16:07 --> Security Class Initialized
INFO - 2018-04-19 12:46:07 --> Helper loaded: notification_helper
INFO - 2018-04-19 07:16:07 --> Output Class Initialized
INFO - 2018-04-19 12:46:07 --> Helper loaded: settings_helper
INFO - 2018-04-19 12:46:07 --> Helper loaded: permission_helper
DEBUG - 2018-04-19 07:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 07:16:07 --> Input Class Initialized
INFO - 2018-04-19 12:46:07 --> Helper loaded: users_helper
INFO - 2018-04-19 07:16:07 --> Language Class Initialized
INFO - 2018-04-19 07:16:07 --> Security Class Initialized
DEBUG - 2018-04-19 07:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 07:16:07 --> Input Class Initialized
INFO - 2018-04-19 07:16:07 --> Language Class Initialized
INFO - 2018-04-19 12:46:07 --> Database Driver Class Initialized
INFO - 2018-04-19 07:16:07 --> Language Class Initialized
INFO - 2018-04-19 07:16:07 --> Config Class Initialized
INFO - 2018-04-19 07:16:07 --> Loader Class Initialized
DEBUG - 2018-04-19 12:46:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 12:46:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 12:46:07 --> Helper loaded: url_helper
INFO - 2018-04-19 12:46:07 --> Helper loaded: notification_helper
INFO - 2018-04-19 12:46:07 --> Helper loaded: settings_helper
INFO - 2018-04-19 12:46:07 --> Helper loaded: permission_helper
INFO - 2018-04-19 12:46:07 --> Helper loaded: users_helper
INFO - 2018-04-19 07:16:07 --> Language Class Initialized
INFO - 2018-04-19 07:16:07 --> Config Class Initialized
INFO - 2018-04-19 07:16:07 --> Loader Class Initialized
INFO - 2018-04-19 12:46:07 --> Helper loaded: form_helper
INFO - 2018-04-19 12:46:07 --> Form Validation Class Initialized
INFO - 2018-04-19 12:46:07 --> Controller Class Initialized
INFO - 2018-04-19 12:46:07 --> Helper loaded: url_helper
INFO - 2018-04-19 12:46:07 --> Helper loaded: notification_helper
INFO - 2018-04-19 12:46:07 --> Helper loaded: settings_helper
INFO - 2018-04-19 12:46:07 --> Helper loaded: permission_helper
INFO - 2018-04-19 12:46:07 --> Helper loaded: users_helper
INFO - 2018-04-19 12:46:07 --> Database Driver Class Initialized
INFO - 2018-04-19 12:46:07 --> Model Class Initialized
INFO - 2018-04-19 12:46:07 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 12:46:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-04-19 12:46:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 12:46:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 12:46:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 12:46:07 --> Model Class Initialized
INFO - 2018-04-19 12:46:07 --> Model Class Initialized
INFO - 2018-04-19 12:46:07 --> Model Class Initialized
INFO - 2018-04-19 12:46:07 --> Model Class Initialized
INFO - 2018-04-19 12:46:07 --> Model Class Initialized
INFO - 2018-04-19 12:46:07 --> Model Class Initialized
INFO - 2018-04-19 12:46:07 --> Model Class Initialized
INFO - 2018-04-19 12:46:07 --> Model Class Initialized
INFO - 2018-04-19 12:46:07 --> Model Class Initialized
INFO - 2018-04-19 12:46:07 --> Model Class Initialized
INFO - 2018-04-19 12:46:07 --> Database Driver Class Initialized
INFO - 2018-04-19 12:46:07 --> Helper loaded: form_helper
INFO - 2018-04-19 12:46:07 --> Form Validation Class Initialized
INFO - 2018-04-19 12:46:07 --> Controller Class Initialized
INFO - 2018-04-19 12:46:07 --> Model Class Initialized
INFO - 2018-04-19 12:46:07 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 12:46:07 --> Model Class Initialized
DEBUG - 2018-04-19 12:46:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 12:46:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 12:46:07 --> Model Class Initialized
INFO - 2018-04-19 12:46:07 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 12:46:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 12:46:07 --> Helper loaded: form_helper
INFO - 2018-04-19 12:46:07 --> Form Validation Class Initialized
INFO - 2018-04-19 12:46:07 --> Controller Class Initialized
INFO - 2018-04-19 12:46:07 --> Final output sent to browser
DEBUG - 2018-04-19 12:46:07 --> Total execution time: 0.4019
INFO - 2018-04-19 12:46:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 12:46:07 --> Model Class Initialized
INFO - 2018-04-19 12:46:07 --> Model Class Initialized
INFO - 2018-04-19 12:46:07 --> Model Class Initialized
INFO - 2018-04-19 12:46:07 --> Model Class Initialized
INFO - 2018-04-19 12:46:07 --> Model Class Initialized
INFO - 2018-04-19 12:46:07 --> Model Class Initialized
INFO - 2018-04-19 12:46:07 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 12:46:07 --> Final output sent to browser
DEBUG - 2018-04-19 12:46:07 --> Total execution time: 0.3841
INFO - 2018-04-19 12:46:07 --> Model Class Initialized
INFO - 2018-04-19 12:46:07 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 12:46:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 12:46:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 12:46:07 --> Model Class Initialized
INFO - 2018-04-19 12:46:07 --> Model Class Initialized
INFO - 2018-04-19 12:46:07 --> Model Class Initialized
INFO - 2018-04-19 12:46:07 --> Model Class Initialized
INFO - 2018-04-19 12:46:07 --> Model Class Initialized
INFO - 2018-04-19 12:46:07 --> Model Class Initialized
INFO - 2018-04-19 12:46:07 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 12:46:07 --> Model Class Initialized
INFO - 2018-04-19 12:46:07 --> Final output sent to browser
DEBUG - 2018-04-19 12:46:07 --> Total execution time: 0.4001
INFO - 2018-04-19 07:16:11 --> Config Class Initialized
INFO - 2018-04-19 07:16:11 --> Hooks Class Initialized
DEBUG - 2018-04-19 07:16:11 --> UTF-8 Support Enabled
INFO - 2018-04-19 07:16:11 --> Utf8 Class Initialized
INFO - 2018-04-19 07:16:11 --> URI Class Initialized
INFO - 2018-04-19 07:16:11 --> Router Class Initialized
INFO - 2018-04-19 07:16:11 --> Output Class Initialized
INFO - 2018-04-19 07:16:11 --> Security Class Initialized
DEBUG - 2018-04-19 07:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 07:16:11 --> Input Class Initialized
INFO - 2018-04-19 07:16:11 --> Language Class Initialized
INFO - 2018-04-19 07:16:11 --> Language Class Initialized
INFO - 2018-04-19 07:16:11 --> Config Class Initialized
INFO - 2018-04-19 07:16:11 --> Loader Class Initialized
INFO - 2018-04-19 12:46:11 --> Helper loaded: url_helper
INFO - 2018-04-19 12:46:11 --> Helper loaded: notification_helper
INFO - 2018-04-19 12:46:11 --> Helper loaded: settings_helper
INFO - 2018-04-19 12:46:11 --> Helper loaded: permission_helper
INFO - 2018-04-19 12:46:11 --> Helper loaded: users_helper
INFO - 2018-04-19 12:46:11 --> Database Driver Class Initialized
DEBUG - 2018-04-19 12:46:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 12:46:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 12:46:11 --> Helper loaded: form_helper
INFO - 2018-04-19 12:46:11 --> Form Validation Class Initialized
INFO - 2018-04-19 12:46:11 --> Controller Class Initialized
INFO - 2018-04-19 12:46:11 --> Model Class Initialized
INFO - 2018-04-19 12:46:11 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 12:46:11 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 12:46:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 12:46:11 --> Model Class Initialized
INFO - 2018-04-19 12:46:11 --> Model Class Initialized
INFO - 2018-04-19 12:46:11 --> Model Class Initialized
INFO - 2018-04-19 12:46:11 --> Model Class Initialized
INFO - 2018-04-19 12:46:11 --> Model Class Initialized
INFO - 2018-04-19 12:46:11 --> Model Class Initialized
INFO - 2018-04-19 12:46:11 --> Model Class Initialized
INFO - 2018-04-19 12:46:11 --> Model Class Initialized
INFO - 2018-04-19 12:46:11 --> Model Class Initialized
INFO - 2018-04-19 12:46:11 --> Model Class Initialized
INFO - 2018-04-19 12:46:11 --> Model Class Initialized
INFO - 2018-04-19 12:46:11 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 12:46:11 --> Model Class Initialized
INFO - 2018-04-19 12:46:11 --> Final output sent to browser
DEBUG - 2018-04-19 12:46:11 --> Total execution time: 0.1225
INFO - 2018-04-19 07:16:12 --> Config Class Initialized
INFO - 2018-04-19 07:16:12 --> Hooks Class Initialized
DEBUG - 2018-04-19 07:16:12 --> UTF-8 Support Enabled
INFO - 2018-04-19 07:16:12 --> Utf8 Class Initialized
INFO - 2018-04-19 07:16:12 --> URI Class Initialized
INFO - 2018-04-19 07:16:12 --> Router Class Initialized
INFO - 2018-04-19 07:16:12 --> Output Class Initialized
INFO - 2018-04-19 07:16:12 --> Security Class Initialized
DEBUG - 2018-04-19 07:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 07:16:12 --> Input Class Initialized
INFO - 2018-04-19 07:16:12 --> Language Class Initialized
INFO - 2018-04-19 07:16:12 --> Language Class Initialized
INFO - 2018-04-19 07:16:12 --> Config Class Initialized
INFO - 2018-04-19 07:16:12 --> Loader Class Initialized
INFO - 2018-04-19 12:46:12 --> Helper loaded: url_helper
INFO - 2018-04-19 12:46:12 --> Helper loaded: notification_helper
INFO - 2018-04-19 12:46:12 --> Helper loaded: settings_helper
INFO - 2018-04-19 12:46:12 --> Helper loaded: permission_helper
INFO - 2018-04-19 12:46:12 --> Helper loaded: users_helper
INFO - 2018-04-19 12:46:12 --> Database Driver Class Initialized
DEBUG - 2018-04-19 12:46:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 12:46:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 12:46:12 --> Helper loaded: form_helper
INFO - 2018-04-19 12:46:12 --> Form Validation Class Initialized
INFO - 2018-04-19 12:46:12 --> Controller Class Initialized
INFO - 2018-04-19 12:46:12 --> Model Class Initialized
INFO - 2018-04-19 12:46:12 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 12:46:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 12:46:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 12:46:12 --> Model Class Initialized
INFO - 2018-04-19 12:46:12 --> Model Class Initialized
INFO - 2018-04-19 12:46:12 --> Model Class Initialized
INFO - 2018-04-19 12:46:12 --> Model Class Initialized
INFO - 2018-04-19 12:46:12 --> Final output sent to browser
DEBUG - 2018-04-19 12:46:12 --> Total execution time: 0.1250
INFO - 2018-04-19 07:16:14 --> Config Class Initialized
INFO - 2018-04-19 07:16:14 --> Hooks Class Initialized
DEBUG - 2018-04-19 07:16:14 --> UTF-8 Support Enabled
INFO - 2018-04-19 07:16:14 --> Utf8 Class Initialized
INFO - 2018-04-19 07:16:14 --> URI Class Initialized
INFO - 2018-04-19 07:16:14 --> Router Class Initialized
INFO - 2018-04-19 07:16:14 --> Output Class Initialized
INFO - 2018-04-19 07:16:14 --> Security Class Initialized
DEBUG - 2018-04-19 07:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 07:16:14 --> Input Class Initialized
INFO - 2018-04-19 07:16:14 --> Language Class Initialized
INFO - 2018-04-19 07:16:14 --> Language Class Initialized
INFO - 2018-04-19 07:16:14 --> Config Class Initialized
INFO - 2018-04-19 07:16:14 --> Loader Class Initialized
INFO - 2018-04-19 12:46:14 --> Helper loaded: url_helper
INFO - 2018-04-19 12:46:14 --> Helper loaded: notification_helper
INFO - 2018-04-19 12:46:14 --> Helper loaded: settings_helper
INFO - 2018-04-19 12:46:14 --> Helper loaded: permission_helper
INFO - 2018-04-19 12:46:14 --> Helper loaded: users_helper
INFO - 2018-04-19 12:46:14 --> Database Driver Class Initialized
DEBUG - 2018-04-19 12:46:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 12:46:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 12:46:14 --> Helper loaded: form_helper
INFO - 2018-04-19 12:46:14 --> Form Validation Class Initialized
INFO - 2018-04-19 12:46:14 --> Controller Class Initialized
INFO - 2018-04-19 12:46:14 --> Model Class Initialized
INFO - 2018-04-19 12:46:14 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 12:46:14 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 12:46:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 12:46:14 --> Model Class Initialized
INFO - 2018-04-19 12:46:14 --> Model Class Initialized
INFO - 2018-04-19 12:46:14 --> Model Class Initialized
INFO - 2018-04-19 12:46:14 --> Model Class Initialized
INFO - 2018-04-19 12:46:14 --> Final output sent to browser
DEBUG - 2018-04-19 12:46:14 --> Total execution time: 0.1284
INFO - 2018-04-19 07:16:18 --> Config Class Initialized
INFO - 2018-04-19 07:16:18 --> Hooks Class Initialized
DEBUG - 2018-04-19 07:16:18 --> UTF-8 Support Enabled
INFO - 2018-04-19 07:16:18 --> Utf8 Class Initialized
INFO - 2018-04-19 07:16:18 --> URI Class Initialized
INFO - 2018-04-19 07:16:18 --> Router Class Initialized
INFO - 2018-04-19 07:16:18 --> Output Class Initialized
INFO - 2018-04-19 07:16:18 --> Security Class Initialized
DEBUG - 2018-04-19 07:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 07:16:18 --> Input Class Initialized
INFO - 2018-04-19 07:16:18 --> Language Class Initialized
INFO - 2018-04-19 07:16:18 --> Language Class Initialized
INFO - 2018-04-19 07:16:18 --> Config Class Initialized
INFO - 2018-04-19 07:16:18 --> Loader Class Initialized
INFO - 2018-04-19 12:46:18 --> Helper loaded: url_helper
INFO - 2018-04-19 12:46:18 --> Helper loaded: notification_helper
INFO - 2018-04-19 12:46:18 --> Helper loaded: settings_helper
INFO - 2018-04-19 12:46:18 --> Helper loaded: permission_helper
INFO - 2018-04-19 12:46:18 --> Helper loaded: users_helper
INFO - 2018-04-19 12:46:18 --> Database Driver Class Initialized
DEBUG - 2018-04-19 12:46:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 12:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 12:46:18 --> Helper loaded: form_helper
INFO - 2018-04-19 12:46:18 --> Form Validation Class Initialized
INFO - 2018-04-19 12:46:18 --> Controller Class Initialized
INFO - 2018-04-19 12:46:18 --> Model Class Initialized
INFO - 2018-04-19 12:46:18 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 12:46:18 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 12:46:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 12:46:18 --> Model Class Initialized
INFO - 2018-04-19 12:46:18 --> Model Class Initialized
INFO - 2018-04-19 12:46:18 --> Model Class Initialized
INFO - 2018-04-19 12:46:18 --> Model Class Initialized
INFO - 2018-04-19 12:46:18 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 12:46:18 --> Final output sent to browser
DEBUG - 2018-04-19 12:46:18 --> Total execution time: 0.0790
INFO - 2018-04-19 07:16:18 --> Config Class Initialized
INFO - 2018-04-19 07:16:18 --> Hooks Class Initialized
DEBUG - 2018-04-19 07:16:19 --> UTF-8 Support Enabled
INFO - 2018-04-19 07:16:19 --> Utf8 Class Initialized
INFO - 2018-04-19 07:16:19 --> URI Class Initialized
INFO - 2018-04-19 07:16:19 --> Router Class Initialized
INFO - 2018-04-19 07:16:19 --> Output Class Initialized
INFO - 2018-04-19 07:16:19 --> Security Class Initialized
DEBUG - 2018-04-19 07:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 07:16:19 --> Input Class Initialized
INFO - 2018-04-19 07:16:19 --> Language Class Initialized
INFO - 2018-04-19 07:16:19 --> Language Class Initialized
INFO - 2018-04-19 07:16:19 --> Config Class Initialized
INFO - 2018-04-19 07:16:19 --> Loader Class Initialized
INFO - 2018-04-19 12:46:19 --> Helper loaded: url_helper
INFO - 2018-04-19 12:46:19 --> Helper loaded: notification_helper
INFO - 2018-04-19 12:46:19 --> Helper loaded: settings_helper
INFO - 2018-04-19 12:46:19 --> Helper loaded: permission_helper
INFO - 2018-04-19 12:46:19 --> Helper loaded: users_helper
INFO - 2018-04-19 12:46:19 --> Database Driver Class Initialized
DEBUG - 2018-04-19 12:46:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 12:46:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 12:46:19 --> Helper loaded: form_helper
INFO - 2018-04-19 12:46:19 --> Form Validation Class Initialized
INFO - 2018-04-19 12:46:19 --> Controller Class Initialized
INFO - 2018-04-19 12:46:19 --> Model Class Initialized
INFO - 2018-04-19 12:46:19 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 12:46:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 12:46:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 12:46:19 --> Model Class Initialized
INFO - 2018-04-19 12:46:19 --> Model Class Initialized
INFO - 2018-04-19 12:46:19 --> Model Class Initialized
INFO - 2018-04-19 12:46:19 --> Model Class Initialized
INFO - 2018-04-19 12:46:19 --> Model Class Initialized
INFO - 2018-04-19 12:46:19 --> Model Class Initialized
INFO - 2018-04-19 12:46:19 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-04-19 12:46:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-04-19 12:46:19 --> Final output sent to browser
DEBUG - 2018-04-19 12:46:19 --> Total execution time: 0.1367
INFO - 2018-04-19 07:16:23 --> Config Class Initialized
INFO - 2018-04-19 07:16:23 --> Hooks Class Initialized
DEBUG - 2018-04-19 07:16:23 --> UTF-8 Support Enabled
INFO - 2018-04-19 07:16:23 --> Utf8 Class Initialized
INFO - 2018-04-19 07:16:23 --> URI Class Initialized
INFO - 2018-04-19 07:16:23 --> Router Class Initialized
INFO - 2018-04-19 07:16:23 --> Output Class Initialized
INFO - 2018-04-19 07:16:23 --> Security Class Initialized
DEBUG - 2018-04-19 07:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 07:16:23 --> Input Class Initialized
INFO - 2018-04-19 07:16:23 --> Language Class Initialized
INFO - 2018-04-19 07:16:23 --> Language Class Initialized
INFO - 2018-04-19 07:16:23 --> Config Class Initialized
INFO - 2018-04-19 07:16:23 --> Loader Class Initialized
INFO - 2018-04-19 12:46:23 --> Helper loaded: url_helper
INFO - 2018-04-19 12:46:23 --> Helper loaded: notification_helper
INFO - 2018-04-19 12:46:23 --> Helper loaded: settings_helper
INFO - 2018-04-19 12:46:23 --> Helper loaded: permission_helper
INFO - 2018-04-19 12:46:23 --> Helper loaded: users_helper
INFO - 2018-04-19 12:46:23 --> Database Driver Class Initialized
DEBUG - 2018-04-19 12:46:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 12:46:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 12:46:23 --> Helper loaded: form_helper
INFO - 2018-04-19 12:46:23 --> Form Validation Class Initialized
INFO - 2018-04-19 12:46:23 --> Controller Class Initialized
INFO - 2018-04-19 12:46:23 --> Model Class Initialized
INFO - 2018-04-19 12:46:23 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 12:46:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 12:46:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 12:46:23 --> Model Class Initialized
INFO - 2018-04-19 12:46:23 --> Model Class Initialized
INFO - 2018-04-19 12:46:23 --> Model Class Initialized
INFO - 2018-04-19 12:46:23 --> Model Class Initialized
INFO - 2018-04-19 12:46:23 --> Final output sent to browser
DEBUG - 2018-04-19 12:46:23 --> Total execution time: 0.1042
INFO - 2018-04-19 07:16:25 --> Config Class Initialized
INFO - 2018-04-19 07:16:25 --> Hooks Class Initialized
DEBUG - 2018-04-19 07:16:25 --> UTF-8 Support Enabled
INFO - 2018-04-19 07:16:25 --> Utf8 Class Initialized
INFO - 2018-04-19 07:16:25 --> URI Class Initialized
INFO - 2018-04-19 07:16:25 --> Router Class Initialized
INFO - 2018-04-19 07:16:25 --> Output Class Initialized
INFO - 2018-04-19 07:16:25 --> Security Class Initialized
DEBUG - 2018-04-19 07:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 07:16:25 --> Input Class Initialized
INFO - 2018-04-19 07:16:25 --> Language Class Initialized
INFO - 2018-04-19 07:16:25 --> Language Class Initialized
INFO - 2018-04-19 07:16:25 --> Config Class Initialized
INFO - 2018-04-19 07:16:25 --> Loader Class Initialized
INFO - 2018-04-19 12:46:25 --> Helper loaded: url_helper
INFO - 2018-04-19 12:46:25 --> Helper loaded: notification_helper
INFO - 2018-04-19 12:46:25 --> Helper loaded: settings_helper
INFO - 2018-04-19 12:46:25 --> Helper loaded: permission_helper
INFO - 2018-04-19 12:46:25 --> Helper loaded: users_helper
INFO - 2018-04-19 12:46:25 --> Database Driver Class Initialized
DEBUG - 2018-04-19 12:46:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 12:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 12:46:25 --> Helper loaded: form_helper
INFO - 2018-04-19 12:46:25 --> Form Validation Class Initialized
INFO - 2018-04-19 12:46:25 --> Controller Class Initialized
INFO - 2018-04-19 12:46:25 --> Model Class Initialized
INFO - 2018-04-19 12:46:25 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 12:46:25 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 12:46:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 12:46:25 --> Model Class Initialized
INFO - 2018-04-19 12:46:25 --> Model Class Initialized
INFO - 2018-04-19 12:46:25 --> Model Class Initialized
INFO - 2018-04-19 12:46:25 --> Model Class Initialized
INFO - 2018-04-19 12:46:25 --> Model Class Initialized
INFO - 2018-04-19 12:46:25 --> Model Class Initialized
INFO - 2018-04-19 12:46:25 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-04-19 12:46:25 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-04-19 12:46:25 --> Final output sent to browser
DEBUG - 2018-04-19 12:46:25 --> Total execution time: 0.1069
INFO - 2018-04-19 07:16:33 --> Config Class Initialized
INFO - 2018-04-19 07:16:33 --> Hooks Class Initialized
DEBUG - 2018-04-19 07:16:33 --> UTF-8 Support Enabled
INFO - 2018-04-19 07:16:33 --> Utf8 Class Initialized
INFO - 2018-04-19 07:16:33 --> URI Class Initialized
INFO - 2018-04-19 07:16:33 --> Router Class Initialized
INFO - 2018-04-19 07:16:33 --> Output Class Initialized
INFO - 2018-04-19 07:16:33 --> Security Class Initialized
DEBUG - 2018-04-19 07:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 07:16:33 --> Input Class Initialized
INFO - 2018-04-19 07:16:33 --> Language Class Initialized
INFO - 2018-04-19 07:16:33 --> Language Class Initialized
INFO - 2018-04-19 07:16:33 --> Config Class Initialized
INFO - 2018-04-19 07:16:33 --> Loader Class Initialized
INFO - 2018-04-19 12:46:33 --> Helper loaded: url_helper
INFO - 2018-04-19 12:46:33 --> Helper loaded: notification_helper
INFO - 2018-04-19 12:46:33 --> Helper loaded: settings_helper
INFO - 2018-04-19 12:46:33 --> Helper loaded: permission_helper
INFO - 2018-04-19 12:46:33 --> Helper loaded: users_helper
INFO - 2018-04-19 12:46:33 --> Database Driver Class Initialized
DEBUG - 2018-04-19 12:46:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 12:46:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 12:46:33 --> Helper loaded: form_helper
INFO - 2018-04-19 12:46:33 --> Form Validation Class Initialized
INFO - 2018-04-19 12:46:33 --> Controller Class Initialized
INFO - 2018-04-19 12:46:33 --> Model Class Initialized
INFO - 2018-04-19 12:46:33 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 12:46:33 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 12:46:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 12:46:33 --> Model Class Initialized
INFO - 2018-04-19 12:46:33 --> Model Class Initialized
INFO - 2018-04-19 12:46:33 --> Model Class Initialized
INFO - 2018-04-19 12:46:33 --> Model Class Initialized
INFO - 2018-04-19 12:46:33 --> Model Class Initialized
INFO - 2018-04-19 12:46:33 --> Model Class Initialized
INFO - 2018-04-19 12:46:33 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 12:46:33 --> Final output sent to browser
DEBUG - 2018-04-19 12:46:33 --> Total execution time: 0.1123
INFO - 2018-04-19 07:25:46 --> Config Class Initialized
INFO - 2018-04-19 07:25:46 --> Hooks Class Initialized
DEBUG - 2018-04-19 07:25:46 --> UTF-8 Support Enabled
INFO - 2018-04-19 07:25:46 --> Utf8 Class Initialized
INFO - 2018-04-19 07:25:46 --> URI Class Initialized
INFO - 2018-04-19 07:25:46 --> Router Class Initialized
INFO - 2018-04-19 07:25:46 --> Output Class Initialized
INFO - 2018-04-19 07:25:46 --> Security Class Initialized
DEBUG - 2018-04-19 07:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 07:25:46 --> Input Class Initialized
INFO - 2018-04-19 07:25:46 --> Language Class Initialized
INFO - 2018-04-19 07:25:46 --> Language Class Initialized
INFO - 2018-04-19 07:25:46 --> Config Class Initialized
INFO - 2018-04-19 07:25:46 --> Loader Class Initialized
INFO - 2018-04-19 12:55:46 --> Helper loaded: url_helper
INFO - 2018-04-19 12:55:46 --> Helper loaded: notification_helper
INFO - 2018-04-19 12:55:46 --> Helper loaded: settings_helper
INFO - 2018-04-19 12:55:46 --> Helper loaded: permission_helper
INFO - 2018-04-19 12:55:46 --> Helper loaded: users_helper
INFO - 2018-04-19 12:55:46 --> Database Driver Class Initialized
DEBUG - 2018-04-19 12:55:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 12:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 07:25:46 --> Config Class Initialized
INFO - 2018-04-19 07:25:46 --> Hooks Class Initialized
INFO - 2018-04-19 12:55:46 --> Helper loaded: form_helper
INFO - 2018-04-19 12:55:46 --> Form Validation Class Initialized
INFO - 2018-04-19 12:55:46 --> Controller Class Initialized
DEBUG - 2018-04-19 07:25:46 --> UTF-8 Support Enabled
INFO - 2018-04-19 07:25:46 --> Utf8 Class Initialized
INFO - 2018-04-19 07:25:46 --> URI Class Initialized
INFO - 2018-04-19 07:25:46 --> Router Class Initialized
INFO - 2018-04-19 12:55:46 --> Model Class Initialized
INFO - 2018-04-19 12:55:46 --> Helper loaded: inflector_helper
INFO - 2018-04-19 07:25:46 --> Output Class Initialized
DEBUG - 2018-04-19 12:55:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 07:25:46 --> Security Class Initialized
INFO - 2018-04-19 12:55:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 12:55:46 --> Model Class Initialized
INFO - 2018-04-19 12:55:46 --> Model Class Initialized
DEBUG - 2018-04-19 07:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 07:25:46 --> Input Class Initialized
INFO - 2018-04-19 12:55:46 --> Model Class Initialized
INFO - 2018-04-19 12:55:46 --> Model Class Initialized
INFO - 2018-04-19 12:55:46 --> Model Class Initialized
INFO - 2018-04-19 07:25:46 --> Language Class Initialized
INFO - 2018-04-19 12:55:46 --> Model Class Initialized
INFO - 2018-04-19 12:55:46 --> Model Class Initialized
INFO - 2018-04-19 12:55:46 --> Model Class Initialized
INFO - 2018-04-19 12:55:46 --> Model Class Initialized
INFO - 2018-04-19 12:55:46 --> Model Class Initialized
INFO - 2018-04-19 12:55:46 --> Model Class Initialized
INFO - 2018-04-19 12:55:46 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 12:55:46 --> Model Class Initialized
INFO - 2018-04-19 12:55:46 --> Final output sent to browser
DEBUG - 2018-04-19 12:55:46 --> Total execution time: 0.1198
INFO - 2018-04-19 07:25:46 --> Language Class Initialized
INFO - 2018-04-19 07:25:46 --> Config Class Initialized
INFO - 2018-04-19 07:25:46 --> Loader Class Initialized
INFO - 2018-04-19 12:55:46 --> Helper loaded: url_helper
INFO - 2018-04-19 12:55:46 --> Helper loaded: notification_helper
INFO - 2018-04-19 12:55:46 --> Helper loaded: settings_helper
INFO - 2018-04-19 12:55:46 --> Helper loaded: permission_helper
INFO - 2018-04-19 12:55:46 --> Helper loaded: users_helper
INFO - 2018-04-19 12:55:46 --> Database Driver Class Initialized
DEBUG - 2018-04-19 12:55:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 12:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 12:55:46 --> Helper loaded: form_helper
INFO - 2018-04-19 12:55:46 --> Form Validation Class Initialized
INFO - 2018-04-19 12:55:46 --> Controller Class Initialized
INFO - 2018-04-19 12:55:46 --> Model Class Initialized
INFO - 2018-04-19 12:55:46 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 12:55:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 12:55:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 12:55:46 --> Model Class Initialized
INFO - 2018-04-19 12:55:46 --> Model Class Initialized
INFO - 2018-04-19 12:55:46 --> Model Class Initialized
INFO - 2018-04-19 12:55:46 --> Model Class Initialized
INFO - 2018-04-19 12:55:46 --> Model Class Initialized
INFO - 2018-04-19 12:55:46 --> Model Class Initialized
INFO - 2018-04-19 12:55:46 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 12:55:46 --> Final output sent to browser
DEBUG - 2018-04-19 12:55:46 --> Total execution time: 0.1181
INFO - 2018-04-19 07:25:46 --> Config Class Initialized
INFO - 2018-04-19 07:25:46 --> Hooks Class Initialized
DEBUG - 2018-04-19 07:25:46 --> UTF-8 Support Enabled
INFO - 2018-04-19 07:25:46 --> Utf8 Class Initialized
INFO - 2018-04-19 07:25:46 --> URI Class Initialized
INFO - 2018-04-19 07:25:46 --> Router Class Initialized
INFO - 2018-04-19 07:25:46 --> Output Class Initialized
INFO - 2018-04-19 07:25:46 --> Security Class Initialized
DEBUG - 2018-04-19 07:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 07:25:46 --> Input Class Initialized
INFO - 2018-04-19 07:25:46 --> Language Class Initialized
INFO - 2018-04-19 07:25:46 --> Language Class Initialized
INFO - 2018-04-19 07:25:46 --> Config Class Initialized
INFO - 2018-04-19 07:25:46 --> Loader Class Initialized
INFO - 2018-04-19 12:55:46 --> Helper loaded: url_helper
INFO - 2018-04-19 12:55:46 --> Helper loaded: notification_helper
INFO - 2018-04-19 12:55:46 --> Helper loaded: settings_helper
INFO - 2018-04-19 12:55:46 --> Helper loaded: permission_helper
INFO - 2018-04-19 12:55:46 --> Helper loaded: users_helper
INFO - 2018-04-19 12:55:46 --> Database Driver Class Initialized
DEBUG - 2018-04-19 12:55:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 12:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 12:55:46 --> Helper loaded: form_helper
INFO - 2018-04-19 12:55:46 --> Form Validation Class Initialized
INFO - 2018-04-19 12:55:46 --> Controller Class Initialized
INFO - 2018-04-19 12:55:46 --> Model Class Initialized
INFO - 2018-04-19 12:55:46 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 12:55:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 12:55:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 12:55:46 --> Model Class Initialized
INFO - 2018-04-19 12:55:46 --> Model Class Initialized
INFO - 2018-04-19 12:55:46 --> Model Class Initialized
INFO - 2018-04-19 12:55:46 --> Model Class Initialized
INFO - 2018-04-19 12:55:46 --> Model Class Initialized
INFO - 2018-04-19 12:55:46 --> Model Class Initialized
INFO - 2018-04-19 12:55:46 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 12:55:46 --> Model Class Initialized
INFO - 2018-04-19 12:55:46 --> Final output sent to browser
DEBUG - 2018-04-19 12:55:46 --> Total execution time: 0.1520
INFO - 2018-04-19 07:25:47 --> Config Class Initialized
INFO - 2018-04-19 07:25:47 --> Hooks Class Initialized
DEBUG - 2018-04-19 07:25:47 --> UTF-8 Support Enabled
INFO - 2018-04-19 07:25:47 --> Utf8 Class Initialized
INFO - 2018-04-19 07:25:47 --> URI Class Initialized
INFO - 2018-04-19 07:25:47 --> Router Class Initialized
INFO - 2018-04-19 07:25:47 --> Output Class Initialized
INFO - 2018-04-19 07:25:47 --> Security Class Initialized
DEBUG - 2018-04-19 07:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 07:25:47 --> Input Class Initialized
INFO - 2018-04-19 07:25:47 --> Language Class Initialized
INFO - 2018-04-19 07:25:47 --> Language Class Initialized
INFO - 2018-04-19 07:25:47 --> Config Class Initialized
INFO - 2018-04-19 07:25:47 --> Loader Class Initialized
INFO - 2018-04-19 12:55:47 --> Helper loaded: url_helper
INFO - 2018-04-19 12:55:47 --> Helper loaded: notification_helper
INFO - 2018-04-19 12:55:47 --> Helper loaded: settings_helper
INFO - 2018-04-19 12:55:47 --> Helper loaded: permission_helper
INFO - 2018-04-19 12:55:47 --> Helper loaded: users_helper
INFO - 2018-04-19 12:55:47 --> Database Driver Class Initialized
DEBUG - 2018-04-19 12:55:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 12:55:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 12:55:47 --> Helper loaded: form_helper
INFO - 2018-04-19 12:55:47 --> Form Validation Class Initialized
INFO - 2018-04-19 12:55:47 --> Controller Class Initialized
INFO - 2018-04-19 12:55:47 --> Model Class Initialized
INFO - 2018-04-19 12:55:47 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 12:55:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 12:55:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 12:55:47 --> Model Class Initialized
INFO - 2018-04-19 12:55:47 --> Model Class Initialized
INFO - 2018-04-19 12:55:47 --> Model Class Initialized
INFO - 2018-04-19 12:55:47 --> Model Class Initialized
INFO - 2018-04-19 12:55:47 --> Model Class Initialized
INFO - 2018-04-19 12:55:47 --> Model Class Initialized
INFO - 2018-04-19 12:55:47 --> Model Class Initialized
INFO - 2018-04-19 12:55:47 --> Model Class Initialized
INFO - 2018-04-19 12:55:47 --> Model Class Initialized
INFO - 2018-04-19 12:55:47 --> Model Class Initialized
INFO - 2018-04-19 12:55:47 --> Model Class Initialized
INFO - 2018-04-19 12:55:47 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 12:55:47 --> Model Class Initialized
INFO - 2018-04-19 12:55:47 --> Final output sent to browser
DEBUG - 2018-04-19 12:55:47 --> Total execution time: 0.1272
INFO - 2018-04-19 07:25:47 --> Config Class Initialized
INFO - 2018-04-19 07:25:47 --> Hooks Class Initialized
DEBUG - 2018-04-19 07:25:47 --> UTF-8 Support Enabled
INFO - 2018-04-19 07:25:47 --> Utf8 Class Initialized
INFO - 2018-04-19 07:25:47 --> URI Class Initialized
INFO - 2018-04-19 07:25:47 --> Router Class Initialized
INFO - 2018-04-19 07:25:47 --> Output Class Initialized
INFO - 2018-04-19 07:25:47 --> Security Class Initialized
DEBUG - 2018-04-19 07:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 07:25:47 --> Input Class Initialized
INFO - 2018-04-19 07:25:47 --> Language Class Initialized
INFO - 2018-04-19 07:25:47 --> Language Class Initialized
INFO - 2018-04-19 07:25:47 --> Config Class Initialized
INFO - 2018-04-19 07:25:47 --> Loader Class Initialized
INFO - 2018-04-19 12:55:47 --> Helper loaded: url_helper
INFO - 2018-04-19 12:55:47 --> Helper loaded: notification_helper
INFO - 2018-04-19 12:55:47 --> Helper loaded: settings_helper
INFO - 2018-04-19 12:55:47 --> Helper loaded: permission_helper
INFO - 2018-04-19 12:55:47 --> Helper loaded: users_helper
INFO - 2018-04-19 12:55:48 --> Database Driver Class Initialized
DEBUG - 2018-04-19 12:55:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 12:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 12:55:48 --> Helper loaded: form_helper
INFO - 2018-04-19 12:55:48 --> Form Validation Class Initialized
INFO - 2018-04-19 12:55:48 --> Controller Class Initialized
INFO - 2018-04-19 12:55:48 --> Model Class Initialized
INFO - 2018-04-19 12:55:48 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 12:55:48 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 12:55:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 12:55:48 --> Model Class Initialized
INFO - 2018-04-19 12:55:48 --> Model Class Initialized
INFO - 2018-04-19 12:55:48 --> Model Class Initialized
INFO - 2018-04-19 12:55:48 --> Model Class Initialized
INFO - 2018-04-19 12:55:48 --> Model Class Initialized
INFO - 2018-04-19 12:55:48 --> Model Class Initialized
INFO - 2018-04-19 12:55:48 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 12:55:48 --> Model Class Initialized
INFO - 2018-04-19 12:55:48 --> Final output sent to browser
DEBUG - 2018-04-19 12:55:48 --> Total execution time: 0.1103
INFO - 2018-04-19 07:25:52 --> Config Class Initialized
INFO - 2018-04-19 07:25:52 --> Hooks Class Initialized
DEBUG - 2018-04-19 07:25:52 --> UTF-8 Support Enabled
INFO - 2018-04-19 07:25:52 --> Utf8 Class Initialized
INFO - 2018-04-19 07:25:52 --> URI Class Initialized
INFO - 2018-04-19 07:25:52 --> Router Class Initialized
INFO - 2018-04-19 07:25:52 --> Output Class Initialized
INFO - 2018-04-19 07:25:52 --> Security Class Initialized
DEBUG - 2018-04-19 07:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 07:25:52 --> Input Class Initialized
INFO - 2018-04-19 07:25:52 --> Language Class Initialized
INFO - 2018-04-19 07:25:52 --> Language Class Initialized
INFO - 2018-04-19 07:25:52 --> Config Class Initialized
INFO - 2018-04-19 07:25:52 --> Loader Class Initialized
INFO - 2018-04-19 12:55:52 --> Helper loaded: url_helper
INFO - 2018-04-19 12:55:53 --> Helper loaded: notification_helper
INFO - 2018-04-19 12:55:53 --> Helper loaded: settings_helper
INFO - 2018-04-19 12:55:53 --> Helper loaded: permission_helper
INFO - 2018-04-19 12:55:53 --> Helper loaded: users_helper
INFO - 2018-04-19 12:55:53 --> Database Driver Class Initialized
DEBUG - 2018-04-19 12:55:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 12:55:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 12:55:53 --> Helper loaded: form_helper
INFO - 2018-04-19 12:55:53 --> Form Validation Class Initialized
INFO - 2018-04-19 12:55:53 --> Controller Class Initialized
INFO - 2018-04-19 12:55:53 --> Model Class Initialized
INFO - 2018-04-19 12:55:53 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 12:55:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 12:55:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 12:55:53 --> Model Class Initialized
INFO - 2018-04-19 12:55:53 --> Model Class Initialized
INFO - 2018-04-19 12:55:53 --> Model Class Initialized
INFO - 2018-04-19 12:55:53 --> Model Class Initialized
INFO - 2018-04-19 12:55:53 --> Model Class Initialized
INFO - 2018-04-19 12:55:53 --> Model Class Initialized
INFO - 2018-04-19 12:55:53 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 12:55:53 --> Final output sent to browser
DEBUG - 2018-04-19 12:55:53 --> Total execution time: 0.1162
INFO - 2018-04-19 07:25:53 --> Config Class Initialized
INFO - 2018-04-19 07:25:53 --> Hooks Class Initialized
DEBUG - 2018-04-19 07:25:53 --> UTF-8 Support Enabled
INFO - 2018-04-19 07:25:53 --> Utf8 Class Initialized
INFO - 2018-04-19 07:25:53 --> URI Class Initialized
INFO - 2018-04-19 07:25:53 --> Router Class Initialized
INFO - 2018-04-19 07:25:53 --> Output Class Initialized
INFO - 2018-04-19 07:25:53 --> Security Class Initialized
DEBUG - 2018-04-19 07:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 07:25:53 --> Input Class Initialized
INFO - 2018-04-19 07:25:53 --> Language Class Initialized
INFO - 2018-04-19 07:25:53 --> Language Class Initialized
INFO - 2018-04-19 07:25:53 --> Config Class Initialized
INFO - 2018-04-19 07:25:53 --> Loader Class Initialized
INFO - 2018-04-19 12:55:53 --> Helper loaded: url_helper
INFO - 2018-04-19 12:55:53 --> Helper loaded: notification_helper
INFO - 2018-04-19 12:55:53 --> Helper loaded: settings_helper
INFO - 2018-04-19 12:55:53 --> Helper loaded: permission_helper
INFO - 2018-04-19 12:55:53 --> Helper loaded: users_helper
INFO - 2018-04-19 12:55:53 --> Database Driver Class Initialized
DEBUG - 2018-04-19 12:55:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 12:55:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 12:55:53 --> Helper loaded: form_helper
INFO - 2018-04-19 12:55:53 --> Form Validation Class Initialized
INFO - 2018-04-19 12:55:53 --> Controller Class Initialized
INFO - 2018-04-19 12:55:53 --> Model Class Initialized
INFO - 2018-04-19 12:55:53 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 12:55:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 12:55:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 12:55:53 --> Model Class Initialized
INFO - 2018-04-19 12:55:53 --> Model Class Initialized
INFO - 2018-04-19 12:55:53 --> Model Class Initialized
INFO - 2018-04-19 12:55:53 --> Model Class Initialized
INFO - 2018-04-19 12:55:53 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 12:55:53 --> Final output sent to browser
DEBUG - 2018-04-19 12:55:53 --> Total execution time: 0.1013
INFO - 2018-04-19 07:25:54 --> Config Class Initialized
INFO - 2018-04-19 07:25:54 --> Hooks Class Initialized
DEBUG - 2018-04-19 07:25:54 --> UTF-8 Support Enabled
INFO - 2018-04-19 07:25:54 --> Utf8 Class Initialized
INFO - 2018-04-19 07:25:54 --> URI Class Initialized
INFO - 2018-04-19 07:25:54 --> Router Class Initialized
INFO - 2018-04-19 07:25:54 --> Output Class Initialized
INFO - 2018-04-19 07:25:54 --> Security Class Initialized
DEBUG - 2018-04-19 07:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 07:25:54 --> Input Class Initialized
INFO - 2018-04-19 07:25:54 --> Language Class Initialized
INFO - 2018-04-19 07:25:54 --> Language Class Initialized
INFO - 2018-04-19 07:25:54 --> Config Class Initialized
INFO - 2018-04-19 07:25:54 --> Loader Class Initialized
INFO - 2018-04-19 12:55:54 --> Helper loaded: url_helper
INFO - 2018-04-19 12:55:54 --> Helper loaded: notification_helper
INFO - 2018-04-19 12:55:54 --> Helper loaded: settings_helper
INFO - 2018-04-19 12:55:54 --> Helper loaded: permission_helper
INFO - 2018-04-19 12:55:54 --> Helper loaded: users_helper
INFO - 2018-04-19 12:55:54 --> Database Driver Class Initialized
DEBUG - 2018-04-19 12:55:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 12:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 12:55:54 --> Helper loaded: form_helper
INFO - 2018-04-19 12:55:54 --> Form Validation Class Initialized
INFO - 2018-04-19 12:55:54 --> Controller Class Initialized
INFO - 2018-04-19 12:55:54 --> Model Class Initialized
INFO - 2018-04-19 12:55:54 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 12:55:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 12:55:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 12:55:54 --> Model Class Initialized
INFO - 2018-04-19 12:55:54 --> Model Class Initialized
INFO - 2018-04-19 12:55:54 --> Model Class Initialized
INFO - 2018-04-19 12:55:54 --> Model Class Initialized
INFO - 2018-04-19 12:55:54 --> Model Class Initialized
INFO - 2018-04-19 12:55:54 --> Model Class Initialized
INFO - 2018-04-19 12:55:54 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 12:55:54 --> Final output sent to browser
DEBUG - 2018-04-19 12:55:54 --> Total execution time: 0.1188
INFO - 2018-04-19 07:25:56 --> Config Class Initialized
INFO - 2018-04-19 07:25:56 --> Hooks Class Initialized
DEBUG - 2018-04-19 07:25:56 --> UTF-8 Support Enabled
INFO - 2018-04-19 07:25:56 --> Utf8 Class Initialized
INFO - 2018-04-19 07:25:56 --> URI Class Initialized
INFO - 2018-04-19 07:25:56 --> Router Class Initialized
INFO - 2018-04-19 07:25:56 --> Output Class Initialized
INFO - 2018-04-19 07:25:56 --> Security Class Initialized
DEBUG - 2018-04-19 07:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 07:25:56 --> Input Class Initialized
INFO - 2018-04-19 07:25:56 --> Language Class Initialized
INFO - 2018-04-19 07:25:56 --> Language Class Initialized
INFO - 2018-04-19 07:25:56 --> Config Class Initialized
INFO - 2018-04-19 07:25:56 --> Loader Class Initialized
INFO - 2018-04-19 12:55:56 --> Helper loaded: url_helper
INFO - 2018-04-19 12:55:56 --> Helper loaded: notification_helper
INFO - 2018-04-19 12:55:56 --> Helper loaded: settings_helper
INFO - 2018-04-19 12:55:56 --> Helper loaded: permission_helper
INFO - 2018-04-19 12:55:56 --> Helper loaded: users_helper
INFO - 2018-04-19 12:55:56 --> Database Driver Class Initialized
DEBUG - 2018-04-19 12:55:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 12:55:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 12:55:56 --> Helper loaded: form_helper
INFO - 2018-04-19 12:55:56 --> Form Validation Class Initialized
INFO - 2018-04-19 12:55:56 --> Controller Class Initialized
INFO - 2018-04-19 12:55:56 --> Model Class Initialized
INFO - 2018-04-19 12:55:56 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 12:55:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 12:55:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 12:55:56 --> Model Class Initialized
INFO - 2018-04-19 12:55:56 --> Model Class Initialized
INFO - 2018-04-19 12:55:56 --> Model Class Initialized
INFO - 2018-04-19 12:55:56 --> Model Class Initialized
INFO - 2018-04-19 12:55:56 --> Model Class Initialized
INFO - 2018-04-19 12:55:56 --> Model Class Initialized
INFO - 2018-04-19 12:55:56 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 12:55:56 --> Final output sent to browser
DEBUG - 2018-04-19 12:55:56 --> Total execution time: 0.1159
INFO - 2018-04-19 07:25:57 --> Config Class Initialized
INFO - 2018-04-19 07:25:57 --> Hooks Class Initialized
DEBUG - 2018-04-19 07:25:57 --> UTF-8 Support Enabled
INFO - 2018-04-19 07:25:57 --> Utf8 Class Initialized
INFO - 2018-04-19 07:25:57 --> URI Class Initialized
INFO - 2018-04-19 07:25:57 --> Router Class Initialized
INFO - 2018-04-19 07:25:57 --> Output Class Initialized
INFO - 2018-04-19 07:25:57 --> Security Class Initialized
DEBUG - 2018-04-19 07:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 07:25:57 --> Input Class Initialized
INFO - 2018-04-19 07:25:57 --> Language Class Initialized
INFO - 2018-04-19 07:25:57 --> Language Class Initialized
INFO - 2018-04-19 07:25:57 --> Config Class Initialized
INFO - 2018-04-19 07:25:57 --> Loader Class Initialized
INFO - 2018-04-19 12:55:57 --> Helper loaded: url_helper
INFO - 2018-04-19 12:55:57 --> Helper loaded: notification_helper
INFO - 2018-04-19 12:55:57 --> Helper loaded: settings_helper
INFO - 2018-04-19 12:55:57 --> Helper loaded: permission_helper
INFO - 2018-04-19 12:55:57 --> Helper loaded: users_helper
INFO - 2018-04-19 12:55:57 --> Database Driver Class Initialized
DEBUG - 2018-04-19 12:55:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 12:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 12:55:57 --> Helper loaded: form_helper
INFO - 2018-04-19 12:55:57 --> Form Validation Class Initialized
INFO - 2018-04-19 12:55:57 --> Controller Class Initialized
INFO - 2018-04-19 12:55:57 --> Model Class Initialized
INFO - 2018-04-19 12:55:57 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 12:55:57 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 12:55:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 12:55:57 --> Model Class Initialized
INFO - 2018-04-19 12:55:57 --> Model Class Initialized
INFO - 2018-04-19 12:55:57 --> Model Class Initialized
INFO - 2018-04-19 12:55:57 --> Model Class Initialized
INFO - 2018-04-19 12:55:57 --> Model Class Initialized
INFO - 2018-04-19 12:55:57 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 12:55:57 --> Model Class Initialized
INFO - 2018-04-19 12:55:57 --> Final output sent to browser
DEBUG - 2018-04-19 12:55:57 --> Total execution time: 0.0814
INFO - 2018-04-19 07:26:05 --> Config Class Initialized
INFO - 2018-04-19 07:26:05 --> Hooks Class Initialized
DEBUG - 2018-04-19 07:26:05 --> UTF-8 Support Enabled
INFO - 2018-04-19 07:26:05 --> Utf8 Class Initialized
INFO - 2018-04-19 07:26:05 --> URI Class Initialized
INFO - 2018-04-19 07:26:05 --> Router Class Initialized
INFO - 2018-04-19 07:26:05 --> Output Class Initialized
INFO - 2018-04-19 07:26:05 --> Security Class Initialized
DEBUG - 2018-04-19 07:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 07:26:05 --> Input Class Initialized
INFO - 2018-04-19 07:26:05 --> Language Class Initialized
INFO - 2018-04-19 07:26:05 --> Language Class Initialized
INFO - 2018-04-19 07:26:05 --> Config Class Initialized
INFO - 2018-04-19 07:26:05 --> Loader Class Initialized
INFO - 2018-04-19 12:56:05 --> Helper loaded: url_helper
INFO - 2018-04-19 12:56:05 --> Helper loaded: notification_helper
INFO - 2018-04-19 12:56:05 --> Helper loaded: settings_helper
INFO - 2018-04-19 12:56:05 --> Helper loaded: permission_helper
INFO - 2018-04-19 12:56:05 --> Helper loaded: users_helper
INFO - 2018-04-19 12:56:05 --> Database Driver Class Initialized
DEBUG - 2018-04-19 12:56:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 12:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 12:56:05 --> Helper loaded: form_helper
INFO - 2018-04-19 12:56:05 --> Form Validation Class Initialized
INFO - 2018-04-19 12:56:05 --> Controller Class Initialized
INFO - 2018-04-19 12:56:05 --> Model Class Initialized
INFO - 2018-04-19 12:56:05 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 12:56:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 12:56:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 12:56:05 --> Model Class Initialized
INFO - 2018-04-19 12:56:05 --> Model Class Initialized
INFO - 2018-04-19 12:56:05 --> Model Class Initialized
INFO - 2018-04-19 12:56:05 --> Model Class Initialized
INFO - 2018-04-19 12:56:05 --> Model Class Initialized
INFO - 2018-04-19 12:56:05 --> Model Class Initialized
INFO - 2018-04-19 12:56:05 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 12:56:05 --> Upload Class Initialized
INFO - 2018-04-19 12:56:05 --> Final output sent to browser
DEBUG - 2018-04-19 12:56:05 --> Total execution time: 0.1171
INFO - 2018-04-19 07:26:07 --> Config Class Initialized
INFO - 2018-04-19 07:26:07 --> Hooks Class Initialized
DEBUG - 2018-04-19 07:26:07 --> UTF-8 Support Enabled
INFO - 2018-04-19 07:26:07 --> Utf8 Class Initialized
INFO - 2018-04-19 07:26:07 --> URI Class Initialized
INFO - 2018-04-19 07:26:07 --> Router Class Initialized
INFO - 2018-04-19 07:26:07 --> Output Class Initialized
INFO - 2018-04-19 07:26:07 --> Security Class Initialized
DEBUG - 2018-04-19 07:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 07:26:07 --> Input Class Initialized
INFO - 2018-04-19 07:26:07 --> Language Class Initialized
INFO - 2018-04-19 07:26:07 --> Language Class Initialized
INFO - 2018-04-19 07:26:07 --> Config Class Initialized
INFO - 2018-04-19 07:26:07 --> Loader Class Initialized
INFO - 2018-04-19 12:56:07 --> Helper loaded: url_helper
INFO - 2018-04-19 12:56:07 --> Helper loaded: notification_helper
INFO - 2018-04-19 12:56:07 --> Helper loaded: settings_helper
INFO - 2018-04-19 12:56:07 --> Helper loaded: permission_helper
INFO - 2018-04-19 12:56:07 --> Helper loaded: users_helper
INFO - 2018-04-19 12:56:07 --> Database Driver Class Initialized
DEBUG - 2018-04-19 12:56:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 12:56:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 12:56:07 --> Helper loaded: form_helper
INFO - 2018-04-19 12:56:07 --> Form Validation Class Initialized
INFO - 2018-04-19 12:56:07 --> Controller Class Initialized
INFO - 2018-04-19 12:56:07 --> Model Class Initialized
INFO - 2018-04-19 12:56:07 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 12:56:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 12:56:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 12:56:07 --> Model Class Initialized
INFO - 2018-04-19 12:56:07 --> Model Class Initialized
INFO - 2018-04-19 12:56:07 --> Model Class Initialized
INFO - 2018-04-19 12:56:07 --> Model Class Initialized
INFO - 2018-04-19 12:56:07 --> Model Class Initialized
INFO - 2018-04-19 12:56:07 --> Model Class Initialized
INFO - 2018-04-19 12:56:07 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 12:56:07 --> Final output sent to browser
DEBUG - 2018-04-19 12:56:07 --> Total execution time: 0.0781
INFO - 2018-04-19 07:26:47 --> Config Class Initialized
INFO - 2018-04-19 07:26:47 --> Hooks Class Initialized
DEBUG - 2018-04-19 07:26:47 --> UTF-8 Support Enabled
INFO - 2018-04-19 07:26:47 --> Utf8 Class Initialized
INFO - 2018-04-19 07:26:47 --> URI Class Initialized
INFO - 2018-04-19 07:26:47 --> Router Class Initialized
INFO - 2018-04-19 07:26:47 --> Output Class Initialized
INFO - 2018-04-19 07:26:47 --> Security Class Initialized
DEBUG - 2018-04-19 07:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 07:26:47 --> Input Class Initialized
INFO - 2018-04-19 07:26:47 --> Language Class Initialized
INFO - 2018-04-19 07:26:47 --> Language Class Initialized
INFO - 2018-04-19 07:26:47 --> Config Class Initialized
INFO - 2018-04-19 07:26:47 --> Loader Class Initialized
INFO - 2018-04-19 12:56:47 --> Helper loaded: url_helper
INFO - 2018-04-19 12:56:47 --> Helper loaded: notification_helper
INFO - 2018-04-19 12:56:47 --> Helper loaded: settings_helper
INFO - 2018-04-19 12:56:47 --> Helper loaded: permission_helper
INFO - 2018-04-19 12:56:47 --> Helper loaded: users_helper
INFO - 2018-04-19 12:56:47 --> Database Driver Class Initialized
DEBUG - 2018-04-19 12:56:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 12:56:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 12:56:47 --> Helper loaded: form_helper
INFO - 2018-04-19 12:56:47 --> Form Validation Class Initialized
INFO - 2018-04-19 12:56:47 --> Controller Class Initialized
INFO - 2018-04-19 12:56:47 --> Model Class Initialized
INFO - 2018-04-19 12:56:47 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 12:56:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 12:56:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 12:56:47 --> Model Class Initialized
INFO - 2018-04-19 12:56:47 --> Model Class Initialized
INFO - 2018-04-19 12:56:47 --> Model Class Initialized
INFO - 2018-04-19 12:56:47 --> Model Class Initialized
INFO - 2018-04-19 12:56:47 --> Model Class Initialized
INFO - 2018-04-19 12:56:47 --> Model Class Initialized
INFO - 2018-04-19 12:56:47 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 12:56:47 --> Final output sent to browser
DEBUG - 2018-04-19 12:56:47 --> Total execution time: 0.0812
INFO - 2018-04-19 07:26:48 --> Config Class Initialized
INFO - 2018-04-19 07:26:48 --> Hooks Class Initialized
DEBUG - 2018-04-19 07:26:48 --> UTF-8 Support Enabled
INFO - 2018-04-19 07:26:48 --> Utf8 Class Initialized
INFO - 2018-04-19 07:26:48 --> URI Class Initialized
INFO - 2018-04-19 07:26:48 --> Router Class Initialized
INFO - 2018-04-19 07:26:48 --> Output Class Initialized
INFO - 2018-04-19 07:26:48 --> Security Class Initialized
DEBUG - 2018-04-19 07:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 07:26:48 --> Input Class Initialized
INFO - 2018-04-19 07:26:48 --> Language Class Initialized
INFO - 2018-04-19 07:26:48 --> Language Class Initialized
INFO - 2018-04-19 07:26:48 --> Config Class Initialized
INFO - 2018-04-19 07:26:48 --> Loader Class Initialized
INFO - 2018-04-19 12:56:48 --> Helper loaded: url_helper
INFO - 2018-04-19 12:56:48 --> Helper loaded: notification_helper
INFO - 2018-04-19 12:56:48 --> Helper loaded: settings_helper
INFO - 2018-04-19 12:56:48 --> Helper loaded: permission_helper
INFO - 2018-04-19 12:56:48 --> Helper loaded: users_helper
INFO - 2018-04-19 12:56:48 --> Database Driver Class Initialized
DEBUG - 2018-04-19 12:56:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 12:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 12:56:48 --> Helper loaded: form_helper
INFO - 2018-04-19 12:56:48 --> Form Validation Class Initialized
INFO - 2018-04-19 12:56:48 --> Controller Class Initialized
INFO - 2018-04-19 12:56:48 --> Model Class Initialized
INFO - 2018-04-19 12:56:48 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 12:56:48 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 12:56:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 12:56:48 --> Model Class Initialized
INFO - 2018-04-19 12:56:48 --> Model Class Initialized
INFO - 2018-04-19 12:56:48 --> Model Class Initialized
INFO - 2018-04-19 12:56:48 --> Model Class Initialized
INFO - 2018-04-19 12:56:48 --> Model Class Initialized
INFO - 2018-04-19 12:56:48 --> Model Class Initialized
INFO - 2018-04-19 12:56:48 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 12:56:48 --> Final output sent to browser
DEBUG - 2018-04-19 12:56:48 --> Total execution time: 0.1067
INFO - 2018-04-19 07:27:09 --> Config Class Initialized
INFO - 2018-04-19 07:27:09 --> Hooks Class Initialized
DEBUG - 2018-04-19 07:27:09 --> UTF-8 Support Enabled
INFO - 2018-04-19 07:27:09 --> Utf8 Class Initialized
INFO - 2018-04-19 07:27:09 --> Config Class Initialized
INFO - 2018-04-19 07:27:09 --> Hooks Class Initialized
INFO - 2018-04-19 07:27:09 --> URI Class Initialized
DEBUG - 2018-04-19 07:27:09 --> UTF-8 Support Enabled
INFO - 2018-04-19 07:27:09 --> Utf8 Class Initialized
INFO - 2018-04-19 07:27:09 --> Router Class Initialized
INFO - 2018-04-19 07:27:09 --> URI Class Initialized
INFO - 2018-04-19 07:27:09 --> Output Class Initialized
INFO - 2018-04-19 07:27:09 --> Security Class Initialized
INFO - 2018-04-19 07:27:09 --> Router Class Initialized
DEBUG - 2018-04-19 07:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 07:27:09 --> Input Class Initialized
INFO - 2018-04-19 07:27:09 --> Output Class Initialized
INFO - 2018-04-19 07:27:09 --> Language Class Initialized
INFO - 2018-04-19 07:27:09 --> Security Class Initialized
DEBUG - 2018-04-19 07:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 07:27:09 --> Input Class Initialized
INFO - 2018-04-19 07:27:09 --> Config Class Initialized
INFO - 2018-04-19 07:27:09 --> Hooks Class Initialized
INFO - 2018-04-19 07:27:09 --> Language Class Initialized
DEBUG - 2018-04-19 07:27:09 --> UTF-8 Support Enabled
INFO - 2018-04-19 07:27:09 --> Utf8 Class Initialized
INFO - 2018-04-19 07:27:09 --> URI Class Initialized
INFO - 2018-04-19 07:27:09 --> Router Class Initialized
INFO - 2018-04-19 07:27:09 --> Output Class Initialized
INFO - 2018-04-19 07:27:09 --> Language Class Initialized
INFO - 2018-04-19 07:27:09 --> Config Class Initialized
INFO - 2018-04-19 07:27:09 --> Loader Class Initialized
INFO - 2018-04-19 07:27:09 --> Security Class Initialized
INFO - 2018-04-19 12:57:09 --> Helper loaded: url_helper
INFO - 2018-04-19 12:57:09 --> Helper loaded: notification_helper
DEBUG - 2018-04-19 07:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 07:27:09 --> Input Class Initialized
INFO - 2018-04-19 12:57:09 --> Helper loaded: settings_helper
INFO - 2018-04-19 07:27:09 --> Language Class Initialized
INFO - 2018-04-19 12:57:09 --> Helper loaded: permission_helper
INFO - 2018-04-19 12:57:09 --> Helper loaded: users_helper
INFO - 2018-04-19 07:27:09 --> Language Class Initialized
INFO - 2018-04-19 07:27:09 --> Config Class Initialized
INFO - 2018-04-19 07:27:09 --> Loader Class Initialized
INFO - 2018-04-19 12:57:09 --> Helper loaded: url_helper
INFO - 2018-04-19 12:57:09 --> Helper loaded: notification_helper
INFO - 2018-04-19 12:57:09 --> Helper loaded: settings_helper
INFO - 2018-04-19 12:57:09 --> Helper loaded: permission_helper
INFO - 2018-04-19 12:57:09 --> Helper loaded: users_helper
INFO - 2018-04-19 12:57:09 --> Database Driver Class Initialized
INFO - 2018-04-19 07:27:09 --> Language Class Initialized
INFO - 2018-04-19 07:27:09 --> Config Class Initialized
INFO - 2018-04-19 07:27:09 --> Loader Class Initialized
DEBUG - 2018-04-19 12:57:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 12:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 12:57:09 --> Helper loaded: url_helper
INFO - 2018-04-19 12:57:09 --> Helper loaded: notification_helper
INFO - 2018-04-19 12:57:09 --> Helper loaded: settings_helper
INFO - 2018-04-19 12:57:09 --> Database Driver Class Initialized
INFO - 2018-04-19 12:57:09 --> Helper loaded: permission_helper
INFO - 2018-04-19 12:57:09 --> Helper loaded: users_helper
INFO - 2018-04-19 12:57:09 --> Helper loaded: form_helper
INFO - 2018-04-19 12:57:09 --> Form Validation Class Initialized
INFO - 2018-04-19 12:57:09 --> Controller Class Initialized
DEBUG - 2018-04-19 12:57:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 12:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 12:57:09 --> Helper loaded: form_helper
INFO - 2018-04-19 12:57:09 --> Form Validation Class Initialized
INFO - 2018-04-19 12:57:09 --> Controller Class Initialized
INFO - 2018-04-19 12:57:09 --> Model Class Initialized
INFO - 2018-04-19 12:57:09 --> Helper loaded: inflector_helper
INFO - 2018-04-19 12:57:09 --> Database Driver Class Initialized
DEBUG - 2018-04-19 12:57:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 07:27:09 --> Config Class Initialized
INFO - 2018-04-19 07:27:09 --> Hooks Class Initialized
INFO - 2018-04-19 12:57:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 12:57:09 --> Model Class Initialized
DEBUG - 2018-04-19 12:57:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 12:57:09 --> Model Class Initialized
INFO - 2018-04-19 12:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 12:57:09 --> Model Class Initialized
INFO - 2018-04-19 12:57:09 --> Model Class Initialized
DEBUG - 2018-04-19 07:27:09 --> UTF-8 Support Enabled
INFO - 2018-04-19 07:27:09 --> Utf8 Class Initialized
INFO - 2018-04-19 12:57:09 --> Model Class Initialized
INFO - 2018-04-19 12:57:09 --> Model Class Initialized
INFO - 2018-04-19 12:57:09 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 12:57:09 --> Model Class Initialized
INFO - 2018-04-19 12:57:09 --> Helper loaded: inflector_helper
INFO - 2018-04-19 07:27:09 --> URI Class Initialized
INFO - 2018-04-19 12:57:09 --> Model Class Initialized
INFO - 2018-04-19 12:57:09 --> Final output sent to browser
DEBUG - 2018-04-19 12:57:09 --> Total execution time: 0.1125
INFO - 2018-04-19 12:57:09 --> Helper loaded: form_helper
INFO - 2018-04-19 12:57:09 --> Form Validation Class Initialized
INFO - 2018-04-19 12:57:09 --> Controller Class Initialized
DEBUG - 2018-04-19 12:57:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 07:27:09 --> Router Class Initialized
INFO - 2018-04-19 12:57:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 12:57:09 --> Model Class Initialized
INFO - 2018-04-19 12:57:09 --> Model Class Initialized
INFO - 2018-04-19 12:57:09 --> Model Class Initialized
INFO - 2018-04-19 12:57:09 --> Model Class Initialized
INFO - 2018-04-19 12:57:09 --> Model Class Initialized
INFO - 2018-04-19 12:57:09 --> Helper loaded: inflector_helper
INFO - 2018-04-19 12:57:09 --> Model Class Initialized
INFO - 2018-04-19 12:57:09 --> Model Class Initialized
INFO - 2018-04-19 12:57:09 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 07:27:09 --> Output Class Initialized
DEBUG - 2018-04-19 12:57:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 12:57:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 12:57:09 --> Model Class Initialized
INFO - 2018-04-19 12:57:09 --> Model Class Initialized
INFO - 2018-04-19 12:57:09 --> Model Class Initialized
INFO - 2018-04-19 07:27:09 --> Security Class Initialized
INFO - 2018-04-19 12:57:09 --> Model Class Initialized
INFO - 2018-04-19 12:57:09 --> Model Class Initialized
INFO - 2018-04-19 12:57:09 --> Model Class Initialized
INFO - 2018-04-19 12:57:09 --> Model Class Initialized
INFO - 2018-04-19 12:57:09 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 12:57:09 --> Final output sent to browser
DEBUG - 2018-04-19 12:57:09 --> Total execution time: 0.1308
DEBUG - 2018-04-19 07:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 07:27:09 --> Input Class Initialized
INFO - 2018-04-19 12:57:09 --> Final output sent to browser
DEBUG - 2018-04-19 12:57:09 --> Total execution time: 0.1133
INFO - 2018-04-19 07:27:09 --> Language Class Initialized
INFO - 2018-04-19 07:27:09 --> Language Class Initialized
INFO - 2018-04-19 07:27:09 --> Config Class Initialized
INFO - 2018-04-19 07:27:09 --> Loader Class Initialized
INFO - 2018-04-19 12:57:09 --> Helper loaded: url_helper
INFO - 2018-04-19 12:57:09 --> Helper loaded: notification_helper
INFO - 2018-04-19 12:57:09 --> Helper loaded: settings_helper
INFO - 2018-04-19 12:57:09 --> Helper loaded: permission_helper
INFO - 2018-04-19 12:57:09 --> Helper loaded: users_helper
INFO - 2018-04-19 12:57:09 --> Database Driver Class Initialized
DEBUG - 2018-04-19 12:57:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 12:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 12:57:09 --> Helper loaded: form_helper
INFO - 2018-04-19 12:57:09 --> Form Validation Class Initialized
INFO - 2018-04-19 12:57:09 --> Controller Class Initialized
INFO - 2018-04-19 12:57:09 --> Model Class Initialized
INFO - 2018-04-19 12:57:09 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 12:57:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 12:57:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 12:57:09 --> Model Class Initialized
INFO - 2018-04-19 12:57:09 --> Model Class Initialized
INFO - 2018-04-19 12:57:09 --> Model Class Initialized
INFO - 2018-04-19 12:57:09 --> Model Class Initialized
INFO - 2018-04-19 12:57:09 --> Model Class Initialized
INFO - 2018-04-19 12:57:09 --> Model Class Initialized
INFO - 2018-04-19 12:57:09 --> Model Class Initialized
INFO - 2018-04-19 12:57:09 --> Model Class Initialized
INFO - 2018-04-19 12:57:09 --> Model Class Initialized
INFO - 2018-04-19 12:57:09 --> Model Class Initialized
INFO - 2018-04-19 12:57:09 --> Model Class Initialized
INFO - 2018-04-19 12:57:09 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 12:57:09 --> Model Class Initialized
INFO - 2018-04-19 12:57:09 --> Final output sent to browser
DEBUG - 2018-04-19 12:57:09 --> Total execution time: 0.1505
INFO - 2018-04-19 07:27:10 --> Config Class Initialized
INFO - 2018-04-19 07:27:10 --> Hooks Class Initialized
DEBUG - 2018-04-19 07:27:10 --> UTF-8 Support Enabled
INFO - 2018-04-19 07:27:10 --> Utf8 Class Initialized
INFO - 2018-04-19 07:27:10 --> URI Class Initialized
INFO - 2018-04-19 07:27:10 --> Router Class Initialized
INFO - 2018-04-19 07:27:10 --> Output Class Initialized
INFO - 2018-04-19 07:27:10 --> Security Class Initialized
DEBUG - 2018-04-19 07:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 07:27:10 --> Input Class Initialized
INFO - 2018-04-19 07:27:10 --> Language Class Initialized
INFO - 2018-04-19 07:27:10 --> Language Class Initialized
INFO - 2018-04-19 07:27:10 --> Config Class Initialized
INFO - 2018-04-19 07:27:10 --> Loader Class Initialized
INFO - 2018-04-19 12:57:10 --> Helper loaded: url_helper
INFO - 2018-04-19 12:57:10 --> Helper loaded: notification_helper
INFO - 2018-04-19 12:57:10 --> Helper loaded: settings_helper
INFO - 2018-04-19 12:57:10 --> Helper loaded: permission_helper
INFO - 2018-04-19 12:57:10 --> Helper loaded: users_helper
INFO - 2018-04-19 12:57:11 --> Database Driver Class Initialized
DEBUG - 2018-04-19 12:57:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 12:57:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 12:57:11 --> Helper loaded: form_helper
INFO - 2018-04-19 12:57:11 --> Form Validation Class Initialized
INFO - 2018-04-19 12:57:11 --> Controller Class Initialized
INFO - 2018-04-19 12:57:11 --> Model Class Initialized
INFO - 2018-04-19 12:57:11 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 12:57:11 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 12:57:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 12:57:11 --> Model Class Initialized
INFO - 2018-04-19 12:57:11 --> Model Class Initialized
INFO - 2018-04-19 12:57:11 --> Model Class Initialized
INFO - 2018-04-19 12:57:11 --> Model Class Initialized
INFO - 2018-04-19 12:57:11 --> Model Class Initialized
INFO - 2018-04-19 12:57:11 --> Model Class Initialized
INFO - 2018-04-19 12:57:11 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 12:57:11 --> Final output sent to browser
DEBUG - 2018-04-19 12:57:11 --> Total execution time: 0.1167
INFO - 2018-04-19 07:27:11 --> Config Class Initialized
INFO - 2018-04-19 07:27:11 --> Hooks Class Initialized
DEBUG - 2018-04-19 07:27:11 --> UTF-8 Support Enabled
INFO - 2018-04-19 07:27:11 --> Utf8 Class Initialized
INFO - 2018-04-19 07:27:11 --> URI Class Initialized
INFO - 2018-04-19 07:27:11 --> Router Class Initialized
INFO - 2018-04-19 07:27:11 --> Output Class Initialized
INFO - 2018-04-19 07:27:11 --> Security Class Initialized
DEBUG - 2018-04-19 07:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 07:27:11 --> Input Class Initialized
INFO - 2018-04-19 07:27:11 --> Language Class Initialized
INFO - 2018-04-19 07:27:11 --> Language Class Initialized
INFO - 2018-04-19 07:27:11 --> Config Class Initialized
INFO - 2018-04-19 07:27:11 --> Loader Class Initialized
INFO - 2018-04-19 12:57:11 --> Helper loaded: url_helper
INFO - 2018-04-19 12:57:11 --> Helper loaded: notification_helper
INFO - 2018-04-19 12:57:11 --> Helper loaded: settings_helper
INFO - 2018-04-19 12:57:11 --> Helper loaded: permission_helper
INFO - 2018-04-19 12:57:11 --> Helper loaded: users_helper
INFO - 2018-04-19 12:57:11 --> Database Driver Class Initialized
DEBUG - 2018-04-19 12:57:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 12:57:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 12:57:11 --> Helper loaded: form_helper
INFO - 2018-04-19 12:57:11 --> Form Validation Class Initialized
INFO - 2018-04-19 12:57:11 --> Controller Class Initialized
INFO - 2018-04-19 12:57:11 --> Model Class Initialized
INFO - 2018-04-19 12:57:11 --> Helper loaded: inflector_helper
DEBUG - 2018-04-19 12:57:11 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-19 12:57:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-19 12:57:11 --> Model Class Initialized
INFO - 2018-04-19 12:57:11 --> Model Class Initialized
INFO - 2018-04-19 12:57:11 --> Model Class Initialized
INFO - 2018-04-19 12:57:11 --> Model Class Initialized
INFO - 2018-04-19 12:57:11 --> Model Class Initialized
INFO - 2018-04-19 12:57:11 --> Model Class Initialized
INFO - 2018-04-19 12:57:11 --> Model Class Initialized
INFO - 2018-04-19 12:57:11 --> Model Class Initialized
INFO - 2018-04-19 12:57:11 --> Model Class Initialized
INFO - 2018-04-19 12:57:11 --> Model Class Initialized
INFO - 2018-04-19 12:57:11 --> Model Class Initialized
INFO - 2018-04-19 12:57:11 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-19 12:57:11 --> Model Class Initialized
INFO - 2018-04-19 12:57:11 --> Final output sent to browser
DEBUG - 2018-04-19 12:57:11 --> Total execution time: 0.0924
