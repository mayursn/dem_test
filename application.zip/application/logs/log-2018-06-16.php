<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-06-16 00:00:02 --> Helper loaded: url_helper
INFO - 2018-06-16 00:00:02 --> Helper loaded: notification_helper
INFO - 2018-06-16 00:00:02 --> Helper loaded: settings_helper
INFO - 2018-06-16 00:00:02 --> Helper loaded: permission_helper
INFO - 2018-06-16 00:00:02 --> Helper loaded: users_helper
INFO - 2018-06-16 00:00:02 --> Database Driver Class Initialized
DEBUG - 2018-06-16 00:00:02 --> Session: Initialization under CLI aborted.
INFO - 2018-06-16 00:00:02 --> Helper loaded: form_helper
INFO - 2018-06-16 00:00:02 --> Form Validation Class Initialized
INFO - 2018-06-16 00:00:02 --> Controller Class Initialized
INFO - 2018-06-16 00:00:02 --> Model Class Initialized
INFO - 2018-06-16 00:00:02 --> Helper loaded: inflector_helper
DEBUG - 2018-06-16 00:00:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 00:00:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 00:00:02 --> Model Class Initialized
INFO - 2018-06-16 00:00:02 --> Model Class Initialized
INFO - 2018-06-16 00:00:02 --> Model Class Initialized
INFO - 2018-06-16 00:00:02 --> Model Class Initialized
INFO - 2018-06-16 00:00:02 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-16 00:00:02 --> Model Class Initialized
ERROR - 2018-06-16 00:00:02 --> Severity: Notice --> Undefined property: stdClass::$promoted_users_id /home/pr01004/public_html/application/controllers/api/Credits.php 1197
INFO - 2018-06-16 00:00:02 --> Helper loaded: url_helper
INFO - 2018-06-16 00:00:02 --> Helper loaded: notification_helper
INFO - 2018-06-16 00:00:02 --> Helper loaded: settings_helper
INFO - 2018-06-16 00:00:02 --> Helper loaded: permission_helper
INFO - 2018-06-16 00:00:02 --> Helper loaded: users_helper
INFO - 2018-06-16 00:00:02 --> Database Driver Class Initialized
DEBUG - 2018-06-16 00:00:02 --> Session: Initialization under CLI aborted.
INFO - 2018-06-16 00:00:02 --> Helper loaded: form_helper
INFO - 2018-06-16 00:00:02 --> Form Validation Class Initialized
INFO - 2018-06-16 00:00:02 --> Controller Class Initialized
ERROR - 2018-06-16 00:00:02 --> Severity: Notice --> Undefined property: stdClass::$promoted_users_id /home/pr01004/public_html/application/controllers/api/Credits.php 1197
ERROR - 2018-06-16 00:00:02 --> Severity: Notice --> Undefined property: stdClass::$promoted_users_id /home/pr01004/public_html/application/controllers/api/Credits.php 1197
ERROR - 2018-06-16 00:00:02 --> Severity: Notice --> Undefined property: stdClass::$promoted_users_id /home/pr01004/public_html/application/controllers/api/Credits.php 1197
ERROR - 2018-06-16 00:00:02 --> Severity: Notice --> Undefined property: stdClass::$promoted_users_id /home/pr01004/public_html/application/controllers/api/Credits.php 1197
ERROR - 2018-06-16 00:00:02 --> Severity: Notice --> Undefined property: stdClass::$promoted_users_id /home/pr01004/public_html/application/controllers/api/Credits.php 1197
ERROR - 2018-06-16 00:00:02 --> Severity: Notice --> Undefined property: stdClass::$promoted_users_id /home/pr01004/public_html/application/controllers/api/Credits.php 1197
INFO - 2018-06-16 00:00:02 --> Model Class Initialized
INFO - 2018-06-16 00:00:02 --> Helper loaded: inflector_helper
DEBUG - 2018-06-16 00:00:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 00:00:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 00:00:02 --> Model Class Initialized
INFO - 2018-06-16 00:00:02 --> Model Class Initialized
INFO - 2018-06-16 00:00:02 --> Model Class Initialized
INFO - 2018-06-16 00:00:02 --> Model Class Initialized
INFO - 2018-06-16 00:00:02 --> Model Class Initialized
INFO - 2018-06-16 00:00:02 --> Model Class Initialized
INFO - 2018-06-16 00:00:02 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-16 00:00:02 --> Final output sent to browser
DEBUG - 2018-06-16 00:00:02 --> Total execution time: 0.1438
INFO - 2018-06-16 00:00:02 --> Model Class Initialized
INFO - 2018-06-16 00:00:02 --> Final output sent to browser
DEBUG - 2018-06-16 00:00:02 --> Total execution time: 0.0545
INFO - 2018-06-16 02:00:27 --> Helper loaded: url_helper
INFO - 2018-06-16 02:00:27 --> Helper loaded: notification_helper
INFO - 2018-06-16 02:00:27 --> Helper loaded: settings_helper
INFO - 2018-06-16 02:00:27 --> Helper loaded: permission_helper
INFO - 2018-06-16 02:00:27 --> Helper loaded: users_helper
INFO - 2018-06-16 02:00:27 --> Database Driver Class Initialized
DEBUG - 2018-06-16 02:00:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 02:00:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 02:00:27 --> Helper loaded: url_helper
INFO - 2018-06-16 02:00:27 --> Helper loaded: notification_helper
INFO - 2018-06-16 02:00:27 --> Helper loaded: settings_helper
INFO - 2018-06-16 02:00:27 --> Helper loaded: permission_helper
INFO - 2018-06-16 02:00:27 --> Helper loaded: users_helper
INFO - 2018-06-16 02:00:27 --> Helper loaded: form_helper
INFO - 2018-06-16 02:00:27 --> Form Validation Class Initialized
INFO - 2018-06-16 02:00:27 --> Controller Class Initialized
INFO - 2018-06-16 02:00:27 --> Model Class Initialized
INFO - 2018-06-16 02:00:27 --> Helper loaded: inflector_helper
INFO - 2018-06-16 02:00:27 --> Database Driver Class Initialized
DEBUG - 2018-06-16 02:00:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 02:00:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 02:00:27 --> Model Class Initialized
INFO - 2018-06-16 02:00:27 --> Model Class Initialized
INFO - 2018-06-16 02:00:27 --> Model Class Initialized
INFO - 2018-06-16 02:00:27 --> Model Class Initialized
INFO - 2018-06-16 02:00:27 --> Model Class Initialized
INFO - 2018-06-16 02:00:27 --> Model Class Initialized
INFO - 2018-06-16 02:00:27 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-06-16 02:00:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 02:00:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 02:00:27 --> Final output sent to browser
DEBUG - 2018-06-16 02:00:27 --> Total execution time: 0.1531
INFO - 2018-06-16 02:00:27 --> Helper loaded: form_helper
INFO - 2018-06-16 02:00:27 --> Form Validation Class Initialized
INFO - 2018-06-16 02:00:27 --> Controller Class Initialized
INFO - 2018-06-16 02:00:27 --> Model Class Initialized
INFO - 2018-06-16 02:00:27 --> Helper loaded: inflector_helper
DEBUG - 2018-06-16 02:00:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 02:00:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 02:00:27 --> Model Class Initialized
INFO - 2018-06-16 02:00:27 --> Model Class Initialized
INFO - 2018-06-16 02:00:27 --> Model Class Initialized
INFO - 2018-06-16 02:00:27 --> Model Class Initialized
INFO - 2018-06-16 02:00:27 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-16 02:00:27 --> Model Class Initialized
INFO - 2018-06-16 02:00:27 --> Final output sent to browser
DEBUG - 2018-06-16 02:00:27 --> Total execution time: 0.1959
INFO - 2018-06-16 02:00:29 --> Helper loaded: url_helper
INFO - 2018-06-16 02:00:29 --> Helper loaded: notification_helper
INFO - 2018-06-16 02:00:29 --> Helper loaded: settings_helper
INFO - 2018-06-16 02:00:29 --> Helper loaded: permission_helper
INFO - 2018-06-16 02:00:29 --> Helper loaded: users_helper
INFO - 2018-06-16 02:00:29 --> Database Driver Class Initialized
DEBUG - 2018-06-16 02:00:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 02:00:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 02:00:29 --> Helper loaded: form_helper
INFO - 2018-06-16 02:00:29 --> Form Validation Class Initialized
INFO - 2018-06-16 02:00:29 --> Controller Class Initialized
INFO - 2018-06-16 02:00:29 --> Helper loaded: url_helper
INFO - 2018-06-16 02:00:29 --> Helper loaded: notification_helper
INFO - 2018-06-16 02:00:29 --> Helper loaded: settings_helper
INFO - 2018-06-16 02:00:29 --> Helper loaded: permission_helper
INFO - 2018-06-16 02:00:29 --> Helper loaded: users_helper
INFO - 2018-06-16 02:00:29 --> Database Driver Class Initialized
DEBUG - 2018-06-16 02:00:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 02:00:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 02:00:29 --> Helper loaded: form_helper
INFO - 2018-06-16 02:00:29 --> Form Validation Class Initialized
INFO - 2018-06-16 02:00:29 --> Controller Class Initialized
INFO - 2018-06-16 02:00:29 --> Model Class Initialized
INFO - 2018-06-16 02:00:29 --> Helper loaded: inflector_helper
INFO - 2018-06-16 02:00:29 --> Model Class Initialized
INFO - 2018-06-16 02:00:29 --> Helper loaded: inflector_helper
DEBUG - 2018-06-16 02:00:29 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-06-16 02:00:29 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 02:00:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 02:00:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 02:00:29 --> Model Class Initialized
INFO - 2018-06-16 02:00:29 --> Model Class Initialized
INFO - 2018-06-16 02:00:29 --> Model Class Initialized
INFO - 2018-06-16 02:00:29 --> Model Class Initialized
INFO - 2018-06-16 02:00:29 --> Model Class Initialized
INFO - 2018-06-16 02:00:29 --> Model Class Initialized
INFO - 2018-06-16 02:00:29 --> Model Class Initialized
INFO - 2018-06-16 02:00:29 --> Model Class Initialized
INFO - 2018-06-16 02:00:29 --> Model Class Initialized
INFO - 2018-06-16 02:00:29 --> Model Class Initialized
INFO - 2018-06-16 02:00:29 --> Model Class Initialized
INFO - 2018-06-16 02:00:29 --> Model Class Initialized
INFO - 2018-06-16 02:00:29 --> Model Class Initialized
INFO - 2018-06-16 02:00:29 --> Model Class Initialized
INFO - 2018-06-16 02:00:29 --> Model Class Initialized
INFO - 2018-06-16 02:00:29 --> Model Class Initialized
INFO - 2018-06-16 02:00:29 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-16 02:00:29 --> Model Class Initialized
INFO - 2018-06-16 02:00:29 --> Model Class Initialized
INFO - 2018-06-16 02:00:29 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-16 02:00:29 --> Model Class Initialized
INFO - 2018-06-16 02:00:29 --> Final output sent to browser
DEBUG - 2018-06-16 02:00:29 --> Total execution time: 0.1988
INFO - 2018-06-16 02:00:29 --> Final output sent to browser
DEBUG - 2018-06-16 02:00:29 --> Total execution time: 0.1524
INFO - 2018-06-16 02:00:29 --> Helper loaded: url_helper
INFO - 2018-06-16 02:00:29 --> Helper loaded: notification_helper
INFO - 2018-06-16 02:00:29 --> Helper loaded: settings_helper
INFO - 2018-06-16 02:00:29 --> Helper loaded: permission_helper
INFO - 2018-06-16 02:00:29 --> Helper loaded: users_helper
INFO - 2018-06-16 02:00:29 --> Database Driver Class Initialized
DEBUG - 2018-06-16 02:00:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 02:00:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 02:00:29 --> Helper loaded: form_helper
INFO - 2018-06-16 02:00:29 --> Form Validation Class Initialized
INFO - 2018-06-16 02:00:29 --> Controller Class Initialized
INFO - 2018-06-16 02:00:29 --> Model Class Initialized
INFO - 2018-06-16 02:00:29 --> Helper loaded: inflector_helper
DEBUG - 2018-06-16 02:00:29 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 02:00:29 --> Helper loaded: url_helper
INFO - 2018-06-16 02:00:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 02:00:29 --> Model Class Initialized
INFO - 2018-06-16 02:00:29 --> Helper loaded: notification_helper
INFO - 2018-06-16 02:00:29 --> Model Class Initialized
INFO - 2018-06-16 02:00:29 --> Helper loaded: settings_helper
INFO - 2018-06-16 02:00:29 --> Helper loaded: permission_helper
INFO - 2018-06-16 02:00:29 --> Model Class Initialized
INFO - 2018-06-16 02:00:29 --> Model Class Initialized
INFO - 2018-06-16 02:00:29 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-16 02:00:29 --> Model Class Initialized
INFO - 2018-06-16 02:00:29 --> Helper loaded: users_helper
INFO - 2018-06-16 02:00:29 --> Final output sent to browser
DEBUG - 2018-06-16 02:00:29 --> Total execution time: 0.1056
INFO - 2018-06-16 02:00:29 --> Database Driver Class Initialized
INFO - 2018-06-16 02:00:29 --> Helper loaded: url_helper
INFO - 2018-06-16 02:00:29 --> Helper loaded: notification_helper
INFO - 2018-06-16 02:00:29 --> Helper loaded: settings_helper
INFO - 2018-06-16 02:00:29 --> Helper loaded: permission_helper
DEBUG - 2018-06-16 02:00:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 02:00:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 02:00:29 --> Helper loaded: users_helper
INFO - 2018-06-16 02:00:29 --> Helper loaded: form_helper
INFO - 2018-06-16 02:00:29 --> Form Validation Class Initialized
INFO - 2018-06-16 02:00:29 --> Controller Class Initialized
INFO - 2018-06-16 02:00:29 --> Helper loaded: url_helper
INFO - 2018-06-16 02:00:29 --> Helper loaded: notification_helper
INFO - 2018-06-16 02:00:29 --> Helper loaded: settings_helper
INFO - 2018-06-16 02:00:29 --> Helper loaded: permission_helper
INFO - 2018-06-16 02:00:29 --> Helper loaded: users_helper
INFO - 2018-06-16 02:00:29 --> Model Class Initialized
INFO - 2018-06-16 02:00:29 --> Helper loaded: inflector_helper
DEBUG - 2018-06-16 02:00:29 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 02:00:29 --> Database Driver Class Initialized
INFO - 2018-06-16 02:00:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 02:00:29 --> Model Class Initialized
INFO - 2018-06-16 02:00:29 --> Model Class Initialized
INFO - 2018-06-16 02:00:29 --> Model Class Initialized
INFO - 2018-06-16 02:00:29 --> Model Class Initialized
INFO - 2018-06-16 02:00:29 --> Model Class Initialized
INFO - 2018-06-16 02:00:29 --> Model Class Initialized
INFO - 2018-06-16 02:00:29 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-16 02:00:29 --> Model Class Initialized
INFO - 2018-06-16 02:00:29 --> Final output sent to browser
DEBUG - 2018-06-16 02:00:29 --> Total execution time: 0.1080
INFO - 2018-06-16 02:00:29 --> Database Driver Class Initialized
DEBUG - 2018-06-16 02:00:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 02:00:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-06-16 02:00:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 02:00:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 02:00:30 --> Helper loaded: form_helper
INFO - 2018-06-16 02:00:30 --> Form Validation Class Initialized
INFO - 2018-06-16 02:00:30 --> Controller Class Initialized
INFO - 2018-06-16 02:00:30 --> Helper loaded: form_helper
INFO - 2018-06-16 02:00:30 --> Form Validation Class Initialized
INFO - 2018-06-16 02:00:30 --> Controller Class Initialized
INFO - 2018-06-16 02:00:30 --> Model Class Initialized
INFO - 2018-06-16 02:00:30 --> Helper loaded: inflector_helper
DEBUG - 2018-06-16 02:00:30 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 02:00:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 02:00:30 --> Model Class Initialized
INFO - 2018-06-16 02:00:30 --> Model Class Initialized
INFO - 2018-06-16 02:00:30 --> Model Class Initialized
INFO - 2018-06-16 02:00:30 --> Model Class Initialized
INFO - 2018-06-16 02:00:30 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-16 02:00:30 --> Model Class Initialized
INFO - 2018-06-16 02:00:30 --> Final output sent to browser
DEBUG - 2018-06-16 02:00:30 --> Total execution time: 0.1334
INFO - 2018-06-16 02:00:30 --> Model Class Initialized
INFO - 2018-06-16 02:00:30 --> Helper loaded: inflector_helper
DEBUG - 2018-06-16 02:00:30 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 02:00:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 02:00:30 --> Model Class Initialized
INFO - 2018-06-16 02:00:30 --> Model Class Initialized
INFO - 2018-06-16 02:00:30 --> Model Class Initialized
INFO - 2018-06-16 02:00:30 --> Model Class Initialized
INFO - 2018-06-16 02:00:30 --> Model Class Initialized
INFO - 2018-06-16 02:00:30 --> Model Class Initialized
INFO - 2018-06-16 02:00:30 --> Model Class Initialized
INFO - 2018-06-16 02:00:30 --> Model Class Initialized
INFO - 2018-06-16 02:00:30 --> Model Class Initialized
INFO - 2018-06-16 02:00:30 --> Model Class Initialized
INFO - 2018-06-16 02:00:30 --> Model Class Initialized
INFO - 2018-06-16 02:00:30 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-16 02:00:30 --> Model Class Initialized
INFO - 2018-06-16 02:00:30 --> Final output sent to browser
DEBUG - 2018-06-16 02:00:30 --> Total execution time: 0.2265
INFO - 2018-06-16 02:00:33 --> Helper loaded: url_helper
INFO - 2018-06-16 02:00:33 --> Helper loaded: notification_helper
INFO - 2018-06-16 02:00:33 --> Helper loaded: settings_helper
INFO - 2018-06-16 02:00:33 --> Helper loaded: permission_helper
INFO - 2018-06-16 02:00:33 --> Helper loaded: users_helper
INFO - 2018-06-16 02:00:33 --> Database Driver Class Initialized
DEBUG - 2018-06-16 02:00:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 02:00:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 02:00:33 --> Helper loaded: form_helper
INFO - 2018-06-16 02:00:33 --> Form Validation Class Initialized
INFO - 2018-06-16 02:00:33 --> Controller Class Initialized
INFO - 2018-06-16 02:00:33 --> Model Class Initialized
INFO - 2018-06-16 02:00:33 --> Helper loaded: inflector_helper
DEBUG - 2018-06-16 02:00:33 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 02:00:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 02:00:33 --> Model Class Initialized
INFO - 2018-06-16 02:00:33 --> Model Class Initialized
INFO - 2018-06-16 02:00:33 --> Model Class Initialized
INFO - 2018-06-16 02:00:33 --> Model Class Initialized
INFO - 2018-06-16 02:00:33 --> Helper loaded: url_helper
INFO - 2018-06-16 02:00:33 --> Final output sent to browser
DEBUG - 2018-06-16 02:00:33 --> Total execution time: 0.1109
INFO - 2018-06-16 02:00:33 --> Helper loaded: notification_helper
INFO - 2018-06-16 02:00:33 --> Helper loaded: settings_helper
INFO - 2018-06-16 02:00:33 --> Helper loaded: permission_helper
INFO - 2018-06-16 02:00:33 --> Helper loaded: users_helper
INFO - 2018-06-16 02:00:33 --> Database Driver Class Initialized
DEBUG - 2018-06-16 02:00:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 02:00:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 02:00:33 --> Helper loaded: form_helper
INFO - 2018-06-16 02:00:33 --> Form Validation Class Initialized
INFO - 2018-06-16 02:00:33 --> Controller Class Initialized
INFO - 2018-06-16 02:00:33 --> Model Class Initialized
INFO - 2018-06-16 02:00:33 --> Helper loaded: inflector_helper
DEBUG - 2018-06-16 02:00:33 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 02:00:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 02:00:33 --> Model Class Initialized
INFO - 2018-06-16 02:00:33 --> Model Class Initialized
INFO - 2018-06-16 02:00:33 --> Model Class Initialized
INFO - 2018-06-16 02:00:33 --> Model Class Initialized
INFO - 2018-06-16 02:00:33 --> Final output sent to browser
DEBUG - 2018-06-16 02:00:33 --> Total execution time: 0.0903
INFO - 2018-06-16 02:00:37 --> Helper loaded: url_helper
INFO - 2018-06-16 02:00:37 --> Helper loaded: notification_helper
INFO - 2018-06-16 02:00:37 --> Helper loaded: settings_helper
INFO - 2018-06-16 02:00:37 --> Helper loaded: permission_helper
INFO - 2018-06-16 02:00:37 --> Helper loaded: users_helper
INFO - 2018-06-16 02:00:37 --> Helper loaded: url_helper
INFO - 2018-06-16 02:00:37 --> Helper loaded: notification_helper
INFO - 2018-06-16 02:00:37 --> Helper loaded: settings_helper
INFO - 2018-06-16 02:00:37 --> Helper loaded: permission_helper
INFO - 2018-06-16 02:00:37 --> Database Driver Class Initialized
INFO - 2018-06-16 02:00:37 --> Helper loaded: users_helper
DEBUG - 2018-06-16 02:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 02:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 02:00:37 --> Database Driver Class Initialized
INFO - 2018-06-16 02:00:37 --> Helper loaded: form_helper
INFO - 2018-06-16 02:00:37 --> Form Validation Class Initialized
INFO - 2018-06-16 02:00:37 --> Controller Class Initialized
DEBUG - 2018-06-16 02:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 02:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 02:00:37 --> Model Class Initialized
INFO - 2018-06-16 02:00:37 --> Helper loaded: inflector_helper
INFO - 2018-06-16 02:00:37 --> Helper loaded: form_helper
INFO - 2018-06-16 02:00:37 --> Form Validation Class Initialized
INFO - 2018-06-16 02:00:37 --> Controller Class Initialized
DEBUG - 2018-06-16 02:00:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 02:00:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 02:00:37 --> Model Class Initialized
INFO - 2018-06-16 02:00:37 --> Model Class Initialized
INFO - 2018-06-16 02:00:37 --> Model Class Initialized
INFO - 2018-06-16 02:00:37 --> Model Class Initialized
INFO - 2018-06-16 02:00:37 --> Model Class Initialized
INFO - 2018-06-16 02:00:37 --> Model Class Initialized
INFO - 2018-06-16 02:00:37 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-16 02:00:37 --> Model Class Initialized
INFO - 2018-06-16 02:00:37 --> Model Class Initialized
INFO - 2018-06-16 02:00:37 --> Model Class Initialized
INFO - 2018-06-16 02:00:37 --> Helper loaded: inflector_helper
ERROR - 2018-06-16 02:00:37 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 796
DEBUG - 2018-06-16 02:00:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 02:00:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 02:00:37 --> Model Class Initialized
INFO - 2018-06-16 02:00:37 --> Model Class Initialized
INFO - 2018-06-16 02:00:37 --> Model Class Initialized
INFO - 2018-06-16 02:00:37 --> Model Class Initialized
INFO - 2018-06-16 02:00:37 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-16 02:00:37 --> Model Class Initialized
INFO - 2018-06-16 02:00:37 --> Final output sent to browser
DEBUG - 2018-06-16 02:00:37 --> Total execution time: 0.1199
INFO - 2018-06-16 02:00:37 --> Final output sent to browser
DEBUG - 2018-06-16 02:00:37 --> Total execution time: 0.0941
INFO - 2018-06-16 02:00:39 --> Helper loaded: url_helper
INFO - 2018-06-16 02:00:39 --> Helper loaded: notification_helper
INFO - 2018-06-16 02:00:39 --> Helper loaded: settings_helper
INFO - 2018-06-16 02:00:39 --> Helper loaded: permission_helper
INFO - 2018-06-16 02:00:39 --> Helper loaded: users_helper
INFO - 2018-06-16 02:00:39 --> Database Driver Class Initialized
DEBUG - 2018-06-16 02:00:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 02:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 02:00:39 --> Helper loaded: form_helper
INFO - 2018-06-16 02:00:39 --> Form Validation Class Initialized
INFO - 2018-06-16 02:00:39 --> Controller Class Initialized
INFO - 2018-06-16 02:00:39 --> Model Class Initialized
INFO - 2018-06-16 02:00:39 --> Helper loaded: inflector_helper
DEBUG - 2018-06-16 02:00:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 02:00:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 02:00:40 --> Model Class Initialized
INFO - 2018-06-16 02:00:40 --> Model Class Initialized
INFO - 2018-06-16 02:00:40 --> Model Class Initialized
INFO - 2018-06-16 02:00:40 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-16 02:00:40 --> Model Class Initialized
INFO - 2018-06-16 02:00:40 --> Final output sent to browser
DEBUG - 2018-06-16 02:00:40 --> Total execution time: 0.1071
INFO - 2018-06-16 02:00:50 --> Helper loaded: url_helper
INFO - 2018-06-16 02:00:50 --> Helper loaded: notification_helper
INFO - 2018-06-16 02:00:50 --> Helper loaded: settings_helper
INFO - 2018-06-16 02:00:50 --> Helper loaded: permission_helper
INFO - 2018-06-16 02:00:50 --> Helper loaded: users_helper
INFO - 2018-06-16 02:00:50 --> Database Driver Class Initialized
DEBUG - 2018-06-16 02:00:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 02:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 02:00:50 --> Helper loaded: form_helper
INFO - 2018-06-16 02:00:50 --> Form Validation Class Initialized
INFO - 2018-06-16 02:00:50 --> Controller Class Initialized
INFO - 2018-06-16 02:00:50 --> Model Class Initialized
INFO - 2018-06-16 02:00:50 --> Helper loaded: inflector_helper
DEBUG - 2018-06-16 02:00:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 02:00:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 02:00:50 --> Model Class Initialized
INFO - 2018-06-16 02:00:50 --> Model Class Initialized
INFO - 2018-06-16 02:00:50 --> Model Class Initialized
INFO - 2018-06-16 02:00:50 --> Model Class Initialized
INFO - 2018-06-16 02:00:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-16 02:00:50 --> Model Class Initialized
INFO - 2018-06-16 02:00:50 --> Final output sent to browser
DEBUG - 2018-06-16 02:00:50 --> Total execution time: 0.1046
INFO - 2018-06-16 02:00:50 --> Helper loaded: url_helper
INFO - 2018-06-16 02:00:50 --> Helper loaded: notification_helper
INFO - 2018-06-16 02:00:50 --> Helper loaded: settings_helper
INFO - 2018-06-16 02:00:50 --> Helper loaded: permission_helper
INFO - 2018-06-16 02:00:50 --> Helper loaded: users_helper
INFO - 2018-06-16 02:00:50 --> Database Driver Class Initialized
DEBUG - 2018-06-16 02:00:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 02:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 02:00:50 --> Helper loaded: form_helper
INFO - 2018-06-16 02:00:50 --> Form Validation Class Initialized
INFO - 2018-06-16 02:00:50 --> Controller Class Initialized
INFO - 2018-06-16 02:00:50 --> Model Class Initialized
INFO - 2018-06-16 02:00:50 --> Helper loaded: inflector_helper
DEBUG - 2018-06-16 02:00:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 02:00:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 02:00:50 --> Model Class Initialized
INFO - 2018-06-16 02:00:50 --> Model Class Initialized
INFO - 2018-06-16 02:00:50 --> Model Class Initialized
INFO - 2018-06-16 02:00:50 --> Model Class Initialized
INFO - 2018-06-16 02:00:50 --> Model Class Initialized
INFO - 2018-06-16 02:00:50 --> Model Class Initialized
INFO - 2018-06-16 02:00:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-16 02:00:50 --> Model Class Initialized
INFO - 2018-06-16 02:00:50 --> Model Class Initialized
ERROR - 2018-06-16 02:00:50 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 796
INFO - 2018-06-16 02:00:50 --> Final output sent to browser
DEBUG - 2018-06-16 02:00:50 --> Total execution time: 0.1374
INFO - 2018-06-16 02:00:52 --> Helper loaded: url_helper
INFO - 2018-06-16 02:00:52 --> Helper loaded: notification_helper
INFO - 2018-06-16 02:00:52 --> Helper loaded: settings_helper
INFO - 2018-06-16 02:00:52 --> Helper loaded: permission_helper
INFO - 2018-06-16 02:00:52 --> Helper loaded: users_helper
INFO - 2018-06-16 02:00:52 --> Database Driver Class Initialized
DEBUG - 2018-06-16 02:00:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 02:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 02:00:52 --> Helper loaded: form_helper
INFO - 2018-06-16 02:00:52 --> Form Validation Class Initialized
INFO - 2018-06-16 02:00:52 --> Controller Class Initialized
INFO - 2018-06-16 02:00:52 --> Model Class Initialized
INFO - 2018-06-16 02:00:52 --> Helper loaded: inflector_helper
DEBUG - 2018-06-16 02:00:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 02:00:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 02:00:52 --> Model Class Initialized
INFO - 2018-06-16 02:00:52 --> Model Class Initialized
INFO - 2018-06-16 02:00:52 --> Model Class Initialized
INFO - 2018-06-16 02:00:52 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-16 02:00:52 --> Model Class Initialized
INFO - 2018-06-16 02:00:52 --> Final output sent to browser
DEBUG - 2018-06-16 02:00:52 --> Total execution time: 0.1244
INFO - 2018-06-16 02:00:59 --> Helper loaded: url_helper
INFO - 2018-06-16 02:00:59 --> Helper loaded: notification_helper
INFO - 2018-06-16 02:00:59 --> Helper loaded: settings_helper
INFO - 2018-06-16 02:00:59 --> Helper loaded: permission_helper
INFO - 2018-06-16 02:00:59 --> Helper loaded: users_helper
INFO - 2018-06-16 02:00:59 --> Database Driver Class Initialized
DEBUG - 2018-06-16 02:00:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 02:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 02:00:59 --> Helper loaded: form_helper
INFO - 2018-06-16 02:00:59 --> Form Validation Class Initialized
INFO - 2018-06-16 02:00:59 --> Controller Class Initialized
INFO - 2018-06-16 02:00:59 --> Helper loaded: url_helper
INFO - 2018-06-16 02:00:59 --> Helper loaded: notification_helper
INFO - 2018-06-16 02:00:59 --> Helper loaded: settings_helper
INFO - 2018-06-16 02:00:59 --> Helper loaded: permission_helper
INFO - 2018-06-16 02:00:59 --> Helper loaded: users_helper
INFO - 2018-06-16 02:00:59 --> Database Driver Class Initialized
INFO - 2018-06-16 02:00:59 --> Model Class Initialized
DEBUG - 2018-06-16 02:00:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 02:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 02:00:59 --> Helper loaded: inflector_helper
INFO - 2018-06-16 02:00:59 --> Helper loaded: form_helper
INFO - 2018-06-16 02:00:59 --> Form Validation Class Initialized
INFO - 2018-06-16 02:00:59 --> Controller Class Initialized
DEBUG - 2018-06-16 02:00:59 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 02:00:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 02:00:59 --> Model Class Initialized
INFO - 2018-06-16 02:00:59 --> Model Class Initialized
INFO - 2018-06-16 02:00:59 --> Model Class Initialized
INFO - 2018-06-16 02:00:59 --> Helper loaded: inflector_helper
INFO - 2018-06-16 02:00:59 --> Model Class Initialized
INFO - 2018-06-16 02:00:59 --> Model Class Initialized
INFO - 2018-06-16 02:00:59 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-16 02:00:59 --> Model Class Initialized
DEBUG - 2018-06-16 02:00:59 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 02:00:59 --> Final output sent to browser
DEBUG - 2018-06-16 02:00:59 --> Total execution time: 0.1821
INFO - 2018-06-16 02:00:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 02:00:59 --> Model Class Initialized
INFO - 2018-06-16 02:00:59 --> Model Class Initialized
INFO - 2018-06-16 02:00:59 --> Model Class Initialized
INFO - 2018-06-16 02:00:59 --> Model Class Initialized
INFO - 2018-06-16 02:00:59 --> Model Class Initialized
INFO - 2018-06-16 02:00:59 --> Model Class Initialized
INFO - 2018-06-16 02:00:59 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-16 02:00:59 --> Model Class Initialized
INFO - 2018-06-16 02:00:59 --> Model Class Initialized
ERROR - 2018-06-16 02:00:59 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 796
INFO - 2018-06-16 02:00:59 --> Final output sent to browser
DEBUG - 2018-06-16 02:00:59 --> Total execution time: 0.1218
INFO - 2018-06-16 02:01:09 --> Helper loaded: url_helper
INFO - 2018-06-16 02:01:09 --> Helper loaded: notification_helper
INFO - 2018-06-16 02:01:09 --> Helper loaded: settings_helper
INFO - 2018-06-16 02:01:09 --> Helper loaded: permission_helper
INFO - 2018-06-16 02:01:09 --> Helper loaded: users_helper
INFO - 2018-06-16 02:01:09 --> Database Driver Class Initialized
DEBUG - 2018-06-16 02:01:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 02:01:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 02:01:09 --> Helper loaded: form_helper
INFO - 2018-06-16 02:01:09 --> Form Validation Class Initialized
INFO - 2018-06-16 02:01:09 --> Controller Class Initialized
INFO - 2018-06-16 02:01:09 --> Model Class Initialized
INFO - 2018-06-16 02:01:09 --> Helper loaded: inflector_helper
DEBUG - 2018-06-16 02:01:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 02:01:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 02:01:09 --> Model Class Initialized
INFO - 2018-06-16 02:01:09 --> Model Class Initialized
INFO - 2018-06-16 02:01:09 --> Model Class Initialized
INFO - 2018-06-16 02:01:09 --> Model Class Initialized
INFO - 2018-06-16 02:01:09 --> Model Class Initialized
INFO - 2018-06-16 02:01:09 --> Model Class Initialized
INFO - 2018-06-16 02:01:09 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-16 02:01:09 --> Model Class Initialized
INFO - 2018-06-16 02:01:09 --> Model Class Initialized
INFO - 2018-06-16 02:01:09 --> Final output sent to browser
DEBUG - 2018-06-16 02:01:09 --> Total execution time: 0.1446
INFO - 2018-06-16 02:01:10 --> Helper loaded: url_helper
INFO - 2018-06-16 02:01:10 --> Helper loaded: notification_helper
INFO - 2018-06-16 02:01:10 --> Helper loaded: settings_helper
INFO - 2018-06-16 02:01:10 --> Helper loaded: permission_helper
INFO - 2018-06-16 02:01:10 --> Helper loaded: users_helper
INFO - 2018-06-16 02:01:10 --> Database Driver Class Initialized
DEBUG - 2018-06-16 02:01:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 02:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 02:01:10 --> Helper loaded: form_helper
INFO - 2018-06-16 02:01:10 --> Form Validation Class Initialized
INFO - 2018-06-16 02:01:10 --> Controller Class Initialized
INFO - 2018-06-16 02:01:10 --> Model Class Initialized
INFO - 2018-06-16 02:01:10 --> Helper loaded: inflector_helper
DEBUG - 2018-06-16 02:01:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 02:01:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 02:01:10 --> Model Class Initialized
INFO - 2018-06-16 02:01:10 --> Model Class Initialized
INFO - 2018-06-16 02:01:10 --> Model Class Initialized
INFO - 2018-06-16 02:01:10 --> Model Class Initialized
INFO - 2018-06-16 02:01:10 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-16 02:01:10 --> Model Class Initialized
INFO - 2018-06-16 02:01:10 --> Final output sent to browser
DEBUG - 2018-06-16 02:01:10 --> Total execution time: 0.1037
INFO - 2018-06-16 02:01:10 --> Helper loaded: url_helper
INFO - 2018-06-16 02:01:10 --> Helper loaded: notification_helper
INFO - 2018-06-16 02:01:10 --> Helper loaded: settings_helper
INFO - 2018-06-16 02:01:10 --> Helper loaded: permission_helper
INFO - 2018-06-16 02:01:10 --> Helper loaded: users_helper
INFO - 2018-06-16 02:01:11 --> Database Driver Class Initialized
DEBUG - 2018-06-16 02:01:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 02:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 02:01:11 --> Helper loaded: form_helper
INFO - 2018-06-16 02:01:11 --> Form Validation Class Initialized
INFO - 2018-06-16 02:01:11 --> Controller Class Initialized
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Helper loaded: inflector_helper
DEBUG - 2018-06-16 02:01:11 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 02:01:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-16 02:01:11 --> Final output sent to browser
DEBUG - 2018-06-16 02:01:11 --> Total execution time: 0.1446
INFO - 2018-06-16 02:01:11 --> Helper loaded: url_helper
INFO - 2018-06-16 02:01:11 --> Helper loaded: notification_helper
INFO - 2018-06-16 02:01:11 --> Helper loaded: settings_helper
INFO - 2018-06-16 02:01:11 --> Helper loaded: permission_helper
INFO - 2018-06-16 02:01:11 --> Helper loaded: users_helper
INFO - 2018-06-16 02:01:11 --> Helper loaded: url_helper
INFO - 2018-06-16 02:01:11 --> Helper loaded: notification_helper
INFO - 2018-06-16 02:01:11 --> Helper loaded: settings_helper
INFO - 2018-06-16 02:01:11 --> Helper loaded: permission_helper
INFO - 2018-06-16 02:01:11 --> Helper loaded: users_helper
INFO - 2018-06-16 02:01:11 --> Database Driver Class Initialized
INFO - 2018-06-16 02:01:11 --> Database Driver Class Initialized
DEBUG - 2018-06-16 02:01:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 02:01:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-06-16 02:01:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 02:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 02:01:11 --> Helper loaded: form_helper
INFO - 2018-06-16 02:01:11 --> Form Validation Class Initialized
INFO - 2018-06-16 02:01:11 --> Controller Class Initialized
INFO - 2018-06-16 02:01:11 --> Helper loaded: form_helper
INFO - 2018-06-16 02:01:11 --> Form Validation Class Initialized
INFO - 2018-06-16 02:01:11 --> Controller Class Initialized
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Helper loaded: inflector_helper
DEBUG - 2018-06-16 02:01:11 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 02:01:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Helper loaded: inflector_helper
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
DEBUG - 2018-06-16 02:01:11 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 02:01:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 02:01:11 --> Final output sent to browser
DEBUG - 2018-06-16 02:01:11 --> Total execution time: 0.1303
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Final output sent to browser
DEBUG - 2018-06-16 02:01:11 --> Total execution time: 0.1081
INFO - 2018-06-16 02:01:11 --> Helper loaded: url_helper
INFO - 2018-06-16 02:01:11 --> Helper loaded: notification_helper
INFO - 2018-06-16 02:01:11 --> Helper loaded: settings_helper
INFO - 2018-06-16 02:01:11 --> Helper loaded: permission_helper
INFO - 2018-06-16 02:01:11 --> Helper loaded: users_helper
INFO - 2018-06-16 02:01:11 --> Helper loaded: url_helper
INFO - 2018-06-16 02:01:11 --> Helper loaded: notification_helper
INFO - 2018-06-16 02:01:11 --> Helper loaded: settings_helper
INFO - 2018-06-16 02:01:11 --> Helper loaded: permission_helper
INFO - 2018-06-16 02:01:11 --> Helper loaded: users_helper
INFO - 2018-06-16 02:01:11 --> Database Driver Class Initialized
DEBUG - 2018-06-16 02:01:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 02:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 02:01:11 --> Helper loaded: url_helper
INFO - 2018-06-16 02:01:11 --> Helper loaded: form_helper
INFO - 2018-06-16 02:01:11 --> Form Validation Class Initialized
INFO - 2018-06-16 02:01:11 --> Controller Class Initialized
INFO - 2018-06-16 02:01:11 --> Helper loaded: notification_helper
INFO - 2018-06-16 02:01:11 --> Helper loaded: settings_helper
INFO - 2018-06-16 02:01:11 --> Database Driver Class Initialized
INFO - 2018-06-16 02:01:11 --> Helper loaded: permission_helper
INFO - 2018-06-16 02:01:11 --> Helper loaded: users_helper
DEBUG - 2018-06-16 02:01:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 02:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Helper loaded: inflector_helper
INFO - 2018-06-16 02:01:11 --> Helper loaded: url_helper
INFO - 2018-06-16 02:01:11 --> Helper loaded: notification_helper
INFO - 2018-06-16 02:01:11 --> Helper loaded: settings_helper
DEBUG - 2018-06-16 02:01:11 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 02:01:11 --> Helper loaded: form_helper
INFO - 2018-06-16 02:01:11 --> Form Validation Class Initialized
INFO - 2018-06-16 02:01:11 --> Controller Class Initialized
INFO - 2018-06-16 02:01:11 --> Helper loaded: permission_helper
INFO - 2018-06-16 02:01:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 02:01:11 --> Helper loaded: users_helper
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Database Driver Class Initialized
INFO - 2018-06-16 02:01:11 --> Helper loaded: inflector_helper
INFO - 2018-06-16 02:01:11 --> Final output sent to browser
DEBUG - 2018-06-16 02:01:11 --> Total execution time: 0.1728
INFO - 2018-06-16 02:01:11 --> Helper loaded: url_helper
INFO - 2018-06-16 02:01:11 --> Helper loaded: notification_helper
INFO - 2018-06-16 02:01:11 --> Helper loaded: settings_helper
DEBUG - 2018-06-16 02:01:11 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 02:01:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 02:01:11 --> Helper loaded: permission_helper
INFO - 2018-06-16 02:01:11 --> Database Driver Class Initialized
DEBUG - 2018-06-16 02:01:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Helper loaded: users_helper
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-06-16 02:01:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 02:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Final output sent to browser
DEBUG - 2018-06-16 02:01:11 --> Total execution time: 0.2390
INFO - 2018-06-16 02:01:11 --> Helper loaded: form_helper
INFO - 2018-06-16 02:01:11 --> Form Validation Class Initialized
INFO - 2018-06-16 02:01:11 --> Controller Class Initialized
INFO - 2018-06-16 02:01:11 --> Helper loaded: form_helper
INFO - 2018-06-16 02:01:11 --> Form Validation Class Initialized
INFO - 2018-06-16 02:01:11 --> Controller Class Initialized
INFO - 2018-06-16 02:01:11 --> Database Driver Class Initialized
INFO - 2018-06-16 02:01:11 --> Helper loaded: url_helper
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Helper loaded: notification_helper
INFO - 2018-06-16 02:01:11 --> Helper loaded: inflector_helper
INFO - 2018-06-16 02:01:11 --> Helper loaded: settings_helper
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Helper loaded: permission_helper
DEBUG - 2018-06-16 02:01:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 02:01:11 --> Helper loaded: inflector_helper
INFO - 2018-06-16 02:01:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-06-16 02:01:11 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 02:01:11 --> Helper loaded: users_helper
DEBUG - 2018-06-16 02:01:11 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 02:01:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Helper loaded: form_helper
INFO - 2018-06-16 02:01:11 --> Form Validation Class Initialized
INFO - 2018-06-16 02:01:11 --> Controller Class Initialized
INFO - 2018-06-16 02:01:11 --> Helper loaded: url_helper
INFO - 2018-06-16 02:01:11 --> Helper loaded: notification_helper
INFO - 2018-06-16 02:01:11 --> Helper loaded: settings_helper
INFO - 2018-06-16 02:01:11 --> Helper loaded: permission_helper
INFO - 2018-06-16 02:01:11 --> Final output sent to browser
DEBUG - 2018-06-16 02:01:11 --> Total execution time: 0.2123
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Helper loaded: users_helper
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Database Driver Class Initialized
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Helper loaded: inflector_helper
DEBUG - 2018-06-16 02:01:11 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 02:01:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
DEBUG - 2018-06-16 02:01:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 02:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 02:01:11 --> Final output sent to browser
DEBUG - 2018-06-16 02:01:11 --> Total execution time: 0.1799
INFO - 2018-06-16 02:01:11 --> Helper loaded: form_helper
INFO - 2018-06-16 02:01:11 --> Form Validation Class Initialized
INFO - 2018-06-16 02:01:11 --> Controller Class Initialized
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Helper loaded: inflector_helper
INFO - 2018-06-16 02:01:11 --> Database Driver Class Initialized
INFO - 2018-06-16 02:01:11 --> Final output sent to browser
DEBUG - 2018-06-16 02:01:11 --> Total execution time: 0.2675
DEBUG - 2018-06-16 02:01:11 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 02:01:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
DEBUG - 2018-06-16 02:01:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 02:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Helper loaded: form_helper
INFO - 2018-06-16 02:01:11 --> Form Validation Class Initialized
INFO - 2018-06-16 02:01:11 --> Controller Class Initialized
INFO - 2018-06-16 02:01:11 --> Final output sent to browser
DEBUG - 2018-06-16 02:01:11 --> Total execution time: 0.2577
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Helper loaded: inflector_helper
DEBUG - 2018-06-16 02:01:11 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 02:01:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Final output sent to browser
DEBUG - 2018-06-16 02:01:11 --> Total execution time: 0.3819
INFO - 2018-06-16 02:01:11 --> Helper loaded: url_helper
INFO - 2018-06-16 02:01:11 --> Helper loaded: notification_helper
INFO - 2018-06-16 02:01:11 --> Helper loaded: settings_helper
INFO - 2018-06-16 02:01:11 --> Helper loaded: permission_helper
INFO - 2018-06-16 02:01:11 --> Helper loaded: users_helper
INFO - 2018-06-16 02:01:11 --> Database Driver Class Initialized
DEBUG - 2018-06-16 02:01:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 02:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 02:01:11 --> Helper loaded: form_helper
INFO - 2018-06-16 02:01:11 --> Form Validation Class Initialized
INFO - 2018-06-16 02:01:11 --> Controller Class Initialized
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Helper loaded: inflector_helper
DEBUG - 2018-06-16 02:01:11 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 02:01:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Model Class Initialized
INFO - 2018-06-16 02:01:11 --> Final output sent to browser
DEBUG - 2018-06-16 02:01:11 --> Total execution time: 0.1595
INFO - 2018-06-16 02:01:13 --> Helper loaded: url_helper
INFO - 2018-06-16 02:01:13 --> Helper loaded: notification_helper
INFO - 2018-06-16 02:01:13 --> Helper loaded: settings_helper
INFO - 2018-06-16 02:01:13 --> Helper loaded: permission_helper
INFO - 2018-06-16 02:01:13 --> Helper loaded: users_helper
INFO - 2018-06-16 02:01:13 --> Database Driver Class Initialized
DEBUG - 2018-06-16 02:01:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 02:01:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 02:01:13 --> Helper loaded: form_helper
INFO - 2018-06-16 02:01:13 --> Form Validation Class Initialized
INFO - 2018-06-16 02:01:13 --> Controller Class Initialized
INFO - 2018-06-16 02:01:13 --> Model Class Initialized
INFO - 2018-06-16 02:01:13 --> Helper loaded: inflector_helper
DEBUG - 2018-06-16 02:01:13 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 02:01:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 02:01:13 --> Model Class Initialized
INFO - 2018-06-16 02:01:13 --> Model Class Initialized
INFO - 2018-06-16 02:01:13 --> Model Class Initialized
INFO - 2018-06-16 02:01:13 --> Model Class Initialized
INFO - 2018-06-16 02:01:13 --> Model Class Initialized
INFO - 2018-06-16 02:01:13 --> Model Class Initialized
INFO - 2018-06-16 02:01:13 --> Model Class Initialized
INFO - 2018-06-16 02:01:13 --> Model Class Initialized
INFO - 2018-06-16 02:01:13 --> Model Class Initialized
INFO - 2018-06-16 02:01:13 --> Model Class Initialized
INFO - 2018-06-16 02:01:13 --> Model Class Initialized
INFO - 2018-06-16 02:01:13 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-16 02:01:13 --> Model Class Initialized
INFO - 2018-06-16 02:01:13 --> Final output sent to browser
DEBUG - 2018-06-16 02:01:13 --> Total execution time: 0.1367
INFO - 2018-06-16 02:01:13 --> Helper loaded: url_helper
INFO - 2018-06-16 02:01:13 --> Helper loaded: notification_helper
INFO - 2018-06-16 02:01:13 --> Helper loaded: settings_helper
INFO - 2018-06-16 02:01:13 --> Helper loaded: permission_helper
INFO - 2018-06-16 02:01:13 --> Helper loaded: users_helper
INFO - 2018-06-16 02:01:13 --> Database Driver Class Initialized
DEBUG - 2018-06-16 02:01:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 02:01:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 02:01:13 --> Helper loaded: form_helper
INFO - 2018-06-16 02:01:13 --> Form Validation Class Initialized
INFO - 2018-06-16 02:01:13 --> Controller Class Initialized
INFO - 2018-06-16 02:01:13 --> Model Class Initialized
INFO - 2018-06-16 02:01:13 --> Helper loaded: inflector_helper
DEBUG - 2018-06-16 02:01:13 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 02:01:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 02:01:13 --> Model Class Initialized
INFO - 2018-06-16 02:01:13 --> Model Class Initialized
INFO - 2018-06-16 02:01:13 --> Model Class Initialized
INFO - 2018-06-16 02:01:13 --> Model Class Initialized
INFO - 2018-06-16 02:01:13 --> Model Class Initialized
INFO - 2018-06-16 02:01:13 --> Model Class Initialized
INFO - 2018-06-16 02:01:13 --> Model Class Initialized
INFO - 2018-06-16 02:01:13 --> Model Class Initialized
INFO - 2018-06-16 02:01:13 --> Model Class Initialized
INFO - 2018-06-16 02:01:13 --> Model Class Initialized
INFO - 2018-06-16 02:01:13 --> Model Class Initialized
INFO - 2018-06-16 02:01:13 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-16 02:01:13 --> Model Class Initialized
INFO - 2018-06-16 02:01:13 --> Final output sent to browser
DEBUG - 2018-06-16 02:01:13 --> Total execution time: 0.1383
INFO - 2018-06-16 02:01:15 --> Helper loaded: url_helper
INFO - 2018-06-16 02:01:15 --> Helper loaded: notification_helper
INFO - 2018-06-16 02:01:15 --> Helper loaded: settings_helper
INFO - 2018-06-16 02:01:15 --> Helper loaded: permission_helper
INFO - 2018-06-16 02:01:15 --> Helper loaded: users_helper
INFO - 2018-06-16 02:01:15 --> Database Driver Class Initialized
DEBUG - 2018-06-16 02:01:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 02:01:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 02:01:15 --> Helper loaded: form_helper
INFO - 2018-06-16 02:01:15 --> Form Validation Class Initialized
INFO - 2018-06-16 02:01:15 --> Controller Class Initialized
INFO - 2018-06-16 02:01:15 --> Model Class Initialized
INFO - 2018-06-16 02:01:15 --> Helper loaded: inflector_helper
DEBUG - 2018-06-16 02:01:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 02:01:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 02:01:15 --> Model Class Initialized
INFO - 2018-06-16 02:01:15 --> Model Class Initialized
INFO - 2018-06-16 02:01:15 --> Model Class Initialized
INFO - 2018-06-16 02:01:15 --> Model Class Initialized
INFO - 2018-06-16 02:01:15 --> Model Class Initialized
INFO - 2018-06-16 02:01:15 --> Model Class Initialized
INFO - 2018-06-16 02:01:15 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-16 02:01:15 --> Model Class Initialized
INFO - 2018-06-16 02:01:15 --> Model Class Initialized
ERROR - 2018-06-16 02:01:15 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 796
INFO - 2018-06-16 02:01:15 --> Final output sent to browser
DEBUG - 2018-06-16 02:01:15 --> Total execution time: 0.1464
INFO - 2018-06-16 02:01:21 --> Helper loaded: url_helper
INFO - 2018-06-16 02:01:21 --> Helper loaded: notification_helper
INFO - 2018-06-16 02:01:21 --> Helper loaded: settings_helper
INFO - 2018-06-16 02:01:21 --> Helper loaded: permission_helper
INFO - 2018-06-16 02:01:21 --> Helper loaded: users_helper
INFO - 2018-06-16 02:01:21 --> Database Driver Class Initialized
DEBUG - 2018-06-16 02:01:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 02:01:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 02:01:21 --> Helper loaded: form_helper
INFO - 2018-06-16 02:01:21 --> Form Validation Class Initialized
INFO - 2018-06-16 02:01:21 --> Controller Class Initialized
INFO - 2018-06-16 02:01:21 --> Model Class Initialized
INFO - 2018-06-16 02:01:21 --> Helper loaded: inflector_helper
DEBUG - 2018-06-16 02:01:21 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 02:01:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 02:01:21 --> Model Class Initialized
INFO - 2018-06-16 02:01:21 --> Model Class Initialized
INFO - 2018-06-16 02:01:21 --> Model Class Initialized
INFO - 2018-06-16 02:01:21 --> Model Class Initialized
INFO - 2018-06-16 02:01:21 --> Model Class Initialized
INFO - 2018-06-16 02:01:21 --> Model Class Initialized
INFO - 2018-06-16 02:01:21 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-16 02:01:21 --> Model Class Initialized
INFO - 2018-06-16 02:01:21 --> Model Class Initialized
INFO - 2018-06-16 02:01:21 --> Model Class Initialized
INFO - 2018-06-16 02:01:21 --> Final output sent to browser
DEBUG - 2018-06-16 02:01:21 --> Total execution time: 0.3489
INFO - 2018-06-16 02:01:21 --> Helper loaded: url_helper
INFO - 2018-06-16 02:01:21 --> Helper loaded: notification_helper
INFO - 2018-06-16 02:01:21 --> Helper loaded: settings_helper
INFO - 2018-06-16 02:01:21 --> Helper loaded: permission_helper
INFO - 2018-06-16 02:01:21 --> Helper loaded: users_helper
INFO - 2018-06-16 02:01:22 --> Database Driver Class Initialized
DEBUG - 2018-06-16 02:01:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 02:01:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 02:01:22 --> Helper loaded: form_helper
INFO - 2018-06-16 02:01:22 --> Form Validation Class Initialized
INFO - 2018-06-16 02:01:22 --> Controller Class Initialized
INFO - 2018-06-16 02:01:22 --> Model Class Initialized
INFO - 2018-06-16 02:01:22 --> Helper loaded: inflector_helper
DEBUG - 2018-06-16 02:01:22 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 02:01:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 02:01:22 --> Model Class Initialized
INFO - 2018-06-16 02:01:22 --> Model Class Initialized
INFO - 2018-06-16 02:01:22 --> Model Class Initialized
INFO - 2018-06-16 02:01:22 --> Model Class Initialized
INFO - 2018-06-16 02:01:22 --> Model Class Initialized
INFO - 2018-06-16 02:01:22 --> Model Class Initialized
INFO - 2018-06-16 02:01:22 --> Model Class Initialized
INFO - 2018-06-16 02:01:22 --> Model Class Initialized
INFO - 2018-06-16 02:01:22 --> Model Class Initialized
INFO - 2018-06-16 02:01:22 --> Model Class Initialized
INFO - 2018-06-16 02:01:22 --> Model Class Initialized
INFO - 2018-06-16 02:01:22 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-16 02:01:22 --> Model Class Initialized
INFO - 2018-06-16 02:01:22 --> Final output sent to browser
DEBUG - 2018-06-16 02:01:22 --> Total execution time: 0.1309
INFO - 2018-06-16 02:01:22 --> Helper loaded: url_helper
INFO - 2018-06-16 02:01:22 --> Helper loaded: notification_helper
INFO - 2018-06-16 02:01:22 --> Helper loaded: settings_helper
INFO - 2018-06-16 02:01:22 --> Helper loaded: permission_helper
INFO - 2018-06-16 02:01:22 --> Helper loaded: users_helper
INFO - 2018-06-16 02:01:22 --> Database Driver Class Initialized
DEBUG - 2018-06-16 02:01:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 02:01:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 02:01:22 --> Helper loaded: form_helper
INFO - 2018-06-16 02:01:22 --> Form Validation Class Initialized
INFO - 2018-06-16 02:01:22 --> Controller Class Initialized
INFO - 2018-06-16 02:01:22 --> Model Class Initialized
INFO - 2018-06-16 02:01:22 --> Helper loaded: inflector_helper
DEBUG - 2018-06-16 02:01:22 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 02:01:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 02:01:22 --> Model Class Initialized
INFO - 2018-06-16 02:01:22 --> Model Class Initialized
INFO - 2018-06-16 02:01:22 --> Model Class Initialized
INFO - 2018-06-16 02:01:22 --> Model Class Initialized
INFO - 2018-06-16 02:01:22 --> Model Class Initialized
INFO - 2018-06-16 02:01:22 --> Model Class Initialized
INFO - 2018-06-16 02:01:22 --> Model Class Initialized
INFO - 2018-06-16 02:01:22 --> Model Class Initialized
INFO - 2018-06-16 02:01:22 --> Model Class Initialized
INFO - 2018-06-16 02:01:22 --> Model Class Initialized
INFO - 2018-06-16 02:01:22 --> Model Class Initialized
INFO - 2018-06-16 02:01:22 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-16 02:01:22 --> Model Class Initialized
INFO - 2018-06-16 02:01:22 --> Final output sent to browser
DEBUG - 2018-06-16 02:01:22 --> Total execution time: 0.1499
INFO - 2018-06-16 02:01:26 --> Helper loaded: url_helper
INFO - 2018-06-16 02:01:26 --> Helper loaded: notification_helper
INFO - 2018-06-16 02:01:26 --> Helper loaded: settings_helper
INFO - 2018-06-16 02:01:26 --> Helper loaded: permission_helper
INFO - 2018-06-16 02:01:26 --> Helper loaded: users_helper
INFO - 2018-06-16 02:01:26 --> Database Driver Class Initialized
DEBUG - 2018-06-16 02:01:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 02:01:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 02:01:26 --> Helper loaded: form_helper
INFO - 2018-06-16 02:01:26 --> Form Validation Class Initialized
INFO - 2018-06-16 02:01:26 --> Controller Class Initialized
INFO - 2018-06-16 02:01:26 --> Model Class Initialized
INFO - 2018-06-16 02:01:26 --> Helper loaded: inflector_helper
DEBUG - 2018-06-16 02:01:26 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 02:01:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 02:01:26 --> Model Class Initialized
INFO - 2018-06-16 02:01:26 --> Model Class Initialized
INFO - 2018-06-16 02:01:26 --> Model Class Initialized
INFO - 2018-06-16 02:01:26 --> Model Class Initialized
INFO - 2018-06-16 02:01:26 --> Final output sent to browser
DEBUG - 2018-06-16 02:01:26 --> Total execution time: 0.1048
INFO - 2018-06-16 02:01:26 --> Helper loaded: url_helper
INFO - 2018-06-16 02:01:26 --> Helper loaded: notification_helper
INFO - 2018-06-16 02:01:26 --> Helper loaded: settings_helper
INFO - 2018-06-16 02:01:26 --> Helper loaded: permission_helper
INFO - 2018-06-16 02:01:26 --> Helper loaded: users_helper
INFO - 2018-06-16 02:01:26 --> Database Driver Class Initialized
DEBUG - 2018-06-16 02:01:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 02:01:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 02:01:26 --> Helper loaded: form_helper
INFO - 2018-06-16 02:01:26 --> Form Validation Class Initialized
INFO - 2018-06-16 02:01:26 --> Controller Class Initialized
INFO - 2018-06-16 02:01:26 --> Model Class Initialized
INFO - 2018-06-16 02:01:26 --> Helper loaded: inflector_helper
DEBUG - 2018-06-16 02:01:26 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 02:01:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 02:01:26 --> Model Class Initialized
INFO - 2018-06-16 02:01:26 --> Model Class Initialized
INFO - 2018-06-16 02:01:26 --> Model Class Initialized
INFO - 2018-06-16 02:01:26 --> Model Class Initialized
INFO - 2018-06-16 02:01:26 --> Final output sent to browser
DEBUG - 2018-06-16 02:01:26 --> Total execution time: 0.1016
INFO - 2018-06-16 02:01:29 --> Helper loaded: url_helper
INFO - 2018-06-16 02:01:29 --> Helper loaded: notification_helper
INFO - 2018-06-16 02:01:29 --> Helper loaded: settings_helper
INFO - 2018-06-16 02:01:29 --> Helper loaded: permission_helper
INFO - 2018-06-16 02:01:29 --> Helper loaded: users_helper
INFO - 2018-06-16 02:01:29 --> Database Driver Class Initialized
DEBUG - 2018-06-16 02:01:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 02:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 02:01:29 --> Helper loaded: form_helper
INFO - 2018-06-16 02:01:29 --> Form Validation Class Initialized
INFO - 2018-06-16 02:01:29 --> Controller Class Initialized
INFO - 2018-06-16 02:01:29 --> Model Class Initialized
INFO - 2018-06-16 02:01:29 --> Helper loaded: inflector_helper
DEBUG - 2018-06-16 02:01:29 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 02:01:29 --> Helper loaded: url_helper
INFO - 2018-06-16 02:01:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 02:01:29 --> Helper loaded: notification_helper
INFO - 2018-06-16 02:01:29 --> Model Class Initialized
INFO - 2018-06-16 02:01:29 --> Helper loaded: settings_helper
INFO - 2018-06-16 02:01:29 --> Model Class Initialized
INFO - 2018-06-16 02:01:29 --> Helper loaded: permission_helper
INFO - 2018-06-16 02:01:29 --> Model Class Initialized
INFO - 2018-06-16 02:01:29 --> Model Class Initialized
INFO - 2018-06-16 02:01:29 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-16 02:01:29 --> Model Class Initialized
INFO - 2018-06-16 02:01:29 --> Helper loaded: users_helper
INFO - 2018-06-16 02:01:29 --> Final output sent to browser
DEBUG - 2018-06-16 02:01:29 --> Total execution time: 0.1024
INFO - 2018-06-16 02:01:29 --> Database Driver Class Initialized
DEBUG - 2018-06-16 02:01:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 02:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 02:01:29 --> Helper loaded: form_helper
INFO - 2018-06-16 02:01:29 --> Form Validation Class Initialized
INFO - 2018-06-16 02:01:29 --> Controller Class Initialized
INFO - 2018-06-16 02:01:29 --> Model Class Initialized
INFO - 2018-06-16 02:01:29 --> Helper loaded: inflector_helper
DEBUG - 2018-06-16 02:01:29 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 02:01:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 02:01:29 --> Model Class Initialized
INFO - 2018-06-16 02:01:29 --> Model Class Initialized
INFO - 2018-06-16 02:01:29 --> Model Class Initialized
INFO - 2018-06-16 02:01:29 --> Model Class Initialized
INFO - 2018-06-16 02:01:29 --> Model Class Initialized
INFO - 2018-06-16 02:01:29 --> Model Class Initialized
INFO - 2018-06-16 02:01:29 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-16 02:01:29 --> Model Class Initialized
INFO - 2018-06-16 02:01:29 --> Model Class Initialized
ERROR - 2018-06-16 02:01:29 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 796
INFO - 2018-06-16 02:01:29 --> Final output sent to browser
DEBUG - 2018-06-16 02:01:29 --> Total execution time: 0.1298
INFO - 2018-06-16 02:01:30 --> Helper loaded: url_helper
INFO - 2018-06-16 02:01:30 --> Helper loaded: notification_helper
INFO - 2018-06-16 02:01:30 --> Helper loaded: settings_helper
INFO - 2018-06-16 02:01:30 --> Helper loaded: permission_helper
INFO - 2018-06-16 02:01:30 --> Helper loaded: users_helper
INFO - 2018-06-16 02:01:30 --> Database Driver Class Initialized
DEBUG - 2018-06-16 02:01:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 02:01:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 02:01:30 --> Helper loaded: form_helper
INFO - 2018-06-16 02:01:30 --> Form Validation Class Initialized
INFO - 2018-06-16 02:01:30 --> Controller Class Initialized
INFO - 2018-06-16 02:01:30 --> Model Class Initialized
INFO - 2018-06-16 02:01:30 --> Helper loaded: inflector_helper
DEBUG - 2018-06-16 02:01:30 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 02:01:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 02:01:30 --> Model Class Initialized
INFO - 2018-06-16 02:01:30 --> Model Class Initialized
INFO - 2018-06-16 02:01:30 --> Model Class Initialized
INFO - 2018-06-16 02:01:30 --> Model Class Initialized
INFO - 2018-06-16 02:01:30 --> Model Class Initialized
INFO - 2018-06-16 02:01:30 --> Model Class Initialized
INFO - 2018-06-16 02:01:30 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-16 02:01:30 --> Model Class Initialized
INFO - 2018-06-16 02:01:30 --> Model Class Initialized
INFO - 2018-06-16 02:01:30 --> Final output sent to browser
DEBUG - 2018-06-16 02:01:30 --> Total execution time: 0.1337
INFO - 2018-06-16 02:01:31 --> Helper loaded: url_helper
INFO - 2018-06-16 02:01:31 --> Helper loaded: notification_helper
INFO - 2018-06-16 02:01:31 --> Helper loaded: settings_helper
INFO - 2018-06-16 02:01:31 --> Helper loaded: permission_helper
INFO - 2018-06-16 02:01:31 --> Helper loaded: users_helper
INFO - 2018-06-16 02:01:31 --> Database Driver Class Initialized
DEBUG - 2018-06-16 02:01:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 02:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 02:01:31 --> Helper loaded: form_helper
INFO - 2018-06-16 02:01:31 --> Form Validation Class Initialized
INFO - 2018-06-16 02:01:31 --> Controller Class Initialized
INFO - 2018-06-16 02:01:31 --> Helper loaded: url_helper
INFO - 2018-06-16 02:01:31 --> Helper loaded: notification_helper
INFO - 2018-06-16 02:01:31 --> Helper loaded: settings_helper
INFO - 2018-06-16 02:01:31 --> Helper loaded: permission_helper
INFO - 2018-06-16 02:01:31 --> Helper loaded: users_helper
INFO - 2018-06-16 02:01:31 --> Model Class Initialized
INFO - 2018-06-16 02:01:31 --> Helper loaded: inflector_helper
DEBUG - 2018-06-16 02:01:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 02:01:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 02:01:31 --> Model Class Initialized
INFO - 2018-06-16 02:01:31 --> Model Class Initialized
INFO - 2018-06-16 02:01:31 --> Model Class Initialized
INFO - 2018-06-16 02:01:31 --> Model Class Initialized
INFO - 2018-06-16 02:01:31 --> Final output sent to browser
DEBUG - 2018-06-16 02:01:31 --> Total execution time: 0.1186
INFO - 2018-06-16 02:01:31 --> Database Driver Class Initialized
DEBUG - 2018-06-16 02:01:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 02:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 02:01:31 --> Helper loaded: form_helper
INFO - 2018-06-16 02:01:31 --> Form Validation Class Initialized
INFO - 2018-06-16 02:01:31 --> Controller Class Initialized
INFO - 2018-06-16 02:01:31 --> Model Class Initialized
INFO - 2018-06-16 02:01:31 --> Helper loaded: inflector_helper
DEBUG - 2018-06-16 02:01:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 02:01:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 02:01:31 --> Model Class Initialized
INFO - 2018-06-16 02:01:31 --> Model Class Initialized
INFO - 2018-06-16 02:01:31 --> Model Class Initialized
INFO - 2018-06-16 02:01:31 --> Model Class Initialized
INFO - 2018-06-16 02:01:31 --> Final output sent to browser
DEBUG - 2018-06-16 02:01:31 --> Total execution time: 0.1304
INFO - 2018-06-16 02:01:32 --> Helper loaded: url_helper
INFO - 2018-06-16 02:01:32 --> Helper loaded: notification_helper
INFO - 2018-06-16 02:01:32 --> Helper loaded: settings_helper
INFO - 2018-06-16 02:01:32 --> Helper loaded: permission_helper
INFO - 2018-06-16 02:01:32 --> Helper loaded: users_helper
INFO - 2018-06-16 02:01:32 --> Database Driver Class Initialized
DEBUG - 2018-06-16 02:01:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 02:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 02:01:32 --> Helper loaded: form_helper
INFO - 2018-06-16 02:01:32 --> Form Validation Class Initialized
INFO - 2018-06-16 02:01:32 --> Controller Class Initialized
INFO - 2018-06-16 02:01:32 --> Model Class Initialized
INFO - 2018-06-16 02:01:32 --> Helper loaded: inflector_helper
DEBUG - 2018-06-16 02:01:32 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 02:01:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 02:01:32 --> Model Class Initialized
INFO - 2018-06-16 02:01:32 --> Model Class Initialized
INFO - 2018-06-16 02:01:32 --> Model Class Initialized
INFO - 2018-06-16 02:01:32 --> Model Class Initialized
INFO - 2018-06-16 02:01:32 --> Model Class Initialized
INFO - 2018-06-16 02:01:32 --> Model Class Initialized
INFO - 2018-06-16 02:01:32 --> Model Class Initialized
INFO - 2018-06-16 02:01:32 --> Model Class Initialized
INFO - 2018-06-16 02:01:32 --> Model Class Initialized
INFO - 2018-06-16 02:01:32 --> Model Class Initialized
INFO - 2018-06-16 02:01:32 --> Model Class Initialized
INFO - 2018-06-16 02:01:32 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-16 02:01:32 --> Model Class Initialized
INFO - 2018-06-16 02:01:32 --> Final output sent to browser
DEBUG - 2018-06-16 02:01:32 --> Total execution time: 0.1570
INFO - 2018-06-16 02:01:32 --> Helper loaded: url_helper
INFO - 2018-06-16 02:01:32 --> Helper loaded: notification_helper
INFO - 2018-06-16 02:01:32 --> Helper loaded: settings_helper
INFO - 2018-06-16 02:01:32 --> Helper loaded: permission_helper
INFO - 2018-06-16 02:01:32 --> Helper loaded: users_helper
INFO - 2018-06-16 02:01:32 --> Database Driver Class Initialized
DEBUG - 2018-06-16 02:01:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 02:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 02:01:32 --> Helper loaded: form_helper
INFO - 2018-06-16 02:01:32 --> Form Validation Class Initialized
INFO - 2018-06-16 02:01:32 --> Controller Class Initialized
INFO - 2018-06-16 02:01:32 --> Model Class Initialized
INFO - 2018-06-16 02:01:32 --> Helper loaded: inflector_helper
DEBUG - 2018-06-16 02:01:32 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 02:01:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 02:01:32 --> Model Class Initialized
INFO - 2018-06-16 02:01:32 --> Model Class Initialized
INFO - 2018-06-16 02:01:32 --> Model Class Initialized
INFO - 2018-06-16 02:01:32 --> Model Class Initialized
INFO - 2018-06-16 02:01:32 --> Model Class Initialized
INFO - 2018-06-16 02:01:32 --> Model Class Initialized
INFO - 2018-06-16 02:01:32 --> Model Class Initialized
INFO - 2018-06-16 02:01:32 --> Model Class Initialized
INFO - 2018-06-16 02:01:32 --> Model Class Initialized
INFO - 2018-06-16 02:01:32 --> Model Class Initialized
INFO - 2018-06-16 02:01:32 --> Model Class Initialized
INFO - 2018-06-16 02:01:32 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-16 02:01:32 --> Model Class Initialized
INFO - 2018-06-16 02:01:32 --> Final output sent to browser
DEBUG - 2018-06-16 02:01:32 --> Total execution time: 0.1478
INFO - 2018-06-16 02:01:34 --> Helper loaded: url_helper
INFO - 2018-06-16 02:01:34 --> Helper loaded: notification_helper
INFO - 2018-06-16 02:01:34 --> Helper loaded: settings_helper
INFO - 2018-06-16 02:01:34 --> Helper loaded: permission_helper
INFO - 2018-06-16 02:01:34 --> Helper loaded: users_helper
INFO - 2018-06-16 02:01:34 --> Database Driver Class Initialized
DEBUG - 2018-06-16 02:01:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 02:01:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 02:01:35 --> Helper loaded: form_helper
INFO - 2018-06-16 02:01:35 --> Form Validation Class Initialized
INFO - 2018-06-16 02:01:35 --> Controller Class Initialized
INFO - 2018-06-16 02:01:35 --> Model Class Initialized
INFO - 2018-06-16 02:01:35 --> Helper loaded: inflector_helper
DEBUG - 2018-06-16 02:01:35 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 02:01:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 02:01:35 --> Model Class Initialized
INFO - 2018-06-16 02:01:35 --> Model Class Initialized
INFO - 2018-06-16 02:01:35 --> Model Class Initialized
INFO - 2018-06-16 02:01:35 --> Model Class Initialized
INFO - 2018-06-16 02:01:35 --> Model Class Initialized
INFO - 2018-06-16 02:01:35 --> Model Class Initialized
INFO - 2018-06-16 02:01:35 --> Model Class Initialized
INFO - 2018-06-16 02:01:35 --> Model Class Initialized
INFO - 2018-06-16 02:01:35 --> Model Class Initialized
INFO - 2018-06-16 02:01:35 --> Model Class Initialized
INFO - 2018-06-16 02:01:35 --> Model Class Initialized
INFO - 2018-06-16 02:01:35 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-16 02:01:35 --> Model Class Initialized
INFO - 2018-06-16 02:01:35 --> Final output sent to browser
DEBUG - 2018-06-16 02:01:35 --> Total execution time: 0.1552
INFO - 2018-06-16 02:01:37 --> Helper loaded: url_helper
INFO - 2018-06-16 02:01:37 --> Helper loaded: notification_helper
INFO - 2018-06-16 02:01:37 --> Helper loaded: settings_helper
INFO - 2018-06-16 02:01:37 --> Helper loaded: permission_helper
INFO - 2018-06-16 02:01:37 --> Helper loaded: users_helper
INFO - 2018-06-16 02:01:37 --> Database Driver Class Initialized
DEBUG - 2018-06-16 02:01:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 02:01:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 02:01:37 --> Helper loaded: form_helper
INFO - 2018-06-16 02:01:37 --> Form Validation Class Initialized
INFO - 2018-06-16 02:01:37 --> Controller Class Initialized
INFO - 2018-06-16 02:01:37 --> Model Class Initialized
INFO - 2018-06-16 02:01:37 --> Helper loaded: inflector_helper
DEBUG - 2018-06-16 02:01:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 02:01:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 02:01:37 --> Model Class Initialized
INFO - 2018-06-16 02:01:37 --> Model Class Initialized
INFO - 2018-06-16 02:01:37 --> Model Class Initialized
INFO - 2018-06-16 02:01:37 --> Model Class Initialized
INFO - 2018-06-16 02:01:37 --> Model Class Initialized
INFO - 2018-06-16 02:01:37 --> Model Class Initialized
INFO - 2018-06-16 02:01:37 --> Model Class Initialized
INFO - 2018-06-16 02:01:37 --> Model Class Initialized
INFO - 2018-06-16 02:01:37 --> Model Class Initialized
INFO - 2018-06-16 02:01:37 --> Model Class Initialized
INFO - 2018-06-16 02:01:37 --> Model Class Initialized
INFO - 2018-06-16 02:01:37 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-16 02:01:37 --> Model Class Initialized
INFO - 2018-06-16 02:01:37 --> Final output sent to browser
DEBUG - 2018-06-16 02:01:37 --> Total execution time: 0.1497
INFO - 2018-06-16 02:01:40 --> Helper loaded: url_helper
INFO - 2018-06-16 02:01:40 --> Helper loaded: notification_helper
INFO - 2018-06-16 02:01:40 --> Helper loaded: settings_helper
INFO - 2018-06-16 02:01:40 --> Helper loaded: permission_helper
INFO - 2018-06-16 02:01:40 --> Helper loaded: users_helper
INFO - 2018-06-16 02:01:40 --> Database Driver Class Initialized
DEBUG - 2018-06-16 02:01:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 02:01:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 02:01:40 --> Helper loaded: form_helper
INFO - 2018-06-16 02:01:40 --> Form Validation Class Initialized
INFO - 2018-06-16 02:01:40 --> Controller Class Initialized
INFO - 2018-06-16 02:01:40 --> Model Class Initialized
INFO - 2018-06-16 02:01:40 --> Helper loaded: inflector_helper
DEBUG - 2018-06-16 02:01:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 02:01:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 02:01:40 --> Model Class Initialized
INFO - 2018-06-16 02:01:40 --> Model Class Initialized
INFO - 2018-06-16 02:01:40 --> Model Class Initialized
INFO - 2018-06-16 02:01:40 --> Model Class Initialized
INFO - 2018-06-16 02:01:40 --> Model Class Initialized
INFO - 2018-06-16 02:01:40 --> Model Class Initialized
INFO - 2018-06-16 02:01:40 --> Model Class Initialized
INFO - 2018-06-16 02:01:40 --> Model Class Initialized
INFO - 2018-06-16 02:01:40 --> Model Class Initialized
INFO - 2018-06-16 02:01:40 --> Model Class Initialized
INFO - 2018-06-16 02:01:40 --> Model Class Initialized
INFO - 2018-06-16 02:01:40 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-16 02:01:40 --> Final output sent to browser
DEBUG - 2018-06-16 02:01:40 --> Total execution time: 0.1318
INFO - 2018-06-16 02:01:43 --> Helper loaded: url_helper
INFO - 2018-06-16 02:01:43 --> Helper loaded: notification_helper
INFO - 2018-06-16 02:01:43 --> Helper loaded: settings_helper
INFO - 2018-06-16 02:01:43 --> Helper loaded: permission_helper
INFO - 2018-06-16 02:01:43 --> Helper loaded: users_helper
INFO - 2018-06-16 02:01:43 --> Database Driver Class Initialized
DEBUG - 2018-06-16 02:01:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 02:01:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 02:01:43 --> Helper loaded: form_helper
INFO - 2018-06-16 02:01:43 --> Form Validation Class Initialized
INFO - 2018-06-16 02:01:43 --> Controller Class Initialized
INFO - 2018-06-16 02:01:43 --> Model Class Initialized
INFO - 2018-06-16 02:01:43 --> Helper loaded: inflector_helper
DEBUG - 2018-06-16 02:01:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 02:01:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 02:01:43 --> Model Class Initialized
INFO - 2018-06-16 02:01:43 --> Model Class Initialized
INFO - 2018-06-16 02:01:43 --> Model Class Initialized
INFO - 2018-06-16 02:01:43 --> Model Class Initialized
INFO - 2018-06-16 02:01:43 --> Model Class Initialized
INFO - 2018-06-16 02:01:43 --> Model Class Initialized
INFO - 2018-06-16 02:01:43 --> Model Class Initialized
INFO - 2018-06-16 02:01:43 --> Model Class Initialized
INFO - 2018-06-16 02:01:43 --> Model Class Initialized
INFO - 2018-06-16 02:01:43 --> Model Class Initialized
INFO - 2018-06-16 02:01:43 --> Model Class Initialized
INFO - 2018-06-16 02:01:43 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-16 02:01:43 --> Model Class Initialized
INFO - 2018-06-16 02:01:43 --> Final output sent to browser
DEBUG - 2018-06-16 02:01:43 --> Total execution time: 0.1424
INFO - 2018-06-16 02:01:45 --> Helper loaded: url_helper
INFO - 2018-06-16 02:01:45 --> Helper loaded: notification_helper
INFO - 2018-06-16 02:01:45 --> Helper loaded: settings_helper
INFO - 2018-06-16 02:01:45 --> Helper loaded: permission_helper
INFO - 2018-06-16 02:01:45 --> Helper loaded: users_helper
INFO - 2018-06-16 02:01:45 --> Database Driver Class Initialized
DEBUG - 2018-06-16 02:01:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 02:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 02:01:45 --> Helper loaded: form_helper
INFO - 2018-06-16 02:01:45 --> Form Validation Class Initialized
INFO - 2018-06-16 02:01:45 --> Controller Class Initialized
INFO - 2018-06-16 02:01:45 --> Model Class Initialized
INFO - 2018-06-16 02:01:45 --> Helper loaded: inflector_helper
DEBUG - 2018-06-16 02:01:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 02:01:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 02:01:45 --> Model Class Initialized
INFO - 2018-06-16 02:01:45 --> Model Class Initialized
INFO - 2018-06-16 02:01:45 --> Model Class Initialized
INFO - 2018-06-16 02:01:45 --> Model Class Initialized
INFO - 2018-06-16 02:01:45 --> Model Class Initialized
INFO - 2018-06-16 02:01:45 --> Model Class Initialized
INFO - 2018-06-16 02:01:45 --> Model Class Initialized
INFO - 2018-06-16 02:01:45 --> Model Class Initialized
INFO - 2018-06-16 02:01:45 --> Model Class Initialized
INFO - 2018-06-16 02:01:45 --> Model Class Initialized
INFO - 2018-06-16 02:01:45 --> Model Class Initialized
INFO - 2018-06-16 02:01:45 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-16 02:01:45 --> Model Class Initialized
INFO - 2018-06-16 02:01:45 --> Final output sent to browser
DEBUG - 2018-06-16 02:01:45 --> Total execution time: 0.1279
INFO - 2018-06-16 02:01:51 --> Helper loaded: url_helper
INFO - 2018-06-16 02:01:51 --> Helper loaded: notification_helper
INFO - 2018-06-16 02:01:51 --> Helper loaded: settings_helper
INFO - 2018-06-16 02:01:51 --> Helper loaded: permission_helper
INFO - 2018-06-16 02:01:51 --> Helper loaded: users_helper
INFO - 2018-06-16 02:01:51 --> Database Driver Class Initialized
DEBUG - 2018-06-16 02:01:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 02:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 02:01:51 --> Helper loaded: form_helper
INFO - 2018-06-16 02:01:51 --> Form Validation Class Initialized
INFO - 2018-06-16 02:01:51 --> Controller Class Initialized
INFO - 2018-06-16 02:01:51 --> Model Class Initialized
INFO - 2018-06-16 02:01:51 --> Helper loaded: inflector_helper
DEBUG - 2018-06-16 02:01:51 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 02:01:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 02:01:51 --> Model Class Initialized
INFO - 2018-06-16 02:01:51 --> Model Class Initialized
INFO - 2018-06-16 02:01:51 --> Model Class Initialized
INFO - 2018-06-16 02:01:51 --> Model Class Initialized
INFO - 2018-06-16 02:01:51 --> Model Class Initialized
INFO - 2018-06-16 02:01:51 --> Model Class Initialized
INFO - 2018-06-16 02:01:51 --> Model Class Initialized
INFO - 2018-06-16 02:01:51 --> Model Class Initialized
INFO - 2018-06-16 02:01:51 --> Model Class Initialized
INFO - 2018-06-16 02:01:51 --> Model Class Initialized
INFO - 2018-06-16 02:01:51 --> Model Class Initialized
INFO - 2018-06-16 02:01:51 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-16 02:01:51 --> Final output sent to browser
DEBUG - 2018-06-16 02:01:51 --> Total execution time: 0.1496
INFO - 2018-06-16 02:01:54 --> Helper loaded: url_helper
INFO - 2018-06-16 02:01:54 --> Helper loaded: notification_helper
INFO - 2018-06-16 02:01:54 --> Helper loaded: settings_helper
INFO - 2018-06-16 02:01:54 --> Helper loaded: permission_helper
INFO - 2018-06-16 02:01:54 --> Helper loaded: users_helper
INFO - 2018-06-16 02:01:54 --> Database Driver Class Initialized
DEBUG - 2018-06-16 02:01:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 02:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 02:01:54 --> Helper loaded: form_helper
INFO - 2018-06-16 02:01:54 --> Form Validation Class Initialized
INFO - 2018-06-16 02:01:54 --> Controller Class Initialized
INFO - 2018-06-16 02:01:54 --> Model Class Initialized
INFO - 2018-06-16 02:01:54 --> Helper loaded: inflector_helper
DEBUG - 2018-06-16 02:01:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 02:01:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 02:01:54 --> Model Class Initialized
INFO - 2018-06-16 02:01:54 --> Model Class Initialized
INFO - 2018-06-16 02:01:54 --> Model Class Initialized
INFO - 2018-06-16 02:01:54 --> Model Class Initialized
INFO - 2018-06-16 02:01:54 --> Model Class Initialized
INFO - 2018-06-16 02:01:54 --> Model Class Initialized
INFO - 2018-06-16 02:01:54 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-16 02:01:54 --> Final output sent to browser
DEBUG - 2018-06-16 02:01:54 --> Total execution time: 0.1120
INFO - 2018-06-16 02:01:55 --> Helper loaded: url_helper
INFO - 2018-06-16 02:01:55 --> Helper loaded: notification_helper
INFO - 2018-06-16 02:01:55 --> Helper loaded: settings_helper
INFO - 2018-06-16 02:01:55 --> Helper loaded: permission_helper
INFO - 2018-06-16 02:01:55 --> Helper loaded: url_helper
INFO - 2018-06-16 02:01:55 --> Helper loaded: users_helper
INFO - 2018-06-16 02:01:55 --> Helper loaded: notification_helper
INFO - 2018-06-16 02:01:55 --> Helper loaded: settings_helper
INFO - 2018-06-16 02:01:55 --> Helper loaded: permission_helper
INFO - 2018-06-16 02:01:55 --> Helper loaded: users_helper
INFO - 2018-06-16 02:01:55 --> Database Driver Class Initialized
INFO - 2018-06-16 02:01:55 --> Database Driver Class Initialized
DEBUG - 2018-06-16 02:01:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 02:01:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-06-16 02:01:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 02:01:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 02:01:55 --> Helper loaded: form_helper
INFO - 2018-06-16 02:01:55 --> Form Validation Class Initialized
INFO - 2018-06-16 02:01:55 --> Controller Class Initialized
INFO - 2018-06-16 02:01:55 --> Helper loaded: form_helper
INFO - 2018-06-16 02:01:55 --> Form Validation Class Initialized
INFO - 2018-06-16 02:01:55 --> Controller Class Initialized
INFO - 2018-06-16 02:01:55 --> Model Class Initialized
INFO - 2018-06-16 02:01:55 --> Helper loaded: inflector_helper
DEBUG - 2018-06-16 02:01:55 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 02:01:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 02:01:55 --> Model Class Initialized
INFO - 2018-06-16 02:01:55 --> Model Class Initialized
INFO - 2018-06-16 02:01:55 --> Helper loaded: inflector_helper
INFO - 2018-06-16 02:01:55 --> Model Class Initialized
INFO - 2018-06-16 02:01:55 --> Model Class Initialized
INFO - 2018-06-16 02:01:55 --> Model Class Initialized
INFO - 2018-06-16 02:01:55 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-06-16 02:01:55 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 02:01:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 02:01:55 --> Final output sent to browser
DEBUG - 2018-06-16 02:01:55 --> Total execution time: 0.1043
INFO - 2018-06-16 02:01:55 --> Model Class Initialized
INFO - 2018-06-16 02:01:55 --> Model Class Initialized
INFO - 2018-06-16 02:01:55 --> Model Class Initialized
INFO - 2018-06-16 02:01:55 --> Model Class Initialized
INFO - 2018-06-16 02:01:55 --> Model Class Initialized
INFO - 2018-06-16 02:01:55 --> Model Class Initialized
INFO - 2018-06-16 02:01:55 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-16 02:01:55 --> Final output sent to browser
DEBUG - 2018-06-16 02:01:55 --> Total execution time: 0.1177
INFO - 2018-06-16 02:02:03 --> Helper loaded: url_helper
INFO - 2018-06-16 02:02:03 --> Helper loaded: notification_helper
INFO - 2018-06-16 02:02:03 --> Helper loaded: settings_helper
INFO - 2018-06-16 02:02:03 --> Helper loaded: permission_helper
INFO - 2018-06-16 02:02:03 --> Helper loaded: users_helper
INFO - 2018-06-16 02:02:03 --> Database Driver Class Initialized
DEBUG - 2018-06-16 02:02:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 02:02:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 02:02:03 --> Helper loaded: form_helper
INFO - 2018-06-16 02:02:03 --> Form Validation Class Initialized
INFO - 2018-06-16 02:02:03 --> Controller Class Initialized
INFO - 2018-06-16 02:02:03 --> Model Class Initialized
INFO - 2018-06-16 02:02:03 --> Helper loaded: inflector_helper
DEBUG - 2018-06-16 02:02:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 02:02:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 02:02:03 --> Model Class Initialized
INFO - 2018-06-16 02:02:03 --> Model Class Initialized
INFO - 2018-06-16 02:02:03 --> Model Class Initialized
INFO - 2018-06-16 02:02:03 --> Model Class Initialized
INFO - 2018-06-16 02:02:03 --> Model Class Initialized
INFO - 2018-06-16 02:02:03 --> Model Class Initialized
INFO - 2018-06-16 02:02:03 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-16 02:02:03 --> Final output sent to browser
DEBUG - 2018-06-16 02:02:03 --> Total execution time: 0.1170
INFO - 2018-06-16 06:01:59 --> Config Class Initialized
INFO - 2018-06-16 06:01:59 --> Hooks Class Initialized
DEBUG - 2018-06-16 06:01:59 --> UTF-8 Support Enabled
INFO - 2018-06-16 06:01:59 --> Utf8 Class Initialized
INFO - 2018-06-16 06:01:59 --> URI Class Initialized
INFO - 2018-06-16 06:01:59 --> Router Class Initialized
INFO - 2018-06-16 06:01:59 --> Output Class Initialized
INFO - 2018-06-16 06:01:59 --> Security Class Initialized
DEBUG - 2018-06-16 06:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 06:01:59 --> Input Class Initialized
INFO - 2018-06-16 06:01:59 --> Language Class Initialized
INFO - 2018-06-16 06:01:59 --> Config Class Initialized
INFO - 2018-06-16 06:01:59 --> Hooks Class Initialized
DEBUG - 2018-06-16 06:01:59 --> UTF-8 Support Enabled
INFO - 2018-06-16 06:01:59 --> Utf8 Class Initialized
INFO - 2018-06-16 06:01:59 --> URI Class Initialized
INFO - 2018-06-16 06:01:59 --> Language Class Initialized
INFO - 2018-06-16 06:01:59 --> Config Class Initialized
INFO - 2018-06-16 06:01:59 --> Loader Class Initialized
INFO - 2018-06-16 06:01:59 --> Router Class Initialized
INFO - 2018-06-16 11:31:59 --> Helper loaded: url_helper
INFO - 2018-06-16 11:31:59 --> Helper loaded: notification_helper
INFO - 2018-06-16 06:01:59 --> Output Class Initialized
INFO - 2018-06-16 11:31:59 --> Helper loaded: settings_helper
INFO - 2018-06-16 11:31:59 --> Helper loaded: permission_helper
INFO - 2018-06-16 11:31:59 --> Helper loaded: users_helper
INFO - 2018-06-16 06:01:59 --> Security Class Initialized
DEBUG - 2018-06-16 06:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 06:01:59 --> Input Class Initialized
INFO - 2018-06-16 06:01:59 --> Language Class Initialized
INFO - 2018-06-16 11:31:59 --> Database Driver Class Initialized
DEBUG - 2018-06-16 11:31:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 11:31:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 06:01:59 --> Language Class Initialized
INFO - 2018-06-16 06:01:59 --> Config Class Initialized
INFO - 2018-06-16 06:01:59 --> Loader Class Initialized
INFO - 2018-06-16 11:31:59 --> Helper loaded: url_helper
INFO - 2018-06-16 11:31:59 --> Helper loaded: form_helper
INFO - 2018-06-16 11:31:59 --> Form Validation Class Initialized
INFO - 2018-06-16 11:31:59 --> Controller Class Initialized
INFO - 2018-06-16 11:31:59 --> Helper loaded: notification_helper
INFO - 2018-06-16 11:31:59 --> Helper loaded: settings_helper
INFO - 2018-06-16 11:31:59 --> Helper loaded: permission_helper
INFO - 2018-06-16 11:31:59 --> Helper loaded: users_helper
INFO - 2018-06-16 11:31:59 --> Model Class Initialized
INFO - 2018-06-16 11:31:59 --> Helper loaded: inflector_helper
DEBUG - 2018-06-16 11:31:59 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 11:31:59 --> Database Driver Class Initialized
DEBUG - 2018-06-16 11:31:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 11:31:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 11:31:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 11:31:59 --> Model Class Initialized
INFO - 2018-06-16 11:31:59 --> Model Class Initialized
INFO - 2018-06-16 11:31:59 --> Model Class Initialized
INFO - 2018-06-16 11:31:59 --> Model Class Initialized
INFO - 2018-06-16 11:31:59 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-16 11:31:59 --> Model Class Initialized
INFO - 2018-06-16 11:31:59 --> Final output sent to browser
DEBUG - 2018-06-16 11:31:59 --> Total execution time: 0.1406
INFO - 2018-06-16 11:31:59 --> Helper loaded: form_helper
INFO - 2018-06-16 11:31:59 --> Form Validation Class Initialized
INFO - 2018-06-16 11:31:59 --> Controller Class Initialized
INFO - 2018-06-16 11:31:59 --> Model Class Initialized
INFO - 2018-06-16 11:31:59 --> Helper loaded: inflector_helper
DEBUG - 2018-06-16 11:31:59 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 11:31:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 11:31:59 --> Model Class Initialized
INFO - 2018-06-16 11:31:59 --> Model Class Initialized
INFO - 2018-06-16 11:31:59 --> Model Class Initialized
INFO - 2018-06-16 11:31:59 --> Model Class Initialized
INFO - 2018-06-16 11:31:59 --> Model Class Initialized
INFO - 2018-06-16 11:31:59 --> Model Class Initialized
INFO - 2018-06-16 11:31:59 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-16 11:31:59 --> Final output sent to browser
DEBUG - 2018-06-16 11:31:59 --> Total execution time: 0.1466
INFO - 2018-06-16 06:01:59 --> Config Class Initialized
INFO - 2018-06-16 06:01:59 --> Hooks Class Initialized
DEBUG - 2018-06-16 06:01:59 --> UTF-8 Support Enabled
INFO - 2018-06-16 06:01:59 --> Utf8 Class Initialized
INFO - 2018-06-16 06:01:59 --> URI Class Initialized
INFO - 2018-06-16 06:01:59 --> Router Class Initialized
INFO - 2018-06-16 06:01:59 --> Output Class Initialized
INFO - 2018-06-16 06:01:59 --> Security Class Initialized
DEBUG - 2018-06-16 06:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 06:01:59 --> Input Class Initialized
INFO - 2018-06-16 06:01:59 --> Language Class Initialized
INFO - 2018-06-16 06:01:59 --> Language Class Initialized
INFO - 2018-06-16 06:01:59 --> Config Class Initialized
INFO - 2018-06-16 06:01:59 --> Loader Class Initialized
INFO - 2018-06-16 11:31:59 --> Helper loaded: url_helper
INFO - 2018-06-16 11:31:59 --> Helper loaded: notification_helper
INFO - 2018-06-16 11:31:59 --> Helper loaded: settings_helper
INFO - 2018-06-16 11:31:59 --> Helper loaded: permission_helper
INFO - 2018-06-16 11:31:59 --> Helper loaded: users_helper
INFO - 2018-06-16 11:31:59 --> Database Driver Class Initialized
DEBUG - 2018-06-16 11:31:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 11:31:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 11:31:59 --> Helper loaded: form_helper
INFO - 2018-06-16 11:31:59 --> Form Validation Class Initialized
INFO - 2018-06-16 11:31:59 --> Controller Class Initialized
INFO - 2018-06-16 11:31:59 --> Model Class Initialized
INFO - 2018-06-16 11:31:59 --> Helper loaded: inflector_helper
DEBUG - 2018-06-16 11:31:59 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 11:31:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 11:31:59 --> Model Class Initialized
INFO - 2018-06-16 11:31:59 --> Model Class Initialized
INFO - 2018-06-16 11:31:59 --> Model Class Initialized
INFO - 2018-06-16 11:31:59 --> Model Class Initialized
INFO - 2018-06-16 11:31:59 --> Model Class Initialized
INFO - 2018-06-16 11:31:59 --> Model Class Initialized
INFO - 2018-06-16 11:31:59 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-16 11:31:59 --> Model Class Initialized
INFO - 2018-06-16 11:31:59 --> Final output sent to browser
DEBUG - 2018-06-16 11:31:59 --> Total execution time: 0.1247
INFO - 2018-06-16 06:01:59 --> Config Class Initialized
INFO - 2018-06-16 06:01:59 --> Hooks Class Initialized
DEBUG - 2018-06-16 06:01:59 --> UTF-8 Support Enabled
INFO - 2018-06-16 06:01:59 --> Utf8 Class Initialized
INFO - 2018-06-16 06:01:59 --> URI Class Initialized
INFO - 2018-06-16 06:01:59 --> Router Class Initialized
INFO - 2018-06-16 06:01:59 --> Output Class Initialized
INFO - 2018-06-16 06:01:59 --> Config Class Initialized
INFO - 2018-06-16 06:01:59 --> Hooks Class Initialized
INFO - 2018-06-16 06:01:59 --> Security Class Initialized
DEBUG - 2018-06-16 06:01:59 --> UTF-8 Support Enabled
INFO - 2018-06-16 06:01:59 --> Utf8 Class Initialized
DEBUG - 2018-06-16 06:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 06:01:59 --> Input Class Initialized
INFO - 2018-06-16 06:01:59 --> Language Class Initialized
INFO - 2018-06-16 06:01:59 --> URI Class Initialized
INFO - 2018-06-16 06:01:59 --> Router Class Initialized
INFO - 2018-06-16 06:01:59 --> Output Class Initialized
INFO - 2018-06-16 06:01:59 --> Security Class Initialized
DEBUG - 2018-06-16 06:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 06:01:59 --> Input Class Initialized
INFO - 2018-06-16 06:01:59 --> Language Class Initialized
INFO - 2018-06-16 06:01:59 --> Language Class Initialized
INFO - 2018-06-16 06:01:59 --> Config Class Initialized
INFO - 2018-06-16 06:01:59 --> Loader Class Initialized
INFO - 2018-06-16 11:31:59 --> Helper loaded: url_helper
INFO - 2018-06-16 11:31:59 --> Helper loaded: notification_helper
INFO - 2018-06-16 11:31:59 --> Helper loaded: settings_helper
INFO - 2018-06-16 11:31:59 --> Helper loaded: permission_helper
INFO - 2018-06-16 11:31:59 --> Helper loaded: users_helper
INFO - 2018-06-16 06:01:59 --> Config Class Initialized
INFO - 2018-06-16 06:01:59 --> Hooks Class Initialized
INFO - 2018-06-16 06:01:59 --> Language Class Initialized
INFO - 2018-06-16 06:01:59 --> Config Class Initialized
INFO - 2018-06-16 06:01:59 --> Loader Class Initialized
DEBUG - 2018-06-16 06:01:59 --> UTF-8 Support Enabled
INFO - 2018-06-16 06:01:59 --> Utf8 Class Initialized
INFO - 2018-06-16 11:31:59 --> Helper loaded: url_helper
INFO - 2018-06-16 11:31:59 --> Database Driver Class Initialized
INFO - 2018-06-16 11:31:59 --> Helper loaded: notification_helper
INFO - 2018-06-16 06:01:59 --> URI Class Initialized
INFO - 2018-06-16 11:31:59 --> Helper loaded: settings_helper
INFO - 2018-06-16 11:31:59 --> Helper loaded: permission_helper
INFO - 2018-06-16 11:31:59 --> Helper loaded: users_helper
INFO - 2018-06-16 06:01:59 --> Router Class Initialized
DEBUG - 2018-06-16 11:31:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 11:31:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 06:01:59 --> Output Class Initialized
INFO - 2018-06-16 06:01:59 --> Security Class Initialized
DEBUG - 2018-06-16 06:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 06:01:59 --> Input Class Initialized
INFO - 2018-06-16 11:31:59 --> Helper loaded: form_helper
INFO - 2018-06-16 11:31:59 --> Form Validation Class Initialized
INFO - 2018-06-16 11:31:59 --> Controller Class Initialized
INFO - 2018-06-16 06:01:59 --> Language Class Initialized
INFO - 2018-06-16 11:31:59 --> Database Driver Class Initialized
INFO - 2018-06-16 11:31:59 --> Model Class Initialized
INFO - 2018-06-16 11:31:59 --> Helper loaded: inflector_helper
DEBUG - 2018-06-16 11:31:59 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 06:01:59 --> Config Class Initialized
INFO - 2018-06-16 06:01:59 --> Hooks Class Initialized
DEBUG - 2018-06-16 11:31:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 11:31:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 11:31:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 11:31:59 --> Model Class Initialized
INFO - 2018-06-16 11:31:59 --> Model Class Initialized
DEBUG - 2018-06-16 06:01:59 --> UTF-8 Support Enabled
INFO - 2018-06-16 06:01:59 --> Utf8 Class Initialized
INFO - 2018-06-16 11:31:59 --> Model Class Initialized
INFO - 2018-06-16 11:31:59 --> Model Class Initialized
INFO - 2018-06-16 11:31:59 --> Model Class Initialized
INFO - 2018-06-16 06:01:59 --> URI Class Initialized
INFO - 2018-06-16 11:31:59 --> Model Class Initialized
INFO - 2018-06-16 11:31:59 --> Model Class Initialized
INFO - 2018-06-16 11:31:59 --> Model Class Initialized
INFO - 2018-06-16 11:31:59 --> Model Class Initialized
INFO - 2018-06-16 11:31:59 --> Model Class Initialized
INFO - 2018-06-16 06:01:59 --> Router Class Initialized
INFO - 2018-06-16 11:31:59 --> Helper loaded: form_helper
INFO - 2018-06-16 11:31:59 --> Form Validation Class Initialized
INFO - 2018-06-16 11:31:59 --> Controller Class Initialized
INFO - 2018-06-16 11:31:59 --> Model Class Initialized
INFO - 2018-06-16 11:31:59 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-16 11:31:59 --> Model Class Initialized
INFO - 2018-06-16 06:01:59 --> Output Class Initialized
INFO - 2018-06-16 06:01:59 --> Security Class Initialized
INFO - 2018-06-16 06:01:59 --> Config Class Initialized
INFO - 2018-06-16 06:01:59 --> Hooks Class Initialized
DEBUG - 2018-06-16 06:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 06:01:59 --> Input Class Initialized
INFO - 2018-06-16 06:01:59 --> Language Class Initialized
INFO - 2018-06-16 11:31:59 --> Model Class Initialized
INFO - 2018-06-16 11:31:59 --> Helper loaded: inflector_helper
DEBUG - 2018-06-16 11:31:59 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 11:31:59 --> Language file loaded: language/english/rest_controller_lang.php
DEBUG - 2018-06-16 06:01:59 --> UTF-8 Support Enabled
INFO - 2018-06-16 06:01:59 --> Utf8 Class Initialized
INFO - 2018-06-16 11:31:59 --> Model Class Initialized
INFO - 2018-06-16 11:31:59 --> Model Class Initialized
INFO - 2018-06-16 06:01:59 --> URI Class Initialized
INFO - 2018-06-16 11:31:59 --> Model Class Initialized
INFO - 2018-06-16 11:31:59 --> Model Class Initialized
INFO - 2018-06-16 11:31:59 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-16 11:31:59 --> Model Class Initialized
INFO - 2018-06-16 11:31:59 --> Final output sent to browser
DEBUG - 2018-06-16 11:31:59 --> Total execution time: 0.1508
INFO - 2018-06-16 06:01:59 --> Language Class Initialized
INFO - 2018-06-16 06:01:59 --> Config Class Initialized
INFO - 2018-06-16 06:01:59 --> Loader Class Initialized
INFO - 2018-06-16 11:31:59 --> Final output sent to browser
DEBUG - 2018-06-16 11:31:59 --> Total execution time: 0.1344
INFO - 2018-06-16 06:01:59 --> Language Class Initialized
INFO - 2018-06-16 06:01:59 --> Config Class Initialized
INFO - 2018-06-16 06:01:59 --> Loader Class Initialized
INFO - 2018-06-16 11:31:59 --> Helper loaded: url_helper
INFO - 2018-06-16 11:31:59 --> Helper loaded: notification_helper
INFO - 2018-06-16 11:31:59 --> Helper loaded: settings_helper
INFO - 2018-06-16 11:31:59 --> Helper loaded: permission_helper
INFO - 2018-06-16 11:31:59 --> Helper loaded: users_helper
INFO - 2018-06-16 06:01:59 --> Router Class Initialized
INFO - 2018-06-16 11:31:59 --> Helper loaded: url_helper
INFO - 2018-06-16 11:31:59 --> Helper loaded: notification_helper
INFO - 2018-06-16 11:31:59 --> Helper loaded: settings_helper
INFO - 2018-06-16 11:31:59 --> Helper loaded: permission_helper
INFO - 2018-06-16 06:01:59 --> Output Class Initialized
INFO - 2018-06-16 11:31:59 --> Helper loaded: users_helper
INFO - 2018-06-16 06:01:59 --> Security Class Initialized
INFO - 2018-06-16 11:31:59 --> Database Driver Class Initialized
DEBUG - 2018-06-16 06:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 06:01:59 --> Input Class Initialized
INFO - 2018-06-16 06:01:59 --> Language Class Initialized
DEBUG - 2018-06-16 11:31:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 11:31:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 11:31:59 --> Helper loaded: form_helper
INFO - 2018-06-16 11:31:59 --> Form Validation Class Initialized
INFO - 2018-06-16 11:31:59 --> Controller Class Initialized
INFO - 2018-06-16 11:31:59 --> Database Driver Class Initialized
INFO - 2018-06-16 11:31:59 --> Model Class Initialized
INFO - 2018-06-16 11:31:59 --> Helper loaded: inflector_helper
INFO - 2018-06-16 06:01:59 --> Language Class Initialized
INFO - 2018-06-16 06:01:59 --> Config Class Initialized
INFO - 2018-06-16 06:01:59 --> Loader Class Initialized
INFO - 2018-06-16 11:31:59 --> Helper loaded: url_helper
DEBUG - 2018-06-16 11:31:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 11:31:59 --> Helper loaded: notification_helper
INFO - 2018-06-16 11:31:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 11:31:59 --> Helper loaded: settings_helper
INFO - 2018-06-16 11:31:59 --> Helper loaded: permission_helper
INFO - 2018-06-16 11:31:59 --> Helper loaded: users_helper
DEBUG - 2018-06-16 11:31:59 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 11:31:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 11:31:59 --> Model Class Initialized
INFO - 2018-06-16 11:31:59 --> Model Class Initialized
INFO - 2018-06-16 11:31:59 --> Model Class Initialized
INFO - 2018-06-16 11:31:59 --> Model Class Initialized
INFO - 2018-06-16 11:31:59 --> Model Class Initialized
INFO - 2018-06-16 11:31:59 --> Model Class Initialized
INFO - 2018-06-16 11:31:59 --> Model Class Initialized
INFO - 2018-06-16 11:31:59 --> Database Driver Class Initialized
INFO - 2018-06-16 11:31:59 --> Helper loaded: form_helper
INFO - 2018-06-16 11:31:59 --> Form Validation Class Initialized
INFO - 2018-06-16 11:31:59 --> Controller Class Initialized
INFO - 2018-06-16 11:31:59 --> Model Class Initialized
INFO - 2018-06-16 11:31:59 --> Model Class Initialized
INFO - 2018-06-16 11:31:59 --> Model Class Initialized
DEBUG - 2018-06-16 11:31:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 11:31:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 11:31:59 --> Model Class Initialized
INFO - 2018-06-16 11:31:59 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-16 11:31:59 --> Model Class Initialized
INFO - 2018-06-16 11:31:59 --> Helper loaded: form_helper
INFO - 2018-06-16 11:31:59 --> Form Validation Class Initialized
INFO - 2018-06-16 11:31:59 --> Controller Class Initialized
INFO - 2018-06-16 11:31:59 --> Model Class Initialized
INFO - 2018-06-16 11:31:59 --> Helper loaded: inflector_helper
INFO - 2018-06-16 11:31:59 --> Model Class Initialized
DEBUG - 2018-06-16 11:31:59 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 11:31:59 --> Helper loaded: inflector_helper
INFO - 2018-06-16 11:31:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 11:31:59 --> Model Class Initialized
INFO - 2018-06-16 11:31:59 --> Model Class Initialized
INFO - 2018-06-16 11:31:59 --> Model Class Initialized
INFO - 2018-06-16 11:31:59 --> Model Class Initialized
INFO - 2018-06-16 11:31:59 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-16 11:31:59 --> Model Class Initialized
DEBUG - 2018-06-16 11:31:59 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 11:31:59 --> Final output sent to browser
DEBUG - 2018-06-16 11:31:59 --> Total execution time: 0.1714
INFO - 2018-06-16 11:31:59 --> Final output sent to browser
DEBUG - 2018-06-16 11:31:59 --> Total execution time: 0.1880
INFO - 2018-06-16 11:31:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 11:31:59 --> Model Class Initialized
INFO - 2018-06-16 11:31:59 --> Model Class Initialized
INFO - 2018-06-16 11:31:59 --> Model Class Initialized
INFO - 2018-06-16 11:31:59 --> Model Class Initialized
INFO - 2018-06-16 11:31:59 --> Model Class Initialized
INFO - 2018-06-16 11:31:59 --> Model Class Initialized
INFO - 2018-06-16 11:31:59 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-16 11:31:59 --> Model Class Initialized
INFO - 2018-06-16 11:31:59 --> Final output sent to browser
DEBUG - 2018-06-16 11:31:59 --> Total execution time: 0.2449
INFO - 2018-06-16 06:02:07 --> Config Class Initialized
INFO - 2018-06-16 06:02:07 --> Hooks Class Initialized
DEBUG - 2018-06-16 06:02:07 --> UTF-8 Support Enabled
INFO - 2018-06-16 06:02:07 --> Utf8 Class Initialized
INFO - 2018-06-16 06:02:07 --> URI Class Initialized
INFO - 2018-06-16 06:02:07 --> Router Class Initialized
INFO - 2018-06-16 06:02:07 --> Output Class Initialized
INFO - 2018-06-16 06:02:07 --> Security Class Initialized
DEBUG - 2018-06-16 06:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 06:02:07 --> Input Class Initialized
INFO - 2018-06-16 06:02:07 --> Language Class Initialized
INFO - 2018-06-16 06:02:07 --> Language Class Initialized
INFO - 2018-06-16 06:02:07 --> Config Class Initialized
INFO - 2018-06-16 06:02:07 --> Loader Class Initialized
INFO - 2018-06-16 11:32:07 --> Helper loaded: url_helper
INFO - 2018-06-16 11:32:07 --> Helper loaded: notification_helper
INFO - 2018-06-16 11:32:07 --> Helper loaded: settings_helper
INFO - 2018-06-16 11:32:07 --> Helper loaded: permission_helper
INFO - 2018-06-16 11:32:07 --> Helper loaded: users_helper
INFO - 2018-06-16 11:32:07 --> Database Driver Class Initialized
DEBUG - 2018-06-16 11:32:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 11:32:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 06:02:07 --> Config Class Initialized
INFO - 2018-06-16 06:02:07 --> Hooks Class Initialized
DEBUG - 2018-06-16 06:02:07 --> UTF-8 Support Enabled
INFO - 2018-06-16 06:02:07 --> Utf8 Class Initialized
INFO - 2018-06-16 11:32:07 --> Helper loaded: form_helper
INFO - 2018-06-16 11:32:07 --> Form Validation Class Initialized
INFO - 2018-06-16 11:32:07 --> Controller Class Initialized
INFO - 2018-06-16 06:02:07 --> URI Class Initialized
INFO - 2018-06-16 06:02:07 --> Router Class Initialized
INFO - 2018-06-16 11:32:07 --> Model Class Initialized
INFO - 2018-06-16 06:02:07 --> Output Class Initialized
INFO - 2018-06-16 11:32:07 --> Helper loaded: inflector_helper
INFO - 2018-06-16 06:02:07 --> Security Class Initialized
DEBUG - 2018-06-16 11:32:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 11:32:07 --> Language file loaded: language/english/rest_controller_lang.php
DEBUG - 2018-06-16 06:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 06:02:07 --> Input Class Initialized
INFO - 2018-06-16 11:32:07 --> Model Class Initialized
INFO - 2018-06-16 06:02:07 --> Language Class Initialized
INFO - 2018-06-16 11:32:07 --> Model Class Initialized
INFO - 2018-06-16 11:32:07 --> Model Class Initialized
INFO - 2018-06-16 11:32:07 --> Model Class Initialized
INFO - 2018-06-16 11:32:07 --> Final output sent to browser
DEBUG - 2018-06-16 11:32:07 --> Total execution time: 0.1076
INFO - 2018-06-16 06:02:07 --> Language Class Initialized
INFO - 2018-06-16 06:02:07 --> Config Class Initialized
INFO - 2018-06-16 06:02:07 --> Loader Class Initialized
INFO - 2018-06-16 11:32:07 --> Helper loaded: url_helper
INFO - 2018-06-16 11:32:07 --> Helper loaded: notification_helper
INFO - 2018-06-16 11:32:07 --> Helper loaded: settings_helper
INFO - 2018-06-16 11:32:07 --> Helper loaded: permission_helper
INFO - 2018-06-16 11:32:07 --> Helper loaded: users_helper
INFO - 2018-06-16 11:32:07 --> Database Driver Class Initialized
DEBUG - 2018-06-16 11:32:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 11:32:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 11:32:07 --> Helper loaded: form_helper
INFO - 2018-06-16 11:32:07 --> Form Validation Class Initialized
INFO - 2018-06-16 11:32:07 --> Controller Class Initialized
INFO - 2018-06-16 11:32:07 --> Model Class Initialized
INFO - 2018-06-16 11:32:07 --> Helper loaded: inflector_helper
DEBUG - 2018-06-16 11:32:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 11:32:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 11:32:07 --> Model Class Initialized
INFO - 2018-06-16 11:32:07 --> Model Class Initialized
INFO - 2018-06-16 11:32:07 --> Model Class Initialized
INFO - 2018-06-16 11:32:07 --> Model Class Initialized
INFO - 2018-06-16 11:32:07 --> Final output sent to browser
DEBUG - 2018-06-16 11:32:07 --> Total execution time: 0.1203
INFO - 2018-06-16 06:02:10 --> Config Class Initialized
INFO - 2018-06-16 06:02:10 --> Hooks Class Initialized
DEBUG - 2018-06-16 06:02:10 --> UTF-8 Support Enabled
INFO - 2018-06-16 06:02:10 --> Utf8 Class Initialized
INFO - 2018-06-16 06:02:10 --> URI Class Initialized
INFO - 2018-06-16 06:02:10 --> Config Class Initialized
INFO - 2018-06-16 06:02:10 --> Hooks Class Initialized
DEBUG - 2018-06-16 06:02:10 --> UTF-8 Support Enabled
INFO - 2018-06-16 06:02:10 --> Utf8 Class Initialized
INFO - 2018-06-16 06:02:10 --> URI Class Initialized
INFO - 2018-06-16 06:02:10 --> Router Class Initialized
INFO - 2018-06-16 06:02:10 --> Output Class Initialized
INFO - 2018-06-16 06:02:10 --> Router Class Initialized
INFO - 2018-06-16 06:02:10 --> Output Class Initialized
INFO - 2018-06-16 06:02:10 --> Security Class Initialized
DEBUG - 2018-06-16 06:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 06:02:10 --> Input Class Initialized
INFO - 2018-06-16 06:02:10 --> Security Class Initialized
INFO - 2018-06-16 06:02:10 --> Language Class Initialized
DEBUG - 2018-06-16 06:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 06:02:10 --> Input Class Initialized
INFO - 2018-06-16 06:02:10 --> Language Class Initialized
INFO - 2018-06-16 06:02:10 --> Language Class Initialized
INFO - 2018-06-16 06:02:10 --> Config Class Initialized
INFO - 2018-06-16 06:02:10 --> Loader Class Initialized
INFO - 2018-06-16 11:32:10 --> Helper loaded: url_helper
INFO - 2018-06-16 11:32:10 --> Helper loaded: notification_helper
INFO - 2018-06-16 11:32:10 --> Helper loaded: settings_helper
INFO - 2018-06-16 11:32:10 --> Helper loaded: permission_helper
INFO - 2018-06-16 11:32:10 --> Helper loaded: users_helper
INFO - 2018-06-16 06:02:10 --> Language Class Initialized
INFO - 2018-06-16 06:02:10 --> Config Class Initialized
INFO - 2018-06-16 06:02:10 --> Loader Class Initialized
INFO - 2018-06-16 11:32:10 --> Helper loaded: url_helper
INFO - 2018-06-16 11:32:10 --> Database Driver Class Initialized
INFO - 2018-06-16 11:32:10 --> Helper loaded: notification_helper
INFO - 2018-06-16 11:32:10 --> Helper loaded: settings_helper
INFO - 2018-06-16 11:32:10 --> Helper loaded: permission_helper
INFO - 2018-06-16 11:32:10 --> Helper loaded: users_helper
DEBUG - 2018-06-16 11:32:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 11:32:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 11:32:10 --> Helper loaded: form_helper
INFO - 2018-06-16 11:32:10 --> Form Validation Class Initialized
INFO - 2018-06-16 11:32:10 --> Controller Class Initialized
INFO - 2018-06-16 11:32:10 --> Model Class Initialized
INFO - 2018-06-16 11:32:10 --> Helper loaded: inflector_helper
INFO - 2018-06-16 11:32:10 --> Database Driver Class Initialized
DEBUG - 2018-06-16 11:32:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 11:32:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 11:32:10 --> Model Class Initialized
INFO - 2018-06-16 11:32:10 --> Model Class Initialized
INFO - 2018-06-16 11:32:10 --> Model Class Initialized
INFO - 2018-06-16 11:32:10 --> Model Class Initialized
DEBUG - 2018-06-16 11:32:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 11:32:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 11:32:10 --> Final output sent to browser
DEBUG - 2018-06-16 11:32:10 --> Total execution time: 0.1417
INFO - 2018-06-16 11:32:10 --> Helper loaded: form_helper
INFO - 2018-06-16 11:32:10 --> Form Validation Class Initialized
INFO - 2018-06-16 11:32:10 --> Controller Class Initialized
INFO - 2018-06-16 11:32:10 --> Model Class Initialized
INFO - 2018-06-16 11:32:10 --> Helper loaded: inflector_helper
DEBUG - 2018-06-16 11:32:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 11:32:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 11:32:10 --> Model Class Initialized
INFO - 2018-06-16 11:32:10 --> Model Class Initialized
INFO - 2018-06-16 11:32:10 --> Model Class Initialized
INFO - 2018-06-16 11:32:10 --> Model Class Initialized
INFO - 2018-06-16 11:32:10 --> Final output sent to browser
DEBUG - 2018-06-16 11:32:10 --> Total execution time: 0.1772
INFO - 2018-06-16 06:02:13 --> Config Class Initialized
INFO - 2018-06-16 06:02:13 --> Hooks Class Initialized
DEBUG - 2018-06-16 06:02:13 --> UTF-8 Support Enabled
INFO - 2018-06-16 06:02:13 --> Utf8 Class Initialized
INFO - 2018-06-16 06:02:13 --> URI Class Initialized
INFO - 2018-06-16 06:02:13 --> Router Class Initialized
INFO - 2018-06-16 06:02:13 --> Output Class Initialized
INFO - 2018-06-16 06:02:13 --> Security Class Initialized
DEBUG - 2018-06-16 06:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 06:02:13 --> Input Class Initialized
INFO - 2018-06-16 06:02:13 --> Language Class Initialized
INFO - 2018-06-16 06:02:13 --> Language Class Initialized
INFO - 2018-06-16 06:02:13 --> Config Class Initialized
INFO - 2018-06-16 06:02:13 --> Loader Class Initialized
INFO - 2018-06-16 11:32:13 --> Helper loaded: url_helper
INFO - 2018-06-16 11:32:13 --> Helper loaded: notification_helper
INFO - 2018-06-16 11:32:13 --> Helper loaded: settings_helper
INFO - 2018-06-16 11:32:13 --> Helper loaded: permission_helper
INFO - 2018-06-16 11:32:13 --> Helper loaded: users_helper
INFO - 2018-06-16 11:32:13 --> Database Driver Class Initialized
DEBUG - 2018-06-16 11:32:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 11:32:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 11:32:13 --> Helper loaded: form_helper
INFO - 2018-06-16 11:32:13 --> Form Validation Class Initialized
INFO - 2018-06-16 11:32:13 --> Controller Class Initialized
INFO - 2018-06-16 11:32:13 --> Model Class Initialized
INFO - 2018-06-16 11:32:13 --> Helper loaded: inflector_helper
DEBUG - 2018-06-16 11:32:13 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 11:32:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 11:32:13 --> Model Class Initialized
INFO - 2018-06-16 11:32:13 --> Model Class Initialized
INFO - 2018-06-16 11:32:13 --> Model Class Initialized
INFO - 2018-06-16 11:32:13 --> Model Class Initialized
INFO - 2018-06-16 11:32:13 --> Final output sent to browser
DEBUG - 2018-06-16 11:32:13 --> Total execution time: 0.1056
INFO - 2018-06-16 06:02:18 --> Config Class Initialized
INFO - 2018-06-16 06:02:18 --> Hooks Class Initialized
DEBUG - 2018-06-16 06:02:18 --> UTF-8 Support Enabled
INFO - 2018-06-16 06:02:18 --> Utf8 Class Initialized
INFO - 2018-06-16 06:02:18 --> URI Class Initialized
INFO - 2018-06-16 06:02:18 --> Router Class Initialized
INFO - 2018-06-16 06:02:18 --> Output Class Initialized
INFO - 2018-06-16 06:02:18 --> Security Class Initialized
DEBUG - 2018-06-16 06:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 06:02:18 --> Input Class Initialized
INFO - 2018-06-16 06:02:18 --> Language Class Initialized
INFO - 2018-06-16 06:02:18 --> Language Class Initialized
INFO - 2018-06-16 06:02:18 --> Config Class Initialized
INFO - 2018-06-16 06:02:18 --> Loader Class Initialized
INFO - 2018-06-16 11:32:18 --> Helper loaded: url_helper
INFO - 2018-06-16 11:32:18 --> Helper loaded: notification_helper
INFO - 2018-06-16 11:32:18 --> Helper loaded: settings_helper
INFO - 2018-06-16 11:32:18 --> Helper loaded: permission_helper
INFO - 2018-06-16 11:32:18 --> Helper loaded: users_helper
INFO - 2018-06-16 11:32:18 --> Database Driver Class Initialized
DEBUG - 2018-06-16 11:32:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 11:32:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 11:32:18 --> Helper loaded: form_helper
INFO - 2018-06-16 11:32:18 --> Form Validation Class Initialized
INFO - 2018-06-16 11:32:18 --> Controller Class Initialized
INFO - 2018-06-16 11:32:18 --> Model Class Initialized
INFO - 2018-06-16 11:32:18 --> Helper loaded: inflector_helper
DEBUG - 2018-06-16 11:32:18 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 11:32:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 11:32:18 --> Model Class Initialized
INFO - 2018-06-16 11:32:18 --> Model Class Initialized
INFO - 2018-06-16 11:32:18 --> Model Class Initialized
INFO - 2018-06-16 11:32:18 --> Model Class Initialized
INFO - 2018-06-16 11:32:18 --> Final output sent to browser
DEBUG - 2018-06-16 11:32:18 --> Total execution time: 0.1018
INFO - 2018-06-16 06:02:20 --> Config Class Initialized
INFO - 2018-06-16 06:02:20 --> Hooks Class Initialized
DEBUG - 2018-06-16 06:02:20 --> UTF-8 Support Enabled
INFO - 2018-06-16 06:02:20 --> Utf8 Class Initialized
INFO - 2018-06-16 06:02:20 --> URI Class Initialized
INFO - 2018-06-16 06:02:20 --> Router Class Initialized
INFO - 2018-06-16 06:02:20 --> Output Class Initialized
INFO - 2018-06-16 06:02:20 --> Security Class Initialized
DEBUG - 2018-06-16 06:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 06:02:20 --> Input Class Initialized
INFO - 2018-06-16 06:02:20 --> Language Class Initialized
INFO - 2018-06-16 06:02:20 --> Language Class Initialized
INFO - 2018-06-16 06:02:20 --> Config Class Initialized
INFO - 2018-06-16 06:02:20 --> Loader Class Initialized
INFO - 2018-06-16 11:32:20 --> Helper loaded: url_helper
INFO - 2018-06-16 11:32:20 --> Helper loaded: notification_helper
INFO - 2018-06-16 11:32:20 --> Helper loaded: settings_helper
INFO - 2018-06-16 11:32:20 --> Helper loaded: permission_helper
INFO - 2018-06-16 11:32:20 --> Helper loaded: users_helper
INFO - 2018-06-16 11:32:20 --> Database Driver Class Initialized
DEBUG - 2018-06-16 11:32:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 11:32:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 11:32:20 --> Helper loaded: form_helper
INFO - 2018-06-16 11:32:20 --> Form Validation Class Initialized
INFO - 2018-06-16 11:32:20 --> Controller Class Initialized
INFO - 2018-06-16 11:32:20 --> Model Class Initialized
INFO - 2018-06-16 11:32:20 --> Helper loaded: inflector_helper
DEBUG - 2018-06-16 11:32:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 11:32:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 11:32:20 --> Model Class Initialized
INFO - 2018-06-16 11:32:20 --> Model Class Initialized
INFO - 2018-06-16 11:32:20 --> Model Class Initialized
INFO - 2018-06-16 11:32:20 --> Model Class Initialized
INFO - 2018-06-16 11:32:20 --> Model Class Initialized
INFO - 2018-06-16 11:32:20 --> Model Class Initialized
INFO - 2018-06-16 11:32:20 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-16 11:32:20 --> Final output sent to browser
DEBUG - 2018-06-16 11:32:20 --> Total execution time: 0.1302
INFO - 2018-06-16 06:02:21 --> Config Class Initialized
INFO - 2018-06-16 06:02:21 --> Hooks Class Initialized
DEBUG - 2018-06-16 06:02:21 --> UTF-8 Support Enabled
INFO - 2018-06-16 06:02:21 --> Utf8 Class Initialized
INFO - 2018-06-16 06:02:21 --> URI Class Initialized
INFO - 2018-06-16 06:02:21 --> Router Class Initialized
INFO - 2018-06-16 06:02:21 --> Output Class Initialized
INFO - 2018-06-16 06:02:21 --> Security Class Initialized
DEBUG - 2018-06-16 06:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 06:02:21 --> Input Class Initialized
INFO - 2018-06-16 06:02:21 --> Language Class Initialized
INFO - 2018-06-16 06:02:21 --> Config Class Initialized
INFO - 2018-06-16 06:02:21 --> Hooks Class Initialized
DEBUG - 2018-06-16 06:02:21 --> UTF-8 Support Enabled
INFO - 2018-06-16 06:02:21 --> Utf8 Class Initialized
INFO - 2018-06-16 06:02:21 --> URI Class Initialized
INFO - 2018-06-16 06:02:21 --> Router Class Initialized
INFO - 2018-06-16 06:02:21 --> Language Class Initialized
INFO - 2018-06-16 06:02:21 --> Config Class Initialized
INFO - 2018-06-16 06:02:21 --> Loader Class Initialized
INFO - 2018-06-16 06:02:21 --> Output Class Initialized
INFO - 2018-06-16 11:32:21 --> Helper loaded: url_helper
INFO - 2018-06-16 11:32:21 --> Helper loaded: notification_helper
INFO - 2018-06-16 11:32:21 --> Helper loaded: settings_helper
INFO - 2018-06-16 11:32:21 --> Helper loaded: permission_helper
INFO - 2018-06-16 06:02:21 --> Security Class Initialized
INFO - 2018-06-16 11:32:21 --> Helper loaded: users_helper
DEBUG - 2018-06-16 06:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 06:02:21 --> Input Class Initialized
INFO - 2018-06-16 06:02:21 --> Language Class Initialized
INFO - 2018-06-16 11:32:21 --> Database Driver Class Initialized
DEBUG - 2018-06-16 11:32:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 11:32:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 06:02:21 --> Language Class Initialized
INFO - 2018-06-16 11:32:21 --> Helper loaded: form_helper
INFO - 2018-06-16 06:02:21 --> Config Class Initialized
INFO - 2018-06-16 11:32:21 --> Form Validation Class Initialized
INFO - 2018-06-16 06:02:21 --> Loader Class Initialized
INFO - 2018-06-16 11:32:21 --> Controller Class Initialized
INFO - 2018-06-16 11:32:21 --> Helper loaded: url_helper
INFO - 2018-06-16 11:32:21 --> Helper loaded: notification_helper
INFO - 2018-06-16 11:32:21 --> Helper loaded: settings_helper
INFO - 2018-06-16 11:32:21 --> Helper loaded: permission_helper
INFO - 2018-06-16 11:32:21 --> Model Class Initialized
INFO - 2018-06-16 11:32:21 --> Helper loaded: inflector_helper
INFO - 2018-06-16 11:32:21 --> Helper loaded: users_helper
DEBUG - 2018-06-16 11:32:21 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 11:32:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 11:32:21 --> Model Class Initialized
INFO - 2018-06-16 11:32:21 --> Model Class Initialized
INFO - 2018-06-16 11:32:21 --> Model Class Initialized
INFO - 2018-06-16 11:32:21 --> Model Class Initialized
INFO - 2018-06-16 11:32:21 --> Model Class Initialized
INFO - 2018-06-16 11:32:21 --> Model Class Initialized
INFO - 2018-06-16 11:32:21 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-16 11:32:21 --> Final output sent to browser
DEBUG - 2018-06-16 11:32:21 --> Total execution time: 0.1072
INFO - 2018-06-16 11:32:21 --> Database Driver Class Initialized
DEBUG - 2018-06-16 11:32:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 11:32:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 11:32:21 --> Helper loaded: form_helper
INFO - 2018-06-16 11:32:21 --> Form Validation Class Initialized
INFO - 2018-06-16 11:32:21 --> Controller Class Initialized
INFO - 2018-06-16 11:32:21 --> Model Class Initialized
INFO - 2018-06-16 11:32:21 --> Helper loaded: inflector_helper
DEBUG - 2018-06-16 11:32:21 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 11:32:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 11:32:21 --> Model Class Initialized
INFO - 2018-06-16 11:32:21 --> Model Class Initialized
INFO - 2018-06-16 11:32:21 --> Model Class Initialized
INFO - 2018-06-16 11:32:21 --> Model Class Initialized
INFO - 2018-06-16 11:32:21 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-16 11:32:21 --> Final output sent to browser
DEBUG - 2018-06-16 11:32:21 --> Total execution time: 0.1582
INFO - 2018-06-16 06:02:25 --> Config Class Initialized
INFO - 2018-06-16 06:02:25 --> Hooks Class Initialized
DEBUG - 2018-06-16 06:02:25 --> UTF-8 Support Enabled
INFO - 2018-06-16 06:02:25 --> Utf8 Class Initialized
INFO - 2018-06-16 06:02:25 --> URI Class Initialized
INFO - 2018-06-16 06:02:25 --> Router Class Initialized
INFO - 2018-06-16 06:02:25 --> Output Class Initialized
INFO - 2018-06-16 06:02:25 --> Security Class Initialized
DEBUG - 2018-06-16 06:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 06:02:25 --> Input Class Initialized
INFO - 2018-06-16 06:02:25 --> Language Class Initialized
INFO - 2018-06-16 06:02:25 --> Config Class Initialized
INFO - 2018-06-16 06:02:25 --> Hooks Class Initialized
DEBUG - 2018-06-16 06:02:25 --> UTF-8 Support Enabled
INFO - 2018-06-16 06:02:25 --> Utf8 Class Initialized
INFO - 2018-06-16 06:02:25 --> URI Class Initialized
INFO - 2018-06-16 06:02:25 --> Language Class Initialized
INFO - 2018-06-16 06:02:25 --> Config Class Initialized
INFO - 2018-06-16 06:02:25 --> Loader Class Initialized
INFO - 2018-06-16 06:02:25 --> Config Class Initialized
INFO - 2018-06-16 06:02:25 --> Hooks Class Initialized
INFO - 2018-06-16 06:02:25 --> Router Class Initialized
INFO - 2018-06-16 11:32:25 --> Helper loaded: url_helper
DEBUG - 2018-06-16 06:02:25 --> UTF-8 Support Enabled
INFO - 2018-06-16 06:02:25 --> Utf8 Class Initialized
INFO - 2018-06-16 11:32:25 --> Helper loaded: notification_helper
INFO - 2018-06-16 11:32:25 --> Helper loaded: settings_helper
INFO - 2018-06-16 11:32:25 --> Helper loaded: permission_helper
INFO - 2018-06-16 06:02:25 --> URI Class Initialized
INFO - 2018-06-16 06:02:25 --> Output Class Initialized
INFO - 2018-06-16 11:32:25 --> Helper loaded: users_helper
INFO - 2018-06-16 06:02:25 --> Security Class Initialized
INFO - 2018-06-16 06:02:25 --> Router Class Initialized
DEBUG - 2018-06-16 06:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 06:02:25 --> Input Class Initialized
INFO - 2018-06-16 06:02:25 --> Language Class Initialized
INFO - 2018-06-16 06:02:25 --> Output Class Initialized
INFO - 2018-06-16 06:02:25 --> Security Class Initialized
DEBUG - 2018-06-16 06:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 06:02:25 --> Input Class Initialized
INFO - 2018-06-16 06:02:25 --> Language Class Initialized
INFO - 2018-06-16 11:32:26 --> Database Driver Class Initialized
DEBUG - 2018-06-16 11:32:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 11:32:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 06:02:26 --> Language Class Initialized
INFO - 2018-06-16 06:02:26 --> Config Class Initialized
INFO - 2018-06-16 06:02:26 --> Loader Class Initialized
INFO - 2018-06-16 11:32:26 --> Helper loaded: url_helper
INFO - 2018-06-16 06:02:26 --> Language Class Initialized
INFO - 2018-06-16 06:02:26 --> Config Class Initialized
INFO - 2018-06-16 06:02:26 --> Loader Class Initialized
INFO - 2018-06-16 11:32:26 --> Helper loaded: notification_helper
INFO - 2018-06-16 11:32:26 --> Helper loaded: settings_helper
INFO - 2018-06-16 11:32:26 --> Helper loaded: permission_helper
INFO - 2018-06-16 11:32:26 --> Helper loaded: url_helper
INFO - 2018-06-16 11:32:26 --> Helper loaded: users_helper
INFO - 2018-06-16 11:32:26 --> Helper loaded: form_helper
INFO - 2018-06-16 11:32:26 --> Helper loaded: notification_helper
INFO - 2018-06-16 11:32:26 --> Form Validation Class Initialized
INFO - 2018-06-16 11:32:26 --> Controller Class Initialized
INFO - 2018-06-16 11:32:26 --> Helper loaded: settings_helper
INFO - 2018-06-16 11:32:26 --> Helper loaded: permission_helper
INFO - 2018-06-16 11:32:26 --> Helper loaded: users_helper
INFO - 2018-06-16 11:32:26 --> Model Class Initialized
INFO - 2018-06-16 11:32:26 --> Helper loaded: inflector_helper
INFO - 2018-06-16 11:32:26 --> Database Driver Class Initialized
DEBUG - 2018-06-16 11:32:26 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 11:32:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 11:32:26 --> Database Driver Class Initialized
INFO - 2018-06-16 11:32:26 --> Model Class Initialized
INFO - 2018-06-16 11:32:26 --> Model Class Initialized
INFO - 2018-06-16 11:32:26 --> Model Class Initialized
INFO - 2018-06-16 11:32:26 --> Model Class Initialized
INFO - 2018-06-16 11:32:26 --> Model Class Initialized
INFO - 2018-06-16 11:32:26 --> Model Class Initialized
INFO - 2018-06-16 11:32:26 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-06-16 11:32:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 11:32:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 11:32:26 --> Final output sent to browser
DEBUG - 2018-06-16 11:32:26 --> Total execution time: 0.1182
DEBUG - 2018-06-16 11:32:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 11:32:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 11:32:26 --> Helper loaded: form_helper
INFO - 2018-06-16 11:32:26 --> Form Validation Class Initialized
INFO - 2018-06-16 11:32:26 --> Controller Class Initialized
INFO - 2018-06-16 11:32:26 --> Model Class Initialized
INFO - 2018-06-16 11:32:26 --> Helper loaded: inflector_helper
DEBUG - 2018-06-16 11:32:26 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 11:32:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 11:32:26 --> Model Class Initialized
INFO - 2018-06-16 11:32:26 --> Model Class Initialized
INFO - 2018-06-16 11:32:26 --> Model Class Initialized
INFO - 2018-06-16 11:32:26 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-16 11:32:26 --> Model Class Initialized
INFO - 2018-06-16 11:32:26 --> Model Class Initialized
INFO - 2018-06-16 11:32:26 --> Model Class Initialized
INFO - 2018-06-16 11:32:26 --> Helper loaded: form_helper
INFO - 2018-06-16 11:32:26 --> Form Validation Class Initialized
INFO - 2018-06-16 11:32:26 --> Controller Class Initialized
INFO - 2018-06-16 11:32:26 --> Final output sent to browser
DEBUG - 2018-06-16 11:32:26 --> Total execution time: 0.1130
INFO - 2018-06-16 11:32:26 --> Model Class Initialized
INFO - 2018-06-16 11:32:26 --> Helper loaded: inflector_helper
DEBUG - 2018-06-16 11:32:26 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 11:32:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 11:32:26 --> Model Class Initialized
INFO - 2018-06-16 11:32:26 --> Model Class Initialized
INFO - 2018-06-16 11:32:26 --> Model Class Initialized
INFO - 2018-06-16 11:32:26 --> Model Class Initialized
INFO - 2018-06-16 11:32:26 --> Model Class Initialized
INFO - 2018-06-16 11:32:26 --> Model Class Initialized
INFO - 2018-06-16 11:32:26 --> Model Class Initialized
INFO - 2018-06-16 11:32:26 --> Model Class Initialized
INFO - 2018-06-16 11:32:26 --> Model Class Initialized
INFO - 2018-06-16 11:32:26 --> Model Class Initialized
INFO - 2018-06-16 11:32:26 --> Model Class Initialized
INFO - 2018-06-16 11:32:26 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-16 11:32:26 --> Model Class Initialized
INFO - 2018-06-16 11:32:26 --> Final output sent to browser
DEBUG - 2018-06-16 11:32:26 --> Total execution time: 0.3043
INFO - 2018-06-16 06:02:30 --> Config Class Initialized
INFO - 2018-06-16 06:02:30 --> Hooks Class Initialized
DEBUG - 2018-06-16 06:02:30 --> UTF-8 Support Enabled
INFO - 2018-06-16 06:02:30 --> Utf8 Class Initialized
INFO - 2018-06-16 06:02:30 --> URI Class Initialized
INFO - 2018-06-16 06:02:30 --> Router Class Initialized
INFO - 2018-06-16 06:02:30 --> Output Class Initialized
INFO - 2018-06-16 06:02:30 --> Security Class Initialized
DEBUG - 2018-06-16 06:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 06:02:30 --> Input Class Initialized
INFO - 2018-06-16 06:02:30 --> Language Class Initialized
INFO - 2018-06-16 06:02:30 --> Language Class Initialized
INFO - 2018-06-16 06:02:30 --> Config Class Initialized
INFO - 2018-06-16 06:02:30 --> Loader Class Initialized
INFO - 2018-06-16 11:32:30 --> Helper loaded: url_helper
INFO - 2018-06-16 11:32:30 --> Helper loaded: notification_helper
INFO - 2018-06-16 11:32:30 --> Helper loaded: settings_helper
INFO - 2018-06-16 11:32:30 --> Helper loaded: permission_helper
INFO - 2018-06-16 11:32:30 --> Helper loaded: users_helper
INFO - 2018-06-16 11:32:30 --> Database Driver Class Initialized
DEBUG - 2018-06-16 11:32:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 11:32:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 11:32:30 --> Helper loaded: form_helper
INFO - 2018-06-16 11:32:30 --> Form Validation Class Initialized
INFO - 2018-06-16 11:32:30 --> Controller Class Initialized
INFO - 2018-06-16 11:32:30 --> Model Class Initialized
INFO - 2018-06-16 11:32:30 --> Helper loaded: inflector_helper
DEBUG - 2018-06-16 11:32:30 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 11:32:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 11:32:30 --> Model Class Initialized
INFO - 2018-06-16 11:32:30 --> Model Class Initialized
INFO - 2018-06-16 11:32:30 --> Model Class Initialized
INFO - 2018-06-16 11:32:30 --> Model Class Initialized
INFO - 2018-06-16 11:32:30 --> Model Class Initialized
INFO - 2018-06-16 11:32:30 --> Model Class Initialized
INFO - 2018-06-16 11:32:30 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-16 11:32:30 --> Model Class Initialized
INFO - 2018-06-16 11:32:30 --> Model Class Initialized
ERROR - 2018-06-16 11:32:30 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 796
INFO - 2018-06-16 11:32:30 --> Final output sent to browser
DEBUG - 2018-06-16 11:32:30 --> Total execution time: 0.1258
INFO - 2018-06-16 06:02:37 --> Config Class Initialized
INFO - 2018-06-16 06:02:37 --> Hooks Class Initialized
INFO - 2018-06-16 06:02:37 --> Config Class Initialized
INFO - 2018-06-16 06:02:37 --> Hooks Class Initialized
DEBUG - 2018-06-16 06:02:37 --> UTF-8 Support Enabled
INFO - 2018-06-16 06:02:37 --> Utf8 Class Initialized
DEBUG - 2018-06-16 06:02:37 --> UTF-8 Support Enabled
INFO - 2018-06-16 06:02:37 --> Utf8 Class Initialized
INFO - 2018-06-16 06:02:37 --> URI Class Initialized
INFO - 2018-06-16 06:02:37 --> URI Class Initialized
INFO - 2018-06-16 06:02:37 --> Router Class Initialized
INFO - 2018-06-16 06:02:37 --> Router Class Initialized
INFO - 2018-06-16 06:02:37 --> Output Class Initialized
INFO - 2018-06-16 06:02:37 --> Output Class Initialized
INFO - 2018-06-16 06:02:37 --> Security Class Initialized
INFO - 2018-06-16 06:02:37 --> Security Class Initialized
INFO - 2018-06-16 06:02:37 --> Config Class Initialized
INFO - 2018-06-16 06:02:37 --> Hooks Class Initialized
DEBUG - 2018-06-16 06:02:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-06-16 06:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 06:02:37 --> Input Class Initialized
INFO - 2018-06-16 06:02:37 --> Input Class Initialized
INFO - 2018-06-16 06:02:37 --> Language Class Initialized
INFO - 2018-06-16 06:02:37 --> Language Class Initialized
DEBUG - 2018-06-16 06:02:37 --> UTF-8 Support Enabled
INFO - 2018-06-16 06:02:37 --> Utf8 Class Initialized
INFO - 2018-06-16 06:02:37 --> URI Class Initialized
INFO - 2018-06-16 06:02:37 --> Router Class Initialized
INFO - 2018-06-16 06:02:37 --> Output Class Initialized
INFO - 2018-06-16 06:02:37 --> Security Class Initialized
DEBUG - 2018-06-16 06:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 06:02:37 --> Input Class Initialized
INFO - 2018-06-16 06:02:37 --> Language Class Initialized
INFO - 2018-06-16 06:02:37 --> Language Class Initialized
INFO - 2018-06-16 06:02:37 --> Config Class Initialized
INFO - 2018-06-16 06:02:37 --> Loader Class Initialized
INFO - 2018-06-16 11:32:37 --> Helper loaded: url_helper
INFO - 2018-06-16 11:32:37 --> Helper loaded: notification_helper
INFO - 2018-06-16 11:32:37 --> Helper loaded: settings_helper
INFO - 2018-06-16 11:32:37 --> Helper loaded: permission_helper
INFO - 2018-06-16 06:02:37 --> Language Class Initialized
INFO - 2018-06-16 06:02:37 --> Config Class Initialized
INFO - 2018-06-16 06:02:37 --> Loader Class Initialized
INFO - 2018-06-16 11:32:37 --> Helper loaded: users_helper
INFO - 2018-06-16 11:32:37 --> Helper loaded: url_helper
INFO - 2018-06-16 11:32:37 --> Helper loaded: notification_helper
INFO - 2018-06-16 06:02:37 --> Language Class Initialized
INFO - 2018-06-16 06:02:37 --> Config Class Initialized
INFO - 2018-06-16 06:02:37 --> Loader Class Initialized
INFO - 2018-06-16 11:32:37 --> Helper loaded: settings_helper
INFO - 2018-06-16 11:32:37 --> Helper loaded: permission_helper
INFO - 2018-06-16 11:32:37 --> Helper loaded: url_helper
INFO - 2018-06-16 11:32:37 --> Helper loaded: notification_helper
INFO - 2018-06-16 11:32:37 --> Helper loaded: settings_helper
INFO - 2018-06-16 11:32:37 --> Helper loaded: permission_helper
INFO - 2018-06-16 11:32:37 --> Database Driver Class Initialized
INFO - 2018-06-16 11:32:37 --> Helper loaded: users_helper
INFO - 2018-06-16 11:32:37 --> Helper loaded: users_helper
DEBUG - 2018-06-16 11:32:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 11:32:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 11:32:37 --> Helper loaded: form_helper
INFO - 2018-06-16 11:32:37 --> Form Validation Class Initialized
INFO - 2018-06-16 11:32:37 --> Controller Class Initialized
INFO - 2018-06-16 11:32:37 --> Database Driver Class Initialized
INFO - 2018-06-16 11:32:37 --> Database Driver Class Initialized
DEBUG - 2018-06-16 11:32:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 11:32:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 11:32:37 --> Model Class Initialized
INFO - 2018-06-16 11:32:37 --> Helper loaded: inflector_helper
DEBUG - 2018-06-16 11:32:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 11:32:37 --> Helper loaded: form_helper
INFO - 2018-06-16 11:32:37 --> Form Validation Class Initialized
INFO - 2018-06-16 11:32:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 11:32:37 --> Controller Class Initialized
DEBUG - 2018-06-16 11:32:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 11:32:37 --> Model Class Initialized
INFO - 2018-06-16 11:32:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 11:32:37 --> Model Class Initialized
INFO - 2018-06-16 11:32:37 --> Model Class Initialized
INFO - 2018-06-16 11:32:37 --> Model Class Initialized
INFO - 2018-06-16 11:32:37 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-16 11:32:37 --> Model Class Initialized
INFO - 2018-06-16 11:32:37 --> Final output sent to browser
DEBUG - 2018-06-16 11:32:37 --> Total execution time: 0.1163
INFO - 2018-06-16 11:32:37 --> Model Class Initialized
INFO - 2018-06-16 11:32:37 --> Helper loaded: inflector_helper
INFO - 2018-06-16 11:32:37 --> Helper loaded: form_helper
INFO - 2018-06-16 11:32:37 --> Form Validation Class Initialized
INFO - 2018-06-16 11:32:37 --> Controller Class Initialized
DEBUG - 2018-06-16 11:32:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 11:32:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 11:32:37 --> Model Class Initialized
INFO - 2018-06-16 11:32:37 --> Model Class Initialized
INFO - 2018-06-16 11:32:37 --> Model Class Initialized
INFO - 2018-06-16 11:32:37 --> Model Class Initialized
INFO - 2018-06-16 11:32:37 --> Model Class Initialized
INFO - 2018-06-16 11:32:37 --> Model Class Initialized
INFO - 2018-06-16 11:32:37 --> Model Class Initialized
INFO - 2018-06-16 11:32:37 --> Model Class Initialized
INFO - 2018-06-16 11:32:37 --> Model Class Initialized
INFO - 2018-06-16 11:32:37 --> Model Class Initialized
INFO - 2018-06-16 11:32:37 --> Model Class Initialized
INFO - 2018-06-16 11:32:37 --> Helper loaded: inflector_helper
INFO - 2018-06-16 11:32:37 --> Model Class Initialized
INFO - 2018-06-16 11:32:37 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-16 11:32:37 --> Model Class Initialized
DEBUG - 2018-06-16 11:32:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 11:32:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 11:32:37 --> Model Class Initialized
INFO - 2018-06-16 11:32:37 --> Model Class Initialized
INFO - 2018-06-16 11:32:37 --> Model Class Initialized
INFO - 2018-06-16 11:32:37 --> Model Class Initialized
INFO - 2018-06-16 11:32:37 --> Model Class Initialized
INFO - 2018-06-16 11:32:37 --> Model Class Initialized
INFO - 2018-06-16 11:32:37 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-16 11:32:37 --> Model Class Initialized
INFO - 2018-06-16 11:32:37 --> Final output sent to browser
DEBUG - 2018-06-16 11:32:37 --> Total execution time: 0.1579
INFO - 2018-06-16 11:32:37 --> Final output sent to browser
DEBUG - 2018-06-16 11:32:37 --> Total execution time: 0.1556
INFO - 2018-06-16 06:02:38 --> Config Class Initialized
INFO - 2018-06-16 06:02:38 --> Hooks Class Initialized
DEBUG - 2018-06-16 06:02:38 --> UTF-8 Support Enabled
INFO - 2018-06-16 06:02:38 --> Utf8 Class Initialized
INFO - 2018-06-16 06:02:38 --> URI Class Initialized
INFO - 2018-06-16 06:02:38 --> Router Class Initialized
INFO - 2018-06-16 06:02:38 --> Output Class Initialized
INFO - 2018-06-16 06:02:38 --> Config Class Initialized
INFO - 2018-06-16 06:02:38 --> Hooks Class Initialized
INFO - 2018-06-16 06:02:38 --> Security Class Initialized
DEBUG - 2018-06-16 06:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 06:02:38 --> Input Class Initialized
DEBUG - 2018-06-16 06:02:38 --> UTF-8 Support Enabled
INFO - 2018-06-16 06:02:38 --> Utf8 Class Initialized
INFO - 2018-06-16 06:02:38 --> Language Class Initialized
INFO - 2018-06-16 06:02:38 --> URI Class Initialized
INFO - 2018-06-16 06:02:38 --> Router Class Initialized
INFO - 2018-06-16 06:02:38 --> Output Class Initialized
INFO - 2018-06-16 06:02:38 --> Security Class Initialized
DEBUG - 2018-06-16 06:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 06:02:38 --> Input Class Initialized
INFO - 2018-06-16 06:02:38 --> Language Class Initialized
INFO - 2018-06-16 06:02:38 --> Language Class Initialized
INFO - 2018-06-16 06:02:38 --> Config Class Initialized
INFO - 2018-06-16 06:02:38 --> Loader Class Initialized
INFO - 2018-06-16 11:32:38 --> Helper loaded: url_helper
INFO - 2018-06-16 11:32:38 --> Helper loaded: notification_helper
INFO - 2018-06-16 11:32:38 --> Helper loaded: settings_helper
INFO - 2018-06-16 11:32:38 --> Helper loaded: permission_helper
INFO - 2018-06-16 11:32:38 --> Helper loaded: users_helper
INFO - 2018-06-16 06:02:38 --> Language Class Initialized
INFO - 2018-06-16 06:02:38 --> Config Class Initialized
INFO - 2018-06-16 06:02:38 --> Loader Class Initialized
INFO - 2018-06-16 11:32:38 --> Database Driver Class Initialized
INFO - 2018-06-16 11:32:38 --> Helper loaded: url_helper
INFO - 2018-06-16 11:32:38 --> Helper loaded: notification_helper
INFO - 2018-06-16 11:32:38 --> Helper loaded: settings_helper
INFO - 2018-06-16 11:32:38 --> Helper loaded: permission_helper
DEBUG - 2018-06-16 11:32:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 11:32:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 11:32:38 --> Helper loaded: users_helper
INFO - 2018-06-16 11:32:38 --> Helper loaded: form_helper
INFO - 2018-06-16 11:32:38 --> Form Validation Class Initialized
INFO - 2018-06-16 11:32:38 --> Controller Class Initialized
INFO - 2018-06-16 11:32:38 --> Database Driver Class Initialized
INFO - 2018-06-16 11:32:38 --> Model Class Initialized
INFO - 2018-06-16 11:32:38 --> Helper loaded: inflector_helper
DEBUG - 2018-06-16 11:32:38 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-06-16 11:32:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 11:32:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 11:32:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 11:32:38 --> Model Class Initialized
INFO - 2018-06-16 11:32:38 --> Model Class Initialized
INFO - 2018-06-16 11:32:38 --> Model Class Initialized
INFO - 2018-06-16 11:32:38 --> Model Class Initialized
INFO - 2018-06-16 11:32:38 --> Model Class Initialized
INFO - 2018-06-16 11:32:38 --> Model Class Initialized
INFO - 2018-06-16 11:32:38 --> Model Class Initialized
INFO - 2018-06-16 11:32:38 --> Model Class Initialized
INFO - 2018-06-16 11:32:38 --> Model Class Initialized
INFO - 2018-06-16 11:32:38 --> Model Class Initialized
INFO - 2018-06-16 11:32:38 --> Helper loaded: form_helper
INFO - 2018-06-16 11:32:38 --> Form Validation Class Initialized
INFO - 2018-06-16 11:32:38 --> Controller Class Initialized
INFO - 2018-06-16 11:32:38 --> Model Class Initialized
INFO - 2018-06-16 11:32:38 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-16 11:32:38 --> Model Class Initialized
INFO - 2018-06-16 11:32:38 --> Model Class Initialized
INFO - 2018-06-16 11:32:38 --> Helper loaded: inflector_helper
DEBUG - 2018-06-16 11:32:38 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 11:32:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 11:32:38 --> Model Class Initialized
INFO - 2018-06-16 11:32:38 --> Model Class Initialized
INFO - 2018-06-16 11:32:38 --> Model Class Initialized
INFO - 2018-06-16 11:32:38 --> Model Class Initialized
INFO - 2018-06-16 11:32:38 --> Model Class Initialized
INFO - 2018-06-16 11:32:38 --> Model Class Initialized
INFO - 2018-06-16 11:32:38 --> Model Class Initialized
INFO - 2018-06-16 11:32:38 --> Model Class Initialized
INFO - 2018-06-16 11:32:38 --> Model Class Initialized
INFO - 2018-06-16 11:32:38 --> Model Class Initialized
INFO - 2018-06-16 11:32:38 --> Model Class Initialized
INFO - 2018-06-16 11:32:38 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-16 11:32:38 --> Model Class Initialized
INFO - 2018-06-16 11:32:38 --> Final output sent to browser
DEBUG - 2018-06-16 11:32:38 --> Total execution time: 0.1440
INFO - 2018-06-16 11:32:38 --> Final output sent to browser
DEBUG - 2018-06-16 11:32:38 --> Total execution time: 0.1567
INFO - 2018-06-16 06:02:44 --> Config Class Initialized
INFO - 2018-06-16 06:02:44 --> Hooks Class Initialized
DEBUG - 2018-06-16 06:02:44 --> UTF-8 Support Enabled
INFO - 2018-06-16 06:02:44 --> Utf8 Class Initialized
INFO - 2018-06-16 06:02:44 --> URI Class Initialized
INFO - 2018-06-16 06:02:44 --> Router Class Initialized
INFO - 2018-06-16 06:02:44 --> Output Class Initialized
INFO - 2018-06-16 06:02:44 --> Security Class Initialized
DEBUG - 2018-06-16 06:02:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 06:02:44 --> Input Class Initialized
INFO - 2018-06-16 06:02:44 --> Language Class Initialized
INFO - 2018-06-16 06:02:44 --> Language Class Initialized
INFO - 2018-06-16 06:02:44 --> Config Class Initialized
INFO - 2018-06-16 06:02:44 --> Loader Class Initialized
INFO - 2018-06-16 11:32:44 --> Helper loaded: url_helper
INFO - 2018-06-16 11:32:44 --> Helper loaded: notification_helper
INFO - 2018-06-16 11:32:44 --> Helper loaded: settings_helper
INFO - 2018-06-16 11:32:44 --> Helper loaded: permission_helper
INFO - 2018-06-16 11:32:44 --> Helper loaded: users_helper
INFO - 2018-06-16 11:32:44 --> Database Driver Class Initialized
DEBUG - 2018-06-16 11:32:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 11:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 11:32:44 --> Helper loaded: form_helper
INFO - 2018-06-16 11:32:44 --> Form Validation Class Initialized
INFO - 2018-06-16 11:32:44 --> Controller Class Initialized
INFO - 2018-06-16 11:32:44 --> Model Class Initialized
INFO - 2018-06-16 11:32:44 --> Helper loaded: inflector_helper
DEBUG - 2018-06-16 11:32:44 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-16 11:32:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-16 11:32:44 --> Model Class Initialized
INFO - 2018-06-16 11:32:44 --> Model Class Initialized
INFO - 2018-06-16 11:32:44 --> Model Class Initialized
INFO - 2018-06-16 11:32:44 --> Model Class Initialized
INFO - 2018-06-16 11:32:44 --> Model Class Initialized
INFO - 2018-06-16 11:32:44 --> Model Class Initialized
INFO - 2018-06-16 11:32:44 --> Model Class Initialized
INFO - 2018-06-16 11:32:44 --> Model Class Initialized
INFO - 2018-06-16 11:32:44 --> Model Class Initialized
INFO - 2018-06-16 11:32:44 --> Model Class Initialized
INFO - 2018-06-16 11:32:44 --> Model Class Initialized
INFO - 2018-06-16 11:32:44 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-16 11:32:44 --> Model Class Initialized
INFO - 2018-06-16 11:32:44 --> Final output sent to browser
DEBUG - 2018-06-16 11:32:44 --> Total execution time: 0.1943
INFO - 2018-06-16 18:30:01 --> Config Class Initialized
INFO - 2018-06-16 18:30:01 --> Hooks Class Initialized
DEBUG - 2018-06-16 18:30:01 --> UTF-8 Support Enabled
INFO - 2018-06-16 18:30:01 --> Utf8 Class Initialized
INFO - 2018-06-16 18:30:01 --> URI Class Initialized
INFO - 2018-06-16 18:30:01 --> Router Class Initialized
INFO - 2018-06-16 18:30:01 --> Output Class Initialized
INFO - 2018-06-16 18:30:01 --> Security Class Initialized
DEBUG - 2018-06-16 18:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 18:30:01 --> Input Class Initialized
INFO - 2018-06-16 18:30:01 --> Language Class Initialized
INFO - 2018-06-16 18:30:01 --> Language Class Initialized
INFO - 2018-06-16 18:30:01 --> Config Class Initialized
INFO - 2018-06-16 18:30:01 --> Loader Class Initialized
INFO - 2018-06-16 18:30:01 --> Config Class Initialized
INFO - 2018-06-16 18:30:01 --> Hooks Class Initialized
DEBUG - 2018-06-16 18:30:01 --> UTF-8 Support Enabled
INFO - 2018-06-16 18:30:01 --> Utf8 Class Initialized
INFO - 2018-06-16 18:30:01 --> URI Class Initialized
INFO - 2018-06-16 18:30:01 --> Router Class Initialized
INFO - 2018-06-16 18:30:01 --> Output Class Initialized
INFO - 2018-06-16 18:30:01 --> Security Class Initialized
DEBUG - 2018-06-16 18:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 18:30:01 --> Input Class Initialized
INFO - 2018-06-16 18:30:01 --> Language Class Initialized
INFO - 2018-06-16 18:30:01 --> Language Class Initialized
INFO - 2018-06-16 18:30:01 --> Config Class Initialized
INFO - 2018-06-16 18:30:01 --> Loader Class Initialized
