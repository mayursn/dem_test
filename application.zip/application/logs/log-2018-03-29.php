<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-03-29 05:30:18 --> Config Class Initialized
INFO - 2018-03-29 05:30:18 --> Hooks Class Initialized
DEBUG - 2018-03-29 05:30:18 --> UTF-8 Support Enabled
INFO - 2018-03-29 05:30:18 --> Utf8 Class Initialized
INFO - 2018-03-29 05:30:18 --> URI Class Initialized
INFO - 2018-03-29 05:30:18 --> Router Class Initialized
INFO - 2018-03-29 05:30:18 --> Output Class Initialized
INFO - 2018-03-29 05:30:18 --> Security Class Initialized
DEBUG - 2018-03-29 05:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 05:30:18 --> Input Class Initialized
INFO - 2018-03-29 05:30:18 --> Language Class Initialized
INFO - 2018-03-29 05:30:18 --> Language Class Initialized
INFO - 2018-03-29 05:30:18 --> Config Class Initialized
INFO - 2018-03-29 05:30:18 --> Loader Class Initialized
INFO - 2018-03-29 11:00:18 --> Helper loaded: url_helper
INFO - 2018-03-29 11:00:18 --> Helper loaded: notification_helper
INFO - 2018-03-29 11:00:18 --> Helper loaded: settings_helper
INFO - 2018-03-29 11:00:18 --> Helper loaded: permission_helper
INFO - 2018-03-29 11:00:18 --> Helper loaded: users_helper
INFO - 2018-03-29 11:00:18 --> Database Driver Class Initialized
DEBUG - 2018-03-29 11:00:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 11:00:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 11:00:18 --> Helper loaded: form_helper
INFO - 2018-03-29 11:00:18 --> Form Validation Class Initialized
INFO - 2018-03-29 11:00:18 --> Controller Class Initialized
INFO - 2018-03-29 11:00:18 --> Model Class Initialized
INFO - 2018-03-29 11:00:18 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 11:00:18 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 11:00:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 11:00:18 --> Model Class Initialized
INFO - 2018-03-29 11:00:18 --> Model Class Initialized
INFO - 2018-03-29 11:00:18 --> Model Class Initialized
INFO - 2018-03-29 11:00:18 --> Model Class Initialized
INFO - 2018-03-29 11:00:18 --> Model Class Initialized
INFO - 2018-03-29 11:00:18 --> Model Class Initialized
INFO - 2018-03-29 11:00:18 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 11:00:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-29 11:00:18 --> Final output sent to browser
DEBUG - 2018-03-29 11:00:18 --> Total execution time: 0.1855
INFO - 2018-03-29 05:30:20 --> Config Class Initialized
INFO - 2018-03-29 05:30:20 --> Hooks Class Initialized
DEBUG - 2018-03-29 05:30:20 --> UTF-8 Support Enabled
INFO - 2018-03-29 05:30:20 --> Utf8 Class Initialized
INFO - 2018-03-29 05:30:20 --> URI Class Initialized
INFO - 2018-03-29 05:30:20 --> Router Class Initialized
INFO - 2018-03-29 05:30:20 --> Output Class Initialized
INFO - 2018-03-29 05:30:20 --> Security Class Initialized
DEBUG - 2018-03-29 05:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 05:30:20 --> Input Class Initialized
INFO - 2018-03-29 05:30:20 --> Language Class Initialized
INFO - 2018-03-29 05:30:20 --> Language Class Initialized
INFO - 2018-03-29 05:30:20 --> Config Class Initialized
INFO - 2018-03-29 05:30:20 --> Loader Class Initialized
INFO - 2018-03-29 11:00:20 --> Helper loaded: url_helper
INFO - 2018-03-29 11:00:20 --> Helper loaded: notification_helper
INFO - 2018-03-29 11:00:20 --> Helper loaded: settings_helper
INFO - 2018-03-29 11:00:20 --> Helper loaded: permission_helper
INFO - 2018-03-29 11:00:20 --> Helper loaded: users_helper
INFO - 2018-03-29 11:00:20 --> Database Driver Class Initialized
DEBUG - 2018-03-29 11:00:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 11:00:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 11:00:20 --> Helper loaded: form_helper
INFO - 2018-03-29 11:00:20 --> Form Validation Class Initialized
INFO - 2018-03-29 11:00:20 --> Controller Class Initialized
INFO - 2018-03-29 11:00:20 --> Model Class Initialized
INFO - 2018-03-29 11:00:20 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 11:00:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 11:00:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 11:00:20 --> Model Class Initialized
INFO - 2018-03-29 11:00:20 --> Model Class Initialized
INFO - 2018-03-29 11:00:20 --> Model Class Initialized
INFO - 2018-03-29 11:00:20 --> Model Class Initialized
INFO - 2018-03-29 11:00:20 --> Model Class Initialized
INFO - 2018-03-29 11:00:20 --> Model Class Initialized
INFO - 2018-03-29 11:00:20 --> Model Class Initialized
INFO - 2018-03-29 11:00:20 --> Model Class Initialized
INFO - 2018-03-29 11:00:20 --> Model Class Initialized
INFO - 2018-03-29 11:00:20 --> Model Class Initialized
INFO - 2018-03-29 11:00:20 --> Model Class Initialized
INFO - 2018-03-29 11:00:20 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 11:00:20 --> Model Class Initialized
INFO - 2018-03-29 11:00:20 --> Final output sent to browser
DEBUG - 2018-03-29 11:00:20 --> Total execution time: 0.1485
INFO - 2018-03-29 05:30:20 --> Config Class Initialized
INFO - 2018-03-29 05:30:20 --> Hooks Class Initialized
DEBUG - 2018-03-29 05:30:20 --> UTF-8 Support Enabled
INFO - 2018-03-29 05:30:20 --> Utf8 Class Initialized
INFO - 2018-03-29 05:30:20 --> URI Class Initialized
INFO - 2018-03-29 05:30:20 --> Router Class Initialized
INFO - 2018-03-29 05:30:20 --> Output Class Initialized
INFO - 2018-03-29 05:30:20 --> Security Class Initialized
DEBUG - 2018-03-29 05:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 05:30:20 --> Input Class Initialized
INFO - 2018-03-29 05:30:20 --> Language Class Initialized
INFO - 2018-03-29 05:30:20 --> Language Class Initialized
INFO - 2018-03-29 05:30:20 --> Config Class Initialized
INFO - 2018-03-29 05:30:20 --> Loader Class Initialized
INFO - 2018-03-29 11:00:20 --> Helper loaded: url_helper
INFO - 2018-03-29 11:00:20 --> Helper loaded: notification_helper
INFO - 2018-03-29 11:00:20 --> Helper loaded: settings_helper
INFO - 2018-03-29 11:00:20 --> Helper loaded: permission_helper
INFO - 2018-03-29 11:00:20 --> Helper loaded: users_helper
INFO - 2018-03-29 11:00:20 --> Database Driver Class Initialized
DEBUG - 2018-03-29 11:00:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 11:00:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 11:00:20 --> Helper loaded: form_helper
INFO - 2018-03-29 11:00:20 --> Form Validation Class Initialized
INFO - 2018-03-29 11:00:20 --> Controller Class Initialized
INFO - 2018-03-29 11:00:20 --> Model Class Initialized
INFO - 2018-03-29 11:00:20 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 11:00:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 11:00:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 11:00:20 --> Model Class Initialized
INFO - 2018-03-29 11:00:20 --> Model Class Initialized
INFO - 2018-03-29 11:00:20 --> Model Class Initialized
INFO - 2018-03-29 11:00:20 --> Model Class Initialized
INFO - 2018-03-29 11:00:20 --> Model Class Initialized
INFO - 2018-03-29 11:00:20 --> Model Class Initialized
INFO - 2018-03-29 11:00:20 --> Model Class Initialized
INFO - 2018-03-29 11:00:20 --> Model Class Initialized
INFO - 2018-03-29 11:00:20 --> Model Class Initialized
INFO - 2018-03-29 11:00:20 --> Model Class Initialized
INFO - 2018-03-29 11:00:20 --> Model Class Initialized
INFO - 2018-03-29 11:00:20 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 11:00:20 --> Model Class Initialized
INFO - 2018-03-29 11:00:20 --> Final output sent to browser
DEBUG - 2018-03-29 11:00:20 --> Total execution time: 0.1218
INFO - 2018-03-29 05:30:23 --> Config Class Initialized
INFO - 2018-03-29 05:30:23 --> Hooks Class Initialized
DEBUG - 2018-03-29 05:30:23 --> UTF-8 Support Enabled
INFO - 2018-03-29 05:30:23 --> Utf8 Class Initialized
INFO - 2018-03-29 05:30:23 --> URI Class Initialized
INFO - 2018-03-29 05:30:23 --> Router Class Initialized
INFO - 2018-03-29 05:30:23 --> Output Class Initialized
INFO - 2018-03-29 05:30:23 --> Security Class Initialized
DEBUG - 2018-03-29 05:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 05:30:23 --> Input Class Initialized
INFO - 2018-03-29 05:30:23 --> Language Class Initialized
INFO - 2018-03-29 05:30:23 --> Language Class Initialized
INFO - 2018-03-29 05:30:23 --> Config Class Initialized
INFO - 2018-03-29 05:30:23 --> Loader Class Initialized
INFO - 2018-03-29 11:00:23 --> Helper loaded: url_helper
INFO - 2018-03-29 11:00:23 --> Helper loaded: notification_helper
INFO - 2018-03-29 11:00:23 --> Helper loaded: settings_helper
INFO - 2018-03-29 11:00:23 --> Helper loaded: permission_helper
INFO - 2018-03-29 11:00:23 --> Helper loaded: users_helper
INFO - 2018-03-29 11:00:23 --> Database Driver Class Initialized
DEBUG - 2018-03-29 11:00:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 11:00:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 11:00:23 --> Helper loaded: form_helper
INFO - 2018-03-29 11:00:23 --> Form Validation Class Initialized
INFO - 2018-03-29 11:00:23 --> Controller Class Initialized
INFO - 2018-03-29 05:30:23 --> Config Class Initialized
INFO - 2018-03-29 05:30:23 --> Hooks Class Initialized
DEBUG - 2018-03-29 05:30:23 --> UTF-8 Support Enabled
INFO - 2018-03-29 05:30:23 --> Utf8 Class Initialized
INFO - 2018-03-29 05:30:23 --> URI Class Initialized
INFO - 2018-03-29 11:00:23 --> Model Class Initialized
INFO - 2018-03-29 11:00:23 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 11:00:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 05:30:23 --> Router Class Initialized
INFO - 2018-03-29 11:00:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 11:00:23 --> Model Class Initialized
INFO - 2018-03-29 11:00:23 --> Model Class Initialized
INFO - 2018-03-29 05:30:23 --> Output Class Initialized
INFO - 2018-03-29 11:00:23 --> Model Class Initialized
INFO - 2018-03-29 11:00:23 --> Model Class Initialized
INFO - 2018-03-29 11:00:23 --> Model Class Initialized
INFO - 2018-03-29 11:00:23 --> Model Class Initialized
INFO - 2018-03-29 11:00:23 --> Model Class Initialized
INFO - 2018-03-29 11:00:23 --> Model Class Initialized
INFO - 2018-03-29 05:30:23 --> Security Class Initialized
INFO - 2018-03-29 11:00:23 --> Model Class Initialized
INFO - 2018-03-29 11:00:23 --> Model Class Initialized
DEBUG - 2018-03-29 05:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 05:30:23 --> Input Class Initialized
INFO - 2018-03-29 11:00:23 --> Model Class Initialized
INFO - 2018-03-29 11:00:23 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 05:30:23 --> Language Class Initialized
INFO - 2018-03-29 11:00:23 --> Model Class Initialized
INFO - 2018-03-29 11:00:23 --> Final output sent to browser
DEBUG - 2018-03-29 11:00:23 --> Total execution time: 0.1266
INFO - 2018-03-29 05:30:23 --> Language Class Initialized
INFO - 2018-03-29 05:30:23 --> Config Class Initialized
INFO - 2018-03-29 05:30:23 --> Loader Class Initialized
INFO - 2018-03-29 11:00:23 --> Helper loaded: url_helper
INFO - 2018-03-29 11:00:23 --> Helper loaded: notification_helper
INFO - 2018-03-29 11:00:23 --> Helper loaded: settings_helper
INFO - 2018-03-29 11:00:23 --> Helper loaded: permission_helper
INFO - 2018-03-29 11:00:23 --> Helper loaded: users_helper
INFO - 2018-03-29 11:00:23 --> Database Driver Class Initialized
DEBUG - 2018-03-29 11:00:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 11:00:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 11:00:23 --> Helper loaded: form_helper
INFO - 2018-03-29 11:00:23 --> Form Validation Class Initialized
INFO - 2018-03-29 11:00:23 --> Controller Class Initialized
INFO - 2018-03-29 11:00:23 --> Model Class Initialized
INFO - 2018-03-29 11:00:23 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 11:00:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 11:00:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 11:00:23 --> Model Class Initialized
INFO - 2018-03-29 11:00:23 --> Model Class Initialized
INFO - 2018-03-29 11:00:23 --> Model Class Initialized
INFO - 2018-03-29 11:00:23 --> Model Class Initialized
INFO - 2018-03-29 11:00:23 --> Model Class Initialized
INFO - 2018-03-29 11:00:23 --> Model Class Initialized
INFO - 2018-03-29 11:00:23 --> Model Class Initialized
INFO - 2018-03-29 11:00:23 --> Model Class Initialized
INFO - 2018-03-29 11:00:23 --> Model Class Initialized
INFO - 2018-03-29 11:00:23 --> Model Class Initialized
INFO - 2018-03-29 11:00:23 --> Model Class Initialized
INFO - 2018-03-29 11:00:23 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 11:00:23 --> Final output sent to browser
DEBUG - 2018-03-29 11:00:23 --> Total execution time: 0.1290
INFO - 2018-03-29 05:30:27 --> Config Class Initialized
INFO - 2018-03-29 05:30:27 --> Hooks Class Initialized
DEBUG - 2018-03-29 05:30:27 --> UTF-8 Support Enabled
INFO - 2018-03-29 05:30:27 --> Utf8 Class Initialized
INFO - 2018-03-29 05:30:27 --> URI Class Initialized
INFO - 2018-03-29 05:30:27 --> Router Class Initialized
INFO - 2018-03-29 05:30:27 --> Output Class Initialized
INFO - 2018-03-29 05:30:27 --> Security Class Initialized
DEBUG - 2018-03-29 05:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 05:30:27 --> Input Class Initialized
INFO - 2018-03-29 05:30:27 --> Language Class Initialized
INFO - 2018-03-29 05:30:27 --> Language Class Initialized
INFO - 2018-03-29 05:30:27 --> Config Class Initialized
INFO - 2018-03-29 05:30:27 --> Loader Class Initialized
INFO - 2018-03-29 11:00:27 --> Helper loaded: url_helper
INFO - 2018-03-29 11:00:27 --> Helper loaded: notification_helper
INFO - 2018-03-29 11:00:27 --> Helper loaded: settings_helper
INFO - 2018-03-29 11:00:27 --> Helper loaded: permission_helper
INFO - 2018-03-29 11:00:27 --> Helper loaded: users_helper
INFO - 2018-03-29 11:00:27 --> Database Driver Class Initialized
DEBUG - 2018-03-29 11:00:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 11:00:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 11:00:27 --> Helper loaded: form_helper
INFO - 2018-03-29 11:00:27 --> Form Validation Class Initialized
INFO - 2018-03-29 11:00:27 --> Controller Class Initialized
INFO - 2018-03-29 11:00:27 --> Model Class Initialized
INFO - 2018-03-29 11:00:27 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 11:00:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 11:00:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 11:00:27 --> Model Class Initialized
INFO - 2018-03-29 11:00:27 --> Model Class Initialized
INFO - 2018-03-29 11:00:27 --> Model Class Initialized
INFO - 2018-03-29 11:00:27 --> Model Class Initialized
INFO - 2018-03-29 11:00:27 --> Model Class Initialized
INFO - 2018-03-29 11:00:27 --> Model Class Initialized
INFO - 2018-03-29 11:00:27 --> Model Class Initialized
INFO - 2018-03-29 11:00:27 --> Model Class Initialized
INFO - 2018-03-29 11:00:27 --> Model Class Initialized
INFO - 2018-03-29 11:00:27 --> Model Class Initialized
INFO - 2018-03-29 11:00:27 --> Model Class Initialized
INFO - 2018-03-29 11:00:27 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 11:00:27 --> Final output sent to browser
DEBUG - 2018-03-29 11:00:27 --> Total execution time: 0.6206
INFO - 2018-03-29 05:30:32 --> Config Class Initialized
INFO - 2018-03-29 05:30:32 --> Hooks Class Initialized
DEBUG - 2018-03-29 05:30:32 --> UTF-8 Support Enabled
INFO - 2018-03-29 05:30:32 --> Utf8 Class Initialized
INFO - 2018-03-29 05:30:32 --> URI Class Initialized
INFO - 2018-03-29 05:30:32 --> Router Class Initialized
INFO - 2018-03-29 05:30:32 --> Output Class Initialized
INFO - 2018-03-29 05:30:32 --> Security Class Initialized
DEBUG - 2018-03-29 05:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 05:30:32 --> Input Class Initialized
INFO - 2018-03-29 05:30:32 --> Language Class Initialized
INFO - 2018-03-29 05:30:32 --> Language Class Initialized
INFO - 2018-03-29 05:30:32 --> Config Class Initialized
INFO - 2018-03-29 05:30:32 --> Loader Class Initialized
INFO - 2018-03-29 11:00:32 --> Helper loaded: url_helper
INFO - 2018-03-29 11:00:32 --> Helper loaded: notification_helper
INFO - 2018-03-29 11:00:32 --> Helper loaded: settings_helper
INFO - 2018-03-29 11:00:32 --> Helper loaded: permission_helper
INFO - 2018-03-29 11:00:32 --> Helper loaded: users_helper
INFO - 2018-03-29 11:00:32 --> Database Driver Class Initialized
DEBUG - 2018-03-29 11:00:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 11:00:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 11:00:32 --> Helper loaded: form_helper
INFO - 2018-03-29 11:00:32 --> Form Validation Class Initialized
INFO - 2018-03-29 11:00:32 --> Controller Class Initialized
INFO - 2018-03-29 11:00:32 --> Model Class Initialized
INFO - 2018-03-29 11:00:32 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 11:00:32 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 11:00:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 11:00:32 --> Model Class Initialized
INFO - 2018-03-29 11:00:32 --> Model Class Initialized
INFO - 2018-03-29 11:00:32 --> Model Class Initialized
INFO - 2018-03-29 11:00:32 --> Model Class Initialized
INFO - 2018-03-29 11:00:32 --> Model Class Initialized
INFO - 2018-03-29 11:00:32 --> Model Class Initialized
INFO - 2018-03-29 11:00:32 --> Model Class Initialized
INFO - 2018-03-29 11:00:32 --> Model Class Initialized
INFO - 2018-03-29 11:00:32 --> Model Class Initialized
INFO - 2018-03-29 11:00:32 --> Model Class Initialized
INFO - 2018-03-29 11:00:32 --> Model Class Initialized
INFO - 2018-03-29 11:00:32 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 11:00:32 --> Model Class Initialized
INFO - 2018-03-29 11:00:32 --> Final output sent to browser
DEBUG - 2018-03-29 11:00:32 --> Total execution time: 0.4502
INFO - 2018-03-29 05:30:34 --> Config Class Initialized
INFO - 2018-03-29 05:30:34 --> Hooks Class Initialized
DEBUG - 2018-03-29 05:30:34 --> UTF-8 Support Enabled
INFO - 2018-03-29 05:30:34 --> Utf8 Class Initialized
INFO - 2018-03-29 05:30:34 --> URI Class Initialized
INFO - 2018-03-29 05:30:34 --> Router Class Initialized
INFO - 2018-03-29 05:30:34 --> Output Class Initialized
INFO - 2018-03-29 05:30:34 --> Security Class Initialized
DEBUG - 2018-03-29 05:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 05:30:34 --> Input Class Initialized
INFO - 2018-03-29 05:30:34 --> Language Class Initialized
INFO - 2018-03-29 05:30:34 --> Language Class Initialized
INFO - 2018-03-29 05:30:34 --> Config Class Initialized
INFO - 2018-03-29 05:30:34 --> Loader Class Initialized
INFO - 2018-03-29 11:00:34 --> Helper loaded: url_helper
INFO - 2018-03-29 11:00:34 --> Helper loaded: notification_helper
INFO - 2018-03-29 11:00:34 --> Helper loaded: settings_helper
INFO - 2018-03-29 11:00:34 --> Helper loaded: permission_helper
INFO - 2018-03-29 11:00:34 --> Helper loaded: users_helper
INFO - 2018-03-29 11:00:34 --> Database Driver Class Initialized
DEBUG - 2018-03-29 11:00:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 11:00:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 11:00:34 --> Helper loaded: form_helper
INFO - 2018-03-29 11:00:34 --> Form Validation Class Initialized
INFO - 2018-03-29 11:00:34 --> Controller Class Initialized
INFO - 2018-03-29 11:00:34 --> Model Class Initialized
INFO - 2018-03-29 11:00:34 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 11:00:34 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 11:00:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 11:00:34 --> Model Class Initialized
INFO - 2018-03-29 11:00:34 --> Model Class Initialized
INFO - 2018-03-29 11:00:34 --> Model Class Initialized
INFO - 2018-03-29 11:00:34 --> Model Class Initialized
INFO - 2018-03-29 11:00:34 --> Model Class Initialized
INFO - 2018-03-29 11:00:34 --> Model Class Initialized
INFO - 2018-03-29 11:00:34 --> Model Class Initialized
INFO - 2018-03-29 11:00:34 --> Model Class Initialized
INFO - 2018-03-29 11:00:34 --> Model Class Initialized
INFO - 2018-03-29 11:00:34 --> Model Class Initialized
INFO - 2018-03-29 11:00:34 --> Model Class Initialized
INFO - 2018-03-29 11:00:34 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 11:00:34 --> Final output sent to browser
DEBUG - 2018-03-29 11:00:34 --> Total execution time: 0.2580
INFO - 2018-03-29 05:30:39 --> Config Class Initialized
INFO - 2018-03-29 05:30:39 --> Hooks Class Initialized
DEBUG - 2018-03-29 05:30:39 --> UTF-8 Support Enabled
INFO - 2018-03-29 05:30:39 --> Utf8 Class Initialized
INFO - 2018-03-29 05:30:39 --> URI Class Initialized
INFO - 2018-03-29 05:30:39 --> Router Class Initialized
INFO - 2018-03-29 05:30:39 --> Output Class Initialized
INFO - 2018-03-29 05:30:39 --> Security Class Initialized
DEBUG - 2018-03-29 05:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 05:30:39 --> Input Class Initialized
INFO - 2018-03-29 05:30:39 --> Language Class Initialized
INFO - 2018-03-29 05:30:39 --> Language Class Initialized
INFO - 2018-03-29 05:30:39 --> Config Class Initialized
INFO - 2018-03-29 05:30:39 --> Loader Class Initialized
INFO - 2018-03-29 11:00:39 --> Helper loaded: url_helper
INFO - 2018-03-29 11:00:39 --> Helper loaded: notification_helper
INFO - 2018-03-29 11:00:39 --> Helper loaded: settings_helper
INFO - 2018-03-29 11:00:39 --> Helper loaded: permission_helper
INFO - 2018-03-29 11:00:39 --> Helper loaded: users_helper
INFO - 2018-03-29 11:00:39 --> Database Driver Class Initialized
DEBUG - 2018-03-29 11:00:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 11:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 11:00:39 --> Helper loaded: form_helper
INFO - 2018-03-29 11:00:39 --> Form Validation Class Initialized
INFO - 2018-03-29 11:00:39 --> Controller Class Initialized
INFO - 2018-03-29 11:00:39 --> Model Class Initialized
INFO - 2018-03-29 11:00:39 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 11:00:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 11:00:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 11:00:39 --> Model Class Initialized
INFO - 2018-03-29 11:00:39 --> Model Class Initialized
INFO - 2018-03-29 11:00:39 --> Model Class Initialized
INFO - 2018-03-29 11:00:39 --> Model Class Initialized
INFO - 2018-03-29 11:00:39 --> Final output sent to browser
DEBUG - 2018-03-29 11:00:39 --> Total execution time: 0.2020
INFO - 2018-03-29 05:30:40 --> Config Class Initialized
INFO - 2018-03-29 05:30:40 --> Hooks Class Initialized
DEBUG - 2018-03-29 05:30:40 --> UTF-8 Support Enabled
INFO - 2018-03-29 05:30:40 --> Utf8 Class Initialized
INFO - 2018-03-29 05:30:40 --> URI Class Initialized
INFO - 2018-03-29 05:30:40 --> Router Class Initialized
INFO - 2018-03-29 05:30:40 --> Output Class Initialized
INFO - 2018-03-29 05:30:40 --> Security Class Initialized
DEBUG - 2018-03-29 05:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 05:30:40 --> Input Class Initialized
INFO - 2018-03-29 05:30:40 --> Language Class Initialized
INFO - 2018-03-29 05:30:40 --> Language Class Initialized
INFO - 2018-03-29 05:30:40 --> Config Class Initialized
INFO - 2018-03-29 05:30:40 --> Loader Class Initialized
INFO - 2018-03-29 11:00:40 --> Helper loaded: url_helper
INFO - 2018-03-29 11:00:40 --> Helper loaded: notification_helper
INFO - 2018-03-29 11:00:40 --> Helper loaded: settings_helper
INFO - 2018-03-29 11:00:40 --> Helper loaded: permission_helper
INFO - 2018-03-29 11:00:40 --> Helper loaded: users_helper
INFO - 2018-03-29 11:00:40 --> Database Driver Class Initialized
DEBUG - 2018-03-29 11:00:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 11:00:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 11:00:40 --> Helper loaded: form_helper
INFO - 2018-03-29 11:00:40 --> Form Validation Class Initialized
INFO - 2018-03-29 11:00:40 --> Controller Class Initialized
INFO - 2018-03-29 11:00:40 --> Model Class Initialized
INFO - 2018-03-29 11:00:40 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 11:00:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 11:00:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 11:00:40 --> Model Class Initialized
INFO - 2018-03-29 11:00:40 --> Model Class Initialized
INFO - 2018-03-29 11:00:40 --> Model Class Initialized
INFO - 2018-03-29 11:00:40 --> Model Class Initialized
INFO - 2018-03-29 11:00:40 --> Final output sent to browser
DEBUG - 2018-03-29 11:00:40 --> Total execution time: 0.5155
INFO - 2018-03-29 05:30:43 --> Config Class Initialized
INFO - 2018-03-29 05:30:43 --> Hooks Class Initialized
DEBUG - 2018-03-29 05:30:43 --> UTF-8 Support Enabled
INFO - 2018-03-29 05:30:43 --> Utf8 Class Initialized
INFO - 2018-03-29 05:30:43 --> Config Class Initialized
INFO - 2018-03-29 05:30:43 --> Hooks Class Initialized
INFO - 2018-03-29 05:30:43 --> URI Class Initialized
DEBUG - 2018-03-29 05:30:43 --> UTF-8 Support Enabled
INFO - 2018-03-29 05:30:43 --> Utf8 Class Initialized
INFO - 2018-03-29 05:30:43 --> URI Class Initialized
INFO - 2018-03-29 05:30:43 --> Router Class Initialized
INFO - 2018-03-29 05:30:43 --> Router Class Initialized
INFO - 2018-03-29 05:30:43 --> Output Class Initialized
INFO - 2018-03-29 05:30:43 --> Output Class Initialized
INFO - 2018-03-29 05:30:43 --> Security Class Initialized
DEBUG - 2018-03-29 05:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 05:30:43 --> Input Class Initialized
INFO - 2018-03-29 05:30:43 --> Language Class Initialized
INFO - 2018-03-29 05:30:43 --> Security Class Initialized
DEBUG - 2018-03-29 05:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 05:30:43 --> Input Class Initialized
INFO - 2018-03-29 05:30:43 --> Language Class Initialized
INFO - 2018-03-29 05:30:43 --> Language Class Initialized
INFO - 2018-03-29 05:30:43 --> Config Class Initialized
INFO - 2018-03-29 05:30:43 --> Loader Class Initialized
INFO - 2018-03-29 11:00:43 --> Helper loaded: url_helper
INFO - 2018-03-29 11:00:43 --> Helper loaded: notification_helper
INFO - 2018-03-29 11:00:43 --> Helper loaded: settings_helper
INFO - 2018-03-29 11:00:43 --> Helper loaded: permission_helper
INFO - 2018-03-29 11:00:43 --> Helper loaded: users_helper
INFO - 2018-03-29 05:30:43 --> Language Class Initialized
INFO - 2018-03-29 05:30:43 --> Config Class Initialized
INFO - 2018-03-29 05:30:43 --> Loader Class Initialized
INFO - 2018-03-29 11:00:43 --> Database Driver Class Initialized
INFO - 2018-03-29 11:00:43 --> Helper loaded: url_helper
INFO - 2018-03-29 11:00:43 --> Helper loaded: notification_helper
INFO - 2018-03-29 11:00:43 --> Helper loaded: settings_helper
DEBUG - 2018-03-29 11:00:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 11:00:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 11:00:43 --> Helper loaded: permission_helper
INFO - 2018-03-29 11:00:43 --> Helper loaded: users_helper
INFO - 2018-03-29 11:00:43 --> Helper loaded: form_helper
INFO - 2018-03-29 11:00:43 --> Form Validation Class Initialized
INFO - 2018-03-29 11:00:43 --> Controller Class Initialized
INFO - 2018-03-29 11:00:43 --> Model Class Initialized
INFO - 2018-03-29 11:00:43 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 11:00:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 11:00:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 11:00:43 --> Model Class Initialized
INFO - 2018-03-29 11:00:43 --> Model Class Initialized
INFO - 2018-03-29 11:00:43 --> Model Class Initialized
INFO - 2018-03-29 11:00:43 --> Model Class Initialized
INFO - 2018-03-29 11:00:43 --> Model Class Initialized
INFO - 2018-03-29 11:00:43 --> Database Driver Class Initialized
INFO - 2018-03-29 11:00:43 --> Model Class Initialized
INFO - 2018-03-29 11:00:43 --> Model Class Initialized
INFO - 2018-03-29 11:00:43 --> Model Class Initialized
INFO - 2018-03-29 11:00:43 --> Model Class Initialized
INFO - 2018-03-29 11:00:43 --> Model Class Initialized
INFO - 2018-03-29 11:00:43 --> Model Class Initialized
INFO - 2018-03-29 11:00:43 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-03-29 11:00:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 11:00:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 11:00:43 --> Final output sent to browser
DEBUG - 2018-03-29 11:00:43 --> Total execution time: 0.2539
INFO - 2018-03-29 11:00:43 --> Helper loaded: form_helper
INFO - 2018-03-29 11:00:43 --> Form Validation Class Initialized
INFO - 2018-03-29 11:00:43 --> Controller Class Initialized
INFO - 2018-03-29 11:00:44 --> Model Class Initialized
INFO - 2018-03-29 11:00:44 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 11:00:44 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 11:00:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 11:00:44 --> Model Class Initialized
INFO - 2018-03-29 11:00:44 --> Model Class Initialized
INFO - 2018-03-29 11:00:44 --> Model Class Initialized
INFO - 2018-03-29 11:00:44 --> Model Class Initialized
INFO - 2018-03-29 11:00:44 --> Model Class Initialized
INFO - 2018-03-29 11:00:44 --> Model Class Initialized
INFO - 2018-03-29 11:00:44 --> Model Class Initialized
INFO - 2018-03-29 11:00:44 --> Model Class Initialized
INFO - 2018-03-29 11:00:44 --> Model Class Initialized
INFO - 2018-03-29 11:00:44 --> Model Class Initialized
INFO - 2018-03-29 11:00:44 --> Model Class Initialized
INFO - 2018-03-29 11:00:44 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 11:00:44 --> Model Class Initialized
INFO - 2018-03-29 11:00:44 --> Final output sent to browser
DEBUG - 2018-03-29 11:00:44 --> Total execution time: 0.3899
INFO - 2018-03-29 05:33:22 --> Config Class Initialized
INFO - 2018-03-29 05:33:22 --> Hooks Class Initialized
DEBUG - 2018-03-29 05:33:22 --> UTF-8 Support Enabled
INFO - 2018-03-29 05:33:22 --> Utf8 Class Initialized
INFO - 2018-03-29 05:33:22 --> URI Class Initialized
INFO - 2018-03-29 05:33:22 --> Router Class Initialized
INFO - 2018-03-29 05:33:22 --> Output Class Initialized
INFO - 2018-03-29 05:33:22 --> Security Class Initialized
DEBUG - 2018-03-29 05:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 05:33:22 --> Input Class Initialized
INFO - 2018-03-29 05:33:22 --> Language Class Initialized
INFO - 2018-03-29 05:33:23 --> Language Class Initialized
INFO - 2018-03-29 05:33:23 --> Config Class Initialized
INFO - 2018-03-29 05:33:23 --> Loader Class Initialized
INFO - 2018-03-29 11:03:23 --> Helper loaded: url_helper
INFO - 2018-03-29 11:03:23 --> Helper loaded: notification_helper
INFO - 2018-03-29 11:03:23 --> Helper loaded: settings_helper
INFO - 2018-03-29 11:03:23 --> Helper loaded: permission_helper
INFO - 2018-03-29 11:03:23 --> Helper loaded: users_helper
INFO - 2018-03-29 11:03:23 --> Database Driver Class Initialized
DEBUG - 2018-03-29 11:03:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 11:03:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 11:03:24 --> Helper loaded: form_helper
INFO - 2018-03-29 11:03:24 --> Form Validation Class Initialized
INFO - 2018-03-29 11:03:24 --> Controller Class Initialized
INFO - 2018-03-29 11:03:25 --> Model Class Initialized
INFO - 2018-03-29 11:03:25 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 11:03:25 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 11:03:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 11:03:25 --> Model Class Initialized
INFO - 2018-03-29 11:03:25 --> Model Class Initialized
INFO - 2018-03-29 11:03:25 --> Model Class Initialized
INFO - 2018-03-29 11:03:25 --> Model Class Initialized
INFO - 2018-03-29 11:03:25 --> Model Class Initialized
INFO - 2018-03-29 11:03:25 --> Model Class Initialized
INFO - 2018-03-29 11:03:25 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 11:03:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-29 11:03:25 --> Final output sent to browser
DEBUG - 2018-03-29 11:03:25 --> Total execution time: 3.1267
INFO - 2018-03-29 05:33:26 --> Config Class Initialized
INFO - 2018-03-29 05:33:26 --> Hooks Class Initialized
DEBUG - 2018-03-29 05:33:26 --> UTF-8 Support Enabled
INFO - 2018-03-29 05:33:26 --> Utf8 Class Initialized
INFO - 2018-03-29 05:33:26 --> URI Class Initialized
INFO - 2018-03-29 05:33:26 --> Router Class Initialized
INFO - 2018-03-29 05:33:26 --> Output Class Initialized
INFO - 2018-03-29 05:33:26 --> Security Class Initialized
DEBUG - 2018-03-29 05:33:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 05:33:26 --> Input Class Initialized
INFO - 2018-03-29 05:33:26 --> Language Class Initialized
INFO - 2018-03-29 05:33:26 --> Language Class Initialized
INFO - 2018-03-29 05:33:26 --> Config Class Initialized
INFO - 2018-03-29 05:33:26 --> Loader Class Initialized
INFO - 2018-03-29 11:03:26 --> Helper loaded: url_helper
INFO - 2018-03-29 11:03:26 --> Helper loaded: notification_helper
INFO - 2018-03-29 11:03:26 --> Helper loaded: settings_helper
INFO - 2018-03-29 11:03:26 --> Helper loaded: permission_helper
INFO - 2018-03-29 11:03:26 --> Helper loaded: users_helper
INFO - 2018-03-29 11:03:26 --> Database Driver Class Initialized
DEBUG - 2018-03-29 11:03:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 11:03:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 11:03:26 --> Helper loaded: form_helper
INFO - 2018-03-29 11:03:26 --> Form Validation Class Initialized
INFO - 2018-03-29 11:03:26 --> Controller Class Initialized
INFO - 2018-03-29 11:03:26 --> Model Class Initialized
INFO - 2018-03-29 11:03:26 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 11:03:26 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 11:03:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 11:03:26 --> Model Class Initialized
INFO - 2018-03-29 11:03:26 --> Model Class Initialized
INFO - 2018-03-29 11:03:26 --> Model Class Initialized
INFO - 2018-03-29 11:03:26 --> Model Class Initialized
INFO - 2018-03-29 11:03:26 --> Model Class Initialized
INFO - 2018-03-29 11:03:26 --> Model Class Initialized
INFO - 2018-03-29 11:03:26 --> Model Class Initialized
INFO - 2018-03-29 11:03:26 --> Model Class Initialized
INFO - 2018-03-29 11:03:26 --> Model Class Initialized
INFO - 2018-03-29 11:03:26 --> Model Class Initialized
INFO - 2018-03-29 11:03:26 --> Model Class Initialized
INFO - 2018-03-29 11:03:26 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 11:03:26 --> Model Class Initialized
INFO - 2018-03-29 11:03:26 --> Final output sent to browser
DEBUG - 2018-03-29 11:03:26 --> Total execution time: 0.1946
INFO - 2018-03-29 05:33:29 --> Config Class Initialized
INFO - 2018-03-29 05:33:29 --> Hooks Class Initialized
DEBUG - 2018-03-29 05:33:29 --> UTF-8 Support Enabled
INFO - 2018-03-29 05:33:29 --> Utf8 Class Initialized
INFO - 2018-03-29 05:33:29 --> Config Class Initialized
INFO - 2018-03-29 05:33:29 --> Hooks Class Initialized
DEBUG - 2018-03-29 05:33:29 --> UTF-8 Support Enabled
INFO - 2018-03-29 05:33:29 --> Utf8 Class Initialized
INFO - 2018-03-29 05:33:29 --> URI Class Initialized
INFO - 2018-03-29 05:33:29 --> Router Class Initialized
INFO - 2018-03-29 05:33:29 --> Output Class Initialized
INFO - 2018-03-29 05:33:29 --> Security Class Initialized
DEBUG - 2018-03-29 05:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 05:33:29 --> Input Class Initialized
INFO - 2018-03-29 05:33:29 --> Language Class Initialized
INFO - 2018-03-29 05:33:29 --> Language Class Initialized
INFO - 2018-03-29 05:33:29 --> Config Class Initialized
INFO - 2018-03-29 05:33:29 --> Loader Class Initialized
INFO - 2018-03-29 11:03:29 --> Helper loaded: url_helper
INFO - 2018-03-29 11:03:29 --> Helper loaded: notification_helper
INFO - 2018-03-29 11:03:29 --> Helper loaded: settings_helper
INFO - 2018-03-29 11:03:29 --> Helper loaded: permission_helper
INFO - 2018-03-29 05:33:29 --> URI Class Initialized
INFO - 2018-03-29 11:03:29 --> Helper loaded: users_helper
INFO - 2018-03-29 11:03:29 --> Database Driver Class Initialized
DEBUG - 2018-03-29 11:03:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 11:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 11:03:29 --> Helper loaded: form_helper
INFO - 2018-03-29 11:03:29 --> Form Validation Class Initialized
INFO - 2018-03-29 11:03:29 --> Controller Class Initialized
INFO - 2018-03-29 11:03:29 --> Model Class Initialized
INFO - 2018-03-29 11:03:29 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 11:03:29 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 11:03:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 11:03:29 --> Model Class Initialized
INFO - 2018-03-29 11:03:29 --> Model Class Initialized
INFO - 2018-03-29 11:03:29 --> Model Class Initialized
INFO - 2018-03-29 11:03:29 --> Model Class Initialized
INFO - 2018-03-29 11:03:29 --> Model Class Initialized
INFO - 2018-03-29 11:03:29 --> Model Class Initialized
INFO - 2018-03-29 11:03:29 --> Model Class Initialized
INFO - 2018-03-29 11:03:29 --> Model Class Initialized
INFO - 2018-03-29 11:03:29 --> Model Class Initialized
INFO - 2018-03-29 11:03:29 --> Model Class Initialized
INFO - 2018-03-29 11:03:29 --> Model Class Initialized
INFO - 2018-03-29 11:03:29 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 11:03:29 --> Model Class Initialized
INFO - 2018-03-29 11:03:29 --> Final output sent to browser
DEBUG - 2018-03-29 11:03:29 --> Total execution time: 0.2232
INFO - 2018-03-29 05:33:30 --> Router Class Initialized
INFO - 2018-03-29 05:33:30 --> Output Class Initialized
INFO - 2018-03-29 05:33:30 --> Security Class Initialized
DEBUG - 2018-03-29 05:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 05:33:30 --> Input Class Initialized
INFO - 2018-03-29 05:33:30 --> Language Class Initialized
INFO - 2018-03-29 05:33:31 --> Language Class Initialized
INFO - 2018-03-29 05:33:31 --> Config Class Initialized
INFO - 2018-03-29 05:33:31 --> Loader Class Initialized
INFO - 2018-03-29 11:03:31 --> Helper loaded: url_helper
INFO - 2018-03-29 11:03:31 --> Helper loaded: notification_helper
INFO - 2018-03-29 11:03:31 --> Helper loaded: settings_helper
INFO - 2018-03-29 11:03:31 --> Helper loaded: permission_helper
INFO - 2018-03-29 11:03:31 --> Helper loaded: users_helper
INFO - 2018-03-29 11:03:31 --> Database Driver Class Initialized
DEBUG - 2018-03-29 11:03:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 11:03:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 11:03:31 --> Helper loaded: form_helper
INFO - 2018-03-29 11:03:31 --> Form Validation Class Initialized
INFO - 2018-03-29 11:03:31 --> Controller Class Initialized
INFO - 2018-03-29 11:03:31 --> Model Class Initialized
INFO - 2018-03-29 11:03:31 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 11:03:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 11:03:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 11:03:31 --> Model Class Initialized
INFO - 2018-03-29 11:03:31 --> Model Class Initialized
INFO - 2018-03-29 11:03:31 --> Model Class Initialized
INFO - 2018-03-29 11:03:31 --> Model Class Initialized
INFO - 2018-03-29 11:03:31 --> Model Class Initialized
INFO - 2018-03-29 11:03:31 --> Model Class Initialized
INFO - 2018-03-29 11:03:31 --> Model Class Initialized
INFO - 2018-03-29 11:03:31 --> Model Class Initialized
INFO - 2018-03-29 11:03:31 --> Model Class Initialized
INFO - 2018-03-29 11:03:31 --> Model Class Initialized
INFO - 2018-03-29 11:03:31 --> Model Class Initialized
INFO - 2018-03-29 11:03:31 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 11:03:31 --> Model Class Initialized
INFO - 2018-03-29 11:03:31 --> Final output sent to browser
DEBUG - 2018-03-29 11:03:31 --> Total execution time: 2.7135
INFO - 2018-03-29 05:33:44 --> Config Class Initialized
INFO - 2018-03-29 05:33:44 --> Hooks Class Initialized
INFO - 2018-03-29 05:33:44 --> Config Class Initialized
INFO - 2018-03-29 05:33:44 --> Hooks Class Initialized
DEBUG - 2018-03-29 05:33:44 --> UTF-8 Support Enabled
INFO - 2018-03-29 05:33:44 --> Utf8 Class Initialized
INFO - 2018-03-29 05:33:44 --> URI Class Initialized
DEBUG - 2018-03-29 05:33:44 --> UTF-8 Support Enabled
INFO - 2018-03-29 05:33:44 --> Utf8 Class Initialized
INFO - 2018-03-29 05:33:44 --> URI Class Initialized
INFO - 2018-03-29 05:33:44 --> Router Class Initialized
INFO - 2018-03-29 05:33:44 --> Router Class Initialized
INFO - 2018-03-29 05:33:44 --> Output Class Initialized
INFO - 2018-03-29 05:33:44 --> Security Class Initialized
INFO - 2018-03-29 05:33:44 --> Output Class Initialized
DEBUG - 2018-03-29 05:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 05:33:44 --> Input Class Initialized
INFO - 2018-03-29 05:33:44 --> Security Class Initialized
INFO - 2018-03-29 05:33:44 --> Language Class Initialized
DEBUG - 2018-03-29 05:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 05:33:44 --> Input Class Initialized
INFO - 2018-03-29 05:33:44 --> Language Class Initialized
INFO - 2018-03-29 05:33:44 --> Language Class Initialized
INFO - 2018-03-29 05:33:44 --> Config Class Initialized
INFO - 2018-03-29 05:33:44 --> Loader Class Initialized
INFO - 2018-03-29 11:03:44 --> Helper loaded: url_helper
INFO - 2018-03-29 05:33:44 --> Language Class Initialized
INFO - 2018-03-29 05:33:44 --> Config Class Initialized
INFO - 2018-03-29 05:33:44 --> Loader Class Initialized
INFO - 2018-03-29 11:03:44 --> Helper loaded: notification_helper
INFO - 2018-03-29 11:03:44 --> Helper loaded: settings_helper
INFO - 2018-03-29 11:03:44 --> Helper loaded: permission_helper
INFO - 2018-03-29 11:03:44 --> Helper loaded: url_helper
INFO - 2018-03-29 11:03:44 --> Helper loaded: users_helper
INFO - 2018-03-29 11:03:44 --> Helper loaded: notification_helper
INFO - 2018-03-29 11:03:44 --> Helper loaded: settings_helper
INFO - 2018-03-29 11:03:44 --> Helper loaded: permission_helper
INFO - 2018-03-29 11:03:44 --> Helper loaded: users_helper
INFO - 2018-03-29 11:03:45 --> Database Driver Class Initialized
INFO - 2018-03-29 11:03:45 --> Database Driver Class Initialized
DEBUG - 2018-03-29 11:03:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 11:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 11:03:45 --> Helper loaded: form_helper
INFO - 2018-03-29 11:03:45 --> Form Validation Class Initialized
INFO - 2018-03-29 11:03:45 --> Controller Class Initialized
DEBUG - 2018-03-29 11:03:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 11:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 11:03:45 --> Model Class Initialized
INFO - 2018-03-29 11:03:45 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 11:03:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 11:03:45 --> Helper loaded: form_helper
INFO - 2018-03-29 11:03:45 --> Form Validation Class Initialized
INFO - 2018-03-29 11:03:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 11:03:45 --> Controller Class Initialized
INFO - 2018-03-29 11:03:45 --> Model Class Initialized
INFO - 2018-03-29 11:03:45 --> Model Class Initialized
INFO - 2018-03-29 11:03:45 --> Model Class Initialized
INFO - 2018-03-29 11:03:45 --> Model Class Initialized
INFO - 2018-03-29 11:03:45 --> Model Class Initialized
INFO - 2018-03-29 11:03:45 --> Model Class Initialized
INFO - 2018-03-29 11:03:45 --> Model Class Initialized
INFO - 2018-03-29 11:03:45 --> Model Class Initialized
INFO - 2018-03-29 11:03:45 --> Model Class Initialized
INFO - 2018-03-29 11:03:45 --> Model Class Initialized
INFO - 2018-03-29 11:03:45 --> Model Class Initialized
INFO - 2018-03-29 11:03:45 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 11:03:45 --> Model Class Initialized
INFO - 2018-03-29 11:03:45 --> Helper loaded: inflector_helper
INFO - 2018-03-29 11:03:45 --> Final output sent to browser
DEBUG - 2018-03-29 11:03:45 --> Total execution time: 0.3328
DEBUG - 2018-03-29 11:03:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 11:03:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 11:03:45 --> Model Class Initialized
INFO - 2018-03-29 11:03:45 --> Model Class Initialized
INFO - 2018-03-29 11:03:45 --> Model Class Initialized
INFO - 2018-03-29 11:03:45 --> Model Class Initialized
INFO - 2018-03-29 11:03:45 --> Model Class Initialized
INFO - 2018-03-29 11:03:45 --> Model Class Initialized
INFO - 2018-03-29 11:03:45 --> Model Class Initialized
INFO - 2018-03-29 11:03:45 --> Model Class Initialized
INFO - 2018-03-29 11:03:45 --> Model Class Initialized
INFO - 2018-03-29 11:03:45 --> Model Class Initialized
INFO - 2018-03-29 11:03:45 --> Model Class Initialized
INFO - 2018-03-29 11:03:45 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 11:03:45 --> Model Class Initialized
INFO - 2018-03-29 11:03:45 --> Final output sent to browser
DEBUG - 2018-03-29 11:03:45 --> Total execution time: 0.3911
INFO - 2018-03-29 05:33:49 --> Config Class Initialized
INFO - 2018-03-29 05:33:49 --> Hooks Class Initialized
DEBUG - 2018-03-29 05:33:49 --> UTF-8 Support Enabled
INFO - 2018-03-29 05:33:49 --> Utf8 Class Initialized
INFO - 2018-03-29 05:33:49 --> URI Class Initialized
INFO - 2018-03-29 05:33:49 --> Router Class Initialized
INFO - 2018-03-29 05:33:49 --> Output Class Initialized
INFO - 2018-03-29 05:33:49 --> Security Class Initialized
DEBUG - 2018-03-29 05:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 05:33:49 --> Input Class Initialized
INFO - 2018-03-29 05:33:49 --> Language Class Initialized
INFO - 2018-03-29 05:33:49 --> Language Class Initialized
INFO - 2018-03-29 05:33:49 --> Config Class Initialized
INFO - 2018-03-29 05:33:49 --> Loader Class Initialized
INFO - 2018-03-29 11:03:49 --> Helper loaded: url_helper
INFO - 2018-03-29 11:03:49 --> Helper loaded: notification_helper
INFO - 2018-03-29 11:03:49 --> Helper loaded: settings_helper
INFO - 2018-03-29 11:03:49 --> Helper loaded: permission_helper
INFO - 2018-03-29 11:03:49 --> Helper loaded: users_helper
INFO - 2018-03-29 11:03:49 --> Database Driver Class Initialized
DEBUG - 2018-03-29 11:03:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 11:03:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 11:03:49 --> Helper loaded: form_helper
INFO - 2018-03-29 11:03:49 --> Form Validation Class Initialized
INFO - 2018-03-29 11:03:49 --> Controller Class Initialized
INFO - 2018-03-29 11:03:49 --> Model Class Initialized
INFO - 2018-03-29 11:03:49 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 11:03:49 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 11:03:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 11:03:49 --> Model Class Initialized
INFO - 2018-03-29 11:03:49 --> Model Class Initialized
INFO - 2018-03-29 11:03:49 --> Model Class Initialized
INFO - 2018-03-29 11:03:49 --> Model Class Initialized
INFO - 2018-03-29 11:03:49 --> Final output sent to browser
DEBUG - 2018-03-29 11:03:49 --> Total execution time: 0.1055
INFO - 2018-03-29 05:33:49 --> Config Class Initialized
INFO - 2018-03-29 05:33:49 --> Hooks Class Initialized
DEBUG - 2018-03-29 05:33:49 --> UTF-8 Support Enabled
INFO - 2018-03-29 05:33:49 --> Utf8 Class Initialized
INFO - 2018-03-29 05:33:49 --> URI Class Initialized
INFO - 2018-03-29 05:33:49 --> Router Class Initialized
INFO - 2018-03-29 05:33:49 --> Output Class Initialized
INFO - 2018-03-29 05:33:49 --> Security Class Initialized
DEBUG - 2018-03-29 05:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 05:33:49 --> Input Class Initialized
INFO - 2018-03-29 05:33:49 --> Language Class Initialized
INFO - 2018-03-29 05:33:49 --> Language Class Initialized
INFO - 2018-03-29 05:33:49 --> Config Class Initialized
INFO - 2018-03-29 05:33:49 --> Loader Class Initialized
INFO - 2018-03-29 11:03:49 --> Helper loaded: url_helper
INFO - 2018-03-29 11:03:49 --> Helper loaded: notification_helper
INFO - 2018-03-29 11:03:49 --> Helper loaded: settings_helper
INFO - 2018-03-29 11:03:49 --> Helper loaded: permission_helper
INFO - 2018-03-29 11:03:49 --> Helper loaded: users_helper
INFO - 2018-03-29 11:03:50 --> Database Driver Class Initialized
DEBUG - 2018-03-29 11:03:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 11:03:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 11:03:50 --> Helper loaded: form_helper
INFO - 2018-03-29 11:03:50 --> Form Validation Class Initialized
INFO - 2018-03-29 11:03:50 --> Controller Class Initialized
INFO - 2018-03-29 11:03:50 --> Model Class Initialized
INFO - 2018-03-29 11:03:50 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 11:03:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 11:03:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 11:03:50 --> Model Class Initialized
INFO - 2018-03-29 11:03:50 --> Model Class Initialized
INFO - 2018-03-29 11:03:50 --> Model Class Initialized
INFO - 2018-03-29 11:03:50 --> Model Class Initialized
INFO - 2018-03-29 11:03:50 --> Final output sent to browser
DEBUG - 2018-03-29 11:03:50 --> Total execution time: 0.6296
INFO - 2018-03-29 05:33:51 --> Config Class Initialized
INFO - 2018-03-29 05:33:51 --> Hooks Class Initialized
DEBUG - 2018-03-29 05:33:51 --> UTF-8 Support Enabled
INFO - 2018-03-29 05:33:51 --> Utf8 Class Initialized
INFO - 2018-03-29 05:33:51 --> URI Class Initialized
INFO - 2018-03-29 05:33:51 --> Router Class Initialized
INFO - 2018-03-29 05:33:51 --> Output Class Initialized
INFO - 2018-03-29 05:33:51 --> Config Class Initialized
INFO - 2018-03-29 05:33:51 --> Hooks Class Initialized
DEBUG - 2018-03-29 05:33:51 --> UTF-8 Support Enabled
INFO - 2018-03-29 05:33:51 --> Utf8 Class Initialized
INFO - 2018-03-29 05:33:51 --> Security Class Initialized
INFO - 2018-03-29 05:33:51 --> URI Class Initialized
DEBUG - 2018-03-29 05:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 05:33:51 --> Input Class Initialized
INFO - 2018-03-29 05:33:51 --> Language Class Initialized
INFO - 2018-03-29 05:33:51 --> Router Class Initialized
INFO - 2018-03-29 05:33:51 --> Output Class Initialized
INFO - 2018-03-29 05:33:51 --> Security Class Initialized
INFO - 2018-03-29 05:33:51 --> Language Class Initialized
INFO - 2018-03-29 05:33:51 --> Config Class Initialized
INFO - 2018-03-29 05:33:51 --> Loader Class Initialized
DEBUG - 2018-03-29 05:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 05:33:51 --> Input Class Initialized
INFO - 2018-03-29 05:33:51 --> Language Class Initialized
INFO - 2018-03-29 11:03:51 --> Helper loaded: url_helper
INFO - 2018-03-29 11:03:51 --> Helper loaded: notification_helper
INFO - 2018-03-29 11:03:51 --> Helper loaded: settings_helper
INFO - 2018-03-29 11:03:51 --> Helper loaded: permission_helper
INFO - 2018-03-29 11:03:51 --> Helper loaded: users_helper
INFO - 2018-03-29 05:33:51 --> Language Class Initialized
INFO - 2018-03-29 05:33:51 --> Config Class Initialized
INFO - 2018-03-29 05:33:51 --> Loader Class Initialized
INFO - 2018-03-29 11:03:51 --> Helper loaded: url_helper
INFO - 2018-03-29 11:03:51 --> Helper loaded: notification_helper
INFO - 2018-03-29 11:03:51 --> Helper loaded: settings_helper
INFO - 2018-03-29 11:03:51 --> Helper loaded: permission_helper
INFO - 2018-03-29 11:03:51 --> Helper loaded: users_helper
INFO - 2018-03-29 11:03:51 --> Database Driver Class Initialized
INFO - 2018-03-29 11:03:51 --> Database Driver Class Initialized
DEBUG - 2018-03-29 11:03:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 11:03:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-03-29 11:03:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 11:03:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 11:03:51 --> Helper loaded: form_helper
INFO - 2018-03-29 11:03:51 --> Form Validation Class Initialized
INFO - 2018-03-29 11:03:51 --> Controller Class Initialized
INFO - 2018-03-29 11:03:51 --> Helper loaded: form_helper
INFO - 2018-03-29 11:03:51 --> Form Validation Class Initialized
INFO - 2018-03-29 11:03:51 --> Controller Class Initialized
INFO - 2018-03-29 11:03:51 --> Model Class Initialized
INFO - 2018-03-29 11:03:51 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 11:03:51 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 11:03:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 11:03:51 --> Model Class Initialized
INFO - 2018-03-29 11:03:51 --> Model Class Initialized
INFO - 2018-03-29 11:03:51 --> Model Class Initialized
INFO - 2018-03-29 11:03:51 --> Helper loaded: inflector_helper
INFO - 2018-03-29 11:03:51 --> Model Class Initialized
INFO - 2018-03-29 11:03:51 --> Model Class Initialized
INFO - 2018-03-29 11:03:51 --> Model Class Initialized
INFO - 2018-03-29 11:03:51 --> Model Class Initialized
INFO - 2018-03-29 11:03:51 --> Model Class Initialized
INFO - 2018-03-29 11:03:51 --> Model Class Initialized
DEBUG - 2018-03-29 11:03:51 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 11:03:51 --> Model Class Initialized
INFO - 2018-03-29 11:03:51 --> Model Class Initialized
INFO - 2018-03-29 11:03:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 11:03:51 --> Model Class Initialized
INFO - 2018-03-29 11:03:51 --> Model Class Initialized
INFO - 2018-03-29 11:03:51 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 11:03:51 --> Model Class Initialized
INFO - 2018-03-29 11:03:51 --> Model Class Initialized
INFO - 2018-03-29 11:03:51 --> Model Class Initialized
INFO - 2018-03-29 11:03:51 --> Model Class Initialized
INFO - 2018-03-29 11:03:51 --> Model Class Initialized
INFO - 2018-03-29 11:03:51 --> Model Class Initialized
INFO - 2018-03-29 11:03:51 --> Model Class Initialized
INFO - 2018-03-29 11:03:51 --> Model Class Initialized
INFO - 2018-03-29 11:03:51 --> Model Class Initialized
INFO - 2018-03-29 11:03:51 --> Model Class Initialized
INFO - 2018-03-29 11:03:51 --> Model Class Initialized
INFO - 2018-03-29 11:03:51 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 11:03:51 --> Final output sent to browser
DEBUG - 2018-03-29 11:03:51 --> Total execution time: 0.1444
INFO - 2018-03-29 11:03:51 --> Final output sent to browser
DEBUG - 2018-03-29 11:03:51 --> Total execution time: 0.2014
INFO - 2018-03-29 06:42:38 --> Config Class Initialized
INFO - 2018-03-29 06:42:38 --> Hooks Class Initialized
DEBUG - 2018-03-29 06:42:38 --> UTF-8 Support Enabled
INFO - 2018-03-29 06:42:38 --> Utf8 Class Initialized
INFO - 2018-03-29 06:42:38 --> URI Class Initialized
INFO - 2018-03-29 06:42:38 --> Router Class Initialized
INFO - 2018-03-29 06:42:38 --> Output Class Initialized
INFO - 2018-03-29 06:42:38 --> Security Class Initialized
DEBUG - 2018-03-29 06:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 06:42:38 --> Input Class Initialized
INFO - 2018-03-29 06:42:38 --> Language Class Initialized
INFO - 2018-03-29 06:42:38 --> Language Class Initialized
INFO - 2018-03-29 06:42:38 --> Config Class Initialized
INFO - 2018-03-29 06:42:38 --> Loader Class Initialized
INFO - 2018-03-29 12:12:38 --> Helper loaded: url_helper
INFO - 2018-03-29 12:12:38 --> Helper loaded: notification_helper
INFO - 2018-03-29 12:12:38 --> Helper loaded: settings_helper
INFO - 2018-03-29 12:12:38 --> Helper loaded: permission_helper
INFO - 2018-03-29 12:12:38 --> Helper loaded: users_helper
INFO - 2018-03-29 12:12:38 --> Database Driver Class Initialized
DEBUG - 2018-03-29 12:12:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 12:12:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 12:12:38 --> Helper loaded: form_helper
INFO - 2018-03-29 12:12:38 --> Form Validation Class Initialized
INFO - 2018-03-29 12:12:38 --> Controller Class Initialized
INFO - 2018-03-29 12:12:38 --> Model Class Initialized
INFO - 2018-03-29 12:12:38 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 12:12:38 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 12:12:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 12:12:38 --> Model Class Initialized
INFO - 2018-03-29 12:12:38 --> Model Class Initialized
INFO - 2018-03-29 12:12:38 --> Model Class Initialized
INFO - 2018-03-29 12:12:38 --> Model Class Initialized
INFO - 2018-03-29 12:12:38 --> Model Class Initialized
INFO - 2018-03-29 12:12:38 --> Model Class Initialized
INFO - 2018-03-29 12:12:38 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 12:12:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-29 12:12:38 --> Final output sent to browser
DEBUG - 2018-03-29 12:12:38 --> Total execution time: 0.1268
INFO - 2018-03-29 06:42:39 --> Config Class Initialized
INFO - 2018-03-29 06:42:39 --> Hooks Class Initialized
DEBUG - 2018-03-29 06:42:39 --> UTF-8 Support Enabled
INFO - 2018-03-29 06:42:39 --> Utf8 Class Initialized
INFO - 2018-03-29 06:42:39 --> URI Class Initialized
INFO - 2018-03-29 06:42:39 --> Router Class Initialized
INFO - 2018-03-29 06:42:39 --> Output Class Initialized
INFO - 2018-03-29 06:42:39 --> Security Class Initialized
INFO - 2018-03-29 06:42:39 --> Config Class Initialized
INFO - 2018-03-29 06:42:39 --> Hooks Class Initialized
DEBUG - 2018-03-29 06:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 06:42:39 --> Input Class Initialized
INFO - 2018-03-29 06:42:39 --> Language Class Initialized
DEBUG - 2018-03-29 06:42:39 --> UTF-8 Support Enabled
INFO - 2018-03-29 06:42:39 --> Utf8 Class Initialized
INFO - 2018-03-29 06:42:39 --> URI Class Initialized
INFO - 2018-03-29 06:42:39 --> Language Class Initialized
INFO - 2018-03-29 06:42:39 --> Config Class Initialized
INFO - 2018-03-29 06:42:39 --> Loader Class Initialized
INFO - 2018-03-29 12:12:39 --> Helper loaded: url_helper
INFO - 2018-03-29 12:12:39 --> Helper loaded: notification_helper
INFO - 2018-03-29 06:42:39 --> Router Class Initialized
INFO - 2018-03-29 12:12:39 --> Helper loaded: settings_helper
INFO - 2018-03-29 12:12:39 --> Helper loaded: permission_helper
INFO - 2018-03-29 12:12:39 --> Helper loaded: users_helper
INFO - 2018-03-29 06:42:39 --> Output Class Initialized
INFO - 2018-03-29 06:42:40 --> Security Class Initialized
INFO - 2018-03-29 12:12:40 --> Database Driver Class Initialized
DEBUG - 2018-03-29 12:12:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 12:12:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-03-29 06:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 06:42:40 --> Input Class Initialized
INFO - 2018-03-29 12:12:40 --> Helper loaded: form_helper
INFO - 2018-03-29 12:12:40 --> Form Validation Class Initialized
INFO - 2018-03-29 12:12:40 --> Controller Class Initialized
INFO - 2018-03-29 06:42:40 --> Language Class Initialized
INFO - 2018-03-29 12:12:40 --> Model Class Initialized
INFO - 2018-03-29 12:12:40 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 12:12:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 12:12:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 12:12:40 --> Model Class Initialized
INFO - 2018-03-29 12:12:40 --> Model Class Initialized
INFO - 2018-03-29 12:12:40 --> Model Class Initialized
INFO - 2018-03-29 12:12:40 --> Model Class Initialized
INFO - 2018-03-29 12:12:40 --> Model Class Initialized
INFO - 2018-03-29 12:12:40 --> Model Class Initialized
INFO - 2018-03-29 12:12:40 --> Model Class Initialized
INFO - 2018-03-29 12:12:40 --> Model Class Initialized
INFO - 2018-03-29 12:12:40 --> Model Class Initialized
INFO - 2018-03-29 12:12:40 --> Model Class Initialized
INFO - 2018-03-29 12:12:40 --> Model Class Initialized
INFO - 2018-03-29 12:12:40 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 12:12:40 --> Model Class Initialized
INFO - 2018-03-29 12:12:40 --> Final output sent to browser
DEBUG - 2018-03-29 12:12:40 --> Total execution time: 0.4688
INFO - 2018-03-29 06:42:40 --> Language Class Initialized
INFO - 2018-03-29 06:42:40 --> Config Class Initialized
INFO - 2018-03-29 06:42:40 --> Loader Class Initialized
INFO - 2018-03-29 12:12:40 --> Helper loaded: url_helper
INFO - 2018-03-29 12:12:40 --> Helper loaded: notification_helper
INFO - 2018-03-29 12:12:40 --> Helper loaded: settings_helper
INFO - 2018-03-29 12:12:40 --> Helper loaded: permission_helper
INFO - 2018-03-29 12:12:40 --> Helper loaded: users_helper
INFO - 2018-03-29 12:12:41 --> Database Driver Class Initialized
DEBUG - 2018-03-29 12:12:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 12:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 12:12:41 --> Helper loaded: form_helper
INFO - 2018-03-29 12:12:41 --> Form Validation Class Initialized
INFO - 2018-03-29 12:12:41 --> Controller Class Initialized
INFO - 2018-03-29 12:12:41 --> Model Class Initialized
INFO - 2018-03-29 12:12:41 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 12:12:41 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 12:12:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 12:12:41 --> Model Class Initialized
INFO - 2018-03-29 12:12:41 --> Model Class Initialized
INFO - 2018-03-29 12:12:41 --> Model Class Initialized
INFO - 2018-03-29 12:12:41 --> Model Class Initialized
INFO - 2018-03-29 12:12:41 --> Model Class Initialized
INFO - 2018-03-29 12:12:41 --> Model Class Initialized
INFO - 2018-03-29 12:12:41 --> Model Class Initialized
INFO - 2018-03-29 12:12:41 --> Model Class Initialized
INFO - 2018-03-29 12:12:41 --> Model Class Initialized
INFO - 2018-03-29 12:12:41 --> Model Class Initialized
INFO - 2018-03-29 12:12:41 --> Model Class Initialized
INFO - 2018-03-29 12:12:41 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 12:12:41 --> Model Class Initialized
INFO - 2018-03-29 12:12:41 --> Final output sent to browser
DEBUG - 2018-03-29 12:12:41 --> Total execution time: 1.5875
INFO - 2018-03-29 06:42:41 --> Config Class Initialized
INFO - 2018-03-29 06:42:41 --> Hooks Class Initialized
DEBUG - 2018-03-29 06:42:41 --> UTF-8 Support Enabled
INFO - 2018-03-29 06:42:41 --> Utf8 Class Initialized
INFO - 2018-03-29 06:42:41 --> URI Class Initialized
INFO - 2018-03-29 06:42:41 --> Router Class Initialized
INFO - 2018-03-29 06:42:41 --> Output Class Initialized
INFO - 2018-03-29 06:42:41 --> Security Class Initialized
DEBUG - 2018-03-29 06:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 06:42:41 --> Input Class Initialized
INFO - 2018-03-29 06:42:41 --> Language Class Initialized
INFO - 2018-03-29 06:42:41 --> Language Class Initialized
INFO - 2018-03-29 06:42:41 --> Config Class Initialized
INFO - 2018-03-29 06:42:41 --> Loader Class Initialized
INFO - 2018-03-29 12:12:41 --> Helper loaded: url_helper
INFO - 2018-03-29 12:12:41 --> Helper loaded: notification_helper
INFO - 2018-03-29 12:12:41 --> Helper loaded: settings_helper
INFO - 2018-03-29 12:12:41 --> Helper loaded: permission_helper
INFO - 2018-03-29 12:12:41 --> Helper loaded: users_helper
INFO - 2018-03-29 12:12:42 --> Database Driver Class Initialized
DEBUG - 2018-03-29 12:12:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 12:12:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 12:12:42 --> Helper loaded: form_helper
INFO - 2018-03-29 12:12:42 --> Form Validation Class Initialized
INFO - 2018-03-29 12:12:42 --> Controller Class Initialized
INFO - 2018-03-29 12:12:42 --> Model Class Initialized
INFO - 2018-03-29 12:12:42 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 12:12:42 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 12:12:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 12:12:42 --> Model Class Initialized
INFO - 2018-03-29 12:12:42 --> Model Class Initialized
INFO - 2018-03-29 12:12:42 --> Model Class Initialized
INFO - 2018-03-29 12:12:42 --> Model Class Initialized
INFO - 2018-03-29 12:12:42 --> Model Class Initialized
INFO - 2018-03-29 12:12:42 --> Model Class Initialized
INFO - 2018-03-29 12:12:42 --> Model Class Initialized
INFO - 2018-03-29 12:12:42 --> Model Class Initialized
INFO - 2018-03-29 12:12:42 --> Model Class Initialized
INFO - 2018-03-29 12:12:42 --> Model Class Initialized
INFO - 2018-03-29 12:12:42 --> Model Class Initialized
INFO - 2018-03-29 12:12:42 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 12:12:42 --> Model Class Initialized
INFO - 2018-03-29 12:12:42 --> Final output sent to browser
DEBUG - 2018-03-29 12:12:42 --> Total execution time: 0.5423
INFO - 2018-03-29 06:42:46 --> Config Class Initialized
INFO - 2018-03-29 06:42:46 --> Hooks Class Initialized
DEBUG - 2018-03-29 06:42:46 --> UTF-8 Support Enabled
INFO - 2018-03-29 06:42:46 --> Utf8 Class Initialized
INFO - 2018-03-29 06:42:46 --> URI Class Initialized
INFO - 2018-03-29 06:42:46 --> Router Class Initialized
INFO - 2018-03-29 06:42:46 --> Output Class Initialized
INFO - 2018-03-29 06:42:46 --> Security Class Initialized
DEBUG - 2018-03-29 06:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 06:42:46 --> Input Class Initialized
INFO - 2018-03-29 06:42:46 --> Language Class Initialized
INFO - 2018-03-29 06:42:46 --> Language Class Initialized
INFO - 2018-03-29 06:42:46 --> Config Class Initialized
INFO - 2018-03-29 06:42:46 --> Loader Class Initialized
INFO - 2018-03-29 12:12:46 --> Helper loaded: url_helper
INFO - 2018-03-29 12:12:46 --> Helper loaded: notification_helper
INFO - 2018-03-29 12:12:46 --> Helper loaded: settings_helper
INFO - 2018-03-29 12:12:46 --> Helper loaded: permission_helper
INFO - 2018-03-29 12:12:46 --> Helper loaded: users_helper
INFO - 2018-03-29 06:42:46 --> Config Class Initialized
INFO - 2018-03-29 06:42:46 --> Hooks Class Initialized
DEBUG - 2018-03-29 06:42:46 --> UTF-8 Support Enabled
INFO - 2018-03-29 06:42:46 --> Utf8 Class Initialized
INFO - 2018-03-29 06:42:47 --> URI Class Initialized
INFO - 2018-03-29 12:12:47 --> Database Driver Class Initialized
DEBUG - 2018-03-29 12:12:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 12:12:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 12:12:47 --> Helper loaded: form_helper
INFO - 2018-03-29 12:12:47 --> Form Validation Class Initialized
INFO - 2018-03-29 12:12:47 --> Controller Class Initialized
INFO - 2018-03-29 12:12:47 --> Model Class Initialized
INFO - 2018-03-29 12:12:47 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 12:12:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 12:12:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 12:12:47 --> Model Class Initialized
INFO - 2018-03-29 12:12:47 --> Model Class Initialized
INFO - 2018-03-29 12:12:47 --> Model Class Initialized
INFO - 2018-03-29 12:12:47 --> Model Class Initialized
INFO - 2018-03-29 12:12:47 --> Model Class Initialized
INFO - 2018-03-29 12:12:47 --> Model Class Initialized
INFO - 2018-03-29 12:12:47 --> Model Class Initialized
INFO - 2018-03-29 06:42:47 --> Router Class Initialized
INFO - 2018-03-29 12:12:47 --> Model Class Initialized
INFO - 2018-03-29 12:12:47 --> Model Class Initialized
INFO - 2018-03-29 12:12:47 --> Model Class Initialized
INFO - 2018-03-29 12:12:47 --> Model Class Initialized
INFO - 2018-03-29 12:12:47 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 12:12:47 --> Final output sent to browser
DEBUG - 2018-03-29 12:12:47 --> Total execution time: 0.7434
INFO - 2018-03-29 06:42:47 --> Output Class Initialized
INFO - 2018-03-29 06:42:47 --> Security Class Initialized
DEBUG - 2018-03-29 06:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 06:42:47 --> Input Class Initialized
INFO - 2018-03-29 06:42:47 --> Language Class Initialized
INFO - 2018-03-29 06:42:48 --> Language Class Initialized
INFO - 2018-03-29 06:42:48 --> Config Class Initialized
INFO - 2018-03-29 06:42:48 --> Loader Class Initialized
INFO - 2018-03-29 12:12:48 --> Helper loaded: url_helper
INFO - 2018-03-29 12:12:48 --> Helper loaded: notification_helper
INFO - 2018-03-29 12:12:48 --> Helper loaded: settings_helper
INFO - 2018-03-29 12:12:48 --> Helper loaded: permission_helper
INFO - 2018-03-29 12:12:48 --> Helper loaded: users_helper
INFO - 2018-03-29 12:12:48 --> Database Driver Class Initialized
DEBUG - 2018-03-29 12:12:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 12:12:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 12:12:48 --> Helper loaded: form_helper
INFO - 2018-03-29 12:12:48 --> Form Validation Class Initialized
INFO - 2018-03-29 12:12:48 --> Controller Class Initialized
INFO - 2018-03-29 06:42:48 --> Config Class Initialized
INFO - 2018-03-29 06:42:48 --> Hooks Class Initialized
DEBUG - 2018-03-29 06:42:48 --> UTF-8 Support Enabled
INFO - 2018-03-29 06:42:48 --> Utf8 Class Initialized
INFO - 2018-03-29 06:42:48 --> URI Class Initialized
INFO - 2018-03-29 12:12:48 --> Model Class Initialized
INFO - 2018-03-29 12:12:48 --> Helper loaded: inflector_helper
INFO - 2018-03-29 06:42:48 --> Router Class Initialized
DEBUG - 2018-03-29 12:12:48 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 06:42:48 --> Output Class Initialized
INFO - 2018-03-29 12:12:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 12:12:48 --> Model Class Initialized
INFO - 2018-03-29 12:12:48 --> Model Class Initialized
INFO - 2018-03-29 06:42:48 --> Security Class Initialized
INFO - 2018-03-29 12:12:48 --> Model Class Initialized
INFO - 2018-03-29 12:12:48 --> Model Class Initialized
INFO - 2018-03-29 12:12:48 --> Model Class Initialized
INFO - 2018-03-29 12:12:48 --> Model Class Initialized
INFO - 2018-03-29 12:12:48 --> Model Class Initialized
INFO - 2018-03-29 12:12:48 --> Model Class Initialized
INFO - 2018-03-29 12:12:48 --> Model Class Initialized
INFO - 2018-03-29 12:12:48 --> Model Class Initialized
INFO - 2018-03-29 12:12:49 --> Model Class Initialized
INFO - 2018-03-29 12:12:49 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 12:12:49 --> Model Class Initialized
DEBUG - 2018-03-29 06:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 06:42:49 --> Input Class Initialized
INFO - 2018-03-29 12:12:49 --> Final output sent to browser
DEBUG - 2018-03-29 12:12:49 --> Total execution time: 2.5096
INFO - 2018-03-29 06:42:49 --> Language Class Initialized
INFO - 2018-03-29 06:42:49 --> Language Class Initialized
INFO - 2018-03-29 06:42:49 --> Config Class Initialized
INFO - 2018-03-29 06:42:49 --> Loader Class Initialized
INFO - 2018-03-29 12:12:49 --> Helper loaded: url_helper
INFO - 2018-03-29 12:12:49 --> Helper loaded: notification_helper
INFO - 2018-03-29 12:12:49 --> Helper loaded: settings_helper
INFO - 2018-03-29 12:12:49 --> Helper loaded: permission_helper
INFO - 2018-03-29 12:12:49 --> Helper loaded: users_helper
INFO - 2018-03-29 12:12:49 --> Database Driver Class Initialized
DEBUG - 2018-03-29 12:12:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 12:12:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 12:12:49 --> Helper loaded: form_helper
INFO - 2018-03-29 12:12:49 --> Form Validation Class Initialized
INFO - 2018-03-29 12:12:49 --> Controller Class Initialized
INFO - 2018-03-29 12:12:49 --> Model Class Initialized
INFO - 2018-03-29 12:12:49 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 12:12:49 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 12:12:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 12:12:49 --> Model Class Initialized
INFO - 2018-03-29 12:12:49 --> Model Class Initialized
INFO - 2018-03-29 12:12:49 --> Model Class Initialized
INFO - 2018-03-29 12:12:49 --> Model Class Initialized
INFO - 2018-03-29 12:12:49 --> Model Class Initialized
INFO - 2018-03-29 12:12:49 --> Model Class Initialized
INFO - 2018-03-29 12:12:49 --> Model Class Initialized
INFO - 2018-03-29 12:12:49 --> Model Class Initialized
INFO - 2018-03-29 12:12:49 --> Model Class Initialized
INFO - 2018-03-29 12:12:49 --> Model Class Initialized
INFO - 2018-03-29 12:12:49 --> Model Class Initialized
INFO - 2018-03-29 12:12:49 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 12:12:49 --> Model Class Initialized
INFO - 2018-03-29 12:12:49 --> Final output sent to browser
DEBUG - 2018-03-29 12:12:49 --> Total execution time: 0.6876
INFO - 2018-03-29 06:46:30 --> Config Class Initialized
INFO - 2018-03-29 06:46:30 --> Hooks Class Initialized
DEBUG - 2018-03-29 06:46:30 --> UTF-8 Support Enabled
INFO - 2018-03-29 06:46:30 --> Utf8 Class Initialized
INFO - 2018-03-29 06:46:30 --> URI Class Initialized
INFO - 2018-03-29 06:46:30 --> Router Class Initialized
INFO - 2018-03-29 06:46:30 --> Output Class Initialized
INFO - 2018-03-29 06:46:30 --> Security Class Initialized
DEBUG - 2018-03-29 06:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 06:46:30 --> Input Class Initialized
INFO - 2018-03-29 06:46:30 --> Language Class Initialized
INFO - 2018-03-29 06:46:30 --> Language Class Initialized
INFO - 2018-03-29 06:46:30 --> Config Class Initialized
INFO - 2018-03-29 06:46:30 --> Loader Class Initialized
INFO - 2018-03-29 12:16:30 --> Helper loaded: url_helper
INFO - 2018-03-29 12:16:30 --> Helper loaded: notification_helper
INFO - 2018-03-29 12:16:30 --> Helper loaded: settings_helper
INFO - 2018-03-29 12:16:30 --> Helper loaded: permission_helper
INFO - 2018-03-29 12:16:30 --> Helper loaded: users_helper
INFO - 2018-03-29 12:16:30 --> Database Driver Class Initialized
DEBUG - 2018-03-29 12:16:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 12:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 12:16:30 --> Helper loaded: form_helper
INFO - 2018-03-29 12:16:30 --> Form Validation Class Initialized
INFO - 2018-03-29 12:16:30 --> Controller Class Initialized
INFO - 2018-03-29 12:16:30 --> Model Class Initialized
INFO - 2018-03-29 12:16:30 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 12:16:30 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 12:16:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 12:16:30 --> Model Class Initialized
INFO - 2018-03-29 12:16:30 --> Model Class Initialized
INFO - 2018-03-29 12:16:30 --> Model Class Initialized
INFO - 2018-03-29 12:16:30 --> Model Class Initialized
INFO - 2018-03-29 12:16:30 --> Model Class Initialized
INFO - 2018-03-29 12:16:30 --> Model Class Initialized
INFO - 2018-03-29 12:16:30 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 12:16:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-29 12:16:30 --> Final output sent to browser
DEBUG - 2018-03-29 12:16:30 --> Total execution time: 0.2799
INFO - 2018-03-29 06:46:31 --> Config Class Initialized
INFO - 2018-03-29 06:46:31 --> Hooks Class Initialized
DEBUG - 2018-03-29 06:46:31 --> UTF-8 Support Enabled
INFO - 2018-03-29 06:46:31 --> Utf8 Class Initialized
INFO - 2018-03-29 06:46:31 --> URI Class Initialized
INFO - 2018-03-29 06:46:31 --> Router Class Initialized
INFO - 2018-03-29 06:46:31 --> Output Class Initialized
INFO - 2018-03-29 06:46:31 --> Security Class Initialized
DEBUG - 2018-03-29 06:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 06:46:31 --> Input Class Initialized
INFO - 2018-03-29 06:46:31 --> Language Class Initialized
INFO - 2018-03-29 06:46:31 --> Language Class Initialized
INFO - 2018-03-29 06:46:31 --> Config Class Initialized
INFO - 2018-03-29 06:46:31 --> Loader Class Initialized
INFO - 2018-03-29 12:16:31 --> Helper loaded: url_helper
INFO - 2018-03-29 12:16:31 --> Helper loaded: notification_helper
INFO - 2018-03-29 12:16:31 --> Helper loaded: settings_helper
INFO - 2018-03-29 12:16:31 --> Helper loaded: permission_helper
INFO - 2018-03-29 12:16:31 --> Helper loaded: users_helper
INFO - 2018-03-29 12:16:31 --> Database Driver Class Initialized
DEBUG - 2018-03-29 12:16:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 12:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 06:46:31 --> Config Class Initialized
INFO - 2018-03-29 06:46:31 --> Hooks Class Initialized
INFO - 2018-03-29 12:16:31 --> Helper loaded: form_helper
INFO - 2018-03-29 12:16:31 --> Form Validation Class Initialized
INFO - 2018-03-29 12:16:31 --> Controller Class Initialized
DEBUG - 2018-03-29 06:46:31 --> UTF-8 Support Enabled
INFO - 2018-03-29 06:46:31 --> Utf8 Class Initialized
INFO - 2018-03-29 06:46:31 --> URI Class Initialized
INFO - 2018-03-29 06:46:31 --> Router Class Initialized
INFO - 2018-03-29 06:46:31 --> Output Class Initialized
INFO - 2018-03-29 06:46:31 --> Security Class Initialized
INFO - 2018-03-29 12:16:31 --> Model Class Initialized
DEBUG - 2018-03-29 06:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 06:46:31 --> Input Class Initialized
INFO - 2018-03-29 12:16:31 --> Helper loaded: inflector_helper
INFO - 2018-03-29 06:46:31 --> Language Class Initialized
DEBUG - 2018-03-29 12:16:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 12:16:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 12:16:31 --> Model Class Initialized
INFO - 2018-03-29 12:16:31 --> Model Class Initialized
INFO - 2018-03-29 12:16:31 --> Model Class Initialized
INFO - 2018-03-29 12:16:31 --> Model Class Initialized
INFO - 2018-03-29 12:16:31 --> Model Class Initialized
INFO - 2018-03-29 06:46:31 --> Language Class Initialized
INFO - 2018-03-29 06:46:31 --> Config Class Initialized
INFO - 2018-03-29 06:46:31 --> Loader Class Initialized
INFO - 2018-03-29 12:16:31 --> Model Class Initialized
INFO - 2018-03-29 12:16:31 --> Model Class Initialized
INFO - 2018-03-29 12:16:31 --> Helper loaded: url_helper
INFO - 2018-03-29 12:16:31 --> Model Class Initialized
INFO - 2018-03-29 12:16:31 --> Model Class Initialized
INFO - 2018-03-29 12:16:31 --> Model Class Initialized
INFO - 2018-03-29 12:16:31 --> Helper loaded: notification_helper
INFO - 2018-03-29 12:16:31 --> Helper loaded: settings_helper
INFO - 2018-03-29 12:16:31 --> Helper loaded: permission_helper
INFO - 2018-03-29 12:16:31 --> Helper loaded: users_helper
INFO - 2018-03-29 12:16:31 --> Model Class Initialized
INFO - 2018-03-29 12:16:31 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 12:16:31 --> Model Class Initialized
INFO - 2018-03-29 12:16:31 --> Database Driver Class Initialized
INFO - 2018-03-29 12:16:31 --> Final output sent to browser
DEBUG - 2018-03-29 12:16:31 --> Total execution time: 0.3411
DEBUG - 2018-03-29 12:16:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 12:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 12:16:31 --> Helper loaded: form_helper
INFO - 2018-03-29 12:16:31 --> Form Validation Class Initialized
INFO - 2018-03-29 12:16:31 --> Controller Class Initialized
INFO - 2018-03-29 12:16:31 --> Model Class Initialized
INFO - 2018-03-29 12:16:31 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 12:16:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 12:16:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 12:16:31 --> Model Class Initialized
INFO - 2018-03-29 12:16:31 --> Model Class Initialized
INFO - 2018-03-29 12:16:31 --> Model Class Initialized
INFO - 2018-03-29 12:16:31 --> Model Class Initialized
INFO - 2018-03-29 12:16:31 --> Model Class Initialized
INFO - 2018-03-29 12:16:31 --> Model Class Initialized
INFO - 2018-03-29 12:16:31 --> Model Class Initialized
INFO - 2018-03-29 12:16:31 --> Model Class Initialized
INFO - 2018-03-29 12:16:31 --> Model Class Initialized
INFO - 2018-03-29 12:16:31 --> Model Class Initialized
INFO - 2018-03-29 12:16:31 --> Model Class Initialized
INFO - 2018-03-29 12:16:31 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 12:16:31 --> Model Class Initialized
INFO - 2018-03-29 12:16:31 --> Final output sent to browser
DEBUG - 2018-03-29 12:16:31 --> Total execution time: 0.1336
INFO - 2018-03-29 06:46:33 --> Config Class Initialized
INFO - 2018-03-29 06:46:33 --> Hooks Class Initialized
DEBUG - 2018-03-29 06:46:33 --> UTF-8 Support Enabled
INFO - 2018-03-29 06:46:33 --> Utf8 Class Initialized
INFO - 2018-03-29 06:46:33 --> URI Class Initialized
INFO - 2018-03-29 06:46:33 --> Router Class Initialized
INFO - 2018-03-29 06:46:33 --> Output Class Initialized
INFO - 2018-03-29 06:46:33 --> Security Class Initialized
DEBUG - 2018-03-29 06:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 06:46:33 --> Input Class Initialized
INFO - 2018-03-29 06:46:33 --> Language Class Initialized
INFO - 2018-03-29 06:46:33 --> Language Class Initialized
INFO - 2018-03-29 06:46:33 --> Config Class Initialized
INFO - 2018-03-29 06:46:33 --> Loader Class Initialized
INFO - 2018-03-29 12:16:33 --> Helper loaded: url_helper
INFO - 2018-03-29 12:16:33 --> Helper loaded: notification_helper
INFO - 2018-03-29 12:16:33 --> Helper loaded: settings_helper
INFO - 2018-03-29 12:16:33 --> Helper loaded: permission_helper
INFO - 2018-03-29 12:16:33 --> Helper loaded: users_helper
INFO - 2018-03-29 06:46:33 --> Config Class Initialized
INFO - 2018-03-29 06:46:33 --> Hooks Class Initialized
DEBUG - 2018-03-29 06:46:33 --> UTF-8 Support Enabled
INFO - 2018-03-29 06:46:33 --> Utf8 Class Initialized
INFO - 2018-03-29 06:46:33 --> URI Class Initialized
INFO - 2018-03-29 06:46:33 --> Router Class Initialized
INFO - 2018-03-29 06:46:34 --> Output Class Initialized
INFO - 2018-03-29 06:46:34 --> Security Class Initialized
DEBUG - 2018-03-29 06:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 06:46:34 --> Input Class Initialized
INFO - 2018-03-29 06:46:34 --> Language Class Initialized
INFO - 2018-03-29 06:46:34 --> Language Class Initialized
INFO - 2018-03-29 06:46:34 --> Config Class Initialized
INFO - 2018-03-29 06:46:34 --> Loader Class Initialized
INFO - 2018-03-29 12:16:34 --> Helper loaded: url_helper
INFO - 2018-03-29 12:16:34 --> Helper loaded: notification_helper
INFO - 2018-03-29 12:16:34 --> Helper loaded: settings_helper
INFO - 2018-03-29 12:16:34 --> Helper loaded: permission_helper
INFO - 2018-03-29 12:16:34 --> Helper loaded: users_helper
INFO - 2018-03-29 12:16:34 --> Database Driver Class Initialized
DEBUG - 2018-03-29 12:16:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 12:16:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 12:16:34 --> Helper loaded: form_helper
INFO - 2018-03-29 12:16:34 --> Form Validation Class Initialized
INFO - 2018-03-29 12:16:34 --> Controller Class Initialized
INFO - 2018-03-29 12:16:34 --> Model Class Initialized
INFO - 2018-03-29 12:16:34 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 12:16:34 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 12:16:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 12:16:34 --> Model Class Initialized
INFO - 2018-03-29 12:16:34 --> Model Class Initialized
INFO - 2018-03-29 12:16:34 --> Model Class Initialized
INFO - 2018-03-29 12:16:34 --> Model Class Initialized
INFO - 2018-03-29 12:16:34 --> Model Class Initialized
INFO - 2018-03-29 12:16:34 --> Model Class Initialized
INFO - 2018-03-29 12:16:34 --> Model Class Initialized
INFO - 2018-03-29 12:16:34 --> Model Class Initialized
INFO - 2018-03-29 12:16:34 --> Model Class Initialized
INFO - 2018-03-29 12:16:34 --> Model Class Initialized
INFO - 2018-03-29 12:16:34 --> Model Class Initialized
INFO - 2018-03-29 12:16:34 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 12:16:34 --> Final output sent to browser
DEBUG - 2018-03-29 12:16:34 --> Total execution time: 0.2315
INFO - 2018-03-29 12:16:34 --> Database Driver Class Initialized
DEBUG - 2018-03-29 12:16:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 12:16:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 12:16:34 --> Helper loaded: form_helper
INFO - 2018-03-29 12:16:34 --> Form Validation Class Initialized
INFO - 2018-03-29 12:16:34 --> Controller Class Initialized
INFO - 2018-03-29 12:16:35 --> Model Class Initialized
INFO - 2018-03-29 12:16:35 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 12:16:35 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 12:16:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 12:16:35 --> Model Class Initialized
INFO - 2018-03-29 12:16:35 --> Model Class Initialized
INFO - 2018-03-29 12:16:35 --> Model Class Initialized
INFO - 2018-03-29 12:16:35 --> Model Class Initialized
INFO - 2018-03-29 12:16:35 --> Model Class Initialized
INFO - 2018-03-29 12:16:35 --> Model Class Initialized
INFO - 2018-03-29 12:16:35 --> Model Class Initialized
INFO - 2018-03-29 12:16:35 --> Model Class Initialized
INFO - 2018-03-29 12:16:35 --> Model Class Initialized
INFO - 2018-03-29 12:16:35 --> Model Class Initialized
INFO - 2018-03-29 12:16:35 --> Model Class Initialized
INFO - 2018-03-29 12:16:35 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 12:16:35 --> Model Class Initialized
INFO - 2018-03-29 12:16:35 --> Final output sent to browser
DEBUG - 2018-03-29 12:16:35 --> Total execution time: 1.5800
INFO - 2018-03-29 06:46:55 --> Config Class Initialized
INFO - 2018-03-29 06:46:55 --> Hooks Class Initialized
DEBUG - 2018-03-29 06:46:55 --> UTF-8 Support Enabled
INFO - 2018-03-29 06:46:55 --> Utf8 Class Initialized
INFO - 2018-03-29 06:46:55 --> URI Class Initialized
INFO - 2018-03-29 06:46:55 --> Router Class Initialized
INFO - 2018-03-29 06:46:55 --> Output Class Initialized
INFO - 2018-03-29 06:46:55 --> Security Class Initialized
DEBUG - 2018-03-29 06:46:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 06:46:55 --> Input Class Initialized
INFO - 2018-03-29 06:46:55 --> Language Class Initialized
INFO - 2018-03-29 06:46:55 --> Config Class Initialized
INFO - 2018-03-29 06:46:55 --> Hooks Class Initialized
DEBUG - 2018-03-29 06:46:55 --> UTF-8 Support Enabled
INFO - 2018-03-29 06:46:55 --> Utf8 Class Initialized
INFO - 2018-03-29 06:46:55 --> URI Class Initialized
INFO - 2018-03-29 06:46:55 --> Language Class Initialized
INFO - 2018-03-29 06:46:55 --> Config Class Initialized
INFO - 2018-03-29 06:46:55 --> Loader Class Initialized
INFO - 2018-03-29 06:46:55 --> Router Class Initialized
INFO - 2018-03-29 12:16:55 --> Helper loaded: url_helper
INFO - 2018-03-29 12:16:55 --> Helper loaded: notification_helper
INFO - 2018-03-29 12:16:55 --> Helper loaded: settings_helper
INFO - 2018-03-29 06:46:55 --> Output Class Initialized
INFO - 2018-03-29 12:16:55 --> Helper loaded: permission_helper
INFO - 2018-03-29 12:16:55 --> Helper loaded: users_helper
INFO - 2018-03-29 06:46:55 --> Security Class Initialized
DEBUG - 2018-03-29 06:46:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 06:46:55 --> Input Class Initialized
INFO - 2018-03-29 06:46:55 --> Language Class Initialized
INFO - 2018-03-29 12:16:55 --> Database Driver Class Initialized
DEBUG - 2018-03-29 12:16:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 12:16:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 06:46:55 --> Language Class Initialized
INFO - 2018-03-29 06:46:55 --> Config Class Initialized
INFO - 2018-03-29 06:46:55 --> Loader Class Initialized
INFO - 2018-03-29 12:16:55 --> Helper loaded: form_helper
INFO - 2018-03-29 12:16:55 --> Form Validation Class Initialized
INFO - 2018-03-29 12:16:55 --> Controller Class Initialized
INFO - 2018-03-29 12:16:55 --> Helper loaded: url_helper
INFO - 2018-03-29 12:16:55 --> Helper loaded: notification_helper
INFO - 2018-03-29 12:16:55 --> Helper loaded: settings_helper
INFO - 2018-03-29 12:16:55 --> Helper loaded: permission_helper
INFO - 2018-03-29 12:16:55 --> Helper loaded: users_helper
INFO - 2018-03-29 12:16:55 --> Model Class Initialized
INFO - 2018-03-29 12:16:55 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 12:16:55 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 12:16:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 12:16:55 --> Model Class Initialized
INFO - 2018-03-29 12:16:55 --> Model Class Initialized
INFO - 2018-03-29 12:16:55 --> Database Driver Class Initialized
INFO - 2018-03-29 12:16:55 --> Model Class Initialized
INFO - 2018-03-29 12:16:55 --> Model Class Initialized
INFO - 2018-03-29 12:16:55 --> Final output sent to browser
DEBUG - 2018-03-29 12:16:55 --> Total execution time: 0.3694
DEBUG - 2018-03-29 12:16:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 12:16:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 12:16:55 --> Helper loaded: form_helper
INFO - 2018-03-29 12:16:55 --> Form Validation Class Initialized
INFO - 2018-03-29 12:16:55 --> Controller Class Initialized
INFO - 2018-03-29 12:16:55 --> Model Class Initialized
INFO - 2018-03-29 12:16:55 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 12:16:55 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 12:16:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 12:16:55 --> Model Class Initialized
INFO - 2018-03-29 12:16:55 --> Model Class Initialized
INFO - 2018-03-29 12:16:55 --> Model Class Initialized
INFO - 2018-03-29 12:16:55 --> Model Class Initialized
INFO - 2018-03-29 12:16:55 --> Final output sent to browser
DEBUG - 2018-03-29 12:16:55 --> Total execution time: 0.3725
INFO - 2018-03-29 06:57:06 --> Config Class Initialized
INFO - 2018-03-29 06:57:06 --> Hooks Class Initialized
DEBUG - 2018-03-29 06:57:06 --> UTF-8 Support Enabled
INFO - 2018-03-29 06:57:06 --> Utf8 Class Initialized
INFO - 2018-03-29 06:57:06 --> URI Class Initialized
INFO - 2018-03-29 06:57:06 --> Router Class Initialized
INFO - 2018-03-29 06:57:06 --> Output Class Initialized
INFO - 2018-03-29 06:57:06 --> Security Class Initialized
DEBUG - 2018-03-29 06:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 06:57:06 --> Input Class Initialized
INFO - 2018-03-29 06:57:06 --> Language Class Initialized
INFO - 2018-03-29 06:57:06 --> Language Class Initialized
INFO - 2018-03-29 06:57:06 --> Config Class Initialized
INFO - 2018-03-29 06:57:06 --> Loader Class Initialized
INFO - 2018-03-29 12:27:06 --> Helper loaded: url_helper
INFO - 2018-03-29 12:27:06 --> Helper loaded: notification_helper
INFO - 2018-03-29 12:27:06 --> Helper loaded: settings_helper
INFO - 2018-03-29 12:27:06 --> Helper loaded: permission_helper
INFO - 2018-03-29 12:27:06 --> Helper loaded: users_helper
INFO - 2018-03-29 12:27:06 --> Database Driver Class Initialized
DEBUG - 2018-03-29 12:27:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 12:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 12:27:06 --> Helper loaded: form_helper
INFO - 2018-03-29 12:27:06 --> Form Validation Class Initialized
INFO - 2018-03-29 12:27:06 --> Controller Class Initialized
INFO - 2018-03-29 12:27:06 --> Model Class Initialized
INFO - 2018-03-29 12:27:06 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 12:27:06 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 12:27:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 12:27:06 --> Model Class Initialized
INFO - 2018-03-29 12:27:06 --> Model Class Initialized
INFO - 2018-03-29 12:27:06 --> Model Class Initialized
INFO - 2018-03-29 12:27:06 --> Model Class Initialized
INFO - 2018-03-29 12:27:06 --> Model Class Initialized
INFO - 2018-03-29 12:27:06 --> Model Class Initialized
INFO - 2018-03-29 12:27:06 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 12:27:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-29 12:27:06 --> Final output sent to browser
DEBUG - 2018-03-29 12:27:06 --> Total execution time: 0.1904
INFO - 2018-03-29 06:57:07 --> Config Class Initialized
INFO - 2018-03-29 06:57:07 --> Hooks Class Initialized
DEBUG - 2018-03-29 06:57:07 --> UTF-8 Support Enabled
INFO - 2018-03-29 06:57:07 --> Utf8 Class Initialized
INFO - 2018-03-29 06:57:07 --> URI Class Initialized
INFO - 2018-03-29 06:57:07 --> Router Class Initialized
INFO - 2018-03-29 06:57:07 --> Output Class Initialized
INFO - 2018-03-29 06:57:07 --> Security Class Initialized
DEBUG - 2018-03-29 06:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 06:57:07 --> Input Class Initialized
INFO - 2018-03-29 06:57:07 --> Language Class Initialized
INFO - 2018-03-29 06:57:07 --> Language Class Initialized
INFO - 2018-03-29 06:57:07 --> Config Class Initialized
INFO - 2018-03-29 06:57:07 --> Loader Class Initialized
INFO - 2018-03-29 12:27:07 --> Helper loaded: url_helper
INFO - 2018-03-29 12:27:07 --> Helper loaded: notification_helper
INFO - 2018-03-29 12:27:07 --> Helper loaded: settings_helper
INFO - 2018-03-29 12:27:07 --> Helper loaded: permission_helper
INFO - 2018-03-29 12:27:07 --> Helper loaded: users_helper
INFO - 2018-03-29 12:27:07 --> Database Driver Class Initialized
DEBUG - 2018-03-29 12:27:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 12:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 12:27:07 --> Helper loaded: form_helper
INFO - 2018-03-29 12:27:07 --> Form Validation Class Initialized
INFO - 2018-03-29 12:27:07 --> Controller Class Initialized
INFO - 2018-03-29 12:27:07 --> Model Class Initialized
INFO - 2018-03-29 12:27:07 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 12:27:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 12:27:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 12:27:07 --> Model Class Initialized
INFO - 2018-03-29 12:27:07 --> Model Class Initialized
INFO - 2018-03-29 12:27:07 --> Model Class Initialized
INFO - 2018-03-29 12:27:07 --> Model Class Initialized
INFO - 2018-03-29 12:27:07 --> Model Class Initialized
INFO - 2018-03-29 12:27:07 --> Model Class Initialized
INFO - 2018-03-29 12:27:07 --> Model Class Initialized
INFO - 2018-03-29 12:27:07 --> Model Class Initialized
INFO - 2018-03-29 12:27:07 --> Model Class Initialized
INFO - 2018-03-29 12:27:07 --> Model Class Initialized
INFO - 2018-03-29 12:27:07 --> Model Class Initialized
INFO - 2018-03-29 12:27:07 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 12:27:07 --> Model Class Initialized
INFO - 2018-03-29 12:27:07 --> Final output sent to browser
DEBUG - 2018-03-29 12:27:07 --> Total execution time: 0.1386
INFO - 2018-03-29 06:57:08 --> Config Class Initialized
INFO - 2018-03-29 06:57:08 --> Hooks Class Initialized
DEBUG - 2018-03-29 06:57:08 --> UTF-8 Support Enabled
INFO - 2018-03-29 06:57:08 --> Utf8 Class Initialized
INFO - 2018-03-29 06:57:08 --> URI Class Initialized
INFO - 2018-03-29 06:57:08 --> Router Class Initialized
INFO - 2018-03-29 06:57:08 --> Output Class Initialized
INFO - 2018-03-29 06:57:08 --> Security Class Initialized
DEBUG - 2018-03-29 06:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 06:57:09 --> Input Class Initialized
INFO - 2018-03-29 06:57:09 --> Language Class Initialized
INFO - 2018-03-29 06:57:09 --> Language Class Initialized
INFO - 2018-03-29 06:57:09 --> Config Class Initialized
INFO - 2018-03-29 06:57:09 --> Loader Class Initialized
INFO - 2018-03-29 06:57:09 --> Config Class Initialized
INFO - 2018-03-29 06:57:09 --> Hooks Class Initialized
DEBUG - 2018-03-29 06:57:09 --> UTF-8 Support Enabled
INFO - 2018-03-29 06:57:09 --> Utf8 Class Initialized
INFO - 2018-03-29 06:57:09 --> URI Class Initialized
INFO - 2018-03-29 06:57:09 --> Router Class Initialized
INFO - 2018-03-29 06:57:09 --> Output Class Initialized
INFO - 2018-03-29 12:27:09 --> Helper loaded: url_helper
INFO - 2018-03-29 12:27:09 --> Helper loaded: notification_helper
INFO - 2018-03-29 12:27:09 --> Helper loaded: settings_helper
INFO - 2018-03-29 12:27:09 --> Helper loaded: permission_helper
INFO - 2018-03-29 06:57:09 --> Security Class Initialized
DEBUG - 2018-03-29 06:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 06:57:09 --> Input Class Initialized
INFO - 2018-03-29 06:57:09 --> Language Class Initialized
INFO - 2018-03-29 06:57:09 --> Language Class Initialized
INFO - 2018-03-29 06:57:09 --> Config Class Initialized
INFO - 2018-03-29 06:57:09 --> Loader Class Initialized
INFO - 2018-03-29 12:27:09 --> Helper loaded: url_helper
INFO - 2018-03-29 12:27:09 --> Helper loaded: notification_helper
INFO - 2018-03-29 12:27:09 --> Helper loaded: settings_helper
INFO - 2018-03-29 12:27:09 --> Helper loaded: permission_helper
INFO - 2018-03-29 12:27:09 --> Helper loaded: users_helper
INFO - 2018-03-29 12:27:09 --> Database Driver Class Initialized
DEBUG - 2018-03-29 12:27:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 12:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 12:27:09 --> Helper loaded: form_helper
INFO - 2018-03-29 12:27:09 --> Form Validation Class Initialized
INFO - 2018-03-29 12:27:09 --> Controller Class Initialized
INFO - 2018-03-29 12:27:09 --> Model Class Initialized
INFO - 2018-03-29 12:27:09 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 12:27:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 12:27:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 12:27:09 --> Model Class Initialized
INFO - 2018-03-29 12:27:09 --> Model Class Initialized
INFO - 2018-03-29 12:27:09 --> Model Class Initialized
INFO - 2018-03-29 12:27:09 --> Model Class Initialized
INFO - 2018-03-29 12:27:09 --> Model Class Initialized
INFO - 2018-03-29 12:27:09 --> Model Class Initialized
INFO - 2018-03-29 12:27:09 --> Model Class Initialized
INFO - 2018-03-29 12:27:09 --> Model Class Initialized
INFO - 2018-03-29 12:27:09 --> Model Class Initialized
INFO - 2018-03-29 12:27:09 --> Model Class Initialized
INFO - 2018-03-29 12:27:09 --> Model Class Initialized
INFO - 2018-03-29 12:27:09 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 12:27:09 --> Model Class Initialized
INFO - 2018-03-29 12:27:09 --> Final output sent to browser
DEBUG - 2018-03-29 12:27:09 --> Total execution time: 0.1562
INFO - 2018-03-29 12:27:09 --> Helper loaded: users_helper
INFO - 2018-03-29 12:27:10 --> Database Driver Class Initialized
DEBUG - 2018-03-29 12:27:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 12:27:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 12:27:10 --> Helper loaded: form_helper
INFO - 2018-03-29 12:27:10 --> Form Validation Class Initialized
INFO - 2018-03-29 12:27:10 --> Controller Class Initialized
INFO - 2018-03-29 12:27:10 --> Model Class Initialized
INFO - 2018-03-29 12:27:10 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 12:27:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 12:27:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 12:27:10 --> Model Class Initialized
INFO - 2018-03-29 12:27:10 --> Model Class Initialized
INFO - 2018-03-29 12:27:10 --> Model Class Initialized
INFO - 2018-03-29 12:27:10 --> Model Class Initialized
INFO - 2018-03-29 12:27:10 --> Model Class Initialized
INFO - 2018-03-29 12:27:10 --> Model Class Initialized
INFO - 2018-03-29 12:27:10 --> Model Class Initialized
INFO - 2018-03-29 12:27:10 --> Model Class Initialized
INFO - 2018-03-29 12:27:10 --> Model Class Initialized
INFO - 2018-03-29 12:27:10 --> Model Class Initialized
INFO - 2018-03-29 12:27:10 --> Model Class Initialized
INFO - 2018-03-29 12:27:10 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 12:27:10 --> Model Class Initialized
INFO - 2018-03-29 12:27:10 --> Final output sent to browser
DEBUG - 2018-03-29 12:27:10 --> Total execution time: 2.0257
INFO - 2018-03-29 06:57:23 --> Config Class Initialized
INFO - 2018-03-29 06:57:23 --> Hooks Class Initialized
DEBUG - 2018-03-29 06:57:23 --> UTF-8 Support Enabled
INFO - 2018-03-29 06:57:23 --> Utf8 Class Initialized
INFO - 2018-03-29 06:57:23 --> URI Class Initialized
INFO - 2018-03-29 06:57:23 --> Router Class Initialized
INFO - 2018-03-29 06:57:23 --> Output Class Initialized
INFO - 2018-03-29 06:57:23 --> Security Class Initialized
DEBUG - 2018-03-29 06:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 06:57:23 --> Input Class Initialized
INFO - 2018-03-29 06:57:23 --> Language Class Initialized
INFO - 2018-03-29 06:57:23 --> Language Class Initialized
INFO - 2018-03-29 06:57:23 --> Config Class Initialized
INFO - 2018-03-29 06:57:23 --> Loader Class Initialized
INFO - 2018-03-29 12:27:23 --> Helper loaded: url_helper
INFO - 2018-03-29 12:27:23 --> Helper loaded: notification_helper
INFO - 2018-03-29 12:27:23 --> Helper loaded: settings_helper
INFO - 2018-03-29 12:27:23 --> Helper loaded: permission_helper
INFO - 2018-03-29 12:27:23 --> Helper loaded: users_helper
INFO - 2018-03-29 12:27:23 --> Database Driver Class Initialized
DEBUG - 2018-03-29 12:27:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 12:27:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 12:27:23 --> Helper loaded: form_helper
INFO - 2018-03-29 12:27:23 --> Form Validation Class Initialized
INFO - 2018-03-29 12:27:23 --> Controller Class Initialized
INFO - 2018-03-29 12:27:23 --> Model Class Initialized
INFO - 2018-03-29 12:27:23 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 12:27:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 12:27:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 12:27:23 --> Model Class Initialized
INFO - 2018-03-29 12:27:23 --> Model Class Initialized
INFO - 2018-03-29 12:27:23 --> Model Class Initialized
INFO - 2018-03-29 12:27:23 --> Model Class Initialized
INFO - 2018-03-29 12:27:23 --> Model Class Initialized
INFO - 2018-03-29 12:27:23 --> Model Class Initialized
INFO - 2018-03-29 12:27:23 --> Model Class Initialized
INFO - 2018-03-29 12:27:23 --> Model Class Initialized
INFO - 2018-03-29 12:27:23 --> Model Class Initialized
INFO - 2018-03-29 12:27:23 --> Model Class Initialized
INFO - 2018-03-29 12:27:23 --> Model Class Initialized
INFO - 2018-03-29 12:27:23 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 12:27:23 --> Model Class Initialized
INFO - 2018-03-29 12:27:23 --> Final output sent to browser
DEBUG - 2018-03-29 12:27:23 --> Total execution time: 0.2760
INFO - 2018-03-29 06:57:24 --> Config Class Initialized
INFO - 2018-03-29 06:57:24 --> Hooks Class Initialized
DEBUG - 2018-03-29 06:57:24 --> UTF-8 Support Enabled
INFO - 2018-03-29 06:57:24 --> Utf8 Class Initialized
INFO - 2018-03-29 06:57:24 --> URI Class Initialized
INFO - 2018-03-29 06:57:25 --> Router Class Initialized
INFO - 2018-03-29 06:57:25 --> Output Class Initialized
INFO - 2018-03-29 06:57:25 --> Security Class Initialized
DEBUG - 2018-03-29 06:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 06:57:25 --> Input Class Initialized
INFO - 2018-03-29 06:57:25 --> Language Class Initialized
INFO - 2018-03-29 06:57:26 --> Config Class Initialized
INFO - 2018-03-29 06:57:26 --> Hooks Class Initialized
DEBUG - 2018-03-29 06:57:26 --> UTF-8 Support Enabled
INFO - 2018-03-29 06:57:26 --> Utf8 Class Initialized
INFO - 2018-03-29 06:57:26 --> URI Class Initialized
INFO - 2018-03-29 06:57:26 --> Router Class Initialized
INFO - 2018-03-29 06:57:26 --> Output Class Initialized
INFO - 2018-03-29 06:57:26 --> Security Class Initialized
DEBUG - 2018-03-29 06:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 06:57:26 --> Input Class Initialized
INFO - 2018-03-29 06:57:26 --> Language Class Initialized
INFO - 2018-03-29 06:57:26 --> Language Class Initialized
INFO - 2018-03-29 06:57:26 --> Config Class Initialized
INFO - 2018-03-29 06:57:26 --> Loader Class Initialized
INFO - 2018-03-29 06:57:26 --> Language Class Initialized
INFO - 2018-03-29 06:57:26 --> Config Class Initialized
INFO - 2018-03-29 06:57:26 --> Loader Class Initialized
INFO - 2018-03-29 12:27:26 --> Helper loaded: url_helper
INFO - 2018-03-29 12:27:26 --> Helper loaded: notification_helper
INFO - 2018-03-29 12:27:26 --> Helper loaded: settings_helper
INFO - 2018-03-29 12:27:26 --> Helper loaded: permission_helper
INFO - 2018-03-29 12:27:26 --> Helper loaded: users_helper
INFO - 2018-03-29 12:27:26 --> Helper loaded: url_helper
INFO - 2018-03-29 12:27:26 --> Database Driver Class Initialized
DEBUG - 2018-03-29 12:27:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 12:27:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 12:27:26 --> Helper loaded: notification_helper
INFO - 2018-03-29 12:27:26 --> Helper loaded: settings_helper
INFO - 2018-03-29 12:27:26 --> Helper loaded: form_helper
INFO - 2018-03-29 12:27:26 --> Form Validation Class Initialized
INFO - 2018-03-29 12:27:26 --> Controller Class Initialized
INFO - 2018-03-29 12:27:26 --> Helper loaded: permission_helper
INFO - 2018-03-29 12:27:26 --> Helper loaded: users_helper
INFO - 2018-03-29 12:27:26 --> Model Class Initialized
INFO - 2018-03-29 12:27:26 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 12:27:26 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 12:27:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 12:27:26 --> Model Class Initialized
INFO - 2018-03-29 12:27:26 --> Model Class Initialized
INFO - 2018-03-29 12:27:26 --> Model Class Initialized
INFO - 2018-03-29 12:27:26 --> Model Class Initialized
INFO - 2018-03-29 12:27:26 --> Model Class Initialized
INFO - 2018-03-29 12:27:26 --> Model Class Initialized
INFO - 2018-03-29 12:27:26 --> Model Class Initialized
INFO - 2018-03-29 12:27:26 --> Model Class Initialized
INFO - 2018-03-29 12:27:26 --> Model Class Initialized
INFO - 2018-03-29 12:27:26 --> Model Class Initialized
INFO - 2018-03-29 12:27:26 --> Model Class Initialized
INFO - 2018-03-29 12:27:26 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 12:27:26 --> Final output sent to browser
DEBUG - 2018-03-29 12:27:26 --> Total execution time: 0.5348
INFO - 2018-03-29 12:27:26 --> Database Driver Class Initialized
DEBUG - 2018-03-29 12:27:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 12:27:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 12:27:27 --> Helper loaded: form_helper
INFO - 2018-03-29 12:27:27 --> Form Validation Class Initialized
INFO - 2018-03-29 12:27:27 --> Controller Class Initialized
INFO - 2018-03-29 12:27:27 --> Model Class Initialized
INFO - 2018-03-29 12:27:27 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 12:27:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 12:27:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 12:27:27 --> Model Class Initialized
INFO - 2018-03-29 12:27:27 --> Model Class Initialized
INFO - 2018-03-29 12:27:27 --> Model Class Initialized
INFO - 2018-03-29 12:27:27 --> Model Class Initialized
INFO - 2018-03-29 12:27:27 --> Model Class Initialized
INFO - 2018-03-29 12:27:27 --> Model Class Initialized
INFO - 2018-03-29 12:27:27 --> Model Class Initialized
INFO - 2018-03-29 12:27:27 --> Model Class Initialized
INFO - 2018-03-29 12:27:27 --> Model Class Initialized
INFO - 2018-03-29 12:27:27 --> Model Class Initialized
INFO - 2018-03-29 12:27:27 --> Model Class Initialized
INFO - 2018-03-29 12:27:27 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 12:27:27 --> Final output sent to browser
DEBUG - 2018-03-29 12:27:27 --> Total execution time: 3.3426
INFO - 2018-03-29 07:04:23 --> Config Class Initialized
INFO - 2018-03-29 07:04:23 --> Hooks Class Initialized
DEBUG - 2018-03-29 07:04:23 --> UTF-8 Support Enabled
INFO - 2018-03-29 07:04:23 --> Utf8 Class Initialized
INFO - 2018-03-29 07:04:23 --> URI Class Initialized
INFO - 2018-03-29 07:04:23 --> Router Class Initialized
INFO - 2018-03-29 07:04:23 --> Output Class Initialized
INFO - 2018-03-29 07:04:23 --> Security Class Initialized
DEBUG - 2018-03-29 07:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 07:04:23 --> Input Class Initialized
INFO - 2018-03-29 07:04:23 --> Language Class Initialized
INFO - 2018-03-29 07:04:23 --> Language Class Initialized
INFO - 2018-03-29 07:04:23 --> Config Class Initialized
INFO - 2018-03-29 07:04:23 --> Loader Class Initialized
INFO - 2018-03-29 12:34:23 --> Helper loaded: url_helper
INFO - 2018-03-29 12:34:23 --> Helper loaded: notification_helper
INFO - 2018-03-29 12:34:23 --> Helper loaded: settings_helper
INFO - 2018-03-29 12:34:23 --> Helper loaded: permission_helper
INFO - 2018-03-29 12:34:23 --> Helper loaded: users_helper
INFO - 2018-03-29 12:34:24 --> Database Driver Class Initialized
DEBUG - 2018-03-29 12:34:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 12:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 12:34:24 --> Helper loaded: form_helper
INFO - 2018-03-29 12:34:24 --> Form Validation Class Initialized
INFO - 2018-03-29 12:34:24 --> Controller Class Initialized
INFO - 2018-03-29 12:34:24 --> Model Class Initialized
INFO - 2018-03-29 12:34:24 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 12:34:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 12:34:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 12:34:24 --> Model Class Initialized
INFO - 2018-03-29 12:34:24 --> Model Class Initialized
INFO - 2018-03-29 12:34:24 --> Model Class Initialized
INFO - 2018-03-29 12:34:24 --> Model Class Initialized
INFO - 2018-03-29 12:34:24 --> Model Class Initialized
INFO - 2018-03-29 12:34:24 --> Model Class Initialized
INFO - 2018-03-29 12:34:24 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 12:34:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-29 12:34:24 --> Final output sent to browser
DEBUG - 2018-03-29 12:34:24 --> Total execution time: 0.6181
INFO - 2018-03-29 07:04:26 --> Config Class Initialized
INFO - 2018-03-29 07:04:26 --> Hooks Class Initialized
DEBUG - 2018-03-29 07:04:26 --> UTF-8 Support Enabled
INFO - 2018-03-29 07:04:26 --> Utf8 Class Initialized
INFO - 2018-03-29 07:04:26 --> URI Class Initialized
INFO - 2018-03-29 07:04:26 --> Router Class Initialized
INFO - 2018-03-29 07:04:26 --> Output Class Initialized
INFO - 2018-03-29 07:04:26 --> Security Class Initialized
DEBUG - 2018-03-29 07:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 07:04:26 --> Input Class Initialized
INFO - 2018-03-29 07:04:26 --> Language Class Initialized
INFO - 2018-03-29 07:04:26 --> Language Class Initialized
INFO - 2018-03-29 07:04:26 --> Config Class Initialized
INFO - 2018-03-29 07:04:26 --> Loader Class Initialized
INFO - 2018-03-29 12:34:26 --> Helper loaded: url_helper
INFO - 2018-03-29 12:34:26 --> Helper loaded: notification_helper
INFO - 2018-03-29 12:34:26 --> Helper loaded: settings_helper
INFO - 2018-03-29 12:34:26 --> Helper loaded: permission_helper
INFO - 2018-03-29 12:34:26 --> Helper loaded: users_helper
INFO - 2018-03-29 12:34:26 --> Database Driver Class Initialized
DEBUG - 2018-03-29 12:34:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 12:34:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 12:34:26 --> Helper loaded: form_helper
INFO - 2018-03-29 12:34:26 --> Form Validation Class Initialized
INFO - 2018-03-29 12:34:26 --> Controller Class Initialized
INFO - 2018-03-29 12:34:26 --> Model Class Initialized
INFO - 2018-03-29 12:34:26 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 12:34:26 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 12:34:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 12:34:26 --> Model Class Initialized
INFO - 2018-03-29 12:34:26 --> Model Class Initialized
INFO - 2018-03-29 12:34:26 --> Model Class Initialized
INFO - 2018-03-29 12:34:26 --> Model Class Initialized
INFO - 2018-03-29 12:34:26 --> Model Class Initialized
INFO - 2018-03-29 12:34:26 --> Model Class Initialized
INFO - 2018-03-29 12:34:26 --> Model Class Initialized
INFO - 2018-03-29 12:34:26 --> Model Class Initialized
INFO - 2018-03-29 12:34:26 --> Model Class Initialized
INFO - 2018-03-29 12:34:26 --> Model Class Initialized
INFO - 2018-03-29 12:34:26 --> Model Class Initialized
INFO - 2018-03-29 12:34:26 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 12:34:26 --> Model Class Initialized
INFO - 2018-03-29 12:34:26 --> Final output sent to browser
DEBUG - 2018-03-29 12:34:26 --> Total execution time: 0.2826
INFO - 2018-03-29 07:04:26 --> Config Class Initialized
INFO - 2018-03-29 07:04:26 --> Hooks Class Initialized
DEBUG - 2018-03-29 07:04:26 --> UTF-8 Support Enabled
INFO - 2018-03-29 07:04:26 --> Utf8 Class Initialized
INFO - 2018-03-29 07:04:26 --> URI Class Initialized
INFO - 2018-03-29 07:04:26 --> Router Class Initialized
INFO - 2018-03-29 07:04:26 --> Output Class Initialized
INFO - 2018-03-29 07:04:26 --> Security Class Initialized
DEBUG - 2018-03-29 07:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 07:04:26 --> Input Class Initialized
INFO - 2018-03-29 07:04:26 --> Language Class Initialized
INFO - 2018-03-29 07:04:26 --> Language Class Initialized
INFO - 2018-03-29 07:04:26 --> Config Class Initialized
INFO - 2018-03-29 07:04:26 --> Loader Class Initialized
INFO - 2018-03-29 12:34:26 --> Helper loaded: url_helper
INFO - 2018-03-29 12:34:26 --> Helper loaded: notification_helper
INFO - 2018-03-29 12:34:26 --> Helper loaded: settings_helper
INFO - 2018-03-29 12:34:26 --> Helper loaded: permission_helper
INFO - 2018-03-29 12:34:26 --> Helper loaded: users_helper
INFO - 2018-03-29 12:34:26 --> Database Driver Class Initialized
DEBUG - 2018-03-29 12:34:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 12:34:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 12:34:26 --> Helper loaded: form_helper
INFO - 2018-03-29 12:34:26 --> Form Validation Class Initialized
INFO - 2018-03-29 12:34:26 --> Controller Class Initialized
INFO - 2018-03-29 12:34:26 --> Model Class Initialized
INFO - 2018-03-29 12:34:26 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 12:34:26 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 12:34:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 12:34:26 --> Model Class Initialized
INFO - 2018-03-29 12:34:26 --> Model Class Initialized
INFO - 2018-03-29 12:34:26 --> Model Class Initialized
INFO - 2018-03-29 12:34:26 --> Model Class Initialized
INFO - 2018-03-29 12:34:26 --> Model Class Initialized
INFO - 2018-03-29 12:34:26 --> Model Class Initialized
INFO - 2018-03-29 12:34:26 --> Model Class Initialized
INFO - 2018-03-29 12:34:26 --> Model Class Initialized
INFO - 2018-03-29 12:34:26 --> Model Class Initialized
INFO - 2018-03-29 12:34:26 --> Model Class Initialized
INFO - 2018-03-29 12:34:26 --> Model Class Initialized
INFO - 2018-03-29 12:34:26 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 12:34:26 --> Model Class Initialized
INFO - 2018-03-29 12:34:26 --> Final output sent to browser
DEBUG - 2018-03-29 12:34:26 --> Total execution time: 0.1240
INFO - 2018-03-29 07:04:58 --> Config Class Initialized
INFO - 2018-03-29 07:04:58 --> Hooks Class Initialized
DEBUG - 2018-03-29 07:04:58 --> UTF-8 Support Enabled
INFO - 2018-03-29 07:04:58 --> Utf8 Class Initialized
INFO - 2018-03-29 07:04:58 --> URI Class Initialized
INFO - 2018-03-29 07:04:58 --> Router Class Initialized
INFO - 2018-03-29 07:04:58 --> Output Class Initialized
INFO - 2018-03-29 07:04:58 --> Security Class Initialized
DEBUG - 2018-03-29 07:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 07:04:58 --> Input Class Initialized
INFO - 2018-03-29 07:04:58 --> Language Class Initialized
INFO - 2018-03-29 07:04:58 --> Config Class Initialized
INFO - 2018-03-29 07:04:58 --> Hooks Class Initialized
DEBUG - 2018-03-29 07:04:58 --> UTF-8 Support Enabled
INFO - 2018-03-29 07:04:58 --> Utf8 Class Initialized
INFO - 2018-03-29 07:04:58 --> Language Class Initialized
INFO - 2018-03-29 07:04:58 --> Config Class Initialized
INFO - 2018-03-29 07:04:58 --> Loader Class Initialized
INFO - 2018-03-29 07:04:58 --> URI Class Initialized
INFO - 2018-03-29 12:34:58 --> Helper loaded: url_helper
INFO - 2018-03-29 12:34:58 --> Helper loaded: notification_helper
INFO - 2018-03-29 12:34:58 --> Helper loaded: settings_helper
INFO - 2018-03-29 12:34:58 --> Helper loaded: permission_helper
INFO - 2018-03-29 07:04:58 --> Router Class Initialized
INFO - 2018-03-29 12:34:58 --> Helper loaded: users_helper
INFO - 2018-03-29 07:04:58 --> Output Class Initialized
INFO - 2018-03-29 07:04:59 --> Security Class Initialized
DEBUG - 2018-03-29 07:04:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 07:04:59 --> Input Class Initialized
INFO - 2018-03-29 07:04:59 --> Language Class Initialized
INFO - 2018-03-29 12:34:59 --> Database Driver Class Initialized
DEBUG - 2018-03-29 12:34:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 12:34:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 12:34:59 --> Helper loaded: form_helper
INFO - 2018-03-29 12:34:59 --> Form Validation Class Initialized
INFO - 2018-03-29 12:34:59 --> Controller Class Initialized
INFO - 2018-03-29 07:04:59 --> Language Class Initialized
INFO - 2018-03-29 07:04:59 --> Config Class Initialized
INFO - 2018-03-29 07:04:59 --> Loader Class Initialized
INFO - 2018-03-29 12:34:59 --> Helper loaded: url_helper
INFO - 2018-03-29 12:34:59 --> Helper loaded: notification_helper
INFO - 2018-03-29 12:34:59 --> Helper loaded: settings_helper
INFO - 2018-03-29 12:34:59 --> Helper loaded: permission_helper
INFO - 2018-03-29 12:34:59 --> Helper loaded: users_helper
INFO - 2018-03-29 12:34:59 --> Model Class Initialized
INFO - 2018-03-29 12:34:59 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 12:34:59 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 12:34:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 12:34:59 --> Model Class Initialized
INFO - 2018-03-29 12:34:59 --> Model Class Initialized
INFO - 2018-03-29 12:34:59 --> Model Class Initialized
INFO - 2018-03-29 12:34:59 --> Model Class Initialized
INFO - 2018-03-29 12:34:59 --> Model Class Initialized
INFO - 2018-03-29 12:35:00 --> Model Class Initialized
INFO - 2018-03-29 12:35:00 --> Model Class Initialized
INFO - 2018-03-29 12:35:00 --> Model Class Initialized
INFO - 2018-03-29 12:35:00 --> Model Class Initialized
INFO - 2018-03-29 12:35:00 --> Model Class Initialized
INFO - 2018-03-29 12:35:00 --> Database Driver Class Initialized
INFO - 2018-03-29 12:35:00 --> Model Class Initialized
INFO - 2018-03-29 12:35:00 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 12:35:00 --> Model Class Initialized
DEBUG - 2018-03-29 12:35:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 12:35:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 12:35:00 --> Final output sent to browser
DEBUG - 2018-03-29 12:35:00 --> Total execution time: 1.9326
INFO - 2018-03-29 12:35:00 --> Helper loaded: form_helper
INFO - 2018-03-29 12:35:00 --> Form Validation Class Initialized
INFO - 2018-03-29 12:35:00 --> Controller Class Initialized
INFO - 2018-03-29 12:35:00 --> Model Class Initialized
INFO - 2018-03-29 12:35:00 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 12:35:00 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 12:35:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 12:35:00 --> Model Class Initialized
INFO - 2018-03-29 12:35:00 --> Model Class Initialized
INFO - 2018-03-29 12:35:00 --> Model Class Initialized
INFO - 2018-03-29 12:35:00 --> Model Class Initialized
INFO - 2018-03-29 12:35:00 --> Model Class Initialized
INFO - 2018-03-29 12:35:00 --> Model Class Initialized
INFO - 2018-03-29 12:35:00 --> Model Class Initialized
INFO - 2018-03-29 12:35:00 --> Model Class Initialized
INFO - 2018-03-29 12:35:00 --> Model Class Initialized
INFO - 2018-03-29 12:35:00 --> Model Class Initialized
INFO - 2018-03-29 12:35:00 --> Model Class Initialized
INFO - 2018-03-29 12:35:00 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 12:35:00 --> Final output sent to browser
DEBUG - 2018-03-29 12:35:00 --> Total execution time: 2.0499
INFO - 2018-03-29 07:05:01 --> Config Class Initialized
INFO - 2018-03-29 07:05:01 --> Hooks Class Initialized
INFO - 2018-03-29 07:05:01 --> Config Class Initialized
INFO - 2018-03-29 07:05:01 --> Hooks Class Initialized
DEBUG - 2018-03-29 07:05:01 --> UTF-8 Support Enabled
INFO - 2018-03-29 07:05:01 --> Utf8 Class Initialized
DEBUG - 2018-03-29 07:05:01 --> UTF-8 Support Enabled
INFO - 2018-03-29 07:05:01 --> Utf8 Class Initialized
INFO - 2018-03-29 07:05:01 --> URI Class Initialized
INFO - 2018-03-29 07:05:01 --> Router Class Initialized
INFO - 2018-03-29 07:05:01 --> URI Class Initialized
INFO - 2018-03-29 07:05:01 --> Router Class Initialized
INFO - 2018-03-29 07:05:01 --> Output Class Initialized
INFO - 2018-03-29 07:05:01 --> Security Class Initialized
DEBUG - 2018-03-29 07:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 07:05:01 --> Input Class Initialized
INFO - 2018-03-29 07:05:01 --> Language Class Initialized
INFO - 2018-03-29 07:05:01 --> Output Class Initialized
INFO - 2018-03-29 07:05:01 --> Security Class Initialized
DEBUG - 2018-03-29 07:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 07:05:01 --> Input Class Initialized
INFO - 2018-03-29 07:05:01 --> Language Class Initialized
INFO - 2018-03-29 07:05:01 --> Language Class Initialized
INFO - 2018-03-29 07:05:01 --> Config Class Initialized
INFO - 2018-03-29 07:05:01 --> Loader Class Initialized
INFO - 2018-03-29 12:35:01 --> Helper loaded: url_helper
INFO - 2018-03-29 12:35:01 --> Helper loaded: notification_helper
INFO - 2018-03-29 12:35:01 --> Helper loaded: settings_helper
INFO - 2018-03-29 12:35:01 --> Helper loaded: permission_helper
INFO - 2018-03-29 12:35:01 --> Helper loaded: users_helper
INFO - 2018-03-29 07:05:01 --> Language Class Initialized
INFO - 2018-03-29 07:05:01 --> Config Class Initialized
INFO - 2018-03-29 07:05:01 --> Loader Class Initialized
INFO - 2018-03-29 12:35:01 --> Helper loaded: url_helper
INFO - 2018-03-29 12:35:01 --> Helper loaded: notification_helper
INFO - 2018-03-29 12:35:01 --> Helper loaded: settings_helper
INFO - 2018-03-29 12:35:01 --> Helper loaded: permission_helper
INFO - 2018-03-29 12:35:01 --> Helper loaded: users_helper
INFO - 2018-03-29 12:35:01 --> Database Driver Class Initialized
DEBUG - 2018-03-29 12:35:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 12:35:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 12:35:01 --> Helper loaded: form_helper
INFO - 2018-03-29 12:35:01 --> Form Validation Class Initialized
INFO - 2018-03-29 12:35:01 --> Controller Class Initialized
INFO - 2018-03-29 12:35:01 --> Model Class Initialized
INFO - 2018-03-29 12:35:01 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 12:35:01 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 12:35:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 12:35:01 --> Model Class Initialized
INFO - 2018-03-29 12:35:01 --> Model Class Initialized
INFO - 2018-03-29 12:35:01 --> Model Class Initialized
INFO - 2018-03-29 12:35:01 --> Model Class Initialized
INFO - 2018-03-29 12:35:01 --> Model Class Initialized
INFO - 2018-03-29 12:35:01 --> Model Class Initialized
INFO - 2018-03-29 12:35:01 --> Model Class Initialized
INFO - 2018-03-29 12:35:01 --> Model Class Initialized
INFO - 2018-03-29 12:35:01 --> Model Class Initialized
INFO - 2018-03-29 12:35:01 --> Model Class Initialized
INFO - 2018-03-29 12:35:01 --> Model Class Initialized
INFO - 2018-03-29 12:35:01 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 12:35:01 --> Model Class Initialized
INFO - 2018-03-29 12:35:01 --> Final output sent to browser
DEBUG - 2018-03-29 12:35:01 --> Total execution time: 0.5999
INFO - 2018-03-29 12:35:01 --> Database Driver Class Initialized
DEBUG - 2018-03-29 12:35:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 12:35:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 12:35:02 --> Helper loaded: form_helper
INFO - 2018-03-29 12:35:02 --> Form Validation Class Initialized
INFO - 2018-03-29 12:35:02 --> Controller Class Initialized
INFO - 2018-03-29 12:35:03 --> Model Class Initialized
INFO - 2018-03-29 12:35:03 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 12:35:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 12:35:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 12:35:03 --> Model Class Initialized
INFO - 2018-03-29 12:35:03 --> Model Class Initialized
INFO - 2018-03-29 12:35:03 --> Model Class Initialized
INFO - 2018-03-29 12:35:03 --> Model Class Initialized
INFO - 2018-03-29 12:35:03 --> Model Class Initialized
INFO - 2018-03-29 12:35:03 --> Model Class Initialized
INFO - 2018-03-29 12:35:03 --> Model Class Initialized
INFO - 2018-03-29 12:35:03 --> Model Class Initialized
INFO - 2018-03-29 12:35:03 --> Model Class Initialized
INFO - 2018-03-29 12:35:03 --> Model Class Initialized
INFO - 2018-03-29 12:35:03 --> Model Class Initialized
INFO - 2018-03-29 12:35:03 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 12:35:03 --> Final output sent to browser
DEBUG - 2018-03-29 12:35:03 --> Total execution time: 2.3090
INFO - 2018-03-29 07:05:10 --> Config Class Initialized
INFO - 2018-03-29 07:05:10 --> Hooks Class Initialized
DEBUG - 2018-03-29 07:05:10 --> UTF-8 Support Enabled
INFO - 2018-03-29 07:05:10 --> Utf8 Class Initialized
INFO - 2018-03-29 07:05:10 --> URI Class Initialized
INFO - 2018-03-29 07:05:10 --> Router Class Initialized
INFO - 2018-03-29 07:05:10 --> Output Class Initialized
INFO - 2018-03-29 07:05:10 --> Security Class Initialized
DEBUG - 2018-03-29 07:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 07:05:10 --> Input Class Initialized
INFO - 2018-03-29 07:05:10 --> Language Class Initialized
INFO - 2018-03-29 07:05:10 --> Language Class Initialized
INFO - 2018-03-29 07:05:10 --> Config Class Initialized
INFO - 2018-03-29 07:05:10 --> Loader Class Initialized
INFO - 2018-03-29 12:35:10 --> Helper loaded: url_helper
INFO - 2018-03-29 12:35:10 --> Helper loaded: notification_helper
INFO - 2018-03-29 12:35:10 --> Helper loaded: settings_helper
INFO - 2018-03-29 12:35:10 --> Helper loaded: permission_helper
INFO - 2018-03-29 12:35:10 --> Helper loaded: users_helper
INFO - 2018-03-29 12:35:10 --> Database Driver Class Initialized
DEBUG - 2018-03-29 12:35:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 12:35:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 12:35:10 --> Helper loaded: form_helper
INFO - 2018-03-29 12:35:10 --> Form Validation Class Initialized
INFO - 2018-03-29 12:35:10 --> Controller Class Initialized
INFO - 2018-03-29 12:35:10 --> Model Class Initialized
INFO - 2018-03-29 12:35:10 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 12:35:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 12:35:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 12:35:10 --> Model Class Initialized
INFO - 2018-03-29 12:35:10 --> Model Class Initialized
INFO - 2018-03-29 12:35:10 --> Model Class Initialized
INFO - 2018-03-29 12:35:10 --> Model Class Initialized
INFO - 2018-03-29 12:35:10 --> Model Class Initialized
INFO - 2018-03-29 12:35:10 --> Model Class Initialized
INFO - 2018-03-29 12:35:10 --> Model Class Initialized
INFO - 2018-03-29 12:35:10 --> Model Class Initialized
INFO - 2018-03-29 12:35:10 --> Model Class Initialized
INFO - 2018-03-29 12:35:10 --> Model Class Initialized
INFO - 2018-03-29 12:35:10 --> Model Class Initialized
INFO - 2018-03-29 12:35:10 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 12:35:10 --> Final output sent to browser
DEBUG - 2018-03-29 12:35:10 --> Total execution time: 0.1242
INFO - 2018-03-29 07:05:10 --> Config Class Initialized
INFO - 2018-03-29 07:05:10 --> Hooks Class Initialized
DEBUG - 2018-03-29 07:05:10 --> UTF-8 Support Enabled
INFO - 2018-03-29 07:05:10 --> Utf8 Class Initialized
INFO - 2018-03-29 07:05:10 --> URI Class Initialized
INFO - 2018-03-29 07:05:10 --> Router Class Initialized
INFO - 2018-03-29 07:05:10 --> Output Class Initialized
INFO - 2018-03-29 07:05:10 --> Security Class Initialized
DEBUG - 2018-03-29 07:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 07:05:10 --> Input Class Initialized
INFO - 2018-03-29 07:05:10 --> Language Class Initialized
INFO - 2018-03-29 07:05:10 --> Language Class Initialized
INFO - 2018-03-29 07:05:10 --> Config Class Initialized
INFO - 2018-03-29 07:05:10 --> Loader Class Initialized
INFO - 2018-03-29 12:35:10 --> Helper loaded: url_helper
INFO - 2018-03-29 12:35:10 --> Helper loaded: notification_helper
INFO - 2018-03-29 12:35:10 --> Helper loaded: settings_helper
INFO - 2018-03-29 12:35:10 --> Helper loaded: permission_helper
INFO - 2018-03-29 12:35:10 --> Helper loaded: users_helper
INFO - 2018-03-29 12:35:11 --> Database Driver Class Initialized
DEBUG - 2018-03-29 12:35:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 12:35:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 12:35:11 --> Helper loaded: form_helper
INFO - 2018-03-29 12:35:11 --> Form Validation Class Initialized
INFO - 2018-03-29 12:35:11 --> Controller Class Initialized
INFO - 2018-03-29 12:35:11 --> Model Class Initialized
INFO - 2018-03-29 12:35:11 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 12:35:11 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 12:35:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 12:35:11 --> Model Class Initialized
INFO - 2018-03-29 12:35:11 --> Model Class Initialized
INFO - 2018-03-29 12:35:11 --> Model Class Initialized
INFO - 2018-03-29 12:35:11 --> Model Class Initialized
INFO - 2018-03-29 12:35:11 --> Model Class Initialized
INFO - 2018-03-29 12:35:11 --> Model Class Initialized
INFO - 2018-03-29 12:35:11 --> Model Class Initialized
INFO - 2018-03-29 12:35:11 --> Model Class Initialized
INFO - 2018-03-29 12:35:11 --> Model Class Initialized
INFO - 2018-03-29 12:35:11 --> Model Class Initialized
INFO - 2018-03-29 12:35:11 --> Model Class Initialized
INFO - 2018-03-29 12:35:11 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 12:35:11 --> Model Class Initialized
INFO - 2018-03-29 12:35:11 --> Final output sent to browser
DEBUG - 2018-03-29 12:35:11 --> Total execution time: 0.4240
INFO - 2018-03-29 07:07:07 --> Config Class Initialized
INFO - 2018-03-29 07:07:07 --> Hooks Class Initialized
DEBUG - 2018-03-29 07:07:07 --> UTF-8 Support Enabled
INFO - 2018-03-29 07:07:07 --> Utf8 Class Initialized
INFO - 2018-03-29 07:07:07 --> URI Class Initialized
INFO - 2018-03-29 07:07:07 --> Router Class Initialized
INFO - 2018-03-29 07:07:07 --> Output Class Initialized
INFO - 2018-03-29 07:07:07 --> Security Class Initialized
DEBUG - 2018-03-29 07:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 07:07:07 --> Input Class Initialized
INFO - 2018-03-29 07:07:07 --> Language Class Initialized
INFO - 2018-03-29 07:07:08 --> Language Class Initialized
INFO - 2018-03-29 07:07:08 --> Config Class Initialized
INFO - 2018-03-29 07:07:08 --> Loader Class Initialized
INFO - 2018-03-29 12:37:08 --> Helper loaded: url_helper
INFO - 2018-03-29 12:37:08 --> Helper loaded: notification_helper
INFO - 2018-03-29 12:37:08 --> Helper loaded: settings_helper
INFO - 2018-03-29 12:37:08 --> Helper loaded: permission_helper
INFO - 2018-03-29 12:37:08 --> Helper loaded: users_helper
INFO - 2018-03-29 12:37:08 --> Database Driver Class Initialized
DEBUG - 2018-03-29 12:37:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 12:37:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 12:37:09 --> Helper loaded: form_helper
INFO - 2018-03-29 12:37:09 --> Form Validation Class Initialized
INFO - 2018-03-29 12:37:09 --> Controller Class Initialized
INFO - 2018-03-29 12:37:09 --> Model Class Initialized
INFO - 2018-03-29 12:37:09 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 12:37:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 12:37:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 12:37:09 --> Model Class Initialized
INFO - 2018-03-29 12:37:09 --> Model Class Initialized
INFO - 2018-03-29 12:37:09 --> Model Class Initialized
INFO - 2018-03-29 12:37:09 --> Model Class Initialized
INFO - 2018-03-29 12:37:09 --> Model Class Initialized
INFO - 2018-03-29 12:37:09 --> Model Class Initialized
INFO - 2018-03-29 12:37:09 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 12:37:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-29 12:37:09 --> Final output sent to browser
DEBUG - 2018-03-29 12:37:09 --> Total execution time: 2.5163
INFO - 2018-03-29 07:07:10 --> Config Class Initialized
INFO - 2018-03-29 07:07:10 --> Hooks Class Initialized
DEBUG - 2018-03-29 07:07:10 --> UTF-8 Support Enabled
INFO - 2018-03-29 07:07:10 --> Utf8 Class Initialized
INFO - 2018-03-29 07:07:10 --> URI Class Initialized
INFO - 2018-03-29 07:07:10 --> Router Class Initialized
INFO - 2018-03-29 07:07:10 --> Output Class Initialized
INFO - 2018-03-29 07:07:10 --> Security Class Initialized
DEBUG - 2018-03-29 07:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 07:07:10 --> Input Class Initialized
INFO - 2018-03-29 07:07:10 --> Language Class Initialized
INFO - 2018-03-29 07:07:10 --> Language Class Initialized
INFO - 2018-03-29 07:07:10 --> Config Class Initialized
INFO - 2018-03-29 07:07:10 --> Loader Class Initialized
INFO - 2018-03-29 12:37:10 --> Helper loaded: url_helper
INFO - 2018-03-29 12:37:10 --> Helper loaded: notification_helper
INFO - 2018-03-29 12:37:10 --> Helper loaded: settings_helper
INFO - 2018-03-29 12:37:10 --> Helper loaded: permission_helper
INFO - 2018-03-29 12:37:10 --> Helper loaded: users_helper
INFO - 2018-03-29 12:37:10 --> Database Driver Class Initialized
DEBUG - 2018-03-29 12:37:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 12:37:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 12:37:10 --> Helper loaded: form_helper
INFO - 2018-03-29 12:37:10 --> Form Validation Class Initialized
INFO - 2018-03-29 12:37:10 --> Controller Class Initialized
INFO - 2018-03-29 12:37:10 --> Model Class Initialized
INFO - 2018-03-29 12:37:10 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 12:37:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 12:37:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 12:37:10 --> Model Class Initialized
INFO - 2018-03-29 12:37:10 --> Model Class Initialized
INFO - 2018-03-29 12:37:10 --> Model Class Initialized
INFO - 2018-03-29 12:37:10 --> Model Class Initialized
INFO - 2018-03-29 12:37:10 --> Model Class Initialized
INFO - 2018-03-29 12:37:10 --> Model Class Initialized
INFO - 2018-03-29 12:37:10 --> Model Class Initialized
INFO - 2018-03-29 12:37:10 --> Model Class Initialized
INFO - 2018-03-29 12:37:10 --> Model Class Initialized
INFO - 2018-03-29 12:37:10 --> Model Class Initialized
INFO - 2018-03-29 12:37:10 --> Model Class Initialized
INFO - 2018-03-29 12:37:10 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 12:37:10 --> Model Class Initialized
INFO - 2018-03-29 12:37:10 --> Final output sent to browser
DEBUG - 2018-03-29 12:37:10 --> Total execution time: 0.1235
INFO - 2018-03-29 07:07:13 --> Config Class Initialized
INFO - 2018-03-29 07:07:13 --> Hooks Class Initialized
DEBUG - 2018-03-29 07:07:13 --> UTF-8 Support Enabled
INFO - 2018-03-29 07:07:13 --> Utf8 Class Initialized
INFO - 2018-03-29 07:07:13 --> URI Class Initialized
INFO - 2018-03-29 07:07:13 --> Router Class Initialized
INFO - 2018-03-29 07:07:13 --> Output Class Initialized
INFO - 2018-03-29 07:07:14 --> Security Class Initialized
INFO - 2018-03-29 07:07:14 --> Config Class Initialized
INFO - 2018-03-29 07:07:14 --> Hooks Class Initialized
DEBUG - 2018-03-29 07:07:14 --> UTF-8 Support Enabled
INFO - 2018-03-29 07:07:14 --> Utf8 Class Initialized
INFO - 2018-03-29 07:07:14 --> URI Class Initialized
INFO - 2018-03-29 07:07:14 --> Router Class Initialized
INFO - 2018-03-29 07:07:14 --> Output Class Initialized
INFO - 2018-03-29 07:07:14 --> Security Class Initialized
DEBUG - 2018-03-29 07:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 07:07:14 --> Input Class Initialized
INFO - 2018-03-29 07:07:14 --> Language Class Initialized
DEBUG - 2018-03-29 07:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 07:07:14 --> Input Class Initialized
INFO - 2018-03-29 07:07:14 --> Language Class Initialized
INFO - 2018-03-29 07:07:14 --> Language Class Initialized
INFO - 2018-03-29 07:07:14 --> Config Class Initialized
INFO - 2018-03-29 07:07:14 --> Loader Class Initialized
INFO - 2018-03-29 12:37:14 --> Helper loaded: url_helper
INFO - 2018-03-29 12:37:14 --> Helper loaded: notification_helper
INFO - 2018-03-29 12:37:14 --> Helper loaded: settings_helper
INFO - 2018-03-29 12:37:14 --> Helper loaded: permission_helper
INFO - 2018-03-29 12:37:14 --> Helper loaded: users_helper
INFO - 2018-03-29 12:37:14 --> Database Driver Class Initialized
DEBUG - 2018-03-29 12:37:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 12:37:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 12:37:14 --> Helper loaded: form_helper
INFO - 2018-03-29 12:37:14 --> Form Validation Class Initialized
INFO - 2018-03-29 12:37:14 --> Controller Class Initialized
INFO - 2018-03-29 12:37:14 --> Model Class Initialized
INFO - 2018-03-29 12:37:14 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 12:37:14 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 12:37:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 12:37:14 --> Model Class Initialized
INFO - 2018-03-29 12:37:14 --> Model Class Initialized
INFO - 2018-03-29 12:37:14 --> Model Class Initialized
INFO - 2018-03-29 12:37:14 --> Model Class Initialized
INFO - 2018-03-29 12:37:14 --> Model Class Initialized
INFO - 2018-03-29 12:37:14 --> Model Class Initialized
INFO - 2018-03-29 12:37:14 --> Model Class Initialized
INFO - 2018-03-29 12:37:14 --> Model Class Initialized
INFO - 2018-03-29 12:37:14 --> Model Class Initialized
INFO - 2018-03-29 12:37:14 --> Model Class Initialized
INFO - 2018-03-29 12:37:14 --> Model Class Initialized
INFO - 2018-03-29 12:37:14 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 12:37:14 --> Model Class Initialized
INFO - 2018-03-29 12:37:14 --> Final output sent to browser
DEBUG - 2018-03-29 12:37:14 --> Total execution time: 0.7849
INFO - 2018-03-29 07:07:15 --> Language Class Initialized
INFO - 2018-03-29 07:07:15 --> Config Class Initialized
INFO - 2018-03-29 07:07:15 --> Loader Class Initialized
INFO - 2018-03-29 12:37:15 --> Helper loaded: url_helper
INFO - 2018-03-29 12:37:15 --> Helper loaded: notification_helper
INFO - 2018-03-29 12:37:15 --> Helper loaded: settings_helper
INFO - 2018-03-29 12:37:15 --> Helper loaded: permission_helper
INFO - 2018-03-29 12:37:15 --> Helper loaded: users_helper
INFO - 2018-03-29 12:37:16 --> Database Driver Class Initialized
DEBUG - 2018-03-29 12:37:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 12:37:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 12:37:16 --> Helper loaded: form_helper
INFO - 2018-03-29 12:37:16 --> Form Validation Class Initialized
INFO - 2018-03-29 12:37:16 --> Controller Class Initialized
INFO - 2018-03-29 12:37:16 --> Model Class Initialized
INFO - 2018-03-29 12:37:16 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 12:37:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 12:37:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 12:37:16 --> Model Class Initialized
INFO - 2018-03-29 12:37:16 --> Model Class Initialized
INFO - 2018-03-29 12:37:16 --> Model Class Initialized
INFO - 2018-03-29 12:37:16 --> Model Class Initialized
INFO - 2018-03-29 12:37:16 --> Model Class Initialized
INFO - 2018-03-29 12:37:16 --> Model Class Initialized
INFO - 2018-03-29 12:37:16 --> Model Class Initialized
INFO - 2018-03-29 12:37:16 --> Model Class Initialized
INFO - 2018-03-29 12:37:16 --> Model Class Initialized
INFO - 2018-03-29 12:37:16 --> Model Class Initialized
INFO - 2018-03-29 12:37:16 --> Model Class Initialized
INFO - 2018-03-29 12:37:16 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 12:37:16 --> Model Class Initialized
INFO - 2018-03-29 12:37:16 --> Final output sent to browser
DEBUG - 2018-03-29 12:37:16 --> Total execution time: 3.7674
INFO - 2018-03-29 07:07:17 --> Config Class Initialized
INFO - 2018-03-29 07:07:17 --> Hooks Class Initialized
DEBUG - 2018-03-29 07:07:17 --> UTF-8 Support Enabled
INFO - 2018-03-29 07:07:17 --> Utf8 Class Initialized
INFO - 2018-03-29 07:07:17 --> URI Class Initialized
INFO - 2018-03-29 07:07:17 --> Router Class Initialized
INFO - 2018-03-29 07:07:17 --> Output Class Initialized
INFO - 2018-03-29 07:07:17 --> Security Class Initialized
DEBUG - 2018-03-29 07:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 07:07:17 --> Input Class Initialized
INFO - 2018-03-29 07:07:17 --> Language Class Initialized
INFO - 2018-03-29 07:07:17 --> Language Class Initialized
INFO - 2018-03-29 07:07:17 --> Config Class Initialized
INFO - 2018-03-29 07:07:17 --> Loader Class Initialized
INFO - 2018-03-29 12:37:17 --> Helper loaded: url_helper
INFO - 2018-03-29 12:37:17 --> Helper loaded: notification_helper
INFO - 2018-03-29 12:37:17 --> Helper loaded: settings_helper
INFO - 2018-03-29 12:37:17 --> Helper loaded: permission_helper
INFO - 2018-03-29 12:37:17 --> Helper loaded: users_helper
INFO - 2018-03-29 12:37:17 --> Database Driver Class Initialized
DEBUG - 2018-03-29 12:37:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 12:37:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 12:37:17 --> Helper loaded: form_helper
INFO - 2018-03-29 12:37:17 --> Form Validation Class Initialized
INFO - 2018-03-29 12:37:17 --> Controller Class Initialized
INFO - 2018-03-29 12:37:17 --> Model Class Initialized
INFO - 2018-03-29 12:37:17 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 12:37:17 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 12:37:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 12:37:17 --> Model Class Initialized
INFO - 2018-03-29 12:37:17 --> Model Class Initialized
INFO - 2018-03-29 12:37:17 --> Model Class Initialized
INFO - 2018-03-29 12:37:17 --> Model Class Initialized
INFO - 2018-03-29 12:37:17 --> Model Class Initialized
INFO - 2018-03-29 12:37:17 --> Model Class Initialized
INFO - 2018-03-29 12:37:17 --> Model Class Initialized
INFO - 2018-03-29 12:37:17 --> Model Class Initialized
INFO - 2018-03-29 12:37:17 --> Model Class Initialized
INFO - 2018-03-29 12:37:17 --> Model Class Initialized
INFO - 2018-03-29 12:37:17 --> Model Class Initialized
INFO - 2018-03-29 12:37:17 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 12:37:17 --> Model Class Initialized
INFO - 2018-03-29 12:37:17 --> Final output sent to browser
DEBUG - 2018-03-29 12:37:17 --> Total execution time: 0.3881
INFO - 2018-03-29 07:07:18 --> Config Class Initialized
INFO - 2018-03-29 07:07:18 --> Hooks Class Initialized
DEBUG - 2018-03-29 07:07:18 --> UTF-8 Support Enabled
INFO - 2018-03-29 07:07:18 --> Utf8 Class Initialized
INFO - 2018-03-29 07:07:18 --> URI Class Initialized
INFO - 2018-03-29 07:07:18 --> Router Class Initialized
INFO - 2018-03-29 07:07:18 --> Output Class Initialized
INFO - 2018-03-29 07:07:18 --> Security Class Initialized
DEBUG - 2018-03-29 07:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 07:07:18 --> Input Class Initialized
INFO - 2018-03-29 07:07:18 --> Language Class Initialized
INFO - 2018-03-29 07:07:18 --> Language Class Initialized
INFO - 2018-03-29 07:07:18 --> Config Class Initialized
INFO - 2018-03-29 07:07:18 --> Loader Class Initialized
INFO - 2018-03-29 12:37:18 --> Helper loaded: url_helper
INFO - 2018-03-29 12:37:18 --> Helper loaded: notification_helper
INFO - 2018-03-29 12:37:18 --> Helper loaded: settings_helper
INFO - 2018-03-29 12:37:18 --> Helper loaded: permission_helper
INFO - 2018-03-29 12:37:18 --> Helper loaded: users_helper
INFO - 2018-03-29 12:37:18 --> Database Driver Class Initialized
DEBUG - 2018-03-29 12:37:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 12:37:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 12:37:18 --> Helper loaded: form_helper
INFO - 2018-03-29 12:37:18 --> Form Validation Class Initialized
INFO - 2018-03-29 12:37:18 --> Controller Class Initialized
INFO - 2018-03-29 12:37:18 --> Model Class Initialized
INFO - 2018-03-29 12:37:18 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 12:37:18 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 12:37:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 12:37:18 --> Model Class Initialized
INFO - 2018-03-29 12:37:18 --> Model Class Initialized
INFO - 2018-03-29 12:37:18 --> Model Class Initialized
INFO - 2018-03-29 12:37:18 --> Model Class Initialized
INFO - 2018-03-29 12:37:18 --> Model Class Initialized
INFO - 2018-03-29 12:37:18 --> Model Class Initialized
INFO - 2018-03-29 12:37:18 --> Model Class Initialized
INFO - 2018-03-29 12:37:18 --> Model Class Initialized
INFO - 2018-03-29 12:37:18 --> Model Class Initialized
INFO - 2018-03-29 12:37:18 --> Model Class Initialized
INFO - 2018-03-29 12:37:18 --> Model Class Initialized
INFO - 2018-03-29 12:37:18 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 12:37:18 --> Final output sent to browser
DEBUG - 2018-03-29 12:37:18 --> Total execution time: 0.5256
INFO - 2018-03-29 07:12:51 --> Config Class Initialized
INFO - 2018-03-29 07:12:51 --> Hooks Class Initialized
DEBUG - 2018-03-29 07:12:51 --> UTF-8 Support Enabled
INFO - 2018-03-29 07:12:51 --> Utf8 Class Initialized
INFO - 2018-03-29 07:12:51 --> URI Class Initialized
INFO - 2018-03-29 07:12:51 --> Router Class Initialized
INFO - 2018-03-29 07:12:52 --> Output Class Initialized
INFO - 2018-03-29 07:12:52 --> Security Class Initialized
DEBUG - 2018-03-29 07:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 07:12:52 --> Input Class Initialized
INFO - 2018-03-29 07:12:52 --> Language Class Initialized
INFO - 2018-03-29 07:12:52 --> Language Class Initialized
INFO - 2018-03-29 07:12:52 --> Config Class Initialized
INFO - 2018-03-29 07:12:52 --> Loader Class Initialized
INFO - 2018-03-29 12:42:52 --> Helper loaded: url_helper
INFO - 2018-03-29 12:42:52 --> Helper loaded: notification_helper
INFO - 2018-03-29 12:42:52 --> Helper loaded: settings_helper
INFO - 2018-03-29 12:42:52 --> Helper loaded: permission_helper
INFO - 2018-03-29 12:42:52 --> Helper loaded: users_helper
INFO - 2018-03-29 12:42:52 --> Database Driver Class Initialized
DEBUG - 2018-03-29 12:42:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 12:42:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 12:42:52 --> Helper loaded: form_helper
INFO - 2018-03-29 12:42:52 --> Form Validation Class Initialized
INFO - 2018-03-29 12:42:52 --> Controller Class Initialized
INFO - 2018-03-29 12:42:52 --> Model Class Initialized
INFO - 2018-03-29 12:42:52 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 12:42:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 12:42:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 12:42:52 --> Model Class Initialized
INFO - 2018-03-29 12:42:52 --> Model Class Initialized
INFO - 2018-03-29 12:42:52 --> Model Class Initialized
INFO - 2018-03-29 12:42:52 --> Model Class Initialized
INFO - 2018-03-29 12:42:52 --> Model Class Initialized
INFO - 2018-03-29 12:42:52 --> Model Class Initialized
INFO - 2018-03-29 12:42:52 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 12:42:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-29 12:42:52 --> Final output sent to browser
DEBUG - 2018-03-29 12:42:52 --> Total execution time: 0.5034
INFO - 2018-03-29 07:12:53 --> Config Class Initialized
INFO - 2018-03-29 07:12:53 --> Hooks Class Initialized
DEBUG - 2018-03-29 07:12:53 --> UTF-8 Support Enabled
INFO - 2018-03-29 07:12:53 --> Utf8 Class Initialized
INFO - 2018-03-29 07:12:53 --> URI Class Initialized
INFO - 2018-03-29 07:12:53 --> Router Class Initialized
INFO - 2018-03-29 07:12:53 --> Output Class Initialized
INFO - 2018-03-29 07:12:53 --> Security Class Initialized
DEBUG - 2018-03-29 07:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 07:12:53 --> Input Class Initialized
INFO - 2018-03-29 07:12:53 --> Language Class Initialized
INFO - 2018-03-29 07:12:53 --> Config Class Initialized
INFO - 2018-03-29 07:12:53 --> Hooks Class Initialized
DEBUG - 2018-03-29 07:12:53 --> UTF-8 Support Enabled
INFO - 2018-03-29 07:12:53 --> Utf8 Class Initialized
INFO - 2018-03-29 07:12:53 --> URI Class Initialized
INFO - 2018-03-29 07:12:53 --> Router Class Initialized
INFO - 2018-03-29 07:12:53 --> Output Class Initialized
INFO - 2018-03-29 07:12:53 --> Security Class Initialized
DEBUG - 2018-03-29 07:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 07:12:53 --> Input Class Initialized
INFO - 2018-03-29 07:12:53 --> Language Class Initialized
INFO - 2018-03-29 07:12:53 --> Language Class Initialized
INFO - 2018-03-29 07:12:53 --> Config Class Initialized
INFO - 2018-03-29 07:12:53 --> Loader Class Initialized
INFO - 2018-03-29 12:42:53 --> Helper loaded: url_helper
INFO - 2018-03-29 12:42:53 --> Helper loaded: notification_helper
INFO - 2018-03-29 12:42:53 --> Helper loaded: settings_helper
INFO - 2018-03-29 12:42:53 --> Helper loaded: permission_helper
INFO - 2018-03-29 12:42:53 --> Helper loaded: users_helper
INFO - 2018-03-29 12:42:53 --> Database Driver Class Initialized
DEBUG - 2018-03-29 12:42:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 12:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 12:42:53 --> Helper loaded: form_helper
INFO - 2018-03-29 12:42:53 --> Form Validation Class Initialized
INFO - 2018-03-29 12:42:53 --> Controller Class Initialized
INFO - 2018-03-29 12:42:53 --> Model Class Initialized
INFO - 2018-03-29 12:42:53 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 12:42:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 12:42:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 12:42:53 --> Model Class Initialized
INFO - 2018-03-29 12:42:53 --> Model Class Initialized
INFO - 2018-03-29 12:42:53 --> Model Class Initialized
INFO - 2018-03-29 12:42:53 --> Model Class Initialized
INFO - 2018-03-29 12:42:53 --> Model Class Initialized
INFO - 2018-03-29 12:42:53 --> Model Class Initialized
INFO - 2018-03-29 12:42:53 --> Model Class Initialized
INFO - 2018-03-29 12:42:53 --> Model Class Initialized
INFO - 2018-03-29 12:42:53 --> Model Class Initialized
INFO - 2018-03-29 12:42:53 --> Model Class Initialized
INFO - 2018-03-29 12:42:53 --> Model Class Initialized
INFO - 2018-03-29 12:42:53 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 12:42:53 --> Model Class Initialized
INFO - 2018-03-29 12:42:53 --> Final output sent to browser
DEBUG - 2018-03-29 12:42:53 --> Total execution time: 0.1156
INFO - 2018-03-29 07:12:53 --> Language Class Initialized
INFO - 2018-03-29 07:12:53 --> Config Class Initialized
INFO - 2018-03-29 07:12:53 --> Loader Class Initialized
INFO - 2018-03-29 12:42:53 --> Helper loaded: url_helper
INFO - 2018-03-29 12:42:53 --> Helper loaded: notification_helper
INFO - 2018-03-29 12:42:53 --> Helper loaded: settings_helper
INFO - 2018-03-29 12:42:53 --> Helper loaded: permission_helper
INFO - 2018-03-29 12:42:53 --> Helper loaded: users_helper
INFO - 2018-03-29 12:42:53 --> Database Driver Class Initialized
DEBUG - 2018-03-29 12:42:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 12:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 12:42:53 --> Helper loaded: form_helper
INFO - 2018-03-29 12:42:53 --> Form Validation Class Initialized
INFO - 2018-03-29 12:42:53 --> Controller Class Initialized
INFO - 2018-03-29 12:42:54 --> Model Class Initialized
INFO - 2018-03-29 12:42:54 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 12:42:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 12:42:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 12:42:54 --> Model Class Initialized
INFO - 2018-03-29 12:42:54 --> Model Class Initialized
INFO - 2018-03-29 12:42:54 --> Model Class Initialized
INFO - 2018-03-29 12:42:54 --> Model Class Initialized
INFO - 2018-03-29 12:42:54 --> Model Class Initialized
INFO - 2018-03-29 12:42:54 --> Model Class Initialized
INFO - 2018-03-29 12:42:54 --> Model Class Initialized
INFO - 2018-03-29 12:42:54 --> Model Class Initialized
INFO - 2018-03-29 12:42:54 --> Model Class Initialized
INFO - 2018-03-29 12:42:54 --> Model Class Initialized
INFO - 2018-03-29 12:42:54 --> Model Class Initialized
INFO - 2018-03-29 12:42:54 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 12:42:54 --> Model Class Initialized
INFO - 2018-03-29 12:42:54 --> Final output sent to browser
DEBUG - 2018-03-29 12:42:54 --> Total execution time: 0.5966
INFO - 2018-03-29 07:13:04 --> Config Class Initialized
INFO - 2018-03-29 07:13:04 --> Hooks Class Initialized
DEBUG - 2018-03-29 07:13:04 --> UTF-8 Support Enabled
INFO - 2018-03-29 07:13:04 --> Utf8 Class Initialized
INFO - 2018-03-29 07:13:04 --> URI Class Initialized
INFO - 2018-03-29 07:13:04 --> Router Class Initialized
INFO - 2018-03-29 07:13:04 --> Output Class Initialized
INFO - 2018-03-29 07:13:04 --> Security Class Initialized
DEBUG - 2018-03-29 07:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 07:13:04 --> Input Class Initialized
INFO - 2018-03-29 07:13:04 --> Language Class Initialized
INFO - 2018-03-29 07:13:05 --> Language Class Initialized
INFO - 2018-03-29 07:13:05 --> Config Class Initialized
INFO - 2018-03-29 07:13:05 --> Loader Class Initialized
INFO - 2018-03-29 12:43:05 --> Helper loaded: url_helper
INFO - 2018-03-29 12:43:05 --> Helper loaded: notification_helper
INFO - 2018-03-29 12:43:05 --> Helper loaded: settings_helper
INFO - 2018-03-29 12:43:05 --> Helper loaded: permission_helper
INFO - 2018-03-29 12:43:05 --> Helper loaded: users_helper
INFO - 2018-03-29 12:43:05 --> Database Driver Class Initialized
DEBUG - 2018-03-29 12:43:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 12:43:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 12:43:05 --> Helper loaded: form_helper
INFO - 2018-03-29 12:43:05 --> Form Validation Class Initialized
INFO - 2018-03-29 12:43:05 --> Controller Class Initialized
INFO - 2018-03-29 07:13:05 --> Config Class Initialized
INFO - 2018-03-29 07:13:05 --> Hooks Class Initialized
INFO - 2018-03-29 12:43:05 --> Model Class Initialized
INFO - 2018-03-29 12:43:05 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 12:43:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 12:43:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 12:43:05 --> Model Class Initialized
INFO - 2018-03-29 12:43:05 --> Model Class Initialized
INFO - 2018-03-29 12:43:05 --> Model Class Initialized
INFO - 2018-03-29 12:43:05 --> Model Class Initialized
INFO - 2018-03-29 12:43:05 --> Model Class Initialized
INFO - 2018-03-29 12:43:05 --> Model Class Initialized
INFO - 2018-03-29 12:43:05 --> Model Class Initialized
INFO - 2018-03-29 12:43:05 --> Model Class Initialized
INFO - 2018-03-29 12:43:05 --> Model Class Initialized
INFO - 2018-03-29 12:43:05 --> Model Class Initialized
INFO - 2018-03-29 12:43:05 --> Model Class Initialized
INFO - 2018-03-29 12:43:05 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 12:43:05 --> Final output sent to browser
DEBUG - 2018-03-29 12:43:05 --> Total execution time: 0.3415
DEBUG - 2018-03-29 07:13:05 --> UTF-8 Support Enabled
INFO - 2018-03-29 07:13:05 --> Utf8 Class Initialized
INFO - 2018-03-29 07:13:05 --> URI Class Initialized
INFO - 2018-03-29 07:13:06 --> Config Class Initialized
INFO - 2018-03-29 07:13:06 --> Hooks Class Initialized
DEBUG - 2018-03-29 07:13:06 --> UTF-8 Support Enabled
INFO - 2018-03-29 07:13:06 --> Utf8 Class Initialized
INFO - 2018-03-29 07:13:06 --> URI Class Initialized
INFO - 2018-03-29 07:13:06 --> Router Class Initialized
INFO - 2018-03-29 07:13:06 --> Output Class Initialized
INFO - 2018-03-29 07:13:06 --> Security Class Initialized
DEBUG - 2018-03-29 07:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 07:13:06 --> Input Class Initialized
INFO - 2018-03-29 07:13:06 --> Language Class Initialized
INFO - 2018-03-29 07:13:06 --> Language Class Initialized
INFO - 2018-03-29 07:13:06 --> Config Class Initialized
INFO - 2018-03-29 07:13:06 --> Loader Class Initialized
INFO - 2018-03-29 12:43:06 --> Helper loaded: url_helper
INFO - 2018-03-29 12:43:06 --> Helper loaded: notification_helper
INFO - 2018-03-29 12:43:06 --> Helper loaded: settings_helper
INFO - 2018-03-29 12:43:06 --> Helper loaded: permission_helper
INFO - 2018-03-29 12:43:06 --> Helper loaded: users_helper
INFO - 2018-03-29 12:43:06 --> Database Driver Class Initialized
DEBUG - 2018-03-29 12:43:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 12:43:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 12:43:06 --> Helper loaded: form_helper
INFO - 2018-03-29 12:43:06 --> Form Validation Class Initialized
INFO - 2018-03-29 12:43:06 --> Controller Class Initialized
INFO - 2018-03-29 12:43:06 --> Model Class Initialized
INFO - 2018-03-29 12:43:06 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 12:43:06 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 12:43:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 12:43:06 --> Model Class Initialized
INFO - 2018-03-29 12:43:06 --> Model Class Initialized
INFO - 2018-03-29 12:43:06 --> Model Class Initialized
INFO - 2018-03-29 12:43:06 --> Model Class Initialized
INFO - 2018-03-29 12:43:06 --> Model Class Initialized
INFO - 2018-03-29 12:43:06 --> Model Class Initialized
INFO - 2018-03-29 12:43:06 --> Model Class Initialized
INFO - 2018-03-29 12:43:06 --> Model Class Initialized
INFO - 2018-03-29 12:43:06 --> Model Class Initialized
INFO - 2018-03-29 12:43:06 --> Model Class Initialized
INFO - 2018-03-29 12:43:06 --> Model Class Initialized
INFO - 2018-03-29 12:43:06 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 12:43:06 --> Model Class Initialized
INFO - 2018-03-29 12:43:06 --> Final output sent to browser
DEBUG - 2018-03-29 12:43:06 --> Total execution time: 0.1383
INFO - 2018-03-29 07:13:06 --> Router Class Initialized
INFO - 2018-03-29 07:13:06 --> Output Class Initialized
INFO - 2018-03-29 07:13:06 --> Security Class Initialized
DEBUG - 2018-03-29 07:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 07:13:06 --> Input Class Initialized
INFO - 2018-03-29 07:13:06 --> Language Class Initialized
INFO - 2018-03-29 07:13:07 --> Language Class Initialized
INFO - 2018-03-29 07:13:07 --> Config Class Initialized
INFO - 2018-03-29 07:13:07 --> Loader Class Initialized
INFO - 2018-03-29 12:43:07 --> Helper loaded: url_helper
INFO - 2018-03-29 12:43:07 --> Helper loaded: notification_helper
INFO - 2018-03-29 12:43:07 --> Helper loaded: settings_helper
INFO - 2018-03-29 12:43:07 --> Helper loaded: permission_helper
INFO - 2018-03-29 12:43:07 --> Helper loaded: users_helper
INFO - 2018-03-29 12:43:08 --> Database Driver Class Initialized
DEBUG - 2018-03-29 12:43:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 12:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 12:43:08 --> Helper loaded: form_helper
INFO - 2018-03-29 12:43:09 --> Form Validation Class Initialized
INFO - 2018-03-29 12:43:09 --> Controller Class Initialized
INFO - 2018-03-29 12:43:09 --> Model Class Initialized
INFO - 2018-03-29 12:43:09 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 12:43:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 12:43:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 12:43:09 --> Model Class Initialized
INFO - 2018-03-29 12:43:09 --> Model Class Initialized
INFO - 2018-03-29 12:43:09 --> Model Class Initialized
INFO - 2018-03-29 12:43:09 --> Model Class Initialized
INFO - 2018-03-29 12:43:09 --> Model Class Initialized
INFO - 2018-03-29 12:43:10 --> Model Class Initialized
INFO - 2018-03-29 12:43:10 --> Model Class Initialized
INFO - 2018-03-29 12:43:10 --> Model Class Initialized
INFO - 2018-03-29 12:43:10 --> Model Class Initialized
INFO - 2018-03-29 12:43:10 --> Model Class Initialized
INFO - 2018-03-29 12:43:10 --> Model Class Initialized
INFO - 2018-03-29 12:43:10 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 12:43:10 --> Model Class Initialized
INFO - 2018-03-29 12:43:10 --> Final output sent to browser
DEBUG - 2018-03-29 12:43:10 --> Total execution time: 5.8504
INFO - 2018-03-29 07:13:14 --> Config Class Initialized
INFO - 2018-03-29 07:13:14 --> Hooks Class Initialized
DEBUG - 2018-03-29 07:13:14 --> UTF-8 Support Enabled
INFO - 2018-03-29 07:13:14 --> Utf8 Class Initialized
INFO - 2018-03-29 07:13:14 --> URI Class Initialized
INFO - 2018-03-29 07:13:14 --> Router Class Initialized
INFO - 2018-03-29 07:13:14 --> Output Class Initialized
INFO - 2018-03-29 07:13:14 --> Security Class Initialized
DEBUG - 2018-03-29 07:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 07:13:14 --> Input Class Initialized
INFO - 2018-03-29 07:13:14 --> Language Class Initialized
INFO - 2018-03-29 07:13:14 --> Language Class Initialized
INFO - 2018-03-29 07:13:14 --> Config Class Initialized
INFO - 2018-03-29 07:13:14 --> Loader Class Initialized
INFO - 2018-03-29 12:43:14 --> Helper loaded: url_helper
INFO - 2018-03-29 12:43:14 --> Helper loaded: notification_helper
INFO - 2018-03-29 12:43:14 --> Helper loaded: settings_helper
INFO - 2018-03-29 12:43:14 --> Helper loaded: permission_helper
INFO - 2018-03-29 12:43:14 --> Helper loaded: users_helper
INFO - 2018-03-29 12:43:14 --> Database Driver Class Initialized
DEBUG - 2018-03-29 12:43:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 12:43:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 12:43:14 --> Helper loaded: form_helper
INFO - 2018-03-29 12:43:14 --> Form Validation Class Initialized
INFO - 2018-03-29 12:43:14 --> Controller Class Initialized
INFO - 2018-03-29 12:43:14 --> Model Class Initialized
INFO - 2018-03-29 12:43:14 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 12:43:14 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 12:43:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 12:43:14 --> Model Class Initialized
INFO - 2018-03-29 12:43:14 --> Model Class Initialized
INFO - 2018-03-29 12:43:14 --> Model Class Initialized
INFO - 2018-03-29 12:43:14 --> Model Class Initialized
INFO - 2018-03-29 12:43:14 --> Model Class Initialized
INFO - 2018-03-29 12:43:14 --> Model Class Initialized
INFO - 2018-03-29 12:43:14 --> Model Class Initialized
INFO - 2018-03-29 12:43:14 --> Model Class Initialized
INFO - 2018-03-29 12:43:14 --> Model Class Initialized
INFO - 2018-03-29 12:43:14 --> Model Class Initialized
INFO - 2018-03-29 12:43:14 --> Model Class Initialized
INFO - 2018-03-29 12:43:14 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 12:43:14 --> Model Class Initialized
INFO - 2018-03-29 12:43:14 --> Final output sent to browser
DEBUG - 2018-03-29 12:43:14 --> Total execution time: 0.2631
INFO - 2018-03-29 07:13:15 --> Config Class Initialized
INFO - 2018-03-29 07:13:15 --> Hooks Class Initialized
DEBUG - 2018-03-29 07:13:16 --> UTF-8 Support Enabled
INFO - 2018-03-29 07:13:16 --> Utf8 Class Initialized
INFO - 2018-03-29 07:13:16 --> URI Class Initialized
INFO - 2018-03-29 07:13:16 --> Router Class Initialized
INFO - 2018-03-29 07:13:16 --> Output Class Initialized
INFO - 2018-03-29 07:13:16 --> Security Class Initialized
DEBUG - 2018-03-29 07:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 07:13:16 --> Input Class Initialized
INFO - 2018-03-29 07:13:16 --> Language Class Initialized
INFO - 2018-03-29 07:13:16 --> Config Class Initialized
INFO - 2018-03-29 07:13:16 --> Hooks Class Initialized
DEBUG - 2018-03-29 07:13:17 --> UTF-8 Support Enabled
INFO - 2018-03-29 07:13:17 --> Utf8 Class Initialized
INFO - 2018-03-29 07:13:17 --> URI Class Initialized
INFO - 2018-03-29 07:13:17 --> Router Class Initialized
INFO - 2018-03-29 07:13:17 --> Language Class Initialized
INFO - 2018-03-29 07:13:17 --> Config Class Initialized
INFO - 2018-03-29 07:13:17 --> Loader Class Initialized
INFO - 2018-03-29 07:13:17 --> Output Class Initialized
INFO - 2018-03-29 07:13:17 --> Security Class Initialized
DEBUG - 2018-03-29 07:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 07:13:17 --> Input Class Initialized
INFO - 2018-03-29 07:13:17 --> Language Class Initialized
INFO - 2018-03-29 12:43:17 --> Helper loaded: url_helper
INFO - 2018-03-29 12:43:17 --> Helper loaded: notification_helper
INFO - 2018-03-29 12:43:17 --> Helper loaded: settings_helper
INFO - 2018-03-29 12:43:17 --> Helper loaded: permission_helper
INFO - 2018-03-29 07:13:17 --> Language Class Initialized
INFO - 2018-03-29 07:13:17 --> Config Class Initialized
INFO - 2018-03-29 07:13:17 --> Loader Class Initialized
INFO - 2018-03-29 12:43:17 --> Helper loaded: users_helper
INFO - 2018-03-29 12:43:17 --> Helper loaded: url_helper
INFO - 2018-03-29 12:43:17 --> Helper loaded: notification_helper
INFO - 2018-03-29 12:43:17 --> Helper loaded: settings_helper
INFO - 2018-03-29 12:43:17 --> Helper loaded: permission_helper
INFO - 2018-03-29 12:43:17 --> Helper loaded: users_helper
INFO - 2018-03-29 12:43:17 --> Database Driver Class Initialized
DEBUG - 2018-03-29 12:43:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 12:43:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 12:43:17 --> Helper loaded: form_helper
INFO - 2018-03-29 12:43:17 --> Form Validation Class Initialized
INFO - 2018-03-29 12:43:17 --> Controller Class Initialized
INFO - 2018-03-29 12:43:17 --> Model Class Initialized
INFO - 2018-03-29 12:43:17 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 12:43:17 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 12:43:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 12:43:17 --> Model Class Initialized
INFO - 2018-03-29 12:43:17 --> Model Class Initialized
INFO - 2018-03-29 12:43:17 --> Model Class Initialized
INFO - 2018-03-29 12:43:17 --> Model Class Initialized
INFO - 2018-03-29 12:43:17 --> Model Class Initialized
INFO - 2018-03-29 12:43:17 --> Model Class Initialized
INFO - 2018-03-29 12:43:17 --> Model Class Initialized
INFO - 2018-03-29 12:43:17 --> Model Class Initialized
INFO - 2018-03-29 12:43:17 --> Model Class Initialized
INFO - 2018-03-29 12:43:17 --> Model Class Initialized
INFO - 2018-03-29 12:43:17 --> Model Class Initialized
INFO - 2018-03-29 12:43:17 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 12:43:17 --> Final output sent to browser
DEBUG - 2018-03-29 12:43:17 --> Total execution time: 0.9752
INFO - 2018-03-29 12:43:18 --> Database Driver Class Initialized
DEBUG - 2018-03-29 12:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 12:43:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 12:43:18 --> Helper loaded: form_helper
INFO - 2018-03-29 12:43:18 --> Form Validation Class Initialized
INFO - 2018-03-29 12:43:18 --> Controller Class Initialized
INFO - 2018-03-29 12:43:18 --> Model Class Initialized
INFO - 2018-03-29 12:43:18 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 12:43:18 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 12:43:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 12:43:18 --> Model Class Initialized
INFO - 2018-03-29 12:43:18 --> Model Class Initialized
INFO - 2018-03-29 12:43:18 --> Model Class Initialized
INFO - 2018-03-29 12:43:18 --> Model Class Initialized
INFO - 2018-03-29 12:43:18 --> Model Class Initialized
INFO - 2018-03-29 12:43:18 --> Model Class Initialized
INFO - 2018-03-29 12:43:18 --> Model Class Initialized
INFO - 2018-03-29 12:43:18 --> Model Class Initialized
INFO - 2018-03-29 12:43:18 --> Model Class Initialized
INFO - 2018-03-29 12:43:18 --> Model Class Initialized
INFO - 2018-03-29 12:43:18 --> Model Class Initialized
INFO - 2018-03-29 12:43:18 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 12:43:18 --> Final output sent to browser
DEBUG - 2018-03-29 12:43:18 --> Total execution time: 2.5147
INFO - 2018-03-29 07:13:24 --> Config Class Initialized
INFO - 2018-03-29 07:13:24 --> Hooks Class Initialized
DEBUG - 2018-03-29 07:13:24 --> UTF-8 Support Enabled
INFO - 2018-03-29 07:13:24 --> Utf8 Class Initialized
INFO - 2018-03-29 07:13:24 --> URI Class Initialized
INFO - 2018-03-29 07:13:24 --> Router Class Initialized
INFO - 2018-03-29 07:13:24 --> Output Class Initialized
INFO - 2018-03-29 07:13:24 --> Security Class Initialized
DEBUG - 2018-03-29 07:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 07:13:24 --> Input Class Initialized
INFO - 2018-03-29 07:13:24 --> Language Class Initialized
INFO - 2018-03-29 07:13:24 --> Language Class Initialized
INFO - 2018-03-29 07:13:24 --> Config Class Initialized
INFO - 2018-03-29 07:13:24 --> Loader Class Initialized
INFO - 2018-03-29 12:43:24 --> Helper loaded: url_helper
INFO - 2018-03-29 12:43:24 --> Helper loaded: notification_helper
INFO - 2018-03-29 12:43:24 --> Helper loaded: settings_helper
INFO - 2018-03-29 12:43:24 --> Helper loaded: permission_helper
INFO - 2018-03-29 12:43:24 --> Helper loaded: users_helper
INFO - 2018-03-29 12:43:24 --> Database Driver Class Initialized
DEBUG - 2018-03-29 12:43:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 12:43:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 12:43:24 --> Helper loaded: form_helper
INFO - 2018-03-29 12:43:24 --> Form Validation Class Initialized
INFO - 2018-03-29 12:43:24 --> Controller Class Initialized
INFO - 2018-03-29 12:43:24 --> Model Class Initialized
INFO - 2018-03-29 12:43:24 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 12:43:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 12:43:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 12:43:24 --> Model Class Initialized
INFO - 2018-03-29 12:43:24 --> Model Class Initialized
INFO - 2018-03-29 12:43:24 --> Model Class Initialized
INFO - 2018-03-29 12:43:24 --> Model Class Initialized
INFO - 2018-03-29 12:43:24 --> Final output sent to browser
DEBUG - 2018-03-29 12:43:24 --> Total execution time: 0.2047
INFO - 2018-03-29 07:13:25 --> Config Class Initialized
INFO - 2018-03-29 07:13:25 --> Hooks Class Initialized
DEBUG - 2018-03-29 07:13:25 --> UTF-8 Support Enabled
INFO - 2018-03-29 07:13:25 --> Utf8 Class Initialized
INFO - 2018-03-29 07:13:25 --> URI Class Initialized
INFO - 2018-03-29 07:13:25 --> Router Class Initialized
INFO - 2018-03-29 07:13:25 --> Output Class Initialized
INFO - 2018-03-29 07:13:26 --> Security Class Initialized
DEBUG - 2018-03-29 07:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 07:13:26 --> Input Class Initialized
INFO - 2018-03-29 07:13:26 --> Language Class Initialized
INFO - 2018-03-29 07:13:26 --> Language Class Initialized
INFO - 2018-03-29 07:13:26 --> Config Class Initialized
INFO - 2018-03-29 07:13:26 --> Loader Class Initialized
INFO - 2018-03-29 12:43:27 --> Helper loaded: url_helper
INFO - 2018-03-29 12:43:27 --> Helper loaded: notification_helper
INFO - 2018-03-29 12:43:27 --> Helper loaded: settings_helper
INFO - 2018-03-29 12:43:27 --> Helper loaded: permission_helper
INFO - 2018-03-29 12:43:27 --> Helper loaded: users_helper
INFO - 2018-03-29 12:43:28 --> Database Driver Class Initialized
INFO - 2018-03-29 07:13:28 --> Config Class Initialized
INFO - 2018-03-29 07:13:28 --> Hooks Class Initialized
DEBUG - 2018-03-29 12:43:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 12:43:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-03-29 07:13:28 --> UTF-8 Support Enabled
INFO - 2018-03-29 07:13:28 --> Utf8 Class Initialized
INFO - 2018-03-29 12:43:28 --> Helper loaded: form_helper
INFO - 2018-03-29 12:43:28 --> Form Validation Class Initialized
INFO - 2018-03-29 12:43:28 --> Controller Class Initialized
INFO - 2018-03-29 12:43:28 --> Model Class Initialized
INFO - 2018-03-29 12:43:28 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 12:43:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 12:43:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 12:43:28 --> Model Class Initialized
INFO - 2018-03-29 12:43:28 --> Model Class Initialized
INFO - 2018-03-29 12:43:28 --> Model Class Initialized
INFO - 2018-03-29 12:43:28 --> Model Class Initialized
INFO - 2018-03-29 12:43:28 --> Final output sent to browser
DEBUG - 2018-03-29 12:43:28 --> Total execution time: 3.3556
INFO - 2018-03-29 07:13:28 --> URI Class Initialized
INFO - 2018-03-29 07:13:28 --> Router Class Initialized
INFO - 2018-03-29 07:13:28 --> Output Class Initialized
INFO - 2018-03-29 07:13:29 --> Security Class Initialized
DEBUG - 2018-03-29 07:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 07:13:29 --> Input Class Initialized
INFO - 2018-03-29 07:13:29 --> Language Class Initialized
INFO - 2018-03-29 07:13:29 --> Language Class Initialized
INFO - 2018-03-29 07:13:29 --> Config Class Initialized
INFO - 2018-03-29 07:13:29 --> Loader Class Initialized
INFO - 2018-03-29 12:43:30 --> Helper loaded: url_helper
INFO - 2018-03-29 12:43:30 --> Helper loaded: notification_helper
INFO - 2018-03-29 12:43:30 --> Helper loaded: settings_helper
INFO - 2018-03-29 12:43:30 --> Helper loaded: permission_helper
INFO - 2018-03-29 12:43:30 --> Helper loaded: users_helper
INFO - 2018-03-29 12:43:30 --> Database Driver Class Initialized
DEBUG - 2018-03-29 12:43:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 12:43:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 12:43:30 --> Helper loaded: form_helper
INFO - 2018-03-29 12:43:30 --> Form Validation Class Initialized
INFO - 2018-03-29 12:43:30 --> Controller Class Initialized
INFO - 2018-03-29 12:43:31 --> Model Class Initialized
INFO - 2018-03-29 12:43:31 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 12:43:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 12:43:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 12:43:31 --> Model Class Initialized
INFO - 2018-03-29 12:43:31 --> Model Class Initialized
INFO - 2018-03-29 12:43:31 --> Model Class Initialized
INFO - 2018-03-29 12:43:31 --> Model Class Initialized
INFO - 2018-03-29 12:43:31 --> Final output sent to browser
DEBUG - 2018-03-29 12:43:31 --> Total execution time: 3.3303
INFO - 2018-03-29 08:40:08 --> Config Class Initialized
INFO - 2018-03-29 08:40:08 --> Hooks Class Initialized
DEBUG - 2018-03-29 08:40:08 --> UTF-8 Support Enabled
INFO - 2018-03-29 08:40:08 --> Utf8 Class Initialized
INFO - 2018-03-29 08:40:08 --> URI Class Initialized
INFO - 2018-03-29 08:40:08 --> Router Class Initialized
INFO - 2018-03-29 08:40:08 --> Output Class Initialized
INFO - 2018-03-29 08:40:08 --> Security Class Initialized
DEBUG - 2018-03-29 08:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 08:40:08 --> Input Class Initialized
INFO - 2018-03-29 08:40:08 --> Language Class Initialized
INFO - 2018-03-29 08:40:08 --> Language Class Initialized
INFO - 2018-03-29 08:40:08 --> Config Class Initialized
INFO - 2018-03-29 08:40:08 --> Loader Class Initialized
INFO - 2018-03-29 14:10:08 --> Helper loaded: url_helper
INFO - 2018-03-29 14:10:08 --> Helper loaded: notification_helper
INFO - 2018-03-29 14:10:08 --> Helper loaded: settings_helper
INFO - 2018-03-29 14:10:08 --> Helper loaded: permission_helper
INFO - 2018-03-29 14:10:08 --> Helper loaded: users_helper
INFO - 2018-03-29 14:10:08 --> Database Driver Class Initialized
DEBUG - 2018-03-29 14:10:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 14:10:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 14:10:08 --> Helper loaded: form_helper
INFO - 2018-03-29 14:10:08 --> Form Validation Class Initialized
INFO - 2018-03-29 14:10:08 --> Controller Class Initialized
INFO - 2018-03-29 14:10:08 --> Model Class Initialized
INFO - 2018-03-29 14:10:08 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 14:10:08 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 14:10:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 14:10:08 --> Model Class Initialized
INFO - 2018-03-29 14:10:08 --> Model Class Initialized
INFO - 2018-03-29 14:10:08 --> Model Class Initialized
INFO - 2018-03-29 14:10:08 --> Model Class Initialized
INFO - 2018-03-29 14:10:08 --> Model Class Initialized
INFO - 2018-03-29 14:10:08 --> Model Class Initialized
INFO - 2018-03-29 14:10:08 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 14:10:08 --> Final output sent to browser
DEBUG - 2018-03-29 14:10:08 --> Total execution time: 0.1213
INFO - 2018-03-29 08:40:09 --> Config Class Initialized
INFO - 2018-03-29 08:40:09 --> Hooks Class Initialized
DEBUG - 2018-03-29 08:40:09 --> UTF-8 Support Enabled
INFO - 2018-03-29 08:40:09 --> Utf8 Class Initialized
INFO - 2018-03-29 08:40:09 --> URI Class Initialized
INFO - 2018-03-29 08:40:09 --> Router Class Initialized
INFO - 2018-03-29 08:40:09 --> Output Class Initialized
INFO - 2018-03-29 08:40:09 --> Security Class Initialized
DEBUG - 2018-03-29 08:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 08:40:09 --> Input Class Initialized
INFO - 2018-03-29 08:40:09 --> Language Class Initialized
INFO - 2018-03-29 08:40:09 --> Language Class Initialized
INFO - 2018-03-29 08:40:09 --> Config Class Initialized
INFO - 2018-03-29 08:40:09 --> Loader Class Initialized
INFO - 2018-03-29 14:10:09 --> Helper loaded: url_helper
INFO - 2018-03-29 14:10:09 --> Helper loaded: notification_helper
INFO - 2018-03-29 14:10:09 --> Helper loaded: settings_helper
INFO - 2018-03-29 14:10:09 --> Helper loaded: permission_helper
INFO - 2018-03-29 14:10:09 --> Helper loaded: users_helper
INFO - 2018-03-29 08:40:10 --> Config Class Initialized
INFO - 2018-03-29 08:40:10 --> Hooks Class Initialized
INFO - 2018-03-29 08:40:10 --> Config Class Initialized
INFO - 2018-03-29 08:40:10 --> Hooks Class Initialized
DEBUG - 2018-03-29 08:40:10 --> UTF-8 Support Enabled
INFO - 2018-03-29 08:40:10 --> Utf8 Class Initialized
INFO - 2018-03-29 08:40:10 --> URI Class Initialized
INFO - 2018-03-29 08:40:10 --> Router Class Initialized
INFO - 2018-03-29 08:40:10 --> Output Class Initialized
INFO - 2018-03-29 08:40:10 --> Security Class Initialized
DEBUG - 2018-03-29 08:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 08:40:10 --> Input Class Initialized
INFO - 2018-03-29 08:40:10 --> Language Class Initialized
INFO - 2018-03-29 08:40:10 --> Language Class Initialized
INFO - 2018-03-29 08:40:10 --> Config Class Initialized
INFO - 2018-03-29 08:40:10 --> Loader Class Initialized
INFO - 2018-03-29 14:10:10 --> Helper loaded: url_helper
INFO - 2018-03-29 14:10:10 --> Helper loaded: notification_helper
INFO - 2018-03-29 14:10:10 --> Helper loaded: settings_helper
INFO - 2018-03-29 14:10:10 --> Helper loaded: permission_helper
INFO - 2018-03-29 14:10:10 --> Helper loaded: users_helper
INFO - 2018-03-29 14:10:10 --> Database Driver Class Initialized
DEBUG - 2018-03-29 14:10:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 14:10:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-03-29 08:40:10 --> UTF-8 Support Enabled
INFO - 2018-03-29 14:10:10 --> Helper loaded: form_helper
INFO - 2018-03-29 14:10:10 --> Form Validation Class Initialized
INFO - 2018-03-29 14:10:10 --> Controller Class Initialized
INFO - 2018-03-29 08:40:10 --> Utf8 Class Initialized
INFO - 2018-03-29 14:10:10 --> Model Class Initialized
INFO - 2018-03-29 14:10:10 --> Helper loaded: inflector_helper
INFO - 2018-03-29 08:40:10 --> URI Class Initialized
INFO - 2018-03-29 08:40:10 --> Router Class Initialized
DEBUG - 2018-03-29 14:10:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 08:40:10 --> Output Class Initialized
INFO - 2018-03-29 14:10:10 --> Database Driver Class Initialized
DEBUG - 2018-03-29 14:10:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 14:10:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 14:10:10 --> Helper loaded: form_helper
INFO - 2018-03-29 14:10:10 --> Form Validation Class Initialized
INFO - 2018-03-29 14:10:10 --> Controller Class Initialized
INFO - 2018-03-29 08:40:10 --> Config Class Initialized
INFO - 2018-03-29 08:40:10 --> Hooks Class Initialized
INFO - 2018-03-29 14:10:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 08:40:10 --> Security Class Initialized
DEBUG - 2018-03-29 08:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 08:40:10 --> Input Class Initialized
INFO - 2018-03-29 08:40:10 --> Language Class Initialized
INFO - 2018-03-29 14:10:10 --> Model Class Initialized
INFO - 2018-03-29 14:10:10 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 14:10:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 14:10:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 14:10:10 --> Model Class Initialized
INFO - 2018-03-29 14:10:10 --> Model Class Initialized
INFO - 2018-03-29 14:10:10 --> Model Class Initialized
INFO - 2018-03-29 14:10:10 --> Model Class Initialized
INFO - 2018-03-29 14:10:10 --> Model Class Initialized
INFO - 2018-03-29 14:10:10 --> Model Class Initialized
INFO - 2018-03-29 14:10:10 --> Model Class Initialized
INFO - 2018-03-29 14:10:10 --> Model Class Initialized
INFO - 2018-03-29 14:10:10 --> Model Class Initialized
INFO - 2018-03-29 14:10:10 --> Model Class Initialized
INFO - 2018-03-29 14:10:10 --> Model Class Initialized
INFO - 2018-03-29 14:10:10 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 14:10:10 --> Model Class Initialized
INFO - 2018-03-29 08:40:10 --> Language Class Initialized
INFO - 2018-03-29 08:40:10 --> Config Class Initialized
INFO - 2018-03-29 08:40:10 --> Loader Class Initialized
INFO - 2018-03-29 14:10:10 --> Helper loaded: url_helper
INFO - 2018-03-29 14:10:10 --> Helper loaded: notification_helper
INFO - 2018-03-29 14:10:10 --> Helper loaded: settings_helper
INFO - 2018-03-29 14:10:10 --> Helper loaded: permission_helper
INFO - 2018-03-29 14:10:10 --> Helper loaded: users_helper
INFO - 2018-03-29 14:10:10 --> Model Class Initialized
INFO - 2018-03-29 14:10:10 --> Final output sent to browser
DEBUG - 2018-03-29 14:10:10 --> Total execution time: 1.0817
INFO - 2018-03-29 14:10:10 --> Model Class Initialized
INFO - 2018-03-29 14:10:10 --> Database Driver Class Initialized
DEBUG - 2018-03-29 14:10:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 14:10:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 14:10:10 --> Helper loaded: form_helper
INFO - 2018-03-29 14:10:10 --> Form Validation Class Initialized
INFO - 2018-03-29 14:10:10 --> Controller Class Initialized
INFO - 2018-03-29 14:10:10 --> Model Class Initialized
INFO - 2018-03-29 14:10:10 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 08:40:10 --> UTF-8 Support Enabled
INFO - 2018-03-29 08:40:10 --> Utf8 Class Initialized
DEBUG - 2018-03-29 14:10:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 14:10:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 14:10:10 --> Model Class Initialized
INFO - 2018-03-29 14:10:10 --> Model Class Initialized
INFO - 2018-03-29 14:10:10 --> Model Class Initialized
INFO - 2018-03-29 14:10:10 --> Model Class Initialized
INFO - 2018-03-29 14:10:10 --> Model Class Initialized
INFO - 2018-03-29 14:10:10 --> Model Class Initialized
INFO - 2018-03-29 14:10:10 --> Model Class Initialized
INFO - 2018-03-29 14:10:10 --> Model Class Initialized
INFO - 2018-03-29 14:10:10 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 14:10:10 --> Model Class Initialized
INFO - 2018-03-29 14:10:10 --> Model Class Initialized
INFO - 2018-03-29 14:10:10 --> Model Class Initialized
INFO - 2018-03-29 14:10:10 --> Final output sent to browser
DEBUG - 2018-03-29 14:10:10 --> Total execution time: 0.5128
INFO - 2018-03-29 14:10:10 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 14:10:10 --> Model Class Initialized
INFO - 2018-03-29 08:40:10 --> URI Class Initialized
INFO - 2018-03-29 14:10:10 --> Final output sent to browser
DEBUG - 2018-03-29 14:10:10 --> Total execution time: 0.4767
INFO - 2018-03-29 08:40:10 --> Router Class Initialized
INFO - 2018-03-29 08:40:10 --> Output Class Initialized
INFO - 2018-03-29 08:40:10 --> Security Class Initialized
DEBUG - 2018-03-29 08:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 08:40:10 --> Input Class Initialized
INFO - 2018-03-29 08:40:10 --> Language Class Initialized
INFO - 2018-03-29 08:40:11 --> Language Class Initialized
INFO - 2018-03-29 08:40:11 --> Config Class Initialized
INFO - 2018-03-29 08:40:11 --> Loader Class Initialized
INFO - 2018-03-29 14:10:11 --> Helper loaded: url_helper
INFO - 2018-03-29 14:10:11 --> Helper loaded: notification_helper
INFO - 2018-03-29 14:10:11 --> Helper loaded: settings_helper
INFO - 2018-03-29 14:10:11 --> Helper loaded: permission_helper
INFO - 2018-03-29 14:10:11 --> Helper loaded: users_helper
INFO - 2018-03-29 08:40:11 --> Config Class Initialized
INFO - 2018-03-29 08:40:11 --> Hooks Class Initialized
DEBUG - 2018-03-29 08:40:11 --> UTF-8 Support Enabled
INFO - 2018-03-29 08:40:11 --> Utf8 Class Initialized
INFO - 2018-03-29 08:40:11 --> URI Class Initialized
INFO - 2018-03-29 08:40:11 --> Router Class Initialized
INFO - 2018-03-29 08:40:11 --> Output Class Initialized
INFO - 2018-03-29 08:40:11 --> Security Class Initialized
DEBUG - 2018-03-29 08:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 08:40:11 --> Input Class Initialized
INFO - 2018-03-29 08:40:11 --> Language Class Initialized
INFO - 2018-03-29 08:40:11 --> Language Class Initialized
INFO - 2018-03-29 08:40:11 --> Config Class Initialized
INFO - 2018-03-29 08:40:11 --> Loader Class Initialized
INFO - 2018-03-29 14:10:11 --> Helper loaded: url_helper
INFO - 2018-03-29 14:10:11 --> Helper loaded: notification_helper
INFO - 2018-03-29 14:10:11 --> Helper loaded: settings_helper
INFO - 2018-03-29 14:10:11 --> Helper loaded: permission_helper
INFO - 2018-03-29 14:10:11 --> Helper loaded: users_helper
INFO - 2018-03-29 08:40:12 --> Config Class Initialized
INFO - 2018-03-29 08:40:12 --> Hooks Class Initialized
DEBUG - 2018-03-29 08:40:12 --> UTF-8 Support Enabled
INFO - 2018-03-29 08:40:12 --> Utf8 Class Initialized
INFO - 2018-03-29 08:40:12 --> URI Class Initialized
INFO - 2018-03-29 08:40:12 --> Router Class Initialized
INFO - 2018-03-29 08:40:12 --> Output Class Initialized
INFO - 2018-03-29 08:40:12 --> Security Class Initialized
DEBUG - 2018-03-29 08:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 08:40:12 --> Input Class Initialized
INFO - 2018-03-29 08:40:12 --> Language Class Initialized
INFO - 2018-03-29 08:40:12 --> Config Class Initialized
INFO - 2018-03-29 08:40:12 --> Hooks Class Initialized
INFO - 2018-03-29 14:10:12 --> Database Driver Class Initialized
DEBUG - 2018-03-29 14:10:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-29 08:40:12 --> UTF-8 Support Enabled
INFO - 2018-03-29 08:40:12 --> Utf8 Class Initialized
INFO - 2018-03-29 14:10:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 08:40:12 --> URI Class Initialized
INFO - 2018-03-29 08:40:12 --> Router Class Initialized
INFO - 2018-03-29 14:10:12 --> Helper loaded: form_helper
INFO - 2018-03-29 14:10:12 --> Form Validation Class Initialized
INFO - 2018-03-29 08:40:12 --> Output Class Initialized
INFO - 2018-03-29 14:10:12 --> Controller Class Initialized
INFO - 2018-03-29 14:10:12 --> Database Driver Class Initialized
DEBUG - 2018-03-29 14:10:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 14:10:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 14:10:12 --> Helper loaded: form_helper
INFO - 2018-03-29 14:10:12 --> Form Validation Class Initialized
INFO - 2018-03-29 14:10:12 --> Controller Class Initialized
INFO - 2018-03-29 08:40:12 --> Security Class Initialized
INFO - 2018-03-29 14:10:12 --> Model Class Initialized
INFO - 2018-03-29 14:10:12 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 14:10:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 14:10:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 14:10:12 --> Model Class Initialized
INFO - 2018-03-29 14:10:12 --> Model Class Initialized
INFO - 2018-03-29 14:10:12 --> Model Class Initialized
INFO - 2018-03-29 14:10:12 --> Model Class Initialized
INFO - 2018-03-29 14:10:12 --> Model Class Initialized
INFO - 2018-03-29 14:10:12 --> Model Class Initialized
INFO - 2018-03-29 14:10:12 --> Model Class Initialized
INFO - 2018-03-29 14:10:12 --> Model Class Initialized
INFO - 2018-03-29 14:10:12 --> Model Class Initialized
INFO - 2018-03-29 14:10:12 --> Model Class Initialized
INFO - 2018-03-29 14:10:12 --> Model Class Initialized
INFO - 2018-03-29 14:10:12 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 14:10:12 --> Model Class Initialized
DEBUG - 2018-03-29 08:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 08:40:12 --> Input Class Initialized
INFO - 2018-03-29 08:40:12 --> Language Class Initialized
INFO - 2018-03-29 14:10:12 --> Final output sent to browser
DEBUG - 2018-03-29 14:10:12 --> Total execution time: 2.5207
INFO - 2018-03-29 08:40:12 --> Language Class Initialized
INFO - 2018-03-29 08:40:12 --> Config Class Initialized
INFO - 2018-03-29 08:40:12 --> Loader Class Initialized
INFO - 2018-03-29 08:40:12 --> Language Class Initialized
INFO - 2018-03-29 08:40:12 --> Config Class Initialized
INFO - 2018-03-29 08:40:12 --> Loader Class Initialized
INFO - 2018-03-29 14:10:12 --> Helper loaded: url_helper
INFO - 2018-03-29 14:10:12 --> Helper loaded: notification_helper
INFO - 2018-03-29 14:10:12 --> Helper loaded: settings_helper
INFO - 2018-03-29 14:10:12 --> Helper loaded: permission_helper
INFO - 2018-03-29 14:10:12 --> Helper loaded: users_helper
INFO - 2018-03-29 14:10:12 --> Helper loaded: url_helper
INFO - 2018-03-29 14:10:12 --> Helper loaded: notification_helper
INFO - 2018-03-29 14:10:12 --> Helper loaded: settings_helper
INFO - 2018-03-29 14:10:12 --> Helper loaded: permission_helper
INFO - 2018-03-29 14:10:12 --> Model Class Initialized
INFO - 2018-03-29 14:10:12 --> Helper loaded: users_helper
INFO - 2018-03-29 14:10:12 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 14:10:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 14:10:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 14:10:12 --> Model Class Initialized
INFO - 2018-03-29 14:10:12 --> Model Class Initialized
INFO - 2018-03-29 14:10:12 --> Model Class Initialized
INFO - 2018-03-29 14:10:12 --> Model Class Initialized
INFO - 2018-03-29 14:10:12 --> Model Class Initialized
INFO - 2018-03-29 14:10:12 --> Model Class Initialized
INFO - 2018-03-29 14:10:12 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-29 14:10:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-03-29 14:10:12 --> Final output sent to browser
DEBUG - 2018-03-29 14:10:12 --> Total execution time: 1.2529
INFO - 2018-03-29 14:10:12 --> Database Driver Class Initialized
DEBUG - 2018-03-29 14:10:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 14:10:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 14:10:12 --> Helper loaded: form_helper
INFO - 2018-03-29 14:10:12 --> Form Validation Class Initialized
INFO - 2018-03-29 14:10:12 --> Controller Class Initialized
INFO - 2018-03-29 14:10:13 --> Model Class Initialized
INFO - 2018-03-29 14:10:13 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 14:10:13 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 14:10:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 14:10:13 --> Model Class Initialized
INFO - 2018-03-29 14:10:13 --> Model Class Initialized
INFO - 2018-03-29 14:10:13 --> Model Class Initialized
INFO - 2018-03-29 14:10:13 --> Model Class Initialized
INFO - 2018-03-29 14:10:13 --> Model Class Initialized
INFO - 2018-03-29 14:10:13 --> Model Class Initialized
INFO - 2018-03-29 14:10:13 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-29 14:10:13 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-03-29 14:10:13 --> Final output sent to browser
DEBUG - 2018-03-29 14:10:13 --> Total execution time: 1.1176
INFO - 2018-03-29 14:10:13 --> Database Driver Class Initialized
DEBUG - 2018-03-29 14:10:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 14:10:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 14:10:13 --> Helper loaded: form_helper
INFO - 2018-03-29 14:10:13 --> Form Validation Class Initialized
INFO - 2018-03-29 14:10:13 --> Controller Class Initialized
INFO - 2018-03-29 14:10:13 --> Model Class Initialized
INFO - 2018-03-29 14:10:13 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 14:10:13 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 14:10:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 14:10:13 --> Model Class Initialized
INFO - 2018-03-29 14:10:13 --> Model Class Initialized
INFO - 2018-03-29 14:10:13 --> Model Class Initialized
INFO - 2018-03-29 14:10:13 --> Model Class Initialized
INFO - 2018-03-29 14:10:13 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 14:10:13 --> Final output sent to browser
DEBUG - 2018-03-29 14:10:13 --> Total execution time: 1.3228
INFO - 2018-03-29 08:40:14 --> Config Class Initialized
INFO - 2018-03-29 08:40:14 --> Hooks Class Initialized
DEBUG - 2018-03-29 08:40:14 --> UTF-8 Support Enabled
INFO - 2018-03-29 08:40:14 --> Utf8 Class Initialized
INFO - 2018-03-29 08:40:14 --> URI Class Initialized
INFO - 2018-03-29 08:40:14 --> Config Class Initialized
INFO - 2018-03-29 08:40:14 --> Hooks Class Initialized
INFO - 2018-03-29 08:40:14 --> Router Class Initialized
DEBUG - 2018-03-29 08:40:14 --> UTF-8 Support Enabled
INFO - 2018-03-29 08:40:14 --> Utf8 Class Initialized
INFO - 2018-03-29 08:40:14 --> Output Class Initialized
INFO - 2018-03-29 08:40:14 --> URI Class Initialized
INFO - 2018-03-29 08:40:14 --> Security Class Initialized
INFO - 2018-03-29 08:40:14 --> Router Class Initialized
DEBUG - 2018-03-29 08:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 08:40:14 --> Input Class Initialized
INFO - 2018-03-29 08:40:14 --> Language Class Initialized
INFO - 2018-03-29 08:40:14 --> Output Class Initialized
INFO - 2018-03-29 08:40:14 --> Security Class Initialized
DEBUG - 2018-03-29 08:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 08:40:14 --> Input Class Initialized
INFO - 2018-03-29 08:40:14 --> Language Class Initialized
INFO - 2018-03-29 08:40:14 --> Language Class Initialized
INFO - 2018-03-29 08:40:14 --> Config Class Initialized
INFO - 2018-03-29 08:40:14 --> Loader Class Initialized
INFO - 2018-03-29 14:10:14 --> Helper loaded: url_helper
INFO - 2018-03-29 14:10:14 --> Helper loaded: notification_helper
INFO - 2018-03-29 14:10:14 --> Helper loaded: settings_helper
INFO - 2018-03-29 08:40:14 --> Language Class Initialized
INFO - 2018-03-29 08:40:14 --> Config Class Initialized
INFO - 2018-03-29 08:40:14 --> Loader Class Initialized
INFO - 2018-03-29 14:10:14 --> Helper loaded: permission_helper
INFO - 2018-03-29 14:10:14 --> Helper loaded: users_helper
INFO - 2018-03-29 14:10:14 --> Helper loaded: url_helper
INFO - 2018-03-29 14:10:14 --> Helper loaded: notification_helper
INFO - 2018-03-29 14:10:14 --> Helper loaded: settings_helper
INFO - 2018-03-29 14:10:14 --> Helper loaded: permission_helper
INFO - 2018-03-29 14:10:14 --> Helper loaded: users_helper
INFO - 2018-03-29 14:10:14 --> Database Driver Class Initialized
DEBUG - 2018-03-29 14:10:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 14:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 14:10:14 --> Database Driver Class Initialized
DEBUG - 2018-03-29 14:10:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 14:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 14:10:14 --> Helper loaded: form_helper
INFO - 2018-03-29 14:10:14 --> Form Validation Class Initialized
INFO - 2018-03-29 14:10:14 --> Controller Class Initialized
INFO - 2018-03-29 14:10:14 --> Helper loaded: form_helper
INFO - 2018-03-29 14:10:14 --> Form Validation Class Initialized
INFO - 2018-03-29 14:10:14 --> Controller Class Initialized
INFO - 2018-03-29 14:10:14 --> Model Class Initialized
INFO - 2018-03-29 14:10:14 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 14:10:14 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 14:10:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 14:10:14 --> Model Class Initialized
INFO - 2018-03-29 14:10:14 --> Model Class Initialized
INFO - 2018-03-29 14:10:14 --> Model Class Initialized
INFO - 2018-03-29 14:10:14 --> Helper loaded: inflector_helper
INFO - 2018-03-29 14:10:14 --> Model Class Initialized
INFO - 2018-03-29 14:10:14 --> Model Class Initialized
INFO - 2018-03-29 14:10:14 --> Model Class Initialized
INFO - 2018-03-29 14:10:14 --> Model Class Initialized
INFO - 2018-03-29 14:10:14 --> Model Class Initialized
INFO - 2018-03-29 14:10:14 --> Model Class Initialized
INFO - 2018-03-29 14:10:14 --> Model Class Initialized
INFO - 2018-03-29 14:10:14 --> Model Class Initialized
DEBUG - 2018-03-29 14:10:14 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 14:10:14 --> Model Class Initialized
INFO - 2018-03-29 14:10:14 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 14:10:14 --> Model Class Initialized
INFO - 2018-03-29 14:10:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 14:10:14 --> Model Class Initialized
INFO - 2018-03-29 14:10:14 --> Model Class Initialized
INFO - 2018-03-29 14:10:14 --> Model Class Initialized
INFO - 2018-03-29 14:10:14 --> Model Class Initialized
INFO - 2018-03-29 14:10:14 --> Model Class Initialized
INFO - 2018-03-29 14:10:14 --> Model Class Initialized
INFO - 2018-03-29 14:10:14 --> Final output sent to browser
DEBUG - 2018-03-29 14:10:14 --> Total execution time: 0.3606
INFO - 2018-03-29 14:10:14 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 14:10:14 --> Model Class Initialized
INFO - 2018-03-29 14:10:14 --> Final output sent to browser
DEBUG - 2018-03-29 14:10:14 --> Total execution time: 0.4075
INFO - 2018-03-29 08:40:16 --> Config Class Initialized
INFO - 2018-03-29 08:40:16 --> Hooks Class Initialized
DEBUG - 2018-03-29 08:40:16 --> UTF-8 Support Enabled
INFO - 2018-03-29 08:40:16 --> Utf8 Class Initialized
INFO - 2018-03-29 08:40:16 --> URI Class Initialized
INFO - 2018-03-29 08:40:16 --> Router Class Initialized
INFO - 2018-03-29 08:40:16 --> Output Class Initialized
INFO - 2018-03-29 08:40:16 --> Security Class Initialized
DEBUG - 2018-03-29 08:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 08:40:16 --> Input Class Initialized
INFO - 2018-03-29 08:40:16 --> Language Class Initialized
INFO - 2018-03-29 08:40:16 --> Language Class Initialized
INFO - 2018-03-29 08:40:16 --> Config Class Initialized
INFO - 2018-03-29 08:40:16 --> Loader Class Initialized
INFO - 2018-03-29 14:10:16 --> Helper loaded: url_helper
INFO - 2018-03-29 14:10:16 --> Helper loaded: notification_helper
INFO - 2018-03-29 14:10:16 --> Helper loaded: settings_helper
INFO - 2018-03-29 14:10:16 --> Helper loaded: permission_helper
INFO - 2018-03-29 14:10:16 --> Helper loaded: users_helper
INFO - 2018-03-29 08:40:16 --> Config Class Initialized
INFO - 2018-03-29 08:40:16 --> Hooks Class Initialized
INFO - 2018-03-29 14:10:16 --> Database Driver Class Initialized
DEBUG - 2018-03-29 08:40:16 --> UTF-8 Support Enabled
INFO - 2018-03-29 08:40:16 --> Utf8 Class Initialized
DEBUG - 2018-03-29 14:10:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 14:10:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 08:40:16 --> URI Class Initialized
INFO - 2018-03-29 08:40:16 --> Router Class Initialized
INFO - 2018-03-29 08:40:16 --> Config Class Initialized
INFO - 2018-03-29 08:40:16 --> Hooks Class Initialized
INFO - 2018-03-29 08:40:16 --> Output Class Initialized
DEBUG - 2018-03-29 08:40:16 --> UTF-8 Support Enabled
INFO - 2018-03-29 08:40:16 --> Utf8 Class Initialized
INFO - 2018-03-29 14:10:16 --> Helper loaded: form_helper
INFO - 2018-03-29 14:10:16 --> Form Validation Class Initialized
INFO - 2018-03-29 14:10:16 --> Controller Class Initialized
INFO - 2018-03-29 08:40:16 --> Security Class Initialized
INFO - 2018-03-29 08:40:16 --> URI Class Initialized
DEBUG - 2018-03-29 08:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 08:40:17 --> Input Class Initialized
INFO - 2018-03-29 08:40:17 --> Language Class Initialized
INFO - 2018-03-29 08:40:17 --> Router Class Initialized
INFO - 2018-03-29 14:10:17 --> Model Class Initialized
INFO - 2018-03-29 14:10:17 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 14:10:17 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 08:40:17 --> Output Class Initialized
INFO - 2018-03-29 14:10:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 14:10:17 --> Model Class Initialized
INFO - 2018-03-29 14:10:17 --> Model Class Initialized
INFO - 2018-03-29 08:40:17 --> Security Class Initialized
INFO - 2018-03-29 14:10:17 --> Model Class Initialized
INFO - 2018-03-29 14:10:17 --> Model Class Initialized
INFO - 2018-03-29 14:10:17 --> Model Class Initialized
INFO - 2018-03-29 14:10:17 --> Model Class Initialized
INFO - 2018-03-29 14:10:17 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-03-29 08:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 08:40:17 --> Input Class Initialized
ERROR - 2018-03-29 14:10:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-03-29 14:10:17 --> Final output sent to browser
DEBUG - 2018-03-29 14:10:17 --> Total execution time: 1.2944
INFO - 2018-03-29 08:40:17 --> Language Class Initialized
INFO - 2018-03-29 08:40:17 --> Language Class Initialized
INFO - 2018-03-29 08:40:17 --> Config Class Initialized
INFO - 2018-03-29 08:40:17 --> Loader Class Initialized
INFO - 2018-03-29 14:10:17 --> Helper loaded: url_helper
INFO - 2018-03-29 14:10:17 --> Helper loaded: notification_helper
INFO - 2018-03-29 14:10:17 --> Helper loaded: settings_helper
INFO - 2018-03-29 08:40:17 --> Language Class Initialized
INFO - 2018-03-29 08:40:18 --> Config Class Initialized
INFO - 2018-03-29 08:40:18 --> Loader Class Initialized
INFO - 2018-03-29 14:10:18 --> Helper loaded: permission_helper
INFO - 2018-03-29 14:10:18 --> Helper loaded: users_helper
INFO - 2018-03-29 14:10:18 --> Helper loaded: url_helper
INFO - 2018-03-29 14:10:18 --> Helper loaded: notification_helper
INFO - 2018-03-29 14:10:18 --> Helper loaded: settings_helper
INFO - 2018-03-29 14:10:18 --> Helper loaded: permission_helper
INFO - 2018-03-29 14:10:18 --> Helper loaded: users_helper
INFO - 2018-03-29 08:40:18 --> Config Class Initialized
INFO - 2018-03-29 08:40:18 --> Hooks Class Initialized
DEBUG - 2018-03-29 08:40:18 --> UTF-8 Support Enabled
INFO - 2018-03-29 08:40:18 --> Utf8 Class Initialized
INFO - 2018-03-29 08:40:18 --> URI Class Initialized
INFO - 2018-03-29 08:40:18 --> Router Class Initialized
INFO - 2018-03-29 08:40:18 --> Output Class Initialized
INFO - 2018-03-29 08:40:18 --> Security Class Initialized
DEBUG - 2018-03-29 08:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 08:40:18 --> Input Class Initialized
INFO - 2018-03-29 08:40:18 --> Language Class Initialized
INFO - 2018-03-29 08:40:18 --> Language Class Initialized
INFO - 2018-03-29 08:40:18 --> Config Class Initialized
INFO - 2018-03-29 08:40:18 --> Loader Class Initialized
INFO - 2018-03-29 14:10:18 --> Helper loaded: url_helper
INFO - 2018-03-29 14:10:18 --> Helper loaded: notification_helper
INFO - 2018-03-29 14:10:18 --> Helper loaded: settings_helper
INFO - 2018-03-29 14:10:18 --> Helper loaded: permission_helper
INFO - 2018-03-29 14:10:18 --> Helper loaded: users_helper
INFO - 2018-03-29 08:40:18 --> Config Class Initialized
INFO - 2018-03-29 08:40:18 --> Hooks Class Initialized
DEBUG - 2018-03-29 08:40:18 --> UTF-8 Support Enabled
INFO - 2018-03-29 08:40:18 --> Utf8 Class Initialized
INFO - 2018-03-29 08:40:18 --> URI Class Initialized
INFO - 2018-03-29 08:40:18 --> Router Class Initialized
INFO - 2018-03-29 08:40:18 --> Output Class Initialized
INFO - 2018-03-29 08:40:18 --> Security Class Initialized
DEBUG - 2018-03-29 08:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 08:40:18 --> Input Class Initialized
INFO - 2018-03-29 08:40:18 --> Language Class Initialized
INFO - 2018-03-29 14:10:18 --> Database Driver Class Initialized
INFO - 2018-03-29 08:40:18 --> Language Class Initialized
INFO - 2018-03-29 08:40:18 --> Config Class Initialized
INFO - 2018-03-29 08:40:18 --> Loader Class Initialized
INFO - 2018-03-29 14:10:18 --> Helper loaded: url_helper
INFO - 2018-03-29 14:10:18 --> Helper loaded: notification_helper
INFO - 2018-03-29 14:10:18 --> Helper loaded: settings_helper
INFO - 2018-03-29 14:10:18 --> Helper loaded: permission_helper
DEBUG - 2018-03-29 14:10:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 14:10:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 14:10:18 --> Helper loaded: users_helper
INFO - 2018-03-29 14:10:18 --> Database Driver Class Initialized
INFO - 2018-03-29 14:10:18 --> Helper loaded: form_helper
INFO - 2018-03-29 14:10:18 --> Form Validation Class Initialized
INFO - 2018-03-29 14:10:18 --> Controller Class Initialized
DEBUG - 2018-03-29 14:10:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 14:10:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 14:10:18 --> Helper loaded: form_helper
INFO - 2018-03-29 14:10:18 --> Form Validation Class Initialized
INFO - 2018-03-29 14:10:18 --> Controller Class Initialized
INFO - 2018-03-29 14:10:18 --> Model Class Initialized
INFO - 2018-03-29 14:10:18 --> Helper loaded: inflector_helper
INFO - 2018-03-29 14:10:18 --> Model Class Initialized
INFO - 2018-03-29 14:10:18 --> Database Driver Class Initialized
INFO - 2018-03-29 14:10:18 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 14:10:18 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-03-29 14:10:18 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 14:10:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 14:10:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 14:10:18 --> Model Class Initialized
INFO - 2018-03-29 14:10:18 --> Model Class Initialized
DEBUG - 2018-03-29 14:10:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 14:10:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 14:10:18 --> Model Class Initialized
INFO - 2018-03-29 14:10:18 --> Helper loaded: form_helper
INFO - 2018-03-29 14:10:18 --> Form Validation Class Initialized
INFO - 2018-03-29 14:10:18 --> Controller Class Initialized
INFO - 2018-03-29 14:10:18 --> Model Class Initialized
INFO - 2018-03-29 14:10:18 --> Model Class Initialized
INFO - 2018-03-29 14:10:18 --> Model Class Initialized
INFO - 2018-03-29 14:10:18 --> Helper loaded: inflector_helper
INFO - 2018-03-29 14:10:18 --> Model Class Initialized
INFO - 2018-03-29 14:10:18 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-03-29 14:10:18 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 14:10:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 14:10:18 --> Model Class Initialized
INFO - 2018-03-29 14:10:18 --> Model Class Initialized
INFO - 2018-03-29 14:10:18 --> Model Class Initialized
INFO - 2018-03-29 14:10:18 --> Model Class Initialized
INFO - 2018-03-29 14:10:18 --> Model Class Initialized
INFO - 2018-03-29 14:10:18 --> Model Class Initialized
INFO - 2018-03-29 14:10:18 --> Model Class Initialized
INFO - 2018-03-29 14:10:18 --> Model Class Initialized
INFO - 2018-03-29 14:10:18 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 14:10:18 --> Final output sent to browser
DEBUG - 2018-03-29 14:10:18 --> Total execution time: 0.2728
INFO - 2018-03-29 14:10:18 --> Model Class Initialized
ERROR - 2018-03-29 14:10:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-03-29 14:10:18 --> Final output sent to browser
DEBUG - 2018-03-29 14:10:18 --> Total execution time: 2.3099
INFO - 2018-03-29 14:10:18 --> Model Class Initialized
INFO - 2018-03-29 14:10:18 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-29 14:10:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-03-29 14:10:18 --> Final output sent to browser
DEBUG - 2018-03-29 14:10:18 --> Total execution time: 0.2718
INFO - 2018-03-29 14:10:18 --> Database Driver Class Initialized
DEBUG - 2018-03-29 14:10:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 14:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 14:10:19 --> Helper loaded: form_helper
INFO - 2018-03-29 14:10:19 --> Form Validation Class Initialized
INFO - 2018-03-29 14:10:19 --> Controller Class Initialized
INFO - 2018-03-29 14:10:19 --> Model Class Initialized
INFO - 2018-03-29 14:10:20 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 14:10:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 08:40:20 --> Config Class Initialized
INFO - 2018-03-29 08:40:20 --> Hooks Class Initialized
DEBUG - 2018-03-29 08:40:20 --> UTF-8 Support Enabled
INFO - 2018-03-29 08:40:20 --> Utf8 Class Initialized
INFO - 2018-03-29 08:40:20 --> URI Class Initialized
INFO - 2018-03-29 08:40:20 --> Router Class Initialized
INFO - 2018-03-29 08:40:20 --> Output Class Initialized
INFO - 2018-03-29 08:40:20 --> Security Class Initialized
DEBUG - 2018-03-29 08:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 08:40:20 --> Input Class Initialized
INFO - 2018-03-29 08:40:20 --> Language Class Initialized
INFO - 2018-03-29 14:10:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 08:40:20 --> Language Class Initialized
INFO - 2018-03-29 08:40:20 --> Config Class Initialized
INFO - 2018-03-29 08:40:20 --> Loader Class Initialized
INFO - 2018-03-29 14:10:20 --> Helper loaded: url_helper
INFO - 2018-03-29 14:10:20 --> Helper loaded: notification_helper
INFO - 2018-03-29 14:10:20 --> Helper loaded: settings_helper
INFO - 2018-03-29 14:10:20 --> Helper loaded: permission_helper
INFO - 2018-03-29 14:10:20 --> Helper loaded: users_helper
INFO - 2018-03-29 14:10:20 --> Model Class Initialized
INFO - 2018-03-29 14:10:20 --> Model Class Initialized
INFO - 2018-03-29 14:10:20 --> Database Driver Class Initialized
DEBUG - 2018-03-29 14:10:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 14:10:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 14:10:20 --> Helper loaded: form_helper
INFO - 2018-03-29 14:10:20 --> Form Validation Class Initialized
INFO - 2018-03-29 14:10:20 --> Controller Class Initialized
INFO - 2018-03-29 14:10:20 --> Model Class Initialized
INFO - 2018-03-29 14:10:20 --> Helper loaded: inflector_helper
INFO - 2018-03-29 14:10:20 --> Model Class Initialized
DEBUG - 2018-03-29 14:10:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 14:10:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 14:10:20 --> Model Class Initialized
INFO - 2018-03-29 14:10:20 --> Model Class Initialized
INFO - 2018-03-29 14:10:20 --> Model Class Initialized
INFO - 2018-03-29 14:10:20 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 14:10:20 --> Final output sent to browser
DEBUG - 2018-03-29 14:10:20 --> Total execution time: 0.2825
INFO - 2018-03-29 14:10:20 --> Final output sent to browser
DEBUG - 2018-03-29 14:10:20 --> Total execution time: 3.9262
INFO - 2018-03-29 08:40:25 --> Config Class Initialized
INFO - 2018-03-29 08:40:25 --> Hooks Class Initialized
DEBUG - 2018-03-29 08:40:26 --> UTF-8 Support Enabled
INFO - 2018-03-29 08:40:26 --> Utf8 Class Initialized
INFO - 2018-03-29 08:40:26 --> Config Class Initialized
INFO - 2018-03-29 08:40:26 --> Hooks Class Initialized
DEBUG - 2018-03-29 08:40:26 --> UTF-8 Support Enabled
INFO - 2018-03-29 08:40:26 --> Utf8 Class Initialized
INFO - 2018-03-29 08:40:26 --> URI Class Initialized
INFO - 2018-03-29 08:40:26 --> URI Class Initialized
INFO - 2018-03-29 08:40:26 --> Router Class Initialized
INFO - 2018-03-29 08:40:26 --> Output Class Initialized
INFO - 2018-03-29 08:40:26 --> Security Class Initialized
DEBUG - 2018-03-29 08:40:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 08:40:26 --> Input Class Initialized
INFO - 2018-03-29 08:40:26 --> Language Class Initialized
INFO - 2018-03-29 08:40:26 --> Router Class Initialized
INFO - 2018-03-29 08:40:26 --> Language Class Initialized
INFO - 2018-03-29 08:40:26 --> Config Class Initialized
INFO - 2018-03-29 08:40:26 --> Loader Class Initialized
INFO - 2018-03-29 14:10:26 --> Helper loaded: url_helper
INFO - 2018-03-29 14:10:26 --> Helper loaded: notification_helper
INFO - 2018-03-29 14:10:26 --> Helper loaded: settings_helper
INFO - 2018-03-29 14:10:26 --> Helper loaded: permission_helper
INFO - 2018-03-29 14:10:26 --> Helper loaded: users_helper
INFO - 2018-03-29 14:10:26 --> Database Driver Class Initialized
DEBUG - 2018-03-29 14:10:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 14:10:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 14:10:26 --> Helper loaded: form_helper
INFO - 2018-03-29 14:10:26 --> Form Validation Class Initialized
INFO - 2018-03-29 14:10:26 --> Controller Class Initialized
INFO - 2018-03-29 14:10:26 --> Model Class Initialized
INFO - 2018-03-29 14:10:26 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 14:10:26 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 14:10:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 14:10:26 --> Model Class Initialized
INFO - 2018-03-29 14:10:26 --> Model Class Initialized
INFO - 2018-03-29 14:10:26 --> Final output sent to browser
DEBUG - 2018-03-29 14:10:26 --> Total execution time: 0.5893
INFO - 2018-03-29 08:40:26 --> Output Class Initialized
INFO - 2018-03-29 08:40:26 --> Security Class Initialized
DEBUG - 2018-03-29 08:40:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 08:40:26 --> Input Class Initialized
INFO - 2018-03-29 08:40:27 --> Language Class Initialized
INFO - 2018-03-29 08:40:27 --> Language Class Initialized
INFO - 2018-03-29 08:40:27 --> Config Class Initialized
INFO - 2018-03-29 08:40:27 --> Loader Class Initialized
INFO - 2018-03-29 14:10:27 --> Helper loaded: url_helper
INFO - 2018-03-29 14:10:27 --> Helper loaded: notification_helper
INFO - 2018-03-29 14:10:27 --> Helper loaded: settings_helper
INFO - 2018-03-29 14:10:27 --> Helper loaded: permission_helper
INFO - 2018-03-29 14:10:27 --> Helper loaded: users_helper
INFO - 2018-03-29 14:10:27 --> Database Driver Class Initialized
DEBUG - 2018-03-29 14:10:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 14:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 14:10:27 --> Helper loaded: form_helper
INFO - 2018-03-29 14:10:27 --> Form Validation Class Initialized
INFO - 2018-03-29 14:10:27 --> Controller Class Initialized
INFO - 2018-03-29 14:10:27 --> Model Class Initialized
INFO - 2018-03-29 14:10:27 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 14:10:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 14:10:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 14:10:27 --> Model Class Initialized
INFO - 2018-03-29 14:10:27 --> Model Class Initialized
INFO - 2018-03-29 14:10:27 --> Final output sent to browser
DEBUG - 2018-03-29 14:10:27 --> Total execution time: 1.7910
INFO - 2018-03-29 08:53:20 --> Config Class Initialized
INFO - 2018-03-29 08:53:20 --> Hooks Class Initialized
DEBUG - 2018-03-29 08:53:20 --> UTF-8 Support Enabled
INFO - 2018-03-29 08:53:20 --> Utf8 Class Initialized
INFO - 2018-03-29 08:53:20 --> URI Class Initialized
INFO - 2018-03-29 08:53:20 --> Router Class Initialized
INFO - 2018-03-29 08:53:20 --> Output Class Initialized
INFO - 2018-03-29 08:53:20 --> Security Class Initialized
DEBUG - 2018-03-29 08:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 08:53:20 --> Input Class Initialized
INFO - 2018-03-29 08:53:20 --> Language Class Initialized
INFO - 2018-03-29 08:53:20 --> Language Class Initialized
INFO - 2018-03-29 08:53:20 --> Config Class Initialized
INFO - 2018-03-29 08:53:20 --> Loader Class Initialized
INFO - 2018-03-29 14:23:20 --> Helper loaded: url_helper
INFO - 2018-03-29 14:23:20 --> Helper loaded: notification_helper
INFO - 2018-03-29 14:23:20 --> Helper loaded: settings_helper
INFO - 2018-03-29 14:23:20 --> Helper loaded: permission_helper
INFO - 2018-03-29 14:23:20 --> Helper loaded: users_helper
INFO - 2018-03-29 14:23:20 --> Database Driver Class Initialized
DEBUG - 2018-03-29 14:23:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 14:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 08:53:21 --> Config Class Initialized
INFO - 2018-03-29 08:53:21 --> Hooks Class Initialized
INFO - 2018-03-29 14:23:21 --> Helper loaded: form_helper
INFO - 2018-03-29 14:23:21 --> Form Validation Class Initialized
INFO - 2018-03-29 14:23:21 --> Controller Class Initialized
DEBUG - 2018-03-29 08:53:21 --> UTF-8 Support Enabled
INFO - 2018-03-29 08:53:21 --> Utf8 Class Initialized
INFO - 2018-03-29 08:53:21 --> Config Class Initialized
INFO - 2018-03-29 08:53:21 --> Hooks Class Initialized
INFO - 2018-03-29 08:53:21 --> URI Class Initialized
DEBUG - 2018-03-29 08:53:21 --> UTF-8 Support Enabled
INFO - 2018-03-29 08:53:21 --> Utf8 Class Initialized
INFO - 2018-03-29 08:53:21 --> URI Class Initialized
INFO - 2018-03-29 08:53:21 --> Router Class Initialized
INFO - 2018-03-29 08:53:21 --> Output Class Initialized
INFO - 2018-03-29 08:53:21 --> Router Class Initialized
INFO - 2018-03-29 08:53:21 --> Security Class Initialized
INFO - 2018-03-29 14:23:21 --> Model Class Initialized
INFO - 2018-03-29 08:53:21 --> Output Class Initialized
INFO - 2018-03-29 14:23:21 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 08:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 08:53:21 --> Input Class Initialized
INFO - 2018-03-29 08:53:21 --> Language Class Initialized
INFO - 2018-03-29 08:53:21 --> Security Class Initialized
DEBUG - 2018-03-29 08:53:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-29 14:23:21 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 08:53:21 --> Input Class Initialized
INFO - 2018-03-29 08:53:21 --> Language Class Initialized
INFO - 2018-03-29 14:23:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 14:23:21 --> Model Class Initialized
INFO - 2018-03-29 14:23:21 --> Model Class Initialized
INFO - 2018-03-29 14:23:21 --> Model Class Initialized
INFO - 2018-03-29 14:23:21 --> Model Class Initialized
INFO - 2018-03-29 14:23:21 --> Model Class Initialized
INFO - 2018-03-29 14:23:21 --> Model Class Initialized
INFO - 2018-03-29 08:53:21 --> Language Class Initialized
INFO - 2018-03-29 08:53:21 --> Config Class Initialized
INFO - 2018-03-29 08:53:21 --> Loader Class Initialized
INFO - 2018-03-29 14:23:21 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 08:53:21 --> Language Class Initialized
INFO - 2018-03-29 08:53:21 --> Config Class Initialized
INFO - 2018-03-29 08:53:21 --> Loader Class Initialized
INFO - 2018-03-29 14:23:21 --> Helper loaded: url_helper
INFO - 2018-03-29 14:23:21 --> Helper loaded: notification_helper
INFO - 2018-03-29 14:23:21 --> Helper loaded: settings_helper
INFO - 2018-03-29 14:23:21 --> Helper loaded: permission_helper
INFO - 2018-03-29 14:23:21 --> Helper loaded: users_helper
INFO - 2018-03-29 14:23:21 --> Helper loaded: url_helper
INFO - 2018-03-29 14:23:21 --> Final output sent to browser
DEBUG - 2018-03-29 14:23:21 --> Total execution time: 0.1851
INFO - 2018-03-29 14:23:21 --> Helper loaded: notification_helper
INFO - 2018-03-29 14:23:21 --> Helper loaded: settings_helper
INFO - 2018-03-29 14:23:21 --> Helper loaded: permission_helper
INFO - 2018-03-29 14:23:21 --> Helper loaded: users_helper
INFO - 2018-03-29 14:23:21 --> Database Driver Class Initialized
DEBUG - 2018-03-29 14:23:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 14:23:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 14:23:21 --> Helper loaded: form_helper
INFO - 2018-03-29 14:23:21 --> Form Validation Class Initialized
INFO - 2018-03-29 14:23:21 --> Controller Class Initialized
INFO - 2018-03-29 14:23:21 --> Database Driver Class Initialized
DEBUG - 2018-03-29 14:23:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 14:23:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 14:23:21 --> Model Class Initialized
INFO - 2018-03-29 14:23:21 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 14:23:21 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 14:23:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 14:23:21 --> Model Class Initialized
INFO - 2018-03-29 14:23:21 --> Model Class Initialized
INFO - 2018-03-29 14:23:21 --> Model Class Initialized
INFO - 2018-03-29 14:23:21 --> Model Class Initialized
INFO - 2018-03-29 14:23:21 --> Model Class Initialized
INFO - 2018-03-29 14:23:21 --> Model Class Initialized
INFO - 2018-03-29 14:23:21 --> Model Class Initialized
INFO - 2018-03-29 14:23:21 --> Model Class Initialized
INFO - 2018-03-29 14:23:21 --> Model Class Initialized
INFO - 2018-03-29 14:23:21 --> Model Class Initialized
INFO - 2018-03-29 14:23:21 --> Helper loaded: form_helper
INFO - 2018-03-29 14:23:21 --> Form Validation Class Initialized
INFO - 2018-03-29 14:23:21 --> Controller Class Initialized
INFO - 2018-03-29 14:23:21 --> Model Class Initialized
INFO - 2018-03-29 14:23:21 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 14:23:21 --> Model Class Initialized
INFO - 2018-03-29 14:23:21 --> Final output sent to browser
DEBUG - 2018-03-29 14:23:21 --> Total execution time: 0.1600
INFO - 2018-03-29 14:23:21 --> Model Class Initialized
INFO - 2018-03-29 14:23:21 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 14:23:21 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 14:23:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 14:23:21 --> Model Class Initialized
INFO - 2018-03-29 14:23:21 --> Model Class Initialized
INFO - 2018-03-29 14:23:21 --> Model Class Initialized
INFO - 2018-03-29 14:23:21 --> Model Class Initialized
INFO - 2018-03-29 14:23:21 --> Model Class Initialized
INFO - 2018-03-29 14:23:21 --> Model Class Initialized
INFO - 2018-03-29 14:23:21 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 14:23:21 --> Model Class Initialized
INFO - 2018-03-29 14:23:21 --> Final output sent to browser
DEBUG - 2018-03-29 14:23:21 --> Total execution time: 0.1969
INFO - 2018-03-29 08:53:24 --> Config Class Initialized
INFO - 2018-03-29 08:53:24 --> Hooks Class Initialized
DEBUG - 2018-03-29 08:53:24 --> UTF-8 Support Enabled
INFO - 2018-03-29 08:53:24 --> Utf8 Class Initialized
INFO - 2018-03-29 08:53:24 --> URI Class Initialized
INFO - 2018-03-29 08:53:24 --> Router Class Initialized
INFO - 2018-03-29 08:53:24 --> Output Class Initialized
INFO - 2018-03-29 08:53:25 --> Security Class Initialized
DEBUG - 2018-03-29 08:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 08:53:25 --> Input Class Initialized
INFO - 2018-03-29 08:53:25 --> Language Class Initialized
INFO - 2018-03-29 08:53:26 --> Language Class Initialized
INFO - 2018-03-29 08:53:26 --> Config Class Initialized
INFO - 2018-03-29 08:53:26 --> Loader Class Initialized
INFO - 2018-03-29 14:23:26 --> Helper loaded: url_helper
INFO - 2018-03-29 14:23:26 --> Helper loaded: notification_helper
INFO - 2018-03-29 14:23:26 --> Helper loaded: settings_helper
INFO - 2018-03-29 14:23:26 --> Helper loaded: permission_helper
INFO - 2018-03-29 14:23:26 --> Helper loaded: users_helper
INFO - 2018-03-29 14:23:27 --> Database Driver Class Initialized
DEBUG - 2018-03-29 14:23:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 14:23:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 14:23:27 --> Helper loaded: form_helper
INFO - 2018-03-29 14:23:27 --> Form Validation Class Initialized
INFO - 2018-03-29 14:23:27 --> Controller Class Initialized
INFO - 2018-03-29 14:23:27 --> Model Class Initialized
INFO - 2018-03-29 14:23:27 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 14:23:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 14:23:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 14:23:27 --> Model Class Initialized
INFO - 2018-03-29 14:23:27 --> Model Class Initialized
INFO - 2018-03-29 14:23:27 --> Model Class Initialized
INFO - 2018-03-29 14:23:27 --> Model Class Initialized
INFO - 2018-03-29 14:23:27 --> Model Class Initialized
INFO - 2018-03-29 14:23:27 --> Model Class Initialized
INFO - 2018-03-29 14:23:27 --> Model Class Initialized
INFO - 2018-03-29 14:23:27 --> Model Class Initialized
INFO - 2018-03-29 14:23:27 --> Model Class Initialized
INFO - 2018-03-29 14:23:27 --> Model Class Initialized
INFO - 2018-03-29 14:23:27 --> Model Class Initialized
INFO - 2018-03-29 14:23:27 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 14:23:27 --> Model Class Initialized
INFO - 2018-03-29 14:23:27 --> Final output sent to browser
DEBUG - 2018-03-29 14:23:27 --> Total execution time: 3.5970
INFO - 2018-03-29 08:53:31 --> Config Class Initialized
INFO - 2018-03-29 08:53:31 --> Hooks Class Initialized
DEBUG - 2018-03-29 08:53:31 --> UTF-8 Support Enabled
INFO - 2018-03-29 08:53:31 --> Utf8 Class Initialized
INFO - 2018-03-29 08:53:31 --> URI Class Initialized
INFO - 2018-03-29 08:53:31 --> Router Class Initialized
INFO - 2018-03-29 08:53:31 --> Output Class Initialized
INFO - 2018-03-29 08:53:31 --> Security Class Initialized
DEBUG - 2018-03-29 08:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 08:53:31 --> Input Class Initialized
INFO - 2018-03-29 08:53:31 --> Language Class Initialized
INFO - 2018-03-29 08:53:31 --> Language Class Initialized
INFO - 2018-03-29 08:53:31 --> Config Class Initialized
INFO - 2018-03-29 08:53:31 --> Loader Class Initialized
INFO - 2018-03-29 14:23:31 --> Helper loaded: url_helper
INFO - 2018-03-29 14:23:31 --> Helper loaded: notification_helper
INFO - 2018-03-29 14:23:31 --> Helper loaded: settings_helper
INFO - 2018-03-29 14:23:31 --> Helper loaded: permission_helper
INFO - 2018-03-29 14:23:31 --> Helper loaded: users_helper
INFO - 2018-03-29 14:23:31 --> Database Driver Class Initialized
DEBUG - 2018-03-29 14:23:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 14:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 14:23:31 --> Helper loaded: form_helper
INFO - 2018-03-29 14:23:31 --> Form Validation Class Initialized
INFO - 2018-03-29 14:23:31 --> Controller Class Initialized
INFO - 2018-03-29 14:23:31 --> Model Class Initialized
INFO - 2018-03-29 14:23:31 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 14:23:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 14:23:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 14:23:31 --> Model Class Initialized
INFO - 2018-03-29 14:23:31 --> Model Class Initialized
INFO - 2018-03-29 14:23:31 --> Model Class Initialized
INFO - 2018-03-29 14:23:31 --> Model Class Initialized
INFO - 2018-03-29 14:23:31 --> Final output sent to browser
DEBUG - 2018-03-29 14:23:31 --> Total execution time: 1.0355
INFO - 2018-03-29 08:53:33 --> Config Class Initialized
INFO - 2018-03-29 08:53:33 --> Hooks Class Initialized
DEBUG - 2018-03-29 08:53:33 --> UTF-8 Support Enabled
INFO - 2018-03-29 08:53:33 --> Utf8 Class Initialized
INFO - 2018-03-29 08:53:33 --> URI Class Initialized
INFO - 2018-03-29 08:53:33 --> Router Class Initialized
INFO - 2018-03-29 08:53:33 --> Output Class Initialized
INFO - 2018-03-29 08:53:33 --> Security Class Initialized
DEBUG - 2018-03-29 08:53:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 08:53:33 --> Input Class Initialized
INFO - 2018-03-29 08:53:33 --> Language Class Initialized
INFO - 2018-03-29 08:53:33 --> Language Class Initialized
INFO - 2018-03-29 08:53:33 --> Config Class Initialized
INFO - 2018-03-29 08:53:33 --> Loader Class Initialized
INFO - 2018-03-29 14:23:33 --> Helper loaded: url_helper
INFO - 2018-03-29 14:23:33 --> Helper loaded: notification_helper
INFO - 2018-03-29 14:23:33 --> Helper loaded: settings_helper
INFO - 2018-03-29 14:23:33 --> Helper loaded: permission_helper
INFO - 2018-03-29 14:23:33 --> Helper loaded: users_helper
INFO - 2018-03-29 14:23:33 --> Database Driver Class Initialized
DEBUG - 2018-03-29 14:23:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 14:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 14:23:33 --> Helper loaded: form_helper
INFO - 2018-03-29 14:23:33 --> Form Validation Class Initialized
INFO - 2018-03-29 14:23:33 --> Controller Class Initialized
INFO - 2018-03-29 14:23:33 --> Model Class Initialized
INFO - 2018-03-29 14:23:33 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 14:23:33 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 14:23:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 14:23:33 --> Model Class Initialized
INFO - 2018-03-29 14:23:33 --> Model Class Initialized
INFO - 2018-03-29 14:23:33 --> Model Class Initialized
INFO - 2018-03-29 14:23:33 --> Model Class Initialized
INFO - 2018-03-29 14:23:33 --> Final output sent to browser
DEBUG - 2018-03-29 14:23:33 --> Total execution time: 0.1898
INFO - 2018-03-29 08:53:36 --> Config Class Initialized
INFO - 2018-03-29 08:53:36 --> Hooks Class Initialized
DEBUG - 2018-03-29 08:53:36 --> UTF-8 Support Enabled
INFO - 2018-03-29 08:53:36 --> Utf8 Class Initialized
INFO - 2018-03-29 08:53:36 --> URI Class Initialized
INFO - 2018-03-29 08:53:36 --> Router Class Initialized
INFO - 2018-03-29 08:53:36 --> Output Class Initialized
INFO - 2018-03-29 08:53:36 --> Security Class Initialized
DEBUG - 2018-03-29 08:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 08:53:36 --> Input Class Initialized
INFO - 2018-03-29 08:53:36 --> Language Class Initialized
INFO - 2018-03-29 08:53:36 --> Language Class Initialized
INFO - 2018-03-29 08:53:36 --> Config Class Initialized
INFO - 2018-03-29 08:53:36 --> Loader Class Initialized
INFO - 2018-03-29 14:23:36 --> Helper loaded: url_helper
INFO - 2018-03-29 14:23:36 --> Helper loaded: notification_helper
INFO - 2018-03-29 14:23:36 --> Helper loaded: settings_helper
INFO - 2018-03-29 14:23:36 --> Helper loaded: permission_helper
INFO - 2018-03-29 14:23:36 --> Helper loaded: users_helper
INFO - 2018-03-29 14:23:36 --> Database Driver Class Initialized
DEBUG - 2018-03-29 14:23:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 14:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 14:23:36 --> Helper loaded: form_helper
INFO - 2018-03-29 14:23:36 --> Form Validation Class Initialized
INFO - 2018-03-29 14:23:36 --> Controller Class Initialized
INFO - 2018-03-29 14:23:37 --> Model Class Initialized
INFO - 2018-03-29 14:23:37 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 14:23:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 14:23:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 14:23:37 --> Model Class Initialized
INFO - 2018-03-29 14:23:37 --> Model Class Initialized
INFO - 2018-03-29 14:23:37 --> Model Class Initialized
INFO - 2018-03-29 14:23:37 --> Model Class Initialized
INFO - 2018-03-29 14:23:37 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 14:23:37 --> Final output sent to browser
DEBUG - 2018-03-29 14:23:37 --> Total execution time: 0.9724
INFO - 2018-03-29 08:53:37 --> Config Class Initialized
INFO - 2018-03-29 08:53:37 --> Hooks Class Initialized
DEBUG - 2018-03-29 08:53:38 --> UTF-8 Support Enabled
INFO - 2018-03-29 08:53:38 --> Utf8 Class Initialized
INFO - 2018-03-29 08:53:38 --> URI Class Initialized
INFO - 2018-03-29 08:53:38 --> Router Class Initialized
INFO - 2018-03-29 08:53:38 --> Output Class Initialized
INFO - 2018-03-29 08:53:38 --> Security Class Initialized
DEBUG - 2018-03-29 08:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 08:53:38 --> Input Class Initialized
INFO - 2018-03-29 08:53:38 --> Language Class Initialized
INFO - 2018-03-29 08:53:39 --> Language Class Initialized
INFO - 2018-03-29 08:53:39 --> Config Class Initialized
INFO - 2018-03-29 08:53:39 --> Loader Class Initialized
INFO - 2018-03-29 14:23:39 --> Helper loaded: url_helper
INFO - 2018-03-29 14:23:39 --> Helper loaded: notification_helper
INFO - 2018-03-29 14:23:39 --> Helper loaded: settings_helper
INFO - 2018-03-29 14:23:39 --> Helper loaded: permission_helper
INFO - 2018-03-29 14:23:39 --> Helper loaded: users_helper
INFO - 2018-03-29 14:23:39 --> Database Driver Class Initialized
DEBUG - 2018-03-29 14:23:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 14:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 14:23:40 --> Helper loaded: form_helper
INFO - 2018-03-29 14:23:40 --> Form Validation Class Initialized
INFO - 2018-03-29 14:23:40 --> Controller Class Initialized
INFO - 2018-03-29 14:23:40 --> Model Class Initialized
INFO - 2018-03-29 14:23:40 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 14:23:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 14:23:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 14:23:40 --> Model Class Initialized
INFO - 2018-03-29 14:23:40 --> Model Class Initialized
INFO - 2018-03-29 14:23:40 --> Model Class Initialized
INFO - 2018-03-29 14:23:40 --> Model Class Initialized
INFO - 2018-03-29 14:23:40 --> Model Class Initialized
INFO - 2018-03-29 14:23:41 --> Model Class Initialized
INFO - 2018-03-29 14:23:41 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-29 14:23:41 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-03-29 14:23:41 --> Final output sent to browser
DEBUG - 2018-03-29 14:23:41 --> Total execution time: 3.5211
INFO - 2018-03-29 08:53:46 --> Config Class Initialized
INFO - 2018-03-29 08:53:46 --> Hooks Class Initialized
DEBUG - 2018-03-29 08:53:46 --> UTF-8 Support Enabled
INFO - 2018-03-29 08:53:46 --> Utf8 Class Initialized
INFO - 2018-03-29 08:53:46 --> URI Class Initialized
INFO - 2018-03-29 08:53:46 --> Router Class Initialized
INFO - 2018-03-29 08:53:46 --> Output Class Initialized
INFO - 2018-03-29 08:53:46 --> Security Class Initialized
DEBUG - 2018-03-29 08:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 08:53:46 --> Input Class Initialized
INFO - 2018-03-29 08:53:46 --> Language Class Initialized
INFO - 2018-03-29 08:53:46 --> Language Class Initialized
INFO - 2018-03-29 08:53:46 --> Config Class Initialized
INFO - 2018-03-29 08:53:46 --> Loader Class Initialized
INFO - 2018-03-29 14:23:46 --> Helper loaded: url_helper
INFO - 2018-03-29 14:23:46 --> Helper loaded: notification_helper
INFO - 2018-03-29 14:23:46 --> Helper loaded: settings_helper
INFO - 2018-03-29 14:23:46 --> Helper loaded: permission_helper
INFO - 2018-03-29 14:23:46 --> Helper loaded: users_helper
INFO - 2018-03-29 14:23:46 --> Database Driver Class Initialized
DEBUG - 2018-03-29 14:23:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 14:23:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 14:23:46 --> Helper loaded: form_helper
INFO - 2018-03-29 14:23:46 --> Form Validation Class Initialized
INFO - 2018-03-29 14:23:46 --> Controller Class Initialized
INFO - 2018-03-29 14:23:46 --> Model Class Initialized
INFO - 2018-03-29 14:23:46 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 14:23:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 14:23:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 14:23:46 --> Model Class Initialized
INFO - 2018-03-29 14:23:46 --> Model Class Initialized
INFO - 2018-03-29 14:23:46 --> Model Class Initialized
INFO - 2018-03-29 14:23:46 --> Model Class Initialized
INFO - 2018-03-29 14:23:46 --> Model Class Initialized
INFO - 2018-03-29 14:23:46 --> Model Class Initialized
INFO - 2018-03-29 14:23:46 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 14:23:46 --> Final output sent to browser
DEBUG - 2018-03-29 14:23:46 --> Total execution time: 0.5539
INFO - 2018-03-29 09:55:24 --> Config Class Initialized
INFO - 2018-03-29 09:55:24 --> Hooks Class Initialized
DEBUG - 2018-03-29 09:55:24 --> UTF-8 Support Enabled
INFO - 2018-03-29 09:55:24 --> Utf8 Class Initialized
INFO - 2018-03-29 09:55:24 --> URI Class Initialized
INFO - 2018-03-29 09:55:24 --> Router Class Initialized
INFO - 2018-03-29 09:55:24 --> Output Class Initialized
INFO - 2018-03-29 09:55:24 --> Security Class Initialized
DEBUG - 2018-03-29 09:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 09:55:24 --> Input Class Initialized
INFO - 2018-03-29 09:55:24 --> Language Class Initialized
INFO - 2018-03-29 09:55:24 --> Language Class Initialized
INFO - 2018-03-29 09:55:24 --> Config Class Initialized
INFO - 2018-03-29 09:55:24 --> Loader Class Initialized
INFO - 2018-03-29 15:25:25 --> Helper loaded: url_helper
INFO - 2018-03-29 15:25:25 --> Helper loaded: notification_helper
INFO - 2018-03-29 15:25:25 --> Helper loaded: settings_helper
INFO - 2018-03-29 15:25:25 --> Helper loaded: permission_helper
INFO - 2018-03-29 15:25:25 --> Helper loaded: users_helper
INFO - 2018-03-29 15:25:25 --> Database Driver Class Initialized
DEBUG - 2018-03-29 15:25:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 15:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 15:25:25 --> Helper loaded: form_helper
INFO - 2018-03-29 15:25:25 --> Form Validation Class Initialized
INFO - 2018-03-29 15:25:25 --> Controller Class Initialized
INFO - 2018-03-29 15:25:25 --> Model Class Initialized
INFO - 2018-03-29 15:25:25 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 15:25:25 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 15:25:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 15:25:25 --> Model Class Initialized
INFO - 2018-03-29 15:25:25 --> Model Class Initialized
INFO - 2018-03-29 15:25:25 --> Model Class Initialized
INFO - 2018-03-29 15:25:25 --> Model Class Initialized
INFO - 2018-03-29 15:25:25 --> Model Class Initialized
INFO - 2018-03-29 15:25:25 --> Model Class Initialized
INFO - 2018-03-29 15:25:25 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 15:25:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-29 15:25:25 --> Final output sent to browser
DEBUG - 2018-03-29 15:25:25 --> Total execution time: 1.0757
INFO - 2018-03-29 09:55:36 --> Config Class Initialized
INFO - 2018-03-29 09:55:36 --> Hooks Class Initialized
DEBUG - 2018-03-29 09:55:36 --> UTF-8 Support Enabled
INFO - 2018-03-29 09:55:36 --> Utf8 Class Initialized
INFO - 2018-03-29 09:55:36 --> URI Class Initialized
INFO - 2018-03-29 09:55:36 --> Router Class Initialized
INFO - 2018-03-29 09:55:36 --> Output Class Initialized
INFO - 2018-03-29 09:55:36 --> Security Class Initialized
DEBUG - 2018-03-29 09:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 09:55:36 --> Input Class Initialized
INFO - 2018-03-29 09:55:36 --> Language Class Initialized
INFO - 2018-03-29 09:55:36 --> Language Class Initialized
INFO - 2018-03-29 09:55:36 --> Config Class Initialized
INFO - 2018-03-29 09:55:36 --> Loader Class Initialized
INFO - 2018-03-29 15:25:36 --> Helper loaded: url_helper
INFO - 2018-03-29 15:25:36 --> Helper loaded: notification_helper
INFO - 2018-03-29 15:25:36 --> Helper loaded: settings_helper
INFO - 2018-03-29 15:25:36 --> Helper loaded: permission_helper
INFO - 2018-03-29 15:25:36 --> Helper loaded: users_helper
INFO - 2018-03-29 15:25:36 --> Database Driver Class Initialized
DEBUG - 2018-03-29 15:25:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 15:25:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 15:25:36 --> Helper loaded: form_helper
INFO - 2018-03-29 15:25:36 --> Form Validation Class Initialized
INFO - 2018-03-29 15:25:36 --> Controller Class Initialized
INFO - 2018-03-29 15:25:36 --> Model Class Initialized
INFO - 2018-03-29 15:25:36 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 15:25:36 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 15:25:36 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 15:25:36 --> Model Class Initialized
INFO - 2018-03-29 15:25:36 --> Model Class Initialized
INFO - 2018-03-29 15:25:36 --> Model Class Initialized
INFO - 2018-03-29 15:25:36 --> Model Class Initialized
INFO - 2018-03-29 15:25:36 --> Model Class Initialized
INFO - 2018-03-29 15:25:36 --> Model Class Initialized
INFO - 2018-03-29 15:25:36 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 15:25:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-29 15:25:36 --> Final output sent to browser
DEBUG - 2018-03-29 15:25:36 --> Total execution time: 0.0945
INFO - 2018-03-29 09:55:37 --> Config Class Initialized
INFO - 2018-03-29 09:55:37 --> Hooks Class Initialized
DEBUG - 2018-03-29 09:55:37 --> UTF-8 Support Enabled
INFO - 2018-03-29 09:55:37 --> Utf8 Class Initialized
INFO - 2018-03-29 09:55:37 --> URI Class Initialized
INFO - 2018-03-29 09:55:37 --> Router Class Initialized
INFO - 2018-03-29 09:55:37 --> Output Class Initialized
INFO - 2018-03-29 09:55:37 --> Security Class Initialized
DEBUG - 2018-03-29 09:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 09:55:37 --> Input Class Initialized
INFO - 2018-03-29 09:55:37 --> Language Class Initialized
INFO - 2018-03-29 09:55:37 --> Language Class Initialized
INFO - 2018-03-29 09:55:37 --> Config Class Initialized
INFO - 2018-03-29 09:55:37 --> Loader Class Initialized
INFO - 2018-03-29 15:25:37 --> Helper loaded: url_helper
INFO - 2018-03-29 15:25:37 --> Helper loaded: notification_helper
INFO - 2018-03-29 15:25:37 --> Helper loaded: settings_helper
INFO - 2018-03-29 15:25:37 --> Helper loaded: permission_helper
INFO - 2018-03-29 15:25:37 --> Helper loaded: users_helper
INFO - 2018-03-29 15:25:37 --> Database Driver Class Initialized
DEBUG - 2018-03-29 15:25:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 15:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 15:25:37 --> Helper loaded: form_helper
INFO - 2018-03-29 15:25:37 --> Form Validation Class Initialized
INFO - 2018-03-29 15:25:37 --> Controller Class Initialized
INFO - 2018-03-29 15:25:37 --> Model Class Initialized
INFO - 2018-03-29 15:25:37 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 15:25:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 15:25:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 15:25:37 --> Model Class Initialized
INFO - 2018-03-29 15:25:37 --> Model Class Initialized
INFO - 2018-03-29 15:25:37 --> Model Class Initialized
INFO - 2018-03-29 15:25:37 --> Model Class Initialized
INFO - 2018-03-29 15:25:37 --> Model Class Initialized
INFO - 2018-03-29 15:25:37 --> Model Class Initialized
INFO - 2018-03-29 15:25:37 --> Model Class Initialized
INFO - 2018-03-29 15:25:37 --> Model Class Initialized
INFO - 2018-03-29 15:25:37 --> Model Class Initialized
INFO - 2018-03-29 15:25:37 --> Model Class Initialized
INFO - 2018-03-29 15:25:37 --> Model Class Initialized
INFO - 2018-03-29 15:25:37 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 15:25:37 --> Model Class Initialized
INFO - 2018-03-29 15:25:37 --> Final output sent to browser
DEBUG - 2018-03-29 15:25:37 --> Total execution time: 0.1835
INFO - 2018-03-29 09:55:37 --> Config Class Initialized
INFO - 2018-03-29 09:55:37 --> Hooks Class Initialized
DEBUG - 2018-03-29 09:55:37 --> UTF-8 Support Enabled
INFO - 2018-03-29 09:55:37 --> Utf8 Class Initialized
INFO - 2018-03-29 09:55:37 --> URI Class Initialized
INFO - 2018-03-29 09:55:37 --> Router Class Initialized
INFO - 2018-03-29 09:55:37 --> Output Class Initialized
INFO - 2018-03-29 09:55:37 --> Security Class Initialized
DEBUG - 2018-03-29 09:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 09:55:37 --> Input Class Initialized
INFO - 2018-03-29 09:55:37 --> Language Class Initialized
INFO - 2018-03-29 09:55:37 --> Language Class Initialized
INFO - 2018-03-29 09:55:37 --> Config Class Initialized
INFO - 2018-03-29 09:55:37 --> Loader Class Initialized
INFO - 2018-03-29 15:25:37 --> Helper loaded: url_helper
INFO - 2018-03-29 15:25:37 --> Helper loaded: notification_helper
INFO - 2018-03-29 15:25:37 --> Helper loaded: settings_helper
INFO - 2018-03-29 15:25:37 --> Helper loaded: permission_helper
INFO - 2018-03-29 15:25:37 --> Helper loaded: users_helper
INFO - 2018-03-29 15:25:37 --> Database Driver Class Initialized
DEBUG - 2018-03-29 15:25:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 15:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 15:25:37 --> Helper loaded: form_helper
INFO - 2018-03-29 15:25:37 --> Form Validation Class Initialized
INFO - 2018-03-29 15:25:37 --> Controller Class Initialized
INFO - 2018-03-29 15:25:37 --> Model Class Initialized
INFO - 2018-03-29 15:25:37 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 15:25:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 15:25:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 15:25:37 --> Model Class Initialized
INFO - 2018-03-29 15:25:37 --> Model Class Initialized
INFO - 2018-03-29 15:25:37 --> Model Class Initialized
INFO - 2018-03-29 15:25:37 --> Model Class Initialized
INFO - 2018-03-29 15:25:37 --> Model Class Initialized
INFO - 2018-03-29 15:25:37 --> Model Class Initialized
INFO - 2018-03-29 15:25:37 --> Model Class Initialized
INFO - 2018-03-29 15:25:37 --> Model Class Initialized
INFO - 2018-03-29 15:25:37 --> Model Class Initialized
INFO - 2018-03-29 15:25:37 --> Model Class Initialized
INFO - 2018-03-29 15:25:37 --> Model Class Initialized
INFO - 2018-03-29 15:25:37 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 15:25:37 --> Model Class Initialized
INFO - 2018-03-29 15:25:37 --> Final output sent to browser
DEBUG - 2018-03-29 15:25:37 --> Total execution time: 0.1282
INFO - 2018-03-29 09:55:39 --> Config Class Initialized
INFO - 2018-03-29 09:55:39 --> Hooks Class Initialized
DEBUG - 2018-03-29 09:55:39 --> UTF-8 Support Enabled
INFO - 2018-03-29 09:55:39 --> Utf8 Class Initialized
INFO - 2018-03-29 09:55:39 --> URI Class Initialized
INFO - 2018-03-29 09:55:39 --> Router Class Initialized
INFO - 2018-03-29 09:55:39 --> Output Class Initialized
INFO - 2018-03-29 09:55:39 --> Security Class Initialized
DEBUG - 2018-03-29 09:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 09:55:39 --> Input Class Initialized
INFO - 2018-03-29 09:55:39 --> Language Class Initialized
INFO - 2018-03-29 09:55:40 --> Language Class Initialized
INFO - 2018-03-29 09:55:40 --> Config Class Initialized
INFO - 2018-03-29 09:55:40 --> Loader Class Initialized
INFO - 2018-03-29 15:25:40 --> Helper loaded: url_helper
INFO - 2018-03-29 15:25:40 --> Helper loaded: notification_helper
INFO - 2018-03-29 15:25:40 --> Helper loaded: settings_helper
INFO - 2018-03-29 15:25:40 --> Helper loaded: permission_helper
INFO - 2018-03-29 15:25:40 --> Helper loaded: users_helper
INFO - 2018-03-29 09:55:40 --> Config Class Initialized
INFO - 2018-03-29 09:55:40 --> Hooks Class Initialized
DEBUG - 2018-03-29 09:55:41 --> UTF-8 Support Enabled
INFO - 2018-03-29 09:55:41 --> Utf8 Class Initialized
INFO - 2018-03-29 09:55:41 --> URI Class Initialized
INFO - 2018-03-29 09:55:41 --> Router Class Initialized
INFO - 2018-03-29 15:25:41 --> Database Driver Class Initialized
DEBUG - 2018-03-29 15:25:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 15:25:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 15:25:41 --> Helper loaded: form_helper
INFO - 2018-03-29 15:25:41 --> Form Validation Class Initialized
INFO - 2018-03-29 15:25:41 --> Controller Class Initialized
INFO - 2018-03-29 15:25:41 --> Model Class Initialized
INFO - 2018-03-29 15:25:41 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 15:25:41 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 15:25:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 15:25:41 --> Model Class Initialized
INFO - 2018-03-29 15:25:41 --> Model Class Initialized
INFO - 2018-03-29 15:25:41 --> Model Class Initialized
INFO - 2018-03-29 15:25:41 --> Model Class Initialized
INFO - 2018-03-29 15:25:41 --> Model Class Initialized
INFO - 2018-03-29 15:25:41 --> Model Class Initialized
INFO - 2018-03-29 15:25:41 --> Model Class Initialized
INFO - 2018-03-29 15:25:41 --> Model Class Initialized
INFO - 2018-03-29 15:25:41 --> Model Class Initialized
INFO - 2018-03-29 15:25:41 --> Model Class Initialized
INFO - 2018-03-29 15:25:41 --> Model Class Initialized
INFO - 2018-03-29 15:25:41 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 15:25:41 --> Final output sent to browser
DEBUG - 2018-03-29 15:25:41 --> Total execution time: 1.7465
INFO - 2018-03-29 09:55:41 --> Output Class Initialized
INFO - 2018-03-29 09:55:41 --> Security Class Initialized
DEBUG - 2018-03-29 09:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 09:55:41 --> Input Class Initialized
INFO - 2018-03-29 09:55:41 --> Language Class Initialized
INFO - 2018-03-29 09:55:42 --> Config Class Initialized
INFO - 2018-03-29 09:55:42 --> Hooks Class Initialized
DEBUG - 2018-03-29 09:55:42 --> UTF-8 Support Enabled
INFO - 2018-03-29 09:55:42 --> Utf8 Class Initialized
INFO - 2018-03-29 09:55:42 --> URI Class Initialized
INFO - 2018-03-29 09:55:42 --> Router Class Initialized
INFO - 2018-03-29 09:55:42 --> Output Class Initialized
INFO - 2018-03-29 09:55:42 --> Security Class Initialized
DEBUG - 2018-03-29 09:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 09:55:42 --> Input Class Initialized
INFO - 2018-03-29 09:55:42 --> Language Class Initialized
INFO - 2018-03-29 09:55:42 --> Language Class Initialized
INFO - 2018-03-29 09:55:42 --> Config Class Initialized
INFO - 2018-03-29 09:55:42 --> Loader Class Initialized
INFO - 2018-03-29 15:25:42 --> Helper loaded: url_helper
INFO - 2018-03-29 15:25:42 --> Helper loaded: notification_helper
INFO - 2018-03-29 15:25:42 --> Helper loaded: settings_helper
INFO - 2018-03-29 15:25:42 --> Helper loaded: permission_helper
INFO - 2018-03-29 15:25:42 --> Helper loaded: users_helper
INFO - 2018-03-29 15:25:42 --> Database Driver Class Initialized
DEBUG - 2018-03-29 15:25:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 15:25:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 15:25:42 --> Helper loaded: form_helper
INFO - 2018-03-29 15:25:42 --> Form Validation Class Initialized
INFO - 2018-03-29 15:25:42 --> Controller Class Initialized
INFO - 2018-03-29 15:25:42 --> Model Class Initialized
INFO - 2018-03-29 15:25:42 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 15:25:42 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 15:25:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 15:25:42 --> Model Class Initialized
INFO - 2018-03-29 15:25:42 --> Model Class Initialized
INFO - 2018-03-29 09:55:42 --> Language Class Initialized
INFO - 2018-03-29 09:55:42 --> Config Class Initialized
INFO - 2018-03-29 09:55:42 --> Loader Class Initialized
INFO - 2018-03-29 15:25:42 --> Model Class Initialized
INFO - 2018-03-29 15:25:42 --> Model Class Initialized
INFO - 2018-03-29 15:25:42 --> Model Class Initialized
INFO - 2018-03-29 15:25:42 --> Model Class Initialized
INFO - 2018-03-29 15:25:42 --> Model Class Initialized
INFO - 2018-03-29 15:25:42 --> Helper loaded: url_helper
INFO - 2018-03-29 15:25:42 --> Model Class Initialized
INFO - 2018-03-29 15:25:42 --> Model Class Initialized
INFO - 2018-03-29 15:25:42 --> Model Class Initialized
INFO - 2018-03-29 15:25:42 --> Model Class Initialized
INFO - 2018-03-29 15:25:42 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 15:25:42 --> Model Class Initialized
INFO - 2018-03-29 15:25:42 --> Helper loaded: notification_helper
INFO - 2018-03-29 15:25:42 --> Helper loaded: settings_helper
INFO - 2018-03-29 15:25:42 --> Helper loaded: permission_helper
INFO - 2018-03-29 15:25:42 --> Helper loaded: users_helper
INFO - 2018-03-29 15:25:42 --> Final output sent to browser
DEBUG - 2018-03-29 15:25:42 --> Total execution time: 0.4741
INFO - 2018-03-29 15:25:42 --> Database Driver Class Initialized
DEBUG - 2018-03-29 15:25:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 15:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 15:25:43 --> Helper loaded: form_helper
INFO - 2018-03-29 15:25:43 --> Form Validation Class Initialized
INFO - 2018-03-29 15:25:43 --> Controller Class Initialized
INFO - 2018-03-29 15:25:43 --> Model Class Initialized
INFO - 2018-03-29 15:25:43 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 15:25:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 15:25:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 15:25:43 --> Model Class Initialized
INFO - 2018-03-29 15:25:43 --> Model Class Initialized
INFO - 2018-03-29 15:25:43 --> Model Class Initialized
INFO - 2018-03-29 15:25:43 --> Model Class Initialized
INFO - 2018-03-29 15:25:43 --> Model Class Initialized
INFO - 2018-03-29 15:25:43 --> Model Class Initialized
INFO - 2018-03-29 15:25:43 --> Model Class Initialized
INFO - 2018-03-29 15:25:43 --> Model Class Initialized
INFO - 2018-03-29 15:25:43 --> Model Class Initialized
INFO - 2018-03-29 15:25:43 --> Model Class Initialized
INFO - 2018-03-29 15:25:43 --> Model Class Initialized
INFO - 2018-03-29 15:25:43 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 15:25:43 --> Model Class Initialized
INFO - 2018-03-29 15:25:43 --> Final output sent to browser
DEBUG - 2018-03-29 15:25:43 --> Total execution time: 2.8227
INFO - 2018-03-29 09:55:45 --> Config Class Initialized
INFO - 2018-03-29 09:55:45 --> Hooks Class Initialized
DEBUG - 2018-03-29 09:55:45 --> UTF-8 Support Enabled
INFO - 2018-03-29 09:55:45 --> Utf8 Class Initialized
INFO - 2018-03-29 09:55:45 --> URI Class Initialized
INFO - 2018-03-29 09:55:45 --> Router Class Initialized
INFO - 2018-03-29 09:55:45 --> Output Class Initialized
INFO - 2018-03-29 09:55:45 --> Security Class Initialized
DEBUG - 2018-03-29 09:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 09:55:45 --> Input Class Initialized
INFO - 2018-03-29 09:55:45 --> Language Class Initialized
INFO - 2018-03-29 09:55:45 --> Language Class Initialized
INFO - 2018-03-29 09:55:45 --> Config Class Initialized
INFO - 2018-03-29 09:55:45 --> Loader Class Initialized
INFO - 2018-03-29 15:25:45 --> Helper loaded: url_helper
INFO - 2018-03-29 15:25:45 --> Helper loaded: notification_helper
INFO - 2018-03-29 15:25:45 --> Helper loaded: settings_helper
INFO - 2018-03-29 15:25:45 --> Helper loaded: permission_helper
INFO - 2018-03-29 15:25:45 --> Helper loaded: users_helper
INFO - 2018-03-29 15:25:45 --> Database Driver Class Initialized
DEBUG - 2018-03-29 15:25:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 15:25:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 15:25:45 --> Helper loaded: form_helper
INFO - 2018-03-29 15:25:45 --> Form Validation Class Initialized
INFO - 2018-03-29 15:25:45 --> Controller Class Initialized
INFO - 2018-03-29 15:25:45 --> Model Class Initialized
INFO - 2018-03-29 15:25:45 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 15:25:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 15:25:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 15:25:45 --> Model Class Initialized
INFO - 2018-03-29 15:25:45 --> Model Class Initialized
INFO - 2018-03-29 15:25:45 --> Model Class Initialized
INFO - 2018-03-29 15:25:45 --> Model Class Initialized
INFO - 2018-03-29 15:25:45 --> Model Class Initialized
INFO - 2018-03-29 15:25:45 --> Model Class Initialized
INFO - 2018-03-29 15:25:45 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-29 15:25:45 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-03-29 15:25:45 --> Final output sent to browser
DEBUG - 2018-03-29 15:25:45 --> Total execution time: 0.1404
INFO - 2018-03-29 09:55:46 --> Config Class Initialized
INFO - 2018-03-29 09:55:46 --> Hooks Class Initialized
DEBUG - 2018-03-29 09:55:46 --> UTF-8 Support Enabled
INFO - 2018-03-29 09:55:46 --> Utf8 Class Initialized
INFO - 2018-03-29 09:55:46 --> URI Class Initialized
INFO - 2018-03-29 09:55:46 --> Router Class Initialized
INFO - 2018-03-29 09:55:46 --> Output Class Initialized
INFO - 2018-03-29 09:55:46 --> Security Class Initialized
DEBUG - 2018-03-29 09:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 09:55:46 --> Input Class Initialized
INFO - 2018-03-29 09:55:46 --> Language Class Initialized
INFO - 2018-03-29 09:55:47 --> Language Class Initialized
INFO - 2018-03-29 09:55:47 --> Config Class Initialized
INFO - 2018-03-29 09:55:47 --> Loader Class Initialized
INFO - 2018-03-29 15:25:47 --> Helper loaded: url_helper
INFO - 2018-03-29 15:25:47 --> Helper loaded: notification_helper
INFO - 2018-03-29 15:25:47 --> Helper loaded: settings_helper
INFO - 2018-03-29 15:25:47 --> Helper loaded: permission_helper
INFO - 2018-03-29 15:25:47 --> Helper loaded: users_helper
INFO - 2018-03-29 15:25:48 --> Database Driver Class Initialized
DEBUG - 2018-03-29 15:25:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 15:25:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 15:25:48 --> Helper loaded: form_helper
INFO - 2018-03-29 15:25:48 --> Form Validation Class Initialized
INFO - 2018-03-29 15:25:48 --> Controller Class Initialized
INFO - 2018-03-29 15:25:48 --> Model Class Initialized
INFO - 2018-03-29 15:25:48 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 15:25:48 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 15:25:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 15:25:48 --> Model Class Initialized
INFO - 2018-03-29 15:25:48 --> Model Class Initialized
INFO - 2018-03-29 15:25:48 --> Model Class Initialized
INFO - 2018-03-29 15:25:48 --> Model Class Initialized
INFO - 2018-03-29 15:25:48 --> Model Class Initialized
INFO - 2018-03-29 15:25:48 --> Model Class Initialized
INFO - 2018-03-29 15:25:48 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-29 15:25:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-03-29 15:25:48 --> Final output sent to browser
DEBUG - 2018-03-29 15:25:48 --> Total execution time: 2.3336
INFO - 2018-03-29 09:55:48 --> Config Class Initialized
INFO - 2018-03-29 09:55:48 --> Hooks Class Initialized
DEBUG - 2018-03-29 09:55:48 --> UTF-8 Support Enabled
INFO - 2018-03-29 09:55:48 --> Utf8 Class Initialized
INFO - 2018-03-29 09:55:48 --> URI Class Initialized
INFO - 2018-03-29 09:55:48 --> Router Class Initialized
INFO - 2018-03-29 09:55:48 --> Output Class Initialized
INFO - 2018-03-29 09:55:48 --> Security Class Initialized
DEBUG - 2018-03-29 09:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 09:55:48 --> Input Class Initialized
INFO - 2018-03-29 09:55:48 --> Language Class Initialized
INFO - 2018-03-29 09:55:48 --> Language Class Initialized
INFO - 2018-03-29 09:55:48 --> Config Class Initialized
INFO - 2018-03-29 09:55:48 --> Loader Class Initialized
INFO - 2018-03-29 15:25:48 --> Helper loaded: url_helper
INFO - 2018-03-29 15:25:48 --> Helper loaded: notification_helper
INFO - 2018-03-29 15:25:48 --> Helper loaded: settings_helper
INFO - 2018-03-29 15:25:48 --> Helper loaded: permission_helper
INFO - 2018-03-29 15:25:48 --> Helper loaded: users_helper
INFO - 2018-03-29 15:25:48 --> Database Driver Class Initialized
DEBUG - 2018-03-29 15:25:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 15:25:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 15:25:48 --> Helper loaded: form_helper
INFO - 2018-03-29 15:25:48 --> Form Validation Class Initialized
INFO - 2018-03-29 15:25:48 --> Controller Class Initialized
INFO - 2018-03-29 15:25:48 --> Model Class Initialized
INFO - 2018-03-29 15:25:48 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 15:25:48 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 15:25:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 15:25:48 --> Model Class Initialized
INFO - 2018-03-29 15:25:48 --> Model Class Initialized
INFO - 2018-03-29 15:25:48 --> Model Class Initialized
INFO - 2018-03-29 15:25:48 --> Model Class Initialized
INFO - 2018-03-29 15:25:48 --> Model Class Initialized
INFO - 2018-03-29 15:25:48 --> Model Class Initialized
INFO - 2018-03-29 15:25:48 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-29 15:25:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-03-29 15:25:48 --> Final output sent to browser
DEBUG - 2018-03-29 15:25:48 --> Total execution time: 0.7765
INFO - 2018-03-29 09:58:45 --> Config Class Initialized
INFO - 2018-03-29 09:58:45 --> Hooks Class Initialized
DEBUG - 2018-03-29 09:58:45 --> UTF-8 Support Enabled
INFO - 2018-03-29 09:58:45 --> Utf8 Class Initialized
INFO - 2018-03-29 09:58:45 --> URI Class Initialized
INFO - 2018-03-29 09:58:45 --> Router Class Initialized
INFO - 2018-03-29 09:58:45 --> Output Class Initialized
INFO - 2018-03-29 09:58:45 --> Security Class Initialized
DEBUG - 2018-03-29 09:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 09:58:45 --> Input Class Initialized
INFO - 2018-03-29 09:58:45 --> Language Class Initialized
INFO - 2018-03-29 09:58:45 --> Language Class Initialized
INFO - 2018-03-29 09:58:45 --> Config Class Initialized
INFO - 2018-03-29 09:58:45 --> Loader Class Initialized
INFO - 2018-03-29 15:28:45 --> Helper loaded: url_helper
INFO - 2018-03-29 15:28:45 --> Helper loaded: notification_helper
INFO - 2018-03-29 15:28:45 --> Helper loaded: settings_helper
INFO - 2018-03-29 15:28:45 --> Helper loaded: permission_helper
INFO - 2018-03-29 15:28:45 --> Helper loaded: users_helper
INFO - 2018-03-29 15:28:45 --> Database Driver Class Initialized
DEBUG - 2018-03-29 15:28:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 15:28:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 15:28:45 --> Helper loaded: form_helper
INFO - 2018-03-29 15:28:45 --> Form Validation Class Initialized
INFO - 2018-03-29 15:28:45 --> Controller Class Initialized
INFO - 2018-03-29 15:28:45 --> Model Class Initialized
INFO - 2018-03-29 15:28:45 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 15:28:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 15:28:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 15:28:45 --> Model Class Initialized
INFO - 2018-03-29 15:28:45 --> Model Class Initialized
INFO - 2018-03-29 15:28:45 --> Model Class Initialized
INFO - 2018-03-29 15:28:45 --> Model Class Initialized
INFO - 2018-03-29 15:28:45 --> Model Class Initialized
INFO - 2018-03-29 15:28:45 --> Model Class Initialized
INFO - 2018-03-29 15:28:45 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 15:28:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-29 15:28:45 --> Final output sent to browser
DEBUG - 2018-03-29 15:28:45 --> Total execution time: 0.1162
INFO - 2018-03-29 09:58:46 --> Config Class Initialized
INFO - 2018-03-29 09:58:46 --> Hooks Class Initialized
DEBUG - 2018-03-29 09:58:46 --> UTF-8 Support Enabled
INFO - 2018-03-29 09:58:46 --> Utf8 Class Initialized
INFO - 2018-03-29 09:58:46 --> URI Class Initialized
INFO - 2018-03-29 09:58:46 --> Router Class Initialized
INFO - 2018-03-29 09:58:46 --> Output Class Initialized
INFO - 2018-03-29 09:58:46 --> Security Class Initialized
DEBUG - 2018-03-29 09:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 09:58:46 --> Input Class Initialized
INFO - 2018-03-29 09:58:46 --> Language Class Initialized
INFO - 2018-03-29 09:58:46 --> Config Class Initialized
INFO - 2018-03-29 09:58:46 --> Hooks Class Initialized
DEBUG - 2018-03-29 09:58:46 --> UTF-8 Support Enabled
INFO - 2018-03-29 09:58:46 --> Utf8 Class Initialized
INFO - 2018-03-29 09:58:46 --> URI Class Initialized
INFO - 2018-03-29 09:58:46 --> Router Class Initialized
INFO - 2018-03-29 09:58:46 --> Output Class Initialized
INFO - 2018-03-29 09:58:46 --> Security Class Initialized
DEBUG - 2018-03-29 09:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 09:58:46 --> Input Class Initialized
INFO - 2018-03-29 09:58:46 --> Language Class Initialized
INFO - 2018-03-29 09:58:46 --> Language Class Initialized
INFO - 2018-03-29 09:58:46 --> Config Class Initialized
INFO - 2018-03-29 09:58:46 --> Loader Class Initialized
INFO - 2018-03-29 15:28:46 --> Helper loaded: url_helper
INFO - 2018-03-29 15:28:46 --> Helper loaded: notification_helper
INFO - 2018-03-29 15:28:46 --> Helper loaded: settings_helper
INFO - 2018-03-29 15:28:46 --> Helper loaded: permission_helper
INFO - 2018-03-29 15:28:46 --> Helper loaded: users_helper
INFO - 2018-03-29 09:58:46 --> Language Class Initialized
INFO - 2018-03-29 09:58:46 --> Config Class Initialized
INFO - 2018-03-29 09:58:46 --> Loader Class Initialized
INFO - 2018-03-29 15:28:46 --> Helper loaded: url_helper
INFO - 2018-03-29 15:28:46 --> Helper loaded: notification_helper
INFO - 2018-03-29 15:28:46 --> Helper loaded: settings_helper
INFO - 2018-03-29 15:28:46 --> Helper loaded: permission_helper
INFO - 2018-03-29 15:28:46 --> Helper loaded: users_helper
INFO - 2018-03-29 15:28:46 --> Database Driver Class Initialized
DEBUG - 2018-03-29 15:28:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 15:28:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 15:28:46 --> Helper loaded: form_helper
INFO - 2018-03-29 15:28:46 --> Form Validation Class Initialized
INFO - 2018-03-29 15:28:46 --> Controller Class Initialized
INFO - 2018-03-29 15:28:46 --> Model Class Initialized
INFO - 2018-03-29 15:28:46 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 15:28:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 15:28:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 15:28:46 --> Model Class Initialized
INFO - 2018-03-29 15:28:46 --> Model Class Initialized
INFO - 2018-03-29 15:28:46 --> Model Class Initialized
INFO - 2018-03-29 15:28:46 --> Model Class Initialized
INFO - 2018-03-29 15:28:46 --> Model Class Initialized
INFO - 2018-03-29 15:28:46 --> Model Class Initialized
INFO - 2018-03-29 15:28:46 --> Model Class Initialized
INFO - 2018-03-29 15:28:46 --> Model Class Initialized
INFO - 2018-03-29 15:28:46 --> Model Class Initialized
INFO - 2018-03-29 15:28:46 --> Model Class Initialized
INFO - 2018-03-29 15:28:46 --> Model Class Initialized
INFO - 2018-03-29 15:28:46 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 15:28:46 --> Model Class Initialized
INFO - 2018-03-29 15:28:46 --> Database Driver Class Initialized
INFO - 2018-03-29 15:28:46 --> Final output sent to browser
DEBUG - 2018-03-29 15:28:46 --> Total execution time: 0.1954
DEBUG - 2018-03-29 15:28:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 15:28:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 15:28:46 --> Helper loaded: form_helper
INFO - 2018-03-29 15:28:46 --> Form Validation Class Initialized
INFO - 2018-03-29 15:28:46 --> Controller Class Initialized
INFO - 2018-03-29 15:28:46 --> Model Class Initialized
INFO - 2018-03-29 15:28:46 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 15:28:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 15:28:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 15:28:47 --> Model Class Initialized
INFO - 2018-03-29 15:28:47 --> Model Class Initialized
INFO - 2018-03-29 15:28:47 --> Model Class Initialized
INFO - 2018-03-29 15:28:47 --> Model Class Initialized
INFO - 2018-03-29 15:28:47 --> Model Class Initialized
INFO - 2018-03-29 15:28:47 --> Model Class Initialized
INFO - 2018-03-29 15:28:47 --> Model Class Initialized
INFO - 2018-03-29 15:28:47 --> Model Class Initialized
INFO - 2018-03-29 15:28:47 --> Model Class Initialized
INFO - 2018-03-29 15:28:47 --> Model Class Initialized
INFO - 2018-03-29 15:28:47 --> Model Class Initialized
INFO - 2018-03-29 15:28:47 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 15:28:47 --> Model Class Initialized
INFO - 2018-03-29 15:28:47 --> Final output sent to browser
DEBUG - 2018-03-29 15:28:47 --> Total execution time: 0.6873
INFO - 2018-03-29 09:58:56 --> Config Class Initialized
INFO - 2018-03-29 09:58:56 --> Hooks Class Initialized
DEBUG - 2018-03-29 09:58:56 --> UTF-8 Support Enabled
INFO - 2018-03-29 09:58:56 --> Utf8 Class Initialized
INFO - 2018-03-29 09:58:56 --> URI Class Initialized
INFO - 2018-03-29 09:58:56 --> Router Class Initialized
INFO - 2018-03-29 09:58:56 --> Config Class Initialized
INFO - 2018-03-29 09:58:56 --> Hooks Class Initialized
INFO - 2018-03-29 09:58:56 --> Output Class Initialized
DEBUG - 2018-03-29 09:58:56 --> UTF-8 Support Enabled
INFO - 2018-03-29 09:58:56 --> Utf8 Class Initialized
INFO - 2018-03-29 09:58:56 --> URI Class Initialized
INFO - 2018-03-29 09:58:56 --> Security Class Initialized
DEBUG - 2018-03-29 09:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 09:58:56 --> Input Class Initialized
INFO - 2018-03-29 09:58:56 --> Language Class Initialized
INFO - 2018-03-29 09:58:56 --> Router Class Initialized
INFO - 2018-03-29 09:58:56 --> Output Class Initialized
INFO - 2018-03-29 09:58:56 --> Security Class Initialized
DEBUG - 2018-03-29 09:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 09:58:56 --> Input Class Initialized
INFO - 2018-03-29 09:58:56 --> Language Class Initialized
INFO - 2018-03-29 09:58:56 --> Language Class Initialized
INFO - 2018-03-29 09:58:56 --> Config Class Initialized
INFO - 2018-03-29 09:58:56 --> Loader Class Initialized
INFO - 2018-03-29 15:28:56 --> Helper loaded: url_helper
INFO - 2018-03-29 15:28:56 --> Helper loaded: notification_helper
INFO - 2018-03-29 15:28:56 --> Helper loaded: settings_helper
INFO - 2018-03-29 15:28:56 --> Helper loaded: permission_helper
INFO - 2018-03-29 15:28:56 --> Helper loaded: users_helper
INFO - 2018-03-29 09:58:56 --> Language Class Initialized
INFO - 2018-03-29 09:58:56 --> Config Class Initialized
INFO - 2018-03-29 09:58:56 --> Loader Class Initialized
INFO - 2018-03-29 15:28:56 --> Helper loaded: url_helper
INFO - 2018-03-29 15:28:56 --> Helper loaded: notification_helper
INFO - 2018-03-29 15:28:56 --> Helper loaded: settings_helper
INFO - 2018-03-29 15:28:56 --> Helper loaded: permission_helper
INFO - 2018-03-29 15:28:56 --> Helper loaded: users_helper
INFO - 2018-03-29 15:28:56 --> Database Driver Class Initialized
DEBUG - 2018-03-29 15:28:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 15:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 15:28:56 --> Helper loaded: form_helper
INFO - 2018-03-29 15:28:56 --> Form Validation Class Initialized
INFO - 2018-03-29 15:28:56 --> Controller Class Initialized
INFO - 2018-03-29 15:28:56 --> Model Class Initialized
INFO - 2018-03-29 15:28:56 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 15:28:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 15:28:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 15:28:56 --> Model Class Initialized
INFO - 2018-03-29 15:28:56 --> Model Class Initialized
INFO - 2018-03-29 15:28:56 --> Model Class Initialized
INFO - 2018-03-29 15:28:56 --> Model Class Initialized
INFO - 2018-03-29 15:28:56 --> Model Class Initialized
INFO - 2018-03-29 15:28:56 --> Model Class Initialized
INFO - 2018-03-29 15:28:56 --> Model Class Initialized
INFO - 2018-03-29 15:28:56 --> Model Class Initialized
INFO - 2018-03-29 15:28:56 --> Model Class Initialized
INFO - 2018-03-29 15:28:56 --> Model Class Initialized
INFO - 2018-03-29 15:28:56 --> Database Driver Class Initialized
INFO - 2018-03-29 15:28:56 --> Model Class Initialized
INFO - 2018-03-29 15:28:56 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 15:28:56 --> Model Class Initialized
DEBUG - 2018-03-29 15:28:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 15:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 15:28:56 --> Final output sent to browser
DEBUG - 2018-03-29 15:28:56 --> Total execution time: 1.0874
INFO - 2018-03-29 15:28:56 --> Helper loaded: form_helper
INFO - 2018-03-29 15:28:56 --> Form Validation Class Initialized
INFO - 2018-03-29 15:28:56 --> Controller Class Initialized
INFO - 2018-03-29 15:28:56 --> Model Class Initialized
INFO - 2018-03-29 15:28:56 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 15:28:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 15:28:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 15:28:56 --> Model Class Initialized
INFO - 2018-03-29 15:28:56 --> Model Class Initialized
INFO - 2018-03-29 15:28:56 --> Model Class Initialized
INFO - 2018-03-29 15:28:56 --> Model Class Initialized
INFO - 2018-03-29 15:28:56 --> Model Class Initialized
INFO - 2018-03-29 15:28:56 --> Model Class Initialized
INFO - 2018-03-29 15:28:56 --> Model Class Initialized
INFO - 2018-03-29 15:28:56 --> Model Class Initialized
INFO - 2018-03-29 15:28:56 --> Model Class Initialized
INFO - 2018-03-29 15:28:56 --> Model Class Initialized
INFO - 2018-03-29 15:28:56 --> Model Class Initialized
INFO - 2018-03-29 15:28:56 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 15:28:56 --> Final output sent to browser
DEBUG - 2018-03-29 15:28:56 --> Total execution time: 0.7155
INFO - 2018-03-29 09:58:58 --> Config Class Initialized
INFO - 2018-03-29 09:58:58 --> Hooks Class Initialized
DEBUG - 2018-03-29 09:58:58 --> UTF-8 Support Enabled
INFO - 2018-03-29 09:58:58 --> Utf8 Class Initialized
INFO - 2018-03-29 09:58:58 --> URI Class Initialized
INFO - 2018-03-29 09:58:58 --> Router Class Initialized
INFO - 2018-03-29 09:58:58 --> Output Class Initialized
INFO - 2018-03-29 09:58:58 --> Security Class Initialized
DEBUG - 2018-03-29 09:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 09:58:58 --> Input Class Initialized
INFO - 2018-03-29 09:58:58 --> Language Class Initialized
INFO - 2018-03-29 09:58:58 --> Language Class Initialized
INFO - 2018-03-29 09:58:58 --> Config Class Initialized
INFO - 2018-03-29 09:58:58 --> Loader Class Initialized
INFO - 2018-03-29 15:28:58 --> Helper loaded: url_helper
INFO - 2018-03-29 15:28:58 --> Helper loaded: notification_helper
INFO - 2018-03-29 15:28:58 --> Helper loaded: settings_helper
INFO - 2018-03-29 15:28:58 --> Helper loaded: permission_helper
INFO - 2018-03-29 15:28:58 --> Helper loaded: users_helper
INFO - 2018-03-29 15:28:59 --> Database Driver Class Initialized
DEBUG - 2018-03-29 15:28:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 15:28:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 15:28:59 --> Helper loaded: form_helper
INFO - 2018-03-29 15:28:59 --> Form Validation Class Initialized
INFO - 2018-03-29 15:28:59 --> Controller Class Initialized
INFO - 2018-03-29 09:58:59 --> Config Class Initialized
INFO - 2018-03-29 15:28:59 --> Model Class Initialized
INFO - 2018-03-29 09:58:59 --> Hooks Class Initialized
INFO - 2018-03-29 15:28:59 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 15:28:59 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 15:28:59 --> Language file loaded: language/english/rest_controller_lang.php
DEBUG - 2018-03-29 09:58:59 --> UTF-8 Support Enabled
INFO - 2018-03-29 09:58:59 --> Utf8 Class Initialized
INFO - 2018-03-29 15:28:59 --> Model Class Initialized
INFO - 2018-03-29 15:28:59 --> Model Class Initialized
INFO - 2018-03-29 09:58:59 --> URI Class Initialized
INFO - 2018-03-29 15:28:59 --> Model Class Initialized
INFO - 2018-03-29 15:28:59 --> Model Class Initialized
INFO - 2018-03-29 09:58:59 --> Router Class Initialized
INFO - 2018-03-29 09:58:59 --> Output Class Initialized
INFO - 2018-03-29 09:58:59 --> Security Class Initialized
DEBUG - 2018-03-29 09:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 09:58:59 --> Input Class Initialized
INFO - 2018-03-29 09:58:59 --> Language Class Initialized
INFO - 2018-03-29 09:58:59 --> Language Class Initialized
INFO - 2018-03-29 09:58:59 --> Config Class Initialized
INFO - 2018-03-29 09:58:59 --> Loader Class Initialized
INFO - 2018-03-29 15:28:59 --> Helper loaded: url_helper
INFO - 2018-03-29 15:28:59 --> Helper loaded: notification_helper
INFO - 2018-03-29 15:28:59 --> Helper loaded: settings_helper
INFO - 2018-03-29 15:28:59 --> Helper loaded: permission_helper
INFO - 2018-03-29 15:28:59 --> Helper loaded: users_helper
INFO - 2018-03-29 15:28:59 --> Database Driver Class Initialized
DEBUG - 2018-03-29 15:28:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 15:28:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 15:28:59 --> Helper loaded: form_helper
INFO - 2018-03-29 15:28:59 --> Form Validation Class Initialized
INFO - 2018-03-29 15:28:59 --> Controller Class Initialized
INFO - 2018-03-29 15:28:59 --> Model Class Initialized
INFO - 2018-03-29 15:28:59 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 15:28:59 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 15:28:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 15:28:59 --> Model Class Initialized
INFO - 2018-03-29 15:28:59 --> Model Class Initialized
INFO - 2018-03-29 15:28:59 --> Model Class Initialized
INFO - 2018-03-29 15:28:59 --> Model Class Initialized
INFO - 2018-03-29 15:28:59 --> Final output sent to browser
INFO - 2018-03-29 15:28:59 --> Final output sent to browser
DEBUG - 2018-03-29 15:28:59 --> Total execution time: 0.1731
DEBUG - 2018-03-29 15:28:59 --> Total execution time: 0.2838
INFO - 2018-03-29 09:59:00 --> Config Class Initialized
INFO - 2018-03-29 09:59:00 --> Hooks Class Initialized
INFO - 2018-03-29 09:59:00 --> Config Class Initialized
INFO - 2018-03-29 09:59:00 --> Hooks Class Initialized
DEBUG - 2018-03-29 09:59:00 --> UTF-8 Support Enabled
INFO - 2018-03-29 09:59:00 --> Utf8 Class Initialized
DEBUG - 2018-03-29 09:59:00 --> UTF-8 Support Enabled
INFO - 2018-03-29 09:59:00 --> Utf8 Class Initialized
INFO - 2018-03-29 09:59:00 --> URI Class Initialized
INFO - 2018-03-29 09:59:01 --> URI Class Initialized
INFO - 2018-03-29 09:59:01 --> Router Class Initialized
INFO - 2018-03-29 09:59:01 --> Router Class Initialized
INFO - 2018-03-29 09:59:01 --> Output Class Initialized
INFO - 2018-03-29 09:59:01 --> Output Class Initialized
INFO - 2018-03-29 09:59:01 --> Security Class Initialized
INFO - 2018-03-29 09:59:01 --> Security Class Initialized
DEBUG - 2018-03-29 09:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 09:59:01 --> Input Class Initialized
DEBUG - 2018-03-29 09:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 09:59:01 --> Input Class Initialized
INFO - 2018-03-29 09:59:01 --> Language Class Initialized
INFO - 2018-03-29 09:59:01 --> Language Class Initialized
INFO - 2018-03-29 09:59:01 --> Language Class Initialized
INFO - 2018-03-29 09:59:01 --> Config Class Initialized
INFO - 2018-03-29 09:59:01 --> Loader Class Initialized
INFO - 2018-03-29 15:29:01 --> Helper loaded: url_helper
INFO - 2018-03-29 15:29:01 --> Helper loaded: notification_helper
INFO - 2018-03-29 15:29:01 --> Helper loaded: settings_helper
INFO - 2018-03-29 15:29:01 --> Helper loaded: permission_helper
INFO - 2018-03-29 15:29:01 --> Helper loaded: users_helper
INFO - 2018-03-29 15:29:01 --> Database Driver Class Initialized
INFO - 2018-03-29 09:59:01 --> Language Class Initialized
INFO - 2018-03-29 09:59:01 --> Config Class Initialized
INFO - 2018-03-29 09:59:01 --> Loader Class Initialized
INFO - 2018-03-29 15:29:01 --> Helper loaded: url_helper
INFO - 2018-03-29 15:29:01 --> Helper loaded: notification_helper
DEBUG - 2018-03-29 15:29:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 15:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 15:29:01 --> Helper loaded: settings_helper
INFO - 2018-03-29 15:29:01 --> Helper loaded: permission_helper
INFO - 2018-03-29 15:29:01 --> Helper loaded: users_helper
INFO - 2018-03-29 15:29:01 --> Helper loaded: form_helper
INFO - 2018-03-29 15:29:01 --> Form Validation Class Initialized
INFO - 2018-03-29 15:29:01 --> Controller Class Initialized
INFO - 2018-03-29 15:29:01 --> Model Class Initialized
INFO - 2018-03-29 15:29:01 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 15:29:01 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 15:29:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 15:29:01 --> Model Class Initialized
INFO - 2018-03-29 15:29:01 --> Model Class Initialized
INFO - 2018-03-29 15:29:01 --> Model Class Initialized
INFO - 2018-03-29 15:29:01 --> Model Class Initialized
INFO - 2018-03-29 15:29:01 --> Model Class Initialized
INFO - 2018-03-29 15:29:01 --> Model Class Initialized
INFO - 2018-03-29 15:29:01 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-29 15:29:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-03-29 15:29:01 --> Final output sent to browser
DEBUG - 2018-03-29 15:29:01 --> Total execution time: 0.1358
INFO - 2018-03-29 15:29:01 --> Database Driver Class Initialized
DEBUG - 2018-03-29 15:29:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 15:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 15:29:01 --> Helper loaded: form_helper
INFO - 2018-03-29 15:29:01 --> Form Validation Class Initialized
INFO - 2018-03-29 15:29:01 --> Controller Class Initialized
INFO - 2018-03-29 15:29:01 --> Model Class Initialized
INFO - 2018-03-29 15:29:01 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 15:29:01 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 15:29:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 15:29:01 --> Model Class Initialized
INFO - 2018-03-29 15:29:01 --> Model Class Initialized
INFO - 2018-03-29 15:29:01 --> Model Class Initialized
INFO - 2018-03-29 15:29:01 --> Model Class Initialized
INFO - 2018-03-29 15:29:01 --> Model Class Initialized
INFO - 2018-03-29 15:29:01 --> Model Class Initialized
INFO - 2018-03-29 15:29:01 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-29 15:29:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-03-29 15:29:01 --> Final output sent to browser
DEBUG - 2018-03-29 15:29:01 --> Total execution time: 0.2929
INFO - 2018-03-29 10:28:23 --> Config Class Initialized
INFO - 2018-03-29 10:28:23 --> Hooks Class Initialized
DEBUG - 2018-03-29 10:28:23 --> UTF-8 Support Enabled
INFO - 2018-03-29 10:28:23 --> Utf8 Class Initialized
INFO - 2018-03-29 10:28:23 --> URI Class Initialized
INFO - 2018-03-29 10:28:23 --> Router Class Initialized
INFO - 2018-03-29 10:28:23 --> Output Class Initialized
INFO - 2018-03-29 10:28:23 --> Security Class Initialized
DEBUG - 2018-03-29 10:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 10:28:23 --> Input Class Initialized
INFO - 2018-03-29 10:28:23 --> Language Class Initialized
INFO - 2018-03-29 10:28:24 --> Language Class Initialized
INFO - 2018-03-29 10:28:24 --> Config Class Initialized
INFO - 2018-03-29 10:28:24 --> Loader Class Initialized
INFO - 2018-03-29 15:58:24 --> Helper loaded: url_helper
INFO - 2018-03-29 15:58:24 --> Helper loaded: notification_helper
INFO - 2018-03-29 15:58:24 --> Helper loaded: settings_helper
INFO - 2018-03-29 15:58:24 --> Helper loaded: permission_helper
INFO - 2018-03-29 15:58:24 --> Helper loaded: users_helper
INFO - 2018-03-29 15:58:24 --> Database Driver Class Initialized
DEBUG - 2018-03-29 15:58:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 15:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 15:58:24 --> Helper loaded: form_helper
INFO - 2018-03-29 15:58:24 --> Form Validation Class Initialized
INFO - 2018-03-29 15:58:24 --> Controller Class Initialized
INFO - 2018-03-29 15:58:24 --> Model Class Initialized
INFO - 2018-03-29 15:58:24 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 15:58:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 15:58:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 15:58:24 --> Model Class Initialized
INFO - 2018-03-29 15:58:24 --> Model Class Initialized
INFO - 2018-03-29 15:58:24 --> Model Class Initialized
INFO - 2018-03-29 15:58:24 --> Model Class Initialized
INFO - 2018-03-29 15:58:24 --> Model Class Initialized
INFO - 2018-03-29 15:58:24 --> Model Class Initialized
INFO - 2018-03-29 15:58:24 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 15:58:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-29 15:58:24 --> Final output sent to browser
DEBUG - 2018-03-29 15:58:24 --> Total execution time: 1.4086
INFO - 2018-03-29 10:28:25 --> Config Class Initialized
INFO - 2018-03-29 10:28:25 --> Hooks Class Initialized
DEBUG - 2018-03-29 10:28:25 --> UTF-8 Support Enabled
INFO - 2018-03-29 10:28:25 --> Utf8 Class Initialized
INFO - 2018-03-29 10:28:25 --> URI Class Initialized
INFO - 2018-03-29 10:28:25 --> Router Class Initialized
INFO - 2018-03-29 10:28:25 --> Output Class Initialized
INFO - 2018-03-29 10:28:25 --> Security Class Initialized
DEBUG - 2018-03-29 10:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 10:28:25 --> Input Class Initialized
INFO - 2018-03-29 10:28:25 --> Language Class Initialized
INFO - 2018-03-29 10:28:25 --> Language Class Initialized
INFO - 2018-03-29 10:28:25 --> Config Class Initialized
INFO - 2018-03-29 10:28:25 --> Loader Class Initialized
INFO - 2018-03-29 15:58:25 --> Helper loaded: url_helper
INFO - 2018-03-29 15:58:25 --> Helper loaded: notification_helper
INFO - 2018-03-29 15:58:25 --> Helper loaded: settings_helper
INFO - 2018-03-29 15:58:25 --> Helper loaded: permission_helper
INFO - 2018-03-29 15:58:25 --> Helper loaded: users_helper
INFO - 2018-03-29 15:58:25 --> Database Driver Class Initialized
DEBUG - 2018-03-29 15:58:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 15:58:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 15:58:25 --> Helper loaded: form_helper
INFO - 2018-03-29 15:58:25 --> Form Validation Class Initialized
INFO - 2018-03-29 15:58:25 --> Controller Class Initialized
INFO - 2018-03-29 15:58:25 --> Model Class Initialized
INFO - 2018-03-29 15:58:25 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 15:58:25 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 15:58:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 15:58:25 --> Model Class Initialized
INFO - 2018-03-29 15:58:25 --> Model Class Initialized
INFO - 2018-03-29 15:58:25 --> Model Class Initialized
INFO - 2018-03-29 15:58:25 --> Model Class Initialized
INFO - 2018-03-29 15:58:25 --> Model Class Initialized
INFO - 2018-03-29 15:58:25 --> Model Class Initialized
INFO - 2018-03-29 15:58:25 --> Model Class Initialized
INFO - 2018-03-29 15:58:25 --> Model Class Initialized
INFO - 2018-03-29 15:58:25 --> Model Class Initialized
INFO - 2018-03-29 15:58:25 --> Model Class Initialized
INFO - 2018-03-29 15:58:25 --> Model Class Initialized
INFO - 2018-03-29 15:58:25 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 15:58:25 --> Model Class Initialized
INFO - 2018-03-29 15:58:25 --> Final output sent to browser
DEBUG - 2018-03-29 15:58:25 --> Total execution time: 0.1261
INFO - 2018-03-29 10:28:26 --> Config Class Initialized
INFO - 2018-03-29 10:28:26 --> Hooks Class Initialized
DEBUG - 2018-03-29 10:28:26 --> UTF-8 Support Enabled
INFO - 2018-03-29 10:28:26 --> Utf8 Class Initialized
INFO - 2018-03-29 10:28:27 --> URI Class Initialized
INFO - 2018-03-29 10:28:27 --> Router Class Initialized
INFO - 2018-03-29 10:28:27 --> Output Class Initialized
INFO - 2018-03-29 10:28:27 --> Security Class Initialized
DEBUG - 2018-03-29 10:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 10:28:27 --> Input Class Initialized
INFO - 2018-03-29 10:28:27 --> Language Class Initialized
INFO - 2018-03-29 10:28:27 --> Config Class Initialized
INFO - 2018-03-29 10:28:27 --> Hooks Class Initialized
DEBUG - 2018-03-29 10:28:27 --> UTF-8 Support Enabled
INFO - 2018-03-29 10:28:27 --> Utf8 Class Initialized
INFO - 2018-03-29 10:28:27 --> URI Class Initialized
INFO - 2018-03-29 10:28:27 --> Router Class Initialized
INFO - 2018-03-29 10:28:27 --> Output Class Initialized
INFO - 2018-03-29 10:28:27 --> Security Class Initialized
DEBUG - 2018-03-29 10:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 10:28:27 --> Input Class Initialized
INFO - 2018-03-29 10:28:27 --> Language Class Initialized
INFO - 2018-03-29 10:28:27 --> Language Class Initialized
INFO - 2018-03-29 10:28:27 --> Config Class Initialized
INFO - 2018-03-29 10:28:27 --> Loader Class Initialized
INFO - 2018-03-29 15:58:27 --> Helper loaded: url_helper
INFO - 2018-03-29 15:58:27 --> Helper loaded: notification_helper
INFO - 2018-03-29 15:58:27 --> Helper loaded: settings_helper
INFO - 2018-03-29 15:58:27 --> Helper loaded: permission_helper
INFO - 2018-03-29 15:58:27 --> Helper loaded: users_helper
INFO - 2018-03-29 15:58:27 --> Database Driver Class Initialized
DEBUG - 2018-03-29 15:58:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 15:58:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 15:58:27 --> Helper loaded: form_helper
INFO - 2018-03-29 15:58:27 --> Form Validation Class Initialized
INFO - 2018-03-29 15:58:27 --> Controller Class Initialized
INFO - 2018-03-29 15:58:27 --> Model Class Initialized
INFO - 2018-03-29 15:58:27 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 15:58:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 15:58:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 15:58:27 --> Model Class Initialized
INFO - 2018-03-29 15:58:27 --> Model Class Initialized
INFO - 2018-03-29 15:58:27 --> Model Class Initialized
INFO - 2018-03-29 15:58:27 --> Model Class Initialized
INFO - 2018-03-29 15:58:27 --> Model Class Initialized
INFO - 2018-03-29 15:58:27 --> Model Class Initialized
INFO - 2018-03-29 15:58:27 --> Model Class Initialized
INFO - 2018-03-29 15:58:27 --> Model Class Initialized
INFO - 2018-03-29 15:58:27 --> Model Class Initialized
INFO - 2018-03-29 15:58:27 --> Model Class Initialized
INFO - 2018-03-29 15:58:27 --> Model Class Initialized
INFO - 2018-03-29 15:58:27 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 15:58:27 --> Model Class Initialized
INFO - 2018-03-29 15:58:27 --> Final output sent to browser
DEBUG - 2018-03-29 15:58:27 --> Total execution time: 0.2146
INFO - 2018-03-29 10:28:28 --> Language Class Initialized
INFO - 2018-03-29 10:28:28 --> Config Class Initialized
INFO - 2018-03-29 10:28:28 --> Loader Class Initialized
INFO - 2018-03-29 15:58:28 --> Helper loaded: url_helper
INFO - 2018-03-29 15:58:28 --> Helper loaded: notification_helper
INFO - 2018-03-29 15:58:28 --> Helper loaded: settings_helper
INFO - 2018-03-29 15:58:28 --> Helper loaded: permission_helper
INFO - 2018-03-29 15:58:28 --> Helper loaded: users_helper
INFO - 2018-03-29 15:58:29 --> Database Driver Class Initialized
DEBUG - 2018-03-29 15:58:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 15:58:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 15:58:29 --> Helper loaded: form_helper
INFO - 2018-03-29 15:58:29 --> Form Validation Class Initialized
INFO - 2018-03-29 15:58:29 --> Controller Class Initialized
INFO - 2018-03-29 15:58:29 --> Model Class Initialized
INFO - 2018-03-29 15:58:29 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 15:58:29 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 15:58:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 15:58:29 --> Model Class Initialized
INFO - 2018-03-29 15:58:29 --> Model Class Initialized
INFO - 2018-03-29 15:58:29 --> Model Class Initialized
INFO - 2018-03-29 15:58:29 --> Model Class Initialized
INFO - 2018-03-29 15:58:29 --> Model Class Initialized
INFO - 2018-03-29 15:58:29 --> Model Class Initialized
INFO - 2018-03-29 15:58:29 --> Model Class Initialized
INFO - 2018-03-29 15:58:29 --> Model Class Initialized
INFO - 2018-03-29 15:58:29 --> Model Class Initialized
INFO - 2018-03-29 15:58:29 --> Model Class Initialized
INFO - 2018-03-29 15:58:29 --> Model Class Initialized
INFO - 2018-03-29 15:58:29 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 15:58:29 --> Model Class Initialized
INFO - 2018-03-29 15:58:29 --> Final output sent to browser
DEBUG - 2018-03-29 15:58:29 --> Total execution time: 3.0297
INFO - 2018-03-29 10:28:56 --> Config Class Initialized
INFO - 2018-03-29 10:28:56 --> Hooks Class Initialized
DEBUG - 2018-03-29 10:28:57 --> UTF-8 Support Enabled
INFO - 2018-03-29 10:28:57 --> Utf8 Class Initialized
INFO - 2018-03-29 10:28:57 --> URI Class Initialized
INFO - 2018-03-29 10:28:57 --> Router Class Initialized
INFO - 2018-03-29 10:28:57 --> Output Class Initialized
INFO - 2018-03-29 10:28:57 --> Security Class Initialized
INFO - 2018-03-29 10:28:57 --> Config Class Initialized
INFO - 2018-03-29 10:28:57 --> Hooks Class Initialized
DEBUG - 2018-03-29 10:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 10:28:57 --> Input Class Initialized
INFO - 2018-03-29 10:28:57 --> Language Class Initialized
DEBUG - 2018-03-29 10:28:57 --> UTF-8 Support Enabled
INFO - 2018-03-29 10:28:57 --> Utf8 Class Initialized
INFO - 2018-03-29 10:28:57 --> URI Class Initialized
INFO - 2018-03-29 10:28:57 --> Router Class Initialized
INFO - 2018-03-29 10:28:57 --> Language Class Initialized
INFO - 2018-03-29 10:28:57 --> Config Class Initialized
INFO - 2018-03-29 10:28:57 --> Loader Class Initialized
INFO - 2018-03-29 10:28:58 --> Output Class Initialized
INFO - 2018-03-29 15:58:58 --> Helper loaded: url_helper
INFO - 2018-03-29 10:28:58 --> Security Class Initialized
INFO - 2018-03-29 15:58:58 --> Helper loaded: notification_helper
INFO - 2018-03-29 15:58:58 --> Helper loaded: settings_helper
INFO - 2018-03-29 15:58:58 --> Helper loaded: permission_helper
INFO - 2018-03-29 15:58:58 --> Helper loaded: users_helper
DEBUG - 2018-03-29 10:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 10:28:58 --> Input Class Initialized
INFO - 2018-03-29 10:28:58 --> Language Class Initialized
INFO - 2018-03-29 10:28:58 --> Config Class Initialized
INFO - 2018-03-29 10:28:58 --> Hooks Class Initialized
DEBUG - 2018-03-29 10:28:58 --> UTF-8 Support Enabled
INFO - 2018-03-29 10:28:58 --> Utf8 Class Initialized
INFO - 2018-03-29 10:28:58 --> URI Class Initialized
INFO - 2018-03-29 10:28:58 --> Router Class Initialized
INFO - 2018-03-29 10:28:58 --> Output Class Initialized
INFO - 2018-03-29 10:28:58 --> Security Class Initialized
DEBUG - 2018-03-29 10:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 10:28:58 --> Input Class Initialized
INFO - 2018-03-29 10:28:58 --> Language Class Initialized
INFO - 2018-03-29 10:28:58 --> Language Class Initialized
INFO - 2018-03-29 10:28:58 --> Config Class Initialized
INFO - 2018-03-29 10:28:58 --> Loader Class Initialized
INFO - 2018-03-29 15:58:58 --> Helper loaded: url_helper
INFO - 2018-03-29 15:58:58 --> Helper loaded: notification_helper
INFO - 2018-03-29 15:58:58 --> Helper loaded: settings_helper
INFO - 2018-03-29 15:58:58 --> Helper loaded: permission_helper
INFO - 2018-03-29 15:58:58 --> Helper loaded: users_helper
INFO - 2018-03-29 15:58:58 --> Database Driver Class Initialized
DEBUG - 2018-03-29 15:58:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 15:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 15:58:58 --> Helper loaded: form_helper
INFO - 2018-03-29 15:58:58 --> Form Validation Class Initialized
INFO - 2018-03-29 15:58:58 --> Controller Class Initialized
INFO - 2018-03-29 15:58:58 --> Model Class Initialized
INFO - 2018-03-29 15:58:58 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 15:58:58 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 15:58:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 15:58:58 --> Model Class Initialized
INFO - 2018-03-29 15:58:58 --> Model Class Initialized
INFO - 2018-03-29 15:58:58 --> Model Class Initialized
INFO - 2018-03-29 15:58:58 --> Model Class Initialized
INFO - 2018-03-29 15:58:58 --> Model Class Initialized
INFO - 2018-03-29 15:58:58 --> Model Class Initialized
INFO - 2018-03-29 15:58:58 --> Model Class Initialized
INFO - 2018-03-29 15:58:58 --> Model Class Initialized
INFO - 2018-03-29 15:58:58 --> Model Class Initialized
INFO - 2018-03-29 15:58:58 --> Model Class Initialized
INFO - 2018-03-29 15:58:58 --> Model Class Initialized
INFO - 2018-03-29 15:58:58 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 15:58:58 --> Model Class Initialized
INFO - 2018-03-29 15:58:58 --> Final output sent to browser
DEBUG - 2018-03-29 15:58:58 --> Total execution time: 0.1298
INFO - 2018-03-29 15:58:58 --> Database Driver Class Initialized
DEBUG - 2018-03-29 15:58:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 15:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 15:58:58 --> Helper loaded: form_helper
INFO - 2018-03-29 15:58:58 --> Form Validation Class Initialized
INFO - 2018-03-29 15:58:58 --> Controller Class Initialized
INFO - 2018-03-29 15:58:58 --> Model Class Initialized
INFO - 2018-03-29 15:58:58 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 15:58:58 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 15:58:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 15:58:58 --> Model Class Initialized
INFO - 2018-03-29 15:58:58 --> Model Class Initialized
INFO - 2018-03-29 15:58:58 --> Model Class Initialized
INFO - 2018-03-29 15:58:58 --> Model Class Initialized
INFO - 2018-03-29 15:58:58 --> Model Class Initialized
INFO - 2018-03-29 15:58:58 --> Model Class Initialized
INFO - 2018-03-29 15:58:58 --> Model Class Initialized
INFO - 2018-03-29 15:58:58 --> Model Class Initialized
INFO - 2018-03-29 15:58:58 --> Model Class Initialized
INFO - 2018-03-29 15:58:58 --> Model Class Initialized
INFO - 2018-03-29 15:58:58 --> Model Class Initialized
INFO - 2018-03-29 15:58:58 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 15:58:58 --> Model Class Initialized
INFO - 2018-03-29 15:58:58 --> Final output sent to browser
DEBUG - 2018-03-29 15:58:58 --> Total execution time: 2.2560
INFO - 2018-03-29 10:28:58 --> Language Class Initialized
INFO - 2018-03-29 10:28:58 --> Config Class Initialized
INFO - 2018-03-29 10:28:58 --> Loader Class Initialized
INFO - 2018-03-29 15:58:59 --> Helper loaded: url_helper
INFO - 2018-03-29 15:58:59 --> Helper loaded: notification_helper
INFO - 2018-03-29 15:58:59 --> Helper loaded: settings_helper
INFO - 2018-03-29 15:58:59 --> Helper loaded: permission_helper
INFO - 2018-03-29 15:58:59 --> Helper loaded: users_helper
INFO - 2018-03-29 15:58:59 --> Database Driver Class Initialized
DEBUG - 2018-03-29 15:58:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 15:58:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 15:58:59 --> Helper loaded: form_helper
INFO - 2018-03-29 15:58:59 --> Form Validation Class Initialized
INFO - 2018-03-29 15:58:59 --> Controller Class Initialized
INFO - 2018-03-29 15:58:59 --> Model Class Initialized
INFO - 2018-03-29 15:58:59 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 15:58:59 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 15:58:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 15:58:59 --> Model Class Initialized
INFO - 2018-03-29 15:58:59 --> Model Class Initialized
INFO - 2018-03-29 15:58:59 --> Model Class Initialized
INFO - 2018-03-29 15:58:59 --> Model Class Initialized
INFO - 2018-03-29 15:58:59 --> Model Class Initialized
INFO - 2018-03-29 15:58:59 --> Model Class Initialized
INFO - 2018-03-29 15:58:59 --> Model Class Initialized
INFO - 2018-03-29 15:58:59 --> Model Class Initialized
INFO - 2018-03-29 15:58:59 --> Model Class Initialized
INFO - 2018-03-29 15:58:59 --> Model Class Initialized
INFO - 2018-03-29 15:58:59 --> Model Class Initialized
INFO - 2018-03-29 15:58:59 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 15:58:59 --> Final output sent to browser
DEBUG - 2018-03-29 15:58:59 --> Total execution time: 2.2586
INFO - 2018-03-29 10:28:59 --> Config Class Initialized
INFO - 2018-03-29 10:28:59 --> Hooks Class Initialized
DEBUG - 2018-03-29 10:29:00 --> UTF-8 Support Enabled
INFO - 2018-03-29 10:29:00 --> Utf8 Class Initialized
INFO - 2018-03-29 10:29:00 --> URI Class Initialized
INFO - 2018-03-29 10:29:00 --> Router Class Initialized
INFO - 2018-03-29 10:29:00 --> Output Class Initialized
INFO - 2018-03-29 10:29:00 --> Security Class Initialized
DEBUG - 2018-03-29 10:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 10:29:00 --> Input Class Initialized
INFO - 2018-03-29 10:29:00 --> Language Class Initialized
INFO - 2018-03-29 10:29:00 --> Language Class Initialized
INFO - 2018-03-29 10:29:00 --> Config Class Initialized
INFO - 2018-03-29 10:29:00 --> Loader Class Initialized
INFO - 2018-03-29 15:59:01 --> Helper loaded: url_helper
INFO - 2018-03-29 15:59:01 --> Helper loaded: notification_helper
INFO - 2018-03-29 15:59:01 --> Helper loaded: settings_helper
INFO - 2018-03-29 15:59:01 --> Helper loaded: permission_helper
INFO - 2018-03-29 15:59:01 --> Helper loaded: users_helper
INFO - 2018-03-29 15:59:01 --> Database Driver Class Initialized
DEBUG - 2018-03-29 15:59:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 15:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 15:59:01 --> Helper loaded: form_helper
INFO - 2018-03-29 15:59:01 --> Form Validation Class Initialized
INFO - 2018-03-29 15:59:01 --> Controller Class Initialized
INFO - 2018-03-29 15:59:01 --> Model Class Initialized
INFO - 2018-03-29 15:59:01 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 15:59:01 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 15:59:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 15:59:01 --> Model Class Initialized
INFO - 2018-03-29 15:59:01 --> Model Class Initialized
INFO - 2018-03-29 15:59:01 --> Model Class Initialized
INFO - 2018-03-29 15:59:01 --> Model Class Initialized
INFO - 2018-03-29 15:59:01 --> Model Class Initialized
INFO - 2018-03-29 15:59:01 --> Model Class Initialized
INFO - 2018-03-29 15:59:01 --> Model Class Initialized
INFO - 2018-03-29 15:59:01 --> Model Class Initialized
INFO - 2018-03-29 15:59:01 --> Model Class Initialized
INFO - 2018-03-29 15:59:01 --> Model Class Initialized
INFO - 2018-03-29 15:59:01 --> Model Class Initialized
INFO - 2018-03-29 15:59:01 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 15:59:01 --> Final output sent to browser
DEBUG - 2018-03-29 15:59:01 --> Total execution time: 1.5160
INFO - 2018-03-29 10:29:03 --> Config Class Initialized
INFO - 2018-03-29 10:29:03 --> Hooks Class Initialized
DEBUG - 2018-03-29 10:29:03 --> UTF-8 Support Enabled
INFO - 2018-03-29 10:29:03 --> Utf8 Class Initialized
INFO - 2018-03-29 10:29:03 --> URI Class Initialized
INFO - 2018-03-29 10:29:03 --> Router Class Initialized
INFO - 2018-03-29 10:29:03 --> Output Class Initialized
INFO - 2018-03-29 10:29:03 --> Security Class Initialized
DEBUG - 2018-03-29 10:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 10:29:03 --> Input Class Initialized
INFO - 2018-03-29 10:29:03 --> Language Class Initialized
INFO - 2018-03-29 10:29:03 --> Language Class Initialized
INFO - 2018-03-29 10:29:03 --> Config Class Initialized
INFO - 2018-03-29 10:29:03 --> Loader Class Initialized
INFO - 2018-03-29 15:59:03 --> Helper loaded: url_helper
INFO - 2018-03-29 15:59:03 --> Helper loaded: notification_helper
INFO - 2018-03-29 15:59:03 --> Helper loaded: settings_helper
INFO - 2018-03-29 15:59:03 --> Helper loaded: permission_helper
INFO - 2018-03-29 15:59:03 --> Helper loaded: users_helper
INFO - 2018-03-29 15:59:03 --> Database Driver Class Initialized
DEBUG - 2018-03-29 15:59:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 15:59:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 15:59:03 --> Helper loaded: form_helper
INFO - 2018-03-29 15:59:03 --> Form Validation Class Initialized
INFO - 2018-03-29 15:59:03 --> Controller Class Initialized
INFO - 2018-03-29 15:59:03 --> Model Class Initialized
INFO - 2018-03-29 15:59:03 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 15:59:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 15:59:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 15:59:03 --> Model Class Initialized
INFO - 2018-03-29 15:59:03 --> Model Class Initialized
INFO - 2018-03-29 15:59:03 --> Model Class Initialized
INFO - 2018-03-29 15:59:03 --> Model Class Initialized
INFO - 2018-03-29 15:59:03 --> Model Class Initialized
INFO - 2018-03-29 15:59:03 --> Model Class Initialized
INFO - 2018-03-29 15:59:03 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-29 15:59:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-03-29 15:59:03 --> Final output sent to browser
DEBUG - 2018-03-29 15:59:03 --> Total execution time: 0.1286
INFO - 2018-03-29 10:29:03 --> Config Class Initialized
INFO - 2018-03-29 10:29:03 --> Hooks Class Initialized
DEBUG - 2018-03-29 10:29:03 --> UTF-8 Support Enabled
INFO - 2018-03-29 10:29:03 --> Utf8 Class Initialized
INFO - 2018-03-29 10:29:03 --> URI Class Initialized
INFO - 2018-03-29 10:29:03 --> Router Class Initialized
INFO - 2018-03-29 10:29:03 --> Output Class Initialized
INFO - 2018-03-29 10:29:03 --> Security Class Initialized
DEBUG - 2018-03-29 10:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 10:29:03 --> Input Class Initialized
INFO - 2018-03-29 10:29:03 --> Language Class Initialized
INFO - 2018-03-29 10:29:04 --> Language Class Initialized
INFO - 2018-03-29 10:29:04 --> Config Class Initialized
INFO - 2018-03-29 10:29:04 --> Loader Class Initialized
INFO - 2018-03-29 15:59:04 --> Helper loaded: url_helper
INFO - 2018-03-29 15:59:04 --> Helper loaded: notification_helper
INFO - 2018-03-29 15:59:04 --> Helper loaded: settings_helper
INFO - 2018-03-29 15:59:04 --> Helper loaded: permission_helper
INFO - 2018-03-29 15:59:04 --> Helper loaded: users_helper
INFO - 2018-03-29 15:59:04 --> Database Driver Class Initialized
DEBUG - 2018-03-29 15:59:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 15:59:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 15:59:04 --> Helper loaded: form_helper
INFO - 2018-03-29 15:59:04 --> Form Validation Class Initialized
INFO - 2018-03-29 15:59:04 --> Controller Class Initialized
INFO - 2018-03-29 15:59:04 --> Model Class Initialized
INFO - 2018-03-29 15:59:04 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 15:59:04 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 15:59:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 15:59:04 --> Model Class Initialized
INFO - 2018-03-29 15:59:04 --> Model Class Initialized
INFO - 2018-03-29 15:59:04 --> Model Class Initialized
INFO - 2018-03-29 15:59:04 --> Model Class Initialized
INFO - 2018-03-29 15:59:04 --> Model Class Initialized
INFO - 2018-03-29 15:59:04 --> Model Class Initialized
INFO - 2018-03-29 15:59:04 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-29 15:59:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-03-29 15:59:04 --> Final output sent to browser
DEBUG - 2018-03-29 15:59:04 --> Total execution time: 1.0284
INFO - 2018-03-29 10:42:14 --> Config Class Initialized
INFO - 2018-03-29 10:42:14 --> Hooks Class Initialized
DEBUG - 2018-03-29 10:42:14 --> UTF-8 Support Enabled
INFO - 2018-03-29 10:42:14 --> Utf8 Class Initialized
INFO - 2018-03-29 10:42:14 --> URI Class Initialized
INFO - 2018-03-29 10:42:14 --> Router Class Initialized
INFO - 2018-03-29 10:42:14 --> Output Class Initialized
INFO - 2018-03-29 10:42:14 --> Security Class Initialized
DEBUG - 2018-03-29 10:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 10:42:14 --> Input Class Initialized
INFO - 2018-03-29 10:42:14 --> Language Class Initialized
INFO - 2018-03-29 10:42:14 --> Language Class Initialized
INFO - 2018-03-29 10:42:14 --> Config Class Initialized
INFO - 2018-03-29 10:42:14 --> Loader Class Initialized
INFO - 2018-03-29 16:12:14 --> Helper loaded: url_helper
INFO - 2018-03-29 16:12:14 --> Helper loaded: notification_helper
INFO - 2018-03-29 16:12:14 --> Helper loaded: settings_helper
INFO - 2018-03-29 16:12:14 --> Helper loaded: permission_helper
INFO - 2018-03-29 16:12:14 --> Helper loaded: users_helper
INFO - 2018-03-29 16:12:14 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:12:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:12:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:12:14 --> Helper loaded: form_helper
INFO - 2018-03-29 16:12:14 --> Form Validation Class Initialized
INFO - 2018-03-29 16:12:14 --> Controller Class Initialized
INFO - 2018-03-29 16:12:14 --> Model Class Initialized
INFO - 2018-03-29 16:12:14 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 16:12:14 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 16:12:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 16:12:14 --> Model Class Initialized
INFO - 2018-03-29 16:12:14 --> Model Class Initialized
INFO - 2018-03-29 16:12:14 --> Model Class Initialized
INFO - 2018-03-29 16:12:14 --> Model Class Initialized
INFO - 2018-03-29 16:12:14 --> Model Class Initialized
INFO - 2018-03-29 16:12:14 --> Model Class Initialized
INFO - 2018-03-29 16:12:14 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 16:12:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-29 16:12:14 --> Final output sent to browser
DEBUG - 2018-03-29 16:12:14 --> Total execution time: 0.1251
INFO - 2018-03-29 10:42:15 --> Config Class Initialized
INFO - 2018-03-29 10:42:15 --> Hooks Class Initialized
DEBUG - 2018-03-29 10:42:15 --> UTF-8 Support Enabled
INFO - 2018-03-29 10:42:15 --> Utf8 Class Initialized
INFO - 2018-03-29 10:42:15 --> URI Class Initialized
INFO - 2018-03-29 10:42:15 --> Router Class Initialized
INFO - 2018-03-29 10:42:15 --> Output Class Initialized
INFO - 2018-03-29 10:42:15 --> Security Class Initialized
DEBUG - 2018-03-29 10:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 10:42:15 --> Input Class Initialized
INFO - 2018-03-29 10:42:15 --> Language Class Initialized
INFO - 2018-03-29 10:42:15 --> Language Class Initialized
INFO - 2018-03-29 10:42:15 --> Config Class Initialized
INFO - 2018-03-29 10:42:15 --> Loader Class Initialized
INFO - 2018-03-29 16:12:15 --> Helper loaded: url_helper
INFO - 2018-03-29 16:12:15 --> Helper loaded: notification_helper
INFO - 2018-03-29 16:12:15 --> Helper loaded: settings_helper
INFO - 2018-03-29 16:12:15 --> Helper loaded: permission_helper
INFO - 2018-03-29 16:12:15 --> Helper loaded: users_helper
INFO - 2018-03-29 16:12:15 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:12:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:12:15 --> Helper loaded: form_helper
INFO - 2018-03-29 16:12:15 --> Form Validation Class Initialized
INFO - 2018-03-29 16:12:15 --> Controller Class Initialized
INFO - 2018-03-29 16:12:15 --> Model Class Initialized
INFO - 2018-03-29 16:12:15 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 16:12:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 16:12:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 16:12:15 --> Model Class Initialized
INFO - 2018-03-29 16:12:15 --> Model Class Initialized
INFO - 2018-03-29 16:12:15 --> Model Class Initialized
INFO - 2018-03-29 16:12:15 --> Model Class Initialized
INFO - 2018-03-29 16:12:15 --> Model Class Initialized
INFO - 2018-03-29 16:12:15 --> Model Class Initialized
INFO - 2018-03-29 16:12:15 --> Model Class Initialized
INFO - 2018-03-29 16:12:15 --> Model Class Initialized
INFO - 2018-03-29 16:12:15 --> Model Class Initialized
INFO - 2018-03-29 16:12:15 --> Model Class Initialized
INFO - 2018-03-29 16:12:15 --> Model Class Initialized
INFO - 2018-03-29 16:12:15 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 16:12:15 --> Model Class Initialized
INFO - 2018-03-29 16:12:15 --> Final output sent to browser
DEBUG - 2018-03-29 16:12:15 --> Total execution time: 0.1397
INFO - 2018-03-29 10:42:15 --> Config Class Initialized
INFO - 2018-03-29 10:42:15 --> Hooks Class Initialized
DEBUG - 2018-03-29 10:42:15 --> UTF-8 Support Enabled
INFO - 2018-03-29 10:42:15 --> Utf8 Class Initialized
INFO - 2018-03-29 10:42:15 --> URI Class Initialized
INFO - 2018-03-29 10:42:15 --> Router Class Initialized
INFO - 2018-03-29 10:42:15 --> Output Class Initialized
INFO - 2018-03-29 10:42:15 --> Security Class Initialized
DEBUG - 2018-03-29 10:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 10:42:15 --> Input Class Initialized
INFO - 2018-03-29 10:42:15 --> Language Class Initialized
INFO - 2018-03-29 10:42:15 --> Language Class Initialized
INFO - 2018-03-29 10:42:15 --> Config Class Initialized
INFO - 2018-03-29 10:42:15 --> Loader Class Initialized
INFO - 2018-03-29 16:12:15 --> Helper loaded: url_helper
INFO - 2018-03-29 16:12:15 --> Helper loaded: notification_helper
INFO - 2018-03-29 16:12:15 --> Helper loaded: settings_helper
INFO - 2018-03-29 16:12:15 --> Helper loaded: permission_helper
INFO - 2018-03-29 16:12:15 --> Helper loaded: users_helper
INFO - 2018-03-29 16:12:15 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:12:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:12:15 --> Helper loaded: form_helper
INFO - 2018-03-29 16:12:15 --> Form Validation Class Initialized
INFO - 2018-03-29 16:12:15 --> Controller Class Initialized
INFO - 2018-03-29 16:12:15 --> Model Class Initialized
INFO - 2018-03-29 16:12:15 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 16:12:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 16:12:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 16:12:15 --> Model Class Initialized
INFO - 2018-03-29 16:12:15 --> Model Class Initialized
INFO - 2018-03-29 16:12:15 --> Model Class Initialized
INFO - 2018-03-29 16:12:15 --> Model Class Initialized
INFO - 2018-03-29 16:12:15 --> Model Class Initialized
INFO - 2018-03-29 16:12:15 --> Model Class Initialized
INFO - 2018-03-29 16:12:15 --> Model Class Initialized
INFO - 2018-03-29 16:12:15 --> Model Class Initialized
INFO - 2018-03-29 16:12:15 --> Model Class Initialized
INFO - 2018-03-29 16:12:15 --> Model Class Initialized
INFO - 2018-03-29 16:12:15 --> Model Class Initialized
INFO - 2018-03-29 16:12:15 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 16:12:15 --> Model Class Initialized
INFO - 2018-03-29 16:12:15 --> Final output sent to browser
DEBUG - 2018-03-29 16:12:15 --> Total execution time: 0.1227
INFO - 2018-03-29 10:42:17 --> Config Class Initialized
INFO - 2018-03-29 10:42:17 --> Hooks Class Initialized
DEBUG - 2018-03-29 10:42:17 --> UTF-8 Support Enabled
INFO - 2018-03-29 10:42:17 --> Utf8 Class Initialized
INFO - 2018-03-29 10:42:17 --> URI Class Initialized
INFO - 2018-03-29 10:42:17 --> Router Class Initialized
INFO - 2018-03-29 10:42:17 --> Output Class Initialized
INFO - 2018-03-29 10:42:17 --> Security Class Initialized
DEBUG - 2018-03-29 10:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 10:42:17 --> Input Class Initialized
INFO - 2018-03-29 10:42:17 --> Language Class Initialized
INFO - 2018-03-29 10:42:18 --> Language Class Initialized
INFO - 2018-03-29 10:42:18 --> Config Class Initialized
INFO - 2018-03-29 10:42:18 --> Loader Class Initialized
INFO - 2018-03-29 16:12:18 --> Helper loaded: url_helper
INFO - 2018-03-29 16:12:18 --> Helper loaded: notification_helper
INFO - 2018-03-29 16:12:18 --> Helper loaded: settings_helper
INFO - 2018-03-29 16:12:18 --> Helper loaded: permission_helper
INFO - 2018-03-29 10:42:18 --> Config Class Initialized
INFO - 2018-03-29 10:42:18 --> Hooks Class Initialized
INFO - 2018-03-29 16:12:18 --> Helper loaded: users_helper
DEBUG - 2018-03-29 10:42:18 --> UTF-8 Support Enabled
INFO - 2018-03-29 10:42:18 --> Utf8 Class Initialized
INFO - 2018-03-29 10:42:18 --> URI Class Initialized
INFO - 2018-03-29 10:42:18 --> Router Class Initialized
INFO - 2018-03-29 10:42:18 --> Output Class Initialized
INFO - 2018-03-29 10:42:18 --> Security Class Initialized
DEBUG - 2018-03-29 10:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 10:42:18 --> Input Class Initialized
INFO - 2018-03-29 10:42:18 --> Language Class Initialized
INFO - 2018-03-29 16:12:18 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:12:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:12:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:12:18 --> Helper loaded: form_helper
INFO - 2018-03-29 16:12:18 --> Form Validation Class Initialized
INFO - 2018-03-29 16:12:18 --> Controller Class Initialized
INFO - 2018-03-29 16:12:18 --> Model Class Initialized
INFO - 2018-03-29 16:12:18 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 16:12:18 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 16:12:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 16:12:18 --> Model Class Initialized
INFO - 2018-03-29 16:12:18 --> Model Class Initialized
INFO - 2018-03-29 16:12:18 --> Model Class Initialized
INFO - 2018-03-29 16:12:18 --> Model Class Initialized
INFO - 2018-03-29 16:12:18 --> Model Class Initialized
INFO - 2018-03-29 16:12:18 --> Model Class Initialized
INFO - 2018-03-29 16:12:18 --> Model Class Initialized
INFO - 2018-03-29 16:12:18 --> Model Class Initialized
INFO - 2018-03-29 16:12:18 --> Model Class Initialized
INFO - 2018-03-29 16:12:18 --> Model Class Initialized
INFO - 2018-03-29 16:12:18 --> Model Class Initialized
INFO - 2018-03-29 16:12:18 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 16:12:18 --> Final output sent to browser
DEBUG - 2018-03-29 16:12:18 --> Total execution time: 0.7556
INFO - 2018-03-29 10:42:18 --> Language Class Initialized
INFO - 2018-03-29 10:42:18 --> Config Class Initialized
INFO - 2018-03-29 10:42:18 --> Loader Class Initialized
INFO - 2018-03-29 16:12:18 --> Helper loaded: url_helper
INFO - 2018-03-29 16:12:18 --> Helper loaded: notification_helper
INFO - 2018-03-29 16:12:18 --> Helper loaded: settings_helper
INFO - 2018-03-29 16:12:18 --> Helper loaded: permission_helper
INFO - 2018-03-29 16:12:18 --> Helper loaded: users_helper
INFO - 2018-03-29 16:12:19 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:12:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:12:19 --> Helper loaded: form_helper
INFO - 2018-03-29 16:12:19 --> Form Validation Class Initialized
INFO - 2018-03-29 16:12:19 --> Controller Class Initialized
INFO - 2018-03-29 16:12:19 --> Model Class Initialized
INFO - 2018-03-29 16:12:19 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 16:12:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 16:12:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 16:12:19 --> Model Class Initialized
INFO - 2018-03-29 16:12:19 --> Model Class Initialized
INFO - 2018-03-29 16:12:19 --> Model Class Initialized
INFO - 2018-03-29 16:12:19 --> Model Class Initialized
INFO - 2018-03-29 16:12:19 --> Model Class Initialized
INFO - 2018-03-29 16:12:19 --> Model Class Initialized
INFO - 2018-03-29 16:12:19 --> Model Class Initialized
INFO - 2018-03-29 16:12:19 --> Model Class Initialized
INFO - 2018-03-29 16:12:19 --> Model Class Initialized
INFO - 2018-03-29 16:12:19 --> Model Class Initialized
INFO - 2018-03-29 16:12:19 --> Model Class Initialized
INFO - 2018-03-29 16:12:19 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 16:12:19 --> Model Class Initialized
INFO - 2018-03-29 16:12:19 --> Final output sent to browser
DEBUG - 2018-03-29 16:12:19 --> Total execution time: 1.5680
INFO - 2018-03-29 10:42:22 --> Config Class Initialized
INFO - 2018-03-29 10:42:22 --> Hooks Class Initialized
DEBUG - 2018-03-29 10:42:22 --> UTF-8 Support Enabled
INFO - 2018-03-29 10:42:22 --> Utf8 Class Initialized
INFO - 2018-03-29 10:42:22 --> URI Class Initialized
INFO - 2018-03-29 10:42:22 --> Router Class Initialized
INFO - 2018-03-29 10:42:22 --> Output Class Initialized
INFO - 2018-03-29 10:42:22 --> Security Class Initialized
DEBUG - 2018-03-29 10:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 10:42:22 --> Input Class Initialized
INFO - 2018-03-29 10:42:22 --> Language Class Initialized
INFO - 2018-03-29 10:42:22 --> Language Class Initialized
INFO - 2018-03-29 10:42:22 --> Config Class Initialized
INFO - 2018-03-29 10:42:22 --> Loader Class Initialized
INFO - 2018-03-29 16:12:22 --> Helper loaded: url_helper
INFO - 2018-03-29 16:12:22 --> Helper loaded: notification_helper
INFO - 2018-03-29 16:12:22 --> Helper loaded: settings_helper
INFO - 2018-03-29 16:12:22 --> Helper loaded: permission_helper
INFO - 2018-03-29 16:12:22 --> Helper loaded: users_helper
INFO - 2018-03-29 16:12:22 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:12:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:12:23 --> Helper loaded: form_helper
INFO - 2018-03-29 16:12:23 --> Form Validation Class Initialized
INFO - 2018-03-29 16:12:23 --> Controller Class Initialized
INFO - 2018-03-29 16:12:23 --> Model Class Initialized
INFO - 2018-03-29 16:12:23 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 16:12:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 16:12:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 16:12:23 --> Model Class Initialized
INFO - 2018-03-29 16:12:23 --> Model Class Initialized
INFO - 2018-03-29 16:12:23 --> Model Class Initialized
INFO - 2018-03-29 16:12:23 --> Model Class Initialized
INFO - 2018-03-29 16:12:23 --> Model Class Initialized
INFO - 2018-03-29 16:12:23 --> Model Class Initialized
INFO - 2018-03-29 16:12:23 --> Model Class Initialized
INFO - 2018-03-29 16:12:23 --> Model Class Initialized
INFO - 2018-03-29 16:12:23 --> Model Class Initialized
INFO - 2018-03-29 16:12:23 --> Model Class Initialized
INFO - 2018-03-29 16:12:23 --> Model Class Initialized
INFO - 2018-03-29 16:12:23 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 16:12:23 --> Model Class Initialized
INFO - 2018-03-29 16:12:23 --> Final output sent to browser
DEBUG - 2018-03-29 16:12:23 --> Total execution time: 0.1822
INFO - 2018-03-29 10:42:26 --> Config Class Initialized
INFO - 2018-03-29 10:42:26 --> Hooks Class Initialized
DEBUG - 2018-03-29 10:42:26 --> UTF-8 Support Enabled
INFO - 2018-03-29 10:42:26 --> Utf8 Class Initialized
INFO - 2018-03-29 10:42:26 --> URI Class Initialized
INFO - 2018-03-29 10:42:27 --> Router Class Initialized
INFO - 2018-03-29 10:42:27 --> Output Class Initialized
INFO - 2018-03-29 10:42:27 --> Security Class Initialized
DEBUG - 2018-03-29 10:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 10:42:27 --> Input Class Initialized
INFO - 2018-03-29 10:42:27 --> Language Class Initialized
INFO - 2018-03-29 10:42:27 --> Language Class Initialized
INFO - 2018-03-29 10:42:27 --> Config Class Initialized
INFO - 2018-03-29 10:42:27 --> Loader Class Initialized
INFO - 2018-03-29 16:12:27 --> Helper loaded: url_helper
INFO - 2018-03-29 16:12:27 --> Helper loaded: notification_helper
INFO - 2018-03-29 16:12:27 --> Helper loaded: settings_helper
INFO - 2018-03-29 16:12:27 --> Helper loaded: permission_helper
INFO - 2018-03-29 16:12:27 --> Helper loaded: users_helper
INFO - 2018-03-29 16:12:27 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:12:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:12:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:12:28 --> Helper loaded: form_helper
INFO - 2018-03-29 16:12:28 --> Form Validation Class Initialized
INFO - 2018-03-29 16:12:28 --> Controller Class Initialized
INFO - 2018-03-29 16:12:28 --> Model Class Initialized
INFO - 2018-03-29 16:12:28 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 16:12:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 16:12:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 16:12:28 --> Model Class Initialized
INFO - 2018-03-29 16:12:28 --> Model Class Initialized
INFO - 2018-03-29 16:12:28 --> Model Class Initialized
INFO - 2018-03-29 16:12:28 --> Model Class Initialized
INFO - 2018-03-29 16:12:28 --> Model Class Initialized
INFO - 2018-03-29 16:12:28 --> Model Class Initialized
INFO - 2018-03-29 16:12:28 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-29 16:12:28 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-03-29 16:12:28 --> Final output sent to browser
DEBUG - 2018-03-29 16:12:28 --> Total execution time: 1.7000
INFO - 2018-03-29 10:50:40 --> Config Class Initialized
INFO - 2018-03-29 10:50:40 --> Hooks Class Initialized
DEBUG - 2018-03-29 10:50:40 --> UTF-8 Support Enabled
INFO - 2018-03-29 10:50:40 --> Utf8 Class Initialized
INFO - 2018-03-29 10:50:40 --> URI Class Initialized
INFO - 2018-03-29 10:50:40 --> Router Class Initialized
INFO - 2018-03-29 10:50:40 --> Output Class Initialized
INFO - 2018-03-29 10:50:40 --> Security Class Initialized
DEBUG - 2018-03-29 10:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 10:50:40 --> Input Class Initialized
INFO - 2018-03-29 10:50:40 --> Language Class Initialized
INFO - 2018-03-29 10:50:40 --> Language Class Initialized
INFO - 2018-03-29 10:50:40 --> Config Class Initialized
INFO - 2018-03-29 10:50:40 --> Loader Class Initialized
INFO - 2018-03-29 16:20:41 --> Helper loaded: url_helper
INFO - 2018-03-29 16:20:41 --> Helper loaded: notification_helper
INFO - 2018-03-29 16:20:41 --> Helper loaded: settings_helper
INFO - 2018-03-29 16:20:41 --> Helper loaded: permission_helper
INFO - 2018-03-29 16:20:41 --> Helper loaded: users_helper
INFO - 2018-03-29 16:20:41 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:20:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:20:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:20:41 --> Helper loaded: form_helper
INFO - 2018-03-29 16:20:41 --> Form Validation Class Initialized
INFO - 2018-03-29 16:20:41 --> Controller Class Initialized
INFO - 2018-03-29 16:20:42 --> Model Class Initialized
INFO - 2018-03-29 16:20:42 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 16:20:42 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 16:20:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 16:20:42 --> Model Class Initialized
INFO - 2018-03-29 16:20:42 --> Model Class Initialized
INFO - 2018-03-29 16:20:42 --> Model Class Initialized
INFO - 2018-03-29 16:20:42 --> Model Class Initialized
INFO - 2018-03-29 16:20:42 --> Model Class Initialized
INFO - 2018-03-29 16:20:42 --> Model Class Initialized
INFO - 2018-03-29 16:20:42 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 16:20:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-29 16:20:42 --> Final output sent to browser
DEBUG - 2018-03-29 16:20:42 --> Total execution time: 1.6477
INFO - 2018-03-29 10:50:43 --> Config Class Initialized
INFO - 2018-03-29 10:50:43 --> Hooks Class Initialized
DEBUG - 2018-03-29 10:50:43 --> UTF-8 Support Enabled
INFO - 2018-03-29 10:50:43 --> Utf8 Class Initialized
INFO - 2018-03-29 10:50:43 --> URI Class Initialized
INFO - 2018-03-29 10:50:43 --> Router Class Initialized
INFO - 2018-03-29 10:50:43 --> Output Class Initialized
INFO - 2018-03-29 10:50:43 --> Security Class Initialized
DEBUG - 2018-03-29 10:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 10:50:43 --> Input Class Initialized
INFO - 2018-03-29 10:50:43 --> Language Class Initialized
INFO - 2018-03-29 10:50:43 --> Language Class Initialized
INFO - 2018-03-29 10:50:43 --> Config Class Initialized
INFO - 2018-03-29 10:50:43 --> Loader Class Initialized
INFO - 2018-03-29 16:20:43 --> Helper loaded: url_helper
INFO - 2018-03-29 16:20:43 --> Helper loaded: notification_helper
INFO - 2018-03-29 16:20:43 --> Helper loaded: settings_helper
INFO - 2018-03-29 16:20:43 --> Helper loaded: permission_helper
INFO - 2018-03-29 16:20:43 --> Helper loaded: users_helper
INFO - 2018-03-29 16:20:43 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:20:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:20:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:20:43 --> Helper loaded: form_helper
INFO - 2018-03-29 16:20:43 --> Form Validation Class Initialized
INFO - 2018-03-29 16:20:43 --> Controller Class Initialized
INFO - 2018-03-29 16:20:43 --> Model Class Initialized
INFO - 2018-03-29 16:20:43 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 16:20:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 16:20:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 16:20:43 --> Model Class Initialized
INFO - 2018-03-29 16:20:43 --> Model Class Initialized
INFO - 2018-03-29 16:20:43 --> Model Class Initialized
INFO - 2018-03-29 16:20:43 --> Model Class Initialized
INFO - 2018-03-29 16:20:43 --> Model Class Initialized
INFO - 2018-03-29 16:20:43 --> Model Class Initialized
INFO - 2018-03-29 16:20:43 --> Model Class Initialized
INFO - 2018-03-29 16:20:43 --> Model Class Initialized
INFO - 2018-03-29 16:20:43 --> Model Class Initialized
INFO - 2018-03-29 16:20:43 --> Model Class Initialized
INFO - 2018-03-29 16:20:43 --> Model Class Initialized
INFO - 2018-03-29 16:20:43 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 16:20:43 --> Model Class Initialized
INFO - 2018-03-29 16:20:43 --> Final output sent to browser
DEBUG - 2018-03-29 16:20:43 --> Total execution time: 0.2113
INFO - 2018-03-29 10:50:45 --> Config Class Initialized
INFO - 2018-03-29 10:50:45 --> Hooks Class Initialized
DEBUG - 2018-03-29 10:50:45 --> UTF-8 Support Enabled
INFO - 2018-03-29 10:50:45 --> Utf8 Class Initialized
INFO - 2018-03-29 10:50:45 --> URI Class Initialized
INFO - 2018-03-29 10:50:45 --> Router Class Initialized
INFO - 2018-03-29 10:50:45 --> Config Class Initialized
INFO - 2018-03-29 10:50:45 --> Hooks Class Initialized
DEBUG - 2018-03-29 10:50:45 --> UTF-8 Support Enabled
INFO - 2018-03-29 10:50:45 --> Utf8 Class Initialized
INFO - 2018-03-29 10:50:45 --> URI Class Initialized
INFO - 2018-03-29 10:50:45 --> Router Class Initialized
INFO - 2018-03-29 10:50:45 --> Output Class Initialized
INFO - 2018-03-29 10:50:45 --> Output Class Initialized
INFO - 2018-03-29 10:50:45 --> Security Class Initialized
DEBUG - 2018-03-29 10:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 10:50:45 --> Input Class Initialized
INFO - 2018-03-29 10:50:45 --> Language Class Initialized
INFO - 2018-03-29 10:50:45 --> Language Class Initialized
INFO - 2018-03-29 10:50:45 --> Config Class Initialized
INFO - 2018-03-29 10:50:45 --> Loader Class Initialized
INFO - 2018-03-29 16:20:45 --> Helper loaded: url_helper
INFO - 2018-03-29 16:20:45 --> Helper loaded: notification_helper
INFO - 2018-03-29 16:20:45 --> Helper loaded: settings_helper
INFO - 2018-03-29 16:20:45 --> Helper loaded: permission_helper
INFO - 2018-03-29 16:20:45 --> Helper loaded: users_helper
INFO - 2018-03-29 16:20:45 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:20:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:20:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:20:45 --> Helper loaded: form_helper
INFO - 2018-03-29 16:20:45 --> Form Validation Class Initialized
INFO - 2018-03-29 16:20:45 --> Controller Class Initialized
INFO - 2018-03-29 16:20:45 --> Model Class Initialized
INFO - 2018-03-29 16:20:45 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 16:20:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 16:20:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 16:20:45 --> Model Class Initialized
INFO - 2018-03-29 16:20:45 --> Model Class Initialized
INFO - 2018-03-29 16:20:45 --> Model Class Initialized
INFO - 2018-03-29 16:20:45 --> Model Class Initialized
INFO - 2018-03-29 16:20:45 --> Model Class Initialized
INFO - 2018-03-29 16:20:45 --> Model Class Initialized
INFO - 2018-03-29 16:20:45 --> Model Class Initialized
INFO - 2018-03-29 16:20:45 --> Model Class Initialized
INFO - 2018-03-29 16:20:45 --> Model Class Initialized
INFO - 2018-03-29 16:20:45 --> Model Class Initialized
INFO - 2018-03-29 16:20:45 --> Model Class Initialized
INFO - 2018-03-29 16:20:45 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 16:20:45 --> Model Class Initialized
INFO - 2018-03-29 16:20:45 --> Final output sent to browser
DEBUG - 2018-03-29 16:20:45 --> Total execution time: 0.2272
INFO - 2018-03-29 10:50:45 --> Security Class Initialized
DEBUG - 2018-03-29 10:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 10:50:46 --> Input Class Initialized
INFO - 2018-03-29 10:50:46 --> Language Class Initialized
INFO - 2018-03-29 10:50:46 --> Language Class Initialized
INFO - 2018-03-29 10:50:46 --> Config Class Initialized
INFO - 2018-03-29 10:50:46 --> Loader Class Initialized
INFO - 2018-03-29 16:20:46 --> Helper loaded: url_helper
INFO - 2018-03-29 16:20:46 --> Helper loaded: notification_helper
INFO - 2018-03-29 16:20:46 --> Helper loaded: settings_helper
INFO - 2018-03-29 16:20:46 --> Helper loaded: permission_helper
INFO - 2018-03-29 16:20:46 --> Helper loaded: users_helper
INFO - 2018-03-29 16:20:46 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:20:46 --> Helper loaded: form_helper
INFO - 2018-03-29 16:20:46 --> Form Validation Class Initialized
INFO - 2018-03-29 16:20:46 --> Controller Class Initialized
INFO - 2018-03-29 16:20:46 --> Model Class Initialized
INFO - 2018-03-29 16:20:46 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 16:20:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 16:20:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 16:20:46 --> Model Class Initialized
INFO - 2018-03-29 16:20:46 --> Model Class Initialized
INFO - 2018-03-29 16:20:46 --> Model Class Initialized
INFO - 2018-03-29 16:20:46 --> Model Class Initialized
INFO - 2018-03-29 16:20:47 --> Model Class Initialized
INFO - 2018-03-29 16:20:47 --> Model Class Initialized
INFO - 2018-03-29 16:20:47 --> Model Class Initialized
INFO - 2018-03-29 16:20:47 --> Model Class Initialized
INFO - 2018-03-29 16:20:47 --> Model Class Initialized
INFO - 2018-03-29 16:20:47 --> Model Class Initialized
INFO - 2018-03-29 16:20:47 --> Model Class Initialized
INFO - 2018-03-29 16:20:47 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 16:20:47 --> Model Class Initialized
INFO - 2018-03-29 16:20:47 --> Final output sent to browser
DEBUG - 2018-03-29 16:20:47 --> Total execution time: 2.4443
INFO - 2018-03-29 10:50:47 --> Config Class Initialized
INFO - 2018-03-29 10:50:47 --> Hooks Class Initialized
DEBUG - 2018-03-29 10:50:47 --> UTF-8 Support Enabled
INFO - 2018-03-29 10:50:47 --> Utf8 Class Initialized
INFO - 2018-03-29 10:50:47 --> URI Class Initialized
INFO - 2018-03-29 10:50:47 --> Router Class Initialized
INFO - 2018-03-29 10:50:47 --> Output Class Initialized
INFO - 2018-03-29 10:50:47 --> Security Class Initialized
DEBUG - 2018-03-29 10:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 10:50:47 --> Input Class Initialized
INFO - 2018-03-29 10:50:47 --> Language Class Initialized
INFO - 2018-03-29 10:50:47 --> Language Class Initialized
INFO - 2018-03-29 10:50:47 --> Config Class Initialized
INFO - 2018-03-29 10:50:47 --> Loader Class Initialized
INFO - 2018-03-29 16:20:47 --> Helper loaded: url_helper
INFO - 2018-03-29 16:20:47 --> Helper loaded: notification_helper
INFO - 2018-03-29 16:20:47 --> Helper loaded: settings_helper
INFO - 2018-03-29 16:20:47 --> Helper loaded: permission_helper
INFO - 2018-03-29 16:20:47 --> Helper loaded: users_helper
INFO - 2018-03-29 16:20:47 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:20:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:20:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:20:47 --> Helper loaded: form_helper
INFO - 2018-03-29 16:20:47 --> Form Validation Class Initialized
INFO - 2018-03-29 16:20:47 --> Controller Class Initialized
INFO - 2018-03-29 16:20:48 --> Model Class Initialized
INFO - 2018-03-29 16:20:48 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 16:20:48 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 16:20:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 16:20:48 --> Model Class Initialized
INFO - 2018-03-29 16:20:48 --> Model Class Initialized
INFO - 2018-03-29 16:20:48 --> Model Class Initialized
INFO - 2018-03-29 16:20:48 --> Model Class Initialized
INFO - 2018-03-29 16:20:48 --> Model Class Initialized
INFO - 2018-03-29 16:20:48 --> Model Class Initialized
INFO - 2018-03-29 16:20:48 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-29 16:20:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-03-29 16:20:48 --> Final output sent to browser
DEBUG - 2018-03-29 16:20:48 --> Total execution time: 0.2025
INFO - 2018-03-29 10:50:48 --> Config Class Initialized
INFO - 2018-03-29 10:50:48 --> Hooks Class Initialized
DEBUG - 2018-03-29 10:50:48 --> UTF-8 Support Enabled
INFO - 2018-03-29 10:50:48 --> Utf8 Class Initialized
INFO - 2018-03-29 10:50:48 --> URI Class Initialized
INFO - 2018-03-29 10:50:48 --> Router Class Initialized
INFO - 2018-03-29 10:50:48 --> Output Class Initialized
INFO - 2018-03-29 10:50:48 --> Security Class Initialized
DEBUG - 2018-03-29 10:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 10:50:49 --> Input Class Initialized
INFO - 2018-03-29 10:50:49 --> Language Class Initialized
INFO - 2018-03-29 10:50:49 --> Language Class Initialized
INFO - 2018-03-29 10:50:49 --> Config Class Initialized
INFO - 2018-03-29 10:50:49 --> Loader Class Initialized
INFO - 2018-03-29 16:20:49 --> Helper loaded: url_helper
INFO - 2018-03-29 16:20:49 --> Helper loaded: notification_helper
INFO - 2018-03-29 16:20:49 --> Helper loaded: settings_helper
INFO - 2018-03-29 16:20:49 --> Helper loaded: permission_helper
INFO - 2018-03-29 16:20:49 --> Helper loaded: users_helper
INFO - 2018-03-29 16:20:50 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:20:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:20:50 --> Helper loaded: form_helper
INFO - 2018-03-29 16:20:50 --> Form Validation Class Initialized
INFO - 2018-03-29 16:20:50 --> Controller Class Initialized
INFO - 2018-03-29 16:20:50 --> Model Class Initialized
INFO - 2018-03-29 16:20:50 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 16:20:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 16:20:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 16:20:50 --> Model Class Initialized
INFO - 2018-03-29 16:20:50 --> Model Class Initialized
INFO - 2018-03-29 16:20:50 --> Model Class Initialized
INFO - 2018-03-29 16:20:50 --> Model Class Initialized
INFO - 2018-03-29 16:20:50 --> Model Class Initialized
INFO - 2018-03-29 16:20:50 --> Model Class Initialized
INFO - 2018-03-29 16:20:50 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-29 16:20:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-03-29 16:20:50 --> Final output sent to browser
DEBUG - 2018-03-29 16:20:50 --> Total execution time: 2.0570
INFO - 2018-03-29 10:50:50 --> Config Class Initialized
INFO - 2018-03-29 10:50:50 --> Hooks Class Initialized
DEBUG - 2018-03-29 10:50:50 --> UTF-8 Support Enabled
INFO - 2018-03-29 10:50:50 --> Utf8 Class Initialized
INFO - 2018-03-29 10:50:50 --> URI Class Initialized
INFO - 2018-03-29 10:50:50 --> Router Class Initialized
INFO - 2018-03-29 10:50:50 --> Output Class Initialized
INFO - 2018-03-29 10:50:50 --> Security Class Initialized
DEBUG - 2018-03-29 10:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 10:50:50 --> Input Class Initialized
INFO - 2018-03-29 10:50:50 --> Language Class Initialized
INFO - 2018-03-29 10:50:50 --> Language Class Initialized
INFO - 2018-03-29 10:50:50 --> Config Class Initialized
INFO - 2018-03-29 10:50:50 --> Loader Class Initialized
INFO - 2018-03-29 16:20:50 --> Helper loaded: url_helper
INFO - 2018-03-29 16:20:50 --> Helper loaded: notification_helper
INFO - 2018-03-29 16:20:50 --> Helper loaded: settings_helper
INFO - 2018-03-29 16:20:50 --> Helper loaded: permission_helper
INFO - 2018-03-29 16:20:50 --> Helper loaded: users_helper
INFO - 2018-03-29 16:20:50 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:20:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:20:50 --> Helper loaded: form_helper
INFO - 2018-03-29 16:20:50 --> Form Validation Class Initialized
INFO - 2018-03-29 16:20:50 --> Controller Class Initialized
INFO - 2018-03-29 16:20:51 --> Model Class Initialized
INFO - 2018-03-29 16:20:51 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 16:20:51 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 16:20:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 16:20:51 --> Model Class Initialized
INFO - 2018-03-29 16:20:51 --> Model Class Initialized
INFO - 2018-03-29 16:20:51 --> Model Class Initialized
INFO - 2018-03-29 16:20:51 --> Model Class Initialized
INFO - 2018-03-29 16:20:51 --> Model Class Initialized
INFO - 2018-03-29 16:20:51 --> Model Class Initialized
INFO - 2018-03-29 16:20:51 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-29 16:20:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-03-29 16:20:51 --> Final output sent to browser
DEBUG - 2018-03-29 16:20:51 --> Total execution time: 0.3439
INFO - 2018-03-29 10:53:12 --> Config Class Initialized
INFO - 2018-03-29 10:53:12 --> Hooks Class Initialized
DEBUG - 2018-03-29 10:53:12 --> UTF-8 Support Enabled
INFO - 2018-03-29 10:53:12 --> Utf8 Class Initialized
INFO - 2018-03-29 10:53:12 --> URI Class Initialized
INFO - 2018-03-29 10:53:12 --> Router Class Initialized
INFO - 2018-03-29 10:53:12 --> Output Class Initialized
INFO - 2018-03-29 10:53:12 --> Security Class Initialized
DEBUG - 2018-03-29 10:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 10:53:12 --> Input Class Initialized
INFO - 2018-03-29 10:53:12 --> Language Class Initialized
INFO - 2018-03-29 10:53:12 --> Language Class Initialized
INFO - 2018-03-29 10:53:12 --> Config Class Initialized
INFO - 2018-03-29 10:53:12 --> Loader Class Initialized
INFO - 2018-03-29 16:23:12 --> Helper loaded: url_helper
INFO - 2018-03-29 16:23:12 --> Helper loaded: notification_helper
INFO - 2018-03-29 16:23:12 --> Helper loaded: settings_helper
INFO - 2018-03-29 16:23:12 --> Helper loaded: permission_helper
INFO - 2018-03-29 16:23:12 --> Helper loaded: users_helper
INFO - 2018-03-29 16:23:12 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:23:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:23:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:23:12 --> Helper loaded: form_helper
INFO - 2018-03-29 16:23:12 --> Form Validation Class Initialized
INFO - 2018-03-29 16:23:12 --> Controller Class Initialized
INFO - 2018-03-29 16:23:12 --> Model Class Initialized
INFO - 2018-03-29 16:23:12 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 16:23:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 16:23:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 16:23:12 --> Model Class Initialized
INFO - 2018-03-29 16:23:12 --> Model Class Initialized
INFO - 2018-03-29 16:23:12 --> Model Class Initialized
INFO - 2018-03-29 16:23:12 --> Model Class Initialized
INFO - 2018-03-29 16:23:12 --> Model Class Initialized
INFO - 2018-03-29 16:23:12 --> Model Class Initialized
INFO - 2018-03-29 16:23:12 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 16:23:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-29 16:23:12 --> Final output sent to browser
DEBUG - 2018-03-29 16:23:12 --> Total execution time: 0.1316
INFO - 2018-03-29 10:53:13 --> Config Class Initialized
INFO - 2018-03-29 10:53:13 --> Hooks Class Initialized
DEBUG - 2018-03-29 10:53:13 --> UTF-8 Support Enabled
INFO - 2018-03-29 10:53:13 --> Utf8 Class Initialized
INFO - 2018-03-29 10:53:13 --> URI Class Initialized
INFO - 2018-03-29 10:53:13 --> Router Class Initialized
INFO - 2018-03-29 10:53:13 --> Output Class Initialized
INFO - 2018-03-29 10:53:13 --> Security Class Initialized
DEBUG - 2018-03-29 10:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 10:53:13 --> Input Class Initialized
INFO - 2018-03-29 10:53:13 --> Language Class Initialized
INFO - 2018-03-29 10:53:13 --> Language Class Initialized
INFO - 2018-03-29 10:53:13 --> Config Class Initialized
INFO - 2018-03-29 10:53:13 --> Loader Class Initialized
INFO - 2018-03-29 16:23:13 --> Helper loaded: url_helper
INFO - 2018-03-29 16:23:13 --> Helper loaded: notification_helper
INFO - 2018-03-29 16:23:13 --> Helper loaded: settings_helper
INFO - 2018-03-29 16:23:13 --> Helper loaded: permission_helper
INFO - 2018-03-29 16:23:13 --> Helper loaded: users_helper
INFO - 2018-03-29 16:23:13 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:23:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:23:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:23:13 --> Helper loaded: form_helper
INFO - 2018-03-29 16:23:13 --> Form Validation Class Initialized
INFO - 2018-03-29 16:23:13 --> Controller Class Initialized
INFO - 2018-03-29 16:23:13 --> Model Class Initialized
INFO - 2018-03-29 16:23:13 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 16:23:13 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 16:23:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 16:23:13 --> Model Class Initialized
INFO - 2018-03-29 16:23:13 --> Model Class Initialized
INFO - 2018-03-29 16:23:13 --> Model Class Initialized
INFO - 2018-03-29 16:23:13 --> Model Class Initialized
INFO - 2018-03-29 16:23:13 --> Model Class Initialized
INFO - 2018-03-29 16:23:13 --> Model Class Initialized
INFO - 2018-03-29 16:23:13 --> Model Class Initialized
INFO - 2018-03-29 16:23:13 --> Model Class Initialized
INFO - 2018-03-29 16:23:13 --> Model Class Initialized
INFO - 2018-03-29 16:23:13 --> Model Class Initialized
INFO - 2018-03-29 16:23:13 --> Model Class Initialized
INFO - 2018-03-29 16:23:13 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 16:23:13 --> Model Class Initialized
INFO - 2018-03-29 16:23:13 --> Final output sent to browser
DEBUG - 2018-03-29 16:23:13 --> Total execution time: 0.2489
INFO - 2018-03-29 10:53:14 --> Config Class Initialized
INFO - 2018-03-29 10:53:14 --> Hooks Class Initialized
DEBUG - 2018-03-29 10:53:14 --> UTF-8 Support Enabled
INFO - 2018-03-29 10:53:14 --> Utf8 Class Initialized
INFO - 2018-03-29 10:53:14 --> URI Class Initialized
INFO - 2018-03-29 10:53:14 --> Router Class Initialized
INFO - 2018-03-29 10:53:15 --> Output Class Initialized
INFO - 2018-03-29 10:53:15 --> Security Class Initialized
DEBUG - 2018-03-29 10:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 10:53:15 --> Input Class Initialized
INFO - 2018-03-29 10:53:15 --> Language Class Initialized
INFO - 2018-03-29 10:53:16 --> Language Class Initialized
INFO - 2018-03-29 10:53:16 --> Config Class Initialized
INFO - 2018-03-29 10:53:16 --> Loader Class Initialized
INFO - 2018-03-29 16:23:16 --> Helper loaded: url_helper
INFO - 2018-03-29 16:23:16 --> Helper loaded: notification_helper
INFO - 2018-03-29 16:23:16 --> Helper loaded: settings_helper
INFO - 2018-03-29 16:23:16 --> Helper loaded: permission_helper
INFO - 2018-03-29 10:53:16 --> Config Class Initialized
INFO - 2018-03-29 10:53:16 --> Hooks Class Initialized
DEBUG - 2018-03-29 10:53:16 --> UTF-8 Support Enabled
INFO - 2018-03-29 10:53:16 --> Utf8 Class Initialized
INFO - 2018-03-29 10:53:16 --> URI Class Initialized
INFO - 2018-03-29 10:53:16 --> Router Class Initialized
INFO - 2018-03-29 10:53:16 --> Output Class Initialized
INFO - 2018-03-29 10:53:16 --> Security Class Initialized
DEBUG - 2018-03-29 10:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 10:53:16 --> Input Class Initialized
INFO - 2018-03-29 10:53:16 --> Language Class Initialized
INFO - 2018-03-29 16:23:16 --> Helper loaded: users_helper
INFO - 2018-03-29 10:53:16 --> Language Class Initialized
INFO - 2018-03-29 10:53:16 --> Config Class Initialized
INFO - 2018-03-29 10:53:16 --> Loader Class Initialized
INFO - 2018-03-29 16:23:16 --> Helper loaded: url_helper
INFO - 2018-03-29 16:23:16 --> Helper loaded: notification_helper
INFO - 2018-03-29 16:23:16 --> Helper loaded: settings_helper
INFO - 2018-03-29 16:23:16 --> Helper loaded: permission_helper
INFO - 2018-03-29 16:23:16 --> Helper loaded: users_helper
INFO - 2018-03-29 16:23:16 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:23:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:23:16 --> Helper loaded: form_helper
INFO - 2018-03-29 16:23:16 --> Form Validation Class Initialized
INFO - 2018-03-29 16:23:16 --> Controller Class Initialized
INFO - 2018-03-29 16:23:16 --> Model Class Initialized
INFO - 2018-03-29 16:23:16 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 16:23:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 16:23:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 16:23:16 --> Model Class Initialized
INFO - 2018-03-29 16:23:16 --> Model Class Initialized
INFO - 2018-03-29 16:23:16 --> Model Class Initialized
INFO - 2018-03-29 16:23:16 --> Model Class Initialized
INFO - 2018-03-29 16:23:16 --> Model Class Initialized
INFO - 2018-03-29 16:23:16 --> Model Class Initialized
INFO - 2018-03-29 16:23:16 --> Model Class Initialized
INFO - 2018-03-29 16:23:16 --> Model Class Initialized
INFO - 2018-03-29 16:23:16 --> Model Class Initialized
INFO - 2018-03-29 16:23:16 --> Model Class Initialized
INFO - 2018-03-29 16:23:16 --> Model Class Initialized
INFO - 2018-03-29 16:23:16 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 16:23:16 --> Model Class Initialized
INFO - 2018-03-29 16:23:16 --> Final output sent to browser
DEBUG - 2018-03-29 16:23:16 --> Total execution time: 0.1214
INFO - 2018-03-29 16:23:16 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:23:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:23:16 --> Helper loaded: form_helper
INFO - 2018-03-29 16:23:16 --> Form Validation Class Initialized
INFO - 2018-03-29 16:23:16 --> Controller Class Initialized
INFO - 2018-03-29 16:23:16 --> Model Class Initialized
INFO - 2018-03-29 16:23:16 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 16:23:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 16:23:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 16:23:16 --> Model Class Initialized
INFO - 2018-03-29 16:23:16 --> Model Class Initialized
INFO - 2018-03-29 16:23:16 --> Model Class Initialized
INFO - 2018-03-29 16:23:16 --> Model Class Initialized
INFO - 2018-03-29 16:23:16 --> Model Class Initialized
INFO - 2018-03-29 16:23:16 --> Model Class Initialized
INFO - 2018-03-29 16:23:16 --> Model Class Initialized
INFO - 2018-03-29 16:23:16 --> Model Class Initialized
INFO - 2018-03-29 16:23:16 --> Model Class Initialized
INFO - 2018-03-29 16:23:16 --> Model Class Initialized
INFO - 2018-03-29 16:23:16 --> Model Class Initialized
INFO - 2018-03-29 16:23:16 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 16:23:16 --> Model Class Initialized
INFO - 2018-03-29 16:23:16 --> Final output sent to browser
DEBUG - 2018-03-29 16:23:16 --> Total execution time: 2.4373
INFO - 2018-03-29 10:53:18 --> Config Class Initialized
INFO - 2018-03-29 10:53:18 --> Hooks Class Initialized
DEBUG - 2018-03-29 10:53:18 --> UTF-8 Support Enabled
INFO - 2018-03-29 10:53:18 --> Utf8 Class Initialized
INFO - 2018-03-29 10:53:18 --> URI Class Initialized
INFO - 2018-03-29 10:53:18 --> Router Class Initialized
INFO - 2018-03-29 10:53:18 --> Output Class Initialized
INFO - 2018-03-29 10:53:18 --> Security Class Initialized
DEBUG - 2018-03-29 10:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 10:53:18 --> Input Class Initialized
INFO - 2018-03-29 10:53:18 --> Language Class Initialized
INFO - 2018-03-29 10:53:18 --> Language Class Initialized
INFO - 2018-03-29 10:53:18 --> Config Class Initialized
INFO - 2018-03-29 10:53:18 --> Loader Class Initialized
INFO - 2018-03-29 16:23:18 --> Helper loaded: url_helper
INFO - 2018-03-29 16:23:18 --> Helper loaded: notification_helper
INFO - 2018-03-29 16:23:18 --> Helper loaded: settings_helper
INFO - 2018-03-29 16:23:18 --> Helper loaded: permission_helper
INFO - 2018-03-29 16:23:18 --> Helper loaded: users_helper
INFO - 2018-03-29 16:23:18 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:23:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:23:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:23:18 --> Helper loaded: form_helper
INFO - 2018-03-29 16:23:18 --> Form Validation Class Initialized
INFO - 2018-03-29 16:23:18 --> Controller Class Initialized
INFO - 2018-03-29 16:23:18 --> Model Class Initialized
INFO - 2018-03-29 16:23:18 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 16:23:18 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 16:23:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 16:23:18 --> Model Class Initialized
INFO - 2018-03-29 16:23:18 --> Model Class Initialized
INFO - 2018-03-29 16:23:18 --> Model Class Initialized
INFO - 2018-03-29 16:23:18 --> Model Class Initialized
INFO - 2018-03-29 16:23:18 --> Model Class Initialized
INFO - 2018-03-29 16:23:18 --> Model Class Initialized
INFO - 2018-03-29 16:23:18 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-29 16:23:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-03-29 16:23:18 --> Final output sent to browser
DEBUG - 2018-03-29 16:23:18 --> Total execution time: 0.4967
INFO - 2018-03-29 10:53:20 --> Config Class Initialized
INFO - 2018-03-29 10:53:20 --> Hooks Class Initialized
DEBUG - 2018-03-29 10:53:20 --> UTF-8 Support Enabled
INFO - 2018-03-29 10:53:20 --> Utf8 Class Initialized
INFO - 2018-03-29 10:53:20 --> Config Class Initialized
INFO - 2018-03-29 10:53:20 --> Hooks Class Initialized
DEBUG - 2018-03-29 10:53:20 --> UTF-8 Support Enabled
INFO - 2018-03-29 10:53:20 --> Utf8 Class Initialized
INFO - 2018-03-29 10:53:20 --> URI Class Initialized
INFO - 2018-03-29 10:53:20 --> URI Class Initialized
INFO - 2018-03-29 10:53:20 --> Router Class Initialized
INFO - 2018-03-29 10:53:20 --> Output Class Initialized
INFO - 2018-03-29 10:53:20 --> Security Class Initialized
DEBUG - 2018-03-29 10:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 10:53:20 --> Input Class Initialized
INFO - 2018-03-29 10:53:20 --> Language Class Initialized
INFO - 2018-03-29 10:53:20 --> Language Class Initialized
INFO - 2018-03-29 10:53:20 --> Config Class Initialized
INFO - 2018-03-29 10:53:20 --> Loader Class Initialized
INFO - 2018-03-29 16:23:20 --> Helper loaded: url_helper
INFO - 2018-03-29 16:23:20 --> Helper loaded: notification_helper
INFO - 2018-03-29 16:23:20 --> Helper loaded: settings_helper
INFO - 2018-03-29 16:23:20 --> Helper loaded: permission_helper
INFO - 2018-03-29 16:23:20 --> Helper loaded: users_helper
INFO - 2018-03-29 10:53:20 --> Router Class Initialized
INFO - 2018-03-29 16:23:20 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:23:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 10:53:20 --> Output Class Initialized
INFO - 2018-03-29 10:53:20 --> Security Class Initialized
INFO - 2018-03-29 16:23:21 --> Helper loaded: form_helper
INFO - 2018-03-29 16:23:21 --> Form Validation Class Initialized
INFO - 2018-03-29 16:23:21 --> Controller Class Initialized
DEBUG - 2018-03-29 10:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:23:21 --> Model Class Initialized
INFO - 2018-03-29 10:53:21 --> Input Class Initialized
INFO - 2018-03-29 16:23:21 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 16:23:21 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 16:23:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 10:53:21 --> Language Class Initialized
INFO - 2018-03-29 16:23:21 --> Model Class Initialized
INFO - 2018-03-29 16:23:21 --> Model Class Initialized
INFO - 2018-03-29 16:23:21 --> Model Class Initialized
INFO - 2018-03-29 16:23:21 --> Model Class Initialized
INFO - 2018-03-29 16:23:21 --> Model Class Initialized
INFO - 2018-03-29 16:23:21 --> Model Class Initialized
INFO - 2018-03-29 16:23:21 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-29 16:23:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-03-29 16:23:21 --> Final output sent to browser
DEBUG - 2018-03-29 16:23:21 --> Total execution time: 0.6823
INFO - 2018-03-29 10:53:21 --> Language Class Initialized
INFO - 2018-03-29 10:53:21 --> Config Class Initialized
INFO - 2018-03-29 10:53:21 --> Loader Class Initialized
INFO - 2018-03-29 16:23:21 --> Helper loaded: url_helper
INFO - 2018-03-29 16:23:21 --> Helper loaded: notification_helper
INFO - 2018-03-29 16:23:21 --> Helper loaded: settings_helper
INFO - 2018-03-29 16:23:21 --> Helper loaded: permission_helper
INFO - 2018-03-29 16:23:21 --> Helper loaded: users_helper
INFO - 2018-03-29 16:23:22 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:23:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:23:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:23:22 --> Helper loaded: form_helper
INFO - 2018-03-29 16:23:22 --> Form Validation Class Initialized
INFO - 2018-03-29 16:23:22 --> Controller Class Initialized
INFO - 2018-03-29 16:23:22 --> Model Class Initialized
INFO - 2018-03-29 16:23:22 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 16:23:22 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 16:23:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 16:23:22 --> Model Class Initialized
INFO - 2018-03-29 16:23:22 --> Model Class Initialized
INFO - 2018-03-29 16:23:22 --> Model Class Initialized
INFO - 2018-03-29 16:23:22 --> Model Class Initialized
INFO - 2018-03-29 16:23:22 --> Model Class Initialized
INFO - 2018-03-29 16:23:22 --> Model Class Initialized
INFO - 2018-03-29 16:23:22 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-29 16:23:22 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-03-29 16:23:22 --> Final output sent to browser
DEBUG - 2018-03-29 16:23:22 --> Total execution time: 2.8323
INFO - 2018-03-29 10:55:02 --> Config Class Initialized
INFO - 2018-03-29 10:55:02 --> Hooks Class Initialized
DEBUG - 2018-03-29 10:55:02 --> UTF-8 Support Enabled
INFO - 2018-03-29 10:55:02 --> Utf8 Class Initialized
INFO - 2018-03-29 10:55:02 --> URI Class Initialized
INFO - 2018-03-29 10:55:02 --> Router Class Initialized
INFO - 2018-03-29 10:55:02 --> Output Class Initialized
INFO - 2018-03-29 10:55:02 --> Security Class Initialized
DEBUG - 2018-03-29 10:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 10:55:02 --> Input Class Initialized
INFO - 2018-03-29 10:55:02 --> Language Class Initialized
INFO - 2018-03-29 10:55:02 --> Language Class Initialized
INFO - 2018-03-29 10:55:02 --> Config Class Initialized
INFO - 2018-03-29 10:55:02 --> Loader Class Initialized
INFO - 2018-03-29 16:25:02 --> Helper loaded: url_helper
INFO - 2018-03-29 16:25:02 --> Helper loaded: notification_helper
INFO - 2018-03-29 16:25:02 --> Helper loaded: settings_helper
INFO - 2018-03-29 16:25:02 --> Helper loaded: permission_helper
INFO - 2018-03-29 16:25:02 --> Helper loaded: users_helper
INFO - 2018-03-29 16:25:02 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:25:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:25:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:25:02 --> Helper loaded: form_helper
INFO - 2018-03-29 16:25:02 --> Form Validation Class Initialized
INFO - 2018-03-29 16:25:02 --> Controller Class Initialized
INFO - 2018-03-29 16:25:02 --> Model Class Initialized
INFO - 2018-03-29 16:25:02 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 16:25:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 16:25:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 16:25:02 --> Model Class Initialized
INFO - 2018-03-29 16:25:02 --> Model Class Initialized
INFO - 2018-03-29 16:25:02 --> Model Class Initialized
INFO - 2018-03-29 16:25:02 --> Model Class Initialized
INFO - 2018-03-29 16:25:02 --> Model Class Initialized
INFO - 2018-03-29 16:25:02 --> Model Class Initialized
INFO - 2018-03-29 16:25:02 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 16:25:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-29 16:25:02 --> Final output sent to browser
DEBUG - 2018-03-29 16:25:02 --> Total execution time: 0.1173
INFO - 2018-03-29 10:55:03 --> Config Class Initialized
INFO - 2018-03-29 10:55:03 --> Hooks Class Initialized
DEBUG - 2018-03-29 10:55:03 --> UTF-8 Support Enabled
INFO - 2018-03-29 10:55:03 --> Utf8 Class Initialized
INFO - 2018-03-29 10:55:03 --> URI Class Initialized
INFO - 2018-03-29 10:55:03 --> Router Class Initialized
INFO - 2018-03-29 10:55:03 --> Output Class Initialized
INFO - 2018-03-29 10:55:03 --> Security Class Initialized
DEBUG - 2018-03-29 10:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 10:55:03 --> Input Class Initialized
INFO - 2018-03-29 10:55:03 --> Language Class Initialized
INFO - 2018-03-29 10:55:03 --> Language Class Initialized
INFO - 2018-03-29 10:55:03 --> Config Class Initialized
INFO - 2018-03-29 10:55:03 --> Loader Class Initialized
INFO - 2018-03-29 16:25:03 --> Helper loaded: url_helper
INFO - 2018-03-29 16:25:03 --> Helper loaded: notification_helper
INFO - 2018-03-29 16:25:03 --> Helper loaded: settings_helper
INFO - 2018-03-29 16:25:03 --> Helper loaded: permission_helper
INFO - 2018-03-29 16:25:03 --> Helper loaded: users_helper
INFO - 2018-03-29 16:25:03 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:25:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:25:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:25:03 --> Helper loaded: form_helper
INFO - 2018-03-29 16:25:03 --> Form Validation Class Initialized
INFO - 2018-03-29 16:25:03 --> Controller Class Initialized
INFO - 2018-03-29 16:25:03 --> Model Class Initialized
INFO - 2018-03-29 16:25:03 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 16:25:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 16:25:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 16:25:03 --> Model Class Initialized
INFO - 2018-03-29 16:25:03 --> Model Class Initialized
INFO - 2018-03-29 16:25:03 --> Model Class Initialized
INFO - 2018-03-29 16:25:03 --> Model Class Initialized
INFO - 2018-03-29 16:25:03 --> Model Class Initialized
INFO - 2018-03-29 16:25:03 --> Model Class Initialized
INFO - 2018-03-29 16:25:03 --> Model Class Initialized
INFO - 2018-03-29 16:25:03 --> Model Class Initialized
INFO - 2018-03-29 16:25:03 --> Model Class Initialized
INFO - 2018-03-29 16:25:03 --> Model Class Initialized
INFO - 2018-03-29 16:25:03 --> Model Class Initialized
INFO - 2018-03-29 16:25:03 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 16:25:03 --> Model Class Initialized
INFO - 2018-03-29 16:25:03 --> Final output sent to browser
DEBUG - 2018-03-29 16:25:03 --> Total execution time: 0.1394
INFO - 2018-03-29 10:55:03 --> Config Class Initialized
INFO - 2018-03-29 10:55:03 --> Hooks Class Initialized
DEBUG - 2018-03-29 10:55:03 --> UTF-8 Support Enabled
INFO - 2018-03-29 10:55:03 --> Utf8 Class Initialized
INFO - 2018-03-29 10:55:03 --> URI Class Initialized
INFO - 2018-03-29 10:55:03 --> Router Class Initialized
INFO - 2018-03-29 10:55:03 --> Output Class Initialized
INFO - 2018-03-29 10:55:03 --> Security Class Initialized
DEBUG - 2018-03-29 10:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 10:55:03 --> Input Class Initialized
INFO - 2018-03-29 10:55:03 --> Language Class Initialized
INFO - 2018-03-29 10:55:03 --> Language Class Initialized
INFO - 2018-03-29 10:55:03 --> Config Class Initialized
INFO - 2018-03-29 10:55:03 --> Loader Class Initialized
INFO - 2018-03-29 16:25:03 --> Helper loaded: url_helper
INFO - 2018-03-29 16:25:03 --> Helper loaded: notification_helper
INFO - 2018-03-29 16:25:03 --> Helper loaded: settings_helper
INFO - 2018-03-29 16:25:03 --> Helper loaded: permission_helper
INFO - 2018-03-29 16:25:03 --> Helper loaded: users_helper
INFO - 2018-03-29 16:25:03 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:25:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:25:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:25:03 --> Helper loaded: form_helper
INFO - 2018-03-29 16:25:03 --> Form Validation Class Initialized
INFO - 2018-03-29 16:25:03 --> Controller Class Initialized
INFO - 2018-03-29 16:25:03 --> Model Class Initialized
INFO - 2018-03-29 16:25:03 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 16:25:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 16:25:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 16:25:03 --> Model Class Initialized
INFO - 2018-03-29 16:25:03 --> Model Class Initialized
INFO - 2018-03-29 16:25:03 --> Model Class Initialized
INFO - 2018-03-29 16:25:03 --> Model Class Initialized
INFO - 2018-03-29 16:25:03 --> Model Class Initialized
INFO - 2018-03-29 16:25:03 --> Model Class Initialized
INFO - 2018-03-29 16:25:03 --> Model Class Initialized
INFO - 2018-03-29 16:25:03 --> Model Class Initialized
INFO - 2018-03-29 16:25:03 --> Model Class Initialized
INFO - 2018-03-29 16:25:03 --> Model Class Initialized
INFO - 2018-03-29 16:25:03 --> Model Class Initialized
INFO - 2018-03-29 16:25:03 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 16:25:03 --> Model Class Initialized
INFO - 2018-03-29 16:25:03 --> Final output sent to browser
DEBUG - 2018-03-29 16:25:03 --> Total execution time: 0.1390
INFO - 2018-03-29 10:55:07 --> Config Class Initialized
INFO - 2018-03-29 10:55:07 --> Config Class Initialized
INFO - 2018-03-29 10:55:07 --> Hooks Class Initialized
INFO - 2018-03-29 10:55:07 --> Hooks Class Initialized
DEBUG - 2018-03-29 10:55:07 --> UTF-8 Support Enabled
DEBUG - 2018-03-29 10:55:07 --> UTF-8 Support Enabled
INFO - 2018-03-29 10:55:07 --> Utf8 Class Initialized
INFO - 2018-03-29 10:55:07 --> Utf8 Class Initialized
INFO - 2018-03-29 10:55:07 --> URI Class Initialized
INFO - 2018-03-29 10:55:07 --> URI Class Initialized
INFO - 2018-03-29 10:55:07 --> Router Class Initialized
INFO - 2018-03-29 10:55:07 --> Router Class Initialized
INFO - 2018-03-29 10:55:07 --> Output Class Initialized
INFO - 2018-03-29 10:55:07 --> Output Class Initialized
INFO - 2018-03-29 10:55:07 --> Security Class Initialized
INFO - 2018-03-29 10:55:08 --> Security Class Initialized
DEBUG - 2018-03-29 10:55:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-29 10:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 10:55:08 --> Input Class Initialized
INFO - 2018-03-29 10:55:08 --> Input Class Initialized
INFO - 2018-03-29 10:55:08 --> Language Class Initialized
INFO - 2018-03-29 10:55:08 --> Language Class Initialized
INFO - 2018-03-29 10:55:08 --> Language Class Initialized
INFO - 2018-03-29 10:55:08 --> Language Class Initialized
INFO - 2018-03-29 10:55:08 --> Config Class Initialized
INFO - 2018-03-29 10:55:08 --> Config Class Initialized
INFO - 2018-03-29 10:55:08 --> Loader Class Initialized
INFO - 2018-03-29 10:55:08 --> Loader Class Initialized
INFO - 2018-03-29 16:25:08 --> Helper loaded: url_helper
INFO - 2018-03-29 16:25:08 --> Helper loaded: url_helper
INFO - 2018-03-29 16:25:08 --> Helper loaded: notification_helper
INFO - 2018-03-29 16:25:08 --> Helper loaded: notification_helper
INFO - 2018-03-29 16:25:08 --> Helper loaded: settings_helper
INFO - 2018-03-29 16:25:08 --> Helper loaded: settings_helper
INFO - 2018-03-29 16:25:08 --> Helper loaded: permission_helper
INFO - 2018-03-29 16:25:08 --> Helper loaded: permission_helper
INFO - 2018-03-29 16:25:08 --> Helper loaded: users_helper
INFO - 2018-03-29 16:25:08 --> Helper loaded: users_helper
INFO - 2018-03-29 16:25:08 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:25:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:25:08 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:25:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:25:08 --> Helper loaded: form_helper
INFO - 2018-03-29 16:25:08 --> Form Validation Class Initialized
INFO - 2018-03-29 16:25:08 --> Controller Class Initialized
INFO - 2018-03-29 16:25:08 --> Helper loaded: form_helper
INFO - 2018-03-29 16:25:08 --> Form Validation Class Initialized
INFO - 2018-03-29 16:25:08 --> Controller Class Initialized
INFO - 2018-03-29 16:25:08 --> Model Class Initialized
INFO - 2018-03-29 16:25:08 --> Helper loaded: inflector_helper
INFO - 2018-03-29 16:25:08 --> Model Class Initialized
DEBUG - 2018-03-29 16:25:08 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 16:25:08 --> Helper loaded: inflector_helper
INFO - 2018-03-29 16:25:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 16:25:08 --> Model Class Initialized
INFO - 2018-03-29 16:25:08 --> Model Class Initialized
DEBUG - 2018-03-29 16:25:08 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 16:25:08 --> Model Class Initialized
INFO - 2018-03-29 16:25:08 --> Model Class Initialized
INFO - 2018-03-29 16:25:08 --> Model Class Initialized
INFO - 2018-03-29 16:25:08 --> Model Class Initialized
INFO - 2018-03-29 16:25:08 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 16:25:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 16:25:08 --> Model Class Initialized
INFO - 2018-03-29 16:25:08 --> Model Class Initialized
ERROR - 2018-03-29 16:25:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 556
INFO - 2018-03-29 16:25:08 --> Model Class Initialized
INFO - 2018-03-29 16:25:08 --> Model Class Initialized
INFO - 2018-03-29 16:25:08 --> Model Class Initialized
INFO - 2018-03-29 16:25:08 --> Final output sent to browser
DEBUG - 2018-03-29 16:25:08 --> Total execution time: 0.3603
INFO - 2018-03-29 16:25:08 --> Model Class Initialized
INFO - 2018-03-29 16:25:08 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-29 16:25:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-03-29 16:25:08 --> Final output sent to browser
DEBUG - 2018-03-29 16:25:08 --> Total execution time: 0.3679
INFO - 2018-03-29 10:56:15 --> Config Class Initialized
INFO - 2018-03-29 10:56:15 --> Hooks Class Initialized
DEBUG - 2018-03-29 10:56:15 --> UTF-8 Support Enabled
INFO - 2018-03-29 10:56:15 --> Utf8 Class Initialized
INFO - 2018-03-29 10:56:15 --> URI Class Initialized
INFO - 2018-03-29 10:56:15 --> Router Class Initialized
INFO - 2018-03-29 10:56:15 --> Output Class Initialized
INFO - 2018-03-29 10:56:15 --> Security Class Initialized
DEBUG - 2018-03-29 10:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 10:56:15 --> Input Class Initialized
INFO - 2018-03-29 10:56:15 --> Language Class Initialized
INFO - 2018-03-29 10:56:15 --> Language Class Initialized
INFO - 2018-03-29 10:56:15 --> Config Class Initialized
INFO - 2018-03-29 10:56:15 --> Loader Class Initialized
INFO - 2018-03-29 16:26:15 --> Helper loaded: url_helper
INFO - 2018-03-29 16:26:15 --> Helper loaded: notification_helper
INFO - 2018-03-29 16:26:15 --> Helper loaded: settings_helper
INFO - 2018-03-29 16:26:15 --> Helper loaded: permission_helper
INFO - 2018-03-29 16:26:15 --> Helper loaded: users_helper
INFO - 2018-03-29 16:26:15 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:26:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:26:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:26:15 --> Helper loaded: form_helper
INFO - 2018-03-29 16:26:15 --> Form Validation Class Initialized
INFO - 2018-03-29 16:26:15 --> Controller Class Initialized
INFO - 2018-03-29 16:26:15 --> Model Class Initialized
INFO - 2018-03-29 16:26:15 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 16:26:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 16:26:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 16:26:15 --> Model Class Initialized
INFO - 2018-03-29 16:26:15 --> Model Class Initialized
INFO - 2018-03-29 16:26:15 --> Model Class Initialized
INFO - 2018-03-29 16:26:15 --> Model Class Initialized
INFO - 2018-03-29 16:26:15 --> Model Class Initialized
INFO - 2018-03-29 16:26:15 --> Model Class Initialized
INFO - 2018-03-29 16:26:15 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 16:26:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-29 16:26:15 --> Final output sent to browser
DEBUG - 2018-03-29 16:26:15 --> Total execution time: 0.1762
INFO - 2018-03-29 10:56:16 --> Config Class Initialized
INFO - 2018-03-29 10:56:16 --> Hooks Class Initialized
DEBUG - 2018-03-29 10:56:16 --> UTF-8 Support Enabled
INFO - 2018-03-29 10:56:16 --> Utf8 Class Initialized
INFO - 2018-03-29 10:56:16 --> URI Class Initialized
INFO - 2018-03-29 10:56:16 --> Router Class Initialized
INFO - 2018-03-29 10:56:16 --> Output Class Initialized
INFO - 2018-03-29 10:56:16 --> Security Class Initialized
DEBUG - 2018-03-29 10:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 10:56:16 --> Input Class Initialized
INFO - 2018-03-29 10:56:16 --> Language Class Initialized
INFO - 2018-03-29 10:56:16 --> Language Class Initialized
INFO - 2018-03-29 10:56:16 --> Config Class Initialized
INFO - 2018-03-29 10:56:16 --> Loader Class Initialized
INFO - 2018-03-29 16:26:16 --> Helper loaded: url_helper
INFO - 2018-03-29 16:26:16 --> Helper loaded: notification_helper
INFO - 2018-03-29 16:26:16 --> Helper loaded: settings_helper
INFO - 2018-03-29 16:26:16 --> Helper loaded: permission_helper
INFO - 2018-03-29 16:26:16 --> Helper loaded: users_helper
INFO - 2018-03-29 16:26:16 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:26:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:26:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:26:16 --> Helper loaded: form_helper
INFO - 2018-03-29 16:26:16 --> Form Validation Class Initialized
INFO - 2018-03-29 16:26:16 --> Controller Class Initialized
INFO - 2018-03-29 16:26:16 --> Model Class Initialized
INFO - 2018-03-29 16:26:16 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 16:26:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 16:26:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 16:26:16 --> Model Class Initialized
INFO - 2018-03-29 16:26:16 --> Model Class Initialized
INFO - 2018-03-29 16:26:16 --> Model Class Initialized
INFO - 2018-03-29 16:26:16 --> Model Class Initialized
INFO - 2018-03-29 16:26:16 --> Model Class Initialized
INFO - 2018-03-29 16:26:16 --> Model Class Initialized
INFO - 2018-03-29 16:26:16 --> Model Class Initialized
INFO - 2018-03-29 16:26:16 --> Model Class Initialized
INFO - 2018-03-29 16:26:16 --> Model Class Initialized
INFO - 2018-03-29 16:26:16 --> Model Class Initialized
INFO - 2018-03-29 16:26:16 --> Model Class Initialized
INFO - 2018-03-29 16:26:16 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 16:26:16 --> Model Class Initialized
INFO - 2018-03-29 16:26:16 --> Final output sent to browser
DEBUG - 2018-03-29 16:26:16 --> Total execution time: 0.1215
INFO - 2018-03-29 10:56:16 --> Config Class Initialized
INFO - 2018-03-29 10:56:16 --> Hooks Class Initialized
DEBUG - 2018-03-29 10:56:16 --> UTF-8 Support Enabled
INFO - 2018-03-29 10:56:16 --> Utf8 Class Initialized
INFO - 2018-03-29 10:56:16 --> URI Class Initialized
INFO - 2018-03-29 10:56:16 --> Router Class Initialized
INFO - 2018-03-29 10:56:17 --> Output Class Initialized
INFO - 2018-03-29 10:56:17 --> Security Class Initialized
DEBUG - 2018-03-29 10:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 10:56:17 --> Input Class Initialized
INFO - 2018-03-29 10:56:17 --> Language Class Initialized
INFO - 2018-03-29 10:56:17 --> Language Class Initialized
INFO - 2018-03-29 10:56:17 --> Config Class Initialized
INFO - 2018-03-29 10:56:17 --> Loader Class Initialized
INFO - 2018-03-29 16:26:17 --> Helper loaded: url_helper
INFO - 2018-03-29 16:26:17 --> Helper loaded: notification_helper
INFO - 2018-03-29 16:26:17 --> Helper loaded: settings_helper
INFO - 2018-03-29 16:26:17 --> Helper loaded: permission_helper
INFO - 2018-03-29 16:26:17 --> Helper loaded: users_helper
INFO - 2018-03-29 16:26:17 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:26:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:26:17 --> Helper loaded: form_helper
INFO - 2018-03-29 16:26:17 --> Form Validation Class Initialized
INFO - 2018-03-29 16:26:17 --> Controller Class Initialized
INFO - 2018-03-29 16:26:17 --> Model Class Initialized
INFO - 2018-03-29 16:26:17 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 16:26:17 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 16:26:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 16:26:17 --> Model Class Initialized
INFO - 2018-03-29 16:26:17 --> Model Class Initialized
INFO - 2018-03-29 16:26:17 --> Model Class Initialized
INFO - 2018-03-29 16:26:17 --> Model Class Initialized
INFO - 2018-03-29 16:26:17 --> Model Class Initialized
INFO - 2018-03-29 16:26:17 --> Model Class Initialized
INFO - 2018-03-29 16:26:17 --> Model Class Initialized
INFO - 2018-03-29 16:26:17 --> Model Class Initialized
INFO - 2018-03-29 16:26:17 --> Model Class Initialized
INFO - 2018-03-29 16:26:17 --> Model Class Initialized
INFO - 2018-03-29 16:26:17 --> Model Class Initialized
INFO - 2018-03-29 16:26:17 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 16:26:17 --> Model Class Initialized
INFO - 2018-03-29 16:26:17 --> Final output sent to browser
DEBUG - 2018-03-29 16:26:17 --> Total execution time: 0.5630
INFO - 2018-03-29 10:56:20 --> Config Class Initialized
INFO - 2018-03-29 10:56:20 --> Hooks Class Initialized
DEBUG - 2018-03-29 10:56:20 --> UTF-8 Support Enabled
INFO - 2018-03-29 10:56:20 --> Utf8 Class Initialized
INFO - 2018-03-29 10:56:20 --> URI Class Initialized
INFO - 2018-03-29 10:56:20 --> Router Class Initialized
INFO - 2018-03-29 10:56:20 --> Output Class Initialized
INFO - 2018-03-29 10:56:20 --> Security Class Initialized
DEBUG - 2018-03-29 10:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 10:56:20 --> Input Class Initialized
INFO - 2018-03-29 10:56:20 --> Language Class Initialized
INFO - 2018-03-29 10:56:20 --> Config Class Initialized
INFO - 2018-03-29 10:56:20 --> Hooks Class Initialized
DEBUG - 2018-03-29 10:56:20 --> UTF-8 Support Enabled
INFO - 2018-03-29 10:56:20 --> Utf8 Class Initialized
INFO - 2018-03-29 10:56:20 --> URI Class Initialized
INFO - 2018-03-29 10:56:20 --> Router Class Initialized
INFO - 2018-03-29 10:56:20 --> Output Class Initialized
INFO - 2018-03-29 10:56:20 --> Security Class Initialized
DEBUG - 2018-03-29 10:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 10:56:20 --> Input Class Initialized
INFO - 2018-03-29 10:56:20 --> Language Class Initialized
INFO - 2018-03-29 10:56:20 --> Language Class Initialized
INFO - 2018-03-29 10:56:20 --> Config Class Initialized
INFO - 2018-03-29 10:56:20 --> Loader Class Initialized
INFO - 2018-03-29 10:56:20 --> Language Class Initialized
INFO - 2018-03-29 10:56:20 --> Config Class Initialized
INFO - 2018-03-29 10:56:20 --> Loader Class Initialized
INFO - 2018-03-29 16:26:20 --> Helper loaded: url_helper
INFO - 2018-03-29 16:26:20 --> Helper loaded: notification_helper
INFO - 2018-03-29 16:26:20 --> Helper loaded: settings_helper
INFO - 2018-03-29 16:26:20 --> Helper loaded: permission_helper
INFO - 2018-03-29 16:26:20 --> Helper loaded: users_helper
INFO - 2018-03-29 16:26:20 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:26:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:26:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:26:20 --> Helper loaded: form_helper
INFO - 2018-03-29 16:26:20 --> Form Validation Class Initialized
INFO - 2018-03-29 16:26:20 --> Controller Class Initialized
INFO - 2018-03-29 16:26:20 --> Helper loaded: url_helper
INFO - 2018-03-29 16:26:20 --> Model Class Initialized
INFO - 2018-03-29 16:26:20 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 16:26:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 16:26:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 16:26:20 --> Helper loaded: notification_helper
INFO - 2018-03-29 16:26:20 --> Model Class Initialized
INFO - 2018-03-29 16:26:20 --> Model Class Initialized
INFO - 2018-03-29 16:26:20 --> Model Class Initialized
INFO - 2018-03-29 16:26:20 --> Model Class Initialized
INFO - 2018-03-29 16:26:20 --> Model Class Initialized
INFO - 2018-03-29 16:26:20 --> Model Class Initialized
INFO - 2018-03-29 16:26:20 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 16:26:20 --> Final output sent to browser
DEBUG - 2018-03-29 16:26:20 --> Total execution time: 0.2170
INFO - 2018-03-29 16:26:20 --> Helper loaded: settings_helper
INFO - 2018-03-29 16:26:20 --> Helper loaded: permission_helper
INFO - 2018-03-29 16:26:20 --> Helper loaded: users_helper
INFO - 2018-03-29 16:26:20 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:26:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:26:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:26:21 --> Helper loaded: form_helper
INFO - 2018-03-29 16:26:21 --> Form Validation Class Initialized
INFO - 2018-03-29 16:26:21 --> Controller Class Initialized
INFO - 2018-03-29 16:26:21 --> Model Class Initialized
INFO - 2018-03-29 16:26:21 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 16:26:21 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 16:26:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 16:26:21 --> Model Class Initialized
INFO - 2018-03-29 16:26:21 --> Model Class Initialized
INFO - 2018-03-29 16:26:21 --> Model Class Initialized
INFO - 2018-03-29 16:26:21 --> Model Class Initialized
INFO - 2018-03-29 16:26:21 --> Model Class Initialized
INFO - 2018-03-29 16:26:21 --> Model Class Initialized
INFO - 2018-03-29 16:26:21 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 16:26:21 --> Final output sent to browser
DEBUG - 2018-03-29 16:26:21 --> Total execution time: 1.0029
INFO - 2018-03-29 10:59:55 --> Config Class Initialized
INFO - 2018-03-29 10:59:55 --> Hooks Class Initialized
DEBUG - 2018-03-29 10:59:55 --> UTF-8 Support Enabled
INFO - 2018-03-29 10:59:55 --> Utf8 Class Initialized
INFO - 2018-03-29 10:59:55 --> URI Class Initialized
INFO - 2018-03-29 10:59:55 --> Router Class Initialized
INFO - 2018-03-29 10:59:55 --> Output Class Initialized
INFO - 2018-03-29 10:59:55 --> Security Class Initialized
DEBUG - 2018-03-29 10:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 10:59:55 --> Input Class Initialized
INFO - 2018-03-29 10:59:55 --> Language Class Initialized
INFO - 2018-03-29 10:59:55 --> Language Class Initialized
INFO - 2018-03-29 10:59:55 --> Config Class Initialized
INFO - 2018-03-29 10:59:55 --> Loader Class Initialized
INFO - 2018-03-29 16:29:55 --> Helper loaded: url_helper
INFO - 2018-03-29 16:29:55 --> Helper loaded: notification_helper
INFO - 2018-03-29 16:29:55 --> Helper loaded: settings_helper
INFO - 2018-03-29 16:29:55 --> Helper loaded: permission_helper
INFO - 2018-03-29 16:29:55 --> Helper loaded: users_helper
INFO - 2018-03-29 16:29:55 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:29:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:29:56 --> Helper loaded: form_helper
INFO - 2018-03-29 16:29:56 --> Form Validation Class Initialized
INFO - 2018-03-29 16:29:56 --> Controller Class Initialized
INFO - 2018-03-29 16:29:56 --> Model Class Initialized
INFO - 2018-03-29 16:29:56 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 16:29:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 16:29:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 16:29:56 --> Model Class Initialized
INFO - 2018-03-29 16:29:56 --> Model Class Initialized
INFO - 2018-03-29 16:29:56 --> Model Class Initialized
INFO - 2018-03-29 16:29:56 --> Model Class Initialized
INFO - 2018-03-29 16:29:56 --> Model Class Initialized
INFO - 2018-03-29 16:29:56 --> Model Class Initialized
INFO - 2018-03-29 16:29:56 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 16:29:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-29 16:29:56 --> Final output sent to browser
DEBUG - 2018-03-29 16:29:56 --> Total execution time: 0.2541
INFO - 2018-03-29 10:59:57 --> Config Class Initialized
INFO - 2018-03-29 10:59:57 --> Hooks Class Initialized
DEBUG - 2018-03-29 10:59:57 --> UTF-8 Support Enabled
INFO - 2018-03-29 10:59:57 --> Utf8 Class Initialized
INFO - 2018-03-29 10:59:57 --> URI Class Initialized
INFO - 2018-03-29 10:59:57 --> Router Class Initialized
INFO - 2018-03-29 10:59:57 --> Output Class Initialized
INFO - 2018-03-29 10:59:57 --> Security Class Initialized
DEBUG - 2018-03-29 10:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 10:59:57 --> Input Class Initialized
INFO - 2018-03-29 10:59:57 --> Language Class Initialized
INFO - 2018-03-29 10:59:57 --> Language Class Initialized
INFO - 2018-03-29 10:59:57 --> Config Class Initialized
INFO - 2018-03-29 10:59:57 --> Loader Class Initialized
INFO - 2018-03-29 16:29:57 --> Helper loaded: url_helper
INFO - 2018-03-29 16:29:57 --> Helper loaded: notification_helper
INFO - 2018-03-29 16:29:57 --> Helper loaded: settings_helper
INFO - 2018-03-29 16:29:57 --> Helper loaded: permission_helper
INFO - 2018-03-29 16:29:57 --> Helper loaded: users_helper
INFO - 2018-03-29 16:29:57 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:29:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:29:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:29:57 --> Helper loaded: form_helper
INFO - 2018-03-29 16:29:57 --> Form Validation Class Initialized
INFO - 2018-03-29 16:29:57 --> Controller Class Initialized
INFO - 2018-03-29 16:29:57 --> Model Class Initialized
INFO - 2018-03-29 16:29:57 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 16:29:57 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 16:29:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 16:29:57 --> Model Class Initialized
INFO - 2018-03-29 16:29:57 --> Model Class Initialized
INFO - 2018-03-29 16:29:57 --> Model Class Initialized
INFO - 2018-03-29 16:29:57 --> Model Class Initialized
INFO - 2018-03-29 16:29:57 --> Model Class Initialized
INFO - 2018-03-29 16:29:57 --> Model Class Initialized
INFO - 2018-03-29 16:29:57 --> Model Class Initialized
INFO - 2018-03-29 16:29:57 --> Model Class Initialized
INFO - 2018-03-29 16:29:57 --> Model Class Initialized
INFO - 2018-03-29 16:29:57 --> Model Class Initialized
INFO - 2018-03-29 16:29:57 --> Model Class Initialized
INFO - 2018-03-29 16:29:57 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 16:29:57 --> Model Class Initialized
INFO - 2018-03-29 16:29:57 --> Final output sent to browser
DEBUG - 2018-03-29 16:29:57 --> Total execution time: 0.2694
INFO - 2018-03-29 10:59:57 --> Config Class Initialized
INFO - 2018-03-29 10:59:57 --> Hooks Class Initialized
DEBUG - 2018-03-29 10:59:57 --> UTF-8 Support Enabled
INFO - 2018-03-29 10:59:57 --> Utf8 Class Initialized
INFO - 2018-03-29 10:59:57 --> URI Class Initialized
INFO - 2018-03-29 10:59:57 --> Router Class Initialized
INFO - 2018-03-29 10:59:57 --> Output Class Initialized
INFO - 2018-03-29 10:59:57 --> Security Class Initialized
DEBUG - 2018-03-29 10:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 10:59:57 --> Input Class Initialized
INFO - 2018-03-29 10:59:57 --> Language Class Initialized
INFO - 2018-03-29 10:59:57 --> Language Class Initialized
INFO - 2018-03-29 10:59:57 --> Config Class Initialized
INFO - 2018-03-29 10:59:57 --> Loader Class Initialized
INFO - 2018-03-29 16:29:57 --> Helper loaded: url_helper
INFO - 2018-03-29 16:29:57 --> Helper loaded: notification_helper
INFO - 2018-03-29 16:29:57 --> Helper loaded: settings_helper
INFO - 2018-03-29 16:29:57 --> Helper loaded: permission_helper
INFO - 2018-03-29 16:29:57 --> Helper loaded: users_helper
INFO - 2018-03-29 16:29:57 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:29:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:29:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:29:57 --> Helper loaded: form_helper
INFO - 2018-03-29 16:29:57 --> Form Validation Class Initialized
INFO - 2018-03-29 16:29:57 --> Controller Class Initialized
INFO - 2018-03-29 16:29:57 --> Model Class Initialized
INFO - 2018-03-29 16:29:57 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 16:29:57 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 16:29:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 16:29:58 --> Model Class Initialized
INFO - 2018-03-29 16:29:58 --> Model Class Initialized
INFO - 2018-03-29 16:29:58 --> Model Class Initialized
INFO - 2018-03-29 16:29:58 --> Model Class Initialized
INFO - 2018-03-29 16:29:58 --> Model Class Initialized
INFO - 2018-03-29 16:29:58 --> Model Class Initialized
INFO - 2018-03-29 16:29:58 --> Model Class Initialized
INFO - 2018-03-29 16:29:58 --> Model Class Initialized
INFO - 2018-03-29 16:29:58 --> Model Class Initialized
INFO - 2018-03-29 16:29:58 --> Model Class Initialized
INFO - 2018-03-29 16:29:58 --> Model Class Initialized
INFO - 2018-03-29 16:29:58 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 16:29:58 --> Model Class Initialized
INFO - 2018-03-29 16:29:58 --> Final output sent to browser
DEBUG - 2018-03-29 16:29:58 --> Total execution time: 1.0556
INFO - 2018-03-29 11:00:01 --> Config Class Initialized
INFO - 2018-03-29 11:00:01 --> Hooks Class Initialized
DEBUG - 2018-03-29 11:00:01 --> UTF-8 Support Enabled
INFO - 2018-03-29 11:00:01 --> Utf8 Class Initialized
INFO - 2018-03-29 11:00:01 --> URI Class Initialized
INFO - 2018-03-29 11:00:01 --> Router Class Initialized
INFO - 2018-03-29 11:00:01 --> Output Class Initialized
INFO - 2018-03-29 11:00:01 --> Security Class Initialized
DEBUG - 2018-03-29 11:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 11:00:01 --> Input Class Initialized
INFO - 2018-03-29 11:00:01 --> Language Class Initialized
INFO - 2018-03-29 11:00:01 --> Config Class Initialized
INFO - 2018-03-29 11:00:01 --> Hooks Class Initialized
DEBUG - 2018-03-29 11:00:01 --> UTF-8 Support Enabled
INFO - 2018-03-29 11:00:01 --> Utf8 Class Initialized
INFO - 2018-03-29 11:00:01 --> URI Class Initialized
INFO - 2018-03-29 11:00:01 --> Router Class Initialized
INFO - 2018-03-29 11:00:01 --> Output Class Initialized
INFO - 2018-03-29 11:00:01 --> Security Class Initialized
DEBUG - 2018-03-29 11:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 11:00:01 --> Input Class Initialized
INFO - 2018-03-29 11:00:01 --> Language Class Initialized
INFO - 2018-03-29 11:00:01 --> Language Class Initialized
INFO - 2018-03-29 11:00:01 --> Config Class Initialized
INFO - 2018-03-29 11:00:01 --> Loader Class Initialized
INFO - 2018-03-29 16:30:01 --> Helper loaded: url_helper
INFO - 2018-03-29 16:30:01 --> Helper loaded: notification_helper
INFO - 2018-03-29 16:30:01 --> Helper loaded: settings_helper
INFO - 2018-03-29 16:30:01 --> Helper loaded: permission_helper
INFO - 2018-03-29 16:30:01 --> Helper loaded: users_helper
INFO - 2018-03-29 16:30:01 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:30:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:30:01 --> Helper loaded: form_helper
INFO - 2018-03-29 16:30:01 --> Form Validation Class Initialized
INFO - 2018-03-29 16:30:01 --> Controller Class Initialized
INFO - 2018-03-29 11:00:01 --> Language Class Initialized
INFO - 2018-03-29 11:00:01 --> Config Class Initialized
INFO - 2018-03-29 11:00:01 --> Loader Class Initialized
INFO - 2018-03-29 16:30:01 --> Helper loaded: url_helper
INFO - 2018-03-29 16:30:01 --> Model Class Initialized
INFO - 2018-03-29 16:30:01 --> Helper loaded: notification_helper
INFO - 2018-03-29 16:30:01 --> Helper loaded: inflector_helper
INFO - 2018-03-29 16:30:01 --> Helper loaded: settings_helper
INFO - 2018-03-29 16:30:01 --> Helper loaded: permission_helper
INFO - 2018-03-29 16:30:01 --> Helper loaded: users_helper
DEBUG - 2018-03-29 16:30:01 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 16:30:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 16:30:01 --> Model Class Initialized
INFO - 2018-03-29 16:30:01 --> Model Class Initialized
INFO - 2018-03-29 16:30:01 --> Model Class Initialized
INFO - 2018-03-29 16:30:01 --> Model Class Initialized
INFO - 2018-03-29 16:30:01 --> Model Class Initialized
INFO - 2018-03-29 16:30:02 --> Model Class Initialized
INFO - 2018-03-29 16:30:02 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 16:30:02 --> Final output sent to browser
DEBUG - 2018-03-29 16:30:02 --> Total execution time: 0.6232
INFO - 2018-03-29 16:30:02 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:30:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:30:02 --> Helper loaded: form_helper
INFO - 2018-03-29 16:30:02 --> Form Validation Class Initialized
INFO - 2018-03-29 16:30:02 --> Controller Class Initialized
INFO - 2018-03-29 16:30:03 --> Model Class Initialized
INFO - 2018-03-29 16:30:03 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 16:30:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 16:30:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 16:30:03 --> Model Class Initialized
INFO - 2018-03-29 16:30:03 --> Model Class Initialized
INFO - 2018-03-29 16:30:03 --> Model Class Initialized
INFO - 2018-03-29 16:30:03 --> Model Class Initialized
INFO - 2018-03-29 16:30:03 --> Model Class Initialized
INFO - 2018-03-29 16:30:03 --> Model Class Initialized
INFO - 2018-03-29 16:30:03 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 16:30:03 --> Final output sent to browser
DEBUG - 2018-03-29 16:30:03 --> Total execution time: 1.8237
INFO - 2018-03-29 11:02:18 --> Config Class Initialized
INFO - 2018-03-29 11:02:18 --> Hooks Class Initialized
DEBUG - 2018-03-29 11:02:18 --> UTF-8 Support Enabled
INFO - 2018-03-29 11:02:18 --> Utf8 Class Initialized
INFO - 2018-03-29 11:02:18 --> URI Class Initialized
INFO - 2018-03-29 11:02:18 --> Router Class Initialized
INFO - 2018-03-29 11:02:18 --> Output Class Initialized
INFO - 2018-03-29 11:02:18 --> Security Class Initialized
DEBUG - 2018-03-29 11:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 11:02:18 --> Input Class Initialized
INFO - 2018-03-29 11:02:18 --> Language Class Initialized
INFO - 2018-03-29 11:02:18 --> Language Class Initialized
INFO - 2018-03-29 11:02:18 --> Config Class Initialized
INFO - 2018-03-29 11:02:18 --> Loader Class Initialized
INFO - 2018-03-29 16:32:18 --> Helper loaded: url_helper
INFO - 2018-03-29 16:32:18 --> Helper loaded: notification_helper
INFO - 2018-03-29 16:32:18 --> Helper loaded: settings_helper
INFO - 2018-03-29 16:32:18 --> Helper loaded: permission_helper
INFO - 2018-03-29 16:32:18 --> Helper loaded: users_helper
INFO - 2018-03-29 16:32:19 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:32:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:32:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:32:19 --> Helper loaded: form_helper
INFO - 2018-03-29 16:32:19 --> Form Validation Class Initialized
INFO - 2018-03-29 16:32:19 --> Controller Class Initialized
INFO - 2018-03-29 16:32:19 --> Model Class Initialized
INFO - 2018-03-29 16:32:19 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 16:32:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 16:32:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 16:32:19 --> Model Class Initialized
INFO - 2018-03-29 16:32:19 --> Model Class Initialized
INFO - 2018-03-29 16:32:19 --> Model Class Initialized
INFO - 2018-03-29 16:32:19 --> Model Class Initialized
INFO - 2018-03-29 16:32:19 --> Model Class Initialized
INFO - 2018-03-29 16:32:19 --> Model Class Initialized
INFO - 2018-03-29 16:32:19 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 16:32:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-29 16:32:19 --> Final output sent to browser
DEBUG - 2018-03-29 16:32:19 --> Total execution time: 0.4943
INFO - 2018-03-29 11:02:20 --> Config Class Initialized
INFO - 2018-03-29 11:02:20 --> Hooks Class Initialized
DEBUG - 2018-03-29 11:02:20 --> UTF-8 Support Enabled
INFO - 2018-03-29 11:02:20 --> Utf8 Class Initialized
INFO - 2018-03-29 11:02:20 --> URI Class Initialized
INFO - 2018-03-29 11:02:20 --> Router Class Initialized
INFO - 2018-03-29 11:02:20 --> Output Class Initialized
INFO - 2018-03-29 11:02:20 --> Security Class Initialized
DEBUG - 2018-03-29 11:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 11:02:20 --> Input Class Initialized
INFO - 2018-03-29 11:02:20 --> Language Class Initialized
INFO - 2018-03-29 11:02:20 --> Language Class Initialized
INFO - 2018-03-29 11:02:20 --> Config Class Initialized
INFO - 2018-03-29 11:02:20 --> Loader Class Initialized
INFO - 2018-03-29 16:32:20 --> Helper loaded: url_helper
INFO - 2018-03-29 16:32:20 --> Helper loaded: notification_helper
INFO - 2018-03-29 16:32:20 --> Helper loaded: settings_helper
INFO - 2018-03-29 16:32:20 --> Helper loaded: permission_helper
INFO - 2018-03-29 16:32:20 --> Helper loaded: users_helper
INFO - 2018-03-29 16:32:20 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:32:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:32:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:32:20 --> Helper loaded: form_helper
INFO - 2018-03-29 16:32:20 --> Form Validation Class Initialized
INFO - 2018-03-29 16:32:20 --> Controller Class Initialized
INFO - 2018-03-29 16:32:20 --> Model Class Initialized
INFO - 2018-03-29 16:32:20 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 16:32:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 16:32:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 16:32:20 --> Model Class Initialized
INFO - 2018-03-29 16:32:20 --> Model Class Initialized
INFO - 2018-03-29 16:32:20 --> Model Class Initialized
INFO - 2018-03-29 16:32:20 --> Model Class Initialized
INFO - 2018-03-29 16:32:20 --> Model Class Initialized
INFO - 2018-03-29 16:32:20 --> Model Class Initialized
INFO - 2018-03-29 16:32:20 --> Model Class Initialized
INFO - 2018-03-29 16:32:20 --> Model Class Initialized
INFO - 2018-03-29 16:32:20 --> Model Class Initialized
INFO - 2018-03-29 16:32:20 --> Model Class Initialized
INFO - 2018-03-29 16:32:20 --> Model Class Initialized
INFO - 2018-03-29 16:32:20 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 16:32:20 --> Model Class Initialized
INFO - 2018-03-29 16:32:20 --> Final output sent to browser
DEBUG - 2018-03-29 16:32:20 --> Total execution time: 0.2592
INFO - 2018-03-29 11:02:21 --> Config Class Initialized
INFO - 2018-03-29 11:02:21 --> Hooks Class Initialized
DEBUG - 2018-03-29 11:02:21 --> UTF-8 Support Enabled
INFO - 2018-03-29 11:02:21 --> Utf8 Class Initialized
INFO - 2018-03-29 11:02:21 --> URI Class Initialized
INFO - 2018-03-29 11:02:21 --> Router Class Initialized
INFO - 2018-03-29 11:02:21 --> Output Class Initialized
INFO - 2018-03-29 11:02:21 --> Security Class Initialized
DEBUG - 2018-03-29 11:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 11:02:21 --> Input Class Initialized
INFO - 2018-03-29 11:02:21 --> Language Class Initialized
INFO - 2018-03-29 11:02:22 --> Language Class Initialized
INFO - 2018-03-29 11:02:22 --> Config Class Initialized
INFO - 2018-03-29 11:02:22 --> Loader Class Initialized
INFO - 2018-03-29 16:32:22 --> Helper loaded: url_helper
INFO - 2018-03-29 16:32:22 --> Helper loaded: notification_helper
INFO - 2018-03-29 16:32:22 --> Helper loaded: settings_helper
INFO - 2018-03-29 16:32:22 --> Helper loaded: permission_helper
INFO - 2018-03-29 16:32:22 --> Helper loaded: users_helper
INFO - 2018-03-29 16:32:22 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:32:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:32:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:32:22 --> Helper loaded: form_helper
INFO - 2018-03-29 16:32:22 --> Form Validation Class Initialized
INFO - 2018-03-29 16:32:22 --> Controller Class Initialized
INFO - 2018-03-29 16:32:22 --> Model Class Initialized
INFO - 2018-03-29 16:32:22 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 16:32:22 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 16:32:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 11:02:22 --> Config Class Initialized
INFO - 2018-03-29 11:02:22 --> Hooks Class Initialized
DEBUG - 2018-03-29 11:02:22 --> UTF-8 Support Enabled
INFO - 2018-03-29 11:02:22 --> Utf8 Class Initialized
INFO - 2018-03-29 11:02:22 --> URI Class Initialized
INFO - 2018-03-29 16:32:22 --> Model Class Initialized
INFO - 2018-03-29 16:32:22 --> Model Class Initialized
INFO - 2018-03-29 11:02:22 --> Router Class Initialized
INFO - 2018-03-29 11:02:22 --> Output Class Initialized
INFO - 2018-03-29 11:02:22 --> Security Class Initialized
INFO - 2018-03-29 16:32:22 --> Model Class Initialized
DEBUG - 2018-03-29 11:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 11:02:22 --> Input Class Initialized
INFO - 2018-03-29 11:02:22 --> Language Class Initialized
INFO - 2018-03-29 16:32:22 --> Model Class Initialized
INFO - 2018-03-29 16:32:22 --> Model Class Initialized
INFO - 2018-03-29 16:32:22 --> Model Class Initialized
INFO - 2018-03-29 16:32:22 --> Model Class Initialized
INFO - 2018-03-29 16:32:22 --> Model Class Initialized
INFO - 2018-03-29 16:32:22 --> Model Class Initialized
INFO - 2018-03-29 16:32:22 --> Model Class Initialized
INFO - 2018-03-29 11:02:22 --> Language Class Initialized
INFO - 2018-03-29 11:02:22 --> Config Class Initialized
INFO - 2018-03-29 11:02:22 --> Loader Class Initialized
INFO - 2018-03-29 16:32:22 --> Helper loaded: url_helper
INFO - 2018-03-29 16:32:22 --> Helper loaded: notification_helper
INFO - 2018-03-29 16:32:22 --> Helper loaded: settings_helper
INFO - 2018-03-29 16:32:22 --> Helper loaded: permission_helper
INFO - 2018-03-29 16:32:22 --> Helper loaded: users_helper
INFO - 2018-03-29 16:32:23 --> Model Class Initialized
INFO - 2018-03-29 16:32:23 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 16:32:23 --> Model Class Initialized
INFO - 2018-03-29 16:32:23 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:32:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:32:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:32:23 --> Helper loaded: form_helper
INFO - 2018-03-29 16:32:23 --> Form Validation Class Initialized
INFO - 2018-03-29 16:32:23 --> Controller Class Initialized
INFO - 2018-03-29 16:32:23 --> Final output sent to browser
DEBUG - 2018-03-29 16:32:23 --> Total execution time: 2.2371
INFO - 2018-03-29 16:32:23 --> Model Class Initialized
INFO - 2018-03-29 16:32:23 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 16:32:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 16:32:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 16:32:23 --> Model Class Initialized
INFO - 2018-03-29 16:32:23 --> Model Class Initialized
INFO - 2018-03-29 16:32:23 --> Model Class Initialized
INFO - 2018-03-29 16:32:23 --> Model Class Initialized
INFO - 2018-03-29 16:32:23 --> Model Class Initialized
INFO - 2018-03-29 16:32:23 --> Model Class Initialized
INFO - 2018-03-29 16:32:23 --> Model Class Initialized
INFO - 2018-03-29 16:32:23 --> Model Class Initialized
INFO - 2018-03-29 16:32:23 --> Model Class Initialized
INFO - 2018-03-29 16:32:23 --> Model Class Initialized
INFO - 2018-03-29 16:32:23 --> Model Class Initialized
INFO - 2018-03-29 16:32:23 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 16:32:23 --> Model Class Initialized
INFO - 2018-03-29 16:32:23 --> Final output sent to browser
DEBUG - 2018-03-29 16:32:23 --> Total execution time: 0.2492
INFO - 2018-03-29 11:02:25 --> Config Class Initialized
INFO - 2018-03-29 11:02:25 --> Hooks Class Initialized
DEBUG - 2018-03-29 11:02:25 --> UTF-8 Support Enabled
INFO - 2018-03-29 11:02:25 --> Utf8 Class Initialized
INFO - 2018-03-29 11:02:25 --> URI Class Initialized
INFO - 2018-03-29 11:02:25 --> Router Class Initialized
INFO - 2018-03-29 11:02:25 --> Output Class Initialized
INFO - 2018-03-29 11:02:25 --> Security Class Initialized
DEBUG - 2018-03-29 11:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 11:02:25 --> Input Class Initialized
INFO - 2018-03-29 11:02:25 --> Language Class Initialized
INFO - 2018-03-29 11:02:26 --> Config Class Initialized
INFO - 2018-03-29 11:02:26 --> Hooks Class Initialized
DEBUG - 2018-03-29 11:02:26 --> UTF-8 Support Enabled
INFO - 2018-03-29 11:02:26 --> Utf8 Class Initialized
INFO - 2018-03-29 11:02:26 --> URI Class Initialized
INFO - 2018-03-29 11:02:26 --> Router Class Initialized
INFO - 2018-03-29 11:02:26 --> Output Class Initialized
INFO - 2018-03-29 11:02:26 --> Security Class Initialized
DEBUG - 2018-03-29 11:02:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 11:02:26 --> Input Class Initialized
INFO - 2018-03-29 11:02:26 --> Language Class Initialized
INFO - 2018-03-29 11:02:26 --> Language Class Initialized
INFO - 2018-03-29 11:02:26 --> Config Class Initialized
INFO - 2018-03-29 11:02:26 --> Loader Class Initialized
INFO - 2018-03-29 16:32:26 --> Helper loaded: url_helper
INFO - 2018-03-29 11:02:26 --> Language Class Initialized
INFO - 2018-03-29 16:32:26 --> Helper loaded: notification_helper
INFO - 2018-03-29 11:02:26 --> Config Class Initialized
INFO - 2018-03-29 11:02:26 --> Loader Class Initialized
INFO - 2018-03-29 16:32:27 --> Helper loaded: settings_helper
INFO - 2018-03-29 16:32:27 --> Helper loaded: permission_helper
INFO - 2018-03-29 16:32:27 --> Helper loaded: users_helper
INFO - 2018-03-29 16:32:27 --> Helper loaded: url_helper
INFO - 2018-03-29 16:32:27 --> Helper loaded: notification_helper
INFO - 2018-03-29 16:32:27 --> Helper loaded: settings_helper
INFO - 2018-03-29 16:32:27 --> Helper loaded: permission_helper
INFO - 2018-03-29 16:32:27 --> Helper loaded: users_helper
INFO - 2018-03-29 11:02:27 --> Config Class Initialized
INFO - 2018-03-29 11:02:27 --> Hooks Class Initialized
DEBUG - 2018-03-29 11:02:27 --> UTF-8 Support Enabled
INFO - 2018-03-29 11:02:27 --> Utf8 Class Initialized
INFO - 2018-03-29 11:02:27 --> URI Class Initialized
INFO - 2018-03-29 11:02:27 --> Router Class Initialized
INFO - 2018-03-29 11:02:27 --> Output Class Initialized
INFO - 2018-03-29 11:02:27 --> Security Class Initialized
DEBUG - 2018-03-29 11:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 11:02:27 --> Input Class Initialized
INFO - 2018-03-29 11:02:27 --> Language Class Initialized
INFO - 2018-03-29 11:02:27 --> Language Class Initialized
INFO - 2018-03-29 11:02:27 --> Config Class Initialized
INFO - 2018-03-29 11:02:27 --> Loader Class Initialized
INFO - 2018-03-29 16:32:27 --> Helper loaded: url_helper
INFO - 2018-03-29 16:32:27 --> Helper loaded: notification_helper
INFO - 2018-03-29 16:32:27 --> Helper loaded: settings_helper
INFO - 2018-03-29 16:32:27 --> Helper loaded: permission_helper
INFO - 2018-03-29 16:32:27 --> Helper loaded: users_helper
INFO - 2018-03-29 16:32:28 --> Database Driver Class Initialized
INFO - 2018-03-29 16:32:28 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:32:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:32:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-03-29 16:32:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:32:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:32:28 --> Helper loaded: form_helper
INFO - 2018-03-29 16:32:28 --> Form Validation Class Initialized
INFO - 2018-03-29 16:32:28 --> Controller Class Initialized
INFO - 2018-03-29 16:32:28 --> Helper loaded: form_helper
INFO - 2018-03-29 16:32:28 --> Form Validation Class Initialized
INFO - 2018-03-29 16:32:28 --> Controller Class Initialized
INFO - 2018-03-29 16:32:28 --> Model Class Initialized
INFO - 2018-03-29 16:32:28 --> Model Class Initialized
INFO - 2018-03-29 16:32:28 --> Helper loaded: inflector_helper
INFO - 2018-03-29 16:32:28 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 16:32:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 16:32:28 --> Language file loaded: language/english/rest_controller_lang.php
DEBUG - 2018-03-29 16:32:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 16:32:28 --> Model Class Initialized
INFO - 2018-03-29 16:32:28 --> Model Class Initialized
INFO - 2018-03-29 16:32:28 --> Model Class Initialized
INFO - 2018-03-29 16:32:28 --> Model Class Initialized
INFO - 2018-03-29 16:32:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 16:32:28 --> Model Class Initialized
INFO - 2018-03-29 16:32:28 --> Model Class Initialized
INFO - 2018-03-29 16:32:28 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 16:32:28 --> Model Class Initialized
INFO - 2018-03-29 16:32:28 --> Model Class Initialized
INFO - 2018-03-29 16:32:28 --> Final output sent to browser
DEBUG - 2018-03-29 16:32:28 --> Total execution time: 0.2610
INFO - 2018-03-29 16:32:28 --> Model Class Initialized
INFO - 2018-03-29 16:32:28 --> Model Class Initialized
INFO - 2018-03-29 16:32:28 --> Model Class Initialized
INFO - 2018-03-29 16:32:28 --> Model Class Initialized
INFO - 2018-03-29 16:32:28 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 16:32:28 --> Final output sent to browser
DEBUG - 2018-03-29 16:32:28 --> Total execution time: 1.9814
INFO - 2018-03-29 11:02:28 --> Config Class Initialized
INFO - 2018-03-29 11:02:28 --> Hooks Class Initialized
DEBUG - 2018-03-29 11:02:28 --> UTF-8 Support Enabled
INFO - 2018-03-29 11:02:28 --> Utf8 Class Initialized
INFO - 2018-03-29 11:02:28 --> URI Class Initialized
INFO - 2018-03-29 11:02:28 --> Router Class Initialized
INFO - 2018-03-29 11:02:28 --> Output Class Initialized
INFO - 2018-03-29 11:02:28 --> Security Class Initialized
DEBUG - 2018-03-29 11:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 11:02:28 --> Input Class Initialized
INFO - 2018-03-29 11:02:28 --> Language Class Initialized
INFO - 2018-03-29 11:02:28 --> Language Class Initialized
INFO - 2018-03-29 11:02:28 --> Config Class Initialized
INFO - 2018-03-29 11:02:28 --> Loader Class Initialized
INFO - 2018-03-29 16:32:28 --> Helper loaded: url_helper
INFO - 2018-03-29 16:32:28 --> Helper loaded: notification_helper
INFO - 2018-03-29 16:32:28 --> Helper loaded: settings_helper
INFO - 2018-03-29 16:32:28 --> Helper loaded: permission_helper
INFO - 2018-03-29 16:32:28 --> Helper loaded: users_helper
INFO - 2018-03-29 16:32:28 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:32:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:32:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:32:28 --> Helper loaded: form_helper
INFO - 2018-03-29 16:32:28 --> Form Validation Class Initialized
INFO - 2018-03-29 16:32:28 --> Controller Class Initialized
INFO - 2018-03-29 16:32:28 --> Model Class Initialized
INFO - 2018-03-29 16:32:28 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 16:32:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 16:32:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 16:32:28 --> Model Class Initialized
INFO - 2018-03-29 16:32:28 --> Model Class Initialized
INFO - 2018-03-29 16:32:28 --> Model Class Initialized
INFO - 2018-03-29 16:32:28 --> Model Class Initialized
INFO - 2018-03-29 16:32:28 --> Model Class Initialized
INFO - 2018-03-29 16:32:28 --> Model Class Initialized
INFO - 2018-03-29 16:32:28 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 16:32:28 --> Final output sent to browser
DEBUG - 2018-03-29 16:32:28 --> Total execution time: 0.1924
INFO - 2018-03-29 16:32:28 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:32:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:32:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:32:28 --> Helper loaded: form_helper
INFO - 2018-03-29 16:32:28 --> Form Validation Class Initialized
INFO - 2018-03-29 16:32:28 --> Controller Class Initialized
INFO - 2018-03-29 16:32:28 --> Model Class Initialized
INFO - 2018-03-29 16:32:28 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 16:32:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 16:32:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 16:32:28 --> Model Class Initialized
INFO - 2018-03-29 16:32:28 --> Model Class Initialized
INFO - 2018-03-29 16:32:28 --> Model Class Initialized
INFO - 2018-03-29 16:32:28 --> Model Class Initialized
INFO - 2018-03-29 16:32:28 --> Model Class Initialized
INFO - 2018-03-29 16:32:28 --> Model Class Initialized
INFO - 2018-03-29 16:32:28 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 16:32:28 --> Final output sent to browser
DEBUG - 2018-03-29 16:32:28 --> Total execution time: 3.1550
INFO - 2018-03-29 11:07:11 --> Config Class Initialized
INFO - 2018-03-29 11:07:11 --> Hooks Class Initialized
DEBUG - 2018-03-29 11:07:11 --> UTF-8 Support Enabled
INFO - 2018-03-29 11:07:11 --> Utf8 Class Initialized
INFO - 2018-03-29 11:07:12 --> URI Class Initialized
INFO - 2018-03-29 11:07:12 --> Router Class Initialized
INFO - 2018-03-29 11:07:12 --> Output Class Initialized
INFO - 2018-03-29 11:07:12 --> Security Class Initialized
DEBUG - 2018-03-29 11:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 11:07:13 --> Input Class Initialized
INFO - 2018-03-29 11:07:13 --> Language Class Initialized
INFO - 2018-03-29 11:07:14 --> Language Class Initialized
INFO - 2018-03-29 11:07:14 --> Config Class Initialized
INFO - 2018-03-29 11:07:14 --> Loader Class Initialized
INFO - 2018-03-29 16:37:14 --> Helper loaded: url_helper
INFO - 2018-03-29 16:37:14 --> Helper loaded: notification_helper
INFO - 2018-03-29 16:37:14 --> Helper loaded: settings_helper
INFO - 2018-03-29 16:37:14 --> Helper loaded: permission_helper
INFO - 2018-03-29 16:37:14 --> Helper loaded: users_helper
INFO - 2018-03-29 16:37:15 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:37:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:37:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:37:15 --> Helper loaded: form_helper
INFO - 2018-03-29 16:37:15 --> Form Validation Class Initialized
INFO - 2018-03-29 16:37:15 --> Controller Class Initialized
INFO - 2018-03-29 16:37:15 --> Model Class Initialized
INFO - 2018-03-29 16:37:15 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 16:37:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 16:37:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 16:37:15 --> Model Class Initialized
INFO - 2018-03-29 16:37:15 --> Model Class Initialized
INFO - 2018-03-29 16:37:15 --> Model Class Initialized
INFO - 2018-03-29 16:37:15 --> Model Class Initialized
INFO - 2018-03-29 16:37:15 --> Model Class Initialized
INFO - 2018-03-29 16:37:15 --> Model Class Initialized
INFO - 2018-03-29 16:37:15 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 16:37:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-29 16:37:15 --> Final output sent to browser
DEBUG - 2018-03-29 16:37:15 --> Total execution time: 3.6101
INFO - 2018-03-29 11:07:16 --> Config Class Initialized
INFO - 2018-03-29 11:07:16 --> Hooks Class Initialized
DEBUG - 2018-03-29 11:07:16 --> UTF-8 Support Enabled
INFO - 2018-03-29 11:07:16 --> Utf8 Class Initialized
INFO - 2018-03-29 11:07:16 --> URI Class Initialized
INFO - 2018-03-29 11:07:16 --> Router Class Initialized
INFO - 2018-03-29 11:07:16 --> Output Class Initialized
INFO - 2018-03-29 11:07:16 --> Security Class Initialized
DEBUG - 2018-03-29 11:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 11:07:16 --> Input Class Initialized
INFO - 2018-03-29 11:07:16 --> Language Class Initialized
INFO - 2018-03-29 11:07:16 --> Language Class Initialized
INFO - 2018-03-29 11:07:16 --> Config Class Initialized
INFO - 2018-03-29 11:07:16 --> Loader Class Initialized
INFO - 2018-03-29 16:37:16 --> Helper loaded: url_helper
INFO - 2018-03-29 16:37:16 --> Helper loaded: notification_helper
INFO - 2018-03-29 16:37:16 --> Helper loaded: settings_helper
INFO - 2018-03-29 16:37:16 --> Helper loaded: permission_helper
INFO - 2018-03-29 16:37:16 --> Helper loaded: users_helper
INFO - 2018-03-29 16:37:16 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:37:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:37:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:37:16 --> Helper loaded: form_helper
INFO - 2018-03-29 16:37:16 --> Form Validation Class Initialized
INFO - 2018-03-29 16:37:16 --> Controller Class Initialized
INFO - 2018-03-29 16:37:16 --> Model Class Initialized
INFO - 2018-03-29 16:37:16 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 16:37:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 16:37:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 16:37:16 --> Model Class Initialized
INFO - 2018-03-29 16:37:16 --> Model Class Initialized
INFO - 2018-03-29 16:37:16 --> Model Class Initialized
INFO - 2018-03-29 16:37:16 --> Model Class Initialized
INFO - 2018-03-29 16:37:16 --> Model Class Initialized
INFO - 2018-03-29 16:37:16 --> Model Class Initialized
INFO - 2018-03-29 16:37:16 --> Model Class Initialized
INFO - 2018-03-29 16:37:16 --> Model Class Initialized
INFO - 2018-03-29 16:37:16 --> Model Class Initialized
INFO - 2018-03-29 16:37:16 --> Model Class Initialized
INFO - 2018-03-29 16:37:16 --> Model Class Initialized
INFO - 2018-03-29 16:37:16 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 16:37:16 --> Model Class Initialized
INFO - 2018-03-29 16:37:16 --> Final output sent to browser
DEBUG - 2018-03-29 16:37:16 --> Total execution time: 0.3174
INFO - 2018-03-29 11:07:16 --> Config Class Initialized
INFO - 2018-03-29 11:07:16 --> Hooks Class Initialized
DEBUG - 2018-03-29 11:07:16 --> UTF-8 Support Enabled
INFO - 2018-03-29 11:07:16 --> Utf8 Class Initialized
INFO - 2018-03-29 11:07:16 --> URI Class Initialized
INFO - 2018-03-29 11:07:16 --> Router Class Initialized
INFO - 2018-03-29 11:07:16 --> Output Class Initialized
INFO - 2018-03-29 11:07:16 --> Security Class Initialized
DEBUG - 2018-03-29 11:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 11:07:17 --> Input Class Initialized
INFO - 2018-03-29 11:07:17 --> Language Class Initialized
INFO - 2018-03-29 11:07:17 --> Language Class Initialized
INFO - 2018-03-29 11:07:17 --> Config Class Initialized
INFO - 2018-03-29 11:07:17 --> Loader Class Initialized
INFO - 2018-03-29 16:37:17 --> Helper loaded: url_helper
INFO - 2018-03-29 16:37:17 --> Helper loaded: notification_helper
INFO - 2018-03-29 16:37:17 --> Helper loaded: settings_helper
INFO - 2018-03-29 16:37:17 --> Helper loaded: permission_helper
INFO - 2018-03-29 16:37:17 --> Helper loaded: users_helper
INFO - 2018-03-29 16:37:18 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:37:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:37:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:37:18 --> Helper loaded: form_helper
INFO - 2018-03-29 16:37:18 --> Form Validation Class Initialized
INFO - 2018-03-29 16:37:18 --> Controller Class Initialized
INFO - 2018-03-29 16:37:18 --> Model Class Initialized
INFO - 2018-03-29 16:37:18 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 16:37:18 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 16:37:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 16:37:18 --> Model Class Initialized
INFO - 2018-03-29 16:37:18 --> Model Class Initialized
INFO - 2018-03-29 16:37:18 --> Model Class Initialized
INFO - 2018-03-29 16:37:18 --> Model Class Initialized
INFO - 2018-03-29 16:37:18 --> Model Class Initialized
INFO - 2018-03-29 16:37:18 --> Model Class Initialized
INFO - 2018-03-29 16:37:18 --> Model Class Initialized
INFO - 2018-03-29 16:37:18 --> Model Class Initialized
INFO - 2018-03-29 16:37:18 --> Model Class Initialized
INFO - 2018-03-29 16:37:18 --> Model Class Initialized
INFO - 2018-03-29 16:37:18 --> Model Class Initialized
INFO - 2018-03-29 16:37:18 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 16:37:18 --> Model Class Initialized
INFO - 2018-03-29 16:37:18 --> Final output sent to browser
DEBUG - 2018-03-29 16:37:18 --> Total execution time: 1.6129
INFO - 2018-03-29 11:07:18 --> Config Class Initialized
INFO - 2018-03-29 11:07:18 --> Hooks Class Initialized
DEBUG - 2018-03-29 11:07:18 --> UTF-8 Support Enabled
INFO - 2018-03-29 11:07:18 --> Utf8 Class Initialized
INFO - 2018-03-29 11:07:18 --> URI Class Initialized
INFO - 2018-03-29 11:07:18 --> Router Class Initialized
INFO - 2018-03-29 11:07:18 --> Output Class Initialized
INFO - 2018-03-29 11:07:18 --> Security Class Initialized
DEBUG - 2018-03-29 11:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 11:07:18 --> Input Class Initialized
INFO - 2018-03-29 11:07:18 --> Language Class Initialized
INFO - 2018-03-29 11:07:18 --> Language Class Initialized
INFO - 2018-03-29 11:07:18 --> Config Class Initialized
INFO - 2018-03-29 11:07:18 --> Loader Class Initialized
INFO - 2018-03-29 16:37:18 --> Helper loaded: url_helper
INFO - 2018-03-29 16:37:18 --> Helper loaded: notification_helper
INFO - 2018-03-29 16:37:18 --> Helper loaded: settings_helper
INFO - 2018-03-29 16:37:18 --> Helper loaded: permission_helper
INFO - 2018-03-29 16:37:18 --> Helper loaded: users_helper
INFO - 2018-03-29 16:37:18 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:37:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:37:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:37:19 --> Helper loaded: form_helper
INFO - 2018-03-29 16:37:19 --> Form Validation Class Initialized
INFO - 2018-03-29 16:37:19 --> Controller Class Initialized
INFO - 2018-03-29 16:37:19 --> Model Class Initialized
INFO - 2018-03-29 16:37:19 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 16:37:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 16:37:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 16:37:19 --> Model Class Initialized
INFO - 2018-03-29 16:37:19 --> Model Class Initialized
INFO - 2018-03-29 16:37:19 --> Model Class Initialized
INFO - 2018-03-29 16:37:19 --> Model Class Initialized
INFO - 2018-03-29 16:37:19 --> Model Class Initialized
INFO - 2018-03-29 16:37:19 --> Model Class Initialized
INFO - 2018-03-29 16:37:19 --> Model Class Initialized
INFO - 2018-03-29 16:37:19 --> Model Class Initialized
INFO - 2018-03-29 16:37:19 --> Model Class Initialized
INFO - 2018-03-29 16:37:19 --> Model Class Initialized
INFO - 2018-03-29 16:37:19 --> Model Class Initialized
INFO - 2018-03-29 16:37:19 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 16:37:19 --> Model Class Initialized
INFO - 2018-03-29 16:37:19 --> Final output sent to browser
DEBUG - 2018-03-29 16:37:19 --> Total execution time: 0.6809
INFO - 2018-03-29 11:07:21 --> Config Class Initialized
INFO - 2018-03-29 11:07:21 --> Hooks Class Initialized
DEBUG - 2018-03-29 11:07:21 --> UTF-8 Support Enabled
INFO - 2018-03-29 11:07:21 --> Utf8 Class Initialized
INFO - 2018-03-29 11:07:21 --> URI Class Initialized
INFO - 2018-03-29 11:07:21 --> Router Class Initialized
INFO - 2018-03-29 11:07:22 --> Output Class Initialized
INFO - 2018-03-29 11:07:22 --> Security Class Initialized
DEBUG - 2018-03-29 11:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 11:07:22 --> Input Class Initialized
INFO - 2018-03-29 11:07:22 --> Language Class Initialized
INFO - 2018-03-29 11:07:22 --> Language Class Initialized
INFO - 2018-03-29 11:07:22 --> Config Class Initialized
INFO - 2018-03-29 11:07:22 --> Loader Class Initialized
INFO - 2018-03-29 16:37:22 --> Helper loaded: url_helper
INFO - 2018-03-29 16:37:22 --> Helper loaded: notification_helper
INFO - 2018-03-29 16:37:22 --> Helper loaded: settings_helper
INFO - 2018-03-29 16:37:22 --> Helper loaded: permission_helper
INFO - 2018-03-29 16:37:22 --> Helper loaded: users_helper
INFO - 2018-03-29 16:37:22 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:37:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:37:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:37:22 --> Helper loaded: form_helper
INFO - 2018-03-29 16:37:22 --> Form Validation Class Initialized
INFO - 2018-03-29 16:37:22 --> Controller Class Initialized
INFO - 2018-03-29 16:37:22 --> Model Class Initialized
INFO - 2018-03-29 16:37:22 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 16:37:22 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 16:37:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 16:37:22 --> Model Class Initialized
INFO - 2018-03-29 16:37:22 --> Model Class Initialized
INFO - 2018-03-29 16:37:22 --> Model Class Initialized
INFO - 2018-03-29 16:37:22 --> Model Class Initialized
INFO - 2018-03-29 16:37:22 --> Model Class Initialized
INFO - 2018-03-29 16:37:22 --> Model Class Initialized
INFO - 2018-03-29 16:37:22 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 16:37:22 --> Final output sent to browser
DEBUG - 2018-03-29 16:37:22 --> Total execution time: 0.3187
INFO - 2018-03-29 11:07:23 --> Config Class Initialized
INFO - 2018-03-29 11:07:23 --> Hooks Class Initialized
DEBUG - 2018-03-29 11:07:23 --> UTF-8 Support Enabled
INFO - 2018-03-29 11:07:23 --> Utf8 Class Initialized
INFO - 2018-03-29 11:07:23 --> URI Class Initialized
INFO - 2018-03-29 11:07:23 --> Router Class Initialized
INFO - 2018-03-29 11:07:23 --> Output Class Initialized
INFO - 2018-03-29 11:07:23 --> Security Class Initialized
DEBUG - 2018-03-29 11:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 11:07:23 --> Input Class Initialized
INFO - 2018-03-29 11:07:23 --> Language Class Initialized
INFO - 2018-03-29 11:07:23 --> Config Class Initialized
INFO - 2018-03-29 11:07:23 --> Hooks Class Initialized
DEBUG - 2018-03-29 11:07:23 --> UTF-8 Support Enabled
INFO - 2018-03-29 11:07:23 --> Utf8 Class Initialized
INFO - 2018-03-29 11:07:23 --> URI Class Initialized
INFO - 2018-03-29 11:07:23 --> Router Class Initialized
INFO - 2018-03-29 11:07:23 --> Output Class Initialized
INFO - 2018-03-29 11:07:23 --> Security Class Initialized
DEBUG - 2018-03-29 11:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 11:07:23 --> Input Class Initialized
INFO - 2018-03-29 11:07:23 --> Language Class Initialized
INFO - 2018-03-29 11:07:23 --> Language Class Initialized
INFO - 2018-03-29 11:07:23 --> Config Class Initialized
INFO - 2018-03-29 11:07:23 --> Loader Class Initialized
INFO - 2018-03-29 16:37:23 --> Helper loaded: url_helper
INFO - 2018-03-29 16:37:23 --> Helper loaded: notification_helper
INFO - 2018-03-29 16:37:23 --> Helper loaded: settings_helper
INFO - 2018-03-29 11:07:23 --> Language Class Initialized
INFO - 2018-03-29 11:07:23 --> Config Class Initialized
INFO - 2018-03-29 11:07:23 --> Loader Class Initialized
INFO - 2018-03-29 16:37:23 --> Helper loaded: permission_helper
INFO - 2018-03-29 16:37:23 --> Helper loaded: users_helper
INFO - 2018-03-29 16:37:23 --> Helper loaded: url_helper
INFO - 2018-03-29 16:37:23 --> Helper loaded: notification_helper
INFO - 2018-03-29 16:37:23 --> Database Driver Class Initialized
INFO - 2018-03-29 16:37:23 --> Helper loaded: settings_helper
INFO - 2018-03-29 16:37:23 --> Helper loaded: permission_helper
DEBUG - 2018-03-29 16:37:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:37:23 --> Helper loaded: users_helper
INFO - 2018-03-29 16:37:23 --> Helper loaded: form_helper
INFO - 2018-03-29 16:37:23 --> Form Validation Class Initialized
INFO - 2018-03-29 16:37:23 --> Controller Class Initialized
INFO - 2018-03-29 16:37:23 --> Model Class Initialized
INFO - 2018-03-29 16:37:23 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 16:37:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 16:37:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 16:37:23 --> Model Class Initialized
INFO - 2018-03-29 16:37:23 --> Model Class Initialized
INFO - 2018-03-29 16:37:23 --> Model Class Initialized
INFO - 2018-03-29 16:37:23 --> Model Class Initialized
INFO - 2018-03-29 16:37:23 --> Model Class Initialized
INFO - 2018-03-29 16:37:23 --> Model Class Initialized
INFO - 2018-03-29 16:37:23 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 16:37:23 --> Final output sent to browser
DEBUG - 2018-03-29 16:37:23 --> Total execution time: 0.2339
INFO - 2018-03-29 16:37:24 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:37:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:37:24 --> Helper loaded: form_helper
INFO - 2018-03-29 16:37:24 --> Form Validation Class Initialized
INFO - 2018-03-29 16:37:24 --> Controller Class Initialized
INFO - 2018-03-29 16:37:24 --> Model Class Initialized
INFO - 2018-03-29 16:37:24 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 16:37:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 16:37:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 16:37:24 --> Model Class Initialized
INFO - 2018-03-29 16:37:24 --> Model Class Initialized
INFO - 2018-03-29 16:37:24 --> Model Class Initialized
INFO - 2018-03-29 16:37:24 --> Model Class Initialized
INFO - 2018-03-29 16:37:24 --> Model Class Initialized
INFO - 2018-03-29 16:37:24 --> Model Class Initialized
INFO - 2018-03-29 16:37:24 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 16:37:24 --> Final output sent to browser
DEBUG - 2018-03-29 16:37:24 --> Total execution time: 1.8878
INFO - 2018-03-29 11:07:30 --> Config Class Initialized
INFO - 2018-03-29 11:07:30 --> Hooks Class Initialized
DEBUG - 2018-03-29 11:07:30 --> UTF-8 Support Enabled
INFO - 2018-03-29 11:07:30 --> Utf8 Class Initialized
INFO - 2018-03-29 11:07:30 --> URI Class Initialized
INFO - 2018-03-29 11:07:30 --> Router Class Initialized
INFO - 2018-03-29 11:07:30 --> Output Class Initialized
INFO - 2018-03-29 11:07:30 --> Security Class Initialized
DEBUG - 2018-03-29 11:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 11:07:30 --> Input Class Initialized
INFO - 2018-03-29 11:07:30 --> Language Class Initialized
INFO - 2018-03-29 11:07:31 --> Language Class Initialized
INFO - 2018-03-29 11:07:31 --> Config Class Initialized
INFO - 2018-03-29 11:07:31 --> Loader Class Initialized
INFO - 2018-03-29 16:37:31 --> Helper loaded: url_helper
INFO - 2018-03-29 16:37:31 --> Helper loaded: notification_helper
INFO - 2018-03-29 16:37:31 --> Helper loaded: settings_helper
INFO - 2018-03-29 16:37:31 --> Helper loaded: permission_helper
INFO - 2018-03-29 16:37:31 --> Helper loaded: users_helper
INFO - 2018-03-29 16:37:32 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:37:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:37:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:37:32 --> Helper loaded: form_helper
INFO - 2018-03-29 16:37:32 --> Form Validation Class Initialized
INFO - 2018-03-29 16:37:32 --> Controller Class Initialized
INFO - 2018-03-29 16:37:32 --> Model Class Initialized
INFO - 2018-03-29 16:37:32 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 16:37:32 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 16:37:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 16:37:32 --> Model Class Initialized
INFO - 2018-03-29 16:37:32 --> Model Class Initialized
INFO - 2018-03-29 16:37:32 --> Model Class Initialized
INFO - 2018-03-29 16:37:32 --> Model Class Initialized
INFO - 2018-03-29 16:37:32 --> Model Class Initialized
INFO - 2018-03-29 16:37:32 --> Model Class Initialized
INFO - 2018-03-29 16:37:32 --> Model Class Initialized
INFO - 2018-03-29 16:37:32 --> Model Class Initialized
INFO - 2018-03-29 16:37:32 --> Model Class Initialized
INFO - 2018-03-29 16:37:32 --> Model Class Initialized
INFO - 2018-03-29 16:37:32 --> Model Class Initialized
INFO - 2018-03-29 16:37:32 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 16:37:32 --> Model Class Initialized
INFO - 2018-03-29 16:37:32 --> Final output sent to browser
DEBUG - 2018-03-29 16:37:32 --> Total execution time: 2.3872
INFO - 2018-03-29 11:07:33 --> Config Class Initialized
INFO - 2018-03-29 11:07:33 --> Hooks Class Initialized
DEBUG - 2018-03-29 11:07:33 --> UTF-8 Support Enabled
INFO - 2018-03-29 11:07:33 --> Utf8 Class Initialized
INFO - 2018-03-29 11:07:33 --> URI Class Initialized
INFO - 2018-03-29 11:07:33 --> Router Class Initialized
INFO - 2018-03-29 11:07:33 --> Output Class Initialized
INFO - 2018-03-29 11:07:33 --> Security Class Initialized
DEBUG - 2018-03-29 11:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 11:07:33 --> Input Class Initialized
INFO - 2018-03-29 11:07:33 --> Language Class Initialized
INFO - 2018-03-29 11:07:33 --> Language Class Initialized
INFO - 2018-03-29 11:07:33 --> Config Class Initialized
INFO - 2018-03-29 11:07:33 --> Loader Class Initialized
INFO - 2018-03-29 16:37:33 --> Helper loaded: url_helper
INFO - 2018-03-29 16:37:33 --> Helper loaded: notification_helper
INFO - 2018-03-29 16:37:33 --> Helper loaded: settings_helper
INFO - 2018-03-29 16:37:33 --> Helper loaded: permission_helper
INFO - 2018-03-29 16:37:33 --> Helper loaded: users_helper
INFO - 2018-03-29 16:37:33 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:37:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:37:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:37:33 --> Helper loaded: form_helper
INFO - 2018-03-29 16:37:33 --> Form Validation Class Initialized
INFO - 2018-03-29 16:37:33 --> Controller Class Initialized
INFO - 2018-03-29 16:37:33 --> Model Class Initialized
INFO - 2018-03-29 16:37:33 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 16:37:33 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 16:37:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 16:37:33 --> Model Class Initialized
INFO - 2018-03-29 16:37:33 --> Model Class Initialized
INFO - 2018-03-29 16:37:33 --> Model Class Initialized
INFO - 2018-03-29 16:37:33 --> Model Class Initialized
INFO - 2018-03-29 16:37:33 --> Model Class Initialized
INFO - 2018-03-29 16:37:33 --> Model Class Initialized
INFO - 2018-03-29 16:37:33 --> Model Class Initialized
INFO - 2018-03-29 16:37:33 --> Model Class Initialized
INFO - 2018-03-29 16:37:33 --> Model Class Initialized
INFO - 2018-03-29 16:37:33 --> Model Class Initialized
INFO - 2018-03-29 16:37:33 --> Model Class Initialized
INFO - 2018-03-29 16:37:33 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 16:37:33 --> Model Class Initialized
INFO - 2018-03-29 16:37:33 --> Final output sent to browser
DEBUG - 2018-03-29 16:37:33 --> Total execution time: 0.3198
INFO - 2018-03-29 11:07:36 --> Config Class Initialized
INFO - 2018-03-29 11:07:36 --> Hooks Class Initialized
DEBUG - 2018-03-29 11:07:37 --> UTF-8 Support Enabled
INFO - 2018-03-29 11:07:37 --> Utf8 Class Initialized
INFO - 2018-03-29 11:07:37 --> URI Class Initialized
INFO - 2018-03-29 11:07:37 --> Router Class Initialized
INFO - 2018-03-29 11:07:37 --> Output Class Initialized
INFO - 2018-03-29 11:07:37 --> Security Class Initialized
DEBUG - 2018-03-29 11:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 11:07:37 --> Input Class Initialized
INFO - 2018-03-29 11:07:37 --> Language Class Initialized
INFO - 2018-03-29 11:07:37 --> Language Class Initialized
INFO - 2018-03-29 11:07:37 --> Config Class Initialized
INFO - 2018-03-29 11:07:37 --> Loader Class Initialized
INFO - 2018-03-29 16:37:37 --> Helper loaded: url_helper
INFO - 2018-03-29 16:37:37 --> Helper loaded: notification_helper
INFO - 2018-03-29 16:37:37 --> Helper loaded: settings_helper
INFO - 2018-03-29 16:37:38 --> Helper loaded: permission_helper
INFO - 2018-03-29 16:37:38 --> Helper loaded: users_helper
INFO - 2018-03-29 16:37:38 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:37:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:37:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 11:07:38 --> Config Class Initialized
INFO - 2018-03-29 11:07:38 --> Hooks Class Initialized
DEBUG - 2018-03-29 11:07:38 --> UTF-8 Support Enabled
INFO - 2018-03-29 11:07:38 --> Utf8 Class Initialized
INFO - 2018-03-29 11:07:38 --> URI Class Initialized
INFO - 2018-03-29 11:07:38 --> Router Class Initialized
INFO - 2018-03-29 11:07:38 --> Output Class Initialized
INFO - 2018-03-29 11:07:38 --> Security Class Initialized
DEBUG - 2018-03-29 11:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 11:07:38 --> Input Class Initialized
INFO - 2018-03-29 11:07:38 --> Language Class Initialized
INFO - 2018-03-29 11:07:38 --> Language Class Initialized
INFO - 2018-03-29 11:07:38 --> Config Class Initialized
INFO - 2018-03-29 11:07:38 --> Loader Class Initialized
INFO - 2018-03-29 16:37:38 --> Helper loaded: url_helper
INFO - 2018-03-29 16:37:38 --> Helper loaded: notification_helper
INFO - 2018-03-29 16:37:38 --> Helper loaded: settings_helper
INFO - 2018-03-29 16:37:38 --> Helper loaded: permission_helper
INFO - 2018-03-29 16:37:38 --> Helper loaded: users_helper
INFO - 2018-03-29 16:37:38 --> Helper loaded: form_helper
INFO - 2018-03-29 16:37:38 --> Form Validation Class Initialized
INFO - 2018-03-29 16:37:38 --> Database Driver Class Initialized
INFO - 2018-03-29 16:37:38 --> Controller Class Initialized
DEBUG - 2018-03-29 16:37:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:37:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:37:38 --> Helper loaded: form_helper
INFO - 2018-03-29 16:37:38 --> Form Validation Class Initialized
INFO - 2018-03-29 16:37:38 --> Controller Class Initialized
INFO - 2018-03-29 16:37:38 --> Model Class Initialized
INFO - 2018-03-29 16:37:38 --> Helper loaded: inflector_helper
INFO - 2018-03-29 16:37:39 --> Model Class Initialized
INFO - 2018-03-29 16:37:39 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 16:37:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-03-29 16:37:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 16:37:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 16:37:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 16:37:39 --> Model Class Initialized
INFO - 2018-03-29 16:37:39 --> Model Class Initialized
INFO - 2018-03-29 16:37:39 --> Model Class Initialized
INFO - 2018-03-29 16:37:39 --> Model Class Initialized
INFO - 2018-03-29 16:37:39 --> Model Class Initialized
INFO - 2018-03-29 16:37:39 --> Model Class Initialized
INFO - 2018-03-29 16:37:39 --> Model Class Initialized
INFO - 2018-03-29 16:37:39 --> Model Class Initialized
INFO - 2018-03-29 16:37:39 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 16:37:39 --> Model Class Initialized
INFO - 2018-03-29 16:37:39 --> Model Class Initialized
ERROR - 2018-03-29 16:37:39 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-29 16:37:39 --> Model Class Initialized
INFO - 2018-03-29 16:37:39 --> Model Class Initialized
INFO - 2018-03-29 16:37:39 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 16:37:39 --> Final output sent to browser
DEBUG - 2018-03-29 16:37:39 --> Total execution time: 0.4762
ERROR - 2018-03-29 16:37:39 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-29 16:37:39 --> Final output sent to browser
DEBUG - 2018-03-29 16:37:39 --> Total execution time: 2.2145
INFO - 2018-03-29 11:19:34 --> Config Class Initialized
INFO - 2018-03-29 11:19:34 --> Hooks Class Initialized
DEBUG - 2018-03-29 11:19:34 --> UTF-8 Support Enabled
INFO - 2018-03-29 11:19:34 --> Utf8 Class Initialized
INFO - 2018-03-29 11:19:34 --> URI Class Initialized
INFO - 2018-03-29 11:19:34 --> Router Class Initialized
INFO - 2018-03-29 11:19:34 --> Output Class Initialized
INFO - 2018-03-29 11:19:34 --> Security Class Initialized
DEBUG - 2018-03-29 11:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 11:19:34 --> Input Class Initialized
INFO - 2018-03-29 11:19:34 --> Language Class Initialized
INFO - 2018-03-29 11:19:34 --> Language Class Initialized
INFO - 2018-03-29 11:19:34 --> Config Class Initialized
INFO - 2018-03-29 11:19:34 --> Loader Class Initialized
INFO - 2018-03-29 16:49:34 --> Helper loaded: url_helper
INFO - 2018-03-29 16:49:34 --> Helper loaded: notification_helper
INFO - 2018-03-29 16:49:34 --> Helper loaded: settings_helper
INFO - 2018-03-29 16:49:34 --> Helper loaded: permission_helper
INFO - 2018-03-29 16:49:34 --> Helper loaded: users_helper
INFO - 2018-03-29 16:49:34 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:49:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:49:35 --> Helper loaded: form_helper
INFO - 2018-03-29 16:49:35 --> Form Validation Class Initialized
INFO - 2018-03-29 16:49:35 --> Controller Class Initialized
INFO - 2018-03-29 16:49:35 --> Model Class Initialized
INFO - 2018-03-29 16:49:35 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 16:49:35 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 16:49:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 16:49:35 --> Model Class Initialized
INFO - 2018-03-29 16:49:35 --> Model Class Initialized
INFO - 2018-03-29 16:49:35 --> Model Class Initialized
INFO - 2018-03-29 16:49:35 --> Model Class Initialized
INFO - 2018-03-29 16:49:35 --> Model Class Initialized
INFO - 2018-03-29 16:49:35 --> Model Class Initialized
INFO - 2018-03-29 16:49:35 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 16:49:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-29 16:49:35 --> Final output sent to browser
DEBUG - 2018-03-29 16:49:35 --> Total execution time: 0.2262
INFO - 2018-03-29 11:19:37 --> Config Class Initialized
INFO - 2018-03-29 11:19:37 --> Hooks Class Initialized
DEBUG - 2018-03-29 11:19:37 --> UTF-8 Support Enabled
INFO - 2018-03-29 11:19:37 --> Utf8 Class Initialized
INFO - 2018-03-29 11:19:37 --> URI Class Initialized
INFO - 2018-03-29 11:19:37 --> Config Class Initialized
INFO - 2018-03-29 11:19:37 --> Hooks Class Initialized
DEBUG - 2018-03-29 11:19:37 --> UTF-8 Support Enabled
INFO - 2018-03-29 11:19:37 --> Utf8 Class Initialized
INFO - 2018-03-29 11:19:37 --> Router Class Initialized
INFO - 2018-03-29 11:19:37 --> URI Class Initialized
INFO - 2018-03-29 11:19:37 --> Output Class Initialized
INFO - 2018-03-29 11:19:37 --> Router Class Initialized
INFO - 2018-03-29 11:19:37 --> Security Class Initialized
INFO - 2018-03-29 11:19:37 --> Output Class Initialized
DEBUG - 2018-03-29 11:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 11:19:37 --> Input Class Initialized
INFO - 2018-03-29 11:19:37 --> Security Class Initialized
INFO - 2018-03-29 11:19:38 --> Language Class Initialized
DEBUG - 2018-03-29 11:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 11:19:38 --> Input Class Initialized
INFO - 2018-03-29 11:19:38 --> Language Class Initialized
INFO - 2018-03-29 11:19:39 --> Config Class Initialized
INFO - 2018-03-29 11:19:39 --> Hooks Class Initialized
DEBUG - 2018-03-29 11:19:39 --> UTF-8 Support Enabled
INFO - 2018-03-29 11:19:39 --> Utf8 Class Initialized
INFO - 2018-03-29 11:19:39 --> URI Class Initialized
INFO - 2018-03-29 11:19:39 --> Router Class Initialized
INFO - 2018-03-29 11:19:39 --> Output Class Initialized
INFO - 2018-03-29 11:19:39 --> Security Class Initialized
DEBUG - 2018-03-29 11:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 11:19:39 --> Input Class Initialized
INFO - 2018-03-29 11:19:39 --> Language Class Initialized
INFO - 2018-03-29 11:19:39 --> Language Class Initialized
INFO - 2018-03-29 11:19:39 --> Language Class Initialized
INFO - 2018-03-29 11:19:39 --> Config Class Initialized
INFO - 2018-03-29 11:19:39 --> Config Class Initialized
INFO - 2018-03-29 11:19:39 --> Loader Class Initialized
INFO - 2018-03-29 11:19:39 --> Loader Class Initialized
INFO - 2018-03-29 16:49:39 --> Helper loaded: url_helper
INFO - 2018-03-29 16:49:39 --> Helper loaded: url_helper
INFO - 2018-03-29 16:49:39 --> Helper loaded: notification_helper
INFO - 2018-03-29 16:49:39 --> Helper loaded: settings_helper
INFO - 2018-03-29 16:49:39 --> Helper loaded: notification_helper
INFO - 2018-03-29 16:49:39 --> Helper loaded: permission_helper
INFO - 2018-03-29 16:49:39 --> Helper loaded: settings_helper
INFO - 2018-03-29 16:49:39 --> Helper loaded: users_helper
INFO - 2018-03-29 16:49:39 --> Helper loaded: permission_helper
INFO - 2018-03-29 16:49:39 --> Helper loaded: users_helper
INFO - 2018-03-29 16:49:39 --> Database Driver Class Initialized
INFO - 2018-03-29 16:49:39 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:49:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:49:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 11:19:39 --> Language Class Initialized
DEBUG - 2018-03-29 16:49:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:49:39 --> Helper loaded: form_helper
INFO - 2018-03-29 16:49:39 --> Form Validation Class Initialized
INFO - 2018-03-29 16:49:39 --> Controller Class Initialized
INFO - 2018-03-29 16:49:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 11:19:39 --> Config Class Initialized
INFO - 2018-03-29 11:19:39 --> Loader Class Initialized
INFO - 2018-03-29 16:49:39 --> Helper loaded: form_helper
INFO - 2018-03-29 16:49:39 --> Form Validation Class Initialized
INFO - 2018-03-29 16:49:39 --> Controller Class Initialized
INFO - 2018-03-29 16:49:39 --> Helper loaded: url_helper
INFO - 2018-03-29 16:49:39 --> Model Class Initialized
INFO - 2018-03-29 16:49:39 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 16:49:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 16:49:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 16:49:39 --> Model Class Initialized
INFO - 2018-03-29 16:49:39 --> Model Class Initialized
INFO - 2018-03-29 16:49:39 --> Model Class Initialized
INFO - 2018-03-29 16:49:39 --> Model Class Initialized
INFO - 2018-03-29 16:49:39 --> Model Class Initialized
INFO - 2018-03-29 16:49:39 --> Model Class Initialized
INFO - 2018-03-29 16:49:39 --> Model Class Initialized
INFO - 2018-03-29 16:49:39 --> Model Class Initialized
INFO - 2018-03-29 16:49:39 --> Helper loaded: inflector_helper
INFO - 2018-03-29 16:49:39 --> Model Class Initialized
INFO - 2018-03-29 16:49:39 --> Model Class Initialized
INFO - 2018-03-29 16:49:39 --> Model Class Initialized
DEBUG - 2018-03-29 16:49:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 16:49:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 16:49:39 --> Model Class Initialized
INFO - 2018-03-29 16:49:39 --> Model Class Initialized
INFO - 2018-03-29 16:49:39 --> Model Class Initialized
INFO - 2018-03-29 16:49:39 --> Model Class Initialized
INFO - 2018-03-29 16:49:39 --> Model Class Initialized
INFO - 2018-03-29 16:49:39 --> Model Class Initialized
INFO - 2018-03-29 16:49:39 --> Model Class Initialized
INFO - 2018-03-29 16:49:39 --> Model Class Initialized
INFO - 2018-03-29 16:49:39 --> Model Class Initialized
INFO - 2018-03-29 16:49:39 --> Model Class Initialized
INFO - 2018-03-29 16:49:39 --> Model Class Initialized
INFO - 2018-03-29 16:49:39 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 16:49:39 --> Model Class Initialized
INFO - 2018-03-29 16:49:39 --> Model Class Initialized
INFO - 2018-03-29 16:49:39 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 16:49:39 --> Model Class Initialized
INFO - 2018-03-29 16:49:39 --> Final output sent to browser
DEBUG - 2018-03-29 16:49:39 --> Total execution time: 0.5421
INFO - 2018-03-29 16:49:39 --> Final output sent to browser
DEBUG - 2018-03-29 16:49:39 --> Total execution time: 2.1012
INFO - 2018-03-29 16:49:39 --> Helper loaded: notification_helper
INFO - 2018-03-29 16:49:39 --> Helper loaded: settings_helper
INFO - 2018-03-29 16:49:39 --> Helper loaded: permission_helper
INFO - 2018-03-29 16:49:39 --> Helper loaded: users_helper
INFO - 2018-03-29 16:49:40 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:49:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:49:40 --> Helper loaded: form_helper
INFO - 2018-03-29 16:49:40 --> Form Validation Class Initialized
INFO - 2018-03-29 16:49:40 --> Controller Class Initialized
INFO - 2018-03-29 16:49:40 --> Model Class Initialized
INFO - 2018-03-29 16:49:40 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 16:49:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 16:49:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 16:49:40 --> Model Class Initialized
INFO - 2018-03-29 16:49:40 --> Model Class Initialized
INFO - 2018-03-29 16:49:40 --> Model Class Initialized
INFO - 2018-03-29 16:49:40 --> Model Class Initialized
INFO - 2018-03-29 16:49:40 --> Model Class Initialized
INFO - 2018-03-29 16:49:40 --> Model Class Initialized
INFO - 2018-03-29 16:49:40 --> Model Class Initialized
INFO - 2018-03-29 16:49:40 --> Model Class Initialized
INFO - 2018-03-29 16:49:40 --> Model Class Initialized
INFO - 2018-03-29 16:49:40 --> Model Class Initialized
INFO - 2018-03-29 16:49:40 --> Model Class Initialized
INFO - 2018-03-29 16:49:40 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 16:49:40 --> Model Class Initialized
INFO - 2018-03-29 16:49:40 --> Final output sent to browser
DEBUG - 2018-03-29 16:49:40 --> Total execution time: 3.8466
INFO - 2018-03-29 11:19:41 --> Config Class Initialized
INFO - 2018-03-29 11:19:41 --> Hooks Class Initialized
DEBUG - 2018-03-29 11:19:41 --> UTF-8 Support Enabled
INFO - 2018-03-29 11:19:41 --> Utf8 Class Initialized
INFO - 2018-03-29 11:19:41 --> URI Class Initialized
INFO - 2018-03-29 11:19:41 --> Router Class Initialized
INFO - 2018-03-29 11:19:42 --> Output Class Initialized
INFO - 2018-03-29 11:19:42 --> Security Class Initialized
DEBUG - 2018-03-29 11:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 11:19:42 --> Input Class Initialized
INFO - 2018-03-29 11:19:42 --> Language Class Initialized
INFO - 2018-03-29 11:19:42 --> Language Class Initialized
INFO - 2018-03-29 11:19:42 --> Config Class Initialized
INFO - 2018-03-29 11:19:42 --> Loader Class Initialized
INFO - 2018-03-29 16:49:42 --> Helper loaded: url_helper
INFO - 2018-03-29 16:49:42 --> Helper loaded: notification_helper
INFO - 2018-03-29 16:49:42 --> Helper loaded: settings_helper
INFO - 2018-03-29 16:49:42 --> Helper loaded: permission_helper
INFO - 2018-03-29 16:49:42 --> Helper loaded: users_helper
INFO - 2018-03-29 16:49:43 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:49:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:49:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:49:43 --> Helper loaded: form_helper
INFO - 2018-03-29 16:49:43 --> Form Validation Class Initialized
INFO - 2018-03-29 16:49:43 --> Controller Class Initialized
INFO - 2018-03-29 16:49:43 --> Model Class Initialized
INFO - 2018-03-29 16:49:43 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 16:49:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 16:49:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 16:49:43 --> Model Class Initialized
INFO - 2018-03-29 16:49:43 --> Model Class Initialized
INFO - 2018-03-29 16:49:43 --> Model Class Initialized
INFO - 2018-03-29 16:49:43 --> Model Class Initialized
INFO - 2018-03-29 16:49:43 --> Model Class Initialized
INFO - 2018-03-29 16:49:43 --> Model Class Initialized
INFO - 2018-03-29 16:49:43 --> Model Class Initialized
INFO - 2018-03-29 16:49:43 --> Model Class Initialized
INFO - 2018-03-29 16:49:43 --> Model Class Initialized
INFO - 2018-03-29 16:49:43 --> Model Class Initialized
INFO - 2018-03-29 16:49:43 --> Model Class Initialized
INFO - 2018-03-29 16:49:43 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 16:49:44 --> Model Class Initialized
INFO - 2018-03-29 16:49:44 --> Final output sent to browser
DEBUG - 2018-03-29 16:49:44 --> Total execution time: 2.8499
INFO - 2018-03-29 11:19:46 --> Config Class Initialized
INFO - 2018-03-29 11:19:46 --> Hooks Class Initialized
DEBUG - 2018-03-29 11:19:46 --> UTF-8 Support Enabled
INFO - 2018-03-29 11:19:46 --> Utf8 Class Initialized
INFO - 2018-03-29 11:19:46 --> URI Class Initialized
INFO - 2018-03-29 11:19:46 --> Router Class Initialized
INFO - 2018-03-29 11:19:47 --> Output Class Initialized
INFO - 2018-03-29 11:19:47 --> Security Class Initialized
DEBUG - 2018-03-29 11:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 11:19:47 --> Input Class Initialized
INFO - 2018-03-29 11:19:47 --> Language Class Initialized
INFO - 2018-03-29 11:19:48 --> Language Class Initialized
INFO - 2018-03-29 11:19:48 --> Config Class Initialized
INFO - 2018-03-29 11:19:48 --> Loader Class Initialized
INFO - 2018-03-29 16:49:48 --> Helper loaded: url_helper
INFO - 2018-03-29 16:49:48 --> Helper loaded: notification_helper
INFO - 2018-03-29 16:49:48 --> Helper loaded: settings_helper
INFO - 2018-03-29 16:49:48 --> Helper loaded: permission_helper
INFO - 2018-03-29 16:49:48 --> Helper loaded: users_helper
INFO - 2018-03-29 16:49:48 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:49:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:49:48 --> Helper loaded: form_helper
INFO - 2018-03-29 16:49:48 --> Form Validation Class Initialized
INFO - 2018-03-29 16:49:48 --> Controller Class Initialized
INFO - 2018-03-29 16:49:48 --> Model Class Initialized
INFO - 2018-03-29 16:49:48 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 16:49:48 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 16:49:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 16:49:48 --> Model Class Initialized
INFO - 2018-03-29 16:49:48 --> Model Class Initialized
INFO - 2018-03-29 16:49:48 --> Model Class Initialized
INFO - 2018-03-29 16:49:48 --> Model Class Initialized
INFO - 2018-03-29 16:49:48 --> Model Class Initialized
INFO - 2018-03-29 16:49:48 --> Model Class Initialized
INFO - 2018-03-29 16:49:48 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-29 16:49:48 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-29 16:49:48 --> Final output sent to browser
DEBUG - 2018-03-29 16:49:48 --> Total execution time: 2.0369
INFO - 2018-03-29 11:19:50 --> Config Class Initialized
INFO - 2018-03-29 11:19:50 --> Hooks Class Initialized
DEBUG - 2018-03-29 11:19:50 --> UTF-8 Support Enabled
INFO - 2018-03-29 11:19:50 --> Utf8 Class Initialized
INFO - 2018-03-29 11:19:50 --> URI Class Initialized
INFO - 2018-03-29 11:19:50 --> Router Class Initialized
INFO - 2018-03-29 11:19:50 --> Output Class Initialized
INFO - 2018-03-29 11:19:50 --> Security Class Initialized
DEBUG - 2018-03-29 11:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 11:19:51 --> Input Class Initialized
INFO - 2018-03-29 11:19:51 --> Language Class Initialized
INFO - 2018-03-29 11:19:51 --> Language Class Initialized
INFO - 2018-03-29 11:19:51 --> Config Class Initialized
INFO - 2018-03-29 11:19:51 --> Loader Class Initialized
INFO - 2018-03-29 16:49:52 --> Helper loaded: url_helper
INFO - 2018-03-29 16:49:52 --> Helper loaded: notification_helper
INFO - 2018-03-29 16:49:52 --> Helper loaded: settings_helper
INFO - 2018-03-29 16:49:52 --> Helper loaded: permission_helper
INFO - 2018-03-29 16:49:52 --> Helper loaded: users_helper
INFO - 2018-03-29 16:49:52 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:49:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:49:53 --> Helper loaded: form_helper
INFO - 2018-03-29 16:49:53 --> Form Validation Class Initialized
INFO - 2018-03-29 16:49:53 --> Controller Class Initialized
INFO - 2018-03-29 16:49:53 --> Model Class Initialized
INFO - 2018-03-29 16:49:53 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 16:49:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 16:49:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 16:49:53 --> Model Class Initialized
INFO - 2018-03-29 16:49:54 --> Model Class Initialized
INFO - 2018-03-29 16:49:54 --> Model Class Initialized
INFO - 2018-03-29 16:49:54 --> Model Class Initialized
INFO - 2018-03-29 16:49:54 --> Model Class Initialized
INFO - 2018-03-29 16:49:54 --> Model Class Initialized
INFO - 2018-03-29 16:49:54 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-29 16:49:54 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-29 16:49:54 --> Final output sent to browser
DEBUG - 2018-03-29 16:49:54 --> Total execution time: 4.1200
INFO - 2018-03-29 11:20:15 --> Config Class Initialized
INFO - 2018-03-29 11:20:15 --> Hooks Class Initialized
DEBUG - 2018-03-29 11:20:15 --> UTF-8 Support Enabled
INFO - 2018-03-29 11:20:15 --> Utf8 Class Initialized
INFO - 2018-03-29 11:20:15 --> URI Class Initialized
INFO - 2018-03-29 11:20:15 --> Router Class Initialized
INFO - 2018-03-29 11:20:15 --> Output Class Initialized
INFO - 2018-03-29 11:20:15 --> Security Class Initialized
DEBUG - 2018-03-29 11:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 11:20:15 --> Input Class Initialized
INFO - 2018-03-29 11:20:15 --> Language Class Initialized
INFO - 2018-03-29 11:20:15 --> Language Class Initialized
INFO - 2018-03-29 11:20:15 --> Config Class Initialized
INFO - 2018-03-29 11:20:15 --> Loader Class Initialized
INFO - 2018-03-29 16:50:15 --> Helper loaded: url_helper
INFO - 2018-03-29 16:50:15 --> Helper loaded: notification_helper
INFO - 2018-03-29 16:50:15 --> Helper loaded: settings_helper
INFO - 2018-03-29 16:50:15 --> Helper loaded: permission_helper
INFO - 2018-03-29 16:50:15 --> Helper loaded: users_helper
INFO - 2018-03-29 16:50:15 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:50:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:50:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:50:15 --> Helper loaded: form_helper
INFO - 2018-03-29 16:50:15 --> Form Validation Class Initialized
INFO - 2018-03-29 16:50:15 --> Controller Class Initialized
INFO - 2018-03-29 16:50:15 --> Model Class Initialized
INFO - 2018-03-29 16:50:15 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 16:50:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 16:50:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 16:50:15 --> Model Class Initialized
INFO - 2018-03-29 16:50:15 --> Model Class Initialized
INFO - 2018-03-29 16:50:15 --> Model Class Initialized
INFO - 2018-03-29 16:50:15 --> Model Class Initialized
INFO - 2018-03-29 16:50:15 --> Model Class Initialized
INFO - 2018-03-29 16:50:15 --> Model Class Initialized
INFO - 2018-03-29 16:50:15 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-29 16:50:15 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-29 16:50:15 --> Final output sent to browser
DEBUG - 2018-03-29 16:50:15 --> Total execution time: 0.1216
INFO - 2018-03-29 11:20:25 --> Config Class Initialized
INFO - 2018-03-29 11:20:25 --> Hooks Class Initialized
DEBUG - 2018-03-29 11:20:25 --> UTF-8 Support Enabled
INFO - 2018-03-29 11:20:25 --> Utf8 Class Initialized
INFO - 2018-03-29 11:20:25 --> URI Class Initialized
INFO - 2018-03-29 11:20:25 --> Router Class Initialized
INFO - 2018-03-29 11:20:25 --> Output Class Initialized
INFO - 2018-03-29 11:20:25 --> Security Class Initialized
DEBUG - 2018-03-29 11:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 11:20:25 --> Input Class Initialized
INFO - 2018-03-29 11:20:25 --> Language Class Initialized
INFO - 2018-03-29 11:20:25 --> Language Class Initialized
INFO - 2018-03-29 11:20:25 --> Config Class Initialized
INFO - 2018-03-29 11:20:25 --> Loader Class Initialized
INFO - 2018-03-29 16:50:25 --> Helper loaded: url_helper
INFO - 2018-03-29 16:50:25 --> Helper loaded: notification_helper
INFO - 2018-03-29 16:50:25 --> Helper loaded: settings_helper
INFO - 2018-03-29 16:50:25 --> Helper loaded: permission_helper
INFO - 2018-03-29 16:50:25 --> Helper loaded: users_helper
INFO - 2018-03-29 16:50:25 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:50:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:50:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:50:25 --> Helper loaded: form_helper
INFO - 2018-03-29 16:50:25 --> Form Validation Class Initialized
INFO - 2018-03-29 16:50:25 --> Controller Class Initialized
INFO - 2018-03-29 16:50:25 --> Model Class Initialized
INFO - 2018-03-29 16:50:25 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 16:50:25 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 16:50:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 16:50:25 --> Model Class Initialized
INFO - 2018-03-29 16:50:25 --> Model Class Initialized
INFO - 2018-03-29 16:50:25 --> Model Class Initialized
INFO - 2018-03-29 16:50:25 --> Model Class Initialized
INFO - 2018-03-29 16:50:25 --> Model Class Initialized
INFO - 2018-03-29 16:50:25 --> Model Class Initialized
INFO - 2018-03-29 16:50:25 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-29 16:50:25 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-29 16:50:25 --> Final output sent to browser
DEBUG - 2018-03-29 16:50:25 --> Total execution time: 0.2854
INFO - 2018-03-29 11:20:29 --> Config Class Initialized
INFO - 2018-03-29 11:20:29 --> Hooks Class Initialized
DEBUG - 2018-03-29 11:20:29 --> UTF-8 Support Enabled
INFO - 2018-03-29 11:20:29 --> Utf8 Class Initialized
INFO - 2018-03-29 11:20:29 --> URI Class Initialized
INFO - 2018-03-29 11:20:29 --> Router Class Initialized
INFO - 2018-03-29 11:20:29 --> Output Class Initialized
INFO - 2018-03-29 11:20:29 --> Security Class Initialized
DEBUG - 2018-03-29 11:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 11:20:29 --> Input Class Initialized
INFO - 2018-03-29 11:20:29 --> Language Class Initialized
INFO - 2018-03-29 11:20:29 --> Language Class Initialized
INFO - 2018-03-29 11:20:29 --> Config Class Initialized
INFO - 2018-03-29 11:20:29 --> Loader Class Initialized
INFO - 2018-03-29 16:50:29 --> Helper loaded: url_helper
INFO - 2018-03-29 16:50:29 --> Helper loaded: notification_helper
INFO - 2018-03-29 16:50:29 --> Helper loaded: settings_helper
INFO - 2018-03-29 16:50:29 --> Helper loaded: permission_helper
INFO - 2018-03-29 16:50:29 --> Helper loaded: users_helper
INFO - 2018-03-29 16:50:29 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:50:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:50:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:50:29 --> Helper loaded: form_helper
INFO - 2018-03-29 16:50:29 --> Form Validation Class Initialized
INFO - 2018-03-29 16:50:29 --> Controller Class Initialized
INFO - 2018-03-29 16:50:30 --> Model Class Initialized
INFO - 2018-03-29 16:50:30 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 16:50:30 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 16:50:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 16:50:30 --> Model Class Initialized
INFO - 2018-03-29 16:50:30 --> Model Class Initialized
INFO - 2018-03-29 16:50:30 --> Model Class Initialized
INFO - 2018-03-29 16:50:30 --> Model Class Initialized
INFO - 2018-03-29 16:50:30 --> Final output sent to browser
DEBUG - 2018-03-29 16:50:30 --> Total execution time: 0.1341
INFO - 2018-03-29 11:20:30 --> Config Class Initialized
INFO - 2018-03-29 11:20:30 --> Hooks Class Initialized
DEBUG - 2018-03-29 11:20:30 --> UTF-8 Support Enabled
INFO - 2018-03-29 11:20:30 --> Utf8 Class Initialized
INFO - 2018-03-29 11:20:30 --> URI Class Initialized
INFO - 2018-03-29 11:20:30 --> Router Class Initialized
INFO - 2018-03-29 11:20:30 --> Output Class Initialized
INFO - 2018-03-29 11:20:30 --> Security Class Initialized
DEBUG - 2018-03-29 11:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 11:20:30 --> Input Class Initialized
INFO - 2018-03-29 11:20:30 --> Language Class Initialized
INFO - 2018-03-29 11:20:30 --> Language Class Initialized
INFO - 2018-03-29 11:20:30 --> Config Class Initialized
INFO - 2018-03-29 11:20:30 --> Loader Class Initialized
INFO - 2018-03-29 16:50:30 --> Helper loaded: url_helper
INFO - 2018-03-29 16:50:30 --> Helper loaded: notification_helper
INFO - 2018-03-29 16:50:30 --> Helper loaded: settings_helper
INFO - 2018-03-29 16:50:30 --> Helper loaded: permission_helper
INFO - 2018-03-29 16:50:30 --> Helper loaded: users_helper
INFO - 2018-03-29 16:50:31 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:50:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:50:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:50:31 --> Helper loaded: form_helper
INFO - 2018-03-29 16:50:31 --> Form Validation Class Initialized
INFO - 2018-03-29 16:50:31 --> Controller Class Initialized
INFO - 2018-03-29 16:50:31 --> Model Class Initialized
INFO - 2018-03-29 16:50:31 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 16:50:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 16:50:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 16:50:31 --> Model Class Initialized
INFO - 2018-03-29 16:50:31 --> Model Class Initialized
INFO - 2018-03-29 16:50:31 --> Model Class Initialized
INFO - 2018-03-29 16:50:31 --> Model Class Initialized
INFO - 2018-03-29 16:50:31 --> Final output sent to browser
DEBUG - 2018-03-29 16:50:31 --> Total execution time: 0.2644
INFO - 2018-03-29 11:20:32 --> Config Class Initialized
INFO - 2018-03-29 11:20:32 --> Hooks Class Initialized
DEBUG - 2018-03-29 11:20:32 --> UTF-8 Support Enabled
INFO - 2018-03-29 11:20:32 --> Utf8 Class Initialized
INFO - 2018-03-29 11:20:32 --> URI Class Initialized
INFO - 2018-03-29 11:20:32 --> Router Class Initialized
INFO - 2018-03-29 11:20:32 --> Output Class Initialized
INFO - 2018-03-29 11:20:32 --> Security Class Initialized
DEBUG - 2018-03-29 11:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 11:20:32 --> Input Class Initialized
INFO - 2018-03-29 11:20:32 --> Language Class Initialized
INFO - 2018-03-29 11:20:32 --> Language Class Initialized
INFO - 2018-03-29 11:20:32 --> Config Class Initialized
INFO - 2018-03-29 11:20:32 --> Loader Class Initialized
INFO - 2018-03-29 16:50:32 --> Helper loaded: url_helper
INFO - 2018-03-29 16:50:32 --> Helper loaded: notification_helper
INFO - 2018-03-29 16:50:32 --> Helper loaded: settings_helper
INFO - 2018-03-29 16:50:32 --> Helper loaded: permission_helper
INFO - 2018-03-29 16:50:32 --> Helper loaded: users_helper
INFO - 2018-03-29 16:50:32 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:50:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:50:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:50:32 --> Helper loaded: form_helper
INFO - 2018-03-29 16:50:32 --> Form Validation Class Initialized
INFO - 2018-03-29 16:50:32 --> Controller Class Initialized
INFO - 2018-03-29 16:50:32 --> Model Class Initialized
INFO - 2018-03-29 16:50:32 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 16:50:32 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 16:50:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 16:50:32 --> Model Class Initialized
INFO - 2018-03-29 16:50:32 --> Model Class Initialized
INFO - 2018-03-29 16:50:32 --> Model Class Initialized
INFO - 2018-03-29 16:50:32 --> Model Class Initialized
INFO - 2018-03-29 16:50:32 --> Model Class Initialized
INFO - 2018-03-29 16:50:32 --> Model Class Initialized
INFO - 2018-03-29 16:50:32 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-29 16:50:32 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-29 16:50:32 --> Final output sent to browser
DEBUG - 2018-03-29 16:50:32 --> Total execution time: 0.1479
INFO - 2018-03-29 11:20:40 --> Config Class Initialized
INFO - 2018-03-29 11:20:40 --> Hooks Class Initialized
DEBUG - 2018-03-29 11:20:40 --> UTF-8 Support Enabled
INFO - 2018-03-29 11:20:40 --> Utf8 Class Initialized
INFO - 2018-03-29 11:20:40 --> URI Class Initialized
INFO - 2018-03-29 11:20:40 --> Router Class Initialized
INFO - 2018-03-29 11:20:41 --> Output Class Initialized
INFO - 2018-03-29 11:20:41 --> Security Class Initialized
DEBUG - 2018-03-29 11:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 11:20:41 --> Input Class Initialized
INFO - 2018-03-29 11:20:41 --> Language Class Initialized
INFO - 2018-03-29 11:20:41 --> Config Class Initialized
INFO - 2018-03-29 11:20:41 --> Hooks Class Initialized
DEBUG - 2018-03-29 11:20:41 --> UTF-8 Support Enabled
INFO - 2018-03-29 11:20:41 --> Utf8 Class Initialized
INFO - 2018-03-29 11:20:41 --> URI Class Initialized
INFO - 2018-03-29 11:20:41 --> Router Class Initialized
INFO - 2018-03-29 11:20:41 --> Output Class Initialized
INFO - 2018-03-29 11:20:41 --> Security Class Initialized
DEBUG - 2018-03-29 11:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 11:20:41 --> Input Class Initialized
INFO - 2018-03-29 11:20:41 --> Language Class Initialized
INFO - 2018-03-29 11:20:41 --> Language Class Initialized
INFO - 2018-03-29 11:20:41 --> Config Class Initialized
INFO - 2018-03-29 11:20:41 --> Loader Class Initialized
INFO - 2018-03-29 16:50:41 --> Helper loaded: url_helper
INFO - 2018-03-29 16:50:41 --> Helper loaded: notification_helper
INFO - 2018-03-29 16:50:41 --> Helper loaded: settings_helper
INFO - 2018-03-29 16:50:41 --> Helper loaded: permission_helper
INFO - 2018-03-29 16:50:41 --> Helper loaded: users_helper
INFO - 2018-03-29 16:50:41 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:50:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:50:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:50:41 --> Helper loaded: form_helper
INFO - 2018-03-29 16:50:41 --> Form Validation Class Initialized
INFO - 2018-03-29 16:50:41 --> Controller Class Initialized
INFO - 2018-03-29 16:50:41 --> Model Class Initialized
INFO - 2018-03-29 16:50:41 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 16:50:41 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 16:50:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 16:50:41 --> Model Class Initialized
INFO - 2018-03-29 16:50:41 --> Model Class Initialized
INFO - 2018-03-29 16:50:41 --> Model Class Initialized
INFO - 2018-03-29 16:50:41 --> Model Class Initialized
INFO - 2018-03-29 16:50:41 --> Model Class Initialized
INFO - 2018-03-29 16:50:41 --> Model Class Initialized
INFO - 2018-03-29 16:50:41 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-29 16:50:41 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-29 16:50:41 --> Final output sent to browser
DEBUG - 2018-03-29 16:50:41 --> Total execution time: 0.2481
INFO - 2018-03-29 11:20:42 --> Language Class Initialized
INFO - 2018-03-29 11:20:42 --> Config Class Initialized
INFO - 2018-03-29 11:20:42 --> Loader Class Initialized
INFO - 2018-03-29 16:50:42 --> Helper loaded: url_helper
INFO - 2018-03-29 16:50:42 --> Helper loaded: notification_helper
INFO - 2018-03-29 16:50:42 --> Helper loaded: settings_helper
INFO - 2018-03-29 16:50:42 --> Helper loaded: permission_helper
INFO - 2018-03-29 16:50:42 --> Helper loaded: users_helper
INFO - 2018-03-29 16:50:42 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:50:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:50:43 --> Helper loaded: form_helper
INFO - 2018-03-29 16:50:43 --> Form Validation Class Initialized
INFO - 2018-03-29 16:50:43 --> Controller Class Initialized
INFO - 2018-03-29 16:50:43 --> Model Class Initialized
INFO - 2018-03-29 16:50:43 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 16:50:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 16:50:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 16:50:43 --> Model Class Initialized
INFO - 2018-03-29 16:50:43 --> Model Class Initialized
INFO - 2018-03-29 16:50:43 --> Model Class Initialized
INFO - 2018-03-29 16:50:43 --> Model Class Initialized
INFO - 2018-03-29 16:50:43 --> Model Class Initialized
INFO - 2018-03-29 16:50:43 --> Model Class Initialized
INFO - 2018-03-29 16:50:43 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-29 16:50:44 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-29 16:50:44 --> Final output sent to browser
DEBUG - 2018-03-29 16:50:44 --> Total execution time: 4.2107
INFO - 2018-03-29 12:37:09 --> Config Class Initialized
INFO - 2018-03-29 12:37:09 --> Hooks Class Initialized
DEBUG - 2018-03-29 12:37:09 --> UTF-8 Support Enabled
INFO - 2018-03-29 12:37:09 --> Utf8 Class Initialized
INFO - 2018-03-29 12:37:09 --> URI Class Initialized
INFO - 2018-03-29 12:37:10 --> Router Class Initialized
INFO - 2018-03-29 12:37:10 --> Output Class Initialized
INFO - 2018-03-29 12:37:10 --> Security Class Initialized
DEBUG - 2018-03-29 12:37:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 12:37:10 --> Input Class Initialized
INFO - 2018-03-29 12:37:11 --> Language Class Initialized
INFO - 2018-03-29 12:37:12 --> Language Class Initialized
INFO - 2018-03-29 12:37:12 --> Config Class Initialized
INFO - 2018-03-29 12:37:12 --> Loader Class Initialized
INFO - 2018-03-29 18:07:12 --> Helper loaded: url_helper
INFO - 2018-03-29 18:07:12 --> Helper loaded: notification_helper
INFO - 2018-03-29 18:07:12 --> Helper loaded: settings_helper
INFO - 2018-03-29 18:07:12 --> Helper loaded: permission_helper
INFO - 2018-03-29 18:07:12 --> Helper loaded: users_helper
INFO - 2018-03-29 12:37:12 --> Config Class Initialized
INFO - 2018-03-29 12:37:12 --> Hooks Class Initialized
DEBUG - 2018-03-29 12:37:12 --> UTF-8 Support Enabled
INFO - 2018-03-29 12:37:12 --> Utf8 Class Initialized
INFO - 2018-03-29 12:37:12 --> URI Class Initialized
INFO - 2018-03-29 12:37:12 --> Router Class Initialized
INFO - 2018-03-29 12:37:12 --> Output Class Initialized
INFO - 2018-03-29 12:37:12 --> Security Class Initialized
DEBUG - 2018-03-29 12:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 12:37:12 --> Input Class Initialized
INFO - 2018-03-29 12:37:12 --> Language Class Initialized
INFO - 2018-03-29 12:37:12 --> Language Class Initialized
INFO - 2018-03-29 12:37:12 --> Config Class Initialized
INFO - 2018-03-29 12:37:12 --> Loader Class Initialized
INFO - 2018-03-29 18:07:12 --> Helper loaded: url_helper
INFO - 2018-03-29 18:07:12 --> Helper loaded: notification_helper
INFO - 2018-03-29 18:07:12 --> Helper loaded: settings_helper
INFO - 2018-03-29 18:07:12 --> Helper loaded: permission_helper
INFO - 2018-03-29 18:07:12 --> Helper loaded: users_helper
INFO - 2018-03-29 18:07:12 --> Database Driver Class Initialized
DEBUG - 2018-03-29 18:07:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 18:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 18:07:12 --> Helper loaded: form_helper
INFO - 2018-03-29 18:07:12 --> Form Validation Class Initialized
INFO - 2018-03-29 18:07:12 --> Controller Class Initialized
INFO - 2018-03-29 18:07:12 --> Model Class Initialized
INFO - 2018-03-29 18:07:12 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 18:07:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 18:07:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 18:07:12 --> Model Class Initialized
INFO - 2018-03-29 18:07:12 --> Model Class Initialized
INFO - 2018-03-29 18:07:12 --> Model Class Initialized
INFO - 2018-03-29 18:07:12 --> Model Class Initialized
INFO - 2018-03-29 18:07:12 --> Model Class Initialized
INFO - 2018-03-29 18:07:12 --> Model Class Initialized
INFO - 2018-03-29 18:07:12 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 18:07:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-29 18:07:12 --> Final output sent to browser
DEBUG - 2018-03-29 18:07:12 --> Total execution time: 0.1296
INFO - 2018-03-29 18:07:13 --> Database Driver Class Initialized
DEBUG - 2018-03-29 18:07:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 18:07:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 18:07:13 --> Helper loaded: form_helper
INFO - 2018-03-29 18:07:13 --> Form Validation Class Initialized
INFO - 2018-03-29 18:07:13 --> Controller Class Initialized
INFO - 2018-03-29 18:07:13 --> Model Class Initialized
INFO - 2018-03-29 18:07:13 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 18:07:13 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 18:07:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 18:07:13 --> Model Class Initialized
INFO - 2018-03-29 18:07:13 --> Model Class Initialized
INFO - 2018-03-29 18:07:13 --> Model Class Initialized
INFO - 2018-03-29 18:07:13 --> Model Class Initialized
INFO - 2018-03-29 18:07:13 --> Model Class Initialized
INFO - 2018-03-29 18:07:13 --> Model Class Initialized
INFO - 2018-03-29 18:07:13 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 18:07:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-29 18:07:13 --> Final output sent to browser
DEBUG - 2018-03-29 18:07:13 --> Total execution time: 4.0114
INFO - 2018-03-29 12:37:13 --> Config Class Initialized
INFO - 2018-03-29 12:37:13 --> Hooks Class Initialized
DEBUG - 2018-03-29 12:37:13 --> UTF-8 Support Enabled
INFO - 2018-03-29 12:37:13 --> Utf8 Class Initialized
INFO - 2018-03-29 12:37:13 --> URI Class Initialized
INFO - 2018-03-29 12:37:13 --> Router Class Initialized
INFO - 2018-03-29 12:37:13 --> Output Class Initialized
INFO - 2018-03-29 12:37:13 --> Security Class Initialized
DEBUG - 2018-03-29 12:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 12:37:13 --> Input Class Initialized
INFO - 2018-03-29 12:37:13 --> Language Class Initialized
INFO - 2018-03-29 12:37:13 --> Language Class Initialized
INFO - 2018-03-29 12:37:13 --> Config Class Initialized
INFO - 2018-03-29 12:37:13 --> Loader Class Initialized
INFO - 2018-03-29 18:07:13 --> Helper loaded: url_helper
INFO - 2018-03-29 18:07:13 --> Helper loaded: notification_helper
INFO - 2018-03-29 18:07:13 --> Helper loaded: settings_helper
INFO - 2018-03-29 18:07:13 --> Helper loaded: permission_helper
INFO - 2018-03-29 18:07:13 --> Helper loaded: users_helper
INFO - 2018-03-29 18:07:13 --> Database Driver Class Initialized
DEBUG - 2018-03-29 18:07:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 18:07:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 18:07:13 --> Helper loaded: form_helper
INFO - 2018-03-29 18:07:13 --> Form Validation Class Initialized
INFO - 2018-03-29 18:07:13 --> Controller Class Initialized
INFO - 2018-03-29 18:07:13 --> Model Class Initialized
INFO - 2018-03-29 18:07:13 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 18:07:13 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 18:07:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 18:07:13 --> Model Class Initialized
INFO - 2018-03-29 18:07:13 --> Model Class Initialized
INFO - 2018-03-29 18:07:13 --> Model Class Initialized
INFO - 2018-03-29 18:07:13 --> Model Class Initialized
INFO - 2018-03-29 18:07:13 --> Model Class Initialized
INFO - 2018-03-29 18:07:13 --> Model Class Initialized
INFO - 2018-03-29 18:07:13 --> Model Class Initialized
INFO - 2018-03-29 18:07:13 --> Model Class Initialized
INFO - 2018-03-29 18:07:13 --> Model Class Initialized
INFO - 2018-03-29 18:07:13 --> Model Class Initialized
INFO - 2018-03-29 18:07:13 --> Model Class Initialized
INFO - 2018-03-29 18:07:13 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 18:07:13 --> Model Class Initialized
INFO - 2018-03-29 18:07:13 --> Final output sent to browser
DEBUG - 2018-03-29 18:07:13 --> Total execution time: 0.1507
INFO - 2018-03-29 12:37:13 --> Config Class Initialized
INFO - 2018-03-29 12:37:13 --> Hooks Class Initialized
DEBUG - 2018-03-29 12:37:13 --> UTF-8 Support Enabled
INFO - 2018-03-29 12:37:13 --> Utf8 Class Initialized
INFO - 2018-03-29 12:37:13 --> URI Class Initialized
INFO - 2018-03-29 12:37:13 --> Router Class Initialized
INFO - 2018-03-29 12:37:13 --> Output Class Initialized
INFO - 2018-03-29 12:37:13 --> Security Class Initialized
DEBUG - 2018-03-29 12:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 12:37:13 --> Input Class Initialized
INFO - 2018-03-29 12:37:13 --> Language Class Initialized
INFO - 2018-03-29 12:37:13 --> Language Class Initialized
INFO - 2018-03-29 12:37:13 --> Config Class Initialized
INFO - 2018-03-29 12:37:13 --> Loader Class Initialized
INFO - 2018-03-29 18:07:13 --> Helper loaded: url_helper
INFO - 2018-03-29 18:07:13 --> Helper loaded: notification_helper
INFO - 2018-03-29 18:07:13 --> Helper loaded: settings_helper
INFO - 2018-03-29 18:07:13 --> Helper loaded: permission_helper
INFO - 2018-03-29 18:07:13 --> Helper loaded: users_helper
INFO - 2018-03-29 18:07:14 --> Database Driver Class Initialized
DEBUG - 2018-03-29 18:07:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 18:07:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 18:07:14 --> Helper loaded: form_helper
INFO - 2018-03-29 18:07:14 --> Form Validation Class Initialized
INFO - 2018-03-29 18:07:14 --> Controller Class Initialized
INFO - 2018-03-29 18:07:14 --> Model Class Initialized
INFO - 2018-03-29 18:07:14 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 18:07:14 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 18:07:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 18:07:14 --> Model Class Initialized
INFO - 2018-03-29 18:07:14 --> Model Class Initialized
INFO - 2018-03-29 18:07:14 --> Model Class Initialized
INFO - 2018-03-29 18:07:14 --> Model Class Initialized
INFO - 2018-03-29 18:07:14 --> Model Class Initialized
INFO - 2018-03-29 18:07:14 --> Model Class Initialized
INFO - 2018-03-29 18:07:14 --> Model Class Initialized
INFO - 2018-03-29 18:07:14 --> Model Class Initialized
INFO - 2018-03-29 18:07:14 --> Model Class Initialized
INFO - 2018-03-29 18:07:14 --> Model Class Initialized
INFO - 2018-03-29 18:07:14 --> Model Class Initialized
INFO - 2018-03-29 18:07:14 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 18:07:14 --> Model Class Initialized
INFO - 2018-03-29 18:07:14 --> Final output sent to browser
DEBUG - 2018-03-29 18:07:14 --> Total execution time: 0.7988
INFO - 2018-03-29 12:37:34 --> Config Class Initialized
INFO - 2018-03-29 12:37:34 --> Hooks Class Initialized
DEBUG - 2018-03-29 12:37:34 --> UTF-8 Support Enabled
INFO - 2018-03-29 12:37:34 --> Utf8 Class Initialized
INFO - 2018-03-29 12:37:34 --> URI Class Initialized
INFO - 2018-03-29 12:37:34 --> Router Class Initialized
INFO - 2018-03-29 12:37:34 --> Output Class Initialized
INFO - 2018-03-29 12:37:34 --> Security Class Initialized
DEBUG - 2018-03-29 12:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 12:37:34 --> Input Class Initialized
INFO - 2018-03-29 12:37:34 --> Language Class Initialized
INFO - 2018-03-29 12:37:34 --> Language Class Initialized
INFO - 2018-03-29 12:37:34 --> Config Class Initialized
INFO - 2018-03-29 12:37:34 --> Loader Class Initialized
INFO - 2018-03-29 18:07:34 --> Helper loaded: url_helper
INFO - 2018-03-29 18:07:34 --> Helper loaded: notification_helper
INFO - 2018-03-29 18:07:34 --> Helper loaded: settings_helper
INFO - 2018-03-29 18:07:34 --> Helper loaded: permission_helper
INFO - 2018-03-29 18:07:34 --> Helper loaded: users_helper
INFO - 2018-03-29 18:07:34 --> Database Driver Class Initialized
DEBUG - 2018-03-29 18:07:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 18:07:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 18:07:34 --> Helper loaded: form_helper
INFO - 2018-03-29 18:07:34 --> Form Validation Class Initialized
INFO - 2018-03-29 18:07:34 --> Controller Class Initialized
INFO - 2018-03-29 18:07:34 --> Model Class Initialized
INFO - 2018-03-29 18:07:34 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 18:07:34 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 18:07:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 18:07:34 --> Model Class Initialized
INFO - 2018-03-29 18:07:34 --> Model Class Initialized
INFO - 2018-03-29 18:07:34 --> Model Class Initialized
INFO - 2018-03-29 18:07:34 --> Model Class Initialized
INFO - 2018-03-29 18:07:34 --> Model Class Initialized
INFO - 2018-03-29 18:07:34 --> Model Class Initialized
INFO - 2018-03-29 18:07:34 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-29 18:07:34 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-29 18:07:34 --> Final output sent to browser
DEBUG - 2018-03-29 18:07:34 --> Total execution time: 0.1254
INFO - 2018-03-29 12:37:39 --> Config Class Initialized
INFO - 2018-03-29 12:37:39 --> Hooks Class Initialized
DEBUG - 2018-03-29 12:37:39 --> UTF-8 Support Enabled
INFO - 2018-03-29 12:37:39 --> Utf8 Class Initialized
INFO - 2018-03-29 12:37:39 --> URI Class Initialized
INFO - 2018-03-29 12:37:39 --> Router Class Initialized
INFO - 2018-03-29 12:37:39 --> Output Class Initialized
INFO - 2018-03-29 12:37:39 --> Security Class Initialized
DEBUG - 2018-03-29 12:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 12:37:39 --> Input Class Initialized
INFO - 2018-03-29 12:37:39 --> Language Class Initialized
INFO - 2018-03-29 12:37:40 --> Language Class Initialized
INFO - 2018-03-29 12:37:40 --> Config Class Initialized
INFO - 2018-03-29 12:37:40 --> Loader Class Initialized
INFO - 2018-03-29 18:07:40 --> Helper loaded: url_helper
INFO - 2018-03-29 18:07:40 --> Helper loaded: notification_helper
INFO - 2018-03-29 18:07:40 --> Helper loaded: settings_helper
INFO - 2018-03-29 18:07:40 --> Helper loaded: permission_helper
INFO - 2018-03-29 18:07:40 --> Helper loaded: users_helper
INFO - 2018-03-29 18:07:40 --> Database Driver Class Initialized
DEBUG - 2018-03-29 18:07:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 18:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 18:07:41 --> Helper loaded: form_helper
INFO - 2018-03-29 18:07:41 --> Form Validation Class Initialized
INFO - 2018-03-29 18:07:41 --> Controller Class Initialized
INFO - 2018-03-29 12:37:41 --> Config Class Initialized
INFO - 2018-03-29 12:37:41 --> Hooks Class Initialized
DEBUG - 2018-03-29 12:37:41 --> UTF-8 Support Enabled
INFO - 2018-03-29 12:37:41 --> Utf8 Class Initialized
INFO - 2018-03-29 12:37:41 --> URI Class Initialized
INFO - 2018-03-29 12:37:41 --> Router Class Initialized
INFO - 2018-03-29 12:37:41 --> Output Class Initialized
INFO - 2018-03-29 12:37:41 --> Security Class Initialized
DEBUG - 2018-03-29 12:37:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 12:37:42 --> Input Class Initialized
INFO - 2018-03-29 18:07:42 --> Model Class Initialized
INFO - 2018-03-29 12:37:42 --> Language Class Initialized
INFO - 2018-03-29 18:07:42 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 18:07:42 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 18:07:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 18:07:42 --> Model Class Initialized
INFO - 2018-03-29 18:07:42 --> Model Class Initialized
INFO - 2018-03-29 18:07:42 --> Model Class Initialized
INFO - 2018-03-29 18:07:42 --> Model Class Initialized
INFO - 2018-03-29 18:07:42 --> Model Class Initialized
INFO - 2018-03-29 18:07:42 --> Model Class Initialized
INFO - 2018-03-29 18:07:42 --> Model Class Initialized
INFO - 2018-03-29 18:07:42 --> Model Class Initialized
INFO - 2018-03-29 18:07:42 --> Model Class Initialized
INFO - 2018-03-29 18:07:42 --> Model Class Initialized
INFO - 2018-03-29 18:07:42 --> Model Class Initialized
INFO - 2018-03-29 18:07:42 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 18:07:42 --> Final output sent to browser
DEBUG - 2018-03-29 18:07:42 --> Total execution time: 2.5061
INFO - 2018-03-29 12:37:42 --> Language Class Initialized
INFO - 2018-03-29 12:37:42 --> Config Class Initialized
INFO - 2018-03-29 12:37:42 --> Loader Class Initialized
INFO - 2018-03-29 18:07:42 --> Helper loaded: url_helper
INFO - 2018-03-29 18:07:42 --> Helper loaded: notification_helper
INFO - 2018-03-29 18:07:42 --> Helper loaded: settings_helper
INFO - 2018-03-29 18:07:42 --> Helper loaded: permission_helper
INFO - 2018-03-29 12:37:42 --> Config Class Initialized
INFO - 2018-03-29 12:37:42 --> Hooks Class Initialized
DEBUG - 2018-03-29 12:37:43 --> UTF-8 Support Enabled
INFO - 2018-03-29 12:37:43 --> Utf8 Class Initialized
INFO - 2018-03-29 12:37:43 --> URI Class Initialized
INFO - 2018-03-29 12:37:43 --> Router Class Initialized
INFO - 2018-03-29 12:37:43 --> Output Class Initialized
INFO - 2018-03-29 12:37:43 --> Security Class Initialized
DEBUG - 2018-03-29 12:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 12:37:43 --> Input Class Initialized
INFO - 2018-03-29 12:37:43 --> Language Class Initialized
INFO - 2018-03-29 18:07:43 --> Helper loaded: users_helper
INFO - 2018-03-29 12:37:43 --> Language Class Initialized
INFO - 2018-03-29 12:37:43 --> Config Class Initialized
INFO - 2018-03-29 12:37:43 --> Loader Class Initialized
INFO - 2018-03-29 18:07:43 --> Database Driver Class Initialized
DEBUG - 2018-03-29 18:07:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 18:07:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 18:07:43 --> Helper loaded: form_helper
INFO - 2018-03-29 18:07:43 --> Form Validation Class Initialized
INFO - 2018-03-29 18:07:43 --> Controller Class Initialized
INFO - 2018-03-29 18:07:43 --> Model Class Initialized
INFO - 2018-03-29 18:07:43 --> Helper loaded: inflector_helper
INFO - 2018-03-29 18:07:43 --> Helper loaded: url_helper
INFO - 2018-03-29 18:07:43 --> Helper loaded: notification_helper
INFO - 2018-03-29 18:07:43 --> Helper loaded: settings_helper
INFO - 2018-03-29 18:07:43 --> Helper loaded: permission_helper
DEBUG - 2018-03-29 18:07:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 18:07:43 --> Helper loaded: users_helper
INFO - 2018-03-29 18:07:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 18:07:43 --> Model Class Initialized
INFO - 2018-03-29 18:07:43 --> Model Class Initialized
INFO - 2018-03-29 18:07:44 --> Model Class Initialized
INFO - 2018-03-29 18:07:44 --> Model Class Initialized
INFO - 2018-03-29 18:07:44 --> Model Class Initialized
INFO - 2018-03-29 18:07:44 --> Model Class Initialized
INFO - 2018-03-29 18:07:44 --> Model Class Initialized
INFO - 2018-03-29 18:07:44 --> Model Class Initialized
INFO - 2018-03-29 18:07:44 --> Model Class Initialized
INFO - 2018-03-29 18:07:44 --> Model Class Initialized
INFO - 2018-03-29 18:07:44 --> Model Class Initialized
INFO - 2018-03-29 18:07:44 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 18:07:44 --> Model Class Initialized
INFO - 2018-03-29 18:07:44 --> Database Driver Class Initialized
INFO - 2018-03-29 18:07:44 --> Final output sent to browser
DEBUG - 2018-03-29 18:07:44 --> Total execution time: 2.7101
DEBUG - 2018-03-29 18:07:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 18:07:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 18:07:44 --> Helper loaded: form_helper
INFO - 2018-03-29 18:07:44 --> Form Validation Class Initialized
INFO - 2018-03-29 18:07:44 --> Controller Class Initialized
INFO - 2018-03-29 18:07:44 --> Model Class Initialized
INFO - 2018-03-29 18:07:44 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 18:07:44 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 18:07:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 18:07:44 --> Model Class Initialized
INFO - 2018-03-29 18:07:44 --> Model Class Initialized
INFO - 2018-03-29 18:07:44 --> Model Class Initialized
INFO - 2018-03-29 18:07:44 --> Model Class Initialized
INFO - 2018-03-29 18:07:44 --> Model Class Initialized
INFO - 2018-03-29 18:07:44 --> Model Class Initialized
INFO - 2018-03-29 18:07:44 --> Model Class Initialized
INFO - 2018-03-29 18:07:44 --> Model Class Initialized
INFO - 2018-03-29 18:07:44 --> Model Class Initialized
INFO - 2018-03-29 18:07:44 --> Model Class Initialized
INFO - 2018-03-29 18:07:44 --> Model Class Initialized
INFO - 2018-03-29 18:07:44 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 18:07:44 --> Final output sent to browser
DEBUG - 2018-03-29 18:07:44 --> Total execution time: 1.6978
INFO - 2018-03-29 12:37:44 --> Config Class Initialized
INFO - 2018-03-29 12:37:44 --> Hooks Class Initialized
DEBUG - 2018-03-29 12:37:45 --> UTF-8 Support Enabled
INFO - 2018-03-29 12:37:45 --> Utf8 Class Initialized
INFO - 2018-03-29 12:37:45 --> URI Class Initialized
INFO - 2018-03-29 12:37:45 --> Router Class Initialized
INFO - 2018-03-29 12:37:45 --> Output Class Initialized
INFO - 2018-03-29 12:37:45 --> Security Class Initialized
DEBUG - 2018-03-29 12:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 12:37:45 --> Input Class Initialized
INFO - 2018-03-29 12:37:45 --> Language Class Initialized
INFO - 2018-03-29 12:37:46 --> Language Class Initialized
INFO - 2018-03-29 12:37:46 --> Config Class Initialized
INFO - 2018-03-29 12:37:46 --> Loader Class Initialized
INFO - 2018-03-29 18:07:46 --> Helper loaded: url_helper
INFO - 2018-03-29 18:07:46 --> Helper loaded: notification_helper
INFO - 2018-03-29 18:07:46 --> Helper loaded: settings_helper
INFO - 2018-03-29 18:07:46 --> Helper loaded: permission_helper
INFO - 2018-03-29 18:07:46 --> Helper loaded: users_helper
INFO - 2018-03-29 18:07:47 --> Database Driver Class Initialized
DEBUG - 2018-03-29 18:07:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 18:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 18:07:48 --> Helper loaded: form_helper
INFO - 2018-03-29 18:07:48 --> Form Validation Class Initialized
INFO - 2018-03-29 18:07:48 --> Controller Class Initialized
INFO - 2018-03-29 18:07:48 --> Model Class Initialized
INFO - 2018-03-29 18:07:48 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 18:07:48 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 18:07:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 18:07:49 --> Model Class Initialized
INFO - 2018-03-29 18:07:49 --> Model Class Initialized
INFO - 2018-03-29 18:07:49 --> Model Class Initialized
INFO - 2018-03-29 18:07:49 --> Model Class Initialized
INFO - 2018-03-29 18:07:49 --> Model Class Initialized
INFO - 2018-03-29 18:07:49 --> Model Class Initialized
INFO - 2018-03-29 18:07:49 --> Model Class Initialized
INFO - 2018-03-29 18:07:49 --> Model Class Initialized
INFO - 2018-03-29 18:07:49 --> Model Class Initialized
INFO - 2018-03-29 18:07:49 --> Model Class Initialized
INFO - 2018-03-29 18:07:49 --> Model Class Initialized
INFO - 2018-03-29 18:07:49 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 18:07:49 --> Model Class Initialized
INFO - 2018-03-29 18:07:49 --> Final output sent to browser
DEBUG - 2018-03-29 18:07:49 --> Total execution time: 5.2665
INFO - 2018-03-29 12:37:52 --> Config Class Initialized
INFO - 2018-03-29 12:37:52 --> Hooks Class Initialized
DEBUG - 2018-03-29 12:37:53 --> UTF-8 Support Enabled
INFO - 2018-03-29 12:37:53 --> Utf8 Class Initialized
INFO - 2018-03-29 12:37:53 --> URI Class Initialized
INFO - 2018-03-29 12:37:53 --> Router Class Initialized
INFO - 2018-03-29 12:37:53 --> Config Class Initialized
INFO - 2018-03-29 12:37:53 --> Hooks Class Initialized
DEBUG - 2018-03-29 12:37:53 --> UTF-8 Support Enabled
INFO - 2018-03-29 12:37:53 --> Utf8 Class Initialized
INFO - 2018-03-29 12:37:53 --> URI Class Initialized
INFO - 2018-03-29 12:37:53 --> Router Class Initialized
INFO - 2018-03-29 12:37:53 --> Output Class Initialized
INFO - 2018-03-29 12:37:53 --> Security Class Initialized
DEBUG - 2018-03-29 12:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 12:37:53 --> Input Class Initialized
INFO - 2018-03-29 12:37:53 --> Language Class Initialized
INFO - 2018-03-29 12:37:53 --> Language Class Initialized
INFO - 2018-03-29 12:37:53 --> Config Class Initialized
INFO - 2018-03-29 12:37:53 --> Loader Class Initialized
INFO - 2018-03-29 18:07:53 --> Helper loaded: url_helper
INFO - 2018-03-29 18:07:53 --> Helper loaded: notification_helper
INFO - 2018-03-29 18:07:53 --> Helper loaded: settings_helper
INFO - 2018-03-29 18:07:53 --> Helper loaded: permission_helper
INFO - 2018-03-29 18:07:53 --> Helper loaded: users_helper
INFO - 2018-03-29 12:37:53 --> Output Class Initialized
INFO - 2018-03-29 18:07:53 --> Database Driver Class Initialized
INFO - 2018-03-29 12:37:53 --> Security Class Initialized
DEBUG - 2018-03-29 18:07:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 18:07:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-03-29 12:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 12:37:53 --> Input Class Initialized
INFO - 2018-03-29 18:07:53 --> Helper loaded: form_helper
INFO - 2018-03-29 18:07:53 --> Form Validation Class Initialized
INFO - 2018-03-29 18:07:53 --> Controller Class Initialized
INFO - 2018-03-29 12:37:53 --> Language Class Initialized
INFO - 2018-03-29 18:07:54 --> Model Class Initialized
INFO - 2018-03-29 18:07:54 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 18:07:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 18:07:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 18:07:54 --> Model Class Initialized
INFO - 2018-03-29 18:07:54 --> Model Class Initialized
INFO - 2018-03-29 18:07:54 --> Model Class Initialized
INFO - 2018-03-29 18:07:54 --> Model Class Initialized
INFO - 2018-03-29 18:07:55 --> Model Class Initialized
INFO - 2018-03-29 18:07:55 --> Model Class Initialized
INFO - 2018-03-29 18:07:55 --> Model Class Initialized
INFO - 2018-03-29 18:07:55 --> Model Class Initialized
INFO - 2018-03-29 18:07:55 --> Model Class Initialized
INFO - 2018-03-29 18:07:55 --> Model Class Initialized
INFO - 2018-03-29 12:37:55 --> Language Class Initialized
INFO - 2018-03-29 12:37:55 --> Config Class Initialized
INFO - 2018-03-29 12:37:55 --> Loader Class Initialized
INFO - 2018-03-29 18:07:55 --> Helper loaded: url_helper
INFO - 2018-03-29 18:07:55 --> Helper loaded: notification_helper
INFO - 2018-03-29 18:07:55 --> Model Class Initialized
INFO - 2018-03-29 18:07:55 --> Helper loaded: settings_helper
INFO - 2018-03-29 18:07:55 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 18:07:55 --> Helper loaded: permission_helper
INFO - 2018-03-29 18:07:55 --> Helper loaded: users_helper
INFO - 2018-03-29 18:07:55 --> Final output sent to browser
DEBUG - 2018-03-29 18:07:55 --> Total execution time: 2.3058
INFO - 2018-03-29 18:07:55 --> Database Driver Class Initialized
DEBUG - 2018-03-29 18:07:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 18:07:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 18:07:55 --> Helper loaded: form_helper
INFO - 2018-03-29 18:07:55 --> Form Validation Class Initialized
INFO - 2018-03-29 18:07:55 --> Controller Class Initialized
INFO - 2018-03-29 18:07:56 --> Model Class Initialized
INFO - 2018-03-29 18:07:56 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 18:07:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 18:07:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 18:07:56 --> Model Class Initialized
INFO - 2018-03-29 18:07:56 --> Model Class Initialized
INFO - 2018-03-29 18:07:56 --> Model Class Initialized
INFO - 2018-03-29 18:07:56 --> Model Class Initialized
INFO - 2018-03-29 18:07:56 --> Model Class Initialized
INFO - 2018-03-29 18:07:56 --> Model Class Initialized
INFO - 2018-03-29 18:07:56 --> Model Class Initialized
INFO - 2018-03-29 18:07:56 --> Model Class Initialized
INFO - 2018-03-29 18:07:56 --> Model Class Initialized
INFO - 2018-03-29 18:07:56 --> Model Class Initialized
INFO - 2018-03-29 18:07:56 --> Model Class Initialized
INFO - 2018-03-29 18:07:56 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 18:07:56 --> Final output sent to browser
DEBUG - 2018-03-29 18:07:56 --> Total execution time: 3.5569
INFO - 2018-03-29 12:37:58 --> Config Class Initialized
INFO - 2018-03-29 12:37:58 --> Hooks Class Initialized
DEBUG - 2018-03-29 12:37:58 --> UTF-8 Support Enabled
INFO - 2018-03-29 12:37:58 --> Utf8 Class Initialized
INFO - 2018-03-29 12:37:59 --> URI Class Initialized
INFO - 2018-03-29 12:37:59 --> Router Class Initialized
INFO - 2018-03-29 12:37:59 --> Output Class Initialized
INFO - 2018-03-29 12:37:59 --> Security Class Initialized
DEBUG - 2018-03-29 12:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 12:37:59 --> Input Class Initialized
INFO - 2018-03-29 12:37:59 --> Language Class Initialized
INFO - 2018-03-29 12:37:59 --> Language Class Initialized
INFO - 2018-03-29 12:37:59 --> Config Class Initialized
INFO - 2018-03-29 12:37:59 --> Loader Class Initialized
INFO - 2018-03-29 18:07:59 --> Helper loaded: url_helper
INFO - 2018-03-29 18:07:59 --> Helper loaded: notification_helper
INFO - 2018-03-29 18:07:59 --> Helper loaded: settings_helper
INFO - 2018-03-29 18:07:59 --> Helper loaded: permission_helper
INFO - 2018-03-29 18:07:59 --> Helper loaded: users_helper
INFO - 2018-03-29 18:08:00 --> Database Driver Class Initialized
DEBUG - 2018-03-29 18:08:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 18:08:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 18:08:00 --> Helper loaded: form_helper
INFO - 2018-03-29 18:08:00 --> Form Validation Class Initialized
INFO - 2018-03-29 18:08:00 --> Controller Class Initialized
INFO - 2018-03-29 18:08:00 --> Model Class Initialized
INFO - 2018-03-29 18:08:00 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 18:08:00 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 18:08:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 18:08:00 --> Model Class Initialized
INFO - 2018-03-29 18:08:00 --> Model Class Initialized
INFO - 2018-03-29 18:08:00 --> Model Class Initialized
INFO - 2018-03-29 18:08:00 --> Model Class Initialized
INFO - 2018-03-29 18:08:00 --> Model Class Initialized
INFO - 2018-03-29 18:08:00 --> Model Class Initialized
INFO - 2018-03-29 18:08:00 --> Model Class Initialized
INFO - 2018-03-29 18:08:00 --> Model Class Initialized
INFO - 2018-03-29 18:08:00 --> Model Class Initialized
INFO - 2018-03-29 18:08:00 --> Model Class Initialized
INFO - 2018-03-29 18:08:00 --> Model Class Initialized
INFO - 2018-03-29 18:08:00 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 18:08:00 --> Model Class Initialized
INFO - 2018-03-29 18:08:00 --> Final output sent to browser
DEBUG - 2018-03-29 18:08:00 --> Total execution time: 1.4947
INFO - 2018-03-29 12:38:00 --> Config Class Initialized
INFO - 2018-03-29 12:38:00 --> Hooks Class Initialized
DEBUG - 2018-03-29 12:38:00 --> UTF-8 Support Enabled
INFO - 2018-03-29 12:38:00 --> Utf8 Class Initialized
INFO - 2018-03-29 12:38:00 --> URI Class Initialized
INFO - 2018-03-29 12:38:00 --> Router Class Initialized
INFO - 2018-03-29 12:38:00 --> Output Class Initialized
INFO - 2018-03-29 12:38:00 --> Security Class Initialized
DEBUG - 2018-03-29 12:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 12:38:00 --> Input Class Initialized
INFO - 2018-03-29 12:38:00 --> Language Class Initialized
INFO - 2018-03-29 12:38:00 --> Language Class Initialized
INFO - 2018-03-29 12:38:00 --> Config Class Initialized
INFO - 2018-03-29 12:38:00 --> Loader Class Initialized
INFO - 2018-03-29 18:08:00 --> Helper loaded: url_helper
INFO - 2018-03-29 18:08:00 --> Helper loaded: notification_helper
INFO - 2018-03-29 18:08:00 --> Helper loaded: settings_helper
INFO - 2018-03-29 18:08:00 --> Helper loaded: permission_helper
INFO - 2018-03-29 18:08:00 --> Helper loaded: users_helper
INFO - 2018-03-29 18:08:00 --> Database Driver Class Initialized
DEBUG - 2018-03-29 18:08:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 18:08:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 18:08:00 --> Helper loaded: form_helper
INFO - 2018-03-29 18:08:00 --> Form Validation Class Initialized
INFO - 2018-03-29 18:08:00 --> Controller Class Initialized
INFO - 2018-03-29 18:08:00 --> Model Class Initialized
INFO - 2018-03-29 18:08:00 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 18:08:00 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 18:08:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 18:08:00 --> Model Class Initialized
INFO - 2018-03-29 18:08:00 --> Model Class Initialized
INFO - 2018-03-29 18:08:00 --> Model Class Initialized
INFO - 2018-03-29 18:08:00 --> Model Class Initialized
INFO - 2018-03-29 18:08:00 --> Model Class Initialized
INFO - 2018-03-29 18:08:00 --> Model Class Initialized
INFO - 2018-03-29 18:08:00 --> Model Class Initialized
INFO - 2018-03-29 18:08:00 --> Model Class Initialized
INFO - 2018-03-29 18:08:00 --> Model Class Initialized
INFO - 2018-03-29 18:08:00 --> Model Class Initialized
INFO - 2018-03-29 18:08:00 --> Model Class Initialized
INFO - 2018-03-29 18:08:00 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 18:08:00 --> Model Class Initialized
INFO - 2018-03-29 18:08:00 --> Final output sent to browser
DEBUG - 2018-03-29 18:08:00 --> Total execution time: 0.2790
INFO - 2018-03-29 12:38:11 --> Config Class Initialized
INFO - 2018-03-29 12:38:11 --> Hooks Class Initialized
DEBUG - 2018-03-29 12:38:11 --> UTF-8 Support Enabled
INFO - 2018-03-29 12:38:11 --> Utf8 Class Initialized
INFO - 2018-03-29 12:38:11 --> URI Class Initialized
INFO - 2018-03-29 12:38:11 --> Router Class Initialized
INFO - 2018-03-29 12:38:11 --> Output Class Initialized
INFO - 2018-03-29 12:38:11 --> Security Class Initialized
DEBUG - 2018-03-29 12:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 12:38:11 --> Input Class Initialized
INFO - 2018-03-29 12:38:11 --> Language Class Initialized
INFO - 2018-03-29 12:38:11 --> Language Class Initialized
INFO - 2018-03-29 12:38:11 --> Config Class Initialized
INFO - 2018-03-29 12:38:11 --> Loader Class Initialized
INFO - 2018-03-29 18:08:11 --> Helper loaded: url_helper
INFO - 2018-03-29 18:08:11 --> Helper loaded: notification_helper
INFO - 2018-03-29 18:08:11 --> Helper loaded: settings_helper
INFO - 2018-03-29 18:08:11 --> Helper loaded: permission_helper
INFO - 2018-03-29 18:08:11 --> Helper loaded: users_helper
INFO - 2018-03-29 18:08:11 --> Database Driver Class Initialized
DEBUG - 2018-03-29 18:08:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 18:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 18:08:11 --> Helper loaded: form_helper
INFO - 2018-03-29 18:08:11 --> Form Validation Class Initialized
INFO - 2018-03-29 18:08:11 --> Controller Class Initialized
INFO - 2018-03-29 18:08:11 --> Model Class Initialized
INFO - 2018-03-29 18:08:11 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 18:08:11 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 18:08:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 18:08:11 --> Model Class Initialized
INFO - 2018-03-29 18:08:11 --> Model Class Initialized
INFO - 2018-03-29 18:08:11 --> Model Class Initialized
INFO - 2018-03-29 18:08:11 --> Model Class Initialized
INFO - 2018-03-29 18:08:11 --> Model Class Initialized
INFO - 2018-03-29 18:08:11 --> Model Class Initialized
INFO - 2018-03-29 18:08:11 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 18:08:11 --> Final output sent to browser
DEBUG - 2018-03-29 18:08:11 --> Total execution time: 0.1109
INFO - 2018-03-29 12:38:12 --> Config Class Initialized
INFO - 2018-03-29 12:38:12 --> Hooks Class Initialized
DEBUG - 2018-03-29 12:38:12 --> UTF-8 Support Enabled
INFO - 2018-03-29 12:38:12 --> Utf8 Class Initialized
INFO - 2018-03-29 12:38:12 --> URI Class Initialized
INFO - 2018-03-29 12:38:12 --> Router Class Initialized
INFO - 2018-03-29 12:38:12 --> Output Class Initialized
INFO - 2018-03-29 12:38:12 --> Security Class Initialized
DEBUG - 2018-03-29 12:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 12:38:12 --> Input Class Initialized
INFO - 2018-03-29 12:38:12 --> Language Class Initialized
INFO - 2018-03-29 12:38:13 --> Language Class Initialized
INFO - 2018-03-29 12:38:13 --> Config Class Initialized
INFO - 2018-03-29 12:38:13 --> Loader Class Initialized
INFO - 2018-03-29 18:08:13 --> Helper loaded: url_helper
INFO - 2018-03-29 18:08:13 --> Helper loaded: notification_helper
INFO - 2018-03-29 18:08:13 --> Helper loaded: settings_helper
INFO - 2018-03-29 18:08:13 --> Helper loaded: permission_helper
INFO - 2018-03-29 18:08:13 --> Helper loaded: users_helper
INFO - 2018-03-29 18:08:14 --> Database Driver Class Initialized
DEBUG - 2018-03-29 18:08:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 18:08:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 18:08:14 --> Helper loaded: form_helper
INFO - 2018-03-29 18:08:14 --> Form Validation Class Initialized
INFO - 2018-03-29 18:08:14 --> Controller Class Initialized
INFO - 2018-03-29 18:08:14 --> Model Class Initialized
INFO - 2018-03-29 18:08:14 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 18:08:14 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 18:08:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 18:08:14 --> Model Class Initialized
INFO - 2018-03-29 18:08:14 --> Model Class Initialized
INFO - 2018-03-29 18:08:14 --> Model Class Initialized
INFO - 2018-03-29 18:08:14 --> Model Class Initialized
INFO - 2018-03-29 18:08:14 --> Model Class Initialized
INFO - 2018-03-29 18:08:14 --> Model Class Initialized
INFO - 2018-03-29 18:08:14 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 18:08:15 --> Final output sent to browser
DEBUG - 2018-03-29 18:08:15 --> Total execution time: 2.8292
INFO - 2018-03-29 12:38:15 --> Config Class Initialized
INFO - 2018-03-29 12:38:15 --> Hooks Class Initialized
DEBUG - 2018-03-29 12:38:15 --> UTF-8 Support Enabled
INFO - 2018-03-29 12:38:15 --> Utf8 Class Initialized
INFO - 2018-03-29 12:38:15 --> URI Class Initialized
INFO - 2018-03-29 12:38:15 --> Router Class Initialized
INFO - 2018-03-29 12:38:16 --> Output Class Initialized
INFO - 2018-03-29 12:38:16 --> Security Class Initialized
DEBUG - 2018-03-29 12:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 12:38:16 --> Input Class Initialized
INFO - 2018-03-29 12:38:16 --> Language Class Initialized
INFO - 2018-03-29 12:38:16 --> Language Class Initialized
INFO - 2018-03-29 12:38:17 --> Config Class Initialized
INFO - 2018-03-29 12:38:17 --> Loader Class Initialized
INFO - 2018-03-29 18:08:17 --> Helper loaded: url_helper
INFO - 2018-03-29 18:08:17 --> Helper loaded: notification_helper
INFO - 2018-03-29 18:08:17 --> Helper loaded: settings_helper
INFO - 2018-03-29 18:08:17 --> Helper loaded: permission_helper
INFO - 2018-03-29 18:08:17 --> Helper loaded: users_helper
INFO - 2018-03-29 18:08:18 --> Database Driver Class Initialized
DEBUG - 2018-03-29 18:08:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 18:08:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 18:08:18 --> Helper loaded: form_helper
INFO - 2018-03-29 18:08:18 --> Form Validation Class Initialized
INFO - 2018-03-29 18:08:18 --> Controller Class Initialized
INFO - 2018-03-29 18:08:18 --> Model Class Initialized
INFO - 2018-03-29 18:08:18 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 18:08:18 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 18:08:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 18:08:18 --> Model Class Initialized
INFO - 2018-03-29 18:08:18 --> Model Class Initialized
INFO - 2018-03-29 18:08:18 --> Model Class Initialized
INFO - 2018-03-29 18:08:18 --> Model Class Initialized
INFO - 2018-03-29 18:08:18 --> Model Class Initialized
INFO - 2018-03-29 18:08:18 --> Model Class Initialized
INFO - 2018-03-29 18:08:18 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 18:08:18 --> Final output sent to browser
DEBUG - 2018-03-29 18:08:18 --> Total execution time: 3.0874
INFO - 2018-03-29 12:38:43 --> Config Class Initialized
INFO - 2018-03-29 12:38:43 --> Hooks Class Initialized
INFO - 2018-03-29 12:38:43 --> Config Class Initialized
INFO - 2018-03-29 12:38:43 --> Hooks Class Initialized
DEBUG - 2018-03-29 12:38:43 --> UTF-8 Support Enabled
INFO - 2018-03-29 12:38:43 --> Utf8 Class Initialized
DEBUG - 2018-03-29 12:38:43 --> UTF-8 Support Enabled
INFO - 2018-03-29 12:38:43 --> Utf8 Class Initialized
INFO - 2018-03-29 12:38:43 --> URI Class Initialized
INFO - 2018-03-29 12:38:43 --> URI Class Initialized
INFO - 2018-03-29 12:38:43 --> Router Class Initialized
INFO - 2018-03-29 12:38:43 --> Router Class Initialized
INFO - 2018-03-29 12:38:43 --> Output Class Initialized
INFO - 2018-03-29 12:38:43 --> Security Class Initialized
INFO - 2018-03-29 12:38:43 --> Output Class Initialized
DEBUG - 2018-03-29 12:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 12:38:43 --> Input Class Initialized
INFO - 2018-03-29 12:38:43 --> Security Class Initialized
INFO - 2018-03-29 12:38:43 --> Language Class Initialized
INFO - 2018-03-29 12:38:43 --> Language Class Initialized
INFO - 2018-03-29 12:38:43 --> Config Class Initialized
INFO - 2018-03-29 12:38:43 --> Loader Class Initialized
INFO - 2018-03-29 18:08:43 --> Helper loaded: url_helper
INFO - 2018-03-29 18:08:43 --> Helper loaded: notification_helper
INFO - 2018-03-29 18:08:43 --> Helper loaded: settings_helper
INFO - 2018-03-29 18:08:43 --> Helper loaded: permission_helper
INFO - 2018-03-29 18:08:43 --> Helper loaded: users_helper
DEBUG - 2018-03-29 12:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 12:38:43 --> Input Class Initialized
INFO - 2018-03-29 18:08:43 --> Database Driver Class Initialized
DEBUG - 2018-03-29 18:08:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 18:08:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 12:38:43 --> Language Class Initialized
INFO - 2018-03-29 18:08:43 --> Helper loaded: form_helper
INFO - 2018-03-29 18:08:43 --> Form Validation Class Initialized
INFO - 2018-03-29 18:08:43 --> Controller Class Initialized
INFO - 2018-03-29 12:38:43 --> Language Class Initialized
INFO - 2018-03-29 12:38:43 --> Config Class Initialized
INFO - 2018-03-29 12:38:43 --> Loader Class Initialized
INFO - 2018-03-29 18:08:43 --> Model Class Initialized
INFO - 2018-03-29 18:08:43 --> Helper loaded: inflector_helper
INFO - 2018-03-29 18:08:43 --> Helper loaded: url_helper
INFO - 2018-03-29 18:08:43 --> Helper loaded: notification_helper
INFO - 2018-03-29 18:08:43 --> Helper loaded: settings_helper
DEBUG - 2018-03-29 18:08:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 18:08:43 --> Helper loaded: permission_helper
INFO - 2018-03-29 18:08:43 --> Helper loaded: users_helper
INFO - 2018-03-29 18:08:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 18:08:43 --> Model Class Initialized
INFO - 2018-03-29 18:08:43 --> Model Class Initialized
INFO - 2018-03-29 18:08:43 --> Model Class Initialized
INFO - 2018-03-29 18:08:43 --> Model Class Initialized
INFO - 2018-03-29 18:08:43 --> Final output sent to browser
DEBUG - 2018-03-29 18:08:43 --> Total execution time: 0.2270
INFO - 2018-03-29 18:08:43 --> Database Driver Class Initialized
DEBUG - 2018-03-29 18:08:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 18:08:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 18:08:43 --> Helper loaded: form_helper
INFO - 2018-03-29 18:08:43 --> Form Validation Class Initialized
INFO - 2018-03-29 18:08:43 --> Controller Class Initialized
INFO - 2018-03-29 18:08:43 --> Model Class Initialized
INFO - 2018-03-29 18:08:43 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 18:08:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 18:08:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 18:08:43 --> Model Class Initialized
INFO - 2018-03-29 18:08:43 --> Model Class Initialized
INFO - 2018-03-29 18:08:43 --> Model Class Initialized
INFO - 2018-03-29 18:08:43 --> Model Class Initialized
INFO - 2018-03-29 18:08:43 --> Final output sent to browser
DEBUG - 2018-03-29 18:08:43 --> Total execution time: 0.2781
INFO - 2018-03-29 12:38:45 --> Config Class Initialized
INFO - 2018-03-29 12:38:45 --> Hooks Class Initialized
DEBUG - 2018-03-29 12:38:45 --> UTF-8 Support Enabled
INFO - 2018-03-29 12:38:45 --> Utf8 Class Initialized
INFO - 2018-03-29 12:38:45 --> URI Class Initialized
INFO - 2018-03-29 12:38:45 --> Router Class Initialized
INFO - 2018-03-29 12:38:45 --> Output Class Initialized
INFO - 2018-03-29 12:38:45 --> Security Class Initialized
DEBUG - 2018-03-29 12:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 12:38:45 --> Input Class Initialized
INFO - 2018-03-29 12:38:45 --> Language Class Initialized
INFO - 2018-03-29 12:38:45 --> Language Class Initialized
INFO - 2018-03-29 12:38:45 --> Config Class Initialized
INFO - 2018-03-29 12:38:45 --> Loader Class Initialized
INFO - 2018-03-29 18:08:45 --> Helper loaded: url_helper
INFO - 2018-03-29 18:08:45 --> Helper loaded: notification_helper
INFO - 2018-03-29 18:08:45 --> Helper loaded: settings_helper
INFO - 2018-03-29 18:08:45 --> Helper loaded: permission_helper
INFO - 2018-03-29 18:08:45 --> Helper loaded: users_helper
INFO - 2018-03-29 18:08:45 --> Database Driver Class Initialized
DEBUG - 2018-03-29 18:08:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 18:08:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 18:08:45 --> Helper loaded: form_helper
INFO - 2018-03-29 18:08:45 --> Form Validation Class Initialized
INFO - 2018-03-29 18:08:45 --> Controller Class Initialized
INFO - 2018-03-29 12:38:45 --> Config Class Initialized
INFO - 2018-03-29 12:38:45 --> Hooks Class Initialized
INFO - 2018-03-29 18:08:45 --> Model Class Initialized
INFO - 2018-03-29 18:08:45 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 18:08:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 18:08:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 18:08:45 --> Model Class Initialized
INFO - 2018-03-29 18:08:45 --> Model Class Initialized
INFO - 2018-03-29 18:08:45 --> Model Class Initialized
INFO - 2018-03-29 18:08:45 --> Model Class Initialized
INFO - 2018-03-29 18:08:45 --> Model Class Initialized
INFO - 2018-03-29 18:08:45 --> Model Class Initialized
INFO - 2018-03-29 18:08:45 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 18:08:46 --> Final output sent to browser
DEBUG - 2018-03-29 18:08:46 --> Total execution time: 0.9615
DEBUG - 2018-03-29 12:38:46 --> UTF-8 Support Enabled
INFO - 2018-03-29 12:38:46 --> Utf8 Class Initialized
INFO - 2018-03-29 12:38:46 --> URI Class Initialized
INFO - 2018-03-29 12:38:46 --> Router Class Initialized
INFO - 2018-03-29 12:38:46 --> Output Class Initialized
INFO - 2018-03-29 12:38:46 --> Security Class Initialized
DEBUG - 2018-03-29 12:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 12:38:46 --> Input Class Initialized
INFO - 2018-03-29 12:38:46 --> Language Class Initialized
INFO - 2018-03-29 12:38:47 --> Language Class Initialized
INFO - 2018-03-29 12:38:47 --> Config Class Initialized
INFO - 2018-03-29 12:38:47 --> Loader Class Initialized
INFO - 2018-03-29 18:08:47 --> Helper loaded: url_helper
INFO - 2018-03-29 18:08:47 --> Helper loaded: notification_helper
INFO - 2018-03-29 18:08:47 --> Helper loaded: settings_helper
INFO - 2018-03-29 18:08:47 --> Helper loaded: permission_helper
INFO - 2018-03-29 18:08:48 --> Helper loaded: users_helper
INFO - 2018-03-29 18:08:48 --> Database Driver Class Initialized
DEBUG - 2018-03-29 18:08:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 18:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 18:08:49 --> Helper loaded: form_helper
INFO - 2018-03-29 18:08:49 --> Form Validation Class Initialized
INFO - 2018-03-29 18:08:49 --> Controller Class Initialized
INFO - 2018-03-29 18:08:49 --> Model Class Initialized
INFO - 2018-03-29 18:08:49 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 18:08:49 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 18:08:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 18:08:49 --> Model Class Initialized
INFO - 2018-03-29 18:08:49 --> Model Class Initialized
INFO - 2018-03-29 18:08:49 --> Model Class Initialized
INFO - 2018-03-29 18:08:49 --> Model Class Initialized
INFO - 2018-03-29 18:08:49 --> Model Class Initialized
INFO - 2018-03-29 18:08:49 --> Model Class Initialized
INFO - 2018-03-29 18:08:49 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 18:08:49 --> Final output sent to browser
DEBUG - 2018-03-29 18:08:49 --> Total execution time: 3.8106
INFO - 2018-03-29 12:38:49 --> Config Class Initialized
INFO - 2018-03-29 12:38:49 --> Hooks Class Initialized
DEBUG - 2018-03-29 12:38:49 --> UTF-8 Support Enabled
INFO - 2018-03-29 12:38:49 --> Utf8 Class Initialized
INFO - 2018-03-29 12:38:50 --> URI Class Initialized
INFO - 2018-03-29 12:38:50 --> Router Class Initialized
INFO - 2018-03-29 12:38:50 --> Output Class Initialized
INFO - 2018-03-29 12:38:50 --> Security Class Initialized
DEBUG - 2018-03-29 12:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 12:38:50 --> Input Class Initialized
INFO - 2018-03-29 12:38:50 --> Language Class Initialized
INFO - 2018-03-29 12:38:51 --> Language Class Initialized
INFO - 2018-03-29 12:38:51 --> Config Class Initialized
INFO - 2018-03-29 12:38:51 --> Loader Class Initialized
INFO - 2018-03-29 18:08:51 --> Helper loaded: url_helper
INFO - 2018-03-29 18:08:51 --> Helper loaded: notification_helper
INFO - 2018-03-29 18:08:51 --> Helper loaded: settings_helper
INFO - 2018-03-29 18:08:51 --> Helper loaded: permission_helper
INFO - 2018-03-29 18:08:51 --> Helper loaded: users_helper
INFO - 2018-03-29 18:08:52 --> Database Driver Class Initialized
DEBUG - 2018-03-29 18:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 18:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 18:08:52 --> Helper loaded: form_helper
INFO - 2018-03-29 18:08:52 --> Form Validation Class Initialized
INFO - 2018-03-29 18:08:52 --> Controller Class Initialized
INFO - 2018-03-29 18:08:52 --> Model Class Initialized
INFO - 2018-03-29 18:08:52 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 18:08:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 18:08:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 18:08:52 --> Model Class Initialized
INFO - 2018-03-29 18:08:52 --> Model Class Initialized
INFO - 2018-03-29 18:08:52 --> Model Class Initialized
INFO - 2018-03-29 18:08:52 --> Model Class Initialized
INFO - 2018-03-29 18:08:52 --> Model Class Initialized
INFO - 2018-03-29 18:08:52 --> Model Class Initialized
INFO - 2018-03-29 18:08:52 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 18:08:52 --> Final output sent to browser
DEBUG - 2018-03-29 18:08:52 --> Total execution time: 3.1686
INFO - 2018-03-29 12:39:04 --> Config Class Initialized
INFO - 2018-03-29 12:39:04 --> Hooks Class Initialized
INFO - 2018-03-29 12:39:04 --> Config Class Initialized
DEBUG - 2018-03-29 12:39:04 --> UTF-8 Support Enabled
INFO - 2018-03-29 12:39:04 --> Utf8 Class Initialized
INFO - 2018-03-29 12:39:04 --> Hooks Class Initialized
INFO - 2018-03-29 12:39:04 --> URI Class Initialized
DEBUG - 2018-03-29 12:39:04 --> UTF-8 Support Enabled
INFO - 2018-03-29 12:39:04 --> Utf8 Class Initialized
INFO - 2018-03-29 12:39:04 --> URI Class Initialized
INFO - 2018-03-29 12:39:04 --> Router Class Initialized
INFO - 2018-03-29 12:39:04 --> Output Class Initialized
INFO - 2018-03-29 12:39:04 --> Router Class Initialized
INFO - 2018-03-29 12:39:04 --> Security Class Initialized
INFO - 2018-03-29 12:39:04 --> Output Class Initialized
DEBUG - 2018-03-29 12:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 12:39:04 --> Input Class Initialized
INFO - 2018-03-29 12:39:04 --> Security Class Initialized
INFO - 2018-03-29 12:39:04 --> Language Class Initialized
DEBUG - 2018-03-29 12:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 12:39:04 --> Input Class Initialized
INFO - 2018-03-29 12:39:04 --> Language Class Initialized
INFO - 2018-03-29 12:39:04 --> Language Class Initialized
INFO - 2018-03-29 12:39:04 --> Config Class Initialized
INFO - 2018-03-29 12:39:04 --> Loader Class Initialized
INFO - 2018-03-29 18:09:04 --> Helper loaded: url_helper
INFO - 2018-03-29 12:39:04 --> Language Class Initialized
INFO - 2018-03-29 12:39:04 --> Config Class Initialized
INFO - 2018-03-29 12:39:04 --> Loader Class Initialized
INFO - 2018-03-29 18:09:04 --> Helper loaded: notification_helper
INFO - 2018-03-29 18:09:04 --> Helper loaded: settings_helper
INFO - 2018-03-29 18:09:04 --> Helper loaded: permission_helper
INFO - 2018-03-29 18:09:04 --> Helper loaded: users_helper
INFO - 2018-03-29 18:09:04 --> Helper loaded: url_helper
INFO - 2018-03-29 18:09:04 --> Helper loaded: notification_helper
INFO - 2018-03-29 18:09:04 --> Helper loaded: settings_helper
INFO - 2018-03-29 18:09:04 --> Helper loaded: permission_helper
INFO - 2018-03-29 18:09:04 --> Helper loaded: users_helper
INFO - 2018-03-29 18:09:04 --> Database Driver Class Initialized
DEBUG - 2018-03-29 18:09:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 18:09:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 18:09:04 --> Helper loaded: form_helper
INFO - 2018-03-29 18:09:04 --> Form Validation Class Initialized
INFO - 2018-03-29 18:09:04 --> Controller Class Initialized
INFO - 2018-03-29 18:09:04 --> Model Class Initialized
INFO - 2018-03-29 18:09:04 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 18:09:04 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 18:09:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 18:09:04 --> Model Class Initialized
INFO - 2018-03-29 18:09:04 --> Model Class Initialized
INFO - 2018-03-29 18:09:04 --> Model Class Initialized
INFO - 2018-03-29 18:09:04 --> Model Class Initialized
INFO - 2018-03-29 18:09:04 --> Final output sent to browser
DEBUG - 2018-03-29 18:09:04 --> Total execution time: 0.5351
INFO - 2018-03-29 18:09:04 --> Database Driver Class Initialized
DEBUG - 2018-03-29 18:09:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 18:09:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 18:09:04 --> Helper loaded: form_helper
INFO - 2018-03-29 18:09:04 --> Form Validation Class Initialized
INFO - 2018-03-29 18:09:04 --> Controller Class Initialized
INFO - 2018-03-29 18:09:04 --> Model Class Initialized
INFO - 2018-03-29 18:09:04 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 18:09:04 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 18:09:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 18:09:04 --> Model Class Initialized
INFO - 2018-03-29 18:09:04 --> Model Class Initialized
INFO - 2018-03-29 18:09:04 --> Model Class Initialized
INFO - 2018-03-29 18:09:04 --> Model Class Initialized
INFO - 2018-03-29 18:09:04 --> Final output sent to browser
DEBUG - 2018-03-29 18:09:04 --> Total execution time: 0.8037
INFO - 2018-03-29 12:39:06 --> Config Class Initialized
INFO - 2018-03-29 12:39:06 --> Hooks Class Initialized
DEBUG - 2018-03-29 12:39:06 --> UTF-8 Support Enabled
INFO - 2018-03-29 12:39:06 --> Utf8 Class Initialized
INFO - 2018-03-29 12:39:06 --> URI Class Initialized
INFO - 2018-03-29 12:39:06 --> Router Class Initialized
INFO - 2018-03-29 12:39:06 --> Output Class Initialized
INFO - 2018-03-29 12:39:06 --> Security Class Initialized
DEBUG - 2018-03-29 12:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 12:39:06 --> Input Class Initialized
INFO - 2018-03-29 12:39:06 --> Language Class Initialized
INFO - 2018-03-29 12:39:06 --> Language Class Initialized
INFO - 2018-03-29 12:39:06 --> Config Class Initialized
INFO - 2018-03-29 12:39:06 --> Loader Class Initialized
INFO - 2018-03-29 18:09:06 --> Helper loaded: url_helper
INFO - 2018-03-29 18:09:06 --> Helper loaded: notification_helper
INFO - 2018-03-29 18:09:06 --> Helper loaded: settings_helper
INFO - 2018-03-29 18:09:06 --> Helper loaded: permission_helper
INFO - 2018-03-29 18:09:06 --> Helper loaded: users_helper
INFO - 2018-03-29 18:09:06 --> Database Driver Class Initialized
DEBUG - 2018-03-29 18:09:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 18:09:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 18:09:06 --> Helper loaded: form_helper
INFO - 2018-03-29 18:09:06 --> Form Validation Class Initialized
INFO - 2018-03-29 18:09:06 --> Controller Class Initialized
INFO - 2018-03-29 18:09:06 --> Model Class Initialized
INFO - 2018-03-29 18:09:06 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 18:09:06 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 18:09:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 18:09:06 --> Model Class Initialized
INFO - 2018-03-29 18:09:06 --> Model Class Initialized
INFO - 2018-03-29 18:09:06 --> Model Class Initialized
INFO - 2018-03-29 18:09:06 --> Model Class Initialized
INFO - 2018-03-29 18:09:06 --> Model Class Initialized
INFO - 2018-03-29 18:09:06 --> Model Class Initialized
INFO - 2018-03-29 18:09:06 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 18:09:06 --> Final output sent to browser
DEBUG - 2018-03-29 18:09:06 --> Total execution time: 0.2374
INFO - 2018-03-29 12:39:07 --> Config Class Initialized
INFO - 2018-03-29 12:39:07 --> Hooks Class Initialized
DEBUG - 2018-03-29 12:39:07 --> UTF-8 Support Enabled
INFO - 2018-03-29 12:39:07 --> Utf8 Class Initialized
INFO - 2018-03-29 12:39:08 --> URI Class Initialized
INFO - 2018-03-29 12:39:08 --> Router Class Initialized
INFO - 2018-03-29 12:39:08 --> Output Class Initialized
INFO - 2018-03-29 12:39:08 --> Security Class Initialized
DEBUG - 2018-03-29 12:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 12:39:08 --> Input Class Initialized
INFO - 2018-03-29 12:39:08 --> Language Class Initialized
INFO - 2018-03-29 12:39:09 --> Language Class Initialized
INFO - 2018-03-29 12:39:09 --> Config Class Initialized
INFO - 2018-03-29 12:39:09 --> Loader Class Initialized
INFO - 2018-03-29 18:09:09 --> Helper loaded: url_helper
INFO - 2018-03-29 18:09:09 --> Helper loaded: notification_helper
INFO - 2018-03-29 18:09:09 --> Helper loaded: settings_helper
INFO - 2018-03-29 12:39:09 --> Config Class Initialized
INFO - 2018-03-29 12:39:09 --> Hooks Class Initialized
INFO - 2018-03-29 18:09:09 --> Helper loaded: permission_helper
DEBUG - 2018-03-29 12:39:09 --> UTF-8 Support Enabled
INFO - 2018-03-29 12:39:09 --> Utf8 Class Initialized
INFO - 2018-03-29 12:39:09 --> URI Class Initialized
INFO - 2018-03-29 12:39:09 --> Router Class Initialized
INFO - 2018-03-29 12:39:09 --> Output Class Initialized
INFO - 2018-03-29 12:39:09 --> Security Class Initialized
DEBUG - 2018-03-29 12:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 12:39:09 --> Input Class Initialized
INFO - 2018-03-29 12:39:09 --> Language Class Initialized
INFO - 2018-03-29 18:09:09 --> Helper loaded: users_helper
INFO - 2018-03-29 12:39:09 --> Language Class Initialized
INFO - 2018-03-29 12:39:09 --> Config Class Initialized
INFO - 2018-03-29 12:39:09 --> Loader Class Initialized
INFO - 2018-03-29 18:09:09 --> Helper loaded: url_helper
INFO - 2018-03-29 18:09:09 --> Helper loaded: notification_helper
INFO - 2018-03-29 18:09:09 --> Helper loaded: settings_helper
INFO - 2018-03-29 18:09:09 --> Helper loaded: permission_helper
INFO - 2018-03-29 18:09:09 --> Helper loaded: users_helper
INFO - 2018-03-29 18:09:09 --> Database Driver Class Initialized
DEBUG - 2018-03-29 18:09:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 18:09:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 18:09:09 --> Helper loaded: form_helper
INFO - 2018-03-29 18:09:09 --> Form Validation Class Initialized
INFO - 2018-03-29 18:09:09 --> Controller Class Initialized
INFO - 2018-03-29 18:09:09 --> Model Class Initialized
INFO - 2018-03-29 18:09:09 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 18:09:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 18:09:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 18:09:09 --> Model Class Initialized
INFO - 2018-03-29 18:09:09 --> Model Class Initialized
INFO - 2018-03-29 18:09:09 --> Model Class Initialized
INFO - 2018-03-29 18:09:09 --> Model Class Initialized
INFO - 2018-03-29 18:09:09 --> Model Class Initialized
INFO - 2018-03-29 18:09:09 --> Model Class Initialized
INFO - 2018-03-29 18:09:09 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 18:09:09 --> Final output sent to browser
DEBUG - 2018-03-29 18:09:09 --> Total execution time: 0.1959
INFO - 2018-03-29 18:09:09 --> Database Driver Class Initialized
DEBUG - 2018-03-29 18:09:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 18:09:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 18:09:09 --> Helper loaded: form_helper
INFO - 2018-03-29 18:09:09 --> Form Validation Class Initialized
INFO - 2018-03-29 18:09:09 --> Controller Class Initialized
INFO - 2018-03-29 18:09:10 --> Model Class Initialized
INFO - 2018-03-29 18:09:10 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 18:09:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 18:09:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 18:09:10 --> Model Class Initialized
INFO - 2018-03-29 18:09:10 --> Model Class Initialized
INFO - 2018-03-29 18:09:10 --> Model Class Initialized
INFO - 2018-03-29 18:09:10 --> Model Class Initialized
INFO - 2018-03-29 18:09:10 --> Model Class Initialized
INFO - 2018-03-29 18:09:10 --> Model Class Initialized
INFO - 2018-03-29 18:09:10 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 18:09:10 --> Final output sent to browser
DEBUG - 2018-03-29 18:09:10 --> Total execution time: 3.2435
INFO - 2018-03-29 12:39:12 --> Config Class Initialized
INFO - 2018-03-29 12:39:12 --> Hooks Class Initialized
DEBUG - 2018-03-29 12:39:12 --> UTF-8 Support Enabled
INFO - 2018-03-29 12:39:12 --> Utf8 Class Initialized
INFO - 2018-03-29 12:39:12 --> URI Class Initialized
INFO - 2018-03-29 12:39:12 --> Router Class Initialized
INFO - 2018-03-29 12:39:12 --> Output Class Initialized
INFO - 2018-03-29 12:39:12 --> Security Class Initialized
DEBUG - 2018-03-29 12:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 12:39:12 --> Input Class Initialized
INFO - 2018-03-29 12:39:12 --> Language Class Initialized
INFO - 2018-03-29 12:39:13 --> Language Class Initialized
INFO - 2018-03-29 12:39:13 --> Config Class Initialized
INFO - 2018-03-29 12:39:13 --> Loader Class Initialized
INFO - 2018-03-29 18:09:13 --> Helper loaded: url_helper
INFO - 2018-03-29 18:09:13 --> Helper loaded: notification_helper
INFO - 2018-03-29 18:09:13 --> Helper loaded: settings_helper
INFO - 2018-03-29 18:09:13 --> Helper loaded: permission_helper
INFO - 2018-03-29 18:09:13 --> Helper loaded: users_helper
INFO - 2018-03-29 18:09:13 --> Database Driver Class Initialized
DEBUG - 2018-03-29 18:09:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 18:09:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 18:09:13 --> Helper loaded: form_helper
INFO - 2018-03-29 18:09:13 --> Form Validation Class Initialized
INFO - 2018-03-29 18:09:13 --> Controller Class Initialized
INFO - 2018-03-29 18:09:13 --> Model Class Initialized
INFO - 2018-03-29 18:09:13 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 18:09:13 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 18:09:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 18:09:13 --> Model Class Initialized
INFO - 2018-03-29 18:09:13 --> Model Class Initialized
INFO - 2018-03-29 18:09:13 --> Model Class Initialized
INFO - 2018-03-29 18:09:13 --> Model Class Initialized
INFO - 2018-03-29 18:09:13 --> Model Class Initialized
INFO - 2018-03-29 18:09:13 --> Model Class Initialized
INFO - 2018-03-29 18:09:13 --> Model Class Initialized
INFO - 2018-03-29 18:09:13 --> Model Class Initialized
INFO - 2018-03-29 18:09:13 --> Model Class Initialized
INFO - 2018-03-29 18:09:13 --> Model Class Initialized
INFO - 2018-03-29 18:09:13 --> Model Class Initialized
INFO - 2018-03-29 18:09:13 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 18:09:13 --> Final output sent to browser
DEBUG - 2018-03-29 18:09:13 --> Total execution time: 0.2393
INFO - 2018-03-29 12:39:14 --> Config Class Initialized
INFO - 2018-03-29 12:39:14 --> Hooks Class Initialized
DEBUG - 2018-03-29 12:39:14 --> UTF-8 Support Enabled
INFO - 2018-03-29 12:39:14 --> Utf8 Class Initialized
INFO - 2018-03-29 12:39:14 --> URI Class Initialized
INFO - 2018-03-29 12:39:14 --> Router Class Initialized
INFO - 2018-03-29 12:39:14 --> Output Class Initialized
INFO - 2018-03-29 12:39:14 --> Config Class Initialized
INFO - 2018-03-29 12:39:14 --> Hooks Class Initialized
DEBUG - 2018-03-29 12:39:14 --> UTF-8 Support Enabled
INFO - 2018-03-29 12:39:14 --> Utf8 Class Initialized
INFO - 2018-03-29 12:39:14 --> URI Class Initialized
INFO - 2018-03-29 12:39:14 --> Router Class Initialized
INFO - 2018-03-29 12:39:14 --> Output Class Initialized
INFO - 2018-03-29 12:39:14 --> Security Class Initialized
DEBUG - 2018-03-29 12:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 12:39:14 --> Input Class Initialized
INFO - 2018-03-29 12:39:14 --> Language Class Initialized
INFO - 2018-03-29 12:39:15 --> Language Class Initialized
INFO - 2018-03-29 12:39:15 --> Config Class Initialized
INFO - 2018-03-29 12:39:15 --> Loader Class Initialized
INFO - 2018-03-29 18:09:15 --> Helper loaded: url_helper
INFO - 2018-03-29 18:09:15 --> Helper loaded: notification_helper
INFO - 2018-03-29 18:09:15 --> Helper loaded: settings_helper
INFO - 2018-03-29 18:09:15 --> Helper loaded: permission_helper
INFO - 2018-03-29 18:09:15 --> Helper loaded: users_helper
INFO - 2018-03-29 18:09:15 --> Database Driver Class Initialized
DEBUG - 2018-03-29 18:09:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 18:09:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 18:09:15 --> Helper loaded: form_helper
INFO - 2018-03-29 18:09:15 --> Form Validation Class Initialized
INFO - 2018-03-29 18:09:15 --> Controller Class Initialized
INFO - 2018-03-29 18:09:15 --> Model Class Initialized
INFO - 2018-03-29 18:09:15 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 18:09:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 18:09:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 18:09:15 --> Model Class Initialized
INFO - 2018-03-29 18:09:15 --> Model Class Initialized
INFO - 2018-03-29 18:09:15 --> Model Class Initialized
INFO - 2018-03-29 18:09:15 --> Model Class Initialized
INFO - 2018-03-29 18:09:15 --> Model Class Initialized
INFO - 2018-03-29 18:09:15 --> Model Class Initialized
INFO - 2018-03-29 18:09:15 --> Model Class Initialized
INFO - 2018-03-29 18:09:15 --> Model Class Initialized
INFO - 2018-03-29 18:09:15 --> Model Class Initialized
INFO - 2018-03-29 18:09:15 --> Model Class Initialized
INFO - 2018-03-29 18:09:15 --> Model Class Initialized
INFO - 2018-03-29 18:09:15 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 18:09:15 --> Model Class Initialized
INFO - 2018-03-29 18:09:15 --> Final output sent to browser
DEBUG - 2018-03-29 18:09:15 --> Total execution time: 0.1584
INFO - 2018-03-29 12:39:15 --> Security Class Initialized
DEBUG - 2018-03-29 12:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 12:39:15 --> Input Class Initialized
INFO - 2018-03-29 12:39:15 --> Language Class Initialized
INFO - 2018-03-29 12:39:16 --> Config Class Initialized
INFO - 2018-03-29 12:39:16 --> Hooks Class Initialized
DEBUG - 2018-03-29 12:39:16 --> UTF-8 Support Enabled
INFO - 2018-03-29 12:39:16 --> Utf8 Class Initialized
INFO - 2018-03-29 12:39:16 --> URI Class Initialized
INFO - 2018-03-29 12:39:16 --> Router Class Initialized
INFO - 2018-03-29 12:39:16 --> Output Class Initialized
INFO - 2018-03-29 12:39:16 --> Security Class Initialized
DEBUG - 2018-03-29 12:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 12:39:16 --> Input Class Initialized
INFO - 2018-03-29 12:39:16 --> Language Class Initialized
INFO - 2018-03-29 12:39:16 --> Language Class Initialized
INFO - 2018-03-29 12:39:16 --> Config Class Initialized
INFO - 2018-03-29 12:39:16 --> Loader Class Initialized
INFO - 2018-03-29 18:09:16 --> Helper loaded: url_helper
INFO - 2018-03-29 18:09:16 --> Helper loaded: notification_helper
INFO - 2018-03-29 18:09:16 --> Helper loaded: settings_helper
INFO - 2018-03-29 18:09:16 --> Helper loaded: permission_helper
INFO - 2018-03-29 18:09:16 --> Helper loaded: users_helper
INFO - 2018-03-29 18:09:16 --> Database Driver Class Initialized
DEBUG - 2018-03-29 18:09:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 18:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 18:09:16 --> Helper loaded: form_helper
INFO - 2018-03-29 18:09:16 --> Form Validation Class Initialized
INFO - 2018-03-29 18:09:16 --> Controller Class Initialized
INFO - 2018-03-29 18:09:16 --> Model Class Initialized
INFO - 2018-03-29 18:09:16 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 18:09:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 18:09:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 18:09:16 --> Model Class Initialized
INFO - 2018-03-29 18:09:16 --> Model Class Initialized
INFO - 2018-03-29 18:09:16 --> Model Class Initialized
INFO - 2018-03-29 18:09:16 --> Model Class Initialized
INFO - 2018-03-29 18:09:16 --> Model Class Initialized
INFO - 2018-03-29 18:09:16 --> Model Class Initialized
INFO - 2018-03-29 18:09:16 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-03-29 18:09:16 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-03-29 12:39:16 --> Language Class Initialized
INFO - 2018-03-29 12:39:16 --> Config Class Initialized
INFO - 2018-03-29 12:39:16 --> Loader Class Initialized
INFO - 2018-03-29 18:09:16 --> Final output sent to browser
DEBUG - 2018-03-29 18:09:16 --> Total execution time: 0.2138
INFO - 2018-03-29 18:09:16 --> Helper loaded: url_helper
INFO - 2018-03-29 18:09:16 --> Helper loaded: notification_helper
INFO - 2018-03-29 18:09:17 --> Helper loaded: settings_helper
INFO - 2018-03-29 18:09:17 --> Helper loaded: permission_helper
INFO - 2018-03-29 18:09:17 --> Helper loaded: users_helper
INFO - 2018-03-29 18:09:17 --> Database Driver Class Initialized
DEBUG - 2018-03-29 18:09:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 18:09:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 18:09:17 --> Helper loaded: form_helper
INFO - 2018-03-29 18:09:17 --> Form Validation Class Initialized
INFO - 2018-03-29 18:09:17 --> Controller Class Initialized
INFO - 2018-03-29 18:09:17 --> Model Class Initialized
INFO - 2018-03-29 18:09:17 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 18:09:17 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 18:09:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 18:09:17 --> Model Class Initialized
INFO - 2018-03-29 18:09:17 --> Model Class Initialized
INFO - 2018-03-29 18:09:17 --> Model Class Initialized
INFO - 2018-03-29 18:09:17 --> Model Class Initialized
INFO - 2018-03-29 18:09:17 --> Model Class Initialized
INFO - 2018-03-29 18:09:17 --> Model Class Initialized
INFO - 2018-03-29 18:09:17 --> Model Class Initialized
INFO - 2018-03-29 18:09:17 --> Model Class Initialized
INFO - 2018-03-29 18:09:17 --> Model Class Initialized
INFO - 2018-03-29 18:09:17 --> Model Class Initialized
INFO - 2018-03-29 18:09:17 --> Model Class Initialized
INFO - 2018-03-29 18:09:17 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 18:09:17 --> Model Class Initialized
INFO - 2018-03-29 18:09:17 --> Final output sent to browser
DEBUG - 2018-03-29 18:09:17 --> Total execution time: 3.8556
INFO - 2018-03-29 13:01:05 --> Config Class Initialized
INFO - 2018-03-29 13:01:05 --> Hooks Class Initialized
DEBUG - 2018-03-29 13:01:05 --> UTF-8 Support Enabled
INFO - 2018-03-29 13:01:05 --> Utf8 Class Initialized
INFO - 2018-03-29 13:01:05 --> URI Class Initialized
INFO - 2018-03-29 13:01:06 --> Router Class Initialized
INFO - 2018-03-29 13:01:06 --> Output Class Initialized
INFO - 2018-03-29 13:01:06 --> Security Class Initialized
DEBUG - 2018-03-29 13:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 13:01:06 --> Input Class Initialized
INFO - 2018-03-29 13:01:06 --> Language Class Initialized
INFO - 2018-03-29 13:01:07 --> Language Class Initialized
INFO - 2018-03-29 13:01:07 --> Config Class Initialized
INFO - 2018-03-29 13:01:07 --> Loader Class Initialized
INFO - 2018-03-29 18:31:07 --> Helper loaded: url_helper
INFO - 2018-03-29 18:31:07 --> Helper loaded: notification_helper
INFO - 2018-03-29 18:31:07 --> Helper loaded: settings_helper
INFO - 2018-03-29 18:31:07 --> Helper loaded: permission_helper
INFO - 2018-03-29 18:31:07 --> Helper loaded: users_helper
INFO - 2018-03-29 18:31:08 --> Database Driver Class Initialized
DEBUG - 2018-03-29 18:31:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 18:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 18:31:08 --> Helper loaded: form_helper
INFO - 2018-03-29 18:31:08 --> Form Validation Class Initialized
INFO - 2018-03-29 18:31:08 --> Controller Class Initialized
INFO - 2018-03-29 18:31:08 --> Model Class Initialized
INFO - 2018-03-29 18:31:08 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 18:31:08 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 18:31:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 18:31:08 --> Model Class Initialized
INFO - 2018-03-29 18:31:08 --> Model Class Initialized
INFO - 2018-03-29 18:31:08 --> Model Class Initialized
INFO - 2018-03-29 18:31:08 --> Model Class Initialized
INFO - 2018-03-29 18:31:08 --> Model Class Initialized
INFO - 2018-03-29 18:31:08 --> Model Class Initialized
INFO - 2018-03-29 18:31:08 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 18:31:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-29 18:31:08 --> Final output sent to browser
DEBUG - 2018-03-29 18:31:08 --> Total execution time: 3.2645
INFO - 2018-03-29 13:01:12 --> Config Class Initialized
INFO - 2018-03-29 13:01:12 --> Hooks Class Initialized
DEBUG - 2018-03-29 13:01:12 --> UTF-8 Support Enabled
INFO - 2018-03-29 13:01:12 --> Utf8 Class Initialized
INFO - 2018-03-29 13:01:12 --> URI Class Initialized
INFO - 2018-03-29 13:01:12 --> Router Class Initialized
INFO - 2018-03-29 13:01:12 --> Output Class Initialized
INFO - 2018-03-29 13:01:12 --> Security Class Initialized
DEBUG - 2018-03-29 13:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 13:01:13 --> Input Class Initialized
INFO - 2018-03-29 13:01:13 --> Language Class Initialized
INFO - 2018-03-29 13:01:13 --> Language Class Initialized
INFO - 2018-03-29 13:01:13 --> Config Class Initialized
INFO - 2018-03-29 13:01:13 --> Loader Class Initialized
INFO - 2018-03-29 18:31:13 --> Helper loaded: url_helper
INFO - 2018-03-29 18:31:13 --> Helper loaded: notification_helper
INFO - 2018-03-29 18:31:13 --> Helper loaded: settings_helper
INFO - 2018-03-29 18:31:13 --> Helper loaded: permission_helper
INFO - 2018-03-29 18:31:13 --> Helper loaded: users_helper
INFO - 2018-03-29 18:31:14 --> Database Driver Class Initialized
DEBUG - 2018-03-29 18:31:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 18:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 18:31:14 --> Helper loaded: form_helper
INFO - 2018-03-29 18:31:14 --> Form Validation Class Initialized
INFO - 2018-03-29 18:31:14 --> Controller Class Initialized
INFO - 2018-03-29 18:31:15 --> Model Class Initialized
INFO - 2018-03-29 18:31:15 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 18:31:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 18:31:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 18:31:15 --> Model Class Initialized
INFO - 2018-03-29 18:31:15 --> Model Class Initialized
INFO - 2018-03-29 18:31:15 --> Model Class Initialized
INFO - 2018-03-29 18:31:15 --> Model Class Initialized
INFO - 2018-03-29 18:31:15 --> Model Class Initialized
INFO - 2018-03-29 18:31:15 --> Model Class Initialized
INFO - 2018-03-29 18:31:15 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 18:31:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-29 18:31:15 --> Final output sent to browser
DEBUG - 2018-03-29 18:31:15 --> Total execution time: 2.3264
INFO - 2018-03-29 13:01:16 --> Config Class Initialized
INFO - 2018-03-29 13:01:16 --> Hooks Class Initialized
DEBUG - 2018-03-29 13:01:16 --> UTF-8 Support Enabled
INFO - 2018-03-29 13:01:16 --> Utf8 Class Initialized
INFO - 2018-03-29 13:01:16 --> URI Class Initialized
INFO - 2018-03-29 13:01:16 --> Router Class Initialized
INFO - 2018-03-29 13:01:16 --> Output Class Initialized
INFO - 2018-03-29 13:01:16 --> Security Class Initialized
DEBUG - 2018-03-29 13:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 13:01:16 --> Input Class Initialized
INFO - 2018-03-29 13:01:16 --> Language Class Initialized
INFO - 2018-03-29 13:01:16 --> Language Class Initialized
INFO - 2018-03-29 13:01:16 --> Config Class Initialized
INFO - 2018-03-29 13:01:16 --> Loader Class Initialized
INFO - 2018-03-29 18:31:16 --> Helper loaded: url_helper
INFO - 2018-03-29 18:31:16 --> Helper loaded: notification_helper
INFO - 2018-03-29 18:31:16 --> Helper loaded: settings_helper
INFO - 2018-03-29 18:31:16 --> Helper loaded: permission_helper
INFO - 2018-03-29 18:31:16 --> Helper loaded: users_helper
INFO - 2018-03-29 18:31:16 --> Database Driver Class Initialized
DEBUG - 2018-03-29 18:31:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 18:31:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 18:31:16 --> Helper loaded: form_helper
INFO - 2018-03-29 18:31:16 --> Form Validation Class Initialized
INFO - 2018-03-29 18:31:16 --> Controller Class Initialized
INFO - 2018-03-29 18:31:16 --> Model Class Initialized
INFO - 2018-03-29 18:31:16 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 18:31:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 18:31:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 18:31:16 --> Model Class Initialized
INFO - 2018-03-29 18:31:16 --> Model Class Initialized
INFO - 2018-03-29 18:31:16 --> Model Class Initialized
INFO - 2018-03-29 18:31:16 --> Model Class Initialized
INFO - 2018-03-29 18:31:16 --> Model Class Initialized
INFO - 2018-03-29 18:31:16 --> Model Class Initialized
INFO - 2018-03-29 18:31:16 --> Model Class Initialized
INFO - 2018-03-29 18:31:16 --> Model Class Initialized
INFO - 2018-03-29 18:31:16 --> Model Class Initialized
INFO - 2018-03-29 18:31:16 --> Model Class Initialized
INFO - 2018-03-29 18:31:16 --> Model Class Initialized
INFO - 2018-03-29 18:31:16 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 18:31:16 --> Model Class Initialized
INFO - 2018-03-29 18:31:16 --> Final output sent to browser
DEBUG - 2018-03-29 18:31:16 --> Total execution time: 0.2666
INFO - 2018-03-29 13:01:18 --> Config Class Initialized
INFO - 2018-03-29 13:01:18 --> Hooks Class Initialized
DEBUG - 2018-03-29 13:01:18 --> UTF-8 Support Enabled
INFO - 2018-03-29 13:01:18 --> Utf8 Class Initialized
INFO - 2018-03-29 13:01:18 --> URI Class Initialized
INFO - 2018-03-29 13:01:18 --> Router Class Initialized
INFO - 2018-03-29 13:01:18 --> Output Class Initialized
INFO - 2018-03-29 13:01:18 --> Security Class Initialized
DEBUG - 2018-03-29 13:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 13:01:18 --> Input Class Initialized
INFO - 2018-03-29 13:01:18 --> Language Class Initialized
INFO - 2018-03-29 13:01:18 --> Language Class Initialized
INFO - 2018-03-29 13:01:18 --> Config Class Initialized
INFO - 2018-03-29 13:01:18 --> Loader Class Initialized
INFO - 2018-03-29 18:31:18 --> Helper loaded: url_helper
INFO - 2018-03-29 18:31:18 --> Helper loaded: notification_helper
INFO - 2018-03-29 18:31:18 --> Helper loaded: settings_helper
INFO - 2018-03-29 18:31:18 --> Helper loaded: permission_helper
INFO - 2018-03-29 18:31:18 --> Helper loaded: users_helper
INFO - 2018-03-29 18:31:18 --> Database Driver Class Initialized
DEBUG - 2018-03-29 18:31:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 18:31:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 18:31:18 --> Helper loaded: form_helper
INFO - 2018-03-29 18:31:18 --> Form Validation Class Initialized
INFO - 2018-03-29 18:31:18 --> Controller Class Initialized
INFO - 2018-03-29 18:31:18 --> Model Class Initialized
INFO - 2018-03-29 18:31:19 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 18:31:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 18:31:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 18:31:19 --> Model Class Initialized
INFO - 2018-03-29 18:31:19 --> Model Class Initialized
INFO - 2018-03-29 18:31:19 --> Model Class Initialized
INFO - 2018-03-29 18:31:19 --> Model Class Initialized
INFO - 2018-03-29 18:31:19 --> Model Class Initialized
INFO - 2018-03-29 18:31:19 --> Model Class Initialized
INFO - 2018-03-29 18:31:19 --> Model Class Initialized
INFO - 2018-03-29 18:31:19 --> Model Class Initialized
INFO - 2018-03-29 18:31:19 --> Model Class Initialized
INFO - 2018-03-29 18:31:19 --> Model Class Initialized
INFO - 2018-03-29 18:31:19 --> Model Class Initialized
INFO - 2018-03-29 18:31:19 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 18:31:19 --> Model Class Initialized
INFO - 2018-03-29 18:31:19 --> Final output sent to browser
DEBUG - 2018-03-29 18:31:19 --> Total execution time: 0.2658
INFO - 2018-03-29 13:01:19 --> Config Class Initialized
INFO - 2018-03-29 13:01:19 --> Hooks Class Initialized
DEBUG - 2018-03-29 13:01:19 --> UTF-8 Support Enabled
INFO - 2018-03-29 13:01:19 --> Utf8 Class Initialized
INFO - 2018-03-29 13:01:19 --> URI Class Initialized
INFO - 2018-03-29 13:01:19 --> Router Class Initialized
INFO - 2018-03-29 13:01:19 --> Output Class Initialized
INFO - 2018-03-29 13:01:19 --> Security Class Initialized
DEBUG - 2018-03-29 13:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 13:01:20 --> Input Class Initialized
INFO - 2018-03-29 13:01:20 --> Language Class Initialized
INFO - 2018-03-29 13:01:20 --> Language Class Initialized
INFO - 2018-03-29 13:01:20 --> Config Class Initialized
INFO - 2018-03-29 13:01:20 --> Loader Class Initialized
INFO - 2018-03-29 18:31:20 --> Helper loaded: url_helper
INFO - 2018-03-29 18:31:20 --> Helper loaded: notification_helper
INFO - 2018-03-29 18:31:20 --> Helper loaded: settings_helper
INFO - 2018-03-29 18:31:20 --> Helper loaded: permission_helper
INFO - 2018-03-29 18:31:21 --> Helper loaded: users_helper
INFO - 2018-03-29 18:31:21 --> Database Driver Class Initialized
DEBUG - 2018-03-29 18:31:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 18:31:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 18:31:21 --> Helper loaded: form_helper
INFO - 2018-03-29 18:31:21 --> Form Validation Class Initialized
INFO - 2018-03-29 18:31:21 --> Controller Class Initialized
INFO - 2018-03-29 18:31:21 --> Model Class Initialized
INFO - 2018-03-29 18:31:21 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 18:31:21 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 18:31:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 18:31:21 --> Model Class Initialized
INFO - 2018-03-29 18:31:21 --> Model Class Initialized
INFO - 2018-03-29 18:31:21 --> Model Class Initialized
INFO - 2018-03-29 18:31:21 --> Model Class Initialized
INFO - 2018-03-29 18:31:21 --> Model Class Initialized
INFO - 2018-03-29 18:31:21 --> Model Class Initialized
INFO - 2018-03-29 18:31:21 --> Model Class Initialized
INFO - 2018-03-29 18:31:21 --> Model Class Initialized
INFO - 2018-03-29 18:31:21 --> Model Class Initialized
INFO - 2018-03-29 18:31:21 --> Model Class Initialized
INFO - 2018-03-29 18:31:21 --> Model Class Initialized
INFO - 2018-03-29 18:31:21 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 18:31:21 --> Model Class Initialized
INFO - 2018-03-29 18:31:21 --> Final output sent to browser
DEBUG - 2018-03-29 18:31:21 --> Total execution time: 3.1225
INFO - 2018-03-29 13:01:26 --> Config Class Initialized
INFO - 2018-03-29 13:01:26 --> Hooks Class Initialized
DEBUG - 2018-03-29 13:01:26 --> UTF-8 Support Enabled
INFO - 2018-03-29 13:01:26 --> Utf8 Class Initialized
INFO - 2018-03-29 13:01:26 --> Config Class Initialized
INFO - 2018-03-29 13:01:26 --> Hooks Class Initialized
DEBUG - 2018-03-29 13:01:26 --> UTF-8 Support Enabled
INFO - 2018-03-29 13:01:26 --> Utf8 Class Initialized
INFO - 2018-03-29 13:01:26 --> URI Class Initialized
INFO - 2018-03-29 13:01:26 --> URI Class Initialized
INFO - 2018-03-29 13:01:26 --> Router Class Initialized
INFO - 2018-03-29 13:01:26 --> Router Class Initialized
INFO - 2018-03-29 13:01:26 --> Output Class Initialized
INFO - 2018-03-29 13:01:26 --> Output Class Initialized
INFO - 2018-03-29 13:01:26 --> Security Class Initialized
INFO - 2018-03-29 13:01:26 --> Security Class Initialized
DEBUG - 2018-03-29 13:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 13:01:26 --> Input Class Initialized
INFO - 2018-03-29 13:01:26 --> Language Class Initialized
DEBUG - 2018-03-29 13:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 13:01:26 --> Input Class Initialized
INFO - 2018-03-29 13:01:26 --> Language Class Initialized
INFO - 2018-03-29 13:01:26 --> Language Class Initialized
INFO - 2018-03-29 13:01:26 --> Config Class Initialized
INFO - 2018-03-29 13:01:26 --> Loader Class Initialized
INFO - 2018-03-29 13:01:26 --> Language Class Initialized
INFO - 2018-03-29 13:01:26 --> Config Class Initialized
INFO - 2018-03-29 13:01:26 --> Loader Class Initialized
INFO - 2018-03-29 18:31:26 --> Helper loaded: url_helper
INFO - 2018-03-29 18:31:26 --> Helper loaded: url_helper
INFO - 2018-03-29 18:31:26 --> Helper loaded: notification_helper
INFO - 2018-03-29 18:31:26 --> Helper loaded: notification_helper
INFO - 2018-03-29 18:31:26 --> Helper loaded: settings_helper
INFO - 2018-03-29 18:31:26 --> Helper loaded: settings_helper
INFO - 2018-03-29 18:31:26 --> Helper loaded: permission_helper
INFO - 2018-03-29 18:31:26 --> Helper loaded: permission_helper
INFO - 2018-03-29 18:31:26 --> Helper loaded: users_helper
INFO - 2018-03-29 18:31:26 --> Helper loaded: users_helper
INFO - 2018-03-29 18:31:26 --> Database Driver Class Initialized
INFO - 2018-03-29 18:31:26 --> Database Driver Class Initialized
DEBUG - 2018-03-29 18:31:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 18:31:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-03-29 18:31:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 18:31:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 18:31:26 --> Helper loaded: form_helper
INFO - 2018-03-29 18:31:26 --> Form Validation Class Initialized
INFO - 2018-03-29 18:31:26 --> Helper loaded: form_helper
INFO - 2018-03-29 18:31:26 --> Form Validation Class Initialized
INFO - 2018-03-29 18:31:26 --> Controller Class Initialized
INFO - 2018-03-29 18:31:26 --> Controller Class Initialized
INFO - 2018-03-29 18:31:26 --> Model Class Initialized
INFO - 2018-03-29 18:31:26 --> Model Class Initialized
INFO - 2018-03-29 18:31:26 --> Helper loaded: inflector_helper
INFO - 2018-03-29 18:31:26 --> Helper loaded: inflector_helper
DEBUG - 2018-03-29 18:31:26 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-03-29 18:31:26 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-29 18:31:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 18:31:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-29 18:31:26 --> Model Class Initialized
INFO - 2018-03-29 18:31:26 --> Model Class Initialized
INFO - 2018-03-29 18:31:26 --> Model Class Initialized
INFO - 2018-03-29 18:31:26 --> Model Class Initialized
INFO - 2018-03-29 18:31:26 --> Model Class Initialized
INFO - 2018-03-29 18:31:26 --> Model Class Initialized
INFO - 2018-03-29 18:31:26 --> Model Class Initialized
INFO - 2018-03-29 18:31:26 --> Model Class Initialized
INFO - 2018-03-29 18:31:26 --> Model Class Initialized
INFO - 2018-03-29 18:31:26 --> Model Class Initialized
INFO - 2018-03-29 18:31:26 --> Model Class Initialized
INFO - 2018-03-29 18:31:26 --> Model Class Initialized
INFO - 2018-03-29 18:31:26 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 18:31:26 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-29 18:31:26 --> Final output sent to browser
DEBUG - 2018-03-29 18:31:26 --> Total execution time: 0.3753
INFO - 2018-03-29 18:31:26 --> Final output sent to browser
DEBUG - 2018-03-29 18:31:26 --> Total execution time: 0.3798
